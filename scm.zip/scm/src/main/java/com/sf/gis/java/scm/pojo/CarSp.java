package com.sf.gis.java.scm.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 车辆轨迹滞留点
 */
@Table
public class CarSp implements Serializable {
    @Column(name = "agr_id")
    private String agrId;
    @Column(name = "agr_cnt")
    private String agrCnt;
    @Column(name = "agr_dis")
    private String agrDis;
    @Column(name = "agr_tm")
    private String agrTm;
    @Column(name = "agr_lng")
    private String agrLng;
    @Column(name = "agr_lat")
    private String agrLat;
    @Column(name = "agr_dis2sp")
    private String agrdis2sp;
    @Column(name = "agr_gh")
    private String agrGh;
    @Column(name = "agr_rs_id")
    private String agrRsId;
    @Column(name = "agr_rs_cnt")
    private String agrRsCnt;
    @Column(name = "type")
    private String type;  // DC: 集散地(distributing centre); GS: 加油站(gas station)
    @Column(name = "data_src")
    private String dataSrc;  // 数据来源：YY-粤运；SF-顺丰
    @Column(name = "cmp_partition")
    private String cmpPartition;

    public CarSp() {
    }

    public CarSp(String agrId, String agrCnt, String agrDis, String agrTm, String agrLng, String agrLat, String agrdis2sp, String agrGh, String agrRsId, String agrRsCnt, String type, String dataSrc, String cmpPartition) {
        this.agrId = agrId;
        this.agrCnt = agrCnt;
        this.agrDis = agrDis;
        this.agrTm = agrTm;
        this.agrLng = agrLng;
        this.agrLat = agrLat;
        this.agrdis2sp = agrdis2sp;
        this.agrGh = agrGh;
        this.agrRsId = agrRsId;
        this.agrRsCnt = agrRsCnt;
        this.type = type;
        this.dataSrc = dataSrc;
        this.cmpPartition = cmpPartition;
    }

    public String getAgrId() {
        return agrId;
    }

    public void setAgrId(String agrId) {
        this.agrId = agrId;
    }

    public String getAgrCnt() {
        return agrCnt;
    }

    public void setAgrCnt(String agrCnt) {
        this.agrCnt = agrCnt;
    }

    public String getAgrDis() {
        return agrDis;
    }

    public void setAgrDis(String agrDis) {
        this.agrDis = agrDis;
    }

    public String getAgrTm() {
        return agrTm;
    }

    public void setAgrTm(String agrTm) {
        this.agrTm = agrTm;
    }

    public String getAgrLng() {
        return agrLng;
    }

    public void setAgrLng(String agrLng) {
        this.agrLng = agrLng;
    }

    public String getAgrLat() {
        return agrLat;
    }

    public void setAgrLat(String agrLat) {
        this.agrLat = agrLat;
    }

    public String getAgrdis2sp() {
        return agrdis2sp;
    }

    public void setAgrdis2sp(String agrdis2sp) {
        this.agrdis2sp = agrdis2sp;
    }

    public String getAgrGh() {
        return agrGh;
    }

    public void setAgrGh(String agrGh) {
        this.agrGh = agrGh;
    }

    public String getAgrRsId() {
        return agrRsId;
    }

    public void setAgrRsId(String agrRsId) {
        this.agrRsId = agrRsId;
    }

    public String getAgrRsCnt() {
        return agrRsCnt;
    }

    public void setAgrRsCnt(String agrRsCnt) {
        this.agrRsCnt = agrRsCnt;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDataSrc() {
        return dataSrc;
    }

    public void setDataSrc(String dataSrc) {
        this.dataSrc = dataSrc;
    }

    public String getCmpPartition() {
        return cmpPartition;
    }

    public void setCmpPartition(String cmpPartition) {
        this.cmpPartition = cmpPartition;
    }

    @Override
    public String toString() {
        return "CarSp{" +
                "agrId='" + agrId + '\'' +
                ", agrCnt='" + agrCnt + '\'' +
                ", agrDis='" + agrDis + '\'' +
                ", agrTm='" + agrTm + '\'' +
                ", agrLng='" + agrLng + '\'' +
                ", agrLat='" + agrLat + '\'' +
                ", agrdis2sp='" + agrdis2sp + '\'' +
                ", agrGh='" + agrGh + '\'' +
                ", agrRsId='" + agrRsId + '\'' +
                ", agrRsCnt='" + agrRsCnt + '\'' +
                ", type='" + type + '\'' +
                ", dataSrc='" + dataSrc + '\'' +
                ", cmpPartition='" + cmpPartition + '\'' +
                '}';
    }
}
