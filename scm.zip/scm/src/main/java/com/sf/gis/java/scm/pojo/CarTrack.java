package com.sf.gis.java.scm.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 车辆轨迹表
 */
@Table
public class CarTrack implements Serializable {
    @Column(name = "un")
    private String un;
    @Column(name = "car_id")
    private String carId;
    @Column(name = "lng")
    private String lng;
    @Column(name = "lat")
    private String lat;
    @Column(name = "tm")
    private String tm;
    @Column(name = "ak")
    private String ak;

    public String getUn() {
        return un;
    }

    public void setUn(String un) {
        this.un = un;
    }

    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getTm() {
        return tm;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    @Override
    public String toString() {
        return "CarTrack{" +
                "un='" + un + '\'' +
                "carId='" + carId + '\'' +
                ", lng='" + lng + '\'' +
                ", lat='" + lat + '\'' +
                ", tm='" + tm + '\'' +
                ", ak='" + ak + '\'' +
                '}';
    }
}
