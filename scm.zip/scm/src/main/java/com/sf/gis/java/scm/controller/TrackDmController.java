package com.sf.gis.java.scm.controller;

import com.clearspring.analytics.util.Lists;
import com.github.davidmoten.geo.GeoHash;
import com.sf.gis.java.base.dto.PointDto;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.dto.StayPointDto;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.base.util.TrajectoryUtil;
import com.sf.gis.java.scm.constant.ScmConstant;
import com.sf.gis.java.scm.pojo.CarSp;
import com.sf.gis.java.scm.pojo.CarTrack;
import com.sf.gis.java.scm.service.CarTrackService;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;

public class TrackDmController {
    private static final Logger logger = LoggerFactory.getLogger(TrackDmController.class);

    private static final CarTrackService ctSvc = new CarTrackService();

    public void process(String operType, String ak, String startDate, String endDate, int splitTmDc, int splitDisDc, int splitPCntDc, int splitDisAgrDc, int splitTmGs, int splitDisGs, int splitRegionDisGs, int splitDisAgrGs) {
        logger.error("------------------- start process -------------------");
        logger.error("operType - {}, ak - {}, startDate - {}, endDate - {}, splitTmDc - {}, splitDisDc - {}, splitPCntDc - {}, splitDisAgrDc - {}, splitTmGs - {}, splitDisGs - {}, splitRegionDisGs - {}, splitDisAgrGs - {}", new Object[]{operType, ak, startDate, endDate, splitTmDc, splitDisDc, splitPCntDc, splitDisAgrDc, splitTmGs, splitDisGs, splitRegionDisGs, splitDisAgrGs});
        SparkInfo si = SparkUtil.getSpark4GisBd(TrackDmController.class.getName());

        String partition = ctSvc.getComParition(ak, startDate, endDate);
        Broadcast<String> partitionBc = si.getContext().broadcast(partition);
        JavaRDD<CarSp> rddYYSpSgl = null;
        if ("INIT".equals(operType)) {
            JavaRDD<CarTrack> rddInit = ctSvc.loadYyTrack(si, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("初始化轨迹信息: ak - {}, startDate - {}, endDate - {} 的数据量为：{}", ak, startDate, endDate, rddInit.count());
            rddInit.take(3).forEach(o -> logger.error("初始化数据详细信息：{}", o.toString()));

            rddYYSpSgl = rddInit.mapToPair(o -> new Tuple2<>(o.getUn(), o)).groupByKey().flatMap(o -> {
                List<CarSp> cspList = new ArrayList<>();
                List<CarTrack> carTrackList = Lists.newArrayList(o._2);
                String un = o._1;
                String cmpPartition = partitionBc.getValue();
                List<PointDto> pdList = new ArrayList<>();
                for (CarTrack tmp : carTrackList) {
                    pdList.add(new PointDto(un, Double.parseDouble(tmp.getLng()), Double.parseDouble(tmp.getLat()), Long.parseLong(tmp.getTm())));
                }
                logger.error("车辆 {} 总估计数据量：{}", un, pdList.size());
                carTrackList.clear();

                List<StayPointDto> spDcList = TrajectoryUtil.trackStayPointDm(new ArrayList<>(pdList), splitTmDc, splitDisDc, splitPCntDc);
                logger.error("车辆 {} 挖掘到的集散地数量：{}", spDcList.size());

                List<StayPointDto> spGsList = TrajectoryUtil.trackDis2spDm(new ArrayList<>(pdList), splitTmGs, splitDisGs, splitRegionDisGs);
                logger.error("车辆 {} 挖掘到的沿边加油站数量：{}", spDcList.size());
                pdList.clear();

                for (StayPointDto tmp : spDcList) {
                    cspList.add(new CarSp(un + "_" + tmp.getId(), tmp.getpCnt() + "", tmp.getDis() + "", tmp.getSpTm() + "", tmp.getCenterLng() + "", tmp.getCenterLat() + "", tmp.getDis2sp() + "", GeoHash.encodeHash(tmp.getCenterLat(), tmp.getCenterLng(), 6), "", "", ScmConstant.CAR_TRACK_TYPE_DC, ScmConstant.CAR_TRACK_DATA_SOURCE_YY, cmpPartition));
                }
                for (StayPointDto tmp : spGsList) {
                    cspList.add(new CarSp(un + "_" + tmp.getId(), tmp.getpCnt() + "", tmp.getDis() + "", tmp.getSpTm() + "", tmp.getCenterLng() + "", tmp.getCenterLat() + "", tmp.getDis2sp() + "", GeoHash.encodeHash(tmp.getCenterLat(), tmp.getCenterLng(), 6), "", "", ScmConstant.CAR_TRACK_TYPE_GS, ScmConstant.CAR_TRACK_DATA_SOURCE_YY, cmpPartition));
                }
                spDcList.clear();
                spGsList.clear();

                return cspList.iterator();
            }).repartition(50).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("单个车辆集散地和沿边加油站数据挖掘详细数量为：{}", rddYYSpSgl.count());
            rddYYSpSgl.take(3).forEach(o -> logger.error("单个车辆集散地和沿边加油站数据挖掘详细信息为：{}", o.toString()));
            rddInit.unpersist();
            DataUtil.saveOverwrite(si, "dm_gis.dwd_ddjy_track_yy_dm_sgl_di", CarSp.class, rddYYSpSgl, "cmp_partition");
        } else {
            rddYYSpSgl = ctSvc.loadSgl(si, "dm_gis.dwd_ddjy_track_yy_dm_sgl_di", partition, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("YY single 数量为：{}", rddYYSpSgl.count());
            rddYYSpSgl.take(3).forEach(o -> logger.error("YY single 详细信息为：{}", o.toString()));
        }

        JavaRDD<CarSp> rddIcSpSgl = ctSvc.loadSgl(si, "dm_gis.dwd_ddjy_mid_track_ic_dm_sgl_di", partition, startDate, endDate).map(o -> {
            o.setCmpPartition(partitionBc.getValue());
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("IC single 数量为：{}", rddIcSpSgl.count());
        rddIcSpSgl.take(3).forEach(o -> logger.error("IC single 详细信息为：{}", o.toString()));

        JavaRDD<CarSp> rddSpSgl = rddYYSpSgl.union(rddIcSpSgl).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("single 总数量为：{}", rddSpSgl.count());
        rddSpSgl.take(3).forEach(o -> logger.error("single 详细信息为：{}", o.toString()));
        rddYYSpSgl.unpersist();
        rddIcSpSgl.unpersist();

        JavaRDD<CarSp> rddSpMulti = ctSvc.sglAgr(rddSpSgl, splitDisAgrDc, splitDisAgrGs).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("多个车辆集散地和加油站数据挖掘详细数量为：{}", rddSpMulti.count());
        rddSpMulti.take(3).forEach(o -> logger.error("多个车辆集散地和加油站数据挖掘详细信息为：{}", o.toString()));
        rddSpSgl.unpersist();

        DataUtil.saveOverwrite(si, "dm_gis.dwd_ddjy_sp_dm_wi", CarSp.class, rddSpMulti, "cmp_partition");


        logger.error("------------------- end process -------------------");
    }

}
