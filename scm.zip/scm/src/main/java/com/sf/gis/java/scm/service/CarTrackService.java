package com.sf.gis.java.scm.service;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.PointDto;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.TrajectoryUtil;
import com.sf.gis.java.scm.constant.ScmConstant;
import com.sf.gis.java.scm.controller.YyTrackDmController;
import com.sf.gis.java.scm.pojo.CarSp;
import com.sf.gis.java.scm.pojo.CarTrack;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.datanucleus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 车辆轨迹滞留点挖掘（需求：李双双）
 * @author 01370539
 * Created on Jul.29 2022
 */
public class CarTrackService {
    private static final Logger logger = LoggerFactory.getLogger(CarTrackService.class);

    public JavaRDD<CarTrack> loadSfTrack(SparkInfo si, String ak, String startDate, String endDate) {
        String sql = "select distinct un, zx lng, zy lat, tm, ak, inc_day from dm_gis.gis_vms_track_device_track_flatmap where inc_day between '" + startDate + "' and '" + endDate + "' and zx != '0.0' and zx != '0' and zx != '' and zx is not null and zy != '0.0' and zy != '0' and zy != '' and zy is not null";
        if (!"ALL".equals(ak)) {
            sql += " and ak = '" + ak + "'";
        }
        return DataUtil.loadData(si, sql, CarTrack.class);
    }

    public JavaRDD<CarTrack> loadYyTrack(SparkInfo si, String startDate, String endDate) {
        String yy_partition = DateUtil.getDayAfter(endDate, "yyyyMMdd", 1);
        String sql = "select distinct car_no as un, lng, lat, tm, inc_day from dm_gis.ods_track_yy_di where inc_day = '" + yy_partition + "' and lng != '0.0' and lng != '0' and lng != '' and lng is not null and lat != '0.0' and lat != '0' and lat != '' and lat is not null";

        return DataUtil.loadData(si, sql, CarTrack.class);
    }

    public JavaRDD<CarTrack> loadCar(SparkInfo si) {
        String sql = "select car_id, device_id un from (select car_id, device_id, bind_time, ROW_NUMBER() OVER(PARTITION BY device_id ORDER BY bind_time desc) AS rn from dm_gis.tt_device_relation) tdr WHERE tdr.rn = 1";
        return DataUtil.loadData(si, sql, CarTrack.class);
    }

    public JavaRDD<CarSp> loadSingle(SparkInfo si, String cmpPartition) {
        String sql = "select * from dm_gis.ct_sp where cmp_partition = '" + cmpPartition + "'";
        return DataUtil.loadData(si, sql, CarSp.class);
    }

    public JavaRDD<CarSp> loadSgl(SparkInfo si, String tblName, String cmp_partition, String startDate, String endDate) {
        String sql = "select * from " + tblName + " where cmp_partition = '" + cmp_partition + "' or cmp_partition between '" + startDate + "' and '" + endDate + "'";
        return DataUtil.loadData(si, sql, CarSp.class);
    }

    public JavaRDD<CarSp> sglAgr(JavaRDD<CarSp> rddSpSgl, int splitDisAgrDc, int splitDisAgrGs) {
        return rddSpSgl.map(o -> {
            if ("single.csv".equals(o.getType())) {
                o.setType(ScmConstant.CAR_TRACK_TYPE_DC);
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getAgrGh() + "_" + o.getType(), o)).groupByKey().flatMap(o -> {
            String[] keyArr = o._1.split("_");
            List<CarSp> carSpList = Lists.newArrayList(o._2);
            logger.error("key {} 要处理的点数：{}", o._1, carSpList.size());
            if (carSpList.size() > 0) {
                List<PointDto> pdList = new ArrayList<>();
                for (CarSp tmp : carSpList) {
                    pdList.add(new PointDto(tmp.getAgrId(), Double.parseDouble(tmp.getAgrLng()), Double.parseDouble(tmp.getAgrLat()), 0l));
                }
                Map<String, String> agrMap;
                if (ScmConstant.CAR_TRACK_TYPE_DC.equalsIgnoreCase(keyArr[1])) {
                    agrMap = TrajectoryUtil.trackStayPointAgr(keyArr[0], new ArrayList<>(pdList), splitDisAgrDc);
                } else {
                    agrMap = TrajectoryUtil.trackStayPointAgr(keyArr[0], new ArrayList<>(pdList), splitDisAgrGs);
                }

                logger.error("key {} 能聚集的点数：{}", o._1, agrMap.size());
                carSpList.forEach(tmp -> {
                    if (agrMap.get(tmp.getAgrId()) != null) {
                        String[] rsArr = agrMap.get(tmp.getAgrId()).split("#");
                        tmp.setAgrRsId(rsArr[0]);
                        tmp.setAgrRsCnt(rsArr[1]);
                    }
                });
                agrMap.clear();
            }
            return carSpList.iterator();
        });
    }

    public String getComParition(String ak, String startDate, String endDate) {
        String comPartition = "";
        if (StringUtils.isEmpty(ak) || ScmConstant.CAR_TRACK_DATA_SOURCE_ALL.equals(ak)) {
            comPartition = startDate + "_" + endDate;
        } else {
            comPartition = ak + "_" + startDate + "_" + endDate;
        }
        return comPartition;
    }
}
