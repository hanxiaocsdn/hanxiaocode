package com.sf.gis.java.scm.controller;

import com.clearspring.analytics.util.Lists;
import com.github.davidmoten.geo.GeoHash;
import com.sf.gis.java.base.dto.PointDto;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.dto.StayPointDto;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.base.util.TrajectoryUtil;
import com.sf.gis.java.scm.constant.ScmConstant;
import com.sf.gis.java.scm.pojo.CarSp;
import com.sf.gis.java.scm.pojo.CarTrack;
import com.sf.gis.java.scm.service.CarTrackService;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 轨迹挖掘（需求：李双双）
 * @author 01370539
 * Created on Sep.09 2022
 */
public class CarTrackController {
    private static final Logger logger = LoggerFactory.getLogger(CarTrackController.class);

    private static final CarTrackService ctSvc = new CarTrackService();

    public void process(String operType, String ak, String startDate, String endDate, int splitTmDc, int splitDisDc, int splitPCntDc, int splitDisAgrDc, int splitTmGs, int splitDisGs, int splitRegionDisGs, int splitDisAgrGs) {
        logger.error("------------------- start process -------------------");
        logger.error("operType - {}, ak - {}, startDate - {}, endDate - {}, splitTmDc - {}, splitDisDc - {}, splitPCntDc - {}, splitDisAgrDc - {}, splitTmGs - {}, splitDisGs - {}, splitRegionDisGs - {}, splitDisAgrGs - {}", new Object[]{operType, ak, startDate, endDate, splitTmDc, splitDisDc, splitPCntDc, splitDisAgrDc, splitTmGs, splitDisGs, splitRegionDisGs, splitDisAgrGs});
        SparkInfo si = SparkUtil.getSpark(CarTrackController.class.getName());

        String comPartition = ctSvc.getComParition(ak, startDate, endDate);
        JavaRDD<CarSp> rddSpSingle = null;
        if (ScmConstant.CAR_TRACK_OPER_TYPE_ALL.equalsIgnoreCase(operType)) {
            JavaRDD<CarTrack> rddInit = ctSvc.loadSfTrack(si, ak, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("初始化轨迹信息: ak - {}, startDate - {}, endDate - {} 的数据量为：{}", ak, startDate, endDate, rddInit.count());
            rddInit.take(3).forEach(o -> logger.error("初始化数据详细信息：{}", o.toString()));

            JavaRDD<CarTrack> rddCar = ctSvc.loadCar(si).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("初始化车辆的数据量为：{}", rddCar.count());
            rddCar.take(3).forEach(o -> logger.error("初始化车辆的详细信息：{}", o.toString()));

            rddSpSingle = rddInit.mapToPair(o -> new Tuple2<>(o.getUn(), o)).groupByKey().leftOuterJoin(rddCar.mapToPair(o -> new Tuple2<>(o.getUn(), o)).groupByKey()).flatMap(o -> {
                List<CarSp> cspList = new ArrayList<>();
                List<CarTrack> carTrackList = Lists.newArrayList(o._2._1);
                String un = o._1;
                if (o._2._2.isPresent()) {
                    List<CarTrack> carInfoList = Lists.newArrayList(o._2._2.get());
                    if (carInfoList.size() > 0) {
                        un += "_" + carInfoList.get(0).getCarId();
                    }
                }
                String tmpAk = carTrackList.get(0).getAk();
                List<PointDto> pdList = new ArrayList<>();
                for (CarTrack tmp : carTrackList) {
                    pdList.add(new PointDto(un, Double.parseDouble(tmp.getLng()), Double.parseDouble(tmp.getLat()), Long.parseLong(tmp.getTm())));
                }
                logger.error("车辆 {} 总估计数据量：{}", un, pdList.size());
                carTrackList.clear();

                List<StayPointDto> spDcList = TrajectoryUtil.trackStayPointDm(new ArrayList<>(pdList), splitTmDc, splitDisDc, splitPCntDc);
                logger.error("车辆 {} 挖掘到的集散地数量：{}", spDcList.size());

                List<StayPointDto> spGsList = TrajectoryUtil.trackDis2spDm(new ArrayList<>(pdList), splitTmGs, splitDisGs, splitRegionDisGs);
                logger.error("车辆 {} 挖掘到的加油站数量：{}", spDcList.size());
                pdList.clear();

                for (StayPointDto tmp : spDcList) {
                    cspList.add(new CarSp(un + "_" + tmp.getId(), tmp.getpCnt() + "", tmp.getDis() + "", tmp.getSpTm() + "", tmp.getCenterLng() + "", tmp.getCenterLat() + "", tmp.getDis2sp() + "", GeoHash.encodeHash(tmp.getCenterLat(), tmp.getCenterLng(), 6), "", "", ScmConstant.CAR_TRACK_TYPE_DC, ScmConstant.CAR_TRACK_DATA_SOURCE_SF, comPartition));
                }
                for (StayPointDto tmp : spGsList) {
                    cspList.add(new CarSp(un + "_" + tmp.getId(), tmp.getpCnt() + "", tmp.getDis() + "", tmp.getSpTm() + "", tmp.getCenterLng() + "", tmp.getCenterLat() + "", tmp.getDis2sp() + "", GeoHash.encodeHash(tmp.getCenterLat(), tmp.getCenterLng(), 6), "", "", ScmConstant.CAR_TRACK_TYPE_GS, ScmConstant.CAR_TRACK_DATA_SOURCE_SF, comPartition));
                }
                spDcList.clear();
                spGsList.clear();

                return cspList.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("单个车辆集散地和加油站数据挖掘详细数量为：{}", rddSpSingle.count());
            rddSpSingle.take(3).forEach(o -> logger.error("单个车辆集散地和加油站数据挖掘详细信息为：{}", o.toString()));
            rddInit.unpersist();

            DataUtil.saveOverwrite(si, "dm_gis.ct_sp", CarSp.class, rddSpSingle, "cmp_partition");
        } else {
            rddSpSingle = ctSvc.loadSingle(si, comPartition);
            logger.error("单个车辆集散地和加油站数据挖掘详细数量为：{}", rddSpSingle.count());
            rddSpSingle.take(3).forEach(o -> logger.error("单个车辆集散地和加油站数据挖掘详细信息为：{}", o.toString()));
        }

        JavaRDD<CarSp> rddSpMulti = rddSpSingle.mapToPair(o -> new Tuple2<>(o.getAgrGh() + "_" + o.getType(), o)).groupByKey().flatMap(o -> {
            String[] keyArr = o._1.split("_");
            List<CarSp> carSpList = Lists.newArrayList(o._2);
            logger.error("key {} 要处理的点数：{}", o._1, carSpList.size());
            if (carSpList.size() > 0) {
                List<PointDto> pdList = new ArrayList<>();
                for (CarSp tmp : carSpList) {
                    pdList.add(new PointDto(tmp.getAgrId(), Double.parseDouble(tmp.getAgrLng()), Double.parseDouble(tmp.getAgrLat()), 0l));
                }
                Map<String, String> agrMap;
                if (ScmConstant.CAR_TRACK_TYPE_DC.equalsIgnoreCase(keyArr[1])) {
                    agrMap = TrajectoryUtil.trackStayPointAgr(keyArr[0], new ArrayList<>(pdList), splitDisAgrDc);
                } else {
                    agrMap = TrajectoryUtil.trackStayPointAgr(keyArr[0], pdList, splitDisAgrGs);
                }

                logger.error("key {} 能聚集的点数：{}", o._1, agrMap.size());
                carSpList.forEach(tmp -> {
                    if (agrMap.get(tmp.getAgrId()) != null) {
                        String[] rsArr = agrMap.get(tmp.getAgrId()).split("#");
                        tmp.setAgrRsId(rsArr[0]);
                        tmp.setAgrRsCnt(rsArr[1]);
                    }
                });
                agrMap.clear();
            }
            return carSpList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("多个车辆集散地和加油站数据挖掘详细数量为：{}", rddSpMulti.count());
        rddSpMulti.take(3).forEach(o -> logger.error("多个车辆集散地和加油站数据挖掘详细信息为：{}", o.toString()));
        rddSpSingle.unpersist();

        DataUtil.saveOverwrite(si, "dm_gis.ct_sp", CarSp.class, rddSpMulti, "cmp_partition");

        logger.error("------------------- end process -------------------");
    }


}
