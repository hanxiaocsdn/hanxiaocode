package com.sf.gis.java.scm.app;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.scm.constant.ScmConstant;
import com.sf.gis.java.scm.controller.CarTrackController;
import com.sf.gis.java.scm.controller.TrackDmController;
import com.sf.gis.java.scm.controller.YyTrackDmController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CarTrackApp {
    private static final Logger logger = LoggerFactory.getLogger(CarTrackApp.class);

    public static void main(String[] args) {
        if (args != null && args.length >= 12) {
            String operType = args[0];
            String ak = args[1];
            String startDate = args[2];
            String endDate = args[3];
            int splitTmDc = Integer.parseInt(args[4]);
            int splitDisDc = Integer.parseInt(args[5]);
            int splitPCntDc = Integer.parseInt(args[6]);
            int splitDisAgrDc = Integer.parseInt(args[7]);
            int splitTmGs = Integer.parseInt(args[8]);
            int splitDisGs = Integer.parseInt(args[9]);
            int splitRegionDisGs = Integer.parseInt(args[10]);
            int splitDisAgrGs = Integer.parseInt(args[11]);
            if (startDate.equals(endDate) && FixedConstant.HYPHEN.equals(startDate)) {
                startDate = DateUtil.getCurrentDateBefore("yyyyMMdd", 2);
                endDate = startDate;
            }
            if (ScmConstant.CAR_TRACK_DATA_SOURCE_YY.equals(ak)) {
                new YyTrackDmController().process(operType, ak, startDate, endDate, splitTmDc, splitDisDc, splitPCntDc, splitDisAgrDc, splitTmGs, splitDisGs, splitRegionDisGs, splitDisAgrGs);
            } else if(ScmConstant.CAR_TRACK_DATA_SOURCE_ALL.equals(ak)) {
                new TrackDmController().process(operType, ak, startDate, endDate, splitTmDc, splitDisDc, splitPCntDc, splitDisAgrDc, splitTmGs, splitDisGs, splitRegionDisGs, splitDisAgrGs);
            } else {
                new CarTrackController().process(operType, ak, startDate, endDate, splitTmDc, splitDisDc, splitPCntDc, splitDisAgrDc, splitTmGs, splitDisGs, splitRegionDisGs, splitDisAgrGs);
            }

        } else {
            logger.error("参数有异常： {}", args);
        }
    }
}
