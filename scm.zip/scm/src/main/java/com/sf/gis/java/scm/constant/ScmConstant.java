package com.sf.gis.java.scm.constant;

/**
 * 常量类
 * @author 01370539 Created On: May.07 2021
 */
public class ScmConstant {
    public static final String CAR_TRACK_TYPE_DC = "DC"; // 集散地 distributing centre
    public static final String CAR_TRACK_TYPE_GS = "GS"; // 加油站 gas station

    public static final String CAR_TRACK_OPER_TYPE_ALL = "ALL";

    public static final String CAR_TRACK_DATA_SOURCE_YY = "YY";
    public static final String CAR_TRACK_DATA_SOURCE_SF = "SF";
    public static final String CAR_TRACK_DATA_SOURCE_ALL = "ALL";
}