-- 轨迹滞留点数据表(需求：李双双，在gis bdp名称为：dm_gis.dwd_ddjy_sp_dm_wi)
CREATE TABLE `dm_gis.ct_sp`(
`agr_id` string COMMENT '聚合ID',
`agr_cnt` string COMMENT '聚合数量',
`agr_dis` string COMMENT '聚合首尾点距离',
`agr_tm` string COMMENT '聚合首尾点间隔时间',
`agr_lng` string COMMENT '聚合中心点经度',
`agr_lat` string COMMENT '聚合中心点纬度',
`agr_dis2sp` string COMMENT '到起始点的距离',
`agr_gh` string COMMENT '根据geohash分片',
`agr_rs_id` string COMMENT '大组ID（二次聚合之后的）',
`agr_rs_cnt` string COMMENT '大组数量',
`type` string COMMENT '类型(DC: 集散地(distributing centre); GS: 加油站(gas station))')
PARTITIONED BY (
`cmp_partition` string COMMENT '分区(由ak_startDate_endDate组成)')
ROW FORMAT SERDE
'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
WITH SERDEPROPERTIES (
'field.delim'='\t',
'line.delim'='\n',
'serialization.format'='\t')
STORED AS PARQUET TBLPROPERTIES('parquet.compression'='SNAPPY')