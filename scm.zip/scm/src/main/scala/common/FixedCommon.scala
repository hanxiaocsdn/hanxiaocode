package common

/**
 * @author 01418539
 * @date 2021年12月20日 10:09
 */
object FixedCommon {
  val CHARSET_UTF8 = "UTF-8"
  val CHARSET_GB = "GB18030"

}
