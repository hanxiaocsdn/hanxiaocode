package utils

import org.slf4j.LoggerFactory

import java.sql.{Connection, DriverManager}

/**
 * @author 01418539
 * @date 2022年01月20日 19:51
 */
object JDBCUtils {
  val logger = LoggerFactory.getLogger(this.getClass)

  var connection: Connection = null

  /**
   * 获取数据库连接gis_oms_lip_pns
   */
  def getDevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "gis_oms_pns"
    //密码
    val password = "gis_oms_pns@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接mysql数据库时出现错误", ex)
        throw ex
      }
    }
  }

  /**
   * 智慧社区--bdp平台上的mysql库 获取数据库gis_oms_lip_egov连接
   */
  def getDevEGOVMysqlConnect(): Connection = {

    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_egov?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "gis_oms_egov"
    //密码
    val password = "gis_oms_egov@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接mysql数据库时出现错误", ex)
        throw ex
      }
    }
  }


  /**
   * 智慧社区项目--获取dev mysql数据库连接
   */
  def getSmartDeMysqlConnect(): Connection = {

    val url = "jdbc:mysql://etraffic-m.db.sfcloud.local:3306/smart_community?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "statUser"
    //密码
    val password = "statUser@ft123"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接mysql数据库时出现错误", ex)
        throw ex
      }
    }
  }

  /**
   * 智慧社区项目--获取dev CK数据库连接
   */
  def getSmartDevCKConnect(): Connection = {

    val url = "jdbc:clickhouse://10.216.162.10:8123/gis_oms_uimp_vs"
    //驱动名称
    val driver = "ru.yandex.clickhouse.ClickHouseDriver"
    //用户名
    val username = "gis_oms_vs"
    //密码
    val password = "gis_oms_vs@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接clickhouse数据库时出现错误", ex)
        throw ex
      }
    }
  }

  /**
   * GIS-RSS-ETA：油耗数据--获取dev mysql数据库连接
   */
  def getETADevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://rosopr-m.db.sfcloud.local:3306/rosopreta?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "rosopreta"
    //密码
    val password = "steve@1234"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接ETA的mysql数据库时出现错误", ex)
        throw ex
      }
    }
  }

  /**
   * 导航大宽表：mysql数据库连接
   * todo mysql版本8.0.22
   */
  def getNaviDevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://naviqueryindex-m.db.sfcloud.local:3306/navi_index?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
    //驱动名称
    //    val driver = "com.mysql.jdbc.Driver"
    val driver = "com.mysql.cj.jdbc.Driver"
    //用户名
    val username = "navi_index"
    //密码
    val password = "hs9x+nh8u"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接NAVI的mysql数据库时出现错误", ex)
        throw ex
      }
    }
  }

  /**
   * 燃油消耗：mysql数据库连接
   */
  def getFlameDevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://vmscore-s1.db.sfcloud.local:3306/vmscore?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "vmscore"
    //密码
    val password = "vmscore123!@#"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接FLAME的mysql数据库时出现错误", ex)
        throw ex
      }
    }
  }


}
