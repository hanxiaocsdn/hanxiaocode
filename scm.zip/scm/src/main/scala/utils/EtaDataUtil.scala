//package utils
//
//import com.sf.eta.AggUtil.create_days
//import com.sf.eta.Util.addDayForamt
//import com.sf.map.{PointVector, TrackPoint}
//
//object EtaDataUtil {
//  private var gis_eta_query_log_sql = {
//	  "select  " +
//	  "eta.inc_day  " +
//	  ",eta.reqId  " +
//	  ",eta.points  " +
//	  ",eta.dataTime  " +
//	  ",concat(eta.taskId,'_',eta.srcZoneId,'_',eta.destZoneId) as group_task  " +
//	  ",eta.taskId  " +
//	  ",eta.lineCode  " +
//	  ",eta.srcZoneId  " +
//	  ",eta.destZoneId  " +
//	  ",concat(eta.srcZone_x, ',', eta.srcZone_y) as eta_srcZoneCoordinate  " +
//	  ",concat(eta.destZone_x, ',', eta.destZone_y) as eta_destZoneCoordinate  " +
//	  ",eta.plate               " +
//	  ",eta.requestTime         " +
//	  ",eta.validTime           " +
//	  ",concat(eta.x,',',eta.y) as eta_act_point  " +
//	  ",eta.tm as eta_act_time   " +
//	  ",eta.index                " +
//	  ",eta.lineType             " +
//	  ",eta.arriveTime           " +
//	  ",eta.time as eta_time     " +
//	  ",eta.dist                 " +
//	  ",eta.tmcEtaTime           " +
//	  ",eta.tmcEtaDist           " +
//	  ",eta.qmPointTime          " +
//	  ",eta.qmPointDist          " +
//	  ",eta.stdId                " +
//	  ",eta.lineSource           " +
//	  ",wmp.uid  " +
//	  ",wmp.destZoneCoordinate  " +
//	  "from (  " + "select  " +
//	  "inc_day,  " +
//	  "get_json_object(log, '$.reqId') as reqId,  " +
//	  "get_json_object(log, '$.dataTime') as dataTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.taskId') as taskId,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.lineCode') as lineCode,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.srcZoneId') as srcZoneId,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.destZoneId') as destZoneId,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.plate') as plate,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.requestTime') as requestTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.validTime') as validTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.x1') as srcZone_x,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.y1') as srcZone_y,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.x2') as destZone_x,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.y2') as destZone_y,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.result'),'$.x') as x,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.result'),'$.y') as y,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.tm') as tm,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.points') as points,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.index') as index,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.lineType') as lineType,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.arriveTime') as arriveTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.time') as time,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.dist') as dist,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.tmcEtaTime') as tmcEtaTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.tmcEtaDist') as tmcEtaDist,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.qmPointTime') as qmPointTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.qmPointDist') as qmPointDist,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.stdId') as stdId,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.lineSource') as lineSource  " +
//	  //",concat(get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.taskId'),'_',  " +
//	  //"   get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.srcZoneId'),'_',  " +
//	  //"   get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.destZoneId'),'_',  " +
//	  //"   get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.x2'),'_',  " +
//	  //"   get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.y2')) as gp  " +
//	  "from dm_gis.gis_eta_query_log  " +
//	  "where inc_day >= '%s' and inc_day <= '%s'  " +
//	  "and get_json_object(log,'$.subType')='queryLocationEta'  " +
//	  "and get_json_object(log,'$.type')='etaQuery'  " +
//	  ") as eta  " +
//	  "left join (  " +
//	  "select  " +
//	  "uid  " +
//	  ",destZoneCoordinate  " +
//	  "from (  " +
//	  "select  " +
//	  "get_json_object(info,'$.uid') uid  " +
//	  ",get_json_object(info,'$.destZoneCoordinate') destZoneCoordinate  " +
//	  ",row_number() over (partition by get_json_object(info,'$.uid') order by get_json_object(info,'$.pickUpTm') desc) as rn  " +
//	  "from dm_gis.eta_ts_wmp_info_to_hive  " +
//	  "where inc_day >= '%s' and inc_day <= '%s'  " +
//	  "and get_json_object(info,'$.status') not in (1, 2, 3)  " +
//	  ") t  " +
//	  "where t.rn = 1  " +
//	  ") wmp on eta.reqId = wmp.uid  " +
//	  " where from_unixtime(cast(requestTime as int), 'hh') in ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12') limit 10000 "
//  }
//
//  private var eta_std_line_recall_sql = {
//	  "select  " +
//	  "task_area_code  " +
//	  ",task_id  " +
//	  ",sort_num  " +
//	  ",task_subid  " +
//	  ",task_inc_day  " +
//	  ",concat(task_id,'_',start_dept,'_',end_dept) as group_task  " +
//	  ",(unix_timestamp(actual_depart_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_depart_tm, 'yyyy-MM-dd HH:mm:ss')) as act_plan_depart_tm_diff  " +
//	  ",cast((unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(actual_depart_tm, 'yyyy-MM-dd HH:mm:ss'))/600 as INT) as eta_count  " +
//	  ",(unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_arrive_tm, 'yyyy-MM-dd HH:mm:ss')) as act_delay_tm  " +
//	  ",start_dept  " +
//	  ",end_dept  " +
//	  ",start_type  " +
//	  ",end_type  " +
//	  ",line_code  " +
//	  ",vehicle_serial  " +
//	  ",actual_capacity_load  " +
//	  ",plan_depart_tm  " +
//	  ",actual_depart_tm  " +
//	  ",plan_arrive_tm  " +
//	  ",actual_arrive_tm  " +
//	  ",driver_id  " +
//	  ",driver_name  " +
//	  ",line_time  " +
//	  ",line_distance  " +
//	  ",actual_run_time  " +
//	  ",start_longitude " +
//	  ",start_latitude  " +
//	  ",end_longitude  " +
//	  ",end_latitude  " +
//	  ",is_stop  " +
//	  ",transoport_level  " +
//	  ",carrier_type  " +
//	  ",vehicle_type  " +
//	  ",axls_number  " +
//	  ",log_dist  " +
//	  ",x1  " +
//	  ",y1  " +
//	  ",x2  " +
//	  ",y2  " +
//	  ",duration  " +
//	  ",time as act_time  " +
//	  ",rt_dist  " +
//	  ",highwaymileage  " +
//	  ",toll_charge  " +
//	  ",start_distance  " +
//	  ",end_distance  " +
//	  ",src  " +
//	  ",line_distance_std  " +
//	  ",line_time_std  " +
//	  ",sim1  " +
//	  ",sim5  " +
//	  ",is_navi  " +
//	  //",concat(task_id,'_',start_dept,'_',end_dept,'_',end_longitude,'_',end_latitude) as gp  " +
//	  "from dm_gis.eta_std_line_recall  " +
//	  "where inc_day >= '%s' and inc_day <= '%s'  " +
//	  "and if_evaluate_time = '1'  limit 10000 "
//  }
//
//  def getLogSql(stime:String, etime:String)={
//	gis_eta_query_log_sql = gis_eta_query_log_sql.format(stime, etime, stime, etime)
//	gis_eta_query_log_sql
//  }
//
//  def getRecallSql(stime:String, etime:String)={
//	eta_std_line_recall_sql = eta_std_line_recall_sql.format(stime, etime)
//	eta_std_line_recall_sql
//  }
//
//
//  private var trackInfoSql:String = {
//	"select  " +
//	  "eta.inc_day  " +
//	  ",eta.gp  " +
//	  ",recall.vehicle_serial   " +
//	  ",recall.actual_depart_tm  " +
//	  ",recall.actual_arrive_tm  " +
//	  ",eta.reqId  " +
//	  ",eta.points  " +
//	  ",eta.dataTime  " +
//	  ",concat(eta.taskId,'_',eta.srcZoneId,'_',eta.destZoneId) as group_task  " +
//	  ",eta.taskId  " +
//	  ",eta.lineCode  " +
//	  ",eta.srcZoneId  " +
//	  ",eta.destZoneId  " +
//	  ",concat(eta.srcZone_x, ',', eta.srcZone_y) as eta_srcZoneCoordinate  " +
//	  ",concat(eta.destZone_x, ',', eta.destZone_y) as eta_destZoneCoordinate  " +
//	  ",eta.plate               " +
//	  ",eta.requestTime         " +
//	  ",eta.validTime           " +
//	  ",concat(eta.x,',',eta.y) as eta_act_point  " +
//	  ",eta.tm as eta_act_time   " +
//	  //",eta.index                " +
//	  //",eta.lineType             " +
//	  //",eta.arriveTime           " +
//	  //",eta.time as eta_time     " +
//	  //",eta.dist                 " +
//	  //",eta.tmcEtaTime           " +
//	  //",eta.tmcEtaDist           " +
//	  //",eta.qmPointTime          " +
//	  //",eta.qmPointDist          " +
//	  //",eta.stdId                " +
//	  //",eta.lineSource           " +
//	  ",wmp.uid  " +
//	  ",wmp.destZoneCoordinate  " +
//	  "from (  " + "select  " +
//	  "inc_day,  " +
//	  "get_json_object(log, '$.reqId') as reqId,  " +
//	  "get_json_object(log, '$.dataTime') as dataTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.taskId') as taskId,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.lineCode') as lineCode,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.srcZoneId') as srcZoneId,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.destZoneId') as destZoneId,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.plate') as plate,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.requestTime') as requestTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.validTime') as validTime,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.x1') as srcZone_x,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.y1') as srcZone_y,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.x2') as destZone_x,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.y2') as destZone_y,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.result'),'$.x') as x,  " +
//	  "get_json_object(get_json_object(get_json_object(log, '$.data'), '$.result'),'$.y') as y,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.tm') as tm,  " +
//	  "get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.points') as points,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.index') as index,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.lineType') as lineType,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.arriveTime') as arriveTime,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.time') as time,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.dist') as dist,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.tmcEtaTime') as tmcEtaTime,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.tmcEtaDist') as tmcEtaDist,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.qmPointTime') as qmPointTime,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.qmPointDist') as qmPointDist,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.stdId') as stdId,  " +
//	  //"get_json_object(get_json_object(get_json_object(log,'$.data'), '$.result'), '$.lineSource') as lineSource,  " +
//	  "concat(get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.taskId'),'_',  " +
//	  "   get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.srcZoneId'),'_',  " +
//	  "   get_json_object(get_json_object(get_json_object(log,'$.data'), '$.arg'), '$.destZoneId'),'_',  " +
//	  "   cast(get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.x2') as decimal(10,6)),'_',  " +
//	  "   cast(get_json_object(get_json_object(get_json_object(log, '$.data'), '$.arg'),'$.y2') as decimal(10,6))) as gp  " +
//	  "from dm_gis.gis_eta_query_log  " +
//	  "where inc_day >= '%s' and inc_day <= '%s'  " +
//	  "and get_json_object(log,'$.subType')='queryLocationEta'  " +
//	  "and get_json_object(log,'$.type')='etaQuery'  " +
//	  ") as eta  " +
//	  "left join (  " +
//	  "select  " +
//	  "uid  " +
//	  ",destZoneCoordinate  " +
//	  "from (  " +
//	  "select  " +
//	  "get_json_object(info,'$.uid') uid  " +
//	  ",get_json_object(info,'$.destZoneCoordinate') destZoneCoordinate  " +
//	  ",row_number() over (partition by get_json_object(info,'$.uid') order by get_json_object(info,'$.pickUpTm') desc) as rn  " +
//	  "from dm_gis.eta_ts_wmp_info_to_hive  " +
//	  "where inc_day >= '%s' and inc_day <= '%s'  " +
//	  "and get_json_object(info,'$.status') not in (1, 2, 3)  " +
//	  ") t  " +
//	  "where t.rn = 1  " +
//	  ") wmp on eta.reqId = wmp.uid  " +
//	  "left join(  " +
//	  "select  " +
//	  "task_area_code  " +
//	  ",task_id  " +
//	  ",sort_num  " +
//	  ",task_subid  " +
//	  ",task_inc_day  " +
//	  ",concat(task_id,'_',start_dept,'_',end_dept) as group_task  " +
//	  ",(unix_timestamp(actual_depart_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_depart_tm, 'yyyy-MM-dd HH:mm:ss')) as act_plan_depart_tm_diff  " +
//	  ",cast((unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(actual_depart_tm, 'yyyy-MM-dd HH:mm:ss'))/600 as INT) as eta_count  " +
//	  ",(unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_arrive_tm, 'yyyy-MM-dd HH:mm:ss')) as act_delay_tm  " +
//	  ",start_dept  " +
//	  ",end_dept  " +
//	  ",start_type  " +
//	  ",end_type  " +
//	  ",line_code  " +
//	  ",vehicle_serial  " +
//	  ",actual_capacity_load  " +
//	  ",plan_depart_tm  " +
//	  ",actual_depart_tm  " +
//	  ",plan_arrive_tm  " +
//	  ",actual_arrive_tm  " +
//	  ",driver_id  " +
//	  ",driver_name  " +
//	  ",line_time  " +
//	  ",line_distance  " +
//	  ",actual_run_time  " +
//	  ",start_longitude " +
//	  ",start_latitude  " +
//	  ",end_longitude  " +
//	  ",end_latitude  " +
//	  ",is_stop  " +
//	  ",transoport_level  " +
//	  ",carrier_type  " +
//	  ",vehicle_type  " +
//	  ",axls_number  " +
//	  ",log_dist  " +
//	  ",x1  " +
//	  ",y1  " +
//	  ",x2  " +
//	  ",y2  " +
//	  ",duration  " +
//	  ",time as act_time  " +
//	  //",rt_dist  " +
//	  //",highwaymileage  " +
//	  //",toll_charge  " +
//	  //",start_distance  " +
//	  //",end_distance  " +
//	  //",src  " +
//	  //",line_distance_std  " +
//	  //",line_time_std  " +
//	  //",sim1  " +
//	  //",sim5  " +
//	  //",is_navi  " +
//	  ",concat(task_id,'_',start_dept,'_',end_dept,'_',cast(end_longitude as decimal(10,6)),'_',cast(end_latitude as decimal(10,6))) as gp  " +
//	  "from dm_gis.eta_std_line_recall  " +
//	  "where inc_day >= '%s' and inc_day <= '%s'  " +
//	  "and if_evaluate_time = '1'  " +
//	  ") as recall  " +
//	  "on eta.gp = recall.gp where from_unixtime(cast(requestTime as int), 'hh') in ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12')  " +
//	  "and eta.gp is not null  " +
//		  "and recall.vehicle_serial is not null  " +
//	  "and recall.actual_depart_tm is not null  " +
//	  "and recall.actual_arrive_tm is not null  " +
//	  "and eta.points is not null " +
//	  "and (eta.tm - unix_timestamp(recall.actual_depart_tm, 'yyyy-MM-dd HH:mm:ss')) >= 0 " +
//	  "and (eta.tm - unix_timestamp(recall.actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss')) <= 0 "
//	  //"and eta.reqId in ( 1656259088366493696, 1656149329831829504, 1656066041112485888, 1655987741973319680, 1656224970558271488, 1655988147875520512, 1656166056802250752, 1656153070994305024, 1656146697425293312, 1656211208598056960, 1656077281531637760, 1655994774320181248 )" // 1655994647778029568,1656291298358980608
//	  //" limit 50000 "
//  }
//
//
//  /*
//  * log表取etime
//  * hive表取stime
//  * recall表往后推一天:stime-etime
//  * */
//  def getTrackSimSql(stime: String, etime: String) = {
//	trackInfoSql = trackInfoSql.format(stime, stime, stime, stime, stime, etime)
//	trackInfoSql
//  }
//
//  def next_day(start_day: String, step: Int, format: String): List[String] = {
//	val end_day = addDayForamt(start_day, 2, format)
//	val lst = create_days(start_day, end_day)
//	lst
//  }
//
//  //获取请求时间最近点到终点的轨迹点,eta_act_time单位为s
//  def get_point_by_time(tracks :String, eta_act_time:Long)={
//	  val vec2 = new PointVector();
//	  var pts2 = tracks.split("\\|")
//	  var lasttime:Long = 0
//	  var lastx = 0.0
//	  var lasty = 0.0
//	  var bOK = false
//	  for (pt <- pts2) {
//		var p = pt.split(",")
//		if (p.size == 3) {
//		  if(bOK == true) {
//			vec2.add(new TrackPoint(p(0).toString.toDouble, p(1).toString.toDouble))
//		  }
//		  else
//		  {
//			  val curtime = p(2).toString.toInt//时间戳s
//			  if (eta_act_time >= lasttime && eta_act_time <= curtime){
//				  bOK = true
//				  if(math.abs(eta_act_time - lasttime) < math.abs(eta_act_time - curtime)){
//					vec2.add(new TrackPoint(lastx,lasty))
//				  }
//				  vec2.add(new TrackPoint(p(0).toString.toDouble,p(1).toString.toDouble))
//			  }
//			  else {
//				lasttime = curtime
//				lastx = p(0).toString.toDouble
//				lasty = p(1).toString.toDouble
//				}
//		  }
//		}
//	  }
//	  vec2
//  }
//
//	private var trackInfoSql_detail :String  = {
//			"select  " +
//			"  eta.inc_day  " +
//			"  ,eta.gp  " +
//			"  ,recall.vehicle_serial   " +
//			"  ,recall.actual_depart_tm  " +
//			"  ,recall.actual_arrive_tm  " +
//			"  ,eta.reqId  " +
//			"  ,eta.points  " +
//			"  ,eta.dataTime  " +
//			"  ,eta.group_task  " +
//			"  ,eta.taskId  " +
//			"  ,eta.lineCode  " +
//			"  ,eta.srcZoneId  " +
//			"  ,eta.destZoneId  " +
//			"  ,eta.eta_srczonecoordinate  " +
//			"  ,eta.eta_destzonecoordinate  " +
//			"  ,eta.plate               " +
//			"  ,eta.requestTime         " +
//			"  ,eta.validTime           " +
//			"  ,eta.eta_act_point  " +
//			"  ,eta.eta_act_time   " +
//			"  from (   select  " +
//			"  inc_day,  " +
//			"  reqid,  " +
//			"  datatime,  " +
//			"  taskid,  " +
//			"  linecode,  " +
//			"  srczoneid,  " +
//			"  destzoneid,  " +
//			"  plate,  " +
//			"  requesttime,  " +
//			"  validtime,  " +
//			"  group_task,  " +
//			"  eta_srczonecoordinate,  " +
//			"  eta_destzonecoordinate,  " +
//			"  eta_act_point,  " +
//			"  eta_act_time,  " +
//			"  points,  " +
//			"  concat(group_task,'_'," +
//			"         cast(split(eta_destzonecoordinate,',')[0] as decimal(10,6)),'_',  " +
//			"         cast(split(eta_destzonecoordinate,',')[1] as decimal(10,6))) as gp  " +
//			"  from dm_gis.gis_eta_query_log_detail  " +
//			"  where inc_day >= '%s' and inc_day <= '%s'  " +
//			"  ) as eta  " +
//			"  left join(  " +
//			"  select  " +
//			"  task_area_code  " +
//			"  ,task_id  " +
//			"  ,sort_num  " +
//			"  ,task_subid  " +
//			"  ,task_inc_day  " +
//			"  ,concat(task_id,'_',start_dept,'_',end_dept) as group_task  " +
//			"  ,(unix_timestamp(actual_depart_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_depart_tm, 'yyyy-MM-dd HH:mm:ss')) as act_plan_depart_tm_diff  " +
//			"  ,cast((unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(actual_depart_tm, 'yyyy-MM-dd HH:mm:ss'))/600 as INT) as eta_count  " +
//			"  ,(unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_arrive_tm, 'yyyy-MM-dd HH:mm:ss')) as act_delay_tm  " +
//			"  ,start_dept  " +
//			"  ,end_dept  " +
//			"  ,start_type  " +
//			"  ,end_type  " +
//			"  ,line_code  " +
//			"  ,vehicle_serial  " +
//			"  ,actual_capacity_load  " +
//			"  ,plan_depart_tm  " +
//			"  ,actual_depart_tm  " +
//			"  ,plan_arrive_tm  " +
//			"  ,actual_arrive_tm  " +
//			"  ,driver_id  " +
//			"  ,driver_name  " +
//			"  ,line_time  " +
//			"  ,line_distance  " +
//			"  ,actual_run_time  " +
//			"  ,start_longitude " +
//			"  ,start_latitude  " +
//			"  ,end_longitude  " +
//			"  ,end_latitude  " +
//			"  ,is_stop  " +
//			"  ,transoport_level  " +
//			"  ,carrier_type  " +
//			"  ,vehicle_type  " +
//			"  ,axls_number  " +
//			"  ,log_dist  " +
//			"  ,x1  " +
//			"  ,y1  " +
//			"  ,x2  " +
//			"  ,y2  " +
//			"  ,duration  " +
//			"  ,time as act_time  " +
//			"  ,concat(task_id,'_',start_dept,'_',end_dept,'_',cast(end_longitude as decimal(10,6)),'_',cast(end_latitude as decimal(10,6))) as gp  " +
//			"  from dm_gis.eta_std_line_recall  " +
//			"  where inc_day >= '%s' and inc_day <= '%s'  " +
//			"  and if_evaluate_time = '1'  " +
//			"  ) as recall  " +
//			"  on eta.gp = recall.gp where from_unixtime(cast(requestTime as int), 'hh') in ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12')  " +
//			"  and eta.gp is not null  " +
//			"  and recall.vehicle_serial is not null  " +
//			"  and recall.actual_depart_tm is not null  " +
//			"  and recall.actual_arrive_tm is not null  " +
//			"  and eta.points is not null  " +
//			"  and (eta.eta_act_time - unix_timestamp(recall.actual_depart_tm, 'yyyy-MM-dd HH:mm:ss')) >= 0  " +
//			"  and (eta.eta_act_time - unix_timestamp(recall.actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss')) <= 0  "
//	}
//
//	/*
//    * log_detail中间表取etime
//    * recall表往后推一天:stime-etime
//    * */
//	def getTrackSimDetailSql(stime: String, etime: String) = {
//		trackInfoSql_detail = trackInfoSql_detail.format(stime, stime, stime, etime)
//		trackInfoSql_detail
//	}
//
//}
