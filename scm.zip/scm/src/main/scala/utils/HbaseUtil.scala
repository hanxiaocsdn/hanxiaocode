//package utils
//
//import org.apache.hadoop.hbase.client.{Delete, ResultScanner, Scan, Table}
//import org.apache.hadoop.hbase.filter.{CompareFilter, RowFilter, SubstringComparator}
//import org.apache.hadoop.hbase.util.Bytes
//import org.apache.log4j.Logger
//
//import scala.collection.mutable.ArrayBuffer
//
///**
// * Created by 01375125 on 2018/10/16.
// * hbase操作工具类
// */
//object HbaseUtil {
//
//  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getName)
//
//  /**
//   * 根据subKey模糊批量查询多行数据
//   *
//   * @param subKey
//   * @param family
//   * @param column
//   * @return
//   */
//  def scanBySubKey(table: Table, subKey: String, family: String, column: String): ArrayBuffer[String] = {
//    val resultList = new ArrayBuffer[String]()
//    //批量模糊查询
//    val filter = new RowFilter(CompareFilter.CompareOp.EQUAL, new SubstringComparator(subKey))
//    val scan = new Scan()
//    scan.setFilter(filter)
//    val rs: ResultScanner = table.getScanner(scan)
//    for (result <- rs) {
//      if (result.containsColumn(Bytes.toBytes(family), Bytes.toBytes(column))) {
//        val value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)))
//        resultList += value
//      }
//    }
//    resultList
//  }
//
//
//  /**
//   * 根据rowKey模糊删除
//   *
//   * @param table
//   * @param subKey
//   */
//  def deleteByKeys(table: Table, subKey: String): Unit = {
//    try {
//      //批量模糊删除
//      val filter = new RowFilter(CompareFilter.CompareOp.EQUAL, new SubstringComparator(subKey))
//      val scan = new Scan()
//      scan.setFilter(filter)
//      val scanners: ResultScanner = table.getScanner(scan)
//      val keyList = new ArrayBuffer[Delete]()
//      var delete: Delete = null
//      //注意：scala和java的for循环有区别，需要引入转换
//      for (scanner <- scanners) {
//        val rowKey = new String(scanner.getRow)
//        delete = new Delete(rowKey.getBytes)
//        keyList += delete
//      }
//      table.delete(keyList)
//    } catch {
//      case e: Exception => println(">>>删除操作失败：" + e)
//    }
//
//  }
//
//
//}
