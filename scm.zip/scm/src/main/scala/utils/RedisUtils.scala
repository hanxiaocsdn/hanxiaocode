package utils

import redis.clients.jedis.{HostAndPort, JedisPoolConfig, JedisSentinelPool}

import java.util

object RedisUtils {

  /**
   * 测试redis连接
   *
   * @return
   */
  def initJedisTestPool(addressId: String, master: String, passwd: String): JedisSentinelPool = {
    //测试redis
    val MAX_IDLE = 50
    val MIN_IDLE = 50
    val MAX_WAIT_MILLIS = 30000
    val masterName = master
    val TIMEOUT = 30000
    val password = passwd
    val sentinelsArr = addressId
    val sentinels = new util.HashSet[String]()
    val config = new JedisPoolConfig()

    config.setMinIdle(MAX_IDLE)
    config.setMinIdle(MIN_IDLE)
    config.setMaxWaitMillis(MAX_WAIT_MILLIS)

    for (elem <- sentinelsArr.split(",").toList)
      sentinels.add(new HostAndPort(elem.split(":")(0), elem.split(":")(1).toInt).toString())

    val pool = new JedisSentinelPool(masterName, sentinels, config, TIMEOUT, password)
    pool
  }


}
