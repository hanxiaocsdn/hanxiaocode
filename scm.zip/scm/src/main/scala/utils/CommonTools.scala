package utils

import org.apache.log4j.Logger

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}
/**
 *需求名称：常用工具包
 **/
object CommonTools {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  // 推n月
  def getmonthsBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val dateFormat2: SimpleDateFormat = new SimpleDateFormat("yyyyMM")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    dateFormat2.format(cal.getTime)
  }
  // 推n分钟,负数是往前，正数是往后
  def getminisBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val dateFormat2: SimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.MINUTE, num)
    dateFormat2.format(cal.getTime)
  }

  //往前推n天
  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

  //定义时间差计算：秒，str2比str1大,传入格式：2022-09-30 15:30:18，例如返回结果：300
  def TimeDiffSecond(str1: String, str2: String): Long = {
    var datedf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    //转换时间戳：毫秒
    val x1 = datedf.parse(str1).getTime
    val x2 = datedf.parse(str2).getTime
    //除以1000就是秒为单位
    val x3 = (x2 - x1) / 1000
    return x3
  }

  //当前时间时分秒，格式：2022-11-03 10:19:57
  def getnow():String= {
    var dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    var cal: Calendar = Calendar.getInstance()
    var day = dateFormat.format(cal.getTime())
    day
  }

  //转化为时间戳，毫秒
  def tranTimeToLong(tm:String) :Long={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val dt = fm.parse(tm)
    val aa = fm.format(dt)
    val tim: Long = dt.getTime()
    tim
  }
  //时间戳转化：输入秒
  def tranTimeToStrings(tm:String) :String={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val tim = fm.format(new Date(tm.toLong))
    tim
  }

  /**
   * 获取指定日期的前后 n 天日期
   * @param inc_day
   * @return yyyy-mm-dd
   */
  def getdaysBefore(inc_day: String, num: Int, format: String): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat(format)
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime())
  }

  /**
   * @param 根据传入的日期类型 ，进行转换成当天日期
   */
  def getCurrentDate(format: String): String = {
    var cur_Date = ""
    val date: SimpleDateFormat = new SimpleDateFormat(format)
    try {
      cur_Date = date.format(new Date())
    } catch {
      case e: Exception => logger.error("getCurrentDate execute exception, exception info: ", e)
    }
    cur_Date
  }

}
