package utils;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.datanucleus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

/**
 * ftp服务器工具类，提供从ftp服务器上传下载服务
 * @author 01370539 created on Sep.8 2021
 */
public class FtpUtil {

    private static final Logger logger = LoggerFactory.getLogger(FtpUtil.class);

    /**
     * FTPClient
     * @param host 服务器ip
     * @param port 端口
     * @param username 用户名
     * @param password 密码
     * @param charset // 编码格式，为空是默认UTF-8
     * @return FTPClient
     */
    public static FTPClient getFtpClient(String host, int port, String username, String password, String charset) {
        FTPClient ftpClient = null;
        try {
            ftpClient = new FTPClient();
            ftpClient.setControlEncoding(StringUtils.isEmpty(charset) ? "UTF-8" : charset);
            ftpClient.connect(host, port);// 连接FTP服务器
            if (FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
                if (ftpClient.login(username, password)) {
                    ftpClient.enterLocalPassiveMode();
                    ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
                    logger.error("FTP连接成功.");
                } else {
                    logger.error("FTP登录失败. username - {}, password - {}", username, password);
                    disconnect(ftpClient);
                }
            } else {
                logger.error("FTP连接失败. host - {}, port - {}", host, port);
                disconnect(ftpClient);
            }


        } catch (Exception e) {
            e.printStackTrace();
            logger.error("FTP的IP地址可能错误，请正确配置。");
        }
        return ftpClient;
    }

    /**
     * 断开与服务器的连接
     * @throws IOException
     */
    public static void disconnect(FTPClient ftpClient) throws IOException {
        if (ftpClient.isConnected()) {
            ftpClient.disconnect();
            logger.error("ftp is disconnect!");
        }
    }

    /**
     * 删除FTP文件目录或包括文件
     * @param ftpClient FTPClient
     * @param ftpDir 要删除的目录或文件
     */
    public static void delete(FTPClient ftpClient, String ftpDir) {
        try {
            FTPFile[] ftpFiles = ftpClient.listFiles(ftpDir);
            boolean result;
            if (ftpFiles != null && ftpFiles.length > 0) {
                if (ftpDir.indexOf(".") > 0) {
                    result = ftpClient.deleteFile(ftpDir);
                    logger.error("remove file: {}, {}", ftpDir, result ? "删除成功！" : "删除失败！");
                } else {
                    for (FTPFile ftpFile : ftpFiles) {
                        delete(ftpClient, ftpDir, ftpFile);
                    }
                    result = ftpClient.removeDirectory(ftpDir);
                    logger.error("remove directory: {}, {}", ftpDir, result ? "删除成功！" : "删除失败！");
                }
            } else {
                String parentDir = ftpDir.substring(0, ftpDir.lastIndexOf("/"));
                ftpFiles = ftpClient.listFiles(parentDir);
                if (ftpFiles != null && ftpFiles.length > 0) {
                    boolean isExist = false;
                    for (FTPFile ftpFile : ftpFiles) {
                        if (ftpDir.equals(parentDir + "/" + ftpFile.getName())) {
                            isExist = true;
                            break;
                        }
                    }
                    if (isExist) {
                        result = ftpClient.removeDirectory(ftpDir);
                        logger.error("remove directory: {}, {}", ftpDir, result ? "删除成功！" : "删除失败！");
                    } else {
                        logger.error("{} 不存在，不可删除！", ftpDir);
                    }
                } else {
                    logger.error("{} 不存在，不可删除！", ftpDir);
                }
            }
        } catch (Exception e) {
            logger.error("FTP文件删除失败：{}", e);
        }
    }

    /**
     * 删除文件
     * @param ftpClient FTPClient
     * @param ftpDir 要删除的文件所在目录
     * @param ftpFile 要删除的文件内容
     * @throws IOException IOException
     */
    private static void delete(FTPClient ftpClient, String ftpDir, FTPFile ftpFile) throws IOException {
        ftpDir = ftpDir + "/" + ftpFile.getName();
        if (ftpFile.isDirectory()) {
            FTPFile[] subFiles = ftpClient.listFiles(ftpDir);
            logger.error("process directory: {}, sub count: {}", ftpDir, subFiles.length);
            for (FTPFile subFile : subFiles) {
                delete(ftpClient, ftpDir, subFile);
            }
            logger.error("remove directory: {}, {}", ftpDir, ftpClient.removeDirectory(ftpDir) ? "删除成功！" : "删除失败！");
        } else {
            logger.error("remove file: {}, {}", ftpDir, ftpClient.deleteFile(ftpDir) ? "删除成功！" : "删除失败！");
        }
    }

    /**
     * 文件同步到ftp上，如果路径为文件目录，则把目录下的所有文件都上传的ftp
     * @param ftpClient FTPClient
     * @param localDir 本地文件目录
     * @param ftpDir ftp目录
     * @throws Exception Exception
     */
    public static void upload(FTPClient ftpClient, String localDir, String ftpDir) {
        try {
            if (!ftpClient.isConnected()) {
                logger.error("远程服务器连接丢失！");
            }
            // 更改FTP会话的当前工作目录，如果更改不成功，则进行目录的创建
            if (!ftpClient.changeWorkingDirectory(ftpDir)) {
                if (!createMultiDirectory(ftpClient, ftpDir)) {
                    logger.error("ftp文件夹创建失败!");
                }
            }

            File localFile = new File(localDir);
            if(!localFile.exists()){
                logger.error("本地文件不存在！");
            } else {
                upload(ftpClient, localFile);
            }
        } catch (Exception e) {
            logger.error("upload execute error. e - {}", e);
        }
    }

    /**
     * 上传文件
     * @param ftpClient FTPClient
     * @param localFile 待上传的文件
     */
    private static void upload(FTPClient ftpClient, File localFile) {
        try {
            if (localFile.isDirectory()) {
                logger.error("upload directory: {}", localFile.getName());
                ftpClient.makeDirectory(localFile.getName());
                ftpClient.changeWorkingDirectory(localFile.getName());
                File[] subList = localFile.listFiles();
                for (File subFile : subList) {
                    upload(ftpClient, subFile);
                }
                ftpClient.changeWorkingDirectory(ftpClient.printWorkingDirectory().substring(0, ftpClient.printWorkingDirectory().lastIndexOf("/")));
            } else {
                logger.error("upload file : {}", localFile.getName());
                InputStream in = new FileInputStream(localFile);
                ftpClient.storeFile(localFile.getName(), in);
                in.close();
            }
        } catch(Exception e) {
            logger.error("文件上传失败： {}", e);
        }
    }

    public static void download(FTPClient ftpClient, String localDir, String ftpDir) {
        try {
            File localFile = new File(localDir);
            if (localFile.exists() && localFile.isDirectory()) {
                FTPFile[] ftpFiles = ftpClient.listFiles(ftpDir);
                boolean result;
                if (ftpFiles != null && ftpFiles.length > 0) {
                    localDir = localDir + "/" + ftpDir.substring(ftpDir.lastIndexOf("/") + 1);
                    if (ftpDir.indexOf(".") > 0) {
                        OutputStream os = new FileOutputStream(localDir);
                        result = ftpClient.retrieveFile(ftpDir, os);
                        os.close();
                        logger.error("download file: {}, {}", ftpDir, result ? "下载成功！" : "下载失败！");
                    } else {
                        localFile = new File(localDir);
                        if (!localFile.exists()) {
                            logger.error("创建目录： {} {}", localDir, localFile.mkdirs() ? "成功！" : "失败！");
                        }
                        for (FTPFile ftpFile : ftpFiles) {
                            download(ftpClient, localDir, ftpDir, ftpFile);
                        }
                    }
                } else {
                    String parentFtpDir = ftpDir.substring(0, ftpDir.lastIndexOf("/"));
                    ftpFiles = ftpClient.listFiles(parentFtpDir);
                    if (ftpFiles != null && ftpFiles.length > 0) {
                        boolean isExist = false;
                        for (FTPFile ftpFile : ftpFiles) {
                            if (ftpDir.equals(parentFtpDir + "/" + ftpFile.getName())) {
                                isExist = true;
                                localDir = localDir + "/" + ftpFile.getName();
                                break;
                            }
                        }
                        if (isExist) {
                            localFile = new File(localDir);
                            if (!localFile.exists()) {
                                logger.error("创建目录： {} {}", localDir, localFile.mkdirs() ? "成功！" : "失败！");
                            }
                        } else {
                            logger.error("{} 不存在，不可下载！", ftpDir);
                        }
                    } else {
                        logger.error("{} 不存在，不可下载！", ftpDir);
                    }
                }
            } else {
                logger.error("{} 不存在！", localDir);
            }
        } catch (Exception e) {

        }
    }

    private static void download(FTPClient ftpClient, String localDir, String ftpDir, FTPFile ftpFile) {
        try {
            localDir = localDir + "/" + ftpFile.getName();
            ftpDir = ftpDir + "/" + ftpFile.getName();
            if (ftpFile.isDirectory()) {
                File localFile = new File(localDir);
                if (!localFile.exists()) {
                    logger.error("创建目录： {} {}", localDir, localFile.mkdirs() ? "成功！" : "失败！");
                }
                FTPFile[] subFiles = ftpClient.listFiles(ftpDir);
                for(FTPFile subFile : subFiles) {
                    download(ftpClient, localDir, ftpDir, subFile);
                }
            } else {
                OutputStream os = new FileOutputStream(localDir);
                logger.error("download file: {}, {}", ftpDir, ftpClient.retrieveFile(ftpDir, os) ? "下载成功！" : "下载失败！");
                os.close();
            }
        } catch (Exception e) {
            logger.error("下载文件失败。e - {}", e);
        }
    }

    /**
     * 创建文件目录，
     * @param ftpClient FTPClient
     * @param ftpDir 要创建的ftp路径
     * @return // 创建目录成功，返回true，创建目录失败，返回false
     */
    public static boolean createMultiDirectory(FTPClient ftpClient, String ftpDir) {
        boolean result;
        try {
            ftpClient.changeWorkingDirectory("/");   // 进入ftp根目录
            String[] dirs = ftpDir.split("/");   // 对路径分层进行拆分

            // 如果ftp路径以'/'开始，则从'/'后的文件目录开始创建
            int curFileIndex = 0;
            if (ftpDir.indexOf("/") == 0) {
                curFileIndex = 1;
            }

            //按顺序检查目录是否存在，不存在则创建目录
            for (int i = curFileIndex; i < dirs.length; i++) {
                if(!ftpClient.changeWorkingDirectory(dirs[i])) {
                    ftpClient.makeDirectory(dirs[i]);
                    ftpClient.changeWorkingDirectory(dirs[i]);
                }
            }
            result = true;
        } catch (Exception e) {
            logger.error("创建目录失败： {}", e);
            result =false;
        }
        return result;
    }

    public static void main(String[] args) {
        FTPClient ftpClient = getFtpClient("10.116.49.190", 21, "gis", "L1iwM21xYF", null);
    }


//
//    public  void  megerHdfsPathToLocalFile(String hdfsPath,String localFile,
//                                           boolean deleteSource, boolean overwrite, String heads) throws Exception {
//        File dstPath = new File(localFile);
//        if (dstPath.exists()) {
//            if (dstPath.isFile()) {
//                if (overwrite) {
//                    Files.delete(dstPath.toPath());
//                }
//            } else {
//                logger.error("destination file must be a file");
//            }
//        }
//
//        FileStatus[] stats=listFileStatus(hdfsPath);
//        File dstFile  = new File(localFile);
//
//        FileOutputStream fileOutputStream  =   new FileOutputStream(dstFile);
//
//
//        if(!StringUtils.isEmpty(heads)){
//            fileOutputStream.write((heads + "\r\n").getBytes());
//        }
//
//        for (int i=0; i<stats.length; i++){
//            //打印每个文件路径
//            logger.info(stats[i].getPath().toString());
//            //读取每个文件
//            InputStream in = fs.open(stats[i].getPath());
//
//            org.apache.hadoop.io.IOUtils.copyBytes(in, fileOutputStream, fs.getConf(),false);
//            in.close();
//        }
//
//        if (deleteSource) {
//            fs.delete(new Path(hdfsPath), true);
//        }
//
//        fileOutputStream.close();
//    }
//

}
