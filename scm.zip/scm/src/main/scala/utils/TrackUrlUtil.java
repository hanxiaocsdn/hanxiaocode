package utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.datanucleus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Set;

public class TrackUrlUtil {
    public static final Logger logger = LoggerFactory.getLogger(TrackUrlUtil.class);
    private static PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    private static CloseableHttpClient httpClient = null;
    private static boolean isInitConnection = false;

    static {
        initConnectionManager();
    }

    public static void initConnectionManager() {
        try {
            connManager.setMaxTotal(5); // 设置整个连接池最大连接数 根据自己的场景决定
            // 是路由的默认最大连接（该值默认为2），限制数量实际使用DefaultMaxPerRoute并非MaxTotal。设置过小无法支持大并发(ConnectionPoolTimeoutException: Timeout waiting for connection from pool)，路由是对maxTotal的细分。
            connManager.setDefaultMaxPerRoute(5);// （目前只有一个路由，因此让他等于最大值）
            SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setSoTimeout(120000).setTcpNoDelay(true).build();
            connManager.setDefaultSocketConfig(socketConfig);

            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(120000).setConnectTimeout(120000).setSocketTimeout(120000).build();
            httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setConnectionManager(connManager).build();
        } catch (Exception e) {
            logger.error("initConnectionManager error. ", e);
        }
    }

    public static String sendGet(String req, String charset, int maxTryTime) {
        String content = sendGet(req, charset);
        int tryTime = 0;
        while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            logger.error("try time {}: {}", maxTryTime, req);
            content = sendGet(req, charset);
        }
        return content;
    }

    public static String sendPost(String req, String param, int maxTryTime) {
        String content = sendPost(req, param);
        int tryTime = 0;
        while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            logger.error("try time {}: {}", maxTryTime, req);
            content = sendPost(req, param);
        }
        return content;
    }

    public static String sendGet(String req, String charset) {
        BufferedReader in = null;
        StringBuilder sb = new StringBuilder();
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(req);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setConnectTimeout(3000);
            urlConnection.setReadTimeout(3000);
            urlConnection.connect();
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream(), charset));
            String line;
            while ((line = in.readLine()) != null) {
                sb.append(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
        return sb.toString();
    }

    public static String sendPost(String url, String param) {
        String jsonStr = null;
        CloseableHttpResponse response = null;
        HttpPost post = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }

            post = new HttpPost(url);
            post.setHeader("Content-Type", "application/json");
            post.setHeader("Connection", "Keep-Alive");
            HttpEntity re = new StringEntity(param, "UTF-8");
            post.setEntity(re);

            response = httpClient.execute(post);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, "utf-8");
        } catch (Exception e) {
            logger.error("resonse - {}", response);
            logger.error("readContentFromPost err. ", e);
        } finally {
            try {
                if (jsonStr != null) {
                    if (post != null) {
                        EntityUtils.consume(entity);
                        post.releaseConnection();
                    }
                    if (response != null) {
                        response.close();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return jsonStr;
    }

    public static String runGet(String req, Set<Integer> acLimitCodeSet) {
        String content = "";
        try {
            content = sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (StringUtils.isEmpty(content)) {
                return content;
            }
            while (isAcTime(JSON.parseObject(content), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            }
        } catch (Exception e) {
            logger.error("request error. url:{}", req);
            e.printStackTrace();
        }
        return content;
    }

    public static String runPost(String req, String param, Set<Integer> acLimitCodeSet) {
        String content = "";
        try {
            content = sendPost(req, param, FixedConstant.MAX_TRY_TIME_THREE);
            if (StringUtils.isEmpty(content)) {
                return content;
            }
            logger.error("content:{}", content);
            while (isAcTime(JSON.parseObject(content), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = sendPost(req, param, FixedConstant.MAX_TRY_TIME_THREE);
            }
        } catch (Exception e) {
            logger.error("post error. url:{}", req);
            e.printStackTrace();
        }
        return content;
    }

    public static boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    /**
     * 进行get请求
     *
     * @param url        请求路径
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    public static JSONObject httpGetJSON(String url, int maxTryTime) {
        int count = maxTryTime;
        JSONObject ret;
        while (count-- > 0) {
            HttpGet httpGet = new HttpGet(url);
            try (CloseableHttpClient httpClient = HttpClients.custom().build();
                 CloseableHttpResponse response = httpClient.execute(httpGet)) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    ret = JSON.parseObject(result);
                    return ret;
                }
            } catch (Exception e) {
                sleep(count, url, e);
            } finally {
                httpGet.releaseConnection();
            }
        }
        return null;
    }
    private static void sleep(int count, String url, Exception e) {
        try {
            if (count == 0) {
                logger.error(url + "," + e.getMessage());
            } else if (count == 1) {
                Thread.sleep(500);
            } else if (count == 2) {
                Thread.sleep(250);
            } else if (count == 3) {
                Thread.sleep(125);
            }
        } catch (InterruptedException e1) {
        }
    }


}