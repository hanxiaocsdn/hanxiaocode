package utils;

import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpHost;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.Args;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;


public class HttpConnectionManager extends PoolingHttpClientConnectionManager {


    private static int maxTotalPool = 200;
    private static int maxConPerRoute = 20;
    private static int socketTimeout = 60000;
    private static final SocketConfig defaultSocketConfig = SocketConfig.custom().setTcpNoDelay(true)
            .setSoTimeout(socketTimeout).build();
    private static int connectTimeout = 5000;
    private static final RequestConfig defaultRequestConfig = RequestConfig.custom()
    		.setConnectTimeout(connectTimeout)
            .setSocketTimeout(socketTimeout).build();
    private static HttpRequestRetryHandler myRetryHandler = null;
    private static CloseableHttpClient httpClient = null;
    private static Registry<ConnectionSocketFactory> socketFactoryRegistry = null;
    private static IdleConnectionMonitorThread idleThread = null;

    static {
        SSLContext sslcontext = null;
        try {
            sslcontext = SSLContexts.custom().loadTrustMaterial(null, new TrustSelfSignedStrategy()).build();
        } catch (Exception e) {
//            logger.error(e);
        }
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext,
                new String[]{"SSLv2Hello", "SSLv3", "TLSv1", "TLSv1.2"}, null, NoopHostnameVerifier.INSTANCE);
        socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
                .register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", sslsf).build();
    }

    public HttpConnectionManager(final Registry<ConnectionSocketFactory> socketFactoryRegistry) {
        super(socketFactoryRegistry, null, null);
    }

    private static void config() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {

        try {
            myRetryHandler = new HttpRequestRetryHandler() {

                public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {
                    if (executionCount >= 3) {
                        // Do not retry if over max retry count
                        return false;
                    }
                    // if (exception instanceof UnknownHostException ||
                    // exception instanceof ConnectTimeoutException
                    // || !(exception instanceof SSLException) || exception
                    // instanceof NoHttpResponseException) {
                    // return true;
                    // }

                    if (exception instanceof NoHttpResponseException) {// 如果服务器丢掉了连接，那么就重试
                        return true;
                    }
                    if (exception instanceof SSLHandshakeException) {// 不要重试SSL握手异常
                        return false;
                    }
                    if (exception instanceof InterruptedIOException) {// 超时
                        return false;
                    }
                    if (exception instanceof UnknownHostException) {// 目标服务器不可达
                        return false;
                    }
                    if (exception instanceof ConnectTimeoutException) {// 连接被拒绝
                        return false;
                    }
                    if (exception instanceof SSLException) {// SSL握手异常
                        return false;
                    }
                    HttpClientContext clientContext = HttpClientContext.adapt(context);
                    org.apache.http.HttpRequest  request = clientContext.getRequest();
                    boolean idempotent = !(request instanceof HttpEntityEnclosingRequest);
                    if (idempotent) {
                        // Retry if the request is considered idempotent
                        return true;
                    }
                    return false;
                }

            };
            // 将最大连接数增加到200
            ConnetcionHolder.instance.setMaxTotal(maxTotalPool);
            // 将每个路由基础的连接增加到20
            ConnetcionHolder.instance.setDefaultMaxPerRoute(maxConPerRoute);

//            idleThread = new IdleConnectionMonitorThread();
//            idleThread.start();

            HttpClientBuilder httpClientBuilder = HttpClients.custom().setRetryHandler(myRetryHandler)
                    .setConnectionManager(ConnetcionHolder.instance).setDefaultRequestConfig(defaultRequestConfig)
                    .setDefaultSocketConfig(defaultSocketConfig);// set

            httpClient = httpClientBuilder.build();
        } catch (Exception e) {
//            logger.error("InterfacePhpUtilManager init Exception" + e.toString());
        }
    }

    public static HttpConnectionManager getManager() {
        return ConnetcionHolder.instance;
    }

    public void closeMgr() throws IOException {
        httpClient.close();
        this.shutdown();
        idleThread.interrupt();
    }

    private void closeLeasedConnection(final long idletime, final TimeUnit tunit) {

        Args.notNull(tunit, "Time unit");
        long time = tunit.toMillis(idletime);
        if (time < 0) {
            time = 0;
        }
        final long deadline = System.currentTimeMillis() - time;
//        this.enumLeased(entry -> {
//            if (entry.getUpdated() <= deadline) {
////                    logger.info(entry.toString() + ", deadline : " + deadline + ", Updated: " + entry.getUpdated());
//                entry.close();
//            }
//        });
    }

    public HttpGet getHttpGetByProxy(String proxyIp, int proxPort, String url) {
        HttpGet httpGet = new HttpGet(url);

        RequestConfig requestConfig = RequestConfig.copy(defaultRequestConfig).setProxy(new HttpHost(proxyIp, proxPort))
                .build();
        httpGet.setConfig(requestConfig);
        // proxy
        if (this != null && this.getTotalStats() != null) {
//            logger.info("now client pool " + this.getTotalStats().toString());
        }

        return httpGet;
    }

    public HttpGet getHttpGet(String url) {
        HttpGet httpGet = new HttpGet(url);

        // proxy
        if (this != null && this.getTotalStats() != null) {
//            logger.info("now client pool " + this.getTotalStats().toString());
        }
        return httpGet;
    }

    public CloseableHttpClient getHttpClient() {
        return httpClient;
    }

    static class ConnetcionHolder {
        private static HttpConnectionManager instance = new HttpConnectionManager(socketFactoryRegistry);

        static {
            try {
                config();
            } catch (Exception e) {
//                logger.error(e);
            }
        }
    }

    static class IdleConnectionMonitorThread extends Thread {

        @Override
        public void run() {
            try {
                while (true) {
                    sleep(5000);
                    getManager().closeExpiredConnections();
                    getManager().closeLeasedConnection(5, TimeUnit.SECONDS);
                    getManager().closeIdleConnections(30, TimeUnit.SECONDS);
//                    if (activeHttpThreads.get() == 0) {
//                        getManager().closeMgr();
//                        break;
//                    }

                }
            } catch (Exception ex) {
//                logger.error(ex);
            }
        }

    }
}
