package utils

import org.apache.commons.net.ftp.{FTPClient, FTPReply}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FSDataOutputStream, FileSystem, Path}
import org.apache.hadoop.io.IOUtils
import org.apache.log4j.Logger

import java.io.InputStream

/**
 * @task_id:
 * @description:
 * @demander:
 * @author 01418539 caojia
 * @date 2023/3/13 10:04
 */
object FTPCopyFileUtils {


  @transient lazy val logger: Logger = Logger.getLogger(FTPCopyFileUtils.getClass)


  def main(args: Array[String]): Unit = {
    val sourcePath = args(0)
    val destinationPath = args(1)
    downLoad(sourcePath, destinationPath)
  }

  def downLoad(sourcePath: String, destinationPath: String): Unit = {
    val conf = new Configuration()
    val ftp = FtpUtil.getFtpClient("10.116.49.190", 21, "gis", "L1iwM21xYF", "")
    downloadFromFtpToHdfsHierarchy(ftp, sourcePath, destinationPath, conf)
  }


  /**
   * 将 ftp 上的文件拉取到 hdfs 上
   *
   * @param ftpClient
   * @param ftpPath
   * @param hdfsPath
   * @param fileName
   * @param conf
   * @return
   */
  def downloadFromFtpToHdfsHierarchy(ftpClient: FTPClient, ftpPath: String, hdfsPath: String, conf: Configuration): Boolean = {
    var inputStream: InputStream = null
    var outputStream: FSDataOutputStream = null
    var flag = true
    try {
      val reply = ftpClient.getReplyCode
      if (!FTPReply.isPositiveCompletion(reply)) ftpClient.disconnect

      val files = ftpClient.listFiles(ftpPath)
      val hdfsFile: FileSystem = FileSystem.get(conf)
      var i: Int = 1
      for (file <- files) {
        inputStream = ftpClient.retrieveFileStream(ftpPath + file.getName)
        outputStream = hdfsFile.create(new Path(hdfsPath + file.getName))
        IOUtils.copyBytes(inputStream, outputStream, conf, false)
        if (inputStream != null) {
          inputStream.close();
          ftpClient.completePendingCommand()
        }
        logger.error("上传第" + i)
        i += 1
        //        }
      }
      ftpClient.disconnect()
    } catch {
      case e: Exception => flag = false
        e.printStackTrace()
    }
    if (flag) logger.error("FTP上的文件,已成功拉取到hdfs上！")
    flag
  }


  /**
   * 将 ftp 上的文件拉取到 hdfs 上
   *
   * @param ftpClient
   * @param ftpPath
   * @param hdfsPath
   * @param fileName
   * @param conf
   * @return
   */
  def downloadFromHdfsToFtpHierarchy(ftpClient: FTPClient, ftpPath: String, hdfsPath: String, conf: Configuration): Boolean = {
    var inputStream: InputStream = null
    var outputStream: FSDataOutputStream = null
    var flag = true
    try {
      val reply = ftpClient.getReplyCode
      if (!FTPReply.isPositiveCompletion(reply)) ftpClient.disconnect

      val files = ftpClient.listFiles(ftpPath)


      val hdfsFile: FileSystem = FileSystem.get(conf)


      var i: Int = 1
      for (file <- files) {
        inputStream = ftpClient.retrieveFileStream(ftpPath + file.getName)
        outputStream = hdfsFile.create(new Path(hdfsPath + file.getName))
        IOUtils.copyBytes(inputStream, outputStream, conf, false)
        if (inputStream != null) {
          inputStream.close();
          ftpClient.completePendingCommand()
        }
        logger.error("上传第" + i)
        i += 1
        //        }
      }
      ftpClient.disconnect()
    } catch {
      case e: Exception => flag = false
        e.printStackTrace()
    }
    if (flag) logger.error("FTP上的文件,已成功拉取到hdfs上！")
    flag
  }

  //
  //  def megerHdfsPathToLocalFile(hdfsPath: String, localFile: String, deleteSource: Boolean, overwrite: Boolean, heads: String): Unit = {
  //
  //    val hdfsFile: FileSystem = FileSystem.get(conf)
  //
  //
  //    val dstPath = new File(localFile)
  //    if (dstPath.exists) if (dstPath.isFile) if (overwrite) Files.delete(dstPath.toPath)
  //    else logger.error("destination file must be a file")
  //    val stats = listFileStatus(hdfsPath)
  //    val dstFile = new File(localFile)
  //    val fileOutputStream = new FileOutputStream(dstFile)
  //    if (!StringUtils.isEmpty(heads)) fileOutputStream.write((heads + "\r\n").getBytes)
  //    var i = 0
  //    while ( {
  //      i < stats.length
  //    }) { //打印每个文件路径
  //      logger.info(stats(i).getPath.toString)
  //      //读取每个文件
  //      val in = fs.open(stats(i).getPath)
  //      org.apache.hadoop.io.IOUtils.copyBytes(in, fileOutputStream, fs.getConf, false)
  //      in.close()
  //
  //      {
  //        i += 1; i - 1
  //      }
  //    }
  //    if (deleteSource) fs.delete(new Path(hdfsPath), true)
  //    fileOutputStream.close()
  //  }

}
