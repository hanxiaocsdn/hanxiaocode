package utils

import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.{Calendar, Date}

/**
**author:01390943
**description:自己定义日期、时间类型的方法
**/

object TimeDef {

  // 推n分钟,负数是往前，正数是往后t1和t2格式：2023-02-16 13:07:02
  def getminisdif(t1: String,t2: String): Long = {
    val l1 = LocalDateTime.parse(t1,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    val l2 = LocalDateTime.parse(t2,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    val l3 = l1.minusSeconds(l1.getSecond)
    val l4 = l2.minusSeconds(l2.getSecond)
    ChronoUnit.MINUTES.between(l4,l3)
  }

  // 推n分钟,负数是往前，正数是往后
  def getminisBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val dateFormat2: SimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.MINUTE, num)
    dateFormat2.format(cal.getTime)
  }

  // 推n小时,负数是往前，正数是往后
  def gethourBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.HOUR, num)
    dateFormat.format(cal.getTime)
  }

  // 推n分钟,负数是往前，正数是往后，推算天
  def getminisday(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val dateFormat2: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat2.format(cal.getTime)
  }

  //往前推n天
  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

  //往前推n天
  def getdaysBeforeOrAftera(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

  // 推n月
  def getmonthsBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val dateFormat2: SimpleDateFormat = new SimpleDateFormat("yyyyMM")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    dateFormat2.format(cal.getTime)
  }

  //定义时间差计算：秒，str2比str1大,传入格式：2022-09-30 15:30:18，例如返回结果：300
  def TimeDiffSecond(str1: String, str2: String): Long = {
    var datedf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    //转换时间戳：毫秒
    val x1 = datedf.parse(str1).getTime
    val x2 = datedf.parse(str2).getTime
    //除以1000就是秒为单位
    val x3 = (x2 - x1) / 1000
    return x3
  }

  //计算最近x天的日期，例如：20221008执行x=2，结果就是20221006,执行x=-2结果就是20221010
  def getday(x:Int):String= {
    var dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    var cal: Calendar = Calendar.getInstance()
    cal.add(Calendar.DATE, -1*x)
    var day = dateFormat.format(cal.getTime())
    day
  }

  //计算最近x天的日期，例如：2022-10-08执行x=2，结果就是2022-10-06,执行x=-2结果就是2022-10-10
  def getdaya(x:Int):String= {
    var dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
    var cal: Calendar = Calendar.getInstance()
    cal.add(Calendar.DATE, -1*x)
    var day = dateFormat.format(cal.getTime())
    day
  }


  //当前时间时分秒，格式：2022-11-03 10:19:57
  def getnow():String= {
    var dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    var cal: Calendar = Calendar.getInstance()
    var day = dateFormat.format(cal.getTime())
    day
  }

  //当前时间时分，格式：202211031019
  def getnow_minit():String= {
    var dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm")
    var cal: Calendar = Calendar.getInstance()
    var day = dateFormat.format(cal.getTime())
    day
  }

  //转化为时间戳，毫秒
  def tranTimeToLong(tm:String) :Long={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val dt = fm.parse(tm)
    val aa = fm.format(dt)
    val tim: Long = dt.getTime()
    tim
  }

  //定义日期格式转换
  def turnday(inputday:String):String= {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val dateFormat2: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inputday)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, 0)
    dateFormat2.format(cal.getTime)
  }

  //时间戳转化
  def tranTimeToString(tm:String) :String={
    val fm = new SimpleDateFormat("yyyyMMddHHmmss")
    val tim = fm.format(new Date(tm.toLong))
    tim
  }

  //时间戳转化：输入秒
  def tranTimeToStrings(tm:String) :String={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val tim = fm.format(new Date(tm.toLong))
    tim
  }
  //时间戳转化：输入毫秒
  def tranTimeToStringhm(tm:String) :String={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val tim = fm.format(new Date(tm.toLong))
    tim
  }


}
