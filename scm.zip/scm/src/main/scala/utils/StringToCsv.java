package utils;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/6/1
*/


import java.io.*;


public class StringToCsv {


    public static void stringToCsv(String fileName,String path,String context) throws FileNotFoundException, UnsupportedEncodingException {

        File file = new File("..", "/file/TestFile.txt");
//        input = new FileInputStream(file);

        PrintWriter pw = new PrintWriter(new File(fileName));

        pw.write(context);

        pw.close();

        System.out.println("done!");


    }



}
