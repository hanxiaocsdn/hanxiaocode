package utils

import com.google.common.base.Charsets
import com.google.common.hash.Hashing
import org.apache.log4j.Logger
import org.apache.spark.sql.Column
import org.apache.spark.sql.functions.{trim, udf}

import java.text.SimpleDateFormat
import java.util.regex.Pattern
import java.util.{Calendar, Date}
import scala.collection.mutable.ListBuffer

/**
 * @author 01418539 caojia
 * @date 2022年02月16日 19:18
 */
object ColumnUtil {
  @transient lazy val logger: Logger = Logger.getLogger(ColumnUtil.getClass)

  /**
   * 对列字段正则匹配
   *
   * @param col字段
   * @return boolean类型
   */
  def regexpMatch(matchCond: String) = udf((colName: String) => {
    val pattern: Pattern = Pattern.compile(matchCond)
    var flag = false
    try {
      if (!colName.isEmpty && colName != null && colName.trim != "") {
        flag = pattern.matcher(colName).matches()
      }
    } catch {
      case e: Exception => logger.error("异常：" + e.getMessage)
    }
    flag
  })


  /**
   * 对给定的字符串 进行空值判断
   *
   * @param col列字段
   * @return 列类型
   */
  def strNotNull(str: String): Boolean = {
    !str.isEmpty && str.trim != ""
  }

  /**
   * 对给定的列进行空值判断
   * 目前仅适用于 GetAccidentDetectionApp 类中使用
   *
   * @param col列字段
   * @return 列类型
   */
  def colNotNull(col: Column): Column = {
    col.isNotNull && trim(col) =!= "" && col > 0
  }

  /**
   * 计算经纬度点之间的距离，单位：米
   *
   * @return 距离值：单位米
   */
  def lngLatToDistance(longitude1: String, latitude1: String, longitude2: String, latitude2: String): Double = {
    val EARTH_RADIUS = 6378137
    var distance = 0.00 //返回单位: 米
    try { // 纬度
      if (longitude1 != null && longitude1.trim != "" && latitude1 != null && latitude1.trim != "" && longitude2 != null && longitude2.trim != "" && latitude2 != null && latitude2.trim != "") {
        val lat1 = Math.toRadians(latitude1.toDouble)
        val lat2 = Math.toRadians(latitude2.toDouble)
        // 经度
        val lng1 = Math.toRadians(longitude1.toDouble)
        val lng2 = Math.toRadians(longitude2.toDouble)
        // 纬度之差
        val a = lat1 - lat2
        // 经度之差
        val b = lng1 - lng2
        // 计算两点距离的公式
        val s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(b / 2), 2)))
        // 弧长乘地球半径, 返回单位: 米
        distance = s * EARTH_RADIUS
      }
    } catch {
      case e: Exception => logger.error("经纬度为null 或者为 空串'>>>>>>>" + e.printStackTrace())
        distance = 0.00
    }
    distance
  }

  /**
   * 计算经纬度点之间的距离，单位：米
   *
   * @return 距离值：单位米
   */
  def lngLatToDistance = udf((longitude1: String, latitude1: String, longitude2: String, latitude2: String) => {
    val EARTH_RADIUS = 6378137
    var distance = 0.00 //返回单位: 米
    try { // 纬度
      if (longitude1 != null && longitude1.trim != "" && latitude1 != null && latitude1.trim != "" && longitude2 != null && longitude2.trim != "" && latitude2 != null && latitude2.trim != "") {
        val lat1 = Math.toRadians(latitude1.toDouble)
        val lat2 = Math.toRadians(latitude2.toDouble)
        // 经度
        val lng1 = Math.toRadians(longitude1.toDouble)
        val lng2 = Math.toRadians(longitude2.toDouble)
        // 纬度之差
        val a = lat1 - lat2
        // 经度之差
        val b = lng1 - lng2
        // 计算两点距离的公式
        val s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(b / 2), 2)))
        // 弧长乘地球半径, 返回单位: 米
        distance = s * EARTH_RADIUS
      }
    } catch {
      case e: Exception => logger.error("经纬度为null 或者为 空串'>>>>>>>" + e.printStackTrace())
        distance = 0.00
    }
    distance
  })

  /**
   * @param 字符串类型的 日期 ‘2022-02-10’ 返回：4（星期四）
   * @return 返回对应当天星期日 一 二 三 四 五 六
   */
  def colGetWeek = udf((date: String) => {
    val date_new = date.replaceAll("-", "")
    val sdf = new SimpleDateFormat("yyyyMMdd")
    var inputDate: Date = sdf.parse(date_new)
    val weeks = Array("7", "1", "2", "3", "4", "5", "6")
    val cal = Calendar.getInstance()
    cal.setTime(inputDate)
    var week_index = cal.get(Calendar.DAY_OF_WEEK) - 1
    if (week_index < 0) {
      week_index = 0
    }
    weeks(week_index)
  })

  /**
   * 唯一主键
   *
   * @return
   */
  def primaryKeyEncrypt = udf((col1: String, col2: String, col3: String, col4: String, col5: String, col6: String, col7: String) => {
    val inputStr = col1 + col2 + col3 + col4 + col5 + col6 + col7
    Hashing.md5().newHasher().putString(inputStr, Charsets.UTF_8).hash().toString()
  })


  /**
   * 对指定字段集  重命名
   *
   * @param initCols ：需要重命名的字段
   * @param newNames ： 重命名的 String 集合
   * @return 返回重命名字段的完整描述： Seq( col("") alias "" )
   */
  def renameColumn(initCols: Seq[Column], newNames: Seq[String]): Seq[Column] = {
    initCols zip newNames map (x => x._1.alias(x._2))
  }

  def strHandle(str: String, sep: String, flag: Boolean = true): Array[String] = {
    var res: Array[String] = Array()
    try {
      if (flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep)
      //是否需要排序
      if (!flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep).sortWith(_.compareTo(_) < 0)
    } catch {
      case e: NullPointerException => logger.error("原始数据为空" + e.getMessage)
      case e: ArrayIndexOutOfBoundsException => logger.error("指标越界" + e.getMessage)
    }
    res
  }

  //对返回的5类数据切分
  def splitFun(sep: String) = udf((ds_tl_infos: String) => {
    var res: Array[String] = Array()
    try {
      if (strNotNull(ds_tl_infos)) {
        res = strHandle(ds_tl_infos, sep)
      }
    } catch {
      case e: Exception => logger.error("101 检查返回的结果值", e)
    }
    res
  })

  def sortField = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("\\|")
      val other_arr = other.split("\\|")
      val new_arr = num_arr.zip(other_arr).sortWith((x, y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })

}
