package utils

import com.alibaba.fastjson.{JSON, JSONArray}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.udf

import java.text.SimpleDateFormat
import java.util.Date
import scala.collection.mutable.ArrayBuffer

object Functions {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  /**
   * 两种不同格式时间字符串相互转换
   *
   * @param time
   * @param format
   * @param newFormat
   * @throws
   * @return
   */
  def timeToCustomTime(time: String, format1: String, format2: String) = {
    val format = new SimpleDateFormat(format1)
    val newFormat = new SimpleDateFormat(format2)

    var standardTime = new Date()
    var newTime = ""
    try {
      standardTime = format.parse(time)
      newTime = newFormat.format(standardTime)
    } catch {
      case e: Exception => println(">>>日期转换异常" + e)
    }
    newTime
  }

  /**
   * 计算两个日期的时间差，单位为天，保留指定位小数
   * date1: 时间字段1
   * date2: 时间字段2
   * dateFormat：时间格式
   * decimal：保留几位小数
   *
   * @return 时间差 单位为天，保留指定位小数
   */
  def getDateDiff = udf((date1: String, date2: String, dateFormat: String, decimal: Int) => {
    var date1_time: Double = 0.0
    var date2_time: Double = 0.0
    var datediff = ""
    try {
      date1_time = new SimpleDateFormat(dateFormat).parse(date1).getTime
      date2_time = new SimpleDateFormat(dateFormat).parse(date2).getTime
    } catch {
      case e: Exception => println("date1时间格式错误：" + e.getMessage)
    }
    if (!date1_time.equals(0.0) && !date2_time.equals(0.0)) {
      datediff = ((date1_time - date2_time) / (1000 * 60 * 60 * 24)).formatted(s"%.${decimal}f")
    }
    datediff
  })

  //  两种不同格式时间字符串相互转换
  def timeToCustomTime2 = udf((time: String, format1: String, format2: String) => {
    val format = new SimpleDateFormat(format1)
    val newFormat = new SimpleDateFormat(format2)

    var standardTime = new Date()
    var newTime = ""
    try {
      standardTime = format.parse(time)
      newTime = newFormat.format(standardTime)
    } catch {
      case e: Exception => println(">>>日期转换异常" + e)
    }
    newTime
  })

  /**
   * 将字符串转换成JSONArray再转成特定格式
   * [[108.66265,34.209589],[108.66265,34.209589],[108.66248,34.20997]] 转成 108.66265,34.209589|108.66265,34.209589|108.66248,34.20997
   *
   * @param str
   * @return
   */
  def stdCoordsToPoints(str: String) = {

    var obj = new JSONArray()
    val arr = new ArrayBuffer[String]()
    try {
      obj = JSON.parseArray(str)
      for (i <- 0 until obj.size()) {
        val x = obj.getJSONArray(i).getString(0)
        val y = obj.getJSONArray(i).getString(1)
        val sss = s"""${x},${y}"""
        arr.append(sss)
      }
    } catch {
      case e: Exception => println(">>>轨迹转换异常" + e)
    }
    val points = arr.mkString("|")
    points
  }

  /**
   * 时间转换为时间戳
   *
   * @param tm
   * @return
   */
  def tranTimeToLong = udf((time: String, format: String) => {
    var tm = 0L
    if (time != null && time.trim != "" && format != null && format.trim != "") {
      val fm = new SimpleDateFormat(format)
      try {
        tm = fm.parse(time).getTime
      } catch {
        case e: Exception => println(">>>时间转换成时间戳异常：" + e)
      }
    }
    tm
  })

  // 时间戳毫秒转换为时间
  def timestampToTime = udf((timestamp: String, format: String) => {
    var datetime = ""
    if (timestamp != null && timestamp.trim != "") {

      try {
        val sdf = new SimpleDateFormat(format)
        datetime = sdf.format(new Date(timestamp.toLong))
      } catch {
        case e: Exception => println(">>>时间戳解析异常:" + e)
      }
    }
    datetime
  })

  /**
   * 将小数转化成百分数函数，保留两位
   *
   * @return
   */
  def doubleToPercent = udf((col1: String) => {
    var percent = "0.0%"
    if (col1 != null && col1.trim != "") {
      try {
        percent = f"${col1.toDouble * 100}%.2f%%"
      } catch {
        case e: Exception => println(">>>小数转换成百分数异常：" + e)
      }
    }
    percent
  })

  // 判断 某个字符串是否为空或者null
  def isEmptyOrNull = udf((str: String) => {
    var flag: Boolean = false
    if (str == null) flag = true
    else if (str.isEmpty) flag = true
    flag
  })

}
