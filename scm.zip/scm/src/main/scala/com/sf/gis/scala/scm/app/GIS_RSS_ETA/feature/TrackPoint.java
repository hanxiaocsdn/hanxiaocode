package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

import static java.lang.Math.sqrt;

/**
 * 轨迹点结构体类
 *
 * @author 01408031
 */
public class TrackPoint {
	
	public double x = 0.0;
	public double y = 0.0;
	public TrackPoint() {
			x = 0.0;
			y = 0.0;
	}

	public TrackPoint(double _x,double _y) {
		this.x = _x;
		this.y = _y;
	}

	public double distance(TrackPoint p) {
		double delta_x = this.x - p.x;
		double delta_y = this.y - p.y;
		return sqrt(delta_x * delta_x + delta_y * delta_y);
	}

	public double getX() { return this.x; }

	public double getY() {
		return this.y;
	}

	public void setX(double _x) {
		this.x = _x;
	}

	public void setY(double _y) {
		this.y = _y;
	}

}