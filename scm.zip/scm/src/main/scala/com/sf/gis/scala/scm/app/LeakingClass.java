/**
 * Copyright (C), 2015-2023
 * FileName: LeakingClass
 * Author:   caiguofang
 * Date:     2023/10/16 15:44
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
package com.sf.gis.scala.scm.app;

import java.util.HashMap;
import java.util.Map;
import java.lang.reflect.*;
/**
 * 〈〉
 * @ClassName LeakingClass
 * @author 01420395
 * @create 2023/10/16 15:44
 * @since 1.0.0
 */
public class LeakingClass {
    private static final Map<String, Object> map = new HashMap<>();

    public static void add(String key, Object value) {
        map.put(key, value);
    }

    public static void clear() {
        map.clear();
    }


    /**
     * 数据量很大时候进行分批提交, 不能全部数据加载到内存中;不然会导致 OOM
     * @param args
     */
    public static void main(String[] args) throws ClassNotFoundException {
        int count  =0 ;
        for (int i = 0; i <=1000000000; i++) {
            Class pClass1 = Class.forName("com.sf.gis.scala.scm.app.TestJson");
//            method=m.getClass().getMethod("getAge");
//            Object returnValue=method.invoke(m);     //返回Integer对象

            LeakingClass.add("key" + i, pClass1.desiredAssertionStatus());
            if(i==1000000000){
                System.out.println(i+"");
            }
            count++;

//            System.out.printf(LeakingClass.map.size()+"");
            if (count ==10){
                count =0;
//                LeakingClass.clear();

            }
//            try {
//                Thread.sleep(2);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
        }
    }




}