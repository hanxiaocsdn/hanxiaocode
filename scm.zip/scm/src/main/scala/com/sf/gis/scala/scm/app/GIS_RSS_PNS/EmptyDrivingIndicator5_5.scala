package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.SparkBuilder


/**
  *@author 01420395
  *@DESCRIPTION
  *轨迹缺失表 需求ID 1842890   GIS-RSS-PNS：【价值线路】空驶指标监控需求_V1.0
  *任务id : 770551
  *@create 2023/06/14
  */
object EmptyDrivingIndicator5_5  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val gis_eta_jiazhi_cost_new_ksDf = gis_eta_jiazhi_cost_new_ks(inc_day, spark)

    val gis_eta_jiazhi_cost_grd1_ksDF = gis_eta_jiazhi_cost_grd1_ks(inc_day, spark)


    var jionDf = gis_eta_jiazhi_cost_new_ksDf
      .join(gis_eta_jiazhi_cost_grd1_ksDF, Seq("grd1", "inc_day"),"left")

    import spark.implicits._

    val resultDF  =  jionDf
      .withColumn("diff_road_fee",'road_fee - 're_road_fee)
      .withColumn("diff_fuel_cost",'fuel_cost - 're_fuel_cost)
      .withColumn("diff_miles",'miles - 're_miles)
      .withColumn("diff_sum_cost",'Sum_cost - 're_sum_cost)

      .select('task_area_code ,'task_id ,'task_subid ,'start_dept,'end_dept,'start_type,
        'end_type,'line_code,'linevehicle,'std_id,'vehicle_serial,'conduct_type,'is_run_ontime,'start_longitude,
        'start_latitude,'end_longitude,'end_latitude,'rt_dist,'is_stop,'stop_over_zone_code,'transoport_level,
        'carrier_name,'carrier_type,'error_type,'vehicle_type,'axls_number,'length,'weight,'length_weight,'mload,
        'miles,'road_fee,'fuel_prices,'update_uint_fuel,'fuel_cost,'sum_cost,'reject_flag,'std_id_jz,
        'online_date,'source,'grd1,'task_inc_day,'diff_road_fee,'diff_fuel_cost,'diff_miles,'diff_sum_cost,
        're_road_fee,'re_miles,'re_fuel_cost,'re_sum_cost,'inc_day)

    writeToHive(spark, resultDF, Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_compute55_ks")
  }



  def gis_eta_jiazhi_cost_new_ks(inc_day:String,spark:SparkSession)={

    val gis_eta_jiazhi_cost_new_ks_Sql =
      s"""
         |select *
         |from  dm_gis.gis_eta_jiazhi_cost_new_ks
         |where  inc_day  = '${inc_day}'
         |and conduct_type = 1
         |and sum_cost is not null
         |and reject_flag= '0'
         |and task_inc_day = '${inc_day}'
      """.stripMargin

    logger.error(gis_eta_jiazhi_cost_new_ks_Sql)

    val resultDF = spark.sql(gis_eta_jiazhi_cost_new_ks_Sql)

    resultDF
  }



  def gis_eta_jiazhi_cost_grd1_ks(inc_day:String,spark:SparkSession)={

    val gis_eta_jiazhi_cost_grd1_ks_Sql =
      s"""
         |select *
         |from  dm_gis.gis_eta_jiazhi_cost_grd1_ks
         |where  inc_day  = '${inc_day}'
      """.stripMargin

    val resultDF = spark.sql(gis_eta_jiazhi_cost_grd1_ks_Sql)

    resultDF
  }




}
