package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import common.DataSourceCommon
import utils.JDBCUtils.logger
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SaveMode}
import utils.{DateUtil, SparkUtils}

import java.sql.{Connection, DriverManager, PreparedStatement}
import java.util.Properties

/**
 * GIS-RSS-PNS：【实时交通】任务司机统计信息落表需求说明书_数据侧_V1.0 写入到ck中
 * 需求方：曹倩倩(01425168)
 *
 * @author 01420395
 *         任务ID：911271
 *         任务名称：任务司机统计信息落表
 */

object TaskDriverStatisticsToCk extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val tblName:String  ="dm_gis.DMTask_Driver_Statistics"

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    start(inc_day)
  }

  def start(inc_day: String): Unit = {

    val spark = SparkUtils.getSparkSession(appName, "yarn")
    spark.sparkContext.setLogLevel("ERROR")

    val  resouceSql  =
      s"""
         |select  vehicle_serial
         , driver_id
         , start_dept
         , end_dept
         , actual_run_time_mean
         , actual_run_time_sum
         , actual_run_time_min
         , actual_run_time_max
         , actual_run_time_std
         , rt_dist_mean
         , rt_dist_sum
         , rt_dist_min
         , rt_dist_max
         , rt_dist_std
         , sim1_mean
         , sim1_sum
         , sim1_min
         , sim1_max
         , sim1_std
         , sim5_mean
         , sim5_sum
         , sim5_min
         , sim5_max
         , sim5_std
         , plan_mean_speed
         , act_mean_speed
         , delayed_count
         , delayed_ratio
         , avg_delayed_time
         , delay_time_ratio
         , polymerization_type
         |, inc_day
         | from  dm_gis.DMTask_Driver_Statistics where inc_day  =  '${inc_day}'
         |
         |""".stripMargin

    val resourceDF = spark.sql(resouceSql)
    import spark.implicits._
    val resultDf = resourceDF
      .withColumn("etl_time", lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
      .withColumn("inc_day", lit(DateUtil.getdaysBefore(inc_day, 0  ,"yyyyMMdd","yyyy-MM-dd")))
      .select(
        'driver_id
        , 'start_dept
        , 'end_dept
        , 'actual_run_time_mean
        , 'actual_run_time_sum
        , 'actual_run_time_min
        , 'actual_run_time_max
        , 'actual_run_time_std
        , 'rt_dist_mean
        , 'rt_dist_sum
        , 'rt_dist_min
        , 'rt_dist_max
        , 'rt_dist_std
        , 'sim1_mean
        , 'sim1_sum
        , 'sim1_min
        , 'sim1_max
        , 'sim1_std
        , 'sim5_mean
        , 'sim5_sum
        , 'sim5_min
        , 'sim5_max
        , 'sim5_std
        , 'plan_mean_speed
        , 'act_mean_speed
        , 'delayed_count
        , 'delayed_ratio
        , 'avg_delayed_time
        , 'delay_time_ratio
        , 'polymerization_type
        , 'etl_time
        , 'inc_day
      )

    saveToClickhouse(resultDf,inc_day)
    spark.close()
    logger.error(println(inc_day + "：计算日期结束"))

  }

  import utils.JDBCUtils._

  def saveToClickhouse(df:DataFrame,inc_day: String): Unit = {
    val conn: Connection = getSmartDevCKConnect()
    val biz_day   = DateUtil.getdaysBefore(inc_day, 0, "yyyyMMdd", "yyyy-MM-dd")
    try {
      val delSql = s"ALTER TABLE dm_ck_scm.DMTask_Driver_Statistics DELETE WHERE inc_day = '${biz_day}'"
      val del: PreparedStatement = conn.prepareStatement(delSql)
      del.execute()
    } catch {
      case ex: Exception => logger.error(s"删除表 dm_ck_scm.DMTask_Driver_Statistics 中 '${biz_day}'数据时出现错误", ex)
        throw ex
    }

    val ck_url = "jdbc:clickhouse://10.119.82.211:8123/dm_ck_scm"

    val ckProp = new Properties()

    //写入/out读出参数
    val ck_params = Map[String, String](
      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
      "batchsize" -> "20000",
      "isolationLevel" -> "NONE",
      "numPartitions" -> "1",
      "user" -> "dm_ck_scm",
      "password" -> "dm_ck_scm@123@"
    )

    //加载
    df.write.mode(SaveMode.Append).options(ck_params).jdbc(ck_url, s"dm_ck_scm.DMTask_Driver_Statistics", ckProp)
  }


  /**
   * 智慧社区项目--获取dev CK数据库连接
   */
  def getSmartDevCKConnect(): Connection = {

    val url = "jdbc:clickhouse://10.119.82.211:8123/dm_ck_scm"
    //驱动名称
    val driver = "ru.yandex.clickhouse.ClickHouseDriver"
    //用户名
    val username = "dm_ck_scm"
    //密码
    val password = "dm_ck_scm@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接clickhouse数据库时出现错误", ex)
        throw ex
      }
    }
  }

}
