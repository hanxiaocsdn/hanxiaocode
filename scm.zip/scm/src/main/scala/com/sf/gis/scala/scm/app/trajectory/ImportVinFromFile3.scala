package com.sf.gis.scala.scm.app.trajectory

import common.DataSourceCommon
import utils.SparkBuilder

object ImportVinFromFile2 extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {


    val inc_day  = args(1)
    val path  = args(0)
    val cols = Seq("wfms","wfdz","dir","coords" ,"swid","hpzl","fre2020","fre2021","fre2022","fre2023","fre","src","remark")

    import org.apache.spark.sql.functions._

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val inputPath = path
    val vehicle_df = spark.read.option("header", "false")
      .option("delimiter", ",")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*).withColumn("inc_day",lit(inc_day))

    writeToHive(spark, vehicle_df,Seq("inc_day"), "dm_gis.bjwz")
  }



}
