//package com.sf.gis.scala.scm.app.heavycargostatic.ls
//
//import com.sf.gis.scala.scm.utils.{DateUtil, HBaseUtils, SparkBuilder}
//import com.sf.gis.scala.scm.common.DataSourceCommon
//import org.apache.hadoop.hbase.client.Put
//import org.apache.hadoop.hbase.util.Bytes
//import org.apache.spark.sql.SparkSession
//
///**
//  * @description: 全国重货基础信息初始化到hbase,一次性任务;  需求ID: 1720287 任务id 698593
//  * @author 01420935 caiguofang
//  * @date 2023/04/10 10:36
//  */
//object InitBasicVehicleFromFile extends DataSourceCommon{
//
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//  val hdfsPath="/user/01420395/upload"
//
//  val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
//  val zkPort = "2181"
//  val zkParent = "/hbase"
//
//
//  def main(args: Array[String]): Unit = {
//    val tbl_name = ""
//    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
//
//    initVehicleBasic(spark,tbl_name)
//
//    spark.close()
//  }
//
//  /**
//    * spark 读取车辆基础信息
//    * @param sparkSession
//    * @param tbl_name
//    */
//  def initVehicleBasic(spark: SparkSession, tbl_name:String)={
//
//    val vehicleBasicPath= hdfsPath+"/insurance_vehicle_basics_original_0220.csv"
//
//    import org.apache.spark.sql.functions._
//
//    val sourceDf = spark.read.format("csv").option("header", "true").load(vehicleBasicPath)
//      .select(col("id").cast("string").as("id")
//        , col("vin").cast("string").as("vin")
//        , col("vehicle_age").cast("string").as("vehicle_age")
//        , col("original_value_vehicle").cast("string").as("original_value_vehicle")
//        , col("company_name").cast("string").as("company_name")
//        , col("vehicle_type").cast("string").as("vehicle_type")
//        , col("brand_name").cast("string").as("brand_name")
//        , col("vehicle_weight").cast("string").as("vehicle_weight")
//        , col("full_weight").cast("string").as("full_weight")
//        , col("ratified_load_capacity").cast("string").as("ratified_load_capacity")
//        , col("track_front").cast("string").as("track_front")
//        , col("track_rear").cast("string").as("track_rear")
//        , col("tire_number").cast("string").as("tire_number")
//        , col("tire_specification").cast("string").as("tire_specification")
//        , col("wheel_base").cast("string").as("wheel_base")
//        , col("wheel_number").cast("string").as("wheel_number")
//        , col("long_profile_size").cast("string").as("long_profile_size")
//        , col("wide_profile_size").cast("string").as("wide_profile_size")
//        , col("height_profile_size").cast("string").as("height_profile_size")
//        , col("fuel_type").cast("string").as("fuel_type")
//        , col("effluent_standard").cast("string").as("effluent_standard")
//        , col("vehicle_model").cast("string").as("vehicle_model")
//
//        , col("wmi").cast("string").as("wmi")
//        , col("vds").cast("string").as("vds")
//        , col("vehicle_typecode").cast("string").as("vehicle_typecode")
//        , col("results_number").cast("string").as("results_number")
//        , col("data_sources").cast("string").as("data_sources")
//        , col("create_time").cast("string").as("create_time"))
//
//    sourceDf.show(2)
//
//    //存放到hive表已比对数据
//    sourceDf.createOrReplaceTempView("tmpTableName")
//    val sql = String.format(s"insert overwrite table %s select * from %s", "dm_gis.insurance_vehicle_basics_original_20230412", "tmpTableName")
//    logger.error(sql)
//    spark.sql(sql)
//    spark.catalog.dropTempView("tmpTableName")
//
//
//    logger.error(">>>>>删除hbase 完毕" )
//    //写入hbase
//    sourceDf.foreachPartition( rows => {
//      val hbaseTblName = "gis:insurance_vehicle_basics_original"
//      val hbaseTbl  = HBaseUtils.getHbaseTable(hbaseTblName,zkParent,zkQuorum,zkPort)
//      rows.foreach(row => {
//        val id  =  row.getAs[String]("id")
//        val vin = row.getAs[String]("vin")
//        val vehicle_age = row.getAs[String]("vehicle_age")
//        val original_value_vehicle = row.getAs[String]("original_value_vehicle")
//        val company_name = row.getAs[String]("company_name")
//        val vehicle_type = row.getAs[String]("vehicle_type")
//        val brand_name = row.getAs[String]("brand_name")
//        val vehicle_weight = row.getAs[String]("vehicle_weight")
//        val full_weight = row.getAs[String]("full_weight")
//
//        val ratified_load_capacity = row.getAs[String]("ratified_load_capacity")
//        val track_front = row.getAs[String]("track_front")
//        val track_rear = row.getAs[String]("track_rear")
//        val tire_number = row.getAs[String]("tire_number")
//        val tire_specification = row.getAs[String]("tire_specification")
//        val wheel_base = row.getAs[String]("wheel_base")
//        val wheel_number = row.getAs[String]("wheel_number")
//        val long_profile_size = row.getAs[String]("long_profile_size")
//        val wide_profile_size = row.getAs[String]("wide_profile_size")
//        val height_profile_size = row.getAs[String]("height_profile_size")
//        val fuel_type = row.getAs[String]("fuel_type")
//        val effluent_standard = row.getAs[String]("effluent_standard")
//
//        val vehicle_model = row.getAs[String]("vehicle_model")
//        val wmi = row.getAs[String]("wmi")
//        val vds = row.getAs[String]("vds")
//
//        val vehicle_typecode = row.getAs[String]("vehicle_typecode")
//        val results_number = row.getAs[String]("results_number")
//        val data_sources = row.getAs[String]("data_sources")
//        val create_time = row.getAs[String]("create_time")
//
//
//        val key = HBaseUtils.getKeyByStr(vin,20)
//
//        val put = new Put(Bytes.toBytes(key))
//
//        if(id != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("id"),Bytes.toBytes(id))
//        }
//
//
//        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vin"),Bytes.toBytes(vin))
//
//
//        if(full_weight != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("full_weight"),Bytes.toBytes(full_weight))
//        }
//
//        if(vehicle_model != null && !"".equalsIgnoreCase(vehicle_model)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_model"),Bytes.toBytes(vehicle_model))
//        }
//
//        if(vehicle_typecode != null && !"".equalsIgnoreCase(vehicle_typecode)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_typecode"),Bytes.toBytes(vehicle_typecode))
//        }
//
//        if(vehicle_age != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_age"),Bytes.toBytes(vehicle_age))
//        }
//
//
//        if(original_value_vehicle != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("original_value_vehicle"),Bytes.toBytes(original_value_vehicle))
//        }
//
//        if(company_name != null && !"".equalsIgnoreCase(company_name)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("company_name"),Bytes.toBytes(company_name))
//        }
//
//        if(vehicle_type != null && !"".equalsIgnoreCase(vehicle_type)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_type"),Bytes.toBytes(vehicle_type))
//        }
//
//        if(brand_name != null && !"".equalsIgnoreCase(brand_name)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("brand_name"),Bytes.toBytes(brand_name))
//        }
//
//        if(vehicle_weight != null ){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_weight"),Bytes.toBytes(vehicle_weight))
//        }
//
//        if(ratified_load_capacity != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("ratified_load_capacity"),Bytes.toBytes(ratified_load_capacity))
//        }
//
//
//        if(track_front != null ){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("track_front"),Bytes.toBytes(track_front))
//        }
//
//
//        if(track_rear != null ){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("track_rear"),Bytes.toBytes(track_rear))
//        }
//
//
//        if(tire_number != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("tire_number"),Bytes.toBytes(tire_number))
//        }
//
//
//        if(tire_specification != null && !"".equalsIgnoreCase(tire_specification)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("tire_specification"),Bytes.toBytes(tire_specification))
//        }
//
//        if(wheel_base != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wheel_base"),Bytes.toBytes(wheel_base))
//        }
//
//        if(wheel_number != null ){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wheel_number"),Bytes.toBytes(wheel_number))
//        }
//
//        if(long_profile_size != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("long_profile_size"),Bytes.toBytes(long_profile_size))
//        }
//
//        if(wide_profile_size != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wide_profile_size"),Bytes.toBytes(wide_profile_size))
//        }
//
//        if(height_profile_size != null ){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("height_profile_size"),Bytes.toBytes(height_profile_size))
//        }
//
//        if(fuel_type != null && !"".equalsIgnoreCase(fuel_type)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("fuel_type"),Bytes.toBytes(fuel_type))
//        }
//
//
//        if(effluent_standard != null && !"".equalsIgnoreCase(effluent_standard)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("effluent_standard"),Bytes.toBytes(effluent_standard))
//        }
//
//
//        if(wmi != null && !"".equalsIgnoreCase(wmi)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wmi"),Bytes.toBytes(wmi))
//        }
//
//
//        if(vds != null && !"".equalsIgnoreCase(vds)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vds"),Bytes.toBytes(vds))
//        }
//
//
//        if(results_number != null && !"".equalsIgnoreCase(results_number)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("results_number"),Bytes.toBytes(results_number))
//        }
//
//
//        if(data_sources != null && !"".equalsIgnoreCase(data_sources)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("data_sources"),Bytes.toBytes(data_sources))
//        }else{
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("data_sources"),Bytes.toBytes("1"))
//        }
//
//        if(create_time != null && !"".equalsIgnoreCase(create_time)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("create_time"),Bytes.toBytes(create_time))
//        }else{
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("create_time"),Bytes.toBytes(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
//        }
//        try{
//          hbaseTbl.put(put)
//        }catch {
//          case e:Exception=> logger.error(key+","+row.toString())
//        }
//        hbaseTbl.flushCommits()
//
//      })
//      hbaseTbl.close()
//      logger.error("写入hbase 成功")
//    })
//  }
//
//}
