package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import common.DataSourceCommon
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import utils.{DateUtil, SparkBuilder, StringUtils}

import scala.collection.mutable.ArrayBuffer


/**
  *@author 01420395
  *@DESCRIPTION
  *需求ID 1861561 GIS-RSS-ETA：【时效专项】 一级护航干预指标监控线上化_V1.0
  *任务id : 773891
  *任务依赖：
  *@create 2023/06/28
  */
object grd_ft_duiying  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val  summaryDF = get_tt_vehicle_monitor_warning_summary(spark, inc_day)

    val  socAlarmsDF = get_soc_alarms(spark, inc_day)


    import spark.implicits._

    socAlarmsDF.filter('grd_task_id === "888Y11827908").show(50 )

    val jionDF  = summaryDF.join(socAlarmsDF,socAlarmsDF("grd_task_id") === summaryDF("task_id"),"left")
      .select('task_id,'task_id_attr39,'task_id_attr34,'grd_task_id,'grd_task_id_grd_start_update_tm,'grd_task_id_alarm_name,'inc_day )


    jionDF.filter('task_id === "888Y11827908").show(50 )

    import spark.implicits._

    val resultDF = jionDF.map(row =>{
      var task_id_attr39 = row.getAs[String]("task_id_attr39")
      var grd_task_id_grd_start_update_tm = row.getAs[String]("grd_task_id_grd_start_update_tm")

      //拆分数据
      if(StringUtils.isEmpty(task_id_attr39)){
        task_id_attr39 = ""
      }
      if(StringUtils.isEmpty(grd_task_id_grd_start_update_tm)){
        grd_task_id_grd_start_update_tm = ""
      }

      val  task_id_attr39_list =  task_id_attr39.split("\\|", -1)
      val  grd_task_id_grd_start_update_tm_list =  grd_task_id_grd_start_update_tm.split("\\|", -1)


      logger.error("task_id_attr39_list >>>> " + task_id_attr39_list.size)
      logger.error("grd_task_id_grd_start_update_tm_list >>>> " + grd_task_id_grd_start_update_tm_list.size)



      val ab_tm_List  = new ArrayBuffer[String]()
      val tm_List  = new ArrayBuffer[String]()

      //获取attr39 所对应最早时间及时间差
      for(  attr39  <- task_id_attr39_list){
        var tm_cz = 0.0
        var tm_Str = attr39
        var  isHaving = false

        //获取最近时间
        for(  grd_start_update_tm  <- grd_task_id_grd_start_update_tm_list){
          //默认是最近时间倒序排序,计算毫秒数差值
          if(!StringUtils.isEmpty(attr39) && !StringUtils.isEmpty(grd_start_update_tm)){
            isHaving = true
            val sdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")
            val attr39_tm = sdf.parse(attr39)

            logger.error(attr39_tm)

            val sdf2 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")
            val grd_start_update_tm_tm = sdf2.parse(grd_start_update_tm)

            logger.error(grd_start_update_tm_tm)

            //时间戳毫秒转秒
            val absolute_tm  = Math.abs(attr39_tm.getTime/1000 - grd_start_update_tm_tm.getTime/1000)
            if(tm_cz > absolute_tm){
              tm_cz = absolute_tm
              tm_Str = grd_start_update_tm
            }
          }
        }


        //数据拼接
        if(tm_cz <= 600 && isHaving){
          ab_tm_List.append(tm_Str)
          tm_List.append( tm_cz.toString)
        }else{
          ab_tm_List.append(" ")
          tm_List.append(" ")
        }
      }

      logger.error("ab_tm_List >>>> " + ab_tm_List.size)
      logger.error("tm_List >>>> " + tm_List.size)

      val task_id = row.getAs[String]("task_id")
      val task_id_attr34 = row.getAs[String]("task_id_attr34")
      val grd_task_id_alarm_name = row.getAs[String]("grd_task_id_alarm_name")


      var Grd_ft_diff_tm = ""
      for(ab_tm <- ab_tm_List){
        if(!StringUtils.isEmpty(Grd_ft_diff_tm)){
          Grd_ft_diff_tm = Grd_ft_diff_tm + "|" + ab_tm
        }else{
          Grd_ft_diff_tm = ab_tm
        }
      }

      var Grd_ft_tm = ""
      for(ab_tm <- tm_List){
        if(!StringUtils.isEmpty(Grd_ft_tm)){
          Grd_ft_tm = Grd_ft_tm + "|" + ab_tm
        }else{
          Grd_ft_tm = ab_tm
        }
      }

      val inc_day = row.getAs[String]("inc_day")
      (task_id,task_id_attr39,task_id_attr34,grd_task_id_grd_start_update_tm,grd_task_id_alarm_name, Grd_ft_diff_tm, Grd_ft_tm,inc_day)
    }).toDF("Task_id", "Now_level_create_tm","Abnormal_relieve_tm"
      ,"grd_start_update_tm","alarm_name","Grd_ft_diff_tm"
      ,"Grd_ft_tm","inc_day")


    writeToHive(spark,resultDF,Seq("inc_day"), "dm_gis.grd_ft_duiying")
  }


  /***
    * grd预警
    * @param spark
    * @param inc_day
    * @return
    */

  def  get_tt_vehicle_monitor_warning_summary(spark :SparkSession, inc_day: String)= {

    val before7Day =DateUtil.getdaysBefore(inc_day,-7,"yyyyMMdd")
    val after3Day =DateUtil.getdaysBefore(inc_day,3,"yyyyMMdd")

    val before0Day =DateUtil.getdaysBefore(inc_day,0,"yyyyMMdd","yyyy-MM-dd")
    val before1Day =DateUtil.getdaysBefore(inc_day,-1,"yyyyMMdd","yyyy-MM-dd")
    val before2Day =DateUtil.getdaysBefore(inc_day,-2,"yyyyMMdd","yyyy-MM-dd")
    val before3Day =DateUtil.getdaysBefore(inc_day,-3,"yyyyMMdd","yyyy-MM-dd")
    val before4Day =DateUtil.getdaysBefore(inc_day,-4,"yyyyMMdd","yyyy-MM-dd")

    val sql  =
      s"""
         |select
         | distinct task_id,attr39, from_unixtime(attr34/1000,'yyyy-MM-dd HH:mm:ss') as attr34,
         | from_unixtime(unix_timestamp(task_plan_depart_date,'yyyy-MM-dd'),'yyyyMMdd') as  inc_day
         |from
         |  ods_russtask.tt_vehicle_monitor_warning_summary
         |where
         |  inc_day >= '${before7Day}'
         |  and inc_day <= '${after3Day}'
         |  and task_plan_depart_date in ('${before0Day}','${before1Day}','${before2Day}','${before3Day}','${before4Day}')
         |  and msg_type in ('5', '7', '8')  --低速，停留，轨迹缺失
         |  and biz_type in ('0', '16')  --大件，小件
         |  and warn_level in ('3')  --一级
         |  and attr34 is not null
         |order by task_id ASC, attr39 ASC
         |
       """.stripMargin



    logger.error(sql)

    val  sourceDF  = spark.sql(sql)
    sourceDF.show(1)

    import org.apache.spark.sql.functions._
    import spark.implicits._

    val resultDF =   sourceDF
      .withColumn("task_id_attr39",concat_ws("|",collect_list('attr39)over(Window.partitionBy('task_id))))
      .withColumn("task_id_attr34",concat_ws("|",collect_list('attr34)over(Window.partitionBy('task_id))))
      .select('task_id , 'task_id_attr39, 'task_id_attr34, 'inc_day).distinct()

    logger.error("tt_vehicle_monitor_warning_summary 总数量 " + resultDF.count())
    resultDF
  }



  /***
    * ft预警
    * @param spark
    * @param inc_day
    * @return
    */
  def  get_soc_alarms(spark :SparkSession, inc_day: String)= {


    val after3Day =DateUtil.getdaysBefore(inc_day,3,"yyyyMMdd")
    val before7Day =DateUtil.getdaysBefore(inc_day,-7,"yyyyMMdd")


    val before0Day =DateUtil.getdaysBefore(inc_day,0,"yyyyMMdd","yyyy-MM-dd")
    val before1Day =DateUtil.getdaysBefore(inc_day,-1,"yyyyMMdd","yyyy-MM-dd")
    val before2Day =DateUtil.getdaysBefore(inc_day,-2,"yyyyMMdd","yyyy-MM-dd")
    val before3Day =DateUtil.getdaysBefore(inc_day,-3,"yyyyMMdd","yyyy-MM-dd")
    val before4Day =DateUtil.getdaysBefore(inc_day,-4,"yyyyMMdd","yyyy-MM-dd")


    val sql  =
      s"""
        select distinct grd_task_id,grd_start_update_tm,alarm_name
         |    from
         |      dm_gis.soc_alarms
         |    where
         |      date_format(grd_plan_depart_tm, 'yyyy-MM-dd') in ('${before0Day}','${before1Day}','${before2Day}','${before3Day}','${before4Day}')
         |      and subtype in ('1', '2', '4') --告警小类
         |      and ptype in ('2') --告警大类
         |      and data_source in ('6')
         |      and def_end_type != '0'
         |      and inc_day >= '${before7Day}'
         |      and inc_day <= '${after3Day}'
         |order by grd_task_id,grd_start_update_tm,alarm_name ASC
         |
       """.stripMargin

    logger.error(sql)

    val  sourceDF  = spark.sql(sql)

    import org.apache.spark.sql.functions._
    import spark.implicits._
    val resultDF =   sourceDF
      .withColumn("grd_task_id_grd_start_update_tm",concat_ws("|",collect_list('grd_start_update_tm)over(Window.partitionBy('grd_task_id))))
      .withColumn("grd_task_id_alarm_name",concat_ws("|",collect_list('alarm_name)over(Window.partitionBy('grd_task_id))))
      .select('grd_task_id , 'grd_task_id_grd_start_update_tm, 'grd_task_id_alarm_name).distinct()

    logger.error("soc_alarms 总数量 " + resultDF.count())
    resultDF

  }
}
