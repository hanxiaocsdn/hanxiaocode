package com.sf.gis.scala.scm.app.trajectory

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.util.HttpClientUtil
import common.DataSourceCommon
import org.apache.spark.sql.functions.col
import utils.{HttpPostUtils, SparkBuilder}

import scala.collection.mutable.ArrayBuffer

/**
@author 01420395
@DESCRIPTION
需求ID 1829909 GIS-RSS-ETA-STD-LINE:【线路基础服务】城市间距离计算_V1.0 任务id 一次性任务
任务依赖：395524 临时任务
@create 2023/06/02
 */
object CityDistanceApp2 extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val url = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get"
  val getUrls = "http://gis-int2.int.sfdc.com.cn:1080/geo/api"
  val ak  = "fe044a34e92c42f5a2996275ff0074d7"
  val cityUrl = "http://ftkj-gis-apis.intsit.sfcloud.local:1080/rp/v2/api"


  def main(args: Array[String]): Unit = {
    //获取最大分区数据
    val sparkSession = SparkBuilder.localInitSpark(this.getClass.getSimpleName)


    //    val srcCitySeq = Seq("天津市天津市武清区普洛斯现代物流园5号门","湖北省荆门市掇刀区凤凰五路李宁物流园","湖北省武汉市东西湖区新沟镇荷香路5号")
    //    val srcCitySeq = Seq("广东省广州市番禺区大石镇会江村石南二路3号广宇物流李宁仓")

    val  cols = Seq("start_pri","start_city","end_pri","end_city")


    import org.apache.spark.sql.functions._
    import sparkSession.implicits._
    val inputPath = "E:\\caiguofang\\workspace\\gis-ass-oms-bd-20240218\\gis-ass-oms-bd\\scm\\src\\main\\scala\\com\\sf\\gis\\scala\\scm\\app\\trajectory\\202402201.csv"
    val vehicle_df = sparkSession.read.option("header", "true")
      .option("delimiter", "\\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*).select("start_pri","start_city","end_pri","end_city")
      //      .withColumn("start_addr",concat('start_pri,lit("_"), 'start_city))
      //      .withColumn("end_addr",concat('end_pri,lit("_"),'end_city))
      //      .select("start_addr","end_addr")
      .distinct()

    vehicle_df.show(2, false)


    val resultDF  = vehicle_df.map(row => {
      val start_pri = row.getAs[String]("start_pri")
      val start_city = row.getAs[String]("start_city")
      val end_pri = row.getAs[String]("end_pri")
      val end_city = row.getAs[String]("end_city")

      val  srcCity =  start_pri + start_city
      //获取srcCity 坐标
      val getUrl_ali = url + "?url=" + getUrls + "&address=" + srcCity + "&ak=" + ak
      val cityZbJson_ali = HttpClientUtil.getJsonByGet(getUrl_ali)
      val (x_ali, y_ali) = paserXYByCity(cityZbJson_ali)

      //获取目的坐标
      val addr1 = end_pri + end_city
      val getUrl_addr1 = url + "?url=" + getUrls + "&address=" + addr1 + "&ak=" + ak
      val cityZbJson_addr1 = HttpClientUtil.getJsonByGet(getUrl_addr1)
      val (x_pri, y_pri) = paserXYByCity(cityZbJson_addr1)

      //获取387<-ali
      val parasJson = new JSONObject()
      parasJson.put("ak", "de17fa220fbe42be95f3c84212b41c7a")
      parasJson.put("opt", "zh1")
      parasJson.put("vehicle", "6")
      parasJson.put("mLoad", "0.5")
      parasJson.put("planDate", "")
      parasJson.put("closefilter", "1")
      parasJson.put("tolls", "1")
      parasJson.put("x1", x_ali)
      parasJson.put("y1", y_ali)
      parasJson.put("x2", x_pri)
      parasJson.put("y2", y_pri)

      val lengthResultStr_ali = HttpPostUtils.post(cityUrl, parasJson, "utf-8")
      var length_ali = "0.00"
      val json = JSON.parseObject(lengthResultStr_ali).getJSONObject("result")
      if (json != null && json.containsKey("dist")) {
        length_ali = json.getString("dist")
      }
      (start_pri, start_city, end_pri, end_city, length_ali)
    })

    resultDF.coalesce(1)
      .write
      .mode("overwrite")
      .format("csv")
      .csv("E:\\caiguofang\\workspace\\gis-ass-oms-bd-20240218\\gis-ass-oms-bd\\scm\\src\\main\\scala\\com\\sf\\gis\\scala\\scm\\app\\trajectory\\20240220_out.csv")
  }


  def paserXYByCity(cityDistance:JSONObject):(String,String)={
    val result = cityDistance.getJSONObject("result")
    val x = result.getString("xcoord")
    val y = result.getString("ycoord")
    (x,y)
  }

}
