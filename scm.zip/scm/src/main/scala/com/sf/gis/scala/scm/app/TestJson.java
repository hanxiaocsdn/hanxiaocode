/**
 * Copyright (C), 2015-2023
 * FileName: TestJson
 * Author:   caiguofang
 * Date:     2023/10/17 11:32
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
package com.sf.gis.scala.scm.app;

import org.apache.commons.lang3.StringUtils;
/**
 * 〈〉
 * @ClassName TestJson
 * @author 01420395
 * @create 2023/10/17 11:32
 * @since 1.0.0
 */
public class TestJson {
     private String a ;


     public  static  void main(String [] agrs){
     }

}