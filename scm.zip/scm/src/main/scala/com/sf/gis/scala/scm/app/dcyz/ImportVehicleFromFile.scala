package com.sf.gis.scala.scm.app.dcyz

import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.{DateUtil, SparkBuilder, SparkUtils}

object ImportVehicleFromFile{

  @transient lazy val logger: Logger = Logger.getLogger(ImportVehicleFromFile.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val cols = Seq("num","lpn","vehicle_color","vin","vehicle_weight",
      "company_name","is_lkyw","sys_regist_date","license_regist_date","create_time","update_time","source","inc_day")

    val cols1 = Seq("vid","vehicle_no","vehicle_plate_color")

    val cols2 = Seq("vid","owner_name","vin")

    val sparkSession = SparkBuilder.initSpark(this.getClass.getSimpleName)
    //val sparkSession = SparkBuilder.localInitSpark(this.getClass.getSimpleName)

    val inputPath = "/user/01420395/upload/data/export/vehicle/Untitled1.csv"
    val inputPath2 = "/user/01420395/upload/data/export/vehicle/Untitled2.csv"

    import org.apache.spark.sql.functions._


    val vehicle_df1 = sparkSession.read.option("header", "true")
      .format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat")
      .option("delimiter", ",")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .load(inputPath)
      .toDF((cols1): _*)
      .coalesce(1)
      .select(cols1.map(col): _*)


    val vehicle_df2 = sparkSession.read.option("header", "true")
      .format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat")
      .option("delimiter", ",")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .load(inputPath2)
      .toDF((cols2): _*)
      .coalesce(1)
      .select(cols2.map(col): _*)

    import sparkSession.implicits._

    //    1-蓝色，2-黄色，3-黑色，4-白色，5-绿色，9-其他，91-农黄色，92-农绿色，93-黄绿色，94-渐变绿色
    val vehicle_df = vehicle_df1.join(vehicle_df2,Seq("vid"),"left")
      .selectExpr("vid","vehicle_no","vehicle_plate_color","owner_name","vin")

    val vehicleDfJson = SparkUtils.getRowToJson(vehicle_df)
      .map(row  =>{
        val vehicle_plate_color = row.getString("vehicle_plate_color")
        if("蓝色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",1)
        }else if("黄色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",2)
        }else if("黑色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",3)
        }else if("白色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",4)
        }else if("绿色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",5)
        }else if("农黄色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",91)
        }else if("农绿色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",92)
        }else if("黄绿色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",93)
        }else if("渐变绿色".equalsIgnoreCase(vehicle_plate_color)){
          row.put("vehicle_color",94)
        }else{
          row.put("vehicle_color",9)
        }
        (row.getString("vid"),row.getString("vehicle_no"),
          row.getString("vehicle_plate_color"),row.getString("owner_name")
          ,row.getString("vin"),row.getString("vehicle_color"))
      })
  val resulteDF =   sparkSession.createDataFrame(vehicleDfJson)
      .toDF("vid","vehicle_no","vehicle_plate_color","owner_name","vin","vehicle_color")
      .withColumn("lpn",'vehicle_no)
      .withColumn("vehicle_weight",lit("0"))
      .withColumn("company_name",'owner_name)
      .withColumn("is_lkyw",lit(""))
      .withColumn("sys_regist_date",lit(""))
      .withColumn("license_regist_date",lit(""))
      .withColumn("create_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
      .withColumn("update_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
      .withColumn("source",lit("1"))
      .withColumn("inc_day",lit(DateUtil.getCurrentDate("yyyyMMdd")))
      .select('lpn,'vehicle_color,'vin,'vehicle_weight,'company_name,
        'is_lkyw,'sys_regist_date,'license_regist_date,'create_time,'update_time,'source,'inc_day)

    writeToHive(sparkSession, resulteDF, Seq("inc_day"), "dm_gis.insurance_vehicle_original")

  }


  @Override
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"""insert overwrite table %s partition($parCols)  select * from %s """, resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }


}
