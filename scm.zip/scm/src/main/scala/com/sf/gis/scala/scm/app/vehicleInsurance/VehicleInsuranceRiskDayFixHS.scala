package com.sf.gis.scala.scm.app.vehicleInsurance

import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import utils.SparkBuilder

/**
  * @description: 车辆保险 日结表 异常修复 449514 (前置任务id:441364) 车辆信息回溯
  * @author 01418539 caojia
  * @date 2022/6/17 10:36
  */
object VehicleInsuranceRiskDayFixHS extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processMerge(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processMerge(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    //

    val vehicleNumberDf  = spark.sql("select lpn as lpn_v,vehicle_type as vehicle_type_v,vehicle_color as vehicle_color_v " +
      "from  dm_gis.insurance_vehicle_original  ")
    //车牌号数据为空的数据 dm_gis.insurance_vehicle_original   车辆信息 落地表
    val vehicleFixDf  = spark.sql(
      s"""
         |select  *  from dm_gis.insurance_model_duration_dist_daily_qgzh_fix
         |where  inc_day = ${start_day}
      """.stripMargin)

    val columns  = vehicleFixDf.schema.map(_.name).map(col)

    val vehicleColorIsNullDF = vehicleFixDf.filter('vehicle_color isNull)

    import org.apache.spark.sql.functions._
    val vehicleColoerDf = vehicleColorIsNullDF.join(vehicleNumberDf, vehicleColorIsNullDF("lpn")===vehicleNumberDf("lpn_v"),"left")
      .withColumn("vehicle_color",when('lpn_v isNull,
        when('vehicle_type_v ==="0",lit("黄色")).otherwise("未知"))
        .otherwise('vehicle_type_v))

      .select(columns: _*)


   val unionDF =  vehicleFixDf.filter('vehicle_color isNotNull).union(vehicleColoerDf)

    unionDF.map(row  => (row.getAs[String]("lpn")+"_"+ row.getAs[String]("vehicle_color"), row))
      .rdd.groupByKey().map(row => {
      row._2



    })
    //
    //    logger.error("写入数据=========================")
    //
    //
    //    writeToHive(spark, mrg_df, Seq("inc_day", "ak"), "dm_gis.insurance_model_duration_dist_daily_qgzh_fix")
  }
}
