package com.sf.gis.scala.scm.app.heavycargostatic.ls

import common.DataSourceCommon
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import utils.SparkBuilder

/**
  * @description: 全国重货车架号信息同步到hive中 需求ID: 1720287 任务id
  * @author 01420935 caiguofang
  * @date 2023/04/10 10:36
  */
object ExportVehicleBasicFromHbaseMain extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
//  val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
  val zkPort = "2181"
  val zkParent = "/hbase"


  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val hbaseConf  = HBaseConfiguration.create()
    hbaseConf.set("zookeeper.znode.parent", zkParent)
    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")

   val basicVehicleDF =  exportInitVehicleBasicFromHbase(spark,hbaseConf)

    writeToHiveNoPWithDB(spark,basicVehicleDF,"dm_gis.insurance_vehicle_basics_original")

    spark.close()
  }


  /**
    * 获取需要计算的车辆基础信息
    * @param spark
    * @param hbaseConf
    * @param broadcast
    * @return
    */
  def exportInitVehicleBasicFromHbase(spark: SparkSession, hbaseConf: Configuration):DataFrame={

    //获取不匹配车型数据
    val hBaseTblName = "gis:insurance_vehicle_basics_original"
    hbaseConf.set(TableInputFormat.INPUT_TABLE, hBaseTblName)

    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])

    val vehicleBaseDf = hbaseTblRdd.map(row => {
      val result = row._2
      val id  = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("id")))
      val vin = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vin")))
      val  vehicle_age = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_age")))
      val original_value_vehicle = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("original_value_vehicle")))
      val company_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_name")))
      val vehicle_type = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_type")))
      val brand_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("brand_name")))
      val  vehicle_weight = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_weight")))
      val full_weight = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("full_weight")))
      val ratified_load_capacity = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("ratified_load_capacity")))
      val track_front = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("track_front")))
      val  track_rear = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("track_rear")))
      val tire_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tire_number")))
      val tire_specification = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tire_specification")))
      val  wheel_base = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wheel_base")))
      val  wheel_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wheel_number")))
      val long_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("long_profile_size")))
      val  wide_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wide_profile_size")))
      val height_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("height_profile_size")))
      val fuel_type = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("fuel_type")))
      val effluent_standard = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("effluent_standard")))
      val vehicle_model = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_model")))
      val wmi = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wmi")))
      val vds = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vds")))
      val vehicle_typecode = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_typecode")))
      val results_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("results_number")))
      val data_sources = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("data_sources")))
      val create_time = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("create_time")))


      val temList  = List(id,vin,vehicle_age,original_value_vehicle,company_name,vehicle_type,brand_name,
        vehicle_weight,full_weight,ratified_load_capacity,track_front,track_rear,tire_number,tire_specification,
        wheel_base,wheel_number,long_profile_size,wide_profile_size,height_profile_size,fuel_type,effluent_standard,
        vehicle_model,wmi,vds,vehicle_typecode,results_number,data_sources,create_time)


      Row.fromSeq(temList)

    })


    // 转成df
    val hBaseSchame =StructType(
      List(
        StructField("id", StringType, true)
        ,StructField("vin", StringType, true)
        ,StructField("vehicle_age", StringType, true)
        ,StructField("original_value_vehicle", StringType, true)
        ,StructField("company_name", StringType, true)
        ,StructField("vehicle_type", StringType, true)
        ,StructField("brand_name", StringType, true)
        ,StructField("vehicle_weight", StringType, true)
        ,StructField("full_weight", StringType, true)
        ,StructField("ratified_load_capacity", StringType, true)
        ,StructField("track_front", StringType, true)
        ,StructField("track_rear", StringType, true)
        ,StructField("tire_number", StringType, true)
        ,StructField("tire_specification", StringType, true)
        ,StructField("wheel_base", StringType, true)
        ,StructField("wheel_number", StringType, true)
        ,StructField("long_profile_size", StringType, true)
        ,StructField("wide_profile_size", StringType, true)
        ,StructField("height_profile_size", StringType, true)
        ,StructField("fuel_type", StringType, true)
        ,StructField("effluent_standard", StringType, true)
        ,StructField("vehicle_model", StringType, true)
        ,StructField("wmi", StringType, true)
        ,StructField("vds", StringType, true)
        ,StructField("vehicle_typecode", StringType, true)
        ,StructField("results_number", StringType, true)
        ,StructField("data_sources", StringType, true)
        ,StructField("create_time", StringType, true)
      )
    )
    val vehicleDf =  spark.createDataFrame(vehicleBaseDf, hBaseSchame)

    //车型计算逻辑
    import spark.implicits._
    val resultDF = vehicleDf
      .select('id.cast("string").as("id"),
      'vin.cast("string").as("vin"),
      'vehicle_age.cast("string").as("vehicle_age"),
      'original_value_vehicle.cast("Float").as("original_value_vehicle"),
      'company_name.cast("string").as("company_name"),
      'vehicle_type.cast("string").as("vehicle_type"),
      'brand_name.cast("string").as("brand_name"),
      'vehicle_weight.cast("Float").as("vehicle_weight"),
      'full_weight.cast("Float").as("full_weight"),
      'ratified_load_capacity.cast("Float").as("ratified_load_capacity"),
      'track_front.cast("Float").as("track_front"),
      'track_rear.cast("Float").as("track_rear"),
      'tire_number.cast("Float").as("tire_number"),
      'tire_specification.cast("string").as("tire_specification"),
      'wheel_base.cast("Float").as("wheel_base"),
      'wheel_number.cast("string").as("wheel_number"),
      'long_profile_size.cast("Float").as("long_profile_size"),
      'wide_profile_size.cast("Float").as("wide_profile_size"),
      'height_profile_size.cast("Float").as("height_profile_size"),
      'fuel_type.cast("string").as("fuel_type"),
      'effluent_standard.cast("string").as("effluent_standard"),
      'vehicle_model.cast("string").as("vehicle_model"),

      'wmi.cast("string").as("wmi"),
      'vds.cast("string").as("vds"),
      'vehicle_typecode.cast("string").as("vehicle_typecode"),
      'results_number.cast("string").as("results_number"),
      'data_sources.cast("string").as("data_sources"),
      'create_time.cast("string").as("create_time")

    )

    logger.error("读取 hbase 需要计算车架总条数 "+resultDF.count() + " 车型总数 :" + resultDF.select('vehicle_typecode).distinct().count())

    resultDF
  }

}
