package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

public class RttData extends LinkData {
    public int   rtt_code =-1;
    public float rtt_speed = -1;
    public float rtt_travel_time = -1;

    public String rtt_detail = "";

    public RttData(){    }

    public RttData(long link_id,int dir,int code,float speed,float travel_time,String detail)
    {
        this.link_id = link_id;
        this.dir = dir;
        this.rtt_code = code;
        this.rtt_speed = speed;
        this.rtt_travel_time = travel_time;
        this.rtt_detail = detail;
    }

    public RttData(LinkData data,int code,float speed,float travel_time,String detail)
    {
        this.link_id = data.link_id;
        this.dir = data.dir;
        this.rtt_code = code;
        this.rtt_speed = speed;
        this.rtt_travel_time = travel_time;
        this.rtt_detail = detail;
    }
}
