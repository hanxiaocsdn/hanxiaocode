package com.sf.gis.scala.scm.app.GIS_RSS_SCM

import common.DataSourceCommon
import utils.{DateUtil, SparkBuilder}


/**
  * GIS_RSS_SCM：【北京违章扣罚】北京区违章信息获取的线上化_V1.0, 需求id 2017326
  *
  *@author 01420395 任务id: 826925
  *@DESCRIPTION ${DESCRIPTION}
  *@create 20230918
  */
object ImportbjWeiZhangToHive2   extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)

    val tableName = "dm_gis.t_bj_car_illegal_list"

    val cols = Seq("id","wfms","fkje","wfjfs","wfzt","xh","hpzl","hphm","wfsj","wfdz","wfxw","clbj","clsj","jkbj","cjjgmc","cjjg","gxsj","clbjStr","jkbjStr","scz","bzz","wfxwmc","hpzlmc","swjgbj","glbm","jdsbh","input_hphm","input_type","input_hpzl","startDate","endDate","page","task_name","ss"
    )

    import org.apache.spark.sql.functions._

    val dataFilePath = s"/user/01420395/upload/FT20230019/2017326/${inc_day}/csv/INFS_SITES_ADDR_BJ122_L.csv"
    val vehicle_df = spark.read.option("header", "false")
      .option("delimiter", ",")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(dataFilePath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*)
      .withColumn("seq_id",lit(""))
      .withColumn("guid",lit(""))
      .withColumn("city",lit(""))
      .withColumn("adcode",lit(""))
      .withColumn("batch_id",lit(""))
      .withColumn("indate",lit(""))
      .withColumn("pg_indate",lit(""))
      .withColumn("info",lit(""))
      .withColumn("etl_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
      .withColumn("inc_day",lit(inc_day))

    import  spark.implicits._
    vehicle_df.select('id).show(1,false)


    val resultRdd = vehicle_df.select(
      "id"
      ,"seq_id"
      ,"wfms"
      ,"fkje"
      ,"wfjfs"
      ,"wfzt"
      ,"xh"
      ,"hpzl"
      ,"hphm"
      ,"wfsj"
      ,"wfdz"
      ,"wfxw"
      ,"guid"
      ,"clbj"
      ,"clsj"
      ,"jkbj"
      ,"cjjgmc"
      ,"cjjg"
      ,"gxsj"
      ,"clbjstr"
      ,"jkbjstr"
      ,"scz"
      ,"bzz"
      ,"city"
      ,"wfxwmc"
      ,"hpzlmc"
      ,"swjgbj"
      ,"glbm"
      ,"jdsbh"
      ,"input_hphm"
      ,"input_type"
      ,"input_hpzl"
      ,"page"
      ,"task_name"
      ,"adcode"
      ,"ss"
      ,"batch_id"
      ,"indate"
      ,"pg_indate"
      ,"info"
      ,"etl_time"
    ,"inc_day")

    resultRdd.select('id).show(1,false)
    writeToHive(spark, resultRdd, Seq("inc_day"), tableName)
  }

}

