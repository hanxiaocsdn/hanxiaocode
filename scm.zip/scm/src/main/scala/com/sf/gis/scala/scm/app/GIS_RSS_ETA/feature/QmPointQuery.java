package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import utils.HttpRequest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.nio.file.Files;
import java.nio.file.Paths;

public class QmPointQuery {

    // Used for QmPointCache
    public String getQmpointStr(String strRequest,String build_tm){
        List<List<QmStep>> steps = new ArrayList<List<QmStep>>();
        String strResp = EnsurePost(strRequest);
//        int ret = parseResp(strResp, steps);
//        String ptString = ensembleJson(steps,build_tm,false);
//        return ptString;
        return  strResp;
    }

    public List<List<QmStep>> getQmpointStep(String strRequest){
        List<List<QmStep>> steps = new ArrayList<List<QmStep>>();
        String strResp = EnsurePost(strRequest);
        parseResp(strResp, steps);
        return steps;
    }

    public List<Long> getLinkid(List<List<QmStep>> steps)
    {
        List<Long> links = new ArrayList<>();
        for (List<QmStep> step : steps) {
            for (int j = 0; j < step.size(); ++j) {
                List<QmLink> item = step.get(j).qmlinks;
                for (int k = 0; k < item.size(); ++k) {
                    links.add(item.get(k).link_id);
                }
            }
        }
        return links;
    }

    //将查询的RTT路况绑定到link中并返回成json
    public String getQmpointStrWithRtt(List<RttData> queryed_data,String build_tm,String eta_ac_tm,List<List<QmStep>> steps) {
        Map<LinkData, RttData> mMap = new HashMap<>();
        for (int i = 0; i < queryed_data.size(); ++i){
            RttData rd = queryed_data.get(i);
            mMap.put(new LinkData(rd.link_id,rd.dir), rd);
        }
        for (List<QmStep> step : steps) {
            for(QmStep sp : step) {
                for (QmLink lk : sp.qmlinks){
                    LinkData key = new LinkData(lk.link_id,lk.dir);
                    if(mMap.containsKey(key)){
                        RttData value = mMap.get(key);
                        lk.rtt_code = value.rtt_code;
                        lk.rtt_speed = value.rtt_speed;
                        lk.rtt_travel_time = value.rtt_travel_time;
                    }
                }
            }
        }
        String js = ensembleJson(steps,build_tm,eta_ac_tm,true);
        return  js;
    }

    public String getQmpointAbout(){
        String url = "http://gis-int2.int.sfdc.com.cn:1080/rp/cpp/about";
        String strResp = EnsureGet(url);
        return  strResp;
    }

    public String ensembleJson(List<List<QmStep>> routes,String build_tm,String eta_ac_tm, boolean with_rtt) {
        String jsStr = new String();
        JSONObject rootObj = new JSONObject();
        JSONArray routeObject = new JSONArray();
        for(int k =0; k < routes.size(); ++k)
        {
            JSONObject stepObject = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            for(int i =0 ; i < routes.get(k).size();++i)
            {
                //构建json数组
                JSONObject stObject = new JSONObject();
                stObject.put("distance",routes.get(k).get(i).distance);
                stObject.put("duration",routes.get(k).get(i).duration);

                JSONArray linkArr = new JSONArray();
                for (int j =0; j< routes.get(k).get(i).qmlinks.size(); ++j)
                {
                    QmLink lk = routes.get(k).get(i).qmlinks.get(j);
                    JSONObject obj = new JSONObject();
                    obj.put("linkid", lk.link_id);
                    obj.put("dr_len", lk.dr_len);
                    obj.put("duration", lk.duration);
                    obj.put("dir", lk.dir);
                    obj.put("length", lk.length);
                    obj.put("fm", lk.fm);
                    obj.put("rc", lk.rc);
                    obj.put("hasLight", lk.hasLight);
                    obj.put("lnk_type", lk.lnk_type);
                    obj.put("adcode", lk.adcode);
                    obj.put("isCell", lk.isCell);
                    if(with_rtt == true){
                        obj.put("rtt_code",lk.rtt_code);
                        obj.put("rtt_speed",lk.rtt_speed);
                        obj.put("rtt_travel_time",lk.rtt_travel_time);
                        obj.put("rtt_detail",lk.rtt_detail);
                    }
                    linkArr.add(obj);
                }
                stObject.put("links",linkArr);
                jsonArray.add(stObject);
            }
            stepObject.put("steps", jsonArray);
            routeObject.add(stepObject);
        }
        rootObj.put("eta_ac_tm",eta_ac_tm);
        rootObj.put("build_time",build_tm);
        rootObj.put("route",routeObject);
        jsStr = rootObj.toJSONString();
        return jsStr;
    }

    /**
     * 发送post请求到qmpoint服务
     * @param strRequest 输入的json文件data
     * @param
     * @throws
     */
    public String EnsurePost(String strRequest) {
        int cnt = 0;
        try {
            do {
                String strResponse = HttpRequest.sendPost("http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail", strRequest, "c4f264d5b97c43f094cfae8373e49a0a");
                if(!strResponse.isEmpty()) {
                    JSONObject resp = JSON.parseObject(strResponse);
                    if(resp.containsKey("route") && !resp.containsKey("err")) {  //"err": 109,"msg": "访问限制,访问量已超过每分钟配额,限制了每分钟访问量:1000,总来访:3027"
                        return strResponse;
                    }
                    else if (!resp.containsKey("route") && resp.containsKey("status") && resp.getIntValue("status") == 0)
                    {
                        return "";
                    }
                    else
                    {
                        Thread.sleep(1000);
                    }
                }
                ++cnt;
            }while(cnt < 60);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 发送get请求到qmpoint服务
     * @param
     * @throws
     */
    public String EnsureGet(String url){
        int cnt = 0;
        try {
            do {
                //String strResponse = HttpRequest.sendPost(Config.getQmpointServer(), strRequest, Config.getQmPointAk());
                String strResponse = HttpRequest.sendGet(url, 60000);
                if(!strResponse.isEmpty()) {
                    return strResponse;
                }
                else
                {
                    Thread.sleep(1000);
                }
                ++cnt;
            }while(cnt < 60);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 解析qmpoint返回的json
     *
     * @author 01408031
     */
    public int parseResp(String strResp, List<List<QmStep>> qmSteps)
    {
        if (strResp.isEmpty())
            return -1;
        JSONObject rp = JSON.parseObject(strResp);
        if(!rp.containsKey("route")) {
            return -1;
        }
        JSONObject rest = rp.getJSONObject("route");
        if(!rest.containsKey("paths")) {
            return -1;
        }

        JSONArray path = rest.getJSONArray("paths");
        for (int k = 0 ; k < path.size(); ++k)
        {
            List<QmStep> stepList = new ArrayList<QmStep>();
            JSONObject data = path.getJSONObject(k);
            if (!data.containsKey("steps") || data.getJSONArray("steps").isEmpty()) {
                continue;
            }
            JSONArray steps = data.getJSONArray("steps");
            for (int i = 0; i < steps.size(); ++i) {
                JSONObject obj = steps.getJSONObject(i);
                if (!obj.containsKey("links") && !obj.containsKey("distance") && !obj.containsKey("duration"))
                    continue;

                QmStep qmstep = new QmStep();
                qmstep.distance = obj.getIntValue("distance");
                qmstep.duration = obj.getIntValue("duration");
                JSONArray links = obj.getJSONArray("links");
                for (int j =0; j < links.size(); ++j)
                {
                    JSONObject lko = links.getJSONObject(j);
                    QmLink qmlink = new QmLink();
                    qmlink.link_id = lko.getLongValue("sw_id");
                    qmlink.dr_len = lko.getIntValue("dr_length");
                    qmlink.duration = lko.getFloatValue("duration");
                    qmlink.dir = lko.getIntValue("direction");
                    qmlink.length = lko.getIntValue("length");
                    qmlink.fm = lko.getIntValue("formway");
                    qmlink.rc = lko.getIntValue("roadclass");
                    qmlink.hasLight = lko.getIntValue("has_light");
                    qmlink.lnk_type = lko.getIntValue("lnk_type");
                    qmlink.adcode = lko.getIntValue("adcode");
                    if (lko.containsKey("fcell") || lko.containsKey("tcell")){
                        qmlink.isCell = 1;
                    }
                    qmstep.qmlinks.add(qmlink);
                }
                stepList.add(qmstep);
            }
            qmSteps.add(stepList);
        }
        return 0;
    }

    public void thirdWay(String data) throws IOException {
        String dir = "D:\\user\\01408031\\桌面\\c.txt";
        File file = new File(dir);
        //如果文件不存在，创建文件
        if (!file.exists())
            file.createNewFile();
        //创建FileOutputStream对象，写入内容
        FileOutputStream fos = new FileOutputStream(file);
        //向文件中写入内容
        fos.write(data.getBytes());
        fos.close();
        //创建FileInputStream对象，读取文件内容
        FileInputStream fis = new FileInputStream(file);
        byte[] bys = new byte[100];
        while (fis.read(bys, 0, bys.length)!=-1) {
            //将字节数组转换为字符串
            System.out.println(new String(bys));
        }
        fis.close();
    }

        public static void main(String []args) {
        try {
            String content = new String(Files.readAllBytes(Paths.get("D:\\user\\01408031\\桌面\\123456.json")));
            QmPointQuery qpq = new QmPointQuery();
            List<List<QmStep>> steps = new ArrayList<List<QmStep>>();
            int ret = qpq.parseResp(content, steps);
            String build_tm = "aaa";
            String eta_ac_tm = "bbb";
            String ptString = qpq.ensembleJson(steps,build_tm,eta_ac_tm,false);
            qpq.thirdWay(ptString);
            System.out.println("Hello World!");
        }catch (Exception exception){
            System.out.println(exception);
        }

    }
}
