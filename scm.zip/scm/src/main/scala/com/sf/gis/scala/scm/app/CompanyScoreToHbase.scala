//package com.sf.gis.scala.scm.app
//
//import com.alibaba.fastjson.JSONObject
//import com.sf.gis.scala.scm.utils.{HBaseUtils, JSONUtils, SparkUtils}
//import org.apache.hadoop.conf.Configuration
//import org.apache.hadoop.hbase.HBaseConfiguration
//import org.apache.hadoop.hbase.client.{Put, Result}
//import org.apache.hadoop.hbase.io.ImmutableBytesWritable
//import org.apache.hadoop.hbase.mapreduce.TableInputFormat
//import org.apache.hadoop.hbase.util.Bytes
//import org.apache.log4j.Logger
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.types.{StringType, StructField, StructType}
//import org.apache.spark.sql.{Row, SparkSession}
//
///*
//企业评分数据 导出hbase 任务id 710431
// @author 01401062
// @DESCRIPTION ${DESCRIPTION}
// @create 2022/12/1
//*/
//
//object CompanyScoreToHbase {
//  @transient lazy val logger: Logger = Logger.getLogger(CompanyScoreToHbase.getClass)
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//
//  //获取原始数据
//  //切换集群
//  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw" //新的
////    val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
//
//  val zkPort = "2181"
//  val zkParent = "/hbase"
//
//
//  /**
//    * 获取原始hive数据
//    * @param spark
//    * @param inc_day
//    * @return
//    */
//
//  def getSourceRdd(spark: SparkSession) = {
//
//    val sorceTable = "dm_gis_edt.vehicle_company_score"
//
//    import spark.implicits._
//    var partitionsSql = s"""show partitions ${sorceTable}"""
//    val tblDf = spark.sql(partitionsSql)
//
//    val partisionRDD = tblDf.map(x=>{
//      val partition = x.getString(0)
//      val value =  partition.split("=")(1)
//
//      value
//    })
//    import org.apache.spark.sql.functions._
//    val maxParitions = partisionRDD.toDF("inc_day").select(max('inc_day).as("inc_day")).collectAsList()
//
//    val inc_day =  maxParitions.get(0).getAs[String](0)
//
//    logger.error("最大分区 " + inc_day)
//
//    val sourceSql =
//      s"""
//         |select
//         |  *
//         |from
//         |  ${sorceTable}
//         |where
//         |  inc_day='${inc_day}'
//         |and
//         |  company_id != ''
//         |and
//         |  company_id is not null
//         |""".stripMargin
//
//
//    logger.error("执行sql : " + sourceSql)
//
//    val sourceDf = spark.sql(sourceSql)
//    val sourceRdd = SparkUtils.getRowToJson(sourceDf)
//
//    sourceRdd
//  }
//
//
//  /**
//    * 获取需要计算的车辆基础信息
//    * @param spark
//    * @param hbaseConf
//    * @param broadcast
//    * @return
//    */
//  def getSourceRdd2(spark: SparkSession, hbaseConf: Configuration)= {
//
//    //获取不匹配车型数据
//    val hBaseTblName = "gis:gis_company_score"
//    val family = "info"
//
//    hbaseConf.set(TableInputFormat.INPUT_TABLE, hBaseTblName)
//
//    val hbaseTblRdd = spark.sparkContext.newAPIHadoopRDD(hbaseConf, classOf[TableInputFormat], classOf[ImmutableBytesWritable], classOf[Result])
//
//    val vehicleBaseDf = hbaseTblRdd.map(row => {
//      val result = row._2
//      val company_id = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_id")))
//      val company_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_name")))
//      val credit_code = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("credit_code")))
//      val province = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("province")))
//      val lawsuit_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("lawsuit_number")))
//      val abnormal_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("abnormal_number")))
//      val company_score = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_score")))
//      val cate_1 = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("cate_1")))
//      val reg_location = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("reg_location")))
//      val company_org_type_new = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_org_type_new")))
//      val phone_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("phone_number")))
//      val legal_person_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("legal_person_name")))
//      val tax_credit_recent_local_rate = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tax_credit_recent_local_rate")))
//
//      val temList = List(company_id, company_name, credit_code, province, lawsuit_number, abnormal_number, company_score,
//        cate_1, reg_location, company_org_type_new, phone_number, legal_person_name, tax_credit_recent_local_rate)
//
//      Row.fromSeq(temList)
//
//    })
//
//    // 转成df
//    val hBaseSchame =StructType(
//      List(
//        StructField("company_id", StringType, true)
//        ,StructField("company_name", StringType, true)
//        ,StructField("credit_code", StringType, true)
//        ,StructField("province", StringType, true)
//        ,StructField("lawsuit_number", StringType, true)
//        ,StructField("abnormal_number", StringType, true)
//        ,StructField("company_score", StringType, true)
//        ,StructField("cate_1", StringType, true)
//        ,StructField("reg_location", StringType, true)
//        ,StructField("company_org_type_new", StringType, true)
//        ,StructField("phone_number", StringType, true)
//        ,StructField("legal_person_name", StringType, true)
//        ,StructField("tax_credit_recent_local_rate", StringType, true)
//      )
//    )
//    val vehicleDf =  spark.createDataFrame(vehicleBaseDf, hBaseSchame)
//    vehicleDf.show(10)
//
//    SparkUtils.getRowToJson(vehicleDf)
//
//
//  }
//
//  def builderVehicleCompanyScore2(sparkSession: SparkSession,sourceRdd:RDD[JSONObject])={
//    val rows =  sourceRdd.map(obj => {
//      val company_id = JSONUtils.getJsonValue(obj,"company_id","")
//      val company_name = JSONUtils.getJsonValue(obj,"company_name","")
//      val credit_code = JSONUtils.getJsonValue(obj,"credit_code","")
//      val province = JSONUtils.getJsonValue(obj,"province","")
//      val lawsuit_number = JSONUtils.getJsonValue(obj,"lawsuit_number","")
//      val abnormal_number = JSONUtils.getJsonValue(obj,"abnormal_number","")
//      val company_score = JSONUtils.getJsonValue(obj,"company_score","")
//      val cate_1 = JSONUtils.getJsonValue(obj,"cate_1","")
//      val reg_location = JSONUtils.getJsonValue(obj,"reg_location","")
//      val company_org_type_new = JSONUtils.getJsonValue(obj,"company_org_type_new","")
//      val phone_number = JSONUtils.getJsonValue(obj,"phone_number","")
//      val legal_person_name = JSONUtils.getJsonValue(obj,"legal_person_name","")
//      val tax_credit_recent_local_rate	 = JSONUtils.getJsonValue(obj,"tax_credit_recent_local_rate","")
//      val key = HBaseUtils.getKeyByStr2(company_name,30)
//      (key,company_name,company_id,credit_code,province,lawsuit_number,abnormal_number,company_score,cate_1,reg_location,company_org_type_new,phone_number,legal_person_name,tax_credit_recent_local_rate)
//
//    })
//
//    val VehicleCompanyScore2DF = sparkSession.createDataFrame( rows)
//      .toDF("rowkey","company_name","company_id","credit_code",
//        "province","lawsuit_number","abnormal_number","company_score","cate_1"
//        ,"reg_location","company_org_type_new","phone_number","legal_person_name"
//        ,"tax_credit_recent_local_rate")
//
//
//    SparkUtils.getRowToJson(VehicleCompanyScore2DF)
//  }
//
//
//
//  def startSta(spark: SparkSession, inc_day: String) = {
////    val sourceRdd = getSourceRdd(spark)
//
//    val hbaseConf  = HBaseConfiguration.create()
//    hbaseConf.set("zookeeper.znode.parent", zkParent)
//    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
//    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
//    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")
//
//
//    val sourceRdd = getSourceRdd2(spark,hbaseConf)
////
//    //保存 gis_company_score2
//    savevehicleCompanyScoreRDDToHbase(sourceRdd)
//
//    //保存 gis_company_score
//    savevehicleCompanyScore2RDDToHbase(sourceRdd)
//
//  }
//
//  /**
//    * 二级索引推送到hbase 中
//    * @param sourceRdd
//    */
//  def savevehicleCompanyScore2RDDToHbase(sourceRdd: RDD[JSONObject]) = {
//    val hTable = "gis:gis_company_score"
//    val family = "info"
//
//    sourceRdd.foreachPartition(iter => {
//      val table =HBaseUtils.getHbaseTable(hTable,zkParent,zkQuorum,zkPort)
//
//      iter.foreach(obj => {
//
//        val company_id = JSONUtils.getJsonValue(obj,"company_id","")
//        val company_name = JSONUtils.getJsonValue(obj,"company_name","")
//        val credit_code = JSONUtils.getJsonValue(obj,"credit_code","")
//        val province = JSONUtils.getJsonValue(obj,"province","")
//        val lawsuit_number = JSONUtils.getJsonValue(obj,"lawsuit_number","")
//        val abnormal_number = JSONUtils.getJsonValue(obj,"abnormal_number","")
//        val company_score = JSONUtils.getJsonValue(obj,"company_score","")
//        val cate_1 = JSONUtils.getJsonValue(obj,"cate_1","")
//        val reg_location = JSONUtils.getJsonValue(obj,"reg_location","")
//        val company_org_type_new = JSONUtils.getJsonValue(obj,"company_org_type_new","")
//        val phone_number = JSONUtils.getJsonValue(obj,"phone_number","")
//        val legal_person_name = JSONUtils.getJsonValue(obj,"legal_person_name","")
//        val tax_credit_recent_local_rate	 = JSONUtils.getJsonValue(obj,"tax_credit_recent_local_rate","")
//        val key = HBaseUtils.getKeyByStr2(company_name,30)
//
//
//        val put = new Put(Bytes.toBytes(key))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("company_name"), Bytes.toBytes(company_name))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("company_id"), Bytes.toBytes(company_id))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("credit_code"), Bytes.toBytes(credit_code))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("province"), Bytes.toBytes(province))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("lawsuit_number"), Bytes.toBytes(lawsuit_number))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("abnormal_number"), Bytes.toBytes(abnormal_number))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("company_score"), Bytes.toBytes(company_score))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("cate_1"), Bytes.toBytes(cate_1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("reg_location"), Bytes.toBytes(reg_location))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("company_org_type_new"), Bytes.toBytes(company_org_type_new))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("phone_number"), Bytes.toBytes(phone_number))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("legal_person_name"), Bytes.toBytes(legal_person_name))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("tax_credit_recent_local_rate"), Bytes.toBytes(tax_credit_recent_local_rate))
//
//        try{
//          table.put(put)
//        }catch {
//          case e:Exception=> logger.error(key+","+obj.toJSONString)
//        }
//        table.flushCommits()
//      })
//
//      table.close()
//
//    })
//
//    logger.error("写入hbase成功")
//
//  }
//
//
//  /**
//    * 一级索引推送到hbase 中
//    * @param sourceRdd
//    */
//  def savevehicleCompanyScoreRDDToHbase(sourceRdd: RDD[JSONObject]) = {
//    val hTable = "gis:gis_company_score2"
//    val family = "info"
//
//    sourceRdd.foreachPartition(iter => {
//      val table =HBaseUtils.getHbaseTable(hTable,zkParent,zkQuorum,zkPort)
//
//      iter.foreach(obj => {
//
//        val company_id = JSONUtils.getJsonValue(obj,"company_id","")
//        val company_name = JSONUtils.getJsonValue(obj,"company_name","")
//        val credit_code = JSONUtils.getJsonValue(obj,"credit_code","")
//
//        val new_row_key = HBaseUtils.getKeyByStr2(credit_code,30)
//        val other_rowkey = HBaseUtils.getKeyByStr2(company_name,30)
//
//        val put = new Put(Bytes.toBytes(new_row_key))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("credit_code"), Bytes.toBytes(credit_code))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("company_id"), Bytes.toBytes(company_id))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("other_rowkey"), Bytes.toBytes(other_rowkey))
//
//        try{
//          table.put(put)
//        }catch {
//          case e:Exception=> logger.error(new_row_key+","+obj.toJSONString)
//        }
//        table.flushCommits()
//      })
//
//      table.close()
//
//    })
//
//    logger.error("写入hbase成功")
//
//  }
//
//
//
//  def start(inc_day: String): Unit = {
//
//    val spark = SparkSession.builder()
//      .appName(appName)
//      .master("yarn")
//      .enableHiveSupport()
//      .config("hive.exec.dynamic.partition",true)
//      .config("hive.exec.dynamic.partition.mode","nonstrict")
//      .getOrCreate()
//
//    spark.sparkContext.setLogLevel("ERROR")
//    startSta(spark,inc_day)
//    logger.error("统计结束")
//
//
//  }
//
//
//  def main(args: Array[String]): Unit = {
//
//    val inc_day = args(0)
//
//    start(inc_day)
//
//  }
//
//
//}
