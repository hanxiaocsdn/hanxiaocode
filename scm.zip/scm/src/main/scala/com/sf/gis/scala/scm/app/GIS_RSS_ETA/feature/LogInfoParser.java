package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

//解析log表
public class LogInfoParser {

    public LogInfoParser(){}

    public static String format_decimal( String num, Integer ndigits) {
        String[] data = num.split("\\.");  //注意:java必须是\\.
        String a = "";
        String b = "";
        String res = "";
        if(data.length == 2 ){
            a = data[0];
            if(data[1].length() < ndigits){
                b =data[1];
            }else{
                b = data[1].substring(0,ndigits);
            }
            res = a + "." + b;
        }
        return res;
    }
    public static LogInfo parseLog(String log) throws Exception {
        LogInfo loginfo = new LogInfo();
        if(!JSON.isValidObject(log) || log.isEmpty()){
            return loginfo;
        }
        JSONObject ret = JSON.parseObject(log);
        // 按k取值
        if(ret.containsKey("dataTime")){
            loginfo.dataTime = ret.getString("dataTime");
        }
        if (ret.containsKey("reqId")){
            loginfo.reqId = ret.getString("reqId");
        }
        if (ret.containsKey("type")){
            loginfo.eta_type = ret.getString("type");
        }
        if (ret.containsKey("subType")){
            loginfo.sub_type = ret.getString("subType");
        }
        if (ret.containsKey("data") ){
            JSONObject data = ret.getJSONObject("data");
            if (data.containsKey("arg")){
                JSONObject arg = data.getJSONObject("arg");
                if (arg.containsKey("taskId")){
                    loginfo.taskId = arg.getString("taskId");
                }
                if (arg.containsKey("lineCode")){
                    loginfo.lineCode = arg.getString("lineCode");
                }
                if(arg.containsKey("srcZoneId")){
                    loginfo.srcZoneId = arg.getString("srcZoneId");
                }
                if(arg.containsKey("destZoneId")){
                    loginfo.destZoneId = arg.getString("destZoneId");
                }
                if (arg.containsKey("plate")){
                    loginfo.plate = arg.getString("plate");
                }
                if (arg.containsKey("requestTime")){
                    loginfo.requestTime = arg.getString("requestTime");
                }
                if (arg.containsKey("validTime")){
                    loginfo.validTime = arg.getString("validTime");
                }
                if (arg.containsKey("x1")){
                    loginfo.srcZone_x = arg.getString("x1");
                }
                if (arg.containsKey("y1")){
                    loginfo.srcZone_y = arg.getString("y1");
                }
                loginfo.eta_srcZoneCoordinate = loginfo.srcZone_x + "," + loginfo.srcZone_y;
                if (arg.containsKey("x2")){
                    loginfo.destZone_x = arg.getString("x2");
                }
                if (arg.containsKey("y2")){
                    loginfo.destZone_y = arg.getString("y2");
                }
                loginfo.eta_destZoneCoordinate = loginfo.destZone_x + "," + loginfo.destZone_y;

            }
            if (data.containsKey("result")){
                JSONObject result = data.getJSONObject("result");
                if(null != result){
                    if (!result.isEmpty() && result.containsKey("x") ){ //&& result.get("x") != null
                        loginfo.x = result.get("x").toString();
                    }
                    if (!result.isEmpty() && result.containsKey("y") ){ //&& result.get("y") != null
                        loginfo.y = result.get("y").toString();
                    }
                    loginfo.eta_act_point = loginfo.x  + "," + loginfo.y;
                    if (!result.isEmpty() && result.containsKey("tm")){ // && result.get("tm") != null
                        loginfo.eta_act_time = result.get("tm").toString();
                    }
                    if (!result.isEmpty() && result.containsKey("points")){
                        loginfo.points = result.getString("points");
                    }
                    if (!result.isEmpty() && result.containsKey("etaMachineFeature")){
                        loginfo.etaMachineFeature = result.getString("etaMachineFeature");
                    }
                    if(!result.isEmpty() && result.containsKey("etaMachineTime")){
                        loginfo.etaMachineTime = result.getString("etaMachineTime");
                    }
                    if(!result.isEmpty() && result.containsKey("etaMachineDist")){
                        loginfo.etaMachineDist = result.getString("etaMachineDist");
                    }
                    if(!result.isEmpty() && result.containsKey("arriveTime")){
                        loginfo.arriveTime = result.getString("arriveTime");
                    }
                    if(!result.isEmpty() && result.containsKey("etaType")){
                        loginfo.etaType = result.getString("etaType");
                    }

                    loginfo.group_task = loginfo.taskId + "_" + loginfo.srcZoneId + "_" + loginfo.destZoneId;
                    //https://blog.csdn.net/neleuska/article/details/73277042
                    loginfo.destZone_x_round = format_decimal(loginfo.destZone_x, 6);      //圆整
                    loginfo.destZone_y_round = format_decimal(loginfo.destZone_y, 6);
                    loginfo.gp = loginfo.group_task + "_" + loginfo.destZone_x_round + "_" + loginfo.destZone_y_round;
                }
            }
//            }
        }
        return loginfo;
    }
}
