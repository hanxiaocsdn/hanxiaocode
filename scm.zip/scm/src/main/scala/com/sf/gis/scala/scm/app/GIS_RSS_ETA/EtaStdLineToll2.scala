package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.util.HttpUtils
import common.DataSourceCommon
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions.{col, when}
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import utils.{HttpPostUtils, SparkUtil, SparkUtils}

/**
 * 一次性任务
 */
object EtaStdLineToll2 extends DataSourceCommon {
  val className: String = this.getClass.getSimpleName.replace("$", "")

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val rcodeUrl:String  = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/geo/api"
  val rCodeAk:String  ="fe044a34e92c42f5a2996275ff0074d7"

  val freeUrl: String  = "http://ftkj-gis-apis.intsit.sfcloud.local:1080/rp/v2/api"
  val freeAk: String = "de17fa220fbe42be95f3c84212b41c7a"




  def main(args: Array[String]): Unit = {

    val spark =  SparkUtil.getLocalSpark(appName)
    logger.error("++++++++  任务开始   ++++")
    start(spark)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }


  def start(sparkSession:SparkSession)={

    val cols = Seq("col1","col2","col3","col4","col5","col6","col7","col8","col9","col10","col11")
    val inputPath = "E:\\caiguofang\\导航相关资料\\管网钢管运输费用预测1113.csv"
    val vehicle_df = sparkSession.read.option("header", "true")
      .option("delimiter", "\\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*).select("col7","col8","col9","col10").distinct()

    vehicle_df.show(1, false)


    //获取坐标数据

    val rcodeJson  = SparkUtils.getRowToJson(vehicle_df)

    val rcodeJson2=  rcodeJson.map(row  =>{

      val startRcode = row.getString("col7")
      val endRcode = row.getString("col9")

      //开始坐标
      val url = rcodeUrl + "&ak="+rCodeAk
      val startRCodeResponse  = HttpUtils.urlConnectionGetStr(url+"&address="+startRcode,1000)
      var startRCodeJSon =  JSON.parseObject(startRCodeResponse)

      val statue  = startRCodeJSon.getInteger("match_level")
      if(0!=statue){
        val startRcode1 = row.getString("col8")
        val startRCodeResponse  = HttpUtils.urlConnectionGetStr(url+"&address="+startRcode1,1000)
        startRCodeJSon =  JSON.parseObject(startRCodeResponse)
      }
      val start_x = startRCodeJSon.getJSONObject("result").getString("xcoord")
      val start_y = startRCodeJSon.getJSONObject("result").getString("ycoord")


      val endRCodeResponse  = HttpUtils.urlConnectionGetStr(url+"&address="+endRcode,1000)
      val endRCodeJSon =  JSON.parseObject(endRCodeResponse)
      val end_x = endRCodeJSon.getJSONObject("result").getString("xcoord")
      val end_y = endRCodeJSon.getJSONObject("result").getString("ycoord")

      row.put("start_x",start_x)
      row.put("start_y",start_y)
      row.put("end_x",end_x)
      row.put("end_y",end_y)

      row.put("vehicle",8)
      row.put("axleNumber",6)
      row.put("mLoad",30)

      row
    })

    //获取路桥费

    val resulte = rcodeJson2.map(row => {
      val requeseJson  = new JSONObject
      requeseJson.put("ak", "de17fa220fbe42be95f3c84212b41c7a")
      requeseJson.put("axleNumber", row.getString("axleNumber"))
      requeseJson.put("coordFlag", 1)
      requeseJson.put("mLoad",row.getString("mLoad"))
      requeseJson.put("opt", "1")
      requeseJson.put("pathCount",1)
      requeseJson.put("tolls", "1")
      requeseJson.put("vehicle", row.getString("vehicle"))
      requeseJson.put("x1", row.getString("start_x"))
      requeseJson.put("x2", row.getString("end_x"))
      requeseJson.put("y1", row.getString("start_y"))
      requeseJson.put("y2", row.getString("end_y"))


      logger.error(row.getString("col7") + "=="+row.getString("col9") + "=== 请求 " + requeseJson)

      val response =  HttpPostUtils.post(freeUrl,requeseJson,"utf-8")

      val responseJson  = JSON.parseObject(response)

      logger.error("=== 响应 " + responseJson)

      val status  = responseJson.getInteger("status")
      val resultJson  = new JSONObject()

      resultJson.put("srcCity",row.getString("col7"))
      resultJson.put("srcRcode",row.getString("start_x") + ","+row.getString("start_y"))
      resultJson.put("desCity",row.getString("col9"))
      resultJson.put("desRcode",row.getString("end_x") + ","+row.getString("end_y"))
      resultJson.put("fx",row.getString("col7") + "=="+row.getString("col9"))
      resultJson.put("srcCity1",row.getString("col7"))
      resultJson.put("desCity1",row.getString("col9"))
      resultJson.put("type",row.getString("col10"))
      resultJson.put("srcRcode1",row.getString("start_x") + ","+row.getString("start_y"))
      resultJson.put("desRcode1",row.getString("end_x") + ","+row.getString("end_y"))


      if(0==status){
        val highway  =  responseJson.getJSONObject("result").getLong("highway")

        resultJson.put("highway",highway/1000)


        val time  = responseJson.getJSONObject("result").getDouble("time")

        val hTime  = time/3600
        val hSc  = (time - hTime.toInt*3600)/60

        resultJson.put("time",hTime.toInt +"H" + hSc.toInt +"M")

        var tolls =  responseJson.getJSONObject("result").getDouble("tolls")

        if(tolls == -1){
          tolls = highway*1.5
        }

        resultJson.put("tolls",tolls)

        val dist  = responseJson.getJSONObject("result").getDouble("dist")/1000
        resultJson.put("dist",dist)
        resultJson.put("yf",28.42*8.1*dist / 100)
        resultJson.put("rgfy",dist)
        resultJson.put("total",dist + tolls + 28.42*8.1*dist / 100)
      }else{
        resultJson.put("highway",0)
        resultJson.put("time","0")
        resultJson.put("tolls",0)
        resultJson.put("dist",0)
        resultJson.put("yf",0)
        resultJson.put("rgfy",0)
        resultJson.put("total",0)
      }

      Row(resultJson.getString("srcCity")
        ,resultJson.getString("srcRcode")
        ,resultJson.getString("desCity")
        ,resultJson.getString("desRcode")
        ,resultJson.getString("fx")
        ,resultJson.getString("srcCity1")
        ,resultJson.getString("desCity1")
        ,resultJson.getString("type")
        ,resultJson.getString("srcRcode1")
        ,resultJson.getString("desRcode1")
        ,resultJson.getDouble("dist")
        ,resultJson.getDouble("highway")
        ,resultJson.getString("time")
        ,resultJson.getDouble("tolls")
        ,resultJson.getDouble("yf")
        ,resultJson.getDouble("rgfy")
        ,resultJson.getDouble("total"))
    })

    logger.error(resulte.count())

    val schema = StructType(List(
      StructField("srcCity", StringType, true),
      StructField("srcRcode", StringType, true),
      StructField("desCity", StringType, true),
      StructField("desRcode", StringType, true),
      StructField("fx", StringType, true),
      StructField("srcCity1", StringType, true),
      StructField("desCity1", StringType, true),
      StructField("vtype", StringType, true),
      StructField("srcRcode1", StringType, true),
      StructField("desRcode1", StringType, true),
      StructField("dist", DoubleType, true),
      StructField("highway", DoubleType, true),
      StructField("time", StringType, true),
      StructField("tolls", DoubleType, true),
      StructField("yf", DoubleType, true),
      StructField("rgfy", DoubleType, true),
      StructField("total", DoubleType, true)
    ))


    val freeDf =  sparkSession.createDataFrame(resulte, schema)

    freeDf.show(3, false)

    val outPath = "E:\\caiguofang\\导航相关资料\\1113.csv"

    freeDf.coalesce(1).write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", ",")
      .csv(outPath)
  }

}
