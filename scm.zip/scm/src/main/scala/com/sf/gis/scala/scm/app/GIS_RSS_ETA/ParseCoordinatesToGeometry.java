package com.sf.gis.scala.scm.app.GIS_RSS_ETA;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2023/11/20
*/

import com.vividsolutions.jts.algorithm.ConvexHull;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.io.WKTWriter;
import com.vividsolutions.jts.triangulate.ConformingDelaunayTriangulationBuilder;

public class ParseCoordinatesToGeometry {

    public static void main(String[] args) {
        String coordinates = "122.38384481,41.41249384|122.39092908,41.41182255|122.39397333,41.41501473000001|122.38555724000001,41.41303442|122.38409023,41.41261252|122.38404329,41.41259441";

        // 解析坐标字符串为 Polygon 几何对象
        Polygon polygon = coordinatesToPolygon(coordinates);

        Coordinate coordinate = new Coordinate( 122.383914, 41.415351);
        GeometryFactory geometryFactory = new GeometryFactory();

        Point point = geometryFactory.createPoint(coordinate);

        // 打印 Polygon 几何对象的 WKT 字符串表示
        System.out.println("Polygon: " + polygon.toString());
        System.out.println("Point: " + point.toString());

        boolean contains = polygon.contains(point);

        System.out.println("是否包含：" + contains);


    }



        // 将坐标字符串转换为 Polygon 几何对象
    public static Polygon coordinatesToPolygon(String coordinates) {
        GeometryFactory geometryFactory = new GeometryFactory();

        // 分割坐标字符串
        String[] points = coordinates.split("\\|");
        Coordinate[] coords = new Coordinate[points.length];

        // 解析每个点的经纬度并创建 Coordinate 对象
        for (int i = 0; i < points.length; i++) {
            String[] parts = points[i].split(",");
            double x = Double.parseDouble(parts[0]);
            double y = Double.parseDouble(parts[1]);
            coords[i] = new Coordinate(x, y);
        }

        try {
            ConvexHull convexHull = new ConvexHull(coords, new GeometryFactory());

            Geometry hull = convexHull.getConvexHull().buffer(0.001);

            // 打印凸包多边形的 WKT 字符串表示
//            System.out.println("Convex Hull Polygon: " + hull.toString());

            // 直接将凸包转换为 Polygon
            Polygon polygon = geometryFactory.createPolygon(hull.getCoordinates());

            return polygon;

        } catch (Exception e) {
            return  null;
        }

//        // 通过 Delaunay 三角化算法生成的
//        GeometryFactory gf = new GeometryFactory();
//        MultiPoint mp = gf.createMultiPoint(coords);
//
//        ConformingDelaunayTriangulationBuilder builder = new ConformingDelaunayTriangulationBuilder();
//
//        builder.setSites(mp);
//        //实际为GeometryCollection（组成的geometry紧密相连）
//        Geometry ts = builder.getTriangles(gf);
//        System.out.println(ts.toString());
//
//        //以0的距离进行缓冲（因为各多边形两两共边），生成一个多边形
//        //此时则将点云构造成了多边形
//        Geometry union = ts.buffer(0.001);

//        return union;


    }


}
