package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import com.sf.gis.java.base.util.DateUtil
import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel
import utils.SparkUtil

/**
  * GIS-RSS-PNS：供应商路桥费接入计算
  * 需求方：杨汶铭（ft80006323） 需求id:  2070253  GIS-RSS-ETA:【线路基础服务】标准路桥费_V1.1_01417347_徐游飞
  *
  * @author guofangcai（01420395）
  * 任务ID： 875818
  * 任务名称：供应商路桥费接入车辆信息计算
  */

//骑行超速轨迹辨识
object EtaStdLineTollVehicle extends DataSourceCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    var inc_day  = DateUtil.getCurrentDate("yyyyMMdd")
    var isAllData  = true
    if(args.size > 0){
      inc_day  = args(0)
      isAllData = false
    }
    val sparkSession = SparkUtil.getSparkSession(appName)
    val sparkConf = sparkSession.sparkContext.getConf
    sparkConf.set("spark.sql.hive.convertMetastoreParquet", "false")

    start(sparkSession, inc_day, isAllData)
    sparkSession.stop()
  }

  /**
    *  根据日期获取对应的所有数据
    * @param session
    * @param str
    * @param bool
    */

  import org.apache.spark.sql.functions._
  def start(spark: SparkSession, inc_day: String, isAllData: Boolean)={

    var sql  = ""

    if (isAllData){
      sql = s"""
              |select plate,vehicle_type,plate_color from dm_gis.dm_eta_ctfo_record_dtl_di
              | where  vehicle_type >0
              | group by plate,vehicle_type,plate_color
            """.stripMargin
    }else{
      sql =s"""
              |select plate,vehicle_type,plate_color from dm_gis.dm_eta_ctfo_record_dtl_di
              |where inc_day ='${inc_day}'
              |and  vehicle_type >0  group by plate,vehicle_type,plate_color
      """.stripMargin
    }
    import spark.implicits._

    logger.error(sql)
    //获取车辆类型第一个
    val dm_eta_task_tolls_record_dtl_di_Df =  spark.sql(sql)

        .withColumn("vehicle_type_1", substring('vehicle_type,-1,1))

    val resultDF =  dm_eta_task_tolls_record_dtl_di_Df
      .withColumn("vehicle_name",
        when('vehicle_type_1==="1" or 'vehicle_type_1==="2" ,"2轴车")
          .when('vehicle_type_1==="3","3轴车")
          .when('vehicle_type_1==="4","4轴车")
          .when('vehicle_type_1==="5","5轴车")
          .when('vehicle_type_1==="6","6轴车"))
      .withColumn("plate_color_name",
        when('plate_color==="0","蓝色")
          .when('plate_color==="1","黄色")
          .when('plate_color==="2","黑色")
          .when('plate_color==="3","白色")
          .when('plate_color==="4","渐变绿色")
          .when('plate_color==="5","黄绿双拼色")
          .when('plate_color==="6","蓝白渐变色")
          .when('plate_color==="7","临时拍照")
          .when('plate_color==="11","绿色")
          .when('plate_color==="12","红色")
      )
      .withColumn("axis",
        when('vehicle_type_1==="1" or 'vehicle_type_1==="2" ,"2")
          .when('vehicle_type_1==="3","3")
          .when('vehicle_type_1==="4","4")
          .when('vehicle_type_1==="5","5")
          .when('vehicle_type_1==="6","6")
      )

      .withColumn("weight",
        when('vehicle_type_1==="1","3.6")
          .when('vehicle_type_1==="2","5.4")
          .when('vehicle_type_1==="3","14")
          .when('vehicle_type_1==="4","18")
          .when('vehicle_type_1==="5","27")
          .when('vehicle_type_1==="6","30")
      )
      .withColumn("length",
        when('vehicle_type_1==="1","3.6")
          .when('vehicle_type_1==="2","7.2")
          .when('vehicle_type_1==="3","9.6")
          .when('vehicle_type_1==="4","9.6")
          .when('vehicle_type_1==="5","9.9")
          .when('vehicle_type_1==="6","12.7")
      )
      .withColumn("load",lit("") )
      .withColumn("height",lit(""))
      .withColumn("type",
        when(('vehicle_type.cast("int")/10).cast("int") ===0,"客车")
          .when(('vehicle_type.cast("int")/10).cast("int") ===1,"货车")
          .when(('vehicle_type.cast("int")/10).cast("int") ===2,"专项车")
      )

      .withColumn("category",
        when('vehicle_type_1==="1","一类")
          .when('vehicle_type_1==="2","二类")
          .when('vehicle_type_1==="3","三类")
          .when('vehicle_type_1==="4","四类")
          .when('vehicle_type_1==="5","五类")
          .when('vehicle_type_1==="6","六类")
      )


    resultDF.show(1, false)

    //全量去重

    val exceptResultDf = resultDF.drop("vehicle_type_1")
//    val resultDF1= exceptResultDf.union(eta_std_line_toll_vehicle_DF)

    //存在一个车牌多条数据去重操作,
   val resultDF2 =  exceptResultDf.withColumn("count",count(lit(1))over(Window.partitionBy('plate)))

    //获取牵引车
    val resultDF3 =  resultDF2.filter('count>1)
      .withColumn("plate",'plate)
      .withColumn("vehicle_type",lit(""))
      .withColumn("vehicle_name",lit(""))
      .withColumn("plate_color",lit(""))
      .withColumn("plate_color_name",lit(""))
      .withColumn("axis",lit(""))
      .withColumn("weight",lit(""))
      .withColumn("length",lit(""))
      .withColumn("load",lit(""))
      .withColumn("height",lit(""))
      .withColumn("type",lit("牵引车"))
      .withColumn("category",lit(""))

    val resultDF4 = resultDF2.filter('count===1).union(resultDF3.distinct()).drop("count")



    val eta_std_line_toll_vehicle_DF = spark.sql("""select  *  from  dm_gis.eta_std_line_toll_vehicle """)
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("数据量 :" + eta_std_line_toll_vehicle_DF.count())

    val resultDF5= eta_std_line_toll_vehicle_DF.join(resultDF4,Seq("plate"),"left")
      .filter(resultDF4("plate").isNull)
      .select(eta_std_line_toll_vehicle_DF("plate").as("plate")
      , eta_std_line_toll_vehicle_DF("vehicle_type").as("vehicle_type")
        , eta_std_line_toll_vehicle_DF("vehicle_name").as("vehicle_name")
        , eta_std_line_toll_vehicle_DF("plate_color").as("plate_color")
        , eta_std_line_toll_vehicle_DF("plate_color_name").as("plate_color_name")
        , eta_std_line_toll_vehicle_DF("axis").as("axis")
        , eta_std_line_toll_vehicle_DF("weight").as("weight")
        , eta_std_line_toll_vehicle_DF("length").as("length")
        , eta_std_line_toll_vehicle_DF("load").as("load")
        , eta_std_line_toll_vehicle_DF("height").as("height")
        , eta_std_line_toll_vehicle_DF("type").as("type")
        , eta_std_line_toll_vehicle_DF("category").as("category")
      )

    val resultDF6= eta_std_line_toll_vehicle_DF.union(resultDF4).distinct().coalesce(1)
    // 结果表保存至hive
    val cols_dtl =spark.sql("""select * from dm_gis.eta_std_line_toll_vehicle limit 0""").schema.map(_.name).map(col)
//    resultDF6.select(cols_dtl: _*).write.mode(SaveMode.Overwrite).saveAsTable("dm_gis.eta_std_line_toll_vehicle").
    spark.catalog.refreshTable("dm_gis.eta_std_line_toll_vehicle")
    writeToHiveNoP(spark,resultDF6.select(cols_dtl: _*),"dm_gis.eta_std_line_toll_vehicle")
  }



}
