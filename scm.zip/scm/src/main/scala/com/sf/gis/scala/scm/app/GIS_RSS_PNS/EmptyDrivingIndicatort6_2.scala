package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.SparkBuilder


/**
  *@author 01420395
  *@DESCRIPTION
  *轨迹缺失表 需求ID 1842890   GIS-RSS-PNS：【价值线路】空驶指标监控需求_V1.0
  *任务id： 771182
  *@create 2023/06/14
  */
object EmptyDrivingIndicatort6_2 extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    // 6_2
    val gis_eta_jiazhi_cost_stat_new_detail2_ksDF1 = gis_eta_jiazhi_cost_stat_new_detail2_ks(inc_day, spark)

    logger.error(gis_eta_jiazhi_cost_stat_new_detail2_ksDF1.count())

    import org.apache.spark.sql.functions._
    import spark.implicits._

    val gis_eta_jiazhi_cost_stat_new_detail2_ksDF =  gis_eta_jiazhi_cost_stat_new_detail2_ksDF1
      .withColumn("conduct_type", when('conduct_type === "1",lit("已执行")).otherwise(lit("未执行")))
      .withColumn("is_run_ontime", when('is_run_ontime === "0",lit("准点")).otherwise(lit("超时")))
      .withColumn("online_flag", when('online_date === "20230101",lit("2022年上线"))
        .otherwise(concat(substring('online_date,0,4),lit("年"),substring('online_date,5,2),lit("月上线"))))


    val resultDF1 =  gis_eta_jiazhi_cost_stat_new_detail2_ksDF
      .withColumn("fuel_prices",'fuel_prices)
      .withColumn("update_uint_fuel",'update_uint_fuel)
      .withColumn("diff_distm_final",'diff_miles_mean_adjust)
      .withColumn("diff_rfm_final",'diff_road_fee_mean_adjust)
      .withColumn("re_rfm_final",'re_road_fee_mean_adjust)
      .withColumn("re_dist_final",'re_miles_mean_adjust)
      .withColumn("rfm_final",'road_fee_mean_adjust)
      .withColumn("distm_final",'miles_mean_adjust)


    val resultDF2 =resultDF1
      .withColumn("diff_fcm_final",'diff_distm_final*'fuel_prices*'update_uint_fuel/100)
      .withColumn("re_fcm_final",'re_dist_final*'fuel_prices*'update_uint_fuel/100)
      .withColumn("fcm_final",'distm_final*'fuel_prices*'update_uint_fuel/100)

    val resultDF =resultDF2
      .withColumn("diff_scm_final",'diff_fcm_final + 'diff_rfm_final)
      .withColumn("re_scm_final",'re_fcm_final+'re_rfm_final)
      .withColumn("scm_final",'fcm_final+'rfm_final)

      .select('task_area_code,'task_inc_day,'task_id,'task_subid,'conduct_type,
        'is_run_ontime,'line_code,'carrier_name,'start_dept,'end_dept,'vehicle_serial,'vehicle_type,
        'mload,'axls_number,'rt_dist,'online_date,'online_flag,'diff_sum_cost_mean,
        'diff_road_fee_mean,'diff_fuel_cost_mean,'diff_miles_mean,
        'sum_cost_mean,'road_fee_mean,'fuel_cost_mean,'miles_mean,'re_sum_cost_mean,'re_road_fee_mean,
        're_fuel_cost_mean,'re_miles_mean,'diff_sum_cost_mean_adjust,'diff_road_fee_mean_adjust,
        'diff_fuel_cost_mean_adjust,'diff_miles_mean_adjust,'sum_cost_mean_adjust,
        'road_fee_mean_adjust,'fuel_cost_mean_adjust,'miles_mean_adjust,'re_sum_cost_mean_adjust,
        're_road_fee_mean_adjust,'re_fuel_cost_mean_adjust,'re_miles_mean_adjust,'fuel_prices,'update_uint_fuel,
        'diff_scm_final,'diff_rfm_final,'diff_fcm_final,'diff_distm_final,'re_scm_final,'re_rfm_final,
        're_fcm_final,'re_dist_final,'scm_final,'rfm_final,'fcm_final,'distm_final,
        'online_before_exe,'online_before_task_num,'inc_day)


    writeToHive(spark, resultDF, Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_stat_new_detail2_ks")

  }

  def gis_eta_jiazhi_cost_stat_new_detail2_ks(inc_day:String,spark:SparkSession)={

    val gis_eta_jiazhi_task_ks_Sql =
      s"""
         |select task_area_code
         |,task_id
         |,task_subid
         |,sort_num
         |,start_dept
         |,end_dept
         |,start_type
         |,end_type
         |,line_code
         |,linevehicle
         |,grd1
         |,std_id
         |,vehicle_serial
         |,conduct_type
         |,is_run_ontime
         |,start_longitude
         |,start_latitude
         |,end_longitude
         |,end_latitude
         |,rt_dist
         |,toll_charge
         |,is_stop
         |,stop_over_zone_code
         |,transoport_level
         |,carrier_type
         |,carrier_name
         |,vehicle_type
         |,axls_number
         |,length
         |,weight
         |,mload
         |,length_weight
         |,miles
         |,road_fee
         |,fuel_cost
         |,sum_cost
         |,error_type
         |,std_id_jz
         |,std_id_jz_time
         |,add_reason
         |,task_inc_day
         |,inc_day
         |from  dm_gis.gis_eta_jiazhi_task_ks
         |where  inc_day  = '${inc_day}'
      """.stripMargin

    import org.apache.spark.sql.functions._
    import spark.implicits._
    val gis_eta_jiazhi_task_ksDF = spark.sql(gis_eta_jiazhi_task_ks_Sql)
      .withColumn("online_date",when(length('std_id_jz_time)>8,
        from_unixtime(unix_timestamp('std_id_jz_time, "yyyy-MM-dd HH:mm:ss"), "yyyyMMdd")).otherwise('std_id_jz_time))



    val gis_eta_jiazhi_cost_stat_new_ks_Sql =
      s"""
         |select task_area_code
         |,line_code
         |,vehicle_type
         |,inc_day
         |,online_date
         |,miles
         |,road_fee
         |,fuel_cost
         |,sum_cost
         |,re_road_fee
         |,re_miles
         |,re_fuel_cost
         |,re_sum_cost
         |,diff_road_fee
         |,diff_fuel_cost
         |,diff_miles
         |,diff_sum_cost
         |,diff_cost_flag
         |,num
         |,road_fee_mean
         |,miles_mean
         |,fuel_cost_mean
         |,sum_cost_mean
         |,re_road_fee_mean
         |,re_miles_mean
         |,re_fuel_cost_mean
         |,re_sum_cost_mean
         |,diff_road_fee_mean
         |,diff_fuel_cost_mean
         |,diff_miles_mean
         |,diff_sum_cost_mean
         |from  dm_gis.gis_eta_jiazhi_cost_stat_new_ks
         |where  inc_day  = '${inc_day}'
         |and diff_cost_flag in('0','2')
         |and length(trim(online_date))>0 and online_date is not null and  online_date <> ' '
      """.stripMargin

    val gis_eta_jiazhi_cost_stat_new_ksDF = spark.sql(gis_eta_jiazhi_cost_stat_new_ks_Sql)

    val gis_eta_jiazhi_cost_stat_new_ks_Sql2 =
      s"""
         |select task_area_code
         |,line_code
         |,vehicle_type
         |,inc_day
         |,online_date
         |,road_fee_mean
         |,miles_mean
         |,fuel_cost_mean
         |,sum_cost_mean
         |,re_road_fee_mean
         |,re_miles_mean
         |,re_fuel_cost_mean
         |,re_sum_cost_mean
         |,diff_road_fee_mean
         |,diff_fuel_cost_mean
         |,diff_miles_mean
         |,diff_sum_cost_mean
         |from  dm_gis.gis_eta_jiazhi_cost_stat_new_ks
         |where  diff_cost_flag in('0','2')
         |and length(trim(online_date))>0 and online_date is not null and  online_date <> ' '
      """.stripMargin

    val gis_eta_jiazhi_cost_stat_new_ksDF2 = spark.sql(gis_eta_jiazhi_cost_stat_new_ks_Sql2)


    val groupIdMeanDF1 = gis_eta_jiazhi_task_ksDF.join(gis_eta_jiazhi_cost_stat_new_ksDF2,
      gis_eta_jiazhi_task_ksDF("line_code")===gis_eta_jiazhi_cost_stat_new_ksDF2("line_code")
        && gis_eta_jiazhi_task_ksDF("task_area_code")===gis_eta_jiazhi_cost_stat_new_ksDF2("task_area_code")
        && gis_eta_jiazhi_task_ksDF("vehicle_type")===gis_eta_jiazhi_cost_stat_new_ksDF2("vehicle_type")
        && gis_eta_jiazhi_task_ksDF("online_date")===gis_eta_jiazhi_cost_stat_new_ksDF2("online_date")
        && gis_eta_jiazhi_task_ksDF("inc_day")>=gis_eta_jiazhi_cost_stat_new_ksDF2("inc_day")
        && gis_eta_jiazhi_task_ksDF("online_date")<=gis_eta_jiazhi_cost_stat_new_ksDF2("inc_day")
      ,"inner")

      .select(gis_eta_jiazhi_task_ksDF("line_code"),gis_eta_jiazhi_task_ksDF("task_area_code"),
        gis_eta_jiazhi_task_ksDF("vehicle_type"),gis_eta_jiazhi_task_ksDF("online_date"),
        'diff_sum_cost_mean,'diff_road_fee_mean,'diff_fuel_cost_mean,'diff_miles_mean,'sum_cost_mean,
        'road_fee_mean,'fuel_cost_mean,'miles_mean,'re_sum_cost_mean,'re_road_fee_mean,'re_road_fee_mean,
        're_fuel_cost_mean,'re_miles_mean)


    groupIdMeanDF1.show(1, false)


    val groupIdMeanDF = groupIdMeanDF1
      .groupBy("line_code","task_area_code","vehicle_type","online_date")
      .agg(
        avg('diff_sum_cost_mean).as("diff_sum_cost_mean_adjust"),
        avg('diff_road_fee_mean).as("diff_road_fee_mean_adjust"),
        avg('diff_fuel_cost_mean).as("diff_fuel_cost_mean_adjust"),
        avg('diff_miles_mean).as("diff_miles_mean_adjust"),
        avg('sum_cost_mean).as("sum_cost_mean_adjust"),
        avg('road_fee_mean).as("road_fee_mean_adjust"),
        avg('fuel_cost_mean).as("fuel_cost_mean_adjust"),
        avg('miles_mean).as("miles_mean_adjust"),
        avg('re_sum_cost_mean).as("re_sum_cost_mean_adjust"),
        avg('re_road_fee_mean).as("re_road_fee_mean_adjust"),
        avg('re_fuel_cost_mean).as("re_fuel_cost_mean_adjust"),
        avg('re_miles_mean).as("re_miles_mean_adjust")
      )


    val gis_fule_pricesDF  = spark.sql(
      s"""
         |select fuel_prices, inc_day from  dm_gis.gis_fule_prices where inc_day ='${inc_day}'
         |
      """.stripMargin)


    val gis_vehicle_fuleDF  = spark.sql(
      s"""
         |select vehicle_serial,update_uint_fuel as update_uint_fuel from  dm_gis.gis_vehicle_fule_stat where inc_day = '${inc_day}'
         |
      """.stripMargin)

    val resultDf  =   gis_eta_jiazhi_task_ksDF
      .join(gis_eta_jiazhi_cost_stat_new_ksDF, Seq("line_code","vehicle_type","online_date","task_area_code","inc_day"),"left")
      .join(groupIdMeanDF, Seq("line_code","vehicle_type","online_date","task_area_code"),"left")
      .join(gis_fule_pricesDF, Seq("inc_day"),"left")
      .join(gis_vehicle_fuleDF, Seq("vehicle_serial"),"left")


    //获取上线总数量
    val gis_eta_jiazhi_task_ks_Sql2 =
      s"""
         |select task_area_code
         |,task_id
         |,task_subid
         |,sort_num
         |,start_dept
         |,end_dept
         |,start_type
         |,end_type
         |,line_code
         |,linevehicle
         |,grd1
         |,std_id
         |,vehicle_serial
         |,conduct_type
         |,is_run_ontime
         |,start_longitude
         |,start_latitude
         |,end_longitude
         |,end_latitude
         |,rt_dist
         |,toll_charge
         |,is_stop
         |,stop_over_zone_code
         |,transoport_level
         |,carrier_type
         |,carrier_name
         |,vehicle_type
         |,axls_number
         |,length
         |,weight
         |,mload
         |,length_weight
         |,miles
         |,road_fee
         |,fuel_cost
         |,sum_cost
         |,error_type
         |,std_id_jz
         |,std_id_jz_time
         |,add_reason
         |,task_inc_day
         |,inc_day
         |from  dm_gis.gis_eta_jiazhi_task_ks
      """.stripMargin



    import org.apache.spark.sql.functions._
    import spark.implicits._
    val gis_eta_jiazhi_task_ksDF1 = spark.sql(gis_eta_jiazhi_task_ks_Sql2)

    val taskIdCountDF5 = gis_eta_jiazhi_task_ksDF1
      .join(resultDf,gis_eta_jiazhi_task_ksDF1("line_code")=== resultDf("line_code")
        &&gis_eta_jiazhi_task_ksDF1("vehicle_type")=== resultDf("vehicle_type")
        && gis_eta_jiazhi_task_ksDF1("task_area_code")=== resultDf("task_area_code")
        && gis_eta_jiazhi_task_ksDF1("task_inc_day")<= resultDf("online_date")
        && gis_eta_jiazhi_task_ksDF1("task_inc_day")>= from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('online_date,"yyyyMMdd"),"yyyy-MM-dd"),61),"yyyy-MM-dd"),"yyyyMMdd")
        && gis_eta_jiazhi_task_ksDF1("inc_day")<= resultDf("online_date")
        && gis_eta_jiazhi_task_ksDF1("inc_day")>= from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('online_date,"yyyyMMdd"),"yyyy-MM-dd"),61),"yyyy-MM-dd"),"yyyyMMdd")
        ,"inner")
      .select(gis_eta_jiazhi_task_ksDF1("line_code"),gis_eta_jiazhi_task_ksDF1("vehicle_type"),
        gis_eta_jiazhi_task_ksDF1("task_area_code"),gis_eta_jiazhi_task_ksDF1("task_subid"))

    logger.error(taskIdCountDF5.filter('line_code ==="010BBA_010WE" && 'task_area_code  === "010Y").distinct().count())

    taskIdCountDF5.filter('line_code ==="010BBA_010WE" && 'task_area_code  === "010Y").distinct()
      .show(1000, false)


      val taskIdCountDF1 = taskIdCountDF5
      .groupBy("line_code","vehicle_type","task_area_code")
      .agg(countDistinct(gis_eta_jiazhi_task_ksDF1("task_subid")).as("online_before_task_num"))

    logger.error(taskIdCountDF1.count)


    resultDf
      .filter('line_code ==="010BBA_010WE" && 'task_area_code  === "010Y")
      .withColumn("test",from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('online_date,"yyyyMMdd"),"yyyy-MM-dd"),61),"yyyy-MM-dd"),"yyyyMMdd") )
      .select ('test, 'online_date).show (100, false)

    val taskIdCountDF2 = gis_eta_jiazhi_task_ksDF1
      .join(resultDf,gis_eta_jiazhi_task_ksDF1("line_code")=== resultDf("line_code")
        &&gis_eta_jiazhi_task_ksDF1("vehicle_type")=== resultDf("vehicle_type")
        && gis_eta_jiazhi_task_ksDF1("task_area_code")=== resultDf("task_area_code")
        && gis_eta_jiazhi_task_ksDF1("task_inc_day")<= resultDf("online_date")
        && gis_eta_jiazhi_task_ksDF1("task_inc_day")>= from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('online_date,"yyyyMMdd"),"yyyy-MM-dd"),61),"yyyy-MM-dd"),"yyyyMMdd")
        && gis_eta_jiazhi_task_ksDF1("conduct_type") === "1"
        && gis_eta_jiazhi_task_ksDF1("inc_day")<= resultDf("online_date")
        && gis_eta_jiazhi_task_ksDF1("inc_day")>= from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('online_date,"yyyyMMdd"),"yyyy-MM-dd"),61),"yyyy-MM-dd"),"yyyyMMdd")
        ,"inner")
      .select(gis_eta_jiazhi_task_ksDF1("line_code"),gis_eta_jiazhi_task_ksDF1("vehicle_type"),
        gis_eta_jiazhi_task_ksDF1("task_area_code"),gis_eta_jiazhi_task_ksDF1("task_subid"))
      .groupBy("line_code","vehicle_type","task_area_code")
      .agg(countDistinct(gis_eta_jiazhi_task_ksDF1("task_subid")).as("online_before_exe"))

    logger.error(taskIdCountDF2.count)
    taskIdCountDF2.show(1,false)

    val resultDf1 = resultDf
      .join(taskIdCountDF1,Seq("line_code","vehicle_type","task_area_code"), "left")
      .join(taskIdCountDF2,Seq("line_code","vehicle_type","task_area_code"), "left")


    resultDf1.filter('online_before_task_num isNotNull).show(1, false)

    resultDf1

  }




}
