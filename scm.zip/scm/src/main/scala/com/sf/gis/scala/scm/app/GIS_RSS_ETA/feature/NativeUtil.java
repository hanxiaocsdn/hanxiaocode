package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

import org.apache.spark.SparkContext;
import org.apache.spark.SparkFiles;

public class NativeUtil {

    static boolean g_init_flag = false;

    public static void InitFile(SparkContext context) {
        context.addFile("hdfs://sfbdp1/user/01420395/upload/jar/libmaputil.so");
        context.addJar("hdfs://sfbdp1/user/01420395/upload/jar/com.sf.map.utils.jar");
    }
    public static void LoadLibray() {

        if (!g_init_flag) {
            g_init_flag = true;
            String soPath = SparkFiles.get("libmaputil.so");
            soPath = soPath.replace("libmaputil.so", "");
            System.setProperty("jna.library.path", soPath);
            System.loadLibrary("maputil");
        }
    }


}
