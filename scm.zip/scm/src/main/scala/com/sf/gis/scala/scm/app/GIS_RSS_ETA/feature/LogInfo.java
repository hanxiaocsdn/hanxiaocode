package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

public class LogInfo {
    public String dataTime = "";
    public String reqId = "";
    public String eta_type = "";
    public String sub_type = "";
    public String taskId = "";
    public String lineCode =  "";
    public String srcZoneId =  "";
    public String destZoneId =  "";
    public String plate =  "";
    public String requestTime =  "";
    public String validTime =  "";
    public String srcZone_x =  "";
    public String srcZone_y =  "";
    public String eta_srcZoneCoordinate =  "";
    public String destZone_x =  "";
    public String destZone_y =  "";
    public String eta_destZoneCoordinate =  "";
    public String x =  "";
    public String y =  "";
    public String eta_act_point =  "";
    public String eta_act_time =  "";
    public String points =  "";

    public String etaMachineTime = "";
    public String etaMachineDist = "";
    public String arriveTime = "";

    public String etaType="";

    public String etaMachineFeature =  "";
    public String group_task =  "";
    public String destZone_x_round =  "";
    public String destZone_y_round=  "";
    public String gp = "";
    
    public LogInfo(){
        
    }
}
