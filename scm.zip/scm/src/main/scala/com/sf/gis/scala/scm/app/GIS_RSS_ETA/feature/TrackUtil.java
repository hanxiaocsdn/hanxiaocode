package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;


public class TrackUtil {

    public static double distance_meters(double x1, double y1, double x2, double y2){
        double dx = x2 - x1;
        double dy = y2 - y1;
        double sx = dx * Math.cos(y1 * 0.01745329252f);
        return Math.sqrt(sx * sx + dy * dy) * 111195.0;
    }

    public static class TrackPoint implements Comparable<TrackPoint>{
        public TrackPoint(double x_, double y_, int t_){
            x = x_;
            y = y_;
            tm = t_;
        }
        //位置 经度
        public double x;
        //位置 纬度
        public double y;
        //时间
        public int tm;

        @Override
        public int compareTo(TrackPoint o) {
            return this.tm - o.tm;
        }
    }
    public static class StayInfo {
        public StayInfo(double x_, double y_, int st_, int et_){
            x = x_;
            y = y_;
            stime = st_;
            etime = et_;
        }
        //位置 经度
        public double x;
        //位置 纬度
        public double y;
        //开始时间
        public int stime;
        //结束时间
        public int etime;
    }
    public static ArrayList<StayInfo> getStays(ArrayList<TrackPoint> tracks){
        Collections.sort(tracks);
        ArrayList<StayInfo> array = new ArrayList<>();
        if(tracks.isEmpty())
            return array;

        TrackPoint p0 = tracks.get(0);
        StayInfo last = null;
        for (int i = 1; i < tracks.size(); i++) {
            TrackPoint p1 = tracks.get(i);
            double dist = distance_meters(p0.x, p0.y, p1.x, p1.y);
            int diff = p1.tm - p0.tm;
            double speed = 3.6* dist / diff;
            if (speed < 5 && dist < 100)
            {
                if(last == null)
                {
                    last = new StayInfo(p1.x, p1.y, p0.tm, p1.tm);
                    // array.add(last);
                }
                else{
                    double last_dist = distance_meters(p0.x, p0.y, last.x, last.y);
                    int last_diff = p0.tm - last.etime;
                    if(last_diff < 60 || last_dist < 50){
                        last.etime = p1.tm;
                        last.x = p1.x;
                        last.y = p1.y;
                    }
                    else {
                        if((last.etime-last.stime)>1800){
                            array.add(last);
                        }
                        last = new StayInfo(p1.x, p1.y, p0.tm, p1.tm);
                    }
                }
            }
            else if(last != null) {
                int last_diff = p0.tm - last.etime;
                if (last_diff>600 && (last.etime-last.stime)>1800)
                {
                    array.add(last);
                    last = null;
                }
            }
            p0 = p1;
        }
        if(last!= null && (last.etime-last.stime)>1800){
            array.add(last);
        }
        // array.add(new StayInfo(tracks.get(0).x, tracks.get(0).y, tracks.size(),0));
        return array;
    }

}
