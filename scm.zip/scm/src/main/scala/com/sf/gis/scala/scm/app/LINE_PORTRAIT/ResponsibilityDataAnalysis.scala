package com.sf.gis.scala.scm.app.LINE_PORTRAIT

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, SparkUtil}
import common.DataSourceCommon
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import utils.{SparkBuilder, SparkUtils}

import scala.collection.mutable.ArrayBuffer

/**
 * @description: 线路画像定责数据解析需求说明;  需求ID: 2113078
 * @author 01420935 caiguofang
 * @date 20231121
 */
object ResponsibilityDataAnalysis extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  val tableName:String = "dm_gis.Responsibility_Data_Analysis"

  def execute(sparkSession: SparkSession, inc_day: String) = {

    val sourceSql  =
      s"""
         |select  * from  dm_gis.eta_std_line_recall_realtime2 where  inc_day ='${inc_day}'
         |""".stripMargin


    val sourceDF = sparkSession.sql(sourceSql)

    val sourceJson = SparkUtils.getRowToJson(sourceDF)

    val resultDF =  sourceJson.map(row  => {JSON.parseObject(row.getString("info"))})flatMap(row  => {

      val task_id  = row.getString("task_id")

      //子任务拆分
      val task_subids  = row.getString("task_subid")
      val task_subid_array = task_subids.split("\\|")


      val roadClosures  =  row.getJSONArray("roadClosure")

      val youngduDetailInfos  = row.getJSONArray("youngduDetailInfo")

      val report_description = row.getString("report_description")

      val stayInfoDetails = row.getJSONArray("stayInfoDetail")

      val congestion_time = row.getString("congestion_time")
      val highwaymileage  = row.getString("highwaymileage")
      val responsibility_reason  = row.getString("responsibility_reason")
      val line_code  = row.getString("line_code")
      val conduct_type_final  = row.getString("conduct_type_final")
      val conduct_type_final2  = row.getString("conduct_type_final2")
      val task_conduct_type  = row.getString("task_conduct_type")


      val  rows  = new ArrayBuffer[Row]()


      for( i <- 0.until(task_subid_array.length)){
        val task_subid =  task_subid_array(i)

        val roadClosure  =  roadClosures.getJSONObject(i)
        val is_closure = roadClosure.getString("is_closure")
        val closure_contime = roadClosure.getString("closure_contime")
        val jp_duration_sum = roadClosure.getString("jp_duration_sum")
        val std_duration_sum = roadClosure.getString("std_duration_sum")
        val jp_dr_length_sum = roadClosure.getString("jp_dr_length_sum")
        val std_dr_length_sum = roadClosure.getString("std_dr_length_sum")

        val youngduDetailInfo  =  youngduDetailInfos.getJSONObject(i)
        val yongdu_gd_len = youngduDetailInfo.getString("yongdu_gd_len")
        val yongdu_speed_avg_gd = youngduDetailInfo.getString("yongdu_speed_avg_gd")
        val yongdu_continue_tm = youngduDetailInfo.getString("yongdu_continue_tm")
        val yongdu_total_duration = youngduDetailInfo.getString("yongdu_total_duration")
        val disu_duration_exp = youngduDetailInfo.getString("disu_duration_exp")
        val events_S = youngduDetailInfo.getString("events_S")
        val events_L = youngduDetailInfo.getString("events_L")

        val stayInfoDetail = stayInfoDetails.getJSONObject(i)
        val stay_swid_length_total = stayInfoDetail.getString("stay_swid_length_total")
        val stay_swid_gd2 = stayInfoDetail.getString("stay_swid_gd2")
        val is_zhuguan = stayInfoDetail.getString("is_zhuguan")

        rows.append(Row(task_id,yongdu_gd_len,yongdu_speed_avg_gd,yongdu_continue_tm,yongdu_total_duration,disu_duration_exp,events_S,events_L,report_description
          ,is_closure,closure_contime,jp_duration_sum,std_duration_sum,jp_dr_length_sum,std_dr_length_sum,stay_swid_length_total,stay_swid_gd2,is_zhuguan
          ,congestion_time,highwaymileage,task_subid,responsibility_reason,line_code,conduct_type_final,conduct_type_final2,task_conduct_type))
      }
      rows
    })

    resultDF.foreach(println(_))

    val schema = StructType(List(
      StructField("task_id", StringType, true),
      StructField("yongdu_gd_len", StringType, true),
      StructField("yongdu_speed_avg_gd", StringType, true),
      StructField("yongdu_continue_tm", StringType, true),
      StructField("yongdu_total_duration", StringType, true),
      StructField("disu_duration_exp", StringType, true),
      StructField("events_S", StringType, true),
      StructField("events_L", StringType, true),
      StructField("report_description", StringType, true),
      StructField("is_closure", StringType, true),
      StructField("closure_contime", StringType, true),
      StructField("jp_duration_sum", StringType, true),
      StructField("std_duration_sum", StringType, true),
      StructField("jp_dr_length_sum", StringType, true),
      StructField("std_dr_length_sum", StringType, true),
      StructField("stay_swid_length_total", StringType, true),
      StructField("stay_swid_gd2", StringType, true),
      StructField("is_zhuguan", StringType, true),
      StructField("congestion_time", StringType, true),
      StructField("highwaymileage", StringType, true),
      StructField("task_subid", StringType, true),
      StructField("responsibility_reason", StringType, true),
      StructField("line_code", StringType, true),
      StructField("conduct_type_final", StringType, true),
      StructField("conduct_type_final2", StringType, true),
      StructField("task_conduct_type", StringType, true)
    ))


    val resultDF1= sparkSession.createDataFrame(resultDF,schema).withColumn("inc_day",lit(inc_day))

    resultDF1.show(1, false)
    writeToHive(sparkSession,resultDF1,Seq("inc_day"),tableName)

  }



  def main(args: Array[String]): Unit = {
    val inc_day = args(0)

    val spark = SparkBuilder.initSpark(className)

    logger.error("++++++++  任务开始   ++++")
    execute(spark, inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }




}
