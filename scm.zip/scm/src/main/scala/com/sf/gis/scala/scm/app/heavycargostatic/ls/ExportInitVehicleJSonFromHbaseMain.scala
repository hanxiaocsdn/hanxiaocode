package com.sf.gis.scala.scm.app.heavycargostatic.ls

import common.DataSourceCommon
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import utils.SparkBuilder

/**
  * @description: 全国重货精友接口返回信息同步到hive中 需求ID: 1720287 任务id
  * @author 01420935 caiguofang
  * @date 2023/04/10 10:36
  */
object ExportInitVehicleJSonFromHbaseMain extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
//  val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
  val zkPort = "2181"
  val zkParent = "/hbase"


  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val hbaseConf  = HBaseConfiguration.create()
    hbaseConf.set("zookeeper.znode.parent", zkParent)
    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")


    val modelVehicleDF = exportInitVehicleJSONFromHbase(spark,hbaseConf)

    writeToHiveNoPWithDB(spark,modelVehicleDF,"dm_gis.insurance_vehicle_json_original")

    spark.close()
  }

  /**
    * 获取现有的车型数据
    * @param spark
    * @param hbaseConf
    * @return
    */
  def exportInitVehicleJSONFromHbase(spark: SparkSession, hbaseConf: Configuration):DataFrame={

    //获取不匹配车型数据
    val hBaseTblName = "gis:insurance_vehicle_json_original"
    hbaseConf.set(TableInputFormat.INPUT_TABLE, hBaseTblName)

    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])

    val vehicleBaseDf = hbaseTblRdd.map(row => {
      val result = row._2
      val id  = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("id")))
      val vin = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vin")))
      val is_success = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("is_success")))
      val jy_json_str = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("jy_json_str")))
      val create_time = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("create_time")))

      val temList  = List(id,vin,is_success,jy_json_str,create_time)

      Row.fromSeq(temList)

    })
    // 转成df
    val hBaseSchame =StructType(
      List(
        StructField("id", StringType, true)
        ,StructField("vin", StringType, true)
        ,StructField("is_success", StringType, true)
        ,StructField("jy_json_str", StringType, true)
        ,StructField("create_time", StringType, true)
      )
    )
    val vehicleDf =  spark.createDataFrame(vehicleBaseDf, hBaseSchame)

    //车型计算逻辑
    import spark.implicits._
    val resultDF = vehicleDf
      .select('id.cast("string").as("id"),
        'vin.cast("string").as("vin"),
        'is_success.cast("string").as("is_success"),
        'jy_json_str.cast("string").as("jy_json_str"),
        'create_time.cast("string").as("create_time")
      )

    logger.error("读取 hbase 精友json数据 总条数 "+resultDF.count())

    resultDF
  }

}
