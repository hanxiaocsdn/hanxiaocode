package com.sf.gis.scala.scm.app.jysd

import java.util.Date
import com.sf.gis.java.scm.Utils.Rarefy.RarefyService
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.java.scm.pojo.Dot
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DateTimeUtil, JSONUtils, SparkUtils}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer


/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/10/25
*/



object experienceSpeedEtaCalOnline {

  @transient lazy val logger: Logger = Logger.getLogger(experienceSpeedEtaCalOnline.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  //测试
  //  val fixUrl = "http://10.246.162.18:8080/roadcost"
  //  val fixUrl = "http://10.216.22.140:54321/roadcost"

  val fixUrl = "http://gis-int2.int.sfdc.com.cn:1080/lssrectify/api/roadcost"

  val weekFileNameMap = new mutable.HashMap[Int,String]()
  weekFileNameMap.put(1,"mon")
  weekFileNameMap.put(1,"tue")
  weekFileNameMap.put(1,"wed")
  weekFileNameMap.put(1,"thu")
  weekFileNameMap.put(1,"fri")
  weekFileNameMap.put(1,"sat")
  weekFileNameMap.put(1,"sun")




  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val end_day = args(1)

    start(inc_day, end_day)

  }


  // 增加超过5000点过滤逻辑

  def rarefyCal(sourceRdd2: RDD[JSONObject]) = {

    val calSourceRdd = sourceRdd2.map(x => {

      val un = x.getString("un")
      //按照un进行分组
      (un,x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).persist(StorageLevel.DISK_ONLY)


    val calRarefyCalRdd = calSourceRdd
      .filter(x => {
        val list = x._2
        list.size > 2000
      }).flatMap(x => {

      val list = x._2.toList
      //在此进行tm升序排序
      val listSort = list.sortBy(obj => {
        val tm = obj.getString("tm")
        tm
      })
      val listNew:java.util.List[Dot] = new java.util.ArrayList[Dot]()
      val dots = listSort

      (0 to dots.size-1).foreach(i=>{
        val p = dots(i).asInstanceOf[JSONObject]
        val dot = new Dot()
        dot.x = p.getDouble("zx")
        dot.y = p.getDouble("zy")
        listNew.add(dot)
      })

      //      val retain = RarefyService.douglasPeucker(listNew,0.00000005)
      val retain = RarefyService.douglasPeucker(listNew,0.05)

      //      val retain = RarefyService.douglasPeucker(listNew,0.005)
      val lest = retain.toArray()
      val tracks = new ArrayBuffer[JSONObject]()
      (0 to dots.size-1 by 3).foreach(i=>{
        if(lest.contains(i))
          tracks.append(dots(i))
      })

      tracks
    })


    val calUnRarefyRdd = calSourceRdd.filter(x => {
      val list = x._2
      list.size <= 2000
    }).flatMap(_._2)
    logger.error("未抽稀数据量为：" + calUnRarefyRdd.count())

    val calTotalSourceRdd = calRarefyCalRdd.union(calUnRarefyRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("rarefyCal的数据量为：" + calTotalSourceRdd.count())
    calSourceRdd.unpersist()

    calTotalSourceRdd

  }

  def getSourceData(spark: SparkSession, inc_day: String): RDD[JSONObject] = {

    val sourceSql =
      s"""
         |select
         |   un,tm,zx,zy
         |from
         |(
         |    select un,tm,zx,zy,row_number() over (partition by un,tm order by zx) rn
         |    from
         |       dm_gis.esg_gis_loc_trajectory
         |    where
         |    inc_day='${inc_day}'
         |    and
         |    ak != 1
         |) t1
         |where
         |    t1.rn = 1
         |union all
         |select
         |    carno as un,tm,x as zx,y as zy
         |from
         |(
         |    select carno,tm,x,y,row_number() over (partition by carno,tm order by x) rn
         |    from
         |       dm_gis.gis_rss_eta_navi_track_flatmap
         |    where
         |    inc_day='${inc_day}'
         |    and
         |    ak = '336'
         |) t2
         |where
         |    t2.rn = 1
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)


    val sourceRdd = SparkUtils.getRowToJson(sourceDf,1000)
    sourceRdd

  }


  def calEtaTracks(spark: SparkSession, inc_day: String, sourceRdd: RDD[JSONObject]) = {


    val schemaEtaTracksRdd = sourceRdd.map(x => {

      val un = JSONUtils.getJsonValue(x, "un", "")

      (un, x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {

        val un = x._1
        val list = x._2
        val group_tm = list.toArray.map(x => {
          val json = x.asInstanceOf[JSONObject]
          val tm = json.getString("tm")
          (tm, json)
        }).toStream.sortBy(_._1)
        val tracks = new JSONArray()

        group_tm.zipWithIndex.toArray.map(x => {
          val joTracks = new JSONObject()
          val trajJson = x._1._2.asInstanceOf[JSONObject]
          val index = x._2.asInstanceOf[Int]

          val tm = JSONUtils.getJsonValueLong(trajJson, "tm", 0)
          val zx = JSONUtils.getJsonValueDouble(trajJson, "zx", 0)
          val zy = JSONUtils.getJsonValueDouble(trajJson, "zy", 0)

          joTracks.put("time", tm)
          joTracks.put("x", zx)
          joTracks.put("y", zy)
          tracks.add(joTracks)
        })
        val joPost = new JSONObject()
        joPost.put("ak", "e365c6a601124a6b9b9526c81ffe3776")
        joPost.put("link_speed", 1)
        joPost.put("tracks", tracks)
        joPost.put("un", un)
        joPost.put("compress", 1)
        joPost
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)


    // TODO: 待测试rangePartitioner性能  排序的目的是啥 ？？？？？？？
    logger.error("schemaEtaTracksRdd3的数据量为：" + schemaEtaTracksRdd.count())
    schemaEtaTracksRdd
  }


  /**
    * 分时间段接口返回解析
    *
    * @param x
    * @return
    */

  def calEtaTracksRdd(x: JSONObject): JSONObject = {

    val un_ak = x.getString("un")

    val fixResponse = SparkUtils.doPost(fixUrl,x,logger,"e365c6a601124a6b9b9526c81ffe3776")
    val fixResponseParse = try {
      println("当前处理车牌为：" + un_ak)
      JSON.parseObject(fixResponse)
    } catch {
      case e: Exception =>
        val jo = new JSONObject()
        jo.put("err", e.toString)
        jo
    }
    fixResponseParse.put("un",un_ak)
    if (fixResponse.size < 1000) fixResponseParse.put("req",x.toJSONString)

    fixResponseParse

  }


  def saveToTrackTable(spark: SparkSession, inc_day: String, etaTracksRdd: RDD[JSONObject]) = {

    import org.apache.spark.sql.functions._
    import spark.implicits._


    //删除分区数据
    val sql = s"select 1 from dm_gis.eta_experience_speed_tracks_fix_info2  where  inc_day  = '${inc_day}' limit 1"
    val count = spark.sql(sql).count()
    if(count>0){
      spark.sql(s"alter table  dm_gis.eta_experience_speed_tracks_fix_info2 drop partition(inc_day ='${inc_day}')")
    }

    etaTracksRdd.map(x => {
      val un = x.getString("un")
      var req = x.getString("req")
      x.remove("un")
      x.remove("req")

      if (x.toJSONString().size > 1000) req = ""
      (un,req,x.toJSONString)
    }).repartition(500)
      .toDF("un","req","info")
      .withColumn("inc_day", lit(inc_day))
      .write.mode(SaveMode.Overwrite)
      .insertInto("dm_gis.eta_experience_speed_tracks_fix_info2")


  }



  /**
    * 解析不同类型的接口返回结果
    * @param getFixSourceRdd
    * @param strType
    * @return
    */

  def parsefixResponse(getFixSourceRdd: RDD[JSONObject], strType: String) = {

    val roadcostsRdd = getFixSourceRdd.flatMap(x => {

      val roadcosts = x.getJSONArray(strType)

      var joList = List[JSONObject]()

      for (i <- (0 until (roadcosts.size()))) {
        val jo = roadcosts.getJSONObject(i)
        joList = joList :+ jo
      }

      joList

    })
    roadcostsRdd

  }

  /**
    * 从结果解析货车经验速度日志返回
    * @param spark
    * @param inc_day
    * @return
    */

  def parseFixTable(spark: SparkSession, inc_day: String,etaTracksRdd:RDD[JSONObject]) = {
    val getFixSourceRdd = etaTracksRdd
    val jsonCostsRdd = parsefixResponse(getFixSourceRdd, "roadcosts")
    val jsonSpeedRdd = parsefixResponse(getFixSourceRdd, "roadspeed")

    (jsonCostsRdd, jsonSpeedRdd)
  }

  def calJsonCostsRdd(jsonCostsRdd: RDD[JSONObject], inc_day: String) = {

    val jsonCostsRdd2 = jsonCostsRdd.filter(x => {
      val crosscost = JSONUtils.getJsonValueDouble(x, "crosscost", 0)
      crosscost >= 0  && crosscost <= 1000
    }).map(x => {

      val swid_in = JSONUtils.getJsonValue(x, "in", "")
      val swid_out = JSONUtils.getJsonValue(x, "out", "")
      val adcode = JSONUtils.getJsonValue(x, "adcode", "")
      val tm = JSONUtils.getJsonValueInt(x, "time", 0)
      val periodType = try {DateTimeUtil.getPeriodTimeIndex(tm, inc_day)} catch {case e:Exception => 0}

      ((adcode, swid_in, swid_out, periodType), x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val (adcode, swid_in, swid_out, periodType) = x._1
        val list = x._2.toList
        var costSum = 0.0
        var cnt = 0
        list.map(obj => {
          val crosscost = JSONUtils.getJsonValueDouble(obj,"crosscost",0)
          costSum += crosscost
          cnt += 1
        })
        val avgCost = costSum / cnt
        (adcode, swid_in, swid_out, periodType,4,avgCost.formatted("%.2f").toDouble,cnt)
      })
    jsonCostsRdd2
  }

  def calJsonSpeedRdd(jsonSpeedRdd: RDD[JSONObject], inc_day: String) = {

    val jsonSpeedRdd2 = jsonSpeedRdd.filter(x => {
      val speed = JSONUtils.getJsonValueDouble(x, "speed", 0)
      speed >= 0  && speed <= 127
    }).map(x => {

      val linkid = JSONUtils.getJsonValue(x, "linkid", "")
      val dir = JSONUtils.getJsonValue(x, "dir", "")
      val adcode = JSONUtils.getJsonValue(x, "adcode", "")
      val tm = JSONUtils.getJsonValueInt(x, "time", 0)
      val periodType = try {DateTimeUtil.getPeriodTimeIndex(tm, inc_day)}catch {case e:Exception => 0}
      val weekDay = DateTimeUtil.judgeWeekDayTimeStamp(tm.toLong)

      ((adcode, linkid, dir, periodType,weekDay), x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val (adcode, linkid, dir, periodType,weekDay) = x._1
        val list = x._2.toList
        var sumSpeed = 0.0
        var sumCnt = 0
        list.map(obj => {
          val speed = JSONUtils.getJsonValueDouble(obj,"speed",0)
          sumSpeed += speed
          sumCnt += 1
        })
        val avgSpeed = sumSpeed / sumCnt
        (adcode, linkid, dir, periodType,weekDay,avgSpeed,sumCnt)
      })
    jsonSpeedRdd2
  }




  /**
    * 调用接口返回
    * @param schemaEtaTracksRdd
    * @return
    */

  def schemaEtaTracks(schemaEtaTracksRdd: RDD[JSONObject]) = {
    SparkUtils.memTime()
    val t0 = new Date().getTime

    val etaTracksRdd = schemaEtaTracksRdd.map(x => {
      val jo = calEtaTracksRdd(x)
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("etaTracksRdd的数据量为：" + etaTracksRdd.count())

    val t1 = new Date().getTime
    val cost = SparkUtils.formatTime(t1 - t0)

    SparkUtils.showCost(cost,false)
    etaTracksRdd
  }


  /**
    * 解析计算全流程
    * @param spark
    * @param inc_day
    */

  def parseProcess(spark: SparkSession, inc_day: String,etaTracksRdd:RDD[JSONObject]) = {
    val (jsonCostsRdd, jsonSpeedRdd) = parseFixTable(spark, inc_day,etaTracksRdd)

    val speedRdd = calJsonSpeedRdd(jsonSpeedRdd, inc_day)
    val costRdd = calJsonCostsRdd(jsonCostsRdd, inc_day)

    (speedRdd,costRdd)
  }

  def staStat(spark: SparkSession, inc_day: String): Unit = {

    // TODO: 获取数据
    val sourceRdd = getSourceData(spark, inc_day)

    // TODO: 调用接口返回
    val schemaEtaTracksRdd = calEtaTracks(spark, inc_day, sourceRdd)

    val  count  = schemaEtaTracksRdd.count
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark,"01420395"
      ,"757244","经验速度","经验速度"
      ,fixUrl,"e365c6a601124a6b9b9526c81ffe3776",count,100
    )
    val etaTracksRdd = schemaEtaTracks(schemaEtaTracksRdd)

    BdpTaskRecordUtil.endNetworkInterface("01420395",httpInvokeId)

    // TODO: 存储轨迹中间表
    saveToTrackTable(spark, inc_day, etaTracksRdd)

  }


  def start(inc_day: String, end_day: String): Unit = {

    val spark = SparkUtils.getSparkSession(appName, "yarn")

    spark.sparkContext.setLogLevel("ERROR")
    val dataList = DateTimeUtil.getDateInterval(inc_day, end_day, "yyyyMMdd", "yyyyMMdd")



    for (incDay <- dataList) {
      //    val incDay = inc_day
      //    val incDay = DateTimeUtil.getCurDayYesterDay()
      //    val incDay = inc_day
      logger.error(println("当前计算日期为：" + incDay))

      staStat(spark, incDay)

      SparkUtils.clearCache(spark)
      spark.sqlContext.clearCache()

      val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
      ds.foreach(x => {
        x._2.unpersist()
      })
      logger.error(println(incDay + "：计算日期结束"))
    }

    logger.error("统计完成")
  }


}