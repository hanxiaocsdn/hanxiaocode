package com.sf.gis.scala.scm.app.etastdlinerecallvms

import common.DataSourceCommon
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, row_number, substring, when}
import org.apache.spark.storage.StorageLevel
import utils.SparkBuilder

/**
@author 01420395
@DESCRIPTION  导出数据到ftp  任务id 683679 ; 任务依赖
 任务id: 683679 任务名称 [1623091]-回溯表日志里程数据导出-eta_std_line_recall_vms
 需求ID :
 业务负责人:
@create 2023/04/19
  */
object ExportEtastdlinerecallvmFromHive  extends DataSourceCommon  {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val hdfsPath="/user/01420395/upload/data/export"

  def main(args: Array[String]): Unit = {
    val biz_date = args(0)

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    exportEmVmsVehicle(spark,biz_date)

    exportGisTmVehicle(spark,biz_date)

    exportDataFromHive(spark, biz_date)

    spark.close()
  }

  /**
    * 导出数据文件
    * @param sparkSession
    * @param inc_day
    * @param tblName
    */
  def exportDataFromHive(sparkSession:SparkSession,inc_day:String): Unit ={

    //导出数据文件 EtaStdLineRecallVms
    val EtaStdLineRecallVmsSql  =
      s"""
         |SELECT
         |    task_area_code,
         |    task_id,
         |    task_subid,
         |    start_dept,
         |    end_dept,
         |    start_type,
         |    end_type,
         |    line_code,
         |    concat(line_code, '_', start_dept, '_', end_dept) AS line,
         |    concat( line_code, '_', start_dept, '_', end_dept, '_', vehicle_type ) AS linevehicle,
         |    concat( line_code, '_', start_dept, '_', end_dept, '_', vehicle_type, '_', actual_capacity_load) AS linemload,
         |    (
         |        CASE
         |            WHEN actual_capacity_load < 1.5
         |            THEN 0.84
         |            WHEN actual_capacity_load >= 1.5
         |            AND actual_capacity_load < 3
         |            THEN 0.84
         |            WHEN actual_capacity_load >= 3
         |            AND actual_capacity_load < 5
         |            THEN 0.88
         |            WHEN actual_capacity_load >= 5
         |            AND actual_capacity_load < 7
         |            THEN 1.07
         |            WHEN actual_capacity_load >= 7
         |            AND actual_capacity_load < 14
         |            THEN 1.36
         |            WHEN actual_capacity_load >= 14
         |            AND actual_capacity_load < 20
         |            THEN 1.51
         |            WHEN actual_capacity_load >= 20
         |            AND actual_capacity_load < 30
         |            THEN 1.88
         |            WHEN actual_capacity_load >= 30
         |            THEN 1.99
         |        END ) AS unitprice,
         |    vehicle_serial,
         |    actual_capacity_load,
         |    actual_depart_tm,
         |    actual_arrive_tm,
         |    line_time,
         |    line_distance,
         |    actual_run_time,
         |    is_stop,
         |    transoport_level,
         |    carrier_type,
         |    plf_flag,
         |    vehicle_type,
         |    axls_number,
         |    log_dist,
         |    duration,
         |    TIME,
         |    rt_dist,
         |    highwaymileage,
         |    toll_charge,
         |    error_type,
         |    pns_dist,
         |    pns_time,
         |    src,
         |    line_distance_std,
         |    line_time_std,
         |    sim1,
         |    sim5,
         |    conduct_type,
         |    is_run_ontime_std,
         |    is_run_ontime,
         |    tl_time,
         |    halfway_integrate_rate,
         |    biz_type,
         |    require_category,
         |    std_toll_charge,
         |    start_longitude,
         |    start_latitude,
         |    end_longitude,
         |    end_latitude,
         |    std_id,
         |    task_inc_day,
         |    inc_day,
         |    accrual_dist,
         |    accrual_dist_type,
         |    stop_over_zone_code
         |FROM
         |    dm_gis.eta_std_line_recall_vms
         |WHERE
         |    inc_day = ${inc_day}
      """.stripMargin
    val etaStdLineRecallVmsDF = sparkSession.sql(EtaStdLineRecallVmsSql)

    logger.error("获取的数据量 " +inc_day+ ">>>>>> " + etaStdLineRecallVmsDF.count())

    val cityCode_2 = Seq("010" ,"052" ,"053" ,"027" ,"025" ,"029" ,"021" ,"024" ,"028" ,"022" ,"086" ,"088" ,"023" )
    val cityCode_3 = Seq("511", "514", "519", "660", "663", "754", "768", "411", "415", "769", "757", "758", "766", "591", "593", "598", "599", "930", "931", "932", "933", "934", "935", "936", "937", "938", "939", "941", "943", "970", "971", "972", "973", "974", "975", "976", "977", "979", "701", "791", "792", "793", "798", "790", "794", "795", "796", "797", "799", "770", "771", "772", "773", "774", "775", "776", "777", "778", "779", "020", "751", "763", "851", "854", "855", "856", "857", "858", "859", "898", "451", "452", "453", "454", "455", "456", "457", "458", "459", "464", "467", "468", "469", "470", "710", "711", "712", "713", "714", "715", "716", "717", "718", "719", "722", "724", "728", "752", "753", "762", "431", "432", "433", "434", "435", "436", "437", "438", "439", "482", "530", "531", "534", "537", "538", "634", "635", "313", "314", "315", "316", "317", "335", "310", "311", "312", "318", "319", "570", "578", "579", "532", "535", "631", "533", "536", "539", "543", "546", "632", "633", "513", "515", "471", "472", "473", "474", "475", "476", "477", "478", "479", "483", "574", "580", "951", "952", "953", "954", "955", "594", "595", "592", "596", "597", "349", "350", "351", "352", "353", "354", "355", "356", "357", "358", "359", "911", "912", "913", "914", "915", "916", "917", "919", "755", "412", "414", "416", "417", "418", "419", "421", "427", "429", "812", "813", "816", "817", "818", "825", "826", "827", "830", "831", "832", "833", "834", "835", "836", "837", "838", "839", "891", "892", "893", "894", "895", "896", "897", "516", "517", "518", "527", "512", "576", "551", "552", "554", "557", "558", "561", "564", "550", "553", "555", "556", "559", "562", "563", "566", "577", "510", "523", "852", "853", "730", "734", "735", "736", "737", "738", "739", "743", "744", "745", "746", "901", "902", "903", "906", "908", "909", "990", "991", "992", "993", "994", "995", "996", "997", "998", "999", "370", "371", "372", "373", "378", "391", "392", "393", "374", "375", "376", "377", "379", "394", "395", "396", "398", "662", "668", "750", "756", "759", "760", "691", "692", "870", "871", "872", "873", "874", "875", "876", "877", "878", "879", "883", "887", "571", "572", "573", "575")
    val cityCode_4 = Seq("7311","8981","7312","7313")


    import sparkSession.implicits._
    val cityCodeDf2 = sparkSession.createDataset(cityCode_2).toDF("cityCode2")
    val cityCodeDf3 = sparkSession.createDataset(cityCode_3).toDF("cityCode3")
    val cityCodeDf4 = sparkSession.createDataset(cityCode_4).toDF("cityCode4")


    //获取城市编码 2位相等的数据

    val etaStdLineRecallVmDeptDF
    = etaStdLineRecallVmsDF
      .withColumn("start_dept_2",substring(col("start_dept"),0,3))
      .withColumn("end_dept_2",substring(col("end_dept"),0,3))
      .withColumn("start_dept_3",substring(col("start_dept"),0,3))
      .withColumn("end_dept_3",substring(col("end_dept"),0,3))
      .withColumn("start_dept_4",substring(col("start_dept"),0,4))
      .withColumn("end_dept_4",substring(col("end_dept"),0,4))

    val rowWindow = Window.partitionBy("city_Code","task_subid").orderBy('task_inc_day.desc)

    val etaStdLineRecallVmDeptDF2=  etaStdLineRecallVmDeptDF.join(cityCodeDf2, $"start_dept_2"===$"cityCode2" ,"inner")
      .filter('end_dept_2==='start_dept_2).withColumn("city_Code",'cityCode2)


    val deptDF2 =  etaStdLineRecallVmDeptDF2.withColumn("rn",row_number()over(rowWindow))
      .filter('rn===1).withColumn("biz_day", 'inc_day)


    val etaStdLineRecallVmDeptDF3=  etaStdLineRecallVmDeptDF.join(cityCodeDf3, $"start_dept_3"===$"cityCode3" ,"inner")
      .filter('end_dept_3==='start_dept_3).withColumn("city_Code",'cityCode3)

    val deptDF3 = etaStdLineRecallVmDeptDF3.withColumn("rn",row_number()over(rowWindow))
      .filter('rn===1).withColumn("biz_day", 'inc_day)

    val etaStdLineRecallVmDeptDF4=  etaStdLineRecallVmDeptDF.join(cityCodeDf4, $"start_dept_4"===$"cityCode4" ,"inner")
      .filter('end_dept_4==='start_dept_4).withColumn("city_Code",'cityCode4)

    val deptDF4 =  etaStdLineRecallVmDeptDF4.withColumn("rn",row_number()over(rowWindow))
      .filter('rn===1).withColumn("biz_day", 'inc_day)


    val etaStdLineRecallVmUnionDF  = deptDF2.union(deptDF3).union(deptDF4)

    val etaStdLineRecallVmsDropDF =  etaStdLineRecallVmUnionDF.drop('start_dept_2)
      .drop('end_dept_2)
      .drop('start_dept_3)
      .drop('end_dept_3)
      .drop('start_dept_4)
      .drop('end_dept_4)
      .drop('cityCode2)



    //进行分组排序
    val resultDf = etaStdLineRecallVmsDropDF
      .select("task_area_code",
        "task_id",
        "task_subid",
        "start_dept",
        "end_dept",
        "start_type",
        "end_type",
        "line_code",
        "line",
        "linevehicle",
        "linemload",
        "unitprice",
        "vehicle_serial",
        "actual_capacity_load",
        "actual_depart_tm",
        "actual_arrive_tm",
        "line_time",
        "line_distance",
        "actual_run_time",
        "is_stop",
        "transoport_level",
        "carrier_type",
        "plf_flag",
        "vehicle_type",
        "axls_number",
        "log_dist",
        "duration",
        "time",
        "rt_dist",
        "highwaymileage",
        "toll_charge",
        "error_type",
        "pns_dist",
        "pns_time",
        "src",
        "line_distance_std",
        "line_time_std",
        "sim1",
        "sim5",
        "conduct_type",
        "is_run_ontime_std",
        "is_run_ontime",
        "tl_time",
        "halfway_integrate_rate",
        "biz_type",
        "require_category",
        "std_toll_charge",
        "start_longitude",
        "start_latitude",
        "end_longitude",
        "end_latitude",
        "std_id",
        "task_inc_day",
        "inc_day",
        "accrual_dist",
        "accrual_dist_type",
        "stop_over_zone_code",
        "biz_day",
        "city_Code")
      .orderBy('line_code, 'line, 'linevehicle, 'linemload, 'task_id, 'task_inc_day)

    logger.error(">>>> 数据量 " + resultDf.count())

    val cityCodes = resultDf.select("city_code").distinct().collect().par
    logger.error("城市数据个数 " + cityCodes.size)

    //删除目录
    val fs = FileSystem.get(sparkSession.sparkContext.hadoopConfiguration)
    if(fs.exists(new Path(hdfsPath + "/"+inc_day + "/dm_gis.eta_std_line_recall_vms"))){
      fs.delete(new Path(hdfsPath + "/"+inc_day + "/dm_gis.eta_std_line_recall_vms"),true)
    }


    //循环cityCode导出文件
    cityCodes.map(x => {
      val cityCode  = x.get(0)
      logger.error("城市编码 " +cityCode)


      //导出 dm_gis.eta_std_line_recall_vms 文件
      val cityCodeDf =  resultDf.filter('city_code === cityCode)
        .drop("city_code").drop("biz_day")

      val cityCodePath = hdfsPath + "/"+inc_day + "/dm_gis.eta_std_line_recall_vms"+ "/" + cityCode

      cityCodeDf.coalesce(1)
        .write
        .mode("overwrite")
        .option("header", "true")
        .option("delimiter", "\t")
        .csv(cityCodePath)

      hdfsFileReName(sparkSession,cityCodePath, "dm_gis.eta_std_line_recall_vms_"+inc_day+".csv")

    }
    )

  }

  /**
    * 导出  gis_tm_vehicle 数据
    * @param sparkSession
    * @param inc_day
    */
  def exportGisTmVehicle(sparkSession: SparkSession , inc_day: String)= {
//    \\\\s,\\\\.*。、,]+
//    regexp_replace(vehicle, '[\r\n\0,\\\\s, \\\\.*。、,]+', '') vehicle_serial,
    val gis_tm_vehicle_sql =
      s"""
        SELECT
         |          regexp_replace(vehicle, '[\r\n\0, \\\\s, \\\\.*。、, ，;/!"”“（‘’！）^]+', '') vehicle,
         |          hko_vehicle_code,
         |          trailer_vehicle_code,
         |          source,
         |          vehicle_type,
         |          length,
         |          vehicle_length,
         |          vehicle_full_load_weight,
         |          outer_length,
         |          outer_width,
         |          outer_height,
         |          inner_length,
         |          inner_width,
         |          inner_height,
         |          axis,
         |          weight,
         |          load_weight,
         |          full_load_weight,
         |          color,
         |          energy,
         |          license,
         |          emission,
         |          is_trailer,
         |          vehicle_type_ground,
         |          exception_axis,
         |          exception_weight,
         |          exception_length,
         |          exception_width,
         |          exception_height,
         |          inc_day
         |        from
         |          dm_gis.gis_tm_vehicle
         |        where
         |          inc_day = '${inc_day}'
      """.stripMargin

    logger.error(">>>> gis_tm_vehicle: " + gis_tm_vehicle_sql)
    import sparkSession.implicits._
    val gis_tm_vehicle_Tbl_DF = sparkSession.sql(gis_tm_vehicle_sql)

    val orderWindow = Window.partitionBy("vehicle")
      .orderBy('inc_day.desc,
        'source.asc,
        'vehicle_type_rn.asc,
        'vehicle_length.asc
      )

    val resultDf = gis_tm_vehicle_Tbl_DF
      .withColumn("vehicle_type_rn",
        when('vehicle_type===4, 1)
          when('vehicle_type===8, 2)
          when('vehicle_type===7, 3)
          when('vehicle_type===6, 4)
          when('vehicle_type===5, 5)otherwise(6))

      .withColumn("rn", row_number.over(orderWindow))
      .filter('rn ===1 )
      .select("vehicle",
        "hko_vehicle_code",
        "trailer_vehicle_code",
        "source",
        "vehicle_type",
        "length",
        "vehicle_length",
        "vehicle_full_load_weight",
        "outer_length",
        "outer_width",
        "outer_height",
        "inner_length",
        "inner_width",
        "inner_height",
        "axis",
        "weight",
        "load_weight",
        "full_load_weight",
        "color",
        "energy",
        "license",
        "emission",
        "is_trailer",
        "vehicle_type_ground",
        "exception_axis",
        "exception_weight",
        "exception_length",
        "exception_width",
        "exception_height",
        "inc_day")


    logger.error(">>>> gis_tm_vehicle 数据量 " + resultDf.count() )


    val outPath = hdfsPath+"/"+inc_day+"/dm_gis.gis_tm_vehicle"
    resultDf.persist(StorageLevel.MEMORY_AND_DISK)


    resultDf.coalesce(1)
      .write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", ",")
      .csv(outPath)
    hdfsFileReName(sparkSession,outPath, "dm_gis.gis_tm_vehicle_"+inc_day+".csv")

  }


  /**
    * 导出  tm_vms_vehicle 数据
    * @param sparkSession
    * @param inc_day
    */
  def exportEmVmsVehicle(sparkSession: SparkSession , inc_day: String)= {
    //获取对应的数据
    val tm_vms_vehicle_sql =
      s"""
         |select vehicle_code,dept_id,device_id,color,driver_id,model,fuel_type,used_kind,brand_model,vehicle_state,vendor_id,is_truck,max_person,cab_person,max_load,outer_length,outer_width,outer_height,inner_length,inner_width,inner_height,plate_color,net_weight,axes,wheelbase,total_traction,max_fuel,created_emp_code,created_tm,modified_emp_code,modified_tm,last_maintance_dt,vehicle_driving_type,line_level,emissionrulecode,vehicle_code2,vehicle_classify,operating_lease_type,has_permit,use_kind_name,current_miles,inc_day from ods_vms.tm_vms_vehicle
         | where inc_day =${inc_day}
      """.stripMargin


    val tmVmsVehicleDF = sparkSession.sql(tm_vms_vehicle_sql)

    logger.error(">>>> tm_vms_vehicle 数据量  " + tmVmsVehicleDF.count())
    tmVmsVehicleDF.select("vehicle_code",
      "dept_id",
      "device_id",
      "color",
      "driver_id",
      "model",
      "fuel_type",
      "used_kind",
      "brand_model",
      "vehicle_state",
      "vendor_id",
      "is_truck",
      "max_person",
      "cab_person",
      "max_load",
      "outer_length",
      "outer_width",
      "outer_height",
      "inner_length",
      "inner_width",
      "inner_height",
      "plate_color",
      "net_weight",
      "axes",
      "wheelbase",
      "total_traction",
      "max_fuel",
      "created_emp_code",
      "created_tm",
      "modified_emp_code",
      "modified_tm",
      "last_maintance_dt",
      "vehicle_driving_type",
      "line_level",
      "emissionrulecode",
      "vehicle_code2",
      "vehicle_classify",
      "operating_lease_type",
      "has_permit",
      "use_kind_name",
      "current_miles",
      "inc_day").coalesce(1)

    tmVmsVehicleDF.persist(StorageLevel.MEMORY_AND_DISK)

    val outPath = hdfsPath+"/"+inc_day+"/ods_vms.tm_vms_vehicle"

    tmVmsVehicleDF.coalesce(1).write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", ",")
      .csv(outPath)
    hdfsFileReName(sparkSession,outPath, "ods_vms.tm_vms_vehicle_"+inc_day+".csv")

  }


  def hdfsFileReName(sparkSession: SparkSession , outpath:String, fileName:String )={

    val fs = FileSystem.get(sparkSession.sparkContext.hadoopConfiguration)
    val file = fs.globStatus(new Path(s"$outpath/part-0000*"))(0).getPath().getName()

    if(fs.exists(new Path(outpath + "/" + fileName))){
      fs.delete(new Path(outpath + "/" + fileName),true)
    }

    println(s"$outpath/$file rename to $outpath/$fileName")
    fs.rename(new Path(outpath + "/" + file), new Path(outpath + "/" + fileName))
  }


}
