package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import java.util.UUID
import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.pathSimilar.PathSimilar
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel
import utils.{DateTimeUtil, HttpPostUtils, SparkBuilder, SparkUtils, StringUtils}

import scala.collection.mutable.ArrayBuffer


/**
  *@author 01420395
  *@DESCRIPTION
  *轨迹缺失表 需求ID 1842890   GIS-RSS-PNS：【价值线路】空驶指标监控需求_V1.0
  * 任务id 797486 封路场景&挽救线路准点率指标监控
  *@create 2023/06/14
  */
object TaskSubShiQianWanJiu  extends DataSourceCommon {



  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val url ="http://dyn-gd.int.sfcloud.local:8081/check_route" //生产环境
//    val url = "http://10.202.116.145:1205/check_route"// #1205 测试环境
  case class TaskSubShiQianWanJiu(task_area_code:String,
                                  task_id:String,
                                  task_subid:String,
                                  start_dept:String,
                                  end_dept:String,
                                  start_type:String,
                                  end_type:String,
                                  line_code:String,
                                  vehicle_serial:String,
                                  actual_capacity_load:String,
                                  plan_depart_tm:String,
                                  actual_depart_tm:String,
                                  plan_arrive_tm:String,
                                  actual_arrive_tm:String,
                                  line_time:String,
                                  line_distance:String,
                                  actual_run_time:String,
                                  vehicle_type:String,
                                  axls_number:String,
                                  start_longitude:String,
                                  start_latitude:String,
                                  end_longitude:String,
                                  end_latitude:String,
                                  transoport_level:String,
                                  carrier_type:String,
                                  x1:String,
                                  y1:String,
                                  x2:String,
                                  y2:String,
                                  duration:String,
                                  start_outer_add_code:String,
                                  end_outer_add_code:String,
                                  request_id:String,
                                  ac_is_run_ontime:String,
                                  last_update_tm:String,
                                  std_id:String,
                                  std_coords:String,
                                  rt_coords:String,
                                  rt_dist:String,
                                  inc_day:String,
                                  group_task:String,
                                  vehicle:String,
                                  weight:String,
                                  mload:String,
                                  length:String,
                                  width:String,
                                  height:String,
                                  plate_color:String,
                                  energy:String,
                                  emit_stand:String,
                                  replan_remain_time:String,
                                  replan_remain_distance:String,
                                  real_good_links:String,
                                  replan_point:String,
                                  linkid:String,
                                  routeId:String,
                                  code:String,
                                  point:String,
                                  content:String,
                                  state:String,
                                  good_route_idx:String,
                                  travel_time:String,
                                  distance:String,
                                  conduct_state:String,
                                  sim:String)

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val sparkSession = SparkBuilder.initSpark(this.getClass.getSimpleName)
    // 1.获取的原始数据
    val sourceRdd  = getResourceRdd(sparkSession,inc_day)

    val httpInvokeId  = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01420395"
      ,"797486","封路场景&挽救线路准点率指标监控","封路场景&挽救线路准点率指标监控"
      ,url,"",sourceRdd.count(),100
    )


    val simRdd =  sourceRdd
      //过滤为空的数据
      .filter(row=>{
      !(StringUtils.isEmpty(row.getString("std_coords"))
        || StringUtils.isEmpty(row.getString("plan_arrive_tm"))
        || StringUtils.isEmpty(row.getString("start_dept"))
        || StringUtils.isEmpty(row.getString("line_code"))
        || StringUtils.isEmpty(row.getString("line_distance"))
        || StringUtils.isEmpty(row.getString("vehicle_type")))
    }).map(row => {
      //2.数据轨迹点及通过接口获取封路状态信息
      val params = builderParams(row)
      getRequest(row,params)
    }).map(row =>{
      //计算相识度
      val rt_coords1 = row.getString("rt_coords")
      var replan_points  = row.getString("replan_points")

      replan_points =  replan_points.replaceAll("\\)","").replaceAll("\\(","")
      // 调用jar包计算相似度
      logger.error("相似度计算:" +  rt_coords1  + "===" +  replan_points)

      val object1 = new JSONObject()
      object1.put("rt_coords",rt_coords1)
      val object2 = new JSONObject()
      object2.put("rt_coords",replan_points)

      val simil = PathSimilar.simProcess(object1.toString, object2.toString)
      val sim1 = simil.first
      row.put("sim",sim1)

      if(sim1 > 0.8){
        row.put("conduct_state",1)
      }else{
        row.put("conduct_state",0)
      }

      val task_area_code = row.getString("task_area_code")
      val task_id= row.getString("task_id")
      val task_subid= row.getString("task_subid")
      val start_dept= row.getString("start_dept")
      val end_dept= row.getString("end_dept")
      val start_type= row.getString("start_type")
      val end_type= row.getString("end_type")
      val line_code= row.getString("line_code")
      val vehicle_serial= row.getString("vehicle_serial")
      val actual_capacity_load= row.getString("actual_capacity_load")
      val plan_depart_tm= row.getString("plan_depart_tm")
      val actual_depart_tm= row.getString("actual_depart_tm")
      val plan_arrive_tm= row.getString("plan_arrive_tm")
      val actual_arrive_tm= row.getString("actual_arrive_tm")
      val line_time= row.getString("line_time")
      val line_distance= row.getString("line_distance")
      val actual_run_time= row.getString("actual_run_time")
      val vehicle_type= row.getString("vehicle_type")
      val axls_number= row.getString("axls_number")
      val start_longitude= row.getString("start_longitude")
      val start_latitude= row.getString("start_latitude")
      val end_longitude= row.getString("end_longitude")
      val end_latitude= row.getString("end_latitude")
      val transoport_level= row.getString("transoport_level")
      val carrier_type= row.getString("carrier_type")
      val x1= row.getString("x1")
      val y1= row.getString("y1")
      val x2= row.getString("x2")
      val y2= row.getString("y2")
      val duration= row.getString("duration")
      val start_outer_add_code= row.getString("start_outer_add_code")
      val end_outer_add_code= row.getString("end_outer_add_code")
      val ac_is_run_ontime= row.getString("ac_is_run_ontime")
      val last_update_tm= row.getString("last_update_tm")
      val std_id= row.getString("std_id")
      val std_coords= row.getString("std_coords")
      val rt_coords= row.getString("rt_coords")
      val rt_dist= row.getString("rt_dist")
      val inc_day= row.getString("inc_day")
      val group_task= row.getString("group_task")
      val vehicle= row.getString("vehicle")
      val weight= row.getString("weight")
      val mload= row.getString("mload")
      val length= row.getString("length")
      val width= row.getString("width")
      val height= row.getString("height")
      val plate_color= row.getString("plate_color")
      val energy= row.getString("energy")
      val emit_stand= row.getString("emit_stand")
      val replan_remain_time= row.getString("replan_remain_time")
      val replan_remain_distance= row.getString("replan_remain_distance")
      val real_good_links= row.getString("real_good_links")
      val replan_point= row.getString("replan_points")
      val linkid= row.getString("linkid")
      val routeId= row.getString("routeId")
      val code= row.getString("code")
      val point= row.getString("point")
      val content= row.getString("content")
      val state= row.getString("state")
      val good_route_idx= row.getString("good_route_idx")
      val travel_time= row.getString("travel_time")
      val distance= row.getString("distance")
      val conduct_state  = row.getString("conduct_state")
      val sim  = row.getString("sim")
      val request_id = row.getString("request_id")


      TaskSubShiQianWanJiu(task_area_code,
        task_id,task_subid,start_dept,end_dept,start_type,end_type,line_code,vehicle_serial,actual_capacity_load,
        plan_depart_tm,actual_depart_tm,plan_arrive_tm,actual_arrive_tm,line_time,line_distance,actual_run_time,
        vehicle_type,axls_number,start_longitude,start_latitude,end_longitude,end_latitude,transoport_level,carrier_type,
        x1,y1,x2,y2,duration,start_outer_add_code,end_outer_add_code,request_id,ac_is_run_ontime,last_update_tm,std_id,std_coords,
        rt_coords,rt_dist,inc_day,group_task,vehicle,weight,mload,length,width,height,plate_color,energy,emit_stand,
        replan_remain_time,replan_remain_distance,real_good_links,replan_point,linkid,routeId,code,point,content,state,
        good_route_idx,travel_time,distance,conduct_state,sim)
    })


    simRdd.persist(StorageLevel.MEMORY_AND_DISK)
    BdpTaskRecordUtil.endNetworkInterface("01420395", httpInvokeId )

    import sparkSession.implicits._
    val Rdd2 =   sparkSession.createDataFrame(simRdd)

    val resultRdd =Rdd2
      .select("task_area_code","task_id","task_subid","start_dept","end_dept",
        "start_type","end_type","line_code","vehicle_serial",
        "actual_capacity_load","plan_depart_tm","actual_depart_tm","plan_arrive_tm","actual_arrive_tm","line_time","line_distance",
        "actual_run_time","vehicle_type","axls_number","start_longitude","start_latitude","end_longitude","end_latitude","transoport_level",
        "carrier_type","x1","y1","x2","y2","duration","start_outer_add_code","end_outer_add_code","ac_is_run_ontime","last_update_tm",
        "std_id","std_coords","rt_coords","rt_dist","inc_day","group_task","vehicle","weight","mload","length","width","height",
        "plate_color","energy","emit_stand","replan_remain_time","replan_remain_distance","real_good_links","replan_point",
        "linkid","routeId","code","point","content","state","good_route_idx","travel_time","distance","conduct_state","sim","request_id")


    resultRdd.show(1,false)

    import org.apache.spark.sql.functions._

    val  resultRdd1 =  resultRdd.withColumn("num_transoport_level",
      sum(when('state ===2,1).otherwise(0)).over(Window.partitionBy('transoport_level)))
      .withColumn("use_time",'actual_run_time*60)
      .withColumn("rec_time",'replan_remain_time)
      .withColumn("actual_run_time",'replan_remain_time*60)

    val resultRdd12 = resultRdd1.select('task_area_code
      ,'task_id
      ,'task_subid
      ,'start_dept
      ,'end_dept
      ,'start_type
      ,'end_type
      ,'line_code
      ,'vehicle_serial
      ,'actual_capacity_load
      ,'plan_depart_tm
      ,'actual_depart_tm
      ,'plan_arrive_tm
      ,'actual_arrive_tm
      ,'line_time
      ,'line_distance
      ,'actual_run_time
      ,'vehicle_type
      ,'axls_number
      ,'start_longitude
      ,'start_latitude
      ,'end_longitude
      ,'end_latitude
      ,'transoport_level
      ,'carrier_type
      ,'x1
      ,'y1
      ,'x2
      ,'y2
      ,'duration
      ,'start_outer_add_code
      ,'end_outer_add_code
      ,'request_id
      ,'ac_is_run_ontime
      ,'last_update_tm
      ,'std_id
      ,'std_coords
      ,'rt_coords
      ,'rt_dist
      ,'group_task
      ,'vehicle
      ,'weight
      ,'mload
      ,'length
      ,'width
      ,'height
      ,'plate_color
      ,'energy
      ,'emit_stand
      ,'replan_remain_time
      ,'replan_remain_distance
      ,'real_good_links
      ,'replan_point
      ,'linkid
      ,'routeId
      ,'code
      ,'point
      ,'content
      ,'state
      ,'good_route_idx
      ,'travel_time
      ,'distance
      ,'conduct_state
      ,'sim
      ,'use_time
      ,'rec_time
      ,'inc_day )

//    writeToHive(sparkSession,resultRdd12,Seq("inc_day"),"dm_gis.tasksub_shiqianwanjiu_temp")

    val fenglu_Num_transoport_level_12 = resultRdd1.filter('state===2 && ('transoport_level===1 || 'transoport_level ===2)).count()
    val fenglu_Num_transoport_level_34 = resultRdd1.filter('state===2 && ('transoport_level===4 || 'transoport_level ===3)).count()
    val conduct_Num_transoport_level_12 = resultRdd1.filter('state===2 && ('transoport_level===1 || 'transoport_level ===2) && 'conduct_state===1).count()
    val conduct_Num_transoport_level_3 = resultRdd1.filter('state===2 &&('transoport_level===3 || 'transoport_level ===4) && 'conduct_state===1).count()

    val  resultRdd2 =   resultRdd1
      .withColumn("match_10",when(abs('use_time - 'rec_time)/'use_time<=0.1,1).otherwise(0))
      .withColumn("match_15",when(abs('use_time - 'rec_time)/'use_time<=0.15,1).otherwise(0))
      .withColumn("match_30",when(abs('use_time - 'rec_time)<=30,1).otherwise(0))

      .withColumn("Fenglu_match_10",when('state===2,when(abs('use_time - 'rec_time)/'use_time<=0.1,1).otherwise(0)))
      .withColumn("Fenglu_match_15",when('state===2,when(abs('use_time - 'rec_time)/'use_time<=0.15,1).otherwise(0)))
      .withColumn("Fenglu_match_30",when('state===2,when(abs('use_time - 'rec_time)<=30,1).otherwise(0)))

      .withColumn("ac_is_run_ontime",when('plan_arrive_tm==='actual_arrive_tm,1).otherwise(0))
      .withColumn("wanjiu_is_run_ontime",when('rec_time > 'use_time,1).otherwise(0))
      .withColumn("fenglu_Num_transoport_level_12",lit(fenglu_Num_transoport_level_12))
      .withColumn("fenglu_Num_transoport_level_34",lit(fenglu_Num_transoport_level_34))
      .withColumn("conduct_Num_transoport_level_12",lit(conduct_Num_transoport_level_12))
      .withColumn("conduct_Num_transoport_level_34",lit(conduct_Num_transoport_level_3))


    val  num_match_10 = resultRdd2.filter('state===2 &&'line_distance <= 500 && 'match_10===1).count()
    val  num_match_15 = resultRdd2.filter('state===2 &&('match_15===1) && ('transoport_level===3 || 'transoport_level===4)).count()
    val  num_match_30 = resultRdd2.filter('state===2 &&'line_distance <= 500 && 'match_30===1).count()
    val  num_12_wenhe = resultRdd2.filter('state===2 &&('transoport_level===1 || 'transoport_level===2) && ('match_10===1 || 'match_30===1)).count()
    val  num_34_wenhe_one = resultRdd2.filter('state===2 &&('match_10===1 || 'match_30===1) && ('transoport_level===3 || 'transoport_level===4  )).count()
    val  num_34_wenhe_two = resultRdd2.filter('state===2 &&('match_15===1 || 'match_30===1) && ('transoport_level===3 || 'transoport_level===4 )).count()

    val resultRdd3 = resultRdd2
      .withColumn("num_match_10",lit(num_match_10))
      .withColumn("num_match_15",lit(num_match_15))
      .withColumn("num_match_30",lit(num_match_30))
      .withColumn("num_12_wenhe",lit(num_12_wenhe))
      .withColumn("num_34_wenhe_one",lit(num_34_wenhe_one) )
      .withColumn("num_34_wenhe_two",lit(num_34_wenhe_two) )

    val num_fenglu_12_wanjiu_ontime =  resultRdd3.filter('state===2 &&(('Wanjiu_is_run_ontime===1) && ('transoport_level===1 || 'transoport_level===2))).count()
    val num_fenglu_34_wanjiu_ontime =  resultRdd3.filter('state===2 &&(('Wanjiu_is_run_ontime===1) && ('transoport_level===3 || 'transoport_level===4)  )).count()
    val num_conduct_12_wanjiu_ontime =  resultRdd3.filter('state===2 &&(('Wanjiu_is_run_ontime===1 && 'conduct_state ===1) && ('transoport_level===1 || 'transoport_level===2) )).count()
    val num_conduct_34_wanjiu_ontime =  resultRdd3.filter('state===2 &&(('Wanjiu_is_run_ontime===1 && 'conduct_state ===1) && ('transoport_level===3 || 'transoport_level===4 ))).count()

    val  resultRdd4 = resultRdd3
      .withColumn("ratio_num_12_wenhe",'num_12_wenhe/'fenglu_Num_transoport_level_12)
      .withColumn("ratio_num_34_wenhe_one",'num_34_wenhe_one/'fenglu_Num_transoport_level_34)
      .withColumn("ratio_num_34_wenhe_two",'num_34_wenhe_two/'fenglu_Num_transoport_level_34)
      .withColumn("num_fenglu_12_wanjiu_ontime",lit(num_fenglu_12_wanjiu_ontime))
      .withColumn("num_fenglu_34_wanjiu_ontime",lit(num_fenglu_34_wanjiu_ontime))
      .withColumn("num_conduct_12_wanjiu_ontime",lit(num_conduct_12_wanjiu_ontime))
      .withColumn("num_conduct_34_wanjiu_ontime",lit(num_conduct_34_wanjiu_ontime))

    val  resultRdd5 = resultRdd4
      .withColumn("ratio_fenglu_12_wanjiu_ontime",'Num_fenglu_12_wanjiu_ontime/'fenglu_Num_transoport_level_12)
      .withColumn("ratio_fenglu_34_wanjiu_ontime",'Num_fenglu_34_wanjiu_ontime/'fenglu_Num_transoport_level_34)
      .withColumn("ratio_fenglu_conduct_12_wanjiu_ontime",'Num_conduct_12_wanjiu_ontime/'conduct_Num_transoport_level_12)
      .withColumn("ratio_fenglu_conduct_34_wanjiu_ontime",'Num_conduct_34_wanjiu_ontime/'conduct_Num_transoport_level_34)


    val saveResultRdd =   resultRdd5

      .select("task_subid"
        ,"transoport_level"
        ,"num_transoport_level"
        ,"start_dept"
        ,"end_dept"
        ,"line_code"
        ,"use_time"
        ,"line_distance"
        ,"plan_depart_tm"
        ,"plan_arrive_tm"
        ,"actual_depart_tm"
        ,"actual_arrive_tm"
        ,"start_outer_add_code"
        ,"end_outer_add_code"
        ,"vehicle_serial"
        ,"line_time"
        ,"request_id"
        ,"match_10"
        ,"match_15"
        ,"match_30"
        ,"Fenglu_match_10"
        ,"Fenglu_match_15"
        ,"Fenglu_match_30"
        ,"rec_time"
        ,"fenglu_Num_transoport_level_12"
        ,"fenglu_Num_transoport_level_34"
        ,"conduct_state"
        ,"conduct_Num_transoport_level_12"
        ,"conduct_Num_transoport_level_34"
        ,"ac_is_run_ontime"
        ,"wanjiu_is_run_ontime"
        ,"num_match_10"
        ,"num_match_15"
        ,"num_match_30"
        ,"num_12_wenhe"
        ,"num_34_wenhe_one"
        ,"num_34_wenhe_two"
        ,"ratio_num_12_wenhe"
        ,"ratio_num_34_wenhe_one"
        ,"ratio_num_34_wenhe_two"
        ,"num_fenglu_12_wanjiu_ontime"
        ,"num_fenglu_34_wanjiu_ontime"
        ,"num_conduct_12_wanjiu_ontime"
        ,"num_conduct_34_wanjiu_ontime"
        ,"ratio_fenglu_12_wanjiu_ontime"
        ,"ratio_fenglu_34_wanjiu_ontime"
        ,"ratio_fenglu_conduct_12_wanjiu_ontime"
        ,"ratio_fenglu_conduct_34_wanjiu_ontime"
        ,"state"
        ,"inc_day"
      )

    saveResultRdd.show(1,false)

    writeToHive(sparkSession,saveResultRdd,Seq("inc_day"),"dm_gis.tasksub_shiqianwanjiu")
  }


  /**
    * 通过接口获取对应的数据信息
    * @param row
    * @return
    */
  def getRequest(row:JSONObject,params :JSONObject)={

    val good_route_idxs = new ArrayBuffer[String]()
    val travel_times = new ArrayBuffer[Int]()
    val distances = new ArrayBuffer[Int]()
    val replan_points = new ArrayBuffer[(Double,Double)]()
    val linkids = new ArrayBuffer[(Long,Long)]()
    val routeIds = new ArrayBuffer[String]()
    val codes = new ArrayBuffer[Int]()
    val points = new ArrayBuffer[String]()
    val contents = new ArrayBuffer[String]()
    val real_good_links = new ArrayBuffer[(Long,Long)]()

    val good_links = new ArrayBuffer[(Long,Long)]()

    val postContent  = HttpPostUtils.postStream(url, params)
    //解析数据
    logger.error("返回数据:" +postContent.toString)
    if(!StringUtils.isEmpty(postContent.toString)) {
      //replan_points,linkid,routeId,code,point,content,state,replan_remain_time,replan_remain_distance,good_route_idx,travel_time,distance,real_good_links
      val effective = postContent.getEffective
      val state = effective.getState
      row.put("request_id",postContent.getRequestId)
      //linkId 解析
      var reasonList = postContent.getEffectiveOrBuilder.getReasonList
      for(i <- 0.until(reasonList.size()) ){
        val reason = reasonList.get(i)
        val linkId = reason.getLinkId
        val dir =(linkId & 1 + 1) >> 1
        good_links.append((linkId,dir))

        //        def parseLink(self, links):
        //        good_links = []
        //        for lk in links:
        //          lk = int(lk)
        //        dir = (lk & 1) + 1  # 0为正向,1为反向 ->  1为正向,2为反向
        //          linkid = lk >> 1
        //        good_links.append((linkid,dir))
      }

      val good_routes = effective.getGoodRoutesList
      for (i <- 0.until(good_routes.size())){
        val good_route = good_routes.get(i)
        var  goodRouteIdx = ""
        var  distance = -1
        var  travel_time = -1
        goodRouteIdx = good_route.getGoodRouteIdx
        distance= good_route.getDistance
        travel_time = good_route.getTravelTime
        good_route_idxs.append(goodRouteIdx)
        travel_times.append(travel_time)
        distances.append(distance)
      }

      println(state == 2)
      //replan_point,linkid,routeId,code,point,content,state,replan_remain_time,replan_remain_distance,good_route_idx,travel_time,distance,real_good_links
      if (state == 2) {
        for (i <- 0.until(reasonList.size())) {
          val reason   = reasonList.get(i)
          val link_id = reason.getLinkId
          val route_id = reason.getRouteId
          val cd = reason.getCode
          val pt = reason.getPoint
          val ct = reason.getContent
          val dir = reason.getDir

          linkids.append((link_id, dir.toInt + 1))
          routeIds.append(route_id)
          codes.append(cd)
          points.append(pt)
          contents.append(ct)
        }
        val basePath = postContent.getBasePath//.getString("basePath")
        val patheFirst = basePath.getPathesOrBuilder(0)//.getJSONArray("pathes")
       val  feature  =  basePath.getFeatures(0)

        //直接拿第一条数据进行处理
//        val patheFirst = pathes.get(0)
//        val replan_remain_time = patheFirst.getDestination// .getString("duration")
        val replan_remain_time = feature.getDuration
        val replan_remain_distance = feature.getDistance//.getString("distance")
        val polylineXs = patheFirst.getPolylineXList//.getJSONArray("polylineX")
        val polylineYs = patheFirst.getPolylineYList//.getJSONArray("polylineY")
        logger.error(polylineXs)

        var startX, startY = 0
        for (i <- 0.until(polylineXs.size())) {
          val  polylineX = polylineXs.get(i)
          val  polylineY = polylineYs.get(i)
          if (i == 0) {
            startX = polylineX
            startY = polylineY
            val x = startX / 3600000.00
            val y = startY / 3600000.00
            replan_points.append((x, y))

          } else {
            startX += polylineX
            startY += polylineY
            val x = startX / 3600000.00
            val y = startY / 3600000.00
            replan_points.append((x, y))
          }
        }

        logger.error(replan_points)

        row.put("replan_remain_time", replan_remain_time)
        row.put("replan_remain_distance", replan_remain_distance)
        row.put("real_good_links", real_good_links.mkString)

      }

      row.put("replan_points", replan_points.mkString("[[","],[","]]"))
      row.put("linkid", linkids.mkString("[",",","]"))
      row.put("routeId", routeIds.mkString("[",",","]"))
      row.put("code", codes.mkString("[",",","]"))
      row.put("point", points.mkString("[",",","]"))
      row.put("content", contents.mkString("[",",","]"))
      row.put("state", state)
      row.put("good_route_idx", good_route_idxs.mkString("[",",","]"))
      row.put("travel_time", travel_times.mkString("[",",","]"))
      row.put("distance", distances.mkString("[",",","]"))

      row.put("request_tm", params.getString("request_time"))
      row.put("url", url)
      row.put("return_label", "")
      row.put("request_id", params.getString("request_id"))
      row.put("good_links", real_good_links)

    }else{
      row.put("replan_remain_time","")
      row.put("replan_remain_distance","")
      row.put("real_good_links",good_links.mkString("[",",","]"))
      row.put("replan_points",replan_points.mkString)
      row.put("linkid",linkids.mkString("[",",","]"))
      row.put("routeId",routeIds.mkString("[",",","]"))
      row.put("code",codes.mkString("[",",","]"))
      row.put("point",points.mkString("[",",","]"))
      row.put("content",contents.mkString("[",",","]"))
      row.put("state","")
      row.put("good_route_idx",good_route_idxs.mkString("[",",","]"))
      row.put("travel_time",travel_times.mkString("[",",","]"))
      row.put("distance",distances.mkString("[",",","]"))

      row.put("request_tm", params.getString("request_time"))
      row.put("url", url)
      row.put("return_label", "")
      row.put("request_id", params.getString("request_id"))
      row.put("good_links", good_links.mkString("[",",","]"))
    }
    row
  }


  def builderParams(row : JSONObject) = {

    //请求接口信息
    val vehicle_serial = row.getString("vehicle_serial")
    val weight = row.getString("weight")
    val mload = row.getString("mload")
    val height = row.getString("height")
    val vehicle_type = row.getString("vehicle_type")
    val plate_color = row.getString("plate_color")
    val width = row.getString("width")
    val energy =row.getString("energy")
    val emit_stand = row.getString("emit_stand")
    //     val planDate =  Util.tm2str(Util.str2tm(data[9],'%Y-%m-%d %H:%M:%S')  + args.offset, '%Y%m%d%H%M%S')
    val planDate =  DateTimeUtil.timestampConvertDate(row.getLong("plan_depart_tm"),"yyyyMMddmmHHss")// Util.tm2str(Util.str2tm(data[9],'%Y-%m-%d %H:%M:%S')  + args.offset, '%Y%m%d%H%M%S')
    val end_dept = row.getString("end_dept")
    val request_id = UUID.randomUUID().toString
    val req_tm = DateTimeUtil.getCurrentSystemTime("yyyyMMddHHmmss")//time.strftime('%Y%m%d%H%M%S',time.localtime())
    val request_time = req_tm
    var points = row.getString("std_coords")
    points = points.replaceAll("\"","").replaceAll("\\]\\,\\[","|")
      .replaceAll("\\[\\[","") .replaceAll("\\]\\]","")

    val index = "route_test1"
    val carrier_type = row.getString("carrier_type")
    val planArriveTm = DateTimeUtil.timestampConvertDate(row.getLong("plan_arrive_tm"),"yyyyMMddmmHHss")//Util.tm2str(Util.str2tm(data[13],'%Y-%m-%d %H:%M:%S')+ args.offset, '%Y%m%d%H%M%S')
    val startDeptcode = row.getString("start_dept")
    val lineCode = row.getString("line_code")
    val lineDistance = row.getString("line_distance")
    val startOuteraddcode = row.getString("start_outer_add_code")
    val endOuteraddcode = row.getString("end_outer_add_code")
    val holiday = 0

    val  param  = new JSONObject()

    if(!StringUtils.isEmpty(vehicle_serial)){
      param.put("plate",vehicle_serial)
    }
    if(!StringUtils.isEmpty(weight)){
      param.put("weight",weight.toFloat)
    }
    if(!StringUtils.isEmpty(mload)){
      param.put("mload",mload.toFloat)
    }

    if(!StringUtils.isEmpty(height)){
      param.put("height",height.toFloat)
    }

    if(!StringUtils.isEmpty(plate_color)){
      param.put("plate_color",plate_color.toInt)
    }

    if(!StringUtils.isEmpty(width)){
      param.put("width",width.toFloat)
    }

    if(!StringUtils.isEmpty(energy)){
      param.put("energy",energy.toInt)
    }
    if(!StringUtils.isEmpty(emit_stand)){
      param.put("emit_stand",emit_stand.toInt)
    }

    if(!StringUtils.isEmpty(startOuteraddcode)){
      param.put("startOuteraddcode",startOuteraddcode)
    }

    if(!StringUtils.isEmpty(endOuteraddcode)){
      param.put("endOuteraddcode",endOuteraddcode)
    }


    param.put("ak","8bb09e5e110845f39a000391668e3e80")
    param.put("vehicle",vehicle_type.toInt)
    param.put("planDate",planDate)
    param.put("destDeptCode",end_dept)
    param.put("request_id",request_id)
    param.put("request_time",request_time)

    param.put("carrier_type",carrier_type)
    param.put("planArriveTm",planArriveTm)
    param.put("startDeptcode",startDeptcode)
    param.put("lineCode",lineCode)
    param.put("lineDistance",lineDistance)
    param.put("holiday",holiday)
    param.put("debug",0)


    val  route = new JSONObject()
    route.put("points",points)
    route.put("index",index)


    val routes = new JSONArray()
    routes.add(route)
    param.put("routes",routes)

    logger.error(param.toString)
    param
  }


  def getResourceRdd(spark:SparkSession, inc_day:String) = {
    val sql  =
      s"""
         |select m.*, n.*
         |from
         |(select
         |*
         |from (
         |select
         |task_area_code,
         |task_id,
         |task_subid,
         |start_dept,
         |end_dept,
         |start_type,
         |end_type,
         |line_code,
         |vehicle_serial,
         |actual_capacity_load,
         |plan_depart_tm,
         |actual_depart_tm,
         |plan_arrive_tm,
         |actual_arrive_tm,
         |line_time,
         |line_distance,
         |actual_run_time,
         |vehicle_type,
         |axls_number,
         |start_longitude,
         |start_latitude,
         |end_longitude,
         |end_latitude,
         |transoport_level,
         |carrier_type,
         |x1,
         |y1,
         |x2,
         |y2,
         |duration,
         |start_outer_add_code,
         |end_outer_add_code,
         |ac_is_run_ontime,
         |last_update_tm,
         |std_id,
         |std_coords,
         |rt_coords,
         |rt_dist,
         |inc_day,
         |concat (task_id,'_',start_dept,'_',end_dept) as group_task,
         |row_number() over (partition by task_subid order by last_update_tm desc) as rn
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day = '${inc_day}'
         |  ) t
         | where t.rn=1) m
         |left join
         |(select * from (select vehicle,weight, mload, length, width, height, plate_color, energy, emit_stand,
         |row_number() over (partition by vehicle order by req_time desc) as rnn
         |from dm_gis.gis_navi_eta_result1
         |where inc_day = '${inc_day}') t1
         |where t1.rnn=1) n
         |on m.vehicle_serial = n.vehicle
         |
         |where m.task_subid in ('513Y58355131' ,'333Y78760192' ,'300Y47491411' ,'591Y51479781' ,'111Y151661071' ,'791Y61670271' ,'513Y58292451' ,'931Y39663771' ,'021Y253131721' ,'595Y47054281' ,'700Y20663031' ,'999Y67021381' ,'591Y51764901' ,'871Y53213431' ,'371Y105791921' ,'555Y35342031' ,'010Y164811991' ,'551Y90592242' ,'222Y169587501' ,'351Y58577141' ,'111Y150517011' ,'700Y20725001' ,'551Y89936411' ,'512Y122726041' ,'300Y47456661' ,'531Y89628181' ,'591Y51843472' ,'551Y89306171' ,'531Y89996011' ,'028Y107010222' ,'222Y169808621' ,'577Y70569042' ,'333Y78477191' ,'531Y89032421' ,'517Y59967541' ,'316Y64043631' ,'871Y52841121' ,'300Y47697551' ,'371Y105252751' ,'471Y36141544' ,'111Y150773451' ,'316Y63657541' ,'536Y74364911' ,'020Y174800251' ,'791Y60865651' ,'027Y96574301' ,'010Y166577371' ,'027Y96349671' ,'571Y163216911' ,'760Y60693472' ,'700Y20925251' ,'571Y163186332' ,'757Y58527902' ,'451Y38491331' ,'760Y60522761' ,'111Y150497721' ,'111Y152313091' ,'666Y32628731' ,'333Y79267461' ,'471Y36248691' ,'351Y58160611' ,'021Y252022821' ,'551Y89874131' ,'316Y63971372' ,'111Y151073461' ,'024Y78679431' ,'010Y166402011' ,'513Y57900572' ,'431Y35937621' ,'371Y105258601' ,'351Y58666841' ,'222Y169406592' ,'791Y61508171' ,'111Y151522481' ,'024Y78687421' ,'010Y166303621' ,'571Y164175342' ,'111Y151305522' ,'471Y36322051' ,'931Y39428521' ,'020Y174905292' ,'451Y38639763' ,'023Y57116042' ,'010Y165744031' ,'769Y78918291' ,'022Y54110851' ,'010Y167881141' ,'791Y61201551' ,'595Y46835681' ,'333Y79001782' ,'888Y120997901' ,'311Y84540213' ,'010Y165860922' ,'023Y56723151' ,'371Y106064461' ,'024Y78901671' ,'577Y70297932' ,'510Y68143731' ,'471Y36036001' ,'551Y90283121' ,'931Y39538991' ,'871Y53045772' ,'029Y67257621' ,'311Y82454901' ,'888Y121327411' ,'025Y76260861' ,'371Y105653202' ,'010Y167892041' ,'752Y45608681' ,'024Y79599911' ,'579Y61621611' ,'760Y60205261' ,'222Y169777791' ,'021Y250735742' ,'021Y252157601' ,'888Y120793021' ,'769Y79632833' ,'311Y83570282' ,'028Y106707661' ,'532Y60947521' ,'574Y75923371' ,'791Y61047041' ,'471Y36460571' ,'999Y66864871' ,'771Y60830071' ,'888Y121528961' ,'532Y60444671' ,'571Y164513922' ,'574Y76085771' ,'027Y95715911' ,'471Y36486371' ,'010Y164984551' ,'760Y60379412' ,'791Y61481531' ,'451Y38640061' ,'311Y83889621' ,'111Y151041331' ,'536Y74600021' ,'510Y68002921' ,'028Y107040832' ,'027Y96317353' ,'311Y83587111' ,'555Y35284411' ,'020Y173862971' ,'577Y70401621' ,'020Y173190571' ,'555Y35477121' ,'311Y84568331' ,'333Y78355212' ,'574Y76248372' ,'531Y89635281' ,'577Y70476061' )
      """.stripMargin
    logger.error("running sql : " + sql)

    import spark.implicits._
    val resultRdd = spark.sql(sql).select(
      'task_area_code
      ,'task_id
      ,'task_subid
      ,'start_dept
      ,'end_dept
      ,'start_type
      ,'end_type
      ,'line_code
      ,'vehicle_serial
      ,'actual_capacity_load
      ,'plan_depart_tm
      ,'actual_depart_tm
      ,'plan_arrive_tm
      ,'actual_arrive_tm
      ,'line_time
      ,'line_distance
      ,'actual_run_time
      ,'vehicle_type
      ,'axls_number
      ,'start_longitude
      ,'start_latitude
      ,'end_longitude
      ,'end_latitude
      ,'transoport_level
      ,'carrier_type
      ,'x1
      ,'y1
      ,'x2
      ,'y2
      ,'duration
      ,'start_outer_add_code
      ,'end_outer_add_code
      ,'ac_is_run_ontime
      ,'last_update_tm
      ,'std_id
      ,'std_coords
      ,'rt_coords
      ,'rt_dist
      ,'inc_day
      ,'group_task
      ,'vehicle
      ,'weight
      ,'mload
      ,'length
      ,'width
      ,'height
      ,'plate_color
      ,'energy
      ,'emit_stand
    )

    SparkUtils.getRowToJson(resultRdd,100)
  }


}
