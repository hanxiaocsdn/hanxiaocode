package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class HiveInfoParser {
    public  HiveInfoParser(){}

    public static HiveInfo parserHive(String info){
        HiveInfo hiveinfo = new HiveInfo();
        if (info.isEmpty() || !JSON.isValidObject(info)){
            return hiveinfo;
        }
        JSONObject ret = JSON.parseObject(info);
        if (ret.containsKey("uid")){
            hiveinfo.uid = ret.getString("uid");
        }
        if (ret.containsKey("destZoneCoordinate")){
            hiveinfo.destZoneCoordinate = ret.getString("destZoneCoordinate");
        }
        if (ret.containsKey("pickUpTm")){
            hiveinfo.pickUpTm = ret.getString("pickUpTm");
        }
        if (ret.containsKey("status")){
            hiveinfo.status = ret.getInteger("status").toString();
        }
        return  hiveinfo;
    }
}
