package com.sf.gis.scala.scm.app.trajectory

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.scala.base.util.HttpClientUtil
import common.DataSourceCommon
import org.apache.spark.sql.functions.{col, split}
import utils.{HttpPostUtils, SparkBuilder, StringUtils}

import scala.collection.mutable.ArrayBuffer

/**
@author 01420395
@DESCRIPTION
需求ID 1829909 GIS-RSS-ETA-STD-LINE:【线路基础服务】城市间距离计算_V1.0 任务id 一次性任务
任务依赖：395524 临时任务
@create 2023/06/02
 */
object CityDistanceApp extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val url = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get"
  val getUrls = "http://gis-int2.int.sfdc.com.cn:1080/geo/api"
  val ak  = "fe044a34e92c42f5a2996275ff0074d7"
  val cityUrl = "http://ftkj-gis-apis.intsit.sfcloud.local:1080/rp/v2/api"


  def main(args: Array[String]): Unit = {
    //获取最大分区数据
    val sparkSession = SparkBuilder.localInitSpark(this.getClass.getSimpleName)


    val srcCitySeq = Seq("七台河市","三亚市","三明市","三门峡市","上海市","上饶市","东莞市","东营市","中卫市","中山市","临夏回族自治州","临汾市","临沂市","临沧市","丹东市","丽水市","丽江市","乌兰察布市","乌海市","乌鲁木齐市","乐山市","九江市","云浮市","亳州市","伊春市","伊犁哈萨克自治州","佛山市","佳木斯市","保定市","保山市","信阳市","克孜勒苏柯尔克孜自治州","克拉玛依市","六安市","六盘水市","兰州市","兴安盟","内江市","凉山彝族自治州","包头市","北京市","北海市","十堰市","南京市","南充市","南平市","南昌市","南通市","南阳市","博尔塔拉蒙古自治州","厦门市","双鸭山市","台州市","合肥市","吉安市","吉林市","吐鲁番地区","吕梁市","吴忠市","周口市","呼伦贝尔市","呼和浩特市","和田地区","咸宁市","哈密地区","哈尔滨市","唐山市","商丘市","商洛市","喀什地区","嘉兴市","嘉峪关市","四平市","固原市","塔城地区","大兴安岭地区","大同市","大庆市","大理白族自治州","大连市","天水市","天津市","太原市","威海市","娄底市","孝感市","宁德市","宁波市","安庆市","安康市","安阳市","安顺市","定西市","宜宾市","宜昌市","宜春市","宝鸡市","宣城市","宿州市","宿迁市","山南地区","岳阳市","崇左市","巴中市","巴彦淖尔市","巴音郭楞蒙古自治州","常州市","常德市","平凉市","平顶山市","广元市","广安市","广州市","庆阳市","廊坊市","延安市","延边朝鲜族自治州","开封市","张家口市","张家界市","张掖市","徐州市","德宏傣族景颇族自治州","德州市","德阳市","忻州市","怀化市","怒江傈僳族自治州","恩施土家族苗族自治州","惠州市","成都市","扬州市","承德市","抚州市","拉萨市","揭阳市","攀枝花市","文山壮族苗族自治州","新乡市","新余市","无锡市","日喀则地区","日照市","昆明市","昌吉回族自治州","昌都市","昭通市","晋中市","晋城市","普洱市","景德镇市","曲靖市","朔州市","朝阳市","本溪市","来宾市","杭州市","松原市","林芝地区","果洛藏族自治州","枣庄市","株洲市","格尔木","桂林市","梅州市","楚雄彝族自治州","榆林市","武汉市","毕节市","永州市","汉中市","汕头市","汕尾市","江门市","池州市","沈阳市","沧州市","河池市","河源市","泉州市","泰安市","泰州市","泸州市","洛阳市","济南市","济宁市","海东市","海北藏族自治州","海南藏族自治州","海口市","海西蒙古族藏族自治州","淄博市","淮北市","淮南市","淮安市","深圳市","清远市","温州市","渭南市","湖州市","湘潭市","湘西土家族苗族自治州","湛江市","滁州市","滨州市","漯河市","漳州市","潍坊市","潜江市","潮州市","濮阳市","烟台市","焦作市","牡丹江市","玉树藏族自治州","玉溪市","珠海市","甘南藏族自治州","甘孜藏族自治州","白城市","白山市","白银市","百色市","益阳市","盐城市","盘锦市","石嘴山市","石家庄市","石河子市","福州市","秦皇岛市","红河哈尼族彝族自治州","绍兴市","绥化市","绵阳市","聊城市","肇庆市","自贡市","舟山市","芜湖市","苏州市","茂名市","荆州市","荆门市","莆田市","菏泽市","萍乡市","营口市","葫芦岛市","蚌埠市","衡水市","衡阳市","衢州市","襄阳市","西双版纳傣族自治州","西宁市","西安市","许昌市","贵港市","贵阳市","贺州市","赣州市","赤峰市","辽源市","辽阳市","达州市","运城市","连云港市","迪庆藏族自治州","通化市","通辽市","遂宁市","遵义市","邢台市","那曲地区","邯郸市","邵阳市","郑州市","郴州市","鄂尔多斯市","鄂州市","重庆市","金华市","金昌市","钦州市","铜仁市","铜川市","铜陵市","银川市","锡林郭勒盟","锦州市","镇江市","长春市","长沙市","长治市","阜新市","防城港市","阳江市","阳泉市","阿克苏地区","阿勒泰地区","阿坝藏族羌族自治州","阿拉善盟","陇南市","随州市","雅安市","青岛市","鞍山市","韶关市","马鞍山市","驻马店市","鸡西市","鹤壁市","鹤岗市","鹰潭市","黄冈市","黄南藏族自治州","黄山市","黄石市","黑河市","黔东南苗族侗族自治州","黔南布依族苗族自治州","黔西南布依族苗族自治州","齐齐哈尔市","龙岩市","武威市","阜阳市","梧州市","玉林市","咸阳市","济源市","酒泉市","南宁市","资阳市","眉山市","柳州市","铁岭市","抚顺市","天门市","仙桃市","香港市","奎屯市","格尔木市","日喀则市","莱芜市")
    //    val srcCitySeq = Seq("七台河市")
    //    getGreatCircleDistance

    val  cols = Seq("city_flow","src_city_code","src_city_name","src_area_name","src_province_name","src_hq_name","dest_city_code","dest_city_name","dest_area_name","dest_province_name","dest_hq_name","distance_type_code1","distance_type_code2","distince_type1","distince_type2","sf_jr","sf_cc","sf_sp4","sf_gr","sf_cr_up","sf_gr_up","is_same","rate_tag","sp4_tag","t4_tag","distance_range","distance_label","distance","sf_t77","sf_t77_up","sf_gr_down","important_type","is_import_flow","is_import_flow_ly","t68_cfg","sf_cr_up2","sf_gr_up2","t6_tag","is_7a_flag","is_core617_flag","is_express_flag","is_express_config","src_fbq_code","src_fbq_name","dest_fbq_code","dest_fbq_name","src_area_code","dest_area_code","inc_month")

    import sparkSession.implicits._
    val inputPath = "D:\\user\\01420395\\桌面\\城市数据.csv"
    val vehicle_df = sparkSession.read.option("header", "true")
      .option("delimiter", "\\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*).select("src_city_name","src_city_code").distinct()
      .withColumn("src_city_name", split('src_city_name,"/")(0))

    vehicle_df.show(1000, false)

    import sparkSession.implicits._

    val responseJson = vehicle_df.map(row => {
      val lists = new ArrayBuffer[(String,String,String,String,String ,String  )]()
      val city = row.getAs[String]("src_city_name")
      val city_code = row.getAs[Int]("src_city_code")
      //获取387->ali
      val aliCity ="三沙市"
      val aliCityCode ="8983"
      val getUrl_ali = url + "?url="+getUrls+"&address="+aliCity+"&ak="+ak
      val cityZbJson_ali  = HttpClientUtil.getJsonByGet(getUrl_ali)
      val (x_ali,y_ali) =  paserXYByCity(cityZbJson_ali)

      //获取387<-ali
      val getUrl_city = url + "?url="+getUrls+"&address="+city+"&ak="+ak
      val cityZbJson_city  = HttpClientUtil.getJsonByGet(getUrl_city)
      val (x_city,y_city) =  paserXYByCity(cityZbJson_city)

      //获取387<-ali
      val parasJson  = new JSONObject()
      parasJson.put("ak","de17fa220fbe42be95f3c84212b41c7a")
      parasJson.put("axleNumber","2")
      parasJson.put("coordFlag","1")
      parasJson.put("mLoad","0.5")
      parasJson.put("opt","zh1")
      parasJson.put("pathCount","1")
      parasJson.put("tolls","1")
      parasJson.put("vehicle","5")
      parasJson.put("x1",x_ali)
      parasJson.put("y1",y_ali)
      parasJson.put("x2",x_city)
      parasJson.put("y2",y_city)

      val lengthResultStr_ali =  HttpPostUtils.post(cityUrl,parasJson,"utf-8")
      var   length_ali = "0.00"
      val  json  = JSON.parseObject(lengthResultStr_ali).getJSONObject("result")
      if(json!=null &&  json.containsKey("dist")){
        length_ali = json.getString("dist")
      }else{
        logger.error(city +"=="+ x_ali +"=="+ y_ali+"=="+ x_city +"=="+ y_city+ ">>>>>>" + json.getString("msg"))
      }
      var lenght=0.00
      if(!StringUtils.isEmpty(x_ali) && !StringUtils.isEmpty(y_ali) && !StringUtils.isEmpty(x_city) && !StringUtils.isEmpty(y_city)){
        lenght=  GeometryUtil.getDistance(GeometryUtil.createPoint(x_ali,y_ali),GeometryUtil.createPoint(x_city,y_city))
        logger.error(lenght  + "========" + length_ali)
      }

      //获取387->ali
      parasJson.put("x1",x_city)
      parasJson.put("y1",y_city)
      parasJson.put("x2",x_ali)
      parasJson.put("y2",y_ali)

      val lengthResultStr_city =  HttpPostUtils.post(cityUrl,parasJson,"utf-8")
      val length_city = JSON.parseObject(lengthResultStr_city).getJSONObject("result").getString("dist")

      lists.append((aliCity,x_ali+":"+y_ali,city,x_city+":"+y_city,aliCityCode+"-"+city_code,length_ali))
      lists.append((city,x_city+":"+y_city,aliCity,x_ali+":"+y_ali,city_code +"-"+aliCityCode,length_city))

      lists
    }).flatMap(row=>{row.toSeq})


    val responseJson1 = vehicle_df.map(row => {
      val lists = new ArrayBuffer[(String,String,String,String,String ,String  )]()
      val city_code = row.getAs[Int]("src_city_code")
      val city  =  row.getAs[String]("src_city_name")
      //      val aliCity = "阿里地区"
      //      val aliCity =Seq("三沙市","儋州")
      //获取387->ali
      val aliCity ="儋州"
      val aliCityCode ="8982"


      val getUrl_ali = url + "?url="+getUrls+"&address="+aliCity+"&ak="+ak
      val cityZbJson_ali  = HttpClientUtil.getJsonByGet(getUrl_ali)
      val (x_ali,y_ali) =  paserXYByCity(cityZbJson_ali)

      //获取387<-ali
      val getUrl_city = url + "?url="+getUrls+"&address="+city+"&ak="+ak
      val cityZbJson_city  = HttpClientUtil.getJsonByGet(getUrl_city)
      val (x_city,y_city) =  paserXYByCity(cityZbJson_city)

      //获取387<-ali
      val parasJson  = new JSONObject()
      parasJson.put("ak","de17fa220fbe42be95f3c84212b41c7a")
      parasJson.put("axleNumber","2")
      parasJson.put("coordFlag","1")
      parasJson.put("mLoad","0.5")
      parasJson.put("opt","zh1")
      parasJson.put("pathCount","1")
      parasJson.put("tolls","1")
      parasJson.put("vehicle","5")
      parasJson.put("x1",x_ali)
      parasJson.put("y1",y_ali)
      parasJson.put("x2",x_city)
      parasJson.put("y2",y_city)

      val lengthResultStr_ali =  HttpPostUtils.post(cityUrl,parasJson,"utf-8")
      var   length_ali = "0.00"
      val  json  = JSON.parseObject(lengthResultStr_ali).getJSONObject("result")
      if(json!=null &&  json.containsKey("dist")){
        length_ali = json.getString("dist")
      }else{
        logger.error(city +"=="+ x_ali +"=="+ y_ali+"=="+ x_city +"=="+ y_city+ ">>>>>>" + json.getString("msg"))
      }
      var lenght=0.00
      if(!StringUtils.isEmpty(x_ali) && !StringUtils.isEmpty(y_ali) && !StringUtils.isEmpty(x_city) && !StringUtils.isEmpty(y_city)){
        lenght=  GeometryUtil.getDistance(GeometryUtil.createPoint(x_ali,y_ali),GeometryUtil.createPoint(x_city,y_city))
        logger.error(lenght  + "========" + length_ali)
      }

      //获取387->ali
      parasJson.put("x1",x_city)
      parasJson.put("y1",y_city)
      parasJson.put("x2",x_ali)
      parasJson.put("y2",y_ali)

      val lengthResultStr_city =  HttpPostUtils.post(cityUrl,parasJson,"utf-8")
      val length_city = JSON.parseObject(lengthResultStr_city).getJSONObject("result").getString("dist")

      lists.append((aliCity,x_ali+":"+y_ali,city,x_city+":"+y_city,aliCityCode+"-"+city_code,length_ali))
      lists.append((city,x_city+":"+y_city,aliCity,x_ali+":"+y_ali,city_code +"-"+aliCityCode,length_city))
      lists
    }).flatMap(row=>{row.toSeq})

    val result =  responseJson.union(responseJson1)

    result.cache()
    result.foreach(println(_))
    val df = result.toDF(
        "src_city_code",
        "src_city_coordinates",
        "dest_city_code",
        "dsc_city_coordinates",
        "flow_direction",
        "Line_mileage"
      )
    df.show(2,  false)

    df.coalesce(1)
      .write
      .mode("overwrite")
      .format("csv")
      .csv("E:\\caiguofang\\protects\\gis-ass-oms-bd\\scm\\src\\main\\resource\\city_distance.csv")
    //    writeToHiveNoP(sparkSession, df,"dm_gis.city_distance")
  }


  def paserXYByCity(cityDistance:JSONObject):(String,String)={
    val result = cityDistance.getJSONObject("result")
    val x = result.getString("xcoord")
    val y = result.getString("ycoord")
    (x,y)
  }

}
