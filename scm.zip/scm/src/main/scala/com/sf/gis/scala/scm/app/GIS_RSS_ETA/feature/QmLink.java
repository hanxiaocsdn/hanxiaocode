package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

public class QmLink extends RttData {
    public float  dr_len = 0;
    public float duration = 0;

    public float length =0;
    public int fm = 0;
    public int rc = 0;
    public int hasLight = 0;
    public int lnk_type = 0;
    public int adcode = 0;
    public int isCell = 0; //0为非cell节点,1为cell节点

}
