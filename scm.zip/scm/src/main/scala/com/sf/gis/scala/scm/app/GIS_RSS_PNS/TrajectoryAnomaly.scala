package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import com.alibaba.fastjson.{JSON, JSONObject}
import common.DataSourceCommon
import utils.{HttpPostUtils, SparkBuilder, SparkUtils, StringUtils}

/**
  *@author 01420395
  *@DESCRIPTION 一次性任务
  *轨迹缺失表 需求ID 1842890   GIS-RSS-PNS：GIS_RSS_SCM 【计提数据】轨迹异常数据轨迹数据获取V1.0需求说明书
  *任务id ：
  *@create 2023/09/27
  */
object TrajectoryAnomaly  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val url:String  = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/queryDetail"


  case class TrajectoryAnomalyClass(vehicleSerial:String,
                                    taskId:String,
                                    beginDateTime:String,
                                    endDateTime:String,
                                    rtDist:String,
                                    logDist:String,
                                    driverId:String,
                                    driverName:String,
                                    inc_day:String)
  def main(args: Array[String]): Unit = {
    val cols  = Seq("taskId","vehicleSerial","beginDateTime","endDateTime","driverId",
      "driverName","logDist","rtDist","inc_day"
    )

    val inc_Day  = args(0)
//            val spark = SparkBuilder.localInitSpark(this.getClass.getSimpleName)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    import spark.implicits._
    //读取本地数据
//            val dataFilePath = s"E:\\caiguofang\\导航相关资料/20230920.csv"
    val dataFilePath = s"/user/01420395/upload/20230920.csv"
    val vehicle_df = spark.read.option("header", "true")
      .option("delimiter", "\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(dataFilePath)
      .toDF((cols): _*)

      .filter('inc_day ===inc_Day)

    vehicle_df.show(1, false)

    //接口获取数据
    val resultJson  = SparkUtils.getRowToJson(vehicle_df,100).repartition(1000)
    val resultDS =  resultJson.map(row => {
      val un  = row.getString("vehicleSerial")
      val taskId  = row.getString("taskId")
      var beginDateTime  = row.getString("beginDateTime")
      beginDateTime = beginDateTime.substring(0 , beginDateTime.size-2)

      var endDateTime  = row.getString("endDateTime")
      endDateTime = endDateTime.substring(0 , endDateTime.size-2)
      val requesJson = new JSONObject()

      if(!StringUtils.isEmpty(beginDateTime)) requesJson.put("beginDateTime", beginDateTime.replaceAll("-","").replaceAll(" ","").replaceAll(":",""))
      if(!StringUtils.isEmpty(endDateTime)) requesJson.put("endDateTime", endDateTime.replaceAll("-","").replaceAll(" ","").replaceAll(":",""))

      //      requesJson.put("beginDateTime","20230920082504")
      //      requesJson.put("endDateTime","20230920164516")
      requesJson.put("ak","b40f2c38165d43b3b3e4d83a0c9b25f9")
      requesJson.put("traceId","1703717963089068032")
      requesJson.put("un",un)
      requesJson.put("type","0")
      requesJson.put("vehicle","6")
      requesJson.put("addpoint",1)
      requesJson.put("taskId",taskId)

      logger.error(requesJson)
      println(requesJson)
      //发送请求
      val httpObject2  = HttpPostUtils.post(url, requesJson,"utf-8")
      logger.error(httpObject2)
      //获取最后一个 调vms接口获取返回结果中tracks的list中最后一个list的sumdist作为rtdist和原始数据匹配，输出表数据
      var rtDist = httpObject2

      val vehicleSerial = row.getString("vehicleSerial")
      var beginDateTime_s = row.getString("beginDateTime")
      beginDateTime_s = beginDateTime_s.substring(0 , beginDateTime_s.size-2)
      var endDateTime_s = row.getString("endDateTime")
      endDateTime_s = endDateTime_s.substring(0 , endDateTime_s.size-2)
      if(httpObject2!=null){
        val httpObject =  JSON.parseObject(httpObject2)
        val result = httpObject.getJSONObject("result")
        if(result!=null){
          val data =  result.getJSONObject("data")
          if(data!=null){
            val tracks = data.getJSONArray("track")
            rtDist = tracks.getJSONObject(tracks.size()-1).getString("sumDist")
          }
        }
      }
      val logDist = row.getString("logDist")
      val driverId = row.getString("driverId")
      val driverName = row.getString("driverName")
      val inc_day = row.getString("inc_day")
      TrajectoryAnomalyClass(vehicleSerial,taskId,beginDateTime_s,endDateTime_s,rtDist,logDist,driverId,driverName,inc_day)
    }).persist()
    //落地表


    val res =  spark.createDataFrame(resultDS).repartition(100)
      .select(
        'vehicleSerial
        ,'taskId
        ,'beginDateTime
        ,'endDateTime
        ,'driverId
        ,'driverName
        ,'logDist
        ,'rtDist
        ,'inc_day)

    writeToHive(spark,res,Seq("inc_day"),"dm_gis.TrajectoryAnomaly")

  }

}
