//package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature
//
//import com.alibaba.fastjson.{JSON, JSONObject}
//import com.sf.gis.java.base.util.BdpTaskRecordUtil
//import com.sf.map.{PointVector, TrackMath}
//import common.DataSourceCommon
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.expressions.Window
//import org.apache.spark.sql.functions._
//import org.apache.spark.sql.{Column, DataFrame, SparkSession}
//import utils.{CommonTools, DateUtil, SparkBuilder, SparkUtils}
//
//import java.util.List
//import scala.collection.JavaConversions.asScalaBuffer
//import scala.collection.mutable
//import scala.collection.mutable.{ArrayBuffer, ListBuffer}
//
///**
// * @author 01420395
// * @DESCRIPTION
// * 轨迹缺失表 需求ID 2145736   GIS-RSS-PNS：【实时交通】ETA feature信息落表需求_V1.0
// * 任务id：930982
// * @create 2023/12/06
// */
//object ETA_Feature_Main extends DataSourceCommon {
//
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//  case class QmParams(reqid: String, eta_act_tm: String, std_coords: String, sim: Double, vehicle_serial:String,eta_feature:String)
//
//  def main(args: Array[String]): Unit = {
//    val inc_day = args(0)
//    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
//    NativeUtil.InitFile(spark.sparkContext)
//
//    //获取任务监控数据
//    val logSqlDF = getLogSqlRdd(inc_day, spark).repartition(2000)
//
//    //补全历程和路桥信息
//    val etaTsWmpInfoToHiveDF = getetaTsWmpInfoToHive(inc_day, spark).repartition(2000)
//
//    val etaStdLineRecallDF = getEtaStdLineRecall(inc_day, spark).repartition(2000)
//
//
//    val jionDf = logSqlDF
//      .join(etaTsWmpInfoToHiveDF.distinct(), Seq("reqId"), "left")
//      .join(etaStdLineRecallDF.distinct(), Seq("gp"), "left").repartition(2000).limit(1000)
//
//
//    logger.error("jionDf数据量 : " + jionDf.count())
//
//
//    import spark.implicits._
//
//    val jionD1= jionDf
//      .filter(('actual_depart_tm isNotNull) &&  ('eta_act_time isNotNull)  && ('actual_arrive_tm isNotNull) && ('pickUpTm isNotNull)&& ('vehicle_serial isNotNull))
//
//    logger.error("jionD1 数据量 : " + jionD1.count())
//
//
//    val resultDF = jionD1.filter(row => {
//      val actual_depart_tm = row.getAs[String]("actual_depart_tm")
//      val actual_arrive_tm = row.getAs[String]("actual_arrive_tm")
//      val eta_act_time = row.getAs[String]("eta_act_time")
//
//      val actual_depart_tm_long = CommonTools.tranTimeToLong(actual_depart_tm)
//      val actual_arrive_tm_long = CommonTools.tranTimeToLong(actual_arrive_tm)
//      val eta_act_time_long = eta_act_time.toLong
//
//      val delta1 = actual_depart_tm_long/1000 - eta_act_time_long
//      val delta2 = actual_arrive_tm_long/1000 - eta_act_time_long
//      (delta1 <= 0) && (delta2 >= 0)
//    }).select(
//      'inc_day
//      , 'gp
//      , 'vehicle_serial
//      , 'actual_depart_tm
//      , 'actual_arrive_tm
//      , 'reqId
//      , 'points
//      , 'dataTime
//      , 'group_task
//      , 'taskId
//      , 'lineCode
//      , 'srcZoneId
//      , 'destZoneId
//      , 'eta_srcZoneCoordinate
//      , 'eta_destZoneCoordinate
//      , 'plate
//      , 'requestTime
//      , 'validTime
//      , 'eta_act_point
//      , 'eta_act_time
//      , 'etaMachineFeature
//    ).repartition(2000)
//
//    val resultDF2 = resultDF.select("inc_day", "gp", "vehicle_serial", "actual_depart_tm", "actual_arrive_tm", "reqId", "points", "dataTime",
//      "group_task", "taskId", "lineCode", "srcZoneId", "destZoneId", "eta_srcZoneCoordinate", "eta_destZoneCoordinate", "plate",
//      "requestTime", "validTime", "eta_act_point", "eta_act_time", "etaMachineFeature")
//
//    logger.error("resultDF2 数据量: " + resultDF2.count())
//    resultDF2.show(1, false)
//
//
//    //相识度
//    val httpInvokeId  = BdpTaskRecordUtil.startRunNetworkInterface(spark,"01420395"
//      ,"930982","ETA feature落表","ETA feature落表"
//      ,"http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail","571a61a2b89c4dcb962f9b4977119b37",resultDF2.count(),280
//    )
//
//    val resultDF3 = treat_similar(resultDF2)
//    logger.error("resultDF3 数据量: " + resultDF3.count())
//
//    BdpTaskRecordUtil.endNetworkInterface("01420395", httpInvokeId )
//
//    val resultDf44 = resultDF3.flatMap(ff => {
//      val qmParam = ff._3
//      val actual_arrive_tm = ff._5
//      //按任务分组,根据每个请求中的轨迹点查询qmpoint
//
//      val list  = ArrayBuffer[(String,String,String,String,String)]()
//      for (r <- qmParam){
//        val reqid = r.reqid
//        val eta_act_time = r.eta_act_tm
//        val eta_feature = r.eta_feature
//        val tm_s = eta_act_time.toLong / 1000 //转为时间戳:s
//        val tm_hive =  DateUtil.tranTstampToTime((tm_s - (tm_s % 120)).toString) //圆整后的时间,转为字符串
//        list.append((tm_hive,reqid,eta_feature,eta_act_time,actual_arrive_tm))
//      }
//      logger.error("======================================list" + list.size)
//      list.toSeq
//    })
//
//    logger.error("resultDf44 数据量: " + resultDf44.count())
//
//    val result4  =  spark.createDataFrame(resultDf44).toDF("tm_hive", "reqid", "eta_feature", "eta_act_time", "actual_arrive_tm")
//
//    logger.error("result 数据量: " + result4.count())
//    result4.show(1, false)
//
//    val resultDF5 = treat_assemble(spark, result4)
//      .select(
//        "reqid", "eta_ac_tm", "actural_arrive_tm", "eta_feature"
//      )
//      .withColumn("etl_time", lit(DateUtil.getCurrentDate("yyyyMMdd HH:mm:ss")))
//      .withColumn("inc_day",lit(inc_day))
//
//    logger.error("resultDF5 数据量: " + resultDF5.count())
//    resultDF5.show(1, false)
//
//    writeToHive(spark,resultDF5 ,Seq("inc_day"),"dm_gis.dwd_ETA_Feature")
//
//
//  }
//
//  def getStepDist(steps: List[List[QmStep]])={
//    var dist : Float = 0
//    steps.foreach(f => {
//      f.foreach(ff => {
//        dist += ff.distance
//      })
//    })
//    dist
//  }
//
//
//  def getQmpointStep(inJson: String)= {
//    val qmp = new QmPointQuery()
//    val steps = qmp.getQmpointStep(inJson)
//    steps
//  }
//
//
//  /*
//  *   查询qmpoint,("tm_hive", "link_id", "dir", "reqid", "pathIx", "stepIx", "linkIx", "duration", "rc", "dr_len", "lnk_type", "adcode", "fm", "length", "hasLight")
//  */
//  def treat_qmpoint(spark:SparkSession,df2 : RDD[(String, String, ListBuffer[QmParams],String,String)])={
//    import spark.implicits._
//
//    val df3 = df2.flatMap(ff => {
//      val qmParam = ff._3
//      val actual_arrive_tm = ff._5
//      //按任务分组,根据每个请求中的轨迹点查询qmpoint
//
//      val list  = ArrayBuffer[(String,String,String,String,String)]()
//      for (r <- qmParam){
//        val reqid = r.reqid
//        val eta_act_time = r.eta_act_tm
//        val eta_feature = r.eta_feature
//        val tm_s = eta_act_time.toLong / 1000 //转为时间戳:s
//        val tm_hive =  DateUtil.tranTstampToTime((tm_s - (tm_s % 120)).toString) //圆整后的时间,转为字符串
//        list.append((tm_hive,reqid,eta_feature,eta_act_time,actual_arrive_tm))
//      }
//      logger.error("======================================list" + list.size)
//      list.toSeq
//    })
//    val result  =  spark.createDataFrame(df3).toDF("tm_hive", "reqid", "eta_feature", "eta_act_time", "actual_arrive_tm")
//
//    result
//  }
//
//
//  //拆分的数据重组成json
//  def treat_assemble(spark: SparkSession, rst:DataFrame) = {
//    import spark.implicits._
//    val gp_merge = rst.groupByKey(f => {
//      (f.getAs[String]("tm_hive"), f.getAs[String]("reqid"))
//    })
//    var df_feature = gp_merge
//      .mapGroups { case (k, ff) => {
//        var reqid = k._2
//        var eta_feature = ""
//        var eta_ac_tm = ""
//        var actural_arrive_tm = ""
//        import scala.util.control.Breaks._
//        val gp_list = ff.toList
//        breakable(
//          gp_list.foreach(k => {
//            eta_feature = k.getAs[String]("eta_feature")
//            eta_ac_tm = k.getAs[String]("eta_act_time")
//            actural_arrive_tm = k.getAs[String]("actual_arrive_tm")
//            if (eta_feature.nonEmpty && eta_ac_tm.nonEmpty && actural_arrive_tm.nonEmpty)
//              break
//          })
//        )
//        (reqid, eta_ac_tm, actural_arrive_tm, eta_feature)
//      }
//      }
//      .filter(f => f._1.nonEmpty && f._2.nonEmpty && f._3.nonEmpty && f._4.nonEmpty) //某些特征值存在空值
//      .toDF("reqid", "eta_ac_tm", "actural_arrive_tm", "eta_feature")
//
//    df_feature
//  }
//
//
//  def getTrackPtsWithoutTime(inJson: String) = {
//    val tracks = new Tracks()
//    val ptStr = tracks.getTrackPtStrWithoutTime(inJson)
//    ptStr
//  }
//
//  //计算相似度,(group_task, eta_destZoneCoordinate,ListBuffer[QmParams])
//  def treat_similar(df: DataFrame) = {
//
//    //    val resultDF2 = resultDF.select("inc_day", "gp", "vehicle_serial", "actual_depart_tm", "actual_arrive_tm", "reqId", "points", "dataTime",
//    //      "group_task", "taskId", "lineCode", "srcZoneId", "destZoneId", "eta_srcZoneCoordinate", "eta_destZoneCoordinate", "plate",
//    //      "requestTime", "validTime", "eta_act_point", "eta_act_time", "etaMachineFeature")
//
//
//    val df1 = df.rdd.groupBy(ff => (ff.getAs[String]("group_task"), ff.getAs[String]("eta_destZoneCoordinate"))) //.repartition(10000)
//    val df2 = df1.map { case (k, f) => {
//      var vehicle_serial = ""
//      var actual_depart_tm = ""
//      var actual_arrive_tm = ""
//      import scala.util.control.Breaks._
//      val gp_list = f.toSeq
//      breakable(
//        for (a <- gp_list) {
//          vehicle_serial = a.getAs[String]("vehicle_serial")
//          actual_depart_tm = a.get(3).toString.replaceAll("-", "").replaceAll(":", "").replace(" ", "")
//          actual_arrive_tm = a.get(4).toString.replaceAll("-", "").replaceAll(":", "").replace(" ", "")
//          if (!vehicle_serial.isEmpty && !actual_depart_tm.isEmpty && !actual_arrive_tm.isEmpty) {
//            break
//          }
//        })
//
//      val responseJson = new JSONObject()
//      responseJson.put("un", vehicle_serial)
//      responseJson.put("beginDateTime", actual_depart_tm)
//      responseJson.put("endDateTime", actual_arrive_tm)
//      responseJson.put("unType", "0")
//      responseJson.put("type", "400")
//      responseJson.put("ak", "571a61a2b89c4dcb962f9b4977119b37")
//      responseJson.put("addpoint", "1")
//      val inJson = responseJson.toJSONString
//
//      logger.error("请求数据:" + inJson)
//      val trackStr = getTrackPts(inJson) //获取原始轨迹数据
//      logger.error("返回数据:" + trackStr)
//
//
//      //计算相似度
//      val lstQmParam = new ListBuffer[QmParams]
//      for (b <- gp_list) {
//        val reqid = b.getAs[String]("reqId")
//        val pts = b.get(6).toString
//        val pick_up_time = b.get(19).toString.toLong //s
//        val eta_feature = b.get(20).toString
//        val eta_act_time = (pick_up_time * 1000).toString //ms
//
//        logger.error("原始数据1: " + b)
//
//        val sim_res = processTracksSimilar(pts, trackStr, pick_up_time)
//
//        logger.error("原始数据: " + pts)
//        logger.error("相识度: " + sim_res)
//        if (sim_res >= 0.80) {
//        logger.error("相识度: " + sim_res)
//          lstQmParam += QmParams(reqid, eta_act_time, pts, sim_res, vehicle_serial, eta_feature) //new
//        }
//      }
//      (k._1, k._1, lstQmParam, actual_depart_tm, actual_arrive_tm)
//    }
//    }
//    df2
//  }
//
//  def getTrackPts(inJson: String)={
//    val tracks = new Tracks()
//    val ptStr = tracks.getTrackPtStr(inJson)
//    ptStr
//  }
//
//
//  //获取请求时间最近点到终点的轨迹点,eta_act_time单位为s
//  def get_point_by_time(tracks: String, eta_act_time: Long) = {
//    import com.sf.map.{TrackPoint}
//
//    val vec2 = new PointVector();
//    var pts2 = tracks.split("\\|")
//    var lasttime: Long = 0
//    var lastx = 0.0
//    var lasty = 0.0
//    var bOK = false
//    for (pt <- pts2) {
//      var p = pt.split(",")
//      if (p.size == 3) {
//        if (bOK == true) {
//          vec2.add(new TrackPoint(p(0).toString.toDouble, p(1).toString.toDouble))
//        }
//        else {
//          val curtime = p(2).toString.toInt //时间戳s
//          if (eta_act_time >= lasttime && eta_act_time <= curtime) {
//            bOK = true
//            if (math.abs(eta_act_time - lasttime) < math.abs(eta_act_time - curtime)) {
//              vec2.add(new TrackPoint(lastx, lasty))
//            }
//            vec2.add(new TrackPoint(p(0).toString.toDouble, p(1).toString.toDouble))
//          }
//          else {
//            lasttime = curtime
//            lastx = p(0).toString.toDouble
//            lasty = p(1).toString.toDouble
//          }
//        }
//      }
//    }
//    vec2
//  }
//
//  //1.处理轨迹点和完整轨迹点,计算相似度,pts是短的,tracks表示长的
//  def processTracksSimilar(pts: String, tracks: String, eta_act_time: Long): Double = {
//    //加载c++编译的so文件
//    NativeUtil.LoadLibray
//    import  com.sf.map.TrackPoint
//    val vec1 = new PointVector();//导航规划点
//    var pts1 = pts.split("\\|")
//    for (pt <- pts1) {
//      var p = pt.split(",")
//      if (p.size == 2) {
//        vec1.add(new TrackPoint(p(0).toString.toDouble, p(1).toString.toDouble))
//      }
//    }
//
//    val vec2 = get_point_by_time(tracks, eta_act_time)//实走轨迹点
//    var sim = 0.0
//    var sim1 = 0.0
//    //按最后终点距离过滤
//    val p1_size = vec1.size.toInt
//    val p2_size = vec2.size.toInt
//    if(p1_size == 0 || p2_size == 0){
//      return sim
//    }
//    val p1 = vec1.get(p1_size - 1)
//    val p2 = vec2.get(p2_size - 1)
//    val dist_dest = cal_dis(p1.getX, p1.getY, p2.getX, p2.getY)
//    if (dist_dest >= 2000) { //终点大于2km为异常轨迹
//      return sim
//    }
//    val p3 = vec1.get(0)
//    val p4 = vec2.get(0)
//    val dist_start = cal_dis(p3.getX,p3.getY,p4.getX,p4.getY)
//    if(dist_start > 3000){   //起点大于3km为异常轨迹
//      return sim
//    }
//
//    sim = TrackMath.CalTrackSimilarity(vec2, vec1, 10)
//    sim1 = TrackMath.CalTrackSimilarity(vec1, vec2, 10)
//    sim = math.min(sim,sim1)
//    return sim
//    0.0
//  }
//
//
//  def cal_dis(x1:Double, y1:Double, x2:Double, y2:Double) = {
//    val dx = x2 - x1
//    val dy = y2 - y1
//    val sx = dx * math.cos(y1 * 0.01745329252)
//    val res = math.sqrt(sx * sx + dy * dy) * 111195.0
//    res
//  }
//
//
//  /**
//   * 获取日志数据
//   *
//   * @param inc_day
//   * @param sparkSession
//   */
//  def getLogSqlRdd(inc_day: String, sparkSession: SparkSession) = {
//
//    val logSql =
//      s"""
//         |    select inc_day
//         |    ,log
//         |    from
//         |    dm_gis.gis_eta_query_log
//         |    where
//         |    inc_day='${inc_day}'
//         |    and log is not null
//         |    and log != '{}'
//         |
//         |""".stripMargin
//
//    logger.error("logSql   ：" + logSql)
//
//
//    val logSourceDF = sparkSession.sql(logSql)
//
//    logger.error("gis_eta_query_log 数据量: " + logSourceDF.count())
//
//    import sparkSession.implicits._
//
//    val logSourceRdd = logSourceDF.rdd.map(row => {
//      val inc_day = row.getAs[String]("inc_day")
//      val log = row.getAs[String]("log")
//      val logJsonObject = LogInfoParser.parseLog(log)
//
//      (logJsonObject.eta_type,
//        logJsonObject.sub_type,
//        inc_day,
//        logJsonObject.gp,
//        logJsonObject.reqId,
//        logJsonObject.points,
//        logJsonObject.dataTime,
//        logJsonObject.group_task,
//        logJsonObject.taskId,
//        logJsonObject.lineCode,
//        logJsonObject.srcZoneId,
//        logJsonObject.destZoneId,
//        logJsonObject.eta_srcZoneCoordinate,
//        logJsonObject.eta_destZoneCoordinate,
//        logJsonObject.plate,
//        logJsonObject.requestTime,
//        logJsonObject.validTime,
//        logJsonObject.eta_act_point,
//        logJsonObject.eta_act_time,
//        logJsonObject.etaMachineFeature
//      )
//    }
//    )
//
//    val logSourceDF3 = sparkSession.createDataFrame(logSourceRdd)
//      .toDF("eta_type", "sub_type", "inc_day", "gp", "reqId", "points", "dataTime", "group_task", "taskId", "lineCode", "srcZoneId",
//        "destZoneId", "eta_srcZoneCoordinate", "eta_destZoneCoordinate", "plate", "requestTime", "validTime", "eta_act_point",
//        "eta_act_time", "etaMachineFeature")
//
//      logger.error("logSourceDF3  数据量: " + logSourceDF3.count())
//    logSourceDF3.show(1, false)
//
//    val logSourceDF2 =logSourceDF3
//      .filter(('eta_type === "etaQuery") && ('sub_type === "queryLocationEta")
//        && ('gp isNotNull)
//        && ('reqId isNotNull)
//        && ('points isNotNull)
//        && ('group_task isNotNull)
//        && ('eta_destZoneCoordinate isNotNull)
//        && ('requestTime isNotNull)
//        && ('eta_act_time isNotNull)
//        && ('etaMachineFeature isNotNull)
//      )
//
//    logger.error("logSourceDF2  数据量: " + logSourceDF2.count())
//
//    logSourceDF2
//  }
//
//
//  /**
//   * 获取日志数据
//   *
//   * @param inc_day
//   * @param sparkSession
//   */
//  def getetaTsWmpInfoToHive(inc_day: String, sparkSession: SparkSession) = {
//
//    val end_inc_day  = DateUtil.getdaysBefore(inc_day,1,"yyyyMMdd")
//
//    val etaTsWmpInfoToHiveSql =
//      s"""
//         | select inc_day,info
//         |  from dm_gis.eta_ts_wmp_info_to_hive
//         |  where inc_day >= '${inc_day}' and inc_day <= '${end_inc_day}'
//         |  and info is not null
//         |  and info != '{}'
//         |""".stripMargin
//
//    logger.error("etaTsWmpInfoToHiveSql   ：" + etaTsWmpInfoToHiveSql)
//
//
//    val etaTsWmpInfoToHiveDF = sparkSession.sql(etaTsWmpInfoToHiveSql)
//
//    logger.error("eta_ts_wmp_info_to_hive 数据量: " + etaTsWmpInfoToHiveDF.count())
//
//
//    val etaTsWmpInfoToHiveRDd = etaTsWmpInfoToHiveDF.rdd.map(row => {
//      val inc_day = row.getAs[String]("inc_day")
//      val hive = row.getAs[String]("info")
//      val hiveJsonObject = HiveInfoParser.parserHive(hive)
//      (inc_day, hiveJsonObject.uid, hiveJsonObject.pickUpTm,hiveJsonObject.destZoneCoordinate, hiveJsonObject.status)
//    })
//
//    import sparkSession.implicits._
//    val etaTsWmpInfoToHiveDF1 = sparkSession.createDataFrame(etaTsWmpInfoToHiveRDd)
//      .toDF("inc_day", "uid", "pickUpTm", "destZoneCoordinate", "status")
//
//    val etaTsWmpInfoToHiveDF2 = etaTsWmpInfoToHiveDF1
//      .filter(('uid isNotNull)
//        && ('pickUpTm isNotNull)
//        && ('status =!= "1") && ('status =!= "2") && ('status =!= "3")
//      ).withColumn("rn", row_number() over (Window.partitionBy("uid").orderBy(desc("pickUpTm"))))
//
//    val resultDF = etaTsWmpInfoToHiveDF2
//      .filter('rn === 1)
//      .withColumn("reqId", 'uid)
//      .withColumn("pickUpTm", 'pickUpTm)
//      .withColumn("destZoneCoordinate", 'destZoneCoordinate)
//      .withColumn("status", 'status)
//      .select("reqId", "pickUpTm", "destZoneCoordinate", "status")
//    //      .filter('uid==="1730362223225262080")
//
//
//    logger.error("eta_ts_wmp_info_to_hive 数据量 " + resultDF.count())
//
//    resultDF
//
//  }
//
//  def format_decimal(column: Column, ndigits: Int):Column={
//    val num = column.toString()
//    val data = num.split("\\.") //注意:java必须是\\.
//    var a = ""
//    var b = ""
//    var res = ""
//    if(data.size == 2 ){
//      a = data(0)
//      if(data(1).length < ndigits){
//        b = data(1)
//      }else{
//        b = data(1).substring(0,ndigits)
//      }
//      res = f"${a}.${b}"
//    }
//    lit(res)
//  }
//
//
//  def format_decimal  =  (num: String, ndigits: Int) => {
//    val data = num.split("\\.") //注意:java必须是\\.
//    var a = ""
//    var b = ""
//    var res = ""
//    if(data.size == 2 ) {
//      a = data(0)
//      if (data(1).length < ndigits) {
//        b = data(1)
//      } else {
//        b = data(1).substring(0, ndigits)
//      }
//      res = f"${a}.${b}"
//    }
//    lit(res)
//  }
//
//  /**
//   * 获取日志数据
//   *
//   * @param inc_day
//   * @param sparkSession
//   */
//  def getEtaStdLineRecall(inc_day: String, sparkSession: SparkSession) = {
//
//    val end_inc_day  = DateUtil.getdaysBefore(inc_day,1,"yyyyMMdd")
//
//    val getEtaStdLineRecallSql =
//      s"""
//         |select
//         | task_id
//         |,start_dept
//         |,end_dept
//         |,concat(task_id,'_',start_dept,'_',end_dept) as group_task
//         |,vehicle_serial
//         |,plan_depart_tm
//         |,actual_depart_tm
//         |,plan_arrive_tm
//         |,actual_arrive_tm
//         |,end_longitude
//         |,end_latitude
//         |from dm_gis.eta_std_line_recall
//         |where inc_day >= '${inc_day}' and inc_day <= '${end_inc_day}'
//         |and if_evaluate_time = '1'
//         |and task_id is not null
//         |and start_dept is not null
//         |and end_dept is not null
//         |and vehicle_serial is not null
//         |and actual_depart_tm is not null
//         |and actual_arrive_tm is not null
//         |and end_longitude is not null
//         |and end_latitude is not null
//         |""".stripMargin
//
//    logger.error("getEtaStdLineRecallSql   ：" + getEtaStdLineRecallSql)
//
//    val getEtaStdLineRecallDF = sparkSession.sql(getEtaStdLineRecallSql)
//
//    import sparkSession.implicits._
//    import org.apache.spark.sql.functions._
//
//    //    sparkSession.udf.register("format_decimal", format_decimal)
//
//    val resultDF1 = getEtaStdLineRecallDF
//      .withColumn("end_longitude_round", concat(substring_index('end_longitude,".",1),lit("."),substring(substring_index('end_longitude,".",-1),0,6) ))
//
//      .withColumn("end_latitude_round",concat(substring_index('end_latitude,".",1),lit("."),substring(substring_index('end_latitude,".",-1),0,6) ))
//
//    resultDF1.show(1, false)
//    logger.error("eta_std_line_recall resultDF1  数据量 ：" + resultDF1.count())
//
//    val resultDF = resultDF1
//      .withColumn("gp", concat('group_task, lit("_"), 'end_longitude_round, lit("_"), 'end_latitude_round))
//      .filter(('gp isNotNull)  && ('vehicle_serial isNotNull) && ('actual_depart_tm isNotNull) && ('actual_arrive_tm isNotNull) )
//      .select('gp , 'vehicle_serial , 'actual_depart_tm , 'actual_arrive_tm)
//    //      .filter('gp==="010Y17742897_010WE_010CG_116.347348_40.086422")
//
//    logger.error("eta_std_line_recall  数据量 ：" + resultDF.count())
//
//    resultDF
//  }
//
//}
