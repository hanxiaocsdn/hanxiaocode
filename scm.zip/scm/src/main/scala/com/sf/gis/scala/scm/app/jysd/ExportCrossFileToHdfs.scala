package com.sf.gis.scala.scm.app.jysd

import com.sf.gis.scala.scm.app.etastdlinerecallvms.ExportEtastdlinerecallvmFromHive.hdfsFileReName
import org.apache.log4j.Logger
import utils.SparkBuilder


/*
 @author 01401062 任务id 773813
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/10/25

 经验速度cross 直方图, 依赖 任务 678182,678187
*/


object ExportCrossFileToHdfs {

  @transient lazy val logger: Logger = Logger.getLogger(ExportCrossFileToHdfs.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class experienceSpeed(
                              adcode:String,
                              swid_in:String,
                              dir:String,
                              time_range:String,
                              weekday:String,
                              speed_type:String,
                              frequecy:String
                            )




  def main(args: Array[String]): Unit = {

    val inc_day = args(0)

    logger.error("日期: "+ inc_day)
    start(inc_day)
  }



  def start(inc_day: String) = {
    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_experience_costs_info_half_year_histogram
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sourceRdd = spark.sql(sourceSql)

    logger.error("数据量 : "+ sourceRdd.count())
    val hdfsPath="/user/01420395/upload/data/export/jysd"

    val outPath = hdfsPath+"/"+inc_day+"/dm_gis.eta_experience_costs_info_half_year_histogram/"

    sourceRdd.coalesce(1).write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", ",")
      .csv(outPath)
    hdfsFileReName(spark,outPath, "cross_coss_"+inc_day+".csv")

  }
}