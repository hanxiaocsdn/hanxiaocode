package com.sf.gis.scala.scm.app.vehicleInsurance

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import com.sf.gis.scala.scm.app.vehicleInsurance.VehicleInsuranceRiskEvalMonth.{filterSort, topMatch}
import common.DataSourceCommon
import utils.{ColumnUtil, DateUtil, RedisUtils, SparkBuilder, StringUtils}

import scala.collection.mutable

/**
  * @description: 车辆风险安全year特征值表 448971  452386
  * @author 01418539 caojia
  * @date 2022/6/13 15:33
  */

case class CityProvModel(lpn: String,vehicle_color:String,
                         adcode_city_y1: String, adcode_city_cnt_y1: String, adcode_city_y2: String, adcode_city_cnt_y2: String, adcode_city_y3: String, adcode_city_cnt_y3: String,
                         adcode_prov_y1: String, adcode_prov_cnt_y1: String, adcode_prov_y2: String, adcode_prov_cnt_y2: String, adcode_prov_y3: String, adcode_prov_cnt_y3: String,
                         adcode_dist_city_y1: String, adcode_dist_city_dist_y1: String, adcode_dist_city_y2: String, adcode_dist_city_dist_y2: String, adcode_dist_city_y3: String, adcode_dist_city_dist_y3: String,
                         adcode_dist_prov_y1: String, adcode_dist_prov_dist_y1: String, adcode_dist_prov_y2: String, adcode_dist_prov_dist_y2: String, adcode_dist_prov_y3: String, adcode_dist_prov_dist_y3: String,
                         adcode_dura_city_y1: String, adcode_dura_city_duration_y1: String, adcode_dura_city_y2: String, adcode_dura_city_duration_y2: String, adcode_dura_city_duration_y3: String, adcode_dura_city_y3: String,
                         adcode_dura_prov_y1: String, adcode_dura_prov_cnt_y1: String, adcode_dura_prov_y2: String, adcode_dura_prov_cnt_y2: String, adcode_dura_prov_y3: String, adcode_dura_prov_cnt_y3: String)

object VehicleInsuranceRiskEvalFeature extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val o_table = args(1)
    val e_table = args(2)
    multiMonthCal(spark, o_table, e_table, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def multiMonthCal(spark: SparkSession, o_table: String, e_table: String, inc_day: String): Unit = {
    import spark.implicits._


    val bef_12month_first_day = DateUtil.getFirstDayofMonthBeforeOrAfter(inc_day, -12) // 12 month
    val bef_6month_first_day = DateUtil.getFirstDayofMonthBeforeOrAfter(inc_day, -6) // 6 month
    val bef_3month_first_day = DateUtil.getFirstDayofMonthBeforeOrAfter(inc_day, -3) // 3 month
    val month_last_day = DateUtil.getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月底最后一天

    logger.error("业务日期 :" + inc_day + " 业务日期  : " + inc_day )
    logger.error("当前时间 :" + DateUtil.getCurrentDate("yyyyMMdd"))
    logger.error("12开始日期 :" + bef_12month_first_day + " 6结束日期 : " + bef_6month_first_day )

    logger.error("3开始日期 :" + bef_3month_first_day + " 上月日期 : " + month_last_day )
    val month_12_dtl = spark.sql(
      s"""select *
         |from dm_gis.dwd_insurance_model_duration_dist_qgzh_month_dtl
         |where inc_day>='$bef_12month_first_day' and inc_day <= '$month_last_day'
         |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)



    val month_6_dtl = month_12_dtl.filter('inc_day >= bef_6month_first_day && 'inc_day <= month_last_day)
    val month_3_dtl = month_12_dtl.filter('inc_day >= bef_3month_first_day && 'inc_day <= month_last_day)
    //按已有表结构拼装字段
    val year_cols = spark.sql(s"""select * from dm_gis.dwd_insurance_model_duration_dist_qgzh_year_feature_dtl limit 0""").schema.map(_.name).map(col)

    val month_12_df = processYearFeature(spark, month_12_dtl, year_cols, month_last_day, "12")
    val month_6_df = processYearFeature(spark, month_6_dtl, year_cols, month_last_day, "6")
    val month_3_df = processYearFeature(spark, month_3_dtl, year_cols, month_last_day, "3")

    val res = month_12_df.union(month_6_df).union(month_3_df).repartition( 500)

    writeToHive(spark, res, Seq("inc_day", "months_flag"), e_table)

    month_12_dtl.unpersist()

    //redis 写入日期数据  YEARFEATURE_INCDAY 20230328
    val add = "gis-ass-adds-type-data1.cache.sfdc.com.cn:8001,gis-ass-adds-type-data2.cache.sfdc.com.cn:8001,gis-ass-adds-type-data3.cache.sfdc.com.cn:8001"
    val pd= "cnzifff5lf2csdvp"
    val materNam="GIS_ASS_ADDS_REDIS_TYPE_DATA_C01"
    val pool = RedisUtils.initJedisTestPool(add,materNam,pd)
    val jedis = pool.getResource

    var incDay = jedis.get("YEARFEATURE_INCDAY")

    if(StringUtils.isEmpty(incDay)){
      incDay = "0"
    }

    logger.error(month_last_day + ">>>>  当前的 YEARFEATURE_INCDAY >>> " + incDay)
    if(Integer.parseInt(incDay) < Integer.parseInt(month_last_day)){
      logger.error(s"dbSize:${jedis.dbSize()}")
      jedis.set("YEARFEATURE_INCDAY", month_last_day)
      logger.error( jedis.get("YEARFEATURE_INCDAY"))
    }

    pool.close()

  }

  def processYearFeature(spark: SparkSession, o_month_dtl: DataFrame, year_cols: Seq[Column], month_last_day: String, month_flag: String): DataFrame = {
    import spark.implicits._

    val o_month_cols: Seq[String] = o_month_dtl.schema.map(_.name)
    //part 1  16 里程dist year total /year max
    val o_yt_dist_cols_str = o_month_cols.filter(_.endsWith("_dist_mt"))

    val o_ym_dist_cols_str: Seq[String] = Seq(
      "total_dist_mm", "night_dirve_dist_mm", "before_dawn_drive_dist_mm", "early_morning_drive_dist_mm", "afternoon_drive_dist_mm", "dusk_drive_dist_mm",
      "high_speed_dist_mm", "state_road_dist_mm", "provincial_dist_mm", "county_dist_mm", "township_dist_mm", "dangerous_road_dist_mm",
      "high_accident_road_dist_mm", "school_road_dist_mm", "sharp_turn_road_dist_mm", "village_road_dist_mm")

    //part 2  14 时长dist year total /year max
    val o_yt_dura_cols_str = o_month_cols.filter(_.endsWith("_duration_mt"))

    val o_ym_dura_cols_str: Seq[String] = Seq(
      "total_duration_mm", "night_dirve_duration_mm", "before_dawn_drive_duration_mm", "early_morning_drive_duration_mm",
      "afternoon_drive_duration_mm", "dusk_drive_duration_mm", "dangerous_road_duration_mm", "high_accident_road_duration_mm", "school_road_duration_mm",
      "sharp_turn_road_duration_mm", "township_road_duration_mm", "over_speed_duration_mm", "over_speed_ser_duration_mm", "over_drive_duration_mm")

    //part 3  8 经过次数dist year total /year max
    val o_yt_road_cols_str = o_month_cols.filter(_.endsWith("_cnt_mt"))
    val o_ym_road_cols_str: Seq[String] = Seq(
      "lnk_cnt_mm", "dangerous_road_cnt_mm", "high_accident_road_cnt_mm", "school_road_cnt_mm", "sharp_turn_road_cnt_mm", "township_road_road_cnt_mm", "operation_cnt_mm", "operation_same_city_cnt_mm")

    //year total、year max
    val init_yt_cols_str = o_yt_dist_cols_str ++ o_yt_dura_cols_str ++ o_yt_road_cols_str
    val init_ym_cols_str = o_ym_dist_cols_str ++ o_ym_dura_cols_str ++ o_ym_road_cols_str
    //agg 字段
    //行驶里程 行驶时长 经过路口次数 year total
    val yt_cols_str = init_yt_cols_str.map(_.replace("_mt", "_yt"))
    val yt_cols = ColumnUtil.renameColumn(init_yt_cols_str.map(sum(_)), yt_cols_str)
    //行驶里程 行驶时长 经过路口次数 year max
    val ym_cols_str = init_ym_cols_str.map(_.replace("_mm", "_ym"))
    val ym_cols = ColumnUtil.renameColumn(init_ym_cols_str.map(max(_)), ym_cols_str)

    val ot_cols = Seq(
      min("first_track_eff_day").alias("first_track_eff_day"),
      sum("track_eff_days").alias("track_eff_days"),
      sum("track_eff_months").alias("track_eff_months")
    )

    val t1_cols = yt_cols ++ ym_cols ++ ot_cols

    //agg
    val dist_dura_road_df_tmp = o_month_dtl
      .withColumn("track_eff_months", lit(1))
      .withColumn("num", row_number().over(Window.partitionBy("lpn","vehicle_color").orderBy("inc_day")))
      .withColumn("first_track_eff_day", when('num === 1, 'first_track_eff_day).otherwise(""))
      .groupBy("lpn","vehicle_color")
      .agg(t1_cols.head, t1_cols.tail: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val dist_dura_road_df_cols = dist_dura_road_df_tmp.schema.map(_.name).map(col)
    //计算 月均
    //step1
    val add_dist_yad_cols = avgMonthAndYear(o_yt_dist_cols_str, 1)._1
    val add_dist_yam_cols = avgMonthAndYear(o_yt_dist_cols_str, 1)._2
    //step2
    val add_dura_yad_cols = avgMonthAndYear(o_yt_dura_cols_str, 1)._1
    val add_dura_yam_cols = avgMonthAndYear(o_yt_dura_cols_str, 1)._2
    //step3
    val add_road_yad_cols = avgMonthAndYear(o_yt_road_cols_str, 1)._1
    val add_road_yam_cols = avgMonthAndYear(o_yt_road_cols_str, 1)._2

    val add_avg_prop_cols = add_dist_yad_cols ++ add_dist_yam_cols ++ add_dura_yad_cols ++ add_dura_yam_cols ++ add_road_yad_cols ++ add_road_yam_cols

    val dist_dura_road_df = dist_dura_road_df_tmp.select(dist_dura_road_df_cols ++ add_avg_prop_cols: _*)

    //计算 月黄昏总里程/总里程 占比
    val dist_ymp_cols = avgMonthAndYear(o_yt_dist_cols_str, 2, "total_links_dist_mt")._3
    val dura_ymp_cols = avgMonthAndYear(o_yt_dura_cols_str, 2, "total_links_duration_mt")._3
    val t2_agg_cls = dist_ymp_cols ++ dura_ymp_cols

    val dist_dura_aggm_df = o_month_dtl
      .groupBy("lpn","vehicle_color")
      .agg(t2_agg_cls.head, t2_agg_cls.tail: _*)

    //map省 市拆分完的字段 一一对应
    val city_dura_map_cols = Seq("lpn","vehicle_color",
      "adcode_city_y1", "adcode_city_cnt_y1", "adcode_city_y2", "adcode_city_cnt_y2", "adcode_city_y3", "adcode_city_cnt_y3",
      "adcode_prov_y1", "adcode_prov_cnt_y1", "adcode_prov_y2", "adcode_prov_cnt_y2", "adcode_prov_y3", "adcode_prov_cnt_y3",
      "adcode_dist_city_y1", "adcode_dist_city_dist_y1", "adcode_dist_city_y2", "adcode_dist_city_dist_y2", "adcode_dist_city_y3", "adcode_dist_city_dist_y3",
      "adcode_dist_prov_y1", "adcode_dist_prov_dist_y1", "adcode_dist_prov_y2", "adcode_dist_prov_dist_y2", "adcode_dist_prov_y3", "adcode_dist_prov_dist_y3",
      "adcode_dura_city_y1", "adcode_dura_city_duration_y1", "adcode_dura_city_y2", "adcode_dura_city_duration_y2", "adcode_dura_city_y3", "adcode_dura_city_duration_y3",
      "adcode_dura_prov_y1", "adcode_dura_prov_cnt_y1", "adcode_dura_prov_y2", "adcode_dura_prov_cnt_y2", "adcode_dura_prov_y3", "adcode_dura_prov_cnt_y3")

    val city_prov_top_df = o_month_dtl.select("lpn", "vehicle_color","adcode_city_map", "adcode_prov_map", "adcode_dist_city_map", "adcode_dist_prov_map", "adcode_dura_city_map", "adcode_dura_prov_map")
      .withColumn("adcode_city_map", regexp_replace('adcode_city_map, "\\{|\\}| ", ""))
      .withColumn("adcode_prov_map", regexp_replace('adcode_prov_map, "\\{|\\}| ", ""))
      .withColumn("adcode_dist_city_map", regexp_replace('adcode_dist_city_map, "\\{|\\}| ", ""))
      .withColumn("adcode_dist_prov_map", regexp_replace('adcode_dist_prov_map, "\\{|\\}| ", ""))
      .withColumn("adcode_dura_city_map", regexp_replace('adcode_dura_city_map, "\\{|\\}| ", ""))
      .withColumn("adcode_dura_prov_map", regexp_replace('adcode_dura_prov_map, "\\{|\\}| ", ""))
      .groupBy("lpn","vehicle_color")
      .agg(
        concat_ws(",", collect_list("adcode_city_map")) as "adcode_city_map",
        concat_ws(",", collect_list("adcode_prov_map")) as "adcode_prov_map",
        concat_ws(",", collect_list("adcode_dist_city_map")) as "adcode_dist_city_map",
        concat_ws(",", collect_list("adcode_dist_prov_map")) as "adcode_dist_prov_map",
        concat_ws(",", collect_list("adcode_dura_city_map")) as "adcode_dura_city_map",
        concat_ws(",", collect_list("adcode_dura_prov_map")) as "adcode_dura_prov_map"
      )
      .map(row => {
        val un = row.getAs[String]("lpn")
        val vehicle_color = row.getAs[String]("vehicle_color")
        val adcode_city_map = row.getAs[String]("adcode_city_map")
        val adcode_prov_map = row.getAs[String]("adcode_prov_map")
        val adcode_dist_city_map = row.getAs[String]("adcode_dist_city_map")
        val adcode_dist_prov_map = row.getAs[String]("adcode_dist_prov_map")
        val adcode_dura_city_map = row.getAs[String]("adcode_dura_city_map")
        val adcode_dura_prov_map = row.getAs[String]("adcode_dura_prov_map")
        val a = getTopPolymer(adcode_city_map)
        val b = getTopPolymer(adcode_prov_map)
        val m = getTopPolymer(adcode_dist_city_map)
        val n = getTopPolymer(adcode_dist_prov_map)
        val x = getTopPolymer(adcode_dura_city_map)
        val y = getTopPolymer(adcode_dura_prov_map)
        CityProvModel(un, vehicle_color,a._1._1, a._1._2, a._2._1, a._2._2, a._3._1, a._3._2, b._1._1, b._1._2, b._2._1, b._2._2, b._3._1, b._3._2, m._1._1, m._1._2, m._2._1, m._2._2, m._3._1, m._3._2, n._1._1, n._1._2, n._2._1, n._2._2, n._3._1, n._3._2, x._1._1, x._1._2, x._2._1, x._2._2, x._3._1, x._3._2, y._1._1, y._1._2, y._2._1, y._2._2, y._3._1, y._3._2)
      }).toDF(city_dura_map_cols: _*)

    val res = dist_dura_road_df.join(city_prov_top_df, Seq("lpn","vehicle_color"), "left")
      .join(dist_dura_aggm_df, Seq("lpn","vehicle_color"), "left")
      .withColumn("months_flag", lit(month_flag))
      .withColumn("inc_day", lit(month_last_day))
      .select(year_cols: _*)
    res
  }

  def avgMonthAndYear(cols_str: Seq[String], flag: Int, filerCol: String = ""): (Seq[Column], Seq[Column], Seq[Column]) = {
    var add_yad_cols = Seq(lit(""))
    var add_yam_cols = Seq(lit(""))
    var add_ymp_cols = Seq(lit(""))

    if (flag == 1) {
      val yad_cols = cols_str.map(_.replace("_mt", "_yt")).map(col).map(x => when(col("track_eff_days") =!= 0, x / 'track_eff_days).otherwise(0))
      val yam_cols = cols_str.map(_.replace("_mt", "_yt")).map(col).map(x => when(col("track_eff_months") =!= 0, x / 'track_eff_months).otherwise(0))
      add_yad_cols = ColumnUtil.renameColumn(yad_cols, cols_str.map(_.replace("_mt", "_yad")))
      add_yam_cols = ColumnUtil.renameColumn(yam_cols, cols_str.map(_.replace("_mt", "_yam")))
    } else {
      val yp_cols = cols_str.filter(_ != filerCol).map(col).map(x => when(col(filerCol) =!= 0, x / col(filerCol)).otherwise(0))
      val newNames: Seq[String] = cols_str.filter(_ != filerCol).map(_.replace("_mt", "_yp"))
      val add_yp_cols = ColumnUtil.renameColumn(yp_cols, newNames)
      add_ymp_cols = ColumnUtil.renameColumn(add_yp_cols.map(max(_)), newNames)
    }
    (add_yad_cols, add_yam_cols, add_ymp_cols)
  }

  /**
    * 获取 省、市 维度数据top3 * 2 及 2类顺序组合---共8个字段
    *
    * @param adcode_str
    * @param flag int or double 类型数据标识
    * @return
    */
  def getTopPolymer(adcode_str: String): ((String, String), (String, String), (String, String)) = {
    val adcode_arr = adcode_str.split(",")

    val adcode_hm = new mutable.HashMap[String, Double]()

    for (i <- 0 until adcode_arr.length) {
      val kv_arr = adcode_arr(i).split("=")
      var key = ""
      var value = 0.0
      try {
        key = kv_arr(0)
        value = kv_arr(1).toDouble
      } catch {
        case e: Exception => logger.error("检查原数据中，字段是否是map形式,或为空" + e.getMessage)
      }
      if (adcode_hm.contains(key)) adcode_hm.put(key, adcode_hm.getOrElse(key, 0.0) + value) else adcode_hm.put(key, value)
    }

    val adcode_tup: Array[(String, Double)] = filterSort(adcode_hm)

    val top_adcode: ((String, String), (String, String), (String, String)) = topMatch(adcode_tup)
    val adcode_top_1 = top_adcode._1
    val adcode_top_2 = top_adcode._2
    val adcode_top_3 = top_adcode._3

    (adcode_top_1, adcode_top_2, adcode_top_3)
  }

}
