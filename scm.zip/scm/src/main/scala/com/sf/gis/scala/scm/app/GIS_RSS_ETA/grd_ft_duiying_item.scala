package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.{DateUtil, SparkBuilder, StringUtils}

import scala.collection.mutable.ArrayBuffer


/**
  *@author 01420395
  *@DESCRIPTION
  *需求ID 1861561 GIS-RSS-ETA：【时效专项】 一级护航干预指标监控线上化_V1.0
 * 任务id :  773891
  *任务依赖：
  *@create 2023/06/28
  */
object grd_ft_duiying_item  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val  duiying_itemDF = get_duiying_item(spark, inc_day)
    val  soc_alarmsDF = get_soc_alarms(spark, inc_day)


    val dm_soc_sys_dict_dtl_di = get_dm_soc_sys_dict_dtl_di(spark, inc_day) //大类
    val dm_soc_sys_dict_item_dtl_di = get_dm_soc_sys_dict_item_dtl_di(spark, inc_day) //小类
    val dm_ua_sys_dict_dtl_di = get_dm_ua_sys_dict_dtl_di(spark, inc_day) //护航结束原因

    val timeDf  =  getTimeDf(spark, inc_day)

    val  soc_alarmsDF2 =  soc_alarmsDF
      .join(dm_soc_sys_dict_dtl_di,soc_alarmsDF("def_major_reason")===dm_soc_sys_dict_dtl_di("value"),"left")
      .join(dm_soc_sys_dict_item_dtl_di,soc_alarmsDF("def_major_reason_item")===dm_soc_sys_dict_item_dtl_di("value"),"left")
      .join(dm_ua_sys_dict_dtl_di,soc_alarmsDF("def_end_type")===dm_ua_sys_dict_dtl_di("value"),"left")

    import spark.implicits._

    val resultDf = duiying_itemDF
      .join(soc_alarmsDF2,Seq("Group_ft_tm"),"left")
      .join(timeDf,Seq("task_id"),"left" )

    logger.error("duiying_itemDF >>> " + resultDf.count())


    import org.apache.spark.sql.functions._
    val resultDf3 = resultDf
      .withColumn("Relieve_tm",when(('def_e_time isNull) || ('Abnormal_relieve_tm isNull),"").otherwise(
        floor((unix_timestamp('Abnormal_relieve_tm,"yyyy-MM-dd HH:mm:ss") - unix_timestamp('def_e_time,"yyyy-MM-dd HH:mm:ss"))/60)
      ) )
      .withColumn("Relieve_tm2",when('def_task_alarm_state ===1 && 'Relieve_tm < 0,0)
        .otherwise('Relieve_tm))


    resultDf3.show(1)

    val resultDf4 =  resultDf3.select('Task_id
      ,'Now_level_create_tm
      ,'Abnormal_relieve_tm
      ,'Grd_ft_tm
      ,'Group_grd_tm
      ,'Group_ft_tm
      ,'alarm_id,
      'alarm_name,
      'alarm_time,
      'risk_level,
      'source,
      'data_source,
      'is_meddle,
      'meddle_remark,
      'handle_type,
      'ptype,
      'subtype,
      'uid,
      'grd_task_id,
      'grd_req_id,
      'grd_std_id,
      'grd_transoport_level,
      'grd_solution,
      'grd_save_speed,
      'grd_task_save_state,
      'grd_plan_arrive_tm,
      'grd_actual_depart_tm,
      'grd_plan_run_tm,
      'grd_plan_dtime,
      'grd_rt_dtime,
      'grd_remain_dis,
      'grd_remain_time,
      'grd_arrival_tm,
      'grd_count,
      'grd_src_citycode,
      'grd_dest_citycode,
      'grd_carrier_type,
      'grd_child_carrier_name,
      'grd_src_zone_code,
      'grd_dest_zone_code,
      'grd_dest_zone_coordinate,
      'bd_car_no,
      'bd_driver_name,
      'bd_driver_code,
      'bd_driver_mobile,
      'bd_sdriver_name,
      'bd_sdriver_code,
      'bd_sdriver_mobile,
      'bd_dept_code,
      'bd_dept_name,
      'ft_alarm_id,
      'ft_ptype,
      'ft_subtype,
      'te_imei,
      'te_serial_no,
      'te_tts,
      'te_type,
      'te_vedio_path,
      'lng,
      'lat,
      'tf_flag,
      'tts_type,
      'tts_no_reason,
      'def_end_type,
      'def_end_desc,
      'def_result,
      'def_need_type,
      'def_no_reason,
      'def_status,
      'def_emp_code,
      'def_emp_id,
      'def_duration_tm,
      'def_s_time,
      'def_e_time,
      'def_pf_sl_nl_fit,
      'def_pf_saveline_type,
      'def_pf_cl_sl_fit,
      'def_pf_phone_on,
      'def_pf_phone_true,
      'def_pf_dr_coo,
      'def_no_qualified_reason,
      'def_no_qualified_desc,
      'def_qualified,
      'def_pf_sup_type,
      'def_mspeed_status,
      'def_mspeed_result,
      'def_pf_sup_nr,
      'def_stay_flag,
      'def_abnormal_stay_time,
      'def_continue_tm,
      'navi_save_status,
      'meddle_work_order_id,
      'create_time,
      'update_time,
      'te_speed,
      'average_speed,
      'alarm_status,
      'is_show,
      'grd_punctual,
      'grd_actual_arrive_tm,
      'alarm_work_order_id,
      'timeliness_state,
      'timeout_state,
      'grd_secure_state,
      'def_active_time,
      'def_non_result,
      'def_upgrade_mgr,
      'def_already_upgrade_mgr,
      'def_respond_tm,
      'def_handle_tm,
      'meddle_resource_id,
      'alarm_resource_id,
      'def_upgrade_carrier,
      'vms_gps_time,
      'vms_send_time,
      'vms_end_time,
      'grd_start_update_tm,
      'def_con_phone,
      'def_special_memo,
      'def_major_alarm,
      'def_major_reason,
      'def_major_reason_item,
      'def_major_memo,
      'def_objective_alarm,
      'def_task_alarm_state,
      'grd_plan_depart_tm,
      'def_car_driver_mate,
      'def_non_upgrade_reason,
      'def_carrier_upgrade_mgr
      ,'Big_type
      ,'small_type
      ,'End_cause
      ,'Relieve_tm
      ,'Relieve_tm2
      ,'actual_run_time
      ,'line_time
      ,'delay_time
      ,'actual_depart_tm
      ,'actual_arrive_tm
      ,'inc_day).distinct()

    writeToHive(spark,resultDf4,Seq("inc_day"), "dm_gis.grd_ft_duiying_item")
  }


  /***
    * @param spark
    * @param inc_day
    * @return
    */

  def  get_duiying_item(spark :SparkSession, inc_day: String)= {
    val before3Day = DateUtil.getdaysBefore(inc_day,-4, "yyyyMMdd")

    val sql  =
      s"""
         |select
         |  task_id,Now_level_create_tm,Abnormal_relieve_tm,Grd_ft_tm,grd_start_update_tm, inc_day
         |from
         |  dm_gis.grd_ft_duiying
         |where
         |  inc_day <= '${inc_day}'
         |  and inc_day >= '${before3Day}'
       """.stripMargin

    logger.error(sql)

    val  sourceDF  = spark.sql(sql)

    logger.error("总数 : " + sourceDF.count())
    sourceDF.show(1)


    import org.apache.spark.sql.functions._
    import spark.implicits._

    val resultDF =  sourceDF.flatMap(row => {


      var Now_level_create_tm = row.getAs[String]("Now_level_create_tm")
      var Abnormal_relieve_tm =row.getAs[String]("Abnormal_relieve_tm")
      var Grd_ft_tm =row.getAs[String]("Grd_ft_tm")
      var grd_start_update_tm =row.getAs[String]("grd_start_update_tm")


      var inc_day =row.getAs[String]("inc_day")


      if(StringUtils.isEmpty(Now_level_create_tm)){
        Now_level_create_tm =""
      }

      if(StringUtils.isEmpty(Abnormal_relieve_tm)){
        Abnormal_relieve_tm =""
      }

      if(StringUtils.isEmpty(Grd_ft_tm)){
        Grd_ft_tm =""
      }

      val task_id =row.getAs[String]("task_id")


      val Now_level_create_tm_list = Now_level_create_tm.split("\\|",-1)
      val Abnormal_relieve_tm_list =Abnormal_relieve_tm.split("\\|",-1)
      val Grd_ft_tm_list =Grd_ft_tm.split("\\|",-1)
      val grd_start_update_tm_list =grd_start_update_tm.split("\\|",-1)



      val length = Now_level_create_tm_list.size
      var i  = 0

      val rowList  = new ArrayBuffer[(String ,String ,String , String,String, String)]()
      while (i<length){

        var Now_level_create = ""
        if(Now_level_create_tm_list.size>i){
          Now_level_create =  Now_level_create_tm_list(i)
        }

        var Abnormal_relieve = ""
        if(Abnormal_relieve_tm_list.size>i){
          Abnormal_relieve =  Abnormal_relieve_tm_list(i)
        }

        var Grd_ft = ""
        if(Grd_ft_tm_list.size>i){
          Grd_ft =  Grd_ft_tm_list(i)
        }

        var grd_start_update = ""
        if(grd_start_update_tm_list.size>i){
          grd_start_update =  grd_start_update_tm_list(i)
        }

        i = i + 1
        rowList.append((task_id,Now_level_create,Abnormal_relieve,Grd_ft,grd_start_update,inc_day))
      }
      rowList.toList
    }).toDF("Task_id","Now_level_create_tm","Abnormal_relieve_tm","Grd_ft_tm","grd_start_update_tm","inc_day")

    logger.error("展开总数 : " + resultDF.count())

    resultDF
      .withColumn("Group_grd_tm", concat_ws("_",'Task_id,'Now_level_create_tm))
      .withColumn("Group_ft_tm", concat_ws("_",'Task_id,'grd_start_update_tm))
      .drop('grd_start_update_tm)
  }



  /***
    * @param spark
    * @param inc_day
    * @return
    */
  def  get_soc_alarms(spark :SparkSession, inc_day: String)= {

    val before7Day =DateUtil.getdaysBefore(inc_day,-6,"yyyyMMdd")
    val after3Day =DateUtil.getdaysBefore(inc_day,3,"yyyyMMdd")


    val before0Day =DateUtil.getdaysBefore(inc_day,0,"yyyyMMdd", "yyyy-MM-dd")
    val before1Day =DateUtil.getdaysBefore(inc_day,-1,"yyyyMMdd", "yyyy-MM-dd")
    val before2Day =DateUtil.getdaysBefore(inc_day,-2,"yyyyMMdd", "yyyy-MM-dd")
    val before3Day =DateUtil.getdaysBefore(inc_day,-3,"yyyyMMdd", "yyyy-MM-dd")
    val before4Day =DateUtil.getdaysBefore(inc_day,-4,"yyyyMMdd", "yyyy-MM-dd")

    val sql  =
      s"""
      select   alarm_id,alarm_name,alarm_time,risk_level,source,data_source,is_meddle,meddle_remark,handle_type,ptype,subtype,uid,grd_task_id,grd_req_id,grd_std_id,grd_transoport_level,grd_solution,grd_save_speed,grd_task_save_state,grd_plan_arrive_tm,grd_actual_depart_tm,grd_plan_run_tm,grd_plan_dtime,grd_rt_dtime,grd_remain_dis,grd_remain_time,grd_arrival_tm,grd_count,grd_src_citycode,grd_dest_citycode,grd_carrier_type,grd_child_carrier_name,grd_src_zone_code,grd_dest_zone_code,grd_dest_zone_coordinate,bd_car_no,bd_driver_name,bd_driver_code,bd_driver_mobile,bd_sdriver_name,bd_sdriver_code,bd_sdriver_mobile,bd_dept_code,bd_dept_name,ft_alarm_id,ft_ptype,ft_subtype,te_imei,te_serial_no,te_tts,te_type,te_vedio_path,lng,lat,tf_flag,tts_type,tts_no_reason,def_end_type,def_end_desc,def_result,def_need_type,def_no_reason,def_status,def_emp_code,def_emp_id,def_duration_tm,def_s_time,def_e_time,def_pf_sl_nl_fit,def_pf_saveline_type,def_pf_cl_sl_fit,def_pf_phone_on,def_pf_phone_true,def_pf_dr_coo,def_no_qualified_reason,def_no_qualified_desc,def_qualified,def_pf_sup_type,def_mspeed_status,def_mspeed_result,def_pf_sup_nr,def_stay_flag,def_abnormal_stay_time,def_continue_tm,navi_save_status,meddle_work_order_id,create_time,update_time,te_speed,average_speed,alarm_status,is_show,grd_punctual,grd_actual_arrive_tm,alarm_work_order_id,timeliness_state,timeout_state,grd_secure_state,def_active_time,def_non_result,def_upgrade_mgr,def_already_upgrade_mgr,def_respond_tm,def_handle_tm,meddle_resource_id,alarm_resource_id,def_upgrade_carrier,vms_gps_time,vms_send_time,vms_end_time,grd_start_update_tm,def_con_phone,def_special_memo,def_major_alarm,def_major_reason,def_major_reason_item,def_major_memo,def_objective_alarm,def_task_alarm_state,grd_plan_depart_tm,def_car_driver_mate,def_non_upgrade_reason,def_carrier_upgrade_mgr,
       concat(grd_task_id,'_',grd_start_update_tm) as Group_ft_tm
         |    from
         |      dm_gis.soc_alarms
         |    where
         |      date_format(grd_plan_depart_tm, 'yyyy-MM-dd') in ('${before0Day}', '${before1Day}','${before2Day}','${before3Day}','${before4Day}')
         |      and subtype in ('1', '2', '4') --告警小类
         |      and ptype in ('2') --告警大类
         |      and data_source in ('6')
         |      and def_end_type != '0'
         |      and inc_day >= '${before7Day}'
         |      and inc_day <= '${after3Day}'
         |
       """.stripMargin

    logger.error(sql)

    val  sourceDF  = spark.sql(sql)


    logger.error(">>>>> soc_alarms " + sourceDF.count())

    sourceDF

  }



  /***
    * @param spark
    * @param inc_day
    * @return
    */
  def  get_dm_soc_sys_dict_dtl_di(spark :SparkSession, inc_day: String)= {

    val sql  =
      s"""
         |Select value, dsc as Big_type from
         |dm_gis_scm.dm_soc_sys_dict_dtl_di
         |
       """.stripMargin

    logger.error(sql)

    val  sourceDF  = spark.sql(sql)
    sourceDF

  }


  /***
    * @param spark
    * @param inc_day
    * @return
    */
  def  get_dm_soc_sys_dict_item_dtl_di(spark :SparkSession, inc_day: String)= {

    val sql  =
      s"""
         Select value,label as small_type from
         |dm_gis_scm.dm_soc_sys_dict_item_dtl_di
         |
       """.stripMargin

    logger.error(sql)

    val  sourceDF  = spark.sql(sql)
    sourceDF
  }


  /***
    * @param spark
    * @param inc_day
    * @return
    */
  def  get_dm_ua_sys_dict_dtl_di(spark :SparkSession, inc_day: String)= {

    val sql  =
      s"""
        Select value,label as End_cause from
         |dm_gis_scm.dm_ua_sys_dict_dtl_di where inc_day ='${inc_day}'
         |
       """.stripMargin

    logger.error(sql)

    val  sourceDF  = spark.sql(sql)
    sourceDF.show(1)
    sourceDF
  }

  /***
    * @param spark
    * @param inc_day
    * @return
    */
  def  getTimeDf(spark :SparkSession, inc_day: String)= {



    val after3Day =DateUtil.getdaysBefore(inc_day,3,"yyyyMMdd")



    val before0Day =DateUtil.getdaysBefore(inc_day,0,"yyyyMMdd")
    val before1Day =DateUtil.getdaysBefore(inc_day,-1,"yyyyMMdd")
    val before2Day =DateUtil.getdaysBefore(inc_day,-2,"yyyyMMdd")

    val before4Day =DateUtil.getdaysBefore(inc_day,-3,"yyyyMMdd")
    val before5Day =DateUtil.getdaysBefore(inc_day,-4,"yyyyMMdd")

    val before3Day =DateUtil.getdaysBefore(before5Day,-3,"yyyyMMdd")


    val sql  =
      s"""
      select distinct task_id, actual_run_time,line_time,delay_time,actual_depart_tm,actual_arrive_tm   from (
       select  task_id,
       actual_run_time,
       line_time,
       (line_time-actual_run_time) as delay_time,
       row_number()over(partition by task_id order by  inc_day desc) as rn,
       actual_depart_tm,
       actual_arrive_tm
       from dm_gis.eta_std_line_recall1
        where inc_day>='${before3Day}' and inc_day<= '${after3Day}'
        and date_format(plan_depart_tm, 'yyyyMMdd') in ('${before0Day}','${before1Day}','${before2Day}','${before4Day}','${before5Day}')
        ) t where t.rn =1
         |
       """.stripMargin


    logger.error(sql)

    val  sourceDF  = spark.sql(sql)
    sourceDF
  }
}
