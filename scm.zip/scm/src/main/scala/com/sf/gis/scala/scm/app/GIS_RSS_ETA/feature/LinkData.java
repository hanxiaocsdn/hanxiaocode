package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

import java.util.Objects;

/*
* @author:01408031
* 作为map中的key需要定义
* ps: 在IDEA中使用 ALT + INSERT可以快速帮我们实现equals和hashcode方法
* */
public class LinkData {
    public long link_id = 0;
    public int dir = 0;

    public  LinkData(){
    }

    public LinkData(long link, int dir){
        this.link_id= link;
        this.dir = dir;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinkData linkData = (LinkData) o;
        return link_id == linkData.link_id && dir == linkData.dir;
    }

    @Override
    public int hashCode() {
        return Objects.hash(link_id, dir);
    }
}
