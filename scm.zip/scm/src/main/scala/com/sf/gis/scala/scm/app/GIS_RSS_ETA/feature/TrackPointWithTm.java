package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

//轨迹点数据添加时间戳信息
public class TrackPointWithTm extends TrackPoint {
    public int tm = 0; //时间戳
    public TrackPointWithTm(){
        tm = 0;
    }
}
