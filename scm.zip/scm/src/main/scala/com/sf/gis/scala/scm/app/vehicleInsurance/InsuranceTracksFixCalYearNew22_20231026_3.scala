package com.sf.gis.scala.scm.app.vehicleInsurance

import java.util
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.java.scm.Utils.Rarefy.RarefyService
import com.sf.gis.java.scm.pojo.{Dot, Douglas2, Point}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DateTimeUtil, JSONUtils, SparkBuilder, SparkUtils, StringUtils}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION} 日结数据迭代 自动获取ak 数据进行分组 需求id 1834553
 GIS-RSS-SCM：【车险风险模型】保险数据处理-指标计算_V2.6_01420395_蔡国房
 @create 2022/5/25  任务id 441364
*/
object InsuranceTracksFixCalYearNew22_20231026_3 {

  @transient lazy val logger: Logger = Logger.getLogger(InsuranceTracksFixCalYearNew22_20231026_3.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  //  val fixUrl = "http://10.216.162.38:8080/drectify"
  val fixUrl = "http://10.242.162.66:8080/drectify"
  val fixUrl_38 = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/post?url=http://10.216.162.38:8080/drectify"

  val periodMap = new mutable.HashMap[String,(String,String)]()

  periodMap.put("night",("21:00:00","23:59:59"))
  periodMap.put("before_dawn",("00:00:00","03:59:59"))
  periodMap.put("early_morning",("07:00:00","09:59:59"))
  periodMap.put("afternoon",("13:00:00","15:59:59"))
  periodMap.put("dusk",("17:00:00","19:59:59"))


  case class res(un: String, total_dist: String, total_duration: String, drive_dist: String, night_dirve_dist: String, before_dawn_drive_dist: String, early_morning_drive_dist: String, afternoon_drive_dist: String, dusk_drive_dist: String, high_speed_dist: String, state_road_dist: String, provincial_dist: String, county_dist: String, township_dist: String, dangerous_road_dist: String, high_accident_road_dist: String, school_road_dist: String, sharp_turn_road_dist: String, village_road_dist: String,
                 drive_duration: String, drive_duration_array: String, night_dirve_duration: String, before_dawn_drive_duration: String, early_morning_drive_duration: String, afternoon_drive_duration: String, dusk_drive_duration: String, dangerous_road_duration: String, high_accident_road_duration: String, school_road_duration: String, sharp_turn_road_duration: String, township_road_duration: String, over_speed_duration: String, over_speed_ser_duration: String,
                 lnk_cnt: String, dangerous_road_cnt: String, high_accident_road_cnt: String, school_road_cnt: String, sharp_turn_road_cnt: String, township_road_road_cnt: String,
                 operation_cnt: String, operation_same_city_cnt: String, adcode_map: String, adcode_duration_map: String, adcode_dist_map: String, over_drive_duration: String,
                 night_high_speed_duration: String, night_state_road_duration: String, night_provincial_duration: String,
                 night_county_duration: String, night_township_duration: String, night_high_speed_dist: String, night_state_road_dist: String, night_provincial_dist: String,
                 night_county_dist: String, night_township_dist: String, night_dangerous_road_cnt: String, night_high_accident_road_cnt: String, night_school_road_cnt: String,
                 night_sharp_turn_road_cnt: String, night_township_road_cnt: String, night_lnk_cnt: String,
                 before_dawn_high_speed_duration: String, before_dawn_state_road_duration: String, before_dawn_provincial_duration: String, before_dawn_county_duration: String,
                 before_dawn_township_duration: String, before_dawn_high_speed_dist: String, before_dawn_road_dist: String, before_dawn_provincial_dist: String,
                 before_dawn_county_dist: String, before_dawn_township_dist: String, before_dawn_dangerous_road_cnt: String, before_dawn_high_accident_road_cnt: String,
                 before_dawn_school_road_cnt: String, before_dawn_sharp_turn_road_cnt: String, before_dawn_township_road_cnt: String, before_dawn_lnk_cnt: String,
                 early_morning_high_speed_duration: String, early_morning_state_road_duration: String,
                 early_morning_provincial_duration: String, early_morning_county_duration: String, early_morning_township_duration: String, early_morning_high_speed_dist: String,
                 early_morning_road_dist: String, early_morning_provincial_dist: String, early_morning_county_dist: String, early_morning_township_dist: String,
                 early_morning_dangerous_road_cnt: String, early_morning_high_accident_road_cnt: String, early_morning_school_road_cnt: String,
                 early_morning_sharp_turn_road_cnt: String, early_morning_township_road_cnt: String, early_morning_lnk_cnt: String,
                 afternoon_high_speed_duration: String, afternoon_state_road_duration: String, afternoon_provincial_duration: String,
                 afternoon_county_duration: String, afternoon_township_duration: String, afternoon_high_speed_dist: String, afternoon_road_dist: String,
                 afternoon_provincial_dist: String, afternoon_county_dist: String, afternoon_township_dist: String, afternoon_dangerous_road_cnt: String,
                 afternoon_high_accident_road_cnt: String, afternoon_school_road_cnt: String, afternoon_sharp_turn_road_cnt: String, afternoon_township_road_cnt: String,
                 afternoon_lnk_type_cnt: String,
                 dusk_high_speed_duration: String, dusk_state_road_duration: String,
                 dusk_provincial_duration: String, dusk_county_duration: String, dusk_township_duration: String, dusk_high_speed_dist: String, dusk_road_dist: String,
                 dusk_provincial_dist: String, dusk_county_dist: String, dusk_township_dist: String, dusk_dangerous_road_cnt: String, dusk_high_accident_road_cnt: String,
                 dusk_school_road_cnt: String, dusk_sharp_turn_road_cnt: String, dusk_township_road_cnt: String, dusk_lnk_type_cnt: String,
                 total_links_dist: String, total_links_duration: String, operation_same_prov_cnt: String, sc_table: String, lpn: String,
                 high_speed_duration: String, state_road_duration: String, provincial_duration: String, county_duration: String, township_duration: String, high_speed_lowspeed_duration: String
                )




  def rarefyCalNew(sourceRdd2: RDD[JSONObject], inc_day: String) = {

    val calTotalSourceRdd = sourceRdd2.map(x => {

      val un = x.getString("un")
      val ak = x.getString("ak")
      //按照un进行分组
      ((un, ak), x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).flatMap(x => {

      val list = x._2.toList
      //在此进行tm升序排序
      val listSort = list.sortBy(obj => {
        val tm = obj.getString("tm")
        tm
      })
      val listNew: java.util.List[Point] = new java.util.ArrayList[Point]()
      val points = listSort

      (0 to points.size - 1).foreach(i => {
        val p = points(i)
        val point = new Point()
        point.setLongitude(p.getDouble("zx"))
        point.setLatitude(p.getDouble("zy"))
        listNew.add(point)
      })

      //      val retain = RarefySrviceNew.getRarefy(listNew,0,listNew.size()-1,0.0005)

      val retain = Douglas2.getCompressList(listNew)

      //      val retain = RarefyService.douglasPeucker(listNew,0.005)
      val lest = retain.toArray()
      val tracks = new ArrayBuffer[JSONObject]()
      (0 to points.size - 1).foreach(i => {
        if (lest.contains(i))
          tracks.append(points(i))
      })

      tracks
    }).repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("rarefyCal的数据量为：" + calTotalSourceRdd.count())


    calTotalSourceRdd


  }


  /**
    *  过滤坐标为0 的数据, 并且在同一个时间 获取随速度 更大的一条数据
    * @param sourceRdd
    * @return
    */
  def calSourceRdd(sourceRdd: RDD[JSONObject]) = {

    val sourceRdd2 = sourceRdd.repartition(800).filter(x => {
      val zx = JSONUtils.getJsonValueDouble(x,"zx",0.0)
      val zy = JSONUtils.getJsonValueDouble(x,"zy",0.0)
      zx !=0 && zy != 0
    })
      .map(x => {
        val un = x.getString("un")
        val ak = x.getString("ak")
        val tm = x.getString("tm")
        ((un,ak,tm),x)
      })
      .reduceByKey((obj1,obj2) => mergeSource(obj1,obj2)).map(_._2)

    sourceRdd2

  }


  def mergeSource(obj1: JSONObject, obj2: JSONObject): JSONObject = {

    val sp1 = JSONUtils.getJsonValueDouble(obj1,"sp",0)
    val sp2 = JSONUtils.getJsonValueDouble(obj2,"sp",0)

    if (sp1 > sp2){
      obj1
    }else{
      obj2
    }

  }


  def rarefyCal(sourceRdd2: RDD[JSONObject], inc_day: String) = {

    val calTotalSourceRdd = sourceRdd2.map(x => {

      val un = x.getString("un")
      val ak = x.getString("ak")
      //按照un进行分组
      ((un,ak),x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).flatMap(x => {

      val list = x._2.toList
      //在此进行tm升序排序
      val listSort = list.sortBy(obj => {
        val tm = obj.getString("tm")
        tm
      })
      val listNew:java.util.List[Dot] = new java.util.ArrayList[Dot]()
      val dots = listSort

      (0 to dots.size-1).foreach(i=>{
        val p = dots(i).asInstanceOf[JSONObject]
        val dot = new Dot()
        dot.x = p.getDouble("zx")
        dot.y = p.getDouble("zy")
        listNew.add(dot)
      })

      val retain = RarefyService.douglasPeucker(listNew,0.00000005)

      val lest = retain.toArray()
      val tracks = new ArrayBuffer[JSONObject]()
      (0 to dots.size-1).foreach(i=>{
        if(lest.contains(i))
          tracks.append(dots(i))
      })

      tracks
    }).repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("rarefyCal的数据量为：" + calTotalSourceRdd.count())


    calTotalSourceRdd


  }

  def getSourceData(spark: SparkSession, inc_day: String) = {

    val curTimeStamp = DateTimeUtil.getCurDayTimeStamp(inc_day)
    val nextTimeStamp= DateTimeUtil.getCurDayTimeStamp(DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 1))

    val ak  = ""

    val cols = Seq("un","tp","zx","zy","ac","be","sp","tm","bk","ak")
    //    val sourceDf = spark.read
    //    logger.error(sql)

    val inputPath = "D:\\user\\01420395\\Downloads\\融合后数据 (4).csv"
    val sourceDf = spark.read
      .option("header", "false")
      .option("delimiter", "\\t")
      .option("inferSchema", true)
      .option("numPartitions", 1)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(1)
      .select(cols.map(col): _*)

    val sourceRdd = SparkUtils.getRowToJson(sourceDf,"Memory")

    val sourceRdd2 = calSourceRdd(sourceRdd)
    logger.error("sourceRdd2的数据量为：" + sourceRdd2.count())

    // TODO: 仅310，303 做轨迹抽稀、需简化逻辑，增加抽稀算法 和新的去重规则
    val rarefyRdd = if (ak.equals("310")  || ak.equals("303")) rarefyCal(sourceRdd2,inc_day) else sourceRdd2

    //    // TODO: 计算车牌号
    //    val sourceDf2 = spark.sql(sql2)
    //    logger.error(sql2)
    //    val lpnRddPre = SparkUtils.getRowToJson(sourceDf2,"Memory")
    //
    //    val lpnRdd = lpnRddPre.map(x => {
    //      val device_id = x.getString("device_id")
    //      (device_id,x)
    //    }).reduceByKey((obj1,obj2) => filterDeviceId(obj1,obj2)).map(_._2)
    val lpnRdd = null
    (rarefyRdd,lpnRdd)
  }


  def getSourceAkData(spark: SparkSession, inc_day: String) = {

    import org.apache.spark.sql.functions._
    val curTimeStamp = DateTimeUtil.getCurDayTimeStamp(inc_day)
    val nextTimeStamp= DateTimeUtil.getCurDayTimeStamp(DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 1))

    val sql =
      s"""
         |select
         |  ak
         |from
         |  dm_gis.esg_gis_loc_trajectory
         |where
         |  inc_day ='${inc_day}'
         |  and un ='41189253'
         |and
         |  tm >= '${curTimeStamp}'
         |and
         |  tm <= '${nextTimeStamp}'
         |  group by ak
       """.stripMargin

    val lists  = spark.sql(sql).withColumn("ak",collect_list("ak"))
      .collectAsList().get(0).getList[String](0)

    lists
  }



  def filterDeviceId(obj1: JSONObject, obj2: JSONObject) = {

    val bind_time1 = obj1.getString("bind_time")
    val source1 = obj1.getString("source")
    val bind_time2 = obj2.getString("bind_time")
    val source2 = obj2.getString("source")
    if (StringUtils.nonEmpty(source1) && source1.equals("ERP")) {
      obj1
    }else if (StringUtils.nonEmpty(source2) && source2.equals("ERP")){
      obj2
    }else if (StringUtils.nonEmpty(bind_time1) && StringUtils.nonEmpty(bind_time2) && bind_time1 > bind_time2){
      obj1
    }else{
      obj2
    }

  }


  def calOverSpeed(tracks: JSONArray, swidMap: util.HashMap[String, Int], swidRoadClassList: ArrayBuffer[String]) = {


    var over_speed_start = try {
      tracks.getJSONObject(0).getIntValue("time")
    } catch {
      case e: Exception => 0
    }
    var over_speed_end = try {
      tracks.getJSONObject(0).getIntValue("time")
    } catch {
      case e: Exception => 0
    }
    var is_over_speed = false
    var overSpeedDuration = 0


    var over_speed_start_ser = try {
      tracks.getJSONObject(0).getIntValue("time")
    } catch {
      case e: Exception => 0
    }
    var over_speed_end_ser = try {
      tracks.getJSONObject(0).getIntValue("time")
    } catch {
      case e: Exception => 0
    }
    var is_over_speed_ser = false
    var overSpeedSeriousDuration = 0

    val trackSize = tracks.size()
    var highRoadLowSpeedDuration = 0


    for (i <- 0 until (trackSize)) {
      val trackJo = tracks.getJSONObject(i)

      val tm = JSONUtils.getJsonValueInt(trackJo, "time", 0)
      val speed = JSONUtils.getJsonValueDouble(trackJo, "speed", 0)
      val swid = JSONUtils.getJsonValue(trackJo, "SWID", "")

      val speed_limit = swidMap.getOrDefault(swid, 120)


      // TODO: 增加高速道路低速行驶时长计算
      if (trackSize > 2 && i <= trackSize - 2 && speed < 60 && StringUtils.nonEmpty(swid) && swidRoadClassList.contains(swid)) {
        val trackJoNext = tracks.getJSONObject(i + 1)
        val tmNext = JSONUtils.getJsonValueInt(trackJoNext, "time", 0)
        val speedNext = JSONUtils.getJsonValueDouble(trackJoNext, "speed", 0)
        val swidNext = JSONUtils.getJsonValue(trackJoNext, "SWID", "")

        if (speedNext < 60 && StringUtils.nonEmpty(swidNext) && swidRoadClassList.contains(swidNext)) {
          if (tmNext - tm <= 600 && tmNext - tm > 0) highRoadLowSpeedDuration += (tmNext - tm)
        }

      }

      // 判断是否超速驾驶
      if (speed > 30) {
        //判断超速
        if (speed  > speed_limit) {
          // 如果已经超速驾驶，则更新终止时间
          if (is_over_speed) {
            over_speed_end = tm
            // 如果已经是最后一个元素
            if (i == tracks.size() - 1) {
              // 判断是否超过30s
              if (over_speed_end - over_speed_start >= 30) {
                overSpeedDuration += (over_speed_end - over_speed_start)
              }
            }
          } else {
            //初始化起始和终止位置
            over_speed_start = tm
            over_speed_end = tm
            is_over_speed = true
          }
        } else if (is_over_speed){
          // 判断起始和终止是否超过30s
          if (over_speed_end - over_speed_start >= 30) {
            overSpeedDuration += (over_speed_end - over_speed_start)
          }
          is_over_speed = false
        }
      } else {
        // 判断起始和终止是否超过30s
        if (is_over_speed && over_speed_end - over_speed_start >= 30) {
          overSpeedDuration += (over_speed_end - over_speed_start)
        }
        is_over_speed = false
      }

      // 判断是否严重超速驾驶
      if (speed > 30) {
        if (speed  > 1.2 * speed_limit) {
          // 如果已经超速驾驶，则更新终止时间
          if (is_over_speed_ser) {
            over_speed_end_ser = tm
            // 如果已经是最后一个元素
            if (i == tracks.size() - 1) {
              // 判断是否超过30s
              if (over_speed_end_ser - over_speed_start_ser >= 30) {
                overSpeedSeriousDuration += (over_speed_end_ser - over_speed_start_ser)
              }
            }
          } else {
            //初始化起始和终止位置
            over_speed_start_ser = tm
            over_speed_end_ser = tm
            is_over_speed_ser = true
          }
        } else if (is_over_speed_ser){
          // 判断起始和终止是否超过30s
          if (over_speed_end_ser - over_speed_start_ser >= 30) {
            overSpeedSeriousDuration += (over_speed_end_ser - over_speed_start_ser)
          }
          is_over_speed_ser = false
        }
      } else {
        // 判断起始和终止是否超过30s
        if (is_over_speed_ser && over_speed_end_ser - over_speed_start_ser >= 30) {
          overSpeedSeriousDuration += (over_speed_end_ser - over_speed_start_ser)
        }
        is_over_speed_ser = false
      }
    }

    (overSpeedDuration, overSpeedSeriousDuration, highRoadLowSpeedDuration)

  }

  def calDurationPart(tracks: JSONArray, inc_day: String) = {

    // TODO: 需要返回行驶时长，行驶时段，超时驾驶时长，运营次数，同城运营次数，运营起始城市次数
    val resJson = new JSONObject()

    // 初始化轨迹行驶起始、终止位置
    var start_time = try {
      tracks.getJSONObject(0).getIntValue("time")
    } catch {
      case e: Exception => 0
    }
    var end_time = try {
      tracks.getJSONObject(0).getIntValue("time")
    } catch {
      case e: Exception => 0
    }

    var start_adcode = try {
      tracks.getJSONObject(0).getIntValue("adcode")
    } catch {
      case e: Exception => 0
    }
    var end_adcode = try {
      tracks.getJSONObject(0).getIntValue("adcode")
    } catch {
      case e: Exception => 0
    }

    // 中断间隔
    var intervelTag = false

    var duration = 0

    val durationArray = new JSONArray()

    for (i <- 0 until (tracks.size() - 1)) {

      val track_per = tracks.getJSONObject(i)
      val track_cur = tracks.getJSONObject(i + 1)
      val x_per = JSONUtils.getJsonValueDouble(track_per, "x", 0)
      val y_per = JSONUtils.getJsonValueDouble(track_per, "y", 0)
      val tm_per = JSONUtils.getJsonValueInt(track_per, "time", 0)
      val status_per = JSONUtils.getJsonValueInt(track_per, "status", 0)
      val adcode_per = JSONUtils.getJsonValueInt(track_per, "adcode", 0)


      val x_cur = JSONUtils.getJsonValueDouble(track_cur, "x", 0)
      val y_cur = JSONUtils.getJsonValueDouble(track_cur, "y", 0)
      val tm_cur = JSONUtils.getJsonValueInt(track_cur, "time", 0)
      val status_cur = JSONUtils.getJsonValueInt(track_cur, "status", 0)
      val adcode_cur = JSONUtils.getJsonValueInt(track_cur, "adcode", 0)


      if ((tm_cur - tm_per > 600 || (status_per == 100 && status_cur == 100)) && intervelTag) {
        start_time = tm_cur
        start_adcode = adcode_cur
      } else {
        // 当前点和下一个点时间间隔超过600，或者是否是两个连续停留点，则为停留点
        if (tm_cur - tm_per > 600 || (status_per == 100 && status_cur == 100)) {
          //          intervelTag = true
          end_time = tm_per
          end_adcode = adcode_per
          val jsonArray = new JSONArray()
          jsonArray.add(start_time)
          jsonArray.add(end_time)

          jsonArray.add(start_adcode)
          jsonArray.add(end_adcode)
          durationArray.add(jsonArray)
          duration += (end_time - start_time)

          start_time = tm_cur
          start_adcode = adcode_cur
          intervelTag = true
        } else if (i == tracks.size() - 2 && intervelTag) {

          // 如果为最后点依然在判断，之前没有中断点
          end_time = tm_cur
          end_adcode = adcode_cur

          val jsonArray = new JSONArray()
          jsonArray.add(start_time)
          jsonArray.add(end_time)
          jsonArray.add(start_adcode)
          jsonArray.add(end_adcode)

          durationArray.add(jsonArray)
          duration += (end_time - start_time)
          intervelTag = true
        } else {
          intervelTag = false
        }

      }
    }


    var merge_start_tag = try {
      durationArray.getJSONArray(0).getIntValue(0)
    } catch {
      case e: Exception => 0
    }
    var merge_end_tag = try {
      durationArray.getJSONArray(0).getIntValue(1)
    } catch {
      case e: Exception => 0
    }
    val mergeDuration = new JSONArray()

    // 增加adcode判断
    var merge_start_adcode = try {
      durationArray.getJSONArray(0).getIntValue(2)
    } catch {
      case e: Exception => 0
    }
    var merge_end_adcode = try {
      durationArray.getJSONArray(0).getIntValue(3)
    } catch {
      case e: Exception => 0
    }

    for (j <- (0 until (durationArray.size() - 1))) {

      val end_tm_pre = durationArray.getJSONArray(j).getIntValue(1)
      val end_adcode_pre = durationArray.getJSONArray(j).getIntValue(3)

      val start_tm_cur = durationArray.getJSONArray(j + 1).getIntValue(0)
      val start_adcode_cur = durationArray.getJSONArray(j + 1).getIntValue(2)

      val end_tm_cur = durationArray.getJSONArray(j + 1).getIntValue(1)
      val end_adcode_cur = durationArray.getJSONArray(j + 1).getIntValue(3)

      if (start_tm_cur - end_tm_pre <= 1140) {
        merge_end_tag = end_tm_cur
        merge_end_adcode = end_adcode_cur

        //边界判断
        if (j == durationArray.size() - 2) {
          val jsonArray = new JSONArray()
          jsonArray.add(merge_start_tag)
          jsonArray.add(merge_end_tag)

          jsonArray.add(merge_start_adcode)
          jsonArray.add(merge_end_adcode)

          mergeDuration.add(jsonArray)
        }

      } else {
        // 将合并后的区间添加到新数组中
        val jsonArray = new JSONArray()
        jsonArray.add(merge_start_tag)
        jsonArray.add(merge_end_tag)
        jsonArray.add(merge_start_adcode)
        jsonArray.add(merge_end_adcode)

        mergeDuration.add(jsonArray)

        merge_start_tag = start_tm_cur
        merge_end_tag = end_tm_cur

        merge_start_adcode = start_adcode_cur
        merge_end_adcode = end_adcode_cur

        //边界判断
        if (j == durationArray.size() - 2) {
          val jsonArray = new JSONArray()
          jsonArray.add(merge_start_tag)
          jsonArray.add(merge_end_tag)
          jsonArray.add(merge_start_adcode)
          jsonArray.add(merge_end_adcode)
          mergeDuration.add(jsonArray)
        }
      }
    }


    // TODO: 计算超时驾驶时长和连续运营次数
    var overDirveAll = 0
    var operationCnt = 0
    var sameCityOperationCnt = 0
    val adcodeMap = new util.HashMap[Int, Int]()

    // TODO: 计算同省运营次数
    var sameProvinceCnt = 0

    //②计算夜间时长, 计算合并后每段夜间时长和总驾驶时长
    for (i <- (0 until (mergeDuration.size()))) {

      val start_duration = mergeDuration.getJSONArray(i).getIntValue(0)
      val end_duration = mergeDuration.getJSONArray(i).getIntValue(1)

      // 增加adcode统计
      var start_adcode = try {
        mergeDuration.getJSONArray(i).getIntValue(2)
      } catch {
        case e: Exception => 0
      }
      var end_adcode = try {
        mergeDuration.getJSONArray(i).getIntValue(3)
      } catch {
        case e: Exception => 0
      }

      val all_duration = end_duration - start_duration
      var night_duration_06 = 0

      val start_period = concatTimestamp(inc_day, "00:00:00")
      val end_period = concatTimestamp(inc_day, "06:00:00")


      if (start_duration >= start_period && start_duration <= end_period) {
        // TODO: 截取相应时间
        if (end_duration <= end_period) {
          night_duration_06 += (end_duration - start_duration)
        } else {
          night_duration_06 += (end_period - start_duration)
        }
      }
      var over_drive_duration = 0

      //  假设同一段连续驾驶，其在夜间的行驶时长是X，总行驶时长是Y，超时驾驶时长为C
      //  4h = 14400s
      //  1）X ≥4，C = Y-2；
      //  2）2≤ X ＜4，C = max(X-2,Y-4)；
      //  3）X <2，C = Y-4
      //  如果不跨天计算，只用考虑0~6点为夜间

      if (night_duration_06 >= 14400) {
        over_drive_duration = all_duration - 7200
      } else if (night_duration_06 >= 7200 && night_duration_06 < 14400) {
        over_drive_duration = Math.max(night_duration_06 - 7200, all_duration - 14400)
      } else if (night_duration_06 <= 7200 && all_duration - 14400 > 0) {
        over_drive_duration = all_duration - 14400
      } else {
        over_drive_duration = 0
      }

      // 计算运营次数
      if (all_duration > 1800) {
        operationCnt += 1
        // 判断是否是同城运营
        if (start_adcode != 0 && start_adcode.toString.size > 2 && end_adcode.toString.size > 2 && start_adcode.toString.dropRight(2).equals(end_adcode.toString.dropRight(2))) {
          sameCityOperationCnt += 1
        }
        // 判断是否是同省运营
        if (start_adcode != 0 && start_adcode.toString.size > 4 && end_adcode.toString.size > 4 && start_adcode.toString.dropRight(4).equals(end_adcode.toString.dropRight(4))) {
          sameProvinceCnt += 1
        }

        adcodeMap.put(start_adcode, adcodeMap.getOrDefault(start_adcode, 0) + 1)
        adcodeMap.put(end_adcode, adcodeMap.getOrDefault(end_adcode, 0) + 1)
      }

      overDirveAll += over_drive_duration
    }


    // TODO: 需要返回行驶时长，行驶时段，超时驾驶时长，运营次数，同城运营次数，运营起始城市次数

    resJson.put("driveDuration", duration)
    resJson.put("durationArray", durationArray)
    resJson.put("overDirveDuration", overDirveAll)
    resJson.put("operationCnt", operationCnt)
    resJson.put("sameCityOperationCnt", sameCityOperationCnt)
    resJson.put("sameProvinceCnt", sameProvinceCnt)
    resJson.put("adcodeMap", adcodeMap)

    resJson
  }

  /**
    * 解析返回swid字段
    *
    * @param tracks
    */


  def calSwidLinkMap(tracks: JSONArray) = {


    val buffer = new ArrayBuffer[JSONObject]()

    for (i <- (0 until (tracks.size()))) {
      buffer.append(tracks.getJSONObject(i))
    }

    val filterBuffer = buffer
      //        .filter(obj => {
      //          val swid = JSONUtils.getJsonValue(obj, "SWID", "")
      //          swid == "5290129"
      //        })
      .filter(obj => {
      val speed = JSONUtils.getJsonValueDouble(obj, "speed", 0)
      val swid = JSONUtils.getJsonValue(obj, "SWID", "")
      speed != 0 && StringUtils.nonEmpty(swid) && swid != "0"
    }).sortBy(obj => {
      JSONUtils.getJsonValueDouble(obj, "time", 0)
    })


    // TODO: 增加swid匹配link
    val swidLinkMap = new util.HashMap[String, (Int, Int)]()

    val swidAllMap = new util.HashMap[String, Int]()

    //    val trackSize = filterBuffer2.size
    val trackSize = filterBuffer.size


    var tmpJo = filterBuffer(0)


    for (k <- (1 until (trackSize))) {

      val trackJo = filterBuffer(k)
      val swid = JSONUtils.getJsonValue(trackJo, "SWID", "")
      val tm = JSONUtils.getJsonValueInt(trackJo, "time", 0)

      val tmpSwid = JSONUtils.getJsonValue(tmpJo, "SWID", "")
      val tmpTm = JSONUtils.getJsonValueInt(tmpJo, "time", 0)

      val trackJoI = filterBuffer(k - 1)
      val tmJoi = JSONUtils.getJsonValueInt(trackJoI, "time", 0)

      if (tmpSwid != swid || k == trackSize -1) {
        // 判断是否存储过此swid
        if (swidAllMap.containsKey(tmpSwid)) {
          // TODO: 动态更新最大索引
          val index = swidAllMap.getOrDefault(tmpSwid, 0) + 1
          swidAllMap.put(tmpSwid, index)
          swidLinkMap.put(tmpSwid + "_" + index.toString, (tmpTm, tmJoi))
        } else {
          swidAllMap.put(tmpSwid, 0)
          swidLinkMap.put(tmpSwid + "_" + "0", (tmpTm, tmJoi))
        }
        tmpJo = trackJo
      }

    }


    swidLinkMap

  }


  def calAllPeriod(links: JSONArray, swidTracksMap: util.HashMap[String, (Int, Int)]) = {


    val linksSwidMap = new util.HashMap[String,Int]()

    val buffer = new ArrayBuffer[JSONObject]()
    for (k <- (0 until (links.size()))) {
      val linksJo = links.getJSONObject(k)
      val swid_id = JSONUtils.getJsonValue(linksJo, "sw_id", "")

      val key = swid_id + "_" + linksSwidMap.getOrDefault(swid_id, 0).toString
      breakable {
        val (start_tm, end_tm) = if (swidTracksMap.containsKey(key)) swidTracksMap.getOrDefault(key, (0, 0)) else break

        linksSwidMap.put(swid_id, linksSwidMap.getOrDefault(swid_id, 0) + 1)

        linksJo.put("start_tm",start_tm)
        linksJo.put("end_tm",end_tm)

        buffer.append(linksJo)
      }
    }
    buffer

  }

  def calPeriodProcess(periodBuffer: ArrayBuffer[JSONObject],period: String) = {

    val resJson = new JSONObject()
    // TODO: 计算高速、国道、省道、县道、乡路 行驶里程
    val roadclassMapDist = new util.HashMap[Int,Double]()
    val roadclassMapDuration = new util.HashMap[Int,Double]()

    // TODO: 增加不同道路设施时长统计
    var furnitures_21 = 0
    var furnitures_6 = 0
    var furnitures_13 = 0
    var furnitures_3 = 0
    var furnitures_12 = 0

    // TODO: 计算经过路口次数
    var lnk_type_cnt = 0


    // TODO: 计算分时段里程和时长
    var total_links_duration = 0.0
    var total_links_dist = 0.0

    periodBuffer.sortBy(period => {
      val tm = JSONUtils.getJsonValueInt(period, "tm", 0)
    }).map(linksJo => {

      //          val links_length = JSONUtils.getJsonValueDouble(linksJo, "length", 0)
      val links_length = JSONUtils.getJsonValueInt(linksJo, "dr_length", 0)
      val links_duration = JSONUtils.getJsonValueDouble(linksJo, "duration", 0.0)
      val lnk_type_list = JSONUtils.getJsonValue(linksJo, "lnk_type", "-1").split("\\|")
      val adcode = linksJo.getString("adcode")

      // TODO: 计算分时段总里程和时长
      val roadclass = JSONUtils.getJsonValueInt(linksJo, "roadclass", -1)

      for (i <- (0 to (lnk_type_list.size -1))){
        val lnk_type = try {lnk_type_list(i).toInt} catch {case e:Exception => -1}
        // 计算经过路口次数
        if (lnk_type == 0 || lnk_type == 1 || lnk_type == 2) {
          lnk_type_cnt += 1
        }
      }
      // TODO: 存储roadclass里程 时长
      total_links_duration += links_duration

      roadclassMapDuration.put(roadclass,roadclassMapDuration.getOrDefault(roadclass,0) + links_duration)
      roadclassMapDist.put(roadclass,roadclassMapDist.getOrDefault(roadclass,0) + links_length)

      total_links_dist += links_length

      // TODO: 计算道路设施  furnitures
      val furnituresArray = linksJo.getJSONArray("furnitures")

      for (index <- (0 until(furnituresArray.size()))){

        val frunType = JSONUtils.getJsonValueInt(furnituresArray.getJSONObject(index),"type",0)
        if (frunType == 21) {
          furnitures_21 += 1
        }
        if (frunType == 6) {
          furnitures_6 += 1
        }
        if (frunType == 13) {
          furnitures_13 += 1
        }
        if (frunType == 3) {
          furnitures_3 += 1
        }
        if (frunType == 12) {
          furnitures_12 += 1
        }

      }
    })


    // TODO: 计算高速 国道 省道 县道 乡路 行驶里程 时长
    val roadclass0Dist = roadclassMapDist.getOrDefault(0,0)
    val roadclass1Dist = roadclassMapDist.getOrDefault(1,0)
    val roadclass2Dist = roadclassMapDist.getOrDefault(2,0)
    val roadclass3Dist = roadclassMapDist.getOrDefault(3,0)
    val roadclass4Dist = roadclassMapDist.getOrDefault(4,0)

    resJson.put("roadclass0Dist",roadclass0Dist)
    resJson.put("roadclass1Dist",roadclass1Dist)
    resJson.put("roadclass2Dist",roadclass2Dist)
    resJson.put("roadclass3Dist",roadclass3Dist)
    resJson.put("roadclass4Dist",roadclass4Dist)


    val roadclass0Duraion = roadclassMapDuration.getOrDefault(0,0)
    val roadclass1Duraion = roadclassMapDuration.getOrDefault(1,0)
    val roadclass2Duraion = roadclassMapDuration.getOrDefault(2,0)
    val roadclass3Duraion = roadclassMapDuration.getOrDefault(3,0)
    val roadclass4Duraion = roadclassMapDuration.getOrDefault(4,0)

    resJson.put("roadclass0Duraion",roadclass0Duraion)
    resJson.put("roadclass1Duraion",roadclass1Duraion)
    resJson.put("roadclass2Duraion",roadclass2Duraion)
    resJson.put("roadclass3Duraion",roadclass3Duraion)
    resJson.put("roadclass4Duraion",roadclass4Duraion)



    // TODO: 计算危险路段、事故高发路段、学校路段、急转弯路段、村庄路段 次数
    resJson.put("furnitures_21",furnitures_21)
    resJson.put("furnitures_6",furnitures_6)
    resJson.put("furnitures_13",furnitures_13)
    resJson.put("furnitures_3",furnitures_3)
    resJson.put("furnitures_12",furnitures_12)

    // TODO: 经过路口次数
    resJson.put("lnk_type_cnt",lnk_type_cnt)

    // TODO: 分时段标识
    resJson.put("period_length",total_links_dist)
    resJson.put("period_duration",total_links_duration)


    resJson.put("period",period)


    resJson

  }

  def filterPeriodDuration(buffer: ArrayBuffer[JSONObject], period: String, inc_day:String) = {

    val (start_period_pre,end_period_pre) = periodMap.getOrElse(period,("",""))

    val start_period = concatTimestamp(inc_day,start_period_pre)
    val end_period = concatTimestamp(inc_day,end_period_pre)

    val periodBuffer = buffer.filter(x => {
      val start_tm = JSONUtils.getJsonValueInt(x,"start_tm",0)
      val end_tm = JSONUtils.getJsonValueInt(x,"end_tm",0)

      ((start_tm >= start_period && start_tm <= end_period) || (end_tm >= start_period && end_tm <= end_period))
    })

    val resJson = calPeriodProcess(periodBuffer, period: String)

    resJson

  }

  def calFlatBuffer(bufferAll: ArrayBuffer[JSONObject]) = {

    // TODO: 将行转列 得到分时段时长和里程数据

    var night_duration = 0.0
    var before_dawn_duration =0.0
    var early_morning_duration = 0.0
    var afternoon_duration = 0.0
    var dusk_duration = 0.0

    var night_length = 0.0
    var before_dawn_length = 0.0
    var early_morning_length = 0.0
    var afternoon_length = 0.0
    var dusk_length = 0.0

    // TODO: 分时段设施 dist duration
    // TODO: night
    var night_roadclass0_duration = 0.0
    var night_roadclass1_duration = 0.0
    var night_roadclass2_duration = 0.0
    var night_roadclass3_duration = 0.0
    var night_roadclass4_duration = 0.0

    var night_roadclass0_dist = 0.0
    var night_roadclass1_dist = 0.0
    var night_roadclass2_dist = 0.0
    var night_roadclass3_dist = 0.0
    var night_roadclass4_dist = 0.0

    var night_furnitures_21 = 0
    var night_furnitures_6 = 0
    var night_furnitures_13 = 0
    var night_furnitures_3 = 0
    var night_furnitures_12 = 0

    var night_lnk_type_cnt =0

    // TODO: before_dawn
    var before_dawn_roadclass0_duration = 0.0
    var before_dawn_roadclass1_duration = 0.0
    var before_dawn_roadclass2_duration = 0.0
    var before_dawn_roadclass3_duration = 0.0
    var before_dawn_roadclass4_duration = 0.0

    var before_dawn_roadclass0_dist = 0.0
    var before_dawn_roadclass1_dist = 0.0
    var before_dawn_roadclass2_dist = 0.0
    var before_dawn_roadclass3_dist = 0.0
    var before_dawn_roadclass4_dist = 0.0

    var before_dawn_furnitures_21 = 0
    var before_dawn_furnitures_6 = 0
    var before_dawn_furnitures_13 = 0
    var before_dawn_furnitures_3 = 0
    var before_dawn_furnitures_12 = 0

    var before_dawn_lnk_type_cnt =0

    // TODO: early_morning
    var early_morning_roadclass0_duration = 0.0
    var early_morning_roadclass1_duration = 0.0
    var early_morning_roadclass2_duration = 0.0
    var early_morning_roadclass3_duration = 0.0
    var early_morning_roadclass4_duration = 0.0

    var early_morning_roadclass0_dist = 0.0
    var early_morning_roadclass1_dist = 0.0
    var early_morning_roadclass2_dist = 0.0
    var early_morning_roadclass3_dist = 0.0
    var early_morning_roadclass4_dist = 0.0

    var early_morning_furnitures_21 = 0
    var early_morning_furnitures_6 = 0
    var early_morning_furnitures_13 = 0
    var early_morning_furnitures_3 = 0
    var early_morning_furnitures_12 = 0

    var early_morning_lnk_type_cnt =0

    // TODO: afternoon
    var afternoon_roadclass0_duration = 0.0
    var afternoon_roadclass1_duration = 0.0
    var afternoon_roadclass2_duration = 0.0
    var afternoon_roadclass3_duration = 0.0
    var afternoon_roadclass4_duration = 0.0

    var afternoon_roadclass0_dist = 0.0
    var afternoon_roadclass1_dist = 0.0
    var afternoon_roadclass2_dist = 0.0
    var afternoon_roadclass3_dist = 0.0
    var afternoon_roadclass4_dist = 0.0

    var afternoon_furnitures_21 = 0
    var afternoon_furnitures_6 = 0
    var afternoon_furnitures_13 = 0
    var afternoon_furnitures_3 = 0
    var afternoon_furnitures_12 = 0

    var afternoon_lnk_type_cnt =0

    // TODO: dusk
    var dusk_roadclass0_duration = 0.0
    var dusk_roadclass1_duration = 0.0
    var dusk_roadclass2_duration = 0.0
    var dusk_roadclass3_duration = 0.0
    var dusk_roadclass4_duration = 0.0

    var dusk_roadclass0_dist = 0.0
    var dusk_roadclass1_dist = 0.0
    var dusk_roadclass2_dist = 0.0
    var dusk_roadclass3_dist = 0.0
    var dusk_roadclass4_dist = 0.0

    var dusk_furnitures_21 = 0
    var dusk_furnitures_6 = 0
    var dusk_furnitures_13 = 0
    var dusk_furnitures_3 = 0
    var dusk_furnitures_12 = 0

    var dusk_lnk_type_cnt =0


    // TODO: 分时段道路等级

    bufferAll.map(obj => {
      val period = obj.getString("period")
      val len = JSONUtils.getJsonValueDouble(obj,"period_length",0)
      val duration = JSONUtils.getJsonValueDouble(obj,"period_duration",0)

      // TODO: 道路等级
      val roadclass0Dist = JSONUtils.getJsonValueDouble(obj,"roadclass0Dist",0)
      val roadclass1Dist = JSONUtils.getJsonValueDouble(obj,"roadclass1Dist",0)
      val roadclass2Dist = JSONUtils.getJsonValueDouble(obj,"roadclass2Dist",0)
      val roadclass3Dist = JSONUtils.getJsonValueDouble(obj,"roadclass3Dist",0)
      val roadclass4Dist = JSONUtils.getJsonValueDouble(obj,"roadclass4Dist",0)

      val roadclass0Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass0Duraion",0)
      val roadclass1Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass1Duraion",0)
      val roadclass2Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass2Duraion",0)
      val roadclass3Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass3Duraion",0)
      val roadclass4Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass4Duraion",0)

      // TODO: 经过危险路段、事故高发、学校、急转弯、村庄次数
      val furnitures_21 = JSONUtils.getJsonValueInt(obj,"furnitures_21",0)
      val furnitures_6 = JSONUtils.getJsonValueInt(obj,"furnitures_6",0)
      val furnitures_13 = JSONUtils.getJsonValueInt(obj,"furnitures_13",0)
      val furnitures_3 = JSONUtils.getJsonValueInt(obj,"furnitures_3",0)
      val furnitures_12 = JSONUtils.getJsonValueInt(obj,"furnitures_12",0)

      // TODO: 经过路口次数
      val lnk_type_cnt = JSONUtils.getJsonValueInt(obj,"lnk_type_cnt",0)

      if(StringUtils.nonEmpty(period)){

        period match {
          case period if period.equals("night") =>
            night_duration +=duration
            night_length += len
            night_roadclass0_duration += roadclass0Duraion
            night_roadclass1_duration += roadclass1Duraion
            night_roadclass2_duration += roadclass2Duraion
            night_roadclass3_duration += roadclass3Duraion
            night_roadclass4_duration += roadclass4Duraion
            night_roadclass0_dist += roadclass0Dist
            night_roadclass1_dist += roadclass1Dist
            night_roadclass2_dist += roadclass2Dist
            night_roadclass3_dist += roadclass3Dist
            night_roadclass4_dist += roadclass4Dist
            night_furnitures_21 += furnitures_21
            night_furnitures_6 += furnitures_6
            night_furnitures_13 += furnitures_13
            night_furnitures_3 += furnitures_3
            night_furnitures_12 += furnitures_12
            night_lnk_type_cnt += lnk_type_cnt

          case period if period.equals("before_dawn") =>
            before_dawn_duration +=duration
            before_dawn_length += len
            before_dawn_roadclass0_duration += roadclass0Duraion
            before_dawn_roadclass1_duration += roadclass1Duraion
            before_dawn_roadclass2_duration += roadclass2Duraion
            before_dawn_roadclass3_duration += roadclass3Duraion
            before_dawn_roadclass4_duration += roadclass4Duraion
            before_dawn_roadclass0_dist += roadclass0Dist
            before_dawn_roadclass1_dist += roadclass1Dist
            before_dawn_roadclass2_dist += roadclass2Dist
            before_dawn_roadclass3_dist += roadclass3Dist
            before_dawn_roadclass4_dist += roadclass4Dist
            before_dawn_furnitures_21 += furnitures_21
            before_dawn_furnitures_6 += furnitures_6
            before_dawn_furnitures_13 += furnitures_13
            before_dawn_furnitures_3 += furnitures_3
            before_dawn_furnitures_12 += furnitures_12
            before_dawn_lnk_type_cnt += lnk_type_cnt
          case period if period.equals("early_morning") =>
            early_morning_duration +=duration
            early_morning_length += len
            early_morning_roadclass0_duration += roadclass0Duraion
            early_morning_roadclass1_duration += roadclass1Duraion
            early_morning_roadclass2_duration += roadclass2Duraion
            early_morning_roadclass3_duration += roadclass3Duraion
            early_morning_roadclass4_duration += roadclass4Duraion
            early_morning_roadclass0_dist += roadclass0Dist
            early_morning_roadclass1_dist += roadclass1Dist
            early_morning_roadclass2_dist += roadclass2Dist
            early_morning_roadclass3_dist += roadclass3Dist
            early_morning_roadclass4_dist += roadclass4Dist
            early_morning_furnitures_21 += furnitures_21
            early_morning_furnitures_6 += furnitures_6
            early_morning_furnitures_13 += furnitures_13
            early_morning_furnitures_3 += furnitures_3
            early_morning_furnitures_12 += furnitures_12
            early_morning_lnk_type_cnt += lnk_type_cnt
          case period if period.equals("afternoon") =>
            afternoon_duration +=duration
            afternoon_length += len
            afternoon_roadclass0_duration += roadclass0Duraion
            afternoon_roadclass1_duration += roadclass1Duraion
            afternoon_roadclass2_duration += roadclass2Duraion
            afternoon_roadclass3_duration += roadclass3Duraion
            afternoon_roadclass4_duration += roadclass4Duraion
            afternoon_roadclass0_dist += roadclass0Dist
            afternoon_roadclass1_dist += roadclass1Dist
            afternoon_roadclass2_dist += roadclass2Dist
            afternoon_roadclass3_dist += roadclass3Dist
            afternoon_roadclass4_dist += roadclass4Dist
            afternoon_furnitures_21 += furnitures_21
            afternoon_furnitures_6 += furnitures_6
            afternoon_furnitures_13 += furnitures_13
            afternoon_furnitures_3 += furnitures_3
            afternoon_furnitures_12 += furnitures_12
            afternoon_lnk_type_cnt += lnk_type_cnt
          case period if period.equals("dusk") =>
            dusk_duration +=duration
            dusk_length += len
            dusk_roadclass0_duration += roadclass0Duraion
            dusk_roadclass1_duration += roadclass1Duraion
            dusk_roadclass2_duration += roadclass2Duraion
            dusk_roadclass3_duration += roadclass3Duraion
            dusk_roadclass4_duration += roadclass4Duraion
            dusk_roadclass0_dist += roadclass0Dist
            dusk_roadclass1_dist += roadclass1Dist
            dusk_roadclass2_dist += roadclass2Dist
            dusk_roadclass3_dist += roadclass3Dist
            dusk_roadclass4_dist += roadclass4Dist
            dusk_furnitures_21 += furnitures_21
            dusk_furnitures_6 += furnitures_6
            dusk_furnitures_13 += furnitures_13
            dusk_furnitures_3 += furnitures_3
            dusk_furnitures_12 += furnitures_12
            dusk_lnk_type_cnt += lnk_type_cnt
        }
      }
    })

    val json = new JSONObject()

    // TODO: night
    json.put("night_duration",night_duration)
    json.put("night_length",night_length)
    json.put("night_roadclass0_duration",night_roadclass0_duration)
    json.put("night_roadclass1_duration",night_roadclass1_duration)
    json.put("night_roadclass2_duration",night_roadclass2_duration)
    json.put("night_roadclass3_duration",night_roadclass3_duration)
    json.put("night_roadclass4_duration",night_roadclass4_duration)
    json.put("night_roadclass0_dist",night_roadclass0_dist)
    json.put("night_roadclass1_dist",night_roadclass1_dist)
    json.put("night_roadclass2_dist",night_roadclass2_dist)
    json.put("night_roadclass3_dist",night_roadclass3_dist)
    json.put("night_roadclass4_dist",night_roadclass4_dist)
    json.put("night_furnitures_21",night_furnitures_21)
    json.put("night_furnitures_6",night_furnitures_6)
    json.put("night_furnitures_13",night_furnitures_13)
    json.put("night_furnitures_3",night_furnitures_3)
    json.put("night_furnitures_12",night_furnitures_12)
    json.put("night_lnk_type_cnt",night_lnk_type_cnt)
    // TODO: before_dawn
    json.put("before_dawn_duration",before_dawn_duration)
    json.put("before_dawn_length",before_dawn_length)
    json.put("before_dawn_roadclass0_duration",before_dawn_roadclass0_duration)
    json.put("before_dawn_roadclass1_duration",before_dawn_roadclass1_duration)
    json.put("before_dawn_roadclass2_duration",before_dawn_roadclass2_duration)
    json.put("before_dawn_roadclass3_duration",before_dawn_roadclass3_duration)
    json.put("before_dawn_roadclass4_duration",before_dawn_roadclass4_duration)
    json.put("before_dawn_roadclass0_dist",before_dawn_roadclass0_dist)
    json.put("before_dawn_roadclass1_dist",before_dawn_roadclass1_dist)
    json.put("before_dawn_roadclass2_dist",before_dawn_roadclass2_dist)
    json.put("before_dawn_roadclass3_dist",before_dawn_roadclass3_dist)
    json.put("before_dawn_roadclass4_dist",before_dawn_roadclass4_dist)
    json.put("before_dawn_furnitures_21",before_dawn_furnitures_21)
    json.put("before_dawn_furnitures_6",before_dawn_furnitures_6)
    json.put("before_dawn_furnitures_13",before_dawn_furnitures_13)
    json.put("before_dawn_furnitures_3",before_dawn_furnitures_3)
    json.put("before_dawn_furnitures_12",before_dawn_furnitures_12)
    json.put("before_dawn_lnk_type_cnt",before_dawn_lnk_type_cnt)
    // TODO: early_morning
    json.put("early_morning_duration",early_morning_duration)
    json.put("early_morning_length",early_morning_length)
    json.put("early_morning_roadclass0_duration",early_morning_roadclass0_duration)
    json.put("early_morning_roadclass1_duration",early_morning_roadclass1_duration)
    json.put("early_morning_roadclass2_duration",early_morning_roadclass2_duration)
    json.put("early_morning_roadclass3_duration",early_morning_roadclass3_duration)
    json.put("early_morning_roadclass4_duration",early_morning_roadclass4_duration)
    json.put("early_morning_roadclass0_dist",early_morning_roadclass0_dist)
    json.put("early_morning_roadclass1_dist",early_morning_roadclass1_dist)
    json.put("early_morning_roadclass2_dist",early_morning_roadclass2_dist)
    json.put("early_morning_roadclass3_dist",early_morning_roadclass3_dist)
    json.put("early_morning_roadclass4_dist",early_morning_roadclass4_dist)
    json.put("early_morning_furnitures_21",early_morning_furnitures_21)
    json.put("early_morning_furnitures_6",early_morning_furnitures_6)
    json.put("early_morning_furnitures_13",early_morning_furnitures_13)
    json.put("early_morning_furnitures_3",early_morning_furnitures_3)
    json.put("early_morning_furnitures_12",early_morning_furnitures_12)
    json.put("early_morning_lnk_type_cnt",early_morning_lnk_type_cnt)

    // TODO: afternoon
    json.put("afternoon_duration",afternoon_duration)
    json.put("afternoon_length",afternoon_length)
    json.put("afternoon_roadclass0_duration",afternoon_roadclass0_duration)
    json.put("afternoon_roadclass1_duration",afternoon_roadclass1_duration)
    json.put("afternoon_roadclass2_duration",afternoon_roadclass2_duration)
    json.put("afternoon_roadclass3_duration",afternoon_roadclass3_duration)
    json.put("afternoon_roadclass4_duration",afternoon_roadclass4_duration)
    json.put("afternoon_roadclass0_dist",afternoon_roadclass0_dist)
    json.put("afternoon_roadclass1_dist",afternoon_roadclass1_dist)
    json.put("afternoon_roadclass2_dist",afternoon_roadclass2_dist)
    json.put("afternoon_roadclass3_dist",afternoon_roadclass3_dist)
    json.put("afternoon_roadclass4_dist",afternoon_roadclass4_dist)
    json.put("afternoon_furnitures_21",afternoon_furnitures_21)
    json.put("afternoon_furnitures_6",afternoon_furnitures_6)
    json.put("afternoon_furnitures_13",afternoon_furnitures_13)
    json.put("afternoon_furnitures_3",afternoon_furnitures_3)
    json.put("afternoon_furnitures_12",afternoon_furnitures_12)
    json.put("afternoon_lnk_type_cnt",afternoon_lnk_type_cnt)

    // TODO: dusk
    json.put("dusk_duration",dusk_duration)
    json.put("dusk_length",dusk_length)
    json.put("dusk_roadclass0_duration",dusk_roadclass0_duration)
    json.put("dusk_roadclass1_duration",dusk_roadclass1_duration)
    json.put("dusk_roadclass2_duration",dusk_roadclass2_duration)
    json.put("dusk_roadclass3_duration",dusk_roadclass3_duration)
    json.put("dusk_roadclass4_duration",dusk_roadclass4_duration)
    json.put("dusk_roadclass0_dist",dusk_roadclass0_dist)
    json.put("dusk_roadclass1_dist",dusk_roadclass1_dist)
    json.put("dusk_roadclass2_dist",dusk_roadclass2_dist)
    json.put("dusk_roadclass3_dist",dusk_roadclass3_dist)
    json.put("dusk_roadclass4_dist",dusk_roadclass4_dist)
    json.put("dusk_furnitures_21",dusk_furnitures_21)
    json.put("dusk_furnitures_6",dusk_furnitures_6)
    json.put("dusk_furnitures_13",dusk_furnitures_13)
    json.put("dusk_furnitures_3",dusk_furnitures_3)
    json.put("dusk_furnitures_12",dusk_furnitures_12)
    json.put("dusk_lnk_type_cnt",dusk_lnk_type_cnt)


    json

  }
  def calCombineLinks(paths: JSONArray) = {

    val linksNew = new ArrayBuffer[JSONObject]()

    for (i <- (0 until (paths.size))) {
      val jo = paths.getJSONObject(i)
      val duration = JSONUtils.getJsonValueDouble(jo, "duration", 0)

      val steps = jo.getJSONArray("steps")
      for (j <- (0 until (steps.size()))) {
        val stepsJo = steps.getJSONObject(j)
        val links = stepsJo.getJSONArray("links")

        for (k <- (0 until (links.size()))) {
          val linksJo = links.getJSONObject(k)
          linksNew.append(linksJo)
        }
      }
    }

    println(linksNew.size)

    val linksNew2 = new JSONArray()

    var tempLinksJo = new JSONObject()
    for (i <- (0 until (linksNew.size))) {

      val linksJo = linksNew(i)
      val swid_id = JSONUtils.getJsonValue(linksJo, "sw_id", "")

      val links_duration = JSONUtils.getJsonValueDouble(linksJo, "duration", 0.0)
      val lnk_type = JSONUtils.getJsonValue(linksJo, "lnk_type", "-1")
      val furnituresArray = linksJo.getJSONArray("furnitures")

      val swid_id_tmp = JSONUtils.getJsonValue(tempLinksJo, "sw_id", "")

      if (StringUtils.nonEmpty(swid_id_tmp) && swid_id_tmp.equals(swid_id)){
        val links_length_tmp = JSONUtils.getJsonValueDouble(tempLinksJo, "dr_length", 0)
        val duration_tmp = JSONUtils.getJsonValueDouble(tempLinksJo, "duration", 0) + links_duration
        val lnk_type_tmp = JSONUtils.getJsonValue(tempLinksJo, "lnk_type", "-1") + "|" + lnk_type

        val furnituresArray_tmp = tempLinksJo.getJSONArray("furnitures")
        furnituresArray_tmp.fluentAddAll(furnituresArray)

        tempLinksJo.put("links_length_tmp",links_length_tmp)
        tempLinksJo.put("duration",duration_tmp)
        tempLinksJo.put("lnk_type",lnk_type_tmp)
        tempLinksJo.put("furnitures",furnituresArray_tmp)

      } else {
        if (i != 0) linksNew2.add(tempLinksJo)

        if (i == linksNew.size -1 || i == linksNew.size -2) {
          linksNew2.add(linksJo)
        }
        tempLinksJo = linksJo
      }
    }

    linksNew2
  }
  /**
    * 解析全部轨迹
    *
    * @param x
    * @param inc_day
    * @return
    */


  def parsefixResponse(x: JSONObject,inc_day:String) = {

    // TODO: 行驶时长 行驶里程
    var durationSum = 0.0

    val jo = new JSONObject()
    val path = x.getJSONObject("paths")
    val route = path.getJSONObject("route")
    val paths = route.getJSONArray("paths")
    val tracks = x.getJSONArray("tracks")

    val distSum = JSONUtils.getJsonValueInt(x,"len",0)
    var total_links_dist = 0.0
    var total_links_duration = 0.0

    val periodJsonresJson = new JSONObject()

    // TODO: 计算高速、国道、省道、县道、乡路 行驶里程、时长
    val roadClassDistMap = new util.HashMap[Int,Double]()
    val roadClassDurationMap = new util.HashMap[Int,Double]()


    // TODO: 获取轨迹swidLinkMap的起使时间段
    val swidTracksMap = calSwidLinkMap(tracks)

    val combinePaths = calCombineLinks(paths)


    // TODO: 获取全量分时段计算结果
    val buffer = calAllPeriod(combinePaths,swidTracksMap)

    val buffer0 = filterPeriodDuration(buffer,"night",inc_day)
    val buffer1 = filterPeriodDuration(buffer,"before_dawn",inc_day)
    val buffer2 = filterPeriodDuration(buffer,"early_morning",inc_day)
    val buffer3 = filterPeriodDuration(buffer,"afternoon",inc_day)
    val buffer4 = filterPeriodDuration(buffer,"dusk",inc_day)

    val bufferAll = new ArrayBuffer[JSONObject]()
    bufferAll.append(buffer0)
    bufferAll.append(buffer1)
    bufferAll.append(buffer2)
    bufferAll.append(buffer3)
    bufferAll.append(buffer4)


    // TODO:  将分段结果汇总
    val periodJson = calFlatBuffer(bufferAll)

    val resJson = new JSONObject()

    resJson.put("period",periodJson)

    // TODO: 计算危险路段、事故高发路段、学校路段、急转弯路段、村庄路段 里程和次数
    // TODO: 增加不同道路设施时长统计
    var furnitures_21 = 0
    var furnitures_6 = 0
    var furnitures_13 = 0
    var furnitures_3 = 0
    var furnitures_12 = 0

    var furnitures_21_dist = 0.0
    var furnitures_6_dist = 0.0
    var furnitures_13_dist = 0.0
    var furnitures_3_dist = 0.0
    var furnitures_12_dist = 0.0


    var furnitures_21_duration = 0.0
    var furnitures_6_duration = 0.0
    var furnitures_13_duration = 0.0
    var furnitures_3_duration = 0.0
    var furnitures_12_duration = 0.0


    // TODO: 计算城市里程、城市时长
    val adcodeDistMap = new util.HashMap[String,Double]()
    val adcodeDurationMap = new util.HashMap[String,Double]()

    // TODO: 存储SWID为map
    val swidMap = new util.HashMap[String,Int]()
    //    val swidRoadClassMap = new com.sf.gis.scala.scm.app.util.HashMap[String,Int]()
    val swidRoadClassList = new ArrayBuffer[String]()

    // TODO: 计算经过路口次数
    var lnk_type_cnt = 0

    for (i <- (0 until (paths.size))) {
      val jo = paths.getJSONObject(i)
      val duration = JSONUtils.getJsonValueDouble(jo, "duration", 0)
      durationSum += duration
    }


    for (k <- (0 until (combinePaths.size()))) {
      val linksJo = combinePaths.getJSONObject(k)
      //          val links_length = JSONUtils.getJsonValueDouble(linksJo, "length", 0)
      val links_length = JSONUtils.getJsonValueDouble(linksJo, "dr_length", 0)
      val links_duration = JSONUtils.getJsonValueDouble(linksJo, "duration", 0.0)
      val lnk_type_list = JSONUtils.getJsonValue(linksJo, "lnk_type", "-1").split("\\|")
      val adcode = linksJo.getString("adcode")

      // TODO: 计算经过路口次数

      for (i <- (0 to (lnk_type_list.size -1))){
        val lnk_type = try {lnk_type_list(i).toInt} catch {case e:Exception => -1}
        // 计算经过路口次数
        if (lnk_type == 0 || lnk_type == 1 || lnk_type == 2) {
          lnk_type_cnt += 1
        }
      }

      // TODO: 计算总时长、总里程
      total_links_dist += links_length
      total_links_duration += links_duration

      // TODO: 计算城市里程、城市时长
      adcodeDistMap.put(adcode, adcodeDistMap.getOrDefault(adcode, 0) + links_length)
      adcodeDurationMap.put(adcode, adcodeDurationMap.getOrDefault(adcode, 0) + links_duration)

      // TODO: 存储swid 限速信息
      val swid_id = JSONUtils.getJsonValue(linksJo, "sw_id", "")
      val speed_limit = JSONUtils.getJsonValueInt(linksJo, "speed_limit", 120)
      swidMap.put(swid_id, speed_limit)

      // TODO: 存储roadclass里程
      val roadclass = JSONUtils.getJsonValueInt(linksJo, "roadclass", -1)
      roadClassDistMap.put(roadclass,roadClassDistMap.getOrDefault(roadclass,0) + links_length)
      roadClassDurationMap.put(roadclass,roadClassDurationMap.getOrDefault(roadclass,0) + links_duration)
      // TODO: 存储swid和高速道路信息对应关系
      if (roadclass == 0) swidRoadClassList.append(swid_id)

      // TODO: 计算道路设施  furnitures
      val furnituresArray = linksJo.getJSONArray("furnitures")

      val furnituresBuffer = new ArrayBuffer[Int]()
      for (index <- (0 until(furnituresArray.size()))){
        val frunType = JSONUtils.getJsonValueInt(furnituresArray.getJSONObject(index), "type", 0)
        furnituresBuffer.append(frunType)
        if (frunType == 21) {
          furnitures_21 += 1
        }
        if (frunType == 6) {
          furnitures_6 += 1
        }
        if (frunType == 13) {
          furnitures_13 += 1
        }
        if (frunType == 3) {
          furnitures_3 += 1
        }
        if (frunType == 12) {
          furnitures_12 += 1
        }
      }

      val furnituresBufferDistinct = furnituresBuffer.distinct

      furnituresBufferDistinct.map(frunType => {
        if (frunType == 21) {
          furnitures_21_dist += links_length
          furnitures_21_duration += links_duration
        }
        if (frunType == 6) {
          furnitures_6_dist += links_length
          furnitures_6_duration += links_duration
        }
        if (frunType == 13) {
          furnitures_13_dist += links_length
          furnitures_13_duration += links_duration
        }
        if (frunType == 3) {
          furnitures_3_dist += links_length
          furnitures_3_duration += links_duration
        }
        if (frunType == 12) {
          furnitures_12_dist += links_length
          furnitures_12_duration += links_duration
        }
      })

    }


    // TODO: 计算超速起始和终止
    val (overSpeedDuration,overSpeedSeriousDuration,highRoadLowSpeedDuration) = try {calOverSpeed(tracks,swidMap,swidRoadClassList) } catch {case e:Exception =>(0,0,0)}

    // TODO: 计算行驶时间段  需要返回行驶时长，行驶时段，超时驾驶时长，运营次数，同城运营次数，运营起始城市次数
    val durationProcessJson = try {calDurationPart(tracks,inc_day) } catch {case e:Exception => new JSONObject()}

    // TODO: 总时长
    resJson.put("durationSum",durationSum)
    // TODO: 总里程
    resJson.put("distSum",distSum)

    resJson.put("total_links_dist",total_links_dist)
    resJson.put("total_links_duration",total_links_duration)


    // TODO: 各个城市的里程和时长
    resJson.put("adcodeDistMap",adcodeDistMap.toString)
    resJson.put("adcodeDurationMap",adcodeDurationMap.toString)

    // TODO: 计算高速 国道 省道 县道 乡路 行驶里程、时长
    val roadclass0Dist = roadClassDistMap.getOrDefault(0,0)
    val roadclass1Dist = roadClassDistMap.getOrDefault(1,0)
    val roadclass2Dist = roadClassDistMap.getOrDefault(2,0)
    val roadclass3Dist = roadClassDistMap.getOrDefault(3,0)
    val roadclass4Dist = roadClassDistMap.getOrDefault(4,0)

    val roadclass0Duration = roadClassDurationMap.getOrDefault(0,0)
    val roadclass1Duration = roadClassDurationMap.getOrDefault(1,0)
    val roadclass2Duration = roadClassDurationMap.getOrDefault(2,0)
    val roadclass3Duration = roadClassDurationMap.getOrDefault(3,0)
    val roadclass4Duration = roadClassDurationMap.getOrDefault(4,0)

    resJson.put("roadClass0Dist",roadclass0Dist)
    resJson.put("roadClass1Dist",roadclass1Dist)
    resJson.put("roadClass2Dist",roadclass2Dist)
    resJson.put("roadClass3Dist",roadclass3Dist)
    resJson.put("roadClass4Dist",roadclass4Dist)

    resJson.put("roadClass0Duration",roadclass0Duration)
    resJson.put("roadClass1Duration",roadclass1Duration)
    resJson.put("roadClass2Duration",roadclass2Duration)
    resJson.put("roadClass3Duration",roadclass3Duration)
    resJson.put("roadClass4Duration",roadclass4Duration)

    // TODO: 计算危险路段、事故高发路段、学校路段、急转弯路段、村庄路段 次数和里程与时长
    resJson.put("furnitures_21",furnitures_21)
    resJson.put("furnitures_6",furnitures_6)
    resJson.put("furnitures_13",furnitures_13)
    resJson.put("furnitures_3",furnitures_3)
    resJson.put("furnitures_12",furnitures_12)
    resJson.put("furnitures_21_dist",furnitures_21_dist)
    resJson.put("furnitures_6_dist",furnitures_6_dist)
    resJson.put("furnitures_13_dist",furnitures_13_dist)
    resJson.put("furnitures_3_dist",furnitures_3_dist)
    resJson.put("furnitures_12_dist",furnitures_12_dist)
    resJson.put("furnitures_21_duration",furnitures_21_duration)
    resJson.put("furnitures_6_duration",furnitures_6_duration)
    resJson.put("furnitures_13_duration",furnitures_13_duration)
    resJson.put("furnitures_3_duration",furnitures_3_duration)
    resJson.put("furnitures_12_duration",furnitures_12_duration)

    // TODO:  行驶时长，行驶时段，超时驾驶时长，运营次数，同城运营次数，运营起始城市
    resJson.fluentPutAll(durationProcessJson)

    // TODO: 经过路口次数
    resJson.put("lnk_type_cnt",lnk_type_cnt)
    // TODO: 超速驾驶时长 严重超速驾驶时长
    resJson.put("overSpeedDuration",overSpeedDuration - overSpeedSeriousDuration)
    resJson.put("overSpeedSeriousDuration", overSpeedSeriousDuration)

    // TODO: 增加高速道路低速行驶时长
    resJson.put("highRoadLowSpeedDuration", highRoadLowSpeedDuration)


    resJson
  }




  /**
    * 解析分时段返回结果
    * @param x
    * @return
    */


  def parsePeriodfixResponse(x: JSONObject) = {

    // TODO: 行驶时长 行驶里程

    val jo = new JSONObject()
    val path = x.getJSONObject("paths")
    val route = path.getJSONObject("route")
    val paths = route.getJSONArray("paths")
    val tracks = x.getJSONArray("tracks")

    val resJson = new JSONObject()

    // TODO: 计算高速、国道、省道、县道、乡路 行驶里程
    val roadclassMapDist = new util.HashMap[Int,Double]()
    val roadclassMapDuration = new util.HashMap[Int,Double]()

    // TODO: 计算危险路段、事故高发路段、学校路段、急转弯路段、村庄路段 里程和次数
    // TODO: 增加不同道路设施时长统计
    var furnitures_21 = 0
    var furnitures_6 = 0
    var furnitures_13 = 0
    var furnitures_3 = 0
    var furnitures_12 = 0


    // TODO: 计算经过路口次数
    var lnk_type_cnt = 0


    // TODO: 计算分时段里程和时长
    var total_links_duration = 0.0
    var total_links_dist = 0.0

    for (i <- (0 until (paths.size))) {
      val jo = paths.getJSONObject(i)
      val duration = JSONUtils.getJsonValueDouble(jo, "duration", 0)

      val steps = jo.getJSONArray("steps")
      for (j <- (0 until (steps.size()))) {
        val stepsJo = steps.getJSONObject(j)
        val links = stepsJo.getJSONArray("links")
        for (k <- (0 until (links.size()))) {
          val linksJo = links.getJSONObject(k)
          //          val links_length = JSONUtils.getJsonValueDouble(linksJo, "length", 0)
          val links_length = JSONUtils.getJsonValueDouble(linksJo, "dr_length", 0)
          val links_duration = JSONUtils.getJsonValueDouble(linksJo, "duration", 0.0)
          val lnk_type = JSONUtils.getJsonValueInt(linksJo, "lnk_type", -1)
          val adcode = linksJo.getString("adcode")

          // TODO: 计算分时段总里程和时长
          total_links_duration += links_duration
          total_links_dist += links_length

          // TODO: 存储roadclass里程 时长
          val roadclass = JSONUtils.getJsonValueInt(linksJo, "roadclass", -1)
          roadclassMapDist.put(roadclass,roadclassMapDist.getOrDefault(roadclass,0) + links_length)
          roadclassMapDuration.put(roadclass,roadclassMapDuration.getOrDefault(roadclass,0) + links_duration)

          // TODO: 计算道路设施  furnitures
          val furnituresArray = linksJo.getJSONArray("furnitures")

          for (index <- (0 until(furnituresArray.size()))){

            val frunType = JSONUtils.getJsonValueInt(furnituresArray.getJSONObject(index),"type",0)
            if (frunType == 21) {
              furnitures_21 += 1
            }
            if (frunType == 6) {
              furnitures_6 += 1
            }
            if (frunType == 13) {
              furnitures_13 += 1
            }
            if (frunType == 3) {
              furnitures_3 += 1
            }
            if (frunType == 12) {
              furnitures_12 += 1
            }

          }

          // 计算经过路口次数
          if (lnk_type == 0 || lnk_type == 1 || lnk_type == 2) {
            lnk_type_cnt += 1
          }
        }
      }
    }


    // TODO: 计算高速 国道 省道 县道 乡路 行驶里程 时长
    val roadclass0Dist = roadclassMapDist.getOrDefault(0,0)
    val roadclass1Dist = roadclassMapDist.getOrDefault(1,0)
    val roadclass2Dist = roadclassMapDist.getOrDefault(2,0)
    val roadclass3Dist = roadclassMapDist.getOrDefault(3,0)
    val roadclass4Dist = roadclassMapDist.getOrDefault(4,0)

    resJson.put("roadclass0Dist",roadclass0Dist)
    resJson.put("roadclass1Dist",roadclass1Dist)
    resJson.put("roadclass2Dist",roadclass2Dist)
    resJson.put("roadclass3Dist",roadclass3Dist)
    resJson.put("roadclass4Dist",roadclass4Dist)


    val roadclass0Duraion = roadclassMapDuration.getOrDefault(0,0)
    val roadclass1Duraion = roadclassMapDuration.getOrDefault(1,0)
    val roadclass2Duraion = roadclassMapDuration.getOrDefault(2,0)
    val roadclass3Duraion = roadclassMapDuration.getOrDefault(3,0)
    val roadclass4Duraion = roadclassMapDuration.getOrDefault(4,0)

    resJson.put("roadclass0Duraion",roadclass0Duraion)
    resJson.put("roadclass1Duraion",roadclass1Duraion)
    resJson.put("roadclass2Duraion",roadclass2Duraion)
    resJson.put("roadclass3Duraion",roadclass3Duraion)
    resJson.put("roadclass4Duraion",roadclass4Duraion)



    // TODO: 计算危险路段、事故高发路段、学校路段、急转弯路段、村庄路段 次数
    resJson.put("furnitures_21",furnitures_21)
    resJson.put("furnitures_6",furnitures_6)
    resJson.put("furnitures_13",furnitures_13)
    resJson.put("furnitures_3",furnitures_3)
    resJson.put("furnitures_12",furnitures_12)

    // TODO: 经过路口次数
    resJson.put("lnk_type_cnt",lnk_type_cnt)

    // TODO: 分时段标识
    resJson.put("period_length",total_links_dist)
    resJson.put("period_duration",total_links_duration)

    resJson


  }



  /**
    * 全量接口返回解析
    * @param x
    * @return
    */

  def calGjRectify(x:JSONObject):JSONObject = {

    val un_ak = x.getString("un")
    val un  = try {un_ak.split("_")(0)} catch {case e:Exception => un_ak}
    val ak  = try {un_ak.split("_")(1)} catch {case e:Exception => un_ak}

    val inc_day = x.getString("inc_day")
    x.remove("inc_day")

    //0702进行地图切换
    var url  = fixUrl_38
    logger.error("使用的服务器 : " + url + " ====== "+ x)
    val fixResponse = SparkUtils.doPost(url,x,logger)

    //    System.out.println(fixResponse)
    val fixResponseParse = try {JSON.parseObject(fixResponse)} catch {case e:Exception => new JSONObject()}

    val json = try {parsefixResponse(fixResponseParse,inc_day)} catch {case e:Exception => new JSONObject()}

    json.put("un",un)
    json.put("ak",ak)

    json

  }



  def stdSourceRdd(sourceRdd: RDD[JSONObject],inc_day:String) = {

    val stdRdd = sourceRdd.map(x => {

      val un = x.getString("un")
      val ak = x.getString("ak")
      ((un,ak),x)

    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map( x => {

        val (un,ak) = x._1
        val list = x._2
        val group_tm = list.toArray.map(x => {
          val json = x
          val tm = json.getString("tm")
          (tm,json)
        }).toStream.sortBy(_._1)
        val vehicle_type = 3
        val tracks = new JSONArray()

        group_tm.zipWithIndex.toArray.map(x => {
          val joTracks = new JSONObject()
          val trajJson = x._1._2.asInstanceOf[JSONObject]
          val index = x._2.asInstanceOf[Int]
          //          val be = JSONUtils.getJsonValueDouble(trajJson,"be",0)
          var tm = JSONUtils.getJsonValueLong(trajJson,"tm",0)

          //转换成前一天或者是随意的时间戳
//          tm = tm-86400

          val zx = JSONUtils.getJsonValueDouble(trajJson,"zx",0).formatted("%.6f").toDouble
          val zy = JSONUtils.getJsonValueDouble(trajJson,"zy",0).formatted("%.6f").toDouble

          //          joTracks.put("azimuth",be)
          //          joTracks.put("index",index)
          //          joTracks.put("type",1)

          joTracks.put("time",tm)
          joTracks.put("x",zx)
          joTracks.put("y",zy)
          tracks.add(joTracks)
        })
        val joPost = new JSONObject()

        joPost.put("ak","--")
        joPost.put("addpoint",1)
        //        joPost.put("retflag",7)
        joPost.put("retflag",100)
        joPost.put("pathinfo",1)
        joPost.put("roadinfo",1)
        joPost.put("vehicle,",vehicle_type)
        joPost.put("tracks",tracks)
        //20230510 纠偏返回数据不一样问题 导致  total_links_duration 翻倍由0修改成1
        joPost.put("coord_type_input",1)
        joPost.put("un",un + "_" + ak)
        joPost.put("inc_day",inc_day)
        joPost.put("compress",1)

        joPost
      })

    stdRdd


  }

  def concatTimestamp(inc_day: String, start_period_pre: String) = {

    val stamp = DateTimeUtil.getIncDayToTimeStamp(inc_day,start_period_pre)
    stamp

  }




  /**
    * 计算全部轨迹
    * @param sourceRdd
    */
  def calProcessAllTracks(sourceRdd: RDD[JSONObject],inc_day:String, spark: SparkSession) = {

    val calSourceRdd = stdSourceRdd(sourceRdd,inc_day)
    calSourceRdd.foreach(row =>{logger.error(row.toJSONString)})
    val httpInvokeId  = BdpTaskRecordUtil.startRunNetworkInterface(spark,"01420395"
      ,"794608","保险模型例行","保险模型例行"
      ,fixUrl_38,"",calSourceRdd.count(),280
    )

    val limitMin = 25000
    val gjRectifyRdd = SparkUtils.akLimitMultiThreadRdd(calSourceRdd.repartition(1000))(calGjRectify)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("输入数据量为:" + gjRectifyRdd.count())

    BdpTaskRecordUtil.endNetworkInterface("01420395", httpInvokeId )

    gjRectifyRdd

  }



  def getUnionPeriod(unionPeriodRdd: RDD[(String, JSONObject)]) = {

    val periodRdd = unionPeriodRdd
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val un = x._1
        val list = x._2

        // TODO: 将行转列 得到分时段时长和里程数据

        var night_duration = 0.0
        var before_dawn_duration =0.0
        var early_morning_duration = 0.0
        var afternoon_duration = 0.0
        var dusk_duration = 0.0

        var night_length = 0.0
        var before_dawn_length = 0.0
        var early_morning_length = 0.0
        var afternoon_length = 0.0
        var dusk_length = 0.0

        // TODO: 分时段设施 dist duration
        // TODO: night
        var night_roadclass0_duration = 0.0
        var night_roadclass1_duration = 0.0
        var night_roadclass2_duration = 0.0
        var night_roadclass3_duration = 0.0
        var night_roadclass4_duration = 0.0

        var night_roadclass0_dist = 0.0
        var night_roadclass1_dist = 0.0
        var night_roadclass2_dist = 0.0
        var night_roadclass3_dist = 0.0
        var night_roadclass4_dist = 0.0

        var night_furnitures_21 = 0
        var night_furnitures_6 = 0
        var night_furnitures_13 = 0
        var night_furnitures_3 = 0
        var night_furnitures_12 = 0

        var night_lnk_type_cnt =0

        // TODO: before_dawn
        var before_dawn_roadclass0_duration = 0.0
        var before_dawn_roadclass1_duration = 0.0
        var before_dawn_roadclass2_duration = 0.0
        var before_dawn_roadclass3_duration = 0.0
        var before_dawn_roadclass4_duration = 0.0

        var before_dawn_roadclass0_dist = 0.0
        var before_dawn_roadclass1_dist = 0.0
        var before_dawn_roadclass2_dist = 0.0
        var before_dawn_roadclass3_dist = 0.0
        var before_dawn_roadclass4_dist = 0.0

        var before_dawn_furnitures_21 = 0
        var before_dawn_furnitures_6 = 0
        var before_dawn_furnitures_13 = 0
        var before_dawn_furnitures_3 = 0
        var before_dawn_furnitures_12 = 0

        var before_dawn_lnk_type_cnt =0

        // TODO: early_morning
        var early_morning_roadclass0_duration = 0.0
        var early_morning_roadclass1_duration = 0.0
        var early_morning_roadclass2_duration = 0.0
        var early_morning_roadclass3_duration = 0.0
        var early_morning_roadclass4_duration = 0.0

        var early_morning_roadclass0_dist = 0.0
        var early_morning_roadclass1_dist = 0.0
        var early_morning_roadclass2_dist = 0.0
        var early_morning_roadclass3_dist = 0.0
        var early_morning_roadclass4_dist = 0.0

        var early_morning_furnitures_21 = 0
        var early_morning_furnitures_6 = 0
        var early_morning_furnitures_13 = 0
        var early_morning_furnitures_3 = 0
        var early_morning_furnitures_12 = 0

        var early_morning_lnk_type_cnt =0

        // TODO: afternoon
        var afternoon_roadclass0_duration = 0.0
        var afternoon_roadclass1_duration = 0.0
        var afternoon_roadclass2_duration = 0.0
        var afternoon_roadclass3_duration = 0.0
        var afternoon_roadclass4_duration = 0.0

        var afternoon_roadclass0_dist = 0.0
        var afternoon_roadclass1_dist = 0.0
        var afternoon_roadclass2_dist = 0.0
        var afternoon_roadclass3_dist = 0.0
        var afternoon_roadclass4_dist = 0.0

        var afternoon_furnitures_21 = 0
        var afternoon_furnitures_6 = 0
        var afternoon_furnitures_13 = 0
        var afternoon_furnitures_3 = 0
        var afternoon_furnitures_12 = 0

        var afternoon_lnk_type_cnt =0

        // TODO: dusk
        var dusk_roadclass0_duration = 0.0
        var dusk_roadclass1_duration = 0.0
        var dusk_roadclass2_duration = 0.0
        var dusk_roadclass3_duration = 0.0
        var dusk_roadclass4_duration = 0.0

        var dusk_roadclass0_dist = 0.0
        var dusk_roadclass1_dist = 0.0
        var dusk_roadclass2_dist = 0.0
        var dusk_roadclass3_dist = 0.0
        var dusk_roadclass4_dist = 0.0

        var dusk_furnitures_21 = 0
        var dusk_furnitures_6 = 0
        var dusk_furnitures_13 = 0
        var dusk_furnitures_3 = 0
        var dusk_furnitures_12 = 0

        var dusk_lnk_type_cnt =0


        // TODO: 分时段道路等级

        list.map(obj => {
          val period = obj.getString("period")
          val len = JSONUtils.getJsonValueDouble(obj,"period_length",0)
          val duration = JSONUtils.getJsonValueDouble(obj,"period_duration",0)

          // TODO: 道路等级
          val roadclass0Dist = JSONUtils.getJsonValueDouble(obj,"roadclass0Dist",0)
          val roadclass1Dist = JSONUtils.getJsonValueDouble(obj,"roadclass1Dist",0)
          val roadclass2Dist = JSONUtils.getJsonValueDouble(obj,"roadclass2Dist",0)
          val roadclass3Dist = JSONUtils.getJsonValueDouble(obj,"roadclass3Dist",0)
          val roadclass4Dist = JSONUtils.getJsonValueDouble(obj,"roadclass4Dist",0)

          val roadclass0Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass0Duraion",0)
          val roadclass1Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass1Duraion",0)
          val roadclass2Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass2Duraion",0)
          val roadclass3Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass3Duraion",0)
          val roadclass4Duraion = JSONUtils.getJsonValueDouble(obj,"roadclass4Duraion",0)

          // TODO: 经过危险路段、事故高发、学校、急转弯、村庄次数
          val furnitures_21 = JSONUtils.getJsonValueInt(obj,"furnitures_21",0)
          val furnitures_6 = JSONUtils.getJsonValueInt(obj,"furnitures_6",0)
          val furnitures_13 = JSONUtils.getJsonValueInt(obj,"furnitures_13",0)
          val furnitures_3 = JSONUtils.getJsonValueInt(obj,"furnitures_3",0)
          val furnitures_12 = JSONUtils.getJsonValueInt(obj,"furnitures_12",0)

          // TODO: 经过路口次数
          val lnk_type_cnt = JSONUtils.getJsonValueInt(obj,"lnk_type_cnt",0)

          if(StringUtils.nonEmpty(period)){

            period match {
              case period if period.equals("night") =>
                night_duration +=duration
                night_length += len
                night_roadclass0_duration += roadclass0Duraion
                night_roadclass1_duration += roadclass1Duraion
                night_roadclass2_duration += roadclass2Duraion
                night_roadclass3_duration += roadclass3Duraion
                night_roadclass4_duration += roadclass4Duraion
                night_roadclass0_dist += roadclass0Dist
                night_roadclass1_dist += roadclass1Dist
                night_roadclass2_dist += roadclass2Dist
                night_roadclass3_dist += roadclass3Dist
                night_roadclass4_dist += roadclass4Dist
                night_furnitures_21 += furnitures_21
                night_furnitures_6 += furnitures_6
                night_furnitures_13 += furnitures_13
                night_furnitures_3 += furnitures_3
                night_furnitures_12 += furnitures_12
                night_lnk_type_cnt += lnk_type_cnt

              case period if period.equals("before_dawn") =>
                before_dawn_duration +=duration
                before_dawn_length += len
                before_dawn_roadclass0_duration += roadclass0Duraion
                before_dawn_roadclass1_duration += roadclass1Duraion
                before_dawn_roadclass2_duration += roadclass2Duraion
                before_dawn_roadclass3_duration += roadclass3Duraion
                before_dawn_roadclass4_duration += roadclass4Duraion
                before_dawn_roadclass0_dist += roadclass0Dist
                before_dawn_roadclass1_dist += roadclass1Dist
                before_dawn_roadclass2_dist += roadclass2Dist
                before_dawn_roadclass3_dist += roadclass3Dist
                before_dawn_roadclass4_dist += roadclass4Dist
                before_dawn_furnitures_21 += furnitures_21
                before_dawn_furnitures_6 += furnitures_6
                before_dawn_furnitures_13 += furnitures_13
                before_dawn_furnitures_3 += furnitures_3
                before_dawn_furnitures_12 += furnitures_12
                before_dawn_lnk_type_cnt += lnk_type_cnt
              case period if period.equals("early_morning") =>
                early_morning_duration +=duration
                early_morning_length += len
                early_morning_roadclass0_duration += roadclass0Duraion
                early_morning_roadclass1_duration += roadclass1Duraion
                early_morning_roadclass2_duration += roadclass2Duraion
                early_morning_roadclass3_duration += roadclass3Duraion
                early_morning_roadclass4_duration += roadclass4Duraion
                early_morning_roadclass0_dist += roadclass0Dist
                early_morning_roadclass1_dist += roadclass1Dist
                early_morning_roadclass2_dist += roadclass2Dist
                early_morning_roadclass3_dist += roadclass3Dist
                early_morning_roadclass4_dist += roadclass4Dist
                early_morning_furnitures_21 += furnitures_21
                early_morning_furnitures_6 += furnitures_6
                early_morning_furnitures_13 += furnitures_13
                early_morning_furnitures_3 += furnitures_3
                early_morning_furnitures_12 += furnitures_12
                early_morning_lnk_type_cnt += lnk_type_cnt
              case period if period.equals("afternoon") =>
                afternoon_duration +=duration
                afternoon_length += len
                afternoon_roadclass0_duration += roadclass0Duraion
                afternoon_roadclass1_duration += roadclass1Duraion
                afternoon_roadclass2_duration += roadclass2Duraion
                afternoon_roadclass3_duration += roadclass3Duraion
                afternoon_roadclass4_duration += roadclass4Duraion
                afternoon_roadclass0_dist += roadclass0Dist
                afternoon_roadclass1_dist += roadclass1Dist
                afternoon_roadclass2_dist += roadclass2Dist
                afternoon_roadclass3_dist += roadclass3Dist
                afternoon_roadclass4_dist += roadclass4Dist
                afternoon_furnitures_21 += furnitures_21
                afternoon_furnitures_6 += furnitures_6
                afternoon_furnitures_13 += furnitures_13
                afternoon_furnitures_3 += furnitures_3
                afternoon_furnitures_12 += furnitures_12
                afternoon_lnk_type_cnt += lnk_type_cnt
              case period if period.equals("dusk") =>
                dusk_duration +=duration
                dusk_length += len
                dusk_roadclass0_duration += roadclass0Duraion
                dusk_roadclass1_duration += roadclass1Duraion
                dusk_roadclass2_duration += roadclass2Duraion
                dusk_roadclass3_duration += roadclass3Duraion
                dusk_roadclass4_duration += roadclass4Duraion
                dusk_roadclass0_dist += roadclass0Dist
                dusk_roadclass1_dist += roadclass1Dist
                dusk_roadclass2_dist += roadclass2Dist
                dusk_roadclass3_dist += roadclass3Dist
                dusk_roadclass4_dist += roadclass4Dist
                dusk_furnitures_21 += furnitures_21
                dusk_furnitures_6 += furnitures_6
                dusk_furnitures_13 += furnitures_13
                dusk_furnitures_3 += furnitures_3
                dusk_furnitures_12 += furnitures_12
                dusk_lnk_type_cnt += lnk_type_cnt
            }
          }
        })


        val json = new JSONObject()

        // TODO: night
        json.put("night_duration",night_duration)
        json.put("night_length",night_length)
        json.put("night_roadclass0_duration",night_roadclass0_duration)
        json.put("night_roadclass1_duration",night_roadclass1_duration)
        json.put("night_roadclass2_duration",night_roadclass2_duration)
        json.put("night_roadclass3_duration",night_roadclass3_duration)
        json.put("night_roadclass4_duration",night_roadclass4_duration)
        json.put("night_roadclass0_dist",night_roadclass0_dist)
        json.put("night_roadclass1_dist",night_roadclass1_dist)
        json.put("night_roadclass2_dist",night_roadclass2_dist)
        json.put("night_roadclass3_dist",night_roadclass3_dist)
        json.put("night_roadclass4_dist",night_roadclass4_dist)
        json.put("night_furnitures_21",night_furnitures_21)
        json.put("night_furnitures_6",night_furnitures_6)
        json.put("night_furnitures_13",night_furnitures_13)
        json.put("night_furnitures_3",night_furnitures_3)
        json.put("night_furnitures_12",night_furnitures_12)
        json.put("night_lnk_type_cnt",night_lnk_type_cnt)
        // TODO: before_dawn
        json.put("before_dawn_duration",before_dawn_duration)
        json.put("before_dawn_length",before_dawn_length)
        json.put("before_dawn_roadclass0_duration",before_dawn_roadclass0_duration)
        json.put("before_dawn_roadclass1_duration",before_dawn_roadclass1_duration)
        json.put("before_dawn_roadclass2_duration",before_dawn_roadclass2_duration)
        json.put("before_dawn_roadclass3_duration",before_dawn_roadclass3_duration)
        json.put("before_dawn_roadclass4_duration",before_dawn_roadclass4_duration)
        json.put("before_dawn_roadclass0_dist",before_dawn_roadclass0_dist)
        json.put("before_dawn_roadclass1_dist",before_dawn_roadclass1_dist)
        json.put("before_dawn_roadclass2_dist",before_dawn_roadclass2_dist)
        json.put("before_dawn_roadclass3_dist",before_dawn_roadclass3_dist)
        json.put("before_dawn_roadclass4_dist",before_dawn_roadclass4_dist)
        json.put("before_dawn_furnitures_21",before_dawn_furnitures_21)
        json.put("before_dawn_furnitures_6",before_dawn_furnitures_6)
        json.put("before_dawn_furnitures_13",before_dawn_furnitures_13)
        json.put("before_dawn_furnitures_3",before_dawn_furnitures_3)
        json.put("before_dawn_furnitures_12",before_dawn_furnitures_12)
        json.put("before_dawn_lnk_type_cnt",before_dawn_lnk_type_cnt)
        // TODO: early_morning
        json.put("early_morning_duration",early_morning_duration)
        json.put("early_morning_length",early_morning_length)
        json.put("early_morning_roadclass0_duration",early_morning_roadclass0_duration)
        json.put("early_morning_roadclass1_duration",early_morning_roadclass1_duration)
        json.put("early_morning_roadclass2_duration",early_morning_roadclass2_duration)
        json.put("early_morning_roadclass3_duration",early_morning_roadclass3_duration)
        json.put("early_morning_roadclass4_duration",early_morning_roadclass4_duration)
        json.put("early_morning_roadclass0_dist",early_morning_roadclass0_dist)
        json.put("early_morning_roadclass1_dist",early_morning_roadclass1_dist)
        json.put("early_morning_roadclass2_dist",early_morning_roadclass2_dist)
        json.put("early_morning_roadclass3_dist",early_morning_roadclass3_dist)
        json.put("early_morning_roadclass4_dist",early_morning_roadclass4_dist)
        json.put("early_morning_furnitures_21",early_morning_furnitures_21)
        json.put("early_morning_furnitures_6",early_morning_furnitures_6)
        json.put("early_morning_furnitures_13",early_morning_furnitures_13)
        json.put("early_morning_furnitures_3",early_morning_furnitures_3)
        json.put("early_morning_furnitures_12",early_morning_furnitures_12)
        json.put("early_morning_lnk_type_cnt",early_morning_lnk_type_cnt)

        // TODO: afternoon
        json.put("afternoon_duration",afternoon_duration)
        json.put("afternoon_length",afternoon_length)
        json.put("afternoon_roadclass0_duration",afternoon_roadclass0_duration)
        json.put("afternoon_roadclass1_duration",afternoon_roadclass1_duration)
        json.put("afternoon_roadclass2_duration",afternoon_roadclass2_duration)
        json.put("afternoon_roadclass3_duration",afternoon_roadclass3_duration)
        json.put("afternoon_roadclass4_duration",afternoon_roadclass4_duration)
        json.put("afternoon_roadclass0_dist",afternoon_roadclass0_dist)
        json.put("afternoon_roadclass1_dist",afternoon_roadclass1_dist)
        json.put("afternoon_roadclass2_dist",afternoon_roadclass2_dist)
        json.put("afternoon_roadclass3_dist",afternoon_roadclass3_dist)
        json.put("afternoon_roadclass4_dist",afternoon_roadclass4_dist)
        json.put("afternoon_furnitures_21",afternoon_furnitures_21)
        json.put("afternoon_furnitures_6",afternoon_furnitures_6)
        json.put("afternoon_furnitures_13",afternoon_furnitures_13)
        json.put("afternoon_furnitures_3",afternoon_furnitures_3)
        json.put("afternoon_furnitures_12",afternoon_furnitures_12)
        json.put("afternoon_lnk_type_cnt",afternoon_lnk_type_cnt)

        // TODO: dusk
        json.put("dusk_duration",dusk_duration)
        json.put("dusk_length",dusk_length)
        json.put("dusk_roadclass0_duration",dusk_roadclass0_duration)
        json.put("dusk_roadclass1_duration",dusk_roadclass1_duration)
        json.put("dusk_roadclass2_duration",dusk_roadclass2_duration)
        json.put("dusk_roadclass3_duration",dusk_roadclass3_duration)
        json.put("dusk_roadclass4_duration",dusk_roadclass4_duration)
        json.put("dusk_roadclass0_dist",dusk_roadclass0_dist)
        json.put("dusk_roadclass1_dist",dusk_roadclass1_dist)
        json.put("dusk_roadclass2_dist",dusk_roadclass2_dist)
        json.put("dusk_roadclass3_dist",dusk_roadclass3_dist)
        json.put("dusk_roadclass4_dist",dusk_roadclass4_dist)
        json.put("dusk_furnitures_21",dusk_furnitures_21)
        json.put("dusk_furnitures_6",dusk_furnitures_6)
        json.put("dusk_furnitures_13",dusk_furnitures_13)
        json.put("dusk_furnitures_3",dusk_furnitures_3)
        json.put("dusk_furnitures_12",dusk_furnitures_12)
        json.put("dusk_lnk_type_cnt",dusk_lnk_type_cnt)

        (un,json)
      })

    periodRdd


  }




  /**
    * 总处理流程
    *
    * @param sourceRdd
    * @param inc_day
    */

  def calProcess(sourceRdd: RDD[JSONObject],lpnRdd: RDD[JSONObject], inc_day: String, spark :SparkSession) = {

    // TODO: 计算全量时长里程等字段
    val calAllRdd = calProcessAllTracks(sourceRdd,inc_day,spark)
    logger.error("calAllRdd的数据量为：" + calAllRdd.count())

    val resAllRdd = joinAllRdd(calAllRdd,lpnRdd)
    resAllRdd.take(2).foreach(println(_))

    resAllRdd
  }


  /**
    * join上分时段里程和时长
    * @param calAllRdd
    * @param lpnRdd
    */

  def joinAllRdd(calAllRdd: RDD[JSONObject],lpnRdd:RDD[JSONObject]) = {

    val lpnJoinRdd = lpnRdd.map(x => {
      val device_id = x.getString("device_id")
      (device_id,x)
    })

    val resAllRdd = calAllRdd.map(x => {
      val un = x.getString("un")
      val ak = x.getString("ak")
      (un,x)
    }).leftOuterJoin(lpnJoinRdd).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      if(rightOption.nonEmpty){
        val car_id = rightOption.get.getString("car_id")
        left.put("car_id",car_id)
      }else{
        val un = x._1
        left.put("car_id",un)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    resAllRdd
  }



  def saveToHive(spark: SparkSession, calRdd: RDD[JSONObject],inc_day:String,ak:String) = {

    val saveTableName = "dm_gis.insurance_model_duration_dist_daily_20231023"

    val resRdd = calRdd.map(x => {

      var periodJson = x.getJSONObject("period")
      // TODO: 日行表新增分段统计字段
      if (periodJson == null) periodJson = new JSONObject()

      val un = x.getString("un")
      val total_dist = JSONUtils.getJsonValue(x,"distSum","")
      val total_duration = JSONUtils.getJsonValue(x,"durationSum","")
      //      val drive_dist = if (StringUtils.isEmpty(total_dist) || total_dist == "0")  JSONUtils.getJsonValue(x,"err","") + "_" +"fixResponse:" + JSONUtils.getJsonValue(x,"fixResponse","") else ""
      //        JSONUtils.getJsonValue(x,"drive_dist","")
      val drive_dist =JSONUtils.getJsonValue(x,"drive_dist","")
      val night_dirve_dist = JSONUtils.getJsonValue(periodJson,"night_length","")
      val before_dawn_drive_dist = JSONUtils.getJsonValue(periodJson,"before_dawn_length","")
      val early_morning_drive_dist = JSONUtils.getJsonValue(periodJson,"early_morning_length","")
      val afternoon_drive_dist = JSONUtils.getJsonValue(periodJson,"afternoon_length","")
      val dusk_drive_dist = JSONUtils.getJsonValue(periodJson,"dusk_length","")

      val high_speed_dist = JSONUtils.getJsonValue(x,"roadClass0Dist","")
      val state_road_dist = JSONUtils.getJsonValue(x,"roadClass1Dist","")
      val provincial_dist = JSONUtils.getJsonValue(x,"roadClass2Dist","")
      val county_dist = JSONUtils.getJsonValue(x,"roadClass3Dist","")
      val township_dist = JSONUtils.getJsonValue(x,"roadClass4Dist","")
      val dangerous_road_dist = JSONUtils.getJsonValue(x,"furnitures_21_dist","")
      val high_accident_road_dist = JSONUtils.getJsonValue(x,"furnitures_6_dist","")
      val school_road_dist = JSONUtils.getJsonValue(x,"furnitures_13_dist","")
      val sharp_turn_road_dist = JSONUtils.getJsonValue(x,"furnitures_3_dist","")
      val village_road_dist = JSONUtils.getJsonValue(x,"furnitures_12_dist","")

      val drive_duration = JSONUtils.getJsonValue(x,"driveDuration","")
      val drive_duration_array = JSONUtils.getJsonValue(x,"durationArray","")

      val night_dirve_duration = JSONUtils.getJsonValue(periodJson,"night_duration","")
      val before_dawn_drive_duration = JSONUtils.getJsonValue(periodJson,"before_dawn_duration","")
      val early_morning_drive_duration = JSONUtils.getJsonValue(periodJson,"early_morning_duration","")
      val afternoon_drive_duration = JSONUtils.getJsonValue(periodJson,"afternoon_duration","")
      val dusk_drive_duration = JSONUtils.getJsonValue(periodJson,"dusk_duration","")

      val dangerous_road_duration = JSONUtils.getJsonValue(x,"furnitures_21_duration","")
      val high_accident_road_duration = JSONUtils.getJsonValue(x,"furnitures_6_duration","")
      val school_road_duration = JSONUtils.getJsonValue(x,"furnitures_13_duration","")
      val sharp_turn_road_duration = JSONUtils.getJsonValue(x,"furnitures_3_duration","")
      val township_road_duration = JSONUtils.getJsonValue(x,"furnitures_12_duration","")
      val over_speed_duration = JSONUtils.getJsonValue(x,"overSpeedDuration","")
      val over_speed_ser_duration = JSONUtils.getJsonValue(x,"overSpeedSeriousDuration","")

      val lnk_cnt = JSONUtils.getJsonValue(x,"lnk_type_cnt","")
      val dangerous_road_cnt = JSONUtils.getJsonValue(x,"furnitures_21","")
      val high_accident_road_cnt = JSONUtils.getJsonValue(x,"furnitures_6","")
      val school_road_cnt = JSONUtils.getJsonValue(x,"furnitures_13","")
      val sharp_turn_road_cnt = JSONUtils.getJsonValue(x,"furnitures_3","")
      val township_road_road_cnt = JSONUtils.getJsonValue(x,"furnitures_12","")
      val operation_cnt = JSONUtils.getJsonValue(x,"operationCnt","")
      val operation_same_city_cnt = JSONUtils.getJsonValue(x,"sameCityOperationCnt","")
      val adcode_map = JSONUtils.getJsonValue(x,"adcodeMap","")
      val adcode_duration_map = JSONUtils.getJsonValue(x,"adcodeDurationMap","")
      val adcode_dist_map = JSONUtils.getJsonValue(x,"adcodeDistMap","")
      val over_drive_duration = JSONUtils.getJsonValue(x,"overDirveDuration","")

      // TODO: 日行表新增分段统计字段


      if (periodJson == null) periodJson = new JSONObject()
      // 高速、国道、省道、县道、乡路
      val night_high_speed_duration= JSONUtils.getJsonValue(periodJson,"night_roadclass0_duration","")
      val night_state_road_duration= JSONUtils.getJsonValue(periodJson,"night_roadclass1_duration","")
      val night_provincial_duration= JSONUtils.getJsonValue(periodJson,"night_roadclass2_duration","")
      val night_county_duration= JSONUtils.getJsonValue(periodJson,"night_roadclass3_duration","")
      val night_township_duration= JSONUtils.getJsonValue(periodJson,"night_roadclass4_duration","")
      val night_high_speed_dist= JSONUtils.getJsonValue(periodJson,"night_roadclass0_dist","")
      val night_state_road_dist= JSONUtils.getJsonValue(periodJson,"night_roadclass1_dist","")
      val night_provincial_dist= periodJson.getString("night_roadclass2_dist")
      val night_county_dist= periodJson.getString("night_roadclass3_dist")
      val night_township_dist= periodJson.getString("night_roadclass4_dist")
      val night_dangerous_road_cnt = periodJson.getString("night_furnitures_21")
      val night_high_accident_road_cnt = periodJson.getString("night_furnitures_6")
      val night_school_road_cnt = periodJson.getString("night_furnitures_13")
      val night_sharp_turn_road_cnt = periodJson.getString("night_furnitures_3")
      val night_township_road_cnt = periodJson.getString("night_furnitures_12")
      val night_lnk_cnt= periodJson.getString("night_lnk_type_cnt")


      val before_dawn_high_speed_duration = periodJson.getString("before_dawn_roadclass0_duration")
      val before_dawn_state_road_duration = periodJson.getString("before_dawn_roadclass1_duration")
      val before_dawn_provincial_duration = periodJson.getString("before_dawn_roadclass2_duration")
      val before_dawn_county_duration = periodJson.getString("before_dawn_roadclass3_duration")
      val before_dawn_township_duration = periodJson.getString("before_dawn_roadclass4_duration")
      val before_dawn_high_speed_dist= periodJson.getString("before_dawn_roadclass0_dist")
      val before_dawn_road_dist= periodJson.getString("before_dawn_roadclass1_dist")
      val before_dawn_provincial_dist = periodJson.getString("before_dawn_roadclass2_dist")
      val before_dawn_county_dist = periodJson.getString("before_dawn_roadclass3_dist")
      val before_dawn_township_dist= periodJson.getString("before_dawn_roadclass4_dist")
      val before_dawn_dangerous_road_cnt = periodJson.getString("before_dawn_furnitures_21")
      val before_dawn_high_accident_road_cnt = periodJson.getString("before_dawn_furnitures_6")
      val before_dawn_school_road_cnt = periodJson.getString("before_dawn_furnitures_13")
      val before_dawn_sharp_turn_road_cnt = periodJson.getString("before_dawn_furnitures_3")
      val before_dawn_township_road_cnt = periodJson.getString("before_dawn_furnitures_12")
      val before_dawn_lnk_cnt= periodJson.getString("before_dawn_lnk_type_cnt")

      val early_morning_high_speed_duration = periodJson.getString("early_morning_roadclass0_duration")
      val early_morning_state_road_duration = periodJson.getString("early_morning_roadclass1_duration")
      val early_morning_provincial_duration = periodJson.getString("early_morning_roadclass2_duration")
      val early_morning_county_duration = periodJson.getString("early_morning_roadclass3_duration")
      val early_morning_township_duration = periodJson.getString("early_morning_roadclass4_duration")
      val early_morning_high_speed_dist = periodJson.getString("early_morning_roadclass0_dist")
      val early_morning_road_dist= periodJson.getString("early_morning_roadclass1_dist")
      val early_morning_provincial_dist= periodJson.getString("early_morning_roadclass2_dist")
      val early_morning_county_dist = periodJson.getString("early_morning_roadclass3_dist")
      val early_morning_township_dist = periodJson.getString("early_morning_roadclass4_dist")
      val early_morning_dangerous_road_cnt = periodJson.getString("early_morning_furnitures_21")
      val early_morning_high_accident_road_cnt = periodJson.getString("early_morning_furnitures_6")
      val early_morning_school_road_cnt = periodJson.getString("early_morning_furnitures_13")
      val early_morning_sharp_turn_road_cnt = periodJson.getString("early_morning_furnitures_3")
      val early_morning_township_road_cnt = periodJson.getString("early_morning_furnitures_12")
      val early_morning_lnk_cnt = periodJson.getString("early_morning_lnk_type_cnt")

      val afternoon_high_speed_duration = periodJson.getString("afternoon_roadclass0_duration")
      val afternoon_state_road_duration = periodJson.getString("afternoon_roadclass1_duration")
      val afternoon_provincial_duration = periodJson.getString("afternoon_roadclass2_duration")
      val afternoon_county_duration = periodJson.getString("afternoon_roadclass3_duration")
      val afternoon_township_duration = periodJson.getString("afternoon_roadclass4_duration")
      val afternoon_high_speed_dist= periodJson.getString("afternoon_roadclass0_dist")
      val afternoon_road_dist = periodJson.getString("afternoon_roadclass1_dist")
      val afternoon_provincial_dist= periodJson.getString("afternoon_roadclass2_dist")
      val afternoon_county_dist = periodJson.getString("afternoon_roadclass3_dist")
      val afternoon_township_dist = periodJson.getString("afternoon_roadclass4_dist")
      val afternoon_dangerous_road_cnt= periodJson.getString("afternoon_furnitures_21")
      val afternoon_high_accident_road_cnt = periodJson.getString("afternoon_furnitures_6")
      val afternoon_school_road_cnt= periodJson.getString("afternoon_furnitures_13")
      val afternoon_sharp_turn_road_cnt = periodJson.getString("afternoon_furnitures_3")
      val afternoon_township_road_cnt = periodJson.getString("afternoon_furnitures_12")
      val afternoon_lnk_type_cnt= periodJson.getString("afternoon_lnk_type_cnt")


      val dusk_high_speed_duration = periodJson.getString("dusk_roadclass0_duration")
      val dusk_state_road_duration = periodJson.getString("dusk_roadclass1_duration")
      val dusk_provincial_duration = periodJson.getString("dusk_roadclass2_duration")
      val dusk_county_duration = periodJson.getString("dusk_roadclass3_duration")
      val dusk_township_duration = periodJson.getString("dusk_roadclass4_duration")
      val dusk_high_speed_dist= periodJson.getString("dusk_roadclass0_dist")
      val dusk_road_dist = periodJson.getString("dusk_roadclass1_dist")
      val dusk_provincial_dist= periodJson.getString("dusk_roadclass2_dist")
      val dusk_county_dist = periodJson.getString("dusk_roadclass3_dist")
      val dusk_township_dist = periodJson.getString("dusk_roadclass4_dist")
      val dusk_dangerous_road_cnt= periodJson.getString("dusk_furnitures_21")
      val dusk_high_accident_road_cnt = periodJson.getString("dusk_furnitures_6")
      val dusk_school_road_cnt = periodJson.getString("dusk_furnitures_13")
      val dusk_sharp_turn_road_cnt = periodJson.getString("dusk_furnitures_3")
      val dusk_township_road_cnt = periodJson.getString("dusk_furnitures_12")
      val dusk_lnk_type_cnt = periodJson.getString("dusk_lnk_type_cnt")


      // TODO: 新增links 时长里程、同省运营次数
      val total_links_dist= x.getString("total_links_dist")
      val total_links_duration= x.getString("total_links_duration")
      val operation_same_prov_cnt = x.getString("sameProvinceCnt")

      // TODO: 增加轨迹上游表、轨迹数据对应ak
      val sc_table = "1"

      val lpn = x.getString("car_id")


      val high_speed_duration = JSONUtils.getJsonValue(x,"roadClass0Duration","")
      val state_road_duration = JSONUtils.getJsonValue(x,"roadClass1Duration","")
      val provincial_duration = JSONUtils.getJsonValue(x,"roadClass2Duration","")
      val county_duration = JSONUtils.getJsonValue(x,"roadClass3Duration","")
      val township_duration = JSONUtils.getJsonValue(x,"roadClass4Duration","")

      // TODO: 增加高速道路低速行驶时长
      val high_speed_lowspeed_duration =JSONUtils.getJsonValue(x,"highRoadLowSpeedDuration","")

      res(un,total_dist,total_duration,drive_dist,night_dirve_dist,before_dawn_drive_dist,early_morning_drive_dist,afternoon_drive_dist,dusk_drive_dist,
        high_speed_dist,state_road_dist,provincial_dist,county_dist,township_dist,dangerous_road_dist,high_accident_road_dist,school_road_dist,sharp_turn_road_dist,village_road_dist,
        drive_duration,drive_duration_array,night_dirve_duration,before_dawn_drive_duration,early_morning_drive_duration,afternoon_drive_duration,dusk_drive_duration,dangerous_road_duration,
        high_accident_road_duration,school_road_duration,sharp_turn_road_duration,township_road_duration,over_speed_duration,over_speed_ser_duration,
        lnk_cnt,dangerous_road_cnt,high_accident_road_cnt,school_road_cnt,sharp_turn_road_cnt,township_road_road_cnt,operation_cnt,operation_same_city_cnt,
        adcode_map,adcode_duration_map,adcode_dist_map,over_drive_duration,
        night_high_speed_duration,night_state_road_duration,night_provincial_duration,night_county_duration,night_township_duration,
        night_high_speed_dist,night_state_road_dist,night_provincial_dist,night_county_dist,night_township_dist,night_dangerous_road_cnt,night_high_accident_road_cnt,
        night_school_road_cnt,night_sharp_turn_road_cnt,night_township_road_cnt,night_lnk_cnt,before_dawn_high_speed_duration,
        before_dawn_state_road_duration,before_dawn_provincial_duration,before_dawn_county_duration,before_dawn_township_duration,before_dawn_high_speed_dist,
        before_dawn_road_dist,before_dawn_provincial_dist,before_dawn_county_dist,before_dawn_township_dist,before_dawn_dangerous_road_cnt,
        before_dawn_high_accident_road_cnt,before_dawn_school_road_cnt,before_dawn_sharp_turn_road_cnt,before_dawn_township_road_cnt,before_dawn_lnk_cnt,
        early_morning_high_speed_duration,early_morning_state_road_duration,early_morning_provincial_duration,
        early_morning_county_duration,early_morning_township_duration,early_morning_high_speed_dist,early_morning_road_dist,early_morning_provincial_dist,
        early_morning_county_dist,early_morning_township_dist,early_morning_dangerous_road_cnt,early_morning_high_accident_road_cnt,early_morning_school_road_cnt,
        early_morning_sharp_turn_road_cnt,early_morning_township_road_cnt,early_morning_lnk_cnt,afternoon_high_speed_duration,
        afternoon_state_road_duration,afternoon_provincial_duration,afternoon_county_duration,afternoon_township_duration,afternoon_high_speed_dist,afternoon_road_dist,
        afternoon_provincial_dist,afternoon_county_dist,afternoon_township_dist,afternoon_dangerous_road_cnt,afternoon_high_accident_road_cnt,afternoon_school_road_cnt,
        afternoon_sharp_turn_road_cnt,afternoon_township_road_cnt,afternoon_lnk_type_cnt,dusk_high_speed_duration,dusk_state_road_duration,
        dusk_provincial_duration,dusk_county_duration,dusk_township_duration,dusk_high_speed_dist,dusk_road_dist,dusk_provincial_dist,dusk_county_dist,dusk_township_dist,
        dusk_dangerous_road_cnt,dusk_high_accident_road_cnt,dusk_school_road_cnt,dusk_sharp_turn_road_cnt,dusk_township_road_cnt,dusk_lnk_type_cnt,
        total_links_dist,total_links_duration,operation_same_prov_cnt,sc_table,lpn,high_speed_duration,state_road_duration,provincial_duration,county_duration,township_duration,high_speed_lowspeed_duration
      )

    })


    import org.apache.spark.sql.functions._
    import spark.implicits._


    val list1 = List("314","310","324")
    val list2 = List("313","315","304","317","301","316")

    val repNum = if (list1.contains(ak)) 100 else if (list2.contains(ak)) 2 else 50

    resRdd.repartition(repNum).toDF().withColumn("inc_day",lit("20231021")).withColumn("ak",lit(ak)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)


  }

  def staStat(spark: SparkSession, inc_day: String) = {

    val (sourceRdd,lpnRdd) = getSourceData(spark,inc_day)

    val calRdd = calProcess(sourceRdd,lpnRdd,inc_day,spark)

//    saveToHive(spark,calRdd,inc_day,ak)

  }



  def start (inc_day:String): Unit = {
    val spark = SparkBuilder.localInitSpark("test")

    //迭代需求 1834553 GIS-RSS-SCM：【车险风险模型】保险数据处理-指标计算_V2.6_01420395_蔡国房
      staStat(spark,inc_day)

      spark.sqlContext.clearCache()

      val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
      ds.foreach(x => {
        x._2.unpersist()
      })
    logger.error("统计结束")

  }

  def main(args: Array[String]): Unit = {


    val inc_day = args(0)

    start(inc_day)

  }





}
