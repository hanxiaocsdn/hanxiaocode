package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{count, lit}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DateUtil, SparkBuilder, SparkUtils, StringUtils}


/**
  *@author 01420395
  *@DESCRIPTION
  *轨迹缺失表 需求ID 1842890   GIS-RSS-PNS：【价值线路】空驶指标监控需求_V1.0
  *任务id : 770505
  *@create 2023/06/14
  */
object EmptyDrivingIndicator3_2  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val cols =Seq(
      "task_area_code"
      ,"task_id"
      ,"task_subid"
      ,"start_dept"
      ,"end_dept"
      ,"start_type"
      ,"end_type"
      ,"line_code"
      ,"linevehicle"
      ,"std_id"
      ,"vehicle_serial"
      ,"conduct_type"
      ,"is_run_ontime"
      ,"start_longitude"
      ,"start_latitude"
      ,"end_longitude"
      ,"end_latitude"
      ,"rt_dist"
      ,"toll_charge"
      ,"is_stop"
      ,"stop_over_zone_code"
      ,"transoport_level"
      ,"carrier_type"
      ,"error_type"
      ,"carrier_name"
      ,"vehicle_type"
      ,"axls_number"
      ,"length"
      ,"weight"
      ,"mload"
      ,"length_weight"
      ,"miles"
      ,"road_fee"
      ,"road_fee_flag"
      ,"miles_flag"
      ,"reject_flag"
      ,"fuel_prices"
      ,"update_uint_fuel"
      ,"fuel_cost"
      ,"sum_cost"
      ,"std_id_jz"
      ,"online_date"
      ,"source"
      ,"grd1"
      ,"task_type"
      ,"task_inc_day"
      ,"inc_day"
    )

    val gis_eta_jiazhi_cost_new_ks_Json = gis_eta_jiazhi_cost_new_ks(inc_day, spark)

    val  resultDF =  gis_eta_jiazhi_cost_new_ks_Json.map(row  =>{
      val task_area_code = row.getString("task_area_code")
      val task_id = row.getString("task_id")
      val task_subid = row.getString("task_subid")
      val start_dept = row.getString("start_dept")
      val end_dept = row.getString("end_dept")
      val start_type = row.getString("start_type")
      val end_type = row.getString("end_type")
      val line_code = row.getString("line_code")
      val linevehicle = row.getString("linevehicle")
      val std_id = row.getString("std_id")
      val vehicle_serial = row.getString("vehicle_serial")
      val conduct_type = row.getString("conduct_type")
      val is_run_ontime = row.getString("is_run_ontime")
      val start_longitude = row.getString("start_longitude")
      val start_latitude = row.getString("start_latitude")
      val end_longitude = row.getString("end_longitude")
      val end_latitude = row.getString("end_latitude")
      var rt_dist = row.getString("rt_dist")
      if(StringUtils.isEmpty(rt_dist)){
        rt_dist =  "0.0"
      }
      val toll_charge = row.getString("toll_charge")
      val is_stop = row.getString("is_stop")
      val stop_over_zone_code = row.getString("stop_over_zone_code")
      val transoport_level = row.getString("transoport_level")
      val carrier_type = row.getString("carrier_type")
      val error_type = row.getString("error_type")
      val carrier_name = row.getString("carrier_name")
      val vehicle_type = row.getString("vehicle_type")
      val axls_number = row.getString("axls_number")
      val length = row.getString("length")
      val weight = row.getString("weight")
      val mload = row.getString("mload")
      val length_weight = row.getString("length_weight")

      val miles = row.getString("miles")
      val road_fee = row.getString("road_fee")

      val fuel_prices = row.getString("fuel_prices")
      val update_uint_fuel = row.getString("update_uint_fuel")
      val fuel_cost = row.getString("fuel_cost")
      val sum_cost = row.getString("sum_cost")
      val std_id_jz = row.getString("std_id_jz")
      val std_id_jz_time = row.getString("std_id_jz_time")

      val source = row.getString("source")
      val grd1 = row.getString("grd1")

      val task_inc_day = row.getString("task_inc_day")
      val inc_day = row.getString("inc_day")

      //     1：上线期任务，task_inc_day>=(online_date)最早日期
      //     2：基准期任务，(online_date)最早日期-180<=task_inc_day<(online_date)最早日期
      //     0：其他情况
      var task_type = "0"
      val online_date = row.getString("onLine_time")
      if(!StringUtils.isEmpty(task_inc_day) && !StringUtils.isEmpty(online_date) ){
        val beforeDate =  DateUtil.getLastDayofMonthBeforeOrAfter(online_date,-180)

        if(task_inc_day >= online_date){
          task_type = "1"
        }else if (beforeDate <= task_inc_day && task_inc_day < online_date){
          task_type = "2"
        }
      }

      var  miles_range  = row.getDouble("miles_range")
      if(miles_range==null){
        miles_range = 0.0
      }
      var  miles_mean  = row.getDouble("miles_mean")
      if(miles_mean==null){
        miles_mean = 0.0
      }
      var  miles_mode  = row.getDouble("miles_mode")
      if(miles_mode==null){
        miles_mode = 0.0
      }
      var  miles_std  = row.getDouble("miles_std")
      if(miles_std==null){
        miles_std = 0.0
      }
      var  miles_ratio_mode  = row.getDouble("miles_ratio_mode")
      if(miles_ratio_mode==null){
        miles_ratio_mode = 0.0
      }
      var  miles_ratio_std  = row.getDouble("miles_ratio_std")
      if(miles_ratio_std==null){
        miles_ratio_std = 0.0
      }

      //    miles_range=miles最大值-miles最小值
      //    miles_mean：miles的均值
      //    miles_mode：miles的众数
      //    miles_std：miles的标准差
      //    miles_ratio_mode：miles_ratio 的众数
      //    miles_ratio_std：miles_ratio 的标准差
      var miles_d = 0.0

      if(!StringUtils.isEmpty(miles)){
        miles_d = miles.toDouble
      }
      var  miles_flag = "0"
      if(!StringUtils.isEmpty(miles) &&  miles_d !=0.0){
        val  referMile = rt_dist.toDouble / 1000
        val  miles_ratio = miles.toDouble / referMile
        var isAbnormal = false
        if((miles_d < (miles_mode -3 * miles_std)||miles_d > (miles_mode+ 3 * miles_std)) &&
          (miles_ratio < miles_ratio_mode - 3*miles_ratio_std
            || miles_ratio > miles_ratio_mode + 3*miles_ratio_std)&&(miles_range>0.1*miles_mean
          )){
          isAbnormal = true
        }
        if(isAbnormal){
          miles_flag = "2"
        }
      }else{
        miles_flag = "1"
      }


      var  road_fee_range  = row.getDouble("road_fee_range")
      if(road_fee_range==null){
        road_fee_range = 0.0
      }
      var  road_fee_mean  = row.getDouble("road_fee_mean")
      if(road_fee_mean==null){
        road_fee_mean = 0.0
      }
      var  road_fee_mode  = row.getDouble("road_fee_mode")
      if(road_fee_mode==null){
        road_fee_mode = 0.0
      }
      var  road_fee_std  = row.getDouble("road_fee_std")
      if(road_fee_std==null){
        road_fee_std = 0.0
      }
      var  road_fee_ratio_mode  = row.getDouble("road_fee_ratio_mode")
      if(road_fee_ratio_mode==null){
        road_fee_ratio_mode = 0.0
      }
      var  road_fee_ratio_std  = row.getDouble("road_fee_ratio_std")
      if(road_fee_ratio_std==null){
        road_fee_ratio_std = 0.0
      }

      var road_fee_flag = "0"
      var road_fee_d = 0.0
      if(!StringUtils.isEmpty(road_fee) && road_fee.toDouble !=0){
        road_fee_d = road_fee.toDouble
      }else{
        road_fee_flag = "1"
      }

      if(road_fee_d !=0){
        var tollCharge = 0.0
        if(!StringUtils.isEmpty(toll_charge)){
          tollCharge = toll_charge.toDouble
        }
        var road_fee_ratio = 0.0

        if(tollCharge<=1){
          road_fee_ratio = 1
        }else{
          road_fee_ratio = road_fee.toDouble / tollCharge
        }

        //异常判断
        if((road_fee_d < (road_fee_mode - 3*road_fee_std) || road_fee_d>(road_fee_mode+3*road_fee_std))
          &&(road_fee_ratio < road_fee_ratio_mode - 3*road_fee_ratio_std|| road_fee_ratio > road_fee_ratio_mode + 3*road_fee_ratio_std)
          &&(road_fee_range>0.1*road_fee_mean)){
          road_fee_flag = "2"
        }else{
          road_fee_flag="0"
        }
      }

      var reject_flag = ""

      if(road_fee_flag == "0"  && miles_flag == "0" ){
        reject_flag ="0"
      }else if(road_fee_flag== "0" && miles_flag !="0"){
        reject_flag=miles_flag
      }else if(road_fee_flag !="0" && miles_flag=="0"){
        reject_flag=road_fee_flag
      }else if(road_fee_flag !="0" && miles_flag !="0"){
        reject_flag=road_fee_flag +"|"+ miles_flag
      }

      val colums = List(task_area_code,task_id,task_subid,start_dept,end_dept,start_type,end_type,line_code,linevehicle,std_id,
        vehicle_serial,conduct_type,is_run_ontime,start_longitude,start_latitude,end_longitude,end_latitude,rt_dist,
        toll_charge,is_stop,stop_over_zone_code,transoport_level,carrier_type,error_type,carrier_name,vehicle_type,
        axls_number,length,weight,mload,length_weight,miles,road_fee,
        road_fee_flag,miles_flag,reject_flag,
        fuel_prices,update_uint_fuel,fuel_cost,sum_cost,std_id_jz,std_id_jz_time,source,grd1,task_type,task_inc_day,inc_day)


      Row.fromSeq(colums.toSeq)
    })

    val scame = StructType(cols.map(
      col=>{StructField(col,StringType,nullable = true)}
    ))

    val resultDf1=  spark.createDataFrame(resultDF,scame).withColumn("inc_day", lit(inc_day))

    resultDf1.show(1)

    writeToHive(spark,resultDf1,Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_new_ks")

  }


  def  gis_eta_jiazhi_cost_new_ks(inc_day:String, spark:SparkSession) ={


    //获取最小执行时间

    val sql1  =
      s"""
         |select  min(case when  length(std_id_jz_time)> 8
         |then  from_unixtime(unix_timestamp(std_id_jz_time, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMMdd') else std_id_jz_time end ) as std_id_jz_time_min
         |from  dm_gis.gis_eta_jiazhi_task_ks
         |where inc_day  ='${inc_day}'
      """.stripMargin

    logger.error(sql1)

    var std_id_jz_time_min =  spark.sql(sql1).collectAsList().get(0).getAs[String](0)
    logger.error("最小执行时间 : " + std_id_jz_time_min)

    var before60Day = ""
    var after1Day = ""

    if (!StringUtils.isEmpty(std_id_jz_time_min)){
      before60Day = DateUtil.getdaysBeforeOrAfter(std_id_jz_time_min,-60)
      after1Day = DateUtil.getdaysBeforeOrAfter(inc_day,1)
    }

    val sql  =
      s"""
         |select  task_area_code
         |,task_id
         |,task_subid
         |,sort_num
         |,start_dept
         |,end_dept
         |,start_type
         |,end_type
         |,line_code
         |,linevehicle
         |,grd1
         |,std_id
         |,vehicle_serial
         |,conduct_type
         |,is_run_ontime
         |,start_longitude
         |,start_latitude
         |,end_longitude
         |,end_latitude
         |,cast(rt_dist as double) as rt_dist
         |,toll_charge
         |,is_stop
         |,stop_over_zone_code
         |,transoport_level
         |,carrier_type
         |,carrier_name
         |,vehicle_type
         |,axls_number
         |,length
         |,weight
         |,mload
         |,length_weight
         |,cast(miles as double) as miles
         |,cast(road_fee as double) as road_fee
         |,fuel_prices
         |,update_uint_fuel
         |,fuel_cost
         |,sum_cost
         |,error_type
         |,std_id_jz
         |,std_id_jz_time
         |,case when  length(std_id_jz_time)> 8 then  from_unixtime(unix_timestamp(std_id_jz_time, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMMdd')
         | else std_id_jz_time end  as onLine_time
         |,add_reason
         |,task_inc_day
         |,inc_day
         |, cast(miles as double)/cast(rt_dist as double)*1000 as miles_ratio
         |, case when  toll_charge <=1 then 1.0 else cast(road_fee as double) / cast(toll_charge as double)  end as road_fee_ratio
         |from  dm_gis.gis_eta_jiazhi_task_ks
         |where (conduct_type = 1 and inc_day  ='${inc_day}')
         | or  (conduct_type = 3 and inc_day >='${before60Day}' and inc_day<='${after1Day}' )
      """.stripMargin


    logger.error(sql)

    //    1.conduct_type =1 and inc_day =t-1
    //    2.conduct_type = 3 and t >= online_date >=60

    val gis_eta_jiazhi_task_ks_df  = spark.sql(sql)
    //    miles_range=miles最大值-miles最小值
    //    miles_mean：miles的均值
    //    miles_mode：miles的众数
    //    miles_std：miles的标准差
    //    miles_ratio_mode：miles_ratio 的众数
    //    miles_ratio_std：miles_ratio 的标准差

    import org.apache.spark.sql.functions._
    import  spark.implicits._

    gis_eta_jiazhi_task_ks_df.persist(StorageLevel.MEMORY_ONLY)

    val gis_eta_jiazhi_task_ks_df1  = gis_eta_jiazhi_task_ks_df.filter(('miles isNotNull) &&  'miles =!=0.0 )
      .withColumn("miles_max",max("miles")over(Window.partitionBy("grd1")))
      .withColumn("miles_min",min("miles")over(Window.partitionBy("grd1")))
      .withColumn("miles_mean",mean("miles")over(Window.partitionBy("grd1")))
      .withColumn("miles_std",stddev("miles")over(Window.partitionBy("grd1")))
      .withColumn("miles_ratio_std",stddev("miles_ratio")over(Window.partitionBy("grd1")))
      .select('grd1, 'miles_max,'miles_min,'miles_mean,'miles_std, 'miles_ratio_std).distinct()


    //    road_fee_range=road_fee最大值-road_fee最小值
    //    road_fee_mean：road_fee的均值
    //    road_fee_mode：road_fee的众数
    //    road_fee_std：road_fee的标准差
    //    road_fee_ratio_mode：road_fee_ratio的众数
    //    road_fee_ratio_std：road_fee_ratio的标准差

    val gis_eta_jiazhi_task_ks_df2  = gis_eta_jiazhi_task_ks_df.filter(('road_fee isNotNull)  &&  'road_fee =!=0.0 )
      .withColumn("road_fee_max",max("road_fee")over(Window.partitionBy("grd1")))
      .withColumn("road_fee_min",min("road_fee")over(Window.partitionBy("grd1")))
      .withColumn("road_fee_mean",mean("road_fee")over(Window.partitionBy("grd1")))
      .withColumn("road_fee_std",stddev("road_fee")over(Window.partitionBy("grd1")))
      .withColumn("road_fee_ratio_std",stddev("road_fee_ratio")over(Window.partitionBy("grd1")))
      .select('grd1, 'road_fee_max, 'road_fee_min, 'road_fee_mean, 'road_fee_std, 'road_fee_ratio_std).distinct()


    gis_eta_jiazhi_task_ks_df.persist(StorageLevel.MEMORY_ONLY)

    val jionDf =  gis_eta_jiazhi_task_ks_df
      .join(gis_eta_jiazhi_task_ks_df1,Seq("grd1"),"left")
      .join(gis_eta_jiazhi_task_ks_df2,Seq("grd1"),"left")

    logger.error(jionDf.count())

    import spark.implicits._
    val  gis_eta_jiazhi_task_ks_df3 = jionDf
      .withColumn("miles_range", 'miles_max - 'miles_min)
      .withColumn("road_fee_range", 'road_fee_max - 'road_fee_min)

    //获取 miles_ratio 和 miles 众数
    val  milesModeDf = builderMilesMode(spark,gis_eta_jiazhi_task_ks_df)

    logger.error( milesModeDf.count())

    val modeDF = gis_eta_jiazhi_task_ks_df3
      .join(milesModeDf, Seq("grd1"),"left")

    val temp =  modeDF.select('task_area_code
      ,'task_id
      ,'task_subid
      ,'sort_num
      ,'start_dept
      ,'end_dept
      ,'start_type
      ,'end_type
      ,'line_code
      ,'linevehicle
      ,'grd1
      ,'std_id
      ,'vehicle_serial
      ,'conduct_type
      ,'is_run_ontime
      ,'start_longitude
      ,'start_latitude
      ,'end_longitude
      ,'end_latitude
      ,'rt_dist
      ,'toll_charge
      ,'is_stop
      ,'stop_over_zone_code
      ,'transoport_level
      ,'carrier_type
      ,'carrier_name
      ,'vehicle_type
      ,'axls_number
      ,'length
      ,'weight
      ,'mload
      ,'length_weight
      ,'miles
      ,'road_fee
      ,'fuel_prices
      ,'update_uint_fuel
      ,'fuel_cost
      ,'sum_cost
      ,'error_type
      ,'std_id_jz
      ,'std_id_jz_time
      ,'add_reason
      ,'task_inc_day
      ,'miles_ratio
      ,'road_fee_ratio
      ,'miles_max
      ,'miles_min
      ,'miles_mean
      ,'miles_std
      ,'miles_ratio_std
      ,'road_fee_max
      ,'road_fee_min
      ,'road_fee_mean
      ,'road_fee_std
      ,'road_fee_ratio_std
      ,'miles_range
      ,'road_fee_range
      ,'miles_ratio_mode
      ,'miles_mode
      ,'road_fee_mode
      ,'road_fee_ratio_mode
      ,'inc_day)


    temp.show(1,false)
    //      writeToHive(spark,temp,Seq("inc_day"),"dm_gis.gis_eta_jiazhi_task_ks_temp")

    val resultDf = modeDF.drop("miles_max","miles_min","road_fee_max","road_fee_min")

    SparkUtils.getRowToJson(resultDf)

  }



  //获取众数
  def builderMilesMode(spark:SparkSession, gis_eta_jiazhi_task_ks_df: DataFrame)= {

    import spark.implicits._

    val gis_eta_jiazhi_task_ks_df1_miles  = gis_eta_jiazhi_task_ks_df.filter(('miles isNotNull)  &&  'miles =!=0.0 )
      .withColumn("count",count(lit(1))over(Window.partitionBy("grd1")))
      .withColumn("count_miles_ratio",count(lit(1))over(Window.partitionBy("grd1","miles_ratio")))
      .withColumn("count_miles",count(lit(1))over(Window.partitionBy("grd1","miles")))

    val gis_eta_jiazhi_task_ks_df1_road_fee  = gis_eta_jiazhi_task_ks_df.filter(('road_fee isNotNull)  &&  'road_fee =!=0.0 )
      .withColumn("count",count(lit(1))over(Window.partitionBy("grd1")))
      .withColumn("count_road_fee",count(lit(1))over(Window.partitionBy("grd1","road_fee")))
      .withColumn("count_road_fee_ratio",count(lit(1))over(Window.partitionBy("grd1","road_fee_ratio")))


    val gis_eta_jiazhi_task_ks_df2_miles = gis_eta_jiazhi_task_ks_df1_miles
      .withColumn("count_miles_ratio_pre", 'count_miles_ratio / 'count)
      .withColumn("count_miles_pre", 'count_miles / 'count)
      .select('grd1,'miles,'miles_ratio,'count, 'count_miles_ratio,'count_miles,'count_miles_ratio_pre, 'count_miles_pre)
      .distinct()

    val gis_eta_jiazhi_task_ks_df2_miles_Json = SparkUtils.getRowToJson(gis_eta_jiazhi_task_ks_df2_miles)

    val grd1Mode_milesDF =  gis_eta_jiazhi_task_ks_df2_miles_Json.map(row =>{
      (row.getString("grd1"),
        (row.getDouble("count_miles_ratio_pre"),
          row.getDouble("count_miles_pre"),
          row.getString("miles"),
          row.getString("miles_ratio")
        ))
    }).groupByKey().map(row  =>  {
      val  grd1 =row._1
      val lists  = row._2.iterator
      var count_miles_ratio_pre = 0.0
      var count_miles_pre = 0.0

      var miles  = ""
      var miles_ratio  = ""

      while(lists.hasNext){
        val row_data = lists.next()
        val count_miles_ratio_pre_y = row_data._1
        val count_miles_pre_y = row_data._2

        if(count_miles_ratio_pre < count_miles_ratio_pre_y && null !=  row_data._4  ){
          count_miles_ratio_pre = count_miles_ratio_pre_y
          miles_ratio = row_data._4
        }

        if(count_miles_pre < count_miles_pre_y && row_data._3 != null ){
          count_miles_pre = count_miles_pre_y
          miles = row_data._3
        }
      }
      (grd1,miles_ratio,miles)
    }).toDF("grd1","miles_ratio_mode","miles_mode").distinct()



    val gis_eta_jiazhi_task_ks_df2_road_fee = gis_eta_jiazhi_task_ks_df1_road_fee
      .withColumn("count_road_fee_pre", 'count_road_fee / 'count)
      .withColumn("count_road_fee_ratio_pre", 'count_road_fee_ratio / 'count)
      .select('grd1,'road_fee,'road_fee_ratio, 'count_road_fee,'count_road_fee_ratio,'count_road_fee_pre, 'count_road_fee_ratio_pre)
      .distinct()


    val gis_eta_jiazhi_task_ks_df2_road_fee_Json = SparkUtils.getRowToJson(gis_eta_jiazhi_task_ks_df2_road_fee)


    val grd1ModeFreeDF =  gis_eta_jiazhi_task_ks_df2_road_fee_Json.map(row =>{
      (row.getString("grd1"),(
        row.getDouble("count_road_fee_pre"),
        row.getDouble("count_road_fee_ratio_pre"),
        row.getString("road_fee"),
        row.getString("road_fee_ratio")
      ))
    }).groupByKey().map(row  =>  {
      val  grd1 =row._1
      val lists  = row._2.iterator
      var count_road_fee_pre = 0.0
      var count_road_fee_ratio_pre = 0.0

      var road_fee  = ""
      var road_fee_ratio  = ""

      while(lists.hasNext){
        val row_data = lists.next()

        val count_road_fee_pre_y = row_data._1

        val count_road_fee_ratio_pre_y = row_data._2

        if(count_road_fee_pre < count_road_fee_pre_y&& row_data._3 != null ){
          count_road_fee_pre = count_road_fee_pre_y
          road_fee = row_data._3
        }

        if(count_road_fee_ratio_pre < count_road_fee_ratio_pre_y && row_data._4 != null ){
          count_road_fee_ratio_pre = count_road_fee_ratio_pre_y
          road_fee_ratio = row_data._4
        }
      }
      (grd1,road_fee.toString,road_fee_ratio.toString)
    }).toDF("grd1","road_fee_mode","road_fee_ratio_mode").distinct()


    val gis_eta_jiazhi_task_ks_df2 = gis_eta_jiazhi_task_ks_df
      .join(grd1ModeFreeDF,Seq("grd1"),"left")
      .join(grd1Mode_milesDF,Seq("grd1"),"left")

    gis_eta_jiazhi_task_ks_df2.filter('grd1==="021KA_021WG_121.68_30.92_121.52_31.06_6米8_9吨")
      .show(1000, false)

    var resulteDf =  gis_eta_jiazhi_task_ks_df2.select('grd1 , 'road_fee_mode,'road_fee_ratio_mode, 'miles_ratio_mode, 'miles_mode  ).distinct()

    resulteDf
  }

}
