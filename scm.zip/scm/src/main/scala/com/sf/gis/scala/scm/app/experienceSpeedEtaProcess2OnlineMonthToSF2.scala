package com.sf.gis.scala.scm.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.ShellExcutor
import org.apache
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.io.NullWritable
import org.apache.hadoop.mapred.{InvalidJobConfException, JobConf}
import org.apache.hadoop.mapred.lib.MultipleTextOutputFormat
import org.apache.hadoop.mapreduce.security.TokenCache
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import utils.{JSONUtils, SparkUtils}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer


/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/10/25
*/


class RDDMultipleTextOutputFormat2 extends MultipleTextOutputFormat[Any, Any] {
  //  override def generateFileNameForKeyValue(key: Any, value: Any, name: String): String =
  //    key.asInstanceOf[String]

  override def generateActualKey(key: Any, value: Any): Any =
    NullWritable.get()

  override def generateFileNameForKeyValue(key: Any, value: Any, name: String): String =
  //    key.toString+"/"+name
    key.asInstanceOf[String] + ".csv"

  override def checkOutputSpecs(ignored: FileSystem, job: JobConf): Unit = {
    val name: String = job.get(org.apache.hadoop.mapreduce.lib.output.FileOutputFormat.OUTDIR)
    var outDir: Path = if (name == null) null else new Path(name)
    //当输出任务不等于0 且输出的路径为空，则抛出异常
    if (outDir == null && job.getNumReduceTasks != 0) {
      throw new InvalidJobConfException("Output directory not set in JobConf.")
    }
    //当有输出任务和输出路径不为null时
    if (outDir != null) {
      val fs: FileSystem = outDir.getFileSystem(job)
      outDir = fs.makeQualified(outDir)
      outDir = new Path(job.getWorkingDirectory, outDir)
      job.set(org.apache.hadoop.mapreduce.lib.output.FileOutputFormat.OUTDIR, outDir.toString)
      TokenCache.obtainTokensForNamenodes(job.getCredentials, Array[Path](outDir), job)
      //下面的注释掉，就不会出现这个目录已经存在的提示了
      /* if (fs.exists(outDir)) {
           throw new FileAlreadyExistsException("Outputdirectory"
                   + outDir + "alreadyexists");
       }
    }*/

    }
  }
}//



object experienceSpeedEtaProcess2OnlineMonthToSF2 {

  @transient lazy val logger: Logger = Logger.getLogger(experienceSpeedEtaProcess2OnlineMonthToSF2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  var isGS : Boolean  = false

  val weekFileNameMap = new mutable.HashMap[Int,String]()
  weekFileNameMap.put(1,"mon")
  weekFileNameMap.put(2,"tue")
  weekFileNameMap.put(3,"wed")
  weekFileNameMap.put(4,"thu")
  weekFileNameMap.put(5,"fri")
  weekFileNameMap.put(6,"sat")
  weekFileNameMap.put(7,"sun")


  def main(args: Array[String]): Unit = {

    val inc_day = args(0)


    start(inc_day)

  }


  /**
    * 存储到hdfs文件中（speed）
    * @param sourceRdd
    * @param inc_day
    * @param spark
    */

//  (adcode,swid_in,swid_out_or_dir,periodType,weekDay,quantile_50,quantile_60,quantile_70)

def saveToHdfsFileSpeed(sourceRdd: RDD[(String, String, String, Int, Int, Double, Int)],
                        inc_day: String, spark: SparkSession, static_filed: String, save_name: String,
                        tag_name: String): Unit = {
      import Array._
      val staticRdd = sourceRdd
        .map(x => {
          val (adcode, swid_in, swid_out_or_dir, periodType, weekDay, quantile_60_speed, freCnt) = x
          val jo = new JSONObject()
          jo.put("periodType", periodType)
          jo.put("staticFiled", quantile_60_speed)
          jo.put("freCnt", freCnt)
          jo.put("weekDay", weekDay)

          //      (adcode, linkid, dir, periodType,avgSpeed,sumCnt)
          ((adcode, swid_in, swid_out_or_dir), jo)
        })
        .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
        .map(x => {

          val typeList = range(0, 96)

          val (adcode, swid_in, swid_out_or_dir) = x._1
          val joList = x._2

          val weekList = List(1, 2, 3, 4, 5)
          val restList = List(6, 7)

          val joListAdd = new ArrayBuffer[JSONObject]()

          for (i <- typeList) {
            val tmpTypeList = joList.filter(obj => {
              val joType = JSONUtils.getJsonValueInt(obj, "periodType", 0)
              joType == i
            })

            // TODO: 填充缺失值
            // TODO: step 1 筛选出周一到周五的数据 与 周六、日的数据
            val weekDayList = tmpTypeList.filter(obj => {
              val weekDay = JSONUtils.getJsonValueInt(obj, "weekDay", 4)
              weekList.contains(weekDay)
            })
            val restDayList = tmpTypeList.filter(obj => {
              val weekDay = JSONUtils.getJsonValueInt(obj, "weekDay", 7)
              restList.contains(weekDay)
            })

            var week_day_speed_sum = 0.0
            var week_day_speed_cnt = 0
            var rest_day_speed_sum = 0.0
            var rest_day_speed_cnt = 0

            // TODO: step 2 求工作日该时段的平均速度和总次数 与 休息日的该时段的平均速度与总次数
            weekDayList.map(obj => {
              val staticFiled = JSONUtils.getJsonValueDouble(obj, "staticFiled", 0)
              val freCnt = JSONUtils.getJsonValueInt(obj, "freCnt", 1)

              week_day_speed_sum += staticFiled * freCnt
              week_day_speed_cnt += freCnt
            })

            restDayList.map(obj => {
              val staticFiled = JSONUtils.getJsonValueDouble(obj, "staticFiled", 0)
              val freCnt = JSONUtils.getJsonValueInt(obj, "freCnt", 1)

              rest_day_speed_sum += staticFiled * freCnt
              rest_day_speed_cnt += freCnt
            })


            // TODO: step3 将该时段缺失值赋值


            // 求得工作日和休息日得速度平均值
            val week_day_speed_avg = if (week_day_speed_cnt != 0) week_day_speed_sum / week_day_speed_cnt else 0
            val rest_day_speed_avg = if (rest_day_speed_cnt != 0) rest_day_speed_sum / rest_day_speed_cnt else 0
            val addWeekFlag = if (week_day_speed_cnt <= 1 && week_day_speed_avg <= 5) 0 else 1
            val addRestFlag = if (rest_day_speed_cnt <= 1 && rest_day_speed_avg <= 5) 0 else 1

            val weekDayAllList = List(1, 2, 3, 4, 5, 6, 7)

            for (week <- weekDayAllList) {
              var weekDayList = tmpTypeList.filter(obj => {
                val weekDay = JSONUtils.getJsonValueInt(obj, "weekDay", 4)
                weekDay == week
              })

              if (weekDayList.size == 0 && weekList.contains(week) && addWeekFlag == 1) {
                val weekDayAdd = new JSONObject()
                weekDayAdd.put("periodType", i)
                weekDayAdd.put("weekDay", week)
                weekDayAdd.put("freCnt", week_day_speed_cnt)
                weekDayAdd.put("staticFiled", week_day_speed_avg)

                // 将工作日填充数据添加进结果数组
                joListAdd.append(weekDayAdd)

              } else if (weekDayList.size == 0 && restList.contains(week) && addRestFlag == 1) {
                val restDayAdd = new JSONObject()
                restDayAdd.put("periodType", i)
                restDayAdd.put("weekDay", week)
                restDayAdd.put("staticFiled", rest_day_speed_avg)
                restDayAdd.put("freCnt", rest_day_speed_cnt)

                // 将休息日填充数据添加进结果数组
                joListAdd.append(restDayAdd)

              } else if (weekDayList.size == 1) {
                // 将未符合填充的数据添加进结果数组
                if (JSONUtils.getJsonValueInt(weekDayList.head, "freCnt", 4) > 1  || JSONUtils.getJsonValueInt(weekDayList.head, "staticFiled", 0) > 5) {
                  joListAdd.append(weekDayList.head)
                }
              } else if (weekDayList.size > 1) {
                // 将未符合填充的数据添加进结果数组
                // 防止原本数据频次为1并且速度小于5的情况
//                if (JSONUtils.getJsonValueInt(weekDayList.head, "freCnt", 4) > 1 || JSONUtils.getJsonValueInt(weekDayList.head, "staticFiled", 0) > 5){
//                  joListAdd.append(weekDayList.head)
//                }
                joListAdd.append(weekDayList.head)
              }
            }


          }
          (x._1, joListAdd)
        }).flatMap(x => {
        val (adcode, swid_in, swid_out_or_dir) = x._1
        val joList = x._2.toList
        val resList = joList.groupBy(obj => {
          val weekDay = JSONUtils.getJsonValueInt(obj, "weekDay", 7)
          weekDay
        }).map(obj => {
          val weekDay = obj._1
          val list = obj._2
          var rowList = List(swid_in, swid_out_or_dir, weekDay)

          //              val listNew = list.map(y => {
          val typeList = range(0, 96)
          for (i <- typeList) {
            val tmpTypeList = list.filter(obj2 => {
              val joType = JSONUtils.getJsonValueInt(obj2, "periodType", 0)
              joType == i
            })
            if (tmpTypeList.size == 0) {
              rowList = rowList :+ "0"
            } else {
              rowList = rowList :+ JSONUtils.getJsonValueDouble(tmpTypeList.head, "staticFiled", 0).toInt.toString
            }
          }
          val key = save_name + "_" + adcode
          key + "|" +  rowList.mkString(",")
        })
        resList
      })
        .map(x => {
          val strings = x.split("\\|")
          val key = strings(0)
          val rowList = strings(1)
          (key,rowList)
        })
    .persist(StorageLevel.MEMORY_AND_DISK_SER)


    logger.error("static" + static_filed + "的数据量为：" + staticRdd.count())


   //经验速度搞得数据填充
//   val tag_name = builderSpeedByGD(spark, staticRdd,adcode);


    val rmCmd = s"/user/01420395/upload/gis/data/${static_filed}/${tag_name}"
    logger.error("预先删除文件" + rmCmd)
    ShellExcutor.exeCmd(s"hadoop fs -rm -r ${rmCmd}")

    staticRdd.partitionBy(new apache.spark.HashPartitioner(100)).saveAsHadoopFile(s"/user/01420395/upload/gis/data/${inc_day}/${static_filed}/${tag_name}", classOf[String], classOf[String],
      classOf[RDDMultipleTextOutputFormat2])

  }

  /**
    * 高德数据填充
    * @param spark
    * @param staticRdd
    * @param staStat
//    */
//  def builderSpeedByGD(spark:SparkSession , staticRdd:RDD[JSONObject],  adcode: String):RDD={
//
//    //获取对应高德的数据
//    adcode
//
//
//
//
//
//
//  }


  /**
    * 存储到hdfs文件中（tally,cost）
    * @param sourceRdd
    * @param inc_day
    * @param spark
    */

  def saveToHdfsFile(sourceRdd: RDD[(String, String, String, Int, Int, Double, Int)], inc_day: String,spark:SparkSession,static_filed:String,save_name:String,tag_name:String): Unit = {
    import Array._
    val staticRdd = sourceRdd
      .map(x => {
        val (adcode, swid_in, swid_out_or_dir, periodType, weekDay, avg, cnt) = x
        val jo = new JSONObject()
        val staticFiled = if (static_filed.equals("tally")) cnt else avg

        jo.put("periodType", periodType)
        jo.put("staticFiled", staticFiled)

        //      (adcode, linkid, dir, periodType,avgSpeed,sumCnt)
        ((adcode, swid_in, swid_out_or_dir, weekDay), jo)
      })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {

        val typeList = range(0, 96)
        val (adcode, swid_in, swid_out_or_dir, weekDay) = x._1
        val joList = x._2


        // TODO: 拼接格式不同，如果是crosscost则需要增加第三列默认值为4
        var rowList = if (static_filed.equals("cross")) List(swid_in, swid_out_or_dir, "4") else List(swid_in, swid_out_or_dir,weekDay)


        for (i <- typeList) {
          val tmpTypeList = joList.filter(obj => {
            val joType = JSONUtils.getJsonValueInt(obj, "periodType", 0)
            joType == i
          })

          if (tmpTypeList.isEmpty || tmpTypeList.size == 0) {
            if (static_filed.equals("cross")) rowList = rowList :+ "-1.00" else rowList = rowList :+ "0"
          } else {
            if (static_filed.equals("cross")) rowList = rowList :+ JSONUtils.getJsonValue(tmpTypeList.head, "staticFiled", "0") else rowList = rowList :+ JSONUtils.getJsonValueDouble(tmpTypeList.head, "staticFiled", 0).toInt.toString
          }
        }

        val key = save_name + "_" + adcode

        (key, rowList.mkString(","))
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("static" + static_filed + "的数据量为：" + staticRdd.count())

      val rmCmd = s"/user/01401062/upload/gis/data/${static_filed}/${tag_name}"
      logger.error("预先删除文件" + rmCmd)
      ShellExcutor.exeCmd(s"hadoop fs -rm -r ${rmCmd}")

      staticRdd.partitionBy(new apache.spark.HashPartitioner(100)).saveAsHadoopFile(s"/user/01401062/upload/gis/data/${inc_day}/${static_filed}/${tag_name}", classOf[String], classOf[String],
        classOf[RDDMultipleTextOutputFormat2])

  }


  def calUnionAvgCnt(obj1: (Double, Int,Double), obj2: (Double, Int,Double)): (Double, Int,Double) = {

    val avg_speed1 = obj1._1
    val avg_speed2 = obj2._1

    var max_speed = if (avg_speed1 > avg_speed2) avg_speed1 else avg_speed2

    val fre1 = obj1._2
    val fre2 = obj2._2

    val fre = fre1 + fre2
    var avg_speed = try { (avg_speed1 * fre1 + avg_speed2 * fre2) / fre} catch {case e:Exception => 0}
    avg_speed = avg_speed.formatted("%.2f").toDouble
    (avg_speed,fre,max_speed)
  }

  /**
    * 读取统计日表数据
    *
    * @param spark
    * @param inc_day
    * @return
    */

  def getDailyStatTable(spark: SparkSession, inc_day: String,ak:Int) = {
    val speedSql =
      s"""
         |select
         |  concat(substr(adcode,0,4),'00') as adcode,swid_in, dir,time_range,weekday,avg_speed,frequecy,quantile_60
         |from
         |  dm_gis.eta_experience_speed_info_daily_quantile
         |where
         | --  inc_day >= '20221021'
         | -- inc_day <= '${inc_day}'
         | -- and
         |inc_day >= '20230101'
         |-- and adcode rlike '^1301.*'
         |and PMOD(hash(concat(substr(adcode,0,4),'00')), 10) = '${ak}'
         |-- limit 100
       """.stripMargin

    val costSql =
      s"""
         |select
         |  concat(substr(adcode,0,4),'00') as adcode,swid_in,dir,time_range,weekday,avg_speed,frequecy
         |from
         |  dm_gis.eta_experience_cross_info_daily_quantile
         |where
         |  inc_day >= '20230101'
         | -- limit 100
         | --  inc_day <= '${inc_day}'
         | -- and inc_day >= '20220501'
         | and PMOD(hash(concat(substr(adcode,0,4),'00')), 10) = '${ak}'
         | -- and adcode rlike '^1301.*'
       """.stripMargin


    logger.error(speedSql)
    val speedDf = spark.sql(speedSql)
//    speedDf.repartition(1).toDF().write.mode(SaveMode.Overwrite).option("header", "true").csv("/user/01401062/upload/gis/data/eta/20221222_speed.csv")

    val costRddDf = spark.sql(costSql)
//    costRddDf.repartition(1).toDF().write.mode(SaveMode.Overwrite).option("header", "true").csv("/user/01401062/upload/gis/data/eta/20221222_cost.csv")


    val speedRdd = SparkUtils.getRowToJson(speedDf,1000).map(x => {

      val adcode = JSONUtils.getJsonValue(x,"adcode","") //行政编码
//      val adcode = JSONUtils.getJsonValue(x,"adcode","").substring(0,4) + "00"
      val swid_in = JSONUtils.getJsonValue(x,"swid_in","") //行政编码
      val swid_out_or_dir = JSONUtils.getJsonValue(x,"dir","") //行政编码
      val periodType = JSONUtils.getJsonValueInt(x,"time_range",0).toInt
      val weekDay = JSONUtils.getJsonValueInt(x,"weekday",4).toInt
      val cnt = JSONUtils.getJsonValueInt(x,"frequecy",1).toInt

      x.remove("swid_in")
      x.remove("dir")
      ((adcode,swid_in,swid_out_or_dir,periodType,weekDay),x)
    })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val (adcode,swid_in,swid_out_or_dir,periodType,weekDay) = x._1

        val listSort = x._2.sortBy(obj => {
          val quantile_60 = JSONUtils.getJsonValueDouble(obj,"quantile_60",0)
          quantile_60
        })

        var quantile_60 = 0.0

        var freSum = 0
        listSort.map(obj => {
          val cnt = JSONUtils.getJsonValueInt(obj,"frequecy",1).toInt
          freSum += cnt
        })

        var index60  = scala.math.ceil(freSum * 0.6).toInt
        if (listSort.size == 1) index60 = 0 else if (index60 >= listSort.size) index60 = listSort.size - 1

        var freSum60 = 0

        import scala.util.control.Breaks.{break, breakable}
        breakable {
          for (i <- (0 to (listSort.size - 1))) {
            val cnt = JSONUtils.getJsonValueInt(listSort(i), "frequecy", 1).toInt
            freSum60 += cnt
            if (freSum60 >= index60) {
              quantile_60 = JSONUtils.getJsonValueDouble(listSort(i), "quantile_60", 0)
              break()
            }
          }
        }
        (adcode,swid_in,swid_out_or_dir,periodType,weekDay,quantile_60,freSum)
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("输入speedRdd数据量为：" + speedRdd.count())


    val costRdd = SparkUtils.getRowToJson(costRddDf,1000).map(x => {

      val adcode = JSONUtils.getJsonValue(x,"adcode","").substring(0,4) + "00"
      val swid_in = JSONUtils.getJsonValue(x,"swid_in","")
      val swid_out_or_dir = JSONUtils.getJsonValue(x,"dir","")
      val periodType = JSONUtils.getJsonValueInt(x,"time_range",0).toInt
      val weekDay = JSONUtils.getJsonValueInt(x,"weekday",4).toInt
      val avg = JSONUtils.getJsonValueDouble(x,"avg_speed",0)
      val cnt = JSONUtils.getJsonValueInt(x,"frequecy",1).toInt


      ((adcode,swid_in,swid_out_or_dir,periodType,weekDay),x)
    })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val (adcode,swid_in,swid_out_or_dir,periodType,weekDay) = x._1
        val listSort = x._2.sortBy(obj => {
          val avg_speed = JSONUtils.getJsonValueDouble(obj,"avg_speed",0)
          avg_speed
        })


        var quantile_15 = 0.0
        var quantile_85 = 0.0


        val size = listSort.size
        val index15  = (size* 0.15).toInt
        val index85  = (size* 0.85).toInt

        val filterList = try {listSort.slice(index15,index85)} catch {case e:Exception => listSort}

        var costSum = 0.0
        var cnt = 0

        filterList.map(obj => {
          val crosscost = JSONUtils.getJsonValueDouble(obj,"avg_speed",0)
          val fre = JSONUtils.getJsonValueInt(obj,"frequecy",1).toInt
          costSum += crosscost
          cnt += fre
        })
        val avgCost = costSum / cnt

        (adcode,swid_in,swid_out_or_dir,periodType,weekDay,avgCost,cnt)
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)


    logger.error("输入costRdd数据量为：" + costRdd.count())


    (speedRdd,costRdd)

  }





  def staStat(spark: SparkSession, inc_day: String,ak:Int): Unit = {

      // TODO: 解析轨迹表
      val (speedRdd,costRdd) = getDailyStatTable(spark,inc_day,ak)
      costRdd.take(2).foreach(println(_))
      speedRdd.take(2).foreach(println(_))


      // TODO: costRdd
      saveToHdfsFileSpeed(speedRdd,inc_day,spark,"speed","speed",ak.toString)


//      saveToHdfsFile(speedRdd,inc_day,spark,"tally","tally",ak.toString)
//
//
//      saveToHdfsFile(costRdd,inc_day,spark,"cross","cross_cost",ak.toString)

  }






  def start(inc_day: String): Unit = {


    val spark = SparkUtils.getSparkSession(appName,"yarn")
    spark.conf.set("mapreduce.fileoutputcommitter.algorithm.version", "2")

    spark.sparkContext.setLogLevel("ERROR")

    val incDay = "20230403"
    logger.error(println("当前计算日期为：" + incDay))


    import scala.Array.range

    val akList = range(0, 10)

    for (ak <- akList){

      staStat(spark, incDay,ak)

    }

//    staStat(spark, incDay,0)


    logger.error("统计完成")

  }

}