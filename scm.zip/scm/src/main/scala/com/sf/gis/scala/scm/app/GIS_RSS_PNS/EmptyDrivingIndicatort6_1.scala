package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.SparkBuilder


/**
  *@author 01420395
  *@DESCRIPTION
  *轨迹缺失表 需求ID 1842890   GIS-RSS-PNS：【价值线路】空驶指标监控需求_V1.0
  *任务id： 770639
  *@create 2023/06/14
  */
object EmptyDrivingIndicatort6_1 extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val gis_eta_jiazhi_cost_stat_new_ksDf = gis_eta_jiazhi_cost_stat_new_ks(inc_day, spark)

    import spark.implicits._

    val resultDF = gis_eta_jiazhi_cost_stat_new_ksDf
      .select('task_area_code
        ,'line_code
        ,'vehicle_type
        ,'online_date
        ,'miles
        ,'road_fee
        ,'fuel_cost
        ,'sum_cost
        ,'re_road_fee
        ,'re_miles
        ,'re_fuel_cost
        ,'re_sum_cost
        ,'diff_road_fee
        ,'diff_fuel_cost
        ,'diff_miles
        ,'diff_sum_cost
        ,'diff_cost_flag
        ,'num
        ,'road_fee_mean
        ,'miles_mean
        ,'fuel_cost_mean
        ,'sum_cost_mean
        ,'re_road_fee_mean
        ,'re_miles_mean
        ,'re_fuel_cost_mean
        ,'re_sum_cost_mean
        ,'diff_road_fee_mean
        ,'diff_fuel_cost_mean
        ,'diff_miles_mean
        ,'diff_sum_cost_mean
        ,'inc_day)

    writeToHive(spark, resultDF, Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_stat_new_ks")

  }


  def gis_eta_jiazhi_cost_stat_new_ks(inc_day:String,spark:SparkSession)={

    val gis_eta_jiazhi_cost_stat_new_ks_Sql =
      s"""
         |select task_area_code
         |,line_code
         |,vehicle_type
         |,inc_day
         |,online_date
         |,sum(miles) as miles
         |,sum(road_fee) as road_fee
         |,sum(fuel_cost) as fuel_cost
         |,sum(sum_cost) as sum_cost
         |,sum(re_road_fee) as re_road_fee
         |,sum(re_miles) as re_miles
         |,sum(re_fuel_cost) as re_fuel_cost
         |,sum(re_sum_cost) as re_sum_cost
         |,sum(diff_road_fee) as diff_road_fee
         |,sum(diff_fuel_cost) as diff_fuel_cost
         |,sum(diff_miles) as diff_miles
         |,sum(diff_sum_cost) as diff_sum_cost
         |,count(task_id) as num
         |from  dm_gis.gis_eta_jiazhi_cost_compute55_ks
         |where  inc_day  = '${inc_day}'
         |and diff_sum_cost is not null
         |group by task_area_code
         |,line_code
         |,vehicle_type
         |,inc_day
         |,online_date
      """.stripMargin

    val resultDF = spark.sql(gis_eta_jiazhi_cost_stat_new_ks_Sql)

    import org.apache.spark.sql.functions._
    import spark.implicits._

    val resultDF1 =  resultDF.withColumn("road_fee_mean",'road_fee/'num)
      .withColumn("miles_mean",'miles/'num)
      .withColumn("fuel_cost_mean",'fuel_cost/'num)
      .withColumn("sum_cost_mean",'sum_cost/'num)
      .withColumn("re_road_fee_mean",'re_road_fee/'num)
      .withColumn("re_miles_mean",'re_miles/'num)

      .withColumn("re_fuel_cost_mean",'re_fuel_cost/'num)
      .withColumn("re_sum_cost_mean",'re_sum_cost/'num)
      .withColumn("diff_road_fee_mean",'diff_road_fee/'num)
      .withColumn("diff_fuel_cost_mean",'diff_fuel_cost/'num)
      .withColumn("diff_miles_mean",'diff_miles/'num)
      .withColumn("diff_sum_cost_mean",'diff_sum_cost/'num)
      .withColumn("diff_cost_flag",when('diff_sum_cost.cast("double")===0,lit("0")).otherwise(
        when('diff_sum_cost.cast("double")>0,lit("1")).otherwise(lit("2")))
      )

    resultDF1
  }


}
