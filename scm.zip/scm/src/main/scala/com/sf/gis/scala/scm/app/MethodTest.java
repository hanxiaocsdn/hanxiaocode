/**
 * Copyright (C), 2015-2023
 * FileName: MethodTest
 * Author:   caiguofang
 * Date:     2023/10/17 14:39
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
package com.sf.gis.scala.scm.app;

import com.sf.gis.scala.base.util.StringUtils;

import java.lang.reflect.*;

/**
 * 〈〉
 * @ClassName MethodTest
 * @author 01420395
 * @create 2023/10/17 14:39
 * @since 1.0.0
 */
public class MethodTest {


    public static void printMethods(Class<?> classType)
            throws Exception{
        //获得类的所有方法
        Method methods[] = classType.getDeclaredMethods();
        for(Method method : methods)
            System.out.println(method.toString());
    }


    public static void invokeMethod(TestJson m)throws Exception{
        //表示Employee类的setAge()方法
        Method method=m.getClass()
                .getMethod("setAge",new Class[]{int.class});
        //调用Employee对象的setAge()方法
        method.invoke(m,new Object[]{Integer.valueOf(18)});

        //表示Employee类的getAge()方法
        method=m.getClass().getMethod("getAge");
        //调用Employee对象的getAge()方法
        Object returnValue=method.invoke(m);
        //打印18
        System.out.println(returnValue);

    }
}