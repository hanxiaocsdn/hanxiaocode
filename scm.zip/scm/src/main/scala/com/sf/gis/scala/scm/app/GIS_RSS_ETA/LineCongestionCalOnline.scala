package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.vividsolutions.jts.geom.{Coordinate, GeometryFactory}
import org.apache.log4j.Logger
import org.apache.spark.RangePartitioner
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DateTimeUtil, JSONUtils, SparkUtils, StringUtils}

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import scala.Array.range
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.Try

object LineCongestionCalOnline {

  @transient lazy val logger: Logger = Logger.getLogger(LineCongestionCalOnline.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class JamCalRes(task_id: String, task_subid: String, line_code: String, task_area_code: String, vehicle_serial: String,
                       start_dept: String, end_dept: String, start_outer_add_code: String, end_outer_add_code: String,
                       carrier_name: String, actual_carrier_name: String, plan_depart_tm: String, actual_depart_tm: String,
                       plan_arrive_tm: String, actual_arrive_tm: String, line_time: String, actual_run_tm: String, line_distance: String,
                       start_point: String, end_point: String, transoport_level: String, point_type: String, point_name: String,
                       jam_period: String, event_final_uni: String, warn_final_uni: String,
                       jp_coords: String, jp_swid: String, jp_time: String, jp_length: String,
                       jam_status: String, jam_time: String, jam_swid: String, jam_length: String,
                       jam_exp_speed: String, jam_time_delta: String, jam_time_delta_total: String, jam_period2: String, jam_coords: String, yongdu_continue_tm: String,
                       swid_len_exp: String, disu_duration_exp: String, sum_swid_len_exp: String, speed_siji: String)


  def getSorcePair(spark: SparkSession, inc_day: String) = {

    val sourceSql =
      s"""
         |select
         |  pair_name,hull_coords
         |from
         |  dm_gis.highway_pair_nodes
       """.stripMargin

    val lineDf = spark.sql(sourceSql)

    //    val lineDf = spark.read.format("csv").option("header", "true").option("delimiter","\t").load("d:\\user\\01401062\\桌面\\highway_nodes.csv")

    val pairNodeRdd = SparkUtils.getRowToJson(lineDf, "MEMORY_AND_DISK_SER")
    logger.error("获取节点数据总量为：" + lineDf.count())
    pairNodeRdd.take(2).foreach(println(_))

    pairNodeRdd
  }

  def getLineData(spark: SparkSession, inc_day: String, ak: Int) = {

    val sourceSql =
      s"""
         |SELECT
         |  *
         | FROM
         |(
         |select
         |  *,
         | ROW_NUMBER() OVER (PARTITION BY task_subid ORDER BY yongdu_time2) AS row_num
         |from
         |  dm_gis.eta_std_line_recall_realtime_congestion
         |where
         |  inc_day='${inc_day}'
         |and
         |  regexp_replace(yongdu_time2,";","") != ''
         |and
         |  PMOD(hash(reverse(task_id)), 60) = '${ak}'
         |) AS ranked
         |WHERE
         |    row_num = 1
       """.stripMargin


    val lineDf = spark.sql(sourceSql)

    //    val lineDf = spark.read.format("csv").option("header", "true").option("delimiter","\t").load("d:\\user\\01401062\\桌面\\line_test.csv")

    val lineRdd = SparkUtils.getRowToJson(lineDf, "MEMORY_AND_DISK_SER")

    logger.error("获取线路轨迹数据量为：" + lineRdd.count())

    lineRdd

  }

  def scheduleYongdu(jamRdd: RDD[((String, Int, String), Iterable[JSONObject])]) = {
    val yongduCalRdd = jamRdd.map(x => {

      //      val fixUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/post?url=http://gis-int.int.sfdc.com.cn:1080/rp/navi/query/getExprCost"
      val fixUrl = "http://gis-int.int.sfdc.com.cn:1080/rp/navi/query/getExprCost"
      val task_subid, jam_index, node_name = x._1
      val yongduList = x._2.toList.sortBy(_.getString("jp_time"))

      val jamHead = yongduList.head

      // 截取出的拥堵段
      val yongduTimeList = yongduList.map(jp => JSONUtils.getJsonValueLong(jp, "jp_time", 0))
      val minJpTime = yongduTimeList.min
      val maxJpTime = yongduTimeList.max
      val jam_period = minJpTime + "~" + maxJpTime
      val jam_period2 = DateTimeUtil.timestampConvertDate(minJpTime, "yyyy-MM-dd HH:mm:ss") + "~" + DateTimeUtil.timestampConvertDate(maxJpTime, "yyyy-MM-dd HH:mm:ss")


      // TODO: 待确认数据格式
      val yongdu_continue_tm = maxJpTime.toDouble - minJpTime.toDouble

      val jam_swid = yongduList.map(_.getString("jp_swid")).mkString("|")
      val jam_length = yongduList.map(_.getString("jp_length")).mkString("|")
      val jam_coords = yongduList.map(_.getString("jp_coords")).mkString("|")
      val jam_time = yongduList.map(_.getString("jp_time")).mkString("|")

      val post_jam = postJamRequest(jam_swid, jam_period2, jam_swid, jam_length, fixUrl)

      val swid_exp = post_jam._1
      val speed_exp = post_jam._2
      val swid_len_exp = post_jam._3
      val disu_duration_exp = post_jam._4
      val sum_swid_len_exp = post_jam._5

      // 总拥堵时长 - 低速时长
      val jam_time_delta_before = yongdu_continue_tm - disu_duration_exp.toDouble
      val jam_time_delta = if (jam_time_delta_before < 0) 0 else jam_time_delta_before

      val speed_siji = sum_swid_len_exp.toDouble / 1000 / yongdu_continue_tm / 60


      jamHead.put("jam_swid", jam_swid)
      jamHead.put("jam_length", jam_length)
      jamHead.put("jam_coords", jam_coords)
      jamHead.put("jam_time", jam_time)
      jamHead.put("jam_period", jam_period)
      jamHead.put("jam_period2", jam_period2)
      jamHead.put("yongdu_continue_tm", yongdu_continue_tm)
      jamHead.put("jam_exp_speed", speed_exp)

      jamHead.put("swid_len_exp", swid_len_exp)
      jamHead.put("disu_duration_exp", disu_duration_exp)
      jamHead.put("sum_swid_len_exp", sum_swid_len_exp)
      jamHead.put("jam_time_delta", jam_time_delta)
      jamHead.put("speed_siji", speed_siji)

      jamHead

    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("yongduCalRdd的数据量为：" + yongduCalRdd.count())
    yongduCalRdd
  }

  def diffSwid(swid: String) = {
    var new_swid: Array[String] = null
    try {
      val swid_arr = swid.split(",")
      new_swid = new Array[String](swid_arr.size)
      for (i <- 0 until swid_arr.size) {
        if (swid_arr(i) != "0") {
          if (i < 1) new_swid(i) = swid_arr(i)
          if (i >= 1 && swid_arr(i) != swid_arr(i - 1)) new_swid(i) = swid_arr(i)
        }
      }
    } catch {
      case e: Exception => e + ""
    }
    new_swid.filter(_ != null).mkString(",")
  }


  def getSwidLengthMap(jp_swid: String, jp_length: String): collection.mutable.Map[String, String] = {
    val swid_length_map = collection.mutable.Map[String, String]()
    if (StringUtils.nonEmpty(jp_swid) && StringUtils.nonEmpty(jp_length)) {
      val jp_swid_arr = jp_swid.split("\\|")
      val jp_length_arr = jp_length.split("\\|")
      for (i <- 0 until jp_swid_arr.size) {
        swid_length_map.put(jp_swid_arr(i), jp_length_arr(i))
      }
    }
    swid_length_map
  }

  def postJamRequest(yongdu_swid: String, yongdu_time2: String, jp_swid: String, jp_length: String, url: String): (String, String, String, String, String) = {
    val out_swid_exp_arr, out_speed_exp_arr, out_swid_len_exp_arr, out_disu_duration_exp, out_sum_swid_len_exp = new ListBuffer[String]()
    val task_swid_map = getSwidLengthMap(jp_swid, jp_length)

    if (StringUtils.nonEmpty(yongdu_swid)) {
      val yongdu_swid_arr = yongdu_swid.split(";")
      for (i <- 0 until (yongdu_swid_arr.length)) {
        val swid_exp_arr, speed_exp_arr, swid_len_exp_arr = new ListBuffer[String]()
        var disu_duration_exp, sum_swid_len_exp = 0.0
        val links = yongdu_swid_arr(i).replaceAll("\\|", ",")
        //去重后调接口
        val diff_links = diffSwid(links)
        val time = yongdu_time2.split("~")(0).replaceAll("\\s+", "T").replaceAll("-|:", "")
        val start_time = yongdu_time2.split("~")(0).split("\\s+")(1).replaceAll(":", "")
        // 生产
        val params = s"""{"ak": "dc894b4a3c7444b4a3505315d00b87ad","swId": 1,"links": "$diff_links","type": 1,"time": "$time","output": "json","gzip": "0","roadAttrToken": "6134FAA5B6B6ED55E87EA116466734ED"}""".stripMargin

        var jy_tracks: JSONArray = null
        try {
          val jam_str = SparkUtils.doPost(url, JSON.parseObject(params), logger)
          //          System.err.println(">>>>>>>>>>接口正常调用中>>>>>>>" + params)
          val jam_str_json = JSON.parseObject(jam_str)
          jy_tracks = jam_str_json.getJSONArray("linkCostArray")
        } catch {
          case e: Exception => ""
        }
        if (jy_tracks != null && jy_tracks.size() > 0) {
          for (i <- 0 until jy_tracks.size()) {
            val linkID = jy_tracks.getJSONObject(i).getString("linkID")
            swid_exp_arr += linkID
            //获取swid返回的长度
            val swid_len = task_swid_map.getOrElse(linkID, "")
            if (swid_len.trim != "") {
              swid_len_exp_arr += swid_len
            } else {
              swid_len_exp_arr += "0"
            }
            //低速速度拼接 km/h
            val costArray = jy_tracks.getJSONObject(i).getJSONArray("costArray")
            var diff = 235959
            var speed_exp_t = "0"
            if (costArray != null && costArray.size() > 0) {
              for (j <- 0 until costArray.size()) {
                val startTime = costArray.getJSONObject(j).getString("startTime")
                val speed = costArray.getJSONObject(j).getString("speed")
                val cur_diff = Math.abs(start_time.toDouble.toInt - startTime.toInt * 100) //start_time = 235523
                if (cur_diff <= diff) {
                  diff = cur_diff
                  speed_exp_t = speed
                }
              }
              val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
              disu_duration_exp += sd_tmp
              speed_exp_arr += speed_exp_t
            } else {
              val staticspeed = jy_tracks.getJSONObject(i).getString("staticSpeed")
              if (staticspeed != null) {
                speed_exp_t = staticspeed
                val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
                speed_exp_arr += staticspeed
                disu_duration_exp += sd_tmp
              } else {
                speed_exp_arr += "-"
              }
            }
          }
        }
        if (swid_len_exp_arr.size > 0) sum_swid_len_exp = swid_len_exp_arr.map(_.toDouble).sum
        if (swid_exp_arr.size == 0) swid_exp_arr += "-"
        if (speed_exp_arr.size == 0) speed_exp_arr += "-"
        if (swid_len_exp_arr.size == 0) swid_len_exp_arr += "-"
        out_swid_exp_arr += swid_exp_arr.mkString("|")
        out_speed_exp_arr += speed_exp_arr.mkString("|")
        out_swid_len_exp_arr += swid_len_exp_arr.mkString("|")
        out_disu_duration_exp += disu_duration_exp.formatted("%.2f")
        out_sum_swid_len_exp += sum_swid_len_exp.formatted("%.2f")
      }
    }
    (out_swid_exp_arr.mkString("|"), out_speed_exp_arr.mkString("|"), out_swid_len_exp_arr.mkString("|"), out_disu_duration_exp.mkString("|"), out_sum_swid_len_exp.mkString("|"))
  }


  /**
   * 节点计算结果
   *
   * @param pointRdd
   * @return
   */
  def calPointRdd(pointRdd: RDD[JSONObject]) = {
    val pointCalRdd = pointRdd.map(x => {
      val task_subid = JSONUtils.getJsonValue(x, "task_subid", "")
      val point_name = JSONUtils.getJsonValue(x, "point_name", "")
      ((task_subid, point_name), x)
    })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val (task_subid, point_name) = x._1
        val pointList = x._2.toList.sortBy(_.getString("jp_time"))

        val jp_coords = pointList.map(_.getString("jp_coords")).mkString("|")
        val jp_swid = pointList.map(_.getString("jp_swid")).mkString("|")
        val jp_time = pointList.map(_.getString("jp_time")).mkString("|")
        val jp_length = pointList.map(_.getString("jp_length")).mkString("|")

        val jpJson = new JSONObject()
        jpJson.put("jp_coords", jp_coords)
        jpJson.put("jp_swid", jp_swid)
        jpJson.put("jp_time", jp_time)
        jpJson.put("jp_length", jp_length)

        ((task_subid, point_name), jpJson)
      }).persist(StorageLevel.DISK_ONLY)

    pointCalRdd
  }

  def jamJoinPoint(yongduCalRdd: RDD[JSONObject], pointCalRdd: RDD[((String, String), JSONObject)]) = {

    val jamJoinPointRdd = yongduCalRdd.map(x => {
      val task_subid = JSONUtils.getJsonValue(x, "task_subid", "")
      val point_name = JSONUtils.getJsonValue(x, "point_name", "")
      ((task_subid, point_name), x)
    }).leftOuterJoin(pointCalRdd).map(x => {
      val (task_subid, point_name) = x._1
      val left = x._2._1
      val rightOpt = x._2._2.getOrElse(new JSONObject())

      left.fluentPutAll(rightOpt)
      left
    }).persist(StorageLevel.DISK_ONLY)

    jamJoinPointRdd

  }

  def calExpend(lineRdd: RDD[JSONObject], pairListBc: Broadcast[Array[(String, String)]], spark: SparkSession) = {
    // 将数据拓展为点，并计算相应的多边形交集
    import scala.util.Try
    val pointRdd0 = lineRdd.repartition(800).mapPartitions(iterator => {
      iterator.flatMap(x => {
        val expandedArray = new ArrayBuffer[JSONObject]()

        //todo 轨迹点 稀释操作
        var jp_coords_list = x.getString("jp_coords").split("\\|").toList.take(30000)
        val jp_swid_list = x.getString("jp_swid").split("\\|").toList.take(30000)
        val jp_time_list = x.getString("jp_time").split("\\|").toList.take(30000)
        val jp_dir_list = Try(x.getString("jp_dir").split("\\|").toList) getOrElse (new Array[String](jp_coords_list.length).toList)
        val jp_length_list = x.getString("jp_length").split("\\|").toList.take(30000)

        for (i <- 0 until jp_coords_list.length by 3) {
          val jp_coords = Try(jp_coords_list(i)) getOrElse ("-")
          val jp_swid = Try(jp_swid_list(i)) getOrElse ("-")
          val jp_time = Try(jp_time_list(i)) getOrElse ("-")
          val jp_dir = Try(jp_dir_list(i)) getOrElse ("-")
          val jp_length = Try(jp_length_list(i)) getOrElse ("-")
          val tempObj = new JSONObject()
          tempObj.fluentPutAll(x)
          tempObj.remove("yongdu_coords")
          tempObj.remove("yongdu_swid_gd")
          tempObj.remove("yongdu_swid_after")
          tempObj.remove("speed_gd")
          tempObj.remove("yongdu_stay_coords")
          tempObj.remove("yongdu_dir_after")
          tempObj.remove("sum_dist")
          tempObj.remove("status_gd")
          tempObj.remove("swid_gd")
          tempObj.remove("yongdu_speed_gd")
          tempObj.remove("event_content")
          tempObj.remove("duation_periods")

          tempObj.put("jp_coords", jp_coords)
          tempObj.put("jp_swid", jp_swid)
          tempObj.put("jp_time", jp_time)
          tempObj.put("jp_dir", jp_dir)
          tempObj.put("jp_length", jp_length)


          expandedArray += tempObj
        }

        expandedArray
      })
    }).persist(StorageLevel.MEMORY_AND_DISK)


    logger.error("pointRdd0的数据量为：" + pointRdd0.count())

    val pointRdd = pointRdd0
      .mapPartitionsWithIndex((index, iter) => {

        val pairList = pairListBc.value.toList

        val pairGeoList = pairList.map(pair => {
          val pair_name = pair._1
          val hull_coords = pair._2
          val geometry = ParseCoordinatesToGeometry.coordinatesToPolygon(hull_coords)
          (pair_name, geometry)
        })
        val geometryFactory = new GeometryFactory()

        iter.map(obj => {
          val jp_coords = JSONUtils.getJsonValue(obj, "jp_coords", "")

          val parts = jp_coords.split(",")
          val lat = parts(0).toDouble
          val lng = parts(1).toDouble
          val coordinate = new Coordinate(lat, lng)
          val geoPoint = geometryFactory.createPoint(coordinate)

          var found = false

          for (poly <- pairGeoList if !found) {
            val pairName = poly._1
            val pairPoly = poly._2
            if (pairPoly.contains(geoPoint)) {
              obj.put("node_name", pairName)
              found = true
            }
          }
          obj
        })
      })
      //      .filter(x => {
      //      val node_name = x.getString("node_name")
      //      StringUtils.nonEmpty(node_name) && node_name.contains("1251")
      //    })
      .persist(StorageLevel.DISK_ONLY)
    logger.error("pointRdd的数据量为：" + pointRdd.count())


    //    val groupRdd = pointRdd.map(x => {
    //      val node_name = x.getString("node_name")
    //      (node_name,x)
    //    }).groupByKey().map(x => {
    //      val node_name = x._1
    //      val list = x._2.toList
    //      val list_new = list.map(obj => {
    //        val jp_coords = JSONUtils.getJsonValue(obj, "jp_coords", "")
    //        jp_coords
    //      }).mkString("|")
    //      (node_name, list_new)
    //    })
    //    import spark.implicits._
    //
    //    groupRdd.repartition(1).toDF().write.mode(SaveMode.Overwrite).option("delimiter", "\t").csv("d:\\user\\01401062\\桌面\\20231129_0.csv")


    pointRdd
  }

  def nodeEdgeCal(pointRdd: RDD[JSONObject], spark: SparkSession) = {

    val pointRdd2 = pointRdd.zipWithIndex().map(x => {
      (x._2, x._1)
    })

    val pointRdd3 = pointRdd2.partitionBy(new RangePartitioner(400, pointRdd2)).map(_._2)

    //    // 增加node_name2\node_name3的计算
    //    val nodeEdgeRdd = pointRdd3.map(x => {
    //      val task_subid = JSONUtils.getJsonValue(x, "task_subid", "")
    //      (task_subid, x)
    //    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).flatMap(x => {
    //      val list = x._2.toList.sortBy(_.getString("jp_time"))
    //      list.zipWithIndex.map {case (obj, index) =>
    //        val node_name = obj.getString("node_name")
    //        var node_name2 = ""
    //        var node_name3 = ""
    //        if (StringUtils.isEmpty(node_name)) {
    //          // 如果当前元素的 node_name 字段为空，则向前找到第一个有值的 node_name，作为 node_name2
    //          val previousNodes = list.take(index).reverse
    //          val firstPreviousNode = previousNodes.find(obj => Option(obj.getString("node_name")).exists(_.nonEmpty))
    //
    //          // 获取第一个有值的 node_name，并设置为 node_name2
    //          node_name2 = firstPreviousNode.map(_.getString("node_name")).getOrElse("")
    //
    //          // 向后找到第一个有值的 node_name，作为 node_name3
    //          val nextNodes = list.drop(index + 1)
    //          val firstNextNode = nextNodes.find(obj => Option(obj.getString("node_name")).exists(_.nonEmpty))
    //
    //          // 获取第一个有值的 node_name，并设置为 node_name3
    //          node_name3 = firstNextNode.map(_.getString("node_name")).getOrElse("")
    //
    //          obj.put("node_name2", node_name2)
    //          obj.put("node_name3", node_name3)
    //
    //        } else {
    //          // 如果当前元素的 node_name 字段不为空，则直接复制给 node_name2，并将 node_name3 设置为 node_name
    //          obj.put("node_name2", node_name)
    //          obj.put("node_name3", node_name)
    //        }
    //
    //        if (StringUtils.nonEmpty(node_name)) {
    //          obj.put("point_type", "node")
    //          obj.put("point_name", node_name)
    //        } else if (StringUtils.nonEmpty(node_name2) && StringUtils.nonEmpty(node_name2)) {
    //          obj.put("point_type", "edge")
    //          obj.put("point_name", node_name2 + ">>" + node_name3)
    //        }
    //        obj
    //      }
    //    }).filter(x => StringUtils.nonEmpty(x.getString("point_type"))).persist(StorageLevel.DISK_ONLY)

    //    val nodeEdgeRddList = pointRdd3.map(x => {
    //      val task_subid = JSONUtils.getJsonValue(x, "task_subid", "")
    ////      val randomKey = Random.nextInt(10)  // 生成随机数作为新的key
    ////      val task_subid_random =task_subid + "_" + randomKey
    //      (task_subid, x)
    //    })
    //      .filter(x => {StringUtils.nonEmpty(x._1)})
    //      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
    //        .map(x => {
    //          (x._1,x._2.size)
    //        }).sortBy(_._2,false).take(10).foreach(println(_))


    // 增加node_name2\node_name3的计算
    val nodeEdgeRdd = pointRdd3.map(x => {
      val task_subid = JSONUtils.getJsonValue(x, "task_subid", "")
      (task_subid, x)
    })
      .filter(x => {
        StringUtils.nonEmpty(x._1)
      })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .mapPartitions(iter => {
        iter.flatMap { case (_, values) =>
          val sortedList = values.toList.sortBy(_.getString("jp_time"))
          //          val sortedList = list.sortBy(_.getString("jp_time"))
          sortedList.zipWithIndex.map { case (obj, index) =>
            val node_name = obj.getString("node_name")
            var node_name2 = ""
            var node_name3 = ""
            if (StringUtils.isEmpty(node_name)) {
              val previousNodes = sortedList.take(index).reverse
              val firstPreviousNode = previousNodes.find(obj => Option(obj.getString("node_name")).exists(_.nonEmpty))
              node_name2 = firstPreviousNode.map(_.getString("node_name")).getOrElse("")

              val nextNodes = sortedList.drop(index + 1)
              val firstNextNode = nextNodes.find(obj => Option(obj.getString("node_name")).exists(_.nonEmpty))
              node_name3 = firstNextNode.map(_.getString("node_name")).getOrElse("")

              obj.put("node_name2", node_name2)
              obj.put("node_name3", node_name3)
            } else {
              obj.put("node_name2", node_name)
              obj.put("node_name3", node_name)
            }

            if (StringUtils.nonEmpty(node_name)) {
              obj.put("point_type", "node")
              obj.put("point_name", node_name)
            } else if (StringUtils.nonEmpty(node_name2) && StringUtils.nonEmpty(node_name3)) {
              obj.put("point_type", "edge")
              obj.put("point_name", node_name2 + ">>" + node_name3)
            }
            obj
          }
        }
      }).filter(x => StringUtils.nonEmpty(x.getString("point_type"))).persist(StorageLevel.DISK_ONLY)

    logger.error("nodeEdgeRdd数据量为：" + nodeEdgeRdd.count())

    nodeEdgeRdd
  }

  def calPointNode(nodeEdgeRdd: RDD[JSONObject], spark: SparkSession) = {

    val pointNodeRdd = nodeEdgeRdd.map(x => {

      val yongdu_time2 = JSONUtils.getJsonValue(x, "yongdu_time2", "")

      val jp_time_stamp = JSONUtils.getJsonValueLong(x, "jp_time", 0L)
      val jp_time = LocalDateTime.parse(DateTimeUtil.timestampConvertDate(jp_time_stamp, "yyyy-MM-dd HH:mm:ss"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))

      val timeRanges = yongdu_time2.split(";")

      val event_final_uni_str = JSONUtils.getJsonValue(x, "yongdu_event_final_uni", "")
      val warn_final_uni_str = JSONUtils.getJsonValue(x, "yongdu_warn_final_uni", "")

      val event_final_uni = event_final_uni_str.split(";")
      val warn_final_uni = warn_final_uni_str.split(";")


      var indexInRange = -1

      // 检查给定时间是否在任何一个时间范围内
      timeRanges.zipWithIndex.foreach { case (range, index) =>
        val startEnd = range.split("_")
        val startTime = LocalDateTime.parse(startEnd(0), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        val endTime = LocalDateTime.parse(startEnd(1), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))

        if (jp_time.isAfter(startTime) && jp_time.isBefore(endTime)) {
          indexInRange = index
        }
      }

      if (indexInRange != -1) {
        x.put("jam_status", 1)
        x.put("jam_index", indexInRange)

        val event_final_uni_point = try {
          event_final_uni(indexInRange)
        } catch {
          case e: Exception => ""
        }
        val warn_final_uni_point = try {
          warn_final_uni(indexInRange)
        } catch {
          case e: Exception => ""
        }

        x.put("event_final_uni", event_final_uni_point)
        x.put("warn_final_uni", warn_final_uni_point)
      }
      x
    }).persist(StorageLevel.DISK_ONLY)

    //    val groupRdd = pointNodeRdd.map(x => {
    //      val node_name = x.getString("point_name")
    //      val point_type = x.getString("point_type")
    //      val jam_index = x.getString("jam_index")
    //
    //      ((node_name,point_type,jam_index),x)
    //    }).groupByKey().map(x => {
    //      val (node_name,point_type,jam_index) = x._1
    //      val list = x._2.toList
    //      val list_new = list.map(obj => {
    //        val jp_coords = JSONUtils.getJsonValue(obj, "jp_coords", "")
    //        jp_coords
    //      }).mkString("|")
    //      (node_name ,point_type,jam_index, list_new)
    //    })
    //    import spark.implicits._
    //
    //    groupRdd.repartition(1).toDF().write.mode(SaveMode.Overwrite).option("delimiter", "\t").csv("d:\\user\\01401062\\桌面\\20231129_2.csv")

    logger.error("pointNodeRdd的数据量为：" + pointNodeRdd.count())
    pointNodeRdd
  }

  def saveTable(spark: SparkSession, inc_day: String, jamJoinPointRdd: RDD[JSONObject], ak: Int) = {

    import spark.implicits._

    import scala.util.Try

    val jamRdd = jamJoinPointRdd.map(x => {
      val task_id = x.getString("task_id")
      val task_subid = x.getString("task_subid")
      val line_code = x.getString("line_code")
      val task_area_code = x.getString("task_area_code")
      val vehicle_serial = x.getString("vehicle_serial")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val start_outer_add_code = x.getString("start_outer_add_code")
      val end_outer_add_code = x.getString("end_outer_add_code")
      val carrier_name = x.getString("carrier_name")
      val actual_carrier_name = x.getString("actual_carrier_name")
      val plan_depart_tm = x.getString("plan_depart_tm")
      val actual_depart_tm = x.getString("actual_depart_tm")
      val plan_arrive_tm = x.getString("plan_arrive_tm")
      val actual_arrive_tm = x.getString("actual_arrive_tm")
      val line_time = x.getString("line_time")
      val actual_run_tm = x.getString("actual_run_tm")
      val line_distance = x.getString("line_distance")
      val start_point = x.getString("start_point")
      val end_point = x.getString("end_point")
      val transoport_level = x.getString("transoport_level")
      val id = task_subid + "_" + x.getString("jam_index")
      val point_type = x.getString("point_type")
      val point_name = x.getString("point_name")
      val jam_period = x.getString("jam_period")
      val event_final_uni = x.getString("event_final_uni")
      val warn_final_uni = x.getString("warn_final_uni")
      val jp_coords = x.getString("jp_coords")
      val jp_swid = x.getString("jp_swid")
      val jp_time = x.getString("jp_time")
      val jp_length = x.getString("jp_length")
      val jam_status = x.getString("jam_status")
      val jam_time = x.getString("jam_time")
      val jam_swid = x.getString("jam_swid")
      val jam_length = x.getString("jam_length")
      val jam_exp_speed = x.getString("jam_exp_speed")
      val jam_time_delta = x.getString("jam_time_delta")
      val jam_time_delta_list = jam_time_delta.split(";")
      var jam_time_delta_total = 0.0
      jam_time_delta_list.map(jam => {
        val jam_time = Try(jam.toDouble).getOrElse(0.0)
        jam_time_delta_total += jam_time
      })
      //      val jam_time_delta_total= x.getString("jam_time_delta_total")
      val jam_period2 = x.getString("jam_period2")
      val jam_coords = x.getString("jam_coords")
      val yongdu_continue_tm = x.getString("yongdu_continue_tm")

      val swid_len_exp = x.getString("swid_len_exp")
      val disu_duration_exp = x.getString("swid_len_exp")
      val sum_swid_len_exp = x.getString("sum_swid_len_exp")
      val speed_siji = x.getString("speed_siji")


      JamCalRes(task_id, task_subid, line_code, task_area_code, vehicle_serial, start_dept, end_dept,
        start_outer_add_code, end_outer_add_code, carrier_name, actual_carrier_name, plan_depart_tm, actual_depart_tm,
        plan_arrive_tm, actual_arrive_tm, line_time, actual_run_tm, line_distance, start_point, end_point,
        transoport_level, point_type, point_name, jam_period, event_final_uni, warn_final_uni,
        jp_coords, jp_swid, jp_time, jp_length, jam_status, jam_time, jam_swid, jam_length, jam_exp_speed, jam_time_delta, jam_time_delta_total.toString,
        jam_period2, jam_coords, yongdu_continue_tm, swid_len_exp, disu_duration_exp, sum_swid_len_exp, speed_siji)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("jamRdd的数据量为：" + jamRdd.count())
    jamRdd.toDF().withColumn("inc_day", lit(inc_day)).withColumn("ak", lit(ak)).repartition(5).write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_std_line_recall_realtime_congestion2_ak")


  }

  def groupNode(yongduCalRdd: RDD[JSONObject]) = {

    val nodeGroupRdd = yongduCalRdd.map(x => {
      val task_subid = JSONUtils.getJsonValue(x, "task_subid", "")
      val point_name = x.getString("point_name")
      ((task_subid, point_name), x)
    })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {

        val (task_subid, point_name) = x._1
        val list = x._2.toList
        val jamHead = list.head

        val jam_swid = list.map(_.getString("jam_swid")).mkString(";")
        val jam_length = list.map(_.getString("jam_length")).mkString(";")
        val jam_coords = list.map(_.getString("jam_coords")).mkString(";")
        val jam_time = list.map(_.getString("jam_time")).mkString(";")
        val jam_period = list.map(_.getString("jam_period")).mkString(";")
        val jam_period2 = list.map(_.getString("jam_period2")).mkString(";")
        val yongdu_continue_tm = list.map(_.getString("yongdu_continue_tm")).mkString(";")
        val jam_exp_speed = list.map(_.getString("jam_exp_speed")).mkString(";")
        val swid_len_exp = list.map(_.getString("swid_len_exp")).mkString(";")
        val disu_duration_exp = list.map(_.getString("disu_duration_exp")).mkString(";")
        val sum_swid_len_exp = list.map(_.getString("sum_swid_len_exp")).mkString(";")
        val jam_time_delta = list.map(_.getString("jam_time_delta")).mkString(";")
        val speed_siji = list.map(_.getString("speed_siji")).mkString(";")

        val jam_time_delta_total = list.map(obj => {
          val disu_duration_exp_str = JSONUtils.getJsonValue(obj, "disu_duration_exp", "")
          val disu_duration_exp = disu_duration_exp_str.split("|")
          var disu_duration_exp_sum = 0
          for (i <- disu_duration_exp) {
            val tmp = try {
              i.asInstanceOf[Int]
            } catch {
              case e: Exception => 0
            }
            disu_duration_exp_sum += tmp
          }
          disu_duration_exp_sum
        }).sum

        jamHead.put("jam_swid", jam_swid)
        jamHead.put("jam_length", jam_length)
        jamHead.put("jam_coords", jam_coords)
        jamHead.put("jam_time", jam_time)
        jamHead.put("jam_period", jam_period)
        jamHead.put("jam_period2", jam_period2)
        jamHead.put("yongdu_continue_tm", yongdu_continue_tm)
        jamHead.put("jam_exp_speed", jam_exp_speed)

        jamHead.put("swid_len_exp", swid_len_exp)
        jamHead.put("disu_duration_exp", disu_duration_exp)
        jamHead.put("sum_swid_len_exp", sum_swid_len_exp)
        jamHead.put("jam_time_delta", jam_time_delta)
        jamHead.put("speed_siji", speed_siji)
        jamHead.put("jam_time_delta_total", jam_time_delta_total)

        jamHead
      }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("nodeGroupRdd的数据量为：" + nodeGroupRdd.count())

    nodeGroupRdd

  }

  def calCongestion(spark: SparkSession, lineRdd: RDD[JSONObject], pairNodeRdd: RDD[JSONObject]) = {

    val pairList = pairNodeRdd.map(x => {
      val pair_name = x.getString("pair_name")
      val hull_coords = x.getString("hull_coords")
      (pair_name, hull_coords)
    }).collect()


    val pairListBc = spark.sparkContext.broadcast(pairList)

    // 拓展并计算多边形关系
    val pointRdd = calExpend(lineRdd, pairListBc, spark)

    val nodeEdgeRdd = nodeEdgeCal(pointRdd, spark)

    val pointNodeRdd = calPointNode(nodeEdgeRdd, spark)

    // TODO: 拥堵段的计算结果
    val jamInputRdd = pointNodeRdd.map(x => {
      val task_subid = JSONUtils.getJsonValue(x, "task_subid", "")
      val jam_index = JSONUtils.getJsonValueInt(x, "jam_index", -1)
      val point_name = x.getString("point_name")
      ((task_subid, jam_index.toInt, point_name), x)
    }).filter(_._1._2 != -1).groupByKey()
    //    val groupRdd = jamInputRdd.map(x => {
    //      val (task_subid,jam_index,point_name) = x._1
    //      val list = x._2.toList
    //      val list_new = list.map(obj => {
    //        val jp_coords = JSONUtils.getJsonValue(obj, "jp_coords", "")
    //        jp_coords
    //      }).mkString("|")
    //      (task_subid,jam_index,point_name, list_new)
    //    })
    //    import spark.implicits._
    //
    //    groupRdd.repartition(1).toDF().write.mode(SaveMode.Overwrite).option("delimiter", "\t").csv("d:\\user\\01401062\\桌面\\20231129_3.csv")

    // TODO: 拥堵段维度
    val yongduCalRdd = scheduleYongdu(jamInputRdd)

    // TODO: 不同拥堵段汇总为节点维度
    val nodeGroupRdd = groupNode(yongduCalRdd)

    // TODO: 节点上的计算结果
    val pointCalRdd = calPointRdd(pointNodeRdd)

    // TODO: 拥堵上的计算结果关联上节点的结果
    val jamJoinPointRdd = jamJoinPoint(nodeGroupRdd, pointCalRdd)

    jamJoinPointRdd

  }

  def processCal(spark: SparkSession, inc_day: String, ak: Int) = {

    val lineRdd = getLineData(spark, inc_day, ak)
    val pairNodeRdd = getSorcePair(spark, inc_day)

    val resRdd = calCongestion(spark, lineRdd, pairNodeRdd)

    saveTable(spark, inc_day, resRdd, ak)

    logger.error("写入表" + inc_day + "ak:" + ak + "成功")
    SparkUtils.clearCache(spark)
    spark.sqlContext.clearCache()

    val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
    ds.foreach(x => {
      x._2.unpersist()
    })


  }

  def start(inc_day: String, akInput: Int): Unit = {

    //    val spark = SparkUtils.getSparkSession(appName, "local[*]")

    val spark = SparkUtils.getSparkSession(appName, "yarn")
    spark.sparkContext.setLogLevel("ERROR")

    val akList = if (akInput != 0) range(akInput, 30) else range(0, 30)

    for (ak <- akList) {

      logger.error("当前ak为：" + ak)
      processCal(spark, inc_day, ak)
      logger.error("ak：" + ak + "计算完成")

    }

  }


  def main(args: Array[String]): Unit = {

    val inc_day = args(0)

    val akInput = Try(args(1).toInt) getOrElse (0)

    start(inc_day, akInput)

    logger.error("统计完成")

  }


}
