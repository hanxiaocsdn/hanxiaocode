package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import app.route.OilStationRecommendDetail.{getDistance, rad}
import com.alibaba.fastjson.{JSON, JSONObject}
import com.github.davidmoten.rtree.RTree
import com.github.davidmoten.rtree.geometry.{Geometries, Point}
import com.sf.gis.scala.base.util.DistanceTool
import org.apache.spark.sql.{DataFrame, Row, SparkSession, functions}
import org.apache.spark.sql.functions.{substring, _}
import common.DataSourceCommon
import utils.{SparkUtil, SparkUtils, StringUtils}

import java.util
import scala.collection.mutable.{ArrayBuffer, ListBuffer}


/**
 * GIS-RSS-ETA：【燃油管控】 第四步：判断是否按推荐行驶，计算实际加油点油价_V1.0
 * 需求方：zuojiayi（01403789）
 *
 * @author guofangcai（01420395）
 * 任务ID： 970133
 * 任务名称：判断是否按推荐行驶，计算实际加油点油价
 */
object ImplementRecommendedStations extends DataSourceCommon {
  val className: String = this.getClass.getSimpleName.replace("$", "")

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  var url  = "http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf"

  def main(args: Array[String]): Unit = {
    val spark =  SparkUtil.getSparkSession(appName)
    val inc_day  = args(0)
    start(spark, inc_day)
    spark.stop()
  }


  def start(sparkSession:SparkSession, inc_day: String )={

    import  sparkSession.implicits._

    val sourceDF = baseSourceDF(sparkSession,inc_day)

    //获取油站库信息

    val  oil_config_station_sql  =
      s"""
         |
         |select
         |  distinct city_adcode city_adcode,
         |  display_pos,
         |  name_chn,
         |  address,
         |  check_src src_mark,
         |  check_POIID
         |from
         |  dm_gis.oil_config_station
         |where
         |  inc_day = ${inc_day}
         |
         |""".stripMargin

    logger.error("oil_config_station " + oil_config_station_sql)

    val oil_config_station_df = sparkSession.sql(oil_config_station_sql).withColumn("adcode_4",'city_adcode)

    logger.error("oil_config_station 数据量 " + oil_config_station_df.count())

    //通过停留点调用接口获取对应的城市编码信息
    val stayPointDF = sourceDF.filter('stay_point  isNotNull ).select('Stay_point).distinct()

    logger.error("通过停留点调用接口获取对应的城市编码信息数据量 " + stayPointDF.count())

    stayPointDF.show(100,false)
    //数据格式(stay_point,Adcode,Swid)
    val stayPointRequeseDF = stayPointDF.flatMap(row  =>  {
      val stayPoint = row.getAs[String]("Stay_point")
      val stayPoints = stayPoint.replaceAll(" ","")
        .replaceAll("], \\[","|").replaceAll("\\[","")
        .replaceAll("]","").split("\\|")
      val rowList = new ArrayBuffer[(String,String, String, String)]()
      //points 调用接口获取对应的数据 遍历停留点调用接口
      for(point <- stayPoints){
        rowList.append(pointResponse(stayPoint,point))
      }
      logger.error("解析数据 " + rowList.toSeq)
      rowList.toSeq
    }).flatMap(row=>{
      //对adcodes 进行拆分
      val stay_point_src = row._1
      val stay_point  = row._2
      val adcodes  = row._3
      val swid  = row._4

      val adcodesplitArray  = new ArrayBuffer[(String,String , String ,String)]()
      val adcodeSlipts  = adcodes.split("\\|")
      val swids  = swid.split("\\|")
      for(i <- 0.until(adcodeSlipts.size)){
        adcodesplitArray.append((stay_point_src,stay_point, adcodeSlipts(i), swids(i)))
      }
      adcodesplitArray.toSeq
    }).toDF("stay_point_src","stay_point","adcode", "swids")
      .withColumn("adcode_4",substring('adcode,0,4))


    stayPointRequeseDF.show(100,false)
    logger.error("接口返回数据量 " + stayPointRequeseDF.count())
    //关联数据
    val stayPointJoinDf  =  stayPointRequeseDF.join(oil_config_station_df,Seq("adcode_4"),"left")


    //通过stayPoint进行分组遍历对应的油站库获取最小距离油站库信息
    val stationPointDF  =  stayPointJoinDf.map(row =>{
      val stay_point_src = row.getAs[String]("stay_point_src")
      val stayPoint = row.getAs[String]("stay_point")
      val adcode = row.getAs[String]("adcode")
      val adcode_4 = row.getAs[String]("adcode_4")
      val display_pos = row.getAs[String]("display_pos")
      val name_chn = row.getAs[String]("name_chn")
      val address = row.getAs[String]("address")
      val check_POIID = row.getAs[String]("check_POIID")
      val src_mark = row.getAs[String]("src_mark")
      (stayPoint,(stay_point_src,stayPoint,display_pos,name_chn,address,check_POIID,src_mark,0.0))
    }).rdd.reduceByKey((x,y)=>{
      //比对停留点和站点之间的距离 取最小的那个
      val  stay_point_src = x._1
      val stayPoint_x  = x._2
      val display_pos_x = x._3
      val length_x = line_distance(stayPoint_x,display_pos_x)
      val stayPoint_y  = y._2
      val display_pos_y = y._3
      val length_y = line_distance(stayPoint_y,display_pos_y)

      val  name_chn_x  = x._4
      val  name_chn_y  = y._4
      val  address_x  = x._5
      val  address_y  = y._5
      val  check_POIID_x  = x._6
      val  check_POIID_y  = y._6
      val  src_mark_x  = x._7
      val  src_mark_y  = y._7

      if(length_x<length_y){
        (stay_point_src,stayPoint_x,display_pos_x,name_chn_x,address_x,check_POIID_x,src_mark_x,length_x)
      }else{
        (stay_point_src,stayPoint_y,display_pos_y,name_chn_y,address_y,check_POIID_y,src_mark_y,length_y)
      }
    }).map(row=>{
      row._2
    }).toDF("stay_point_src","stay_point","if_exit_pos_info","oil_name_min","oil_address_min","oil_poid_min","oil_station_src_min","if_exit_dist")
      .withColumn("std_dist",when('oil_name_min like("%服务区%"),"100").otherwise("80"))
      .withColumn("if_exit",when('if_exit_dist<='std_dist,"是").otherwise("否"))
      .drop("stay_point")

    stationPointDF.show(100, false)


    //推荐加油点位循环遍历油站库
    val oilPointDf  = sourceDF.filter('Oil_point.isNotNull).select('Oil_point,'stay_point).distinct()
    //推荐加油点位循环遍历油站库
    val recomdDf  = oilPointDf.map(row  => {
      val oidPoint = row.getAs[String]("Oil_point")
      val stayPoint = row.getAs[String]("stay_point")

      //todo 对stay_point循环处理
      val length = line_distance(oidPoint, stayPoint)
      var if_recomd  = ""
      if(length<=150){
        if_recomd = "是"
      }else{
        if_recomd = "否"
      }
      (oidPoint,if_recomd,length)
    }).toDF("Oil_point","if_recomd","if_recomd_dist")


    recomdDf.show(100,false)

    //Oil_point 和display_pos依次计算直线距离全量关联油站数据空间索引计算距离 todo
    val oilPointDf1  = sourceDF.filter('Oil_point isNotNull).select('Oil_point).distinct()
    //数据量会发散
    val oil_config = oil_config_station_df.map(row  => {
      val display_pos = row.getAs[String]("display_pos")
      val display_poss  = display_pos.split(",")
      val oil_name_recomd  = row.getAs[String]("name_chn")
      val oil_address_recomd  = row.getAs[String]("address")
      val oil_station_src_recomd  = row.getAs[String]("src_mark")
      val oil_poid_recomd  = row.getAs[String]("check_POIID")

      val key  = oil_name_recomd +"_" + oil_address_recomd +"_" + oil_station_src_recomd +"_" + oil_poid_recomd
      (key,display_poss(0).toDouble,display_pos(1).toDouble)
    }).collect()

    val oil_configList  = sparkSession.sparkContext.broadcast(oil_config)


    val  oilDF = SparkUtils.getRowToJson(oilPointDf1).mapPartitionsWithIndex((inx, iters)  => {

      // 将加油站建立为rtree
      val tuplesList = oil_configList.value.toList
      var tree:RTree[String,Point] = RTree.star().maxChildren(6).create()
      tuplesList.map(obj => {
        val point_name =obj._1
        val x_coord =obj._2
        val y_coord =obj._3
        tree = tree.add(point_name, Geometries.point(x_coord, y_coord))
      })

      iters.map(x  =>  {
        val tl_stay_points = x.getString("Oil_point")
        val stay_point_x = try {tl_stay_points.split(",")(0).toDouble} catch {case e:Exception =>  0.0}
        val stay_point_y = try {tl_stay_points.split(",")(1).toDouble} catch {case e:Exception =>  0.0}
        var if_jyz = ""
        try {
          val points = tree.nearest(Geometries.point(stay_point_x, stay_point_y), 150, 1).toList().toBlocking().single().get(0)
          val jyz_x_1 = points.geometry().x()
          val jyz_y_1 = points.geometry().y()
          val key  = points.value()
          logger.error("points " + key)

          val keys  = key.split("_")

          val dist = DistanceTool.getGreatCircleDistance(stay_point_x, stay_point_y, jyz_x_1, jyz_y_1)
          if_jyz = if (dist < 150) "是" else "否"

//          if (dist < 150) { todo 先看一下数据是否正确
            x.put("if_exit_pos_info_recomd", jyz_x_1.toString + "," + jyz_y_1.toString)
            x.put("oil_name_recomd", keys(0))
            x.put("oil_address_recomd", keys(1))
            x.put("oil_station_src_recomd", keys(2))
            x.put("oil_poid_recomd", key(3))
             x.put("oil_dist_recomd", dist)
//          }

        }catch {
          case e:Exception => e.printStackTrace()
        }
        x.put("if_exit_dist_recomd", if_jyz)
        x
      })

    }).map(row => {
      val Oil_point = row.getString("Oil_point")
      val if_exit_pos_info_recomd = row.getString("if_exit_pos_info_recomd")
      val if_exit_dist_recomd = row.getString("if_exit_dist_recomd")
      val oil_name_recomd  = row.getString("oil_name_recomd")
      val oil_address_recomd  = row.getString("oil_address_recomd")
      val oil_station_src_recomd  = row.getString("oil_station_src_recomd")
      val oil_poid_recomd  = row.getString("oil_poid_recomd")
      val oil_dist_recomd  = row.getString("oil_dist_recomd")

      (Oil_point,if_exit_pos_info_recomd, oil_name_recomd, oil_address_recomd, oil_station_src_recomd,oil_poid_recomd,if_exit_dist_recomd,oil_dist_recomd)
    }).toDF("Oil_point","if_exit_pos_info_recomd","oil_name_recomd","oil_address_recomd","oil_station_src_recomd","oil_poid_recomd","if_exit_dist_recomd","oil_dist_recomd")
     //todo  oil_dist_recomd 表中么有对应的字段, 需求文档字段名称重复
    oilDF.show(100,false)

    //1.1.1.5.获取推荐油站到请求点的数据信息
    val planPointDf  = sourceDF.filter(row  =>{
      val  plan_tracks = row.getAs[String]("plan_tracks")
      !StringUtils.isEmpty(plan_tracks)
    } ).select('plan_tracks,'oil_point).distinct()

    val planPointDF1 =  planPointDf.map(row=>{
      val planTrack = row.getAs[String]("plan_tracks")
      val planTracks =planTrack.split(";")
      val oilPoint  =  row.getAs[String]("oil_point")

      logger.error("数据: " + planTracks.mkString(",").toString)

      //计算距离
      var minIndex = 0
      var minLength = Double.MaxValue
      var minTrack = ""
      for(track <- planTracks){
        logger.error("数1据: " + track)
        val length = line_distance(track, oilPoint)
        if(minLength>=length){
          minIndex = planTracks.indexOf(track)
          minLength =length
          minTrack = track
        }
      }
      logger.error("数1据: " + planTracks.size + "  " + minIndex + "  " + minLength)
      //获取距离最小的点到末尾的数据
      val tracks = new ArrayBuffer[String]()
      for (i <- minIndex.until(planTracks.size)){
        tracks.append(planTracks(i))
      }
      // coords，min_pos, dist_min
      if(minLength<1000){
        (planTrack,tracks.mkString("|"),minTrack,minLength.toString)
      }else{
        (planTrack,"","","")
      }
    }).toDF("plan_tracks","coords","min_pos","dist_min")
      .withColumn("com_info",when('dist_min isNotNull, concat('min_pos,lit("_"),'dist_min)).otherwise(""))

    planPointDF1.show(100,false)

    val planPointDF2 = planPointDF1.filter('com_info isNotNull).map(row =>{
      val coords = row.getAs[String]("coords")
      val coordsList = coords.split("\\|")

      val distances  = new ArrayBuffer[String]()
      val durations  = new ArrayBuffer[String]()
      //http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf 通过轨迹点获取对应的路径信息
      for(coord <-  coordsList){
        val postJson   = new JSONObject()
        postJson.put("No",0)
        postJson.put("opt","sf4")
        postJson.put("test",1)
        postJson.put("stype",0)
        postJson.put("mode",2)
        postJson.put("etype",0)
        postJson.put("Passport","100000")
        postJson.put("Speed","1")
        postJson.put("Date","")
        postJson.put("simple_distance","0")
        postJson.put("useEstimateTime","1")
        postJson.put("ak","8bb09e5e110845f39a000391668e3e80")
        postJson.put("Points",coord)

        // 地址获取省市信息
        //    val response = SparkUtils.doPost(url,postJson,logger,ak)
        logger.error("请求数据1:" + postJson )
        val response =SparkUtils.doPost(url,postJson,logger,"8bb09e5e110845f39a000391668e3e80")
        // 地址获取省市信息
        logger.error("返回数据1:" + response )
        val responseJSON = try {JSON.parseObject(response)} catch {case e:Exception => new JSONObject()}

        //解析数据
        if(responseJSON !=null  && responseJSON.getJSONObject("route") !=null ){

          val paths =  responseJSON.getJSONObject("route").getJSONArray("paths")
          for (i <- 0.until(paths.size())){
            val distance = paths.getJSONObject(i).getString("distance")
            val Duration = paths.getJSONObject(i).getString("duration")
            distances.append(distance)
            durations.append(Duration)
          }
        }
      }

      val Plan_tracks = row.getAs[String]("plan_tracks")
      val min_pos = row.getAs[String]("min_pos")
      val dist_min = row.getAs[String]("dist_min")
      val com_info = row.getAs[String]("com_info")

      (Plan_tracks,coords,min_pos,dist_min,com_info,distances.mkString(","),durations.mkString(","))
    }).toDF("plan_tracks","coords","min_pos","dist_min","com_info","distance","duration")

    planPointDF2.show(1000,false)

    //拼接数据
    val resultDF1=  sourceDF.join(stationPointDF,sourceDF("stay_point")===stationPointDF("stay_point_src"),"left")
      .join(recomdDf,Seq("oil_point"),"left")
      .join(oilDF,Seq("oil_point"),"left") //todo
      .join(planPointDF2,Seq("plan_tracks"),"left")
      .withColumn("if_recomd",when('if_recom_oil ==="未请求",lit("")).otherwise('if_recomd))
      .withColumn("if_recomd_dist",when('if_recom_oil ==="未请求",lit("")).otherwise('if_recomd_dist))
      .withColumn("if_exit_dist_recomd",when('if_recom_oil ==="未请求",lit("")).otherwise('if_exit_dist_recomd))
      .withColumn("if_exit_pos_info_recomd",when('if_recom_oil ==="未请求",lit("")).otherwise('if_exit_pos_info_recomd))
      .withColumn("oil_name_recomd",when('if_recom_oil ==="未请求",lit("")).otherwise('oil_name_recomd))
      .withColumn("oil_address_recomd",when('if_recom_oil ==="未请求",lit("")).otherwise('oil_address_recomd))
      .withColumn("oil_station_src_recomd",when('if_recom_oil ==="未请求",lit("")).otherwise('oil_station_src_recomd))
      .select('task_id
        ,'navi_id
        ,'app_ver
        ,'src_deptcode
        ,'dest_deptcode
        ,'driver_id
        ,'vehicle
        ,'if_req
        ,'if_recom_oil
        ,'req_time
        ,'fuel_no
        ,'poi_id
        ,'oil_point
        ,'oil_price
        ,'oil_name
        ,'oil_brand
        ,'fuel_left_distance
        ,'is_fuel_point
        ,'plan_tracks
        ,'request_id
        ,'req_app_ver
        ,'search_type
        ,'type_poi_oil
        ,'add_oil
        ,'std_id_list
        ,'std_line_recommend
        ,'req_driver_id
        ,'line_code
        ,'fuel_scene
        ,'recommened_refuel_size
        ,'start_fuel_size
        ,'start_fuel_size_arti
        ,'task_classification
        ,'station_tag
        ,'station_type
        ,'is_showed
        ,'fuel_qty
        ,'fuel_prices
        ,'start_miles
        ,'end_miles
        ,'miles
        ,'addfuel_miles
        ,'is_add_oil
        ,'data_source
        ,'total_amount
        ,'addfuel_tm
        ,'start_tm
        ,'end_tm
        ,'drive_members
        ,'start_place
        ,'end_place
        ,'task_type
        ,'addoil_behavior
        ,'actual_if_better
        ,'stay_source
        ,'stay_time
        ,'stay_duration
        ,'stay_point
        ,'stay_roadname
        ,'nornal_stay
        ,'osstempurl
        ,'req_traveled_dist
        ,'req_traveled_coords
        ,'return_start
        ,'if_recomd
        ,'if_recomd_dist
        ,'if_exit_dist_recomd
        ,'if_exit_pos_info_recomd
        ,'oil_name_recomd
        ,'oil_address_recomd
        ,'oil_station_src_recomd
        ,'oil_poid_recomd
        ,'oil_dist_recomd
        ,'if_exit
        ,'if_exit_dist
        ,'if_exit_pos_info
        ,'oil_name_min
        ,'oil_address_min
        ,'oil_station_src_min
        ,'oil_poid_min
        ,'distance
        ,'Duration
        ,'com_info
      )


    //推荐油站折后价格
    val gassStationPriceDf =   gassStationPrice(sparkSession, inc_day, sourceDF)
    //计算实际加油点油价
    val resultDF2 = resultDF1.join(gassStationPriceDf,Seq("Oil_point"),"left")
      .withColumn("Task_inc_day",split('start_tm," ")(0))
    //计算实际加油点油价
    val result5 = gassPrice(sparkSession,inc_day,resultDF2)

    result5.show(1,false)

    val result6 =result5.select('task_id
      ,'navi_id
      ,'app_ver
      ,'src_deptcode
      ,'dest_deptcode
      ,'driver_id
      ,'vehicle
      ,'if_req
      ,'if_recom_oil
      ,'req_time
      ,'fuel_no
      ,'poi_id
      ,'oil_point
      ,'oil_price
      ,'oil_name
      ,'oil_brand
      ,'fuel_left_distance
      ,'is_fuel_point
      ,'plan_tracks
      ,'request_id
      ,'req_app_ver
      ,'search_type
      ,'type_poi_oil
      ,'add_oil
      ,'std_id_list
      ,'std_line_recommend
      ,'req_driver_id
      ,'line_code
      ,'fuel_scene
      ,'recommened_refuel_size
      ,'start_fuel_size
      ,'start_fuel_size_arti
      ,'task_classification
      ,'station_tag
      ,'station_type
      ,'is_showed
      ,'fuel_qty
      ,'fuel_prices
      ,'start_miles
      ,'end_miles
      ,'miles
      ,'addfuel_miles
      ,'is_add_oil
      ,'data_source
      ,'total_amount
      ,'addfuel_tm
      ,'start_tm
      ,'end_tm
      ,'drive_members
      ,'start_place
      ,'end_place
      ,'task_type
      ,'addoil_behavior
      ,'actual_if_better
      ,'stay_source
      ,'stay_time
      ,'stay_duration
      ,'stay_point
      ,'stay_roadname
      ,'nornal_stay
      ,'osstempurl
      ,'req_traveled_dist
      ,'req_traveled_coords
      ,'return_start
      ,'if_recomd
      ,'if_recomd_dist
      ,'if_exit_dist_recomd
      ,'if_exit_pos_info_recomd
      ,'oil_name_recomd
      ,'oil_address_recomd
      ,'oil_station_src_recomd
      ,'oil_poid_recomd
      ,'oil_dist_recomd
      ,'if_exit
      ,'if_exit_dist
      ,'if_exit_pos_info
      ,'oil_name_min
      ,'oil_address_min
      ,'oil_station_src_min
      ,'oil_poid_min
      ,'distance
      ,'Duration
      ,'com_info
      ,'discount_oil_price
      ,'driver_queryBrand
      ,'driver_his_oil_price
      ,'driver_discount_oil_price
      ,'price_mark
      ,'Task_inc_day
    ).distinct().withColumn("inc_day",lit(inc_day))

    writeToHive(sparkSession, result6, Seq("inc_day"), "dm_gis.dm_eta_basic_data_step3_di_jy")

  }


  def gassStationPrice (sparkSession: SparkSession , inc_day:String, sourceDF:DataFrame)={

    import sparkSession.implicits._
    val oilPointPriceDF  = sourceDF.map(row => {
      val oil_brand = row.getAs[String]("oil_brand")
      val oil_point = row.getAs[String]("oil_point")
      var com_brand  =""
      if(!StringUtils.isEmpty(oil_brand)){
        if(oil_brand =="中石油"){
          com_brand ="中国石油"
        }else if(oil_brand =="中石化"){
          com_brand ="中国石化"
        }else if(oil_brand.toFloat.toInt==1){
          com_brand ="中国石油"
        }else if(oil_brand.toFloat.toInt==2){
          com_brand ="中国石化"
        }else{
          com_brand ="未知品牌"
        }
      }
      (oil_point,com_brand)
    }).filter(row =>  {
      val com_brand = row._2
      !"未知品牌".equalsIgnoreCase(com_brand)
    }).map(row => {
      //      Oil_point 调qmpoint 获取 adcode 和 swid
      val  oil_point = row._1
      val  response =  pointResponse(oil_point,oil_point)

      (row._1,row._2,response._3,response._4) //Oil_point, com_brand , adcode  , swids
    }).flatMap(row =>  {
      val adcode  = row._3
      val rows  = new ArrayBuffer[(String,String,String,String,String)]()
      if(!StringUtils.isEmpty(adcode)){
        val adcodes = adcode.split("\\|")
        for(i <- 0.until(adcodes.size)){
          rows.append((row._1,row._2,adcodes(i),row._4, adcodes(i)))
        }
      }
      rows.toSeq
    }).toDF("oil_point","com_brand","adcode","swids","adcode_4")
      .withColumn("adcode_2", concat('adcode.substr(lit(0),length('adcode)-2),lit("00")))
    //转换成df
    import sparkSession.implicits._

    oilPointPriceDF.show(1,false)
    val  oilPointPriceDF1=  oilPointPriceDF.withColumn("adcode_4", 'adcode_4.substr(0,4))

    oilPointPriceDF1.show(1)
    //关联城市数据
    val citySql  = """select  adcode,cityName from dm_gis.dwd_city_adcode_map """

    import sparkSession.implicits._
    val cityDF = sparkSession.sql(citySql)
    val cityDF2 = cityDF.select('adcode.as("adcode_2"),'cityName.as("cityName_2"))

    val cityDF4 = cityDF.select('adcode.as("adcode_4"),'cityName.as("cityName_4"))

    val resultDF1 = oilPointPriceDF1
      .join(cityDF4,Seq("adcode_4"),"left")
      .join(cityDF2,Seq("adcode_2"),"left")
      .withColumn("name",when('cityName_4.isNotNull, 'cityName_4)
        .when('cityName_4.isNull &&  'cityName_2.isNotNull,'cityName_2).otherwise(lit("")))
      .withColumn("cityname",when('name.isin("金华市","台州市","温州市","宁波市","湖州市","丽水市","舟山市","嘉兴市","绍兴市","衢州市") && 'com_brand === "中国石化",lit("浙江省")).otherwise('name))


    val oil_price_sql  =
      s"""select cityname,city_mark,brand,preferential_price_0 from dm_gis.oil_price_data
         |where inc_day='${inc_day}' and  cityName  not in ('上海市','北京市','香港市','重庆市','天津市')  and city_mark=1""".stripMargin  //todo    cityName  not in ('上海市','北京市','香港市','重庆市','天津市') and

    val oil_price_df =  sparkSession.sql(oil_price_sql).withColumn("com_brand",'brand)


    val result =  resultDF1.join(oil_price_df,Seq("cityname","com_brand"),"left")
      .withColumn("discount_oil_price",'preferential_price_0)
      .select('oil_point,'discount_oil_price)

    result

  }


  /**
   * 实际加油价格
   * @param sparkSession
   * @param inc_day
   * @param sourceDF
   * @return
   */
  def gassPrice (sparkSession: SparkSession , inc_day:String, sourceDF:DataFrame)={

    import sparkSession.implicits._
    val oil_config_station_sql= s"""select
                                   |  display_pos,
                                   |  queryBrand,
                                   |  priceActivity,
                                   |  Key_value2,
                                   |  Brand_name
                                   |from
                                   |  dm_gis.oil_config_station
                                   |where
                                   |  inc_day = ${inc_day}""".stripMargin
    val oil_config_station_df =   sparkSession.sql(oil_config_station_sql)


    val oil_price_sql  =
      s"""select min_date
          ,max_date
          ,Key
          ,Preferential_price_0
          ,Official_price_0
          ,Vehicle_jiancheng
         | from dm_gis.oil_price_data
         |where inc_day='${inc_day}' """.stripMargin
    val oil_price_df =  sparkSession.sql(oil_price_sql)

    val  displayDf = oil_config_station_df.join(oil_price_df,oil_price_df("Key")===oil_config_station_df("Key_value2"),"left")
      .select('display_pos,'queryBrand,'priceActivity,'Brand_name,'min_date,'max_date,'Preferential_price_0,'Official_price_0,'Vehicle_jiancheng)

    displayDf.show(1, false )

    val resultDF =  sourceDF.withColumn("display_pos",'if_exit_pos_info) //todo 确认 提取司机实际加油油站坐标if_exit_pos_info.split('_')[1].split(':')[1] 逻辑
      .join(displayDf,Seq("display_pos"),"left")
      .withColumn("driver_queryBrand" ,when('task_inc_day<='max_date && 'task_inc_day>='min_date && ('min_date.isNotNull),'queryBrand))
      .withColumn("driver_his_oil_price" ,when(('task_inc_day<='max_date && 'task_inc_day>='min_date && ('min_date.isNotNull))
        && (substring('Vehicle,0,1)==='Vehicle_jiancheng  || 'Brand_name ==="中国石油"),lit("优惠价格")).otherwise(lit("发改委价格")))

      .withColumn("driver_discount_oil_price" ,when(('task_inc_day<='max_date && 'task_inc_day>='min_date && ('min_date.isNotNull))
        && (substring('Vehicle,0,1)==='Vehicle_jiancheng  || 'Brand_name ==="中国石油"),'Preferential_price_0).otherwise('Official_price_0))

      .withColumn("price_mark" ,when('task_inc_day<='max_date && 'task_inc_day>='min_date && ('min_date.isNotNull),'queryBrand))

    resultDF.show(1 , false)

    resultDF
  }

  /**
   * 获取对应的原始数据
   * @param sparkSession
   * @param inc_day
   */
  def baseSourceDF(sparkSession: SparkSession, inc_day : String ) = {

    //获取油站点信息

    val pointSql =
      s"""
         | Select task_id
         |,navi_id
         |,app_ver
         |,src_deptcode
         |,dest_deptcode
         |,driver_id
         |,vehicle
         |,if_req
         |,if_recom_oil
         |,req_time
         |,fuel_no
         |,poi_id
         |,oil_point
         |,oil_price
         |,oil_name
         |,oil_brand
         |,fuel_left_distance
         |,is_fuel_point
         |,plan_tracks
         |,request_id
         |,req_app_ver
         |,search_type
         |,type_poi_oil
         |,add_oil
         |,std_id_list
         |,std_line_recommend
         |,req_driver_id
         |,line_code
         |,fuel_scene
         |,recommened_refuel_size
         |,start_fuel_size
         |,start_fuel_size_arti
         |,task_classification
         |,station_tag
         |,station_type
         |,is_showed
         |,fuel_qty
         |,fuel_prices
         |,start_miles
         |,end_miles
         |,miles
         |,addfuel_miles
         |,is_add_oil
         |,data_source
         |,total_amount
         |,addfuel_tm
         |,start_tm
         |,end_tm
         |,drive_members
         |,start_place
         |,end_place
         |,task_type
         |,addoil_behavior
         |,actual_if_better
         |,stay_source
         |,stay_time
         |,stay_duration
         |,stay_point
         |,stay_roadname
         |,nornal_stay
         |,osstempurl
         |,req_traveled_dist
         |,req_traveled_coords
         |,return_start
         |,inc_day
         | from dm_gis.dm_eta_basic_data_step3_di where inc_day = '${inc_day}'
         |""".stripMargin

    // todo  是否需要排除  and Stay_point is not null  停留点数据

    logger.error("dm_eta_basic_data_step3_di " + pointSql)

    val  pointDF = sparkSession.sql(pointSql)

    logger.error("dm_eta_basic_data_step3_di 数据量 " + pointDF.count())
    pointDF

  }


  //定义计算直线距离
  def line_distance(str1:String,str2:String):Double={
    val distance_List: ListBuffer[Double] = new ListBuffer[Double]
    if(str1 !=null && !str1.isEmpty && str1.trim !="" && str2 !=null && !str2.isEmpty && str2.trim !="")
    {
      val arr_str1=str1.split("[|]")
      val arr_str2=str2.split("[|]")
      val l1=arr_str1.length
      val l2=arr_str2.length
      for(i<-0 until l1){
        for(j<-0 until l2)
        {
          val d=getDistance(arr_str1(i),arr_str2(j))
          distance_List.append(d)
        }
      }
    }
    var min  = 0.0
    for (i<- 0.until(distance_List.size)){
      val length  =  distance_List(i)
      if(min < length){
        min  = length
      }
    }
    min
  }
  //定义udf函数
  val line_distance_udf=udf(line_distance _)


  def getDistance(x:String,y:String): Double = {
    val lat1=x.split(",")(1).toDouble
    val lng1=x.split(",")(0).toDouble
    val lat2=y.split(",")(1).toDouble
    val lng2=y.split(",")(0).toDouble

    val EARTH_RADIUS: Double = 6378.137
    val radLat1: Double = rad(lat1)
    val radLat2: Double = rad(lat2)
    val a: Double = radLat1 - radLat2
    val b: Double = rad(lng1) - rad(lng2)
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)))
    s = s * EARTH_RADIUS
    s = s * 10000d.round / 10000d
    s = s * 1000
    s
  }


  /**
   * 全量接口返回解析
   * @param x
   * @return
   */

  def pointResponse(x:JSONObject):JSONObject = {

    val  points = x.getString("stay_Point")
    val postJson   = new JSONObject()
    postJson.put("No",0)
    postJson.put("opt","sf4")
    postJson.put("test",1)
    postJson.put("stype",0)
    postJson.put("mode",2)
    postJson.put("etype",0)
    postJson.put("Passport","100000")
    postJson.put("Speed","1")
    postJson.put("Date","")
    postJson.put("simple_distance","0")
    postJson.put("useEstimateTime","1")
    postJson.put("ak","8bb09e5e110845f39a000391668e3e80")
    postJson.put("Points",points)


    // 地址获取省市信息
    //    val response = SparkUtils.doPost(url,postJson,logger,ak)
    logger.error("请求数据:" + postJson )
    val response =SparkUtils.doPost(url,postJson,logger,"")
    // 地址获取省市信息
    logger.error("返回数据:" + response )
    val responseJSON = try {JSON.parseObject(response)} catch {case e:Exception => new JSONObject()}

    val json = try {parseResponse(responseJSON)} catch {case e:Exception => new JSONObject()}
    logger.error("解析的数据"+ json)

    json.put("points",points)
    json
  }



  /**
   * 全量接口返回解析
   * @param x
   * @return
   */

  def pointResponse(points_src:String,point:String) = {

    val postJson   = new JSONObject()

    postJson.put("No",0)
    postJson.put("opt","sf4")
    postJson.put("test",1)
    postJson.put("stype",0)
    postJson.put("mode",2)
    postJson.put("etype",0)
    postJson.put("Passport","100000")
    postJson.put("Speed","1")
    postJson.put("Date","")
    postJson.put("simple_distance","0")
    postJson.put("useEstimateTime","1")
    postJson.put("ak","8bb09e5e110845f39a000391668e3e80")
    postJson.put("Points",point)


    // 地址获取省市信息
    //    val response = SparkUtils.doPost(url,postJson,logger,ak)
    logger.error("请求数据:" + postJson )
    val response =SparkUtils.doPost(url,postJson,logger,"")
    logger.error("返回数据:" + response )
    val responseJSON = try {JSON.parseObject(response)} catch {case e:Exception => new JSONObject()}

    val json = try {parseResponse(responseJSON)} catch {case e:Exception => new JSONObject()}
    logger.error("解析的数据"+ json)


    (points_src,point,json.getString("Adcode"),json.getString("Swid"))
  }

  def parseResponse(response:JSONObject) = {

    val responseJson = new JSONObject()
    val status = response.getString("status")
    if("0".equals(status)){
      val route  = response.getJSONObject("route")
      val routeKeys = route.keySet()
      val adcodeList = new ArrayBuffer[String]()
      val swidList = new ArrayBuffer[String]()
      if(routeKeys.contains("linkTemplates")){
        val  linkTemplates  = route.getJSONArray("linkTemplates")
        for(i <- 0.until(linkTemplates.size())){
          val linkTempLate = linkTemplates.getJSONObject(i)
          val adcode  = linkTempLate.getString("adcode")
          val swid = linkTempLate.getString("swId")
          adcodeList.append(adcode)
          swidList.append(swid)

        }
      }else{
        val  paths =  route.getJSONArray("paths")
        for(i <- 0.until(paths.size())){
          val path = paths.getJSONObject(i)
          val steps  = path.getJSONArray("steps")
          for(i <- 0.until(steps.size())){
            val step = steps.getJSONObject(i)
            val links  = step.getJSONArray("links")
            for(i <- 0.until(links.size())){
              val link = links.getJSONObject(i)
              val adcode  = link.getString("adcode")
              adcodeList.append(adcode)
              val swid = link.getString("sw_id")
              swidList.append(swid)
            }
          }
        }
      }
      responseJson.put("Adcode",adcodeList.mkString("|"))
      responseJson.put("Swid",swidList.mkString("|"))
    }
    logger.error("返回数据: " + responseJson.toJSONString)
    responseJson
  }

}
