package com.sf.gis.scala.scm.app.LINE_PORTRAIT

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, SparkUtil}
import common.DataSourceCommon
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import utils.SparkUtils

import java.util
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}


object LinePortrait extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")


  val tableName : String ="dm_gis.eta_std_line_recall_line_portrait"

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始   ++++")
    execute(spark, inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }


  def execute(sparkSession: SparkSession, inc_day: String) = {

    val sourceSql =
      s"""
         |select task_area_code
         |,task_id
         |,sort_num
         |,task_subid
         |,start_dept
         |,end_dept
         |,start_type
         |,end_type
         |,line_code
         |,vehicle_serial
         |,actual_capacity_load
         |,plan_depart_tm
         |,actual_depart_tm
         |,plan_arrive_tm
         |,actual_arrive_tm
         |,driver_id
         |,driver_name
         |,line_time
         |,line_distance
         |,actual_run_time
         |,start_longitude
         |,start_latitude
         |,end_longitude
         |,end_latitude
         |,is_stop
         |,transoport_level
         |,carrier_type
         |,plf_flag
         |,vehicle_type
         |,axls_number
         |,log_dist
         |,rt_coords
         |,x1
         |,y1
         |,x2
         |,y2
         |,duration
         |,time
         |,rt_dist
         |,highwaymileage
         |,toll_charge
         |,start_distance
         |,end_distance
         |,error_type
         |,pns_dist
         |,pns_time
         |,src
         |,std_coords
         |,line_distance_std
         |,line_time_std
         |,sim1
         |,sim5
         |,diffdist_rt_line
         |,diffratio_rt_line
         |,diffdist_rt_std
         |,diffratio_rt_std
         |,diffdist_rt_log
         |,diffratio_rt_log
         |,diffdist_line_log
         |,diffratio_line_log
         |,diffdist_line_std
         |,diffratio_line_std
         |,diffdist_log_std
         |,diffratio_log_std
         |,conduct_type
         |,difftime_line_std
         |,diffratio1_line_std
         |,difftime_line_std_10min
         |,difftime_line_rt
         |,diffratio1_line_rt
         |,difftime_rt_gh_10min
         |,is_run_ontime_std
         |,is_run_ontime
         |,if_dist_equal
         |,if_time_equal
         |,pns_error
         |,task_inc_day
         |,difftime_std_rt
         |,diffratio1_std_rt
         |,difftime_std_rt_10min
         |,tl_time
         |,halfway_integrate_rate
         |,std_x1
         |,std_y1
         |,std_x2
         |,std_y2
         |,start_distance_std
         |,end_distance_std
         |,std_line_error
         |,ac_difftime_line_rt
         |,ac_diffratio1_line_rt
         |,ac_difftime_rt_gh_10min
         |,ac_difftime_std_rt
         |,ac_diffratio1_std_rt
         |,ac_difftime_std_rt_10min
         |,ac_is_run_ontime_std
         |,ac_is_run_ontime
         |,if_evaluate_time
         |,carrier_name
         |,stop_over_zone_code
         |,biz_type
         |,require_category
         |,to_ground
         |,std_toll_charge
         |,std_id
         |,navi_strategy
         |,is_return_std_line
         |,is_navi_at_start
         |,is_navi_by_std_line
         |,route_time
         |,drive_time
         |,is_yaw_by_driver
         |,navi_complete_rate
         |,accrual_dist
         |,accrual_dist_type
         |,last_update_tm
         |,main_driver_account
         |,road_fee
         |,line_require_id
         |,start_outer_add_code
         |,end_outer_add_code
         |,start_sortnum
         |,end_sortnum
         |,is_navi
         |,rt_tm
         |,inc_day
         | from  dm_gis.eta_std_line_recall where inc_day  = '${inc_day}'
         |""".stripMargin


    val sourceDF = sparkSession.sql(sourceSql)


    import sparkSession.implicits._
    //    //过滤sim1 sim5 > 0.9
    //    val sourceSimDF = sourceDF.filter('sim1 > 0.9 && 'sim5 > 0.9)
    //
    //
    //    //过滤已经存在的数据
    //    val odlStdIdDF = sparkSession.sql(s"""select  std_id from ${tableName} where inc_day ='${inc_day}'""".stripMargin)
    //
    //    val filterSourceDf = sourceSimDF.join(odlStdIdDF, Seq("std_id"), "left")
    //      .filter(odlStdIdDF("std_id") isNull)


    //获取流向数据
    val transportConnectionWeeklyStatisticsDF = sparkSession
      .sql(
        s"""select highway_distance --高速距离 1265.02/73.81
            ,plan_run_speed -- 计划运行时速
            ,actual_run_speed -- 实际运行时速
            ,days_per_week -- 每周频次
            ,total_trips_num -- 行业总趟次
            ,improve_batch_trips_num -- 行业满足跨班次趟次
            ,sf_total_trips_num -- sf总频次
            ,sf_improve_batch_trips_num -- sf满足班次趟次
            ,line_code  --线路编码
        from  dm_gis.transport_connection_weekly_statistics_0929 t0
        inner join (select max(inc_day) as inc_day from dm_gis.transport_connection_weekly_statistics_0929 a where  inc_day <= '${inc_day}' )  t1
        on t0.inc_day  = t1.inc_day
        """)


    //actual_arrive_tm  2023-11-18 05:58:47

    val streamDF = sourceDF.join(transportConnectionWeeklyStatisticsDF, Seq("line_code"), "left")
      .select('highway_distance
        ,'plan_run_speed
        ,'actual_run_speed
        ,'days_per_week
        ,'total_trips_num
        ,'improve_batch_trips_num
        ,'sf_total_trips_num
        ,'sf_improve_batch_trips_num
        ,'task_area_code
        ,'task_id
        ,'sort_num
        ,'task_subid
        ,'start_dept
        ,'end_dept
        ,'start_type
        ,'end_type
        ,'line_code
        ,'vehicle_serial
        ,'actual_capacity_load
        ,'plan_depart_tm
        ,'actual_depart_tm
        ,'plan_arrive_tm
        ,'actual_arrive_tm
        ,'driver_id
        ,'driver_name
        ,'line_time
        ,'line_distance
        ,'actual_run_time
        ,'start_longitude
        ,'start_latitude
        ,'end_longitude
        ,'end_latitude
        ,'is_stop
        ,'transoport_level
        ,'carrier_type
        ,'plf_flag
        ,'vehicle_type
        ,'axls_number
        ,'log_dist
        ,'rt_coords
        ,'x1
        ,'y1
        ,'x2
        ,'y2
        ,'duration
        ,'time
        ,'rt_dist
        ,'highwaymileage
        ,'toll_charge
        ,'start_distance
        ,'end_distance
        ,'error_type
        ,'pns_dist
        ,'pns_time
        ,'src
        ,'std_coords
        ,'line_distance_std
        ,'line_time_std
        ,'sim1
        ,'sim5
        ,'diffdist_rt_line
        ,'diffratio_rt_line
        ,'diffdist_rt_std
        ,'diffratio_rt_std
        ,'diffdist_rt_log
        ,'diffratio_rt_log
        ,'diffdist_line_log
        ,'diffratio_line_log
        ,'diffdist_line_std
        ,'diffratio_line_std
        ,'diffdist_log_std
        ,'diffratio_log_std
        ,'conduct_type
        ,'difftime_line_std
        ,'diffratio1_line_std
        ,'difftime_line_std_10min
        ,'difftime_line_rt
        ,'diffratio1_line_rt
        ,'difftime_rt_gh_10min
        ,'is_run_ontime_std
        ,'is_run_ontime
        ,'if_dist_equal
        ,'if_time_equal
        ,'pns_error
        ,'task_inc_day
        ,'difftime_std_rt
        ,'diffratio1_std_rt
        ,'difftime_std_rt_10min
        ,'tl_time
        ,'halfway_integrate_rate
        ,'std_x1
        ,'std_y1
        ,'std_x2
        ,'std_y2
        ,'start_distance_std
        ,'end_distance_std
        ,'std_line_error
        ,'ac_difftime_line_rt
        ,'ac_diffratio1_line_rt
        ,'ac_difftime_rt_gh_10min
        ,'ac_difftime_std_rt
        ,'ac_diffratio1_std_rt
        ,'ac_difftime_std_rt_10min
        ,'ac_is_run_ontime_std
        ,'ac_is_run_ontime
        ,'if_evaluate_time
        ,'carrier_name
        ,'stop_over_zone_code
        ,'biz_type
        ,'require_category
        ,'to_ground
        ,'std_toll_charge
        ,'std_id
        ,'navi_strategy
        ,'is_return_std_line
        ,'is_navi_at_start
        ,'is_navi_by_std_line
        ,'route_time
        ,'drive_time
        ,'is_yaw_by_driver
        ,'navi_complete_rate
        ,'accrual_dist
        ,'accrual_dist_type
        ,'last_update_tm
        ,'main_driver_account
        ,'road_fee
        ,'line_require_id
        ,'start_outer_add_code
        ,'end_outer_add_code
        ,'start_sortnum
        ,'end_sortnum
        ,'is_navi
        ,'rt_tm
        , 'inc_day)

    //获取原始轨迹
    writeToHive(sparkSession, streamDF, Seq("inc_day"), tableName)

  }



}
