package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import common.DataSourceCommon
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.{DateUtil, SparkUtils}

import scala.collection.mutable.ArrayBuffer

/**
 * GIS-RSS-PNS：【实时交通】任务司机统计信息落表需求说明书_数据侧_V1.0
 * 需求方：曹倩倩(01425168)
 *
 * @author 01420395
 *         任务ID：911271
 *         任务名称：任务司机统计信息落表
 */

object TaskDriverStatistics extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val tblName:String  ="dm_gis.DMTask_Driver_Statistics"

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    start(inc_day)
  }

  def start(inc_day: String): Unit = {

    val spark = SparkUtils.getSparkSession(appName, "yarn")
    spark.sparkContext.setLogLevel("ERROR")

    val dateList = Seq(1,3, 5, 7)

    for (dateType <- dateList) {
     getTaskDriverStatistics(spark,inc_day, dateType)
    }


    SparkUtils.clearCache(spark)
    spark.sqlContext.clearCache()

    val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
    ds.foreach(x => {
      x._2.unpersist()
    })
    logger.error(println(inc_day + "：计算日期结束"))

  }


  def  getTaskDriverStatistics(spark:SparkSession,inc_day  :String , date_type:Int)={


    val start_inc_day = DateUtil.getdaysBefore(inc_day,-date_type,"yyyyMMdd")
    val end_inc_day = inc_day

    // 获取eta_std_line_recall 数据
    val sourceSql =
      s"""
        |    select
        |     task_area_code
        |     ,task_id
        |     ,sort_num
        |     ,task_subid
        |     ,task_inc_day	  -- 任务日期
        |     ,concat(task_id,'_',start_dept,'_',end_dept) as group_task
        |     ,(unix_timestamp(actual_depart_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_depart_tm, 'yyyy-MM-dd HH:mm:ss')) as act_plan_depart_tm_diff   -- 出发时间差
        |     ,cast((unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(actual_depart_tm, 'yyyy-MM-dd HH:mm:ss'))/600 as INT) as eta_count   -- 应判断次数
        |     ,(unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_arrive_tm, 'yyyy-MM-dd HH:mm:ss')) as act_delay_tm   -- 实际延迟时间,可为负数
        |     ,start_dept	  -- 始发网点
        |     ,end_dept	  -- 目的网点
        |     ,start_type	  -- 始发网点类型
        |     ,end_type	  -- 目的网点类型
        |     ,line_code	  -- 线路编码
        |     ,vehicle_serial	  -- 车牌号码
        |     ,actual_capacity_load	  -- 实际运力载量（指派的车辆吨位）
        |     ,plan_depart_tm	  -- 计划发车时间
        |     ,actual_depart_tm	  -- 实际发车时间
        |     ,plan_arrive_tm	  -- 计划到车时间
        |     ,actual_arrive_tm	  -- 实际到车时间
        |     ,driver_id	  -- 司机ID
        |     ,driver_name	  -- 司机姓名
        |     ,line_time	  -- 计划运行时长(min)
        |     ,line_distance	  -- 规划里程(km)
        |     ,actual_run_time	  -- 实际运行时长(min)
        |     ,start_longitude	  -- 起点经度
        |     ,start_latitude	  -- 起点纬度
        |     ,end_longitude	  -- 终点经度
        |     ,end_latitude	  -- 终点纬度
        |     ,is_stop	  -- 是否经停(1：直发2：经停3：多卸货口)
        |     ,transoport_level	  -- 运输等级(1一级运输，2二级运输，3三级运输，4短驳)
        |     ,carrier_type	  -- 承运商类型
        |     ,plf_flag	  -- 是否平台车主
        |     ,vehicle_type	  -- 车辆类型
        |     ,axls_number	  -- 轴数
        |     ,log_dist	  -- 码表里程
        |     ,x1	  -- 轨迹实际起点经度
        |     ,y1	  -- 轨迹实际起点纬度
        |     ,x2	  -- 轨迹实际终点经度
        |     ,y2	  -- 轨迹实际终点纬度
        |     ,duration	  -- 停留时长(s)
        |     ,time as act_time   -- 实际行驶时间
        |     ,rt_dist	  -- 任务实际里程(m)
        |     ,highwaymileage	  -- 高速里程(m)
        |     ,toll_charge	  -- 收费
        |     ,start_distance	  -- 轨迹起点与起点网点距离(m)
        |     ,end_distance	  -- 轨迹终点与终点网点距离(m)
        |     ,error_type	  -- 轨迹异常类型
        |     ,pns_dist	  -- 标准线路里程(m)
        |     ,pns_time	  -- 标准线路时效(s)
        |     ,src	  -- 标准线路来源
        |     ,line_distance_std	  -- 配置里程(m)
        |     ,line_time_std	  -- 配置时长(s)
        |     ,sim1	  -- 相似度1
        |     ,sim5	  -- 相似度5
        |     ,diffdist_rt_line	  -- 实际里程与规划里程偏差(m)
        |     ,diffratio_rt_line	  -- 实际里程与规划里程偏差率
        |     ,diffdist_rt_std	  -- 实际里程与标准线路里程偏差(m)
        |     ,diffratio_rt_std	  -- 实际里程与标准线路里程偏差率
        |     ,diffdist_rt_log	  -- 实际里程与码表里程偏差(m)
        |     ,diffratio_rt_log	  -- 实际里程与码表里程偏差率
        |     ,diffdist_line_log	  -- 规划里程与码表里程偏差(m)
        |     ,diffratio_line_log	  -- 规划里程与码表里程偏差率
        |     ,diffdist_line_std	  -- 规划里程与标准线路里程偏差(m)
        |     ,diffratio_line_std	  -- 规划里程与标准线路里程偏差率
        |     ,diffdist_log_std	  -- 码表里程与标准线路里程偏差(m)
        |     ,diffratio_log_std	  -- 码表里程与标准线路里程偏差率
        |     ,conduct_type	  -- 执行情况
        |     ,difftime_line_std	  -- 规划时长与标准线路时长偏差(s)
        |     ,diffratio1_line_std	  -- 规划时长与标准线路时长偏差率
        |     ,difftime_line_std_10min	  -- 规划时长与标准线路时长偏差区间
        |     ,difftime_line_rt	  -- 规划耗时与实际耗时(去停留)偏差
        |     ,diffratio1_line_rt	  -- 规划耗时与实际耗时(去停留)偏差率
        |     ,difftime_rt_gh_10min	  -- 规划耗时与实际耗时偏差区间
        |     ,is_run_ontime_std	  -- 是否准点(去停留)_std
        |     ,is_run_ontime	  -- 是否准点(去停留)
        |     ,if_dist_equal	  -- 接口返回配置里程是否准确
        |     ,if_time_equal	  -- 接口返回配置时长是否准确
        |     ,pns_error	  -- 接口返回异常情况
        |     ,difftime_std_rt	  -- 标准线路时长与实际耗时(去停留)偏差
        |     ,diffratio1_std_rt	  -- 标准线路时长与实际耗时(去停留)偏差率
        |     ,difftime_std_rt_10min	  -- 标准线路时长与实际耗时(去停留)偏差区间
        |     ,tl_time	  -- 实际行驶时间(单位:s,去停留)
        |     ,halfway_integrate_rate	  -- 轨迹完整率
        |     ,std_x1	  -- 标准线路起点经度
        |     ,std_y1	  -- 标准线路起点纬度
        |     ,std_x2	  -- 标准线路终点经度
        |     ,std_y2	  -- 标准线路终点纬度
        |     ,start_distance_std	  -- 标准线路起点和实际起点的距离(m)
        |     ,end_distance_std	  -- 标准线路终点和实际终点的距离(m)
        |     ,std_line_error	  -- 标准线路与实际轨迹起终点匹配是否异常
        |     ,ac_difftime_line_rt	  -- 规划耗时与实际耗时偏差(s)
        |     ,ac_diffratio1_line_rt	  -- 规划耗时与实际耗时偏差率
        |     ,ac_difftime_rt_gh_10min	  -- 规划耗时与实际耗时偏差区间
        |     ,ac_difftime_std_rt	  -- 标准线路时长与实际耗时偏差(s)
        |     ,ac_diffratio1_std_rt	  -- 标准线路时长与实际耗时偏差率
        |     ,ac_difftime_std_rt_10min	  -- 标准线路时长与实际耗时偏差区间(s)
        |     ,ac_is_run_ontime_std	  -- 是否准点_std
        |     ,ac_is_run_ontime	  -- 是否准点
        |     ,if_evaluate_time	  -- 任务是否考核时效
        |     ,carrier_name	  -- 承运商名称
        |     ,stop_over_zone_code	  -- 经停点
        |     ,biz_type	  -- 业务类型
        |     ,require_category	  -- 需求类别
        |     ,to_ground	  -- 过滤条件,'1'
        |     ,std_toll_charge	  -- 标准线路收费
        |     ,std_id	  -- 标准线路id
        |     ,navi_strategy	  -- （导航）点选策略
        |     ,is_return_std_line	  -- （导航）是否有返回标准线路（0否 1是）
        |     ,is_navi_at_start	  -- 是否起点导航（0否 1是）
        |     ,is_navi_by_std_line	  -- 是否标准线路开始导航（0否 1是）
        |     ,route_time	  -- （导航）线路规划时长
        |     ,drive_time	  -- （导航）行驶时长
        |     ,is_yaw_by_driver	  -- （导航）是否有司机主动偏航（0否 1是）
        |     ,navi_complete_rate	  -- 导航完成率
        |     ,accrual_dist	  -- 计提里程
        |     ,accrual_dist_type	  -- 计提里程类型
        |     ,last_update_tm	grd   -- 任务数据更新时间戳
        |     ,main_driver_account	  -- 司机工号
        |     ,road_fee	  -- 日志路桥费
        |     ,is_navi   -- 是否全程使用导航 1
        |    from dm_gis.eta_std_line_recall
        |    where inc_day >= '${start_inc_day}' and inc_day <= '${end_inc_day}'
        |    and if_evaluate_time = '1'
        |    and driver_id is not null
        |    and line_code is not null
        |    and task_area_code is not null
        |    and carrier_name is not null
        |    and start_dept is not null
        |    and end_dept is not null
        |    and line_time  is not null
        |    and line_distance   is not null
        |    and actual_run_time   is not null
        |    and is_run_ontime  is not null
        |    and ac_is_run_ontime   is not null
        |    and rt_dist   is not null
        |    and sim1  is not null
        |    and sim5   is not null
        |    and vehicle_serial is not null
        |
        |""".stripMargin


    logger.error( sourceSql )

    import  spark.implicits._

    import org.apache.spark.sql.functions._
    val  sourceDF  =  spark.sql(sourceSql)
      .withColumn("plan_speed",  'line_distance / 'line_time*60)  //  单位是km/h
      .withColumn("act_speed",  'rt_dist/ 1000  / ('act_time / 3600))
      .withColumn("is_delayed",  when('act_delay_tm>=0,lit(1)).otherwise(lit(0))) // 是否延迟

    import org.apache.spark.sql.functions._

    logger.error( "数据量: " +  sourceDF.count()  )
    val  sourceDF1 =  sourceDF.select(
      'vehicle_serial
      ,'driver_id
      ,'start_dept
      ,'end_dept
      ,'actual_run_time
      ,'rt_dist
      ,'sim1
      ,'sim5
      ,'plan_speed
      ,'act_speed
      ,'is_delayed
      ,'act_time
      ,'act_delay_tm)


    // 计算值
    val  start_end_dept_DF  =  sourceDF1.groupBy("start_dept","end_dept").agg(
      max("actual_run_time").as("actual_run_time_max"),
      sum("actual_run_time").as("actual_run_time_sum"),
      min("actual_run_time").as("actual_run_time_min"),
      mean("actual_run_time").as("actual_run_time_mean"),
      stddev("actual_run_time").as("actual_run_time_std"),

      max("rt_dist").as("rt_dist_max"),
      sum("rt_dist").as("rt_dist_sum"),
      min("rt_dist").as("rt_dist_min"),
      mean("rt_dist").as("rt_dist_mean"),
      stddev("rt_dist").as("rt_dist_std"),

      max("sim1").as("sim1_max"),
      sum("sim1").as("sim1_sum"),
      min("sim1").as("sim1_min"),
      mean("sim1").as("sim1_mean"),
      stddev("sim1").as("sim1_std"),

      max("sim5").as("sim5_max"),
      sum("sim5").as("sim5_sum"),
      min("sim5").as("sim5_min"),
      mean("sim5").as("sim5_mean"),
      stddev("sim5").as("sim5_std"),

      mean("plan_speed").as("plan_mean_speed"),
      mean("act_speed").as("act_mean_speed"),

      sum(when('is_delayed===1,1).otherwise(0)).as("delayed_count"),
      (sum(when('is_delayed===1,1).otherwise(0))/count(lit(1))).as("delayed_ratio"),
      (sum(when('is_delayed===1,'act_delay_tm).otherwise(lit(0)))/sum(when('is_delayed===1,lit(1)).otherwise(lit(0)))).as("avg_delayed_time"),
      (sum(when('is_delayed===1,'act_delay_tm).otherwise(0))/sum('act_time)).as("delay_time_ratio")
    ).withColumn("vehicle_serial",lit(""))
      .withColumn("driver_id",lit(""))
      .withColumn("date_type",lit(date_type))
      .withColumn("polymerization_type",lit("3"))


    start_end_dept_DF.show(1,false)

    val  start_end_dept_vehicle_serial_DF  =  sourceDF1.groupBy("start_dept","end_dept","vehicle_serial").agg(
      max("actual_run_time").as("actual_run_time_max"),
      sum("actual_run_time").as("actual_run_time_sum"),
      min("actual_run_time").as("actual_run_time_min"),
      mean("actual_run_time").as("actual_run_time_mean"),
      stddev("actual_run_time").as("actual_run_time_std"),

      max("rt_dist").as("rt_dist_max"),
      sum("rt_dist").as("rt_dist_sum"),
      min("rt_dist").as("rt_dist_min"),
      mean("rt_dist").as("rt_dist_mean"),
      stddev("rt_dist").as("rt_dist_std"),

      max("sim1").as("sim1_max"),
      sum("sim1").as("sim1_sum"),
      min("sim1").as("sim1_min"),
      mean("sim1").as("sim1_mean"),
      stddev("sim1").as("sim1_std"),

      max("sim5").as("sim5_max"),
      sum("sim5").as("sim5_sum"),
      min("sim5").as("sim5_min"),
      mean("sim5").as("sim5_mean"),
      stddev("sim5").as("sim5_std"),

      mean("plan_speed").as("plan_mean_speed"),
      mean("act_speed").as("act_mean_speed"),

      sum(when('is_delayed===1,1).otherwise(0)).as("delayed_count"),
      (sum(when('is_delayed===1,1).otherwise(0))/count(lit(1))).as("delayed_ratio"),
      (sum(when('is_delayed===1,'act_delay_tm).otherwise(lit(0)))/sum(when('is_delayed===1,lit(1)).otherwise(lit(0)))).as("avg_delayed_time"),
      (sum(when('is_delayed===1,'act_delay_tm).otherwise(0))/sum('act_time)).as("delay_time_ratio")
    ) .withColumn("driver_id",lit(""))
      .withColumn("date_type",lit(date_type))
      .withColumn("polymerization_type",lit("1"))



    val  start_end_dept_driver_id_DF  =  sourceDF1.groupBy("start_dept","end_dept","driver_id").agg(
      max("actual_run_time").as("actual_run_time_max"),
      sum("actual_run_time").as("actual_run_time_sum"),
      min("actual_run_time").as("actual_run_time_min"),
      mean("actual_run_time").as("actual_run_time_mean"),
      stddev("actual_run_time").as("actual_run_time_std"),

      max("rt_dist").as("rt_dist_max"),
      sum("rt_dist").as("rt_dist_sum"),
      min("rt_dist").as("rt_dist_min"),
      mean("rt_dist").as("rt_dist_mean"),
      stddev("rt_dist").as("rt_dist_std"),

      max("sim1").as("sim1_max"),
      sum("sim1").as("sim1_sum"),
      min("sim1").as("sim1_min"),
      mean("sim1").as("sim1_mean"),
      stddev("sim1").as("sim1_std"),

      max("sim5").as("sim5_max"),
      sum("sim5").as("sim5_sum"),
      min("sim5").as("sim5_min"),
      mean("sim5").as("sim5_mean"),
      stddev("sim5").as("sim5_std"),

      mean("plan_speed").as("plan_mean_speed"),
      mean("act_speed").as("act_mean_speed"),

      sum(when('is_delayed===1,1).otherwise(0)).as("delayed_count"),
      (sum(when('is_delayed===1,1).otherwise(0))/count(lit(1))).as("delayed_ratio"),
      (sum(when('is_delayed===1,'act_delay_tm).otherwise(lit(0)))/sum(when('is_delayed===1,lit(1)).otherwise(lit(0)))).as("avg_delayed_time"),
      (sum(when('is_delayed===1,'act_delay_tm).otherwise(0))/sum('act_time)).as("delay_time_ratio")
    ) .withColumn("vehicle_serial",lit(""))
      .withColumn("date_type",lit(date_type))
      .withColumn("polymerization_type",lit("2"))


    val resultDF = start_end_dept_driver_id_DF.union(start_end_dept_vehicle_serial_DF).union(start_end_dept_DF)
      .withColumn("inc_day",lit(inc_day))
      .select(
        'vehicle_serial
        ,'driver_id
        ,'start_dept
        ,'end_dept
        ,'actual_run_time_mean
        ,'actual_run_time_sum
        ,'actual_run_time_min
        ,'actual_run_time_max
        ,'actual_run_time_std
        ,'rt_dist_mean
        ,'rt_dist_sum
        ,'rt_dist_min
        ,'rt_dist_max
        ,'rt_dist_std
        ,'sim1_mean
        ,'sim1_sum
        ,'sim1_min
        ,'sim1_max
        ,'sim1_std
        ,'sim5_mean
        ,'sim5_sum
        ,'sim5_min
        ,'sim5_max
        ,'sim5_std
        ,'plan_mean_speed
        ,'act_mean_speed
        ,'delayed_count
        ,'delayed_ratio
        ,'avg_delayed_time
        ,'delay_time_ratio
        ,'polymerization_type
        ,'inc_day
        ,'date_type
      )

    logger.error("数据量:" + resultDF.count())

    resultDF.show(1)

    writeToHive(spark, resultDF,Seq("inc_day", "date_type"), tblName)
  }

}
