package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import utils.DateUtil

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01368978 on 2021/5/28.
  */
object NaviLogParse {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)



  /**
    * 开始程序
    * @param args
    * @param spark
    * @param runDate
    * @param getDateListF
    * @param getHiveRddF
    * @param saveHiveRddF
    * @return
    */
  def start(args: Array[String], spark:SparkSession, runDate:String, getDateListF:(String) => ArrayBuffer[String], getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit): Unit ={

    if (args.length == 0) {
      //代码内部传入日期参数
      val date = runDate
      NaviLogParse.handleTask(spark, date,getDateListF,getHiveRddF,saveHiveRddF)
    } else if (args.length == 1) {
      //传入参数，单天任务
      val date = args(0)
      NaviLogParse.handleTask(spark, date,getDateListF,getHiveRddF,saveHiveRddF)
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      val startDate = args(0)
      val endDate = args(1)
      var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
      logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
      for (date <- dateList) {
        NaviLogParse.handleTask(spark, date,getDateListF,getHiveRddF,saveHiveRddF)
      }
    }
  }


  /**
    * 批量任务
    *
    * @param spark
    * @param startDate
    * @param endDate
    * @param getDateListF
    * @param getHiveRddF
    * @param saveHiveRddF
    */
  def batchTask(spark: SparkSession, startDate: String, endDate: String, getDateListF:(String) => ArrayBuffer[String], getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      handleTask(spark, date,getDateListF,getHiveRddF,saveHiveRddF)
    }
  }



  /**
    * 解析日志主流程
    * @param spark
    * @param endDate
    * @param getDateListF
    * @param getHiveRddF
    * @param saveHiveRddF
    * @return
    */
  def handleTask(spark:SparkSession, endDate:String, getDateListF:(String) => ArrayBuffer[String], getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit): Unit ={
    val dateList = getDateListF(endDate)
    logger.error(">>>处理"+dateList.mkString(",")+"号的任务----------------------------------")
    //EtaLogParse.parseLog(spark,getHiveRddF,saveHiveRddF,dateList)
    logger.error(">>>The End!")
  }


  /**
    * 解析日志主流程
    * @param spark
    * @param getRddF
    * @param getHiveRddF
    * @param computeRddF
    * @param table
    * @param structs
    * @param keys
    * @param saveHiveRddF
    * @param dateList
    * @return
    */
  def parseSaveLog(spark:SparkSession, getRddF:(SparkSession,(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject],ArrayBuffer[String]) => RDD[JSONObject],
                   getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], computeRddF:(RDD[JSONObject]) => RDD[JSONObject],
                   table: String, structs:Array[String], keys:Array[String],
                   saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit, dateList:ArrayBuffer[String]): Unit ={
    val etaComputeRdd = getRddF(spark,getHiveRddF,dateList)
    if(computeRddF!=null){
      val resultRdd = computeRddF(etaComputeRdd)
      logger.error("数据量统计: " + resultRdd.count())
      saveHiveRddF(spark,resultRdd,table,structs,keys,dateList)
      etaComputeRdd.unpersist()
      resultRdd.unpersist()
    }
    else{
      saveHiveRddF(spark,etaComputeRdd,table,structs,keys,dateList)
      etaComputeRdd.unpersist()
    }
  }


  /**
    * 保存到hive日志
    * @param spark
    * @param resultRdd
    * @param table
    * @param structs
    * @param keys
    * @param date
    * @return
    */

  def filterRddToHive(spark:SparkSession, resultRdd:RDD[JSONObject],table: String, structs:Array[String], keys:Array[String],date:String): Unit ={
    SaveDataToHive.saveJSONObjectRDDToHive(spark,resultRdd,table,structs,keys,date)
  }



  def filterRddToHive2(spark:SparkSession, resultRdd:RDD[JSONObject],table: String, structs:Array[String], keys:Array[String],date:String): Unit ={
    SaveDataToHive.saveJSONObjectRDDToHive2(spark,resultRdd,table,structs,keys,date)
  }



  /**
    * 过滤有效日志
    * @param spark
    * @param sql
    * @return
    */
  def getValidLog(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val logRdd =  spark.sql(sql).na.fill("").rdd.repartition(6400).map(row=>{
      var json:JSONObject = null
      try {
        val line = row.getString(0)
        json = JSON.parseObject(line)

//        val inc_date = row.getString(1)
//        if(json!=null) json.put("inc_date",inc_date)
      } catch {
        case e:Exception =>logger.error(">>>日志转json失败："+e)
      }
      json
    }).filter(_!=null).persist()
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }


  /**
    * 过滤有效日志
    * @param spark
    * @param sql
    * @return
    */
  def getValidJson(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(1000).map(row=>{
      val json = new JSONObject()
      for(i<-fields.indices){
        json.put(header(i),row.getString(i))
      }
      json
    }).filter(_!=null).persist()
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }



}
