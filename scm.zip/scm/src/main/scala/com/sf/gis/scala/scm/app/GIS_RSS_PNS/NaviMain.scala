package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import com.alibaba.fastjson.JSONObject
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import utils.{DateUtil, SparkUtil}

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01368978 on 2021/5/28.
  * 多天的
  */
object NaviMain {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)



  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    val runDate = DateUtil.getYesterday

    logger.error("处理" + runDate)
    NaviLogParse.start(args: Array[String],spark,runDate,getMutiDayDateList,fiterMutiDayValidLog,mutiDayRddToHive)

    spark.stop()
  }



  /**
    * 获取日期列表
    * @param endDate
    * @return
    */
  def getMutiDayDateList(endDate:String): ArrayBuffer[String] ={
    val startDate = DateUtil.getDateStr(endDate,-1)
    //val endDate1 = DateUtil.getDateStr(endDate,1)
    val dateList = DateUtil.getTwoDatesStr(startDate,endDate)
    dateList+=endDate
  }



  /**
    * 过滤有效日志
    * @param spark
    * @param dateList
    * @param subType
    * @return
    */
  def fiterMutiDayValidLog(spark:SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject])={
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val endDate1 = endDate//DateUtil.getDateStr(endDate,1)
    var sql=""
    var logRdd:RDD[JSONObject] = null
    var table = ""
    if(subType.contains("Result") && (subType.contains("V2") || subType.contains("path"))) table = "gis_eta_navi_query_proto_hive"
    else table = "gis_eta_navi_query_hive"
    if(subType.contains(",")){
      val subTypes = subType.split(",")
      val subType1 = subTypes(0)
      val subType2 = subTypes(1)
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate1'
           | and (get_json_object(data, '$$.subType') = '$subType1' or get_json_object(data, '$$.subType') = '$subType2')
       """.stripMargin
    }
    else{
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate1'
           | and get_json_object(data, '$$.subType') = '$subType'
       """.stripMargin
    }
    logRdd = NaviLogParse.getValidLog(spark, sql)
    logRdd
  }



  /**
    * 保存到hive日志
    * @param spark
    * @param resultRdd
    * @param table
    * @param structs
    * @param keys
    * @param dateList
    * @return
    */
  def mutiDayRddToHive(spark:SparkSession, resultRdd:RDD[JSONObject], table: String, structs:Array[String], keys:Array[String], dateList:ArrayBuffer[String]): Unit ={
    for(date<-dateList){
      val resultRdd2 = filterRdd(resultRdd,date)
      NaviLogParse.filterRddToHive(spark,resultRdd2,table,structs,keys,date)
    }
    resultRdd.unpersist()
  }

  def mutiDayRddToHive2(spark:SparkSession, resultRdd:RDD[JSONObject], table: String, structs:Array[String], keys:Array[String], dateList:ArrayBuffer[String]): Unit ={
    for(date<-dateList){
      val resultRdd2 = filterRdd(resultRdd,date)
      NaviLogParse.filterRddToHive2(spark,resultRdd2,table,structs,keys,date)
    }
    resultRdd.unpersist()
  }


  /**
    * 过滤日志
    * @param resultRdd
    * @param date
    * @return
    */
  def filterRdd(resultRdd:RDD[JSONObject], date:String): RDD[JSONObject] ={
    val dateRdd = resultRdd.filter(json=>{
      val inc_date = json.getString("inc_date")
      inc_date!=null && inc_date.equals(date)
    }).persist()

    dateRdd
  }


}
