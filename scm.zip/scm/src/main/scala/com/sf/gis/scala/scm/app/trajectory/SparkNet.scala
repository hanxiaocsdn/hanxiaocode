package com.sf.gis.scala.scm.app.trajectory

import com.alibaba.fastjson.JSONObject
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.{Executors, LinkedBlockingQueue}
import scala.concurrent.{ExecutionContext, ExecutionContextExecutorService}

/**
  * Created by 01374443 on 2020/7/27.
  */
object SparkNet {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  /**
    * 跑限制了带ak分钟最大量的接口
    *
    * @param dataRdd     数据主体，包含了需要跑接口的数据
    * @param parallelism 指定接口并发度
    * @param akMinuLimit ak分钟最大使用量
    */
  def runInterfaceWithAkLimit(sparkSession: SparkSession,dataRdd: RDD[JSONObject], fun: (String, JSONObject) => JSONObject, parallelism: Int, ak: String, akMinuLimit: Int): RDD[JSONObject] = {
    var cores = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.cores", "0"))
    var excutors = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.instances", "0"));
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    val localMaster: String = sparkSession.sparkContext.getConf.get("spark.master", "")
    logger.error(localMaster)
    /*if (!localMaster.isEmpty) {
      logger.error("本地调用")
      excutors = localMaster.takeRight(2).dropRight(1).toInt;
      cores = 1
    }*/
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    //为了精确控制并发，task数量和并行度需要小于excutors数量，否则并行度和ak单位分钟限制无法精确控制
    var maxParallelism = parallelism
    if (parallelism > excutors) {
      maxParallelism = excutors;
    }
    logger.error("最大分区数：" + maxParallelism)
    val curPartition = dataRdd.getNumPartitions
    var runRdd: RDD[JSONObject] = null
    if (curPartition != maxParallelism) {
      runRdd = dataRdd.repartition(maxParallelism)
      logger.error("重分区：" + maxParallelism)
    } else {
      runRdd = dataRdd
    }
    var maxMinueOfPartition = akMinuLimit / maxParallelism
    if (parallelism > maxParallelism) {
      maxMinueOfPartition = akMinuLimit / maxParallelism;
    }
    logger.error("单分区ak最大分钟限制：" + maxMinueOfPartition)
    val retRdd = runRdd.mapPartitions(partitions => {
      val partitionLimitMinu = maxMinueOfPartition
      var lastMin = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      //实际单为并行跑数
      partitions.map(obj => {
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin) {
          timeInt = timeInt + 1
          if (timeInt >= partitionLimitMinu) {
            logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount)
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          timeInt = 1
          lastMin = cur
        }
        fun(ak, obj)
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("接口运行完毕:" + retRdd.count())
    retRdd.take(2).foreach(obj => {
      logger.error(obj.toJSONString)
    })
    retRdd
  }




  /**
   * 跑限制了带ak分钟最大量的接口
   *
   * @param dataRdd     数据主体，包含了需要跑接口的数据
   * @param parallelism 指定接口并发度
   * @param akMinuLimit ak分钟最大使用量
   */
  def runInterfaceWithAkLimit1(sparkSession: SparkSession,dataRdd: RDD[JSONObject], fun: (String, JSONObject) => Seq[JSONObject], parallelism: Int, ak: String, akMinuLimit: Int): RDD[Seq[JSONObject]] = {
    var cores = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.cores", "0"))
    var excutors = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.instances", "0"));
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    val localMaster: String = sparkSession.sparkContext.getConf.get("spark.master", "")
    logger.error(localMaster)
    /*if (!localMaster.isEmpty) {
      logger.error("本地调用")
      excutors = localMaster.takeRight(2).dropRight(1).toInt;
      cores = 1
    }*/
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    //为了精确控制并发，task数量和并行度需要小于excutors数量，否则并行度和ak单位分钟限制无法精确控制
    var maxParallelism = parallelism
    if (parallelism > excutors) {
      maxParallelism = excutors;
    }
    logger.error("最大分区数：" + maxParallelism)
    val curPartition = dataRdd.getNumPartitions
    var runRdd: RDD[JSONObject] = null
    if (curPartition != maxParallelism) {
      runRdd = dataRdd.repartition(maxParallelism)
      logger.error("重分区：" + maxParallelism)
    } else {
      runRdd = dataRdd
    }
    var maxMinueOfPartition = akMinuLimit / maxParallelism
    if (parallelism > maxParallelism) {
      maxMinueOfPartition = akMinuLimit / maxParallelism;
    }
    logger.error("单分区ak最大分钟限制：" + maxMinueOfPartition)
    val retRdd = runRdd.mapPartitions(partitions => {
      val partitionLimitMinu = maxMinueOfPartition
      var lastMin = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      //实际单为并行跑数
      partitions.map(obj => {
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin) {
          timeInt = timeInt + 1
          if (timeInt >= partitionLimitMinu) {
            logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount)
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          timeInt = 1
          lastMin = cur
        }
        fun(ak, obj)
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error("接口运行完毕:" + retRdd.count())
    retRdd
  }


  /**
    * 单核多线程的跑数，充分利用核
    */
  def runInterfaceWithAkLimitMultiThread(sparkSession: SparkSession,
                                         dataRdd: RDD[JSONObject], fun: (String, JSONObject, Map[String, String]) => JSONObject,
                                         keyMap: Map[String, String], parallelism: Int, ak: String, akMinuLimit: Int): RDD[JSONObject] = {
    var cores = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.cores", "0"))
    var excutors = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.instances", "0"));
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    val localMaster = sparkSession.sparkContext.getConf.get("spark.master", "")
    if (!localMaster.isEmpty) {
      logger.error("本地调用")
      excutors = localMaster.takeRight(2).dropRight(1).toInt;
      cores = 1
    }
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    //为了精确控制并发，task数量和并行度需要小于excutors数量，否则并行度和ak单位分钟限制无法精确控制
    var maxParallelism = parallelism
    if (parallelism > excutors) {
      maxParallelism = excutors;
    }
    logger.error("最大分区数：" + maxParallelism)
    val curPartition = dataRdd.getNumPartitions
    var runRdd: RDD[JSONObject] = null
    if (curPartition != maxParallelism) {
      runRdd = dataRdd.repartition(maxParallelism)
      logger.error("重分区：" + maxParallelism)
    } else {
      runRdd = dataRdd
    }
    var maxMinueOfPartition = akMinuLimit / maxParallelism
    if (parallelism > maxParallelism) {
      maxMinueOfPartition = akMinuLimit / maxParallelism;
    }
    logger.error("单分区ak最大分钟限制：" + maxMinueOfPartition)
    var poolSize = parallelism / maxParallelism
    if (poolSize == 0) {
      poolSize = 1
    }
    logger.error("线程池数量:" + poolSize)
    val retRdd = runRdd.mapPartitions(partitions => {
      val partitionLimitMinu = maxMinueOfPartition
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)
      val retList = new LinkedBlockingQueue[JSONObject]
      if (poolSize != 1) {
        //多线程运行，起线程池
        val threadPool = Executors.newFixedThreadPool(poolSize)
        implicit val ec: ExecutionContextExecutorService = ExecutionContext.fromExecutorService(threadPool)
        partitions.foreach(obj => {
          threadPool.submit(new Runnable {
            override def run(): Unit = {
              akLimitMultiThreadDetail(partitionLimitMinu, partitionsCount, lastMin,
                timeInt, fun, retList, ak, obj, keyMap)
            }
          })
        })
        threadPool.shutdown()
        while (!threadPool.isTerminated()) {
          Thread.sleep(100)
        }
      } else {
        //单线程运行，起线程池
        partitions.foreach(obj => {
          akLimitMultiThreadDetail(partitionLimitMinu, partitionsCount, lastMin,
            timeInt, fun, retList, ak, obj, keyMap)
        })
      }
      retList.toArray().iterator
    }).map(obj => obj.asInstanceOf[JSONObject]).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("接口运行完毕:" + retRdd.count())
    retRdd.take(2).foreach(obj => {
      logger.error(obj.toJSONString)
    })
    retRdd
  }
  def akLimitMultiThreadDetail(partitionLimitMinu: Int, partitionsCount: AtomicInteger, lastMin: AtomicInteger,
                               timeInt: AtomicInteger, fun: (String, JSONObject, Map[String, String]) => JSONObject,
                               retList: LinkedBlockingQueue[JSONObject], ak: String,
                               obj: JSONObject, keyMap: Map[String, String]): Unit = {
    if (partitionsCount.incrementAndGet() % 100 == 0) {
      logger.error(partitionsCount)
    }
    val second = Calendar.getInstance().get(Calendar.SECOND)
    val cur = Calendar.getInstance().get(Calendar.MINUTE)
    if (cur == lastMin.get()) {
      if (timeInt.incrementAndGet() >= partitionLimitMinu) {
        logger.error("分钟数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
        Thread.sleep((60 - second) * 1000)
      }
    } else {
      //不能精细控制，set存在并发问题
      timeInt.set(1)
      lastMin.set(cur)
    }
    retList.add(fun(ak, obj, keyMap))
  }

}
