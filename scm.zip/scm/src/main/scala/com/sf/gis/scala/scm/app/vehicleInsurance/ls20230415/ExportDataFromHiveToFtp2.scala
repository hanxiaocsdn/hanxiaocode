package com.sf.gis.scala.scm.app.vehicleInsurance.ls20230415

import common.DataSourceCommon
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import utils.{DateTimeUtil, SparkBuilder}

object ExportDataFromHiveToFtp2  extends DataSourceCommon  {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val hdfsPath="/dolphinscheduler/user/01401062/1611146"

  def main(args: Array[String]): Unit = {

    val startDate = args(0)
    val endDate = args(1)

    val dataList = DateTimeUtil.getDateInterval(startDate,endDate,"yyyyMMdd","yyyyMMdd").reverse
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    for (biz_date <- dataList){
      exportEmVmsVehicle(spark,biz_date)
    }
  }

  /**
    * 导出  gis_tm_vehicle 数据
    * @param sparkSession
    * @param inc_day
    */
  def exportEmVmsVehicle(sparkSession: SparkSession , inc_day: String)= {
    val gis_tm_vehicle_sql =
      s"""
        SELECT car_no,lng,lat,tm,inc_day,biz_week from dm_gis.ods_track_yy_di_20230415_y where inc_day = '${inc_day}'
      """.stripMargin

    logger.error(">>>> ods_track_yy_di_20230415_y: " + gis_tm_vehicle_sql)
    val gis_tm_vehicle_Tbl_DF = sparkSession.sql(gis_tm_vehicle_sql)
    logger.error(">>>> gis_tm_vehicle 数据量 " + gis_tm_vehicle_Tbl_DF.count() )

    val outPath = hdfsPath+"/"+inc_day+"/dm_gis.ods_track_yy_di_20230415_y"
    gis_tm_vehicle_Tbl_DF.persist(StorageLevel.MEMORY_AND_DISK)

    gis_tm_vehicle_Tbl_DF.coalesce(1)
      .write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", ",")
      .csv(outPath)
    hdfsFileReName(sparkSession,outPath, "dm_gis.ods_track_yy_di_20230415_y"+inc_day+".csv")



  }



  def hdfsFileReName(sparkSession: SparkSession , outpath:String, fileName:String )={

    val fs = FileSystem.get(sparkSession.sparkContext.hadoopConfiguration)
    val file = fs.globStatus(new Path(s"$outpath/part-0000*"))(0).getPath().getName()

    if(fs.exists(new Path(outpath + "/" + fileName))){
      fs.delete(new Path(outpath + "/" + fileName),true)
    }

    println(s"$outpath/$file rename to $outpath/$fileName")
    fs.rename(new Path(outpath + "/" + file), new Path(outpath + "/" + fileName))

  }


}
