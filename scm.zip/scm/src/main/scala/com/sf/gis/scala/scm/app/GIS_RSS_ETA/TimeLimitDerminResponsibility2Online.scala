//package com.sf.gis.scala.scm.app.GIS_RSS_ETA
//
//import java.lang.Math
//import java.text.SimpleDateFormat
//import java.util
//
//import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
//import com.fengtu.sparktest.utils.{DateTimeUtil, JSONUtils, SparkUtils, StringUtils}
//import com.fengtu.sparktest.utils2.Utils
//import com.github.davidmoten.rtree.RTree
//import com.github.davidmoten.rtree.geometry.{Geometries, Point}
//import org.apache.log4j.Logger
//import org.apache.spark.broadcast.Broadcast
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.functions.lit
//import org.apache.spark.sql.{SaveMode, SparkSession}
//import org.apache.spark.storage.StorageLevel
//import test.Utils.{DistanceTool, StringToCsv}
//
//import scala.collection.mutable.ArrayBuffer
//
//
//
///*
// @author 01401062
// @DESCRIPTION ${DESCRIPTION}
// @create 2022/8/1
//*/
//
//object TimeLimitDerminResponsibility2Online {
//
//  @transient lazy val logger: Logger = Logger.getLogger(TimeLimitDerminResponsibility2Online.getClass)
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//
//  val requestRoadConditionUrl = "http://gis-apis.int.sfcloud.local:1080/tmcgd/api/tmc/history2"
//  //  val requestRoadConditionUrl = "http://gis-int.intsit.sfdc.com.cn:1080/tmcgd/api/tmc/history2"
//  //  val multiSourcesRoadConditionUrl = "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/roadAttr?gzip=0&output=json&mask=31&ak=39681f679699410b9ecc8dbcc5c98bde&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED&swId="
//  val multiSourcesRoadConditionUrl = "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/roadAttr?gzip=0&output=json&mask=31&ak=dc894b4a3c7444b4a3505315d00b87ad&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED&swId="
//
//  // test
//  //  val multiSourcesRoadConditionUrl = "http://10.202.43.227:8170/road_attr?gzip=0&coors=1&output=json&swId="
//
//  val multiSourcesRoadConditionUrl2 = "http://gis-gw.int.sfdc.com.cn:9080/dt/api/query"
//  // test
//  // val multiSourcesRoadConditionUrl2 = "http://gis-gw.intsit.sfdc.com.cn:9080/dt/api/query"
//
//
//  //  val serviceAreaCorrectionUrl = "http://gis-int.intsit.sfdc.com.cn:1080/rp/navi/query/qRoad"
//  val serviceAreaCorrectionUrl = "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/qRoad"
//
//  val calCrossHeightsUrl = "http://10.202.116.53:7888/inspectbypassroute"
//
//
//  case class TimeMonitorStayPoint(
//                                   tl_stay_points:String,tl_index:String,tl_time_period:String,tl_durations:String,tl_road:String,tl_roadclasss:String,
//                                   tl_link:String,tl_links:String,tl_length:String,
//                                   task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,
//                                   end_dept:String,actual_run_time2:String,line_code:String,vehicle_serial:String,plan_depart_tm:String,
//                                   actual_depart_tm:String,actual_arrive_tm:String,driver_id:String,driver_name:String,start_longitude:String,start_latitude:String,
//                                   end_longitude:String,end_latitude:String,rt_dist:String,error_type:String,task_inc_day:String,carrier_name:String,
//                                   difftime_plan_actual:String,jp_swid:String,jp_time:String,jp_coords:String,jp_status:String,sum_dist:String,
//                                   t_links_union:String,toll_station:String,service:String,toll_station_linkpointinfo:String,
//                                   start_road_dist:String,end_road_dist:String,mark:String,mark2:String,mark3:String,
//                                   status:String,speed:String,events:String,events_code:String,stay_points_start_time:String,speed_diveation_value:String,
//                                   speed_diveation_ratio:String,subjective_objective_status:String,service_sw_id:String,service_start_coordinate:String,
//                                   service_end_coordinate:String,service_link_index:String,service_start_distance:String,service_end_distance:String,
//                                   service_staypoints_service_position:String,if_service:String,jp_service_swid:String,if_jp_service:String,toll_station_sw_id:String,toll_station_start_coordinate:String,
//                                   toll_station_end_coordinate:String,toll_station_link_index:String,toll_station_start_distance:String,
//                                   toll_station_end_distance:String,toll_station_road_dist:String,staypoints_toll_station_position:String,
//                                   if_toll_station:String,start_dept_radius:String,end_dept_radius:String,start_distance:String,
//                                   end_distance:String,end_in_radius:String,if_start:String,if_end_notin_radius:String,if_end_in_radius:String,
//                                   epidemic_xy1:String,epidemic_xy2:String,epidemic_orCode:String,epidemic_swids:String,epidemic_stay_event_start_distance:String,
//                                   epidemic_stay_event_end_distance:String,epidemic_index:String,if_epidemic:String,epidemic_content:String,
//                                   staypoints_epidemic_position:String,jyz_coords:String,jyz_dis:String,name_chn:String,if_jyz:String,
//                                   event_xy1:String,event_xy2:String,event_orCode:String,event_swids:String,event_stay_event_start_distance:String,
//                                   event_stay_event_end_distance:String,events_index:String,if_other_event:String,event_content:String,bypass_lineid:String,
//                                   bypass_mark:String,existlimit:String,originroadclasslist:String,problemStr:String,tollstation_link_highlow_level:String,
//                                   if_high_low_level:String,if_gaosu:String,label:String,label2:String,label3:String,
//                                   line_time:String,service_station_linkpointinfo:String,plan_run_time2:String,plan_arrive_tm:String,tl_sort_num:String,mark4:String,
//                                   guiji_lishi:String,imei_lishi:String,guiji_lishi_imei:String,lishi_max_tl_tm:String,lishi_max2_tl_tm:String,lishi_mean_speed_ins:String,
//                                   lishi_speed_ins_ls:String,lishi_speed0_ins_count:String,lishi_time_diff:String,lishi_time_diff_ratio:String, lishi_label:String,multi_road_err:String,
//                                   events_content2:String,events_eventcode:String,yongdu_time2:String,yongdu_time3:String
//                                 )
//
//
//  def getSourceRdd(spark: SparkSession, inc_day: String) = {
//
//    val sourceSql =
//      s"""
//         |select
//         |  *
//         |from
//         |  dm_gis.eta_time_monitor
//         |where
//         |  inc_day = '${inc_day}'
//         |and
//         |  tl_stay_points != ''
//       """.stripMargin
//
//    val df = spark.sql(sourceSql)
//
//    //    df.repartition(1).write.mode(SaveMode.Overwrite).option("header","true").option("delimiter","\t").csv(s"/user/01401062/upload/gis/data/20220905.csv")
//
//
//    val sourceRdd = SparkUtils.getRowToJson(df)
//
//    logger.error("输入数据量为：" + sourceRdd.count())
//
//    sourceRdd
//
//
//  }
//
//
//  /**
//    * 1.0 展开停留点
//    * @param sourceRdd
//    * @return
//    */
//  def getRejectFlatMapRdd(sourceRdd: RDD[JSONObject]) = {
//
//    val rejectFlatMapRdd = sourceRdd.flatMap(x => {
//
//      val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//      val tl_index = JSONUtils.getJsonValue(x,"tl_index","")
//      val tl_time_period = JSONUtils.getJsonValue(x,"tl_time_periods","")
//      val tl_durations = JSONUtils.getJsonValue(x,"tl_durations","")
//      val tl_road = JSONUtils.getJsonValue(x,"tl_road","")
//      val tl_roadclasss = JSONUtils.getJsonValue(x,"tl_roadclass","")
//      val tl_link = JSONUtils.getJsonValue(x,"tl_link","")
//      val tl_links = JSONUtils.getJsonValue(x,"tl_links","")
//      val tl_length = JSONUtils.getJsonValue(x,"tl_length","")
//
//
//      // TODO: 将字符串全部转换为数组 tl_stay_points、tl_index、tl_time_period、tl_durations、tl_road、tl_roadclasss、tl_link、tl_links、tl_length
//
//      val tl_stay_points_array =
//        if (StringUtils.nonEmpty(tl_stay_points)){
//          tl_stay_points.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//      val tl_index_array =
//        if (StringUtils.nonEmpty(tl_index)){
//          tl_index.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//      val tl_time_periods_array =
//        if (StringUtils.nonEmpty(tl_time_period)){
//          tl_time_period.replace("[","").replace("]","").split(",")
//        } else {
//          new Array[String](0)
//        }
//
//      val tl_durations_array =
//        if (StringUtils.nonEmpty(tl_durations)){
//          tl_durations.replace("[","").replace("]","").split(",")
//        } else {
//          new Array[String](0)
//        }
//
//      val tl_roads_array =
//        if (StringUtils.nonEmpty(tl_road)){
//          tl_road.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//      val tl_roadclasss_array =
//        if (StringUtils.nonEmpty(tl_roadclasss)){
//          tl_roadclasss.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//      val tl_link_array =
//        if (StringUtils.nonEmpty(tl_link)){
//          tl_link.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//
//      val tl_links_array =
//        if (StringUtils.nonEmpty(tl_links)){
//          tl_links.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//      val tl_length_array =
//        if (StringUtils.nonEmpty(tl_length)){
//          tl_length.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//
//      val sum_dist = JSONUtils.getJsonValue(x,"sum_dist","")
//      val sum_dist_array =
//        if (StringUtils.nonEmpty(sum_dist)){
//          sum_dist.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//
//
//      val buffer = new ArrayBuffer[JSONObject]()
//
//      if (!tl_stay_points_array.isEmpty && tl_stay_points_array.length > 0){
//
//        for (i <- (0 until(tl_stay_points_array.length))){
//
//          val json  = new JSONObject()
//          json.fluentPutAll(x)
//          val tl_stay_points = tl_stay_points_array(i)
//          val tl_index = try {tl_index_array(i).toInt} catch {case e:Exception => 0}
//          val tl_time_period = tl_time_periods_array(i)
//          val tl_durations = tl_durations_array(i)
//          val tl_road = try {tl_roads_array(i)} catch {case e:Exception => ""}
//          val tl_roadclasss = tl_roadclasss_array(i)
//          val tl_link = tl_link_array(i)
//          val tl_links = tl_links_array(i)
//          val tl_length = tl_length_array(i)
//          val start_road_dist = try {sum_dist_array(tl_index).toDouble} catch {case e:Exception => 0}
//          val end_road_dist = try {math.abs(sum_dist_array(sum_dist_array.size -1).toDouble - start_road_dist)} catch {case e:Exception => 0}
//
//          val plan_arrive_tm = JSONUtils.getJsonValue(x,"plan_arrive_tm","")
//          val plan_depart_tm = JSONUtils.getJsonValue(x,"plan_depart_tm","")
//
//          val plan_run_time2 = try {DateTimeUtil.parseFtTimeMin(plan_arrive_tm,plan_depart_tm,"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm:ss").toInt} catch {case e:Exception => 0}
//
//
//          val tl_sort_num = i
//
//          json.put("tl_stay_points",tl_stay_points)
//          json.put("tl_index",tl_index)
//          json.put("tl_time_period",tl_time_period)
//          json.put("tl_durations",tl_durations)
//          json.put("tl_road",tl_road)
//          json.put("tl_roadclasss",tl_roadclasss)
//          json.put("tl_link",tl_link)
//          json.put("tl_links",tl_links)
//          json.put("tl_length",tl_length)
//          json.put("start_road_dist",start_road_dist)
//          json.put("end_road_dist",end_road_dist)
//          json.put("tl_sort_num",tl_sort_num)
//          json.put("plan_run_time2",plan_run_time2)
//
//          buffer.append(json)
//        }
//      }
//
//      buffer
//
//    })
//
//
//    rejectFlatMapRdd
//  }
//
//
//  /**
//    * 1.1.1、1.1.2 异常停留点剔除
//    * @param rejectFlatMapRdd
//    */
//  def getCalRejectRdd1(rejectFlatMapRdd: RDD[JSONObject]) = {
//
//    val calRejectRdd1 = rejectFlatMapRdd
//      .map(x => {
//
//        val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//        val tl_link = JSONUtils.getJsonValue(x,"tl_link","")
//        val tl_index = JSONUtils.getJsonValue(x,"tl_index","")
//
//
//        // TODO: 将jp_status，jp_coords，jp_swid 转换为数组
//        val jp_status = JSONUtils.getJsonValue(x,"jp_status","")
//        val jp_coords = JSONUtils.getJsonValue(x,"jp_coords","")
//        val jp_swid = JSONUtils.getJsonValue(x,"jp_swid","")
//
//        val jp_status_array =
//          if (StringUtils.nonEmpty(jp_status)){
//            jp_status.split("\\|")
//          } else {
//            new Array[String](0)
//          }
//
//        val jp_coords_array =
//          if (StringUtils.nonEmpty(jp_coords)){
//            jp_coords.split("\\|")
//          } else {
//            new Array[String](0)
//          }
//
//        val jp_swid_array =
//          if (StringUtils.nonEmpty(jp_swid)){
//            jp_swid.split("\\|")
//          } else {
//            new Array[String](0)
//          }
//
//        // TODO: 标记mark
//        var mark = 3
//        var index = -1
//
//
//        if (!jp_coords_array.isEmpty && jp_coords_array.contains(tl_stay_points)) {
//          //找到相同的点，输出该点在jp_coords中的索引位置idx1
//          val i = jp_coords_array.indexOf(tl_stay_points)
//          index = i
//          mark = 1
//        }
//
//        if (mark == 3 && !jp_swid_array.isEmpty && jp_swid_array.contains(tl_link)) {
//          //如果在jp_coords_array未找到，用停留点对应的link即 link 字段，循环判断和jp_swid中的每个link是否相同，找到相同的link，输出该link在jp_swid中的索引位置idx2
//          index = jp_swid_array.indexOf(tl_link)
//          mark = 2
//        }
//
//        if (mark != 3 && index >= 1 && index != jp_status_array.size-1){
//
//
//          // TODO: 判断是否是第一个点、最后一个点
//          // 如果已找到索引位置，则找索引位置左右两边最近的点
//          val jp_status_array0 = if (index < jp_status_array.length) jp_status_array.slice(0,index) else new Array[String](0)
//          var stratIndex = jp_status_array0.lastIndexOf("0")
//
//          var startTag =  try {if (jp_swid_array.size >= 0 && StringUtils.nonEmpty(tl_link) && (jp_swid_array(stratIndex).equals(tl_link) ||
//            jp_swid_array(stratIndex).equals("0"))) 0 else 1} catch {case e:Exception => 1}
//
//          for ( j <- (0 until(stratIndex)).reverse if (startTag == 0)){
//            try {
//              stratIndex = if (jp_status_array0(j).equals("0")) j else stratIndex
//              startTag = if (jp_swid_array.size >= 0 && StringUtils.nonEmpty(tl_link) && (jp_swid_array(stratIndex).equals(tl_link) ||
//                jp_swid_array(stratIndex).equals("0"))) 0 else 1
//            }catch {
//              case e:Exception => startTag = 1
//            }
//          }
//
//          val jp_status_array1 = if (index + 1 < jp_status_array.length) jp_status_array.slice(index+1,jp_status_array.length) else new Array[String](0)
//          var endIndex = jp_status_array1.indexOf("0") + index
//          //        var endIndex = jp_status_array1.indexOf("0")
//
//          var endTag = try { if (jp_swid_array.size >= 0 && StringUtils.nonEmpty(tl_link) && (jp_swid_array(endIndex).equals(tl_link) ||
//            jp_swid_array(endIndex).equals("0"))) 0 else 1} catch {case e:Exception => 1}
//
//          for ( j <- ((endIndex+1) until(jp_status_array.size)) if (endTag == 0)){
//            try {
//              endIndex = if (jp_status_array(j).equals("0")) j else endIndex
//              endTag = if (jp_swid_array.size >= 0 && StringUtils.nonEmpty(tl_link) && (jp_swid_array(endIndex).equals(tl_link) ||
//                jp_swid_array(endIndex).equals("0"))) 0 else 1
//            }catch {
//              case e:Exception => startTag = 1
//            }
//          }
//
//          if (stratIndex != -1 && endIndex != -1){
//
//            val start_x = try {jp_coords_array(stratIndex).split(",")(0).toDouble} catch {case e:Exception => 0.0}
//            val start_y = try {jp_coords_array(stratIndex).split(",")(1).toDouble} catch {case e:Exception => 0.0}
//            val end_x = try {jp_coords_array(endIndex).split(",")(0).toDouble} catch {case e:Exception => 0.0}
//            val end_y = try {jp_coords_array(endIndex).split(",")(1).toDouble} catch {case e:Exception => 0.0}
//            val dist = DistanceTool.getGreatCircleDistance(start_x,start_y,end_x,end_y)
//
//            if (dist > 4000) mark = 6
//
//          }
//
//        }
//
//        x.put("mark",mark)
//
//        x
//      }).filter(x => {
//      val mark = x.getIntValue("mark")
//      mark != 6
//    })
//
//    calRejectRdd1
//
//  }
//
//
//  /**
//    * 1.1.3 剔除与linkid绑错的停留点
//    * @param calRejectRdd1
//    */
//
//  def getCalRejectRdd2(calRejectRdd1: RDD[JSONObject]) = {
//
//    val calRejectRdd2 = calRejectRdd1.map(x => {
//
//      val tl_link = JSONUtils.getJsonValue(x,"tl_link","")
//      val tl_link_array =
//        if (StringUtils.nonEmpty(tl_link)){
//          tl_link.split("_")
//        } else {
//          new Array[String](0)
//        }
//
//      var mark2 = 0
//
//      if (tl_link_array.length > 5) mark2 = 1 else if (tl_link_array.size == 0 ||  tl_link.equals("0")) mark2 = 1
//      x.put("mark2",mark2)
//      x
//    }).filter(x => {
//      val mark2 = x.getIntValue("mark2")
//      mark2 != 1
//    })
//
//    calRejectRdd2
//
//  }
//
//
//  /**
//    * 剔除起终网点距离小于2km的停留点, 剔除error_type包含4的停留点
//    * @param calRejectRdd2
//    */
//
//
//  def getCalRejectRdd3(calRejectRdd2: RDD[JSONObject]) = {
//
//    val calRejectRdd3 = calRejectRdd2.map(x => {
//
//      val start_longitude = JSONUtils.getJsonValueDouble(x,"start_longitude",0)
//      val start_latitude = JSONUtils.getJsonValueDouble(x,"start_latitude",0)
//      val end_longitude = JSONUtils.getJsonValueDouble(x,"end_longitude",0)
//      val end_latitude = JSONUtils.getJsonValueDouble(x,"end_latitude",0)
//
//      val start_end_distance = DistanceTool.getGreatCircleDistance(start_longitude,start_latitude,end_longitude,end_latitude)
//
//      var mark3 = 0
//
//      if (start_end_distance < 2000) mark3 = 1
//
//      x.put("mark3",mark3)
//      x
//    }).filter(x => {
//      val mark3 = x.getIntValue("mark3")
//      mark3 != 1
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    logger.error("calRejectRdd3的数据量为：" + calRejectRdd3.count())
//
//    val calRejectRdd4 = calRejectRdd3.map(x => {
//
//      val error_type = JSONUtils.getJsonValue(x,"error_type","")
//      var mark4 = 0
//
//      if (StringUtils.nonEmpty(error_type) && error_type.contains("4")){
//        mark4 = 1
//      }
//      x.put("mark4",mark4)
//      x
//    }).filter(x => {
//      val mark4 = x.getIntValue("mark4")
//      mark4 != 1
//    })
//
//    calRejectRdd4
//
//  }
//
//
//  def getRquestRoadCondition(x: JSONObject) = {
//
//    val tl_time_period = JSONUtils.getJsonValue(x,"tl_time_period","").split("_")(0)
//
//    val tl_time_period_timeStamp = DateTimeUtil.timeToLong(tl_time_period,"yyyy-MM-dd HH:mm:ss") / 1000
//
//    // TODO: tl_time_period 往前取5min
//    val tl_time_period_pre5 = tl_time_period_timeStamp  - 300
//    // TODO: tl_time_period 往后取5min
//    val tl_time_period_after5 = tl_time_period_timeStamp  + 300
//    // TODO: tl_time_period 往后取10min
//    val tl_time_period_after10 = tl_time_period_timeStamp  + 600
//    // TODO: tl_time_period 往后取15min
//    val tl_time_period_after15 = tl_time_period_timeStamp  + 900
//
//
//    val swid = JSONUtils.getJsonValue(x,"tl_link","")
//
//    val json = new JSONObject()
//    //    json.put("ak", "ebf48ecaa1fd436fa3d40c4600aa051f")
//    json.put("ak", "ef789d00926d46cdae8fc721608557ad")
//
//    json.put("focus", "flow,event,warn")
//
//    val tracksArray = new JSONArray()
//    val jo0 = new JSONObject()
//    jo0.put("link_id",swid)
//    jo0.put("timestamp",tl_time_period_pre5)
//    tracksArray.add(jo0)
//
//    val jo1 = new JSONObject()
//    jo1.put("link_id",swid)
//    jo1.put("timestamp",tl_time_period)
//    tracksArray.add(jo1)
//
//    val jo2 = new JSONObject()
//    jo2.put("link_id",swid)
//    jo2.put("timestamp",tl_time_period_after5)
//    tracksArray.add(jo2)
//
//    val jo3 = new JSONObject()
//    jo3.put("link_id",swid)
//    jo3.put("timestamp",tl_time_period_after10)
//    tracksArray.add(jo3)
//
//    val jo4 = new JSONObject()
//    jo4.put("link_id",swid)
//    jo4.put("timestamp",tl_time_period_after15)
//    tracksArray.add(jo4)
//
//    json.put("tracks",tracksArray)
//
//    json
//
//  }
//
//
//  def parseRoadCondition(x: JSONObject, rep: String) = {
//    val repJo = JSON.parseObject(rep)
//    val tracks = repJo.getJSONArray("tracks")
//
//    var MaxStatus = 0
//    var MaxSpeed = 0
//
//    var events_code = ""
//
//    try {
//      for (i <- (0 until(tracks.size()))){
//        val array = try {tracks.getJSONObject(i).getJSONArray("flow")}catch {case e:Exception => new JSONArray()}
//        val flow = try {array.getJSONObject(0)}catch {case e:Exception => new JSONObject()}
//        val status = JSONUtils.getJsonValueInt(flow,"status",0)
//        val speed = JSONUtils.getJsonValueInt(flow,"speed",0)
//
//        val events = try {
//          tracks.getJSONObject(i).getJSONArray("events").getJSONObject(0)
//        } catch {
//          case e: Exception => new JSONObject()
//        }
//        val limit_c = events.getString("limit_c")
//        val limit_t = events.getString("limit_t")
//        val reason_c = events.getString("reason_c")
//        val reason_t = events.getString("reason_t")
//        val events_code_new = "[" + limit_c + "," + limit_t + "," + reason_c + "," + reason_t + "]"
//        if (!events.isEmpty) {
//          events_code = events_code_new
//        }
//
//        if (status > MaxStatus) {
//          MaxStatus = status
//          MaxSpeed = speed
//        }
//      }
//    } catch {
//      case e:Exception => e.printStackTrace()
//    }
//
//
//
//    val tl_length = JSONUtils.getJsonValueInt(x,"tl_length",0)
//    val tl_durations = JSONUtils.getJsonValueInt(x,"tl_durations",0)
//
//    val stay_points_start_time = if (MaxStatus != 1 && MaxSpeed != 0) (tl_length * 0.001 / MaxSpeed)*3600 else 0
//    val speed_diveation_value = tl_durations - stay_points_start_time
//    val speed_diveation_ratio = if (speed_diveation_value != 0) speed_diveation_value/stay_points_start_time else 0
//    val subjective_objective_status = if (MaxStatus == 1 || (MaxStatus != 1 && speed_diveation_ratio >= 1)) 1 else 0
//
//    x.put("status",MaxStatus)
//    x.put("speed",MaxSpeed)
//    x.put("events_code",events_code)
//
//    x.put("stay_points_start_time",stay_points_start_time)
//    x.put("speed_diveation_value",speed_diveation_value)
//    x.put("speed_diveation_ratio",speed_diveation_ratio)
//    x.put("subjective_objective_status",subjective_objective_status)
//
//    x
//  }
//
//  /**
//    * 停留点link路况判校验接口调用返回
//    *
//    * @param json
//    */
//
//  def requestRoadConditionInterface(x:JSONObject,json:JSONObject) = {
//
//    val rep = Utils.retryPost(requestRoadConditionUrl,json)
//
//    val repJson =
//      try {
//        parseRoadCondition(x,rep)
//      } catch {
//        case e: Exception =>
//          x.put("road_con_err", e + "接口异常返回为：" + rep)
//          x.put("road_con_errInfo",rep)
//          x
//      }
//
//    repJson
//
//  }
//
//
//  /**
//    * 停留点link路口校验 调用接口与解析返回
//    * @param x
//    * @return
//    */
//
//  def calRoadCondition(x:JSONObject):JSONObject = {
//
//    val json = getRquestRoadCondition(x)
//
//    val repJson = requestRoadConditionInterface(x,json)
//
//    repJson
//
//  }
//
//
//  /**
//    * 多源路口校验1
//    * @param x
//    */
//
//
//  def multiRoadConditionInterface(x: JSONObject) = {
//
//    val tl_link = JSONUtils.getJsonValue(x, "tl_link", "")
//    val url = multiSourcesRoadConditionUrl.concat(tl_link)
//    println(url)
//    val responseStr = Utils.retryGet(url)
//    println(responseStr)
//    println("+++++++++++++++++++++++++++++++++++++++")
//    try {
//      val response = JSON.parseObject(responseStr)
//      val line = response.getJSONObject("line")
//      val box = line.getJSONObject("box")
//
//      val xmin = JSONUtils.getJsonValueDouble(box, "xmin", 0) / 3600000
//      val ymin = JSONUtils.getJsonValueDouble(box, "ymin", 0) / 3600000
//      val xmax = JSONUtils.getJsonValueDouble(box, "xmax", 0) / 3600000
//      val ymax = JSONUtils.getJsonValueDouble(box, "ymax", 0) / 3600000
//
//      val startpos = line.getJSONObject("startpos")
//      val endpos = line.getJSONObject("endpos")
//
//      val x1 = JSONUtils.getJsonValueDouble(startpos, "x", 0) / 3600000
//      val y1 = JSONUtils.getJsonValueDouble(startpos, "y", 0) / 3600000
//      val x2 = JSONUtils.getJsonValueDouble(endpos, "x", 0) / 3600000
//      val y2 = JSONUtils.getJsonValueDouble(endpos, "y", 0) / 3600000
//
//
//      var angle = 0.0
//      val dx = x2 - x1
//      val dy = y2 - y1
//      if (x2 == x1){
//        angle =  math.Pi / 2.0
//        if (y2 == y1)
//          angle = 0.0
//        else if (y2 < y1)
//          angle = 3.0 * math.Pi / 2.0
//      }
//      else if (x2 > x1 && y2 > y1)
//        angle = math.atan(dx / dy)
//      else if (x2 > x1 && y2 < y1)
//        angle = math.Pi / 2 + math.atan(-dy / dx)
//      else if (x2 < x1 && y2 < y1)
//        angle = math.Pi + math.atan(dx / dy)
//      else if (x2 < x1 && y2 > y1)
//        angle = 3.0 * math.Pi / 2.0 + math.atan(dy / -dx)
//
//      angle = angle * 180 / math.Pi
//
//      x.put("tl_xmin",xmin)
//      x.put("tl_ymin",ymin)
//      x.put("tl_xmax",xmax)
//      x.put("tl_ymax",ymax)
//      x.put("angle",angle)
//
//    } catch {
//      case e: Exception =>
//        x.put("angleerrInfo", "调用异常")
//        x
//    }
//    x
//  }
//
//
//  /**
//    * 调用320w货车轨迹点接口 解析
//    * @param x
//    * @param responseStr
//    * @return
//    */
//
//  def parseMultiRoadCondition2(x:JSONObject,responseStr: String) = {
//
//    val angle = JSONUtils.getJsonValueDouble(x,"angle",0)
//
//
//    val tl_time_period = JSONUtils.getJsonValue(x,"tl_time_period","")
//    val tl_links_array =
//      if (StringUtils.nonEmpty(tl_time_period)){
//        tl_time_period.split("_")
//      } else {
//        new Array[String](0)
//      }
//
//    val period0 = if (tl_links_array.length> 0) DateTimeUtil.timeToLong(tl_links_array(0),"yyyy-MM-dd HH:mm:ss")  else 0
//    val period1 = if (tl_links_array.length> 0) DateTimeUtil.timeToLong(tl_links_array(1),"yyyy-MM-dd HH:mm:ss")  else 0
//
//
//    val guiji_lishi = new ArrayBuffer[JSONObject]()
//
//
//    val response = JSON.parseObject(responseStr)
//    val trajectory = response.getJSONArray("trajectory")
//
//    try {
//
//      if (trajectory != null){
//
//        for (i <- (0 until (trajectory.size()))) {
//
//          val trajJson = trajectory.getJSONObject(i)
//          val info = trajJson.getJSONObject("info")
//          val bearing = info.getIntValue("bearing")
//          val timeStamp = info.getString("timeStamp").toLong
//
//          if (Math.abs(bearing - angle) < 30 && tl_links_array.length > 0 && timeStamp > period0 && timeStamp < period1) {
//            guiji_lishi.append(trajJson)
//          }
//
//        }
//                StringToCsv.stringToCsv("2022080801","",guiji_lishi.toString())
//
//        val imei_lishi = new StringBuffer()
//
//        if (guiji_lishi.size != 0){
//          val guiji_lishi_imei = guiji_lishi.toList.map(guijiJson => {
//            val imei = JSONUtils.getJsonValue(guijiJson,"imei","")
//            if (imei_lishi.length() >0 && (!imei_lishi.toString.contains(imei)))
//              imei_lishi.append("|").append(imei)
//            else if (!imei_lishi.toString.contains(imei)) imei_lishi.append(imei)
//            (imei,guijiJson)
//          }).groupBy(_._1).map(obj => {
//            val imei = obj._1
//            val buffer2 = obj._2
//
//            // TODO: 计算该imei的speed_ins、count
//            var speed_ins = 0.0
//            var count = buffer2.size
//
//            buffer2.foreach(j => {
//              val guijJson = j._2
//              val info = guijJson.getJSONObject("info")
//              val speed = JSONUtils.getJsonValueDouble(info,"speed",0)
//              speed_ins += speed
//            })
//
//            val maxJson = buffer2.map(j => {
//              val guijJson = j._2
//              val info = guijJson.getJSONObject("info")
//              val timestamp = JSONUtils.getJsonValueLong(info,"timeStamp",0)
//              (timestamp,guijJson)
//            }).maxBy(_._1)
//
//            val minJson = buffer2.map(j => {
//              val guijJson = j._2
//              val info = guijJson.getJSONObject("info")
//              val timestamp = JSONUtils.getJsonValueLong(info,"timeStamp",0)
//              (timestamp,guijJson)
//            }).minBy(_._1)
//
//            // TODO: 计算时间差，距离，speed_eta
//            val timeDiff = (maxJson._1 - minJson._1) / 1000.0
//
//            val x1 = JSONUtils.getJsonValueDouble(maxJson._2,"lng",0)
//            val y1 = JSONUtils.getJsonValueDouble(maxJson._2,"lat",0)
//
//            val x2 = JSONUtils.getJsonValueDouble(minJson._2,"lng",0)
//            val y2 = JSONUtils.getJsonValueDouble(minJson._2,"lat",0)
//
//            val dist = DistanceTool.getGreatCircleDistance(x1,y1,x2,y2)
//
//            val speed_eta = if (timeDiff != 0) (dist / 1000) / (timeDiff / 3600) else 0
//
//            val jo = new JSONObject()
//
//            jo.put("speed_ins",(speed_ins / count) * 3.6)
//            jo.put("count",count)
//            jo.put("timeDiff",timeDiff)
//            jo.put("dist",dist)
//            jo.put("speed_eta",speed_eta)
//            jo.put("imei",imei)
//
//            jo
//          })
//
//
//          val guiji_lishi_speed0 = guiji_lishi_imei.toList.filter(JSONUtils.getJsonValueDouble(_,"speed_eta",0) < 1)
//
//          val lishi_max_tl_tm = JSONUtils.getJsonValueDouble(guiji_lishi_speed0.maxBy(JSONUtils.getJsonValueDouble(_,"timeDiff",0)),"timeDiff",0)
//          val lishi_max2_tl_tm = try {guiji_lishi_speed0.sortBy(JSONUtils.getJsonValueDouble(_,"timeDiff",0)).reverse.slice(1,2)
//            .map(JSONUtils.getJsonValueDouble(_,"timeDiff",0)).head} catch {case e:Exception => 0}
//
//          var speed_ins_all = 0.0
//          val lishi_speed_ins_ls = new StringBuffer()
//
//          guiji_lishi_imei.toList.map(x => {
//            val speed_ins = JSONUtils.getJsonValueDouble(x,"speed_ins",0)
//            if (lishi_speed_ins_ls.length() >0) lishi_speed_ins_ls.append("|").append(speed_ins) else lishi_speed_ins_ls.append(speed_ins)
//            speed_ins_all += speed_ins
//          })
//
//          val lishi_speed_ins_ls_new = try {lishi_speed_ins_ls.toString.split("\\|").toList.sortBy(obj => obj.toDouble).mkString("|") } catch {case e:Exception => ""}
//
//          val lishi_mean_speed_ins = speed_ins_all / guiji_lishi_imei.size
//
//          val lishi_speed0_ins_count =  guiji_lishi_imei.toList.filter(JSONUtils.getJsonValueDouble(_,"speed_ins",0) == 0).size
//
//          val tl_length = JSONUtils.getJsonValueInt(x,"tl_length",0)
//          val tl_durations = JSONUtils.getJsonValueInt(x,"tl_durations",0)
//
//          val lishi_time_diff = if (lishi_mean_speed_ins != 0) ((tl_length * 0.001) / (lishi_mean_speed_ins) * 3600) - tl_durations else 0
//
//          val lishi_time_diff_ratio = if (tl_durations != 0) lishi_time_diff / tl_durations else 0
//
//          val imei_lishi_size = imei_lishi.toString.split("\\|").size
//
//
//          val lishi_label =
//            if (imei_lishi_size == 0)
//              "无车辆经过"
//            else if (tl_length == 0)
//              "异常"
//            else if (lishi_max2_tl_tm > 300)
//              "平均时长判断客观"
//            else if (imei_lishi_size > 0 && imei_lishi_size <= 3)
//              "车辆频次过低"
//            else if (imei_lishi_size > 3 && lishi_speed0_ins_count>3)
//              "平均时长判断客观"
//            else if (imei_lishi_size >3 && (lishi_mean_speed_ins>0 && lishi_time_diff > -600 || lishi_time_diff_ratio> -0.4))
//              "平均时长判断客观"
//            else if (imei_lishi_size >3 && (lishi_mean_speed_ins>0 && lishi_time_diff <= -600 || lishi_time_diff_ratio <= -0.4))
//              "平均时长判断主观"
//            else ""
//
//          x.put("guiji_lishi", guiji_lishi.toList.toString())
//          x.put("imei_lishi",imei_lishi.toString)
//          x.put("guiji_lishi_imei",guiji_lishi_imei.toString())
//          x.put("lishi_max_tl_tm",lishi_max_tl_tm)
//          x.put("lishi_max2_tl_tm",lishi_max2_tl_tm)
//          x.put("lishi_mean_speed_ins",lishi_mean_speed_ins)
//          x.put("lishi_speed_ins_ls",lishi_speed_ins_ls_new)
//          x.put("lishi_speed0_ins_count",lishi_speed0_ins_count)
//          x.put("lishi_time_diff",lishi_time_diff)
//          x.put("lishi_time_diff_ratio",lishi_time_diff_ratio)
//          x.put("lishi_label",lishi_label)
//
//        }
//
//      }
//      x
//    }catch {
//      case e:Exception =>
//        x.put("err",responseStr)
//        x
//    }
//    x
//  }
//
//
//
//
//
//
//
//  /**
//    * 多源路口校验2
//    *
//    * @param x
//    * @return
//    */
//
//  def multiRoadConditionInterface2(x: JSONObject) = {
//
//    val x1 = JSONUtils.getJsonValueDouble(x, "tl_xmin", 0)
//    val y1 = JSONUtils.getJsonValueDouble(x, "tl_ymin", 0)
//    val x2 = JSONUtils.getJsonValueDouble(x, "tl_xmax", 0)
//    val y2 = JSONUtils.getJsonValueDouble(x, "tl_ymax", 0)
//
//
//    val tl_time_period = JSONUtils.getJsonValue(x, "tl_time_period", "")
//    val tile_version = if (tl_time_period.size > 10) tl_time_period.substring(0,10).replace("-","") else ""
//
//    val tl_links_array =
//      if (StringUtils.nonEmpty(tl_time_period)){
//        tl_time_period.split("_")
//      } else {
//        new Array[String](0)
//      }
//
//    val start_time = try {if (tl_links_array.length> 1) DateTimeUtil.transformDateFormat(tl_links_array(0),"yyyy-MM-dd HH:mm:ss","HHmmss") else "000000"} catch {case e:Exception => "000000"}
//    val end_time = try {if (tl_links_array.length> 1) DateTimeUtil.transformDateFormat(tl_links_array(1),"yyyy-MM-dd HH:mm:ss","HHmmss") else "000000"} catch {case e:Exception => "000000"}
//
//    val ori_bearing = JSONUtils.getJsonValueDouble(x, "angle", 0).toInt
//
//    val json = new JSONObject()
//    json.put("tile_version",tile_version)
//    json.put("data_id",26)
//    val bbox = new JSONArray()
//    val jo = new JSONObject()
//    jo.put("start_time",start_time)
//    jo.put("end_time",end_time)
//    jo.put("ori_bearing",ori_bearing)
//    jo.put("angle",30)
//    jo.put("minx",x1)
//    jo.put("miny",y1)
//    jo.put("maxx",x2)
//    jo.put("maxy",y2)
//    bbox.add(jo)
//    json.put("bbox",bbox)
//
//    val responseStr = try {Utils.retryPost320Tracks(multiSourcesRoadConditionUrl2,json)} catch {case e:Exception => "调用异常"}
//
//    val requestJson = try {
//      parseMultiRoadCondition2(x,responseStr)
//    } catch {
//      case e: Exception =>
//        x.put("MultiRoadErrInfo", "response为： " + responseStr)
//        x
//    }
//
//    requestJson
//  }
//
//
//  /**
//    * 多源link路口校验 调用接口与解析返回
//    *
//    * @param x
//    * @return
//    */
//
//  def calMultiRoadCondition(x:JSONObject):JSONObject = {
//
//    val json = multiRoadConditionInterface(x)
//
//    val repJson = multiRoadConditionInterface2(json)
//
//    repJson
//
//  }
//
//
//
//  /**
//    * 1.1.3调用接口，并匹配events
//    * @param calRejectRdd3
//    * @param gdEventMap
//    * @return
//    */
//
//  def getRoadCondition(calRejectRdd3: RDD[JSONObject],gdEventMap: Broadcast[util.HashMap[String, String]]) = {
//
//    val limitMin = 800
//    val requestRdd = SparkUtils.akLimitMultiThreadRdd(calRejectRdd3)(calRoadCondition)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    val addEventRdd =  requestRdd.map(x =>{
//
//      val events_code = JSONUtils.getJsonValue(x,"events_code","")
//
//      val events = gdEventMap.value.getOrDefault(events_code,"")
//
//      x.put("events",events)
//
//      x
//
//    }).repartition(5)
//
//    addEventRdd
//  }
//
//
//  /**
//    * 调用link相关信息接口 调用320w货车轨迹点接口
//    * @param roadConditionRdd
//    */
//
//  def multiSourcesRoadConditionCheck(roadConditionRdd: RDD[JSONObject]) = {
//
//    val limitMin = 5000
//
//    val multiSourcesRoadConditioRdd = SparkUtils.akLimitMultiThreadRdd(roadConditionRdd)(calMultiRoadCondition)(limitMin).repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("multiSourcesRoadConditioRdd的数据量为：" + multiSourcesRoadConditioRdd.count())
//
//    multiSourcesRoadConditioRdd
//  }
//
//
//  // TODO: 计算流程1 拆分停留点维度
//
//  def getRoadCondition2(spark: SparkSession) = {
//
//    val df = spark.read.format("csv").option("header", "true")
//      .option("delimiter","\t").csv("d:\\user\\01401062\\桌面\\20220905.csv")
//
//    val sourceRdd = SparkUtils.getRowToJson(df)
//    sourceRdd.take(2).foreach(println(_))
//    sourceRdd
//
//  }
//
//  def rejectStayPoints(spark:SparkSession, sourceRdd: RDD[JSONObject]) = {
//
//    // TODO: 展开停留点
//    val rejectFlatMapRdd = getRejectFlatMapRdd(sourceRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("rejectFlatMapRdd的数据量为：" + rejectFlatMapRdd.count())
//    //    rejectFlatMapRdd.take(2).foreach(println(_))
//    // TODO: 剔除扯线异常停留点
//    val calRejectRdd1 = getCalRejectRdd1(rejectFlatMapRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("calRejectRdd1的数据量为：" + calRejectRdd1.count())
//    //    calRejectRdd1.take(2).foreach(println(_))
//    rejectFlatMapRdd.unpersist()
//    // TODO: 剔除与linkid绑错的停留点
//
//    val calRejectRdd2 = getCalRejectRdd2(calRejectRdd1).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("calRejectRdd2的数据量为：" + calRejectRdd2.count())
//    calRejectRdd1.unpersist()
//
//    // TODO: 剔除起终网点距离小于2km的停留点 && 剔除error_type包含4的停留点
//    val calRejectRdd3 = getCalRejectRdd3(calRejectRdd2).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("calRejectRdd4的数据量为：" + calRejectRdd3.count())
//    calRejectRdd2.unpersist()
//
//    // TODO: 停留点link路况校验
//    val broadcastGdMap = spark.sparkContext.broadcast(GetGdEventMap.getMap())
//    val roadConditionRdd = getRoadCondition(calRejectRdd3,broadcastGdMap)
//
//    logger.error("roadConditionRdd的数据量为：" + roadConditionRdd.count())
//    calRejectRdd3.unpersist()
//
//    //    roadConditionRdd
//    //    val roadConditionRdd2 = getRoadCondition2(spark)
//    //     TODO: 历史轨迹多源路况再次校验
//    val multiSourcesRoadConditionCheckRdd = multiSourcesRoadConditionCheck(roadConditionRdd)
//
//    multiSourcesRoadConditionCheckRdd
//  }
//
//
//  /**
//    * 计算服务区停留
//    * @param rejectStayRdd
//    * @return
//    */
//
//  def getServiceAreaIdentify(rejectStayRdd: RDD[JSONObject]) = {
//
//    val serviceAreaIdentifyRdd = rejectStayRdd.map(x => {
//
//
//      val service = JSONUtils.getJsonValue(x,"service","")
//
//      val service_station_linkpointinfo = JSONUtils.getJsonValue(x,"service_station_linkpointinfo","")
//
//      val jp_swid = JSONUtils.getJsonValue(x,"jp_swid","")
//
//      val tl_link = JSONUtils.getJsonValue(x,"tl_link","")
//      val tl_index = JSONUtils.getJsonValueInt(x,"tl_index",-1)
//
//
//      val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//
//      val service_station_linkpointinfo_array =
//        if (StringUtils.nonEmpty(service_station_linkpointinfo)){
//          service_station_linkpointinfo.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//      val service_array =
//        if (StringUtils.nonEmpty(service)){
//          service.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//
//
//      val stay_point_x = tl_stay_points.split(",")(0).toDouble
//      val stay_point_y = tl_stay_points.split(",")(1).toDouble
//
//
//      var sw_id = ""
//
//      var start_coordinate = (0.0,0.0)
//      var end_coordinate = (0.0,0.0)
//
//      var minDist = 1000000000.0
//
//      var link_index = -1
//      var start_distance = 99999999.0
//      var end_distance = 99999999.0
//
//
//
//      for (i <- (0 until(service_station_linkpointinfo_array.size))){
//
//        val points = service_station_linkpointinfo_array(i).split(";")
//
//        val point_start = points(0).split(",")
//        val point_start_x = point_start(0).toDouble
//        val point_start_y = point_start(1).toDouble
//
//        val point_end = points(1).split(",")
//        val point_end_x = point_end(0).toDouble
//        val point_end_y = point_end(1).toDouble
//
//        val dist_start = DistanceTool.getGreatCircleDistance(stay_point_x,stay_point_y,point_start_x,point_start_y)
//        val dist_end = DistanceTool.getGreatCircleDistance(stay_point_x,stay_point_y,point_end_x,point_end_y)
//
//        val dist = Math.min(dist_start,dist_end)
//
//        if (dist < 1000){
//          if(dist <= minDist){
//            sw_id = service_array(i)
//            minDist = dist
//            start_coordinate = (point_start_x,point_start_y)
//            end_coordinate = (point_end_x,point_end_y)
//            start_distance = dist_start
//            end_distance = dist_end
//          }
//        }
//      }
//
//
//      val jp_swid_array =
//        if (StringUtils.nonEmpty(jp_swid)){
//          jp_swid.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//      for (i <- (0 until(jp_swid_array.size))){
//        if (StringUtils.nonEmpty(sw_id) && sw_id.equals(jp_swid_array(i))){
//          link_index = i
//        }
//      }
//
//
//      val staypoints_service_position =
//        if (StringUtils.nonEmpty(sw_id) && sw_id.equals(tl_link)){
//          3
//        } else if (link_index >= tl_index && (start_distance <= 1000 || end_distance <= 1000)){
//          1
//        } else if (link_index < tl_index  && (start_distance <= 450 || end_distance <= 450)){
//          2
//        } else {
//          -1
//        }
//
//      val if_service = if (start_distance != 0 && staypoints_service_position != -1) 1 else 0
//
//
//
//      x.put("service_sw_id",sw_id)
//      x.put("service_start_coordinate",start_coordinate._1.toString() + "," + start_coordinate._2.toString)
//      x.put("service_end_coordinate",end_coordinate._1.toString() + "," + end_coordinate._2.toString)
//      x.put("service_link_index",link_index)
//      x.put("service_start_distance",start_distance)
//      x.put("service_end_distance",end_distance)
//      x.put("service_staypoints_service_position",staypoints_service_position)
//      x.put("if_service",if_service)
//
//      x
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    logger.error("serviceAreaIdentifyRdd的数据量为：" + serviceAreaIdentifyRdd.count())
//    serviceAreaIdentifyRdd
//
//  }
//
//
//
//  def calRectangle(x:Double,y:Double) ={
//
//    val dis = 500.0
//    val r = 6371000
//
//    var dlng = 2 * math.asin(math.sin(dis / (2 * r)) / math.cos(x * math.Pi / 180))
//    //角度转为弧度
//    dlng = dlng * 180 / math.Pi
//    var dlat = dis / r
//    dlat = dlat * 180 / math.Pi
//    val x1 = x - dlat
//    val x2 = x + dlat
//    val y1 = y - dlng
//    val y2 = y + dlng
//
//    (x1,y1,x2,y2)
//  }
//
//
//  /**
//    * 拼接请求
//    * @param x
//    */
//
//  def getRquestServiceAreaCorrection(x: JSONObject) = {
//
//    val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//    val stay_point_x = tl_stay_points.split(",")(0).toDouble
//    val stay_point_y = tl_stay_points.split(",")(1).toDouble
//
//    val (x1,y1,x2,y2) = calRectangle(stay_point_x,stay_point_y)
//
//    val jo = new JSONObject()
//
//    // TODO: 测试ak
//    //    jo.put("ak","12fe501477bc44e49cbbe61a6c1d8866")
//    // TODO: 线上ak
//    //    jo.put("ak","39681f679699410b9ecc8dbcc5c98bde")
//    jo.put("ak","dc894b4a3c7444b4a3505315d00b87ad")
//
//    jo.put("x1",x1)
//    jo.put("y1",y1)
//    jo.put("x2",x2)
//    jo.put("y2",y2)
//    jo.put("FC",5)
//    jo.put("toll",0)
//    jo.put("inner",0)
//    jo.put("furniture",0)
//    jo.put("fw2",0)
//    jo.put("poi",0)
//    jo.put("exprIndex",-1)
//    jo.put("mask",35)
//    jo.put("output","json")
//    jo.put("gzip",0)
//    // TODO: 测试token
//    //    jo.put("roadAttrToken","000011112222333344445555666677778888")
//    // TODO: 线上token
//    jo.put("roadAttrToken","6134FAA5B6B6ED55E87EA116466734ED")
//
//    val responseStr = Utils.retryPost(serviceAreaCorrectionUrl,jo)
//
//
//    val jp_service_swid=
//      try {
//        parseServiceAreaCorrection(responseStr)
//      } catch {
//        case e: Exception =>
//          e.toString
//      }
//
//    val if_service = JSONUtils.getJsonValueInt(x,"if_service",0)
//
//    val if_jp_service = if (if_service == 0 && StringUtils.nonEmpty(jp_service_swid.toString) && !jp_service_swid.contains("Exception")) 1 else 0
//
//
//    x.put("jp_service_swid",jp_service_swid)
//    x.put("if_jp_service",if_jp_service)
//
//    x
//
//  }
//
//  def parseServiceAreaCorrection(responseStr :String) = {
//
//    val request = JSON.parseObject(responseStr)
//
//    val lines = request.getJSONArray("lines")
//
//    val jp_service_swid = new StringBuffer()
//
//
//    for (i <- (0 until(lines.size()))){
//
//      val formway = JSONUtils.getJsonValueInt(lines.getJSONObject(i),"formway",0)
//      val swID = JSONUtils.getJsonValue(lines.getJSONObject(i),"swID","")
//
//      if (formway == 5) {
//        if (jp_service_swid.toString.size != 0){
//          jp_service_swid.append("|").append(swID)
//        }else {
//          jp_service_swid.append(swID)
//        }
//      }
//    }
//
//
//    jp_service_swid.toString
//  }
//
//  /**
//    * 停留点link路口校验 调用接口与解析返回
//    *
//    * @param x
//    * @return
//    */
//
//  def calServiceAreaCorrection(x:JSONObject):JSONObject = {
//
//    // 输入拼接 请求接口 返回解析
//    val repJson = getRquestServiceAreaCorrection(x)
//
//    repJson
//
//  }
//
//
//  // TODO: 服务区停留纠偏
//  def getServiceAreaCorrection(serviceAreaIdentifyRdd: RDD[JSONObject]) = {
//
//    val limitMin = 5000
//    val requestRdd = SparkUtils.akLimitMultiThreadRdd(serviceAreaIdentifyRdd)(calServiceAreaCorrection)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("requestRdd的数据量为：" + requestRdd.count())
//    requestRdd
//  }
//
//
//  // TODO: 收费站停留识别
//  def getTollStation(serviceAreaCorrectionRdd: RDD[JSONObject]) = {
//
//    val tollStationRdd = serviceAreaCorrectionRdd.map(x => {
//      val tl_link = JSONUtils.getJsonValue(x,"tl_link","")
//      val tl_index = JSONUtils.getJsonValueInt(x,"tl_index",0)
//      //123.575517,41.741448
//      val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//
//      val toll_station_linkpointinfo = JSONUtils.getJsonValue(x,"toll_station_linkpointinfo","")
//      val toll_station = JSONUtils.getJsonValue(x,"toll_station","")
//
//      //114.949340,38.038151;114.948612,38.038184|118.079888,39.507061;118.081255,39.507482
//      val toll_station_linkpointinfo_array =
//        if (StringUtils.nonEmpty(toll_station_linkpointinfo)){
//          toll_station_linkpointinfo.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//      val toll_station_array =
//        if (StringUtils.nonEmpty(toll_station)){
//          toll_station.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//
//      // TODO: 获取停留点
//      val stay_point_x = try {tl_stay_points.split(",")(0).toDouble} catch {case e:Exception => 0.0}
//      val stay_point_y = try {tl_stay_points.split(",")(1).toDouble} catch {case e:Exception => 0.0}
//
//
//
//      // TODO: 计算sw_id  start_coordinate end_coordinate link_index start_distance end_distance toll_station_road_dist staypoints_toll_station_position if_toll_station
//
//      var sw_id = ""
//      var start_coordinate = (0.0,0.0)
//      var end_coordinate = (0.0,0.0)
//
//      var minDist = 1000000000.0
//
//      var link_index = 0
//      var start_distance = 9999999.0
//      var end_distance = 9999999.0
//
//      for (i <- (0 until(toll_station_linkpointinfo_array.size))) {
//
//        val points = toll_station_linkpointinfo_array(i).split(";")
//        val point_start = points(0).split(",")
//        val point_start_x = point_start(0).toDouble
//        val point_start_y = point_start(1).toDouble
//
//        val point_end = points(1).split(",")
//        val point_end_x = point_end(0).toDouble
//        val point_end_y = point_end(1).toDouble
//
//        val dist_start = DistanceTool.getGreatCircleDistance(stay_point_x,stay_point_y,point_start_x,point_start_y)
//        val dist_end = DistanceTool.getGreatCircleDistance(stay_point_x,stay_point_y,point_end_x,point_end_y)
//
//        val dist = Math.min(dist_start,dist_end)
//
//        if (dist < 600 && minDist > dist){
//          minDist = dist
//          sw_id = toll_station_array(i)
//          start_coordinate = (point_start_x,point_start_y)
//          end_coordinate = (point_end_x,point_end_y)
//          start_distance = dist_start
//          end_distance = dist_end
//        }
//      }
//
//      val jp_swid = JSONUtils.getJsonValue(x,"jp_swid","")
//      val sum_dist = JSONUtils.getJsonValue(x,"sum_dist","")
//
//
//      val jp_swid_array =
//        if (StringUtils.nonEmpty(jp_swid)){
//          jp_swid.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//
//
//      for (i <- (0 until(jp_swid_array.size))){
//        if (StringUtils.nonEmpty(sw_id) && sw_id.equals(jp_swid_array(i)) && link_index == 0){
//          link_index = i
//        }
//      }
//
//      // TODO: 计算sum_dist
//      val sum_dist_array =
//        if (StringUtils.nonEmpty(sum_dist)){
//          sum_dist.split("\\|")
//        } else {
//          new Array[String](0)
//        }
//
//
//      val toll_station_road_dist = Math.abs(sum_dist_array(tl_index).toDouble - sum_dist_array(link_index).toDouble)
//
//      val staypoints_toll_station_position =
//        if (StringUtils.nonEmpty(sw_id) && sw_id.equals(tl_link)){
//          3
//        } else if (link_index >= tl_index && (start_distance <= 600 || end_distance <= 600)){
//          1
//        } else if (link_index < tl_index && (start_distance <= 400 || end_distance <= 400)){
//          2
//        } else {
//          -1
//        }
//
//      val start_road_dist = JSONUtils.getJsonValueDouble(x,"start_road_dist",0)
//      val end_road_dist = JSONUtils.getJsonValueDouble(x,"end_road_dist",0)
//
//      val if_toll_station =
//        if (start_distance != 0 && start_road_dist < toll_station_road_dist
//          && toll_station_road_dist > 600 && staypoints_toll_station_position != -1)
//          0
//        else if (start_distance != 0 && end_road_dist < toll_station_road_dist
//          && toll_station_road_dist > 600 && staypoints_toll_station_position != -1)
//          0
//        else if (start_distance != 0  && staypoints_toll_station_position != -1)
//          1
//        else 0
//
//
//
//      x.put("toll_station_sw_id",sw_id)
//      x.put("toll_station_start_coordinate",start_coordinate._1.toString + "," +  start_coordinate._2.toString)
//      x.put("toll_station_end_coordinate",end_coordinate._1.toString + "," +  end_coordinate._2.toString)
//      x.put("toll_station_link_index",link_index)
//      x.put("toll_station_start_distance",start_distance)
//      x.put("toll_station_end_distance",end_distance)
//      x.put("toll_station_road_dist",toll_station_road_dist)
//
//      x.put("staypoints_toll_station_position",staypoints_toll_station_position)
//      x.put("if_toll_station",if_toll_station)
//
//      x
//
//    })
//
//    tollStationRdd
//
//  }
//
//  /**
//    * 获取电子围栏数据
//    * @param spark
//    * @param inc_day
//    * @return
//    */
//
//  def getElectricFence(spark: SparkSession, inc_day: String) = {
//
//
//    val sql =
//      s"""
//         |select
//         |  zone_code,etc_fence_distance
//         |from
//         |  dm_gis.tt_rs_vehicle_common_cfg
//       """.stripMargin
//
//    val map = spark.sql(sql).rdd.map(x => {
//      val zone_code = x.getString(0)
//      val etc_fence_distance = try {x.getString(1).toInt} catch {case e:Exception => 0}
//      (zone_code,etc_fence_distance)
//    }).collectAsMap()
//
//    val radiusMapBc = spark.sparkContext.broadcast(map)
//
//    radiusMapBc
//  }
//
//  def calStartEndDeptIndentify(radiusMapBc:Broadcast[collection.Map[String, Int]],tollStationRdd: RDD[JSONObject]) = {
//
//    val startEndDeptIndentifyRdd = tollStationRdd.map(x => {
//      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
//      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
//
//      val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//
//      val stay_point_x = tl_stay_points.split(",")(0).toDouble
//      val stay_point_y = tl_stay_points.split(",")(1).toDouble
//
//      val start_dept_radius = radiusMapBc.value.getOrElse(start_dept,0)
//      val end_dept_radius = radiusMapBc.value.getOrElse(end_dept,0)
//
//      val start_longitude = JSONUtils.getJsonValueDouble(x,"start_longitude",0)
//      val start_latitude = JSONUtils.getJsonValueDouble(x,"start_latitude",0)
//
//      val end_longitude = JSONUtils.getJsonValueDouble(x,"end_longitude",0)
//      val end_latitude = JSONUtils.getJsonValueDouble(x,"end_latitude",0)
//
//      val dist1 = DistanceTool.getGreatCircleDistance(stay_point_x,stay_point_y,start_longitude,start_latitude)
//      val dist2 = DistanceTool.getGreatCircleDistance(stay_point_x,stay_point_y,end_longitude,end_latitude)
//
//      val start_distance = if (dist1 < start_dept_radius) dist1 else 999999
//      val end_distance = if (dist2 <= 1700) dist2 else 999999
//
//      val end_in_radius = if (end_distance < end_dept_radius) "是" else "否"
//
//      val if_start = if (start_distance != 999999 ) 1 else 0
//      val if_end_notin_radius = if (end_distance != 999999  && "否".equals(end_in_radius)) 1 else 0
//      val if_end_in_radius = if (end_distance != 999999 && "是".equals(end_in_radius)) 1 else 0
//
//
//      x.put("start_dept_radius",start_dept_radius)
//      x.put("end_dept_radius",end_dept_radius)
//      x.put("start_distance",start_distance)
//      x.put("end_distance",end_distance)
//      x.put("end_in_radius",end_in_radius)
//      x.put("if_start",if_start)
//      x.put("if_end_notin_radius",if_end_notin_radius)
//      x.put("if_end_in_radius",if_end_in_radius)
//
//      x
//    })
//
//    startEndDeptIndentifyRdd
//
//  }
//
//  /**
//    * 获取起终点停留识别
//    */
//  def getStartEndDeptIndentify(spark:SparkSession,tollStationRdd: RDD[JSONObject],inc_day:String) = {
//
//    // 获取电子围栏数据
//    val radiusMapBc = getElectricFence(spark,inc_day)
//
//    // 判断起终点停留
//    val startEndDeptIndentifyRdd = calStartEndDeptIndentify(radiusMapBc,tollStationRdd)
//
//
//    startEndDeptIndentifyRdd
//
//  }
//
//
//  /**
//    * 疫情停留识别判断
//    * @param startEndDeptIndentifyRdd
//    */
//
//  def getEpidemicIndentify(startEndDeptIndentifyRdd: RDD[JSONObject]) = {
//
//    val epidemicIndentifyRdd = startEndDeptIndentifyRdd.map(x => {
//
//      val rt_event_info_str = try {JSONUtils.getJsonValue(x,"rt_event_info","")
//        .replaceAll("\\{\"","{'")
//        .replaceAll("\":\"", "':'")
//        .replaceAll("\",\"", "','")
//        .replaceAll("\":", "':")
//        .replaceAll(",\"", ",'")
//        .replaceAll("\"\\}", "'}")
//        .replaceAll("\"", "")
//        .replaceAll("'", "\"")
//        .replaceAll("", "")
//        .replaceAll("\\\\", "?")
//      } catch {case e:Exception => ""}
//      val rt_event_info = try {JSON.parseArray(rt_event_info_str)} catch {case e:Exception => new JSONArray()}
//
//      val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//      val tl_link = JSONUtils.getJsonValue(x,"tl_link","")
//      val tl_index = JSONUtils.getJsonValueInt(x,"tl_index",0)
//
//
//      val stay_point_x = try {tl_stay_points.split(",")(0).toDouble} catch {case e:Exception => 0.0}
//      val stay_point_y = try {tl_stay_points.split(",")(1).toDouble} catch {case e:Exception => 0.0}
//
//
//
//      var minDist = 1000000000.0
//
//      // TODO: 计算停留点
//      //      var events_fanhui_epidemic = -1.0
//
//      var points = ""
//      var orCode = ""
//      var swids = ""
//      var stay_event_start_distance = 9999999.0
//      var stay_event_end_distance = 9999999.0
//      var events_index = 0
//      var content = ""
//
//      var if_epidemic = 0
//      var staypoints_epidemic_position = -1
//
//      try {
//        for (i <- (0 until (rt_event_info.size()))) {
//          val event_json = try {rt_event_info.getJSONObject(i)} catch {case e:Exception => new JSONObject()}
//          val event_orCode = try{JSONUtils.getJsonValue(event_json, "event_orCode", "")} catch {case e:Exception => ""}
//
//          if (StringUtils.nonEmpty(event_orCode) && ("0,0,6,16".equals(event_orCode) || "1,1,6,16".equals(event_orCode))) {
//
//            //        event_xy2 : "115.375890,37.998103"
//
//            val event_xy1 = JSONUtils.getJsonValue(event_json, "event_xy1", "")
//            val event_xy2 = JSONUtils.getJsonValue(event_json, "event_xy2", "")
//            //        event_orCode : "0,0,200,201"
//            //        event_swids : "9488724213280"
//            val event_swids = JSONUtils.getJsonValue(event_json, "event_swids", "")
//            val event_content = JSONUtils.getJsonValue(event_json, "event_content", "")
//
//            val event_x1 = event_xy1.split(",")(0).toDouble
//            val event_y1 = event_xy1.split(",")(1).toDouble
//            val event_x2 = event_xy2.split(",")(0).toDouble
//            val event_y2 = event_xy2.split(",")(1).toDouble
//
//            val dist1 = DistanceTool.getGreatCircleDistance(stay_point_x, stay_point_y, event_x1, event_y1)
//            val dist2 = DistanceTool.getGreatCircleDistance(stay_point_x, stay_point_y, event_x2, event_y2)
//
//            if (dist1 < 4000 || dist2 < 4000) {
//              points = event_xy2
//              orCode = event_orCode
//              swids = event_swids
//              stay_event_start_distance = dist1
//              stay_event_end_distance = dist2
//              content = event_content
//            }
//
//
//            var events_index = 0
//
//            val jp_swid = JSONUtils.getJsonValue(x, "jp_swid", "")
//
//            val jp_swid_array =
//              if (StringUtils.nonEmpty(jp_swid)) {
//                jp_swid.split("\\|")
//              } else {
//                new Array[String](0)
//              }
//
//
//            var flag = 0
//            for (i <- (0 until (jp_swid_array.size)) if (flag == 0)) {
//              if (StringUtils.nonEmpty(swids) && swids.equals(jp_swid_array(i))) {
//                flag = 1
//                events_index = i
//              }
//            }
//
//            staypoints_epidemic_position =
//              if (StringUtils.nonEmpty(swids) && swids.equals(tl_link)) {
//                3
//              } else if (events_index >= tl_index && (stay_event_start_distance <= 4000 || stay_event_end_distance <= 4000)) {
//                1
//              } else if (events_index < tl_index && (stay_event_start_distance <= 1500 || stay_event_end_distance <= 1500)) {
//                2
//              } else {
//                -1
//              }
//
//            if_epidemic =
//              if (stay_event_start_distance != -1 && staypoints_epidemic_position != -1)
//                1
//              else if (stay_event_start_distance == -1 && StringUtils.nonEmpty(event_orCode))
//                1
//              else
//                0
//
//            x.put("epidemic_xy1", event_xy1)
//            x.put("epidemic_xy2", event_xy2)
//            x.put("epidemic_orCode", orCode)
//            x.put("epidemic_swids", swids)
//            x.put("epidemic_stay_event_start_distance", stay_event_start_distance)
//            x.put("epidemic_stay_event_end_distance", stay_event_end_distance)
//            x.put("epidemic_index", events_index)
//            x.put("epidemic_content", content)
//
//          }
//        }
//      }catch {
//        case e:Exception => e.printStackTrace()
//      }
//      x.put("if_epidemic",if_epidemic)
//      x.put("staypoints_epidemic_position", staypoints_epidemic_position)
//
//      x
//    })
//
//    epidemicIndentifyRdd
//
//  }
//
//  /**
//    * 加油站停留识别
//    *
//    * @param epidemicIndentifyRdd
//    */
//
//  def getFillingStation(spark: SparkSession, epidemicIndentifyRdd: RDD[JSONObject], inc_day: String) = {
//
//    val fillingPointDf = spark.read.format("csv").option("header", "true").option("delimiter","\t").csv("/user/01401062/upload/gis/data/eta/fillGasolineStation2.csv")
//      .rdd.map(x => {
//      val index = x.getString(0)
//      val name_chn = x.getString(1)
//      val x_coord = x.getString(2)
//      val y_coord = x.getString(3)
//      val x_coords = x_coord.toDouble
//      val y_coords = y_coord.toDouble
//      val point_name = index + "_" + name_chn
//      (point_name,x_coords,y_coords)
//    }).collect()
//
//    val fillingList = spark.sparkContext.broadcast(fillingPointDf)
//
//    //    // 将加油站建立为rtree
//    //    var tree:RTree[String,Point] = RTree.star().maxChildren(6).create()
//    //
//    //    fillingPointDf.rdd.foreach(x => {
//    //      val index = x.getString(0)
//    //      val name_chn = x.getString(1)
//    //      val x_coord = x.getDouble(2)
//    //      val y_coord = x.getDouble(3)
//    //
//    //      val point_name = index + "_" + name_chn
//    //
//    //      tree = tree.add(point_name, Geometries.point(x_coord, y_coord))
//    //    })
//
//    val fillingStationRdd = epidemicIndentifyRdd
//      .mapPartitionsWithIndex((index, iter) => {
//
//      // 将加油站建立为rtree
//      val tuplesList = fillingList.value.toList
//      var tree:RTree[String,Point] = RTree.star().maxChildren(6).create()
//      tuplesList.map(obj => {
//        val point_name =obj._1
//        val x_coord =obj._2
//        val y_coord =obj._3
//        tree = tree.add(point_name, Geometries.point(x_coord, y_coord))
//      })
//
//      iter.map(x => {
//        val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//        val stay_point_x = try {tl_stay_points.split(",")(0).toDouble} catch {case e:Exception =>  0.0}
//        val stay_point_y = try {tl_stay_points.split(",")(1).toDouble} catch {case e:Exception =>  0.0}
//        var if_jyz = 0
//        try {
//          val points = tree.nearest(Geometries.point(stay_point_x, stay_point_y), 150, 1).toList().toBlocking().single().get(0)
//          val jyz_x_1 = points.geometry().x()
//          val jyz_y_1 = points.geometry().y()
//          val name_chn = points.value()
//
//          val dist = DistanceTool.getGreatCircleDistance(stay_point_x, stay_point_y, jyz_x_1, jyz_y_1)
//
//          if_jyz = if (dist < 150) 1 else 0
//
//          if (dist < 150) {
//            x.put("jyz_coords", jyz_x_1.toString + "," + jyz_y_1.toString)
//            x.put("jyz_dis", dist)
//            x.put("name_chn", name_chn)
//          }
//
//        }catch {
//          case e:Exception => e.printStackTrace()
//        }
//        x.put("if_jyz", if_jyz)
//        x
//      })
//
//    })
//
//    //    val fillingStationRdd = epidemicIndentifyRdd.map(x => {
//    //
//    //      val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//    //      val stay_point_x = tl_stay_points.split(",")(0).toDouble
//    //      val stay_point_y = tl_stay_points.split(",")(1).toDouble
//    //
//    //      val tuplesList = fillingList.value.toList
//    //
//    //      var tree:RTree[String,Point] = RTree.star().maxChildren(6).create()
//    //
//    //      tuplesList.map(obj => {
//    //        val point_name =obj._1
//    //        val x_coord =obj._2
//    //        val y_coord =obj._3
//    //        tree = tree.add(point_name, Geometries.point(x_coord, y_coord))
//    //      })
//    //      // 搜素rtree，快速找到临近加油站
//    ////      val points = tree.nearest(Geometries.point(stay_point_x,stay_point_y),150,1).toBlocking().toIterable()
//    //      val points = tree.nearest(Geometries.point(stay_point_x, stay_point_y), 0.15, 1).toList().toBlocking().single().get(0)
//    //
//    //      val jyz_x_1 = points.geometry().x()
//    //      val jyz_y_1 = points.geometry().y()
//    //      val name_chn = points.value()
//    //
//    //      val dist = DistanceTool.getGreatCircleDistance(stay_point_x,stay_point_y,jyz_x_1,jyz_y_1)
//    //
//    //      val if_jyz = if (dist < 150)  1 else 0
//    //
//    //      x.put("jyz_coords",jyz_x_1.toString + "," + jyz_y_1.toString)
//    //      x.put("jyz_dis",dist)
//    //      x.put("name_chn",name_chn)
//    //      x.put("if_jyz",if_jyz)
//    //
//    //      x
//    //
//    //    })
//
//
//    fillingStationRdd
//
//  }
//
//  /**
//    * 其他事件停留（除疫情）识别
//    * @param fillingStationRdd
//    */
//
//
//  def getOtherEvent(fillingStationRdd: RDD[JSONObject]) = {
//
//    val otherEventRdd = fillingStationRdd.map(x => {
//
//
//      val rt_event_info_str = try {JSONUtils.getJsonValue(x,"rt_event_info","")
//        .replaceAll("\\{\"","{'")
//        .replaceAll("\":\"", "':'")
//        .replaceAll("\",\"", "','")
//        .replaceAll("\":", "':")
//        .replaceAll(",\"", ",'")
//        .replaceAll("\"\\}", "'}")
//        .replaceAll("\"", "")
//        .replaceAll("'", "\"")
//        .replaceAll("", "")
//        .replaceAll("\\\\", "?")
//      } catch {case e:Exception => ""}
//      val rt_event_info =  try {JSON.parseArray(rt_event_info_str)} catch {case e:Exception => new JSONArray()}
//
//      val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
//      val tl_index = JSONUtils.getJsonValueInt(x,"tl_index",-1)
//
//      val events_code = JSONUtils.getJsonValue(x,"events_code","")
//      val events = JSONUtils.getJsonValue(x,"events","")
//
//
//      val stay_point_x = try {tl_stay_points.split(",")(0).toDouble} catch {case e:Exception => 0.0 }
//      val stay_point_y = try {tl_stay_points.split(",")(1).toDouble} catch {case e:Exception => 0.0 }
//
//      var minDist = 1000000000.0
//
//      // TODO: 计算停留点
//      //      var events_fanhui_epidemic = -1.0
//
//      var total_event_xy1 = ""
//      var total_event_xy2 = ""
//      var orCode = ""
//      var swids = ""
//      var stay_event_start_distance = 999999.0
//      var stay_event_end_distance = 999999.0
//      var events_index = -1
//      var content = ""
//      var if_other_event = 0
//
//      try {
//
//        for (i <- (0 until (rt_event_info.size()))) {
//          val event_json = rt_event_info.getJSONObject(i)
//          val event_orCode = JSONUtils.getJsonValue(event_json, "event_orCode", "")
//
//          if (StringUtils.nonEmpty(event_orCode) && (!"0,0,6,16".equals(event_orCode) && !"1,1,6,16".equals(event_orCode))) {
//
//            //        event_xy2 : "115.375890,37.998103"
//
//            val event_xy1 = JSONUtils.getJsonValue(event_json, "event_xy1", "")
//            val event_xy2 = JSONUtils.getJsonValue(event_json, "event_xy2", "")
//            //        event_orCode : "0,0,200,201"
//            //        event_swids : "9488724213280"
//            val event_swids = JSONUtils.getJsonValue(event_json, "event_swids", "")
//            val event_content = JSONUtils.getJsonValue(event_json, "event_content", "")
//
//            val event_x1 = event_xy1.split(",")(0).toDouble
//            val event_y1 = event_xy1.split(",")(1).toDouble
//            val event_x2 = event_xy2.split(",")(0).toDouble
//            val event_y2 = event_xy2.split(",")(1).toDouble
//
//            val dist1 = DistanceTool.getGreatCircleDistance(stay_point_x, stay_point_y, event_x1, event_y1)
//            val dist2 = DistanceTool.getGreatCircleDistance(stay_point_x, stay_point_y, event_x2, event_y2)
//            val min_dist = math.min(dist1, dist2)
//
//            if ((dist1 < 4000 || dist2 < 4000) && minDist > min_dist) {
//              minDist = min_dist
//              total_event_xy1 = event_xy1
//              total_event_xy2 = event_xy2
//              orCode = event_orCode
//              swids = event_swids
//              stay_event_start_distance = dist1
//              stay_event_end_distance = dist2
//              content = event_content
//            }
//          }
//        }
//
//        val jp_swid = JSONUtils.getJsonValue(x,"jp_swid","")
//
//        val jp_swid_array =
//          if (StringUtils.nonEmpty(jp_swid)){
//            jp_swid.split("\\|")
//          } else {
//            new Array[String](0)
//          }
//
//
//        for (i <- (0 until(jp_swid_array.size))){
//          if (StringUtils.nonEmpty(swids) && swids.equals(jp_swid_array(i))){
//            events_index = i
//          }
//        }
//
//
//        if_other_event =
//          if (stay_event_start_distance != 999999.0)
//            1
//          else if (stay_event_start_distance == 999999.0 && StringUtils.nonEmpty(events_code))
//            1
//          else
//            0
//
//
//      } catch {case e:Exception => e.printStackTrace()}
//
//
//      val events_content2 = if (StringUtils.nonEmpty(content)) content else if (StringUtils.nonEmpty(events)) events else "-"
//
//      val events_eventcode = if (StringUtils.nonEmpty(orCode)) orCode else if (StringUtils.nonEmpty(events_code)) events_code else "-"
//
//
//
//
//      x.put("event_xy1",total_event_xy1)
//      x.put("event_xy2",total_event_xy2)
//      x.put("event_orCode",orCode)
//      x.put("event_swids",swids)
//      x.put("event_stay_event_start_distance",stay_event_start_distance)
//      x.put("event_stay_event_end_distance",stay_event_end_distance)
//      x.put("events_index",events_index)
//      x.put("if_other_event",if_other_event)
//      x.put("event_content",content)
//      x.put("events_content2",events_content2)
//      x.put("events_eventcode",events_eventcode)
//
//      x
//    })
//
//    otherEventRdd
//
//
//  }
//
//
//
//
//
//
//  /**
//    * 获取穿行高低接口返回、解析
//    *
//    * @param x
//    * @return
//    */
//
//  def calCrossHeights(x:JSONObject):JSONObject = {
//
//    val lineid = JSONUtils.getJsonValue(x,"task_subid","")
//    val t_links_union = JSONUtils.getJsonValue(x,"t_links_union","")
//    val tl_link = JSONUtils.getJsonValue(x,"tl_link","-")
//    val ft_coords = JSONUtils.getJsonValue(x,"jp_coords","")
//
//    val ft_coords_array =
//      if (StringUtils.nonEmpty(ft_coords)){
//        ft_coords.split("\\|")
//      } else {
//        new Array[String](0)
//      }
//
//    val array = new JSONArray()
//
//    for (i <- (0 until(ft_coords_array.size))){
//
//      val joArray = new JSONArray()
//      val x1 = ft_coords_array(i).split(",")(0).toDouble
//      val y1 = ft_coords_array(i).split(",")(1).toDouble
//
//      joArray.add(x1)
//      joArray.add(y1)
//
//      array.add(joArray)
//    }
//
//
//
//    val jo = new JSONObject()
//
//    // TODO: 测试ak
//    //    jo.put("ak","12fe501477bc44e49cbbe61a6c1d8866")
//    // TODO: 线上ak
//    //    jo.put("ak","39681f679699410b9ecc8dbcc5c98bde")
//    jo.put("ak","dc894b4a3c7444b4a3505315d00b87ad")
//    jo.put("lineid",lineid)
//    jo.put("links_union",t_links_union)
//    jo.put("vehicle_type",6)
//    jo.put("vehicle","")
//    jo.put("req_time","")
//    jo.put("ft_coords",array.toJSONString)
//    jo.put("turn_bypass_ratio_limit",1.5)
//
//    //    StringToCsv.stringToCsv("2022080802","",jo.toJSONString)
//
//
//    var mark = 0
//    var if_high_low_level = 0
//
//    var tollstation_link_highlow_level = 0
//
//    //      try {
//    //        val responseStr = Utils.retryPost(calCrossHeightsUrl,jo)
//    //        val request = JSON.parseObject(responseStr)
//    //        val bypassResult = request.getJSONArray("bypassResult")
//    //
//    //        var bypassJson = new JSONObject()
//    //        var markflag = 0
//    //
//    //        for (i <- (0 until(bypassResult.size())) if(markflag == 0)){
//    //          val jo = bypassResult.getJSONObject(i)
//    //          val mark = JSONUtils.getJsonValueInt(jo,"mark",0)
//    //          val existlimit = JSONUtils.getJsonValueInt(jo,"existlimit",-1)
//    //          val originroadclasslist = JSONUtils.getJsonValue(jo,"originroadclasslist","")
//    //          val problemStr = JSONUtils.getJsonValue(jo,"problemStr","")
//    //
//    //          val if_exist_problemStr = if (StringUtils.nonEmpty(originroadclasslist) && originroadclasslist.startsWith("0")
//    //          && originroadclasslist.endsWith("0") && StringUtils.nonEmpty(problemStr) && problemStr.contains(tl_link)) 1 else 0
//    //
//    //          if ((mark == 70 || mark == 71) && existlimit == 0 && if_exist_problemStr == 1){
//    //            markflag = 1
//    //            bypassJson = jo
//    //          }
//    //        }
//    //
//    //        val mark = JSONUtils.getJsonValueInt(bypassJson,"mark",0)
//    //        val originroadclasslist = JSONUtils.getJsonValue(bypassJson,"originroadclasslist","")
//    //        val existlimit = JSONUtils.getJsonValueInt(bypassJson,"existlimit",0)
//    //        val problemStr = JSONUtils.getJsonValue(bypassJson,"problemStr","")
//    //
//    //
//    ////        val markNew = if (mark == 70 || mark == 71) mark else 0
//    ////        val existlimitNew = if (existlimit == 0 ) 0 else -1
//    ////        val problemStrNew = if (StringUtils.nonEmpty(originroadclasslist) && originroadclasslist.startsWith("0")
//    ////          && originroadclasslist.endsWith("0")
//    ////          && problemStr.contains(tl_link)) problemStr else ""
//    //
//    //
//    //        val toll_station = JSONUtils.getJsonValue(x,"toll_station","")
//    //
//    //        val toll_station_array =
//    //          if (StringUtils.nonEmpty(toll_station)){
//    //            toll_station.split("\\|")
//    //          } else {
//    //            new Array[String](0)
//    //          }
//    //
//    //        toll_station_array.map( toll => {
//    //          if ( StringUtils.nonEmpty(problemStr) && problemStr.contains(toll)){
//    //            tollstation_link_highlow_level = 1
//    //          }
//    //        })
//    //
//    //
//    //        if_high_low_level = if (StringUtils.nonEmpty(problemStr) && tollstation_link_highlow_level == 1) 1 else 0
//    //
//    //        x.put("bypass_mark",mark)
//    //        x.put("existlimit",existlimit)
//    //        x.put("originroadclasslist",originroadclasslist)
//    //        x.put("problemStr",problemStr)
//    //
//    //      } catch {
//    //        case e: Exception =>
//    //          e.toString
//    //      }
//    x.put("tollstation_link_highlow_level",tollstation_link_highlow_level)
//    x.put("if_high_low_level",if_high_low_level)
//
//    x
//  }
//
//
//  /**
//    * 穿行高低等级停留识别
//    * @param otherEventRdd
//    */
//
//
//  def getCrossHeights(otherEventRdd: RDD[JSONObject]) = {
//
//    val limitMin = 15000
//    val requestRdd = SparkUtils.akLimitMultiThreadRdd(otherEventRdd)(calCrossHeights)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    //    val requestRdd = otherEventRdd.repartition(2).map(x => {
//    //      val request = calCrossHeights(x)
//    //      request
//    //    })
//
//    logger.error("requestRdd的数据量为：" + requestRdd.count())
//
//
//    requestRdd
//
//  }
//
//
//  /**
//    * 高速停留识别
//    * @param crossHeightsRdd
//    */
//
//  def getHighSpeedIndentify(crossHeightsRdd: RDD[JSONObject]) = {
//
//    val highSpeedIndentifyRdd = crossHeightsRdd.map(x => {
//
//      val tl_road = x.getString("tl_road")
//
//      val if_gaosu = if (StringUtils.nonEmpty(tl_road) && tl_road.contains("高速") && (!tl_road.contains("高速出口") || !tl_road.contains("高速入口"))) 1 else 0
//
//      x.put("if_gaosu",if_gaosu)
//
//      x
//    })
//
//    highSpeedIndentifyRdd
//  }
//
//
//
//
//  /**
//    * 停留点类型标记
//    *
//    * @param highSpeedIndentifyRdd
//    */
//
//  def getStayPointMarkType(highSpeedIndentifyRdd: RDD[JSONObject],holidayList:Broadcast[Array[String]]) = {
//
//    val stayPointMarkTypeRdd = highSpeedIndentifyRdd.map(x => {
//
//      val if_epidemic = JSONUtils.getJsonValueInt(x,"if_epidemic",-1)
//      val if_service = JSONUtils.getJsonValueInt(x,"if_service",-1)
//      val if_jp_service = JSONUtils.getJsonValueInt(x,"if_jp_service",-1)
//      val stay_event_start_distance = JSONUtils.getJsonValueInt(x,"stay_event_start_distance",99999999)
//      val if_toll_station = JSONUtils.getJsonValueInt(x,"if_toll_station",-1)
//      val if_jyz = JSONUtils.getJsonValueInt(x,"if_jyz",-1)
//      val if_start = JSONUtils.getJsonValueInt(x,"if_start",-1)
//      val if_other_event = JSONUtils.getJsonValueInt(x,"if_other_event",-1)
//      val if_end_notin_radius = JSONUtils.getJsonValueInt(x,"if_end_notin_radius",-1)
//      val if_end_in_radius = JSONUtils.getJsonValueInt(x,"if_end_in_radius",-1)
//      val if_high_low_level = JSONUtils.getJsonValueInt(x,"if_high_low_level",-1)
//      val if_gaosu = JSONUtils.getJsonValueInt(x,"if_gaosu",-1)
//      val subjective_objective_status = JSONUtils.getJsonValueInt(x,"subjective_objective_status",-1)
//      val lishi_label = JSONUtils.getJsonValue(x,"lishi_label","")
//
//
//      val epidemic_stay_event_start_distance = JSONUtils.getJsonValueDouble(x,"epidemic_stay_event_start_distance",0)
//      val event_stay_event_start_distance = JSONUtils.getJsonValueDouble(x,"event_stay_event_start_distance",0)
//      val service_start_distance = JSONUtils.getJsonValueDouble(x,"service_start_distance",0)
//
//
//
//      val label =
//        if (if_epidemic == 1 && (if_service == 0 && if_jp_service == 0)){
//          "疫情停留"
//        }else if (if_epidemic == 1 && (if_service == 1 || if_jp_service == 1) && epidemic_stay_event_start_distance > service_start_distance && stay_event_start_distance >= 1000){
//          "服务区停留"
//        }else if (if_epidemic == 1 && (if_service == 1 || if_jp_service == 1) &&  service_start_distance >= epidemic_stay_event_start_distance && stay_event_start_distance < 1000){
//          "疫情停留"
//        }else if (if_service == 1 || if_jp_service == 1){
//          "服务区停留"
//        }else if (if_toll_station == 1){
//          "收费站停留"
//        }else if (if_jyz == 1){
//          "加油站停留"
//        }else if (if_start == 1){
//          "起点停留"
//        }else if (if_other_event == 1){
//          "其他事件停留"
//        }else if (if_end_notin_radius == 1){
//          "终点停留"
//        }else if (if_end_in_radius == 1){
//          "终点停留_电子围栏内未打卡"
//        }else if (if_high_low_level == 1){
//          "穿行高低等级停留"
//        }else if (if_gaosu == 1){
//          "高速停留"
//        }else {
//          "无标记停留"
//        }
//
//      var label2 =
//        if ("疫情停留".equals(label)){
//          if (subjective_objective_status == 1){
//            "疫情主观停留"
//          }else if (subjective_objective_status == 0){
//            "疫情客观停留"
//          }else {
//            label
//          }
//        }else if ("收费站停留".equals(label)){
//          if (subjective_objective_status == 1){
//            "收费站主观停留"
//          }else {
//            "收费站客观停留"
//          }
//        }else if ("高速停留".equals(label)){
//          if (subjective_objective_status ==1){
//            "高速主观停留"
//          }else {
//            "高速客观停留"
//          }
//        }else if ("无标记停留".equals(label)) {
//          if (subjective_objective_status == 1) {
//            "无标记主观停留"
//          }else {
//            "无标记客观停留"
//          }
//        }else {
//          label
//        }
//
//
//
//      var label3 =
//        if ("疫情停留".equals(label)){
//          if (lishi_label.equals("平均时长判断主观") && "疫情主观停留".equals(label2)){
//            "疫情主观停留"
//          }else if (lishi_label.equals("平均时长判断客观")){
//            "疫情客观停留"
//          }else {
//            label2
//          }
//        }else if ("收费站停留".equals(label)){
//          if (lishi_label.equals("平均时长判断主观") && "收费站主观停留".equals(label2)){
//            "收费站主观停留"
//          }else if (lishi_label.equals("平均时长判断客观")){
//            "收费站客观停留"
//          }else {
//            label2
//          }
//        }else if ("高速停留".equals(label)){
//          if (lishi_label.equals("平均时长判断主观") && "高速主观停留".equals(label2)){
//            "高速主观停留"
//          }else if (lishi_label.equals("平均时长判断客观")){
//            "高速客观停留"
//          }else {
//            label2
//          }
//        }else if ("无标记停留".equals(label)){
//          if (lishi_label.equals("平均时长判断主观") && "无标记主观停留".equals(label2)){
//            "无标记主观停留"
//          }else if (lishi_label.equals("平均时长判断客观")){
//            "无标记客观停留"
//          }else {
//            label
//          }
//        }else {
//          label
//        }
//
//
//      // TODO: 20230207增加逻辑
//      val tl_time_period = JSONUtils.getJsonValue(x, "tl_time_period", "")
//      val tile_version = if (tl_time_period.size > 10) tl_time_period.substring(0,10).replace("-","") else ""
//
//      val tl_time_period_array =
//        if (StringUtils.nonEmpty(tl_time_period)){
//          tl_time_period.split("_")
//        } else {
//          new Array[String](0)
//        }
//
//      val tl_time_period_before_day = try {if (tl_time_period_array.length> 1) (tl_time_period_array(0).substring(0,10)) else "2000-01-10"} catch {case e:Exception => "2000-01-10"}
//      val tl_time_period_after_day = try {if (tl_time_period_array.length> 1) (tl_time_period_array(1).substring(0,10)) else "2000-01-10"} catch {case e:Exception => "2000-01-10"}
//
//      val beforeWeekDay = DateTimeUtil.judgeWeekDay(tl_time_period_before_day,"yyyy-MM-dd")
//      val afterWeekDay = DateTimeUtil.judgeWeekDay(tl_time_period_after_day,"yyyy-MM-dd")
//
//      val tl_time_period_before_timestamp = if (tl_time_period_array.length> 0) DateTimeUtil.timeToLong(tl_time_period_array(0),"yyyy-MM-dd HH:mm:ss") / 1000  else 0
//      val tl_time_period_after_timestamp = if (tl_time_period_array.length> 0) DateTimeUtil.timeToLong(tl_time_period_array(1),"yyyy-MM-dd HH:mm:ss") / 1000  else 0
//
//
//      val tl_time_period_before_hour = try {if (tl_time_period_array.length> 1) (tl_time_period_array(0).substring(11,19).replace(":","").toInt) else 0} catch {case e:Exception => 0}
//      val tl_time_period_after_hour = try {if (tl_time_period_array.length> 1) (tl_time_period_array(1).substring(11,19).replace(":","").toInt) else 0} catch {case e:Exception => 0}
//
//      val holidays = holidayList.value
//
//      var yongdu_time2 = 0L
//      var yongdu_time3 = 0L
//
//      if (((tl_time_period_before_hour >= 70000 && tl_time_period_after_hour <= 90000) ||
//        (tl_time_period_before_hour >= 170000 && tl_time_period_after_hour <= 190000) ||
//        ((holidays.contains(tl_time_period_before_day.replace("-","")) ||  (beforeWeekDay== 6 || beforeWeekDay== 7 )) &&
//          (holidays.contains(tl_time_period_after_day.replace("-","")) ||  (afterWeekDay== 6 || afterWeekDay== 7 )))) && label2.equals("无标记客观停留")) {
//
//        label2 = "高峰拥堵"
//        label3 = "高峰拥堵"
//        yongdu_time2 = tl_time_period_after_timestamp - tl_time_period_before_timestamp
//        yongdu_time3 = tl_time_period_after_timestamp - tl_time_period_before_timestamp
//
//      }
//
//
//      x.put("label",label)
//      x.put("label2",label2)
//      x.put("label3",label3)
//      x.put("yongdu_time2",yongdu_time2)
//      x.put("yongdu_time3",yongdu_time3)
//
//      x
//    })
//
//
//    stayPointMarkTypeRdd
//
//
//  }
//
//  /**
//    * 获取当年节假日信息
//    * @param spark
//    */
//  def getHoliday(spark: SparkSession) = {
//
//    import spark.implicits._
//
//    val sql =
//      s"""
//         |select
//         |  holiday
//         |from
//         |  dm_gis.eta_holiday_table
//       """.stripMargin
//
//    val holidayList = spark.sql(sql).map(x => {
//      val holiday = x.getString(0)
//      holiday
//    }).collect()
//
//    logger.error(holidayList.mkString("|"))
//    val holidayListBroad = spark.sparkContext.broadcast(holidayList)
//
//
//    holidayListBroad
//  }
//
//  // TODO: 计算流程2  停留类型标记
//  def stayPointsMarkType(spark: SparkSession, rejectStayRdd: RDD[JSONObject],inc_day:String) = {
//
//    // TODO: 服务区停留识别
//    val serviceAreaIdentifyRdd = getServiceAreaIdentify(rejectStayRdd)
//
//    // TODO: 服务区纠偏
//    val serviceAreaCorrectionRdd = getServiceAreaCorrection(serviceAreaIdentifyRdd)
//
//    // TODO: 收费站停留识别
//    val tollStationRdd = getTollStation(serviceAreaCorrectionRdd)
//
//    // TODO: 起终点停留识别
//    val startEndDeptIndentifyRdd = getStartEndDeptIndentify(spark,tollStationRdd,inc_day)
//
//    // TODO: 疫情停留识别
//    val epidemicIndentifyRdd = getEpidemicIndentify(startEndDeptIndentifyRdd)
//
//    // TODO: 加油站停留识别
//    val fillingStationRdd = getFillingStation(spark,epidemicIndentifyRdd,inc_day)
//
//    // TODO: 其他事件停留（除疫情）识别
//    val otherEventRdd = getOtherEvent(fillingStationRdd)
//
//    //    // TODO: 穿行高低等级停留识别
//    //    val crossHeightsRdd = getCrossHeights(rejectStayRdd)
//    val crossHeightsRdd = getCrossHeights(otherEventRdd)
//
//    // TODO: 高速停留识别
//    val highSpeedIndentifyRdd = getHighSpeedIndentify(crossHeightsRdd)
//
//    // TODO: 停留点类型标记
//    // 获取节假日信息
//    val holidayList = getHoliday(spark)
//
//    val stayPointMarkTypeRdd = getStayPointMarkType(highSpeedIndentifyRdd,holidayList)
//
//    stayPointMarkTypeRdd
//  }
//
//
//  def saveTabel(spark: SparkSession, inc_day: String, stayPointMarkTypeRdd: RDD[JSONObject]) = {
//
//    import spark.implicits._
//    val saveTable = "dm_gis.eta_time_monitor_split_staypoint"
////    val saveTable = "dm_gis.eta_time_monitor_split_staypoint_test"
//
//    val stayPoinTableRdd = stayPointMarkTypeRdd.map(x => {
//
//      val tl_stay_points= x.getString("tl_stay_points")
//      val tl_index= x.getString("tl_index")
//      val tl_time_period= x.getString("tl_time_period")
//      val tl_durations= x.getString("tl_durations")
//      val tl_road= x.getString("tl_road")
//      val tl_roadclasss= x.getString("tl_roadclasss")
//      val tl_link= x.getString("tl_link")
//      val tl_links= x.getString("tl_links")
//      val tl_length= x.getString("tl_length")
//
//      val task_area_code = x.getString("task_area_code")
//      val task_id = x.getString("task_id")
//      val sort_num = x.getString("sort_num")
//      val task_subid = x.getString("task_subid")
//      val start_dept = x.getString("start_dept")
//      val end_dept = x.getString("end_dept")
//
//      val actual_run_time2 = x.getString("actual_run_time")
//
//      val line_code = JSONUtils.getJsonValue(x,"line_code","")
//      val vehicle_serial = JSONUtils.getJsonValue(x,"vehicle_serial","")
//      val plan_depart_tm = JSONUtils.getJsonValue(x,"plan_depart_tm","")
//
//      val actual_depart_tm = JSONUtils.getJsonValue(x,"actual_depart_tm","")
//      val actual_arrive_tm = JSONUtils.getJsonValue(x,"actual_arrive_tm","")
//      val driver_id = JSONUtils.getJsonValue(x,"driver_id","")
//      val driver_name = JSONUtils.getJsonValue(x,"driver_name","")
//      val start_longitude = JSONUtils.getJsonValue(x,"start_longitude","")
//      val start_latitude = JSONUtils.getJsonValue(x,"start_latitude","")
//      val end_longitude = JSONUtils.getJsonValue(x,"end_longitude","")
//      val end_latitude = JSONUtils.getJsonValue(x,"end_latitude","")
//      val rt_dist = JSONUtils.getJsonValue(x,"rt_dist","")
//      val error_type = JSONUtils.getJsonValue(x,"error_type","")
//      val task_inc_day = JSONUtils.getJsonValue(x,"task_inc_day","")
//      val carrier_name = JSONUtils.getJsonValue(x,"carrier_name","")
//      val difftime_plan_actual = JSONUtils.getJsonValue(x,"difftime_plan_actual","")
//      val jp_swid = JSONUtils.getJsonValue(x,"jp_swid","")
//      val jp_time = JSONUtils.getJsonValue(x,"jp_time","")
//      val jp_coords = JSONUtils.getJsonValue(x,"jp_coords","")
//      val jp_status = JSONUtils.getJsonValue(x,"jp_status","")
//      val sum_dist = JSONUtils.getJsonValue(x,"sum_dist","")
//      val t_links_union = JSONUtils.getJsonValue(x,"t_links_union","")
//      val toll_station = JSONUtils.getJsonValue(x,"toll_station","")
//      val service = JSONUtils.getJsonValue(x,"service","")
//      val toll_station_linkpointinfo = JSONUtils.getJsonValue(x,"toll_station_linkpointinfo","")
//
//
//      val start_road_dist= x.getString("start_road_dist")
//      val end_road_dist= x.getString("end_road_dist")
//      val mark= x.getString("mark")
//      val mark2= x.getString("mark2")
//      val mark3= x.getString("mark3")
//      val status= x.getString("status")
//      val speed= x.getString("speed")
//      val events = x.getString("events")
//      val events_code= try {JSONUtils.getJsonValue(x,"events_code","").replace("[","").replace("]","")} catch {case e:Exception => ""}
//      val stay_points_start_time= x.getString("stay_points_start_time")
//      val speed_diveation_value= x.getString("speed_diveation_value")
//      val speed_diveation_ratio= x.getString("speed_diveation_ratio")
//      val subjective_objective_status= x.getString("subjective_objective_status")
//      val service_sw_id= x.getString("service_sw_id")
//      val service_start_coordinate= x.getString("service_start_coordinate")
//      val service_end_coordinate= x.getString("service_end_coordinate")
//      val service_link_index= x.getString("service_link_index")
//      val service_start_distance= x.getString("service_start_distance")
//      val service_end_distance= x.getString("service_end_distance")
//      val service_staypoints_service_position= x.getString("service_staypoints_service_position")
//      val if_service= x.getString("if_service")
//
//      val jp_service_swid = x.getString("jp_service_swid")
//      val if_jp_service = x.getString("if_jp_service")
//      val toll_station_sw_id= x.getString("toll_station_sw_id")
//      val toll_station_start_coordinate= x.getString("toll_station_start_coordinate")
//      val toll_station_end_coordinate= x.getString("toll_station_end_coordinate")
//      val toll_station_link_index= x.getString("toll_station_link_index")
//      val toll_station_start_distance= x.getString("toll_station_start_distance")
//      val toll_station_end_distance= x.getString("toll_station_end_distance")
//      val toll_station_road_dist= x.getString("toll_station_road_dist")
//      val staypoints_toll_station_position= x.getString("staypoints_toll_station_position")
//      val if_toll_station= x.getString("if_toll_station")
//      val start_dept_radius= x.getString("start_dept_radius")
//      val end_dept_radius= x.getString("end_dept_radius")
//      val start_distance= x.getString("start_distance")
//      val end_distance= x.getString("end_distance")
//      val end_in_radius= x.getString("end_in_radius")
//      val if_start= x.getString("if_start")
//      val if_end_notin_radius= x.getString("if_end_notin_radius")
//      val if_end_in_radius= x.getString("if_end_in_radius")
//      val epidemic_xy1= x.getString("epidemic_xy1")
//      val epidemic_xy2= x.getString("epidemic_xy2")
//      val epidemic_orCode= x.getString("epidemic_orCode")
//      val epidemic_swids= x.getString("epidemic_swids")
//      val epidemic_stay_event_start_distance= x.getString("epidemic_stay_event_start_distance")
//      val epidemic_stay_event_end_distance= x.getString("epidemic_stay_event_end_distance")
//      val epidemic_index= x.getString("epidemic_index")
//      val if_epidemic= x.getString("if_epidemic")
//      val epidemic_content= x.getString("epidemic_content")
//      val staypoints_epidemic_position= x.getString("staypoints_epidemic_position")
//      val jyz_coords= x.getString("jyz_coords")
//      val jyz_dis= x.getString("jyz_dis")
//      val name_chn= x.getString("name_chn")
//      val if_jyz= x.getString("if_jyz")
//      val event_xy1= x.getString("event_xy1")
//      val event_xy2= x.getString("event_xy2")
//      val event_orCode= x.getString("event_orCode")
//      val event_swids= x.getString("event_swids")
//      val event_stay_event_start_distance= x.getString("event_stay_event_start_distance")
//      val event_stay_event_end_distance= x.getString("event_stay_event_end_distance")
//      val events_index= x.getString("events_index")
//      val if_other_event= x.getString("if_other_event")
//      val event_content= x.getString("event_content")
//      val bypass_lineid= x.getString("bypass_lineid")
//      val bypass_mark= x.getString("bypass_mark")
//      val existlimit= x.getString("existlimit")
//      val originroadclasslist= x.getString("originroadclasslist")
//      val problemStr= x.getString("problemStr")
//      val tollstation_link_highlow_level= x.getString("tollstation_link_highlow_level")
//      val if_high_low_level= x.getString("if_high_low_level")
//      val if_gaosu= x.getString("if_gaosu")
//      val label= x.getString("label")
//      val label2= x.getString("label2")
//      val label3= x.getString("label3")
//
//      // TODO: 0811新增字段
//      val line_time = x.getString("line_time")
//      val service_station_linkpointinfo = JSONUtils.getJsonValue(x,"service_station_linkpointinfo","")
//      // TODO: 0811新增字段 plan_arrive_tm - plan_depart_tm（待修改）
//      val plan_run_time2 = x.getString("plan_run_time2")
//      val plan_arrive_tm = JSONUtils.getJsonValue(x,"plan_arrive_tm","")
//      val tl_sort_num =  x.getString("tl_sort_num")
//      val mark4 = x.getString("mark4")
//
//
//      val guiji_lishi =  x.getString("guiji_lishi")
//      val imei_lishi =  x.getString("imei_lishi")
//      val guiji_lishi_imei =  x.getString("guiji_lishi_imei")
//      val lishi_max_tl_tm =  x.getString("lishi_max_tl_tm")
//      val lishi_max2_tl_tm =  x.getString("lishi_max2_tl_tm")
//      val lishi_mean_speed_ins =  x.getString("lishi_mean_speed_ins")
//      val lishi_speed_ins_ls =  x.getString("lishi_speed_ins_ls")
//      val lishi_speed0_ins_count =  x.getString("lishi_speed0_ins_count")
//      val lishi_time_diff =  x.getString("lishi_time_diff")
//      val lishi_time_diff_ratio =  x.getString("lishi_time_diff_ratio")
//      val lishi_label =  x.getString("lishi_label")
//
//      val multi_road_err = x.getString("MultiRoadErrInfo")
//
//      val events_content2 = x.getString("events_content2")
//      val events_eventcode = x.getString("events_eventcode").replace("[","").replace("]","")
//      val yongdu_time2 = x.getString("yongdu_time2")
//      val yongdu_time3 = x.getString("yongdu_time3")
//
//
//      TimeMonitorStayPoint(tl_stay_points,tl_index,tl_time_period,tl_durations,tl_road,tl_roadclasss,tl_link,tl_links,tl_length,
//        task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,actual_run_time2,line_code,vehicle_serial,plan_depart_tm,
//        actual_depart_tm,actual_arrive_tm,driver_id,driver_name,start_longitude,start_latitude,end_longitude,end_latitude,rt_dist,
//        error_type,task_inc_day,carrier_name,difftime_plan_actual,jp_swid,jp_time,jp_coords,jp_status,sum_dist,t_links_union,
//        toll_station,service,toll_station_linkpointinfo,
//        start_road_dist,end_road_dist,mark,mark2,mark3,status,speed,events,events_code,stay_points_start_time,speed_diveation_value,
//        speed_diveation_ratio,subjective_objective_status,service_sw_id,service_start_coordinate,service_end_coordinate,
//        service_link_index,service_start_distance,service_end_distance,service_staypoints_service_position,if_service,jp_service_swid,if_jp_service,
//        toll_station_sw_id,toll_station_start_coordinate,toll_station_end_coordinate,toll_station_link_index,toll_station_start_distance,
//        toll_station_end_distance,toll_station_road_dist,staypoints_toll_station_position,if_toll_station,start_dept_radius,end_dept_radius,
//        start_distance,end_distance,end_in_radius,if_start,if_end_notin_radius,if_end_in_radius,
//        epidemic_xy1,epidemic_xy2,epidemic_orCode,epidemic_swids,epidemic_stay_event_start_distance,epidemic_stay_event_end_distance
//        ,epidemic_index,if_epidemic,epidemic_content,staypoints_epidemic_position,jyz_coords,jyz_dis,name_chn,
//        if_jyz,event_xy1,event_xy2,event_orCode,event_swids,event_stay_event_start_distance,event_stay_event_end_distance,events_index,if_other_event,
//        event_content,bypass_lineid,bypass_mark,existlimit,originroadclasslist,problemStr,tollstation_link_highlow_level,if_high_low_level,if_gaosu,label,label2,label3,
//        line_time,service_station_linkpointinfo,plan_run_time2,plan_arrive_tm,tl_sort_num,mark4,
//        guiji_lishi,imei_lishi,guiji_lishi_imei,lishi_max_tl_tm,lishi_max2_tl_tm,lishi_mean_speed_ins,lishi_speed_ins_ls,lishi_speed0_ins_count,
//        lishi_time_diff,lishi_time_diff_ratio,lishi_label,multi_road_err,events_content2,events_eventcode,yongdu_time2,yongdu_time3
//      )
//    }).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTable)
//    //      .repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").option("delimiter","\t").csv("d:\\user\\01401062\\桌面\\20220906.csv")
//
//
//  }
//
//  def startSta(spark: SparkSession, inc_day: String) = {
//
//    val sourceRdd = getSourceRdd(spark,inc_day)
//
//    val rejectStayRdd = rejectStayPoints(spark,sourceRdd)
//
//    val stayPointMarkTypeRdd = stayPointsMarkType(spark,rejectStayRdd,inc_day)
//
//    saveTabel(spark,inc_day,stayPointMarkTypeRdd)
//
//  }
//
//  def start(inc_day: String) = {
//
//    val spark = SparkUtils.getSparkSession(appName,"yarn")
//    //    val spark = SparkUtils.getSparkSession(appName,"local[16]")
//
//    spark.sparkContext.setLogLevel("ERROR")
//
//    startSta(spark,inc_day)
//    logger.error("统计结束")
//
//  }
//
//  def main(args: Array[String]): Unit = {
//
//    val inc_day = args(0)
//    //    val inc_day = ""
//
//    //    val str = "{\"tl_length\":\"3072\",\"tl_durations\":\"1319\",\"tl_link\":\"8489623760610\",\"tl_time_period\":\"2022-07-06 04:22:22_2022-07-06 04:44:21\"}"
//    //    val jo = JSON.parseObject(str)
//    //    println(jo.toJSONString)
//    //    val json = multiRoadConditionInterface(jo)
//    //    val repJson = multiRoadConditionInterface2(json)
//
//    start(inc_day)
//
//  }
//
//
//
//
//}
