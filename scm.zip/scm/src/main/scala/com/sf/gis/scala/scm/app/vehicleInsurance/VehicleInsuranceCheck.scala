package com.sf.gis.scala.scm.app.vehicleInsurance

import com.alibaba.fastjson.JSON
import com.sf.gis.scala.base.util.HttpUtils
import common.DataSourceCommon
import utils.{DateUtil, SparkBuilder}

/**
  * GIS-RSS-SCM：【车险风险模型】全国重货轨迹日结数据接入_v1.4_01420395_蔡国房
  *@author 01420395
  *@DESCRIPTION  日结接入后进行数量核对落地
  *@create 20230707 任务已经交接给徐达 01413008
  */
object VehicleInsuranceCheck extends DataSourceCommon{


  val vehicleUrl = "http://gis-issp-gw.sf-express.com/transform/queryFinish?time=%s&dataType=car-stat"

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    import org.apache.spark.sql.functions._

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)

    val sql =
      s"""
        select * from dm_gis.insurance_model_duration_dist_daily_qgzh where inc_day  = '${inc_day}'
      """.stripMargin
    logger.error(sql)
    val insuranceDF = spark.sql(sql)

    import spark.implicits._

    //数据量核对
    val countNum  = insuranceDF.count()
    val biz_day  = DateUtil.getdaysBefore(inc_day,0,"yyyyMMdd","yyyy-MM-dd")
    //通过接口获取对应的当天总数量
    val responseJSONP =  HttpUtils.urlConnectionGetJson(String.format(vehicleUrl,biz_day),1000)
    var changeCount = 0.0
    if(responseJSONP!=null) {
      val json = JSON.parseObject(responseJSONP.getString("result"))
      logger.error(json)
      val readStatus = json.getString("isFinish")
      changeCount = readStatus.toLong
    }

    // 车均里程 , 车均时长  , 车均轨迹点
    val checkDataDF   = insuranceDF.groupBy("inc_day")
      .agg(avg("total_links_dist").as("total_links_dist_ck"),
      avg("total_links_duration").as("total_links_duration_ck"),
      avg("track_point_count").as("track_point_count_ck")
    ).select('inc_day, 'total_links_dist_ck, 'total_links_duration_ck, 'track_point_count_ck)

    //前七天
    val before7_day  = DateUtil.getdaysBefore(inc_day,-7,"yyyyMMdd")
    val sql3 =
      s"""
        select * from dm_gis.insurance_model_duration_dist_daily_qgzh where inc_day between '${before7_day}' and  '${inc_day}'
      """.stripMargin
    logger.error(sql3)

    val insurance7DF = spark.sql(sql3)
    val before7Count = insurance7DF.count


    //上一天
    val before1_day  = DateUtil.getdaysBefore(inc_day,-1,"yyyyMMdd")
    val sql4 =
      s"""
        select * from dm_gis.insurance_model_duration_dist_daily_qgzh where inc_day =  '${before1_day}'
      """.stripMargin
    logger.error(sql4)
    val insurance1DF = spark.sql(sql4)
    val before1Count = insurance1DF.count



    //上周同一天
    val before_Week_day  = DateUtil.getdaysBefore(inc_day,-7,"yyyyMMdd")
    val sql5 =
      s"""
            select * from dm_gis.insurance_model_duration_dist_daily_qgzh where inc_day = '${before_Week_day}'
          """.stripMargin
    logger.error(sql5)
    val insurance7DayDF = spark.sql(sql5)
    val beforeSevenOneCount = insurance7DayDF.count


    val resultDf  =  checkDataDF
      .withColumn("tblCount",lit(countNum))
      .withColumn("changeCount",lit(changeCount))
      .withColumn("beforeOneCount",lit(before1Count))
      .withColumn("beforeSevenCount",lit(before7Count))
      .withColumn("beforeSevenOneCount",lit(beforeSevenOneCount))
      .withColumn("etl_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))


    import org.apache.spark.sql.functions._
    import spark.implicits._

    val resultDfCheck  = resultDf
      //日活（车辆数）和推送信息统计的车辆数相差大于100条
      .withColumn("isloss", ('tblCount - 'changeCount))

      //日活（车辆数）相比于前七天平均减少5%
      .withColumn("isLessServen", ('beforeSevenCount/7 - 'tblCount)/'beforeSevenCount*7)

      //或相比于前一天减少7.5%
      .withColumn("isLessOne", ('beforeOneCount - 'tblCount)/'beforeOneCount)

      //或同比上周减少5%
      .withColumn("isLessServenOne", ('beforeSevenOneCount - 'tblCount)/'beforeSevenOneCount)

      //或小于400万
      .withColumn("isLessBil", 'tblCount)

      //车均里程（total_links_dist 之和/ 车辆数） 小于150000
      .withColumn("isLinksDist", 'total_links_dist_ck)

      //车均时长（total_links_duration 之和/ 车辆数） 小于10000
      .withColumn("IsLinksDuration", 'total_links_duration_ck)

      //车均轨迹点（track_point_count 之和/ 车辆数）小于950
      .withColumn("IsPointCount", 'track_point_count_ck)


    val resultDfCheck1  = resultDfCheck
      .withColumn("isloss_zw",
        when('isloss ===1 ,concat(lit("本日日结数据接收异常,预期推送"),'changeCount,lit("条,接收"),'tblCount,lit("条"))).otherwise(lit("正常")))
      .withColumn("isLessServen_zw",
        when('isLessServen ===1 ,concat(lit("本日车辆数为"),'tblCount,lit("辆,前七天平均"),'beforeSevenCount/7,lit("辆"))).otherwise(lit("正常")))
      .withColumn("isLessOne_zw",
        when('isLessOne ===1 ,concat(lit("本日车辆数为"),'tblCount,lit("辆,前一天"),'beforeOneCount,lit("辆"))).otherwise(lit("正常")))
      .withColumn("isLessServenOne_zw",
        when('isLessServenOne ===1 ,concat(lit("本日车辆数为"),'tblCount,lit("辆,上周"),'beforeSevenOneCount,lit("辆"))).otherwise(lit("正常")))
      .withColumn("isLessBil_zw",
        when('isLessBil ===1 ,concat(lit("本日车辆数为"),'tblCount,lit("辆"))).otherwise(lit("正常")))

      .withColumn("isLinksDist_zw",
        when('isLinksDist ===1 ,concat(lit("本日车均里程异常,车均里程为"),'total_links_dist_ck,lit("米,小于预警值150000"))).otherwise(lit("正常")))
      .withColumn("IsLinksDuration_zw",
        when('IsLinksDuration ===1 ,concat(lit("本日车均时长异常,车均时长为"),'total_links_duration_ck,lit("秒,小于预警值10000"))).otherwise(lit("正常")))
      .withColumn("IsPointCount_zw",
        when('IsPointCount ===1 ,concat(lit("本日车均轨迹点数异常,车均轨迹点数为"),'track_point_count_ck,lit("点,小于预警值950"))).otherwise(lit("正常")))

      .select(
        'tblCount,
        'changeCount,
        'beforeOneCount,
        'beforeSevenCount,
        'beforeSevenOneCount,
        'isloss,
        'isloss_zw,
        'isLessServen,
        'isLessServen_zw,
        'isLessOne,
        'isLessOne_zw,
        'isLessServenOne,
        'isLessServenOne_zw,
        'isLessBil,
        'isLessBil_zw,
        'isLinksDist,
        'isLinksDist_zw,
        'IsLinksDuration,
        'IsLinksDuration_zw,
        'IsPointCount,
        'IsPointCount_zw,
        'total_links_dist_ck,
        'total_links_duration_ck,
        'track_point_count_ck,
        'etl_time,
        'inc_day)


    resultDfCheck1.show(1)
    writeToHive(spark, resultDfCheck1,Seq("inc_day") , "dm_gis.insurance_vehicle_check")

  }



}
