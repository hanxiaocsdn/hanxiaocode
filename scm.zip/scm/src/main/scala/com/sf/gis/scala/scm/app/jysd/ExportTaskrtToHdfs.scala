package com.sf.gis.scala.scm.app.jysd

import com.sf.gis.scala.scm.app.etastdlinerecallvms.ExportEtastdlinerecallvmFromHive.hdfsFileReName
import org.apache.log4j.Logger
import utils.SparkBuilder


/*
 @author 01401062 任务id 773813
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/10/25

 经验速度cross 直方图, 依赖 任务 678182,678187
*/


object ExportTaskrtToHdfs {

  @transient lazy val logger: Logger = Logger.getLogger(ExportCrossFileToHdfs.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {
    start()
  }


  def start() = {

    val sourceSql =
      s"""
      select  *
      from  dm_gis.eta_time_task_rt
      where task_inc_day  between  '20230928' and  '20231006'
       """.stripMargin


    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sourceRdd2 = spark.sql(sourceSql)

    val hdfsPath="/user/01420395/upload/data/export/eta_time_task_rt"

    val outPath = hdfsPath+"/20231007/dm_gis.eta_time_task_rt/"

      sourceRdd2.coalesce(1).write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", "\t")
      .csv(outPath)

    hdfsFileReName(spark,outPath, "eta_time_task_rt_20231007.csv")
  }
}