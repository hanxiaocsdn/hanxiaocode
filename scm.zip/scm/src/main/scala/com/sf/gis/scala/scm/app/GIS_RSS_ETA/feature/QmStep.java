//QmPoint结构体用于存储
package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

import java.util.ArrayList;
import java.util.List;


public class QmStep {
    public int   distance = 0 ;
    public float duration = 0;
    public List<QmLink> qmlinks;

    public QmStep() {
        distance = 0;
        duration = 0;
        this.qmlinks = new ArrayList<QmLink>();
    }
}
