package com.sf.gis.scala.scm.app.dcyz

import com.alibaba.fastjson.JSONObject
import common.DataSourceCommon
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.{DateUtil, SparkBuilder, SparkUtils, StringUtils}

/**
@author 01420395
@DESCRIPTION
轨迹缺失表 需求ID 1799441  单车风险评分及因子缓存_V1.0
  任务依赖：
@create 2023/04/19
  */
object DCYZMainApp extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val month_last_day = DateUtil.getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    //轨迹特征
    val featureDF = spark.sql(s"""select lpn as lpn_f
                                 |,vehicle_color as vehicle_color_f
                                 |,concat(lpn,'_',vehicle_color) as lpn_vehicle_color_f
                                 |,total_dist_yt
                                 |,total_links_dist_yt
                                 |,night_dirve_dist_yt
                                 |,before_dawn_drive_dist_yt
                                 |,early_morning_drive_dist_yt
                                 |,afternoon_drive_dist_yt
                                 |,dusk_drive_dist_yt
                                 |,high_speed_dist_yt
                                 |,state_road_dist_yt
                                 |,provincial_dist_yt
                                 |,county_dist_yt
                                 |,township_dist_yt
                                 |,dangerous_road_dist_yt
                                 |,high_accident_road_dist_yt
                                 |,school_road_dist_yt
                                 |,sharp_turn_road_dist_yt
                                 |,village_road_dist_yt
                                 |,night_high_speed_dist_yt
                                 |,night_state_road_dist_yt
                                 |,night_provincial_dist_yt
                                 |,night_county_dist_yt
                                 |,night_township_dist_yt
                                 |,before_dawn_high_speed_dist_yt
                                 |,before_dawn_state_road_dist_yt
                                 |,before_dawn_provincial_dist_yt
                                 |,before_dawn_county_dist_yt
                                 |,before_dawn_township_dist_yt
                                 |,early_morning_high_speed_dist_yt
                                 |,early_morning_state_road_dist_yt
                                 |,early_morning_provincial_dist_yt
                                 |,early_morning_county_dist_yt
                                 |,early_morning_township_dist_yt
                                 |,afternoon_high_speed_dist_yt
                                 |,afternoon_state_road_dist_yt
                                 |,afternoon_provincial_dist_yt
                                 |,afternoon_county_dist_yt
                                 |,afternoon_township_dist_yt
                                 |,dusk_high_speed_dist_yt
                                 |,dusk_state_road_dist_yt
                                 |,dusk_provincial_dist_yt
                                 |,dusk_county_dist_yt
                                 |,dusk_township_dist_yt
                                 |,night_dirve_dist_yp
                                 |,before_dawn_drive_dist_yp
                                 |,early_morning_drive_dist_yp
                                 |,afternoon_drive_dist_yp
                                 |,dusk_drive_dist_yp
                                 |,high_speed_dist_yp
                                 |,state_road_dist_yp
                                 |,provincial_dist_yp
                                 |,county_dist_yp
                                 |,township_dist_yp
                                 |,dangerous_road_dist_yp
                                 |,high_accident_road_dist_yp
                                 |,school_road_dist_yp
                                 |,sharp_turn_road_dist_yp
                                 |,village_road_dist_yp
                                 |,total_dist_ym
                                 |,night_dirve_dist_ym
                                 |,before_dawn_drive_dist_ym
                                 |,early_morning_drive_dist_ym
                                 |,afternoon_drive_dist_ym
                                 |,dusk_drive_dist_ym
                                 |,high_speed_dist_ym
                                 |,state_road_dist_ym
                                 |,provincial_dist_ym
                                 |,county_dist_ym
                                 |,township_dist_ym
                                 |,dangerous_road_dist_ym
                                 |,high_accident_road_dist_ym
                                 |,school_road_dist_ym
                                 |,sharp_turn_road_dist_ym
                                 |,village_road_dist_ym
                                 |,total_duration_yt
                                 |,total_links_duration_yt
                                 |,night_dirve_duration_yt
                                 |,before_dawn_drive_duration_yt
                                 |,early_morning_drive_duration_yt
                                 |,afternoon_drive_duration_yt
                                 |,dusk_drive_duration_yt
                                 |,high_speed_duration_yt
                                 |,state_road_duration_yt
                                 |,provincial_duration_yt
                                 |,county_duration_yt
                                 |,township_duration_yt
                                 |,dangerous_road_duration_yt
                                 |,high_accident_road_duration_yt
                                 |,school_road_duration_yt
                                 |,sharp_turn_road_duration_yt
                                 |,township_road_duration_yt
                                 |,over_speed_duration_yt
                                 |,over_speed_ser_duration_yt
                                 |,over_drive_duration_yt
                                 |,night_high_speed_duration_yt
                                 |,night_state_road_duration_yt
                                 |,night_provincial_duration_yt
                                 |,night_county_duration_yt
                                 |,night_township_duration_yt
                                 |,before_dawn_high_speed_duration_yt
                                 |,before_dawn_state_road_duration_yt
                                 |,before_dawn_provincial_duration_yt
                                 |,before_dawn_county_duration_yt
                                 |,before_dawn_township_duration_yt
                                 |,early_morning_high_speed_duration_yt
                                 |,early_morning_state_road_duration_yt
                                 |,early_morning_provincial_duration_yt
                                 |,early_morning_county_duration_yt
                                 |,early_morning_township_duration_yt
                                 |,afternoon_high_speed_duration_yt
                                 |,afternoon_state_road_duration_yt
                                 |,afternoon_provincial_duration_yt
                                 |,afternoon_county_duration_yt
                                 |,afternoon_township_duration_yt
                                 |,dusk_high_speed_duration_yt
                                 |,dusk_state_road_duration_yt
                                 |,dusk_provincial_duration_yt
                                 |,dusk_county_duration_yt
                                 |,dusk_township_duration_yt
                                 |,high_speed_lowspeed_duration_yt
                                 |,night_dirve_duration_yp
                                 |,before_dawn_drive_duration_yp
                                 |,early_morning_drive_duration_yp
                                 |,afternoon_drive_duration_yp
                                 |,dusk_drive_duration_yp
                                 |,dangerous_road_duration_yp
                                 |,high_accident_road_duration_yp
                                 |,school_road_duration_yp
                                 |,sharp_turn_road_duration_yp
                                 |,township_road_duration_yp
                                 |,over_speed_duration_yp
                                 |,over_speed_ser_duration_yp
                                 |,over_drive_duration_yp
                                 |,total_duration_ym
                                 |,night_dirve_duration_ym
                                 |,before_dawn_drive_duration_ym
                                 |,early_morning_drive_duration_ym
                                 |,afternoon_drive_duration_ym
                                 |,dusk_drive_duration_ym
                                 |,dangerous_road_duration_ym
                                 |,high_accident_road_duration_ym
                                 |,school_road_duration_ym
                                 |,sharp_turn_road_duration_ym
                                 |,township_road_duration_ym
                                 |,over_speed_duration_ym
                                 |,over_speed_ser_duration_ym
                                 |,over_drive_duration_ym
                                 |,track_eff_days
                                 |,track_eff_months
                                 |,first_track_eff_day
                                 |,lnk_cnt_yt
                                 |,dangerous_road_cnt_yt
                                 |,high_accident_road_cnt_yt
                                 |,school_road_cnt_yt
                                 |,sharp_turn_road_cnt_yt
                                 |,township_road_road_cnt_yt
                                 |,night_lnk_cnt_yt
                                 |,night_dangerous_road_cnt_yt
                                 |,night_high_accident_road_cnt_yt
                                 |,night_school_road_cnt_yt
                                 |,night_sharp_turn_road_cnt_yt
                                 |,night_township_road_road_cnt_yt
                                 |,before_dawn_lnk_cnt_yt
                                 |,before_dawn_dangerous_road_cnt_yt
                                 |,before_dawn_high_accident_road_cnt_yt
                                 |,before_dawn_school_road_cnt_yt
                                 |,before_dawn_sharp_turn_road_cnt_yt
                                 |,before_dawn_township_road_road_cnt_yt
                                 |,early_morning_lnk_cnt_yt
                                 |,early_morning_dangerous_road_cnt_yt
                                 |,early_morning_high_accident_road_cnt_yt
                                 |,early_morning_school_road_cnt_yt
                                 |,early_morning_sharp_turn_road_cnt_yt
                                 |,early_morning_township_road_road_cnt_yt
                                 |,afternoon_lnk_cnt_yt
                                 |,afternoon_dangerous_road_cnt_yt
                                 |,afternoon_high_accident_road_cnt_yt
                                 |,afternoon_school_road_cnt_yt
                                 |,afternoon_sharp_turn_road_cnt_yt
                                 |,afternoon_township_road_road_cnt_yt
                                 |,dusk_lnk_cnt_yt
                                 |,dusk_dangerous_road_cnt_yt
                                 |,dusk_high_accident_road_cnt_yt
                                 |,dusk_school_road_cnt_yt
                                 |,dusk_sharp_turn_road_cnt_yt
                                 |,dusk_township_road_road_cnt_yt
                                 |,operation_cnt_yt
                                 |,operation_same_city_cnt_yt
                                 |,operation_same_prov_cnt_yt
                                 |,lnk_cnt_ym
                                 |,dangerous_road_cnt_ym
                                 |,high_accident_road_cnt_ym
                                 |,school_road_cnt_ym
                                 |,sharp_turn_road_cnt_ym
                                 |,township_road_road_cnt_ym
                                 |,operation_cnt_ym
                                 |,operation_same_city_cnt_ym
                                 |,adcode_dura_prov_y1
                                 |,adcode_dura_prov_cnt_y1
                                 |,adcode_dura_prov_y2
                                 |,adcode_dura_prov_cnt_y2
                                 |,adcode_dura_prov_y3
                                 |,adcode_dura_prov_cnt_y3
                                 |,adcode_dist_prov_y1
                                 |,adcode_dist_prov_dist_y1
                                 |,adcode_dist_prov_y2
                                 |,adcode_dist_prov_dist_y2
                                 |,adcode_dist_prov_y3
                                 |,adcode_dist_prov_dist_y3
                                 |,adcode_prov_y1
                                 |,adcode_prov_cnt_y1
                                 |,adcode_prov_y2
                                 |,adcode_prov_cnt_y2
                                 |,adcode_prov_y3
                                 |,adcode_prov_cnt_y3
                                 |,adcode_dura_city_y1
                                 |,adcode_dura_city_duration_y1
                                 |,adcode_dura_city_y2
                                 |,adcode_dura_city_duration_y2
                                 |,adcode_dura_city_y3
                                 |,adcode_dura_city_duration_y3
                                 |,adcode_dist_city_y1
                                 |,adcode_dist_city_dist_y1
                                 |,adcode_dist_city_y2
                                 |,adcode_dist_city_dist_y2
                                 |,adcode_dist_city_y3
                                 |,adcode_dist_city_dist_y3
                                 |,adcode_city_y1
                                 |,adcode_city_cnt_y1
                                 |,adcode_city_y2
                                 |,adcode_city_cnt_y2
                                 |,adcode_city_y3
                                 |,adcode_city_cnt_y3
                                 |,inc_day
                                 |,months_flag
                                 | from  dm_gis.dwd_insurance_model_duration_dist_qgzh_year_feature_dtl
                                 | where inc_day  = ${month_last_day}
                                 | """
      .stripMargin)

    logger.error("特征信息" + featureDF.count())

    //车辆基础信息
    val vehicle_basics_originalDF = spark.sql(
      """
        |     select vin vin_b,vehicle_age vehicle_age_b,
        |      original_value_vehicle original_value_vehicle_b,company_name company_name_b,
        |      vehicle_type vehicle_type_b,brand_name brand_name_b,vehicle_weight vehicle_weight_b,
        |      full_weight full_weight_b,ratified_load_capacity ratified_load_capacity_b,track_front track_front_b,
        |      track_rear track_rear_b,tire_number tire_number_b,
        |      tire_specification tire_specification_b,wheel_base wheel_base_b,wheel_number wheel_number_b,
        |      long_profile_size long_profile_size_b,wide_profile_size wide_profile_size_b,
        |      height_profile_size height_profile_size_b,fuel_type fuel_type_b,effluent_standard effluent_standard_b,
        |      vehicle_model vehicle_model_b,data_sources data_sources_b
        |    from dm_gis.insurance_vehicle_basics_original
      """.stripMargin)

    logger.error("车辆基础信息" + vehicle_basics_originalDF.count())
    //车型基础信息
    val vehicle_model_originalDF = spark.sql(
      """
        |select vehicle_typecode as vehicle_typecode_m
        |,vehicle_age as vehicle_age_m
        |,original_value_vehicle  as original_value_vehicle_m
        |,company_name  as company_name_m
        |,vehicle_type  as vehicle_type_m
        |,brand_name  as brand_name_m
        |,vehicle_weight  as vehicle_weight_m
        |,full_weight  as full_weight_m
        |,ratified_load_capacity  as ratified_load_capacity_m
        |,track_front  as track_front_m
        |,track_rear  as track_rear_m
        |,tire_number  as tire_number_m
        |,tire_specification  as tire_specification_m
        |,wheel_base  as wheel_base_m
        |,wheel_number  as wheel_number_m
        |,long_profile_size  as long_profile_size_m
        |,wide_profile_size  as wide_profile_size_m
        |,height_profile_size  as height_profile_size_m
        |,fuel_type  as fuel_type_m
        |,effluent_standard  as effluent_standard_m
        |,vehicle_model  as vehicle_model_m
        |from dm_gis.insurance_vehicle_model_original where  is_type_ok = 1
      """.stripMargin
    )
    logger.error("车型信息" + vehicle_model_originalDF.count())

    //全国车辆信息库 车型代码 取VIN前八位及第十、十一位，LZZ8BCML3LC298419
    val vehicleDF = spark.sql("select lpn as lpn_v ,vehicle_color as vehicle_color_v, " +
      "concat(lpn,'_',vehicle_color) as lpn_vehicle_color_v" +
      ",vin as vin_v, concat(subStr(vin,0,8),subStr(vin,10,2)) as vehicle_typecode_v " +
      s"from dm_gis.insurance_vehicle_original where inc_day  = ${inc_day}")

    logger.error("车辆信息" + vehicleDF.count())
    import org.apache.spark.sql.functions._
    import spark.implicits._

    //关联车辆信息数据
    val vehicleJionBasicOrModelDF = vehicleDF
      .join(vehicle_basics_originalDF,$"vin_v" === $"vin_b","left") //车辆信息
      .join(vehicle_model_originalDF,$"vehicle_typecode_v"===$"vehicle_typecode_m","left") //车型信息

    val vehicleJionBasicOrModelDF1 = vehicleJionBasicOrModelDF
      .withColumn("isMateVin",when('vin_b isNotNull ,lit("0")).otherwise(lit("1")))
      .withColumn("isMateVehicleTypeCode",when('vehicle_typecode_m isNotNull ,lit("0")).otherwise(lit("1")))

    //货车打标识
    val vehicleJionBasicOrModelDFJsonRdd = SparkUtils.getRowToJson(vehicleJionBasicOrModelDF1,100)
    val vehicleJionBasicOrModelDFJsonRdd1 = vehicleJionBasicOrModelDFJsonRdd.map(row => {
      //车辆是否匹配上
      val isMateVin = row.getString("isMateVin")
      val isMateVehicleTypeCode = row.getString("isMateVehicleTypeCode")

      val vehicleJsonObject = new JSONObject()
      vehicleJsonObject.put("lpn", row.getString("lpn_v"))
      vehicleJsonObject.put("vehicle_color", row.getString("vehicle_color_v"))
      vehicleJsonObject.put("lpn_vehicle_color", row.getString("lpn_vehicle_color_v"))
      vehicleJsonObject.put("vin", row.getString("vin_v"))
      vehicleJsonObject.put("vehicle_typecode", row.getString("vehicle_typecode_v"))
      vehicleJsonObject.put("vehicle_age", "")
      vehicleJsonObject.put("original_value_vehicle", "")
      vehicleJsonObject.put("company_name", "")
      vehicleJsonObject.put("vehicle_type", "")
      vehicleJsonObject.put("brand_name", "")
      vehicleJsonObject.put("vehicle_weight", "")
      vehicleJsonObject.put("full_weight", "")
      vehicleJsonObject.put("ratified_load_capacity", "")
      vehicleJsonObject.put("track_front", "")
      vehicleJsonObject.put("track_rear", "")
      vehicleJsonObject.put("tire_number", "")
      vehicleJsonObject.put("tire_specification", "")
      vehicleJsonObject.put("wheel_base", "")
      vehicleJsonObject.put("wheel_number", "")
      vehicleJsonObject.put("long_profile_size", "")
      vehicleJsonObject.put("wide_profile_size", "")
      vehicleJsonObject.put("height_profile_size", "")
      vehicleJsonObject.put("fuel_type", "")
      vehicleJsonObject.put("effluent_standard", "")
      vehicleJsonObject.put("vehicle_model", "")
      vehicleJsonObject.put("hasVehicleInfo", "1")
      vehicleJsonObject.put("weight_vehicle_model", "99")

      vehicleJsonObject.put("wxpfType", "")//默认是无效


      var hasVehicleInfo = "2" //默认标记无效评分原因是 2-无车辆基础信息
      //匹配车辆信息 1.有车辆信息 2.有车型信息
      if ("0".equalsIgnoreCase(isMateVin)) {
        hasVehicleInfo = "0"
        vehicleJsonObject.put("vehicle_age", row.getString("vehicle_age_b"))
        vehicleJsonObject.put("original_value_vehicle", row.getString("original_value_vehicle_b"))
        vehicleJsonObject.put("company_name", row.getString("company_name_b"))
        vehicleJsonObject.put("vehicle_type", row.getString("vehicle_type_b"))
        vehicleJsonObject.put("brand_name", row.getString("brand_name_b"))
        vehicleJsonObject.put("vehicle_weight", row.getString("vehicle_weight_b"))
        vehicleJsonObject.put("full_weight", row.getString("full_weight_b"))
        vehicleJsonObject.put("ratified_load_capacity", row.getString("ratified_load_capacity_b"))
        vehicleJsonObject.put("track_front", row.getString("track_front_b"))
        vehicleJsonObject.put("track_rear", row.getString("track_rear_b"))
        vehicleJsonObject.put("tire_number", row.getString("tire_number_b"))
        vehicleJsonObject.put("tire_specification", row.getString("tire_specification_b"))
        vehicleJsonObject.put("wheel_base", row.getString("wheel_base_b"))
        vehicleJsonObject.put("wheel_number", row.getString("wheel_number_b"))
        vehicleJsonObject.put("long_profile_size", row.getString("long_profile_size_b"))
        vehicleJsonObject.put("wide_profile_size", row.getString("wide_profile_size_b"))
        vehicleJsonObject.put("height_profile_size", row.getString("height_profile_size_b"))
        vehicleJsonObject.put("fuel_type", row.getString("fuel_type_b"))
        vehicleJsonObject.put("effluent_standard", row.getString("effluent_standard_b"))
        vehicleJsonObject.put("vehicle_model", row.getString("vehicle_model_b"))
        vehicleJsonObject.put("hasVehicleInfo",hasVehicleInfo)
        vehicleJsonObject.put("wxpfType", "0")
      } else {
        //车型是否匹配
        if ("0".equalsIgnoreCase(isMateVehicleTypeCode)) {
          hasVehicleInfo = "0"
          vehicleJsonObject.put("vehicle_age", row.getString("vehicle_age_m"))
          vehicleJsonObject.put("original_value_vehicle", row.getString("original_value_vehicle_m"))
          vehicleJsonObject.put("company_name", row.getString("company_name_m"))
          vehicleJsonObject.put("vehicle_type", row.getString("vehicle_type_m"))
          vehicleJsonObject.put("brand_name", row.getString("brand_name_m"))
          vehicleJsonObject.put("vehicle_weight", row.getString("vehicle_weight_m"))
          vehicleJsonObject.put("full_weight", row.getString("full_weight_m"))
          vehicleJsonObject.put("ratified_load_capacity", row.getString("ratified_load_capacity_m"))
          vehicleJsonObject.put("track_front", row.getString("track_front_m"))
          vehicleJsonObject.put("track_rear", row.getString("track_rear_m"))
          vehicleJsonObject.put("tire_number", row.getString("tire_number_m"))
          vehicleJsonObject.put("tire_specification", row.getString("tire_specification_m"))
          vehicleJsonObject.put("wheel_base", row.getString("wheel_base_m"))
          vehicleJsonObject.put("wheel_number", row.getString("wheel_number_m"))
          vehicleJsonObject.put("long_profile_size", row.getString("long_profile_size_m"))
          vehicleJsonObject.put("wide_profile_size", row.getString("wide_profile_size_m"))
          vehicleJsonObject.put("height_profile_size", row.getString("height_profile_size_m"))
          vehicleJsonObject.put("fuel_type", row.getString("fuel_type_m"))
          vehicleJsonObject.put("effluent_standard", row.getString("effluent_standard_m"))
          vehicleJsonObject.put("vehicle_model", row.getString("vehicle_model_m"))
          vehicleJsonObject.put("hasVehicleInfo",hasVehicleInfo)
          vehicleJsonObject.put("wxpfType", "0")
        }else{
          vehicleJsonObject.put("wxpfType", "2")
        }
      }
      //3.模型车分类
      if("0".equalsIgnoreCase(hasVehicleInfo)){
        val vehicleType = vehicleJsonObject.getString("vehicle_type")
        val vehicleWeight_str = vehicleJsonObject.getString("vehicle_weight")
        var vehicleWeight = 0.00
        if(!StringUtils.isEmpty(vehicleWeight_str)){
          vehicleWeight = vehicleWeight_str.toFloat
        }

        val ratifiedLoadCapaCity_str = vehicleJsonObject.getString("ratified_load_capacity")
        var ratifiedLoadCapacity = 0.00
        if(!StringUtils.isEmpty(ratifiedLoadCapaCity_str)){
          ratifiedLoadCapacity = ratifiedLoadCapaCity_str.toFloat
        }

        var vehicleModeType = "99" //默认是非模型
        if(!StringUtils.isEmpty(vehicleType) && !(vehicleType.indexOf("轿车")>=0||vehicleType.indexOf("客车")>=0
          ||vehicleType.indexOf("小型汽车")>=0||vehicleType.indexOf("校车")>=0
          ||vehicleType.indexOf("乘用车")>=0)){

          if(vehicleWeight >= 12000  ||  ratifiedLoadCapacity>=8000){
            vehicleModeType = "2"
            if(vehicleType.indexOf("牵引")>=0){
              vehicleModeType = "3"
            }
          }else {
            vehicleModeType = "1"
          }
        }else{
          if(!StringUtils.isEmpty(vehicleType) && "多用途乘用车".equalsIgnoreCase(vehicleType)){
            vehicleModeType = "1"
          }else{
            vehicleModeType = "99"
          }
        }
        vehicleJsonObject.put("weight_vehicle_model", vehicleModeType)
        if("1".equalsIgnoreCase(vehicleModeType)|| "99".equalsIgnoreCase(vehicleModeType)){
          vehicleJsonObject.put("wxpfType", "3")
        }else{
          vehicleJsonObject.put("wxpfType", "0")
        }
      }

      //是否有效评分

      //转换
      Row.fromSeq( List(
        vehicleJsonObject.getString("lpn")
        ,vehicleJsonObject.getString("vehicle_color")
        ,vehicleJsonObject.getString("lpn_vehicle_color")
        ,vehicleJsonObject.getString("vin")
        ,vehicleJsonObject.getString("vehicle_typecode")
        ,vehicleJsonObject.getString("vehicle_age")
        ,vehicleJsonObject.getString("original_value_vehicle")
        ,vehicleJsonObject.getString("company_name")
        ,vehicleJsonObject.getString("vehicle_type")
        ,vehicleJsonObject.getString("brand_name")
        ,vehicleJsonObject.getString("vehicle_weight")
        ,vehicleJsonObject.getString("full_weight")
        ,vehicleJsonObject.getString("ratified_load_capacity")
        ,vehicleJsonObject.getString("track_front")
        ,vehicleJsonObject.getString("track_rear")
        ,vehicleJsonObject.getString("tire_number")
        ,vehicleJsonObject.getString("tire_specification")
        ,vehicleJsonObject.getString("wheel_base")
        ,vehicleJsonObject.getString("wheel_number")
        ,vehicleJsonObject.getString("long_profile_size")
        ,vehicleJsonObject.getString("wide_profile_size")
        ,vehicleJsonObject.getString("height_profile_size")
        ,vehicleJsonObject.getString("fuel_type")
        ,vehicleJsonObject.getString("effluent_standard")
        ,vehicleJsonObject.getString("vehicle_model")
        ,vehicleJsonObject.getString("hasVehicleInfo")
        ,vehicleJsonObject.getString("weight_vehicle_model")
        ,vehicleJsonObject.getString("wxpfType")

      ))
    })


    val schame =StructType(
      List(
        StructField("lpn", StringType, true)
        ,StructField("vehicle_color", StringType, true)
        ,StructField("lpn_vehicle_color", StringType, true)
        ,StructField("vin", StringType, true)
        ,StructField("vehicle_typecode", StringType, true)
        ,StructField("vehicle_age", StringType, true)
        ,StructField("original_value_vehicle", StringType, true)
        ,StructField("company_name", StringType, true)
        ,StructField("vehicle_type", StringType, true)
        ,StructField("brand_name", StringType, true)
        ,StructField("vehicle_weight", StringType, true)
        ,StructField("full_weight", StringType, true)
        ,StructField("ratified_load_capacity", StringType, true)
        ,StructField("track_front", StringType, true)
        ,StructField("track_rear", StringType, true)
        ,StructField("tire_number", StringType, true)
        ,StructField("tire_specification", StringType, true)
        ,StructField("wheel_base", StringType, true)
        ,StructField("wheel_number", StringType, true)
        ,StructField("long_profile_size", StringType, true)
        ,StructField("wide_profile_size", StringType, true)
        ,StructField("height_profile_size", StringType, true)
        ,StructField("fuel_type", StringType, true)
        ,StructField("effluent_standard", StringType, true)
        ,StructField("vehicle_model", StringType, true)
        ,StructField("hasVehicleInfo", StringType, true)
        ,StructField("weight_vehicle_model", StringType, true)
        ,StructField("wxpfType", StringType, true)

      )
    )
    val vehicleDf =  spark.createDataFrame(vehicleJionBasicOrModelDFJsonRdd1,schame)

    logger.error(vehicleDf.count())
    vehicleDf.show(1,false)

    //关联轨迹数据

    val vehicleJionYearFeatureDF  = vehicleDf.join(featureDF,'lpn_vehicle_color === 'lpn_vehicle_color_f,"left")  //轨迹信息
    val vehicleJionYearFeatureDF1 =  vehicleJionYearFeatureDF
      .withColumn("isYearFeatureFlag", when('lpn_vehicle_color_f isNotNull , lit("0")).otherwise("1"))
      .withColumn("inc_day", lit(month_last_day))


    val resultRdd =  vehicleJionYearFeatureDF1.select(
      'vin
      ,'vehicle_typecode
      ,'vehicle_age
      ,'original_value_vehicle
      ,'company_name
      ,'vehicle_type
      ,'brand_name
      ,'vehicle_weight
      ,'full_weight
      ,'ratified_load_capacity
      ,'track_front
      ,'track_rear
      ,'tire_number
      ,'tire_specification
      ,'wheel_base
      ,'wheel_number
      ,'long_profile_size
      ,'wide_profile_size
      ,'height_profile_size
      ,'fuel_type
      ,'effluent_standard
      ,'vehicle_model
      ,'hasVehicleInfo
      ,'weight_vehicle_model
      ,'isYearFeatureFlag
      ,'lpn
      ,'vehicle_color
      ,'total_dist_yt
      ,'total_links_dist_yt
      ,'night_dirve_dist_yt
      ,'before_dawn_drive_dist_yt
      ,'early_morning_drive_dist_yt
      ,'afternoon_drive_dist_yt
      ,'dusk_drive_dist_yt
      ,'high_speed_dist_yt
      ,'state_road_dist_yt
      ,'provincial_dist_yt
      ,'county_dist_yt
      ,'township_dist_yt
      ,'dangerous_road_dist_yt
      ,'high_accident_road_dist_yt
      ,'school_road_dist_yt
      ,'sharp_turn_road_dist_yt
      ,'village_road_dist_yt
      ,'night_high_speed_dist_yt
      ,'night_state_road_dist_yt
      ,'night_provincial_dist_yt
      ,'night_county_dist_yt
      ,'night_township_dist_yt
      ,'before_dawn_high_speed_dist_yt
      ,'before_dawn_state_road_dist_yt
      ,'before_dawn_provincial_dist_yt
      ,'before_dawn_county_dist_yt
      ,'before_dawn_township_dist_yt
      ,'early_morning_high_speed_dist_yt
      ,'early_morning_state_road_dist_yt
      ,'early_morning_provincial_dist_yt
      ,'early_morning_county_dist_yt
      ,'early_morning_township_dist_yt
      ,'afternoon_high_speed_dist_yt
      ,'afternoon_state_road_dist_yt
      ,'afternoon_provincial_dist_yt
      ,'afternoon_county_dist_yt
      ,'afternoon_township_dist_yt
      ,'dusk_high_speed_dist_yt
      ,'dusk_state_road_dist_yt
      ,'dusk_provincial_dist_yt
      ,'dusk_county_dist_yt
      ,'dusk_township_dist_yt
      ,'night_dirve_dist_yp
      ,'before_dawn_drive_dist_yp
      ,'early_morning_drive_dist_yp
      ,'afternoon_drive_dist_yp
      ,'dusk_drive_dist_yp
      ,'high_speed_dist_yp
      ,'state_road_dist_yp
      ,'provincial_dist_yp
      ,'county_dist_yp
      ,'township_dist_yp
      ,'dangerous_road_dist_yp
      ,'high_accident_road_dist_yp
      ,'school_road_dist_yp
      ,'sharp_turn_road_dist_yp
      ,'village_road_dist_yp
      ,'total_dist_ym
      ,'night_dirve_dist_ym
      ,'before_dawn_drive_dist_ym
      ,'early_morning_drive_dist_ym
      ,'afternoon_drive_dist_ym
      ,'dusk_drive_dist_ym
      ,'high_speed_dist_ym
      ,'state_road_dist_ym
      ,'provincial_dist_ym
      ,'county_dist_ym
      ,'township_dist_ym
      ,'dangerous_road_dist_ym
      ,'high_accident_road_dist_ym
      ,'school_road_dist_ym
      ,'sharp_turn_road_dist_ym
      ,'village_road_dist_ym
      ,'total_duration_yt
      ,'total_links_duration_yt
      ,'night_dirve_duration_yt
      ,'before_dawn_drive_duration_yt
      ,'early_morning_drive_duration_yt
      ,'afternoon_drive_duration_yt
      ,'dusk_drive_duration_yt
      ,'high_speed_duration_yt
      ,'state_road_duration_yt
      ,'provincial_duration_yt
      ,'county_duration_yt
      ,'township_duration_yt
      ,'dangerous_road_duration_yt
      ,'high_accident_road_duration_yt
      ,'school_road_duration_yt
      ,'sharp_turn_road_duration_yt
      ,'township_road_duration_yt
      ,'over_speed_duration_yt
      ,'over_speed_ser_duration_yt
      ,'over_drive_duration_yt
      ,'night_high_speed_duration_yt
      ,'night_state_road_duration_yt
      ,'night_provincial_duration_yt
      ,'night_county_duration_yt
      ,'night_township_duration_yt
      ,'before_dawn_high_speed_duration_yt
      ,'before_dawn_state_road_duration_yt
      ,'before_dawn_provincial_duration_yt
      ,'before_dawn_county_duration_yt
      ,'before_dawn_township_duration_yt
      ,'early_morning_high_speed_duration_yt
      ,'early_morning_state_road_duration_yt
      ,'early_morning_provincial_duration_yt
      ,'early_morning_county_duration_yt
      ,'early_morning_township_duration_yt
      ,'afternoon_high_speed_duration_yt
      ,'afternoon_state_road_duration_yt
      ,'afternoon_provincial_duration_yt
      ,'afternoon_county_duration_yt
      ,'afternoon_township_duration_yt
      ,'dusk_high_speed_duration_yt
      ,'dusk_state_road_duration_yt
      ,'dusk_provincial_duration_yt
      ,'dusk_county_duration_yt
      ,'dusk_township_duration_yt
      ,'high_speed_lowspeed_duration_yt
      ,'night_dirve_duration_yp
      ,'before_dawn_drive_duration_yp
      ,'early_morning_drive_duration_yp
      ,'afternoon_drive_duration_yp
      ,'dusk_drive_duration_yp
      ,'dangerous_road_duration_yp
      ,'high_accident_road_duration_yp
      ,'school_road_duration_yp
      ,'sharp_turn_road_duration_yp
      ,'township_road_duration_yp
      ,'over_speed_duration_yp
      ,'over_speed_ser_duration_yp
      ,'over_drive_duration_yp
      ,'total_duration_ym
      ,'night_dirve_duration_ym
      ,'before_dawn_drive_duration_ym
      ,'early_morning_drive_duration_ym
      ,'afternoon_drive_duration_ym
      ,'dusk_drive_duration_ym
      ,'dangerous_road_duration_ym
      ,'high_accident_road_duration_ym
      ,'school_road_duration_ym
      ,'sharp_turn_road_duration_ym
      ,'township_road_duration_ym
      ,'over_speed_duration_ym
      ,'over_speed_ser_duration_ym
      ,'over_drive_duration_ym
      ,'track_eff_days
      ,'track_eff_months
      ,'first_track_eff_day
      ,'lnk_cnt_yt
      ,'dangerous_road_cnt_yt
      ,'high_accident_road_cnt_yt
      ,'school_road_cnt_yt
      ,'sharp_turn_road_cnt_yt
      ,'township_road_road_cnt_yt
      ,'night_lnk_cnt_yt
      ,'night_dangerous_road_cnt_yt
      ,'night_high_accident_road_cnt_yt
      ,'night_school_road_cnt_yt
      ,'night_sharp_turn_road_cnt_yt
      ,'night_township_road_road_cnt_yt
      ,'before_dawn_lnk_cnt_yt
      ,'before_dawn_dangerous_road_cnt_yt
      ,'before_dawn_high_accident_road_cnt_yt
      ,'before_dawn_school_road_cnt_yt
      ,'before_dawn_sharp_turn_road_cnt_yt
      ,'before_dawn_township_road_road_cnt_yt
      ,'early_morning_lnk_cnt_yt
      ,'early_morning_dangerous_road_cnt_yt
      ,'early_morning_high_accident_road_cnt_yt
      ,'early_morning_school_road_cnt_yt
      ,'early_morning_sharp_turn_road_cnt_yt
      ,'early_morning_township_road_road_cnt_yt
      ,'afternoon_lnk_cnt_yt
      ,'afternoon_dangerous_road_cnt_yt
      ,'afternoon_high_accident_road_cnt_yt
      ,'afternoon_school_road_cnt_yt
      ,'afternoon_sharp_turn_road_cnt_yt
      ,'afternoon_township_road_road_cnt_yt
      ,'dusk_lnk_cnt_yt
      ,'dusk_dangerous_road_cnt_yt
      ,'dusk_high_accident_road_cnt_yt
      ,'dusk_school_road_cnt_yt
      ,'dusk_sharp_turn_road_cnt_yt
      ,'dusk_township_road_road_cnt_yt
      ,'operation_cnt_yt
      ,'operation_same_city_cnt_yt
      ,'operation_same_prov_cnt_yt
      ,'lnk_cnt_ym
      ,'dangerous_road_cnt_ym
      ,'high_accident_road_cnt_ym
      ,'school_road_cnt_ym
      ,'sharp_turn_road_cnt_ym
      ,'township_road_road_cnt_ym
      ,'operation_cnt_ym
      ,'operation_same_city_cnt_ym
      ,'adcode_dura_prov_y1
      ,'adcode_dura_prov_cnt_y1
      ,'adcode_dura_prov_y2
      ,'adcode_dura_prov_cnt_y2
      ,'adcode_dura_prov_y3
      ,'adcode_dura_prov_cnt_y3
      ,'adcode_dist_prov_y1
      ,'adcode_dist_prov_dist_y1
      ,'adcode_dist_prov_y2
      ,'adcode_dist_prov_dist_y2
      ,'adcode_dist_prov_y3
      ,'adcode_dist_prov_dist_y3
      ,'adcode_prov_y1
      ,'adcode_prov_cnt_y1
      ,'adcode_prov_y2
      ,'adcode_prov_cnt_y2
      ,'adcode_prov_y3
      ,'adcode_prov_cnt_y3
      ,'adcode_dura_city_y1
      ,'adcode_dura_city_duration_y1
      ,'adcode_dura_city_y2
      ,'adcode_dura_city_duration_y2
      ,'adcode_dura_city_y3
      ,'adcode_dura_city_duration_y3
      ,'adcode_dist_city_y1
      ,'adcode_dist_city_dist_y1
      ,'adcode_dist_city_y2
      ,'adcode_dist_city_dist_y2
      ,'adcode_dist_city_y3
      ,'adcode_dist_city_dist_y3
      ,'adcode_city_y1
      ,'adcode_city_cnt_y1
      ,'adcode_city_y2
      ,'adcode_city_cnt_y2
      ,'adcode_city_y3
      ,'adcode_city_cnt_y3
      ,'months_flag
      ,'inc_day
    )

    writeToHive(spark,resultRdd,Seq("inc_day"),"dm_gis.insurance_Bicycle_factor")
  }
}
