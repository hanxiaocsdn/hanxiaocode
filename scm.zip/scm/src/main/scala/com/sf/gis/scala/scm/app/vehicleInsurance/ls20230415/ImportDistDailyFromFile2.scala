package com.sf.gis.scala.scm.app.vehicleInsurance.ls20230415

import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.SparkBuilder

object ImportDistDailyFromFile2{

  @transient lazy val logger: Logger = Logger.getLogger(ImportDistDailyFromFile2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val start_date = args(0)
    writetoHiveTbleods_track_yy_di_20230415_y(start_date)
    writetoHiveTblegis_vms_track_device_track_flatmap(start_date)
  }

  def writetoHiveTblegis_vms_track_device_track_flatmap(inc_day:String): Unit ={
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val vehicle_df = spark.sql(
      s"""
         |select  car_no as un
         |    ,'1' tp
         |    ,lng zx
         |    ,lat zy
         |    ,'' ac
         |    ,'' ad
         |    ,'' be
         |    ,'' sl
         |    ,'' sp
         |    ,tm tm
         |    ,'' sc
         |    ,'' bt
         |    ,'A10000' ak
         |    ,'' dx
         |    ,'' dy
         |    ,'' state
         |    ,'' pc
         |    ,'' ewl
         |    ,'' bk
         |    ,'' bk2
         |    ,'' bk3
         | , inc_day
         |from dm_gis.ods_track_yy_di_20230415_y where inc_day ='${inc_day}'
      """.stripMargin)

    writeToHive(spark, vehicle_df, Seq("inc_day"), "dm_gis.gis_vms_track_device_track_flatmap_20230416")
  }


  //  car_no,lng,lat,tm,inc_day,biz_week
  def writetoHiveTbleods_track_yy_di_20230415_y(biz_date:String): Unit ={

    val cols = Seq("car_no"
      ,"lng"
      ,"lat"
      ,"tm"
      ,"inc_day"
      ,"biz_week")

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    import spark.implicits._
    val inputPath = "/user/01420395/upload/FT20230019/1611146/ods_track_yy_di_20230415_y/" +biz_date +"/" + biz_date + ".csv"
    val vehicle_df = spark.read.option("header", "false")
      .option("delimiter", ",")
      .option("inferSchema", true)
      .option("numPartitions", 2)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select('car_no,'lng,'lat,'tm,'biz_week,'inc_day)

    writeToHive(spark, vehicle_df, Seq("inc_day"), "dm_gis.ods_track_yy_di_20230415_y")
  }


  @Override
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"""insert overwrite table %s partition($parCols) select * from tmpTableName""",resTableName)
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }



}
