package com.sf.gis.scala.scm.app.vehicleInsurance.ls20230415

import common.DataSourceCommon
import utils.{RedisUtils, StringUtils}

/**
  * @description: 车辆风险安全year特征值表 征征期期到redis
  * @author 01420395 caiguofang
  * @date 2023/4/2
  */

object WriteVehicleInsuranceDateToRedis extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val inc_day = args(0)

    //redis 写入日期数据  YEARFEATURE_INCDAY 20230328
    val add = "gis-ass-adds-type-data1.cache.sfdc.com.cn:8001,gis-ass-adds-type-data2.cache.sfdc.com.cn:8001,gis-ass-adds-type-data3.cache.sfdc.com.cn:8001"
    val pd= "cnzifff5lf2csdvp"
    val materNam="GIS_ASS_ADDS_REDIS_TYPE_DATA_C01"
    val pool = RedisUtils.initJedisTestPool(add,materNam,pd)
    val jedis = pool.getResource

    var incDay = jedis.get("YEARFEATURE_INCDAY")

    if(StringUtils.isEmpty(incDay)){
      incDay = "0"
    }

    logger.error(inc_day + ">>>>  当前的 YEARFEATURE_INCDAY >>> " + incDay)
    if(Integer.parseInt(incDay) < Integer.parseInt(inc_day)){
      logger.error(s"dbSize:${jedis.dbSize()}")
      jedis.set("YEARFEATURE_INCDAY", inc_day)
      logger.error( jedis.get("YEARFEATURE_INCDAY"))
    }

    pool.close()
  }

}
