package com.sf.gis.scala.scm.app.jysd

import com.sf.gis.scala.scm.app.etastdlinerecallvms.ExportEtastdlinerecallvmFromHive.hdfsFileReName
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.col
import utils.SparkBuilder


/*
 @author 01401062 任务id 773813
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/10/25

 经验速度cross 直方图, 依赖 任务 678182,678187
*/


object ExportResult2ToHdfs {

  @transient lazy val logger: Logger = Logger.getLogger(ExportCrossFileToHdfs.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {
    start()
  }


  def start() = {

    val sourceSql =
      s"""
      select  id
      ,src_province
      ,src_citycode
      ,src_deptcode
      ,dest_province
      ,dest_citycode
      ,dest_deptcode
      ,navi_distance
      ,similarity1
      ,similarity5
      ,t1
      ,yaw_time
      ,trackstart_distance
      ,trackend_distance
      ,gdsimilarity1
      ,gdsimilarity5
      ,yaw_time2
      ,start_dept
      ,end_dept
      ,vehicle_type_navi
      ,stdmatchtype
      ,passzonetype
      ,cachestdid
      ,linerequireid
      ,passzonetableid
      ,cachestdblockroad
      ,nostdreasontype
      ,nostdreasondetail
      ,inc_day
      from  dm_gis.gis_navi_eta_result2
      where inc_day  between  '20230926' and  '20231006'
       """.stripMargin




    val sourceSql1 =
      s"""
      select  id
      ,task_id
      ,navi_id
      ,routeid
      ,request_id
      ,navi_starttime
      ,starttime_type
      ,req_time
      ,navi_endtime
      ,req_type
      from  dm_gis.gis_navi_eta_result1
      where inc_day  between  '20230926' and  '20231006'
       """.stripMargin


    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sourceRdd2 = spark.sql(sourceSql)

    val sourceRdd1 = spark.sql(sourceSql1)

    val cols = Seq("task_id")

    val inputPath = "/user/01420395/upload/20231007.csv"
    val taskDF = spark.read.option("header", "false")
      .option("delimiter", "\\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*).drop("tab").distinct()

    import spark.implicits._

    val sourceRdd3=sourceRdd1
      .join(taskDF, Seq("task_id"),"inner")
      .join(sourceRdd2, Seq("id"),"left")
      .select('id
        ,'task_id
        ,'navi_id
        ,'routeid
        ,'request_id
        ,'navi_starttime
        ,'starttime_type
        ,'req_time
        ,'navi_endtime
        ,'req_type
        ,'src_province
        ,'src_citycode
        ,'src_deptcode
        ,'dest_province
        ,'dest_citycode
        ,'dest_deptcode
        ,'navi_distance
        ,'similarity1
        ,'similarity5
        ,'t1
        ,'yaw_time
        ,'trackstart_distance
        ,'trackend_distance
        ,'gdsimilarity1
        ,'gdsimilarity5
        ,'yaw_time2
        ,'start_dept
        ,'end_dept
        ,'vehicle_type_navi
        ,'stdmatchtype
        ,'passzonetype
        ,'cachestdid
        ,'linerequireid
        ,'passzonetableid
        ,'cachestdblockroad
        ,'nostdreasontype
        ,'nostdreasondetail
        ,'inc_day).distinct()

    val hdfsPath="/user/01420395/upload/data/export/result2"

    val outPath = hdfsPath+"/20231007/dm_gis.gis_navi_eta_result2/"

    sourceRdd3.coalesce(1).write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", "\t")
      .csv(outPath)

    hdfsFileReName(spark,outPath, "gis_navi_eta_result2_20231007.csv")
  }
}