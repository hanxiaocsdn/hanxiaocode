package com.sf.gis.scala.scm.app.GIS_RSS_SCM

import common.DataSourceCommon

import java.io.File
import net.lingala.zip4j.ZipFile


/**
  * GIS_RSS_SCM：【北京违章扣罚】北京区违章信息获取的线上化_V1.0, 需求id 2017326
  *
  *@author 01420395
  * 任务id: 831556
  *@DESCRIPTION ${DESCRIPTION}
  *@create 20230918
  */
object ImportbjWeiZhangToHDFS  extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    var homePath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath;
    val fileName = s"qb_BJ122_${inc_day}.zip"

    homePath =  homePath.substring(0, homePath.lastIndexOf(File.separator))
    val inputPath = s"${homePath}/${fileName}"
    logger.error(inputPath)

    val zipFile= new ZipFile(inputPath,"bj122".toCharArray)
    zipFile.extractAll(s"${homePath}/csv")
  }

}

