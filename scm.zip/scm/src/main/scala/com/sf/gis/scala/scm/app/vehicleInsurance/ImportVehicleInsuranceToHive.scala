package com.sf.gis.scala.scm.app.vehicleInsurance

import com.alibaba.fastjson.JSON
import common.DataSourceCommon
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.{DateUtil, SparkBuilder}


/**
  * 重货日结数据从kafka原始表数据中读取到hive日结表中,原始数据有可能重复; 需要进行去重
  *
  *@author 01420395
  *@DESCRIPTION ${DESCRIPTION}
  *@create 20230420
  */
object ImportVehicleInsuranceToHive   extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val end_day = DateUtil.getCurrentDate("yyyyMMdd")
    val start_day = DateUtil.getdaysBefore(DateUtil.getCurrentDate("yyyyMMdd"),-7,"yyyyMMdd")
    val biz_day = args(0)

    val sql =
      s"""
        select distinct log from dm_gis.insurance_model_duration_dist_daily_qgzh_kafka where inc_day  between '${start_day}' and '${end_day}'
      """.stripMargin

    logger.error("kafka数据日期: " + start_day +  " == " +end_day + " 业务日期 : " + biz_day)

    logger.error(sql)

    val insuranceKafkaDF = spark.sql(sql)

    logger.error(s">>>> kafka 消费 ${biz_day} 总批次: " + insuranceKafkaDF.count())


    val cols = Seq("un"
      ,"vehicle_color"
      ,"total_dist"
      ,"total_duration"
      ,"drive_dist"
      ,"night_dirve_dist"
      ,"before_dawn_drive_dist"
      ,"early_morning_drive_dist"
      ,"afternoon_drive_dist"
      ,"dusk_drive_dist"
      ,"high_speed_dist"
      ,"state_road_dist"
      ,"provincial_dist"
      ,"county_dist"
      ,"township_dist"
      ,"dangerous_road_dist"
      ,"high_accident_road_dist"
      ,"school_road_dist"
      ,"sharp_turn_road_dist"
      ,"village_road_dist"
      ,"drive_duration"
      ,"drive_duration_array"
      ,"night_dirve_duration"
      ,"before_dawn_drive_duration"
      ,"early_morning_drive_duration"
      ,"afternoon_drive_duration"
      ,"dusk_drive_duration"
      ,"dangerous_road_duration"
      ,"high_accident_road_duration"
      ,"school_road_duration"
      ,"sharp_turn_road_duration"
      ,"township_road_duration"
      ,"over_speed_duration"
      ,"over_speed_ser_duration"
      ,"lnk_cnt"
      ,"dangerous_road_cnt"
      ,"high_accident_road_cnt"
      ,"school_road_cnt"
      ,"sharp_turn_road_cnt"
      ,"township_road_road_cnt"
      ,"operation_cnt"
      ,"operation_same_city_cnt"
      ,"adcode_map"
      ,"adcode_duration_map"
      ,"adcode_dist_map"
      ,"over_drive_duration"
      ,"night_high_speed_duration"
      ,"night_state_road_duration"
      ,"night_provincial_duration"
      ,"night_county_duration"
      ,"night_township_duration"
      ,"night_high_speed_dist"
      ,"night_state_road_dist"
      ,"night_provincial_dist"
      ,"night_county_dist"
      ,"night_township_dist"
      ,"night_dangerous_road_cnt"
      ,"night_high_accident_road_cnt"
      ,"night_school_road_cnt"
      ,"night_sharp_turn_road_cnt"
      ,"night_township_road_road_cnt"
      ,"night_lnk_cnt"
      ,"before_dawn_high_speed_duration"
      ,"before_dawn_state_road_duration"
      ,"before_dawn_provincial_duration"
      ,"before_dawn_county_duration"
      ,"before_dawn_township_duration"
      ,"before_dawn_high_speed_dist"
      ,"before_dawn_state_road_dist"
      ,"before_dawn_provincial_dist"
      ,"before_dawn_county_dist"
      ,"before_dawn_township_dist"
      ,"before_dawn_dangerous_road_cnt"
      ,"before_dawn_high_accident_road_cnt"
      ,"before_dawn_school_road_cnt"
      ,"before_dawn_sharp_turn_road_cnt"
      ,"before_dawn_township_road_road_cnt"
      ,"before_dawn_lnk_cnt"
      ,"early_morning_high_speed_duration"
      ,"early_morning_state_road_duration"
      ,"early_morning_provincial_duration"
      ,"early_morning_county_duration"
      ,"early_morning_township_duration"
      ,"early_morning_high_speed_dist"
      ,"early_morning_state_road_dist"
      ,"early_morning_provincial_dist"
      ,"early_morning_county_dist"
      ,"early_morning_township_dist"
      ,"early_morning_dangerous_road_cnt"
      ,"early_morning_high_accident_road_cnt"
      ,"early_morning_school_road_cnt"
      ,"early_morning_sharp_turn_road_cnt"
      ,"early_morning_township_road_road_cnt"
      ,"early_morning_lnk_cnt"
      ,"afternoon_high_speed_duration"
      ,"afternoon_state_road_duration"
      ,"afternoon_provincial_duration"
      ,"afternoon_county_duration"
      ,"afternoon_township_duration"
      ,"afternoon_high_speed_dist"
      ,"afternoon_state_road_dist"
      ,"afternoon_provincial_dist"
      ,"afternoon_county_dist"
      ,"afternoon_township_dist"
      ,"afternoon_dangerous_road_cnt"
      ,"afternoon_high_accident_road_cnt"
      ,"afternoon_school_road_cnt"
      ,"afternoon_sharp_turn_road_cnt"
      ,"afternoon_township_road_road_cnt"
      ,"afternoon_lnk_cnt"
      ,"dusk_high_speed_duration"
      ,"dusk_state_road_duration"
      ,"dusk_provincial_duration"
      ,"dusk_county_duration"
      ,"dusk_township_duration"
      ,"dusk_high_speed_dist"
      ,"dusk_state_road_dist"
      ,"dusk_provincial_dist"
      ,"dusk_county_dist"
      ,"dusk_township_dist"
      ,"dusk_dangerous_road_cnt"
      ,"dusk_high_accident_road_cnt"
      ,"dusk_school_road_cnt"
      ,"dusk_sharp_turn_road_cnt"
      ,"dusk_township_road_road_cnt"
      ,"dusk_lnk_cnt"
      ,"total_links_dist"
      ,"total_links_duration"
      ,"operation_same_prov_cnt"
      ,"sc_table"
      ,"lpn"
      ,"high_speed_duration"
      ,"state_road_duration"
      ,"provincial_duration"
      ,"county_duration"
      ,"township_duration"
      ,"high_speed_lowspeed_duration"
      ,"track_point_count"
      ,"track_interval"
      ,"track_repeat_count"
      ,"track_continuos_rate"
      ,"track_drift_count"
      ,"inc_day"
      ,"ak"
    )
    import org.apache.spark.sql.functions._
    import spark.implicits._
    val insuranceKafkaLogDF1 =  insuranceKafkaDF
      .filter(get_json_object('log,"$.time")===s"${biz_day}"
      &&  get_json_object('log,"$.dataType")==="car-stat")


    val insuranceKafkaLogDF = insuranceKafkaLogDF1
      .withColumn("log", get_json_object('log,"$.data"))
      .select('log).distinct()

    logger.error(s">>>> kafka 消费 ${biz_day} 批次 : " + insuranceKafkaLogDF.count())

    //解析json字段
    val insuranceRdd  = insuranceKafkaLogDF.rdd.flatMap(row =>{
      JSON.parseArray(row.getAs[String](0)).toArray
    }).map(row  => {
      val jsonObject = JSON.parseObject(row.toString)
      val adcode_dist_map = jsonObject.getString("adcode_dist_map")
      val adcode_duration_map = jsonObject.getString("adcode_duration_map")
      val adcode_map = jsonObject.getString("adcode_map")
      val afternoon_county_dist = jsonObject.getString("afternoon_county_dist")
      val afternoon_county_duration = jsonObject.getString("afternoon_county_duration")
      val afternoon_dangerous_road_cnt = jsonObject.getString("afternoon_dangerous_road_cnt")
      val afternoon_drive_dist = jsonObject.getString("afternoon_drive_dist")
      val afternoon_drive_duration = jsonObject.getString("afternoon_drive_duration")
      val afternoon_high_accident_road_cnt = jsonObject.getString("afternoon_high_accident_road_cnt")
      val afternoon_high_speed_dist = jsonObject.getString("afternoon_high_speed_dist")
      val afternoon_high_speed_duration = jsonObject.getString("afternoon_high_speed_duration")
      val afternoon_lnk_type_cnt = jsonObject.getString("afternoon_lnk_type_cnt")
      val afternoon_provincial_dist = jsonObject.getString("afternoon_provincial_dist")
      val afternoon_provincial_duration = jsonObject.getString("afternoon_provincial_duration")
      val afternoon_road_dist = jsonObject.getString("afternoon_road_dist")
      val afternoon_school_road_cnt = jsonObject.getString("afternoon_school_road_cnt")
      val afternoon_sharp_turn_road_cnt = jsonObject.getString("afternoon_sharp_turn_road_cnt")
      val afternoon_state_road_duration = jsonObject.getString("afternoon_state_road_duration")
      val afternoon_township_dist = jsonObject.getString("afternoon_township_dist")
      val afternoon_township_duration = jsonObject.getString("afternoon_township_duration")
      val afternoon_township_road_cnt = jsonObject.getString("afternoon_township_road_cnt")
      val ak = jsonObject.getString("ak")
      val before_dawn_county_dist = jsonObject.getString("before_dawn_county_dist")
      val before_dawn_county_duration = jsonObject.getString("before_dawn_county_duration")
      val before_dawn_dangerous_road_cnt = jsonObject.getString("before_dawn_dangerous_road_cnt")
      val before_dawn_drive_dist = jsonObject.getString("before_dawn_drive_dist")
      val before_dawn_drive_duration = jsonObject.getString("before_dawn_drive_duration")
      val before_dawn_high_accident_road_cnt = jsonObject.getString("before_dawn_high_accident_road_cnt")
      val before_dawn_high_speed_dist = jsonObject.getString("before_dawn_high_speed_dist")
      val before_dawn_high_speed_duration = jsonObject.getString("before_dawn_high_speed_duration")
      val before_dawn_lnk_cnt = jsonObject.getString("before_dawn_lnk_cnt")
      val before_dawn_provincial_dist = jsonObject.getString("before_dawn_provincial_dist")
      val before_dawn_provincial_duration = jsonObject.getString("before_dawn_provincial_duration")
      val before_dawn_road_dist = jsonObject.getString("before_dawn_road_dist")
      val before_dawn_school_road_cnt = jsonObject.getString("before_dawn_school_road_cnt")
      val before_dawn_sharp_turn_road_cnt = jsonObject.getString("before_dawn_sharp_turn_road_cnt")
      val before_dawn_state_road_duration = jsonObject.getString("before_dawn_state_road_duration")
      val before_dawn_township_dist = jsonObject.getString("before_dawn_township_dist")
      val before_dawn_township_duration = jsonObject.getString("before_dawn_township_duration")
      val before_dawn_township_road_cnt = jsonObject.getString("before_dawn_township_road_cnt")
      val county_dist = jsonObject.getString("county_dist")
      val county_duration = jsonObject.getString("county_duration")
      val dangerous_road_cnt = jsonObject.getString("dangerous_road_cnt")
      val dangerous_road_dist = jsonObject.getString("dangerous_road_dist")
      val dangerous_road_duration = jsonObject.getString("dangerous_road_duration")
      val drive_dist = jsonObject.getString("drive_dist")
      val drive_duration = jsonObject.getString("drive_duration")
      val drive_duration_array = jsonObject.getString("drive_duration_array")
      val dusk_county_dist = jsonObject.getString("dusk_county_dist")
      val dusk_county_duration = jsonObject.getString("dusk_county_duration")
      val dusk_dangerous_road_cnt = jsonObject.getString("dusk_dangerous_road_cnt")
      val dusk_drive_dist = jsonObject.getString("dusk_drive_dist")
      val dusk_drive_duration = jsonObject.getString("dusk_drive_duration")
      val dusk_high_accident_road_cnt = jsonObject.getString("dusk_high_accident_road_cnt")
      val dusk_high_speed_dist = jsonObject.getString("dusk_high_speed_dist")
      val dusk_high_speed_duration = jsonObject.getString("dusk_high_speed_duration")
      val dusk_lnk_type_cnt = jsonObject.getString("dusk_lnk_type_cnt")
      val dusk_provincial_dist = jsonObject.getString("dusk_provincial_dist")
      val dusk_provincial_duration = jsonObject.getString("dusk_provincial_duration")
      val dusk_road_dist = jsonObject.getString("dusk_road_dist")
      val dusk_school_road_cnt = jsonObject.getString("dusk_school_road_cnt")
      val dusk_sharp_turn_road_cnt = jsonObject.getString("dusk_sharp_turn_road_cnt")
      val dusk_state_road_duration = jsonObject.getString("dusk_state_road_duration")
      val dusk_township_dist = jsonObject.getString("dusk_township_dist")
      val dusk_township_duration = jsonObject.getString("dusk_township_duration")
      val dusk_township_road_cnt = jsonObject.getString("dusk_township_road_cnt")
      val early_morning_county_dist = jsonObject.getString("early_morning_county_dist")
      val early_morning_county_duration = jsonObject.getString("early_morning_county_duration")
      val early_morning_dangerous_road_cnt = jsonObject.getString("early_morning_dangerous_road_cnt")
      val early_morning_drive_dist = jsonObject.getString("early_morning_drive_dist")
      val early_morning_drive_duration = jsonObject.getString("early_morning_drive_duration")
      val early_morning_high_accident_road_cnt = jsonObject.getString("early_morning_high_accident_road_cnt")
      val early_morning_high_speed_dist = jsonObject.getString("early_morning_high_speed_dist")
      val early_morning_high_speed_duration = jsonObject.getString("early_morning_high_speed_duration")
      val early_morning_lnk_cnt = jsonObject.getString("early_morning_lnk_cnt")
      val early_morning_provincial_dist = jsonObject.getString("early_morning_provincial_dist")
      val early_morning_provincial_duration = jsonObject.getString("early_morning_provincial_duration")
      val early_morning_road_dist = jsonObject.getString("early_morning_road_dist")
      val early_morning_school_road_cnt = jsonObject.getString("early_morning_school_road_cnt")
      val early_morning_sharp_turn_road_cnt = jsonObject.getString("early_morning_sharp_turn_road_cnt")
      val early_morning_state_road_duration = jsonObject.getString("early_morning_state_road_duration")
      val early_morning_township_dist = jsonObject.getString("early_morning_township_dist")
      val early_morning_township_duration = jsonObject.getString("early_morning_township_duration")
      val early_morning_township_road_cnt = jsonObject.getString("early_morning_township_road_cnt")
      val high_accident_road_cnt = jsonObject.getString("high_accident_road_cnt")
      val high_accident_road_dist = jsonObject.getString("high_accident_road_dist")
      val high_accident_road_duration = jsonObject.getString("high_accident_road_duration")
      val high_speed_dist = jsonObject.getString("high_speed_dist")
      val high_speed_duration = jsonObject.getString("high_speed_duration")
      val high_speed_lowspeed_duration = jsonObject.getString("high_speed_lowspeed_duration")
      val if_highspeed = jsonObject.getString("if_highspeed")
      val inc_day = jsonObject.getString("inc_day")
      val lnk_cnt = jsonObject.getString("lnk_cnt")

      val night_county_dist = jsonObject.getString("night_county_dist")
      val night_county_duration = jsonObject.getString("night_county_duration")
      val night_dangerous_road_cnt = jsonObject.getString("night_dangerous_road_cnt")
      val night_dirve_dist = jsonObject.getString("night_dirve_dist")
      val night_dirve_duration = jsonObject.getString("night_dirve_duration")
      val night_high_accident_road_cnt = jsonObject.getString("night_high_accident_road_cnt")
      val night_high_speed_dist = jsonObject.getString("night_high_speed_dist")
      val night_high_speed_duration = jsonObject.getString("night_high_speed_duration")
      val night_lnk_cnt = jsonObject.getString("night_lnk_cnt")
      val night_provincial_dist = jsonObject.getString("night_provincial_dist")
      val night_provincial_duration = jsonObject.getString("night_provincial_duration")
      val night_school_road_cnt = jsonObject.getString("night_school_road_cnt")
      val night_sharp_turn_road_cnt = jsonObject.getString("night_sharp_turn_road_cnt")
      val night_state_road_dist = jsonObject.getString("night_state_road_dist")
      val night_state_road_duration = jsonObject.getString("night_state_road_duration")
      val night_township_dist = jsonObject.getString("night_township_dist")
      val night_township_duration = jsonObject.getString("night_township_duration")
      val night_township_road_cnt = jsonObject.getString("night_township_road_cnt")
      val operation_cnt = jsonObject.getString("operation_cnt")
      val operation_same_city_cnt = jsonObject.getString("operation_same_city_cnt")
      val operation_same_prov_cnt = jsonObject.getString("operation_same_prov_cnt")
      val over_drive_duration = jsonObject.getString("over_drive_duration")
      val over_speed_duration = jsonObject.getString("over_speed_duration")
      val over_speed_ser_duration = jsonObject.getString("over_speed_ser_duration")
      val provincial_dist = jsonObject.getString("provincial_dist")
      val provincial_duration = jsonObject.getString("provincial_duration")
      val road_dist = jsonObject.getString("road_dist")
      val road_end_adcode = jsonObject.getString("road_end_adcode")
      val road_end_time = jsonObject.getString("road_end_time")
      val road_id_end = jsonObject.getString("road_id_end")
      val road_id_start = jsonObject.getString("road_id_start")
      val road_rank = jsonObject.getString("road_rank")
      val road_start_adcode = jsonObject.getString("road_start_adcode")
      val road_start_time = jsonObject.getString("road_start_time")
      val sc_table = jsonObject.getString("sc_table")
      val school_road_cnt = jsonObject.getString("school_road_cnt")
      val school_road_dist = jsonObject.getString("school_road_dist")
      val school_road_duration = jsonObject.getString("school_road_duration")
      val sharp_turn_road_cnt = jsonObject.getString("sharp_turn_road_cnt")
      val sharp_turn_road_dist = jsonObject.getString("sharp_turn_road_dist")
      val sharp_turn_road_duration = jsonObject.getString("sharp_turn_road_duration")
      val state_road_dist = jsonObject.getString("state_road_dist")
      val state_road_duration = jsonObject.getString("state_road_duration")
      val tl_link = jsonObject.getString("tl_link")
      val tl_periods = jsonObject.getString("tl_periods")
      val tl_roadclass = jsonObject.getString("tl_roadclass")
      val tl_roadname = jsonObject.getString("tl_roadname")
      val total_dist = jsonObject.getString("total_dist")
      val total_duration = jsonObject.getString("total_duration")
      val total_links_dist = jsonObject.getString("total_links_dist")
      val total_links_duration = jsonObject.getString("total_links_duration")
      val township_dist = jsonObject.getString("township_dist")
      val township_duration = jsonObject.getString("township_duration")
      val township_road_duration = jsonObject.getString("township_road_duration")
      val township_road_road_cnt = jsonObject.getString("township_road_road_cnt")
      val track_continuos_rate = jsonObject.getString("track_continuos_rate")
      val track_drift_count = jsonObject.getString("track_drift_count")
      val track_interval = jsonObject.getString("track_interval")
      val track_point_count = jsonObject.getString("track_point_count")
      val track_repeat_count = jsonObject.getString("track_repeat_count")

      val village_road_dist = jsonObject.getString("village_road_dist")

      val un = jsonObject.getString("un")
      val vehicle_color = un.split("_")(1)
      val lpn = un.split("_")(0)


      Row(un,vehicle_color,total_dist,total_duration,drive_dist,night_dirve_dist,before_dawn_drive_dist,
        early_morning_drive_dist,afternoon_drive_dist,dusk_drive_dist,high_speed_dist,state_road_dist,provincial_dist,
        county_dist,township_dist,dangerous_road_dist,high_accident_road_dist,school_road_dist,sharp_turn_road_dist,
        village_road_dist,drive_duration,drive_duration_array,night_dirve_duration,before_dawn_drive_duration,
        early_morning_drive_duration,afternoon_drive_duration,dusk_drive_duration,dangerous_road_duration,
        high_accident_road_duration,school_road_duration,sharp_turn_road_duration,township_road_duration,
        over_speed_duration,over_speed_ser_duration,lnk_cnt,dangerous_road_cnt,high_accident_road_cnt,
        school_road_cnt,sharp_turn_road_cnt,township_road_road_cnt,operation_cnt,operation_same_city_cnt,
        adcode_map,adcode_duration_map,adcode_dist_map,over_drive_duration,night_high_speed_duration,
        night_state_road_duration,night_provincial_duration,night_county_duration,night_township_duration,
        night_high_speed_dist,night_state_road_dist,night_provincial_dist,night_county_dist,
        night_township_dist,night_dangerous_road_cnt,night_high_accident_road_cnt,night_school_road_cnt,night_sharp_turn_road_cnt,
        night_township_road_cnt,night_lnk_cnt,before_dawn_high_speed_duration,before_dawn_state_road_duration,
        before_dawn_provincial_duration,before_dawn_county_duration,before_dawn_township_duration,before_dawn_high_speed_dist,
        before_dawn_road_dist,before_dawn_provincial_dist,before_dawn_county_dist,before_dawn_township_dist,
        before_dawn_dangerous_road_cnt,before_dawn_high_accident_road_cnt,before_dawn_school_road_cnt,before_dawn_sharp_turn_road_cnt,
        before_dawn_township_road_cnt,before_dawn_lnk_cnt,early_morning_high_speed_duration,early_morning_state_road_duration,
        early_morning_provincial_duration,early_morning_county_duration,early_morning_township_duration,early_morning_high_speed_dist,
        early_morning_road_dist,early_morning_provincial_dist,early_morning_county_dist,early_morning_township_dist,
        early_morning_dangerous_road_cnt,early_morning_high_accident_road_cnt,early_morning_school_road_cnt,early_morning_sharp_turn_road_cnt,
        early_morning_township_road_cnt,early_morning_lnk_cnt,afternoon_high_speed_duration,afternoon_state_road_duration,
        afternoon_provincial_duration,afternoon_county_duration,afternoon_township_duration,afternoon_high_speed_dist,
        afternoon_road_dist,afternoon_provincial_dist,afternoon_county_dist,afternoon_township_dist,
        afternoon_dangerous_road_cnt,afternoon_high_accident_road_cnt,afternoon_school_road_cnt,afternoon_sharp_turn_road_cnt,
        afternoon_township_road_cnt,afternoon_lnk_type_cnt,dusk_high_speed_duration,dusk_state_road_duration,dusk_provincial_duration,
        dusk_county_duration,dusk_township_duration,dusk_high_speed_dist,dusk_road_dist,dusk_provincial_dist,dusk_county_dist,
        dusk_township_dist,dusk_dangerous_road_cnt,dusk_high_accident_road_cnt,dusk_school_road_cnt,dusk_sharp_turn_road_cnt,
        dusk_township_road_cnt,dusk_lnk_type_cnt,total_links_dist,total_links_duration,operation_same_prov_cnt,sc_table,lpn,
        high_speed_duration,state_road_duration,provincial_duration,county_duration,township_duration,
        high_speed_lowspeed_duration
        ,track_point_count
        ,track_interval
        ,track_repeat_count
        ,track_continuos_rate
        ,track_drift_count
        ,inc_day,ak)
    }).distinct()

    logger.error("业务日期: " + biz_day + " >>>  总条数 " + insuranceRdd.count())
    val fields = cols.map(fieldsName => StructField(fieldsName,StringType,nullable = true))
    val schema = StructType(fields)
    val insuranceDF = spark.createDataFrame(insuranceRdd,schema)

    writeToHive(spark, insuranceDF, Seq("inc_day","ak"), "dm_gis.insurance_model_duration_dist_daily_qgzh")

  }



}
