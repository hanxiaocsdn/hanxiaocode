package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import common.DataSourceCommon
import utils.ColumnUtil._
import utils.Functions._
import utils.SparkUtil._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
 * 一次性任务
 */
object EtaStdLineToll extends DataSourceCommon {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val IntegrateDetail_LINE: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"



  // task_result 过滤函数
  def task_result_filter = udf((task_result: String) => {
    var ret = false
    if(task_result != null && task_result.trim != ""){
      try{
        val obj = JSON.parseObject(task_result)
        val body = JSONUtil.getJsonArrayMulti(obj, "body")
        if(body.size() == 1){
          ret = true
        }else if(body.size() >= 2){
          val enDateTime_0 = JSONUtil.getJsonVal(body.getJSONObject(0),"enDateTime","")
          val enDateTime_1 = JSONUtil.getJsonVal(body.getJSONObject(1),"enDateTime","")
          if(!enDateTime_0.equals(enDateTime_1)){
            ret = true
          }
        }
      }catch {
        case e: Exception => println(">>>转换异常："+e)
      }
    }
    ret
  })


  def execute(spark: SparkSession, inc_day: String) = {
    val dayBefore1 = "20231019"
    val dayBefore2 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 2)
    val dayBefore30 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 30)

    import spark.implicits._
    val fees_dtl_sql =
      s"""
         |select
         |  t0.task_id,
         |  t0.line_code,
         |  t0.task_start_time,
         |  t0.task_end_time,
         |  cast(t0.ctfo_task_fee as double) / 100 as ctfo_task_fee,
         |  cast(t0.discountfee as double) / 100 as discountfee,
         |  case when t0.ctfo_task_fee  is not  null  then  t0.vehicle_type else t1.vehicle_type end as vehicle_type,
         |  t0.plate,
         |  t0.rate,
         |  t0.stop_dept,
         |  t0.task_result
         |from
         |  dm_gis.dm_supplier_roadbridge_fees_dtl t0
         |  left join dm_gis.eta_std_line_toll_vehicle t1 on t0.plate = t1.plate
         |where
         |  t0.inc_day between '20231023' and  '20231029'
         |  and t0.task_type = '1'
         |  and t0.task_status =6
         |
         |""".stripMargin
    println(fees_dtl_sql)
    val df_fees_dtl = spark.sql(fees_dtl_sql)
      .withColumn("toll_fee_qf",'ctfo_task_fee + 'discountfee)
//      .withColumn("ctfo_task_fee", when('ctfo_task_fee isNotNull,'ctfo_task_fee + 'discountfee).otherwise('ctfo_task_fee))
      .withColumn("vehicle_type",when('vehicle_type isNull,lit("11")).otherwise('vehicle_type))

//    logger.error("原数据总量: " + df_fees_dtl1.count())
//
//
//    val df_fees_dtl = df_fees_dtl1
//      .filter(task_result_filter('task_result))

    logger.error("过滤之后原数据总量: " + df_fees_dtl.count())


    val config_sql =
      s"""
         |select
         |  line_code,
         |  src_dept_code,
         |  des_dept_code,
         |  axles_num,
         |  toll_fee as toll_fee_config,
         |  stop_dept_code,
         |  cast(vehicle_len as double) as vehicle_len,
         |  count(line_code) as cn
         |from
         |  ods_tbpdispatch.tm_quality_driver_fee_item_config
         |where
         |  inc_day >= '20230401'
         |  and is_delete = '0'
         |group by
         |  line_code,
         |  src_dept_code,
         |  des_dept_code,
         |  axles_num,
         |  vehicle_len,
         |  toll_fee,
         |  stop_dept_code
         |""".stripMargin
    println(config_sql)
    val df_config = spark.sql(config_sql)
      .withColumn("stop_dept",when(!isEmptyOrNull('stop_dept_code),concat_dept2('src_dept_code,'des_dept_code,'stop_dept_code))
        .otherwise(concat_ws(",",'src_dept_code,'des_dept_code)))
      .withColumn("vehicle_type",when('axles_num === "2" and 'vehicle_len < 6.0,"11")
        .when('axles_num === "2" and 'vehicle_len >= 6.0,"12")
        .when('axles_num === "3","13")
        .when('axles_num === "4","14")
        .when('axles_num === "5","15")
        .when('axles_num === "6","16")
        .otherwise("11"))
      .withColumn("rn", row_number().over(Window.partitionBy("line_code","vehicle_type","stop_dept").orderBy(desc("toll_fee_config"))))
      .filter('rn === 1)  // 去重
      .select("line_code","vehicle_type","stop_dept","toll_fee_config")

    // 调标准线路查询接口
    val rdd_rdd_detail_toll = SparkNet.runInterfaceWithAkLimit(spark, df_fees_dtl.rdd.map(row2Json), runIntegrateDetailInteface, 10, "93ec117f7f1b4226b4e537c4802319e9", 200)


    logger.error("接口数据总量: " + rdd_rdd_detail_toll.count())


    val df_detail = rdd_rdd_detail_toll.map(obj=>{
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val task_start_time = JSONUtil.getJsonVal(obj, "task_start_time", "")
      val task_end_time = JSONUtil.getJsonVal(obj, "task_end_time", "")
      val ctfo_task_fee = JSONUtil.getJsonVal(obj, "ctfo_task_fee", "")
      val discountfee = JSONUtil.getJsonVal(obj, "discountfee", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val plate = JSONUtil.getJsonVal(obj, "plate", "")
      val rate = JSONUtil.getJsonVal(obj, "rate", "")
      val stop_dept = JSONUtil.getJsonVal(obj, "stop_dept", "")
      val toll_fee_qf = JSONUtil.getJsonVal(obj, "toll_fee_qf", "")

      val toll_charge = JSONUtil.getJsonVal(obj, "tollCharge", "")

      TestTolls(task_id,line_code,task_start_time,task_end_time,ctfo_task_fee,discountfee,vehicle_type,plate,rate,stop_dept,toll_charge,toll_fee_qf)
    }).toDF()
      .join(df_config,Seq("line_code","vehicle_type","stop_dept"),"left")
      .withColumn("inc_day",lit(dayBefore1))

    val cols = spark.sql("""select * from dm_gis.eta_std_line_toll_tmp20230918 limit 0""").schema.map(_.name).map(col)

    logger.error("接口数据总量: " + df_detail.count())
    writeToHive(spark,df_detail.select(cols: _*),Seq("inc_day"),"dm_gis.eta_std_line_toll_tmp20230918")

    //    val sql = s"select * from dm_gis.eta_std_line_toll_tmp20230918 where inc_day = '$dayBefore1' and cast(rate as double) > 0.8"
    //    println(sql)
    //    val df_detail = spark.sql(sql)

    val ret_df = df_detail
      .groupBy("line_code","vehicle_type","stop_dept")
      .agg(
        max('toll_fee_qf.cast("double")) as "toll_fee_qf_max",
        min('toll_fee_qf.cast("double")) as "toll_fee_qf_min",
        avg('toll_fee_qf.cast("double")) as "toll_fee_qf_avg",
        concat_ws("|",collect_list('toll_fee_qf)) as "toll_fee_qf_arr",

        max('toll_charge.cast("double")) as "toll_charge_max",
        min('toll_charge.cast("double")) as "toll_charge_min",
        avg('toll_charge.cast("double")) as "toll_charge_avg",
        concat_ws("|",collect_list('toll_charge)) as "toll_charge_arr",

        max('toll_fee_config.cast("double")) as "toll_fee_config_max",
        min('toll_fee_config.cast("double")) as "toll_fee_config_min",
        avg('toll_fee_config.cast("double")) as "toll_fee_config_avg",
        concat_ws("|",collect_list('toll_fee_config)) as "toll_fee_config_arr"
      )
      .withColumn("toll_fee_qf_mode",get_mode('toll_fee_qf_arr))
      .withColumn("toll_charge_mode",get_mode('toll_charge_arr))
      .withColumn("toll_fee_config_mode",get_mode('toll_fee_config_arr))
      .withColumn("inc_day",lit(dayBefore1))


    val cols1 = spark.sql("""select * from dm_gis.eta_std_line_tmp20230918 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,ret_df.select(cols1: _*),Seq("inc_day"),"dm_gis.eta_std_line_tmp20230918")

  }

  case class TestTolls(
                        task_id : String,
                        line_code : String,
                        task_start_time : String,
                        task_end_time : String,
                        ctfo_task_fee : String,
                        discountfee : String,
                        vehicle_type : String,
                        plate : String,
                        rate : String,
                        stop_dept : String,
                        toll_charge : String,
                        toll_fee_qf : String
                      )

  // 求众数
  def get_mode = udf((ctfo_task_fee: String) => {

    val array = ctfo_task_fee.split("\\|")

    val map = new mutable.HashMap[String, Int]
    for (data <- array) {
      map.put(data, map.getOrElse(data, 0) + 1)
    }
    var ans: String = ""
    var cnt = 0
    for ((key, value) <- map) {
      if (value > cnt) {
        ans = key
        cnt = value
      }
    }
    ans
  })


  def runIntegrateDetailInteface(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_type = JSONUtil.getJsonValInt(obj, "vehicle_type", 0)
    val un = JSONUtil.getJsonVal(obj, "plate", "")
    val task_start_time = JSONUtil.getJsonVal(obj, "task_start_time", "")
    val task_end_time = JSONUtil.getJsonVal(obj, "task_end_time", "")
    // 将时间戳转换成接口需要的格式
    val beginDateTime = timeToCustomTime(task_start_time,"yyyy-MM-dd HH:mm:ss","yyyyMMddHHmmss")
    val endDateTime = timeToCustomTime(task_end_time,"yyyy-MM-dd HH:mm:ss","yyyyMMddHHmmss")

    var axis = 0
    var length = 0.0
    var weight = 0.0
    var load = 0.0
    vehicle_type match {
      case 11 => (axis = 2, length = 5.4, weight = 3.6, load = 3.6)
      case 12 => (axis = 2, length = 7.2, weight = 5.4, load = 5.4)
      case 13 => (axis = 3, length = 7.2, weight = 5.4, load = 5.4)
      case 14 => (axis = 4, length = 7.2, weight = 5.4, load = 5.4)
      case 15 => (axis = 5, length = 7.2, weight = 5.4, load = 5.4)
      case 16 => (axis = 6, length = 7.2, weight = 5.4, load = 5.4)
      case _ =>
    }

    //初始化接口请求参数
    val vehicleInfo = new JSONObject()
    vehicleInfo.put("axis",axis)
    vehicleInfo.put("length",length)
    vehicleInfo.put("weight",weight)
    vehicleInfo.put("load",load)

    val param = new JSONObject()
    param.put("type", "0")
    param.put("un", un)
    param.put("unType", "0")
    param.put("rectify", false)
    param.put("ak", ak)
    param.put("beginDateTime", beginDateTime)
    param.put("endDateTime", endDateTime)
    param.put("hasRate", true)
    param.put("vehicleInfo", vehicleInfo)


    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(IntegrateDetail_LINE,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, String, JSONObject) = parseGetLineHttpData(retJSONObject)
    val tollCharge = httpData._3
    val codeStatue_1 = httpData._1
    val msg_1 = httpData._2

    obj.put("tollCharge",tollCharge)
    obj.put("codeStatue_1",codeStatue_1)
    obj.put("msg_1",msg_1)

    obj
  }

  /**
   * 解析 标准线路配置查询接口返回值
   * @param ret
   * @return
   */
  def parseGetLineHttpData(ret: JSONObject): (String, String, String, JSONObject) = {
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null, null)
      } else {
        var tollCharge = ""
        try{
          tollCharge = ret.getJSONObject("result").getJSONObject("data").getString("tollCharge")
        }catch {
          case e: Exception => logger.error(e)
        }
        return (codeStatue, "成功", tollCharge, null)
      }
    }
    ("22", "请求失败", null, null)
  }

  // 将任务的所有子任务经停网点收集
  def concat_dept2 = udf((src_dept_code: String,des_dept_code: String,stop_dept_code: String) => {

    val arr_tmp = new ArrayBuffer[String]()
    arr_tmp.append(src_dept_code)  // 添加起始网点

    if(!stop_dept_code.isEmpty){
      val stop_dept_arr = stop_dept_code.split(",")
      for(i <- 0 until stop_dept_arr.length){
        val dept = stop_dept_arr(i)
        if(!arr_tmp.contains(dept)) arr_tmp.append(dept) // 添加经停网点
      }
    }
    if(!arr_tmp.contains(des_dept_code)) arr_tmp.append(des_dept_code) // 添加终点网点

    arr_tmp.mkString(",")
  })

  // 将任务的所有子任务经停网点收集
  def concat_dept = udf((start_dept: String,end_dept: String) => {

    val start_dept_arr = start_dept.split("\\|")
    val end_dept_arr = end_dept.split("\\|")
    val arr_tmp = new ArrayBuffer[String]()

    for(i <- 0 until start_dept_arr.length){
      val dept = start_dept_arr(i)
      if(!arr_tmp.contains(dept)) arr_tmp.append(dept)
    }
    val dept_end = end_dept_arr(end_dept_arr.length - 1)
    if(!arr_tmp.contains(dept_end)) arr_tmp.append(dept_end)

    arr_tmp.mkString("|")
  })

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231019  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}
