package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.{DateTimeUtil, SparkUtil}


/**
 * GIS-RSS-ETA：【燃油管控】 第四步：判断是否按推荐行驶，计算实际加油点油价_V1.0
 * 需求方：zuojiayi（01403789） 油站价格数据初始化
 *
 * @author guofangcai（01420395）
 * 任务ID：
 * 任务名称：读取城市和城市编码映射关系任务，一次性任务
 */
object AdcodeDataInit extends DataSourceCommon {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {
    val spark =  SparkUtil.getSparkSession(appName)
    val inc_day  = args(0)
    start(spark, inc_day)
    spark.stop()
  }

  def start(sparkSession:SparkSession, inc_day: String )= {

    import  sparkSession.implicits._
    val cols = Seq("cityname","adcode")
    val inputPath = "/user/01420395/upload/data/import/2208536/adcode.csv"
    val adcode_df = sparkSession.read.option("header", "true")
      .option("delimiter", ",")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select('adcode,'cityname)
      .withColumn("etl_time",lit(DateTimeUtil.getCurrentSystemTime("yyyy-MM-dd HH:mm:ss")))

    adcode_df.show(1, false)
    writeToHiveNoP(sparkSession,adcode_df,"dm_gis.dwd_city_adcode_map")

  }

}
