package com.sf.gis.scala.scm.app.GIS_RSS_SCM

import com.alibaba.fastjson.JSON
import common.DataSourceCommon
import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.{DateUtil, SparkBuilder, StringUtils}


/**
  * 北京违章数据从kafka原始表数据中读取到hive日结表中,原始数据有可能重复; 需要进行去重
  *
  *@author 01420395 任务id: 784704
  *@DESCRIPTION ${DESCRIPTION}
  *@create 20230420
  */
object ImportbjWeiZhangToHive   extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val end_day = DateUtil.getCurrentDate("yyyyMMdd")
    val start_day = DateUtil.getdaysBefore(DateUtil.getCurrentDate("yyyyMMdd"),-3,"yyyyMMdd")
    val inc_day = args(0)

    val sql =
      s"""
        select distinct log from dm_gis.insurance_model_duration_dist_daily_qgzh_kafka
        where inc_day  between '${start_day}' and '${end_day}'
      """.stripMargin

    logger.error("kafka数据日期: " + start_day +  " == " +end_day + " 业务日期 : " + inc_day )

    logger.error(sql)


    val insuranceKafkaDF = spark.sql(sql)

    val cols = Seq(
      "wfms"
      ,"wfdz"
      ,"dir"
      ,"coords"
      ,"swid"
      ,"hpzl"
      ,"yearStats"
      ,"fre"
      ,"src"
      ,"pushtime"
    )


    import org.apache.spark.sql.functions._
    import spark.implicits._
    val insuranceKafkaLogDF1 =  insuranceKafkaDF.filter(
      get_json_object('log,"$.time")===s"${inc_day}"
        &&  get_json_object('log,"$.dataType")==="bj_weizhang")


    val insuranceKafkaLogDF = insuranceKafkaLogDF1
      .withColumn("log", get_json_object('log,"$.data")).select('log)

    logger.error(s">>>> kafka 消费 ${inc_day}批次 : " + insuranceKafkaLogDF1.count())

    //解析json字段
    val insura0nceRdd  = insuranceKafkaLogDF.rdd.flatMap(row =>{
      JSON.parseArray(row.getAs[String](0)).toArray
    }).map(row  => {
      val jsonObject = JSON.parseObject(row.toString)
      val wfms = jsonObject.getString("wfms")
      val wfdz = jsonObject.getString("wfdz")
      val dir = jsonObject.getString("dir")
      var coords = jsonObject.getString("coords")
       if(!StringUtils.isEmpty(coords)&& coords.contains("|")){
         coords = coords.split("\\|",-1)(0)+"\""
       }
      val swid = jsonObject.getString("swid")
      val hpzl = jsonObject.getString("hpzl")
      val src = jsonObject.getString("src")
      val yearStats = jsonObject.getString("yearStats")
      val fre  = jsonObject.getString("fre")
      var pushtime  = ""
      if(jsonObject.containsKey("pushtime")){
        pushtime  = jsonObject.getString("pushtime")
      }

      Row(wfms,wfdz,dir,coords,swid, hpzl,yearStats,fre,src,pushtime)
    })

    logger.error("业务日期: " + inc_day + " >>>  总条数 " + insura0nceRdd.count())
    val fields = cols.map(fieldsName => StructField(fieldsName,StringType,nullable = true))
    val schema = StructType(fields)
    val insuranceDF = spark.createDataFrame(insura0nceRdd,schema)
      .withColumn("etl_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))

    val resultDF =  insuranceDF
      .withColumn("rn",row_number()over(Window.partitionBy("swid").orderBy(desc("pushtime"))))

    val resultDF2 =  resultDF.filter('rn===1).drop('pushtime).drop('rn)
        .select("wfms"
          ,"wfdz"
          ,"dir"
          ,"coords"
          ,"swid"
          ,"hpzl"
          ,"yearStats"
          ,"fre"
          ,"src"
          ,"etl_time")

    resultDF2.show(10)


    writeToHiveNoP2(spark,resultDF2,"dm_gis.Vehicle_violation_statistics")
  }

}

