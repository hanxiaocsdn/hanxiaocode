package com.sf.gis.scala.scm.app.heavycargostatic

import common.DataSourceCommon
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SparkSession}
import utils.{SparkBuilder, StringUtils}

/**
  * @description: 同步到全国重货静态信息同步到hive表中;  需求ID: 1720287 任务id 722121
  * @author 01420935 caiguofang
  * @date 2023/04/10 10:36
  */
object ImportVehicleStatusFromHbaseMain extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  //切换集群
  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
//    val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"

  val zkPort = "2181"
  val zkParent = "/hbase"


  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val hbaseConf  = HBaseConfiguration.create()
    hbaseConf.set("zookeeper.znode.parent", zkParent)
    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")

    exportBasicVehicle(spark,hbaseConf)

    exportModelVehicle(spark,hbaseConf)

    exportJsonVehicle(spark,hbaseConf)
    spark.close()
  }




  /**
    * 导出计算的车辆基础信息
    * @param spark
    * @param hbaseConf
    * @param broadcast
    * @return
    */
  def exportModelVehicle(spark: SparkSession, hbaseConf: Configuration)={

    //获取不匹配车型数据
    val hBaseTblName = "gis:insurance_vehicle_model_original"
    hbaseConf.set(TableInputFormat.INPUT_TABLE, hBaseTblName)

    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])

    val vehicleBaseDf = hbaseTblRdd.map(row => {
      val result = row._2
      val id  = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("id")))
      val vehicle_typecode = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_typecode")))
      val is_type_ok = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("is_type_ok")))
      val vehicle_age = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_age")))
      val original_value_vehicle = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("original_value_vehicle")))
      val company_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_name")))
      val vehicle_type = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_type")))
      val brand_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("brand_name")))
      val  vehicle_weight = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_weight")))
      val full_weight = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("full_weight")))
      val ratified_load_capacity = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("ratified_load_capacity")))
      val track_front = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("track_front")))
      val  track_rear = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("track_rear")))
      val tire_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tire_number")))
      val tire_specification = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tire_specification")))
      val  wheel_base = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wheel_base")))
      val  wheel_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wheel_number")))
      val long_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("long_profile_size")))
      val  wide_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wide_profile_size")))
      val height_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("height_profile_size")))
      val fuel_type = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("fuel_type")))
      val effluent_standard = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("effluent_standard")))
      val vehicle_model = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_model")))
      val data_sources = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("data_sources")))
      val create_time = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("create_time")))


      val temList  = List(id,vehicle_typecode,is_type_ok,vehicle_age,original_value_vehicle,company_name,vehicle_type,brand_name,
        vehicle_weight,full_weight,ratified_load_capacity,track_front,track_rear,tire_number,tire_specification,
        wheel_base,wheel_number,long_profile_size,wide_profile_size,height_profile_size,fuel_type,effluent_standard,
        vehicle_model,data_sources,create_time)

      Row.fromSeq(temList)

    })


    // 转成df
    val hBaseSchame =StructType(
      List(
        StructField("id", StringType, true)
        ,StructField("vehicle_typecode", StringType, true)
        ,StructField("is_type_ok", StringType, true)
        ,StructField("vehicle_age", StringType, true)
        ,StructField("original_value_vehicle", StringType, true)
        ,StructField("company_name", StringType, true)
        ,StructField("vehicle_type", StringType, true)
        ,StructField("brand_name", StringType, true)
        ,StructField("vehicle_weight", StringType, true)
        ,StructField("full_weight", StringType, true)
        ,StructField("ratified_load_capacity", StringType, true)
        ,StructField("track_front", StringType, true)
        ,StructField("track_rear", StringType, true)
        ,StructField("tire_number", StringType, true)
        ,StructField("tire_specification", StringType, true)
        ,StructField("wheel_base", StringType, true)
        ,StructField("wheel_number", StringType, true)
        ,StructField("long_profile_size", StringType, true)
        ,StructField("wide_profile_size", StringType, true)
        ,StructField("height_profile_size", StringType, true)
        ,StructField("fuel_type", StringType, true)
        ,StructField("effluent_standard", StringType, true)
        ,StructField("vehicle_model", StringType, true)
        ,StructField("data_sources", StringType, true)
        ,StructField("create_time", StringType, true)
      )
    )
    val vehicleDf =  spark.createDataFrame(vehicleBaseDf, hBaseSchame)

    vehicleDf.show(1)

    writeToHiveNoP(spark,vehicleDf,"dm_gis.insurance_vehicle_model_original")

  }


  /**
    * 获取现有的车型数据
    * @param spark
    * @param tbl_name
    * @param hbaseConf
    * @return
    */
  def exportJsonVehicle(spark: SparkSession, hbaseConf: Configuration)={

    //获取不匹配车型数据
    val hBaseTblName = "gis:insurance_vehicle_json_original"
    hbaseConf.set(TableInputFormat.INPUT_TABLE, hBaseTblName)

    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])

    val vehicleBaseDf = hbaseTblRdd.map(row => {
      val result = row._2
      val id  = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("id")))
      val vin = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vin")))
      val is_success = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("is_success")))
      var JY_json_str = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("JY_json_str")))
      if(StringUtils.isEmpty(JY_json_str)){
        JY_json_str = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("jy_json_str")))
      }
      val create_time = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("create_time")))

      val temList  = List(id,vin,is_success,JY_json_str,create_time)

      Row.fromSeq(temList)
    })

    // 转成df
    val hBaseSchame =StructType(
      List(
        StructField("id", StringType, true)
        ,StructField("vin", StringType, true)
        ,StructField("is_success", StringType, true)
        ,StructField("JY_json_str", StringType, true)
        ,StructField("create_time", StringType, true)
      )
    )
    val vehicleDf =  spark.createDataFrame(vehicleBaseDf, hBaseSchame)
    vehicleDf.show(1)
    writeToHiveNoP(spark,vehicleDf,"dm_gis.insurance_vehicle_json_original")
  }


  /**
    * 导出计算的车辆基础信息
    * @param spark
    * @param hbaseConf
    * @param broadcast
    * @return
    */
  def exportBasicVehicle(spark: SparkSession, hbaseConf: Configuration)={

    //获取不匹配车型数据
    val hBaseTblName = "gis:insurance_vehicle_basics_original"
    hbaseConf.set(TableInputFormat.INPUT_TABLE, hBaseTblName)

    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])

    val vehicleBaseDf = hbaseTblRdd.map(row => {
      val result = row._2
      val id  = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("id")))
      val vin = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vin")))
      val  vehicle_age = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_age")))
      val original_value_vehicle = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("original_value_vehicle")))
      val company_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_name")))
      val vehicle_type = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_type")))
      val brand_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("brand_name")))
      val  vehicle_weight = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_weight")))
      val full_weight = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("full_weight")))
      val ratified_load_capacity = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("ratified_load_capacity")))
      val track_front = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("track_front")))
      val  track_rear = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("track_rear")))
      val tire_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tire_number")))
      val tire_specification = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tire_specification")))
      val  wheel_base = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wheel_base")))
      val  wheel_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wheel_number")))
      val long_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("long_profile_size")))
      val  wide_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wide_profile_size")))
      val height_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("height_profile_size")))
      val fuel_type = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("fuel_type")))
      val effluent_standard = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("effluent_standard")))
      val vehicle_model = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_model")))
      val wmi = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wmi")))
      val vds = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vds")))
      val vehicle_typecode = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_typecode")))
      val results_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("results_number")))
      val data_sources = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("data_sources")))
      val create_time = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("create_time")))


      val temList  = List(id,vin,vehicle_age,original_value_vehicle,company_name,vehicle_type,brand_name,
        vehicle_weight,full_weight,ratified_load_capacity,track_front,track_rear,tire_number,tire_specification,
        wheel_base,wheel_number,long_profile_size,wide_profile_size,height_profile_size,fuel_type,effluent_standard,
        vehicle_model,wmi,vds,vehicle_typecode,results_number,data_sources,create_time)

      Row.fromSeq(temList)

    })


    // 转成df
    val hBaseSchame =StructType(
      List(
        StructField("id", StringType, true)
        ,StructField("vin", StringType, true)
        ,StructField("vehicle_age", StringType, true)
        ,StructField("original_value_vehicle", StringType, true)
        ,StructField("company_name", StringType, true)
        ,StructField("vehicle_type", StringType, true)
        ,StructField("brand_name", StringType, true)
        ,StructField("vehicle_weight", StringType, true)
        ,StructField("full_weight", StringType, true)
        ,StructField("ratified_load_capacity", StringType, true)
        ,StructField("track_front", StringType, true)
        ,StructField("track_rear", StringType, true)
        ,StructField("tire_number", StringType, true)
        ,StructField("tire_specification", StringType, true)
        ,StructField("wheel_base", StringType, true)
        ,StructField("wheel_number", StringType, true)
        ,StructField("long_profile_size", StringType, true)
        ,StructField("wide_profile_size", StringType, true)
        ,StructField("height_profile_size", StringType, true)
        ,StructField("fuel_type", StringType, true)
        ,StructField("effluent_standard", StringType, true)
        ,StructField("vehicle_model", StringType, true)
        ,StructField("wmi", StringType, true)
        ,StructField("vds", StringType, true)
        ,StructField("vehicle_typecode", StringType, true)
        ,StructField("results_number", StringType, true)
        ,StructField("data_sources", StringType, true)
        ,StructField("create_time", StringType, true)
      )
    )
    val vehicleDf =  spark.createDataFrame(vehicleBaseDf, hBaseSchame)
    vehicleDf.show(1)
    writeToHiveNoP(spark,vehicleDf,"dm_gis.insurance_vehicle_basics_original")

  }

}
