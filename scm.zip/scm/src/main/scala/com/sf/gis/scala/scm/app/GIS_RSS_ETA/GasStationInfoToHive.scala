package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import common.DataSourceCommon
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{StringUtils, TrackUrlUtil}

/**
 * @Description:调油站信息接口落hive表
 * 需求方：娇悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:522
 * 任务名称：油站全量信息表
 * 依赖任务：无
 * 数据源：
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0
 * 数据结果：dm_ddjy_gas_station_info_di
 */
object GasStationInfoToHive  extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def stationInterface(spark: SparkSession, inc_day: String) = {
    import spark.implicits._
    var num:Long = 50000
    var flag=0
    var dataVersion: Int = 0
    var updateTimeStamp: String =""
    var finalUrl: String =""
    var finalStationInfoRdd: RDD[JSONObject] = spark.sparkContext.emptyRDD
    while (num==50000){
      if (flag==0){
        val stationUrlStart="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0&limitCount=50000&dataVersion=0&switchCode=BESTEXPRESSSF"
        logger.error("初始化接口url:"+stationUrlStart)
        val startObj: JSONObject = TrackUrlUtil.httpGetJSON(stationUrlStart,3)
        dataVersion = startObj.getIntValue("dataVersion")
        val data = startObj.getJSONArray("data").toArray()
        val stationInfoRdd = spark.sparkContext.parallelize(data).map(obj=>{
          val tmpObj: JSONObject = obj.asInstanceOf[JSONObject]
          tmpObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("第一次查询油站数据量:"+stationInfoRdd.count())
        updateTimeStamp = stationInfoRdd.map(obj => {
          val updateTimeStamp: String = obj.getString("updateTimeStamp")
          updateTimeStamp
        }).max()
        finalStationInfoRdd=stationInfoRdd
        num = stationInfoRdd.count()
        stationInfoRdd.unpersist()
        flag=1
        Thread.sleep(5000)
      }else{
        val stationUrl="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=%s&limitCount=50000&dataVersion=%d&switchCode=BESTEXPRESSSF"
        finalUrl = stationUrl.format(updateTimeStamp,dataVersion)
        logger.error("接口url:"+finalUrl)
        val retObj: JSONObject = TrackUrlUtil.httpGetJSON(finalUrl,3)
        val data = retObj.getJSONArray("data").toArray()
        val stationInfoRdd = spark.sparkContext.parallelize(data).map(obj=>{
          val tmpObj: JSONObject = obj.asInstanceOf[JSONObject]
          tmpObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("查询油站数据量:"+stationInfoRdd.count())
        updateTimeStamp = stationInfoRdd.map(obj => {
          val updateTimeStamp: String = obj.getString("updateTimeStamp")
          updateTimeStamp
        }).max()
        finalStationInfoRdd=stationInfoRdd.union(finalStationInfoRdd)
        num = stationInfoRdd.count()
        stationInfoRdd.unpersist()
        Thread.sleep(5000)
      }
    }


    println( finalStationInfoRdd.take(3).toList)

    val finalStationInfoDf: DataFrame = finalStationInfoRdd.map(data => {
      val check_GRPID = data.getString("GRPID")
      val check_poiid = data.getString("POIID")
      val check_srcId = data.getString("srcId")
      val name_chn = data.getString("stationName")
      val address = data.getString("addr")
      val x = data.getString("lng")
      val y = data.getString("lat")
      val check_src = data.getString("src")
      val queryBrand = data.getString("queryBrandID")
      val province = data.getString("province")
      val city = data.getString("city")
      val check_adcode = data.getString("adcode")
      val check_enableFlag = data.getString("enableFlag")
      val check_delFlag = data.getString("delFlag")
      var priceActivity = data.getString("priceActivityVec")
      priceActivity = priceActivity.replaceAll("\\[","").replaceAll("]","")

      val check_gunPriceVec = data.getString("gunPriceVec")
      val check_roadID = data.getString("roadID")
      val check_updateTimeStamp = data.getString("updateTimeStamp")
      val check_hasOilName = data.getString("hasOilName")
      val check_sfGunPriceVec = data.getString("sfGunPriceVec")
      var officialPriceVec = data.getString("officialPriceVec")
      officialPriceVec = officialPriceVec.replaceAll("\\[","").replaceAll("]","")

      val check_oilNameVec = data.getString("oilNameVec")
      val check_gapPriceVec = data.getString("gapPriceVec")
      val check_discountModelVec = data.getString("discountModelVec")

      var city_adcode =""
      var province_adcode =""

      if(!StringUtils.isEmpty(check_adcode)){
        city_adcode = check_adcode.substring(0, 4)

        province_adcode = check_adcode.substring(0,2)
      }
      val display_pos  = x + ","+ y

      val pro_lists = Seq("山东省", "陕西省", "山西省", "江西省", "湖南省", "贵州省", "安徽省", "新疆维吾尔自治区", "广东省", "江苏省", "湖北省", "上海市", "黑龙江省", "河北省","四川省", "云南省", "浙江省", "内蒙古自治区", "辽宁省", "吉林省", "广西壮族自治区", "福建省", "河南省", "海南省", "北京市", "天津市", "重庆市", "西藏自治区","青海省", "甘肃省", "宁夏回族自治区")
      val card_lists = Seq("鲁", "陕", "晋", "赣", "湘", "贵", "皖", "新", "粤", "苏", "鄂", "沪", "黑", "冀", "川", "云", "浙", "蒙", "辽", "吉", "桂","闽", "豫", "琼", "京", "津", "渝", "藏", "青", "甘", "宁")

      var card_list = ""
      if(pro_lists.contains(province)){
        card_list = card_lists(pro_lists.indexOf(province))
      }

      var Brand_name = ""
      if(queryBrand.toInt ==1){
        Brand_name = "中国石油"
      }else if(queryBrand.toInt ==2){
        Brand_name = "中国石化"
      }else {
        Brand_name=queryBrand
      }

      var Key_value2 =""

      val cityList = Seq("温州市", "宁波市", "金华市", "台州市", "湖州市", "丽水市", "舟山市", "嘉兴市", "绍兴市", "衢州市")
      if(cityList.indexOf(city)>0){
        Key_value2= city + "_" + Brand_name
      }else{
        Key_value2=province + "_" + Brand_name
      }

      val Key_value = 	city_adcode + ',' + Brand_name

      OilConfigStationClass(check_GRPID
        ,check_poiid
        ,check_srcId
        ,name_chn
        ,address
        ,x
        ,y
        ,check_src
        ,queryBrand
        ,province
        ,city
        ,check_adcode
        ,check_enableFlag
        ,check_delFlag
        ,priceActivity
        ,check_gunPriceVec
        ,check_roadID
        ,check_updateTimeStamp
        ,check_hasOilName
        ,check_sfGunPriceVec
        ,officialPriceVec
        ,check_oilNameVec
        ,check_gapPriceVec
        ,check_discountModelVec
        ,city_adcode
        ,province_adcode
        ,display_pos
        ,card_list
        ,Brand_name
        ,Key_value2
        ,Key_value)
    }).toDF().withColumn("inc_day",lit(inc_day))

    finalStationInfoDf.show(10)
    val resutlDf = finalStationInfoDf.filter('queryBrand.isin("1","2")  &&  'check_delFlag.isin("0"))
    writeToHive(spark,resutlDf,Seq("inc_day"),"dm_gis.oil_config_station")

    //    SparkWrite.writeToHiveNoPart(spark,finalStationInfoDf,"dm_gis.dm_ddjy_gas_station_info_di")
    //finalStationInfoDf.createOrReplaceTempView("finalStationInfoTmp")
    //spark.sql(s"insert overwrite table dm_gis.dm_ddjy_gas_station_info_di select * from finalStationInfoTmp")
  }



  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取全量油站
    stationInterface(spark, incDay)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>GasStationInfoToHive Execute Ok")
  }


  case class  OilConfigStationClass (check_GRPID:String
                                     ,check_poiid:String
                                     ,check_srcId:String
                                     ,name_chn:String
                                     ,address:String
                                     ,x:String
                                     ,y:String
                                     ,check_src:String
                                     ,queryBrand:String
                                     ,province:String
                                     ,city:String
                                     ,check_adcode:String
                                     ,check_enableFlag:String
                                     ,check_delFlag:String
                                     ,priceActivity:String
                                     ,check_gunPriceVec:String
                                     ,check_roadID:String
                                     ,check_updateTimeStamp:String
                                     ,check_hasOilName:String
                                     ,check_sfGunPriceVec:String
                                     ,officialPriceVec:String
                                     ,check_oilNameVec:String
                                     ,check_gapPriceVec:String
                                     ,check_discountModelVec:String
                                     ,city_adcode:String
                                     ,province_adcode:String
                                     ,display_pos:String
                                     ,card_list:String
                                     ,Brand_name:String
                                     ,Key_value2:String
                                     ,Key_value:String)

}
