package com.sf.gis.scala.scm.app.vehicleInsurance

import common.DataSourceCommon

/**
  * 重货日结数据从kafka中读取到hive中
  *
  *@author 01420395
  *@DESCRIPTION ${DESCRIPTION}
  *@create 20230420
  */
object ImportVehicleInsuranceFromKafkaToHive  extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val kafka_bootstrap_servers="10.202.218.5:9092,10.202.218.4:9092,10.202.218.6:9092"
  val kafka_topic="gis-vehicle-qgzh"

  def main(args: Array[String]): Unit = {
//    Kafka2HiveUtil.processTime("vehiclekafka2hive.properties", appName,"\t")
  }
}
