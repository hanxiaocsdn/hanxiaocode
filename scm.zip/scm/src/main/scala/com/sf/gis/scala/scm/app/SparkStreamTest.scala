//package com.sf.gis.scala.scm.app
//
//import com.fasterxml.jackson.databind.deser.std.StringDeserializer
//import org.apache.log4j.Logger
//import org.apache.spark.streaming.StreamingContext
//import org.apache.twill.kafka.client.TopicPartition
//import org.iq80.leveldb.DB
//
//object SparkStreamTest {
//  @transient lazy val logger: Logger = Logger.getLogger(Test.getClass)
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//  def main(args: Array[String]): Unit = {
//
//    val topic="topic1"
//    val group="spark_app1"
//
//    val kafkaParams= Map[String, Object](
//      "bootstrap.servers" -> "node1:6667,node2:6667,node3:6667",
//      "key.deserializer" -> classOf[StringDeserializer],
//      "value.deserializer" -> classOf[StringDeserializer],
//      "auto.offset.reset" -> "latest",//latest earliest
//      "enable.auto.commit" -> (false: java.lang.Boolean),
//      "group.id" -> group)
//
//    DBCPConnectionPool.singleton("jdbc:mysql://node3:3306/bigdata", "", "")
//
//    val initOffset=DB.readOnly(implicit session=>{
//      sql"select `partition`,offset from kafka_topic_offset where topic =${topic} and `group`=${group}"
//        .map(item=> new TopicPartition(topic, item.get[Int]("partition")) -> item.get[Long]("offset"))
//        .list().apply().toMap
//    })
//
//    //CreateDirectStream
//    //从指定的Topic、Partition、Offset开始消费
//    val sourceDStream =KafkaUtils.createDirectStream[String,String](
//      ssc,
//      LocationStrategies.PreferConsistent,
//      ConsumerStrategies.Assign[String,String](initOffset.keys,kafkaParams,initOffset)
//    )
//
//
//    sourceDStream.foreachRDD(rdd=>{
//      if (!rdd.isEmpty()){
//        val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
//        offsetRanges.foreach(offsetRange=>{
//          logger.info(s"Topic: ${offsetRange.topic},Group: ${group},Partition: ${offsetRange.partition},fromOffset: ${offsetRange.fromOffset},untilOffset: ${offsetRange.untilOffset}")
//        })
//
//        //统计分析
//        //将结果收集到Driver端
//        val sparkSession = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()
//        import sparkSession.implicits._
//        val dataFrame = sparkSession.read.json(rdd.map(_.value()).toDS)
//        dataFrame.createOrReplaceTempView("tmpTable")
//        val result=sparkSession.sql(
//          """
//            |select
//            |   --每分钟
//            |   eventTimeMinute,
//            |   --每种语言
//            |   language,
//            |   -- 次数
//            |   count(1) pv,
//            |   -- 人数
//            |   count(distinct(userID)) uv
//            |from(
//            |   select *, substr(eventTime,0,16) eventTimeMinute from tmpTable
//            |) as tmp group by eventTimeMinute,language
//          """.stripMargin
//        ).collect()
//
//        //在Driver端存储数据、提交Offset
//        //结果存储与Offset提交在同一事务中原子执行
//        //这里将偏移量保存在Mysql中
//        DB.localTx(implicit session=>{
//
//          //结果存储
//          result.foreach(row=>{
//            sql"""
//            insert into twitter_pv_uv (eventTimeMinute, language,pv,uv)
//            value (
//                ${row.getAs[String]("eventTimeMinute")},
//                ${row.getAs[String]("language")},
//                ${row.getAs[Long]("pv")},
//                ${row.getAs[Long]("uv")}
//                )
//            on duplicate key update pv=pv,uv=uv
//          """.update.apply()
//          })
//
//          //Offset提交
//          offsetRanges.foreach(offsetRange=>{
//            val affectedRows = sql"""
//          update kafka_topic_offset set offset = ${offsetRange.untilOffset}
//          where
//            topic = ${topic}
//            and `group` = ${group}
//            and `partition` = ${offsetRange.partition}
//            and offset = ${offsetRange.fromOffset}
//          """.update.apply()
//
//            if (affectedRows != 1) {
//              throw new Exception(s"""Commit Kafka Topic: ${topic} Offset Faild!""")
//            }
//          })
//        })
//      }
//    })
//
//    ssc.start()
//    ssc.awaitTermination()
//  }
//}
