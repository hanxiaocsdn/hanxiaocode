//package com.sf.gis.scala.scm.app
//
//import com.sf.gis.scala.scm.utils.DateTimeUtil
//import org.apache.log4j.Logger
//import org.apache.spark.SparkConf
//import org.apache.spark.sql.execution.QueryExecution
//import org.apache.spark.streaming.{Seconds, StreamingContext}
//import org.apache.spark.sql.util.QueryExecutionListener
//
//import scala.reflect.ClassTag
//
//object Test  extends  QueryExecutionListener{
//  @transient lazy val logger: Logger = Logger.getLogger(Test.getClass)
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//  case class TrajectoryAnomalyClass(id:String,
//                                       sum:Int)
//
//  case class TrajectoryAnomalyClassTag(id:String,
//                                    sum:Int) extends ClassTag[TrajectoryAnomalyClass] {
//    override def runtimeClass: Class[_] = TrajectoryAnomalyClass.getClass
//  }
//
//
//  def onSuccess(funcName: String, qe: QueryExecution, durationNs: Long) = {
//    qe.
//
//  }
//
//  def main(args: Array[String]): Unit = {
//    //    var endDateTime = "2023-9-20 8:25:04"
//    //    endDateTime = DateUtil.getdaysBefore(endDateTime,0,"yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
//    //    println(endDateTime.replaceAll("-","").replaceAll(" ","").replaceAll(":",""))
//    val conf  = new SparkConf()
//      .setMaster("local[2]")
//      .setAppName("test")
//
//
//
//    val sparkStream = new StreamingContext(conf,Seconds(10))
//    sparkStream.checkpoint("file:\\E:\\caiguofang\\workspace\\gis-ass-oms-bd-20230928\\gis-ass-oms-bd\\scm\\src\\main\\resource\\checkpoints")
//
//    //    val fileDS =  sparkStream.fileStream("E:\\caiguofang\\workspace\\gis-ass-oms-bd-20230928\\gis-ass-oms-bd\\scm\\src\\main\\resource\\city_distance.txt")
//    val fileDS = sparkStream.textFileStream("file:///E:\\caiguofang\\workspace\\gis-ass-oms-bd-20230928\\gis-ass-oms-bd\\scm\\src\\main\\resource\\city_distance.csv")
//      .checkpoint(Seconds(10))
//    //    val fileDS =  sparkStream.socketTextStream("localhost",9999).checkpoint(Seconds(10))
//    fileDS.context.sparkContext.files.foreach(println(_))
//    val resultDF  = fileDS.flatMap(row =>{
//      row.split(",")
//    }).map(row  => (row,1))
//      .updateStateByKey((values: Seq[TrajectoryAnomalyClassTag], state: Option[TrajectoryAnomalyClassTag])=>{
//
//        TrajectoryAnomalyClassTag("tst", 1)
//
//      })
//    //.reduceByKeyAndWindow(((a:Int,b:Int)=> {a + b}),Seconds(30), Seconds(10))
//
//
//    sparkStream.start()
//
//    sparkStream.awaitTermination()
//    //
//    //    val cols = Seq("task_id")
//    //
//    //    val inputPath = "E:\\caiguofang\\导航相关资料/20231007.csv"
//    //    val taskDF = spark.read.option("header", "false")
//    //      .option("delimiter", "\\t")
//    //      .option("inferSchema", true)
//    //      .option("numPartitions", 100)
//    //      .csv(inputPath)
//    //      .toDF((cols): _*)
//    //      .repartition(50)
//    //      .select(cols.map(col): _*).drop("tab").distinct()
//    //
//    //    taskDF.show(1, true)
//
//
//    val before_one_day = DateTimeUtil.getDaysApartDate("yyyyMMdd", "20231010",-893)
//
//    println(before_one_day)
//
//  }
//}
