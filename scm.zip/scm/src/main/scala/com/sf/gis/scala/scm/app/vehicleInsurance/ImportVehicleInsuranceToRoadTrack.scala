package com.sf.gis.scala.scm.app.vehicleInsurance

import com.alibaba.fastjson.JSON
import common.DataSourceCommon
import org.apache.spark.sql.Row
import org.apache.spark.sql.catalyst.expressions.RowNumber
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.{DateUtil, SparkBuilder}


/**
 * 重货日结数据从kafka原始表数据中读取到hive日结表中,原始数据有可能重复; 需要进行去重
 *
 *@author 01420395 任务id: 769430
 *@DESCRIPTION ${DESCRIPTION}
 *@create 20230420
 */
object ImportVehicleInsuranceToRoadTrack   extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)
    val end_day =  DateUtil.getdaysBefore(inc_day.replaceAll("-",""),5,"yyyyMMdd")
    val start_day = DateUtil.getdaysBefore(inc_day.replaceAll("-",""),-5,"yyyyMMdd")

//    val end_day =  DateUtil.getdaysBefore(DateUtil.getCurrentDate("yyyyMMdd"),5,"yyyyMMdd")
//    val start_day = DateUtil.getdaysBefore(DateUtil.getCurrentDate("yyyyMMdd"),-5,"yyyyMMdd")

    val sql =
      s"""
        select distinct log from dm_gis.insurance_model_duration_dist_daily_qgzh_kafka where inc_day  between '${start_day}' and '${end_day}'
      """.stripMargin

    logger.error("kafka数据日期: " + start_day +  " == " +end_day + " 业务日期 : " + inc_day )

    logger.error(sql)


    val insuranceKafkaDF = spark.sql(sql)

    logger.error(s">>>> kafka 消费 ${inc_day} 总批次: " + insuranceKafkaDF.count())

    val cols = Seq(
      "un"
      ,"road_rank"
      ,"road_ids"
      ,"if_highspeed"
      ,"road_start_time"
      ,"road_end_time"
      ,"road_start_adcode"
      ,"road_end_adcode"
      ,"road_dist"
      ,"tl_periods"
      ,"tl_link"
      ,"tl_roadclass"
      ,"vehicle_color"
      ,"vin"
      ,"vehicle_weight"
      ,"company_name"
      ,"is_lkyw"
      ,"license_regist_date"
      ,"sys_regist_date"
      ,"push_time"
      ,"update_time"
      ,"inc_day"
    )
    import org.apache.spark.sql.functions._
    import spark.implicits._
    val insuranceKafkaLogDF1 =  insuranceKafkaDF.filter(
      get_json_object('log,"$.time")===s"${inc_day}"
        &&  get_json_object('log,"$.dataType")==="car-stat")




    val insuranceKafkaLogDF = insuranceKafkaLogDF1
      .withColumn("log", get_json_object('log,"$.data")).select('log)

    insuranceKafkaLogDF.show(1, false)

    logger.error(s">>>> kafka 消费 ${inc_day}批次 : " + insuranceKafkaLogDF.count())

    //解析json字段
    val insuranceRdd  = insuranceKafkaLogDF.rdd.flatMap(row =>{
      JSON.parseArray(row.getAs[String](0)).toArray
    }).map(row  => {
      val jsonObject = JSON.parseObject(row.toString)
      val road_ids = jsonObject.getString("road_ids")
      val if_highspeed = jsonObject.getString("if_highspeed")

      val road_dist = jsonObject.getString("road_dist")
      val road_end_adcode = jsonObject.getString("road_end_adcode")
      val road_end_time = jsonObject.getString("road_end_time")
      val road_rank = jsonObject.getString("road_rank")
      val road_start_adcode = jsonObject.getString("road_start_adcode")
      val road_start_time = jsonObject.getString("road_start_time")
      val tl_link = jsonObject.getString("tl_link")
      val tl_periods = jsonObject.getString("tl_periods")

      val vin = ""
      val vehicle_weight = ""
      val company_name = ""
      val is_lkyw = ""
      val license_regist_date = ""
      val sys_regist_date = ""


      val un = jsonObject.getString("un")
      val vehicle_color = un.split("_")(1)
      val push_time  =jsonObject.getString("push_time")

      val update_time = push_time

      val tl_roadclass = jsonObject.getString("tl_roadclass")
      val inc_day = jsonObject.getString("inc_day")


      Row(un,road_rank
        ,road_ids
        ,if_highspeed
        ,road_start_time
        ,road_end_time
        ,road_start_adcode
        ,road_end_adcode
        ,road_dist
        ,tl_periods
        ,tl_link
        ,tl_roadclass
        ,vehicle_color
        ,vin
        ,vehicle_weight
        ,company_name
        ,is_lkyw
        ,license_regist_date
        ,sys_regist_date
        ,push_time
        ,update_time
        ,inc_day)
    })




    logger.error("业务日期: " + inc_day + " >>>  总条数 " + insuranceRdd.count())
    val fields = cols.map(fieldsName => StructField(fieldsName,StringType,nullable = true))
    val schema = StructType(fields)
    val insuranceDF = spark.createDataFrame(insuranceRdd,schema)

    val resultDf = insuranceDF.withColumn("rn", row_number() over( Window.partitionBy("un","inc_day").orderBy(asc("push_time"))))
      .filter('rn ===1)

    logger.error("业务日期: " + inc_day + " >>>  总条数 " + insuranceDF.count())

    resultDf.show(1, false)

    val resultDf1 = resultDf.drop("push_time","rn")

    writeToHive(spark, resultDf1, Seq("inc_day"), "dm_gis.road_track_info_daily")
  }

}
