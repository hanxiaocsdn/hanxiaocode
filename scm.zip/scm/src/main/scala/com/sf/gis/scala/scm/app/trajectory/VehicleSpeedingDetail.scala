package com.sf.gis.scala.scm.app.trajectory

import java.text.SimpleDateFormat
import java.util.Date
import com.alibaba.fastjson
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.util.HttpUtils
import common.DataSourceCommon
import utils.SparkUtil.row2Json
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.{SparkBuilder, SparkUtils, StringUtils}

import scala.collection.mutable.ArrayBuffer

/**
@author 01420395
@DESCRIPTION GIS-RSS-SCM：【陆运油耗管控报表】陆运油耗管数据报表需求_V1.0 需求id 1948035 任务id:
车辆任务超速明细数据: 1.  获取表 dm_gis.eta_std_line_recall  where  carrier_type=0 数据
             2. 调用接口获取轨迹点信息
             3. 根据车辆吨位判断对应速度是否超速,
@create 2023/08/16 任务id 791583 任务依赖：  794860
  */
object VehicleSpeedingDetail  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //  val url:String = "http://gis-vms-query-new.sf-express.com:80/trackquery-new/api/integrateDetail" //办公网访问地址
  val url:String ="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail" //bdp访问地址
  val ak:String = "93ec117f7f1b4226b4e537c4802319e9"


  def main(args: Array[String]): Unit = {

    val inc_day  = args(0)
    //获取前30天
    val sparkSession = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sql =s"""
         select task_id
          ,task_subid
          ,vehicle_serial
          ,actual_capacity_load
          ,zytype
          ,area_code
          ,area_name
          ,driver_id
          ,driver_name
          ,plan_depart_tm
          ,actual_depart_tm
          ,plan_arrive_tm
          ,actual_arrive_tm
          ,line_time
          ,actual_run_time
          ,early_arrival_time as  early_arrival_time
          ,'' start_time
          ,'' end_time
          ,'' start_area
          ,'' end_area
          ,'' start_speed
          ,'' end_speed
          ,'' duration_overspeed_s
          ,'' duration_overspeed_min
          ,'' max_sp
          ,'' min_sp
          ,'' overspeed_mileage
          ,'' avg_sp
          ,'' start_date
          ,'' sp_distribution
          ,'' over_sp_road_class
        from (
          select task_id
            ,task_subid
            ,vehicle_serial
            ,actual_capacity_load
            ,driver_id
            ,driver_name
            ,plan_depart_tm
            ,nvl(actual_depart_tm,plan_depart_tm) as actual_depart_tm
            ,plan_arrive_tm
            ,nvl(actual_arrive_tm,plan_arrive_tm) as actual_arrive_tm
            ,line_time
            ,actual_run_time
            ,line_time - actual_run_time as early_arrival_time
            from  dm_gis.eta_std_line_recall
            where inc_day  = '${inc_day}' and carrier_type=0
          ) t0
        left join(select carplate,zytype from dm_arss.dm_device_hh_dtl_di where inc_day = '${inc_day}') t1 on t0.vehicle_serial=t1.carplate
        left join(select vehicle_code,dept_id from ods_vms.tm_vms_vehicle where inc_day ='${inc_day}') t2 on t0.vehicle_serial=t2.vehicle_code
        left join(select dept_id,dept_code,area_code,area_name from dim.dim_dept_info_df where inc_day ='${inc_day}') t3 on  t2.dept_id = t3.dept_id
      """.stripMargin

    logger.error(sql)

    val sourceDF = sparkSession.sql(sql)

    val filterRdd =  sourceDF.filter(row  => {val endTime = row.getAs[String]("actual_arrive_tm")
      !StringUtils.isEmpty(endTime)
    } )


    val sourceJson = SparkNet.runInterfaceWithAkLimit1(sparkSession, filterRdd.rdd.map(row2Json), runIntegrateDetailInteface, 20, ak, 3600)


//    val sourceJson  = SparkUtils.getRowToJson(rdd_rdd_detail_toll)

    logger.error("原始数据: " + sourceJson.count())

    val  count  = sourceJson.count


    val httpInvokeId  = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01420395"
      ,"791583","陆运油耗管控报表超速数据","陆运油耗管控报表超速数据"
      ,url,ak,count,60
    )




    val resultRDD =  sourceJson.flatMap(_.toSeq).flatMap(row  => {
      val task_id = row.getString("task_id")
      val task_subid = row.getString("task_subid")
      val vehicle_serial = row.getString("vehicle_serial")
      val actual_capacity_load = row.getString("actual_capacity_load")
      val zytype = row.getString("zytype")
      val area_code = row.getString("area_code")
      val area_name = row.getString("area_name")
      val driver_id = row.getString("driver_id")
      val driver_name = row.getString("driver_name")
      val plan_depart_tm = row.getString("plan_depart_tm")
      val actual_depart_tm = row.getString("actual_depart_tm")
      val plan_arrive_tm = row.getString("plan_arrive_tm")
      val actual_arrive_tm = row.getString("actual_arrive_tm")
      val line_time = row.getString("line_time")
      val actual_run_time = row.getString("actual_run_time")
      val early_arrival_time = row.getString("early_arrival_time")
      val start_time = row.getString("start_time")
      val end_time = row.getString("end_time")
      val start_area = row.getString("start_area")
      val end_area = row.getString("end_area")
      val start_speed = row.getString("start_speed")
      val end_speed = row.getString("end_speed")
      val duration_overspeed_s = row.getString("duration_overspeed_s")
      val duration_overspeed_min = row.getString("duration_overspeed_min")
      val max_sp = row.getString("max_sp")
      val min_sp = row.getString("min_sp")
      val overspeed_mileage = row.getString("overspeed_mileage")
      val avg_sp = row.getString("avg_sp")
      val date = row.getString("date")
      val sp_distribution = row.getString("sp_distribution")
      val over_sp_road_class = row.getString("over_sp_road_class")
      val arrayBuffer = new ArrayBuffer[Row]()

      val over_sp_road_classs=  JSON.parseObject(over_sp_road_class)

      if(over_sp_road_classs == null || over_sp_road_classs.isEmpty || over_sp_road_classs.keySet()==null ||over_sp_road_classs.keySet().isEmpty ){
        val row  =  Row(task_id
          ,task_subid
          ,vehicle_serial
          ,actual_capacity_load
          ,zytype
          ,area_code
          ,area_name
          ,driver_id
          ,driver_name
          ,plan_depart_tm
          ,actual_depart_tm
          ,plan_arrive_tm
          ,actual_arrive_tm
          ,line_time
          ,actual_run_time
          ,early_arrival_time
          ,start_time
          ,end_time
          ,start_area
          ,end_area
          ,start_speed
          ,end_speed
          ,duration_overspeed_s
          ,duration_overspeed_min
          ,max_sp
          ,min_sp
          ,overspeed_mileage
          ,avg_sp
          ,date
          ,sp_distribution
          ,"")
        arrayBuffer.append(row)
      }else{
        val iterator = over_sp_road_classs.keySet().iterator()
        if(!iterator.hasNext){
          val row  =  Row(task_id
            ,task_subid
            ,vehicle_serial
            ,actual_capacity_load
            ,zytype
            ,area_code
            ,area_name
            ,driver_id
            ,driver_name
            ,plan_depart_tm
            ,actual_depart_tm
            ,plan_arrive_tm
            ,actual_arrive_tm
            ,line_time
            ,actual_run_time
            ,early_arrival_time
            ,start_time
            ,end_time
            ,start_area
            ,end_area
            ,start_speed
            ,end_speed
            ,duration_overspeed_s
            ,duration_overspeed_min
            ,max_sp
            ,min_sp
            ,overspeed_mileage
            ,avg_sp
            ,date
            ,sp_distribution
            ,"")
          arrayBuffer.append(row)
        }else{
          while (iterator.hasNext){
            val over_sp_road_class_a = iterator.next()
            val row  =  Row(task_id
              ,task_subid
              ,vehicle_serial
              ,actual_capacity_load
              ,zytype
              ,area_code
              ,area_name
              ,driver_id
              ,driver_name
              ,plan_depart_tm
              ,actual_depart_tm
              ,plan_arrive_tm
              ,actual_arrive_tm
              ,line_time
              ,actual_run_time
              ,early_arrival_time
              ,start_time
              ,end_time
              ,start_area
              ,end_area
              ,start_speed
              ,end_speed
              ,duration_overspeed_s
              ,duration_overspeed_min
              ,max_sp
              ,min_sp
              ,overspeed_mileage
              ,avg_sp
              ,date
              ,sp_distribution
              ,over_sp_road_class_a)
            arrayBuffer.append(row)
          }
        }
      }

      arrayBuffer.toSeq
    })

    BdpTaskRecordUtil.endNetworkInterface("01420395",httpInvokeId)

    val schema = StructType(List(
      StructField("task_id", StringType, true)
      ,StructField("task_subid", StringType, true)
      ,StructField("vehicle_serial", StringType, true)
      ,StructField("actual_capacity_load", StringType, true)
      ,StructField("zytype", StringType, true)
      ,StructField("area_code", StringType, true)
      ,StructField("area_name", StringType, true)
      ,StructField("driver_id", StringType, true)
      ,StructField("driver_name", StringType, true)
      ,StructField("plan_depart_tm", StringType, true)
      ,StructField("actual_depart_tm", StringType, true)
      ,StructField("plan_arrive_tm", StringType, true)
      ,StructField("actual_arrive_tm", StringType, true)
      ,StructField("line_time", StringType, true)
      ,StructField("actual_run_time", StringType, true)
      ,StructField("early_arrival_time", StringType, true)
      ,StructField("start_time", StringType, true)
      ,StructField("end_time", StringType, true)
      ,StructField("start_area", StringType, true)
      ,StructField("end_area", StringType, true)
      ,StructField("start_speed", StringType, true)
      ,StructField("end_speed", StringType, true)
      ,StructField("duration_overspeed_s", StringType, true)
      ,StructField("duration_overspeed_min", StringType, true)
      ,StructField("max_sp", StringType, true)
      ,StructField("min_sp", StringType, true)
      ,StructField("overspeed_mileage", StringType, true)
      ,StructField("avg_sp", StringType, true)
      ,StructField("start_date", StringType, true)
      ,StructField("sp_distribution", StringType,   true)
      ,StructField("over_sp_road_class", StringType, true)
    ))

    import org.apache.spark.sql.functions.lit
    val resultRdd = sparkSession.createDataFrame(resultRDD, schema)
      .withColumn("inc_day",lit(inc_day))

    resultRdd.show(10,false)

    writeToHive(sparkSession,resultRdd,Seq("inc_day"),"dm_gis.vehicle_task_speeding_detail")

  }



  def runIntegrateDetailInteface(ak:String, row: JSONObject):Seq[JSONObject] = {
      val vehicle = row.getString("vehicle_serial")
      //todo 需要进行日期格式化
      val beginDateTime = row.getString("actual_depart_tm")
      val endDateTime = row.getString("actual_arrive_tm")
      val actual_capacity_load = row.getDouble("actual_capacity_load") //吨位
      val task_id = row.getString("task_id")
      val task_subid = row.getString("task_subid")
      val zytype = row.getString("zytype")
      val area_code = row.getString("area_code")
      val area_name = row.getString("area_name")
      val driver_id = row.getString("driver_id")
      val driver_name = row.getString("driver_name")
      val plan_depart_tm = row.getString("plan_depart_tm")
      val actual_depart_tm = row.getString("actual_depart_tm")
      val plan_arrive_tm = row.getString("plan_arrive_tm")
      val actual_arrive_tm = row.getString("actual_arrive_tm")
      val line_time = row.getString("line_time")
      val actual_run_time = row.getString("actual_run_time")
      val early_arrival_time = row.getString("early_arrival_time")

      val postJson = new JSONObject()
      postJson.put("type","401")
      postJson.put("un",vehicle)
      postJson.put("unType","0")
      postJson.put("ak",ak)
      postJson.put("beginDateTime",beginDateTime.replaceAll("-","").replaceAll(" ","").replaceAll(":",""))
      postJson.put("endDateTime",endDateTime.replaceAll("-","").replaceAll(" ","").replaceAll(":",""))

      val result =  HttpUtils.post(url,postJson,"utf-8")
      //      val result  = UrlUtil.sendPost(url, postJson.toJSONString, 5)



      logger.error("返回数据: " +  result)
      val highTracksArray = new ArrayBuffer[JSONObject]()

      //解析返回数据获取对应的速度轨迹信息
      if(!StringUtils.isEmpty(result)){

        val resultJson =  JSON.parseObject(result)
        val status  =  resultJson.getInteger("status")
        if(status  ==0){
          val trackArray  = resultJson.getJSONObject("result").getJSONObject("data").getJSONArray("track")
          val iterator  = trackArray.iterator()
          val higherSp = new ArrayBuffer[JSONObject]()

          //是否连续
          var isContinuous = true
          while (iterator.hasNext){
            if(!isContinuous && higherSp.size>0){

              val maxSpeedingJson =  builderSpeedingFromSpArray(higherSp,vehicle)

              maxSpeedingJson.put("task_id",task_id)
              maxSpeedingJson.put("task_subid",task_subid)
              maxSpeedingJson.put("vehicle_serial",vehicle)
              maxSpeedingJson.put("zytype",zytype)
              maxSpeedingJson.put("area_code",area_code)
              maxSpeedingJson.put("area_name",area_name)
              maxSpeedingJson.put("driver_id",driver_id)
              maxSpeedingJson.put("driver_name",driver_name)
              maxSpeedingJson.put("plan_depart_tm",plan_depart_tm)
              maxSpeedingJson.put("actual_depart_tm",actual_depart_tm)
              maxSpeedingJson.put("plan_arrive_tm",plan_arrive_tm)
              maxSpeedingJson.put("actual_arrive_tm",actual_arrive_tm)
              maxSpeedingJson.put("line_time",line_time)
              maxSpeedingJson.put("actual_run_time",actual_run_time)
              maxSpeedingJson.put("early_arrival_time",early_arrival_time)
              maxSpeedingJson.put("actual_capacity_load",actual_capacity_load)


              highTracksArray.append(maxSpeedingJson)
              higherSp.clear()

            }

            val track = iterator.next()
            val trackJson = JSON.parseObject(track.toString)
            val sp = trackJson.getDouble("sp")
            val tm = trackJson.getLong("tm")
            val roadClass = trackJson.getLong("roadClass")
            val roadName = trackJson.getString("roadName")

            val trackJsonNew =  new JSONObject()
            //超速
            if (actual_capacity_load < 5 && sp >= 80 || actual_capacity_load >= 5 && sp >= 90){
              trackJsonNew.put("sp",sp)
              trackJsonNew.put("tm",tm)
              trackJsonNew.put("roadClass",roadClass)
              trackJsonNew.put("roadName",roadName)
              higherSp.append(trackJsonNew)
              isContinuous = true
            }else{
              isContinuous = false
            }
          }


          //最后一次的进行数据清洗,只有当是超速才进行数据拼接
          if(higherSp.size>0 && isContinuous){
            val task_id = row.getString("task_id")
            val task_subid = row.getString("task_subid")
            val vehicle_serial = row.getString("vehicle_serial")
            val zytype = row.getString("zytype")
            val driver_id = row.getString("driver_id")
            val driver_name = row.getString("driver_name")
            val plan_depart_tm = row.getString("plan_depart_tm")
            val actual_depart_tm = row.getString("actual_depart_tm")
            val plan_arrive_tm = row.getString("plan_arrive_tm")
            val actual_arrive_tm = row.getString("actual_arrive_tm")
            val line_time = row.getString("line_time")
            val actual_run_time = row.getString("actual_run_time")
            val early_arrival_time = row.getString("early_arrival_time")

            val maxSpeedingJson =  builderSpeedingFromSpArray(higherSp,vehicle_serial)

            maxSpeedingJson.put("task_id",task_id)
            maxSpeedingJson.put("task_subid",task_subid)
            maxSpeedingJson.put("vehicle_serial",vehicle_serial)
            maxSpeedingJson.put("zytype",zytype)
            maxSpeedingJson.put("area_code",area_code)
            maxSpeedingJson.put("area_name",area_name)
            maxSpeedingJson.put("driver_id",driver_id)
            maxSpeedingJson.put("driver_name",driver_name)
            maxSpeedingJson.put("plan_depart_tm",plan_depart_tm)
            maxSpeedingJson.put("actual_depart_tm",actual_depart_tm)
            maxSpeedingJson.put("plan_arrive_tm",plan_arrive_tm)
            maxSpeedingJson.put("actual_arrive_tm",actual_arrive_tm)
            maxSpeedingJson.put("line_time",line_time)
            maxSpeedingJson.put("actual_run_time",actual_run_time)
            maxSpeedingJson.put("early_arrival_time",early_arrival_time)
            maxSpeedingJson.put("actual_capacity_load",actual_capacity_load)
            highTracksArray.append(maxSpeedingJson)
          }
        }
      }
      highTracksArray.toSeq
  }



  def builderSpeedingFromSpArray(higherSp :ArrayBuffer[JSONObject],vehicle:String)={

    //不连续的时候需要进行数据分段, 然后进行数据拆分; 计算总数据
    val sdf1  = new SimpleDateFormat("yyyyMMddHHmmss")
    val start_time = higherSp(0).getString("tm")//	超速开始时间
    val start_time_fr = sdf1.format(new Date(start_time.toLong*1000L))

    var end_time = higherSp(higherSp.size-1).getString("tm")//	超速结束时间
    //只有一个轨迹点的时候, 结束开始时间相差 1
    if(higherSp.size==1){
      end_time = (end_time.toLong+1).toString
    }

    val end_time_fr = sdf1.format(new Date(end_time.toLong*1000L))

    val start_area = higherSp(0).getString("roadName")//	超速开始地点
    val end_area =higherSp(higherSp.size-1).getString("roadName")//	超速结束地点

    val start_speed = higherSp(0).getString("sp")//	开始速度
    val end_speed =higherSp(higherSp.size-1).getString("sp")//	结束速度
    //
    val postJson = new fastjson.JSONObject()
    postJson.put("type","401")
    postJson.put("un",vehicle)
    postJson.put("unType","0")

    val iterator  = higherSp.iterator
    var spSum =  0.0
    while(iterator.hasNext){
      val track  = iterator.next()
      spSum = spSum + track.getDouble("sp")
    }


    postJson.put("beginDateTime",start_time_fr)
    postJson.put("endDateTime",end_time_fr)
    postJson.put("ak",ak)
    val result =  HttpUtils.post(url,postJson,"utf-8")
    //解析返回数据获取对应的速度轨迹信息
    val resultJson =  JSON.parseObject(result)
    val status  =  resultJson.getInteger("status")

    var over_sp_road_class=""
    var duration_overspeed_s=0.0
    var duration_overspeed_min=0.0
    var overspeed_mileage=0.0

    var max_sp,min_sp = 0.00

    if(status ==0){
      val data  = resultJson.getJSONObject("result").getJSONObject("data")
      over_sp_road_class =data.getString("rc_distance")//	超速区间道路等级
      duration_overspeed_s =data.getDouble("roadTime")//	超速持续时间(s) todo 数据转换
      duration_overspeed_min =data.getDouble("roadTime")/60 //	超速持续时间(min)  todo 数据转换
      overspeed_mileage =data.getDouble("len")/1000 //	超速里程
      val (max_sp_1,min_sp_1) = builderMaxMinSp(data.getJSONArray("track"))//	最大/最小sp
      max_sp = max_sp_1
      min_sp = min_sp_1
    }


    //    val avg_sp = overspeed_mileage/duration_overspeed_min/60/60 ///	平均速度 公里/每小时
    val avg_sp = spSum/higherSp.size ///	平均速度 公里/每小时


    val sdf  = new SimpleDateFormat("yyyy-MM-dd")
    val date = sdf.format(new Date(start_time.toLong*1000L))//	日期

    val sp_distribution =builderAvgSp(avg_sp)//	速度分布

    val json =  new JSONObject()
    val sdf2  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

    json.put("start_time",sdf2.format(new Date(start_time.toLong*1000L)))
    json.put("end_time",sdf2.format(new Date(end_time.toLong*1000L)))
    json.put("start_area",start_area)
    json.put("end_area",end_area)
    json.put("start_speed",start_speed)
    json.put("end_speed",end_speed)
    json.put("max_sp",max_sp)
    json.put("min_sp",min_sp)
    json.put("avg_sp",avg_sp)
    json.put("date",date)
    json.put("sp_distribution",sp_distribution)
    json.put("over_sp_road_class",over_sp_road_class)
    json.put("duration_overspeed_s",duration_overspeed_s)
    json.put("duration_overspeed_min",duration_overspeed_min)
    json.put("overspeed_mileage",overspeed_mileage)

    json

  }


  def builderAvgSp(avg_sp:Double):String={
    (math.floor(avg_sp/5)*5).toInt +"-" + (math.ceil(avg_sp/5)*5).toInt
  }



  def builderMaxMinSp(trucks : JSONArray):(Double,Double)={
    var maxSp = 0.0
    var minSp = 200.00
    val iterator  = trucks.iterator
    while(iterator.hasNext){
      val truck  = iterator.next()
      val sp = JSON.parseObject(truck.toString).getDouble("sp")
      if(maxSp < sp){
        maxSp = sp
      }

      if(minSp > sp){
        minSp = sp
      }
    }
    (maxSp,minSp)
  }

}
