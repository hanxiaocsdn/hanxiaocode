package com.sf.gis.scala.scm.app.jysd

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DateTimeUtil, JSONUtils, SparkUtils}

import scala.collection.mutable


/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/10/25
*/



object experienceSpeedEtaProcess2Online2ToSF {

  @transient lazy val logger: Logger = Logger.getLogger(experienceSpeedEtaProcess2Online2ToSF.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class experienceSpeed(
                              adcode:String,
                              swid_in:String,
                              dir:String,
                              time_range:String,
                              weekday:String,
                              avg_speed:String,
                              frequecy:String,
                              quantile_50:String,
                              quantile_60:String,
                              quantile_70:String
                            )


  val weekFileNameMap = new mutable.HashMap[Int,String]()
  weekFileNameMap.put(1,"mon")
  weekFileNameMap.put(2,"tue")
  weekFileNameMap.put(3,"wed")
  weekFileNameMap.put(4,"thu")
  weekFileNameMap.put(5,"fri")
  weekFileNameMap.put(6,"sat")
  weekFileNameMap.put(7,"sun")



  val speedTableName = "dm_gis.eta_experience_speed_info_daily_quantile"

  val crossTableName = "dm_gis.eta_experience_cross_info_daily_quantile"



  def main(args: Array[String]): Unit = {

    val inc_day = args(0)

    val end_day = args(1)
    start(inc_day, end_day)

  }




  def getFixSourceTable(spark: SparkSession, inc_day: String) = {
    val sourceSql =
      s"""
         |select
         |  un,info
         |from
         |  dm_gis.eta_experience_speed_tracks_fix_info2
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin


    import  org.apache.spark.sql.functions._
    import  spark.implicits._


    val sourceRdd = spark.sql(sourceSql).withColumn("info",get_json_object('info,"$.result"))

      .repartition(400).rdd.map(x => {
      var json = try {
        JSON.parseObject(x.getString(1))
      } catch {
        case e: Exception => new JSONObject()
      }
      if(json ==null){
        json = new JSONObject()
      }
      val un = x.getString(0)
      json.put("un",un)
      json
    }).filter(x => {
      val roadcosts = x.getJSONArray("roadcosts")
      val roadspeed = x.getJSONArray("roadspeed")

      (!x.isEmpty) && roadcosts != null && roadspeed != null
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("输入数据量为：" + sourceRdd.count())
//    sourceRdd.take(2).foreach(println(_))

    sourceRdd


  }


  /**
    * 解析不同类型的接口返回结果
    * @param getFixSourceRdd
    * @param strType
    * @return
    */

  def parsefixResponse(getFixSourceRdd: RDD[JSONObject], strType: String, step:Int) = {

    val roadcostsRdd = getFixSourceRdd.flatMap(x => {

      val roadcosts = x.getJSONArray(strType)

      var joList = List[JSONObject]()


      for (i <- (0 until (roadcosts.size())) by step) {
        val jo = roadcosts.getJSONObject(i)
        joList = joList :+ jo
      }

      joList

    })
    roadcostsRdd

  }

  /**
    * 从结果解析货车经验速度日志返回
    * @param spark
    * @param inc_day
    * @return
    */

  def parseFixTable(spark: SparkSession, inc_day: String) = {

    val getFixSourceRdd = getFixSourceTable(spark, inc_day)

    val jsonCostsRdd = parsefixResponse(getFixSourceRdd, "roadcosts",1)
    val jsonSpeedRdd = parsefixResponse(getFixSourceRdd, "roadspeed",1)

    (jsonCostsRdd, jsonSpeedRdd)
  }

  def calJsonCostsRdd(jsonCostsRdd: RDD[JSONObject], inc_day: String) = {

    val jsonCostsRdd2 = jsonCostsRdd.filter(x => {
      val crosscost = JSONUtils.getJsonValueDouble(x, "crosscost", 0)
      crosscost >= 0  && crosscost <= 1000
    }).map(x => {

      val swid_in = JSONUtils.getJsonValue(x, "in", "")
      val swid_out = JSONUtils.getJsonValue(x, "out", "")
      val adcode = JSONUtils.getJsonValue(x, "adcode", "")
      val tm = JSONUtils.getJsonValueInt(x, "time", 0)
      val periodType = try {DateTimeUtil.getPeriodTimeIndex(tm, inc_day)} catch {case e:Exception => 0}

      ((adcode, swid_in, swid_out, periodType), x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val (adcode, swid_in, swid_out, periodType) = x._1
        val list = x._2.toList
        var costSum = 0.0
        var cnt = 0
        list.map(obj => {
          val crosscost = JSONUtils.getJsonValueDouble(obj,"crosscost",0)
          costSum += crosscost
          cnt += 1
        })
        val avgCost = costSum / cnt

        val listSort = list.sortBy(obj => {
          val speed = JSONUtils.getJsonValueDouble(obj,"crosscost",0)
          speed
        })

        var cost50 = 0.0
        var cost60 = 0.0
        var cost70 = 0.0

        val size = listSort.size
        val index50  = (size* 0.5).toInt
        val index60  = (size* 0.6).toInt
        val index70  = (size* 0.7).toInt

        cost50 = JSONUtils.getJsonValueDouble(listSort(index50),"crosscost",0)
        cost60 = JSONUtils.getJsonValueDouble(listSort(index60),"crosscost",0)
        cost70 = JSONUtils.getJsonValueDouble(listSort(index70),"crosscost",0)



        (adcode, swid_in, swid_out, periodType,4,avgCost.formatted("%.2f").toDouble,cnt,cost50,cost60,cost70)
      })
    jsonCostsRdd2
  }

  def calJsonSpeedRdd(jsonSpeedRdd: RDD[JSONObject], inc_day: String) = {

    val jsonSpeedRdd2 = jsonSpeedRdd.filter(x => {
      val speed = JSONUtils.getJsonValueDouble(x, "speed", 0)
      speed >= 0  && speed <= 127
    }).map(x => {

      val linkid = JSONUtils.getJsonValue(x, "linkid", "")
      val dir = JSONUtils.getJsonValue(x, "dir", "")
      val adcode = JSONUtils.getJsonValue(x, "adcode", "")
      val tm = JSONUtils.getJsonValueInt(x, "time", 0)
      val periodType = try {DateTimeUtil.getPeriodTimeIndex(tm, inc_day)}catch {case e:Exception => 0}
      val weekDay = DateTimeUtil.judgeWeekDayTimeStamp(tm.toLong)

      ((adcode, linkid, dir, periodType,weekDay), x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val (adcode, linkid, dir, periodType,weekDay) = x._1
        val list = x._2.toList
        var sumSpeed = 0.0
        var sumCnt = 0
        val listSort = list.sortBy(obj => {
          val speed = JSONUtils.getJsonValueDouble(obj,"speed",0)
          speed
        })
        listSort.map(obj => {
          val speed = JSONUtils.getJsonValueDouble(obj,"speed",0)
          sumSpeed += speed
          sumCnt += 1
        })
        val avgSpeed = sumSpeed / sumCnt

        var speed50 = 0.0
        var speed60 = 0.0
        var speed70 = 0.0

        val size = listSort.size
        val index50  = (size* 0.5).toInt
        val index60  = (size* 0.6).toInt
        val index70  = (size* 0.7).toInt

        speed50 = JSONUtils.getJsonValueDouble(listSort(index50),"speed",0)
        speed60 = JSONUtils.getJsonValueDouble(listSort(index60),"speed",0)
        speed70 = JSONUtils.getJsonValueDouble(listSort(index70),"speed",0)

        (adcode, linkid, dir, periodType,weekDay,avgSpeed,sumCnt,speed50,speed60,speed70)
      })
    jsonSpeedRdd2
  }



  def saveToHive(sourceRdd: RDD[(String, String, String, Int, Int, Double, Int,Double,Double,Double)], inc_day: String,spark:SparkSession,static_filed:String,tableName:String): Unit = {

    import spark.implicits._
    val staticRdd = sourceRdd.map(x => {
      val (adcode, swid_in, swid_out_or_dir, periodType,weekDay,avg,cnt,quantile_50,quantile_60,quantile_70) = x

      experienceSpeed(adcode, swid_in, swid_out_or_dir, periodType.toString,weekDay.toString,avg.toString,cnt.toString,quantile_50.toString,quantile_60.toString,quantile_70.toString)
    }).repartition(50).toDF().withColumn("inc_day", lit(inc_day))
      .write
      .mode(SaveMode.Overwrite)
      .insertInto(tableName)

  }



  /**
    * 解析计算全流程
    * @param spark
    * @param inc_day
    */

  def parseProcess(spark: SparkSession, inc_day: String) = {
    val (jsonCostsRdd, jsonSpeedRdd) = parseFixTable(spark, inc_day)

    val speedRdd = calJsonSpeedRdd(jsonSpeedRdd, inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val costRdd = calJsonCostsRdd(jsonCostsRdd, inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)

    (speedRdd,costRdd)
  }

  def staStat(spark: SparkSession, inc_day: String): Unit = {

    // TODO: 解析轨迹表
    val (speedRdd,costRdd) = parseProcess(spark, inc_day)
    costRdd.take(2).foreach(println(_))
    speedRdd.take(2).foreach(println(_))

    // TODO: 存储为日行hive表
    saveToHive(speedRdd,inc_day,spark,"speed",speedTableName)
    saveToHive(costRdd,inc_day,spark,"speed",crossTableName)

  }



  def start(inc_day: String,  end_day: String): Unit = {


    val spark = SparkUtils.getSparkSession(appName, "yarn")

    spark.sparkContext.setLogLevel("ERROR")

    val dataList = DateTimeUtil.getDateInterval(inc_day, end_day, "yyyyMMdd", "yyyyMMdd")

    for (incDay <- dataList) {
      logger.error(println("当前计算日期为：" + incDay))
      staStat(spark, incDay)
      spark.sqlContext.clearCache()

      val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
      ds.foreach(x => {
        x._2.unpersist()
      })
      logger.error(println(incDay + "：计算日期结束"))

    }
    logger.error("统计完成")

  }

}