package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import app.route.OilStationRecommendDetail.rad
import com.alibaba.fastjson.{JSON, JSONObject}
import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.storage.StorageLevel
import utils.{SparkUtil, SparkUtils}

import java.util
import scala.collection.mutable.{ArrayBuffer, ListBuffer}


/**
 * GIS-RSS-ETA：【燃油管控】 第四步：判断是否按推荐行驶，计算实际加油点油价_V1.0
 * 需求方：zuojiayi（01403789） 油站价格数据初始化
 *
 * @author guofangcai（01420395）
 * 任务ID：
 * 任务名称：判断是否按推荐行驶，计算实际加油点油价
 */
object OilPriceDataInit extends DataSourceCommon {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {
    val spark =  SparkUtil.getSparkSession(appName)
    val inc_day  = args(0)
    start(spark, inc_day)
    spark.stop()
  }

  def start(sparkSession:SparkSession, inc_day: String )= {
    val cols = Seq("Province","City","Preferential_line","brand","Preferential_type","Preferential_range","remark","Province2","City2","Vehicle_jiancheng","Key","Adcode"
      ,"Official_price_0","Preferential_price_0","Official_price_10","Preferential_price_10","Price_time","version")
    val inputPath = "/user/01420395/upload/data/import/2208536/gassprice.csv"
    val price_df = sparkSession.read.option("header", "true")
      .option("delimiter", ",")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*)

    price_df.show(1, false)


    import  sparkSession.implicits._
    //关联实时价格计算
    val sspriceSql  = s"""select province,oilname,officalprice,pricechangetime,updatetime,batchno from  dm_gis.ods_gass_t_officialprice_raw where inc_Day ='${inc_day}'"""

    val sspriceDf =  sparkSession.sql(sspriceSql).withColumn("province2",'province).drop("province")

    val joinDf = price_df.join(sspriceDf,Seq("province2"),"left")


   val resultDf =  joinDf.withColumn("Official_price_0", when('oilName ==="oil_0",'officalprice).otherwise(null))
      .withColumn("Preferential_price_0", when('oilName ==="oil_0",'Official_price_0 - 'Preferential_line).otherwise(null))
      .withColumn("Official_price_10", when('oilName ==="oil_10",'officalprice).otherwise(null))
      .withColumn("Preferential_price_10", when('oilName ==="oil_10",'Official_price_10 - 'Preferential_line).otherwise(null))
      .withColumn("version", date_format('updatetime,"yyyy-MM-dd"))
      .withColumn("Price_time", concat(date_format('updatetime,"yyyy-MM-dd"), lit("_"), date_add(date_format('updatetime,"yyyy-MM-dd"), 30)))
      .withColumn("Cityname", split('Key,"_")(0))
      .withColumn("City_mark", when('cityname.contains("市"),lit("1")).otherwise( "0"))
      .withColumn("Max_date",  date_add(date_format('updatetime,"yyyy-MM-dd"), 30))
      .withColumn("Min_date", date_format('updatetime,"yyyy-MM-dd"))
      .withColumn("inc_day", lit(inc_day))
      .select("province","City","Preferential_line","brand","Preferential_type","Preferential_range","remark","Province2","City2","Vehicle_jiancheng","Key","Adcode"
        ,"Official_price_0","Preferential_price_0","Official_price_10","Preferential_price_10","Price_time","version","Cityname","City_mark","Max_date","Min_date","inc_day")

    writeToHive(sparkSession,resultDf, Seq("inc_day"),"dm_gis.oil_price_data")
  }

}
