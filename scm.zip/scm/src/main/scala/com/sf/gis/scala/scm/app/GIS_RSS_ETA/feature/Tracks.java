package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import utils.HttpRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * 获取司机轨迹坐标点-赵勇的需求，供ETA轨迹使用
 *
 * @author 01408031
 */
public final class Tracks {

	public String getTrackPtStrWithoutTime(String strRequest){
		List<TrackPointWithTm> trackPoints = new ArrayList<TrackPointWithTm>();
		String strResp = EnsurePost(strRequest);
		parseTracks(strResp, trackPoints);
		String ptString = ensemblePtsWithoutTime(trackPoints);
		return ptString;
	}


	public String getTrackPtStr(String strRequest){
		List<TrackPointWithTm> trackPoints = new ArrayList<TrackPointWithTm>();
		String strResp = EnsurePost(strRequest);
		int ret = parseTracks(strResp, trackPoints);
		String ptString = ensemblePts(trackPoints);
		return ptString;
	}
	public String ensemblePts(List<TrackPointWithTm> pts) {
		String ptStr = new String();
		for(int i =0 ; i < pts.size();++i)
		{
			if(i==0) {
				ptStr += pts.get(i).x + "," + pts.get(i).y + "," + pts.get(i).tm;
			}
			else {
				ptStr += "|" + pts.get(i).x + "," + pts.get(i).y + "," + pts.get(i).tm;
			}
		}
		return ptStr;
	}



	//大数据EtaDataProcess 不需要时间戳字段
	public String ensemblePtsWithoutTime(List<TrackPointWithTm> pts) {
		String ptStr = new String();
		for(int i =0 ; i < pts.size();++i)
		{
			if(i==0) {
				ptStr += pts.get(i).x + "," + pts.get(i).y;
			}
			else {
				ptStr += "|" + pts.get(i).x + "," + pts.get(i).y;
			}
		}
		return ptStr;
	}

	/**
	 * 发送post请求到按车牌请求轨迹点的服务
	 * @param strRequest 输入的json文件data
	 * @param
	 * @throws
	 */
	public String EnsurePost(String strRequest) {
		boolean bRet = false;
		int cnt = 0;
		String strResponse = "";
		try {
			do {
				strResponse = HttpRequest.sendPost("http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail", strRequest,"571a61a2b89c4dcb962f9b4977119b37");
				if(!strResponse.isEmpty()) {
					Object parse = JSON.parse(strResponse);
					String s = parse.toString();
					JSONObject resp = JSON.parseObject(s);//strResponse
					if(resp.containsKey("result")) {
						bRet = true;
						break;
					}else
					{
						Thread.sleep(1000);
					}
				}
				++cnt;
			}while(!bRet && cnt < 60);
		}
		catch (InterruptedException e)
		{
			System.out.println("strResponse:" + strResponse); //for test
			e.printStackTrace();
		}
		return strResponse;
	}
	
	/**
	 * 解析post请求返回的轨迹点数据
	 * @param  strResp 输入返回的json响应
	 * @return trackPoints 解析出的轨迹点
	*/
	public int parseTracks(String strResp,List<TrackPointWithTm> trackPoints)
	{
		JSONObject rp = JSON.parseObject(strResp);
		if(!rp.containsKey("result")) {
			return -1;
		}
		JSONObject rest = rp.getJSONObject("result");
		if(!rest.containsKey("data")) {
			return -1;
		}
		JSONObject data = rest.getJSONObject("data");
		if (!data.containsKey("track") || data.getJSONArray("track").isEmpty()) {
			return -1;
		}
		JSONArray track = data.getJSONArray("track");
		for (int i = 0; i < track.size(); ++i) {
			JSONObject obj = track.getJSONObject(i);
			if(obj.containsKey("dx") && obj.containsKey("dy") && obj.containsKey("tm")) {
				TrackPointWithTm tps = new TrackPointWithTm();
				double dx = obj.getDoubleValue("dx");
				double dy = obj.getDoubleValue("dy");
				int tm = obj.getIntValue("tm");
				tps.x = dx;
				tps.y = dy;
				tps.tm = tm;
				trackPoints.add(tps);
			}
		}
		return 0;
	}
}