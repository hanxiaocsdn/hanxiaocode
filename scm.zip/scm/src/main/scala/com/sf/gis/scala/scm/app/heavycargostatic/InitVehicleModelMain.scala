//package com.sf.gis.scala.scm.app.heavycargostatic
//
//import com.sf.gis.scala.scm.utils.{DateUtil, HBaseUtils, SparkBuilder, StringUtils}
//import com.sf.gis.scala.scm.common.DataSourceCommon
//import org.apache.hadoop.conf.Configuration
//import org.apache.hadoop.hbase.HBaseConfiguration
//import org.apache.hadoop.hbase.client.{Delete, Put, Result}
//import org.apache.hadoop.hbase.io.ImmutableBytesWritable
//import org.apache.hadoop.hbase.mapreduce.TableInputFormat
//import org.apache.hadoop.hbase.util.Bytes
//import org.apache.spark.sql.expressions.Window
//import org.apache.spark.sql.types._
//import org.apache.spark.sql.{DataFrame, Row, SparkSession}
//import org.apache.spark.storage.StorageLevel
///**
//  * @description: 全国重货车型信息计算同步到到hbase;  需求ID: 1720287 任务id 698593
//  * @author 01420935 caiguofang
//  * @date 2023/04/10 10:36
//  */
//object InitVehicleModelMain extends DataSourceCommon {
//
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//  //切换集群
//  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
////  val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
//  val zkPort = "2181"
//  val zkParent = "/hbase"
//  var isInit = 0
//
//  def main(args: Array[String]): Unit = {
//    isInit = args(0).toInt
//    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
//    initVehicleModel(spark,isInit)
//    spark.close()
//  }
//
//  /**
//    * 获取现有的车型数据
//    * @param spark
//    * @param tbl_name
//    * @param hbaseConf
//    * @return
//    */
//  def getExitsModelTypeCodeSource(spark: SparkSession, hbaseConf: Configuration):Array[String]={
//
//    //获取不匹配车型数据
//    val hModelTblName = "gis:insurance_vehicle_model_original"
//    hbaseConf.set(TableInputFormat.INPUT_TABLE, hModelTblName)
//    val hModelTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])
//    hModelTblRdd.mapPartitions(rows =>{
//      val hbaseTbl  = HBaseUtils.getHbaseTable(hModelTblName,zkParent,zkQuorum,zkPort)
//      rows.foreach(row =>{
//        val  result = row._2.getRow
//        hbaseTbl.delete(new Delete(result))
//        hbaseTbl.flushCommits()
//      })
//      hbaseTbl.close()
//      rows
//    })
//
//    val modelNotInList =  hModelTblRdd.map(row =>{
//      var  result = row._2
//      val vehicle_typecode  = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_typecode")))
//      vehicle_typecode
//    }).collect()
//
//    modelNotInList
//  }
//
//
//  /**
//    * 获取需要计算的车辆基础信息
//    * @param spark
//    * @param hbaseConf
//    * @param broadcast
//    * @return
//    */
//  def getExitsVehicleBasicSource(spark: SparkSession, hbaseConf: Configuration, modelNotInList:Array[String]):DataFrame={
//
//    val broadcast  = spark.sparkContext.broadcast(modelNotInList)
//    logger.error("广播匹配好的数据 >> " + broadcast.value.foreach(print(_ ,  "====")))
//
//    //获取不匹配车型数据
//    val hBaseTblName = "gis:insurance_vehicle_basics_original"
//    hbaseConf.set(TableInputFormat.INPUT_TABLE, hBaseTblName)
//
//    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])
//
//    val vehicleBaseDf = hbaseTblRdd.filter(row => {
//      //过滤已经匹配好和不匹配的数据
//      val vehicle_typecode = Bytes.toString(row._2.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_typecode")))
//      !broadcast.value.contains(vehicle_typecode) && !StringUtils.isEmpty(vehicle_typecode)
//
//    }).map(row => {
//      val result = row._2
//      val id  = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("id")))
//      val vin = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vin")))
//      val  vehicle_age = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_age")))
//      val original_value_vehicle = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("original_value_vehicle")))
//      val company_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_name")))
//      val vehicle_type = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_type")))
//      val brand_name = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("brand_name")))
//      val  vehicle_weight = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_weight")))
//      val full_weight = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("full_weight")))
//      val ratified_load_capacity = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("ratified_load_capacity")))
//      val track_front = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("track_front")))
//      val  track_rear = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("track_rear")))
//      val tire_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tire_number")))
//      val tire_specification = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("tire_specification")))
//      val  wheel_base = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wheel_base")))
//      val  wheel_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wheel_number")))
//      val long_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("long_profile_size")))
//      val  wide_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wide_profile_size")))
//      val height_profile_size = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("height_profile_size")))
//      val fuel_type = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("fuel_type")))
//      val effluent_standard = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("effluent_standard")))
//      val vehicle_model = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_model")))
//      val wmi = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("wmi")))
//      val vds = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vds")))
//      val vehicle_typecode = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("vehicle_typecode")))
//      val results_number = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("results_number")))
//      val data_sources = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("data_sources")))
//      val create_time = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("create_time")))
//
//
//      val temList  = List(id,vin,vehicle_age,original_value_vehicle,company_name,vehicle_type,brand_name,
//        vehicle_weight,full_weight,ratified_load_capacity,track_front,track_rear,tire_number,tire_specification,
//        wheel_base,wheel_number,long_profile_size,wide_profile_size,height_profile_size,fuel_type,effluent_standard,
//        vehicle_model,wmi,vds,vehicle_typecode,results_number,data_sources,create_time)
//
//
//      Row.fromSeq(temList)
//
//    })
//
//
//    // 转成df
//    val hBaseSchame =StructType(
//      List(
//        StructField("id", StringType, true)
//        ,StructField("vin", StringType, true)
//        ,StructField("vehicle_age", StringType, true)
//        ,StructField("original_value_vehicle", StringType, true)
//        ,StructField("company_name", StringType, true)
//        ,StructField("vehicle_type", StringType, true)
//        ,StructField("brand_name", StringType, true)
//        ,StructField("vehicle_weight", StringType, true)
//        ,StructField("full_weight", StringType, true)
//        ,StructField("ratified_load_capacity", StringType, true)
//        ,StructField("track_front", StringType, true)
//        ,StructField("track_rear", StringType, true)
//        ,StructField("tire_number", StringType, true)
//        ,StructField("tire_specification", StringType, true)
//        ,StructField("wheel_base", StringType, true)
//        ,StructField("wheel_number", StringType, true)
//        ,StructField("long_profile_size", StringType, true)
//        ,StructField("wide_profile_size", StringType, true)
//        ,StructField("height_profile_size", StringType, true)
//        ,StructField("fuel_type", StringType, true)
//        ,StructField("effluent_standard", StringType, true)
//        ,StructField("vehicle_model", StringType, true)
//        ,StructField("wmi", StringType, true)
//        ,StructField("vds", StringType, true)
//        ,StructField("vehicle_typecode", StringType, true)
//        ,StructField("results_number", StringType, true)
//        ,StructField("data_sources", StringType, true)
//        ,StructField("create_time", StringType, true)
//      )
//    )
//    val vehicleDf =  spark.createDataFrame(vehicleBaseDf, hBaseSchame)
//    //车型计算逻辑
//    import org.apache.spark.sql.functions._
//    import spark.implicits._
//    val resultDF = vehicleDf.withColumn("data_sources",lit(1)).select('id.cast("string").as("id"),
//      'vin.cast("string").as("vin"),
//      'vehicle_age.cast("string").as("vehicle_age"),
//      'original_value_vehicle.cast("Float").as("original_value_vehicle"),
//      'company_name.cast("string").as("company_name"),
//      'vehicle_type.cast("string").as("vehicle_type"),
//      'brand_name.cast("string").as("brand_name"),
//      'vehicle_weight.cast("Float").as("vehicle_weight"),
//      'full_weight.cast("Float").as("full_weight"),
//      'ratified_load_capacity.cast("Float").as("ratified_load_capacity"),
//      'track_front.cast("Float").as("track_front"),
//      'track_rear.cast("Float").as("track_rear"),
//      'tire_number.cast("Float").as("tire_number"),
//      'tire_specification.cast("string").as("tire_specification"),
//      'wheel_base.cast("Float").as("wheel_base"),
//      'wheel_number.cast("string").as("wheel_number"),
//      'long_profile_size.cast("Float").as("long_profile_size"),
//      'wide_profile_size.cast("Float").as("wide_profile_size"),
//      'height_profile_size.cast("Float").as("height_profile_size"),
//      'fuel_type.cast("string").as("fuel_type"),
//      'effluent_standard.cast("string").as("effluent_standard"),
//      'vehicle_model.cast("string").as("vehicle_model"),
//
//      'wmi.cast("string").as("wmi"),
//      'vds.cast("string").as("vds"),
//      'vehicle_typecode.cast("string").as("vehicle_typecode"),
//      'results_number.cast("string").as("results_number"),
//      'data_sources.cast("string").as("data_sources"),
//      'create_time.cast("string").as("create_time")
//
//    )
//
//    logger.error("读取 hbase 需要计算车架总条数 "+resultDF.count() + " 车型总数 :" + resultDF.select('vehicle_typecode).distinct().count())
//
//    resultDF
//  }
//
//
//  /**
//    * 获取当个车型数据条数超过 50条的数据
//    * @param spark
//    * @param vehicleDf
//    * @return
//    */
//  def getVehicleCountMoreThen50(spark: SparkSession,vehicleDf: DataFrame):DataFrame={
//
//    import org.apache.spark.sql.expressions.Window
//    import org.apache.spark.sql.functions._
//    import spark.implicits._
//
//    val vehicleDf1 =  vehicleDf.repartition(50)
//      .withColumn("num",lit(1))
//
//    //同一车型代码是否超过50 车型代码--vehicle_typecode
//    val vehicleDf2 = vehicleDf1
//      .withColumn("vehicle_typecode_count", sum('num)over(Window.partitionBy('vehicle_typecode)))
//      .filter('vehicle_typecode_count >= 50)
//
//    logger.error(">>>>超过50条的车辆条数"+vehicleDf2.count()+" 车型数量 " + vehicleDf2.select('vehicle_typecode).distinct().count())
//
//    vehicleDf2
//
//  }
//
//
//  /**
//    * 超过95的数据插入到车型信息中
//    * @param spark
//    * @param dataFrame
//    */
//  def insertVehicleByCountMoreThen95(spark: SparkSession, vehicleModelDf: DataFrame)={
//
//    import org.apache.spark.sql.expressions.Window
//    import org.apache.spark.sql.functions._
//    import spark.implicits._
//
//    //超过占比直接入库
//    val vehicleMoreDf =vehicleModelDf.filter('max_pre >= 0.95)
//      .withColumn("is_type_ok",lit(1))
//      .withColumn("max_id",max("id") over(Window.partitionBy('vehicle_typecode)))
//
//    logger.error(">>>>超过0.95 占比的车辆总数 " + vehicleMoreDf.count() + "车型总数: " + vehicleMoreDf.select('vehicle_typecode).distinct().count())
//
//
//    val vehicleBg95 = vehicleMoreDf.select('max_id.as("id")
//      ,'vehicle_typecode.cast("String").as("vehicle_typecode")
//      ,'is_type_ok.cast("String").as("is_type_ok")
//      ,'vehicle_age.cast("String").as("vehicle_age")
//      ,'original_value_vehicle.cast("String").as("original_value_vehicle")
//      ,'company_name.cast("String").as("company_name")
//      ,'vehicle_type.cast("String").as("vehicle_type")
//      ,'brand_name.cast("String").as("brand_name")
//      ,'vehicle_weight.cast("String").as("vehicle_weight")
//      ,'full_weight.cast("String").as("full_weight")
//      ,'ratified_load_capacity.cast("String").as("ratified_load_capacity")
//      ,'track_front.cast("String").as("track_front")
//      ,'track_rear.cast("String").as("track_rear")
//      ,'tire_number.cast("String").as("tire_number")
//      ,'tire_specification.cast("String").as("tire_specification")
//      ,'wheel_base.cast("String").as("wheel_base")
//      ,'wheel_number.cast("String").as("wheel_number")
//      ,'long_profile_size.cast("String").as("long_profile_size")
//      ,'wide_profile_size.cast("String").as("wide_profile_size")
//      ,'height_profile_size.cast("String").as("height_profile_size")
//      ,'fuel_type.cast("String").as("fuel_type")
//      ,'effluent_standard.cast("String").as("effluent_standard")
//      ,'vehicle_model.cast("String").as("vehicle_model")
//      ,'data_sources.cast("String").as("data_sources")
//      ,'num.cast("int").as("num")
//    )
//
//    //获取众数
//    val resultDF = builderVehicleModel(spark,vehicleBg95,"1")
//
//    resultDF
//  }
//
//
//
//
//  /**
//    * 超过95的数据插入到车型信息中
//    * @param spark
//    * @param dataFrame
//    */
//  def insertVehicleByCountLessThen95(spark: SparkSession, vehicleModelDf: DataFrame):DataFrame={
//
//    import org.apache.spark.sql.functions._
//    import spark.implicits._
//
//    //没有达到指标的进行离散判断
//    val vehicleLessDf= vehicleModelDf.filter('max_pre < 0.95)
//
//    logger.error("小于0.95 车辆总条数 : " + vehicleLessDf.count() +  " 车型总条数:" + vehicleLessDf.select('vehicle_typecode).distinct().count())
//
//    val original_value_vehicle_df  = vehicleModelDf.withColumn("original_value_vehicle",
//      when('original_value_vehicle isNull,"0" ).otherwise('original_value_vehicle))
//      .filter( 'original_value_vehicle =!="0")
//      .groupBy("vehicle_typecode")
//      .agg((stddev('original_value_vehicle)/mean('original_value_vehicle)*1).as("original_value_vehicle_xs"))
//
//
//    val vehicle_weight_df  = vehicleModelDf.withColumn("vehicle_weight",
//      when('vehicle_weight isNull,0 ).otherwise('vehicle_weight))
//      .filter( 'vehicle_weight =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('vehicle_weight)/mean('vehicle_weight)*1).as("vehicle_weight_xs"))
//
//
//    val full_weight_df  = vehicleModelDf.withColumn("full_weight",
//      when('full_weight isNull,0).otherwise('full_weight))
//      .filter( 'full_weight =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('full_weight)/mean('full_weight)*1).as("full_weight_xs"))
//
//
//    val ratified_load_capacity_df  = vehicleModelDf.withColumn("ratified_load_capacity",
//      when('ratified_load_capacity isNull,0 ).otherwise('ratified_load_capacity))
//      .filter( 'ratified_load_capacity =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('ratified_load_capacity)/mean('ratified_load_capacity)*1).as("ratified_load_capacity_xs"))
//
//
//    val track_front_df  = vehicleModelDf.withColumn("track_front",
//      when('track_front isNull,0 ).otherwise('track_front))
//      .filter( 'track_front =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('track_front)/mean('track_front)*0.5).as("track_front_xs"))
//
//    val tire_number_df  = vehicleModelDf.withColumn("tire_number",
//      when('tire_number isNull,0 ).otherwise('tire_number))
//      .filter( 'tire_number =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('tire_number)/mean('tire_number)*0.5).as("tire_number_xs"))
//
//
//    val track_rear_df  = vehicleModelDf.withColumn("track_rear",
//      when('track_rear isNull,0 ).otherwise('track_rear))
//      .filter( 'track_rear =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('track_rear)/mean('track_rear)*0.5).as("track_rear_xs"))
//
//
//
//    val wheel_base_df  = vehicleModelDf.withColumn("wheel_base",
//      when('wheel_base isNull,0 ).otherwise('wheel_base))
//      .filter( 'wheel_base =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('wheel_base)/mean('wheel_base)*0.5).as("wheel_base_xs"))
//
//
//
//    val wheel_number_df  = vehicleModelDf.withColumn("wheel_number",
//      when('wheel_number isNull,0 ).otherwise('wheel_number))
//      .filter( 'wheel_number =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('wheel_number)/mean('wheel_number)*0.5).as("wheel_number_xs"))
//
//
//
//    val long_profile_size_df  = vehicleModelDf.withColumn("long_profile_size",
//      when('long_profile_size isNull,0 ).otherwise('long_profile_size))
//      .filter( 'long_profile_size =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('long_profile_size)/mean('long_profile_size)*1).as("long_profile_size_xs"))
//
//
//    val wide_profile_size_df  = vehicleModelDf.withColumn("wide_profile_size",
//      when('wide_profile_size isNull,0 ).otherwise('wide_profile_size))
//      .filter( 'wide_profile_size =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('wide_profile_size)/mean('wide_profile_size)*1).as("wide_profile_size_xs"))
//
//
//    val height_profile_size_df  = vehicleModelDf.withColumn("height_profile_size",
//      when('height_profile_size isNull,0 ).otherwise('height_profile_size))
//      .filter( 'height_profile_size =!=0 )
//      .groupBy("vehicle_typecode")
//      .agg((stddev('height_profile_size)/mean('height_profile_size)*1).as("height_profile_size_xs")).toDF()
//
//
//    val vehicleDf4  = original_value_vehicle_df
//      .join(vehicle_weight_df,Seq("vehicle_typecode"),"left")
//      .join(full_weight_df,Seq("vehicle_typecode"),"left")
//      .join(ratified_load_capacity_df,Seq("vehicle_typecode"),"left")
//      .join(track_front_df,Seq("vehicle_typecode"),"left")
//      .join(track_rear_df,Seq("vehicle_typecode"),"left")
//      .join(tire_number_df,Seq("vehicle_typecode"),"left")
//      .join(wheel_base_df,Seq("vehicle_typecode"),"left")
//      .join(wheel_number_df,Seq("vehicle_typecode"),"left")
//      .join(long_profile_size_df,Seq("vehicle_typecode"),"left")
//      .join(wide_profile_size_df,Seq("vehicle_typecode"),"left")
//      .join(height_profile_size_df,Seq("vehicle_typecode"),"left")
//
//    val xsDf2 =  vehicleDf4.select('vehicle_typecode,
//      'original_value_vehicle_xs,
//      'vehicle_weight_xs,
//      'full_weight_xs,
//      'ratified_load_capacity_xs,
//      'track_front_xs,
//      'track_rear_xs,
//      'tire_number_xs,
//      'wheel_base_xs,
//      'wheel_number_xs,
//      'long_profile_size_xs,
//      'wide_profile_size_xs,
//      'height_profile_size_xs
//    ).withColumn("xs", 'original_value_vehicle_xs + 'vehicle_weight_xs
//      + 'full_weight_xs + 'ratified_load_capacity_xs + 'track_front_xs + 'track_rear_xs+ 'tire_number_xs+ 'wheel_base_xs+ 'wheel_number_xs
//      + 'long_profile_size_xs
//      + 'wide_profile_size_xs
//      + 'height_profile_size_xs)
//
//
//    val xsDf = xsDf2.distinct()
//
//    val leftRd  = vehicleLessDf.join(xsDf, Seq("vehicle_typecode"), "left")
//
//
//
//    val leftRd2  = leftRd.select('id,'vin,'vehicle_age,'original_value_vehicle,'company_name,'vehicle_type,
//      'brand_name,'vehicle_weight,'full_weight,'ratified_load_capacity,'track_front,'track_rear,'tire_number,
//      'tire_specification,'wheel_base,'wheel_number,'long_profile_size,'wide_profile_size,'height_profile_size,
//      'fuel_type,'effluent_standard,'vehicle_model,'wmi,'vds,'vehicle_typecode,'results_number,'data_sources,'create_time,
//      'num,'vehicle_typecode_count,'count_model,'count_pre,'count_vehicle_type,'count_vehicle_type_pre,
//      'max_id,'count_vehicle_type_order,'count_vehicle_type_order_count,'count_pre_two,'max_pre,'max_vehicle_type_pre,'max_pre_two,
//      'original_value_vehicle_xs,'vehicle_weight_xs,'full_weight_xs,'ratified_load_capacity_xs,'track_front_xs,
//      'track_rear_xs,'tire_number_xs,'wheel_base_xs,'wheel_number_xs,'long_profile_size_xs,'wide_profile_size_xs,'height_profile_size_xs,'xs)
//
//    if(isInit!=1){
//      writeToHiveNoP(spark,leftRd2,"dm_gis.insurance_vehicle_basics_original_20230424")
//    }else{
//      writeToHiveNoP2(spark,leftRd2,"dm_gis.insurance_vehicle_basics_original_20230424")
//    }
//    //
//
//    //最多车辆类型数占比>=95% 整体变异<=0.2 低 提取众数入车型库
//    val vehicleBetweenDf= leftRd.filter(('max_vehicle_type_pre >= 0.8 || 'max_pre_two>=0.90)  && 'xs <=0.5)
//      .withColumn("is_type_ok",lit(1))
//      .select('id.as("id")
//        ,'vehicle_typecode.cast("String").as("vehicle_typecode")
//        ,'is_type_ok.cast("String").as("is_type_ok")
//        ,'vehicle_age.cast("String").as("vehicle_age")
//        ,'original_value_vehicle.cast("String").as("original_value_vehicle")
//        ,'company_name.cast("String").as("company_name")
//        ,'vehicle_type.cast("String").as("vehicle_type")
//        ,'brand_name.cast("String").as("brand_name")
//        ,'vehicle_weight.cast("String").as("vehicle_weight")
//        ,'full_weight.cast("String").as("full_weight")
//        ,'ratified_load_capacity.cast("String").as("ratified_load_capacity")
//        ,'track_front.cast("String").as("track_front")
//        ,'track_rear.cast("String").as("track_rear")
//        ,'tire_number.cast("String").as("tire_number")
//        ,'tire_specification.cast("String").as("tire_specification")
//        ,'wheel_base.cast("String").as("wheel_base")
//        ,'wheel_number.cast("String").as("wheel_number")
//        ,'long_profile_size.cast("String").as("long_profile_size")
//        ,'wide_profile_size.cast("String").as("wide_profile_size")
//        ,'height_profile_size.cast("String").as("height_profile_size")
//        ,'fuel_type.cast("String").as("fuel_type")
//        ,'effluent_standard.cast("String").as("effluent_standard")
//        ,'vehicle_model.cast("String").as("vehicle_model")
//        ,'data_sources.cast("String").as("data_sources")
//        ,'num.cast("int").as("num")
//      )
//
//    logger.error("低系数数据 车辆总条数 : " + vehicleBetweenDf.count() +  " 车型总条数:" + vehicleBetweenDf.select('vehicle_typecode).distinct().count())
//    //获取众数
//    val resultDF = builderVehicleModel(spark,vehicleBetweenDf,"1")
//
//    //最多车辆类型数占比<=80% 整体变异>1 高 标注不可匹配, 并且所有字段信息设置成空
//    val vehicleLess80Df= leftRd.filter('max_vehicle_type_pre <= 0.8 && 'xs >1 )
//      .withColumn("is_type_ok",lit(2))
//      .withColumn("vehicle_age",lit(""))
//      .withColumn("original_value_vehicle",lit(""))
//      .withColumn("company_name",lit(""))
//      .withColumn("vehicle_type",lit(""))
//      .withColumn("brand_name",lit(""))
//      .withColumn("vehicle_weight",lit(""))
//      .withColumn("full_weight",lit(""))
//      .withColumn("ratified_load_capacity",lit(""))
//      .withColumn("track_front",lit(""))
//      .withColumn("track_rear",lit(""))
//      .withColumn("tire_number",lit(""))
//      .withColumn("tire_specification",lit(""))
//      .withColumn("wheel_base",lit(""))
//      .withColumn("wheel_number",lit(""))
//      .withColumn("long_profile_size",lit(""))
//      .withColumn("wide_profile_size",lit(""))
//      .withColumn("height_profile_size",lit(""))
//      .withColumn("fuel_type",lit(""))
//      .withColumn("effluent_standard",lit(""))
//      .withColumn("vehicle_model",lit(""))
//      .withColumn("create_time",lit(""))
//      .withColumn("data_sources",lit(""))
//      .withColumn("max_id",max('id)over(Window.partitionBy('vehicle_typecode)))
//      .select('max_id.as("id")
//        ,'vehicle_typecode
//        ,'is_type_ok
//        ,'vehicle_age
//        ,'original_value_vehicle
//        ,'company_name
//        ,'vehicle_type
//        ,'brand_name
//        ,'vehicle_weight
//        ,'full_weight
//        ,'ratified_load_capacity
//        ,'track_front
//        ,'track_rear
//        ,'tire_number
//        ,'tire_specification
//        ,'wheel_base
//        ,'wheel_number
//        ,'long_profile_size
//        ,'wide_profile_size
//        ,'height_profile_size
//        ,'fuel_type
//        ,'effluent_standard
//        ,'vehicle_model
//        ,'data_sources
//        ,'num )
//
//    logger.error("高系数数据 车辆总条数 : " + vehicleLess80Df.count() +  " 车型总条数:" + vehicleLess80Df.select('vehicle_typecode).distinct().count())
//    val result80DF = builderVehicleModel(spark,vehicleLess80Df,"2")
//
//
//
//
//    resultDF.union(result80DF)
//
//
//
//  }
//  /**
//    * 获取众数
//    * @param sparkSession
//    * @param tbl_name
//    */
//  def builderVehicleModel(spark: SparkSession, vehicleBetweenDf: DataFrame, is_type_ok:String):DataFrame={
//
//    import org.apache.spark.sql.expressions.Window
//    import org.apache.spark.sql.functions._
//    import spark.implicits._
//
//    //以车型维度 获取众数 参考《车辆基础信息库》，如 is_type_ok =1，多辆车均取众数，如 is_type_ok =2 则为空
//    val vehicleBetweenDf1 =  vehicleBetweenDf
//      .withColumn("vehicle_weight_num",sum(when('vehicle_weight isNull,0 ).otherwise('num)) over(Window.partitionBy('vehicle_typecode,'vehicle_weight)))
//      .withColumn("full_weight_num",sum(when('full_weight isNull,0 ).otherwise('num)) over(Window.partitionBy('vehicle_typecode,'full_weight)))
//      .withColumn("ratified_load_capacity_num",sum(when('ratified_load_capacity isNull,0 ).otherwise('num)) over(Window.partitionBy('vehicle_typecode,'ratified_load_capacity)))
//      .withColumn("track_front_num",sum(when('track_front isNull,0 ).otherwise('num)) over(Window.partitionBy('vehicle_typecode,'track_front)))
//      .withColumn("track_rear_num",sum(when('track_rear isNull,0 ).otherwise('num)) over(Window.partitionBy('vehicle_typecode,'track_rear)))
//      .withColumn("tire_number_num",sum(when('tire_number isNull,0 ).otherwise('num)) over(Window.partitionBy('vehicle_typecode,'tire_number)))
//      .withColumn("wheel_base_num",sum(when('wheel_base isNull,0 ).otherwise('num)) over(Window.partitionBy('vehicle_typecode,'wheel_base)))
//      .withColumn("original_value_vehicle_num",sum(when('original_value_vehicle isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'original_value_vehicle)))
//      .withColumn("long_profile_size_num",sum(when('long_profile_size isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'long_profile_size)))
//      .withColumn("wide_profile_size_num",sum(when('wide_profile_size isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'wide_profile_size)))
//      .withColumn("height_profile_size_num",sum(when('height_profile_size isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'height_profile_size)))
//
//
//
//      .withColumn("num_count",sum('num )over(Window.partitionBy('vehicle_typecode)))
//
//      //数据为空不记录统计
//      .withColumn("vehicle_age_num",sum(when('vehicle_age isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'vehicle_age)))
//      .withColumn("company_name_num",sum(when('company_name isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'company_name)))
//      .withColumn("vehicle_type_num",sum(when('vehicle_type isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'vehicle_type)))
//      .withColumn("brand_name_num",sum(when('brand_name isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'brand_name)))
//      .withColumn("tire_specification_num",sum(when('tire_specification isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'tire_specification)))
//      .withColumn("wheel_number_num",sum(when('wheel_number isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'wheel_number)))
//      .withColumn("fuel_type_num",sum(when('fuel_type isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'fuel_type)))
//      .withColumn("effluent_standard_num",sum(when('effluent_standard isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'effluent_standard)))
//      .withColumn("vehicle_model_num",sum(when('vehicle_model isNull,0 ).otherwise('num))over(Window.partitionBy('vehicle_typecode,'vehicle_model)))
//
//
//      .withColumn("create_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
//      .persist()
//
//    //计算出现比例, 获取众数取最大的值
//    val vehicleBetweenDf2 =  vehicleBetweenDf1
//      .withColumn("vehicle_age_num_pre",'vehicle_age_num/'num_count)
//      .withColumn("company_name_num_pre",'company_name_num/'num_count)
//      .withColumn("vehicle_type_num_pre",'vehicle_type_num/'num_count)
//      .withColumn("brand_name_num_pre",'brand_name_num/'num_count)
//      .withColumn("tire_specification_num_pre",'tire_specification_num/'num_count)
//      .withColumn("wheel_number_num_pre",'wheel_number_num/'num_count)
//      .withColumn("fuel_type_num_pre",'fuel_type_num/'num_count)
//      .withColumn("effluent_standard_num_pre",'effluent_standard_num/'num_count)
//      .withColumn("vehicle_model_num_pre",'vehicle_model_num/'num_count)
//
//
//      .withColumn("vehicle_weight_num_pre",'vehicle_weight_num/'num_count)
//      .withColumn("full_weight_num_pre",'full_weight_num/'num_count)
//      .withColumn("ratified_load_capacity_num_pre",'ratified_load_capacity_num/'num_count)
//      .withColumn("track_front_num_pre",'track_front_num/'num_count)
//      .withColumn("track_rear_num_pre",'track_rear_num/'num_count)
//      .withColumn("tire_number_num_pre",'tire_number_num/'num_count)
//      .withColumn("wheel_base_num_pre",'wheel_base_num/'num_count)
//      .withColumn("original_value_vehicle_num_pre",'original_value_vehicle_num/'num_count)
//      .withColumn("long_profile_size_num_pre",'long_profile_size_num/'num_count)
//      .withColumn("wide_profile_size_num_pre",'wide_profile_size_num/'num_count)
//      .withColumn("height_profile_size_num_pre",'height_profile_size_num/'num_count)
//
//      .persist()
//
//
//    // resultDF 提取众数
//    import spark.implicits._
//
//    val vehicleTopRdd  =  vehicleBetweenDf2.rdd.map(row => (row.getAs[String]("vehicle_typecode"), row ))
//      .groupByKey().map(x => {
//      val vehicle_typecode = x._1
//
//      var vehicle_age:String =null
//      var company_name:String =null
//      var brand_name:String =null
//      var tire_specification:String =null
//      var wheel_number:String =null
//      var fuel_type:String =null
//      var effluent_standard:String =null
//      var vehicle_type:String =null
//      var vehicle_model:String =null
//
//      var vehicle_weight:String =null
//      var full_weight:String =null
//      var ratified_load_capacity:String =null
//      var track_front:String =null
//      var track_rear:String =null
//      var tire_number:String =null
//      var wheel_base:String =null
//      var original_value_vehicle:String =null
//      var long_profile_size:String =null
//      var wide_profile_size:String =null
//      var height_profile_size:String =null
//
//
//
//      var vehicle_age_num_pre=0.0
//      var company_name_num_pre =0.0
//      var brand_name_num_pre =0.0
//      var tire_specification_num_pre =0.0
//      var wheel_number_num_pre =0.0
//      var fuel_type_num_pre =0.0
//      var effluent_standard_num_pre =0.0
//      var vehicle_type_num_pre =0.0
//      var vehicle_model_num_pre =0.0
//
//
//      var vehicle_weight_num_pre =0.0
//      var full_weight_num_pre =0.0
//      var ratified_load_capacity_num_pre =0.0
//      var track_front_num_pre =0.0
//      var track_rear_num_pre =0.0
//      var tire_number_num_pre =0.0
//      var wheel_base_num_pre =0.0
//      var original_value_vehicle_num_pre =0.0
//      var long_profile_size_num_pre =0.0
//      var wide_profile_size_num_pre =0.0
//      var height_profile_size_num_pre =0.0
//
//
//      val iterator  =  x._2.iterator
//      while(iterator.hasNext){
//        val row = iterator.next()
//
//        val vehicle_age_num_pre_y =  row.getAs[Double]("vehicle_age_num_pre")
//        if(vehicle_age_num_pre < vehicle_age_num_pre_y){
//          vehicle_age_num_pre = vehicle_age_num_pre_y
//          vehicle_age = row.getAs[String]("vehicle_age")
//        }
//
//        val company_name_num_pre_y =  row.getAs[Double]("company_name_num_pre")
//        if(company_name_num_pre < company_name_num_pre_y){
//          company_name_num_pre = company_name_num_pre_y
//          company_name = row.getAs[String]("company_name")
//        }
//
//        val brand_name_num_pre_y =  row.getAs[Double]("brand_name_num_pre")
//        if(brand_name_num_pre < brand_name_num_pre_y){
//          brand_name_num_pre = brand_name_num_pre_y
//          brand_name = row.getAs[String]("brand_name")
//        }
//
//        val tire_specification_num_pre_y =  row.getAs[Double]("tire_specification_num_pre")
//        if(tire_specification_num_pre < tire_specification_num_pre_y){
//          tire_specification_num_pre = tire_specification_num_pre_y
//          tire_specification = row.getAs[String]("tire_specification")
//        }
//
//        val wheel_number_num_pre_y =  row.getAs[Double]("wheel_number_num_pre")
//        if(wheel_number_num_pre < wheel_number_num_pre_y){
//          wheel_number_num_pre = wheel_number_num_pre_y
//          wheel_number = row.getAs[String]("wheel_number")
//        }
//
//        val fuel_type_num_pre_y =  row.getAs[Double]("fuel_type_num_pre")
//        if(fuel_type_num_pre < fuel_type_num_pre_y){
//          fuel_type_num_pre = fuel_type_num_pre_y
//          fuel_type = row.getAs[String]("fuel_type")
//        }
//
//
//        val effluent_standard_num_pre_y =  row.getAs[Double]("effluent_standard_num_pre")
//        if(effluent_standard_num_pre < effluent_standard_num_pre_y){
//          effluent_standard_num_pre = effluent_standard_num_pre_y
//          effluent_standard = row.getAs[String]("effluent_standard")
//        }
//
//
//        val vehicle_type_num_pre_y =  row.getAs[Double]("vehicle_type_num_pre")
//        if(vehicle_type_num_pre < vehicle_type_num_pre_y){
//          vehicle_type_num_pre = vehicle_type_num_pre_y
//          vehicle_type = row.getAs[String]("vehicle_type")
//        }
//
//        val vehicle_model_num_pre_y =  row.getAs[Double]("vehicle_model_num_pre")
//        if(vehicle_model_num_pre < vehicle_model_num_pre_y){
//          vehicle_model_num_pre = vehicle_model_num_pre_y
//          vehicle_model = row.getAs[String]("vehicle_model")
//        }
//
//
//        val vehicle_weight_num_pre_y =  row.getAs[Double]("vehicle_weight_num_pre")
//        if(vehicle_weight_num_pre < vehicle_weight_num_pre_y){
//          vehicle_weight_num_pre = vehicle_weight_num_pre_y
//          vehicle_weight = row.getAs[String]("vehicle_weight")
//        }
//
//        val full_weight_num_pre_y =  row.getAs[Double]("full_weight_num_pre")
//        if(full_weight_num_pre < full_weight_num_pre_y){
//          full_weight_num_pre = full_weight_num_pre_y
//          full_weight = row.getAs[String]("full_weight")
//        }
//
//
//        val ratified_load_capacity_num_pre_y =  row.getAs[Double]("ratified_load_capacity_num_pre")
//        if(ratified_load_capacity_num_pre < ratified_load_capacity_num_pre_y){
//          ratified_load_capacity_num_pre = ratified_load_capacity_num_pre_y
//          ratified_load_capacity = row.getAs[String]("ratified_load_capacity")
//        }
//
//        val track_front_num_pre_y =  row.getAs[Double]("track_front_num_pre")
//        if(track_front_num_pre < track_front_num_pre_y){
//          track_front_num_pre = track_front_num_pre_y
//          track_front = row.getAs[String]("track_front")
//        }
//        val track_rear_num_pre_y =  row.getAs[Double]("track_rear_num_pre")
//        if(track_rear_num_pre < track_rear_num_pre_y){
//          track_rear_num_pre = track_rear_num_pre_y
//          track_rear = row.getAs[String]("track_rear")
//        }
//
//        val tire_number_num_pre_y =  row.getAs[Double]("tire_number_num_pre")
//        if(tire_number_num_pre < tire_number_num_pre_y){
//          tire_number_num_pre = tire_number_num_pre_y
//          tire_number = row.getAs[String]("tire_number")
//        }
//
//        val wheel_base_num_pre_y =  row.getAs[Double]("wheel_base_num_pre")
//        if(wheel_base_num_pre < wheel_base_num_pre_y){
//          wheel_base_num_pre = wheel_base_num_pre_y
//          wheel_base = row.getAs[String]("wheel_base")
//        }
//
//        val original_value_vehicle_num_pre_y =  row.getAs[Double]("original_value_vehicle_num_pre")
//        if(original_value_vehicle_num_pre < original_value_vehicle_num_pre_y){
//          original_value_vehicle_num_pre = original_value_vehicle_num_pre_y
//          original_value_vehicle = row.getAs[String]("original_value_vehicle")
//        }
//
//        val long_profile_size_num_pre_y =  row.getAs[Double]("long_profile_size_num_pre")
//        if(long_profile_size_num_pre < long_profile_size_num_pre_y){
//          long_profile_size_num_pre = long_profile_size_num_pre_y
//          long_profile_size = row.getAs[String]("long_profile_size")
//        }
//
//        val wide_profile_size_num_pre_y =  row.getAs[Double]("wide_profile_size_num_pre")
//        if(wide_profile_size_num_pre < wide_profile_size_num_pre_y){
//          wide_profile_size_num_pre = wide_profile_size_num_pre_y
//          wide_profile_size = row.getAs[String]("wide_profile_size")
//        }
//
//        val height_profile_size_num_pre_y =  row.getAs[Double]("height_profile_size_num_pre")
//        if(height_profile_size_num_pre < height_profile_size_num_pre_y){
//          height_profile_size_num_pre = height_profile_size_num_pre_y
//          height_profile_size = row.getAs[String]("height_profile_size")
//        }
//      }
//      (vehicle_typecode,vehicle_age,company_name,brand_name,tire_specification,wheel_number,fuel_type,
//        effluent_standard,vehicle_type,vehicle_model,vehicle_weight,full_weight,ratified_load_capacity,track_front,track_rear,
//        tire_number,wheel_base,original_value_vehicle,long_profile_size,
//        wide_profile_size,height_profile_size)
//    }).toDF("vehicle_typecode","vehicle_age","company_name","brand_name","tire_specification","wheel_number","fuel_type",
//      "effluent_standard","vehicle_type","vehicle_model","vehicle_weight","full_weight","ratified_load_capacity","track_front","track_rear",
//      "tire_number","wheel_base","original_value_vehicle","long_profile_size",
//      "wide_profile_size","height_profile_size")
//
//
//
//    vehicleTopRdd.select('vehicle_typecode,'full_weight).show(100, false)
//
//    val vehicleRdd =  vehicleTopRdd.distinct().withColumn("id",lit(""))
//      .withColumn("is_type_ok",lit(is_type_ok))
//      .withColumn("data_sources",lit("1"))
//      .select( 'id, 'vehicle_typecode, 'is_type_ok,'vehicle_age,'original_value_vehicle,'company_name,'vehicle_type,
//        'brand_name,'vehicle_weight,'full_weight,'ratified_load_capacity,'track_front,'track_rear,'tire_number,
//        'tire_specification,'wheel_base,'wheel_number,'long_profile_size,'wide_profile_size,'height_profile_size
//        ,'fuel_type
//        ,'effluent_standard
//        ,'vehicle_model,'data_sources )
//
//
//    val resulteDf = vehicleRdd
//      .withColumn("create_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
//      .select('id.cast("String").as("id"),
//        'vehicle_typecode.cast("String").as("vehicle_typecode"),
//        'is_type_ok.cast("String").as("is_type_ok"),
//        'vehicle_age.cast("String").as("vehicle_age"),
//        'original_value_vehicle.cast("String").as("original_value_vehicle"),
//        'company_name.cast("String").as("company_name"),
//        'vehicle_type.cast("String").as("vehicle_type"),
//        'brand_name.cast("String").as("brand_name"),
//        'vehicle_weight.cast("String").as("vehicle_weight"),
//        'full_weight.cast("String").as("full_weight"),
//        'ratified_load_capacity.cast("String").as("ratified_load_capacity"),
//        'track_front.cast("String").as("track_front"),
//        'track_rear.cast("String").as("track_rear"),
//        'tire_number.cast("String").as("tire_number"),
//        'tire_specification.cast("String").as("tire_specification"),
//        'wheel_base.cast("String").as("wheel_base"),
//        'wheel_number.cast("String").as("wheel_number"),
//        'long_profile_size.cast("String").as("long_profile_size"),
//        'wide_profile_size.cast("String").as("wide_profile_size"),
//        'height_profile_size.cast("String").as("height_profile_size"),
//        'fuel_type.cast("String").as("fuel_type"),
//        'effluent_standard.cast("String").as("effluent_standard"),
//        'vehicle_model.cast("String").as("vehicle_model"),
//        'create_time.cast("String").as("create_time"),
//        'data_sources.cast("String").as("data_sources")
//      )
//
//
//    logger.error("众数后的车型数 : " + resulteDf.count() + " ===="  +  resulteDf.select('vehicle_typecode).distinct().count())
//    resulteDf
//
//  }
//
//
//  /**
//    * spark 读取车辆基础信息
//    * @param sparkSession
//    * @param tbl_name
//    */
//  def insertVehicleModel(spark: SparkSession, dataFrame: DataFrame)={
//
//    //写入hbase
//    dataFrame.foreachPartition( rows => {
//      val hbaseTblName = "gis:insurance_vehicle_model_original"
//      val hbaseTbl  = HBaseUtils.getHbaseTable(hbaseTblName,zkParent,zkQuorum,zkPort)
//      rows.foreach(row => {
//        val id  =  row.getAs[String]("id")
//        val vehicle_typecode = row.getAs[String]("vehicle_typecode")
//        val is_type_ok = row.getAs[String]("is_type_ok")
//        val vehicle_age = row.getAs[String]("vehicle_age")
//        val original_value_vehicle = row.getAs[String]("original_value_vehicle")
//        val company_name = row.getAs[String]("company_name")
//        val vehicle_type = row.getAs[String]("vehicle_type")
//        val brand_name = row.getAs[String]("brand_name")
//        val vehicle_weight = row.getAs[String]("vehicle_weight")
//
//        val full_weight = row.getAs[String]("full_weight")
//
//        val ratified_load_capacity = row.getAs[String]("ratified_load_capacity")
//        val track_front = row.getAs[String]("track_front")
//        val track_rear = row.getAs[String]("track_rear")
//        val tire_number = row.getAs[String]("tire_number")
//        val tire_specification = row.getAs[String]("tire_specification")
//
//        val wheel_base = row.getAs[String]("wheel_base")
//        val wheel_number = row.getAs[String]("wheel_number")
//        val long_profile_size = row.getAs[String]("long_profile_size")
//        val wide_profile_size = row.getAs[String]("wide_profile_size")
//        val height_profile_size = row.getAs[String]("height_profile_size")
//
//
//        val fuel_type = row.getAs[String]("fuel_type")
//        val effluent_standard = row.getAs[String]("effluent_standard")
//        val vehicle_model = row.getAs[String]("vehicle_model")
//        val data_sources = "1"
//        val create_time = DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")
//
//        val key = HBaseUtils.getKeyByStr(vehicle_typecode,20)
//
//        val put = new Put(Bytes.toBytes(key))
//
//        if(id != null && !"".equalsIgnoreCase(id)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("id"),Bytes.toBytes(id))
//        }
//
//        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_typecode"),Bytes.toBytes(vehicle_typecode))
//
//
//        if(is_type_ok != null && !"".equalsIgnoreCase(is_type_ok)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("is_type_ok"),Bytes.toBytes(is_type_ok))
//        }
//
//        if(vehicle_age != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_age"),Bytes.toBytes(vehicle_age))
//        }
//
//
//        if(original_value_vehicle != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("original_value_vehicle"),Bytes.toBytes(original_value_vehicle))
//        }
//
//        if(company_name != null && !"".equalsIgnoreCase(company_name)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("company_name"),Bytes.toBytes(company_name))
//        }
//
//        if(vehicle_type != null && !"".equalsIgnoreCase(vehicle_type)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_type"),Bytes.toBytes(vehicle_type))
//        }
//
//        if(brand_name != null && !"".equalsIgnoreCase(brand_name)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("brand_name"),Bytes.toBytes(brand_name))
//        }
//
//        if(vehicle_weight != null ){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_weight"),Bytes.toBytes(vehicle_weight))
//        }
//
//        if(ratified_load_capacity != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("ratified_load_capacity"),Bytes.toBytes(ratified_load_capacity))
//        }
//
//
//        if(track_front != null ){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("track_front"),Bytes.toBytes(track_front))
//        }
//
//
//        if(track_rear != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("track_rear"),Bytes.toBytes(track_rear))
//        }
//
//
//        if(tire_number != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("tire_number"),Bytes.toBytes(tire_number))
//        }
//
//
//        if(tire_specification != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("tire_specification"),Bytes.toBytes(tire_specification))
//        }
//
//        if(wheel_base != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wheel_base"),Bytes.toBytes(wheel_base))
//        }
//
//        if(wheel_number != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wheel_number"),Bytes.toBytes(wheel_number))
//        }
//
//        if(long_profile_size != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("long_profile_size"),Bytes.toBytes(long_profile_size))
//        }
//
//        if(full_weight != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("full_weight"),Bytes.toBytes(full_weight))
//        }
//
//        if(wide_profile_size != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wide_profile_size"),Bytes.toBytes(wide_profile_size))
//        }
//
//        if(height_profile_size != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("height_profile_size"),Bytes.toBytes(height_profile_size))
//        }
//
//        if(fuel_type != null && !"".equalsIgnoreCase(fuel_type)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("fuel_type"),Bytes.toBytes(fuel_type))
//        }
//
//
//        if(effluent_standard != null && !"".equalsIgnoreCase(effluent_standard)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("effluent_standard"),Bytes.toBytes(effluent_standard))
//        }
//
//        if(vehicle_model != null && !"".equalsIgnoreCase(vehicle_model)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vehicle_model"),Bytes.toBytes(vehicle_model))
//        }
//
//
//        if(data_sources != null && !"".equalsIgnoreCase(data_sources)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("data_sources"),Bytes.toBytes(data_sources))
//        }else{
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("data_sources"),Bytes.toBytes("1"))
//        }
//
//        if(create_time != null && !"".equalsIgnoreCase(create_time)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("create_time"),Bytes.toBytes(create_time))
//        }else{
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("create_time"),Bytes.toBytes(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
//        }
//        try{
//          hbaseTbl.put(put)
//        }catch {
//          case e:Exception=> logger.error(key+","+row.toString())
//        }
//        hbaseTbl.flushCommits()
//
//      })
//      hbaseTbl.close()
//      logger.error("写入hbase 成功")
//    })
//  }
//
//
//  /**
//    * spark 初始化车型基础信息
//    * @param sparkSession
//    * @param tbl_name
//    */
//  def initVehicleModel(spark: SparkSession, isInit:Int)={
//
//
//    val hbaseConf  = HBaseConfiguration.create()
//    hbaseConf.set("zookeeper.znode.parent", zkParent)
//    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
//    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
//    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")
//
//
//    //获取已经存在的车型数据
//    var modelNotInList = new Array[String](0)
//    if(isInit!=1){
//      modelNotInList = getExitsModelTypeCodeSource(spark,hbaseConf)
//    }
//    //获取车辆信息
//    val vehicleDf = getExitsVehicleBasicSource(spark,hbaseConf, modelNotInList)
//
//    import org.apache.spark.sql.expressions.Window
//    import org.apache.spark.sql.functions._
//    import spark.implicits._
//
//    val VehicleCountMoreThen50DF = getVehicleCountMoreThen50(spark, vehicleDf)
//
//    //计算车型占比  count_pre和最大占比 增加字段 num, vehicle_typecode_count, count_model, count_pre, max_pre
//    val vehicleDf5 = VehicleCountMoreThen50DF
//      .withColumn("count_model",sum('num)over(Window.partitionBy('vehicle_typecode, 'vehicle_model)) )
//      .withColumn("count_pre",'count_model / 'vehicle_typecode_count )
//
//      .withColumn("count_vehicle_type",sum('num)over(Window.partitionBy('vehicle_typecode, 'vehicle_type)) )
//      .withColumn("count_vehicle_type_pre",'count_vehicle_type / 'vehicle_typecode_count)
//      .withColumn("max_id",max('id)over(Window.partitionBy('vehicle_typecode)))
//
//
//    //count_model 进行排序, 获取前面第二名累加, 降序排序
//    val vehicleDf6 = vehicleDf5
//      .withColumn("count_vehicle_type_order",dense_rank()over(Window.partitionBy('vehicle_typecode).orderBy('count_vehicle_type.cast("int").desc)) )
//
//    val vehicleDf3 = vehicleDf6
//      .withColumn("count_vehicle_type_order_count",
//        sum(when('count_vehicle_type_order<=2,'num).otherwise(0))over(Window.partitionBy('vehicle_typecode)))
//      .withColumn("count_pre_two",'count_vehicle_type_order_count / 'vehicle_typecode_count )
//
//
//
//    val vehicleModelDf = vehicleDf3
//      .withColumn("max_pre",max('count_pre)over(Window.partitionBy('vehicle_typecode)))
//      .withColumn("max_vehicle_type_pre",max('count_vehicle_type_pre)over(Window.partitionBy('vehicle_typecode)))
//      .withColumn("max_pre_two",max('count_pre_two)over(Window.partitionBy('vehicle_typecode)))
//      .withColumn("id",'max_id)
//
//    vehicleModelDf.persist(StorageLevel.MEMORY_AND_DISK)
//
//
//
//    //占比超过95数据处理, 直接更新到车型表中
//    val resultMore95DF = insertVehicleByCountMoreThen95(spark,vehicleModelDf)
//
//    //    //占少95数据处理, 离散处理
//    val resultLess95DF = insertVehicleByCountLessThen95(spark,vehicleModelDf)
//
//    val resultDF = resultMore95DF.union(resultLess95DF)
//    //
//    //写入到hbase中
//    insertVehicleModel(spark,resultDF)
//
//    logger.error("车型插入到hbase完成" + resultDF.count() + "车型数据 : " + resultDF.select('vehicle_typecode).distinct().count())
//
//  }
//
//}
