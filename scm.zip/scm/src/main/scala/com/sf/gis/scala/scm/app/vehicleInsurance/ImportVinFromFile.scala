package com.sf.gis.scala.scm.app.vehicleInsurance

import common.DataSourceCommon
import org.apache.spark.sql.functions.col
import utils.SparkBuilder

object ImportVinFromFile extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    val cols = Seq("vin")

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val inputPath = "/user/01420395/upload/车架号.csv"
    val vehicle_df = spark.read.option("header", "false")
      .option("delimiter", "\\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*)

    writeToHiveNoP(spark, vehicle_df, "dm_gis.insurance_vehicle_vin")
  }



}
