//package com.sf.gis.scala.scm.app.vehicleInsurance.ls20230415
//
//import com.alibaba.fastjson.JSONObject
//import com.sf.gis.scala.scm.utils.{HBaseUtils, JSONUtils, SparkBuilder}
//import com.sf.gis.scala.scm.common.DataSourceCommon
//import org.apache.hadoop.hbase.client.Put
//import org.apache.hadoop.hbase.util.Bytes
//import org.apache.spark.rdd.RDD
//
///*
//企业评分数据 导出hbase 任务id 710431
// @author 01401062
// @DESCRIPTION ${DESCRIPTION}
// @create 2022/12/1
//*/
//
//object ExportFixCalYearToHbase extends  DataSourceCommon{
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//
//  //获取原始数据
//  val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
//  val zkPort = "2181"
//  val zkParent = "/hbase"
//
//
//  /**
//    * 获取原始hive数据
//    * @param spark
//    * @param inc_day
//    * @return
//    */
//
//  def getSourceRdd() ={
//
//    val cols = Seq("num","lpn",
//      "vehicle_color",
//      "total_dist_yt",
//      "total_links_dist_yt",
//      "night_dirve_dist_yt",
//      "before_dawn_drive_dist_yt",
//      "early_morning_drive_dist_yt",
//      "afternoon_drive_dist_yt",
//      "dusk_drive_dist_yt",
//      "high_speed_dist_yt",
//      "state_road_dist_yt",
//      "provincial_dist_yt",
//      "county_dist_yt",
//      "township_dist_yt",
//      "dangerous_road_dist_yt",
//      "high_accident_road_dist_yt",
//      "school_road_dist_yt",
//      "sharp_turn_road_dist_yt",
//      "village_road_dist_yt",
//      "night_high_speed_dist_yt",
//      "night_state_road_dist_yt",
//      "night_provincial_dist_yt",
//      "night_county_dist_yt",
//      "night_township_dist_yt",
//      "before_dawn_high_speed_dist_yt",
//      "before_dawn_state_road_dist_yt",
//      "before_dawn_provincial_dist_yt",
//      "before_dawn_county_dist_yt",
//      "before_dawn_township_dist_yt",
//      "early_morning_high_speed_dist_yt",
//      "early_morning_state_road_dist_yt",
//      "early_morning_provincial_dist_yt",
//      "early_morning_county_dist_yt",
//      "early_morning_township_dist_yt",
//      "afternoon_high_speed_dist_yt",
//      "afternoon_state_road_dist_yt",
//      "afternoon_provincial_dist_yt",
//      "afternoon_county_dist_yt",
//      "afternoon_township_dist_yt",
//      "dusk_high_speed_dist_yt",
//      "dusk_state_road_dist_yt",
//      "dusk_provincial_dist_yt",
//      "dusk_county_dist_yt",
//      "dusk_township_dist_yt",
//      "night_dirve_dist_yp",
//      "before_dawn_drive_dist_yp",
//      "early_morning_drive_dist_yp",
//      "afternoon_drive_dist_yp",
//      "dusk_drive_dist_yp",
//      "high_speed_dist_yp",
//      "state_road_dist_yp",
//      "provincial_dist_yp",
//      "county_dist_yp",
//      "township_dist_yp",
//      "dangerous_road_dist_yp",
//      "high_accident_road_dist_yp",
//      "school_road_dist_yp",
//      "sharp_turn_road_dist_yp",
//      "village_road_dist_yp",
//      "total_dist_ym",
//      "night_dirve_dist_ym",
//      "before_dawn_drive_dist_ym",
//      "early_morning_drive_dist_ym",
//      "afternoon_drive_dist_ym",
//      "dusk_drive_dist_ym",
//      "high_speed_dist_ym",
//      "state_road_dist_ym",
//      "provincial_dist_ym",
//      "county_dist_ym",
//      "township_dist_ym",
//      "dangerous_road_dist_ym",
//      "high_accident_road_dist_ym",
//      "school_road_dist_ym",
//      "sharp_turn_road_dist_ym",
//      "village_road_dist_ym",
//      "total_duration_yt",
//      "total_links_duration_yt",
//      "night_dirve_duration_yt",
//      "before_dawn_drive_duration_yt",
//      "early_morning_drive_duration_yt",
//      "afternoon_drive_duration_yt",
//      "dusk_drive_duration_yt",
//      "high_speed_duration_yt",
//      "state_road_duration_yt",
//      "provincial_duration_yt",
//      "county_duration_yt",
//      "township_duration_yt",
//      "dangerous_road_duration_yt",
//      "high_accident_road_duration_yt",
//      "school_road_duration_yt",
//      "sharp_turn_road_duration_yt",
//      "township_road_duration_yt",
//      "over_speed_duration_yt",
//      "over_speed_ser_duration_yt",
//      "over_drive_duration_yt",
//      "night_high_speed_duration_yt",
//      "night_state_road_duration_yt",
//      "night_provincial_duration_yt",
//      "night_county_duration_yt",
//      "night_township_duration_yt",
//      "before_dawn_high_speed_duration_yt",
//      "before_dawn_state_road_duration_yt",
//      "before_dawn_provincial_duration_yt",
//      "before_dawn_county_duration_yt",
//      "before_dawn_township_duration_yt",
//      "early_morning_high_speed_duration_yt",
//      "early_morning_state_road_duration_yt",
//      "early_morning_provincial_duration_yt",
//      "early_morning_county_duration_yt",
//      "early_morning_township_duration_yt",
//      "afternoon_high_speed_duration_yt",
//      "afternoon_state_road_duration_yt",
//      "afternoon_provincial_duration_yt",
//      "afternoon_county_duration_yt",
//      "afternoon_township_duration_yt",
//      "dusk_high_speed_duration_yt",
//      "dusk_state_road_duration_yt",
//      "dusk_provincial_duration_yt",
//      "dusk_county_duration_yt",
//      "dusk_township_duration_yt",
//      "high_speed_lowspeed_duration_yt",
//      "night_dirve_duration_yp",
//      "before_dawn_drive_duration_yp",
//      "early_morning_drive_duration_yp",
//      "afternoon_drive_duration_yp",
//      "dusk_drive_duration_yp",
//      "dangerous_road_duration_yp",
//      "high_accident_road_duration_yp",
//      "school_road_duration_yp",
//      "sharp_turn_road_duration_yp",
//      "township_road_duration_yp",
//      "over_speed_duration_yp",
//      "over_speed_ser_duration_yp",
//      "over_drive_duration_yp",
//      "total_duration_ym",
//      "night_dirve_duration_ym",
//      "before_dawn_drive_duration_ym",
//      "early_morning_drive_duration_ym",
//      "afternoon_drive_duration_ym",
//      "dusk_drive_duration_ym",
//      "dangerous_road_duration_ym",
//      "high_accident_road_duration_ym",
//      "school_road_duration_ym",
//      "sharp_turn_road_duration_ym",
//      "township_road_duration_ym",
//      "over_speed_duration_ym",
//      "over_speed_ser_duration_ym",
//      "over_drive_duration_ym",
//      "track_eff_days",
//      "track_eff_months",
//      "first_track_eff_day",
//      "lnk_cnt_yt",
//      "dangerous_road_cnt_yt",
//      "high_accident_road_cnt_yt",
//      "school_road_cnt_yt",
//      "sharp_turn_road_cnt_yt",
//      "township_road_road_cnt_yt",
//      "night_lnk_cnt_yt",
//      "night_dangerous_road_cnt_yt",
//      "night_high_accident_road_cnt_yt",
//      "night_school_road_cnt_yt",
//      "night_sharp_turn_road_cnt_yt",
//      "night_township_road_road_cnt_yt",
//      "before_dawn_lnk_cnt_yt",
//      "before_dawn_dangerous_road_cnt_yt",
//      "before_dawn_high_accident_road_cnt_yt",
//      "before_dawn_school_road_cnt_yt",
//      "before_dawn_sharp_turn_road_cnt_yt",
//      "before_dawn_township_road_road_cnt_yt",
//      "early_morning_lnk_cnt_yt",
//      "early_morning_dangerous_road_cnt_yt",
//      "early_morning_high_accident_road_cnt_yt",
//      "early_morning_school_road_cnt_yt",
//      "early_morning_sharp_turn_road_cnt_yt",
//      "early_morning_township_road_road_cnt_yt",
//      "afternoon_lnk_cnt_yt",
//      "afternoon_dangerous_road_cnt_yt",
//      "afternoon_high_accident_road_cnt_yt",
//      "afternoon_school_road_cnt_yt",
//      "afternoon_sharp_turn_road_cnt_yt",
//      "afternoon_township_road_road_cnt_yt",
//      "dusk_lnk_cnt_yt",
//      "dusk_dangerous_road_cnt_yt",
//      "dusk_high_accident_road_cnt_yt",
//      "dusk_school_road_cnt_yt",
//      "dusk_sharp_turn_road_cnt_yt",
//      "dusk_township_road_road_cnt_yt",
//      "operation_cnt_yt",
//      "operation_same_city_cnt_yt",
//      "operation_same_prov_cnt_yt",
//      "lnk_cnt_ym",
//      "dangerous_road_cnt_ym",
//      "high_accident_road_cnt_ym",
//      "school_road_cnt_ym",
//      "sharp_turn_road_cnt_ym",
//      "township_road_road_cnt_ym",
//      "operation_cnt_ym",
//      "operation_same_city_cnt_ym",
//      "adcode_dura_prov_y1",
//      "adcode_dura_prov_cnt_y1",
//      "adcode_dura_prov_y2",
//      "adcode_dura_prov_cnt_y2",
//      "adcode_dura_prov_y3",
//      "adcode_dura_prov_cnt_y3",
//      "adcode_dist_prov_y1",
//      "adcode_dist_prov_dist_y1",
//      "adcode_dist_prov_y2",
//      "adcode_dist_prov_dist_y2",
//      "adcode_dist_prov_y3",
//      "adcode_dist_prov_dist_y3",
//      "adcode_prov_y1",
//      "adcode_prov_cnt_y1",
//      "adcode_prov_y2",
//      "adcode_prov_cnt_y2",
//      "adcode_prov_y3",
//      "adcode_prov_cnt_y3",
//      "adcode_dura_city_y1",
//      "adcode_dura_city_duration_y1",
//      "adcode_dura_city_y2",
//      "adcode_dura_city_duration_y2",
//      "adcode_dura_city_y3",
//      "adcode_dura_city_duration_y3",
//      "adcode_dist_city_y1",
//      "adcode_dist_city_dist_y1",
//      "adcode_dist_city_y2",
//      "adcode_dist_city_dist_y2",
//      "adcode_dist_city_y3",
//      "adcode_dist_city_dist_y3",
//      "adcode_city_y1",
//      "adcode_city_cnt_y1",
//      "adcode_city_y2",
//      "adcode_city_cnt_y2",
//      "adcode_city_y3",
//      "adcode_city_cnt_y3",
//      "inc_day",
//      "months_flag")
//
//    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
//    //        val spark  = SparkBuilder.localInitSpark("test")
//
//    import spark.implicits._
//    val inputPath = "/user/01420395/upload/FT20230019/230417.csv"
//    //        val inputPath = "D:\\user\\01420395\\桌面\\230417.csv"
//    val vehicle_df = spark.read.option("header", "true")
//      .option("delimiter", ",")
//      .option("inferSchema", true)
//      .option("encoding", "utf-8")
//      .option("numPartitions", 2)
//      .csv(inputPath)
//      .toDF((cols): _*)
//      .repartition(50)
//      .withColumn("vehicle_Color", 'vehicle_Color.cast("int"))
//      .withColumn("vehicle_Color", 'vehicle_Color.cast("String"))
//      .drop("num")
//
//
//    logger.error("总条数  " + vehicle_df.count())
//    vehicle_df.show(2000, false)
//
//    writeToHive(spark,vehicle_df,Seq("inc_day","months_flag"),"dm_gis.dwd_insurance_model_duration_dist_qgzh_year_feature_dtl_20230417")
//  }
//
//
//  /**
//    * 一级索引推送到hbase 中
//    * @param sourceRdd
//    */
//  def saveToHbase(sourceRdd: RDD[JSONObject]) = {
//    val hTable = "gis:gis_year_feature_dtl"
//    val family = "info"
//
//    sourceRdd.foreachPartition(iter => {
//      val table =HBaseUtils.getHbaseTable(hTable,zkParent,zkQuorum,zkPort)
//
//      iter.foreach(obj => {
//
//        val lpn = JSONUtils.getJsonValue(obj,"lpn","")
//        val vehicle_color = JSONUtils.getJsonValue(obj,"vehicle_color","")
//        val total_dist_yt = JSONUtils.getJsonValue(obj,"total_dist_yt","")
//        val total_links_dist_yt = JSONUtils.getJsonValue(obj,"total_links_dist_yt","")
//        val night_dirve_dist_yt = JSONUtils.getJsonValue(obj,"night_dirve_dist_yt","")
//        val before_dawn_drive_dist_yt = JSONUtils.getJsonValue(obj,"before_dawn_drive_dist_yt","")
//        val early_morning_drive_dist_yt = JSONUtils.getJsonValue(obj,"early_morning_drive_dist_yt","")
//        val afternoon_drive_dist_yt = JSONUtils.getJsonValue(obj,"afternoon_drive_dist_yt","")
//        val dusk_drive_dist_yt = JSONUtils.getJsonValue(obj,"dusk_drive_dist_yt","")
//        val high_speed_dist_yt = JSONUtils.getJsonValue(obj,"high_speed_dist_yt","")
//        val state_road_dist_yt = JSONUtils.getJsonValue(obj,"state_road_dist_yt","")
//        val provincial_dist_yt = JSONUtils.getJsonValue(obj,"provincial_dist_yt","")
//        val county_dist_yt = JSONUtils.getJsonValue(obj,"county_dist_yt","")
//        val township_dist_yt = JSONUtils.getJsonValue(obj,"township_dist_yt","")
//        val dangerous_road_dist_yt = JSONUtils.getJsonValue(obj,"dangerous_road_dist_yt","")
//        val high_accident_road_dist_yt = JSONUtils.getJsonValue(obj,"high_accident_road_dist_yt","")
//        val school_road_dist_yt = JSONUtils.getJsonValue(obj,"school_road_dist_yt","")
//        val sharp_turn_road_dist_yt = JSONUtils.getJsonValue(obj,"sharp_turn_road_dist_yt","")
//        val village_road_dist_yt = JSONUtils.getJsonValue(obj,"village_road_dist_yt","")
//        val night_high_speed_dist_yt = JSONUtils.getJsonValue(obj,"night_high_speed_dist_yt","")
//        val night_state_road_dist_yt = JSONUtils.getJsonValue(obj,"night_state_road_dist_yt","")
//        val night_provincial_dist_yt = JSONUtils.getJsonValue(obj,"night_provincial_dist_yt","")
//        val night_county_dist_yt = JSONUtils.getJsonValue(obj,"night_county_dist_yt","")
//        val night_township_dist_yt = JSONUtils.getJsonValue(obj,"night_township_dist_yt","")
//        val before_dawn_high_speed_dist_yt = JSONUtils.getJsonValue(obj,"before_dawn_high_speed_dist_yt","")
//        val before_dawn_state_road_dist_yt = JSONUtils.getJsonValue(obj,"before_dawn_state_road_dist_yt","")
//        val before_dawn_provincial_dist_yt = JSONUtils.getJsonValue(obj,"before_dawn_provincial_dist_yt","")
//        val before_dawn_county_dist_yt = JSONUtils.getJsonValue(obj,"before_dawn_county_dist_yt","")
//        val before_dawn_township_dist_yt = JSONUtils.getJsonValue(obj,"before_dawn_township_dist_yt","")
//        val early_morning_high_speed_dist_yt = JSONUtils.getJsonValue(obj,"early_morning_high_speed_dist_yt","")
//        val early_morning_state_road_dist_yt = JSONUtils.getJsonValue(obj,"early_morning_state_road_dist_yt","")
//        val early_morning_provincial_dist_yt = JSONUtils.getJsonValue(obj,"early_morning_provincial_dist_yt","")
//        val early_morning_county_dist_yt = JSONUtils.getJsonValue(obj,"early_morning_county_dist_yt","")
//        val early_morning_township_dist_yt = JSONUtils.getJsonValue(obj,"early_morning_township_dist_yt","")
//        val afternoon_high_speed_dist_yt = JSONUtils.getJsonValue(obj,"afternoon_high_speed_dist_yt","")
//        val afternoon_state_road_dist_yt = JSONUtils.getJsonValue(obj,"afternoon_state_road_dist_yt","")
//        val afternoon_provincial_dist_yt = JSONUtils.getJsonValue(obj,"afternoon_provincial_dist_yt","")
//        val afternoon_county_dist_yt = JSONUtils.getJsonValue(obj,"afternoon_county_dist_yt","")
//        val afternoon_township_dist_yt = JSONUtils.getJsonValue(obj,"afternoon_township_dist_yt","")
//        val dusk_high_speed_dist_yt = JSONUtils.getJsonValue(obj,"dusk_high_speed_dist_yt","")
//        val dusk_state_road_dist_yt = JSONUtils.getJsonValue(obj,"dusk_state_road_dist_yt","")
//        val dusk_provincial_dist_yt = JSONUtils.getJsonValue(obj,"dusk_provincial_dist_yt","")
//        val dusk_county_dist_yt = JSONUtils.getJsonValue(obj,"dusk_county_dist_yt","")
//        val dusk_township_dist_yt = JSONUtils.getJsonValue(obj,"dusk_township_dist_yt","")
//        val night_dirve_dist_yp = JSONUtils.getJsonValue(obj,"night_dirve_dist_yp","")
//        val before_dawn_drive_dist_yp = JSONUtils.getJsonValue(obj,"before_dawn_drive_dist_yp","")
//        val early_morning_drive_dist_yp = JSONUtils.getJsonValue(obj,"early_morning_drive_dist_yp","")
//        val afternoon_drive_dist_yp = JSONUtils.getJsonValue(obj,"afternoon_drive_dist_yp","")
//        val dusk_drive_dist_yp = JSONUtils.getJsonValue(obj,"dusk_drive_dist_yp","")
//        val high_speed_dist_yp = JSONUtils.getJsonValue(obj,"high_speed_dist_yp","")
//        val state_road_dist_yp = JSONUtils.getJsonValue(obj,"state_road_dist_yp","")
//        val provincial_dist_yp = JSONUtils.getJsonValue(obj,"provincial_dist_yp","")
//        val county_dist_yp = JSONUtils.getJsonValue(obj,"county_dist_yp","")
//        val township_dist_yp = JSONUtils.getJsonValue(obj,"township_dist_yp","")
//        val dangerous_road_dist_yp = JSONUtils.getJsonValue(obj,"dangerous_road_dist_yp","")
//        val high_accident_road_dist_yp = JSONUtils.getJsonValue(obj,"high_accident_road_dist_yp","")
//        val school_road_dist_yp = JSONUtils.getJsonValue(obj,"school_road_dist_yp","")
//        val sharp_turn_road_dist_yp = JSONUtils.getJsonValue(obj,"sharp_turn_road_dist_yp","")
//        val village_road_dist_yp = JSONUtils.getJsonValue(obj,"village_road_dist_yp","")
//        val total_dist_ym = JSONUtils.getJsonValue(obj,"total_dist_ym","")
//        val night_dirve_dist_ym = JSONUtils.getJsonValue(obj,"night_dirve_dist_ym","")
//        val before_dawn_drive_dist_ym = JSONUtils.getJsonValue(obj,"before_dawn_drive_dist_ym","")
//        val early_morning_drive_dist_ym = JSONUtils.getJsonValue(obj,"early_morning_drive_dist_ym","")
//        val afternoon_drive_dist_ym = JSONUtils.getJsonValue(obj,"afternoon_drive_dist_ym","")
//        val dusk_drive_dist_ym = JSONUtils.getJsonValue(obj,"dusk_drive_dist_ym","")
//        val high_speed_dist_ym = JSONUtils.getJsonValue(obj,"high_speed_dist_ym","")
//        val state_road_dist_ym = JSONUtils.getJsonValue(obj,"state_road_dist_ym","")
//        val provincial_dist_ym = JSONUtils.getJsonValue(obj,"provincial_dist_ym","")
//        val county_dist_ym = JSONUtils.getJsonValue(obj,"county_dist_ym","")
//        val township_dist_ym = JSONUtils.getJsonValue(obj,"township_dist_ym","")
//        val dangerous_road_dist_ym = JSONUtils.getJsonValue(obj,"dangerous_road_dist_ym","")
//        val high_accident_road_dist_ym = JSONUtils.getJsonValue(obj,"high_accident_road_dist_ym","")
//        val school_road_dist_ym = JSONUtils.getJsonValue(obj,"school_road_dist_ym","")
//        val sharp_turn_road_dist_ym = JSONUtils.getJsonValue(obj,"sharp_turn_road_dist_ym","")
//        val village_road_dist_ym = JSONUtils.getJsonValue(obj,"village_road_dist_ym","")
//        val total_duration_yt = JSONUtils.getJsonValue(obj,"total_duration_yt","")
//        val total_links_duration_yt = JSONUtils.getJsonValue(obj,"total_links_duration_yt","")
//        val night_dirve_duration_yt = JSONUtils.getJsonValue(obj,"night_dirve_duration_yt","")
//        val before_dawn_drive_duration_yt = JSONUtils.getJsonValue(obj,"before_dawn_drive_duration_yt","")
//        val early_morning_drive_duration_yt = JSONUtils.getJsonValue(obj,"early_morning_drive_duration_yt","")
//        val afternoon_drive_duration_yt = JSONUtils.getJsonValue(obj,"afternoon_drive_duration_yt","")
//        val dusk_drive_duration_yt = JSONUtils.getJsonValue(obj,"dusk_drive_duration_yt","")
//        val high_speed_duration_yt = JSONUtils.getJsonValue(obj,"high_speed_duration_yt","")
//        val state_road_duration_yt = JSONUtils.getJsonValue(obj,"state_road_duration_yt","")
//        val provincial_duration_yt = JSONUtils.getJsonValue(obj,"provincial_duration_yt","")
//        val county_duration_yt = JSONUtils.getJsonValue(obj,"county_duration_yt","")
//        val township_duration_yt = JSONUtils.getJsonValue(obj,"township_duration_yt","")
//        val dangerous_road_duration_yt = JSONUtils.getJsonValue(obj,"dangerous_road_duration_yt","")
//        val high_accident_road_duration_yt = JSONUtils.getJsonValue(obj,"high_accident_road_duration_yt","")
//        val school_road_duration_yt = JSONUtils.getJsonValue(obj,"school_road_duration_yt","")
//        val sharp_turn_road_duration_yt = JSONUtils.getJsonValue(obj,"sharp_turn_road_duration_yt","")
//        val township_road_duration_yt = JSONUtils.getJsonValue(obj,"township_road_duration_yt","")
//        val over_speed_duration_yt = JSONUtils.getJsonValue(obj,"over_speed_duration_yt","")
//        val over_speed_ser_duration_yt = JSONUtils.getJsonValue(obj,"over_speed_ser_duration_yt","")
//        val over_drive_duration_yt = JSONUtils.getJsonValue(obj,"over_drive_duration_yt","")
//        val night_high_speed_duration_yt = JSONUtils.getJsonValue(obj,"night_high_speed_duration_yt","")
//        val night_state_road_duration_yt = JSONUtils.getJsonValue(obj,"night_state_road_duration_yt","")
//        val night_provincial_duration_yt = JSONUtils.getJsonValue(obj,"night_provincial_duration_yt","")
//        val night_county_duration_yt = JSONUtils.getJsonValue(obj,"night_county_duration_yt","")
//        val night_township_duration_yt = JSONUtils.getJsonValue(obj,"night_township_duration_yt","")
//        val before_dawn_high_speed_duration_yt = JSONUtils.getJsonValue(obj,"before_dawn_high_speed_duration_yt","")
//        val before_dawn_state_road_duration_yt = JSONUtils.getJsonValue(obj,"before_dawn_state_road_duration_yt","")
//        val before_dawn_provincial_duration_yt = JSONUtils.getJsonValue(obj,"before_dawn_provincial_duration_yt","")
//        val before_dawn_county_duration_yt = JSONUtils.getJsonValue(obj,"before_dawn_county_duration_yt","")
//        val before_dawn_township_duration_yt = JSONUtils.getJsonValue(obj,"before_dawn_township_duration_yt","")
//        val early_morning_high_speed_duration_yt = JSONUtils.getJsonValue(obj,"early_morning_high_speed_duration_yt","")
//        val early_morning_state_road_duration_yt = JSONUtils.getJsonValue(obj,"early_morning_state_road_duration_yt","")
//        val early_morning_provincial_duration_yt = JSONUtils.getJsonValue(obj,"early_morning_provincial_duration_yt","")
//        val early_morning_county_duration_yt = JSONUtils.getJsonValue(obj,"early_morning_county_duration_yt","")
//        val early_morning_township_duration_yt = JSONUtils.getJsonValue(obj,"early_morning_township_duration_yt","")
//        val afternoon_high_speed_duration_yt = JSONUtils.getJsonValue(obj,"afternoon_high_speed_duration_yt","")
//        val afternoon_state_road_duration_yt = JSONUtils.getJsonValue(obj,"afternoon_state_road_duration_yt","")
//        val afternoon_provincial_duration_yt = JSONUtils.getJsonValue(obj,"afternoon_provincial_duration_yt","")
//        val afternoon_county_duration_yt = JSONUtils.getJsonValue(obj,"afternoon_county_duration_yt","")
//        val afternoon_township_duration_yt = JSONUtils.getJsonValue(obj,"afternoon_township_duration_yt","")
//        val dusk_high_speed_duration_yt = JSONUtils.getJsonValue(obj,"dusk_high_speed_duration_yt","")
//        val dusk_state_road_duration_yt = JSONUtils.getJsonValue(obj,"dusk_state_road_duration_yt","")
//        val dusk_provincial_duration_yt = JSONUtils.getJsonValue(obj,"dusk_provincial_duration_yt","")
//        val dusk_county_duration_yt = JSONUtils.getJsonValue(obj,"dusk_county_duration_yt","")
//        val dusk_township_duration_yt = JSONUtils.getJsonValue(obj,"dusk_township_duration_yt","")
//        val high_speed_lowspeed_duration_yt = JSONUtils.getJsonValue(obj,"high_speed_lowspeed_duration_yt","")
//        val night_dirve_duration_yp = JSONUtils.getJsonValue(obj,"night_dirve_duration_yp","")
//        val before_dawn_drive_duration_yp = JSONUtils.getJsonValue(obj,"before_dawn_drive_duration_yp","")
//        val early_morning_drive_duration_yp = JSONUtils.getJsonValue(obj,"early_morning_drive_duration_yp","")
//        val afternoon_drive_duration_yp = JSONUtils.getJsonValue(obj,"afternoon_drive_duration_yp","")
//        val dusk_drive_duration_yp = JSONUtils.getJsonValue(obj,"dusk_drive_duration_yp","")
//        val dangerous_road_duration_yp = JSONUtils.getJsonValue(obj,"dangerous_road_duration_yp","")
//        val high_accident_road_duration_yp = JSONUtils.getJsonValue(obj,"high_accident_road_duration_yp","")
//        val school_road_duration_yp = JSONUtils.getJsonValue(obj,"school_road_duration_yp","")
//        val sharp_turn_road_duration_yp = JSONUtils.getJsonValue(obj,"sharp_turn_road_duration_yp","")
//        val township_road_duration_yp = JSONUtils.getJsonValue(obj,"township_road_duration_yp","")
//        val over_speed_duration_yp = JSONUtils.getJsonValue(obj,"over_speed_duration_yp","")
//        val over_speed_ser_duration_yp = JSONUtils.getJsonValue(obj,"over_speed_ser_duration_yp","")
//        val over_drive_duration_yp = JSONUtils.getJsonValue(obj,"over_drive_duration_yp","")
//        val total_duration_ym = JSONUtils.getJsonValue(obj,"total_duration_ym","")
//        val night_dirve_duration_ym = JSONUtils.getJsonValue(obj,"night_dirve_duration_ym","")
//        val before_dawn_drive_duration_ym = JSONUtils.getJsonValue(obj,"before_dawn_drive_duration_ym","")
//        val early_morning_drive_duration_ym = JSONUtils.getJsonValue(obj,"early_morning_drive_duration_ym","")
//        val afternoon_drive_duration_ym = JSONUtils.getJsonValue(obj,"afternoon_drive_duration_ym","")
//        val dusk_drive_duration_ym = JSONUtils.getJsonValue(obj,"dusk_drive_duration_ym","")
//        val dangerous_road_duration_ym = JSONUtils.getJsonValue(obj,"dangerous_road_duration_ym","")
//        val high_accident_road_duration_ym = JSONUtils.getJsonValue(obj,"high_accident_road_duration_ym","")
//        val school_road_duration_ym = JSONUtils.getJsonValue(obj,"school_road_duration_ym","")
//        val sharp_turn_road_duration_ym = JSONUtils.getJsonValue(obj,"sharp_turn_road_duration_ym","")
//        val township_road_duration_ym = JSONUtils.getJsonValue(obj,"township_road_duration_ym","")
//        val over_speed_duration_ym = JSONUtils.getJsonValue(obj,"over_speed_duration_ym","")
//        val over_speed_ser_duration_ym = JSONUtils.getJsonValue(obj,"over_speed_ser_duration_ym","")
//        val over_drive_duration_ym = JSONUtils.getJsonValue(obj,"over_drive_duration_ym","")
//        val track_eff_days = JSONUtils.getJsonValue(obj,"track_eff_days","")
//        val track_eff_months = JSONUtils.getJsonValue(obj,"track_eff_months","")
//        val first_track_eff_day = JSONUtils.getJsonValue(obj,"first_track_eff_day","")
//        val lnk_cnt_yt = JSONUtils.getJsonValue(obj,"lnk_cnt_yt","")
//        val dangerous_road_cnt_yt = JSONUtils.getJsonValue(obj,"dangerous_road_cnt_yt","")
//        val high_accident_road_cnt_yt = JSONUtils.getJsonValue(obj,"high_accident_road_cnt_yt","")
//        val school_road_cnt_yt = JSONUtils.getJsonValue(obj,"school_road_cnt_yt","")
//        val sharp_turn_road_cnt_yt = JSONUtils.getJsonValue(obj,"sharp_turn_road_cnt_yt","")
//        val township_road_road_cnt_yt = JSONUtils.getJsonValue(obj,"township_road_road_cnt_yt","")
//        val night_lnk_cnt_yt = JSONUtils.getJsonValue(obj,"night_lnk_cnt_yt","")
//        val night_dangerous_road_cnt_yt = JSONUtils.getJsonValue(obj,"night_dangerous_road_cnt_yt","")
//        val night_high_accident_road_cnt_yt = JSONUtils.getJsonValue(obj,"night_high_accident_road_cnt_yt","")
//        val night_school_road_cnt_yt = JSONUtils.getJsonValue(obj,"night_school_road_cnt_yt","")
//        val night_sharp_turn_road_cnt_yt = JSONUtils.getJsonValue(obj,"night_sharp_turn_road_cnt_yt","")
//        val night_township_road_road_cnt_yt = JSONUtils.getJsonValue(obj,"night_township_road_road_cnt_yt","")
//        val before_dawn_lnk_cnt_yt = JSONUtils.getJsonValue(obj,"before_dawn_lnk_cnt_yt","")
//        val before_dawn_dangerous_road_cnt_yt = JSONUtils.getJsonValue(obj,"before_dawn_dangerous_road_cnt_yt","")
//        val before_dawn_high_accident_road_cnt_yt = JSONUtils.getJsonValue(obj,"before_dawn_high_accident_road_cnt_yt","")
//        val before_dawn_school_road_cnt_yt = JSONUtils.getJsonValue(obj,"before_dawn_school_road_cnt_yt","")
//        val before_dawn_sharp_turn_road_cnt_yt = JSONUtils.getJsonValue(obj,"before_dawn_sharp_turn_road_cnt_yt","")
//        val before_dawn_township_road_road_cnt_yt = JSONUtils.getJsonValue(obj,"before_dawn_township_road_road_cnt_yt","")
//        val early_morning_lnk_cnt_yt = JSONUtils.getJsonValue(obj,"early_morning_lnk_cnt_yt","")
//        val early_morning_dangerous_road_cnt_yt = JSONUtils.getJsonValue(obj,"early_morning_dangerous_road_cnt_yt","")
//        val early_morning_high_accident_road_cnt_yt = JSONUtils.getJsonValue(obj,"early_morning_high_accident_road_cnt_yt","")
//        val early_morning_school_road_cnt_yt = JSONUtils.getJsonValue(obj,"early_morning_school_road_cnt_yt","")
//        val early_morning_sharp_turn_road_cnt_yt = JSONUtils.getJsonValue(obj,"early_morning_sharp_turn_road_cnt_yt","")
//        val early_morning_township_road_road_cnt_yt = JSONUtils.getJsonValue(obj,"early_morning_township_road_road_cnt_yt","")
//        val afternoon_lnk_cnt_yt = JSONUtils.getJsonValue(obj,"afternoon_lnk_cnt_yt","")
//        val afternoon_dangerous_road_cnt_yt = JSONUtils.getJsonValue(obj,"afternoon_dangerous_road_cnt_yt","")
//        val afternoon_high_accident_road_cnt_yt = JSONUtils.getJsonValue(obj,"afternoon_high_accident_road_cnt_yt","")
//        val afternoon_school_road_cnt_yt = JSONUtils.getJsonValue(obj,"afternoon_school_road_cnt_yt","")
//        val afternoon_sharp_turn_road_cnt_yt = JSONUtils.getJsonValue(obj,"afternoon_sharp_turn_road_cnt_yt","")
//        val afternoon_township_road_road_cnt_yt = JSONUtils.getJsonValue(obj,"afternoon_township_road_road_cnt_yt","")
//        val dusk_lnk_cnt_yt = JSONUtils.getJsonValue(obj,"dusk_lnk_cnt_yt","")
//        val dusk_dangerous_road_cnt_yt = JSONUtils.getJsonValue(obj,"dusk_dangerous_road_cnt_yt","")
//        val dusk_high_accident_road_cnt_yt = JSONUtils.getJsonValue(obj,"dusk_high_accident_road_cnt_yt","")
//        val dusk_school_road_cnt_yt = JSONUtils.getJsonValue(obj,"dusk_school_road_cnt_yt","")
//        val dusk_sharp_turn_road_cnt_yt = JSONUtils.getJsonValue(obj,"dusk_sharp_turn_road_cnt_yt","")
//        val dusk_township_road_road_cnt_yt = JSONUtils.getJsonValue(obj,"dusk_township_road_road_cnt_yt","")
//        val operation_cnt_yt = JSONUtils.getJsonValue(obj,"operation_cnt_yt","")
//        val operation_same_city_cnt_yt = JSONUtils.getJsonValue(obj,"operation_same_city_cnt_yt","")
//        val operation_same_prov_cnt_yt = JSONUtils.getJsonValue(obj,"operation_same_prov_cnt_yt","")
//        val lnk_cnt_ym = JSONUtils.getJsonValue(obj,"lnk_cnt_ym","")
//        val dangerous_road_cnt_ym = JSONUtils.getJsonValue(obj,"dangerous_road_cnt_ym","")
//        val high_accident_road_cnt_ym = JSONUtils.getJsonValue(obj,"high_accident_road_cnt_ym","")
//        val school_road_cnt_ym = JSONUtils.getJsonValue(obj,"school_road_cnt_ym","")
//        val sharp_turn_road_cnt_ym = JSONUtils.getJsonValue(obj,"sharp_turn_road_cnt_ym","")
//        val township_road_road_cnt_ym = JSONUtils.getJsonValue(obj,"township_road_road_cnt_ym","")
//        val operation_cnt_ym = JSONUtils.getJsonValue(obj,"operation_cnt_ym","")
//        val operation_same_city_cnt_ym = JSONUtils.getJsonValue(obj,"operation_same_city_cnt_ym","")
//        val adcode_dura_prov_y1 = JSONUtils.getJsonValue(obj,"adcode_dura_prov_y1","")
//        val adcode_dura_prov_cnt_y1 = JSONUtils.getJsonValue(obj,"adcode_dura_prov_cnt_y1","")
//        val adcode_dura_prov_y2 = JSONUtils.getJsonValue(obj,"adcode_dura_prov_y2","")
//        val adcode_dura_prov_cnt_y2 = JSONUtils.getJsonValue(obj,"adcode_dura_prov_cnt_y2","")
//        val adcode_dura_prov_y3 = JSONUtils.getJsonValue(obj,"adcode_dura_prov_y3","")
//        val adcode_dura_prov_cnt_y3 = JSONUtils.getJsonValue(obj,"adcode_dura_prov_cnt_y3","")
//        val adcode_dist_prov_y1 = JSONUtils.getJsonValue(obj,"adcode_dist_prov_y1","")
//        val adcode_dist_prov_dist_y1 = JSONUtils.getJsonValue(obj,"adcode_dist_prov_dist_y1","")
//        val adcode_dist_prov_y2 = JSONUtils.getJsonValue(obj,"adcode_dist_prov_y2","")
//        val adcode_dist_prov_dist_y2 = JSONUtils.getJsonValue(obj,"adcode_dist_prov_dist_y2","")
//        val adcode_dist_prov_y3 = JSONUtils.getJsonValue(obj,"adcode_dist_prov_y3","")
//        val adcode_dist_prov_dist_y3 = JSONUtils.getJsonValue(obj,"adcode_dist_prov_dist_y3","")
//        val adcode_prov_y1 = JSONUtils.getJsonValue(obj,"adcode_prov_y1","")
//        val adcode_prov_cnt_y1 = JSONUtils.getJsonValue(obj,"adcode_prov_cnt_y1","")
//        val adcode_prov_y2 = JSONUtils.getJsonValue(obj,"adcode_prov_y2","")
//        val adcode_prov_cnt_y2 = JSONUtils.getJsonValue(obj,"adcode_prov_cnt_y2","")
//        val adcode_prov_y3 = JSONUtils.getJsonValue(obj,"adcode_prov_y3","")
//        val adcode_prov_cnt_y3 = JSONUtils.getJsonValue(obj,"adcode_prov_cnt_y3","")
//        val adcode_dura_city_y1 = JSONUtils.getJsonValue(obj,"adcode_dura_city_y1","")
//        val adcode_dura_city_duration_y1 = JSONUtils.getJsonValue(obj,"adcode_dura_city_duration_y1","")
//        val adcode_dura_city_y2 = JSONUtils.getJsonValue(obj,"adcode_dura_city_y2","")
//        val adcode_dura_city_duration_y2 = JSONUtils.getJsonValue(obj,"adcode_dura_city_duration_y2","")
//        val adcode_dura_city_y3 = JSONUtils.getJsonValue(obj,"adcode_dura_city_y3","")
//        val adcode_dura_city_duration_y3 = JSONUtils.getJsonValue(obj,"adcode_dura_city_duration_y3","")
//        val adcode_dist_city_y1 = JSONUtils.getJsonValue(obj,"adcode_dist_city_y1","")
//        val adcode_dist_city_dist_y1 = JSONUtils.getJsonValue(obj,"adcode_dist_city_dist_y1","")
//        val adcode_dist_city_y2 = JSONUtils.getJsonValue(obj,"adcode_dist_city_y2","")
//        val adcode_dist_city_dist_y2 = JSONUtils.getJsonValue(obj,"adcode_dist_city_dist_y2","")
//        val adcode_dist_city_y3 = JSONUtils.getJsonValue(obj,"adcode_dist_city_y3","")
//        val adcode_dist_city_dist_y3 = JSONUtils.getJsonValue(obj,"adcode_dist_city_dist_y3","")
//        val adcode_city_y1 = JSONUtils.getJsonValue(obj,"adcode_city_y1","")
//        val adcode_city_cnt_y1 = JSONUtils.getJsonValue(obj,"adcode_city_cnt_y1","")
//        val adcode_city_y2 = JSONUtils.getJsonValue(obj,"adcode_city_y2","")
//        val adcode_city_cnt_y2 = JSONUtils.getJsonValue(obj,"adcode_city_cnt_y2","")
//        val adcode_city_y3 = JSONUtils.getJsonValue(obj,"adcode_city_y3","")
//        val adcode_city_cnt_y3 = JSONUtils.getJsonValue(obj,"adcode_city_cnt_y3","")
//        val inc_day = JSONUtils.getJsonValue(obj,"inc_day","")
//        val months_flag = JSONUtils.getJsonValue(obj,"months_flag","")
//
//
//        val rowkey =  JSONUtils.getJsonValue(obj,"rowkey","")
//
//        val put = new Put(Bytes.toBytes(rowkey))
//
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("lpn"), Bytes.toBytes(lpn))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("vehicle_color"), Bytes.toBytes(vehicle_color))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("total_dist_yt"), Bytes.toBytes(total_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("total_links_dist_yt"), Bytes.toBytes(total_links_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_dirve_dist_yt"), Bytes.toBytes(night_dirve_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_drive_dist_yt"), Bytes.toBytes(before_dawn_drive_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_drive_dist_yt"), Bytes.toBytes(early_morning_drive_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_drive_dist_yt"), Bytes.toBytes(afternoon_drive_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_drive_dist_yt"), Bytes.toBytes(dusk_drive_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_speed_dist_yt"), Bytes.toBytes(high_speed_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("state_road_dist_yt"), Bytes.toBytes(state_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("provincial_dist_yt"), Bytes.toBytes(provincial_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("county_dist_yt"), Bytes.toBytes(county_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_dist_yt"), Bytes.toBytes(township_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dangerous_road_dist_yt"), Bytes.toBytes(dangerous_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_accident_road_dist_yt"), Bytes.toBytes(high_accident_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("school_road_dist_yt"), Bytes.toBytes(school_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("sharp_turn_road_dist_yt"), Bytes.toBytes(sharp_turn_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("village_road_dist_yt"), Bytes.toBytes(village_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_high_speed_dist_yt"), Bytes.toBytes(night_high_speed_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_state_road_dist_yt"), Bytes.toBytes(night_state_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_provincial_dist_yt"), Bytes.toBytes(night_provincial_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_county_dist_yt"), Bytes.toBytes(night_county_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_township_dist_yt"), Bytes.toBytes(night_township_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_high_speed_dist_yt"), Bytes.toBytes(before_dawn_high_speed_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_state_road_dist_yt"), Bytes.toBytes(before_dawn_state_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_provincial_dist_yt"), Bytes.toBytes(before_dawn_provincial_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_county_dist_yt"), Bytes.toBytes(before_dawn_county_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_township_dist_yt"), Bytes.toBytes(before_dawn_township_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_high_speed_dist_yt"), Bytes.toBytes(early_morning_high_speed_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_state_road_dist_yt"), Bytes.toBytes(early_morning_state_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_provincial_dist_yt"), Bytes.toBytes(early_morning_provincial_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_county_dist_yt"), Bytes.toBytes(early_morning_county_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_township_dist_yt"), Bytes.toBytes(early_morning_township_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_high_speed_dist_yt"), Bytes.toBytes(afternoon_high_speed_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_state_road_dist_yt"), Bytes.toBytes(afternoon_state_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_provincial_dist_yt"), Bytes.toBytes(afternoon_provincial_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_county_dist_yt"), Bytes.toBytes(afternoon_county_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_township_dist_yt"), Bytes.toBytes(afternoon_township_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_high_speed_dist_yt"), Bytes.toBytes(dusk_high_speed_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_state_road_dist_yt"), Bytes.toBytes(dusk_state_road_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_provincial_dist_yt"), Bytes.toBytes(dusk_provincial_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_county_dist_yt"), Bytes.toBytes(dusk_county_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_township_dist_yt"), Bytes.toBytes(dusk_township_dist_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_dirve_dist_yp"), Bytes.toBytes(night_dirve_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_drive_dist_yp"), Bytes.toBytes(before_dawn_drive_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_drive_dist_yp"), Bytes.toBytes(early_morning_drive_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_drive_dist_yp"), Bytes.toBytes(afternoon_drive_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_drive_dist_yp"), Bytes.toBytes(dusk_drive_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_speed_dist_yp"), Bytes.toBytes(high_speed_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("state_road_dist_yp"), Bytes.toBytes(state_road_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("provincial_dist_yp"), Bytes.toBytes(provincial_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("county_dist_yp"), Bytes.toBytes(county_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_dist_yp"), Bytes.toBytes(township_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dangerous_road_dist_yp"), Bytes.toBytes(dangerous_road_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_accident_road_dist_yp"), Bytes.toBytes(high_accident_road_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("school_road_dist_yp"), Bytes.toBytes(school_road_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("sharp_turn_road_dist_yp"), Bytes.toBytes(sharp_turn_road_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("village_road_dist_yp"), Bytes.toBytes(village_road_dist_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("total_dist_ym"), Bytes.toBytes(total_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_dirve_dist_ym"), Bytes.toBytes(night_dirve_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_drive_dist_ym"), Bytes.toBytes(before_dawn_drive_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_drive_dist_ym"), Bytes.toBytes(early_morning_drive_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_drive_dist_ym"), Bytes.toBytes(afternoon_drive_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_drive_dist_ym"), Bytes.toBytes(dusk_drive_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_speed_dist_ym"), Bytes.toBytes(high_speed_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("state_road_dist_ym"), Bytes.toBytes(state_road_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("provincial_dist_ym"), Bytes.toBytes(provincial_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("county_dist_ym"), Bytes.toBytes(county_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_dist_ym"), Bytes.toBytes(township_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dangerous_road_dist_ym"), Bytes.toBytes(dangerous_road_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_accident_road_dist_ym"), Bytes.toBytes(high_accident_road_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("school_road_dist_ym"), Bytes.toBytes(school_road_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("sharp_turn_road_dist_ym"), Bytes.toBytes(sharp_turn_road_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("village_road_dist_ym"), Bytes.toBytes(village_road_dist_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("total_duration_yt"), Bytes.toBytes(total_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("total_links_duration_yt"), Bytes.toBytes(total_links_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_dirve_duration_yt"), Bytes.toBytes(night_dirve_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_drive_duration_yt"), Bytes.toBytes(before_dawn_drive_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_drive_duration_yt"), Bytes.toBytes(early_morning_drive_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_drive_duration_yt"), Bytes.toBytes(afternoon_drive_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_drive_duration_yt"), Bytes.toBytes(dusk_drive_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_speed_duration_yt"), Bytes.toBytes(high_speed_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("state_road_duration_yt"), Bytes.toBytes(state_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("provincial_duration_yt"), Bytes.toBytes(provincial_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("county_duration_yt"), Bytes.toBytes(county_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_duration_yt"), Bytes.toBytes(township_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dangerous_road_duration_yt"), Bytes.toBytes(dangerous_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_accident_road_duration_yt"), Bytes.toBytes(high_accident_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("school_road_duration_yt"), Bytes.toBytes(school_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("sharp_turn_road_duration_yt"), Bytes.toBytes(sharp_turn_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_road_duration_yt"), Bytes.toBytes(township_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_speed_duration_yt"), Bytes.toBytes(over_speed_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_speed_ser_duration_yt"), Bytes.toBytes(over_speed_ser_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_drive_duration_yt"), Bytes.toBytes(over_drive_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_high_speed_duration_yt"), Bytes.toBytes(night_high_speed_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_state_road_duration_yt"), Bytes.toBytes(night_state_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_provincial_duration_yt"), Bytes.toBytes(night_provincial_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_county_duration_yt"), Bytes.toBytes(night_county_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_township_duration_yt"), Bytes.toBytes(night_township_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_high_speed_duration_yt"), Bytes.toBytes(before_dawn_high_speed_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_state_road_duration_yt"), Bytes.toBytes(before_dawn_state_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_provincial_duration_yt"), Bytes.toBytes(before_dawn_provincial_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_county_duration_yt"), Bytes.toBytes(before_dawn_county_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_township_duration_yt"), Bytes.toBytes(before_dawn_township_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_high_speed_duration_yt"), Bytes.toBytes(early_morning_high_speed_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_state_road_duration_yt"), Bytes.toBytes(early_morning_state_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_provincial_duration_yt"), Bytes.toBytes(early_morning_provincial_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_county_duration_yt"), Bytes.toBytes(early_morning_county_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_township_duration_yt"), Bytes.toBytes(early_morning_township_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_high_speed_duration_yt"), Bytes.toBytes(afternoon_high_speed_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_state_road_duration_yt"), Bytes.toBytes(afternoon_state_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_provincial_duration_yt"), Bytes.toBytes(afternoon_provincial_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_county_duration_yt"), Bytes.toBytes(afternoon_county_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_township_duration_yt"), Bytes.toBytes(afternoon_township_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_high_speed_duration_yt"), Bytes.toBytes(dusk_high_speed_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_state_road_duration_yt"), Bytes.toBytes(dusk_state_road_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_provincial_duration_yt"), Bytes.toBytes(dusk_provincial_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_county_duration_yt"), Bytes.toBytes(dusk_county_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_township_duration_yt"), Bytes.toBytes(dusk_township_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_speed_lowspeed_duration_yt"), Bytes.toBytes(high_speed_lowspeed_duration_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_dirve_duration_yp"), Bytes.toBytes(night_dirve_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_drive_duration_yp"), Bytes.toBytes(before_dawn_drive_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_drive_duration_yp"), Bytes.toBytes(early_morning_drive_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_drive_duration_yp"), Bytes.toBytes(afternoon_drive_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_drive_duration_yp"), Bytes.toBytes(dusk_drive_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dangerous_road_duration_yp"), Bytes.toBytes(dangerous_road_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_accident_road_duration_yp"), Bytes.toBytes(high_accident_road_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("school_road_duration_yp"), Bytes.toBytes(school_road_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("sharp_turn_road_duration_yp"), Bytes.toBytes(sharp_turn_road_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_road_duration_yp"), Bytes.toBytes(township_road_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_speed_duration_yp"), Bytes.toBytes(over_speed_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_speed_ser_duration_yp"), Bytes.toBytes(over_speed_ser_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_drive_duration_yp"), Bytes.toBytes(over_drive_duration_yp))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("total_duration_ym"), Bytes.toBytes(total_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_dirve_duration_ym"), Bytes.toBytes(night_dirve_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_drive_duration_ym"), Bytes.toBytes(before_dawn_drive_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_drive_duration_ym"), Bytes.toBytes(early_morning_drive_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_drive_duration_ym"), Bytes.toBytes(afternoon_drive_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_drive_duration_ym"), Bytes.toBytes(dusk_drive_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dangerous_road_duration_ym"), Bytes.toBytes(dangerous_road_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_accident_road_duration_ym"), Bytes.toBytes(high_accident_road_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("school_road_duration_ym"), Bytes.toBytes(school_road_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("sharp_turn_road_duration_ym"), Bytes.toBytes(sharp_turn_road_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_road_duration_ym"), Bytes.toBytes(township_road_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_speed_duration_ym"), Bytes.toBytes(over_speed_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_speed_ser_duration_ym"), Bytes.toBytes(over_speed_ser_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("over_drive_duration_ym"), Bytes.toBytes(over_drive_duration_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("track_eff_days"), Bytes.toBytes(track_eff_days))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("track_eff_months"), Bytes.toBytes(track_eff_months))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("first_track_eff_day"), Bytes.toBytes(first_track_eff_day))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("lnk_cnt_yt"), Bytes.toBytes(lnk_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dangerous_road_cnt_yt"), Bytes.toBytes(dangerous_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_accident_road_cnt_yt"), Bytes.toBytes(high_accident_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("school_road_cnt_yt"), Bytes.toBytes(school_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("sharp_turn_road_cnt_yt"), Bytes.toBytes(sharp_turn_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_road_road_cnt_yt"), Bytes.toBytes(township_road_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_lnk_cnt_yt"), Bytes.toBytes(night_lnk_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_dangerous_road_cnt_yt"), Bytes.toBytes(night_dangerous_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_high_accident_road_cnt_yt"), Bytes.toBytes(night_high_accident_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_school_road_cnt_yt"), Bytes.toBytes(night_school_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_sharp_turn_road_cnt_yt"), Bytes.toBytes(night_sharp_turn_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("night_township_road_road_cnt_yt"), Bytes.toBytes(night_township_road_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_lnk_cnt_yt"), Bytes.toBytes(before_dawn_lnk_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_dangerous_road_cnt_yt"), Bytes.toBytes(before_dawn_dangerous_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_high_accident_road_cnt_yt"), Bytes.toBytes(before_dawn_high_accident_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_school_road_cnt_yt"), Bytes.toBytes(before_dawn_school_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_sharp_turn_road_cnt_yt"), Bytes.toBytes(before_dawn_sharp_turn_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("before_dawn_township_road_road_cnt_yt"), Bytes.toBytes(before_dawn_township_road_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_lnk_cnt_yt"), Bytes.toBytes(early_morning_lnk_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_dangerous_road_cnt_yt"), Bytes.toBytes(early_morning_dangerous_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_high_accident_road_cnt_yt"), Bytes.toBytes(early_morning_high_accident_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_school_road_cnt_yt"), Bytes.toBytes(early_morning_school_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_sharp_turn_road_cnt_yt"), Bytes.toBytes(early_morning_sharp_turn_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("early_morning_township_road_road_cnt_yt"), Bytes.toBytes(early_morning_township_road_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_lnk_cnt_yt"), Bytes.toBytes(afternoon_lnk_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_dangerous_road_cnt_yt"), Bytes.toBytes(afternoon_dangerous_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_high_accident_road_cnt_yt"), Bytes.toBytes(afternoon_high_accident_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_school_road_cnt_yt"), Bytes.toBytes(afternoon_school_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_sharp_turn_road_cnt_yt"), Bytes.toBytes(afternoon_sharp_turn_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("afternoon_township_road_road_cnt_yt"), Bytes.toBytes(afternoon_township_road_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_lnk_cnt_yt"), Bytes.toBytes(dusk_lnk_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_dangerous_road_cnt_yt"), Bytes.toBytes(dusk_dangerous_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_high_accident_road_cnt_yt"), Bytes.toBytes(dusk_high_accident_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_school_road_cnt_yt"), Bytes.toBytes(dusk_school_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_sharp_turn_road_cnt_yt"), Bytes.toBytes(dusk_sharp_turn_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dusk_township_road_road_cnt_yt"), Bytes.toBytes(dusk_township_road_road_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("operation_cnt_yt"), Bytes.toBytes(operation_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("operation_same_city_cnt_yt"), Bytes.toBytes(operation_same_city_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("operation_same_prov_cnt_yt"), Bytes.toBytes(operation_same_prov_cnt_yt))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("lnk_cnt_ym"), Bytes.toBytes(lnk_cnt_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("dangerous_road_cnt_ym"), Bytes.toBytes(dangerous_road_cnt_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("high_accident_road_cnt_ym"), Bytes.toBytes(high_accident_road_cnt_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("school_road_cnt_ym"), Bytes.toBytes(school_road_cnt_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("sharp_turn_road_cnt_ym"), Bytes.toBytes(sharp_turn_road_cnt_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("township_road_road_cnt_ym"), Bytes.toBytes(township_road_road_cnt_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("operation_cnt_ym"), Bytes.toBytes(operation_cnt_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("operation_same_city_cnt_ym"), Bytes.toBytes(operation_same_city_cnt_ym))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_prov_y1"), Bytes.toBytes(adcode_dura_prov_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_prov_cnt_y1"), Bytes.toBytes(adcode_dura_prov_cnt_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_prov_y2"), Bytes.toBytes(adcode_dura_prov_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_prov_cnt_y2"), Bytes.toBytes(adcode_dura_prov_cnt_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_prov_y3"), Bytes.toBytes(adcode_dura_prov_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_prov_cnt_y3"), Bytes.toBytes(adcode_dura_prov_cnt_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_prov_y1"), Bytes.toBytes(adcode_dist_prov_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_prov_dist_y1"), Bytes.toBytes(adcode_dist_prov_dist_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_prov_y2"), Bytes.toBytes(adcode_dist_prov_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_prov_dist_y2"), Bytes.toBytes(adcode_dist_prov_dist_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_prov_y3"), Bytes.toBytes(adcode_dist_prov_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_prov_dist_y3"), Bytes.toBytes(adcode_dist_prov_dist_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_prov_y1"), Bytes.toBytes(adcode_prov_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_prov_cnt_y1"), Bytes.toBytes(adcode_prov_cnt_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_prov_y2"), Bytes.toBytes(adcode_prov_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_prov_cnt_y2"), Bytes.toBytes(adcode_prov_cnt_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_prov_y3"), Bytes.toBytes(adcode_prov_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_prov_cnt_y3"), Bytes.toBytes(adcode_prov_cnt_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_city_y1"), Bytes.toBytes(adcode_dura_city_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_city_duration_y1"), Bytes.toBytes(adcode_dura_city_duration_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_city_y2"), Bytes.toBytes(adcode_dura_city_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_city_duration_y2"), Bytes.toBytes(adcode_dura_city_duration_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_city_y3"), Bytes.toBytes(adcode_dura_city_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dura_city_duration_y3"), Bytes.toBytes(adcode_dura_city_duration_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_city_y1"), Bytes.toBytes(adcode_dist_city_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_city_dist_y1"), Bytes.toBytes(adcode_dist_city_dist_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_city_y2"), Bytes.toBytes(adcode_dist_city_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_city_dist_y2"), Bytes.toBytes(adcode_dist_city_dist_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_city_y3"), Bytes.toBytes(adcode_dist_city_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_dist_city_dist_y3"), Bytes.toBytes(adcode_dist_city_dist_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_city_y1"), Bytes.toBytes(adcode_city_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_city_cnt_y1"), Bytes.toBytes(adcode_city_cnt_y1))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_city_y2"), Bytes.toBytes(adcode_city_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_city_cnt_y2"), Bytes.toBytes(adcode_city_cnt_y2))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_city_y3"), Bytes.toBytes(adcode_city_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("adcode_city_cnt_y3"), Bytes.toBytes(adcode_city_cnt_y3))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("inc_day"), Bytes.toBytes(inc_day))
//        put.addColumn(Bytes.toBytes(family), Bytes.toBytes("months_flag"), Bytes.toBytes(months_flag))
//
//        try{
//          table.put(put)
//        }catch {
//          case e:Exception=> logger.error(rowkey+","+obj.toJSONString)
//        }
//        table.flushCommits()
//      })
//
//      table.close()
//
//    })
//
//    logger.error("写入hbase成功")
//
//  }
//
//
//  def main(args: Array[String]): Unit = {
//    val sourceRdd = getSourceRdd()
//
//    //导入hbase中
//    //    saveToHbase(SparkUtils.getRowToJson(sourceRdd))
//    logger.error("统计结束")
//  }
//
//
//}
