package com.sf.gis.scala.scm.app.GIS_RSS_ETA

import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.{DateUtil, SparkBuilder}


/**
  *@author 01420395
  *@DESCRIPTION
  *需求ID 1861561 GIS-RSS-ETA：【时效专项】 一级护航干预指标监控线上化_V1.0
 * 任务id :  773891
  *任务依赖：
  *@create 2023/06/28
  */
object total_zhibiao  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val sourceDF  = get_grd_ft_duiying_ite(spark, inc_day)

    import org.apache.spark.sql.functions._
    import spark.implicits._


   val  sourceDf2 =  sourceDF.groupBy('inc_day).agg(
     sum(when('alarm_id isNotNull,1).otherwise(0)).as("Num_first_level_ft"),
     sum(when('alarm_id isNotNull,1).otherwise(0)).as("Num_first_level_ft_huhang"),
     sum(when(('alarm_id isNotNull) && ('def_need_type === "1"),1).otherwise(0)).as("Num_huhang"),
     sum(when('def_need_type === "0" && ('alarm_id isNotNull) ,1).otherwise(0)).as("Num_no_huhang"),
     sum(when('def_respond_tm<=900 && 'def_need_type ==="1" && ('alarm_id isNotNull) ,1).otherwise(0))
       .as("Num_huhang_jishi_heshi"),
     sum(when('def_respond_tm>900 && 'def_need_type ==="1" && ('alarm_id isNotNull) ,1).otherwise(0))
       .as("Num_no_huhang_jishi_heshi"),

     sum(when('def_respond_tm<=900 && 'def_need_type ==="1" && ('alarm_id isNotNull)
       && (('def_major_reason isNotNull) && 'def_major_reason =!=""),1).otherwise(0))
       .as("Num_heshi"),
     //     Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900 and def_major_reason 为null
     sum(when('def_respond_tm<=900 && 'def_need_type ==="1" && ('alarm_id isNotNull)
       && (('def_major_reason isNull) || 'def_major_reason ==="") ,1).otherwise(0)).as("Num_no_heshi"),

     //Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900 and def_major_reason 为null and def_pf_phone_on = 0
     sum(when('def_respond_tm  <= 900 && 'def_need_type ==="1"
       &&('alarm_id isNotNull)  &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'def_pf_phone_on ==="0",1).otherwise(0))
       .as("Num_phone_no"),

     //Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900 and def_major_reason 为null
     // and def_pf_phone_on = 0 and def_car_driver_mate = 0
     sum(when('def_respond_tm  <= 900 && 'def_need_type ==="1"&&('alarm_id isNotNull)
       &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'def_pf_phone_on ==="1"
       && 'def_car_driver_mate==="0",1).otherwise(0))
       .as("People_car_nomatch"),

     //Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900 and def_major_reason 为null
     // and def_pf_phone_on = 0 and def_car_driver_mate = 0 and def_pf_phone_true = 0
     sum(when('def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
       &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'def_pf_phone_on ==="1" && 'def_car_driver_mate ==="1" && 'def_pf_phone_true ==="0",1).otherwise(0))
       .as("Wrong_phone_number"),


      //Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
     // and def_major_reason 为null and def_pf_phone_on = 0
     // and def_car_driver_mate = 0 and def_pf_phone_true = 0 and def_pf_dr_coo = 0
     sum(when('def_respond_tm  <= 900 && 'def_need_type ==="1"&&('alarm_id isNotNull)
       &&  (('def_major_reason isNull) || 'def_major_reason ==="")
       && 'def_pf_phone_on ==="1"  && 'def_car_driver_mate==="1" && 'def_pf_phone_true ==="1" && 'def_pf_dr_coo ==="0",1).otherwise(0))
       .as("Attitude_incompatibility"),


//     Count(alarm_id) where alarm_id 不为null
     //     and def_need_type = 1 and def_respond_tm<=900 and def_major_reason 为null
     //    and def_pf_dr_coo in (‘996’,’995’)

//     Count(alarm_id) where alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900 and def_major_reason 为null
//       and def_pf_dr_coo in (‘996’,’995’)
     sum(when('def_respond_tm  <= 900 && 'def_need_type ==="1"&&('alarm_id isNotNull)
       &&  (('def_major_reason isNull) || 'def_major_reason ==="")
      && ('def_end_type ==="996" ||  'def_end_type ==="995"),1).otherwise(0))
       .as("Alarm_relieve"),


     // Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
     // and def_major_reason 不为null and def_major_reason_item in ('10702','20001','20101','20201','20301','20401','20501')
     sum(when('def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
       &&  (('def_major_reason isNotNull) && 'def_major_reason =!="")
       && ('def_major_reason_item ==="10702" or 'def_major_reason_item ==="20001" or 'def_major_reason_item ==="20101"
       or 'def_major_reason_item ==="20201" or 'def_major_reason_item ==="20301"  or 'def_major_reason_item ==="20401"
       or 'def_major_reason_item ==="20501"),1).otherwise(0))
       .as("Num_heshi_upgrade"),

     //Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
     // and def_major_reason 不为null and def_objective_alarm = 0
     sum(when('def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
       &&  (('def_major_reason isNotNull) && 'def_major_reason =!="")
       && 'def_objective_alarm ==="0" && 'def_major_alarm ==="0",1).otherwise(0))
       .as("Num_heshi_ganyu_sub"),


     //Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
     // and def_major_reason 不为null and def_objective_alarm = 0 and def_task_alarm_state = 1
     sum(when(
       'def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
         &&  (('def_major_reason isNotNull) && 'def_major_reason =!="")
         && 'def_objective_alarm ==="0" && 'def_task_alarm_state === 1
       && 'def_major_alarm==="0",1).otherwise(0))
       .as("Num_heshi_ganyu_sub_success"),


    // Count(alarm_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
     // and def_major_reason 不为null and def_objective_alarm = 0 and def_task_alarm_state in (‘0’,’2’)
     sum(when(
       'def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
         &&  (('def_major_reason isNotNull) && 'def_major_reason =!="") && 'def_objective_alarm ==="0"
         &&('def_task_alarm_state ==="0" ) &&  'def_major_alarm==="0",1).otherwise(0))
       .as("Num_heshi_ganyu_sub_fail"),


     //Num_heshi_ganyu_sub_fail_tm
//     Avg(Relieve_tm2) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
//    and def_major_reason 不为null and def_objective_alarm = 0 and def_task_alarm_state = 0

     sum(when(
       'def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
         &&  (('def_major_reason isNotNull) && 'def_major_reason =!="") && 'def_objective_alarm === "0"
         &&('def_task_alarm_state ==="0" &&  'def_major_alarm==="0"),1).otherwise(0))
       .as("Num_heshi_ganyu_sub_fail_tm_count"),


       sum(when(
       'def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
         &&  (('def_major_reason isNotNull) && 'def_major_reason =!="") && 'def_objective_alarm === "0"
         &&('def_task_alarm_state ==="0" &&  'def_major_alarm==="0" ),'Relieve_tm2).otherwise(0))
         .as("Num_heshi_ganyu_sub_fail_tm_sum"),


     //Num_heshi_ganyu_sub_success_tm  Avg(Relieve_tm2) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
     // and def_major_reason 不为null
     // and def_objective_alarm = 0 and def_task_alarm_state = 1
     sum(when(
       'def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
         &&  (('def_major_reason isNotNull) && 'def_major_reason =!="") && 'def_objective_alarm ==="0"
         &&('def_task_alarm_state  ==="1") &&  'def_major_alarm==="0",1).otherwise(0))
       .as("Num_heshi_ganyu_sub_success_tm_count"),

       sum(when(
       'def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
         &&  (('def_major_reason isNotNull) && 'def_major_reason =!="") && 'def_objective_alarm ==="0"
         &&('def_task_alarm_state  ==="1") &&  'def_major_alarm==="0",'Relieve_tm2).otherwise(0))
         .as("Num_heshi_ganyu_sub_success_tm_sum")


   )
    sourceDf2.show(1)

    val countDF = sourceDF.groupBy('inc_day).agg(sum(lit(1)).as("Num_first_level_grd"))

//    Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1  and def_respond_tm<=900
//    and def_major_reason 为null and grd_carrier_type = 0
  val Num_task_no_heshi_zy = sourceDF.filter('def_respond_tm  <= 900 && 'def_need_type ==="1" &&('alarm_id isNotNull)
    &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'grd_carrier_type ==="0").groupBy('inc_day)
    .agg(countDistinct('task_id).as("Num_task_no_heshi_zy"))

    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 为null and grd_punctual = 1 and grd_carrier_type = 0

    val Num_task_no_heshi_ontime_zy = sourceDF.filter(('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'grd_punctual === "1" && 'grd_carrier_type ==="0").groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_no_heshi_ontime_zy"))



//    Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
//    and def_major_reason 为null and grd_punctual = 2 and grd_carrier_type = 0
    val Num_task_no_heshi_delay_zy = sourceDF.filter(('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
      &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'grd_punctual ==="2" && 'grd_carrier_type ==="0").groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_no_heshi_delay_zy"))



    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 为null and grd_punctual = 0 and grd_carrier_type = 0
    val Num_task_no_heshi_ontrip_zy = sourceDF.filter(('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
      &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'grd_punctual ==="0" && 'grd_carrier_type ==="0" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_no_heshi_ontrip_zy"))


//Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
// and def_major_reason 为null and grd_carrier_type = 0
    val Num_task_no_heshi_wb = sourceDF.filter(('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
      &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'grd_carrier_type ==="1" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_no_heshi_wb"))

//Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
// and def_major_reason 为null and grd_punctual = 1 and grd_carrier_type = 0
    val Num_task_no_heshi_ontime_wb = sourceDF.filter(('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
      &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'grd_punctual === "1" && 'grd_carrier_type === "1" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_no_heshi_ontime_wb"))

    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 为null and grd_punctual = 2 and grd_carrier_type = 0
    val Num_task_no_heshi_delay_wb = sourceDF.filter(('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
      &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'grd_punctual ==="2" && 'grd_carrier_type ==="1" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_no_heshi_delay_wb"))


    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 为null and grd_punctual = 0 and grd_carrier_type = 0
    val Num_task_no_heshi_ontrip_wb = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNull) || 'def_major_reason ==="") && 'grd_punctual ==="0" && 'grd_carrier_type ==="1" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_no_heshi_ontrip_wb"))


    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 不为null and grd_carrier_type = 0
    val Num_task_heshi_zy = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNotNull) &&  'def_major_reason =!="") && 'grd_carrier_type ==="0" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_heshi_zy"))

//Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
// and def_major_reason 不为null and grd_punctual = 1 and grd_carrier_type = 0
    val Num_task_heshi_ontime_zy = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNotNull) &&  'def_major_reason =!="") && 'grd_carrier_type ==="0" && 'grd_punctual === "1" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_heshi_ontime_zy"))


    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 不为null and grd_punctual = 2 and grd_carrier_type = 0
    val Num_task_heshi_delay_zy = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNotNull) &&  'def_major_reason =!="") && 'grd_carrier_type ==="0" && 'grd_punctual ==="2" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_heshi_delay_zy"))


    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 不为null and grd_punctual = 0 and grd_carrier_type = 0

    val Num_task_heshi_ontrip_zy = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNotNull) &&  'def_major_reason =!="") && 'grd_carrier_type ==="0" && 'grd_punctual ==="0").groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_heshi_ontrip_zy"))

    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 不为null and grd_carrier_type = 0

    val Num_task_heshi_wb = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNotNull) &&  'def_major_reason =!="") && 'grd_carrier_type ==="1" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_heshi_wb"))

//Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 不为null and grd_punctual = 1 and grd_carrier_type = 0
    val Num_task_heshi_ontime_wb = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        && (('def_major_reason isNotNull) &&  'def_major_reason =!="") && 'grd_punctual ==="1" && 'grd_carrier_type ==="1" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_heshi_ontime_wb"))

    //Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
    // and def_major_reason 不为null and grd_punctual = 2 and grd_carrier_type = 0

    val Num_task_heshi_delay_wb = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNotNull) &&  'def_major_reason =!="") && 'grd_carrier_type ==="1" && 'grd_punctual ==="2" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_heshi_delay_wb"))

//Count(distinct Task_id) if alarm_id 不为null and def_need_type = 1 and def_respond_tm<=900
// and def_major_reason 不为null and grd_punctual = 0 and grd_carrier_type = 0
    val Num_task_heshi_ontrip_wb = sourceDF.filter(
      ('alarm_id isNotNull) && 'def_need_type ==="1"  && 'def_respond_tm  <= 900
        &&  (('def_major_reason isNotNull) &&  'def_major_reason =!="") && 'grd_carrier_type ==="1" && 'grd_punctual ==="0" ).groupBy('inc_day)
      .agg(countDistinct('task_id).as("Num_task_heshi_ontrip_wb"))


   val sourceDf9= sourceDf2.join(countDF,Seq("inc_day"),"left")
     .join(Num_task_no_heshi_ontime_zy,Seq("inc_day"),"left")
     .join(Num_task_no_heshi_delay_zy,Seq("inc_day"),"left")
     .join(Num_task_no_heshi_ontrip_zy,Seq("inc_day"),"left")
     .join(Num_task_no_heshi_wb,Seq("inc_day"),"left")
     .join(Num_task_no_heshi_ontime_wb,Seq("inc_day"),"left")

     .join(Num_task_no_heshi_delay_wb,Seq("inc_day"),"left")
     .join(Num_task_no_heshi_ontrip_wb,Seq("inc_day"),"left")
     .join(Num_task_heshi_zy,Seq("inc_day"),"left")
     .join(Num_task_heshi_ontime_zy,Seq("inc_day"),"left")
     .join(Num_task_heshi_delay_zy,Seq("inc_day"),"left")
     .join(Num_task_heshi_ontrip_zy,Seq("inc_day"),"left")
     .join(Num_task_heshi_wb,Seq("inc_day"),"left")

     .join(Num_task_heshi_delay_wb,Seq("inc_day"),"left")
     .join(Num_task_heshi_ontrip_wb,Seq("inc_day"),"left")
     .join(Num_task_no_heshi_zy,Seq("inc_day"),"left")
     .join(Num_task_heshi_ontime_wb,Seq("inc_day"),"left")


     //空值给成默认 0
     val sourceDf8  = sourceDf9
       .withColumn("Num_task_no_heshi_ontime_zy", when('Num_task_no_heshi_ontime_zy isNull,0 )
         .otherwise('Num_task_no_heshi_ontime_zy))

       .withColumn("Num_task_no_heshi_delay_zy", when('Num_task_no_heshi_delay_zy isNull,0 )
         .otherwise('Num_task_no_heshi_delay_zy))

       .withColumn("Num_task_no_heshi_ontrip_zy", when('Num_task_no_heshi_ontrip_zy isNull,0 )
         .otherwise('Num_task_no_heshi_ontrip_zy))

       .withColumn("Num_task_no_heshi_wb", when('Num_task_no_heshi_wb isNull,0 )
         .otherwise('Num_task_no_heshi_wb))

       .withColumn("Num_task_no_heshi_ontime_wb", when('Num_task_no_heshi_ontime_wb isNull,0 )
         .otherwise('Num_task_no_heshi_ontime_wb))


       .withColumn("Num_task_no_heshi_delay_wb", when('Num_task_no_heshi_delay_wb isNull,0 )
         .otherwise('Num_task_no_heshi_delay_wb))
       .withColumn("Num_task_no_heshi_ontrip_wb", when('Num_task_no_heshi_ontrip_wb isNull,0 )
         .otherwise('Num_task_no_heshi_ontrip_wb))

       .withColumn("Num_task_heshi_zy", when('Num_task_heshi_zy isNull,0 )
         .otherwise('Num_task_heshi_zy))

       .withColumn("Num_task_heshi_ontime_zy", when('Num_task_heshi_ontime_zy isNull,0 )
         .otherwise('Num_task_heshi_ontime_zy))

       .withColumn("Num_task_heshi_delay_zy", when('Num_task_heshi_delay_zy isNull,0 )
         .otherwise('Num_task_heshi_delay_zy))

       .withColumn("Num_task_heshi_ontrip_zy", when('Num_task_heshi_ontrip_zy isNull,0 )
         .otherwise('Num_task_heshi_ontrip_zy))


       .withColumn("Num_task_heshi_wb", when('Num_task_heshi_wb isNull,0 )
         .otherwise('Num_task_heshi_wb))
       .withColumn("Num_task_heshi_delay_wb", when('Num_task_heshi_delay_wb isNull,0 )
         .otherwise('Num_task_heshi_delay_wb))

       .withColumn("Num_task_heshi_ontrip_wb", when('Num_task_heshi_ontrip_wb isNull,0 )
         .otherwise('Num_task_heshi_ontrip_wb))


       .withColumn("Num_task_no_heshi_zy", when('Num_task_no_heshi_zy isNull,0 )
         .otherwise('Num_task_no_heshi_zy))

       .withColumn("Num_task_heshi_ontime_wb", when('Num_task_heshi_ontime_wb isNull,0 )
         .otherwise('Num_task_heshi_ontime_wb))




    val sourceDf4 =  sourceDf8.withColumn("Ratio_first_jieru",'Num_first_level_ft/'Num_first_level_grd)
      .withColumn("Ratio_huhang",'Num_huhang/'Num_first_level_ft_huhang)
      .withColumn("Ratio_huhang_ontime",'Num_huhang_jishi_heshi/'Num_first_level_ft_huhang)
      .withColumn("ratio_heshi",'Num_heshi/'Num_huhang_jishi_heshi)
      .withColumn("ratio_no_heshi",'Num_no_heshi/'Num_huhang_jishi_heshi)
      .withColumn("Num_no_heshi_upgrade",'Num_no_heshi-'Alarm_relieve)


      .withColumn("Ratio_task_no_heshi_ontime_zy",'Num_task_no_heshi_ontime_zy/'Num_task_no_heshi_zy)
      .withColumn("Ratio_task_no_heshi_delay_zy",'Num_task_no_heshi_delay_zy/'Num_task_no_heshi_zy)
      .withColumn("Ratio_task_no_heshi_ontrip_zy",'Num_task_no_heshi_ontrip_zy/'Num_task_no_heshi_zy)
      .withColumn("Ratio_no_heshi_ontime_zy",'Num_task_no_heshi_ontime_zy/('Num_task_no_heshi_ontime_zy+'Num_task_no_heshi_delay_zy))
      .withColumn("Ratio_task_no_heshi_ontime_wb",'Num_task_no_heshi_ontime_wb/'Num_task_no_heshi_wb)
      .withColumn("Ratio_task_no_heshi_delay_wb",'Num_task_no_heshi_delay_wb/'Num_task_no_heshi_wb)


      .withColumn("Ratio_task_no_heshi_ontrip_wb",'Num_task_no_heshi_ontrip_wb/'Num_task_no_heshi_wb)
      .withColumn("Ratio_no_heshi_ontime_wb",'Num_task_no_heshi_ontime_wb/('Num_task_no_heshi_ontime_wb +'Num_task_no_heshi_delay_wb))
      .withColumn("Ratio_task_heshi_ontime_zy",'Num_task_heshi_ontime_zy/'Num_task_heshi_zy)
      .withColumn("Ratio_task_heshi_delay_zy",'num_task_heshi_delay_zy/'Num_task_heshi_zy)
      .withColumn("Ratio_task_heshi_ontrip_zy",'Num_task_heshi_ontrip_zy/'Num_task_heshi_zy)
      .withColumn("Ratio_heshi_ontime_zy",'Num_task_heshi_ontime_zy/('Num_task_heshi_ontime_zy+'Num_task_heshi_delay_zy))
      .withColumn("Ratio_task_heshi_ontime_wb",'Num_task_heshi_ontime_wb/'Num_task_heshi_wb)
      .withColumn("Ratio_task_heshi_delay_wb",'Num_task_heshi_delay_wb/'Num_task_heshi_wb)
      .withColumn("Ratio_task_heshi_ontrip_wb",'Num_task_heshi_ontrip_wb/'Num_task_heshi_wb)
      .withColumn("Ratio_heshi_ontime_wb",'Num_task_heshi_ontime_wb/('Num_task_heshi_ontime_wb+'Num_task_heshi_delay_wb))
      .withColumn("Num_heshi_ganyu_sub_fail_tm",'Num_heshi_ganyu_sub_fail_tm_sum/'Num_heshi_ganyu_sub_fail_tm_count)
      .withColumn("Num_heshi_ganyu_sub_success_tm",'Num_heshi_ganyu_sub_success_tm_sum/'Num_heshi_ganyu_sub_success_tm_count)



   var sourceDf5 = sourceDf4
     .select('Num_first_level_grd
     ,'Num_first_level_ft
     ,'Ratio_first_jieru
     ,'Num_first_level_ft_huhang
     ,'Num_huhang
     ,'Num_no_huhang
     ,'Ratio_huhang
     ,'Num_huhang_jishi_heshi
     ,'Num_no_huhang_jishi_heshi
     ,'Ratio_huhang_ontime
     ,'Num_heshi
     ,'ratio_heshi
     ,'Num_no_heshi
     ,'ratio_no_heshi
     ,'Num_phone_no
     ,'People_car_nomatch
     ,'Wrong_phone_number
     ,'Attitude_incompatibility
     ,'Alarm_relieve
     ,'Num_no_heshi_upgrade
     ,'Num_heshi_upgrade
     ,'Num_heshi_ganyu_sub
     ,'Num_heshi_ganyu_sub_success
     ,'Num_heshi_ganyu_sub_success_tm
     ,'Num_heshi_ganyu_sub_fail
     ,'Num_heshi_ganyu_sub_fail_tm
     ,'Num_task_no_heshi_zy
     ,'Num_task_no_heshi_ontime_zy
     ,'Ratio_task_no_heshi_ontime_zy
     ,'Num_task_no_heshi_delay_zy
     ,'Ratio_task_no_heshi_delay_zy
     ,'Num_task_no_heshi_ontrip_zy
     ,'Ratio_task_no_heshi_ontrip_zy
     ,'Ratio_no_heshi_ontime_zy
     ,'Num_task_no_heshi_wb
     ,'Num_task_no_heshi_ontime_wb
     ,'Ratio_task_no_heshi_ontime_wb
     ,'Num_task_no_heshi_delay_wb
     ,'Ratio_task_no_heshi_delay_wb
     ,'Num_task_no_heshi_ontrip_wb
     ,'Ratio_task_no_heshi_ontrip_wb
     ,'Ratio_no_heshi_ontime_wb
     ,'Num_task_heshi_zy
     ,'Num_task_heshi_ontime_zy
     ,'Ratio_task_heshi_ontime_zy
     ,'Num_task_heshi_delay_zy
     ,'Ratio_task_heshi_delay_zy
     ,'Num_task_heshi_ontrip_zy
     ,'Ratio_task_heshi_ontrip_zy
     ,'Ratio_heshi_ontime_zy
     ,'Num_task_heshi_wb
     ,'Num_task_heshi_ontime_wb
     ,'Ratio_task_heshi_ontime_wb
     ,'Num_task_heshi_delay_wb
     ,'Ratio_task_heshi_delay_wb
     ,'Num_task_heshi_ontrip_wb
     ,'Ratio_task_heshi_ontrip_wb
     ,'Ratio_heshi_ontime_wb
     ,'Inc_day)

    writeToHive(spark,sourceDf5,Seq("inc_day"), "dm_gis.total_zhibiao")
  }


  /***
    * @param spark
    * @param inc_day
    * @return
    */

  def  get_grd_ft_duiying_ite(spark :SparkSession, inc_day: String)= {
    val before3Day = DateUtil.getdaysBefore(inc_day,-4, "yyyyMMdd")
    val sql  =
      s"""
         |select
         | task_id	-- 	任务id
         |,now_level_create_tm	-- 	Grd当前等级创建时间
         |,abnormal_relieve_tm	-- 	Grd异常解除时间
         |,grd_ft_tm	-- 	关联上ft时间
         |,group_grd_tm	-- 	Task_id+”_”+Now_level_create_tm
         |,group_ft_tm	-- 	Task_id+”_”+Grd_ft_tm
         |,alarm_id	-- 	告警ID
         |,alarm_name	-- 	告警名称
         |,alarm_time	-- 	告警发生时间
         |,risk_level	-- 	风险级别 1-高危 2-中危 3-低危 4-无需处理
         |,source	-- 	告警来源：1 时效系统、2 导航、3 异常事件
         |,data_source	-- 	告警数据来源：1 时效系统、2 轨迹系统
         |,is_meddle	-- 	业务使用：0无需干预、1 需干预
         |,meddle_remark	-- 	是否干预备注
         |,handle_type	-- 	处理方式：1-人工处理 2-自动处理
         |,ptype	-- 	平台大类
         |,subtype	-- 	平台小类
         |,uid	-- 	请求唯一ID
         |,grd_task_id	-- 	grd任务ID
         |,grd_req_id	-- 	计划临时需求ID
         |,grd_std_id	-- 	标准线路编码
         |,grd_transoport_level	-- 	线路等级 1一级 2二级
         |,grd_solution	-- 	是否有挽救方案，1 时效挽救 2 线路挽救，0 没有
         |,grd_save_speed	-- 	挽救要求平均时速
         |,grd_task_save_state	-- 	任务是否可挽救状态 1计划到车时间挽救，10：运行时长挽救
         |,grd_plan_arrive_tm	-- 	计划到车时间(ms)
         |,grd_actual_depart_tm	-- 	实际发车时间(ms)
         |,grd_plan_run_tm	-- 	计划运行时长(分钟)
         |,grd_plan_dtime	-- 	计划晚点时长(分钟)
         |,grd_rt_dtime	-- 	运行晚点时长(分钟)
         |,grd_remain_dis	-- 	预计剩余里程 米
         |,grd_remain_time	-- 	预计剩余时长 S
         |,grd_arrival_tm	-- 	预计到达时间
         |,grd_count	-- 	第几次告警
         |,grd_src_citycode	-- 	源城市代码
         |,grd_dest_citycode	-- 	目的城市代码
         |,grd_carrier_type	-- 	承运商类型 0.自营 1.个体
         |,grd_child_carrier_name	-- 	承运商名称
         |,grd_src_zone_code	-- 	始发网点
         |,grd_dest_zone_code	-- 	目的网点
         |,grd_dest_zone_coordinate	-- 	终点网点坐标
         |,bd_car_no	-- 	车牌号码
         |,bd_driver_name	-- 	司机名称
         |,bd_driver_code	-- 	司机工号
         |,bd_driver_mobile	-- 	司机手机号码
         |,bd_sdriver_name	-- 	副司机名称
         |,bd_sdriver_code	-- 	副司机工号
         |,bd_sdriver_mobile	-- 	副司机电话号码
         |,bd_dept_code	-- 	部门编码
         |,bd_dept_name	-- 	部门名称
         |,ft_alarm_id	-- 	外部告警ID
         |,ft_ptype	-- 	基座大类
         |,ft_subtype	-- 	基座小类
         |,te_imei	-- 	设备IMEI号
         |,te_serial_no	-- 	告警序列号，部标查询附件用
         |,te_tts	-- 	发送设备端tts语音内容
         |,te_type	-- 	设备类型
         |,te_vedio_path	-- 	终端视频path路径
         |,lng	-- 	经度
         |,lat	-- 	维度
         |,tf_flag	-- 	审核正确错误标识 1 正确，2 错误
         |,tts_type	-- 	语音播报类型 1 导航播报、2 设备播报 0 未下发
         |,tts_no_reason	-- 	未播报原因 看字典
         |,def_end_type	-- 	护航结束原因，看字典
         |,def_end_desc	-- 	护航结束备注
         |,def_result	-- 	护航结果 1 护航成功，2 护航失败
         |,def_need_type	-- 	是否护航 0 不，1 是
         |,def_no_reason	-- 	无需护航原因 见字典
         |,def_status	-- 	护航状态 0: 无需 1：待处理；2：处理中；3：已处理
         |,def_emp_code	-- 	护航运营账号名称
         |,def_emp_id	-- 	护航运营账号ID
         |,def_duration_tm	-- 	护航时长分钟
         |,def_s_time	-- 	护航开始时间
         |,def_e_time	-- 	护航结束时间
         |,def_pf_sl_nl_fit	-- 	挽救线路与导航线路是否一致：0否，1是
         |,def_pf_saveline_type	-- 	车辆是否在挽救线路上：0 不在，1 在
         |,def_pf_cl_sl_fit	-- 	车辆轨迹是否到达挽救线路：0否，1是
         |,def_pf_phone_on	-- 	电话是否接通： 0未接通、1接通
         |,def_pf_phone_true	-- 	司机电话是否正确：0错误、1正确
         |,def_pf_dr_coo	-- 	司机是否配合：0不配合、1配合
         |,def_no_qualified_reason	-- 	不具备护航条件原因
         |,def_no_qualified_desc	-- 	不具备护航条件的备注
         |,def_qualified	-- 	是否具备护航条件 0: 不具备 1：具备
         |,def_pf_sup_type	-- 	前方是否具备加速条件：0不具备、1 具备
         |,def_mspeed_status	-- 	监控5分钟内速度是否达到要求(0开始监控，1有，2,没有)
         |,def_mspeed_result	-- 	5分钟内轨迹速度
         |,def_pf_sup_nr	-- 	前方不具备加速的原因 见字典
         |,def_stay_flag	-- 	当前停留所在地类型0：默认值，1：服务区/加油站
         |,def_abnormal_stay_time	-- 	服务区加油站累计异常停留时长，单位秒
         |,def_continue_tm	-- 	异常持续时长（异常结束时间-异常开始时间（单位：秒）
         |,navi_save_status	-- 	导航同步挽救结果：1 还原成功 2还原失败 3挽救线路拉取失败
         |,meddle_work_order_id	-- 	干预视频提取work_order_id
         |,create_time	-- 	创建日期
         |,update_time	-- 	更新日期
         |,te_speed	-- 	告警速度，设备iot告警
         |,average_speed	-- 	平均速度
         |,alarm_status	-- 	告警状态
         |,is_show	-- 	数据是否可见，默认0可见，1不可见
         |,grd_punctual	-- 	是否准点(0在途，1准点，2晚点)
         |,grd_actual_arrive_tm	-- 	实际到车时间
         |,alarm_work_order_id	-- 	告警视频提取order_id
         |,timeliness_state	-- 	GRD异常未到标签 0正常1预计晚到2异常未到
         |,timeout_state	-- 	超时未处理标签 0未超时，1超时
         |,grd_secure_state	-- 	RD主动解除标识 0异常，1解除,2失效，3降级
         |,def_active_time	-- 	主动开始护航时间
         |,def_non_result	-- 	无法护航小类:1,告警解除、2,告警失效、3，告警降级
         |,def_upgrade_mgr	-- 	是否需要升级到车管 0不升级，1升级
         |,def_already_upgrade_mgr	-- 	是否已升级到车管 0否，1是
         |,case when  def_respond_tm is null or length(trim(def_respond_tm))==0 then '0' else def_respond_tm end as def_respond_tm	-- 	响应时长
         |,def_handle_tm	-- 	处理时长
         |,meddle_resource_id	-- 	干预视频提取resourceId
         |,alarm_resource_id	-- 	告警视频提取resourceId
         |,def_upgrade_carrier	-- 	护航需升级承运商 0不升级，1升级
         |,vms_gps_time	-- 	异常开始时间（时间戳）
         |,vms_send_time	-- 	推送kafka时间（时间戳）
         |,vms_end_time	-- 	异常结束时间（时间戳）
         |,grd_start_update_tm	-- 	grd升级紧急异常时的时间
         |,def_con_phone	-- 	联系方式是否为电话：0不是 1是
         |,def_special_memo	-- 	特殊备注
         |,def_major_alarm	-- 	是否重大告警 0不是，1是
         |,def_major_reason	-- 	重大告警原因,见字典配置项
         |,def_major_reason_item	-- 	重大告警原因,见字典配置项1
         |,def_major_memo	-- 	重大告警备注
         |,def_objective_alarm	-- 	是否为客观原因 0，不是，1是
         |,def_task_alarm_state	-- 	任务告警状态：0未解除、1已解除、2任务已完成
         |,grd_plan_depart_tm	-- 	计划发车时间
         |,def_car_driver_mate	-- 	人与车是否匹配
         |,def_non_upgrade_reason	-- 	无需升级的原因
         |,def_carrier_upgrade_mgr	-- 	由承运商升级到车管 0否 1是
         |,big_type	-- 	大类
         |,small_type	-- 	小类
         |,end_cause	-- 	护航结束原因
         |,relieve_tm	-- 	护航解除时间（min）
         |,relieve_tm2	-- 	护航解除时间2（min）
         |,actual_run_time	-- 	实际运行时长
         |,line_time	-- 	计划运行时长
         |,delay_time	-- 	晚点时长
         |,actual_depart_tm	-- 	实际发车时间
         |,actual_arrive_tm	-- 	实际结束时间
         |,inc_day	-- 	统计时间
         |from
         |  dm_gis.grd_ft_duiying_item
         |where
         |  inc_day <= '${inc_day}'
         | and  inc_day >= '${before3Day}'
       """.stripMargin

    logger.error(sql)

    val  sourceDF  = spark.sql(sql)
    sourceDF.show(1)
    sourceDF

  }

}
