//package com.sf.gis.scala.scm.app.heavycargostatic.ls
//
//import com.sf.gis.scala.scm.utils.{HBaseUtils, SparkBuilder}
//import com.sf.gis.scala.scm.common.DataSourceCommon
//import org.apache.hadoop.hbase.client.Put
//import org.apache.hadoop.hbase.util.Bytes
//import org.apache.spark.sql.SparkSession
//
///**
//  * @description: 全国重货基础信息json初始化到hbase,一次性任务;  需求ID: 1720287 任务id
//  * @author 01420935 caiguofang
//  * @date 2023/04/10 10:36
//  */
//object InitBasicVehicleJsonFromFile extends DataSourceCommon{
//
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//  val hdfsPath="/user/01420395/upload"
//
//  //  val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
//  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
//  val zkPort = "2181"
//  val zkParent = "/hbase"
//
//
//  def main(args: Array[String]): Unit = {
//    val tbl_name = ""
//
//
//    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
//    //    val spark = SparkBuilder.localInitSpark(this.getClass.getSimpleName)
//
//    initVehicleBasic(spark,tbl_name)
//
//    spark.close()
//  }
//
//  /**
//    * spark 读取精友数据 初始化到hbase中
//    * @param sparkSession
//    * @param tbl_name
//    */
//  def initVehicleBasic(spark: SparkSession, tbl_name:String)={
//
//    val vehicleBasicPath= hdfsPath+"/insurance_vehicle_basics_json_original_0414.csv"
//
//    //    val vehicleBasicPath= "E:\\caiguofang\\GIS-RSS-SCM：【车险风险模型】全国重货静态信息查询接口及数据库_v1.0\\insurance_vehicle_basics_json_original_0414.csv"
//
//
//    val sourceDf = spark.read.format("csv")
//      .option("header", "true")
//      .option("delimiter", "\t").load(vehicleBasicPath)
//
//    sourceDf.show(1)
//
//    import spark.implicits._
//
//    val resultDF =  sourceDf
//      .select('id.cast("string").as("id")
//        , 'vin.cast("string").as("vin")
//        , 'json_str.cast("string").as("json_str")
//        , 'create_time.cast("string").as("create_time"))
//
//    resultDF.show(2)
//
//    //写入hbase
//    resultDF.foreachPartition( rows => {
//      val hbaseTblName = "gis:insurance_vehicle_json_original"
//      val hbaseTbl  = HBaseUtils.getHbaseTable(hbaseTblName,zkParent,zkQuorum,zkPort)
//      rows.foreach(row => {
//        val id  =  row.getAs[String]("id")
//        val vin = row.getAs[String]("vin")
//        val json_str = row.getAs[String]("json_str")
//        val create_time = row.getAs[String]("create_time")
//
//        val key = HBaseUtils.getKeyByStr(vin,20)
//
//        val put = new Put(Bytes.toBytes(key))
//
//        if(id != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("id"),Bytes.toBytes(id))
//        }
//        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("vin"),Bytes.toBytes(vin))
//
//        if(json_str != null){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("JY_json_str"),Bytes.toBytes(json_str))
//        }
//
//        if(create_time != null && !"".equalsIgnoreCase(create_time)){
//          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("create_time"),Bytes.toBytes(create_time))
//        }
//
//        try{
//          hbaseTbl.put(put)
//        }catch {
//          case e:Exception=> logger.error(key+","+row.toString())
//        }
//        hbaseTbl.flushCommits()
//
//      })
//      hbaseTbl.close()
//      logger.error("写入hbase 成功")
//    })
//  }
//
//}
