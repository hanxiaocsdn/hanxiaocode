package com.sf.gis.scala.scm.app.GIS_RSS_SCM

import common.DataSourceCommon
import org.apache.spark.storage.StorageLevel
import utils.{DateUtil, SparkUtil, SparkUtils, StringUtils}


/**
 * GIS-LSS-MMS：【时效护航项目】时效项目用户运营-任务维度明细表_V1.0
 *需求id 2214906
 *@author 01420395
 *@DESCRIPTION ${DESCRIPTION}
 *@create 20240122  蔡国房
 *
 * 任务id:
 */
object DwdOperationTaskDayDi  extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day  = args(0)

    start(inc_day)
  }


  def start(inc_day: String) ={

    val saprkSession  = SparkUtil.getSparkSession(appName)

    val biz_day = DateUtil.getdaysBefore(inc_day,0,"yyyyMMdd","yyyy-MM-dd")
    val inc_day_7 = DateUtil.getdaysBefore(inc_day,-6,"yyyyMMdd","yyyyMMdd")

    // 获取
    val grd_new_task_detail_sql=
      s"""
         |select distinct  date_format(t0.actual_arrive_tm, 'yyyy-MM-dd')  as actual_arrive_date
         |,t0.task_id
         |,t0.actual_depart_tm
         |,t0.actual_arrive_tm
         |,t0.actual_run_time
         |,t0.plan_run_time
         |,t0.late_time
         |,t0.vehicle_serial
         |,t0.task_area_code
         |,t0.carrier_name
         |,t0.origin_carrier_name
         |,t0.actual_carrier_name
         |,t0.driver_id
         |,t0.main_driver_account
         |,t0.driver_name
         |,t0.src_zone_code
         |,t0.dest_zone_code
         |,t0.src_city_name
         |,t0.dest_city_name
         |,t0.line_code
         |,t0.line_distance
         |,t0.is_stop
         |,t0.transport_level
         |,t0.require_category
         |,t0.carrier_type
         |,t0.vehicle_type
         |,t0.state
         |,t0.is_run_ontime
         |,t0.app_time_actual_distance
         |,t0.line_price
         |,t0.last_update_tm
         |,CASE WHEN car_no is NULL THEN 0 ELSE 1 END in_service
         |,CASE WHEN carplate is NULL THEN 0 ELSE 1 END imei
         |,field_bak26 vehicle_source
         |,capacity_reource_type capacity_reource_type
         |,CASE WHEN exception_type = '14' THEN '轨迹' when  exception_type = '6' THEN '时效' END  as exception_type
         |,CASE WHEN (handle_status = '0' OR handle_result = '4' OR handle_result = '7') THEN '不确定' WHEN handle_result in ('2','5','10','12') THEN '免责' ELSE '不免责' END  as exception_penalty
         |,CASE WHEN handle_status != '0' AND handle_result in ('2','5','10','12') AND handle_node in ('2','3') THEN '自动免责' WHEN handle_status != 0 AND handle_result in ('2','5','10','12') AND handle_node in ('0','1') THEN '审核免责' ELSE '' END  as exceptioni_penalty_labor_system
         |,max_continueTm max_continueTm
         |,IF(CAST(nvl(max_continueTm,0) AS INTEGER) >= 3600, 1,0) max_continueTm_1h
         |,regexp_replace(cast(format_number(IF(CAST(nvl(max_continueTm,0) AS INTEGER) >= 3600, line_price*0.05, 0),2) as string),',','') track_penalty_amount
         |,CASE WHEN t6.ac_is_run_ontime = 0 AND t7.task_label_final in ('未执行标准线路', '主观', '百分百主观') THEN '主观' WHEN t6.ac_is_run_ontime = 0 AND t7.task_label_final in ('客观情况1', '客观情况2') THEN '客观'  ELSE '不能判断' END  timing_penalty_responsibility
         |,responsibility_reason responsibility_reason_conduct
         |,responsibility_reason responsibility_reason_stay
         |,responsibility_reason responsibility_reason_service
         |,responsibility_reason responsibility_reason_jam
         |,responsibility_reason responsibility_reason_road
         |,emergent_need_deal_count
         |,emergent_deal_count
         |,emergent_timely_response_count
         |,regexp_replace(cast(format_number(emergent_response_tm_sum,2) as string),',','') emergent_response_tm_sum
         |,regexp_replace(cast(format_number(emergent_close_tm_sum,2) as string),',','') emergent_close_tm_sum
         |,emergent_success_count
         |,timing_need_deal_count
         |,timing_deal_count
         |,timing_timely_response_count
         |,regexp_replace(cast(format_number(timing_response_tm_sum,2) as string),',','') timing_response_tm_sum
         |,regexp_replace(cast(format_number(timing_close_tm_sum,2) as string),',','') timing_close_tm_sum
         |,timing_success_count
         |,timing_eliminate_count
         |,timing_neliminate_count
         |,track_need_deal_count
         |,track_deal_count
         |,track_timely_response_count
         |,regexp_replace(cast(format_number(track_response_tm_sum,2) as string),',','') track_response_tm_sum
         |,regexp_replace(cast(format_number(track_close_tm_sum,2) as string),',','') track_close_tm_sum
         |,track_success_count
         |,track_eliminate_count
         |,track_neliminate_count
         |,'' major_alarm_anomaly
         |,t5.exception_type exception_type_src
         |,handle_status handle_status
         |,handle_result handle_result
         |,handle_node handle_node
         |,task_label_final task_label_final
         |,t9.risk_level risk_level
         |,t9.def_need_type def_need_type
         |,t9.def_status as def_status
         |,t9.alarm_time as alarm_time
         |,t9.def_s_time as def_s_time
         |,t9.def_duration_tm as def_duration_tm
         |,t9.def_result as def_result
         |,t9.alarm_name as alarm_name
         |,t9.def_task_alarm_state as  def_task_alarm_state
         |,t9.def_major_alarm def_major_alarm
         |,max_starttime
         |,max_endtime
         |,is_timeliness_appraise
         |,src_province
         |,dest_province
         |,imei  as imei_x
         |,modify_tm
         |,${inc_day} inc_day
         |from (select inc_day,task_id ,actual_depart_tm ,plan_run_time,if(plan_run_time<actual_run_time, actual_run_time - plan_run_time, 0)  late_time,actual_arrive_tm ,
         |actual_run_time ,vehicle_serial ,task_area_code ,carrier_name ,origin_carrier_name ,actual_carrier_name ,driver_id ,main_driver_account ,driver_name ,src_zone_code ,
         |dest_zone_code ,src_city_name ,dest_city_name ,line_code ,line_distance ,is_stop ,transoport_level transport_level ,require_category ,carrier_type ,vehicle_type ,state ,
         |is_run_ontime ,app_time_actual_distance ,line_price ,last_update_tm, is_timeliness_appraise, src_province,dest_province from dm_grd.grd_new_task_detail where inc_day >='${inc_day_7}'
         |and  date_format(actual_arrive_tm, 'yyyy-MM-dd') = '${biz_day}') t0
         |left join (select car_no from  dm_gis_scm.dm_soc_alarm_filter_dtl_di where inc_day  = '${inc_day}' and  filter_type = '4' ) t1 on t0.vehicle_serial = t1.car_no
         |left join (select carplate,inc_day,imei from  dm_arss.dm_device_hh_dtl_di where inc_day  = '${inc_day}' and  deleteflag = 0 ) t2  on t0.vehicle_serial = t2.carplate
         |left join (select distinct  task_id, field_bak26 from  dm_tdsp.rpt_grd_task_monitor_re_dtl_di where inc_day   >='${inc_day_7}'  ) t3 on t0.task_id = t3.task_id
         |left join (select get_json_object(info, '$$.task_id') as task_id ,get_json_object(info, '$$.capacity_reource_type') as capacity_reource_type from  dm_gis.omcs_ground_task_flatmap where inc_day   >='${inc_day_7}'  ) t4 on  t0.task_id = t4.task_id
         |left join (select exception_type, handle_status, handle_result, handle_node,modify_tm,own_dept_code,task_id,CONCAT(CAST(own_dept_code AS String), CAST(task_id AS String)) as task_Join,rOW_NUMBER() over(partition by CONCAT(CAST(own_dept_code AS String), CAST(task_id AS String)), exception_type order by modify_tm desc) RowNum from  ods_shiva_ground.tt_task_exception_manage where inc_day   >='${inc_day_7}' and exception_type in ('6', '14')  ) t5 on  t0.task_id = t5.task_Join and  t5.RowNum=1
         |
         |left join (select ac_is_run_ontime,max_continueTm,task_id, max_starttime, max_endtime from  dm_gis.gis_vms_gta_track_miss_all where inc_day   ='${inc_day}'  ) t6 on  t0.task_id = t6.task_id
         |
         |left join (select get_json_object(info, '$$.task_label_final') as task_label_final,
         |get_json_object(info, '$$.responsibility_reason') as responsibility_reason,
         |get_json_object(info, '$$.task_id') as  task_id from  dm_gis.eta_std_line_recall_realtime2 where inc_day   ='${inc_day}'  ) t7 on  t0.task_id = t7.task_id
         |
         |left join (
         |select grd_task_id, SUM(CASE WHEN risk_level = '0' AND def_need_type = '1' AND def_status = '3' THEN 1 ELSE 0 END )as emergent_deal_count,
         |SUM(CASE WHEN risk_level = '0' AND def_need_type = '1' AND def_status = '3' AND def_s_time IS NOT NULL AND alarm_time IS NOT NULL AND alarm_time != '' AND def_s_time != '' AND abs(unix_timestamp(date_format(def_s_time, 'yyyy-MM-dd HH:mm:ss'))-unix_timestamp(date_format(alarm_time , 'yyyy-MM-dd HH:mm:ss')))/60 <= 30 THEN 1 ELSE 0 END) as emergent_timely_response_count,
         |SUM(CASE WHEN risk_level = '0' AND def_need_type = '1' AND def_status = '3' AND def_s_time IS NOT NULL AND alarm_time IS NOT NULL AND alarm_time != '' AND def_s_time != '' THEN abs(unix_timestamp(date_format(def_s_time, 'yyyy-MM-dd HH:mm:ss'))-unix_timestamp(date_format(alarm_time , 'yyyy-MM-dd HH:mm:ss')))/60 ELSE 0 END) as emergent_response_tm_sum,
         |SUM(CASE WHEN risk_level = '0' AND def_need_type = '1' AND def_status = '3' THEN CAST(def_duration_tm AS INT) ELSE 0 END) as emergent_close_tm_sum,
         |SUM(CASE WHEN risk_level = '0' AND def_need_type = '1' AND def_status = '3' AND def_result = '1' THEN 1 ELSE 0 END) as emergent_success_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('异常低速', '异常停车', '运行晚点预警') THEN 1 ELSE 0 END) as timing_need_deal_count,
         |SUM(CASE WHEN risk_level = '0' AND def_need_type = '1' THEN 1 ELSE 0 END) emergent_need_deal_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('异常低速', '异常停车', '运行晚点预警') AND def_status = '3' THEN 1 ELSE 0 END) as timing_deal_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('异常低速', '异常停车', '运行晚点预警') AND def_status = '3' AND def_s_time IS NOT NULL AND alarm_time IS NOT NULL AND alarm_time != '' AND def_s_time != '' AND abs(unix_timestamp(date_format(def_s_time, 'yyyy-MM-dd HH:mm:ss'))-unix_timestamp(date_format(alarm_time , 'yyyy-MM-dd HH:mm:ss')))/60 <= 30 THEN 1 ELSE 0 END) as timing_timely_response_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('异常低速', '异常停车', '运行晚点预警') AND def_status = '3' AND def_s_time IS NOT NULL AND alarm_time IS NOT NULL AND alarm_time != '' AND def_s_time != '' THEN abs(unix_timestamp(date_format(def_s_time, 'yyyy-MM-dd HH:mm:ss'))-unix_timestamp(date_format(alarm_time , 'yyyy-MM-dd HH:mm:ss')))/60 ELSE 0 END) as timing_response_tm_sum,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('异常低速', '异常停车', '运行晚点预警') AND def_status = '3' THEN CAST(def_duration_tm AS INT) ELSE 0 END) as timing_close_tm_sum,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('异常低速', '异常停车', '运行晚点预警') AND def_status = '3' AND def_result = '1' THEN 1 ELSE 0 END) as timing_success_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('异常低速', '异常停车', '运行晚点预警') AND def_status = '3' AND def_task_alarm_state = '1' THEN 1 ELSE 0 END) as timing_eliminate_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('异常低速', '异常停车', '运行晚点预警') AND def_status = '3' AND def_task_alarm_state = '0' THEN 1 ELSE 0 END) as timing_neliminate_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') THEN 1 ELSE 0 END) as track_need_deal_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') AND def_status = '3' THEN 1 ELSE 0 END) as track_deal_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') AND def_status = '3' AND def_s_time IS NOT NULL AND alarm_time IS NOT NULL AND alarm_time != '' AND def_s_time != '' AND abs(unix_timestamp(date_format(def_s_time, 'yyyy-MM-dd HH:mm:ss'))-unix_timestamp(date_format(alarm_time , 'yyyy-MM-dd HH:mm:ss')))/60 <= 30 THEN 1 ELSE 0 END) as track_timely_response_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') AND def_status = '3' AND def_s_time IS NOT NULL AND alarm_time IS NOT NULL AND alarm_time != '' AND def_s_time != '' THEN abs(unix_timestamp(date_format(def_s_time, 'yyyy-MM-dd HH:mm:ss'))-unix_timestamp(date_format(alarm_time , 'yyyy-MM-dd HH:mm:ss')))/60 ELSE 0 END) as track_response_tm_sum,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') AND def_status = '3' THEN CAST(def_duration_tm AS INT) ELSE 0 END) as track_close_tm_sum,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') AND def_status = '3' AND def_result = '1' THEN 1 ELSE 0 END) as track_success_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') AND def_status = '3' AND def_task_alarm_state = '1' THEN 1 ELSE 0 END) as track_eliminate_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') AND def_status = '3' AND def_task_alarm_state = '0' THEN 1 ELSE 0 END) as major_alarm_count,
         |SUM(CASE WHEN risk_level <>'0' AND def_need_type = '1' AND alarm_name in ('轨迹缺失') AND def_status = '3' AND def_task_alarm_state = '0' THEN 1 ELSE 0 END) as track_neliminate_count
         |from  dm_gis.soc_alarms where inc_day >= '${inc_day_7}'  group by grd_task_id ) t8 on  t0.task_id = t8.grd_task_id
         |left join (select distinct  grd_task_id, risk_level,def_need_type,alarm_time,def_status,def_s_time,
         |def_major_alarm,def_task_alarm_state,alarm_name, def_result, def_duration_tm
         |from  dm_gis.soc_alarms where inc_day   >= '${inc_day_7}'  ) t9 on  t8.grd_task_id = t9.grd_task_id
         |
         |order  by t0.task_id desc,modify_tm desc
         |""".stripMargin

    logger.error(grd_new_task_detail_sql)

    val resultDF = saprkSession.sql(grd_new_task_detail_sql).drop("modify_tm").distinct()

    resultDF.persist(StorageLevel.MEMORY_AND_DISK)

    import  saprkSession.implicits._

    //获取字段进行分组聚合
    val resultDF2  = resultDF.select('task_id ,
      'exception_type,
      'exception_penalty,
      'exceptioni_penalty_labor_system
    ).distinct()

    val resultdf3 = SparkUtils.getRowToJson(resultDF2).map(row  =>{
      (row.getString("task_id"), row)
    }).reduceByKey((x,y)=>{
      val exception_type =compareColum(x.getString("exception_type"),y.getString("exception_type"),",")
      val exception_penalty =compareColum(x.getString("exception_penalty"),y.getString("exception_penalty"),",")
      val exceptioni_penalty_labor_system =compareColum(x.getString("exceptioni_penalty_labor_system"),y.getString("exceptioni_penalty_labor_system"),",")
      val exception_type_src =compareColum(x.getString("exception_type_src"),y.getString("exception_type_src"),",")



      x.put("exception_type",exception_type)
      x.put("exception_penalty",exception_penalty)
      x.put("exceptioni_penalty_labor_system",exceptioni_penalty_labor_system)
      x.put("exception_type_src",exception_type_src)
      x
    }).map(row => {
      val x = row._2

      (x.getString("task_id")
        ,x.getString("exception_type")
        ,x.getString("exception_penalty")
        ,x.getString("exceptioni_penalty_labor_system")
        ,x.getString("exception_type_src"))
    }).toDF("task_id",
      "exception_type_1",
      "exception_penalty_1",
      "exceptioni_penalty_labor_system_1",
      "exception_type_src_1"
    ).distinct()


    //获取字段进行分组聚合
    val resultDF5  = resultDF.select('task_id
      ,'handle_status
      ,'handle_result
      ,'handle_node
      ,'task_label_final
      ,'risk_level
      ,'def_need_type
      ,'def_status
      ,'alarm_time
      ,'def_s_time
      ,'def_duration_tm
      ,'def_result
      ,'alarm_name
      ,'def_task_alarm_state
      ,'def_major_alarm
      ,'max_starttime
      ,'max_endtime
      ,'max_continuetm
      ,'is_timeliness_appraise
      ,'src_province
      ,'dest_province
    ).distinct()


    val resultdf6 = SparkUtils.getRowToJson(resultDF5).map(row  =>{
      (row.getString("task_id"), row)
    }).reduceByKey((x,y)=>{
      val  handle_status = compareColum2(x.getString("handle_status"),y.getString("handle_status"),"|")
      val  handle_result = compareColum2(x.getString("handle_result"),y.getString("handle_result"),"|")
      val  handle_node = compareColum2(x.getString("handle_node"),y.getString("handle_node"),"|")
      val  task_label_final = compareColum2(x.getString("task_label_final"),y.getString("task_label_final"),"|")
      val  risk_level = compareColum2(x.getString("risk_level"),y.getString("risk_level"),"|")
      val  def_need_type = compareColum2(x.getString("def_need_type"),y.getString("def_need_type"),"|")
      val  def_status = compareColum2(x.getString("def_status"),y.getString("def_status"),"|")
      val  alarm_time = compareColum2(x.getString("alarm_time"),y.getString("alarm_time"),"|")
      val  def_s_time = compareColum2(x.getString("def_s_time"),y.getString("def_s_time"),"|")
      val  def_duration_tm = compareColum2(x.getString("def_duration_tm"),y.getString("def_duration_tm"),"|")
      val  def_result = compareColum2(x.getString("def_result"),y.getString("def_result"),"|")
      val  alarm_name = compareColum2(x.getString("alarm_name"),y.getString("alarm_name"),"|")
      val  def_task_alarm_state = compareColum2(x.getString("def_task_alarm_state"),y.getString("def_task_alarm_state"),"|")
      val  def_major_alarm = compareColum2(x.getString("def_major_alarm"),y.getString("def_major_alarm"),"|")
      val  max_starttime = compareColum2(x.getString("max_starttime"),y.getString("max_starttime"),"|")
      val  max_endtime = compareColum2(x.getString("max_endtime"),y.getString("max_endtime"),"|")
      val  max_continuetm = compareColum2(x.getString("max_continuetm"),y.getString("max_continuetm"),"|")
      val  is_timeliness_appraise = compareColum2(x.getString("is_timeliness_appraise"),y.getString("is_timeliness_appraise"),"|")
      val  src_province = compareColum2(x.getString("src_province"),y.getString("src_province"),"|")
      val  dest_province = compareColum2(x.getString("dest_province"),y.getString("dest_province"),"|")

      x.put("handle_status",handle_status)
      x.put("handle_result",handle_result)
      x.put("handle_node",handle_node)
      x.put("task_label_final",task_label_final)
      x.put("risk_level",risk_level)
      x.put("def_need_type",def_need_type)
      x.put("def_status",def_status)
      x.put("alarm_time",alarm_time)
      x.put("def_s_time",def_s_time)
      x.put("def_duration_tm",def_duration_tm)
      x.put("def_result",def_result)
      x.put("alarm_name",alarm_name)
      x.put("def_task_alarm_state",def_task_alarm_state)
      x.put("def_major_alarm",def_major_alarm)
      x.put("max_starttime",max_starttime)
      x.put("max_endtime",max_endtime)
      x.put("max_continuetm",max_continuetm)
      x.put("is_timeliness_appraise",is_timeliness_appraise)
      x.put("src_province",src_province)
      x.put("dest_province",dest_province)

      x
    }).map(row => {
      val x = row._2

      (x.getString("task_id")
        ,x.getString("handle_status")
        ,x.getString("handle_result")
        ,x.getString("handle_node")
        ,x.getString("task_label_final")
        ,x.getString("risk_level")
        ,x.getString("def_need_type")
        ,x.getString("def_status")
        ,x.getString("alarm_time")
        ,x.getString("def_s_time")
        ,x.getString("def_duration_tm")
        ,x.getString("def_result")
        ,x.getString("alarm_name")
        ,x.getString("def_task_alarm_state")
        ,x.getString("def_major_alarm")
        ,x.getString("max_starttime")
        ,x.getString("max_endtime")
        ,x.getString("max_continuetm")
        ,x.getString("is_timeliness_appraise")
        ,x.getString("src_province")
        ,x.getString("dest_province")
      )
    }).toDF("task_id",
      "handle_status_1",
      "handle_result_1",
      "handle_node_1",
      "task_label_final_1",
      "risk_level_1",
      "def_need_type_1",
      "def_status_1",
      "alarm_time_1",
      "def_s_time_1",
      "def_duration_tm_1",
      "def_result_1",
      "alarm_name_1",
      "def_task_alarm_state_1",
      "def_major_alarm_1",
      "max_starttime_1",
      "max_endtime_1",
      "max_continuetm_1",
      "is_timeliness_appraise_1",
      "src_province_1",
      "dest_province_1"
    ).distinct()


    //获取有值的task_id
    val resultDF7  = resultDF.select('task_id,'def_major_alarm)
      .filter('def_major_alarm ==="1").distinct()
      .withColumn("def_major_alarm_2",'def_major_alarm)
      .drop("def_major_alarm")


    import org.apache.spark.sql.functions._

    val resultDF4 = resultDF.join(resultdf3, Seq("task_id"),"left")
      .join(resultdf6, Seq("task_id"),"left")
      .join(resultDF7, Seq("task_id"),"left")
      .withColumn("major_alarm_anomaly", when('def_major_alarm_2.isNotNull,'def_major_alarm_2).otherwise(lit("0")))
      .select('actual_arrive_date
        ,'task_id
        ,'actual_depart_tm
        ,'actual_arrive_tm
        ,'actual_run_time
        ,'plan_run_time
        ,'late_time
        ,'vehicle_serial
        ,'task_area_code
        ,'carrier_name
        ,'origin_carrier_name
        ,'actual_carrier_name
        ,'driver_id
        ,'main_driver_account
        ,'driver_name
        ,'src_zone_code
        ,'dest_zone_code
        ,'src_city_name
        ,'dest_city_name
        ,'line_code
        ,'line_distance
        ,'is_stop
        ,'transport_level
        ,'require_category
        ,'carrier_type
        ,'vehicle_type
        ,'state
        ,'is_run_ontime
        ,'app_time_actual_distance
        ,'line_price
        ,'last_update_tm
        ,'in_service
        ,'imei
        ,'vehicle_source
        ,'capacity_reource_type
        ,'exception_type_1.as("exception_type")
        ,'exception_penalty_1.as("exception_penalty")
        ,'exceptioni_penalty_labor_system_1.as("exceptioni_penalty_labor_system")
        ,'max_continueTm
        ,'max_continueTm_1h
        ,'track_penalty_amount
        ,'timing_penalty_responsibility
        ,'responsibility_reason_conduct
        ,'responsibility_reason_stay
        ,'responsibility_reason_service
        ,'responsibility_reason_jam
        ,'responsibility_reason_road
        ,'emergent_need_deal_count
        ,'emergent_deal_count
        ,'emergent_timely_response_count
        ,'emergent_response_tm_sum
        ,'emergent_close_tm_sum
        ,'emergent_success_count
        ,'timing_need_deal_count
        ,'timing_deal_count
        ,'timing_timely_response_count
        ,'timing_response_tm_sum
        ,'timing_close_tm_sum
        ,'timing_success_count
        ,'timing_eliminate_count
        ,'timing_neliminate_count
        ,'track_need_deal_count
        ,'track_deal_count
        ,'track_timely_response_count
        ,'track_response_tm_sum
        ,'track_close_tm_sum
        ,'track_success_count
        ,'track_eliminate_count
        ,'track_neliminate_count
        ,'major_alarm_anomaly
        ,'exception_type_src_1.as("exception_type_src")
        ,'handle_status_1.as("handle_status")
        ,'handle_result_1.as("handle_result")
        ,'handle_node_1.as("handle_node")
        ,'task_label_final_1.as("task_label_final")
        ,'risk_level_1.as("risk_level")
        ,'def_need_type_1.as("def_need_type")
        ,'def_status_1.as("def_status")
        ,'alarm_time_1.as("alarm_time")
        ,'def_s_time_1.as("def_s_time")
        ,'def_duration_tm_1.as("def_duration_tm")
        ,'def_result_1.as("def_result")
        ,'alarm_name_1.as("alarm_name")
        ,'def_task_alarm_state_1.as("def_task_alarm_state")
        ,'def_major_alarm_1.as("def_major_alarm")
        ,'max_starttime_1.as("max_starttime")
        ,'max_endtime_1.as("max_endtime")
        ,'is_timeliness_appraise_1.as("is_timeliness_appraise")
        ,'src_province_1.as("src_province")
        ,'dest_province_1.as("dest_province")
        ,'imei_x
        ,'inc_day).distinct()

    resultDF4.select("task_id","exception_type","exception_penalty", "exception_type_src","exceptioni_penalty_labor_system").show(1, false)

    writeToHive(saprkSession,resultDF4, Seq("inc_day"),"dm_gis.dwd_operation_task_day_di")

  }


  def compareColum (x:String,y:String,slipt:String)={
    var values =""
    if(StringUtils.isEmpty(x) && StringUtils.isEmpty(y)){
      values = ""
    }else if(StringUtils.isEmpty(x) && !StringUtils.isEmpty(y)){
      values =y
    }else if(!StringUtils.isEmpty(x) && StringUtils.isEmpty(y)){
      values=x
    }else if(!StringUtils.isEmpty(x) && !StringUtils.isEmpty(y)){
      values = x+slipt+y
    }
    values
  }



  def compareColum2 (x:String,y:String,slipt:String)={
    var values =""
    values = x+slipt+y
    values
  }
}
