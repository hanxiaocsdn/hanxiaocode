package com.sf.gis.scala.scm.app.GIS_RSS_SCM

import com.alibaba.fastjson.{JSON, JSONObject}
import common.DataSourceCommon
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.{SparkBuilder, SparkUtils}

import scala.collection.mutable.ArrayBuffer


/**
 *
 *@author 01420395
 * 任务id: 831556
 *@DESCRIPTION  GIS-RSS-SCM-PLAN：【时效安全托管服务运营报表】设备异常报表需求说明书_V1.0, 需求id 2110794 需求人: 01425432
 *@create 20231116
 */
object DeviceExceptionInfo  extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)

    val sql =
      s"""
      select inc_day data_day
      ,imei
      ,healthEType
      ,cameralist
      from  dm_gis.dm_dwd_device_day
      where inc_Day  = '${inc_day}' and length(cameralist)>0 and length(healthEType)>0
      """.stripMargin

    logger.error(sql)


    val sourceDF = spark.sql(sql)

    val  detailDF =   SparkUtils.getRowToJson(sourceDF).flatMap(row  =>{
      val cameralist =   row.getString("cameralist")
      val cameralistJSONArray  = JSON.parseArray(cameralist)

      val data_day  = row.getString("data_day")
      val imei  = row.getString("imei")
      val healthEType  = row.getString("healthEType")

      val array = new ArrayBuffer[Row]()

      for (index <- 0 until cameralistJSONArray.size()) {
        val cameralistJSON = cameralistJSONArray.getJSONObject(index)
        val position = cameralistJSON.getString("position")
        val type1 = cameralistJSON.getString("type")
        val event_time = cameralistJSON.getString("event_time")

        array.append(Row(data_day,imei,healthEType,position,type1,event_time,inc_day))
      }
      array
    })


    // 转成df
    val schame =StructType(
      List(
        StructField("data_day", StringType, true)
        ,StructField("imei", StringType, true)
        ,StructField("healthEType", StringType, true)
        ,StructField("position", StringType, true)
        ,StructField("type1", StringType, true)
        ,StructField("event_time", StringType, true)
        ,StructField("inc_day", StringType, true)
      )
    )

    val  resultDF =  spark.createDataFrame(detailDF, schame)

    resultDF.show( 1,false)

    writeToHive(spark, resultDF,Seq("inc_day"),"dm_gis.dm_dwd_device_day_temp")


  }

}

