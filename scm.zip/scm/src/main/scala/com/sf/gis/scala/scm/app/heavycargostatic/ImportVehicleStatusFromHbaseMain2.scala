//package com.sf.gis.scala.scm.app.heavycargostatic
//
//import java.util.Properties
//
////import com.sf.gis.java.base.util.HbaseUtil
//import com.sf.gis.scala.scm.utils.SparkBuilder
//import com.sf.gis.scala.scm.common.DataSourceCommon
//import org.apache.hadoop.conf.Configuration
//import org.apache.hadoop.hbase.HBaseConfiguration
//import org.apache.hadoop.hbase.mapreduce.TableInputFormat
//import org.apache.hadoop.hbase.util.Bytes
//import org.apache.spark.sql.SparkSession
///**
//  * @description: 同步到全国重货静态信息同步到hive表中;  需求ID: 1720287 任务id 722121
//  * @author 01420935 caiguofang
//  * @date 2023/04/10 10:36
//  */
//object ImportVehicleStatusFromHbaseMain2 extends DataSourceCommon {
//
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//  //切换集群
//  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
//  val zkQuorum2 = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
//
//  val zkPort = "2181"
//  val zkParent = "/hbase"
//
//
//  def main(args: Array[String]): Unit = {
//    val spark = SparkBuilder.localInitSpark(this.getClass.getSimpleName)
//    val hbaseConf  = HBaseConfiguration.create()
//    hbaseConf.set("zookeeper.znode.parent", zkParent)
//    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
//    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
//    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")
//
//    val pro  = new  Properties ()
//
//    pro.setProperty("hbase.zookeeper.quorum",zkQuorum)
//    pro.setProperty("hbase.zookeeper.property.clientPort",zkPort)
//    pro.setProperty("zookeeper.znode.parent",zkParent)
//
//    val hBaseTblName = "gis:gis_company_score"
//
//    HbaseUtil.setProperties(pro)
//    val table = HbaseUtil.getTable(hBaseTblName)
//    val result =  HbaseUtil.getByKey(table,"00_.嘉祥县隆源养殖场")
//
//
//    println(Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("company_name"))))
//
//    spark.close()
//  }
//
//
//
//
//  /**
//    * 导出计算的车辆基础信息
//    * @param spark
//    * @param hbaseConf
//    * @param broadcast
//    * @return
//    */
//  def exportBasicVehicle(spark: SparkSession, hbaseConf: Configuration)={
//
//    //获取不匹配车型数据
//    val hBaseTblName = "gis:gis_company_score"
//    hbaseConf.set(TableInputFormat.INPUT_TABLE, hBaseTblName)
//
//
//
//    //        System.out.println("");
//
//    //
//    //    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])
//    //
//    //    val vehicleBaseDf = hbaseTblRdd.map(row => {
//    //      val result = row._2
//    //      val rowKey  = Bytes.toString(result.getValue(Bytes.toBytes("info"), Bytes.toBytes("rowKey")))
//    //      val temList  = List(rowKey)
//    //      Row.fromSeq(temList)
//    //    })
//    //
//    //    // 转成df
//    //    val hBaseSchame =StructType(
//    //      List(
//    //        StructField("rowKey", StringType, true)
//    //      )
//    //    )
//    //    val vehicleDf =  spark.createDataFrame(vehicleBaseDf, hBaseSchame)
//    //
//    //    vehicleDf.show(10, false)
//    //    //    writeToHiveNoP(spark,vehicleDf,"dm_gis.insurance_vehicle_basics_original")
//
//  }
//
//}
