package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import common.DataSourceCommon
import org.apache.spark.sql.functions.{from_unixtime, lit, udf}
import utils.{DateUtil, SparkUtils}

/**
 * GIS-RSS-PNS：【实时交通】获取司机任务路况信息_数据侧_V1.0 2126905
 * 需求方：曹倩倩(01425168)
 *
 * @author 01420395
 *         任务ID：875549
 *         任务名称：获取司机任务路况信息
 */

object TaskDriverRoadConditions extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val tblName:String  ="dm_gis.Task_Driver_road_Conditions"

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    start(inc_day)
  }

  def start(inc_day: String): Unit = {

    val spark = SparkUtils.getSparkSession(appName, "yarn")
    spark.sparkContext.setLogLevel("ERROR")


    //获取文件linkID
    import spark.implicits._

    val dataFilePath = s"/user/01420395/upload/data/import/rtt_condition/link_time_${inc_day}.csv"
    val linkIdDF = spark.read.option("header", "true")
      .option("delimiter", "\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(dataFilePath)
      .toDF((Seq("link_id", "timestamp","dir" )): _*)
      .withColumn("tm_hive",from_unixtime( ('timestamp - 'timestamp%120), "yyyyMMddHHmmss") )
      .repartition(2000)


    linkIdDF.show(1, false)


    val linkIdFileBloomDF = linkIdDF.filter(row =>{
      val  link_id  = row.getAs[Long]("link_id")
      link_id != null
    }).stat.bloomFilter('link_id, 80000000, 0.05)

    val  udf_df_bloom =  udf((x: Long) => linkIdFileBloomDF.mightContainLong(x))


    val start_inc_day = DateUtil.getdaysBefore(inc_day,-5,"yyyyMMdd")


    //获取数据表格数据

    val resouceSql  = s"""
                |select rt_time_from,
                |link_id,
                |dir,
                |speed,
                |code,
                |travel_time,
                |detail,
                |inc_day from dm_gis.dm_etaroadkfk2hive_dtl
                |where inc_day>='${start_inc_day}' and  inc_day <= '${inc_day}'
                |and  link_id is not null
                          """
      .stripMargin
    logger.error(resouceSql)


    val resourceDF = spark.sql(resouceSql)
//      .toDF("tm_hive", "link_id", "dir", "speed", "code", "travel_time", "detail")
      .withColumn("tm_hive", 'rt_time_from)
      .withColumn("link_id", 'link_id )
      .withColumn("dir", 'dir -1)
      .withColumn("speed", 'speed)
      .withColumn("code", 'code)
      .withColumn("travel_time", 'travel_time)
      .withColumn("detail", 'detail)


    val rttData_bloom =  resourceDF.filter(udf_df_bloom('link_id))

    //进行数据关联
   val resultDF =  linkIdDF.join(rttData_bloom, Seq("tm_hive" , "link_id", "dir"),"left").na.fill(-1)
     .withColumn("inc_day",lit(inc_day))
      .select('tm_hive,'link_id,'dir,'timestamp.as("ts"),'speed,'code,'travel_time,'detail,'inc_day)


    resultDF.show(1,false)
    logger.error("数据量:" + resultDF.count())

    writeToHive(spark, resultDF,Seq("inc_day"), tblName)
    spark.sqlContext.clearCache()
    logger.error(println(inc_day + "：计算日期结束"))
    spark.close()

  }




}
