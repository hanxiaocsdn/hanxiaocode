package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;

public class HiveInfo {
    public String  uid = "";
    public String  destZoneCoordinate = "";
    public String  pickUpTm = "";  //"yyyy-MM-dd HH:mm:ss"格式
    public String  status = "";

    public HiveInfo(){

    }
}
