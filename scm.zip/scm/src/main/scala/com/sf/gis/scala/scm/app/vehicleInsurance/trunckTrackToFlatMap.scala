package com.sf.gis.scala.scm.app.vehicleInsurance

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import utils.{DateTimeUtil, SparkUtils}


/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION} 320w 外部车辆轨迹数据
 @create 2022/10/25 任务id 778109
*/


object trunckTrackToFlatMap {

  @transient lazy val logger: Logger = Logger.getLogger(trunckTrackToFlatMap.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class res(un:String,tp:String,zx:String,zy:String,ac:String,ad:String,be:String,sl:String,sp:String,
                 tm:String,bt:String,ak:String,dx:String,dy:String,state:String,pc:String)


  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val biz_day = args(1)
    logger.error(inc_day + "====" +  biz_day)
    start(inc_day,biz_day)


  }


  def getSourceData(spark: SparkSession, inc_day: String)  = {

    val before_one_day = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day,-5)

    val sourceSql =
      s"""
         |select
         |  info
         |from
         |  dm_gis.truck_track_info
         |where
         |  inc_day >='${before_one_day}'
         |  and inc_day <='${inc_day}'
         |  and length(trim(info))>0
       """.stripMargin

    logger.error("语句:" + sourceSql)

    val sourceDf = spark.sql(sourceSql)

    logger.error("数据量:" + sourceDf.count())

    sourceDf

  }


  def calEtaTracks(spark: SparkSession, inc_day: String, sourceRdd: DataFrame) = {

    import spark.implicits._

    val parseTracksRdd = sourceRdd.flatMap(x => {

      val info = x.getAs[String]("info")

      val infoArray = JSON.parseArray(info).toArray().map(d=>{
        val json = d.asInstanceOf[JSONObject]
        val un = json.getString("un")
        val tp = json.getString("tp")
        val zx = json.getString("zx")
        val zy = json.getString("zy")
        val ac = json.getString("ac")
        val ad = json.getString("ad")
        val be = json.getString("be")
        val sl = json.getString("sl")
        val sp = json.getString("sp")
        val tm = json.getString("tm")
        val bt = json.getString("bt")
        val ak = json.getString("ak")
        val dx = json.getString("dx")
        val dy = json.getString("dy")
        val state = json.getString("state")
        val pc = json.getString("pc")

        res(un,tp,zx,zy,ac,ad,be,sl,sp,tm,bt,ak,dx,dy,state,pc)

      })

      infoArray

    }).toDF("un","tp","zx","zy","ac","ad","be","sl","sp","tm","bt","ak","dx","dy","state","pc")

    parseTracksRdd
  }




  def saveToTrackTable(spark: SparkSession, inc_day: String, parseTracksRdd: DataFrame) = {

    import org.apache.spark.sql.functions._
    import spark.implicits._
   val  rdd  =  parseTracksRdd.repartition(1000).toDF()
      .withColumn("inc_day",from_unixtime('tm.cast("long"),"yyyyMMdd"))

    rdd.select('inc_day).distinct().show(10 )


    val result  = rdd.filter('inc_day === inc_day)
    result.show(1, false)

    result.write
      .mode(SaveMode.Overwrite).insertInto("dm_gis.truck_track_info_flatmap")

  }



  def staStat(spark: SparkSession, inc_day: String, biz_day:String): Unit = {

    // TODO: 获取数据
    val sourceRdd = getSourceData(spark, inc_day)

    // TODO: 调用接口返回
    val parseTracksRdd = calEtaTracks(spark, inc_day, sourceRdd)

    // TODO: 存储轨迹中间表

    logger.error("数据量: " + parseTracksRdd.count())
    saveToTrackTable(spark, biz_day, parseTracksRdd)

  }


  def start(inc_day: String,biz_day:String): Unit = {

    val spark = SparkUtils.getSparkSession(appName, "yarn")

    spark.sparkContext.setLogLevel("ERROR")
    //    val dataList = DateTimeUtil.getDateInterval("20230816", "20230816", "yyyyMMdd", "yyyyMMdd")
    //    for (incDay <- dataList) {
    //    val incDay = inc_day
    //    val incDay = DateTimeUtil.getCurDayYesterDay()
    //    val incDay = inc_day
    logger.error(println("当前计算日期为：" + biz_day))
    staStat(spark, inc_day,biz_day)

    SparkUtils.clearCache(spark)
    spark.sqlContext.clearCache()

    val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
    ds.foreach(x => {
      x._2.unpersist()
    })
    logger.error(println(inc_day + "：计算日期结束"))
    //    }

    logger.error("统计完成")
  }


}