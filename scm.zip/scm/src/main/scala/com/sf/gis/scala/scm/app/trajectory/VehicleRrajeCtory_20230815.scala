package com.sf.gis.scala.scm.app.trajectory

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.pathSimilar.PathSimilar
import common.DataSourceCommon
import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel
import utils.{DateUtil, SparkBuilder, SparkUtils, StringUtils}

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks._

/**
@author 01420395
@DESCRIPTION
轨迹缺失表 需求ID 1823186   GIS-RSS-ETA-STD-LINE:【时长规划决策】司机实际轨迹汇总表_V1.0 任务id 763977
  任务依赖：371318
@create 2023/06/02
  */
object VehicleRrajeCtory_20230815   extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {

    val inc_day  = args(0)
    //获取前30天
    val beforeDay =DateUtil.getdaysBefore(inc_day,-30,"yyyyMMdd")
    val sparkSession = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sql =
      s"""
         |select * from (
         |select
         |task_id,
         |actual_depart_tm,
         |actual_arrive_tm,
         |task_subid,
         |line_code,
         |case when  start_type = '2'  then start_dept
         |when  start_type = '1' and start_outer_add_code is not null then start_outer_add_code
         |when  start_type = '1' and start_outer_add_code is  null then 'start_dept' end as start_dept ,
         |case when end_type  = '2' then end_dept
         |when  end_type = '1' and end_outer_add_code is not null then end_outer_add_code
         |when  end_type = '1' and end_outer_add_code is  null then 'end_dept'  end as end_dept,
         |vehicle_type,
         |carrier_type,
         |rt_coords,
         |halfway_integrate_rate,
         |accrual_dist,
         |carrier_name,
         |std_id,
         |navi_complete_rate,
         |0 as num_order,
         |from_unixtime(cast(last_update_tm as bigint),"yyyy-MM-dd HH:mm:ss") as last_update_tm
         |from dm_gis.eta_std_line_recall
         |where inc_day  between '${beforeDay}' and  '${inc_day}'
         |and error_type = 0 and  conduct_type=3
         |)t
      """.stripMargin
    //    and line_code  = '010CAJ010WB1900' and start_dept = '010CAJ' and end_dept = '010WB' and vehicle_type = '6' limit 2

    logger.error(sql)
    val sourceDF = sparkSession.sql(sql)

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val windoRn  = Window.partitionBy("task_subid").orderBy(desc("last_update_tm"))
    val rn_sourceDF =  sourceDF.filter( 'end_dept =!="end_dept" )
      .filter( 'start_dept =!="start_dept" )
      .withColumn("rn",row_number()over(windoRn))

    val listSourceDf = rn_sourceDF.where('rn === 1).repartition(500)
    val sourceJson  = SparkUtils.getRowToJson(listSourceDf)
    logger.error(sourceJson.count())


    val resultJson  =   sourceJson.map(rowJson  =>  {
      val line_code  =  rowJson.getString("line_code")
      val start_dept  =  rowJson.getString("start_dept")
      val end_dept  =  rowJson.getString("end_dept")
      val vehicle_type  =  rowJson.getString("vehicle_type")

      rowJson.put("grp1",line_code+"_"+start_dept+"_"+end_dept+"_"+vehicle_type)
      (line_code+"||"+start_dept+"||"+end_dept+"||"+vehicle_type,rowJson)

    }).groupByKey().map(row => {
      // 按key打grp
      val rowJson  = row._2.toArray[JSONObject]
      val arr2: ArrayBuffer[JSONObject] = groupRoute2(rowJson)
      arr2
    }).flatMap(row => row.iterator.toSeq).repartition(500)
      .map(row =>  {
      Row(row.getString("line_code"),
        row.getString("start_dept"),
        row.getString("end_dept"),
        row.getString("vehicle_type"),
        row.getString("carrier_name"),
        row.getString("rt_coords"),
        row.getString("std_id"),
        row.getString("grp2"),
        row.getString("sim1"),
        row.getString("actual_depart_tm"),
        row.getString("actual_arrive_tm"),
        row.getString("task_id"),
        row.getString("halfway_integrate_rate") ,
        row.getInteger("num_order")
      )
    }).map(row  => (row.getString(0),row.getString(1),row.getString(2),row.getString(3),row.getString(4),row.getString(5),
      row.getString(6),row.getString(7),row.getString(8),row.getString(9),row.getString(10),row.getString(11),row.getString(12), row.getInt(13)
    ))

    val resultDf1 = sparkSession.createDataFrame(resultJson)
      .toDF("line_code","start_dept","end_dept","vehicle_type","carrier_name","rt_coords","std_id","grp2","sim1"
        ,"actual_depart_tm" ,"actual_arrive_tm" ,"task_id","halfway_integrate_rate","num_order")

    logger.error("数据量1: " + resultDf1.count())

    resultDf1.persist(StorageLevel.MEMORY_AND_DISK)


    //判断两条轨迹的完整率和轨迹点的之间距离 需求迭代 1932888  司机实际轨迹汇总表_V1.1
    val  max_halfway_integrate_rate_df =  resultDf1.withColumn("max_halfway_integrate_rate_rn",
      row_number()over(Window.partitionBy("grp2").orderBy(desc("halfway_integrate_rate"))))
        .filter('max_halfway_integrate_rate_rn ===1)
      .select('grp2,'max_halfway_integrate_rate_rn,'rt_coords.as("max_rt_coords"))

    logger.error("数据量2: " + max_halfway_integrate_rate_df.count())


   val  resultDf7 = resultDf1
      .join(max_halfway_integrate_rate_df,Seq("grp2"),"left")
      .withColumn("rt_coords",'max_rt_coords)
       .distinct()

    logger.error("数据量3: " + resultDf7.count())
    resultDf7.persist(StorageLevel.MEMORY_AND_DISK)


    val window = Window.partitionBy("line_code", "start_dept" , "end_dept","vehicle_type","carrier_name","grp2")
    //
    import org.apache.spark.sql.functions._

    val resultDf2= resultDf7.repartition(500).withColumn("Count",count(lit(1)).over(window))
      .withColumn("task_id", concat_ws("|",collect_list("task_id")over(window).orderBy(desc("num_order"))))
      .select("line_code","start_dept","end_dept","vehicle_type","carrier_name","std_id","rt_coords","Count","task_id","actual_depart_tm",
        "actual_arrive_tm","grp2").distinct()

    val resultDf3 = resultDf2.withColumn("id",md5('rt_coords))
      .withColumn("inc_day",lit(inc_day))

    val resultDf4 = resultDf3
      .select("line_code","start_dept","end_dept","vehicle_type","carrier_name","id","std_id","rt_coords","Count",
        "task_id","actual_depart_tm",
        "actual_arrive_tm", "inc_day")
    logger.error(resultDf4.count())

    writeToHive(sparkSession,resultDf4,Seq("inc_day"),"dm_gis.Actual_vehicle_trajectory")

  }


  // 按key打grp
  def groupRoute2(arr: Array[JSONObject]): ArrayBuffer[JSONObject] = {

    val ret_arr = new ArrayBuffer[JSONObject]()
    val groupArray2 = new ArrayBuffer[JSONObject]()
    var grp2_cnt = 0
    var sim1 = -99.0

    for (o <- arr) {
      var tag2: Int = 0
      if (grp2_cnt == 0) {
        grp2_cnt = grp2_cnt + 1
        o.put("grp2", o.getString("grp1") + "_" + grp2_cnt)
        o.put("sim1",sim1)
        val arr_tmp = new JSONObject()
        arr_tmp.put("rt_coords",o.getString("rt_coords"))
        arr_tmp.put("halfway_integrate_rate",o.getString("halfway_integrate_rate"))
        arr_tmp.put("grp2",o.getString("grp2"))
        arr_tmp.put("actual_depart_tm",o.getString("actual_depart_tm"))
        arr_tmp.put("actual_arrive_tm",o.getString("actual_arrive_tm"))
        arr_tmp.put("num_order",1)

        groupArray2.append(arr_tmp)
      } else {
        breakable {
          for (array2 <- groupArray2) {
            val rt_coords: String = o.getString("rt_coords")
            val rt_coords2: String = array2.getString("rt_coords")

            val actual_depart_tm: String = array2.getString("actual_depart_tm")
            val actual_arrive_tm: String = array2.getString("actual_arrive_tm")

            if (!isEmptyOrNull(rt_coords) && rt_coords.length > 3 && !isEmptyOrNull(rt_coords2) && rt_coords2.length > 3) {
              // 缩短轨迹点
              val obj_1 = new JSONObject()
              val obj_2 = new JSONObject()

              obj_1.put("rt_coords",rt_coords)
              obj_2.put("rt_coords",rt_coords2)
              logger.error("相似度对比中...")
              // 调用jar包计算相似度
              val simil = PathSimilar.simProcess(obj_1, obj_2)

              // 调线上接口计算相似度
              sim1 = simil.first
              logger.error("sim1:"+sim1)
              if (sim1 >= 0.9) {
                val grp2: String = array2.getString("grp2")
                o.put("grp2", grp2)
                o.put("sim1", sim1)
                val halfway_integrate_rate2 = array2.getString("halfway_integrate_rate")
//                val rt_coords_new = getRtCoords(o,array2)
//                o.put("rt_coords", rt_coords_new)
                o.put("rt_coords", rt_coords2)
                o.put("halfway_integrate_rate", halfway_integrate_rate2)
                o.put("actual_depart_tm", actual_depart_tm)
                o.put("actual_arrive_tm", actual_arrive_tm)
                tag2 = 1
                break()
              }
            }
          }

          if (tag2 == 0) {
            grp2_cnt = grp2_cnt + 1
            o.put("grp2", o.getString("grp1") + "_" + grp2_cnt)
            o.put("sim1",sim1)
            val arr_tmp = new JSONObject()

            arr_tmp.put("rt_coords",o.getString("rt_coords"))
            arr_tmp.put("grp2",o.getString("grp2"))
            arr_tmp.put("halfway_integrate_rate",o.getString("halfway_integrate_rate"))
            arr_tmp.put("actual_depart_tm", o.getString("actual_depart_tm"))
            arr_tmp.put("actual_arrive_tm", o.getString("actual_arrive_tm"))
            arr_tmp.put("num_order",1)
            groupArray2.append(arr_tmp)
          }
        }

      }
      ret_arr.append(o)
    }
    ret_arr
  }


  //获取对应的轨迹点信息
  def getRtCoords(o1:JSONObject,o2:JSONObject):String={

    val halfway_integrate_rate1 =o1.getString("halfway_integrate_rate")
    val halfway_integrate_rate2 =o2.getString("halfway_integrate_rate")

    val rt_coords1 =o1.getString("rt_coords")

    val rt_coords2 =o2.getString("rt_coords")
    var rt_coords_return = ""

    if(halfway_integrate_rate1.toDouble > halfway_integrate_rate2.toDouble) {
      rt_coords_return = rt_coords2
    }else{
      rt_coords_return = rt_coords1
    }

  rt_coords_return
}



def isEmptyOrNull(input:String):Boolean={
  if(StringUtils.isEmpty(input)){
  true
}else{
  false
}
}

}
