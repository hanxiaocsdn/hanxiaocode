package com.sf.gis.scala.scm.app.GIS_RSS_SCM

import common.DataSourceCommon
import utils.{DateUtil, SparkBuilder}


/**
  * GIS_RSS_SCM：【北京违章扣罚】北京区违章信息获取的线上化_V1.0, 需求id 2017326
  *
  *@author 01420395 任务id: 826926
  *@DESCRIPTION ${DESCRIPTION}
  *@create 20230918
  */
object ImportbjWeiZhangToHive1   extends DataSourceCommon{

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
//    val spark = SparkBuilder.localInitSpark(this.getClass.getSimpleName)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)

    val tableName = "dm_gis.t_bj_car_illegal_detail"
    val cols = Seq("id","wfms","fkje","wfjfs","wfzt","xh","hpzl","hphm","fzjg","wfdz","wfxw","clbj","jkbj","cjjg","cjjgmc",
      "fsjg","jsjg","gxsj","dcbj","wfsj","clsj","clbjStr","jkbjStr","cljg","cljgmc","cljg1","cljg2","wrapStr","wrapCljg",
      "hpzlStr","fzjgStr","sfjf","sfcl","photos","wfxcsq","sfyss","scz","bzz","swjgbj","glbm","jdsbh","input_hphm",
      "input_hpzl","input_xh","input_cjjg","task_name","ss"
    )
    import org.apache.spark.sql.functions._
    import spark.implicits._
//    val fileName = s"qb_BJ122_${inc_day}.zip"
//    val inputPath = s"/user/01420395/upload/FT20230019/2017326/${inc_day}/${fileName}"
//    val inputPath = "E:\\caiguofang\\封路场景&挽救线路准点率指标监控需求说明书/bj122-详情数据.csv"

//    logger.error(inputPath)
//
//    val zipFile= new ZipFile(inputPath,"bj122".toCharArray)
////    zipFile.extractFile("INFS_SITES_ADDR_BJ122_D.csv",s"/user/01420395/upload/FT20230019/2017326/${inc_day}")
//    zipFile.extractAll(s"/user/01420395/upload/FT20230019/2017326/${inc_day}/csv")

    val dataFilePath = s"/user/01420395/upload/FT20230019/2017326/${inc_day}/csv/INFS_SITES_ADDR_BJ122_D.csv"
    val vehicle_df = spark.read.option("header", "false")
      .option("delimiter", ",")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(dataFilePath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*)
      .withColumn("seq_id",lit(""))
      .withColumn("guid",lit(""))
      .withColumn("adcode",lit(""))
      .withColumn("city",lit(""))
      .withColumn("batch_id",lit(""))
      .withColumn("indate",lit(""))
      .withColumn("pg_indate",lit(""))
      .withColumn("info",lit(""))
      .withColumn("etl_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
      .withColumn("inc_day",lit(inc_day))



    val resultRdd = vehicle_df
      .select(
        'id
      ,'seq_id
      ,'wfms
      ,'fkje
      ,'wfjfs
      ,'wfzt
      ,'xh
      ,'hpzl
      ,'hphm
      ,'fzjg
      ,'wfdz
      ,'wfxw
      ,'guid
      ,'clbj
      ,'jkbj
      ,'cjjg
      ,'cjjgmc
      ,'fsjg
      ,'jsjg
      ,'gxsj
      ,'dcbj
      ,'wfsj
      ,'clsj
      ,'city
      ,'clbjstr
      ,'jkbjstr
      ,'cljg
      ,'cljgmc
      ,'cljg1
      ,'cljg2
      ,'wrapstr
      ,'wrapcljg
      ,'hpzlstr
      ,'fzjgstr
      ,'adcode
      ,'sfjf
      ,'sfcl
      ,'photos
      ,'wfxcsq
      ,'sfyss
      ,'scz
      ,'bzz
      ,'swjgbj
      ,'jdsbh
      ,'glbm
      ,'ss
      ,'input_hphm
      ,'input_hpzl
      ,'input_xh
      ,'input_cjjg
      ,'task_name
      ,'batch_id
      ,'indate
      ,'pg_indate
      ,'info
      ,'etl_time
      ,'inc_day
    )
    resultRdd.select('id).show(1,false)
    writeToHive(spark, resultRdd, Seq("inc_day"), tableName)
  }

}

