package com.sf.gis.scala.scm.app.vehicleInsurance

import com.alibaba.fastjson.JSON
import com.sf.gis.scala.base.util.HttpUtils
import org.apache.log4j.Logger

import scala.util.control.Breaks


/**
  * 接口获取对应的数据传输结束标识
  *
  *@author 01420395
  *@DESCRIPTION ${DESCRIPTION}
  *@create 20230420
  */
object ApplVehicleInsuranceFromHive {

  @transient lazy val logger: Logger = Logger.getLogger(ApplVehicleInsuranceFromHive.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val vehicleUrl = "http://gis-issp-gw.sf-express.com/transform/queryFinish?time=%s&dataType=car-stat"
//val vehicleUrl = "http://gis-issp-gw.sit.sf-express.com/transform//queryFinish?time=%s&dataType=car-stat"


  def main(args: Array[String]): Unit = {

    val inc_day  = args(0)
    Breaks.breakable(while(true){
    val responseJSONP =  HttpUtils.urlConnectionGetJson(String.format(vehicleUrl,inc_day),1000)
      if(responseJSONP!=null){
        val json  = JSON.parseObject(responseJSONP.getString("result"))
        logger.error(json)
        val readStatus  = json.getString("isFinish")
        if(!"-1".equalsIgnoreCase(readStatus)){
          Thread.sleep(12*60*1000)
          logger.error(vehicleUrl + "数据完成.......")
          println(vehicleUrl + "数据完成.......")
          //等待10+2分钟, 等待flink数据消费完毕; 参考flink任务消费kafka间隔
          Breaks.break()
        }
        println(vehicleUrl + "数据暂未完成.......")
        logger.error(vehicleUrl + "数据暂未完成.......")
        Thread.sleep(6000)
      }
    })
  }
}
