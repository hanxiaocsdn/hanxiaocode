package com.sf.gis.scala.scm.app.GIS_RSS_ETA.feature;
import com.sf.map.PointVector;
public class QmAbout {
    public  String data_build_time;
    public  String service_build_time;
    public QmAbout()
    {
        data_build_time = new String();
        service_build_time = new String();
    }
}
