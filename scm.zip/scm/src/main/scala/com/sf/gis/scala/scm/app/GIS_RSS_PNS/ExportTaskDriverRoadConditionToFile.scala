package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import com.sf.gis.scala.scm.app.etastdlinerecallvms.ExportEtastdlinerecallvmFromHive.hdfsFileReName
import common.DataSourceCommon
import utils.SparkBuilder


/**
  *@author 01420395
  *@DESCRIPTION
  *轨迹缺失表 需求ID 1971281    GIS-RSS-PNS：【路径规划】司机实走标准路线每日下载需求说明书_V1.0
  *任务id : 795308   任务依赖：  371318
  *@create 2023/08/28
  */
object ExportTaskDriverRoadConditionToFile  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)

    logger.error("日期 : " +  inc_day)
    start(inc_day)

  }


  def start(inc_day: String) = {
    val sourceSql =
      s"""
         select  * from  dm_gis.Task_Driver_road_Conditions  where inc_day='${inc_day}'
       """.stripMargin


    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sourceRdd = spark.sql(sourceSql)

    logger.error("数据量 : " +  sourceRdd.count() )

    val hdfsPath = "/user/01420395/upload/data/export/Task_Driver_road_Conditions"

    val outPath = hdfsPath + "/" + inc_day + "/dm_gis.Task_Driver_road_Conditions/"




    sourceRdd.coalesce(1).write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", "\t")
      .csv(outPath)

    hdfsFileReName(spark, outPath, "Task_Driver_road_Conditions_" + inc_day.substring(4,8) + ".csv")

  }

}