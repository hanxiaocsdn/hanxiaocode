package com.sf.gis.scala.scm.app.trajectory

import common.DataSourceCommon
import org.apache.spark.storage.StorageLevel
import utils.SparkBuilder

/**
  @author 01420395
  @DESCRIPTION GIS-RSS-SCM：【陆运油耗管控报表】陆运油耗管数据报表需求_V1.0 需求id 1948035 任务id:
  车辆任务超速明细数据: 1.  获取表 dm_gis.eta_std_line_recall  where  carrier_type=0 数据
               2. 调用接口获取轨迹点信息
               3. 根据车辆吨位判断对应速度是否超速,
  任务id 794648
  任务依赖：  794860
  @create 2023/08/16
  */
object VehicleTaskControlDetail  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    val inc_day  = args(0)
    //获取前30天
    val sparkSession = SparkBuilder.initSpark(this.getClass.getSimpleName)


    //获取超速信息
    val speedingSql   =
      s"""
         |select
         |duration_overspeed_s speeding_times_s , --超速时长
         |duration_overspeed_min speeding_times_m , --超速时长
         |avg_sp,  -- 平均速度
         |overspeed_mileage speeding_dist,  -- 超速里程
         |task_id ,
         |task_subid,
         |over_sp_road_class as road_class --高速
         |from  dm_gis.vehicle_task_speeding_detail
         |where inc_day  = '${inc_day}'
         |
      """.stripMargin

    val  speedingRdd = sparkSession.sql(speedingSql)

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._


    val speedingGroupRdd  = speedingRdd.groupBy('task_id).agg(
      sum('speeding_times_s).as("speeding_times_s") ,
      sum('speeding_times_m).as("speeding_times_m") ,
      sum('speeding_dist).as("speeding_dist"),
      avg('avg_sp).as("speed_avg_sp")
    )

    logger.error("数据量 speedingGroupRdd:  " + speedingGroupRdd.count())


    val highSpeedingGroupRdd  = speedingRdd
      .filter('road_class === "0")
      .groupBy('task_id).agg(
      sum('speeding_times_s).as("high_speeding_times_s") ,
      sum('speeding_times_m).as("high_speeding_times_m") ,
      sum('speeding_dist).as("high_speeding_dist")
    )
    logger.error("数据量 highSpeedingGroupRdd:  " + highSpeedingGroupRdd.count())

    //获取怠速信息
    val stopSql  =
      s"""
         |select
         |stop_rm_tm_s stop_times_s , --怠速时长
         |stop_rm_tm_min stop_times_m , --怠速时长
         |task_id ,
         |task_subid,
         |road_class
         |from  dm_gis.vehicle_task_stopping_detail where inc_day  = '${inc_day}'
         |
      """.stripMargin


    val  stopRdd = sparkSession.sql(stopSql)

    val stopGroupRdd  = stopRdd.groupBy('task_id)
      .agg(
        sum('stop_times_s).as("stop_times_s") ,
        sum('stop_times_m).as("stop_times_m")
      )

    logger.error("数据量 stopGroupRdd:  " + stopGroupRdd.count())


    val highstopRdd  = stopRdd
      .filter('road_class === "0")
      .groupBy('task_id).agg(
      sum('stop_times_s).as("high_stop_times_s") ,
      sum('stop_times_m).as("high_stop_times_m")
    )

    logger.error("数据量 highstopRdd:  " + highstopRdd.count())

//    sparkSession.sql(s"""create table dm_gis.dm_device_hh_dtl_di_temp  as  select  * from  dm_arss.dm_device_hh_dtl_di where inc_day = '${inc_day}'""")
//    sparkSession.sql(s"""create table dm_gis.tm_vms_vehicle_temp  as  select  * from  ods_vms.tm_vms_vehicle where inc_day = '${inc_day}'""")
//    sparkSession.sql(s"""create table dm_gis.dim_dept_info_df_temp  as  select  * from  dim.dim_dept_info_df where inc_day = '${inc_day}'""")


    val sql =s"""
         select  task_id
          ,task_subid
          ,vehicle_serial
          ,actual_capacity_load
          ,zytype
          ,area_code
          ,area_name
          ,driver_id
          ,driver_name
          ,plan_depart_tm
          ,actual_depart_tm
          ,plan_arrive_tm
          ,actual_arrive_tm
          ,line_distance
          ,rt_dist
          ,high_way_mileage
          ,nohigh_way_mileage
          ,line_time line_time_min
          ,line_time*60 line_time_s
          ,actual_run_time
          ,actual_run_time actual_run_time_min
          ,actual_run_time*60 actual_run_time_s
          ,early_arrival_time as early_arrival_time_min
          ,rt_dist as drive_dist
          ,rt_dist/(time-duration) as avg_hour_sp
        from (
          select task_id
            ,task_subid
            ,vehicle_serial
            ,actual_capacity_load
            ,driver_id
            ,driver_name
            ,plan_depart_tm
            ,actual_depart_tm
            ,plan_arrive_tm
            ,actual_arrive_tm
            ,line_time
            ,actual_run_time
            ,line_time - actual_run_time as early_arrival_time
            ,rt_dist
            ,line_distance
            ,highwaymileage as high_way_mileage
            ,rt_dist - highwaymileage as nohigh_way_mileage
            , time
            , duration
            from  dm_gis.eta_std_line_recall
            where inc_day  = '${inc_day}' and carrier_type=0
          ) t0
        left join(select carplate,zytype from dm_arss.dm_device_hh_dtl_di where inc_day = '${inc_day}') t1 on t0.vehicle_serial=t1.carplate
        left join(select vehicle_code,dept_id from ods_vms.tm_vms_vehicle where inc_day ='${inc_day}' and  dept_id is not null ) t2 on t0.vehicle_serial=t2.vehicle_code
        left join(select dept_id,area_code,area_name from dim.dim_dept_info_df where inc_day ='${inc_day}' and dept_id is not null) t3 on  t2.dept_id = t3.dept_id
      """.stripMargin

    logger.error(sql)

    val sourceDF = sparkSession.sql(sql)
    logger.error("数据量 :  " + sourceDF.count())

    val joinRdd  =  sourceDF
      .join(speedingGroupRdd, Seq("task_id"),"left")
      .join(highSpeedingGroupRdd, Seq("task_id"),"left")
      .join(stopGroupRdd, Seq("task_id"),"left")
      .join(highstopRdd, Seq("task_id"),"left")
      .repartition(50)

//      .withColumn("line_distance", 'line_distance/1000)
//      .withColumn("rt_dist", 'rt_dist/1000)
//      .withColumn("line_time_s", 'line_time_s/60)
//      .withColumn("actual_run_time_s", 'actual_run_time_s/60)

      .select(
        'task_id
        ,'task_subid
        ,'vehicle_serial
        ,'actual_capacity_load
        ,'driver_id
        ,'driver_name
        ,'zytype
        ,'area_code
        ,'area_name
        ,'plan_depart_tm
        ,'actual_depart_tm
        ,'plan_arrive_tm
        ,'actual_arrive_tm

        ,('line_distance/1000).as("line_distance")
        ,('rt_dist/1000).as("rt_dist")

        ,'high_way_mileage
        ,'nohigh_way_mileage

        ,'line_time_min
        ,('line_time_s/60).as("line_time_s")
        ,'actual_run_time_min
        ,('actual_run_time_s/60).as("actual_run_time_s")
        ,'actual_run_time

        ,'early_arrival_time_min
        ,'drive_dist

        ,'avg_hour_sp

        ,('speeding_times_s/60/60).as("speeding_times_s")
        ,'speeding_times_m
        ,('speeding_times_m/'actual_run_time).as("speeding_times_p")

        ,'speeding_dist
        ,('speeding_dist/'rt_dist).as("speeding_p")

        ,('stop_times_s/60/60).as("stop_times_s")
        ,'stop_times_m
        ,('stop_times_m/'actual_run_time).as("stop_times_p")

        ,('high_speeding_dist/1000).as("high_way_mil")
        ,('speeding_dist / 'speeding_times_m).as("high_way_avg_sp")

        ,('high_speeding_times_s/60/60).as("high_speeding_times_s")
        ,'high_speeding_times_m
        ,('high_speeding_times_m /'speeding_times_m ).as("high_way_speeding_p")

        ,('high_speeding_dist/1000).as("high_way_speeding_dist")
        ,('high_speeding_dist/'high_way_mileage).as("high_way_speeding_dist_p")

        ,('high_stop_times_s/60/60).as("high_way_stop_s")
        ,'high_stop_times_m.as("high_way_stop_m")
        ,('high_stop_times_m/'stop_times_m).as("high_way_stop_p")
      )

    joinRdd.persist(StorageLevel.MEMORY_ONLY)

    logger.error("数据量 joinRdd :  " + joinRdd.count())

    val resultDF =  joinRdd

      .withColumn("no_high_way_dist",'rt_dist - 'high_way_speeding_dist)
      .withColumn("no_high_way_avg_speed",('rt_dist - 'high_way_speeding_dist)/('actual_run_time-'high_speeding_times_m))


      //todo 不是高速超速
      .withColumn("no_high_way_speeding_s",'speeding_times_s - 'high_speeding_times_s)
      .withColumn("no_high_way_speeding_m",'speeding_times_m - 'high_speeding_times_m)
      .withColumn("no_high_way_speeding_p",('speeding_times_m - 'high_speeding_times_m) / 'speeding_times_m)

      .withColumn("no_high_way_speeding_dist",'speeding_dist - 'high_way_speeding_dist)
      .withColumn("no_high_way_speeding_dist_P",('speeding_dist - 'high_way_speeding_dist)/ 'speeding_dist)

      .withColumn("no_high_way_stop_s",'stop_times_s - 'high_way_stop_s)
      .withColumn("no_high_way_stop_m",'stop_times_m - 'high_speeding_times_m)
      .withColumn("no_high_way_stop_p",('stop_times_s - 'high_way_stop_s)/'stop_times_s)

    val Df = resultDF.withColumn("inc_day", lit(inc_day)).drop("actual_run_time")


    logger.error("数据量 Df :  " + resultDF.count())


    writeToHive(sparkSession,Df,Seq("inc_day"),"dm_gis.vehicle_task_speeding_Control")

  }

}
