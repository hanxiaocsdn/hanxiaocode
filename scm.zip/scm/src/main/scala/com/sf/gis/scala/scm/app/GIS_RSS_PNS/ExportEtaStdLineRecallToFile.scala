package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import com.sf.gis.scala.scm.app.etastdlinerecallvms.ExportEtastdlinerecallvmFromHive.hdfsFileReName
import common.DataSourceCommon
import utils.SparkBuilder


/**
  *@author 01420395
  *@DESCRIPTION
  *轨迹缺失表 需求ID 1971281    GIS-RSS-PNS：【路径规划】司机实走标准路线每日下载需求说明书_V1.0
  *任务id : 795308   任务依赖：  371318
  *@create 2023/08/28
  */
object ExportEtaStdLineRecallToFile  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    start(inc_day)

  }


  def start(inc_day: String) = {
    val sourceSql =
      s"""
         select
  task_area_code,
  task_id,
  task_subid,
  carrier_type,
  concat(
            line_code,
            '_',
            start_dept,
            '_',
            end_dept,
            '_',
            vehicle_type,
            '_',
            actual_capacity_load
          ) as linemload,
  start_dept,
  end_dept,
  line_code,
  vehicle_serial,
  actual_capacity_load,
  actual_depart_tm,
  actual_arrive_tm,
  line_time,
  line_distance,
  actual_run_time,
  start_longitude,
  start_latitude,
  end_longitude,
  end_latitude,
  vehicle_type,
  axls_number,
  rt_coords,
  x1,
  y1,
  x2,
  y2,
  time,
  rt_dist,
  toll_charge,
  inc_day
from
  dm_gis.eta_std_line_recall
where
  inc_day = '${inc_day}'
  and line_distance >= 3
  and halfway_integrate_rate >= 0.9
  and error_type = 0
       """.stripMargin


    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sourceRdd = spark.sql(sourceSql)

    val hdfsPath = "/user/01420395/upload/data/export/eta_std_line_recall"

    val outPath = hdfsPath + "/" + inc_day + "/dm_gis.eta_std_line_recall/"

    sourceRdd.coalesce(1).write
      .mode("overwrite")
      .option("header", "true")
      .option("delimiter", "\t")
      .csv(outPath)


    hdfsFileReName(spark, outPath, "standard_day_" + inc_day.substring(4,8) + ".csv")

  }

}