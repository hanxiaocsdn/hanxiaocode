package com.sf.gis.scala.scm.app.trajectory

import java.text.SimpleDateFormat
import java.util.Date
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, UrlUtil}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil}
import common.DataSourceCommon
import utils.SparkUtil.row2Json
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.{HttpPostUtils, SparkBuilder, SparkUtils, StringUtils}

import scala.collection.mutable.ArrayBuffer

/**
@author 01420395
@DESCRIPTION GIS-RSS-SCM：【陆运油耗管控报表】陆运油耗管数据报表需求_V1.0 需求id 1948035 任务id:
车辆任务超速明细数据: 1.  获取表 dm_gis.eta_std_line_recall  where  carrier_type=0 数据
             2. 调用接口获取轨迹点信息
             3. 根据车辆吨位判断对应速度是否超速,
@create 2023/08/16 任务id 794608 任务依赖：  794860
  */
object VehicleStopDetail  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //  val url:String = "http://gis-vms-query-new.sf-express.com:80/trackquery-new/api/integrateDetail"
  val url:String ="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail" //bdp访问地址


  val ak:String = "93ec117f7f1b4226b4e537c4802319e9"

  val poiUrl:String = "http://gis-apis.int.sfcloud.local:1080/rgeo/api"

  val poiAk:String = "27ca925be2e84bc9abe8c6abceba116a"


  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val sparkSession = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sql =
      s"""
         select task_id
          ,task_subid
          ,vehicle_serial
          ,actual_capacity_load
          ,zytype
          ,area_code
          ,area_name
          ,driver_id
          ,driver_name
          ,plan_depart_tm
          ,actual_depart_tm
          ,plan_arrive_tm
          ,actual_arrive_tm
          ,'' stop_area
         |,'' stop_begin_tm
         |,'' stop_end_tm
         |,'' stop_rm_tm_s
         |,'' stop_rm_tm_min
         |,'' road_class
         |,'' service
        from (
          select task_id
            ,task_subid
            ,vehicle_serial
            ,actual_capacity_load
            ,driver_id
            ,driver_name
            ,plan_depart_tm
            ,actual_depart_tm
            ,plan_arrive_tm
            ,actual_arrive_tm
            ,line_time
            ,actual_run_time
            ,line_time - actual_run_time as early_arrival_time
            from  dm_gis.eta_std_line_recall
            where inc_day  = '${inc_day}' and carrier_type=0
          ) t0
        left join(select carplate,zytype from dm_arss.dm_device_hh_dtl_di where inc_day = '${inc_day}') t1 on t0.vehicle_serial=t1.carplate
        left join(select vehicle_code,dept_id from ods_vms.tm_vms_vehicle where inc_day ='${inc_day}') t2 on t0.vehicle_serial=t2.vehicle_code
        left join(select dept_id,area_code,area_name from dim.dim_dept_info_df where inc_day ='${inc_day}') t3 on  t2.dept_id = t3.dept_id
      """.stripMargin

    logger.error(sql)


    val sourceDF = sparkSession.sql(sql)
    sourceDF.show(10)

   val  filaterRDD = sourceDF.filter(row  => {val endTime = row.getAs[String]("actual_arrive_tm")
      !StringUtils.isEmpty(endTime)
    } )

    logger.error("原始数据: " + sourceDF.count())

    val httpInvokeId2  = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01420395"
      ,"794608","陆运油耗管控报表-怠速","陆运油耗管控报表-怠速"
      ,poiUrl,poiAk,sourceDF.count(),60
    )



    val httpInvokeId1  = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01420395"
      ,"794608","陆运油耗管控报表-怠速","陆运油耗管控报表-怠速"
      ,url,ak,sourceDF.count(),60
    )

    import sparkSession.implicits._
    val sourceJson = SparkNet.runInterfaceWithAkLimit1(sparkSession, filaterRDD.rdd.map(row2Json), runIntegrateDetailInteface, 50, ak, 1800)

    val resultRDD = sourceJson.flatMap(_.toSeq).map(row=> {
      val task_id = row.getString("task_id")
      val task_subid = row.getString("task_subid")
      val vehicle_serial = row.getString("vehicle_serial")
      val actual_capacity_load = row.getString("actual_capacity_load")
      val zytype = row.getString("zytype")
      val area_code = row.getString("area_code")
      val area_name = row.getString("area_name")
      val plan_depart_tm = row.getString("plan_depart_tm")
      val actual_depart_tm = row.getString("actual_depart_tm")
      val plan_arrive_tm = row.getString("plan_arrive_tm")
      val actual_arrive_tm = row.getString("actual_arrive_tm")
      val stop_area = row.getString("stop_area")
      val stop_begin_tm = row.getString("stop_begin_tm")
      val stop_end_tm = row.getString("stop_end_tm")
      val stop_rm_tm_s = row.getString("stop_rm_tm_s")
      val stop_rm_tm_min = row.getString("stop_rm_tm_min")
      val road_class = row.getString("road_class")
      val service = row.getString("service")

      Row(task_id
        , task_subid
        , vehicle_serial
        , actual_capacity_load
        , zytype
        , area_code
        , area_name
        , plan_depart_tm
        , actual_depart_tm
        , plan_arrive_tm
        , actual_arrive_tm
        , stop_area
        , stop_begin_tm
        , stop_end_tm
        , stop_rm_tm_s
        , stop_rm_tm_min
        , road_class
        , service)
    })

    BdpTaskRecordUtil.endNetworkInterface("01420395",httpInvokeId1)
    BdpTaskRecordUtil.endNetworkInterface("01420395",httpInvokeId2)


    val schema = StructType(List(
      StructField("task_id", StringType, true),
      StructField("task_subid", StringType, true),
      StructField("vehicle_serial", StringType, true),
      StructField("actual_capacity_load", StringType, true),
      StructField("zytype", StringType, true),
      StructField("area_code", StringType, true),
      StructField("area_name", StringType, true),
      StructField("plan_depart_tm", StringType, true),
      StructField("actual_depart_tm", StringType, true),
      StructField("plan_arrive_tm", StringType, true),
      StructField("actual_arrive_tm", StringType, true),
      StructField("stop_area", StringType, true),
      StructField("stop_begin_tm", StringType, true),
      StructField("stop_end_tm", StringType, true),
      StructField("stop_rm_tm_s", StringType, true),
      StructField("stop_rm_tm_min", StringType, true),
      StructField("road_class", StringType, true),
      StructField("service", StringType, true)
    ))

    import org.apache.spark.sql.functions._
    val resultRdd = sparkSession.createDataFrame(resultRDD, schema).withColumn("inc_day", lit(inc_day))
    resultRdd.show(10, false)

    writeToHive(sparkSession,resultRdd,Seq("inc_day"),"dm_gis.vehicle_task_stopping_detail")

  }




  def runIntegrateDetailInteface(ak:String, row: JSONObject):Seq[JSONObject] = {
    val vehicle = row.getString("vehicle_serial")

    //todo 需要进行日期格式化
    val beginDateTime = row.getString("actual_depart_tm")
    val endDateTime = row.getString("actual_arrive_tm")
    val task_id = row.getString("task_id")
    val task_subid = row.getString("task_subid")
    val zytype = row.getString("zytype")
    val area_code = row.getString("area_code")
    val area_name = row.getString("area_name")
    val plan_depart_tm = row.getString("plan_depart_tm")
    val actual_depart_tm = row.getString("actual_depart_tm")
    val plan_arrive_tm = row.getString("plan_arrive_tm")
    val actual_arrive_tm = row.getString("actual_arrive_tm")
    val actual_capacity_load = row.getString("actual_capacity_load")


    val postJson = new JSONObject()
    postJson.put("type", "401")
    postJson.put("un", vehicle)
    postJson.put("unType", "0")
    postJson.put("beginDateTime", beginDateTime.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    postJson.put("endDateTime", endDateTime.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    postJson.put("ak",ak)


    val result = HttpUtils.post(url, postJson, "utf-8")
    //      val reNaviParse_sdkNaviLogNsult = UrlUtil.sendPost(url,postJson.toJSONString)

    logger.error("返回数据: " + result)
    var highTracksArray = new ArrayBuffer[JSONObject]()
    //解析返回数据获取对应的速度轨迹信息
    val resultJson = JSON.parseObject(result)
    val status = resultJson.getInteger("status")
    if (status == 0) {
      val trackArray = resultJson.getJSONObject("result").getJSONObject("data").getJSONArray("track")
      val iterator = trackArray.iterator()
      var higherSp = new ArrayBuffer[JSONObject]()
      //是否连续
      var isContinuous = true
      while (iterator.hasNext) {
        if (!isContinuous && higherSp.size > 0) {
          val stopJson = builderStopJsonFromSp(higherSp)

          stopJson.put("task_id", task_id)
          stopJson.put("task_subid", task_subid)
          stopJson.put("vehicle_serial", vehicle)
          stopJson.put("zytype", zytype)
          stopJson.put("area_code", area_code)
          stopJson.put("area_name", area_name)
          stopJson.put("plan_depart_tm", plan_depart_tm)
          stopJson.put("actual_depart_tm", actual_depart_tm)
          stopJson.put("plan_arrive_tm", plan_arrive_tm)
          stopJson.put("actual_arrive_tm", actual_arrive_tm)
          stopJson.put("actual_capacity_load", actual_capacity_load)


          highTracksArray.append(stopJson)
          higherSp.clear()
        }

        val track = iterator.next()
        val trackJson = JSON.parseObject(track.toString)
        val sp = trackJson.getDouble("sp")
        val tm = trackJson.getLong("tm")
        val roadClass = trackJson.getString("roadClass")
        val roadName = trackJson.getString("roadName")

        val trackJsonNew = new JSONObject()
        //怠速
        if (sp == 0) {
          trackJsonNew.put("sp", sp)
          trackJsonNew.put("tm", tm)
          trackJsonNew.put("roadClass", roadClass)
          trackJsonNew.put("roadName", roadName)
          higherSp.append(trackJsonNew)
          isContinuous = true
        } else {
          isContinuous = false
        }
      }

      //最后一次的进行数据清洗
      if (higherSp.size > 0 ) {
        val stopJson = builderStopJsonFromSp(higherSp)
        stopJson.put("task_id", task_id)
        stopJson.put("task_subid", task_subid)
        stopJson.put("vehicle_serial", vehicle)
        stopJson.put("zytype", zytype)
        stopJson.put("area_code", area_code)
        stopJson.put("area_name", area_name)
        stopJson.put("plan_depart_tm", plan_depart_tm)
        stopJson.put("actual_depart_tm", actual_depart_tm)
        stopJson.put("plan_arrive_tm", plan_arrive_tm)
        stopJson.put("actual_arrive_tm", actual_arrive_tm)
        stopJson.put("actual_capacity_load", actual_capacity_load)


        highTracksArray.append(stopJson)
      }
    }
    highTracksArray.toSeq
  }



  def builderStopJsonFromSp(higherSp :ArrayBuffer[JSONObject])={

    val sdf1  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

    //不连续的时候需要进行数据分段, 然后进行数据拆分; 计算总数据
    val x = higherSp(0).getDouble("zx")
    val y = higherSp(0).getDouble("zy")
    val road_class = higherSp(0).getString("roadClass")
    var stop_start_tm = higherSp(0).getLong("tm")
    val start_time_fr = sdf1.format(new Date(stop_start_tm.toLong*1000L))


    var stop_end_tm = higherSp(higherSp.size-1).getLong("tm")
    //如果是只有一个轨迹点 结束开始时间设置成相差 1s
    if(higherSp.size==1){
      stop_end_tm = (stop_start_tm + 1)
    }

    val stop_end_tm_fr = sdf1.format(new Date(stop_end_tm.toLong*1000L))

    val stop_area = higherSp(0).getString("roadName")
    //https://gis.sf-express.com/rgeo/api?opt=sf1&ak=""&x=112.79341697361343&y=22.423639341778376
    val url  =poiUrl +   "?" + "opt=sf1&"+"ak="+poiAk+"&"+"x="+x+"&"+"y="+y
    println(url)
    val result =  HttpPostUtils.retryGet(url)
//        val result = UrlUtil.retryGet(url,"UTF-8")

    println(result)

    import scala.util.control.Breaks.{break, breakable}
    //解析返回数据获取对应的速度轨迹信息
    val resultJson =  JSON.parseObject(result)
    val status  =  resultJson.getInteger("status")
    var isPoi = "0"
    if(status ==0){
      val pois  = resultJson.getJSONObject("result").getJSONArray("pois")
      val iterator  = pois.iterator()
      while (iterator.hasNext){
        val poi = iterator.next()
        val poiJson = JSON.parseObject(poi.toString)
        val name = poiJson.getString("name")
        val distance  = poiJson.getDouble("distance")
        breakable {
          if(name.indexOf("服务区")>0 &&  distance<500 ){
            isPoi = "1"
            break()
          }
        }
      }
    }

    val  returnJson  = new JSONObject()
    returnJson.put("stop_begin_tm",start_time_fr)
    returnJson.put("stop_end_tm",stop_end_tm_fr)
    returnJson.put("stop_rm_tm_s",(stop_end_tm-stop_start_tm))
    returnJson.put("stop_rm_tm_min",((stop_end_tm-stop_start_tm)/60.000))
    returnJson.put("road_class",road_class)
    returnJson.put("service",isPoi)
    returnJson.put("stop_area",stop_area)

    returnJson
  }
}
