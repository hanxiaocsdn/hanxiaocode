//package com.sf.gis.scala.scm.app.heavycargostatic.ls
//
//import com.sf.gis.scala.scm.utils.{HBaseUtils, SparkBuilder}
//import com.sf.gis.scala.scm.common.DataSourceCommon
//import org.apache.hadoop.hbase.HBaseConfiguration
//import org.apache.hadoop.hbase.client.{Delete, Result}
//import org.apache.hadoop.hbase.io.ImmutableBytesWritable
//import org.apache.hadoop.hbase.mapreduce.TableInputFormat
//import org.apache.spark.sql.SparkSession
//
///**
//  * @description: 全国重货车型信息计算同步到到hbase;  需求ID: 1720287 任务id 698593
//  * @author 01420935 caiguofang
//  * @date 2023/04/10 10:36
//  */
//object CleanVehicleMain extends DataSourceCommon {
//
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
////  val zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545"
//  val zkPort = "2181"
//  val zkParent = "/hbase"
//
//
//  def main(args: Array[String]): Unit = {
//    val tableName  = args(0)
//    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
//    if("insurance_vehicle_basics_original".equalsIgnoreCase(tableName)){
//      cleanBasicVehicleMode(spark)
//    }else if("insurance_vehicle_model_original".equalsIgnoreCase(tableName) ){
//      cleanModelVehicleMode(spark)
//    }else {
//      cleanBasicVehicleJson(spark)
//    }
//
//    spark.close()
//  }
//
//
//  def cleanModelVehicleMode(spark:SparkSession): Unit ={
//
//    //清空数据
//    val hbaseTblName = "gis:insurance_vehicle_model_original"
//    val hbaseConf  = HBaseConfiguration.create()
//    hbaseConf.set("zookeeper.znode.parent", zkParent)
//    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
//    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
//    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")
//    hbaseConf.set(TableInputFormat.INPUT_TABLE, hbaseTblName)
//
//    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])
//    hbaseTblRdd.foreachPartition(rows =>{
//      val hbaseTbl  = HBaseUtils.getHbaseTable(hbaseTblName,zkParent,zkQuorum,zkPort)
//      hbaseTbl.setAutoFlush(false)
//      rows.foreach(row =>{
//        val result = row._2.getRow
//        logger.error("删除" + result)
//        hbaseTbl.delete(new Delete(result))
//        logger.error("删除数据 " + result)
//      })
//      hbaseTbl.flushCommits()
//      hbaseTbl.close()
//    })
//  }
//
//
//  def cleanBasicVehicleMode(spark:SparkSession): Unit ={
//
//    //清空数据
//    val hbaseTblName = "gis:insurance_vehicle_basics_original"
//    val hbaseConf  = HBaseConfiguration.create()
//    hbaseConf.set("zookeeper.znode.parent", zkParent)
//    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
//    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
//    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")
//    hbaseConf.set(TableInputFormat.INPUT_TABLE, hbaseTblName)
//
//    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])
//
//    hbaseTblRdd.foreachPartition(rows=>{
//      val hbaseTbl  = HBaseUtils.getHbaseTable(hbaseTblName,zkParent,zkQuorum,zkPort)
//      hbaseTbl.setAutoFlush(false)
//
//      rows.foreach(row =>{
//        val result = row._2.getRow
//        logger.error("删除" + result)
//        hbaseTbl.delete(new Delete(result))
//        logger.error("删除数据 " + result)
//      })
//      logger.error("删除数据2")
//      hbaseTbl.flushCommits()
//      hbaseTbl.close()
//    })
//  }
//
//
//
//  def cleanBasicVehicleJson(spark:SparkSession): Unit ={
//
//    //清空数据
//    val hbaseTblName = "gis:insurance_vehicle_json_original"
//    val hbaseConf  = HBaseConfiguration.create()
//    hbaseConf.set("zookeeper.znode.parent", zkParent)
//    hbaseConf.set("hbase.zookeeper.quorum", zkQuorum)
//    hbaseConf.set("hbase.zookeeper.property.clientPort", zkPort)
//    hbaseConf.set(TableInputFormat.SCAN_BATCHSIZE, "100")
//    hbaseConf.set(TableInputFormat.INPUT_TABLE, hbaseTblName)
//
//    val hbaseTblRdd  = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],classOf[ImmutableBytesWritable], classOf[Result])
//
//    hbaseTblRdd.foreachPartition(rows=>{
//      val hbaseTbl  = HBaseUtils.getHbaseTable(hbaseTblName,zkParent,zkQuorum,zkPort)
//      hbaseTbl.setAutoFlush(false)
//
//      rows.foreach(row =>{
//        val result = row._2.getRow
//        logger.error("删除" + result)
//        hbaseTbl.delete(new Delete(result))
//        logger.error("删除数据 " + result)
//      })
//      logger.error("删除数据2")
//      hbaseTbl.flushCommits()
//      hbaseTbl.close()
//    })
//  }
//}
