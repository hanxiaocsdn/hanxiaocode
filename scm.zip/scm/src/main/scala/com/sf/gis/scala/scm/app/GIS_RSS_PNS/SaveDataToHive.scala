package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import java.util
import com.alibaba.fastjson.JSONObject
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import utils.JsonUtil

/**
 * Created by 01368978 on 2021/3/12.
 */
object SaveDataToHive {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def saveJSONObjectRDDToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if (StringUtils.isEmpty(dataBase)) database = "dm_gis"
    else database = dataBase

    logger.error(">>>table=" + database + "." + table)
    spark.sql(s"use $database")
    //1 构造DataFrame的元数据 StructField
    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    //2 构建StructType用于DataFrame的元数据描述
    val structType = DataTypes.createStructType(structFileds)
    //3 构建Row格式数据集RDD[Row]
    val rowRdd = resultRdd.filter(_ != null).map(obj => {
      var row: Row = null
      try {
        val v = new Array[String](keys.length)
        for (i <- keys.indices) v(i) = JsonUtil.getJsonVal(obj, keys(i), "")
        row = RowFactory.create(v: _*)
      } catch {
        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
      }
      row
    }).filter(_ != null)
    // 4 构建DataFrame
    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
    //5 基于Datarame创建临时表

    logger.error("保存数据量 : " + df.count())

    val tempView = String.format("%s_temp_view", table)
    df.createOrReplaceTempView(tempView)
    //6 分区、表等操作
    val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
    logger.error(">>>删除分区：" + deleteSql)
    spark.sql(deleteSql)
    val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
    logger.error(">>>新建分区：" + createPartitionSql)
    spark.sql(createPartitionSql)
    //7 把临时表的数据刷进hive表中
    spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
    logger.error(">>>数据入hive库结束!")

  }



  def saveJSONObjectRDDToHive2(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if (StringUtils.isEmpty(dataBase)) database = "dm_gis"
    else database = dataBase

    logger.error(">>>table=" + database + "." + table)
    spark.sql(s"use $database")
    //1 构造DataFrame的元数据 StructField
    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    //2 构建StructType用于DataFrame的元数据描述
    val structType = DataTypes.createStructType(structFileds)
    //3 构建Row格式数据集RDD[Row]
    val rowRdd = resultRdd.filter(_ != null).map(obj => {
      var row: Row = null
      try {
        val v = new Array[String](keys.length)
        for (i <- keys.indices) v(i) = JsonUtil.getJsonVal(obj, keys(i), "")
        row = RowFactory.create(v: _*)
      } catch {
        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
      }
      row
    }).filter(_ != null)
    // 4 构建DataFrame
    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
    //5 基于Datarame创建临时表

    logger.error("保存数据量 : " + df.count())

    val tempView = String.format("%s_temp_view", table)


    import org.apache.spark.sql.functions.lit

    df.withColumn("inc_day",lit(incDay)).createOrReplaceTempView(tempView)


    df.show(1, false)

    //7 把临时表的数据刷进hive表中
    spark.sql(String.format("insert overwrite table %s partition(inc_day) select * from %s", database + "." + table, tempView))
    spark.catalog.dropTempView(tempView)
    logger.error(">>>数据入hive库结束!")


  }

  def saveArrayRDDToHive(spark: SparkSession, resultRdd: RDD[Array[String]], table: String, structs: Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if (StringUtils.isEmpty(dataBase)) database = "dm_gis" else database = dataBase
    logger.error(">>>table=" + database + "." + table)
    spark.sql(s"use $database")
    //1 构造DataFrame的元数据 StructField
    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    //2 构建StructType用于DataFrame的元数据描述
    val structType = DataTypes.createStructType(structFileds)
    //3 构建Row格式数据集RDD[Row]
    val rowRdd = resultRdd.filter(_ != null).map(v => {
      var row: Row = null
      try {
        row = RowFactory.create(v: _*)
      } catch {
        case e: Exception => logger.error(">>>构造row异常:" + e + "," + v)
      }
      row
    }).filter(_ != null)
    // 4 构建DataFrame
    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
    //5 基于Datarame创建临时表
    val tempView = String.format("%s_temp_view", table)
    df.createOrReplaceTempView(tempView)
    //6 分区、表等操作
    val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
    logger.error(">>>删除分区：" + deleteSql)
    spark.sql(deleteSql)
    val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
    logger.error(">>>新建分区：" + createPartitionSql)
    spark.sql(createPartitionSql)
    //7 把临时表的数据刷进hive表中
    spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
    logger.error(">>>数据入hive库结束!")
  }
}
