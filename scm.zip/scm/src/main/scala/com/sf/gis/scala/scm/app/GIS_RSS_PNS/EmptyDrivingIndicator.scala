package com.sf.gis.scala.scm.app.GIS_RSS_PNS

import common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import utils.{DateUtil, SparkBuilder, SparkUtils, StringUtils}


/**
  *@author 01420395
  *@DESCRIPTION
  *轨迹缺失表 需求ID 1842890   GIS-RSS-PNS：【价值线路】空驶指标监控需求_V1.0
  *任务id：770341
  *@create 2023/06/14
  */
object EmptyDrivingIndicator  extends DataSourceCommon {

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    //获取任务监控数据
    val gisEtaTsAccuralParseDF = gisEtaTsAccuralParse(inc_day,spark)

    //补全历程和路桥信息
    //sum(road_fee) road_fee,sum(miles) miles,task_id
    val  ttVmsDrivingLogItemDF = ttVmsDrivingLogItem(inc_day,spark)
    //获取价值线路信息
    // a.std_id ,
    //  a.add_reason,
    //  b.value_time as online_date,
    val etaStdLineConfDF = etaStdLineConf(inc_day,spark)

    val etaStdLineConfDF1 =  gisEtaTsAccuralParseDF
      .join(etaStdLineConfDF,Seq("std_id"),"inner")
      .join(ttVmsDrivingLogItemDF, Seq("task_id"),"left" )

    //补全车辆信息
    //    Row(row.getString("vehicle_serial"),
    //      row.getString("mload_cc"),
    //      row.getString("length"),
    //      row.getString("axle_number_cc"),
    //      row.getString("weight"),
    //      row.getString("lenght_weight")

    val tm_vms_vehicleDf = tm_vms_vehicle(inc_day, spark)

    //    vehicle_serial,
    //    actual_capacity_load as mload_rw,
    //    axls_number as axle_number_rw,
    //    actual_depart_tm
    val eta_std_line_recall1DF = eta_std_line_recall1(inc_day, spark)

    import org.apache.spark.sql.functions._
    import spark.implicits._

    tm_vms_vehicleDf.show(1, false)

    val etaStdLineConfDF2 =  etaStdLineConfDF1
      .join(tm_vms_vehicleDf, Seq("vehicle_serial"),"left")
      .join(eta_std_line_recall1DF, Seq("vehicle_serial"),"left")

    etaStdLineConfDF2.show(1, false)

    val etaStdLineConfDF3 =etaStdLineConfDF2
      .withColumn("axls_number",when('axle_number_cc  isNotNull , 'axle_number_cc).otherwise('axle_number_rw))
      .withColumn("mload",when('mload_cc  isNotNull , 'mload_cc).otherwise('mload_rw))
      .withColumn("grd1", concat_ws("_", 'start_dept,'end_dept,
        format_number('start_longitude.cast("Double"),2),
        format_number('start_latitude.cast("Double"),2),
        format_number('end_longitude.cast("Double"),2),
        format_number('end_latitude.cast("Double"),2),
        'length_weight)
      )

    etaStdLineConfDF3.show(1, false)

    //补全油价信息
    val gis_fule_pricesDf = gis_fule_prices(inc_day, spark)
    val gis_vehicle_fule_statDf = gis_vehicle_fule_stat(inc_day, spark)

    val etaStdLineConfDF4 = etaStdLineConfDF3
      .join(gis_fule_pricesDf,Seq("inc_day"),"left")
      .join(gis_vehicle_fule_statDf, Seq("vehicle_serial"),"left")

    val etaStdLineConfDF5= etaStdLineConfDF4
      .withColumn("fuel_cost",'fuel_prices*'update_uint_fuel*'miles/100)

    val etaStdLineConfDF6=etaStdLineConfDF5.withColumn("sum_cost",'fuel_cost + 'road_fee)

    val  etaStdLineConfDF7 = etaStdLineConfDF6.select(
      'task_area_code
      , 'task_id
      , 'task_subid
      , 'sort_num
      , 'start_dept
      , 'end_dept
      , 'start_type
      , 'end_type
      , 'line_code
      , 'linevehicle
      , 'grd1
      , 'std_id
      , 'vehicle_serial
      , 'conduct_type
      , 'is_run_ontime
      , 'start_longitude
      , 'start_latitude
      , 'end_longitude
      , 'end_latitude
      , 'rt_dist
      , 'toll_charge
      , 'is_stop
      , 'stop_over_zone_code
      , 'transoport_level
      , 'carrier_type
      , 'carrier_name
      , 'vehicle_type
      , 'axls_number
      , 'length
      , 'weight
      , 'mload
      , 'length_weight
      , 'miles
      , 'road_fee
      , 'fuel_prices
      , 'update_uint_fuel
      , 'fuel_cost
      , 'sum_cost
      , 'error_type
      , 'std_id_jz
      , 'std_id_jz_time
      , 'add_reason
      , 'task_inc_day
      , 'inc_day
    )
    etaStdLineConfDF7.show(1, false )

    writeToHive(spark,etaStdLineConfDF7,Seq("inc_day"),"dm_gis.gis_eta_jiazhi_task_ks")

  }

  /**
    * 获取油价
    */
  def gis_fule_prices(inc_day:String, spark:SparkSession)={


    val resourceDF = spark.sql(
      s"""
         |select
         |fuel_prices,inc_day
         |from
         |dm_gis.gis_fule_prices
         |where
         | inc_day = '${inc_day}'
       """.stripMargin)

    resourceDF
  }


  /**
    * 获取油耗
    */
  def gis_vehicle_fule_stat(inc_day:String, spark:SparkSession)={

    val resourceDF = spark.sql(
      s"""
         | select
         |vehicle_serial,update_uint_fuel
         |from
         |dm_gis.gis_vehicle_fule_stat
         |where
         |inc_day = '${inc_day}'
       """.stripMargin)
    resourceDF
  }



  /**
    * 获取车参数据
    */
  def tm_vms_vehicle(inc_day:String, spark:SparkSession)={

    val resourceDF = spark.sql(
      s"""
         |  select
         |  vehicle_code as vehicle_serial,
         |  round(max_load/ 1000, 2) as mload_cc,
         |  round(outer_length/ 1000, 2) as length,
         |  axes as axle_number_cc,
         |  round((max_load + net_weight)/ 1000, 2) as weight
         |  from
         |  ods_vms.tm_vms_vehicle
         |  where
         |  inc_day = '${inc_day}'
       """.stripMargin)

    val resourceJson = SparkUtils.getRowToJson(resourceDF)

    val resultRdd =  resourceJson.map(row =>{
      val length  = row.getString("length")
      val weight  = row.getString("weight")
      val mload_cc  = row.getString("mload_cc")

      //都不为空的时候
      if(!StringUtils.isEmpty(length) && !StringUtils.isEmpty(weight)){
        val len = length.toDouble
        val wei = weight.toDouble
        if(len < 5.5){
          if(wei < 4){
            row.put("length_weight","4米2_3吨")
          }else if(4<=wei && wei< 6){
            row.put("length_weight","4米2_5吨")
          }else if(6<=wei && wei< 8){
            row.put("length_weight","4米2_7吨")
          }else if(8<=wei && wei< 12.5){
            row.put("length_weight","4米2_9吨")
          }else{
            row.put("length_weight","4米2_13吨+")
          }
        }else if(5.5<=len && len< 8.2){
          if(wei < 6){
            row.put("length_weight","6米8_5吨")
          }else if(6<=wei && wei< 8){
            row.put("length_weight","6米8_7吨")
          }else if(8<=wei && wei< 10.5){
            row.put("length_weight","6米8_9吨")
          }else if(10.5<=wei && wei< 14){
            row.put("length_weight","6米8_12吨")
          }else if(14<=wei && wei< 20){
            row.put("length_weight","6米8_16吨")
          }else if(20<=wei && wei< 27.5){
            row.put("length_weight","6米8_25吨")
          }else{
            row.put("length_weight","6米8_30吨+")
          }
        }else if(8.2<=len && len< 10.8){
          if(wei < 13){
            row.put("length_weight","9米6_10吨")
          }else if(13<=wei && wei< 17){
            row.put("length_weight","9米6_16吨")
          }else if(17<=wei && wei< 20){
            row.put("length_weight","9米6_18吨")
          }else if(20<=wei && wei< 23.5){
            row.put("length_weight","9米6_25吨")
          }else{
            row.put("length_weight","9米6_30吨+")
          }
        }else if(10.8<=len && len< 14){
          if(wei < 21.5){
            row.put("length_weight","12米_18吨")
          }else if(21.5<=wei && wei< 27.5){
            row.put("length_weight","12米_25吨")
          }else if(27.5<=wei && wei< 32.5){
            row.put("length_weight","12米_30吨")
          }else if(32.5<=wei && wei< 37.5){
            row.put("length_weight","12米_35吨")
          }else if(37.5<=wei && wei< 42.5){
            row.put("length_weight","12米_40吨")
          }else{
            row.put("length_weight","12米_45吨+")
          }
        }else if(14<=len && len< 18){
          if(wei < 37.5){
            row.put("length_weight","16米_35吨")
          }else if(37.5<=wei && wei< 50){
            row.put("length_weight","16米_40吨")
          }else if(50<=wei && wei< 65){
            row.put("length_weight","16米_60吨")
          }else{
            row.put("length_weight","16米_70吨")
          }
        }else if(18<=len){
          if(wei < 21.5){
            row.put("length_weight","19米1_18吨")
          }else{
            row.put("length_weight","19米1_25吨")
          }
        }
      }else{
        var mload  = 0.0
        if(!StringUtils.isEmpty(mload_cc)){
          mload =  mload_cc.toDouble
        }
        if(mload<1){
          row.put("length_weight","1吨")
        }else if(mload>1 && mload<=2){
          row.put("length_weight","1.5吨")
        }else if(mload>2 && mload<=4){
          row.put("length_weight","3吨")
        }else if(mload>4 && mload<=6){
          row.put("length_weight","6吨")
        }else if(mload>6 && mload<=10){
          row.put("length_weight","7吨")
        }else if(mload>10 && mload<=17){
          row.put("length_weight","14吨")
        }else if(mload>17 && mload<=25){
          row.put("length_weight","20吨")
        }else{
          row.put("length_weight","30吨")
        }
      }
      Row(row.getString("vehicle_serial"),
        row.getString("mload_cc"),
        row.getString("length"),
        row.getString("axle_number_cc"),
        row.getString("weight"),
        row.getString("length_weight")
      )
    })

    val schema =  StructType(List(
      StructField("vehicle_serial",StringType,nullable = true),
      StructField("mload_cc",StringType,nullable = true),
      StructField("length",StringType,nullable = true),
      StructField("axle_number_cc",StringType,nullable = true),
      StructField("weight",StringType,nullable = true),
      StructField("length_weight",StringType,nullable = true))
    )


    spark.createDataFrame(resultRdd,schema)
  }



  /**
    * 获取车参数据
    */
  def eta_std_line_recall1(inc_day:String, spark:SparkSession)={

    import spark.implicits._

    // 根据vehicle_serial去重，每个车牌保留最新一条记录
    val resourceDF = spark.sql(
      s"""
         |select
         |    vehicle_serial,
         |    actual_capacity_load as mload_rw,
         |    axls_number as axle_number_rw,
         |    actual_depart_tm
         |    from dm_gis.eta_std_line_recall1
         |    where inc_day >='${inc_day}'
       """.stripMargin)

    //    length_weight赋值逻辑详见载货，任意为空则根据mload赋值
    resourceDF
      .withColumn("rn",row_number()over(Window.partitionBy('vehicle_serial).orderBy(desc("actual_depart_tm"))))
      .filter(row  => {1==row.getAs[Int]("rn")})
  }





  /**
    * 获取任务监控数据
    */
  def gisEtaTsAccuralParse(inc_day:String, spark:SparkSession)={

    import spark.implicits._

    val resourceDF = spark.sql(
      s"""
         |select *
         | from dm_gis.gis_eta_ts_accural_parse2
         |     where
         |     inc_day='${inc_day}'
         |     and
         |     length(task_id) > 20
       """.stripMargin)

    resourceDF.withColumn("line_code",concat('start_dept , lit("_"),'end_dept))
      .withColumn("linevehicle",concat('start_dept , lit("_"),'end_dept, lit("_"),'vehicle_type))
      .withColumn("is_run_ontime",'ac_is_run_ontime)

  }


  /**
    * 获取行车日志明细数据
    */
  def ttVmsDrivingLogItem(inc_day:String, spark:SparkSession)={

    val inc_month = DateUtil.getMonthsBeforeOrAfter(inc_day,0 ).substring(0,6) //上月最后一天

    val last_month =DateUtil.getMonthsBeforeOrAfter(inc_day,-1 ).substring(0,6)  //上月最后一天


    val sql  =
      s"""
         |select
         |sum(road_fee) road_fee,sum(miles) miles,task_id
         |from
         |(select
         |task_id,road_fee,miles
         |from
         |(select
         |row_number() over(partition by driving_log_item_id order by created_tm desc) as id,*
         |from
         |(select
         |task_id,road_fee,miles,start_tm,driving_log_item_id,created_tm
         |from
         |ods_vms.tt_vms_driving_log_item
         |where
         |inc_month >= '${last_month}'
         |and inc_month <= '${inc_month}'
         |and length(task_id) > 20) as t1) as t2
         |where id = 1) as t3
         |group by task_id
         |
       """.stripMargin

    logger.error(sql)

    spark.sql(sql)

  }


  /**
    * 获取价值线路配置表
    */
  def etaStdLineConf(inc_day:String, spark:SparkSession)={
    val etaStdLineDf =  spark.sql(
      s"""
         |select
         |  a.std_id ,
         |  a.add_reason,
         |  b.value_time as online_date,
         |  a.create_time
         |from
         |  dm_gis.eta_std_line_conf a
         |  left join dm_gis.eta_std_line_prop b on a.std_id = b.std_id
         |where
         |  a.delete_flag = '0'
         |  and is_econ = '0'
         |  and value_time is not null
         |  and value_time <> ''
       """.stripMargin)


    //存在多条数据的取最新一条数据
    import spark.implicits._

    val rowNumDf  = etaStdLineDf.withColumn("std_id_jz",'std_id)
      .withColumn("std_id_jz_time", when('online_date < "20221231", lit("20230101"))
        .otherwise(from_unixtime(unix_timestamp('online_date,"yyyy-MM-dd HH:mm:ss"),"yyyyMMdd")))
      .withColumn("rn",row_number()over(Window.partitionBy("std_id").orderBy(desc("create_time"))))

    val resultDf =  rowNumDf.filter(row  =>{1 == row.getAs[Int]("rn")})
      .drop("create_time")
      .drop("rn")

    resultDf.map(row  => {
      val  add_reason = row.getAs[String]("add_reason")
      var  add_reason_new = "标准"
      if(!StringUtils.isEmpty(add_reason)){
        if(!(add_reason.contains("融合")||add_reason.contains("未来排班")) && add_reason.contains("新方案")&& add_reason.contains("旧方案")){
          add_reason_new = "多源"
        }else if((add_reason.contains("融合")||add_reason.contains("未来排班")) && !add_reason.contains("新方案")&& add_reason.contains("旧方案")){
          add_reason_new = "多源"
        }else if((add_reason.contains("融合")||add_reason.contains("未来排班")) && add_reason.contains("新方案")&& !add_reason.contains("旧方案")){
          add_reason_new = "多源"
        }else if(!(add_reason.contains("融合")||add_reason.contains("未来排班")) && !add_reason.contains("新方案")&& !add_reason.contains("旧方案")){
          add_reason_new = "标准"
        }else if((add_reason.contains("融合")||add_reason.contains("未来排班")) && !add_reason.contains("新方案")&& !add_reason.contains("旧方案")){
          add_reason_new = "融合"
        }else if(!(add_reason.contains("融合")||add_reason.contains("未来排班")) && add_reason.contains("新方案")&& !add_reason.contains("旧方案")){
          add_reason_new = "新方案"
        }else if(!(add_reason.contains("融合")||add_reason.contains("未来排班")) && !add_reason.contains("新方案")&& add_reason.contains("旧方案")){
          add_reason_new = "旧方案"
        }
      }
      (row.getAs[String]("std_id"),add_reason_new,row.getAs[String]("online_date")
        ,row.getAs[String]("std_id_jz"),row.getAs[String]("std_id_jz_time"))
    }).toDF("std_id","add_reason","online_date","std_id_jz","std_id_jz_time")
  }


}
