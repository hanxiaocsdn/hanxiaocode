package app

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
 * GIS-RSS-SCM：【司机计提】异常封车数据对接tcas_V1.0
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：941861
 * 任务名称：异常封车月度统计
 */
object CarSealExceptionMonth  extends  DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def execute(spark: SparkSession, inc_day: String) = {
    val before_month = DateUtil.getMouthBefore(inc_day, 1).substring(0,6)

    import spark.implicits._
    val car_seal_sql =
      s"""
         |select
         |  task_id,
         |  dept_code,
         |  breach_of_contract_detailed,
         |  main_driver_account,
         |  driver_name,
         |  appeal_process_status,
         |  audit_result,
         |  plan_send_time,
         |  actual_arrival_date,
         |  update_time
         |from
         |  dm_gis.car_seal_exception
         |""".stripMargin
    println(car_seal_sql)

    val df_car_seal = spark.sql(car_seal_sql)
      .withColumn("month",substring(regexp_replace('actual_arrival_date,"-",""),0,6))
      .filter('month === before_month)  // 保留实际到车时间为上个月的任务
      .withColumn("task_id",concat_ws("",'dept_code,'task_id))
      .withColumn("audit_result_type",concat_ws("|",collect_list('audit_result).over(Window.partitionBy("task_id"))))
      .filter(('breach_of_contract_detailed === "28" and !'audit_result_type.contains("1")) // 扣罚任务
        or ('breach_of_contract_detailed === "29" and !'audit_result_type.contains("2")))             // 奖励任务
      .withColumn("rn", row_number().over(Window.partitionBy("task_id","breach_of_contract_detailed").orderBy(desc("update_time"))))
      .filter('rn === 1)  // 去重
      .coalesce(1)

    val cols_1 = spark.sql("""select * from dm_gis.car_seal_exception_month limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_car_seal.select(cols_1: _*),Seq("month"),"dm_gis.car_seal_exception_month")
  }


  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error(s"++++++++  任务开始  inc_day=$inc_day  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成 20231218  ++++")

    spark.stop()
  }

}
