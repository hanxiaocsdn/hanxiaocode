package app.route

import com.sf.gis.java.base.util.SparkUtil

import java.sql.{Connection, DriverManager, PreparedStatement, ResultSet}
import com.sf.gis.scala.base.spark.Spark
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql._
import org.apache.spark.sql.functions.col

/**
 * 任务名称：eta_std_line_nostop_季度分表数据入库
 * 需求描述:需将自营任务信息详情表同步至BDP供业务高宇做数据分析使用，gis平台无法大批量导出数据
 * 需求方：ft220114 李非龙
 * 研发: 01390943 周勇
 * 日期: 20230808
 * 任务id:785950
 **/

object LineNostopToHive extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    //获取传入参数日期
    val inc_day1: String = args(0)
    val inc_day2: String = args(1)
    logger.error("参数inc_day1："+inc_day1)
    logger.error("参数inc_day2："+inc_day2)
    //判断月份所在的季度
    val year=inc_day1.substring(0,4)
    val fix=inc_day1.substring(4,6)

    val tb_fix=if(fix=="01" || fix=="02" || fix=="03" ){year.concat("01")}
    else if(fix=="04" || fix=="05" || fix=="06" ){year.concat("02")}
    else if(fix=="07" || fix=="08" || fix=="09" ){year.concat("03")}
    else if(fix=="10" || fix=="11" || fix=="12" ){year.concat("04")}
    else {"xxxxx"}

    val mysqltable="eta_std_line_nostop_".concat(tb_fix)

    mysqlToHive(spark,mysqltable,inc_day1,inc_day2)

    logger.error(">>>>>>执行完毕")
  }

  def mysqlToHive(spark: SparkSession, mysqlTable: String,inc_day1: String,inc_day2: String): Unit = {
    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://plan-s1.db.sfcloud.local:3306/plan?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val userName = "bdp"
    val passWd = "cB0C25#10E2D60nA032D"
    val tableName=
      s"""
         |(select
         |id,
         |rn,
         |task_area_code,
         |carrier_name,
         |task_id,
         |start_dept,
         |end_dept,
         |start_type,
         |end_type,
         |line_code,
         |vehicle_serial,
         |actual_capacity_load,
         |plan_depart_tm,
         |actual_depart_tm,
         |plan_arrive_tm,
         |actual_arrive_tm,
         |driver_id,
         |driver_name,
         |line_time,
         |line_distance,
         |actual_run_time,
         |is_stop,
         |carrier_type,
         |vehicle_type,
         |log_dist,
         |duration,
         |time,
         |rt_dist,
         |highwaymileage,
         |toll_charge,
         |pns_dist,
         |pns_time,
         |task_inc_day ,
         |ac_is_run_ontime,
         |src,
         |conduct_type,
         |if_evaluate_time,
         |if_error,
         |stop_over_zone_code,
         |std_toll_charge,
         |diffratio_log_rt,
         |accrual_money,
         |accrual_dist,
         |accrual_dist_type,
         |accrual_dist_source,
         |base_accrual_dist,
         |last_update_tm,
         |confirm_login_name,
         |confirm_time,
         |confirmed,
         |main_driver_account,
         |confirm_source,
         |deputy_driver_account,
         |deputy_driver_name,
         |driver_operate_type,
         |source,
         |deputy_accrual_money,
         |type,
         |time_type,
         |require_category,
         |task_type,
         |if_appeal,
         |appeal_result,
         |transoport_level,
         |total_oil_consumption,
         |oil_cost,
         |total_cost,
         |src_city_name,
         |dest_city_name,
         |child_carrier_name,
         |child_carrier_id
         |from $mysqlTable
         |where task_inc_day>=$inc_day1 and task_inc_day<$inc_day2
         |) as t
         |""".stripMargin

    logger.error(s"开始读取MySQL:$mysqlTable 表中数据")

    import spark.implicits._
    val orignal_df: DataFrame = spark
      .read
      .format("jdbc")
      .option("encoding","utf-8")
      .option("url", url)
      .option("user", userName)
      .option("password", passWd)
      .option("dbtable", tableName)
      .option("driver", driver)
      .option("numPartitions", 5)
      .option("fetchsize", 1000)
      .option("batchsize", 1000)
      .load().toDF()
      .filter($"task_inc_day".isNotNull && $"task_inc_day"=!="")
      .withColumn("inc_day",$"task_inc_day")

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.eta_std_line_nostop_all limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark, orignal_df.select(table_cols: _*), Seq("inc_day"), "dm_gis.eta_std_line_nostop_all")

  }

}
