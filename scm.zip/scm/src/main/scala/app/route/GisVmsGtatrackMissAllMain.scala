package app.route

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon

import java.sql.{Connection, PreparedStatement}
import java.util.Properties
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import utils.CommonTools.{getCurrentDate, getdaysBefore}

/**
**研发：01420395蔡国房、01390943周勇
**任务id：旧的任务id：716489，新的任务id：789421，结果表：gis_vms_gta_track_miss_all
**需求名：轨迹缺失表 需求ID 1749828  GIS-RSS-ETA：【时效专项】轨迹缺失表需求说明书_V1.0
**需求背景：规范车辆在途轨迹缺失问题，支撑业务落地车辆轨迹缺失考核，提供指标监控支持；针对承运商维度的指标监控，可以从承运商维度定位并解决轨迹缺失问题。
**需求日期： 2023/04/19
 **/

object GisVmsGtatrackMissAllMain   extends  DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    logger.error(">>>>>初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._
    val inc_day = args(0)

    gisVmsGtatrackMissAll(spark, inc_day)
    logger.error(s">>>>>COMPLETELY SUCCESS!")
  }

  /**
   * 轨迹缺失计算
   * @param sparkSession
   * @param inc_day
   */
  def  gisVmsGtatrackMissAll(sparkSession: SparkSession ,inc_day: String): Unit ={

    val beforeSevenDate = getdaysBefore(inc_day,-7,"yyyyMMdd")

    val before14Date = getdaysBefore(inc_day,-20,"yyyyMMdd")

    // 1	dm_gis	eta_std_line_recall1	标准路由回溯表1
    val etaStdLineRecallRdd = getEtaStdLineRecallRdd(sparkSession,inc_day,beforeSevenDate)

    // 2	dm_gis	gis_vms_gta_track_miss	轨迹缺失重算日志
    val gisVmsGtaTrackMissRdd = getGisVmsGtaTrackMissRdd(sparkSession,inc_day,before14Date)

    // 3	dm_arss	dm_device_hh_dtl_di	护航设备明细表
    val dmDeviceHhDtlDiRdd = getDmDeviceHhDtlDiRdd(sparkSession,inc_day,beforeSevenDate)

    //4. grd新任务明细 需求迭代 20230609 需求id 1828959
    val grd_new_task_detail_Rdd = getgrd_new_task_detailRdd(sparkSession,inc_day,beforeSevenDate)

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._
    val etaStdLineRecallRdd2 =  etaStdLineRecallRdd
      .join(gisVmsGtaTrackMissRdd,Seq("task_id"), "left")
      .join(dmDeviceHhDtlDiRdd,'vehicle_serial==='carplate, "left")
      .join(grd_new_task_detail_Rdd,Seq("task_id"),"left")
      //轨迹开始时间小于设备创建时间, imei 置空
      .withColumn("diff",'actual_depart_tm <= 'createtime)
      .withColumn("imei",when('actual_depart_tm <= 'createtime, lit("")).otherwise('imei))

    val etaStdLineRecallRdd1 =etaStdLineRecallRdd2
      .select('task_id
        ,'carrier_type
        ,'vehicle_serial
        ,'line_code
        ,'start_dept
        ,'end_dept
        ,'actual_depart_tm
        ,'actual_arrive_tm
        ,'actual_run_time
        ,'transoport_level
        ,'if_evaluate_time
        ,'task_inc_day
        ,'ac_is_run_ontime
        ,'crossFlag
        ,'inc_day_new
        ,'continueTm
        ,'startTime1
        ,'startTime
        ,'endTime1
        ,'endTime
        ,'recalculateStartTime1
        ,'recalculateStartTime
        ,'recalculateEndTime1
        ,'recalculateEndTime
        ,'recalculateContinueTm
        ,'time_slot
        ,'max_continueTm
        ,'max_time_slot
        ,'imei
        ,'is_security
        ,'zytype
        ,'data_channel
        ,'sync_day
        ,'etl_time
        ,'deleteflag
        ,'max_startTime
        ,'max_endTime
        ,'actual_carrier_name
        ,'createtime.as("create_tm")
        ,'inc_day
      ).distinct()

    import org.apache.spark.sql.functions._
    //获取原有数据dm_gis.gis_vms_gta_track_miss_all
    val incDayList =  etaStdLineRecallRdd1.select(concat_ws(",", collect_set('inc_day))).as("inc_days").collectAsList()
    val incDayListStr = incDayList.get(0).mkString("(",",",")")
    logger.error("获取的日期包含 " + incDayListStr)

    //数据推送往前前面推一天,把当天的日期数据删除
    val incDayCKList =  etaStdLineRecallRdd1.filter('inc_day  =!= inc_day)
      .select(concat_ws("','", collect_set('inc_day))).as("inc_days")
      .collectAsList()

    val incDayListCKStr = incDayCKList.get(0).mkString("('",",","')")
    logger.error("获取的CK日期包含 " + incDayListCKStr)

    val gisVmsGtaTrackMissAllRdd = getGisVmsGtaTrackMissAll(sparkSession,incDayListStr)

   //etaStdLineRecallRdd1.filter('task_id ==="020Y16161556").show(1, false )

    //过滤对应的重复的数据
    val gisVmsGtaTrackMissAllRdd1 =  gisVmsGtaTrackMissAllRdd
      .join(etaStdLineRecallRdd1,Seq("task_id"),"left")
      .filter(etaStdLineRecallRdd1("task_id") isNull )
      .select(gisVmsGtaTrackMissAllRdd("task_id")
        ,gisVmsGtaTrackMissAllRdd("carrier_type")
        ,gisVmsGtaTrackMissAllRdd("vehicle_serial")
        ,gisVmsGtaTrackMissAllRdd("line_code")
        ,gisVmsGtaTrackMissAllRdd("start_dept")
        ,gisVmsGtaTrackMissAllRdd("end_dept")
        ,gisVmsGtaTrackMissAllRdd("actual_depart_tm")
        ,gisVmsGtaTrackMissAllRdd("actual_arrive_tm")
        ,gisVmsGtaTrackMissAllRdd("actual_run_time")
        ,gisVmsGtaTrackMissAllRdd("transoport_level")
        ,gisVmsGtaTrackMissAllRdd("if_evaluate_time")
        ,gisVmsGtaTrackMissAllRdd("task_inc_day")
        ,gisVmsGtaTrackMissAllRdd("ac_is_run_ontime")
        ,gisVmsGtaTrackMissAllRdd("crossFlag")
        ,gisVmsGtaTrackMissAllRdd("inc_day_new")
        ,gisVmsGtaTrackMissAllRdd("continueTm")
        ,gisVmsGtaTrackMissAllRdd("startTime1")
        ,gisVmsGtaTrackMissAllRdd("startTime")
        ,gisVmsGtaTrackMissAllRdd("endTime1")
        ,gisVmsGtaTrackMissAllRdd("endTime")
        ,gisVmsGtaTrackMissAllRdd("recalculateStartTime1")
        ,gisVmsGtaTrackMissAllRdd("recalculateStartTime")
        ,gisVmsGtaTrackMissAllRdd("recalculateEndTime1")
        ,gisVmsGtaTrackMissAllRdd("recalculateEndTime")
        ,gisVmsGtaTrackMissAllRdd("recalculateContinueTm")
        ,gisVmsGtaTrackMissAllRdd("time_slot")
        ,gisVmsGtaTrackMissAllRdd("max_continueTm")
        ,gisVmsGtaTrackMissAllRdd("max_time_slot")
        ,gisVmsGtaTrackMissAllRdd("imei")
        ,gisVmsGtaTrackMissAllRdd("is_security")
        ,gisVmsGtaTrackMissAllRdd("zytype")
        ,gisVmsGtaTrackMissAllRdd("data_channel")
        ,gisVmsGtaTrackMissAllRdd("sync_day")
        ,gisVmsGtaTrackMissAllRdd("etl_time")
        ,gisVmsGtaTrackMissAllRdd("deleteflag")
        ,gisVmsGtaTrackMissAllRdd("max_startTime")
        ,gisVmsGtaTrackMissAllRdd("max_endTime")
        ,gisVmsGtaTrackMissAllRdd("actual_carrier_name")
        ,gisVmsGtaTrackMissAllRdd("create_tm")
        ,gisVmsGtaTrackMissAllRdd("inc_day")
      )

    val resultRdd  = gisVmsGtaTrackMissAllRdd1.union(etaStdLineRecallRdd1)

    //resultRdd.filter('task_id ==="020Y16161556").show(1, false )

    writeToHive(sparkSession, resultRdd,Seq("inc_day"),"dm_gis.gis_vms_gta_track_miss_all")
    val df2= sparkSession.sql("select  * from dm_gis.gis_vms_gta_track_miss_all where inc_day in " + incDayListCKStr)
    logger.error("etl总数据 " + df2.count())

    //存放到clickhouse
    saveToClickhouse(sparkSession, df2.drop("etl_time","deleteflag","max_startTime","max_endTime"),incDayListCKStr)
  }

  def saveToClickhouse(spark: SparkSession,df:DataFrame,inc_days: String): Unit = {
    val conn: Connection = getSmartDevCKConnect()
    try {
      val delSql = s"ALTER TABLE gis_oms_uimp_vs.gis_vms_gta_track_miss_all DELETE WHERE inc_day in ${inc_days}"
      val del: PreparedStatement = conn.prepareStatement(delSql)
      del.execute()
    } catch {
      case ex: Exception => logger.error(s"删除表 gis_oms_uimp_vs.gis_vms_gta_track_miss_all 中 ${inc_days}数据时出现错误", ex)
        throw ex
    }

    val ck_url = "jdbc:clickhouse://10.216.162.10:8123/gis_oms_uimp_vs"

    val ckProp = new Properties()

    //写入/out读出参数
    val ck_params = Map[String, String](
      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
      "batchsize" -> "20000",
      "isolationLevel" -> "NONE",
      "numPartitions" -> "1",
      "user" -> "gis_oms_vs",
      "password" -> "gis_oms_vs@123@"
    )

    //加载 hive 中的表数据
    df.write.mode(SaveMode.Append).options(ck_params)
      .jdbc(ck_url, s"gis_oms_uimp_vs.gis_vms_gta_track_miss_all", ckProp)

    //读出数据，检查是否写成功
    val querySQL = s"(SELECT *  FROM gis_oms_uimp_vs.gis_vms_gta_track_miss_all where inc_day in ${inc_days}) as tmp"

    val partData: DataFrame = spark.read
      .format("jdbc")
      .option("url", ck_url)
      .options(ck_params)
      .option("dbtable", querySQL)
      .load()
    partData.limit(20).collect().foreach(println(_))
    logger.error(s"insert into table gis_oms_uimp_vs.gis_vms_gta_track_miss_all,the count in ${inc_days}) is:" + partData.count())

  }

  /**
   * 标准路由回溯表 前面7天的数据
   * @param sparkSession
   * @param inc_day
   * @param beforeSevenDate
   * @return
   */
  def  getEtaStdLineRecallRdd(sparkSession: SparkSession ,inc_day: String, beforeSevenDate: String ):DataFrame= {

    val etaStdLineRecallSql =
      s"""
         |select
         |  task_id, -- 任务ID
         |  carrier_type,-- 承运商类型(1外包，0自营)
         |  start_dept,-- 始发网点
         |  end_dept,-- 目的网点
         |  line_code,-- 线路编码
         |  vehicle_serial,-- 车牌号
         |  transoport_level,-- 运输等级(1一级运输，2二级运输，3三级运输，4短驳)
         |  actual_depart_tm,-- 实际发车时间
         |  case when actual_arrive_tm is null then from_unixtime(unix_timestamp(actual_depart_tm)+cast(actual_run_time as int)*60)  else actual_arrive_tm end as  actual_arrive_tm,-- 实际到车时间
         |  actual_run_time,-- 实际运行时长(min)
         |  task_inc_day,-- 任务日期
         |  ac_is_run_ontime,-- 是否准点
         |  last_update_tm, --
         |  if_evaluate_time -- 任务是否考核时效
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day >= '${beforeSevenDate}' and inc_day <= '${inc_day}'
         |
      """.stripMargin

    logger.error(etaStdLineRecallSql)

    val etaStdLineRecallDF  = sparkSession.sql(etaStdLineRecallSql)

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._
    //以task_id进行分组,  last_update_tm 倒序 获取时间最新的一条数据
    val etaStdLineRecallNewDF = etaStdLineRecallDF.
      withColumn("inc_day_new",from_unixtime(unix_timestamp('actual_arrive_tm, "yyyy-MM-dd HH:mm:ss"), "yyyy-MM-dd"))
      .withColumn("rowNum",row_number()over(Window.partitionBy('task_id).orderBy(desc("last_update_tm"))))
      .withColumn("etl_time",lit(getCurrentDate("yyyy-MM-dd HH:mm:ss")))

    val resultDF = etaStdLineRecallNewDF.filter('rowNum===1)
      .drop("rowNum").withColumn("inc_day", from_unixtime(unix_timestamp('inc_day_new, "yyyy-MM-dd"), "yyyyMMdd"))

    resultDF
  }

  /**
   * 标准路由回溯表 前面7天的数据
   * @param sparkSession
   * @param inc_day
   * @param beforeSevenDate
   * @return
   */
  def  getGisVmsGtaTrackMissAll(sparkSession: SparkSession ,incDayList: String):DataFrame= {
    val gisVmsGtaTrackMissAllSql =
      s"""
         |SELECT task_id,carrier_type,vehicle_serial,line_code,start_dept,end_dept,actual_depart_tm,actual_arrive_tm,actual_run_time,transoport_level,if_evaluate_time,task_inc_day,ac_is_run_ontime,crossflag,inc_day_new,continuetm,starttime1,starttime,endtime1,endtime,recalculatestarttime1,recalculatestarttime,recalculateendtime1,recalculateendtime,recalculatecontinuetm,time_slot,max_continuetm,max_time_slot,imei,is_security,zytype,data_channel,sync_day,etl_time,inc_day
         |,max_startTime
         | ,max_endTime
         | ,deleteflag
         | ,actual_carrier_name
         |, create_tm
         |FROM dm_gis.gis_vms_gta_track_miss_all
         |where
         |  inc_day in ${incDayList}
         |
      """.stripMargin

    logger.error(gisVmsGtaTrackMissAllSql)

    val etaStdLineRecallDF  = sparkSession.sql(gisVmsGtaTrackMissAllSql)
    etaStdLineRecallDF
  }

  /**
   * 新接口表 前面7天的数据
   * @param sparkSession
   * @param inc_day
   * @param beforeSevenDate
   * @return
   */
  def  getGisVmsGtaTrackMissRdd(sparkSession: SparkSession ,inc_day: String, beforeSevenDate: String ):DataFrame= {

    val gisVmsGtaTrackMissSql =
      s"""
         select
         |task_id,
         |continuetm,-- 缺失时长
         |starttime1,-- 缺失开始时间（时间戳）
         |starttime,-- 缺失开始时间
         |endtime1,-- 缺失结束时间（时间戳）
         |endtime,-- 缺失结束时间
         |recalculatestarttime1,-- 重算缺失开始时间（时间戳）
         |recalculatestarttime,-- 重算缺失开始时间
         |recalculateendtime1,-- 重算缺失结束时间（时间戳）
         |recalculateendtime,-- 重算缺失结束时间
         |recalculatecontinuetm,-- 重算缺失时长
         |crossFlag,
         |time_slot,--重算缺失时间段
         |inc_day
         |from dm_gis.gis_vms_gta_track_miss
         |where inc_day >= '${beforeSevenDate}' and inc_day <='${inc_day}'
      """.stripMargin

    logger.error(gisVmsGtaTrackMissSql)

    val gisVmsGtaTrackMissDF  = sparkSession.sql(gisVmsGtaTrackMissSql)

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._
    //以task_id进行分组,  last_update_tm 倒序 获取时间最新的一条数据
    val gisVmsGtaTrackMissNewDF_1 = gisVmsGtaTrackMissDF
      .distinct()
      .withColumn("recalculateContinueTm_int", when(isnull('recalculateContinueTm),0)
        .otherwise('recalculateContinueTm.cast("Int")))
      .withColumn("time_slot_int",
        when('time_slot==="[0-600)",1)
          .when('time_slot==="[600-1800)",2)
          .when('time_slot==="[1800-3600)",3)
          .when('time_slot==="[3600-7200)",4)
          .when('time_slot==="2小时以上",5)
          .otherwise(0))
      .orderBy(asc("task_id"),asc("starttime"))

    val gisVmsGtaTrackMissNewDF_3 = gisVmsGtaTrackMissNewDF_1
      .withColumn("max_continueTm",max('recalculateContinueTm_int)over(Window.partitionBy('task_id,'inc_day)))
      .withColumn("max_time_slot",max('time_slot_int)over(Window.partitionBy('task_id, 'inc_day )))
      .withColumn("rn",row_number()over(Window.partitionBy('task_id).orderBy(desc("inc_day"), desc("recalculateContinueTm_int"))))

    //找到最大max_continueTm 所对应的最小开始时间
    val maxStartEndTimeDF1 =  gisVmsGtaTrackMissNewDF_3
      .filter('max_continueTm==='recalculateContinueTm_int &&  'rn ===1)
      .withColumn("min_start_time", min('starttime)over(Window.partitionBy('task_id)))
      .select('task_id,'min_start_time,'recalculatestarttime,'recalculateendtime)

    //找到对应开始时间所对应的 开始时间和结束时间 成为最大开始时间和最大结束时间
    val maxStartEndTimeDF2 =  maxStartEndTimeDF1
      .filter('min_start_time==='starttime)
      .withColumn("max_startTime",'recalculatestarttime)
      .withColumn("max_endTime",'recalculateendtime)
      .drop('recalculatestarttime)
      .drop('recalculateendtime)
      .drop('min_start_time)

    val maxStartEndTimeDF = maxStartEndTimeDF2.distinct()
    //maxStartEndTimeDF.filter('task_id ==="020Y16161556").show(1, false )

    val gisVmsGtaTrackMissNewDF_4 = gisVmsGtaTrackMissNewDF_3
      .withColumn("continuetm",concat_ws("|",collect_list('continuetm)over(Window.partitionBy('task_id,'inc_day))))
      .withColumn("starttime1",concat_ws("|", collect_list('starttime1)over(Window.partitionBy('task_id,'inc_day)) ))
      .withColumn("endtime1",concat_ws("|", collect_list('endtime1)over(Window.partitionBy('task_id,'inc_day)) ))
      .withColumn("endtime",concat_ws("|", collect_list('endtime)over(Window.partitionBy('task_id,'inc_day)) ))
      .withColumn("recalculatestarttime1",concat_ws("|", collect_list('recalculatestarttime1)over(Window.partitionBy('task_id,'inc_day)) ))
      .withColumn("recalculatestarttime",concat_ws("|", collect_list('recalculatestarttime)over(Window.partitionBy('task_id,'inc_day)) ))
      .withColumn("recalculateendtime1",concat_ws("|", collect_list('recalculateendtime1)over(Window.partitionBy('task_id,'inc_day)) ))
      .withColumn("recalculateendtime",concat_ws("|", collect_list('recalculateendtime)over(Window.partitionBy('task_id,'inc_day)) ))
      .withColumn("recalculatecontinuetm",concat_ws("|", collect_list('recalculatecontinuetm)over(Window.partitionBy('task_id,'inc_day)) ))
      .withColumn("time_slot",concat_ws("|", collect_list('time_slot)over(Window.partitionBy('task_id,'inc_day))))

    val gisVmsGtaTrackMissNewDF_2 = gisVmsGtaTrackMissNewDF_4
      .withColumn("starttime",concat_ws("|",collect_list('starttime)over(Window.partitionBy('task_id,'inc_day))))

    val gisVmsGtaTrackMissNewDF_5 = gisVmsGtaTrackMissNewDF_2
      .withColumn("rn",row_number()over(Window.partitionBy('task_id).orderBy('task_id,desc("inc_day"))))
      .drop('recalculateContinueTm_int)

    val gisVmsGtaTrackMissNewDF_6 = gisVmsGtaTrackMissNewDF_5.filter('rn===1)

    val gisVmsGtaTrackMissNewDF = gisVmsGtaTrackMissNewDF_6
      .withColumn("max_time_slot",
        when('max_time_slot===1,"[0-600)")
          .when('max_time_slot===2,"[600-1800)")
          .when('max_time_slot===3,"[1800-3600)")
          .when('max_time_slot===4,"[3600-7200)")
          .when('max_time_slot===5,"2小时以上"))
      .distinct()

   // gisVmsGtaTrackMissNewDF.filter('task_id ==="771Y5755515").show(10, true )

    val resultDF =  gisVmsGtaTrackMissNewDF.join(maxStartEndTimeDF,Seq("task_id"),"left")
      .drop('inc_day)

    resultDF.filter('task_id ==="888Y11689995")
      .show(1, false )

    resultDF
  }

  /**
   * 护航设备明细表
   * @param sparkSession
   * @param inc_day
   * @param beforeSevenDate
   * @return
   */
  def  getDmDeviceHhDtlDiRdd(sparkSession: SparkSession ,inc_day: String, beforeSevenDate: String ):DataFrame= {

    val dmDeviceHhDtlDiSql =
      s"""
         |select
         |carplate,imei ,
         |is_security,zytype,data_channel,sync_day,deleteflag,
         |case when createtime is null then updatetime else createtime end as createtime
         |from dm_arss.dm_device_hh_dtl_di
         |where
         |inc_day = '${inc_day}'
         |and deleteflag = 0
         |
      """.stripMargin

    logger.error(dmDeviceHhDtlDiSql)

    val dmDeviceHhDtlDiDF  = sparkSession.sql(dmDeviceHhDtlDiSql)

    dmDeviceHhDtlDiDF
  }

  /**
   * 护航设备明细表
   * @param sparkSession
   * @param inc_day
   * @param beforeSevenDate
   * @return
   */
  def  getgrd_new_task_detailRdd(sparkSession: SparkSession ,inc_day: String, beforeSevenDate: String ):DataFrame= {

    val beforeDate = getdaysBefore(inc_day,-20,"yyyyMMdd")

    val afterDate = getdaysBefore(inc_day,20,"yyyyMMdd")

    val getgrd_new_task_detailSql =
      s"""
         |select distinct
         |task_id,actual_carrier_name
         |from dm_grd.grd_new_task_detail
         |where
         |inc_day between '${beforeDate}' and   '${afterDate}'
         |
      """.stripMargin

    logger.error(getgrd_new_task_detailSql)
    val getgrd_new_task_detailDF  = sparkSession.sql(getgrd_new_task_detailSql)

    getgrd_new_task_detailDF
  }

  /**
   *CK数据库连接
   */
  def getSmartDevCKConnect(): Connection = {

    val url = "jdbc:clickhouse://10.216.162.10:8123/gis_oms_uimp_vs"
    //驱动名称
    val driver = "ru.yandex.clickhouse.ClickHouseDriver"
    //用户名
    val username = "gis_oms_vs"
    //密码
    val password = "gis_oms_vs@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      import java.sql.{Connection, DriverManager}
      var connection: Connection = null
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => {
        logger.error("连接clickhouse数据库时出现错误", ex)
        throw ex
      }
    }
  }

}