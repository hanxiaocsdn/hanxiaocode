package app.route


import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.TimeDef.{getdaysBeforeOrAfter, getminisBeforeOrAfter, getmonthsBeforeOrAfter, getnow_minit}
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.text.SimpleDateFormat

import scala.collection.mutable.ListBuffer

/**
 *需求名称：定点加油数据监控需求
 *需求方：周思毅(01399920)，李建飞(01413751)
 *开发: 周勇(01390943)
 *任务创建时间：20221214
 *任务id：756360（每天06:10执行）
 **/

object OilStationRecommendDetail {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .config("spark.executor.memoryOverhead", "12G")
      .enableHiveSupport()
      .getOrCreate()
    val inc_day: String = args(0)
    //如1108跑数，取1101-1107
    val day_var7: String = getdaysBeforeOrAfter(inc_day,-6)
    //获取相对的当天日期
    val day_var_d: String = getdaysBeforeOrAfter(inc_day,1)
    //跑数当天所在本月时间
    val month0: String = getmonthsBeforeOrAfter(day_var_d,0)
    //跑数当天所在上月时间
    val month1: String = getmonthsBeforeOrAfter(day_var_d,-1)
    import spark.implicits._


    //执行表3，获取加油站的信息，增量更新
    //batch_get(spark,inc_day)

    val station_df=spark.sql("select * from dm_gis.online_config_oil_station_detail where inc_day='99990101' ")
      .withColumn("rank", row_number().over(Window.partitionBy("poiid")
        .orderBy(desc("updatetimestamp"))))
      .filter($"rank"===1)
      .filter($"del_flag"===0)
      .drop("inc_day","rank")


    //导航数据
    val navi_data_df=navi_data(spark, day_var7, inc_day).persist(StorageLevel.MEMORY_AND_DISK)


    //println("输出navi_data_df")
    //spark.sql("drop table if exists default.tempzy20221210x1navi_data_df")
    // navi_data_df.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1navi_data_df")


    //请求推荐入参表
    val query_hive_data_df=query_hive_data(spark, day_var7, inc_day).persist(StorageLevel.MEMORY_AND_DISK)


    //  println("输出query_hive_data_df")
    //  spark.sql("drop table if exists default.tempzy20221210x1query_hive_data_df")
    //   query_hive_data_df.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1query_hive_data_df")


    //请求推荐出参明细表
    val proto_hive_data_df=proto_hive_data(spark, day_var7, inc_day).persist(StorageLevel.MEMORY_AND_DISK)


    //    println("输出proto_hive_data_df")
    //  spark.sql("drop table if exists default.tempzy20221210x1proto_hive_data_df")
    //  proto_hive_data_df.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1proto_hive_data_df")


    //行车日志数据
    val driving_log_data_df=driving_log_data(spark, month0, month1).persist(StorageLevel.MEMORY_AND_DISK)

    //  println("输出driving_log_data_df")
    //   spark.sql("drop table if exists default.tempzy20221210x1driving_log_data_df")
    //   driving_log_data_df.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1driving_log_data_df")

    //入参关联出参:关联后根据taskId、oil_point去重, 保留fuelleftDistance最大的记录
    val join_data1=query_hive_data_df.join(proto_hive_data_df,Seq("requestid"),"left")
      .withColumn("rank",row_number().over(Window.partitionBy("taskid","rec_oil_point")
        .orderBy(desc("fuelleftdistance"))))
      .filter($"rank"===1)
      .drop("rank")
      .withColumn("sn",row_number().over(Window.partitionBy("taskid")
        .orderBy(asc("reqtime")))).persist(StorageLevel.MEMORY_AND_DISK)


    // println("输出join_data1")
    //  spark.sql("drop table if exists default.tempzy20221210x1join_data1")
    //   join_data1.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1join_data1")

    //入参关联出参:合并油站、油价等计算指标
    val join_data2= join_data1.groupBy("requestid")
      .agg(
        concat_ws("&", collect_list("sn")) as "sn_list",
        concat_ws("&", collect_list("rec_oil_name")) as "rec_oil_name_list",
        concat_ws("&", collect_list("rec_oil_brand")) as "rec_oil_brand_list",
        concat_ws("&", collect_list("rec_oil_price")) as "rec_oil_price_list",
        concat_ws("&", collect_list("rec_oil_point")) as "rec_oil_point_list",
        concat_ws("&", collect_list("rec_coords")) as "rec_coords_list"

      )
      .withColumn("rec_oil_name", sortField('sn_list, 'rec_oil_name_list))
      .withColumn("rec_oil_brand", sortField('sn_list, 'rec_oil_brand_list))
      .withColumn("rec_oil_price", sortField('sn_list, 'rec_oil_price_list))
      .withColumn("rec_oil_point", sortField('sn_list, 'rec_oil_point_list))
      .withColumn("rec_coords", sortField('sn_list, 'rec_coords_list)).persist(StorageLevel.MEMORY_AND_DISK)


    //   println("输出join_data2")
    //  spark.sql("drop table if exists default.tempzy20221210x1join_data2")
    //  join_data2.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1join_data2")


    //入参关联出参:剩余指标排序取fuelLeftdistance最大值
    val join_data3= join_data1.withColumn("task_id",$"taskid")
      .select("task_id","fuelleftdistance","reqtime","isfuelpoint","litersnumber","unitprice","username","vehiclecode","requestid")
      .withColumn("rank",row_number().over(Window.partitionBy("task_id")
        .orderBy(desc("fuelleftdistance"))))
      .filter($"rank"===1)
      .drop("rank").persist(StorageLevel.MEMORY_AND_DISK)


    //     println("输出join_data3")
    //   spark.sql("drop table if exists default.tempzy20221210x1join_data3")
    //     join_data3.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1join_data3")


    //入参关联出参
    val join_data4=join_data3.join(join_data2,Seq("requestid"),"left")

    //  println("输出join_data4")
    //   spark.sql("drop table if exists default.tempzy20221210x1join_data4")
    //     join_data4.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1join_data4")

    //val join_data4 =join_data4a.drop("requestid").persist(StorageLevel.MEMORY_AND_DISK)

    //导航任务关联推荐详情
    val join_data5=navi_data_df.join(join_data4,Seq("task_id"),"left")
      .withColumn("if_req_fuel",when($"fuelleftdistance".isNotNull && $"fuelleftdistance" =!="","是").otherwise("否"))
      .withColumn("if_req_suc",when($"if_req_fuel"==="是" &&  $"rec_oil_point".isNotNull && trim($"rec_oil_point") =!="","是").
        when($"if_req_fuel"==="是" ,"否").
        otherwise(""))
      .drop(navi_data_df("requestid"))


    //  println("输出join_data5")
    //     spark.sql("drop table if exists default.tempzy20221210x1join_data5")
    //    join_data5.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1join_data5")

    import spark.implicits._
    //导航关联日志数据
    val join_data6=join_data5.withColumn("taskid",$"task_id")
      .join(driving_log_data_df,Seq("taskid"),"left")
      .withColumn("if_add_fuel", when($"addfuel_tm".isNotNull && $"addfuel_tm" =!="","是").otherwise("否"))
      .withColumn("task_type", when($"taskid".like("%-%"),"空驶").otherwise("载货"))
      .withColumn("part_coords",min_points_udf($"rec_oil_point",$"rec_coords"))

    //      println("输出join_data6")
    //    spark.sql("drop table if exists default.tempzy20221210x2join_data6")
    //    join_data6.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x2join_data6")


    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = excutors * cores * 3

    println("输出sql_Rdd")
    //转化rdd
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, join_data6, calPartitions).repartition(30)


    println("输出QilpointRdd_result")
    val QilpointRdd_result=Multi_Oilpoint(spark,sql_Rdd,calPartitions)
    println("输出Multi_Qmpoint_result")
    //并发获取qm接口
    val Multi_Qmpoint_result=Multi_Qmpoint(spark,QilpointRdd_result,calPartitions)

    //加油图片信息refuel
    val imgtype_refuel=spark.sql(
      s"""
         |select task_id,imgtype,osstemp_url as refuel_url,coordinate,inc_day
         |from dm_gis.gis_eta_navi_fuel_oil_with_picture
         |where inc_day>=$day_var7 and inc_day<=$inc_day and imgtype='Refuel'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("task_id")
        .orderBy(desc("inc_day"))))
      .filter($"rank"===1)
      .select("task_id","refuel_url","coordinate")

    //加油图片信息invoice
    val imgtype_invoice=spark.sql(
      s"""
         |select task_id,imgtype,osstemp_url as invoice_url,inc_day
         |from dm_gis.gis_eta_navi_fuel_oil_with_picture
         |where inc_day>=$day_var7 and inc_day<=$inc_day and imgtype='Invoice'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("task_id")
        .orderBy(desc("inc_day"))))
      .filter($"rank"===1)
      .select("task_id","invoice_url")

    println("输出Qilpoint_df")
    // val table_cols_tmp = spark.sql("""select * from dm_gis_scm.oil_station_recommend_detail7 limit 0""").schema.map(_.name).map(col)
    val Qilpoint_df: DataFrame = Multi_Qmpoint_result.map(
      obj=>{
        val inc_day=obj.getString("inc_day")
        val task_type=obj.getString("task_type")
        val task_id=obj.getString("task_id")
        val navi_id=obj.getString("navi_id")
        val app_ver=obj.getString("app_ver")
        val line_code=obj.getString("line_code")
        val start_dept=obj.getString("start_dept")
        val end_dept=obj.getString("end_dept")
        val driver_menbers=obj.getString("driver_menbers")
        val vehicle_serial=obj.getString("vehicle_serial")
        val if_add_fuel=obj.getString("if_add_fuel")
        val if_req_fuel=obj.getString("if_req_fuel")
        val if_req_suc=obj.getString("if_req_suc")
        val addfuel_tm=obj.getString("addfuel_tm")
        val addfuel_point=obj.getString("addfuel_point")
        val fuel_prices=obj.getString("fuel_prices")
        val fuel_qty=obj.getString("fuel_qty")
        val fuel_log_dist=obj.getString("fuel_log_dist")
        val total_amount=obj.getString("total_amount")
        val start_tm=obj.getString("start_tm")
        val end_tm=obj.getString("end_tm")
        val start_miles=obj.getString("start_miles")
        val end_miles=obj.getString("end_miles")
        val log_dist=obj.getString("log_dist")
        val fuel_left_distance=obj.getString("fuelleftdistance")
        val rec_oil_brand=obj.getString("rec_oil_brand")
        val rec_oil_name=obj.getString("rec_oil_name")
        val rec_oil_point=obj.getString("rec_oil_point")
        val rec_oil_price=obj.getString("rec_oil_price")
        val rec_coords=obj.getString("rec_coords")
        val addfuelstop_tm=obj.getString("addfuelstop_tm")
        val stpos_recpos_dist=obj.getString("stpos_recpos_dist")
        val st_rec_tm=obj.getString("st_rec_tm")
        val reqtime=obj.getString("reqtime")
        val adcode=Qmpoint_url_adcode(addfuel_point)
        val ret_result=obj.getString("ret_result")
        val ret_result_qm=obj.getString("ret_result_qm")

        objmodel(inc_day,task_type,task_id,navi_id,app_ver,line_code,start_dept,
          end_dept,driver_menbers,vehicle_serial,if_add_fuel,if_req_fuel,if_req_suc,addfuel_tm,addfuel_point,
          fuel_prices,fuel_qty,fuel_log_dist,total_amount,start_tm,end_tm,start_miles,end_miles,
          log_dist,fuel_left_distance,rec_oil_brand,rec_oil_name,rec_oil_point,rec_oil_price,rec_coords,
          addfuelstop_tm,stpos_recpos_dist,st_rec_tm,reqtime,adcode,ret_result,ret_result_qm)
      }
    ).toDF("inc_day","task_type","task_id","navi_id","app_ver","line_code","start_dept",
      "end_dept","driver_menbers","vehicle_serial","if_add_fuel","if_req_fuel",
      "if_req_suc","addfuel_tm","addfuel_point","fuel_prices","fuel_qty","fuel_log_dist",
      "total_amount","start_tm","end_tm","start_miles","end_miles","log_dist",
      "fuel_left_distance","rec_oil_brand","rec_oil_name","rec_oil_point","rec_oil_price","rec_coords","addfuelstop_tm",
      "stpos_recpos_dist","st_rec_tm","reqtime","adcode","ret_result","ret_result_qm")
      //20230224新增
      .join(imgtype_refuel,Seq("task_id"),"left")
      .join(imgtype_invoice,Seq("task_id"),"left")
      //addfuel_point合并上coordinate
      .withColumn("coordinate",when($"coordinate".isNull || trim($"coordinate") ==="",null).
        otherwise($"coordinate"))
      .withColumn("addfuel_point",when($"addfuel_point".isNull || trim($"addfuel_point") ==="",null).
        when($"coordinate".isNull || trim($"coordinate") ==="",$"addfuel_point").
        otherwise(concat_ws("|",$"addfuel_point",$"coordinate")))
      //替换null值，否则后面会出错
      .withColumn("addfuel_point",when($"addfuel_point".isNull || trim($"addfuel_point") ==="","").otherwise($"addfuel_point"))
      .withColumn("point_distance",when($"addfuel_point".isNull || $"rec_oil_point".isNull ||
        trim($"addfuel_point") === "" || trim($"rec_oil_point") === "" ,"")
        .otherwise(round(line_distance_udf($"addfuel_point",$"rec_oil_point"),4)))
      .withColumn("if_add_fuel_rec",when($"addfuel_point".isNull || $"rec_oil_point".isNull ||
        trim($"addfuel_point") === "" || trim($"rec_oil_point") === "" ,"").
        when($"point_distance".isNotNull && $"point_distance"=!="" && $"point_distance".cast("double")<150,"是").otherwise("否"))
      .withColumn("req_brand",lit(""))
      .withColumn("if_eu_dirver",lit(""))
      .withColumn("dirver_batch",lit(""))
      .withColumn("rec_addfuel_dist",OilPoint_addfuel_dist_udf($"vehicle_serial",$"reqtime",$"addfuel_tm"))
      .withColumn("adcode4",when($"adcode".isNull || $"adcode" === "","abcd").otherwise($"adcode".substr(0,4)))
      //产生一个唯一识别
      .withColumn("rank1",lit(1))
      .withColumn("onlyrank", row_number().over(Window.partitionBy("rank1")
        .orderBy(asc("inc_day"))))
    //.select(table_cols_tmp: _*)

    //      println("输出Qilpoint_df_asdasdasd")
    //   spark.sql("drop table if exists default.Qilpoint_df_asdasdasd")
    //   Qilpoint_df.write.mode("overwrite").format("parquet").saveAsTable("default.Qilpoint_df_asdasdasd")


    val Qilpoint_df2 =Qilpoint_df
      .drop("ret_result","ret_result_qm")
      .withColumn("addfuel_point_new",explode(split($"addfuel_point","[|]")))


    //由于执行结果集存为parquet的时候报错，bdp离线客服解释让我切换存储格式，因此这里采用中间表计算
    println("Qilpoint_df2:")
    Qilpoint_df2.createOrReplaceTempView("Qilpoint_df_tb2")

    //  //保存用于测试
    //   spark.sql("drop table if exists default.tempzy20221215Qilpoint_df2")
    //  Qilpoint_df2.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221215Qilpoint_df2")

    //  //保存用于测试
    //    spark.sql("drop table if exists default.tempzy20221215station_df")
    //   station_df.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221215station_df")

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.oil_station_recommend_detail limit 0""").schema.map(_.name).map(col)


    station_df.createOrReplaceTempView("station_df_tb")

    spark.sql("""insert overwrite table  dm_gis.oil_station_recommend_detail_middtl
                |select t1.inc_day,t1.task_type,t1.task_id,t1.navi_id,t1.app_ver,t1.line_code,
                |t1.start_dept,t1.end_dept,t1.driver_menbers,t1.vehicle_serial,t1.if_add_fuel,
                |t1.if_req_fuel,t1.if_req_suc,t1.addfuel_tm,t1.addfuel_point,t1.fuel_prices,
                |t1.fuel_qty,t1.fuel_log_dist,t1.total_amount,t1.start_tm,t1.end_tm,t1.start_miles,
                |t1.end_miles,t1.log_dist,t1.fuel_left_distance,t1.rec_oil_brand,t1.rec_oil_name,
                |t1.rec_oil_point,t1.rec_oil_price,t1.rec_coords,t1.addfuelstop_tm,t1.stpos_recpos_dist,
                |t1.st_rec_tm,t1.reqtime,t1.adcode,t1.point_distance,t1.if_add_fuel_rec,t1.req_brand,t1.if_eu_dirver,
                |t1.dirver_batch,t1.rec_addfuel_dist,t1.adcode4,t1.rank1,t1.onlyrank,t1.addfuel_point_new,
                |t1.adcode5,t2.station_pos,t2.station_name,t2.station_addr,t2.price_activity_vec,t2.query_brand_id,
                |'' req_time,'' driver_problem,'' task_problem,t1.coordinate,t1.refuel_url,t1.invoice_url
                |from
                |(select *,case when adcode is null or adcode ='' then '2222' else  substr(adcode,0,4) end adcode5
                |from Qilpoint_df_tb2
                |) t1
                |left join
                |(
                |select *,case when adcode is null or adcode='' then '1111' else substr(adcode,0,4) end adcode4
                |from station_df_tb
                |) t2 on t1.adcode5=t2.adcode4""".stripMargin)

    val temp_x2=spark.sql("""select * from dm_gis.oil_station_recommend_detail_middtl""".stripMargin)

    val Qilpoint_df3 =temp_x2
      .withColumn("distance_count",when($"addfuel_point_new".isNull || trim($"addfuel_point_new")==="" || $"station_pos".isNull || trim($"station_pos")==="",lit(999999999999.00))
        .otherwise(getDistance_udf($"addfuel_point_new",$"station_pos")))
      .withColumn("rank", row_number().over(Window.partitionBy("onlyrank")
        .orderBy(asc("distance_count"))))
      .filter($"rank"===1)
      .withColumn("exist_dist",when($"distance_count".isNull || $"distance_count"==="","").otherwise($"distance_count"))
      .withColumn("oil_name",$"station_name")
      .withColumn("oil_address",$"station_addr")
      .withColumn("price_activity_vec",$"price_activity_vec")
      .withColumn("if_exist",when(($"oil_name".like("%服务区%") && $"exist_dist".isNotNull && $"exist_dist" =!="" && $"exist_dist"<=100)
        ||  ($"exist_dist".isNotNull && $"exist_dist" =!="" && $"exist_dist"<=80)  ,"是").otherwise("否"))
      .withColumn("exist_info",hebing_as_udf($"addfuel_point_new",$"station_pos"))
      .withColumn("query_brand_id_tmp",$"query_brand_id")
      .withColumn("query_brand_id",when($"query_brand_id"==="1" ,"中国石油").when($"query_brand_id"==="2" ,"中国石化")
        .otherwise($"query_brand_id"))
      //重新处理exist_dist
      .withColumn("exist_dist",when($"distance_count"===999999999999.00,"").otherwise($"distance_count"))
      .withColumn("req_time",$"reqtime")
      .withColumn("driver_problem_tmp1",when($"if_add_fuel"==="是" && $"if_add_fuel_rec"==="否" && $"if_req_fuel"==="是" && $"rec_addfuel_dist"<=1000,"请求点加油").otherwise(null))
      .withColumn("driver_problem_tmp2",when($"if_add_fuel"==="是" && trim($"rec_oil_brand")=!="" && $"rec_oil_brand".isNotNull && $"if_req_fuel"==="是"
        && brand_pp_udf($"rec_oil_brand",$"query_brand_id_tmp")==="N","油卡类型错误").otherwise(null))
      .withColumn("driver_problem",concat_ws("|",$"driver_problem_tmp1",$"driver_problem_tmp2"))
      .withColumn("task_problem_tmp1",when($"addfuel_tm".isNotNull && trim($"addfuel_tm")=!="" && $"req_time" >= $"addfuel_tm" ,"加油后请求").otherwise(null))
      .withColumn("task_problem_tmp2",when($"addfuel_tm".isNotNull && trim($"addfuel_tm")=!="" && $"addfuel_point".isNull || trim($"addfuel_point")===""  ,"获取实际加油点异常").otherwise(null))
      .withColumn("task_problem_tmp3",when($"addfuel_tm".isNotNull && trim($"addfuel_tm")=!="" && ($"addfuel_tm" > $"end_tm" || $"addfuel_tm" < $"start_tm")
        ,"加油时间异常").otherwise(null))
      .withColumn("task_problem",concat_ws("|",$"task_problem_tmp1",$"task_problem_tmp2",$"task_problem_tmp3"))
      .select(table_cols: _*)

    //数据存dm表
    writeToHive(spark, Qilpoint_df3, Seq("inc_day"), "dm_gis.oil_station_recommend_detail")
    /*
        Qilpoint_df3.createOrReplaceTempView("Qilpoint_df3_view")

        //数据存dm表
        val insert_sql=s"""insert overwrite table dm_gis.oil_station_recommend_detail
                          |partition(inc_day=${inc_day})
                          |select task_type,task_id,navi_id,app_ver,line_code,start_dept,end_dept,driver_menbers,vehicle_serial,
                          |if_add_fuel,if_req_fuel,if_req_suc,addfuel_tm,addfuel_point,fuel_prices,fuel_qty,fuel_log_dist,
                          |total_amount,start_tm,end_tm,start_miles,end_miles,log_dist,fuel_left_distance,rec_oil_brand,
                          |rec_oil_name,rec_oil_point,rec_oil_price,point_distance,if_add_fuel_rec,addfuelstop_tm,
                          |rec_coords,rec_addfuel_dist,req_brand,if_eu_dirver,dirver_batch,stpos_recpos_dist,
                          |st_rec_tm,exist_dist,if_exist,exist_info,oil_name,oil_address,price_activity_vec,query_brand_id,
                          |req_time,driver_problem,task_problem,coordinate,refuel_url,invoice_url from Qilpoint_df3_view""".stripMargin
        spark.sql(insert_sql)
    */

    //选择所需列
    val table_cols2 = spark.sql("""select * from dm_gis.oil_station_recommend_daily_st limit 0""").schema.map(_.name).map(col)


    val rec_result=spark.sql(
      s"""select * from dm_gis.oil_station_recommend_detail
         |where inc_day>=${day_var7} and inc_day<=${inc_day}
         |""".stripMargin)
      .withColumn("test_if_add_fuel_rec",when($"if_add_fuel_rec"==="是" ,1).otherwise(2))
      .withColumn("rank",row_number().over(Window.partitionBy("task_id").orderBy(asc("test_if_add_fuel_rec"),desc("inc_day"))))
      .filter("rank=1")


    val rec_result1=rec_result
      .groupBy("inc_day","task_type")
      .agg(
        // driver_ct_udf(concat_ws(";",$"driver_menbers")) as "driver_num",
        count($"task_id") as "task_num",
        count(when($"if_add_fuel"==="是",1).otherwise(null)) as "addfuel_num",
        count(when($"if_add_fuel"==="是" &&  $"if_req_fuel"==="是",1).otherwise(null)) as "req_num",
        count(when($"if_add_fuel"==="是" &&  $"if_req_fuel"==="是" &&  $"if_req_suc"==="是",1).otherwise(null)) as "req_suc_num",
        count(when($"if_add_fuel"==="是" &&  $"if_req_fuel"==="是" &&  $"if_req_suc"==="是" &&  $"if_add_fuel_rec"==="是",1).otherwise(null)) as "addfuel_rec_num"
      )

    val rec_result2=rec_result.groupBy("inc_day","task_type")
      .agg(concat_ws(";",collect_set($"driver_menbers")) as "dreverlist")
      .withColumn("driver_num",driver_ct_udf($"dreverlist"))

    val rec_result3=rec_result1.join(rec_result2,Seq("inc_day","task_type"),"left")
      .select(table_cols2: _*)

    //数据存dm表
    writeToHive(spark, rec_result3, Seq("inc_day"), "dm_gis.oil_station_recommend_daily_st")

    //spark任务完成退出
    spark.close()
  }

  //遍历rec_oil_brand的数据 判断是否有与query_brand_id相等的
  def brand_pp(x:String,y:String): String ={
    val x_arr=x.split("|")
    if( ! x_arr.contains(y)){"N"}
    else{"Y"}
  }
  val brand_pp_udf=udf(brand_pp _)

  //计算地图距离
  def rad(d: Double): Double = d * Math.PI / 180.0

  def getDistance(x:String,y:String): Double = {
    val lat1=x.split(",")(1).toDouble
    val lng1=x.split(",")(0).toDouble
    val lat2=y.split(",")(1).toDouble
    val lng2=y.split(",")(0).toDouble

    val EARTH_RADIUS: Double = 6378.137
    val radLat1: Double = rad(lat1)
    val radLat2: Double = rad(lat2)
    val a: Double = radLat1 - radLat2
    val b: Double = rad(lng1) - rad(lng2)
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)))
    s = s * EARTH_RADIUS
    s = s * 10000d.round / 10000d
    s = s * 1000
    s
  }

  val getDistance_udf=udf(getDistance _)

  //转换Double
  def todouble_fun(x: String): Double = {
    x.toDouble
  }
  val todouble_fun_udf=udf(todouble_fun _)

  //合并addfuel_point和station_pos
  def hebing_as(x:String,y:String): String ={
    if(x !=null && x.trim != "" && y !=null && y.trim != ""){
      x.concat("_").concat(y)
    }
    else{""}
  }
  val hebing_as_udf=udf(hebing_as _)

  case class oilstationtb(
                           distance_count:String,
                           station_pos	:String,
                           oil_name	:String,
                           oil_address	:String,
                           price_activity_vec :String,
                           query_brand_id:String
                         )

  def points_distance(x:String,y:String): Double ={
    if(x !=null && x.trim != "" && y !=null && y.trim != ""){
      val arr_str1_x=x.split(",")(0).toDouble
      val arr_str1_y=x.split(",")(1).toDouble
      val arr_str2_x=y.split(",")(0).toDouble
      val arr_str2_y=y.split(",")(1).toDouble
      val m=scala.math.pow(arr_str1_x-arr_str2_x,2)
      val n=scala.math.pow(arr_str1_y-arr_str2_y,2)
      val d=scala.math.pow(m+n,0.5)
      d
    }else{9999999999999999.99999}
  }

  val points_distance_udf=udf(points_distance _)


  def substrfunc(str:String): String ={
    if(str !=null && str.trim != ""){
      str.substring(0,4)
    }else{""}
  }

  val substrfunc_udf=udf(substrfunc _)

  //定义获取url数据adcode
  def Qmpoint_url_adcode(addfuel_point: String): String = {
    var adcode=""
    val url="http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf"
    try {
      val ak="b52f9104afc34ddeab53029720e264c5"
      val test=1
      val stype=0
      val etype=0
      val passport="100000"
      val date=""
      val mode=2
      val speed=1
      val Toll=1
      val point_src=1
      val points=addfuel_point
      val opt="sf4"
      val json = new JSONObject()
      json.put("ak",ak)
      json.put("test",test)
      json.put("stype",stype)
      json.put("etype",etype)
      json.put("passport",passport)
      json.put("date",date)
      json.put("mode",mode)
      json.put("speed",speed)
      json.put("Toll",Toll)
      json.put("point_src",point_src)
      json.put("points",points)
      json.put("opt",opt)
      val parm=json.toJSONString
      val retStr: String = HttpInvokeUtil.sendPost(url,parm,5)
      val ret: JSONObject = JSON.parseObject(retStr)
      val route=ret.getString("route")
      if(route !=null && route.trim != ""){
        val routejson: JSONObject = JSON.parseObject(route)
        val paths=routejson.getJSONArray("paths")
        var new_distance: Int = 0
        var new_duration: Double = 0.0
        if (paths != null && paths.size() > 0) {
          val paths0 =paths.getString(0)
          if(paths0 !=null && paths0.trim != ""){
            val paths0_json: JSONObject = JSON.parseObject(paths0)
            val steps=paths0_json.getJSONArray("steps")
            val steps0=steps.getString(0)
            val steps0_json: JSONObject = JSON.parseObject(steps0)
            val links=steps0_json.getJSONArray("links")
            val links0=links.getString(0)
            val links0_json: JSONObject = JSON.parseObject(links0)
            adcode=links0_json.getString("adcode")
          }
        }
      }

      //Thread.sleep(1*1000)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
    }
    adcode
  }

  val Qmpoint_url_adcode_udf=udf(Qmpoint_url_adcode _)
  //定义获取url数据
  def Qmpoint_url(ak:String,obj:JSONObject): JSONObject = {
    //使用新的QM接口
    val url="http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf"
    val part_coords: String = obj.getString("part_coords")
    val part_coords_arry=part_coords.split("[|]")
    if(part_coords_arry != null && part_coords_arry.size > 0)
    {
      val l=part_coords_arry.size
      val distance_List: ListBuffer[Int] = new ListBuffer[Int]
      val duration_List: ListBuffer[Double] = new ListBuffer[Double]
      for(i<-0 until l){
        try {
          val part_coords_i: String = part_coords_arry(i).replaceAll(";","|")
          val ak="b52f9104afc34ddeab53029720e264c5"
          val test=1
          val stype=0
          val etype=0
          val passport="100000"
          val date=""
          val mode=2
          val speed=1
          val Toll=1
          val point_src=1
          val points=part_coords_i
          val opt="sf4"
          val json = new JSONObject()
          json.put("ak",ak)
          json.put("test",test)
          json.put("stype",stype)
          json.put("etype",etype)
          json.put("passport",passport)
          json.put("date",date)
          json.put("mode",mode)
          json.put("speed",speed)
          json.put("Toll",Toll)
          json.put("point_src",point_src)
          json.put("points",points)
          json.put("opt",opt)
          val parm=json.toJSONString
          val retStr: String = HttpInvokeUtil.sendPost(url,parm,5)
          val ret: JSONObject = JSON.parseObject(retStr)
          val route=ret.getString("route")
          if(route !=null && route.trim != ""){
            val routejson: JSONObject = JSON.parseObject(route)
            val paths=routejson.getJSONArray("paths")
            var new_distance: Int = 0
            var new_duration: Double = 0.0
            if (paths != null && paths.size() > 0) {
              val n: Int = paths.size()
              for (i <- 0 until n) {
                val obj: JSONObject = paths.getJSONObject(i)
                new_distance += obj.getInteger("distance")
                new_duration += obj.getDoubleValue("duration")
              }
            }
            distance_List.append(new_distance)
            duration_List.append(new_duration)
          }
          obj.put("stpos_recpos_dist",distance_List.mkString("|"))
          obj.put("st_rec_tm",duration_List.mkString("|"))
          obj.put("ret_result_qm",ret)
          Thread.sleep(1*1000)
        } catch {
          case e: Exception => logger.error(e)
            val tmp = new JSONObject()
            tmp.put("myException",e.getMessage)
            obj.put("ret_result_qm",tmp)
        }
      }
    }

    obj
  }

  //调取接口并发请求
  def Multi_Qmpoint(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {

    //调用开始上报
    val httpUrl="http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf"
    val httpAk="b52f9104afc34ddeab53029720e264c5"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "756360", "定点加油数据监控需求",
      "定点加油,加油站推荐",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, Qmpoint_url, 3, "b52f9104afc34ddeab53029720e264c5", 2000)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    returnAtRDD
  }

  //获取轨迹中距离最短的加油站
  def min_points(rec_oil_point:String,rec_coords:String): String ={
    val mb_List: ListBuffer[String] = new ListBuffer[String]
    if(rec_oil_point !=null && rec_oil_point.trim != "" && rec_coords !=null && rec_coords.trim != ""){
      val rec_oil_point_str=rec_oil_point.split("[|]")
      val rec_coords_str=rec_coords.split("[|]")
      if(rec_oil_point_str.size==rec_coords_str.size){
        val l=rec_oil_point_str.size
        val distance_List: ListBuffer[Double] = new ListBuffer[Double]
        val all_List: ListBuffer[ListBuffer[Double]] = new ListBuffer[ListBuffer[Double]]
        //循环遍历每个分段
        for(i<-0 until l){
          val d_List: ListBuffer[Double] = new ListBuffer[Double]
          val xy_List: ListBuffer[String] = new ListBuffer[String]
          val rec_oil_point_str_i=rec_oil_point_str(i)
          val pointx=rec_oil_point_str_i.split(",")(0).toDouble
          val pointy=rec_oil_point_str_i.split(",")(1).toDouble
          val rec_coords_str_i=rec_coords_str(i)
          val rec_coords_str_ilist=rec_coords_str_i.split(";")
          val g=rec_coords_str_ilist.size
          for(j<-0 until g){
            val coordsx=rec_coords_str_ilist(j).split(",")(0).toDouble
            val coordsy=rec_coords_str_ilist(j).split(",")(1).toDouble
            // val m=scala.math.pow(pointx-coordsx,2)
            //  val n=scala.math.pow(pointy-coordsy,2)
            //val d=scala.math.pow(m+n,0.5)
            val d=getDistance(rec_oil_point_str_i,rec_coords_str_ilist(j))
            d_List.append(d)
          }
          val d_min=d_List.min
          //获取每个分区段的最小距离坐标轨迹
          val j_list: ListBuffer[Int] = new ListBuffer[Int]
          for(j<-0 until g){
            val d_List_j=d_List(j)
            if(d_List_j==d_min){j_list.append(j)}
          }
          val j_str=j_list.min
          for(i<-0 to j_str){
            xy_List.append(rec_coords_str_ilist(i))
          }
          //将加油站并入轨迹中
          xy_List.append(rec_oil_point_str_i)
          mb_List.append(xy_List.mkString(";"))
        }
      }
    }
    mb_List.mkString("|")
  }

  val min_points_udf=udf(min_points _)

  //计算司机去重数量
  def driver_ct(str:String): Int ={
    val str_arr=str.split(";")
    val s=str_arr.size
    val distance_List: ListBuffer[String] = new ListBuffer[String]
    for(i<-0 until s){
      distance_List.append(str_arr(i))
    }
    val res_list=distance_List.distinct
    res_list.length
  }
  val driver_ct_udf=udf(driver_ct _)

  //定义计算直线距离
  def line_distance(str1:String,str2:String):Double={
    val distance_List: ListBuffer[Double] = new ListBuffer[Double]
    if(str1 !=null && !str1.isEmpty && str1.trim !="" && str2 !=null && !str2.isEmpty && str2.trim !="")
    {
      val arr_str1=str1.split("[|]")
      val arr_str2=str2.split("[|]")
      val l1=arr_str1.length
      val l2=arr_str2.length
      for(i<-0 until l1){
        for(j<-0 until l2)
        {
          val d=getDistance(arr_str1(i),arr_str2(j))
          distance_List.append(d)
        }
      }
    }
    distance_List.min
  }
  //定义udf函数
  val line_distance_udf=udf(line_distance _)

  case class objmodel(inc_day:String,
                      task_type:String,
                      task_id:String,
                      navi_id: String,
                      app_ver: String,
                      line_code: String,
                      start_dept: String,
                      end_dept: String,
                      driver_menbers: String,
                      vehicle_serial: String,
                      if_add_fuel: String,
                      if_req_fuel: String,
                      if_req_suc: String,
                      addfuel_tm: String,
                      addfuel_point: String,
                      fuel_prices: String,
                      fuel_qty: String,
                      fuel_log_dist: String,
                      total_amount: String,
                      start_tm: String,
                      end_tm: String,
                      start_miles: String,
                      end_miles: String,
                      log_dist: String,
                      fuel_left_distance: String,
                      rec_oil_brand: String,
                      rec_oil_name: String,
                      rec_oil_point: String,
                      rec_oil_price: String,
                      rec_coords: String,
                      addfuelstop_tm: String,
                      stpos_recpos_dist: String,
                      st_rec_tm: String,
                      reqtime:String,
                      adcode: String,
                      ret_result: String ,
                      ret_result_qm:String
                      // isoilstation: oilstationtb
                     )

  //定义获取url数据:计算请求点到实际加油点里程
  def OilPoint_addfuel_dist(vehicle_serial:String,reqtime:String,addfuel_tm:String): String = {
    //使用新的oil接口
    var rec_addfuel_dist=""
    val url="http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"
    try {
      //设置入参
      val ak="87a1347bc3944718911a05c21ec888a9"
      val input_type="0"
      val un= vehicle_serial
      val addpoint=1
      //转换时间格式
      val beginDateTime=getminisBeforeOrAfter(reqtime,0)
      val endDateTime=getminisBeforeOrAfter(addfuel_tm,0)
      val opt="all"
      val json = new JSONObject()
      json.put("ak",ak)
      json.put("type",input_type)
      json.put("un",un)
      json.put("addpoint",addpoint)
      json.put("beginDateTime",beginDateTime)
      json.put("endDateTime",endDateTime)
      json.put("opt",opt)
      val parm=json.toJSONString
      val retStr: String = HttpInvokeUtil.sendPost(url,parm,5)

      if(retStr !=null && !retStr.isEmpty) {
        val obj_ret= JSON.parseObject(retStr)
        val result = obj_ret.getString("result")
        if(result !=null && !result.isEmpty) {
          val obj_result= JSON.parseObject(result)
          val data = obj_result.getString("data")
          if(data !=null && !data.isEmpty) {
            val obj_data = JSON.parseObject(data)
            rec_addfuel_dist=obj_data.getString("len")
          }
        }
      }

      Thread.sleep(1*1000)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
    }
    rec_addfuel_dist
  }

  val OilPoint_addfuel_dist_udf=udf(OilPoint_addfuel_dist _)

  //定义获取url数据
  def OilPoint_url(ak:String,obj:JSONObject): JSONObject = {
    //使用新的oil接口
    val url="http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"
    try {
      //获取json的时间，进行转化
      val addfuel_tm: String = obj.getString("addfuel_tm")
      //设置入参
      val ak="87a1347bc3944718911a05c21ec888a9"
      val input_type="0"
      val un: String = obj.getString("vehicle_serial")
      val addpoint=1
      val beginDateTime=getminisBeforeOrAfter(addfuel_tm,-10)
      val endDateTime=getminisBeforeOrAfter(addfuel_tm,10)
      val stayDuration=120
      val stayRadius=10
      val opt="all"
      val json = new JSONObject()
      json.put("ak",ak)
      json.put("type",input_type)
      json.put("un",un)
      json.put("addpoint",addpoint)
      json.put("beginDateTime",beginDateTime)
      json.put("endDateTime",endDateTime)
      json.put("stayDuration",stayDuration)
      json.put("stayRadius",stayRadius)
      json.put("opt",opt)
      val parm=json.toJSONString
      val retStr: String = HttpInvokeUtil.sendPost(url,parm,5)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
      //Thread.sleep(1*1000)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("ret",tmp)
    }
    obj
  }


  //调取接口并发请求
  def Multi_Oilpoint(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {

    //调用开始上报
    val httpUrl="http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"
    val httpAk="87a1347bc3944718911a05c21ec888a9"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "756360", "定点加油数据监控需求",
      "定点加油,加油站推荐",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, OilPoint_url, 2, "87a1347bc3944718911a05c21ec888a9", 200)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    val atRdd: RDD[JSONObject] = returnAtRDD.map(obj => {
      val ret = obj.getString( "ret")
      var addfuel_point=""
      var addfuelstop_tm=""
      if(ret !=null && !ret.isEmpty) {
        val obj_ret= JSON.parseObject(ret)
        val result = obj_ret.getString("result")
        if(result !=null && !result.isEmpty) {
          val obj_result= JSON.parseObject(result)
          val data = obj_result.getString("data")
          if(data !=null && !data.isEmpty) {
            val obj_data = JSON.parseObject(data)
            val staypoints = obj_data.getJSONArray("stayPoints")
            val track=obj_data.getJSONArray("track")
            val s=staypoints.size()
            val l=track.size()
            if(staypoints !=null && !staypoints.isEmpty && s>0){
              val xy_List: ListBuffer[String] = new ListBuffer[String]
              val duration_List: ListBuffer[Double] = new ListBuffer[Double]
              for(i<-0 until s){
                val staypoints_i= JSON.parseObject(staypoints.getString(i))
                val startlon=staypoints_i.getString("startLon")
                val startlat=staypoints_i.getString("startLat")
                val d=","
                val xy=startlon.concat(d).concat(startlat)
                xy_List.append(xy)
                val duration_time=staypoints_i.getString("duration").toDouble
                duration_List.append(duration_time)
              }
              addfuel_point=xy_List.mkString("|")
              addfuelstop_tm=duration_List.mkString("|")
            }else{
              if(track !=null && !track.isEmpty && l>0) {
                var midxy=0
                if(l==1){midxy=0}
                else if (l%2==1) {midxy=(l+1)/2} else{midxy=l/2}
                val mid_str=track.getString(midxy)
                if(mid_str !=null && !mid_str.isEmpty ){
                  val track_i= JSON.parseObject(mid_str)
                  val track_x=track_i.getString("dx")
                  val track_y=track_i.getString("dy")
                  val d=","
                  addfuel_point=track_x.concat(d).concat(track_y)
                }
              }
            }
          }
        }
      }
      obj.put("addfuel_point",addfuel_point)
      obj.put("addfuelstop_tm",addfuelstop_tm)
      obj.put("ret_result",ret)
      obj
    })
    atRdd
  }

  //导航数据，司机工号是线下提供
  def navi_data(spark:SparkSession,day_var7:String,inc_day:String): DataFrame ={
    val navi_data_res= spark.sql(
      s"""select task_id,line_code,navi_id,inc_day,vehicle as vehicle_serial,app_ver,request_id as requestid from dm_gis.gis_navi_top3_parse
         |where inc_day>=${day_var7} and inc_day<=${inc_day}
         |and driver_id in
         |('41814145','41526639','41514892','41494375','41492395','603923','41545885','551757',
         |'571934','41545264','123759','41501281','41505081','41238963','41193768','41768376',
         |'41476750','41730328','41510821','41498089','41509320','41509370','41509319','41508466',
         |'41565881','441588','41555294','41571816','41591201','41319930','41701226','41727284',
         |'41524997','41733805','41529886','41529891','641667','41533788','41966548','40325581',
         |'706919','41779544','41164881','885760','643549','42034193','839502','01281199','42026570',
         |'41797260','41861953','41476037','634823','41704375','214155','541006','41667385','41545885',
         |'41584644','41489585','41489473','41497420','41542793','41578424','41761301','42034172','41708726',
         |'41537541','41279733','40559499','41547603','41733805','41569289','40453028','41475532','41667402',
         |'564948','41487750','40512542','41726893','41867716','443335','41545885','40574394','41895729',
         |'41549131','670274','41530073','41931682','41493548','41490758','41931686','41476748','41479669',
         |'40420824','41525389','41916328','41712406','251927','41931682','40443962','41699031','40433957',
         |'481803','41699031','41490653','41517348','41656375','41565881','293712','693738','40681504',
         |'41939218','41939218','41500570','40791444','153064','41767660','40433957','280512','41931682',
         |'41931682','41939218','41435450','592318','172035','41521025','01137288','40972347',
         |'41552808','41462518','41462526','120558','403569')
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("task_id").orderBy(desc("inc_day"))))
      .filter("rank=1")
      .drop("rank")
    navi_data_res
  }

  //按照Y数据分割函数
  def y_split(str:String): String ={
    if(str.contains("Y")){
      val y_arr=str.split("Y")
      if(y_arr.length>=2){return y_arr(1)}
      else{str }
    }else{return str}
  }
  //定义udf函数
  val y_split_udf=udf(y_split _)

  //时间处理函数
  def timedeal(str:String): String ={
    val DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    DATE_FORMAT.format(str.toLong)
  }
  //定义udf函数
  val timedeal_udf=udf(timedeal _)


  //请求推荐入参表
  def query_hive_data(spark:SparkSession,day_var7:String,inc_day:String):DataFrame={
    import spark.implicits._
    val query_hive_data1=spark.sql(s"""select data,inc_day  from dm_gis.gis_eta_navi_query_hive
                                      |where inc_day>=${day_var7} and inc_day<=${inc_day}
                                      |""".stripMargin)
      .withColumn("subtype",get_json_object($"data","$.subType"))
      .filter("subtype='grdFuelChargingInfoLog'")
      .withColumn("reqid",get_json_object($"data","$.reqId"))
      .withColumn("deptcode",get_json_object($"data","$.data.fuelChargingInfoArg.deptCode"))
      .withColumn("ischanged",get_json_object($"data","$.data.fuelChargingInfoArg.isChanged"))
      .withColumn("isfuelpoint",get_json_object($"data","$.data.fuelChargingInfoArg.isFuelPoint"))
      .withColumn("litersnumber",get_json_object($"data","$.data.fuelChargingInfoArg.litersNumber"))
      .withColumn("unitprice",get_json_object($"data","$.data.fuelChargingInfoArg.unitPrice"))
      .withColumn("fuel_taskserial",get_json_object($"data","$.data.fuelChargingInfoArg.taskSerial"))
      .withColumn("fuel_taskid",get_json_object($"data","$.data.fuelChargingInfoArg.taskId"))
      .withColumn("taskserial",when($"fuel_taskserial" =!= "/",$"fuel_taskserial").otherwise($"fuel_taskid"))
      .withColumn("username",get_json_object($"data","$.data.fuelChargingInfoArg.username"))
      .withColumn("vehiclecode",get_json_object($"data","$.data.fuelChargingInfoArg.vehicleCode"))
      .drop("data","subtype")

    val query_hive_data2=spark.sql(s"""select data  from dm_gis.gis_eta_navi_query_hive
                                      |where inc_day>=${day_var7} and inc_day<=${inc_day}
                                      |""".stripMargin)
      .withColumn("subtype",get_json_object($"data","$.subType"))
      .filter("subtype='adjustPathLog'")
      .withColumn("taskid",get_json_object($"data","$.data.adjustPathArg.taskId"))
      .withColumn("requestid",get_json_object($"data","$.data.requestId"))
      .withColumn("projectno",get_json_object($"data","$.data.pnsAdjustPathArgs.projectNo"))
      .withColumn("fuelleftdistance",get_json_object($"data","$.data.pnsAdjustPathArgs.fuelLeftDistance"))
      .withColumn("pathlist",get_json_object($"data","$.data.pnsAdjustPathArgs.pathList"))
      .withColumn("reqtime",timedeal_udf(get_json_object($"data","$.data.pnsAdjustPathArgs.reqTime")))
      .withColumn("taskserial",when($"taskid".like ("%Y%"),y_split_udf($"taskid")).otherwise($"taskid" ))
      .drop("subtype","data")

    val query_hive_data_res=query_hive_data1.join(query_hive_data2,Seq("taskserial"),"right")
      .withColumn("rank",row_number().over(Window.partitionBy("reqid","taskid","requestid","taskserial").
        orderBy(desc("inc_day"))))
      .filter($"rank"===1)
      .drop("rank")

    query_hive_data_res
  }

  //请求推荐出参明细表
  def proto_hive_data(spark:SparkSession,day_var7:String,inc_day:String):DataFrame={
    import spark.implicits._
    val proto_hive_data_res=spark.sql(s"""select data
                                         |from dm_gis.gis_eta_navi_query_proto_hive
                                         |where inc_day>=${day_var7} and inc_day<=${inc_day}
                                         |""".stripMargin)
      .withColumn("subtype",get_json_object($"data","$.subType"))
      .filter("subtype='adjustPathLog'")
      .withColumn("requestid",get_json_object($"data","$.requestId"))
      .withColumn("info",get_json_object($"data","$.info"))
      .withColumn("stindex",rec_oil_info_udf($"info",$"data"))
      .withColumn("rec_oil_name",$"stindex.rec_oil_name")
      .withColumn("rec_oil_brand",$"stindex.rec_oil_brand")
      .withColumn("rec_oil_price",$"stindex.rec_oil_price")
      .withColumn("rec_oil_point",$"stindex.rec_oil_point")
      .withColumn("rec_coords",$"stindex.rec_coords")
      .drop("subtype","data")
    proto_hive_data_res
  }

  //行车日志数据
  def driving_log_data(spark: SparkSession,month0:String,month1:String): DataFrame ={
    import spark.implicits._
    val driving_logres=spark.sql(s"""select fuel_qty,fuel_prices,start_miles,end_miles,miles,addfuel_miles,is_add_oil,
                                    |data_source,round(total_amount,2) total_amount,task_id,if(operation_type_detail='1',addfuel_tm,'') as addfuel_tm,
                                    |start_tm,end_tm,drive_members,start_place as start_dept,end_place as end_dept,inc_month,operation_type_detail
                                    |from ods_vms.tt_vms_driving_log_item
                                    |where inc_month in ($month0,$month1)""".stripMargin)
      .withColumn("taskid",taskid_split_udf($"task_id"))
      .withColumn("fuel_log_dist",when($"addfuel_miles"-$"start_miles"<0.0,0.0).otherwise($"addfuel_miles"-$"start_miles"))
      .withColumn("log_dist",when($"end_miles"-$"start_miles"<0.0,0.0).otherwise($"end_miles"-$"start_miles"))
      .withColumn("driver_menbers",menbers_dump_udf($"drive_members"))
      .drop("task_id")

    //保存用于测试
    //spark.sql("drop table if exists default.tempzy20221215driving_logres")
    //driving_logres.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221215driving_logres")

    driving_logres
  }

  //driver_menbers清洗去重
  def menbers_dump(str:String): String ={
    if( str !=null && str.trim != ""){
      val str_arr=str.split(";")
      str_arr.distinct.mkString(";")
    }
    else{str}
  }
  //定义udf函数
  val menbers_dump_udf=udf(menbers_dump _)

  //按照Y数据分割函数
  def taskid_split(str:String): String ={
    if( str !=null && str.trim != ""){
      if(str.contains("-")){
        return str.split("Y")(1)
      }else{return  str}
    }
    else{return  str}
  }
  //定义udf函数
  val taskid_split_udf=udf(taskid_split _)


  //定义函数获取油价地址价格等等信息
  def rec_oil_info(info:String,data:String): rec_oil_info_data={
    var rec_oil_name: ListBuffer[String] = new ListBuffer[String]
    var rec_oil_brand: ListBuffer[String] = new ListBuffer[String]
    var rec_oil_price: ListBuffer[Double] = new ListBuffer[Double]
    var rec_oil_point: ListBuffer[String] = new ListBuffer[String]
    var rec_coords: ListBuffer[String] = new ListBuffer[String]
    var rec_oil_name_str=""
    var rec_oil_brand_str=""
    var rec_oil_price_str=""
    var rec_oil_point_str=""
    var rec_coords_str=""
    if(info=="Succ" && data !=null && !data.isEmpty){
      val json_data= JSON.parseObject(data)
      if(json_data != null && !json_data.isEmpty && json_data !=""){
        val pathWithPoi: JSONArray=json_data.getJSONArray("pathWithPoi")
        if( pathWithPoi !=null && pathWithPoi.size()>0){
          val s=pathWithPoi.size()
          if(s>0){
            for(i<-0 until s){
              val pathWithPoi_i=pathWithPoi.getString(i)
              if(pathWithPoi_i !=null && !pathWithPoi_i.isEmpty ){
                val pathWithPoi_j= JSON.parseObject(pathWithPoi_i)
                val poi_data=pathWithPoi_j.getString("poi")
                if(poi_data !=null && !poi_data.isEmpty ) {
                  val json_poi= JSON.parseObject(poi_data)
                  val rec_oil_name_i=json_poi.getString("name")
                  val rec_oil_brand_i=json_poi.getString("chainCode")
                  val rec_oil_price_i=json_poi.getDouble("price")
                  var rec_oil_point_i=""
                  val displayPos=json_poi.getString("displayPos")
                  if(displayPos !=null && !displayPos.isEmpty )
                  {val pointxy= JSON.parseObject(displayPos)
                    val x= (pointxy.getLong("x")/3600000.0).formatted("%.7f")
                    val y= (pointxy.getLong("y")/3600000.0).formatted("%.7f")
                    val d=","
                    rec_oil_point_i=x.concat(d).concat(y)
                  }
                  rec_oil_name.append(rec_oil_name_i)
                  rec_oil_brand.append(rec_oil_brand_i)
                  rec_oil_price.append(rec_oil_price_i)
                  rec_oil_point.append(rec_oil_point_i)
                }

                //解析pathResult
                val pathResult_data=pathWithPoi_j.getString("pathResult")
                if(pathResult_data !=null && !pathResult_data.isEmpty ) {
                  var rec_coords_i=""
                  val json_pathResult= JSON.parseObject(pathResult_data)
                  val pathes_data=json_pathResult.getJSONArray("pathes")
                  if( pathes_data !=null && pathes_data.size()>0){
                    val pathes_data0=pathes_data.getString(0)
                    if(pathes_data0 !=null && !pathes_data0.isEmpty ) {
                      val polylineX=JSON.parseObject(pathes_data0).getString("polylineX")
                      val polylineY=JSON.parseObject(pathes_data0).getString("polylineY")
                      rec_coords_i=ployxy(polylineX,polylineY)
                      rec_coords.append(rec_coords_i)
                    }
                  }
                }



              }
            }
          }
        }

      }
      rec_oil_name_str=rec_oil_name.mkString("|")
      rec_oil_brand_str=rec_oil_brand.mkString("|")
      rec_oil_price_str= rec_oil_price.mkString("|")
      rec_oil_point_str=rec_oil_point.mkString("|")
      rec_coords_str=rec_coords.mkString("|")
    }
    rec_oil_info_data(rec_oil_name_str,rec_oil_brand_str,rec_oil_price_str,rec_oil_point_str,rec_coords_str)
  }

  case class rec_oil_info_data(rec_oil_name:String,
                               rec_oil_brand:String,
                               rec_oil_price:String,
                               rec_oil_point:String,
                               rec_coords:String)

  //定义函数清洗坐标
  def ployxy(x:String,y:String):String ={
    val poly_list:ListBuffer[(Double,Double)] = new ListBuffer[(Double,Double)]
    if(x !=null && x.trim != "" && y !=null && y.trim != "" ){
      val x_arr=x.replaceAll("\\[", "").replaceAll("\\]", "").split(",")
      val y_arr=y.replaceAll("\\[", "").replaceAll("\\]", "").split(",")
      if(x_arr !=null && x_arr.size>0 && y_arr !=null && y_arr.size>0){
        val l=x_arr.size
        var x_arr_0=x_arr(0).toDouble
        var y_arr_0=y_arr(0).toDouble
        if(l>=2){
          poly_list.append((x_arr_0.toDouble/3600000,y_arr_0.toDouble/3600000))
          for(i<-1 until l){
            x_arr_0=x_arr_0.toDouble+x_arr(i).toDouble
            y_arr_0=y_arr_0.toDouble+y_arr(i).toDouble
            poly_list.append((x_arr_0.toDouble/3600000,y_arr_0.toDouble/3600000))
          }
        }
        else{poly_list.append((x_arr_0.toDouble/3600000,y_arr_0.toDouble/3600000))}
      }
    }
    poly_list.mkString(";").replaceAll("\\(", "").replaceAll("\\)", "")
  }


  //定义udf函数
  val rec_oil_info_udf=udf(rec_oil_info _)

  def sortField = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("\\&")
      val other_arr = other.split("\\&")
      val new_arr = num_arr.zip(other_arr).sortWith((x,y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })
  //定义函数存入数据
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

}