package app.route


import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions._

import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.functions.{asc, col, collect_list, collect_set, concat_ws, count, desc, get_json_object, lit, row_number, substring, udf, when}

/**
 *需求名称：定点加油数据监控需求-加油站点接口获取
 *需求方：周思毅(01399920)，李建飞(01413751)
 *@author: 周勇(01390943)
 *任务创建时间：20221214
 *任务id：666878（每天05:00执行）
 **/

object OilStationConfigDetail {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .enableHiveSupport()
      .getOrCreate()

    //初始化99990101数据
    batch_get_all_initial(spark)
    //全量获取数据存于99990101分区
    batch_get_all(spark)
    spark.close()
  }
  //每周初始化一份全量的数据
  def batch_get_all_initial(spark:SparkSession): Unit ={
    import  spark.implicits._
    spark.sql("alter table dm_gis.online_config_oil_station_detail drop if exists partition (inc_day='99990101')")
    //考虑到更新时间有0的情况
    val maxtime="0"
    val Oilstation_url_res=Oilstation_url(maxtime)
    val inc_day="99990101"
    jsondetail(Oilstation_url_res,spark,inc_day)
  }
  //每周日全量获取数据
  def batch_get_all(spark:SparkSession): Unit ={
    import  spark.implicits._
    val maxtimea=spark.sql("""
                             |select nvl(updatetimestamp,0) updatetimestamp from dm_gis.online_config_oil_station_detail
                             |where inc_day='99990101'
                             |""".stripMargin)

    val maxtime=maxtimea.agg(max($"updatetimestamp") as "maxtime").collect()(0)(0).toString
    println("maxtime:")
    println(maxtime)
    val Oilstation_url_res=Oilstation_url(maxtime)
    val inc_day="99990101"
    val continue_flag=jsondetail(Oilstation_url_res,spark,inc_day)
    if(continue_flag==1){batch_get_all(spark)}
    Thread.sleep(2000)
  }

  //递归循环获取接口数据
  def batch_get(spark:SparkSession,inc_day:String): Unit ={
    import  spark.implicits._
    val maxtimea=spark.sql("""
                             |select nvl(updatetimestamp,0) updatetimestamp from dm_gis.online_config_oil_station_detail
                             |""".stripMargin)

    val maxtime=maxtimea.agg(max($"updatetimestamp") as "maxtime").collect()(0)(0).toString
    //val maxtime="0"
    println("maxtime:")
    println(maxtime)
    //调用开始上报
    val httpUrl="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData"
    val httpAk=""

    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "666878", "定点加油数据监控需求",
      "定点加油,加油站推荐",
      httpUrl, httpAk, 500, 1)

    val Oilstation_url_res=Oilstation_url(maxtime)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    //jsondetail(Oilstation_url_res,spark,inc_day)
    val continue_flag=jsondetail(Oilstation_url_res,spark,inc_day)
    if(continue_flag==1){batch_get(spark,inc_day)}
    Thread.sleep(2000)
  }

  //解析数据
  def jsondetail(json_data:JSONObject,spark:SparkSession,inc_day:String): Int ={
    import  spark.implicits._
    var flag=1
    if(json_data !=null ){
      val ret: JSONObject = json_data.getJSONObject("ret")
      val xlist=ret.getJSONArray("data")
      val arrlist: ListBuffer[String] = new ListBuffer[String]
      if(xlist !=null && !xlist.isEmpty){
        val l=xlist.size()
        for(i<-0 until l){
          val arr_i= xlist.getString(i)
          arrlist.append(arr_i)
        }
      }else{flag=0}
      val xstr=arrlist.mkString("@")
      //选择所需列
      val table_cols = spark.sql("""select * from dm_gis.online_config_oil_station_detail limit 0""").schema.map(_.name).map(col)
      //定义list
      val x_seqa=List(("xxx",100))
      //转为df
      val x_df=x_seqa.toDF("testa","testb")
        .withColumn("xstr",lit(xstr))
        .withColumn("xstr_detail",explode(split($"xstr","[@]")))
        .withColumn("grpid",get_json_object($"xstr_detail","$.GRPID"))
        .withColumn("poi_id",get_json_object($"xstr_detail","$.POIID"))
        .withColumn("station_name",get_json_object($"xstr_detail","$.stationName"))
        .withColumn("station_addr",get_json_object($"xstr_detail","$.addr"))
        .withColumn("lng",get_json_object($"xstr_detail","$.lng"))
        .withColumn("lat",get_json_object($"xstr_detail","$.lat"))
        .withColumn("station_pos",strconcat_udf($"lng",$"lat"))
        .withColumn("src",get_json_object($"xstr_detail","$.src"))
        .withColumn("query_brand_id",get_json_object($"xstr_detail","$.queryBrandID"))
        .withColumn("province",get_json_object($"xstr_detail","$.province"))
        .withColumn("city",get_json_object($"xstr_detail","$.city"))
        .withColumn("adcode",get_json_object($"xstr_detail","$.adcode"))
        .withColumn("del_flag",get_json_object($"xstr_detail","$.delFlag"))
        .withColumn("price_activity_vec",cl_price_activity_udf(get_json_object($"xstr_detail","$.priceActivityVec")))
        .withColumn("gun_price_vec",get_json_object($"xstr_detail","$.gunPriceVec"))
        .withColumn("update_time_stamp",get_json_object($"xstr_detail","$.updateTimeStamp"))
        .withColumn("official_price_vec",get_json_object($"xstr_detail","$.officialPriceVec"))
        .withColumn("gap_price_vec",get_json_object($"xstr_detail","$.gapPriceVec"))
        .withColumn("updateTimeStamp",get_json_object($"xstr_detail","$.updateTimeStamp"))
        .withColumn("poiid",get_json_object($"xstr_detail","$.POIID"))
        .withColumn("district",get_json_object($"xstr_detail","$.district"))
        .withColumn("inc_day",lit(inc_day))
        .filter($"poiid".isNotNull && trim($"poiid") =!="")
        .select(table_cols: _*)
        .persist(StorageLevel.MEMORY_AND_DISK)
      x_df.show(5)
      val x_dfl=x_df.count()
      if(x_dfl==0){flag=0}
      //增量数据存dm表
      InsertToHive(spark, x_df, Seq("inc_day"), "dm_gis.online_config_oil_station_detail")

    }
    flag
  }
  //定义清洗price_activity_vec
  def cl_price_activity(x:String): String ={
    if(x !=null && x.trim != "" ) {
      return x.replaceAll("\\[", "").replaceAll("\\]", "")
    }
    else return ""
  }

  val cl_price_activity_udf=udf(cl_price_activity _)

  // 定义合并坐标函数
  def strconcat(x:String,y:String): String =
  {
    if(x !=null && x.trim != "" && y !=null && y.trim != "") {
      return x.concat(",").concat(y)
    }
    else return ""
  }

  val strconcat_udf=udf(strconcat _)

  //定义获取url数据
  def Oilstation_url(maxtime:String): JSONObject = {
    //办公环境
    //val url="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/post?url=http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData"
    //正式环境
    val url="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData"
    val obj = new JSONObject()
    try {
      val json = new JSONObject()
      val dataVersion=1
      val src="5"
      val switchCode="BESTEXPRESSSF"
      json.put("dataVersion",dataVersion)
      json.put("src",src)
      json.put("switchCode",switchCode)
      json.put("lastTimeStamp",maxtime)
      json.put("limitCount",1000)
      val parm=json.toJSONString
      val retStr: String = HttpInvokeUtil.sendPost(url,parm,5)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
      //Thread.sleep(1*1000)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("ret",tmp)
    }
    obj
  }

  //定义函数存入数据
  def InsertToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert into table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }


}
