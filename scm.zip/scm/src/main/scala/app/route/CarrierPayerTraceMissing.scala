package app.route

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{col, count, countDistinct, lit, round, when}
import org.apache.spark.storage.StorageLevel

/**
 *需求名称：承运商付费用户维度轨迹缺失指标监控
 *需求描述：全量客户做紧急护航，付费用户需要前置护航，因此需要对付费用户的指标监控效果做数据监控。
 *需求方：江瑞(01408185)
 *开发: 周勇(01390943)
 *任务创建时间：20230817
 *任务id：790293
 **/

object CarrierPayerTraceMissing  extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args:Array[String]) {

    logger.error(">>>初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._
    //取跑数T-3日期
    val dayvar = args(0)
    //月份计算
    val monthvar=dayvar.substring(1,6)
    //月度计算范围
    val monthflag=dayvar.substring(1,4).concat("-").concat(dayvar.substring(5,6)).concat("-").concat("01").concat("~")
      .concat(dayvar.substring(1,4)).concat("-").concat(dayvar.substring(5,6)).concat("-").concat(dayvar.substring(7,8))
    logger.error("计算日期："+dayvar)
    logger.error("计算月份："+monthvar)
    logger.error("计算月份范围："+monthflag)

    //获取轨迹缺失表
    val miss_data=spark.sql(
      s"""
         |select task_id,carrier_type,max_time_slot,imei,inc_day_new,actual_carrier_name,create_tm,vehicle_serial
         | from dm_gis.gis_vms_gta_track_miss_all
         |where inc_day='$dayvar' and carrier_type='1'
         |""".stripMargin)

    //获取时效护航告警试点过滤规则表
    val alarm_filter=spark.sql(
      s"""
         |select car_no as vehicle_serial,create_time
         |from dm_gis_scm.dm_soc_alarm_filter_dtl_di
         |where inc_day='$dayvar' and filter_type='4'
         |""".stripMargin)

    //关联查询
    val hb_data=miss_data.join(alarm_filter,Seq("vehicle_serial")).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val tb_cols1=List("state_period","carrier_name","vehicle_serial","create_tm","task_ct","vehicle_ct","tracemiss1","tracemiss1_pert","tracemiss2","tracemiss2_pert",
      "tracemiss12","tracemiss12_pert","tracemiss051","tracemiss051_pert","flag")

    //表格1：总体每日监控报表
    val tb1=hb_data
      .withColumn("state_period",lit($"inc_day_new"))
      .withColumn("carrier_name",lit("总体"))
      .groupBy("state_period","carrier_name")
      .agg(count($"task_id") as "task_ct",
        countDistinct($"vehicle_serial") as "vehicle_ct",
        count(when($"max_time_slot"==="2小时以上" || $"max_time_slot"==="[3600-7200)",$"task_id").otherwise(null)) as "tracemiss1",
        count(when($"max_time_slot"==="2小时以上" ,$"task_id").otherwise(null)) as "tracemiss2",
        count(when( $"max_time_slot"==="[3600-7200)",$"task_id").otherwise(null)) as "tracemiss12",
        count(when( $"max_time_slot"==="[1800-3600)",$"task_id").otherwise(null)) as "tracemiss051"
      )
      .withColumn("tracemiss1_pert",round($"tracemiss1"/$"task_ct",6))
      .withColumn("tracemiss2_pert",round($"tracemiss2"/$"task_ct",6))
      .withColumn("tracemiss12_pert",round($"tracemiss12"/$"task_ct",6))
      .withColumn("tracemiss051_pert",round($"tracemiss051"/$"task_ct",6))
      .withColumn("flag",lit("1"))
      .withColumn("vehicle_serial",lit(""))
      .withColumn("create_tm",lit(""))
      .select(tb_cols1.head, tb_cols1.tail :_*)

    //表格2：付费企业维度总体监控报表,表格3：付费企业维度每日监控报表，共用一个数据集
    val tb2=hb_data
      .withColumn("state_period",lit($"inc_day_new"))
      .withColumn("carrier_name",lit($"actual_carrier_name"))
      .groupBy("state_period","carrier_name")
      .agg(count($"task_id") as "task_ct",
        countDistinct($"vehicle_serial") as "vehicle_ct",
        count(when($"max_time_slot"==="2小时以上" || $"max_time_slot"==="[3600-7200)",$"task_id").otherwise(null)) as "tracemiss1",
        count(when($"max_time_slot"==="2小时以上" ,$"task_id").otherwise(null)) as "tracemiss2",
        count(when( $"max_time_slot"==="[3600-7200)",$"task_id").otherwise(null)) as "tracemiss12",
        count(when( $"max_time_slot"==="[1800-3600)",$"task_id").otherwise(null)) as "tracemiss051"
      )
      .withColumn("tracemiss1_pert",round($"tracemiss1"/$"task_ct",6))
      .withColumn("tracemiss2_pert",round($"tracemiss2"/$"task_ct",6))
      .withColumn("tracemiss12_pert",round($"tracemiss12"/$"task_ct",6))
      .withColumn("tracemiss051_pert",round($"tracemiss051"/$"task_ct",6))
      .withColumn("flag",lit("2"))
      .withColumn("vehicle_serial",lit(""))
      .withColumn("create_tm",lit(""))
      .select(tb_cols1.head, tb_cols1.tail :_*)

    //表格4：付费企业车辆维度每日监控报表
    val tb4=hb_data
      .withColumn("state_period",lit($"inc_day_new"))
      .withColumn("carrier_name",lit($"actual_carrier_name"))
      .groupBy("state_period","carrier_name","vehicle_serial","create_tm")
      .agg(count($"task_id") as "task_ct",
        countDistinct($"vehicle_serial") as "vehicle_ct",
        count(when($"max_time_slot"==="2小时以上" || $"max_time_slot"==="[3600-7200)",$"task_id").otherwise(null)) as "tracemiss1",
        count(when($"max_time_slot"==="2小时以上" ,$"task_id").otherwise(null)) as "tracemiss2",
        count(when( $"max_time_slot"==="[3600-7200)",$"task_id").otherwise(null)) as "tracemiss12",
        count(when( $"max_time_slot"==="[1800-3600)",$"task_id").otherwise(null)) as "tracemiss051"
      )
      .withColumn("tracemiss1_pert",round($"tracemiss1"/$"task_ct",6))
      .withColumn("tracemiss2_pert",round($"tracemiss2"/$"task_ct",6))
      .withColumn("tracemiss12_pert",round($"tracemiss12"/$"task_ct",6))
      .withColumn("tracemiss051_pert",round($"tracemiss051"/$"task_ct",6))
      .withColumn("flag",lit("4"))
      .select(tb_cols1.head, tb_cols1.tail :_*)

    val result_data=tb1.union(tb2).union(tb4)
      .withColumn("inc_day",lit(dayvar))

    val tb_cols2 = spark.sql("""select * from dm_gis.dm_carrierpayer_tracemiss_dtl limit 0""").schema.map(_.name).map(col)
    //存储表
    writeToHive(spark, result_data.select(tb_cols2:_*), Seq("inc_day"), "dm_gis.dm_carrierpayer_tracemiss_dtl")

    logger.error(">>>任务执行成功！")

    spark.close()
  }


}
