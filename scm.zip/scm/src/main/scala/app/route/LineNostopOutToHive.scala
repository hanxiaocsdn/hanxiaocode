package app.route

import com.sf.gis.java.base.util.SparkUtil
import org.apache.log4j.Logger
import org.apache.spark.sql._
import org.apache.spark.sql.functions.col
import utils.SparkUtils.writeToHive

/**
 * eta_std_line_nostop_out 表数据同步hive
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：1046228  1046232
 * 任务名称：eta_std_line_nostop_out_表同步hive_天任务  eta_std_line_nostop_out_表同步hive_月任务
 */
object LineNostopOutToHive {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    //获取传入参数日期
    val inc_day1: String = args(0)
    val inc_day2: String = args(1)
    logger.error("参数inc_day1："+inc_day1)
    logger.error("参数inc_day2："+inc_day2)
    //判断月份所在的季度
    val year=inc_day1.substring(0,4)
    val fix=inc_day1.substring(4,6)

    val tb_fix=if(fix=="01" || fix=="02" || fix=="03" ){year.concat("01")}
    else if(fix=="04" || fix=="05" || fix=="06" ){year.concat("02")}
    else if(fix=="07" || fix=="08" || fix=="09" ){year.concat("03")}
    else if(fix=="10" || fix=="11" || fix=="12" ){year.concat("04")}
    else {"xxxxx"}

    val mysqltable="eta_std_line_nostop_out_".concat(tb_fix)

    mysqlToHive(spark,mysqltable,inc_day1,inc_day2)

    logger.error(">>>>>>执行完毕")
  }

  def mysqlToHive(spark: SparkSession, mysqlTable: String,inc_day1: String,inc_day2: String): Unit = {
    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://plan-s1.db.sfcloud.local:3306/plan?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val userName = "bdp"
    val passWd = "cB0C25#10E2D60nA032D"
    val tableName=
      s"""
         |(select
         |id,
         |task_area_code,
         |carrier_name,
         |task_id,
         |task_inc_day,
         |task_type,
         |start_dept,
         |end_dept,
         |start_type,
         |end_type,
         |line_require_id,
         |source_type,
         |line_code,
         |vehicle_serial,
         |actual_capacity_load,
         |plan_depart_tm,
         |actual_depart_tm,
         |plan_arrive_tm,
         |actual_arrive_tm,
         |driver_id,
         |driver_name,
         |line_time,
         |line_distance,
         |actual_run_time,
         |is_stop,
         |carrier_type,
         |vehicle_type,
         |time,
         |rt_dist,
         |highwaymileage,
         |toll_charge,
         |pns_dist,
         |pns_time,
         |ac_is_run_ontime,
         |src,
         |conduct_type,
         |if_evaluate_time,
         |if_error,
         |stop_over_zone_code,
         |transoport_level,
         |accrual_dist,
         |accrual_dist_type,
         |update_tm,
         |deputy_driver_id,
         |deputy_driver_name,
         |if_appeal,
         |appeal_result,
         |main_driver_account,
         |deputy_driver_account,
         |create_time,
         |update_time
         |from $mysqlTable
         |where task_inc_day>=$inc_day1 and task_inc_day<$inc_day2
         |) as t
         |""".stripMargin

    logger.error(s"开始读取MySQL:$mysqlTable 表中数据")

    import spark.implicits._
    val orignal_df: DataFrame = spark
      .read
      .format("jdbc")
      .option("encoding","utf-8")
      .option("url", url)
      .option("user", userName)
      .option("password", passWd)
      .option("dbtable", tableName)
      .option("driver", driver)
      .option("numPartitions", 5)
      .option("fetchsize", 1000)
      .option("batchsize", 1000)
      .load().toDF()
      .filter($"task_inc_day".isNotNull && $"task_inc_day"=!="")
      .withColumn("inc_day",$"task_inc_day")

    println(s"[$inc_day1,$inc_day2) 数据量："+orignal_df.count())
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_eta_std_line_nostop_out_di limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark, orignal_df.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_eta_std_line_nostop_out_di")

  }

}
