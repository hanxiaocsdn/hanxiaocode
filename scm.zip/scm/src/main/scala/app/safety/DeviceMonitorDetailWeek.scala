package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import utils.CommonTools.getdaysBeforeOrAfter
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, collect_list, concat, concat_ws, desc, lit, lpad, row_number, sort_array, trim, udf, when}

/**
 *需求名称：记录设备调整周明细
 *需求描述：顺丰客户对地区进行安全管理，对地区维度有相关考核指标。此表为方便取出设备调整明细，监管地区安全情况，提高周报统计效率所建。
 *需求方：黄晓冰(01422522)
 *开发: 周勇(01390943)
 *任务创建时间：20230707
 *任务id：785151
 **/

object DeviceMonitorDetailWeek extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    val dayvar = args(0)
    val dayvar7 = getdaysBeforeOrAfter(dayvar, -6)
    val dayvar8 = getdaysBeforeOrAfter(dayvar, -7)
    val dayvar30 = getdaysBeforeOrAfter(dayvar, -30)
    logger.error("接收输入变量dayvar:" + dayvar)
    logger.error("接收输入变量dayvar7:" + dayvar7)
    logger.error("接收输入变量dayvar8:" + dayvar8)
    logger.error("接收输入变量dayvar30:" + dayvar30)

    //获取日度明细
    val daydetail=spark.sql(
      s"""
         |select * from dm_gis.dm_deviceadjust_monitor_df
         |where inc_day='$dayvar8'
         |""".stripMargin)

    //设备质检日志:确认调整
    val selfcheck_log=spark.sql(
      s"""
         |SELECT car_no, camera_type,count(car_no) car_ct
         |FROM  dm_gis.dm_marvin_zt_device_selfcheck_log_log_di
         |WHERE  check_result = '2' and inc_day ='$dayvar'
         |and regexp_replace(create_date,'-','') >='$dayvar7' and regexp_replace(create_date,'-','') <='$dayvar'
         |GROUP BY car_no, camera_type
         |""".stripMargin)
      .withColumn("position_text",when($"camera_type"==="0","adas").when($"camera_type"==="1","dms").otherwise(""))
      .withColumn("log_flag",when($"car_ct">0,"1").otherwise("0"))
      .select("car_no","position_text","log_flag")

    //设备质检日志:调整成功
    val selfcheck_log2=spark.sql(
      s"""
         |SELECT car_no, camera_type,count(car_no) car_ct
         |FROM  dm_gis.dm_marvin_zt_device_selfcheck_log_log_di
         |WHERE  system_check_result = '1' and inc_day ='$dayvar'
         |and regexp_replace(create_date,'-','') >='$dayvar7' and regexp_replace(create_date,'-','') <='$dayvar'
         |GROUP BY car_no, camera_type
         |""".stripMargin)
      .withColumn("position_text",when($"camera_type"==="0","adas").when($"camera_type"==="1","dms").otherwise(""))
      .withColumn("log_flag2",when($"car_ct">0,"1").otherwise("0"))
      .select("car_no","position_text","log_flag2")

    //设备质检日志:我已核实
    val selfcheck_log3=spark.sql(
      s"""
         |SELECT car_no, camera_type,count(car_no) car_ct
         |FROM  dm_gis.dm_marvin_zt_device_selfcheck_log_log_di
         |WHERE  check_result = '4' and inc_day ='$dayvar'
         |and regexp_replace(create_date,'-','') >='$dayvar7' and regexp_replace(create_date,'-','') <='$dayvar'
         |GROUP BY car_no, camera_type
         |""".stripMargin)
      .withColumn("position_text",when($"camera_type"==="0","adas").when($"camera_type"==="1","dms").otherwise(""))
      .withColumn("log_flag3",when($"car_ct">0,"1").otherwise("0"))
      .select("car_no","position_text","log_flag3")

    //设备质检日志:无法调整
    val selfcheck_log4=spark.sql(
      s"""
         |SELECT car_no, camera_type,count(car_no) car_ct
         |FROM  dm_gis.dm_marvin_zt_device_selfcheck_log_log_di
         |WHERE  check_result = '3' and inc_day ='$dayvar'
         |and regexp_replace(create_date,'-','') >='$dayvar7' and regexp_replace(create_date,'-','') <='$dayvar'
         |GROUP BY car_no, camera_type
         |""".stripMargin)
      .withColumn("position_text",when($"camera_type"==="0","adas").when($"camera_type"==="1","dms").otherwise(""))
      .withColumn("log_flag4",when($"car_ct">0,"1").otherwise("0"))
      .select("car_no","position_text","log_flag4")

    //连续异常天数
    val device_data_days30=spark.sql(
      s"""
         |select * from dm_gis.dm_cameralist_exception_dtl
         |where inc_day>='$dayvar30' and inc_day<='$dayvar'
         |and position_text in ('adas','dms')
         |and org_name in ('顺丰自营','冷运事业部','顺丰医药','顺丰航空车辆室内外定位监管项目')
         |and tag= ''
         |and (stability>0.2 or trim(stability)= '' or stability is null)
         |""".stripMargin)
      .withColumn("is_exist",when($"position_text".isNull || trim($"position_text")==="",0).otherwise(1))
      .withColumn("rank",row_number().over(Window.partitionBy("imei","position_text","inc_day").orderBy(desc("inc_day"))))
      .filter($"rank"==="1")
      .withColumn("rank1",row_number().over(Window.partitionBy("imei","position_text").orderBy(desc("inc_day"))))
      .withColumn("rank2",lpad($"rank1",8,"0"))
      .withColumn("daytype",concat($"rank2",lit("_"),$"inc_day",lit("_"),$"is_exist"))
      .groupBy("imei","position_text")
      .agg(concat_ws(";",sort_array(collect_list($"daytype"))) as "hebing")
      .withColumn("exceptiondays",countlx_udf($"hebing"))
      .withColumn("w_exceptiondays",when($"exceptiondays">30,30).otherwise($"exceptiondays"))
      .select("imei","position_text","w_exceptiondays")

    //结果统计
    val data_res=daydetail

      //是否确认调整
      .join(selfcheck_log,Seq("car_no","position_text"),"left")
      .withColumn("w_isconfigadjust",when($"log_flag"==="1","1").otherwise("0"))
      //是否调整成功
      .join(selfcheck_log2,Seq("car_no","position_text"),"left")
      .withColumn("w_isadjustsuc",when($"log_flag2"==="1","1").otherwise("0"))
      //是否我已核实
      .join(selfcheck_log3,Seq("car_no","position_text"),"left")
      .withColumn("w_ischecked",when($"log_flag3"==="1","1").otherwise("0"))
      //是否无法调整
      .join(selfcheck_log4,Seq("car_no","position_text"),"left")
      .withColumn("w_isnoadjust",when($"log_flag4"==="1","1").otherwise("0"))
      //是否成功
      .withColumn("w_issucess",when($"w_isadjustsuc"==="1" || ($"w_isconfigadjust"==="1" && $"w_isadjustsuc"==="0" && $"w_ischecked"==="1"),"1").otherwise("0"))
      .join(device_data_days30,Seq("imei","position_text"),"left")
      //增加日期
      .withColumn("inc_day",lit(dayvar))
      //是否调整
      .withColumn("w_isadjust",when($"w_isconfigadjust">="1" || $"w_ischecked">="1" || $"w_isnoadjust">="1","1").otherwise("0"))
      //清洗w_exceptiondays
      .withColumn("w_exceptiondays",when($"w_exceptiondays".isNull || trim($"w_exceptiondays")==="",0).otherwise($"w_exceptiondays"))

    val need_cols = spark.sql("""select * from dm_gis.dm_devicemonitor_detail_week limit 0""").schema.map(_.name).map(col)
    //存入正式表
    writeToHive(spark, data_res.select(need_cols: _*), Seq("inc_day"), "dm_gis.dm_devicemonitor_detail_week")

  }

  //计算连续异常天数
  def countlx(x:String): Int = {
    val x_arr = x.split(";")
    val l = x_arr.length
    var i = 0
    var flag = 1
    if (l == 1) {
      //当长度只有1
      if (x_arr(i).split("_")(2) == "1") {
        i = i + 1
      }
      else {i = i}
    }
    else {
      //当长度大于1
      while (flag == 1 && i + 1 < l) {
        //同时判断日期和异常
        if (x_arr(i).split("_")(2) == "1" && x_arr(i + 1).split("_")(1) == getdaysBeforeOrAfter(x_arr(i).split("_")(1), -1)) {
          i = i + 1
          flag = 1
        }
        else flag = 0
      }
      //由于第一天一定不为空，所以加上第一天
      i=i+1
    }
    i
  }

  val countlx_udf=udf(countlx _)

}
