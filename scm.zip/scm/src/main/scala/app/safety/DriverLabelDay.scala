package app.safety

import app.safety.DriverAlarmDay.startfun
import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.storage.StorageLevel
import utils.CommonTools.{getnow, tranTimeToLong}
import org.apache.log4j.Logger

/**
 *需求名称：司机画像日结表结果表-结果汇总
 *需求描述：为了降低司机驾驶风险，增加各项监控指标。
 *需求方：算法对接：01374048王珊珊，产品：ft80006475高梅
 *开发: 周勇(01390943)
 *任务创建时间：20221023
 *任务id：785132
 **/

object DriverLabelDay  extends  DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args:Array[String] )={
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._

    import spark.implicits._
    //获取传入参数日期
    val input_inc_day=args(0)
    //计算日度告警中间表
    startfun(spark,input_inc_day)
    //执行司机基础信息
    println("当前时间1："+getnow())
    val tempzy20221109_driver_basic=driver_basicinfo(spark,input_inc_day)
    //执行司机事故信息
    val sql1=s"""
                |select *,regexp_replace(substr(accident_time,0,10),"-","") accident_day,
                |case when road_type='1' then '高速公路'
                |when road_type='2' then '国道'
                |when road_type='3' then '省道'
                |when road_type='4' then '县道'
                |when road_type='5' then '乡公路'
                |when road_type='6' then '县乡村内部道路'
                |when road_type='8' then '城市快速道'
                |when road_type='9' then '主要道路'
                |when road_type='10' then '次要道路'
                |when road_type='11' then '普通道路'
                |when road_type='12' then '非导航道路'
                |when road_type='13' then '服务区/停车场'
                |else '' end road_type_name
                |from dm_arss.dm_tc_accident_info
                |where del_status='0' and inc_day='20221109'
                |and regexp_replace(substr(accident_time,0,10),"-","")>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day}','yyyymmdd'),'yyyy-mm-dd'),183),'-','')
                |""".stripMargin
    val tempzy20221110_accident_drivermobile =spark.sql(sql1).persist(StorageLevel.MEMORY_AND_DISK)
    //据护航事故表和当天出车任务只有唯一来识别司机身份，最近半年出车任务
    val sql2=s"""
                |select vehicle_serial as car_no,main_driver_account,actual_depart_tm,actual_arrive_tm,
                |regexp_replace(substr(actual_depart_tm,0,10),"-","") actual_depart_day,coalesce(gis_distance,line_distance,0) new_miles
                |from dm_grd.grd_new_task_detail
                |where inc_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day}','yyyymmdd'),'yyyy-mm-dd'),183),'-','')
                |and inc_day<=${input_inc_day}
                |and state='6'
                |and main_driver_account is not null and main_driver_account !=''
               """.stripMargin

    val task_data=spark.sql(sql2).persist(StorageLevel.MEMORY_AND_DISK)
    //根据车牌号码匹配识别
    val tempzy20221110_accident_drivermobile_carno=tempzy20221110_accident_drivermobile.select("car_no").distinct()

    val tempzy20221110_task_detail_drivermobile=task_data
      .join(tempzy20221110_accident_drivermobile_carno,Seq("car_no"),"inner")

    //当天车子有不同司机出车任务，根据具体任务时间来匹配
    val tempzy20221110_task_detail_mutip1=tempzy20221110_accident_drivermobile.join(tempzy20221110_task_detail_drivermobile,
      tempzy20221110_accident_drivermobile("car_no")===tempzy20221110_task_detail_drivermobile("car_no")
        && tempzy20221110_accident_drivermobile("accident_day")===tempzy20221110_task_detail_drivermobile("actual_depart_day")
      ,"left")

    //选取时间范围内的第一个任务
    val tempzy20221110_task_detail_mutip2=tempzy20221110_task_detail_mutip1.filter($"accident_time">=$"actual_depart_tm" && $"accident_time"<=$"actual_arrive_tm")
      .withColumn("rank", row_number().over(Window.partitionBy("id").orderBy(desc("actual_depart_tm"))))
      .filter($"rank"===1)
      .drop("rank")

    //根据护航事故表的手机号识别司机身份
    val tempzy20221110_task_detail_mutip2new=tempzy20221110_task_detail_mutip2.select("id","main_driver_account")
    val tempzy20221110_accident_drivermobile_result=tempzy20221110_accident_drivermobile.join(tempzy20221110_task_detail_mutip2new,Seq("id"),"left")

    //司机电话号码匹配，以防电话重复，做去重处理
    spark.sql("add jar hdfs://sfbdp1/tmp/udf/01397450/97887/1000/decrypt-1.0.0.jar")
    spark.sql("add file hdfs://sfbdp1//tmp/udf/sfencode/01390943/sfdencrpt.ini")
    spark.sql("create temporary function new_decrypt as 'com.sf.udf.decrypt.Decrypt'")

    val sql6=s"""
                |select * from (
                |select *,row_number() over(partition by mobile_phone_mw order by emp_codea desc) rankb from (
                |select emp_code as emp_codea,mobile_phone,new_decrypt(mobile_phone) mobile_phone_mw
                |from dm_gis_scm.dm_scm_driver
                |where inc_day=${input_inc_day}
                |) x where length(mobile_phone_mw)>8
                |) y where y.rankb=1""".stripMargin
    val tempzy20221110_accident_driver_labelinfo=spark.sql(sql6).select("mobile_phone_mw","emp_codea").persist(StorageLevel.MEMORY_AND_DISK)

    //判断工号
    val tempzy20221110_accident_drivermobile_result2=tempzy20221110_accident_drivermobile_result.join(tempzy20221110_accident_driver_labelinfo,
      tempzy20221110_accident_drivermobile_result("driver_mobile")===tempzy20221110_accident_driver_labelinfo("mobile_phone_mw"),"left")
      .withColumn("emp_code",when($"main_driver_account".isNull || trim($"main_driver_account")==="",$"emp_codea").otherwise($"main_driver_account"))

    //告警申诉,剔除1和4申诉成功的
    val alarm_appeal=spark.sql(s"""select alarm_id,alarm_id as alarm_ida from dm_gis.dm_alarm_appeal
                                  |where inc_day='${input_inc_day}' and appeal_status in ('1','4')""".stripMargin)

    alarm_appeal.createOrReplaceTempView("alarm_appeal_tb")

    //司机告警信息匹配
    val sql8=s"""
                |select attribute6 emp_code,alarm_time,is_meddle,tf_flag,alarm_id,concat(ft_p_type,'|',ft_sub_type,'|',p_type_r,'|',sub_type_r) hb,
                |risk_level,defend_status
                |from dm_arss.dm_alarm_detail_dtl_di
                |where attribute6 is not null and attribute6 !=''
                |and inc_day<=${input_inc_day}
                |and inc_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day}','yyyymmdd'),'yyyy-mm-dd'),185),'-','')
              """.stripMargin

    //告警配置表
    val alarm_config=spark.sql(s"""select alarm_p_name,sub_name,concat(alarm_p_type,'|',alarm_sub_type,'|',p_type,'|',sub_type) hb from dm_gis_scm.dm_tc_alarm_rule
                                  |where inc_day=${input_inc_day}""".stripMargin)

    val x1=spark.sql(sql8)
    val x2=tempzy20221110_accident_drivermobile_result2.select("emp_code").distinct()
    val tempzy20221110_accident_driver_alarm=x1.join(x2,Seq("emp_code"),"inner")
      .join(alarm_config,Seq("hb"),"left")
      .join(alarm_appeal,Seq("alarm_id"),"left")
      .filter($"alarm_p_name".isin ("DMS","HOD","ADAS","过激驾驶"))
      .withColumn("is_appeal",when($"alarm_ida".isNotNull,1).otherwise(0))
      .withColumn("is_need",when($"sub_name"==="打电话" && $"is_meddle"===1 &&  $"tf_flag"===1 && $"is_appeal"===0,1).
        when($"sub_name"==="打电话" ,0).
        when($"sub_name"==="摄像头遮挡" && $"is_meddle"===1 &&  $"tf_flag"===1 && $"is_appeal"===0,1).
        when($"sub_name"==="摄像头遮挡" ,0).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") && $"is_meddle"===1 &&  $"tf_flag"===1 && $"risk_level"==="1",1).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") && $"is_meddle"===1 &&  $"tf_flag"===1 && $"defend_status"==="2",1).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") ,0).
        when($"alarm_p_name"==="ADAS" ,1).
        when($"alarm_p_name"==="过激驾驶" ,1).
        when($"alarm_p_name"==="DMS" && $"tf_flag"===1,1).
        when($"alarm_p_name"==="HOD" && $"tf_flag"===1,1).
        otherwise(0))
      .filter($"is_need"===1)

    //匹配告警明细
    val tempzy20221110_accident_driver_alarm2=tempzy20221110_accident_drivermobile_result2.join(tempzy20221110_accident_driver_alarm
      ,Seq("emp_code"),"left")
      .select("id","emp_code","accident_time","road_type_name","alarm_time")

    //创建临时表
    tempzy20221110_accident_driver_alarm2.createOrReplaceTempView("tmpx1")

    //识别事故24\48小时内告警

    val sql10="""
                |select id,emp_code,accident_time,alarm_time,
                |concat(date_sub(from_unixtime(unix_timestamp(regexp_replace(substr(accident_time,0,10),"-",""),'yyyymmdd'),'yyyy-mm-dd'),1),substr(accident_time,11,9)) time24,
                |concat(date_sub(from_unixtime(unix_timestamp(regexp_replace(substr(accident_time,0,10),"-",""),'yyyymmdd'),'yyyy-mm-dd'),2),substr(accident_time,11,9)) time48
                |from tmpx1""".stripMargin
    val tempzy20221110_accident_driver_alarm3=spark.sql(sql10)


    //识别事故24小时内告警
    val tempzy20221110_accident_driver_alarm4=tempzy20221110_accident_driver_alarm3.filter($"alarm_time"<=$"accident_time" && $"alarm_time">=$"time24")
      .groupBy("emp_code","accident_time")
      .agg(count($"emp_code") as "ct24")

    //识别事故48小时内告警
    val tempzy20221110_accident_driver_alarm5=tempzy20221110_accident_driver_alarm3.filter($"alarm_time"<=$"accident_time" && $"alarm_time">=$"time48")
      .groupBy("emp_code","accident_time")
      .agg(count($"emp_code") as "ct48")

    //24、48小时告警统计

    val tempzy20221110_accident_driver_alarm7=tempzy20221110_accident_drivermobile_result2.filter($"emp_code".isNotNull && trim($"emp_code") =!="")
      .join(tempzy20221110_accident_driver_alarm4,
        Seq("emp_code","accident_time"),"left")
      .join(tempzy20221110_accident_driver_alarm5,
        Seq("emp_code","accident_time"),"left")
      .withColumn("ct24",when($"ct24".isNull || trim($"ct24") ==="",0).otherwise($"ct24"))
      .withColumn("ct48",when($"ct48".isNull || trim($"ct48") ==="",0).otherwise($"ct48"))
      .withColumn("time_hour",substring($"accident_time",12,2)+0.0)
      .withColumn("time_type",when($"time_hour"<7,"凌晨").when($"time_hour"<10,"清晨").
        when($"time_hour"<13,"中午").when($"time_hour"<17,"午后").
        when($"time_hour"<20,"黄昏").when($"time_hour"<24,"夜间").otherwise(""))
      .withColumn("accid_rank", row_number().over(Window.partitionBy("emp_code").orderBy(desc("accident_time"))))


    val tempzy20221110_accident_driver_alarm8=tempzy20221110_accident_driver_alarm7
      .withColumn("accident_type",concat(lit("\"rank_"),$"accid_rank",lit("\":\""),lit("无"),lit("\"")))
      .withColumn("accident_time",concat(lit("\"rank_"),$"accid_rank",lit("\":\""),$"accident_time",lit("\"")))
      .withColumn("accident_alarm_24",concat(lit("\"rank_"),$"accid_rank",lit("\":"),$"ct24"))
      .withColumn("accident_alarm_48",concat(lit("\"rank_"),$"accid_rank",lit("\":"),$"ct48"))
      .withColumn("accident_road_type",concat(lit("\"rank_"),$"accid_rank",lit("\":\""),$"road_type_name",lit("\"")))
      .withColumn("accident_time_type",concat(lit("\"rank_"),$"accid_rank",lit("\":\""),$"time_type",lit("\"")))
      .withColumn("insturance_type",concat(lit("\"rank_"),$"accid_rank",lit("\":"),lit("无")))
      .withColumn("insturance_cost",concat(lit("\"rank_"),$"accid_rank",lit("\":"),lit("无")))
      .groupBy("emp_code")
      .agg(concat(lit("{"),concat_ws(",",sort_array(collect_list($"accident_type"))),lit("}")) as("d_accident_type"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"accident_time"))),lit("}")) as("d_accident_time"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"accident_alarm_24"))),lit("}")) as("d_accident_alarm_24"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"accident_alarm_48"))),lit("}")) as("d_accident_alarm_48"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"accident_road_type"))),lit("}")) as("d_accident_road_type"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"accident_time_type"))),lit("}")) as("d_accident_time_type"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"insturance_type"))),lit("}")) as("d_insturance_type"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"insturance_cost"))),lit("}")) as("d_insturance_cost")
      ).select("emp_code","d_accident_type","d_accident_time","d_accident_alarm_24","d_accident_alarm_48","d_accident_road_type",
      "d_accident_time_type","d_insturance_type","d_insturance_cost")

    //新建临时表
    tempzy20221110_accident_driver_alarm8.createOrReplaceTempView("temp_tb8")
    //数据存dm表
    val insert_sql=s"""insert overwrite table  dm_gis_scm.driver_accident_index_d
                      |partition(inc_day=${input_inc_day})
                      |select * from temp_tb8""".stripMargin
    spark.sql(insert_sql)

    //*************************安全行驶里程
    //如果出车任务当天有发生事故，则当天不算安全驾驶
    val accid_dayinfo=tempzy20221110_accident_drivermobile_result2.filter($"emp_code".isNotNull && trim($"emp_code") =!="")
      .select("emp_code","accident_day").distinct()

    val tempzy20221114_task_detail_safety=task_data.join(accid_dayinfo,
      task_data("main_driver_account")===accid_dayinfo("emp_code") &&  task_data("actual_depart_day")===accid_dayinfo("accident_day")
      ,"left")
    //日均安全行驶时间、行驶速度、行驶里程数
    val tempzy20221114_task_detail_safety1=tempzy20221114_task_detail_safety.filter($"accident_day".isNull && $"actual_depart_tm".isNotNull
      && trim($"actual_depart_tm") =!="" && $"actual_arrive_tm".isNotNull && trim($"actual_arrive_tm") =!="" && $"new_miles">=0.05)
      .withColumn("arrive_tmnew",tranTimeToLong_udf($"actual_arrive_tm"))
      .withColumn("depart_tmnew",tranTimeToLong_udf($"actual_depart_tm"))
      .withColumn("tm_diff",($"arrive_tmnew"-$"depart_tmnew")/1000)
      .groupBy("main_driver_account","actual_depart_day")
      .agg(sum($"new_miles") as "sm",
        sum($"tm_diff")/3600 as "time_hour")
      .withColumn("sm_speed",$"sm"/$"time_hour")
      .groupBy("main_driver_account")
      .agg(round(avg($"sm"),6) as "d_safe_mileage",
        round(avg($"sm_speed"),6) as "d_safe_speed",
        round(avg($"time_hour"),6) as "d_safe_time"
      )
    //以24号为基点，在导入的手工版数据基础上累加
    val basic_taskinfo=spark.sql(s"""select actual_depart_day,main_driver_account,sum(new_miles) d_miles
                                    |from (
                                    |select  main_driver_account,gis_distance,line_distance,
                                    |regexp_replace(substr(actual_depart_tm,0,10),'-','') actual_depart_day,
                                    |coalesce(gis_distance,line_distance,0) new_miles
                                    |from dm_grd.grd_new_task_detail
                                    |where inc_day>='20220824' and inc_day<=${input_inc_day} and state='6'
                                    |and main_driver_account is not null and main_driver_account !=''
                                    |) x where actual_depart_day>'20220824'
                                    |group by actual_depart_day,main_driver_account""".stripMargin).persist(StorageLevel.MEMORY_AND_DISK)

    val accid_result2_new=tempzy20221110_accident_drivermobile_result2
      .filter($"emp_code".isNotNull && trim($"emp_code") =!="")
      .withColumn("rank", row_number().over(Window.partitionBy("emp_code").orderBy(desc("accident_day"))))
      .filter($"rank"===1)
      .select("emp_code","accident_day")

    val tempzy20221114_dayly_saftymiles1=basic_taskinfo.join(accid_result2_new,
      basic_taskinfo("main_driver_account")===accid_result2_new("emp_code"),"left")
    //安全行驶里程：出事故的司机，从事故后开始累计计算
    val tempzy20221114_dayly_saftymiles2=tempzy20221114_dayly_saftymiles1.filter($"actual_depart_day">$"accident_day")
      .groupBy("main_driver_account")
      .agg(sum(when($"d_miles".isNull || trim($"d_miles")==="",0).otherwise($"d_miles")) as "new_miles_sm")
    //安全行驶里程：没出事故的司机，历史数据再加上后面新增的
    val tempzy20221114_dayly_saftymiles2a=tempzy20221114_dayly_saftymiles1
      .groupBy("main_driver_account")
      .agg(sum(when($"d_miles".isNull || trim($"d_miles")==="",0).otherwise($"d_miles")) as "new_miles_sm2")
    //安全行驶里程
    val his_milesinfo=spark.sql("""select * from dm_gis_scm.dm_driver_safetymiles
                                  |where inc_day='20220824'
                                  |""".stripMargin).drop("inc_day")

    val tempzy20221114_dayly_saftymiles3=tempzy20221109_driver_basic.join(his_milesinfo,Seq("emp_code"),"left")
      .join(tempzy20221114_dayly_saftymiles2,tempzy20221109_driver_basic("emp_code")===tempzy20221114_dayly_saftymiles2("main_driver_account"),"left")
      .drop("main_driver_account")
      .join(tempzy20221114_dayly_saftymiles2a,tempzy20221109_driver_basic("emp_code")===tempzy20221114_dayly_saftymiles2a("main_driver_account"),"left")
      .drop("main_driver_account")
      .withColumn("his_safetymiles",when($"his_safetymiles".isNull || trim($"his_safetymiles")==="",0).otherwise($"his_safetymiles"))
      .withColumn("new_miles_sm2",when($"new_miles_sm2".isNull || trim($"new_miles_sm2")==="",0).otherwise($"new_miles_sm2"))
      .withColumn("new_safetymiles",when($"new_miles_sm".isNotNull,$"new_miles_sm").otherwise($"his_safetymiles"+$"new_miles_sm2"))

    //原始安全赋分
    val tempzy20221114_dayly_saftyscore=spark.sql(s"""
                                                     |select * from (
                                                     |select *,row_number() over(partition by emp_code order by id desc) rank
                                                     | from  dm_gis.dm_zt_driver
                                                     |where inc_day=${input_inc_day}
                                                     |) x where x.rank=1""".stripMargin
    ).select("emp_code","safety_score")
    //考试分数
    val tempzy20221114_driver_exam=spark.sql(s"""
                                                |select emp_code,exam_ct,pass_ct,cast(pass_ct/exam_ct as decimal(10,4)) exam_pass_pert
                                                |from (
                                                |select emp_code,count(*) exam_ct,count(case when emp_exam_state='1' then 1 else null end) pass_ct
                                                |from (
                                                |select *,regexp_replace(substr(exam_start_time,0,10),'-','') exam_day
                                                |from dm_gis_scm.dm_scm_driver_exam
                                                |where month<=substr(${input_inc_day},0,6)
                                                |and month>=substr(regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day}','yyyymmdd'),'yyyy-mm-dd'),183),'-',''),0,6)
                                                |and regexp_replace(substr(exam_start_time,0,10),'-','')>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day}','yyyymmdd'),'yyyy-mm-dd'),183),'-','')
                                                |and regexp_replace(substr(exam_start_time,0,10),'-','')<=${input_inc_day}
                                                |	) y group by y.emp_code
                                                |) x""".stripMargin)

    //新建临时表
    tempzy20221109_driver_basic.createOrReplaceTempView("tempzy20221109_driver_basic")
    tempzy20221114_dayly_saftymiles3.createOrReplaceTempView("tempzy20221114_dayly_saftymiles3")
    tempzy20221114_dayly_saftyscore.createOrReplaceTempView("tempzy20221114_dayly_saftyscore")
    tempzy20221114_driver_exam.createOrReplaceTempView("tempzy20221114_driver_exam")
    tempzy20221114_task_detail_safety1.createOrReplaceTempView("tempzy20221114_task_detail_safety1")

    //数据入库
    val all_result_sql=s"""
                          |select
                          |t1.name as driver_name	,---姓名
                          |case when t8.driver_state	is null then '离职' else t8.driver_state end 	driver_state,---在职状态
                          |t1.emp_code as driver_code	,---工号
                          |t2.new_safetymiles as driver_safe_mileage,---	安全行驶里程
                          |t3.safety_score as driver_safe_mark	,---安全赋分
                          |t1.driving_age as driver_experience	,---驾龄
                          |t1.quasi_driving_type as driver_license	,---驾照类型
                          |t5.d_accident_type	,---过去半年事故等级
                          |t5.d_accident_time	,---过去半年事故时间
                          |t5.d_accident_alarm_24	,---过去半年事故发生前24小时告警总数
                          |t5.d_accident_alarm_48	,---过去半年事故发生前48小时告警总数
                          |t5.d_accident_road_type	,---过去半年事故发生道路类型
                          |t5.d_accident_time_type	,---过去半年事故发生时间类型
                          |t5.d_insturance_type	,---过去半年理赔责任类型
                          |t5.d_insturance_cost	,---过去半年理赔总金额
                          |t6.exam_ct as d_study_all	,---过去半年司机学习次数
                          |t6.exam_pass_pert as d_study_rate	,---过去半年司机学习通过率
                          |case when t1.character_type='1' then '多血质型'
                          |when t1.character_type='2' then '胆汁质型'
                          |when t1.character_type='3' then '粘液质型'
                          |when t1.character_type='4' then '抑郁质型'
                          |else '' end as driver_nature	,---司机性格
                          |t1.driver_license_deadline	,---驾驶证有效截止日期
                          |'' d_meeting_state	,---当天是否例会参与度
                          |t7.d_safe_mileage	,---过去半年日均安全里程数
                          |t7.d_safe_speed	,---过去半年日均安全行驶速度
                          |t7.d_safe_time,	---过去半年日均安全行驶时间
                          |t1.dept_code,t1.dept_name,t1.motorcade_code,t1.motorcade_name,t1.area_code,t1.area_name
                          |from tempzy20221109_driver_basic t1
                          |left join tempzy20221114_dayly_saftymiles3 t2
                          |on t1.emp_code=t2.emp_code
                          |left join tempzy20221114_dayly_saftyscore t3
                          |on t1.emp_code=t3.emp_code
                          |left join
                          |(
                          |select * from dm_gis_scm.driver_accident_index_d
                          |where inc_day=${input_inc_day}
                          |) t5 on t1.emp_code=t5.emp_code
                          |left join tempzy20221114_driver_exam t6
                          |on t1.emp_code=t6.emp_code
                          |left join tempzy20221114_task_detail_safety1 t7
                          |on t1.emp_code=t7.main_driver_account
                          |left join
                          |(select emp_code,case when cancel_flag='Y' then '离职' else '在职' end driver_state
                          | from dim.dim_emp_info_df where inc_day=${input_inc_day}
                          |) t8 on lpad(t1.emp_code,8,'0')=lpad(t8.emp_code,8,'0')""".stripMargin

    val accident_index=spark.sql(s"""select * from dm_gis_scm.dm_driver_alarm_fact_d
                                    |where inc_day=${input_inc_day}""".stripMargin)


    val table_cols = spark.sql("""select * from dm_gis_scm.dm_driver_label_day limit 0""").schema.map(_.name).map(col)

    val tempzy20221114_driver_insert=spark.sql(all_result_sql)

    val final_res=tempzy20221114_driver_insert.join(accident_index,tempzy20221114_driver_insert("driver_code")===accident_index("emp_code"),"left")
      .withColumn("inc_day",lit(input_inc_day))
      .drop("emp_code")
      .select(table_cols: _*)

    //数据存dm表
    writeToHive(spark, final_res, Seq("inc_day"), "dm_gis_scm.dm_driver_label_day")

    println("运行已结束，当前时间："+getnow())
    spark.close()

  }

  val tranTimeToLong_udf=udf(tranTimeToLong _)

  //*************************清洗出司机基础信息，以20220824日生效的司机作为基础，后面添加的司机都需要做画像
  def driver_basicinfo(spark:SparkSession,input_inc_day:String): DataFrame ={
    import spark.implicits._
    //最新的全量司机
    val sql1=s"""select * from (
                |select *,row_number() over(partition by emp_codeb order by modify_tm desc) ranka
                |from (
                |select *,case when length(int(emp_code))<=6 then lpad(int(emp_code),6,'0')
                |when length(int(emp_code))<=8 then lpad(int(emp_code),8,'0')
                |else emp_code end emp_codeb from dm_gis_scm.dm_scm_driver
                |where inc_day=$input_inc_day and emp_code is not null and emp_code !=''  and driver_type='1'
                |and length(emp_code)<=8
                |) x
                |) y where y.ranka=1
                |""".stripMargin
    val tempzy20221109_driver_basic_org1=spark.sql(sql1)
    //8月24号全量司机
    val sql2="""
               |select * from
               |(
               |select *,row_number() over(partition by emp_codeb order by modify_tm desc) ranka
               |from (
               |select *,case when length(int(emp_code))<=6 then lpad(int(emp_code),6,'0')
               |when length(int(emp_code))<=8 then lpad(int(emp_code),8,'0')
               |else emp_code end emp_codeb from dm_gis_scm.dm_scm_driver
               |where inc_day='20220824' and emp_code is not null and emp_code !='' and driver_type='1'
               |) x
               |) y where y.ranka=1
               |""".stripMargin
    val tempzy20221109_driver_basic_org2=spark.sql(sql2).withColumn("emp_codeb2",$"emp_codeb")
      .select("emp_codeb2","emp_codeb")
    //8月24号在职司机
    val sql3="""
               |select * from
               |(
               |select *,row_number() over(partition by emp_codeb order by modify_tm desc) ranka
               |from (
               |select *,case when length(int(emp_code))<=6 then lpad(int(emp_code),6,'0')
               |when length(int(emp_code))<=8 then lpad(int(emp_code),8,'0')
               |else emp_code end emp_codeb from dm_gis_scm.dm_scm_driver
               |where inc_day='20220824' and emp_code is not null and emp_code !=''
               | and driver_type='1' and (state_new='1' or state_new is null or state_new='')
               |) x
               |) y where y.ranka=1
               |""".stripMargin
    val tempzy20221109_driver_basic_org3=spark.sql(sql3)
      .select("emp_codeb")
    //相比8月24号全量新增的部分
    val tempzy20221109_driver_basic_org4=tempzy20221109_driver_basic_org1.join(tempzy20221109_driver_basic_org2
      .filter($"state_new"==="1" || $"state_new".isNull || $"state_new"===""),
      Seq("emp_codeb"),"left")
      .filter($"emp_codeb2".isNull)
      .drop("emp_codeb2")
    //保留8月24号生效的部分
    val tempzy20221109_driver_basic_org5=tempzy20221109_driver_basic_org1.join(tempzy20221109_driver_basic_org3,
      Seq("emp_codeb"),"inner")

    //车队信息
    val sql5a=s"""
                 |SELECT t1.dept_id,t1.motorcade_code,t2.motorcade_name
                 |FROM (
                 |select * from (
                 |SELECT motorcade_code, dept_id, ROW_NUMBER() OVER (PARTITION BY dept_id ORDER BY create_tm DESC ) AS rn
                 |FROM ods_shiva_ground.ts_motorcade_dept
                 |WHERE inc_day= '${input_inc_day}') x where rn = 1
                 |) t1
                 |LEFT JOIN
                 |(SELECT motorcade_code, motorcade_name from ods_shiva_ground.ts_motorcadeinfo
                 |WHERE inc_day= '${input_inc_day}'
                 |) t2 ON t1.motorcade_code = t2.motorcade_code""".stripMargin
    val tempzy20221114_driver_motorcade=spark.sql(sql5a)

    //参数配置表
    val tm_vms_vehicle_use_kind=spark.sql(
      s"""
         |select use_kind_code,use_kind_name from ods_vms.tm_vms_vehicle_use_kind
         |where inc_day=$input_inc_day
         |""".stripMargin)

    //维度信息表
    val dim_department=spark.sql("""
                                   |select dept_id,area_code,area_name,create_tm
                                   | from dim.dim_department  where delete_flg=0 """.stripMargin)
      .withColumn("rank", row_number().over(Window.partitionBy("dept_id").orderBy(desc("create_tm"))))
      .filter($"rank"===1)
      .drop("rank","create_tm")

    //司机基础信息清洗底表合并
    val tempzy20221109_driver_basic=tempzy20221109_driver_basic_org4.union(tempzy20221109_driver_basic_org5)
      .join(tm_vms_vehicle_use_kind,Seq("use_kind_code"),"left")
      .join(tempzy20221114_driver_motorcade,Seq("dept_id"),"left")
      .join(dim_department,Seq("dept_id"),"left")

    return tempzy20221109_driver_basic
  }

}
