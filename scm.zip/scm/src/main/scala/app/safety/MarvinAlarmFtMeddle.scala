package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
 **author:01390943 周勇
 **需求方：01422522 黄晓冰。历史需求方：ft80006475 高梅
 **description:自营丰图需干预明细，顺丰客户对地区进行安全管理，对地区维度有相关考核指标，此表为方便客户取出告警明细，监管地区安全情况，提高周报统计效率所建。
 **任务id：785142
 **/

object MarvinAlarmFtMeddle  extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args:Array[String])={
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._
    //取跑数T-1日期
    val day1 = args(0)
    val day2 = args(1)
    val day3 = args(2)
    val day2a = args(3)

    //更新历史数据
    update_alarm_detail(spark,day1,day2a)

    //所有符合要求的告警记录
    val alarm_mid=spark.sql(
      s"""
         |select *,regexp_replace(substr(alarm_time,0,10),'-','') alarm_day,
         |date_add(next_day(from_unixtime(unix_timestamp(inc_day,'yyyymmdd'),'yyyy-mm-dd'),'MO'),-7) as biz_week,
         |date_add(next_day(from_unixtime(unix_timestamp(inc_day,'yyyymmdd'),'yyyy-mm-dd'),'MO'),0) as biz_week2,
         |case when attribute7 is null then int(1000000*rand()) else attribute7 end task_id
         |from dm_gis_scm.dm_marvinmeddle_alarm_detail
         |where inc_day>='$day3' and car_no not in
         |('京ABB7672a','沪AB98860a','京ABD3893a','沪AB93528a','沪AB95531a','沪AB93360a','沪AB87862a','京ABD3796a',
         |'沪AB82863a','京ABD8712a','沪AB98939a','京ABD5339a','京ABE6372a','沪AB85728a','京ABE7138a','京ABB5660a',
         |'京ABB3080a','京ABD3813a','京ABB9528a','京ABA8202a','京ABB7183a','苏FDG2099a','苏FDK7918a','苏FDG6681a',
         |'苏FDG2200a','苏FDK9188a','苏FDG8359a','苏FDG8208a','京ABE2176a','京ABB8122a','京ABE2291a','京ABD0535a',
         |'京ABB1033a','京ABB6503a','京ABD5062a','京ABD5532a','京ABE6983a','京ABB5297a','京ABD3273a','京ABB5107a',
         |'京ABD8370a','京ABD9121a','京ABB5839a','京ABA0878a','京ABD1276a','京ABE9511a','京ABE5306a','京ABE2966a',
         |'京ABE5131a','京ABE7851a','京ABD3253a','京ABD9378a','京ABD7371a','京ABE7156a','京ABD2835a','京ABE3582a',
         |'京ABD1290a','京ABE6139a')
         |""".stripMargin)
      //用于关联告警的下一个周一申诉状态
      .withColumn("joinday",regexp_replace($"biz_week2","-",""))

    //申诉记录,筛选星期一的数据
    val alarm_appeal=spark.sql(
      s"""
         |select *,pmod(datediff(from_unixtime(unix_timestamp(inc_day,'yyyymmdd'),'yyyy-mm-dd'), '2012-01-01'), 7) dayns,
         |inc_day as appeal_inc_day,inc_day as joinday
         |from dm_gis.dm_alarm_appeal
         |where inc_day>=${day3}
         |""".stripMargin)
      .filter($"dayns".cast("string")==="1")
      .withColumn("appeal_status_first",$"appeal_status")
      .select("appeal_inc_day","appeal_status_first","alarm_id","dayns","joinday")

      //保存测试数据
//      spark.sql("drop table if exists tmp_dm_gis.tmp_zy_alarm_appeal")
//      alarm_appeal.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tmp_zy_alarm_appeal")

    val alarm_mid2=alarm_mid.join(alarm_appeal,Seq("alarm_id","joinday"),"left")
      .withColumn("appeal_inc_day",when($"appeal_inc_day".isNull || $"appeal_inc_day"==="","99990101").otherwise($"appeal_inc_day"))
      .filter($"alarm_day"<$"appeal_inc_day")
      .withColumn("rank",row_number().over(Window.partitionBy("alarm_id").orderBy(asc("appeal_inc_day"))))
      .filter($"rank"===1)
      .drop("rank")

    //保存测试数据
//    spark.sql("drop table if exists tmp_dm_gis.tmp_zy_alarm_appeal2")
//    alarm_mid2.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tmp_zy_alarm_appeal2")

    //申诉的T-1分区
    val alarm_appeal_day=spark.sql(
      s"""
         |select alarm_id,appeal_status from dm_gis.dm_alarm_appeal
         |where inc_day='$day1'
         |""".stripMargin)

    val appeal_status_condition=when($"appeal_status"==="0","初检审核中").
      when($"appeal_status"==="1","初检结束-通过").
      when($"appeal_status"==="2","初检结束-未通过").
      when($"appeal_status"==="3","终检审核中").
      when($"appeal_status"==="4","终检结束-通过").
      when($"appeal_status"==="5","终检结束-未通过").
      when($"appeal_status"==="6","初检未通过").
      otherwise("")

    val defend_status_condition=when($"defend_status"==="0","待处理").
      when($"defend_status"==="1","处理中").
      when($"defend_status"==="2","已处理").
      otherwise($"defend_status")

    val dayn_condition= when($"dayn"==="1","周一").
      when($"dayn"==="2","周二").
      when($"dayn"==="3","周三").
      when($"dayn"==="4","周四").
      when($"dayn"==="5","周五").
      when($"dayn"==="6","周六").
      when($"dayn"==="0","周日").
      otherwise("")

    val isgz_condition=when($"alarm_name"==="打电话","是").
      when($"alarm_name"==="摄像头遮挡","是").
      when($"risk_level"==="高","是").
      when($"defend_status_temp"==="1","是").
      when($"defend_status_temp"==="2","是").
      otherwise("否")

    val is_gzcar_condition=when($"car_no".isin("京ABB7672","沪AB98860","京ABD3893","沪AB93528","沪AB95531","沪AB93360","沪AB87862",
      "京ABD3796","沪AB82863","京ABD8712","沪AB98939","京ABD5339","京ABE6372","沪AB85728",
      "京ABE7138","京ABB5660","京ABB3080","京ABD3813","京ABB9528","京ABA8202","京ABB7183",
      "苏FDG2099","苏FDK7918","苏FDG6681","苏FDG2200","苏FDK9188","苏FDG8359","苏FDG8208",
      "京ABE2176","京ABB8122","京ABE2291","京ABD0535","京ABB1033","京ABB6503","京ABD5062",
      "京ABD5532","京ABE6983","京ABB5297","京ABD3273","京ABB5107","京ABD8370","京ABD9121",
      "京ABB5839","京ABA0878","京ABD1276","京ABE9511","京ABE5306","京ABE2966","京ABE5131",
      "京ABE7851","京ABD3253","京ABD9378","京ABD7371","京ABE7156","京ABD2835","京ABE3582",
      "京ABD1290","京ABE6139"),"否").otherwise("是")

    val appeal_status_first_condition= when($"appeal_status_first"==="0","初检审核中").
      when($"appeal_status_first"==="1","初检结束-通过").
      when($"appeal_status_first"==="2","初检结束-未通过").
      when($"appeal_status_first"==="3","终检审核中").
      when($"appeal_status_first"==="4","终检结束-通过").
      when($"appeal_status_first"==="5","终检结束-未通过").
      when($"appeal_status_first"==="6","初检未通过").
      otherwise("")

    val is_nextwk_condition=when($"appeal_status_first_temp".isin("0","6","3") && $"appeal_status_temp".isin("2","5"),"是")
      .otherwise("")

    //类型：分两种情况判断is_nextwk='是' 和空
    val typ_condition=when(($"is_nextwk".isNull || trim($"is_nextwk")==="") &&
      $"isgz"==="是" && $"is_gzcar"==="是" && !$"alarm_name".isin("打电话","摄像头遮挡")
      && !$"appeal_status_first".isin ("初检审核中", "初检未通过","终检审核中", "初检结束-通过","终检结束-通过")
      ,"疲劳高危"   )
      .when(($"is_nextwk".isNull || trim($"is_nextwk")==="") &&
        $"isgz"==="是" && $"is_gzcar"==="是" && $"alarm_name"==="打电话"
        && !$"appeal_status_first".isin ("初检审核中", "初检未通过","终检审核中", "初检结束-通过","终检结束-通过")
        ,"打电话")
      .when(($"is_nextwk".isNull || trim($"is_nextwk")==="") &&
        $"isgz"==="是" && $"is_gzcar"==="是" && $"alarm_name"==="摄像头遮挡"
        && !$"appeal_status_first".isin ("初检审核中", "初检未通过","终检审核中", "初检结束-通过","终检结束-通过")
        ,"遮挡")
      .when( ($"is_nextwk".isNull || trim($"is_nextwk")==="") &&
        $"is_gzcar"==="是" && $"alarm_name"==="吸烟"
        && !$"appeal_status_first".isin ("初检审核中", "初检未通过","终检审核中", "初检结束-通过","终检结束-通过")
        ,"非速运-吸烟")
      .when( ($"is_nextwk".isNull || trim($"is_nextwk")==="") &&
        $"is_gzcar"==="是" && $"alarm_name"==="设备超时告警"
        ,"超时")
      .when( ($"is_nextwk".isNull || trim($"is_nextwk")==="") &&
        $"is_gzcar"==="是" && $"alarm_name"==="设备超速告警"
        ,"超速")
      .when( ($"is_nextwk".isNull || trim($"is_nextwk")==="") &&
        $"is_gzcar"==="是" && $"alarm_name"==="斑马线未减速告警"
        ,"斑马线未减速").


      when($"is_nextwk"==="是" &&
        $"isgz"==="是" && $"is_gzcar"==="是" && !$"alarm_name".isin("打电话","摄像头遮挡")
        && !$"appeal_status_first".isin ("初检结束-通过", "终检结束-通过")
        ,"疲劳高危"   )
      .when($"is_nextwk"==="是" &&
        $"isgz"==="是" && $"is_gzcar"==="是" && $"alarm_name"==="打电话"
        && !$"appeal_status_first".isin ("初检结束-通过", "终检结束-通过")
        ,"打电话")
      .when($"is_nextwk"==="是" &&
        $"isgz"==="是" && $"is_gzcar"==="是" && $"alarm_name"==="摄像头遮挡"
        && !$"appeal_status_first".isin ("初检结束-通过", "终检结束-通过")
        ,"遮挡")
      .when( $"is_nextwk"==="是" &&
        $"is_gzcar"==="是" && $"alarm_name"==="吸烟"
        && !$"appeal_status_first".isin ("初检结束-通过", "终检结束-通过")
        ,"非速运-吸烟")
      .otherwise("")

    //统计周
    val static_week_condition=when($"is_nextwk"==="是",$"biz_week2").otherwise($"biz_week")

    //匹配任务数据
    val taskgrd=spark.sql(
      s"""
         |select task_id,task_area_code,ground_task_id,line_code
         |from dm_grd.grd_new_task_detail
         |where inc_day>='$day3' and inc_day<='$day1'
         |""".stripMargin)

    //组织机构数据
    val dept_data2=spark.sql(
      s"""
         |select code as task_area_code,update_time,name as task_area_name from dm_arss.dm_sys_dept_dtl_di
         |where inc_Day='$day1'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("task_area_code").orderBy(desc("update_time"))))
      .filter($"rank"===1)
      .drop("update_time","rank")

    val taskgrd2=taskgrd.join(dept_data2,Seq("task_area_code"),"left")

    //获取告警明细里面的字段
    val alarm_detail2=spark.sql(
      s"""
         |select alarm_id,
         |case when audit_recieve_time is null or trim(audit_recieve_time)='' then recieve_time else audit_recieve_time end audit_recieve_time,
         |case when audit_submit_time is null or trim(audit_submit_time)='' then submit_time else audit_submit_time end audit_submit_time,
         |case when audit_status='0' then '待处理'  when audit_status='1' then '处理中'   when audit_status='2' then '已处理'
         | when audit_status='-1' then '无需处理'  else '' end audit_status,
         | case when status='0' then '待处理'  when status='1' then '处理中'   when status='2' then '已处理'
         | when status='-1' then '无需处理'  else '' end status,
         |alarm_audits,
         |defend_recieve_time,defend_submit_time,
         |defend_records,inc_day
         | from dm_arss.dm_alarm_detail_dtl_di
         |where inc_day>='$day3' and inc_day<='$day1'
         |and (
         |(is_meddle='1' and tf_flag='1'
         |and p_type = '1'
         |and alarm_name not in ('阻断型墨镜', '墨镜遮挡', '驾驶员离席', '驾驶员异常','斑马线未减速告警'))
         |or (alarm_name in ('设备超速告警','设备超时告警') and cast(speed as int) > 90 and cast(speed as int)<110)
         |or (alarm_name='斑马线未减速告警' and cast(speed as int) >= 50)
         |)
         |and attribute6 is not null
         |and trim(attribute6) != ''
         |and driver_name is not null
         |and trim(driver_name) != ''
         |""".stripMargin)
      .withColumn("alarm_audits_tmp",regexp_replace($"alarm_audits","\\[|\\]",""))
      .withColumn("defend_records_tmp",regexp_replace($"defend_records","\\[|\\]",""))
      .withColumn("ttsmsg",get_json_object($"alarm_audits_tmp","$.ttsMsg"))
      .withColumn("updefendreason",get_json_object($"alarm_audits_tmp","$.upDefendReason"))
      .withColumn("endreasonmsg",get_json_object($"defend_records_tmp","$.endReasonMsg"))
      .withColumn("audit_status",when($"audit_status".isNull || trim($"audit_status")==="",$"status").otherwise($"audit_status"))
      .withColumn("rank",row_number().over(Window.partitionBy("alarm_id").orderBy(desc("inc_day"))))
      .filter($"rank"===1)
      .drop("rank","inc_day")

    val tb_cols1 = spark.sql("""select * from dm_gis.alarm_marvin_meddle_dtl limit 0""").schema.map(_.name).map(col)

    val alarm_detail=alarm_mid2.join(alarm_appeal_day,Seq("alarm_id"),"left")
      .withColumn("appeal_status_temp",$"appeal_status")
      .withColumn("defend_status_temp",$"defend_status")
      .withColumn("appeal_status_first_temp",$"appeal_status_first")
      .withColumn("appeal_status",appeal_status_condition)
      .withColumn("defend_status",defend_status_condition)
      .withColumn("dayn",dayn_condition)
      .withColumn("isgz",isgz_condition)
      .withColumn("is_gzcar",is_gzcar_condition)
      .withColumn("appeal_status_first",appeal_status_first_condition)
      .withColumn("is_nextwk",is_nextwk_condition)
      .withColumn("types",typ_condition)
      .withColumn("static_week",static_week_condition)
      .join(taskgrd2,Seq("task_id"),"left")
      .withColumn("task_area_code",when($"name".isin("顺丰自营","冷运事业部","顺丰医药"),$"dept_code")
        .when($"task_area_code".isNotNull,$"task_area_code").otherwise(""))
      .withColumn("task_area_name",when($"name".isin("顺丰自营","冷运事业部","顺丰医药"),$"dept_name")
        .when($"task_area_name".isNotNull,$"task_area_name").otherwise(""))
      .join(alarm_detail2,Seq("alarm_id"),"left")
      .withColumn("dealer",when($"alarm_time".isNull || trim($"alarm_time")==="","").otherwise(dealer_str_udf($"alarm_time")))
      .select(tb_cols1: _*)

    //结果表数据存dm表
    alarm_detail.createOrReplaceTempView("alarm_detail_tb")
    spark.sql(
      """
        |insert overwrite table dm_gis.alarm_marvin_meddle_dtl
        |select * from alarm_detail_tb
        |""".stripMargin)

    logger.error("任务执行完毕！")
    spark.close()
  }

  //判断处理人
  def dealer_str(x:String): String ={
    val hours=x.substring(11,13)
    val dealer_name=hours match{
      case "06"=>"廖幻丝"
      case "07"=>"李庆"
      case "08"=>"蛮又晴"
      case "09"=>"廖幻丝"
      case "10"=>"李庆"
      case "11"=>"蛮又晴"
      case "12"=>"廖幻丝"
      case "13"=>"李庆"
      case "14"=>"蛮又晴"
      case "15"=>"廖幻丝"
      case "16"=>"兴温文"
      case "17"=>"尚山"
      case "18"=>"欧梓倩"
      case "19"=>"兴温文"
      case "20"=>"尚山"
      case "21"=>"欧梓倩"
      case "22"=>"兴温文"
      case "23"=>"连兴言"
      case "00"=>"闭兴运"
      case "01"=>"连兴言"
      case "02"=>"闭兴运"
      case "03"=>"连兴言"
      case "04"=>"闭兴运"
      case "05"=>"连兴言"
      case hours => hours
    }
    dealer_name
  }

  val dealer_str_udf=udf(dealer_str _)


  //基表历史数据更新
  def update_alarm_detail(spark:SparkSession,day1:String,day2a:String): Unit ={
    import spark.implicits._
    val alarm_detail=spark.sql(
      s"""
         |select *,pmod(datediff(substr(create_time,0,10), '2012-01-01'), 7) dayn from dm_arss.dm_alarm_detail_dtl_di
         |where inc_Day>='$day2a' and inc_Day<='$day1'
         |and (
         |(is_meddle='1' and tf_flag='1'
         |and p_type = '1'
         |and alarm_name not in ('阻断型墨镜', '墨镜遮挡', '驾驶员离席', '驾驶员异常','斑马线未减速告警'))
         |or (alarm_name in ('设备超速告警','设备超时告警') and cast(speed as int) > 90 and cast(speed as int)<110)
         |or (alarm_name='斑马线未减速告警' and cast(speed as int) >= 50)
         |)
         |and attribute6 is not null
         |and trim(attribute6) != ''
         |and driver_name is not null
         |and trim(driver_name) != ''
         |""".stripMargin)
      .withColumn("risk_level",when($"risk_level"==="1","高").when($"risk_level"==="2","中").
        when($"risk_level"==="3","低").otherwise($"risk_level"))
      .withColumn("is_meddle",when($"is_meddle"==="1","需干预").otherwise("无需干预"))
      .withColumn("data_code",when(trim($"data_code")==="" || $"data_code".isNull ,"").otherwise($"data_code".substr(0,8)))


    val dept_data=spark.sql(
      s"""
         |select data_code,update_time,name from dm_arss.dm_sys_dept_dtl_di
         |where inc_Day='$day1'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("data_code").orderBy(desc("update_time"))))
      .filter($"rank"===1)
      .drop("update_time","rank")

    val tb_cols = spark.sql("""select * from dm_gis_scm.dm_marvinmeddle_alarm_detail limit 0""").schema.map(_.name).map(col)
    val alarm_result=alarm_detail.join(dept_data,Seq("data_code"),"left")
      .select(tb_cols: _*)
    //存储表
    writeToHive(spark, alarm_result, Seq("inc_day"), "dm_gis_scm.dm_marvinmeddle_alarm_detail")

  }

}
