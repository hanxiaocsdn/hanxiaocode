package app.safety


import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.UrlUtil
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions.{avg, col, count, lit, trim, udf, when}
import org.apache.log4j.Logger
import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon

import java.text.SimpleDateFormat
import java.util.Calendar
import scala.collection.mutable.ListBuffer

/**
 **需求名称:日度计算告警数据中间表
 **任务id：785132
 **研发:01390943周勇，算法对接：01374048王珊珊，产品：ft80006475高梅
 **需求描述:日度计算告警数据，用于计算司机画像日结表
 **/

object DriverAlarmDay extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  //开始执行
  def startfun(spark: SparkSession,input_inc_day:String): Unit ={
    import spark.implicits._
    //执行任务主表信息
    println("----process start: task_info(spark)")
    task_info(spark,input_inc_day)
    println("----process end: task_info(spark)")

    //告警汇总指标
    println("----process start: alarm_static(spark)")
    alarm_static(spark,input_inc_day)
    println("----process end: alarm_static(spark)")

    //计算半小时告警最多的起止时间('DMS','HOD')
    println("----process start: get_halfmost_aa(spark)")
    get_halfmost_aa(spark)
    println("----process end: get_halfmost_aa(spark)")
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数('DMS','HOD')
    val calPartitions = excutors * cores * 3
    println("index_roadclass_aa："+getnow())
    index_roadclass_aa(spark,calPartitions)

    //计算半小时告警最多的起止时间('ADAS','过激驾驶')
    println("----process start: get_halfmost_bb(spark)")
    get_halfmost_bb(spark)
    println("----process end: get_halfmost_bb(spark)")
    val (excutors2, cores2) = Spark.getExcutorInfo(spark)
    //计算并行数('ADAS','过激驾驶')
    val calPartitions2 = excutors2 * cores2 * 3
    println("index_roadclass_bb："+getnow())
    index_roadclass_bb(spark,calPartitions2)

    //各指标合并d_distance
    println("汇总合并："+getnow())
    val res_sql="""
                  |select t1.main_driver_account as emp_code,t2.d_violations_all,t2.d_violations_dms_all,t2.d_violations_hod_all,
                  |t2.d_violations_dms_intervene,t2.d_violations_hod_intervene,t2.d_violations_high,t2.d_violations_high_intervene,
                  |cast(100*t2.d_violations_dms_all/t12.d_distance as decimal(10,2)) d_hundred_dms_count,
                  |cast(100*t2.d_violations_hod_all/t12.d_distance as decimal(10,2)) d_hundred_hod_count,
                  |t3.d_violations_mosthalf,t4.d_violations_top_type,t5.d_violations_road_type,t6.d_violations_time_type,
                  |t7.d_habit_all,t7.d_habit_adas_all,t7.d_habit_hhh_all,t7.d_habit_adas_intervene,t7.d_habit_hgh_intervene,t7.d_habit_high,
                  |t7.d_habit_high_intervene,cast(100*t7.d_habit_adas_all/t12.d_distance as decimal(10,2)) d_hundred_adas_count,
                  |cast(100*t7.d_habit_hhh_all/t12.d_distance as decimal(10,2)) d_hundred_HHH_count,
                  |t8.d_habit_mosthalf,t9.d_habit_top_type,t10.d_habit_road_type,t11.d_habit_time_type,
                  |t13.d_habit_adas_intervene_speed,t13.d_habit_hgh_intervene_speed,t13.d_habit_high_intervene_speed,
                  |t13.d_violations_dms_intervene_speed,t13.d_violations_hod_intervene_speed,t13.d_violations_high_intervene_speed,
                  |t14.*
                  |from
                  |(select main_driver_account from zy20221115_drivealarm_static3a
                  | union
                  | select main_driver_account from zy20221115_drivealarm_static3b
                  |) t1
                  |left join zy20221115_drivealarm_static3a t2
                  |on t1.main_driver_account=t2.main_driver_account
                  |left join zy20221115_drivealarm_static13_aa t3
                  |on t1.main_driver_account=t3.main_driver_account
                  |left join zy20221115_drivealarm_static4a t4
                  |on t1.main_driver_account=t4.main_driver_account
                  |left join zy20221115_drivealarm_static12_aa t5
                  |on t1.main_driver_account=t5.main_driver_account
                  |left join zy20221115_drivealarm_static5a t6
                  |on t1.main_driver_account=t6.main_driver_account
                  |left join zy20221115_drivealarm_static3b t7
                  |on t1.main_driver_account=t7.main_driver_account
                  |left join zy20221115_drivealarm_static13_bb t8
                  |on t1.main_driver_account=t8.main_driver_account
                  |left join zy20221115_drivealarm_static4b t9
                  |on t1.main_driver_account=t9.main_driver_account
                  |left join zy20221115_drivealarm_static12_bb t10
                  |on t1.main_driver_account=t10.main_driver_account
                  |left join zy20221115_drivealarm_static5b t11
                  |on t1.main_driver_account=t11.main_driver_account
                  |left join tempzy20221115_driver_tasklicheng t12
                  |on t1.main_driver_account=t12.main_driver_account
                  |left join day_index_avg t13
                  |on t1.main_driver_account=t13.main_driver_account
                  |left join day_index t14
                  |on t1.main_driver_account=t14.main_driver_account_a
                  |""".stripMargin

    val table_cols = spark.sql("""select * from dm_gis_scm.dm_driver_alarm_fact_d limit 0""").schema.map(_.name).map(col)
    val zy20221115_drivealarm_static14=spark.sql(res_sql)
      .withColumn("inc_day",lit(input_inc_day))
      .select(table_cols:_*)

    //数据存dm表
    writeToHive(spark, zy20221115_drivealarm_static14.coalesce(5), Seq("inc_day"), "dm_gis_scm.dm_driver_alarm_fact_d")
  }

  //任务主表，本次只统计有任务的出车记录
  def task_info(spark: SparkSession,input_inc_day:String): Unit = {

    val tempzy20221115_driver_task1=spark.sql(s"""
                                                 |select task_id,main_driver_mobilephone,vehicle_serial,src_zone_code,task_dept_code,plan_depart_tm,actual_depart_tm,
                                                 |plan_arrive_tm,actual_arrive_tm,actual_run_time,transoport_level,cross_days,nvl(gis_distance,line_distance) gis_distance,
                                                 |regexp_replace(substr(actual_depart_tm,0,10),'-','') actual_depart_day,main_driver_account,
                                                 |CAST((unix_timestamp(actual_depart_tm) - unix_timestamp(plan_depart_tm)) / 60 AS int) % 60 dif_depart_min,
                                                 |CAST((unix_timestamp(actual_arrive_tm) - unix_timestamp(plan_arrive_tm)) / 60 AS int) % 60 dif_arrive_min,
                                                 |is_reach_ontime,is_run_ontime from dm_grd.grd_new_task_detail
                                                 |where inc_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day}','yyyymmdd'),'yyyy-mm-dd'),3),'-','')
                                                 |and inc_day<='${input_inc_day}'
                                                 |and state='6'
                                                 |and nvl(gis_distance,line_distance)>0.01 ---过滤原地不动的任务""".stripMargin)

    tempzy20221115_driver_task1.createOrReplaceTempView("tempzy20221115_driver_task1")


    val tempzy20221115_driver_tasklicheng=spark.sql(s"""
                                                       |select main_driver_account,sum(nvl(gis_distance,0)) d_distance from tempzy20221115_driver_task1
                                                       |where actual_depart_day='${input_inc_day}'
                                                       |group by main_driver_account""".stripMargin)

    tempzy20221115_driver_tasklicheng.createOrReplaceTempView("tempzy20221115_driver_tasklicheng")
  }


  //匹配告警信息进行计算
  def alarm_static(spark: SparkSession,input_inc_day:String): Unit = {
    import  spark.implicits._
    //取所有有任务的的告警，干预状态status：-1是无需处理，0 待处理 1处理中 2已处理
    val sql1=s"""
                |select t1.*,
                |case when int(substr(t1.alarm_time,12,2))<7 then '凌晨'
                |when int(substr(t1.alarm_time,12,2))<10 then '清晨'
                |when int(substr(t1.alarm_time,12,2))<13 then '中午'
                |when int(substr(t1.alarm_time,12,2))<7 then '午后'
                |when int(substr(t1.alarm_time,12,2))<20 then '黄昏'
                |when int(substr(t1.alarm_time,12,2))<24 then '夜间'
                |else '' end time_type,t2.main_driver_account
                |from
                |(
                |select * from
                |(select  alarm_id,alarm_time ,lng,lat,ft_p_type,ft_sub_type,p_type_r,sub_type_r,attribute7,status,is_meddle,tf_flag,speed,
                |regexp_replace(substr(alarm_time,0,10),'-','') alarm_day
                |from dm_arss.dm_alarm_detail_dtl_di
                |where inc_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day}','yyyymmdd'),'yyyy-mm-dd'),2),'-','')
                |and inc_day<=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day}','yyyymmdd'),'yyyy-mm-dd'),-1),'-','')
                |) x
                |where alarm_day=${input_inc_day}
                |) t1
                |join
                |(select * from tempzy20221115_driver_task1
                |where actual_depart_day=${input_inc_day}
                |) t2 on t1.attribute7=t2.task_id""".stripMargin
    println("当前sql1:"+sql1)
    val zy20221115_drivealarm_static1=spark.sql(sql1)


    zy20221115_drivealarm_static1.createOrReplaceTempView("zy20221115_drivealarm_static1")


    //告警申诉,剔除1和4申诉成功的
    val alarm_appeal=spark.sql(s"""select alarm_id,alarm_id as alarm_ida from dm_gis.dm_alarm_appeal
                                  |where inc_day='${input_inc_day}' and appeal_status in ('1','4')""".stripMargin)

    alarm_appeal.createOrReplaceTempView("alarm_appeal_tb")


    //匹配告警大小类型
    val zy20221115_drivealarm_static2=spark.sql(s"""
                                                   |select t1.*,t2.alarm_p_name,t2.sub_name,t4.alarm_ida
                                                   |from (
                                                   |select *,concat(ft_p_type,'|',ft_sub_type,'|',p_type_r,'|',sub_type_r) hb
                                                   |from zy20221115_drivealarm_static1
                                                   |) t1
                                                   |left join
                                                   |(
                                                   |select *,concat(alarm_p_type,'|',alarm_sub_type,'|',p_type,'|',sub_type) hb from dm_gis_scm.dm_tc_alarm_rule
                                                   |where inc_day=${input_inc_day}
                                                   |) t2 on t1.hb=t2.hb
                                                   |left join alarm_appeal_tb t4
                                                   |on t1.alarm_id=t4.alarm_id""".stripMargin)
      .filter($"alarm_p_name".isin ("DMS","HOD","ADAS","过激驾驶"))
      .withColumn("speed",when($"speed".isNull || trim($"speed")==="",0).otherwise($"speed"))
      .withColumn("is_appeal",when($"alarm_ida".isNotNull,1).otherwise(0))
      .withColumn("is_need",when($"sub_name"==="打电话" && $"is_meddle"===1 &&  $"tf_flag"===1 && $"is_appeal"===0,1).
        when($"sub_name"==="打电话" ,0).
        when($"sub_name"==="摄像头遮挡" && $"is_meddle"===1 &&  $"tf_flag"===1 && $"is_appeal"===0,1).
        when($"sub_name"==="摄像头遮挡" ,0).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") && $"is_meddle"===1 &&  $"tf_flag"===1,1).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") ,0).
        when($"alarm_p_name"==="ADAS" ,1).
        when($"alarm_p_name"==="过激驾驶" ,1).
        when($"alarm_p_name"==="DMS" && $"tf_flag"===1,1).
        when($"alarm_p_name"==="HOD" && $"tf_flag"===1,1).
        otherwise(0))
      .filter($"is_need"===1)

    zy20221115_drivealarm_static2.createOrReplaceTempView("zy20221115_drivealarm_static2")


    //平均速度计算
    val day_index_avg=zy20221115_drivealarm_static2
      .groupBy("main_driver_account")
      .agg(
        //ADAS告警已干预平均时速，ADAS默认全部是正确的，没有人工干预
        avg(when($"alarm_p_name"==="ADAS",$"speed")).as("d_habit_adas_intervene_speed"),
        //HHH告警已干预平均时速，HHH默认全部是正确的，没有人工干预
        avg(when($"alarm_p_name"==="过激驾驶",$"speed")).as("d_habit_hgh_intervene_speed"),
        //高危告警已干预平均时速,默认全部是正确的，没有人工干预
        avg(when($"sub_name".isin("车距过近","急加速","急减速","急转弯"),$"speed")).as("d_habit_high_intervene_speed"),
        //DMS告警已干预平均时速
        avg(when($"alarm_p_name"==="DMS",$"speed")).as("d_violations_dms_intervene_speed"),
        //HOD告警已干预平均时速
        avg(when($"alarm_p_name"==="HOD",$"speed")).as("d_violations_hod_intervene_speed"),
        //高危告警已干预平均时速
        avg(when($"sub_name".isin("吸烟","闭眼","疲劳","打电话","未系安全带"),$"speed")).as("d_violations_high_intervene_speed")
      )

    day_index_avg.createOrReplaceTempView("day_index_avg")

    //汇总指标计算
    val day_index=zy20221115_drivealarm_static2
      .groupBy("main_driver_account")
      .agg(
        //打电话 + 摄像头遮挡 + 疲劳（疲劳/闭眼/云端算法-闭眼） + 吸烟
        //分心驾驶（分心驾驶/分心驾驶抬头/分心驾驶低头） + 车道偏离 + 车距过近 + 急加速 + 急减速 + 超速 (超速/超限速告警)+ 路口未减速
        count(when($"sub_name".isin("吸烟","打电话","摄像头遮挡","云端算法-疲劳（闭眼）","疲劳","闭眼"),1).otherwise(null)).as("d_violations_follow_all"),
        count(when($"sub_name".isin("分心驾驶","分心驾驶抬头","分心驾驶低头","车道偏离","车距过近","急加速","急减速","超速"),1).otherwise(null)).as("d_driving_follow_all"),
        count(when($"sub_name".isin("分心驾驶","分心驾驶抬头","分心驾驶低头"),1).otherwise(null)).as("d_driving_distracted_all"),
        //由于筛选了"tf_flag"===1，所以dms所有的都是人工干预的
        count(when($"sub_name".isin("分心驾驶","分心驾驶抬头","分心驾驶低头"),1).otherwise(null)).as("d_driving_distracted_all_intervene"),
        avg(when($"sub_name".isin("分心驾驶","分心驾驶抬头","分心驾驶低头"),$"speed")).as("d_driving_distracted_all_speed"),

        count(when($"sub_name"==="吸烟",1).otherwise(null)).as("d_driving_smoking_all"),
        count(when($"sub_name"==="吸烟",1).otherwise(null)).as("d_driving_smoking_all_intervene"),
        avg(when($"sub_name"==="吸烟",$"speed")).as("d_driving_smoking_all_intervene_speed"),

        count(when($"sub_name"==="打电话",1).otherwise(null)).as("d_driving_phone_all"),
        count(when($"sub_name"==="打电话",1).otherwise(null)).as("d_driving_phone_all_intervene"),
        avg(when($"sub_name"==="打电话",$"speed")).as("d_driving_phone_all_intervene_speed"),

        count(when($"sub_name"==="摄像头遮挡",1).otherwise(null)).as("d_driving_camera_all"),
        count(when($"sub_name"==="摄像头遮挡",1).otherwise(null)).as("d_driving_camera_all_intervene"),
        avg(when($"sub_name"==="摄像头遮挡",$"speed")).as("d_driving_camera_all_intervene_speed"),

        count(when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼"),1).otherwise(null)).as("d_driving_fatigue_all"),
        count(when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼"),1).otherwise(null)).as("d_driving_fatigue_all_intervene"),
        avg(when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼"),$"speed")).as("d_driving_fatigue_all_intervene_speed"),

        count(when($"sub_name"==="车道偏离",1).otherwise(null)).as("d_driving_laned_eparture_all"),
        count(when($"sub_name"==="车道偏离",1).otherwise(null)).as("d_driving_laned_eparture_all_intervene"),
        avg(when($"sub_name"==="车道偏离",$"speed")).as("d_driving_laned_eparture_all_intervene_speed"),

        count(when($"sub_name"==="车距过近",1).otherwise(null)).as("d_driving_close_distance_all"),
        count(when($"sub_name"==="车距过近",1).otherwise(null)).as("d_driving_close_distance_all_intervene"),
        avg(when($"sub_name"==="车距过近",$"speed")).as("d_driving_close_distance_all_intervene_speed"),

        count(when($"sub_name"==="急加速",1).otherwise(null)).as("d_driving_rapid_acceleration_all"),
        count(when($"sub_name"==="急加速",1).otherwise(null)).as("d_driving_rapid_acceleration_all_intervene"),
        avg(when($"sub_name"==="急加速",$"speed")).as("d_driving_rapid_acceleration_all_intervene_speed"),

        count(when($"sub_name"==="急减速",1).otherwise(null)).as("d_driving_sharp_deceleration_all"),
        count(when($"sub_name"==="急减速",1).otherwise(null)).as("d_driving_sharp_deceleration_all_intervene"),
        avg(when($"sub_name"==="急减速",$"speed")).as("d_driving_sharp_deceleration_all_intervene_speed"),

        count(when($"sub_name"==="超速",1).otherwise(null)).as("d_driving_speeding_all"),
        count(when($"sub_name"==="超速",1).otherwise(null)).as("d_driving_speeding_all_intervene"),
        avg(when($"sub_name"==="超速",$"speed")).as("d_driving_speeding_all_intervene_speed")
      )
      .withColumn("d_driving_intersection_speeding_all",lit(""))
      .withColumn("d_driving_intersection_speeding_all_intervene",lit(""))
      .withColumn("d_driving_intersection_speeding_all_intervene_speed",lit(""))
      .withColumn("main_driver_account_a",$"main_driver_account")
      .drop("main_driver_account")

    day_index.createOrReplaceTempView("day_index")


    //告警数据统计('DMS','HOD')
    val zy20221115_drivealarm_static3a=spark.sql("""
                                                   |select main_driver_account,
                                                   |count(*) d_violations_all,  ---总告警数
                                                   |count(case when alarm_p_name='DMS' then 1 else null end) d_violations_dms_all,  ---DMS告警数
                                                   |count(case when alarm_p_name='HOD' then 1 else null end) d_violations_hod_all,   ---HOD告警数
                                                   |count(case when alarm_p_name='DMS' and tf_flag is not null and tf_flag !='' then 1 else null end) d_violations_dms_intervene,  ---DMS已干预告警数
                                                   |count(case when alarm_p_name='HOD' and tf_flag is not null and tf_flag !=''  then 1 else null end) d_violations_hod_intervene,   ---HOD已干预告警数
                                                   |count(case when sub_name in ('吸烟','闭眼','疲劳','打电话','未系安全带') then 1 else null end) d_violations_high,  ---高危告警（抽烟/闭眼疲劳/电话/未系安全带）总数
                                                   |count(case when sub_name in ('吸烟','闭眼','疲劳','打电话','未系安全带') and tf_flag is not null and tf_flag !='' then 1 else null end)
                                                   | as d_violations_high_intervene   ---高危告警（抽烟/闭眼疲劳/电话/未系安全带）已干预
                                                   |from zy20221115_drivealarm_static2
                                                   |where alarm_p_name in ('DMS','HOD')
                                                   |group by main_driver_account""".stripMargin)

    zy20221115_drivealarm_static3a.createOrReplaceTempView("zy20221115_drivealarm_static3a")

    //告警数据统计(ADAS+HHH),ADAS+HHH默认全部正确
    val zy20221115_drivealarm_static3b=spark.sql("""
                                                   |select main_driver_account,
                                                   |count(*) d_habit_all,  ---ADAS+HHH告警总数
                                                   |count(case when alarm_p_name='ADAS' then 1 else null end) d_habit_adas_all,  ---ADAS告警总数
                                                   |count(case when alarm_p_name='过激驾驶' then 1 else null end) d_habit_hhh_all,   ---HHH告警总数
                                                   |count(case when alarm_p_name='ADAS'  then 1 else null end) d_habit_adas_intervene,  ---ADAS告警已干预
                                                   |count(case when alarm_p_name='过激驾驶'  then 1 else null end) d_habit_hgh_intervene,   ---HHH告警已干预
                                                   |count(case when sub_name in ('车距过近','急加速','急减速','急转弯') then 1 else null end) d_habit_high,  ---高危告警（跟车过近/急转弯/急加速/急减速）总数
                                                   |count(case when sub_name in ('车距过近','急加速','急减速','急转弯')  then 1 else null end)
                                                   | as d_habit_high_intervene   ---高危告警（跟车过近/急转弯/急加速/急减速）已干预
                                                   |from zy20221115_drivealarm_static2
                                                   |where alarm_p_name in  ('ADAS','过激驾驶')
                                                   |group by main_driver_account""".stripMargin)

    zy20221115_drivealarm_static3b.createOrReplaceTempView("zy20221115_drivealarm_static3b")

    //告警top类型 ('DMS','HOD')
    val zy20221115_drivealarm_static4a=spark.sql("""
                                                   |select main_driver_account,
                                                   |concat('{',concat_ws(',',sort_array(collect_list(hebing))),'}')  d_violations_top_type
                                                   |from (
                                                   |select main_driver_account,sub_name,ct,
                                                   |concat('"rank_',rank,'":"',sub_name,'"') hebing from (
                                                   |select *,row_number() over(partition by main_driver_account order by ct desc) rank
                                                   |from (
                                                   |select main_driver_account,sub_name,count(*) ct
                                                   |from zy20221115_drivealarm_static2
                                                   |where alarm_p_name in ('DMS','HOD')
                                                   |group by main_driver_account,sub_name
                                                   |) x
                                                   |) y where rank<=3
                                                   |) z group by main_driver_account""".stripMargin)

    zy20221115_drivealarm_static4a.createOrReplaceTempView("zy20221115_drivealarm_static4a")

    //告警top类型 (ADAS+HHH)
    val zy20221115_drivealarm_static4b=spark.sql("""
                                                   |select main_driver_account,
                                                   |concat('{',concat_ws(',',sort_array(collect_list(hebing))),'}')  d_habit_top_type
                                                   |from (
                                                   |select main_driver_account,sub_name,ct,
                                                   |concat('"rank_',rank,'":"',sub_name,'"') hebing from (
                                                   |select *,row_number() over(partition by main_driver_account order by ct desc) rank
                                                   |from (
                                                   |select main_driver_account,sub_name,count(*) ct
                                                   |from zy20221115_drivealarm_static2
                                                   |where alarm_p_name in ('ADAS','过激驾驶')
                                                   |group by main_driver_account,sub_name
                                                   |) x
                                                   |) y where rank<=3
                                                   |) z group by main_driver_account""".stripMargin)

    zy20221115_drivealarm_static4b.createOrReplaceTempView("zy20221115_drivealarm_static4b")

    //top告警时间类型 ('DMS','HOD')
    val zy20221115_drivealarm_static5a=spark.sql("""
                                                   |select main_driver_account,
                                                   |concat('{',concat_ws(',',sort_array(collect_list(hebing))),'}')  d_violations_time_type
                                                   |from (
                                                   |select main_driver_account,time_type,ct,
                                                   |concat('"rank_',rank,'":"',time_type,'"') hebing from (
                                                   |select *,row_number() over(partition by main_driver_account order by ct desc) rank
                                                   |from (
                                                   |select main_driver_account,time_type,count(*) ct
                                                   |from zy20221115_drivealarm_static2
                                                   |where alarm_p_name in ('DMS','HOD')
                                                   |group by main_driver_account,time_type
                                                   |) x
                                                   |) y where rank<=3
                                                   |) z group by main_driver_account""".stripMargin)

    zy20221115_drivealarm_static5a.createOrReplaceTempView("zy20221115_drivealarm_static5a")

    //告警top告警时间类型 (ADAS+HHH)
    val zy20221115_drivealarm_static5b=spark.sql("""
                                                   |select main_driver_account,
                                                   |concat('{',concat_ws(',',sort_array(collect_list(hebing))),'}')  d_habit_time_type
                                                   |from (
                                                   |select main_driver_account,time_type,ct,
                                                   |concat('"rank_',rank,'":"',time_type,'"') hebing from (
                                                   |select *,row_number() over(partition by main_driver_account order by ct desc) rank
                                                   |from (
                                                   |select main_driver_account,time_type,count(*) ct
                                                   |from zy20221115_drivealarm_static2
                                                   |where alarm_p_name in ('ADAS','过激驾驶')
                                                   |group by main_driver_account,time_type
                                                   |) x
                                                   |) y where rank<=3
                                                   |) z group by main_driver_account""".stripMargin)

    zy20221115_drivealarm_static5b.createOrReplaceTempView("zy20221115_drivealarm_static5b")

    //按照工号合并告警时间('DMS','HOD')
    val zy20221115_drivealarm_static7_aa=spark.sql("""
                                                     |select main_driver_account,concat_ws(',',sort_array(collect_list(alarm_time))) hb_result1
                                                     |from zy20221115_drivealarm_static2
                                                     |where alarm_p_name in ('DMS','HOD')
                                                     |group by main_driver_account""".stripMargin)

    zy20221115_drivealarm_static7_aa.createOrReplaceTempView("zy20221115_drivealarm_static7_aa")

    //按照工号合并告警时间('ADAS','过激驾驶')
    val zy20221115_drivealarm_static7_bb=spark.sql("""
                                                     |select main_driver_account,concat_ws(',',sort_array(collect_list(alarm_time))) hb_result2
                                                     |from zy20221115_drivealarm_static2
                                                     |where alarm_p_name in ('ADAS','过激驾驶')
                                                     |group by main_driver_account""".stripMargin)

    zy20221115_drivealarm_static7_bb.createOrReplaceTempView("zy20221115_drivealarm_static7_bb")

  }

  //匹配半小时最多告警('DMS','HOD')
  def get_halfmost_aa(spark: SparkSession): Unit = {
    import spark.implicits._
    //注册udf函数
    val udf_halfhour=udf(MostcountStartEnd _)
    //计算半小时最多告警的起止时间
    val x=spark.sql("select * from zy20221115_drivealarm_static7_aa")
      .repartition(500)
      .withColumn("hb_resulta",udf_halfhour($"hb_result1",lit(1800)))
      .persist(StorageLevel.MEMORY_AND_DISK)

    x.createOrReplaceTempView("zy20221115_drivealarm_mosttime_aa")

    //匹配起止时间
    val zy20221115_drivealarm_static8_aa=spark.sql("""
                                                     |select t1.main_driver_account,t1.lng,t1.lat,t1.alarm_time,
                                                     |t2.hb_resulta[0] min_time,t2.hb_resulta[1] max_time
                                                     |from zy20221115_drivealarm_static2 t1
                                                     |left join zy20221115_drivealarm_mosttime_aa t2
                                                     |on t1.main_driver_account=t2.main_driver_account
                                                     |where t1.alarm_p_name in ('DMS','HOD')""".stripMargin)

    zy20221115_drivealarm_static8_aa.createOrReplaceTempView("zy20221115_drivealarm_static8_aa")

    //筛选时间段
    val zy20221115_drivealarm_static9_aa=spark.sql("""
                                                     |select * from zy20221115_drivealarm_static8_aa
                                                     |where alarm_time>=min_time and alarm_time<=max_time""".stripMargin)

    zy20221115_drivealarm_static9_aa.createOrReplaceTempView("zy20221115_drivealarm_static9_aa")

  }

  //转成rdd('DMS','HOD')
  def Get_Alarm_Data_aa(spark: SparkSession,calPartitions: Int) = {
    val sql="select * from zy20221115_drivealarm_static9_aa"
    val sql_Df: DataFrame = spark.sql(sql).persist(StorageLevel.MEMORY_AND_DISK)
    val sql_Df2=sql_Df.select("main_driver_account","lng","lat","alarm_time","min_time","max_time")
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, sql_Df2, calPartitions).persist(StorageLevel.MEMORY_AND_DISK)
    sql_Rdd
  }

  def xtostring(x:String):String={
    x.toString
  }

  val xtostring_udf=udf(xtostring _)

  //计算道路等级指标('DMS','HOD')
  def index_roadclass_aa(spark: SparkSession,calPartitions:Int): Unit = {
    import spark.implicits._
    //获取rdd数据
    val AlarmRdd: RDD[JSONObject] = Get_Alarm_Data_aa(spark,calPartitions).repartition(1000)
    val AlarmRdd_result=interfaceAlarm(spark,AlarmRdd,calPartitions)
    //获取道路等级
    val y: DataFrame =AlarmRdd_result.map(
      obj=>{
        val main_driver_account=obj.getString("main_driver_account")
        val lng=obj.getString("lng")
        val lat=obj.getString("lat")
        val alarm_time=obj.getString("alarm_time")
        val min_time=obj.getString("min_time")
        val max_time=obj.getString("max_time")
        val roadclass=obj.getString("roadclass")
        (main_driver_account, lng,lat,alarm_time,min_time,max_time, roadclass)
      }

    ).toDF("main_driver_account", "lng","lat","alarm_time","min_time","max_time","roadclass")
      .persist(StorageLevel.MEMORY_AND_DISK)

    y.createOrReplaceTempView("zy20221115_drivealarm_static10_roadclass")


    //指标匹配
    val sql_static11="""
                       |select *,
                       |case when roadclass=0 then '高速公路'
                       |when roadclass=1 then '国道'
                       |when roadclass=2 then '省道'
                       |when roadclass=3 then '县道'
                       |when roadclass=4 then '乡公路'
                       |when roadclass=5 then '县乡村内部道路'
                       |when roadclass=6 then '主要大街、城市快速道'
                       |when roadclass=7 then '主要道路'
                       |when roadclass=8 then '次要道路'
                       |when roadclass=9 then '普通道路'
                       |when roadclass=10 then '非导航道路'
                       |else '其他' end road_type
                       |from zy20221115_drivealarm_static10_roadclass """.stripMargin
    val zy20221115_drivealarm_static11_aa=spark.sql(sql_static11)

    zy20221115_drivealarm_static11_aa.createOrReplaceTempView("zy20221115_drivealarm_static11_aa")

    //路段类型汇总去重
    val sql_static12="""
                       |select main_driver_account,concat('{',concat_ws(',',sort_array(collect_list(road_typea))),'}') d_violations_road_type
                       |from (
                       |select *,concat('"rank_',rank,'":"',road_type,'"') road_typea
                       |from(
                       |select *,row_number() over(partition by main_driver_account order by road_typect desc) rank
                       |from(
                       |select main_driver_account,road_type,count(*) road_typect
                       |from zy20221115_drivealarm_static11_aa
                       |group by main_driver_account,road_type
                       |) a
                       |) x where x.rank<=3
                       |) y
                       |group by main_driver_account""".stripMargin
    val zy20221115_drivealarm_static12_aa=spark.sql(sql_static12)
    zy20221115_drivealarm_static12_aa.createOrReplaceTempView("zy20221115_drivealarm_static12_aa")



    //指标计算汇总
    val sql_static13="""
                       |select y1.main_driver_account,y1.start_time,y1.end_time,
                       |concat('{"start_time": "',y1.start_time,'", "end_time": "',y1.end_time,'"}') d_violations_mosthalf
                       |from (
                       |select main_driver_account,hb_resulta[0] start_time,hb_resulta[1] end_time
                       |from zy20221115_drivealarm_mosttime_aa
                       |) y1""".stripMargin
    val zy20221115_drivealarm_static13_aa=spark.sql(sql_static13)

    zy20221115_drivealarm_static13_aa.createOrReplaceTempView("zy20221115_drivealarm_static13_aa")
  }

  //匹配半小时最多告警(ADAS+HHH)
  def get_halfmost_bb(spark: SparkSession): Unit = {
    import spark.implicits._
    //注册udf函数
    val udf_halfhour=udf(MostcountStartEnd _)
    //计算半小时最多告警的起止时间


    val x=spark.sql("select * from zy20221115_drivealarm_static7_bb")
      .repartition(500)
      .withColumn("hb_resulta",udf_halfhour($"hb_result2",lit(1800)))
      .persist(StorageLevel.MEMORY_AND_DISK)

    x.createOrReplaceTempView("zy20221115_drivealarm_mosttime_bb")

    //匹配起止时间
    val zy20221115_drivealarm_static8_bb=spark.sql("""
                                                     |select t1.main_driver_account,t1.lng,t1.lat,t1.alarm_time,
                                                     |t2.hb_resulta[0] min_time,t2.hb_resulta[1] max_time
                                                     |from zy20221115_drivealarm_static2 t1
                                                     |left join zy20221115_drivealarm_mosttime_bb t2
                                                     |on t1.main_driver_account=t2.main_driver_account
                                                     |where t1.alarm_p_name in ('ADAS','过激驾驶')""".stripMargin)

    zy20221115_drivealarm_static8_bb.createOrReplaceTempView("zy20221115_drivealarm_static8_bb")

    //筛选时间段
    val zy20221115_drivealarm_static9_bb=spark.sql("""
                                                     |select * from zy20221115_drivealarm_static8_bb
                                                     |where alarm_time>=min_time and alarm_time<=max_time""".stripMargin)

    zy20221115_drivealarm_static9_bb.createOrReplaceTempView("zy20221115_drivealarm_static9_bb")
  }

  //转成rdd(ADAS+HHH)
  def Get_Alarm_Data_bb(spark: SparkSession,calPartitions: Int) = {
    val sql="select * from zy20221115_drivealarm_static9_bb"
    val sql_Df: DataFrame = spark.sql(sql).persist(StorageLevel.MEMORY_AND_DISK)
    val sql_Df2=sql_Df.select("main_driver_account","lng","lat","alarm_time","min_time","max_time")
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, sql_Df2, calPartitions).persist(StorageLevel.MEMORY_AND_DISK)
    sql_Rdd
  }

  //计算道路等级指标(ADAS+HHH)
  def index_roadclass_bb(spark: SparkSession,calPartitions:Int): Unit = {
    import spark.implicits._
    //获取rdd数据
    val AlarmRdd: RDD[JSONObject] = Get_Alarm_Data_bb(spark,calPartitions).repartition(1000)
    val AlarmRdd_result=interfaceAlarm(spark,AlarmRdd,calPartitions)
    //获取道路等级
    val y: DataFrame =AlarmRdd_result.map(
      obj=>{
        val main_driver_account=obj.getString("main_driver_account")
        val lng=obj.getString("lng")
        val lat=obj.getString("lat")
        val alarm_time=obj.getString("alarm_time")
        val min_time=obj.getString("min_time")
        val max_time=obj.getString("max_time")
        val roadclass=obj.getString("roadclass")
        (main_driver_account, lng,lat,alarm_time,min_time,max_time, roadclass)
      }

    ).toDF("main_driver_account", "lng","lat","alarm_time","min_time","max_time","roadclass")
      .persist(StorageLevel.MEMORY_AND_DISK)

    y.createOrReplaceTempView("zy20221115_drivealarm_static10_bb")

    //指标匹配
    val sql_static11="""
                       |select *,
                       |case when roadclass=0 then '高速公路'
                       |when roadclass=1 then '国道'
                       |when roadclass=2 then '省道'
                       |when roadclass=3 then '县道'
                       |when roadclass=4 then '乡公路'
                       |when roadclass=5 then '县乡村内部道路'
                       |when roadclass=6 then '主要大街、城市快速道'
                       |when roadclass=7 then '主要道路'
                       |when roadclass=8 then '次要道路'
                       |when roadclass=9 then '普通道路'
                       |when roadclass=10 then '非导航道路'
                       |else '其他' end road_type
                       |from zy20221115_drivealarm_static10_bb """.stripMargin
    val zy20221115_drivealarm_static11_bb=spark.sql(sql_static11)

    zy20221115_drivealarm_static11_bb.createOrReplaceTempView("zy20221115_drivealarm_static11_bb")

    //路段类型汇总去重
    val sql_static12="""
                       |select main_driver_account,concat('{',concat_ws(',',sort_array(collect_list(road_typea))),'}') d_habit_road_type
                       |from (
                       |select *,concat('"rank_',rank,'":"',road_type,'"') road_typea
                       |from(
                       |select *,row_number() over(partition by main_driver_account order by road_typect desc) rank
                       |from(
                       |select main_driver_account,road_type,count(*) road_typect
                       |from zy20221115_drivealarm_static11_bb
                       |group by main_driver_account,road_type
                       |) a
                       |) x where x.rank<=3
                       |) y
                       |group by main_driver_account""".stripMargin
    val zy20221115_drivealarm_static12_bb=spark.sql(sql_static12)

    zy20221115_drivealarm_static12_bb.createOrReplaceTempView("zy20221115_drivealarm_static12_bb")

    //指标计算汇总
    val sql_static13="""
                       |select y1.main_driver_account,y1.start_time,y1.end_time,
                       |concat('{"start_time": "',y1.start_time,'", "end_time": "',y1.end_time,'"}') d_habit_mosthalf
                       |from (
                       |select main_driver_account,hb_resulta[0] start_time,hb_resulta[1] end_time
                       |from zy20221115_drivealarm_mosttime_bb
                       |) y1""".stripMargin
    val zy20221115_drivealarm_static13_bb=spark.sql(sql_static13)

    zy20221115_drivealarm_static13_bb.createOrReplaceTempView("zy20221115_drivealarm_static13_bb")
  }

  //定义获取url数据
  //  def Alarm_url(ak:String,obj:JSONObject): JSONObject = {
  //    val url=UrlsDef.rect_url
  //    try {
  //      val main_driver_account=obj.getString("main_driver_account")
  //      val lng=obj.getString("lng")
  //      val lat=obj.getString("lat")
  //      val alarm_time=obj.getString("alarm_time")
  //      val min_time=obj.getString("min_time")
  //      val max_time=obj.getString("max_time")
  //      //入参
  //      val parm =
  //        """{"ak": "7f2e357570ee40f5a0470137b7e4d72c",""" + """"roadinfo":1,""" +
  //          """"tracks": [{"x": """ + lng + ""","y": """ + lat +
  //          """}]}""".stripMargin
  //      val retStr: String = UrlUtil.sendPost(url,parm,5)
  //      val ret: JSONObject = JSON.parseObject(retStr)
  //      obj.put("ret",ret)
  //      logger.error("接口调用成功...")
  //      Thread.sleep(1*1000)
  //    } catch {
  //      case e: Exception => logger.error(e)
  //        val tmp = new JSONObject()
  //        tmp.put("myException",e.getMessage)
  //        obj.put("ret",tmp)
  //        logger.error("接口调用失败！！！")
  //    }
  //    obj
  //  }

  //定义获取url数据,暂时没啥用
  def Alarm_url(ak:String,obj:JSONObject): JSONObject = {
    obj
  }

  //调取接口并发请求
  def interfaceAlarm(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {

    //道路等级暂时不用
    //val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, Alarm_url, 4, "", 2000)

    val returnAtRDD: RDD[JSONObject] = DataRdd

    val atRdd: RDD[JSONObject] = returnAtRDD.map(obj => {
      val ret = obj.getString("ret")
      try{
        if(ret != null && ret.nonEmpty) {
          val js_result = JSON.parseObject(ret).getString("result")
          if(js_result != null && js_result.nonEmpty) {
            val js_tracks = JSON.parseObject(js_result).getJSONArray("tracks")
            val js_roadclass = js_tracks.getJSONObject(0).getString("roadclass")
            obj.put("roadclass", js_roadclass)
          }
        }
      }
      catch {
        case e:Exception=>logger.error("解析错误："+e.getMessage)
      }
      obj
    })

    atRdd
  }

  //返回指定times时间内，数据量最大的时间范围起始和截点值，例如：times为30分钟是30*60=1800
  //str格式："2022-09-11 00:00:34,2022-09-11 00:31:23,2022-09-11 00:28:19,2022-09-11 00:18:27,2022-09-11 00:08:27"
  //返回示例：List(2022-09-11 00:00:34, 2022-09-11 00:28:27)，使用下标调用即可
  def MostcountStartEnd(str: String,times:Long): List[String] = {
    //切割转化为list，然后升序
    val str_list = str.split(",").toList
    val str_lists = str_list.sorted
    val l = str_lists.length
    //往列表中存入当前判断值，存储格式为vector
    val x_final = for (i <- 0 until l)
      yield {
        var xlist = ListBuffer(str_lists(i))
        // println("xlist:"+xlist)
        var flag = true //布尔值判断终结循环
        var j = i
        //循环中心向右平移判断
        while (j < l) {
          if (flag) {
            if (TimeDiffSecond(str_lists(i), str_lists(j)) <= times) {
              flag = true
              xlist += str_lists(j)
            }
            j = j + 1
          }
          else {
            flag = false
          }
        }
        //返回本次循环的结果：格式 List(List(1),List(2),List(3))
        xlist.toList
      }
    //将vector格式转化为list
    val x_final2 = x_final.toList
    val sl = x_final2.length
    //计算返回的list里面每个小list的长度
    val sld = for (i <- 0 until (sl))
      yield {
        x_final2(i).length
      }
    val sld_list = sld.toList
    //求最长长度
    val sld_list_max = sld_list.max
    //过滤只保留最长的
    val sld_list_filter = x_final2.filter(x => x.length == sld_list_max)
    //返回的最长的如果有多个，则默认取第一个
    val sld_list_filter_rs1 = sld_list_filter(0)
    //println("sld_list_filter:"+sld_list_filter(0)(0))
    //翻转list
    val sld_list_filter_rs2 = sld_list_filter(0).reverse
    //结果返回
    val rs_list = List(sld_list_filter_rs1(0), sld_list_filter_rs2(0))
    return rs_list
  }

  //定义时间差计算：秒，str2比str1大,传入格式：2022-09-30 15:30:18，例如返回结果：300
  def TimeDiffSecond(str1: String, str2: String): Long = {
    var datedf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    //转换时间戳：毫秒
    val x1 = datedf.parse(str1).getTime
    val x2 = datedf.parse(str2).getTime
    //除以1000就是秒为单位
    val x3 = (x2 - x1) / 1000
    return x3
  }

  //当前时间时分秒，格式：2022-11-03 10:19:57
  def getnow():String= {
    var dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    var cal: Calendar = Calendar.getInstance()
    var day = dateFormat.format(cal.getTime())
    day
  }

}


