package app.safety



import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.CommonTools.getdaysBeforeOrAfter

/**
 **author:01390943 周勇
 **需求方：01422522 黄晓冰。历史需求方：ft80006475 高梅
 **description:自营丰图需干预明细周报表
 **任务id：788037
 **/

object MarvinAlarmFtMeddleWeek  extends DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")
  def main(args:Array[String])= {
    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._
    //取跑数T-1日期
    val dayvar0 = args(0)

    //取跑数T-7日期，用于对比
    val dayvar7 = getdaysBeforeOrAfter(dayvar0, -6)
    val dayvar7b = getdaysBeforeOrAfter(dayvar0, -13)
    //自营司机信息第一部分
    val self_driver=spark.sql(
      s"""
         | select data_code,name as org_name,dept_code,dept_name,driver_name,attribute6 as emp_code,alarm_time,
         | date_add(next_day(from_unixtime(unix_timestamp(inc_day,'yyyymmdd'),'yyyy-mm-dd'),'MO'),-7) as biz_week
         |from dm_gis_scm.dm_marvinmeddle_alarm_detail
         |WHERE  inc_day <= '$dayvar0' and inc_day >= '$dayvar7'
         |""".stripMargin)
      .withColumn("rank", row_number().over(Window.partitionBy("emp_code")
        .orderBy(desc("alarm_time"))))
      .filter($"rank"===1)
      .filter(trim($"emp_code") =!="" && trim($"emp_code").isNotNull)
      .drop("rank","alarm_time")

    //需要添加上上周的is_nextwk='是司机
    val before_driver=spark.sql(
      s"""
         |select data_code,name as org_name,dept_code,dept_name,driver_name,attribute6 as emp_code,alarm_time,biz_week
         | from dm_gis.alarm_marvin_meddle_dtl
         |WHERE  inc_day < '$dayvar7' and inc_day >= '$dayvar7b' and is_nextwk='是'
         |""".stripMargin)
      .withColumn("rank", row_number().over(Window.partitionBy("emp_code")
        .orderBy(desc("alarm_time"))))
      .filter($"rank"===1)
      .filter(trim($"emp_code") =!="" && trim($"emp_code").isNotNull)
      .drop("rank","alarm_time")

    //司机合并
    val self_driver2=self_driver.union(before_driver)
      .withColumn("rank", row_number().over(Window.partitionBy("emp_code")
        .orderBy(desc("biz_week"))))
      .filter($"rank"===1)
      .drop("rank")

    //需干预告警明细
    val alarm_dtl=spark.sql(
      s"""
         |select *,attribute6 as emp_code from dm_gis.alarm_marvin_meddle_dtl
         |WHERE  inc_day <= '$dayvar0' and inc_day >= '$dayvar7b'
         |and types is not null and trim(types) !=''
         |""".stripMargin)


    //历史数据对比:上2周
    val week_2=getdaysBeforeOrAfter(dayvar0, -7)
    val alarm_week_2=spark.sql(
      s"""select emp_code	,
         w_alarm_ct as w_alarm_ct2,
         |w_alarm_tired_ct as w_alarm_tired_ct2,
         |w_alarm_tired_orgct as w_alarm_tired_orgct2,
         |w_apeal_tired_delct as w_apeal_tired_delct2,
         |w_alarm_tired_tsct as w_alarm_tired_tsct2,
         |w_alarm_tired_pert as w_alarm_tired_pert2,
         |w_alarm_tired_risklevel as w_alarm_tired_risklevel2,
         |w_alarm_tired_change as w_alarm_tired_change2,
         |w_alarm_mobile_ct as w_alarm_mobile_ct2,
         |w_alarm_mobile_orgct as w_alarm_mobile_orgct2,
         |w_apeal_mobile_delct as w_apeal_mobile_delct2,
         |w_alarm_mobile_tsct as w_alarm_mobile_tsct2,
         |w_alarm_mobile_pert as w_alarm_mobile_pert2,
         |w_alarm_mobile_risklevel as w_alarm_mobile_risklevel2,
         |w_alarm_mobile_change as w_alarm_mobile_change2,
         |w_alarm_cama_ct as w_alarm_cama_ct2,
         |w_alarm_cama_orgct as w_alarm_cama_orgct2,
         |w_apeal_cama_delct as w_apeal_cama_delct2,
         |w_alarm_cama_tsct as w_alarm_cama_tsct2,
         |w_alarm_cama_pert as w_alarm_cama_pert2,
         |w_alarm_cama_risklevel as w_alarm_cama_risklevel2,
         |w_alarm_cama_change as w_alarm_cama_change2,
         |w_alarm_speed_orgct as w_alarm_speed_orgct2,
         |w_alarm_zebra_orgct as w_alarm_zebra_orgct2
         | from dm_gis.alarm_marvin_meddle_week
         |where inc_day='$week_2'
         |""".stripMargin)


    //历史数据对比:上3周
    val week_3=getdaysBeforeOrAfter(dayvar0, -14)
    val alarm_week_3=spark.sql(
      s"""select emp_code	,
         w_alarm_ct as w_alarm_ct3,
         |w_alarm_tired_ct as w_alarm_tired_ct3,
         |w_alarm_tired_orgct as w_alarm_tired_orgct3,
         |w_apeal_tired_delct as w_apeal_tired_delct3,
         |w_alarm_tired_tsct as w_alarm_tired_tsct3,
         |w_alarm_tired_pert as w_alarm_tired_pert3,
         |w_alarm_tired_risklevel as w_alarm_tired_risklevel3,
         |w_alarm_tired_change as w_alarm_tired_change3,
         |w_alarm_mobile_ct as w_alarm_mobile_ct3,
         |w_alarm_mobile_orgct as w_alarm_mobile_orgct3,
         |w_apeal_mobile_delct as w_apeal_mobile_delct3,
         |w_alarm_mobile_tsct as w_alarm_mobile_tsct3,
         |w_alarm_mobile_pert as w_alarm_mobile_pert3,
         |w_alarm_mobile_risklevel as w_alarm_mobile_risklevel3,
         |w_alarm_mobile_change as w_alarm_mobile_change3,
         |w_alarm_cama_ct as w_alarm_cama_ct3,
         |w_alarm_cama_orgct as w_alarm_cama_orgct3,
         |w_apeal_cama_delct as w_apeal_cama_delct3,
         |w_alarm_cama_tsct as w_alarm_cama_tsct3,
         |w_alarm_cama_pert as w_alarm_cama_pert3,
         |w_alarm_cama_risklevel as w_alarm_cama_risklevel3,
         |w_alarm_cama_change as w_alarm_cama_change3,
         |w_alarm_speed_orgct as w_alarm_speed_orgct3,
         |w_alarm_zebra_orgct as w_alarm_zebra_orgct3
         | from dm_gis.alarm_marvin_meddle_week
         |where inc_day='$week_3'
         |""".stripMargin)


    //历史数据对比:上4周
    val week_4=getdaysBeforeOrAfter(dayvar0, -21)
    val alarm_week_4=spark.sql(
      s"""select emp_code	,
         w_alarm_ct as w_alarm_ct4,
         |w_alarm_tired_ct as w_alarm_tired_ct4,
         |w_alarm_tired_orgct as w_alarm_tired_orgct4,
         |w_apeal_tired_delct as w_apeal_tired_delct4,
         |w_alarm_tired_tsct as w_alarm_tired_tsct4,
         |w_alarm_tired_pert as w_alarm_tired_pert4,
         |w_alarm_tired_risklevel as w_alarm_tired_risklevel4,
         |w_alarm_tired_change as w_alarm_tired_change4,
         |w_alarm_mobile_ct as w_alarm_mobile_ct4,
         |w_alarm_mobile_orgct as w_alarm_mobile_orgct4,
         |w_apeal_mobile_delct as w_apeal_mobile_delct4,
         |w_alarm_mobile_tsct as w_alarm_mobile_tsct4,
         |w_alarm_mobile_pert as w_alarm_mobile_pert4,
         |w_alarm_mobile_risklevel as w_alarm_mobile_risklevel4,
         |w_alarm_mobile_change as w_alarm_mobile_change4,
         |w_alarm_cama_ct as w_alarm_cama_ct4,
         |w_alarm_cama_orgct as w_alarm_cama_orgct4,
         |w_apeal_cama_delct as w_apeal_cama_delct4,
         |w_alarm_cama_tsct as w_alarm_cama_tsct4,
         |w_alarm_cama_pert as w_alarm_cama_pert4,
         |w_alarm_cama_risklevel as w_alarm_cama_risklevel4,
         |w_alarm_cama_change as w_alarm_cama_change4,
         |w_alarm_speed_orgct as w_alarm_speed_orgct4,
         |w_alarm_zebra_orgct as w_alarm_zebra_orgct4
         | from dm_gis.alarm_marvin_meddle_week
         |where inc_day='$week_4'
         |""".stripMargin)


    val alarm_dtl_result=alarm_dtl.groupBy("emp_code")
      .agg(
        //疲劳高危原始告警量0
        count(when(regexp_replace($"biz_week","-","")===dayvar7 &&
          ($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")) && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "w_alarm_tired_orgct",
        //疲劳高危申诉剔除量0
        count(when(regexp_replace($"biz_week","-","")===dayvar7 &&
          ($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")) && $"isgz"==="是" && $"is_gzcar"==="是"
          && $"appeal_status_first".isin("初检结束-通过","终检结束-通过","初检审核中","终检审核中","初检未通过"),1).
          otherwise(null)) as "w_apeal_tired_delct",
        //疲劳高危计入本周量0
        count(when( regexp_replace($"biz_week","-","")===dayvar7b &&
          $"is_nextwk"==="是" && ($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")),1).
          otherwise(null)) as "w_alarm_tired_tsct",
        //打电话原始告警量0
        count(when(regexp_replace($"biz_week","-","")===dayvar7 &&
          $"alarm_name"==="打电话"  && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "w_alarm_mobile_orgct",
        //打电话申诉剔除量0
        count(when(  regexp_replace($"biz_week","-","")===dayvar7 &&
          $"alarm_name"==="打电话"
          && $"appeal_status_first".isin("初检结束-通过","终检结束-通过","初检审核中","终检审核中","初检未通过"),1).
          otherwise(null)) as "w_apeal_mobile_delct",
        //打电话计入本周量0
        count(when( regexp_replace($"biz_week","-","")===dayvar7b &&
          $"alarm_name"==="打电话" && $"is_nextwk"==="是",1).otherwise(null)) as "w_alarm_mobile_tsct",
        //摄像头遮挡原始告警量0
        count(when(  regexp_replace($"biz_week","-","")===dayvar7 &&
          $"alarm_name"==="摄像头遮挡"  && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "w_alarm_cama_orgct",
        //摄像头遮挡申诉剔除量0
        count(when(  regexp_replace($"biz_week","-","")===dayvar7 &&
          $"alarm_name"==="摄像头遮挡"
          && $"appeal_status_first".isin("初检结束-通过","终检结束-通过","初检审核中","终检审核中","初检未通过"),1).
          otherwise(null)) as "w_apeal_cama_delct",
        //摄像头遮挡计入本周量0
        count(when( regexp_replace($"biz_week","-","")===dayvar7b &&
          $"alarm_name"==="摄像头遮挡" && $"is_nextwk"==="是",1).otherwise(null)) as "w_alarm_cama_tsct",
        //超速告警量
        count(when(  regexp_replace($"biz_week","-","")===dayvar7 &&
        $"alarm_name"==="设备超速告警"  && $"is_gzcar"==="是",1).
        otherwise(null)) as "w_alarm_speed_orgct",
        //斑马线未减速告警量
        count(when(  regexp_replace($"biz_week","-","")===dayvar7 &&
          $"alarm_name"==="斑马线未减速告警"  && $"is_gzcar"==="是",1).
          otherwise(null)) as "w_alarm_zebra_orgct"
      )
      //疲劳高危告警量
      .withColumn("w_alarm_tired_ct",$"w_alarm_tired_orgct"-$"w_apeal_tired_delct"+$"w_alarm_tired_tsct")
      //打电话告警量
      .withColumn("w_alarm_mobile_ct",$"w_alarm_mobile_orgct"-$"w_apeal_mobile_delct"+$"w_alarm_mobile_tsct")
      //摄像头遮挡告警量
      .withColumn("w_alarm_cama_ct",$"w_alarm_cama_orgct"-$"w_apeal_cama_delct"+$"w_alarm_cama_tsct")
      //告警量
      .withColumn("w_alarm_ct",$"w_alarm_tired_ct"+$"w_alarm_mobile_ct"+$"w_alarm_cama_ct")

    val tb_cols = spark.sql("""select * from dm_gis.alarm_marvin_meddle_week limit 0""").schema.map(_.name).map(col)
    val alarm_result=self_driver2.join(alarm_dtl_result,Seq("emp_code")) //这里要用inner join
      .join(alarm_week_2,Seq("emp_code"),"left")
      .join(alarm_week_3,Seq("emp_code"),"left")
      .join(alarm_week_4,Seq("emp_code"),"left")
      .na.fill(0,Seq("w_alarm_tired_ct2","w_alarm_mobile_ct2","w_alarm_cama_ct2","w_alarm_tired_ct3",
      "w_alarm_mobile_ct3","w_alarm_cama_ct3","w_alarm_tired_ct4","w_alarm_mobile_ct4","w_alarm_cama_ct4",
      "w_alarm_speed_orgct","w_alarm_speed_orgct2","w_alarm_speed_orgct3","w_alarm_speed_orgct4",
      "w_alarm_zebra_orgct","w_alarm_zebra_orgct2","w_alarm_zebra_orgct3","w_alarm_zebra_orgct4"
    ))
      //疲劳高危周环比
      .withColumn("w_alarm_tired_pert",$"w_alarm_tired_ct"-$"w_alarm_tired_ct2")
      //打电话周环比
      .withColumn("w_alarm_mobile_pert",$"w_alarm_mobile_ct"-$"w_alarm_mobile_ct2")
      //摄像头遮挡周环比
      .withColumn("w_alarm_cama_pert",$"w_alarm_cama_ct"-$"w_alarm_cama_ct2")
      //超速告警量周环比
      .withColumn("w_alarm_speed_pert",$"w_alarm_speed_orgct"-$"w_alarm_speed_orgct2")
      //斑马线未减速告警量周环比
      .withColumn("w_alarm_zebra_pert",$"w_alarm_zebra_orgct"-$"w_alarm_zebra_orgct2")

      //疲劳高危改善状态
      .withColumn("w_alarm_tired_change",
        when(($"w_alarm_tired_ct"+$"w_alarm_tired_ct2"+$"w_alarm_tired_ct3"+$"w_alarm_tired_ct4")===0,"无需改善").
          when($"w_alarm_tired_ct"===0 && ($"w_alarm_tired_ct2"+$"w_alarm_tired_ct3"+$"w_alarm_tired_ct4")>0 ,"已改善").
          when($"w_alarm_tired_ct">0 && $"w_alarm_tired_ct2">0,"持续未改善").
          when($"w_alarm_tired_ct">0 && $"w_alarm_tired_ct2"===0 && ($"w_alarm_tired_ct3"+$"w_alarm_tired_ct4")>0,"改善后新增").
          when($"w_alarm_tired_ct">0 && ($"w_alarm_tired_ct2"+$"w_alarm_tired_ct3"+$"w_alarm_tired_ct4")===0,"新增").
          otherwise(""))
      //打电话改善状态
      .withColumn("w_alarm_mobile_change",
        when(($"w_alarm_mobile_ct"+$"w_alarm_mobile_ct2"+$"w_alarm_mobile_ct3"+$"w_alarm_mobile_ct4")===0,"无需改善").
          when($"w_alarm_mobile_ct"===0 && ($"w_alarm_mobile_ct2"+$"w_alarm_mobile_ct3"+$"w_alarm_mobile_ct4")>0 ,"已改善").
          when($"w_alarm_mobile_ct">0 && $"w_alarm_mobile_ct2">0,"持续未改善").
          when($"w_alarm_mobile_ct">0 && $"w_alarm_mobile_ct2"===0 && ($"w_alarm_mobile_ct3"+$"w_alarm_mobile_ct4")>0,"改善后新增").
          when($"w_alarm_mobile_ct">0 && ($"w_alarm_mobile_ct2"+$"w_alarm_mobile_ct3"+$"w_alarm_mobile_ct4")===0,"新增").
          otherwise(""))
      //摄像头遮挡改善状态
      .withColumn("w_alarm_cama_change",
        when(($"w_alarm_cama_ct"+$"w_alarm_cama_ct2"+$"w_alarm_cama_ct3"+$"w_alarm_cama_ct4")===0,"无需改善").
          when($"w_alarm_cama_ct"===0 && ($"w_alarm_cama_ct2"+$"w_alarm_cama_ct3"+$"w_alarm_cama_ct4")>0 ,"已改善").
          when($"w_alarm_cama_ct">0 && $"w_alarm_cama_ct2">0,"持续未改善").
          when($"w_alarm_cama_ct">0 && $"w_alarm_cama_ct2"===0 && ($"w_alarm_cama_ct3"+$"w_alarm_cama_ct4")>0,"改善后新增").
          when($"w_alarm_cama_ct">0 && ($"w_alarm_cama_ct2"+$"w_alarm_cama_ct3"+$"w_alarm_cama_ct4")===0,"新增").
          otherwise(""))
      //超速告警量改善状态
      .withColumn("w_alarm_speed_change",
        when(($"w_alarm_speed_orgct"+$"w_alarm_speed_orgct2"+$"w_alarm_speed_orgct3"+$"w_alarm_speed_orgct4")===0,"无需改善").
          when($"w_alarm_speed_orgct"===0 && ($"w_alarm_speed_orgct2"+$"w_alarm_speed_orgct3"+$"w_alarm_speed_orgct4")>0 ,"已改善").
          when($"w_alarm_speed_orgct">0 && $"w_alarm_speed_orgct2">0,"持续未改善").
          when($"w_alarm_speed_orgct">0 && $"w_alarm_speed_orgct2"===0 && ($"w_alarm_speed_orgct3"+$"w_alarm_speed_orgct4")>0,"改善后新增").
          when($"w_alarm_speed_orgct">0 && ($"w_alarm_speed_orgct2"+$"w_alarm_speed_orgct3"+$"w_alarm_speed_orgct4")===0,"新增").
          otherwise(""))
      //斑马线未减速告警量改善状态
      .withColumn("w_alarm_zebra_change",
        when(($"w_alarm_zebra_orgct"+$"w_alarm_zebra_orgct2"+$"w_alarm_zebra_orgct3"+$"w_alarm_zebra_orgct4")===0,"无需改善").
          when($"w_alarm_zebra_orgct"===0 && ($"w_alarm_zebra_orgct2"+$"w_alarm_zebra_orgct3"+$"w_alarm_zebra_orgct4")>0 ,"已改善").
          when($"w_alarm_zebra_orgct">0 && $"w_alarm_zebra_orgct2">0,"持续未改善").
          when($"w_alarm_zebra_orgct">0 && $"w_alarm_zebra_orgct2"===0 && ($"w_alarm_zebra_orgct3"+$"w_alarm_zebra_orgct4")>0,"改善后新增").
          when($"w_alarm_zebra_orgct">0 && ($"w_alarm_zebra_orgct2"+$"w_alarm_zebra_orgct3"+$"w_alarm_zebra_orgct4")===0,"新增").
          otherwise(""))

      //疲劳高危风险等级
      .withColumn("w_alarm_tired_risklevel",when($"w_alarm_tired_change"==="无需改善","无风险").
        when($"w_alarm_tired_change"==="已改善","解除风险").
        when($"w_alarm_tired_ct">0,"极高风险").
        otherwise("")
      )
      //摄像头遮挡风险等级
      .withColumn("w_alarm_mobile_risklevel",when($"w_alarm_mobile_change"==="无需改善","无风险").
        when($"w_alarm_mobile_change"==="已改善","解除风险").
        when($"w_alarm_mobile_ct">0,"极高风险").
        otherwise("")
      )
      //疲劳高危风险等级
      .withColumn("w_alarm_cama_risklevel",when($"w_alarm_cama_change"==="无需改善","无风险").
        when($"w_alarm_cama_change"==="已改善","解除风险").
        when($"w_alarm_cama_ct">0,"极高风险").
        otherwise("")
      )
      //超速风险等级
      .withColumn("w_alarm_speed_risklevel",when($"w_alarm_speed_change"==="无需改善","无风险").
        when($"w_alarm_speed_change"==="已改善","解除风险").
        when($"w_alarm_speed_orgct">0,"极高风险").
        otherwise("")
      )
      //斑马线未减速告警量风险等级
      .withColumn("w_alarm_zebra_risklevel",when($"w_alarm_zebra_change"==="无需改善","无风险").
        when($"w_alarm_zebra_change"==="已改善","解除风险").
        when($"w_alarm_zebra_orgct">0,"极高风险").
        otherwise("")
      )

      .withColumn("biz_week",lit(dayvar7.substring(0,4).concat("-").concat(dayvar7.substring(4,6)).concat("-").concat(dayvar7.substring(6,8))))
      .withColumn("inc_day",lit(dayvar0))
      .select(tb_cols: _*)
    //存储表
    writeToHive(spark, alarm_result, Seq("inc_day"), "dm_gis.alarm_marvin_meddle_week")

    logger.error("任务执行完毕！")
  }

}
