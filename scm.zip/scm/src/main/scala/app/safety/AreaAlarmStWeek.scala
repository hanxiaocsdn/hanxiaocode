package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import utils.CommonTools.getdaysBeforeOrAfter
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
 *需求名称：地区告警周报
 *需求描述：顺丰客户对地区进行安全管理，对地区维度有相关考核指标，为方便客户取数分析，监管地区安全情况，提高周报统计效率，需建立地区维度告警周报。
 *需求方：黄晓冰(01422522)
 *开发: 周勇(01390943)
 *任务创建时间：20230424
 *任务id：783654
 **/

object AreaAlarmStWeek extends DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]) = {
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._
    //取跑数T-1日期
    val dayvar = args(0)
    //取跑数T-7日期
    val dayvar7 = getdaysBeforeOrAfter(dayvar, -6)
    //取跑数上周日期，用于对比
    val lastsunday = getdaysBeforeOrAfter(dayvar, -7)
    //所在月份
    val monthvar = dayvar7.substring(0,6)

    logger.error("接收输入变量dayvar:"+dayvar)
    logger.error("接收输入变量dayvar7:"+dayvar7)
    logger.error("接收输入变量lastsunday:"+lastsunday)
    logger.error("接收输入变量monthvar:"+monthvar)

    //获取日度告警地区日报基础数据
    val alarmday_info=spark.sql(
      s"""
         |select dept_name,dept_code,type_name,area_type,biz_week,project_name,area_name,id
         |from dm_gis.alarm_area_static_day
         |where inc_day='$dayvar'
         |group by dept_name,dept_code,type_name,area_type,biz_week,project_name,area_name,id
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))

    //周度出勤人次统计
    val work_empsct=spark.sql(
      s"""
         |select dept_code,onwork_emps
         |from dm_gis.alarm_area_static_day
         |where inc_day>='$dayvar7' and inc_day<='$dayvar'
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))
      .withColumn("onwork_emps",when($"onwork_emps".isNull || trim($"onwork_emps")==="",0).otherwise($"onwork_emps"))
      .groupBy("dept_code")
      .agg(sum($"onwork_emps") as "work_empsct")

    //在职人数
    val static_day=spark.sql(
      s"""
         |select dept_code,onposition_emps
         |from dm_gis.alarm_area_static_day
         |where inc_day='$dayvar'
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))

    //疲劳高危人数
    val alarm_thisweek=spark.sql(
      s"""
         |select *
         |from dm_gis.alarm_marvin_meddle_week
         |where inc_day='$dayvar'
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))
      .groupBy("dept_code")
      .agg(countDistinct(when($"w_alarm_tired_ct">0,$"emp_code").otherwise(null)) as "tied_empsct",
        sum(when($"w_alarm_tired_ct">0,$"w_alarm_tired_ct").otherwise(0)) as "week_tired_ct",

        countDistinct(when($"w_alarm_mobile_ct">0,$"emp_code").otherwise(null)) as "mobile_empsct",
        sum(when($"w_alarm_mobile_ct">0,$"w_alarm_mobile_ct").otherwise(0)) as "week_mobile_ct",

        countDistinct(when($"w_alarm_cama_ct">0,$"emp_code").otherwise(null)) as "cama_empsct",
        sum(when($"w_alarm_cama_ct">0,$"w_alarm_cama_ct").otherwise(0)) as "week_cama_ct",

        //超速人数
        countDistinct(when($"w_alarm_speed_orgct">0,$"emp_code").otherwise(null)) as "speed_empsct",
        //超速次数
        sum(when($"w_alarm_speed_orgct">0,$"w_alarm_speed_orgct").otherwise(0)) as "week_speed_ct",

        //斑马线未减速人数
        countDistinct(when($"w_alarm_zebra_orgct">0,$"emp_code").otherwise(null)) as "zebra_empsct",
        //斑马线未减速次数
        sum(when($"w_alarm_zebra_orgct">0,$"w_alarm_zebra_orgct").otherwise(0)) as "week_zebra_ct"

      )

    logger.error("alarm_thisweek的数据量"+alarm_thisweek.count())
    alarm_thisweek.limit(5).show(false)

    //环比上周
    val alarm_lastweek=spark.sql(
      s"""
         |select *
         |from dm_gis.alarm_marvin_meddle_week
         |where inc_day='$lastsunday'
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))
      .groupBy("dept_code")
      .agg(countDistinct(when($"w_alarm_tired_ct">0,$"emp_code").otherwise(null)) as "tied_empsct_last",
        sum(when($"w_alarm_tired_ct">0,$"w_alarm_tired_ct").otherwise(0)) as "week_tired_ct_last",

        countDistinct(when($"w_alarm_mobile_ct">0,$"emp_code").otherwise(null)) as "mobile_empsct_last",
        sum(when($"w_alarm_mobile_ct">0,$"w_alarm_mobile_ct").otherwise(0)) as "week_mobile_ct_last",

        countDistinct(when($"w_alarm_cama_ct">0,$"emp_code").otherwise(null)) as "cama_empsct_last",
        sum(when($"w_alarm_cama_ct">0,$"w_alarm_cama_ct").otherwise(0)) as "week_cama_ct_last",

        //上周超速人数
        countDistinct(when($"w_alarm_speed_orgct">0,$"emp_code").otherwise(null)) as "speed_empsct_last",
        //上周超速次数
        sum(when($"w_alarm_speed_orgct">0,$"w_alarm_speed_orgct").otherwise(0)) as "week_speed_ct_last",

        //上周斑马线未减速人数
        countDistinct(when($"w_alarm_zebra_orgct">0,$"emp_code").otherwise(null)) as "zebra_empsct_last",
        //上周斑马线未减速次数
        sum(when($"w_alarm_zebra_orgct">0,$"w_alarm_zebra_orgct").otherwise(0)) as "week_zebra_ct_last"
      )

    //月度指标
    val alrm_monthindex=spark.sql(
      s"""
         |select * from dm_gis.alarm_marvin_meddle_week
         |where substr(regexp_replace(biz_week,'-',''),0,6)='$monthvar' and inc_day<='$dayvar'
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))
      .groupBy("dept_code")
      .agg(
        countDistinct(when($"w_alarm_ct">0,$"emp_code").otherwise(null)) as "m_alarm_empct",
        sum(when($"w_alarm_ct">0,$"w_alarm_ct").otherwise(0)) as "m_alarm_ct",

        countDistinct(when($"w_alarm_tired_ct">0,$"emp_code").otherwise(null)) as "m_alarmtired_empct",
        sum(when($"w_alarm_tired_ct">0,$"w_alarm_tired_ct").otherwise(0)) as "m_alarmtired_ct",

        countDistinct(when($"w_alarm_mobile_ct">0,$"emp_code").otherwise(null)) as "m_alarmmobile_empct",
        sum(when($"w_alarm_mobile_ct">0,$"w_alarm_mobile_ct").otherwise(0)) as "m_alarmmobile_ct",

        countDistinct(when($"w_alarm_cama_ct">0,$"emp_code").otherwise(null)) as "m_alarmcama_empct",
        sum(when($"w_alarm_cama_ct">0,$"w_alarm_cama_ct").otherwise(0)) as "m_alarmcama_ct",
        //本月累计超速人数
        countDistinct(when($"w_alarm_speed_orgct">0,$"emp_code").otherwise(null)) as "m_alarmspeed_empct",
        //本月累计超速次数
        sum(when($"w_alarm_speed_orgct">0,$"w_alarm_speed_orgct").otherwise(0)) as "m_alarmspeed_ct",
        //本月累计斑马线未减速人数
        countDistinct(when($"w_alarm_zebra_orgct">0,$"emp_code").otherwise(null)) as "m_alarmzebra_empct",
        //本月累计斑马线未减速次数
        sum(when($"w_alarm_zebra_orgct">0,$"w_alarm_zebra_orgct").otherwise(0)) as "m_alarmzebra_ct"

      )

    logger.error("alrm_monthindex的数据量"+alrm_monthindex.count())
    alrm_monthindex.limit(5).show(false)

    //周度指标
    val alrm_weekindex=spark.sql(
      s"""
         |select * from dm_gis.alarm_marvin_meddle_week
         |where inc_day='$dayvar'
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))
      .groupBy("dept_code")
      .agg(
        //疲劳
        countDistinct(when($"w_alarm_tired_ct">0 && $"w_alarm_tired_change" === "持续未改善",$"emp_code").otherwise(null)) as "w_alarm_tiredcx_empct",
        countDistinct(when($"w_alarm_tired_ct">0 && $"w_alarm_tired_change" === "新增",$"emp_code").otherwise(null)) as "w_alarm_tiredxz_empct",
        countDistinct(when($"w_alarm_tired_ct">0 && $"w_alarm_tired_change" === "改善后新增",$"emp_code").otherwise(null)) as "w_alarm_tiredgsxz_empct",
        //打电话
        countDistinct(when($"w_alarm_mobile_ct">0 && $"w_alarm_mobile_change" === "持续未改善",$"emp_code").otherwise(null)) as "w_alarm_mobilecx_empct",
        countDistinct(when($"w_alarm_mobile_ct">0 && $"w_alarm_mobile_change" === "新增",$"emp_code").otherwise(null)) as "w_alarm_mobilexz_empct",
        countDistinct(when($"w_alarm_mobile_ct">0 && $"w_alarm_mobile_change" === "改善后新增",$"emp_code").otherwise(null)) as "w_alarm_mobilegsxz_empct",
        //	遮挡持续未改善人数,	遮挡新增人数,	遮挡改善后新增人数
        countDistinct(when($"w_alarm_cama_ct">0 && $"w_alarm_cama_change" === "持续未改善",$"emp_code").otherwise(null)) as "w_alarm_camacx_empct",
        countDistinct(when($"w_alarm_cama_ct">0 && $"w_alarm_cama_change" === "新增",$"emp_code").otherwise(null)) as "w_alarm_camaxz_empct",
        countDistinct(when($"w_alarm_cama_ct">0 && $"w_alarm_cama_change" === "改善后新增",$"emp_code").otherwise(null)) as "w_alarm_camagsxz_empct",
        //	超速持续未改善人数,	超速新增人数,	超速改善后新增人数
        countDistinct(when($"w_alarm_speed_orgct">0 && $"w_alarm_speed_change" === "持续未改善",$"emp_code").otherwise(null)) as "w_alarm_speedcx_empct",
        countDistinct(when($"w_alarm_speed_orgct">0 && $"w_alarm_speed_change" === "新增",$"emp_code").otherwise(null)) as "w_alarm_speedxz_empct",
        countDistinct(when($"w_alarm_speed_orgct">0 && $"w_alarm_speed_change" === "改善后新增",$"emp_code").otherwise(null)) as "w_alarm_speedgsxz_empct",
        //	斑马线未减速持续未改善人数,	斑马线未减速新增人数,	斑马线未减速改善后新增人数
        countDistinct(when($"w_alarm_zebra_orgct">0 && $"w_alarm_zebra_change" === "持续未改善",$"emp_code").otherwise(null)) as "w_alarm_zebracx_empct",
        countDistinct(when($"w_alarm_zebra_orgct">0 && $"w_alarm_zebra_change" === "新增",$"emp_code").otherwise(null)) as "w_alarm_zebraxz_empct",
        countDistinct(when($"w_alarm_zebra_orgct">0 && $"w_alarm_zebra_change" === "改善后新增",$"emp_code").otherwise(null)) as "w_alarm_zebragsxz_empct"

      )

    //结果关联
    val res_df=alarmday_info
      //序号
      //.withColumn("area_index",when($"dept_name".isNull || trim($"dept_name")==="","").otherwise(area_index_udf($"dept_name")))
      .withColumn("area_index",$"id")
      //所在月份
      .withColumn("stmonth",lit(monthvar))
      //关联周度出勤人次统计
      .join(work_empsct,Seq("dept_code"),"left")
      //关联在职人数
      .join(static_day,Seq("dept_code"),"left")
      //关联疲劳高危人数
      .join(alarm_thisweek,Seq("dept_code"),"left")
      //关联疲劳高危人数
      .join(alarm_lastweek,Seq("dept_code"),"left")
      .na.fill(0,Array("tied_empsct","tied_empsct_last","week_tired_ct","week_tired_ct_last",
      "mobile_empsct","mobile_empsct_last","week_mobile_ct","week_mobile_ct_last","cama_empsct","cama_empsct_last","week_cama_ct"
      ,"week_cama_ct_last","week_speed_ct","week_speed_ct_last","speed_empsct","speed_empsct_last","zebra_empsct","zebra_empsct_last",
      "week_zebra_ct","week_zebra_ct_last"))
      // 疲劳高危告警人数周环比
      .withColumn("empsct_diff",$"tied_empsct"-$"tied_empsct_last")
      // 疲劳高危次数周环比
      .withColumn("week_tired_ct_diff",$"week_tired_ct"-$"week_tired_ct_last")
      // 打电话人数周环比
      .withColumn("mobile_empsct_diff",$"mobile_empsct"-$"mobile_empsct_last")
      // 打电话次数周环比
      .withColumn("week_mobile_ct_diff",$"week_mobile_ct"-$"week_mobile_ct_last")
      // 遮挡人数周环比
      .withColumn("cama_empsct_diff",$"cama_empsct"-$"cama_empsct_last")
      // 遮挡次数周环比
      .withColumn("week_cama_ct_diff",$"week_cama_ct"-$"week_cama_ct_last")
      // 超速人数周环比
      .withColumn("speed_empsct_diff",$"speed_empsct"-$"speed_empsct_last")
      // 超速次数周环比
      .withColumn("week_speed_ct_diff",$"week_speed_ct"-$"week_speed_ct_last")
      // 斑马线未减速人数周环比
      .withColumn("zebra_empsct_diff",$"zebra_empsct"-$"zebra_empsct_last")
      // 斑马线未减速次数周环比
      .withColumn("week_zebra_ct_diff",$"week_zebra_ct"-$"week_zebra_ct_last")


      //百人疲劳违规率
      .withColumn("tied_empsct_pert",$"tied_empsct"/$"onposition_emps")
      .withColumn("tied_empsct_pert",$"tied_empsct_pert"*100)
      //百人打电话违规率
      .withColumn("mobile_empsct_pert",$"mobile_empsct"/$"onposition_emps")
      .withColumn("mobile_empsct_pert",$"mobile_empsct_pert"*100)
      //百人遮挡违规率
      .withColumn("cama_empsct_pert",$"cama_empsct"/$"onposition_emps")
      .withColumn("cama_empsct_pert",$"cama_empsct_pert"*100)
      //百人疲劳违规率排名
      .withColumn("tied_empsct_rank",rank().over(Window.partitionBy("project_name").orderBy(asc("tied_empsct_pert"))))
      //百人打电话违规率排名
      .withColumn("mobile_empsct_rank",rank().over(Window.partitionBy("project_name").orderBy(asc("mobile_empsct_pert"))))
      //百人遮挡违规率排名
      .withColumn("cama_empsct_rank",rank().over(Window.partitionBy("project_name").orderBy(asc("cama_empsct_pert"))))
      //关联月度指标
      .join(alrm_monthindex,Seq("dept_code"),"left")
      //关联周度指标
      .join(alrm_weekindex,Seq("dept_code"),"left")
      .na.fill(0,Array("m_alarm_empct","m_alarm_ct","m_alarmtired_empct","m_alarmtired_ct","w_alarm_tiredcx_empct","w_alarm_tiredxz_empct","w_alarm_tiredgsxz_empct",
      "m_alarmmobile_empct","m_alarmmobile_ct","w_alarm_mobilecx_empct","w_alarm_mobilexz_empct","w_alarm_mobilegsxz_empct","m_alarmcama_empct",
      "m_alarmcama_ct","w_alarm_camacx_empct","w_alarm_camaxz_empct","w_alarm_camagsxz_empct", "m_alarmspeed_empct","m_alarmspeed_ct","m_alarmzebra_empct","m_alarmzebra_ct",
      "w_alarm_speedcx_empct","w_alarm_speedxz_empct","w_alarm_speedgsxz_empct","w_alarm_zebracx_empct","w_alarm_zebraxz_empct","w_alarm_zebragsxz_empct"))
      .withColumn("inc_day",lit(dayvar))

    //存入dm表
    val tb_cols = spark.sql("""select * from dm_gis.alarm_area_static_week limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, res_df.select(tb_cols:_*), Seq("inc_day"), "dm_gis.alarm_area_static_week")

    logger.error("执行完成")
    spark.close()
  }

  //地区序号转换
  def area_index(x_str:String): String ={
    val x_name=x_str match{
      case "上海区" => "1"
      case "深圳区" => "2"
      case "广州区" => "3"
      case "北京区" => "4"
      case "浙北区" => "5"
      case "苏州区" => "6"
      case "东莞区" => "7"
      case "鲁东区" => "8"
      case "佛山区" => "9"
      case "宁波区" => "10"
      case "泉州区" => "11"
      case "无锡区" => "12"
      case "南京区" => "13"
      case "温州区" => "14"
      case "金华区" => "15"
      case "天津区" => "16"
      case "厦门区" => "17"
      case "福州区" => "18"
      case "苏北区" => "19"
      case "南通区" => "20"
      case "粤西区" => "21"
      case "粤东区" => "22"
      case "济南区" => "23"
      case "冀州区" => "24"
      case "鲁中区" => "25"
      case "冀北区" => "26"
      case "重庆区" => "27"
      case "湖北区" => "28"
      case "四川区" => "29"
      case "河南区" => "30"
      case "安徽区" => "31"
      case "湖南区" => "32"
      case "江西区" => "33"
      case "辽宁区" => "34"
      case "陕西区" => "35"
      case "云南区" => "36"
      case "广西区" => "37"
      case "黑龙江区" => "38"
      case "吉林区" => "39"
      case "山西区" => "40"
      case "贵州区" => "41"
      case "甘肃区" => "42"
      case "内蒙古区" => "43"
      case "海南区" => "44"
      case "新疆区" => "45"
      case "华南分拨区" => "46"
      case "苏沪分拨区" => "47"
      case "鲁晋分拨区" => "48"
      case "华北分拨区" => "49"
      case "东北分拨区" => "50"
      case "东南分拨区" => "51"
      case "西北分拨区" => "52"
      case "西南分拨区" => "53"
      case "全国航空枢纽（杭州）" => "54"
      case "华中分拨区" => "55"
      case x => x
    }
    x_name
  }

  val area_index_udf=udf(area_index _)

}