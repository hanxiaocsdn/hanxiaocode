package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import org.apache.spark.sql.functions.{avg, col, lit, trim, when}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger

/**
 *需求名称：司机画像周结表
 *需求描述：为了降低司机驾驶风险，增加各项监控指标。
 *需求方：算法对接：01374048王珊珊，产品：ft80006475高梅
 *开发: 周勇(01390943)
 *任务创建时间：20221023
 *任务id：785140
 **/

object DriverLabelWeek  extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args:Array[String] )={
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._

    //获取传入参数日期
    val input_inc_day1=args(0)
    val input_inc_day2=args(1)

    //出车任务信息,过滤原地不动的任务
    val sql1=s"""
                |select * from (
                |select task_id,main_driver_mobilephone,vehicle_serial,src_zone_code,task_dept_code,plan_depart_tm,actual_depart_tm,
                |plan_arrive_tm,actual_arrive_tm,actual_run_time,transoport_level,cross_days,nvl(gis_distance,line_distance) gis_distance,
                |regexp_replace(substr(actual_depart_tm,0,10),'-','') actual_depart_day,main_driver_account,
                |CAST((unix_timestamp(actual_depart_tm) - unix_timestamp(plan_depart_tm)) / 60 AS int) % 60 dif_depart_min,
                |CAST((unix_timestamp(actual_arrive_tm) - unix_timestamp(plan_arrive_tm)) / 60 AS int) % 60 dif_arrive_min,
                |is_reach_ontime,is_run_ontime from dm_grd.grd_new_task_detail
                |where inc_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day1}','yyyymmdd'),'yyyy-mm-dd'),2),'-','')
                |and inc_day<='${input_inc_day2}'
                |and state='6'
                |and nvl(gis_distance,line_distance)>0.01
                |) x where actual_depart_day>='${input_inc_day1}' and actual_depart_day<='${input_inc_day2}'""".stripMargin
    val tempzy20221116_driverweek_task_detail=spark.sql(sql1)

    tempzy20221116_driverweek_task_detail.createOrReplaceTempView("tempzy20221116_driverweek_task_detail_tb")

    //告警申诉,剔除1和4申诉成功的
    val alarm_appeal=spark.sql(s"""select alarm_id,alarm_id as alarm_ida from dm_gis.dm_alarm_appeal
                                  |where inc_day='${input_inc_day2}' and appeal_status in ('1','4')""".stripMargin)

    alarm_appeal.createOrReplaceTempView("alarm_appeal_tb")

    //---周度告警
    val sql2=s"""
                |select t1.*,t2.main_driver_account,t3.alarm_p_name,t3.alarm_sub_name,t3.sub_name,t4.alarm_ida
                |from (
                |select *,concat(ft_p_type,'|',ft_sub_type,'|',p_type_r,'|',sub_type_r) hb from
                |(select alarm_id,alarm_time,lng,lat,ft_p_type,ft_sub_type,p_type_r,sub_type_r,attribute7,status,speed,is_meddle,tf_flag,
                |risk_level,defend_status,
                |regexp_replace(substr(alarm_time,0,10),'-','') alarm_day
                |from dm_arss.dm_alarm_detail_dtl_di
                |where inc_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day1}','yyyymmdd'),'yyyy-mm-dd'),2),'-','')
                |and inc_day<=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day2}','yyyymmdd'),'yyyy-mm-dd'),-1),'-','')
                |) x where x.alarm_day>='${input_inc_day1}' and x.alarm_day<='${input_inc_day2}'
                |) t1
                |join tempzy20221116_driverweek_task_detail_tb t2
                |on t1.attribute7=t2.task_id
                |left join
                |(
                |select *,concat(alarm_p_type,'|',alarm_sub_type,'|',p_type,'|',sub_type) hb from dm_gis_scm.dm_tc_alarm_rule
                |where inc_day=${input_inc_day2}
                |) t3 on t1.hb=t3.hb
                |left join alarm_appeal_tb t4
                |on t1.alarm_id=t4.alarm_id""".stripMargin

    //增加不同类型告警的判断
    val tempzy20221116_driverweek_alarm_detail=spark.sql(sql2)
      .filter($"alarm_p_name".isin ("DMS","HOD","ADAS","过激驾驶"))
      .withColumn("is_appeal",when($"alarm_ida".isNotNull,1).otherwise(0))
      .withColumn("is_need",when($"sub_name"==="打电话" && $"is_meddle"===1 &&  $"tf_flag"===1 && $"is_appeal"===0,1).
        when($"sub_name"==="打电话" ,0).
        when($"sub_name"==="摄像头遮挡" && $"is_meddle"===1 &&  $"tf_flag"===1 && $"is_appeal"===0,1).
        when($"sub_name"==="摄像头遮挡" ,0).

        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") && $"is_meddle"===1 &&  $"tf_flag"===1 && $"risk_level"==="1",1).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") && $"is_meddle"===1 &&  $"tf_flag"===1 && $"defend_status"==="2",1).

        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") ,0).
        when($"alarm_p_name"==="ADAS" ,1).
        when($"alarm_p_name"==="过激驾驶" ,1).
        when($"alarm_p_name"==="DMS" && $"tf_flag"===1,1).
        when($"alarm_p_name"==="HOD" && $"tf_flag"===1,1).
        otherwise(0)
      )
      .filter($"is_need"===1)
      .persist(StorageLevel.MEMORY_AND_DISK)

    tempzy20221116_driverweek_alarm_detail.createOrReplaceTempView("tempzy20221116_driverweek_alarm_detail_tb")

    //周度告警汇总
    val sql3="""
               |select main_driver_account,
               |count(case when alarm_p_name in ('DMS','HOD') then 1 else null end) driver_violations_all,
               |count(case when alarm_p_name='DMS' then 1 else null end) driver_violations_dms_all,
               |count(case when alarm_p_name='HOD' then 1 else null end) driver_violations_hod_all,
               |count(case when alarm_p_name in ('ADAS','过激驾驶') then 1 else null end) driver_habit_all,
               |count(case when alarm_p_name='ADAS' then 1 else null end) driver_habit_adas_all,
               |count(case when alarm_p_name='过激驾驶' then 1 else null end) driver_habit_hhh_all,
               |count(case when sub_name='吸烟' then 1 else null end) driver_violations_smoking_all,
               |count(case when sub_name='打电话' then 1 else null end) driver_violations_phone_all,
               |count(case when sub_name='摄像头遮挡' then 1 else null end) driver_violations_camera_all,
               |count(case when sub_name in ("云端算法-疲劳（闭眼）","疲劳","闭眼") then 1 else null end) driver_violations_fatigue_all,
               |count(case when sub_name in ("吸烟","打电话","摄像头遮挡","云端算法-疲劳（闭眼）","疲劳","闭眼") then 1 else null end) driver_violations_follow_all,
               |count(case when sub_name in ("分心驾驶","分心驾驶抬头","分心驾驶低头","车道偏离","车距过近","急加速","急减速","超速") then 1 else null end) driver_driving_follow_all,
               |count(case when sub_name in ("分心驾驶","分心驾驶抬头","分心驾驶低头") then 1 else null end) driver_habit_distracted_all,
               |count(case when sub_name='车道偏离' then 1 else null end) driver_habit_laned_eparture_all,
               |count(case when sub_name='车距过近' then 1 else null end) driver_habit_close_distance_all,
               |count(case when sub_name='急加速' then 1 else null end) driver_habit_rapid_acceleration_all,
               |count(case when sub_name='急减速' then 1 else null end) driver_habit_sharp_deceleration_all,
               |count(case when sub_name='超速' then 1 else null end) driver_habit_speeding_all
               |from tempzy20221116_driverweek_alarm_detail_tb
               |where main_driver_account !='' and main_driver_account is not null
               |group by main_driver_account""".stripMargin
    val tempzy20221116_driverweek_alarm_detail2=spark.sql(sql3)


    tempzy20221116_driverweek_alarm_detail2.createOrReplaceTempView("tempzy20221116_driverweek_alarm_detail_tb2")

    //违规行为平均时速
    val week_index1_a=tempzy20221116_driverweek_alarm_detail.filter($"alarm_p_name".isin ("DMS","HOD"))
      .groupBy("main_driver_account")
      .agg(
        avg(when($"speed".isNull || trim($"speed")==="",0.0).otherwise($"speed")).as("driver_violations_all_speed")
      )

    //习惯行为平均时速
    val week_index1_b=tempzy20221116_driverweek_alarm_detail.filter($"alarm_p_name".isin ("ADAS","过激驾驶"))
      .groupBy("main_driver_account")
      .agg(
        avg(when($"speed".isNull || trim($"speed")==="",0.0).otherwise($"speed")).as("driver_habit_all_speed")
      )

    //考试分数
    val sql_sdy=s"""
                   |select emp_code,exam_ct,pass_ct,cast(pass_ct/exam_ct as decimal(10,4)) exam_pass_pert
                   |from (
                   |select emp_code,count(*) exam_ct,count(case when emp_exam_state='1' then 1 else null end) pass_ct
                   |from (
                   |select *,regexp_replace(substr(exam_start_time,0,10),'-','') exam_day
                   |from dm_gis_scm.dm_scm_driver_exam
                   |where month<=substr(${input_inc_day2},0,6)
                   |and month>=substr(${input_inc_day1},0,6)
                   |and regexp_replace(substr(exam_start_time,0,10),'-','')>=${input_inc_day1}
                   |and regexp_replace(substr(exam_start_time,0,10),'-','')<=${input_inc_day2}
                   |	) y group by y.emp_code
                   |) x""".stripMargin
    val tempzy20221116_driver_exam=spark.sql(sql_sdy)

    tempzy20221116_driver_exam.createOrReplaceTempView("tempzy20221116_driver_exam_tb")

    //车队信息
    val sql_motorcade=s"""
                         |SELECT t1.dept_id,t1.motorcade_code,t2.motorcade_name
                         |FROM (
                         |select * from (
                         |SELECT motorcade_code, dept_id, ROW_NUMBER() OVER (PARTITION BY dept_id ORDER BY create_tm DESC ) AS rn
                         |FROM ods_shiva_ground.ts_motorcade_dept
                         |WHERE inc_day= '${input_inc_day2}') x where rn = 1
                         |) t1
                         |LEFT JOIN
                         |(SELECT motorcade_code, motorcade_name from ods_shiva_ground.ts_motorcadeinfo
                         |WHERE inc_day= '${input_inc_day2}'
                         |) t2 ON t1.motorcade_code = t2.motorcade_code""".stripMargin

    val tempzy20221116_driver_motorcade=spark.sql(sql_motorcade)

    tempzy20221116_driver_motorcade.createOrReplaceTempView("tempzy20221116_driver_motorcade_tb")


    //---周结表汇总
    val sql4=s"""
                |select
                |t1.driver_code	,---工号
                |t2.name as driver_name	,---姓名
                |t2.dept_id, ---网点id
                |t2.dept_code,---网点编码
                |t2.dept_name,---网点名称
                |t5.area_code,---地区编码
                |t5.area_name,---地区名称
                |t6.motorcade_code,---车队编码
                |t6.motorcade_name ,---车队名称
                |'' as driver_style	,---驾驶风格标签
                |case when t7.driver_state	is null then '离职' else t7.driver_state end driver_state,---司机在职状态
                |case when length(t2.mobile_phone)<5 then '' else  t2.mobile_phone end driver_phone	,---联系方式
                |case when length(t2.nric_id)<5 then '' else  t2.nric_id end as driver_id_card	,---身份证号
                |case when gender='1' then '男' when gender='2' then '女' else '' end as driver_gender	,---性别
                |t2.age as driver_age	,---年龄
                |t2.native_place as driver_place	,---籍贯
                |case when t2.education ='1' then '本科'
                | when t2.education ='2' then '大专'
                | when t2.education ='3' then '中专'
                | when t2.education ='4' then '高中'
                | when t2.education ='5' then '初中'
                | when t2.education ='6' then '小学'
                | else '' end as driver_edu	,---教育程度
                |case when t2.nationality='1' then '汉族'
                |when t2.nationality='2' then '回族'
                |when t2.nationality='3' then '藏族'
                |when t2.nationality='4' then '苗族'
                |when t2.nationality='5' then '彝族'
                |when t2.nationality='6' then '壮族'
                |when t2.nationality='7' then '满族'
                |when t2.nationality='8' then '其他'
                |else '' end as driver_nation  ,---民族
                |case when t2.character_type='1' then '多血质型'
                |when t2.character_type='2' then '胆汁质型'
                |when t2.character_type='3' then '粘液质型'
                |when t2.character_type='4' then '抑郁质型'
                |else '' end as driver_nature	,---司机性格
                |t2.dept_name as driver_org	,---所属机构
                |t1.driver_safe_mileage as driver_safe_mileage	,---安全行驶里程
                |t1.driver_safe_mark as driver_safe_mark	,---安全赋分
                |t2.medical_exam_dt as driver_test_date	,---体检日期
                |t2.driving_age as driver_experience	,---驾龄
                |t2.quasi_driving_type as driver_license	,---驾照类型
                |t2.urgent_contact  driver_emergency_contact,---紧急联系人
                |case when length(t2.urgent_contact_number)<5 then '' else t2.urgent_contact_number end  as driver_emergency_phone	,---紧急联系方式
                |'' driver_week_score	,---司机周得分
                |'' month_statistics	,---月度综合得分
                |'' month_dictionary	,---分数解读
                |'' driver_month_statistics	,---每个月综合得分
                |'' driver_week_score_all	,---周度综合得分
                |'' driver_violations_score	,---违规行为得分
                |t3.driver_violations_all	,---违规行为总数
                |t3.driver_violations_dms_all	,---DMS告警总数
                |t3.driver_violations_hod_all	,---HOD告警总数
                |'' driver_habit_score	,---驾驶习惯得分
                |t3.driver_habit_all	,---高危告警总数
                |t3.driver_habit_adas_all	,---ADAS告警总数
                |t3.driver_habit_hhh_all	,---HHH告警总数
                |'' driver_accident_score	,---历史事故评估得分
                | int((length(nvl(t1.d_accident_time,''))-length(regexp_replace(nvl(t1.d_accident_time,''), "rank", ''))) / length("rank"))
                | as driver_accident_all	,---过去半年事故次数
                |'' driver_accident_type	,---过去半年事故发生等级
                |'' driver_insturance_all	,---过去半年理赔成本
                |'' driver_safety_score	,---安全意识得分
                |t4.exam_ct as driver_study_all	,---学习次数
                |t4.pass_ct as driver_study_pass	,---通过次数
                |t4.exam_pass_pert as driver_study_rate	,---学习通过率
                |case when regexp_replace(substr(t2.driver_license_deadline,0,10),'-','')>=${input_inc_day2} then 1 else 0 end driver_license_state	,---驾驶证是否有效,1有效、0无效
                |'' driver_meeting_all	,---例会总次数
                |'' driver_meeting_ct	,---例会参与次数
                |'' driver_meeting_state	,---例会参与度
                |'' driver_safe_mileage_score	,---安全行驶里程得分
                |'' score_dictionary	,---分数解读
                |'${input_inc_day1}' data_start	,---周结表计算周期开始时间
                |'${input_inc_day2}' data_end, ---周结表计算周期结束时间
                |t3.driver_violations_smoking_all,
                |t3.driver_violations_phone_all,
                |t3.driver_violations_camera_all,
                |t3.driver_violations_fatigue_all,
                |t3.driver_violations_follow_all,
                |t3.driver_driving_follow_all,
                |t3.driver_habit_distracted_all,
                |t3.driver_habit_laned_eparture_all,
                |t3.driver_habit_close_distance_all,
                |t3.driver_habit_rapid_acceleration_all,
                |t3.driver_habit_sharp_deceleration_all,
                |t3.driver_habit_speeding_all
                |from (
                |select * from dm_gis_scm.dm_driver_label_day
                |where inc_day=${input_inc_day2}
                |) t1
                |left join
                |(
                |select * from dm_gis_scm.dm_scm_driver
                |where inc_day=${input_inc_day2} and emp_code is not null and emp_code !=''  and driver_type='1'
                |) t2 on t1.driver_code=t2.emp_code
                |left join tempzy20221116_driverweek_alarm_detail_tb2 t3
                |on t1.driver_code=t3.main_driver_account
                |left join tempzy20221116_driver_exam_tb t4
                |on t1.driver_code=t4.emp_code
                |left join
                |( select * from (
                |select dept_id,area_code,area_name,row_number() over(partition by dept_id order by create_tm desc) rank
                | from dim.dim_department) x where x.rank=1
                |) t5 on t2.dept_id=t5.dept_id
                |left join tempzy20221116_driver_motorcade_tb t6
                |on t2.dept_id=t6.dept_id
                |left join
                |(select emp_code,case when cancel_flag='Y' then '离职' else '在职' end driver_state
                | from dim.dim_emp_info_df where inc_day=${input_inc_day2}
                |) t7 on lpad(t1.driver_code,8,'0')=lpad(t7.emp_code,8,'0')""".stripMargin
    val week_result=spark.sql(sql4)

    week_result.createOrReplaceTempView("tempzy20221116_driverweek_result_tb")
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis_scm.dm_driver_label_week limit 0""").schema.map(_.name).map(col)

    val final_result=week_result.join(week_index1_a,week_result("driver_code")===week_index1_a("main_driver_account"),"left")
      .drop(week_index1_a("main_driver_account"))
      .withColumn("driver_violations_all_intervene",lit(""))
      .withColumn("driver_violations_dms_all_intervene",lit(""))
      .withColumn("driver_violations_hod_all__intervene",lit(""))
      .withColumn("driver_violations_smoking_all_intervene",lit(""))
      .withColumn("driver_violations_phone_all_intervene",lit(""))
      .withColumn("driver_violations_camera_all_intervene",lit(""))
      .withColumn("driver_violations_fatigue_all_intervene",lit(""))
      .withColumn("driver_violations_all_intervene_count",lit(""))
      .withColumn("driver_violations_all_intervene_type",lit(""))
      .join(week_index1_b,week_result("driver_code")===week_index1_b("main_driver_account"),"left")
      .drop(week_index1_b("main_driver_account"))
      .withColumn("driver_habit_all_intervene",lit(""))
      .withColumn("driver_habit_adas_all_intervene",lit(""))
      .withColumn("driver_habit_hhh_all_intervene",lit(""))
      .withColumn("driver_habit_distracted_all_intervene",lit(""))
      .withColumn("driver_habit_laned_eparture_all_intervene",lit(""))
      .withColumn("driver_habit_close_distance_all_intervene",lit(""))
      .withColumn("driver_habit_rapid_acceleration_all_intervene",lit(""))
      .withColumn("driver_habit_sharp_deceleration_all_intervene",lit(""))
      .withColumn("driver_habit_speeding_all_intervene",lit(""))
      .withColumn("driver_habit_intersection_speeding_all",lit(""))
      .withColumn("driver_habit_intersection_speeding_all_intervene",lit(""))
      .withColumn("driver_habit_all_intervene_count",lit(""))
      .withColumn("driver_habit_all_intervene_type",lit(""))
      .withColumn("driver_violations_all_speed",when($"driver_violations_follow_all">0 && ($"driver_violations_all_speed".isNull ||trim($"driver_violations_all_speed")===""),0)
        .otherwise($"driver_violations_all_speed"))
      .withColumn("driver_habit_all_speed",when($"driver_driving_follow_all">0 && ($"driver_habit_all_speed".isNull ||trim($"driver_habit_all_speed")===""),0)
        .otherwise($"driver_habit_all_speed"))
      .withColumn("inc_day",lit(input_inc_day2))
      .select(table_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK)
    //数据存dm表
    writeToHive(spark, final_result, Seq("inc_day"), "dm_gis_scm.dm_driver_label_week")

    spark.close()
  }

}
