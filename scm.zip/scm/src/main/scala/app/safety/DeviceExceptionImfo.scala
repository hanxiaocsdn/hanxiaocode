package app.safety


import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.TimeDef.{getdaysBeforeOrAfter, turnday}
/**
 **description：设备异常宽表
 ***需求描述：顺丰客户对地区进行安全管理，对地区维度有相关考核指标。此表为方便取出设备调整明细，监管地区安全情况，提高周报统计效率所建。
 **任务id：661045
 **研发：01390943周勇
 **需求方：01422529刘桓
 **/

object DeviceExceptionImfo extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args:Array[String] )={

    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol","true")
      .config("spark.sql.broadcastTimeout","36000")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._
    //日期
    val dayvar0=args(0)
    //往前取2天，用于对比
    val dayvar2 = getdaysBeforeOrAfter(dayvar0, -2)
    //往前取6天，用于对比
    val dayvar6 = getdaysBeforeOrAfter(dayvar0, -6)
    //往前取6天，用于对比
    val dayvar30 = getdaysBeforeOrAfter(dayvar0, -29)
    //设备异常
    val device_data=spark.sql(
      s"""
         |select * from dm_gis.dm_dwd_device_day
         |where inc_day='$dayvar0'
         |""".stripMargin)
      .withColumn("datacode_tmp",$"datacode")
      .withColumn("datacode",substring($"datacode",0,8))

    logger.error("device_data数据量："+device_data.count())

    //position映射 1:"adas", 2:"dms", 3:"bsd", 4:"bsd2", 6:"back",7:"hod",8:"general",9:"general2"
    val position_condition=when(get_json_object($"cameralist_dtl","$.position")==="1","adas").
      when(get_json_object($"cameralist_dtl","$.position")==="2","dms").
      when(get_json_object($"cameralist_dtl","$.position")==="3","bsd").
      when(get_json_object($"cameralist_dtl","$.position")==="4","bsd2").
      when(get_json_object($"cameralist_dtl","$.position")==="6","back").
      when(get_json_object($"cameralist_dtl","$.position")==="7","hod").
      when(get_json_object($"cameralist_dtl","$.position")==="8","general").
      when(get_json_object($"cameralist_dtl","$.position")==="9","general2").
      otherwise(get_json_object($"cameralist_dtl","$.position"))

    //type映射 0:"正常", 1:"模糊", 2:"角度偏上", 3:"角度偏下", 4:"不确定", 5:"屏幕异常",6:"信号丢失", 7:"角度轻微偏离", 8:"角度异常", 9:"花屏"
    val type_condition=when(get_json_object($"cameralist_dtl","$.type")==="0","正常").
      when(get_json_object($"cameralist_dtl","$.type")==="1","模糊").
      when(get_json_object($"cameralist_dtl","$.type")==="2","角度偏上").
      when(get_json_object($"cameralist_dtl","$.type")==="3","角度偏下").
      when(get_json_object($"cameralist_dtl","$.type")==="4","不确定").
      when(get_json_object($"cameralist_dtl","$.type")==="5","屏幕异常").
      when(get_json_object($"cameralist_dtl","$.type")==="6","信号丢失").
      when(get_json_object($"cameralist_dtl","$.type")==="7","角度轻微偏离").
      when(get_json_object($"cameralist_dtl","$.type")==="8","角度异常").
      when(get_json_object($"cameralist_dtl","$.type")==="9","花屏").
      otherwise(get_json_object($"cameralist_dtl","$.type"))

    //cameralist数据
    val cameralist_data=spark.sql(
      s"""
         |select x.*,cameralist_dtl
         |from (
         |select imei,datacode as datacode_ca,cameralist,inc_day,replace(replace(replace(replace(cameralist,'[',''),']',''),'},{"position"','}|{"position"'),'}, {"position"','}|{"position"')  cameralist2
         |from
         |(
         |select imei,datacode,case when cameralist is null or trim(cameralist)='' then 'nulla' else cameralist end cameralist,inc_day
         |from dm_gis.dm_dwd_device_day
         |where inc_day='$dayvar0'
         |) a
         |) x
         |LATERAL VIEW explode (split(cameralist2, '[|]')) tmp as cameralist_dtl
         |""".stripMargin)
      .withColumn("position",get_json_object($"cameralist_dtl","$.position"))
      .withColumn("position_text",position_condition)
      .withColumn("type",get_json_object($"cameralist_dtl","$.type"))
      .withColumn("type_text",type_condition)
      .withColumn("event_time",get_json_object($"cameralist_dtl","$.event_time"))
      .withColumn("event_day",when($"event_time".isNotNull && trim($"event_time") =!="",regexp_replace($"event_time".substr(0,10),"-","")).
        otherwise(""))
      .withColumn("confidence",get_json_object($"cameralist_dtl","$.confidence"))
      .withColumn("deviation_camera",get_json_object($"cameralist_dtl","$.deviation"))
      .withColumn("deviationpercentage",get_json_object($"cameralist_dtl","$.deviationPercentage"))


    //cameraType映射 0:"adas", 1:"dms", 2:"bsd", 3:"bsd2", 4:"back", 5:"hod", 6:"general", 7:"general2"
    val cameratype_condition=when(get_json_object($"analysislist_dtl","$.cameraType")==="0","adas").
      when(get_json_object($"analysislist_dtl","$.cameraType")==="1","dms").
      when(get_json_object($"analysislist_dtl","$.cameraType")==="2","bsd").
      when(get_json_object($"analysislist_dtl","$.cameraType")==="3","bsd2").
      when(get_json_object($"analysislist_dtl","$.cameraType")==="4","back").
      when(get_json_object($"analysislist_dtl","$.cameraType")==="5","hod").
      when(get_json_object($"analysislist_dtl","$.cameraType")==="6","general").
      when(get_json_object($"analysislist_dtl","$.cameraType")==="7","general2").
      otherwise(get_json_object($"analysislist_dtl","$.cameraType"))

    //analysislist数据
    val analysislist_data=spark.sql(
      s"""
         |select x.*,analysislist_dtl
         |from (
         |select imei,datacode as datacode_tmpan,analysislist,inc_day,
         |replace(replace(replace(replace(analysislist,'[',''),']',''),'},{"cameraType"','}|{"cameraType"'),'}, {"cameraType"','}|{"cameraType"')  analysislist2
         |from
         |(
         |select imei,datacode,case when analysislist is null or trim(analysislist)='' then 'nulla' else analysislist end analysislist,inc_day
         |from dm_gis.dm_dwd_device_day
         |where inc_day='$dayvar0'
         |) a
         |) x
         |LATERAL VIEW explode (split(analysislist2, '[|]')) tmp as analysislist_dtl
         |""".stripMargin)
      .withColumn("cameratype",get_json_object($"analysislist_dtl","$.cameraType"))
      .withColumn("cameratype_text",cameratype_condition)
      .withColumn("stability",get_json_object($"analysislist_dtl","$.stability"))
      .withColumn("priority",get_json_object($"analysislist_dtl","$.priority"))


    //camera_error计算
    val camera_error_data=cameralist_data.join(analysislist_data, cameralist_data("imei")===analysislist_data("imei")
      && cameralist_data("datacode_ca")===analysislist_data("datacode_tmpan")
      && cameralist_data("position_text")===analysislist_data("cameratype_text"),
      "left")
      .drop(analysislist_data("imei"))
      .filter($"type".isin("1","2","3","8") && !$"position".isin("6","8","9"))
      .withColumn("is_stability",when($"stability"<=0.2,0).otherwise(1))
      .filter($"is_stability"===1)
      .withColumn("position_type_text",concat_ws("",$"position_text",$"type_text"))

      .withColumn("dayvar6",lit(dayvar6))
      .withColumn("data_flag",when($"event_day"<$"dayvar6",1).otherwise(0))
      .filter($"data_flag"===0)

      .groupBy("imei")
      .agg(concat_ws(";",collect_list($"position_type_text")) as "camera_error" )

    //zytype条件映射
    val zytype_condition=when($"zytype"==="1","T1").
      when($"zytype"==="0","T1").
      when($"zytype"==="2","G1").
      when($"zytype"==="3","B1").
      when($"zytype"==="4","B2").
      when($"zytype"==="5","L1").
      when($"zytype"==="6","T3").
      when($"zytype"==="7","T2").
      when($"zytype"==="10","JT").
      when($"zytype"==="11","L2").
      when($"zytype"==="12","丰图宝").
      when($"zytype"==="13","S1").
      when($"zytype"==="14","ZG4").
      when($"zytype"==="15","ZG23").
      when($"zytype"==="16","D1").
      when($"zytype"==="17","电子锁").
      when($"zytype"==="18","B201").
      when($"zytype"==="19","T5").
      when($"zytype"==="20","T6").
      when($"zytype"==="21","优必飞").
      when($"zytype"==="22","佑驾").
      when($"zytype"==="23","T3SE").
      otherwise($"zytype")

    //type映射值
    val temp_condition=when($"exception_type".isin("11","12"),"adas").
      when($"exception_type".isin("13","14"),"dms").
      when($"exception_type".isin("15","16"),"bsd").
      when($"exception_type"==="19","bsd2").
      when($"exception_type"==="21","hod").
      otherwise("")

    //maincode映射值
    val maincode_condition=when($"maincode"==="-1","系统软件状态").
      when($"maincode"==="-2","SD卡状态").
      when($"maincode"==="-3","主机状态").
      when($"maincode"==="-4","摄像头硬件状态").
      otherwise($"maincode")

    //exceptionList的type映射值
    val exception_type_condition=when($"exception_type"==="1","采集app").
      when($"exception_type"==="2","iot登录").
      when($"exception_type"==="3","iot新消息").
      when($"exception_type"==="4","obs").
      when($"exception_type"==="5","sd卡挂载").
      when($"exception_type"==="6","sd卡剩余空间").
      when($"exception_type"==="7","sd卡容量").
      when($"exception_type"==="8","系统时间").
      when($"exception_type"==="9","频繁ACC开关").
      when($"exception_type"==="10","长时间待机").
      when($"exception_type"==="11","adas摄像头帧").
      when($"exception_type"==="12","adas摄像头视频").
      when($"exception_type"==="13","dms摄像头帧").
      when($"exception_type"==="14","dms摄像头视频").
      when($"exception_type"==="15","bsd摄像头帧").
      when($"exception_type"==="16","bsd摄像头视频").
      when($"exception_type"==="17","无法获取定位").
      when($"exception_type"==="18","长时间定位无更新").
      when($"exception_type"==="19","第二路BSD摄像头").
      when($"exception_type"==="20","车尾摄像头").
      when($"exception_type"==="21","HOD摄像头").
      when($"exception_type"==="22","普通（无算法）监控摄像头").
      when($"exception_type"==="23","普通（无算法）监控摄像头2").
      otherwise($"exception_type")

    //exceptionList数据
    val exceptionlist_data=spark.sql(
      s"""
         |select x.*,exceptionlist_dtl
         |from (
         |select imei,datacode as datacode_tmpexc,exceptionlist,healthetype,zytype,coalarmscount,addascount,hodcount,bsdcount,coalarms,inc_day,
         |replace(replace(replace(replace(exceptionlist,'[',''),']',''),'},{"mainCode"','}|{"mainCode"'),'}, {"mainCode"','}|{"mainCode"')  exceptionlist2
         |from
         |(
         |select imei,datacode,case when exceptionlist is null or trim(exceptionlist)='' then 'nulla' else exceptionlist end exceptionlist,
         |healthetype,zytype,coalarmscount,addascount,hodcount,bsdcount,coalarms,inc_day
         |from dm_gis.dm_dwd_device_day
         |where inc_day='$dayvar0'
         |) a
         |) x
         |LATERAL VIEW explode (split(exceptionlist2, '[|]')) tmp as exceptionlist_dtl
         |""".stripMargin)
      .withColumn("subcode",get_json_object($"exceptionlist_dtl","$.subCode"))
      .withColumn("maincode",get_json_object($"exceptionlist_dtl","$.mainCode"))
      .withColumn("maincode_text",maincode_condition)
      .withColumn("exception_type",get_json_object($"exceptionlist_dtl","$.type"))
      .withColumn("exception_type_text",exception_type_condition)
      .withColumn("devicetype",zytype_condition)
      .withColumn("temp",temp_condition)
      .withColumn("exceptiontime",get_json_object($"exceptionlist_dtl","$.exceptionTime"))


    //过滤不符合要求的
    val is_exception_delete_condition=when($"maincode"==="-1" && $"exception_type"==="3",1).
      when($"maincode"==="-2" && $"exception_type"==="5" && $"devicetype".isin("B1","B2","B201","JT"),1).
      when($"maincode"==="-2" && $"exception_type"==="7",1).
      when($"maincode"==="-4" && $"exception_type".isin("20","22"),1).
      when($"maincode"==="-4" && $"exception_type".isin("11","12") && $"devicetype".isin("B1","B2","B201","JT") && $"addascount">0,1).
      when($"maincode"==="-4" && $"exception_type".isin("13","14") && $"devicetype".isin("B1","B2","B201","JT") && $"coalarmscount"-$"coalarms">0,1).
      when($"maincode"==="-4" && $"exception_type"==="21" && $"devicetype".isin("B1","B2","B201","JT") && $"hodcount">0,1).
      otherwise(0)


    val exception_error_data1=exceptionlist_data.filter($"healthetype".isin("1","3") && $"subcode"==="-1")
      .withColumn("is_exception_delete",is_exception_delete_condition)
      .filter($"is_exception_delete"===0)
      .join(cameralist_data,exceptionlist_data("imei")===cameralist_data("imei")
        && exceptionlist_data("temp")===cameralist_data("position_text")
        ,"left")
      .drop(cameralist_data("imei"))
      //dayvar2格式是YYYYMMDD
      .withColumn("dayvar2",lit(dayvar2))
      .withColumn("data_flag",when($"event_day">=$"dayvar2",1).otherwise(0))
      .withColumn("is_group_delete",when($"temp"=!="" && $"type".isin("0", "1", "2", "3", "4", "7", "8") && $"data_flag"===1 ,1)
        .otherwise(0))
      .filter($"is_group_delete"===0 )
      .filter($"maincode_text"==="摄像头硬件状态")
      .groupBy("imei")
      .agg(concat_ws(";",collect_list($"exception_type_text")) as "exception_error1" )


    //exception_error计算：第二段
    val exception_error_data2=cameralist_data.filter($"type".isin("5","6","9") && !$"position".isin("6","8","9"))
      .withColumn("maincode_type_text2",concat_ws("",$"position_text",$"type_text"))
      .groupBy("imei")
      .agg(concat_ws(";",collect_list($"maincode_type_text2")) as "exception_error1" )

    //exception_error合并
    val exception_error_all=exception_error_data2.union(exception_error_data1)
      .groupBy("imei")
      .agg(concat_ws(";",collect_list($"exception_error1")) as "exception_error" )

    //sdcard计算
    val sdcard_data=exceptionlist_data.filter($"healthetype".isin("1","3") && $"subcode"==="-1")
      .withColumn("is_exception_delete",is_exception_delete_condition)
      .filter($"is_exception_delete"===0)
      .join(cameralist_data,exceptionlist_data("imei")===cameralist_data("imei")
        && exceptionlist_data("temp")===cameralist_data("position_text")
        ,"left")
      .drop(cameralist_data("imei"))
      //dayvar2格式是YYYYMMDD
      .withColumn("dayvar2",lit(dayvar2))
      .withColumn("data_flag",when($"event_day">=$"dayvar2",1).otherwise(0))
      .withColumn("is_group_delete",when($"temp"=!="" && $"type".isin("0", "1", "2", "3", "4", "7", "8") && $"data_flag"===1 ,1)
        .otherwise(0))
      .filter($"is_group_delete"===0 )
      .filter($"maincode_text"==="SD卡状态")
      .groupBy("imei")
      .agg(concat_ws(";",collect_list($"exception_type_text")) as "sdcard" )

    //engine计算
    val engine_data=exceptionlist_data.filter($"healthetype".isin("1","3") && $"subcode"==="-1")
      .withColumn("is_exception_delete",is_exception_delete_condition)
      .filter($"is_exception_delete"===0)
      .join(cameralist_data,exceptionlist_data("imei")===cameralist_data("imei")
        && exceptionlist_data("temp")===cameralist_data("position_text")
        ,"left")
      .drop(cameralist_data("imei"))
      //dayvar2格式是YYYYMMDD
      .withColumn("dayvar2",lit(dayvar2))
      .withColumn("data_flag",when($"event_day">=$"dayvar2",1).otherwise(0))
      .withColumn("is_group_delete",when($"temp"=!="" && $"type".isin("0", "1", "2", "3", "4", "7", "8") && $"data_flag"===1 ,1)
        .otherwise(0))
      .filter($"is_group_delete"===0 )
      .filter($"maincode_text"==="主机状态")
      .groupBy("imei")
      .agg(concat_ws(";",collect_list($"exception_type_text")) as "engine" )

    //software计算
    val software_data_temp=exceptionlist_data.filter($"healthetype".isin("1","3") && $"subcode"==="-1")
      .withColumn("is_exception_delete",is_exception_delete_condition)
      .filter($"is_exception_delete"===0)
      .join(cameralist_data,exceptionlist_data("imei")===cameralist_data("imei")
        && exceptionlist_data("temp")===cameralist_data("position_text")
        ,"left")
      .drop(cameralist_data("imei"))
      //dayvar2格式是YYYYMMDD
      .withColumn("dayvar2",lit(dayvar2))
      .withColumn("data_flag",when($"event_day">=$"dayvar2",1).otherwise(0))
      .withColumn("is_group_delete",when($"temp"=!="" && $"type".isin("0", "1", "2", "3", "4", "7", "8") && $"data_flag"===1 ,1)
        .otherwise(0))
      .filter($"is_group_delete"===0 )
      .withColumn("flag_a",when($"maincode"==="-2" && $"exception_type"==="5",1).
        when($"maincode"==="-1",2).
        otherwise(3))

    val software_data_temp_a=software_data_temp.filter($"flag_a"===1)
      .withColumn("imei_a",$"imei")
      .select("imei","imei_a")
      .distinct()

    val software_data_temp_b=software_data_temp.join(software_data_temp_a,Seq("imei"),"left")
      .withColumn("flag_b",when($"flag_a"===2 && $"imei_a".isNotNull,0).otherwise(1))


    val software_data=software_data_temp_b
      .filter($"flag_b"===1)
      // .filter($"flag4"===1)
      .filter($"maincode_text"==="系统软件状态")
      .groupBy("imei")
      .agg(concat_ws(";",collect_list($"exception_type_text")) as "software" )


    //注册一个udf函数定义日期格式
    val turnday_udf=udf(turnday _)

    //计算out7day和maxnotcheckdays
    val out7day_max_data=cameralist_data
      //dayvar6格式是YYYYMMDD
      .withColumn("dayvar6",lit(dayvar6))
      .withColumn("data_flag",when($"event_day"<$"dayvar6",1).otherwise(0))
      .filter($"data_flag"===1)
      .withColumn("position_type_text",concat_ws("",$"position_text",$"type_text"))
      .withColumn("event_day_a",when($"event_day".isNull || trim($"event_day")==="","").otherwise(turnday_udf($"event_day")))
      .withColumn("inc_day_a",turnday_udf($"inc_day"))
      .withColumn("datediff_cnt",when($"event_day".isNull || trim($"event_day")==="",null).
        otherwise(datediff($"inc_day_a",$"event_day_a")))
      .groupBy("imei")
      .agg(concat_ws(";",collect_list($"position_type_text")) as "out7day" ,
        max($"datediff_cnt") as "maxnotcheckdays")

    //最近7天上线次数
    val device_data_days7=spark.sql(
      s"""
         |select * from dm_gis.dm_dwd_device_day
         |where inc_day>='$dayvar6' and inc_day<='$dayvar0'
         |""".stripMargin)
      //.withColumn("is_exist",when($"onlinetime".isNull || trim($"onlinetime")==="",0).otherwise(1))
      .withColumn("is_exist",when($"tnalarm">0 || $"kmcar">0 || ($"onlinetime".isNotNull && trim($"onlinetime")=!="")  || ($"offlinetime".isNotNull && trim($"offlinetime")=!="") ,1).otherwise(0))
      .groupBy("imei")
      .agg(sum($"is_exist") as "onlinetag")
      .withColumn("onlinetag",when($"onlinetag"===0,"7天不在线").otherwise(""))

    //连续不在线天数
    val device_data_days30=spark.sql(
      s"""
         |select * from dm_gis.dm_dwd_device_day
         |where inc_day>='$dayvar30' and inc_day<='$dayvar0'
         |""".stripMargin)
      //.withColumn("is_exist",when($"onlinetime".isNull || trim($"onlinetime")==="",0).otherwise(1))
      .withColumn("is_exist",when($"tnalarm">0 || $"kmcar">0 || ($"onlinetime".isNotNull && trim($"onlinetime")=!="")  || ($"offlinetime".isNotNull && trim($"offlinetime")=!="") ,1).otherwise(0))
      .withColumn("rank",row_number().over(Window.partitionBy("imei").orderBy(desc("inc_day"))))
      .withColumn("rank1",lpad($"rank",8,"0"))
      .withColumn("daytype",concat($"rank1",lit("_"),$"is_exist"))
      .groupBy("imei")
      .agg(concat_ws(";",sort_array(collect_list($"daytype"))) as "hebing")
      .withColumn("offlinedays",countlx_udf($"hebing"))

    //部门组织表
    val sysorg_data=spark.sql(
      s"""
         |select data_code as datacode,name as org_name from dm_arss.dm_sys_dept_dtl_di
         |where inc_day='$dayvar0'
         |""".stripMargin)

    //过滤条件
    val final_filter_condition=when(($"camera_error".isNull || trim($"camera_error")==="") &&
      ($"exception_error".isNull || trim($"exception_error")==="") &&
      ($"sdcard".isNull || trim($"sdcard")==="") &&
      ($"engine".isNull || trim($"engine")==="") &&
      ($"software".isNull || trim($"software")==="") &&
      ($"out7day".isNull || trim($"out7day")==="") &&
      ($"maxnotcheckdays".isNull || trim($"maxnotcheckdays")==="") &&
      $"onlinetag" =!="7天不在线"
      ,0).otherwise(1)
    val table_cols1 = spark.sql("""select * from dm_gis.dm_device_exception_dtl limit 0""").schema.map(_.name).map(col)
    //结果表一数据合并
    val result_exception_tb_tmp=device_data.join(sysorg_data,Seq("datacode"),"left")
      .withColumn("car_no",$"carno")
      .withColumn("devicetype",zytype_condition)
      .join(camera_error_data,Seq("imei"),"left")
      .join(exception_error_all,Seq("imei"),"left")
      .join(out7day_max_data,Seq("imei"),"left")
      .join(device_data_days7,Seq("imei"),"left")
      .join(sdcard_data,Seq("imei"),"left")
      .join(engine_data,Seq("imei"),"left")
      .join(software_data,Seq("imei"),"left")
      .join(device_data_days30,Seq("imei"),"left")
      .withColumn("inc_day", lit(dayvar0))
      .withColumn("is_final_filter",final_filter_condition)
      .withColumn("onlinetag",when($"onlinetag"==="7天不在线" && $"offlinedays">=7,"7天不在线").otherwise(""))
      .persist(StorageLevel.MEMORY_AND_DISK)

    //保存用于测试
    //    spark.sql("drop table if exists default.result_exception_tb_tmp2")
    //    result_exception_tb_tmp.write.mode("overwrite").format("parquet").saveAsTable("default.result_exception_tb_tmp2")

    logger.error("result_exception_tb_tmp数据量："+result_exception_tb_tmp.count())

    val result_exception_tb=result_exception_tb_tmp.filter($"is_final_filter"===1)
      .select(table_cols1: _*)

    logger.error("result_exception_tb数据量："+result_exception_tb.count())

    //结果表一数据存dm表：设备异常宽表
    writeToHive(spark, result_exception_tb, Seq("inc_day"), "dm_gis.dm_device_exception_dtl")

    //---------------------------表二---------------------------------------------

    //过滤条件
    val final_filter_condition2=when($"type".isin("1","2","3","8") && !$"position".isin("6","8","9")
      ,1).otherwise(0)
    //选取字段
    val table_cols2 = spark.sql("""select * from dm_gis.dm_cameralist_exception_dtl limit 0""").schema.map(_.name).map(col)
    //结果表二数据合并
    val result_exception_tb2=device_data.join(sysorg_data,Seq("datacode"),"left")
      .withColumn("car_no",$"carno")
      .withColumn("devicetype",zytype_condition)
      .join(cameralist_data,Seq("imei"),"left")
      .join(analysislist_data,device_data("imei")===analysislist_data("imei") && device_data("datacode_tmp")===analysislist_data("datacode_tmpan") &&
        cameralist_data("position_text")===analysislist_data("cameratype_text"),"left")
      .drop(analysislist_data("imei"))
      .drop(cameralist_data("inc_day"))
      .drop(analysislist_data("inc_day"))
      .withColumn("event_day_b",when($"event_day".isNull || trim($"event_day")==="","").otherwise(turnday_udf($"event_day")))
      .withColumn("inc_day_b",turnday_udf($"inc_day"))
      .withColumn("datediff_cntb",when($"event_day".isNull || trim($"event_day")==="","").
        otherwise(datediff($"inc_day_b",$"event_day_b")))
      .withColumn("tag",when($"datediff_cntb">=7,"自检时间7天外").otherwise(""))
      .withColumn("inc_day", lit(dayvar0))
      .withColumn("is_final_filter",final_filter_condition2)
      .filter($"is_final_filter"===1)
      .select(table_cols2: _*)

    //结果表二数据存dm表：设备异常宽表
    writeToHive(spark, result_exception_tb2, Seq("inc_day"), "dm_gis.dm_cameralist_exception_dtl")

    //---------------------------表三---------------------------------------------

    //过滤条件
    val final_filter_condition3a=when($"type".isin("5","6","9") && !$"position".isin("6","8","9")
      ,1).otherwise(0)
    //选取字段
    val table_cols3 = spark.sql("""select * from dm_gis.dm_hardwale_exception_dtl limit 0""").schema.map(_.name).map(col)
    //结果表三数据：a部分
    val result_exception_tb3a=device_data.join(sysorg_data,Seq("datacode"),"left")
      .withColumn("car_no",$"carno")
      .withColumn("devicetype",zytype_condition)
      .join(cameralist_data,Seq("imei"),"left")
      .drop(cameralist_data("inc_day"))
      .withColumn("maincode2",position_condition)
      .withColumn("type2",type_condition)
      .withColumn("exceptiontime",$"event_time")
      .withColumn("is_final_filter",final_filter_condition3a)
      .filter($"is_final_filter"===1)
      .select(table_cols3: _*)

    //过滤不符合要求
    val is_exception_delete_condition3b=when($"maincode"==="-1" && $"exception_type"==="3",1).
      when($"maincode"==="-2" && $"exception_type"==="5" && $"devicetype".isin("B1","B2","B201","JT"),1).
      when($"maincode"==="-2" && $"exception_type"==="7",1).
      when($"maincode"==="-4" && $"exception_type".isin("20","22"),1).
      when($"maincode"==="-4" && $"exception_type".isin("11","12") && $"devicetype".isin("B1","B2","B201","JT") && $"addascount">0,1).
      when($"maincode"==="-4" && $"exception_type".isin("13","14") && $"devicetype".isin("B1","B2","B201","JT") && $"coalarmscount"-$"coalarms">0,1).
      when($"maincode"==="-4" && $"exception_type"==="21" && $"devicetype".isin("B1","B2","B201","JT") && $"hodcount">0,1).
      otherwise(0)
    //过滤条件
    val final_filter_condition3b=when($"healthetype".isin("1","3") && $"subcode"==="-1",1).otherwise(0)
    //结果表三数据：b部分
    val result_exception_tb3b=device_data.drop("addascount","coalarmscount","coalarms","hodcount","healthetype")
      .join(sysorg_data,Seq("datacode"),"left")
      .withColumn("car_no",$"carno")
      .withColumn("devicetype",zytype_condition)
      .join(exceptionlist_data,Seq("imei"),"left")
      .drop(exceptionlist_data("inc_day"))
      .drop(exceptionlist_data("devicetype"))
      .withColumn("is_exception_delete",is_exception_delete_condition3b)
      .filter($"is_exception_delete"===0)
      .withColumn("maincode2",maincode_condition)
      .withColumn("type2",exception_type_condition)
      .withColumn("exceptiontime",$"exceptiontime")
      .withColumn("is_final_filter",final_filter_condition3b)
      .filter($"is_final_filter"===1)
      .join(cameralist_data,device_data("imei")===cameralist_data("imei")
        && exceptionlist_data("temp")===cameralist_data("position_text")
        ,"left")
      .drop(cameralist_data("imei"))
      .drop(cameralist_data("inc_day"))
      //dayvar2格式是YYYYMMDD
      .withColumn("dayvar2",lit(dayvar2))
      .withColumn("data_flag",when($"event_day">=$"dayvar2",1).otherwise(0))
      .withColumn("is_group_delete",when($"temp"=!="" && $"type".isin("0", "1", "2", "3", "4", "7", "8") && $"data_flag"===1 ,1)
        .otherwise(0))
      .filter($"is_group_delete"===0 )

      .withColumn("flag_a",when($"maincode"==="-2" && $"exception_type"==="5",1).
        when($"maincode"==="-1",2).
        otherwise(3))


    val result_exception_tb3b_1=result_exception_tb3b.filter($"flag_a"===1)
      .withColumn("imei_a",$"imei")
      .select("imei","imei_a")
      .distinct()

    val result_exception_tb3b_2=result_exception_tb3b.join(result_exception_tb3b_1,Seq("imei"),"left")
      .withColumn("flag_b",when($"flag_a"===2 && $"imei_a".isNotNull,0).otherwise(1))

      .filter($"flag_b"===1)
      .select(table_cols3: _*)

    //结果表三数据合并
    val result_exception_tb3=result_exception_tb3a.union(result_exception_tb3b_2)

    //结果表三数据存dm表：设备异常宽表
    writeToHive(spark, result_exception_tb3, Seq("inc_day"), "dm_gis.dm_hardwale_exception_dtl")

    //---------------------------表四---------------------------------------------

    //过滤条件
    val final_filter_condition4=when($"tag"==="自检时间7天外",1).otherwise(0)
    //选取字段
    val table_cols4 = spark.sql("""select * from dm_gis.dm_selfcheck_exception_dtl limit 0""").schema.map(_.name).map(col)
    //结果表四数据合并
    val result_exception_tb4=device_data.join(sysorg_data,Seq("datacode"),"left")
      .withColumn("car_no",$"carno")
      .withColumn("devicetype",zytype_condition)
      .join(cameralist_data,Seq("imei"),"left")
      .join(analysislist_data,device_data("imei")===analysislist_data("imei") && device_data("datacode_tmp")===analysislist_data("datacode_tmpan") &&
        cameralist_data("position_text")===analysislist_data("cameratype_text"),"left")
      .drop(analysislist_data("imei"))
      .drop(cameralist_data("inc_day"))
      .drop(analysislist_data("inc_day"))
      .withColumn("event_day_b",when($"event_day".isNull || trim($"event_day")==="","").otherwise(turnday_udf($"event_day")))
      .withColumn("inc_day_b",turnday_udf($"inc_day"))
      .withColumn("datediff_cntb",when($"event_day".isNull || trim($"event_day")==="","").
        otherwise(datediff($"inc_day_b",$"event_day_b")))
      .withColumn("tag",when($"datediff_cntb">=7,"自检时间7天外").otherwise(""))
      .withColumn("inc_day", lit(dayvar0))
      .withColumn("is_final_filter",final_filter_condition4)
      .filter($"is_final_filter"===1)
      .select(table_cols4: _*)

    //结果表四数据存dm表：设备异常宽表
    writeToHive(spark, result_exception_tb4, Seq("inc_day"), "dm_gis.dm_selfcheck_exception_dtl")

    spark.close()
  }

  //计算连续不在线天数
  def countlx(x:String): Int ={
    val x_arr=x.split(";")
    val l=x_arr.length
    var i=0
    var flag=1
    while(flag==1 && i<l){
      if(x_arr(i).split("_")(1)=="0")
      { i=i+1
        flag=1
      }
      else flag=0
    }
    i
  }
  val countlx_udf=udf(countlx _)



}





