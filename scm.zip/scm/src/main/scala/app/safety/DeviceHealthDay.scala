package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import utils.CommonTools.getdaysBeforeOrAfter
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util.Calendar

/**
 *需求名称：设备健康度日报表
 *需求描述：顺丰客户对地区进行安全管理，对地区维度有相关考核指标。此表为方便取出地区维度的设备治理情况，监管地区安全情况，提高日报统计效率所建。
 *需求方：刘桓(01422529)
 *开发: 周勇(01390943)
 *任务创建时间：20230511
 *任务id：785128
 **/

object DeviceHealthDay  extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    val dayvar = args(0)
    val dayvar1 = getdaysBeforeOrAfter(dayvar, -1)
    val dayvar3 = getdaysBeforeOrAfter(dayvar, -3)
    val dayvar4 = getdaysBeforeOrAfter(dayvar, -7)
    logger.error("接收输入变量dayvar:" + dayvar)
    logger.error("接收输入变量dayvar1:" + dayvar1)
    logger.error("接收输入变量dayvar3:" + dayvar3)
    logger.error("接收输入变量dayvar4:" + dayvar4)

    //设备区域表
    val device_dept=spark.sql(
      s"""
         |select *,carplate car_no from dm_arss.dm_device_hh_dtl_di
         |where inc_day='$dayvar1'
         |""".stripMargin)
      .filter($"is_security"==="0")
      .withColumn("data_code_tmp",$"data_code".substr(1,8))
      .filter($"data_code_tmp".isin("10001004","10001010","10001011","10001120"))

    //设备区域表去重
    val device_deptcq=device_dept
      .withColumn("rank", row_number().over(Window.partitionBy("deptname").orderBy(desc("updatetime"))))
      .filter($"rank"===1)
      .select("data_code","deptname","data_code_tmp")
      .persist(StorageLevel.MEMORY_AND_DISK)

    //组织架构表
    val sys_dept=spark.sql(
      s"""
         |select * from dm_arss.dm_sys_dept_dtl_di
         |where inc_day='$dayvar1'
         |""".stripMargin)
      .withColumn("rank", row_number().over(Window.partitionBy("data_code").orderBy(desc("update_time"))))
      .filter($"rank"===1)
      .withColumn("data_code_tmp",$"data_code")
      .select("name","data_code_tmp")

    //结果关联
    val data_dept=device_deptcq.join(sys_dept,Seq("data_code_tmp"),"left")
      .select("data_code","deptname","name","data_code_tmp")

    //设备数
    val device_ct_df=device_dept.groupBy("deptname")
      .agg(count($"car_no") as "device_ct")

    //异常调整表
    val deviceadjust=spark.sql(
      s"""
         |select * from dm_gis.dm_deviceadjust_monitor_df
         |where inc_day='$dayvar1'
         |""".stripMargin)
      .withColumn("deptname",$"ctname")

    //异常3天数
    val exception_dtl3=spark.sql(
      s"""
         |select * from dm_gis.dm_cameralist_exception_dtl
         |where inc_day>='$dayvar3' and inc_day<='$dayvar1'
         |""".stripMargin)
      .filter($"position_text".isin("adas","dms")
        && $"org_name".isin("顺丰自营","冷运事业部","顺丰医药","顺丰航空车辆室内外定位监管项目")
        && ($"stability".cast("double")>0.2 || trim($"tag")==="")
      )
      .groupBy("car_no")
      .agg(countDistinct($"inc_day") as "exception_day3")


    val deviceadjust3=deviceadjust.join(exception_dtl3,Seq("car_no"),"left")
      .groupBy("deptname")
      .agg(count(when($"exception_day3"===3,$"car_no").otherwise(null)) as "lxexcpt_day3")

    //调整统计
    val deviceadjust_res=deviceadjust.groupBy("deptname")
      .agg(
        //摄像头异常数
        countDistinct($"car_no") as "cama_expct",
        //未反馈数
        countDistinct(when($"isadjust"==="0",$"car_no").otherwise(null)) as "noreply_ct",
        //调整失败数
        countDistinct(when($"isconfigadjust"==="1" && $"isadjustsuc"==="0" && $"ischecked"==="0",$"car_no").otherwise(null)) as "adjust_fal_ct",

        countDistinct($"car_no") as "all_ct",
        countDistinct(when($"isadjust"==="0",$"car_no").otherwise(null)) as "ct0",
        countDistinct(when($"issucess"==="0",$"car_no").otherwise(null)) as "ct1",
        countDistinct(when($"isconfigadjust"==="0",$"car_no").otherwise(null)) as "ct2",
        countDistinct(when($"isadjustsuc"==="0",$"car_no").otherwise(null)) as "ct3",
        countDistinct(when($"ischecked"==="0",$"car_no").otherwise(null)) as "ct4",
        countDistinct(when($"isnoadjust"==="0",$"car_no").otherwise(null)) as "ct5"

      )
      //调整数
      .withColumn("adjust_ct",$"all_ct"-$"ct0")
      //调整成功数
      .withColumn("adjustsucc_ct",$"all_ct"-$"ct1")
      //确认调整数
      .withColumn("adjustconf_ct",$"all_ct"-$"ct2")
      //确认调整成功数
      .withColumn("adjustconfsucc_ct",$"all_ct"-$"ct3")
      //确认我已核实数
      .withColumn("confcheck_ct",$"all_ct"-$"ct4")
      //无法调整数
      .withColumn("noadjust_ct",$"all_ct"-$"ct5")

    //不在线设备数
    val offline_ct_df=spark.sql(
      s"""
         |select *,carno as car_no from dm_gis.dm_dwd_device_day
         |where inc_day='$dayvar1'
         |""".stripMargin)
      .withColumn("data_code_tmp",$"datacode".substr(1,8))
      .filter($"data_code_tmp".isin("10001004","10001010","10001011","10001120"))
      .withColumn("deptname",$"ctname")
      .groupBy("deptname")
      .agg(count(when($"onlinetime".isNull || trim($"onlinetime")==="",$"car_no").otherwise(null)) as "offline_ct")

    //结果关联
    val data_result=data_dept.join(device_ct_df,Seq("deptname"),"left")
      .join(deviceadjust_res,Seq("deptname"),"left")
      .join(offline_ct_df,Seq("deptname"),"left")
      .join(deviceadjust3,Seq("deptname"),"left")
      //摄像头异常率
      .withColumn("cama_expct_pert",round($"cama_expct"/$"device_ct",6))
      //设备在线率
      .withColumn("online_pert",round(($"device_ct"-$"offline_ct")/$"device_ct",6))
      //反馈率
      .withColumn("adjust_ct_pert",round($"adjust_ct"/$"cama_expct",6))
      //反馈成功率
      .withColumn("adjustconfsucc_ct_pert",round($"adjustconfsucc_ct"/$"adjustconf_ct",6))
      //设备异常数
      .withColumn("device_expct",$"noreply_ct"+$"adjust_fal_ct")
      //设备异常率
      .withColumn("device_expct_pert",round($"device_expct"/$"device_ct",6))
      .withColumn("inc_day",lit(dayvar1))
      //数据补0
      .withColumn("cama_expct",when($"cama_expct".isNull || trim($"cama_expct")==="",0).otherwise($"cama_expct"))
      .withColumn("device_expct",when($"device_expct".isNull || trim($"device_expct")==="",0).otherwise($"device_expct"))
      .withColumn("noreply_ct",when($"noreply_ct".isNull || trim($"noreply_ct")==="",0).otherwise($"noreply_ct"))
      .withColumn("adjust_fal_ct",when($"adjust_fal_ct".isNull || trim($"adjust_fal_ct")==="",0).otherwise($"adjust_fal_ct"))
      .withColumn("adjust_ct",when($"adjust_ct".isNull || trim($"adjust_ct")==="",0).otherwise($"adjust_ct"))
      .withColumn("adjustsucc_ct",when($"adjustsucc_ct".isNull || trim($"adjustsucc_ct")==="",0).otherwise($"adjustsucc_ct"))
      .withColumn("adjustconf_ct",when($"adjustconf_ct".isNull || trim($"adjustconf_ct")==="",0).otherwise($"adjustconf_ct"))
      .withColumn("adjustconfsucc_ct",when($"adjustconfsucc_ct".isNull || trim($"adjustconfsucc_ct")==="",0).otherwise($"adjustconfsucc_ct"))
      .withColumn("confcheck_ct",when($"confcheck_ct".isNull || trim($"confcheck_ct")==="",0).otherwise($"confcheck_ct"))
      .withColumn("noadjust_ct",when($"noadjust_ct".isNull || trim($"noadjust_ct")==="",0).otherwise($"noadjust_ct"))
      .withColumn("lxexcpt_day3",when($"lxexcpt_day3".isNull || trim($"lxexcpt_day3")==="",0).otherwise($"lxexcpt_day3"))
      .withColumn("cama_expct_pert",when($"cama_expct_pert".isNull || trim($"cama_expct_pert")==="",0.00).otherwise($"cama_expct_pert"))
      .withColumn("online_pert",when($"online_pert".isNull || trim($"online_pert")==="",0.00).otherwise($"online_pert"))
      .withColumn("adjust_ct_pert",when($"adjust_ct_pert".isNull || trim($"adjust_ct_pert")==="",0.00).otherwise($"adjust_ct_pert"))
      .withColumn("adjustconfsucc_ct_pert",when($"adjustconfsucc_ct_pert".isNull || trim($"adjustconfsucc_ct_pert")==="",0.00).otherwise($"adjustconfsucc_ct_pert"))
      .withColumn("device_expct_pert",when($"device_expct_pert".isNull || trim($"device_expct_pert")==="",0.00).otherwise($"device_expct_pert"))
      .withColumn("weekday",WeekDayFlag_udf($"inc_day"))
      .withColumn("cama_expct_pert_avg",lit(0.00))

    //结果汇总：全网
    val data_result2=data_result.withColumn("deptname",lit("全网"))
      .groupBy("name","deptname")
      .agg(
        sum($"device_ct") as "device_ct_tmp",
        sum($"cama_expct") as "cama_expct_tmp",
        sum($"offline_ct") as "offline_ct_tmp",
        sum($"device_expct") as "device_expct_tmp",
        sum($"noreply_ct") as "noreply_ct_tmp",
        sum($"adjust_fal_ct") as "adjust_fal_ct_tmp",
        sum($"adjust_ct") as "adjust_ct_tmp",
        sum($"adjustsucc_ct") as "adjustsucc_ct_tmp",
        sum($"adjustconf_ct") as "adjustconf_ct_tmp",
        sum($"adjustconfsucc_ct") as "adjustconfsucc_ct_tmp",
        sum($"confcheck_ct") as "confcheck_ct_tmp",
        sum($"noadjust_ct") as "noadjust_ct_tmp",
        sum($"lxexcpt_day3") as "lxexcpt_day3_tmp"
      )
      .withColumnRenamed("device_ct_tmp","device_ct")
      .withColumnRenamed("cama_expct_tmp","cama_expct")
      .withColumnRenamed("offline_ct_tmp","offline_ct")
      .withColumnRenamed("device_expct_tmp","device_expct")
      .withColumnRenamed("noreply_ct_tmp","noreply_ct")
      .withColumnRenamed("adjust_fal_ct_tmp","adjust_fal_ct")
      .withColumnRenamed("adjust_ct_tmp","adjust_ct")
      .withColumnRenamed("adjustsucc_ct_tmp","adjustsucc_ct")
      .withColumnRenamed("adjustconf_ct_tmp","adjustconf_ct")
      .withColumnRenamed("adjustconfsucc_ct_tmp","adjustconfsucc_ct")
      .withColumnRenamed("confcheck_ct_tmp","confcheck_ct")
      .withColumnRenamed("noadjust_ct_tmp","noadjust_ct")
      .withColumnRenamed("lxexcpt_day3_tmp","lxexcpt_day3")
      //摄像头异常率
      .withColumn("cama_expct_pert",round($"cama_expct"/$"device_ct",6))
      //设备在线率
      .withColumn("online_pert",round(($"device_ct"-$"offline_ct")/$"device_ct",6))
      //反馈率
      .withColumn("adjust_ct_pert",round($"adjust_ct"/$"cama_expct",6))
      //反馈成功率
      .withColumn("adjustconfsucc_ct_pert",round($"adjustconfsucc_ct"/$"adjustconf_ct",6))
      //设备异常率
      .withColumn("device_expct_pert",round($"device_expct"/$"device_ct",6))
      .withColumn("cama_expct_pert",when($"cama_expct_pert".isNull || trim($"cama_expct_pert")==="",0.00).otherwise($"cama_expct_pert"))
      .withColumn("online_pert",when($"online_pert".isNull || trim($"online_pert")==="",0.00).otherwise($"online_pert"))
      .withColumn("adjust_ct_pert",when($"adjust_ct_pert".isNull || trim($"adjust_ct_pert")==="",0.00).otherwise($"adjust_ct_pert"))
      .withColumn("adjustconfsucc_ct_pert",when($"adjustconfsucc_ct_pert".isNull || trim($"adjustconfsucc_ct_pert")==="",0.00).otherwise($"adjustconfsucc_ct_pert"))
      .withColumn("device_expct_pert",when($"device_expct_pert".isNull || trim($"device_expct_pert")==="",0.00).otherwise($"device_expct_pert"))
      .withColumn("inc_day",lit(dayvar1))
      .withColumn("weekday",WeekDayFlag_udf($"inc_day"))
      .withColumn("cama_expct_pert_avg",lit(0.00))

    //存储表
    val tb_cols = spark.sql("""select * from dm_gis.dm_device_health_day limit 0""").schema.map(_.name).map(col)

    //合并数据
    val data_result3=data_result.select(tb_cols:_*)
      .union(data_result2.select(tb_cols:_*))

    //获取过去六天数据
    val data_last6=spark.sql(
      s"""
        |select * from dm_gis.dm_device_health_day
        |where inc_day>='$dayvar4' and inc_day<='$dayvar1'
        |""".stripMargin)

    //合并计算摄像头异常率均值
    val data_last6_all=data_last6.select(tb_cols:_*)
      .union(data_result3.select(tb_cols:_*))
      .groupBy("name","deptname")
      .agg(
        avg($"cama_expct_pert") as "cama_expct_pert_avg_temp"
      )

    val data_result4=data_result3.join(data_last6_all,Seq("name","deptname"),"left")
      .withColumn("cama_expct_pert_avg",round($"cama_expct_pert_avg_temp",6))

    writeToHive(spark, data_result4.select(tb_cols:_*), Seq("inc_day"), "dm_gis.dm_device_health_day")

    spark.close()

  }
  //判断星期几
  def WeekDayFlag(inc_day: String): String = {

    val cal = Calendar.getInstance()
    val sdf = new SimpleDateFormat("yyyyMMdd")

    var dayForWeek = 0
    try {
      cal.setTime(sdf.parse(inc_day))
      val w = cal.get(Calendar.DAY_OF_WEEK) - 1
      if (cal.get(Calendar.DAY_OF_WEEK) == 1) {
        dayForWeek = 7
      } else {
        dayForWeek = cal.get(Calendar.DAY_OF_WEEK) - 1
      }
    } catch {
      case e: Exception => e.printStackTrace()
    }

    val daytype=if(dayForWeek==1){"星期一"}
    else if (dayForWeek==2){"星期二"}
    else if (dayForWeek==3){"星期三"}
    else if (dayForWeek==4){"星期四"}
    else if (dayForWeek==5){"星期五"}
    else if (dayForWeek==6){"星期六"}
    else if (dayForWeek==7){"星期日"}
    else if (dayForWeek==0){"星期日"}
    else {""}

    daytype

  }

  val WeekDayFlag_udf=udf(WeekDayFlag _)

}
