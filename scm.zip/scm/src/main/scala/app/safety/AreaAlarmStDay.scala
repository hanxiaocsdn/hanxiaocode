package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import utils.CommonTools.getdaysBeforeOrAfter
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

/**
 *需求名称：地区告警日报
 *需求描述：顺丰客户对地区进行安全管理，对地区维度有相关考核指标，为方便客户取数分析，监管地区安全情况，提高周报统计效率，需建立地区维度告警日报。
 *需求方：黄晓冰(01422522)
 *开发: 周勇(01390943)
 *任务创建时间：20230330
 *任务id：783632
 **/

object AreaAlarmStDay extends DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]) = {
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._
    //取跑数T-1日期
    val dayvar = args(0)
    //取跑数T-2日期，用于对比
    val dayvar1 = getdaysBeforeOrAfter(dayvar, -1)
    //昨天所在月份
    val monthvar = dayvar.substring(0,6)

    logger.error("接收输入变量dayvar:"+dayvar)
    logger.error("接收输入变量dayvar1:"+dayvar1)
    logger.error("接收输入变量monthvar:"+monthvar)

    //grd自营司机
    val grd_self_driver=spark.sql(
      s"""
         |select * from dm_tdsp.grd_self_driver_daily_detial
         |where inc_day='$dayvar'
         |""".stripMargin)
      //.filter($"type_level"==="3" && $"dept_name" =!= "香港區部" && $"emp_sub_group_name".isin("长期合同制","业务外包","平台用工"))
      .filter( $"emp_sub_group_name".isin("长期合同制","业务外包","平台用工"))
      .withColumn("dept_code",trim($"dept_code"))
      .withColumn("dept_name",trim($"dept_name"))
      .withColumn("area_name",trim($"area_name"))
      .groupBy( "dept_code")
      //当日出勤人数
      .agg(countDistinct(when($"status"==="1" && $"done_task_cnt" > 0 && $"is_work"==="1" &&
        $"emp_sub_group_name".isin("长期合同制","业务外包","平台用工"),$"emp_code").otherwise(null)) as "onwork_emps",
        //在职人数
        countDistinct(when($"status"==="1" ,$"emp_code").otherwise(null)) as "onposition_emps")

    //grd自营司机全量网点编码
    val grd_self_driver_code=spark.sql(
      s"""
         |select dept_code,type_name,area_type,biz_week,biz_date,area_name,dept_name,inc_day from dm_tdsp.grd_self_driver_daily_detial
         |where inc_day='$dayvar'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("dept_code","type_name","area_type","biz_week","biz_date","area_name","dept_name").orderBy(desc("inc_day"))))
      .filter($"rank"===1)
      .select("dept_code","type_name","area_type","biz_week","biz_date","area_name","dept_name")

    //告警日表按月汇总
    val Alarm_m_sql=s"""
                       |select *,substr(inc_day,1,6) inc_daya from dm_gis.alarm_marvin_meddle_day
                       |where substr(inc_day,1,6)='$monthvar'
                       |""".stripMargin

    val Alarm_m=spark.sql(Alarm_m_sql)
      .withColumn("dept_code",trim($"dept_code"))
      .groupBy( "dept_code")
      .agg(
        //本月累计违规人数
        countDistinct(when( $"d_alarm_ct" > 0 ,$"emp_code").otherwise(null)) as "m_alarm_emps",
        //本月累计违规次数
        sum(when($"d_alarm_ct" > 0  ,$"d_alarm_ct").otherwise(0)) as "m_alarm_cts",
        //本月累计疲劳高危人数
        countDistinct(when( $"d_alarm_tired_ct" > 0 ,$"emp_code").otherwise(null)) as "m_tiredalarm_emps",
        //本月累计疲劳高危次数
        sum(when($"d_alarm_tired_ct" > 0  ,$"d_alarm_tired_ct").otherwise(0)) as "m_tiredalarm_cts",
        //本月累计打电话告警人数
        countDistinct(when( $"d_alarm_mobile_ct" > 0 ,$"emp_code").otherwise(null)) as "m_mobilealarm_emps",
        //本月累计打电话告警次数
        sum(when($"d_alarm_mobile_ct" > 0  ,$"d_alarm_mobile_ct").otherwise(0)) as "m_mobilealarm_cts",
        //本月累计遮挡告警人数
        countDistinct(when( $"d_alarm_cama_ct" > 0 ,$"emp_code").otherwise(null)) as "m_camaalarm_emps",
        //本月累计遮挡告警次数
        sum(when($"d_alarm_cama_ct" > 0  ,$"d_alarm_cama_ct").otherwise(0)) as "m_camaalarm_cts"
      )

    //告警日表按日汇总T-1
    val Alarm_d=spark.sql(
      s"""
         |select * from dm_gis.alarm_marvin_meddle_day
         |where inc_day='$dayvar'
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))
      .groupBy( "dept_code")
      .agg(
        //当天累计疲劳高危次数
        sum(when($"d_alarm_tired_ct" > 0  ,$"d_alarm_tired_ct").otherwise(0)) as "d_tiredalarm_cts",
        //当天累计打电话告警次数
        sum(when($"d_alarm_mobile_ct" > 0  ,$"d_alarm_mobile_ct").otherwise(0)) as "d_mobilealarm_cts",
        //当天累计遮挡告警次数
        sum(when($"d_alarm_cama_ct" > 0  ,$"d_alarm_cama_ct").otherwise(0)) as "d_camaalarm_cts"
      )

    //告警日表按日汇总T-2
    val Alarm_d1=spark.sql(
      s"""
         |select * from dm_gis.alarm_marvin_meddle_day
         |where inc_day='$dayvar1'
         |""".stripMargin)
      .withColumn("dept_code",trim($"dept_code"))
      .groupBy( "dept_code")
      .agg(
        //当天累计疲劳高危次数
        sum(when($"d_alarm_tired_ct" > 0  ,$"d_alarm_tired_ct").otherwise(0)) as "d_tiredalarm_cts1",
        //当天累计打电话告警次数
        sum(when($"d_alarm_mobile_ct" > 0  ,$"d_alarm_mobile_ct").otherwise(0)) as "d_mobilealarm_cts1",
        //当天累计遮挡告警次数
        sum(when($"d_alarm_cama_ct" > 0  ,$"d_alarm_cama_ct").otherwise(0)) as "d_camaalarm_cts1"
      )

    //地区归属映射
    val area_sys=spark.sql(
      s"""
         |select data_code,code,name,update_time,
         |case when substr(data_code, 0, 8) = '10001004' then '顺丰自营'
         |     when substr(data_code, 0, 8) = '10001010' then '冷运事业部'
         |     when substr(data_code, 0, 8) = '10001011' then '顺丰医药'
         |     else '' end project_name,
         |date_add(next_day( concat(substr(inc_day, 0, 4),'-',substr(inc_day, 5, 2),'-',substr(inc_day,7, 2)),'MO'),-7) as monday,
         | concat(substr(inc_day, 0, 4),'-',substr(inc_day, 5, 2),'-',substr(inc_day,7, 2)) thisday
         |      from dm_arss.dm_sys_dept_dtl_di
         |where inc_day='$dayvar'
         |and substr(data_code, 0, 8) in ('10001004', '10001010', '10001011')
         |and length(trim(data_code)) = 16
         |""".stripMargin)
      .withColumn("data_code",trim($"data_code"))
      .withColumn("code",trim($"code"))
      .withColumn("name",trim($"name"))
      .withColumn("rank",row_number().over(Window.partitionBy("data_code","code","name").orderBy(desc("update_time"))))
      .filter($"rank"===1)
      .withColumn("id",area_id_udf($"code"))
      .withColumn("dept_code",$"code")
      .select("data_code","code","name","project_name","id","dept_code","monday","thisday")
      .join(grd_self_driver_code,Seq("dept_code"),"left")
      .withColumn("dept_name",when($"name".isNull || trim($"name")==="",$"dept_name").otherwise($"name"))


    //自营司机宽表
    val selfdriver=spark.sql(
      s"""
         |select * from dm_gis.dm_self_driver_dtl
         |where inc_day='$dayvar'
         |""".stripMargin).persist(StorageLevel.MEMORY_AND_DISK)

    //司机宽表指标统计汇总
    val selfdriver_data=selfdriver.groupBy("dept_code")
      .agg(
        //准疲劳人数_长期
        count(when($"is_tired_group"==="1" && $"emp_sub_group_name" === "长期合同制",1).otherwise(null)) as "tireddrivers_cq_cts",
        //准疲劳人数_平台
        count(when($"is_tired_group"==="1" && $"emp_sub_group_name" === "平台用工",1).otherwise(null)) as "tireddrivers_pt_cts",
        //准疲劳人数_外包
        count(when($"is_tired_group"==="1" && $"emp_sub_group_name" === "业务外包",1).otherwise(null)) as "tireddrivers_wb_cts",
        //连续出勤人数_长期
        count(when($"is_tired_expect"==="3" && $"emp_sub_group_name" === "长期合同制",1).otherwise(null)) as "lxworking_cq_cts",
        //连续出勤人数_平台
        count(when($"is_tired_expect"==="3" && $"emp_sub_group_name" === "平台用工",1).otherwise(null)) as "lxworking_pt_cts",
        //连续出勤人数_外包
        count(when($"is_tired_expect"==="3" && $"emp_sub_group_name" === "业务外包",1).otherwise(null)) as "lxworking_wb_cts",
        //长途准疲劳人数_长期
        count(when($"is_cttired_expect"==="1" && $"emp_sub_group_name" === "长期合同制",1).otherwise(null)) as "tireddrivers_far_cq_cts",
        //长途准疲劳人数_平台
        count(when($"is_cttired_expect"==="1" && $"emp_sub_group_name" === "平台用工",1).otherwise(null)) as "tireddrivers_far_pt_cts",
        //长途准疲劳人数_外包
        count(when($"is_cttired_expect"==="1" && $"emp_sub_group_name" === "业务外包",1).otherwise(null)) as "tireddrivers_far_wb_cts"
      )
      //准疲劳人数
      .withColumn("tireddrivers_cts",$"tireddrivers_cq_cts"+ $"tireddrivers_pt_cts"+$"tireddrivers_wb_cts")
      //连续出勤人数
      .withColumn("lxworking_cts",$"lxworking_cq_cts"+ $"lxworking_pt_cts"+$"lxworking_wb_cts")
      //长途准疲劳人数
      .withColumn("tireddrivers_far_cts",$"tireddrivers_far_cq_cts"+ $"tireddrivers_far_pt_cts"+$"tireddrivers_far_wb_cts")

    //结果汇总
    val tb_cols = spark.sql("""select * from dm_gis.alarm_area_static_day limit 0""").schema.map(_.name).map(col)
    val result=area_sys.join(grd_self_driver,Seq("dept_code"),"left")
      .join(Alarm_m,Seq("dept_code"),"left")
      //grd_self_driver.join(Alarm_m,Seq("dept_code"),"left")
      .join(Alarm_d,Seq("dept_code"),"left")
      .join(Alarm_d1,Seq("dept_code"),"left")
      .na.fill(0,Seq("d_tiredalarm_cts","d_mobilealarm_cts","d_camaalarm_cts","d_tiredalarm_cts1","d_mobilealarm_cts1","d_camaalarm_cts1"))
      //疲劳高危次数日环比
      .withColumn("d_tiredalarm_cts_pert",when($"d_tiredalarm_cts1"===0 && $"d_tiredalarm_cts">0,1.0000).
        otherwise(($"d_tiredalarm_cts"-$"d_tiredalarm_cts1")/$"d_tiredalarm_cts1"))
      .withColumn("d_tiredalarm_cts_pert",when($"d_tiredalarm_cts_pert".isNull || trim($"d_tiredalarm_cts_pert")==="","").otherwise(round($"d_tiredalarm_cts_pert",4)))
      //打电话次数日环比
      .withColumn("d_mobilealarm_cts_pert",when($"d_mobilealarm_cts1"===0 && $"d_mobilealarm_cts">0,1.0000).
        otherwise(($"d_mobilealarm_cts"-$"d_mobilealarm_cts1")/$"d_mobilealarm_cts1"))
      .withColumn("d_mobilealarm_cts_pert",when($"d_mobilealarm_cts_pert".isNull || trim($"d_mobilealarm_cts_pert")==="","").otherwise(round($"d_mobilealarm_cts_pert",4)))
      //遮挡次数日环比
      .withColumn("d_camaalarm_cts_pert",when($"d_camaalarm_cts1"===0 && $"d_camaalarm_cts">0,1.0000).
        otherwise(($"d_camaalarm_cts"-$"d_camaalarm_cts1")/$"d_camaalarm_cts1"))
      .withColumn("d_camaalarm_cts_pert",when($"d_camaalarm_cts_pert".isNull || trim($"d_camaalarm_cts_pert")==="","").otherwise(round($"d_camaalarm_cts_pert",4)))
      .withColumn("inc_day",lit(dayvar))
      //.join(area_sys,Seq("dept_code"),"left")
      .join(selfdriver_data,Seq("dept_code"),"left")
      //准疲劳占比
      .withColumn("tireddrivers_cts_pert",round($"tireddrivers_cts".cast("double")/$"onwork_emps".cast("double"),6))
      //连续出勤占比
      .withColumn("lxworking_cts_pert",round($"lxworking_cts".cast("double")/$"onwork_emps".cast("double"),6))
      //长途准疲劳占比
      .withColumn("tireddrivers_far_cts_pert",round($"tireddrivers_far_cts".cast("double")/$"onwork_emps".cast("double"),6))
      .na.fill(0,Seq("tireddrivers_cts","tireddrivers_cq_cts","tireddrivers_pt_cts","tireddrivers_wb_cts","lxworking_cts",
      "lxworking_cq_cts","lxworking_pt_cts","lxworking_wb_cts","tireddrivers_far_cts","tireddrivers_far_cq_cts"
      ,"tireddrivers_far_pt_cts","tireddrivers_far_wb_cts"))
      .na.fill(0,Seq("onwork_emps","onposition_emps","m_alarm_emps","m_alarm_cts","m_tiredalarm_emps","m_tiredalarm_cts","d_tiredalarm_cts","d_tiredalarm_cts_pert",
      "m_mobilealarm_emps","m_mobilealarm_cts","d_mobilealarm_cts","m_camaalarm_emps","m_camaalarm_cts","d_camaalarm_cts"))
      .withColumn("biz_week",$"monday")
      .withColumn("biz_date",$"thisday")
      .select(tb_cols:_*)

    //存储表
    writeToHive(spark, result, Seq("inc_day"), "dm_gis.alarm_area_static_day")

  }

  //地区id映射
  def area_id(dept_code:String): String ={
    val dept_code_a=dept_code.trim
    val dept_name_id=dept_code_a match{
      case "021Y" =>"1"
      case "755Y" =>"2"
      case "020Y" =>"3"
      case "010Y" =>"4"
      case "571Y" =>"5"
      case "512Y" =>"6"
      case "769Y" =>"7"
      case "532Y" =>"8"
      case "757Y" =>"9"
      case "574Y" =>"10"
      case "595Y" =>"11"
      case "510Y" =>"12"
      case "025Y" =>"13"
      case "577Y" =>"14"
      case "579Y" =>"15"
      case "022Y" =>"16"
      case "592Y" =>"17"
      case "591Y" =>"18"
      case "517Y" =>"19"
      case "513Y" =>"20"
      case "760Y" =>"21"
      case "752Y" =>"22"
      case "531Y" =>"23"
      case "311Y" =>"24"
      case "536Y" =>"25"
      case "316Y" =>"26"
      case "023Y" =>"27"
      case "027Y" =>"28"
      case "028Y" =>"29"
      case "371Y" =>"30"
      case "551Y" =>"31"
      case "731Y" =>"32"
      case "791Y" =>"33"
      case "024Y" =>"34"
      case "029Y" =>"35"
      case "871Y" =>"36"
      case "771Y" =>"37"
      case "451Y" =>"38"
      case "431Y" =>"39"
      case "351Y" =>"40"
      case "851Y" =>"41"
      case "931Y" =>"42"
      case "471Y" =>"43"
      case "898Y" =>"44"
      case "991Y" =>"45"
      case "111Y" =>"46"
      case "222Y" =>"47"
      case "300Y" =>"48"
      case "333Y" =>"49"
      case "555Y" =>"50"
      case "666Y" =>"51"
      case "700Y" =>"52"
      case "777Y" =>"53"
      case "888Y" =>"54"
      case "999Y" =>"55"
      case "P010LYB" =>"56"
      case "P311LYB" =>"57"
      case "P024LYB" =>"58"
      case "P411LYB" =>"59"
      case "P531LYB" =>"60"
      case "P532LYB" =>"61"
      case "P451LYB" =>"62"
      case "P022LYB" =>"63"
      case "P021LYB" =>"64"
      case "P025CDA" =>"65"
      case "P517LFA" =>"66"
      case "P519CKA" =>"67"
      case "P571LFC" =>"68"
      case "P551LYB" =>"69"
      case "P571LYB" =>"70"
      case "P574LYB" =>"71"
      case "P512LYB" =>"72"
      case "P025LYB" =>"73"
      case "P020LYB" =>"74"
      case "P752CKA" =>"75"
      case "P020CTA" =>"76"
      case "P769LYB" =>"77"
      case "P591LYB" =>"78"
      case "P592LYB" =>"79"
      case "P898LYB" =>"80"
      case "P757LYB" =>"81"
      case "P027LYB" =>"82"
      case "P371LYB" =>"83"
      case "P731LYB" =>"84"
      case "P028LYB" =>"85"
      case "P023LYB" =>"86"
      case "P029LYB" =>"87"
      case "P991LYB" =>"88"
      case "P891LYB" =>"89"
      case "M010CKA" =>"90"
      case "M024CKA" =>"91"
      case "M371CKA" =>"92"
      case "M531CKA" =>"93"
      case "M451CKA" =>"94"
      case "M351CKA" =>"95"
      case "M532CKA" =>"96"
      case "M022CKA" =>"97"
      case "M311CKA" =>"98"
      case "M431CKA" =>"99"
      case "M010CSA" =>"100"
      case "M027CKA" =>"101"
      case "M7311CKA" =>"102"
      case "M020CKA" =>"103"
      case "M755CKA" =>"104"
      case "M592CKA" =>"105"
      case "M791CKA" =>"106"
      case "M020CSA" =>"107"
      case "M021CKA" =>"108"
      case "M025CKA" =>"109"
      case "M551CKA" =>"110"
      case "M571CKA" =>"111"
      case "M025LKWA" =>"112"
      case "M523CKA" =>"113"
      case "M512CKA" =>"114"
      case "M028CKB" =>"115"
      case "M023CKA" =>"116"
      case "M029CKA" =>"117"
      case "M931CKA" =>"118"
      case "M871CKA" =>"119"
      case "M028CKA" =>"120"
      case "M991CKA" =>"121"
      case "M371CSA" =>"122"
      case "M431CSA" =>"123"
      case "M023CSA" =>"124"
      case dept_code_a =>dept_code_a
    }
    dept_name_id
  }

  val area_id_udf=udf(area_id _)





}
