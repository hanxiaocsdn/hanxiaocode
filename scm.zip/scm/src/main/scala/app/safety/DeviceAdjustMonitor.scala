package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import utils.CommonTools.getdaysBeforeOrAfter
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, collect_list, concat, concat_ws, count, desc, lit, lpad, regexp_replace, row_number, sort_array, trim, udf, when}

/**
 *需求名称：设备调整监控报表需求
 *需求描述：顺丰客户对地区进行安全管理，对地区维度有相关考核指标。此表为方便取出设备调整明细，监管地区安全情况，提高周报统计效率所建。
 *需求方：刘桓(01422529)
 *开发: 周勇(01390943)
 *任务创建时间：20230423
 *任务id：785126
 **/

object DeviceAdjustMonitor extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._

    val dayvar = args(0)
    val dayvar1 = getdaysBeforeOrAfter(dayvar, -1)
    val dayvar30 =getdaysBeforeOrAfter(dayvar, -35)
    logger.error("接收输入变量dayvar:"+dayvar)
    logger.error("接收输入变量dayvar1:"+dayvar1)
    logger.error("接收输入变量dayvar30:"+dayvar30)

    //获取cameralist表
    val camera_info=spark.sql(
      s"""
         |select imei,org_name,car_no,devicetype,position_text,type_text,event_time,tag
         |from dm_gis.dm_cameralist_exception_dtl
         |where inc_day='$dayvar1'
         |""".stripMargin)
      .filter($"position_text".isin("adas","dms") && $"org_name".isin("顺丰自营","冷运事业部","顺丰医药","顺丰航空车辆室内外定位监管项目")
        && trim($"tag")==="" && ($"stability".cast("double")>0.2 || trim($"stability")==="" || $"stability".isNull)
      )

    logger.error("camera_info的数据量:"+camera_info.count())

    //获取device_exception表
    val device_exception_info=spark.sql(
      s"""
         |select imei,ctname
         |from dm_gis.dm_device_exception_dtl
         |where inc_day='$dayvar1'
         |""".stripMargin)

    //获取log表
    val log_info=spark.sql(
      s"""
         |select imei,check_result,exception_place,create_date,system_check_result,camera_type
         |from dm_gis.dm_marvin_zt_device_selfcheck_log_log_di
         |where inc_day='$dayvar'
         |""".stripMargin)
      .withColumn("position_text",when($"camera_type"==="0","adas").when($"camera_type"==="1","dms").otherwise(""))
      .withColumn("create_date_tmp",regexp_replace($"create_date","-",""))
      .filter( $"create_date_tmp"===dayvar)

    //计算是否调整
    val log_info_isadjust=log_info.groupBy("imei","position_text")
      .agg(count($"imei") as "isadjust_ct")

    //计算是否确认调整
    val log_info_isconfigadjust=log_info.filter($"check_result"==="2")
      .groupBy("imei","position_text")
      .agg(count($"imei") as "isconfigadjust_ct")

    //计算是否调整成功
    val log_info_isadjustsuc=log_info.filter($"system_check_result"==="1")
      .groupBy("imei","position_text")
      .agg(count($"imei") as "isadjustsuc_ct")

    //计算是否我已核实
    val log_info_ischecked=log_info.filter($"check_result"==="4")
      .groupBy("imei","position_text")
      .agg(count($"imei") as "ischecked_ct")

    //计算是否无法调整
    val log_info_isnoadjust=log_info.filter($"check_result"==="3")
      .groupBy("imei","position_text")
      .agg(count($"imei") as "isnoadjust_ct")

    //连续异常天数
    val device_data_days30=spark.sql(
      s"""
         |select * from dm_gis.dm_cameralist_exception_dtl
         |where inc_day>='$dayvar30' and inc_day<='$dayvar1'
         |""".stripMargin)
      .withColumn("is_exist",when($"position_text".isNull || trim($"position_text")==="",0).otherwise(1))
      .withColumn("rank",row_number().over(Window.partitionBy("imei","position_text","inc_day").orderBy(desc("inc_day"))))
      .filter($"rank"==="1")
      .withColumn("rank1",row_number().over(Window.partitionBy("imei","position_text").orderBy(desc("inc_day"))))
      .withColumn("rank2",lpad($"rank1",8,"0"))
      .withColumn("daytype",concat($"rank2",lit("_"),$"inc_day",lit("_"),$"is_exist"))
      .groupBy("imei","position_text")
      .agg(concat_ws(";",sort_array(collect_list($"daytype"))) as "hebing")
      .withColumn("exceptiondays",countlx_udf($"hebing"))
      .withColumn("exceptiondays",when($"exceptiondays">30,30).otherwise($"exceptiondays"))

    val need_cols = spark.sql("""select * from dm_gis.dm_deviceadjust_monitor_df limit 0""").schema.map(_.name).map(col)
    //结果关联
    val data_result=camera_info.join(device_exception_info,Seq("imei"),"left")
      //是否调整
      .join(log_info_isadjust,Seq("imei","position_text"),"left")
      .withColumn("isadjust",when($"isadjust_ct".isNotNull && $"isadjust_ct">0,"1").otherwise("0"))
      //是否确认调整
      .join(log_info_isconfigadjust,Seq("imei","position_text"),"left")
      .withColumn("isconfigadjust",when($"isconfigadjust_ct".isNotNull && $"isconfigadjust_ct">0,"1").otherwise("0"))
      //是否调整成功
      .join(log_info_isadjustsuc,Seq("imei","position_text"),"left")
      .withColumn("isadjustsuc",when($"isadjustsuc_ct".isNotNull && $"isadjustsuc_ct">0,"1").otherwise("0"))
      //是否我已核实
      .join(log_info_ischecked,Seq("imei","position_text"),"left")
      .withColumn("ischecked",when($"ischecked_ct".isNotNull && $"ischecked_ct">0,"1").otherwise("0"))
      //是否无法调整
      .join(log_info_isnoadjust,Seq("imei","position_text"),"left")
      .withColumn("isnoadjust",when($"isnoadjust_ct".isNotNull && $"isnoadjust_ct">0,"1").otherwise("0"))
      //是否成功
      .withColumn("issucess",when($"isadjustsuc"==="1" || ($"isconfigadjust"==="1" && $"isadjustsuc"==="0" && $"ischecked"==="1"),"1").otherwise("0"))
      .join(device_data_days30,Seq("imei","position_text"),"left")
      //增加日期
      .withColumn("inc_day",lit(dayvar1))
    //存入正式表
    writeToHive(spark, data_result.select(need_cols: _*), Seq("inc_day"), "dm_gis.dm_deviceadjust_monitor_df")

  }

  //计算连续异常天数
  def countlx(x:String): Int = {
    val x_arr = x.split(";")
    val l = x_arr.length
    var i = 0
    var flag = 1
    if (l == 1) {
      //当长度只有1
      if (x_arr(i).split("_")(2) == "1") {
        i = i + 1
      }
      else {i = i}
    }
    else {
      //当长度大于1
      while (flag == 1 && i + 1 < l) {
        //同时判断日期和异常
        if (x_arr(i).split("_")(2) == "1" && x_arr(i + 1).split("_")(1) == getdaysBeforeOrAfter(x_arr(i).split("_")(1), -1)) {
          i = i + 1
          flag = 1
        }
        else flag = 0
      }
      //由于第一天一定不为空，所以加上第一天
      i=i+1
    }
    i
  }

  val countlx_udf=udf(countlx _)

}
