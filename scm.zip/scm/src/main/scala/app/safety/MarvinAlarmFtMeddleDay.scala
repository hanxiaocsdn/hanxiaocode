package app.safety


import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.TimeDef.getdaysBeforeOrAfter
/**
 **author:01390943 周勇
 **需求方：01422522 黄晓冰。历史需求方：ft80006475 高梅
 **description:自营丰图需干预明细日报表
 **任务id：664099
 **/

object MarvinAlarmFtMeddleDay  extends DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")
  def main(args:Array[String])= {
    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._
    //取跑数T-1日期
    val dayvar0 = args(0)
    //取跑数T-2日期，用于对比
    val dayvar1 = getdaysBeforeOrAfter(dayvar0, -1)
    //司机信息
    val self_driver=spark.sql(
      s"""
         | select data_code,name as org_name,dept_code,dept_name,driver_name,attribute6 as emp_code,alarm_time,
         | date_add(next_day(from_unixtime(unix_timestamp(inc_day,'yyyymmdd'),'yyyy-mm-dd'),'MO'),-7) as biz_week
         |from dm_gis_scm.dm_marvinmeddle_alarm_detail
         |WHERE  inc_day = '$dayvar0'
         |""".stripMargin)
      .withColumn("rank", row_number().over(Window.partitionBy("emp_code")
        .orderBy(desc("alarm_time"))))
      .filter($"rank"===1)
      .filter(trim($"emp_code") =!="" && trim($"emp_code").isNotNull)
      .drop("rank","alarm_time")

    // println("alarm_dtl0_result::::")
    //保存用于测试
    // spark.sql("drop table if exists default.alarm_self_driver")
    //self_driver.write.mode("overwrite").format("parquet").saveAsTable("default.alarm_self_driver")

    //需干预告警明细
    val alarm_dtl0=spark.sql(
      s"""
         |select *,attribute6 as emp_code from dm_gis.alarm_marvin_meddle_dtl
         |WHERE  inc_day = '$dayvar0'
         |""".stripMargin)


    val alarm_dtl0_result=alarm_dtl0.groupBy("emp_code")
      .agg(
        //疲劳高危告警量
        count(when(($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")) && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "d_alarm_tired_ct",
        //疲劳高危申诉量
        count(when(($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")) && $"appeal_status".isNotNull && trim($"appeal_status")=!="",1).
          otherwise(null)) as "d_apeal_tired_ct",
        //疲劳高危申诉通过量
        count(when(($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")) && $"appeal_status".isin("1","4"),1).
          otherwise(null)) as "d_apeal_tired_subct",

        //打电话告警量
        count(when($"alarm_name"==="打电话"  && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "d_alarm_mobile_ct",
        //打电话申诉量
        count(when($"alarm_name"==="打电话" && $"appeal_status".isNotNull && trim($"appeal_status")=!="",1).
          otherwise(null)) as "d_apeal_mobile_ct",
        //打电话申诉通过量
        count(when($"alarm_name"==="打电话" && $"appeal_status".isin("1","4"),1).
          otherwise(null)) as "d_apeal_mobile_subct",

        //摄像头告警量
        count(when($"alarm_name"==="摄像头遮挡"  && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "d_alarm_cama_ct",
        //摄像头申诉量
        count(when($"alarm_name"==="摄像头遮挡" && $"appeal_status".isNotNull && trim($"appeal_status")=!="",1).
          otherwise(null)) as "d_apeal_cama_ct",
        //摄像头申诉通过量
        count(when($"alarm_name"==="摄像头遮挡" && $"appeal_status".isin("1","4"),1).
          otherwise(null)) as "d_apeal_cama_subct"
      )
      //告警量
      .withColumn("d_alarm_ct",$"d_alarm_tired_ct"+$"d_alarm_mobile_ct"+$"d_alarm_cama_ct")

    //println("alarm_dtl0_result::::")
    //保存用于测试
    //spark.sql("drop table if exists default.alarm_dtl0_result")
    //alarm_dtl0_result.write.mode("overwrite").format("parquet").saveAsTable("default.alarm_dtl0_result")

    val alarm_dtl1=spark.sql(
      s"""
         |select *,attribute6 as emp_code from dm_gis.alarm_marvin_meddle_dtl
         |WHERE  inc_day = '$dayvar1'
         |""".stripMargin)

    val alarm_dtl1_result=alarm_dtl1.groupBy("emp_code")
      .agg(
        //疲劳高危告警量
        count(when(($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")) && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "d_alarm_tired_ct1",
        //疲劳高危申诉量
        count(when(($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")) && $"appeal_status".isNotNull && trim($"appeal_status")=!="",1).
          otherwise(null)) as "d_apeal_tired_ct1",
        //疲劳高危申诉通过量
        count(when(($"risk_level"==="高" || $"defend_status".isin("处理中","已处理")) && $"appeal_status".isin("1","4"),1).
          otherwise(null)) as "d_apeal_tired_subct1",

        //打电话告警量
        count(when($"alarm_name"==="打电话"  && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "d_alarm_mobile_ct1",
        //打电话申诉量
        count(when($"alarm_name"==="打电话" && $"appeal_status".isNotNull && trim($"appeal_status")=!="",1).
          otherwise(null)) as "d_apeal_mobile_ct1",
        //打电话申诉通过量
        count(when($"alarm_name"==="打电话" && $"appeal_status".isin("1","4"),1).
          otherwise(null)) as "d_apeal_mobile_subct1",

        //摄像头告警量
        count(when($"alarm_name"==="摄像头遮挡"  && $"isgz"==="是" && $"is_gzcar"==="是",1).
          otherwise(null)) as "d_alarm_cama_ct1",
        //摄像头申诉量
        count(when($"alarm_name"==="摄像头遮挡" && $"appeal_status".isNotNull && trim($"appeal_status")=!="",1).
          otherwise(null)) as "d_apeal_cama_ct1",
        //摄像头申诉通过量
        count(when($"alarm_name"==="摄像头遮挡" && $"appeal_status".isin("1","4"),1).
          otherwise(null)) as "d_apeal_cama_subct1"
      )
      //告警量
      .withColumn("d_alarm_ct1",$"d_alarm_tired_ct1"+$"d_alarm_mobile_ct1"+$"d_alarm_cama_ct1")


    // println("alarm_dtl1_result::::")
    //保存用于测试
    //spark.sql("drop table if exists default.alarm_dtl1_result")
    //alarm_dtl1_result.write.mode("overwrite").format("parquet").saveAsTable("default.alarm_dtl1_result")

    //数据合并
    val tb_cols = spark.sql("""select * from dm_gis.alarm_marvin_meddle_day limit 0""").schema.map(_.name).map(col)
    val alarm_result=self_driver.join(alarm_dtl0_result,Seq("emp_code"),"left")
      .join(alarm_dtl1_result,Seq("emp_code"),"left")

      .withColumn("d_alarm_ct_pert",when($"d_alarm_ct".isNull || trim($"d_alarm_ct")==="",0).otherwise($"d_alarm_ct")-
        when($"d_alarm_ct1".isNull || trim($"d_alarm_ct1")==="",0).otherwise($"d_alarm_ct1"))

      .withColumn("d_alarm_tired_ct_pert",when($"d_alarm_tired_ct".isNull || trim($"d_alarm_tired_ct")==="",0).otherwise($"d_alarm_tired_ct")-
        when($"d_alarm_tired_ct1".isNull || trim($"d_alarm_tired_ct1")==="",0).otherwise($"d_alarm_tired_ct1"))

      .withColumn("d_alarm_mobile_ct_pert",when($"d_alarm_mobile_ct".isNull || trim($"d_alarm_mobile_ct")==="",0).otherwise($"d_alarm_mobile_ct")-
        when($"d_alarm_mobile_ct1".isNull || trim($"d_alarm_mobile_ct1")==="",0).otherwise($"d_alarm_mobile_ct1"))

      .withColumn("d_alarm_cama_ct_pert",when($"d_alarm_cama_ct".isNull || trim($"d_alarm_cama_ct")==="",0).otherwise($"d_alarm_cama_ct")-
        when($"d_alarm_cama_ct1".isNull || trim($"d_alarm_cama_ct1")==="",0).otherwise($"d_alarm_cama_ct1"))
      .withColumn("inc_day",lit(dayvar0))
      .select(tb_cols: _*)
    //存储表
    writeToHive(spark, alarm_result, Seq("inc_day"), "dm_gis.alarm_marvin_meddle_day")

  }

}
