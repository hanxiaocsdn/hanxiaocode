package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.expressions.Window

/**
 *需求名称：司机画像月结表
 *需求描述：为了降低司机驾驶风险，增加各项监控指标。
 *需求方：算法对接：01374048王珊珊，产品：ft80006475高梅
 *开发: 周勇(01390943)
 *任务创建时间：20221023
 *任务id：785134、785135
 **/

object DriverLabelMonth  extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._

    //获取传入参数日期
    val input_inc_day1=args(0)
    val input_inc_day2=args(1)
    val input_inc_month=args(2)

    logger.error("参数0："+input_inc_day1)
    logger.error("参数1："+input_inc_day2)
    logger.error("参数2："+input_inc_month)
    //******************读取任务表信息
    val task_sql=
      s"""select task_id,actual_depart_tm,main_driver_account,nvl(gis_distance,line_distance) new_distance from dm_grd.grd_new_task_detail
         |where inc_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day1}','yyyymmdd'),'yyyy-mm-dd'),2),'-','')
         |and inc_day<='${input_inc_day2}'""".stripMargin
    val task_info=spark.sql(task_sql)
      .withColumn("actual_depart_day",regexp_replace(substring(col("actual_depart_tm"),0,10),"-",""))
      .filter(s"state='6' and actual_depart_day>='${input_inc_day1}' and actual_depart_day<='${input_inc_day2}' and new_distance>0.01")
      .filter("main_driver_account is not null and main_driver_account !=''")
      .persist(StorageLevel.MEMORY_AND_DISK)
    //******************月度告警
    val alarm_sql=s"""
                     |select alarm_id,alarm_time,lng,lat,ft_p_type,ft_sub_type,p_type_r,sub_type_r,attribute7,speed,is_meddle,tf_flag,
                     |regexp_replace(substr(alarm_time,0,10),'-','') alarm_day,risk_level,defend_status,attribute6,
                     |concat(ft_p_type,'|',ft_sub_type,'|',p_type_r,'|',sub_type_r) hb
                     |from dm_arss.dm_alarm_detail_dtl_di
                     |where inc_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day1}','yyyymmdd'),'yyyy-mm-dd'),2),'-','')
                     |and inc_day<=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day2}','yyyymmdd'),'yyyy-mm-dd'),-1),'-','')
                     |""".stripMargin
    val alarm_info=spark.sql(alarm_sql)
      .filter("attribute7 is not null and attribute7 !=''")
      .persist(StorageLevel.MEMORY_AND_DISK)


    val task_alarm_detail=alarm_info.join(task_info,alarm_info("attribute7")===task_info("task_id"),"inner")
      .withColumn("main_driver_account",when($"attribute6".isNotNull && trim($"attribute6")=!="",  $"attribute6" ).otherwise($"main_driver_account"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    //*************告警规则配置表
    val alarm_rule_sql=s"""select alarm_p_name,alarm_sub_name,concat(alarm_p_type,'|',alarm_sub_type,'|',p_type,'|',sub_type) hb_name,sub_name
                          |from dm_gis_scm.dm_tc_alarm_rule
                          |where inc_day=${input_inc_day2}
                          |""".stripMargin
    val alarm_rule_info=spark.sql(alarm_rule_sql).filter("del_status='0'").persist(StorageLevel.MEMORY_AND_DISK)

    //告警申诉,剔除1和4申诉成功的
    val alarm_appeal=spark.sql(s"""select alarm_id,alarm_id as alarm_ida from dm_gis.dm_alarm_appeal
                                  |where inc_day='${input_inc_day2}' and appeal_status in ('1','4')""".stripMargin)
    //关联结果
    val task_alarm_rule_detail=task_alarm_detail.join(alarm_rule_info,task_alarm_detail("hb")===alarm_rule_info("hb_name"),"left")
      .join(alarm_appeal,Seq("alarm_id"),"left")
      .filter($"alarm_p_name".isin ("DMS","HOD","ADAS","过激驾驶"))
      .withColumn("is_appeal",when($"alarm_ida".isNotNull,1).otherwise(0))
      .withColumn("is_need",when($"sub_name"==="打电话" && $"is_meddle"===1 &&  $"tf_flag"===1 && $"is_appeal"===0,1).
        when($"sub_name"==="打电话" ,0).
        when($"sub_name"==="摄像头遮挡" && $"is_meddle"===1 &&  $"tf_flag"===1 && $"is_appeal"===0,1).
        when($"sub_name"==="摄像头遮挡" ,0).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") && $"is_meddle"===1 &&  $"tf_flag"===1 && $"risk_level"==="1",1).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") && $"is_meddle"===1 &&  $"tf_flag"===1 && $"defend_status"==="2",1).
        when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼") ,0).
        when($"alarm_p_name"==="ADAS" ,1).
        when($"alarm_p_name"==="过激驾驶" ,1).
        when($"alarm_p_name"==="DMS" && $"tf_flag"===1,1).
        when($"alarm_p_name"==="HOD" && $"tf_flag"===1,1).
        otherwise(0)
      )
      .persist(StorageLevel.MEMORY_AND_DISK)
//
//    保存用于测试
//    logger.error("存储临时表：关联明细表")
//      spark.sql("drop table if exists default.tempzy20230110x1")
//      task_alarm_rule_detail.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20230110x1")

    //*********汇总月度告警指标
    val month_index1=task_alarm_rule_detail.filter($"is_need"===1)
      .groupBy("main_driver_account")
      .agg(
        count(when($"alarm_p_name".isin ("DMS","HOD"),1).otherwise(null)).as("driver_violations_all"),
        count(when($"alarm_p_name"==="DMS",1).otherwise(null)).as("driver_violations_dms_all"),
        count(when($"alarm_p_name"==="HOD",1).otherwise(null)).as("driver_violations_hod_all"),
        count(when($"sub_name".isin ("疲劳","打哈欠","闭眼"),1).otherwise(null)).as("driver_violations_emerg_all"),
        count(when($"alarm_p_name".isin ("ADAS","过激驾驶"),1).otherwise(null)).as("driver_habit_all"),
        count(when($"alarm_p_name"==="ADAS",1).otherwise(null)).as("driver_habit_adas_all"),
        count(when($"alarm_p_name"==="过激驾驶",1).otherwise(null)).as("driver_habit_hhh_all"),
        //打电话 + 摄像头遮挡 + 疲劳（疲劳/闭眼/云端算法-闭眼） + 吸烟
        count(when($"sub_name".isin("吸烟","打电话","摄像头遮挡","云端算法-疲劳（闭眼）","疲劳","闭眼"),1).otherwise(null)).as("driver_violations_follow_all"),
        count(when($"sub_name"==="吸烟",1).otherwise(null)).as("driver_violations_smoking_all"),
        count(when($"sub_name"==="打电话",1).otherwise(null)).as("driver_violations_phone_all"),
        count(when($"sub_name"==="摄像头遮挡",1).otherwise(null)).as("driver_violations_camera_all"),
        count(when($"sub_name".isin("云端算法-疲劳（闭眼）","疲劳","闭眼"),1).otherwise(null)).as("driver_violations_fatigue_all"),
        //分心驾驶（分心驾驶/分心驾驶抬头/分心驾驶低头） + 车道偏离 + 车距过近 + 急加速 + 急减速 + 超速 (超速/超限速告警)+ 路口未减速
        count(when($"sub_name".isin("分心驾驶","分心驾驶抬头","分心驾驶低头","车道偏离","车距过近","急加速","急减速","超速"),1).otherwise(null)).as("driver_driving_follow_all"),
        count(when($"sub_name".isin("分心驾驶","分心驾驶抬头","分心驾驶低头"),1).otherwise(null)).as("driver_habit_distracted_all"),
        count(when($"sub_name"==="车道偏离",1).otherwise(null)).as("driver_habit_laned_eparture_all"),
        count(when($"sub_name"==="车距过近",1).otherwise(null)).as("driver_habit_close_distance_all"),
        count(when($"sub_name"==="急加速",1).otherwise(null)).as("driver_habit_rapid_acceleration_all"),
        count(when($"sub_name"==="急减速",1).otherwise(null)).as("driver_habit_sharp_deceleration_all"),
        count(when($"sub_name"==="超速",1).otherwise(null)).as("driver_habit_speeding_all")
      ).withColumn("driver_habit_intersection_speeding_all",lit(0))
      .persist(StorageLevel.MEMORY_AND_DISK)

    //违规行为平均时速
    val month_index1_a=task_alarm_rule_detail.filter($"alarm_p_name".isin ("DMS","HOD"))
      .groupBy("main_driver_account")
      .agg(
        avg(when($"speed".isNull || trim($"speed")==="",0.0).otherwise($"speed")).as("driver_violations_all_speed")
      )

    //习惯行为平均时速
    val month_index1_b=task_alarm_rule_detail.filter($"alarm_p_name".isin ("ADAS","过激驾驶"))
      .groupBy("main_driver_account")
      .agg(
        avg(when($"speed".isNull || trim($"speed")==="",0.0).otherwise($"speed")).as("driver_habit_all_speed")
      )

    //培训考试指标
    val sql_sdy=s"""|select *,regexp_replace(substr(exam_start_time,0,10),'-','') exam_day
                    |from dm_gis_scm.dm_scm_driver_exam
                    |where month<=substr(${input_inc_day2},0,6)
                    |and month>=substr(${input_inc_day1},0,6)
                    |and regexp_replace(substr(exam_start_time,0,10),'-','')>=${input_inc_day1}
                    |and regexp_replace(substr(exam_start_time,0,10),'-','')<=${input_inc_day2}
                    |""".stripMargin


    val sdy_index=spark.sql(sql_sdy). groupBy("emp_code")
      .agg(count($"emp_code").as("driver_study_all"),
        count(when($"emp_exam_state"===1,1).otherwise(null)).as("driver_study_pass")
      )
      .withColumn("driver_study_rate",$"driver_study_pass"/$"driver_study_all" )
      .persist(StorageLevel.MEMORY_AND_DISK)

    //月度事故数据，统计最近半年
    val accidt_sql=s"""|select *,concat('"rank_',rank,'":"',ycdj,'"') accident_level,
                       |concat('"rank_',rank,'":',0) accident_amt from
                       |(
                       |select *,row_number() over(partition by emp_code order by data_day desc,data_time desc) rank
                       |from dm_gis_scm.dm_accident_import
                       |where data_day<='${input_inc_day2}'
                       |and data_day>=regexp_replace(date_sub(from_unixtime(unix_timestamp('${input_inc_day2}','yyyymmdd'),'yyyy-mm-dd'),183),'-','')
                       |) x""".stripMargin

    val accidt_index=spark.sql(accidt_sql)
      .withColumn("rank",row_number().over(Window.partitionBy("emp_code").orderBy(desc("data_day"),desc("data_time")) ))
      .withColumn("accident_level",concat(lit("\"rank_"),$"rank",lit("\":\""),$"ycdj",lit("\"")))
      .withColumn("accident_amt",concat(lit("\"rank_"),$"rank",lit("\":"),lit(0)))
      .groupBy("emp_code")
      .agg(count($"emp_code") as("driver_accident_all"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"accident_level"))),lit("}")) as("driver_accident_type"),
        concat(lit("{"),concat_ws(",",sort_array(collect_list($"accident_amt"))),lit("}")) as("driver_insturance_all")
      )
      .persist(StorageLevel.MEMORY_AND_DISK)

    //车队信息
    val motorcade_info=spark.sql(s"""SELECT t1.dept_id,t1.motorcade_code,t2.motorcade_name
                                    |FROM (
                                    |select * from (
                                    |SELECT motorcade_code, dept_id, ROW_NUMBER() OVER (PARTITION BY dept_id ORDER BY create_tm DESC ) AS rn
                                    |FROM ods_shiva_ground.ts_motorcade_dept
                                    |WHERE inc_day= '${input_inc_day2}') x where rn = 1
                                    |) t1
                                    |LEFT JOIN
                                    |(SELECT motorcade_code, motorcade_name from ods_shiva_ground.ts_motorcadeinfo
                                    |WHERE inc_day= '${input_inc_day2}'
                                    |) t2 ON t1.motorcade_code = t2.motorcade_code""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //司机基础信息表
    val driver_basic=spark.sql(s"""select emp_code,name as driver_name,dept_id, dept_code,dept_name,
                                  |mobile_phone as driver_phone	,nric_id as driver_id_card	,
                                  |case when gender='1' then '男' when gender='2' then '女' else '' end as driver_gender	,
                                  |age as driver_age	,native_place as driver_place	,
                                  |case when education ='1' then '本科'
                                  | when education ='2' then '大专'
                                  | when education ='3' then '中专'
                                  | when education ='4' then '高中'
                                  | when education ='5' then '初中'
                                  | when education ='6' then '小学'
                                  | else '' end as driver_edu	,---教育程度
                                  |case when nationality='1' then '汉族'
                                  |when nationality='2' then '回族'
                                  |when nationality='3' then '藏族'
                                  |when nationality='4' then '苗族'
                                  |when nationality='5' then '彝族'
                                  |when nationality='6' then '壮族'
                                  |when nationality='7' then '满族'
                                  |when nationality='8' then '其他'
                                  |else '' end as driver_nation  ,---民族
                                  |case when character_type='1' then '多血质型'
                                  |when character_type='2' then '胆汁质型'
                                  |when character_type='3' then '粘液质型'
                                  |when character_type='4' then '抑郁质型'
                                  |else '' end as driver_nature	,---司机性格
                                  |dept_name as driver_org	,---所属机构
                                  |medical_exam_dt as driver_test_date	,---体检日期
                                  |driving_age as driver_experience	,---驾龄
                                  |quasi_driving_type as driver_license	,---驾照类型
                                  |urgent_contact as driver_emergency_contact	,---紧急联系人
                                  |urgent_contact_number as driver_emergency_phone	,---紧急联系方式
                                  |case when regexp_replace(substr(driver_license_deadline,0,10),'-','')>=${input_inc_day2} then 1 else 0 end driver_license_state	---驾驶证是否有效,1有效、0无效
                                  | from dm_gis_scm.dm_scm_driver
                                  |where inc_day=${input_inc_day2} and emp_code is not null and emp_code !=''  and driver_type='1' """.stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //员工信息表
    val empdf=spark.sql(s"""select emp_code,case when cancel_flag='Y' then '离职' else '在职' end driver_state
                           |from dim.dim_emp_info_df where inc_day=${input_inc_day2}""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //---日结表
    val daydf=spark.sql(s"""select driver_code,driver_safe_mileage as driver_safe_mileage,
                           |driver_safe_mark as driver_safe_mark from dm_gis_scm.dm_driver_label_day
                           |where inc_day=${input_inc_day2}""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //网点明细表
    val dept_df=spark.sql("""select dept_id,area_code,area_name,create_tm
                          from dim.dim_department""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("dept_id").orderBy(desc("create_tm")) ))
      .filter("rank=1")
      .drop("create_tm","rank")
      .persist(StorageLevel.MEMORY_AND_DISK)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis_scm.dm_driver_label_month limit 0""").schema.map(_.name).map(col)

    //---月结表汇总
    val resultdf=daydf.join(driver_basic,daydf("driver_code")===driver_basic("emp_code"),"left")
      .drop(driver_basic("emp_code"))
      .join(empdf,lpad(daydf("driver_code"),8,"0")===lpad(empdf("emp_code"),8,"0"),"left")
      .drop(empdf("emp_code"))
      .join(month_index1,daydf("driver_code")===month_index1("main_driver_account"),"left")
      .drop(month_index1("main_driver_account"))
      .join(accidt_index,daydf("driver_code")===accidt_index("emp_code"),"left")
      .drop(accidt_index("emp_code"))
      .join(sdy_index,daydf("driver_code")===sdy_index("emp_code"),"left")
      .drop(sdy_index("emp_code"))
      .join(motorcade_info,driver_basic("dept_id")===motorcade_info("dept_id"),"left")
      .drop(motorcade_info("dept_id"))
      .join(dept_df,driver_basic("dept_id")===dept_df("dept_id"),"left")
      .drop(dept_df("dept_id"))
      .join(month_index1_a,daydf("driver_code")===month_index1_a("main_driver_account"),"left")
      .drop(month_index1_a("main_driver_account"))
      .join(month_index1_b,daydf("driver_code")===month_index1_b("main_driver_account"),"left")
      .drop(month_index1_b("main_driver_account"))
      .withColumn("driver_state_new",when($"driver_state" === null ,"离职").otherwise($"driver_state"))
      .withColumn("driver_state",$"driver_state_new")
      .withColumn("driver_style",lit(""))
      .withColumn("driver_month_score",lit(""))
      .withColumn("month_statistics",lit(""))
      .withColumn("month_dictionary",lit(""))
      .withColumn("driver_month_statistics",lit(""))
      .withColumn("driver_month_score_all",lit(""))
      .withColumn("driver_violations_score",lit(""))
      .withColumn("driver_habit_score",lit(""))
      .withColumn("driver_accident_score",lit(""))
      .withColumn("driver_safety_score",lit(""))
      .withColumn("driver_meeting_all",lit(""))
      .withColumn("driver_meeting_ct",lit(""))
      .withColumn("driver_meeting_state",lit(""))
      .withColumn("driver_safe_mileage_score",lit(""))
      .withColumn("score_dictionary",lit(""))
      .withColumn("data_start",lit(s"${input_inc_day1}"))
      .withColumn("data_end",lit(s"${input_inc_day2}"))
      .withColumn("inc_month",lit(s"${input_inc_month}"))
      .withColumn("driver_violations_all_speed",when($"driver_violations_follow_all">0 && ($"driver_violations_all_speed".isNull ||trim($"driver_violations_all_speed")===""),0)
        .otherwise($"driver_violations_all_speed"))
      .withColumn("driver_habit_all_speed",when($"driver_driving_follow_all">0 && ($"driver_habit_all_speed".isNull ||trim($"driver_habit_all_speed")===""),0)
        .otherwise($"driver_habit_all_speed"))
      .select(table_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //数据存dm表
    writeToHive(spark, resultdf, Seq("inc_month"), "dm_gis_scm.dm_driver_label_month")
    //writeToHive(spark, resultdf, Seq("inc_month"), "dm_gis.dm_driver_label_month_aaa")



    spark.close()
  }



}
