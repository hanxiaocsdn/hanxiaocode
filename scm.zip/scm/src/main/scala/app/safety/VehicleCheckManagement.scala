package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{asc, col, desc, lit, regexp_replace, row_number, trim, when}
import utils.CommonTools.getdaysBeforeOrAfter

/**
 *需求名称：地区车管车辆检查数据接入
 *需求描述：顺丰车辆在执行任务前需进行车辆安全检查，但是每天任务量大，车管检查工作是否到位没有真实的考核依据；所以总部决定定期下到地区网点抽查任务车辆检查情况，考察地区车管是否将工作落实到位
 *需求方：01425432 马一越
 *开发: 01390943 周勇
 *任务创建时间：20230830
 *任务id：799371
 **/

object VehicleCheckManagement extends DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取传入参数日期:昨日日期
    val dayvar1 = args(0)
    val dayvar2 = args(1)
    val dayvar3 = getdaysBeforeOrAfter(dayvar2, -30)
    logger.error("dayvar1输入：" + dayvar1)
    logger.error("dayvar2输入：" + dayvar2)
    logger.error("dayvar3输入：" + dayvar3)

    //获取GRD_车辆检查执行率表
    val checkt_data=spark.sql(
      s"""
        |select
        |task_id,
        |area_name,
        |area_code,
        |vehicle_serial,
        |check_date,
        |check_type,
        |plan_depart_tm1
        |from dm_tdsp.bie_grd_013_check
        |where substr(plan_depart_tm1,1,7)='$dayvar1' and check_type='已检'
        |""".stripMargin)
      .withColumn("check_date_flag",when($"check_date".isNotNull && trim($"check_date") =!="",1).otherwise(2))

    //获取GRD任务数据
    val grd_task=spark.sql(
      s"""
        |select task_id,actual_depart_tm
        |from dm_grd.grd_new_task_detail
        |where inc_day>='$dayvar3' and inc_day<='$dayvar2' and substr(actual_depart_tm,1,7)='$dayvar1'
        |""".stripMargin)

    //关联过滤
    val res_data=checkt_data.join(grd_task,Seq("task_id"))
      .withColumn("rank",row_number().over(Window.partitionBy("area_code","vehicle_serial").orderBy(asc("check_date_flag"),desc("check_date")) ))
      .filter($"rank"===1)
      .withColumn("inc_month",lit(dayvar1.replace("-","")))
      .coalesce(10)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_bie_grd_check limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,res_data.select(table_cols: _*), Seq("inc_month"), "dm_gis.dm_bie_grd_check")

    logger.error(">>>>任务已完成！")
    spark.close()

  }
}
