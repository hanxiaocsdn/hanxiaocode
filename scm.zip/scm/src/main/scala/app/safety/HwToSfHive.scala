package app.safety

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkUtils
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, desc, lit, row_number}
import org.apache.spark.storage.StorageLevel
import utils.CommonTools.getdaysBeforeOrAfter
import scala.collection.JavaConversions._

import java.util

/**
 *需求名称：华为云护航数据同步至顺丰云hive表
 *需求描述：由于当前疑似事故管理算法准确率较低，希望Q3成立专项提升该算法准确率，以实现功能的优化。现需要大批量提取数据用以分析，以支撑算法优化策略，因此需要将护航平台该数据同步至bdp。
 *需求方：ft220315 樊星
 *开发: 01390943 周勇
 *任务创建时间：20230810
 *任务id：786644
 **/

object HwToSfHive  extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取传入参数日期:昨日日期
    val dayvar = args(0)
    //消费积压延迟上报
    val dayvar1 = getdaysBeforeOrAfter(dayvar, 1)
    //T-2推送
    val dayvar2 = getdaysBeforeOrAfter(dayvar, -1)
    logger.error("dayvar输入：" + dayvar)
    logger.error("dayvar1输入：" + dayvar1)
    logger.error("dayvar2输入：" + dayvar2)
    //从kafka提取所需要的数据：实时一条条推送
    val kafka_data=spark.sql(
      s"""
        |select log,time from dm_gis.insurance_model_duration_dist_daily_qgzh_kafka
        |where inc_day>='$dayvar' and inc_day<='$dayvar1' and log like '%safety-escort%'
        |""".stripMargin).persist(StorageLevel.MEMORY_AND_DISK)

    //从kafka提取所需要的数据：数组格式推送
    val kafka_data_array=spark.sql(
      s"""
         |select log,time from dm_gis.insurance_model_duration_dist_daily_qgzh_kafka
         |where inc_day>='$dayvar' and inc_day<='$dayvar1' and log like '%safety-escort%'
         | and log like '%"data":"[%'
         |""".stripMargin).persist(StorageLevel.MEMORY_AND_DISK)

    //表1：suspe_accident
    suspe_accident_fun(kafka_data:DataFrame,spark:SparkSession,dayvar:String)

    //表2：fleet_buried_page
    fleet_buried_page_fun(kafka_data_array:DataFrame,spark:SparkSession,dayvar:String)

    //表3：fleet_buried_operation
    fleet_buried_operation_fun(kafka_data_array:DataFrame,spark:SparkSession,dayvar:String)

    //表4：union_work_order
    union_work_order_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String)

    //表5：union_work_task
    union_work_task_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String)

    //表6：union_work_log
    union_work_log_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String)

    //表7：清洗device_video_extraction表
    device_video_extraction_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String)

    //表8：清洗device_video_extraction_detail表
    device_video_extraction_detail_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String)

    //表9：清洗video_transfer表
    video_transfer_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String)

    //表10：清洗fleet_user_info表
    fleet_user_info_fun(kafka_data:DataFrame,spark:SparkSession,dayvar:String)

    logger.error(">>>>任务已完成！")
    spark.close()

  }


  //表1：清洗suspe_accident表
def suspe_accident_fun(kafka_data:DataFrame,spark:SparkSession,dayvar:String): Unit ={
  import spark.implicits._
  logger.error(">>>>suspe_accident开始落表：")
  //获取目标表数据
  val mb_tb=kafka_data.filter($"log".like("%suspe_accident%") && !$"log".like("%\"data\":\"[%") )
  //转化rdd
  val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 3)
  logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
  //解析每条json数据
  val x_seq_result2=x_seq_rdd.map(obj=>{

    val obj_i=obj.getJSONObject("log").getString("data")
    val data_time=obj.getJSONObject("log").getString("time").replace("-","")
    var uniqid=""
    //以下是各个表的解析字段
    var alarmid=""
    var carno=""
    var imei=""
    var zytype=""
    var alarmtime=""
    var alarmname=""
    var drivercode=""
    var deptname=""
    var firstdeptname=""
    var datacode=""
    var from_source=""
    var accidentlat=""
    var accidentlng=""
    var accidentaddr=""
    var accidenttime=""
    var accidentcreatetime=""
    var accidentauditresult=""
    var createtime=""
    var nonaccidenttype=""
    var nonknowreason=""
    var accidentremark=""
    var accidentauditempcode=""
    var accidentaudittime=""
    if(obj_i !=null){
      val obj_i_js=JSON.parseObject(obj_i)
      alarmid=obj_i_js.getString("alarmId")
      carno=obj_i_js.getString("carNo")
      imei=obj_i_js.getString("imei")
      zytype=obj_i_js.getString("zyType")
      alarmtime=obj_i_js.getString("alarmTime")
      alarmname=obj_i_js.getString("alarmName")
      drivercode=obj_i_js.getString("driverCode")
      deptname=obj_i_js.getString("deptName")
      firstdeptname=obj_i_js.getString("firstDeptName")
      datacode=obj_i_js.getString("dataCode")
      from_source=obj_i_js.getString("from")
      accidentlat=obj_i_js.getString("accidentLat")
      accidentlng=obj_i_js.getString("accidentLng")
      accidentaddr=obj_i_js.getString("accidentAddr")
      accidenttime=obj_i_js.getString("accidentTime")
      accidentcreatetime=obj_i_js.getString("accidentCreateTime")
      accidentauditresult=obj_i_js.getString("accidentAuditResult")
      createtime=obj_i_js.getString("createTime")

      nonaccidenttype=obj_i_js.getString("nonAccidentType")
      nonknowreason=obj_i_js.getString("nonKnowReason")
      accidentremark=obj_i_js.getString("accidentRemark")
      accidentauditempcode=obj_i_js.getString("accidentAuditEmpCode")
      accidentaudittime=obj_i_js.getString("accidentAuditTime")

      uniqid=obj_i_js.getString("uniqid")

    }

    suspe_accident_tb(data_time,obj_i,alarmid,carno,imei,zytype,alarmtime,alarmname,drivercode,deptname,
      firstdeptname,datacode,from_source,accidentlat,accidentlng,accidentaddr,
      accidenttime,accidentcreatetime,accidentauditresult,createtime,nonaccidenttype,nonknowreason,
      accidentremark,accidentauditempcode,accidentaudittime,uniqid)
  }).toDF()
    //.withColumn("inc_day",$"data_time")
    .withColumn("inc_day",lit(dayvar))
    .filter($"inc_day"===dayvar)
    .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
    .filter($"rank"===1)
  //选择所需列
  val table_cols = spark.sql("""select * from dm_gis.dm_suspe_accident limit 0""").schema.map(_.name).map(col)
  //数据存dm表
  writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_suspe_accident")
  logger.error(">>>>suspe_accident已完成落表！")
}

case class  suspe_accident_tb(data_time:String,obj_i:String,alarmid:String,carno:String,imei:String,zytype:String,alarmtime:String,alarmname:String,drivercode:String,deptname:String,
    firstdeptname:String,datacode:String,from_source:String,accidentlat:String,accidentlng:String,accidentaddr:String,
    accidenttime:String,accidentcreatetime:String,accidentauditresult:String,createtime:String,nonaccidenttype:String,nonknowreason:String,
    accidentremark:String,accidentauditempcode:String,accidentaudittime:String,uniqid:String)

  //表2：清洗fleet_buried_page表
  def fleet_buried_page_fun(kafka_data_array:DataFrame,spark:SparkSession,dayvar:String): Unit ={
    import spark.implicits._
    logger.error(">>>>fleet_buried_page开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data_array.filter($"log".like("%fleet_buried_page%") && $"log".like("%\"data\":\"[%") )
    //转成rdd数据
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 10)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
    val x_seq_result= x_seq_rdd.flatMap(obj => {

      val obj_arr=obj.getJSONObject("log").getJSONArray("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      obj.put("data_time", data_time)
      val tmpList = new util.ArrayList[JSONObject]()
      val s=obj_arr.size()

      for (i <- 0 until(s)) {
        val tmp = new JSONObject()
        tmp.fluentPutAll(obj)
        val obj_i: JSONObject = obj_arr.getJSONObject(i)
        tmp.put("obj_i", obj_i)
        tmpList.add(tmp)
      }
      tmpList.iterator()
    })

    val x_seq_result2=x_seq_result.map(obj=>{

      val data_time=obj.getString("data_time")
      val obj_i=obj.getString("obj_i")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var client =""
      var userid =""
      var datacode =""
      var deptname =""
      var pageurl =""
      var pagename =""
      var inserttime =""
      var exittime =""
      var staytime =""
      var date =""
      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)
        uniqid=obj_i_js.getString("uniqid")
        //用uniqid替换id
        id=obj_i_js.getString("uniqid")
        userid=obj_i_js.getString("userId")
        client=obj_i_js.getString("client")
        datacode=obj_i_js.getString("dataCode")
        deptname=obj_i_js.getString("deptName")
        pageurl=obj_i_js.getString("pageUrl")
        pagename=obj_i_js.getString("pageName")
        inserttime=obj_i_js.getString("insertTime")
        exittime=obj_i_js.getString("exitTime")
        staytime=obj_i_js.getString("stayTime")
        date=obj_i_js.getString("date")
      }
      (id,userid,client,datacode,deptname,pageurl,
        pagename,inserttime,exittime,staytime,date,uniqid,data_time)
    }).toDF("id","userid","client","datacode","deptname","pageurl",
      "pagename","inserttime","exittime","staytime","date","uniqid","data_time")
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar))
      .filter($"inc_day"===dayvar)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_fleet_buried_page limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_fleet_buried_page")

    logger.error(">>>>fleet_buried_page任务已完成！")
  }

  //表3：清洗fleet_buried_operation表
  def fleet_buried_operation_fun(kafka_data_array:DataFrame,spark:SparkSession,dayvar:String): Unit ={
    import spark.implicits._
    logger.error(">>>>fleet_buried_operation开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data_array.filter($"log".like("%fleet_buried_operation%") && $"log".like("%\"data\":\"[%") )
    //转成rdd数据
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 10)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
    val x_seq_result= x_seq_rdd.flatMap(obj => {

      val obj_arr=obj.getJSONObject("log").getJSONArray("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      obj.put("data_time", data_time)
      val tmpList = new util.ArrayList[JSONObject]()
      val s=obj_arr.size()

      for (i <- 0 until(s)) {
        val tmp = new JSONObject()
        tmp.fluentPutAll(obj)
        val obj_i: JSONObject = obj_arr.getJSONObject(i)
        tmp.put("obj_i", obj_i)
        tmpList.add(tmp)
      }
      tmpList.iterator()
    })

    val x_seq_result2=x_seq_result.map(obj=>{

      val data_time=obj.getString("data_time")
      val obj_i=obj.getString("obj_i")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var userid =""
      var client =""
      var datacode =""
      var deptname =""
      var operationbutton =""
      var operationfrom =""
      var operationapi =""
      var operationparams =""
      var createtime =""
      var date =""
      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)
        uniqid=obj_i_js.getString("uniqid")
        //用uniqid替换id
        id=obj_i_js.getString("uniqid")
        userid=obj_i_js.getString("userId")
        client=obj_i_js.getString("client")
        datacode=obj_i_js.getString("dataCode")
        deptname=obj_i_js.getString("deptName")
        operationbutton=obj_i_js.getString("operationButton")
        operationfrom=obj_i_js.getString("operationFrom")
        operationapi=obj_i_js.getString("operationApi")
        operationparams=obj_i_js.getString("operationParams")
        createtime=obj_i_js.getString("createTime")
        date=obj_i_js.getString("date")
      }
      (id,userid,client,datacode,deptname,operationbutton,operationfrom,
        operationapi,operationparams,createtime,date,uniqid,data_time)
    }).toDF("id","userid","client","datacode","deptname","operationbutton","operationfrom",
      "operationapi","operationparams","createtime","date","uniqid","data_time")
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar))
      .filter($"inc_day"===dayvar)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_fleet_buried_operation limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_fleet_buried_operation")

    logger.error(">>>>dm_fleet_buried_operation任务已完成！")
  }

  //表4：清洗union_work_order表，T-2
  def union_work_order_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String): Unit ={
    import spark.implicits._
    logger.error(">>>>union_work_order开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data.filter($"log".like("%union_work_order%") && !$"log".like("%\"data\":\"[%") )
    //转化rdd
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 3)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
    //解析每条json数据
    val x_seq_result2=x_seq_rdd.map(obj=>{

      val obj_i=obj.getJSONObject("log").getString("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var work_order_id =""
      var req_id =""
      var work_model =""
      var fact_model =""
      var imei =""
      var camera =""
      var device_type =""
      var file_num =""
      var begin_time =""
      var end_time =""
      var status =""
      var reason =""
      var retry =""
      var expire_time =""
      var priority =""
      var stream_type =""
      var create_user =""
      var create_time =""
      var update_time =""
      var remark =""


      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)

        id =obj_i_js.getString("uniqid")
        work_order_id =obj_i_js.getString("work_order_id")
        req_id =obj_i_js.getString("req_id")
        work_model =obj_i_js.getString("work_model")
        fact_model =obj_i_js.getString("fact_model")
        imei =obj_i_js.getString("imei")
        camera =obj_i_js.getString("camera")
        device_type =obj_i_js.getString("device_type")
        file_num =obj_i_js.getString("file_num")
        begin_time =obj_i_js.getString("begin_time")
        end_time =obj_i_js.getString("end_time")
        status =obj_i_js.getString("status")
        reason =obj_i_js.getString("reason")
        retry =obj_i_js.getString("retry")
        expire_time =obj_i_js.getString("expire_time")
        priority =obj_i_js.getString("priority")
        stream_type =obj_i_js.getString("stream_type")
        create_user =obj_i_js.getString("create_user")
        create_time =obj_i_js.getString("create_time")
        update_time =obj_i_js.getString("update_time")
        remark =obj_i_js.getString("remark")


        uniqid=obj_i_js.getString("uniqid")
      }

      union_work_order_tb(data_time,id ,work_order_id ,req_id ,work_model ,fact_model ,imei ,
        camera ,device_type ,file_num ,begin_time ,end_time ,
        status ,reason ,retry ,expire_time ,priority ,stream_type ,
        create_user ,create_time ,update_time ,remark ,uniqid)
    }).toDF()
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar2))
      .filter($"inc_day"===dayvar2)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_union_work_order limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_union_work_order")
    logger.error(">>>>union_work_order已完成落表！")
  }

  case class union_work_order_tb(data_time:String,id :String,work_order_id :String,req_id :String,work_model :String,fact_model :String,imei :String,
                                 camera :String,device_type :String,file_num :String,begin_time :String,end_time :String,
                                 status :String,reason :String,retry :String,expire_time :String,priority :String,stream_type :String,
                                 create_user :String,create_time :String,update_time :String,remark :String,uniqid:String)
  //表5：清洗union_work_task表，T-2
  def union_work_task_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String): Unit ={
    import spark.implicits._
    logger.error(">>>>union_work_task开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data.filter($"log".like("%union_work_task%") && !$"log".like("%\"data\":\"[%") )
    //转化rdd
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 3)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())

    //解析每条json数据
    val x_seq_result2=x_seq_rdd.map(obj=>{

      val obj_i=obj.getJSONObject("log").getString("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      var uniqid=""
      //以下是各个表的解析字段
      var id  =""
      var imei  =""
      var work_order_id  =""
      var cmd_id  =""
      var camera  =""
      var filename  =""
      var file_url  =""
      var file_path  =""
      var obs_bucket  =""
      var duration  =""
      var status  =""
      var reason  =""
      var retry  =""
      var fact_model  =""
      var create_time  =""
      var update_time  =""

      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)

        id =obj_i_js.getString("uniqid")
        imei =obj_i_js.getString("imei")
        work_order_id =obj_i_js.getString("work_order_id")
        cmd_id =obj_i_js.getString("cmd_id")
        camera =obj_i_js.getString("camera")
        filename =obj_i_js.getString("filename")
        file_url =obj_i_js.getString("file_url")
        file_path =obj_i_js.getString("file_path")
        obs_bucket =obj_i_js.getString("obs_bucket")
        duration =obj_i_js.getString("duration")
        status =obj_i_js.getString("status")
        reason =obj_i_js.getString("reason")
        retry =obj_i_js.getString("retry")
        fact_model =obj_i_js.getString("fact_model")
        create_time =obj_i_js.getString("create_time")
        update_time =obj_i_js.getString("update_time")

        uniqid=obj_i_js.getString("uniqid")
      }

      (data_time,id,imei,work_order_id,cmd_id,camera,
        filename,file_url,file_path,obs_bucket,
        duration,status,reason,retry,
        fact_model,create_time,update_time,
        uniqid)
    }).toDF("data_time","id","imei","work_order_id","cmd_id","camera",
      "filename","file_url","file_path","obs_bucket",
      "duration","status","reason","retry",
      "fact_model","create_time","update_time",
      "uniqid")
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar2))
      .filter($"inc_day"===dayvar2)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_union_work_task limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_union_work_task")
    logger.error(">>>>union_work_task已完成落表！")
  }

  //表6：清洗union_work_log表，T-2
  def union_work_log_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String): Unit ={
    import spark.implicits._
    logger.error(">>>>union_work_log开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data.filter($"log".like("%union_work_log%") && !$"log".like("%\"data\":\"[%") )
    //转化rdd
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 3)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
    //解析每条json数据
    val x_seq_result2=x_seq_rdd.map(obj=>{

      val obj_i=obj.getJSONObject("log").getString("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var work_order_id =""
      var task_id =""
      var cmd_id =""
      var step =""
      var status =""
      var msg =""
      var create_time =""

      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)

        id =obj_i_js.getString("uniqid")
        work_order_id =obj_i_js.getString("work_order_id")
        task_id =obj_i_js.getString("task_id")
        cmd_id =obj_i_js.getString("cmd_id")
        step =obj_i_js.getString("step")
        status =obj_i_js.getString("status")
        msg =obj_i_js.getString("msg")
        create_time =obj_i_js.getString("create_time")


        uniqid=obj_i_js.getString("uniqid")
      }

      (data_time,id,work_order_id,task_id,cmd_id,
        step,status,msg,create_time, uniqid)
    }).toDF("data_time","id","work_order_id","task_id","cmd_id",
      "step","status","msg","create_time", "uniqid")
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar2))
      .filter($"inc_day"===dayvar2)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_union_work_log limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_union_work_log")
    logger.error(">>>>union_work_log已完成落表！")
  }

  //表7：清洗device_video_extraction表，T-2
  def device_video_extraction_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String): Unit ={
    import spark.implicits._
    logger.error(">>>>device_video_extraction开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data.filter($"log".like("%device_video_extraction%") && !$"log".like("%\"data\":\"[%") )
    //转化rdd
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 3)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
    //解析每条json数据
    val x_seq_result2=x_seq_rdd.map(obj=>{

      val obj_i=obj.getJSONObject("log").getString("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var dept_code =""
      var dept_name =""
      var data_code =""
      var username =""
      var create_time =""
      var update_time =""
      var plate_no =""
      var imei =""
      var camera_id =""
      var extraction_start_time =""
      var extraction_end_time =""
      var reason_first =""
      var reason_second =""
      var status =""
      var use_protocol =""
      var work_order_id =""
      var month =""
      var remark =""
      var video_duration =""
      var car_data_code =""
      var car_dept_name =""
      var camera_name =""
      var stream_type =""
      var resource_id =""
      var expire_time =""
      var size =""
      var progress =""

      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)

        id =obj_i_js.getString("uniqid")
        dept_code =obj_i_js.getString("dept_code")
        dept_name =obj_i_js.getString("dept_name")
        data_code =obj_i_js.getString("data_code")
        username =obj_i_js.getString("username")
        create_time =obj_i_js.getString("create_time")
        update_time =obj_i_js.getString("update_time")
        plate_no =obj_i_js.getString("plate_no")
        imei =obj_i_js.getString("imei")
        camera_id =obj_i_js.getString("camera_id")
        extraction_start_time =obj_i_js.getString("extraction_start_time")
        extraction_end_time =obj_i_js.getString("extraction_end_time")
        reason_first =obj_i_js.getString("reason_first")
        reason_second =obj_i_js.getString("reason_second")
        status =obj_i_js.getString("status")
        use_protocol =obj_i_js.getString("use_protocol")
        work_order_id =obj_i_js.getString("work_order_id")
        month =obj_i_js.getString("month")
        remark =obj_i_js.getString("remark")
        video_duration =obj_i_js.getString("video_duration")
        car_data_code =obj_i_js.getString("car_data_code")
        car_dept_name =obj_i_js.getString("car_dept_name")
        camera_name =obj_i_js.getString("camera_name")
        stream_type =obj_i_js.getString("stream_type")
        resource_id =obj_i_js.getString("resource_id")
        expire_time =obj_i_js.getString("expire_time")
        size =obj_i_js.getString("size")
        progress =obj_i_js.getString("progress")

        uniqid=obj_i_js.getString("uniqid")
      }

      device_video_extraction_tb(data_time,id,dept_code,dept_name,data_code,username,create_time,
        update_time,plate_no,imei,camera_id,extraction_start_time,
        extraction_end_time,reason_first,reason_second,status,
        use_protocol,work_order_id,month,remark,video_duration,
        car_data_code,car_dept_name,camera_name,stream_type,
        resource_id,expire_time,size,progress,uniqid)
    }).toDF()
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar2))
      .filter($"inc_day"===dayvar2)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_device_video_extraction limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_device_video_extraction")
    logger.error(">>>>device_video_extraction已完成落表！")
  }

  case class device_video_extraction_tb(data_time:String,id:String,dept_code:String,dept_name:String,data_code:String,username:String,create_time:String,
    update_time:String,plate_no:String,imei:String,camera_id:String,extraction_start_time:String,
    extraction_end_time:String,reason_first:String,reason_second:String,status:String,
    use_protocol:String,work_order_id:String,month:String,remark:String,video_duration:String,
    car_data_code:String,car_dept_name:String,camera_name:String,stream_type:String,
    resource_id:String,expire_time:String,size:String,progress:String,uniqid:String)

  //表8：清洗device_video_extraction_detail表，T-2
  def device_video_extraction_detail_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String): Unit ={
    import spark.implicits._
    logger.error(">>>>device_video_extraction_detail开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data.filter($"log".like("%device_video_extraction_detail%") && !$"log".like("%\"data\":\"[%") )
    //转化rdd
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 3)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
    //解析每条json数据
    val x_seq_result2=x_seq_rdd.map(obj=>{

      val obj_i=obj.getJSONObject("log").getString("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var resource_id =""
      var work_order_id =""
      var status =""
      var start =""
      var end =""
      var size =""
      var camera =""
      var file =""
      var url =""
      var process =""
      var video_bucket =""
      var video_extraction_id =""
      var create_time =""

      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)

        id =obj_i_js.getString("uniqid")
        resource_id =obj_i_js.getString("resource_id")
        work_order_id =obj_i_js.getString("work_order_id")
        status =obj_i_js.getString("status")
        start =obj_i_js.getString("start")
        end =obj_i_js.getString("end")
        size =obj_i_js.getString("size")
        camera =obj_i_js.getString("camera")
        file =obj_i_js.getString("file")
        url =obj_i_js.getString("url")
        process =obj_i_js.getString("process")
        video_bucket =obj_i_js.getString("video_bucket")
        video_extraction_id =obj_i_js.getString("video_extraction_id")
        create_time =obj_i_js.getString("create_time")


        uniqid=obj_i_js.getString("uniqid")
      }

      (data_time,id,resource_id,work_order_id,status,
        start,end,size,camera,
        file,url,process,video_bucket,
        video_extraction_id,create_time,uniqid)
    }).toDF("data_time","id","resource_id","work_order_id","status",
      "start","end","size","camera",
      "file","url","process","video_bucket",
      "video_extraction_id","create_time","uniqid")
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar2))
      .filter($"inc_day"===dayvar2)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_device_video_extraction_detail limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_device_video_extraction_detail")
    logger.error(">>>>device_video_extraction_detail已完成落表！")
  }

  //表9：清洗video_transfer表，T-2
  def video_transfer_fun(kafka_data:DataFrame,spark:SparkSession,dayvar2:String): Unit ={
    import spark.implicits._
    logger.error(">>>>video_transfer开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data.filter($"log".like("%video_transfer%") && !$"log".like("%\"data\":\"[%") )
    //转化rdd
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 3)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
    //解析每条json数据
    val x_seq_result2=x_seq_rdd.map(obj=>{

      val obj_i=obj.getJSONObject("log").getString("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var extract_id =""
      var imei =""
      var car_no =""
      var camera =""
      var start =""
      var end =""
      var duration =""
      var len =""
      var status =""
      var path =""
      var bucket =""
      var create_time =""
      var update_time =""
      var create_by =""
      var data_code =""
      var dept_name =""

      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)

        id =obj_i_js.getString("uniqid")
        extract_id =obj_i_js.getString("extract_id")
        imei =obj_i_js.getString("imei")
        car_no =obj_i_js.getString("car_no")
        camera =obj_i_js.getString("camera")
        start =obj_i_js.getString("start")
        end =obj_i_js.getString("end")
        duration =obj_i_js.getString("duration")
        len =obj_i_js.getString("len")
        status =obj_i_js.getString("status")
        path =obj_i_js.getString("path")
        bucket =obj_i_js.getString("bucket")
        create_time =obj_i_js.getString("create_time")
        update_time =obj_i_js.getString("update_time")
        create_by =obj_i_js.getString("create_by")
        data_code =obj_i_js.getString("data_code")
        dept_name =obj_i_js.getString("dept_name")

        uniqid=obj_i_js.getString("uniqid")
      }

      (data_time,id,extract_id,imei,car_no,camera,
        start,end,duration,len,status,
        path,bucket,create_time,update_time,
        create_by,data_code,dept_name,uniqid)
    }).toDF("data_time","id","extract_id","imei","car_no","camera",
      "start","end","duration","len","status",
      "path","bucket","create_time","update_time",
      "create_by","data_code","dept_name","uniqid")
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar2))
      .filter($"inc_day"===dayvar2)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_video_transfer limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_video_transfer")
    logger.error(">>>>video_transfer已完成落表！")
  }


  //表10：清洗fleet_user_info表，T-1
  def fleet_user_info_fun(kafka_data:DataFrame,spark:SparkSession,dayvar:String): Unit ={
    import spark.implicits._
    logger.error(">>>>fleet_user_info开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data.filter($"log".like("%fleet_user_info%") && !$"log".like("%\"data\":\"[%") )
    //转化rdd
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 3)
    logger.error(">>>>筛选出数据量："+x_seq_rdd.count())
    //解析每条json数据
    val x_seq_result2=x_seq_rdd.map(obj=>{

      val obj_i=obj.getJSONObject("log").getString("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      var uniqid=""
      //以下是各个表的解析字段
      var username =""
      var name  =""
      var role_name  =""
      var lock_flag  =""
      var del_flag  =""
      var create_time =""

      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)

        username =obj_i_js.getString("username")
        name  =obj_i_js.getString("name")
        role_name  =obj_i_js.getString("role_name")
        lock_flag  =obj_i_js.getString("lock_flag")
        del_flag  =obj_i_js.getString("del_flag")
        create_time =obj_i_js.getString("create_time")

        uniqid=obj_i_js.getString("uniqid")
      }

      (data_time,username,name,role_name,lock_flag,del_flag,create_time,uniqid)
    }).toDF("data_time","username","name","role_name","lock_flag","del_flag","create_time","uniqid")
      //.withColumn("inc_day",$"data_time")
      .withColumn("inc_day",lit(dayvar))
      .filter($"inc_day"===dayvar)
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_fleet_user_info limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_fleet_user_info")
    logger.error(">>>>fleet_user_info已完成落表！")
  }

}
