package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.CommonTools.{TimeDiffSecond, getdaysBeforeOrAfter}

import java.text.SimpleDateFormat

/**
 *需求名称：自营司机明细宽表
 *需求描述：顺丰客户对地区任务排班合理性进行监控，定位准疲劳人群，为方便客户取数分析，监管地区安全情况，提高统计效率，需建立自营司机明细宽表。
 *需求方：黄晓冰(01422522)
 *开发: 周勇(01390943)
 *任务创建时间：20230403
 *任务id：785148
 **/

object SelfDriverDetail  extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args:Array[String]){

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._

    //取跑数T-1日期
    val dayvar = args(0)
    logger.error("获取dayvar："+dayvar)
    //取跑数T-2日期，用于对比
    val dayvar1 = getdaysBeforeOrAfter(dayvar, -1)
    //取跑数T-7日期，用于对比
    val dayvar7 = getdaysBeforeOrAfter(dayvar, -6)
    //取跑数T-8日期，用于对比
    val dayvar8 = getdaysBeforeOrAfter(dayvar, -7)
    //取跑数T-30日期，用于对比
    val dayvar30 = getdaysBeforeOrAfter(dayvar, -29)
    //取跑数T-31日期，用于对比
    val dayvar31 = getdaysBeforeOrAfter(dayvar, -30)
    //取任务前后10天
    val dayvar10a = getdaysBeforeOrAfter(dayvar, -10)
    val dayvar10b = getdaysBeforeOrAfter(dayvar, 10)

    //grd自营司机T-2数据
    val grd_self_driver1=spark.sql(
      s"""
         |select emp_code,biz_date as biz_date1,last_work_time as last_work_time1 from dm_tdsp.grd_self_driver_daily_detial
         |where inc_day='$dayvar1'
         |""".stripMargin)

    //定义时间-1天函数
    val getdaysBeforeOrAfter_udf=udf(getdaysBeforeOrAfter _)
    //定义时间差udf函数
    val TimeDiffSecond_udf=udf(TimeDiffSecond _)

    //7日连续上班
    val working7=spark.sql(
      s"""
         |select * from dm_tdsp.grd_self_driver_daily_detial
         |where inc_day<='$dayvar' and inc_day>='$dayvar8'
         |""".stripMargin)
      //当天上班时间
      .withColumn("tmptime1",concat($"biz_date",lit(" 23:59:59")))
      .withColumn("startwork_time",when(trim($"first_work_time")==="" ||$"first_work_time".isNull,$"tmptime1").otherwise($"first_work_time"))
      //当天下班时间
      .withColumn("tmptime2",concat($"biz_date",lit(" 00:00:00")))
      .withColumn("offwork_brtime",when(trim($"last_work_time")==="" ||$"last_work_time".isNull,$"tmptime2").otherwise($"last_work_time"))
      .withColumn("inc_daya",getdaysBeforeOrAfter_udf($"inc_day",lit(1)))
      .withColumn("inc_dayb",getdaysBeforeOrAfter_udf($"inc_day",lit(-1)))
      .withColumn("inc_dayc",concat_ws("-",$"inc_dayb".substr(1,4),$"inc_dayb".substr(5,2),$"inc_dayb".substr(7,2)))
      .select("emp_code","inc_day","inc_daya","inc_dayc","startwork_time","offwork_brtime")

    //7日关联计算
    val working7a=working7.as("a").join(working7.as("b"),$"a.emp_code"===$"b.emp_code" && $"a.inc_day"===$"b.inc_daya","left")
      .select($"a.emp_code",$"a.inc_day",$"a.inc_daya",$"a.inc_dayc",$"a.startwork_time",$"b.offwork_brtime")
      //当天下班时间清洗
      .withColumn("tmptime2",concat($"inc_dayc",lit(" 00:00:00")))
      .withColumn("offwork_brtime",when(trim($"offwork_brtime")==="" ||$"offwork_brtime".isNull,$"tmptime2").otherwise($"offwork_brtime"))
      //日度休息时长
      .withColumn("rest_duration",round(TimeDiffSecond_udf($"offwork_brtime",$"startwork_time")/3600,4))
      //是否出勤
      .withColumn("is_worked",when($"rest_duration".cast("double")<23.99,"1").otherwise("0"))
      .withColumn("rank",row_number().over(Window.partitionBy("emp_code").orderBy(desc("inc_day"))))
      .withColumn("ranka",lpad($"rank",8,"0"))
      .withColumn("hebing",concat($"ranka",lit("_"),$"is_worked"))
      .filter($"inc_day">=dayvar31)
      .groupBy("emp_code")
      .agg(concat_ws(";",sort_array(collect_list($"hebing"))) as "hebings")
      .withColumn("working_ondays7",count_lx_udf($"hebings"))
      //7日连续出勤天数
      .select("emp_code","working_ondays7")

    //30日连续上班
    val working30=spark.sql(
      s"""
         |select * from dm_tdsp.grd_self_driver_daily_detial
         |where inc_day<='$dayvar' and inc_day>='$dayvar31'
         |""".stripMargin)
      //当天上班时间
      .withColumn("tmptime1",concat($"biz_date",lit(" 23:59:59")))
      .withColumn("startwork_time",when(trim($"first_work_time")==="" ||$"first_work_time".isNull,$"tmptime1").otherwise($"first_work_time"))
      //当天下班时间
      .withColumn("tmptime2",concat($"biz_date",lit(" 00:00:00")))
      .withColumn("offwork_brtime",when(trim($"last_work_time")==="" ||$"last_work_time".isNull,$"tmptime2").otherwise($"last_work_time"))
      .withColumn("inc_daya",getdaysBeforeOrAfter_udf($"inc_day",lit(1)))
      .withColumn("inc_dayb",getdaysBeforeOrAfter_udf($"inc_day",lit(-1)))
      .withColumn("inc_dayc",concat_ws("-",$"inc_dayb".substr(1,4),$"inc_dayb".substr(5,2),$"inc_dayb".substr(7,2)))
      .select("emp_code","inc_day","inc_daya","inc_dayc","startwork_time","offwork_brtime")

    //30日关联计算
    val working30a_tmp=working30.as("a").join(working30.as("b"),$"a.emp_code"===$"b.emp_code" && $"a.inc_day"===$"b.inc_daya","left")
      .select($"a.emp_code",$"a.inc_day",$"a.inc_daya",$"a.inc_dayc",$"a.startwork_time",$"b.offwork_brtime")
      //当天下班时间清洗
      .withColumn("tmptime2",concat($"inc_dayc",lit(" 00:00:00")))
      .withColumn("offwork_brtime",when(trim($"offwork_brtime")==="" ||$"offwork_brtime".isNull,$"tmptime2").otherwise($"offwork_brtime"))
      //日度休息时长
      .withColumn("rest_duration",round(TimeDiffSecond_udf($"offwork_brtime",$"startwork_time")/3600,4))
      //是否出勤
      .withColumn("is_worked",when($"rest_duration".cast("double")<23.99,"1").otherwise("0"))
      .withColumn("rank",row_number().over(Window.partitionBy("emp_code").orderBy(desc("inc_day"))))
      .withColumn("ranka",lpad($"rank",8,"0"))
      .withColumn("hebing",concat($"ranka",lit("_"),$"is_worked"))

    //  println("输出working30a_tmp")
    //  spark.sql("drop table if exists default.tempzy20221210x1working30a_tmp")
    // working30a_tmp.write.mode("overwrite").format("parquet").saveAsTable("default.tempzy20221210x1working30a_tmp")

    val working30a=working30a_tmp
      .filter($"inc_day">=dayvar30)
      .groupBy("emp_code")
      .agg(concat_ws(";",sort_array(collect_list($"hebing"))) as "hebings")
      .withColumn("workingdays30",count_cq_udf($"hebings"))
      .withColumn("working_ondays30",count_lx_udf($"hebings"))
      //30日连续出勤天数
      .select("emp_code","workingdays30","working_ondays30")

    //自营司机告警日度统计
    val alarm_day=spark.sql(
      s"""
         |select emp_code,d_alarm_tired_ct from  dm_gis.alarm_marvin_meddle_day
         |where inc_day='$dayvar'
         |""".stripMargin)
      //当天疲劳告警次数
      .withColumn("emp_code",lpad($"emp_code",8,"0"))

    //任务计算,state=2的用于计算
    val task_detail0a=spark.sql(
      s"""
         |select task_id,driver_id,plan_depart_tm,plan_arrive_tm,actual_depart_tm,actual_arrive_tm,
         |actual_depart_tm as actual_depart_tm_tmp,actual_arrive_tm as actual_arrive_tmtmp,
         |inc_day,lpad(main_driver_account,8,'0') emp_code,
         |lpad(main_driver_account,8,'0') main_driver_account,lpad(deputy_driver_account,8,'0') deputy_driver_account,state,line_distance
         |from dm_grd.grd_new_task_detail
         |where inc_day>='$dayvar10a' and inc_day<='$dayvar10b'
         |and state in ('2','4','6')
         |and main_driver_account is not null and trim(main_driver_account) !='' and main_driver_account !='0'
         |""".stripMargin)
      .withColumn("actual_depart_tm",when($"actual_depart_tm".isNull || trim($"actual_depart_tm")==="",$"plan_depart_tm").otherwise($"actual_depart_tm"))
      .withColumn("actual_arrive_tm",when($"actual_arrive_tm".isNull || trim($"actual_arrive_tm")==="",$"plan_arrive_tm").otherwise($"actual_arrive_tm"))
      .withColumn("actual_arrive_day",when($"actual_arrive_tm".isNull || trim($"actual_arrive_tm")==="","")
        .otherwise(regexp_replace($"actual_arrive_tm".substr(1,10),"-","")))
      .withColumn("actual_depart_day",when($"actual_depart_tm".isNull || trim($"actual_depart_tm")==="","")
        .otherwise(regexp_replace($"actual_depart_tm".substr(1,10),"-","")))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val task_detail0=task_detail0a.filter($"state".isin("4","6"))

    //20230511修改:副驾司机
    val task_detailx=task_detail0.filter($"main_driver_account" =!= $"deputy_driver_account"
      && $"main_driver_account".isNotNull && trim($"main_driver_account") =!=""
      && $"deputy_driver_account".isNotNull && trim($"deputy_driver_account") =!=""
    )
      .withColumn("emp_code",$"deputy_driver_account")

    //20230511修改:副驾司机，用于计算长途
    val task_detailx_ct=task_detail0a.filter($"main_driver_account" =!= $"deputy_driver_account"
      && $"main_driver_account".isNotNull && trim($"main_driver_account") =!=""
      && $"deputy_driver_account".isNotNull && trim($"deputy_driver_account") =!=""
    )
      .withColumn("emp_code",$"deputy_driver_account")

    //将副驾司机也并入计算
    val task_detail=task_detail0.union(task_detailx)
      .withColumn("rank",row_number().over(Window.partitionBy("emp_code").orderBy(asc("actual_depart_tm"))))
      .withColumn("driver_key",concat_ws("_",$"emp_code",$"rank"))

    //将副驾司机也并入计算，用于计算长途
    val task_detail_ct=task_detail0a.union(task_detailx_ct)
      .withColumn("rank",row_number().over(Window.partitionBy("emp_code").orderBy(asc("actual_depart_tm"))))
      .withColumn("driver_key",concat_ws("_",$"emp_code",$"rank"))

    //前一个任务
    val task_detail_a=task_detail
      .withColumn("task_id_1",$"task_id")
      .withColumn("actual_depart_tm_1",$"actual_depart_tm")
      .withColumn("actual_arrive_tm_1",$"actual_arrive_tm")
      .withColumn("actual_depart_day_1",$"actual_depart_day")
      .withColumn("actual_arrive_day_1",$"actual_arrive_day")
      .withColumn("rank_1",$"rank"+1)
      .withColumn("driver_key",concat_ws("_",$"emp_code",$"rank_1"))
      .select("driver_key","task_id_1","actual_depart_tm_1","actual_arrive_tm_1","actual_depart_day_1","actual_arrive_day_1")

    //后一个任务
    val task_detail_b=task_detail
      .withColumn("task_id_2",$"task_id")
      .withColumn("actual_depart_tm_2",$"actual_depart_tm")
      .withColumn("actual_arrive_tm_2",$"actual_arrive_tm")
      .withColumn("actual_depart_day_2",$"actual_depart_day")
      .withColumn("actual_arrive_day_2",$"actual_arrive_day")
      .withColumn("rank_2",$"rank"-1)
      .withColumn("driver_key",concat_ws("_",$"emp_code",$"rank_2"))
      .select("driver_key","task_id_2","actual_depart_tm_2","actual_arrive_tm_2","actual_depart_day_2","actual_arrive_day_2")

    //后一个任务，用于计算长途任务
    val task_detail_b_ct=task_detail_ct
      .withColumn("task_id_3",$"task_id")
      .withColumn("actual_depart_tm_3",$"actual_depart_tm")
      .withColumn("actual_arrive_tm_3",$"actual_arrive_tm")
      .withColumn("actual_depart_day_3",$"actual_depart_day")
      .withColumn("actual_arrive_day_3",$"actual_arrive_day")
      .withColumn("rank_3",$"rank"-1)
      .withColumn("driver_key",concat_ws("_",$"emp_code",$"rank_3"))
      .select("driver_key","task_id_3","actual_depart_tm_3","actual_arrive_tm_3","actual_depart_day_3","actual_arrive_day_3")

    //任务数据关联
    val task_detail_all=task_detail.join(task_detail_a,Seq("driver_key"),"left")
      .join(task_detail_b,Seq("driver_key"),"left")
      .join(task_detail_b_ct,Seq("driver_key"),"left")
      //本次开始和上次结束的时间间隔
      .withColumn("time_dif",when($"actual_depart_tm".isNotNull && trim($"actual_depart_tm")=!=""
        && $"actual_arrive_tm_1".isNotNull && trim($"actual_arrive_tm_1")=!="" && "actual_arrive_day_1"==dayvar,
        round(TimeDiffSecond_udf($"actual_arrive_tm_1",$"actual_depart_tm")/3600,4)).otherwise(lit(null)))
      //单趟任务时长
      .withColumn("time_duration_0",when($"actual_depart_tm".isNotNull && trim($"actual_depart_tm")=!="" && $"actual_arrive_tm".isNotNull && trim($"actual_arrive_tm")=!="",
        round(TimeDiffSecond_udf($"actual_depart_tm",$"actual_arrive_tm")/3600,4)).otherwise(lit(null)))
      //前一天单趟任务时长
      .withColumn("time_duration_1",when($"actual_depart_tm_1".isNotNull && trim($"actual_depart_tm_1")=!="" && $"actual_arrive_tm_1".isNotNull && trim($"actual_arrive_tm_1")=!="",
        round(TimeDiffSecond_udf($"actual_depart_tm_1",$"actual_arrive_tm_1")/3600,4)).otherwise(lit(null)))
      //后一天单趟任务时长
      .withColumn("time_duration_2",when($"actual_depart_tm_2".isNotNull && trim($"actual_depart_tm_2")=!="" && $"actual_arrive_tm_2".isNotNull && trim($"actual_arrive_tm_2")=!="",
        round(TimeDiffSecond_udf($"actual_depart_tm_2",$"actual_arrive_tm_2")/3600,4)).otherwise(lit(null)))
      //筛选指定日期
      //.filter($"inc_day"===dayvar && $"actual_arrive_day">=dayvar)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //平均任务间隔
    val task_detail_avg_timedif=task_detail_all
      .filter($"inc_day"===dayvar && $"actual_arrive_day">=dayvar)
      //若当天只有1个任务，则任务间隔为当天23:59:59-实际到达时间
      .withColumn("day_tmp",concat($"actual_arrive_tm".substr(1,10),lit(" 23:59:59")))
      //如果当天只有1条任务
      .withColumn("time_dif",when(($"actual_arrive_day_1".isNull || trim($"actual_arrive_day_1")==="") && ($"actual_depart_day_2".isNull || trim($"actual_depart_day_2")==="")
        ,round(TimeDiffSecond_udf($"actual_arrive_tm",$"day_tmp")/3600,4)).otherwise($"time_dif"))
      .groupBy("emp_code")
      .agg(round(avg($"time_dif"),4) as "avg_timedif")

    //最小时间间隔的指标
    val task_detail_mindif=task_detail_all
      .filter($"inc_day"===dayvar && $"actual_arrive_day">=dayvar)
      //若当天只有1个任务，则任务间隔为当天23:59:59-实际到达时间
      .withColumn("day_tmp",concat($"actual_arrive_tm".substr(1,10),lit(" 23:59:59")))
      //如果当天只有1条任务
      .withColumn("time_dif",when(($"actual_arrive_day_1".isNull || trim($"actual_arrive_day_1")==="") && ($"actual_depart_day_2".isNull || trim($"actual_depart_day_2")==="")
        ,round(TimeDiffSecond_udf($"actual_arrive_tm",$"day_tmp")/3600,4)).otherwise($"time_dif"))
      .withColumn("rk",row_number().over(Window.partitionBy("emp_code").orderBy(asc("time_dif"))))
      .filter($"rk"===1)
      .withColumn("time_mindif",$"time_dif")
      .withColumn("task_id_1",when($"actual_arrive_day_1"===dayvar,$"task_id_1").otherwise(""))
      .withColumn("task_id_2",when($"actual_depart_day_2"===dayvar,$"task_id_2").otherwise(""))
      .withColumn("time_duration_1",when($"actual_arrive_day_1"===dayvar,$"time_duration_1").otherwise(null))
      .withColumn("time_duration_2",when($"actual_depart_day_2"===dayvar,$"time_duration_2").otherwise(null))
      .select("emp_code","time_mindif","task_id_1","task_id_2","time_duration_1","time_duration_2")

    //计算长途任务:长途任务ID、长途任务后休息时长
    val task_detail_tc=task_detail_all
      .withColumn("actual_depart_tm_x",when($"actual_depart_tm".isNotNull && trim($"actual_depart_tm")=!="" &&
        $"actual_arrive_tm".isNotNull && trim($"actual_arrive_tm")=!="",$"actual_depart_tm").otherwise($"plan_depart_tm"))
      .withColumn("actual_arrive_tm_x",when($"actual_depart_tm".isNotNull && trim($"actual_depart_tm")=!="" &&
        $"actual_arrive_tm".isNotNull && trim($"actual_arrive_tm")=!="",$"actual_arrive_tm").otherwise($"plan_arrive_tm"))
      //单趟任务时长,长途任务计算方式单独计算
      .withColumn("time_duration_0",when($"actual_depart_tm_x".isNotNull && trim($"actual_depart_tm_x")=!="" && $"actual_arrive_tm_x".isNotNull
        && trim($"actual_arrive_tm_x")=!="", round(TimeDiffSecond_udf($"actual_depart_tm_x",$"actual_arrive_tm_x")/3600,4)).otherwise(lit(null)))
      //休息时长
      .withColumn("time_dif_far",when($"actual_depart_tm_3".isNotNull && trim($"actual_depart_tm_3")=!=""
        && $"actual_arrive_tm_x".isNotNull && trim($"actual_arrive_tm_x")=!="" ,
        when($"actual_depart_tm_3"<$"actual_arrive_tm_x",null).otherwise(round(TimeDiffSecond_udf($"actual_arrive_tm_x",$"actual_depart_tm_3")/3600,4))
      ).otherwise(lit(null)))
      //.filter($"actual_arrive_day"===dayvar && $"state".isin("4","6")  && $"time_duration_0".cast("double")>=8 )
      .filter($"state".isin("4","6")  && $"time_duration_0".cast("double")>=8 )
      .withColumn("task_id_far",$"task_id")
      //是否双驾
      .withColumn("is_twodrivers",when($"main_driver_account" =!= $"deputy_driver_account" && $"deputy_driver_account" =!="00000000"
        && $"main_driver_account".isNotNull && trim($"main_driver_account") =!=""
        && $"deputy_driver_account".isNotNull && trim($"deputy_driver_account") =!="","1"
      ).otherwise("0"))
      //以防数据重复，取最后一条数据
      //.withColumn("rkcf",row_number().over(Window.partitionBy("emp_code").orderBy(asc("actual_arrive_tm"))))
      //.filter($"rkcf"===1)
      .withColumn("line_distance_far",$"line_distance")
      .select("emp_code","task_id_far","time_dif_far","is_twodrivers","actual_depart_day","actual_arrive_day","line_distance_far")

    val driver_tc=spark.sql(
      s"""
         |select emp_code,inc_day from dm_tdsp.grd_self_driver_daily_detial
         |where inc_day='$dayvar'
         |""".stripMargin)

    val driver_tc2=driver_tc.join(task_detail_tc,Seq("emp_code"),"left")
      .filter($"actual_depart_day"<=$"inc_day" && $"inc_day"<=$"actual_arrive_day")
      .withColumn("rkcf2",row_number().over(Window.partitionBy("emp_code").orderBy(desc("actual_arrive_day"))))
      .filter($"rkcf2"===1)
      .select("emp_code","task_id_far","time_dif_far","is_twodrivers","line_distance_far")

    //    spark.sql("drop table if exists tmp_dm_gis.tempzy_task_detail_tcsasas1")
    //    task_detail_tc.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tempzy_task_detail_tcsasas1")

    //修改first_work_time：如果存在跨天任务，则补充当天上下班时间
    val driver_worktime=spark.sql(
      s"""
         |select emp_code,first_work_time,last_work_time,biz_date,inc_day from dm_tdsp.grd_self_driver_daily_detial
         |where inc_day='$dayvar'
         |""".stripMargin)

    //10天前后任务筛选出跨3天以及以上的任务
    val task_detail_wktm=task_detail.filter($"state".isin("4","6"))
      .select("emp_code","plan_depart_tm","plan_arrive_tm")
      .withColumn("plan_depart_day",regexp_replace($"plan_depart_tm".substr(1,10),"-",""))
      .withColumn("plan_arrive_day",regexp_replace($"plan_arrive_tm".substr(1,10),"-",""))
      .withColumn("plan_depart_day_2",getdaysBeforeOrAfter_udf($"plan_depart_day",lit(2)))
      .filter($"plan_depart_day_2"<=$"plan_arrive_day")

    val driver_worktime2=driver_worktime.join(task_detail_wktm,Seq("emp_code"),"left")
      .filter($"plan_depart_day"<$"inc_day" && $"inc_day"<$"plan_arrive_day")
      //为防止重复，做去重处理
      .withColumn("rank",row_number().over(Window.partitionBy("emp_code").orderBy(desc("inc_day"))))
      .filter($"rank"===1)
      .withColumn("first_work_time_tmp",concat($"biz_date",lit(" 00:00:00")))
      .withColumn("last_work_time_tmp",concat($"biz_date",lit(" 23:59:59")))
      .select("emp_code","first_work_time_tmp","last_work_time_tmp")

    //结果汇总
    val tb_cols = spark.sql("""select * from dm_gis.dm_self_driver_dtl limit 0""").schema.map(_.name).map(col)
    //grd自营司机
    val grd_self_driver=spark.sql(
      s"""
         |select * from dm_tdsp.grd_self_driver_daily_detial
         |where inc_day='$dayvar'
         |""".stripMargin)
      .join(grd_self_driver1,Seq("emp_code"),"left")
      .join(working7a,Seq("emp_code"),"left")
      .join(alarm_day,Seq("emp_code"),"left")
      .join(working30a,Seq("emp_code"),"left")
      .join(driver_worktime2,Seq("emp_code"),"left")
      .withColumn("first_work_time",when($"first_work_time".isNotNull && trim($"first_work_time") =!="",$"first_work_time").otherwise($"first_work_time_tmp"))
      .withColumn("last_work_time",when($"last_work_time".isNotNull && trim($"last_work_time") =!="",$"last_work_time").otherwise($"last_work_time_tmp"))
      //是否8小时工作时长
      .withColumn("is_hours8",when($"work_hours">=8,1).otherwise(0))
      //当天上班时间
      .withColumn("tmptime1",concat($"biz_date",lit(" 23:59:59")))
      .withColumn("startwork_time",when(trim($"first_work_time")==="" ||$"first_work_time".isNull,$"tmptime1").otherwise($"first_work_time"))
      //前一天下班时间
      .withColumn("inc_dayb",getdaysBeforeOrAfter_udf($"inc_day",lit(-1)))
      .withColumn("inc_dayc",concat_ws("-",$"inc_dayb".substr(1,4),$"inc_dayb".substr(5,2),$"inc_dayb".substr(7,2)))
      .withColumn("tmptime2",concat($"inc_dayc",lit(" 00:00:00")))
      .withColumn("offwork_brtime",when(trim($"last_work_time1")==="" ||$"last_work_time1".isNull,$"tmptime2").otherwise($"last_work_time1"))
      //日度休息时长
      .withColumn("rest_duration",round(TimeDiffSecond_udf($"offwork_brtime",$"startwork_time")/3600,4))
      //是否出勤
      .withColumn("is_worked",when($"rest_duration".cast("double")<19.99,1).otherwise(0))
      //是否准疲劳
      .withColumn("is_tired_expect",when($"working_ondays30".cast("double")<7,0)
        .when($"working_ondays30".cast("double")<14,1).
        when($"working_ondays30".cast("double")<21,2).
        when($"working_ondays30".cast("double")<31,3))
      //填充0
      .na.fill(0,Seq("d_alarm_tired_ct"))
      //在途任务时长
      .withColumn("onway_hours",round($"task_hours".cast("double")+$"cust_task_hours".cast("double"),4))
      //在途是否超过8h
      .withColumn("is_onway8",when($"onway_hours".cast("double")>8,1).otherwise(0))
      .join(task_detail_avg_timedif,Seq("emp_code"),"left")
      .join(task_detail_mindif,Seq("emp_code"),"left")
      .withColumn("inc_day",lit(dayvar))
      //匹配长途计算指标
      .join(driver_tc2,Seq("emp_code"),"left")
      //班次
      .withColumn("work_type",when($"first_work_time".isNull || trim($"first_work_time")===""
        || $"last_work_time".isNull || trim($"last_work_time")==="","").otherwise(work_type_duf($"first_work_time",$"last_work_time")))
      //是否长途准疲劳
      .withColumn("is_cttired_expect",when($"task_id_far".isNotNull && trim($"task_id_far")=!="" && $"time_dif_far".cast("double")<5,"1").otherwise("0"))
      //准疲劳人群
      .withColumn("is_tired_group",when($"is_tired_expect"==="0" && $"is_cttired_expect"==="0","0").otherwise("1"))
      .select(tb_cols:_*)

    //存储表
    writeToHive(spark, grd_self_driver, Seq("inc_day"), "dm_gis.dm_self_driver_dtl")

  }

  //班次计算:x为上班时间，y为下班时间
  def work_type(x:String,y:String): String ={
    if(x !=null && x.trim != "" && y !=null && y.trim != ""){
      //由于真实数据的上班和下班时间都是在当天，这里只计算当天就行
      val y_day=y.substring(0,10)
      val mid_time1=y_day.concat(" ").concat("06:00:00")
      val mid_time2=y_day.concat(" ").concat("22:00:00")
      //白班时间，秒
      var daytime=0L
      //夜班时间，秒
      var nighttime=0L
      //将上班时间和下班时间划到时间段
      if(x<=mid_time1 && y<=mid_time1){
        nighttime=nighttime+TimeDiffSecond(x,y)
      }
      else if(x<=mid_time1 && y<=mid_time2 && y>mid_time1){
        nighttime=nighttime+TimeDiffSecond(x,mid_time1)
        daytime=daytime+TimeDiffSecond(mid_time1,y)
      }
      else if(x<=mid_time1 && y>=mid_time2 ){
        nighttime=nighttime+TimeDiffSecond(x,mid_time1)+TimeDiffSecond(mid_time2,y)
        daytime=daytime+TimeDiffSecond(x,y)
      }
      else if(x>=mid_time1 && x<mid_time2 && y<=mid_time2 ){
        nighttime=nighttime
        daytime=daytime+TimeDiffSecond(x,y)
      }
      else if(x>=mid_time1 && x<mid_time2 && y>mid_time2 ){
        nighttime=nighttime+TimeDiffSecond(x,mid_time2)
        daytime=daytime+TimeDiffSecond(x,y)
      }
      else if(x>=mid_time2  && y>=mid_time2 ){
        nighttime=nighttime+TimeDiffSecond(x,y)
        daytime=daytime
      }
      if (daytime>nighttime){return "1"}
      else if(daytime==nighttime){return "2"}
      else if(daytime<nighttime){return "3"}
      else{return ""}
    }
    else{
      return ""
    }
  }

  val work_type_duf=udf(work_type _)

  //定义时间差计算：秒，str2比str1大,传入格式：2022-09-30 15:30:18，例如返回结果：300
  def TimeDiffSecond(str1: String, str2: String): Long = {
    var datedf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    //转换时间戳：毫秒
    val x1 = datedf.parse(str1).getTime
    val x2 = datedf.parse(str2).getTime
    //除以1000就是秒为单位
    val x3 = (x2 - x1) / 1000
    return x3
  }

  //连续出勤天数
  def count_lx(x:String): Int ={
    val x_arr=x.split(";")
    val l=x_arr.length
    var i=0
    var flag=1
    while(flag==1 && i<l){
      if(x_arr(i).split("_")(1)=="1")
      { i=i+1
        flag=1
      }
      else flag=0
    }
    i
  }

  val count_lx_udf=udf(count_lx _)

  //总出勤天数
  def count_cq(x:String): Int ={
    val x_arr=x.split(";")
    val l=x_arr.length
    var flag=1
    for(i<- 0 until l){
      if(x_arr(i).split("_")(1)=="1"){flag=flag+1}
    }
    flag
  }

  val count_cq_udf=udf(count_cq _)


}
