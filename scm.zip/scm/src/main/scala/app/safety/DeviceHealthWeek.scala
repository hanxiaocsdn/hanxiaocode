package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import utils.CommonTools.getdaysBeforeOrAfter
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._

/**
 *需求名称：设备健康度周报表
 *需求描述：顺丰客户对地区进行安全管理，对地区维度有相关考核指标。此表为方便取出地区维度的设备治理情况，监管地区安全情况，提高日报统计效率所建。
 *需求方：刘桓(01422529) 黄晓冰(01422522)
 *开发: 周勇(01390943)
 *任务创建时间：20230512
 *任务id：785131
 **/

object DeviceHealthWeek  extends  DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    val dayvar = args(0)
    val dayvar8 = getdaysBeforeOrAfter(dayvar, -7)
    logger.error("接收输入变量dayvar:" + dayvar)
    logger.error("接收输入变量dayvar8:" + dayvar8)

    //设备健康日报表
    val healthday=spark.sql(
      s"""
         |select * from dm_gis.dm_device_health_day
         |where inc_day='$dayvar8'
         |""".stripMargin)

    //7天不在线设备数
    val device_exception7=spark.sql(
      s"""
         |select * from dm_gis.dm_device_exception_dtl
         |where inc_day='$dayvar'
         |""".stripMargin)
      .withColumn("deptname",$"ctname")
      .groupBy("deptname")
      .agg(count(when($"onlinetag".isNotNull && trim($"onlinetag")=!="",$"car_no").otherwise(null)) as "onlinetag7")

    //自检未反馈数
    val deviceadjust=spark.sql(
      s"""
         |select * from dm_gis.dm_deviceadjust_monitor_df
         |where inc_day='$dayvar8'
         |""".stripMargin)
      .withColumn("deptname",$"ctname")
      .select("deptname","car_no","position_text")

    val selfcheck_log=spark.sql(
      s"""
         |select * from dm_gis.dm_marvin_zt_device_selfcheck_log_log_di
         |where inc_day='$dayvar'
         |and regexp_replace(create_date,'-','')>'$dayvar8'
         |and regexp_replace(create_date,'-','')<='$dayvar'
         |""".stripMargin)
      .withColumn("position_text",when($"camera_type"==="0","adas").when($"camera_type"==="1","dms").otherwise(""))

//    val selfcheck_loga_noreply=selfcheck_log
//      .groupBy("car_no","position_text")
//      .agg(count($"car_no") as "car_no_ct")
//
//    val selfcheck_noreply_df=deviceadjust.join(selfcheck_loga_noreply,Seq("car_no","position_text"),"left")
//      .withColumn("flag",when($"car_no_ct">0,1).otherwise(0))
//      .filter($"flag"===0 || $"flag".isNull || trim($"flag")==="")
//      .groupBy("deptname")
//      .agg(countDistinct($"car_no") as "selfcheck_noreply" )
//
//    println("调整数1：")
//    selfcheck_noreply_df.filter($"deptname"==="华中分拨区").show(false)

    //自检未反馈数
        val selfcheck_noreply_df=spark.sql(
          s"""
             |SELECT car_no,ctname FROM dm_gis.dm_devicemonitor_detail_week
             |WHERE inc_day = '$dayvar' AND cast(w_exceptiondays as int) >=7 AND w_isadjust ='0'
             |GROUP BY  car_no,ctname
             |""".stripMargin)
          .groupBy("ctname")
          .agg(count($"car_no") as "selfcheck_noreply")
          .withColumnRenamed("ctname","deptname")

    //调整失败数
//    val selfcheck_loga_falire=selfcheck_log
//      .groupBy("car_no","position_text")
//      .agg(count(when($"check_result"==="2",1).otherwise(null)) as "flag1",
//        count(when($"system_check_result"==="1",1).otherwise(null)) as "flag2",
//        count(when($"check_result"==="4",1).otherwise(null)) as "flag3")
//      .filter($"flag1">0 && $"flag2"===0 && $"flag3"===0)
//
//    val selfcheck_falire_df=deviceadjust.join(selfcheck_loga_falire,Seq("car_no","position_text"))
//      .groupBy("deptname")
//      .agg(countDistinct($"car_no") as "selfcheck_falire" )

    val selfcheck_falire_df=spark.sql(
      s"""
         |SELECT car_no,ctname FROM dm_gis.dm_devicemonitor_detail_week
         |WHERE inc_day = '$dayvar' AND cast(w_exceptiondays as int) >=7 AND w_isconfigadjust ='1'
         |and w_issucess = '0'
         |GROUP BY  car_no,ctname
         |""".stripMargin)
      .groupBy("ctname")
      .agg(count($"car_no") as "selfcheck_falire")
      .withColumnRenamed("ctname","deptname")

    //调整数，修改为：设备异常数-自检未反馈数
    val adjust_ct_df0=deviceadjust
      .groupBy("deptname")
      .agg(countDistinct($"car_no") as "selfcheck_ct" )

//    println("调整数2：")
//    adjust_ct_df0.filter($"deptname"==="华中分拨区").show(false)
//
//    val adjust_ct_df=adjust_ct_df0
//      .join(selfcheck_noreply_df,Seq("deptname"),"left")
//      .withColumn("adjust_ct_w",$"selfcheck_ct"-$"selfcheck_noreply")
//      .select("deptname","selfcheck_ct","adjust_ct_w")

    //确认调整数
    val selfcheck_loga_conf=selfcheck_log
      .groupBy("car_no","position_text")
      .agg(count(when($"check_result"==="2",1).otherwise(null)) as "flag")

    val selfcheck_conf_df=deviceadjust.join(selfcheck_loga_conf,Seq("car_no","position_text"),"left")
      .groupBy("deptname")
      .agg(countDistinct($"car_no") as "car_no_ct",
        countDistinct(when($"flag"===0 || $"flag".isNull || trim($"flag")==="",$"car_no").otherwise(null)) as "car_no_ct0"
      )
      .withColumn("selfcheck_conf_ct",$"car_no_ct"-$"car_no_ct0")

    //确认调整成功数
    val selfcheck_confsuccelog=selfcheck_log
      .groupBy("car_no","position_text")
      .agg(count(when($"check_result"==="2",1).otherwise(null)) as "flag1",
        count(when($"system_check_result"==="1",1).otherwise(null)) as "flag2")
      .filter($"flag1">0 && $"flag2"===0 )

    val selfcheck_confsucce_df=deviceadjust.join(selfcheck_confsuccelog,Seq("car_no","position_text"))
      .groupBy("deptname")
      .agg(countDistinct($"car_no") as "selfcheck_confsucce_tmp" )

    //确认我已核实数
    val selfcheck_confchecklog=selfcheck_log
      .groupBy("car_no","position_text")
      .agg(count(when($"check_result"==="4",1).otherwise(null)) as "flag1")
    //.filter( $"flag1"===0 )

    val selfcheck_confcheck_df_0=deviceadjust.join(selfcheck_confchecklog,Seq("car_no","position_text"),"left")
      .withColumn("is_need",when($"flag1"==="0" || $"flag1".isNull || trim($"flag1")==="",1).otherwise(0))
      .filter($"is_need"===1)

    println("调整数3：")
    selfcheck_confcheck_df_0.filter($"deptname"==="华中分拨区").show(false)

    val selfcheck_confcheck_df=selfcheck_confcheck_df_0
      .groupBy("deptname")
      .agg(countDistinct($"car_no") as "selfcheck_confcheck_tmp" )

    println("调整数4：")
    selfcheck_confcheck_df.filter($"deptname"==="华中分拨区").show(false)

    //无法调整数
    val selfcheck_noadjustlog=selfcheck_log
      .groupBy("car_no","position_text")
      .agg(count(when($"check_result"==="3",1).otherwise(null)) as "flag1")

    val selfcheck_noadjust_df_0=deviceadjust.join(selfcheck_noadjustlog,Seq("car_no","position_text"),"left")


    println("调整数5：")
    selfcheck_noadjust_df_0.filter($"deptname"==="华中分拨区").show(false)

    val selfcheck_noadjust_df=selfcheck_noadjust_df_0.filter($"flag1"===0 || $"flag1".isNull || trim($"flag1")==="")
      .groupBy("deptname")
      .agg(countDistinct($"car_no") as "selfcheck_noadjust_tmp" )

    //结果合并
    val data_result=healthday.join(device_exception7,Seq("deptname"),"left")
      .withColumn("cama_expct",when($"cama_expct".isNull || trim($"cama_expct")==="",0).otherwise($"cama_expct"))
      //设备异常数,修改为取设备异常日表cama_expct
      //.withColumn("device_excepct",$"selfcheck_noreply"+$"selfcheck_falire")
      .withColumn("device_excepct",$"cama_expct")
     .join(selfcheck_noreply_df,Seq("deptname"),"left")
      .withColumn("selfcheck_noreply",when($"selfcheck_noreply".isNull || trim($"selfcheck_noreply")==="",0).otherwise($"selfcheck_noreply"))
      .join(selfcheck_falire_df,Seq("deptname"),"left")
      .withColumn("selfcheck_falire",when($"selfcheck_falire".isNull || trim($"selfcheck_falire")==="",0).otherwise($"selfcheck_falire"))
      //.join(adjust_ct_df,Seq("deptname"),"left")
      .join(adjust_ct_df0,Seq("deptname"),"left")
      //调整数
      .withColumn("adjust_ct_w",$"device_excepct"-$"selfcheck_noreply")
      .join(selfcheck_conf_df,Seq("deptname"),"left")
      .join(selfcheck_confsucce_df,Seq("deptname"),"left")
      .join(selfcheck_confcheck_df,Seq("deptname"),"left")
      .join(selfcheck_noadjust_df,Seq("deptname"),"left")
      .na.fill(0,Seq("selfcheck_conf_ct","selfcheck_confsucce_tmp","adjust_ct_w","selfcheck_confcheck_tmp","selfcheck_ct",
      "selfcheck_noadjust_tmp","selfcheck_noreply","selfcheck_falire"))
      .withColumn("selfcheck_confsucce",$"selfcheck_conf_ct"-$"selfcheck_confsucce_tmp")
      .withColumn("selfcheck_confcheck",$"selfcheck_ct"-$"selfcheck_confcheck_tmp")
      .withColumn("selfcheck_noadjust",$"selfcheck_ct"-$"selfcheck_noadjust_tmp")

      //设备异常率
      .withColumn("device_excepct_pert",round($"device_excepct"/$"device_ct",6))
      //反馈率
      .withColumn("reply_excepct_pert",when($"device_excepct"==="0",1).otherwise(round($"adjust_ct_w"/$"device_excepct",6)))
      //调整成功数
      .withColumn("adjust_succe_ct",$"selfcheck_conf_ct"-$"selfcheck_falire")
      //反馈成功率
      .withColumn("reply_succe_pert",when($"selfcheck_conf_ct"==="0",1).otherwise(round($"adjust_succe_ct"/$"selfcheck_conf_ct",6)))
      .withColumn("onlinetag7",when($"onlinetag7".isNull || trim($"onlinetag7")==="",0).otherwise($"onlinetag7"))

      .withColumn("inc_day",lit(dayvar))

    //存储表
    val tb_cols = spark.sql("""select * from dm_gis.dm_device_health_week limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, data_result.select(tb_cols:_*), Seq("inc_day"), "dm_gis.dm_device_health_week")

    spark.close()
  }

}
