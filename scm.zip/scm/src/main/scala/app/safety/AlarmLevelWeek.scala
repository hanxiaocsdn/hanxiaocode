package app.safety

import com.sf.gis.java.base.util.SparkUtil
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.functions
import utils.CommonTools.getdaysBeforeOrAfter
import org.apache.spark.sql.functions.{col, countDistinct, lit, round, sum, when}

/**
 *需求名称：项目分级告警处理周表
 *需求描述：按照项目/周维度，统计各项目每周分级处理告警量及护航量，每周定时同步到mysql
 *需求方：01432230 王珺懿
 *开发: 周勇(01390943)
 *任务创建时间：20230809
 *任务id：786306
 **/

object AlarmLevelWeek extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取传入参数日期:昨日日期
    val input_inc_day1 = args(0)
    //计算日期:T-7日期
    val input_inc_day2 = getdaysBeforeOrAfter(input_inc_day1, -6)
    //计算日期:今日日期，用于分区
    val input_inc_day3 = getdaysBeforeOrAfter(input_inc_day1, 1)
    logger.error("input_inc_day1输入：" + input_inc_day1)
    logger.error("input_inc_day2输入：" + input_inc_day2)
    logger.error("input_inc_day3输入：" + input_inc_day3)

    //获取设备异常宽表数据
    val device_data=spark.sql(
      s"""
        |select
        |substr(datacode,1,8) datacode,
        |imei,
        |risklevel_low_rg,
        |risklevel_low_sys,
        |risklevel_low_ai,
        |risklevel_mid_rg,
        |risklevel_mid_sys,
        |risklevel_mid_ai,
        |risklevel_high_rg,
        |risklevel_high_sys,
        |risklevel_high_ai,
        |dcount,
        |avdcount,
        |healthetype,
        |recount,
        |touchcount,
        |ntntruedevice,
        |ntnfaildevice,
        |aiudqua,ttsnum,
        |inc_day,
        |datacode as datacode_org,
        |roadtimecar
        |from dm_gis.dm_dwd_device_day
        |where inc_day>='$input_inc_day2' and inc_day<='$input_inc_day1'
        |""".stripMargin)

    logger.error("汇总计算:")
    val result_data=device_data.groupBy("datacode")
      .agg(
        countDistinct(when($"inc_day"===input_inc_day1,$"imei").otherwise(null)) as "carnum",
        sum(when($"risklevel_low_rg".isNull || $"risklevel_low_rg"==="",0).otherwise($"risklevel_low_rg")) as "risklevel_low_rg_tmp",
        sum(when($"risklevel_low_sys".isNull || $"risklevel_low_sys"==="",0).otherwise($"risklevel_low_sys")) as "risklevel_low_sys_tmp",
        sum(when($"risklevel_low_ai".isNull || $"risklevel_low_ai"==="",0).otherwise($"risklevel_low_ai")) as "risklevel_low_ai_tmp",
        sum(when($"risklevel_mid_rg".isNull || $"risklevel_mid_rg"==="",0).otherwise($"risklevel_mid_rg")) as "risklevel_mid_rg_tmp",
        sum(when($"risklevel_mid_sys".isNull || $"risklevel_mid_sys"==="",0).otherwise($"risklevel_mid_sys")) as "risklevel_mid_sys_tmp",
        sum(when($"risklevel_mid_ai".isNull || $"risklevel_mid_ai"==="",0).otherwise($"risklevel_mid_ai")) as "risklevel_mid_ai_tmp",
        sum(when($"risklevel_high_rg".isNull || $"risklevel_high_rg"==="",0).otherwise($"risklevel_high_rg")) as "risklevel_high_rg_tmp",
        sum(when($"risklevel_high_sys".isNull || $"risklevel_high_sys"==="",0).otherwise($"risklevel_high_sys")) as "risklevel_high_sys_tmp",
        sum(when($"risklevel_high_ai".isNull || $"risklevel_high_ai"==="",0).otherwise($"risklevel_high_ai")) as "risklevel_high_ai_tmp",
        round(sum(when($"dcount".isNull || $"dcount"==="",0).otherwise($"dcount"))-sum(when($"avdcount".isNull || $"avdcount"==="",0).otherwise($"avdcount")),0) as "defend_sum",
        sum(when($"recount".isNull || $"recount"==="",0).otherwise($"recount")) as "recount_tmp",
        sum(when($"touchcount".isNull || $"touchcount"==="",0).otherwise($"touchcount")) as "touchcount_tmp",
        sum(when($"ntntruedevice".isNull || $"ntntruedevice"==="",0).otherwise($"ntntruedevice")) as "ntntruedevice_tmp",
        sum(when($"ntnfaildevice".isNull || $"ntnfaildevice"==="",0).otherwise($"ntnfaildevice")) as "ntnfaildevice_tmp",
        sum(when($"aiudqua".isNull || $"aiudqua"==="",0).otherwise($"aiudqua")) as "aiudqua_tmp",
        sum(when($"ttsnum".isNull || $"ttsnum"==="",0).otherwise($"ttsnum")) as "ttsnum_tmp",
        sum(when($"roadtimecar".isNull || $"roadtimecar"==="",0).otherwise($"roadtimecar")) as "roadtime_tmp"

      )

    //计算前一天的数据
    val result_daybf=device_data.filter($"inc_day"===input_inc_day1)
      .groupBy("datacode")
      .agg(
        sum(when($"healthetype"==="1" || $"healthetype"==="3",1).otherwise(0)) as "dderror",
        sum(when($"healthetype"==="2" || $"healthetype"==="3",1).otherwise(0)) as "cderror",
        sum(when($"healthetype"=!="" && $"healthetype".isNotNull,1).otherwise(0)) as "derror",
        countDistinct(when($"inc_day"===input_inc_day1,$"datacode_org").otherwise(null)) as "fleetnum_tmp"
      )

    //结果合并
    val result_data2=result_data.join(result_daybf,Seq("datacode"),"left")
      .withColumn("risklevel_low_rg",$"risklevel_low_rg_tmp".cast("int"))
      .withColumn("risklevel_low_sys",$"risklevel_low_sys_tmp".cast("int"))
      .withColumn("risklevel_low_ai",$"risklevel_low_ai_tmp".cast("int"))
      .withColumn("risklevel_mid_rg",$"risklevel_mid_rg_tmp".cast("int"))
      .withColumn("risklevel_mid_sys",$"risklevel_mid_sys_tmp".cast("int"))
      .withColumn("risklevel_mid_ai",$"risklevel_mid_ai_tmp".cast("int"))
      .withColumn("risklevel_high_rg",$"risklevel_high_rg_tmp".cast("int"))
      .withColumn("risklevel_high_sys",$"risklevel_high_sys_tmp".cast("int"))
      .withColumn("risklevel_high_ai",$"risklevel_high_ai_tmp".cast("int"))
      .withColumn("recount",$"recount_tmp".cast("int"))
      .withColumn("touchcount",$"touchcount_tmp".cast("int"))
      .withColumn("ntntruedevice",$"ntntruedevice_tmp".cast("int"))
      .withColumn("ntnfaildevice",$"ntnfaildevice_tmp".cast("int"))
      .withColumn("aiudqua",$"aiudqua_tmp".cast("int"))
      .withColumn("ttsnum",$"ttsnum_tmp".cast("int"))
      .withColumn("fleetnum",$"fleetnum_tmp".cast("int"))
      .withColumn("roadtime",round($"roadtime_tmp".cast("int")/3600,4))
      .withColumn("inc_day",lit(input_inc_day3))

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dws_datacode_alarm_level_week limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark, result_data2.coalesce(1).select(table_cols: _*), Seq("inc_day"), "dm_gis.dws_datacode_alarm_level_week")

  }

}
