package app.safety

import app.safety.HwToSfHive.logger
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkUtils
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, desc, regexp_replace, row_number}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import java.util

/**
 *需求名称：华为云护航数据同步至顺丰云hive表
 *需求描述：由于当前疑似事故管理算法准确率较低，希望Q3成立专项提升该算法准确率，以实现功能的优化。现需要大批量提取数据用以分析，以支撑算法优化策略，因此需要将护航平台该数据同步至bdp。
 *需求方：ft220315 樊星
 *开发: 01390943 周勇
 *任务创建时间：20230810
 *任务id：787082，本任务用于刷新历史数据，每次手动执行
 **/

object HwToSfHiveHistory extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取传入参数日期:昨日日期
    val dayvar = args(0)
    //执行回跑历史数据
    //suspe_accident_all(spark:SparkSession,dayvar:String)

    //从kafka提取所需要的数据：数组格式推送
    val kafka_data_array=spark.sql(
      s"""
         |select log,time from dm_gis.insurance_model_duration_dist_daily_qgzh_kafka
         |where inc_day='$dayvar'  and log like '%safety-escort%'
         | and log like '%"data":"[%'
         |""".stripMargin).persist(StorageLevel.MEMORY_AND_DISK)
    fleet_buried_operation_fun(kafka_data_array,spark,dayvar)
    fleet_buried_page_fun(kafka_data_array,spark,dayvar)
    spark.close()
  }



  //清洗fleet_buried_operation表
  def fleet_buried_operation_fun(kafka_data_array:DataFrame,spark:SparkSession,dayvar:String): Unit ={
    import spark.implicits._
    logger.error(">>>>fleet_buried_operation开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data_array.filter($"log".like("%fleet_buried_operation%") && $"log".like("%\"data\":\"[%") )
    //转成rdd数据
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 10)

    val x_seq_result= x_seq_rdd.flatMap(obj => {

      val obj_arr=obj.getJSONObject("log").getJSONArray("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      obj.put("data_time", data_time)
      val tmpList = new util.ArrayList[JSONObject]()
      val s=obj_arr.size()

      for (i <- 0 until(s)) {
        val tmp = new JSONObject()
        tmp.fluentPutAll(obj)
        val obj_i: JSONObject = obj_arr.getJSONObject(i)
        tmp.put("obj_i", obj_i)
        tmpList.add(tmp)
      }
      tmpList.iterator()
    })

    val x_seq_result2=x_seq_result.map(obj=>{

      val data_time=obj.getString("data_time")
      val obj_i=obj.getString("obj_i")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var userid =""
      var client =""
      var datacode =""
      var deptname =""
      var operationbutton =""
      var operationfrom =""
      var operationapi =""
      var operationparams =""
      var createtime =""
      var date =""
      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)
        uniqid=obj_i_js.getString("uniqid")
        //用uniqid替换id
        id=obj_i_js.getString("uniqid")
        userid=obj_i_js.getString("userId")
        client=obj_i_js.getString("client")
        datacode=obj_i_js.getString("dataCode")
        deptname=obj_i_js.getString("deptName")
        operationbutton=obj_i_js.getString("operationButton")
        operationfrom=obj_i_js.getString("operationFrom")
        operationapi=obj_i_js.getString("operationApi")
        operationparams=obj_i_js.getString("operationParams")
        createtime=obj_i_js.getString("createTime")
        date=obj_i_js.getString("date")
      }
      (id,userid,client,datacode,deptname,operationbutton,operationfrom,
        operationapi,operationparams,createtime,date,uniqid,data_time)
    }).toDF("id","userid","client","datacode","deptname","operationbutton","operationfrom",
      "operationapi","operationparams","createtime","date","uniqid","data_time")
      .withColumn("inc_day",$"data_time")
      .filter($"inc_day">="20230928" and $"inc_day"<="20231007")
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_fleet_buried_operation limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_fleet_buried_operation")

    logger.error(">>>>dm_fleet_buried_operation任务已完成！")
  }

  //清洗fleet_buried_page表
  def fleet_buried_page_fun(kafka_data_array:DataFrame,spark:SparkSession,dayvar:String): Unit ={
    import spark.implicits._
    logger.error(">>>>fleet_buried_page开始落表：")
    //获取目标表数据
    val mb_tb=kafka_data_array.filter($"log".like("%fleet_buried_page%") && $"log".like("%\"data\":\"[%") )
    //转成rdd数据
    val x_seq_rdd= SparkUtils.getDfToJson(spark, mb_tb, 10)

    val x_seq_result= x_seq_rdd.flatMap(obj => {

      val obj_arr=obj.getJSONObject("log").getJSONArray("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      obj.put("data_time", data_time)
      val tmpList = new util.ArrayList[JSONObject]()
      val s=obj_arr.size()

      for (i <- 0 until(s)) {
        val tmp = new JSONObject()
        tmp.fluentPutAll(obj)
        val obj_i: JSONObject = obj_arr.getJSONObject(i)
        tmp.put("obj_i", obj_i)
        tmpList.add(tmp)
      }
      tmpList.iterator()
    })

    val x_seq_result2=x_seq_result.map(obj=>{

      val data_time=obj.getString("data_time")
      val obj_i=obj.getString("obj_i")
      var uniqid=""
      //以下是各个表的解析字段
      var id =""
      var client =""
      var userid =""
      var datacode =""
      var deptname =""
      var pageurl =""
      var pagename =""
      var inserttime =""
      var exittime =""
      var staytime =""
      var date =""
      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)
        uniqid=obj_i_js.getString("uniqid")
        //用uniqid替换id
        id=obj_i_js.getString("uniqid")
        userid=obj_i_js.getString("userId")
        client=obj_i_js.getString("client")
        datacode=obj_i_js.getString("dataCode")
        deptname=obj_i_js.getString("deptName")
        pageurl=obj_i_js.getString("pageUrl")
        pagename=obj_i_js.getString("pageName")
        inserttime=obj_i_js.getString("insertTime")
        exittime=obj_i_js.getString("exitTime")
        staytime=obj_i_js.getString("stayTime")
        date=obj_i_js.getString("date")
      }
      (id,userid,client,datacode,deptname,pageurl,
        pagename,inserttime,exittime,staytime,date,uniqid,data_time)
    }).toDF("id","userid","client","datacode","deptname","pageurl",
      "pagename","inserttime","exittime","staytime","date","uniqid","data_time")
      .withColumn("inc_day",$"data_time")
      .filter($"inc_day">="20230928" and $"inc_day"<="20231007")
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_fleet_buried_page limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_fleet_buried_page")

    logger.error(">>>>fleet_buried_page任务已完成！")
  }


  def suspe_accident_all(spark:SparkSession,dayvar:String): Unit = {
    import spark.implicits._
    //从kafka提取所需要的数据
    val kafka_data=spark.sql(
      s"""
         |select log,time from dm_gis.insurance_model_duration_dist_daily_qgzh_kafka
         |where inc_day='$dayvar' and log like '%safety-escort:suspe_accident%' and log like '%"data":"[%'
         |""".stripMargin)

    logger.error("kafka_data数据量："+kafka_data.count())

    //循环刷历史数据
    val x_seq_rdd= SparkUtils.getDfToJson(spark, kafka_data, 10)

    val x_seq_result= x_seq_rdd.flatMap(obj => {

      val obj_arr=obj.getJSONObject("log").getJSONArray("data")
      val data_time=obj.getJSONObject("log").getString("time").replace("-","")
      obj.put("data_time", data_time)
      val tmpList = new util.ArrayList[JSONObject]()
      val s=obj_arr.size()

      for (i <- 0 until(s)) {
        val tmp = new JSONObject()
        tmp.fluentPutAll(obj)
        val obj_i: JSONObject = obj_arr.getJSONObject(i)
        tmp.put("obj_i", obj_i)
        tmpList.add(tmp)
      }
      tmpList.iterator()
    })

    logger.error("x_seq_result数据量："+x_seq_result.count())

    val x_seq_result2=x_seq_result.map(obj=>{

      //val log=obj.getString("log")
      val data_time=obj.getString("data_time")
      val obj_i=obj.getString("obj_i")
      //以下是各个表的解析字段
      var alarmid=""
      var carno=""
      var imei=""
      var zytype=""
      var alarmtime=""
      var alarmname=""
      var drivercode=""
      var deptname=""
      var firstdeptname=""
      var datacode=""
      var from_source=""
      var accidentlat=""
      var accidentlng=""
      var accidentaddr=""
      var accidenttime=""
      var accidentcreatetime=""
      var accidentauditresult=""
      var createtime=""
      var uniqid=""
      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)
        alarmid=obj_i_js.getString("alarmId")
        carno=obj_i_js.getString("carNo")
        imei=obj_i_js.getString("imei")
        zytype=obj_i_js.getString("zyType")
        alarmtime=obj_i_js.getString("alarmTime")
        alarmname=obj_i_js.getString("alarmName")
        drivercode=obj_i_js.getString("driverCode")
        deptname=obj_i_js.getString("deptName")
        firstdeptname=obj_i_js.getString("firstDeptName")
        datacode=obj_i_js.getString("dataCode")
        from_source=obj_i_js.getString("from")
        accidentlat=obj_i_js.getString("accidentLat")
        accidentlng=obj_i_js.getString("accidentLng")
        accidentaddr=obj_i_js.getString("accidentAddr")
        accidenttime=obj_i_js.getString("accidentTime")
        accidentcreatetime=obj_i_js.getString("accidentCreateTime")
        accidentauditresult=obj_i_js.getString("accidentAuditResult")
        createtime=obj_i_js.getString("createTime")
        uniqid=obj_i_js.getString("uniqid")
      }

      (data_time,obj_i,alarmid,carno,imei,zytype,alarmtime,alarmname,drivercode,deptname,
        firstdeptname,datacode,from_source,accidentlat,accidentlng,accidentaddr,
        accidenttime,accidentcreatetime,accidentauditresult,createtime,uniqid)
    }).toDF("data_time","obj_i","alarmid","carno","imei","zytype","alarmtime","alarmname","drivercode","deptname",
      "firstdeptname","datacode","from_source","accidentlat","accidentlng","accidentaddr",
      "accidenttime","accidentcreatetime","accidentauditresult","createtime","uniqid")
      .withColumn("inc_day",$"data_time")
      .withColumn("rank",row_number().over(Window.partitionBy("uniqid").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
      .filter($"inc_day".isin("20230928","20230929","20230930","20231001","20231002","20231003","20231004","20231005","20231006","20231007"))

    logger.error("x_seq_result2数据量："+x_seq_result2.count())

    //spark.sql("drop table if exists tmp_dm_gis.tempzy20230110x_seq_result2")
    //x_seq_result2.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tempzy20230110x_seq_result2")

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_suspe_accident limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark,x_seq_result2 .select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_suspe_accident")

    logger.error(">>>>任务已完成！")
  }

}
