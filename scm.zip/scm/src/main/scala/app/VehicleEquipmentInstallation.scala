package app

import java.text.SimpleDateFormat
import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
 * @Description:路桥费账单信息统计
 * 需求人员：ft220315 樊星
 * @Author: lixiangzhi 01405644
 * @Date:20240119
 * 任务id:971347
 * 任务名称：erp车队设备数据解析flow
 * 依赖任务：无
 * 数据源：dm_gis.erp_log
 * 调用服务地址：无
 * 数据结果：dm_vehicle_equipment_installation
 */
object VehicleEquipmentInstallation {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readSourceData(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val jsonObj="$"
    val erpLogSql=
      s"""
        |select bizkey,status,createtime,createname,createnickname,updatetime,updatename,closestatus,closereason,from1,projectid,carno,fremano,imei,
        |iccid,assignusername,assigntime,customername,customerphone,installaddr,devicetype,specs,orderreceive,orderreceiveuserid,orderreceivecompanycode,
        |orderexecuteuserid,orderexecuteusername,orderexecutephone,orderreceivetime,audit,audittime,auditusername,auditnickname,enddate,
        |vehiclemodel,load,salesorderno,fcarriageno,fdate,installstatus,commitdate,deal_records,outsideinstall,drivername,driverphone,data
        |from
        |(
        |SELECT
        |    get_json_object(data, '$jsonObj.bizKey') AS bizKey,
        |    get_json_object(data, '$jsonObj.status') AS status,
        |    get_json_object(data, '$jsonObj.createTime') AS createTime,
        |    get_json_object(data, '$jsonObj.createName') AS createName,
        |    get_json_object(data, '$jsonObj.createNickname') AS createNickname,
        |    get_json_object(data, '$jsonObj.updateTime') AS updateTime,
        |    get_json_object(data, '$jsonObj.updateName') AS updateName,
        |    get_json_object(data, '$jsonObj.closeStatus') AS closeStatus,
        |    get_json_object(data, '$jsonObj.closeReason') AS closeReason,
        |    get_json_object(data, '$jsonObj.from') AS from1,
        |    get_json_object(data, '$jsonObj.projectId') AS projectId,
        |    get_json_object(data, '$jsonObj.carNo') AS carNo,
        |    get_json_object(data, '$jsonObj.fremaNo') AS fremaNo,
        |    get_json_object(data, '$jsonObj.imei') AS imei,
        |    get_json_object(data, '$jsonObj.iccid') AS iccid,
        |    get_json_object(data, '$jsonObj.assignUsername') AS assignUsername,
        |    get_json_object(data, '$jsonObj.assignTime') AS assignTime,
        |    get_json_object(data, '$jsonObj.orderType') AS orderType,
        |    get_json_object(data, '$jsonObj.problemType') AS problemType,
        |    get_json_object(data, '$jsonObj.problemPart') AS problemPart,
        |    get_json_object(data, '$jsonObj.serviceType') AS serviceType,
        |    get_json_object(data, '$jsonObj.customerContactName') AS customerContactName,
        |    get_json_object(data, '$jsonObj.customerContactPhone') AS customerContactPhone,
        |    get_json_object(data, '$jsonObj.needSendBack') AS needSendBack,
        |    get_json_object(data, '$jsonObj.receiverName') AS receiverName,
        |    get_json_object(data, '$jsonObj.receiverPhone') AS receiverPhone,
        |    get_json_object(data, '$jsonObj.receiverAddr') AS receiverAddr,
        |    get_json_object(data, '$jsonObj.picAddr') AS picAddr,
        |    get_json_object(data, '$jsonObj.problemContent') AS problemContent,
        |    get_json_object(data, '$jsonObj.advice') AS advice,
        |    get_json_object(data, '$jsonObj.remark') AS remark,
        |    get_json_object(data, '$jsonObj.assignToRole') AS assignToRole,
        |    get_json_object(data, '$jsonObj.assignTo') AS assignTo,
        |    get_json_object(data, '$jsonObj.assignToNickname') AS assignToNickname,
        |    get_json_object(data, '$jsonObj.orderReceiveStatus') AS orderReceiveStatus,
        |    get_json_object(data, '$jsonObj.toOpsOrder') AS toOpsOrder,
        |    get_json_object(data, '$jsonObj.endDate') AS endDate,
        |    get_json_object(data, '$jsonObj.customerName') AS customerName,
        |    get_json_object(data, '$jsonObj.customerPhone') AS customerPhone,
        |    get_json_object(data, '$jsonObj.installAddr') AS installAddr,
        |    get_json_object(data, '$jsonObj.deviceType') AS deviceType,
        |    get_json_object(data, '$jsonObj.specs') AS specs,
        |    get_json_object(data, '$jsonObj.orderReceive') AS orderReceive,
        |    get_json_object(data, '$jsonObj.orderReceiveUserid') AS orderReceiveUserid,
        |    get_json_object(data, '$jsonObj.orderReceiveCompanycode') AS orderReceiveCompanycode,
        |    get_json_object(data, '$jsonObj.orderExecuteUserid') AS orderExecuteUserid,
        |    get_json_object(data, '$jsonObj.orderExecuteUsername') AS orderExecuteUsername,
        |    get_json_object(data, '$jsonObj.orderExecutePhone') AS orderExecutePhone,
        |    get_json_object(data, '$jsonObj.orderReceiveTime') AS orderReceiveTime,
        |    get_json_object(data, '$jsonObj.audit') AS audit,
        |    get_json_object(data, '$jsonObj.auditTime') AS auditTime,
        |    get_json_object(data, '$jsonObj.auditUsername') AS auditUsername,
        |    get_json_object(data, '$jsonObj.auditNickname') AS auditNickname,
        |    get_json_object(data, '$jsonObj.sendNo') AS sendNo,
        |    get_json_object(data, '$jsonObj.sendDate') AS sendDate,
        |    get_json_object(data, '$jsonObj.supplier') AS supplier,
        |    get_json_object(data, '$jsonObj.planVisitDate') AS planVisitDate,
        |    get_json_object(data, '$jsonObj.visitDate') AS visitDate,
        |    get_json_object(data, '$jsonObj.sendImei') AS sendImei,
        |    get_json_object(data, '$jsonObj.sendSn') AS sendSn,
        |    get_json_object(data, '$jsonObj.sendIccid') AS sendIccid,
        |    get_json_object(data, '$jsonObj.backNo') AS backNo,
        |    get_json_object(data, '$jsonObj.backPart') AS backPart,
        |    get_json_object(data, '$jsonObj.solution') AS solution,
        |    get_json_object(data, '$jsonObj.result') AS result,
        |    get_json_object(data, '$jsonObj.beginDate') AS beginDate,
        |    get_json_object(data, '$jsonObj.opsRecord') AS opsRecord,
        |    get_json_object(data, '$jsonObj.backImei') AS backImei,
        |    get_json_object(data, '$jsonObj.backSn') AS backSn,
        |    get_json_object(data, '$jsonObj.backIccid') AS backIccid,
        |    get_json_object(data, '$jsonObj.installImei') AS installImei,
        |    get_json_object(data, '$jsonObj.installSn') AS installSn,
        |    get_json_object(data, '$jsonObj.installIccid') AS installIccid,
        |    get_json_object(data, '$jsonObj.vehicleModel') AS vehiclemodel,
        |    get_json_object(data, '$jsonObj.load') AS load,
        |    get_json_object(data, '$jsonObj.salesorderNo') AS salesorderno,
        |    get_json_object(data, '$jsonObj.fcarriageno') AS fcarriageno,
        |    get_json_object(data, '$jsonObj.fdate') AS fdate,
        |    get_json_object(data, '$jsonObj.installStatus') AS installstatus,
        |    get_json_object(data, '$jsonObj.commitDate') AS commitdate,
        |    get_json_object(data, '$jsonObj.installOrderRecordDtoList') AS deal_records,
        |    get_json_object(data, '$jsonObj.outSideInstall') AS outsideinstall,
        |    get_json_object(data, '$jsonObj.driverName') AS drivername,
        |    get_json_object(data, '$jsonObj.driverPhone') AS driverphone,
        |    data
        |FROM
        |    (select  get_json_object(log,'$jsonObj.data') as data,get_json_object(log,'$jsonObj.type') as type from dm_gis.erp_log where inc_day='${incDay}') t
        |	where type='0'
        |) tt
        |""".stripMargin
    val vehicleEquipmentInstallationDf: DataFrame = SparkUtils.getRowToJsonClear(spark, erpLogSql).map(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val installOrderRecordDtoList: JSONArray = JSONUtil.getJsonArrayMulti(dataObj, "installOrderRecordDtoList")
      val installOrderRecordDtoArray = new util.ArrayList[(String, String)]()
      for (i <- 0 until (installOrderRecordDtoList.size())) {
        val installOrderRecordDtoListObj: JSONObject = installOrderRecordDtoList.getJSONObject(i)
        val uninstallReason: String = installOrderRecordDtoListObj.getString("uninstallReason")
        val updateTime: String = installOrderRecordDtoListObj.getString("updateTime")
        installOrderRecordDtoArray.append((uninstallReason, updateTime))
      }
      if (installOrderRecordDtoArray.nonEmpty) {
        val maxInstallOrderRecordDto: (String, String) = installOrderRecordDtoArray.maxBy(_._2)
        val uninstallReason: String = maxInstallOrderRecordDto._1
        obj.put("uninstallreason", uninstallReason)
      }
      obj.remove("data")
      obj
    }).map(obj => {
      CaseVehicleEquipmentInstallation(
        obj.getString("bizkey"),
        obj.getString("status"),
        obj.getString("createtime"),
        obj.getString("createname"),
        obj.getString("createnickname"),
        obj.getString("updatetime"),
        obj.getString("updatename"),
        obj.getString("closestatus"),
        obj.getString("closereason"),
        obj.getString("from1"),
        obj.getString("projectid"),
        obj.getString("carno"),
        obj.getString("fremano"),
        obj.getString("imei"),
        obj.getString("iccid"),
        obj.getString("assignusername"),
        obj.getString("assigntime"),
        obj.getString("customername"),
        obj.getString("customerphone"),
        obj.getString("installaddr"),
        obj.getString("devicetype"),
        obj.getString("specs"),
        obj.getString("orderreceive"),
        obj.getString("orderreceiveuserid"),
        obj.getString("orderreceivecompanycode"),
        obj.getString("orderexecuteuserid"),
        obj.getString("orderexecuteusername"),
        obj.getString("orderexecutephone"),
        obj.getString("orderreceivetime"),
        obj.getString("audit"),
        obj.getString("audittime"),
        obj.getString("auditusername"),
        obj.getString("auditnickname"),
        obj.getString("enddate"),
        obj.getString("vehiclemodel"),
        obj.getString("load"),
        obj.getString("salesorderno"),
        obj.getString("fcarriageno"),
        obj.getString("fdate"),
        obj.getString("installstatus"),
        obj.getString("commitdate"),
        obj.getString("deal_records"),
        obj.getString("outsideinstall"),
        obj.getString("drivername"),
        obj.getString("driverphone"),
        obj.getString("uninstallreason")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,vehicleEquipmentInstallationDf,"inc_day",incDay,"dm_gis.dm_vehicle_equipment_installation")

  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取表erp_log,并解析字段
    readSourceData(spark, incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    logger.error("incDay:"+incDay)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseVehicleEquipmentInstallation(
                                              bizkey:String,
                                              status:String,
                                              createtime:String,
                                              createname:String,
                                              createnickname:String,
                                              updatetime:String,
                                              updatename:String,
                                              closestatus:String,
                                              closereason:String,
                                              from1:String,
                                              projectid:String,
                                              carno:String,
                                              fremano:String,
                                              imei:String,
                                              iccid:String,
                                              assignusername:String,
                                              assigntime:String,
                                              customername:String,
                                              customerphone:String,
                                              installaddr:String,
                                              devicetype:String,
                                              specs:String,
                                              orderreceive:String,
                                              orderreceiveuserid:String,
                                              orderreceivecompanycode:String,
                                              orderexecuteuserid:String,
                                              orderexecuteusername:String,
                                              orderexecutephone:String,
                                              orderreceivetime:String,
                                              audit:String,
                                              audittime:String,
                                              auditusername:String,
                                              auditnickname:String,
                                              enddate:String,
                                              vehiclemodel:String,
                                              load:String,
                                              salesorderno:String,
                                              fcarriageno:String,
                                              fdate:String,
                                              installstatus:String,
                                              commitdate:String,
                                              deal_records:String,
                                              outsideinstall:String,
                                              drivername:String,
                                              driverphone:String,
                                              uninstallReason:String
                                             )

}
