package app

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * 需求内容：将员工信息维表同步到gm_gis库
 * 需求方：李非龙（ft220114）
 * @author 徐游飞（01417347）
 * 任务ID：869626
 * 任务名称：计提数据同步hive
 */
object DimEmpInfoDf2Hive {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("+++++++++    任务开始  20231016 !!!    ++++++++")

    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    val dim_sql =
      s"""
         |select
         |  *
         |from
         |  dim.dim_emp_info_df
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("员工维表取数sql：")
    println(dim_sql)
    val df_prices = spark.sql(dim_sql)


    val cols_2 = spark.sql("""select * from dm_gis.emp_info_newest limit 0""").schema.map(_.name).map(col)
    writeToHiveNoP(spark, df_prices.select(cols_2: _*), "dm_gis.emp_info_newest")

    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")
    logger.error("+++++++++    任务结束  20231016 !!!    ++++++++")
    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")
  }

  /**
   * 把df数据覆盖写入到不分区hive表
   *
   * @param spark
   * @param dataframe
   * @param resTableName hive表名
   */
  def writeToHiveNoP(spark: SparkSession, dataframe: DataFrame, resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert overwrite table %s select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }


}
