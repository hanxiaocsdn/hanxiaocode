package app

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import common.DataSourceCommon
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

/**
 * GIS_RSS_SCM 【导航监控】司机&车辆维度导航调用量统计需求
 * 需求方：李非龙（ft220114）
 * @author 徐游飞（01417347）
 * 任务ID：669976
 * 任务名称：司机&车辆维度导航调用量统计
 */
object EtaStdLineDriverAndVehicle extends  DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")

  def getDataSouse(spark: SparkSession, dayBefore1: Any) = {
    import spark.implicits._
    // 获取eta标准线路回溯结果2数据
    val result2_sql =
      s"""
         |select
         |  driver_id,
         |  vehicle_serial,
         |  task_id,
         |  carrier_type,
         |  task_area_code,
         |  inc_day,
         |  count(*) as cnt
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day = '$dayBefore1'
         |group by
         |  driver_id,
         |  vehicle_serial,
         |  task_id,
         |  carrier_type,
         |  task_area_code,
         |  inc_day
         |""".stripMargin
    println("获取recall_result2表数据 sql语句：")
    println(result2_sql)
    val df_result2 = spark.sql(result2_sql).drop("cnt")

    val parse_sql =
      s"""
         |select
         |  task_id,
         |  content,
         |  end_type,
         |  type as log_type,
         |  '11' as join_tag,
         |  count(*) as cnt
         |from
         |  dm_gis.gis_navi_sdk_navi_parse
         |where
         |  inc_day = '$dayBefore1'
         |group by
         |  task_id,
         |  content,
         |  end_type,
         |  type
         |""".stripMargin
    println("获取parse表数据 sql语句：")
    println(parse_sql)
    val df_parse = spark.sql(parse_sql).drop("cnt")

    val df_source = df_result2.join(df_parse, Seq("task_id"), "left")

    df_source
  }

  def main(args: Array[String]): Unit = {

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    logger.error("incDay="+ incDay)
    logger.error("dayBefore1="+ dayBefore1)

    // 获取数据
    val df_source = getDataSouse(spark, dayBefore1).persist(StorageLevel.MEMORY_AND_DISK)

    import spark.implicits._
    val df_driver = df_source.groupBy("carrier_type","task_area_code","inc_day")
      .agg(
        //司机维度
        countDistinct('driver_id) as "driver_execute_num",
        countDistinct(when('carrier_type === "0", 'driver_id).otherwise(null)) as "driver_execute_zy_num",
        countDistinct(when('carrier_type === "1", 'driver_id).otherwise(null)) as "driver_execute_wb_num",
        // 进入导航
        countDistinct(when('join_tag === "11", 'driver_id).otherwise(null)) as "driver_entry_navi_num",
        countDistinct(when('join_tag === "11" and 'carrier_type === "0", 'driver_id).otherwise(null)) as "driver_entry_navi_zy_num",
        countDistinct(when('join_tag === "11" and 'carrier_type === "1", 'driver_id).otherwise(null)) as "driver_entry_navi_wb_num",
        // 开始导航
        countDistinct(when('join_tag === "11" and 'log_type === "1", 'driver_id).otherwise(null)) as "driver_start_navi_num",
        countDistinct(when('join_tag === "11" and 'log_type === "1" and 'carrier_type === "0", 'driver_id).otherwise(null)) as "driver_start_navi_zy_num",
        countDistinct(when('join_tag === "11" and 'log_type === "1" and 'carrier_type === "1", 'driver_id).otherwise(null)) as "driver_start_navi_wb_num",
        // 结束导航
        countDistinct(when('join_tag === "11" and 'log_type === "3" and 'end_type === "2", 'driver_id).otherwise(null)) as "driver_end_navi_num",
        countDistinct(when('join_tag === "11" and 'log_type === "3" and 'end_type === "2" and 'carrier_type === "0", 'driver_id).otherwise(null)) as "driver_end_navi_zy_num",
        countDistinct(when('join_tag === "11" and 'log_type === "3" and 'end_type === "2" and 'carrier_type === "1", 'driver_id).otherwise(null)) as "driver_end_navi_wb_num",

        //车辆维度
        countDistinct('vehicle_serial) as "vehicle_execute_num",
        countDistinct(when('carrier_type === "0", 'vehicle_serial).otherwise(null)) as "vehicle_execute_zy_num",
        countDistinct(when('carrier_type === "1", 'vehicle_serial).otherwise(null)) as "vehicle_execute_wb_num",
        // 进入导航
        countDistinct(when('join_tag === "11", 'vehicle_serial).otherwise(null)) as "vehicle_entry_navi_num",
        countDistinct(when('join_tag === "11" and 'carrier_type === "0", 'vehicle_serial).otherwise(null)) as "vehicle_entry_navi_zy_num",
        countDistinct(when('join_tag === "11" and 'carrier_type === "1", 'vehicle_serial).otherwise(null)) as "vehicle_entry_navi_wb_num",
        // 开始导航
        countDistinct(when('join_tag === "11" and 'log_type === "1", 'vehicle_serial).otherwise(null)) as "vehicle_start_navi_num",
        countDistinct(when('join_tag === "11" and 'log_type === "1" and 'carrier_type === "0", 'vehicle_serial).otherwise(null)) as "vehicle_start_navi_zy_num",
        countDistinct(when('join_tag === "11" and 'log_type === "1" and 'carrier_type === "1", 'vehicle_serial).otherwise(null)) as "vehicle_start_navi_wb_num",
        // 结束导航
        countDistinct(when('join_tag === "11" and 'log_type === "3" and 'end_type === "2", 'vehicle_serial).otherwise(null)) as "vehicle_end_navi_num",
        countDistinct(when('join_tag === "11" and 'log_type === "3" and 'end_type === "2" and 'carrier_type === "0", 'vehicle_serial).otherwise(null)) as "vehicle_end_navi_zy_num",
        countDistinct(when('join_tag === "11" and 'log_type === "3" and 'end_type === "2" and 'carrier_type === "1", 'vehicle_serial).otherwise(null)) as "vehicle_end_navi_wb_num"
      )

    val cols_driver = spark.sql("""select * from dm_gis.eta_std_line_driver_vehicle limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_driver.select(cols_driver: _*),Seq("inc_day"),"dm_gis.eta_std_line_driver_vehicle")


    val df_detail = df_source
      .withColumn("entry_type",when('join_tag === "11", 0).otherwise(1))
      .withColumn("start_type",when('join_tag === "11" and 'log_type === "1", 0).otherwise(1))
      .withColumn("end_type",when('join_tag === "11" and 'log_type === "3" and 'end_type === "2", 0).otherwise(1))
      .groupBy("driver_id","carrier_type","entry_type","start_type","end_type")
      .agg(
        count("driver_id") as "num_dtl"
      )
      .withColumn("inc_day",lit(dayBefore1))

    val cols_detail = spark.sql("""select * from dm_gis.eta_std_line_driver_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_detail.select(cols_detail: _*),Seq("inc_day"),"dm_gis.eta_std_line_driver_detail")

    df_source.unpersist()
    logger.error("++++++++  任务完成  20230828  ++++")
    spark.stop()
  }
}
