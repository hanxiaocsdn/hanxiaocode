package com.sf.gis.java.sx.constant.util;


import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by 01375125 on 2018/7/9.
 * java工具类
 */
public class JavaUtil implements Serializable{

    private static final long serialVersionUID = 147258369L;
    // 1-测试，
    // 2-oms生产，
    // 3-派件妥投生产
    // 4-线下日志
    // 5-输入提示的
    // 6-路由分单的
    // 7-高低精审补库测试
    // 8-高低精审补库生产
    // 9-错分生产
    // 11-重量区间

    public static int EN = 2;

    private int flag;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public JavaUtil(int flag) {
        this.flag = flag;
    }

    public JavaUtil() {
    }

    /**
     * 获取配置文件中属性
     * @param key: key
     * @return String: 结果
     */
    public static String getString(String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {

            String configPath = null;
            if(EN == 1)//测试的库
                configPath = "debug-config.properties";
            else if(EN == 2)//生产的库
                configPath = "pro-config.properties";
            else if(EN == 3)//错分的项目
                configPath = "wrong-config.properties";
            else if(EN == 4)//oms离线的项目
                configPath = "offline_pro-config.properties";
            else if(EN == 5)//输入提示的项目
                configPath = "input.properties";
            else if(EN == 6)//rds路由分单的项目
                configPath = "conf/rds.properties";
            else if(EN == 7)//高低精库测试
                configPath = "precision_debug.properties";
            else if(EN == 8)//高低精库生产
                configPath = "precision.properties";
            else if(EN == 9)//错分测试
                configPath = "wd.properties";
            else if(EN == 10)//错分生产
                configPath = "wd.properties";
            in = JavaUtil.class.getClassLoader().getResourceAsStream(configPath);
//            in = AppConfig.class.getClassLoader().getResourceAsStream(configPath);

            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }


    /**
     * 获取配置文件中属性
     * @param key: key
     * @return String: 结果
     */
    public  String get(String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {

            String configPath = null;
            if(flag == 1)//测试的库
                configPath = "debug-config.properties";
            else if(flag == 2)//生产的库
                configPath = "pro-config.properties";
            else if(flag == 3)//错分的项目
                configPath = "wrong-config.properties";
            else if(flag == 4)//oms离线的项目
                configPath = "offline_pro-config.properties";
            else if(flag == 5)//输入提示的项目
                configPath = "input.properties";
            else if(flag == 6)//rds路由分单的项目
                configPath = "conf/rds.properties";
            else if(flag == 7)//高低精库测试
                configPath = "precision_debug.properties";
            else if(flag == 8)//高低精库生产
                configPath = "precision.properties";
            else if(flag == 9)//错分测试
                configPath = "wd.properties";
            else if(flag == 10)//错分生产
                configPath = "wd.properties";
            else if(flag == 11)//重量区间映射数据
                configPath = "kafka-weight.properties";
            in = JavaUtil.class.getClassLoader().getResourceAsStream(configPath);
//            in = AppConfig.class.getClassLoader().getResourceAsStream(configPath);
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }




    /**
     * 获取某个配置文件中某个属性的值
     * @param key: key
     * @return String: 结果
     */
    public static String get(String configName,String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {
            in = JavaUtil.class.getClassLoader().getResourceAsStream(configName);
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }


    /**
     * 读取资源文件
     * @param fileName: 文件名
     * @return String: 结果
     */
    @SuppressWarnings("unused")
    public static Properties getProp(String fileName) {
        Properties props = new Properties();

        try (InputStreamReader in = new InputStreamReader(JavaUtil.class.getClassLoader().getResourceAsStream(fileName), "utf-8")) {
            props.load(in);
        } catch (IOException e) {
            System.out.println("Load properties file error! file name:" + fileName + "\n" + e);
        }
        return props;
    }

    /**
     * 读取资源文件
     * @param key: key
     * @return String: 结果
     */
    public static String get(String key,Properties props) {
        return props.getProperty(key);
    }


    /**
     * 读取资源文件
     * @param fileName: 文件名
     * @return String: 结果
     */
    public static BufferedReader readFile(String fileName) {
        BufferedReader buff = null;
        try{
            InputStreamReader in = new InputStreamReader(JavaUtil.class.getClassLoader().getResourceAsStream(fileName), "utf-8");
            buff = new BufferedReader(in);
        }catch(IOException ignored){

        }
        return buff;
    }


    /**
     * 读取资源文件
     * @param fileName: 文件名
     * @return String: 结果
     */
    public static InputStream readFileAsIn(String fileName) {
        InputStream ins = null;
        try {
            ins = JavaUtil.class.getClassLoader().getResourceAsStream(fileName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ins;
    }

    public List<String> forDate(String date1, String date2) {
        // 日期格式化
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        List<String> list = new ArrayList<>();
        try {
            // 起始日期
            Date d1 = sdf.parse(date1);
            // 结束日期
            Date d2 = sdf.parse(date2);
            Date tmp = d1;
            Calendar dd = Calendar.getInstance();
            dd.setTime(d1);
            // 打印date1到2date2的日期
            while (tmp.getTime() < d2.getTime()) {
                tmp = dd.getTime();
                //System.out.println(sdf.format(tmp));
                list.add(sdf.format(tmp));
                // 天数加上1
                dd.add(Calendar.DAY_OF_MONTH, 1);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 将汉字转换为全拼
     *
     * @param text 文本
     * @return {@link String}
     */
    public static String getPinyin(String text, String separator) {
        char[] chars = text.toCharArray();
        HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();
        // 设置大小写
        format.setCaseType(HanyuPinyinCaseType.LOWERCASE);
        // 设置声调表示方法
        format.setToneType(HanyuPinyinToneType.WITH_TONE_NUMBER);
        // 设置字母u表示方法
        format.setVCharType(HanyuPinyinVCharType.WITH_V);
        String[] s;
        String rs = StringUtils.EMPTY;
        try {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < chars.length; i++) {
                // 判断是否为汉字字符
                if (String.valueOf(chars[i]).matches("[\\u4E00-\\u9FA5]+")) {
                    s = PinyinHelper.toHanyuPinyinStringArray(chars[i], format);
                    if (s != null) {
                        sb.append(s[0]).append(separator);
                        continue;
                    }
                }
                sb.append(String.valueOf(chars[i]));
                if ((i + 1 >= chars.length) || String.valueOf(chars[i + 1]).matches("[\\u4E00-\\u9FA5]+")) {
                    sb.append(separator);
                }
            }
            rs = sb.substring(0, sb.length());
        } catch (BadHanyuPinyinOutputFormatCombination e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static String outputArabNumberString(String chineseNumberString){
        //String reg = "[零一二三四五六七八九十百佰千仟万萬亿億]+";
        String reg = "[〇一二三四五六七八九零壹贰叁肆伍陆柒捌玖貮两十拾百佰千仟万萬亿億]+";
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(chineseNumberString);
        List<String> chineseNumbers = new ArrayList<>(21);
        List<Integer> arabNumbers = new ArrayList<>(21);
        boolean isNumberFirst = false;
        while(matcher.find()){
            chineseNumbers.add(matcher.group());
            // 转化成阿拉伯数字
            int arabNum = transferChineseNumber2ArabNumber(matcher.group());
            arabNumbers.add(arabNum);
        }
        String[] arrStr = chineseNumberString.split(reg);

        StringBuilder transferedNumber = new StringBuilder();

        // 数字的数量不大于文字的数量。
        // 如果结尾不是数字，则文字数量比数字数量多一（即使数字位于第一个也不会有影响）；如果结尾是数字，则数字文本数量相等。
        for(int i =0 ;i<arrStr.length;i++){
            // 先拼文字再拼数字，即使数字在第一个也会存在一个空的字符串（""），先拼也不会有影响
            transferedNumber.append(arrStr[i]);
            if (i<arabNumbers.size()) {
                transferedNumber.append(arabNumbers.get(i));
            }
        }
        return transferedNumber.toString();
    }

    public static String outputArabNumberString_1(String chineseNumberString){
        String reg = "[零一二三四五六七八九十]+";
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(chineseNumberString);
        List<String> chineseNumbers = new ArrayList<>(16);
        List<Integer> arabNumbers = new ArrayList<>(16);
        boolean isNumberFirst = false;
        while(matcher.find()){
            chineseNumbers.add(matcher.group());
            // 转化成阿拉伯数字
            int arabNum = transferChineseNumber2ArabNumber(matcher.group());
            arabNumbers.add(arabNum);
        }
        String[] arrStr = chineseNumberString.split(reg);

        StringBuilder transferedNumber = new StringBuilder();

        // 数字的数量不大于文字的数量。
        // 如果结尾不是数字，则文字数量比数字数量多一（即使数字位于第一个也不会有影响）；如果结尾是数字，则数字文本数量相等。
        for(int i =0 ;i<arrStr.length;i++){
            // 先拼文字再拼数字，即使数字在第一个也会存在一个空的字符串（""），先拼也不会有影响
            transferedNumber.append(arrStr[i]);
            if (i<arabNumbers.size()) {
                transferedNumber.append(arabNumbers.get(i));
            }
        }
        return transferedNumber.toString();
    }


    public static int transferChineseNumber2ArabNumber(String chineseNumber) {
        String aval = "零一二三四五六七八九";
        String bval = "十百佰千仟万萬亿億";
        //int[] bnum = {10, 100, 100, 1000, 1000, 10000, 10000, 100000000, 100000000};
        int[] bnum = {10, 100, 100, 1000, 1000, 10000, 10000, 100000000, 100000000};
        int num = 0;
        char[] arr = chineseNumber.toCharArray();
        int len = arr.length;
        Stack<Integer> stack = new Stack<Integer>();
        for (int i = 0; i < len; i++) {
            char s = arr[i];
            //跳过零
            if(s == '零'){
                continue;
            }
            //用下标找到对应数字
            int index = bval.indexOf(s);
            //如果不在bval中，即当前字符为数字，直接入栈
            if(index == -1){
                stack.push(aval.indexOf(s));
            }else{ //当前字符为单位。
                int tempsum = 0;
                int val = bnum[index];
                //如果栈为空则直接入栈
                if(stack.isEmpty()){
                    stack.push(val);
                    continue;
                }
                //如果栈中有比val小的元素则出栈，累加，乘N，再入栈
                while(!stack.isEmpty() && stack.peek() < val){
                    tempsum += stack.pop();
                }
                //判断是否经过乘法处理
                if(tempsum == 0){
                    stack.push(val);
                }else{
                    stack.push(tempsum * val);
                }
            }
        }
        //计算最终的和
        while(!stack.isEmpty()){
            num += stack.pop();
        }
        return num;
    }

    public static long chinese_to_arabic(String cn) {
        HashMap<String, Integer> CN_NUM = new HashMap<String, Integer>() {{
            put("〇", 0);
            put("一", 1);
            put("二", 2);
            put("三", 3);
            put("四", 4);
            put("五", 5);
            put("六", 6);
            put("七", 7);
            put("八", 8);
            put("九", 9);

            put("零", 0);
            put("壹", 1);
            put("贰", 2);
            put("叁", 3);
            put("肆", 4);
            put("伍", 5);
            put("陆", 6);
            put("柒", 7);
            put("捌", 8);
            put("玖", 9);

            put("貮", 2);
            put("两", 2);

        }};

        HashMap<String, Long> CN_UNIT = new HashMap<String, Long>() {{
            put("十", 10L);
            put("拾", 10L);
            put("百", 100L);
            put("佰", 100L);
            put("千", 1000L);
            put("仟", 1000L);
            put("万", 10000L);
            put("萬", 10000L);
            put("亿", 100000000L);
            put("億", 100000000L);
            put("兆", 1000000000000L);
        }};

        long unit = 0;
        ArrayList<Long> ldig = new ArrayList<>();
        StringBuilder sb = new StringBuilder(cn);
        String reverseCn = sb.reverse().toString();
        for (int i = 0; i < reverseCn.length(); i++) {
            String cndig = reverseCn.charAt(i) + "";
            if (CN_UNIT.containsKey(cndig)) {
                unit = CN_UNIT.get(cndig);
                if (unit == 10000L || unit == 100000000L) {
                    ldig.add(unit);
                    unit = 1;
                }
            } else {
                long dig = CN_NUM.get(cndig);
                if (unit != 0) {
                    dig *= unit;
                    unit = 0;
                }
                ldig.add(dig);
            }
        }

        if (unit == 10) {
            ldig.add(10L);
        }

        long val = 0;
        long tmp = 0;
        for (int i = ldig.size() - 1; i >= 0; i--) {
            Long x = ldig.get(i);
            if (x == 10000L || x == 100000000L) {
                val += tmp * x;
                tmp = 0;
            } else {
                tmp += x;
            }
        }
        val += tmp;
        return val;
    }

    public static String change_chinese_to_arabic_in_centence(String x) {
        String[] strings1 = {"〇", "一", "二", "三", "四", "五", "六", "七", "八", "九", "零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖", "貮", "两", "十", "拾", "百", "佰", "千", "仟", "万", "萬", "亿", "億", "兆"};
        List<String> list1 = Arrays.asList(strings1);
        String[] strings2 = {"兆", "億", "亿", "萬", "万", "仟", "千", "佰", "百"};
        List<String> list2 = Arrays.asList(strings2);
        String xx = "";
        String yy = "";
        for (int j = 0; j < x.length(); j++) {
            String i = x.charAt(j) + "";
            if (!list1.contains(i)) {
                if (StringUtils.isNotEmpty(yy)) {
                    if (list2.contains(yy)) {
                        yy = yy;
                    } else {
                        yy = chinese_to_arabic(yy) + "";
                    }
                    xx += yy;
                }
                xx += i;
                yy = "";
            } else {
                yy += i;
                if (j == x.length() - 1) {
                    if (list2.contains(yy)) {
                        yy = yy;
                    } else {
                        yy = chinese_to_arabic(yy) + "";
                    }
                    xx += yy;
                }
            }

        }
        return xx.toLowerCase();
    }


    public static void main(String[] args) {

//        List<String> betweenDatesStr = getBetweenDatesStr("2018-06-25", "2018-07-05");
//        System.out.println(betweenDatesStr);
//        String name =  JavaUtil.class.getClass().getName();
//        String name =  JavaUtil.class.getName();
//        System.out.println("name:"+name);
//
//        String name1 = get("rds.properties","oms.mysql.driver");
//        System.out.println(name1);


    }

}
