package com.sf.gis.java.sx.constant.util;

public class ChineseChar {
    private char origin;
    private Boolean isNumber;
    private Integer number;
    private Integer rate;

    public void parse(char origin) {
        setOrigin(origin);
        switch (origin) {
            case '壹':
                number = 1;
                isNumber = true;
                break;
            case '贰':
                number = 2;
                isNumber = true;
                break;
            case '叁':
                number = 3;
                isNumber = true;
                break;
            case '肆':
                number = 4;
                isNumber = true;
                break;
            case '伍':
                number = 5;
                isNumber = true;
                break;
            case '陆':
                number = 6;
                isNumber = true;
                break;
            case '柒':
                number = 7;
                isNumber = true;
                break;
            case '捌':
                number = 8;
                isNumber = true;
                break;
            case '玖':
                number = 9;
                isNumber = true;
                break;
            case '一':
                number = 1;
                isNumber = true;
                break;
            case '二':
                number = 2;
                isNumber = true;
                break;
            case '三':
                number = 3;
                isNumber = true;
                break;
            case '四':
                number = 4;
                isNumber = true;
                break;
            case '五':
                number = 5;
                isNumber = true;
                break;
            case '六':
                number = 6;
                isNumber = true;
                break;
            case '七':
                number = 7;
                isNumber = true;
                break;
            case '八':
                number = 8;
                isNumber = true;
                break;
            case '九':
                number = 9;
                isNumber = true;
                break;
            case '零':
                number = 0;
                isNumber = true;
                break;
            case '两':
                number = 2;
                isNumber = true;
                break;
            case '俩':
                number = 2;
                isNumber = true;
                break;
            case '十':
                rate = 10;
                isNumber = false;
                break;
            case '百':
                rate = 100;
                isNumber = false;
                break;
            case '千':
                rate = 1000;
                isNumber = false;
                break;
            case '万':
                rate = 10000;
                isNumber = false;
                break;
            case '拾':
                rate = 10;
                isNumber = false;
                break;
            case '佰':
                rate = 100;
                isNumber = false;
                break;
            case '仟':
                rate = 1000;
                isNumber = false;
                break;
            case '萬':
                rate = 10000;
                isNumber = false;
                break;
            default:
                throw new IllegalArgumentException("数字格式不对：" + origin);
        }
    }

    public char getOrigin() {
        return origin;
    }

    public void setOrigin(char origin) {
        this.origin = origin;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public Boolean isNumber() {
        return this.isNumber;
    }

    public void setIsNumber(Boolean isNumber) {
        this.isNumber = isNumber;
    }

    @Override
    public String toString() {
        return this.origin + "";
    }
}
