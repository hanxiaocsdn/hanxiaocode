package com.sf.gis.pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 16:24 2022/9/15
 */
case class DetailToOperationNew(
                            waybill_no:String,
                            area_code:String,
                            city_code:String,
                            dest_zone_code:String,
                            aoi_code:String,
                            aoi_name:String,
                            barscantm80:String,
                            lng80:String,
                            lat80:String,
                            couriercode:String,
                            aoi_type_code:String,
                            aoi_type_name:String,
                            phonezone:String,
                            point_cnt_30s_before_80:String,
                            track_30s_before_80_in_aoi:String,
                            istougui:String,
                            iszijiziqu:String,
                            isexternal:String,
                            isfwsjg2g:String,
                            iscopyphone:String,
                            consignee_addr:String,
                            cargo_type_code:String,
                            real_product_code:String,
                            freight_payment_type_code:String,
                            is_validcall:String,
                            date:String,
                            key_word:String,
                            aoi_area_code:String,
                            eventfrom:String,
                            aoi_code_t5:String,
                            x_coord:String,
                            y_coord:String,
                            deliver_address_type:String,
                            is_real_tjy_byphonezone:String
)
