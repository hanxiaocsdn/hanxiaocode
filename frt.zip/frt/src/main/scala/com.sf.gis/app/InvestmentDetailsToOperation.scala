package com.sf.gis.app

import java.sql
import java.util.Date
import java.text.SimpleDateFormat

import com.alibaba.fastjson.JSONObject
import com.sf.gis.pojo.DetailToOperation
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.control.Breaks

/**
 * @Description:投竞对需求1.3
 * @Author: lixiangzhi 01405644
 * @Date: 11:40 2022/9/15
 *       任务id: 484019
 */
object InvestmentDetailsToOperation {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  /**
   * 读取投竟对结果表并关联是否电联表
   * @param spark
   * @param inc_day
   * @param calPartitions
   * @return
   */
  def readSourceData(spark: SparkSession, inc_day: String, calPartitions: Int) = {
    val sourceSql=
      s"""
        |select
        |t1.waybill_no
        |,area_code
        |,city_code
        |,dest_zone_code
        |,t1.aoi_code
        |,aoi_name
        |,from_unixtime(cast(barscantm80/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as barscantm80
        |,lng80
        |,lat80
        |,couriercode
        |,aoi_type_code
        |,aoi_type_name
        |,phonezone
        |,point_cnt_30s_before_80
        |,track_30s_before_80_in_aoi
        |,istougui
        |,iszijiziqu
        |,isexternal
        |,isfwsjg2g
        |,iscopyphone
        |,consignee_addr
        |,cargo_type_code
        |,real_product_code
        |,freight_payment_type_code
        |,if(t2.waybill_no is null,0,1) as is_validcall
        |,from_unixtime(unix_timestamp(inc_day,'yyyyMMdd'),'yyyy-MM-dd') as date
        |,t3.aoi_area_code as aoi_area_code
        |,t4.scene_type as eventfrom
        |,t5.aoi_code as aoi_code_t5
        |,x_coord
        |,y_coord
        |from
        |(
        |select
        |	waybill_no
        |	,area_code
        |	,city_code
        |	,dest_zone_code
        |	,aoi_code
        |	,aoi_name
        |	,barscantm80
        |	,lng80
        |	,lat80
        |	,couriercode
        |	,aoi_type_code
        |	,aoi_type_name
        |	,phonezone
        |	,point_cnt_30s_before_80
        |	,track_30s_before_80_in_aoi
        |	,istougui
        |	,iszijiziqu
        |	,isexternal
        |	,isfwsjg2g
        |	,iscopyphone
        |	,consignee_addr
        |	,cargo_type_code
        |	,real_product_code
        |	,freight_payment_type_code
        |    ,inc_day
        |    ,x_coord
        |    ,y_coord
        |	from dm_gis.dm_lbs_tjy_push_result_dtl_di
        |	where inc_day='$inc_day'
        |	and is_tjy='1'
        |) t1
        |left join
        |(
        |select
        |	waybill_no
        |from
        |(
        |	select
        |		waybill_no
        |   ,contact_dur
        |		,row_number() over(partition by waybill_no order by op_time desc) as rn
        |	from dwd.dwd_emp_telephone_contact_dtl_di
        |	where inc_day='$inc_day'
        |	and pd_type=1
        |) as tmp
        |where tmp.rn = 1 and tmp.contact_dur>=5
        |) t2
        |on t1.waybill_no=t2.waybill_no
        |
        |left join
        |
        |(
        |SELECT aoi_id,aoi_code FROM dm_gis.cms_aoi_sch group by aoi_id,aoi_code
        |) t5
        |
        |on t1.aoi_code = t5.aoi_id
        |
        |left join
        |(
        |select
        |	 aoi_id
        |	,aoi_area_code
        |from
        |(
        |	select
        |		 aoi_id
        |		,aoi_area_code
        |		,row_number() over(distribute by aoi_id sort by update_time desc) as rn
        |	from dm_tc_waybillinfo.aoi_area_aoi
        |	where status = 1
        |	and (aoi_id is not null and aoi_id <> '')
        |) as tmp
        |where tmp.rn = 1
        |) as t3
        |
        |on t5.aoi_code = t3.aoi_id
        |
        |left join
        |
        |(
        |	select
        |		waybill_no,scene_type
        |	from
        |	(
        |		select waybill_no,scene_type,row_number() over(partition by waybill_no order by scene_type) as rn from dm_ecas_dcs.tt_edcs_hive_commission_detail where inc_day = '$inc_day' and audit_type = '1'
        |	) as a
        |	where a.rn = 1
        |) as t4
        |
        |on t1.waybill_no = t4.waybill_no
        |""".stripMargin
    logger.error("sourceSql："+sourceSql)
    val sourceDf: DataFrame = spark.sql(sourceSql)
      //.limit(10000)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("投竟对结果表关联是否电联表后数量："+sourceDf.count())
    sourceDf
  }

  /**
   * 调地址接口返回地址关键词
   * @param spark
   * @param sourceDf
   * @param calPartitions
   * @return
   */
  def interfaceAddrKey(spark: SparkSession, sourceDf: DataFrame, calPartitions: Int) = {
    val sourceRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, sourceDf)
    val returnAddrKeywordRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,sourceRdd, SfNetInteface.addrKeywordInterface, 50, "950fddc87bc5420690681a31500ba61a", 20000)
    val keywordRdd: RDD[JSONObject] = returnAddrKeywordRDD.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "addr_keyword_result.result")
      val keyInfo: JSONObject = JSONUtil.getJSONObject(result, "keyInfo")
      val key_word: String = JSONUtil.getJsonValSingle(keyInfo, "key_word")
      val keywordArray = Array("菜鸟", "妈妈驿站", "驿站", "富友", "韵达", "中通", "云柜", "京东", "圆通", "百世", "申通", "天天", "邮政", "收件宝", "德邦", "汇通", "联邦", "中诚","EMS","国通","兔喜","溪鸟","快宝","递管家")
      val keywordLoop = new Breaks
      keywordLoop.breakable{
        for (k <- keywordArray.indices){
          val keywordSeg: String = keywordArray(k)
          if (key_word.contains(keywordSeg)){
            obj.put("key_word", key_word)
            keywordLoop.break()
          }
        }
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加key_word字段后数据量："+keywordRdd.count())
    keywordRdd
  }

  /**
   * 插入hive表
   * @param spark
   * @param keywordRdd
   * @param inc_day
   * @param calPartitions
   * @return
   */
  def insertHiveTable(spark: SparkSession, keywordRdd: RDD[JSONObject], inc_day: String, calPartitions: Int) = {
    import spark.implicits._
    val resultDf: DataFrame = keywordRdd.map(obj => {
      DetailToOperation(obj.getString("waybill_no"),
        obj.getString("area_code"),
        obj.getString("city_code"),
        obj.getString("dest_zone_code"),
        obj.getString("aoi_code"),
        obj.getString("aoi_name"),
        obj.getString("barscantm80"),
        obj.getString("lng80"),
        obj.getString("lat80"),
        obj.getString("couriercode"),
        obj.getString("aoi_type_code"),
        obj.getString("aoi_type_name"),
        obj.getString("phonezone"),
        obj.getString("point_cnt_30s_before_80"),
        obj.getString("track_30s_before_80_in_aoi"),
        obj.getString("istougui"),
        obj.getString("iszijiziqu"),
        obj.getString("isexternal"),
        obj.getString("isfwsjg2g"),
        obj.getString("iscopyphone"),
        obj.getString("consignee_addr"),
        obj.getString("cargo_type_code"),
        obj.getString("real_product_code"),
        obj.getString("freight_payment_type_code"),
        obj.getString("is_validcall"),
        obj.getString("date"),
        obj.getString("key_word"),
        obj.getString("aoi_area_code"),
        obj.getString("eventfrom"),
        obj.getString("aoi_code_t5"),
        obj.getString("x_coord"),
        obj.getString("y_coord")
      )
    }).toDF()
    //resultDf.show(10)
    resultDf.createOrReplaceTempView("tmp_lbs_tjy_detail_to_operation")
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "dm_lbs_tjy_detail_to_operation_di"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day='$inc_day')
         |select
         |	t4.*
         |	,case when is_self_channel = '是' and channel_type = '丰巢柜' and t5.aoi_id is not null then '有效'
         |		  when is_self_channel = '是' and channel_type <> '丰巢柜' and t6.aoi_id is not null then '有效'
         |		  else '无效' end as is_self_channel_effective
         |from
         |(
         |	select
         |		t1.*
         |		,case when t2.aoi_id is not null or t3.aoi_id is not null then '是' else '否' end as is_self_channel
         |		,case when t2.aoi_id is not null then '丰巢柜' else t3.channel end as channel_type
         |		,case when t2.aoi_id is not null then t2.cabinetcode else t3.virtual_addr end as channel_code
         |	from
         |
         |	(SELECT * FROM tmp_lbs_tjy_detail_to_operation) t1
         |
         |	left join
         |
         |	(SELECT aoi_id,concat_ws(',',collect_set(cabinetcode)) as cabinetcode FROM dim.dim_hive_cabinet_info_df where inc_day = '$inc_day' and aoi_id is not null and aoi_id <> '' group by aoi_id) t2
         |
         |	on t1.aoi_code = t2.aoi_id
         |
         |	left join
         |
         |	(
         |		select
         |			a.aoi_id as aoi_id
         |			,concat_ws(',',collect_set(a.virtual_addr)) as virtual_addr
         |			,concat_ws(',',collect_set(b.channel)) as channel
         |		from
         |		(SELECT aoi_id,virtual_addr FROM ods_skss1.sto_aoi_info where inc_day = '$inc_day' and aoi_id is not null and aoi_id <> '' group by aoi_id,virtual_addr) a
         |
         |		left join
         |
         |		(select store_code,channel from dim.dim_sf_store_info_df where inc_day = '$inc_day' group by store_code,channel) b
         |
         |		on a.virtual_addr = b.store_code
         |
         |		group by a.aoi_id
         |	) t3
         |
         |	on t1.aoi_code = t3.aoi_id
         |) as t4
         |
         |left join
         |
         |(
         |	SELECT aoi_id FROM dim.dim_hive_cabinet_info_df where inc_day = '$inc_day' and aoi_id is not null and aoi_id <> '' and status = '1' group by aoi_id
         |) t5
         |
         |on t4.aoi_code = t5.aoi_id
         |
         |left join
         |
         |(
         |	select
         |		a.aoi_id as aoi_id
         |	from
         |	(SELECT aoi_id,virtual_addr FROM ods_skss1.sto_aoi_info where inc_day = '$inc_day' and aoi_id is not null and aoi_id <> '' group by aoi_id,virtual_addr) a
         |
         |	join
         |
         |	(select store_code from dim.dim_sf_store_info_df where inc_day = '$inc_day' and is_delt = '0' and apprv_status = '3' group by store_code,channel) b
         |
         |	on a.virtual_addr = b.store_code
         |
         |	group by a.aoi_id
         |) t6
         |
         |on t4.aoi_code = t6.aoi_id
         |""".stripMargin

    //spark.sql(s"insert overwrite table dm_gis.dm_lbs_tjy_detail_to_operation_di partition(inc_day='$inc_day') select * from tmp_lbs_tjy_detail_to_operation")
    spark.sql(insertSQL)

  }

  def execute(inc_day: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    //投竟对结果表关联是否电联表
    val sourceDf: DataFrame = readSourceData(spark, inc_day, calPartitions)
    //sourceDf.show(20)
    //调用地址关键字接口
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "484019", "投竞对需求结果表导入终端管理处", "投竞对需求结果表导入终端管理处", "http://gis-int.int.sfdc.com.cn:1080/iad/api/keyword", "950fddc87bc5420690681a31500ba61a", unrecognizedData.count(), 50)
    val keywordRdd: RDD[JSONObject] = interfaceAddrKey(spark, sourceDf, calPartitions)
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)
    //keywordRdd.take(20).foreach(println(_))
    insertHiveTable(spark,keywordRdd,inc_day,calPartitions)
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>InvestmentDetailsToOperation Execute Ok")
  }
}
