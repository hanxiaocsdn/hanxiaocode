package com.sf.gis.app

import java.util
import java.util.regex.Pattern
import java.util.stream.Collectors

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.StringNumUtils
import com.sf.gis.java.sx.constant.util.JavaUtil
import com.sf.gis.pojo.{DetailToOperation, DetailToOperationNew}
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.control.Breaks

/**
 * 【壹竿-LBS】投竞对识别_V2.1
 * 需求方：刘雨婷（01408947）
 *
 * @author 韩笑（01417629）
 *         Created on Feb.27 2023
 *         任务信息：669410（投竞对识别，每天1点0分执行、2023年1月1日--）
 */
object InvestmentDetailsToOperationNew {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  /**
   * 读取投竟对结果表并关联是否电联表
   *
   * @param spark
   * @param inc_day
   * @param calPartitions
   * @return
   */
  def readSourceData(spark: SparkSession, inc_day: String, calPartitions: Int) = {
    val sourceSql =
      s"""
         |select
         |t1.waybill_no
         |,area_code
         |,city_code
         |,dest_zone_code
         |,t1.aoi_code
         |,aoi_name
         |,from_unixtime(cast(barscantm80/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as barscantm80
         |,lng80
         |,lat80
         |,couriercode
         |,aoi_type_code
         |,aoi_type_name
         |,phonezone
         |,point_cnt_30s_before_80
         |,track_30s_before_80_in_aoi
         |,istougui
         |,iszijiziqu
         |,isexternal
         |,isfwsjg2g
         |,iscopyphone
         |,consignee_addr
         |,cargo_type_code
         |,real_product_code
         |,freight_payment_type_code
         |,if(t2.waybill_no is null,0,1) as is_validcall
         |,from_unixtime(unix_timestamp(inc_day,'yyyyMMdd'),'yyyy-MM-dd') as date
         |,t3.aoi_area_code as aoi_area_code
         |,t4.scene_type as eventfrom
         |,t5.aoi_code as aoi_code_t5
         |,x_coord
         |,y_coord
         |,cnyz_name
         |,case when t6.waybill_no <> '' and t6.waybill_no is not null then '竞业' else '' end as deliver_address_type
         |from
         |(
         |select
         |	waybill_no
         |	,area_code
         |	,city_code
         |	,dest_zone_code
         |	,aoi_code
         |	,aoi_name
         |	,barscantm80
         |	,lng80
         |	,lat80
         |	,couriercode
         |	,aoi_type_code
         |	,aoi_type_name
         |	,phonezone
         |	,point_cnt_30s_before_80
         |	,track_30s_before_80_in_aoi
         |	,istougui
         |	,iszijiziqu
         |	,isexternal
         |	,isfwsjg2g
         |	,iscopyphone
         |	,consignee_addr
         |	,cargo_type_code
         |	,real_product_code
         |	,freight_payment_type_code
         |    ,inc_day
         |    ,x_coord
         |    ,y_coord
         |    ,cnyz_name
         |	--from dm_gis.dm_lbs_tjy_push_result_dtl_di
         |	--from dm_gis.dm_lbs_tjy_push_result_dtl_di_20230202_tmp
         |	from dm_gis.dm_lbs_tjy_push_result_dtl_di_new
         |	where inc_day='$inc_day'
         |	and is_tjy='1'
         |) t1
         |left join
         |(
         |select
         |	waybill_no
         |from
         |(
         |	select
         |		waybill_no
         |   ,contact_dur
         |		,row_number() over(partition by waybill_no order by op_time desc) as rn
         |	from dwd.dwd_emp_telephone_contact_dtl_di
         |	where inc_day='$inc_day'
         |	and pd_type=1
         |) as tmp
         |where tmp.rn = 1 and tmp.contact_dur>=5
         |) t2
         |on t1.waybill_no=t2.waybill_no
         |
         |left join
         |
         |(
         |SELECT aoi_id,aoi_code FROM dm_gis.cms_aoi_sch group by aoi_id,aoi_code
         |) t5
         |
         |on t1.aoi_code = t5.aoi_id
         |
         |left join
         |(
         |select
         |	 aoi_id
         |	,aoi_area_code
         |from
         |(
         |	select
         |		 aoi_id
         |		,aoi_area_code
         |		,row_number() over(distribute by aoi_id sort by update_time desc) as rn
         |	from dm_tc_waybillinfo.aoi_area_aoi
         |	where status = 1
         |	and (aoi_id is not null and aoi_id <> '')
         |) as tmp
         |where tmp.rn = 1
         |) as t3
         |
         |on t5.aoi_code = t3.aoi_id
         |
         |left join
         |
         |(
         |	select
         |		waybill_no,scene_type
         |	from
         |	(
         |		select waybill_no,scene_type,row_number() over(partition by waybill_no order by scene_type) as rn from dm_ecas_dcs.tt_edcs_hive_commission_detail where inc_day = '$inc_day' and audit_type = '1'
         |	) as a
         |	where a.rn = 1
         |) as t4
         |
         |on t1.waybill_no = t4.waybill_no
         |
         |left join
         |
         |(
         |  select waybill_no from dm_gis.dm_op_pd_deliver_phone_dtl_di where inc_day = '$inc_day' and deliver_address_type = '竞业' group by waybill_no
         |) as t6
         |
         |on t1.waybill_no = t6.waybill_no
         |""".stripMargin
    logger.error("sourceSql：" + sourceSql)
    val sourceDf: DataFrame = spark.sql(sourceSql)
      //.limit(10000)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("投竟对结果表关联是否电联表后数量：" + sourceDf.count())
    sourceDf
  }

  /**
   * 调地址接口返回地址关键词
   *
   * @param spark
   * @param sourceDf
   * @param calPartitions
   * @return
   */
  def interfaceAddrKey(spark: SparkSession, sourceDf: DataFrame, calPartitions: Int) = {
    val sourceRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, sourceDf)
    val returnAddrKeywordRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, sourceRdd, SfNetInteface.addrKeywordInterface, 50, "950fddc87bc5420690681a31500ba61a", 20000)
    val keywordRdd: RDD[JSONObject] = returnAddrKeywordRDD.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "addr_keyword_result.result")
      val keyInfo: JSONObject = JSONUtil.getJSONObject(result, "keyInfo")
      val key_word: String = JSONUtil.getJsonValSingle(keyInfo, "key_word")
      val keywordArray = Array("菜鸟", "妈妈驿站", "驿站", "富友", "韵达", "中通", "云柜", "京东", "圆通", "百世", "申通", "天天", "邮政", "收件宝", "德邦", "汇通", "联邦", "中诚", "EMS", "国通", "兔喜", "溪鸟", "快宝", "递管家")
      val keywordLoop = new Breaks
      keywordLoop.breakable {
        for (k <- keywordArray.indices) {
          val keywordSeg: String = keywordArray(k)
          if (key_word.contains(keywordSeg)) {
            obj.put("key_word", key_word)
            keywordLoop.break()
          }
        }
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加key_word字段后数据量：" + keywordRdd.count())
    keywordRdd
  }

  /**
   * 插入hive表
   *
   * @param spark
   * @param isRealTjyByphonezone
   * @param inc_day
   * @param calPartitions
   * @return
   */
  def insertHiveTable(spark: SparkSession, isRealTjyByphonezone: RDD[JSONObject], inc_day: String, calPartitions: Int) = {
    import spark.implicits._
    val resultDf: DataFrame = isRealTjyByphonezone.map(obj => {
      DetailToOperationNew(obj.getString("waybill_no"),
        obj.getString("area_code"),
        obj.getString("city_code"),
        obj.getString("dest_zone_code"),
        obj.getString("aoi_code"),
        obj.getString("aoi_name"),
        obj.getString("barscantm80"),
        obj.getString("lng80"),
        obj.getString("lat80"),
        obj.getString("couriercode"),
        obj.getString("aoi_type_code"),
        obj.getString("aoi_type_name"),
        obj.getString("phonezone"),
        obj.getString("point_cnt_30s_before_80"),
        obj.getString("track_30s_before_80_in_aoi"),
        obj.getString("istougui"),
        obj.getString("iszijiziqu"),
        obj.getString("isexternal"),
        obj.getString("isfwsjg2g"),
        obj.getString("iscopyphone"),
        obj.getString("consignee_addr"),
        obj.getString("cargo_type_code"),
        obj.getString("real_product_code"),
        obj.getString("freight_payment_type_code"),
        obj.getString("is_validcall"),
        obj.getString("date"),
        obj.getString("key_word"),
        obj.getString("aoi_area_code"),
        obj.getString("eventfrom"),
        obj.getString("aoi_code_t5"),
        obj.getString("x_coord"),
        obj.getString("y_coord"),
        obj.getString("deliver_address_type"),
        obj.getString("is_real_tjy_byphonezone")
      )
    }).toDF()
    resultDf.show(5)
    resultDf.createOrReplaceTempView("tmp_lbs_tjy_detail_to_operation")
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "dm_lbs_tjy_detail_to_operation_di_new"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day='$inc_day')
         |select
         |	t4.waybill_no
         | ,t4.area_code
         | ,city_code
         | ,dest_zone_code
         | ,aoi_code,aoi_name
         | ,barscantm80
         | ,lng80
         | ,lat80
         | ,couriercode
         | ,aoi_type_code
         | ,aoi_type_name
         | ,phonezone
         | ,point_cnt_30s_before_80
         | ,track_30s_before_80_in_aoi
         | ,istougui
         | ,iszijiziqu
         | ,isexternal
         | ,isfwsjg2g
         | ,iscopyphone
         | ,consignee_addr
         | ,cargo_type_code
         | ,real_product_code
         | ,freight_payment_type_code
         | ,is_validcall
         | ,date
         | ,key_word
         | ,aoi_area_code
         | ,eventfrom
         | ,aoi_code_t5
         | ,x_coord
         | ,y_coord
         | ,is_self_channel
         | ,channel_type
         | ,channel_code
         |	,case when is_self_channel = '是' and channel_type = '丰巢柜' and t5.aoi_id is not null then '有效'
         |		  when is_self_channel = '是' and channel_type <> '丰巢柜' and t6.aoi_id is not null then '有效'
         |		  else '无效' end as is_self_channel_effective
         |    ,deliver_address_type
         |    ,is_real_tjy_byphonezone
         |    ,t7.area_name
         |    ,case when cast(t8.phone_eff_cnt as decimal(10,0)) >= 1 then '1' else '0' end as is_phone_eff
         |from
         |(
         |	select
         |		t1.*
         |		,case when t2.aoi_id is not null or t3.aoi_id is not null then '是' else '否' end as is_self_channel
         |		,case when t2.aoi_id is not null then '丰巢柜' else t3.channel end as channel_type
         |		,case when t2.aoi_id is not null then t2.cabinetcode else t3.virtual_addr end as channel_code
         |	from
         |
         |	(SELECT * FROM tmp_lbs_tjy_detail_to_operation) t1
         |
         |	left join
         |
         |	(SELECT aoi_id,concat_ws(',',collect_set(cabinetcode)) as cabinetcode FROM dim.dim_hive_cabinet_info_df where inc_day = '$inc_day' and aoi_id is not null and aoi_id <> '' group by aoi_id) t2
         |
         |	on t1.aoi_code = t2.aoi_id
         |
         |	left join
         |
         |	(
         |		select
         |			a.aoi_id as aoi_id
         |			,concat_ws(',',collect_set(a.virtual_addr)) as virtual_addr
         |			,concat_ws(',',collect_set(b.channel)) as channel
         |		from
         |		(SELECT aoi_id,virtual_addr FROM ods_skss1.sto_aoi_info where inc_day = '$inc_day' and aoi_id is not null and aoi_id <> '' group by aoi_id,virtual_addr) a
         |
         |		left join
         |
         |		(select store_code,channel from dim.dim_sf_store_info_df where inc_day = '$inc_day' group by store_code,channel) b
         |
         |		on a.virtual_addr = b.store_code
         |
         |		group by a.aoi_id
         |	) t3
         |
         |	on t1.aoi_code = t3.aoi_id
         |) as t4
         |
         |left join
         |
         |(
         |	SELECT aoi_id FROM dim.dim_hive_cabinet_info_df where inc_day = '$inc_day' and aoi_id is not null and aoi_id <> '' and status = '1' group by aoi_id
         |) t5
         |
         |on t4.aoi_code = t5.aoi_id
         |
         |left join
         |
         |(
         |	select
         |		a.aoi_id as aoi_id
         |	from
         |	(SELECT aoi_id,virtual_addr FROM ods_skss1.sto_aoi_info where inc_day = '$inc_day' and aoi_id is not null and aoi_id <> '' group by aoi_id,virtual_addr) a
         |
         |	join
         |
         |	(select store_code from dim.dim_sf_store_info_df where inc_day = '$inc_day' and is_delt = '0' and apprv_status = '3' group by store_code,channel) b
         |
         |	on a.virtual_addr = b.store_code
         |
         |	group by a.aoi_id
         |) t6
         |
         |on t4.aoi_code = t6.aoi_id
         |
         |left join
         |
         |(
         |  select area_code,area_name from dm_gis.dim_city_info_df where inc_day = '$inc_day' group by area_code,area_name
         |) t7
         |
         |on t4.area_code = t7.area_code
         |
         |left join
         |
         |(
         |  select waybill_no,phone_eff_cnt from dm_analysis.danko_pd_deliver_phone_detail where inc_day = '$inc_day'
         |) t8
         |on t4.waybill_no = t8.waybill_no
         |""".stripMargin

    //spark.sql(s"insert overwrite table dm_gis.dm_lbs_tjy_detail_to_operation_di partition(inc_day='$inc_day') select * from tmp_lbs_tjy_detail_to_operation")
    spark.sql(insertSQL)

  }

  def getIsRealTjyByphonezone(keywordRdd: RDD[JSONObject]) = {
    val isRealTjyByphonezone = keywordRdd.map(obj => {
      var is_real_tjy_byphonezone = "0"
      val phonezone = JSONUtil.getJsonVal(obj, "phonezone", "")
      val cnyz_name = JSONUtil.getJsonVal(obj, "cnyz_name", "")
      val aoi_name = JSONUtil.getJsonVal(obj, "aoi_name", "")
      val consignee_addr = JSONUtil.getJsonVal(obj, "consignee_addr", "")
      val waybill_no = JSONUtil.getJsonVal(obj, "waybill_no", "")
      obj.put("phonezone", phonezone)
      obj.put("cnyz_name", cnyz_name)
      obj.put("aoi_name", aoi_name)
      obj.put("consignee_addr", consignee_addr)
      obj.put("waybill_no", waybill_no)

      //竞业关键字：′菜鸟′,′驿站′,′申通′,′圆通′,′中通′,′韵达′,′联邦′,′邮政′,′德邦′,′百世′,′汇通′,′国通′,′京东′,′天天′,′EMS′,′云柜′,′收件宝′
      val arr1 = Array("菜鸟", "驿站", "申通", "圆通", "中通", "韵达", "联邦", "邮政", "德邦", "百世", "汇通", "国通", "京东", "天天", "EMS", "云柜", "收件宝")

      //竞业的其他写法：′蔡茑′,′菜乌′,′菜了′,′兔喜′,′邻里′
      val arr2 = Array("蔡茑", "菜乌", "菜了", "兔喜", "邻里")

      //phonezone文本包含竞业关键字?
      val phonezone_arr1 = arr1.map(obj => {
        if (phonezone.contains(obj)) phonezone else null
      }).filter(_ != null)

      obj.put("phonezone_arr1_size", phonezone_arr1.size)
      obj.put("phonezone_arr1", phonezone_arr1.mkString(","))


      //phonezone文本包含竞业的其他写法?
      val phonezone_arr2 = arr2.map(obj => {
        if (phonezone.contains(obj)) phonezone else null
      }).filter(_ != null)

      obj.put("phonezone_arr2_size", phonezone_arr2.size)
      obj.put("phonezone_arr2", phonezone_arr2.mkString(","))

      //phonezone文本转拼音后包含′càiniǎo′
      var phonezone_pin_yin = ""
      if (phonezone.nonEmpty) {
        phonezone_pin_yin = JavaUtil.getPinyin(phonezone, "")
      }

      obj.put("phonezone_pin_yin", phonezone_pin_yin)


      //phonezone1=phonezone(当phonezone以′代收点′,′代收′,′收′,′代′结尾时，去除对应的结尾词后作为phonezone1)
      val arr3 = Array("代收点", "代收", "收", "代")
      val phonezone1_arr = arr3.map(obj => {
        if (phonezone.endsWith(obj) && phonezone.split(obj).size > 0) phonezone.split(obj)(0) else ""
      }).filter(_ != "")

      val phonezone1 = if (phonezone1_arr.size > 0) phonezone1_arr(0) else phonezone
      obj.put("phonezone1", phonezone1)

      try {
        var num = 0
        if (phonezone1.nonEmpty) {
          num = phonezone1.toCharArray.map(obj => {
            if (aoi_name.contains(obj)) 1 else 0
          }).reduce(_ + _)
        }

        obj.put("num", num)

        val flag1 = phonezone1.nonEmpty && cnyz_name.contains(phonezone1) && (cnyz_name.endsWith(phonezone1) || cnyz_name.endsWith(phonezone1 + "店")) && !phonezone1.equals(aoi_name) && !(num >= phonezone1.length - 1) && !(phonezone1.contains(consignee_addr) && !consignee_addr.contains("菜鸟") && !consignee_addr.contains("驿站"))
        obj.put("phonezone1.nonEmpty", phonezone1.nonEmpty)
        obj.put("cnyz_name.contains(phonezone1)", cnyz_name.contains(phonezone1))
        obj.put("cnyz_name.endsWith(phonezone1)", cnyz_name.endsWith(phonezone1))
        obj.put("cnyz_name.endsWith(phonezone1 + \"店\")", cnyz_name.endsWith(phonezone1 + "店"))
        obj.put("!phonezone1.equals(aoi_name)", !phonezone1.equals(aoi_name))
        obj.put("num >= phonezone1.length - 1", num >= phonezone1.length - 1)
        obj.put("phonezone1.contains(consignee_addr)", phonezone1.contains(consignee_addr))
        obj.put("!consignee_addr.contains(\"菜鸟\")", !consignee_addr.contains("菜鸟"))
        obj.put("!consignee_addr.contains(\"驿站\")", !consignee_addr.contains("驿站"))
        obj.put("flag1", flag1)

        /*数字、字母转换逻辑：
        1、对文本中包含的大写数字转为阿拉伯数字，例如：西城路十街 转换为 西城路10街
        当大写数字为′兆′,′億′,′亿′,′萬′,′万′,′仟′,′千′,′佰′,′百′时，且前后文本不是数字时，不转换。例如：重庆万州北山路十二号店 转换为 重庆万州北山路12号店，万不转换为10000
        2、对文本中包含的大写字母转为小写字母，例如：都嘉苑B1区 转换为 都嘉苑b1区*/
        //新增中间逻辑判断字段(不用新增到数据表内，仅为逻辑表达清楚)：phonezone2=对phonezone数字、字母转换后的值
        //phonezone = "西城路十街"
        //val phonezone2 = Util.outputArabNumberStringNew(phonezone.toLowerCase)
        val phonezone2 = StringNumUtils.change_chinese_to_arabic_in_centence(phonezone)
        val cnyz_name2 = StringNumUtils.change_chinese_to_arabic_in_centence(cnyz_name)
        val consignee_addr2 = StringNumUtils.change_chinese_to_arabic_in_centence(consignee_addr)

        obj.put("phonezone2", phonezone2)
        obj.put("cnyz_name2", cnyz_name2)
        obj.put("consignee_addr2", consignee_addr2)


        var phonezone_number = Array("")
        val phonezone_number_list = new util.ArrayList[String]()
        if (phonezone2.nonEmpty) {
          //phonezone_number = phonezone2.replaceAll("[^x00-xff]", "#").split("#").filter(_.nonEmpty).distinct
          //提取数字和字母
          phonezone_number = phonezone2.replaceAll("[^a-zA-Z0-9]", "#").split("#").filter(_.nonEmpty)
        }

        //长沙松雅小区B区2c栋1店2e号9层1-2c-3：[b,2c,1,2e,9] b2c1
        var res_str = ""
        if (phonezone_number.length > 1) {
          for (elem <- phonezone_number) {
            if (elem.matches("^[a-z0-9]*[a-z]$")) {
              res_str += elem
              if(phonezone_number.length - 1 == phonezone_number.indexOf(elem)){
                phonezone_number_list.add(res_str)
              }
            } else {
              if (res_str.matches("^[a-z0-9]*[a-z]$")) {
                res_str += elem
                phonezone_number_list.add(res_str)
                res_str = ""
              } else {
                phonezone_number_list.add(elem)
              }
            }
          }
        }

        if (phonezone_number_list.size() > 0) {
          //phonezone_number = phonezone_number_list.toString.split(",")
          phonezone_number = phonezone_number_list.toString.replaceAll(" ","").replaceAll("\\[|\\]","").split(",")
        }


        obj.put("phonezone_number", phonezone_number.mkString(","))

        var cnyz_name_number = Array("")
        val cnyz_name_number_list = new util.ArrayList[String]()
        if (cnyz_name2.nonEmpty) {
          //cnyz_name_number = cnyz_name2.replaceAll("[^x00-xff]", "#").split("#").filter(_.nonEmpty).distinct
          //提取数字和字母
          cnyz_name_number = cnyz_name2.replaceAll("[^a-zA-Z0-9]", "#").split("#").filter(_.nonEmpty)
        }

        var res_str1 = ""
        if (cnyz_name_number.length > 1) {
          for (elem <- cnyz_name_number) {
            if (elem.matches("^[a-z0-9]*[a-z]$")) {
              res_str1 += elem
              if(cnyz_name_number.length - 1 == cnyz_name_number.indexOf(elem)){
                cnyz_name_number_list.add(res_str1)
              }
            } else {
              if (res_str1.matches("^[a-z0-9]*[a-z]$")) {
                res_str1 += elem
                cnyz_name_number_list.add(res_str1)
                res_str1 = ""
              } else {
                cnyz_name_number_list.add(elem)
              }
            }
          }
        }

        if (cnyz_name_number_list.size() > 0) {
          //cnyz_name_number = cnyz_name_number_list.toString.split(",")
          cnyz_name_number = cnyz_name_number_list.toString.replaceAll(" ","").replaceAll("\\[|\\]","").split(",")
        }

        obj.put("cnyz_name_number", cnyz_name_number.mkString(","))

        //phonezone_number与cnyz_name_number数字字母组合的个数一样 且 phonezone_number与cnyz_name_number在1个相同的位置上数字字母组合不一样(满足这个条件的位置只有1个)
        val flag2 = phonezone_number.diff(cnyz_name_number).size == 1 && cnyz_name_number.diff(phonezone_number).size == 1 && phonezone_number.indexOf(phonezone_number.diff(cnyz_name_number)(0)) == cnyz_name_number.indexOf(cnyz_name_number.diff(phonezone_number)(0))
        obj.put("phonezone_number.diff(cnyz_name_number)", phonezone_number.diff(cnyz_name_number).mkString(","))
        obj.put("cnyz_name_number.diff(phonezone_number)", cnyz_name_number.diff(phonezone_number).mkString(","))
        obj.put("flag2", flag2)

        //phonezone_number与cnyz_name_number有2个以上字母数字组合一样
        val flag3 = phonezone_number.intersect(cnyz_name_number).size >= 2 && !(phonezone_number.size == cnyz_name_number.size && flag2)
        obj.put("phonezone_number.intersect(cnyz_name_number)", phonezone_number.intersect(cnyz_name_number).mkString(","))
        obj.put("flag3", flag3)

        //phonezone_number与cnyz_name_number数字字母组合的个数都为1 且 phonezone_number与cnyz_name_number数字字母组合一样,phonezone_number唯一的数字字母组合长度>=2
        val flag4 = phonezone_number.size == 1 && cnyz_name_number.size == 1 && phonezone_number(0).nonEmpty && phonezone_number(0) == cnyz_name_number(0) && phonezone_number(0).length >= 2
        obj.put("flag4", flag4)


        //phonezone_number个数为1 且 phonezone_number的数字字母组合包含在cnyz_name_number数字字母组合中
        val flag5 = phonezone_number.size == 1 && phonezone_number(0).nonEmpty && cnyz_name_number.contains(phonezone_number(0)) && (phonezone2.split(phonezone_number(0)).size > 0 && phonezone2.split(phonezone_number(0))(0).nonEmpty && cnyz_name2.contains(phonezone2.split(phonezone_number(0))(0)))
        obj.put("flag5", flag5)
        //新增中间逻辑判断字段(不用新增到数据表内，仅为逻辑表达清楚)：phonezone_BuildingNumber=取phonezone2里面的楼栋的数字
        val phonezone_BuildingNumber = pattern_match(phonezone2)
        val cnyz_name_BuildingNumber = pattern_match(cnyz_name2)
        //val consignee_addr_BuildingNumber = pattern_match(consignee_addr)
        val consignee_addr_BuildingNumber = pattern_match(consignee_addr2)
        obj.put("phonezone_BuildingNumber", phonezone_BuildingNumber)
        obj.put("cnyz_name_BuildingNumber", cnyz_name_BuildingNumber)
        obj.put("consignee_addr_BuildingNumber", consignee_addr_BuildingNumber)

        val flag6 = phonezone_BuildingNumber.nonEmpty && phonezone_BuildingNumber == cnyz_name_BuildingNumber

        val flag7 = phonezone_BuildingNumber == consignee_addr_BuildingNumber

        val flag8 = consignee_addr.contains("菜鸟") || consignee_addr.contains("驿站")

        obj.put("flag6", flag6)
        obj.put("flag7", flag7)
        obj.put("flag8", flag8)

        if (phonezone.nonEmpty) {
          if (phonezone_arr1.size > 0) {
            is_real_tjy_byphonezone = "1"
          } else if (phonezone_arr2.size > 0) {
            is_real_tjy_byphonezone = "1"
          } else if (phonezone_pin_yin.contains("cai4niao3")) {
            is_real_tjy_byphonezone = "1"
          } else if (phonezone1.nonEmpty && aoi_name.nonEmpty && cnyz_name.contains(aoi_name) && cnyz_name.split(aoi_name).size >= 2 && cnyz_name.split(aoi_name)(1).contains(phonezone1)) {
            is_real_tjy_byphonezone = "1"
          } else if (cnyz_name.endsWith(phonezone1) && phonezone1.endsWith("店")) {
            is_real_tjy_byphonezone = "1"
          } else if (flag1) {
            is_real_tjy_byphonezone = "1"
          } else if (flag3) {
            is_real_tjy_byphonezone = "1"
          } else if (flag4) {
            is_real_tjy_byphonezone = "1"
          } else if (flag5) {
            is_real_tjy_byphonezone = "1"
          } else if (flag6) {
            if (!flag7) {
              is_real_tjy_byphonezone = "1"
            } else {
              if (flag8) {
                is_real_tjy_byphonezone = "1"
              }
            }
          } else {
            is_real_tjy_byphonezone = "0"
          }
        }
      } catch {
        case e: Exception => logger.error(">>>异常!<<<！\n" + e)
      }
      obj.put("is_real_tjy_byphonezone", is_real_tjy_byphonezone)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s"isRealTjyByphonezone共：${isRealTjyByphonezone.count()}")
    isRealTjyByphonezone
  }

  def pattern_match(str : String) ={
    val pattern = Pattern.compile("(?<!\\d)(\\d{1,3})(?=号楼|栋|座|幢)(?!\\d)")
    var res = ""
    val matcher = pattern.matcher(str)
    val list = new util.ArrayList[String]()
    while (matcher.find()) {
      list.add(matcher.group())
    }
    if (list.size() == 1) {
      res = list.get(0)
    }
    res
  }

  def execute(inc_day: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    //
    /*val wno_set = new util.HashSet[String]()
    val iter = wno.split(",").toIterator
    while (iter.hasNext){
      val str = iter.next()
      wno_set.add(str)
    }*/
    //投竟对结果表关联是否电联表
    val sourceDf: DataFrame = readSourceData(spark, inc_day, calPartitions)
    sourceDf.show(2)
    //调用地址关键字接口
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "404475", "高频补码作业数据源", "高频补码作业数据源", "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api", "dec044d089524419b371bc94555c539d", unrecognizedData.count(), 80)
    val keywordRdd: RDD[JSONObject] = interfaceAddrKey(spark, sourceDf, calPartitions)
    keywordRdd.take(2).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)
    //新增字段：is_real_tjy_byphonezone
    val isRealTjyByphonezone = getIsRealTjyByphonezone(keywordRdd)
    isRealTjyByphonezone.take(2).foreach(println(_))
    //入库
    insertHiveTable(spark, isRealTjyByphonezone, inc_day, calPartitions)
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    //val wno: String = args(1)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>InvestmentDetailsToOperation Execute Ok")
  }
}
