package com.sf.gis.app

import java.sql.{Connection, DriverManager, PreparedStatement, ResultSet}
import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.StringNumUtils
import com.sf.gis.pojo.{cxServiceNetworkClass, dis80New, lbsTjyResult, noviceStationClass}
import com.sf.gis.scala.base.spark.{Spark, SparkJoin, SparkUtils}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.util._
import com.sf.shiva.oms.csm.utils.common.dto.NsCfgDto
import com.sf.shiva.oms.csm.utils.{FwExpressUtils, NsCfgUtils, SJUtils}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.matching.Regex

/**
 * @Description:投竟业跑数需求设计全国数据
 * @Author: lixiangzhi 01405644
 * @Date: 10:42 2022/1/10
 */



object InvestmentProjectsDesignCity {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def originalJoinFourthTable(spark: SparkSession, incDay: String,singleCityCode: String,calPartitions:Int) = {
    val joinWaybillSql =
      s"""
         |select
         |a.*,
         |b.properties_gpslongitude as copyphone_longitude,
         |b.properties_gpslatitude as copyphone_latitude,
         |b.properties_operatime as copyphone_operatime,
         |c.phonezone as phonezone,
         |d.consignee_addr as consignee_addr,
         |d.cargo_type_code as cargo_type_code,
         |d.real_product_code as real_product_code,
         |d.freight_payment_type_code as freight_payment_type_code,
         |e.time as timestamp_80_pre
         |from
         |(
         |select
         |waybill_no
         |,area_code
         |,city_code
         |,dest_zone_code
         |,aoi_code
         |,aoi_name
         |,barscantm80
         |,lng80
         |,lat80
         |,point_cnt_30s_before_80
         |,track_30s_before_80_in_aoi
         |,istougui
         |,iszijiziqu
         |,isexternal
         |,isfwsjg2g
         |,couriercode
         |,aoi_type_code
         |,aoi_type_name
         |,iscopyphone
         |from dm_gis.lbs_loc_index
         |where inc_day='$incDay'
         |and istougui <> '1'
         |and iszijiziqu <> '1'
         |and isexternal <> '1'
         |and (isfwsjg2g <> '1' or isfwsjg2g is null)
         |--and city_code in ($singleCityCode)
         |group by waybill_no,area_code,city_code,dest_zone_code,aoi_code,aoi_name,barscantm80,lng80,lat80,point_cnt_30s_before_80,track_30s_before_80_in_aoi,istougui,iszijiziqu,isexternal,isfwsjg2g,couriercode,aoi_type_code,aoi_type_name,iscopyphone
         |) a
         |left join
         |(
         |select
         |properties_waybillno
         |,properties_gpslongitude
         |,properties_gpslatitude
         |,properties_operatime
         |from
         |(select
         |properties_waybillno
         |,properties_gpslongitude
         |,properties_gpslatitude
         |,properties_operatime
         |,properties_zonecode
         |from dm_sfxg.product_inc_ubas_next_app
         |where inc_day='$incDay'
         |and event_id='21510'
         |) t1 left join dm_gis.st_department t2
         |on t1.properties_zonecode=t2.zno_code
         |--where t2.city_code in ($singleCityCode)
         |) b
         |on a.waybill_no=b.properties_waybillno
         |left join
         |(
         |select
         |waybillno,
         |phonezone
         |from
         |(
         |select
         |waybillno,
         |phonezone,
         |zonecode
         |from ods_kafka_fvp.fvp_core_fact_route
         |where inc_day='$incDay'
         |and opcode = '80'
         |and waybillno is not null and waybillno!=''
         |and phonezone is not null and phonezone!=''
         |) t1 left join dm_gis.st_department t2
         |on t1.zonecode=t2.zno_code
         |--where t2.city_code in ($singleCityCode)
         |group by waybillno,phonezone
         |) c
         |on a.waybill_no=c.waybillno
         |left join
         |(
         |select
         |waybill_no,
         |consignee_addr,
         |cargo_type_code,
         |real_product_code,
         |freight_payment_type_code
         |from dm_gis.tt_waybill_hook
         |where inc_day='$incDay'
         |--and dest_dist_code in ($singleCityCode)
         |) d
         |on a.waybill_no=d.waybill_no
         |left join
         |(
         |select
         |properties_waybillno,
         |max(time) as time
         |from
         |(
         |select
         |properties_waybillno,
         |time,
         |properties_zonecode
         |from dm_sfxg.product_inc_ubas_next_app
         |where inc_day='$incDay'
         |and event_id='1041'
         |) t1 left join dm_gis.st_department t2
         |on t1.properties_zonecode=t2.zno_code
         |--where t2.city_code in ($singleCityCode)
         |group by properties_waybillno
         |) e
         |on a.waybill_no=e.properties_waybillno
         |""".stripMargin
    /*val joinWaybillSql =
      s"""
         |select
         | a.waybill_no
         |,a.area_code
         |,a.city_code
         |,a.dest_zone_code
         |,a.aoi_code
         |,a.aoi_name
         |,a.barscantm80
         |,a.lng80
         |,a.lat80
         |,a.point_cnt_30s_before_80
         |,case when a.track_30s_before_80_in_aoi = '' or a.track_30s_before_80_in_aoi is null or a.track_30s_before_80_in_aoi = '[]' then f.driver_track else a.track_30s_before_80_in_aoi end as track_30s_before_80_in_aoi
         |,a.istougui
         |,a.iszijiziqu
         |,a.isexternal
         |,a.isfwsjg2g
         |,a.couriercode
         |,a.aoi_type_code
         |,a.aoi_type_name
         |,a.iscopyphone
         |,b.properties_gpslongitude as copyphone_longitude
         |,b.properties_gpslatitude as copyphone_latitude
         |,b.properties_operatime as copyphone_operatime
         |,c.phonezone as phonezone
         |,d.consignee_addr as consignee_addr
         |,d.cargo_type_code as cargo_type_code
         |,d.real_product_code as real_product_code
         |,d.freight_payment_type_code as freight_payment_type_code
         |,e.time as timestamp_80_pre
         |from
         |(
         |select
         |waybill_no
         |,area_code
         |,city_code
         |,dest_zone_code
         |,aoi_code
         |,aoi_name
         |,barscantm80
         |,lng80
         |,lat80
         |,point_cnt_30s_before_80
         |,track_30s_before_80_in_aoi
         |,istougui
         |,iszijiziqu
         |,isexternal
         |,isfwsjg2g
         |,couriercode
         |,aoi_type_code
         |,aoi_type_name
         |,iscopyphone
         |from dm_gis.lbs_loc_index
         |where inc_day='$incDay'
         |and istougui <> '1'
         |and iszijiziqu <> '1'
         |and isexternal <> '1'
         |and (isfwsjg2g <> '1' or isfwsjg2g is null)
         |--and city_code in ($singleCityCode)
         |group by waybill_no,area_code,city_code,dest_zone_code,aoi_code,aoi_name,barscantm80,lng80,lat80,point_cnt_30s_before_80,track_30s_before_80_in_aoi,istougui,iszijiziqu,isexternal,isfwsjg2g,couriercode,aoi_type_code,aoi_type_name,iscopyphone
         |) a
         |left join
         |(
         |select
         |properties_waybillno
         |,properties_gpslongitude
         |,properties_gpslatitude
         |,properties_operatime
         |from
         |(select
         |properties_waybillno
         |,properties_gpslongitude
         |,properties_gpslatitude
         |,properties_operatime
         |,properties_zonecode
         |from dm_sfxg.product_inc_ubas_next_app
         |where inc_day='$incDay'
         |and event_id='21510'
         |) t1 left join dm_gis.st_department t2
         |on t1.properties_zonecode=t2.zno_code
         |--where t2.city_code in ($singleCityCode)
         |) b
         |on a.waybill_no=b.properties_waybillno
         |left join
         |(
         |select
         |waybillno,
         |phonezone
         |from
         |(
         |select
         |waybillno,
         |phonezone,
         |zonecode
         |from ods_kafka_fvp.fvp_core_fact_route
         |where inc_day='$incDay'
         |and opcode = '80'
         |and waybillno is not null and waybillno!=''
         |and phonezone is not null and phonezone!=''
         |) t1 left join dm_gis.st_department t2
         |on t1.zonecode=t2.zno_code
         |--where t2.city_code in ($singleCityCode)
         |group by waybillno,phonezone
         |) c
         |on a.waybill_no=c.waybillno
         |left join
         |(
         |select
         |waybill_no,
         |consignee_addr,
         |cargo_type_code,
         |real_product_code,
         |freight_payment_type_code
         |from dm_gis.tt_waybill_hook
         |where inc_day='$incDay'
         |--and dest_dist_code in ($singleCityCode)
         |) d
         |on a.waybill_no=d.waybill_no
         |left join
         |(
         |select
         |properties_waybillno,
         |max(time) as time
         |from
         |(
         |select
         |properties_waybillno,
         |time,
         |properties_zonecode
         |from dm_sfxg.product_inc_ubas_next_app
         |where inc_day='$incDay'
         |and event_id='1041'
         |) t1 left join dm_gis.st_department t2
         |on t1.properties_zonecode=t2.zno_code
         |--where t2.city_code in ($singleCityCode)
         |group by properties_waybillno
         |) e
         |on a.waybill_no=e.properties_waybillno
         |
         |left join
         |
         |(SELECT waybill_no,driver_track FROM dm_gis.sf_order_rider_track where inc_day = '20221207') f
         |
         |on a.waybill_no = f.waybill_no
         |""".stripMargin*/
    logger.error("====>>>joinWaybillSql:" + joinWaybillSql)
    val joinWaybillDf: DataFrame = spark.sql(joinWaybillSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("joinWaybillDf的数量：" + joinWaybillDf.count())
    //and aoi_type_code in ('120302','120301','120305')
    joinWaybillDf
  }


  def noviceStation(spark: SparkSession, incDay: String,singleCityCode:String,cnyzAoiPath: String,calPartitions:Int) = {
    val noviceStationDf: DataFrame = spark.read
      .option("inferschema", "false")
      .option("header", false)
      .option("encoding", "UTF-8")
      .csv(cnyzAoiPath)
      .toDF("id", "city_code", "name", "x", "y", "aoiid", "type")
      //.where(s"city_code in ($singleCityCode)")
      //.filter(obj => {obj.getString(1).equals(singleCityCode)})
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("noviceStationDf数据量：" + noviceStationDf.count())
    logger.error("cnyzAoiPath:"+cnyzAoiPath)
    noviceStationDf
  }

  /*def noviceStation(spark: SparkSession, incDay: String,singleCityCode:String,cnyzAoiPath: String,calPartitions:Int) = {
    val sql =
      s"""
         |select
         |	row_number() over(order by city_code) as id
         |	,city_code
         |	,name
         |	,x
         |	,y
         |	,aoiid
         |	,type
         |from
         |(
         |	select
         |		 city_code
         |		,station_name as name
         |		,longitude as x
         |		,latitude as y
         |		,aoi_id as aoiid
         |		,'1' as type
         |	from
         |	dm_gis.competitor_result
         |	where inc_day = '20221210'
         |	and has_station = '1'
         |	and station_status = '1'
         |	and station_brand in ('CN','CNYZ','CNGZ')
         |
         |	union all
         |
         |	select
         |		 city_code
         |		,station_name as name
         |		,longitude as x
         |		,latitude as y
         |		,aoi_id as aoiid
         |		,'2' as type
         |	from
         |	dm_gis.competitor_result
         |	where inc_day = '20221210'
         |	and has_station = '1'
         |	and station_status = '1'
         |	and station_brand in ('CN','CNYZ','CNGZ')
         |) as tmp
         |""".stripMargin
    val noviceStationDf = spark.sql(sql)
      //.where(s"city_code in ($singleCityCode)")
      //.filter(obj => {obj.getString(1).equals(singleCityCode)})
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("noviceStationDf数据量：" + noviceStationDf.count())
    //logger.error("cnyzAoiPath:"+cnyzAoiPath)
    noviceStationDf

  }*/

  def addFieldWaybill(spark: SparkSession, joinWaybillDf: DataFrame, noviceStationDf: DataFrame,calPartitions:Int,incDay:String,singleCityCode:String) = {
    import spark.implicits._
    //同一小哥相邻妥投准备页面时间timestamp_80_pre加工
    joinWaybillDf.createOrReplaceTempView("joinWaybillTmp")
    val joinWaybillSql=
      """
        |select
        |*,
        |case when (timestamp_80_pre is null or timestamp_80_pre ='') and (timestamp_80_pre_next is null or timestamp_80_pre_next='') then 0 when timestamp_80_pre is not null and timestamp_80_pre !='' and timestamp_80_pre_next is not null and timestamp_80_pre_next!='' then floor((cast(timestamp_80_pre as bigint)-cast(timestamp_80_pre_next as bigint))/1000) else 'Nal' end as time_diff_80_pre,
        |case when (barscantm80 is null or barscantm80 ='') and (barscantm80_next is null or barscantm80_next='') then 0 when barscantm80 is not null and barscantm80 !='' and barscantm80_next is not null and barscantm80_next!='' then floor((cast(barscantm80 as bigint)-cast(barscantm80_next as bigint))/1000) else 'Nal' end as time_diff
        |from
        |(
        |select
        |*,
        |lag(timestamp_80_pre,1) over(partition by couriercode order by timestamp_80_pre) as timestamp_80_pre_next,
        |lag(barscantm80,1) over(partition by couriercode order by barscantm80) as barscantm80_next
        |from joinWaybillTmp
        |) a
        |""".stripMargin
    logger.error("joinWaybillSql:"+joinWaybillSql)
    val timeDiffDf: DataFrame = spark.sql(joinWaybillSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("timeDiffDf:"+timeDiffDf.count())
    joinWaybillDf.unpersist()
    //80前30s内轨迹点最近多少米内有菜鸟cnyz_dis加工
    val noviceStationArray: Array[JSONObject] = SparkUtils.getDfToJson(spark, noviceStationDf)
      .filter(obj=> {
        val type1: String = JSONUtil.getJsonVal(obj,"type","")
        type1=="2"
      }).collect()
    val noviceStationaArrayBR: Broadcast[Array[JSONObject]] = spark.sparkContext.broadcast(noviceStationArray)
    val timeDiffRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, timeDiffDf,calPartitions)
    val cnyzDisRdd = timeDiffRdd.repartition(2000).map(obj => {
      val track_30s_before_80_in_aoi_sting: String = JSONUtil.getJsonVal(obj, "track_30s_before_80_in_aoi","")
      val track_30s_before_80_in_aoi: JSONArray = JSON.parseArray(track_30s_before_80_in_aoi_sting)
      val distanceExternal = new ArrayBuffer[(Double, String,Double,Double)]()
      val city_code: String = JSONUtil.getJsonVal(obj, "city_code","")
      val noviceStationArrayFilter: Array[JSONObject] = noviceStationaArrayBR.value.filter(obj => {
        val novice_station_city_code: String = JSONUtil.getJsonVal(obj, "city_code", "")
        city_code == novice_station_city_code
      })
      //var tag = 0
      try {
        for (i <- 0 until (track_30s_before_80_in_aoi.size())) {
          val track: JSONObject = track_30s_before_80_in_aoi.getJSONObject(i)
          val track_x: Double = JSONUtil.getJsonVal(track, "x", "").toDouble
          //logger.error("track_x"+track_x)
          //obj.put("track_x",track_x)
          val track_y: Double = JSONUtil.getJsonVal(track, "y", "").toDouble

          //logger.error("track_y"+track_y)
          val nameDistanceArray = new ArrayBuffer[(Double, String,Double,Double)]()
          for (j <- noviceStationArrayFilter.indices) {
            val noviceStationObject: JSONObject = noviceStationArrayFilter(j)
            //obj.put("noviceStationObject",noviceStationObject)
            val noviceStation_x: Double = JSONUtil.getJsonVal(noviceStationObject, "x", "").toDouble
            //logger.error("===x:"+noviceStation_x)
            //obj.put("noviceStation_x",noviceStation_x)
            val noviceStation_y: Double = JSONUtil.getJsonVal(noviceStationObject, "y", "").toDouble

            //logger.error("===y:"+noviceStation_y)
            // obj.put("noviceStation_y",noviceStation_y)
            val name: String = JSONUtil.getJsonVal(noviceStationObject, "name", "")
            val distance: Double = MapDistance.getDistance2(track_x, track_y, noviceStation_x, noviceStation_y)
            //logger.error("distance"+distance)
            //obj.put("distance",distance)
            nameDistanceArray.append((distance, name,noviceStation_x,noviceStation_y))
          }
          if (nameDistanceArray.nonEmpty){
            val distanceInternalMin: (Double, String, Double, Double) = nameDistanceArray.toList.min
            distanceExternal.append(distanceInternalMin)
          }

        }
      }catch{
        case _:Exception=>
      }

      if (distanceExternal.nonEmpty){
        //logger.error("====求出距离最小值")
        val name_min: String = distanceExternal.min._2
        val distance_min: Double = distanceExternal.min._1
        val cnyz_x_coord: Double = distanceExternal.min._3
        val cnyz_y_coord: Double = distanceExternal.min._4
        obj.put("cnyz_name", name_min)
        obj.put("cnyz_dis", distance_min.toInt)
        obj.put("cnyz_x_coord", cnyz_x_coord)
        obj.put("cnyz_y_coord", cnyz_y_coord)
      }
      obj
    })
    //添加gf_flag1
    val gfFlag1Rdd: RDD[JSONObject] = cnyzDisRdd.map(obj => {
      val iscopyphone: String = JSONUtil.getJsonVal(obj, "iscopyphone", "")
      val cnyz_dis: String = JSONUtil.getJsonVal(obj, "cnyz_dis", "")
      val cnyz_name: String = JSONUtil.getJsonVal(obj, "cnyz_name", "")
      val time_diff_80_pre: String = JSONUtil.getJsonVal(obj, "time_diff_80_pre", "")
      val cnyz_x_coord: Double = JSONUtil.getJsonDouble(obj, "cnyz_x_coord", 0.0)
      val cnyz_y_coord: Double = JSONUtil.getJsonDouble(obj, "cnyz_y_coord", 0.0)
      var is_copyphone_80_pre = 0
      var cnyz_name_gf_flag_1 = ""
      var x_coord_flag_1 = 0.0
      var y_coord_flag_1 = 0.0
      if (iscopyphone == "1" && StringUtils.isNoneEmpty(cnyz_dis) && cnyz_dis.toDouble <= 30 && time_diff_80_pre!="Nal" && time_diff_80_pre.toInt >= 0 && time_diff_80_pre.toInt <= 1000) {
        is_copyphone_80_pre = 1
        cnyz_name_gf_flag_1=cnyz_name
        x_coord_flag_1=cnyz_x_coord
        y_coord_flag_1=cnyz_y_coord
      }
      obj.put("is_copyphone_80_pre", is_copyphone_80_pre)
      obj.put("cnyz_name_gf_flag_1", cnyz_name_gf_flag_1)
      obj.put("x_coord_flag_1", x_coord_flag_1)
      obj.put("y_coord_flag_1", y_coord_flag_1)
      obj
    })
    //80坐标最近多少米内有菜鸟：80_dis加工
    val dis80Df: DataFrame = gfFlag1Rdd.map(obj => {

      val aoi_type_name: String = JSONUtil.getJsonVal(obj, "aoi_type_name", "")
      val isfwsjg2g: String = JSONUtil.getJsonVal(obj, "isfwsjg2g", "")
      val copyphone_operatime: String = JSONUtil.getJsonVal(obj, "copyphone_operatime", "")
      val time_diff_80_pre: String = JSONUtil.getJsonVal(obj, "time_diff_80_pre", "")
      val cargo_type_code: String = JSONUtil.getJsonVal(obj, "cargo_type_code", "")
      val track_30s_before_80_in_aoi: String = JSONUtil.getJsonVal(obj, "track_30s_before_80_in_aoi", "")
      val timestamp_80_pre_next: String = JSONUtil.getJsonVal(obj, "timestamp_80_pre_next", "")
      val istougui: String = JSONUtil.getJsonVal(obj, "istougui", "")
      val couriercode: String = JSONUtil.getJsonVal(obj, "couriercode", "")
      val real_product_code: String = JSONUtil.getJsonVal(obj, "real_product_code", "")
      val city_code: String = JSONUtil.getJsonVal(obj, "city_code", "")
      val aoi_code: String = JSONUtil.getJsonVal(obj, "aoi_code", "")
      val aoi_name: String = JSONUtil.getJsonVal(obj, "aoi_name", "")
      val freight_payment_type_code: String = JSONUtil.getJsonVal(obj, "freight_payment_type_code", "")
      val timestamp_80_pre: String = JSONUtil.getJsonVal(obj, "timestamp_80_pre", "")
      val barscantm80: String = JSONUtil.getJsonVal(obj, "barscantm80", "")
      val iszijiziqu: String = JSONUtil.getJsonVal(obj, "iszijiziqu", "")
      val waybill_no: String = JSONUtil.getJsonVal(obj, "waybill_no", "")
      val copyphone_longitude: String = JSONUtil.getJsonVal(obj, "copyphone_longitude", "")
      val point_cnt_30s_before_80: String = JSONUtil.getJsonVal(obj, "point_cnt_30s_before_80", "")
      val iscopyphone: String = JSONUtil.getJsonVal(obj, "iscopyphone", "")
      val time_diff: String = JSONUtil.getJsonVal(obj, "time_diff", "")
      val is_copyphone_80_pre: String = JSONUtil.getJsonVal(obj, "is_copyphone_80_pre", "")
      val phonezone: String = JSONUtil.getJsonVal(obj, "phonezone", "")
      val copyphone_latitude: String = JSONUtil.getJsonVal(obj, "copyphone_latitude", "")
      val isexternal: String = JSONUtil.getJsonVal(obj, "isexternal", "")
      val barscantm80_next: String = JSONUtil.getJsonVal(obj, "barscantm80_next", "")
      val area_code: String = JSONUtil.getJsonVal(obj, "area_code", "")
      val aoi_type_code: String = JSONUtil.getJsonVal(obj, "aoi_type_code", "")
      val dest_zone_code: String = JSONUtil.getJsonVal(obj, "dest_zone_code", "")
      val consignee_addr: String = JSONUtil.getJsonVal(obj, "consignee_addr", "")
      val cnyz_dis: String = JSONUtil.getJsonVal(obj, "cnyz_dis", "")
      val cnyz_name: String = JSONUtil.getJsonVal(obj, "cnyz_name", "")
      val cnyz_x_coord: Double = JSONUtil.getJsonDouble(obj, "cnyz_x_coord", 0.0)
      val cnyz_y_coord: Double = JSONUtil.getJsonDouble(obj, "cnyz_y_coord", 0.0)
      val cnyz_name_gf_flag_1: String = JSONUtil.getJsonVal(obj, "cnyz_name_gf_flag_1", "")
      val x_coord_flag_1: Double = JSONUtil.getJsonDouble(obj, "x_coord_flag_1", 0.0)
      val y_coord_flag_1: Double = JSONUtil.getJsonDouble(obj, "y_coord_flag_1", 0.0)
      val distanceExternal = new ArrayBuffer[(Double, String,Double,Double)]()
      val lng80_old: String = JSONUtil.getJsonVal(obj, "lng80", "")
      val lat80_old: String = JSONUtil.getJsonVal(obj, "lat80", "")
      var lng80: Double = 0.0
      var lat80: Double = 0.0
      if (StringUtils.isNoneEmpty(lng80_old) && StringUtils.isNoneEmpty(lat80_old) ){
        lng80 =lng80_old.toDouble
        lat80 =lat80_old.toDouble
      }
      val noviceStationArrayFilter: Array[JSONObject] = noviceStationaArrayBR.value.filter(obj => {
        val novice_station_city_code: String = JSONUtil.getJsonVal(obj, "city_code", "")
        city_code == novice_station_city_code
      })
      try {

        for (j <- noviceStationArrayFilter.indices) {
          val noviceStationObject: JSONObject = noviceStationArrayFilter(j)
          val noviceStation_x: Double = JSONUtil.getJsonVal(noviceStationObject, "x", "").toDouble
          val noviceStation_y: Double = JSONUtil.getJsonVal(noviceStationObject, "y", "").toDouble
          val name: String = JSONUtil.getJsonVal(noviceStationObject, "name", "")
          val distance_80: Double = MapDistance.getDistance2(lng80, lat80, noviceStation_x, noviceStation_y)
          distanceExternal.append((distance_80, name,noviceStation_x,noviceStation_y))
        }
      }catch{
        case _:Exception=>
      }


      if (distanceExternal.nonEmpty){
        val distanceExternalMin80: Double = distanceExternal.min._1
        val name_80: String = distanceExternal.min._2
        val x_coord_80: Double = distanceExternal.min._3
        val y_coord_80: Double = distanceExternal.min._4
        obj.put("dis_80", distanceExternalMin80.toString)
        obj.put("name_80", name_80)
        obj.put("x_coord_80", x_coord_80)
        obj.put("y_coord_80", y_coord_80)
      }
      val dis_80: String = JSONUtil.getJsonVal(obj, "dis_80", "")
      val name_80: String = JSONUtil.getJsonVal(obj, "name_80", "")
      val x_coord_80: Double = JSONUtil.getJsonDouble(obj, "x_coord_80", 0.0)
      val y_coord_80: Double = JSONUtil.getJsonDouble(obj, "y_coord_80", 0.0)
      dis80New(aoi_type_name,isfwsjg2g,copyphone_operatime,time_diff_80_pre,cargo_type_code,track_30s_before_80_in_aoi,timestamp_80_pre_next,istougui,lat80,couriercode,real_product_code,city_code,aoi_code,aoi_name,freight_payment_type_code,timestamp_80_pre,barscantm80,iszijiziqu,waybill_no,copyphone_longitude,point_cnt_30s_before_80,iscopyphone,time_diff,is_copyphone_80_pre,phonezone,copyphone_latitude,isexternal,barscantm80_next,area_code,dis_80,aoi_type_code,dest_zone_code,consignee_addr,lng80,cnyz_dis,cnyz_name,name_80,cnyz_name_gf_flag_1,x_coord_flag_1,y_coord_flag_1,x_coord_80,y_coord_80,cnyz_x_coord,cnyz_y_coord)
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dis80Df:"+dis80Df.count())
    timeDiffDf.unpersist()
    dis80Df.createOrReplaceTempView("dis80Tmp")
    val dis80Sql=
      """
        |select
        |*,
        |count(waybill_no) over(partition by couriercode,barscantm80) as waybill_no_count,
        |count(consignee_addr) over(partition by couriercode,substring(barscantm80,0,10),aoi_code,consignee_addr) as waybill_no_aoi_addr_count,
        |count(waybill_no) over(partition by couriercode,substring(barscantm80,0,10),aoi_code) as waybill_no_aoi_count
        |from dis80Tmp
        |""".stripMargin
    val waybillNoCountDf: DataFrame = spark.sql(dis80Sql)
    //添加gf_flag2、gf_flag3、gf_flag4
    val waybillNoCountRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, waybillNoCountDf,calPartitions)
    val gfFlag2Rdd: RDD[JSONObject] = waybillNoCountRdd.map(obj => {
      val dis80: String = JSONUtil.getJsonVal(obj, "dis_80", "")
      val name_80: String = JSONUtil.getJsonVal(obj, "name_80", "")
      val x_coord_80: Double = JSONUtil.getJsonDouble(obj, "x_coord_80", 0.0)
      val y_coord_80: Double = JSONUtil.getJsonDouble(obj, "y_coord_80", 0.0)
      val point_cnt_30s_before_80: String = JSONUtil.getJsonVal(obj, "point_cnt_30s_before_80", "")
      val time_diff: String = JSONUtil.getJsonVal(obj, "time_diff", "")
      val aoi_type_code: String = JSONUtil.getJsonVal(obj, "aoi_type_code", "")
      val cnyz_dis: String = JSONUtil.getJsonVal(obj, "cnyz_dis", "")
      val cnyz_name: String = JSONUtil.getJsonVal(obj, "cnyz_name", "")
      val x_coord_flag_1: Double = JSONUtil.getJsonDouble(obj, "x_coord_flag_1", 0.0)
      val y_coord_flag_1: Double = JSONUtil.getJsonDouble(obj, "y_coord_flag_1", 0.0)
      val waybill_no_count: Long = JSONUtil.getJsonLong(obj, "waybill_no_count", 0)
      val time_diff_80_pre: String = JSONUtil.getJsonVal(obj, "time_diff_80_pre", "")
      val couriercode: String = JSONUtil.getJsonVal(obj, "couriercode", "")
      val phonezone: String = JSONUtil.getJsonVal(obj, "phonezone", "")
      val waybill_no_aoi_addr_count: Long = JSONUtil.getJsonLong(obj, "waybill_no_aoi_addr_count", 0)
      val waybill_no_aoi_count: Long = JSONUtil.getJsonLong(obj, "waybill_no_aoi_count", 0)
      val cnyz_x_coord: Double = JSONUtil.getJsonDouble(obj, "cnyz_x_coord", 0.0)
      val cnyz_y_coord: Double = JSONUtil.getJsonDouble(obj, "cnyz_y_coord", 0.0)

      val aoi_type_code_array: Array[String] = Array("120301", "120302", "141201", "141206")
      var is_80_aoi_type = 0
      var cnyz_name_gf_flag_2 = ""
      var x_coord_flag_2 = 0.0
      var y_coord_flag_2 = 0.0
      if (StringUtils.isNoneEmpty(dis80) && dis80.toDouble <= 15 && StringUtils.isNoneEmpty(point_cnt_30s_before_80) && point_cnt_30s_before_80.toInt > 0 && time_diff!="Nal"  && time_diff.toInt >= 0 && time_diff.toInt <= 3 && aoi_type_code_array.contains(aoi_type_code)) {
        is_80_aoi_type = 1
        cnyz_name_gf_flag_2=name_80
        x_coord_flag_2=x_coord_80
        y_coord_flag_2=y_coord_80
      }
      var is_aoi_type_waybill_count = 0
      var cnyz_name_gf_flag_3 = ""
      var x_coord_flag_3 = 0.0
      var y_coord_flag_3 = 0.0
      if (StringUtils.isNoneEmpty(cnyz_dis) && cnyz_dis.toDouble <= 30 && waybill_no_count >= 3 && aoi_type_code_array.contains(aoi_type_code)) {
        is_aoi_type_waybill_count = 1
        cnyz_name_gf_flag_3=cnyz_name
        x_coord_flag_3=cnyz_x_coord
        y_coord_flag_3=cnyz_y_coord
      }
      val aoi_type_code_array_4: Array[String] = Array("141201", "141206")
      var is_80_aoi_type_80_pre = 0
      if (time_diff == "0" && time_diff_80_pre == "0" && waybill_no_count >= 10 && aoi_type_code_array_4.contains(aoi_type_code) && couriercode!="") {
        is_80_aoi_type_80_pre = 1
      }

      var is_aoi_type_address_count = 0
      var cnyz_name_gf_flag_5 = ""
      var x_coord_flag_5 = 0.0
      var y_coord_flag_5 = 0.0
      if (waybill_no_aoi_count>=6 && aoi_type_code=="120302" && ((StringUtils.isNoneEmpty(dis80) && dis80.toDouble<=60) || (StringUtils.isNoneEmpty(cnyz_dis) && cnyz_dis.toDouble <=60)) && waybill_no_aoi_addr_count==1 && (phonezone=="" || phonezone=="null" || phonezone == null)){
        is_aoi_type_address_count=1
        if ((StringUtils.isNoneEmpty(cnyz_dis) && StringUtils.isNoneEmpty(dis80) && cnyz_dis.toDouble < dis80.toDouble) || (StringUtils.isNoneEmpty(cnyz_dis) && StringUtils.isEmpty(dis80))){
          cnyz_name_gf_flag_5=cnyz_name
          x_coord_flag_5=cnyz_x_coord
          y_coord_flag_5=cnyz_y_coord
        }else if((StringUtils.isNoneEmpty(cnyz_dis) && StringUtils.isNoneEmpty(dis80) && cnyz_dis.toDouble > dis80.toDouble) || (StringUtils.isEmpty(cnyz_dis) && StringUtils.isNoneEmpty(dis80))){
          cnyz_name_gf_flag_5=name_80
          x_coord_flag_5=x_coord_80
          y_coord_flag_5=y_coord_80
        }
      }

      var is_aoi_type_80_waybill_count = 0
      var cnyz_name_gf_flag_6 = ""
      var x_coord_flag_6 = 0.0
      var y_coord_flag_6 = 0.0
      if (waybill_no_aoi_count>=6 && aoi_type_code_array_4.contains(aoi_type_code) && ((StringUtils.isNoneEmpty(dis80) && dis80.toDouble<=100) || (StringUtils.isNoneEmpty(cnyz_dis) && cnyz_dis.toDouble <=100))){
        is_aoi_type_80_waybill_count = 1
        if ((StringUtils.isNoneEmpty(cnyz_dis) && StringUtils.isNoneEmpty(dis80) && cnyz_dis.toDouble < dis80.toDouble) || (StringUtils.isNoneEmpty(cnyz_dis) && StringUtils.isEmpty(dis80))){
          cnyz_name_gf_flag_6=cnyz_name
          x_coord_flag_6=cnyz_x_coord
          y_coord_flag_6=cnyz_y_coord
        }else if((StringUtils.isNoneEmpty(cnyz_dis) && StringUtils.isNoneEmpty(dis80) && cnyz_dis.toDouble > dis80.toDouble) || (StringUtils.isEmpty(cnyz_dis) && StringUtils.isNoneEmpty(dis80))){
          cnyz_name_gf_flag_6=name_80
          x_coord_flag_6=x_coord_80
          y_coord_flag_6=y_coord_80
        }
      }
      obj.put("is_80_aoi_type", is_80_aoi_type)
      obj.put("cnyz_name_gf_flag_2", cnyz_name_gf_flag_2)
      obj.put("x_coord_flag_2", x_coord_flag_2)
      obj.put("y_coord_flag_2", y_coord_flag_2)

      obj.put("is_aoi_type_waybill_count", is_aoi_type_waybill_count)
      obj.put("cnyz_name_gf_flag_3", cnyz_name_gf_flag_3)
      obj.put("x_coord_flag_3", x_coord_flag_3)
      obj.put("y_coord_flag_3", y_coord_flag_3)

      obj.put("is_80_aoi_type_80_pre", is_80_aoi_type_80_pre)

      obj.put("is_aoi_type_address_count", is_aoi_type_address_count)
      obj.put("cnyz_name_gf_flag_5", cnyz_name_gf_flag_5)
      obj.put("x_coord_flag_5", x_coord_flag_5)
      obj.put("y_coord_flag_5", y_coord_flag_5)

      obj.put("is_aoi_type_80_waybill_count", is_aoi_type_80_waybill_count)
      obj.put("cnyz_name_gf_flag_6", cnyz_name_gf_flag_6)
      obj.put("x_coord_flag_6", x_coord_flag_6)
      obj.put("y_coord_flag_6", y_coord_flag_6)

      obj
    })
    //增加track_30s_before_80_in_aoi_cnyz
    val noviceStation3Array: Array[JSONObject] = SparkUtils.getDfToJson(spark, noviceStationDf)
      .filter(obj=>{
        val type2: String = JSONUtil.getJsonVal(obj, "type", "")
        type2=="2"
      }).collect()
    val noviceStation3ArrayBR: Broadcast[Array[JSONObject]] = spark.sparkContext.broadcast(noviceStation3Array)
    val trackCnyzRdd: RDD[JSONObject] = gfFlag2Rdd.repartition(2000).map(obj => {
      val track_30s_before_80_in_aoi_string: String = JSONUtil.getJsonVal(obj, "track_30s_before_80_in_aoi", "")
      val track_30s_before_80_in_aoi: JSONArray = JSON.parseArray(track_30s_before_80_in_aoi_string)
      val distanceExternal = new ArrayBuffer[(Double, String,Double,Double)]()
      val city_code: String = JSONUtil.getJsonVal(obj, "city_code","")
      val noviceStation3ArrayFilter: Array[JSONObject] = noviceStation3ArrayBR.value.filter(obj => {
        val novice_station_city_code: String = JSONUtil.getJsonVal(obj, "city_code", "")
        city_code == novice_station_city_code
      })
      try {

        for (i <- 0 until (track_30s_before_80_in_aoi.size())) {

          val trackObject: JSONObject = track_30s_before_80_in_aoi.getJSONObject(i)
          val track_x: Double = JSONUtil.getJsonVal(trackObject, "x", "").toDouble
          val track_y: Double = JSONUtil.getJsonVal(trackObject, "y", "").toDouble

          val nameDistanceArray = new ArrayBuffer[(Double, String,Double,Double)]()
          for (j <- noviceStation3ArrayFilter.indices) {
            val noviceStationObject: JSONObject = noviceStation3ArrayFilter(j)
            val noviceStation_x: Double = JSONUtil.getJsonVal(noviceStationObject, "x", "").toDouble
            val noviceStation_y: Double = JSONUtil.getJsonVal(noviceStationObject, "y", "").toDouble
            val distance: Double = MapDistance.getDistance2(track_x, track_y, noviceStation_x, noviceStation_y)
            val name: String = JSONUtil.getJsonVal(noviceStationObject, "name", "")
            nameDistanceArray.append((distance, name,noviceStation_x,noviceStation_y))
          }
          if (nameDistanceArray.nonEmpty){
            val distanceInternalMin: (Double, String, Double, Double) = nameDistanceArray.min
            distanceExternal.append(distanceInternalMin)
            val distanceExternalMin: Double = distanceInternalMin._1
            val nameExternalMin: String = distanceInternalMin._2
            val noviceStation_x_min: Double = distanceInternalMin._3
            val noviceStation_y_min: Double = distanceInternalMin._4
            trackObject.put("name", nameExternalMin)
            trackObject.put("distance", distanceExternalMin)
            trackObject.put("noviceStation_x_min", noviceStation_x_min)
            trackObject.put("noviceStation_y_min", noviceStation_y_min)
          }
        }
      }catch {
        case _:Exception =>
      }
      obj.put("track_30s_before_80_in_aoi_cnyz",track_30s_before_80_in_aoi)
      if (distanceExternal.nonEmpty){
        val name_min: String = distanceExternal.min._2
        val distance_min: Double = distanceExternal.min._1
        val x_min: Double = distanceExternal.min._3
        val y_min: Double = distanceExternal.min._4
        obj.put("name_min", name_min)
        obj.put("distance_min", distance_min.toInt)
        obj.put("x_min", x_min)
        obj.put("y_min", y_min)
      }
      obj
    })

    //计算copyphone_oPeratime与barscantm80之间的时间差
    val trackRdd: RDD[JSONObject] = trackCnyzRdd.map(obj => {
      val copyphone_operatime: String = JSONUtil.getJsonVal(obj, "copyphone_operatime", "")
      val barscantm80: String = JSONUtil.getJsonVal(obj, "barscantm80", "")
      var copyphone_barsan_tm = ""
      if (StringUtils.isNoneEmpty(copyphone_operatime) && StringUtils.isNoneEmpty(barscantm80)) {
        copyphone_barsan_tm = ((barscantm80.toLong - copyphone_operatime.toLong) / 1000).toString
      }
      val name_min: String = JSONUtil.getJsonVal(obj,"name_min","")
      val distance_min: Int = JSONUtil.getJsonValInt(obj, "distance_min", 10000)
      val x_min: Double = JSONUtil.getJsonDouble(obj, "x_min", 0.0)
      val y_min: Double = JSONUtil.getJsonDouble(obj, "y_min", 0.0)

      var Is_bar30s_copyphone3000 = 0
      var cnyz_Is_bar30s_copyphone3000 = ""
      var Is_bar30s_copyphone3000_x = 0.0
      var Is_bar30s_copyphone3000_y = 0.0
      if (distance_min <= 80 && StringUtils.isNoneEmpty(copyphone_barsan_tm) && copyphone_barsan_tm.toLong <= 3000) {
        Is_bar30s_copyphone3000 = 1
        cnyz_Is_bar30s_copyphone3000 = name_min
        Is_bar30s_copyphone3000_x = x_min
        Is_bar30s_copyphone3000_y = y_min
      }
      obj.put("Is_bar30s_copyphone3000", Is_bar30s_copyphone3000)
      obj.put("cnyz_Is_bar30s_copyphone3000", cnyz_Is_bar30s_copyphone3000)
      obj.put("Is_bar30s_copyphone3000_x", Is_bar30s_copyphone3000_x)
      obj.put("Is_bar30s_copyphone3000_y", Is_bar30s_copyphone3000_y)

      val phonezone: String = JSONUtil.getJsonVal(obj, "phonezone", "")
      var Is_bar30s_300_phonezone_cn = 0
      var cnyz_Is_bar30s_300_phonezone_cn = ""
      var Is_bar30s_300_phonezone_cn_x = 0.0
      var Is_bar30s_300_phonezone_cn_y = 0.0
      if (distance_min <= 300 && phonezone.contains("菜鸟")) {
        Is_bar30s_300_phonezone_cn = 1
        cnyz_Is_bar30s_300_phonezone_cn = name_min
        Is_bar30s_300_phonezone_cn_x = x_min
        Is_bar30s_300_phonezone_cn_y = y_min
      }
      obj.put("Is_bar30s_300_phonezone_cn", Is_bar30s_300_phonezone_cn)
      obj.put("cnyz_Is_bar30s_300_phonezone_cn", cnyz_Is_bar30s_300_phonezone_cn)
      obj.put("Is_bar30s_300_phonezone_cn_x", Is_bar30s_300_phonezone_cn_x)
      obj.put("Is_bar30s_300_phonezone_cn_y", Is_bar30s_300_phonezone_cn_y)
      obj
    })
    //判断track_30s_before_80_in_aoi_cnyz
    val phonezoneNameMatch300Rdd: RDD[JSONObject] = trackRdd.map(obj => {
      val track_30s_before_80_in_aoi_cnyz: JSONArray = JSONUtil.getJsonArrayMulti(obj, "track_30s_before_80_in_aoi_cnyz")
      val phonezone: String = JSONUtil.getJsonVal(obj, "phonezone", "")
      var nameMatchSuccessSet: Set[(String,Double,Double)] = Set()
      var Is_bar30s_phonezone_namematch_300 = 0
      var cnyz_Is_bar30s_phonezone_namematch_300 = ""
      var Is_bar30s_phonezone_namematch_300_x = 0.0
      var Is_bar30s_phonezone_namematch_300_y = 0.0
      for (i <- 0 until (track_30s_before_80_in_aoi_cnyz.size())) {
        val track_30s_before_80_in_aoi_cnyz_object: JSONObject = track_30s_before_80_in_aoi_cnyz.getJSONObject(i)
        val name: String = JSONUtil.getJsonVal(track_30s_before_80_in_aoi_cnyz_object, "name", "")
        val distance: Double = JSONUtil.getJsonDouble(track_30s_before_80_in_aoi_cnyz_object, "distance", 0.0)
        val noviceStation_x_min: Double = JSONUtil.getJsonDouble(track_30s_before_80_in_aoi_cnyz_object, "noviceStation_x_min", 0.0)
        val noviceStation_y_min: Double = JSONUtil.getJsonDouble(track_30s_before_80_in_aoi_cnyz_object, "noviceStation_y_min", 0.0)
        if (StringUtils.isNoneEmpty(name) && StringUtils.isNoneEmpty(phonezone)) {
          val phonezoneNew: String = StringNumUtils.outputArabNumberString(phonezone.toLowerCase())
          val nameNew: String = StringNumUtils.outputArabNumberString(name.toLowerCase())
          val pattern: Regex = new Regex("[1-9]\\d*")
          val phonezoneArray: Array[String] = (pattern findAllIn phonezoneNew).toArray
          val nameArray: Array[String] = (pattern findAllIn nameNew).toArray
          if (((phonezoneArray.intersect(nameArray).length ==1 && (phonezoneArray.length == 1 && phonezoneArray(0).length > 1 || nameArray.length == 1 && nameArray(0).length > 1)) || phonezoneArray.intersect(nameArray).length >1)  && distance <= 300) {
            nameMatchSuccessSet += Tuple3(nameNew,noviceStation_x_min,noviceStation_y_min)
          }
        }
      }
      if (nameMatchSuccessSet.size == 1) {
        Is_bar30s_phonezone_namematch_300 = 1
        cnyz_Is_bar30s_phonezone_namematch_300 = nameMatchSuccessSet.head._1
        Is_bar30s_phonezone_namematch_300_x = nameMatchSuccessSet.head._2
        Is_bar30s_phonezone_namematch_300_y = nameMatchSuccessSet.head._3
      }
      obj.put("Is_bar30s_phonezone_namematch_300", Is_bar30s_phonezone_namematch_300)
      obj.put("cnyz_Is_bar30s_phonezone_namematch_300", cnyz_Is_bar30s_phonezone_namematch_300)
      obj.put("Is_bar30s_phonezone_namematch_300_x", Is_bar30s_phonezone_namematch_300_x)
      obj.put("Is_bar30s_phonezone_namematch_300_y", Is_bar30s_phonezone_namematch_300_y)
      obj
    })
    //计算菜鸟驿站(选取type=3的数据)中aoiid与aoi_code一致的数据中的name与phonezone是否匹配
    val phonezoneNameMatchRdd: RDD[JSONObject] = phonezoneNameMatch300Rdd.map(obj => {
      val aoi_code: String = JSONUtil.getJsonVal(obj, "aoi_code", "")
      val city_code: String = JSONUtil.getJsonVal(obj, "city_code","")
      var nameMatchSuccessSet: Set[(String,Double,Double)] = Set()
      var Is_bar30s_phonezone_namematch_aoi = 0
      var cnyz_Is_bar30s_phonezone_namematch_aoi = ""
      var Is_bar30s_phonezone_namematch_aoi_x = 0.0
      var Is_bar30s_phonezone_namematch_aoi_y = 0.0
      val noviceStation3ArrayFilter: Array[JSONObject] = noviceStation3ArrayBR.value.filter(obj => {
        val novice_station_city_code: String = JSONUtil.getJsonVal(obj, "city_code", "")
        city_code == novice_station_city_code
      })
      try{
        for (j <- noviceStation3ArrayFilter.indices) {
          val noviceStation3Object: JSONObject = noviceStation3ArrayFilter(j)
          val aoiid: String = JSONUtil.getJsonVal(noviceStation3Object, "aoiid", "")
          val name: String = JSONUtil.getJsonVal(noviceStation3Object, "name", "")
          val noviceStation_x: Double = JSONUtil.getJsonVal(noviceStation3Object, "x", "").toDouble
          val noviceStation_y: Double = JSONUtil.getJsonVal(noviceStation3Object, "y", "").toDouble

          if (StringUtils.isNoneEmpty(aoi_code) && StringUtils.isNoneEmpty(aoiid) && aoi_code == aoiid) {
            val phonezone: String = JSONUtil.getJsonVal(obj, "phonezone", "")
            if (StringUtils.isNoneEmpty(name) && StringUtils.isNoneEmpty(phonezone)) {
              val phonezoneNew: String = StringNumUtils.outputArabNumberString(phonezone.toLowerCase())
              val nameNew: String = StringNumUtils.outputArabNumberString(name.toLowerCase())
              val pattern: Regex = new Regex("[1-9]\\d*")
              val phonezoneArray: Array[String] = (pattern findAllIn phonezoneNew).toArray
              val nameArray: Array[String] = (pattern findAllIn nameNew).toArray
              if (((phonezoneArray.intersect(nameArray).length ==1 && (phonezoneArray.length == 1 && phonezoneArray(0).length > 1 || nameArray.length == 1 && nameArray(0).length > 1)) || phonezoneArray.intersect(nameArray).length >1)) {
                nameMatchSuccessSet += Tuple3(nameNew,noviceStation_x,noviceStation_y)
              }
            }
          }
        }
      }catch{
        case _:Exception=>
      }

      if (nameMatchSuccessSet.size == 1) {
        Is_bar30s_phonezone_namematch_aoi = 1
        cnyz_Is_bar30s_phonezone_namematch_aoi = nameMatchSuccessSet.head._1
        Is_bar30s_phonezone_namematch_aoi_x = nameMatchSuccessSet.head._2
        Is_bar30s_phonezone_namematch_aoi_y = nameMatchSuccessSet.head._3
      }
      obj.put("Is_bar30s_phonezone_namematch_aoi", Is_bar30s_phonezone_namematch_aoi)
      obj.put("cnyz_Is_bar30s_phonezone_namematch_aoi", cnyz_Is_bar30s_phonezone_namematch_aoi)
      obj.put("Is_bar30s_phonezone_namematch_aoi_x", Is_bar30s_phonezone_namematch_aoi_x)
      obj.put("Is_bar30s_phonezone_namematch_aoi_y", Is_bar30s_phonezone_namematch_aoi_y)
      obj
    })
    //计算80坐标lng80,lat80与最近菜鸟驿站(选取type=3的数据)坐标点间的距离distance_80
    val addBar80PhonecallRdd: RDD[(String, JSONObject)] = phonezoneNameMatchRdd.map(obj => {
      val lng80: Double = JSONUtil.getJsonDouble(obj, "lng80", 0.0)
      val lat80: Double = JSONUtil.getJsonDouble(obj, "lat80", 0.0)
      val nameDistanceExternal = new ArrayBuffer[(Double, String,Double,Double)]()
      val city_code: String = JSONUtil.getJsonVal(obj, "city_code","")

      val noviceStation3ArrayFilter: Array[JSONObject] = noviceStation3ArrayBR.value.filter(obj => {
        val novice_station_city_code: String = JSONUtil.getJsonVal(obj, "city_code", "")
        city_code == novice_station_city_code
      })

      //计算复制电话操作坐标copyphone_longitude, copyphone_latitude与最近菜鸟驿站(选取type=3的数据)坐标点间的距离distance_copyphone
      val copyDistanceExternal = new ArrayBuffer[Double]()
      try {

        for (j <- noviceStation3ArrayFilter.indices) {
          val noviceStationObject: JSONObject = noviceStation3ArrayFilter(j)
          val noviceStation_x: Double = JSONUtil.getJsonVal(noviceStationObject, "x", "").toDouble
          val noviceStation_y: Double = JSONUtil.getJsonVal(noviceStationObject, "y", "").toDouble
          val name: String = JSONUtil.getJsonVal(noviceStationObject, "name", "")
          val distance_80: Double = MapDistance.getDistance2(lng80, lat80, noviceStation_x, noviceStation_y)
          nameDistanceExternal.append((distance_80, name,noviceStation_x,noviceStation_y))
        }
        val copyphone_longitude: Double = JSONUtil.getJsonVal(obj, "copyphone_longitude", "").toDouble
        val copyphone_latitude: Double = JSONUtil.getJsonVal(obj, "copyphone_latitude", "").toDouble


        for (j <- noviceStation3ArrayFilter.indices) {
          val noviceStationObject: JSONObject = noviceStation3ArrayFilter(j)
          val noviceStation_x: Double = JSONUtil.getJsonVal(noviceStationObject, "x", "").toDouble
          val noviceStation_y: Double = JSONUtil.getJsonVal(noviceStationObject, "y", "").toDouble
          val distance_copyphone: Double = MapDistance.getDistance2(copyphone_longitude, copyphone_latitude, noviceStation_x, noviceStation_y)
          copyDistanceExternal.append(distance_copyphone)
        }

      }catch {
        case  _:Exception=>
      }
      var Is_bar80_phonecall = 0
      var cnyz_Is_bar80_phonecall = ""
      var Is_bar80_phonecall_x = 0.0
      var Is_bar80_phonecall_y = 0.0
      try {
        val barscantm80: Long = JSONUtil.getJsonVal(obj, "barscantm80", "").toLong
        val copyphone_oPeratime: Long = JSONUtil.getJsonVal(obj, "copyphone_operatime", "").toLong
        val tt: Long = (barscantm80 - copyphone_oPeratime) / 1000
        val aoi_type_code: String = JSONUtil.getJsonVal(obj, "aoi_type_code", "")
        val aoi_type_code_array_3: Array[String] = Array("120302", "120301", "120305")
        val freight_payment_type_code: Long = JSONUtil.getJsonVal(obj, "freight_payment_type_code", "").toLong

        if (aoi_type_code_array_3.contains(aoi_type_code) && freight_payment_type_code != 2) {
          try {
            val distance_80: Double = nameDistanceExternal.min._1
            val name_80: String = nameDistanceExternal.min._2
            val x_80: Double = nameDistanceExternal.min._3
            val y_80: Double = nameDistanceExternal.min._4
            val distance_copyphone: Double = copyDistanceExternal.min
            if (distance_copyphone <= 30 && distance_80 <= 50 && tt <= 300) {
              Is_bar80_phonecall = 1
              cnyz_Is_bar80_phonecall = name_80
              Is_bar80_phonecall_x = x_80
              Is_bar80_phonecall_y = y_80
            } else {
              if (distance_80 <= 20 && tt <= 1800) {
                Is_bar80_phonecall = 1
                cnyz_Is_bar80_phonecall = name_80
                Is_bar80_phonecall_x = x_80
                Is_bar80_phonecall_y = y_80
              }
            }
          }catch{
            case _: Exception =>
          }
        }
      }catch {
        case _:Exception=>
      }
      obj.put("Is_bar80_phonecall", Is_bar80_phonecall)
      obj.put("cnyz_Is_bar80_phonecall", cnyz_Is_bar80_phonecall)
      obj.put("Is_bar80_phonecall_x", Is_bar80_phonecall_x)
      obj.put("Is_bar80_phonecall_y", Is_bar80_phonecall_y)
      val couriercode: String = JSONUtil.getJsonVal(obj, "couriercode", "")
      (couriercode,obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addBar80PhonecallRdd:"+addBar80PhonecallRdd.count())
    dis80Df.unpersist()
    //在a表中增加计算结果字段Is_fw_related,cnyz_Is_fw_related
    val fgJoinSql=
      s"""
         |select
         |f.waybillno,
         |f.emp_code,
         |f.daili_address,
         |g.barscantm
         |from
         |(
         |select
         |waybillno,
         |emp_code,
         |daili_address
         |from
         |(
         |select
         |waybillno,
         |emp_code,
         |daili_address,
         |zonecode
         |from dm_terminal.yufff_zt_waybill_monitor_dtl
         |where (inc_day='$incDay' or inc_day=regexp_replace(date_add(from_unixtime(unix_timestamp('$incDay','yyyymmdd'),'yyyy-mm-dd'),1),'-',''))
         |and daili_brand='菜鸟驿站'
         |and substring(area_code,0,2)!='FW'
         |) t3
         |left join dm_gis.st_department t4
         |on t3.zonecode=t4.zno_code
         |--where t4.city_code in ($singleCityCode)
         |) f
         |left join
         |(
         |select
         |waybillno,
         |barscantm
         |from
         |(
         |select
         |waybillno,
         |barscantm,
         |zonecode
         |from ods_kafka_fvp.fvp_core_fact_route
         |where inc_day='$incDay'
         |and opcode = '80'
         |)t1
         |left join dm_gis.st_department t2
         |on t1.zonecode=t2.zno_code
         |--where t2.city_code in ($singleCityCode)
         |) g
         |on f.waybillno=g.waybillno
         |""".stripMargin
    val fgJoinDf: DataFrame = spark.sql(fgJoinSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("fgJoinDf:"+fgJoinDf.count())
    val fgJoinRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, fgJoinDf, calPartitions).map(obj => {
      val emp_code: String = JSONUtil.getJsonVal(obj, "emp_code", "")
      (emp_code, obj)
    })
    val addFwRelatedRdd: RDD[JSONObject] = SparkJoin.leftOuterJoinOfLeftLeanElemJSONObject(addBar80PhonecallRdd,fgJoinRdd,15,20)
     // addBar80PhonecallRdd.leftOuterJoin(fgJoinRdd)
      .map(obj => {
      val addTjyZhObject: JSONObject = obj._2._1
      val barscantm80: Long = JSONUtil.getJsonLong(addTjyZhObject, "barscantm80", 0)
      val fgJoinObejct: JSONObject = obj._2._2.getOrElse(new JSONObject())
      val barscantm: Long = JSONUtil.getJsonLong(fgJoinObejct, "barscantm", 0)
      val daili_address: String = JSONUtil.getJsonVal(fgJoinObejct, "daili_address", "")
      val waybillno: String = JSONUtil.getJsonVal(fgJoinObejct, "waybillno", "")
      var ads:Double=99999.0
      if (barscantm!=0){
        ads = ((barscantm - barscantm80) / 1000).abs
      }
      (addTjyZhObject, (ads, daili_address, waybillno))
    }).groupByKey().repartition(1000).map(obj => {
      val addTjyZhObject: JSONObject = obj._1
      val copyphone_operatime: String = JSONUtil.getJsonVal(addTjyZhObject, "copyphone_operatime", "")
      val waybill_no: String = JSONUtil.getJsonVal(addTjyZhObject, "waybill_no", "")
      val fgJoinArray: Iterable[(Double, String, String)] = obj._2
      val min_array: (Double, String, String) = fgJoinArray.min
      val min_tt_fwcn: Double = min_array._1
      val min_daili_address: String = min_array._2
      val waybillnoArray = new ArrayBuffer[String]()
      for (elem <- fgJoinArray.toArray) {
        val waybillno: String = elem._3
        waybillnoArray.append(waybillno)
      }
      var Is_fw_related = 0
      var cnyz_Is_fw_related = ""
      if (((min_tt_fwcn == 0.0) || (min_tt_fwcn <= 120 && StringUtils.isNoneEmpty(copyphone_operatime))) && !waybillnoArray.contains(waybill_no)) {
        Is_fw_related = 1
        cnyz_Is_fw_related = min_daili_address
      }
      addTjyZhObject.put("Is_fw_related", Is_fw_related)
      addTjyZhObject.put("cnyz_Is_fw_related", cnyz_Is_fw_related)
      addTjyZhObject.put("min_tt_fwcn", min_tt_fwcn)
      addTjyZhObject
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addFwRelatedRdd:"+addFwRelatedRdd.count())
    fgJoinDf.unpersist()
    addBar80PhonecallRdd.unpersist()
    //最终投竞业结果输出tjy_zh,is_tjy,cnyz_name,最终的结果表命名为dm_gis.lbs_tjy_result
    val addTjyZhRdd: RDD[JSONObject] = addFwRelatedRdd.map(obj => {
      val is_copyphone_80_pre: Int = JSONUtil.getJsonValInt(obj, "is_copyphone_80_pre", 0)
      val Is_bar30s_copyphone3000: Int = JSONUtil.getJsonValInt(obj, "Is_bar30s_copyphone3000", 0)
      val Is_bar30s_300_phonezone_cn: Int = JSONUtil.getJsonValInt(obj, "Is_bar30s_300_phonezone_cn", 0)
      val Is_bar30s_phonezone_namematch_300: Int = JSONUtil.getJsonValInt(obj, "Is_bar30s_phonezone_namematch_300", 0)
      val Is_bar30s_phonezone_namematch_aoi: Int = JSONUtil.getJsonValInt(obj, "Is_bar30s_phonezone_namematch_aoi", 0)
      val is_80_aoi_type: Int = JSONUtil.getJsonValInt(obj, "is_80_aoi_type", 0)
      val is_aoi_type_waybill_count: Int = JSONUtil.getJsonValInt(obj, "is_aoi_type_waybill_count", 0)
      val Is_bar80_phonecall: Int = JSONUtil.getJsonValInt(obj, "Is_bar80_phonecall", 0)
      val is_80_aoi_type_80_pre: Int = JSONUtil.getJsonValInt(obj, "is_80_aoi_type_80_pre", 0)
      val is_aoi_type_address_count: Int = JSONUtil.getJsonValInt(obj, "is_aoi_type_address_count", 0)
      val is_aoi_type_80_waybill_count: Int = JSONUtil.getJsonValInt(obj, "is_aoi_type_80_waybill_count", 0)
      val cnyz_Is_bar30s_copyphone3000: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar30s_copyphone3000", "")
      val cnyz_Is_bar30s_300_phonezone_cn: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar30s_300_phonezone_cn", "")
      val cnyz_Is_bar30s_phonezone_namematch_300: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar30s_phonezone_namematch_300", "")
      val cnyz_Is_bar30s_phonezone_namematch_aoi: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar30s_phonezone_namematch_aoi", "")
      val cnyz_Is_bar80_phonecall: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar80_phonecall", "")
      val cnyz_name_gf_flag_6: String = JSONUtil.getJsonVal(obj, "cnyz_name_gf_flag_6", "")
      val cnyz_name_gf_flag_5: String = JSONUtil.getJsonVal(obj, "cnyz_name_gf_flag_5", "")
      val cnyz_name_gf_flag_1: String = JSONUtil.getJsonVal(obj, "cnyz_name_gf_flag_1", "")
      val cnyz_name_gf_flag_2: String = JSONUtil.getJsonVal(obj, "cnyz_name_gf_flag_2", "")
      val cnyz_name_gf_flag_3: String = JSONUtil.getJsonVal(obj, "cnyz_name_gf_flag_3", "")
      val x_coord_flag_1: Double = JSONUtil.getJsonDouble(obj, "x_coord_flag_1", 0.0)
      val y_coord_flag_1: Double = JSONUtil.getJsonDouble(obj, "y_coord_flag_1", 0.0)
      val x_coord_flag_2: Double = JSONUtil.getJsonDouble(obj, "x_coord_flag_2", 0.0)
      val y_coord_flag_2: Double = JSONUtil.getJsonDouble(obj, "y_coord_flag_2", 0.0)
      val x_coord_flag_3: Double = JSONUtil.getJsonDouble(obj, "x_coord_flag_3", 0.0)
      val y_coord_flag_3: Double = JSONUtil.getJsonDouble(obj, "y_coord_flag_3", 0.0)
      val x_coord_flag_5: Double = JSONUtil.getJsonDouble(obj, "x_coord_flag_5", 0.0)
      val y_coord_flag_5: Double = JSONUtil.getJsonDouble(obj, "y_coord_flag_5", 0.0)
      val x_coord_flag_6: Double = JSONUtil.getJsonDouble(obj, "x_coord_flag_6", 0.0)
      val y_coord_flag_6: Double = JSONUtil.getJsonDouble(obj, "y_coord_flag_6", 0.0)
      val Is_bar30s_copyphone3000_x: Double = JSONUtil.getJsonDouble(obj, "Is_bar30s_copyphone3000_x", 0.0)
      val Is_bar30s_copyphone3000_y: Double = JSONUtil.getJsonDouble(obj, "Is_bar30s_copyphone3000_y", 0.0)
      val Is_bar30s_300_phonezone_cn_x: Double = JSONUtil.getJsonDouble(obj, "Is_bar30s_300_phonezone_cn_x", 0.0)
      val Is_bar30s_300_phonezone_cn_y: Double = JSONUtil.getJsonDouble(obj, "Is_bar30s_300_phonezone_cn_y", 0.0)
      val Is_bar30s_phonezone_namematch_300_x: Double = JSONUtil.getJsonDouble(obj, "Is_bar30s_phonezone_namematch_300_x", 0.0)
      val Is_bar30s_phonezone_namematch_300_y: Double = JSONUtil.getJsonDouble(obj, "Is_bar30s_phonezone_namematch_300_y", 0.0)
      val Is_bar30s_phonezone_namematch_aoi_x: Double = JSONUtil.getJsonDouble(obj, "Is_bar30s_phonezone_namematch_aoi_x", 0.0)
      val Is_bar30s_phonezone_namematch_aoi_y: Double = JSONUtil.getJsonDouble(obj, "Is_bar30s_phonezone_namematch_aoi_y", 0.0)
      val Is_bar80_phonecall_x: Double = JSONUtil.getJsonDouble(obj, "Is_bar80_phonecall_x", 0.0)
      val Is_bar80_phonecall_y: Double = JSONUtil.getJsonDouble(obj, "Is_bar80_phonecall_y", 0.0)
      val Is_fw_related: Int = JSONUtil.getJsonValInt(obj, "Is_fw_related", 0)
      val cnyz_Is_fw_related: String = JSONUtil.getJsonVal(obj, "cnyz_Is_fw_related", "")

      var tjy_zh = ""
      var is_tjy = 0
      var cnyz_name = ""
      var x_coord = 0.0
      var y_coord = 0.0
      if (Is_fw_related == 1){
        tjy_zh = "Is_fw_related"
        is_tjy = 1
        cnyz_name = cnyz_Is_fw_related
      }else if (is_copyphone_80_pre == 1) {
        tjy_zh = "is_copyphone_80_pre"
        is_tjy = 1
        cnyz_name=cnyz_name_gf_flag_1
        x_coord=x_coord_flag_1
        y_coord=y_coord_flag_1
      } else if (Is_bar30s_copyphone3000 == 1) {
        tjy_zh = "Is_bar30s_copyphone3000"
        is_tjy = 1
        cnyz_name = cnyz_Is_bar30s_copyphone3000
        x_coord=Is_bar30s_copyphone3000_x
        y_coord=Is_bar30s_copyphone3000_y
      } else if (Is_bar30s_300_phonezone_cn == 1) {
        tjy_zh = "Is_bar30s_300_phonezone_cn"
        is_tjy = 1
        cnyz_name = cnyz_Is_bar30s_300_phonezone_cn
        x_coord=Is_bar30s_300_phonezone_cn_x
        y_coord=Is_bar30s_300_phonezone_cn_y
      }else if (Is_bar30s_phonezone_namematch_300 == 1) {
        tjy_zh = "Is_bar30s_phonezone_namematch_300"
        is_tjy = 1
        cnyz_name = cnyz_Is_bar30s_phonezone_namematch_300
        x_coord=Is_bar30s_phonezone_namematch_300_x
        y_coord=Is_bar30s_phonezone_namematch_300_y
      }else if (Is_bar30s_phonezone_namematch_aoi == 1) {
        tjy_zh = "Is_bar30s_phonezone_namematch_aoi"
        is_tjy = 1
        cnyz_name = cnyz_Is_bar30s_phonezone_namematch_aoi
        x_coord=Is_bar30s_phonezone_namematch_aoi_x
        y_coord=Is_bar30s_phonezone_namematch_aoi_y
      }else if (is_80_aoi_type == 1) {
        tjy_zh = "is_80_aoi_type"
        is_tjy = 1
        cnyz_name = cnyz_name_gf_flag_2
        x_coord=x_coord_flag_2
        y_coord=y_coord_flag_2
      }else if (is_aoi_type_waybill_count == 1) {
        tjy_zh = "is_aoi_type_waybill_count"
        is_tjy = 1
        cnyz_name = cnyz_name_gf_flag_3
        x_coord=x_coord_flag_3
        y_coord=y_coord_flag_3
      }else if (Is_bar80_phonecall == 1) {
        tjy_zh = "Is_bar80_phonecall"
        is_tjy = 1
        cnyz_name = cnyz_Is_bar80_phonecall
        x_coord=Is_bar80_phonecall_x
        y_coord=Is_bar80_phonecall_y
      }else if (is_80_aoi_type_80_pre == 1) {
        tjy_zh = "is_80_aoi_type_80_pre"
        is_tjy = 1
      }else if (is_aoi_type_address_count == 1) {
        tjy_zh = "is_aoi_type_address_count"
        is_tjy = 1
        cnyz_name = cnyz_name_gf_flag_5
        x_coord=x_coord_flag_5
        y_coord=y_coord_flag_5
      }else if (is_aoi_type_80_waybill_count == 1) {
        tjy_zh = "is_aoi_type_80_waybill_count"
        is_tjy = 1
        cnyz_name = cnyz_name_gf_flag_6
        x_coord=x_coord_flag_6
        y_coord=y_coord_flag_6
      }
      obj.put("tjy_zh", tjy_zh)
      obj.put("is_tjy", is_tjy)
      obj.put("cnyz_name", cnyz_name)
      obj.put("x_coord", x_coord)
      obj.put("y_coord", y_coord)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addTjyZhRdd:"+addTjyZhRdd.count())
    addFwRelatedRdd.unpersist()
    addTjyZhRdd
  }

  def lbsTjyTableResult(spark: SparkSession, resultRdd: RDD[JSONObject], incDay:String, mode:String, calPartitions:Int,singleCityCode:String) = {
    import spark.implicits._
    val addFieldDf: DataFrame = resultRdd.map(obj => {
      val waybill_no: String = JSONUtil.getJsonVal(obj, "waybill_no", "")
      val area_code: String = JSONUtil.getJsonVal(obj, "area_code", "")
      val city_code: String = JSONUtil.getJsonVal(obj, "city_code", "")
      val dest_zone_code: String = JSONUtil.getJsonVal(obj, "dest_zone_code", "")
      val aoi_code: String = JSONUtil.getJsonVal(obj, "aoi_code", "")
      val aoi_name: String = JSONUtil.getJsonVal(obj, "aoi_name", "")
      val barscantm80: String = JSONUtil.getJsonVal(obj, "barscantm80", "")
      val lng80: String = JSONUtil.getJsonVal(obj, "lng80", "")
      val lat80: String = JSONUtil.getJsonVal(obj, "lat80", "")
      val point_cnt_30s_before_80: String = JSONUtil.getJsonVal(obj, "point_cnt_30s_before_80", "")
      val track_30s_before_80_in_aoi: String = JSONUtil.getJsonVal(obj, "track_30s_before_80_in_aoi", "")
      val istougui: String = JSONUtil.getJsonVal(obj, "istougui", "")
      val iszijiziqu: String = JSONUtil.getJsonVal(obj, "iszijiziqu", "")
      val isexternal: String = JSONUtil.getJsonVal(obj, "isexternal", "")
      val isfwsjg2g: String = JSONUtil.getJsonVal(obj, "isfwsjg2g", "")
      val couriercode: String = JSONUtil.getJsonVal(obj, "couriercode", "")
      val aoi_type_code: String = JSONUtil.getJsonVal(obj, "aoi_type_code", "")
      val aoi_type_name: String = JSONUtil.getJsonVal(obj, "aoi_type_name", "")
      val iscopyphone: String = JSONUtil.getJsonVal(obj, "iscopyphone", "")
      val copyphone_longitude: String = JSONUtil.getJsonVal(obj, "copyphone_longitude", "")
      val copyphone_latitude: String = JSONUtil.getJsonVal(obj, "copyphone_latitude", "")
      val copyphone_operatime: String = JSONUtil.getJsonVal(obj, "copyphone_operatime", "")
      val phonezone: String = JSONUtil.getJsonVal(obj, "phonezone", "")
      val consignee_addr: String = JSONUtil.getJsonVal(obj, "consignee_addr", "")
      val cargo_type_code: String = JSONUtil.getJsonVal(obj, "cargo_type_code", "")
      val real_product_code: String = JSONUtil.getJsonVal(obj, "real_product_code", "")
      val freight_payment_type_code: String = JSONUtil.getJsonVal(obj, "freight_payment_type_code", "")
      val timestamp_80_pre: String = JSONUtil.getJsonVal(obj, "timestamp_80_pre", "")
      val timestamp_80_pre_next: String = JSONUtil.getJsonVal(obj, "timestamp_80_pre_next", "")
      val time_diff_80_pre: String = JSONUtil.getJsonVal(obj, "time_diff_80_pre", "")
      val barscantm80_next: String = JSONUtil.getJsonVal(obj, "barscantm80_next", "")
      val time_diff: String = JSONUtil.getJsonVal(obj, "time_diff", "")
      val cnyz_dis: String = JSONUtil.getJsonVal(obj, "cnyz_dis", "")
      val dis_80: String = JSONUtil.getJsonVal(obj, "dis_80", "")
      val waybill_no_count: Long = JSONUtil.getJsonLong(obj, "waybill_no_count", 0)
      val track_30s_before_80_in_aoi_cnyz: String = JSONUtil.getJsonArrayMulti(obj, "track_30s_before_80_in_aoi_cnyz").toJSONString
      val is_copyphone_80_pre: Int = JSONUtil.getJsonValInt(obj, "is_copyphone_80_pre", 0)
      val is_80_aoi_type: Int = JSONUtil.getJsonValInt(obj, "is_80_aoi_type", 0)
      val is_aoi_type_waybill_count: Int = JSONUtil.getJsonValInt(obj, "is_aoi_type_waybill_count", 0)
      val is_80_aoi_type_80_pre: Int = JSONUtil.getJsonValInt(obj, "is_80_aoi_type_80_pre", 0)
      val Is_bar30s_copyphone3000: Int = JSONUtil.getJsonValInt(obj, "Is_bar30s_copyphone3000", 0)
      val cnyz_Is_bar30s_copyphone3000: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar30s_copyphone3000", "")
      val Is_bar30s_300_phonezone_cn: Int = JSONUtil.getJsonValInt(obj, "Is_bar30s_300_phonezone_cn", 0)
      val cnyz_Is_bar30s_300_phonezone_cn: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar30s_300_phonezone_cn", "")
      val Is_bar30s_phonezone_namematch_300: Int = JSONUtil.getJsonValInt(obj, "Is_bar30s_phonezone_namematch_300", 0)
      val cnyz_Is_bar30s_phonezone_namematch_300: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar30s_phonezone_namematch_300", "")
      val Is_bar30s_phonezone_namematch_aoi: Int = JSONUtil.getJsonValInt(obj, "Is_bar30s_phonezone_namematch_aoi", 0)
      val cnyz_Is_bar30s_phonezone_namematch_aoi: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar30s_phonezone_namematch_aoi", "")
      val Is_bar80_phonecall: Int = JSONUtil.getJsonValInt(obj, "Is_bar80_phonecall", 0)
      val cnyz_Is_bar80_phonecall: String = JSONUtil.getJsonVal(obj, "cnyz_Is_bar80_phonecall", "")
      val tjy_zh: String = JSONUtil.getJsonVal(obj, "tjy_zh", "")
      var is_tjy: Int = JSONUtil.getJsonValInt(obj, "is_tjy", 0)
      val cnyz_name: String = JSONUtil.getJsonVal(obj, "cnyz_name", "")
      val waybill_no_aoi_addr_count: Long = JSONUtil.getJsonLong(obj, "waybill_no_aoi_addr_count", 0)
      val waybill_no_aoi_count: Long = JSONUtil.getJsonLong(obj, "waybill_no_aoi_count", 0)
      val is_aoi_type_address_count: Int = JSONUtil.getJsonValInt(obj, "is_aoi_type_address_count", 0)
      val is_aoi_type_80_waybill_count: Int = JSONUtil.getJsonValInt(obj, "is_aoi_type_80_waybill_count", 0)
      val x_coord: Double = JSONUtil.getJsonDouble(obj, "x_coord", 0.0)
      val y_coord: Double = JSONUtil.getJsonDouble(obj, "y_coord", 0.0)
      val Is_fw_related: Int = JSONUtil.getJsonValInt(obj, "Is_fw_related", 0)
      val cnyz_Is_fw_related: String = JSONUtil.getJsonVal(obj, "cnyz_Is_fw_related", "")
      //val min_tt_fwcn: Double = JSONUtil.getJsonDouble(obj, "min_tt_fwcn", 0.0)
      //val cityArray: Array[String] = Array("551","532","7311","755")
      if (StringUtils.isEmpty(cnyz_name)){
        is_tjy=0
      }
      /*if (cityArray.contains(city_code) && is_tjy==1 && StringUtils.isEmpty(cnyz_name)){
        is_tjy=1
      }else if(!cityArray.contains(city_code) && is_tjy==1 && StringUtils.isEmpty(cnyz_name)){
        is_tjy=0
      }*/
      lbsTjyResult(waybill_no, area_code, city_code, dest_zone_code, aoi_code, aoi_name, barscantm80, lng80, lat80, point_cnt_30s_before_80, track_30s_before_80_in_aoi, istougui, iszijiziqu, isexternal, isfwsjg2g, couriercode, aoi_type_code, aoi_type_name, iscopyphone, copyphone_longitude, copyphone_latitude, copyphone_operatime, phonezone, consignee_addr, cargo_type_code, real_product_code, freight_payment_type_code, timestamp_80_pre, timestamp_80_pre_next, time_diff_80_pre, barscantm80_next, time_diff, cnyz_dis, dis_80, waybill_no_count, track_30s_before_80_in_aoi_cnyz, is_copyphone_80_pre, is_80_aoi_type, is_aoi_type_waybill_count, is_80_aoi_type_80_pre, Is_bar30s_copyphone3000, cnyz_Is_bar30s_copyphone3000, Is_bar30s_300_phonezone_cn, cnyz_Is_bar30s_300_phonezone_cn, Is_bar30s_phonezone_namematch_300, cnyz_Is_bar30s_phonezone_namematch_300, Is_bar30s_phonezone_namematch_aoi, cnyz_Is_bar30s_phonezone_namematch_aoi, Is_bar80_phonecall, cnyz_Is_bar80_phonecall, tjy_zh, is_tjy, cnyz_name,waybill_no_aoi_addr_count,waybill_no_aoi_count,is_aoi_type_address_count,is_aoi_type_80_waybill_count,x_coord,y_coord,Is_fw_related,cnyz_Is_fw_related)
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addFieldDf:"+addFieldDf.count())
    resultRdd.unpersist()
    addFieldDf.createOrReplaceTempView("addAllFieldTmp")
    val waybillNoDistinctSql=
      """
        |select
        |waybill_no, area_code, city_code, dest_zone_code, aoi_code, aoi_name, barscantm80, lng80, lat80, point_cnt_30s_before_80, track_30s_before_80_in_aoi, istougui, iszijiziqu, isexternal, isfwsjg2g, couriercode, aoi_type_code, aoi_type_name, iscopyphone, copyphone_longitude, copyphone_latitude, copyphone_operatime, phonezone, consignee_addr, cargo_type_code, real_product_code, freight_payment_type_code, timestamp_80_pre, timestamp_80_pre_next, time_diff_80_pre, barscantm80_next, time_diff, cnyz_dis, dis_80, waybill_no_count, track_30s_before_80_in_aoi_cnyz, is_copyphone_80_pre, is_80_aoi_type, is_aoi_type_waybill_count, is_80_aoi_type_80_pre, Is_bar30s_copyphone3000, cnyz_Is_bar30s_copyphone3000, Is_bar30s_300_phonezone_cn, cnyz_Is_bar30s_300_phonezone_cn, Is_bar30s_phonezone_namematch_300, cnyz_Is_bar30s_phonezone_namematch_300, Is_bar30s_phonezone_namematch_aoi, cnyz_Is_bar30s_phonezone_namematch_aoi, Is_bar80_phonecall, cnyz_Is_bar80_phonecall, tjy_zh, is_tjy, cnyz_name,waybill_no_aoi_addr_count,waybill_no_aoi_count,is_aoi_type_address_count,is_aoi_type_80_waybill_count,x_coord,y_coord,Is_fw_related,cnyz_Is_fw_related
        |from
        |(
        |select
        |*,
        |row_number() over(partition by waybill_no order by is_tjy desc) as rank
        |from addAllFieldTmp
        |) a
        |where a.rank=1
        |and real_product_code!='SE0134'
        |""".stripMargin
    val waybillNoDistinctDf: DataFrame = spark.sql(waybillNoDistinctSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("waybillNoDistinctDf："+waybillNoDistinctDf.count())
    addFieldDf.unpersist()
    //读取mysql中所有号段配置数据并批量缓存
    //jdkCache()
    //val url: String = PropertyUtil.getPropertyValue("rls-mysql-test.properties", "url")
    val url: String = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rls?useUnicode=true&amp;characterEncoding=utf-8"
    //val username: String = PropertyUtil.getPropertyValue("rls-mysql-test.properties", "username")
    val username: String = "gis_oms_rls"
    //val password: String = PropertyUtil.getPropertyValue("rls-mysql-test.properties", "password")
    val password: String = "gis_oms_rls@123@"
    val conn: Connection = DriverManager.getConnection(url, username, password)
    val sql="select * from TM_NS_CFG"
    val ps: PreparedStatement = conn.prepareStatement(sql)
    val result: ResultSet =ps.executeQuery()
    val nsCfgData: util.ArrayList[NsCfgDto] = new util.ArrayList[NsCfgDto]()
    while (result.next()){
      val ns_code: String = result.getString("ns_code")
      val ns_type_code: String = result.getString("ns_type_code")
      val check_code_rule: String = result.getString("check_code_rule")
      val extend: String = result.getString("extend")
      val dto: NsCfgDto = new NsCfgDto(ns_code, ns_type_code, check_code_rule, extend)
      nsCfgData.add(dto)
    }
    val nsCfgDataBR: Broadcast[util.ArrayList[NsCfgDto]] = spark.sparkContext.broadcast(nsCfgData)
    //过滤出丰网和双捷数据
    val waybillFilterDf: DataFrame = waybillNoDistinctDf.filter(obj => {
      val bool: Boolean = NsCfgUtils.cache(nsCfgDataBR.value)
      logger.error("缓存是否成功："+ bool)
      val waybill_no: String = obj.getString(0)
      !FwExpressUtils.isWaybillNo(waybill_no) && !SJUtils.isWaybillNo(waybill_no)
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("waybillFilterDf:"+waybillFilterDf.count())
    waybillFilterDf.createOrReplaceTempView("dm_lbs_tjy_push_result_dtl_di_tmp")
    spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_push_result_dtl_di partition(inc_day=$incDay) select * from dm_lbs_tjy_push_result_dtl_di_tmp")
    //spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_push_result_dtl_di_20221107_tmp partition(inc_day=$incDay) select * from dm_lbs_tjy_push_result_dtl_di_tmp")
    //spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_push_result_dtl_di_20221207_tmp partition(inc_day=$incDay) select * from dm_lbs_tjy_push_result_dtl_di_tmp")
    //新增输出给同城的表
//    val waybillIstjyDf: DataFrame = waybillFilterDf
//      .where(s"city_code in ($singleCityCode) and is_tjy=1")
    val waybillIstjyDf: DataFrame = waybillFilterDf.where(s"is_tjy=1")
    waybillIstjyDf.createOrReplaceTempView("dm_lbs_tjy_external_result_dtl_di_tmp")
    spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_external_result_dtl_di partition(inc_day=$incDay) select waybill_no,area_code,city_code,dest_zone_code,aoi_code,aoi_name,barscantm80,phonezone from dm_lbs_tjy_external_result_dtl_di_tmp")
    //spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_external_result_dtl_di_20221107_tmp partition(inc_day=$incDay) select waybill_no,area_code,city_code,dest_zone_code,aoi_code,aoi_name,barscantm80,phonezone from dm_lbs_tjy_external_result_dtl_di_tmp")
    //spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_external_result_dtl_di_20221207_tmp partition(inc_day=$incDay) select waybill_no,area_code,city_code,dest_zone_code,aoi_code,aoi_name,barscantm80,phonezone from dm_lbs_tjy_external_result_dtl_di_tmp")

    val waybillFilterCityDf: DataFrame = waybillFilterDf.filter(obj => {
      ("551".equals(obj.getString(2))
        || "755S".equals(obj.getString(3))
        || "755BK".equals(obj.getString(3))
        || "755CM".equals(obj.getString(3))
        || "755BG".equals(obj.getString(3))) && obj.getInt(51)==1
    }).toDF()
    logger.error("waybillFilterCityDf:"+waybillFilterCityDf.count())
    waybillFilterCityDf.createOrReplaceTempView("dm_lbs_tjy_result_dtl_di_tmp")
    spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_result_dtl_di partition(inc_day=$incDay) select * from dm_lbs_tjy_result_dtl_di_tmp")
    //spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_result_dtl_di_20221107_tmp partition(inc_day=$incDay) select * from dm_lbs_tjy_result_dtl_di_tmp")
    //spark.sql(s"insert $mode table dm_gis.dm_lbs_tjy_result_dtl_di_20221207_tmp partition(inc_day=$incDay) select * from dm_lbs_tjy_result_dtl_di_tmp")
  }

//  def aoiidAndENlargeMethod(spark:SparkSession,fOrGTableDf:DataFrame) = {
//    val fOrGTableRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, fOrGTableDf)
//    val resultRdd: RDD[JSONObject] = fOrGTableRdd.repartition(5).map(obj => {
//      val x: String = obj.getString("x")
//      val y: String = obj.getString("y")
//      val aoiObject: JSONObject = HttpClientUtil.getJsonByGet(String.format(xyToAoiURl, x, y), 3)
//      val result: JSONObject = JSONUtil.getJsonObjectMulti(aoiObject, "result")
//      val data: JSONObject = JSONUtil.getJsonObjectMulti(result, "data")
//      val aoi: JSONObject = JSONUtil.getJsonObjectMulti(data, "aoi")
//      val aoi_id: String = JSONUtil.getJsonVal(aoi, "aoi_id", "")
//      val aoi_name: String = JSONUtil.getJsonVal(aoi, "aoi_name", "")
//
//      obj.put("aoi_id", aoi_id)
//      obj.put("aoi_name", aoi_name)
//      if (aoi_id != "") {
//        val aoiEnlargeObject: JSONObject = HttpClientUtil.getJsonByGet(String.format(aoiEnlarge,x,y,aoi_id), 3)
//        val dataEnlarge: String = JSONUtil.getJsonVal(aoiEnlargeObject, "data", "")
//        var is_zyqd_cnyz = 0
//        if (StringUtils.isNoneEmpty(dataEnlarge) && dataEnlarge.toDouble<=50) {
//          is_zyqd_cnyz = 1
//        }
//        obj.put("is_zyqd_cnyz", is_zyqd_cnyz)
//        obj.put("data",dataEnlarge)
//        obj.put("aoiEnlargeObject",aoiEnlargeObject)
//      }
//      obj
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("=======调坐标与aoiid边界的距离接口======")
//    resultRdd.take(5).foreach(println(_))
//    resultRdd
//  }

//  def cxServiceNetwork(spark: SparkSession, incDay: String, singleCityCode:String) = {
//    import spark.implicits._
//    val cxServiceNetworkSql=
//      s"""
//        |select
//        |service_code,
//        |service_name,
//        |service_type,
//        |longitude as x,
//        |latitude as y
//        |from ods_cx.cx_service_network
//        |where inc_day=$incDay
//        |and service_type in ('2','5')
//        |--and Belongdeptcode Like '$singleCityCode%'
//        |""".stripMargin
//    val cxServiceNetworkDf: DataFrame = spark.sql(cxServiceNetworkSql).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("cxServiceNetworkDf数据量："+cxServiceNetworkDf.count())
//    val cxServiceNetworkNewDf: DataFrame = aoiidAndENlargeMethod(spark, cxServiceNetworkDf)
//      .map(obj=>{
//      val service_code: String = JSONUtil.getJsonVal(obj, "service_code", "")
//      val service_name: String = JSONUtil.getJsonVal(obj, "service_name", "")
//      val service_type: String = JSONUtil.getJsonVal(obj, "service_type", "")
//      val x: String = JSONUtil.getJsonVal(obj, "x", "")
//      val y: String = JSONUtil.getJsonVal(obj, "y", "")
//      val aoi_id: String = JSONUtil.getJsonVal(obj, "aoi_id", "")
//      val aoi_name: String = JSONUtil.getJsonVal(obj, "aoi_name", "")
//      val data: String = JSONUtil.getJsonVal(obj, "data", "")
//      val is_zyqd: Int = JSONUtil.getJsonValInt(obj, "is_zyqd_cnyz", 0)
//      cxServiceNetworkClass(service_code,service_name,service_type,x,y,aoi_id,aoi_name,is_zyqd,data)
//    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    cxServiceNetworkNewDf.show(10,false)
//    val cxServiceNetworkAoiidEmpty: Dataset[Row] = cxServiceNetworkDf.filter(obj => {
//      val x: String = obj.getString(3)
//      val y: String = obj.getString(4)
//      val aoi_id: String = obj.getString(5)
//      StringUtils.isNoneEmpty(x) && StringUtils.isNoneEmpty(y) && StringUtils.isEmpty(aoi_id)
//    })
//    logger.error("服务点aoiid为空的数量："+cxServiceNetworkAoiidEmpty.count())
//    cxServiceNetworkNewDf
//  }


//  def noviceStationAddField(spark: SparkSession, noviceStationDf: DataFrame, incDay: String, singleCityCode: String) = {
//    import spark.implicits._
//    val noviceStationNewDf: DataFrame = aoiidAndENlargeMethod(spark, noviceStationDf)
//      .map(obj => {
//        val id: String = JSONUtil.getJsonVal(obj, "id", "")
//        val citycode: String = JSONUtil.getJsonVal(obj, "citycode", "")
//        val x: String = JSONUtil.getJsonVal(obj, "x", "")
//        val y: String = JSONUtil.getJsonVal(obj, "y", "")
//        val aoi_id: String = JSONUtil.getJsonVal(obj, "aoi_id", "")
//        val aoi_name: String = JSONUtil.getJsonVal(obj, "aoi_name", "")
//        val data: String = JSONUtil.getJsonVal(obj, "data", "")
//        val is_cnyz: Int = JSONUtil.getJsonValInt(obj, "is_zyqd_cnyz", 0)
//        noviceStationClass(id, citycode, x, y, aoi_id, aoi_name, is_cnyz,data)
//      }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    noviceStationNewDf.show(10,false)
//    val noviceStationNewAoiidEmpty: Dataset[Row] = noviceStationNewDf.filter(obj => {
//      val x: String = obj.getString(2)
//      val y: String = obj.getString(3)
//      val aoi_id: String = obj.getString(4)
//      StringUtils.isNoneEmpty(x) && StringUtils.isNoneEmpty(y) && StringUtils.isEmpty(aoi_id)
//    })
//    logger.error("菜鸟驿站aoiid为空的数量："+noviceStationNewAoiidEmpty.count())
//    noviceStationNewDf
//
//  }

  def lbsTjyAoiTableResult(spark: SparkSession, incDay: String, waybillNoDistinctDf: DataFrame, cxServiceNetworkNewDf: DataFrame, noviceStationNewDf: DataFrame) = {
    cxServiceNetworkNewDf.createOrReplaceTempView("cxServiceNetworkNewTmp")
    noviceStationNewDf.createOrReplaceTempView("noviceStationNewTmp")
    waybillNoDistinctDf.createOrReplaceTempView("waybillNoDistinctTmp")
    val resultSql=
      """
        |select
        |t1.*,
        |t2.is_zyqd,
        |t3.is_cnyz,
        |t2.data as data_zyqd,
        |t3.data as data_cnyz
        |from waybillNoDistinctTmp t1
        |left join cxServiceNetworkNewTmp t2
        |on t1.aoi_code=t2.aoi_id
        |left join noviceStationNewTmp t3
        |on t1.aoi_code=t3.aoi_id
        |""".stripMargin
    val lbsTjyAoiTableResultDf: DataFrame = spark.sql(resultSql)
    lbsTjyAoiTableResultDf.createOrReplaceTempView("lbsTjyAoiTableResultTmp")
    spark.sql(s"insert overwrite table dm_gis.dm_lbs_tjy_aoi_result_dtl_di partition(inc_day=$incDay) select * from lbsTjyAoiTableResultTmp")
  }

  def execute(incDay: String, singleCityCode: String, mode:String,cnyzAoiPath:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    //关联原始运单、丰源埋点、运单签收、运单信息、签收准备时间数据
    val joinWaybillDf: DataFrame = originalJoinFourthTable(spark, incDay,singleCityCode,calPartitions)
    //读取菜鸟驿站数据
    val noviceStationDf: DataFrame = noviceStation(spark, incDay,singleCityCode,cnyzAoiPath,calPartitions)
    //向运单关联表中添加字段
    val resultRdd: RDD[JSONObject] = addFieldWaybill(spark, joinWaybillDf, noviceStationDf,calPartitions,incDay,singleCityCode).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //插入表dm_gis.lbs_tjy_result
    logger.error("resultRdd数据量："+resultRdd.count())
    lbsTjyTableResult(spark, resultRdd, incDay, mode,calPartitions,singleCityCode)
    resultRdd.unpersist()
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val singleCityCode: String = args(1)
    val mode: String = args(2)
    val cnyzAoiPath: String = args(3)
    execute(incDay,singleCityCode,mode,cnyzAoiPath)
    //execute()
    logger.error("======>>>>>>InvestmentProjectsDesign Execute Ok")
  }
}
