/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2024/2/26
*/

object test {

  def main(args: Array[String]): Unit = {

    val expressTime = "2024-02-05 20:00"

    println(expressTime.takeRight(5).replace(":","").replace(":",""))


  }



}
