package app

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2024/2/23
*/
import net.lingala.zip4j.ZipFile
import org.apache.log4j.Logger

import java.io.File

object UnzipTest {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    var homePath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath;
    val fileName = s"qb_KY_${inc_day}.zip"

    homePath =  homePath.substring(0, homePath.lastIndexOf(File.separator))
    val inputPath = s"${homePath}/${fileName}"
    logger.error(inputPath)

    val zipFile= new ZipFile(inputPath,"jingdui".toCharArray)
    zipFile.extractAll(s"${homePath}/qb_KY_${inc_day}.csv")


  }



}
