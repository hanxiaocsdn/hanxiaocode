package app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.pathSimilar
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{JSONUtils, getSimilarInterface2}

import java.lang
import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger
import scala.collection.mutable.ArrayBuffer
/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2024/2/22
*/
object OilSubsidyTrajSimilar {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def getSourceData(spark: SparkSession, inc_day: String) = {

    val aoi_Sql =
      s"""
         |select
         |aoi_area_id,count(aoi_area_id) aoi_area_id_num
         |from
         |(
         |SELECT aoi_area_id, loginid
         |FROM dm_tc_waybillinfo.schedule_width_data
         |WHERE inc_day = '${inc_day}'
         |AND vehicle = '1'
         |and loginid != ''
         |and loginid is not null
         |AND loginid IN ( SELECT emp_code FROM dm_vms.tm_vms_vehicle_subsicy WHERE inc_day = '${inc_day}')
         |GROUP BY aoi_area_id, loginid
         |) t1
         |group by aoi_area_id
         |having aoi_area_id_num >= 2
       """.stripMargin


    logger.error(aoi_Sql)
    val aoiDf = spark.sql(aoi_Sql)
    aoiDf.createOrReplaceTempView("aoiTable")

    val pathFixSql =
      s"""
         |select
         |    aoi_area_id,loginid un,dept_code,rsp
         |from
         |(
         |SELECT aoi_area_id, loginid,dept_code
         |FROM dm_tc_waybillinfo.schedule_width_data
         |WHERE inc_day = '${inc_day}'
         |AND vehicle = '1'
         |and aoi_area_id in (SELECT aoi_area_id FROM aoiTable)
         |and loginid != ''
         |and loginid is not null
         |AND loginid IN ( SELECT emp_code FROM dm_vms.tm_vms_vehicle_subsicy WHERE inc_day = '${inc_day}')
         |GROUP BY aoi_area_id, loginid,dept_code
         |) a
         |left outer join
         |(
         |select
         |    un, rsp
         |from
         |    dm_gis.path_fix
         |WHERE inc_day = '${inc_day}'
         |) b
         |on a.loginid = b.un
         |""".stripMargin


    logger.error(pathFixSql)
    val pathFixDf = spark.sql(pathFixSql)

    val tarjRdd = SparkUtils.getDfToJson(spark,pathFixDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    val df = spark.read.format("csv")
//      .option("header", "true")
//      .option("delimiter","\t")
//      .csv("d:\\user\\01401062\\桌面\\oilTest.csv")
//    val tarjRdd = SparkUtils.getDfToJson(spark,df)

    logger.error("tarjRdd.count():" + tarjRdd.count())

    tarjRdd

  }

  def calSimilar(trajRdd: RDD[JSONObject]) = {
    //调接口计算相似度
    val simRdd = trajRdd.map(x => {
      val aoi_area_id = x.getString("aoi_area_id")
      (aoi_area_id, x)
    }).aggregateByKey(List[JSONObject]())(Spark.seqOp, Spark.combOp).flatMap(x => {
      val aoi_area_id = x._1
      val list = x._2.sortBy(_.getString("un"))
      val simArray = new ArrayBuffer[JSONObject]()

      for (i <- 0 until list.length - 1) {
        for ( j <- i + 1 until list.length) {
          val jo  = JSON.parseObject(list(i).getString("rsp"))
          val jo2 = JSON.parseObject(list(j).getString("rsp"))
          val joArray1 = new JSONArray()
          val joArray2 = new JSONArray()
          val array1 = try { jo.getJSONArray("tracks") } catch {case e:Exception => new JSONArray()}
          val array2 = try { jo2.getJSONArray("tracks") } catch {case e:Exception => new JSONArray()}

          for (k <- 0 until (array1.size())) {
            val json = array1.getJSONObject(k)
            val x = json.getDouble("x")
            val y = json.getDouble("y")
            val arrayNew = new JSONArray()
            arrayNew.add(x)
            arrayNew.add(y)
            joArray1.add(arrayNew)
          }

          for (k <- 0 until (array2.size())) {
            val json = array2.getJSONObject(k)
            val x = json.getDouble("x")
            val y = json.getDouble("y")
            val arrayNew = new JSONArray()
            arrayNew.add(x)
            arrayNew.add(y)
            joArray2.add(arrayNew)
          }

          val joInput1 = new JSONObject()
          val joInput2 = new JSONObject()
          joInput1.put("rt_coords", joArray1)
          joInput2.put("vehicle_type", "5")
          joInput2.put("rt_coords", joArray2)
//          val simTuple: pathSimilar.Tuple2[lang.Double, lang.Double] = try { pathSimilar.PathSimilar.simProcess(joInput1, joInput2) } catch {case e:Exception => (0.0, 0.0)}
          val simTuple: pathSimilar.Tuple2[lang.Double, lang.Double] = pathSimilar.PathSimilar.simProcess(joInput1, joInput2)

//          val (sim1, sim5) = getSimilarInterface2.getSimilar2(joInput1, joInput2)



          val sim1 = simTuple.first
          val sim5 = simTuple.second

          val resJo = new JSONObject()
          resJo.put("aoi_area_id", aoi_area_id)
          resJo.put("un1", list(i).getString("un"))
          resJo.put("un2", list(j).getString("un"))
          resJo.put("sim1", sim1)
          resJo.put("sim5", sim5)
          resJo.put("dept_code", list(i).getString("dept_code"))

          simArray.append(resJo)
        }
      }
      simArray
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("simRdd.count():" + simRdd.count())
    simRdd.take(10).foreach(println(_))

    simRdd
  }


  def saveTable(spark: SparkSession, similarRdd: RDD[JSONObject], inc_day: String): Unit = {

    import spark.implicits._

    val simTable = "dm_gis.oil_subsidy_path_similar"

    similarRdd.map(x => {
      val aoi_area_id = x.getString("aoi_area_id")
      val un1 = x.getString("un1")
      val un2 = x.getString("un2")
      val sim1 = x.getDouble("sim1")
      val sim5 = x.getDouble("sim5")
      val dept_code = x.getString("dept_code")

      (aoi_area_id, un1, un2, sim1, sim5,dept_code,inc_day)
    }).toDF("aoi_area_id", "un1", "un2", "sim1", "sim5","dept_code","inc_day")
      .write.mode(SaveMode.Overwrite).insertInto(simTable)

    logger.error("save to oil_subsidy_path_similar success")

  }

  def start(inc_day: String): Unit = {
    val spark = Spark.getSparkSession(appName, null,false)
//    val spark = Spark.getSparkSession(appName, null, true)

    spark.sparkContext.setLogLevel("ERROR")

    val trajRdd = getSourceData(spark, inc_day)

    val similarRdd = calSimilar(trajRdd)

    saveTable(spark, similarRdd, inc_day)

  }

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
//    val inc_day = ""

    start(inc_day)
  }




}
