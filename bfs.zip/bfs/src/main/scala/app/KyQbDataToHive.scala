package app

import app.OilSubsidyTrajSimilar.saveTable
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2024/2/26
*/

object KyQbDataToHive {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  case class kyQbData (
                        id: String,
                        send_line: String,
                        collect_line: String,
                        time_dot: String,
                        goods_time: String,
                        service_mode: String,
                        service_mode_name: String,
                        express_time: String,
                        send_area: String,
                        receipt_area: String,
                        delay_tips: String,
                        stowage_flight: String,
                        startend_airport: String,
                        inc_day: String
                      )



  def start(inc_day: String): Unit = {
    val spark = Spark.getSparkSession(appName, null,false)
    //    val spark = Spark.getSparkSession(appName, null, true)

    spark.sparkContext.setLogLevel("ERROR")
    import spark.implicits._

    val df = spark.read.format("csv").option("header", "true").csv("/user/01401062/upload/gis/data/qb_ky/qb_KY_20240205.csv")
    val dataRdd = SparkUtils.getDfToJson(spark,df).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dataRdd.count():"+dataRdd.count())
    dataRdd.take(10).foreach(println)

    val simTable = "dm_gis.dwd_jingdui_qb_ky_quarter"

    dataRdd.map(x => {
      val id = x.getString("_id")
      val send_line = x.getString("sendLine")
      val collect_line = x.getString("collectLine")
      val goods_time = x.getString("goodsTime")
      val service_mode = x.getString("serviceMode")
      val service_mode_name = x.getString("serviceModeName")
      val express_time = x.getString("expressTime")
      val time_dot = x.getString("timeDot") + "D" +  (if (express_time.length >= 5) express_time.takeRight(5).replace(":", "") else "")
      val send_area = x.getString("sendArea")
      val receipt_area = x.getString("receiptArea")
      val delay_tips = x.getString("delayTips")
      val stowage_flight = x.getString("stowageFlight")
      val startend_airport = x.getString("startEndAirport")

      kyQbData(id,send_line,collect_line,time_dot,goods_time,service_mode,service_mode_name,express_time,send_area,receipt_area,delay_tips,stowage_flight,startend_airport,inc_day)

    }).toDF().write.mode(SaveMode.Overwrite).insertInto(simTable)

    logger.error("save to dwd_jingdui_qb_ky_quarter success")

  }



  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    //    val inc_day = ""

    start(inc_day)
  }

}
