package com.sf.gis.java.oms.app;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.oms.controller.WbTrackController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 提供运单和轨迹之间各种基本计算的主入口
 * @author 01370539
 * Created on Mar.30 2023
 */
public class WbTrackApp {
    private static final Logger log = LoggerFactory.getLogger(WbTrackApp.class);
    public static void main(String[] args) {
        log.error(">>>>>>>> start <<<<<<<<");
        String incDay;
        String pgmType;
        if (args.length >= 2) {
            pgmType = args[0];
            incDay = args[1];
            new WbTrackController().dlvDisTrack2Aoi(incDay, pgmType);
        } else {
            log.error("参数异常：{},{}", args);
        }

        log.error(">>>>>>>> end <<<<<<<<");
    }
}
