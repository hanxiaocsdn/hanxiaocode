package com.sf.gis.java.oms.constant.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TmpTaskPojo implements Serializable {
    @Column(name = "src_order_no")
    private String srcOrderNo;
    @Column(name = "address")
    private String address;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "county")
    private String county;
    @Column(name = "comp_name")
    private String compName;
    @Column(name = "mobile")
    private String mobile;
    @Column(name = "phone")
    private String phone;
    @Column(name = "cont_name")
    private String contName;
    @Column(name = "monthly_card_no")
    private String monthlyCardNo;
    @Column(name = "dept_code")
    private String deptCode;
    @Column(name = "team_code")
    private String teamCode;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_code")
    private String aoiCode;
    @Column(name = "aoi_area_code")
    private String aoiAreaCode;
    @Column(name = "aoi_unit")
    private String aoiUnit;
    @Column(name = "address_keyword")
    private String addressKeyword;
    @Column(name = "lp_trans_code")
    private String lpTransCode;
    @Column(name = "aoi_type_code")
    private String aoiTypeCode;
    @Column(name = "vir_map_area")
    private String virMapArea;
    @Column(name = "vir_map_area_mode")
    private String virMapAreaMode;
    @Column(name = "vir_map_dept")
    private String virMapDept;
    @Column(name = "vir_map_cust_mark")
    private String virMapCustMark;
    @Column(name = "aoi_area_group")
    private String aoiAreaGroup;
    @Column(name = "dept_group")
    private String deptGroup;
    @Column(name = "inner_mark")
    private String innerMark;
    @Column(name = "village_code")
    private String villageCode;
    @Column(name = "village_class_code")
    private String villageClassCode;
    @Column(name = "village_flag")
    private String villageFlag;
    @Column(name = "village_town_dist")
    private String villageTownDist;
    @Column(name = "origin_dept")
    private String originDept;
    @Column(name = "aoi_area_group_pf")
    private String aoiAreaGroupPf;
    @Column(name = "poi_ids")
    private String poiIds;
    @Column(name = "poi_level")
    private String poiLevel;
    @Column(name = "applied_aoiId")
    private String appliedAoiId;
    @Column(name = "applied_aoi_code")
    private String appliedAoiCode;
    @Column(name = "applied_aoi_type_code")
    private String appliedAoiTypeCode;
    @Column(name = "applied_aoi_info")
    private String appliedAoiInfo;
    @Column(name = "rs")
    private String rs;
    @Column(name = "inc_day")
    private String incDay;

    public String getSrcOrderNo() {
        return srcOrderNo;
    }

    public void setSrcOrderNo(String srcOrderNo) {
        this.srcOrderNo = srcOrderNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getContName() {
        return contName;
    }

    public void setContName(String contName) {
        this.contName = contName;
    }

    public String getMonthlyCardNo() {
        return monthlyCardNo;
    }

    public void setMonthlyCardNo(String monthlyCardNo) {
        this.monthlyCardNo = monthlyCardNo;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiAreaCode() {
        return aoiAreaCode;
    }

    public void setAoiAreaCode(String aoiAreaCode) {
        this.aoiAreaCode = aoiAreaCode;
    }

    public String getAoiUnit() {
        return aoiUnit;
    }

    public void setAoiUnit(String aoiUnit) {
        this.aoiUnit = aoiUnit;
    }

    public String getAddressKeyword() {
        return addressKeyword;
    }

    public void setAddressKeyword(String addressKeyword) {
        this.addressKeyword = addressKeyword;
    }

    public String getLpTransCode() {
        return lpTransCode;
    }

    public void setLpTransCode(String lpTransCode) {
        this.lpTransCode = lpTransCode;
    }

    public String getAoiTypeCode() {
        return aoiTypeCode;
    }

    public void setAoiTypeCode(String aoiTypeCode) {
        this.aoiTypeCode = aoiTypeCode;
    }

    public String getVirMapArea() {
        return virMapArea;
    }

    public void setVirMapArea(String virMapArea) {
        this.virMapArea = virMapArea;
    }

    public String getVirMapAreaMode() {
        return virMapAreaMode;
    }

    public void setVirMapAreaMode(String virMapAreaMode) {
        this.virMapAreaMode = virMapAreaMode;
    }

    public String getVirMapDept() {
        return virMapDept;
    }

    public void setVirMapDept(String virMapDept) {
        this.virMapDept = virMapDept;
    }

    public String getVirMapCustMark() {
        return virMapCustMark;
    }

    public void setVirMapCustMark(String virMapCustMark) {
        this.virMapCustMark = virMapCustMark;
    }

    public String getAoiAreaGroup() {
        return aoiAreaGroup;
    }

    public void setAoiAreaGroup(String aoiAreaGroup) {
        this.aoiAreaGroup = aoiAreaGroup;
    }

    public String getDeptGroup() {
        return deptGroup;
    }

    public void setDeptGroup(String deptGroup) {
        this.deptGroup = deptGroup;
    }

    public String getInnerMark() {
        return innerMark;
    }

    public void setInnerMark(String innerMark) {
        this.innerMark = innerMark;
    }

    public String getVillageCode() {
        return villageCode;
    }

    public void setVillageCode(String villageCode) {
        this.villageCode = villageCode;
    }

    public String getVillageClassCode() {
        return villageClassCode;
    }

    public void setVillageClassCode(String villageClassCode) {
        this.villageClassCode = villageClassCode;
    }

    public String getVillageFlag() {
        return villageFlag;
    }

    public void setVillageFlag(String villageFlag) {
        this.villageFlag = villageFlag;
    }

    public String getVillageTownDist() {
        return villageTownDist;
    }

    public void setVillageTownDist(String villageTownDist) {
        this.villageTownDist = villageTownDist;
    }

    public String getOriginDept() {
        return originDept;
    }

    public void setOriginDept(String originDept) {
        this.originDept = originDept;
    }

    public String getAoiAreaGroupPf() {
        return aoiAreaGroupPf;
    }

    public void setAoiAreaGroupPf(String aoiAreaGroupPf) {
        this.aoiAreaGroupPf = aoiAreaGroupPf;
    }

    public String getPoiIds() {
        return poiIds;
    }

    public void setPoiIds(String poiIds) {
        this.poiIds = poiIds;
    }

    public String getPoiLevel() {
        return poiLevel;
    }

    public void setPoiLevel(String poiLevel) {
        this.poiLevel = poiLevel;
    }

    public String getAppliedAoiId() {
        return appliedAoiId;
    }

    public void setAppliedAoiId(String appliedAoiId) {
        this.appliedAoiId = appliedAoiId;
    }

    public String getAppliedAoiCode() {
        return appliedAoiCode;
    }

    public void setAppliedAoiCode(String appliedAoiCode) {
        this.appliedAoiCode = appliedAoiCode;
    }

    public String getAppliedAoiTypeCode() {
        return appliedAoiTypeCode;
    }

    public void setAppliedAoiTypeCode(String appliedAoiTypeCode) {
        this.appliedAoiTypeCode = appliedAoiTypeCode;
    }

    public String getAppliedAoiInfo() {
        return appliedAoiInfo;
    }

    public void setAppliedAoiInfo(String appliedAoiInfo) {
        this.appliedAoiInfo = appliedAoiInfo;
    }

    public String getRs() {
        return rs;
    }

    public void setRs(String rs) {
        this.rs = rs;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "TmpTaskPojo{" +
                "srcOrderNo='" + srcOrderNo + '\'' +
                ", address='" + address + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", compName='" + compName + '\'' +
                ", mobile='" + mobile + '\'' +
                ", phone='" + phone + '\'' +
                ", contName='" + contName + '\'' +
                ", monthlyCardNo='" + monthlyCardNo + '\'' +
                ", deptCode='" + deptCode + '\'' +
                ", teampCode='" + teamCode + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiCode='" + aoiCode + '\'' +
                ", aoiAreaCode='" + aoiAreaCode + '\'' +
                ", aoiUnit='" + aoiUnit + '\'' +
                ", addressKeyword='" + addressKeyword + '\'' +
                ", lpTransCode='" + lpTransCode + '\'' +
                ", aoiTypeCode='" + aoiTypeCode + '\'' +
                ", cirMapArea='" + virMapArea + '\'' +
                ", virMapAreaMode='" + virMapAreaMode + '\'' +
                ", virMapDept='" + virMapDept + '\'' +
                ", virMapCustMark='" + virMapCustMark + '\'' +
                ", aoiAreaGroup='" + aoiAreaGroup + '\'' +
                ", deptGroup='" + deptGroup + '\'' +
                ", innerMark='" + innerMark + '\'' +
                ", villageCode='" + villageCode + '\'' +
                ", villageClassCode='" + villageClassCode + '\'' +
                ", villageFlag='" + villageFlag + '\'' +
                ", villageTownDist='" + villageTownDist + '\'' +
                ", originDept='" + originDept + '\'' +
                ", aoiAreaGroupPf='" + aoiAreaGroupPf + '\'' +
                ", poiIds='" + poiIds + '\'' +
                ", poiLevel='" + poiLevel + '\'' +
                ", appliedAoiId='" + appliedAoiId + '\'' +
                ", appliedAoiCode='" + appliedAoiCode + '\'' +
                ", appliedAoiTypeCode='" + appliedAoiTypeCode + '\'' +
                ", appliedAoiInfo='" + appliedAoiInfo + '\'' +
                ", rs='" + rs + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
