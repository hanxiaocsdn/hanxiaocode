package com.sf.gis.java.oms.controller;

import com.sf.gis.java.base.api.AddrApi;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.AddrInfo;
import com.sf.gis.java.base.dto.AtdispatchApiIn;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.pojo.AoiInfo;
import com.sf.gis.java.base.svc.ZcService;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.oms.constant.pojo.ShenJiPojo;
import com.sf.gis.java.oms.service.ShenJiService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.List;

public class ShenJiController {
    private static final Logger log = LoggerFactory.getLogger(ShenJiController.class);

    private static final ShenJiService sjService = new ShenJiService();
    private static final ZcService zcService = new ZcService();

    public void process(String cityCodes, int threadCnt, String startRdDay, long invokeStartTm, long invokeEndTm) {
        log.error("process start. cityCodes - {}, threadCnt - {}, startRdDay - {}, invokeStartTm - {}, invokeEndTm - {}", cityCodes, threadCnt, startRdDay, invokeStartTm, invokeEndTm);

        SparkInfo si = SparkUtil.getSpark(ShenJiController.class.getName());
        List<String> rsPartitionList = sjService.loadAddrAggrRsPartitions(si, startRdDay);
        List<String> cachePartitionList = sjService.loadAddrAggrRsPartitions(si, startRdDay);
        log.error("开始时间 {} 跑数的分区数量为：{}, 缓存的分区量为: {}", startRdDay, rsPartitionList.size(), cachePartitionList.size());

        String[] cityArr = cityCodes.split(",");
        for (String city : cityArr) {
            String finalIncDay = startRdDay + "_" + city;
            if (rsPartitionList.contains(finalIncDay)) {
                log.error("城市：{} 已完成！", city);
                continue;
            }

            if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                log.error("开始处理城市：{} ----------------------------", city);
                JavaRDD<ShenJiPojo> srcRdd;
                if (cachePartitionList.contains(finalIncDay)) {
                    srcRdd = sjService.loadAddrAggrCache(si, finalIncDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                } else {
                    srcRdd = sjService.loadAddrAggrSrc(si, city).persist(StorageLevel.MEMORY_AND_DISK_SER());
                }
                long invokeCnt = srcRdd.filter(o -> StringUtils.isEmpty(o.getAddrName())).count();
                log.error("地址总量为：{}, 需要调用服务的地址量为:{}", srcRdd.count(), invokeCnt);
                srcRdd.take(3).forEach(o -> log.error("运单详细信息：{}", o.toString()));

                String ak = "4da9bfda40954f648f8fd339878961f1";
                String httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(), "01370539", "1005958", "集团审计监察处_地址聚合", "集团审计监察处_地址聚合", HttpConstant.HTTP_URL_ATDISPATCH_API, ak, invokeCnt, threadCnt);
                log.error("调用atpai服务开始，调用服务ID：{}", httpInvokeId);
                JavaRDD<ShenJiPojo> rddAoiAtPai = srcRdd.repartition(threadCnt).map(o -> {
                    if (StringUtils.isEmpty(o.getAddrName())) {
                        if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                            AtdispatchApiIn param = new AtdispatchApiIn();
                            param.setOpt("zh");
                            param.setAk(ak);
                            param.setCity(o.getCityCode());
                            param.setAddress(AddrUtil.getMatch(o.getAddr(), "[\u4e00-\u9fa5-a-zA-Z\\d]+"));
                            AddrInfo rs = AddrApi.atdispatchApi(param, FixedConstant.HTTP_TYPE_PR);
                            o.setAddrName(rs.getAoiId());
                        }
                    }
                    o.setIncDay(finalIncDay);
                    return o;
                }).repartition(SysConstant.PARTITION_COUNT).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("调用atpai后的地址量为:{}", rddAoiAtPai.count());
                rddAoiAtPai.take(3).forEach(o -> log.error("调用atpai后的地址详细信息为：{}", o.toString()));
                log.error("调用atpai服务完成，调用服务ID：{}", httpInvokeId);
                BdpTaskRecordUtil.endNetworkInterface("01370539", httpInvokeId);
                srcRdd.unpersist();

                log.error("调用atpai后的地址有AOI的量为:{}, 无aoi的量为：{}", rddAoiAtPai.filter(o -> StringUtils.isNotEmpty(o.getAddrName())).count(), rddAoiAtPai.filter(o -> StringUtils.isEmpty(o.getAddrName())).count());

                if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                    JavaRDD<AoiInfo> rddAoiInfo = zcService.getCmsAoi(si, city).persist(StorageLevel.MEMORY_AND_DISK_SER());
                    log.error("{} 现存AOI的数量为：{}", city, rddAoiInfo.count());
                    rddAoiInfo.take(3).forEach(o -> log.error("现存AOI详细信息为：{}", o.toString()));

                    JavaRDD<ShenJiPojo> rddFinal = rddAoiAtPai.mapToPair(o -> new Tuple2<>(o.getAddrName(), o)).leftOuterJoin(rddAoiInfo.mapToPair(o -> new Tuple2<>(o.getAoiId(), o))).map(o -> {
                        if (o._2._2.isPresent()) {
                            o._2._1.setAddrName(o._2._2.get().getAoiName());
                        } else {
                            o._2._1.setAddrName(o._2._1.getAddrName() + "_miss");
                        }
                        return o._2._1;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                    log.error("补充了AOI名称的数量为：{}", rddFinal.count());
                    rddFinal.take(3).forEach(o -> log.error("补充了AOI名称的详细信息为：{}", o.toString()));
                    rddAoiAtPai.unpersist();
                    rddAoiInfo.unpersist();

                    DataUtil.saveOverwrite(si, "tmp_dm_gis.dwd_addr_aoi_df", ShenJiPojo.class, rddFinal, "inc_day");
                } else {
                    log.error("{} 入缓存库的数量 - {}", city, rddAoiAtPai.count());
                    DataUtil.saveOverwrite(si, "tmp_dm_gis.dwd_addr_aoi_cache", ShenJiPojo.class, rddAoiAtPai, "inc_day");

                    log.error("当前已跑但未完成的城市为： {}， 当前时间已经不在跑数时间内，程序即将结束！！！", city);
                    break;
                }
            } else {
                log.error("未执行的城市为：{}， 当前时间不在跑数时间内，程序即将结束！！！", city);
                break;
            }
            si.getSession().catalog().clearCache();
        }
        log.error("process end.");
    }
}
