package com.sf.gis.java.oms.app;

import com.sf.gis.java.oms.controller.ShenJiController;
import com.sf.gis.java.oms.controller.TmpTaskController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 审计需求主类
 * @author 01370539
 * Created on Jan.30 2024
 */
public class ShenJiApp {
    private static final Logger log = LoggerFactory.getLogger(ShenJiApp.class);
    public static void main(String[] args) {
        log.error(">>>>>>>> start <<<<<<<<");
        if (args.length >= 5) {
            String cityCodes = args[0];  // 待跑数城市列表
            int threadCnt = Integer.parseInt(args[1]);   // 跑服务线程数量
            String startRdDay = args[2];  // 开始跑数日期
            long invokeStartTm = Long.parseLong(args[3]);   // 跑服务开始时间
            long invokeEndTm = Long.parseLong(args[4]);    // 跑服务结束时间
            new ShenJiController().process(cityCodes, threadCnt, startRdDay, invokeStartTm, invokeEndTm);
        } else {
            log.error("参数异常：{},{}", args);
        }

        log.error(">>>>>>>> end <<<<<<<<");
    }
}
