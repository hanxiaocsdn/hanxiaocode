package com.sf.gis.java.oms.app;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.oms.controller.WbTrackController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 提供轨迹AOI信息
 * @author 01370539
 * Created on Jul.05 2023
 */
public class TrackApp {
    private static final Logger log = LoggerFactory.getLogger(TrackApp.class);
    public static void main(String[] args) {
        log.error(">>>>>>>> start <<<<<<<<");
        String incDay;
        if (args.length >= 1) {
            incDay = args[0];
        } else {
            incDay = DateUtil.getDayBefore(DateUtil.getCurrentDate(), "yyyyMMdd", 1);
        }
        new WbTrackController().getTrackAoi(incDay);
        log.error(">>>>>>>> end <<<<<<<<");
    }
}
