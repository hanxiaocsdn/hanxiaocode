package com.sf.gis.java.oms.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.pojo.TrackInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.pojo.WbTrack;
import org.apache.spark.api.java.JavaRDD;

/**
 * 运单服务
 * @author 01370539
 * Created on Mar.30 2023
 */
public class WbTrackService {
    /**
     * 获取运单派件信息
     */
    public JavaRDD<WbTrack> loadDlvWbHook(SparkInfo si, String incDay) {
        String sql = "select waybill_no, aoi_id, deliver_emp_code courier, inc_day from dm_gis.tt_waybill_hook where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, WbTrack.class);
    }

    /**
     * 数据来自新的运单宽表抽出来的表，由罗振玖生成
     * @param si
     * @param incDay
     * @return
     */
    public JavaRDD<WbTrack> loadDlvWbNew(SparkInfo si, String incDay) {
        String sql = "select waybill_no, aoi_id, deliver_emp_code courier, inc_day from dm_gis.dm_waybill_pai_dtl_di where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, WbTrack.class);
    }

    /**
     * 获取派件巴枪扫描信息
     */
    public JavaRDD<WbTrack> loadDlvFvpRout(SparkInfo si, String incDay) {
        String startDate = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2);
        String sql = "select waybill_no, couriercode courier, barscantm bar_scan_tm, inc_day from (select waybillno waybill_no, couriercode, barscantm, inc_day, row_number() over(partition by waybillno,opcode order by barscantm) rn from ods_kafka_fvp.fvp_core_fact_route where inc_day between '" + startDate + "' and '" + incDay + "' and opcode = '80') tmp where tmp.rn = 1";
        return DataUtil.loadData(si, sql, WbTrack.class);
    }

    /**
     * 获取收件巴枪扫描信息
     */
    public JavaRDD<WbTrack> loadPuFvpRout(SparkInfo si, String incDay) {
        String startDate = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2);
        String sql = "select waybill_no, couriercode courier, barscantm bar_scan_tm, inc_day from (select waybillno waybill_no, couriercode, barscantm, inc_day, row_number() over(partition by waybillno,opcode order by barscantm) rn from ods_kafka_fvp.fvp_core_fact_route where inc_day between '" + startDate + "' and '" + incDay + "' and opcode = '54') tmp where tmp.rn = 1";
        return DataUtil.loadData(si, sql, WbTrack.class);
    }

    /**
     * 获取轨迹相关信息
     */
    public JavaRDD<WbTrack> loadTrackInfo(SparkInfo si, String incDay) {
        String sql = "select un courier, zx lng_track, zy lat_track, tm tm_track, id id_track, tp tp_track, ac ac_track, bn bn_track, ewl ewl_track, app app_track, inc_day from dm_gis.esg_gis_loc_trajectory_ewl where inc_day = '" + incDay + "' and ak = 1";
        return DataUtil.loadData(si, sql, WbTrack.class);
    }

    /**
     * 获取轨迹简单信息
     */
    public JavaRDD<TrackInfo> loadTrackBi(SparkInfo si, String incDay) {
        String sql = "select distinct zx lng, zy lat, inc_day from dm_gis.esg_gis_loc_trajectory_ewl where inc_day = '" + incDay + "' and ak = 1";
        return DataUtil.loadData(si, sql, TrackInfo.class);
    }


}
