package com.sf.gis.java.oms.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.oms.constant.pojo.ShenJiPojo;
import org.apache.spark.api.java.JavaRDD;

import java.util.List;

public class ShenJiService {
    public JavaRDD<ShenJiPojo> loadAddrAggrSrc(SparkInfo si, String city) {
        String sql = "select distinct city_code, decrypt_addr addr from tmp_afs.r_mia_waybill_address_city_s4 where city_code = '" + city + "' and decrypt_addr != '' and decrypt_addr is not null";
        return DataUtil.loadData(si, sql, ShenJiPojo.class);
    }

    public JavaRDD<ShenJiPojo> loadAddrAggrCache(SparkInfo si, String finalIncDay) {
        String sql = "select city_code, addr, addr_name from tmp_dm_gis.dwd_addr_aoi_cache where inc_day = '" + finalIncDay + "'";
        return DataUtil.loadData(si, sql, ShenJiPojo.class);
    }

    public List<String> loadAddrAggrRsPartitions(SparkInfo si, String incDay) {
        String sql = "select distinct(inc_day) from tmp_dm_gis.dwd_addr_aoi_df where inc_day like '" + incDay +"%'";
        List<String> partitions = DataUtil.loadData(si.getSession(), sql).map(o -> {
            return o.getString(0);
        }).collect();
        return partitions;
    }

    public List<String> loadAddrAggrCachePartitions(SparkInfo si, String incDay) {
        String sql = "select distinct(inc_day) from tmp_dm_gis.dwd_addr_aoi_cache where inc_day like '" + incDay +"%'";
        List<String> partitions = DataUtil.loadData(si.getSession(), sql).map(o -> {
            return o.getString(0);
        }).collect();
        return partitions;
    }
}
