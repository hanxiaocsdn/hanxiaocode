package com.sf.gis.java.oms.controller;

import com.sf.gis.java.base.api.AddrApi;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.ChkQueryTcTeamCodeIn;
import com.sf.gis.java.base.dto.ChkQueryTcTeamCodeOut;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.oms.constant.pojo.TmpTaskPojo;
import com.sf.gis.java.oms.service.TmpTaskService;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

public class TmpTaskController {
    private static final Logger log = LoggerFactory.getLogger(TmpTaskController.class);

    private static final TmpTaskService service = new TmpTaskService();

    public void process(String incDay, int threadCnt) {
        log.error("process start. incDay - {}, threadCnt - {}", incDay, threadCnt);

        SparkInfo si = SparkUtil.getSpark(TmpTaskController.class.getName());
        JavaRDD<TmpTaskPojo> rddPojo = service.loadPuWbHook(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        long invokCnt = rddPojo.count();
        log.error("运单量:{}", invokCnt);
        rddPojo.take(3).forEach(o -> log.error("运单详细信息：{}", o.toString()));

        String ak = "77c82ab7a7054f10af86b4422df2f1b2";
        String httpAtShouInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(), "01370539", "957185", "TmpTask", "临时任务-运单结果重复性校验跑数", HttpConstant.HTTP_URL_CHKQUERY_TC_TEAMCODE, ak, invokCnt, threadCnt);
        log.error("调用服务开始，调用服务ID：{}", httpAtShouInvokeId);
        JavaRDD<TmpTaskPojo> rddAoi = rddPojo.repartition(threadCnt).map(o -> {
            ChkQueryTcTeamCodeIn paramIn = new ChkQueryTcTeamCodeIn();
            paramIn.setAk(ak);
            paramIn.setAddress(o.getAddress());
            paramIn.setCityCode(o.getCityCode());
            paramIn.setProvince(o.getProvince());
            paramIn.setCity(o.getCity());
            paramIn.setCounty(o.getCounty());
            paramIn.setPhone(o.getPhone());
            paramIn.setContactsName(o.getContName());
            paramIn.setMobile(o.getMobile());
            paramIn.setCompany(o.getCompName());
            paramIn.setCustomerAccount(o.getMonthlyCardNo());
            ChkQueryTcTeamCodeOut result = AddrApi.chkQueryTcTeamCode(paramIn);
            o.setDeptCode(result.getDeptCode());
            o.setTeamCode(result.getTeamCode());
            o.setAoiId(result.getAoiId());
            o.setAoiCode(result.getAoiCode());
            o.setAoiAreaCode(result.getAoiAreaCode());
            o.setAoiUnit(result.getAoiUnit());
            o.setAddressKeyword(result.getAddressKeyword());
            o.setLpTransCode(result.getLpTransCode());
            o.setAoiTypeCode(result.getAoiTypeCode());
            o.setVirMapArea(result.getVirMapArea());
            o.setVirMapAreaMode(result.getVirMapAreaMode());
            o.setVirMapDept(result.getVirMapDept());
            o.setVirMapCustMark(result.getVirMapCustMark());
            o.setAoiAreaGroup(result.getAoiAreaGroup());
            o.setDeptGroup(result.getDeptGroup());
            o.setInnerMark(result.getInnerMark());
            o.setVillageCode(result.getVillageCode());
            o.setVillageClassCode(result.getVillageClassCode());
            o.setVillageFlag(result.getVillageFlag());
            o.setVillageTownDist(result.getVillageTownDist());
            o.setOriginDept(result.getOriginDept());
            o.setAoiAreaGroupPf(result.getAoiAreaGroupPf());
            o.setPoiIds(result.getPoiIds());
            o.setPoiLevel(result.getPoiLevel());
            o.setAppliedAoiId(result.getAppliedAoiId());
            o.setAppliedAoiCode(result.getAppliedAoiCode());
            o.setAppliedAoiTypeCode(result.getAoiTypeCode());
            o.setAppliedAoiInfo(result.getAppliedAoiInfo());
            o.setRs(result.getRs());
            return o;
        }).repartition(SysConstant.PARTITION_COUNT).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("填充了结果的运单量:{}", rddAoi.count());
        rddPojo.take(3).forEach(o -> log.error("填充了结果的运单详细信息：{}", o.toString()));
        log.error("调用服务完成，调用服务ID：{}", httpAtShouInvokeId);
        BdpTaskRecordUtil.endNetworkInterface("01370539", httpAtShouInvokeId);

        DataUtil.saveOverwrite(si, "tmp_dm_gis.dwd_wb_reapeat_chk_di_toyq", TmpTaskPojo.class, rddAoi, "inc_day");

        log.error("process end. incDay - {}, threadCnt - {}", incDay, threadCnt);
    }
}
