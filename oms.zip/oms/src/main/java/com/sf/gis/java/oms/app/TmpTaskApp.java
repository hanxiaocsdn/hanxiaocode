package com.sf.gis.java.oms.app;

import com.sf.gis.java.oms.controller.TmpTaskController;
import com.sf.gis.java.oms.controller.WbTrackController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 提供运单和轨迹之间各种基本计算的主入口
 * @author 01370539
 * Created on Mar.30 2023
 */
public class TmpTaskApp {
    private static final Logger log = LoggerFactory.getLogger(TmpTaskApp.class);
    public static void main(String[] args) {
        log.error(">>>>>>>> start <<<<<<<<");
        String incDay;
        int threadCnt;
        if (args.length >= 2) {
            incDay = args[0];
            threadCnt = Integer.parseInt(args[1]);
            new TmpTaskController().process(incDay, threadCnt);
        } else {
            log.error("参数异常：{},{}", args);
        }

        log.error(">>>>>>>> end <<<<<<<<");
    }
}
