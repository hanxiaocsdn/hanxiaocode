package com.sf.gis.java.oms.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.api.AoiApi;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.pojo.TrackInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.base.pojo.WbTrack;
import com.sf.gis.java.oms.service.WbTrackService;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.datanucleus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;

/**
 * 提供运单和轨迹之间各种基本计算的控制器，根据参数不同进行不同的计算
 * @author 01370539
 * Created on Mar.30 2023
 */
public class WbTrackController {
    private static final Logger log = LoggerFactory.getLogger(WbTrackController.class);

    private static final WbTrackService wbTrackSvc = new WbTrackService();

    private static final String PGM_TYPE_WBHOOK = "WBHOOK";   // 数据源来自tt_waybill_hook
    private static final String PGM_TYPE_WBINFONEW = "WBINFONEW";   // 数据源来自由罗振玖从dwd.dwd_waybill_info_dtl_di个表抽取出来的派件数据

    /**
     * 小哥巴枪妥投前后5分钟的轨迹，与运单需要妥投的地址的AOI的距离
     * 任务ID：700195
     */
    public void dlvDisTrack2Aoi(String incDay, String pgmType) {
        log.error("start dlvDisTrack2Aoi, incDay - {}", incDay);
        SparkInfo si = SparkUtil.getSpark(WbTrackController.class.getName());

        String taskId;
        String taskName;
        String tblName;
        JavaRDD<WbTrack> rddWb;
        if (PGM_TYPE_WBHOOK.equals(pgmType)) {
            rddWb = wbTrackSvc.loadDlvWbHook(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
            taskId = "700195";
            taskName = "派件地址aoi与轨迹之间";
            tblName = "dm_gis.dwb_wb_track_dlv_di";
        } else {
            rddWb = wbTrackSvc.loadDlvWbNew(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
            taskId = "953836";
            taskName = "新运单宽表派件地址aoi与轨迹之间距离计算";
            tblName = "dm_gis.dwd_newwb_track_dlv_di";
        }
        log.error("------------ 运单数据量：{} ------------", rddWb.count());
        rddWb.take(3).forEach(o -> log.error("运单详细信息：{}", o.toString()));

        JavaRDD<WbTrack> rddRoute = wbTrackSvc.loadDlvFvpRout(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("------------ 巴枪扫描数据量：{} ------------", rddRoute.count());
        rddRoute.take(3).forEach(o -> log.error("巴枪扫描详细信息：{}", o.toString()));

        JavaRDD<WbTrack> rddWbBst = rddWb.mapToPair(o -> new Tuple2<>(o.getWaybillNo() + "_" + o.getCourier() + "_" + o.getIncDay(), o)).groupByKey().leftOuterJoin(rddRoute.mapToPair(o -> new Tuple2<>(o.getWaybillNo() + "_" + o.getCourier() + "_" + o.getIncDay(), o.getBarScanTm())).groupByKey()).flatMap(o -> {
            List<WbTrack> wbList = Lists.newArrayList(o._2._1);
            if (wbList.size() > 1) {
                log.error("dm_gis.tt_waybill_hook 表中 {} 有 {} 条记录，待查验！", o._1, wbList.size());
            }
            if (o._2._2.isPresent()) {
                List<String> barScanTmList = Lists.newArrayList(o._2._2.get());
                if (barScanTmList.size() > 1) {
                    log.error("ods_kafka_fvp.fvp_core_fact_route 表中 {} 有 {} 条记录，待查验！", o._1, barScanTmList.size());
                }
                // 如果有多条巴枪扫描时间，给默认的第一条数据
                wbList.forEach(tmp -> tmp.setBarScanTm(barScanTmList.get(0)));
            }
            return wbList.iterator();
        }).filter(o -> StringUtils.notEmpty(o.getBarScanTm())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("------------ 获取了巴枪扫描时间的运单数据量：{} ------------", rddWbBst.count());
        rddWbBst.take(3).forEach(o -> log.error("获取了巴枪扫描时间的运单详细信息：{}", o.toString()));
        rddWb.unpersist();
        rddRoute.unpersist();

        JavaRDD<WbTrack> rddTrack = wbTrackSvc.loadTrackInfo(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("------------ 轨迹数据量：{} ------------", rddTrack.count());
        rddTrack.take(3).forEach(o -> log.error("轨迹详细信息：{}", o.toString()));

        JavaRDD<WbTrack> rddWbTrack = rddWbBst.mapToPair(o -> new Tuple2<>(o.getCourier(), o)).groupByKey().leftOuterJoin(rddTrack.mapToPair(o -> new Tuple2<>(o.getCourier(), o)).groupByKey()).flatMap(o -> {
            List<WbTrack> rsList = new ArrayList<>();
            List<WbTrack> wbList = Lists.newArrayList(o._2._1);
            if (o._2._2.isPresent()) {
                List<WbTrack> trackList = Lists.newArrayList(o._2._2().get());
                wbList.sort((a,b) -> b.getBarScanTm().compareTo(a.getBarScanTm()));
                trackList.sort((a,b) -> b.getTmTrack().compareTo(a.getTmTrack()));

                long barScanTm;
                long trackTm;
                WbTrack wbTrack;
                for (WbTrack wb : wbList) {
                    barScanTm = Long.parseLong(wb.getBarScanTm());
                    for (WbTrack track : trackList) {
                        wbTrack = new WbTrack(track);
                        trackTm = Long.parseLong(wbTrack.getTmTrack()) * 1000;
                        if (Math.abs(barScanTm - trackTm) <= 300000) {
                           wbTrack.setAoiId(wb.getAoiId());
                           wbTrack.setBarScanTm(wb.getBarScanTm());
                           wbTrack.setWaybillNo(wb.getWaybillNo());
                           rsList.add(wbTrack);
                        }
                    }
                }
            }
            return rsList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("------------ 填充了轨迹信息的运单数据量：{} ------------", rddWbTrack.count());
        rddWbTrack.take(3).forEach(o -> log.error("填充了轨迹信息的运单详细信息：{}", o.toString()));
        rddWbBst.unpersist();
        rddTrack.unpersist();

        JavaPairRDD<String, Iterable<WbTrack>>  rddWbTp = rddWbTrack.mapToPair(o -> new Tuple2<>(o.getAoiId() + "_" + o.getLngTrack() + "_" + o.getLatTrack(), o)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("------------ 需要计算的aoi和轨迹映射量：{} ------------", rddWbTp.count());

        long invokeCnt = rddWbTp.map(o -> {
            String[] keyArr = o._1.split("_");
            if (StringUtils.notEmpty(keyArr[0]) && StringUtils.notEmpty(keyArr[1]) && StringUtils.notEmpty(keyArr[2])) {
                return o._1;
            }
            return null;
        }).filter(o -> !StringUtils.isEmpty(o)).count();
        log.error("------------ 需要调用服务的数量：{} ------------", invokeCnt);

        String httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(),"01370539", taskId, taskName, "基础服务", HttpConstant.HTTP_URL_GETCOORAOIDIST, "", invokeCnt, SysConstant.THREAD_COUNT);
        JavaRDD<WbTrack> rddRs = rddWbTp.flatMap(o -> {
            String[] keyArr = o._1.split("_");
            double dis = -1;
            if (StringUtils.notEmpty(keyArr[0]) && StringUtils.notEmpty(keyArr[1]) && StringUtils.notEmpty(keyArr[2])) {
                dis = AoiApi.getCoorAoiDist(keyArr[0], keyArr[1], keyArr[2]);
            }
            List<WbTrack> wbTrackList = Lists.newArrayList(o._2);
            double finalDis = dis;
            wbTrackList.forEach(tmp -> tmp.setDis(String.valueOf(finalDis)));
            return wbTrackList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("------------ 计算了轨迹与aoi距离的运单数据量：{} ------------", rddRs.count());
        rddRs.take(3).forEach(o -> log.error("计算了轨迹与aoi距离的运单详细信息：{}", o.toString()));
        rddWbTrack.unpersist();
        log.error("调用服务完成，调用服务ID：{}", httpInvokeId);
        BdpTaskRecordUtil.endNetworkInterface("01370539", httpInvokeId);

        DataUtil.saveOverwrite(si, tblName, WbTrack.class, rddRs, "inc_day");
        log.error("end WbTrackController: incDay - {}", incDay);
        si.getSession().catalog().clearCache();
    }

    /**
     * 获取小哥轨迹所属的AOI
     * 任务ID：775238
     */
    public void getTrackAoi(String incDay) {
        log.error("start getTrackAoi, incDay - {}", incDay);
        SparkInfo si = SparkUtil.getSpark(WbTrackController.class.getName());

        JavaRDD<TrackInfo> rddTrack = wbTrackSvc.loadTrackBi(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        long invokeCnt = rddTrack.count();
        log.error("------------ 轨迹数据量：{} ------------", invokeCnt);
        rddTrack.take(3).forEach(o -> log.error("轨迹详细信息：{}", o.toString()));

        String httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(),"01370539", "775238", "小哥轨迹所属AOI计算", "基础服务", HttpConstant.HTTP_URL_GETAOIIDBYPOINT, "", invokeCnt, SysConstant.THREAD_COUNT);
        JavaRDD<TrackInfo> rddTrackAoi = rddTrack.map(o -> {
            String aoiId = AoiApi.getAoiIdByPoint(o.getLng(), o.getLat());
            o.setAoiId(aoiId);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("------------ 获取AOI后的轨迹数据量：{} ------------", rddTrackAoi.count());
        rddTrackAoi.take(3).forEach(o -> log.error("获取AOI后的轨迹详细信息：{}", o.toString()));
        rddTrack.unpersist();
        log.error("调用服务完成，调用服务ID：{}", httpInvokeId);
        BdpTaskRecordUtil.endNetworkInterface("01370539", httpInvokeId);

        DataUtil.saveOverwrite(si, "dm_gis.dwb_track_aoi_di", TrackInfo.class, rddTrackAoi, "inc_day");
        log.error("end getTrackAoi: incDay - {}", incDay);
        si.getSession().catalog().clearCache();
    }

    /**
     * 小哥收件时巴枪妥投前2小时的轨迹，与巴枪54坐标所属AOI、客户寄件地址所属AOI、客户下单地址所属AOI距离计算
     */
    public void puDisTrack2Aoi(String incDay) {

    }
}
