package com.sf.gis.java.oms.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.pojo.WbTrack;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.oms.constant.pojo.TmpTaskPojo;
import org.apache.spark.api.java.JavaRDD;

public class TmpTaskService {
    public JavaRDD<TmpTaskPojo> loadPuWbHook(SparkInfo si, String incDay) {
        String sql = "select distinct sender_address address, sender_city_code city_code, sender_province_name province, sender_city_name city, sender_area_name county, " +
                "sender_company comp_name, sender_mobile mobile, sender_tel phone, sender_name cont_name, monthly_card_no, inc_day " +
                "from tmp_dm_gis.tmp_01374443_dwd_pub_order_dtl_di_20231228_not_in_gis where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, TmpTaskPojo.class);
    }
}
