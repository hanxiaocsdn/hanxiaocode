package com.sf.gis.java.oms.constant.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ShenJiPojo implements Serializable {
    @Column(name = "city_code")
    private String cityCode;

    @Column(name = "addr")
    private String addr;

    @Column(name = "addr_name")
    private String addrName;

    @Column(name = "inc_day")
    private String incDay;

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getAddrName() {
        return addrName;
    }

    public void setAddrName(String addrName) {
        this.addrName = addrName;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "ShenJiPojo{" +
                "cityCode='" + cityCode + '\'' +
                ", addr='" + addr + '\'' +
                ", addrName='" + addrName + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
