package common

import com.alibaba.fastjson.JSONObject
import demand.navi.NaviParse_naviAccrualMoney.{get1, get2, logger}
import demand.utils.JsonUtil
import org.apache.commons.lang3.StringUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}

import java.util
import scala.collection.mutable.ArrayBuffer

/**
 * @description:
 * @author 01418539 caojia
 * @date 2022/10/26 9:55
 */
trait SourceAndDiskCommon {

  def mutiDayRddToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], dateList: ArrayBuffer[String]): Unit = {
   val newResultRdd = resultRdd.persist()
    for (date <- dateList) {
      val resultRdd2 = filterRdd(newResultRdd, date)
      filterRddToHive(spark, resultRdd2, table, structs, keys, date)
    }
    newResultRdd.unpersist()
  }

  def filterRdd(resultRdd: RDD[JSONObject], date: String): RDD[JSONObject] = {
    val dateRdd = resultRdd.filter(json => {
      val inc_day = json.getString("inc_day")
      inc_day != null && inc_day.equals(date)
    }).persist()

    dateRdd
  }

  def filterRddToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], date: String): Unit = {
    saveJSONObjectRDDToHive(spark, resultRdd, table, structs, keys, date)
  }

  def saveJSONObjectRDDToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if (StringUtils.isEmpty(dataBase)) database = "dm_gis" else database = dataBase
    logger.error(">>>table=" + database + "." + table)
    spark.sql(s"use $database")
    //1 构造DataFrame的元数据 StructField
    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    //2 构建StructType用于DataFrame的元数据描述
    val structType = DataTypes.createStructType(structFileds)
    //3 构建Row格式数据集RDD[Row]
    val rowRdd = resultRdd.filter(_ != null).map(obj => {
      var row: Row = null
      try {
        val v = new Array[String](structs.length)
        for (i <- structs.indices) v(i) = JsonUtil.getJsonVal(obj, structs(i).replaceAll("_", ""), "")
        row = RowFactory.create(v: _*)
      } catch {
        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
      }
      row
    }).filter(_ != null)
    // 4 构建DataFrame
    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
    //5 基于Datarame创建临时表
    val tempView = String.format("%s_temp_view", table)
    df.createOrReplaceTempView(tempView)
    //6 分区、表等操作
    val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
    logger.error(">>>删除分区：" + deleteSql)
    spark.sql(deleteSql)
    val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
    logger.error(">>>新建分区：" + createPartitionSql)
    spark.sql(createPartitionSql)
    //7 把临时表的数据刷进hive表中
    spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
    logger.error(">>>数据入hive库结束!")

  }
}
