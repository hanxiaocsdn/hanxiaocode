package demand.eta

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import demand.navi.SaveDataToHive
import demand.utils._
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01368978 on 2021/5/28.
  */
object EtaLogParse {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)



//  /**
//    * 开始程序
//    * @param args
//    * @param spark
//    * @param runDate
//    * @param getDateListF
//    * @param getHiveRddF
//    * @param saveHiveRddF
//    * @return
//    */
//  def start(args: Array[String], spark:SparkSession, runDate:String, getDateListF:(String) => ArrayBuffer[String], getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit): Unit ={
//
//    if (args.length == 0) {
//      //代码内部传入日期参数
//      val date = runDate
//      EtaLogParse.handleTask(spark, date,getDateListF,getHiveRddF,saveHiveRddF)
//    } else if (args.length == 1) {
//      //传入参数，单天任务
//      val date = args(0)
//      EtaLogParse.handleTask(spark, date,getDateListF,getHiveRddF,saveHiveRddF)
//    } else if (args.length == 2) {
//      //传入参数，多天任务 [左闭右开)
//      val startDate = args(0)
//      val endDate = args(1)
//      var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
//      logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
//      for (date <- dateList) {
//        EtaLogParse.handleTask(spark, date,getDateListF,getHiveRddF,saveHiveRddF)
//      }
//    }
//  }
//
//
//  /**
//    * 批量任务
//    *
//    * @param spark
//    * @param startDate
//    * @param endDate
//    * @param getDateListF
//    * @param getHiveRddF
//    * @param saveHiveRddF
//    */
//  def batchTask(spark: SparkSession, startDate: String, endDate: String, getDateListF:(String) => ArrayBuffer[String], getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit): Unit = {
//    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
//    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
//    for (date <- dateList) {
//      handleTask(spark, date,getDateListF,getHiveRddF,saveHiveRddF)
//    }
//  }
//
//
//
//  /**
//    * 解析日志主流程
//    * @param spark
//    * @param endDate
//    * @param getDateListF
//    * @param getHiveRddF
//    * @param saveHiveRddF
//    * @return
//    */
//  def handleTask(spark:SparkSession, endDate:String, getDateListF:(String) => ArrayBuffer[String], getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit): Unit ={
//    val dateList = getDateListF(endDate)
//    logger.error(">>>处理"+dateList.mkString(",")+"号的任务----------------------------------")
//    EtaLogParse.parseLog(spark,getHiveRddF,saveHiveRddF,dateList)
//    logger.error(">>>The End!")
//  }
//
//
//
//  /**
//    * 解析所有日志
//    * @param spark
//    * @param getHiveRddF
//    * @param saveHiveRddF
//    * @param dateList
//    * @return
//    */
//  def parseLog(spark:SparkSession, getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit, dateList:ArrayBuffer[String]): Unit ={
//    logger.error(">>>解析"+dateList.mkString(",")+"号的所有日志")
//    var logType = ""
//    var table = ""
//    var structs:Array[String] = null
//    var keys:Array[String] = null
//
//
//    logType = "etaStartTask"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_start_task_parse"
//    structs = Array("reqid","start_log_tm","starttime","start_time","linecode","vehicle","vehicle_type","origin_type","weight","laodweight","full_loadweight","length","width","height","axle_number","axle_weight","vehicle_color","energy","emitstand","driver_id","passport","track_center_distance","transit_task","start_track_time","initial_start_time","start_latitude","start_longitude")
//    parseSaveLog(spark,ParseLog.getEtaStartTaskRdd,getHiveRddF,ParseLog.computeEtaStartTask,table,structs,structs,saveHiveRddF,dateList)
//
//    logType = "etaCompute"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_compute_parse"
//    structs = Array("reqid","req_order","req_count","distance","costtime","track_time","reqtime","req_time","acttime","list_opt","list_status","list_time","list_dist","list_flen","list_coords","list_links","track_history_arg","track_history_arg_app","track_ak","track_platform","equalbeforetime","x1","y1","x2","y2","plan_date","routeid_input","ft_url","track_history_costtime","ft_status","links","rdynsdlen","rdynsdcnt","routeid_output","ft_dist","ft_highway","ft_tralightcount","ft_tolls","ft_tollsdistance","ft_coords","ft_flen","ft_tlen","is_same","is_match","ft_time_slow_f","coef_median_f","ft_time","ft_arrivetime","ft_arrivetime_slow","opt","sf_costtime","sf_error","gd_url","gd_status","gd_time","gd_dist","gd_highway","gd_tralightcount","gd_tolls","gd_tollsdistance","gd_coords","gd_flen","gd_tlen","gd_arrivetime","ft_gd_diff","gd_costtime","gd_error","zh_opt","zh_url","zh_status","zh_time","zh_costtime","zh_error","routeid_src","track_history_error","relation_id")
//    parseSaveLog(spark,ParseLog.getEtaComputeRdd,getHiveRddF,ParseLog.computeEtaCompute,table,structs,structs,saveHiveRddF,dateList)
//
//    logType = "etaDeptSiteInfo"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_site_info_parse"
//    structs = Array("reqid","src_province","src_region","src_citycode","src_deptcode","src_sitecode","src_longitude","src_latitude","src_radius","src_ploygon","dest_province","dest_region","dest_citycode","dest_deptcode","dest_sitecode","dest_longitude","dest_latitude","dest_radius","dest_ploygon","line_type")
//    parseSaveLog(spark,ParseLog.getEtaDeptSiteInfoRdd,getHiveRddF,ParseLog.computeEtaDeptSiteInfo,table,structs,structs,saveHiveRddF,dateList)
//
//    logType = "etaQuitTask"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_quit_task_parse"
//    structs = Array("reqid","end_log_tm","endtime","end_time","quit_reason_status","quit_track_empty","sf_quit_beyond_maxtime","sf_quittime","sf_arrive_compensatetime","gd_quit_beyond_maxtime","gd_quittime","gd_arrive_compensatetime","repeat_track_arrive_time","in_end_fence_track_time","in_end_fence_track_longitude","in_end_fence_track_latitude","quit_track_longitude","quit_track_latitude","quit_tracktime")
//    parseSaveLog(spark,ParseLog.getEtaQuitTaskRdd,getHiveRddF,ParseLog.computeEtaQuitTask,table,structs,structs,saveHiveRddF,dateList)
//
//    logType = "etaFinishRecallTask"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_finish_recall_parse"
//    structs = Array("reqid","recall_log_time","recall_log_tm","max_track_center_distance","min_track_center_distance","contain_track_valid","judge_degree","dest_deptsite","min_degree","max_degree","track_center_degree","track_time","track_longitude","track_latitude","sf_recall_quitdate","sf_recall_arrive_compensate_time","recall_type","create_time","track_center_distance","track_ak","track_platform","track_history_arg","track_state","track_history_error","route_plan_arg","route_plan_result","route_plan_result_error","recall_track_time")
//    keys = Array("reqid","recall_log_time","recall_log_tm","data.maxTrackCenterDistance","data.minTrackCenterDistance","data.containTrackValid","data.judgeDegree","data.destDeptSite","data.minDegree","data.maxDegree","data.trackCenterDegree","data.trackTime","data.trackLongitude","data.trackLatitude","data.sfRecallQuitDate","data.sfRecallArriveCompensateTime","data.recallType","data.createTime","data.trackCenterDistance","data.trackAk","data.trackPlatform","data.trackHistoryArg","data.state","data.trackHistoryError","data.routePlanArg","data.routePlanResult","data.routePlanResultError","data.trackTime")
//    parseSaveLog(spark,ParseLog.getEtaFinishRecallTaskRdd,getHiveRddF,ParseLog.computeEtaFinishRecallTask,table,structs,keys,saveHiveRddF,dateList)
//
//    logType = "etaStayTracks"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_stay_tracks_detail"
//    structs = Array("reqid","linecode","track_history_arg","track_history_arg_app","stay_start_time ","stay_end_time","stay_duration","stay_start_longitude","stay_start_latitude","stay_end_longitude","stay_end_latitude","specify_start_time","specify_end_time","specify_start_longitude","specify_start_latitude","specify_end_longitude","specify_end_latitude","specify_duration","task_start_time","task_end_time","stay_type")
//    keys = Array("reqid","lineRequireId","track_history_arg","track_history_arg_app","stayStartTime","stayEndTime","stayDuration","stayStartLongitude","stayStartLatitude","stayEndLongitude","stayEndLatitude","specifyStartTime","specifyEndTime","specifyStartLongitude","specifyStartLatitude","specifyEndLongitude","specifyEndLatitude","specifyDuration","taskStartTime","taskEndTime","stayType")
//    parseSaveLog(spark,ParseLog.getEtaStayTracksDetailRdd,getHiveRddF,null,table,structs,keys,saveHiveRddF,dateList)
//
//    logType = "etaGroundTask"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_ground_task_parse"
//    structs = Array("reqid","groundtime","pre_arrive_time","plan_arrive_time","plan_depart_time","actual_depart_time","actual_arrive_time","plan_run_time","dest_sitecode")
//    parseSaveLog(spark,ParseLog.getEtaGroundTaskRdd,getHiveRddF,ParseLog.computeEtaGroundTask,table,structs,structs,saveHiveRddF,dateList)
//
//    logType = "etaFinishPredictTask"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_finish_predict_parse"
//    structs = Array("reqid","req_order","req_count","predict_time","predict_date","center_longitude","center_latitude","track_empty","track_longitude","track_latitude","tracktime","track_center_distance","min_track_center_valid","max_track_center_valid","min_track_center_range","max_track_center_range","track_ak","track_platform")
//    keys = Array("reqid","req_order","req_count","predict_time","predict_date","data.centerLongitude","data.centerLatitude","data.trackEmpty","data.trackLongitude","data.trackLatitude","data.trackTime","data.trackCenterDistance","data.minTrackCenterValid ","data.maxTrackCenterValid","data.minTrackCenterRange","data.maxTrackCenterRange","data.trackAk","data.trackPlatform")
//    parseSaveLog(spark,ParseLog.getEtaFinishPredictTaskRdd,getHiveRddF,null,table,structs,keys,saveHiveRddF,dateList)
//
//    logType = "etaInitialTask"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_initial_task_parse"
//    structs = Array("reqid","req_order","req_count","init_time","init_date","center_longitude","center_latitude","first_track_longitude","first_track_latitude","first_tracktime","second_track_longitude","second_track_latitude","second_tracktime","between_track_distance","track_center_distance","between_track_range","between_track_valid","track_center_range","track_center_valid","track_due","track_empty","track_ak","track_platform","max_track_center_range","max_track_center_valid","before_request_track_range","before_request_track_distance","before_request_track_valid","has_before_valid_request","create_time","start_track_time","start_track_longitude","start_track_latitude","track_history_arg","track_speed","track_speed_valid")
//    keys = Array("reqid","req_order","req_count","init_time","init_date","data.centerLongitude","data.centerLatitude","data.firstTrackLongitude","data.firstTrackLatitude","data.firstTrackTime","data.secondTrackLongitude","data.secondTrackLatitude","data.secondTrackTime","data.betweenTrackDistance","data.trackCenterDistance","data.betweenTrackRange","data.betweenTrackValid","data.trackCenterRange","data.trackCenterValid","data.trackDue","data.trackEmpty","data.trackAk","data.trackPlatform","data.maxTrackCenterRange","data.maxTrackCenterValid","data.beforeRequestTrackRange","data.beforeRequestTrackDistance","data.beforeRequestTrackValid","data.hasBeforeValidRequest","data.createTime","data.startTrackTime","data.startTrackLongitude","data.startTrackLatitude","data.trackHistoryArg","data.trackSpeed","data.trackSpeedValid")
//    parseSaveLog(spark,ParseLog.getEtaInitialTaskRdd,getHiveRddF,null,table,structs,keys,saveHiveRddF,dateList)
//
//    logType = "etaEndFenceFirst"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_end_fence_parse"
//    structs = Array("reqid", "req_order", "req_count", "fence_time", "fence_date", "quit_track_empty", "first_track_longitude", "first_track_latitude", "first_tracktime", "second_track_longitude", "second_track_latitude", "second_tracktime", "first_track_valid", "second_track_valid", "first_track_distance", "second_track_distance", "track_ak", "track_platform")
//    keys = Array("reqid", "req_order", "req_count", "fence_time", "fence_date", "data.quitTrackEmpty", "data.firstTrackLongitude", "data.firstTrackLatitude", "data.firstTrackTime", "data.secondTrackLongitude", "data.secondTrackLatitude", "data.secondTrackTime", "data.firstTrackValid", "data.secondTrackValid", "data.firstTrackDistance", "data.secondTrackDistance", "data.trackAk", "data.trackPlatform")
//    parseSaveLog(spark,ParseLog.getEtaEndFenceFirstRdd,getHiveRddF,null,table,structs,keys,saveHiveRddF,dateList)
//
//    logType = "etaPredictModelInfo"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_predict_model_parse"
//    structs = Array("reqid","datatime","dest_deptcode","src_deptcode","reqtime","size","vehicle","x1","x2","y1","y2","pnsinfo","status","eta","relation_id","weight","driver_id","src_citycode","dest_citycode")
//    parseSaveLog(spark,ParseLog.getEtaPredictModelInfoRdd,getHiveRddF,ParseLog.computeEtaPredictModelInfo,table,structs,structs,saveHiveRddF,dateList)
//
//    logType = "etaStayTracks"
//    logger.error(">>>解析"+dateList.mkString(",")+"号的" + logType + "日志")
//    table = "gis_eta_stay_tracks_parse"
//    structs = Array("reqid","recall_history_costtime","rectify_costtime","rectify_arg","ret","rectify_tracks","mix_track_list","track_ak","staylist","recall_history_error","rectify_error")
//    parseSaveLog(spark,ParseLog.getEtaStayTracksRdd,getHiveRddF,ParseLog.computeEtaStayTracks,table,structs,structs,saveHiveRddF,dateList)
//
//    if(dateList.size > 1){
//      val date0 = dateList(dateList.size - 1)
//      logger.error(">>>统计"+date0+"号的轨迹纠偏指标")
//      StatEtaIndex.statRectifyPerformance(spark,date0)
//    }
//
//    logger.error(">>>关联计算"+dateList.mkString(",")+"号各类型日志")
//    table = "gis_eta_log_parse_union"
//    structs = Array("reqid","req_order","req_count","driver_id","ft_time_km","endtime_km","status","ft_time_diff","ft_time_diff_pct","ft_eta_right","gd_time_diff","gd_time_diff_pct","gd_eta_right","totaltime","sf_recall_time_diff","sf_recall_time_diff_per","sf_recall_right","tl_endtime","actual_time_diff","tl_time","tl_count","ft_arrivetime_slow","pns_time_diff","pns_time_pct","pns_eta_right","plan_arrive_time_diff","plan_time_per","vehicle_type","origin_type","repeat_track_arrive_time","sf_quittime","gd_quittime","endtime","end_time","quit_reason_status","sf_recall_quitdate","line_type","starttime","start_time","src_province","src_region","src_citycode","src_deptcode","src_sitecode","dest_province","dest_region","dest_citycode","dest_deptcode","dest_sitecode","ft_time_slow_f","coef_median_f","is_same","opt","gd_arrivetime","ft_arrivetime","gd_time","gd_status","gd_diff_rate","ft_time","ft_status","ft_diff_rate","zh_time","zh_status","zh_diff_rate","reqtime","req_time","equalbeforetime","pre_arrive_time","plan_run_time","rectify_arg","ret","rectify_tracks","ft_coords","gd_coords","vehicle","distance","sf_right_xiu","sf_diff_per_xiu","sf_diff_time_xiu","gd_right_xiu","gd_diff_per_xiu","gd_diff_time_xiu","quit_track_empty","eta_reqtime","model_status","eta","model_time_diff","model_percent","model_right","transit_task","relation_id","start_track_time")
//    parseSaveLog(spark,ParseLog.getUnionRdd,getHiveRddF,ParseLog.computeUnionFieldRDD,table,structs,structs,saveHiveRddF,dateList)
//
//    EtaSaveDetails.saveDetailsAll(spark,dateList)
//
//  }


  /**
    * 解析日志主流程
    * @param spark
    * @param getRddF
    * @param getHiveRddF
    * @param computeRddF
    * @param table
    * @param structs
    * @param keys
    * @param saveHiveRddF
    * @param dateList
    * @return
    */
  def parseSaveLog(spark:SparkSession, getRddF:(SparkSession,(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject],ArrayBuffer[String]) => RDD[JSONObject], getHiveRddF:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], computeRddF:(RDD[JSONObject]) => RDD[JSONObject], table: String, structs:Array[String], keys:Array[String], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit, dateList:ArrayBuffer[String]): Unit ={
    val etaComputeRdd = getRddF(spark,getHiveRddF,dateList)
    saveHiveRddF(spark,etaComputeRdd,table,structs,keys,dateList)
    etaComputeRdd.unpersist()
  }


  /**
    * 保存到hive日志
    * @param spark
    * @param resultRdd
    * @param table
    * @param structs
    * @param keys
    * @param date
    * @return
    */

  def filterRddToHive(spark:SparkSession, resultRdd:RDD[JSONObject],table: String, structs:Array[String], keys:Array[String],date:String): Unit ={
    SaveDataToHive.saveJSONObjectRDDToHive(spark,resultRdd,table,structs,keys,date)
  }



  /**
    * 过滤有效日志
    * @param spark
    * @param sql
    * @return
    */
  def getValidLog(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val logRdd =  spark.sql(sql).na.fill("").rdd.repartition(6400).map(row=>{
      var json:JSONObject = null
      try {
        val line = row.getString(0)
        json = JSON.parseObject(line)
      } catch {
        case e:Exception =>logger.error(">>>日志转json失败："+e)
      }
      json
    }).filter(_!=null).persist()
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }


  /**
    * 过滤有效日志
    * @param spark
    * @param sql
    * @return
    */
  def getValidJson(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(64000).map(row=>{
      val json = new JSONObject()
      for(i<-fields.indices){
        json.put(header(i),row.getString(i))
      }
      json
    }).filter(_!=null).repartition(64000).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }


  /**
    * 过滤有效日志
    * @param spark
    * @param sql
    * @return
    */
  def getValidJson2(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(64000).map(row=>{
      val json = new JSONObject()
      for(i<-fields.indices){
        json.put(header(i),row.getString(i))
      }
      json
    }).filter(_!=null).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }


}
