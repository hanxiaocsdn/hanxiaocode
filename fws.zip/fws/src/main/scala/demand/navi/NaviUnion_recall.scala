package demand.navi

import com.alibaba.fastjson.JSONObject
import demand.utils.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: (20230615 已下线) 262512
 * @description: gis_navi_recall_result
 * @demander:80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/12/27 18:29
 */
object NaviUnion_recall {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 500
  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val compare_track_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }

    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getNaviUnion_recallRdd
    computeRddF = null
    table = "gis_navi_recall_result"
    structs = Array("reqid", "navi_id", "routeid", "request_id", "status", "req_order", "req_count", "dest_province", "dest_region", "dest_citycode", "dest_deptcode", "dest_sitecode", "src_province", "src_region", "src_citycode", "src_deptcode", "src_sitecode", "line_type", "starttime", "start_time", "linecode", "vehicle", "vehicle_type", "passport", "weight", "loadweight", "full_loadweight", "length", "width", "height", "axle_number", "axle_weight", "vehicle_color", "energy", "emit_stand", "distance", "reqtime", "req_time", "x1", "y1", "x2", "y2", "ft_time", "ft_status", "ft_dist", "ft_highway", "ft_tralightcount", "ft_tolls", "ft_tollsdistance", "ft_coords", "ft_url", "ft_flen", "ft_tlen", "endtime", "end_time", "similarity1", "similarity5", "tracks2", "rdynsdlen", "rdynsdcnt", "driver_id", "tl_endtime", "actual_time_diff", "opt", "routeid_input", "routeid_output")
    keys = Array("reqid", "navi_id", "routeid", "request_id", "status", "req_order", "req_count", "dest_province", "dest_region", "dest_citycode", "dest_deptcode", "dest_sitecode", "src_province", "src_region", "src_citycode", "src_deptcode", "src_sitecode", "line_type", "starttime", "start_time", "linecode", "vehicle", "vehicle_type", "passport", "weight", "loadweight", "full_loadweight", "length", "width", "height", "axle_number", "axle_weight", "vehicle_color", "energy", "emit_stand", "distance", "reqtime", "req_time", "x1", "y1", "x2", "y2", "ft_time", "ft_status", "ft_dist", "ft_highway", "ft_tralightcount", "ft_tolls", "ft_tollsdistance", "ft_coords", "ft_url", "ft_flen", "ft_tlen", "endtime", "end_time", "similarity1", "similarity5", "tracks2", "rdynsdlen", "rdynsdcnt", "driver_id", "tl_endtime", "actual_time_diff", "opt", "routeid_input", "routeid_output")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }

  /**
   * 解析日志主流程
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  def getNaviUnion_recallRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    val dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    var runDate = ""
    if ("3".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = DateUtil.getDateStr(date, -1)
      }
      else {
        runDate = date
      }
      dateList += runDate
    }
    val startDate = DateUtil.getDateStr(date, -3)
    val endDate = date

    logger.error(">>>获取" + runDate + "号的Navi关联偏航")
    val sql =
      s"""
         |select a.id,a.reqid,a.navi_id,a.routeid,a.request_id,a.status,a.req_order,a.req_count,a.starttime,a.vehicle,a.vehicle_type,a.passport,a.weight,a.loadweight,a.length,a.width,a.height,a.axle_number,a.axle_weight,a.vehicle_color,a.energy,a.emit_stand,a.distance,a.reqtime,a.x1,a.y1,a.x2,a.y2,a.ft_time,a.ft_status,a.ft_dist,a.ft_highway,a.ft_tralightcount,a.ft_tolls,a.ft_tollsdistance,a.ft_url,a.ft_flen,a.ft_tlen,a.endtime,a.rdynsdlen,a.rdynsdcnt,a.driver_id,a.opt,a.routeid_input,a.routeid_output,a.tl_endtime,b.dest_province,b.dest_citycode,b.dest_deptcode,b.src_province,b.src_citycode,b.src_deptcode,b.ft_coords,b.similarity1,b.similarity5,b.tracks2,c.line_code,a.inc_day,a.inc_day as inc_date from
         |(select id,task_id as reqid,navi_id,routeid,request_id,req_status as status,req_order,req_count,navi_starttime as starttime,vehicle,vehicle_type,passport,weight,mload as loadweight,length,width,height,axle_number,axle_weight,plate_color as vehicle_color,energy,emit_stand,distance,req_time as reqtime,x1,y1,x2,y2,duration as ft_time,pns_status as ft_status,distance as ft_dist,highspeed_distance as ft_highway,trafficlight_count as ft_tralightcount,tolls as ft_tolls,toll_distance as ft_tollsdistance,ft_url,flen as ft_flen,tlen as ft_tlen,navi_endtime as endtime,rdynsdlen,rdynsdcnt,driver_id,opt,routeid_in as routeid_input,routeid_out as routeid_output,tl_times as tl_endtime,inc_day from dm_gis.gis_navi_eta_result1 where inc_day='$date') a
         |left join (select id,dest_province,dest_citycode,dest_deptcode,src_province,src_citycode,src_deptcode,polyline as ft_coords,similarity1,similarity5,tracks2 from dm_gis.gis_navi_eta_result2 where inc_day='$date') b on a.id=b.id
         |left join (select task_id,line_code from dm_grd.grd_new_task_detail where inc_day between '$startDate' and '$endDate') c on a.reqid=c.task_id
       """.stripMargin
    val resultRdd = NaviLogParse.getValidJson(spark, sql).persist()

    val computeRdd = resultRdd.map(json => {
      if (json != null) {
        try {
          val starttime = json.getLong("starttime")
          if (starttime != null) {
            val start_time = longToTime(starttime)
            json.put("start_time", start_time)
          }

          val reqtime = json.getLong("reqtime")
          if (reqtime != null) {
            val req_time = longToTime(reqtime)
            json.put("req_time", req_time)
          }

          val endtime = json.getLong("endtime")
          if (endtime != null) {
            val end_time = longToTime(endtime)
            json.put("end_time", end_time)
          }

          if (endtime != null && starttime != null) {
            val actual_time_diff = endtime - starttime
            json.put("actual_time_diff", actual_time_diff)
          }
        }
        catch {
          case e: Exception => logger.error(">>>日志转json失败：" + e)
        }
      }

      val task_id = json.getString("task_id")
      val navi_id = json.getString("navi_id")
      val routeid = json.getString("routeid")
      val req_order = json.getInteger("req_order")
      ((task_id, navi_id, routeid), (req_order, json))
    })
      .groupByKey()
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()
        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
        if (jsonList.nonEmpty) {
          val firstJson = jsonList.head
          var distance = ""
          if (firstJson != null) distance = firstJson.getString("ft_dist")

          for (i <- jsonList.indices) {
            val json = jsonList(i)
            json.put("distance", distance)
            list += json
          }
        }
        list
      })
      .persist()
    logger.error(">>>日志量：" + computeRdd.count())
    resultRdd.unpersist()
    (computeRdd, dateList)
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

}
