package demand.navi

import com.alibaba.fastjson.JSONObject
import demand.utils._
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.text.DecimalFormat
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 262444
 * @description: 表12 gis_navi_yaw_route Navi关联偏航
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/10/21 19:07
 */
object NaviUnion_yawroute {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 500

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    //传入参数，单天任务
    UnionLog(spark, args(0), "false")
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getUnionYawRouteRdd
    computeRddF = null
    table = "gis_navi_yaw_route"
    structs = Array("task_id", "navi_id", "navi_starttime", "routeid", "hasyaw", "request_id", "req_time", "src_province", "src_citycode", "src_deptcode", "dest_province", "dest_citycode", "dest_deptcode", "x1", "y1", "x2", "y2", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plate_color", "energy", "emit_stand", "passport", "driver_id", "ft_url", "plan_date", "stype", "path_count", "opt", "strategy", "merge", "routeid_in", "fixed_route", "fencedist", "reroute", "swid", "starts", "status", "pns_status", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "highspeed_distance", "flen", "tlen", "routeid_out", "polyline", "linknum", "rc_distance", "links", "rdynsdlen", "rdynsdcnt", "ak", "rect_result", "strategy2", "routetype", "merge_result", "is_econ", "service_id", "line_code", "navi_type", "path_rule", "path_type", "path_pos", "limit_info", "is_lowrisk", "pathrule_num", "point_num", "area_num", "pull_navitype")
    keys = Array("task_id", "navi_id", "navi_starttime", "new_routeid", "hasyaw", "request_id", "req_time", "src_province", "src_citycode", "src_deptcode", "dest_province", "dest_citycode", "dest_deptcode", "x1", "y1", "x2", "y2", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plate_color", "energy", "emit_stand", "passport", "driver_id", "ft_url", "plan_date", "stype", "path_count", "opt", "strategy", "merge", "routeid_in", "fixed_route", "fencedist", "reroute", "swid", "starts", "status", "pns_status", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "highspeed_distance", "flen", "tlen", "routeid_out", "polyline", "linknum", "rc_distance", "links", "rdynsdlen", "rdynsdcnt", "ak", "rect_result", "strategy2", "routetype", "merge_result", "is_econ", "service_id", "line_code", "navi_type", "path_rule", "path_type", "path_pos", "limit_info", "is_lowrisk", "pathrule_num", "point_num", "area_num", "pull_navitype")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }

  /**
   * 解析日志主流程
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  /**
   * 获取Navi关联偏航
   */
  def getUnionYawRouteRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    val dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    var runDate = ""
    if ("3".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = DateUtil.getDateStr(date, -1)
      }
      else {
        runDate = date
      }
      dateList += runDate
    }

    logger.error(">>>获取" + runDate + "号的Navi关联偏航")
    var sql = ""
    val startDate = DateUtil.getDateStr(date, -1)
    val endDate = runDate
    //    sql =
    //      s"""
    //         |select a.task_id,a.navi_id,a.navi_starttime,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.line_code,a.navi_type,b.new_routeid,b.hasyaw,b2.pull_navitype,c.request_id,c.x1,c.y1,c.pns_status,c.distance,c.duration,c.toll_distance,c.tolls,c.src,c.trafficlight_count,c.highspeed_distance,c.flen,c.tlen,c.routeid_out,c.polyline,c.linknum,c.rc_distance,c.links,c.rdynsdlen,c.rdynsdcnt,c.rect_result,c.strategy2,c.routetype,c.merge_result,c.is_econ,c.path_rule,c.path_type,c.path_pos,c.limit_info,c.is_lowrisk,c.pathrule_num,c.point_num,c.area_num,d.req_time,d.x2,d.y2,d.ft_url,d.plan_date,d.stype,d.path_count,d.opt,d.strategy,d.merge,d.routeid_in,d.fixed_route,d.fencedist,d.reroute,d.swid,d.starts,d.status,d.ak,d.service_id,a.inc_day,a.inc_day as inc_date from
    //         |(select task_id,navi_id,navi_starttime,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,line_code,navi_type,inc_day from dm_gis.gis_navi_top3_click_route where inc_day='$date' and navi_starttime is not null and navi_starttime<>'') a
    //         |left join (select navi_id,get_json_object(content, '$$.yawRouteId') as new_routeid,max(hasyaw) as hasyaw from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type in ('2','22') group by navi_id,get_json_object(content, '$$.yawRouteId')) b on a.navi_id=b.navi_id
    //         |left join (select navi_id,max(pull_navitype) as pull_navitype from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type='6' group by navi_id) b2 on a.navi_id=b2.navi_id
    //         |left join (select request_id,routeid,x1,y1,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate') c on b.new_routeid=c.routeid
    //         |left join (select navi_id,request_id,req_time,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,'' as driver_id,ft_url,plan_date,stype,'1' as path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swids as swid,starts,status,ak,service_id from dm_gis.gis_navi_yaw_parse where inc_day between '$startDate' and '$endDate') d on c.request_id=d.request_id
    //         """.stripMargin
    sql =
      s"""|select
          |  a.task_id,a.navi_id,if(navi_starttime is null or trim(navi_starttime) = '',req_time_flag,navi_starttime) navi_starttime,
          |  a.src_deptcode,a.dest_deptcode,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.line_code,b0.navi_type,b1.new_routeid,b1.hasyaw,b2.pull_navitype,c.request_id,c.x1,c.y1,c.pns_status,c.distance,c.duration,c.toll_distance,c.tolls,c.src,c.trafficlight_count,c.highspeed_distance,c.flen,c.tlen,c.routeid_out,c.polyline,c.linknum,c.rc_distance,c.links,c.rdynsdlen,c.rdynsdcnt,c.rect_result,c.strategy2,c.routetype,c.merge_result,c.is_econ,c.path_rule,c.path_type,c.path_pos,c.limit_info,c.is_lowrisk,c.pathrule_num,c.point_num,c.area_num,d.req_time,d.x2,d.y2,d.ft_url,d.plan_date,d.stype,d.path_count,d.opt,d.strategy,d.merge,d.routeid_in,d.fixed_route,d.fencedist,d.reroute,d.swid,d.starts,d.status,d.ak,d.service_id,e.src_province,e.src_citycode,f.dest_province,f.dest_citycode,if(inc_day1 is null or trim(inc_day1) ='',inc_day9,inc_day1) as inc_date
          |from(
          |select task_id,navi_id,if(req_time is null or trim(req_time) = ''or trim(req_time) = '0','-1',req_time) req_time_flag,src_deptcode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,line_code,inc_day from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate' group by task_id,navi_id,req_time,src_deptcode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,line_code,inc_day
          |  ) a
          |left join (select navi_id,max(report_time) as navi_starttime,max(navi_type) as navi_type,max(inc_day) as inc_day1 from dm_gis.gis_navi_sdk_navi_parse where inc_day = '$endDate' and type = '1' and navi_id is not null and trim(navi_id) != '' group by navi_id) b0 on a.navi_id = b0.navi_id
          |left join (select navi_id,max(inc_day) as inc_day9 from dm_gis.gis_navi_sdk_navi_parse where inc_day = '$endDate' and type = '9' and navi_id is not null and trim(navi_id) != '' group by navi_id ) b00 on a.navi_id = b00.navi_id
          |left join (select navi_id,get_json_object(content, '$$.yawRouteId') as new_routeid,max(hasyaw) as hasyaw from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type in ('2', '22')group by navi_id,get_json_object(content, '$$.yawRouteId')) b1 on a.navi_id = b1.navi_id
          |left join (select navi_id,max(pull_navitype) as pull_navitype from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type = '6' group by navi_id ) b2 on a.navi_id = b2.navi_id
          |left join (select request_id,routeid,x1,y1,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate' group by request_id,routeid,x1,y1,top3_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy,routetype,merge_result,is_econ,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num) c on b1.new_routeid = c.routeid
          |left join (select navi_id,request_id,req_time,endx as x2,endy as y2,ft_url,plan_date,stype,'1' as path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swids as swid,starts,status,ak,service_id from dm_gis.gis_navi_yaw_parse where inc_day between '$startDate' and '$endDate' group by navi_id,request_id,req_time,endx,endy,ft_url,plan_date,stype,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swids,starts,status,ak,service_id) d on c.request_id = d.request_id
          |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day = '20200909') e on a.src_deptcode = e.zone_code
          |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day = '20200909') f on a.dest_deptcode = f.zone_code
          |""".stripMargin

    val resultRdd = NaviLogParse.getValidJson(spark, sql).coalesce(40).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>日志量：" + resultRdd.count())
    (resultRdd, dateList)
  }
}
