package demand.navi

import java.net.URLEncoder
import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date

import com.alibaba.fastjson.{JSONArray, JSONObject}
import demand.navi.NaviParse_sdkNaviLog.{logger, longToTime, repartition}
import demand.utils._
import demand.navi.NaviUtils._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer





object NaviParse_sdkNaviLog {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
@an(1,8,9)
  class NaviParse_sdkNaviLog extends type1{
    override
    val logType = "sdkNaviLog"
    override
    def grf(validRdd:RDD[JSONObject]): RDD[JSONObject] ={
      val computeRdd = validRdd
        .map(json=>{
          var navi_id = ""
          var _type = ""
          var navi_type = ""
          var start_type = ""
          var report_time:java.lang.Long = null
          var routeid = ""

          if(json!=null){
            val data = json.getJSONObject("data")
            if(data!=null){
              navi_id = data.getString("naviId")
              _type = data.getString("type")
              navi_type = data.getString("naviType")
              start_type = data.getString("startType")
              report_time = data.getLong("reportTime")
              if(report_time!=null){
                val inc_date = longToTime(report_time).split(" ")(0).replaceAll("-","")
                json.put("inc_date",inc_date)
              }

              val routeInfo = data.getJSONObject("routeInfo")
              if(routeInfo!=null){
                routeid = routeInfo.getString("routeId")
              }

              var content = ""
              val operateInfo = data.getJSONObject("operateInfo")
              if(operateInfo!=null){
                content = operateInfo.getString("content")
                if(!StringUtils.isEmpty(content)){
                  json.put("content",content)
                }
              }
              if(StringUtils.isEmpty(json.getString("content"))){
                val gdSdkOperateInfo = data.getJSONObject("gdSdkOperateInfo")
                if(gdSdkOperateInfo!=null){
                  content = gdSdkOperateInfo.getString("content")
                  if(!StringUtils.isEmpty(content)){
                    json.put("content",content)
                  }
                }
              }
              val yawInfo = data.getJSONObject("yawInfo")
              if(yawInfo!=null){
                val routeId = yawInfo.getString("routeId")
                if(!StringUtils.isEmpty(routeId)) json.put("new_routeid",routeId)
              }
            }
          }

          if(StringUtils.isEmpty(navi_id)) navi_id = "-"
          if(StringUtils.isEmpty(_type)) _type = "-"
          if(StringUtils.isEmpty(navi_type)) navi_type = "-"
          if(StringUtils.isEmpty(start_type)) start_type = "-"
          if(report_time==null) report_time = Long.MaxValue
          if(StringUtils.isEmpty(routeid)) routeid = "-"
          json.put("navi_id",navi_id)
          json.put("type",_type)
          json.put("navi_type",navi_type)
          json.put("start_type",start_type)
          json.put("report_time",report_time)
          json.put("routeid",routeid)

          json
        })
        .filter(json => !StringUtils.isEmpty(json.getString("inc_date")))
        .map(json=>{
          var navi_id = ""
          var routeid = ""
          navi_id = json.getString("navi_id")
          routeid = json.getString("routeid")

          ((navi_id,routeid),json)
        })
        .groupByKey()
        .flatMap(obj=>{
          var list = new ArrayBuffer[JSONObject]()

          val list2  = obj._2.toList.filter(j=> "9".equalsIgnoreCase(j.getString("type")) || !"10".equalsIgnoreCase(j.getString("type")))
          if(list2.nonEmpty){
            list2.map(json=>{
              list += json
            })
          }

          var json:JSONObject = null

          val list9 = obj._2.toList.filter(j=> "9".equalsIgnoreCase(j.getString("type")))
          if(list9.nonEmpty) {
            if(list9.size == 1) json = list9.head
            else {
              json = list9.minBy(j => j.getLong("report_time"))
            }

            if(json!=null) list += json
          }

          json = null

          val list10 = obj._2.toList.filter(j=> "10".equalsIgnoreCase(j.getString("type")))
          if(list10.nonEmpty) {
            if(list10.size == 1) json = list10.head
            else {
              json = list10.maxBy(j => j.getLong("report_time"))
            }

            if(json!=null) list += json
          }

          list
        })

        .map(json=>{
          if(json!=null){
            if("8".equalsIgnoreCase(json.getString("type"))){
              val data = json.getJSONObject("data")
              if(data!=null){
                val gdSdkOperateInfo = data.getJSONObject("gdSdkOperateInfo")
                if(gdSdkOperateInfo!=null){
                  val content = gdSdkOperateInfo.getString("content")
                  if(!StringUtils.isEmpty(content)) json.put("gd_content", Base64Util.get(content))
                }
              }
            }
          }

          json
        })
        .repartition(repartition).persist()
      validRdd.unpersist()

      computeRdd
    }

  }




  def main(args: Array[String]): Unit = {
    new Navi().start(new NaviParse_sdkNaviLog())(args(0))
  }





  /**
    * 获取naviTop3Log日志
    * @param spark
    * @param getHiveRdd
    * @param dateList
    * @return
    */
  def getTop3Rdd(spark:SparkSession, getHiveRdd:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], dateList:ArrayBuffer[String]):RDD[JSONObject] ={
    val logType = "naviTop3V2Log"//naviTop3Log
    logger.error(">>>获取"+dateList.mkString(",")+"号的" + logType + "日志")
    val validRdd = getHiveRdd(spark,dateList,logType)
    val computeRdd = validRdd.map(json=>{
      var navi_id = ""
      var req_time:java.lang.Long = null
      if(json!=null){
        val data = json.getJSONObject("data")
        if(data!=null){
          val naviTop3Args = data.getJSONObject("naviTop3Args")
          if(naviTop3Args!=null){
            navi_id = naviTop3Args.getString("naviId")
            req_time = naviTop3Args.getLong("reqTime")
            if(req_time!=null){
              val inc_date = longToTime(req_time).split(" ")(0).replaceAll("-","")
              json.put("inc_date",inc_date)
            }
          }
        }
      }
      if(req_time==null) req_time = Long.MaxValue
      (navi_id,(req_time,json))
    })
      .groupByKey().map(obj=>{
      val json = obj._2.toList.sortBy(_._1).map(_._2).reverse.head
      json
    }).map(json=>{
      if(json!=null){
        val data = json.getJSONObject("data")
        if(data!=null){
          val pnsTop3Args = data.getJSONObject("pnsTop3Args")
          if(pnsTop3Args!=null){
            val origin = pnsTop3Args.getString("origin")
            val destination = pnsTop3Args.getString("destination")
            if(origin!=null){
              val coords = origin.split(",")
              if(coords!=null && coords.nonEmpty){
                val x = coords(0)
                json.put("startx",x)
                if(coords.length>1){
                  val y = coords(1)
                  json.put("starty",y)
                }
              }
            }
            if(destination!=null){
              val coords = destination.split(",")
              if(coords!=null && coords.nonEmpty){
                val x = coords(0)
                json.put("endx",x)
                if(coords.length>1){
                  val y = coords(1)
                  json.put("endy",y)
                }
              }
            }

            val ft_url = getUrl(pnsTop3Args, "http://10.206.169.158:8080/rp/navi/v2/top3?")//http://gis-int.int.sfdc.com.cn:1080/rp/navi/top3?
            json.put("ft_url", ft_url)

            val econTrackIds = pnsTop3Args.getString("econTrackIds")
            if(!StringUtils.isEmpty(econTrackIds)){
              json.put("econ_id", econTrackIds)
            }
            else{
              val econ2TrackIds = pnsTop3Args.getString("econ2TrackIds")
              if(!StringUtils.isEmpty(econ2TrackIds)){
                json.put("econ_id", econ2TrackIds)
              }
            }
          }
        }
      }

      json
    })
      .repartition(repartition).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()

    computeRdd
  }


  /**
    * 获取naviTop3LogResult|yawLogResult日志
    * @param spark
    * @param getHiveRdd
    * @param dateList
    * @return
    */
  def getTop3YawResultRdd(spark:SparkSession, getHiveRdd:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], dateList:ArrayBuffer[String]):RDD[JSONObject] ={
    val logType = "naviTop3V2LogResult,yawV2LogResult"//naviTop3LogResult,yawLogResult
    logger.error(">>>获取"+dateList.mkString(",")+"号的" + logType + "日志")
    val validRdd = getHiveRdd(spark,dateList,logType)
    val computeRdd = validRdd
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()
        if(json!=null){
          var request_id = ""
          var req_time:java.lang.Long = null
          var inc_date = ""
          var top3_status = ""
          var top3_info = ""
          var err_status = ""
          var err_info = ""
          var subtype = ""

//          val requestString = json.getString("requestId")
//          if(!StringUtils.isEmpty(requestString)){
//            val requests = requestString.split("_")
//            if(requests!=null && requests.nonEmpty){
//              request_id = requests(0)
//              if(requests.length>1){
//                val time = requests(1)
//                if(!StringUtils.isEmpty(time)){
//                  try{
//                    val _time:java.lang.Long = time.toLong
//                    if(_time!=null){
//                      inc_date = longToTime(_time).split(" ")(0).replaceAll("-","")
//                    }
//                  }
//                  catch {
//                    case e:Exception =>logger.error(">>>日志转json失败："+e)
//                  }
//                }
//              }
//            }
//          }

          request_id = json.getString("requestId")
          if(request_id.contains("_")){
            val requests = request_id.split("_")
            if(requests!=null && requests.nonEmpty){
              request_id = requests(0)
            }
          }

          req_time = json.getLong("reqTime")
          if(req_time!=null){
            inc_date = longToTime(req_time).split(" ")(0).replaceAll("-","")
          }
          subtype = json.getString("subType")

          top3_status = json.getString("status")
          top3_info = json.getString("info")
          val result = json.getJSONObject("result")
          if(result!=null){
            err_status = result.getString("err")
            err_info = result.getString("msg")
          }

          val paths = json.getJSONArray("paths")

          val basePath = json.getJSONObject("basePath")
          if(basePath!=null){
            val linkAttributes = basePath.getJSONArray("linkAttributes")
            val rectResult = basePath.getString("rectResult")
            //            top3_info = routes.getString("info")
            val pathes = basePath.getJSONArray("pathes")
            if(pathes!=null && pathes.size() > 0){
              val route_count = pathes.size()
              if(pathes.size()>0){
                var j = 0
                val path0 = pathes.getJSONObject(0)
                var mergeResult = ""
                if(path0!=null) mergeResult = path0.getString("mergeResult")
                for(i<- 0.until(pathes.size())){
                  val path = pathes.getJSONObject(i)
                  path.put("request_id", request_id)
                  if(req_time!=null) path.put("req_time", req_time)
                  path.put("inc_date", inc_date)
                  path.put("top3_status", top3_status)
                  path.put("top3_info", top3_info)
                  path.put("err_status", err_status)
                  path.put("err_info", err_info)
                  path.put("subtype", subtype)
                  path.put("route_count", route_count)
                  path.put("route_index", i)
                  if(linkAttributes!=null) path.put("linkAttributes", linkAttributes)
                  if(rectResult!=null) path.put("rect_result", rectResult)
                  if(mergeResult!=null) path.put("merge_result", mergeResult)

                  val src = path.getString("src")
                  if("jy".equalsIgnoreCase(src)) {
                    if(paths!=null && paths.size() > j && paths.getJSONObject(j) != null){
                      val _path = paths.getJSONObject(j)
                      if(_path!=null){
                        val routeId = _path.getString("routeId")
                        val isSame = _path.getString("isSame")
                        val isMatch = _path.getString("isMatch")
                        val routetype = _path.getString("routetype")
                        val is_econ = _path.getString("isEcon")
                        if(!StringUtils.isEmpty(routeId)) path.put("routeId",routeId)
                        if(!StringUtils.isEmpty(isSame)) path.put("isSame",isSame)
                        if(!StringUtils.isEmpty(isMatch)) path.put("isMatch",isMatch)
                        if(!StringUtils.isEmpty(routetype)) path.put("routetype",routetype)
                        if(!StringUtils.isEmpty(is_econ)) path.put("is_econ",is_econ)
                      }
                    }
                    else{
                      path.put("routeId","")
                      path.put("isSame","")
                      path.put("isMatch","")
                      path.put("routetype","")
                      path.put("is_econ","")
                    }
                    j = j + 1
                  }
                  else{
                    path.put("routeId","")
                    path.put("isSame","")
                    path.put("isMatch","")
                    path.put("routetype","")
                    path.put("is_econ","")
                  }

                  list += path
                }
              }
            }
          }
        }

        list
      })
      .map(json=>{
        var request_id = ""
        var routeid_out = ""
        if(json!=null){
          request_id = json.getString("request_id")
          routeid_out = json.getString("id")
        }
        ((request_id,routeid_out),json)
      })
      .groupByKey()
      .map(obj=>{
        val json = obj._2.toList.head
        json
      })
      .map(json=>{
        if(json!=null){
          val origin = json.getString("origin")
          val destination = json.getString("destination")
          if(origin!=null){
            val coords = origin.split(",")
            if(coords!=null && coords.nonEmpty){
              val x = coords(0)
              json.put("x1",x)
              if(coords.length>1){
                val y = coords(1)
                json.put("y1",y)
              }
            }
          }
          if(destination!=null){
            val coords = destination.split(",")
            if(coords!=null && coords.nonEmpty){
              val x = coords(0)
              json.put("x2",x)
              if(coords.length>1){
                val y = coords(1)
                json.put("y2",y)
              }
            }
          }

          val polylineX = json.getJSONArray("polylineX")
          val polylineY = json.getJSONArray("polylineY")
          handlePolyline(json, polylineX,polylineY)

          val segments = json.getJSONArray("segments")
          val linkAttributes = json.getJSONArray("linkAttributes")
          handleLinks(json,segments,linkAttributes)
        }

        json
      })
      .repartition(500).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()

    computeRdd
  }



  /**
    * 获取noYawLogResult日志
    * @param spark
    * @param getHiveRdd
    * @param dateList
    * @return
    */
  def getNoYawResultRdd(spark:SparkSession, getHiveRdd:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject], dateList:ArrayBuffer[String]):RDD[JSONObject] ={
    val logType = "pathTimeLogResult"
    logger.error(">>>获取"+dateList.mkString(",")+"号的" + logType + "日志")
    val validRdd = getHiveRdd(spark,dateList,logType)
    val computeRdd = validRdd
      .map(json=>{
        var request_id = ""
        var req_time:java.lang.Long = null
        var inc_date = ""
        if(json!=null){
          //request_id = json.getString("requestId")

//          val requestString = json.getString("requestId")
//          if(!StringUtils.isEmpty(requestString)){
//            val requests = requestString.split("_")
//            if(requests!=null && requests.nonEmpty){
//              request_id = requests(0)
//              if(requests.length>1){
//                val time = requests(1)
//                if(!StringUtils.isEmpty(time)){
//                  try{
//                    val _time:java.lang.Long = time.toLong
//                    if(_time!=null){
//                      inc_date = longToTime(_time).split(" ")(0).replaceAll("-","")
//                    }
//                  }
//                  catch {
//                    case e:Exception =>logger.error(">>>日志转json失败："+e)
//                  }
//                }
//              }
//            }
//          }

          request_id = json.getString("requestId")
          if(request_id.contains("_")){
            val requests = request_id.split("_")
            if(requests!=null && requests.nonEmpty){
              request_id = requests(0)
            }
          }

          req_time = json.getLong("reqTime")
          if(req_time!=null){
            inc_date = longToTime(req_time).split(" ")(0).replaceAll("-","")
          }
        }
        json.put("request_id",request_id)
        if(req_time!=null) json.put("req_time",req_time)
        json.put("inc_date",inc_date)
        (request_id,json)
      })
      .groupByKey()
      .map(obj=>{
        val json = obj._2.toList.head
        json
      })
      .map(json=>{
        if(json!=null){
          handleLinksNoYaw(json)
        }

        json
      })
      .repartition(repartition).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()

    computeRdd
  }


//  /**
//    * 获取yawLog日志
//    * @param spark
//    * @param getHiveRdd
//    * @param dateList
//    * @return
//    */
//  def getYawLogRdd(spark:SparkSession, getHiveRdd:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject],dateList:ArrayBuffer[String]):RDD[JSONObject] ={
//    val logType = "yawV2Log"//yawLog
//    logger.error(">>>获取"+dateList.mkString(",")+"号的" + logType + "日志")
//    val validRdd = getHiveRdd(spark,dateList,logType)
//    val computeRdd = validRdd
//      .map(json=>{
//        var routeid = ""
//        var req_time:java.lang.Long = null
//        if(json!=null){
//          val data = json.getJSONObject("data")
//          if(data!=null){
//            val yawArgs = data.getJSONObject("yawArgs")
//            if(yawArgs!=null){
//              routeid = yawArgs.getString("routeId")
//              req_time = yawArgs.getLong("reqTime")
//              if(req_time!=null){
//                val inc_date = longToTime(req_time).split(" ")(0).replaceAll("-","")
//                json.put("inc_date",inc_date)
//              }
//            }
//          }
//        }
//        if(req_time==null) req_time = Long.MaxValue
//        ((routeid,req_time),json)
//      })
//      .groupByKey()
//      .map(obj=>{
//        val json = obj._2.toList.head
//        json
//      })
//      .map(json=>{
//        if(json!=null){
//          val data = json.getJSONObject("data")
//          if(data!=null){
//            //          val pnsTop3Args = data.getJSONObject("pnsTop3Args")
//            //          if(pnsTop3Args!=null){
//            //            val ft_url = getUrl(pnsTop3Args, "http://gis-int.int.sfdc.com.cn:1080/rp/navi/top3?ak={1}&")
//            //            json.put("ft_url", ft_url)
//            //          }
//
//            var targetObject:JSONObject = null
//            val sfPnsTop3Args = data.getJSONObject("sfPnsTop3Args")
//            if(sfPnsTop3Args!=null) targetObject = sfPnsTop3Args
//            else targetObject = data.getJSONObject("jyPnsTop3Args")
//            if(targetObject!=null){
//              val ft_url = getUrlPost(targetObject, "http://10.206.169.158:8080/rp/navi/v2/top3?")//http://gis-int.int.sfdc.com.cn:1080/rp/navi/top3
//              json.put("ft_url", ft_url)
//
//              val origin = targetObject.getString("origin")
//              val destination = targetObject.getString("destination")
//              if(origin!=null){
//                val coords = origin.split(",")
//                if(coords!=null && coords.nonEmpty){
//                  val x = coords(0)
//                  json.put("startx",x)
//                  if(coords.length>1){
//                    val y = coords(1)
//                    json.put("starty",y)
//                  }
//                }
//              }
//              if(destination!=null){
//                val coords = destination.split(",")
//                if(coords!=null && coords.nonEmpty){
//                  val x = coords(0)
//                  json.put("endx",x)
//                  if(coords.length>1){
//                    val y = coords(1)
//                    json.put("endy",y)
//                  }
//                }
//              }
//
//              val vehicle = targetObject.getString("plate")
//              val vehicle_type = targetObject.getString("vehicle")
//              val weight = targetObject.getString("weight")
//              val mload = targetObject.getString("mload")
//              val length = targetObject.getString("size")
//              val width = targetObject.getString("width")
//              val height = targetObject.getString("height")
//              val axle_weight = targetObject.getString("axleWeight")
//              val axle_number = targetObject.getString("axleNumber")
//              val plan_date = targetObject.getString("planDate")
//              val plate_color = targetObject.getString("plateColor")
//              val energy = targetObject.getString("energy")
//              val emit_stand = targetObject.getString("emitStand")
//              val passport = targetObject.getString("passport")
//              val stype = targetObject.getString("stype")
//              val path_count = targetObject.getString("pathCount")
//              val opt = targetObject.getString("opt")
//              val strategy = targetObject.getString("strategy")
//              val starts = targetObject.getString("starts")
//              val swids = targetObject.getString("swids")
//              val request_id = targetObject.getString("requestId")
//
//              json.put("vehicle",vehicle)
//              json.put("vehicle_type",vehicle_type)
//              json.put("weight",weight)
//              json.put("mload",mload)
//              json.put("length",length)
//              json.put("width",width)
//              json.put("height",height)
//              json.put("axle_weight",axle_weight)
//              json.put("axle_number",axle_number)
//              json.put("plan_date",plan_date)
//              json.put("plate_color",plate_color)
//              json.put("energy",energy)
//              json.put("emit_stand",emit_stand)
//              json.put("passport",passport)
//              json.put("stype",stype)
//              json.put("path_count",path_count)
//              json.put("opt",opt)
//              json.put("strategy",strategy)
//              json.put("starts",starts)
//              json.put("swids",swids)
//              json.put("request_id",request_id)
//            }
//
//            //          targetObject = null
//            //          val sfnaviTop3Result = data.getJSONObject("sfnaviTop3Result")
//            //          if(sfnaviTop3Result!=null) targetObject = sfnaviTop3Result
//            //          else targetObject = data.getJSONObject("jynaviTop3Result")
//            //          if(targetObject!=null){
//            //            val top3_status = targetObject.getString("status")
//            //            json.put("top3_status",top3_status)
//            //
//            //            val result = targetObject.getJSONObject("result")
//            //            if(result!=null){
//            //              val list = result.getJSONArray("list")
//            //              if(list!=null && list.size()>0){
//            //                val e0 = list.getJSONObject(0)
//            //                if(e0!=null){
//            //                  val origin = targetObject.getString("origin")
//            //                  val destination = targetObject.getString("destination")
//            //                  if(origin!=null){
//            //                    val coords = origin.split(",")
//            //                    if(coords!=null && coords.nonEmpty){
//            //                      val x = coords(0)
//            //                      json.put("x1",x)
//            //                      if(coords.length>1){
//            //                        val y = coords(1)
//            //                        json.put("y1",y)
//            //                      }
//            //                    }
//            //                  }
//            //                  if(destination!=null){
//            //                    val coords = destination.split(",")
//            //                    if(coords!=null && coords.nonEmpty){
//            //                      val x = coords(0)
//            //                      json.put("x2",x)
//            //                      if(coords.length>1){
//            //                        val y = coords(1)
//            //                        json.put("y2",y)
//            //                      }
//            //                    }
//            //                  }
//            //
//            //                  val new_routeid = e0.getString("id")
//            //                  val distance = e0.getString("distance")
//            //                  val duration = e0.getString("duration")
//            //                  val toll_distance = e0.getString("tollDistance")
//            //                  val tolls = e0.getString("tolls")
//            //                  val src = e0.getString("src")
//            //                  val trafficlight_count = e0.getString("trafficLightCount")
//            //                  val routeid_out = e0.getString("routeId")
//            //                  val is_same = e0.getString("isSame")
//            //                  val is_match = e0.getString("isMatch")
//            //                  val flen = e0.getString("flen")
//            //                  val tlen = e0.getString("tlen")
//            //                  val highspeed_distance = e0.getString("highspeedDistance")
//            //                  val polyline = e0.getString("polyline")
//            //                  val linknum = e0.getString("linknum")
//            //                  val rc_distance = e0.getString("rcDistance")
//            //
//            //                  json.put("new_routeid",new_routeid)
//            //                  json.put("distance",distance)
//            //                  json.put("duration",duration)
//            //                  json.put("toll_distance",toll_distance)
//            //                  json.put("tolls",tolls)
//            //                  json.put("src",src)
//            //                  json.put("trafficlight_count",trafficlight_count)
//            //                  json.put("routeid_out",routeid_out)
//            //                  json.put("is_same",is_same)
//            //                  json.put("is_match",is_match)
//            //                  json.put("flen",flen)
//            //                  json.put("tlen",tlen)
//            //                  json.put("highspeed_distance",highspeed_distance)
//            //                  json.put("polyline",polyline)
//            //                  json.put("linknum",linknum)
//            //                  json.put("rc_distance",rc_distance)
//            //
//            //                  val segments = e0.getJSONArray("segments")
//            //                  handleLinks(json,segments)
//            //                }
//            //              }
//            //            }
//            //          }
//
//          }
//        }
//
//        json
//      })
//      .repartition(repartition).persist()
//    logger.error(">>>日志量：" + computeRdd.count())
//    validRdd.unpersist()
//
//    computeRdd
//  }


  /**
    * 获取yawLog日志
    * @param spark
    * @param getHiveRdd
    * @param dateList
    * @return
    */
  def getYawLogRdd(spark:SparkSession, getHiveRdd:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject],dateList:ArrayBuffer[String]):RDD[JSONObject] ={
    val logType = "yawV2Log"//yawLog
    logger.error(">>>获取"+dateList.mkString(",")+"号的" + logType + "日志")
    val validRdd = getHiveRdd(spark,dateList,logType)
    val computeRdd = validRdd
      .map(json=>{
        var routeid = ""
        var req_time:java.lang.Long = null
        if(json!=null){
          val data = json.getJSONObject("data")
          if(data!=null){
            val yawArgs = data.getJSONObject("yawArgs")
            if(yawArgs!=null){
              routeid = yawArgs.getString("routeId")
              req_time = yawArgs.getLong("reqTime")
              if(req_time!=null){
                val inc_date = longToTime(req_time).split(" ")(0).replaceAll("-","")
                json.put("inc_date",inc_date)
              }
            }
          }
        }
        if(req_time==null) req_time = Long.MaxValue
        ((routeid,req_time),json)
      })
      .groupByKey()
      .map(obj=>{
        val json = obj._2.toList.head
        json
      })
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        if(json!=null){
          val inc_date = json.getString("inc_date")
          val data = json.getJSONObject("data")
          if(data!=null){
            val baseObject = new JSONObject()
            if(true){
              var task_id = ""
              var navi_id = ""
              var routeid = ""
              var app_ver = ""
              var vehicle_dir = ""
              var req_time = ""
              var status = ""
              var req_start_time = ""
              var req_endtime = ""
              var req_costtime = ""
              var sfpnstop3_starttime = ""
              var sfpnstop3_endtime = ""
              var sfpnstop3_costtime = ""
              var jypnstop3_starttime = ""
              var jypnstop3_endtime = ""
              var jypnstop3_costtime = ""
              var service_id = ""

              status = data.getString("status")
              req_start_time = data.getString("reqStartTime")
              req_endtime = data.getString("reqEndTime")
              req_costtime = data.getString("reqCostTime")
              sfpnstop3_starttime = data.getString("sfPnsTop3StartTime")
              sfpnstop3_endtime = data.getString("sfPnsTop3EndTime")
              sfpnstop3_costtime = data.getString("sfPnsTop3CostTime")
              jypnstop3_starttime = data.getString("jyPnsTop3StartTime")
              jypnstop3_endtime = data.getString("jyPnsTop3EndTime")
              jypnstop3_costtime = data.getString("jyPnsTop3CostTime")

              val yawArgs = data.getJSONObject("yawArgs")
              if(yawArgs!=null){
                task_id = yawArgs.getString("taskId")
                navi_id = yawArgs.getString("naviId")
                routeid = yawArgs.getString("routeId")
                app_ver = yawArgs.getString("appVer")
                vehicle_dir = yawArgs.getString("vehicleDir")
                req_time = yawArgs.getString("reqTime")
                service_id = yawArgs.getString("serviceId")
              }
              if(StringUtils.isEmpty(task_id)) task_id = ""
              if(StringUtils.isEmpty(navi_id)) navi_id = ""
              if(StringUtils.isEmpty(routeid)) routeid = ""
              if(StringUtils.isEmpty(app_ver)) app_ver = ""
              if(StringUtils.isEmpty(vehicle_dir)) vehicle_dir = ""
              if(StringUtils.isEmpty(req_time)) req_time = ""
              if(StringUtils.isEmpty(status)) status = ""
              if(StringUtils.isEmpty(req_start_time)) req_start_time = ""
              if(StringUtils.isEmpty(req_endtime)) req_endtime = ""
              if(StringUtils.isEmpty(req_costtime)) req_costtime = ""
              if(StringUtils.isEmpty(sfpnstop3_starttime)) sfpnstop3_starttime = ""
              if(StringUtils.isEmpty(sfpnstop3_endtime)) sfpnstop3_endtime = ""
              if(StringUtils.isEmpty(sfpnstop3_costtime)) sfpnstop3_costtime = ""
              if(StringUtils.isEmpty(jypnstop3_starttime)) jypnstop3_starttime = ""
              if(StringUtils.isEmpty(jypnstop3_endtime)) jypnstop3_endtime = ""
              if(StringUtils.isEmpty(jypnstop3_costtime)) jypnstop3_costtime = ""
              if(StringUtils.isEmpty(service_id)) service_id = ""

              baseObject.put("task_id", task_id)
              baseObject.put("navi_id", navi_id)
              baseObject.put("routeid", routeid)
              baseObject.put("app_ver", app_ver)
              baseObject.put("vehicle_dir", vehicle_dir)
              baseObject.put("req_time", req_time)
              baseObject.put("status", status)
              baseObject.put("req_start_time", req_start_time)
              baseObject.put("req_endtime", req_endtime)
              baseObject.put("req_costtime", req_costtime)
              baseObject.put("sfpnstop3_starttime", sfpnstop3_starttime)
              baseObject.put("sfpnstop3_endtime", sfpnstop3_endtime)
              baseObject.put("sfpnstop3_costtime", sfpnstop3_costtime)
              baseObject.put("jypnstop3_starttime", jypnstop3_starttime)
              baseObject.put("jypnstop3_endtime", jypnstop3_endtime)
              baseObject.put("jypnstop3_costtime", jypnstop3_costtime)
              baseObject.put("service_id", service_id)
              baseObject.put("inc_date", inc_date)
            }

            val sfPnsTop3Args = data.getJSONObject("sfPnsTop3Args")
            val jyPnsTop3Args = data.getJSONObject("jyPnsTop3Args")
            val gdPnsTop3Args = data.getJSONObject("gdPnsTop3Args")

            if(sfPnsTop3Args!=null) {
              val target1 = sfPnsTop3Args
              val target2 = jyPnsTop3Args
              val target3 = gdPnsTop3Args

              val resultJson = putValuesByOrder(target1, target2, target3, baseObject)
              if(resultJson!=null) list += resultJson
            }

            if(jyPnsTop3Args!=null) {
              val target1 = jyPnsTop3Args
              val target2 = gdPnsTop3Args
              val target3 = sfPnsTop3Args

              val resultJson = putValuesByOrder(target1, target2, target3, baseObject)
              if(resultJson!=null) list += resultJson
            }

            if(gdPnsTop3Args!=null) {
              val target1 = gdPnsTop3Args
              val target2 = jyPnsTop3Args
              val target3 = sfPnsTop3Args

              val resultJson = putValuesByOrder(target1, target2, target3, baseObject)
              if(resultJson!=null) list += resultJson
            }

          }
        }

        list
      })
      .repartition(repartition).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()

    computeRdd
  }


  /**
    * 1
    * @param target1
    * @param target2
    * @param target3
    * @param baseObject
    * @return
    */
  def putValuesByOrder(target1:JSONObject, target2:JSONObject, target3:JSONObject, baseObject:JSONObject):JSONObject = {
    var resultJson:JSONObject = null
    if(target1!=null){
      val request_id = target1.getString("requestId")
      if(!StringUtils.isEmpty(request_id)){
        resultJson = new JSONObject()
        resultJson.fluentPutAll(baseObject)
        resultJson.put("request_id", request_id)

        val ft_url = getUrlPost(target1, "http://10.206.169.158:8080/rp/navi/v2/top3?")//http://gis-int.int.sfdc.com.cn:1080/rp/navi/top3
        resultJson.put("ft_url", ft_url)

        val origin = getValueByOrder(target1, target2, target3, "origin")
        if(origin!=null){
          val coords = origin.split(",")
          if(coords!=null && coords.nonEmpty){
            val x = coords(0)
            resultJson.put("startx",x)
            if(coords.length>1){
              val y = coords(1)
              resultJson.put("starty",y)
            }
          }
        }

        val destination = getValueByOrder(target1, target2, target3, "destination")
        if(destination!=null){
          val coords = destination.split(",")
          if(coords!=null && coords.nonEmpty){
            val x = coords(0)
            resultJson.put("endx",x)
            if(coords.length>1){
              val y = coords(1)
              resultJson.put("endy",y)
            }
          }
        }

        putValueByOrder(target1, target2, target3, "plate", resultJson, "vehicle")
        putValueByOrder(target1, target2, target3, "vehicle", resultJson, "vehicle_type")
        putValueByOrder(target1, target2, target3, "weight", resultJson, "weight")
        putValueByOrder(target1, target2, target3, "mload", resultJson, "mload")
        putValueByOrder(target1, target2, target3, "size", resultJson, "length")
        putValueByOrder(target1, target2, target3, "width", resultJson, "width")
        putValueByOrder(target1, target2, target3, "height", resultJson, "height")
        putValueByOrder(target1, target2, target3, "axleWeight", resultJson, "axle_weight")
        putValueByOrder(target1, target2, target3, "axleNumber", resultJson, "axle_number")
        putValueByOrder(target1, target2, target3, "planDate", resultJson, "plan_date")
        putValueByOrder(target1, target2, target3, "plateColor", resultJson, "plate_color")
        putValueByOrder(target1, target2, target3, "energy", resultJson, "energy")
        putValueByOrder(target1, target2, target3, "emitStand", resultJson, "emit_stand")
        putValueByOrder(target1, target2, target3, "passport", resultJson, "passport")
        putValueByOrder(target1, target2, target3, "stype", resultJson, "stype")
        putValueByOrder(target1, target2, target3, "pathCount", resultJson, "path_count")
        putValueByOrder(target1, target2, target3, "opt", resultJson, "opt")
        putValueByOrder(target1, target2, target3, "strategy", resultJson, "strategy")
        putValueByOrder(target1, target2, target3, "merge", resultJson, "merge")
        putValueByOrder(target1, target2, target3, "routeId", resultJson, "routeid_in")
        putValueByOrder(target1, target2, target3, "fixedRoute", resultJson, "fixed_route")
        putValueByOrder(target1, target2, target3, "fencedist", resultJson, "fencedist")
        putValueByOrder(target1, target2, target3, "reRoute", resultJson, "reroute")
        putValueByOrder(target1, target2, target3, "starts", resultJson, "starts")
        putValueByOrder(target1, target2, target3, "swids", resultJson, "swids")
        putValueByOrder(target1, target2, target3, "lineCode", resultJson, "line_code")
      }
    }

    resultJson
  }


  /**
    * 1
    * @param target1
    * @param target2
    * @param target3
    * @param key
    * @param resultJson
    * @param field
    * @return
    */
  def putValueByOrder(target1:JSONObject, target2:JSONObject, target3:JSONObject, key:String, resultJson:JSONObject, field:String):Unit = {
    val value = getValueByOrder(target1, target2, target3, key)
    if(value!=null) resultJson.put(field, value)
  }


  /**
    * 1
    * @param target1
    * @param target2
    * @param target3
    * @param key
    * @return
    */
  def getValueByOrder(target1:JSONObject, target2:JSONObject, target3:JSONObject, key:String):java.lang.String ={
    var value = ""
    if(target1!=null){
      value = target1.getString(key)
    }
    if(StringUtils.isEmpty(value) && target2!=null){
      value = target2.getString(key)
    }
    if(StringUtils.isEmpty(value) && target3!=null){
      value = target3.getString(key)
    }
    if(StringUtils.isEmpty(value)) value = null
    value
  }





  /**
    * 获取msNaviLog日志
    * @param spark
    * @param getHiveRdd
    * @param dateList
    * @return
    */
  def getMsNaviLogRdd(spark:SparkSession, getHiveRdd:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject],dateList:ArrayBuffer[String]):RDD[JSONObject] ={
    val logType = "msNaviLog"
    logger.error(">>>获取"+dateList.mkString(",")+"号的" + logType + "日志")
    val validRdd = getHiveRdd(spark,dateList,logType)
    val computeRdd = validRdd
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()
        if(json!=null){
          var inc_date = ""

          var pns_logtype = ""
          var request_id = ""
          var req_time:java.lang.Long = null
          var no = ""
          var origin = ""
          var destination = ""
          var route_id = ""
          var src = ""
          var status = ""

          pns_logtype = json.getString("pnsNaviLogType")
          request_id = json.getString("requestId")
          req_time = json.getLong("reqTime")
          if(req_time!=null){
            inc_date = longToTime(req_time).split(" ")(0).replaceAll("-","")
          }
          no = json.getString("no")

          val result = json.getJSONObject("result")
          if(result!=null){
            status = result.getString("status")
            val routes = result.getJSONObject("routes")
            if(routes!=null){
              origin = routes.getString("origin")
              destination = routes.getString("destination")
              val pathes = routes.getJSONArray("pathes")
              if(pathes!=null && pathes.size() > 0){
                val path0 = pathes.getJSONObject(0)
                if(path0!=null){
                  route_id = path0.getString("id")
                  src = path0.getString("src")
                }
                if(StringUtils.isEmpty(inc_date)) inc_date = ""
                if(StringUtils.isEmpty(pns_logtype)) pns_logtype = ""
                if(StringUtils.isEmpty(request_id)) request_id = ""
                if(StringUtils.isEmpty(no)) no = ""
                if(StringUtils.isEmpty(origin)) origin = ""
                if(StringUtils.isEmpty(destination)) destination = ""
                if(StringUtils.isEmpty(route_id)) route_id = ""
                if(StringUtils.isEmpty(src)) src = ""
                if(StringUtils.isEmpty(status)) status = ""

                for(i<- 0.until(pathes.size())){
                  val path = pathes.getJSONObject(i)
                  if(path!=null){
                    val newJson = new JSONObject()
                    newJson.put("inc_date", inc_date)
                    newJson.put("pns_logtype", pns_logtype)
                    newJson.put("request_id", request_id)
                    if(req_time!=null) newJson.put("req_time", req_time)
                    newJson.put("no", no)
                    newJson.put("origin", origin)
                    newJson.put("destination", destination)
                    newJson.put("route_index", i)
                    newJson.put("route_id", route_id)
                    newJson.put("src", src)
                    newJson.put("status", status)

                    val distance = path.getString("distance")
                    if(distance!=null) newJson.put("distance", distance)

                    val links = path.getString("swidList")
                    if(links!=null) newJson.put("links", links)

                    val strategy = path.getString("strategy")
                    if(strategy!=null) newJson.put("strategy", strategy)

                    val polylineX = path.getJSONArray("polylineX")
                    val polylineY = path.getJSONArray("polylineY")
                    handlePolyline(newJson, polylineX, polylineY)

                    list += newJson
                  }
                }

              }
            }
          }

        }

        list
      })
      .repartition(repartition).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()

    computeRdd
  }


//  /**
//    * 获取sdkNaviLog日志
//    * @param spark
//    * @param getHiveRdd
//    * @param dateList
//    * @return
//    */
//  def getSdkNaviLogRdd(spark:SparkSession, getHiveRdd:(SparkSession,ArrayBuffer[String],String) => RDD[JSONObject],dateList:ArrayBuffer[String]):RDD[JSONObject] ={
//    val logType = "sdkNaviLog"
//    logger.error(">>>获取"+dateList.mkString(",")+"号的" + logType + "日志")
//    val validRdd = getHiveRdd(spark,dateList,logType)
//    val computeRdd = validRdd
//      .map(json=>{
//        var navi_id = ""
//        var report_time:java.lang.Long = null
//        if(json!=null){
//          val data = json.getJSONObject("data")
//          if(data!=null){
//            navi_id = data.getString("naviId")
//            report_time = data.getLong("reportTime")
//            if(report_time!=null){
//              val inc_date = longToTime(report_time).split(" ")(0).replaceAll("-","")
//              json.put("inc_date",inc_date)
//            }
//          }
//        }
//        if(report_time==null) report_time = Long.MaxValue
//        ((navi_id,report_time),json)
//      })
//      .groupByKey()
//      .map(obj=>{
//        val json = obj._2.toList.head
//        json
//      })
//      .repartition(repartition).persist(StorageLevel.DISK_ONLY)
//    logger.error(">>>日志量：" + computeRdd.count())
//    validRdd.unpersist()
//
//    computeRdd
//  }








  def getUrl(json:JSONObject, prefix:String): String ={
    var resultUrl = ""
    try {
      val params = new ArrayBuffer[String]()
      if(json != null && json.keySet().size() > 0){
        val keys = json.keySet().toArray
        for (i <- 0.until(json.size())){
          val key = keys(i).toString
          if(key != null){
            var value = json.getString(key)
            if(value == null) value = ""
            val param = key + "=" + URLEncoder.encode(value, "UTF8")
            params += param
          }
        }
      }
      resultUrl= prefix + params.mkString("&")
    } catch {
      case e:Exception =>logger.error(">>>解析url报错："+e)
    }
    resultUrl
  }


  def getUrlPost(json:JSONObject, url:String): String ={
    var resultUrl = url
    if(json!=null) resultUrl = url + ":" + json.toJSONString
    resultUrl
  }


//  /**
//    * 处理link数据
//    * @param json
//    */
//  def handleLinks(json:JSONObject,segments:JSONArray): Unit ={
//    var drLength0List = new ArrayBuffer[Int]()
//    var drLength1List = new ArrayBuffer[Int]()
//    var drLength3List = new ArrayBuffer[Int]()
//    val swids = new ArrayBuffer[String]()
//
//    if(segments!=null && segments.size()>0){
//      for(i<- 0.until(segments.size())){
//        val segment = segments.getJSONObject(i)
//        if(segment!=null){
//          val links = segment.getJSONArray("links")
//          if(links!=null && links.size()>0){
//            for(j<- 0.until(links.size())){
//              val link = links.getJSONObject(j)
//              if(link!=null){
//                val swid = link.getString("swId")
//                if(!StringUtils.isEmpty(swid)) swids += swid
//                val drLength = link.getInteger("drLength")
//                val dynSpeed = link.getInteger("dynSpeed")
//                if(dynSpeed!=null && drLength!=null){
//                  if(dynSpeed==0){
//                    drLength0List+=drLength
//                  }else if(dynSpeed==1){
//                    drLength1List+=drLength
//                  }else if(dynSpeed>=3 && dynSpeed<=9){
//                    drLength3List+=drLength
//                  }
//                }
//              }
//            }
//          }
//        }
//      }
//    }
//
//    val drLength0Sum = drLength0List.sum
//    val drLength1Sum = drLength1List.sum
//    val drLength3Sum = drLength3List.sum
//    val drLengthSum = drLength0Sum+drLength1Sum+drLength3Sum
//    val drLength0SumRate = getRate(drLength0Sum,drLengthSum)
//    val drLength1SumRate = getRate(drLength1Sum,drLengthSum)
//    val drLength3SumRate = getRate(drLength3Sum,drLengthSum)
//    val rdynsdlen =drLength1Sum+"_"+drLength1SumRate+"|"+drLength3Sum+"_"+drLength3SumRate+"|"+drLength0Sum+"_"+drLength0SumRate
//    val drLength0Count = drLength0List.length
//    val drLength1Count = drLength1List.length
//    val drLength3Count = drLength3List.length
//    val drLengthCount = drLength0Count+drLength1Count+drLength3Count
//    val drLength0CountRate = getRate(drLength0Count,drLengthCount)
//    val drLength1CountRate = getRate(drLength1Count,drLengthCount)
//    val drLength3CountRate = getRate(drLength3Count,drLengthCount)
//    val rdynsdcnt = drLength1Count+"_"+drLength1CountRate+"|"+drLength3Count+"_"+drLength3CountRate+"|"+drLength0Count+"_"+drLength0CountRate
//
//    val links = swids.mkString(",")
//    json.put("links", links)
//    json.put("linknum", links.length)
//    json.put("rdynsdlen",rdynsdlen)
//    json.put("rdynsdcnt",rdynsdcnt)
//  }


  /**
    * 处理polyline数据
    * @param json
    */
  def handlePolyline(json:JSONObject,polylineX:JSONArray,polylineY:JSONArray): Unit ={
    val polyline = new JSONArray()

    var x:java.lang.Long = 0l
    var y:java.lang.Long = 0l

    if(polylineX!=null && polylineY!=null && polylineX.size() > 0 && polylineX.size() <= polylineY.size()){
      for(i<-0.until(polylineX.size())){
        val X = polylineX.getLong(i)
        val Y = polylineY.getLong(i)
        x = x + X
        y = y + Y
        val tmpX = x.toDouble / 3600000
        val tmpY = y.toDouble / 3600000
        val xy = new JSONObject()
        xy.put("x",tmpX)
        xy.put("y",tmpY)
        polyline.add(xy)
      }
    }

    if(polyline!=null && polyline.size() > 0) json.put("polyline", polyline)
  }


//  /**
//    * 处理polyline数据
//    * @param json
//    */
//  def handlePolyline(json:JSONObject,polylineX:JSONArray,polylineY:JSONArray): Unit ={
//    val xys = new ArrayBuffer[String]()
//
//    var x:java.lang.Long = 0l
//    var y:java.lang.Long = 0l
//
//    if(polylineX!=null && polylineY!=null && polylineX.size() > 0 && polylineX.size() <= polylineY.size()){
//      for(i<-0.until(polylineX.size())){
//        val X = polylineX.getLong(i)
//        val Y = polylineY.getLong(i)
//        x = x + X
//        y = y + Y
//        val tmpX = x.toDouble / 3600000
//        val tmpY = y.toDouble / 3600000
//        val xy = tmpX.toString + "," + tmpY.toString
//        xys += xy
//      }
//    }
//
//    val str = xys.mkString(";")
//    json.put("polyline", str)
//  }


  /**
    * 处理link数据
    * @param json
    */
  def handleLinks(json:JSONObject,segments:JSONArray,linkAttributes:JSONArray): Unit ={
    var drLength0List = new ArrayBuffer[Int]()
    var drLength1List = new ArrayBuffer[Int]()
    var drLength3List = new ArrayBuffer[Int]()
    val swids = new ArrayBuffer[String]()

    if(segments!=null && segments.size()>0){
      for(i<- 0.until(segments.size())){
        val segment = segments.getJSONObject(i)
        if(segment!=null){
          val linkSu = segment.getJSONArray("linkSu")
          if(linkSu==null || linkSu.size()==0){
            val links = segment.getJSONArray("links")
            if(links!=null && links.size()>0){
              for(j<- 0.until(links.size())){
                val link = links.getJSONObject(j)
                if(link!=null){
                  val drLength = link.getInteger("drLength")
                  val dynSpeed = link.getInteger("dynSpeed")
                  if(dynSpeed!=null && drLength!=null){
                    if(dynSpeed==0){
                      drLength0List+=drLength
                    }else if(dynSpeed==1){
                      drLength1List+=drLength
                    }else if(dynSpeed>=3 && dynSpeed<=9){
                      drLength3List+=drLength
                    }
                  }

                  if(linkAttributes!=null && linkAttributes.size() > 0){
                    val attrIdx = link.getInteger("attrIdx")
                    if(attrIdx!=null && attrIdx < linkAttributes.size()){
                      val linkAttribute = linkAttributes.getJSONObject(attrIdx)
                      if(linkAttribute!=null){
                        val swId = linkAttribute.getString("swId")
                        if(!StringUtils.isEmpty(swId)) swids += swId
                      }
                    }
                  }
                }
              }
            }
          }
          else{
            for(i<-0.until(linkSu.size())){
              val linksu = linkSu.getJSONObject(i)
              if(linksu!=null){
                val swId = linksu.getString("swId")
                if(!StringUtils.isEmpty(swId)) swids += swId
              }
            }
          }


        }
      }
    }

    val drLength0Sum = drLength0List.sum
    val drLength1Sum = drLength1List.sum
    val drLength3Sum = drLength3List.sum
    val drLengthSum = drLength0Sum+drLength1Sum+drLength3Sum
    val drLength0SumRate = getRate(drLength0Sum,drLengthSum)
    val drLength1SumRate = getRate(drLength1Sum,drLengthSum)
    val drLength3SumRate = getRate(drLength3Sum,drLengthSum)
    val rdynsdlen =drLength1Sum+"_"+drLength1SumRate+"|"+drLength3Sum+"_"+drLength3SumRate+"|"+drLength0Sum+"_"+drLength0SumRate
    val drLength0Count = drLength0List.length
    val drLength1Count = drLength1List.length
    val drLength3Count = drLength3List.length
    val drLengthCount = drLength0Count+drLength1Count+drLength3Count
    val drLength0CountRate = getRate(drLength0Count,drLengthCount)
    val drLength1CountRate = getRate(drLength1Count,drLengthCount)
    val drLength3CountRate = getRate(drLength3Count,drLengthCount)
    val rdynsdcnt = drLength1Count+"_"+drLength1CountRate+"|"+drLength3Count+"_"+drLength3CountRate+"|"+drLength0Count+"_"+drLength0CountRate

    val links = swids.mkString(",")
    json.put("links", links)
    json.put("linknum", links.length)
    json.put("rdynsdlen",rdynsdlen)
    json.put("rdynsdcnt",rdynsdcnt)
  }


//  /**
//    * 处理link数据
//    * @param json
//    */
//  def handleLinksNoYaw(json:JSONObject): Unit ={
//    var distance = 0.0
//    var duration = 0.0
//    var toll_distance = 0.0
//    var tolls = 0.0
//    var ft_flen = ""
//    var ft_tlen = ""
//    var trafficlight_count = 0.0
//    var highspeed_distance = 0.0
//    var links_speedList = new ArrayBuffer[String]()
//    var drLength0List = new ArrayBuffer[Int]()
//    var drLength1List = new ArrayBuffer[Int]()
//    var drLength3List = new ArrayBuffer[Int]()
//    val swids = new ArrayBuffer[String]()
//
//    val route = json.getJSONObject("route")
//    if(route!=null){
//      val paths = route.getJSONArray("paths")
//      if(paths!=null && paths.size()>0){
//        val path0 = paths.getJSONObject(0)
//        val pathn = paths.getJSONObject(paths.size() - 1)
//        if(path0!=null){
//          val outinfo = path0.getJSONObject("outinfo")
//          if(outinfo!=null){
//            ft_flen = outinfo.getString("flen")
//          }
//        }
//        if(pathn!=null){
//          val outinfo = pathn.getJSONObject("outinfo")
//          if(outinfo!=null){
//            ft_tlen = outinfo.getString("flen")
//          }
//        }
//
//        for(i<- 0.until(paths.size())){
//          val path = paths.getJSONObject(i)
//          if(path!=null){
//            val _distance = path.getDouble("distance")
//            if(_distance!=null) distance = distance + _distance
//            val _duration = path.getDouble("duration")
//            if(_duration!=null) duration = duration + _duration
//            val _toll_distance = path.getDouble("toll_distance")
//            if(_toll_distance!=null) toll_distance = toll_distance + _toll_distance
//            val _tolls = path.getDouble("tolls")
//            if(_tolls!=null) tolls = tolls + _tolls
//            val _trafficlight_count = path.getInteger("trafficlight_count")
//            if(_trafficlight_count!=null) trafficlight_count = trafficlight_count + _trafficlight_count
//            val _highspeed_distance = path.getDouble("highspeed_distance")
//            if(_highspeed_distance!=null) highspeed_distance = highspeed_distance + _highspeed_distance
//
//            val outinfo = path.getJSONObject("outinfo")
//            if(outinfo!=null){
//              val links = outinfo.getJSONArray("links")
//              if(links!=null && links.size()>0){
//                for(j<- 0.until(links.size())){
//                  val link = links.getJSONObject(j)
//                  if(link!=null){
//                    val swid = link.getString("swid")
//                    if(!StringUtils.isEmpty(swid)) swids += swid
//                    var rticCode = link.getString("rtic_code")
//                    var speed = link.getString("speed")
//                    if(StringUtils.isEmpty(rticCode)) rticCode = ""
//                    if(StringUtils.isEmpty(speed)) speed = ""
//                    if(!StringUtils.isEmpty(rticCode) || !StringUtils.isEmpty(speed)){
//                      links_speedList += rticCode + "_" + speed
//                    }
//                    val drLength = link.getInteger("dr_len")
//                    val dynSpeed = link.getInteger("dynSpeed")
//                    if(dynSpeed!=null && drLength!=null){
//                      if(dynSpeed==0){
//                        drLength0List+=drLength
//                      }else if(dynSpeed==1){
//                        drLength1List+=drLength
//                      }else if(dynSpeed>=3 && dynSpeed<=9){
//                        drLength3List+=drLength
//                      }
//                    }
//                  }
//                }
//              }
//            }
//          }
//        }
//      }
//    }
//
//
//    val drLength0Sum = drLength0List.sum
//    val drLength1Sum = drLength1List.sum
//    val drLength3Sum = drLength3List.sum
//    val drLengthSum = drLength0Sum+drLength1Sum+drLength3Sum
//    val drLength0SumRate = getRate(drLength0Sum,drLengthSum)
//    val drLength1SumRate = getRate(drLength1Sum,drLengthSum)
//    val drLength3SumRate = getRate(drLength3Sum,drLengthSum)
//    val rdynsdlen =drLength1Sum+"_"+drLength1SumRate+"|"+drLength3Sum+"_"+drLength3SumRate+"|"+drLength0Sum+"_"+drLength0SumRate
//    val drLength0Count = drLength0List.length
//    val drLength1Count = drLength1List.length
//    val drLength3Count = drLength3List.length
//    val drLengthCount = drLength0Count+drLength1Count+drLength3Count
//    val drLength0CountRate = getRate(drLength0Count,drLengthCount)
//    val drLength1CountRate = getRate(drLength1Count,drLengthCount)
//    val drLength3CountRate = getRate(drLength3Count,drLengthCount)
//    val rdynsdcnt = drLength1Count+"_"+drLength1CountRate+"|"+drLength3Count+"_"+drLength3CountRate+"|"+drLength0Count+"_"+drLength0CountRate
//
//    json.put("distance",distance)
//    json.put("duration",duration)
//    json.put("toll_distance",toll_distance)
//    json.put("tolls",tolls)
//    json.put("ft_flen",ft_flen)
//    json.put("ft_tlen",ft_tlen)
//    json.put("trafficlight_count",trafficlight_count)
//    json.put("highspeed_distance",highspeed_distance)
//    json.put("links", swids.mkString(","))
//    json.put("links_speed", links_speedList.mkString(","))
//    json.put("rdynsdlen",rdynsdlen)
//    json.put("rdynsdcnt",rdynsdcnt)
//  }



  /**
    * 处理link数据
    * @param json
    */
  def handleLinksNoYaw(json:JSONObject): Unit ={
    var links_speedList = new ArrayBuffer[String]()
    var drLength0List = new ArrayBuffer[Int]()
    var drLength1List = new ArrayBuffer[Int]()
    var drLength3List = new ArrayBuffer[Int]()
    val swids = new ArrayBuffer[String]()

    if(json!=null){
      val detailLink = json.getJSONArray("detailLink")
      if(detailLink!=null && detailLink.size()>0){
        for(i<- 0.until(detailLink.size())){
          val detail = detailLink.getJSONObject(i)
          if(detail!=null){
            val swId = detail.getString("swId")
            if(!StringUtils.isEmpty(swId)) swids += swId
            var rticCode = detail.getString("rticCode")
            var speed = detail.getString("speed")
            if(StringUtils.isEmpty(rticCode)) rticCode = ""
            if(StringUtils.isEmpty(speed)) speed = ""
            if(!StringUtils.isEmpty(rticCode) || !StringUtils.isEmpty(speed)){
              links_speedList += rticCode + "_" + speed
            }
            val drLength = detail.getInteger("dr_len")
            val dynSpeed = detail.getInteger("dynSpeed")
            if(dynSpeed!=null && drLength!=null){
              if(dynSpeed==0){
                drLength0List+=drLength
              }else if(dynSpeed==1){
                drLength1List+=drLength
              }else if(dynSpeed>=3 && dynSpeed<=9){
                drLength3List+=drLength
              }
            }
          }
        }
      }
    }


    val drLength0Sum = drLength0List.sum
    val drLength1Sum = drLength1List.sum
    val drLength3Sum = drLength3List.sum
    val drLengthSum = drLength0Sum+drLength1Sum+drLength3Sum
    val drLength0SumRate = getRate(drLength0Sum,drLengthSum)
    val drLength1SumRate = getRate(drLength1Sum,drLengthSum)
    val drLength3SumRate = getRate(drLength3Sum,drLengthSum)
    val rdynsdlen =drLength1Sum+"_"+drLength1SumRate+"|"+drLength3Sum+"_"+drLength3SumRate+"|"+drLength0Sum+"_"+drLength0SumRate
    val drLength0Count = drLength0List.length
    val drLength1Count = drLength1List.length
    val drLength3Count = drLength3List.length
    val drLengthCount = drLength0Count+drLength1Count+drLength3Count
    val drLength0CountRate = getRate(drLength0Count,drLengthCount)
    val drLength1CountRate = getRate(drLength1Count,drLengthCount)
    val drLength3CountRate = getRate(drLength3Count,drLengthCount)
    val rdynsdcnt = drLength1Count+"_"+drLength1CountRate+"|"+drLength3Count+"_"+drLength3CountRate+"|"+drLength0Count+"_"+drLength0CountRate

    json.put("links", swids.mkString(","))
    json.put("links_speed", links_speedList.mkString(","))
    json.put("rdynsdlen",rdynsdlen)
    json.put("rdynsdcnt",rdynsdcnt)
  }


  def getRate(v1:Int, v2:Int): String ={
    var result = ""
    try {
      result = df.format(v1.toDouble / v2.toDouble)
    } catch {
      case e:Exception =>logger.error(">>>除法异常")
    }
    result
  }



  /**
    * 时间戳转换为时分秒
    * @param timestamp
    * @return
    */
  def longToTime(timestamp:Long,format:String="yyyy-MM-dd HH:mm:ss SSS"): String ={
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e:Exception =>logger.error(">>>时间戳解析异常")
    }
    datetime
  }



  /**
    * 过滤有效日志
    * @param spark
    * @param dateList
    * @param subType
    * @return
    */
  def fiterOneDayValidLog(spark:SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject])={
    val date = dateList(0)
    var sql=""
    var logRdd:RDD[JSONObject] = null
    var table = "gis_eta_ms_navi_hive"
    sql =
      s"""
         |select data,inc_day from dm_gis.$table t
         | where inc_day='$date'
       """.stripMargin
    logRdd = NaviLogParse.getValidLog(spark, sql)
    logRdd
  }



  /**
    * 过滤有效日志
    * @param spark
    * @param dateList
    * @param subType
    * @return
    */
  def fiterMutiDayValidLog(spark:SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject])={
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val endDate1 = endDate//DateUtil.getDateStr(endDate,1)
    var sql=""
    var logRdd:RDD[JSONObject] = null
    var table = "gis_eta_ms_navi_hive"
    sql =
      s"""
         |select data,inc_day from dm_gis.$table t
         | where inc_day between '$startDate' and '$endDate1'
       """.stripMargin
    logRdd = NaviLogParse.getValidLog(spark, sql)
    logRdd
  }


}
