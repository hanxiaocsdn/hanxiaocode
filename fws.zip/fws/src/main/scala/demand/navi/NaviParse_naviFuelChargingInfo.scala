package demand.navi

import com.alibaba.fastjson.{JSON, JSONObject}
import common.SourceAndDiskCommon
import demand.utils.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 542350
 * @description: 定点加油日志解析 gis_eta_navi_fuel_charging_info  中间表  gis_eta_navi_fuel_charging_info_inter
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/10/31 9:47
 */
object NaviParse_naviFuelChargingInfo extends SourceAndDiskCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    result.put("data_all", result.getJSONObject("data"))
    result.fluentPutAll(result.getJSONObject("data"))
    result.keySet().toArray.foreach(key => {
      if (result.get(key.toString).isInstanceOf[JSONObject]) {
        val temp = result.getJSONObject(key.toString)
        temp.keySet().toArray.foreach(k => {
          result.put(k.toString.toLowerCase, temp.getString(k.toString))
        })
      }
    })
    "resultstatus,status"
      .split(";").foreach(x => result.put(x.split(",")(0), result.getString(x.split(",")(1))))
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value

  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)
    spark.sqlContext.setConf("hive.exec.dynamic.partition", "true")
    spark.sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    if (args.length == 0) {
      //代码内部传入日期参数
      ParseLog(spark, DateUtil.getYesterday)
    } else if (args.length == 1) {
      //传入参数，单天任务
      ParseLog(spark, args(0))
      processAgg(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }


  def processAgg(spark: SparkSession, date: String): Unit = {
    import spark.implicits._
    val dateList = NaviMain.getMutiDayDateList(date)
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val grdFuelCharging_cols = Seq("task_id", "taskserial", "relativeid", "appver", "serviceid", "reqstarttime", "reqendtime", "reqcosttime", "actualmiles", "deptcode", "ischanged", "isfuelpoint", "fuelchargingmileage", "issf", "moneytype", "litersnumber", "operationtime", "operationtype", "taskoperatetype", "totalamount", "unitprice", "username", "vehiclecode", "vehicleserial", "success", "inc_day").map(col)
    val fuelCharging_cols = Seq("task_id", "navi_id", "queryoilcardresult", "querylastoilinforesult", "oilpredictarg", "oilpredictresult", "inc_day").map(col)
    val adjustPath_cols = Seq("task_id", "fuelleftdistance", "adjustpathargrequestid", "startfuelsize", "inc_day").map(col)

    val res_df_cols = spark.sql("""select * from dm_gis.gis_eta_navi_fuel_charging_info limit 0""").schema.map(x => col(x.name))

    val org_all_df = spark.sql(s"""select * from dm_gis.gis_eta_navi_fuel_charging_info_inter where inc_day between '$startDate' and '$endDate'""")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val fuelCharging_df = org_all_df.filter('subtype === "grdFuelChargingInfoLog" && notNullDef('task_id)).select(grdFuelCharging_cols: _*)

    val oil_cond = notNullDef('queryoilcardresult) || notNullDef('querylastoilinforesult) || notNullDef('oilpredictarg) || notNullDef('oilpredictresult)
    val naviTop3V2_df = org_all_df.filter('subtype === "naviTop3V2Log" && notNullDef('task_id) && oil_cond).select(fuelCharging_cols: _*)
    val adjustPath_df = org_all_df.filter('subtype === "adjustPathLog" && notNullDef('task_id)).select(adjustPath_cols: _*)

    val res_df = fuelCharging_df.join(broadcast(naviTop3V2_df), Seq("task_id", "inc_day"), "left")
      .join(broadcast(adjustPath_df), Seq("task_id", "inc_day"), "left")
      .withColumn("num", row_number().over(Window.partitionBy(res_df_cols: _*).orderBy('inc_day.desc))).filter("num = 1")
      .select(res_df_cols: _*)

    writeToHive(spark, res_df.coalesce(1), Seq("inc_day"), "dm_gis.gis_eta_navi_fuel_charging_info")
  }

  def notNullDef(col: Column): Column = {
    col.isNotNull && trim(col) =!= ""
  }

  /**
   * 将数据写入hive表中【OVERWRITE】
   *
   * @param spark
   * @param dataframe
   * @param partitionCol
   * @param resTableName
   */
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    var runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getFuelChargingInfoRdd
    computeRddF = null
    table = "gis_eta_navi_fuel_charging_info_inter"

    structs = Array("task_id", "taskserial", "relativeid", "appver", "serviceid", "reqstarttime", "reqendtime", "reqcosttime", "actualmiles", "deptcode", "ischanged", "isfuelpoint", "fuelchargingmileage", "issf", "moneytype", "litersnumber", "operationtime", "operationtype", "taskoperatetype", "totalamount", "unitprice", "username", "vehiclecode", "vehicleserial", "success", "navi_id", "subtype", "queryoilcardresult", "querylastoilinforesult", "oilpredictarg", "oilpredictresult", "fuelleftdistance", "adjustpathargrequestid", "startfuelsize")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)
  }

  /**
   * 获取定点加油日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getFuelChargingInfoRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = "grdFuelChargingInfoLog,naviTop3V2Log,adjustPathLog"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    val computeRdd = validRdd
      .map(json => {
        if (json != null) {
          val subtype = json.getString("subType")
          json.put("subtype", subtype)
          if (subtype == "grdFuelChargingInfoLog") {
            var taskid, deptcode, taskserial = ""
            val data = json.getJSONObject("data_all")
            if (data != null) {
              //1 处理根据reqStartTime 分组的信息
              val grdfuelcharginginfolog = data.getJSONObject("fuelChargingInfoArg")
              val reqStartTime: java.lang.Long = data.getLong("reqStartTime")
              if (reqStartTime != null) {
                val inc_day = longToTime(reqStartTime).split(" ")(0).replaceAll("-", "")
                json.put("inc_day", inc_day)
              }
              if (grdfuelcharginginfolog != null) {
                val taskid_tmp = grdfuelcharginginfolog.getString("taskId")
                deptcode = grdfuelcharginginfolog.getString("deptCode")
                taskserial = grdfuelcharginginfolog.getString("taskSerial")
                if (taskid_tmp == "0") taskid = taskserial
                if (taskid_tmp != "0") taskid = deptcode + "" + taskid_tmp
                json.put("taskid", taskid)
              }
              //2 处理最后1个特殊字段
              val result = data.getJSONObject("result")
              if (result != null) {
                val success = result.getString("success")
                json.put("success", success)
              }
            }
          }
          if (subtype == "naviTop3V2Log") {
            var taskid, naviid, queryoilcardresult, querylastoilinforesult, oilpredictarg, oilpredictresult = ""
            var req_time: java.lang.Long = null
            val data_all = json.getJSONObject("data_all")
            val reqStartTime: java.lang.Long = data_all.getLong("reqStartTime")
            if (reqStartTime != null) {
              val inc_day = longToTime(reqStartTime).split(" ")(0).replaceAll("-", "")
              json.put("inc_day", inc_day)
            }
            if (data_all != null) {
              val navitop3args = data_all.getJSONObject("naviTop3Args")
              if (navitop3args != null) {
                taskid = navitop3args.getString("taskId")
                naviid = navitop3args.getString("naviId")
                json.put("taskid", taskid)
                json.put("naviid", naviid)
              }
            }
            try {
              queryoilcardresult = data_all.getJSONObject("queryOilCardResult").toJSONString
            } catch {
              case e: Exception => logger.error("" + e.getMessage)
            }
            try {
              querylastoilinforesult = data_all.getJSONObject("queryLastOilInfoResult").toJSONString
            } catch {
              case e: Exception => logger.error("" + e.getMessage)
            }
            try {
              oilpredictarg = data_all.getJSONObject("oilPredictArg").toJSONString
            } catch {
              case e: Exception => logger.error("" + e.getMessage)
            }
            try {
              oilpredictresult = data_all.getJSONObject("oilPredictResult").toJSONString
            } catch {
              case e: Exception => logger.error("" + e.getMessage)
            }
            json.put("queryoilcardresult", queryoilcardresult)
            json.put("querylastoilinforesult", querylastoilinforesult)
            json.put("oilpredictarg", oilpredictarg)
            json.put("oilpredictresult", oilpredictresult)

          }
          if (subtype == "adjustPathLog") {
            var taskid, naviid, fuelleftdistance, adjustpathargrequestid, startfuelsize = ""
            val data_all = json.getJSONObject("data_all")
            val reqStartTime: java.lang.Long = data_all.getLong("reqStartTime")
            if (reqStartTime != null) {
              val inc_day = longToTime(reqStartTime).split(" ")(0).replaceAll("-", "")
              json.put("inc_day", inc_day)
            }
            if (data_all != null) {
              val adjustPathArg = data_all.getJSONObject("adjustPathArg")
              adjustpathargrequestid = data_all.getString("requestId")
              json.put("adjustpathargrequestid", adjustpathargrequestid)
              if (adjustPathArg != null) {
                fuelleftdistance = adjustPathArg.getString("fuelLeftDistance")
                startfuelsize = adjustPathArg.getString("startFuelSize")
                taskid = adjustPathArg.getString("taskId")
                naviid = adjustPathArg.getString("naviId")
                json.put("fuelleftdistance", fuelleftdistance)
                json.put("startfuelsize", startfuelsize)
                json.put("taskid", taskid)
                json.put("naviid", naviid)
              }
            }
          }
        }
        json
      }).filter(_ != null)
      .repartition(repartition).persist()

    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()
    computeRdd
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val endDate1 = endDate
    var sql = ""
    val table = "gis_eta_navi_query_hive"
    if (subType.contains(",")) {
      val subTypes = subType.split(",")
      val subType1 = subTypes(0)
      val subType2 = subTypes(1)
      val subType3 = subTypes(2)
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate1'
           | and (
           | get_json_object(data, '$$.subType') = '$subType1'
           | or get_json_object(data, '$$.subType') = '$subType2'
           | or get_json_object(data, '$$.subType') = '$subType3')
       """.stripMargin
    }
    else {
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate1'
           | and get_json_object(data, '$$.subType') = '$subType'
       """.stripMargin
    }
    logger.error("执行的sql>>>>" + sql)
    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x))
  }
}
