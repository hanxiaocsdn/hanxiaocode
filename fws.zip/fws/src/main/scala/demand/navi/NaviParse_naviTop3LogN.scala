package demand.navi

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import common.SourceAndDiskCommon
import demand.utils._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * @task_id: 262059
 * @description:表1 gis_navi_top3_parse
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/10/17 10:46
 */
object NaviParse_naviTop3LogN extends SourceAndDiskCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    result.put("data_all", result.getJSONObject("data"))
    result.fluentPutAll(result.getJSONObject("data"))
    result.keySet().toArray.foreach(key => {
      if (result.get(key.toString).isInstanceOf[JSONObject]) {
        val temp = result.getJSONObject(key.toString)
        temp.keySet().toArray.foreach(k => {
          result.put(k.toString.toLowerCase, temp.getString(k.toString))
        })
      }
    })
    "maxdetaildistance,maxdeta;vehicledir1,vehicledir;startdept,srcdeptcode;enddept,destdeptcode"
      .split(";").foreach(x => result.put(x.split(",")(0), result.getString(x.split(",")(1))))
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value


  def get3[T <% RDD[T]](value: T): RDD[T] = value

  def get4[T](value: T) = List(value)

  trait get5[-T, +U] {
    def apply(x: T): U
  }


  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      ParseLog(spark, DateUtil.getYesterday)
    } else if (args.length == 1) {
      //传入参数，单天任务
      ParseLog(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }

    spark.stop()
    logger.error(">>>处理完毕---------------")
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    var runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getTop3Rdd
    computeRddF = null
    table = "gis_navi_top3_parse"

    structs = Array("task_id", "navi_id", "app_ver", "req_time", "vehicle_dir", "src_deptcode", "dest_deptcode", "driver_id", "startx", "starty", "endx", "endy", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plan_date", "plate_color", "energy", "emit_stand", "passport", "opt", "routeid_in", "fixed_route", "merge", "fencedist", "status", "req_starttime", "req_endtime", "req_costtime", "pnstop3_starttime", "pnstop3_endtime", "pnstop3_costtime", "ft_url", "request_id", "max_detail_distance", "ak", "start_speed", "vehicle_dir1", "tracks", "driver_type", "service_id", "line_code", "origin_src", "econ_id", "stdline", "nostd_reasontype", "nostd_reasondetail", "curplan_arrivetm", "top3_reqtype", "opt_sequence",
      "start_dept", "end_dept", "vehicle_type_navi",
      "stdmatchtype", "passzonetype", "cachestdid",
      "linerequireid", "passzonetableid", "cachestdblockroad",
      "nostdreasontype", "nostdreasondetail", "plantype")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)

  }


  /**
   * 获取naviTop3Log日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getTop3Rdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = "naviTop3V2Log"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "和附加条件为：planType = slSerPlan 日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    //第1part 原始逻辑
    val computeRdd1 = validRdd.map(json => {
      var navi_id = ""
      var src_deptcode, dest_deptcode, vehicle_type, start_dept, end_dept, vehicle_type_navi, opt = ""
      var req_time: java.lang.Long = null
      if (json != null) {
        var data: JSONObject = null
        data = json.getJSONObject("data_all")
        if (data != null) {
          val planType = data.getString("planType")
          if (planType == null || planType != "slSerPlan") {
            val naviTop3Args = data.getJSONObject("naviTop3Args")
            val stdNaviResultData = data.getJSONObject("stdNaviResultData")
            val pnsTop3Args = data.getJSONObject("pnsTop3Args")
            if (naviTop3Args != null) {
              json.put("vehicle", naviTop3Args.getString("vehicle"))
              navi_id = naviTop3Args.getString("naviId")
              req_time = naviTop3Args.getLong("reqTime")
              start_dept = naviTop3Args.getString("srcDeptCode")
              end_dept = naviTop3Args.getString("destDeptCode")
              if (start_dept != null) json.put("startdept", start_dept) else json.put("startdept", "")
              if (end_dept != null) json.put("enddept", end_dept) else json.put("enddept", "")
              if (req_time != null) {
                val inc_day = longToTime(req_time).split(" ")(0).replaceAll("-", "")
                json.put("inc_day", inc_day)
              }
            }
            if (stdNaviResultData != null) {
              src_deptcode = stdNaviResultData.getString("newSrcZoneCode")
              dest_deptcode = stdNaviResultData.getString("newDestZoneCode")

              if (src_deptcode != null) json.put("srcdeptcode", src_deptcode) else json.put("srcdeptcode", "")
              if (dest_deptcode != null) json.put("destdeptcode", dest_deptcode) else json.put("destdeptcode", "")
            }
            if (pnsTop3Args != null) {
              vehicle_type_navi = pnsTop3Args.getString("vehicle")
              opt = pnsTop3Args.getString("opt")
              json.put("vehicletypenavi", vehicle_type_navi)
              json.put("vehicletype", vehicle_type_navi) //data.pnsTop3Args.vehicle
              json.put("opt", opt)
            }
          }
        }
      }
      if (req_time == null) req_time = Long.MaxValue

      val navi_id_key = navi_id + "&_&" + Random.nextInt(1000).toString
      json.put("navi_id_key", navi_id_key)
      json.put("req_time_key", req_time)
      (navi_id_key, (req_time, json))
    })
      .groupByKey().map(obj => {
      val json = obj._2.toList.sortBy(_._1).map(_._2).reverse.head
      json
    }).map(json => {
      val navi_id_key = json.getString("navi_id_key").split("&_&")(0)
      val req_time_key = json.getLong("req_time_key")
      (navi_id_key, (req_time_key, json))
    }).groupByKey().map(obj => {
      val json = obj._2.toList.sortBy(_._1).map(_._2).reverse.head
      json
    })
      .map(json => {
        if (json != null) {
          val data = json.getJSONObject("data_all")
          if (data != null) {
            val pnsTop3Args = data.getJSONObject("pnsTop3Args")
            if (pnsTop3Args != null) {
              val origin = pnsTop3Args.getString("origin")
              val destination = pnsTop3Args.getString("destination")
              if (origin != null) {
                val coords = origin.split(",")
                if (coords != null && coords.nonEmpty) {
                  val x = coords(0)
                  json.put("startx", x)
                  if (coords.length > 1) {
                    val y = coords(1)
                    json.put("starty", y)
                  }
                }
              }
              if (destination != null) {
                val coords = destination.split(",")
                if (coords != null && coords.nonEmpty) {
                  val x = coords(0)
                  json.put("endx", x)
                  if (coords.length > 1) {
                    val y = coords(1)
                    json.put("endy", y)
                  }
                }
              }
              json.put("fturl", "http://10.206.169.158:8080/rp/navi/v2/top3:" + pnsTop3Args.toJSONString)

              val stdLineData = pnsTop3Args.getString("stdLineData")
              if (!StringUtils.isEmpty(stdLineData)) {
                val strs = stdLineData.split("#")
                if (strs != null && strs.size > 1) {
                  json.put("econid", strs(1))
                }
              }
            }
          }
        }
        json
      }).repartition(repartition).persist()
    //    第2part 新增的array的逻辑
    val computeRdd2 = validRdd.flatMap(json => {
      val list = new ArrayBuffer[JSONObject]()
      var reqtime: java.lang.Long = null
      if (json != null) {
        var data: JSONObject = null
        try {
          data = json.getJSONObject("data_all")
        } catch {
          case e1: ClassCastException => logger.error("json转换异常" + e1.getMessage)
          case e2: Exception => logger.error("json转换异常" + e2.getMessage)
        }
        if (data != null) {
          val naviTop3Args = data.getJSONObject("naviTop3Args")
          val pnsTop3Args = data.getJSONObject("pnsTop3Args")
          if (naviTop3Args != null) {
            reqtime = naviTop3Args.getLong("reqTime")
            json.put("reqtime", reqtime)
            json.put("vehicle", naviTop3Args.getString("vehicle"))
          }
          if (reqtime != null) {
            val inc_day = longToTime(reqtime).split(" ")(0).replaceAll("-", "")
            json.put("inc_day", inc_day)
          }
          //          if (pnsTop3Args != null) {
          //            json.put("fturl", "http://10.206.169.158:8080/rp/navi/v2/top3:" + pnsTop3Args.toJSONString)
          //          }
          val planType = data.getString("planType")
          if (planType == "slSerPlan") {
            val stdNaviResultDataList = data.getJSONArray("stdNaviResultDataList")
            val slSerPlanPnsTop3ArgsList = data.getJSONArray("slSerPlanPnsTop3ArgsList")
            val std_name_arr = Seq("srcdeptcode", "destdeptcode", "vehicletype", "stdmatchtype", "passzonetype", "cachestdid", "linerequireid", "passzonetableid", "cachestdblockroad", "nostdreasontype", "nostdreasondetail", "status")
            val std_arr = Seq("newSrcZoneCode", "newDestZoneCode", "newVehicle", "stdMatchType", "passZoneType", "cacheStdId", "lineRequireId", "passZoneTableId", "cacheStdBlockRoad", "noStdReasonType", "noStdReasonDetail", "status")

            val slSerPlan_name_arr = Seq("econid", "origin", "destination", "weight", "mload", "length", "width", "height", "axleweight", "axlenumber", "plandate", "platecolor", "energy", "emitstand", "passport", "opt", "routeidin", "fixedroute", "merge", "fencedist", "requestid", "line_code", "econ_id", "top3reqtype", "vehicletypenavi")
            val slSerPlan_arr = Seq("stdLineData", "origin", "destination", "weight", "mload", "size", "width", "height", "axleWeight", "axleNumber", "planDate", "plateColor", "energy", "emitStand", "passport", "opt", "routeId", "fixedRoute", "merge", "fencedist", "requestId", "lineCode", "stdLineData", "reqType", "vehicle")

            if (stdNaviResultDataList != null && slSerPlanPnsTop3ArgsList != null) {
              for (i <- 0 until stdNaviResultDataList.size()) {
                val new_json = new JSONObject()
                json.keySet().toArray.map(key => {
                  new_json.put(key.toString, json.getString(key.toString))
                })
                try {
                  std_name_arr zip std_arr map { x => new_json.put(x._1.toLowerCase, stdNaviResultDataList.getJSONObject(i).getString(x._2)) }
                } catch {
                  case e: Exception => logger.error(json + "=======" + e.printStackTrace())
                }
                try {
                  new_json.put("fturl", "http://10.206.169.158:8080/rp/navi/v2/top3:" + slSerPlanPnsTop3ArgsList.getJSONObject(i).fluentRemove("stdLineData").toJSONString)
                } catch {
                  case e: Exception => "" + e
                }

                try {
                  slSerPlan_name_arr zip slSerPlan_arr map { x =>
                    if (x._1 == "econid") {
                      val stdLineData = slSerPlanPnsTop3ArgsList.getJSONObject(i).getString(x._2)
                      if (!StringUtils.isEmpty(stdLineData)) {
                        val strs = stdLineData.split("#")
                        if (strs != null && strs.size > 1) {
                          new_json.put(x._1, strs(1))
                        }
                      }
                    } else if (x._1 == "origin") {
                      val origin = slSerPlanPnsTop3ArgsList.getJSONObject(i).getString(x._2)
                      if (origin != null) {
                        val coords = origin.split(",")
                        if (coords != null && coords.nonEmpty) {
                          val x = coords(0)
                          new_json.put("startx", x)
                          if (coords.length > 1) {
                            val y = coords(1)
                            new_json.put("starty", y)
                          }
                        }
                      }
                    } else if (x._1 == "destination") {
                      val destination = slSerPlanPnsTop3ArgsList.getJSONObject(i).getString(x._2)
                      if (destination != null) {
                        val coords = destination.split(",")
                        if (coords != null && coords.nonEmpty) {
                          val x = coords(0)
                          new_json.put("endx", x)
                          if (coords.length > 1) {
                            val y = coords(1)
                            new_json.put("endy", y)
                          }
                        }
                      }
                    }
                    else {
                      new_json.put(x._1.toLowerCase, slSerPlanPnsTop3ArgsList.getJSONObject(i).getString(x._2))
                    }
                  }
                } catch {
                  case e: Exception => logger.error(json + "=======" + e.printStackTrace())
                }
                list += new_json
              }
            }
          }
        }
      }
      if (reqtime == null) reqtime = Long.MaxValue
      list
    }).map(json => {
      var naviid, reqtime, requestid = ""
      if (json != null) {
        naviid = json.getString("naviid")
        reqtime = json.getString("reqtime")
        requestid = json.getString("requestid")
      }
      ((naviid, requestid), (reqtime, json)) //todo 此处分组去重有待核实
    }).groupByKey().map(obj => {
      val json = obj._2.toList.sortBy(_._1).map(_._2).reverse.head
      json
    }).repartition(repartition).persist()

    val computeRdd = computeRdd1.union(computeRdd2)
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()

    computeRdd
  }

  def getUrlPost(json: JSONObject, url: String): String = {
    var resultUrl = url
    if (json != null) resultUrl = url + ":" + json.toJSONString
    resultUrl
  }

  /**
   * 处理polyline数据
   *
   * @param json
   */
  def handlePolyline(json: JSONObject, polylineX: JSONArray, polylineY: JSONArray): Unit = {
    val polyline = new JSONArray()

    var x: java.lang.Long = 0l
    var y: java.lang.Long = 0l

    if (polylineX != null && polylineY != null && polylineX.size() > 0 && polylineX.size() <= polylineY.size()) {
      for (i <- 0.until(polylineX.size())) {
        val X = polylineX.getLong(i)
        val Y = polylineY.getLong(i)
        x = x + X
        y = y + Y
        val tmpX = x.toDouble / 3600000
        val tmpY = y.toDouble / 3600000
        val xy = new JSONObject()
        xy.put("x", tmpX)
        xy.put("y", tmpY)
        polyline.add(xy)
      }
    }

    if (polyline != null && polyline.size() > 0) json.put("polyline", polyline)
  }

  /**
   * 处理link数据
   *
   * @param json
   */
  def handleLinks(json: JSONObject, segments: JSONArray, linkAttributes: JSONArray): Unit = {
    var drLength0List = new ArrayBuffer[Int]()
    var drLength1List = new ArrayBuffer[Int]()
    var drLength3List = new ArrayBuffer[Int]()
    val swids = new ArrayBuffer[String]()

    if (segments != null && segments.size() > 0) {
      for (i <- 0.until(segments.size())) {
        val segment = segments.getJSONObject(i)
        if (segment != null) {
          val linkSu = segment.getJSONArray("linkSu")
          if (linkSu == null || linkSu.size() == 0) {
            val links = segment.getJSONArray("links")
            if (links != null && links.size() > 0) {
              for (j <- 0.until(links.size())) {
                val link = links.getJSONObject(j)
                if (link != null) {
                  val drLength = link.getInteger("drLength")
                  val dynSpeed = link.getInteger("dynSpeed")
                  if (dynSpeed != null && drLength != null) {
                    if (dynSpeed == 0) {
                      drLength0List += drLength
                    } else if (dynSpeed == 1) {
                      drLength1List += drLength
                    } else if (dynSpeed >= 3 && dynSpeed <= 9) {
                      drLength3List += drLength
                    }
                  }

                  if (linkAttributes != null && linkAttributes.size() > 0) {
                    val attrIdx = link.getInteger("attrIdx")
                    if (attrIdx != null && attrIdx < linkAttributes.size()) {
                      val linkAttribute = linkAttributes.getJSONObject(attrIdx)
                      if (linkAttribute != null) {
                        val swId = linkAttribute.getString("swId")
                        if (!StringUtils.isEmpty(swId)) swids += swId
                      }
                    }
                  }
                }
              }
            }
          }
          else {
            for (i <- 0.until(linkSu.size())) {
              val linksu = linkSu.getJSONObject(i)
              if (linksu != null) {
                val swId = linksu.getString("swId")
                if (!StringUtils.isEmpty(swId)) swids += swId
              }
            }
          }


        }
      }
    }

    val drLength0Sum = drLength0List.sum
    val drLength1Sum = drLength1List.sum
    val drLength3Sum = drLength3List.sum
    val drLengthSum = drLength0Sum + drLength1Sum + drLength3Sum
    val drLength0SumRate = getRate(drLength0Sum, drLengthSum)
    val drLength1SumRate = getRate(drLength1Sum, drLengthSum)
    val drLength3SumRate = getRate(drLength3Sum, drLengthSum)
    val rdynsdlen = drLength1Sum + "_" + drLength1SumRate + "|" + drLength3Sum + "_" + drLength3SumRate + "|" + drLength0Sum + "_" + drLength0SumRate
    val drLength0Count = drLength0List.length
    val drLength1Count = drLength1List.length
    val drLength3Count = drLength3List.length
    val drLengthCount = drLength0Count + drLength1Count + drLength3Count
    val drLength0CountRate = getRate(drLength0Count, drLengthCount)
    val drLength1CountRate = getRate(drLength1Count, drLengthCount)
    val drLength3CountRate = getRate(drLength3Count, drLengthCount)
    val rdynsdcnt = drLength1Count + "_" + drLength1CountRate + "|" + drLength3Count + "_" + drLength3CountRate + "|" + drLength0Count + "_" + drLength0CountRate

    val links = swids.mkString(",")
    json.put("links", links)
    json.put("linknum", links.length)
    json.put("rdynsdlen", rdynsdlen)
    json.put("rdynsdcnt", rdynsdcnt)
  }

  def getRate(v1: Int, v2: Int): String = {
    var result = ""
    try {
      result = df.format(v1.toDouble / v2.toDouble)
    } catch {
      case e: Exception => logger.error(">>>除法异常")
    }
    result
  }


  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val endDate1 = endDate //DateUtil.getDateStr(endDate,1)
    var sql = ""
    var logRdd: RDD[JSONObject] = null
    var table = ""
    if (subType.contains("Result") && (subType.contains("V2") || subType.contains("path"))) table = "gis_eta_navi_query_proto_hive"
    else table = "gis_eta_navi_query_hive"
    if (subType.contains(",")) {
      val subTypes = subType.split(",")
      val subType1 = subTypes(0)
      val subType2 = subTypes(1)
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate1'
           | and (get_json_object(data, '$$.subType') = '$subType1' or get_json_object(data, '$$.subType') = '$subType2')
       """.stripMargin
    }
    else {
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate1'
           | and get_json_object(data, '$$.subType') = '$subType'
       """.stripMargin
    }
    logger.error("执行的sql语句：" + sql)
    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x))
  }
}
