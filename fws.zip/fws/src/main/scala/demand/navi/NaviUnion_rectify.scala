package demand.navi

import com.alibaba.fastjson.{JSONArray, JSONObject}
import demand.utils._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 264942
 * @description: gis_navi_rectify_result 表7
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/2/2 11:00
 * 已废弃,新版在com.sf.gis.scala.navi.app.NaviUnion_rectify
 */
object NaviUnion_rectify {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 500
  var trackquery_url1 = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrate"
  var trackquery_url2 = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/query"
  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val rectify_url2 = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val compare_track_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"


  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getRectifyRdd
    computeRddF = null
    table = "gis_navi_rectify_result"
    structs = Array("navi_id", "vehicle", "vehicle_type", "weight", "mload", "length", "axle_number", "navi_starttime", "navi_endtime", "tracks1", "tracks2", "offtime_ratio", "stay_list", "len", "ret", "starttime_type")
    keys = Array("navi_id", "vehicle", "vehicle_type", "weight", "mload", "length", "axle_number", "navi_starttime", "navi_endtime", "tracks1", "tracks2", "offtime_ratio", "stay_list", "len", "ret", "starttime_type")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }


  /**
   * 解析日志主流程
   *
   * @param spark
   * @param getRddF
   * @param computeRddF
   * @param table
   * @param structs
   * @param keys
   * @param saveHiveRddF
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  /**
   * 获取纠偏结果数据
   *
   * @param spark
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def getRectifyRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    var dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    dateList += date
    var sql = ""
    val startDate = DateUtil.getDateStr(date, -1)
    val endDate = date
    sql =
      s"""
         |select a.navi_id,a.navi_starttime,a.starttime_type,a.navi_endtime,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,a.navi_type,b.req_time,a.inc_day,a.inc_day as inc_date from
         |(select task_id,navi_id,navi_starttime,starttime_type,navi_endtime,vehicle,vehicle_type,weight,mload,length,axle_number,navi_type,inc_day from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate' and status in ('1','2','3','10','13','14') and navi_starttime is not null and navi_starttime<>'' and navi_endtime is not null and navi_endtime<>'' group by task_id,navi_id,navi_starttime,starttime_type,navi_endtime,vehicle,vehicle_type,weight,mload,length,axle_number,navi_type,inc_day) a
         |left join (select task_id,navi_id,req_time from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate' and req_time is not null and req_time<>'' group by task_id,navi_id,req_time) b on a.task_id=b.task_id and a.navi_id=b.navi_id
       """.stripMargin

    val resultRdd = NaviLogParse.getValidJson(spark, sql).persist()
    logger.error(">>>日志量：" + resultRdd.count())

    val computeRdd = resultRdd
      .map(json => {
        //获取历史轨迹
        var tracks1_origin: JSONArray = null
        var req_time = ""
        var navi_endtime = ""
        val req_timel = json.getLong("req_time")
        if (req_timel != null) {
          req_time = longToTime(req_timel)
        }
        val navi_endtimel = json.getLong("navi_endtime")
        if (navi_endtimel != null) {
          navi_endtime = longToTime(navi_endtimel + 300000)
        }

        if (!StringUtils.isEmpty(req_time) && !StringUtils.isEmpty(navi_endtime)) {
          var flag = false
          val httpObject1 = accessTrackUrl1(json, req_time, navi_endtime)
          if (httpObject1 != null) {
            val result = httpObject1.getJSONObject("result")
            if (result != null) {
              val data = result.getJSONObject("data")
              if (data != null) {
                val track = data.getJSONArray("track")
                if (track != null && track.size() > 0) {
                  flag = true
                  tracks1_origin = data.getJSONArray("track")
                }
              }
            }
          }
          if (!flag) {
            val httpObject2 = accessTrackUrl2(json, req_time, navi_endtime)
            if (httpObject2 != null) {
              val result = httpObject2.getJSONObject("result")
              if (result != null) {
                val data = result.getJSONObject("data")
                if (data != null) {
                  tracks1_origin = data.getJSONArray("track")
                }
              }
            }
          }
        }

        var tracks1: JSONArray = new JSONArray()
        val tracks1_new = new JSONArray()
        if (tracks1_origin != null && tracks1_origin.size() > 0) {
          for (i <- 0.until(tracks1_origin.size())) {
            val tempJson = tracks1_origin.getJSONObject(i)
            val newJson1 = new JSONObject()
            val newJson2 = new JSONObject()
            if (tempJson != null) {
              val tp = tempJson.getInteger("tp")
              val x = tempJson.getDouble("zx")
              val y = tempJson.getDouble("zy")
              val ac = tempJson.getInteger("ac")
              val sp = tempJson.getDouble("sp")
              val be = tempJson.getDouble("be")
              val tm = tempJson.getInteger("tm")

              if (tp != null) newJson1.put("type", tp)
              if (x != null) newJson1.put("x", x)
              if (y != null) newJson1.put("y", y)
              if (ac != null) newJson1.put("accuracy", ac)
              if (sp != null) newJson1.put("speed", sp)
              if (be != null) newJson1.put("azimuth", be)
              if (tm != null) newJson1.put("time", tm)

              if (x != null) newJson2.put("x", x)
              if (y != null) newJson2.put("y", y)
              if (tm != null) newJson2.put("tm", tm)
            }

            newJson1.put("index", i)
            tracks1.add(newJson1)
            tracks1_new.add(newJson2)
          }
        }

        var tracks2_new = new ArrayBuffer[JSONObject]()
        val stayList = new JSONArray()
        var offTimeRatio = ""
        var len = ""
        var ret = ""

        var result: JSONObject = null
        if ("gdwl".equalsIgnoreCase(json.getString("navi_type"))) {
          result = accessRectifyUrl(json, tracks1)
        }
        else {
          result = accessRectifyUrl2(json, tracks1)
        }
        if (result != null) {
          val status = result.getInteger("status")
          //          if(status!=null && status==0){
          val resultObject = result.getJSONObject("result")
          if (resultObject != null) {
            val tracks2 = resultObject.getJSONArray("tracks")
            val stay_points = resultObject.getJSONArray("stay_points")
            offTimeRatio = resultObject.getString("offTimeRatio")
            len = resultObject.getString("len")
            ret = resultObject.getString("ret")
            if (tracks2 != null && tracks2.size() > 0) {
              for (i <- 0.until(tracks2.size())) {
                val track = tracks2.getJSONObject(i)
                if (track != null) {
                  val newJson = new JSONObject()
                  val x = track.getString("x")
                  val y = track.getString("y")
                  val tm = track.getString("time")
                  val sum_dist = track.getString("sum_dist")
                  val swid = track.getString("SWID")

                  newJson.put("x", x)
                  newJson.put("y", y)
                  newJson.put("tm", tm)
                  newJson.put("sum_dist", sum_dist)
                  newJson.put("swid", swid)
                  tracks2_new += newJson
                }
              }
            }
            if (stay_points != null && tracks2 != null) {
              if (stay_points.size() > 0) {
                for (i <- 0.until(stay_points.size())) {
                  val stay_point = stay_points.getJSONObject(i)
                  if (stay_point != null) {
                    val start_index = stay_point.getInteger("start_index")
                    val end_index = stay_point.getInteger("end_index")
                    val pois = stay_point.getJSONArray("pois")

                    val duration = stay_point.getString("duration")
                    var stayStartTime = ""
                    var stayStartLongitude = ""
                    var stayStartLatitude = ""
                    var stayEndTime = ""
                    var stayEndLongitude = ""
                    var stayEndLatitude = ""
                    var stayType = ""

                    if (start_index != null && start_index < tracks2.size()) {
                      val track = tracks2.getJSONObject(start_index)
                      if (track != null) {
                        stayStartTime = track.getString("time")
                        stayStartLongitude = track.getString("x")
                        stayStartLatitude = track.getString("y")
                      }
                    }

                    if (end_index != null && end_index < tracks2.size()) {
                      val track = tracks2.getJSONObject(end_index)
                      if (track != null) {
                        stayEndTime = track.getString("time")
                        stayEndLongitude = track.getString("x")
                        stayEndLatitude = track.getString("y")
                      }
                    }

                    if (pois != null && pois.size() > 0) {
                      val all_poi_types = new ArrayBuffer[String]()
                      breakable(
                        for (j <- 0.until(pois.size())) {
                          val poi = pois.getJSONObject(j)
                          if (poi != null) {
                            val _type = poi.getString("type")
                            if ("1".equalsIgnoreCase(_type) || "5".equalsIgnoreCase(_type)) {
                              stayType = "3"
                              break
                            }
                            if (!StringUtils.isEmpty(_type)) all_poi_types += _type
                          }
                        }
                      )
                      if (StringUtils.isEmpty(stayType)) {
                        val all_types = all_poi_types.toSet
                        if (all_types.contains("3")) stayType = "1"
                        else if (all_types.contains("2")) stayType = "2"
                        else stayType = "4"
                      }
                    }

                    val newJson = new JSONObject()
                    newJson.put("duration", duration)
                    newJson.put("stayStartTime", stayStartTime)
                    newJson.put("stayStartLongitude", stayStartLongitude)
                    newJson.put("stayStartLatitude", stayStartLatitude)
                    newJson.put("stayEndTime", stayEndTime)
                    newJson.put("stayEndLongitude", stayEndLongitude)
                    newJson.put("stayEndLatitude", stayEndLatitude)
                    newJson.put("stayType", stayType)

                    stayList.add(newJson)

                  }
                }
              }
            }
          }
          //          }
        }

        if (tracks1_new.size() > 0) json.put("tracks1", tracks1_new)
        if (tracks2_new.nonEmpty) {
          val tracks2_new2 = new JSONArray()
          val temp = tracks2_new.sortBy(j => j.getLong("tm"))
          temp.toList.foreach(j => {
            tracks2_new2.add(j)
          })
          json.put("tracks2", tracks2_new2)
        }
        json.put("offtime_ratio", offTimeRatio)
        if (stayList.size() > 0) json.put("stay_list", stayList)
        json.put("len", len)
        json.put("ret", ret)

        json
      })
      .persist()

    logger.error(">>>计算后日志量：" + computeRdd.count())

    resultRdd.unpersist()


    (computeRdd, dateList)
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }


  /**
   * 时间戳转换为时分秒
   *
   * @param date
   * @return
   */
  def dateToTimeStamp(date: String, format: String = "yyyyMMdd"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      val time = sdf.parse(date).getTime
      datetime = time.toString
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }


  /**
   * 访问比较轨迹接口
   *
   * @param json
   * @param tracks
   * @return
   */
  def accessRectifyUrl(json: JSONObject, tracks: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("vehicle", vehicle_type)
    param.put("retflag", 7)
    param.put("addpoint", 1)
    param.put("poiinfo", 1)
    param.put("tracks", tracks)

    val vehicleInfo = new JSONObject()
    val mload = json.getString("mload")
    if (!StringUtils.isEmpty(mload)) vehicleInfo.put("load", mload)
    val axle_number = json.getString("axle_number")
    if (!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis", axle_number)
    val weight = json.getDouble("weight")
    if (weight != null) vehicleInfo.put("weight", weight)
    val length = json.getDouble("length")
    if (length != null) vehicleInfo.put("length", length)

    param.put("vehicleInfo", vehicleInfo)
    param.put("roadinfo", 1)
    param.put("mat_ratio", 1)

    val process = new JSONObject()
    process.put("stay_time", 180)
    process.put("poi_range", 500)

    param.put("process", process)

    //    println("参数：" + param.toString)
    http_result = HttpClientUtil.getJsonByPostJson(rectify_url, param.toString)
    Thread.sleep(600)

    http_result
  }


  /**
   * 访问比较轨迹接口
   *
   * @param json
   * @param tracks1
   * @param tracks2
   * @return
   */
  def accessCompareUrl(json: JSONObject, tracks1: JSONArray, tracks2: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("vehicle", vehicle_type)

    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("retflag", 5)
    param.put("tracktype", 0)
    param.put("tracks1", tracks1)
    param.put("tracks2", tracks2)
    http_result = HttpClientUtil.getJsonByPostJson(compare_track_url, param.toString)
    Thread.sleep(600)
    http_result
  }

  def accessRectifyUrl2(json: JSONObject, tracks: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("vehicle", vehicle_type)
    param.put("retflag", 7)
    param.put("addpoint", 1)
    param.put("poiinfo", 1)
    param.put("tracks", tracks)

    val vehicleInfo = new JSONObject()
    val mload = json.getString("mload")
    if (!StringUtils.isEmpty(mload)) vehicleInfo.put("load", mload)
    val axle_number = json.getString("axle_number")
    if (!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis", axle_number)
    val weight = json.getDouble("weight")
    if (weight != null) vehicleInfo.put("weight", weight)
    val length = json.getDouble("length")
    if (length != null) vehicleInfo.put("length", length)

    param.put("vehicleInfo", vehicleInfo)
    param.put("roadinfo", 1)
    param.put("mat_ratio", 1)

    val process = new JSONObject()
    process.put("stay_time", 180)
    process.put("poi_range", 500)

    param.put("process", process)

    //    println("参数：" + param.toString)
    http_result = HttpClientUtil.getJsonByPostJson(rectify_url2, param.toString)
    Thread.sleep(600)

    http_result
  }


  def accessTrackUrl1(json: JSONObject, req_time: String, navi_endtime: String): JSONObject = {
    var http_result: JSONObject = null
    val param = new JSONObject()
    param.put("un", json.getString("vehicle"))
    if (req_time != null) param.put("beginDateTime", req_time.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    if (navi_endtime != null) param.put("endDateTime", navi_endtime.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    param.put("type", 0)
    param.put("rectify", false)
    param.put("ak", "e640de2b47394b19862ee134d817bbc7")
    param.put("hasRate", true)
    http_result = HttpClientUtil.getJsonByPostJson(trackquery_url1, param.toString)
    Thread.sleep(3000)
    http_result
  }


  def accessTrackUrl2(json: JSONObject, req_time: String, navi_endtime: String): JSONObject = {
    var http_result: JSONObject = null
    val param = new JSONObject()
    param.put("un", json.getString("vehicle"))
    if (req_time != null) param.put("beginDateTime", req_time.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    if (navi_endtime != null) param.put("endDateTime", navi_endtime.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    param.put("type", 400)
    param.put("rectify", false)
    param.put("ak", "e640de2b47394b19862ee134d817bbc7")
    param.put("hasRate", true)
    //    println("-------------json-------" + json)
    http_result = HttpClientUtil.getJsonByPostJson(trackquery_url2, param.toString)
    Thread.sleep(3000)
    http_result
  }
}
