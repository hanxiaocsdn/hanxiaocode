package demand.navi

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import common.SourceAndDiskCommon
import demand.utils.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 349010
 * @description: Navi解析ms	gis_navi_pns_route
 * @demander:80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/11/17 17:26
 */
object NaviParse_MsNaviLogN extends SourceAndDiskCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    try {
      result.fluentPutAll(result.getJSONObject("data"))
    } catch {
      case e: Exception => logger.error("原始数据中无该目录>>>>>>>>" + e.getMessage)
    }
    result.keySet().toArray.foreach(key => {
      if (result.get(key.toString).isInstanceOf[JSONObject]) {
        val temp = result.getJSONObject(key.toString)
        temp.keySet().toArray.foreach(k => {
          result.put(k.toString.toLowerCase, temp.getString(k.toString))
        })
      }
    })
    "resultstatus,status"
      .split(";").foreach(x => result.put(x.split(",")(0), result.getString(x.split(",")(1))))
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value

  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      ParseLog(spark, DateUtil.getYesterday)
    } else if (args.length == 1) {
      //传入参数，单天任务
      ParseLog(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    var runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getMsNaviLogRdd
    computeRddF = null
    table = "gis_navi_pns_route"

    structs = Array("pns_logtype", "request_id", "req_time", "no", "origin", "destination", "route_index", "route_id", "distance", "polyline", "links", "strategy", "src", "status")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)
  }

  /**
   * 获取定点加油日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getMsNaviLogRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = "msNaviLog"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    val computeRdd = validRdd.flatMap(json => {
      val list = new ArrayBuffer[JSONObject]()
      if (json != null) {
        var inc_day, pns_logtype, request_id, no, origin, destination, route_id, src, status = ""
        var req_time: java.lang.Long = null
        pns_logtype = json.getString("pnsNaviLogType")
        request_id = json.getString("requestId")
        req_time = json.getLong("reqTime")
        if (req_time != null) {
          inc_day = longToTime(req_time).split(" ")(0).replaceAll("-", "")
        }
        no = json.getString("no")

        val result = json.getJSONObject("result")
        if (result != null) {
          status = result.getString("status")
          val routes = result.getJSONObject("routes")
          if (routes != null) {
            origin = routes.getString("origin")
            destination = routes.getString("destination")
            val pathes = routes.getJSONArray("pathes")
            if (pathes != null && pathes.size() > 0) {
              val path0 = pathes.getJSONObject(0)
              if (path0 != null) {
                route_id = path0.getString("id")
                src = path0.getString("src")
              }
              if (StringUtils.isEmpty(inc_day)) inc_day = ""
              if (StringUtils.isEmpty(pns_logtype)) pns_logtype = ""
              if (StringUtils.isEmpty(request_id)) request_id = ""
              if (StringUtils.isEmpty(no)) no = ""
              if (StringUtils.isEmpty(origin)) origin = ""
              if (StringUtils.isEmpty(destination)) destination = ""
              if (StringUtils.isEmpty(route_id)) route_id = ""
              if (StringUtils.isEmpty(src)) src = ""
              if (StringUtils.isEmpty(status)) status = ""

              for (i <- 0.until(pathes.size())) {
                val path = pathes.getJSONObject(i)
                if (path != null) {
                  val newJson = new JSONObject()
                  newJson.put("inc_day", inc_day)
                  newJson.put("pnslogtype", pns_logtype)
                  newJson.put("requestid", request_id)
                  if (req_time != null) newJson.put("reqtime", req_time)
                  newJson.put("no", no)
                  newJson.put("origin", origin)
                  newJson.put("destination", destination)
                  newJson.put("routeindex", i)
                  newJson.put("routeid", route_id)
                  newJson.put("src", src)
                  newJson.put("status", status)

                  val distance = path.getString("distance")
                  if (distance != null) newJson.put("distance", distance)

                  val links = path.getString("swidList")
                  if (links != null) newJson.put("links", links)

                  val strategy = path.getString("strategy")
                  if (strategy != null) newJson.put("strategy", strategy)

                  val polylineX = path.getJSONArray("polylineX")
                  val polylineY = path.getJSONArray("polylineY")
                  handlePolyline(newJson, polylineX, polylineY)

                  list += newJson
                }
              }
            }
          }
        }
      }
      list
    }).repartition(600).persist()
    computeRdd.take(1)
    validRdd.unpersist()
    computeRdd
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  /**
   * 处理polyline数据
   *
   * @param json
   */
  def handlePolyline(json: JSONObject, polylineX: JSONArray, polylineY: JSONArray): Unit = {
    val polyline = new JSONArray()

    var x: java.lang.Long = 0l
    var y: java.lang.Long = 0l

    if (polylineX != null && polylineY != null && polylineX.size() > 0 && polylineX.size() <= polylineY.size()) {
      for (i <- 0.until(polylineX.size())) {
        val X = polylineX.getLong(i)
        val Y = polylineY.getLong(i)
        x = x + X
        y = y + Y
        val tmpX = x.toDouble / 3600000
        val tmpY = y.toDouble / 3600000
        val xy = new JSONObject()
        xy.put("x", tmpX)
        xy.put("y", tmpY)
        polyline.add(xy)
      }
    }

    if (polyline != null && polyline.size() > 0) json.put("polyline", polyline)
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    var sql = ""
    val table = "gis_eta_ms_navi_hive"
    sql =
      s"""
         |select data,inc_day from dm_gis.$table t
         | where inc_day between '$startDate' and '$endDate'
       """.stripMargin

    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x))
  }

}
