package demand.navi

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import demand.utils._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer
import scala.util.Random
import scala.util.control.Breaks.{break, breakable}

/**
 * Created by 01368978 on 2021/5/28.
 * 作废，迁移至com.sf.gis.scala.navi.app.NaviUnion_etaresult2 迁移时间20230329 迁移人01374443
 *
 */
object NaviUnion_etaresult2 {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 50
  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val compare_track_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"


  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }

    spark.stop()
    logger.error(">>>处理完毕---------------")
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getEtaResult2Rdd
    computeRddF = null
    table = "gis_navi_eta_result2"
    //    table = "table82"
    structs = Array("id", "task_id", "navi_id", "routeid", "request_id", "navi_starttime", "starttime_type", "req_time", "navi_endtime", "req_type", "src_province", "src_citycode", "src_deptcode", "dest_province", "dest_citycode", "dest_deptcode", "swid", "starts", "polyline", "links", "links2", "tracks1", "tracks2", "navi_distance", "similarity1", "similarity5", "t1", "yaw_time", "trackstart_distance", "trackend_distance", "gd_polyline", "gdsimilarity1", "gdsimilarity5", "yaw_time2",
      "start_dept", "end_dept", "vehicle_type_navi", "stdmatchtype", "passzonetype", "cachestdid",
      "linerequireid", "passzonetableid", "cachestdblockroad",
      "nostdreasontype", "nostdreasondetail")
    keys = Array("id", "task_id", "navi_id", "routeid", "request_id", "navi_starttime", "starttime_type", "req_time", "navi_endtime", "req_type", "src_province", "src_citycode", "src_deptcode", "dest_province", "dest_citycode", "dest_deptcode", "swid", "starts", "polyline", "links", "links2", "tracks1", "tracks2", "navi_distance", "similarity1", "similarity5", "t1", "yaw_time", "trackstart_distance", "trackend_distance", "gd_polyline", "gdsimilarity1", "gdsimilarity5", "yaw_time2",
      "start_dept", "end_dept", "vehicle_type_navi", "stdmatchtype", "passzonetype", "cachestdid",
      "linerequireid", "passzonetableid", "cachestdblockroad",
      "nostdreasontype", "nostdreasondetail")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }


  /**
   * 解析日志主流程
   *
   * @param spark
   * @param getRddF
   * @param computeRddF
   * @param table
   * @param structs
   * @param keys
   * @param saveHiveRddF
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }


  /**
   * 获取ETA结果汇总2
   *
   * @param spark
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def getEtaResult2Rdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    var dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    var runDate = ""
    if ("1".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = date
      }
      else {
        runDate = date
      }
      dateList += runDate
    }
    else if ("3".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = DateUtil.getDateStr(date, -1)
      }
      else {
        runDate = date
      }
      //      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
      //      dateList = DateUtil.getTwoDatesStr(startDate,runDate)
      dateList += runDate
    }

    logger.error(">>>获取" + runDate + "号的ETA结果汇总")
    var sql = ""
    var sql2 = ""

    if ("1".equalsIgnoreCase(runType)) {
      sql =
        s"""
           |select a.task_id,a.navi_id,a.navi_starttime,a.starttime_type,a.routeid,a.request_id,a.req_time,a.req_type,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.swid,a.starts,a.polyline,a.gd_polyline,a.links,a.x1,a.y1,a.x2,a.y2,a.navi_endtime2,b.navi_endtime,a.inc_day,a.inc_date from
           |(select task_id,navi_id,navi_starttime,starttime_type,routeid,request_id,req_time,'top3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,starts,polyline,gd_polyline,links,x1,y1,x2,y2,'' as navi_endtime2,inc_day,inc_day as inc_date,
           | start_dept,end_dept,vehicle_type_navi,
           | stdmatchtype,passzonetype,cachestdid,
           | linerequireid,passzonetableid,cachestdblockroad,
           | nostdreasontype,nostdreasondetail
           | from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' union all
           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'yaw' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,swid,starts,polyline,'' as gd_polyline,links,x1,y1,x2,y2,'' as navi_endtime2,inc_day,inc_day as inc_date,
           |'' start_dept,
           |'' end_dept,
           |'' vehicle_type_navi,
           |'' stdmatchtype,
           |'' passzonetype,
           |'' cachestdid,
           |'' linerequireid,
           |'' passzonetableid,
           |'' cachestdblockroad,
           |'' nostdreasontype,
           |'' nostdreasondetail
           | from dm_gis.gis_navi_yaw_route where inc_day='$runDate' and hasyaw='true' union all
           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'gdtop3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,'' as starts,polyline,'' as gd_polyline,'' as links,x1,y1,x2,y2,navi_endtime as navi_endtime2,inc_day,inc_day as inc_date,
           |'' start_dept,
           |'' end_dept,
           |'' vehicle_type_navi,
           |'' stdmatchtype,
           |'' passzonetype,
           |'' cachestdid,
           |'' linerequireid,
           |'' passzonetableid,
           |'' cachestdblockroad,
           |'' nostdreasontype,
           |'' nostdreasondetail
           | from dm_gis.gis_navi_gd_route_eta where inc_day='$runDate') a
           |left join (select navi_id,max(navi_endtime) as navi_endtime from dm_gis.gis_navi_finish_monitor where inc_day='$runDate' group by navi_id) b on a.navi_id=b.navi_id
       """.stripMargin

      sql2 =
        s"""
           |select navi_id,tracks1,tracks2 from dm_gis.gis_navi_rectify_result where inc_day='$runDate' and navi_id is not null and trim(navi_id) !=''
       """.stripMargin
    }
    else if ("3".equalsIgnoreCase(runType)) {
      val startDate = runDate //DateUtil.getDateStr(runDate,-1)//2
      val endDate = runDate
      val endDate1 = DateUtil.getDateStr(runDate, 1)
      sql =
        s"""
           |select a.task_id,a.navi_id,a.navi_starttime,a.starttime_type,a.routeid,a.request_id,a.req_time,a.req_type,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.swid,a.starts,a.polyline,a.gd_polyline,a.links,a.x1,a.y1,a.x2,a.y2,a.navi_endtime2,b.navi_endtime,a.inc_day,a.inc_date,start_dept,end_dept,vehicle_type_navi,
           |      stdmatchtype,passzonetype,cachestdid,
           |      linerequireid,passzonetableid,cachestdblockroad,
           |      nostdreasontype,nostdreasondetail from
           |(select task_id,navi_id,navi_starttime,starttime_type,routeid,request_id,req_time,'top3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,starts,polyline,gd_polyline,links,x1,y1,x2,y2,'' as navi_endtime2,inc_day,inc_day as inc_date,
           | start_dept,end_dept,vehicle_type_navi,
           |      stdmatchtype,passzonetype,cachestdid,
           |      linerequireid,passzonetableid,cachestdblockroad,
           |      nostdreasontype,nostdreasondetail
           | from dm_gis.gis_navi_top3_click_route where inc_day between '$startDate' and '$endDate' union all
           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'yaw' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,swid,starts,polyline,'' as gd_polyline,links,x1,y1,x2,y2,'' as navi_endtime2,inc_day,inc_day as inc_date,
           |  '' start_dept,
           |'' end_dept,
           |'' vehicle_type_navi,
           |'' stdmatchtype,
           |'' passzonetype,
           |'' cachestdid,
           |'' linerequireid,
           |'' passzonetableid,
           |'' cachestdblockroad,
           |'' nostdreasontype,
           |'' nostdreasondetail
           |from dm_gis.gis_navi_yaw_route where inc_day between '$startDate' and '$endDate' union all
           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'gdtop3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,'' as starts,polyline,'' as gd_polyline,'' as links,x1,y1,x2,y2,navi_endtime as navi_endtime2,inc_day,inc_day as inc_date,
           |   '' start_dept,
           |'' end_dept,
           |'' vehicle_type_navi,
           |'' stdmatchtype,
           |'' passzonetype,
           |'' cachestdid,
           |'' linerequireid,
           |'' passzonetableid,
           |'' cachestdblockroad,
           |'' nostdreasontype,
           |'' nostdreasondetail
           |from dm_gis.gis_navi_gd_route_eta where inc_day between '$startDate' and '$endDate') a
           |left join (select navi_id,max(navi_endtime) as navi_endtime from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate' group by navi_id) b on a.navi_id=b.navi_id
       """.stripMargin

      sql2 =
        s"""
           |select navi_id,tracks1,tracks2 from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate' and navi_id is not null and trim(navi_id) !=''
       """.stripMargin
    }

    val rdd1 = NaviLogParse.getValidJson(spark, sql)
    val rdd2 = NaviLogParse.getValidJson(spark, sql2)

    val resultRdd1 = rdd1.filter(json => !"0be66d610d0490ae0ab70ad1d940cf191".equalsIgnoreCase(json.getString("nava_id"))
      && !"27feba4b90f68ff3e7e6a8af9808b4661".equalsIgnoreCase(json.getString("nava_id"))
      && !"b03d83ec5110b93b153e1509ee13d6420".equalsIgnoreCase(json.getString("nava_id")))
      .map(json => {
        var navi_id = json.getString("navi_id")
        var request_id = json.getString("request_id")
        var req_time = json.getLong("req_time")
        if (StringUtils.isEmpty(navi_id)) navi_id = "-"
        if (StringUtils.isEmpty(request_id)) request_id = "-"
        if (req_time == null) req_time = Long.MaxValue

        val id = navi_id + "_" + request_id + "_" + req_time.toString
        json.put("id", id)

        if ("gdtop3".equalsIgnoreCase(json.getString("req_type"))) {
          var navi_endtime2 = json.getString("navi_endtime2")
          if (StringUtils.isEmpty(navi_endtime2)) navi_endtime2 = ""
          json.put("navi_endtime", navi_endtime2)
        }
        (id, json)
      })
      .groupByKey()
      .map(obj => {
        val json = obj._2.toList.head
        json
      })
      .map(json => {
        var navi_id = json.getString("navi_id")

        if (StringUtils.isEmpty(navi_id)) navi_id = "-"

        val polyline = json.getString("polyline")
        var polyline_array: JSONArray = null
        if (!StringUtils.isEmpty(polyline)) polyline_array = JSON.parseArray(polyline)
        val polyline_new = new JSONArray()
        json.remove("polyline")
        if (polyline_array != null && polyline_array.size() > 0) {
          for (j <- 0.until(polyline_array.size())) {
            val track = polyline_array.getJSONObject(j)
            val tmp = new JSONArray()
            if (track != null) {
              val x = track.getDouble("x")
              val y = track.getDouble("y")
              if (x != null && y != null) {
                tmp.add(x)
                tmp.add(y)
                polyline_new.add(tmp)
              }
            }
          }
          json.put("polyline", polyline_new)
        }

        val gd_polyline = json.getString("gd_polyline")
        var gd_polyline_array: JSONArray = null
        if (!StringUtils.isEmpty(gd_polyline)) gd_polyline_array = JSON.parseArray(gd_polyline)
        val gd_polyline_new = new JSONArray()
        json.remove("gd_polyline")
        if (gd_polyline_array != null && gd_polyline_array.size() > 0) {
          for (j <- 0.until(gd_polyline_array.size())) {
            val track = gd_polyline_array.getJSONObject(j)
            val tmp = new JSONArray()
            if (track != null) {
              val x = track.getDouble("x")
              val y = track.getDouble("y")
              if (x != null && y != null) {
                tmp.add(x)
                tmp.add(y)
                gd_polyline_new.add(tmp)
              }
            }
          }
          json.put("gd_polyline", gd_polyline_new)
        }
        if (json.getLong("req_time") == null) json.put("req_time", Long.MaxValue)

        (navi_id, json)
      })
      .groupByKey()

    val resultRdd2 = rdd2
      .map(json => {
        var navi_id = json.getString("navi_id")
        if (StringUtils.isEmpty(navi_id)) navi_id = "-"

        (navi_id, json)
      }).filter(r => r._1 != "-" && r._1 != "")
      .map(obj => {
        val navi_id = Random.nextInt(9).toString + "_" + obj._1
        val json = obj._2
        (navi_id, json)
      }).groupByKey()
      .map(obj => {
        val json = obj._2.head
        val navi_id = obj._1
        (navi_id, json)
      }).map(x => {
      val navi_id = x._1.split("_")(1)
      val value = x._2
      (navi_id, value)
    }).groupByKey()
      .map(obj => {
        val json = obj._2.head
        val navi_id = obj._1
        (navi_id, json)
      })

    val computeRdd1 = resultRdd1.leftOuterJoin(resultRdd2)
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()

        val jsonList: List[JSONObject] = obj._2._1.toList.sortBy(js => js.getLong("req_time"))
        var targetJson: JSONObject = null
        if (obj._2._2.nonEmpty) {
          targetJson = obj._2._2.get
        }
        var tracks1: JSONArray = null
        var tracks2: JSONArray = null
        if (targetJson != null) {
          tracks1 = targetJson.getJSONArray("tracks1")
          tracks2 = targetJson.getJSONArray("tracks2")
          targetJson.remove("tracks1")
          targetJson.remove("tracks2")
        }

        for (i <- jsonList.indices) {
          val json = jsonList(i)

          val req_time = json.getLong("req_time")
          val navi_endtime = json.getLong("navi_endtime")

          val tracks1_new = new JSONArray()
          if (tracks1 != null && tracks1.size() > 0 && req_time != null && navi_endtime != null) {
            var diff_min1 = Long.MaxValue
            var diff_min2 = Long.MaxValue
            var index1 = -1
            var index2 = -1
            breakable(
              for (j <- 0.until(tracks1.size())) {
                val track = tracks1.getJSONObject(j)
                if (track != null) {
                  val tm = track.getLong("tm")
                  if (tm != null) {
                    val diff = Math.abs(req_time - tm * 1000)
                    if (diff <= diff_min1) {
                      diff_min1 = diff
                      index1 = j
                    }
                  }
                }
              }
            )

            breakable(
              for (j <- 0.until(tracks1.size())) {
                val track = tracks1.getJSONObject(tracks1.size() - j - 1)
                if (track != null) {
                  val tm = track.getLong("tm")
                  if (tm != null) {
                    val diff = Math.abs(navi_endtime - tm * 1000)
                    if (diff <= diff_min2) {
                      diff_min2 = diff
                      index2 = tracks1.size() - j - 1
                    }
                  }
                }
              }
            )

            if (index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks1.size()) {
              for (j <- index1.until(index2 + 1)) {
                val track = tracks1.getJSONObject(j)
                val tmp = new JSONArray()
                if (track != null) {
                  val x = track.getDouble("x")
                  val y = track.getDouble("y")
                  if (x != null && y != null) {
                    tmp.add(x)
                    tmp.add(y)
                    tracks1_new.add(tmp)
                  }
                }
              }
            }
            if (tracks1_new.size() > 0) json.put("tracks1", tracks1_new)
          }

          var navi_distance: java.lang.Double = null
          val tracks2_new = new JSONArray()
          if (tracks2 != null && tracks2.size() > 0 && req_time != null && navi_endtime != null) {
            var diff_min1 = Long.MaxValue
            var diff_min2 = Long.MaxValue
            var index1 = -1
            var index2 = -1
            breakable(
              for (j <- 0.until(tracks2.size())) {
                val track = tracks2.getJSONObject(j)
                if (track != null) {
                  val tm = track.getLong("tm")
                  if (tm != null) {
                    val diff = Math.abs(req_time - tm * 1000)
                    if (diff <= diff_min1) {
                      diff_min1 = diff
                      index1 = j
                    }
                  }
                }
              }
            )

            breakable(
              for (j <- 0.until(tracks2.size())) {
                val track = tracks2.getJSONObject(tracks2.size() - j - 1)
                if (track != null) {
                  val tm = track.getLong("tm")
                  if (tm != null) {
                    val diff = Math.abs(navi_endtime - tm * 1000)
                    if (diff <= diff_min2) {
                      diff_min2 = diff
                      index2 = tracks2.size() - j - 1
                    }
                  }
                }
              }
            )

            val x1 = json.getDouble("x1")
            val y1 = json.getDouble("y1")
            if (index1 != -1 && index1 < tracks2.size() && x1 != null && y1 != null) {
              val track1 = tracks2.getJSONObject(index1)
              if (track1 != null) {
                val x = track1.getDouble("x")
                val y = track1.getDouble("y")
                if (x != null && y != null) {
                  val trackstart_distance = MapApiUtil.getGreatCircleDistance(x, y, x1, y1)
                  json.put("trackstart_distance", trackstart_distance)
                }
              }
            }

            val x2 = json.getDouble("x2")
            val y2 = json.getDouble("y2")
            if (index2 != -1 && index2 < tracks2.size() && x2 != null && y2 != null) {
              val track2 = tracks2.getJSONObject(index2)
              if (track2 != null) {
                val x = track2.getDouble("x")
                val y = track2.getDouble("y")
                if (x != null && y != null) {
                  val trackend_distance = MapApiUtil.getGreatCircleDistance(x, y, x2, y2)
                  json.put("trackend_distance", trackend_distance)
                }
              }
            }

            if (index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks2.size()) {
              val track1 = tracks2.getJSONObject(index1)
              val track2 = tracks2.getJSONObject(index2)
              if (track1 != null && track2 != null) {
                val sum_dist1 = track1.getDouble("sum_dist")
                val sum_dist2 = track2.getDouble("sum_dist")
                if (sum_dist1 != null && sum_dist2 != null) {
                  navi_distance = sum_dist2 - sum_dist1
                }
              }
              var swid = ""
              var links2 = new JSONArray()
              val req_type = json.getString("req_type")
              var type_flag = false
              if ("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)) type_flag = true

              for (j <- index1.until(index2 + 1)) {
                val track = tracks2.getJSONObject(j)
                val tmp = new JSONArray()
                if (track != null) {
                  val x = track.getDouble("x")
                  val y = track.getDouble("y")
                  if (x != null && y != null) {
                    tmp.add(x)
                    tmp.add(y)
                    tracks2_new.add(tmp)
                  }
                }

                if (type_flag) {
                  val _swid = track.getString("swid")
                  if (!swid.equalsIgnoreCase(_swid) && !StringUtils.isEmpty(_swid)) {
                    swid = _swid
                    val tmpTrack = new JSONObject()
                    tmpTrack.put("swid", swid)
                    val tm = track.getString("tm")
                    if (!StringUtils.isEmpty(tm)) tmpTrack.put("tm", tm + "000")
                    links2.add(tmpTrack)
                  }
                }
              }

              if (type_flag) {
                if (links2.size() > 0) {
                  json.put("links2", links2)
                  if (json.containsKey("links") && !StringUtils.isEmpty(json.getString("links"))) {
                    val links = json.getString("links").split(",")
                    val size1 = links.size
                    val size2 = links2.size()
                    var size = 0
                    if (size1 > size2) size = size2
                    else size = size1

                    if (size >= 3) {
                      breakable(
                        for (m <- 0.until(size - 2)) {
                          val link = links(m)
                          val link2 = links2.getJSONObject(m)
                          var swid = ""
                          var tm = "0"

                          val link_next = links(m + 1)
                          val link2_next = links2.getJSONObject(m + 1)
                          var swid_next = ""

                          val link_next2 = links(m + 2)
                          val link2_next2 = links2.getJSONObject(m + 2)
                          var swid_next2 = ""

                          if (link2 != null) {
                            swid = link2.getString("swid")
                            tm = link2.getString("tm")
                          }
                          if (link2_next != null) {
                            swid_next = link2_next.getString("swid")
                          }
                          if (link2_next2 != null) {
                            swid_next2 = link2_next2.getString("swid")
                          }

                          if (((!StringUtils.isEmpty(link) && !link.equalsIgnoreCase(swid)) || (StringUtils.isEmpty(link) && !StringUtils.isEmpty(swid))) &&
                            ((!StringUtils.isEmpty(link_next) && !link_next.equalsIgnoreCase(swid_next)) || (StringUtils.isEmpty(link_next) && !StringUtils.isEmpty(swid_next))) &&
                            ((!StringUtils.isEmpty(link_next2) && !link_next2.equalsIgnoreCase(swid_next2)) || (StringUtils.isEmpty(link_next2) && !StringUtils.isEmpty(swid_next2)))) {
                            json.put("t1", tm)
                          }
                          else json.put("t1", "0")
                        }
                      )

                    }
                    else json.put("t1", "0")
                  }
                  else json.put("t1", "0")
                }
                else json.put("t1", "0")
              }
            }
            if (tracks2_new.size() > 0) json.put("tracks2", tracks2_new)
          }

          if (navi_distance != null) json.put("navi_distance", navi_distance)

          list += json
        }

        for (i <- list.indices) {
          if (i > 0) {
            val j1 = list(i - 1)
            val j2 = list(i)
            if (j1 != null && j2 != null) {
              val req_time = j2.getLong("req_time")
              val links2 = j2.getJSONArray("links2")
              val links2_1 = j1.getJSONArray("links2")
              val links_1 = j1.getString("links")
              if (req_time != null && links2 != null && links2.size() > 0 && links2_1 != null && links2_1.size() > 0 && links2.getJSONObject(0) != null && !StringUtils.isEmpty(links2.getJSONObject(0).getString("swid"))) {
                val swid0 = links2.getJSONObject(0).getString("swid")
                var match_flag = false
                var tm0: java.lang.Long = null
                var tm: java.lang.Long = null
                breakable(
                  for (m <- 0.until(links2_1.size())) {
                    val link = links2_1.getJSONObject(links2_1.size() - 1 - m)

                    var link_next: JSONObject = null
                    if (m == 0) link_next = link
                    else link_next = links2_1.getJSONObject(links2_1.size() - m)

                    if (link != null) {
                      val swid_tmp = link.getString("swid")
                      if (!match_flag && swid0.equalsIgnoreCase(swid_tmp)) {
                        match_flag = true
                        if (link_next != null) tm0 = link_next.getLong("tm")
                      }
                      if (match_flag) {
                        if (!StringUtils.isEmpty(links_1) && links_1.contains(swid_tmp)) {
                          if (link_next != null) {
                            val tm_tmp = link_next.getLong("tm")
                            if (tm_tmp != null) {
                              tm = tm_tmp
                            }
                          }
                        }
                      }
                    }
                  }
                )
                var yaw_time2: java.lang.Long = null
                if (tm != null) {
                  yaw_time2 = req_time - tm
                }
                if (yaw_time2 != null) {
                  if (yaw_time2 < 0) yaw_time2 = 0l
                  j2.put("yaw_time2", yaw_time2)
                }
              }
            }
          }
        }


        list
      })
      .persist()
    logger.error(">>>计算相似度后日志量：" + computeRdd1.count())
    rdd1.unpersist()
    rdd2.unpersist()

    val computeRdd2 = computeRdd1
      .map(json => {
        if (json != null) {
          val tracks2_new = json.getJSONArray("tracks2")
          val polyline_new = json.getJSONArray("polyline")
          val gd_polyline_new = json.getJSONArray("gd_polyline")

          if (true) { //"0".equalsIgnoreCase(req_status)
            if (polyline_new != null && polyline_new.size() > 0 && tracks2_new != null && tracks2_new.size() > 0) {

              val polyline_new2 = new JSONArray()
              for (i <- 0.until(polyline_new.size())) {
                val track = polyline_new.getJSONArray(i)
                if (track != null) {
                  val x = track.getDouble(0)
                  val y = track.getDouble(1)
                  if (x != null && y != null) {
                    val newJson = new JSONObject()
                    newJson.put("x", x)
                    newJson.put("y", y)
                    newJson.put("type", 1)
                    polyline_new2.add(newJson)
                  }
                }
              }

              val tracks2_new2 = new JSONArray()
              for (i <- 0.until(tracks2_new.size())) {
                val track = tracks2_new.getJSONArray(i)
                if (track != null) {
                  val x = track.getDouble(0)
                  val y = track.getDouble(1)
                  if (x != null && y != null) {
                    val newJson = new JSONObject()
                    newJson.put("x", x)
                    newJson.put("y", y)
                    newJson.put("type", 1)
                    tracks2_new2.add(newJson)
                  }
                }
              }

              val resultObject = accessCompareUrl(json, polyline_new2, tracks2_new2)
              if (resultObject != null) {
                val resultObject2 = resultObject.getJSONObject("result")
                if (resultObject2 != null) {
                  val similarity1 = resultObject2.getDouble("similarity1")
                  val similarity2 = resultObject2.getDouble("similarity2")
                  json.put("similarity1", similarity1)
                  json.put("similarity5", similarity2)
                }
              }

            }

            if (gd_polyline_new != null && gd_polyline_new.size() > 0 && tracks2_new != null && tracks2_new.size() > 0) {

              val gd_polyline_new2 = new JSONArray()
              for (i <- 0.until(gd_polyline_new.size())) {
                val track = gd_polyline_new.getJSONArray(i)
                if (track != null) {
                  val x = track.getDouble(0)
                  val y = track.getDouble(1)
                  if (x != null && y != null) {
                    val newJson = new JSONObject()
                    newJson.put("x", x)
                    newJson.put("y", y)
                    newJson.put("type", 1)
                    gd_polyline_new2.add(newJson)
                  }
                }
              }

              val tracks2_new2 = new JSONArray()
              for (i <- 0.until(tracks2_new.size())) {
                val track = tracks2_new.getJSONArray(i)
                if (track != null) {
                  val x = track.getDouble(0)
                  val y = track.getDouble(1)
                  if (x != null && y != null) {
                    val newJson = new JSONObject()
                    newJson.put("x", x)
                    newJson.put("y", y)
                    newJson.put("type", 1)
                    tracks2_new2.add(newJson)
                  }
                }
              }

              val resultObject = accessCompareUrl(json, gd_polyline_new2, tracks2_new2)
              if (resultObject != null) {
                val resultObject2 = resultObject.getJSONObject("result")
                if (resultObject2 != null) {
                  val similarity1 = resultObject2.getDouble("similarity1")
                  val similarity2 = resultObject2.getDouble("similarity2")
                  json.put("gdsimilarity1", similarity1)
                  json.put("gdsimilarity5", similarity2)
                }
              }

            }
          }
        }

        json
      })
      .persist()
    logger.error(">>>计算相似度后日志量：" + computeRdd2.count())
    computeRdd1.unpersist()

    val resultRdd = computeRdd2
      .map(json => {
        val task_id = json.getString("task_id")
        val navi_id = json.getString("navi_id")
        var req_time = json.getLong("req_time")

        if (req_time == null) req_time = Long.MaxValue

        ((task_id, navi_id), (req_time, json))
      })
      .groupByKey()
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()
        val key = obj._1
        val jsonList = obj._2.toList.sortBy(_._1).map(_._2)

        var t1: java.lang.Long = null
        for (i <- jsonList.indices) {
          val json = jsonList(i)
          if (json != null) {
            val req_type = json.getString("req_type")
            if ("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)) {
              val req_time = json.getLong("req_time")
              if (req_time != null) {
                if (t1 != null) {
                  val yaw_time = Math.abs(req_time - t1)
                  if (yaw_time <= 5 * 60 * 1000) json.put("yaw_time", yaw_time)
                  else json.put("yaw_time", yaw_time)
                  //                  else json.put("yaw_time","0")
                  t1 = json.getLong("t1")
                }
                else {
                  json.put("yaw_time", "0")
                  t1 = json.getLong("t1")
                }
              }
              else {
                json.put("yaw_time", "0")
                t1 = json.getLong("t1")
              }
            }
            list += json
          }
        }

        list
      })

      .persist()
    logger.error(">>>计算后日志量：" + resultRdd.count())
    computeRdd2.unpersist()

    (resultRdd, dateList)
  }

  /**
   * 访问比较轨迹接口
   *
   * @param json
   * @param tracks1
   * @param tracks2
   * @return
   */
  def accessCompareUrl(json: JSONObject, tracks1: JSONArray, tracks2: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("vehicle", vehicle_type)
    //param.put("compensate", 1)
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("retflag", 5)
    param.put("tracktype", 0)
    param.put("tracks1", tracks1)
    param.put("tracks2", tracks2)
    //    println("-------------json-------" + json)
    //      println("轨迹对比接口："+compare_track_url)
    //      println("轨迹对比参数："+param)
    http_result = HttpClientUtil.getJsonByPostJson(compare_track_url, param.toString)
    Thread.sleep(600)
    //      println("轨迹对比结果："+http_result)
    //    } catch {
    //      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
    //    }
    http_result
  }


}
