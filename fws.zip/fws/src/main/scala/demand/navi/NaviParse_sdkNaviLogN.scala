package demand.navi

import com.alibaba.fastjson.{JSON, JSONObject}
import demand.utils.{DateUtil, JsonUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util
import java.util.Date
import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * @task_id: 262198
 * @description: 表5 gis_navi_sdk_navi_parse
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/10/19 11:45
 */
object NaviParse_sdkNaviLogN {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    try {
      result.fluentPutAll(result.getJSONObject("data"))
    } catch {
      case e: Exception => logger.error("原始数据中无该目录" + str + ">>>>>>>>" + e.printStackTrace())
    }
    result.keySet().toArray.foreach(key => {
      if (result.get(key.toString).isInstanceOf[JSONObject]) {
        val temp = result.getJSONObject(key.toString)
        temp.keySet().toArray.foreach(k => {
          result.put(k.toString.toLowerCase, temp.getString(k.toString))
        })
      }
    })
    "endx,x;endy,y;crossid,crossingId;voiceinfo,voice"
      .split(";").foreach(x => result.put(x.split(",")(0), result.getString(x.split(",")(1))))
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value

  def get3[T <% RDD[T]](value: T): RDD[T] = value

  def get4[T](value: T) = List(value)

  trait get5[-T, +U] {
    def apply(x: T): U
  }


  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      ParseLog(spark, DateUtil.getYesterday)
    } else if (args.length == 1) {
      //传入参数，单天任务
      ParseLog(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    val runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getsdkNaviLogRdd
    computeRddF = null
    table = "gis_navi_sdk_navi_parse"

    structs = Array("task_id", "navi_id", "sdk_ver", "type", "routeid", "report_time", "new_routeid", "hasyaw", "end_type", "endx", "endy", "cc", "lane_id", "cross_id", "voice_info", "operate", "content", "ak", "start_type", "navi_type", "top3_strategy", "navi_strategy", "navi_pathscore", "service_id", "gd_content", "pull_navitype", "isaccrualtask", "curstartdept", "curenddept", "curendpoint", "curstartpoint", "endsortnum", "isstartpointnavi", "iscontinuenavi", "gddeviceid", "navi_uniqueid")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)
  }

  /**
   * 获取naviConfigLog日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getsdkNaviLogRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = "sdkNaviLog"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "日志")
    val validRdd = getHiveRdd(spark, dateList, logType).persist()
    logger.error(">>>初始化加载的数据总量为>>>>>>" + validRdd.count())
    val computeRdd1 = validRdd.map(json => {
      var navi_id, _type, navi_type, start_type, routeid = ""
      var report_time: java.lang.Long = null
      if (json != null) {
        val data = json.getJSONObject("data")
        if (data != null) {
          json.put("sdkver", data.getString("sdkVersion"))
          navi_id = data.getString("naviId")
          _type = data.getString("type")
          navi_type = data.getString("naviType")
          start_type = data.getString("startType")
          report_time = data.getLong("reportTime")

          if (report_time != null) {
            val inc_day = longToTime(report_time).split(" ")(0).replaceAll("-", "")
            json.put("inc_day", inc_day)
          }

          val routeInfo = data.getJSONObject("routeInfo")
          if (routeInfo != null) {
            routeid = routeInfo.getString("routeId")
            if (_type == "1") {
              json.put("isstartpointnavi", routeInfo.getString("isStartPointNavi"))
              json.put("iscontinuenavi", routeInfo.getString("iscontinueNave"))
              json.put("naviuniqueid", data.getString("naviUniqueId"))
            }
            if (_type == "3") {
              json.put("naviuniqueid", data.getString("naviUniqueId"))
            }
          }

          var content = ""
          val operateInfo = data.getJSONObject("operateInfo")
          if (operateInfo != null) {
            content = operateInfo.getString("content")
            if (!StringUtils.isEmpty(content)) {
              json.put("content", content)
            }
          }
          if (StringUtils.isEmpty(json.getString("content"))) {
            val gdSdkOperateInfo = data.getJSONObject("gdSdkOperateInfo")
            if (gdSdkOperateInfo != null) {
              content = gdSdkOperateInfo.getString("content")
              if (!StringUtils.isEmpty(content)) {
                json.put("content", content)
              }
            }
          }
          val yawInfo = data.getJSONObject("yawInfo")
          if (yawInfo != null) {
            val routeId = yawInfo.getString("routeId")
            if (!StringUtils.isEmpty(routeId)) json.put("new_routeid", routeId)
          }
        }
      }

      if (StringUtils.isEmpty(navi_id)) navi_id = "-"
      if (StringUtils.isEmpty(_type)) _type = "-"
      if (StringUtils.isEmpty(navi_type)) navi_type = "-"
      if (StringUtils.isEmpty(start_type)) start_type = "-"
      if (report_time == null) report_time = Long.MaxValue
      if (StringUtils.isEmpty(routeid)) routeid = "-"
      json.put("navi_id", navi_id)
      json.put("type", _type)
      json.put("navi_type", navi_type)
      json.put("start_type", start_type)
      json.put("report_time", report_time)
      json.put("routeid", routeid)
      json
    })
      .filter(json => json != null && (!StringUtils.isEmpty(json.getString("inc_day")) && json.getString("navi_id") != "-1"))
      .map(json => {
        val navi_id = json.getString("navi_id") + "&_&" + Random.nextInt(5000).toString
        val routeid = json.getString("routeid")
        json.put("navi_id", navi_id)
        ((navi_id, routeid), json)
      }).persist()
    logger.error(">>>computeRdd1的数据总量>>>>>>" + computeRdd1.count())
    val computeRdd2 = computeRdd1.groupByKey()
      .flatMap(obj => {
        var list = new ArrayBuffer[JSONObject]()

        val list2 = obj._2.toList.filter(j => "9".equalsIgnoreCase(j.getString("type")) || !"10".equalsIgnoreCase(j.getString("type")))
        if (list2.nonEmpty) {
          list2.map(json => {
            list += json
          })
        }

        var json: JSONObject = null

        val list9 = obj._2.toList.filter(j => "9".equalsIgnoreCase(j.getString("type")))
        if (list9.nonEmpty) {
          if (list9.size == 1) json = list9.head
          else {
            json = list9.minBy(j => j.getLong("report_time"))
          }

          if (json != null) list += json
        }

        json = null

        val list10 = obj._2.toList.filter(j => "10".equalsIgnoreCase(j.getString("type")))
        if (list10.nonEmpty) {
          if (list10.size == 1) json = list10.head
          else {
            json = list10.maxBy(j => j.getLong("report_time"))
          }

          if (json != null) list += json
        }

        list
      }).map(json => {
      val navi_id = json.getString("navi_id").split("&_&")(0)
      val routeid = json.getString("routeid")
      json.put("navi_id", navi_id)
      ((navi_id, routeid), json)
    }).groupByKey()
      .flatMap(obj => {
        var list = new ArrayBuffer[JSONObject]()

        val list2 = obj._2.toList.filter(j => "9".equalsIgnoreCase(j.getString("type")) || !"10".equalsIgnoreCase(j.getString("type")))
        if (list2.nonEmpty) {
          list2.map(json => {
            list += json
          })
        }

        var json: JSONObject = null

        val list9 = obj._2.toList.filter(j => "9".equalsIgnoreCase(j.getString("type")))
        if (list9.nonEmpty) {
          if (list9.size == 1) json = list9.head
          else {
            json = list9.minBy(j => j.getLong("report_time"))
          }

          if (json != null) list += json
        }

        json = null

        val list10 = obj._2.toList.filter(j => "10".equalsIgnoreCase(j.getString("type")))
        if (list10.nonEmpty) {
          if (list10.size == 1) json = list10.head
          else {
            json = list10.maxBy(j => j.getLong("report_time"))
          }

          if (json != null) list += json
        }

        list
      })

    val computeRdd = computeRdd2.map(json => {
      if (json != null) {
        if ("8".equalsIgnoreCase(json.getString("type"))) {
          val data = json.getJSONObject("data")
          if (data != null) {
            val gdSdkOperateInfo = data.getJSONObject("gdSdkOperateInfo")
            if (gdSdkOperateInfo != null) {
              val content = gdSdkOperateInfo.getString("content")
              try {
                if (!StringUtils.isEmpty(content)) json.put("gd_content", Base64Util.get(content))
              } catch {
                case e: Exception => logger.error(e.getMessage)
              }
            }
          }
        }
      }
      json
    }).coalesce(2000).persist()
    logger.error(">>>computeRdd2的数据总量>>>>>>" + computeRdd.count())
    computeRdd1.unpersist()
    validRdd.unpersist()
    computeRdd
  }

  /**
   * 对给定的字符串 进行空值判断
   *
   * @param
   * @return 列类型
   */
  def strNotNull(str: Any): Boolean = {
    str match {
      case null => false
      case "null" => false
      case _ => !str.toString.isEmpty && str.toString.replaceAll("-", "").trim != ""
    }
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val table = "gis_eta_navi_query_hive"

    val sql =
      s"""
         |select data,inc_day from dm_gis.$table t
         | where inc_day between '$startDate' and '$endDate'
         | and get_json_object(data, '$$.subType') = '$subType'
       """.stripMargin

    logger.error("取数sql:" + sql)
    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x))
  }

  def mutiDayRddToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], dateList: ArrayBuffer[String]): Unit = {
    val resRDD = resultRdd.persist()
    for (date <- dateList) {
      val resultRdd2 = filterRdd(resRDD, date)
      filterRddToHive(spark, resultRdd2, table, structs, keys, date)
    }
  }

  def filterRdd(resultRdd: RDD[JSONObject], date: String): RDD[JSONObject] = {
    val dateRdd = resultRdd.filter(json => {
      val inc_day = json.getString("inc_day")
      inc_day != null && inc_day.equals(date)
    })
    dateRdd
  }

  def filterRddToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], date: String): Unit = {
    saveJSONObjectRDDToHive(spark, resultRdd, table, structs, keys, date)
  }

  def saveJSONObjectRDDToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if (StringUtils.isEmpty(dataBase)) database = "dm_gis" else database = dataBase
    logger.error(">>>table=" + database + "." + table)
    spark.sql(s"use $database")
    //1 构造DataFrame的元数据 StructField
    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    //2 构建StructType用于DataFrame的元数据描述
    val structType = DataTypes.createStructType(structFileds)
    //3 构建Row格式数据集RDD[Row]
    val rowRdd = resultRdd.filter(_ != null).map(obj => {
      var row: Row = null
      try {
        val v = new Array[String](structs.length)
        for (i <- structs.indices) v(i) = JsonUtil.getJsonVal(obj, structs(i).replaceAll("_", ""), "")
        row = RowFactory.create(v: _*)
      } catch {
        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
      }
      row
    }).filter(_ != null)
    // 4 构建DataFrame
    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
    //5 基于Datarame创建临时表
    val tempView = String.format("%s_temp_view", table)
    df.createOrReplaceTempView(tempView)
    //6 分区、表等操作
    val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
    logger.error(">>>删除分区：" + deleteSql)
    spark.sql(deleteSql)
    val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
    logger.error(">>>新建分区：" + createPartitionSql)
    spark.sql(createPartitionSql)
    //7 把临时表的数据刷进hive表中
    spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
    logger.error(">>>数据入hive库结束!")
  }
}
