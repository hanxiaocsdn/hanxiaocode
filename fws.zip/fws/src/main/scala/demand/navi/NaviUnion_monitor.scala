package demand.navi

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import demand.utils.{DateUtil, HttpClientUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer
import scala.util.Random
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 262325
 * @description: Navi关联monitor (表6 +表7)：dm_gis.gis_navi_finish_monitor 合并表7 ，新增字段 "tracks1", "tracks2", "offtime_ratio", "stay_list", "len", "ret", "start_type", "navi_strategy"
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/6/6 15:17
 */
object NaviUnion_monitor {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 500
  var trackquery_url1 = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrate"
  var trackquery_url2 = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/query"
  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"

  val table = "gis_navi_finish_monitor"
  val table_p1 = "gis_navi_finish_monitor_p1" //inc_day 分区
  val table_p2 = "gis_navi_finish_monitor_p2" //inc_day  num 分区

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)
    spark.sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    spark.sqlContext.setConf("hive.exec.dynamic.partition", true.toString)
    UnionMonitorLog(spark, args(0), "false", args(1), args(2), args(3))
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionMonitorLog(spark: SparkSession, date: String, auto: String, start_num: String, inter_num: String, end_num: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getUnion_MonitorRdd
    computeRddF = null
    //gis_navi_finish_monitor 的字段
    //    structs = Array("task_id", "navi_id", "endx", "endy", "navi_logtype", "navi_endtype", "navi_endtime", "navi_endx", "navi_endy", "distance", "status", "vehicle", "vehicle_type", "weight", "mload", "length", "axle_number", "navi_starttime", "starttime_type", "navi_type", "tracks1", "tracks2", "offtime_ratio", "stay_list", "len", "ret", "start_type", "navi_strategy", "num")
    //    keys = Array("task_id", "navi_id", "endx", "endy", "navi_logtype", "navi_endtype", "navi_endtime", "navi_endx", "navi_endy", "distance", "status", "vehicle", "vehicle_type", "weight", "mload", "length", "axle_number", "navi_starttime", "starttime_type", "navi_type", "tracks1", "tracks2", "offtime_ratio", "stay_list", "len", "ret", "start_type", "navi_strategy", "num")
    //中间表中需要增加req_time字段 gis_navi_finish_monitor_p1 字段
    structs = Array("task_id", "navi_id", "endx", "endy", "navi_logtype", "navi_endtype", "navi_endtime", "navi_endx", "navi_endy", "distance", "status", "vehicle", "vehicle_type", "weight", "mload", "length", "axle_number", "navi_starttime", "starttime_type", "navi_type", "tracks1", "tracks2", "offtime_ratio", "stay_list", "len", "ret", "start_type", "navi_strategy", "req_time", "num")
    keys = Array("task_id", "navi_id", "endx", "endy", "navi_logtype", "navi_endtype", "navi_endtime", "navi_endx", "navi_endy", "distance", "status", "vehicle", "vehicle_type", "weight", "mload", "length", "axle_number", "navi_starttime", "starttime_type", "navi_type", "tracks1", "tracks2", "offtime_ratio", "stay_list", "len", "ret", "start_type", "navi_strategy", "req_time", "num")

    logger.error("开始处理" + date)
    //    val initial_cnt = spark.sql(s"""select * from dm_gis.$table_p1 where inc_day='$date' limit 1""").head(1).size
    //    if (initial_cnt == 0) {
    //      parseSaveLog(spark, getRddF, computeRddF, table_p1, structs, keys, saveHiveRddF, "3", date, auto)
    //    }
    parseSaveLog(spark, getRddF, computeRddF, table_p1, structs, keys, saveHiveRddF, "3", date, auto)
    getUnion_MonitorRddFix(spark, table_p1, table_p2, date, start_num, inter_num, end_num)
    val res_cols = spark.sql(s"""select * from dm_gis.$table limit 0""").schema.map(_.name).map(col)
    val df = spark.sql(s"""select * from dm_gis.$table_p2 where inc_day ='$date'""").select(res_cols: _*)
    writeToHive(spark, df.coalesce(10), Seq("inc_day"), s"""dm_gis.$table""")
    spark.sql(s"""truncate table dm_gis.$table_p1""")
    spark.sql(s"""truncate table dm_gis.$table_p2""")
    spark.stop()
  }

  def getUnion_MonitorRddFix(spark: SparkSession, table_p1: String, table_p2: String, date: String, start_num: String, inter_num: String, end_num: String): Unit = {
    import spark.implicits._
    val sql = s"""select * from dm_gis.$table_p1 where inc_day='$date'""".stripMargin
    logger.error(">>>>>接口前步骤1sql>>>>>" + sql)
    val inter_back_df = spark.sql(sql)
    logger.error(">>>>>接口前步骤1生成的数据>>>>>" + inter_back_df.count())

    val httpInvoke_s1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "262325", "表6：Navi关联monitor", "相似度接口1", trackquery_url1, "e640de2b47394b19862ee134d817bbc7", inter_back_df.count(), 25)
    val httpInvoke_s2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "262325", "表6：Navi关联monitor", "相似度接口2", trackquery_url2, "e640de2b47394b19862ee134d817bbc7", inter_back_df.count(), 25)
    val httpInvoke_rec = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "262325", "表6：Navi关联monitor", "纠偏接口", rectify_url, "d9c28a860af34836973480542dc11d83", inter_back_df.count(), 25)

    var start_num_cnt = start_num.toInt
    val inter_num_cnt = inter_num.toInt
    var batch_num_cnt = start_num_cnt + inter_num_cnt
    val end_num_cnt = end_num.toInt

    for (i <- start_num_cnt until 101 if i >= start_num_cnt && i <= end_num_cnt) {
      logger.error("首发批次：" + i + " >>执行的批次num范围:" + start_num_cnt + "结束批次>>>" + batch_num_cnt)
      val inter_post_df_t = inter_back_df.filter('num.cast("int") >= start_num_cnt && 'num.cast("int") <= batch_num_cnt)
      val resultRdd = getValidJsonFromDF(spark, inter_post_df_t).coalesce(25).persist() //接口并发限制
      logger.error(">>>该批次总量为>>>" + resultRdd.count())
      val res_cols = spark.sql(s"""select * from dm_gis.$table_p2 limit 0""").schema.map(_.name).map(col)
      val res_monitorRdd = resultRdd.map(json => {
        var m_json: JSONObject = null
        val filter_cond = Seq("1", "2", "3", "10", "13", "14").contains(json.getString("status")) && strNotNull(json.getString("navi_starttime")) && strNotNull(json.getString("navi_endtime")) && strNotNull(json.getString("req_time"))
        if (filter_cond) {
          m_json = mergeRectify(json)
        } else {
          m_json = json
        }
        Row(m_json.getString("task_id"), m_json.getString("navi_id"), m_json.getString("endx"), m_json.getString("endy"), m_json.getString("navi_logtype"), m_json.getString("navi_endtype"), m_json.getString("navi_endtime"), m_json.getString("navi_endx"), m_json.getString("navi_endy"), m_json.getString("distance"), m_json.getString("status"), m_json.getString("vehicle"), m_json.getString("vehicle_type"), m_json.getString("weight"), m_json.getString("mload"), m_json.getString("length"), m_json.getString("axle_number"), m_json.getString("navi_starttime"), m_json.getString("starttime_type"), m_json.getString("navi_type"), m_json.getString("tracks1"), m_json.getString("tracks2"), m_json.getString("offtime_ratio"), m_json.getString("stay_list"), m_json.getString("len"), m_json.getString("ret"), m_json.getString("start_type"), m_json.getString("navi_strategy"), m_json.getString("req_time"), m_json.getString("inc_day"), m_json.getString("num"))
      }).persist()
      val res_df = spark.createDataFrame(res_monitorRdd, getschema()).select(res_cols: _*).persist()
      logger.error(">>最终数据总量：>>>>>" + res_df.count())
      writeToHive(spark, res_df.coalesce(2), Seq("inc_day", "num"), s"""dm_gis.$table_p2""")
      res_df.unpersist()
      start_num_cnt = batch_num_cnt + 1
      batch_num_cnt = start_num_cnt + inter_num_cnt
    }
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_s1)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_s2)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_rec)

  }

  /**
   * 将数据写入hive表中【OVERWRITE】
   *
   * @param spark
   * @param dataframe
   * @param partitionCol
   * @param resTableName
   */
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  def getschema(): StructType = {
    val schema = StructType(Seq(
      StructField("task_id", StringType, nullable = true),
      StructField("navi_id", StringType, nullable = true),
      StructField("endx", StringType, nullable = true),
      StructField("endy", StringType, nullable = true),
      StructField("navi_logtype", StringType, nullable = true),
      StructField("navi_endtype", StringType, nullable = true),
      StructField("navi_endtime", StringType, nullable = true),
      StructField("navi_endx", StringType, nullable = true),
      StructField("navi_endy", StringType, nullable = true),
      StructField("distance", StringType, nullable = true),
      StructField("status", StringType, nullable = true),
      StructField("vehicle", StringType, nullable = true),
      StructField("vehicle_type", StringType, nullable = true),
      StructField("weight", StringType, nullable = true),
      StructField("mload", StringType, nullable = true),
      StructField("length", StringType, nullable = true),
      StructField("axle_number", StringType, nullable = true),
      StructField("navi_starttime", StringType, nullable = true),
      StructField("starttime_type", StringType, nullable = true),
      StructField("navi_type", StringType, nullable = true),
      StructField("tracks1", StringType, nullable = true),
      StructField("tracks2", StringType, nullable = true),
      StructField("offtime_ratio", StringType, nullable = true),
      StructField("stay_list", StringType, nullable = true),
      StructField("len", StringType, nullable = true),
      StructField("ret", StringType, nullable = true),
      StructField("start_type", StringType, nullable = true),
      StructField("navi_strategy", StringType, nullable = true),
      StructField("req_time", StringType, nullable = true),
      StructField("inc_day", StringType, nullable = true),
      StructField("num", StringType, nullable = true)
    ))
    schema
  }


  def getUnion_MonitorRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    val dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    val startDate = DateUtil.getDateStr(date, -2)
    val endDate = date
    dateList += endDate
    val sql =
      s"""
         |select a.task_id,a.navi_id,a.req_time,a.endx,a.endy,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,b.navi_logtype,b.navi_endtype,b.navi_endtime,b.navi_endx,b.navi_endy,b.cc,c.navi_starttime,c.type,c.navi_type,a.inc_day,a.inc_day as inc_date,'1' as `end`,a.end2,d.navi_endtime2,e.navi_starttime2,start_type,navi_strategy from
         |(select task_id,navi_id,req_time,endx,endy,vehicle,vehicle_type,weight,mload,length,axle_number,inc_day,case when inc_day='$startDate' then '1' else '0' end end2 from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate' and task_id is not null and trim(task_id) !='' and navi_id is not null and trim(navi_id) !='' group by task_id,navi_id,req_time,endx,endy,vehicle,vehicle_type,weight,mload,length,axle_number,inc_day) a
         |left join (select task_id,navi_id,type as navi_logtype,end_type as navi_endtype,report_time as navi_endtime,endx as navi_endx,endy as navi_endy,cc from dm_gis.gis_navi_sdk_navi_parse where type='3' and inc_day between '$startDate' and '$endDate' and task_id is not null and trim(task_id) !='' and navi_id is not null and trim(navi_id) !='' group by task_id,navi_id,type,end_type,report_time,endx,endy,cc) b on a.task_id=b.task_id and a.navi_id=b.navi_id
         |left join (select task_id,navi_id,report_time as navi_starttime,type,navi_type from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day between '$startDate' and '$endDate' and task_id is not null and trim(task_id) !='' and navi_id is not null and trim(navi_id) !='' group by task_id,navi_id,type,report_time,navi_type) c on a.task_id=c.task_id and a.navi_id=c.navi_id
         |left join (select task_id,navi_id,report_time as navi_endtime2 from dm_gis.gis_navi_sdk_navi_parse where type='10' and inc_day between '$startDate' and '$endDate'  and task_id is not null and trim(task_id) !='' and navi_id is not null and trim(navi_id) !='' group by task_id,navi_id,report_time) d on a.task_id=d.task_id and a.navi_id=d.navi_id
         |left join (select task_id,navi_id,report_time as navi_starttime2 from dm_gis.gis_navi_sdk_navi_parse where type='9' and inc_day between '$startDate' and '$endDate' and task_id is not null and trim(task_id) !='' and navi_id is not null and trim(navi_id) !='' group by task_id,navi_id,report_time) e on a.task_id=e.task_id and a.navi_id=e.navi_id
         |left join (select navi_id,max(start_type) as start_type from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' group by navi_id) f on a.navi_id=f.navi_id
         |left join (select navi_id,max(navi_strategy) as navi_strategy from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day between '$startDate' and '$endDate' group by navi_id) g on a.navi_id=g.navi_id
     """.stripMargin

    val resultRdd = getValidJson(spark, sql).persist()
    logger.error(">>>日志量：" + resultRdd.count())
    val monitorRdd = resultRdd.map(json => {
      if (json != null) {
        //如果navi_starttime(type = 1)为空，取navi_starttime2(type = 9)的值
        if (StringUtils.isEmpty(json.getString("navi_starttime"))) {
          val navi_starttime2 = json.getString("navi_starttime2")
          if (!StringUtils.isEmpty(navi_starttime2)) {
            json.put("navi_starttime", navi_starttime2)
          } else {
            val req_time = json.getString("req_time")
            if (!StringUtils.isEmpty(req_time) && !"0".equalsIgnoreCase(req_time)) {
              json.put("navi_starttime", req_time)
            } else {
              json.put("navi_starttime", "-1")
            }
          }
        }
        //如果navi_endtime(type = '3')为空，取navi_endtime2(type = 10)的值
        var flag = false
        if (StringUtils.isEmpty(json.getString("navi_endtime"))) {
          val navi_endtime2 = json.getString("navi_endtime2")
          if (!StringUtils.isEmpty(navi_endtime2)) {
            json.put("navi_endtime", navi_endtime2)
            flag = true
          }
        }

        val end = json.getString("end")
        val end2 = json.getString("end2")
        val navi_endx = json.getDouble("navi_endx")
        val navi_endy = json.getDouble("navi_endy")

        var distance: java.lang.Double = null
        var status = ""
        val endx = json.getDouble("endx")
        val endy = json.getDouble("endy")

        if (endx != null && endy != null && navi_endx != null && navi_endy != null && endx != 0 && endy != 0 && navi_endx != 0 && navi_endy != 0) {
          distance = MapApiUtil.getGreatCircleDistance(endx, endy, navi_endx, navi_endy)
        }
        //navi_endtype 判断获取 status 字段的值
        val navi_endtype = json.getString("navi_endtype") //navi_endtype 来自于 type = 3
        if ("1".equalsIgnoreCase(navi_endtype)) {
          if (distance != null && distance < 1000) status = "1" else status = "10"
        } else if ("2".equalsIgnoreCase(navi_endtype)) {
          status = "2"
        } else if ("3".equalsIgnoreCase(navi_endtype)) {
          if (distance != null && distance < 1000) status = "3" else status = "11"
        } else {
          if ("1".equalsIgnoreCase(end)) {
            if ("1".equalsIgnoreCase(end2)) {
              json.put("navi_endtime", dateToTimeStamp(date))
              json.put("inc_date", date)
              status = "12"
            }
          } else {
            json.put("navi_endtime", dateToTimeStamp(date))
            json.put("inc_date", date)
            status = "0"
          }
        }
        if (endx != null && endy != null && navi_endx != null && navi_endy != null && (endx == 0 || endy == 0 || navi_endx == 0 || navi_endy == 0)) {
          status = "14"
        }
        if (flag) {
          status = "1"
        }
        json.put("distance", distance)
        json.put("status", status)
        json.put("num", Random.nextInt(100) + 1) //1-100
      }
      json
    }).filter(json => {
      json != null && json.getString("inc_date") == date
    }).persist()
    (monitorRdd, dateList)
  }

  def mergeRectify(json: JSONObject): JSONObject = {
    //获取历史轨迹
    var tracks1_origin: JSONArray = null
    var req_time = ""
    var navi_endtime = ""
    val req_timel = json.getLong("req_time")
    if (req_timel != null) {
      req_time = longToTime(req_timel)
    }
    val navi_endtimel = json.getLong("navi_endtime")
    if (navi_endtimel != null) {
      navi_endtime = longToTime(navi_endtimel + 300000)
    }
    if (!StringUtils.isEmpty(req_time) && !StringUtils.isEmpty(navi_endtime)) {
      var flag = false
      val httpObject1 = accessTrackUrl1(json, req_time, navi_endtime)
      if (httpObject1 != null) {
        val result = httpObject1.getJSONObject("result")
        if (result != null) {
          val data = result.getJSONObject("data")
          if (data != null) {
            val track = data.getJSONArray("track")
            if (track != null && track.size() > 0) {
              flag = true
              tracks1_origin = data.getJSONArray("track")
            }
          }
        }
      }
      if (!flag) {
        val httpObject2 = accessTrackUrl2(json, req_time, navi_endtime)
        if (httpObject2 != null) {
          val result = httpObject2.getJSONObject("result")
          if (result != null) {
            val data = result.getJSONObject("data")
            if (data != null) {
              tracks1_origin = data.getJSONArray("track")
            }
          }
        }
      }
    }

    val tracks1: JSONArray = new JSONArray()
    val tracks1_new = new JSONArray()
    if (tracks1_origin != null && tracks1_origin.size() > 0) {
      for (i <- 0.until(tracks1_origin.size())) {
        val tempJson = tracks1_origin.getJSONObject(i)
        val newJson1 = new JSONObject()
        val newJson2 = new JSONObject()
        if (tempJson != null) {
          val tp = tempJson.getInteger("tp")
          val x = tempJson.getDouble("zx")
          val y = tempJson.getDouble("zy")
          val ac = tempJson.getInteger("ac")
          val sp = tempJson.getDouble("sp")
          val be = tempJson.getDouble("be")
          val tm = tempJson.getInteger("tm")

          if (tp != null) newJson1.put("type", tp)
          if (x != null) newJson1.put("x", x)
          if (y != null) newJson1.put("y", y)
          if (ac != null) newJson1.put("accuracy", ac)
          if (sp != null) newJson1.put("speed", sp)
          if (be != null) newJson1.put("azimuth", be)
          if (tm != null) newJson1.put("time", tm)

          if (x != null) newJson2.put("x", x)
          if (y != null) newJson2.put("y", y)
          if (tm != null) newJson2.put("tm", tm)
        }
        newJson1.put("index", i)
        tracks1.add(newJson1)
        tracks1_new.add(newJson2)
      }
    }
    val tracks2_new = new ArrayBuffer[JSONObject]()
    val stayList = new JSONArray()
    var offTimeRatio = ""
    var len = ""
    var ret = ""

    var result: JSONObject = null
    if ("gdwl".equalsIgnoreCase(json.getString("navi_type"))) {
      result = accessRectifyUrl(json, tracks1)
    }
    else {
      result = accessRectifyUrl2(json, tracks1)
    }
    if (result != null) {
      val status = result.getInteger("status")
      val resultObject = result.getJSONObject("result")
      if (resultObject != null) {
        val tracks2 = resultObject.getJSONArray("tracks")
        val stay_points = resultObject.getJSONArray("stay_points")
        offTimeRatio = resultObject.getString("offTimeRatio")
        len = resultObject.getString("len")
        ret = resultObject.getString("ret")
        if (tracks2 != null && tracks2.size() > 0) {
          for (i <- 0.until(tracks2.size())) {
            val track = tracks2.getJSONObject(i)
            if (track != null) {
              val newJson = new JSONObject()
              val x = track.getString("x")
              val y = track.getString("y")
              val tm = track.getString("time")
              val sum_dist = track.getString("sum_dist")
              val swid = track.getString("SWID")

              newJson.put("x", x)
              newJson.put("y", y)
              newJson.put("tm", tm)
              newJson.put("sum_dist", sum_dist)
              newJson.put("swid", swid)
              tracks2_new += newJson
            }
          }
        }
        if (stay_points != null && tracks2 != null) {
          if (stay_points.size() > 0) {
            for (i <- 0.until(stay_points.size())) {
              val stay_point = stay_points.getJSONObject(i)
              if (stay_point != null) {
                val start_index = stay_point.getInteger("start_index")
                val end_index = stay_point.getInteger("end_index")
                val pois = stay_point.getJSONArray("pois")

                val duration = stay_point.getString("duration")
                var stayStartTime = ""
                var stayStartLongitude = ""
                var stayStartLatitude = ""
                var stayEndTime = ""
                var stayEndLongitude = ""
                var stayEndLatitude = ""
                var stayType = ""

                if (start_index != null && start_index < tracks2.size()) {
                  val track = tracks2.getJSONObject(start_index)
                  if (track != null) {
                    stayStartTime = track.getString("time")
                    stayStartLongitude = track.getString("x")
                    stayStartLatitude = track.getString("y")
                  }
                }

                if (end_index != null && end_index < tracks2.size()) {
                  val track = tracks2.getJSONObject(end_index)
                  if (track != null) {
                    stayEndTime = track.getString("time")
                    stayEndLongitude = track.getString("x")
                    stayEndLatitude = track.getString("y")
                  }
                }

                if (pois != null && pois.size() > 0) {
                  val all_poi_types = new ArrayBuffer[String]()
                  breakable(
                    for (j <- 0.until(pois.size())) {
                      val poi = pois.getJSONObject(j)
                      if (poi != null) {
                        val _type = poi.getString("type")
                        if ("1".equalsIgnoreCase(_type) || "5".equalsIgnoreCase(_type)) {
                          stayType = "3"
                          break
                        }
                        if (!StringUtils.isEmpty(_type)) all_poi_types += _type
                      }
                    }
                  )
                  if (StringUtils.isEmpty(stayType)) {
                    val all_types = all_poi_types.toSet
                    if (all_types.contains("3")) stayType = "1"
                    else if (all_types.contains("2")) stayType = "2"
                    else stayType = "4"
                  }
                }

                val newJson = new JSONObject()
                newJson.put("duration", duration)
                newJson.put("stayStartTime", stayStartTime)
                newJson.put("stayStartLongitude", stayStartLongitude)
                newJson.put("stayStartLatitude", stayStartLatitude)
                newJson.put("stayEndTime", stayEndTime)
                newJson.put("stayEndLongitude", stayEndLongitude)
                newJson.put("stayEndLatitude", stayEndLatitude)
                newJson.put("stayType", stayType)
                stayList.add(newJson)
              }
            }
          }
        }
      }
    }
    if (tracks1_new.size() > 0) json.put("tracks1", tracks1_new)
    if (tracks2_new.nonEmpty) {
      val tracks2_new2 = new JSONArray()
      val temp = tracks2_new.sortBy(j => j.getLong("tm"))
      temp.toList.foreach(j => {
        tracks2_new2.add(j)
      })
      json.put("tracks2", tracks2_new2)
    }
    json.put("offtime_ratio", offTimeRatio)
    if (stayList.size() > 0) json.put("stay_list", stayList)
    json.put("len", len)
    json.put("ret", ret)
    json
  }

  /**
   * 解析日志主流程
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
      }
    }
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param date
   * @return
   */
  def dateToTimeStamp(date: String, format: String = "yyyyMMdd"): String = {
    var datetime = ""
    try {
      val sdf = new SimpleDateFormat(format)
      val time = sdf.parse(date).getTime
      datetime = time.toString
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  def accessTrackUrl1(json: JSONObject, req_time: String, navi_endtime: String): JSONObject = {
    var http_result: JSONObject = null
    val param = new JSONObject()
    param.put("un", json.getString("vehicle"))
    if (req_time != null) param.put("beginDateTime", req_time.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    if (navi_endtime != null) param.put("endDateTime", navi_endtime.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    param.put("type", 0)
    param.put("rectify", false)
    param.put("ak", "e640de2b47394b19862ee134d817bbc7")
    param.put("hasRate", true)
    //    println("-------------json-------" + json)
    http_result = HttpClientUtil.getJsonByPostJson(trackquery_url1, param.toString)
    //    Thread.sleep(3000)
    http_result
  }

  def accessTrackUrl2(json: JSONObject, req_time: String, navi_endtime: String): JSONObject = {
    var http_result: JSONObject = null
    val param = new JSONObject()
    param.put("un", json.getString("vehicle"))
    if (req_time != null) param.put("beginDateTime", req_time.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    if (navi_endtime != null) param.put("endDateTime", navi_endtime.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    param.put("type", 400)
    param.put("rectify", false)
    param.put("ak", "e640de2b47394b19862ee134d817bbc7")
    param.put("hasRate", true)
    //    println("-------------json-------" + json)
    http_result = HttpClientUtil.getJsonByPostJson(trackquery_url2, param.toString)
    //    Thread.sleep(3000)
    http_result
  }

  /**
   * 访问比较轨迹接口
   *
   * @param json
   * @param tracks
   * @return
   */
  def accessRectifyUrl(json: JSONObject, tracks: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("vehicle", vehicle_type)
    param.put("retflag", 7)
    param.put("addpoint", 1)
    param.put("poiinfo", 1)
    param.put("tracks", tracks)

    val vehicleInfo = new JSONObject()
    val mload = json.getString("mload")
    if (!StringUtils.isEmpty(mload)) vehicleInfo.put("load", mload)
    val axle_number = json.getString("axle_number")
    if (!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis", axle_number)
    val weight = json.getDouble("weight")
    if (weight != null) vehicleInfo.put("weight", weight)
    val length = json.getDouble("length")
    if (length != null) vehicleInfo.put("length", length)

    param.put("vehicleInfo", vehicleInfo)
    param.put("roadinfo", 1)
    param.put("mat_ratio", 1)

    val process = new JSONObject()
    process.put("stay_time", 180)
    process.put("poi_range", 500)

    param.put("process", process)

    println("参数：" + param.toString)
    http_result = HttpClientUtil.getJsonByPostJson(rectify_url, param.toString)
    http_result
  }

  def accessRectifyUrl2(json: JSONObject, tracks: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("vehicle", vehicle_type)
    param.put("retflag", 7)
    param.put("addpoint", 1)
    param.put("poiinfo", 1)
    param.put("tracks", tracks)

    val vehicleInfo = new JSONObject()
    val mload = json.getString("mload")
    if (!StringUtils.isEmpty(mload)) vehicleInfo.put("load", mload)
    val axle_number = json.getString("axle_number")
    if (!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis", axle_number)
    val weight = json.getDouble("weight")
    if (weight != null) vehicleInfo.put("weight", weight)
    val length = json.getDouble("length")
    if (length != null) vehicleInfo.put("length", length)

    param.put("vehicleInfo", vehicleInfo)
    param.put("roadinfo", 1)
    param.put("mat_ratio", 1)

    val process = new JSONObject()
    process.put("stay_time", 180)
    process.put("poi_range", 500)

    param.put("process", process)

    println("参数：" + param.toString)
    http_result = HttpClientUtil.getJsonByPostJson(rectify_url, param.toString)
    http_result
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param sql
   * @return
   */
  def getValidJson(spark: SparkSession, sql: String): (RDD[JSONObject]) = {
    println("sql=" + sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(6400).map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) {
        json.put(header(i), row.getString(i))
      }
      json
    }).filter(_ != null)
    logRdd
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param sql
   * @return
   */
  def getValidJsonFromDF(spark: SparkSession, df: DataFrame): (RDD[JSONObject]) = {
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(6400).map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) {
        json.put(header(i), row.getString(i))
      }
      json
    }).filter(_ != null)
    logRdd
  }

  def strNotNull(str: Any): Boolean = {
    str match {
      case null => false
      case "null" => false
      case _ => !str.toString.isEmpty && str.toString.replaceAll("-", "").trim != ""
    }
  }
}
