package demand.navi

import com.alibaba.fastjson.JSONObject
import demand.utils._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.DecimalFormat
import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01368978 on 2021/5/28.
 */
object NaviUnion_etaresult1 {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 50

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getEtaResult1Rdd
    computeRddF = null
    table = "gis_navi_eta_result1"
    structs = Array("id", "task_id", "navi_count", "navi_order", "navi_id", "route_count", "route_order", "routeid", "req_count", "req_order", "request_id", "navi_starttime", "starttime_type", "req_time", "req_type", "x1", "y1", "x2", "y2", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plate_color", "energy", "emit_stand", "passport", "driver_id", "ft_url", "plan_date", "stype", "path_count", "opt", "strategy", "merge", "routeid_in", "fixed_route", "fencedist", "reroute", "status", "pns_status", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "highspeed_distance", "flen", "tlen", "routeid_out", "linknum", "rc_distance", "rdynsdlen", "rdynsdcnt", "navi_endstatus", "navi_endtime", "navi_endx", "navi_endy", "navi_time", "diff_time", "ft_right", "tl_times", "tl_navi_time", "tl_diff_time", "tl_ft_right", "req_status", "ret", "offtime_ratio", "yawpoints", "yawpoints_count", "start_speed", "vehicle_dir1", "rect_result", "strategy2", "routetype", "merge_result", "driver_type", "start_type", "is_econ", "service_id", "line_code", "navi_type", "route_index", "navi_strategy", "sdk_type", "top3_reqtype", "path_rule", "path_type", "path_pos", "limit_info", "is_lowrisk", "pathrule_num", "point_num", "area_num", "pull_navitype")
    keys = Array("id", "task_id", "navi_count", "navi_order", "navi_id", "route_count", "route_order", "routeid", "req_count", "req_order", "request_id", "navi_starttime", "starttime_type", "req_time", "req_type", "x1", "y1", "x2", "y2", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plate_color", "energy", "emit_stand", "passport", "driver_id", "ft_url", "plan_date", "stype", "path_count", "opt", "strategy", "merge", "routeid_in", "fixed_route", "fencedist", "reroute", "status", "pns_status", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "highspeed_distance", "flen", "tlen", "routeid_out", "linknum", "rc_distance", "rdynsdlen", "rdynsdcnt", "navi_endstatus", "navi_endtime", "navi_endx", "navi_endy", "navi_time", "diff_time", "ft_right", "tl_times", "tl_navi_time", "tl_diff_time", "tl_ft_right", "req_status", "ret", "offtime_ratio", "yawpoints", "yawpoints_count", "start_speed", "vehicle_dir1", "rect_result", "strategy2", "routetype", "merge_result", "driver_type", "start_type", "is_econ", "service_id", "line_code", "navi_type", "route_index", "navi_strategy", "sdk_type", "top3_reqtype", "path_rule", "path_type", "path_pos", "limit_info", "is_lowrisk", "pathrule_num", "point_num", "area_num", "pull_navitype")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }


  /**
   * 解析日志主流程
   *
   * @param spark
   * @param getRddF
   * @param computeRddF
   * @param table
   * @param structs
   * @param keys
   * @param saveHiveRddF
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }


  /**
   * 获取ETA结果汇总1
   *
   * @param spark
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def getEtaResult1Rdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    var dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    var runDate = ""
    runDate = date
    dateList += runDate

    logger.error(">>>获取" + runDate + "号的ETA结果汇总")
    var sql = ""
    val startDate = runDate //DateUtil.getDateStr(runDate,-1)//2
    val endDate = runDate
    val endDate1 = DateUtil.getDateStr(runDate, 1)
    sql =
      s"""
         |select a.task_id,a.navi_id,a.navi_starttime,a.starttime_type,a.routeid,a.request_id,a.req_time,a.req_type,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.reroute,a.status,a.pns_status,a.distance,a.duration,a.toll_distance,a.tolls,a.src,a.trafficlight_count,a.highspeed_distance,a.flen,a.tlen,a.routeid_out,a.linknum,a.rc_distance,a.rdynsdlen,a.rdynsdcnt,a.start_speed,a.vehicle_dir1,a.rect_result,a.strategy2,a.routetype,a.merge_result,a.driver_type,a.is_econ,a.service_id,a.line_code,a.navi_type,a.route_index,a.sdk_type,a.navi_endtime2,a.top3_reqtype,a.path_rule,a.path_type,a.path_pos,a.limit_info,a.is_lowrisk,a.pathrule_num,a.point_num,a.area_num,a.pull_navitype,b.navi_endstatus,b.navi_endtime,b.navi_endx,b.navi_endy,b.stay_list,b.ret,b.offtime_ratio,b.start_type,b.navi_strategy,a.inc_day,a.inc_date from
         |(select task_id,navi_id,navi_starttime,starttime_type,routeid,request_id,req_time,'top3' as req_type,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,'' as reroute,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,linknum,rc_distance,rdynsdlen,rdynsdcnt,start_speed,vehicle_dir1,rect_result,strategy2,routetype,merge_result,driver_type,is_econ,service_id,line_code,navi_type,route_index,'SFSDK' as sdk_type,'' as navi_endtime2,top3_reqtype,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num,pull_navitype,inc_day,inc_day as inc_date from dm_gis.gis_navi_top3_click_route where inc_day between '$startDate' and '$endDate' union all
         |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'yaw' as req_type,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,linknum,rc_distance,rdynsdlen,rdynsdcnt,'' as start_speed,'' as vehicle_dir1,rect_result,strategy2,routetype,merge_result,'' as driver_type,is_econ,service_id,line_code,navi_type,'' as route_index,'SFSDK' as sdk_type,'' as navi_endtime2,'' as top3_reqtype,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num,pull_navitype,inc_day,inc_day as inc_date from dm_gis.gis_navi_yaw_route where inc_day between '$startDate' and '$endDate'
         |) a
         |left join (select navi_id,max(status) as navi_endstatus,max(navi_endtime) as navi_endtime,max(navi_endx) as navi_endx,max(navi_endy) as navi_endy,max(stay_list) as stay_list,max(ret) as ret,max(offtime_ratio) as offtime_ratio,max(start_type) as start_type,max(navi_strategy) as navi_strategy from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate1' group by navi_id
         |) b on a.navi_id = b.navi_id""".stripMargin


    val resultRdd = NaviLogParse.getValidJson(spark, sql)
    logger.error(">>>日志量：" + resultRdd.count())

    val computeRdd = resultRdd.repartition(600)
      .map(json => {
        var navi_id = json.getString("navi_id")
        var request_id = json.getString("request_id")
        var req_time = json.getLong("req_time")
        if (StringUtils.isEmpty(navi_id)) navi_id = "-"
        if (StringUtils.isEmpty(request_id)) request_id = "-"
        if (req_time == null) req_time = Long.MaxValue

        val id = navi_id + "_" + request_id + "_" + req_time.toString
        json.put("id", id)

        if ("GDSDK".equalsIgnoreCase(json.getString("sdk_type"))) {
          var navi_endtime2 = json.getString("navi_endtime2")
          if (StringUtils.isEmpty(navi_endtime2)) navi_endtime2 = ""
          json.put("navi_endtime", navi_endtime2)
        }

        (id, json)
      })
      .groupByKey()
      .map(obj => {
        val json = obj._2.toList.head
        json
      })
      .map(json => {
        var task_id = json.getString("task_id")
        var navi_id = json.getString("navi_id")
        var routeid = json.getString("routeid")
        var req_time = json.getLong("req_time")

        if (StringUtils.isEmpty(task_id)) task_id = "-"
        if (StringUtils.isEmpty(navi_id)) navi_id = "-"
        if (StringUtils.isEmpty(routeid)) routeid = "-"

        if (req_time == null) req_time = Long.MaxValue

        ((task_id, navi_id, routeid), (req_time, json))
      })
      .groupByKey()
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()
        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
        val req_count = jsonList.size
        for (i <- jsonList.indices) {
          val json = jsonList(i)

          var req_status = ""
          val navi_endstatus = json.getInteger("navi_endstatus")
          if (navi_endstatus != null) {
            if (navi_endstatus >= 10) {
              req_status = "1"
            }
            else if (navi_endstatus == 0) req_status = "-1"
            else if (navi_endstatus < 10) {
              if (i < req_count - 1) {
                val nextJson = jsonList(i + 1)
                val x1 = json.getString("x1")
                val y1 = json.getString("y1")
                val next_x1 = nextJson.getString("x1")
                val next_y1 = nextJson.getString("y1")
                if (!StringUtils.isEmpty(x1) && !StringUtils.isEmpty(y1) && x1.equalsIgnoreCase(next_x1) && y1.equalsIgnoreCase(next_y1)) {
                  req_status = "1"
                }
              }
            }
            json.put("req_status", req_status)
          }

          val req_time = json.getLong("req_time")
          val navi_endtime = json.getLong("navi_endtime")

          var tl_times: java.lang.Long = 0l
          if (true) { //"0".equalsIgnoreCase(req_status)
            val stay_list = json.getJSONArray("stay_list")
            if (req_time != null && navi_endtime != null && stay_list != null && stay_list.size() > 0) {
              for (i <- 0.until(stay_list.size())) {
                val stay = stay_list.getJSONObject(i)
                if (stay != null) {
                  val stayStartTime = stay.getLong("stayStartTime")
                  val stayEndTime = stay.getLong("stayEndTime")
                  var duration = stay.getLong("duration")
                  if (stayStartTime != null && stayEndTime != null && duration != null) {
                    duration = duration * 1000
                    if (stayStartTime >= req_time && stayEndTime <= navi_endtime) {}
                    else if (stayStartTime <= req_time && stayEndTime >= req_time) {
                      duration = duration - (req_time - stayStartTime)
                    }
                    else if (stayStartTime <= navi_endtime && stayEndTime >= navi_endtime) {
                      duration = duration - (stayEndTime - navi_endtime)
                    }
                    tl_times = tl_times + duration
                  }
                }
              }
            }
            json.remove("stay_list")

          }

          if (tl_times != null) json.put("tl_times", tl_times.toDouble / 1000)

          json.put("req_order", i)
          json.put("req_count", req_count)
          list += json
        }
        list
      })

      .map(json => {
        val task_id = json.getString("task_id")
        val navi_id = json.getString("navi_id")
        var req_time = json.getLong("req_time")

        if (req_time == null) req_time = Long.MaxValue

        ((task_id, navi_id), (req_time, json))
      })
      .groupByKey()
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()

        val jsonList = obj._2.toList.groupBy(item => item._2.getString("routeid")).map(item => {
          val sortList = item._2.toList.sortBy(_._1)
          val minReqTime = sortList.head._1
          (minReqTime, sortList.map(_._2))
        }).toList.sortBy(_._1).map(_._2)

        val route_count = jsonList.size
        for (i <- jsonList.indices) {

          val yawpoints = new ArrayBuffer[String]()
          var yawpoints_count = 0
          var yawpoints_str = ""
          if (i != jsonList.size - 1) {
            for (k <- jsonList.indices) {
              if (k > i) {
                val jsonList2 = jsonList(k)
                for (j <- jsonList2.indices) {
                  val json = jsonList2(j)
                  if (json != null) {
                    val req_type = json.getString("req_type")
                    if ("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)) {
                      var x1 = json.getString("x1")
                      var y1 = json.getString("y1")
                      if (StringUtils.isEmpty(x1)) x1 = ""
                      if (StringUtils.isEmpty(y1)) y1 = ""
                      val xy = x1 + "," + y1
                      yawpoints += xy
                      yawpoints_count = yawpoints_count + 1
                    }
                  }
                }
              }
            }
          }
          if (yawpoints.nonEmpty) yawpoints_str = yawpoints.mkString(";")

          val jsonList2 = jsonList(i)
          for (j <- jsonList2.indices) {
            val json = jsonList2(j)

            json.put("yawpoints", yawpoints_str)
            json.put("yawpoints_count", yawpoints_count)

            json.put("route_order", i)
            json.put("route_count", route_count)
            list += json
          }
        }
        list
      })

      .map(json => {
        val task_id = json.getString("task_id")
        var req_time = json.getLong("req_time")

        if (req_time == null) req_time = Long.MaxValue

        (task_id, (req_time, json))
      })
      .groupByKey()
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()

        val jsonList = obj._2.toList.groupBy(item => item._2.getString("navi_id")).map(item => {
          val sortList = item._2.toList.sortBy(_._1)
          val minReqTime = sortList.head._1
          (minReqTime, sortList.map(_._2))
        }).toList.sortBy(_._1).map(_._2)

        val navi_count = jsonList.size
        for (i <- jsonList.indices) {
          val jsonList2 = jsonList(i)
          for (j <- jsonList2.indices) {
            val json = jsonList2(j)
            json.put("navi_order", i)
            json.put("navi_count", navi_count)
            list += json
          }
        }
        list
      })

      .map(json => {
        if (json != null) {
          try {
            val navi_endtime = json.getDouble("navi_endtime")
            val req_time = json.getDouble("req_time")
            if (navi_endtime != null && req_time != null) {
              val navi_time: java.lang.Double = (navi_endtime - req_time).toDouble / 1000
              json.put("navi_time", navi_time)
              val duration = json.getDouble("duration")
              if (duration != null && navi_time != null) {
                val diff_time: java.lang.Double = duration - navi_time
                json.put("diff_time", diff_time)
                if (diff_time != null && navi_time != null && navi_time != 0) {
                  var ft_right = ""
                  if (Math.abs(diff_time / navi_time) <= 0.1667) ft_right = "1"
                  else ft_right = "0"
                  json.put("ft_right", ft_right)
                }
              }
              val tl_times = json.getDouble("tl_times")
              if (tl_times != null && navi_time != null) {
                val tl_navi_time: java.lang.Double = navi_time - tl_times
                json.put("tl_navi_time", tl_navi_time)
                if (duration != null && tl_navi_time != null) {
                  val tl_diff_time: java.lang.Double = duration - tl_navi_time
                  json.put("tl_diff_time", tl_diff_time)
                  if (tl_diff_time != null && tl_navi_time != null && tl_navi_time != 0) {
                    var tl_ft_right = ""
                    if (Math.abs(tl_diff_time / tl_navi_time) <= 0.1667) tl_ft_right = "1"
                    else tl_ft_right = "0"
                    json.put("tl_ft_right", tl_ft_right)
                  }
                }
              }
            }

          }
          catch {
            case e: Exception => logger.error(">>>日志转json失败：" + e)
          }
        }
        json
      })
      .persist()
    logger.error(">>>计算后日志量：" + computeRdd.count())
    resultRdd.unpersist()
    (computeRdd, dateList)
  }
}
