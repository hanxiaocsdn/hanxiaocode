package demand.navi;

import java.text.DecimalFormat;

public class MapApiUtil  {

	private static double EARTH_RADIUS = 6378137.0;

	private static DecimalFormat df = new DecimalFormat("0.000000");

	private static double MAP_PI = Math.PI * 3000.0 / 180.0;

	private static double getRad(double d) {
		return d * Math.PI / 180.0;
	}

	public static double getGreatCircleDistance(double lng1, double lat1, double lng2, double lat2) {
		double radLat1 = getRad(lat1);
		double radLat2 = getRad(lat2);

		double dy = radLat1 - radLat2;
		double dx = getRad(lng1) - getRad(lng2);

		double s = 2 * Math.asin(Math.sqrt(
				Math.pow(Math.sin(dy / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(dx / 2), 2)));
		s = s * EARTH_RADIUS;
		s = Math.round(s * 10000) / 10000.0;
		return s;
	}

	public static String[] bd2gd(double bd_x, double bd_y) {
		double x = bd_x - 0.0065, y = bd_y - 0.006;
		double z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * MAP_PI);
		double theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * MAP_PI);
		double[] gd_xy = { 0, 0 };
		gd_xy[0] = z * Math.cos(theta);
		gd_xy[1] = z * Math.sin(theta);
		return new String[] { df.format(gd_xy[0]), df.format(gd_xy[1]) };
	}

	public static String[] gd2bd(double gd_x, double gd_y) {
		double x = gd_x;
		double y = gd_y;
		double z = Math.sqrt(x * x + y * y) + 0.00002 * Math.sin(y * MAP_PI);
		double theta = Math.atan2(y, x) + 0.000003 * Math.cos(x * MAP_PI);
		double[] bd_xy = { 0, 0 };
		bd_xy[0] = z * Math.cos(theta) + 0.0065;
		bd_xy[1] = z * Math.sin(theta) + 0.006;
		return new String[] { df.format(bd_xy[0]), df.format(bd_xy[1]) };
	}

	public static String[] wgs2gd(double wgLon, double wgLat) {
		double pi = 3.141592653589793D;
		double a = 6378245.0D;
		double ee = 0.006693421622965943D;
		double dLat = transformLat(wgLon - 105.0D, wgLat - 35.0D);
		double dLon = transformLon(wgLon - 105.0D, wgLat - 35.0D);
		double radLat = wgLat / 180.0D * pi;
		double magic = Math.sin(radLat);
		magic = 1.0D - ee * magic * magic;
		double sqrtMagic = Math.sqrt(magic);
		dLat = dLat * 180.0D / (a * (1.0D - ee) / (magic * sqrtMagic) * pi);
		dLon = dLon * 180.0D / (a / sqrtMagic * Math.cos(radLat) * pi);
		String[] out = new String[] { "", "" };
		out[1] = String.valueOf(wgLat + dLat);
		out[0] = String.valueOf(wgLon + dLon);
		return out;
	}

	private static double transformLat(double x, double y) {
		double pi = 3.14159265358979324;
		double ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * Math.sqrt(Math.abs(x));
		ret += (20.0 * Math.sin(6.0 * x * pi) + 20.0 * Math.sin(2.0 * x * pi)) * 2.0 / 3.0;
		ret += (20.0 * Math.sin(y * pi) + 40.0 * Math.sin(y / 3.0 * pi)) * 2.0 / 3.0;
		ret += (160.0 * Math.sin(y / 12.0 * pi) + 320 * Math.sin(y * pi / 30.0)) * 2.0 / 3.0;
		return ret;
	}

	private static double transformLon(double x, double y) {
		double pi = 3.14159265358979324;
		double ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * Math.sqrt(Math.abs(x));
		ret += (20.0 * Math.sin(6.0 * x * pi) + 20.0 * Math.sin(2.0 * x * pi)) * 2.0 / 3.0;
		ret += (20.0 * Math.sin(x * pi) + 40.0 * Math.sin(x / 3.0 * pi)) * 2.0 / 3.0;
		ret += (150.0 * Math.sin(x / 12.0 * pi) + 300.0 * Math.sin(x / 30.0 * pi)) * 2.0 / 3.0;
		return ret;
	}
}
