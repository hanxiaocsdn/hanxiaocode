package demand.navi

import demand.utils.DateUtil.getDateStr
import demand.utils.SparkUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @task_id: 596577
 * @description: 定点加油日志解析[+picture] gis_eta_navi_fuel_charging_picture
 * @demander: ft220114 李非龙
 * @author 01418539 caojia
 * @date 2022/12/7 16:42
 */
object NaviParse_naviFuelChargePicture {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processLoadPic(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processLoadPic(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val yes_day = getDateStr(inc_day, -1, "")
    val o_pic_df = spark.sql(
      s"""
         |select get_json_object(data, '$$.carPlate') car_plate,
         | get_json_object(data, '$$.createTm') create_tm,
         | get_json_object(data, '$$.date') `date`,
         | get_json_object(data, '$$.destZoneCode') dest_zonecode,
         | get_json_object(data, '$$.driverId') driver_id,
         | get_json_object(data, '$$.fileName') `filename`,
         | get_json_object(data, '$$.id') id,
         | get_json_object(data, '$$.naviId') navi_id,
         | get_json_object(data, '$$.ossTempUrl') osstemp_url,
         | get_json_object(data, '$$.taskId') task_id,
         | get_json_object(data, '$$.type') `type`,
         | get_json_object(data, '$$.coordinate') `coordinate`,
         | get_json_object(data, '$$.imgType') `imgtype`,
         | get_json_object(data, '$$.photoUploadType') `photouploadtype`,
         | get_json_object(get_json_object(data, '$$.ocrResult'),'$$.Volumn') `volumn`,
         | get_json_object(get_json_object(data, '$$.ocrResult'),'$$.Price') `price`,
         | get_json_object(get_json_object(data, '$$.ocrResult'),'$$.Amount') `amount`,
         | get_json_object(get_json_object(data, '$$.ocrResult'),'$$.Case') `case`,
         | from_unixtime(cast(get_json_object(data, '$$.createTm')/1000 as bigint),'yyyyMMdd') inc_day
         |from dm_gis.gis_navi_oil_pic_log t
         |where inc_day between '$yes_day' and '$inc_day'
         |and from_unixtime(cast(get_json_object(data, '$$.createTm')/1000 as bigint),'yyyyMMdd') between '$yes_day' and '$inc_day'
         |""".stripMargin)
      .filter('task_id.isNotNull && trim('task_id) =!= "")
      .withColumn("task_id_new", 'task_id).drop("task_id")

//    val task_id_new = when('task_id === "0", 'taskserial).otherwise(concat('deptcode, 'task_id))
    val task_id_new = when('task_id === "0", 'taskserial).otherwise('task_id)
    val o_fuel_df = spark.sql(
      s"""
         |select * from dm_gis.gis_eta_navi_fuel_charging_info where inc_day between '$yes_day' and '$inc_day'
         |""".stripMargin)
      .withColumn("task_id_new", task_id_new)

    //按照已有结果表字段排序
    val res_cols = spark.sql("""select * from dm_gis.gis_eta_navi_fuel_oil_with_picture limit 0""").schema.map(_.name).map(col)

    val res_df = o_fuel_df.drop("navi_id").join(o_pic_df, Seq("task_id_new", "inc_day"), "left")
      .select(res_cols: _*)

    writeToHive(spark, res_df.coalesce(5), Seq("inc_day"), "dm_gis.gis_eta_navi_fuel_oil_with_picture")
  }

  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    spark.sqlContext.setConf("hive.exec.dynamic.partition", "true")
    spark.sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }
}
