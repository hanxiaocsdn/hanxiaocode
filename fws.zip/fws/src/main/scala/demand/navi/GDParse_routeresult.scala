package demand.navi

import com.alibaba.fastjson.{JSONArray, JSONObject}
import demand.utils.{DateUtil, HttpClientUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.lang.Math._
import java.text.DecimalFormat
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 424775
 * @description: gis_gd_sdk_route_result
 * @demander:80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/12/27 17:10
 */
object GDParse_routeresult {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 500
  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val compare_track_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }

    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getGDParse_routeresultRdd
    computeRddF = null
    table = "gis_gd_sdk_route_result"
    structs = Array("taskid", "naviid", "reqtime", "datatime", "sdk_ver", "routeid", "req_type", "ak", "starttime", "endtime", "endtype", "startx", "vehicle", "vehicletype", "starty", "endx", "endy", "routetype", "coords", "tracks1", "tracks2", "len", "similarity1", "similarity2", "id", "route_order", "route_time", "trackstart_distance", "trackend_distance")
    keys = Array("taskid", "naviid", "reqtime", "datatime", "sdk_ver", "routeid", "req_type", "ak", "starttime", "endtime", "endtype", "startx", "vehicle", "vehicletype", "starty", "endx", "endy", "routetype", "coords", "tracks1", "tracks2", "len", "similarity1", "similarity2", "id", "route_order", "route_time", "trackstart_distance", "trackend_distance")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }

  /**
   * 解析日志主流程
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  def getGDParse_routeresultRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    val dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    var runDate = ""
    if ("3".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = DateUtil.getDateStr(date, -1)
      }
      else {
        runDate = date
      }
      dateList += runDate
    }

    logger.error(">>>获取" + runDate + "号的Navi关联偏航")
    val sql =
      s"""
         |select taskid,naviid,reqtime,datatime,sdk_ver,routeid,'top3' as req_type,ak,starttime,endtime,endtype,startx,vehicle,vehicletype,starty,endx,endy,routetype,coords,inc_day as inc_date from  dm_gis.gis_gd_sdk_top3_route where inc_day='$date' union all
         |select taskid,naviid,reqtime,datatime,sdk_ver,routeid,'way' as req_type,ak,starttime,endtime,endtype,startx,vehicle,'' as vehicletype,starty,endx,endy,routetype,coords,inc_day as inc_date from  dm_gis.gis_gd_sdk_yaw_route where inc_day='$date'
        """.stripMargin
    val resultRdd = NaviLogParse.getValidJson(spark, sql).persist()
    val sql2 =
      s"""
         |select routeid,tracks1,tracks2,len from dm_gis.gis_gd_sdk_rectify_route where inc_day='$date'
       """.stripMargin
    val resultRdd2 = NaviLogParse.getValidJson(spark, sql2).persist()
    val tmpRdd = resultRdd
      .filter(json => !StringUtils.isEmpty(json.getString("starttime")))
      .map(json => {
        var naviid = "-"
        var routeid = "-"
        var reqtime: java.lang.Long = null
        if (json != null) {
          naviid = json.getString("naviid")
          routeid = json.getString("routeid")
          reqtime = json.getLong("reqtime")
          var _reqtime = "-"
          if (StringUtils.isEmpty(routeid)) routeid = "-"
          if (reqtime == null) _reqtime = "-"
          else _reqtime = reqtime.toString
          var id = routeid + "_" + _reqtime
          json.put("id", id)

          val starttime = json.getLong("starttime")
          val endtime = json.getLong("endtime")
          if (starttime != null && endtime != null) {
            val route_time = endtime - starttime
            json.put("route_time", route_time)
          }
        }
        if (reqtime == null) reqtime = Long.MaxValue
        ((naviid, routeid), (reqtime, json))
      }).
      groupByKey()
      .flatMap(obj => {
        val list = new ArrayBuffer[(String, JSONObject)]()
        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
        for (i <- jsonList.indices) {
          val json = jsonList(i)
          json.put("route_order", i)
          var routeid = json.getString("routeid")
          if (StringUtils.isEmpty(routeid)) routeid = "-"
          val tmp = (routeid, json)
          list += tmp
        }
        list
      })
      .groupByKey()


    val tmpRdd2 = resultRdd2.map(json => {
      var routeid = "-"
      if (json != null) {
        routeid = json.getString("routeid")
        if (StringUtils.isEmpty(routeid)) routeid = "-"
      }
      (routeid, json)
    })

    val computeRdd2 = tmpRdd.leftOuterJoin(tmpRdd2)
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()
        val jsonList1 = obj._2._1.toList
        var json2: JSONObject = null
        if (obj._2._2.nonEmpty) json2 = obj._2._2.get
        if (json2 != null) {
          val tracks1 = json2.getJSONArray("tracks1")
          val tracks2 = json2.getJSONArray("tracks2")
          val len = json2.getString("len")
          for (i <- jsonList1.indices) {
            val json1 = jsonList1(i)
            if (json1 != null) {
              if (len != null) json1.put("len", len)

              val starttime = json1.getLong("starttime")
              val endtime = json1.getLong("endtime")

              val tracks1_new = new JSONArray()
              if (tracks1 != null && tracks1.size() > 0 && starttime != null && endtime != null) {
                var diff_min1 = Long.MaxValue
                var diff_min2 = Long.MaxValue
                var index1 = -1
                var index2 = -1
                breakable(
                  for (j <- 0.until(tracks1.size())) {
                    val track = tracks1.getJSONArray(j)
                    if (track != null && track.size() >= 3) {
                      val tm = track.getLong(2)
                      if (tm != null) {
                        val diff = Math.abs(starttime - tm * 1000)
                        if (diff < diff_min1) {
                          diff_min1 = diff
                          index1 = j
                        }
                        else break
                      }
                    }
                  }
                )

                breakable(
                  for (j <- 1.until(tracks1.size())) {
                    val track = tracks1.getJSONArray(tracks1.size() - j)
                    if (track != null && track.size() >= 3) {
                      val tm = track.getLong(2)
                      if (tm != null) {
                        val diff = Math.abs(endtime - tm * 1000)
                        if (diff < diff_min2) {
                          diff_min2 = diff
                          index2 = tracks1.size() - j
                        }
                        else break
                      }
                    }
                  }
                )

                if (index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks1.size()) {
                  for (j <- index1.until(index2)) {
                    val track = tracks1.getJSONArray(j)
                    if (track != null) {
                      val temp = new JSONArray()
                      for (m <- 0.until(track.size() - 1)) {
                        temp.add(track.getDouble(m))
                      }
                      tracks1_new.add(temp)
                    }
                  }
                }

                if (tracks1_new.size() > 0) json1.put("tracks1", tracks1_new)
              }

              val tracks2_new = new JSONArray()
              if (tracks2 != null && tracks2.size() > 0 && starttime != null && endtime != null) {
                var diff_min1 = Long.MaxValue
                var diff_min2 = Long.MaxValue
                var index1 = -1
                var index2 = -1
                breakable(
                  for (j <- 0.until(tracks2.size())) {
                    val track = tracks2.getJSONArray(j)
                    if (track != null && track.size() >= 3) {
                      val tm = track.getLong(2)
                      if (tm != null) {
                        val diff = Math.abs(starttime - tm * 1000)
                        if (diff < diff_min1) {
                          diff_min1 = diff
                          index1 = j
                        }
                        else break
                      }
                    }
                  }
                )

                breakable(
                  for (j <- 1.until(tracks2.size())) {
                    val track = tracks2.getJSONArray(tracks2.size() - j)
                    if (track != null && track.size() >= 3) {
                      val tm = track.getLong(2)
                      if (tm != null) {
                        val diff = Math.abs(endtime - tm * 1000)
                        if (diff < diff_min2) {
                          diff_min2 = diff
                          index2 = tracks2.size() - j
                        }
                        else break
                      }
                    }
                  }
                )

                if (index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks2.size()) {
                  for (j <- index1.until(index2)) {
                    val track = tracks2.getJSONArray(j)
                    if (track != null) {
                      val temp = new JSONArray()
                      for (m <- 0.until(track.size() - 1)) {
                        temp.add(track.getDouble(m))
                      }
                      tracks2_new.add(temp)
                    }
                  }
                }
                if (tracks2_new.size() > 0) {
                  json1.put("tracks2", tracks2_new)
                  val lastJson = tracks2_new.getJSONArray(tracks2_new.size() - 1)
                  if (lastJson != null && lastJson.size() > 1) {
                    val x = lastJson.getDouble(0)
                    val y = lastJson.getDouble(1)
                    if (x != null && y != null) {
                      val startx = json1.getDouble("startx")
                      val starty = json1.getDouble("starty")
                      val endx = json1.getDouble("endx")
                      val endy = json1.getDouble("endy")
                      if (startx != null && starty != null) {
                        val trackstart_distance = getDistance(x, y, startx, starty)
                        if (trackstart_distance != null) json1.put("trackstart_distance", trackstart_distance)
                      }
                      if (endx != null && endy != null) {
                        val trackend_distance = getDistance(x, y, endx, endy)
                        if (trackend_distance != null) json1.put("trackend_distance", trackend_distance)
                      }
                    }
                  }
                }
              }

              list += json1
            }
          }
        }
        else {
          for (i <- jsonList1.indices) {
            list += jsonList1(i)
          }
        }

        list
      })

    val computeRdd = computeRdd2
      .map(json => {
        if (json != null) {
          val tracks2_new = json.getJSONArray("tracks2")
          val coords = json.getJSONArray("coords")

          if (coords != null && coords.size() > 0 && tracks2_new != null && tracks2_new.size() > 0) {
            val coords2 = new JSONArray()
            for (i <- 0.until(coords.size())) {
              val track = coords.getJSONArray(i)
              if (track != null) {
                val x = track.getDouble(0)
                val y = track.getDouble(1)
                if (x != null && y != null) {
                  val newJson = new JSONObject()
                  newJson.put("x", x)
                  newJson.put("y", y)
                  newJson.put("type", 1)
                  coords2.add(newJson)
                }
              }
            }

            val tracks2_new2 = new JSONArray()
            for (i <- 0.until(tracks2_new.size())) {
              val track = tracks2_new.getJSONArray(i)
              if (track != null) {
                val x = track.getDouble(0)
                val y = track.getDouble(1)
                if (x != null && y != null) {
                  val newJson = new JSONObject()
                  newJson.put("x", x)
                  newJson.put("y", y)
                  newJson.put("type", 1)
                  tracks2_new2.add(newJson)
                }
              }
            }

            val resultObject = accessCompareUrl(json, coords2, tracks2_new2)
            if (resultObject != null) {
              val resultObject2 = resultObject.getJSONObject("result")
              if (resultObject2 != null) {
                val similarity1 = resultObject2.getDouble("similarity1")
                val similarity2 = resultObject2.getDouble("similarity2")
                json.put("similarity1", similarity1)
                json.put("similarity2", similarity2)
              }
            }

          }
        }
        json
      }).coalesce(2)
      .persist()
    logger.error(">>>计算后日志量：" + computeRdd.count())
    resultRdd.unpersist()
    (computeRdd, dateList)
  }

  def accessCompareUrl(json: JSONObject, tracks1: JSONArray, tracks2: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("vehicle", vehicle_type)
    //param.put("compensate", 1)
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("retflag", 5)
    param.put("tracktype", 0)
    param.put("tracks1", tracks1)
    param.put("tracks2", tracks2)
    println("-------------json-------" + json)
    http_result = HttpClientUtil.getJsonByPostJson(compare_track_url, param.toString)
    Thread.sleep(1000)

    http_result
  }

  def getDistance(x1: java.lang.Double, y1: java.lang.Double, x2: java.lang.Double, y2: java.lang.Double): java.lang.Double = {
    var dis: java.lang.Double = null
    try {
      if (x1 == null || y1 == null || x2 == null || y2 == null) dis = null
      else dis = getDistanceFrom2LngLat(x1, y1, x2, y2) * 1000
    }
    catch {
      case e =>
    }
    dis
  }

  def getDistanceFrom2LngLat(lng1: Double, lat1: Double, lng2: Double, lat2: Double): Double = { //将角度转化为弧度
    val radLng1 = radians(lng1)
    val radLat1 = radians(lat1)
    val radLng2 = radians(lng2)
    val radLat2 = radians(lat2)
    val a = radLat1 - radLat2
    val b = radLng1 - radLng2
    2 * asin(sqrt(sin(a / 2) * sin(a / 2) + cos(radLat1) * cos(radLat2) * sin(b / 2) * sin(b / 2))) * 6378.137
  }

  def radians(d: Double): Double = d * Math.PI / 180.0

}
