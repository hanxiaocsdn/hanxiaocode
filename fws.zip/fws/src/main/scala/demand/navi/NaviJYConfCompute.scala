//package demand.navi
//
//import java.net.URLEncoder
//
//import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
//import demand.utils._
//import SaveDataToHive.saveJSONObjectRDDToHive
//import org.apache.commons.codec.digest.DigestUtils
//import org.apache.commons.lang3.StringUtils
//import org.apache.log4j.Logger
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.SparkSession
//import org.apache.spark.storage.StorageLevel
//
//import scala.collection.mutable.ArrayBuffer
//import scala.util.control.Breaks.{break, breakable}
//
//
///**
//  * Created by 01368978 on 20213/22.
//  */
//object NaviJYConfCompute {
//  val appName:String = this.getClass.getSimpleName.replace("$","")
//  val logger:Logger = Logger.getLogger(appName)
//  var compare_track_url="http://gis-lss-xsd.int.sfdc.com.cn:1080/comparetracks"
//
//  var qm_point_url="http://gis-int.int.sfdc.com.cn:1080/rp/qm_point"
//  val r_coords_url = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&ak=e2271c3157124d04950fa59e30c930c4&"
//
//  var isTemp = false
//
//  var repartition = 100
//
//
//
//
//
//
//  /**
//    * 经验配置工艺
//    * @param spark
//    * @param date
//    */
//  def runJYData(spark:SparkSession,date:String): Unit ={
//    logger.error(">>>跑经验配置工艺各接口数据")
//
//    var table = ""
//    var structs:Array[String] = null
//    var keys:Array[String] = null
//
//    val inputRdd = getJYData(spark,date)
//    val resultRdd = runSim(inputRdd)
//
//    table = "gis_navi_jy_conf_run_data"
//    if(isTemp) table = table + "_tmp"
//    structs = Array("reqid","req_order","req_count","status","opt","ft_coords","req_time","dest_citycode","src_deptcode","dest_deptcode","vehicle","vehicle_type","driver_id","actual_time_diff","list_opt","list_coords","x1","y1","x2","y2","height","full_loadweight","width","laodweight","axle_weight","axle_number","vehicle_color","energy","length","emitstand","similarity1","tracks2","rp_tms","eta_sim","R_sim","R_coords","R_routeid","R_src_routeids","M_sim","M_routeid","M_src_routeids","M_param","M_result","M_list","old_inc_day","r_coords_status","r_coords_url","sf_coords")
//    keys = Array("reqid","req_order","req_count","status","opt","ft_coords","req_time","dest_citycode","src_deptcode","dest_deptcode","vehicle","vehicle_type","driver_id","actual_time_diff","list_opt","list_coords","x1","y1","x2","y2","height","full_loadweight","width","laodweight","axle_weight","axle_number","vehicle_color","energy","length","emitstand","similarity1","tracks2","rp_tms","eta_sim","R_sim","R_coords","R_routeid","R_src_routeids","M_sim","M_routeid","M_src_routeids","M_param","M_result","M_list","inc_day","r_coords_status","r_coords_url","sf_coords")
//    saveJSONObjectRDDToHive(spark,resultRdd.repartition(repartition),table,structs,keys,date)
//    resultRdd.unpersist()
//
//
//
//    val resultRdd2 = getRunData1(spark,date)
//
//    val matchRdd = resultRdd2.flatMap(json=>{
//      val list = new ArrayBuffer[JSONObject]()
//      if(json !=null){
//        val M_list = json.getJSONArray("M_list")
//        if(M_list!=null&&M_list.size()>0){
//          for(i<- 0.until(M_list.size())){
//            val jsonObject = M_list.getJSONObject(i)
//            val newJson = new JSONObject()
//            newJson.fluentPutAll(json)
//            if(jsonObject!=null){
//              newJson.put("jy_sim", jsonObject.getString("jy_sim"))
//              newJson.put("jy_frequency", jsonObject.getString("jy_frequency"))
//              newJson.put("jy_routeid", jsonObject.getString("jy_routeid"))
//              newJson.put("jy_src_routeids", jsonObject.getString("jy_src_routeids"))
//            }
//            list += newJson
//          }
//        }
//        else{
//          val newJson = new JSONObject()
//          newJson.fluentPutAll(json)
//          list += newJson
//        }
//      }
//      list
//    }).repartition(6400).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error(">>>matchRdd："+matchRdd.count())
//    resultRdd2.unpersist()
//
//    table = "gis_navi_jy_conf_match"
//    if(isTemp) table = table + "_tmp"
//    structs = Array("reqid","status","req_order","req_count","dest_citycode","dest_deptcode","src_deptcode","vehicle","vehicle_type","req_time","jy_frequency","jy_sim","jy_routeid","jy_src_routeids","old_inc_day")
//    keys = Array("reqid","status","req_order","req_count","dest_citycode","dest_deptcode","src_deptcode","vehicle","vehicle_type","req_time","jy_frequency","jy_sim","jy_routeid","jy_src_routeids","old_inc_day")
//    saveJSONObjectRDDToHive(spark,matchRdd.repartition(repartition),table,structs,keys,date)
//    matchRdd.unpersist()
//
//
//  }
//
//
//  /**
//    * 获取关联的JY数据
//    * @param spark
//    * @param date
//    * @return
//    */
//  def getJYData(spark:SparkSession, date:String): RDD[JSONObject] ={// and dest_citycode in ('755','020','769') and dest_deptcode='755WE'
//    var sql = ""
//    if(isTemp) {
//      val citystr = "('" + NaviJYConf.citycodes.mkString("\',\'") + "')"
//      sql =
//        s"""
//           |select a.dest_citycode,a.src_deptcode,a.dest_deptcode,a.similarity1,a.tracks2,b.reqid,b.req_order,b.inc_day,b.req_count,b.status,b.opt,b.req_time,b.vehicle,b.vehicle_type,b.driver_id,b.actual_time_diff,b.x1,b.y1,b.x2,b.y2,b.height,b.full_loadweight,b.width,b.laodweight,b.axle_weight,b.axle_number,b.vehicle_color,b.energy,b.length,b.emitstand from
//           |(select id,dest_citycode,src_deptcode,dest_deptcode,similarity1,tracks2 from dm_gis.gis_navi_eta_result2 where inc_day='$date' and src_deptcode!='0' and dest_deptcode!='0' and dest_citycode in $citystr) a
//           |left join (select id,task_id as reqid,req_order,inc_day,req_count,status,opt,concat(from_unixtime(bigint(req_time/1000),'yyyy-MM-dd HH:mm:ss'),' 000') as req_time,vehicle,vehicle_type,driver_id,cast(navi_time*1000 as string) as actual_time_diff,x1,y1,x2,y2,height,weight as full_loadweight,width,mload as laodweight,axle_weight,axle_number,plate_color as vehicle_color,energy,length,emit_stand as emitstand from dm_gis.gis_navi_eta_result1 t where inc_day='$date' and opt = 'top3') b on a.id=b.id
//           |where opt='top3'
//       """.stripMargin
//    }
//    else{
//      sql =
//        s"""
//           |select a.dest_citycode,a.src_deptcode,a.dest_deptcode,a.similarity1,a.tracks2,b.reqid,b.req_order,b.inc_day,b.req_count,b.status,b.opt,b.req_time,b.vehicle,b.vehicle_type,b.driver_id,b.actual_time_diff,b.x1,b.y1,b.x2,b.y2,b.height,b.full_loadweight,b.width,b.laodweight,b.axle_weight,b.axle_number,b.vehicle_color,b.energy,b.length,b.emitstand from
//           |(select id,dest_citycode,src_deptcode,dest_deptcode,similarity1,tracks2 from dm_gis.gis_navi_eta_result2 where inc_day='$date' and src_deptcode!='0' and dest_deptcode!='0') a
//           |left join (select id,task_id as reqid,req_order,inc_day,req_count,status,opt,concat(from_unixtime(bigint(req_time/1000),'yyyy-MM-dd HH:mm:ss'),' 000') as req_time,vehicle,vehicle_type,driver_id,cast(navi_time*1000 as string) as actual_time_diff,x1,y1,x2,y2,height,weight as full_loadweight,width,mload as laodweight,axle_weight,axle_number,plate_color as vehicle_color,energy,length,emit_stand as emitstand from dm_gis.gis_navi_eta_result1 t where inc_day='$date' and opt = 'top3') b on a.id=b.id
//           |where opt='top3'
//       """.stripMargin
//    }
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//
//    resultRdd
//  }
//
//
//  /**
//    * 计算eta_sim、R_sim、R_routeid、M_sim、M_routeid
//    * @param inputRdd
//    */
//  def runSim(inputRdd: RDD[JSONObject]): RDD[JSONObject] ={
//    logger.error(">>>计算eta_sim、R_sim、R_routeid、M_sim、M_routeid")
//    val fieldRdd = inputRdd.map(json=>{
//      val reqid = json.getString("reqid")
//      val req_order = json.getString("req_order")
//
//      val req_time = json.getString("req_time")
//      var rp_tms = ""
//      if(!StringUtils.isEmpty(req_time)){
//        rp_tms = req_time.replaceAll("-","").replaceAll(":","").replaceAll(" ","")
//        if(req_time.length >= 10)
//          rp_tms = rp_tms.substring(8,10)
//        else rp_tms = ""
//        if(!StringUtils.isEmpty(rp_tms)){
//          val rp_tms_int:java.lang.Integer = rp_tms.toInt
//          if(rp_tms_int != null){
//            rp_tms = "%02d".format(rp_tms_int) + "00-" + "%02d".format(rp_tms_int + 1) + "00"
//          }
//        }
//      }
//      json.put("rp_tms",rp_tms)
//
////      val opt = json.getString("opt")
////      val list_opt = json.getString("list_opt")
////      if(!"sf2".equalsIgnoreCase(opt)){
////        if("sf2".equalsIgnoreCase(list_opt)) json.put("ft_coords", json.getString("list_coords"))
////      }
////
////      //获取ETA相似度（eta_sim）
////      val tracks2_str = json.getString("tracks2")
////      val tracks2Params = getCoordsParam(tracks2_str)
////      var eta_sim = ""
////      if("sf2".equalsIgnoreCase(opt)){
////        eta_sim = json.getString("similartity1")
////      }
////      else{
////        val ft_coords_params = getCoordsParam(json.getString("ft_coords"))
////        if(tracks2Params!=null &&ft_coords_params!=null){
////          val result1 = accessCompareUrl(json,tracks2Params,ft_coords_params,"")
////          if(result1!=null){
////            eta_sim =  result1.getString("similarity1")
////          }
////        }
////      }
////      json.put("eta_sim",eta_sim)
//
//      var eta_sim = ""
//      var sf_coords = ""
//      val jsonObject1 = getR_coords1(json)
//      if(jsonObject1 != null){
////        val status = jsonObject1.getString("status")
////        json.put("r_coords_status",status)
////        if(StringUtils.isEmpty(status) || "1".equalsIgnoreCase(status)){
////        }
////        else json.remove("r_coords_url")
//
//        val resultObject = jsonObject1.getJSONObject("result")
//        if(resultObject!=null){
//          sf_coords = resultObject.getString("coords")
//        }
//      }
//
//      val tracks2_str = json.getString("tracks2")
//      val tracks2Params = getCoordsParam(tracks2_str)
//
//      val sf_coords_params = getCoordsParam(sf_coords)
//      if(tracks2Params!=null &&sf_coords_params!=null){
//        val result2 = accessCompareUrl(json,tracks2Params,sf_coords_params,"")
//        if(result2!=null){
//          eta_sim =  result2.getString("similarity1")
//        }
//      }
//
//      json.put("sf_coords",sf_coords)
//      json.put("eta_sim",eta_sim)
//      (reqid,(req_order,json))
//    })
//      .groupByKey()
//      .map(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
//        for(i <- jsonList.indices){
//          list += jsonList(i)
//        }
//        list
//      })
//      .map(list=>{
//        try {
//          var R_sim:java.lang.Double = null
//          var R_coords:java.lang.String = ""
//          var R_routeid = ""
//          var R_src_routeids = ""
//
//          for(i <- list.indices){
//            val json = list(i)
//            if(json!=null){
//              if("1".equalsIgnoreCase(json.getString("req_order"))){
//                val tracks2_str = json.getString("tracks2")
//                val tracks2Params = getCoordsParam(tracks2_str)
//
//                //跑经验路径规划获取相似度(R_sim)
//                val jsonObject1 = getR_coords2(json)
//                if(jsonObject1 != null){
//                  val status = jsonObject1.getString("status")
//                  json.put("r_coords_status",status)
//                  if(StringUtils.isEmpty(status) || "1".equalsIgnoreCase(status)){
//                  }
//                  else json.remove("r_coords_url")
//
//                  val results = new ArrayBuffer[(java.lang.Double,String,String,String)]()
//                  val resultObject = jsonObject1.getJSONObject("result")
//                  val list = resultObject.getJSONArray("list")
//                  if(list!=null && list.size()>0){
//                    breakable(
//                      for(j<-0.until(list.size())){
//                        val el = list.getJSONObject(j)
//                        if(el!=null){
//                          val coords = el.getString("coords")
//                          val routeid = el.getString("route_id")
//                          val src_routeids = el.getString("src_routeids")
//                          if(!StringUtils.isEmpty(coords)){
//                            val R_coords_params = getCoordsParam(coords)
//                            if(tracks2Params!=null &&R_coords_params!=null){
//                              val result2 = accessCompareUrl(json,tracks2Params,R_coords_params,"")
//                              if(result2!=null){
//                                val sim =  result2.getDouble("similarity1")
//                                if(sim!=null){
//                                  val temp = (sim,coords,routeid,src_routeids)
//                                  results += temp
//                                  if(sim >= 0.99){
//                                    R_sim = sim
//                                    R_coords = coords
//                                    R_routeid = routeid
//                                    R_src_routeids = src_routeids
//                                    break
//                                  }
//                                }
//                              }
//                            }
//                          }
//                        }
//                      }
//                    )
//                  }
//
//                  if(results.nonEmpty){
//                    val results2 = results.sortBy(_._1).reverse
//                    val head = results2.head
//
//                    json.put("R_sim",head._1)
//                    json.put("R_coords",head._2)
//                    json.put("R_routeid",head._3)
//                    json.put("R_src_routeids",head._4)
//                  }
//                }
//              }
//            }
//          }
//
//          if(R_sim!=null && R_sim >= 0.99){
//            for(i <- list.indices){
//              val json = list(i)
//              json.put("R_sim",R_sim)
//              json.put("R_coords",R_coords)
//              json.put("R_routeid",R_routeid)
//              json.put("R_src_routeids",R_src_routeids)
//            }
//          }
//          else{
//            for(i <- list.indices){
//              val json = list(i)
//              if(json!=null){
//                if(!"1".equalsIgnoreCase(json.getString("req_order"))){
////                  R_sim = null
////                  R_coords = ""
////                  R_routeid = ""
////                  R_src_routeids = ""
//                  val tracks2_str = json.getString("tracks2")
//                  val tracks2Params = getCoordsParam(tracks2_str)
//
//                  //跑经验路径规划获取相似度(R_sim)
//                  val jsonObject1 = getR_coords2(json)
//                  if(jsonObject1 != null){
//                    val status = jsonObject1.getString("status")
//                    json.put("r_coords_status",status)
//                    if(StringUtils.isEmpty(status) || "1".equalsIgnoreCase(status)){
//                    }
//                    else json.remove("r_coords_url")
//
//                    val results = new ArrayBuffer[(java.lang.Double,String,String,String)]()
//                    val resultObject = jsonObject1.getJSONObject("result")
//                    val list = resultObject.getJSONArray("list")
//                    if(list!=null && list.size()>0){
//                      breakable(
//                        for(j<-0.until(list.size())){
//                          val el = list.getJSONObject(j)
//                          if(el!=null){
//                            val coords = el.getString("coords")
//                            val routeid = el.getString("route_id")
//                            val src_routeids = el.getString("src_routeids")
//                            if(!StringUtils.isEmpty(coords)){
//                              val R_coords_params = getCoordsParam(coords)
//                              if(tracks2Params!=null &&R_coords_params!=null){
//                                val result2 = accessCompareUrl(json,tracks2Params,R_coords_params,"")
//                                if(result2!=null){
//                                  val sim =  result2.getDouble("similarity1")
//                                  if(sim!=null){
//                                    val temp = (sim,coords,routeid,src_routeids)
//                                    results += temp
//                                    if(sim >= 0.99){
//                                      break
//                                    }
//                                  }
//                                }
//                              }
//                            }
//                          }
//                        }
//                      )
//                    }
//
//                    if(results.nonEmpty){
//                      val results2 = results.sortBy(_._1).reverse
//                      val head = results2.head
//
//                      json.put("R_sim",head._1)
//                      json.put("R_coords",head._2)
//                      json.put("R_routeid",head._3)
//                      json.put("R_src_routeids",head._4)
//                    }
//                  }
//                }
//              }
//            }
//          }
//
//        } catch {
//          case e:Exception =>{
//            logger.error(">>>计算字段异常"+e)
//          }
//        }
//        list
//      })
//      .flatMap(list=>{
//        try {
//          var M_sim = ""
//          var M_routeid = ""
//          var M_src_routeids = ""
//          var M_param = ""
//          var M_result = ""
//          var M_list = new JSONArray()
//
//          for(i <- list.indices){
//            val json = list(i)
//            if(json!=null){
//              if("1".equalsIgnoreCase(json.getString("req_order"))){
//                val tmp_list = new ArrayBuffer[JSONObject]()
//                val paths = getM_sim(json)
//                M_param = json.getString("param")
//                M_result = json.getString("http_result")
//
//                //求M_list、tmp_list
//                if(paths !=null && paths.size()>0){
//                  for(i<- 0.until(paths.size())){
//                    val newJson = new JSONObject()
//                    val jsonObject = paths.getJSONObject(i)
//                    if(jsonObject!=null){
//                      val sim = jsonObject.getDouble("sim")
//                      val frequency = jsonObject.getInteger("frequency")
//                      val route_id = jsonObject.getString("route_id")
//                      val src_routeids = jsonObject.getString("src_routeids")
//                      newJson.put("jy_sim", sim)
//                      newJson.put("jy_frequency", frequency)
//                      newJson.put("jy_routeid", route_id)
//                      newJson.put("jy_src_routeids", src_routeids)
//
//                      M_list.add(newJson)
//                      tmp_list += newJson
//                    }
//                  }
//                }
//
//                //求M_sim、M_routeid、M_src_routeids
//                if(tmp_list!=null && tmp_list.size>0) {
//                  val firstJson = tmp_list.sortBy(_.getIntValue("jy_frequency")).reverse.sortBy(_.getDouble("jy_sim")).reverse.head
//                  M_sim = firstJson.getString("jy_sim")
//                  M_routeid = firstJson.getString("jy_routeid")
//                  M_src_routeids = firstJson.getString("jy_src_routeids")
//                }
//
//                //保存各字段
//                json.put("M_sim", M_sim)
//                json.put("M_routeid", M_routeid)
//                json.put("M_src_routeids", M_src_routeids)
//                json.put("M_param", M_param)
//                json.put("M_result", M_result)
//                json.put("M_list", M_list)
//              }
//            }
//          }
//
//          if(!StringUtils.isEmpty(M_sim) && M_sim.toDouble >= 0.99){
//            for(i <- list.indices){
//              val json = list(i)
//              if(json!=null){
//                if(!"1".equalsIgnoreCase(json.getString("req_order"))){
//                  //保存各字段
//                  json.put("M_sim", M_sim)
//                  json.put("M_routeid", M_routeid)
//                  json.put("M_src_routeids", M_src_routeids)
//                  json.put("M_param", M_param)
//                  json.put("M_result", M_result)
//                  json.put("M_list", M_list)
//                }
//              }
//            }
//          }
//          else{
//            for(i <- list.indices){
//              val json = list(i)
//              if(json!=null){
//                if(!"1".equalsIgnoreCase(json.getString("req_order"))){
//                  M_sim = ""
//                  M_routeid = ""
//                  M_src_routeids = ""
//                  M_param = ""
//                  M_result = ""
//                  M_list = new JSONArray()
//
//                  val tmp_list = new ArrayBuffer[JSONObject]()
//                  val paths = getM_sim(json)
//                  M_param = json.getString("param")
//                  M_result = json.getString("http_result")
//
//                  //求M_list、tmp_list
//                  if(paths !=null && paths.size()>0){
//                    for(i<- 0.until(paths.size())){
//                      val newJson = new JSONObject()
//                      val jsonObject = paths.getJSONObject(i)
//                      if(jsonObject!=null){
//                        val sim = jsonObject.getDouble("sim")
//                        val frequency = jsonObject.getInteger("frequency")
//                        val route_id = jsonObject.getString("route_id")
//                        val src_routeids = jsonObject.getString("src_routeids")
//                        newJson.put("jy_sim", sim)
//                        newJson.put("jy_frequency", frequency)
//                        newJson.put("jy_routeid", route_id)
//                        newJson.put("jy_src_routeids", src_routeids)
//
//                        M_list.add(newJson)
//                        tmp_list += newJson
//                      }
//                    }
//                  }
//
//                  //求M_sim、M_routeid、M_src_routeids
//                  if(tmp_list!=null && tmp_list.size>0) {
//                    val firstJson = tmp_list.sortBy(_.getIntValue("jy_frequency")).reverse.sortBy(_.getDouble("jy_sim")).reverse.head
//                    M_sim = firstJson.getString("jy_sim")
//                    M_routeid = firstJson.getString("jy_routeid")
//                    M_src_routeids = firstJson.getString("jy_src_routeids")
//                  }
//
//                  //保存各字段
//                  json.put("M_sim", M_sim)
//                  json.put("M_routeid", M_routeid)
//                  json.put("M_src_routeids", M_src_routeids)
//                  json.put("M_param", M_param)
//                  json.put("M_result", M_result)
//                  json.put("M_list", M_list)
//                }
//              }
//            }
//          }
//
//        } catch {
//          case e:Exception =>{
//            logger.error(">>>计算字段异常"+e)
//          }
//        }
//        list
//      }).repartition(3200).persist()
//    logger.error(">>>计算eta_sim、R_sim、R_routeid、M_sim、M_routeid后的数据量："+fieldRdd.count())
//    inputRdd.unpersist()
//
//    fieldRdd
//  }
//
//
//  /**
//    * 获取关联的JY数据
//    * @param spark
//    * @param date
//    * @return
//    */
//  def getRunData1(spark:SparkSession, date:String): RDD[JSONObject] ={
//    var table = "gis_navi_jy_conf_run_data"
//    if(isTemp) table = table + "_tmp"
//    var sql =
//      s"""
//         |select reqid,status,req_order,req_count,dest_citycode,dest_deptcode,src_deptcode,vehicle,vehicle_type,req_time,old_inc_day,M_list from dm_gis.$table where inc_day='$date'
//       """.stripMargin
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//
//    resultRdd
//  }
//
//
//  /**
//    * 经验配置工艺
//    * @param spark
//    * @param date
//    */
//  def computeJYData(spark:SparkSession,date:String,i:String): Unit ={
//    logger.error(">>>获取跑接口后的数据")
//
//    var table = ""
//    var structs:Array[String] = null
//    var keys:Array[String] = null
//
//
//    if(!"all".equalsIgnoreCase(i)){
//      val endDate = date
//      var startDate =  DateUtil.getDateStr(endDate,-29)
//      if("2".equalsIgnoreCase(i)) startDate =  DateUtil.getDateStr(endDate,-14)
//      val inputRdd = getRunData(spark,startDate,endDate)
//
////    for(i<-1.until(6)){//7
//      logger.error(">>>跑分组类型："+i.toString)
//      var confTypeRdd = computeConfTypeNew(inputRdd, i.toString)
//      val failedRdd = confTypeRdd.filter(obj => "sf".equalsIgnoreCase(obj._1))
//        .flatMap(_._2).repartition(6400).persist()
//      logger.error(">>>failedRdd："+failedRdd.count())
//      val successRdd = confTypeRdd.filter(obj => !"sf".equalsIgnoreCase(obj._1))
//        .flatMap(_._2).repartition(6400).persist()
//      logger.error(">>>successRdd："+successRdd.count())
//      confTypeRdd.unpersist()
//
//      var sRdd:RDD[JSONObject] = null
//      if(successRdd != null && failedRdd !=null) {
//        sRdd = successRdd.union(failedRdd).repartition(6400).persist()
//        logger.error(">>>sRdd："+sRdd.count())
//        successRdd.unpersist()
//        failedRdd.unpersist()
//
//        val fieldRdd = computeFilter(sRdd)
//        logger.error(">>>跑经验配置工艺后的数据量："+fieldRdd.count())
//        sRdd.unpersist()
//        table = "gis_navi_jy_conf_result_all" + i.toString
//        if(isTemp) table = table+ "_tmp"
//        structs = Array("reqid","req_order","req_count","status","opt","ft_coords","req_time","dest_citycode","src_deptcode","dest_deptcode","vehicle","vehicle_type","driver_id","actual_time_diff","list_opt","list_coords","x1","y1","x2","y2","height","full_loadweight","width","laodweight","axle_weight","axle_number","vehicle_color","energy","length","emitstand","similarity1","tracks2","rp_tms","eta_sim","R_sim","R_coords","R_routeid","R_src_routeids","M_sim","M_routeid","M_src_routeids","M_param","M_result","M_list","group_type","group_id","group_cnt","eta_sim_cnt","eta_sim_per","R_sim_cnt","R_sim_per","S_cnt","routeid_max_cnt","routeid_max","routeid_sim_per","conf_type","jy_roadID","out_flag","id","id_norptms","old_inc_day","routeid_group")
//        keys = Array("reqid","req_order","req_count","status","opt","ft_coords","req_time","dest_citycode","src_deptcode","dest_deptcode","vehicle","vehicle_type","driver_id","actual_time_diff","list_opt","list_coords","x1","y1","x2","y2","height","full_loadweight","width","laodweight","axle_weight","axle_number","vehicle_color","energy","length","emitstand","similarity1","tracks2","rp_tms","eta_sim","r_sim","r_coords","r_routeid","r_src_routeids","m_sim","m_routeid","m_src_routeids","m_param","m_result","m_list","group_type","group_id","group_cnt","eta_sim_cnt","eta_sim_per","r_sim_cnt","r_sim_per","s_cnt","routeid_max_cnt","routeid_max","routeid_sim_per","conf_type","jy_roadid","out_flag","id","id_norptms","inc_day","routeid_group")
//        saveJSONObjectRDDToHive(spark,fieldRdd.repartition(repartition),table,structs,keys,date)
//
//        val resultRdd = fieldRdd
//          .filter(json => "true".equalsIgnoreCase(json.getString("out_flag")))
//          .groupBy(json=> json.getString("id"))
//          .map(obj=>{
//            var row:JSONObject = null
//            if(obj._2.size > 0){
//              row = obj._2.toList(0)
//            }
//            row
//          })
//          .filter(_!=null)
//          .repartition(6400)
//          .persist()
//        logger.error(">>>跑经验路径工艺的收尾计算并过滤后的数据量："+resultRdd.count())
//        fieldRdd.unpersist()
//
//        table = "gis_navi_jy_conf_final" + i.toString
//        if(isTemp) table = table+ "_tmp"
//        structs = Array("id","id_norptms","conftype","dest_city","dest_deptcode","driver_id","vehicle","rp_tms","vehicle_type","line","opt_type","jy_roadID","ritcDur","routeid_group")
//        keys = Array("id","id_norptms","conftype","dest_city","dest_deptcode","driver_id","vehicle","rp_tms","vehicle_type","line","opt_type","jy_roadid","ritcdur","routeid_group")
//        saveJSONObjectRDDToHive(spark,resultRdd.repartition(repartition),table,structs,keys,date)
//
//        resultRdd.unpersist()
//      }
//
////    }
//
//      inputRdd.unpersist()
//
//    }
//    else{
//      val resultRdd = getFinalData(spark,date)
//      logger.error(">>>各分组合并后的数据量："+resultRdd.count())
//      table = "gis_eta_jy_conf_final"//gis_navi_jy_conf_final
//      if(isTemp) table = table+ "_tmp"
//      val d = "d"
//      structs = Array("id","id_norptms","conftype","dest_city","dest_deptcode","driver_id","vehicle","rp_tms","vehicle_type","line","opt_type","jy_roadID","ritcDur","routeid_group")
//      keys = Array("id","id_norptms","conftype","dest_city","dest_deptcode","driver_id","vehicle","rp_tms","vehicle_type","line","opt_type","jy_roadid","ritcdur","routeid_group")
//      saveJSONObjectRDDToHive(spark,resultRdd.repartition(repartition),table,structs,keys,date + d)
//      resultRdd.unpersist()
//    }
//
//
//
//  }
//
//
//  /**
//    * 获取各分组合并后的数据
//    * @param spark
//    * @param date
//    * @return
//    */
//  def getFinalData(spark:SparkSession, date:String): RDD[JSONObject] ={
//    var tmp = ""
//    if(isTemp) tmp = "_tmp"
//    var sql =
//      s"""
//         |select id,id_norptms,conftype,dest_city,dest_deptcode,driver_id,vehicle,rp_tms,vehicle_type,line,opt_type,jy_roadID,ritcDur,routeid_group from dm_gis.gis_navi_jy_conf_final1$tmp where inc_day='$date' union all
//         |select id,id_norptms,conftype,dest_city,dest_deptcode,driver_id,vehicle,rp_tms,vehicle_type,line,opt_type,jy_roadID,ritcDur,routeid_group from dm_gis.gis_navi_jy_conf_final2$tmp where inc_day='$date' union all
//         |select id,id_norptms,conftype,dest_city,dest_deptcode,driver_id,vehicle,rp_tms,vehicle_type,line,opt_type,jy_roadID,ritcDur,routeid_group from dm_gis.gis_navi_jy_conf_final3$tmp where inc_day='$date' union all
//         |select id,id_norptms,conftype,dest_city,dest_deptcode,driver_id,vehicle,rp_tms,vehicle_type,line,opt_type,jy_roadID,ritcDur,routeid_group from dm_gis.gis_navi_jy_conf_final4$tmp where inc_day='$date' union all
//         |select id,id_norptms,conftype,dest_city,dest_deptcode,driver_id,vehicle,rp_tms,vehicle_type,line,opt_type,jy_roadID,ritcDur,routeid_group from dm_gis.gis_navi_jy_conf_final5$tmp where inc_day='$date'
//       """.stripMargin
////    union all
////    select id,id_norptms,conftype,dest_city,dest_deptcode,driver_id,vehicle,rp_tms,vehicle_type,line,opt_type,jy_roadID,ritcDur from dm_gis.gis_navi_jy_conf_final6 where inc_day='$date'
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//
//    resultRdd
//  }
//
//
//  /**
//    * 获取关联的JY数据
//    * @param spark
//    * @param startDate
//    * @param endDate
//    * @return
//    */
//  def getRunData(spark:SparkSession, startDate:String, endDate:String): RDD[JSONObject] ={
//    var table = "gis_navi_jy_conf_run_data"
//    if(isTemp) table = table + "_tmp"
//    var sql =
//      s"""
//        select * from dm_gis.gis_navi_jy_conf_run_data where inc_day between '$startDate' and '$endDate'
//       """.stripMargin
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//
//    resultRdd
//  }
//
//
//  /**
//    * 计算conf_type
//    * @param inputRdd
//    */
//  def computeConfTypeNew(inputRdd: RDD[JSONObject], group_type: String): RDD[(String, scala.Iterable[JSONObject])] ={
//    logger.error(">>>计算conf_type")
//    val fieldRdd = inputRdd.map(json=>{
//      var group_id = "-"
//      try {
//        if(json!=null){
//          json.remove("group_type")
//          json.remove("group_id")
//          json.remove("group_cnt")
//          json.remove("eta_sim_cnt")
//          json.remove("eta_sim_per")
//          json.remove("r_sim_cnt")
//          json.remove("r_sim_per")
//          json.remove("s_cnt")
//          json.remove("routeid_max_cnt")
//          json.remove("routeid_max")
//          json.remove("routeid_sim_per")
//          json.remove("conf_type")
//          json.remove("jy_roadid")
//          json.remove("routeid_group")
//
//          group_id = getGroupId(json,group_type)
//          json.put("group_type",group_type)
//          json.put("group_id",group_id)
//        }
//      } catch {
//        case e:Exception =>logger.error(">>>计算字段异常"+e)
//      }
//      (group_id, json)
//    })
//      .groupByKey()
//      .map(obj=>{
//        val group_id = obj._1
//
//        var list: List[JSONObject] = obj._2.toList
//        val tmp_json = list.head
//        val group_type = tmp_json.getString("group_type")
//        val group_cnt = list.size
//
//        val eta_sim_cnt = list.filter(json => json.getDouble("eta_sim") != null && json.getDouble("eta_sim") >= 0.9).size
//        var eta_sim_per = 0.0
//        if(group_cnt > 0) eta_sim_per = eta_sim_cnt.toDouble / group_cnt.toDouble
//        val R_sim_cnt = list.filter(json => json.getDouble("r_sim") != null && json.getDouble("r_sim") >= 0.9).size
//        var R_sim_per = 0.0
//        if(group_cnt > 0) R_sim_per = R_sim_cnt.toDouble / group_cnt.toDouble
//        val S_cnt = R_sim_cnt - eta_sim_cnt
//
//        var routeid_max_cnt = 0
//        var routeid_max = ""
//        var routeid_sim_per = 0.0
//
//        var conf_type = ""
//        var jy_roadID = ""
//        var routeid_group = ""
//        if(eta_sim_per == 1 || R_sim_per == 1){
//          if(R_sim_per == 1){
//            conf_type = "jy"
//          }
//          //          else if(eta_sim_per == 1){
//          //            conf_type = "sf"
//          //          }
//        }
//        else{
//          conf_type = "sf"
//        }
//
//        if("sf".equalsIgnoreCase(conf_type)){
//          val routeids_all = new ArrayBuffer[String]()
//          obj._2.filter(o=> (!StringUtils.isEmpty(o.getString("r_sim"))
//            && o.getString("r_sim").toDouble>=0.9)
//            || (!StringUtils.isEmpty(o.getString("m_sim"))
//            && o.getString("m_sim").toDouble>=0.9))
//            .foreach(json=>{
//              val routeids = new ArrayBuffer[String]()
//              val matchList:JSONArray = json.getJSONArray("m_list")
//              val R_src_routeids = json.getString("r_src_routeids")
//              if(!StringUtils.isEmpty(R_src_routeids)){
//                val tmp_ruouteids = R_src_routeids.split(",")
//                routeids ++= tmp_ruouteids
//              }
//              if(matchList!=null && matchList.size()>0){
//                for(i<- 0.until(matchList.size())){
//                  val matchJson = matchList.getJSONObject(i)
//                  val jy_src_routeids = matchJson.getString("jy_src_routeids")
//                  if(!StringUtils.isEmpty(jy_src_routeids)){
//                    val tmp_ruouteids = jy_src_routeids.split(",")
//                    routeids ++= tmp_ruouteids
//                  }
//                }
//              }
//              routeids_all ++= routeids.toSet
//            })
//
//          var routeidmaxs = new ArrayBuffer[String]()
//          var routeids_order: Array[(Int, String)] = null
//          if(routeids_all.nonEmpty){
//            routeids_order = routeids_all.map{(_,1)}.groupBy{_._1}.map{case(k,v) => (v.size,k)}.toArray.sortBy{_._1}.reverse
//            routeid_max_cnt = routeids_order.head._1
//            routeid_max = routeids_order.head._2
//            if(group_cnt > 0) routeid_sim_per = routeid_max_cnt.toDouble / group_cnt.toDouble
//
//            routeidmaxs += routeid_max
//            if(routeids_order.length > 1){
//              routeidmaxs += routeids_order(1)._2
//            }
//            if(routeids_order.length > 2){
//              routeidmaxs += routeids_order(2)._2
//            }
//          }
//
//          routeid_group = routeidmaxs.mkString(",")
//
//          if(routeid_sim_per > R_sim_per && routeid_sim_per > eta_sim_per){
//            if("1".equalsIgnoreCase(group_type) || "2".equalsIgnoreCase(group_type)){
//              if(routeid_sim_per >= 0.8){
//                conf_type = "jyid"
//                jy_roadID = routeid_max
//              }
//              else{
//                conf_type = "sf"
//                jy_roadID = ""
//              }
//            }
//            else{
//              conf_type = "jyid"
//              jy_roadID = routeid_max
//            }
//          }
//          else if(R_sim_per > eta_sim_per){
//            if("1".equalsIgnoreCase(group_type) || "2".equalsIgnoreCase(group_type)){
//              if(R_sim_per >= 0.8){
//                conf_type = "jy"
//                jy_roadID = ""
//              }
//              else{
//                conf_type = "sf"
//                jy_roadID = ""
//              }
//            }
//            else{
//              conf_type = "jy"
//              jy_roadID = ""
//            }
//          }
//          else{
//            conf_type = "sf"
//            jy_roadID = ""
//          }
//        }
//
//        obj._2.foreach(json=>{
//          json.put("group_cnt",group_cnt)
//          json.put("eta_sim_cnt",eta_sim_cnt)
//          json.put("eta_sim_per",eta_sim_per)
//          json.put("r_sim_cnt",R_sim_cnt)
//          json.put("r_sim_per",R_sim_per)
//          json.put("s_cnt",S_cnt)
//          json.put("routeid_max_cnt",routeid_max_cnt)
//          json.put("routeid_max",routeid_max)
//          json.put("routeid_sim_per",routeid_sim_per)
//          json.put("conf_type",conf_type)
//          json.put("jy_roadid",jy_roadID)
//          json.put("routeid_group", routeid_group)
//        })
//        (conf_type,obj._2)
//      })
//      .repartition(6400).persist()
//    logger.error(">>>计算conf_type后的数据量："+fieldRdd.count())
//    inputRdd.unpersist()
//
//    fieldRdd
//  }
//
//
//  /**
//    * 收尾计算并过滤
//    * @param inputRdd
//    */
//  def computeFilter(inputRdd: RDD[JSONObject]): RDD[JSONObject] ={
//    logger.error(">>>跑经验路径工艺的收尾计算并过滤")
//    val fieldRdd = inputRdd
//      .map(json=>{
//        try {
//          if(json!=null){
//            val conf_type = json.getString("conf_type")
//            if(!"sf".equalsIgnoreCase(conf_type) && !StringUtils.isEmpty(conf_type)){
//              var group_type = json.getString("group_type")
//              var R_sim_per = json.getDouble("r_sim_per")
//              val S_cnt = json.getInteger("s_cnt")
//
//              var flag = false
//              if("5".equalsIgnoreCase(group_type)){
//                if(R_sim_per != null && R_sim_per >= 0.8){
//                  flag = true
//                }
//              }
//              else{
//                flag = true
//                //                if(S_cnt != null && S_cnt > 3){
//                //                  flag = true
//                //                }
//              }
//              if(flag){
//                if("1".equalsIgnoreCase(group_type)){
//                  json.put("vehicle_type","")
//                }
//                if("2".equalsIgnoreCase(group_type)){
//                  json.put("vehicle_type","")
//                  json.put("rp_tms","")
//                }
//                else if("3".equalsIgnoreCase(group_type)){
//                  json.put("vehicle_type","")
//                  json.put("vehicle","")
//                }
//                else if("4".equalsIgnoreCase(group_type)){
//                  json.put("vehicle_type","")
//                  json.put("driver_id","")
//                }
//                else if("5".equalsIgnoreCase(group_type)){
//                  json.put("vehicle_type","")
//                  json.put("vehicle","")
//                  json.put("driver_id","")
//                }
//                else if("6".equalsIgnoreCase(group_type)){
//                  json.put("vehicle_type","")
//                  json.put("vehicle","")
//                  json.put("driver_id","")
//                  json.put("rp_tms","")
//                }
//
//                if("sf".equalsIgnoreCase(conf_type)){
//                  json.put("jy_roadid","")
//                }
//                else if("jy".equalsIgnoreCase(conf_type)){
//                  json.put("jy_roadid","")
//                }
//
//                var conftype = "3"
//                var dest_citycode = json.getString("dest_citycode")
//                var dest_deptcode = json.getString("dest_deptcode")
//                var driver_id = json.getString("driver_id")
//                var vehicle = json.getString("vehicle")
//                var rp_tms = json.getString("rp_tms")
//                var vehicle_type = json.getString("vehicle_type")
//                var src_deptcode = json.getString("src_deptcode")
//                var opt_type = "jy"
//                var jy_roadID = json.getString("jy_roadid")
//                var ritcDur = ""
//                var routeid_group = json.getString("routeid_group")
//
//                json.put("conftype",conftype)
//                json.put("dest_city",dest_citycode)
//                json.put("line",src_deptcode)
//                json.put("opt_type",opt_type)
//                json.put("ritcdur",ritcDur)
//
//                var id = ""
//                var id_norptms = ""
//                id = DigestUtils.md5Hex(Array(conftype,dest_citycode,dest_deptcode,driver_id,vehicle,rp_tms,vehicle_type,src_deptcode).mkString("-")).toUpperCase
//                id_norptms = DigestUtils.md5Hex(Array(conftype,dest_citycode,dest_deptcode,driver_id,vehicle,vehicle_type,src_deptcode).mkString("-")).toUpperCase
//                json.put("id",id)
//                json.put("id_norptms",id_norptms)
//              }
//              json.put("out_flag", flag.toString)
//            }
//          }
//        } catch {
//          case e:Exception =>logger.error(">>>计算字段异常"+e)
//        }
//        json
//      })
//      .repartition(1600).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    inputRdd.unpersist()
//
//    fieldRdd
//  }
//
//
//  /**
//    * 计算conf_type
//    * @param json
//    * @param group_type
//    */
//  def getGroupId(json: JSONObject, group_type: String): String ={
//    var src_deptcode = json.getString("src_deptcode")
//    var dest_deptcode = json.getString("dest_deptcode")
//    var rp_tms = json.getString("rp_tms")
//    var driver_id = json.getString("driver_id")
//    var vehicle_type = json.getString("vehicle_type")
//    var vehicle = json.getString("vehicle")
//
//    if(StringUtils.isEmpty(src_deptcode)) src_deptcode = "-"
//    if(StringUtils.isEmpty(dest_deptcode)) dest_deptcode = "-"
//    if(StringUtils.isEmpty(rp_tms)) rp_tms = "-"
//    if(StringUtils.isEmpty(driver_id)) driver_id = "-"
//    if(StringUtils.isEmpty(vehicle_type)) vehicle_type = "-"
//    if(StringUtils.isEmpty(vehicle)) vehicle = "-"
//
//    var group_id = "-"
//    if("1".equalsIgnoreCase(group_type)){
//      group_id = Array(src_deptcode,dest_deptcode,rp_tms,driver_id,vehicle).mkString("_")
//    }
//    if("2".equalsIgnoreCase(group_type)){
//      group_id = Array(src_deptcode,dest_deptcode,driver_id,vehicle).mkString("_")
//    }
//    else if("3".equalsIgnoreCase(group_type)){
//      group_id = Array(src_deptcode,dest_deptcode,rp_tms,driver_id).mkString("_")
//    }
//    else if("4".equalsIgnoreCase(group_type)){
//      group_id = Array(src_deptcode,dest_deptcode,rp_tms,vehicle).mkString("_")
//    }
//    else if("5".equalsIgnoreCase(group_type)){
//      group_id = Array(src_deptcode,dest_deptcode,rp_tms).mkString("_")
//    }
//    else if("6".equalsIgnoreCase(group_type)){
//      group_id = Array(src_deptcode,dest_deptcode).mkString("_")
//    }
//
//    group_id
//  }
//
//
//  /**
//    * 比较相似度
//    * @param json
//    */
//  def getM_sim(json:JSONObject): JSONArray ={
//    var paths:JSONArray = null
//    try {
//      var tracks2 = json.getString("tracks2")
//
//      var x1 = ""
//      var x2 = ""
//      var y1 = ""
//      var y2 = ""
//      if(!StringUtils.isEmpty(tracks2)){
//        val tracks2Array = JSON.parseArray(tracks2)
//        if(tracks2Array!=null && tracks2Array.size()>0){
//          val point1 = tracks2Array.getJSONArray(0)
//          val point2 = tracks2Array.getJSONArray(tracks2Array.size() - 1)
//          x1 = point1.getString(0)
//          x2 = point2.getString(0)
//          y1 = point1.getString(1)
//          y2 = point2.getString(1)
//        }
//        tracks2 = tracks2.replaceAll("\\],\\[","|").replaceAll("\\[","").replaceAll("]","")
//      }
//      else tracks2 = ""
//
//      var req_time = json.getString("req_time")
//      var height = json.getString("height")
//      var full_loadweight = json.getString("full_loadweight")
//      var simple = "0"
//      var frequency = "1"
//      var stype = "2"
//      var etype = "2"
//      var vehicle_type = json.getString("vehicle_type")
//      var limit = "0"
//      var merge = "4"
//      var _type = "8"
//      var dist = "300"
//      var width = json.getString("width")
//      var ak = "bd8539440f454c5a8a2a0ba47acd1076"
//
//      if(StringUtils.isEmpty(vehicle_type)) vehicle_type = ""
//      else{
//        if("1".equalsIgnoreCase(vehicle_type)) vehicle_type = "1"
//        else if(Array("2","3","4","5","6").contains(vehicle_type)) vehicle_type = "2"
//        else vehicle_type = "3"
//      }
//
//      if(StringUtils.isEmpty(req_time)) req_time = ""
//      else{
//        req_time = req_time.replaceAll("-","").replaceAll(":","").replaceAll(" ","")
//        if(req_time.length >= 12)
//          req_time = req_time.substring(0,12)
//        else req_time = ""
//      }
//
//      if(StringUtils.isEmpty(x1)) x1 = ""
//      if(StringUtils.isEmpty(x2)) x2 = ""
//      if(StringUtils.isEmpty(y1)) y1 = ""
//      if(StringUtils.isEmpty(y2)) y2 = ""
//      if(StringUtils.isEmpty(height)) height = ""
//      if(StringUtils.isEmpty(full_loadweight)) full_loadweight = ""
//      if(StringUtils.isEmpty(width)) width = ""
//
//      val param = new JSONObject()
//      param.put("x1", x1)
//      param.put("x2", x2)
//      param.put("y1", y1)
//      param.put("y2", y2)
//      param.put("date", req_time)
//      param.put("weight", full_loadweight)
//      param.put("simple", simple)
//      param.put("height", height)
//      param.put("points", tracks2)
//      param.put("frequency", frequency)
//      param.put("stype", stype)
//      param.put("etype", etype)
//      param.put("vehicle", vehicle_type)
//      param.put("limit", limit)
//      param.put("merge", merge)
//      param.put("type", _type)
//      param.put("dist", dist)
//      param.put("width", width)
//      param.put("ak", ak)
//      param.put("sim", "0.9")
//
//      json.put("param",param.toJSONString)
//      val jsonObject = HttpClientUtil.getJsonByPostJson(qm_point_url, param.toString)
//      Thread.sleep(200)
//      if(jsonObject!=null) paths = jsonObject.getJSONArray("paths")
//      if(jsonObject!=null) json.put("http_result",jsonObject.toJSONString)
//    } catch {
//      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
//    }
//    paths
//  }
//
//
//  /**
//    * 比较相似度
//    * @param json
//    */
//  def getR_coords1(json:JSONObject): JSONObject ={
//    var jsonObject:JSONObject = null
//    try {
//      var reqid = json.getString("reqid");if(StringUtils.isEmpty(reqid)) reqid = ""
//      var x1 = json.getString("x1");if(StringUtils.isEmpty(x1)) x1 = ""
//      var y1 = json.getString("y1");if(StringUtils.isEmpty(y1)) y1 = ""
//      var x2 = json.getString("x2");if(StringUtils.isEmpty(x2)) x2 = ""
//      var y2 = json.getString("y2");if(StringUtils.isEmpty(y2)) y2 = ""
//      var vehicle_type = json.getString("vehicle_type");if(StringUtils.isEmpty(vehicle_type)) vehicle_type = ""
//      var full_loadweight = json.getString("full_loadweight");if(StringUtils.isEmpty(full_loadweight)) full_loadweight = ""
//      var laodweight = json.getString("laodweight");if(StringUtils.isEmpty(laodweight)) laodweight = ""
//      var height = json.getString("height");if(StringUtils.isEmpty(height)) height = ""
//      var axle_weight = json.getString("axle_weight");if(StringUtils.isEmpty(axle_weight)) axle_weight = ""
//      var axle_number = json.getString("axle_number");if(StringUtils.isEmpty(axle_number)) axle_number = ""
//      var vehicle = json.getString("vehicle");if(StringUtils.isEmpty(vehicle)) vehicle = ""
//      var req_time = json.getString("req_time");
//      if(StringUtils.isEmpty(req_time)) req_time = ""
//      else if(req_time.length >= 16){
//        req_time = req_time.substring(0,17)
//        req_time = req_time.replaceAll("-","").replaceAll(":","").replaceAll(" ","")
//      }
//      var vehicle_color = json.getString("vehicle_color");if(StringUtils.isEmpty(vehicle_color)) vehicle_color = ""
//      var energy = json.getString("energy");if(StringUtils.isEmpty(energy)) energy = ""
//      var width = json.getString("width");if(StringUtils.isEmpty(width)) width = ""
//      var length = json.getString("length");if(StringUtils.isEmpty(length)) length = ""
//      var emitstand = json.getString("emitstand");if(StringUtils.isEmpty(emitstand)) emitstand = ""
//      var actual_time_diff = json.getString("actual_time_diff");if(StringUtils.isEmpty(actual_time_diff)) actual_time_diff = ""
//      var _type = "0"
//      var cc = "1"
//      var strategy = "0"//
//      var opt = "sf2"//
//      var passport = "100000"
//      var tolls = "1"
//      var test = "0"
//      var stype = "0"
//      var etype = "2"
//      var fencedist = "50"
//      var merge = "5"
//
//      val array = new ArrayBuffer[String]()
//      if(true){
//        if(!StringUtils.isEmpty(reqid)) {
//          reqid = "No=" + URLEncoder.encode(reqid, "UTF8")
//          array += reqid
//        }
//        if(!StringUtils.isEmpty(x1)) {
//          x1 = "x1=" + URLEncoder.encode(x1, "UTF8")
//          array += x1
//        }
//        if(!StringUtils.isEmpty(y1)) {
//          y1 = "y1=" + URLEncoder.encode(y1, "UTF8")
//          array += y1
//        }
//        if(!StringUtils.isEmpty(x2)) {
//          x2 = "x2=" + URLEncoder.encode(x2, "UTF8")
//          array += x2
//        }
//        if(!StringUtils.isEmpty(y2)) {
//          y2 = "y2=" + URLEncoder.encode(y2, "UTF8")
//          array += y2
//        }
//        if(!StringUtils.isEmpty(_type)) {
//          _type = "type=" + URLEncoder.encode(_type, "UTF8")
//          array += _type
//        }
//        if(!StringUtils.isEmpty(cc)) {
//          cc = "cc=" + URLEncoder.encode(cc, "UTF8")
//          array += cc
//        }
//        if(!StringUtils.isEmpty(strategy)) {
//          strategy = "strategy=" + URLEncoder.encode(strategy, "UTF8")
//          array += strategy
//        }
//        if(!StringUtils.isEmpty(opt)) {
//          opt = "opt=" + URLEncoder.encode(opt, "UTF8")
//          array += opt
//        }
//        if(!StringUtils.isEmpty(vehicle_type)) {
//          vehicle_type = "vehicle=" + URLEncoder.encode(vehicle_type, "UTF8")
//          array += vehicle_type
//        }
//        if(!StringUtils.isEmpty(full_loadweight)) {
//          full_loadweight = "weight=" + URLEncoder.encode(full_loadweight, "UTF8")
//          array += full_loadweight
//        }
//        if(!StringUtils.isEmpty(laodweight)) {
//          laodweight = "mload=" + URLEncoder.encode(laodweight, "UTF8")
//          array += laodweight
//        }
//        if(!StringUtils.isEmpty(height)) {
//          height = "height=" + URLEncoder.encode(height, "UTF8")
//          array += height
//        }
//        if(!StringUtils.isEmpty(axle_weight)) {
//          axle_weight = "axleWeight=" + URLEncoder.encode(axle_weight, "UTF8")
//          array += axle_weight
//        }
//        if(!StringUtils.isEmpty(axle_number)) {
//          axle_number = "axleNumber=" + URLEncoder.encode(axle_number, "UTF8")
//          array += axle_number
//        }
//        if(!StringUtils.isEmpty(vehicle)) {
//          vehicle = "plate=" + URLEncoder.encode(vehicle, "UTF8")
//          array += vehicle
//        }
//        if(!StringUtils.isEmpty(req_time)) {
//          req_time = "planDate=" + URLEncoder.encode(req_time, "UTF8")
//          array += req_time
//        }
//        if(!StringUtils.isEmpty(vehicle_color)) {
//          vehicle_color = "plateColor=" + URLEncoder.encode(vehicle_color, "UTF8")
//          array += vehicle_color
//        }
//        if(!StringUtils.isEmpty(energy)) {
//          energy = "energy=" + URLEncoder.encode(energy, "UTF8")
//          array += energy
//        }
//        if(!StringUtils.isEmpty(width)) {
//          width = "width=" + URLEncoder.encode(width, "UTF8")
//          array += width
//        }
//        if(!StringUtils.isEmpty(length)) {
//          length = "size=" + URLEncoder.encode(length, "UTF8")
//          array += length
//        }
//        if(!StringUtils.isEmpty(passport)) {
//          passport = "passport=" + URLEncoder.encode(passport, "UTF8")
//          array += passport
//        }
//        if(!StringUtils.isEmpty(emitstand)) {
//          emitstand = "emitStand=" + URLEncoder.encode(emitstand, "UTF8")
//          array += emitstand
//        }
//        if(!StringUtils.isEmpty(tolls)) {
//          tolls = "tolls=" + URLEncoder.encode(tolls, "UTF8")
//          array += tolls
//        }
//        if(!StringUtils.isEmpty(actual_time_diff)) {
//          actual_time_diff = "act_time=" + URLEncoder.encode(actual_time_diff, "UTF8")
//          array += actual_time_diff
//        }
//        if(!StringUtils.isEmpty(test)) {
//          test = "test=" + URLEncoder.encode(test, "UTF8")
//          array += test
//        }
//        if(!StringUtils.isEmpty(stype)) {
//          stype = "stype=" + URLEncoder.encode(stype, "UTF8")
//          array += stype
//        }
//        if(!StringUtils.isEmpty(etype)) {
//          etype = "etype=" + URLEncoder.encode(etype, "UTF8")
//          array += etype
//        }
//        if(!StringUtils.isEmpty(fencedist)) {
//          fencedist = "fencedist=" + URLEncoder.encode(fencedist, "UTF8")
//          array += fencedist
//        }
//        if(!StringUtils.isEmpty(merge)) {
//          merge = "merge=" + URLEncoder.encode(merge, "UTF8")
//          array += merge
//        }
//      }
//
////      reqid = "No=" + URLEncoder.encode(reqid, "UTF8")
////      x1 = "x1=" + URLEncoder.encode(x1, "UTF8")
////      y1 = "y1=" + URLEncoder.encode(y1, "UTF8")
////      x2 = "x2=" + URLEncoder.encode(x2, "UTF8")
////      y2 = "y2=" + URLEncoder.encode(y2, "UTF8")
////      _type = "type=" + URLEncoder.encode(_type, "UTF8")
////      cc = "cc=" + URLEncoder.encode(cc, "UTF8")
////      strategy = "strategy=" + URLEncoder.encode(strategy, "UTF8")
////      opt = "opt=" + URLEncoder.encode(opt, "UTF8")
////      vehicle_type = "vehicle=" + URLEncoder.encode(vehicle_type, "UTF8")
////      full_loadweight = "weight=" + URLEncoder.encode(full_loadweight, "UTF8")
////      laodweight = "mload=" + URLEncoder.encode(laodweight, "UTF8")
////      height = "height=" + URLEncoder.encode(height, "UTF8")
////      axle_weight = "axleWeight=" + URLEncoder.encode(axle_weight, "UTF8")
////      axle_number = "axleNumber=" + URLEncoder.encode(axle_number, "UTF8")
////      vehicle = "plate=" + URLEncoder.encode(vehicle, "UTF8")
////      req_time = "planDate=" + URLEncoder.encode(req_time, "UTF8")
////      vehicle_color = "plateColor=" + URLEncoder.encode(vehicle_color, "UTF8")
////      energy = "energy=" + URLEncoder.encode(energy, "UTF8")
////      width = "width=" + URLEncoder.encode(width, "UTF8")
////      length = "size=" + URLEncoder.encode(length, "UTF8")
////      passport = "passport=" + URLEncoder.encode(passport, "UTF8")
////      emitstand = "emitStand=" + URLEncoder.encode(emitstand, "UTF8")
////      tolls = "tolls=" + URLEncoder.encode(tolls, "UTF8")
////      actual_time_diff = "act_time=" + URLEncoder.encode(actual_time_diff, "UTF8")
////      test = "test=" + URLEncoder.encode(test, "UTF8")
////      stype = "stype=" + URLEncoder.encode(stype, "UTF8")
////      etype = "etype=" + URLEncoder.encode(etype, "UTF8")
////      fencedist = "fencedist=" + URLEncoder.encode(fencedist, "UTF8")
////      merge = "merge=" + URLEncoder.encode(merge, "UTF8")
//
////      val params = Array(reqid,x1,y1,x2,y2,_type,cc,strategy,opt,vehicle_type,full_loadweight,laodweight,height,axle_weight,axle_number,vehicle,req_time,vehicle_color,energy,width,length,passport,emitstand,tolls,actual_time_diff,test,stype,etype,fencedist,merge).mkString("&")
//      val params = array.mkString("&")
//
//      val url = r_coords_url + params
////      json.put("r_coords_url",url)
//      jsonObject = HttpClientUtil.getJsonByGet(url)
//      Thread.sleep(300)
//    } catch {
//      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
//    }
//    jsonObject
//  }
//
//
//  /**
//    * 比较相似度
//    * @param json
//    */
//  def getR_coords2(json:JSONObject): JSONObject ={
//    var jsonObject:JSONObject = null
////    try {
//      var reqid = json.getString("reqid");if(StringUtils.isEmpty(reqid)) reqid = ""
//      var x1 = json.getString("x1");if(StringUtils.isEmpty(x1)) x1 = ""
//      var y1 = json.getString("y1");if(StringUtils.isEmpty(y1)) y1 = ""
//      var x2 = json.getString("x2");if(StringUtils.isEmpty(x2)) x2 = ""
//      var y2 = json.getString("y2");if(StringUtils.isEmpty(y2)) y2 = ""
//      var vehicle_type = json.getString("vehicle_type");if(StringUtils.isEmpty(vehicle_type)) vehicle_type = ""
//      var full_loadweight = json.getString("full_loadweight");if(StringUtils.isEmpty(full_loadweight)) full_loadweight = ""
//      var laodweight = json.getString("laodweight");if(StringUtils.isEmpty(laodweight)) laodweight = ""
//      var height = json.getString("height");if(StringUtils.isEmpty(height)) height = ""
//      var axle_weight = json.getString("axle_weight");if(StringUtils.isEmpty(axle_weight)) axle_weight = ""
//      var axle_number = json.getString("axle_number");if(StringUtils.isEmpty(axle_number)) axle_number = ""
//      var vehicle = json.getString("vehicle");if(StringUtils.isEmpty(vehicle)) vehicle = ""
//      var req_time = json.getString("req_time");
//      if(StringUtils.isEmpty(req_time)) req_time = ""
//      else if(req_time.length >= 16){
//        req_time = req_time.substring(0,17)
//        req_time = req_time.replaceAll("-","").replaceAll(":","").replaceAll(" ","")
//      }
//      var vehicle_color = json.getString("vehicle_color");if(StringUtils.isEmpty(vehicle_color)) vehicle_color = ""
//      var energy = json.getString("energy");if(StringUtils.isEmpty(energy)) energy = ""
//      var width = json.getString("width");if(StringUtils.isEmpty(width)) width = ""
//      var length = json.getString("length");if(StringUtils.isEmpty(length)) length = ""
//      var emitstand = json.getString("emitstand");if(StringUtils.isEmpty(emitstand)) emitstand = ""
//      var actual_time_diff = json.getString("actual_time_diff");if(StringUtils.isEmpty(actual_time_diff)) actual_time_diff = ""
//      var _type = "0"
//      var cc = "1"
//      var strategy = "6"//
//      var opt = "jy2"//
//      var passport = "100000"
//      var tolls = "1"
//      var test = "0"
//      var stype = "0"
//      var etype = "2"
//      var fencedist = "50"
//      var merge = "4"
//      var pathCount = "3"//
//
//      val array = new ArrayBuffer[String]()
//      if(true){
//        if(!StringUtils.isEmpty(reqid)) {
//          reqid = "No=" + URLEncoder.encode(reqid, "UTF8")
//          array += reqid
//        }
//        if(!StringUtils.isEmpty(x1)) {
//          x1 = "x1=" + URLEncoder.encode(x1, "UTF8")
//          array += x1
//        }
//        if(!StringUtils.isEmpty(y1)) {
//          y1 = "y1=" + URLEncoder.encode(y1, "UTF8")
//          array += y1
//        }
//        if(!StringUtils.isEmpty(x2)) {
//          x2 = "x2=" + URLEncoder.encode(x2, "UTF8")
//          array += x2
//        }
//        if(!StringUtils.isEmpty(y2)) {
//          y2 = "y2=" + URLEncoder.encode(y2, "UTF8")
//          array += y2
//        }
//        if(!StringUtils.isEmpty(_type)) {
//          _type = "type=" + URLEncoder.encode(_type, "UTF8")
//          array += _type
//        }
//        if(!StringUtils.isEmpty(cc)) {
//          cc = "cc=" + URLEncoder.encode(cc, "UTF8")
//          array += cc
//        }
//        if(!StringUtils.isEmpty(strategy)) {
//          strategy = "strategy=" + URLEncoder.encode(strategy, "UTF8")
//          array += strategy
//        }
//        if(!StringUtils.isEmpty(opt)) {
//          opt = "opt=" + URLEncoder.encode(opt, "UTF8")
//          array += opt
//        }
//        if(!StringUtils.isEmpty(vehicle_type)) {
//          vehicle_type = "vehicle=" + URLEncoder.encode(vehicle_type, "UTF8")
//          array += vehicle_type
//        }
//        if(!StringUtils.isEmpty(full_loadweight)) {
//          full_loadweight = "weight=" + URLEncoder.encode(full_loadweight, "UTF8")
//          array += full_loadweight
//        }
//        if(!StringUtils.isEmpty(laodweight)) {
//          laodweight = "mload=" + URLEncoder.encode(laodweight, "UTF8")
//          array += laodweight
//        }
//        if(!StringUtils.isEmpty(height)) {
//          height = "height=" + URLEncoder.encode(height, "UTF8")
//          array += height
//        }
//        if(!StringUtils.isEmpty(axle_weight)) {
//          axle_weight = "axleWeight=" + URLEncoder.encode(axle_weight, "UTF8")
//          array += axle_weight
//        }
//        if(!StringUtils.isEmpty(axle_number)) {
//          axle_number = "axleNumber=" + URLEncoder.encode(axle_number, "UTF8")
//          array += axle_number
//        }
//        if(!StringUtils.isEmpty(vehicle)) {
//          vehicle = "plate=" + URLEncoder.encode(vehicle, "UTF8")
//          array += vehicle
//        }
//        if(!StringUtils.isEmpty(req_time)) {
//          req_time = "planDate=" + URLEncoder.encode(req_time, "UTF8")
//          array += req_time
//        }
//        if(!StringUtils.isEmpty(vehicle_color)) {
//          vehicle_color = "plateColor=" + URLEncoder.encode(vehicle_color, "UTF8")
//          array += vehicle_color
//        }
//        if(!StringUtils.isEmpty(energy)) {
//          energy = "energy=" + URLEncoder.encode(energy, "UTF8")
//          array += energy
//        }
//        if(!StringUtils.isEmpty(width)) {
//          width = "width=" + URLEncoder.encode(width, "UTF8")
//          array += width
//        }
//        if(!StringUtils.isEmpty(length)) {
//          length = "size=" + URLEncoder.encode(length, "UTF8")
//          array += length
//        }
//        if(!StringUtils.isEmpty(passport)) {
//          passport = "passport=" + URLEncoder.encode(passport, "UTF8")
//          array += passport
//        }
//        if(!StringUtils.isEmpty(emitstand)) {
//          emitstand = "emitStand=" + URLEncoder.encode(emitstand, "UTF8")
//          array += emitstand
//        }
//        if(!StringUtils.isEmpty(tolls)) {
//          tolls = "tolls=" + URLEncoder.encode(tolls, "UTF8")
//          array += tolls
//        }
//        if(!StringUtils.isEmpty(actual_time_diff)) {
//          actual_time_diff = "act_time=" + URLEncoder.encode(actual_time_diff, "UTF8")
//          array += actual_time_diff
//        }
//        if(!StringUtils.isEmpty(test)) {
//          test = "test=" + URLEncoder.encode(test, "UTF8")
//          array += test
//        }
//        if(!StringUtils.isEmpty(stype)) {
//          stype = "stype=" + URLEncoder.encode(stype, "UTF8")
//          array += stype
//        }
//        if(!StringUtils.isEmpty(etype)) {
//          etype = "etype=" + URLEncoder.encode(etype, "UTF8")
//          array += etype
//        }
//        if(!StringUtils.isEmpty(fencedist)) {
//          fencedist = "fencedist=" + URLEncoder.encode(fencedist, "UTF8")
//          array += fencedist
//        }
//        if(!StringUtils.isEmpty(merge)) {
//          merge = "merge=" + URLEncoder.encode(merge, "UTF8")
//          array += merge
//        }
//        if(!StringUtils.isEmpty(pathCount)) {
//          pathCount = "pathCount=" + URLEncoder.encode(pathCount, "UTF8")
//          array += pathCount
//        }
//      }
//
//      //      reqid = "No=" + URLEncoder.encode(reqid, "UTF8")
//      //      x1 = "x1=" + URLEncoder.encode(x1, "UTF8")
//      //      y1 = "y1=" + URLEncoder.encode(y1, "UTF8")
//      //      x2 = "x2=" + URLEncoder.encode(x2, "UTF8")
//      //      y2 = "y2=" + URLEncoder.encode(y2, "UTF8")
//      //      _type = "type=" + URLEncoder.encode(_type, "UTF8")
//      //      cc = "cc=" + URLEncoder.encode(cc, "UTF8")
//      //      strategy = "strategy=" + URLEncoder.encode(strategy, "UTF8")
//      //      opt = "opt=" + URLEncoder.encode(opt, "UTF8")
//      //      vehicle_type = "vehicle=" + URLEncoder.encode(vehicle_type, "UTF8")
//      //      full_loadweight = "weight=" + URLEncoder.encode(full_loadweight, "UTF8")
//      //      laodweight = "mload=" + URLEncoder.encode(laodweight, "UTF8")
//      //      height = "height=" + URLEncoder.encode(height, "UTF8")
//      //      axle_weight = "axleWeight=" + URLEncoder.encode(axle_weight, "UTF8")
//      //      axle_number = "axleNumber=" + URLEncoder.encode(axle_number, "UTF8")
//      //      vehicle = "plate=" + URLEncoder.encode(vehicle, "UTF8")
//      //      req_time = "planDate=" + URLEncoder.encode(req_time, "UTF8")
//      //      vehicle_color = "plateColor=" + URLEncoder.encode(vehicle_color, "UTF8")
//      //      energy = "energy=" + URLEncoder.encode(energy, "UTF8")
//      //      width = "width=" + URLEncoder.encode(width, "UTF8")
//      //      length = "size=" + URLEncoder.encode(length, "UTF8")
//      //      passport = "passport=" + URLEncoder.encode(passport, "UTF8")
//      //      emitstand = "emitStand=" + URLEncoder.encode(emitstand, "UTF8")
//      //      tolls = "tolls=" + URLEncoder.encode(tolls, "UTF8")
//      //      actual_time_diff = "act_time=" + URLEncoder.encode(actual_time_diff, "UTF8")
//      //      test = "test=" + URLEncoder.encode(test, "UTF8")
//      //      stype = "stype=" + URLEncoder.encode(stype, "UTF8")
//      //      etype = "etype=" + URLEncoder.encode(etype, "UTF8")
//      //      fencedist = "fencedist=" + URLEncoder.encode(fencedist, "UTF8")
//      //      merge = "merge=" + URLEncoder.encode(merge, "UTF8")
//
//      //      val params = Array(reqid,x1,y1,x2,y2,_type,cc,strategy,opt,vehicle_type,full_loadweight,laodweight,height,axle_weight,axle_number,vehicle,req_time,vehicle_color,energy,width,length,passport,emitstand,tolls,actual_time_diff,test,stype,etype,fencedist,merge).mkString("&")
//      val params = array.mkString("&")
//
//      val url = r_coords_url + params
//      json.put("r_coords_url",url)
//      jsonObject = HttpClientUtil.getJsonByGet(url)
//      Thread.sleep(300)
////    } catch {
////      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
////    }
//    jsonObject
//  }
//
//
//  /**
//    * 根据轨迹字符串配置输入参数
//    * @param coords_str
//    * @return
//    */
//  def getCoordsParam(coords_str:String): JSONArray ={
//    val coords_params = new JSONArray()
//    if(coords_str!=null && !"".equalsIgnoreCase(coords_str)){
//      val gd_coords = JSON.parseArray(coords_str)
//      if(gd_coords!=null){
//        for(i<- 0.until(gd_coords.size())){
//          val gd_coord = gd_coords.getJSONArray(i)
//          val x = gd_coord.getDouble(0)
//          val y = gd_coord.getDouble(1)
//          val coords_param = new JSONObject()
//          coords_param.put("x",x)
//          coords_param.put("y",y)
//          coords_param.put("type",1)
//          coords_params.add(coords_param)
//        }
//      }
//    }
//    coords_params
//  }
//
//
//  /**
//    * 访问比较轨迹接口
//    * @param json
//    * @param tracks1
//    * @param tracks2
//    * @return
//    */
//  def accessCompareUrl(json:JSONObject,tracks1:JSONArray,tracks2:JSONArray,order:String): JSONObject ={
//    var http_result:JSONObject = null
//    //    try {
//    var vehicle_type = 8
//    if (json.getInteger("vehicle_type")!=null) vehicle_type = json.getInteger("vehicle_type")
//    val param = new JSONObject()
//    param.put("vehicle", vehicle_type)
//    param.put("compensate", 1)
//    param.put("retflag", 5)
//    param.put("tracktype", 0)
//    param.put("tracks1", tracks1)
//    param.put("tracks2", tracks2)
//    println("-------------json-------"+json)
//    //      println("轨迹对比接口："+compare_track_url)
//    //      println("轨迹对比参数："+param)
//    if(param!=null && !StringUtils.isEmpty(order)) json.put("compare_track_input"+order, param.toString)
//    http_result = HttpClientUtil.getJsonByPostJson(compare_track_url, param.toString)
//    Thread.sleep(200)
//    if(http_result!=null && !StringUtils.isEmpty(order)) json.put("compare_track_output"+order, http_result.toString)
//    //      println("轨迹对比结果："+http_result)
//    //    } catch {
//    //      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
//    //    }
//    http_result
//  }
//
//
//
//
//
//}
