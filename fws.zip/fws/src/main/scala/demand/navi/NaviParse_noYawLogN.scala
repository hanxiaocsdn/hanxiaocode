package demand.navi

import com.alibaba.fastjson.{JSON, JSONObject}
import demand.utils.{DateUtil, JsonUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 262174
 * @description: 表3 gis_navi_no_yaw_parse  Navi解析noYaw
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/10/25 15:27
 */
object NaviParse_noYawLogN {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    result.fluentPutAll(result.getJSONObject("data"))
    result.keySet().toArray.foreach(key => {
      if (result.get(key.toString).isInstanceOf[JSONObject]) {
        val temp = result.getJSONObject(key.toString)
        temp.keySet().toArray.foreach(k => {
          result.put(k.toString.toLowerCase, temp.getString(k.toString))
        })
      }
    })
    "resultstatus,status"
      .split(";").foreach(x => result.put(x.split(",")(0), result.getString(x.split(",")(1))))
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value

  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      ParseLog(spark, DateUtil.getYesterday)
    } else if (args.length == 1) {
      //传入参数，单天任务
      ParseLog(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    var runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getnoYawLogRdd
    computeRddF = null
    table = "gis_navi_no_yaw_parse"

    structs = Array("task_id", "navi_id", "routeid", "req_time", "startx", "starty", "endx", "endy", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plan_date", "plate_color", "energy", "emit_stand", "passport", "opt", "strategy", "test", "swid", "status", "req_starttime", "req_endtime", "req_costtime", "qmpoint_starttime", "qmpoint_endtime", "qmpoint_costtime", "ft_url", "request_id", "ak")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)
  }

  /**
   * 获取naviAccDist日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getnoYawLogRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = "pathTimeLog"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    val computeRdd = validRdd
      .map(json => {
        var routeid = ""
        var req_time: java.lang.Long = null
        if (json != null) {
          val data = json.getJSONObject("data")
          if (data != null) {
            val pathTimeArgs = data.getJSONObject("pathTimeArgs")
            val pnsPathTimeArgs = data.getJSONObject("pnsPathTimeArgs")
            if (pathTimeArgs != null) {
              routeid = pathTimeArgs.getString("routeId")
            }
            if (pnsPathTimeArgs != null) {
              req_time = pnsPathTimeArgs.getLong("reqTime")
              if (req_time != null) {
                val inc_date = longToTime(req_time).split(" ")(0).replaceAll("-", "")
                json.put("inc_date", inc_date)
              }
            }
          }
        }
        if (req_time == null) req_time = Long.MaxValue
        ((routeid, req_time), json)
      })
      .groupByKey()
      .map(obj => {
        val json = obj._2.toList.head
        json
      })
      .map(json => {
        if (json != null) {
          val data = json.getJSONObject("data")
          if (data != null) {
            val pnsPathTimeArgs = data.getJSONObject("pnsPathTimeArgs")
            if (pnsPathTimeArgs != null) {
              val origin = pnsPathTimeArgs.getString("origin")
              val destination = pnsPathTimeArgs.getString("destination")
              if (origin != null) {
                val coords = origin.split(",")
                if (coords != null && coords.nonEmpty) {
                  val x = coords(0)
                  json.put("startx", x)
                  if (coords.length > 1) {
                    val y = coords(1)
                    json.put("starty", y)
                  }
                }
              }
              if (destination != null) {
                val coords = destination.split(",")
                if (coords != null && coords.nonEmpty) {
                  val x = coords(0)
                  json.put("endx", x)
                  if (coords.length > 1) {
                    val y = coords(1)
                    json.put("endy", y)
                  }
                }
              }
              val fturl = getUrlPost(pnsPathTimeArgs, "http://10.206.169.158:8080/rp/navi/query/pathTime")
              json.put("fturl", fturl)
            }
          }
        }
        json
      }).repartition(repartition).persist()
    validRdd.unpersist()
    computeRdd
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  def getUrlPost(json: JSONObject, url: String): String = {
    var resultUrl = url
    if (json != null) resultUrl = url + ":" + json.toJSONString
    resultUrl
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    var sql = ""
    var table = ""
    if (subType.contains("msNaviLog")) table = "gis_eta_ms_navi_hive"
    else if (subType.contains("Result") && (subType.contains("V2") || subType.contains("path"))) table = "gis_eta_navi_query_proto_hive"
    else table = "gis_eta_navi_query_hive"
    if (subType.contains("msNaviLog"))
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate'
       """.stripMargin
    else if (subType.contains(",")) {
      val subTypes = subType.split(",")
      val subType1 = subTypes(0)
      val subType2 = subTypes(1)
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate'
           | and (get_json_object(data, '$$.subType') = '$subType1' or get_json_object(data, '$$.subType') = '$subType2')
       """.stripMargin
    }
    else {
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate'
           | and get_json_object(data, '$$.subType') = '$subType'
       """.stripMargin
    }
    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x)).persist(StorageLevel.MEMORY_AND_DISK_SER)
  }

  def mutiDayRddToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], dateList: ArrayBuffer[String]): Unit = {
    for (date <- dateList) {
      val resultRdd2 = filterRdd(resultRdd, date)
      filterRddToHive(spark, resultRdd2, table, structs, keys, date)
    }
    resultRdd.unpersist()
  }

  def filterRdd(resultRdd: RDD[JSONObject], date: String): RDD[JSONObject] = {
    val dateRdd = resultRdd.filter(json => {
      val inc_day = json.getString("inc_day")
      inc_day != null && inc_day.equals(date)
    }).persist()

    dateRdd
  }

  def filterRddToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], date: String): Unit = {
    saveJSONObjectRDDToHive(spark, resultRdd, table, structs, keys, date)
  }

  def saveJSONObjectRDDToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if (StringUtils.isEmpty(dataBase)) database = "dm_gis"
    else database = dataBase
    try {
      logger.error(">>>table=" + database + "." + table)
      spark.sql(s"use $database")
      //1 构造DataFrame的元数据 StructField
      val structFileds = new util.ArrayList[StructField]()
      for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
      //2 构建StructType用于DataFrame的元数据描述
      val structType = DataTypes.createStructType(structFileds)
      //3 构建Row格式数据集RDD[Row]
      val rowRdd = resultRdd.filter(_ != null).map(obj => {
        var row: Row = null
        try {
          val v = new Array[String](structs.length)
          for (i <- structs.indices) v(i) = JsonUtil.getJsonVal(obj, structs(i).replaceAll("_", ""), "")
          row = RowFactory.create(v: _*)
        } catch {
          case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
        }
        row
      }).filter(_ != null)
      // 4 构建DataFrame
      val df: DataFrame = spark.createDataFrame(rowRdd, structType)
      //5 基于Datarame创建临时表
      val tempView = String.format("%s_temp_view", table)
      df.createOrReplaceTempView(tempView)
      //6 分区、表等操作
      val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
      logger.error(">>>删除分区：" + deleteSql)
      spark.sql(deleteSql)
      val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
      logger.error(">>>新建分区：" + createPartitionSql)
      spark.sql(createPartitionSql)
      //7 把临时表的数据刷进hive表中
      spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
      logger.error(">>>数据入hive库结束!")
    }
    catch {
      case e: Exception => logger.error(">>>" + database + "." + table + "数据入库异常：" + e)
    }
  }

}