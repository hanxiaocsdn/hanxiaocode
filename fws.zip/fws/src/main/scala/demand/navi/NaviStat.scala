package demand.navi

import java.sql.{Connection, DriverManager}
import java.text.{DecimalFormat, SimpleDateFormat}
import java.util
import java.util.Date
import com.alibaba.fastjson.{JSONArray, JSONObject}
import demand.utils._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

object NaviStat {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)
  val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val df = new DecimalFormat("0.0000")

  var url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8mb4&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"

  case class SelectObj(statdate:String,province:String,citycode:String,navi_count:Int,user_count:Int,opt_top3_count:Int,opt_jy_count:Int,opt_sf_count:Int,opt_gd3_count:Int,src_jy_count:Int,src_sf_count:Int,src_gd_count:Int)
  case class FinishObj(statdate:String,province:String,citycode:String,src:String,total_count:Int,count1:Int,count2:Int,count3:Int,count4:Int,count5:Int)
  case class RateObj(statdate:String,province:String,city:String,source:String,sdk_count:Int,navi_count:Int,sf_count:Int,gd_count:Int,service_id:String,gd_sdk_count:Int)


  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)


    var date = DateUtil.getYesterday

    if (args.length == 0) {
      //代码内部传入日期参数
      StatLog(spark, date)
    } else if (args.length == 1) {
      //传入参数，单天任务
      StatLog(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }


    //      var startDate = "20211001"
    //      var endDate = "20211216"
    //      //      endDate = "20200916"
    //      batchTask(spark, runType, startDate, endDate)


    spark.stop()
    logger.error(">>>处理完毕---------------")
  }





  /**
    * 批量任务
    *
    * @param spark
    * @param startDate
    * @param endDate
    */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      StatLog(spark, date)
    }
  }




  def StatLog(spark:SparkSession, date:String): Unit = {
    logger.error(">>>开始处理" + date)
    var saveMysqlF:(RDD[Array[Any]],String,Array[String],String)=>Unit = saveToMysql
    var table = ""
    var structs:Array[String] = null
    var keys:Array[String] = null
    var table1 = ""
    var structs1:Array[String] = null
    var table2 = ""
    var structs2:Array[String] = null

    table1 = "GIS_NAVI_STAT_USER_DAILY"
    structs1 = Array("STATDATE","PROVINCE","CITY","SOURCE","SDK_COUNT","NAVI_COUNT","SF_COUNT","GD_COUNT","SERVICE_ID","GD_SDK_COUNT")
    table2 = "gis_navi_stat_user_daily"
    structs2 = Array("statdate","province","city","source","sdk_count","navi_count","sf_count","gd_count","service_id","gd_sdk_count")
    statSaveIndex(spark,null,statNewUserDailyData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

    table1 = "GIS_NAVI_STAT_TASK_DAILY"
    structs1 = Array("STATDATE","PROVINCE","CITY","SOURCE","SDK_COUNT","NAVI_COUNT","SF_COUNT","GD_COUNT","SERVICE_ID","GD_SDK_COUNT")
    table2 = "gis_navi_stat_task_daily"
    structs2 = Array("statdate","province","city","source","sdk_count","navi_count","sf_count","gd_count","service_id","gd_sdk_count")
    statSaveIndex(spark,null,statNewTaskDailyData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

    table1 = "GIS_NAVI_STAT_USER_MONTH"
    structs1 = Array("STATDATE","PROVINCE","CITY","SOURCE","SDK_COUNT","NAVI_COUNT","SF_COUNT","GD_COUNT","SERVICE_ID","GD_SDK_COUNT")
    table2 = "gis_navi_stat_user_month"
    structs2 = Array("statdate","province","city","source","sdk_count","navi_count","sf_count","gd_count","service_id","gd_sdk_count")
    statSaveIndex(spark,null,statNewUserMonthData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

    table1 = "GIS_NAVI_STAT_TASK_MONTH"
    structs1 = Array("STATDATE","PROVINCE","CITY","SOURCE","SDK_COUNT","NAVI_COUNT","SF_COUNT","GD_COUNT","SERVICE_ID","GD_SDK_COUNT")
    table2 = "gis_navi_stat_task_month"
    structs2 = Array("statdate","province","city","source","sdk_count","navi_count","sf_count","gd_count","service_id","gd_sdk_count")
    statSaveIndex(spark,null,statNewTaskMonthData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)



    table1 = "GIS_NAVI_STAT_NEW_KEEP"
    structs1 = Array("STATDATE","PROVINCE","CITY","SOURCE","USER_COUNT","KEEP_2_COUNT","KEEP_7_COUNT","KEEP_14_COUNT","KEEP_21_COUNT","KEEP_28_COUNT")
    table2 = "gis_navi_stat_new_keep"
    structs2 = Array("statdate","province","city","source","user_count","keep_2_count","keep_7_count","keep_14_count","keep_21_count","keep_28_count")
    statSaveIndex(spark,null,statNewKeepData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)





    table1 = "GIS_NAVI_USER_STAT"
    structs1 = Array("STATDATE","PROVINCE","CITY","SYSTEM","SDK_VER","SOURCE","NEW_COUNT","UV_COUNT","PV_COUNT","STOP_RATIO","KEEP_RATIO","ALL_COUNT")
    table2 = "gis_navi_user_stat"
    structs2 = Array("statdate","province","city","system","sdk_ver","source","new_count","uv_count","pv_count","stop_ratio","keep_ratio","all_count")
    statSaveIndex(spark,null,statUserData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

    table1 = "GIS_NAVI_USER_TIME_STAT"
    structs1 = Array("STATDATE","PROVINCE","CITY","SYSTEM","SDK_VER","SOURCE","HOUR","NEW_COUNT","UV_COUNT","PV_COUNT","STOP_RATIO","KEEP_RATIO","ALL_COUNT")
    table2 = "gis_navi_user_time_stat"
    structs2 = Array("statdate","province","city","system","sdk_ver","source","hour","new_count","uv_count","pv_count","stop_ratio","keep_ratio","all_count")
    statSaveIndex(spark,null,statUserDataTime,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)





    table1 = "GIS_NAVI_USER_STAT2"
    structs1 = Array("STATDATE","CODE","SYSTEM","SDK_VER","SOURCE","ALL_COUNT","NEW_COUNT","DRIVER_COUNT","NAVI_COUNT","KEEP_COUNT","START_COUNT")
    table2 = "gis_navi_user_stat2"
    structs2 = Array("statdate","code","system","sdk_ver","source","all_count","new_count","driver_count","navi_count","keep_count","start_count")
    statSaveIndex(spark,null,statUserData2,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

    table1 = "GIS_NAVI_USER_TIME_STAT2"
    structs1 = Array("STATDATE","CODE","SYSTEM","SDK_VER","SOURCE","HOUR","ALL_COUNT","NEW_COUNT","DRIVER_COUNT","NAVI_COUNT","KEEP_COUNT")
    table2 = "gis_navi_user_time_stat2"
    structs2 = Array("statdate","code","system","sdk_ver","source","hour","all_count","new_count","driver_count","navi_count","keep_count")
    statSaveIndex(spark,null,statUserDataTime2,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)



    table1 = "GIS_NAVI_NAVI_STAT"
    structs1 = Array("STATDATE","PROVINCE","CITY","SYSTEM","SDK_VER","SOURCE","USER_COUNT","TASK_COUNT","CLICK_USER_COUNT","CLICK_NAVI_COUNT","NAVI_USER_COUNT","NAVI_COUNT")
    table2 = "gis_navi_navi_stat"
    structs2 = Array("statdate","province","city","system","sdk_ver","source","user_count","task_count","click_user_count","click_navi_count","navi_user_count","navi_count")
    statSaveIndex(spark,null,statNaviData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

    table1 = "GIS_NAVI_NAVI_TIME_STAT"
    structs1 = Array("STATDATE","PROVINCE","CITY","SYSTEM","SDK_VER","SOURCE","HOUR","USER_COUNT","TASK_COUNT","CLICK_USER_COUNT","CLICK_NAVI_COUNT","NAVI_USER_COUNT","NAVI_COUNT")
    table2 = "gis_navi_navi_time_stat"
    structs2 = Array("statdate","province","city","system","sdk_ver","source","hour","user_count","task_count","click_user_count","click_navi_count","navi_user_count","navi_count")
    statSaveIndex(spark,null,statNaviDataTime,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

    table1 = "GIS_NAVI_SELECT_STAT"
    structs1 = Array("STATDATE","PROVINCE","CITY","NAVI_COUNT","USER_COUNT","OPT_TOP3_COUNT","OPT_JY_COUNT","OPT_SF_COUNT","OPT_GD3_COUNT","SRC_JY_COUNT","SRC_SF_COUNT","SRC_GD_COUNT")
    table2 = "gis_navi_select_stat"
    structs2 = Array("statdate","province","city","navi_count","user_count","opt_top3_count","opt_jy_count","opt_sf_count","opt_gd3_count","src_jy_count","src_sf_count","src_gd_count")
    statSaveIndex(spark,null,statSelectData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

    table1 = "GIS_NAVI_REACT_STAT"
    structs1 = Array("STATDATE","PROVINCE","CITY","DEPTCODE","SYSTEM","SDK_VER","NAVI_COUNT","YAW_COUNT","REACT_TIME","REACT_TIME99","REACT_TIME95","REACT_TIME90")
    table2 = "gis_navi_react_stat"
    structs2 = Array("statdate","province","city","deptcode","system","sdk_ver","navi_count","yaw_count","react_time","react_time99","react_time95","react_time90")
    statSaveIndex(spark,null,statReactData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)


    table1 = "GIS_NAVI_FINISH_STAT"
    structs1 = Array("STATDATE","PROVINCE","CITYCODE","SRC","TOTAL_COUNT","COUNT1","COUNT2","COUNT3","COUNT4","COUNT5")
    table2 = "gis_navi_finish_stat"
    structs2 = Array("statdate","province","citycode","src","total_count","count1","count2","count3","count4","count5")
    statSaveIndex(spark,null,statFinishData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)


  }



  /**
    * 新获取用户日志数据
    * @param spark
    * @param startDate
    * @param endDate
    * @return
    */
  def getNewUserData(spark:SparkSession, startDate:String, endDate:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.task_id,a.navi_id,a.driver_id,a.driver_type,b.type,b.navi_type,c.dest_province,c.dest_citycode from
         |(select task_id,navi_id,driver_id,driver_type from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') a
         |left join (select navi_id,type,navi_type from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day between '$startDate' and '$endDate') b on a.navi_id = b.navi_id
         |left join (select navi_id,dest_province,dest_citycode from dm_gis.gis_navi_eta_result2 where inc_day between '$startDate' and '$endDate') c on a.navi_id=c.navi_id
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd
      .map(json=>{
        var task_id = json.getString("task_id")
        if(StringUtils.isEmpty(task_id)) json.put("task_id", "-")

        var driver_id = json.getString("driver_id")
        if(StringUtils.isEmpty(driver_id)) json.put("driver_id", "-")

        var dest_province = json.getString("dest_province")
        if(StringUtils.isEmpty(dest_province)) json.put("dest_province", "-")

        var dest_citycode = json.getString("dest_citycode")
        if(StringUtils.isEmpty(dest_citycode)) json.put("dest_citycode", "-")

        var driver_type = json.getString("driver_type")
        if("0".equalsIgnoreCase(driver_type)) json.put("driver_type", "自营")
        else if("1".equalsIgnoreCase(driver_type)) json.put("driver_type", "外包")

        //      var _type = json.getString("type")
        //      if(StringUtils.isEmpty(_type)) json.put("type", "-")
        //
        //      var navi_type = json.getString("navi_type")
        //      if(StringUtils.isEmpty(navi_type)) json.put("navi_type", "-")

        json
      })
      .repartition(6400).persist()
    logger.error(">>>日志量："+resultRdd.count())
    logRdd.unpersist()
    resultRdd
  }



  /**
    * 新获取用户日志数据
    * @param spark
    * @param startDate
    * @param endDate
    * @return
    */
  def getNewUserData2(spark:SparkSession, startDate:String, endDate:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.task_id,a.navi_id,a.driver_id,a.driver_type,a.service_id,b.type,b.navi_type,c.dest_province,c.dest_citycode from
         |(select task_id,navi_id,driver_id,driver_type,service_id from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') a
         |left join (select navi_id,type,navi_type from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate') b on a.navi_id = b.navi_id
         |left join (select navi_id,dest_province,dest_citycode from dm_gis.gis_navi_eta_result2 where inc_day between '$startDate' and '$endDate') c on a.navi_id=c.navi_id
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd
      .map(json=>{
        var task_id = json.getString("task_id")
        if(StringUtils.isEmpty(task_id)) json.put("task_id", "-")

        var driver_id = json.getString("driver_id")
        if(StringUtils.isEmpty(driver_id)) json.put("driver_id", "-")

        var dest_province = json.getString("dest_province")
        if(StringUtils.isEmpty(dest_province)) json.put("dest_province", "-")

        var dest_citycode = json.getString("dest_citycode")
        if(StringUtils.isEmpty(dest_citycode)) json.put("dest_citycode", "-")

        var driver_type = json.getString("driver_type")
        if("0".equalsIgnoreCase(driver_type)) json.put("driver_type", "自营")
        else if("1".equalsIgnoreCase(driver_type)) json.put("driver_type", "外包")

        if(StringUtils.isEmpty(json.getString("driver_type"))) json.put("driver_type", "-")

        var service_id = json.getString("service_id")
        if(StringUtils.isEmpty(service_id)) json.put("service_id", "SL")

        json
      })
      .repartition(6400).persist()
    logger.error(">>>日志量："+resultRdd.count())
    logRdd.unpersist()
    resultRdd
  }


  /**
    * 统计日活表
    * @param spark
    * @param startDate
    * @param endDate
    */
  def statNewUserData(spark:SparkSession, startDate:String, endDate:String, key:String): RDD[Array[Any]] ={
    val dateRdd = getNewUserData(spark,startDate,endDate)
    logger.error(">>>指标统计")
    val resultRdd = dateRdd
      .map(json=>{
        var value = json.getString(key)//"driver_id"
        if(StringUtils.isEmpty(value)) value = "-"

        (value,json)
      })
      .groupByKey()
      .map(obj=>{
        var json:JSONObject = null
        val list  = obj._2.toList.filter(j=>"1".equalsIgnoreCase(j.getString("type")))
        if(list.nonEmpty) {
          val list2 = list.filter(j=> !StringUtils.isEmpty(j.getString("navi_type")))
          if(list2.nonEmpty)json = list2.head
          else json = list.head
        }
        else json = obj._2.toList.head
        json
      })
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        list += json

        val newJson = new JSONObject()
        newJson.fluentPutAll(json)
        newJson.put("driver_type", "sum")
        list += newJson

        list
      })
      .map(json=>{
        var dest_province = json.getString("dest_province")
        var dest_citycode = json.getString("dest_citycode")
        var driver_type = json.getString("driver_type")

        ((dest_province,dest_citycode,driver_type),json)
      })
      .groupByKey()
      .map(obj=>{
        var dest_province = obj._1._1
        var dest_citycode = obj._1._2
        var driver_type = obj._1._3

        val list1 = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")))//.map(json => json.getString(key)).distinct
        val list2 = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")) && "sf".equalsIgnoreCase(json.getString("navi_type")))//.map(json => json.getString(key)).distinct
        val list3 = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")) && "gd".equalsIgnoreCase(json.getString("navi_type")))//.map(json => json.getString(key)).distinct

        val sdk_count = obj._2.toList.size
        val navi_count = list1.size
        val sf_count = list2.size
        val gd_count = list3.size

        Array(endDate,dest_province,dest_citycode,driver_type,sdk_count,navi_count,sf_count,gd_count)
      })
      .repartition(1).persist()
    logger.error(">>>指标统计后的数据量："+resultRdd.count())

    resultRdd
  }


  /**
    * 统计日活表
    * @param spark
    * @param startDate
    * @param endDate
    */
  def statNewUserData2(spark:SparkSession, startDate:String, endDate:String, key:String): RDD[Array[Any]] ={
    val dateRdd = getNewUserData2(spark,startDate,endDate)
    logger.error(">>>指标统计")
    val resultRdd = dateRdd
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        list += json

        val newJson = new JSONObject()
        newJson.fluentPutAll(json)
        newJson.put("dest_province", "ALL")
        newJson.put("dest_citycode", "ALL")
        list += newJson

        list
      })

      .map(json=>{
        var dest_province = json.getString("dest_province")
        var dest_citycode = json.getString("dest_citycode")
        var driver_type = json.getString("driver_type")
        var service_id = json.getString("service_id")

        var value = json.getString(key)//"driver_id"
        if(StringUtils.isEmpty(value)) value = "-"

        ((dest_province,dest_citycode,driver_type,service_id,value),json)
      })
      .groupByKey()
      .map(obj=>{
        var statdate = endDate
        var province = obj._1._1
        var city = obj._1._2
        var source = obj._1._3
        var service_id = obj._1._4

        var sdk_count = 0
        var navi_count = 0
        var sf_count = 0
        var gd_count = 0
        var gd_sdk_count = 0


        sdk_count = obj._2.toList.map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size
        navi_count = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")) || "9".equalsIgnoreCase(json.getString("type"))).map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size
        sf_count = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")) && "sf".equalsIgnoreCase(json.getString("navi_type"))).map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size
        gd_count = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")) && "gd".equalsIgnoreCase(json.getString("navi_type"))).map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size
        gd_sdk_count = obj._2.toList.filter(json=> "9".equalsIgnoreCase(json.getString("type"))).map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size

        ((statdate,province,city,source,service_id),RateObj(statdate,province,city,source,sdk_count,navi_count,sf_count,gd_count,service_id,gd_sdk_count))
      })
      .reduceByKey((o1,o2)=>{
        RateObj(o1.statdate,o1.province,o1.city,o1.source,o1.sdk_count+o2.sdk_count,o1.navi_count+o2.navi_count,o1.sf_count+o2.sf_count,o1.gd_count+o2.gd_count,o1.service_id,o1.gd_sdk_count+o2.gd_sdk_count)
      }).values
      .map(o1=>{
        Array(o1.statdate,o1.province,o1.city,o1.source,o1.sdk_count,o1.navi_count,o1.sf_count,o1.gd_count,o1.service_id,o1.gd_sdk_count)
      }).repartition(1).persist()
    logger.error(">>>指标统计后的数据量："+resultRdd.count())

    resultRdd
  }


  /**
    * 统计日活表
    * @param spark
    * @param startDate
    * @param endDate
    */
  def statNewUserData3(spark:SparkSession, startDate:String, endDate:String, key:String): RDD[Array[Any]] ={
    val dateRdd = getNewUserData2(spark,startDate,endDate)
    logger.error(">>>指标统计")
    val resultRdd = dateRdd
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        list += json

        val newJson = new JSONObject()
        newJson.fluentPutAll(json)
        newJson.put("dest_province", "ALL")
        newJson.put("dest_citycode", "ALL")
        list += newJson

        list
      })

      .map(json=>{
        var dest_province = json.getString("dest_province")
        var dest_citycode = json.getString("dest_citycode")
        var driver_type = json.getString("driver_type")
        var service_id = json.getString("service_id")

        var value = json.getString(key)//"driver_id"
        if(StringUtils.isEmpty(value)) value = "-"

        ((dest_province,dest_citycode,driver_type,service_id,value),json)
      })
      .groupByKey()
      .flatMap(obj=>{
        val list = new ArrayBuffer[JSONObject]()
        var flag1 = true

        val list9  = obj._2.toList.filter(j=>"9".equalsIgnoreCase(j.getString("type")))
        if(list9.nonEmpty) {
          flag1 = false
          list += list9.head
        }

        val list1  = obj._2.toList.filter(j=>"1".equalsIgnoreCase(j.getString("type")))
        if(list1.nonEmpty) {
          flag1 = false
          var flag2 = true
          val list1sf = list1.filter(json=> "sf".equalsIgnoreCase(json.getString("navi_type")))
          if(list1sf.nonEmpty) {
            list += list1sf.head
            flag2 = false
          }
          val list1gd = list1.filter(json=> "gd".equalsIgnoreCase(json.getString("navi_type")))
          if(list1gd.nonEmpty) {
            list += list1gd.head
            flag2 = false
          }
          if(flag2) list += list1.head
        }

        if(flag1) list += obj._2.toList.head

        list
      })

      .map(json=>{
        var dest_province = json.getString("dest_province")
        var dest_citycode = json.getString("dest_citycode")
        var driver_type = json.getString("driver_type")
        var service_id = json.getString("service_id")

        ((dest_province,dest_citycode,driver_type,service_id),json)
      })
      .groupByKey()
      .map(obj=>{
        var dest_province = obj._1._1
        var dest_citycode = obj._1._2
        var driver_type = obj._1._3
        var service_id = obj._1._4

        val sdk_count = obj._2.toList.map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size
        val navi_count = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")) || "9".equalsIgnoreCase(json.getString("type"))).map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size
        val sf_count = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")) && "sf".equalsIgnoreCase(json.getString("navi_type"))).map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size
        val gd_count = obj._2.toList.filter(json=> "1".equalsIgnoreCase(json.getString("type")) && "gd".equalsIgnoreCase(json.getString("navi_type"))).map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size
        val gd_sdk_count = obj._2.toList.filter(json=> "9".equalsIgnoreCase(json.getString("type"))).map(json => json.getString(key)).filter(s=> !StringUtils.isEmpty(s)).distinct.size


        Array(endDate,dest_province,dest_citycode,driver_type,sdk_count,navi_count,sf_count,gd_count,service_id,gd_sdk_count)
      })
      .repartition(1).persist()
    logger.error(">>>指标统计后的数据量："+resultRdd.count())

    resultRdd
  }


  /**
    * 统计用户日活表
    * @param spark
    */
  def statNewUserDailyData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val startDate = date
    val endDate = date
    statNewUserData2(spark,startDate,endDate,"driver_id")
  }


  /**
    * 统计用户日活表-任务
    * @param spark
    */
  def statNewTaskDailyData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val startDate = date
    val endDate = date
    statNewUserData2(spark,startDate,endDate,"task_id")
  }


  /**
    * 统计用户日活表-月度
    * @param spark
    */
  def statNewUserMonthData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val startDate = DateUtil.getDateStr(date,-29)
    val endDate = date
    statNewUserData2(spark,startDate,endDate,"driver_id")
  }


  /**
    * 统计任务-月度
    * @param spark
    */
  def statNewTaskMonthData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val startDate = DateUtil.getDateStr(date,-29)
    val endDate = date
    statNewUserData2(spark,startDate,endDate,"task_id")
  }



  /**
    * 新获取用户日志数据
    * @param spark
    * @param date
    * @return
    */
  def getNewKeepData(spark:SparkSession, date:String):RDD[JSONObject] ={
    val date2 = DateUtil.getDateStr(date,-1)
    val date7 = DateUtil.getDateStr(date,-6)
    val date14 = DateUtil.getDateStr(date,-13)
    val date21 = DateUtil.getDateStr(date,-20)
    val date28 = DateUtil.getDateStr(date,-27)
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.driver_type,a.driver_id,b.driver_id2,c.driver_id7,d.driver_id14,e.driver_id21,f.driver_id28,g.dest_province,g.dest_citycode,a.inc_date from
         |(select driver_id,max(navi_id) as navi_id,max(driver_type) as driver_type,max(inc_day) as inc_date from dm_gis.gis_navi_top3_parse where inc_day='$date' and driver_id is not null and driver_id<>'' and driver_id<>'-' group by driver_id) a
         |left join (select driver_id as driver_id2 from dm_gis.gis_navi_top3_parse where inc_day='$date2' group by driver_id) b on a.driver_id=b.driver_id2
         |left join (select driver_id as driver_id7 from dm_gis.gis_navi_top3_parse where inc_day='$date7' group by driver_id) c on a.driver_id=c.driver_id7
         |left join (select driver_id as driver_id14 from dm_gis.gis_navi_top3_parse where inc_day='$date14' group by driver_id) d on a.driver_id=d.driver_id14
         |left join (select driver_id as driver_id21 from dm_gis.gis_navi_top3_parse where inc_day='$date21' group by driver_id) e on a.driver_id=e.driver_id21
         |left join (select driver_id as driver_id28 from dm_gis.gis_navi_top3_parse where inc_day='$date28' group by driver_id) f on a.driver_id=f.driver_id28
         |left join (select navi_id,max(dest_province) as dest_province,max(dest_citycode) as dest_citycode from dm_gis.gis_navi_eta_result2 where inc_day='$date' and navi_id is not null and navi_id<>'' group by navi_id) g on a.navi_id=g.navi_id
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        var dest_province = json.getString("dest_province")
        if(StringUtils.isEmpty(dest_province)) json.put("dest_province", "-")

        var dest_citycode = json.getString("dest_citycode")
        if(StringUtils.isEmpty(dest_citycode)) json.put("dest_citycode", "-")

        var driver_type = json.getString("driver_type")
        if("0".equalsIgnoreCase(driver_type)) json.put("driver_type", "自营")
        else if("1".equalsIgnoreCase(driver_type)) json.put("driver_type", "外包")

        list += json

        val newJson = new JSONObject()
        newJson.fluentPutAll(json)
        newJson.put("driver_type", "sum")
        list += newJson

        list
      })
      .repartition(1000).persist()
    logger.error(">>>日志量："+resultRdd.count())
    logRdd.unpersist()
    resultRdd
  }


  /**
    * 统计日活表
    * @param spark
    * @param date
    */
  def statNewKeepData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val dateRdd = getNewKeepData(spark,date)
    logger.error(">>>留存指标统计")
    val resultRdd = dateRdd
      .map(json=>{
        var dest_province = json.getString("dest_province")
        var dest_citycode = json.getString("dest_citycode")
        var driver_type = json.getString("driver_type")

        ((dest_province,dest_citycode,driver_type),json)
      })
      .groupByKey()
      .map(obj=>{
        var dest_province = obj._1._1
        var dest_citycode = obj._1._2
        var driver_type = obj._1._3

        val user_count = obj._2.toList.size
        val keep_2_count = obj._2.toList.count(json=> !StringUtils.isEmpty(json.getString("driver_id2")))
        val keep_7_count = obj._2.toList.count(json=> !StringUtils.isEmpty(json.getString("driver_id7")))
        val keep_14_count = obj._2.toList.count(json=> !StringUtils.isEmpty(json.getString("driver_id14")))
        val keep_21_count = obj._2.toList.count(json=> !StringUtils.isEmpty(json.getString("driver_id21")))
        val keep_28_count = obj._2.toList.count(json=> !StringUtils.isEmpty(json.getString("driver_id28")))

        Array(date,dest_province,dest_citycode,driver_type,user_count,keep_2_count,keep_7_count,keep_14_count,keep_21_count,keep_28_count)
      })
      .repartition(1).persist()
    logger.error(">>>留存指标统计后的数据量："+resultRdd.count())

    resultRdd
  }




  /**
    * 获取用户日志数据
    * @param spark
    * @param startDate
    * @param endDate
    * @return
    */
  def getUserData(spark:SparkSession, startDate:String, endDate:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.task_id,a.navi_id,a.driver_id,a.dest_deptcode,a.req_time,b.navi_starttime,b.status,c.driver_source,d.sdk_ver,e.city,e.province,a.inc_day from
         |(select task_id,navi_id,driver_id,dest_deptcode,req_time,inc_day from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') a
         |left join (select task_id,navi_id,navi_starttime,status from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate') b on a.task_id=b.task_id and a.navi_id=b.navi_id
         |left join (select task_id,driver_source from dm_grd.grd_new_task_detail where inc_day between '$startDate' and '$endDate') c on a.task_id=c.task_id
         |left join (select task_id,navi_id,sdk_ver from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate') d on a.task_id=d.task_id and a.navi_id=d.navi_id
         |left join (select zone_code,city_name as city,province from dm_gis.gis_navi_dept_info where inc_day='20200909') e on a.dest_deptcode=e.zone_code
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd

      .filter(json=> !json.getString("req_time").contains("."))
      .flatMap(json=>{
      val list = new ArrayBuffer[JSONObject]()

//      var city_code = "-"
//      val dest_deptcode = json.getString("dest_deptcode")
//      if(!StringUtils.isEmpty(dest_deptcode) && dest_deptcode.length >= 3){
//        city_code = dest_deptcode.substring(0,3)
//      }
//      json.put("city_code", city_code)

        if(json.getLong("navi_starttime")==null) json.put("navi_starttime", 0)


        var req_day = ""
        var req_hour = ""
        val req_time = json.getLong("req_time")
        if(req_time!=null){
          val st = longToTime(req_time)
          if(st.length >= 10){
            req_day = st.substring(0,10).replaceAll("-","")
          }
          if(st.length >= 13){
            req_hour = st.substring(11,13)
          }
        }
        json.put("req_day", req_day)
        json.put("req_hour", req_hour)
        json.put("time", req_day + req_hour)

        var system = "-"
        val navi_id = json.getString("navi_id")
        if(!StringUtils.isEmpty(navi_id)){
          if(navi_id.endsWith("0")) system = "android"
          else if(navi_id.endsWith("1")) system = "ios"
        }
        json.put("system", system)

        var source = "-"
        val driver_source = json.getString("driver_source")
        if(!StringUtils.isEmpty(driver_source)){
          if("0".equalsIgnoreCase(driver_source) || "3".equalsIgnoreCase(driver_source)) source = "自营"
          else if("1".equalsIgnoreCase(driver_source) || "2".equalsIgnoreCase(driver_source)) source = "外包"
        }
        json.put("source", source)

        list += json

        val newJson1 = new JSONObject()
        newJson1.fluentPutAll(json)
        newJson1.put("system", "sum")
        list += newJson1

        val newJson2 = new JSONObject()
        newJson2.fluentPutAll(json)
        newJson2.put("source", "sum")
        list += newJson2

        val newJson3 = new JSONObject()
        newJson3.fluentPutAll(json)
        newJson3.put("system", "sum")
        newJson3.put("source", "sum")
        list += newJson3

      list
    }).repartition(1000).persist()
    logger.error(">>>日志量："+resultRdd.count())
    logRdd.unpersist()
    resultRdd
  }


  /**
    * 统计用户日活表
    * @param spark
    */
  def statUserData(spark:SparkSession, date:String): RDD[Array[Any]] ={
//    val sparkSession = SparkSession.getActiveSession
//    var spark:SparkSession = null
//    if(sparkSession.nonEmpty) spark = sparkSession.get

    val startDate1 = DateUtil.getDateStr(date,-60)
    val endDate1 = date
    val dateRdd1 = getUserData(spark,startDate1,endDate1)
    logger.error(">>>统计新增和总用户量")
    val resultRdd1 = dateRdd1
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("province")) && !"-".equalsIgnoreCase(json.getString("province")) &&
          !StringUtils.isEmpty(json.getString("city")) && !"-".equalsIgnoreCase(json.getString("city")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_ver")) && !"-".equalsIgnoreCase(json.getString("sdk_ver")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
          !StringUtils.isEmpty(json.getString("driver_id")) && !"-".equalsIgnoreCase(json.getString("driver_id")) &&
          !StringUtils.isEmpty(json.getString("inc_day")) && !"-".equalsIgnoreCase(json.getString("inc_day"))
      })
      .map(json=>{
        var province = "-"
        var city = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var driver_id = "-"
        var inc_day:java.lang.Long = Long.MaxValue

        if(json!=null){
          province = json.getString("province")
          city = json.getString("city")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          driver_id = json.getString("driver_id")
          inc_day = json.getLong("inc_day")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"
        if(inc_day==null) inc_day = Long.MaxValue

        ((province,city,system,sdk_ver,source,driver_id),(inc_day,json))
      })
      .groupByKey()
      .map(obj=>{
        var province = obj._1._1
        var city = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5

        val sort = obj._2.toList.sortBy(_._1)
        val first_inc_day = sort.map(_._1).head
        val json = sort.map(_._2).head
//        json
        ((province,city,system,sdk_ver,source),(first_inc_day.toString, json))
      })
      .groupByKey()
      .map(obj=>{
        var province = obj._1._1
        var city = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5

        val new_count = obj._2.toList.count(o => date.equalsIgnoreCase(o._1))
        val all_count = obj._2.toList.length
        ((date,province,city,system,sdk_ver,source),(new_count, all_count))
      })
      .repartition(1000).persist()
    dateRdd1.unpersist()

    val startDate2 = DateUtil.getDateStr(date,-1)
    val endDate2 = date
    val dateRdd2 = getUserData(spark,startDate2,endDate2)
    logger.error(">>>统计用户留存量")
    val resultRdd2 = dateRdd2
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("province")) && !"-".equalsIgnoreCase(json.getString("province")) &&
          !StringUtils.isEmpty(json.getString("city")) && !"-".equalsIgnoreCase(json.getString("city")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_ver")) && !"-".equalsIgnoreCase(json.getString("sdk_ver")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
          !StringUtils.isEmpty(json.getString("driver_id")) && !"-".equalsIgnoreCase(json.getString("driver_id")) &&
          !StringUtils.isEmpty(json.getString("inc_day")) && !"-".equalsIgnoreCase(json.getString("inc_day"))
      })
      .map(json=>{
        var province = "-"
        var city = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var driver_id = "-"
        var inc_day:java.lang.Long = Long.MaxValue

        if(json!=null){
          province = json.getString("province")
          city = json.getString("city")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          driver_id = json.getString("driver_id")
          inc_day = json.getLong("inc_day")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"
        if(inc_day==null) inc_day = Long.MaxValue

        ((province,city,system,sdk_ver,source,driver_id),(inc_day.toString,json))
      })
      .groupByKey()
      .map(obj=>{
        var province = obj._1._1
        var city = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5

        var flag = false
        val sort = obj._2.toList.sortBy(_._1)
        val map = sort.map(_._1)
        val json = sort.map(_._2).head
        if(sort!=null && map.contains(startDate2) && map.contains(endDate2)) flag = true
        ((province,city,system,sdk_ver,source),(flag, json))
      })
      .filter(obj=> obj._2._1)
      .groupByKey()
      .map(obj=>{
        var province = obj._1._1
        var city = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5

        val keep_count = obj._2.toList.length
        ((date,province,city,system,sdk_ver,source),keep_count)
      })
      .repartition(1000).persist()
    dateRdd2.unpersist()

    val startDate3 = date
    val endDate3 = date
    val dateRdd3 = getUserData(spark,startDate3,endDate3)
    logger.error(">>>统计当前时段内信息")
    val resultRdd3 = dateRdd3
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("province")) && !"-".equalsIgnoreCase(json.getString("province")) &&
          !StringUtils.isEmpty(json.getString("city")) && !"-".equalsIgnoreCase(json.getString("city")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_ver")) && !"-".equalsIgnoreCase(json.getString("sdk_ver")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
          !StringUtils.isEmpty(json.getString("driver_id")) && !"-".equalsIgnoreCase(json.getString("driver_id")) &&
          !StringUtils.isEmpty(json.getString("inc_day")) && !"-".equalsIgnoreCase(json.getString("inc_day"))
      })
      .map(json=>{
        var province = "-"
        var city = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"

        if(json!=null){
          province = json.getString("province")
          city = json.getString("city")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"

        ((date,province,city,system,sdk_ver,source),json)
      })
      .groupByKey()
      .map(obj=>{
        val key = obj._1

        var uv_count = 0
        var pv_count = 0
        var all_count = 0
        var stop_count = 0
        var stop_ratio = 0.0

        uv_count = obj._2.toList.map(json => json.getString("driver_id")).distinct.size
        pv_count = obj._2.toList.map(json => json.getString("navi_id")).distinct.size
        all_count = obj._2.toList.map(json => json.getString("task_id")).distinct.size
        obj._2.toList.groupBy(json => json.getString("task_id")).foreach(o =>{
          val task_id = o._1
          val first_json = o._2.sortBy(json=>json.getLong("navi_starttime")).reverse.head
          val status = first_json.getString("status")
          if(Array("10","11","12","13","14").contains(status)) stop_count = stop_count + 1
        })
        if(all_count > 0) stop_ratio = stop_count.toDouble / all_count

        (key,(uv_count, pv_count, stop_ratio))
      })
      .repartition(1000).persist()
    dateRdd3.unpersist()

    logger.error(">>>合并各项数据")
    logger.error(">>>合并新增、总用户量和用户留存量")
    val resultRdd12 = resultRdd1.fullOuterJoin(resultRdd2)
      .map(obj =>{
        val key = obj._1
        var new_count = 0
        var all_count = 0
        var keep_count = 0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          new_count = r1._1
          all_count = r1._2
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          keep_count = result2.get
        }

        (key,(new_count,keep_count,all_count))
      }).repartition(1000).persist()
    resultRdd1.unpersist()
    resultRdd2.unpersist()

    logger.error(">>>合并当前时段内信息")
    val resultRdd = resultRdd12.fullOuterJoin(resultRdd3)
      .map(obj =>{
        var date = obj._1._1
        var province = obj._1._2
        var city = obj._1._3
        var system = obj._1._4
        var sdk_ver = obj._1._5
        var source = obj._1._6
        var new_count = 0
        var uv_count = 0
        var pv_count = 0
        var stop_ratio = 0.0
        var keep_count = 0
        var all_count = 0
        var keep_ratio = 0.0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          new_count = r1._1
          keep_count = r1._2
          all_count = r1._3
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          val r2 = result2.get
          uv_count = r2._1
          pv_count = r2._2
          stop_ratio = r2._3
        }
        if(uv_count>0) keep_ratio = keep_count.toDouble / uv_count

        Array(date,province,city,system,sdk_ver,source,new_count,uv_count,pv_count,stop_ratio,keep_ratio,all_count)
      }).repartition(1).persist()
    logger.error(">>>统计用户日活表后的数据量："+resultRdd.count())
    resultRdd12.unpersist()
    resultRdd3.unpersist()

    resultRdd
  }


  /**
    * 按时段统计用户日活表
    * @param spark
    */
  def statUserDataTime(spark:SparkSession, date:String): RDD[Array[Any]] ={
//    val sparkSession = SparkSession.getActiveSession
//    var spark:SparkSession = null
//    if(sparkSession.nonEmpty) spark = sparkSession.get

    val startDate1 = DateUtil.getDateStr(date,-60)
    val endDate1 = date
    val dateRdd1 = getUserData(spark,startDate1,endDate1)
    logger.error(">>>统计新增和总用户量")
    val resultRdd1 = dateRdd1
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("province")) && !"-".equalsIgnoreCase(json.getString("province")) &&
          !StringUtils.isEmpty(json.getString("city")) && !"-".equalsIgnoreCase(json.getString("city")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_ver")) && !"-".equalsIgnoreCase(json.getString("sdk_ver")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
          !StringUtils.isEmpty(json.getString("driver_id")) && !"-".equalsIgnoreCase(json.getString("driver_id")) &&
          !StringUtils.isEmpty(json.getString("time")) && !"-".equalsIgnoreCase(json.getString("time")) &&
          !StringUtils.isEmpty(json.getString("req_day")) && !"-".equalsIgnoreCase(json.getString("req_day")) &&
          !StringUtils.isEmpty(json.getString("req_hour")) && !"-".equalsIgnoreCase(json.getString("req_hour"))
      })
      .map(json=>{
        var province = "-"
        var city = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var driver_id = "-"
        var time:java.lang.Long = Long.MaxValue
        var req_day:java.lang.Long = Long.MaxValue
        var req_hour:java.lang.Long = Long.MaxValue

        if(json!=null){
          province = json.getString("province")
          city = json.getString("city")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          driver_id = json.getString("driver_id")
          time = json.getLong("time")
          req_day = json.getLong("req_day")
          req_hour = json.getLong("req_hour")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"
        if(time==null) time = Long.MaxValue
        if(req_day==null) req_day = Long.MaxValue
        if(req_hour==null) req_hour = Long.MaxValue

        ((province,city,system,sdk_ver,source,driver_id),(time, req_day, req_hour, json))
      })
      .groupByKey()
      .map(obj=>{
        var province = obj._1._1
        var city = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5

        val sort = obj._2.toList.sortBy(_._1)
        val first_req_time = sort.map(_._1).head
        val req_day = sort.map(_._2).head
        val req_hour = sort.map(_._3).head
        val json = sort.map(_._4).head
        ((province,city,system,sdk_ver,source),(req_day, req_hour, json))
      })
      .groupByKey()
      .flatMap(obj=>{
        var province = obj._1._1
        var city = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5

        val list = new ArrayBuffer[((String,String,String,String,String,String,String),(Int,Int))]()

        for(i<-0.until(24)){
          val new_count = obj._2.toList.count(o => date.toLong == o._1 && i == o._2)
          val all_count = obj._2.toList.count(o => (date.toLong > o._1) || (date.toLong == o._1 && i >= o._2))
          val tmp = ((date,province,city,system,sdk_ver,source,i.toString),(new_count, all_count))
          list += tmp
        }
        list
      })
      .repartition(1000).persist()
    dateRdd1.unpersist()

    val startDate2 = DateUtil.getDateStr(date,-1)
    val endDate2 = date
    val dateRdd2 = getUserData(spark,startDate2,endDate2)
    logger.error(">>>统计用户留存量")
    val resultRdd2 = dateRdd2
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("province")) && !"-".equalsIgnoreCase(json.getString("province")) &&
          !StringUtils.isEmpty(json.getString("city")) && !"-".equalsIgnoreCase(json.getString("city")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_ver")) && !"-".equalsIgnoreCase(json.getString("sdk_ver")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
          !StringUtils.isEmpty(json.getString("driver_id")) && !"-".equalsIgnoreCase(json.getString("driver_id")) &&
          !StringUtils.isEmpty(json.getString("time")) && !"-".equalsIgnoreCase(json.getString("time")) &&
          !StringUtils.isEmpty(json.getString("req_day")) && !"-".equalsIgnoreCase(json.getString("req_day")) &&
          !StringUtils.isEmpty(json.getString("req_hour")) && !"-".equalsIgnoreCase(json.getString("req_hour"))
      })
      .map(json=>{
        var province = "-"
        var city = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var driver_id = "-"
        var time:java.lang.Long = Long.MaxValue
        var req_day:java.lang.Long = Long.MaxValue
        var req_hour:java.lang.Long = Long.MaxValue

        if(json!=null){
          province = json.getString("province")
          city = json.getString("city")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          driver_id = json.getString("driver_id")
          time = json.getLong("time")
          req_day = json.getLong("req_day")
          req_hour = json.getLong("req_hour")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"
        if(time==null) time = Long.MaxValue
        if(req_day==null) req_day = Long.MaxValue
        if(req_hour==null) req_hour = Long.MaxValue

        ((province,city,system,sdk_ver,source,driver_id),(req_day, req_hour))
      })
      .groupByKey()
      .flatMap(obj=>{
        var province = obj._1._1
        var city = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5

        val list = new ArrayBuffer[((String,String,String,String,String,String,Int),(String,String,String,String,String,String,Int,Int))]()

        val sort = obj._2.toList.sortBy(_._1)
        if(sort!=null && sort.contains((startDate2.toLong,23l)) && sort.contains((date.toLong,0l))){
          val tmp = ((date,province,city,system,sdk_ver,source,0),(date,province,city,system,sdk_ver,source,0,1))
          list += tmp
        }
        else{
          val tmp = ((date,province,city,system,sdk_ver,source,0),(date,province,city,system,sdk_ver,source,0,0))
          list += tmp
        }

        for(i<-1.until(24)){
          if(sort!=null && sort.contains((date.toLong, (i-1).toLong)) && sort.contains((date.toLong, i.toLong))){
            val tmp = ((date,province,city,system,sdk_ver,source,i),(date,province,city,system,sdk_ver,source,i,1))
            list += tmp
          }
          else{
            val tmp = ((date,province,city,system,sdk_ver,source,i),(date,province,city,system,sdk_ver,source,i,0))
            list += tmp
          }
        }

        list
      })
      .reduceByKey((o1,o2)=>{
        (o1._1,o1._2,o1._3,o1._4,o1._5,o1._6,o1._7,o1._8 + o2._8)
      }).values
      .map(o1=>{
        ((o1._1,o1._2,o1._3,o1._4,o1._5,o1._6,o1._7.toString),o1._8)
      })
      .repartition(1000).persist()
    dateRdd2.unpersist()

    val startDate3 = date
    val endDate3 = date
    val dateRdd3 = getUserData(spark,startDate3,endDate3)
    logger.error(">>>统计当前时段内信息")
    val resultRdd3 = dateRdd3
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("province")) && !"-".equalsIgnoreCase(json.getString("province")) &&
          !StringUtils.isEmpty(json.getString("city")) && !"-".equalsIgnoreCase(json.getString("city")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_ver")) && !"-".equalsIgnoreCase(json.getString("sdk_ver")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
          !StringUtils.isEmpty(json.getString("driver_id")) && !"-".equalsIgnoreCase(json.getString("driver_id")) &&
          !StringUtils.isEmpty(json.getString("time")) && !"-".equalsIgnoreCase(json.getString("time")) &&
          !StringUtils.isEmpty(json.getString("req_day")) && !"-".equalsIgnoreCase(json.getString("req_day")) &&
          !StringUtils.isEmpty(json.getString("req_hour")) && !"-".equalsIgnoreCase(json.getString("req_hour"))
      })
      .map(json=>{
        var province = "-"
        var city = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var req_day:java.lang.Long = Long.MaxValue
        var req_hour:java.lang.Long = Long.MaxValue

        if(json!=null){
          province = json.getString("province")
          city = json.getString("city")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          req_day = json.getLong("req_day")
          req_hour = json.getLong("req_hour")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(req_day==null) req_day = Long.MaxValue
        if(req_hour==null) req_hour = Long.MaxValue

        ((req_day.toString,province,city,system,sdk_ver,source,req_hour.toString),json)
      })
      .filter(obj=> date.equalsIgnoreCase(obj._1._1) && obj._1._7.toLong >= 0 && obj._1._7.toLong <= 23)
      .groupByKey()
      .map(obj=>{
        val key = obj._1

        var uv_count = 0
        var pv_count = 0
        var all_count = 0
        var stop_count = 0
        var stop_ratio = 0.0

        uv_count = obj._2.toList.map(json => json.getString("driver_id")).distinct.size
        pv_count = obj._2.toList.map(json => json.getString("navi_id")).distinct.size
        all_count = obj._2.toList.map(json => json.getString("task_id")).distinct.size
        obj._2.toList.groupBy(json => json.getString("task_id")).foreach(o =>{
          val task_id = o._1
          val first_json = o._2.sortBy(json=>json.getLong("navi_starttime")).reverse.head
          val status = first_json.getString("status")
          if(Array("10","11","12","13","14").contains(status)) stop_count = stop_count + 1
        })
        if(all_count > 0) stop_ratio = stop_count.toDouble / all_count

        (key,(uv_count, pv_count, stop_ratio))
      })
      .repartition(1000).persist()
    dateRdd3.unpersist()

    logger.error(">>>合并各项数据")
    logger.error(">>>合并新增、总用户量和用户留存量")
    val resultRdd12 = resultRdd1.fullOuterJoin(resultRdd2)
      .map(obj =>{
        val key = obj._1
        var new_count = 0
        var all_count = 0
        var keep_count = 0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          new_count = r1._1
          all_count = r1._2
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          keep_count = result2.get
        }

        (key,(new_count, keep_count, all_count))
      }).repartition(1000).persist()
    resultRdd1.unpersist()
    resultRdd2.unpersist()

    logger.error(">>>合并当前时段内信息")
    val resultRdd = resultRdd12.fullOuterJoin(resultRdd3)
      .map(obj =>{
        var date = obj._1._1
        var province = obj._1._2
        var city = obj._1._3
        var system = obj._1._4
        var sdk_ver = obj._1._5
        var source = obj._1._6
        var hour = obj._1._7
        var new_count = 0
        var uv_count = 0
        var pv_count = 0
        var stop_ratio = 0.0
        var keep_count = 0
        var all_count = 0
        var keep_ratio = 0.0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          new_count = r1._1
          keep_count = r1._2
          all_count = r1._3
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          val r2 = result2.get
          uv_count = r2._1
          pv_count = r2._2
          stop_ratio = r2._3
        }
        if(uv_count>0) keep_ratio = keep_count.toDouble / uv_count

        Array(date,province,city,system,sdk_ver,source,hour,new_count,uv_count,pv_count,stop_ratio,keep_ratio,all_count)
      }).repartition(1).persist()
    logger.error(">>>统计用户日活表后的数据量："+resultRdd.count())
    resultRdd12.unpersist()
    resultRdd3.unpersist()

    resultRdd
  }





  /**
    * 获取用户日志数据
    * @param spark
    * @param startDate
    * @param endDate
    * @return
    */
  def getUserData2(spark:SparkSession, startDate:String, endDate:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.task_id,a.navi_id,a.driver_id,a.req_time,a.driver_type,b.sdk_ver,a.inc_day from
         |(select task_id,navi_id,driver_id,req_time,driver_type,inc_day from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') a
         |left join (select navi_id,max(sdk_ver) as sdk_ver from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' group by navi_id) b on a.navi_id=b.navi_id
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd
      .filter(json=> !json.getString("req_time").contains("."))
      .map(json=>{
        var req_day = ""
        var req_hour = ""
        val req_time = json.getLong("req_time")
        if(req_time!=null){
          val st = longToTime(req_time)
          if(st.length >= 10){
            req_day = st.substring(0,10).replaceAll("-","")
          }
          if(st.length >= 13){
            req_hour = st.substring(11,13)
          }
        }
        json.put("req_day", req_day)
        json.put("req_hour", req_hour)
        json.put("time", req_day + req_hour)

        var system = "-"
        val navi_id = json.getString("navi_id")
        if(!StringUtils.isEmpty(navi_id)){
          if(navi_id.endsWith("0")) system = "android"
          else if(navi_id.endsWith("1")) system = "ios"
        }
        json.put("system", system)

        var source = "-"
        val driver_type = json.getString("driver_type")
        if(!StringUtils.isEmpty(driver_type)){
          source = driver_type
        }
        json.put("source", source)

        var code = "-"
        val task_id = json.getString("task_id")
        if(!StringUtils.isEmpty(task_id) && task_id.length >= 4){
          code = task_id.substring(0, 4)
        }
        json.put("code", code)

        var driver_id = json.getString("driver_id")
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"

        (driver_id,json)
      })
      .groupByKey()
      .map(obj=>{
        val json = obj._2.head
        json
      })
//      .filter(json=>{
//        !StringUtils.isEmpty(json.getString("code")) && !"-".equalsIgnoreCase(json.getString("code")) &&
//          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
//          !StringUtils.isEmpty(json.getString("sdk_ver")) && !"-".equalsIgnoreCase(json.getString("sdk_ver")) &&
//          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
//          !StringUtils.isEmpty(json.getString("driver_id")) && !"-".equalsIgnoreCase(json.getString("driver_id"))// &&
//          !StringUtils.isEmpty(json.getString("inc_day")) && !"-".equalsIgnoreCase(json.getString("inc_day"))
//      })
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        list += json

        val newJson1 = new JSONObject()
        newJson1.fluentPutAll(json)
        newJson1.put("system", "sum")
        list += newJson1

        val newJson2 = new JSONObject()
        newJson2.fluentPutAll(json)
        newJson2.put("source", "sum")
        list += newJson2

        val newJson3 = new JSONObject()
        newJson3.fluentPutAll(json)
        newJson3.put("system", "sum")
        newJson3.put("source", "sum")
        list += newJson3

        list
      })
      .repartition(1000).persist()
    logRdd.unpersist()
    resultRdd
  }





  /**
    * 获取开始导航数数据
    * @param spark
    * @param date
    * @return
    */
  def getStartNaviData(spark:SparkSession, date:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.navi_id,a.sdk_ver,b.task_id,b.driver_id,b.driver_type,a.inc_day from
         |(select navi_id,max(sdk_ver) as sdk_ver,max(inc_day) as inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$date' and type='1' group by navi_id) a
         |left join (select navi_id,max(task_id) as task_id,max(driver_id) as driver_id,max(driver_type) as driver_type from dm_gis.gis_navi_top3_parse where inc_day='$date' group by navi_id) b on a.navi_id=b.navi_id
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd
      .map(json=>{

        var system = "-"
        val navi_id = json.getString("navi_id")
        if(!StringUtils.isEmpty(navi_id)){
          if(navi_id.endsWith("0")) system = "android"
          else if(navi_id.endsWith("1")) system = "ios"
        }
        json.put("system", system)

        var source = "-"
        val driver_type = json.getString("driver_type")
        if(!StringUtils.isEmpty(driver_type)){
          source = driver_type
        }
        json.put("source", source)

        var code = "-"
        val task_id = json.getString("task_id")
        if(!StringUtils.isEmpty(task_id) && task_id.length >= 4){
          code = task_id.substring(0, 4)
        }
        json.put("code", code)

        json
      })
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("code")) && !"-".equalsIgnoreCase(json.getString("code")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_ver")) && !"-".equalsIgnoreCase(json.getString("sdk_ver")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
          !StringUtils.isEmpty(json.getString("driver_id")) && !"-".equalsIgnoreCase(json.getString("driver_id")) &&
          !StringUtils.isEmpty(json.getString("inc_day")) && !"-".equalsIgnoreCase(json.getString("inc_day"))
      })
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        list += json

        val newJson1 = new JSONObject()
        newJson1.fluentPutAll(json)
        newJson1.put("system", "sum")
        list += newJson1

        val newJson2 = new JSONObject()
        newJson2.fluentPutAll(json)
        newJson2.put("source", "sum")
        list += newJson2

        val newJson3 = new JSONObject()
        newJson3.fluentPutAll(json)
        newJson3.put("system", "sum")
        newJson3.put("source", "sum")
        list += newJson3

        list
      })
      .repartition(1000).persist()
    logRdd.unpersist()
    resultRdd
  }


  /**
    * 统计用户日活表
    * @param spark
    */
  def statUserData2(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val startDate1 = DateUtil.getDateStr(date,-60)
    val endDate1 = date
    val dateRdd1 = getUserData2(spark,startDate1,endDate1)
    logger.error(">>>统计新增和总用户量")
    val resultRdd1 = dateRdd1
      .map(json=>{
        var code = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var driver_id = "-"
        var inc_day:java.lang.Long = Long.MaxValue

        if(json!=null){
          code = json.getString("code")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          driver_id = json.getString("driver_id")
          inc_day = json.getLong("inc_day")
        }
        if(StringUtils.isEmpty(code)) code = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"
        if(inc_day==null) inc_day = Long.MaxValue

        ((code,system,sdk_ver,source,driver_id),(inc_day,json))
      })
      .groupByKey()
      .map(obj=>{
        var code = obj._1._1
        var system = obj._1._2
        var sdk_ver = obj._1._3
        var source = obj._1._4

        val sort = obj._2.toList.sortBy(_._1)
        val first_inc_day = sort.map(_._1).head
        val json = sort.map(_._2).head
        //        json
        ((code,system,sdk_ver,source),(first_inc_day.toString, json))
      })
      .groupByKey()
      .map(obj=>{
        var code = obj._1._1
        var system = obj._1._2
        var sdk_ver = obj._1._3
        var source = obj._1._4

        val new_count = obj._2.toList.count(o => date.equalsIgnoreCase(o._1))
        val all_count = obj._2.toList.length
        ((date,code,system,sdk_ver,source),(new_count, all_count))
      })
      .repartition(1000).persist()
    dateRdd1.unpersist()

    val startDate2 = DateUtil.getDateStr(date,-1)
    val endDate2 = date
    val dateRdd2 = getUserData2(spark,startDate2,endDate2)
    logger.error(">>>统计用户留存量")
    val resultRdd2 = dateRdd2
      .map(json=>{
        var code = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var driver_id = "-"
        var inc_day:java.lang.Long = Long.MaxValue

        if(json!=null){
          code = json.getString("code")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          driver_id = json.getString("driver_id")
          inc_day = json.getLong("inc_day")
        }
        if(StringUtils.isEmpty(code)) code = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"
        if(inc_day==null) inc_day = Long.MaxValue

        ((code,system,sdk_ver,source,driver_id),(inc_day.toString,json))
      })
      .groupByKey()
      .map(obj=>{
        var code = obj._1._1
        var system = obj._1._2
        var sdk_ver = obj._1._3
        var source = obj._1._4

        var flag = false
        val sort = obj._2.toList.sortBy(_._1)
        val map = sort.map(_._1)
        val json = sort.map(_._2).head
        if(sort!=null && map.contains(startDate2) && map.contains(endDate2)) flag = true
        ((code,system,sdk_ver,source),(flag, json))
      })
      .filter(obj=> obj._2._1)
      .groupByKey()
      .map(obj=>{
        var code = obj._1._1
        var system = obj._1._2
        var sdk_ver = obj._1._3
        var source = obj._1._4

        val keep_count = obj._2.toList.length
        ((date,code,system,sdk_ver,source),keep_count)
      })
      .repartition(1000).persist()
    dateRdd2.unpersist()

    val startDate3 = date
    val endDate3 = date
    val dateRdd3 = getUserData2(spark,startDate3,endDate3)
    logger.error(">>>统计当前时段内信息")
    val resultRdd3 = dateRdd3
      .map(json=>{
        var code = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"

        if(json!=null){
          code = json.getString("code")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
        }
        if(StringUtils.isEmpty(code)) code = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"

        ((date,code,system,sdk_ver,source),json)
      })
      .groupByKey()
      .map(obj=>{
        val key = obj._1

        var driver_count = 0
        var navi_count = 0

        driver_count = obj._2.toList.map(json => json.getString("driver_id")).distinct.size
        navi_count = obj._2.toList.map(json => json.getString("navi_id")).distinct.size

        (key,(driver_count, navi_count))
      })
      .repartition(1000).persist()
    dateRdd3.unpersist()

    val dateRdd4 = getStartNaviData(spark, date)
    logger.error(">>>统计开始导航数")
    val resultRdd4 = dateRdd4
      .map(json=>{
        var code = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"

        if(json!=null){
          code = json.getString("code")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
        }
        if(StringUtils.isEmpty(code)) code = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"

        ((date,code,system,sdk_ver,source),json)
      })
      .groupByKey()
      .map(obj=>{
        val key = obj._1

        var start_count = 0

        start_count = obj._2.toList.map(json => json.getString("navi_id")).distinct.size

        (key,start_count)
      })
      .repartition(1000).persist()
    dateRdd4.unpersist()


    logger.error(">>>合并各项数据")
    logger.error(">>>合并新增、总用户量和用户留存量")
    val resultRdd12 = resultRdd1.fullOuterJoin(resultRdd2)
      .map(obj =>{
        val key = obj._1
        var new_count = 0
        var all_count = 0
        var keep_count = 0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          new_count = r1._1
          all_count = r1._2
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          keep_count = result2.get
        }

        (key,(new_count,keep_count,all_count))
      }).repartition(1000).persist()
    resultRdd1.unpersist()
    resultRdd2.unpersist()

    logger.error(">>>合并当前时段内信息")
    val resultRdd23 = resultRdd12.fullOuterJoin(resultRdd3)
      .map(obj =>{
        var date = obj._1._1
        var code = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5
        var all_count = 0
        var new_count = 0
        var driver_count = 0
        var navi_count = 0
        var keep_count = 0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          new_count = r1._1
          keep_count = r1._2
          all_count = r1._3
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          val r2 = result2.get
          driver_count = r2._1
          navi_count = r2._2
        }

//        Array(date,code,system,sdk_ver,source,all_count,new_count,driver_count,navi_count,keep_count)
        (obj._1,(all_count,new_count,driver_count,navi_count,keep_count))
      }).repartition(1000).persist()
    resultRdd12.unpersist()
    resultRdd3.unpersist()

    logger.error(">>>合并开始导航数")
    val resultRdd = resultRdd23.fullOuterJoin(resultRdd4)
      .map(obj =>{
        var date = obj._1._1
        var code = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5
        var all_count = 0
        var new_count = 0
        var driver_count = 0
        var navi_count = 0
        var keep_count = 0
        var start_count = 0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          all_count = r1._1
          new_count = r1._2
          driver_count = r1._3
          navi_count = r1._4
          keep_count = r1._5
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          start_count = result2.get
        }

        Array(date,code,system,sdk_ver,source,all_count,new_count,driver_count,navi_count,keep_count,start_count)
      }).repartition(1).persist()
    logger.error(">>>统计用户日活表后的数据量："+resultRdd.count())
    resultRdd23.unpersist()
    resultRdd4.unpersist()

    resultRdd
  }


  /**
    * 按时段统计用户日活表
    * @param spark
    */
  def statUserDataTime2(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val startDate1 = DateUtil.getDateStr(date,-60)
    val endDate1 = date
    val dateRdd1 = getUserData2(spark,startDate1,endDate1)
    logger.error(">>>统计新增和总用户量")
    val resultRdd1 = dateRdd1
      .map(json=>{
        var code = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var driver_id = "-"
        var time:java.lang.Long = Long.MaxValue
        var req_day:java.lang.Long = Long.MaxValue
        var req_hour:java.lang.Long = Long.MaxValue

        if(json!=null){
          code = json.getString("code")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          driver_id = json.getString("driver_id")
          time = json.getLong("time")
          req_day = json.getLong("req_day")
          req_hour = json.getLong("req_hour")
        }
        if(StringUtils.isEmpty(code)) code = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"
        if(time==null) time = Long.MaxValue
        if(req_day==null) req_day = Long.MaxValue
        if(req_hour==null) req_hour = Long.MaxValue

        ((code,system,sdk_ver,source,driver_id),(time, req_day, req_hour, json))
      })
      .groupByKey()
      .map(obj=>{
        var code = obj._1._1
        var system = obj._1._2
        var sdk_ver = obj._1._3
        var source = obj._1._4

        val sort = obj._2.toList.sortBy(_._1)
        val first_req_time = sort.map(_._1).head
        val req_day = sort.map(_._2).head
        val req_hour = sort.map(_._3).head
        val json = sort.map(_._4).head
        ((code,system,sdk_ver,source),(req_day, req_hour, json))
      })
      .groupByKey()
      .flatMap(obj=>{
        var code = obj._1._1
        var system = obj._1._2
        var sdk_ver = obj._1._3
        var source = obj._1._4

        val list = new ArrayBuffer[((String,String,String,String,String,String),(Int,Int))]()

        for(i<-0.until(24)){
          val new_count = obj._2.toList.count(o => date.toLong == o._1 && i == o._2)
          val all_count = obj._2.toList.count(o => (date.toLong > o._1) || (date.toLong == o._1 && i >= o._2))
          val tmp = ((date,code,system,sdk_ver,source,i.toString),(new_count, all_count))
          list += tmp
        }
        list
      })
      .repartition(1000).persist()
    dateRdd1.unpersist()

    val startDate2 = DateUtil.getDateStr(date,-1)
    val endDate2 = date
    val dateRdd2 = getUserData2(spark,startDate2,endDate2)
    logger.error(">>>统计用户留存量")
    val resultRdd2 = dateRdd2
      .map(json=>{
        var code = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var driver_id = "-"
        var time:java.lang.Long = Long.MaxValue
        var req_day:java.lang.Long = Long.MaxValue
        var req_hour:java.lang.Long = Long.MaxValue

        if(json!=null){
          code = json.getString("code")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          driver_id = json.getString("driver_id")
          time = json.getLong("time")
          req_day = json.getLong("req_day")
          req_hour = json.getLong("req_hour")
        }
        if(StringUtils.isEmpty(code)) code = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(StringUtils.isEmpty(driver_id)) driver_id = "-"
        if(time==null) time = Long.MaxValue
        if(req_day==null) req_day = Long.MaxValue
        if(req_hour==null) req_hour = Long.MaxValue

        ((code,system,sdk_ver,source,driver_id),(req_day, req_hour))
      })
      .groupByKey()
      .flatMap(obj=>{
        var code = obj._1._1
        var system = obj._1._2
        var sdk_ver = obj._1._3
        var source = obj._1._4

        val list = new ArrayBuffer[((String,String,String,String,String,Int),(String,String,String,String,String,Int,Int))]()

        val sort = obj._2.toList.sortBy(_._1)
        if(sort!=null && sort.contains((startDate2.toLong,23l)) && sort.contains((date.toLong,0l))){
          val tmp = ((date,code,system,sdk_ver,source,0),(date,code,system,sdk_ver,source,0,1))
          list += tmp
        }
        else{
          val tmp = ((date,code,system,sdk_ver,source,0),(date,code,system,sdk_ver,source,0,0))
          list += tmp
        }

        for(i<-1.until(24)){
          if(sort!=null && sort.contains((date.toLong, (i-1).toLong)) && sort.contains((date.toLong, i.toLong))){
            val tmp = ((date,code,system,sdk_ver,source,i),(date,code,system,sdk_ver,source,i,1))
            list += tmp
          }
          else{
            val tmp = ((date,code,system,sdk_ver,source,i),(date,code,system,sdk_ver,source,i,0))
            list += tmp
          }
        }

        list
      })
      .reduceByKey((o1,o2)=>{
        (o1._1,o1._2,o1._3,o1._4,o1._5,o1._6,o1._7 + o2._7)
      }).values
      .map(o1=>{
        ((o1._1,o1._2,o1._3,o1._4,o1._5,o1._6.toString),o1._7)
      })
      .repartition(1000).persist()
    dateRdd2.unpersist()

    val startDate3 = date
    val endDate3 = date
    val dateRdd3 = getUserData2(spark,startDate3,endDate3)
    logger.error(">>>统计当前时段内信息")
    val resultRdd3 = dateRdd3
      .map(json=>{
        var code = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"
        var req_day:java.lang.Long = Long.MaxValue
        var req_hour:java.lang.Long = Long.MaxValue

        if(json!=null){
          code = json.getString("code")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_ver")
          source = json.getString("source")
          req_day = json.getLong("req_day")
          req_hour = json.getLong("req_hour")
        }
        if(StringUtils.isEmpty(code)) code = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"
        if(req_day==null) req_day = Long.MaxValue
        if(req_hour==null) req_hour = Long.MaxValue

        ((req_day.toString,code,system,sdk_ver,source,req_hour.toString),json)
      })
      .filter(obj=> date.equalsIgnoreCase(obj._1._1) && obj._1._6.toLong >= 0 && obj._1._6.toLong <= 23)
      .groupByKey()
      .map(obj=>{
        val key = obj._1

        var driver_count = 0
        var navi_count = 0

        driver_count = obj._2.toList.map(json => json.getString("driver_id")).distinct.size
        navi_count = obj._2.toList.map(json => json.getString("navi_id")).distinct.size

        (key,(driver_count, navi_count))
      })
      .repartition(1000).persist()
    dateRdd3.unpersist()

    logger.error(">>>合并各项数据")
    logger.error(">>>合并新增、总用户量和用户留存量")
    val resultRdd12 = resultRdd1.fullOuterJoin(resultRdd2)
      .map(obj =>{
        val key = obj._1
        var new_count = 0
        var all_count = 0
        var keep_count = 0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          new_count = r1._1
          all_count = r1._2
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          keep_count = result2.get
        }

        (key,(new_count, keep_count, all_count))
      }).repartition(1000).persist()
    resultRdd1.unpersist()
    resultRdd2.unpersist()

    logger.error(">>>合并当前时段内信息")
    val resultRdd = resultRdd12.fullOuterJoin(resultRdd3)
      .map(obj =>{
        var date = obj._1._1
        var code = obj._1._2
        var system = obj._1._3
        var sdk_ver = obj._1._4
        var source = obj._1._5
        var hour = obj._1._6
        var all_count = 0
        var new_count = 0
        var driver_count = 0
        var navi_count = 0
        var keep_count = 0

        val result1 = obj._2._1
        if(result1.nonEmpty) {
          val r1 = result1.get
          new_count = r1._1
          keep_count = r1._2
          all_count = r1._3
        }

        val result2 = obj._2._2
        if(result2.nonEmpty) {
          val r2 = result2.get
          driver_count = r2._1
          navi_count = r2._2
        }

        Array(date,code,system,sdk_ver,source,hour,all_count,new_count,driver_count,navi_count,keep_count)
      }).repartition(1).persist()
    logger.error(">>>统计用户日活表后的数据量："+resultRdd.count())
    resultRdd12.unpersist()
    resultRdd3.unpersist()

    resultRdd
  }





  /**
    * 获取导航日志数据
    * @param spark
    * @param startDate
    * @param endDate
    * @return
    */
  def getNaviData(spark:SparkSession, startDate:String, endDate:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
//    sql =
//      s"""
//         |select a.task_id,a.dest_zone_code,a.actual_depart_tm,a.main_driver_account,a.driver_source,b.navi_id,b.driver_id,b.dest_province,b.dest_citycode,b.dest_deptcode,b.system,b.sdk_version,c.properties,c.properties_username,c.event_id from
//         |(select task_id,dest_zone_code,actual_depart_tm,main_driver_account,driver_source from dm_grd.grd_new_task_detail where inc_day between '$startDate' and '$endDate') a
//         |left join (select task_id,navi_id,driver_id,dest_province,dest_citycode,dest_deptcode,system,sdk_version from dm_gis.gis_navi_result_union where inc_day between '$startDate' and '$endDate') b on a.task_id=b.task_id
//         |left join (select t1.properties_username,t1.properties,t1.event_id from ods_inc_ubas.product_inc_ubas_dev_shiva_trtms_driver t1,(select properties_username,max(time) time from ods_inc_ubas.product_inc_ubas_dev_shiva_trtms_driver where dt between '$startDate' and '$endDate' and event_id='ground_tbp_task_window_choose_navigate' group by properties_username) t2 where t1.dt between '$startDate' and '$endDate' and t1.event_id='ground_tbp_task_window_choose_navigate' and t1.properties_username = t2.properties_username and t1.time = t2.time group by t1.properties_username,t1.properties,t1.event_id) c on a.main_driver_account = c.properties_username
//       """.stripMargin
    sql =
      s"""
         |select a.task_id,a.dest_zone_code,a.actual_depart_tm,a.main_driver_account,a.driver_source,b.navi_id,b.driver_id,b.dest_province,b.dest_citycode,b.dest_deptcode,b.system,b.sdk_version,c.properties,c.properties_username,c.event_id from
         |(select task_id,dest_zone_code,actual_depart_tm,main_driver_account,driver_source from dm_grd.grd_new_task_detail where inc_day between '$startDate' and '$endDate') a
         |left join (select task_id,navi_id,driver_id,dest_province,dest_citycode,dest_deptcode,system,sdk_version from dm_gis.gis_navi_result_union where inc_day between '$startDate' and '$endDate') b on a.task_id=b.task_id
         |left join (select t1.properties_username,t1.properties,t1.event_id from ods_inc_ubas.product_inc_ubas_dev_shiva_trtms_driver t1,(select properties_username,max(time) time from ods_inc_ubas.product_inc_ubas_dev_shiva_trtms_driver where dt between '$startDate' and '$endDate' and event_id='ground_tbp_task_window_choose_navigate' group by properties_username) t2 where t1.dt between '$startDate' and '$endDate' and t1.event_id='ground_tbp_task_window_choose_navigate' and t1.properties_username = t2.properties_username and t1.time = t2.time) c on a.main_driver_account = c.properties_username
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd
      .map(json=>{
        var properties_username = json.getString("properties_username")
        var properties = json.getString("properties")
        var event_id = json.getString("event_id")
        if(StringUtils.isEmpty(properties_username)) properties_username = "-"
        if(StringUtils.isEmpty(properties)) properties = "-"
        if(StringUtils.isEmpty(event_id)) event_id = "-"

        ((properties_username,properties,event_id),json)
      })
      .groupByKey()
      .map(obj=>{
        val json = obj._2.toList.head
        json
      })
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        var source = "-"
        val driver_source = json.getString("driver_source")
        if(!StringUtils.isEmpty(driver_source)){
          if("0".equalsIgnoreCase(driver_source) || "3".equalsIgnoreCase(driver_source)) source = "自营"
          else if("1".equalsIgnoreCase(driver_source) || "2".equalsIgnoreCase(driver_source)) source = "外包"
        }
        else source = "-"
        json.put("source", source)

        var flag = "0"
        val task_id = json.getString("task_id")
        val main_driver_account = json.getString("main_driver_account")
        if(!StringUtils.isEmpty(main_driver_account) && !StringUtils.isEmpty(task_id)){
          breakable(
            Array("755Y","020Y","752Y","754Y","757Y","760Y","769Y").foreach(str=>{
              if(task_id.startsWith(str)){
                flag = "1"
                break
              }
            })
          )
        }
        json.put("flag", flag)


        var hour = "-"
        val actual_depart_tm = json.getString("actual_depart_tm")
        if(actual_depart_tm!=null){
          if(actual_depart_tm.length >= 13){
            hour = actual_depart_tm.substring(11,13)
          }
        }
        json.put("hour", hour)


        list += json

        val newJson1 = new JSONObject()
        newJson1.fluentPutAll(json)
        newJson1.put("system", "sum")
        list += newJson1

        val newJson2 = new JSONObject()
        newJson2.fluentPutAll(json)
        newJson2.put("source", "sum")
        list += newJson2

        val newJson3 = new JSONObject()
        newJson3.fluentPutAll(json)
        newJson3.put("system", "sum")
        newJson3.put("source", "sum")
        list += newJson3

        list
      })
      .repartition(1000).persist()
    logger.error(">>>日志量："+resultRdd.count())
    logRdd.unpersist()
    resultRdd
  }


  /**
    * 统计导航任务表
    * @param spark
    */
  def statNaviData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val dateRdd = getNaviData(spark,date,date)
    logger.error(">>>统计导航任务表")
    val dateRdd2 = dateRdd
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("dest_province")) && !"-".equalsIgnoreCase(json.getString("dest_province")) &&
          !StringUtils.isEmpty(json.getString("dest_citycode")) && !"-".equalsIgnoreCase(json.getString("dest_citycode")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_version")) && !"-".equalsIgnoreCase(json.getString("sdk_version")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source"))
      }).repartition(1000).persist()
    logger.error(">>>过滤后的数据量："+dateRdd2.count())
    val resultRdd = dateRdd2.map(json=>{
        var province = "-"
        var city = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"

        if(json!=null){
          province = json.getString("dest_province")
          city = json.getString("dest_citycode")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_version")
          source = json.getString("source")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"

        ((date,province,city,system,sdk_ver,source),json)
      })
      .groupByKey()
      .map(obj=>{
        var statdate = obj._1._1
        var province = obj._1._2
        var city = obj._1._3
        var system = obj._1._4
        var sdk_ver = obj._1._5
        var source = obj._1._6

        var user_count = 0
        var task_count = 0
        var click_user_count = 0
        var click_navi_count = 0
        var navi_user_count = 0
        var navi_count = 0

        val jsonList = obj._2.toList
        val flagList = jsonList.filter(json=>"1".equalsIgnoreCase(json.getString("flag")))
        val eventList = jsonList.filter(json=>"ground_tbp_task_window_choose_navigate".equalsIgnoreCase(json.getString("event_id")))

        user_count = flagList.map(json => json.getString("main_driver_account")).distinct.size
        task_count = flagList.map(json => json.getString("task_id")).distinct.size
        click_user_count = eventList.map(json => json.getString("properties_username")).distinct.size
        click_navi_count = eventList.map(json => {
          var taskId = ""
          var deptCode = ""
          val properties = json.getJSONObject("properties")
          if(properties!=null){
            taskId = properties.getString("taskId")
            deptCode = properties.getString("deptCode")
          }
          if(StringUtils.isEmpty(taskId)) taskId = ""
          if(StringUtils.isEmpty(deptCode)) deptCode = ""
          (taskId,deptCode)
        }).distinct.size
        navi_user_count = jsonList.filter(json=> !StringUtils.isEmpty(json.getString("driver_id"))).map(json => json.getString("driver_id")).distinct.size
        navi_count = jsonList.filter(json=> !StringUtils.isEmpty(json.getString("navi_id"))).map(json => json.getString("navi_id")).distinct.size

        Array(statdate,province,city,system,sdk_ver,source,user_count,task_count,click_user_count,click_navi_count,navi_user_count,navi_count)
      }).repartition(1).persist()
    logger.error(">>>统计导航任务表后的数据量："+resultRdd.count())
    dateRdd.unpersist()
    dateRdd2.unpersist()

    resultRdd
  }


  /**
    * 按时段统计导航任务表
    * @param spark
    */
  def statNaviDataTime(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val dateRdd = getNaviData(spark,date,date)
    logger.error(">>>按时段统计导航任务表")
    val resultRdd = dateRdd
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("dest_province")) && !"-".equalsIgnoreCase(json.getString("dest_province")) &&
          !StringUtils.isEmpty(json.getString("dest_citycode")) && !"-".equalsIgnoreCase(json.getString("dest_citycode")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_version")) && !"-".equalsIgnoreCase(json.getString("sdk_version")) &&
          !StringUtils.isEmpty(json.getString("source")) && !"-".equalsIgnoreCase(json.getString("source")) &&
          !StringUtils.isEmpty(json.getString("hour")) && !"-".equalsIgnoreCase(json.getString("hour"))
      })
      .map(json=>{
        var province = "-"
        var city = "-"
        var system = "-"
        var sdk_ver = "-"
        var source = "-"

        if(json!=null){
          province = json.getString("dest_province")
          city = json.getString("dest_citycode")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_version")
          source = json.getString("source")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
        if(StringUtils.isEmpty(source)) source = "-"

        ((date,province,city,system,sdk_ver,source),json)
      })
      .groupByKey()
      .flatMap(obj=>{
        var statdate = obj._1._1
        var province = obj._1._2
        var city = obj._1._3
        var system = obj._1._4
        var sdk_ver = obj._1._5
        var source = obj._1._6

        val list = new ArrayBuffer[Array[Any]]()

        for(i<-0.until(24)){
          var user_count = 0
          var task_count = 0
          var click_user_count = 0
          var click_navi_count = 0
          var navi_user_count = 0
          var navi_count = 0

          val jsonList = obj._2.toList.filter(json=> i.toString.equalsIgnoreCase(json.getString("hour")))

          val flagList = jsonList.filter(json=>"1".equalsIgnoreCase(json.getString("flag")))
          val eventList = jsonList.filter(json=>"ground_tbp_task_window_choose_navigate".equalsIgnoreCase(json.getString("event_id")))

          user_count = flagList.map(json => json.getString("main_driver_account")).distinct.size
          task_count = flagList.map(json => json.getString("task_id")).distinct.size
          click_user_count = eventList.map(json => json.getString("properties_username")).distinct.size
          click_navi_count = eventList.map(json => {
            var taskId = ""
            var deptCode = ""
            val properties = json.getJSONObject("properties")
            if(properties!=null){
              taskId = properties.getString("taskId")
              deptCode = properties.getString("deptCode")
            }
            if(StringUtils.isEmpty(taskId)) taskId = ""
            if(StringUtils.isEmpty(deptCode)) deptCode = ""
            (taskId,deptCode)
          }).distinct.size
          navi_user_count = jsonList.filter(json=> !StringUtils.isEmpty(json.getString("driver_id"))).map(json => json.getString("driver_id")).distinct.size
          navi_count = jsonList.filter(json=> !StringUtils.isEmpty(json.getString("navi_id"))).map(json => json.getString("navi_id")).distinct.size

          list += Array(statdate,province,city,system,sdk_ver,source,i.toString,user_count,task_count,click_user_count,click_navi_count,navi_user_count,navi_count)
        }

        list
      }).repartition(1).persist()
    logger.error(">>>按时段统计导航任务表后的数据量："+resultRdd.count())
    dateRdd.unpersist()

    resultRdd
  }


//  /**
//    * 按时段统计导航任务表
//    * @param spark
//    */
//  def statNaviDataTime(spark:SparkSession, date:String): RDD[Array[Any]] ={
//    val dateRdd = getNaviData(spark,date,date)
//    logger.error(">>>按时段统计导航任务表")
//    val resultRdd = dateRdd
//      .map(json=>{
//        var province = "-"
//        var city = "-"
//        var system = "-"
//        var sdk_ver = "-"
//        var source = "-"
//        var hour = "-"
//        var hour_i:java.lang.Integer = null
//
//        if(json!=null){
//          province = json.getString("dest_province")
//          city = json.getString("dest_citycode")
//          system = json.getString("system")
//          sdk_ver = json.getString("sdk_version")
//          source = json.getString("source")
//          hour_i = json.getInteger("hour")
//        }
//        if(StringUtils.isEmpty(province)) province = "-"
//        if(StringUtils.isEmpty(city)) city = "-"
//        if(StringUtils.isEmpty(system)) system = "-"
//        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"
//        if(StringUtils.isEmpty(source)) source = "-"
//        if(hour_i!=null) hour = hour_i.toString
//        else hour = "-"
//
//        ((date,province,city,system,sdk_ver,source),json)
//      })
//      .groupByKey()
//      .map(obj=>{
//        var statdate = obj._1._1
//        var province = obj._1._2
//        var city = obj._1._3
//        var system = obj._1._4
//        var sdk_ver = obj._1._5
//        var source = obj._1._6
//        var hour = obj._1._7
//
//        var user_count = 0
//        var task_count = 0
//        var click_user_count = 0
//        var click_navi_count = 0
//        var navi_user_count = 0
//        var navi_count = 0
//
//        val jsonList = obj._2.toList
//        val flagList = jsonList.filter(json=>"1".equalsIgnoreCase(json.getString("flag")))
//        val eventList = jsonList.filter(json=>"ground_tbp_task_window_choose_navigate".equalsIgnoreCase(json.getString("event_id")))
//
//        user_count = flagList.map(json => json.getString("main_driver_account")).distinct.size
//        task_count = flagList.map(json => json.getString("task_id")).distinct.size
//        click_user_count = eventList.map(json => json.getString("properties_username")).distinct.size
//        click_navi_count = eventList.map(json => {
//          var taskId = ""
//          var deptcode = ""
//          val properties = json.getJSONObject("properties")
//          if(properties!=null){
//            taskId = properties.getString("taskId")
//            deptcode = properties.getString("deptcode")
//          }
//          if(StringUtils.isEmpty(taskId)) taskId = ""
//          if(StringUtils.isEmpty(deptcode)) deptcode = ""
//          (taskId,deptcode)
//        }).distinct.size
//        navi_user_count = jsonList.filter(json=> !StringUtils.isEmpty(json.getString("driver_id"))).map(json => json.getString("driver_id")).distinct.size
//        navi_count = jsonList.filter(json=> !StringUtils.isEmpty(json.getString("navi_id"))).map(json => json.getString("navi_id")).distinct.size
//
//        Array(statdate,province,city,system,sdk_ver,source,hour,user_count,task_count,click_user_count,click_navi_count,navi_user_count,navi_count)
//      }).repartition(1).persist()
//    logger.error(">>>按时段统计导航任务表后的数据量："+resultRdd.count())
//    dateRdd.unpersist()
//
//    resultRdd
//  }







  /**
    * 获取导航选择情况数据
    * @param spark
    * @param startDate
    * @param endDate
    * @return
    */
  def getSelectData(spark:SparkSession, startDate:String, endDate:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.id,a.navi_id,a.driver_id,a.opt,a.src,b.src_province,b.src_citycode,a.inc_date from
         |(select id,navi_id,driver_id,opt,src,inc_day as inc_date from dm_gis.gis_navi_eta_result1 where inc_day between '$startDate' and '$endDate' and req_type='top3' and navi_id<>'' and navi_id is not null) a
         |left join (select id,src_province,src_citycode from dm_gis.gis_navi_eta_result2 where inc_day between '$startDate' and '$endDate') b on a.id=b.id
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd
      .map(json =>{
        var navi_id = "-"
        if(json!=null) navi_id = json.getString("navi_id")

        (navi_id,json)
      })
      .groupByKey()
      .map(obj=>{
        val json = obj._2.toList.head
        json
      })
      .repartition(64000).persist()
    logger.error(">>>按navi_id去重后的数据量："+resultRdd.count())
    logRdd.unpersist()
    resultRdd
  }


  /**
    * 导航选择情况统计
    * @param spark
    */
  def statSelectData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val dateRdd = getSelectData(spark,date,date)
    logger.error(">>>导航选择情况统计")
    val selectIndexRdd = dateRdd.map(json=>{
      var driver_id = json.getString("driver_id")
      var src_province = json.getString("src_province")
      var src_citycode = json.getString("src_citycode")
      if(driver_id==null ||driver_id==""){
        driver_id=""
      }
      if(src_province==null ||src_province==""){
        src_province="-"
      }
      if(src_citycode==null ||src_citycode==""){
        src_citycode="-"
      }

      val opt = json.getString("opt")
      val src = json.getString("src")

      var navi_count,user_count,opt_top3_count,opt_jy_count,opt_sf_count,opt_gd3_count,src_jy_count,src_sf_count,src_gd_count = 0
      navi_count = 1

      if("top3".equalsIgnoreCase(opt)) opt_top3_count = 1
      else if("jy".equalsIgnoreCase(opt)) opt_jy_count = 1
      else if("sf".equalsIgnoreCase(opt)) opt_sf_count = 1
      else if("gd3".equalsIgnoreCase(opt)) opt_gd3_count = 1

      if("jy".equalsIgnoreCase(src)) src_jy_count = 1
      else if("sf".equalsIgnoreCase(src)) src_sf_count = 1
      else if("gd".equalsIgnoreCase(src)) src_gd_count = 1

      val key = Array(date,src_province,src_citycode).mkString(",")
      (key,(driver_id,NaviStat.SelectObj(date,src_province,src_citycode,navi_count,user_count,opt_top3_count,opt_jy_count,opt_sf_count,opt_gd3_count,src_jy_count,src_sf_count,src_gd_count)))
    })
      .groupByKey()
      .map(obj=>{
        val driver_ids = obj._2.map(o => o._1).filter(s=> !StringUtils.isEmpty(s)).toList
        val driver_id_count = driver_ids.distinct.size
        val objs = obj._2.map(o => o._2).toList
        objs.reduce((o1, o2) => {
          SelectObj(o1.statdate,o1.province,o1.citycode,o1.navi_count + o2.navi_count,driver_id_count,o1.opt_top3_count + o2.opt_top3_count,o1.opt_jy_count + o2.opt_jy_count,o1.opt_sf_count + o2.opt_sf_count,o1.opt_gd3_count + o2.opt_gd3_count,o1.src_jy_count + o2.src_jy_count,o1.src_sf_count + o2.src_sf_count,o1.src_gd_count + o2.src_gd_count)
        })
      })
      .map(o1=>
      Array(o1.statdate,o1.province,o1.citycode,o1.navi_count,o1.user_count,o1.opt_top3_count,o1.opt_jy_count,o1.opt_sf_count,o1.opt_gd3_count,o1.src_jy_count,o1.src_sf_count,o1.src_gd_count)
    ).repartition(1).persist()
    logger.error(">>>导航选择情况统计后的数据量："+selectIndexRdd.count())
    dateRdd.unpersist()

    selectIndexRdd
  }



  /**
    * 获取偏航反应时间日志数据
    * @param spark
    * @param startDate
    * @param endDate
    * @return
    */
  def getReactData(spark:SparkSession, startDate:String, endDate:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.task_id,a.navi_id,a.req_type,b.sdk_version,b.system,c.dest_province,c.dest_citycode,c.dest_deptcode,c.yaw_time,a.inc_day from
         |(select id,task_id,navi_id,req_type,inc_day from dm_gis.gis_navi_eta_result1 where inc_day between '$startDate' and '$endDate' and navi_starttime<>'') a
         |left join (select navi_id,max(sdk_version) as sdk_version,max(system) as system from dm_gis.gis_navi_result_union where inc_day between '$startDate' and '$endDate' group by navi_id) b on a.navi_id=b.navi_id
         |left join (select id,dest_province,dest_citycode,dest_deptcode,yaw_time from dm_gis.gis_navi_eta_result2 where inc_day between '$startDate' and '$endDate') c on a.id=c.id
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd.flatMap(json=>{
      val list = new ArrayBuffer[JSONObject]()

//      var system = "-"
//      val navi_id = json.getString("navi_id")
//      if(!StringUtils.isEmpty(navi_id)){
//        if(navi_id.endsWith("0")) system = "android"
//        else if(navi_id.endsWith("1")) system = "ios"
//      }
//      json.put("system", system)

      list += json

      val newJson1 = new JSONObject()
      newJson1.fluentPutAll(json)
      newJson1.put("system", "sum")
      list += newJson1

      val newJson2 = new JSONObject()
      newJson2.fluentPutAll(json)
      newJson2.put("sdk_version", "sum")
      list += newJson2

      val newJson3 = new JSONObject()
      newJson3.fluentPutAll(json)
      newJson3.put("system", "sum")
      newJson3.put("sdk_version", "sum")
      list += newJson3

      list
    }).repartition(64000).persist()
    logRdd.unpersist()
    resultRdd
  }


  /**
    * 统计偏航反应时间
    * @param spark
    */
  def statReactData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val dateRdd = getReactData(spark,date,date)
    logger.error(">>>统计偏航反应时间")
    val resultRdd = dateRdd
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("dest_province")) && !"-".equalsIgnoreCase(json.getString("dest_province")) &&
          !StringUtils.isEmpty(json.getString("dest_citycode")) && !"-".equalsIgnoreCase(json.getString("dest_citycode")) &&
          !StringUtils.isEmpty(json.getString("dest_deptcode")) && !"-".equalsIgnoreCase(json.getString("dest_deptcode")) &&
          !StringUtils.isEmpty(json.getString("system")) && !"-".equalsIgnoreCase(json.getString("system")) &&
          !StringUtils.isEmpty(json.getString("sdk_version")) && !"-".equalsIgnoreCase(json.getString("sdk_version"))
      })
      .map(json=>{
        var province = "-"
        var city = "-"
        var deptcode = "-"
        var system = "-"
        var sdk_ver = "-"

        if(json!=null){
          province = json.getString("dest_province")
          city = json.getString("dest_citycode")
          deptcode = json.getString("dest_deptcode")
          system = json.getString("system")
          sdk_ver = json.getString("sdk_version")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(city)) city = "-"
        if(StringUtils.isEmpty(deptcode)) deptcode = "-"
        if(StringUtils.isEmpty(system)) system = "-"
        if(StringUtils.isEmpty(sdk_ver)) sdk_ver = "-"

        ((date,province,city,deptcode,system,sdk_ver),json)
      })
      .groupByKey()
      .map(obj=>{
        var statdate = obj._1._1
        var province = obj._1._2
        var city = obj._1._3
        var deptcode = obj._1._4
        var system = obj._1._5
        var sdk_ver = obj._1._6

        var navi_count = 0
        var yaw_count = 0
        var react_time = 0.0
        var react_time99 = 0.0
        var react_time95 = 0.0
        var react_time90 = 0.0


        val jsonList = obj._2.toList

        navi_count = jsonList.filter(json=> !StringUtils.isEmpty(json.getString("navi_id"))).map(json => json.getString("navi_id")).distinct.size
//        yaw_count = jsonList.filter(json=> "yaw".equalsIgnoreCase(json.getString("req_type"))).size
        yaw_count = jsonList.count(json=> "yaw".equalsIgnoreCase(json.getString("req_type")))
        if(yaw_count > 0){
          val fiter_jsonList = jsonList.filter(json=> ("yaw".equalsIgnoreCase(json.getString("req_type")) || "top3".equalsIgnoreCase(json.getString("req_type")))
          && !StringUtils.isEmpty(json.getString("yaw_time")) && !"0".equalsIgnoreCase(json.getString("yaw_time")))

          if(fiter_jsonList!=null && fiter_jsonList.nonEmpty){
            val react_jsonList = fiter_jsonList.sortBy(json => json.getLong("yaw_time")).map(json=> json.getLong("yaw_time").toLong)
            if(react_jsonList !=null && react_jsonList.nonEmpty){
              val react_count = react_jsonList.size
              val react_time_sum = react_jsonList.sum
              if(react_count!= 0) react_time = react_time_sum.toDouble / react_count

              val react_count99 = math.ceil(react_count * 0.99).toInt
              val react_time_sum99 = react_jsonList.take(react_count99).sum
              if(react_count99!= 0) react_time99 = react_time_sum99.toDouble / react_count99

              val react_count95 = math.ceil(react_count * 0.95).toInt
              val react_time_sum95 = react_jsonList.take(react_count95).sum
              if(react_count95!= 0) react_time95 = react_time_sum95.toDouble / react_count95

              val react_count90 = math.ceil(react_count * 0.90).toInt
              val react_time_sum90 = react_jsonList.take(react_count90).sum
              if(react_count90!= 0) react_time90 = react_time_sum90.toDouble / react_count90
            }
          }
        }

        Array(statdate,province,city,deptcode,system,sdk_ver,navi_count,yaw_count,react_time,react_time99,react_time95,react_time90)
      }).repartition(1).persist()
    logger.error(">>>统计偏航反应时间后的数据量："+resultRdd.count())
    dateRdd.unpersist()

    resultRdd
  }





  /**
    * 获取导航完成率日志数据
    * @param spark
    * @param date
    * @return
    */
  def getFinishData(spark:SparkSession, date:String):RDD[JSONObject] ={
    var sql=""
    var logRdd:RDD[JSONObject] = null
    sql =
      s"""
         |select a.id,b.src,b.distance,c.src_province,c.src_citycode,c.navi_distance from
         |(select max(id) as id from dm_gis.gis_navi_eta_result1 where inc_day='$date' and req_type='top3' and id is not null and id<>'' group by navi_id) a
         |left join (select id,src,distance from dm_gis.gis_navi_eta_result1 where inc_day='$date' and req_type='top3' and id is not null and id<>'') b on a.id=b.id
         |left join (select id,src_province,src_citycode,navi_distance from dm_gis.gis_navi_eta_result2 where inc_day='$date' and req_type='top3' and id is not null and id<>'') c on a.id=c.id
       """.stripMargin
    logRdd = getValidJson(spark, sql)
    logRdd
  }


  /**
    * 统计导航完成率
    * @param spark
    */
  def statFinishData(spark:SparkSession, date:String): RDD[Array[Any]] ={
    val dateRdd = getFinishData(spark,date)
    logger.error(">>>统计导航完成率")
    val resultRdd = dateRdd
      .filter(json=>{
        !StringUtils.isEmpty(json.getString("src_province")) && !"-".equalsIgnoreCase(json.getString("src_province")) &&
          !StringUtils.isEmpty(json.getString("src_citycode")) && !"-".equalsIgnoreCase(json.getString("src_citycode")) &&
          !StringUtils.isEmpty(json.getString("src")) && !"-".equalsIgnoreCase(json.getString("src"))
      })
      .map(json=>{
        var province = "-"
        var citycode = "-"
        var src = "-"

        if(json!=null){
          province = json.getString("src_province")
          citycode = json.getString("src_citycode")
          src = json.getString("src")
        }
        if(StringUtils.isEmpty(province)) province = "-"
        if(StringUtils.isEmpty(citycode)) citycode = "-"
        if(StringUtils.isEmpty(src)) src = "-"

        var key = Array(date,province,citycode,src).mkString("_")


        var total_count = 1
        var count1,count2,count3,count4,count5 = 0

        val distance = json.getDouble("distance")
        val navi_distance = json.getDouble("navi_distance")
        if(distance!=null && navi_distance!=null && distance!=0){
          val ratio = navi_distance / distance
          if(ratio < 0.1) total_count = 1
          else if(ratio >= 0.1 && ratio < 0.3) count1 = 1
          else if(ratio >= 0.3 && ratio < 0.5) count2 = 1
          else if(ratio >= 0.5 && ratio < 0.8) count3 = 1
          else if(ratio >= 0.8){
            count4 = 1
            if(ratio >= 0.9) count5 = 1
          }
        }


        (key,FinishObj(date,province,citycode,src,total_count,count1,count2,count3,count4,count5))
      })
      .reduceByKey((o1,o2)=>{
        FinishObj(o1.statdate,o1.province,o1.citycode,o1.src,o1.total_count+o2.total_count,o1.count1+o2.count1,o1.count2+o2.count2,o1.count3+o2.count3,o1.count4+o2.count4,o1.count5+o2.count5)
      }).values.map(o1=>{
      Array(o1.statdate,o1.province,o1.citycode,o1.src,o1.total_count,o1.count1,o1.count2,o1.count3,o1.count4,o1.count5)
    }).repartition(1).persist()
    logger.error(">>>统计导航完成率后的数据量："+resultRdd.count())
    dateRdd.unpersist()

    resultRdd
  }









  /**
    * 时间戳转换为时分秒
    * @param timestamp
    * @return
    */
  def longToTime(timestamp:Long,format:String="yyyy-MM-dd HH:mm:ss"): String ={
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e:Exception =>logger.error(">>>时间戳解析异常")
    }
    datetime
  }


  /**
    * 过滤有效日志
    * @param spark
    * @param sql
    * @return
    */
  def getValidJson(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(6400).map(row=>{
      val json = new JSONObject()
      for(i<-fields.indices){
        if("properties".equalsIgnoreCase(header(i))){
          json.put(header(i),row.getMap(i))
        }
        else json.put(header(i),row.getString(i))
      }
      json
    }).filter(_!=null).repartition(6400).persist()
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }


  /**
    * 把请求量和准确率指标存在mysql中
    * @param indexRdd
    * @param date
    */
  def saveToMysql(indexRdd:RDD[Array[Any]],table:String,structs:Array[String],date:String): Unit ={
    try {
      val connection = getConnection()
      val fields = structs.mkString(",")
      val values = structs.map(_=>"?").mkString(",")
      val deleteSql = s"DELETE FROM $table WHERE STATDATE='$date'"
      println(">>>清除当日数据："+deleteSql)
      DbUtil.execute(connection,deleteSql,null)
      val params = indexRdd.collect().toList
      logger.error(">>>当日统计指标数据量："+params.size)
      val insertSql =
        s"""
           |INSERT INTO $table ($fields)
           |VALUES ($values)
             """.stripMargin
      DbUtil.batchListExecute(connection,insertSql,params)
      connection.close()
      logger.error(">>>指标入mysql库的" + table + "表结束！")
    } catch {
      case e:Exception=>logger.error(">>>指标mysql库的" + table + "异常："+e)
    }
  }


  /**
    * 统计和入库流程
    * @param spark
    * @param parseRdd
    * @param statRddF
    * @param saveMysqlF
    * @param saveHiveF
    * @param table1
    * @param structs1
    * @param table2
    * @param structs2
    * @param date
    */
  def statSaveIndex(spark:SparkSession, parseRdd:RDD[JSONObject], statRddF:(SparkSession,String)=>RDD[Array[Any]], saveMysqlF:(RDD[Array[Any]],String,Array[String],String)=>Unit, saveHiveF:(SparkSession,RDD[Array[String]],String,Array[String],String,String)=>Unit, table1:String, structs1:Array[String], table2:String, structs2:Array[String], date:String): Unit ={
    var indexRdd:RDD[Array[Any]] = null
    indexRdd = statRddF(spark, date)
    val indexRdd2 = indexRdd.map(array=>array.map(_.toString))
    indexRdd.unpersist()
    saveHiveF(spark,indexRdd2,table2,structs2,date,"")
    indexRdd2.unpersist()
  }


  def saveArrayRDDToHive(spark: SparkSession, resultRdd: RDD[Array[String]], table: String, structs:Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if(StringUtils.isEmpty(dataBase)) database = "dm_gis"
    else database = dataBase
    try {
      logger.error(">>>table=" + database + "." + table)
      spark.sql(s"use $database")
      //1 构造DataFrame的元数据 StructField
      val structFileds = new util.ArrayList[StructField]()
      for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
      //2 构建StructType用于DataFrame的元数据描述
      val structType = DataTypes.createStructType(structFileds)
      //3 构建Row格式数据集RDD[Row]
      val rowRdd = resultRdd.filter(_!=null).map(v => {
        var row: Row = null
        try {
          row = RowFactory.create(v)
        } catch {
          case e: Exception => logger.error(">>>构造row异常:" + e + "," + v)
        }
        row
      }).filter(_ != null)
      // 4 构建DataFrame
      val df: DataFrame = spark.createDataFrame(rowRdd, structType)
      //5 基于Datarame创建临时表
      val tempView = String.format("%s_temp_view", table)
      //6 分区、表等操作
      val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
      logger.error(">>>新建分区：" + createPartitionSql)
      spark.sql(createPartitionSql)
      //7 把临时表的数据刷进hive表中
      spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
      logger.error(">>>数据入hive库结束!")
    }
    catch {
      case e:Exception =>logger.error(">>>" + database + "." + table + "数据入库异常："+e)
    }
  }


  def getConnection(): Connection ={
    Class.forName("com.mysql.jdbc.Driver").newInstance()
    @transient val connection = DriverManager.getConnection(url,"gis_oms_pns","gis_oms_pns@123@")
    connection
  }



}
