//package demand.navi
//
//import java.text.{DecimalFormat, SimpleDateFormat}
//import java.util.Date
//import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
//import demand.utils._
//import org.apache.commons.lang3.StringUtils
//import org.apache.log4j.Logger
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.SparkSession
//import scala.collection.mutable.ArrayBuffer
//import scala.util.control.Breaks.{break, breakable}
//
///**
//  * Created by 01368978 on 2021/5/28.
//  */
//object NaviUnion {
//  val appName:String = this.getClass.getSimpleName.replace("$","")
//  val logger:Logger = Logger.getLogger(appName)
//  val df = new DecimalFormat("0.0000")
//  var isEnd = false
//  var repartition = 500
//  //val rectify_url = "http://tlocrectify-gis-lss-tloc.dcn2.k8s.sf-express.com/lssrectify/api/rectify"
//  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
//  //val compare_track_url = "http://tlocrectify-gis-lss-tloc.dcn2.k8s.sf-express.com/lssrectify/api/comparetracks"
//  val compare_track_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"
//
//
//  def main(args: Array[String]): Unit = {
//    if(args.length > 1){
//      val runType = args(0)
//      val logType = args(1)
//      val spark = SparkUtil.getSparkSession(appName)
//      logger.error(">>>处理" + logType)
//
//      if (args.length == 2) {
//        //代码内部传入日期参数
//        UnionLog(spark, runType, logType, DateUtil.getToday, "true")
//      } else if (args.length == 3) {
//        //传入参数，单天任务
//        UnionLog(spark, runType, logType, args(2), "false")
//      } else if (args.length == 4) {
//        //传入参数，多天任务 [左闭右开)
//        batchTask(spark, runType, logType, args(2), args(3))
//      }
//
//
////      var startDate = "20211210"
////      var endDate = "20211213"
////      batchTask(spark, runType, logType, startDate, endDate)
//
//      spark.stop()
//      logger.error(">>>处理完毕---------------")
//    }
//  }
//
//
//
//
//
//  /**
//    * 批量任务
//    *
//    * @param spark
//    * @param runType
//    * @param logType
//    * @param startDate
//    * @param endDate
//    */
//  def batchTask(spark: SparkSession, runType:String, logType:String, startDate: String, endDate: String): Unit = {
//    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
//    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
//    for (date <- dateList) {
//      UnionLog(spark, runType, logType, date, "false")
//    }
//  }
//
//
//  /**
//    * 解析日志
//    * @param spark
//    * @param runType
//    * @param logType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def UnionLog(spark:SparkSession, runType:String, logType:String, date:String, auto:String):Unit ={
//    var getRddF:(SparkSession,String,String,String) => (RDD[JSONObject],ArrayBuffer[String]) = null
//    var computeRddF:(RDD[JSONObject]) => RDD[JSONObject] = null
//    var table = ""
//    var structs:Array[String] = null
//    var keys:Array[String] = null
//    var saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit = null
//
//    saveHiveRddF = NaviMain.mutiDayRddToHive
//
//    if("monitor".equalsIgnoreCase(logType)){
//      if("3".equalsIgnoreCase(runType)){
//        isEnd = true
//      }
//      getRddF = getFinishMonitorRdd
//      computeRddF = null
//      table = "gis_navi_finish_monitor"
//      structs = Array("task_id","navi_id","endx","endy","navi_logtype","navi_endtype","navi_endtime","navi_endx","navi_endy","distance","status","vehicle","vehicle_type","weight","mload","length","axle_number","navi_starttime","starttime_type")
//      keys = Array("task_id","navi_id","endx","endy","navi_logtype","navi_endtype","navi_endtime","navi_endx","navi_endy","distance","status","vehicle","vehicle_type","weight","mload","length","axle_number","navi_starttime","starttime_type")
//    }
//    else if("rectify".equalsIgnoreCase(logType)){
//      getRddF = getRectifyRdd
//      computeRddF = null
//      table = "gis_navi_rectify_result"
//      structs = Array("navi_id","vehicle","vehicle_type","weight","mload","length","axle_number","navi_starttime","navi_endtime","tracks1","tracks2","offtime_ratio","stay_list","len","ret","starttime_type")
//      keys = Array("navi_id","vehicle","vehicle_type","weight","mload","length","axle_number","navi_starttime","navi_endtime","tracks1","tracks2","offtime_ratio","stay_list","len","ret","starttime_type")
//    }
//    else if("clickroute".equalsIgnoreCase(logType)){
//      getRddF = getTop3ClickRouteRdd
//      computeRddF = null
//      table = "gis_navi_top3_click_route"
//      structs = Array("task_id","navi_id","navi_starttime","routeid","route_index","request_id","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","merge","routeid_in","fixed_route","fencedist","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","ak","start_speed","vehicle_dir1","rect_result","strategy2","routetype","merge_result","starts","starttime_type","driver_type","is_econ","service_id","line_code","navi_type","gd_polyline")
//      keys = Array("task_id","navi_id","navi_starttime","routeid","route_index","request_id","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","merge","routeid_in","fixed_route","fencedist","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","ak","start_speed","vehicle_dir1","rect_result","strategy2","routetype","merge_result","starts","starttime_type","driver_type","is_econ","service_id","line_code","navi_type","gd_polyline")
//    }
//    else if("yawroute".equalsIgnoreCase(logType)){
//      getRddF = getYawRouteRdd
//      computeRddF = null
//      table = "gis_navi_yaw_route"
//      structs = Array("task_id","navi_id","navi_starttime","routeid","hasyaw","request_id","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","merge","routeid_in","fixed_route","fencedist","reroute","swid","starts","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","ak","rect_result","strategy2","routetype","merge_result","is_econ","service_id","line_code","navi_type")
//      keys = Array("task_id","navi_id","navi_starttime","new_routeid","hasyaw","request_id","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","merge","routeid_in","fixed_route","fencedist","reroute","swid","starts","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","ak","rect_result","strategy2","routetype","merge_result","is_econ","service_id","line_code","navi_type")
//    }
//    else if("noyawroute".equalsIgnoreCase(logType)){
//      getRddF = getNoYawRouteRdd
//      computeRddF = null
//      table = "gis_navi_noyaw_route"
//      structs = Array("task_id","navi_id","navi_starttime","routeid","request_id","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","swid","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","ak")
//      keys = Array("task_id","navi_id","navi_starttime","routeid","request_id","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","swid","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","ak")
//    }
//    else if("etaresult".equalsIgnoreCase(logType)){
//      getRddF = getEtaResultRdd
//      computeRddF = null
//      table = "gis_navi_eta_result"
//      structs = Array("task_id","navi_count","navi_order","navi_id","navi_starttime","route_count","route_order","routeid","req_count","req_order","request_id","req_time","req_type","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","merge","routeid_in","fixed_route","fencedist","reroute","swid","starts","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","navi_endstatus","navi_endtime","navi_endx","navi_endy","navi_time","diff_time","ft_right","tl_times","tl_navi_time","tl_diff_time","tl_ft_right","req_status","similarity1","similarity5","tracks1","tracks2","navi_distance","ret","offtime_ratio","yawpoints","yawpoints_count","start_speed","vehicle_dir1","rect_result","strategy2","routetype","merge_result","links2","t1","yaw_time")
//      keys = Array("task_id","navi_count","navi_order","navi_id","navi_starttime","route_count","route_order","routeid","req_count","req_order","request_id","req_time","req_type","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","merge","routeid_in","fixed_route","fencedist","reroute","swid","starts","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","navi_endstatus","navi_endtime","navi_endx","navi_endy","navi_time","diff_time","ft_right","tl_times","tl_navi_time","tl_diff_time","tl_ft_right","req_status","similarity1","similarity5","tracks1","tracks2","navi_distance","ret","offtime_ratio","yawpoints","yawpoints_count","start_speed","vehicle_dir1","rect_result","strategy2","routetype","merge_result","links2","t1","yaw_time")
//    }
//    else if("etaresult1".equalsIgnoreCase(logType)){
//      getRddF = getEtaResult1Rdd
//      computeRddF = null
//      table = "gis_navi_eta_result1"
//      structs = Array("id","task_id","navi_count","navi_order","navi_id","route_count","route_order","routeid","req_count","req_order","request_id","navi_starttime","starttime_type","req_time","req_type","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","merge","routeid_in","fixed_route","fencedist","reroute","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","linknum","rc_distance","rdynsdlen","rdynsdcnt","navi_endstatus","navi_endtime","navi_endx","navi_endy","navi_time","diff_time","ft_right","tl_times","tl_navi_time","tl_diff_time","tl_ft_right","req_status","ret","offtime_ratio","yawpoints","yawpoints_count","start_speed","vehicle_dir1","rect_result","strategy2","routetype","merge_result","driver_type","start_type","is_econ","service_id","line_code","navi_type","route_index","navi_strategy","sdk_type")
//      keys = Array("id","task_id","navi_count","navi_order","navi_id","route_count","route_order","routeid","req_count","req_order","request_id","navi_starttime","starttime_type","req_time","req_type","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","stype","path_count","opt","strategy","merge","routeid_in","fixed_route","fencedist","reroute","status","pns_status","distance","duration","toll_distance","tolls","src","trafficlight_count","highspeed_distance","flen","tlen","routeid_out","linknum","rc_distance","rdynsdlen","rdynsdcnt","navi_endstatus","navi_endtime","navi_endx","navi_endy","navi_time","diff_time","ft_right","tl_times","tl_navi_time","tl_diff_time","tl_ft_right","req_status","ret","offtime_ratio","yawpoints","yawpoints_count","start_speed","vehicle_dir1","rect_result","strategy2","routetype","merge_result","driver_type","start_type","is_econ","service_id","line_code","navi_type","route_index","navi_strategy","sdk_type")
//    }
//    else if("etaresult2".equalsIgnoreCase(logType)){
//      getRddF = getEtaResult2Rdd
//      computeRddF = null
//      table = "gis_navi_eta_result2"
//      structs = Array("id","task_id","navi_id","routeid","request_id","navi_starttime","starttime_type","req_time","navi_endtime","req_type","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","swid","starts","polyline","links","links2","tracks1","tracks2","navi_distance","similarity1","similarity5","t1","yaw_time","trackstart_distance","trackend_distance","gd_polyline","gdsimilarity1","gdsimilarity5")
//      keys = Array("id","task_id","navi_id","routeid","request_id","navi_starttime","starttime_type","req_time","navi_endtime","req_type","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","swid","starts","polyline","links","links2","tracks1","tracks2","navi_distance","similarity1","similarity5","t1","yaw_time","trackstart_distance","trackend_distance","gd_polyline","gdsimilarity1","gdsimilarity5")
//    }
//    else if("bft".equalsIgnoreCase(logType)){
//      getRddF = getPnsRouteUnionRdd
//      computeRddF = null
//      table = "gis_navi_bft_route_similarity"
//      structs = Array("pns_logtype","request_id","req_time","no","origin","destination","route_index","route_id","distance","polyline","links","strategy","src","status","navi_id","tracks2","similarity1","similarity5","navi_endtime")
//      keys = Array("pns_logtype","request_id","req_time","no","origin","destination","route_index","route_id","distance","polyline","links","strategy","src","status","navi_id","tracks2","similarity1","similarity5","navi_endtime")
//    }
//    else if("recall".equalsIgnoreCase(logType)){
//      getRddF = getRecallRdd
//      computeRddF = null
//      table = "gis_navi_recall_result"
//      structs = Array("reqid","navi_id","routeid","request_id","status","req_order","req_count","dest_province","dest_region","dest_citycode","dest_deptcode","dest_sitecode","src_province","src_region","src_citycode","src_deptcode","src_sitecode","line_type","starttime","start_time","linecode","vehicle","vehicle_type","passport","weight","loadweight","full_loadweight","length","width","height","axle_number","axle_weight","vehicle_color","energy","emit_stand","distance","reqtime","req_time","x1","y1","x2","y2","ft_time","ft_status","ft_dist","ft_highway","ft_tralightcount","ft_tolls","ft_tollsdistance","ft_coords","ft_url","ft_flen","ft_tlen","endtime","end_time","similarity1","similarity5","tracks2","rdynsdlen","rdynsdcnt","driver_id","tl_endtime","actual_time_diff","opt","routeid_input","routeid_output")
//      keys = Array("reqid","navi_id","routeid","request_id","status","req_order","req_count","dest_province","dest_region","dest_citycode","dest_deptcode","dest_sitecode","src_province","src_region","src_citycode","src_deptcode","src_sitecode","line_type","starttime","start_time","linecode","vehicle","vehicle_type","passport","weight","loadweight","full_loadweight","length","width","height","axle_number","axle_weight","vehicle_color","energy","emit_stand","distance","reqtime","req_time","x1","y1","x2","y2","ft_time","ft_status","ft_dist","ft_highway","ft_tralightcount","ft_tolls","ft_tollsdistance","ft_coords","ft_url","ft_flen","ft_tlen","endtime","end_time","similarity1","similarity5","tracks2","rdynsdlen","rdynsdcnt","driver_id","tl_endtime","actual_time_diff","opt","routeid_input","routeid_output")
//    }
//    else if("union".equalsIgnoreCase(logType)){
//      getRddF = getUnionResultRdd
//      computeRddF = null
//      table = "gis_navi_result_union"
//      structs = Array("task_id","navi_id","navi_count","navi_order","route_count","route_order","route_count_all","routeid","hasyaw","src_province","dest_province","src_citycode","dest_citycode","src_deptcode","dest_deptcode","navi_starttime","req_time","route_type","x1","y1","x2","y2","vehicle","driver_id","sdk_version","route_src","ft_url","status","polyline","tracks","segement","navi_endstatus","navi_endtime","endx","endy","navi_endtype","navi_cost","navi_distance","route_cost","system","ak","start_speed","vehicle_dir1","rect_result","strategy","routetype","merge_result","starts","starttime_type","driver_type","start_type","is_econ","service_id","line_code","navi_type")
//      keys = Array("task_id","navi_id","navi_count","navi_order","route_count","route_order","route_count_all","routeid","hasyaw","src_province","dest_province","src_citycode","dest_citycode","src_deptcode","dest_deptcode","navi_starttime","req_time","route_type","x1","y1","x2","y2","vehicle","driver_id","sdk_version","route_src","ft_url","status","polyline","tracks","segement","navi_endstatus","navi_endtime","endx","endy","navi_endtype","navi_cost","navi_distance","route_cost","system","ak","start_speed","vehicle_dir1","rect_result","strategy","routetype","merge_result","starts","starttime_type","driver_type","start_type","is_econ","service_id","line_code","navi_type")
//    }
//    else if("top3_route_similarity".equalsIgnoreCase(logType)){
//      getRddF = getTop3RouteSimilarityRdd
//      computeRddF = null
//      table = "gis_navi_top3_route_similarity"
//      structs = Array("request_id","top3_status","top3_info","err_status","err_info","route_count","route_index","routeid","x1","y1","x2","y2","distance","duration","toll_distance","tolls","src","trafficlight_count","routeid_out","is_same","is_match","flen","tlen","highspeed_distance","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","navi_id","task_id","navi_starttime","navi_endtime","ret","offtime_ratio","navi_distance","tracks1","tracks2","similarity1","similarity5")
//      keys = Array("request_id","top3_status","top3_info","err_status","err_info","route_count","route_index","routeid","x1","y1","x2","y2","distance","duration","toll_distance","tolls","src","trafficlight_count","routeid_out","is_same","is_match","flen","tlen","highspeed_distance","polyline","linknum","rc_distance","links","rdynsdlen","rdynsdcnt","navi_id","task_id","navi_starttime","navi_endtime","ret","offtime_ratio","navi_distance","tracks1","tracks2","similarity1","similarity5")
//    }
//    else if("gd_route_eta".equalsIgnoreCase(logType)){
//      getRddF = getGdRouteEtaRdd
//      computeRddF = null
//      table = "gis_navi_gd_route_eta"
//      structs = Array("task_id","navi_id","navi_starttime","routeid","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","opt","routeid_in","fixed_route","fencedist","status","driver_type","polyline","service_id","line_code","navi_type","navi_endtime","request_id","gd_navi_order")
//      keys = Array("task_id","navi_id","navi_starttime","routeid","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","opt","routeid_in","fixed_route","fencedist","status","driver_type","polyline","service_id","line_code","navi_type","navi_endtime","request_id","gd_navi_order")
//    }
//
//    logger.error("开始处理" + date)
//    parseSaveLog(spark,getRddF,computeRddF,table,structs,keys,saveHiveRddF,runType,date,auto)
//
//
//    if("monitor".equalsIgnoreCase(logType)){
//      getRddF = getGdRouteEtaRdd
//      computeRddF = null
//      table = "gis_navi_gd_route_eta"
//      structs = Array("task_id","navi_id","navi_starttime","routeid","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","opt","routeid_in","fixed_route","fencedist","status","driver_type","polyline","service_id","line_code","navi_type","navi_endtime","request_id","gd_navi_order")
//      keys = Array("task_id","navi_id","navi_starttime","routeid","req_time","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","x1","y1","x2","y2","vehicle","vehicle_type","weight","mload","length","width","height","axle_weight","axle_number","plate_color","energy","emit_stand","passport","driver_id","ft_url","plan_date","opt","routeid_in","fixed_route","fencedist","status","driver_type","polyline","service_id","line_code","navi_type","navi_endtime","request_id","gd_navi_order")
//
//      logger.error("开始处理" + date)
//      parseSaveLog(spark,getRddF,computeRddF,table,structs,keys,saveHiveRddF,runType,date,auto)
//    }
//  }
//
//
//
//  /**
//    * 解析日志主流程
//    * @param spark
//    * @param getRddF
//    * @param computeRddF
//    * @param table
//    * @param structs
//    * @param keys
//    * @param saveHiveRddF
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def parseSaveLog(spark:SparkSession, getRddF:(SparkSession,String,String,String) => (RDD[JSONObject],ArrayBuffer[String]), computeRddF:(RDD[JSONObject]) => RDD[JSONObject], table: String, structs:Array[String], keys:Array[String], saveHiveRddF:(SparkSession,RDD[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit, runType:String, date:String, auto:String): Unit ={
//    val (etaComputeRdd,dateList) = getRddF(spark,runType,date,auto)
//    if(etaComputeRdd!=null){
//      if(computeRddF!=null){
//        val resultRdd = computeRddF(etaComputeRdd)
//        etaComputeRdd.unpersist()
//        saveHiveRddF(spark,resultRdd.repartition(repartition),table,structs,keys,dateList)
//        resultRdd.unpersist()
//      }
//      else{
//        saveHiveRddF(spark,etaComputeRdd.repartition(repartition),table,structs,keys,dateList)
//        etaComputeRdd.unpersist()
//      }
//    }
//  }
//
//
//
//  /**
//    * 获取结束监控数据
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getFinishMonitorRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的结束监控数据")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-2)
//      val endDate = runDate
//      sql=
////        s"""
////           |select a.task_id,a.navi_id,a.req_time,a.endx,a.endy,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,b.navi_logtype,b.navi_endtype,b.navi_endtime,b.navi_endx,b.navi_endy,b.cc,c.navi_starttime,c.type,b.inc_day,b.inc_day as inc_date,d.navi_endtime2,e.navi_starttime2 from
////           |(select task_id,navi_id,req_time,endx,endy,vehicle,vehicle_type,weight,mload,length,axle_number from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') a
////           |left join (select task_id,navi_id,type as navi_logtype,end_type as navi_endtype,report_time as navi_endtime,endx as navi_endx,endy as navi_endy,cc,inc_day from dm_gis.gis_navi_sdk_navi_parse where type='3' and inc_day between '$startDate' and '$endDate') b on a.task_id=b.task_id and a.navi_id=b.navi_id
////           |left join (select task_id,navi_id,report_time as navi_starttime,type from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day between '$startDate' and '$endDate') c on a.task_id=c.task_id and a.navi_id=c.navi_id
////           |left join (select task_id,navi_id,report_time as navi_endtime2 from dm_gis.gis_navi_sdk_navi_parse where type='10' and inc_day between '$startDate' and '$endDate') d on a.task_id=d.task_id and a.navi_id=d.navi_id
////           |left join (select task_id,navi_id,report_time as navi_starttime2 from dm_gis.gis_navi_sdk_navi_parse where type='9' and inc_day between '$startDate' and '$endDate') e on a.task_id=e.task_id and a.navi_id=e.navi_id
////       """.stripMargin
//        s"""
//           |select a.task_id,a.navi_id,a.req_time,a.endx,a.endy,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,b.navi_logtype,b.navi_endtype,b.navi_endtime,b.navi_endx,b.navi_endy,b.cc,c.navi_starttime,c.type,a.inc_day,a.inc_day as inc_date,d.navi_endtime2,e.navi_starttime2 from
//           |(select task_id,navi_id,req_time,endx,endy,vehicle,vehicle_type,weight,mload,length,axle_number,inc_day from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') a
//           |left join (select task_id,navi_id,type as navi_logtype,end_type as navi_endtype,report_time as navi_endtime,endx as navi_endx,endy as navi_endy,cc from dm_gis.gis_navi_sdk_navi_parse where type='3' and inc_day between '$startDate' and '$endDate') b on a.task_id=b.task_id and a.navi_id=b.navi_id
//           |left join (select task_id,navi_id,report_time as navi_starttime,type from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day between '$startDate' and '$endDate') c on a.task_id=c.task_id and a.navi_id=c.navi_id
//           |left join (select task_id,navi_id,report_time as navi_endtime2 from dm_gis.gis_navi_sdk_navi_parse where type='10' and inc_day between '$startDate' and '$endDate') d on a.task_id=d.task_id and a.navi_id=d.navi_id
//           |left join (select task_id,navi_id,report_time as navi_starttime2 from dm_gis.gis_navi_sdk_navi_parse where type='9' and inc_day between '$startDate' and '$endDate') e on a.task_id=e.task_id and a.navi_id=e.navi_id
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-2)
//      val endDate = runDate
//      sql=
////        s"""
////           |select a.task_id,a.navi_id,a.req_time,a.endx,a.endy,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,b.navi_logtype,b.navi_endtype,b.navi_endtime,b.navi_endx,b.navi_endy,b.cc,c.navi_starttime,c.type,b.inc_day,b.inc_day as inc_date,'1' as end,a.end2,d.navi_endtime2,e.navi_starttime2 from
////           |(select task_id,navi_id,req_time,endx,endy,vehicle,vehicle_type,weight,mload,length,axle_number,case when inc_day='$startDate' then '1' else '0' end end2 from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') a
////           |left join (select task_id,navi_id,type as navi_logtype,end_type as navi_endtype,report_time as navi_endtime,endx as navi_endx,endy as navi_endy,cc,inc_day from dm_gis.gis_navi_sdk_navi_parse where type='3' and inc_day between '$startDate' and '$endDate') b on a.task_id=b.task_id and a.navi_id=b.navi_id
////           |left join (select task_id,navi_id,report_time as navi_starttime,type from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day between '$startDate' and '$endDate') c on a.task_id=c.task_id and a.navi_id=c.navi_id
////           |left join (select task_id,navi_id,report_time as navi_endtime2 from dm_gis.gis_navi_sdk_navi_parse where type='10' and inc_day between '$startDate' and '$endDate') d on a.task_id=d.task_id and a.navi_id=d.navi_id
////           |left join (select task_id,navi_id,report_time as navi_starttime2 from dm_gis.gis_navi_sdk_navi_parse where type='9' and inc_day between '$startDate' and '$endDate') e on a.task_id=e.task_id and a.navi_id=e.navi_id
////       """.stripMargin
//      s"""
//         |select a.task_id,a.navi_id,a.req_time,a.endx,a.endy,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,b.navi_logtype,b.navi_endtype,b.navi_endtime,b.navi_endx,b.navi_endy,b.cc,c.navi_starttime,c.type,a.inc_day,a.inc_day as inc_date,'1' as end,a.end2,d.navi_endtime2,e.navi_starttime2 from
//         |(select task_id,navi_id,req_time,endx,endy,vehicle,vehicle_type,weight,mload,length,axle_number,inc_day,case when inc_day='$startDate' then '1' else '0' end end2 from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') a
//         |left join (select task_id,navi_id,type as navi_logtype,end_type as navi_endtype,report_time as navi_endtime,endx as navi_endx,endy as navi_endy,cc from dm_gis.gis_navi_sdk_navi_parse where type='3' and inc_day between '$startDate' and '$endDate') b on a.task_id=b.task_id and a.navi_id=b.navi_id
//         |left join (select task_id,navi_id,report_time as navi_starttime,type from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day between '$startDate' and '$endDate') c on a.task_id=c.task_id and a.navi_id=c.navi_id
//         |left join (select task_id,navi_id,report_time as navi_endtime2 from dm_gis.gis_navi_sdk_navi_parse where type='10' and inc_day between '$startDate' and '$endDate') d on a.task_id=d.task_id and a.navi_id=d.navi_id
//         |left join (select task_id,navi_id,report_time as navi_starttime2 from dm_gis.gis_navi_sdk_navi_parse where type='9' and inc_day between '$startDate' and '$endDate') e on a.task_id=e.task_id and a.navi_id=e.navi_id
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//    val computeRdd = resultRdd.map(json=>{
//      if(json!=null){
////        try{
//
//        if(StringUtils.isEmpty(json.getString("navi_starttime"))){
//          val navi_starttime2 = json.getString("navi_starttime2")
//          if(!StringUtils.isEmpty(navi_starttime2)) {
//            json.put("navi_starttime", navi_starttime2)
//          }
//          else{
//            val req_time = json.getString("req_time")
//            if(!StringUtils.isEmpty(req_time) && !"0".equalsIgnoreCase(req_time)) json.put("navi_starttime",req_time)
//            else json.put("navi_starttime","-1")
//          }
//        }
//
//        var flag = false
//        if(StringUtils.isEmpty(json.getString("navi_endtime"))){
//          val navi_endtime2 = json.getString("navi_endtime2")
//          if(!StringUtils.isEmpty(navi_endtime2)) {
//            json.put("navi_endtime", navi_endtime2)
//            flag = true
//          }
//        }
//
//        if("1".equalsIgnoreCase(json.getString("type"))) json.put("starttime_type","1")
//        else json.put("starttime_type","0")
//
//        val end = json.getString("end")
//        val end2 = json.getString("end2")
//        val cc = json.getString("cc")
//        var navi_endx = json.getDouble("navi_endx")
//        var navi_endy = json.getDouble("navi_endy")
//        if(!StringUtils.isEmpty(cc) && !"1".equalsIgnoreCase(cc) && navi_endx!=null && navi_endy!=null){
//          var xy:Array[String] = null
//          if("2".equalsIgnoreCase(cc)){
//            xy = MapApiUtil.bd2gd(navi_endx, navi_endy)
//          }
//          else if("3".equalsIgnoreCase(cc)){
//            xy = MapApiUtil.wgs2gd(navi_endx, navi_endy)
//          }
//          if(xy!=null && xy.nonEmpty){
//            json.put("navi_endx", xy(0))
//            if(xy.length > 1){
//              json.put("navi_endy", xy(1))
//            }
//          }
//        }
//
//        var distance:java.lang.Double = null
//        var status = ""
//        val endx = json.getDouble("endx")
//        val endy = json.getDouble("endy")
//        navi_endx = json.getDouble("navi_endx")
//        navi_endy = json.getDouble("navi_endy")
//        if(endx!=null && endy!=null && navi_endx!=null && navi_endy!=null && endx!=0 && endy!=0 && navi_endx!=0 && navi_endy!=0){
//          distance = MapApiUtil.getGreatCircleDistance(endx,endy,navi_endx,navi_endy)
//        }
//
//        val navi_endtype = json.getString("navi_endtype")
//        if("1".equalsIgnoreCase(navi_endtype)){
//          if(distance!=null && distance < 1000) status = "1"
//          else status= "10"
//        }
//        else if("2".equalsIgnoreCase(navi_endtype)){
//          status = "2"
//        }
//        else if("3".equalsIgnoreCase(navi_endtype)){
//          if(distance!=null && distance < 1000) status = "3"
//          else status= "11"
//        }
//        else{
//          if("1".equalsIgnoreCase(end)){
//            if("1".equalsIgnoreCase(end2)){
//              json.put("navi_endtime", dateToTimeStamp(runDate))
//              json.put("inc_date", runDate)
//              status = "12"
//            }
//          }
//          else{
//            json.put("navi_endtime", dateToTimeStamp(runDate))
//            json.put("inc_date", runDate)
//            status = "0"
//          }
//        }
//
//        if(StringUtils.isEmpty(json.getString("navi_starttime")) && "1".equalsIgnoreCase(end)){
//          status = "13"
//        }
//
//
//        if(endx!=null && endy!=null && navi_endx!=null && navi_endy!=null && (endx==0 || endy==0 || navi_endx==0 || navi_endy==0)){
//          status= "14"
//        }
//
//        if(flag){
//          status = "1"
//        }
//
//        json.put("distance", distance)
//        json.put("status", status)
////        }
////        catch {
////          case e:Exception =>logger.error(">>>日志转json失败："+e)
////        }
//      }
//      json
//    })
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取纠偏结果数据
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getRectifyRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//
//    if("true".equalsIgnoreCase(auto)){
//      runDate = date
//    }
//    else{
//      runDate = date
//    }
//    val startDate = DateUtil.getDateStr(runDate,-1)
//    dateList = DateUtil.getTwoDatesStr(startDate, runDate)
//    dateList += runDate
//
////    if("1".equalsIgnoreCase(runType)){
////      if("true".equalsIgnoreCase(auto)){
////        runDate = date
////      }
////      else{
////        runDate = date
////      }
////      val startDate = DateUtil.getDateStr(runDate,-2)
////      dateList = DateUtil.getTwoDatesStr(startDate, runDate)
////      dateList += runDate
////    }
////    else if("3".equalsIgnoreCase(runType)){
////      if("true".equalsIgnoreCase(auto)){
////        runDate = DateUtil.getDateStr(date,-3)
////      }
////      else{
////        runDate = date
////      }
////      dateList += runDate
////    }
//
//    logger.error(">>>获取"+runDate+"号的纠偏结果数据")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-1)
//      val endDate = runDate
//      sql=
//        s"""
//           |select a.navi_id,a.navi_starttime,a.starttime_type,a.navi_endtime,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,b.tm,b.x,b.y,b.tp,b.ac,b.sp,b.be,a.inc_day,a.inc_day as inc_date from
//           |(select navi_id,navi_starttime,starttime_type,navi_endtime,vehicle,vehicle_type,weight,mload,length,axle_number,inc_day from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate' and status in ('1','2','3','10','13','14') and navi_starttime is not null and navi_starttime<>'' and navi_endtime is not null and navi_endtime<>'') a
//           |left join (select carno as vehicle,tm,x,y,tp,ac,sp,be from dm_gis.gis_navi_navi_sdk_history_track where inc_day between '$startDate' and '$endDate' and tm is not null and tm<>'') b on a.vehicle=b.vehicle where b.tm>=a.navi_starttime and b.tm<=a.navi_endtime
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-1)
//      val endDate = runDate
//      sql=
//        s"""
//           |select a.navi_id,a.navi_starttime,a.starttime_type,a.navi_endtime,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,b.tm,b.x,b.y,b.tp,b.ac,b.sp,b.be,a.inc_day,a.inc_day as inc_date from
//           |(select navi_id,navi_starttime,starttime_type,navi_endtime,vehicle,vehicle_type,weight,mload,length,axle_number,inc_day from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate' and status in ('1','2','3','10','13','14') and navi_starttime is not null and navi_starttime<>'' and navi_endtime is not null and navi_endtime<>'') a
//           |left join (select carno as vehicle,tm,x,y,tp,ac,sp,be from dm_gis.gis_navi_navi_sdk_history_track where inc_day between '$startDate' and '$endDate' and tm is not null and tm<>'') b on a.vehicle=b.vehicle where b.tm>=a.navi_starttime and b.tm<=a.navi_endtime
//       """.stripMargin
////      val startDate = runDate
////      val endDate = DateUtil.getDateStr(runDate,1)
////      sql=
////        s"""
////           |select a.navi_id,a.navi_starttime,a.navi_endtime,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,b.tm,b.x,b.y,b.tp,b.ac,b.sp,b.be,a.inc_day,a.inc_day as inc_date from
////           |(select navi_id,navi_starttime,navi_endtime,vehicle,vehicle_type,weight,mload,length,axle_number,inc_day from dm_gis.gis_navi_finish_monitor where inc_day='$runDate' and status in ('1','2','3','10','13','14') and navi_starttime is not null and navi_starttime<>'' and navi_endtime is not null and navi_endtime<>'') a
////           |left join (select carno as vehicle,tm,x,y,tp,ac,sp,be from dm_gis.gis_navi_navi_sdk_history_track where inc_day between '$startDate' and '$endDate' and tm is not null and tm<>'') b on a.vehicle=b.vehicle where b.tm>=a.navi_starttime and b.tm<=a.navi_endtime
////       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
////    val computeRdd = null
////    resultRdd
////      .map(json=>{
////        var navi_id = ""
////        var tm:java.lang.Long = null
////        if(json!=null){
////          try{
////            navi_id = json.getString("navi_id")
////            tm = json.getLong("tm")
////          }
////          catch {
////            case e:Exception =>logger.error(">>>日志转json失败："+e)
////          }
////        }
////
////        if(tm==null) tm = Long.MaxValue
////
////        (navi_id,(tm,json))
////      })
////      .groupByKey().collect()
////      .map(obj=>{
////        val list = new ArrayBuffer[JSONObject]()
////        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
////        val tracks1 = new JSONArray()
////        val tracks1_new = new JSONArray()
////        val tracks2_new = new JSONArray()
////        val stayList = new JSONArray()
////        var offTimeRatio = ""
////        var len = ""
////        for(i <- jsonList.indices){
////          val json = jsonList(i)
////          val newJson1 = new JSONObject()
////          val newJson2 = new JSONObject()
////          if(json!=null){
////            val tp = json.getInteger("tp")
////            val x = json.getDouble("x")
////            val y = json.getDouble("y")
////            val ac = json.getInteger("ac")
////            val sp = json.getDouble("sp")
////            val be = json.getDouble("be")
////            val tm = json.getInteger("tm")
////
////            if(tp!=null) newJson1.put("type",tp)
////            if(x!=null) newJson1.put("x",x)
////            if(y!=null) newJson1.put("y",y)
////            if(ac!=null) newJson1.put("accuracy",ac)
////            if(sp!=null) newJson1.put("speed",sp)
////            if(be!=null) newJson1.put("azimuth",be)
////            if(tm!=null) newJson1.put("time",tm)
////
////            if(x!=null) newJson2.put("x",x)
////            if(y!=null) newJson2.put("y",y)
////            if(tm!=null) newJson2.put("tm",tm)
////          }
////
////          newJson1.put("index",i)
////          tracks1.add(newJson1)
////          tracks1_new.add(newJson2)
////        }
////
////        val json = jsonList.head
////        val result = accessRectifyUrl(json,tracks1)
////        if(result!=null){
////          val status = result.getInteger("status")
////          //          if(status!=null && status==0){
////          val resultObject = result.getJSONObject("result")
////          if(resultObject!=null){
////            val tracks2 = resultObject.getJSONArray("tracks")
////            val stay_points = resultObject.getJSONArray("stay_points")
////            offTimeRatio = resultObject.getString("offTimeRatio")
////            len = resultObject.getString("len")
////            if(tracks2!=null && tracks2.size()>0){
////              for(i<-0.until(tracks2.size())){
////                val track = tracks2.getJSONObject(i)
////                if(track!=null){
////                  val newJson = new JSONObject()
////                  val x = track.getString("x")
////                  val y = track.getString("y")
////                  val tm = track.getString("time")
////                  val sum_dist = track.getString("sum_dist")
////
////                  newJson.put("x",x)
////                  newJson.put("y",y)
////                  newJson.put("tm",tm)
////                  newJson.put("sum_dist",sum_dist)
////                  tracks2_new.add(newJson)
////                }
////              }
////            }
////            if(stay_points!=null && tracks2!=null){
////              if(stay_points.size()>0){
////                for(i<-0.until(stay_points.size())){
////                  val stay_point = stay_points.getJSONObject(i)
////                  if(stay_point!=null){
////                    val start_index = stay_point.getInteger("start_index")
////                    val end_index = stay_point.getInteger("end_index")
////                    val pois = stay_point.getJSONArray("pois")
////
////                    val duration = stay_point.getString("duration")
////                    var stayStartTime = ""
////                    var stayStartLongitude = ""
////                    var stayStartLatitude = ""
////                    var stayEndTime = ""
////                    var stayEndLongitude = ""
////                    var stayEndLatitude = ""
////                    var stayType = ""
////
////                    if(start_index!=null && start_index < tracks2.size()){
////                      val track = tracks2.getJSONObject(start_index)
////                      if(track!=null){
////                        stayStartTime = track.getString("time")
////                        stayStartLongitude = track.getString("x")
////                        stayStartLatitude = track.getString("y")
////                      }
////                    }
////
////                    if(end_index!=null && end_index < tracks2.size()){
////                      val track = tracks2.getJSONObject(end_index)
////                      if(track!=null){
////                        stayEndTime = track.getString("time")
////                        stayEndLongitude = track.getString("x")
////                        stayEndLatitude = track.getString("y")
////                      }
////                    }
////
////                    if(pois!=null && pois.size()>0){
////                      val all_poi_types = new ArrayBuffer[String]()
////                      breakable(
////                        for(j<-0.until(pois.size())){
////                          val poi = pois.getJSONObject(j)
////                          if(poi!=null){
////                            val _type = poi.getString("type")
////                            if("1".equalsIgnoreCase(_type) || "5".equalsIgnoreCase(_type)){
////                              stayType = "3"
////                              break
////                            }
////                            if(!StringUtils.isEmpty(_type)) all_poi_types += _type
////                          }
////                        }
////                      )
////                      if(StringUtils.isEmpty(stayType)){
////                        val all_types = all_poi_types.toSet
////                        if(all_types.contains("3")) stayType = "1"
////                        else if(all_types.contains("2")) stayType = "2"
////                        else stayType = "4"
////                      }
////                    }
////
////                    val newJson = new JSONObject()
////                    newJson.put("duration", duration)
////                    newJson.put("stayStartTime", stayStartTime)
////                    newJson.put("stayStartLongitude", stayStartLongitude)
////                    newJson.put("stayStartLatitude", stayStartLatitude)
////                    newJson.put("stayEndTime", stayEndTime)
////                    newJson.put("stayEndLongitude", stayEndLongitude)
////                    newJson.put("stayEndLatitude", stayEndLatitude)
////                    newJson.put("stayType", stayType)
////
////                    stayList.add(newJson)
////
////                  }
////                }
////              }
////            }
////          }
////          //          }
////        }
////
////        if(tracks1_new.size()>0) json.put("tracks1", tracks1_new)
////        if(tracks2_new.size()>0) json.put("tracks2", tracks2_new)
////        json.put("offtime_ratio", offTimeRatio)
////        if(stayList.size()>0) json.put("stay_list", stayList)
////        json.put("len", len)
////
////        json
////      })
//
//    val computeRdd = resultRdd
//      .map(json=>{
//        var navi_id = ""
//        var tm:java.lang.Long = null
//        if(json!=null){
//          try{
//            navi_id = json.getString("navi_id")
//            tm = json.getLong("tm")
//          }
//          catch {
//            case e:Exception =>logger.error(">>>日志转json失败："+e)
//          }
//        }
//
//        if(tm==null) tm = Long.MaxValue
//
//        (navi_id,(tm,json))
//      })
//      .groupByKey()
//      .map(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
//        val tracks1 = new JSONArray()
//        val tracks1_new = new JSONArray()
//        var tracks2_new = new ArrayBuffer[JSONObject]()
//        val stayList = new JSONArray()
//        var offTimeRatio = ""
//        var len = ""
//        var ret = ""
//        for(i <- jsonList.indices){
//          val json = jsonList(i)
//          val newJson1 = new JSONObject()
//          val newJson2 = new JSONObject()
//          if(json!=null){
//            val tp = json.getInteger("tp")
//            val x = json.getDouble("x")
//            val y = json.getDouble("y")
//            val ac = json.getInteger("ac")
//            val sp = json.getDouble("sp")
//            val be = json.getDouble("be")
//            val tm = json.getInteger("tm")
//
//            if(tp!=null) newJson1.put("type",tp)
//            if(x!=null) newJson1.put("x",x)
//            if(y!=null) newJson1.put("y",y)
//            if(ac!=null) newJson1.put("accuracy",ac)
//            if(sp!=null) newJson1.put("speed",sp)
//            if(be!=null) newJson1.put("azimuth",be)
//            if(tm!=null) newJson1.put("time",tm)
//
//            if(x!=null) newJson2.put("x",x)
//            if(y!=null) newJson2.put("y",y)
//            if(tm!=null) newJson2.put("tm",tm)
//          }
//
//          newJson1.put("index",i)
//          tracks1.add(newJson1)
//          tracks1_new.add(newJson2)
//        }
//
//        val json = jsonList.head
//        val result = accessRectifyUrl(json,tracks1)
//        if(result!=null){
//          val status = result.getInteger("status")
////          if(status!=null && status==0){
//            val resultObject = result.getJSONObject("result")
//            if(resultObject!=null){
//              val tracks2 = resultObject.getJSONArray("tracks")
//              val stay_points = resultObject.getJSONArray("stay_points")
//              offTimeRatio = resultObject.getString("offTimeRatio")
//              len = resultObject.getString("len")
//              ret = resultObject.getString("ret")
//              if(tracks2!=null && tracks2.size()>0){
//                for(i<-0.until(tracks2.size())){
//                  val track = tracks2.getJSONObject(i)
//                  if(track!=null){
//                    val newJson = new JSONObject()
//                    val x = track.getString("x")
//                    val y = track.getString("y")
//                    val tm = track.getString("time")
//                    val sum_dist = track.getString("sum_dist")
//                    val swid = track.getString("SWID")
//
//                    newJson.put("x",x)
//                    newJson.put("y",y)
//                    newJson.put("tm",tm)
//                    newJson.put("sum_dist",sum_dist)
//                    newJson.put("swid",swid)
//                    tracks2_new += newJson
//                  }
//                }
//              }
//              if(stay_points!=null && tracks2!=null){
//                if(stay_points.size()>0){
//                  for(i<-0.until(stay_points.size())){
//                    val stay_point = stay_points.getJSONObject(i)
//                    if(stay_point!=null){
//                      val start_index = stay_point.getInteger("start_index")
//                      val end_index = stay_point.getInteger("end_index")
//                      val pois = stay_point.getJSONArray("pois")
//
//                      val duration = stay_point.getString("duration")
//                      var stayStartTime = ""
//                      var stayStartLongitude = ""
//                      var stayStartLatitude = ""
//                      var stayEndTime = ""
//                      var stayEndLongitude = ""
//                      var stayEndLatitude = ""
//                      var stayType = ""
//
//                      if(start_index!=null && start_index < tracks2.size()){
//                        val track = tracks2.getJSONObject(start_index)
//                        if(track!=null){
//                          stayStartTime = track.getString("time")
//                          stayStartLongitude = track.getString("x")
//                          stayStartLatitude = track.getString("y")
//                        }
//                      }
//
//                      if(end_index!=null && end_index < tracks2.size()){
//                        val track = tracks2.getJSONObject(end_index)
//                        if(track!=null){
//                          stayEndTime = track.getString("time")
//                          stayEndLongitude = track.getString("x")
//                          stayEndLatitude = track.getString("y")
//                        }
//                      }
//
//                      if(pois!=null && pois.size()>0){
//                        val all_poi_types = new ArrayBuffer[String]()
//                        breakable(
//                          for(j<-0.until(pois.size())){
//                            val poi = pois.getJSONObject(j)
//                            if(poi!=null){
//                              val _type = poi.getString("type")
//                              if("1".equalsIgnoreCase(_type) || "5".equalsIgnoreCase(_type)){
//                                stayType = "3"
//                                break
//                              }
//                              if(!StringUtils.isEmpty(_type)) all_poi_types += _type
//                            }
//                          }
//                        )
//                        if(StringUtils.isEmpty(stayType)){
//                          val all_types = all_poi_types.toSet
//                          if(all_types.contains("3")) stayType = "1"
//                          else if(all_types.contains("2")) stayType = "2"
//                          else stayType = "4"
//                        }
//                      }
//
//                      val newJson = new JSONObject()
//                      newJson.put("duration", duration)
//                      newJson.put("stayStartTime", stayStartTime)
//                      newJson.put("stayStartLongitude", stayStartLongitude)
//                      newJson.put("stayStartLatitude", stayStartLatitude)
//                      newJson.put("stayEndTime", stayEndTime)
//                      newJson.put("stayEndLongitude", stayEndLongitude)
//                      newJson.put("stayEndLatitude", stayEndLatitude)
//                      newJson.put("stayType", stayType)
//
//                      stayList.add(newJson)
//
//                    }
//                  }
//                }
//              }
//            }
////          }
//        }
//
//        if(tracks1_new.size()>0) json.put("tracks1", tracks1_new)
//        if(tracks2_new.nonEmpty) {
//          val tracks2_new2 = new JSONArray()
//          val temp = tracks2_new.sortBy(j => j.getLong("tm"))
//          temp.toList.foreach(j => {
//            tracks2_new2.add(j)
//          })
//          json.put("tracks2", tracks2_new2)
//        }
//        json.put("offtime_ratio", offTimeRatio)
//        if(stayList.size()>0) json.put("stay_list", stayList)
//        json.put("len", len)
//        json.put("ret", ret)
//
//        json
//      })
//      .persist()
//
//    logger.error(">>>计算后日志量：" + computeRdd.count())
//
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取Top3点选线路的ETA结果
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getTop3ClickRouteRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的Top3点选线路的ETA结果")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.request_id,a.req_time,a.src_deptcode,a.dest_deptcode,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.status,a.ak,a.start_speed,a.vehicle_dir1,a.starts,a.driver_type,a.service_id,a.line_code,a.navi_starttime,a.type,a.routeid,a.navi_type,a.routeid2,a.inc_day2,a.gd_polyline,b.route_index,b.pns_status,b.distance,b.duration,b.toll_distance,b.tolls,b.src,b.trafficlight_count,b.highspeed_distance,b.flen,b.tlen,b.routeid_out,b.polyline,b.linknum,b.rc_distance,b.links,b.rdynsdlen,b.rdynsdcnt,b.rect_result,b.strategy2,b.routetype,b.merge_result,b.is_econ,c.src_citycode,c.src_province,d.dest_citycode,d.dest_province,a.inc_day,a.inc_day as inc_date from
//           |(
//           |select t1.task_id,t1.navi_id,t1.request_id,t1.req_time,t1.src_deptcode,t1.dest_deptcode,t1.x1,t1.y1,t1.x2,t1.y2,t1.vehicle,t1.vehicle_type,t1.weight,t1.mload,t1.length,t1.width,t1.height,t1.axle_weight,t1.axle_number,t1.plate_color,t1.energy,t1.emit_stand,t1.passport,t1.driver_id,t1.ft_url,t1.plan_date,t1.stype,t1.path_count,t1.opt,t1.strategy,t1.merge,t1.routeid_in,t1.fixed_route,t1.fencedist,t1.status,t1.ak,t1.start_speed,t1.vehicle_dir1,t1.starts,t1.driver_type,t1.service_id,t1.line_code,t2.inc_day,t2.navi_starttime,t2.type,t2.routeid,t2.navi_type,t3.routeid2,t3.inc_day2,t4.gd_polyline from
//           |	(select task_id,navi_id,request_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'3' as path_count,opt,'' as strategy,merge,routeid_in,fixed_route,fencedist,status,ak,start_speed,vehicle_dir1,tracks as starts,driver_type,service_id,line_code from dm_gis.gis_navi_top3_parse where inc_day='$runDate') t1
//           |	left join (select navi_id,max(report_time) as navi_starttime,max(type) as type,max(routeid) as routeid,max(navi_type) as navi_type,max(inc_day) as inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='1' group by navi_id) t2 on t1.navi_id=t2.navi_id
//           |	left join (select navi_id,max(routeid) as routeid2,max(inc_day) as inc_day2 from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='9' group by navi_id) t3 on t1.navi_id=t3.navi_id
//           |	left join (select navi_id,max(gd_content) as gd_polyline from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='8' group by navi_id) t4 on t1.navi_id=t4.navi_id
//           |) a
//           |left join (select request_id,routeid,route_index,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ from dm_gis.gis_navi_top3_yaw_result_parse where inc_day='$runDate') b on a.request_id=b.request_id and a.routeid=b.routeid
//           |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909') c on a.src_deptcode=c.zone_code
//           |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909') d on a.dest_deptcode=d.zone_code
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-1)
//      val endDate = runDate
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.request_id,a.req_time,a.src_deptcode,a.dest_deptcode,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.status,a.ak,a.start_speed,a.vehicle_dir1,a.starts,a.driver_type,a.service_id,a.line_code,a.navi_starttime,a.type,a.routeid,a.navi_type,a.routeid2,a.inc_day2,a.gd_polyline,b.route_index,b.pns_status,b.distance,b.duration,b.toll_distance,b.tolls,b.src,b.trafficlight_count,b.highspeed_distance,b.flen,b.tlen,b.routeid_out,b.polyline,b.linknum,b.rc_distance,b.links,b.rdynsdlen,b.rdynsdcnt,b.rect_result,b.strategy2,b.routetype,b.merge_result,b.is_econ,c.src_citycode,c.src_province,d.dest_citycode,d.dest_province,a.inc_day,a.inc_day as inc_date from
//           |(
//           |select t1.task_id,t1.navi_id,t1.request_id,t1.req_time,t1.src_deptcode,t1.dest_deptcode,t1.x1,t1.y1,t1.x2,t1.y2,t1.vehicle,t1.vehicle_type,t1.weight,t1.mload,t1.length,t1.width,t1.height,t1.axle_weight,t1.axle_number,t1.plate_color,t1.energy,t1.emit_stand,t1.passport,t1.driver_id,t1.ft_url,t1.plan_date,t1.stype,t1.path_count,t1.opt,t1.strategy,t1.merge,t1.routeid_in,t1.fixed_route,t1.fencedist,t1.status,t1.ak,t1.start_speed,t1.vehicle_dir1,t1.starts,t1.driver_type,t1.service_id,t1.line_code,t2.inc_day,t2.navi_starttime,t2.type,t2.routeid,t2.navi_type,t3.routeid2,t3.inc_day2,t4.gd_polyline from
//           |	(select task_id,navi_id,request_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'3' as path_count,opt,'' as strategy,merge,routeid_in,fixed_route,fencedist,status,ak,start_speed,vehicle_dir1,tracks as starts,driver_type,service_id,line_code from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') t1
//           |	left join (select navi_id,max(report_time) as navi_starttime,max(type) as type,max(routeid) as routeid,max(navi_type) as navi_type,max(inc_day) as inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='1' group by navi_id) t2 on t1.navi_id=t2.navi_id
//           |	left join (select navi_id,max(routeid) as routeid2,max(inc_day) as inc_day2 from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='9' group by navi_id) t3 on t1.navi_id=t3.navi_id
//           |	left join (select navi_id,max(gd_content) as gd_polyline from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='8' group by navi_id) t4 on t1.navi_id=t4.navi_id
//           |) a
//           |left join (select request_id,routeid,route_index,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate') b on a.request_id=b.request_id and a.routeid=b.routeid
//           |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909') c on a.src_deptcode=c.zone_code
//           |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909') d on a.dest_deptcode=d.zone_code
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//    val computeRdd = resultRdd.map(json=>{
//      if(json!=null){
//        if(StringUtils.isEmpty(json.getString("inc_date"))){
//          val inc_day2 = json.getString("inc_day2")
//          if(!StringUtils.isEmpty(inc_day2)){
//            json.put("inc_date",inc_day2)
//          }
//        }
//        if(StringUtils.isEmpty(json.getString("routeid"))){
//          val routeid2 = json.getString("routeid2")
//          if(!StringUtils.isEmpty(routeid2)){
//            json.put("routeid",routeid2)
//          }
//        }
//
//        var gd_polyline_new = ""
//        val gd_polyline = json.getJSONArray("gd_polyline")
//        if(gd_polyline!=null && gd_polyline.size()>0){
//          var routeid = json.getString("routeid")
//          if(StringUtils.isEmpty(routeid)) routeid = ""
//          breakable(
//            for(j<-0.until(gd_polyline.size())){
//              val track = gd_polyline.getJSONObject(j)
//              if(track!=null){
//                if(routeid.equalsIgnoreCase(track.getString("routeId"))){
//                  gd_polyline_new = track.getString("coords")
//                  gd_polyline_new = gd_polyline_new.replaceAll("latitude","y").replaceAll("longitude","x")
//                  break
//                }
//              }
//            }
//          )
//        }
//        json.put("gd_polyline", gd_polyline_new)
//
//        if(StringUtils.isEmpty(json.getString("navi_starttime"))){
//          val req_time = json.getString("req_time")
//          if(!StringUtils.isEmpty(req_time) && !"0".equalsIgnoreCase(req_time)) json.put("navi_starttime",req_time)
//          else json.put("navi_starttime","-1")
//        }
//        if("1".equalsIgnoreCase(json.getString("type"))) json.put("starttime_type","1")
//        else json.put("starttime_type","0")
//      }
//      json
//    })
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取偏航请求线路的ETA结果
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getYawRouteRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的偏航请求线路的ETA结果")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
////        s"""
////           |select a.task_id,a.navi_id,a.navi_starttime,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,b.request_id,b.req_time,b.x2,b.y2,b.ft_url,b.plan_date,b.stype,b.path_count,b.opt,b.strategy,b.merge,b.routeid_in,b.fixed_route,b.fencedist,b.reroute,b.swid,b.starts,b.status,b.ak,b.service_id,c.routeid,c.x1,c.y1,c.pns_status,c.distance,c.duration,c.toll_distance,c.tolls,c.src,c.trafficlight_count,c.highspeed_distance,c.flen,c.tlen,c.routeid_out,c.polyline,c.linknum,c.rc_distance,c.links,c.rdynsdlen,c.rdynsdcnt,c.rect_result,c.strategy2,c.routetype,c.merge_result,d.hasyaw,a.inc_day,a.inc_day as inc_date from
////           |(select task_id,navi_id,navi_starttime,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,inc_day from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' and navi_starttime is not null and navi_starttime<>'') a
////           |left join (select navi_id,request_id,req_time,endx as x2,endy as y2,ft_url,plan_date,stype,'1' as path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swids as swid,starts,status,ak,service_id from dm_gis.gis_navi_yaw_parse where inc_day='$runDate') b on a.navi_id=b.navi_id
////           |left join (select request_id,routeid,x1,y1,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ from dm_gis.gis_navi_top3_yaw_result_parse where inc_day='$runDate') c on b.request_id=c.request_id
////           |left join (select navi_id,new_routeid,max(hasyaw) as hasyaw from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='2' group by navi_id,new_routeid) d on a.navi_id=d.navi_id and c.routeid=d.new_routeid
////       """.stripMargin
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.line_code,a.navi_type,b.new_routeid,b.hasyaw,c.request_id,c.x1,c.y1,c.pns_status,c.distance,c.duration,c.toll_distance,c.tolls,c.src,c.trafficlight_count,c.highspeed_distance,c.flen,c.tlen,c.routeid_out,c.polyline,c.linknum,c.rc_distance,c.links,c.rdynsdlen,c.rdynsdcnt,c.rect_result,c.strategy2,c.routetype,c.merge_result,d.req_time,d.x2,d.y2,d.ft_url,d.plan_date,d.stype,d.path_count,d.opt,d.strategy,d.merge,d.routeid_in,d.fixed_route,d.fencedist,d.reroute,d.swid,d.starts,d.status,d.ak,d.service_id,a.inc_day,a.inc_day as inc_date from
//           |(select task_id,navi_id,navi_starttime,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,line_code,navi_type,inc_day from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' and navi_starttime is not null and navi_starttime<>'') a
//           |left join (select navi_id,new_routeid,max(hasyaw) as hasyaw from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='2' group by navi_id,new_routeid) b on a.navi_id=b.navi_id
//           |left join (select request_id,routeid,x1,y1,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ from dm_gis.gis_navi_top3_yaw_result_parse where inc_day='$runDate') c on b.new_routeid=c.routeid
//           |left join (select navi_id,request_id,req_time,endx as x2,endy as y2,ft_url,plan_date,stype,'1' as path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swids as swid,starts,status,ak,service_id from dm_gis.gis_navi_yaw_parse where inc_day='$runDate') d on c.request_id=d.request_id
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = runDate
//      val endDate = DateUtil.getDateStr(runDate,1)
//      sql=
////        s"""
////           |select a.task_id,a.navi_id,a.navi_starttime,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,b.request_id,b.req_time,b.x2,b.y2,b.ft_url,b.plan_date,b.stype,b.path_count,b.opt,b.strategy,b.merge,b.routeid_in,b.fixed_route,b.fencedist,b.reroute,b.swid,b.starts,b.status,b.ak,b.service_id,c.routeid,c.x1,c.y1,c.pns_status,c.distance,c.duration,c.toll_distance,c.tolls,c.src,c.trafficlight_count,c.highspeed_distance,c.flen,c.tlen,c.routeid_out,c.polyline,c.linknum,c.rc_distance,c.links,c.rdynsdlen,c.rdynsdcnt,c.rect_result,c.strategy2,c.routetype,c.merge_result,d.hasyaw,a.inc_day,a.inc_day as inc_date from
////           |(select task_id,navi_id,navi_starttime,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,inc_day from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' and navi_starttime is not null and navi_starttime<>'') a
////           |left join (select navi_id,request_id,req_time,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,'' as driver_id,ft_url,plan_date,stype,'1' as path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swids as swid,starts,status,ak,service_id from dm_gis.gis_navi_yaw_parse where inc_day between '$startDate' and '$endDate') b on a.navi_id=b.navi_id
////           |left join (select request_id,routeid,x1,y1,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate') c on b.request_id=c.request_id
////           |left join (select navi_id,new_routeid,max(hasyaw) as hasyaw from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type='2' group by navi_id,new_routeid) d on a.navi_id=d.navi_id and c.routeid=d.new_routeid
////       """.stripMargin
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.line_code,a.navi_type,b.new_routeid,b.hasyaw,c.request_id,c.x1,c.y1,c.pns_status,c.distance,c.duration,c.toll_distance,c.tolls,c.src,c.trafficlight_count,c.highspeed_distance,c.flen,c.tlen,c.routeid_out,c.polyline,c.linknum,c.rc_distance,c.links,c.rdynsdlen,c.rdynsdcnt,c.rect_result,c.strategy2,c.routetype,c.merge_result,d.req_time,d.x2,d.y2,d.ft_url,d.plan_date,d.stype,d.path_count,d.opt,d.strategy,d.merge,d.routeid_in,d.fixed_route,d.fencedist,d.reroute,d.swid,d.starts,d.status,d.ak,d.service_id,a.inc_day,a.inc_day as inc_date from
//           |(select task_id,navi_id,navi_starttime,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,line_code,navi_type,inc_day from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' and navi_starttime is not null and navi_starttime<>'') a
//           |left join (select navi_id,new_routeid,max(hasyaw) as hasyaw from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type='2' group by navi_id,new_routeid) b on a.navi_id=b.navi_id
//           |left join (select request_id,routeid,x1,y1,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate') c on b.new_routeid=c.routeid
//           |left join (select navi_id,request_id,req_time,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,'' as driver_id,ft_url,plan_date,stype,'1' as path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swids as swid,starts,status,ak,service_id from dm_gis.gis_navi_yaw_parse where inc_day between '$startDate' and '$endDate') d on c.request_id=d.request_id
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//    (resultRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取不偏航请求线路的ETA结果
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getNoYawRouteRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的不偏航请求线路的ETA结果")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,b.routeid,b.request_id,b.req_time,b.x1,b.y1,b.x2,b.y2,b.ft_url,b.plan_date,b.stype,b.path_count,b.opt,b.strategy,b.swid,b.status,b.ak,c.pns_status,c.distance,c.duration,c.toll_distance,c.tolls,c.trafficlight_count,c.highspeed_distance,c.flen,c.tlen,c.routeid_out,c.rc_distance,c.links,c.rdynsdlen,c.rdynsdcnt,d.polyline,d.src,a.inc_day,a.inc_day as inc_date from
//           |(select task_id,navi_id,navi_starttime,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,inc_day from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' and navi_starttime is not null and navi_starttime<>'') a
//           |left join (select navi_id,routeid,request_id,req_time,startx as x1,starty as y1,endx as x2,endy as y2,ft_url,plan_date,'' as stype,'1' as path_count,opt,strategy,swid,status,ak from dm_gis.gis_navi_no_yaw_parse where inc_day='$runDate') b on a.navi_id=b.navi_id
//           |left join (select request_id,qm_status as pns_status,distance,duration,toll_distance,tolls,trafficlight_count,highspeed_distance,ft_flen as flen,ft_tlen as tlen,'' as routeid_out,'' as rc_distance,links,rdynsdlen,rdynsdcnt from dm_gis.gis_navi_no_yaw_result_parse where inc_day='$runDate') c on b.request_id=c.request_id
//           |left join (select routeid,polyline,src from dm_gis.gis_navi_top3_yaw_result_parse where inc_day='$runDate') d on b.routeid=d.routeid
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = runDate
//      val endDate = DateUtil.getDateStr(runDate,1)
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,b.routeid,b.request_id,b.req_time,b.x1,b.y1,b.x2,b.y2,b.ft_url,b.plan_date,b.stype,b.path_count,b.opt,b.strategy,b.swid,b.status,b.ak,c.pns_status,c.distance,c.duration,c.toll_distance,c.tolls,c.trafficlight_count,c.highspeed_distance,c.flen,c.tlen,c.routeid_out,c.rc_distance,c.links,c.rdynsdlen,c.rdynsdcnt,d.polyline,d.src,a.inc_day,a.inc_day as inc_date from
//           |(select task_id,navi_id,navi_starttime,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,inc_day from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' and navi_starttime is not null and navi_starttime<>'') a
//           |left join (select navi_id,routeid,request_id,req_time,startx as x1,starty as y1,endx as x2,endy as y2,ft_url,plan_date,'' as stype,'1' as path_count,opt,strategy,swid,status,ak from dm_gis.gis_navi_no_yaw_parse where inc_day between '$startDate' and '$endDate') b on a.navi_id=b.navi_id
//           |left join (select request_id,qm_status as pns_status,distance,duration,toll_distance,tolls,trafficlight_count,highspeed_distance,ft_flen as flen,ft_tlen as tlen,'' as routeid_out,'' as rc_distance,links,rdynsdlen,rdynsdcnt from dm_gis.gis_navi_no_yaw_result_parse where inc_day between '$startDate' and '$endDate') c on b.request_id=c.request_id
//           |left join (select routeid,polyline,src from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate') d on b.routeid=d.routeid
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//    val computeRdd = resultRdd
//      .map(json=>{
//        val links = json.getString("links")
//        if(!StringUtils.isEmpty(links)) {
//          val linknum = links.split(",").length
//          json.put("linknum",linknum)
//        }
//
//        val new_polyline:JSONArray = new JSONArray()
//        val distances = new ArrayBuffer[java.lang.Double]()
//        val x1 = json.getDouble("x1")
//        val y1 = json.getDouble("y1")
//        val polyline = json.getJSONArray("polyline")
//        if(x1!=null && y1!=null && polyline!=null && polyline.size()>0){
//          for(i<-0.until(polyline.size())){
//            val el = polyline.getJSONObject(i)
//            var distance:java.lang.Double = null
//            if(el!=null){
//              val x = el.getDouble("x")
//              val y = el.getDouble("y")
//              if(x!=null && y!=null){
//                distance = (x - x1)*(x - x1) + (y - y1)*(y - y1)
//              }
//            }
//            if(distance==null) distance = Double.MaxValue
//            distances += distance
//          }
//
//          val minIndex = distances.zipWithIndex.minBy(_._1)._2
//          for(i<-minIndex.until(polyline.size())){
//            new_polyline.add(polyline.getJSONObject(i))
//          }
//          json.put("polyline",new_polyline)
//        }
//
//        json
//      })
//    resultRdd.unpersist()
//
//    (computeRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取ETA结果汇总
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getEtaResultRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
////      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
////      dateList = DateUtil.getTwoDatesStr(startDate,runDate)
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的ETA结果汇总")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.routeid,a.request_id,a.req_time,a.req_type,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.reroute,a.swid,a.starts,a.status,a.pns_status,a.distance,a.duration,a.toll_distance,a.tolls,a.src,a.trafficlight_count,a.highspeed_distance,a.flen,a.tlen,a.routeid_out,a.polyline,a.linknum,a.rc_distance,a.links,a.rdynsdlen,a.rdynsdcnt,a.start_speed,a.vehicle_dir1,a.rect_result,a.strategy2,a.routetype,a.merge_result,b.navi_endstatus,b.navi_endtime,b.navi_endx,b.navi_endy,c.stay_list,c.tracks1,c.tracks2,c.ret,c.offtime_ratio,a.inc_day,a.inc_date from
//           |(select task_id,navi_id,navi_starttime,routeid,request_id,req_time,'top3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,'' as reroute,'' as swid,starts,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,start_speed,vehicle_dir1,rect_result,strategy2,routetype,merge_result,inc_day,inc_day as inc_date from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' union all
//           |select task_id,navi_id,navi_starttime,routeid,request_id,req_time,'yaw' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swid,starts,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,'' as start_speed,'' as vehicle_dir1,rect_result,strategy2,routetype,merge_result,inc_day,inc_day as inc_date from dm_gis.gis_navi_yaw_route where inc_day='$runDate' and hasyaw='true' union all
//           |select task_id,navi_id,navi_starttime,routeid,request_id,req_time,'qmpoint' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,'' as merge,'' as routeid_in,'' as fixed_route,'' as fencedist,'' as reroute,swid,'' as starts,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,'' as start_speed,'' as vehicle_dir1,'' as rect_result,'' as strategy2,'' as routetype,'' as merge_result,inc_day,inc_day as inc_date from dm_gis.gis_navi_noyaw_route where inc_day='$runDate') a
//           |left join (select navi_id,status as navi_endstatus,navi_endtime,navi_endx,navi_endy from dm_gis.gis_navi_finish_monitor where inc_day='$runDate') b on a.navi_id=b.navi_id
//           |left join (select navi_id,stay_list,tracks1,tracks2,ret,offtime_ratio from dm_gis.gis_navi_rectify_result where inc_day='$runDate') c on a.navi_id=c.navi_id
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
//      val endDate = runDate
//      val endDate1 = DateUtil.getDateStr(runDate,1)
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.routeid,a.request_id,a.req_time,a.req_type,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.reroute,a.swid,a.starts,a.status,a.pns_status,a.distance,a.duration,a.toll_distance,a.tolls,a.src,a.trafficlight_count,a.highspeed_distance,a.flen,a.tlen,a.routeid_out,a.polyline,a.linknum,a.rc_distance,a.links,a.rdynsdlen,a.rdynsdcnt,a.start_speed,a.vehicle_dir1,a.rect_result,a.strategy2,a.routetype,a.merge_result,b.navi_endstatus,b.navi_endtime,b.navi_endx,b.navi_endy,c.stay_list,c.tracks1,c.tracks2,c.ret,c.offtime_ratio,a.inc_day,a.inc_date from
//           |(select task_id,navi_id,navi_starttime,routeid,request_id,req_time,'top3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,'' as reroute,'' as swid,starts,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,start_speed,vehicle_dir1,rect_result,strategy2,routetype,merge_result,inc_day,inc_day as inc_date from dm_gis.gis_navi_top3_click_route where inc_day between '$startDate' and '$endDate' union all
//           |select task_id,navi_id,navi_starttime,routeid,request_id,req_time,'yaw' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,swid,starts,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,'' as start_speed,'' as vehicle_dir1,rect_result,strategy2,routetype,merge_result,inc_day,inc_day as inc_date from dm_gis.gis_navi_yaw_route where inc_day between '$startDate' and '$endDate' and hasyaw='true' union all
//           |select task_id,navi_id,navi_starttime,routeid,request_id,req_time,'qmpoint' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,'' as merge,'' as routeid_in,'' as fixed_route,'' as fencedist,'' as reroute,swid,'' as starts,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,'' as start_speed,'' as vehicle_dir1,'' as rect_result,'' as strategy2,'' as routetype,'' as merge_result,inc_day,inc_day as inc_date from dm_gis.gis_navi_noyaw_route where inc_day between '$startDate' and '$endDate') a
//           |left join (select navi_id,status as navi_endstatus,navi_endtime,navi_endx,navi_endy from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate1') b on a.navi_id=b.navi_id
//           |left join (select navi_id,stay_list,tracks1,tracks2,ret,offtime_ratio from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1') c on a.navi_id=c.navi_id
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//    val computeRdd = resultRdd.repartition(64000)
//      .map(json=>{
//        val task_id = json.getString("task_id")
//        val navi_id = json.getString("navi_id")
//        val routeid = json.getString("routeid")
//        var req_time = json.getLong("req_time")
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        ((task_id,navi_id,routeid),(req_time,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
//        val req_count = jsonList.size
//        for(i <- jsonList.indices){
//          val json = jsonList(i)
//
//          var req_status = ""
//          val navi_endstatus = json.getInteger("navi_endstatus")
//          if(navi_endstatus!=null){
//            if(navi_endstatus>=10){
//              req_status = "1"
//            }
//            else if(navi_endstatus == 0) req_status = "-1"
//            else if(navi_endstatus < 10){
//              if(i < req_count - 1){
//                val nextJson = jsonList(i + 1)
//                val x1 = json.getString("x1")
//                val y1 = json.getString("y1")
//                val next_x1 = nextJson.getString("x1")
//                val next_y1 = nextJson.getString("y1")
//                if(!StringUtils.isEmpty(x1) && !StringUtils.isEmpty(y1) && x1.equalsIgnoreCase(next_x1) && y1.equalsIgnoreCase(next_y1)){
//                  req_status = "1"
//                }
//              }
//              if(!"1".equalsIgnoreCase(req_status)){
//                val req_time = json.getLong("req_time")
//                val navi_starttime = json.getLong("navi_starttime")
//                if(req_time!=null && navi_starttime!=null && req_time < navi_starttime) req_status = "1"
//                else if(!"0".equalsIgnoreCase(json.getString("status")) || !"0".equalsIgnoreCase(json.getString("pns_status"))) req_status = "1"
//                else req_status = "0"
//              }
//            }
//            json.put("req_status",req_status)
//          }
//
//          val req_time = json.getLong("req_time")
//          val navi_endtime = json.getLong("navi_endtime")
//
//          val tracks1 = json.getJSONArray("tracks1")
//          val tracks1_new = new JSONArray()
//          json.remove("tracks1")
//          if(tracks1!=null && tracks1.size()>0 && req_time!=null && navi_endtime!=null){
//            var diff_min1 = Long.MaxValue
//            var diff_min2 = Long.MaxValue
//            var index1 = -1
//            var index2 = -1
//            breakable(
//              for(j<-0.until(tracks1.size())){
//                val track = tracks1.getJSONObject(j)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(req_time - tm * 1000)
//                    if(diff < diff_min1) {
//                      diff_min1 = diff
//                      index1 = j
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            breakable(
//              for(j<-0.until(tracks1.size())){
//                val track = tracks1.getJSONObject(tracks1.size() - j - 1)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(navi_endtime - tm * 1000)
//                    if(diff < diff_min2) {
//                      diff_min2 = diff
//                      index2 = tracks1.size() - j - 1
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            if(index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks1.size()){
//              for(j<-index1.until(index2 + 1)){
//                val track = tracks1.getJSONObject(j)
//                val tmp = new JSONArray()
//                if(track!=null){
//                  val x = track.getDouble("x")
//                  val y = track.getDouble("y")
//                  if(x!=null && y!=null){
//                    tmp.add(x)
//                    tmp.add(y)
//                    tracks1_new.add(tmp)
//                  }
//                }
//              }
//            }
//            if(tracks1_new.size() > 0) json.put("tracks1", tracks1_new)
//          }
//
//          var navi_distance:java.lang.Double = null
//          val tracks2 = json.getJSONArray("tracks2")
//          val tracks2_new = new JSONArray()
//          json.remove("tracks2")
//          if(tracks2!=null && tracks2.size()>0 && req_time!=null && navi_endtime!=null){
//            var diff_min1 = Long.MaxValue
//            var diff_min2 = Long.MaxValue
//            var index1 = -1
//            var index2 = -1
//            breakable(
//              for(j<-0.until(tracks2.size())){
//                val track = tracks2.getJSONObject(j)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(req_time - tm * 1000)
//                    if(diff <= diff_min1) {
//                      diff_min1 = diff
//                      index1 = j
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            breakable(
//              for(j<-0.until(tracks2.size())){
//                val track = tracks2.getJSONObject(tracks2.size() - j - 1)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(navi_endtime - tm * 1000)
//                    if(diff <= diff_min2) {
//                      diff_min2 = diff
//                      index2 = tracks2.size() - j - 1
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            if(index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks2.size()){
//              val track1 = tracks2.getJSONObject(index1)
//              val track2 = tracks2.getJSONObject(index2)
//              if(track1!=null && track2!=null){
//                val sum_dist1 = track1.getDouble("sum_dist")
//                val sum_dist2 = track2.getDouble("sum_dist")
//                if(sum_dist1!=null && sum_dist2!=null){
//                  navi_distance = sum_dist2 - sum_dist1
//                }
//              }
//              var swid = ""
//              var links2 = new JSONArray()
//              val req_type = json.getString("req_type")
//              var type_flag = false
//              if("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)) type_flag = true
//
//              for(j<-index1.until(index2 + 1)){
//                val track = tracks2.getJSONObject(j)
//                val tmp = new JSONArray()
//                if(track!=null){
//                  val x = track.getDouble("x")
//                  val y = track.getDouble("y")
//                  if(x!=null && y!=null){
//                    tmp.add(x)
//                    tmp.add(y)
//                    tracks2_new.add(tmp)
//                  }
//                }
//
//                if(type_flag){
//                  val _swid = track.getString("swid")
//                  if(!swid.equalsIgnoreCase(_swid) && !StringUtils.isEmpty(_swid)){
//                    swid = _swid
//                    val tmpTrack = new JSONObject()
//                    tmpTrack.put("swid",swid)
//                    val tm = track.getString("tm")
//                    if(!StringUtils.isEmpty(tm)) tmpTrack.put("tm",tm + "000")
//                    links2.add(tmpTrack)
//                  }
//                }
//              }
//              if(type_flag){
//                if(links2.size() > 0){
//                  json.put("links2", links2)
//                  if(json.containsKey("links") && !StringUtils.isEmpty(json.getString("links"))){
//                    val links = json.getString("links").split(",")
//                    val size1 = links.size
//                    val size2 = links2.size()
//                    var size = 0
//                    if(size1 > size2) size = size2
//                    else size = size1
//                    breakable(
//                      for(m<-0.until(size)){
//                        val link = links(m)
//                        val link2 = links2.getJSONObject(m)
//                        if(link2!=null){
//                          val swid = link2.getString("swid")
//                          if(!StringUtils.isEmpty(link)){
//                            if(!link.equalsIgnoreCase(swid)){
//                              val tm = link2.getString("tm")
//                              json.put("t1", tm)
//                              break
//                            }
//                          }
//                          else if(!StringUtils.isEmpty(swid)){
//                            val tm = link2.getString("tm")
//                            json.put("t1", tm)
//                            break
//                          }
//                        }
//                        else if(!StringUtils.isEmpty(link)) {
//                          json.put("t1", "0")
//                          break
//                        }
//                      }
//                    )
//                  }
//                  else json.put("t1", "0")
//                }
//                else json.put("t1", "0")
//              }
//            }
//            if(tracks2_new.size() > 0) json.put("tracks2", tracks2_new)
//          }
//
//          if(navi_distance!=null) json.put("navi_distance",navi_distance)
//
//          val polyline = json.getString("polyline")
//          var polyline_array:JSONArray = null
//          if(!StringUtils.isEmpty(polyline)) polyline_array = JSON.parseArray(polyline)
//          val polyline_new = new JSONArray()
//          json.remove("polyline")
//          if(polyline_array!=null && polyline_array.size()>0){
//            for(j<-0.until(polyline_array.size())){
//              val track = polyline_array.getJSONObject(j)
//              val tmp = new JSONArray()
//              if(track!=null){
//                val x = track.getDouble("x")
//                val y = track.getDouble("y")
//                if(x!=null && y!=null){
//                  tmp.add(x)
//                  tmp.add(y)
//                  polyline_new.add(tmp)
//                }
//              }
//            }
//            json.put("polyline", polyline_new)
//          }
//
//          var tl_times:java.lang.Long = 0l
//          if(true){//"0".equalsIgnoreCase(req_status)
//            val stay_list = json.getJSONArray("stay_list")
//            if(req_time!=null && navi_endtime!=null && stay_list!=null && stay_list.size()>0){
//              for(i<-0.until(stay_list.size())){
//                val stay = stay_list.getJSONObject(i)
//                if(stay!=null){
//                  val stayStartTime = stay.getLong("stayStartTime")
//                  val stayEndTime = stay.getLong("stayEndTime")
//                  var duration = stay.getLong("duration")
//                  if(stayStartTime!=null && stayEndTime!=null && duration!=null){
//                    duration = duration * 1000
//                    if(stayStartTime >= req_time && stayEndTime <= navi_endtime) {}
//                    else if(stayStartTime <= req_time && stayEndTime >= req_time && stayStartTime <= navi_endtime && stayEndTime >= navi_endtime){
//                      duration = duration - (req_time - stayStartTime) - (stayEndTime - navi_endtime)
//                    }
//                    else if(stayStartTime <= req_time && stayEndTime >= req_time){
//                      duration = duration - (req_time - stayStartTime)
//                    }
//                    else if(stayStartTime <= navi_endtime && stayEndTime >= navi_endtime){
//                      duration = duration - (stayEndTime - navi_endtime)
//                    }
//                    tl_times = tl_times + duration
//                  }
//                }
//              }
//            }
//
//            if(polyline_new!=null && polyline_new.size()>0 && tracks2_new!=null && tracks2_new.size()>0){
//
//              val polyline_new2 = new JSONArray()
//              for(i<-0.until(polyline_new.size())){
//                val track = polyline_new.getJSONArray(i)
//                if(track!=null){
//                  val x = track.getDouble(0)
//                  val y = track.getDouble(1)
//                  if(x!=null && y!=null){
//                    val newJson = new JSONObject()
//                    newJson.put("x",x)
//                    newJson.put("y",y)
//                    newJson.put("type",1)
//                    polyline_new2.add(newJson)
//                  }
//                }
//              }
//
//              val tracks2_new2 = new JSONArray()
//              for(i<-0.until(tracks2_new.size())){
//                val track = tracks2_new.getJSONArray(i)
//                if(track!=null){
//                  val x = track.getDouble(0)
//                  val y = track.getDouble(1)
//                  if(x!=null && y!=null){
//                    val newJson = new JSONObject()
//                    newJson.put("x",x)
//                    newJson.put("y",y)
//                    newJson.put("type",1)
//                    tracks2_new2.add(newJson)
//                  }
//                }
//              }
//
//              val resultObject = accessCompareUrl(json,polyline_new2,tracks2_new2)
//              if(resultObject!=null){
//                val resultObject2 = resultObject.getJSONObject("result")
//                if(resultObject2!=null){
//                  val similarity1 =  resultObject2.getDouble("similarity1")
//                  val similarity2 = resultObject2.getDouble("similarity2")
//                  json.put("similarity1",similarity1)
//                  json.put("similarity5",similarity2)
//                }
//              }
//
//            }
//
//          }
//          if(tl_times!=null) json.put("tl_times",tl_times.toDouble / 1000)
//
//          json.put("req_order",i)
//          json.put("req_count",req_count)
//          list += json
//        }
//        list
//      })
//
//      .map(json=>{
//        val task_id = json.getString("task_id")
//        val navi_id = json.getString("navi_id")
//        var req_time = json.getLong("req_time")
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        ((task_id,navi_id),(req_time,json))
//      })
//      .groupByKey()
//      .map(obj=>{
//        val key = obj._1
//        val jsonList = obj._2.toList.sortBy(_._1)
//
//        var t1:java.lang.Long = null
//        for(i<-jsonList.indices){
//          val item = jsonList(i)
//          if(item!=null){
//            val json = item._2
//            if(json!=null){
//              val req_type = json.getString("req_type")
//              if("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)){
//                val req_time = json.getLong("req_time")
//                if(req_time!=null){
//                  if(t1!=null){
//                    val yaw_time = Math.abs(req_time - t1)
//                    if(yaw_time <= 5 * 60 * 1000) json.put("yaw_time",yaw_time)
//                    else json.put("yaw_time","0")
//                    t1 = json.getLong("t1")
//                  }
//                  else{
//                    json.put("yaw_time","0")
//                    t1 = json.getLong("t1")
//                  }
//                }
//                else{
//                  json.put("yaw_time","0")
//                  t1 = json.getLong("t1")
//                }
//              }
//            }
//          }
//        }
//
//        (key,jsonList)
//      })
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//
//        val jsonList = obj._2.toList.groupBy(item=>item._2.getString("routeid")).map(item=>{
//          val sortList = item._2.toList.sortBy(_._1)
//          val minReqTime = sortList.head._1
//          (minReqTime,sortList.map(_._2))
//        }).toList.sortBy(_._1).map(_._2)
//
//        val route_count = jsonList.size
//        for(i <- jsonList.indices){
//
//          val yawpoints = new ArrayBuffer[String]()
//          var yawpoints_count = 0
//          var yawpoints_str = ""
//          if(i != jsonList.size - 1){
//            for(k <- jsonList.indices){
//              if(k > i){
//                val jsonList2 = jsonList(k)
//                for(j <- jsonList2.indices){
//                  val json = jsonList2(j)
//                  if(json!=null){
//                    val req_type = json.getString("req_type")
//                    if("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)){
//                      var x1 = json.getString("x1")
//                      var y1 = json.getString("y1")
//                      if(StringUtils.isEmpty(x1)) x1 = ""
//                      if(StringUtils.isEmpty(y1)) y1 = ""
//                      val xy = x1 + "," + y1
//                      yawpoints += xy
//                      yawpoints_count = yawpoints_count + 1
//                    }
//                  }
//                }
//              }
//            }
//          }
//          if(yawpoints.nonEmpty) yawpoints_str = yawpoints.mkString(";")
//
//          val jsonList2 = jsonList(i)
//          for(j <- jsonList2.indices){
//            val json = jsonList2(j)
//
//            json.put("yawpoints",yawpoints_str)
//            json.put("yawpoints_count",yawpoints_count)
//
//            json.put("route_order",i)
//            json.put("route_count",route_count)
//            list += json
//          }
//        }
//        list
//      })
//
//      .map(json=>{
//        val task_id = json.getString("task_id")
//        var req_time = json.getLong("req_time")
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        (task_id,(req_time,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//
//        val jsonList = obj._2.toList.groupBy(item=>item._2.getString("navi_id")).map(item=>{
//          val sortList = item._2.toList.sortBy(_._1)
//          val minReqTime = sortList.head._1
//          (minReqTime,sortList.map(_._2))
//        }).toList.sortBy(_._1).map(_._2)
//
//        val navi_count = jsonList.size
//        for(i <- jsonList.indices){
//          val jsonList2 = jsonList(i)
//          for(j <- jsonList2.indices){
//            val json = jsonList2(j)
//            json.put("navi_order",i)
//            json.put("navi_count",navi_count)
//            list += json
//          }
//        }
//        list
//      })
//
//      .map(json=>{
//        if(json!=null){
//          try{
//            val navi_endtime = json.getDouble("navi_endtime")
//            val req_time = json.getDouble("req_time")
//            if(navi_endtime!=null && req_time!=null){
//              val navi_time:java.lang.Double = (navi_endtime - req_time).toDouble/1000
//              json.put("navi_time",navi_time)
//              val duration = json.getDouble("duration")
//              if(duration!=null && navi_time!=null){
//                val diff_time:java.lang.Double = duration - navi_time
//                json.put("diff_time",diff_time)
//                if(diff_time!=null && navi_time!=null && navi_time!=0){
//                  var ft_right = ""
//                  if(Math.abs(diff_time/navi_time) <= 0.1667) ft_right = "1"
//                  else ft_right = "0"
//                  json.put("ft_right",ft_right)
//                }
//              }
//
//              val tl_times = json.getDouble("tl_times")
//              if(tl_times!=null && navi_time!=null){
//                val tl_navi_time:java.lang.Double = navi_time - tl_times
//                json.put("tl_navi_time",tl_navi_time)
//                if(duration!=null && tl_navi_time!=null){
//                  val tl_diff_time:java.lang.Double = duration - tl_navi_time
//                  json.put("tl_diff_time",tl_diff_time)
//                  if(tl_diff_time!=null && tl_navi_time!=null && tl_navi_time!=0){
//                    var tl_ft_right = ""
//                    if(Math.abs(tl_diff_time/tl_navi_time) <= 0.1667) tl_ft_right = "1"
//                    else tl_ft_right = "0"
//                    json.put("tl_ft_right",tl_ft_right)
//                  }
//                }
//              }
//            }
//
//          }
//          catch {
//            case e:Exception =>logger.error(">>>日志转json失败："+e)
//          }
//        }
//        json
//      })
//      .persist()
//    logger.error(">>>计算后日志量：" + computeRdd.count())
//
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取ETA结果汇总1
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getEtaResult1Rdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      //      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
//      //      dateList = DateUtil.getTwoDatesStr(startDate,runDate)
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的ETA结果汇总")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.starttime_type,a.routeid,a.request_id,a.req_time,a.req_type,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.reroute,a.status,a.pns_status,a.distance,a.duration,a.toll_distance,a.tolls,a.src,a.trafficlight_count,a.highspeed_distance,a.flen,a.tlen,a.routeid_out,a.linknum,a.rc_distance,a.rdynsdlen,a.rdynsdcnt,a.start_speed,a.vehicle_dir1,a.rect_result,a.strategy2,a.routetype,a.merge_result,a.driver_type,a.is_econ,a.service_id,a.line_code,a.navi_type,a.route_index,a.sdk_type,a.navi_endtime2,b.navi_endstatus,b.navi_endtime,b.navi_endx,b.navi_endy,c.stay_list,c.ret,c.offtime_ratio,d.start_type,e.navi_strategy,a.inc_day,a.inc_date from
//           |(select task_id,navi_id,navi_starttime,starttime_type,routeid,request_id,req_time,'top3' as req_type,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,'' as reroute,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,linknum,rc_distance,rdynsdlen,rdynsdcnt,start_speed,vehicle_dir1,rect_result,strategy2,routetype,merge_result,driver_type,is_econ,service_id,line_code,navi_type,route_index,'SFSDK' as sdk_type,'' as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' union all
//           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'yaw' as req_type,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,linknum,rc_distance,rdynsdlen,rdynsdcnt,'' as start_speed,'' as vehicle_dir1,rect_result,strategy2,routetype,merge_result,'' as driver_type,is_econ,service_id,line_code,navi_type,'' as route_index,'SFSDK' as sdk_type,'' as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_yaw_route where inc_day='$runDate' and hasyaw='true' union all
//           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'gdtop3' as req_type,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'' as path_count,opt,'' as strategy,'' as merge,routeid_in,fixed_route,fencedist,'' as reroute,status,'' as pns_status,'' as distance,'' as duration,'' as toll_distance,'' as tolls,'' as src,'' as trafficlight_count,'' as highspeed_distance,'' as flen,'' as tlen,'' as routeid_out,'' as linknum,'' as rc_distance,'' as rdynsdlen,'' as rdynsdcnt,'' as start_speed,'' as vehicle_dir1,'' as rect_result,'' as strategy2,'' as routetype,'' as merge_result,driver_type,'' as is_econ,service_id,line_code,navi_type,'' as route_index,'GDSDK' as sdk_type,navi_endtime as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_gd_route_eta where inc_day='$runDate') a
//           |left join (select navi_id,max(status) as navi_endstatus,max(navi_endtime) as navi_endtime,max(navi_endx) as navi_endx,max(navi_endy) as navi_endy from dm_gis.gis_navi_finish_monitor where inc_day='$runDate' group by navi_id) b on a.navi_id=b.navi_id
//           |left join (select navi_id,stay_list,ret,offtime_ratio from dm_gis.gis_navi_rectify_result where inc_day='$runDate') c on a.navi_id=c.navi_id
//           |left join (select navi_id,max(start_type) as start_type from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate') group by navi_id) d on a.navi_id=d.navi_id
//           |left join (select navi_id,max(navi_strategy) as navi_strategy from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day='$runDate' group by navi_id) e on a.navi_id=e.navi_id
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
//      val endDate = runDate
//      val endDate1 = DateUtil.getDateStr(runDate,1)
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.starttime_type,a.routeid,a.request_id,a.req_time,a.req_type,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.reroute,a.status,a.pns_status,a.distance,a.duration,a.toll_distance,a.tolls,a.src,a.trafficlight_count,a.highspeed_distance,a.flen,a.tlen,a.routeid_out,a.linknum,a.rc_distance,a.rdynsdlen,a.rdynsdcnt,a.start_speed,a.vehicle_dir1,a.rect_result,a.strategy2,a.routetype,a.merge_result,a.driver_type,a.is_econ,a.service_id,a.line_code,a.navi_type,a.route_index,a.sdk_type,a.navi_endtime2,b.navi_endstatus,b.navi_endtime,b.navi_endx,b.navi_endy,c.stay_list,c.ret,c.offtime_ratio,d.start_type,e.navi_strategy,a.inc_day,a.inc_date from
//           |(select task_id,navi_id,navi_starttime,starttime_type,routeid,request_id,req_time,'top3' as req_type,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,'' as reroute,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,linknum,rc_distance,rdynsdlen,rdynsdcnt,start_speed,vehicle_dir1,rect_result,strategy2,routetype,merge_result,driver_type,is_econ,service_id,line_code,navi_type,route_index,'SFSDK' as sdk_type,'' as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_top3_click_route where inc_day between '$startDate' and '$endDate' union all
//           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'yaw' as req_type,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,strategy,merge,routeid_in,fixed_route,fencedist,reroute,status,pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,linknum,rc_distance,rdynsdlen,rdynsdcnt,'' as start_speed,'' as vehicle_dir1,rect_result,strategy2,routetype,merge_result,'' as driver_type,is_econ,service_id,line_code,navi_type,'' as route_index,'SFSDK' as sdk_type,'' as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_yaw_route where inc_day between '$startDate' and '$endDate' and hasyaw='true' union all
//           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'gdtop3' as req_type,x1,y1,x2,y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'' as path_count,opt,'' as strategy,'' as merge,routeid_in,fixed_route,fencedist,'' as reroute,status,'' as pns_status,'' as distance,'' as duration,'' as toll_distance,'' as tolls,'' as src,'' as trafficlight_count,'' as highspeed_distance,'' as flen,'' as tlen,'' as routeid_out,'' as linknum,'' as rc_distance,'' as rdynsdlen,'' as rdynsdcnt,'' as start_speed,'' as vehicle_dir1,'' as rect_result,'' as strategy2,'' as routetype,'' as merge_result,driver_type,'' as is_econ,service_id,line_code,navi_type,'' as route_index,'GDSDK' as sdk_type,navi_endtime as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_gd_route_eta where inc_day between '$startDate' and '$endDate') a
//           |left join (select navi_id,max(status) as navi_endstatus,max(navi_endtime) as navi_endtime,max(navi_endx) as navi_endx,max(navi_endy) as navi_endy from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate1' group by navi_id) b on a.navi_id=b.navi_id
//           |left join (select navi_id,stay_list,ret,offtime_ratio from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1') c on a.navi_id=c.navi_id
//           |left join (select navi_id,max(start_type) as start_type from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate1' group by navi_id) d on a.navi_id=d.navi_id
//           |left join (select navi_id,max(navi_strategy) as navi_strategy from dm_gis.gis_navi_sdk_navi_parse where type='1' and inc_day between '$startDate' and '$endDate1' group by navi_id) e on a.navi_id=e.navi_id
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//    val computeRdd = resultRdd.repartition(64000)
//      .map(json=>{
//        var navi_id = json.getString("navi_id")
//        var request_id = json.getString("request_id")
//        var req_time = json.getLong("req_time")
//        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
//        if(StringUtils.isEmpty(request_id)) request_id = "-"
//        if(req_time==null) req_time = Long.MaxValue
//
//        val id = navi_id + "_" + request_id + "_" + req_time.toString
//        json.put("id",id)
//
//        if("GDSDK".equalsIgnoreCase(json.getString("sdk_type"))){
//          var navi_endtime2 = json.getString("navi_endtime2")
//          if(StringUtils.isEmpty(navi_endtime2)) navi_endtime2 = ""
//          json.put("navi_endtime",navi_endtime2)
//        }
//
//        (id,json)
//      })
//      .groupByKey()
//      .map(obj=>{
//        val json = obj._2.toList.head
//        json
//      })
//      .map(json=>{
//        var task_id = json.getString("task_id")
//        var navi_id = json.getString("navi_id")
//        var routeid = json.getString("routeid")
//        var req_time = json.getLong("req_time")
//
//        if(StringUtils.isEmpty(task_id)) task_id = "-"
//        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
//        if(StringUtils.isEmpty(routeid)) routeid = "-"
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        ((task_id,navi_id,routeid),(req_time,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
//        val req_count = jsonList.size
//        for(i <- jsonList.indices){
//          val json = jsonList(i)
//
//          var req_status = ""
//          val navi_endstatus = json.getInteger("navi_endstatus")
//          if(navi_endstatus!=null){
//            if(navi_endstatus>=10){
//              req_status = "1"
//            }
//            else if(navi_endstatus == 0) req_status = "-1"
//            else if(navi_endstatus < 10){
//              if(i < req_count - 1){
//                val nextJson = jsonList(i + 1)
//                val x1 = json.getString("x1")
//                val y1 = json.getString("y1")
//                val next_x1 = nextJson.getString("x1")
//                val next_y1 = nextJson.getString("y1")
//                if(!StringUtils.isEmpty(x1) && !StringUtils.isEmpty(y1) && x1.equalsIgnoreCase(next_x1) && y1.equalsIgnoreCase(next_y1)){
//                  req_status = "1"
//                }
//              }
//              if(!"1".equalsIgnoreCase(req_status)){
//                val req_time = json.getLong("req_time")
//                val navi_starttime = json.getLong("navi_starttime")
//                if(req_time!=null && navi_starttime!=null && req_time < navi_starttime) req_status = "1"
//                else if(!"0".equalsIgnoreCase(json.getString("status")) || !"0".equalsIgnoreCase(json.getString("pns_status"))) req_status = "1"
//                else req_status = "0"
//              }
//            }
//            json.put("req_status",req_status)
//          }
//
//          val req_time = json.getLong("req_time")
//          val navi_endtime = json.getLong("navi_endtime")
//
//          var tl_times:java.lang.Long = 0l
//          if(true){//"0".equalsIgnoreCase(req_status)
//          val stay_list = json.getJSONArray("stay_list")
//            if(req_time!=null && navi_endtime!=null && stay_list!=null && stay_list.size()>0){
//              for(i<-0.until(stay_list.size())){
//                val stay = stay_list.getJSONObject(i)
//                if(stay!=null){
//                  val stayStartTime = stay.getLong("stayStartTime")
//                  val stayEndTime = stay.getLong("stayEndTime")
//                  var duration = stay.getLong("duration")
//                  if(stayStartTime!=null && stayEndTime!=null && duration!=null){
//                    duration = duration * 1000
//                    if(stayStartTime >= req_time && stayEndTime <= navi_endtime) {}
//                    else if(stayStartTime <= req_time && stayEndTime >= req_time && stayStartTime <= navi_endtime && stayEndTime >= navi_endtime){
//                      duration = duration - (req_time - stayStartTime) - (stayEndTime - navi_endtime)
//                    }
//                    else if(stayStartTime <= req_time && stayEndTime >= req_time){
//                      duration = duration - (req_time - stayStartTime)
//                    }
//                    else if(stayStartTime <= navi_endtime && stayEndTime >= navi_endtime){
//                      duration = duration - (stayEndTime - navi_endtime)
//                    }
//                    tl_times = tl_times + duration
//                  }
//                }
//              }
//            }
//            json.remove("stay_list")
//
//          }
//
//          if(tl_times!=null) json.put("tl_times",tl_times.toDouble / 1000)
//
//          json.put("req_order",i)
//          json.put("req_count",req_count)
//          list += json
//        }
//        list
//      })
//
//      .map(json=>{
//        val task_id = json.getString("task_id")
//        val navi_id = json.getString("navi_id")
//        var req_time = json.getLong("req_time")
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        ((task_id,navi_id),(req_time,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//
//        val jsonList = obj._2.toList.groupBy(item=>item._2.getString("routeid")).map(item=>{
//          val sortList = item._2.toList.sortBy(_._1)
//          val minReqTime = sortList.head._1
//          (minReqTime,sortList.map(_._2))
//        }).toList.sortBy(_._1).map(_._2)
//
//        val route_count = jsonList.size
//        for(i <- jsonList.indices){
//
//          val yawpoints = new ArrayBuffer[String]()
//          var yawpoints_count = 0
//          var yawpoints_str = ""
//          if(i != jsonList.size - 1){
//            for(k <- jsonList.indices){
//              if(k > i){
//                val jsonList2 = jsonList(k)
//                for(j <- jsonList2.indices){
//                  val json = jsonList2(j)
//                  if(json!=null){
//                    val req_type = json.getString("req_type")
//                    if("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)){
//                      var x1 = json.getString("x1")
//                      var y1 = json.getString("y1")
//                      if(StringUtils.isEmpty(x1)) x1 = ""
//                      if(StringUtils.isEmpty(y1)) y1 = ""
//                      val xy = x1 + "," + y1
//                      yawpoints += xy
//                      yawpoints_count = yawpoints_count + 1
//                    }
//                  }
//                }
//              }
//            }
//          }
//          if(yawpoints.nonEmpty) yawpoints_str = yawpoints.mkString(";")
//
//          val jsonList2 = jsonList(i)
//          for(j <- jsonList2.indices){
//            val json = jsonList2(j)
//
//            json.put("yawpoints",yawpoints_str)
//            json.put("yawpoints_count",yawpoints_count)
//
//            json.put("route_order",i)
//            json.put("route_count",route_count)
//            list += json
//          }
//        }
//        list
//      })
//
//      .map(json=>{
//        val task_id = json.getString("task_id")
//        var req_time = json.getLong("req_time")
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        (task_id,(req_time,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//
//        val jsonList = obj._2.toList.groupBy(item=>item._2.getString("navi_id")).map(item=>{
//          val sortList = item._2.toList.sortBy(_._1)
//          val minReqTime = sortList.head._1
//          (minReqTime,sortList.map(_._2))
//        }).toList.sortBy(_._1).map(_._2)
//
//        val navi_count = jsonList.size
//        for(i <- jsonList.indices){
//          val jsonList2 = jsonList(i)
//          for(j <- jsonList2.indices){
//            val json = jsonList2(j)
//            json.put("navi_order",i)
//            json.put("navi_count",navi_count)
//            list += json
//          }
//        }
//        list
//      })
//
//      .map(json=>{
//        if(json!=null){
//          try{
//            val navi_endtime = json.getDouble("navi_endtime")
//            val req_time = json.getDouble("req_time")
//            if(navi_endtime!=null && req_time!=null){
//              val navi_time:java.lang.Double = (navi_endtime - req_time).toDouble/1000
//              json.put("navi_time",navi_time)
//              val duration = json.getDouble("duration")
//              if(duration!=null && navi_time!=null){
//                val diff_time:java.lang.Double = duration - navi_time
//                json.put("diff_time",diff_time)
//                if(diff_time!=null && navi_time!=null && navi_time!=0){
//                  var ft_right = ""
//                  if(Math.abs(diff_time/navi_time) <= 0.1667) ft_right = "1"
//                  else ft_right = "0"
//                  json.put("ft_right",ft_right)
//                }
//              }
//
//              val tl_times = json.getDouble("tl_times")
//              if(tl_times!=null && navi_time!=null){
//                val tl_navi_time:java.lang.Double = navi_time - tl_times
//                json.put("tl_navi_time",tl_navi_time)
//                if(duration!=null && tl_navi_time!=null){
//                  val tl_diff_time:java.lang.Double = duration - tl_navi_time
//                  json.put("tl_diff_time",tl_diff_time)
//                  if(tl_diff_time!=null && tl_navi_time!=null && tl_navi_time!=0){
//                    var tl_ft_right = ""
//                    if(Math.abs(tl_diff_time/tl_navi_time) <= 0.1667) tl_ft_right = "1"
//                    else tl_ft_right = "0"
//                    json.put("tl_ft_right",tl_ft_right)
//                  }
//                }
//              }
//            }
//
//          }
//          catch {
//            case e:Exception =>logger.error(">>>日志转json失败："+e)
//          }
//        }
//        json
//      })
//      .persist()
//    logger.error(">>>计算后日志量：" + computeRdd.count())
//
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
////  /**
////    * 获取ETA结果汇总2
////    * @param spark
////    * @param runType
////    * @param date
////    * @param auto
////    * @return
////    */
////  def getEtaResult2Rdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
////    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
////    var runDate = ""
////    if("true".equalsIgnoreCase(auto)){
////      runDate = DateUtil.getDateStr(date,-1)
////    }
////    else{
////      runDate = date
////    }
////    //      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
////    //      dateList = DateUtil.getTwoDatesStr(startDate,runDate)
////    dateList += runDate
////
////
////    logger.error(">>>获取"+runDate+"号的ETA结果汇总")
////    var sql1 = ""
////    var sql2 = ""
////    var table = ""
////    var structs:Array[String] = null
////    var keys:Array[String] = null
////
////
////    val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
////    val endDate = runDate
////    val endDate1 = DateUtil.getDateStr(runDate,1)
////
////
////    logger.error(">>>开始处理base")
////    sql1=
////      s"""
////         |select a.task_id,a.navi_id,a.navi_starttime,a.starttime_type,a.routeid,a.request_id,a.req_time,a.req_type,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.swid,a.starts,a.polyline,a.links,b.navi_endtime,a.inc_date from
////         |(select task_id,navi_id,navi_starttime,starttime_type,routeid,request_id,req_time,'top3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,starts,polyline,links,inc_day as inc_date from dm_gis.gis_navi_top3_click_route where inc_day between '$startDate' and '$endDate' union all
////         |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'yaw' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,swid,starts,polyline,links,inc_day as inc_date from dm_gis.gis_navi_yaw_route where inc_day between '$startDate' and '$endDate' and hasyaw='true') a
////         |left join (select navi_id,max(navi_endtime) as navi_endtime from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate1' group by navi_id) b on a.navi_id=b.navi_id
////       """.stripMargin
////
////    val baseLogRdd = NaviLogParse.getValidJson(spark,sql1)
////
////    val baseRdd = baseLogRdd.filter(json => !"0be66d610d0490ae0ab70ad1d940cf191".equalsIgnoreCase(json.getString("nava_id"))
////      && !"27feba4b90f68ff3e7e6a8af9808b4661".equalsIgnoreCase(json.getString("nava_id"))
////      && !"b03d83ec5110b93b153e1509ee13d6420".equalsIgnoreCase(json.getString("nava_id")))
////      .map(json=>{
////        if(json!=null){
////          var navi_id = json.getString("navi_id")
////          var request_id = json.getString("request_id")
////          var req_time = json.getLong("req_time")
////
////          if(StringUtils.isEmpty(navi_id)) navi_id = "-"
////          if(StringUtils.isEmpty(request_id)) request_id = "-"
////          if(req_time==null) req_time = Long.MaxValue
////
////          val polyline = json.getString("polyline")
////          var polyline_array:JSONArray = null
////          if(!StringUtils.isEmpty(polyline)) polyline_array = JSON.parseArray(polyline)
////          val polyline_new = new JSONArray()
////          json.remove("polyline")
////          if(polyline_array!=null && polyline_array.size()>0){
////            for(j<-0.until(polyline_array.size())){
////              val track = polyline_array.getJSONObject(j)
////              val tmp = new JSONArray()
////              if(track!=null){
////                val x = track.getDouble("x")
////                val y = track.getDouble("y")
////                if(x!=null && y!=null){
////                  tmp.add(x)
////                  tmp.add(y)
////                  polyline_new.add(tmp)
////                }
////              }
////            }
////            json.put("polyline", polyline_new)
////          }
////
////          val id = navi_id + "_" + request_id + "_" + req_time.toString
////          json.put("id",id)
////        }
////
////        json
////      }).persist()
////    logger.error(">>>计算base后日志量：" + baseRdd.count())
////    baseLogRdd.unpersist()
////
////    logger.error(">>>base数据保存")
////    table = "gis_navi_eta_result2_base"
////    structs = Array("id","task_id","navi_id","routeid","request_id","navi_starttime","starttime_type","req_time","navi_endtime","req_type","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","swid","starts","polyline","links")
////    keys = Array("id","task_id","navi_id","routeid","request_id","navi_starttime","starttime_type","req_time","navi_endtime","req_type","src_province","src_citycode","src_deptcode","dest_province","dest_citycode","dest_deptcode","swid","starts","polyline","links")
////    NaviMain.mutiDayRddToHive(spark,baseRdd,table,structs,keys,dateList)
////
////
////    logger.error(">>>开始处理tracks1")
////    sql1=
////      s"""
////         |select id,navi_id,req_time,navi_endtime,inc_day as inc_date from dm_gis.gis_navi_eta_result2_base where inc_day between '$startDate' and '$endDate'
////       """.stripMargin
////    sql2=
////      s"""
////         |select navi_id,max(tracks1) as tracks1 from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1' group by navi_id
////       """.stripMargin
////
////    val tracks1LogRdd1 = NaviLogParse.getValidJson(spark,sql1)
////    val tracks1LogRdd2 = NaviLogParse.getValidJson(spark,sql2)
////
////    val tracks1TmpRdd1 = tracks1LogRdd1
////      .map(json=>{
////        var navi_id = json.getString("navi_id")
////        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
////
////        (navi_id,json)
////      })
////      .groupByKey()
////
////    val tracks1TmpRdd2 = tracks1LogRdd2
////      .map(json=>{
////        var navi_id = json.getString("navi_id")
////        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
////
////        (navi_id,json)
////      })
////
////    val tracks1Rdd = tracks1TmpRdd1.leftOuterJoin(tracks1TmpRdd2)
////      .flatMap(obj=>{
////        val list = new ArrayBuffer[JSONObject]()
////
////        val jsonList: List[JSONObject] = obj._2._1.toList
////        var targetJson:JSONObject = null
////        if(obj._2._2.nonEmpty){
////          targetJson = obj._2._2.get
////        }
////        var tracks1:JSONArray = null
////        if(targetJson != null){
////          tracks1 = targetJson.getJSONArray("tracks1")
////          targetJson.remove("tracks1")
////        }
////
////        for(i <- jsonList.indices){
////          val json = jsonList(i)
////
////          val req_time = json.getLong("req_time")
////          val navi_endtime = json.getLong("navi_endtime")
////
////          val tracks1_new = new JSONArray()
////          if(tracks1!=null && tracks1.size()>0 && req_time!=null && navi_endtime!=null){
////            var diff_min1 = Long.MaxValue
////            var diff_min2 = Long.MaxValue
////            var index1 = -1
////            var index2 = -1
////            breakable(
////              for(j<-0.until(tracks1.size())){
////                val track = tracks1.getJSONObject(j)
////                if(track!=null){
////                  val tm = track.getLong("tm")
////                  if(tm!=null){
////                    val diff = Math.abs(req_time - tm * 1000)
////                    if(diff < diff_min1) {
////                      diff_min1 = diff
////                      index1 = j
////                    }
////                    else break
////                  }
////                }
////              }
////            )
////
////            breakable(
////              for(j<-0.until(tracks1.size())){
////                val track = tracks1.getJSONObject(tracks1.size() - j - 1)
////                if(track!=null){
////                  val tm = track.getLong("tm")
////                  if(tm!=null){
////                    val diff = Math.abs(navi_endtime - tm * 1000)
////                    if(diff < diff_min2) {
////                      diff_min2 = diff
////                      index2 = tracks1.size() - j - 1
////                    }
////                    else break
////                  }
////                }
////              }
////            )
////
////            if(index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks1.size()){
////              for(j<-index1.until(index2 + 1)){
////                val track = tracks1.getJSONObject(j)
////                val tmp = new JSONArray()
////                if(track!=null){
////                  val x = track.getDouble("x")
////                  val y = track.getDouble("y")
////                  if(x!=null && y!=null){
////                    tmp.add(x)
////                    tmp.add(y)
////                    tracks1_new.add(tmp)
////                  }
////                }
////              }
////            }
////            if(tracks1_new.size() > 0) json.put("tracks1", tracks1_new)
////          }
////
////          list += json
////        }
////
////        list
////      })
////      .persist()
////    logger.error(">>>计算tracks1后日志量：" + tracks1Rdd.count())
////    tracks1LogRdd1.unpersist()
////    tracks1LogRdd2.unpersist()
////
////    logger.error(">>>tracks1数据保存")
////    table = "gis_navi_eta_result2_tracks1"
////    structs = Array("id","navi_id","req_time","navi_endtime","tracks1")
////    keys = Array("id","navi_id","req_time","navi_endtime","tracks1")
////    NaviMain.mutiDayRddToHive(spark,tracks1Rdd,table,structs,keys,dateList)
////
////
////
////    logger.error(">>>开始处理tracks2")
////    sql1=
////      s"""
////         |select id,navi_id,req_time,navi_endtime,req_type,links,inc_day as inc_date from dm_gis.gis_navi_eta_result2_base where inc_day between '$startDate' and '$endDate'
////       """.stripMargin
////    sql2=
////      s"""
////         |select navi_id,max(tracks2) as tracks2 from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1' group by navi_id
////       """.stripMargin
////
////    val tracks2LogRdd1 = NaviLogParse.getValidJson(spark,sql1)
////    val tracks2LogRdd2 = NaviLogParse.getValidJson(spark,sql2)
////
////    val tracks2TmpRdd1 = tracks2LogRdd1
////      .map(json=>{
////        var navi_id = json.getString("navi_id")
////        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
////
////        var req_time = json.getLong("req_time")
////        if(req_time==null) req_time = Long.MaxValue
////
////        (navi_id,(req_time,json))
////      })
////      .groupByKey()
////
////    val tracks2TmpRdd2 = tracks2LogRdd2
////      .map(json=>{
////        var navi_id = json.getString("navi_id")
////        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
////
////        (navi_id,json)
////      })
////
////    val tracks2Rdd = tracks2TmpRdd1.leftOuterJoin(tracks2TmpRdd2)
////      .flatMap(obj=>{
////        val list = new ArrayBuffer[JSONObject]()
////        val tmp_list = new ArrayBuffer[JSONObject]()
////
////        val jsonList: List[JSONObject] = obj._2._1.toList.sortBy(_._1).map(_._2)
////        var targetJson:JSONObject = null
////        if(obj._2._2.nonEmpty){
////          targetJson = obj._2._2.get
////        }
////        var tracks2:JSONArray = null
////        if(targetJson != null){
////          tracks2 = targetJson.getJSONArray("tracks2")
////          targetJson.remove("tracks2")
////        }
////
////        for(i <- jsonList.indices){
////          val json = jsonList(i)
////
////          val req_time = json.getLong("req_time")
////          val navi_endtime = json.getLong("navi_endtime")
////
////          var navi_distance:java.lang.Double = null
////          val tracks2_new = new JSONArray()
////          if(tracks2!=null && tracks2.size()>0 && req_time!=null && navi_endtime!=null){
////            var diff_min1 = Long.MaxValue
////            var diff_min2 = Long.MaxValue
////            var index1 = -1
////            var index2 = -1
////            breakable(
////              for(j<-0.until(tracks2.size())){
////                val track = tracks2.getJSONObject(j)
////                if(track!=null){
////                  val tm = track.getLong("tm")
////                  if(tm!=null){
////                    val diff = Math.abs(req_time - tm * 1000)
////                    if(diff <= diff_min1) {
////                      diff_min1 = diff
////                      index1 = j
////                    }
////                    else break
////                  }
////                }
////              }
////            )
////
////            breakable(
////              for(j<-0.until(tracks2.size())){
////                val track = tracks2.getJSONObject(tracks2.size() - j - 1)
////                if(track!=null){
////                  val tm = track.getLong("tm")
////                  if(tm!=null){
////                    val diff = Math.abs(navi_endtime - tm * 1000)
////                    if(diff <= diff_min2) {
////                      diff_min2 = diff
////                      index2 = tracks2.size() - j - 1
////                    }
////                    else break
////                  }
////                }
////              }
////            )
////
////            if(index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks2.size()){
////              val track1 = tracks2.getJSONObject(index1)
////              val track2 = tracks2.getJSONObject(index2)
////              if(track1!=null && track2!=null){
////                val sum_dist1 = track1.getDouble("sum_dist")
////                val sum_dist2 = track2.getDouble("sum_dist")
////                if(sum_dist1!=null && sum_dist2!=null){
////                  navi_distance = sum_dist2 - sum_dist1
////                }
////              }
////              var swid = ""
////              var links2 = new JSONArray()
////              val req_type = json.getString("req_type")
////              var type_flag = false
////              if("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)) type_flag = true
////
////              for(j<-index1.until(index2 + 1)){
////                val track = tracks2.getJSONObject(j)
////                val tmp = new JSONArray()
////                if(track!=null){
////                  val x = track.getDouble("x")
////                  val y = track.getDouble("y")
////                  if(x!=null && y!=null){
////                    tmp.add(x)
////                    tmp.add(y)
////                    tracks2_new.add(tmp)
////                  }
////                }
////
////                if(type_flag){
////                  val _swid = track.getString("swid")
////                  if(!swid.equalsIgnoreCase(_swid) && !StringUtils.isEmpty(_swid)){
////                    swid = _swid
////                    val tmpTrack = new JSONObject()
////                    tmpTrack.put("swid",swid)
////                    val tm = track.getString("tm")
////                    if(!StringUtils.isEmpty(tm)) tmpTrack.put("tm",tm + "000")
////                    links2.add(tmpTrack)
////                  }
////                }
////              }
////
////              if(type_flag){
////                if(links2.size() > 0){
////                  json.put("links2", links2)
////                  if(json.containsKey("links") && !StringUtils.isEmpty(json.getString("links"))){
////                    val links = json.getString("links").split(",")
////                    val size1 = links.size
////                    val size2 = links2.size()
////                    var size = 0
////                    if(size1 > size2) size = size2
////                    else size = size1
////                    breakable(
////                      for(m<-0.until(size)){
////                        val link = links(m)
////                        val link2 = links2.getJSONObject(m)
////                        if(link2!=null){
////                          val swid = link2.getString("swid")
////                          if(!StringUtils.isEmpty(link)){
////                            if(!link.equalsIgnoreCase(swid)){
////                              val tm = link2.getString("tm")
////                              json.put("t1", tm)
////                              break
////                            }
////                          }
////                          else if(!StringUtils.isEmpty(swid)){
////                            val tm = link2.getString("tm")
////                            json.put("t1", tm)
////                            break
////                          }
////                        }
////                        else if(!StringUtils.isEmpty(link)) {
////                          json.put("t1", "0")
////                          break
////                        }
////                      }
////                    )
////                  }
////                  else json.put("t1", "0")
////                }
////                else json.put("t1", "0")
////              }
////
////            }
////            if(tracks2_new.size() > 0) json.put("tracks2", tracks2_new)
////          }
////
////          if(navi_distance!=null) json.put("navi_distance",navi_distance)
////
////          tmp_list += json
////        }
////
////        var t1:java.lang.Long = null
////        for(i<-tmp_list.indices){
////          val json = tmp_list(i)
////          if(json!=null){
////            val req_type = json.getString("req_type")
////            if("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)){
////              val req_time = json.getLong("req_time")
////              if(req_time!=null){
////                if(t1!=null){
////                  val yaw_time = Math.abs(req_time - t1)
////                  if(yaw_time <= 5 * 60 * 1000) json.put("yaw_time",yaw_time)
////                  else json.put("yaw_time","0")
////                  t1 = json.getLong("t1")
////                }
////                else{
////                  json.put("yaw_time","0")
////                  t1 = json.getLong("t1")
////                }
////              }
////              else{
////                json.put("yaw_time","0")
////                t1 = json.getLong("t1")
////              }
////            }
////          }
////          list += json
////        }
////
////        list
////      })
////      .persist()
////    logger.error(">>>计算tracks2后日志量：" + tracks2Rdd.count())
////    tracks2LogRdd1.unpersist()
////    tracks2LogRdd2.unpersist()
////
////    logger.error(">>>tracks2数据保存")
////    table = "gis_navi_eta_result2_tracks2"
////    structs = Array("id","navi_id","req_time","navi_endtime","links2","tracks2","navi_distance","t1","yaw_time")
////    keys = Array("id","navi_id","req_time","navi_endtime","links2","tracks2","navi_distance","t1","yaw_time")
////    NaviMain.mutiDayRddToHive(spark,tracks2Rdd,table,structs,keys,dateList)
////
////
////
////    logger.error(">>>开始处理相似度")
////    sql1=
////      s"""
////         |select a.id,a.polyline,b.tracks2,a.inc_date from
////         |(select id,polyline,inc_day as inc_date from dm_gis.gis_navi_eta_result2_base where inc_day between '$startDate' and '$endDate') a
////         |left join (select id,tracks2 from dm_gis.gis_navi_eta_result2_tracks2 where inc_day between '$startDate' and '$endDate') b on a.id=b.id
////       """.stripMargin
////
////    val similarityLogRdd = NaviLogParse.getValidJson(spark,sql1)
////
////    val similarityRdd = similarityLogRdd
////      .map(json=>{
////        if(json!=null){
////          val polyline_new = json.getJSONArray("polyline")
////          val tracks2_new = json.getJSONArray("tracks2")
////
////          if(true){//"0".equalsIgnoreCase(req_status)
////            if(polyline_new!=null && polyline_new.size()>0 && tracks2_new!=null && tracks2_new.size()>0){
////
////              val polyline_new2 = new JSONArray()
////              for(i<-0.until(polyline_new.size())){
////                val track = polyline_new.getJSONArray(i)
////                if(track!=null){
////                  val x = track.getDouble(0)
////                  val y = track.getDouble(1)
////                  if(x!=null && y!=null){
////                    val newJson = new JSONObject()
////                    newJson.put("x",x)
////                    newJson.put("y",y)
////                    newJson.put("type",1)
////                    polyline_new2.add(newJson)
////                  }
////                }
////              }
////
////              val tracks2_new2 = new JSONArray()
////              for(i<-0.until(tracks2_new.size())){
////                val track = tracks2_new.getJSONArray(i)
////                if(track!=null){
////                  val x = track.getDouble(0)
////                  val y = track.getDouble(1)
////                  if(x!=null && y!=null){
////                    val newJson = new JSONObject()
////                    newJson.put("x",x)
////                    newJson.put("y",y)
////                    newJson.put("type",1)
////                    tracks2_new2.add(newJson)
////                  }
////                }
////              }
////
////              val resultObject = accessCompareUrl(json,polyline_new2,tracks2_new2)
////              if(resultObject!=null){
////                val resultObject2 = resultObject.getJSONObject("result")
////                if(resultObject2!=null){
////                  val similarity1 =  resultObject2.getDouble("similarity1")
////                  val similarity2 = resultObject2.getDouble("similarity2")
////                  json.put("similarity1",similarity1)
////                  json.put("similarity5",similarity2)
////                }
////              }
////            }
////          }
////        }
////
////        json
////      })
////      .persist()
////    logger.error(">>>计算相似度后日志量：" + similarityRdd.count())
////    similarityLogRdd.unpersist()
////
////    logger.error(">>>相似度数据保存")
////    table = "gis_navi_eta_result2_similarity"
////    structs = Array("id","similarity1","similarity5")
////    keys = Array("id","similarity1","similarity5")
////    NaviMain.mutiDayRddToHive(spark,similarityRdd,table,structs,keys,dateList)
////
////
////    (null,dateList)
////  }
//
//
//
//  /**
//    * 获取ETA结果汇总2
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getEtaResult2Rdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      //      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
//      //      dateList = DateUtil.getTwoDatesStr(startDate,runDate)
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的ETA结果汇总")
//    var sql = ""
//    var sql2 = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.starttime_type,a.routeid,a.request_id,a.req_time,a.req_type,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.swid,a.starts,a.polyline,a.gd_polyline,a.links,a.x1,a.y1,a.x2,a.y2,a.navi_endtime2,b.navi_endtime,a.inc_day,a.inc_date from
//           |(select task_id,navi_id,navi_starttime,starttime_type,routeid,request_id,req_time,'top3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,starts,polyline,gd_polyline,links,x1,y1,x2,y2,'' as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' union all
//           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'yaw' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,swid,starts,polyline,'' as gd_polyline,links,x1,y1,x2,y2,'' as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_yaw_route where inc_day='$runDate' and hasyaw='true' union all
//           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'gdtop3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,'' as starts,polyline,'' as gd_polyline,'' as links,x1,y1,x2,y2,navi_endtime as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_gd_route_eta where inc_day='$runDate') a
//           |left join (select navi_id,max(navi_endtime) as navi_endtime from dm_gis.gis_navi_finish_monitor where inc_day='$runDate' group by navi_id) b on a.navi_id=b.navi_id
//       """.stripMargin
//
//      sql2 =
//        s"""
//           |select navi_id,tracks1,tracks2 from dm_gis.gis_navi_rectify_result where inc_day='$runDate'
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
//      val endDate = runDate
//      val endDate1 = DateUtil.getDateStr(runDate,1)
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.starttime_type,a.routeid,a.request_id,a.req_time,a.req_type,a.src_province,a.src_citycode,a.src_deptcode,a.dest_province,a.dest_citycode,a.dest_deptcode,a.swid,a.starts,a.polyline,a.gd_polyline,a.links,a.x1,a.y1,a.x2,a.y2,a.navi_endtime2,b.navi_endtime,a.inc_day,a.inc_date from
//           |(select task_id,navi_id,navi_starttime,starttime_type,routeid,request_id,req_time,'top3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,starts,polyline,gd_polyline,links,x1,y1,x2,y2,'' as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_top3_click_route where inc_day between '$startDate' and '$endDate' union all
//           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'yaw' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,swid,starts,polyline,'' as gd_polyline,links,x1,y1,x2,y2,'' as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_yaw_route where inc_day between '$startDate' and '$endDate' and hasyaw='true' union all
//           |select task_id,navi_id,navi_starttime,'' as starttime_type,routeid,request_id,req_time,'gdtop3' as req_type,src_province,src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,'' as swid,'' as starts,polyline,'' as gd_polyline,'' as links,x1,y1,x2,y2,navi_endtime as navi_endtime2,inc_day,inc_day as inc_date from dm_gis.gis_navi_gd_route_eta where inc_day between '$startDate' and '$endDate') a
//           |left join (select navi_id,max(navi_endtime) as navi_endtime from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate1' group by navi_id) b on a.navi_id=b.navi_id
//       """.stripMargin
//
//      sql2=
//        s"""
//           |select navi_id,tracks1,tracks2 from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1'
//       """.stripMargin
//    }
//
//    val rdd1 = NaviLogParse.getValidJson(spark,sql)
//    val rdd2 = NaviLogParse.getValidJson(spark,sql2)
//
//    val resultRdd1 = rdd1.filter(json => !"0be66d610d0490ae0ab70ad1d940cf191".equalsIgnoreCase(json.getString("nava_id"))
//    && !"27feba4b90f68ff3e7e6a8af9808b4661".equalsIgnoreCase(json.getString("nava_id"))
//    && !"b03d83ec5110b93b153e1509ee13d6420".equalsIgnoreCase(json.getString("nava_id")))
//      .map(json=>{
//        var navi_id = json.getString("navi_id")
//        var request_id = json.getString("request_id")
//        var req_time = json.getLong("req_time")
//        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
//        if(StringUtils.isEmpty(request_id)) request_id = "-"
//        if(req_time==null) req_time = Long.MaxValue
//
//        val id = navi_id + "_" + request_id + "_" + req_time.toString
//        json.put("id",id)
//
//        if("gdtop3".equalsIgnoreCase(json.getString("req_type"))){
//          var navi_endtime2 = json.getString("navi_endtime2")
//          if(StringUtils.isEmpty(navi_endtime2)) navi_endtime2 = ""
//          json.put("navi_endtime",navi_endtime2)
//        }
//
//        (id,json)
//      })
//      .groupByKey()
//      .map(obj=>{
//        val json = obj._2.toList.head
//        json
//      })
//      .map(json=>{
//        var navi_id = json.getString("navi_id")
//
//        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
//
//        val polyline = json.getString("polyline")
//        var polyline_array:JSONArray = null
//        if(!StringUtils.isEmpty(polyline)) polyline_array = JSON.parseArray(polyline)
//        val polyline_new = new JSONArray()
//        json.remove("polyline")
//        if(polyline_array!=null && polyline_array.size()>0){
//          for(j<-0.until(polyline_array.size())){
//            val track = polyline_array.getJSONObject(j)
//            val tmp = new JSONArray()
//            if(track!=null){
//              val x = track.getDouble("x")
//              val y = track.getDouble("y")
//              if(x!=null && y!=null){
//                tmp.add(x)
//                tmp.add(y)
//                polyline_new.add(tmp)
//              }
//            }
//          }
//          json.put("polyline", polyline_new)
//        }
//
//        val gd_polyline = json.getString("gd_polyline")
//        var gd_polyline_array:JSONArray = null
//        if(!StringUtils.isEmpty(gd_polyline)) gd_polyline_array = JSON.parseArray(gd_polyline)
//        val gd_polyline_new = new JSONArray()
//        json.remove("gd_polyline")
//        if(gd_polyline_array!=null && gd_polyline_array.size()>0){
//          for(j<-0.until(gd_polyline_array.size())){
//            val track = gd_polyline_array.getJSONObject(j)
//            val tmp = new JSONArray()
//            if(track!=null){
//              val x = track.getDouble("x")
//              val y = track.getDouble("y")
//              if(x!=null && y!=null){
//                tmp.add(x)
//                tmp.add(y)
//                gd_polyline_new.add(tmp)
//              }
//            }
//          }
//          json.put("gd_polyline", gd_polyline_new)
//        }
//
//        (navi_id,json)
//      })
//      .groupByKey()
//
//    val resultRdd2 = rdd2
//      .map(json=>{
//        var navi_id = json.getString("navi_id")
//        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
//
//        (navi_id,json)
//      })
//      .groupByKey()
//      .map(obj=>{
//        val json = obj._2.head
//        val navi_id = obj._1
//
//        (navi_id,json)
//      })
//
//    val computeRdd1 = resultRdd1.leftOuterJoin(resultRdd2)
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//
//        val jsonList: List[JSONObject] = obj._2._1.toList
//        var targetJson:JSONObject = null
//        if(obj._2._2.nonEmpty){
//          targetJson = obj._2._2.get
//        }
//        var tracks1:JSONArray = null
//        var tracks2:JSONArray = null
//        if(targetJson != null){
//          tracks1 = targetJson.getJSONArray("tracks1")
//          tracks2 = targetJson.getJSONArray("tracks2")
//          targetJson.remove("tracks1")
//          targetJson.remove("tracks2")
//        }
//
//        for(i <- jsonList.indices){
//          val json = jsonList(i)
//
//          val req_time = json.getLong("req_time")
//          val navi_endtime = json.getLong("navi_endtime")
//
//          val tracks1_new = new JSONArray()
//          if(tracks1!=null && tracks1.size()>0 && req_time!=null && navi_endtime!=null){
//            var diff_min1 = Long.MaxValue
//            var diff_min2 = Long.MaxValue
//            var index1 = -1
//            var index2 = -1
//            breakable(
//              for(j<-0.until(tracks1.size())){
//                val track = tracks1.getJSONObject(j)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(req_time - tm * 1000)
//                    if(diff <= diff_min1) {
//                      diff_min1 = diff
//                      index1 = j
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            breakable(
//              for(j<-0.until(tracks1.size())){
//                val track = tracks1.getJSONObject(tracks1.size() - j - 1)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(navi_endtime - tm * 1000)
//                    if(diff <= diff_min2) {
//                      diff_min2 = diff
//                      index2 = tracks1.size() - j - 1
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            if(index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks1.size()){
//              for(j<-index1.until(index2 + 1)){
//                val track = tracks1.getJSONObject(j)
//                val tmp = new JSONArray()
//                if(track!=null){
//                  val x = track.getDouble("x")
//                  val y = track.getDouble("y")
//                  if(x!=null && y!=null){
//                    tmp.add(x)
//                    tmp.add(y)
//                    tracks1_new.add(tmp)
//                  }
//                }
//              }
//            }
//            if(tracks1_new.size() > 0) json.put("tracks1", tracks1_new)
//          }
//
//          var navi_distance:java.lang.Double = null
//          val tracks2_new = new JSONArray()
//          if(tracks2!=null && tracks2.size()>0 && req_time!=null && navi_endtime!=null){
//            var diff_min1 = Long.MaxValue
//            var diff_min2 = Long.MaxValue
//            var index1 = -1
//            var index2 = -1
//            breakable(
//              for(j<-0.until(tracks2.size())){
//                val track = tracks2.getJSONObject(j)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(req_time - tm * 1000)
//                    if(diff <= diff_min1) {
//                      diff_min1 = diff
//                      index1 = j
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            breakable(
//              for(j<-0.until(tracks2.size())){
//                val track = tracks2.getJSONObject(tracks2.size() - j - 1)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(navi_endtime - tm * 1000)
//                    if(diff <= diff_min2) {
//                      diff_min2 = diff
//                      index2 = tracks2.size() - j - 1
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            val x1 = json.getDouble("x1")
//            val y1 = json.getDouble("y1")
//            if(index1 != -1 && index1 < tracks2.size() && x1 != null && y1 != null){
//              val track1 = tracks2.getJSONObject(index1)
//              if(track1!=null){
//                val x = track1.getDouble("x")
//                val y = track1.getDouble("y")
//                if(x!=null && y!=null){
//                  val trackstart_distance = MapApiUtil.getGreatCircleDistance(x,y,x1,y1)
//                  json.put("trackstart_distance", trackstart_distance)
//                }
//              }
//            }
//
//            val x2 = json.getDouble("x2")
//            val y2 = json.getDouble("y2")
//            if(index2 != -1 && index2 < tracks2.size() && x2 != null && y2 != null){
//              val track2 = tracks2.getJSONObject(index2)
//              if(track2!=null){
//                val x = track2.getDouble("x")
//                val y = track2.getDouble("y")
//                if(x!=null && y!=null){
//                  val trackend_distance = MapApiUtil.getGreatCircleDistance(x,y,x2,y2)
//                  json.put("trackend_distance", trackend_distance)
//                }
//              }
//            }
//
//            if(index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks2.size()){
//              val track1 = tracks2.getJSONObject(index1)
//              val track2 = tracks2.getJSONObject(index2)
//              if(track1!=null && track2!=null){
//                val sum_dist1 = track1.getDouble("sum_dist")
//                val sum_dist2 = track2.getDouble("sum_dist")
//                if(sum_dist1!=null && sum_dist2!=null){
//                  navi_distance = sum_dist2 - sum_dist1
//                }
//              }
//              var swid = ""
//              var links2 = new JSONArray()
//              val req_type = json.getString("req_type")
//              var type_flag = false
//              if("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)) type_flag = true
//
//              for(j<-index1.until(index2 + 1)){
//                val track = tracks2.getJSONObject(j)
//                val tmp = new JSONArray()
//                if(track!=null){
//                  val x = track.getDouble("x")
//                  val y = track.getDouble("y")
//                  if(x!=null && y!=null){
//                    tmp.add(x)
//                    tmp.add(y)
//                    tracks2_new.add(tmp)
//                  }
//                }
//
//                if(type_flag){
//                  val _swid = track.getString("swid")
//                  if(!swid.equalsIgnoreCase(_swid) && !StringUtils.isEmpty(_swid)){
//                    swid = _swid
//                    val tmpTrack = new JSONObject()
//                    tmpTrack.put("swid",swid)
//                    val tm = track.getString("tm")
//                    if(!StringUtils.isEmpty(tm)) tmpTrack.put("tm",tm + "000")
//                    links2.add(tmpTrack)
//                  }
//                }
//              }
//
//              if(type_flag){
//                if(links2.size() > 0){
//                  json.put("links2", links2)
//                  if(json.containsKey("links") && !StringUtils.isEmpty(json.getString("links"))){
//                    val links = json.getString("links").split(",")
//                    val size1 = links.size
//                    val size2 = links2.size()
//                    var size = 0
//                    if(size1 > size2) size = size2
//                    else size = size1
//                    breakable(
//                      for(m<-0.until(size)){
//                        val link = links(m)
//                        val link2 = links2.getJSONObject(m)
//                        if(link2!=null){
//                          val swid = link2.getString("swid")
//                          if(!StringUtils.isEmpty(link)){
//                            if(!link.equalsIgnoreCase(swid)){
//                              val tm = link2.getString("tm")
//                              json.put("t1", tm)
//                              break
//                            }
//                          }
//                          else if(!StringUtils.isEmpty(swid)){
//                            val tm = link2.getString("tm")
//                            json.put("t1", tm)
//                            break
//                          }
//                        }
//                        else if(!StringUtils.isEmpty(link)) {
//                          json.put("t1", "0")
//                          break
//                        }
//                      }
//                    )
//                  }
//                  else json.put("t1", "0")
//                }
//                else json.put("t1", "0")
//              }
//
//            }
//            if(tracks2_new.size() > 0) json.put("tracks2", tracks2_new)
//          }
//
//          if(navi_distance!=null) json.put("navi_distance",navi_distance)
//
//
//          list += json
//        }
//
//        list
//      })
//      .persist()
//    logger.error(">>>计算相似度后日志量：" + computeRdd1.count())
//    rdd1.unpersist()
//    rdd2.unpersist()
//
//    val computeRdd2 = computeRdd1
//      .map(json=>{
//      if(json!=null){
//        val tracks2_new = json.getJSONArray("tracks2")
//        val polyline_new = json.getJSONArray("polyline")
//        val gd_polyline_new = json.getJSONArray("gd_polyline")
//
//        if(true){//"0".equalsIgnoreCase(req_status)
//          if(polyline_new!=null && polyline_new.size()>0 && tracks2_new!=null && tracks2_new.size()>0){
//
//            val polyline_new2 = new JSONArray()
//            for(i<-0.until(polyline_new.size())){
//              val track = polyline_new.getJSONArray(i)
//              if(track!=null){
//                val x = track.getDouble(0)
//                val y = track.getDouble(1)
//                if(x!=null && y!=null){
//                  val newJson = new JSONObject()
//                  newJson.put("x",x)
//                  newJson.put("y",y)
//                  newJson.put("type",1)
//                  polyline_new2.add(newJson)
//                }
//              }
//            }
//
//            val tracks2_new2 = new JSONArray()
//            for(i<-0.until(tracks2_new.size())){
//              val track = tracks2_new.getJSONArray(i)
//              if(track!=null){
//                val x = track.getDouble(0)
//                val y = track.getDouble(1)
//                if(x!=null && y!=null){
//                  val newJson = new JSONObject()
//                  newJson.put("x",x)
//                  newJson.put("y",y)
//                  newJson.put("type",1)
//                  tracks2_new2.add(newJson)
//                }
//              }
//            }
//
//            val resultObject = accessCompareUrl(json,polyline_new2,tracks2_new2)
//            if(resultObject!=null){
//              val resultObject2 = resultObject.getJSONObject("result")
//              if(resultObject2!=null){
//                val similarity1 =  resultObject2.getDouble("similarity1")
//                val similarity2 = resultObject2.getDouble("similarity2")
//                json.put("similarity1",similarity1)
//                json.put("similarity5",similarity2)
//              }
//            }
//
//          }
//
//          if(gd_polyline_new!=null && gd_polyline_new.size()>0 && tracks2_new!=null && tracks2_new.size()>0){
//
//            val gd_polyline_new2 = new JSONArray()
//            for(i<-0.until(gd_polyline_new.size())){
//              val track = gd_polyline_new.getJSONArray(i)
//              if(track!=null){
//                val x = track.getDouble(0)
//                val y = track.getDouble(1)
//                if(x!=null && y!=null){
//                  val newJson = new JSONObject()
//                  newJson.put("x",x)
//                  newJson.put("y",y)
//                  newJson.put("type",1)
//                  gd_polyline_new2.add(newJson)
//                }
//              }
//            }
//
//            val tracks2_new2 = new JSONArray()
//            for(i<-0.until(tracks2_new.size())){
//              val track = tracks2_new.getJSONArray(i)
//              if(track!=null){
//                val x = track.getDouble(0)
//                val y = track.getDouble(1)
//                if(x!=null && y!=null){
//                  val newJson = new JSONObject()
//                  newJson.put("x",x)
//                  newJson.put("y",y)
//                  newJson.put("type",1)
//                  tracks2_new2.add(newJson)
//                }
//              }
//            }
//
//            val resultObject = accessCompareUrl(json,gd_polyline_new2,tracks2_new2)
//            if(resultObject!=null){
//              val resultObject2 = resultObject.getJSONObject("result")
//              if(resultObject2!=null){
//                val similarity1 =  resultObject2.getDouble("similarity1")
//                val similarity2 = resultObject2.getDouble("similarity2")
//                json.put("gdsimilarity1",similarity1)
//                json.put("gdsimilarity5",similarity2)
//              }
//            }
//
//          }
//        }
//      }
//
//      json
//    })
//      .persist()
//    logger.error(">>>计算相似度后日志量：" + computeRdd2.count())
//    computeRdd1.unpersist()
//
//    val resultRdd = computeRdd2
//      .map(json=>{
//        val task_id = json.getString("task_id")
//        val navi_id = json.getString("navi_id")
//        var req_time = json.getLong("req_time")
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        ((task_id,navi_id),(req_time,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//        val key = obj._1
//        val jsonList = obj._2.toList.sortBy(_._1).map(_._2)
//
//        var t1:java.lang.Long = null
//        for(i<-jsonList.indices){
//          val json = jsonList(i)
//          if(json!=null){
//            val req_type = json.getString("req_type")
//            if("top3".equalsIgnoreCase(req_type) || "yaw".equalsIgnoreCase(req_type)){
//              val req_time = json.getLong("req_time")
//              if(req_time!=null){
//                if(t1!=null){
//                  val yaw_time = Math.abs(req_time - t1)
//                  if(yaw_time <= 5 * 60 * 1000) json.put("yaw_time",yaw_time)
//                  else json.put("yaw_time","0")
//                  t1 = json.getLong("t1")
//                }
//                else{
//                  json.put("yaw_time","0")
//                  t1 = json.getLong("t1")
//                }
//              }
//              else{
//                json.put("yaw_time","0")
//                t1 = json.getLong("t1")
//              }
//            }
//            list += json
//          }
//        }
//
//        list
//      })
//
//      .persist()
//    logger.error(">>>计算后日志量：" + resultRdd.count())
//    computeRdd2.unpersist()
//
//    (resultRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取请求路线记录关联信息
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getPnsRouteUnionRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      //      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
//      //      dateList = DateUtil.getTwoDatesStr(startDate,runDate)
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的请求路线记录关联信息")
//    var sql = ""
//    var sql2 = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
//        s"""
//           |select a.pns_logtype,a.request_id,a.req_time,a.no,a.origin,a.destination,a.route_index,a.route_id,a.distance,a.polyline,a.links,a.strategy,a.src,a.status,b.navi_id,c.navi_endtime,a.inc_date from
//           |(select pns_logtype,request_id,req_time,no,origin,destination,route_index,route_id,distance,polyline,links,strategy,src,status,inc_day as inc_date from dm_gis.gis_navi_pns_route where inc_day='$runDate') a
//           |left join (select navi_id,request_id from dm_gis.gis_navi_top3_parse where inc_day='$runDate') b on a.request_id=b.request_id
//           |left join (select navi_id,max(report_time) as navi_endtime from dm_gis.gis_navi_sdk_navi_parse where type='3' and inc_day='$runDate' group by navi_id) c on b.navi_id=c.navi_id
//       """.stripMargin
//
//      sql2 =
//        s"""
//           |select navi_id,tracks2 from dm_gis.gis_navi_rectify_result where inc_day='$runDate'
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = runDate//DateUtil.getDateStr(runDate,-1)//2
//      val endDate = runDate
//      val endDate1 = DateUtil.getDateStr(runDate,1)
//      sql=
//        s"""
//           |select a.pns_logtype,a.request_id,a.req_time,a.no,a.origin,a.destination,a.route_index,a.route_id,a.distance,a.polyline,a.links,a.strategy,a.src,a.status,b.navi_id,c.navi_endtime,a.inc_date from
//           |(select pns_logtype,request_id,req_time,no,origin,destination,route_index,route_id,distance,polyline,links,strategy,src,status,inc_day as inc_date from dm_gis.gis_navi_pns_route where inc_day between '$startDate' and '$endDate') a
//           |left join (select navi_id,request_id from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') b on a.request_id=b.request_id
//           |left join (select navi_id,max(report_time) as navi_endtime from dm_gis.gis_navi_sdk_navi_parse where type='3' and inc_day between '$startDate' and '$endDate1' group by navi_id) c on b.navi_id=c.navi_id
//       """.stripMargin
//
//      sql2=
//        s"""
//           |select navi_id,tracks2 from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1'
//       """.stripMargin
//    }
//
//    val rdd1 = NaviLogParse.getValidJson(spark,sql)
//    val rdd2 = NaviLogParse.getValidJson(spark,sql2)
//
//    val resultRdd1 = rdd1.filter(json => !"0be66d610d0490ae0ab70ad1d940cf191".equalsIgnoreCase(json.getString("nava_id"))
//      && !"27feba4b90f68ff3e7e6a8af9808b4661".equalsIgnoreCase(json.getString("nava_id"))
//      && !"b03d83ec5110b93b153e1509ee13d6420".equalsIgnoreCase(json.getString("nava_id")))
////      .map(json=>{
////        var navi_id = json.getString("navi_id")
////        var request_id = json.getString("request_id")
////        var req_time = json.getLong("req_time")
////        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
////        if(StringUtils.isEmpty(request_id)) request_id = "-"
////        if(req_time==null) req_time = Long.MaxValue
////
////        val id = navi_id + "_" + request_id + "_" + req_time.toString
////        json.put("id",id)
////        (id,json)
////      })
////      .groupByKey()
////      .map(obj=>{
////        val json = obj._2.toList.head
////        json
////      })
//      .map(json=>{
//        var navi_id = json.getString("navi_id")
//
//        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
//
//        val polyline = json.getString("polyline")
//        var polyline_array:JSONArray = null
//        if(!StringUtils.isEmpty(polyline)) polyline_array = JSON.parseArray(polyline)
//        val polyline_new = new JSONArray()
//        json.remove("polyline")
//        if(polyline_array!=null && polyline_array.size()>0){
//          for(j<-0.until(polyline_array.size())){
//            val track = polyline_array.getJSONObject(j)
//            val tmp = new JSONArray()
//            if(track!=null){
//              val x = track.getDouble("x")
//              val y = track.getDouble("y")
//              if(x!=null && y!=null){
//                tmp.add(x)
//                tmp.add(y)
//                polyline_new.add(tmp)
//              }
//            }
//          }
//          json.put("polyline", polyline_new)
//        }
//
//        (navi_id,json)
//      })
//      .groupByKey()
//
//    val resultRdd2 = rdd2
//      .map(json=>{
//        var navi_id = json.getString("navi_id")
//        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
//
//        (navi_id,json)
//      })
//      .groupByKey()
//      .map(obj=>{
//        val json = obj._2.head
//        val navi_id = obj._1
//
//        (navi_id,json)
//      })
//
//    val computeRdd1 = resultRdd1.leftOuterJoin(resultRdd2)
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//
//        val jsonList: List[JSONObject] = obj._2._1.toList
//        var targetJson:JSONObject = null
//        if(obj._2._2.nonEmpty){
//          targetJson = obj._2._2.get
//        }
//        var tracks2:JSONArray = null
//        if(targetJson != null){
//          tracks2 = targetJson.getJSONArray("tracks2")
//          targetJson.remove("tracks2")
//        }
//
//        for(i <- jsonList.indices){
//          val json = jsonList(i)
//
//          val req_time = json.getLong("req_time")
//          val navi_endtime = json.getLong("navi_endtime")
//
//          val tracks2_new = new JSONArray()
//          if(tracks2!=null && tracks2.size()>0 && req_time!=null && navi_endtime!=null){
//            var diff_min1 = Long.MaxValue
//            var diff_min2 = Long.MaxValue
//            var index1 = -1
//            var index2 = -1
//            breakable(
//              for(j<-0.until(tracks2.size())){
//                val track = tracks2.getJSONObject(j)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(req_time - tm * 1000)
//                    if(diff <= diff_min1) {
//                      diff_min1 = diff
//                      index1 = j
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            breakable(
//              for(j<-0.until(tracks2.size())){
//                val track = tracks2.getJSONObject(tracks2.size() - j - 1)
//                if(track!=null){
//                  val tm = track.getLong("tm")
//                  if(tm!=null){
//                    val diff = Math.abs(navi_endtime - tm * 1000)
//                    if(diff <= diff_min2) {
//                      diff_min2 = diff
//                      index2 = tracks2.size() - j - 1
//                    }
//                    else break
//                  }
//                }
//              }
//            )
//
//            if(index1 != -1 && index2 != -1 && index2 >= index1 && index2 < tracks2.size()){
//              for(j<-index1.until(index2 + 1)){
//                val track = tracks2.getJSONObject(j)
//                val tmp = new JSONArray()
//                if(track!=null){
//                  val x = track.getDouble("x")
//                  val y = track.getDouble("y")
//                  if(x!=null && y!=null){
//                    tmp.add(x)
//                    tmp.add(y)
//                    tracks2_new.add(tmp)
//                  }
//                }
//              }
//            }
//            if(tracks2_new.size() > 0) json.put("tracks2", tracks2_new)
//          }
//
//
//          list += json
//        }
//
//        list
//      })
//      .persist()
//    logger.error(">>>计算相似度后日志量：" + computeRdd1.count())
//    rdd1.unpersist()
//    rdd2.unpersist()
//
//    val computeRdd2 = computeRdd1
//      .map(json=>{
//        if(json!=null){
//          val tracks2_new = json.getJSONArray("tracks2")
//          val polyline_new = json.getJSONArray("polyline")
//
//          if(true){//"0".equalsIgnoreCase(req_status)
//            if(polyline_new!=null && polyline_new.size()>0 && tracks2_new!=null && tracks2_new.size()>0){
//
//              val polyline_new2 = new JSONArray()
//              for(i<-0.until(polyline_new.size())){
//                val track = polyline_new.getJSONArray(i)
//                if(track!=null){
//                  val x = track.getDouble(0)
//                  val y = track.getDouble(1)
//                  if(x!=null && y!=null){
//                    val newJson = new JSONObject()
//                    newJson.put("x",x)
//                    newJson.put("y",y)
//                    newJson.put("type",1)
//                    polyline_new2.add(newJson)
//                  }
//                }
//              }
//
//              val tracks2_new2 = new JSONArray()
//              for(i<-0.until(tracks2_new.size())){
//                val track = tracks2_new.getJSONArray(i)
//                if(track!=null){
//                  val x = track.getDouble(0)
//                  val y = track.getDouble(1)
//                  if(x!=null && y!=null){
//                    val newJson = new JSONObject()
//                    newJson.put("x",x)
//                    newJson.put("y",y)
//                    newJson.put("type",1)
//                    tracks2_new2.add(newJson)
//                  }
//                }
//              }
//
//              val resultObject = accessCompareUrl(json,polyline_new2,tracks2_new2)
//              if(resultObject!=null){
//                val resultObject2 = resultObject.getJSONObject("result")
//                if(resultObject2!=null){
//                  val similarity1 =  resultObject2.getDouble("similarity1")
//                  val similarity2 = resultObject2.getDouble("similarity2")
//                  json.put("similarity1",similarity1)
//                  json.put("similarity5",similarity2)
//                }
//              }
//
//            }
//
//          }
//        }
//
//        json
//      })
//      .persist()
//    logger.error(">>>计算相似度后日志量：" + computeRdd2.count())
//    computeRdd1.unpersist()
//
//    (computeRdd2,dateList)
//  }
//
//
//
//  /**
//    * 生成回溯报表
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getRecallRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的回溯报表结果")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-3)
//      val endDate = runDate
//      sql=
//        s"""
//           |select a.id,a.reqid,a.navi_id,a.routeid,a.request_id,a.status,a.req_order,a.req_count,a.starttime,a.vehicle,a.vehicle_type,a.passport,a.weight,a.loadweight,a.length,a.width,a.height,a.axle_number,a.axle_weight,a.vehicle_color,a.energy,a.emit_stand,a.distance,a.reqtime,a.x1,a.y1,a.x2,a.y2,a.ft_time,a.ft_status,a.ft_dist,a.ft_highway,a.ft_tralightcount,a.ft_tolls,a.ft_tollsdistance,a.ft_url,a.ft_flen,a.ft_tlen,a.endtime,a.rdynsdlen,a.rdynsdcnt,a.driver_id,a.opt,a.routeid_input,a.routeid_output,a.tl_endtime,b.dest_province,b.dest_citycode,b.dest_deptcode,b.src_province,b.src_citycode,b.src_deptcode,b.ft_coords,b.similarity1,b.similarity5,b.tracks2,c.line_code,a.inc_day,a.inc_day as inc_date from
//           |(select id,task_id as reqid,navi_id,routeid,request_id,req_status as status,req_order,req_count,navi_starttime as starttime,vehicle,vehicle_type,passport,weight,mload as loadweight,length,width,height,axle_number,axle_weight,plate_color as vehicle_color,energy,emit_stand,distance,req_time as reqtime,x1,y1,x2,y2,duration as ft_time,pns_status as ft_status,distance as ft_dist,highspeed_distance as ft_highway,trafficlight_count as ft_tralightcount,tolls as ft_tolls,toll_distance as ft_tollsdistance,ft_url,flen as ft_flen,tlen as ft_tlen,navi_endtime as endtime,rdynsdlen,rdynsdcnt,driver_id,opt,routeid_in as routeid_input,routeid_out as routeid_output,tl_times as tl_endtime,inc_day from dm_gis.gis_navi_eta_result1 where inc_day='$runDate') a
//           |left join (select id,dest_province,dest_citycode,dest_deptcode,src_province,src_citycode,src_deptcode,polyline as ft_coords,similarity1,similarity5,tracks2 from dm_gis.gis_navi_eta_result2 where inc_day='$runDate') b on a.id=b.id
//           |left join (select task_id,line_code from dm_grd.grd_new_task_detail where inc_day between '$startDate' and '$endDate') c on a.reqid=c.task_id
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-3)
//      val endDate = runDate
//      sql=
//        s"""
//           |select a.id,a.reqid,a.navi_id,a.routeid,a.request_id,a.status,a.req_order,a.req_count,a.starttime,a.vehicle,a.vehicle_type,a.passport,a.weight,a.loadweight,a.length,a.width,a.height,a.axle_number,a.axle_weight,a.vehicle_color,a.energy,a.emit_stand,a.distance,a.reqtime,a.x1,a.y1,a.x2,a.y2,a.ft_time,a.ft_status,a.ft_dist,a.ft_highway,a.ft_tralightcount,a.ft_tolls,a.ft_tollsdistance,a.ft_url,a.ft_flen,a.ft_tlen,a.endtime,a.rdynsdlen,a.rdynsdcnt,a.driver_id,a.opt,a.routeid_input,a.routeid_output,a.tl_endtime,b.dest_province,b.dest_citycode,b.dest_deptcode,b.src_province,b.src_citycode,b.src_deptcode,b.ft_coords,b.similarity1,b.similarity5,b.tracks2,c.line_code,a.inc_day,a.inc_day as inc_date from
//           |(select id,task_id as reqid,navi_id,routeid,request_id,req_status as status,req_order,req_count,navi_starttime as starttime,vehicle,vehicle_type,passport,weight,mload as loadweight,length,width,height,axle_number,axle_weight,plate_color as vehicle_color,energy,emit_stand,distance,req_time as reqtime,x1,y1,x2,y2,duration as ft_time,pns_status as ft_status,distance as ft_dist,highspeed_distance as ft_highway,trafficlight_count as ft_tralightcount,tolls as ft_tolls,toll_distance as ft_tollsdistance,ft_url,flen as ft_flen,tlen as ft_tlen,navi_endtime as endtime,rdynsdlen,rdynsdcnt,driver_id,opt,routeid_in as routeid_input,routeid_out as routeid_output,tl_times as tl_endtime,inc_day from dm_gis.gis_navi_eta_result1 where inc_day='$runDate') a
//           |left join (select id,dest_province,dest_citycode,dest_deptcode,src_province,src_citycode,src_deptcode,polyline as ft_coords,similarity1,similarity5,tracks2 from dm_gis.gis_navi_eta_result2 where inc_day='$runDate') b on a.id=b.id
//           |left join (select task_id,line_code from dm_grd.grd_new_task_detail where inc_day between '$startDate' and '$endDate') c on a.reqid=c.task_id
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//    val computeRdd = resultRdd
//      .map(json=>{
//        if(json!=null){
//          try{
//            val starttime = json.getLong("starttime")
//            if(starttime!=null){
//              val start_time = longToTime(starttime)
//              json.put("start_time",start_time)
//            }
//
//            val reqtime = json.getLong("reqtime")
//            if(reqtime!=null){
//              val req_time = longToTime(reqtime)
//              json.put("req_time",req_time)
//            }
//
//            val endtime = json.getLong("endtime")
//            if(endtime!=null){
//              val end_time = longToTime(endtime)
//              json.put("end_time",end_time)
//            }
//
//            if(endtime!=null && starttime!=null){
//              val actual_time_diff = endtime - starttime
//              json.put("actual_time_diff",actual_time_diff)
//            }
//          }
//          catch {
//            case e:Exception =>logger.error(">>>日志转json失败："+e)
//          }
//        }
//
//        val task_id = json.getString("task_id")
//        val navi_id = json.getString("navi_id")
//        val routeid = json.getString("routeid")
//        val req_order = json.getInteger("req_order")
//        ((task_id,navi_id,routeid),(req_order,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
//        if(jsonList.nonEmpty){
//          val firstJson = jsonList.head
//          var distance = ""
//          if(firstJson!=null) distance = firstJson.getString("ft_dist")
//
//          for(i <- jsonList.indices){
//            val json = jsonList(i)
//            json.put("distance",distance)
//            list += json
//          }
//        }
//        list
//      })
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取导航结果汇总
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getUnionResultRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      val startDate = DateUtil.getDateStr(runDate,-2)
//      dateList = DateUtil.getTwoDatesStr(startDate,runDate)
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的导航结果汇总")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.routeid,a.hasyaw,a.src_province,a.dest_province,a.src_citycode,a.dest_citycode,a.src_deptcode,a.dest_deptcode,a.navi_starttime,a.req_time,a.route_type,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.driver_id,a.route_src,a.ft_url,a.status,a.ak,a.polyline,a.start_speed,a.vehicle_dir1,a.rect_result,a.strategy,a.routetype,a.merge_result,a.starts,a.starttime_type,a.driver_type,a.is_econ,a.service_id,a.line_code,a.navi_type,b.sdk_version,b.start_type,c.navi_endstatus,c.navi_endtime,c.endx,c.endy,c.navi_endtype,d.navi_distance,a.inc_day,a.inc_day as inc_date from
//           |(select task_id,navi_id,routeid,'' as hasyaw,src_province,dest_province,src_citycode,dest_citycode,src_deptcode,dest_deptcode,navi_starttime,req_time,'top3' as route_type,x1,y1,x2,y2,vehicle,driver_id,src as route_src,ft_url,status,ak,polyline,start_speed,vehicle_dir1,rect_result,strategy2 as strategy,routetype,merge_result,starts,starttime_type,driver_type,is_econ,service_id,line_code,navi_type,inc_day from dm_gis.gis_navi_top3_click_route where inc_day='$runDate' union all
//           |select task_id,navi_id,routeid,hasyaw,src_province,dest_province,src_citycode,dest_citycode,src_deptcode,dest_deptcode,navi_starttime,req_time,'yaw' as route_type,x1,y1,x2,y2,vehicle,driver_id,src as route_src,ft_url,status,ak,polyline,'' as start_speed,'' as vehicle_dir1,rect_result,strategy2 as strategy,routetype,merge_result,starts,'' as starttime_type,'' as driver_type,is_econ,service_id,line_code,navi_type,inc_day from dm_gis.gis_navi_yaw_route where inc_day='$runDate') a
//           |left join (select navi_id,max(sdk_ver) as sdk_version,max(start_type) as start_type from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' group by navi_id) b on a.navi_id=b.navi_id
//           |left join (select navi_id,max(status) as navi_endstatus,max(navi_endtime) as navi_endtime,max(navi_endx) as endx,max(navi_endy) as endy,max(navi_endtype) as navi_endtype from dm_gis.gis_navi_finish_monitor where inc_day='$runDate' group by navi_id) c on a.navi_id=c.navi_id
//           |left join (select navi_id,len as navi_distance from dm_gis.gis_navi_rectify_result where inc_day='$runDate') d on a.navi_id=d.navi_id
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-2)
//      val endDate = runDate
//      val endDate1 = DateUtil.getDateStr(runDate,1)
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.routeid,a.hasyaw,a.src_province,a.dest_province,a.src_citycode,a.dest_citycode,a.src_deptcode,a.dest_deptcode,a.navi_starttime,a.req_time,a.route_type,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.driver_id,a.route_src,a.ft_url,a.status,a.ak,a.polyline,a.start_speed,a.vehicle_dir1,a.rect_result,a.strategy,a.routetype,a.merge_result,a.starts,a.starttime_type,a.driver_type,a.is_econ,a.service_id,a.line_code,a.navi_type,b.sdk_version,b.start_type,c.navi_endstatus,c.navi_endtime,c.endx,c.endy,c.navi_endtype,d.navi_distance,a.inc_day,a.inc_day as inc_date from
//           |(select task_id,navi_id,routeid,'' as hasyaw,src_province,dest_province,src_citycode,dest_citycode,src_deptcode,dest_deptcode,navi_starttime,req_time,'top3' as route_type,x1,y1,x2,y2,vehicle,driver_id,src as route_src,ft_url,status,ak,polyline,start_speed,vehicle_dir1,rect_result,strategy2 as strategy,routetype,merge_result,starts,starttime_type,driver_type,is_econ,service_id,line_code,navi_type,inc_day from dm_gis.gis_navi_top3_click_route where inc_day between '$startDate' and '$endDate' union all
//           |select task_id,navi_id,routeid,hasyaw,src_province,dest_province,src_citycode,dest_citycode,src_deptcode,dest_deptcode,navi_starttime,req_time,'yaw' as route_type,x1,y1,x2,y2,vehicle,driver_id,src as route_src,ft_url,status,ak,polyline,'' as start_speed,'' as vehicle_dir1,rect_result,strategy2 as strategy,routetype,merge_result,starts,'' as starttime_type,'' as driver_type,is_econ,service_id,line_code,navi_type,inc_day from dm_gis.gis_navi_yaw_route where inc_day between '$startDate' and '$endDate') a
//           |left join (select navi_id,max(sdk_ver) as sdk_version,max(start_type) as start_type from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' group by navi_id) b on a.navi_id=b.navi_id
//           |left join (select navi_id,max(status) as navi_endstatus,max(navi_endtime) as navi_endtime,max(navi_endx) as endx,max(navi_endy) as endy,max(navi_endtype) as navi_endtype from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate1' group by navi_id) c on a.navi_id=c.navi_id
//           |left join (select navi_id,len as navi_distance from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1') d on a.navi_id=d.navi_id
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//    val computeRdd = resultRdd
//      .map(json=>{
//        if(json!=null){
//          try{
//            val navi_id = json.getString("navi_id")
//            val navi_starttime = json.getLong("navi_starttime")
//            val navi_endtime = json.getLong("navi_endtime")
//            val req_time = json.getLong("req_time")
//            if(navi_starttime!=null && navi_endtime!=null){
//              val navi_cost = navi_endtime - navi_starttime
//              json.put("navi_cost", navi_cost)
//            }
//            if(req_time!=null && navi_endtime!=null){
//              val route_cost = navi_endtime - req_time
//              json.put("route_cost", route_cost)
//            }
//            var system = ""
//            if(!StringUtils.isEmpty(navi_id)){
//              if(navi_id.endsWith("0")) system = "android"
//              else if(navi_id.endsWith("1")) system = "ios"
//            }
//            json.put("system", system)
//          }
//          catch {
//            case e:Exception =>logger.error(">>>日志转json失败："+e)
//          }
//        }
//
//        val task_id = json.getString("task_id")
//        val navi_id = json.getString("navi_id")
//        var req_time = json.getLong("req_time")
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        ((task_id,navi_id),(req_time,json))
//      })
//
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//
//        val jsonList = obj._2.toList.groupBy(item=>item._2.getString("routeid")).map(item=>{
//          val sortList = item._2.toList.sortBy(_._1)
//          val minReqTime = sortList.head._1
//          (minReqTime,sortList.map(_._2))
//        }).toList.sortBy(_._1).map(_._2)
//
//        var route_count = obj._2.toList.filter(item=>"true".equalsIgnoreCase(item._2.getString("hasyaw")))
//          .groupBy(item=>item._2.getString("routeid")).keys.size
//
//        //if(route_count > 0) route_count = route_count - 1
//
//        val route_count_all = jsonList.size
//        for(i <- jsonList.indices){
//          val jsonList2 = jsonList(i)
//          for(j <- jsonList2.indices){
//            val json = jsonList2(j)
//            json.put("route_count",route_count)
//            json.put("route_order",i)
//            json.put("route_count_all",route_count_all)
//            list += json
//          }
//        }
//        list
//      })
//
//      .map(json=>{
//        val task_id = json.getString("task_id")
//        var req_time = json.getLong("req_time")
//
//        if(req_time==null) req_time = Long.MaxValue
//
//        (task_id,(req_time,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list = new ArrayBuffer[JSONObject]()
//
//        val jsonList = obj._2.toList.groupBy(item=>item._2.getString("navi_id")).map(item=>{
//          val sortList = item._2.toList.sortBy(_._1)
//          val minReqTime = sortList.head._1
//          (minReqTime,sortList.map(_._2))
//        }).toList.sortBy(_._1).map(_._2)
//
//        val navi_count = jsonList.size
//        for(i <- jsonList.indices){
//          val jsonList2 = jsonList(i)
//          for(j <- jsonList2.indices){
//            val json = jsonList2(j)
//            json.put("navi_order",i)
//            json.put("navi_count",navi_count)
//            list += json
//          }
//        }
//        list
//      })
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取Top3线路相似度
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getTop3RouteSimilarityRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      val startDate = DateUtil.getDateStr(runDate,-2)
//      dateList = DateUtil.getTwoDatesStr(startDate,runDate)
//      dateList += runDate
//    }
//
//    logger.error(">>>获取"+runDate+"号的导航结果汇总")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-2)
//      val endDate = runDate
//      sql=
//        s"""
//           |select a.request_id,a.top3_status,a.top3_info,a.err_status,a.err_info,a.route_count,a.route_index,a.routeid,a.x1,a.y1,a.x2,a.y2,a.distance,a.duration,a.toll_distance,a.tolls,a.src,a.trafficlight_count,a.routeid_out,a.is_same,a.is_match,a.flen,a.tlen,a.highspeed_distance,a.polyline,a.linknum,a.rc_distance,a.links,a.rdynsdlen,a.rdynsdcnt,b.navi_id,b.task_id,c.navi_starttime,c.navi_endtime,c.ret,c.offtime_ratio,c.navi_distance,c.tracks1,c.tracks2,a.inc_day,a.inc_day as inc_date from
//           |(select request_id,top3_status,top3_info,err_status,err_info,route_count,route_index,routeid,x1,y1,x2,y2,distance,duration,toll_distance,tolls,src,trafficlight_count,routeid_out,is_same,is_match,flen,tlen,highspeed_distance,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,inc_day from dm_gis.gis_navi_top3_yaw_result_parse where inc_day='$runDate' and subtype='naviTop3V2LogResult') a
//           |left join (select request_id,navi_id,task_id from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate' and request_id is not null and request_id<>'') b on a.request_id=b.request_id
//           |left join (select navi_id,navi_starttime,navi_endtime,ret,offtime_ratio,len as navi_distance,tracks1,tracks2 from dm_gis.gis_navi_rectify_result where inc_day='$runDate' and navi_id is not null and navi_id<>'') c on b.navi_id=c.navi_id
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = DateUtil.getDateStr(runDate,-2)
//      val startDate1 = DateUtil.getDateStr(runDate,-4)
//      val endDate = runDate
//      val endDate1 = DateUtil.getDateStr(runDate,1)
//      sql=
//        s"""
//           |select a.request_id,a.top3_status,a.top3_info,a.err_status,a.err_info,a.route_count,a.route_index,a.routeid,a.x1,a.y1,a.x2,a.y2,a.distance,a.duration,a.toll_distance,a.tolls,a.src,a.trafficlight_count,a.routeid_out,a.is_same,a.is_match,a.flen,a.tlen,a.highspeed_distance,a.polyline,a.linknum,a.rc_distance,a.links,a.rdynsdlen,a.rdynsdcnt,b.navi_id,b.task_id,c.navi_starttime,c.navi_endtime,c.ret,c.offtime_ratio,c.navi_distance,c.tracks1,c.tracks2,'1' as end from
//           |(select request_id,top3_status,top3_info,err_status,err_info,route_count,route_index,routeid,x1,y1,x2,y2,distance,duration,toll_distance,tolls,src,trafficlight_count,routeid_out,is_same,is_match,flen,tlen,highspeed_distance,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate' and subtype='naviTop3V2LogResult') a
//           |left join (select request_id,navi_id,task_id from dm_gis.gis_navi_top3_parse where inc_day between '$startDate1' and '$endDate' and request_id is not null and request_id<>'') b on a.request_id=b.request_id
//           |left join (select navi_id,navi_starttime,navi_endtime,ret,offtime_ratio,len as navi_distance,tracks1,tracks2 from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1' and navi_id is not null and navi_id<>'') c on b.navi_id=c.navi_id
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//
//    val computeRdd = resultRdd.map(json=>{
//      if(json!=null){
////        try{
//        val end = json.getString("end")
//
//        if("1".equalsIgnoreCase(end)){
//          val navi_starttime = json.getLong("navi_starttime")
//          if(navi_starttime!=null){
//            val inc_date = longToTime(navi_starttime).split(" ")(0).replaceAll("-","")
//            json.put("inc_date",inc_date)
//          }
//        }
//
//
//        val polyline = json.getJSONArray("polyline")
//        val polyline_new = new JSONArray()
//        json.remove("polyline")
//        if(polyline!=null && polyline.size()>0){
//          for(j<-0.until(polyline.size())){
//            val track = polyline.getJSONObject(j)
//            val tmp = new JSONArray()
//            if(track!=null){
//              val x = track.getDouble("x")
//              val y = track.getDouble("y")
//              if(x!=null && y!=null){
//                tmp.add(x)
//                tmp.add(y)
//                polyline_new.add(tmp)
//              }
//            }
//          }
//          json.put("polyline", polyline_new)
//        }
//
//        val tracks1 = json.getJSONArray("tracks1")
//        val tracks1_new = new JSONArray()
//        json.remove("tracks1")
//        if(tracks1!=null && tracks1.size()>0){
//          for(j<-0.until(tracks1.size())){
//            val track = tracks1.getJSONObject(j)
//            val tmp = new JSONArray()
//            if(track!=null){
//              val x = track.getDouble("x")
//              val y = track.getDouble("y")
//              if(x!=null && y!=null){
//                tmp.add(x)
//                tmp.add(y)
//                tracks1_new.add(tmp)
//              }
//            }
//          }
//          json.put("tracks1", tracks1_new)
//        }
//
//        val tracks2 = json.getJSONArray("tracks2")
//        val tracks2_new = new JSONArray()
//        json.remove("tracks2")
//        if(tracks2!=null && tracks2.size()>0){
//          for(j<-0.until(tracks2.size())){
//            val track = tracks2.getJSONObject(j)
//            val tmp = new JSONArray()
//            if(track!=null){
//              val x = track.getDouble("x")
//              val y = track.getDouble("y")
//              if(x!=null && y!=null){
//                tmp.add(x)
//                tmp.add(y)
//                tracks2_new.add(tmp)
//              }
//            }
//          }
//          json.put("tracks2", tracks2_new)
//        }
//
//
//        if(polyline_new!=null && polyline_new.size()>0 && tracks2_new!=null && tracks2_new.size()>0){
//
//          val polyline_new2 = new JSONArray()
//          for(i<-0.until(polyline_new.size())){
//            val track = polyline_new.getJSONArray(i)
//            if(track!=null){
//              val x = track.getDouble(0)
//              val y = track.getDouble(1)
//              if(x!=null && y!=null){
//                val newJson = new JSONObject()
//                newJson.put("x",x)
//                newJson.put("y",y)
//                newJson.put("type",1)
//                polyline_new2.add(newJson)
//              }
//            }
//          }
//
//          val tracks2_new2 = new JSONArray()
//          for(i<-0.until(tracks2_new.size())){
//            val track = tracks2_new.getJSONArray(i)
//            if(track!=null){
//              val x = track.getDouble(0)
//              val y = track.getDouble(1)
//              if(x!=null && y!=null){
//                val newJson = new JSONObject()
//                newJson.put("x",x)
//                newJson.put("y",y)
//                newJson.put("type",1)
//                tracks2_new2.add(newJson)
//              }
//            }
//          }
//
//          val resultObject = accessCompareUrl(json,polyline_new2,tracks2_new2)
//          if(resultObject!=null){
//            val resultObject2 = resultObject.getJSONObject("result")
//            if(resultObject2!=null){
//              val similarity1 =  resultObject2.getDouble("similarity1")
//              val similarity2 = resultObject2.getDouble("similarity2")
//              json.put("similarity1",similarity1)
//              json.put("similarity5",similarity2)
//            }
//          }
//
//        }
//
////        }
////        catch {
////          case e:Exception =>logger.error(">>>日志转json失败："+e)
////        }
//      }
//      json
//    })
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
//  /**
//    * 获取高德请求线路的ETA结果
//    * @param spark
//    * @param runType
//    * @param date
//    * @param auto
//    * @return
//    */
//  def getGdRouteEtaRdd(spark:SparkSession, runType:String, date:String, auto:String):(RDD[JSONObject],ArrayBuffer[String]) ={
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//    var runDate = ""
//    if("1".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = date
//      }
//      else{
//        runDate = date
//      }
//      dateList += runDate
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      if("true".equalsIgnoreCase(auto)){
//        runDate = DateUtil.getDateStr(date,-1)
//      }
//      else{
//        runDate = date
//      }
//      dateList = NaviMain.getMutiDayDateList(runDate)
//    }
//
//    logger.error(">>>获取"+runDate+"号的高德请求线路的ETA结果")
//    var sql = ""
//
//    if("1".equalsIgnoreCase(runType)){
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.routeid,a.navi_type,b.polyline,c.req_time,c.src_deptcode,c.dest_deptcode,c.x1,c.y1,c.endxx2,c.y2,c.vehicle,c.vehicle_type,c.weight,c.mload,c.length,c.width,c.height,c.axle_weight,c.axle_number,c.plate_color,c.energy,c.emit_stand,c.passport,c.driver_id,c.ft_url,c.plan_date,c.opt,c.routeid_in,c.fixed_route,c.fencedist,c.status,c.driver_type,c.line_code,c.service_id,c.request_id,d.src_citycode,d.src_province,e.dest_citycode,e.dest_province,f.navi_endtime,a.inc_date from
//           |(select task_id,navi_id,report_time as navi_starttime,routeid,'gdsdk' as navi_type,inc_day as inc_date from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='9') a
//           |left join (select navi_id,gd_content as polyline from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='8') b on a.navi_id=b.navi_id
//           |left join (select navi_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,opt,routeid_in,fixed_route,fencedist,status,driver_type,line_code,service_id,request_id from dm_gis.gis_navi_top3_parse where inc_day='$runDate') c on a.navi_id=c.navi_id
//           |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909') d on c.src_deptcode=d.zone_code
//           |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909') e on c.dest_deptcode=e.zone_code
//           |left join (select navi_id,routeid,report_time as navi_endtime from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='10') f on a.navi_id=f.navi_id and a.routeid=f.routeid
//       """.stripMargin
//    }
//    else if("3".equalsIgnoreCase(runType)){
//      val startDate = dateList(0)
//      val endDate = dateList(dateList.length - 1)
//      sql=
//        s"""
//           |select a.task_id,a.navi_id,a.navi_starttime,a.routeid,a.navi_type,b.polyline,c.req_time,c.src_deptcode,c.dest_deptcode,c.x1,c.y1,c.x2,c.y2,c.vehicle,c.vehicle_type,c.weight,c.mload,c.length,c.width,c.height,c.axle_weight,c.axle_number,c.plate_color,c.energy,c.emit_stand,c.passport,c.driver_id,c.ft_url,c.plan_date,c.opt,c.routeid_in,c.fixed_route,c.fencedist,c.status,c.driver_type,c.line_code,c.service_id,c.request_id,d.src_citycode,d.src_province,e.dest_citycode,e.dest_province,f.navi_endtime,a.inc_date from
//           |(select task_id,navi_id,report_time as navi_starttime,routeid,'gdsdk' as navi_type,inc_day as inc_date from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type='9') a
//           |left join (select navi_id,gd_content as polyline from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type='8') b on a.navi_id=b.navi_id
//           |left join (select navi_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,opt,routeid_in,fixed_route,fencedist,status,driver_type,line_code,service_id,request_id from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate') c on a.navi_id=c.navi_id
//           |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909') d on c.src_deptcode=d.zone_code
//           |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909') e on c.dest_deptcode=e.zone_code
//           |left join (select navi_id,routeid,report_time as navi_endtime from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type='10') f on a.navi_id=f.navi_id and a.routeid=f.routeid
//       """.stripMargin
//    }
//
//    val resultRdd = NaviLogParse.getValidJson(spark,sql)
//    logger.error(">>>日志量：" + resultRdd.count())
//
//
//    val computeRdd = resultRdd
//      .map(json=>{
//        if(json!=null){
//          var polyline_new = ""
//          val polyline = json.getJSONArray("polyline")
//          var routeid = json.getString("routeid")
//          if(StringUtils.isEmpty(routeid)) routeid = ""
//          var flag = true
//          if(polyline!=null && polyline.size()>0){
//            breakable(
//              for(j<-0.until(polyline.size())){
//                val track = polyline.getJSONObject(j)
//                if(track!=null){
//                  if(routeid.equalsIgnoreCase(track.getString("routeId"))){
//                    polyline_new = track.getString("coords")
//                    polyline_new = polyline_new.replaceAll("latitude","y").replaceAll("longitude","x")
//                    flag = false
//                    break
//                  }
//                }
//              }
//            )
//          }
//          if(flag){
//            if(polyline!=null && polyline.size()>0){
//              breakable(
//                for(j<-0.until(polyline.size())){
//                  val track = polyline.getJSONObject(j)
//                  if(track!=null){
//                    if(routeid.equalsIgnoreCase(track.getString("routeUID"))){
//                      polyline_new = track.getString("routeCoordinates")
//                      polyline_new = polyline_new.replaceAll("latitude","y").replaceAll("longitude","x")
//                      flag = false
//                      break
//                    }
//                  }
//                }
//              )
//            }
//          }
//
//          json.put("polyline", polyline_new)
//        }
//        json
//      })
//      .filter(json => !StringUtils.isEmpty(json.getString("polyline")) && !"[]".equalsIgnoreCase(json.getString("polyline")) && !StringUtils.isEmpty(json.getString("navi_endtime")))
//      .map(json=>{
//        var navi_id = json.getString("navi_id")
//        var navi_starttime = json.getLong("navi_starttime")
//        if(StringUtils.isEmpty(navi_id)) navi_id = "-"
//        if(navi_starttime == null) navi_starttime = Long.MaxValue
//        (navi_id,(navi_starttime,json))
//      })
//      .groupByKey()
//      .flatMap(obj=>{
//        val list: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
//        for(i <- list.indices){
//          val json = list(i)
//          json.put("gd_navi_order",i)
//        }
//        list
//      })
//
//    resultRdd.unpersist()
//
//
//    (computeRdd,dateList)
//  }
//
//
//
//
//
//
//
//
//
//  /**
//    * 时间戳转换为时分秒
//    * @param timestamp
//    * @return
//    */
//  def longToTime(timestamp:Long,format:String="yyyy-MM-dd HH:mm:ss SSS"): String ={
//    var datetime = ""
//    try {
//      var sdf = new SimpleDateFormat(format)
//      datetime = sdf.format(new Date(timestamp))
//    } catch {
//      case e:Exception =>logger.error(">>>时间戳解析异常")
//    }
//    datetime
//  }
//
//
//  /**
//    * 时间戳转换为时分秒
//    * @param date
//    * @return
//    */
//  def dateToTimeStamp(date:String,format:String="yyyyMMdd"): String ={
//    var datetime = ""
//    try {
//      var sdf = new SimpleDateFormat(format)
//      val time = sdf.parse(date).getTime
//      datetime = time.toString
//    } catch {
//      case e:Exception =>logger.error(">>>时间戳解析异常")
//    }
//    datetime
//  }
//
//
//
//  /**
//    * 访问比较轨迹接口
//    * @param json
//    * @param tracks
//    * @return
//    */
//  def accessRectifyUrl(json:JSONObject, tracks:JSONArray): JSONObject ={
//    var http_result:JSONObject = null
//    //    try {
//    var vehicle_type = 6
//    if (json.getInteger("vehicle_type")!=null) vehicle_type = json.getInteger("vehicle_type")
//    val param = new JSONObject()
//    param.put("ak", "d9c28a860af34836973480542dc11d83")
//    param.put("vehicle", vehicle_type)
//    param.put("retflag", 7)
//    param.put("addpoint", 1)
//    param.put("poiinfo", 1)
//    param.put("tracks", tracks)
//
//    val vehicleInfo = new JSONObject()
//    val mload = json.getString("mload")
//    if(!StringUtils.isEmpty(mload)) vehicleInfo.put("load",mload)
//    val axle_number = json.getString("axle_number")
//    if(!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis",axle_number)
//    val weight = json.getDouble("weight")
//    if(weight!=null) vehicleInfo.put("weight",weight)
//    val length = json.getDouble("length")
//    if(length!=null) vehicleInfo.put("length",length)
//
//    param.put("vehicleInfo", vehicleInfo)
//    param.put("roadinfo", 1)
//    param.put("mat_ratio", 1)
//
//    val process = new JSONObject()
//    process.put("stay_time",180)
//    process.put("poi_range",500)
//
//    param.put("process", process)
//
//    println("参数："+param.toString)
//    http_result = HttpClientUtil.getJsonByPostJson(rectify_url, param.toString)
//    //println("返回："+http_result.toString)
//    Thread.sleep(600)
//    //      println("轨迹对比结果："+http_result)
//    //    } catch {
//    //      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
//    //    }
//    http_result
//  }
//
//
//
//  /**
//    * 访问比较轨迹接口
//    * @param json
//    * @param tracks1
//    * @param tracks2
//    * @return
//    */
//  def accessCompareUrl(json:JSONObject,tracks1:JSONArray,tracks2:JSONArray): JSONObject ={
//    var http_result:JSONObject = null
//    //    try {
//    var vehicle_type = 6
//    if (json.getInteger("vehicle_type")!=null) vehicle_type = json.getInteger("vehicle_type")
//    val param = new JSONObject()
//    param.put("vehicle", vehicle_type)
//    //param.put("compensate", 1)
//    param.put("ak", "d9c28a860af34836973480542dc11d83")
//    param.put("retflag", 5)
//    param.put("tracktype", 0)
//    param.put("tracks1", tracks1)
//    param.put("tracks2", tracks2)
//    println("-------------json-------"+json)
//    //      println("轨迹对比接口："+compare_track_url)
//    //      println("轨迹对比参数："+param)
//    http_result = HttpClientUtil.getJsonByPostJson(compare_track_url, param.toString)
//    Thread.sleep(600)
//    //      println("轨迹对比结果："+http_result)
//    //    } catch {
//    //      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
//    //    }
//    http_result
//  }
//
//
//
//
//
//}
