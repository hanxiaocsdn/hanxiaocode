package demand.navi

import java.io.File
import java.util.Calendar
import com.csvreader.CsvWriter
import demand.utils.{DateUtil, SparkUtil}
import org.apache.commons.io.Charsets
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession


/**
  * Created by 01368978 on 2021/7/23.
  */
object NaviResultSave {
  val excute = true
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    if(!excute) {
      logger.error("不执行程序")
      logger.error("the end ...")
      return
    }

    val spark = SparkUtil.getSparkSession(appName)

    logger.error("获取和设置日期...")
    var runDate = ""
    var argcount = args.length
    if(argcount == 0) argcount = 1
    for (i <- 0 to argcount - 1) {
      if (args.length == 0) {
        val format = FastDateFormat.getInstance("yyyyMMdd")
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_MONTH, -1)
        runDate = format.format(calendar.getTime)
      }
      else {
        runDate = args(i)
      }


      navi(spark, runDate)


//      batchTask(spark, "20201210","20201218")


    }
    spark.stop()
    logger.error("the end ...")

  }





  /**
    * 批量任务
    *
    * @param spark
    * @param startDate
    * @param endDate
    */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      navi(spark, date)
    }
  }


  def navi(sparkSession: SparkSession, runDate: String) : Unit = {
    val endDate = runDate
    val format = FastDateFormat.getInstance("yyyyMMdd")
    val calendar = Calendar.getInstance()
    calendar.setTime(format.parse(runDate))
    calendar.add(Calendar.DAY_OF_MONTH, -1)
    val beforeDate = format.format(calendar.getTime)
    calendar.add(Calendar.DAY_OF_MONTH, -1)
    val startDate = format.format(calendar.getTime)

    val dateList = Array(startDate,beforeDate,endDate)

    logger.error("开始处理" + runDate)

    logger.error("读取dm_gis.gis_navi_result_union的三天信息")
    var flag_sql =
      s"""select * from dm_gis.gis_navi_result_union where inc_day between '$startDate' and '$endDate' limit 1
       """.stripMargin
    logger.error(flag_sql)
    val gis_navi_result_union_count = sparkSession.sql(flag_sql)
    val gis_navi_result_union_flag = gis_navi_result_union_count.take(1).length == 0

    if(gis_navi_result_union_flag){
      logger.error("没有从gis_navi_result_union获取到数据，放弃执行！")
    }
    else{
      logger.error("开始从gis_navi_result_union获取数据")
      var gis_navi_result_union_sql =
        s"""
           |select task_id,navi_id,navi_count,navi_order,route_count,route_order,route_count_all,routeid,hasyaw,src_province,dest_province,src_citycode,dest_citycode,src_deptcode,dest_deptcode,navi_starttime,req_time as time,route_type,x1,y1,x2,y2,vehicle,driver_id,sdk_version,route_src,ft_url,status,navi_endstatus,navi_endtime,endx,endy,navi_endtype,navi_cost,navi_distance,system,inc_day
           |from dm_gis.gis_navi_result_union where inc_day between '$startDate' and '$endDate' and req_time<>''
       """.stripMargin
      logger.error(gis_navi_result_union_sql)
      val gis_navi_result_union_df = sparkSession.sql(gis_navi_result_union_sql).na.fill("")

      val columnList = gis_navi_result_union_df.columns
      val gis_navi_result_union_all = gis_navi_result_union_df
        .rdd.repartition(960).persist()

      for(date<-dateList){
        logger.error("处理" + date + ".csv")
        val gis_navi_result_union_new = gis_navi_result_union_all
          .filter(row=>date.equalsIgnoreCase(row.getString(36)))
          .repartition(100).map(row => {
          var rowString:List[String] = List()
          for(index <- 0 to row.size - 1){
            if(!row.isNullAt(index)) rowString = rowString :+ row.get(index).toString.replaceAll("\t","").replaceAll("\n","")
            else rowString = rowString :+ ""
          }
          rowString
        }).persist()
        logger.error("count:" + gis_navi_result_union_new.count())

        val filePath = date + ".csv"
        val writer = new CsvWriter(filePath, '\t', Charsets.UTF_8)
        val record = columnList
        logger.error("开始写csv")
        writer.writeRecord(record)
        logger.error("开始写具体数据")
        gis_navi_result_union_new.collect().foreach(rowString => {
          writer.writeRecord(rowString.toArray)
        })
        writer.close()
        logger.error("写csv完成")

        logger.error("开始上传")
        val ftpUtil = new FTPUtil("gisftp.sf-express.com", Integer.parseInt("21"), "devftp", "brYsj2.023ftKjdev")
        ftpUtil.ftpLogin()
        ftpUtil.uploadFile(new File(filePath), "/GIS-ASS-AOS/01368978/Navi/navi_result")
        ftpUtil.ftpLogOut()
        logger.error("上传完成")
        logger.error("删除文件")
        val f = new File(filePath)
        if(f.exists()) f.delete()

        gis_navi_result_union_new.unpersist()
      }

      gis_navi_result_union_all.unpersist()


    }


  }



}
