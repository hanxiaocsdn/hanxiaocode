package demand.navi

import com.alibaba.fastjson.{JSON, JSONObject}
import common.SourceAndDiskCommon
import demand.utils.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 496926
 * @description: 导航计提金额表 gis_eta_navi_accrualmoney
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/10/15 18:14
 */
object NaviParse_naviAccrualMoney extends SourceAndDiskCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    result.fluentPutAll(result.getJSONObject("data"))
    result.keySet().toArray.foreach(key => {
      if (result.get(key.toString).isInstanceOf[JSONObject]) {
        val temp = result.getJSONObject(key.toString)
        temp.keySet().toArray.foreach(k => {
          result.put(k.toString.toLowerCase, temp.getString(k.toString))
        })
      }
    })
    "resultstatus,status"
      .split(";").foreach(x => result.put(x.split(",")(0), result.getString(x.split(",")(1))))
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value

  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      ParseLog(spark, DateUtil.getYesterday)
    } else if (args.length == 1) {
      //传入参数，单天任务
      ParseLog(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    val runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getAccMoneyRdd
    computeRddF = null
    table = "gis_eta_navi_accrualmoney"

    structs = Array("task_id", "reqstarttime", "reqendtime", "reqcosttime", "status", "appver", "serviceid", "ak", "resultstatus", "accrualmoney", "accrualdist", "querysno")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)
  }

  /**
   * 获取naviAccMoney日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getAccMoneyRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = "queryAccrualMoneyLog"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    val computeRdd = validRdd.map(json => {
      var reqStartTime: java.lang.Long = null
      var task_id = ""
      if (json != null) {
        val data = json.getJSONObject("data")
        if (data != null) {
          reqStartTime = data.getLong("reqStartTime")
          //分区字段生成
          if (reqStartTime != null) {
            val inc_day = longToTime(reqStartTime).split(" ")(0).replaceAll("-", "")
            json.put("inc_day", inc_day)
          }
          if (data.getJSONObject("naviQueryAccrualDistArgs") != null) {
            task_id = data.getJSONObject("naviQueryAccrualDistArgs").getString("taskId")
          }
          if (data.getJSONObject("result") != null) {
            val tmp = data.getJSONObject("result").getJSONObject("result")
            if (tmp != null) {
              json.put("accrualmoney", tmp.getString("accrualMoney"))
              json.put("accrualdist", tmp.getString("accrualDist"))
            }
          }
        }
      }
      ((task_id, reqStartTime), json)
    }).groupByKey()
      .map(obj => {
        val json = obj._2.toList.head
        json
      }).repartition(repartition).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()
    computeRdd
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }


  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val endDate1 = endDate
    var sql = ""
    var logRdd: RDD[JSONObject] = null
    var table = ""
    if (subType.contains("Result") && (subType.contains("V2") || subType.contains("path"))) table = "gis_eta_navi_query_proto_hive"
    else table = "gis_eta_navi_query_hive"
    if (subType.contains(",")) {
      val subTypes = subType.split(",")
      val subType1 = subTypes(0)
      val subType2 = subTypes(1)
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate1'
           | and (get_json_object(data, '$$.subType') = '$subType1' or get_json_object(data, '$$.subType') = '$subType2')
       """.stripMargin
    }
    else {
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate1'
           | and get_json_object(data, '$$.subType') = '$subType'
       """.stripMargin
    }
    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x))
  }

}
