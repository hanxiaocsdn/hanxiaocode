package demand.navi

import java.text.SimpleDateFormat
import demand.utils.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * task_id : 264068
 * Created by 01368978 on 2020/9/21. 查看轨迹上传情况
 * 从HBase读取数据 前置主类：com.sf.gis.java.realtime.func.GisHBaseSinkFunction(前置实时 2142879 2142237)
 */

object NaviTrackHbase {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  var repartition = 10

  val tableName = "gis:navi_sdk_history"
  //  val quorum = "10.202.34.200,10.202.34.201,10.202.34.202,10.202.34.203,10.202.116.36,10.202.116.37,10.202.116.38,10.202.116.39,10.202.116.40"
  val quorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
  val port = "2181"

  def main(args: Array[String]): Unit = {
    //val spark = SparkUtil.getLocalSpark(appName)
    val spark = SparkUtil.getSparkSession(appName)


    if (args.length == 0) {
      //代码内部传入日期参数
      saveHbaseData(spark, DateUtil.getYesterday)
    } else if (args.length == 1) {
      //传入参数，单天任务
      saveHbaseData(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }

    //    var startDate = "20210912"
    //    var endDate = "20210914"
    //    //      endDate = "20200916"
    //    batchTask(spark, startDate, endDate)

    spark.stop()
    logger.error(">>>处理完毕---------------")


    spark.stop()
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      saveHbaseData(spark, date)
    }
  }


  def saveHbaseData(spark: SparkSession, date: String): Unit = {
    logger.error("开始处理" + date)
    val endDate = DateUtil.getDateStr(date, 1)
    val start = timeToLong(date)
    val end = timeToLong(endDate)

    // 配置相关信息
    val conf = HBaseUtils.getHBaseConfiguration(quorum, port, tableName)
    conf.set(TableInputFormat.INPUT_TABLE, tableName)
    conf.set(TableInputFormat.SCAN_TIMERANGE_START, start)
    conf.set(TableInputFormat.SCAN_TIMERANGE_END, end)

    // HBase数据转成RDD
    val hBaseRDD = spark.sparkContext.newAPIHadoopRDD(conf, classOf[TableInputFormat],
      classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable],
      classOf[org.apache.hadoop.hbase.client.Result]) //.cache()

    // RDD数据操作
    val dataRdd = hBaseRDD.map(item => {
      val result = item._2
      val key = Bytes.toString(result.getRow)
      var carNo = Bytes.toString(result.getValue("info".getBytes, "un".getBytes))
      var deviceId = Bytes.toString(result.getValue("info".getBytes, "id".getBytes))
      var tag = Bytes.toString(result.getValue("info".getBytes, "tag".getBytes))
      var tm = Bytes.toString(result.getValue("info".getBytes, "tm".getBytes))
      var x = Bytes.toString(result.getValue("info".getBytes, "zx".getBytes))
      var y = Bytes.toString(result.getValue("info".getBytes, "zy".getBytes))
      var sp = Bytes.toString(result.getValue("info".getBytes, "sp".getBytes))
      var be = Bytes.toString(result.getValue("info".getBytes, "be".getBytes))
      var tp = Bytes.toString(result.getValue("info".getBytes, "tp".getBytes))
      var ac = Bytes.toString(result.getValue("info".getBytes, "ac".getBytes))
      var sl = Bytes.toString(result.getValue("info".getBytes, "sl".getBytes))
      var xh = Bytes.toString(result.getValue("info".getBytes, "xh".getBytes))
      var bk = Bytes.toString(result.getValue("info".getBytes, "bk".getBytes))

      if (StringUtils.isEmpty(carNo)) carNo = ""
      if (StringUtils.isEmpty(deviceId)) deviceId = ""
      if (StringUtils.isEmpty(tag)) tag = ""
      if (StringUtils.isEmpty(tm)) tm = ""
      if (StringUtils.isEmpty(x)) x = ""
      if (StringUtils.isEmpty(y)) y = ""
      if (StringUtils.isEmpty(sp)) sp = ""
      if (StringUtils.isEmpty(be)) be = ""
      if (StringUtils.isEmpty(tp)) tp = ""
      if (StringUtils.isEmpty(ac)) ac = ""
      if (StringUtils.isEmpty(sl)) sl = ""
      if (StringUtils.isEmpty(bk)) bk = ""

      val array = Array(carNo, deviceId, tag, tm, x, y, sp, be, tp, ac, sl, xh, bk)
      array
    }).repartition(repartition).persist()

    logger.error("数据量：" + dataRdd.count())

    //data.foreach(println)

    val table = "gis_navi_navi_sdk_history_track"
    val structs = Array("carno", "deviceid", "tag", "tm", "x", "y", "sp", "be", "tp", "ac", "sl", "xh", "bk")
    SaveDataToHive.saveArrayRDDToHive(spark, dataRdd, table, structs, date, "")

    conf.clear()
  }


  def timeToLong(time: String, format: String = "yyyyMMdd HH:mm:ss SSS"): String = {
    val sdf: SimpleDateFormat = new SimpleDateFormat(format)
    val longTime = sdf.parse(time + " 00:00:00 000").getTime
    longTime.toString
  }

}