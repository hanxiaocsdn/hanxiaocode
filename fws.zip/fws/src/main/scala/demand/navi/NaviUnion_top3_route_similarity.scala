package demand.navi

import com.alibaba.fastjson.{JSONArray, JSONObject}
import demand.utils.{DateUtil, HttpClientUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id:(20230615 已下线) 267404
 * @description: gis_navi_top3_route_similarity
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/3/13 15:07
 */
object NaviUnion_top3_route_similarity {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 500
  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val compare_track_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)
    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getTop3RouteSimilarityRdd
    computeRddF = null
    table = "gis_navi_top3_route_similarity"
    structs = Array("request_id", "top3_status", "top3_info", "err_status", "err_info", "route_count", "route_index", "routeid", "x1", "y1", "x2", "y2", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "routeid_out", "is_same", "is_match", "flen", "tlen", "highspeed_distance", "polyline", "linknum", "rc_distance", "links", "rdynsdlen", "rdynsdcnt", "navi_id", "task_id", "navi_starttime", "navi_endtime", "ret", "offtime_ratio", "navi_distance", "tracks1", "tracks2", "similarity1", "similarity5")
    keys = Array("request_id", "top3_status", "top3_info", "err_status", "err_info", "route_count", "route_index", "routeid", "x1", "y1", "x2", "y2", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "routeid_out", "is_same", "is_match", "flen", "tlen", "highspeed_distance", "polyline", "linknum", "rc_distance", "links", "rdynsdlen", "rdynsdcnt", "navi_id", "task_id", "navi_starttime", "navi_endtime", "ret", "offtime_ratio", "navi_distance", "tracks1", "tracks2", "similarity1", "similarity5")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }


  /**
   * 解析日志主流程
   *
   * @param spark
   * @param getRddF
   * @param computeRddF
   * @param table
   * @param structs
   * @param keys
   * @param saveHiveRddF
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  /**
   * 获取Top3线路相似度
   *
   * @param spark
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def getTop3RouteSimilarityRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    val dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    dateList += date

    val startDate = DateUtil.getDateStr(date, -2)
    val startDate1 = DateUtil.getDateStr(date, -4)
    val endDate = date
    val endDate1 = DateUtil.getDateStr(date, 1)
    logger.error(">>>获取" + date + "号的导航结果汇总")
    var sql = ""
    sql =
      s"""
         |select a.request_id,a.top3_status,a.top3_info,a.err_status,a.err_info,a.route_count,a.route_index,a.routeid,a.x1,a.y1,a.x2,a.y2,a.distance,a.duration,a.toll_distance,a.tolls,a.src,a.trafficlight_count,a.routeid_out,a.is_same,a.is_match,a.flen,a.tlen,a.highspeed_distance,a.polyline,a.linknum,a.rc_distance,a.links,a.rdynsdlen,a.rdynsdcnt,b.navi_id,b.task_id,c.navi_starttime,c.navi_endtime,c.ret,c.offtime_ratio,c.navi_distance,c.tracks1,c.tracks2,'1' as end from
         |(select request_id,top3_status,top3_info,err_status,err_info,route_count,route_index,routeid,x1,y1,x2,y2,distance,duration,toll_distance,tolls,src,trafficlight_count,routeid_out,is_same,is_match,flen,tlen,highspeed_distance,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate' and subtype='naviTop3V2LogResult') a
         |left join (select request_id,navi_id,task_id from dm_gis.gis_navi_top3_parse where inc_day between '$startDate1' and '$endDate' and request_id is not null and request_id<>'') b on a.request_id=b.request_id
         |left join (select navi_id,navi_starttime,navi_endtime,ret,offtime_ratio,len as navi_distance,tracks1,tracks2 from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate1' and navi_id is not null and navi_id<>'') c on b.navi_id=c.navi_id
       """.stripMargin

    val resultRdd = NaviLogParse.getValidJson(spark, sql).persist()
    logger.error(">>>日志量：" + resultRdd.count())

    val computeRdd = resultRdd.map(json => {
      if (json != null) {
        //        try{
        val end = json.getString("end")

        if ("1".equalsIgnoreCase(end)) {
          val navi_starttime = json.getLong("navi_starttime")
          if (navi_starttime != null) {
            val inc_date = longToTime(navi_starttime).split(" ")(0).replaceAll("-", "")
            json.put("inc_date", inc_date)
          }
        }
        val polyline = json.getJSONArray("polyline")
        val polyline_new = new JSONArray()
        json.remove("polyline")
        if (polyline != null && polyline.size() > 0) {
          for (j <- 0.until(polyline.size())) {
            val track = polyline.getJSONObject(j)
            val tmp = new JSONArray()
            if (track != null) {
              val x = track.getDouble("x")
              val y = track.getDouble("y")
              if (x != null && y != null) {
                tmp.add(x)
                tmp.add(y)
                polyline_new.add(tmp)
              }
            }
          }
          json.put("polyline", polyline_new)
        }

        val tracks1 = json.getJSONArray("tracks1")
        val tracks1_new = new JSONArray()
        json.remove("tracks1")
        if (tracks1 != null && tracks1.size() > 0) {
          for (j <- 0.until(tracks1.size())) {
            val track = tracks1.getJSONObject(j)
            val tmp = new JSONArray()
            if (track != null) {
              val x = track.getDouble("x")
              val y = track.getDouble("y")
              if (x != null && y != null) {
                tmp.add(x)
                tmp.add(y)
                tracks1_new.add(tmp)
              }
            }
          }
          json.put("tracks1", tracks1_new)
        }

        val tracks2 = json.getJSONArray("tracks2")
        val tracks2_new = new JSONArray()
        json.remove("tracks2")
        if (tracks2 != null && tracks2.size() > 0) {
          for (j <- 0.until(tracks2.size())) {
            val track = tracks2.getJSONObject(j)
            val tmp = new JSONArray()
            if (track != null) {
              val x = track.getDouble("x")
              val y = track.getDouble("y")
              if (x != null && y != null) {
                tmp.add(x)
                tmp.add(y)
                tracks2_new.add(tmp)
              }
            }
          }
          json.put("tracks2", tracks2_new)
        }

        if (polyline_new != null && polyline_new.size() > 0 && tracks2_new != null && tracks2_new.size() > 0) {

          val polyline_new2 = new JSONArray()
          for (i <- 0.until(polyline_new.size())) {
            val track = polyline_new.getJSONArray(i)
            if (track != null) {
              val x = track.getDouble(0)
              val y = track.getDouble(1)
              if (x != null && y != null) {
                val newJson = new JSONObject()
                newJson.put("x", x)
                newJson.put("y", y)
                newJson.put("type", 1)
                polyline_new2.add(newJson)
              }
            }
          }

          val tracks2_new2 = new JSONArray()
          for (i <- 0.until(tracks2_new.size())) {
            val track = tracks2_new.getJSONArray(i)
            if (track != null) {
              val x = track.getDouble(0)
              val y = track.getDouble(1)
              if (x != null && y != null) {
                val newJson = new JSONObject()
                newJson.put("x", x)
                newJson.put("y", y)
                newJson.put("type", 1)
                tracks2_new2.add(newJson)
              }
            }
          }

          val resultObject = accessCompareUrl(json, polyline_new2, tracks2_new2)
          if (resultObject != null) {
            val resultObject2 = resultObject.getJSONObject("result")
            if (resultObject2 != null) {
              val similarity1 = resultObject2.getDouble("similarity1")
              val similarity2 = resultObject2.getDouble("similarity2")
              json.put("similarity1", similarity1)
              json.put("similarity5", similarity2)
            }
          }

        }
      }
      json
    })
    resultRdd.unpersist()
    (computeRdd, dateList)
  }


  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }


  /**
   * 时间戳转换为时分秒
   *
   * @param date
   * @return
   */
  def dateToTimeStamp(date: String, format: String = "yyyyMMdd"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      val time = sdf.parse(date).getTime
      datetime = time.toString
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }


  /**
   * 访问比较轨迹接口
   *
   * @param json
   * @param tracks
   * @return
   */
  def accessRectifyUrl(json: JSONObject, tracks: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("vehicle", vehicle_type)
    param.put("retflag", 7)
    param.put("addpoint", 1)
    param.put("poiinfo", 1)
    param.put("tracks", tracks)

    val vehicleInfo = new JSONObject()
    val mload = json.getString("mload")
    if (!StringUtils.isEmpty(mload)) vehicleInfo.put("load", mload)
    val axle_number = json.getString("axle_number")
    if (!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis", axle_number)
    val weight = json.getDouble("weight")
    if (weight != null) vehicleInfo.put("weight", weight)
    val length = json.getDouble("length")
    if (length != null) vehicleInfo.put("length", length)

    param.put("vehicleInfo", vehicleInfo)
    param.put("roadinfo", 1)
    param.put("mat_ratio", 1)

    val process = new JSONObject()
    process.put("stay_time", 180)
    process.put("poi_range", 500)

    param.put("process", process)

    //    println("参数：" + param.toString)
    http_result = HttpClientUtil.getJsonByPostJson(rectify_url, param.toString)
    Thread.sleep(1000)
    http_result
  }


  /**
   * 访问比较轨迹接口
   *
   * @param json
   * @param tracks1
   * @param tracks2
   * @return
   */
  def accessCompareUrl(json: JSONObject, tracks1: JSONArray, tracks2: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("vehicle", vehicle_type)
    //param.put("compensate", 1)
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("retflag", 5)
    param.put("tracktype", 0)
    param.put("tracks1", tracks1)
    param.put("tracks2", tracks2)
    //    println("-------------json-------" + json)
    http_result = HttpClientUtil.getJsonByPostJson(compare_track_url, param.toString)
    Thread.sleep(900)

    http_result
  }
}
