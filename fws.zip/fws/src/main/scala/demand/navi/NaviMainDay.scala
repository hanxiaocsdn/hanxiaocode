package demand.navi

import com.alibaba.fastjson.JSONObject
import demand.utils._
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01368978 on 2021/5/28.
  * 单天的
  */
object NaviMainDay {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)



  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    val runDate = DateUtil.getToday

    logger.error("处理" + runDate)
    NaviLogParse.start(args: Array[String],spark,runDate,getOneDayDateList,fiterOneDayValidLog,oneDayRddToHive)

    spark.stop()
  }



  /**
    * 获取日期列表
    * @param endDate
    * @return
    */
  def getOneDayDateList(endDate:String): ArrayBuffer[String] ={
    val dateList = new ArrayBuffer[String]
    dateList += endDate
    dateList
  }



  /**
    * 过滤有效日志
    * @param spark
    * @param dateList
    * @param subType
    * @return
    */
  def fiterOneDayValidLog(spark:SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject])={
    val date = dateList(0)
    var sql=""
    var logRdd:RDD[JSONObject] = null
    var table = ""
    if(subType.contains("Result") && (subType.contains("V2") || subType.contains("path"))) table = "gis_navi_query_proto_hive"
    else table = "gis_navi_query_hive"
    if(subType.contains(",")){
      val subTypes = subType.split(",")
      val subType1 = subTypes(0)
      val subType2 = subTypes(1)
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day='$date'
           | and (get_json_object(data, '$$.subType') = '$subType1' or get_json_object(data, '$$.subType') = '$subType2')
       """.stripMargin
    }
    else{
      sql =
        s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day='$date'
           | and get_json_object(data, '$$.subType') = '$subType'
       """.stripMargin
    }
    logRdd = NaviLogParse.getValidLog(spark, sql)
    logRdd
  }



  /**
    * 保存到hive日志
    * @param spark
    * @param resultRdd
    * @param table
    * @param structs
    * @param keys
    * @param dateList
    * @return
    */
  def oneDayRddToHive(spark:SparkSession, resultRdd:RDD[JSONObject], table: String, structs:Array[String], keys:Array[String], dateList:ArrayBuffer[String]): Unit ={
    val date = dateList(0)
    NaviLogParse.filterRddToHive(spark,resultRdd,table,structs,keys,date)
  }


}
