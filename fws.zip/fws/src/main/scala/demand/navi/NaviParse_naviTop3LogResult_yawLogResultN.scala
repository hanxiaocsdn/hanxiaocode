package demand.navi

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import common.SourceAndDiskCommon
import demand.utils.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * @task_id: 262146
 * @description: 表2--导航计提top3出参表 gis_navi_top3_yaw_result_parse 单天45w左右数据量
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/10/18 10:46
 */
object NaviParse_naviTop3LogResult_yawLogResultN extends SourceAndDiskCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value

  def get3[T <% RDD[T]](value: T): RDD[T] = value

  def get4[T](value: T) = List(value)

  trait get5[-T, +U] {
    def apply(x: T): U
  }


  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)
    //传入参数，单天任务
    ParseLog(spark, args(0))
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    val dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    val runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getTop3AndYawLogRdd
    computeRddF = null
    table = "gis_navi_top3_yaw_result_parse"

    structs = Array("request_id", "top3_status", "top3_info", "err_status", "err_info", "route_count", "route_index", "routeid", "x1", "y1", "x2", "y2", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "routeid_out", "is_same", "is_match", "flen", "tlen", "highspeed_distance", "polyline", "linknum", "rc_distance", "links", "rdynsdlen", "rdynsdcnt", "req_time", "subtype", "rect_result", "strategy", "routetype", "merge_result", "is_econ", "service_id", "path_rule", "path_type", "path_pos", "limit_info", "is_lowrisk", "pathrule_num", "point_num", "area_num", "plantype")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)
  }

  /**
   * 获取naviConfigLog日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getTop3AndYawLogRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = "naviTop3V2LogResult,yawV2LogResult,slSerPlan"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    logger.error(">>>加载的原始数据总量为>>>>" + validRdd.count())
    val computeRdd = validRdd.flatMap(json => {
      val list = new ArrayBuffer[JSONObject]()
      if (json != null) {
        //原始逻辑
        if (json.getString("subType") == "naviTop3V2LogResult" || json.getString("subType") == "yawV2LogResult") {
          var inc_day = ""
          val reqtime = json.getString("reqTime").toLong
          if (reqtime != null) {
            inc_day = longToTime(reqtime).split(" ")(0).replaceAll("-", "")
          }
          json.put("top3status", json.getString("status"))
          json.put("top3info", json.getString("info"))
          json.put("errstatus", json.getString("err"))
          json.put("errinfo", json.getString("msg"))
          json.put("inc_day", inc_day)
          json.put("subtype", json.getString("subType"))
          json.put("requestid", json.getString("requestId"))
          json.put("reqtime", reqtime)
          val basePath = json.getJSONObject("basePath")
          val paths = json.getJSONArray("paths")

          if (basePath != null) {
            val linkAttributes = basePath.getJSONArray("linkAttributes")
            val rectResult = basePath.getString("rectResult")
            val origin = basePath.getString("origin")
            val destination = basePath.getString("destination")
            val pathes = basePath.getJSONArray("pathes")
            if (pathes != null && pathes.size() > 0) {
              val routecount = pathes.size()
              var j = 0
              val path0 = pathes.getJSONObject(0)
              var mergeResult = ""
              if (path0 != null) mergeResult = path0.getString("mergeResult")
              for (i <- 0.until(pathes.size())) { //todo 1
                val newjson = new JSONObject()
                val path = pathes.getJSONObject(i)
                Array("top3status", "top3info", "errstatus", "errinfo", "inc_day", "subtype", "requestid", "reqtime").map(key => {
                  newjson.put(key, json.getString(key))
                })
                val polylineX = path.getJSONArray("polylineX")
                val polylineY = path.getJSONArray("polylineY")
                handlePolyline(newjson, polylineX, polylineY)

                val segments = path.getJSONArray("segments")
                handleLinks(newjson, segments, linkAttributes)

                newjson.put("origin", origin)
                newjson.put("destination", destination)
                newjson.put("routecount", routecount)
                newjson.put("routeindex", i)
                newjson.put("routeid", path.getString("id"))
                newjson.put("duration", path.getString("duration"))
                newjson.put("distance", path.getString("distance"))
                newjson.put("tolldistance", path.getString("tollDistance"))
                newjson.put("tolls", path.getString("tolls"))
                newjson.put("src", path.getString("src"))
                newjson.put("trafficlightcount", path.getString("lightCount"))
                newjson.put("flen", path.getString("flen"))
                newjson.put("tlen", path.getString("tlen"))
                newjson.put("tlen", path.getString("tlen"))
                newjson.put("rcdistance", path.getString("rcDistance"))
                newjson.put("routeidout", path.getString("routeId"))
                newjson.put("issame", path.getString("isSame"))
                newjson.put("ismatch", path.getString("isMatch"))
                newjson.put("highspeeddistance", path.getString("highspeedDistance"))
                newjson.put("strategy", path.getString("strategy"))
                newjson.put("pathrule", path.getString("ruleInPath"))

                val swidList = path.getJSONArray("swidList")
                newjson.put("linknum", swidList.size())
                if (swidList != null) newjson.put("links", swidList.toString)
                if (rectResult != null) newjson.put("rectresult", rectResult)
                if (mergeResult != null) newjson.put("mergeresult", mergeResult)

                var pointnum = 0
                var areanum = 0
                val ruleInPath = path.getJSONArray("ruleInPath")
                if (ruleInPath != null && ruleInPath.size() > 0) {
                  val pathtype = new ArrayBuffer[String]()
                  val pathpos = new ArrayBuffer[String]()
                  val limitinfo = new ArrayBuffer[String]()
                  val islowrisk = new ArrayBuffer[String]()
                  for (ss <- 0.until(ruleInPath.size())) { //todo 2
                    val tmpRule = ruleInPath.getJSONObject(ss)
                    if (tmpRule != null) {
                      val _type = tmpRule.getString("type")
                      val pos = tmpRule.getJSONObject("pos")
                      val limitInfo = tmpRule.getString("limitInfo")
                      val isLowRisk = tmpRule.getString("isLowRisk")
                      var x = ""
                      var y = ""
                      if (pos != null) {
                        x = pos.getString("x")
                        y = pos.getString("y")
                      }
                      if ("5".equalsIgnoreCase(_type)) areanum = areanum + 1
                      else pointnum = pointnum + 1

                      if (!StringUtils.isEmpty(_type)) pathtype += _type
                      if (!StringUtils.isEmpty(x) && !StringUtils.isEmpty(y)) pathpos += x + "," + y
                      if (!StringUtils.isEmpty(limitInfo)) limitinfo += limitInfo
                      if (!StringUtils.isEmpty(isLowRisk)) islowrisk += isLowRisk
                    }
                  }
                  if (pathtype.nonEmpty) newjson.put("pathtype", pathtype.mkString(";"))
                  if (pathpos.nonEmpty) newjson.put("pathpos", pathpos.mkString(";"))
                  if (limitinfo.nonEmpty) newjson.put("limitinfo", limitinfo.mkString(";"))
                  if (islowrisk.nonEmpty) newjson.put("islowrisk", islowrisk.mkString(";"))

                  newjson.put("pathrulenum", ruleInPath.size())
                }
                else newjson.put("pathrulenum", "0")
                newjson.put("pointnum", pointnum)
                newjson.put("areanum", areanum)

                val src = path.getString("src")
                if ("jy".equalsIgnoreCase(src)) {
                  if (paths != null && paths.size() > j && paths.getJSONObject(j) != null) {
                    val _path = paths.getJSONObject(j)
                    if (_path != null) {
                      val routeId = _path.getString("routeId")
                      val isSame = _path.getString("isSame")
                      val isMatch = _path.getString("isMatch")
                      val routetype = _path.getString("routetype")
                      val isecon = _path.getString("isEcon")
                      if (!StringUtils.isEmpty(routeId)) newjson.put("routeId", routeId)
                      if (!StringUtils.isEmpty(isSame)) newjson.put("isSame", isSame)
                      if (!StringUtils.isEmpty(isMatch)) newjson.put("isMatch", isMatch)
                      if (!StringUtils.isEmpty(routetype)) newjson.put("routetype", routetype)
                      if (!StringUtils.isEmpty(isecon)) newjson.put("isecon", isecon)
                    }
                  }
                  j = j + 1
                }
                val requestid = newjson.getString("requestid")
                val routeidout = newjson.getString("routeidout")
                val routeid = newjson.getString("routeid")
                if (!(strNotNull(requestid) && strNotNull(routeidout) && strNotNull(routeid))) list += newjson
              }
            }
          }
        }
        //新增部分逻辑
        if (json.getString("planType") == "slSerPlan") {
          var requestid, inc_day, top3status, top3info, subtype = ""
          var reqtime: java.lang.Long = null
          val javaResultLst = json.getJSONArray("javaResultLst")

          if (javaResultLst != null && javaResultLst.size() > 0) {
            for (i <- 0 until javaResultLst.size()) {
              val newjson = new JSONObject()
              val pubres: JSONObject = javaResultLst.getJSONObject(i)
              subtype = json.getString("subType")
              requestid = pubres.getString("requestId")
              top3status = pubres.getString("status")
              top3info = pubres.getString("info")
              reqtime = pubres.getLong("reqTime")
              if (reqtime != null) {
                inc_day = longToTime(reqtime).split(" ")(0).replaceAll("-", "")
              }
              if (pubres != null) {
                val basePath = pubres.getJSONObject("basePath")
                if (basePath != null) {
                  val pathes = basePath.getJSONArray("pathes")
                  if (pathes != null && pathes.size() > 0) {
                    val pubpath = pathes.getJSONObject(0)
                    newjson.put("plantype", "slSerPlan")
                    newjson.put("reqtime", reqtime)
                    newjson.put("inc_day", inc_day)
                    newjson.put("requestid", requestid)
                    newjson.put("top3status", top3status)
                    newjson.put("top3info", top3info)
                    newjson.put("routecount", "1")
                    newjson.put("routeindex", "0")
                    newjson.put("routeid", pubpath.getString("id"))
                    newjson.put("origin", pubpath.getString("origin"))
                    newjson.put("destination", pubpath.getString("destination"))
                    newjson.put("duration", pubpath.getString("duration"))
                    newjson.put("distance", pubpath.getString("distance"))
                    newjson.put("tolldistance", pubpath.getString("tollDistance"))
                    newjson.put("tolls", pubpath.getString("tolls"))
                    newjson.put("src", pubpath.getString("src"))
                    newjson.put("trafficlightcount", pubpath.getString("lightCount"))
                    newjson.put("flen", pubpath.getString("flen"))
                    newjson.put("tlen", pubpath.getString("tlen"))
                    newjson.put("highspeeddistance", pubpath.getString("highspeedDistance"))
                    newjson.put("subtype", "naviTop3LogResult")
                    newjson.put("serviceid", "SL")

                    val polylineX = pubpath.getJSONArray("polylineX")
                    val polylineY = pubpath.getJSONArray("polylineY")
                    handlePolyline(newjson, polylineX, polylineY)
                    val swidList = pubpath.getJSONArray("swidList")
                    newjson.put("linknum", swidList.size())
                    if (swidList != null) newjson.put("links", swidList.toString)
                    newjson.put("strategy", pubpath.getString("strategy"))
                    //解析ruleInPath数组内的字段信息
                    var pointnum, areanum = 0
                    val ruleInPath = pubpath.getJSONArray("ruleInPath")
                    if (ruleInPath != null && ruleInPath.size() > 0) {
                      val pathtype = new ArrayBuffer[String]()
                      val pathpos = new ArrayBuffer[String]()
                      val limitinfo = new ArrayBuffer[String]()
                      val islowrisk = new ArrayBuffer[String]()
                      for (k <- 0.until(ruleInPath.size())) {
                        val tmpRule = ruleInPath.getJSONObject(k)
                        if (tmpRule != null) {
                          val _type = tmpRule.getString("type")
                          val pos = tmpRule.getJSONObject("pos")
                          val limitInfo = tmpRule.getString("limitInfo")
                          val isLowRisk = tmpRule.getString("isLowRisk")
                          var x = ""
                          var y = ""
                          if (pos != null) {
                            x = pos.getString("x")
                            y = pos.getString("y")
                          }
                          if ("5".equalsIgnoreCase(_type)) areanum = areanum + 1
                          else pointnum = pointnum + 1

                          if (!StringUtils.isEmpty(_type)) pathtype += _type
                          if (!StringUtils.isEmpty(x) && !StringUtils.isEmpty(y)) pathpos += x + "," + y
                          if (!StringUtils.isEmpty(limitInfo)) limitinfo += limitInfo
                          if (!StringUtils.isEmpty(isLowRisk)) islowrisk += isLowRisk
                        }
                      }
                      if (pathtype.nonEmpty) newjson.put("pathtype", pathtype.mkString(";"))
                      if (pathpos.nonEmpty) newjson.put("pathpos", pathpos.mkString(";"))
                      if (limitinfo.nonEmpty) newjson.put("limitinfo", limitinfo.mkString(";"))
                      if (islowrisk.nonEmpty) newjson.put("islowrisk", islowrisk.mkString(";"))

                      newjson.put("pathrulenum", ruleInPath.size())
                    }
                    else {
                      newjson.put("pathrulenum", "0")
                    }
                    newjson.put("pointnum", pointnum)
                    newjson.put("areanum", areanum)
                  }
                }
              }
              val requestid_key = newjson.getString("requestid")
              val routeidout_key = newjson.getString("routeidout")
              val routeid_key = newjson.getString("routeid")
              if (!(strNotNull(requestid_key) && strNotNull(routeidout_key) && strNotNull(routeid_key))) list += newjson
            }
          }
        }
      }
      list
    }).filter(_ != null)
      .map(json => {
        var requestid_key = ""
        if (json.getString("requestid") == null) {
          requestid_key = "" + "&_&" + Random.nextInt(1000).toString
        } else {
          requestid_key = json.getString("requestid") + "&_&" + Random.nextInt(1000).toString
        }
        json.put("requestid_key", requestid_key)
        val routeidout = json.getString("id")
        val routeid = json.getString("routeid")
        ((requestid_key, routeidout, routeid), json)
      })
      .groupByKey()
      .map(obj => {
        val json = obj._2.toList.head
        val requestid = json.getString("requestid_key").split("&_&")(0)
        val routeidout = json.getString("routeidout")
        val routeid = json.getString("routeid")
        ((requestid, routeidout, routeid), json)
      })
      .groupByKey()
      .map(obj => {
        val json = obj._2.toList.head
        json
      })
      .map(json => {
        if (json != null) {
          val origin = json.getString("origin")
          val destination = json.getString("destination")
          if (origin != null) {
            val coords = origin.split(",")
            if (coords != null && coords.nonEmpty) {
              val x = coords(0)
              json.put("x1", x)
              if (coords.length > 1) {
                val y = coords(1)
                json.put("y1", y)
              }
            }
          }
          if (destination != null) {
            val coords = destination.split(",")
            if (coords != null && coords.nonEmpty) {
              val x = coords(0)
              json.put("x2", x)
              if (coords.length > 1) {
                val y = coords(1)
                json.put("y2", y)
              }
            }
          }
        }
        json
      }).coalesce(500).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    computeRdd
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  /**
   * 处理polyline数据
   *
   * @param json
   */
  def handlePolyline(json: JSONObject, polylineX: JSONArray, polylineY: JSONArray): Unit = {
    val polyline = new JSONArray()

    var x: java.lang.Long = 0l
    var y: java.lang.Long = 0l

    if (polylineX != null && polylineY != null && polylineX.size() > 0 && polylineX.size() <= polylineY.size()) {
      for (i <- 0.until(polylineX.size())) {
        val X = polylineX.getLong(i)
        val Y = polylineY.getLong(i)
        x = x + X
        y = y + Y
        val tmpX = x.toDouble / 3600000
        val tmpY = y.toDouble / 3600000
        val xy = new JSONObject()
        xy.put("x", tmpX)
        xy.put("y", tmpY)
        polyline.add(xy)
      }
    }

    if (polyline != null && polyline.size() > 0) json.put("polyline", polyline)
  }

  /**
   * 处理link数据
   *
   * @param json
   */
  def handleLinks(json: JSONObject, segments: JSONArray, linkAttributes: JSONArray): Unit = {
    var drLength0List = new ArrayBuffer[Int]()
    var drLength1List = new ArrayBuffer[Int]()
    var drLength3List = new ArrayBuffer[Int]()
    val swids = new ArrayBuffer[String]()

    if (segments != null && segments.size() > 0) {
      for (i <- 0.until(segments.size())) {
        val segment = segments.getJSONObject(i)
        if (segment != null) {
          val linkSu = segment.getJSONArray("linkSu")
          if (linkSu == null || linkSu.size() == 0) {
            val links = segment.getJSONArray("links")
            if (links != null && links.size() > 0) {
              for (j <- 0.until(links.size())) {
                val link = links.getJSONObject(j)
                if (link != null) {
                  val drLength = link.getInteger("drLength")
                  val dynSpeed = link.getInteger("dynSpeed")
                  if (dynSpeed != null && drLength != null) {
                    if (dynSpeed == 0) {
                      drLength0List += drLength
                    } else if (dynSpeed == 1) {
                      drLength1List += drLength
                    } else if (dynSpeed >= 3 && dynSpeed <= 9) {
                      drLength3List += drLength
                    }
                  }

                  if (linkAttributes != null && linkAttributes.size() > 0) {
                    val attrIdx = link.getInteger("attrIdx")
                    if (attrIdx != null && attrIdx < linkAttributes.size()) {
                      val linkAttribute = linkAttributes.getJSONObject(attrIdx)
                      if (linkAttribute != null) {
                        val swId = linkAttribute.getString("swId")
                        if (!StringUtils.isEmpty(swId)) swids += swId
                      }
                    }
                  }
                }
              }
            }
          }
          else {
            for (i <- 0.until(linkSu.size())) {
              val linksu = linkSu.getJSONObject(i)
              if (linksu != null) {
                val swId = linksu.getString("swId")
                if (!StringUtils.isEmpty(swId)) swids += swId
              }
            }
          }


        }
      }
    }

    val drLength0Sum = drLength0List.sum
    val drLength1Sum = drLength1List.sum
    val drLength3Sum = drLength3List.sum
    val drLengthSum = drLength0Sum + drLength1Sum + drLength3Sum
    val drLength0SumRate = getRate(drLength0Sum, drLengthSum)
    val drLength1SumRate = getRate(drLength1Sum, drLengthSum)
    val drLength3SumRate = getRate(drLength3Sum, drLengthSum)
    val rdynsdlen = drLength1Sum + "_" + drLength1SumRate + "|" + drLength3Sum + "_" + drLength3SumRate + "|" + drLength0Sum + "_" + drLength0SumRate
    val drLength0Count = drLength0List.length
    val drLength1Count = drLength1List.length
    val drLength3Count = drLength3List.length
    val drLengthCount = drLength0Count + drLength1Count + drLength3Count
    val drLength0CountRate = getRate(drLength0Count, drLengthCount)
    val drLength1CountRate = getRate(drLength1Count, drLengthCount)
    val drLength3CountRate = getRate(drLength3Count, drLengthCount)
    val rdynsdcnt = drLength1Count + "_" + drLength1CountRate + "|" + drLength3Count + "_" + drLength3CountRate + "|" + drLength0Count + "_" + drLength0CountRate

    json.put("rdynsdlen", rdynsdlen)
    json.put("rdynsdcnt", rdynsdcnt)
  }

  def getRate(v1: Int, v2: Int): String = {
    var result = ""
    try {
      result = df.format(v1.toDouble / v2.toDouble)
    } catch {
      case e: Exception => logger.error(">>>除法异常")
    }
    result
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val table = "gis_eta_navi_query_proto_hive"
    var sql = ""
    //获取原始数据信息
    val subTypes = subType.split(",")
    val subType1 = subTypes(0)
    val subType2 = subTypes(1)
    val subType3 = subTypes(2)
    sql =
      s"""
         |select data,inc_day from dm_gis.$table t
         | where inc_day between '$startDate' and '$endDate'
         | and data like '%basePath%'
         | and (
         | get_json_object(data, '$$.subType') = '$subType1'
         | or get_json_object(data, '$$.subType') = '$subType2'
         | or get_json_object(data, '$$.planType') = '$subType3'
         | )
        """.stripMargin

    logger.error("取数sql:" + sql)
    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x)).repartition(1000).persist()
  }

  /**
   * 对给定的字符串 进行空值判断
   *
   * @param col列字段
   * @return 列类型
   */
  def strNotNull(str: Any): Boolean = {
    str match {
      case null => false
      case "null" => false
      case _ => !str.toString.isEmpty && str.toString.replaceAll("-", "").trim != ""
    }
  }
}