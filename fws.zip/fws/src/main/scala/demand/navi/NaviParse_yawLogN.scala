package demand.navi

import com.alibaba.fastjson.{JSON, JSONObject}
import common.SourceAndDiskCommon
import demand.utils.SparkUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 262196
 * @description:表4:dm_gis.gis_navi_yaw_parse
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/7/4 11:47
 */
object NaviParse_yawLogN extends SourceAndDiskCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null
  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    try {
      result.fluentPutAll(result.getJSONObject("data"))
    } catch {
      case e: Exception => logger.error("原始数据中无该目录" + str + ">>>>>>>>" + e.printStackTrace())
    }
    result.keySet().toArray.foreach(key => {
      if (result.get(key.toString).isInstanceOf[JSONObject]) {
        val temp = result.getJSONObject(key.toString)
        temp.keySet().toArray.foreach(k => {
          //### 此处保留原字段大小写 .toLowerCase
          result.put(k.toString.toLowerCase, temp.getString(k.toString))
        })
      }
    })
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(800).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value


  def get3[T <% RDD[T]](value: T): RDD[T] = value

  def get4[T](value: T) = List(value)

  trait get5[-T, +U] {
    def apply(x: T): U
  }

  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)
    //传入参数，单天任务
    ParseLog(spark, args(0))
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    val runDate = date

    getHiveRddF = fiterYawValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getYawRdd
    computeRddF = null
    table = "gis_navi_yaw_parse"

    structs = Array("task_id", "navi_id", "routeid", "app_ver", "vehicle_dir", "req_time", "startx", "starty", "endx", "endy", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plan_date", "plate_color", "energy", "emit_stand", "passport", "stype", "path_count", "opt", "strategy", "merge", "routeid_in", "fixed_route", "fencedist", "reroute", "starts", "swids", "request_id", "status", "req_start_time", "req_endtime", "req_costtime", "sfpnstop3_starttime", "sfpnstop3_endtime", "sfpnstop3_costtime", "jypnstop3_starttime", "jypnstop3_endtime", "jypnstop3_costtime", "ft_url", "max_detail_distance", "ak", "service_id", "line_code")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)

  }

  /**
   * 获取naviTop3Log日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getYawRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = "yawV2Log"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "的日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    val computeRdd = validRdd
      .map(json => {
        var routeid = ""
        var req_time: java.lang.Long = null
        if (json != null) {
          val data = json.getJSONObject("data")
          if (data != null) {
            val yawArgs = data.getJSONObject("yawArgs")
            if (yawArgs != null) {
              routeid = yawArgs.getString("routeId")
              req_time = yawArgs.getLong("reqTime")
              if (req_time != null) {
                val inc_day = longToTime(req_time).split(" ")(0).replaceAll("-", "")
                json.put("inc_day", inc_day)
              }
            }
          }
        }
        if (req_time == null) req_time = Long.MaxValue
        ((routeid, req_time), json)
      })
      .groupByKey()
      .map(obj => {
        val json = obj._2.toList.head
        json
      })
      .flatMap(json => {
        val list = new ArrayBuffer[JSONObject]()
        if (json != null) {
          val inc_day = json.getString("inc_day")
          val data = json.getJSONObject("data")
          if (data != null) {
            val baseObject = new JSONObject()
            if (true) {
              var task_id, navi_id, routeid, app_ver, vehicle_dir, req_time, status, req_start_time, req_endtime, req_costtime, sfpnstop3_starttime, sfpnstop3_endtime, sfpnstop3_costtime, jypnstop3_starttime, jypnstop3_endtime, jypnstop3_costtime, service_id = ""

              status = data.getString("status")
              req_start_time = data.getString("reqStartTime")
              req_endtime = data.getString("reqEndTime")
              req_costtime = data.getString("reqCostTime")
              sfpnstop3_starttime = data.getString("sfPnsTop3StartTime")
              sfpnstop3_endtime = data.getString("sfPnsTop3EndTime")
              sfpnstop3_costtime = data.getString("sfPnsTop3CostTime")
              jypnstop3_starttime = data.getString("jyPnsTop3StartTime")
              jypnstop3_endtime = data.getString("jyPnsTop3EndTime")
              jypnstop3_costtime = data.getString("jyPnsTop3CostTime")

              val yawArgs = data.getJSONObject("yawArgs")
              if (yawArgs != null) {
                task_id = yawArgs.getString("taskId")
                navi_id = yawArgs.getString("naviId")
                routeid = yawArgs.getString("routeId")
                app_ver = yawArgs.getString("appVer")
                vehicle_dir = yawArgs.getString("vehicleDir")
                req_time = yawArgs.getString("reqTime")
                service_id = yawArgs.getString("serviceId")
              }
              if (StringUtils.isEmpty(task_id)) task_id = ""
              if (StringUtils.isEmpty(navi_id)) navi_id = ""
              if (StringUtils.isEmpty(routeid)) routeid = ""
              if (StringUtils.isEmpty(app_ver)) app_ver = ""
              if (StringUtils.isEmpty(vehicle_dir)) vehicle_dir = ""
              if (StringUtils.isEmpty(req_time)) req_time = ""
              if (StringUtils.isEmpty(status)) status = ""
              if (StringUtils.isEmpty(req_start_time)) req_start_time = ""
              if (StringUtils.isEmpty(req_endtime)) req_endtime = ""
              if (StringUtils.isEmpty(req_costtime)) req_costtime = ""
              if (StringUtils.isEmpty(sfpnstop3_starttime)) sfpnstop3_starttime = ""
              if (StringUtils.isEmpty(sfpnstop3_endtime)) sfpnstop3_endtime = ""
              if (StringUtils.isEmpty(sfpnstop3_costtime)) sfpnstop3_costtime = ""
              if (StringUtils.isEmpty(jypnstop3_starttime)) jypnstop3_starttime = ""
              if (StringUtils.isEmpty(jypnstop3_endtime)) jypnstop3_endtime = ""
              if (StringUtils.isEmpty(jypnstop3_costtime)) jypnstop3_costtime = ""
              if (StringUtils.isEmpty(service_id)) service_id = ""

              baseObject.put("taskid", task_id)
              baseObject.put("naviid", navi_id)
              baseObject.put("routeid", routeid)
              baseObject.put("appver", app_ver)
              baseObject.put("vehicledir", vehicle_dir)
              baseObject.put("reqtime", req_time)
              baseObject.put("status", status)
              baseObject.put("reqstarttime", req_start_time)
              baseObject.put("reqendtime", req_endtime)
              baseObject.put("reqcosttime", req_costtime)
              baseObject.put("sfpnstop3starttime", sfpnstop3_starttime)
              baseObject.put("sfpnstop3endtime", sfpnstop3_endtime)
              baseObject.put("sfpnstop3costtime", sfpnstop3_costtime)
              baseObject.put("jypnstop3starttime", jypnstop3_starttime)
              baseObject.put("jypnstop3endtime", jypnstop3_endtime)
              baseObject.put("jypnstop3costtime", jypnstop3_costtime)
              baseObject.put("serviceid", service_id)
              baseObject.put("inc_day", inc_day)
            }

            val sfPnsTop3Args = data.getJSONObject("sfPnsTop3Args")
            val jyPnsTop3Args = data.getJSONObject("jyPnsTop3Args")
            val gdPnsTop3Args = data.getJSONObject("gdPnsTop3Args")

            if (sfPnsTop3Args != null) {
              val target1 = sfPnsTop3Args
              val target2 = jyPnsTop3Args
              val target3 = gdPnsTop3Args

              val resultJson = putValuesByOrder(target1, target2, target3, baseObject)
              if (resultJson != null) list += resultJson
            }

            if (jyPnsTop3Args != null) {
              val target1 = jyPnsTop3Args
              val target2 = gdPnsTop3Args
              val target3 = sfPnsTop3Args

              val resultJson = putValuesByOrder(target1, target2, target3, baseObject)
              if (resultJson != null) list += resultJson
            }

            if (gdPnsTop3Args != null) {
              val target1 = gdPnsTop3Args
              val target2 = jyPnsTop3Args
              val target3 = sfPnsTop3Args

              val resultJson = putValuesByOrder(target1, target2, target3, baseObject)
              if (resultJson != null) list += resultJson
            }

          }
        }

        list
      })
      .repartition(repartition).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()

    computeRdd
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterYawValidLog(spark: SparkSession, dateList: ArrayBuffer[String], logType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val table = "gis_eta_navi_query_hive"
    val sql =
      s"""
         |select data,inc_day from dm_gis.$table t
         | where inc_day between '$startDate' and '$endDate'
         | and get_json_object(data, '$$.subType') = '$logType'
        """.stripMargin
    logger.error("执行的sql语句：" + sql)
    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x))
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  /**
   * 1
   *
   * @param target1
   * @param target2
   * @param target3
   * @param key
   * @param resultJson
   * @param field
   * @return
   */
  def putValueByOrder(target1: JSONObject, target2: JSONObject, target3: JSONObject, key: String, resultJson: JSONObject, field: String): Unit = {
    val value = getValueByOrder(target1, target2, target3, key)
    if (value != null) resultJson.put(field, value)
  }

  /**
   * 1
   *
   * @param target1
   * @param target2
   * @param target3
   * @param key
   * @return
   */
  def getValueByOrder(target1: JSONObject, target2: JSONObject, target3: JSONObject, key: String): java.lang.String = {
    var value = ""
    if (target1 != null) {
      value = target1.getString(key)
    }
    if (StringUtils.isEmpty(value) && target2 != null) {
      value = target2.getString(key)
    }
    if (StringUtils.isEmpty(value) && target3 != null) {
      value = target3.getString(key)
    }
    if (StringUtils.isEmpty(value)) value = null
    value
  }

  /**
   * 1
   *
   * @param target1
   * @param target2
   * @param target3
   * @param baseObject
   * @return
   */
  def putValuesByOrder(target1: JSONObject, target2: JSONObject, target3: JSONObject, baseObject: JSONObject): JSONObject = {
    var resultJson: JSONObject = null
    if (target1 != null) {
      val request_id = target1.getString("requestId")
      if (!StringUtils.isEmpty(request_id)) {
        resultJson = new JSONObject()
        resultJson.fluentPutAll(baseObject)
        resultJson.put("requestid", request_id)

        val ft_url = getUrlPost(target1, "http://10.206.169.158:8080/rp/navi/v2/top3?") //http://gis-int.int.sfdc.com.cn:1080/rp/navi/top3
        resultJson.put("fturl", ft_url)

        val origin = getValueByOrder(target1, target2, target3, "origin")
        if (origin != null) {
          val coords = origin.split(",")
          if (coords != null && coords.nonEmpty) {
            val x = coords(0)
            resultJson.put("startx", x)
            if (coords.length > 1) {
              val y = coords(1)
              resultJson.put("starty", y)
            }
          }
        }

        val destination = getValueByOrder(target1, target2, target3, "destination")
        if (destination != null) {
          val coords = destination.split(",")
          if (coords != null && coords.nonEmpty) {
            val x = coords(0)
            resultJson.put("endx", x)
            if (coords.length > 1) {
              val y = coords(1)
              resultJson.put("endy", y)
            }
          }
        }

        putValueByOrder(target1, target2, target3, "plate", resultJson, "vehicle")
        putValueByOrder(target1, target2, target3, "vehicle", resultJson, "vehicletype")
        putValueByOrder(target1, target2, target3, "weight", resultJson, "weight")
        putValueByOrder(target1, target2, target3, "mload", resultJson, "mload")
        putValueByOrder(target1, target2, target3, "size", resultJson, "length")
        putValueByOrder(target1, target2, target3, "width", resultJson, "width")
        putValueByOrder(target1, target2, target3, "height", resultJson, "height")
        putValueByOrder(target1, target2, target3, "axleWeight", resultJson, "axleweight")
        putValueByOrder(target1, target2, target3, "axleNumber", resultJson, "axlenumber")
        putValueByOrder(target1, target2, target3, "planDate", resultJson, "plandate")
        putValueByOrder(target1, target2, target3, "plateColor", resultJson, "platecolor")
        putValueByOrder(target1, target2, target3, "energy", resultJson, "energy")
        putValueByOrder(target1, target2, target3, "emitStand", resultJson, "emitstand")
        putValueByOrder(target1, target2, target3, "passport", resultJson, "passport")
        putValueByOrder(target1, target2, target3, "stype", resultJson, "stype")
        putValueByOrder(target1, target2, target3, "pathCount", resultJson, "pathcount")
        putValueByOrder(target1, target2, target3, "opt", resultJson, "opt")
        putValueByOrder(target1, target2, target3, "strategy", resultJson, "strategy")
        putValueByOrder(target1, target2, target3, "merge", resultJson, "merge")
        putValueByOrder(target1, target2, target3, "routeId", resultJson, "routeidin")
        putValueByOrder(target1, target2, target3, "fixedRoute", resultJson, "fixedroute")
        putValueByOrder(target1, target2, target3, "fencedist", resultJson, "fencedist")
        putValueByOrder(target1, target2, target3, "reRoute", resultJson, "reroute")
        putValueByOrder(target1, target2, target3, "starts", resultJson, "starts")
        putValueByOrder(target1, target2, target3, "swids", resultJson, "swids")
        putValueByOrder(target1, target2, target3, "lineCode", resultJson, "linecode")
      }
    }

    resultJson
  }

  def getUrlPost(json: JSONObject, url: String): String = {
    var resultUrl = url
    if (json != null) resultUrl = url + ":" + json.toJSONString
    resultUrl
  }
}
