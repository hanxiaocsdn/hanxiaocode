package demand.navi

import java.lang.String

import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date}

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject => js}

import java.util
import demand.navi.NaviUtils._

import demand.utils._

import demand.utils.SparkUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.{RDD => rd}

import org.apache.spark.sql.types.{DataTypes => dt, StructField => sf}
import org.apache.spark.sql.{DataFrame => dF, Row => Ro, RowFactory => Rof, SparkSession => ss}

import scala.collection.mutable.{ArrayBuffer => ab}

import scala.util.matching.{Regex => rgx}





@an
object NaviUtils {
  val $ = this.getClass.getSimpleName.stripPrefix("$")
  val logger = Logger.getLogger($)
  var s:ss = null
  var partition = 100

  type rdjs = rd[js]

  type rdu = (rdjs, String) => Unit

  type com = rdjs => rdjs

  type rdf = (ss,(ss,ab[String],String) => rdjs,ab[String]) => rdjs

  trait g5[-T, +U] {def apply(x: T): U}


  def frth(rr:rdjs, d:String, rd:rdu): Unit = rd(rr,d)

  def frd(rr:rdjs, d:String): rdjs ={
    val dr = rr.filter(j=>{
      val id = j.getString("inc_date")
      id!=null && id.equals(d)
    }).persist()
    dr
  }

  def svh(rr:rdjs, dl:ab[String], rd:rdu): Unit ={
    for(d<-dl){
      val rr2 = frd(rr,d)
      frth(rr2,d,rd)
    }
    rr.unpersist()
  }


  trait dl {
    def getdl: String => ab[String] = null
    var dl :ab[String] = _
  }

  trait sa {
    var par = 100
    val db: String = "dm_gis"
    var n = "navi"

    def sa(rr: rdjs, date: String):Unit = null
  }

  trait log {
    val logType = "NaviLog"
  }

  trait grf {
    def grf(vr:rdjs):rdjs = null
  }

  trait fmjv {
    def fmjv(sql:String): rdjs = null
  }

  trait fmjv2 extends fmjv {
    override
    def fmjv(l:String): rdjs={
      val df = s.sql(l)
      val f = df.schema.fields
      val h = f.map(_.name)
      val r = df.na.fill("").rdd.repartition(6400).map(row=>{
        val j = new js()
        val x = row.getValuesMap[String](h)
        x.keys.foreach(s1 => j.put(s1.toString,x(s1)))
        j
      }).filter(_!=null).persist()
      logger.error(">>>日志量："+r.count())
      r
    }
  }

  trait dt {
    var date:String = _
  }

  trait fmdv {
    def fmdv(): String = null
  }

  trait fmdvlog extends fmdv with log with dl {
    override
    def fmdv(): String={
      val startDate = dl(0)
      val endDate = dl(dl.size - 1)
      var sql=""
      var table = ""
      if(logType.contains("msNaviLog")) table = "gis_eta_ms_navi_hive"
      else if(logType.contains("Result") && (logType.contains("V2") || logType.contains("path"))) table = "gis_eta_navi_query_proto_hive"
      else table = "gis_eta_navi_query_hive"
      if(logType.contains("msNaviLog"))
        sql =
          s"""
         |select data,inc_day from dm_gis.$table t
         | where inc_day between '$startDate' and '$endDate'
       """.stripMargin
      else if(logType.contains(",")){
        val subTypes = logType.split(",")
        val subType1 = subTypes(0)
        val subType2 = subTypes(1)
        sql =
          s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate'
           | and (get_json_object(data, '$$.subType') = '$subType1' or get_json_object(data, '$$.subType') = '$subType2')
       """.stripMargin
      }
      else{
        sql =
          s"""
           |select data,inc_day from dm_gis.$table t
           | where inc_day between '$startDate' and '$endDate'
           | and get_json_object(data, '$$.subType') = '$logType'
       """.stripMargin
      }
      sql
    }
  }

  @script
  abstract class navi extends Serializable with dl with sa with grf with fmdv with fmjv with dt {
    val $:String = this.getClass.getSimpleName.stripPrefix("$")

    def apply(d: String): Unit = {
      date = d
      s = SparkUtil.getSparkSession($)
      pl(d)
      s.stop()
      logger.error(">>>处理完毕---------------")
    }

    def pl(d:String): Unit ={
      dl = getdl(d)
      val ecrd = grf(fmjv(fmdv()))
      svh(ecrd,dl,sa)
    }


  }
  @script
  abstract class type1 extends navi with fmdvlog
  @script
  abstract class type2 extends navi
  @script
  abstract class type3 extends navi
  @script
  abstract class type4 extends navi
  @script
  abstract class type5 extends navi with fmdvlog




}


class Navi[-T<:fmdv, +U>:navi] {

  def start[W <: T](t: W) : navi = {
    val ru = scala.reflect.runtime.universe
//    ru.typeOf[W]
    val x = t.getClass.newInstance()
    x.asInstanceOf[navi]
  }

}