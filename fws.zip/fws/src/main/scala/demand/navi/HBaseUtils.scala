package demand.navi

import org.apache.hadoop.hbase.HBaseConfiguration
//import org.apache.hadoop.hbase.client.{HBaseAdmin, HTable}

/**
  * Created by 01368978 on 2020/9/21.
  */

object HBaseUtils {

  /**
    * 设置HBaseConfiguration
    * @param quorum
    * @param port
    * @param tableName
    */
  def getHBaseConfiguration(quorum:String, port:String, tableName:String) = {
    val conf = HBaseConfiguration.create()
    conf.set("hbase.zookeeper.quorum",quorum)
    conf.set("hbase.zookeeper.property.clientPort",port)

    conf
  }

//  /**
//    * 返回或新建HBaseAdmin
//    * @param conf
//    * @param tableName
//    * @return
//    */
//  def getHBaseAdmin(conf:Configuration,tableName:String) = {
//    val admin = new HBaseAdmin(conf)
//    if (!admin.isTableAvailable(tableName)) {
//      val tableDesc = new HTableDescriptor(TableName.valueOf(tableName))
//      admin.createTable(tableDesc)
//    }
//
//    admin
//  }

//  /**
//    * 返回HTable
//    * @param conf
//    * @param tableName
//    * @return
//    */
//  def getTable(conf:Configuration,tableName:String) = {
//    new HTable(conf,tableName)
//  }
}
