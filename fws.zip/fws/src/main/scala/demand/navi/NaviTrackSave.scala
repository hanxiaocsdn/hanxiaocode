package demand.navi

import java.util.Calendar
import com.alibaba.fastjson.JSONObject
import demand.eta.EtaLogParse
import demand.utils.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ArrayBuffer


/**
  * Created by 01368978 on 2021/7/23.
  */
object NaviTrackSave {
  val excute = true
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    if(!excute) {
      logger.error("不执行程序")
      logger.error("the end ...")
      return
    }

    val spark = SparkUtil.getSparkSession(appName)

    logger.error("获取和设置日期...")
    var runDate = ""
    var argcount = args.length
    if(argcount == 0) argcount = 1
    for (i <- 0 to argcount - 1) {
      if (args.length == 0) {
        val format = FastDateFormat.getInstance("yyyyMMdd")
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_MONTH, -1)
        runDate = format.format(calendar.getTime)
      }
      else {
        runDate = args(i)
      }


//      navi(spark, runDate)
      batchTask(spark, "20210128","20210204")


    }
    spark.stop()
    logger.error("the end ...")

  }





  /**
    * 批量任务
    *
    * @param spark
    * @param startDate
    * @param endDate
    */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      navi(spark, date)
    }
  }


  def navi(spark: SparkSession, runDate: String) : Unit = {
    val endDate = runDate
    val format = FastDateFormat.getInstance("yyyyMMdd")
    val calendar = Calendar.getInstance()
    calendar.setTime(format.parse(runDate))
    val startDate = endDate
//    calendar.add(Calendar.DAY_OF_MONTH, -1)
//    val startDate = format.format(calendar.getTime)

//    calendar.add(Calendar.DAY_OF_MONTH, -1)
//    val beforeDate = format.format(calendar.getTime)
//    calendar.add(Calendar.DAY_OF_MONTH, -1)
//    val startDate = format.format(calendar.getTime)

    val dateList = new ArrayBuffer[String]()
    dateList += endDate
//    val dateList = Array(startDate,endDate)
//    val dateList = Array(startDate,beforeDate,endDate)

    logger.error("开始处理" + runDate)

    logger.error("读取dm_gis.gis_navi_result_union的三天信息")
    var flag_sql =
      s"""select * from dm_gis.gis_navi_result_union where inc_day between '$startDate' and '$endDate' limit 1
       """.stripMargin
    val gis_navi_result_union_count = spark.sql(flag_sql)
    val gis_navi_result_union_flag = gis_navi_result_union_count.take(1).length == 0

    logger.error(flag_sql)
    if(gis_navi_result_union_flag){
      logger.error("没有从gis_navi_result_union获取到数据，放弃执行！")
    }
    else{
      logger.error("开始从gis_navi_result_union获取数据")
      var gis_navi_result_union_sql = ""

      gis_navi_result_union_sql =
        s"""
           |	select a.task_id,a.navi_id,a.vehicle,a.navi_starttime,a.navi_endtime,b.type,b.time,'' as x,'' as y,b.voice,b.line_image,b.crossing_img,'' as coords_type,'' as speed,'' as azimuth,'' as accuracy,'' as sate,'' as tracks_type,a.inc_date from
           |		(select task_id,navi_id,vehicle,navi_starttime,cast(cast(navi_starttime as bigint) - 120000 as string) navi_starttime2,navi_endtime,inc_day as inc_date from dm_gis.gis_navi_result_union where inc_day between '$startDate' and '$endDate' and route_order='0') a
           |		left join (select navi_id,type,report_time as time,voice_info as voice,lane_id as line_image,cross_id as crossing_img from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' and type in ('4','5','6') and report_time is not null and report_time<>'') b on a.navi_id=b.navi_id
           |	union all
           |	select a.task_id,a.navi_id,a.vehicle,a.navi_starttime,a.navi_endtime,b.type,b.time,b.x,b.y,'' as voice,'' as line_image,'' as crossing_img,b.coords_type,b.speed,b.azimuth,b.accuracy,b.sate,b.tracks_type,a.inc_date from
           |		(select task_id,navi_id,vehicle,navi_starttime,cast(cast(navi_starttime as bigint) - 120000 as string) navi_starttime2,navi_endtime,inc_day as inc_date from dm_gis.gis_navi_result_union where inc_day between '$startDate' and '$endDate' and route_order='0' and navi_starttime is not null and navi_starttime<>'' and navi_endtime is not null and navi_endtime<>'') a
           |		left join (select carno as vehicle,'1' as type,tm as time,x,y,tp as coords_type,sp as speed,be as azimuth,ac as accuracy,sl as sate,case when ak in ('305','330','332') then '1' when ak in ('306','331','333') then '2' else '' end tracks_type from dm_gis.gis_rss_eta_navi_track_flatmap where inc_day between '$startDate' and '$endDate' and tm is not null and tm<>'') b on a.vehicle=b.vehicle where b.time>=a.navi_starttime2 and b.time<=a.navi_endtime
       """.stripMargin
      logger.error(gis_navi_result_union_sql)
      val fieldRdd = getValidJson(spark, gis_navi_result_union_sql)

      logger.error(">>>Navi导航轨迹保存")
      val table = "gis_navi_track_result_save"
      val structs = Array("task_id","navi_id","vehicle","navi_starttime","navi_endtime","type","time","x","y","voice","line_image","crossing_img","coords_type","speed","azimuth","accuracy","sate","tracks_type")
      val keys = Array("task_id","navi_id","vehicle","navi_starttime","navi_endtime","type","time","x","y","voice","line_image","crossing_img","coords_type","speed","azimuth","accuracy","sate","tracks_type")
      mutiDayRddToHive(spark,fieldRdd,table,structs,keys,dateList)

      fieldRdd.unpersist()


    }


  }



  /**
    * 保存到hive日志
    * @param spark
    * @param resultRdd
    * @param table
    * @param structs
    * @param keys
    * @param dateList
    * @return
    */
  def mutiDayRddToHive(spark:SparkSession, resultRdd:RDD[JSONObject], table: String, structs:Array[String], keys:Array[String], dateList:ArrayBuffer[String]): Unit ={
    for(date<-dateList){
      val resultRdd2 = filterRdd(resultRdd,date)
      EtaLogParse.filterRddToHive(spark,resultRdd2,table,structs,keys,date)
    }
    //    val resultRdd2 = filterRdd(resultRdd,dateList(0))
    //    EtaLogParse.filterRddToHive(spark,resultRdd2,table,structs,keys,dateList(0))
    resultRdd.unpersist()
  }


  /**
    * 过滤有效日志
    * @param spark
    * @param sql
    * @return
    */
  def getValidJson(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(6400).map(row=>{
      val json = new JSONObject()
      for(i<-fields.indices){
        var value = row.getString(i)
        if(StringUtils.isEmpty(value) || "null".equalsIgnoreCase(value)) value = ""
        json.put(header(i),value)
      }
      json
    }).filter(_!=null).repartition(6400).persist()
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }



  /**
    * 过滤日志
    * @param resultRdd
    * @param date
    * @return
    */
  def filterRdd(resultRdd:RDD[JSONObject], date:String): RDD[JSONObject] ={
    val dateRdd = resultRdd.filter(json=>{
      val inc_date = json.getString("inc_date")
      inc_date!=null && inc_date.equals(date)
    }).persist()

    dateRdd
  }



}
