package demand.navi

import com.alibaba.fastjson.JSONObject
import demand.utils.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.DecimalFormat
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 424770
 * @description: gis_gd_sdk_yaw_route
 * @demander:80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/12/27 17:07
 */
object GDParse_yawroute {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 100

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }

    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getGDParse_yawrouteRdd
    computeRddF = null
    table = "gis_gd_sdk_yaw_route"
    structs = Array("taskid", "naviid", "reqtime", "datatime", "sdk_ver", "routeid", "ak", "vehicle", "starttime", "endtime", "endtype", "startx", "starty", "endx", "endy", "routetype", "coords", "yawrouteid", "coordyaw")
    keys = Array("taskid", "naviid", "reqtime", "datatime", "sdk_ver", "routeid", "ak", "vehicle", "starttime", "endtime", "endtype", "startx", "starty", "endx", "endy", "routetype", "coords", "yawrouteid", "coordyaw")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }

  /**
   * 解析日志主流程
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  def getGDParse_yawrouteRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    val dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    var runDate = ""
    if ("3".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = DateUtil.getDateStr(date, -1)
      }
      else {
        runDate = date
      }
      dateList += runDate
    }

    logger.error(">>>获取" + runDate + "号的Navi关联偏航")
    val sql =
      s"""
         |select a.taskid,a.naviid,a.reqtime,a.datatime,a.sdk_ver,a.routeid,a.ak,a.vehicle,b.starttime,b.yawrouteid,b.coordyaw,c.endtime,c.endtype,d.startx,d.starty,d.endx,d.endy,d.routetype,d.coords,a.inc_date from
         |(select taskid,naviid,reqtime,datatime,sdk_ver,routeid,ak,vehicle,inc_day as inc_date from dm_gis.gis_gd_sdk_top3_route where inc_day='$date') a
         |left join (select routeid,reqtime as starttime,yawrouteid,coordyaw from dm_gis.gis_gd_sdk_yaw where inc_day='$date') b on a.routeid=b.routeid
         |left join (select routeid,reqtime as endtime,endtype from dm_gis.gis_gd_sdk_naviend where inc_day='$date') c on a.routeid=c.routeid
         |left join (select routeid,startx,starty,endx,endy,routetype,coords from dm_gis.gis_gd_sdk_route where inc_day='$date' and routetype<>'0' and routeid is not null and routeid<>'') d on b.yawrouteid=d.routeid
       """.stripMargin
    val resultRdd = NaviLogParse.getValidJson(spark, sql).persist()
    logger.error(">>>日志量：" + resultRdd.count())
    resultRdd.unpersist()
    (resultRdd, dateList)
  }

}
