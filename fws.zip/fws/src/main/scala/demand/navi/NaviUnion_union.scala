package demand.navi

import com.alibaba.fastjson.JSONObject
import demand.utils.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * @task_id:(20230615 已下线) 262706
 * @description:gis_navi_result_union
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/3/13 15:28
 */
object NaviUnion_union {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 500

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }

    spark.stop()
    logger.error(">>>处理完毕---------------")
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getUnionResultRdd
    computeRddF = null
    table = "gis_navi_result_union"
    structs = Array("task_id", "navi_id", "navi_count", "navi_order", "route_count", "route_order", "route_count_all", "routeid", "hasyaw", "src_province", "dest_province", "src_citycode", "dest_citycode", "src_deptcode", "dest_deptcode", "navi_starttime", "req_time", "route_type", "x1", "y1", "x2", "y2", "vehicle", "driver_id", "sdk_version", "route_src", "ft_url", "status", "polyline", "tracks", "segement", "navi_endstatus", "navi_endtime", "endx", "endy", "navi_endtype", "navi_cost", "navi_distance", "route_cost", "system", "ak", "start_speed", "vehicle_dir1", "rect_result", "strategy", "routetype", "merge_result", "starts", "starttime_type", "driver_type", "start_type", "is_econ", "service_id", "line_code", "navi_type", "pull_navitype")
    keys = Array("task_id", "navi_id", "navi_count", "navi_order", "route_count", "route_order", "route_count_all", "routeid", "hasyaw", "src_province", "dest_province", "src_citycode", "dest_citycode", "src_deptcode", "dest_deptcode", "navi_starttime", "req_time", "route_type", "x1", "y1", "x2", "y2", "vehicle", "driver_id", "sdk_version", "route_src", "ft_url", "status", "polyline", "tracks", "segement", "navi_endstatus", "navi_endtime", "endx", "endy", "navi_endtype", "navi_cost", "navi_distance", "route_cost", "system", "ak", "start_speed", "vehicle_dir1", "rect_result", "strategy", "routetype", "merge_result", "starts", "starttime_type", "driver_type", "start_type", "is_econ", "service_id", "line_code", "navi_type", "pull_navitype")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }


  /**
   * 解析日志主流程
   *
   * @param spark
   * @param getRddF
   * @param computeRddF
   * @param table
   * @param structs
   * @param keys
   * @param saveHiveRddF
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  /**
   * 获取导航结果汇总
   *
   * @param spark
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def getUnionResultRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    val dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    dateList += date
    var sql = ""
    val startDate = DateUtil.getDateStr(date, -2)
    val endDate = date
    val endDate1 = DateUtil.getDateStr(date, 1)
    sql =
      s"""
         |select a.task_id,a.navi_id,a.routeid,a.hasyaw,a.src_province,a.dest_province,a.src_citycode,a.dest_citycode,a.src_deptcode,a.dest_deptcode,a.navi_starttime,a.req_time,a.route_type,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.driver_id,a.route_src,a.ft_url,a.status,a.ak,a.polyline,a.start_speed,a.vehicle_dir1,a.rect_result,a.strategy,a.routetype,a.merge_result,a.starts,a.starttime_type,a.driver_type,a.is_econ,a.service_id,a.line_code,a.navi_type,a.pull_navitype,b.sdk_version,b.start_type,c.navi_endstatus,c.navi_endtime,c.endx,c.endy,c.navi_endtype,d.navi_distance,a.inc_day,a.inc_day as inc_date from
         |(select task_id,navi_id,routeid,'' as hasyaw,src_province,dest_province,src_citycode,dest_citycode,src_deptcode,dest_deptcode,navi_starttime,req_time,'top3' as route_type,x1,y1,x2,y2,vehicle,driver_id,src as route_src,ft_url,status,ak,polyline,start_speed,vehicle_dir1,rect_result,strategy2 as strategy,routetype,merge_result,starts,starttime_type,driver_type,is_econ,service_id,line_code,navi_type,pull_navitype,inc_day from dm_gis.gis_navi_top3_click_route where inc_day between '$startDate' and '$endDate' union all
         |select task_id,navi_id,routeid,hasyaw,src_province,dest_province,src_citycode,dest_citycode,src_deptcode,dest_deptcode,navi_starttime,req_time,'yaw' as route_type,x1,y1,x2,y2,vehicle,driver_id,src as route_src,ft_url,status,ak,polyline,'' as start_speed,'' as vehicle_dir1,rect_result,strategy2 as strategy,routetype,merge_result,starts,'' as starttime_type,'' as driver_type,is_econ,service_id,line_code,navi_type,pull_navitype,inc_day from dm_gis.gis_navi_yaw_route where inc_day between '$startDate' and '$endDate') a
         |left join (select navi_id,max(sdk_ver) as sdk_version,max(start_type) as start_type from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$startDate' and '$endDate' group by navi_id) b on a.navi_id=b.navi_id
         |left join (select navi_id,max(status) as navi_endstatus,max(navi_endtime) as navi_endtime,max(navi_endx) as endx,max(navi_endy) as endy,max(navi_endtype) as navi_endtype from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate' group by navi_id) c on a.navi_id=c.navi_id
         |left join (select navi_id,len as navi_distance from dm_gis.gis_navi_rectify_result where inc_day between '$startDate' and '$endDate') d on a.navi_id=d.navi_id
       """.stripMargin
    val resultRdd = NaviLogParse.getValidJson(spark, sql).persist()
    logger.error(">>>日志量：" + resultRdd.count())

    val computeRdd = resultRdd
      .map(json => {
        if (json != null) {
          try {
            val navi_id = json.getString("navi_id")
            val navi_starttime = json.getLong("navi_starttime")
            val navi_endtime = json.getLong("navi_endtime")
            val req_time = json.getLong("req_time")
            if (navi_starttime != null && navi_endtime != null) {
              val navi_cost = navi_endtime - navi_starttime
              json.put("navi_cost", navi_cost)
            }
            if (req_time != null && navi_endtime != null) {
              val route_cost = navi_endtime - req_time
              json.put("route_cost", route_cost)
            }
            var system = ""
            if (!StringUtils.isEmpty(navi_id)) {
              if (navi_id.endsWith("0")) system = "android"
              else if (navi_id.endsWith("1")) system = "ios"
            }
            json.put("system", system)
          }
          catch {
            case e: Exception => logger.error(">>>日志转json失败：" + e)
          }
        }

        val task_id = json.getString("task_id")
        val navi_id = json.getString("navi_id")
        var req_time = json.getLong("req_time")

        if (req_time == null) req_time = Long.MaxValue

        ((task_id, navi_id), (req_time, json))
      })
      .groupByKey()
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()

        val jsonList = obj._2.toList.groupBy(item => item._2.getString("routeid"))
          .map(item => {
          val sortList = item._2.toList.sortBy(_._1)
          val minReqTime = sortList.head._1
          (minReqTime, sortList.map(_._2))
        }).toList.sortBy(_._1).map(_._2)

        var route_count = obj._2.toList.filter(item => "true".equalsIgnoreCase(item._2.getString("hasyaw")))
          .groupBy(item => item._2.getString("routeid")).keys.size

        if (route_count > 0) route_count = route_count - 1

        val route_count_all = jsonList.size
        for (i <- jsonList.indices) {
          val jsonList2 = jsonList(i)
          for (j <- jsonList2.indices) {
            val json = jsonList2(j)
            json.put("route_count", route_count)
            json.put("route_order", j)
            json.put("route_count_all", route_count_all)
            list += json
          }
        }
        list
      })

      .map(json => {
        val task_id = json.getString("task_id")
        var req_time = json.getLong("req_time")

        if (req_time == null) req_time = Long.MaxValue

        (task_id, (req_time, json))
      })
      .groupByKey()
      .flatMap(obj => {
        val list = new ArrayBuffer[JSONObject]()

        val jsonList = obj._2.toList.groupBy(item => item._2.getString("navi_id")).map(item => {
          val sortList = item._2.toList.sortBy(_._1)
          val minReqTime = sortList.head._1
          (minReqTime, sortList.map(_._2))
        }).toList.sortBy(_._1).map(_._2)

        val navi_count = jsonList.size
        for (i <- jsonList.indices) {
          val jsonList2 = jsonList(i)
          for (j <- jsonList2.indices) {
            val json = jsonList2(j)
            json.put("navi_order", j)
            json.put("navi_count", navi_count)
            list += json
          }
        }
        list
      })
    resultRdd.unpersist()
    (computeRdd, dateList)
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }


  /**
   * 时间戳转换为时分秒
   *
   * @param date
   * @return
   */
  def dateToTimeStamp(date: String, format: String = "yyyyMMdd"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      val time = sdf.parse(date).getTime
      datetime = time.toString
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

}
