package demand.navi

import com.alibaba.fastjson.JSONObject
import demand.utils._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window.orderBy
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.text.DecimalFormat
import scala.collection.mutable.ArrayBuffer
import scala.util.Random
import scala.util.control.Breaks.{break, breakable}

/**
 * Created by 01368978 on 2021/5/28. 262437
 */
object NaviUnion_clickroute {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 500

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)
    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getTop3ClickRouteRdd
    computeRddF = null
    table = "gis_navi_top3_click_route"
    //    table = "table11"
    structs = Array("task_id", "navi_id", "navi_starttime", "routeid", "route_index", "request_id", "req_time", "src_province", "src_citycode", "src_deptcode", "dest_province", "dest_citycode", "dest_deptcode", "x1", "y1", "x2", "y2", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plate_color", "energy", "emit_stand", "passport", "driver_id", "ft_url", "plan_date", "stype", "path_count", "opt", "strategy", "merge", "routeid_in", "fixed_route", "fencedist", "status", "pns_status", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "highspeed_distance", "flen", "tlen", "routeid_out", "polyline", "linknum", "rc_distance", "links", "rdynsdlen", "rdynsdcnt", "ak", "start_speed", "vehicle_dir1", "rect_result", "strategy2", "routetype", "merge_result", "starts", "starttime_type", "driver_type", "is_econ", "service_id", "line_code", "navi_type", "gd_polyline", "top3_reqtype", "path_rule", "path_type", "path_pos", "limit_info", "is_lowrisk", "pathrule_num", "point_num", "area_num", "pull_navitype",
      "start_dept", "end_dept", "vehicle_type_navi", "stdmatchtype", "passzonetype", "cachestdid", "linerequireid", "passzonetableid", "cachestdblockroad", "nostdreasontype", "nostdreasondetail"
    )
    keys = Array("task_id", "navi_id", "navi_starttime", "routeid", "route_index", "request_id", "req_time", "src_province", "src_citycode", "src_deptcode", "dest_province", "dest_citycode", "dest_deptcode", "x1", "y1", "x2", "y2", "vehicle", "vehicle_type", "weight", "mload", "length", "width", "height", "axle_weight", "axle_number", "plate_color", "energy", "emit_stand", "passport", "driver_id", "ft_url", "plan_date", "stype", "path_count", "opt", "strategy", "merge", "routeid_in", "fixed_route", "fencedist", "status", "pns_status", "distance", "duration", "toll_distance", "tolls", "src", "trafficlight_count", "highspeed_distance", "flen", "tlen", "routeid_out", "polyline", "linknum", "rc_distance", "links", "rdynsdlen", "rdynsdcnt", "ak", "start_speed", "vehicle_dir1", "rect_result", "strategy2", "routetype", "merge_result", "starts", "starttime_type", "driver_type", "is_econ", "service_id", "line_code", "navi_type", "gd_polyline", "top3_reqtype", "path_rule", "path_type", "path_pos", "limit_info", "is_lowrisk", "pathrule_num", "point_num", "area_num", "pull_navitype",
      "start_dept", "end_dept", "vehicle_type_navi", "stdmatchtype", "passzonetype", "cachestdid", "linerequireid", "passzonetableid", "cachestdblockroad", "nostdreasontype", "nostdreasondetail"
    )

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }


  /**
   * 解析日志主流程
   *
   * @param spark
   * @param getRddF
   * @param computeRddF
   * @param table
   * @param structs
   * @param keys
   * @param saveHiveRddF
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  /**
   * 获取Top3点选线路的ETA结果
   *
   * @param spark
   * @param runType
   * @param date
   * @param auto
   * @return
   */
  def getTop3ClickRouteRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    var dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    var runDate = ""
    if ("1".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = date
      }
      else {
        runDate = date
      }
      dateList += runDate
    }
    else if ("3".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = DateUtil.getDateStr(date, -1)
      }
      else {
        runDate = date
      }
      dateList += runDate
    }

    logger.error(">>>获取" + runDate + "号的Top3点选线路的ETA结果")
    var sql = ""

    if ("1".equalsIgnoreCase(runType)) {
      sql =
        s"""
           |select a.task_id,a.navi_id,a.request_id,a.req_time,a.src_deptcode,a.dest_deptcode,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.status,a.ak,a.start_speed,a.vehicle_dir1,a.starts,a.driver_type,a.service_id,a.line_code,a.top3_reqtype,a.navi_starttime,a.type,a.routeid,a.navi_type,a.routeid2,a.inc_day2,a.gd_polyline,
           |a.start_dept,a.end_dept,a.vehicle_type_navi,a.stdmatchtype,a.passzonetype,a.cachestdid,a.linerequireid,a.passzonetableid,a.cachestdblockroad,a.nostdreasontype,a.nostdreasondetail,
           |b.route_index,b.pns_status,b.distance,b.duration,b.toll_distance,b.tolls,b.src,b.trafficlight_count,b.highspeed_distance,b.flen,b.tlen,b.routeid_out,b.polyline,b.linknum,b.rc_distance,b.links,b.rdynsdlen,b.rdynsdcnt,b.rect_result,b.strategy2,b.routetype,b.merge_result,b.is_econ,c.src_citycode,c.src_province,d.dest_citycode,d.dest_province,a.inc_day,a.inc_day as inc_date from
           |(
           |select t1.task_id,t1.navi_id,t1.request_id,t1.req_time,t1.src_deptcode,t1.dest_deptcode,t1.x1,t1.y1,t1.x2,t1.y2,t1.vehicle,t1.vehicle_type,t1.weight,t1.mload,t1.length,t1.width,t1.height,t1.axle_weight,t1.axle_number,t1.plate_color,t1.energy,t1.emit_stand,t1.passport,t1.driver_id,t1.ft_url,t1.plan_date,t1.stype,t1.path_count,t1.opt,t1.strategy,t1.merge,t1.routeid_in,t1.fixed_route,t1.fencedist,t1.status,t1.ak,t1.start_speed,t1.vehicle_dir1,t1.starts,t1.driver_type,t1.service_id,t1.line_code,t1.top3_reqtype,
           |t1.start_dept,t1.end_dept,t1.vehicle_type_navi,t1.stdmatchtype,t1.passzonetype,t1.cachestdid,t1.linerequireid,t1.passzonetableid,t1.cachestdblockroad,t1.nostdreasontype,t1.nostdreasondetail,
           |t2.inc_day,t2.navi_starttime,t2.type,t2.routeid,t2.navi_type,t3.routeid2,t3.inc_day2,t4.gd_polyline from
           |  (select task_id,navi_id,request_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'3' as path_count,opt,'' as strategy,merge,routeid_in,fixed_route,fencedist,status,ak,start_speed,vehicle_dir1,tracks as starts,driver_type,service_id,line_code,top3_reqtype,start_dept,end_dept,vehicle_type_navi,
           |      stdmatchtype,passzonetype,cachestdid,
           |      linerequireid,passzonetableid,cachestdblockroad,
           |      nostdreasontype,nostdreasondetail from dm_gis.gis_navi_top3_parse where inc_day='$runDate') t1
           |  left join (select navi_id,max(report_time) as navi_starttime,max(type) as type,max(routeid) as routeid,max(navi_type) as navi_type,max(inc_day) as inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='1' group by navi_id) t2 on t1.navi_id=t2.navi_id
           |  left join (select navi_id,max(routeid) as routeid2,max(inc_day) as inc_day2 from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='9' group by navi_id) t3 on t1.navi_id=t3.navi_id
           |  left join (select navi_id,max(gd_content) as gd_polyline from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='8' group by navi_id) t4 on t1.navi_id=t4.navi_id
           |) a
           |left join (select request_id,routeid,route_index,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ from dm_gis.gis_navi_top3_yaw_result_parse where inc_day='$runDate') b on a.request_id=b.request_id and a.routeid=b.routeid
           |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909') c on a.src_deptcode=c.zone_code
           |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909') d on a.dest_deptcode=d.zone_code
       """.stripMargin
    }
    else if ("3".equalsIgnoreCase(runType)) {
      val startDate = DateUtil.getDateStr(runDate, -1)
      val endDate = runDate
      sql =
        s"""
           |select a.task_id,a.navi_id,a.request_id,a.req_time,a.src_deptcode,a.dest_deptcode,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.status,a.ak,a.start_speed,a.vehicle_dir1,a.starts,a.driver_type,a.service_id,a.line_code,a.top3_reqtype,a.navi_starttime,a.type,a.routeid,a.navi_type,a.routeid2,a.inc_day2,a.gd_polyline,a.pull_navitype,
           |a.start_dept,a.end_dept,a.vehicle_type_navi,a.stdmatchtype,a.passzonetype,a.cachestdid,a.linerequireid,a.passzonetableid,a.cachestdblockroad,a.nostdreasontype,a.nostdreasondetail,
           |b.route_index,b.pns_status,b.distance,b.duration,b.toll_distance,b.tolls,b.src,b.trafficlight_count,b.highspeed_distance,b.flen,b.tlen,b.routeid_out,b.polyline,b.linknum,b.rc_distance,b.links,b.rdynsdlen,b.rdynsdcnt,b.rect_result,b.strategy2,b.routetype,b.merge_result,b.is_econ,b.path_rule,b.path_type,b.path_pos,b.limit_info,b.is_lowrisk,b.pathrule_num,b.point_num,b.area_num,c.src_citycode,c.src_province,d.dest_citycode,d.dest_province,a.inc_day,a.inc_day as inc_date from
           |(
           |select t1.task_id,t1.navi_id,t1.request_id,t1.req_time,t1.src_deptcode,t1.dest_deptcode,t1.x1,t1.y1,t1.x2,t1.y2,t1.vehicle,t1.vehicle_type,t1.weight,t1.mload,t1.length,t1.width,t1.height,t1.axle_weight,t1.axle_number,t1.plate_color,t1.energy,t1.emit_stand,t1.passport,t1.driver_id,t1.ft_url,t1.plan_date,t1.stype,t1.path_count,t1.opt,t1.strategy,t1.merge,t1.routeid_in,t1.fixed_route,t1.fencedist,t1.status,t1.ak,t1.start_speed,t1.vehicle_dir1,t1.starts,t1.driver_type,t1.service_id,t1.line_code,t1.top3_reqtype,
           |t1.start_dept,t1.end_dept,t1.vehicle_type_navi,t1.stdmatchtype,t1.passzonetype,t1.cachestdid,t1.linerequireid,t1.passzonetableid,t1.cachestdblockroad,t1.nostdreasontype,t1.nostdreasondetail,
           |t2.inc_day,t2.navi_starttime,t2.type,t2.routeid,t2.navi_type,t3.routeid2,t3.inc_day2,t4.gd_polyline,t5.pull_navitype from
           |	(select task_id,navi_id,request_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'3' as path_count,opt,'' as strategy,merge,routeid_in,fixed_route,fencedist,status,ak,start_speed,vehicle_dir1,tracks as starts,driver_type,service_id,line_code,top3_reqtype,start_dept,end_dept,vehicle_type_navi,
           |      stdmatchtype,passzonetype,cachestdid,
           |      linerequireid,passzonetableid,cachestdblockroad,
           |      nostdreasontype,nostdreasondetail from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate'  and navi_id is not null and trim(navi_id) !='') t1
           |	left join (select navi_id,max(report_time) as navi_starttime,max(type) as type,max(routeid) as routeid,max(navi_type) as navi_type,max(inc_day) as inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='1'  and navi_id is not null and trim(navi_id) !='' group by navi_id) t2 on t1.navi_id=t2.navi_id
           |	left join (select navi_id,max(routeid) as routeid2,max(inc_day) as inc_day2 from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='9'  and navi_id is not null and trim(navi_id) !='' group by navi_id) t3 on t1.navi_id=t3.navi_id
           |	left join (select navi_id,max(gd_content) as gd_polyline from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='8'  and navi_id is not null and trim(navi_id) !='' group by navi_id) t4 on t1.navi_id=t4.navi_id
           |	left join (select navi_id,max(pull_navitype) as pull_navitype from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='6'  and navi_id is not null and trim(navi_id) !='' group by navi_id) t5 on t1.navi_id=t5.navi_id
           |) a
           |left join (select request_id,routeid,route_index,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate') b on a.request_id=b.request_id and a.routeid=b.routeid
           |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909') c on a.src_deptcode=c.zone_code
           |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909') d on a.dest_deptcode=d.zone_code
       """.stripMargin
      //      sql =
      //        s"""
      //           |select * from dm_gis.table11_tmp where par_day='$runDate'
      //           |""".stripMargin
    }

    val resultRdd = NaviLogParse.getValidJson(spark, sql)
    //    val resultRdd = getValidJoinJson(spark, sql, date)
    //    val resultRdd = getValidJoinJsonP2(spark, date)
    //如果起终网点 数量变化较大，用该方法
//        val resultRdd = getValidJoinJsonDept(spark, date)
    logger.error(">>>日志量：" + resultRdd.count())

    val computeRdd = resultRdd.map(json => {
      if (json != null) {
        if (StringUtils.isEmpty(json.getString("inc_date"))) {
          val inc_day2 = json.getString("inc_day2")
          if (!StringUtils.isEmpty(inc_day2)) {
            json.put("inc_date", inc_day2)
          }
        }
        if (StringUtils.isEmpty(json.getString("routeid"))) {
          val routeid2 = json.getString("routeid2")
          if (!StringUtils.isEmpty(routeid2)) {
            json.put("routeid", routeid2)
          }
        }

        var gd_polyline_new = ""
        val gd_polyline = json.getJSONArray("gd_polyline")
        if (gd_polyline != null && gd_polyline.size() > 0) {
          var routeid = json.getString("routeid")
          if (StringUtils.isEmpty(routeid)) routeid = ""
          breakable(
            for (j <- 0.until(gd_polyline.size())) {
              val track = gd_polyline.getJSONObject(j)
              if (track != null) {
                if (routeid.equalsIgnoreCase(track.getString("routeId"))) {
                  gd_polyline_new = track.getString("coords")
                  gd_polyline_new = gd_polyline_new.replaceAll("latitude", "y").replaceAll("longitude", "x")
                  break
                }
              }
            }
          )
        }
        json.put("gd_polyline", gd_polyline_new)

        if (StringUtils.isEmpty(json.getString("navi_starttime"))) {
          val req_time = json.getString("req_time")
          if (!StringUtils.isEmpty(req_time) && !"0".equalsIgnoreCase(req_time)) json.put("navi_starttime", req_time)
          else json.put("navi_starttime", "-1")
        }
        if ("1".equalsIgnoreCase(json.getString("type"))) json.put("starttime_type", "1")
        else json.put("starttime_type", "0")
      }
      json
    })
    resultRdd.unpersist()
    (computeRdd, dateList)
  }

  /**
   * 单独处理 dept 很多空值的情况
   *
   * @param spark
   * @param date
   * @return
   */
  def getValidJoinJsonDept(spark: SparkSession, date: String): RDD[JSONObject] = {
    val runDate = date
    val startDate = DateUtil.getDateStr(runDate, -1)
    val endDate = runDate
    val sql =
      s"""
         |select a.task_id,a.navi_id,a.request_id,a.req_time,a.src_deptcode,a.dest_deptcode,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.status,a.ak,a.start_speed,a.vehicle_dir1,a.starts,a.driver_type,a.service_id,a.line_code,a.top3_reqtype,a.navi_starttime,a.type,a.routeid,a.navi_type,a.routeid2,a.inc_day2,a.gd_polyline,a.pull_navitype,
         |a.start_dept,a.end_dept,a.vehicle_type_navi,a.stdmatchtype,a.passzonetype,a.cachestdid,a.linerequireid,a.passzonetableid,a.cachestdblockroad,a.nostdreasontype,a.nostdreasondetail,
         |b.route_index,b.pns_status,b.distance,b.duration,b.toll_distance,b.tolls,b.src,b.trafficlight_count,b.highspeed_distance,b.flen,b.tlen,b.routeid_out,b.polyline,b.linknum,b.rc_distance,b.links,b.rdynsdlen,b.rdynsdcnt,b.rect_result,b.strategy2,b.routetype,b.merge_result,b.is_econ,b.path_rule,b.path_type,b.path_pos,b.limit_info,b.is_lowrisk,b.pathrule_num,b.point_num,b.area_num,a.inc_day,a.inc_day as inc_date from
         |(
         |select t1.task_id,t1.navi_id,t1.request_id,t1.req_time,t1.src_deptcode,t1.dest_deptcode,t1.x1,t1.y1,t1.x2,t1.y2,t1.vehicle,t1.vehicle_type,t1.weight,t1.mload,t1.length,t1.width,t1.height,t1.axle_weight,t1.axle_number,t1.plate_color,t1.energy,t1.emit_stand,t1.passport,t1.driver_id,t1.ft_url,t1.plan_date,t1.stype,t1.path_count,t1.opt,t1.strategy,t1.merge,t1.routeid_in,t1.fixed_route,t1.fencedist,t1.status,t1.ak,t1.start_speed,t1.vehicle_dir1,t1.starts,t1.driver_type,t1.service_id,t1.line_code,t1.top3_reqtype,
         |t1.start_dept,t1.end_dept,t1.vehicle_type_navi,t1.stdmatchtype,t1.passzonetype,t1.cachestdid,t1.linerequireid,t1.passzonetableid,t1.cachestdblockroad,t1.nostdreasontype,t1.nostdreasondetail,
         |t2.inc_day,t2.navi_starttime,t2.type,t2.routeid,t2.navi_type,t3.routeid2,t3.inc_day2,t4.gd_polyline,t5.pull_navitype from
         |	(select task_id,navi_id,request_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'3' as path_count,opt,'' as strategy,merge,routeid_in,fixed_route,fencedist,status,ak,start_speed,vehicle_dir1,tracks as starts,driver_type,service_id,line_code,top3_reqtype,start_dept,end_dept,vehicle_type_navi,
         |      stdmatchtype,passzonetype,cachestdid,
         |      linerequireid,passzonetableid,cachestdblockroad,
         |      nostdreasontype,nostdreasondetail from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate'  and navi_id is not null and trim(navi_id) !='') t1
         |	left join (select navi_id,max(report_time) as navi_starttime,max(type) as type,max(routeid) as routeid,max(navi_type) as navi_type,max(inc_day) as inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='1'  and navi_id is not null and trim(navi_id) !='' group by navi_id) t2 on t1.navi_id=t2.navi_id
         |	left join (select navi_id,max(routeid) as routeid2,max(inc_day) as inc_day2 from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='9'  and navi_id is not null and trim(navi_id) !='' group by navi_id) t3 on t1.navi_id=t3.navi_id
         |	left join (select navi_id,max(gd_content) as gd_polyline from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='8'  and navi_id is not null and trim(navi_id) !='' group by navi_id) t4 on t1.navi_id=t4.navi_id
         |	left join (select navi_id,max(pull_navitype) as pull_navitype from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='6'  and navi_id is not null and trim(navi_id) !='' group by navi_id) t5 on t1.navi_id=t5.navi_id
         |) a
         |left join (select request_id,routeid,route_index,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate') b on a.request_id=b.request_id and a.routeid=b.routeid
         |""".stripMargin

    val df1 = spark.sql(sql)

    df1.select("navi_id", "src_deptcode", "dest_deptcode").createTempView("tmp_t_a_b_df")

    val sqlm_start = spark.sql(
      s"""
         |select navi_id,src_deptcode,src_citycode,src_province from
         |(select navi_id,src_deptcode from tmp_t_a_b_df where src_deptcode is not null and trim(src_deptcode) !='' group by navi_id,src_deptcode) a
         |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909' and zone_code is not null and trim(zone_code) !='' ) c on a.src_deptcode=c.zone_code
       """.stripMargin)

    val sqlm_end = spark.sql(
      s"""
         |select navi_id,dest_deptcode,dest_citycode,dest_province from
         |(select navi_id,dest_deptcode from tmp_t_a_b_df where dest_deptcode is not null and trim(dest_deptcode) !='' group by navi_id,dest_deptcode) a
         |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909' and zone_code is not null and trim(zone_code) !='' ) d on a.dest_deptcode=d.zone_code
       """.stripMargin)
    val df = df1
      .join(sqlm_start, Seq("navi_id", "src_deptcode"), "left")
      .join(sqlm_end, Seq("navi_id", "dest_deptcode"), "left")
      .selectExpr("task_id",
        "navi_id",
        "request_id",
        "req_time",
        "src_deptcode",
        "dest_deptcode",
        "x1",
        "y1",
        "x2",
        "y2",
        "vehicle",
        "vehicle_type",
        "weight",
        "mload",
        "length",
        "width",
        "height",
        "axle_weight",
        "axle_number",
        "plate_color",
        "energy",
        "emit_stand",
        "passport",
        "driver_id",
        "ft_url",
        "plan_date",
        "stype",
        "path_count",
        "opt",
        "strategy",
        "merge",
        "routeid_in",
        "fixed_route",
        "fencedist",
        "status",
        "ak",
        "start_speed",
        "vehicle_dir1",
        "starts",
        "driver_type",
        "service_id",
        "line_code",
        "top3_reqtype",
        "navi_starttime",
        "type",
        "routeid",
        "navi_type",
        "routeid2",
        "inc_day2",
        "gd_polyline",
        "pull_navitype",
        "start_dept",
        "end_dept",
        "vehicle_type_navi",
        "stdmatchtype",
        "passzonetype",
        "cachestdid",
        "linerequireid",
        "passzonetableid",
        "cachestdblockroad",
        "nostdreasontype",
        "nostdreasondetail",
        "route_index",
        "pns_status",
        "distance",
        "duration",
        "toll_distance",
        "tolls",
        "src",
        "trafficlight_count",
        "highspeed_distance",
        "flen",
        "tlen",
        "routeid_out",
        "polyline",
        "linknum",
        "rc_distance",
        "links",
        "rdynsdlen",
        "rdynsdcnt",
        "rect_result",
        "strategy2",
        "routetype",
        "merge_result",
        "is_econ",
        "path_rule",
        "path_type",
        "path_pos",
        "limit_info",
        "is_lowrisk",
        "pathrule_num",
        "point_num",
        "area_num",
        "src_citycode",
        "src_province",
        "dest_citycode",
        "dest_province",
        "inc_day",
        "inc_day as inc_date")
      .withColumn("par_day", lit(date)).persist()
    logger.error(">>>>>>结果df>>>>>" + df.count())
    df1.unpersist()

    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(600).map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) {
        json.put(header(i), row.getString(i))
      }
      json
    }).filter(_ != null).persist()
    logger.error(">>>日志量：" + logRdd.count())
    logRdd
  }

  def getValidJoinJsonP2(spark: SparkSession, date: String): RDD[JSONObject] = {
    import spark.implicits._
    val runDate = date
    val startDate = DateUtil.getDateStr(runDate, -1)
    val endDate = runDate
    val sql1 =
      s"""
         |select task_id,navi_id,request_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'3' as path_count,opt,'' as strategy,merge,routeid_in,fixed_route,fencedist,status,ak,start_speed,vehicle_dir1,tracks as starts,driver_type,service_id,line_code,top3_reqtype,start_dept,end_dept,vehicle_type_navi,
         |      stdmatchtype,passzonetype,cachestdid,
         |      linerequireid,passzonetableid,cachestdblockroad,
         |      nostdreasontype,nostdreasondetail from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate'  and navi_id is not null and trim(navi_id) !=''
         |""".stripMargin

    val sql2 =
      s"""
         |select navi_id,max(report_time) as navi_starttime,max(type) as type,max(routeid) as routeid,max(navi_type) as navi_type,max(inc_day) as inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='1'  and navi_id is not null and trim(navi_id) !='' group by navi_id
         |""".stripMargin
    val sql3 =
      s"""
         |select navi_id,max(routeid) as routeid2,max(inc_day) as inc_day2 from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='9'  and navi_id is not null and trim(navi_id) !='' group by navi_id
         |""".stripMargin
    val sql4 =
      s"""
         |select navi_id,max(gd_content) as gd_polyline from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='8'  and navi_id is not null and trim(navi_id) !='' group by navi_id
         |""".stripMargin
    val sql5 =
      s"""
         |select navi_id,max(pull_navitype) as pull_navitype from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='6'  and navi_id is not null and trim(navi_id) !='' and navi_id !='-1' and pull_navitype in ('0','1') group by navi_id
         |""".stripMargin

    val df1 = spark.sql(sql1)
      .withColumn("navi_id", randomPreAdd(8)(col("navi_id")))
    val df2 = spark.sql(sql2).persist()
      .withColumn("navi_id", concat_ws("_", lit("0"), col("navi_id")))
    val df3 = spark.sql(sql3).persist()
      .withColumn("navi_id", concat_ws("_", lit("0"), col("navi_id")))
    val df4 = spark.sql(sql4).persist()
      .withColumn("navi_id", concat_ws("_", lit("0"), col("navi_id")))
    val df5 = spark.sql(sql5).persist()
      .withColumn("navi_id", concat_ws("_", lit("0"), col("navi_id")))

    var new_df2 = df2
    var new_df3 = df3
    var new_df4 = df4
    var new_df5 = df5
    logger.error(">>>df1>>>>>" + df1.count())
    logger.error(">>>df2>>>>>" + df2.count())
    logger.error(">>>df3>>>>>" + df3.count())
    logger.error(">>>df4>>>>>" + df4.count())
    logger.error(">>>df5>>>>>" + df5.count())

    for (i <- 1 until 8) {
      val new_df_2 = df2.withColumn("navi_id", concat_ws("_", lit(i.toString), col("navi_id")))
      val new_df_3 = df3.withColumn("navi_id", concat_ws("_", lit(i.toString), col("navi_id")))
      val new_df_4 = df4.withColumn("navi_id", concat_ws("_", lit(i.toString), col("navi_id")))
      val new_df_5 = df5.withColumn("navi_id", concat_ws("_", lit(i.toString), col("navi_id")))
      new_df2 = new_df2.union(new_df_2)
      new_df3 = new_df3.union(new_df_3)
      new_df4 = new_df4.union(new_df_4)
      new_df5 = new_df5.union(new_df_5)
    }

    logger.error(">>>new_df2>>>>>" + new_df2.count())
    logger.error(">>>new_df3>>>>>" + new_df3.count())
    logger.error(">>>new_df4>>>>>" + new_df4.count())
    logger.error(">>>new_df5>>>>>" + new_df5.count())

    val tmp = df1
      .join(new_df2, Seq("navi_id"), "left")
      .join(new_df3, Seq("navi_id"), "left")
      .join(new_df4, Seq("navi_id"), "left")
      .join(new_df5, Seq("navi_id"), "left")
      .withColumn("navi_id", removePreUdf(col("navi_id")))
      .withColumn("key", randomPreTwoAdd(8)('request_id, 'routeid))
    logger.error(">>>tmp>>>>>" + tmp.count())

    val tmp_b_sql = s"""select request_id,routeid,route_index,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate' and request_id is not null and trim(request_id) !='' and routeid is not null and trim(routeid) !=''"""
    val tmp_b_df = spark.sql(tmp_b_sql).withColumn("key", concat_ws("_", lit("0"), col("request_id"), col("routeid"))).persist()

    var new_tmp_b_df = tmp_b_df
    for (i <- 1 until 8) {
      val new_bb_df_2 = tmp_b_df.withColumn("key", concat_ws("_", lit(i.toString), col("request_id"), col("routeid")))
      new_tmp_b_df = new_tmp_b_df.union(new_bb_df_2)
    }

    val tmp_2 = tmp.join(new_tmp_b_df.drop("request_id", "routeid"), Seq("key"), "left").drop("key")

    logger.error(">>>>>>tmp_2的数据量>>>>>>>" + tmp_2.count())

    tmp_2.select("navi_id", "src_deptcode", "dest_deptcode").createTempView("tmp_t_a_b_df")

    val sqlm_start = spark.sql(
      s"""
         |select navi_id,src_deptcode,src_citycode,src_province from
         |(select navi_id,src_deptcode from tmp_t_a_b_df where src_deptcode is not null and trim(src_deptcode) !='' group by navi_id,src_deptcode) a
         |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909' and zone_code is not null and trim(zone_code) !='' ) c on a.src_deptcode=c.zone_code
       """.stripMargin)

    val sqlm_end = spark.sql(
      s"""
         |select navi_id,dest_deptcode,dest_citycode,dest_province from
         |(select navi_id,dest_deptcode from tmp_t_a_b_df where dest_deptcode is not null and trim(dest_deptcode) !='' group by navi_id,dest_deptcode) a
         |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909' and zone_code is not null and trim(zone_code) !='' ) d on a.dest_deptcode=d.zone_code
       """.stripMargin)

    val df = tmp_2
      .join(sqlm_start, Seq("navi_id", "src_deptcode"), "left")
      .join(sqlm_end, Seq("navi_id", "dest_deptcode"), "left")
      .selectExpr("task_id",
        "navi_id",
        "request_id",
        "req_time",
        "src_deptcode",
        "dest_deptcode",
        "x1",
        "y1",
        "x2",
        "y2",
        "vehicle",
        "vehicle_type",
        "weight",
        "mload",
        "length",
        "width",
        "height",
        "axle_weight",
        "axle_number",
        "plate_color",
        "energy",
        "emit_stand",
        "passport",
        "driver_id",
        "ft_url",
        "plan_date",
        "stype",
        "path_count",
        "opt",
        "strategy",
        "merge",
        "routeid_in",
        "fixed_route",
        "fencedist",
        "status",
        "ak",
        "start_speed",
        "vehicle_dir1",
        "starts",
        "driver_type",
        "service_id",
        "line_code",
        "top3_reqtype",
        "navi_starttime",
        "type",
        "routeid",
        "navi_type",
        "routeid2",
        "inc_day2",
        "gd_polyline",
        "pull_navitype",
        "start_dept",
        "end_dept",
        "vehicle_type_navi",
        "stdmatchtype",
        "passzonetype",
        "cachestdid",
        "linerequireid",
        "passzonetableid",
        "cachestdblockroad",
        "nostdreasontype",
        "nostdreasondetail",
        "route_index",
        "pns_status",
        "distance",
        "duration",
        "toll_distance",
        "tolls",
        "src",
        "trafficlight_count",
        "highspeed_distance",
        "flen",
        "tlen",
        "routeid_out",
        "polyline",
        "linknum",
        "rc_distance",
        "links",
        "rdynsdlen",
        "rdynsdcnt",
        "rect_result",
        "strategy2",
        "routetype",
        "merge_result",
        "is_econ",
        "path_rule",
        "path_type",
        "path_pos",
        "limit_info",
        "is_lowrisk",
        "pathrule_num",
        "point_num",
        "area_num",
        "src_citycode",
        "src_province",
        "dest_citycode",
        "dest_province",
        "inc_day",
        "inc_day as inc_date")
      .withColumn("par_day", lit(date)).persist()
    logger.error(">>>>>>结果df>>>>>" + df.count())
    df1.unpersist()
    df2.unpersist()
    df3.unpersist()
    df4.unpersist()
    df5.unpersist()
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(600).map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) {
        json.put(header(i), row.getString(i))
      }
      json
    }).filter(_ != null).persist()
    logger.error(">>>日志量：" + logRdd.count())
    logRdd

  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param sql
   * @return
   */
  def getValidJoinJson(spark: SparkSession, sql: String, date: String): (RDD[JSONObject]) = {
    import spark.implicits._
    val runDate = date
    val startDate = DateUtil.getDateStr(runDate, -1)
    val endDate = runDate

    val sql1 =
      s"""
         |select task_id,navi_id,request_id,req_time,src_deptcode,dest_deptcode,startx as x1,starty as y1,endx as x2,endy as y2,vehicle,vehicle_type,weight,mload,length,width,height,axle_weight,axle_number,plate_color,energy,emit_stand,passport,driver_id,ft_url,plan_date,'' as stype,'3' as path_count,opt,'' as strategy,merge,routeid_in,fixed_route,fencedist,status,ak,start_speed,vehicle_dir1,tracks as starts,driver_type,service_id,line_code,top3_reqtype,start_dept,end_dept,vehicle_type_navi,
         |      stdmatchtype,passzonetype,cachestdid,
         |      linerequireid,passzonetableid,cachestdblockroad,
         |      nostdreasontype,nostdreasondetail from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate'  and navi_id is not null and trim(navi_id) !=''
         |""".stripMargin
    val sql2 =
      s"""
         |select navi_id,report_time,type,routeid,navi_type,inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='1'  and navi_id is not null and trim(navi_id) !='' and navi_id !='-1'
         |""".stripMargin
    val sql3 =
      s"""
         |select navi_id,routeid,inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='9'  and navi_id is not null and trim(navi_id) !='' and navi_id !='-1'
         |""".stripMargin
    val sql4 =
      s"""
         |select navi_id,gd_content from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='8'  and navi_id is not null and trim(navi_id) !='' and navi_id !='-1'
         |""".stripMargin
    val sql5 = //regexp_replace(pull_navitype,'[^0-9]','')
      s"""
         |select navi_id,cast(pull_navitype as int) pull_navitype from dm_gis.gis_navi_sdk_navi_parse where inc_day='$runDate' and type='6'  and navi_id is not null and trim(navi_id) !='' and navi_id !='-1' and pull_navitype in ('0','1')
         |""".stripMargin
    println("sql1=" + sql1)
    println("sql2=" + sql2)
    println("sql3=" + sql3)
    println("sql4=" + sql4)
    println("sql5=" + sql5)
    val df1 = spark.sql(sql1).persist()
    val df2 = spark.sql(sql2)
      .groupBy(randomPrefix('navi_id) as "navi_id")
      .agg(
        max("report_time") as "navi_starttime",
        max("type") as "type",
        max("routeid") as "routeid",
        max("navi_type") as "navi_type",
        max("inc_day") as "inc_day"
      ).groupBy(removePrefix('navi_id) as "navi_id")
      .agg(
        max("navi_starttime") as "navi_starttime",
        max("type") as "type",
        max("routeid") as "routeid",
        max("navi_type") as "navi_type",
        max("inc_day") as "inc_day"
      ).persist()
    val df3 = spark.sql(sql3)
      .groupBy(randomPrefix('navi_id) as "navi_id")
      .agg(
        max("routeid") as "routeid2",
        max("inc_day") as "inc_day2"
      ).groupBy(removePrefix('navi_id) as "navi_id")
      .agg(
        max("routeid2") as "routeid2",
        max("inc_day2") as "inc_day2"
      ).persist()
    val df4 = spark.sql(sql4)
      .groupBy(randomPrefix('navi_id) as "navi_id")
      .agg(
        max("gd_content") as "gd_polyline"
      ).groupBy(removePrefix('navi_id) as "navi_id")
      .agg(
        max("gd_polyline") as "gd_polyline"
      ).persist()
    val df5 = spark.sql(sql5)
      //      .withColumn("num",row_number().over(Window.partitionBy("navi_id").orderBy(desc("pull_navitype"))))
      //      .filter('num === 1).select("navi_id","pull_navitype")
      .groupBy(randomPrefix('navi_id) as "navi_id")
      .agg(
        max("pull_navitype") as "pull_navitype"
      ).groupBy(removePrefix('navi_id) as "navi_id")
      .agg(
        max("pull_navitype") as "pull_navitype"
      )
      .persist()
    logger.error(">>>df1>>>>>" + df1.count())
    logger.error(">>>df2>>>>>" + df2.count())
    logger.error(">>>df3>>>>>" + df3.count())
    logger.error(">>>df4>>>>>" + df4.count())
    logger.error(">>>df5>>>>>" + df5.count())
    val tmp1 = leftOuterJoin(spark, df1, df2, "navi_id", 8, 20, "right")
    val tmp2 = leftOuterJoin(spark, tmp1, df3, "navi_id", 8, 20, "left")
    val tmp3 = leftOuterJoin(spark, tmp2, df4, "navi_id", 8, 20, "left")
    val tmp = leftOuterJoin(spark, tmp3, df5, "navi_id", 8, 20, "left")

    logger.error(">>>tmp>>>>>" + tmp.count())
    tmp.show(3)
    tmp.createTempView("inter_tmp")
    val sql =
      s"""
         |select a.task_id,a.navi_id,a.request_id,a.req_time,a.src_deptcode,a.dest_deptcode,a.x1,a.y1,a.x2,a.y2,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.width,a.height,a.axle_weight,a.axle_number,a.plate_color,a.energy,a.emit_stand,a.passport,a.driver_id,a.ft_url,a.plan_date,a.stype,a.path_count,a.opt,a.strategy,a.merge,a.routeid_in,a.fixed_route,a.fencedist,a.status,a.ak,a.start_speed,a.vehicle_dir1,a.starts,a.driver_type,a.service_id,a.line_code,a.top3_reqtype,a.navi_starttime,a.type,a.routeid,a.navi_type,a.routeid2,a.inc_day2,a.gd_polyline,a.pull_navitype,
         |a.start_dept,a.end_dept,a.vehicle_type_navi,a.stdmatchtype,a.passzonetype,a.cachestdid,a.linerequireid,a.passzonetableid,a.cachestdblockroad,a.nostdreasontype,a.nostdreasondetail,
         |b.route_index,b.pns_status,b.distance,b.duration,b.toll_distance,b.tolls,b.src,b.trafficlight_count,b.highspeed_distance,b.flen,b.tlen,b.routeid_out,b.polyline,b.linknum,b.rc_distance,b.links,b.rdynsdlen,b.rdynsdcnt,b.rect_result,b.strategy2,b.routetype,b.merge_result,b.is_econ,b.path_rule,b.path_type,b.path_pos,b.limit_info,b.is_lowrisk,b.pathrule_num,b.point_num,b.area_num,c.src_citycode,c.src_province,d.dest_citycode,d.dest_province,a.inc_day,a.inc_day as inc_date from
         |(select * from inter_tmp) a
         |left join (select request_id,routeid,route_index,top3_status as pns_status,distance,duration,toll_distance,tolls,src,trafficlight_count,highspeed_distance,flen,tlen,routeid_out,polyline,linknum,rc_distance,links,rdynsdlen,rdynsdcnt,rect_result,strategy as strategy2,routetype,merge_result,is_econ,path_rule,path_type,path_pos,limit_info,is_lowrisk,pathrule_num,point_num,area_num from dm_gis.gis_navi_top3_yaw_result_parse where inc_day between '$startDate' and '$endDate' and request_id is not null and trim(request_id) !='' and routeid is not null and trim(routeid) !='' ) b on a.request_id=b.request_id and a.routeid=b.routeid
         |left join (select zone_code,city_code as src_citycode,province as src_province from dm_gis.gis_navi_dept_info where inc_day='20200909' and zone_code is not null and trim(zone_code) !='' ) c on a.src_deptcode=c.zone_code
         |left join (select zone_code,city_code as dest_citycode,province as dest_province from dm_gis.gis_navi_dept_info where inc_day='20200909' and zone_code is not null and trim(zone_code) !='' ) d on a.dest_deptcode=d.zone_code
       """.stripMargin
    val df = spark.sql(sql).persist()
    logger.error(">>>df>>>>>" + df.count())
    df1.unpersist()
    df2.unpersist()
    df3.unpersist()
    df4.unpersist()
    df5.unpersist()
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(600).map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) {
        json.put(header(i), row.getString(i))
      }
      json
    }).filter(_ != null).persist()
    logger.error(">>>日志量：" + logRdd.count())
    logRdd
  }

  /**
   * @param 添加前缀
   * @return
   */
  def randomPrefix = udf((colName: String) => {
    Random.nextInt(9).toString + "_" + colName
  })

  /**
   * @param 去前缀
   * @return
   */
  def removePrefix = udf((colName: String) => {
    colName.split("_")(1)
  })

  def randomPreTwoAdd(hashNum: Int) = udf((col1: String, col2: String) => {
    Random.nextInt(hashNum) + "_" + col1 + "_" + col2
  })

  def leftOuterJoin(spark: SparkSession, left: DataFrame, right: DataFrame, key: String, hashNum: Int, topLean: Int = 10, flag: String): DataFrame = {
    import spark.implicits._
    val left_cols = left.schema.map(_.name).map(col)
    val right_cols = right.schema.map(_.name).map(col)
    //1 从主表中提前过滤出需要的key字段
    val portent_key_cols = left.select(key).distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    left.createTempView("left_df")
    right.createTempView("right_df_tmp")
    spark.sql(s"""select * from right_df_tmp where $key in ($portent_key_cols)""").createTempView("right_df")
    //2 判断是根据left 还是right表进行 热点key拆解 并取出热点key
    var key_df: DataFrame = null
    if (flag == "right") {
      key_df = left.select(key).withColumn("cnt", lit(1))
        .groupBy(key).agg(sum("cnt") as "cnt")
        .withColumn("num", row_number().over(orderBy(desc("cnt"))))
        .filter('num <= topLean)
    } else {
      key_df = spark.sql("""select * from right_df""").select(key).withColumn("cnt", lit(1))
        .groupBy(key).agg(sum("cnt") as "cnt")
        .withColumn("num", row_number().over(orderBy(desc("cnt"))))
        .filter('num <= topLean)
    }
    val o_key_str: String = key_df.select(key).distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    println(">>>>>>需要单独处理的key信息>>>>>>>" + o_key_str)
    //3 分别从left 和 right 中把需要单独处理的数据取出。并进行扩容
    //left
    val left_need_enlarge = spark.sql(s"""select * from left_df where $key in ($o_key_str)""")
      .withColumn(key, randomPreAdd(hashNum)(col(key)))
      .select(left_cols: _*)
    val left_no_need_enlarge = spark.sql(s"""select * from left_df where $key not in ($o_key_str)""")
      .select(left_cols: _*)
    val res_left_df = left_need_enlarge.union(left_no_need_enlarge).select(left_cols: _*)
      .repartition(600, col(key)).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>left表数据>>>>" + res_left_df.count())
    //right
    val right_need_enlarge = spark.sql(s"""select * from right_df where $key in ($o_key_str)""")

    var enlarge_df: DataFrame = right_need_enlarge.withColumn(key, concat_ws("_", lit("0"), col(key))).select(right_cols: _*)
    for (i <- 1 until hashNum) {
      val new_df = right_need_enlarge.withColumn(key, concat_ws("_", lit(s"$i"), col(key))).select(right_cols: _*)
      enlarge_df = enlarge_df.union(new_df).select(right_cols: _*)
    }
    val right_no_need_enlarge = spark.sql(s"""select * from right_df where $key not in ($o_key_str)""").select(right_cols: _*)
    val res_right_df = enlarge_df.union(right_no_need_enlarge).repartition(600, col(key)).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>right表数据>>>>" + res_right_df.count())

    //最后关联 去前缀
    val join_df = res_left_df.join(broadcast(res_right_df), Seq(key), "left")
      .withColumn(key, removePreUdf(col(key)))
    spark.catalog.dropTempView("right_df")
    spark.catalog.dropTempView("right_df_tmp")
    spark.catalog.dropTempView("left_df")
    logger.error("关联完后的数据总量为：" + join_df.count())
    join_df
  }

  def removePreUdf = udf((key: String) => {
    var res = key
    if (key.contains("_")) {
      res = key.split("_")(1)
    }
    res
  })


  def randomPreAdd(hashNum: Int) = udf((col: String) => {
    Random.nextInt(hashNum) + "_" + col
  })

}
