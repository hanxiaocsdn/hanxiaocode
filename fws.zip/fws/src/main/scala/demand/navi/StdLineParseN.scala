package demand.navi

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import common.SourceAndDiskCommon
import demand.utils._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 366280  重构代码commmoet模块中代码，原始618数据10倍增长后运行异常失败
 * @description: gis_eta_stdline_result_parse
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/06/14 9:46
 */
object StdLineParseN extends SourceAndDiskCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    try {
      result.fluentPutAll(result.getJSONObject("fields"))
      result.keySet().toArray.foreach(key => {
        if (result.get(key.toString).isInstanceOf[JSONObject]) {
          val temp = result.getJSONObject(key.toString)
          temp.keySet().toArray.foreach(k => {
            result.put(k.toString.toLowerCase, temp.getString(k.toString))
          })
        }
      })
    } catch {
      case e: Exception => "" + e
    }
    result
  }
  //  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").repartition(1000,col("data")).rdd.map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value


  def get3[T <% RDD[T]](value: T): RDD[T] = value

  def get4[T](value: T) = List(value)

  trait get5[-T, +U] {
    def apply(x: T): U
  }


  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)
    ParseLog(spark, args(0))
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    var runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = new ArrayBuffer[String]
    dateList += date

    getRddF = getStdLineRdd
    computeRddF = null
    table = "gis_eta_stdline_result_parse"
    structs = Array("appname", "date_time", "type", "sn", "response_time", "create_time", "ak", "remote_ip", "url", "interfacecontrol", "compensatetime", "src_zonecode", "dest_zonecode", "x1", "y1", "x2", "y2", "line_code", "plan_time", "strategy", "cc", "opt", "merge", "vehicle", "height", "width", "frequency", "test", "mload", "status", "src", "std_id", "query", "pns_dist", "pns_time", "std_dist", "std_compensatetime", "std_time", "std_coords", "list", "line_creattime", "tolls", "tolls_distance", "high_way", "traLight_count", "line_requireid", "task_type")
    keys = Array()
    //    keys = Array("appName", "date_time", "type", "sn", "time", "create_time", "url.ak", "url.remoteIp", "url.url", "url.interfaceControl", "url.compensateTime", "url.srcZoneCode", "url.destZoneCode", "url.x1", "url.y1", "url.x2", "url.y2", "url.lineCode", "url.planTime", "url.strategy", "url.cc", "url.opt", "url.merge", "url.vehicle", "url.height", "url.width", "url.frequency", "url.test", "url.mload", "data.status", "data.result.src", "data.result.stdId", "data.result.query", "data.result.pnsDist", "data.result.pnsTime", "data.result.dist", "data.result.compensateTime", "data.result.time", "data.result.coords", "data.result.list", "data.result.createTime", "data.result.tolls", "data.result.tollsDistance", "data.result.highway", "data.result.traLightCount", "url.lineRequireId", "url.taskType")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)

  }


  /**
   * 获取etStdLineRdd
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getStdLineRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    logger.error(">>>获取" + dateList.mkString(",") + "号的日志")
    val validRdd = getHiveRdd(spark, dateList, "")
    val computeRdd = validRdd
      .map(json => {
        val newJson: JSONObject = new JSONObject()
        val message_str = json.getString("message")
        var message: JSONObject = null
        if (!StringUtils.isEmpty(message_str)) {
          try {
            message = JSON.parseObject(message_str)
          } catch {
            case e: Exception => logger.error(">>>message转json异常")
          }
          if (message != null) {
            newJson.put("appname", message.getString("appName"))
            var dateTime = message.getString("dateTime")
            if (!StringUtils.isEmpty(dateTime)) dateTime = dateTime.split("\\.")(0)
            newJson.put("datetime", dateTime)
            newJson.put("type", message.getString("type"))
            newJson.put("sn", message.getString("sn"))
            newJson.put("responsetime", message.getString("time"))
            val url = message.getJSONObject("url")
            val data = message.getJSONObject("data")
            if (url != null) {
              newJson.put("ak", url.getString("ak"))
              newJson.put("remoteip", url.getString("remoteIp"))
              newJson.put("url", url.getString("url"))
              newJson.put("interfacecontrol", url.getString("interfaceControl"))
              newJson.put("compensatetime", url.getString("compensateTime"))
              newJson.put("srczonecode", url.getString("srcZoneCode"))
              newJson.put("destzonecode", url.getString("destZoneCode"))
              newJson.put("x1", url.getString("x1"))
              newJson.put("y1", url.getString("y1"))
              newJson.put("x2", url.getString("x2"))
              newJson.put("y2", url.getString("y2"))
              newJson.put("linecode", url.getString("lineCode"))
              newJson.put("plantime", url.getString("planTime"))
              newJson.put("strategy", url.getString("strategy"))
              newJson.put("cc", url.getString("cc"))
              newJson.put("opt", url.getString("opt"))
              newJson.put("merge", url.getString("merge"))
              newJson.put("vehicle", url.getString("vehicle"))
              newJson.put("height", url.getString("height"))
              newJson.put("width", url.getString("width"))
              newJson.put("frequency", url.getString("frequency"))
              newJson.put("test", url.getString("test"))
              newJson.put("mload", url.getString("mload"))
              newJson.put("linerequireid", url.getString("lineRequireId"))
              newJson.put("tasktype", url.getString("taskType"))
              val createTime = url.getLong("createTime")
              if (createTime != null) {
                val time = longToTime(createTime)
                val inc_date = time.split(" ")(0).replaceAll("-", "")
                newJson.put("inc_day", inc_date)
                newJson.put("createtime", time)
              }
            }
            if (data != null) {
              newJson.put("status", data.getString("status"))
              val result = data.getJSONObject("result")
              if (result != null) {
                newJson.put("src", result.getString("src"))
                newJson.put("stdid", result.getString("stdId"))
                newJson.put("query", result.getString("query"))
                newJson.put("pnsdist", result.getString("pnsDist"))
                newJson.put("pnstime", result.getString("pnsTime"))
                newJson.put("stddist", result.getString("dist"))
                newJson.put("stdcompensatetime", result.getString("compensateTime"))
                newJson.put("stdtime", result.getString("time"))
                newJson.put("stdcoords", result.getString("coords"))
                newJson.put("list", result.getString("list"))
                newJson.put("linecreattime", result.getString("createTime"))
                newJson.put("tolls", result.getString("tolls"))
                newJson.put("tollsdistance", result.getString("tollsDistance"))
                newJson.put("highway", result.getString("highway"))
                newJson.put("traLightcount", result.getString("traLightCount"))
              }
            }
          }
        }
        newJson
      })
      .filter(_ != null)
      .coalesce(200).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()

    computeRdd
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    //    val endDate1 = DateUtil.getDateStr(endDate, 1)
    var sql = ""
    val table = "eta_std_line_log"
    sql =
      s"""
         |select data from dm_gis.$table t
         | where inc_day between '$startDate' and '$endDate'
         | and get_json_object(get_json_object(data, '$$.message'),'$$.type') ='url_e'
         | --limit 100
       """.stripMargin
    logger.error("执行的sql语句：" + sql)
    val logRdd1 = get1(sql)
    val res_rdd = logRdd1.map(x => get2(x)).persist()
    logger.error(">>>>加载的数据总量为>>>>" + res_rdd.count())
    res_rdd
  }

}
