package demand.navi

import com.alibaba.fastjson.{JSONArray, JSONObject}
import demand.utils.{DateUtil, HttpClientUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.DecimalFormat
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 424772
 * @description: gis_gd_sdk_rectify_route
 * @demander:80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/12/27 17:19
 */
object GDParse_rectifyroute {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 500
  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val compare_track_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"

  def main(args: Array[String]): Unit = {
    val spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      UnionLog(spark, DateUtil.getToday, "true")
    } else if (args.length == 1) {
      //传入参数，单天任务
      UnionLog(spark, args(0), "false")
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }

    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      UnionLog(spark, date, "false")
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @param auto
   * @return
   */
  def UnionLog(spark: SparkSession, date: String, auto: String): Unit = {
    var getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]) = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null

    saveHiveRddF = NaviMain.mutiDayRddToHive

    getRddF = getGDParse_rectifyrouteRdd
    computeRddF = null
    table = "gis_gd_sdk_rectify_route"
    structs = Array("naviid", "routeid", "vehicle", "vehicletype", "navi_starttime", "navi_endtime", "tracks1", "tracks2", "len")
    keys = Array("naviid", "routeid", "vehicle", "vehicletype", "navi_starttime", "navi_endtime", "tracks1", "tracks2", "len")

    logger.error("开始处理" + date)
    parseSaveLog(spark, getRddF, computeRddF, table, structs, keys, saveHiveRddF, "3", date, auto)

  }

  /**
   * 解析日志主流程
   */
  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, String, String, String) => (RDD[JSONObject], ArrayBuffer[String]), computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, runType: String, date: String, auto: String): Unit = {
    val (etaComputeRdd, dateList) = getRddF(spark, runType, date, auto)
    if (etaComputeRdd != null) {
      if (computeRddF != null) {
        val resultRdd = computeRddF(etaComputeRdd)
        etaComputeRdd.unpersist()
        saveHiveRddF(spark, resultRdd.repartition(repartition), table, structs, keys, dateList)
        resultRdd.unpersist()
      }
      else {
        saveHiveRddF(spark, etaComputeRdd.repartition(repartition), table, structs, keys, dateList)
        etaComputeRdd.unpersist()
      }
    }
  }

  def getGDParse_rectifyrouteRdd(spark: SparkSession, runType: String, date: String, auto: String): (RDD[JSONObject], ArrayBuffer[String]) = {
    val dateList: ArrayBuffer[String] = new ArrayBuffer[String]()
    var runDate = ""
    if ("3".equalsIgnoreCase(runType)) {
      if ("true".equalsIgnoreCase(auto)) {
        runDate = DateUtil.getDateStr(date, -1)
      }
      else {
        runDate = date
      }
      dateList += runDate
    }

    logger.error(">>>获取" + runDate + "号的Navi关联偏航")
    val sql =
      s"""
         |select a.naviid,a.routeid,a.vehicle,a.vehicletype,a.navi_starttime,a.navi_endtime,b.tm,b.x,b.y,b.tp,b.ac,b.sp,b.be,a.inc_date from
         |(select naviid,routeid,vehicle,vehicletype,starttime as navi_starttime,endtime as navi_endtime,inc_day as inc_date from  dm_gis.gis_gd_sdk_top3_route where inc_day='$date') a
         |left join (select carno as vehicle,tm,x,y,tp,ac,sp,be from dm_gis.gis_navi_navi_sdk_history_track where inc_day='$date' and tm is not null and tm<>'') b on a.vehicle=b.vehicle where b.tm>=a.navi_starttime and b.tm<=a.navi_endtime
       """.stripMargin
    val resultRdd = NaviLogParse.getValidJson(spark, sql).persist()

    val computeRdd = resultRdd.map(json => {
      var routeid = ""
      var tm: java.lang.Long = null
      if (json != null) {
        routeid = json.getString("routeid")
        tm = json.getLong("tm")
      }

      if (tm == null) tm = Long.MaxValue

      (routeid, (tm, json))
    })
      .groupByKey()
      .map(obj => {
        val list = new ArrayBuffer[JSONObject]()
        val jsonList: List[JSONObject] = obj._2.toList.sortBy(_._1).map(_._2)
        val tracks1 = new JSONArray()
        val tracks1_new = new JSONArray()
        var tracks2_new = new ArrayBuffer[JSONObject]()
        var len = ""
        for (i <- jsonList.indices) {
          val json = jsonList(i)
          val newJson1 = new JSONObject()
          val tmp = new JSONArray()
          if (json != null) {
            val tp = json.getInteger("tp")
            val x = json.getDouble("x")
            val y = json.getDouble("y")
            val ac = json.getInteger("ac")
            val sp = json.getDouble("sp")
            val be = json.getDouble("be")
            val tm = json.getLong("tm")

            if (tp != null) newJson1.put("type", tp)
            if (x != null) newJson1.put("x", x)
            if (y != null) newJson1.put("y", y)
            if (ac != null) newJson1.put("accuracy", ac)
            if (sp != null) newJson1.put("speed", sp)
            if (be != null) newJson1.put("azimuth", be)
            if (tm != null) newJson1.put("time", tm)

            tmp.add(x)
            tmp.add(y)
            tmp.add(tm)
          }

          newJson1.put("index", i)
          tracks1.add(newJson1)
          tracks1_new.add(tmp)
        }

        val json = jsonList.head
        val result = accessRectifyUrl(json, tracks1)
        if (result != null) {
          val status = result.getInteger("status")
          val resultObject = result.getJSONObject("result")
          if (resultObject != null) {
            val tracks2 = resultObject.getJSONArray("tracks")
            len = resultObject.getString("len")
            if (tracks2 != null && tracks2.size() > 0) {
              for (i <- 0.until(tracks2.size())) {
                val track = tracks2.getJSONObject(i)
                if (track != null) {
                  val newJson = new JSONObject()
                  val x = track.getString("x")
                  val y = track.getString("y")
                  val tm = track.getString("time")

                  newJson.put("x", x)
                  newJson.put("y", y)
                  newJson.put("tm", tm)
                  tracks2_new += newJson
                }
              }
            }
          }
        }

        if (tracks1_new.size() > 0) json.put("tracks1", tracks1_new)
        if (tracks2_new.nonEmpty) {
          val tracks2_new2 = new JSONArray()
          val temp = tracks2_new.sortBy(j => j.getLong("tm"))
          temp.toList.foreach(j => {
            val tmp = new JSONArray()
            tmp.add(j.getDouble("x"))
            tmp.add(j.getDouble("y"))
            tmp.add(j.getLong("tm"))
            tracks2_new2.add(tmp)
          })
          json.put("tracks2", tracks2_new2)
        }
        json.put("len", len)

        json
      })
      .persist()
    logger.error(">>>日志量：" + computeRdd.count())
    resultRdd.unpersist()
    (computeRdd, dateList)
  }

  def accessRectifyUrl(json: JSONObject, tracks: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicletype") != null) vehicle_type = json.getInteger("vehicletype")
    val param = new JSONObject()
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("vehicle", vehicle_type)
    param.put("retflag", 7)
    param.put("addpoint", 1)
    param.put("poiinfo", 1)
    param.put("tracks", tracks)
    param.put("mat_ratio", 1)

    val process = new JSONObject()
    process.put("stay_time", 180)
    process.put("poi_range", 500)

    param.put("process", process)

    println("参数：" + param.toString)
    http_result = HttpClientUtil.getJsonByPostJson(rectify_url, param.toString)
    Thread.sleep(600)
    http_result
  }
}
