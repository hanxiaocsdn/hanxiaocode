package demand.navi

import com.alibaba.fastjson.{JSON, JSONObject}
import common.SourceAndDiskCommon
import demand.utils.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 498199
 * @description: 新增配置日志信息 dm_gis.gis_eta_navi_config_log_bdp
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2022/10/15 19:39
 */
object NaviParse_naviConfigLog extends SourceAndDiskCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    result.fluentPutAll(result.getJSONObject("taskResult"))
    result.keySet().toArray.foreach(key => {
      if (result.get(key.toString).isInstanceOf[JSONObject]) {
        val temp = result.getJSONObject(key.toString)
        temp.keySet().toArray.foreach(k => {
          result.put(k.toString.toLowerCase, temp.getString(k.toString))
        })
      }
    })
    "resultstatus,status"
      .split(";").foreach(x => result.put(x.split(",")(0), result.getString(x.split(",")(1))))
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value

  def main(args: Array[String]): Unit = {
    spark = SparkUtil.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      ParseLog(spark, DateUtil.getYesterday)
    } else if (args.length == 1) {
      //传入参数，单天任务
      ParseLog(spark, args(0))
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      batchTask(spark, args(0), args(1))
    }
    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      ParseLog(spark, date)
    }
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String]) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null
    var runDate = date

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = NaviMain.getMutiDayDateList(date)

    getRddF = getConfigLogRdd
    computeRddF = null
    table = "gis_eta_navi_config_log_bdp"

    structs = Array("task_id", "sendtime", "autocutsaveroute", "carplate", "currentopzonecode", "currentopzonesortnum", "detectioninterval", "detectiontimes", "actualarrivetm", "actualdeparttm", "outeraddrcode", "passzoneaddr", "passzonecode", "passzonecoordinate", "planarrivetm", "radius", "sortnum", "linedistance", "monitorintervalconfig", "navitmthreshold", "nextlatestarrivetm", "nextplanarrivetm", "opentasktosave", "plandeparttm", "planruntime", "prearrivetm", "savetmthreshold")
    keys = Array("")

    logger.error("开始处理" + runDate)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    NaviLogParse.parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList)
  }

  /**
   * 获取naviConfigLog日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getConfigLogRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String]): RDD[JSONObject] = {
    val logType = ""
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    val computeRdd = validRdd.flatMap(json => {
      val list = new ArrayBuffer[JSONObject]()
      val navi_arr_str = Array("actualArriveTm", "actualDepartTm", "outerAddrCode", "passZoneAddr", "passZoneCode", "passZoneCoordinate", "planArriveTm", "radius", "sortNum")
      var sendTime: java.lang.Long = null
      if (json != null) {
        sendTime = json.getLong("sendTime")
        json.put("sendtime", sendTime)
        //分区字段生成
        if (sendTime != null) {
          val inc_day = longToTime(sendTime).split(" ")(0).replaceAll("-", "")
          json.put("inc_day", inc_day)
        }
        val taskResult = json.getJSONObject("taskResult")
        if (taskResult != null) {
          val mutil_arr = taskResult.getJSONArray("groundTaskPassZoneResults")
          if (mutil_arr != null && mutil_arr.size() > 0) {
            for (i <- 0 until mutil_arr.size()) {
              val new_json = new JSONObject()
              json.keySet().toArray.map(key => {
                new_json.put(key.toString, json.getString(key.toString))
              })
              for (j <- 0 until navi_arr_str.length) {
                try {
                  new_json.put(navi_arr_str(j).toLowerCase, mutil_arr.getJSONObject(i).getString(navi_arr_str(j)))
                } catch {
                  case e: Exception => logger.error(json + "=======" + e.printStackTrace())
                }
              }
              list += new_json
            }
          }
        }
      }
      list
    }).map(json => {
      var task_id, sendTime, actualArriveTm, actualDepartTm, outerAddrCode, passZoneAddr, passZoneCode, passZoneCoordinate, planArriveTm, radius, sortNum = ""
      if (json != null) {
        task_id = json.getString("task_id")
        sendTime = json.getString("sendtime")
        actualArriveTm = json.getString("actualarrivetm")
        actualDepartTm = json.getString("actualdeparttm")
        outerAddrCode = json.getString("outeraddrcode")
        passZoneAddr = json.getString("passzoneaddr")
        passZoneCode = json.getString("passzonecode")
        passZoneCoordinate = json.getString("passzonecoordinate")
        planArriveTm = json.getString("planarrivetm")
        radius = json.getString("radius")
        sortNum = json.getString("sortnum")
      }
      ((task_id, sendTime, actualArriveTm, actualDepartTm, outerAddrCode, passZoneAddr, passZoneCode, passZoneCoordinate, planArriveTm, radius, sortNum), json)
    })
      .groupByKey()
      .map(obj => {
        val json = obj._2.toList.head
        json
      }).repartition(repartition).persist()
    logger.error(">>>日志量：" + computeRdd.count())
    validRdd.unpersist()
    computeRdd
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val endDate1 = endDate
    var sql = ""
    val table = "gis_eta_navi_query_config_hive"
    sql =
      s"""
         |select data,inc_day from dm_gis.$table t
         | where inc_day between '$startDate' and '$endDate1'
       """.stripMargin
    val logRdd1 = get1(sql)
    logRdd1.map(x => get2(x))
  }
}
