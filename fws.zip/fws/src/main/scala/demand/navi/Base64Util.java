package demand.navi;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.zip.GZIPInputStream;
import org.apache.commons.io.IOUtils;
import java.awt.Dimension;
import java.awt.Toolkit;

public class Base64Util {

    public static byte[] hex2bytes(String str) {
        if (str == null || str.length() == 0 || str.length() % 2 == 1) {
            return null;
        }
        byte[] ba = null;
        try {
            ba = new byte[str.length() / 2];
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < str.length(); i += 2) {
                sb.delete(0, sb.length());
                sb.append("0X");
                sb.append(str.substring(i, i + 2));
                String strDecode = sb.toString();
                ba[i / 2] = (byte) Integer.decode(strDecode).intValue();
            }
            sb = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            str = null;
        }
        return ba;
    }


//    public static byte[] ungzip(byte[] data) throws Exception {
//        ByteArrayInputStream bis = new ByteArrayInputStream(data);
//        GZIPInputStream gzip = new GZIPInputStream(bis);
//        byte[] buf = new byte[1024];
//        int num = true;
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//
//        int num;
//        while((num = gzip.read(buf, 0, buf.length)) != -1) {
//            bos.write(buf, 0, num);
//        }
//
//        gzip.close();
//        bis.close();
//        byte[] ret = bos.toByteArray();
//        bos.flush();
//        bos.close();
//        return ret;
//    }

    public static byte[] uncompress(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ByteArrayInputStream in = new ByteArrayInputStream(bytes);GZIPInputStream ungzip = new GZIPInputStream(in)) {
            byte[] buffer = new byte[256];
            int n;
            while ((n = ungzip.read(buffer)) >= 0) {
                out.write(buffer, 0, n);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            IOUtils.closeQuietly(out);
        }
        return out.toByteArray();
    }

    public static String get(String str){
        String result = "";
        try {
            result = new String(uncompress(Base64.getDecoder().decode(str)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static void main(String[] args){
        String temp = "H4sIAAAAAAAAALWa0Y4dNw5E/+U+jwOJEkXRf7DfEOTBsY3FAkEMOJOnwP++h91zkwCudjCZMfxgz9xbLYkii1Vs//jH7f2nT58//HZ7++Mft1/ePf7v8fcPH29vzX5Yfcf03cYeo7X9cPvl06//ffq49/EDv+7hy7NHrvzy8BU82/bR+965XKFb9zn7zunj9dE9Y09n/7mnglu23lrLWEvBbTQLju4xTcHnco/Vg/29Pjxsr7Wt2862BHy2Pneax+6m4H2x+JwrIoaE+2gj3Vuo1Re7dnawl5uEd8/tvXE0tfqq/XN635EKbZ6N8Lch974Gt9aWmfuWRx8xZsxuvSt0m6OROMfTFdojz7DMKeBO4EdsS5c7j+1z9Vlxf31wDrPdZ86u0pXrzmxWx3d57u3NbR5fUfC1xsjODyZvfPriSmcMvqbgc1Inu62lorZycPbM3WbIC2fTQanOpiot5mB9blwV+Wx7UChVCKrKInsbbRN2FXISlW/UthQ7WSNNvbXFIyS/DOcfbj4kmFNRY8uS1SV6Dm5kew4RcGtr91i20nWesviONdfcKk+t7b8lsoRDyB0WUEXCL3vLvvoI1n82ORk5nHOywyQXFdxJ4kyiF6LAzcZqxhPSeLyC7wl3HbStjm5rgcyMBr0qOAGHnhaJrs5usVoEN1fcJ+HUKNTXVaaz7e17sDN98tla2Bp9D5HoFKa16H5Q37NJ2UZxcm9VC5JeCNnstETqSKFzUCPcPPyjjv3tnVO6XBplNPZSFT5IRcgLzh8qauTLbulRnCwTJnm20zdal6vDTobUcJ4jVw82fvYLgYbUFvzQfeuwoyOcYtucTGUrUadE21HJstI6O5/wL5H/DvC9Mrw0Cvcq4cbB4bnIEHAe29BHEXDYv0BzWxQz7D5UI+ZCLKIlBSPBSU41m7qdUQPwy4pSMK+P9uI4xGMl5LOTHVK/i1qVbX+1WUnsR4EnqbzmVLkOmD7vF7KT/S50XbTW6QwKHoS9LdSEhjv6Z+7wqbvSan6vQ4Vm3d18Hd1YoQkZfSUqwN8BjqSEebna5ipyxd1UShb7C/i2IifujMeodHUKiYZay6vV4XW8AM1HSwkvST1DcwzmKBftHn23dV8IUqIEmkbTkjAMO+jKUruNNu/8qeCsbQih4EtycerUrC/t0UYfhIQNdvJV8uNu/UmniJzBAKJdSedS9M+WElWCzSB2WtdzVcwwdm7k84AtZFtAJPWjDGXYuGc4Oe1QnwLe7wQjj00i4h/R+7qp0MJhrzRuXR2bcJ/2qet8QR+x+zEltUIhZDoWaJGvopdXsy29HxeLu1NnDv/R8BTay/OzNMmo0OhdtMiVU+DM3MZTFQo4Ydn3yAr0bkivk7fV4oR7O9lcRxd3VlWAlLhiR3Sh1eb5yyV699x2XopCB5yMKi8lodDld8uuy3zh9+jW8saknEIvynfhoiQ7VR3QjflzsXZVeMSRjQpN/6+MvWAIaDXJpLwwG+jS5PQZpZnVpQXubvQsQyDhKASKNLdyKoDRKOWxCJwAFztxmz2XUr0WmDjEeOWcRG+ijl6nzkVLqDZLqpAxyuFNOoodUkKFbHl3zGVIcwilWH6jDVftoc1Ok6LgkMPmXLtLDWHlUPLKo7wQje+qjpKUianLnhR2kgxTURP9r/NcbEiTYy8rcVKjhPJuAh5PrNe0s7TZ7GmkpiQAOhdYQ8/3UCYH45mnLZXNqO5qI5+OqZtAky40g6I/JTpn1ih0VkuSYHLxaZynEpWA88G+3LnRTPrp11XcskR+PxSI6IQQGuSx2D7G9Wu0E9SchnTRowykA5+fdyYOjhoNNmd+mBQFZ/dUcRl+cXTcrh0E0ylFufmTMzUpezknWH/sEvMCTbpwrpFaBGD8aJJxGXcCt2M+UaOC10SMXtz6UL4YC0I+jYs+DnXsGmDtaF0JGE7EtqYjh6ewZw7LoBPQN6yh0PBulmCVrAwzIctqUqOHdvTwNpCFV5dOPrD9USMqUaigI+/jiFdHey9NCguwO4VepMXlYN9r3NdLFLs0h53bWOtqjvJCNNYSceLWiwUFmkqOc4qivOWL4TV5u1a8vVLKa6IqZxE4T5o03HwxD6ixf24YfErZyXVhau9zGgnffw7uFRyHsQIa0ylDCc9+TRNE5bTUcgD1T5VG4+kY+9O5Knh2OjneV07uENMwHP5WDzMQTn/uXaLpdtlqft9k3KCQcTDIBTwroD1nKVtFkO2v+ZSEc/QaSciuxrIotKt+7Fwn7RRBfsXN9ZXDHaobT4gNBXXMHOXOIfUYF0oE9ETt7ivpR5IXcV4YNLpC1MH31EMgKjBOR63TLbNcJ779op1TKLQFKsKUzVmNqyKb2JpuiQYTHMkmvelq9aoJJ3S8GlUyCN/qpy8Wca/JldXA+KKp2Si5jcQcUk0slB/VuNrF8M3KePsTSX4HeH2IErrSMqg7XHkOKX6xZ6QiTFPkrszKtyXgy+G0xR1X74TMyhnXuy71LoylB54jR72zlYuTkziiizeAL4bvkiEkrMk3zv+0d4A1M1n1dIm+v8hXja3e9d9F2L+IG8IUMREXTZWDG1V8zHI0HP1635tKuG4nOSuiON5grvPputSgV6x/vf386eH28dcPt7fi5jBl9XpZPgCGhcC/PNw+f/r98eN/eMBtvX9fk1J/0z40ezPj5/km+7v1BmPm/vGQlOv2cPvt8d3nx6/X4yRR//MCnpDvuQc1RrLsmqV++fLT/wFNaCGPXyIAAA==";
        String result = get(temp);
        System.out.println("");
    }

}
