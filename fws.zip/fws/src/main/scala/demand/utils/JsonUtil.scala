package demand.utils

import com.alibaba.fastjson.JSONObject
import org.apache.log4j.Logger

/**
  * Created by 01368978 on 2020/9/3.
  */
object JsonUtil {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  /**
    * 获取多层json的值
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonVal(obj: JSONObject, keys: String): Object = {
    var `val` : Object = null
    var tempObj = obj
    try {
      var keyArr : Array[String] = keys.split("\\.")
      for (i <- 0 to keyArr.length - 1){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.get(keyArr(i))
      }
    } catch {
      case e: Exception =>
        logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    `val`
  }

  /**
    * 获取多层json的值
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonVal(obj: JSONObject, keys: String, defaultValue: String): String = {
    var `val` : String = null
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      var keyArr : Array[String] = keys.split("\\.")
      for (i <- 0 to keyArr.length - 1){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getString(keyArr(i))
      }
    } catch {
      case e: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }

  /**
    * 获取多层json的值
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonValue(obj: JSONObject, keys: String, defaultValue: Any): Any = {
    var result : Any = null
    var tempObj = obj
    try {
      var keyArr : Array[String] = keys.split("\\.")
      for (i <- 0 to keyArr.length - 1){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          result = tempObj.getString(keyArr(i))
      }
    } catch {
      case e: Exception =>logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(result == null) result = defaultValue
    result
  }

  /**
    * 获取json里面的json对象
    * @param obj
    * @param key
    * @param defaultValue
    * @return
    */
  def getJsonObj(obj: JSONObject, key: String, defaultValue: String): String ={
    var returnStr : String = defaultValue
    var tempObj = obj
    try{
      if(key.contains(".")){
        var keyArr : Array[String] = key.split("\\.")
        for (i <- 0 to keyArr.length - 1){
          if(tempObj != null) tempObj = tempObj.getJSONObject(keyArr(i))
        }
      }
      else{
        if(tempObj != null) tempObj = tempObj.getJSONObject(key)
      }
      //      if(returnObj!=null) returnStr = JSON.toJSONString(returnObj).replaceAll("[\\r\\n\\t]", "")
      if(tempObj!=null) returnStr = tempObj.toJSONString().replaceAll("[\\r\\n\\t]", "")
    }catch{
      case e:Exception =>logger.error("获取json数据项" + key + "出错:" + obj, e)
    }
    returnStr
  }


}
