package demand.utils;

import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.*;
import java.io.*;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Created by 01368978 on 2021/4/3.
 * java程序启动工具类
 */
public class JavaUtil {

    private String filename;

    public JavaUtil() {
    }

    public JavaUtil(String filename) {
        this.filename = filename;
    }


    /**
     * 获取配置文件中属性
     * @param key
     * @return
     */
    public  String get(String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {
            in = JavaUtil.class.getClassLoader().getResourceAsStream(filename);
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }

    /**
     * 绕过验证
     *
     * @return
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    public static SSLContext createIgnoreVerifySSL() throws NoSuchAlgorithmException, KeyManagementException {
        SSLContext sc = SSLContext.getInstance("SSLv3");

        // 实现一个X509TrustManager接口，用于绕过验证，不用修改里面的方法
        X509TrustManager trustManager = new X509TrustManager() {
            @Override
            public void checkClientTrusted(
                    java.security.cert.X509Certificate[] paramArrayOfX509Certificate,
                    String paramString) throws CertificateException {
            }

            @Override
            public void checkServerTrusted(
                    java.security.cert.X509Certificate[] paramArrayOfX509Certificate,
                    String paramString) throws CertificateException {
            }

            @Override
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        };

        sc.init(null, new TrustManager[] { trustManager }, null);
        return sc;
    }

    public static String send(String url, String json, String encoding) throws KeyManagementException, NoSuchAlgorithmException, ClientProtocolException, IOException {
        String body = "";
        //采用绕过验证的方式处理https请求
        SSLContext sslcontext = createIgnoreVerifySSL();

        // 设置协议http和https对应的处理socket链接工厂的对象
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
                .register("http", PlainConnectionSocketFactory.INSTANCE)
                .register("https", new SSLConnectionSocketFactory(sslcontext, new HostnameVerifier() {
                    @Override
                    public boolean verify(String s, SSLSession sslSession) {
                        return true;
                    }
                }))
                .build();
        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
        HttpClients.custom().setConnectionManager(connManager);

        //创建自定义的httpclient对象
        CloseableHttpClient client = HttpClients.custom().setConnectionManager(connManager).build();
//        CloseableHttpClient client = HttpClients.createDefault();

        //创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);

//        //装填参数
//        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
//        if(map!=null){
//            for (Map.Entry<String, String> entry : map.entrySet()) {
//                nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
//            }
//        }
//        //设置参数到请求对象中
//        httpPost.setEntity(new UrlEncodedFormEntity(nvps, encoding));

        StringEntity entityIn = new StringEntity(json, ContentType.APPLICATION_JSON);
        //设置参数到请求对象中
        httpPost.setEntity(entityIn);

        //设置header信息
        //指定报文头【Content-type】、【User-Agent】
        httpPost.setHeader("Content-type", "application/json");
        //httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");

        //执行请求操作，并拿到结果（同步阻塞）
        CloseableHttpResponse response = client.execute(httpPost);
        //获取结果实体
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            //按指定编码转换结果实体为String类型
            body = EntityUtils.toString(entity, encoding);
        }
        EntityUtils.consume(entity);
        //释放链接
        response.close();
        client.close();
        return body;
    }

/*    *//**
     * 读取资源文件
     * @param fileName
     * @return
     */
    public static Properties getProp(String fileName) {
        Properties props = new Properties();
        try (InputStreamReader in = new InputStreamReader(JavaUtil.class.getClassLoader().getResourceAsStream(fileName), "utf-8")) {
            props.load(in);
        } catch (IOException e) {
            System.out.println("Load properties file error! file name:" + fileName + "\n" + e);
        }
        return props;
    }

    /**
     * 读取资源文件
     * @param key
     * @return
     */
    public static String get(String key,Properties props) {
        String value = props.getProperty(key);
        return value;
    }


    /**
     * 读取资源文件返回数据流
     * @param fileName
     * @return
     */
    public static BufferedReader    readFile(String fileName) {
        BufferedReader buff = null;
        try{
            InputStreamReader in = new InputStreamReader(JavaUtil.class.getClassLoader().getResourceAsStream(fileName), "utf-8");
            buff = new BufferedReader(in);
        }catch(IOException e){

        }
        return buff;
    }

    /**
     * 读取本笃资源文件
     * @param fileName
     * @return
     */
    public static BufferedReader readLocalFile(String fileName) {
        BufferedReader buff = null;
        try{
            InputStreamReader in = new InputStreamReader(new FileInputStream(fileName), "utf-8");
            buff = new BufferedReader(in);
        }catch(IOException e){

        }
        return buff;
    }



}
