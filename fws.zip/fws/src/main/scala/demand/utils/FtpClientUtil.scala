package demand.utils

import java.io.{File, FileOutputStream}

import org.apache.commons.net.ftp.{FTPClient, FTPFile, FTPReply}
import org.apache.log4j.Logger

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01368978 on 2020/12/17.
  */
object FtpClientUtil {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)
  val fileSepartor:String = System.getProperty("file.separator")

  /**
    * 连接ftp服务器
    * @param hostname
    * @param username
    * @param password
    * @param port
    * @return
    */
  def getFtpClient(hostname:String,username:String,password:String,port:Int): FTPClient ={
    val ftpClient = new FTPClient
    ftpClient.setControlEncoding("UTF-8")
    ftpClient.setConnectTimeout(1000 * 60)
    ftpClient.setDataTimeout(1000 * 60)
    ftpClient.setDefaultTimeout(1000 * 60)
    ftpClient.setBufferSize(1024 * 4)//工作流的大小
    ftpClient.enterLocalPassiveMode()// 被动模式
    //连接服务器
    ftpClient.connect(hostname, port)
    //登录FTP服务器
    ftpClient.login(username, password)
    // 验证FTP服务器是否登录成功
    val replyCode = ftpClient.getReplyCode

    if (!FTPReply.isPositiveCompletion(replyCode)) {
      logger.error(">>>ftp连接失败")
    }
    ftpClient
  }

  /**
    *
    * @param ftpClient ftp下载文件操作
    * @param ftpRelativePath 文件所在目录的相对路径
    */
  def downloadFtpFile(ftpClient:FTPClient,ftpRelativePath:String,downloadPath:String,keyword:String): Unit ={
    ftpClient.changeWorkingDirectory(ftpRelativePath)
    val ftpFiles = ftpClient.listFiles()
    logger.error(">>>该目录下总文件数量："+ftpFiles.size)
    val unhookFtpFile = new ArrayBuffer[FTPFile]()
    for(file <- ftpFiles){
      if(file.getName.indexOf(keyword) != -1){//unhook
        unhookFtpFile += file
      }
    }
    logger.error(">>>需要下载的文件数量："+unhookFtpFile.size)
    print(">>>正在下载文件:")
    for(ftpFile<- unhookFtpFile){
      val filename = ftpFile.getName
      print(filename+",")
      val localfile = new File(downloadPath+fileSepartor+filename)
      val fos = new FileOutputStream(localfile)
      ftpClient.retrieveFile(filename,fos)
      fos.close()
    }
    ftpClient.logout()
    logger.error(">>>下载结束！")
  }

  def main(args: Array[String]): Unit = {
    test()
  }

  def test(): Unit ={
    println(">>>start ftp download...")
    val ftpClient = getFtpClient("10.202.43.200","anonymous","L1iwM21xYF",21)
    val downloadPath = "E:\\demand\\aoi\\unhook_aoi\\download\\20190619\\"
    val ftpRelativePath="/ftp/aoi_manager/conf/output/hook/unhook/"
    val keyword = "unhook"
    downloadFtpFile(ftpClient,ftpRelativePath,downloadPath,keyword)
    logger.error(">>>The End!")
  }



}
