package demand.utils

import java.io.FileInputStream

import org.apache.commons.net.ftp.{FTPClient, FTPReply}
import org.apache.log4j.Logger

/**
  * Created by 01368978 on 2021/3/16.
  */
object FtpUtils {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    start()
  }

  def start(): Unit ={
    println("-------------------")
    val ftpClient = getFtpClient("gisftp.sf-express.com", 21, "devftp", "brYsj2.023ftKjdev","utf-8")

    val srcPath = "E:\\demand\\small_demand\\deppon\\t_deppon_code_relation_list.csv"
    val inputStream = new FileInputStream(srcPath)
//    ftpClient.dele(path)

    //    ftpClient.storeFile("/rds/",inputStream)
    val path = "/rds/t_deppon_code_relation_list.csv"
        val file: Boolean = ftpClient.storeFile("/rds/t_deppon_code_relation_list.csv",inputStream)
    println(file)
    ftpClient.dele(path)

  }

  def mkDir(): Unit ={

  }

  def getDefaultFtpClient={
    getFtpClient("gisftp.sf-express.com", 21, "devftp", "brYsj2.023ftKjdev","utf-8")
  }

  /**
    * 传输文件到ftp
    * @param srcPath
    * @param destPath
    * @param filename
    * @param ftpClient
    */
  def transferFileToFtp(srcPath:String,destPath:String,filename:String,ftpClient:FTPClient=getDefaultFtpClient): Unit ={
    logger.error(">>>传输文件：srcPath="+srcPath+",destPath="+destPath)
    ftpClient.changeWorkingDirectory(destPath)
    ftpClient.setDataTimeout(1200000)
    val inputStream = new FileInputStream(filename)
    val destfile = destPath+"/"+filename
    val success = ftpClient.storeFile(destfile,inputStream)
    if(success){
      logger.error(">>>传输文件成功！"+filename)
    }else{
      logger.error(">>>传输文件失败！"+filename)
    }
  }

  /**
    * 连接并登录ftp
    * @param host
    * @param port
    * @param username
    * @param password
    * @param character
    * @return
    */
  def getFtpClient(host:String, port:Int, username:String, password:String, character:String): FTPClient ={
    val ftpClient = new FTPClient
    ftpClient.setControlEncoding(character)
    println(">>>连接ftp服务器="+host+":"+port)
    ftpClient.connect(host,port) //连接ftp服务器
    ftpClient.login(username,password) //登录ftp服务器
    val replyCode = ftpClient.getReplyCode //是否成功登录服务器
    if (!FTPReply.isPositiveCompletion(replyCode)) {
      println("connect failed...ftp服务器:" + host + ":" + port)
    }else{
      println("connect successful...ftp服务器:" + host + ":" + port)
      //避免忘了开启被动模式
      ftpClient.enterLocalPassiveMode()
    }
    ftpClient
  }

}
