package demand.utils

import java.sql.{Connection, DriverManager, PreparedStatement, SQLException}
import org.apache.log4j.Logger

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01368978 on 2021/4/3.
  */
object DbUtil {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  /**
    * 获取数据库连接
    * @param javaUtil
    * @return
    */
  def getConnection(javaUtil:JavaUtil): Connection ={
    var  connection :Connection = null
    try {
      val DRIVER = javaUtil.get("mysql_driver")
      val URL = javaUtil.get("mysql_url")
      val USERNAME = javaUtil.get("mysql_username")
      val PASSWORD = javaUtil.get("mysql_password")
      Class.forName(DRIVER)
      connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)
    } catch {
      case e:Exception =>logger.error(">>>数据库连接异常："+e.getMessage)
    }
    connection
  }

  /**
    * 查询语句
    * @param conn 连接
    * @param sql 执行语句
    * @param params 传入参数数组
    * @param columns 查询列名数组
    * @return
    */
  def selectColumns(conn: Connection, sql: String, params: Array[String], columns: Array[String]): ArrayBuffer[Array[Any]] = {
    var ps:PreparedStatement= null
    var rows: ArrayBuffer[Array[Any]] = new ArrayBuffer[Array[Any]]
    try {
      ps = conn.prepareStatement(sql)
      if(params!=null){
        for(i <- 0 until params.length) ps.setString(i+1,params(i))
      }
      val rs = ps.executeQuery()
      while(rs.next()){
        val row:Array[Any] = new Array[Any](columns.length)
        for(i <- 0 until row.length){
          val field = rs.getObject(columns(i))
          if(field!=null) {
            row(i) = field.toString
          }else{
            row(i)=""
          }
        }
        rows += row
      }

    } catch {
      case e: SQLException =>println(">>>查询数据异常："+e)

    }
    rows
  }

  def selectColumn(conn: Connection, sql: String, params: Array[String], columns: Array[String]): ArrayBuffer[String] = {
    var ps:PreparedStatement= null
    var rows: ArrayBuffer[String] = new ArrayBuffer[String]
    try {
      ps = conn.prepareStatement(sql)
      if(params!=null){
        for(i <- 0 until params.length) ps.setString(i+1,params(i))
      }
      val rs = ps.executeQuery()
      while(rs.next()){
        val field = rs.getObject(1)
        if(field!=null) {
          rows += field.toString
        }else{
          rows += ""
        }
      }
    } catch {
      case e: SQLException =>println(">>>查询数据异常："+e)
    }
    rows
  }

  /**
    * 查询语句-无需传参
    * @param conn
    * @param sql
    * @param columns
    * @return
    */
  def selectColumns(conn: Connection, sql: String,  columns: Array[String]): ArrayBuffer[Array[Any]] = {
    selectColumns(conn,sql,null,columns)
  }

  /**
    * 单条执行
    *
    * @param sql
    * @param params
    */
  def execute(conn:Connection,sql: String, params: Array[Any]): Unit = {
    try{
      val ps = conn.prepareStatement(sql)
      if (params != null) {
        for (i <- 0 until params.length) ps.setString(i + 1, params(i).toString)
      }
      ps.executeUpdate()
      ps.close()
    } catch {
      case e: Exception => println(">>>数据库操作异常," + e +",sql:"+sql+",param:"+params)
    }
  }


  /**
    * 批量执行
    *
    * @param sql
    * @param paramList
    */
  def batchExecute(conn:Connection,sql: String, paramList: ArrayBuffer[Array[Any]]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(false)
      for (params: Array[Any] <- paramList) {
        if (params != null) {
          for (i <- 0 until params.length) ps.setString(i + 1, params(i).toString)
          ps.addBatch()
        }
      }
      ps.executeBatch()
      conn.commit()
      ps.close()
    } catch {
      case e: Exception => logger.error(String.format(e + ">>>数据批量操作异常: %s", sql))
    }
  }

  /**
    * 批量执行
    *
    * @param sql
    * @param paramList
    */
  def batchListExecute(conn:Connection,sql: String, paramList: List[Array[Any]]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(false)
      for (params: Array[Any] <- paramList) {
        if (params != null) {
          for (i <- 0 until params.length) ps.setString(i + 1, params(i).toString)
          ps.addBatch()
        }
      }
      ps.executeBatch()
      conn.commit()
      ps.close()
    } catch {
      case e: Exception => logger.error(String.format(e + ">>>数据批量操作异常: %s", sql))
    }
  }



}
