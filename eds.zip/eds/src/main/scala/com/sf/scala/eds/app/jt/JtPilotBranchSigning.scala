package com.sf.scala.eds.app.jt

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.log4j.Logger
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.functions.{asc, col, concat_ws, count, desc, lit, row_number, when}
import org.apache.spark.storage.StorageLevel


import java.net.URLEncoder
import scala.collection.mutable.ArrayBuffer

/**
 *需求名称：极兔网点历史签收数据指标统计
 *需求描述：根据aoi统计签收二段ZC	签收三段码TC的出现规律，交叉分析数据的合理性
 *需求方：01403862 赵媛
 *开发: 周勇(01390943)
 *任务创建时间：20231225
 *任务id：1136
 **/

object JtPilotBranchSigning {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    //衡度平台
    val spark = Spark.getSparkSession(className, null, false, 2)
    //科技平台
//    val SparkInfo = SparkUtil.getSpark(className)
//    val spark = SparkInfo.getSession
    import spark.implicits._
    //获取传入参数日期:昨日日期
    val dayvar1 = args(0)
    val dayvar2 = args(1)

    val signing_data=spark.sql(
      s"""
         |select * from dm_gis.jt_pilot_branch_signing_dtl
         |where inc_day='$dayvar1'
         |""".stripMargin)
      .withColumn("province",when($"province".isNull || functions.trim($"province")==="","").otherwise($"province"))
      .withColumn("city",when($"city".isNull || functions.trim($"city")==="","").otherwise($"city"))
      .withColumn("county",when($"county".isNull || functions.trim($"county")==="","").otherwise($"county"))
      .withColumn("street",when($"street".isNull || functions.trim($"street")==="","").otherwise($"street"))
      .withColumn("rec_street",when($"rec_street".isNull || functions.trim($"rec_street")==="","").otherwise($"rec_street"))
      .withColumn("detail_address",when($"detail_address".isNull || functions.trim($"detail_address")==="","").otherwise($"detail_address"))
      //拼接地址：省、城市、区县、乡镇、收件街道以及详细地址拼接得到address
      .withColumn("full_address",concat_ws("",$"province",$"city",$"county",$"street",$"rec_street",$"detail_address"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val signing_second_import=spark.sql(
      s"""
         |select * from dm_gis.jt_pilot_branch_signing_second_import
         |""".stripMargin)
      .select("aoiid","second_code")
      .withColumnRenamed("aoiid","aoi_new")

    val signing_three_import=spark.sql(
      s"""
         |select * from dm_gis.jt_pilot_branch_signing_three_import
         |""".stripMargin)
      .select("aoiid","three_code")
      .withColumnRenamed("aoiid","aoi_new")

    val signing_secondaddr_import=spark.sql(
      s"""
         |select * from dm_gis.jt_pilot_branch_signing_secondaddr_import
         |""".stripMargin)
      .withColumn("full_address",$"address")
      .withColumn("secondaddr_code",$"second_code")
      .select("full_address","secondaddr_code")

    //统计地址频次
    val address_cnt=signing_data
      .groupBy("full_address")
      .agg(count($"inc_day") as "addr_cnt")

    //地址去重获取接口
    val address_data=signing_data
      .select("waybill_no","full_address")
      .withColumn("rank",row_number().over(Window.partitionBy("full_address").orderBy(asc("waybill_no")) ))
      .filter($"rank"===1)
      .drop("rank")

     val address_data_rdd=SparkUtils.getDfToJson(spark, address_data, 300)

    //解析接口数据
     val result_data=Multi_address_query_url(spark,address_data_rdd, 5)
       .map(obj=> {
         val full_address = obj.getString("full_address")
         val rank = obj.getString("rank")
         val src = obj.getString("src")
         val dept = obj.getString("dept")
         val groupid = obj.getString("groupid")
         val aoiid = obj.getString("aoiid")
         val atAoiSrc = obj.getString("atAoiSrc")
         val splitResult = obj.getString("splitResult")
         val filters = obj.getString("filters")
         val group = obj.getString("group")
         val key = obj.getString("key")
         val aoi_ks = obj.getString("aoi_ks")
         val aoitag_ks = obj.getString("aoitag_ks")
         (full_address,rank,src,dept,groupid,aoiid,atAoiSrc,splitResult,filters,group,key,aoi_ks,aoitag_ks)
       }).toDF("full_address","rank","src","dept","groupid","aoiid","atAoiSrc",
       "splitResult","filters","group","key","aoi_ks","aoitag_ks")
       .repartition(300)
       .withColumn("aoi_new",when(!$"aoiid".isNull && $"aoiid" !="",$"aoiid").otherwise($"aoi_ks"))
       .withColumn("aoisrc_new",when(!$"atAoiSrc".isNull && $"atAoiSrc" !="",$"atAoiSrc").otherwise($"aoitag_ks"))
       .join(signing_second_import,Seq("aoi_new"),"left")
       .join(signing_three_import,Seq("aoi_new"),"left")
       .join(signing_secondaddr_import,Seq("full_address"),"left")
       .join(address_cnt,Seq("full_address"),"left")
       .withColumn("znocode_jt",when(!$"aoiid".isNull && $"aoiid" !="",$"second_code").otherwise($"secondaddr_code"))
       .withColumn("areacode_jt",$"three_code")

        logger.error("存储临时表")
    //选择所需列
    val table_cols_mid = spark.sql("""select * from dm_gis.jt_pilot_branch_signing_mid limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, result_data.withColumn("inc_day",lit(dayvar2)).select(table_cols_mid: _*), Seq("inc_day"), "dm_gis.jt_pilot_branch_signing_mid")

    val res=signing_data.join(result_data,Seq("full_address"),"left")
      .withColumn("inc_day",lit(dayvar2))

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_csv_jt_pilotbranchsign_di limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, res.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_csv_jt_pilotbranchsign_di")

    spark.close()
  }

  //定义获取url数据
  def address_query_url(ak:String,obj:JSONObject): JSONObject = {
    try {

      val full_address = URLEncoder.encode(obj.getString("full_address"), "UTF-8")
      val ak = "e4c049dfc856449aadf3c0aa19e662b7"
      //获取接口数据
      val url = s"http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=$full_address&province=&cityName=&district=&city=021&ak=$ak&opt=zh"
      val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 4)
      val ret: JSONObject = JSON.parseObject(retStr)

      val status=ret.getString("status")
      var src=""
      var dept=""
      var groupid=""
      var aoiid=""
      var atAoiSrc=""
      var splitResult=""
      var filters=""
      var group=""
      var key=""

      if(status==0 || status=="0"){
        try{
          src=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("src")
          dept=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("dept")
          groupid=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("groupid")
          aoiid=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid")
          atAoiSrc=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("atAoiSrc")
        }
        catch{
          case e: Exception => logger.error(e)
            obj.put("err_msg1",e.getMessage)
        }
      }

      if(status==0 || status=="0"){
        try{
          splitResult=ret.getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult")
          val geocoder=ret.getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder")
          val s=geocoder.size()
          val filters_arry=new ArrayBuffer[String]()
          val group_arry=new ArrayBuffer[String]()
          val key_arry=new ArrayBuffer[String]()
          if(s>0){
            for(i<-0 until s){
              val filters_i=geocoder.getJSONObject(i).getString("filter")
              val group_i=geocoder.getJSONObject(i).getString("group")
              val key_i=geocoder.getJSONObject(i).getString("key")
              filters_arry.append(filters_i)
              group_arry.append(group_i)
              key_arry.append(key_i)
            }
          }
          filters=filters_arry.mkString("$")
          group=group_arry.mkString("$")
          key=key_arry.mkString("$")
        }
        catch{
          case e: Exception => logger.error(e)
            obj.put("err_msg2",e.getMessage)
        }
      }


      var aoi_ks=""
      var aoitag_ks=""

      if(aoiid ==null || aoiid.trim =="")
        {
          val ak2 = "e4c049dfc856449aadf3c0aa19e662b7"
          val url2=s"http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam?ak=$ak2&address=$full_address&city=021&company=&province=&cityName=&dept=$dept&sssDept=&tc2Dept=&tc2Tc=&tc2Aoi=&tc2AoiCode=&x=&y=&mobile="
          val retStr2: String = HttpInvokeUtil.sendGet(url2, "UTF-8", 4)
          val ret2: JSONObject = JSON.parseObject(retStr2)
          val status2=ret2.getString("status")
          if(status2==0 || status2=="0"){
            aoi_ks=ret2.getJSONObject("result").getString("aoi")
            aoitag_ks=ret2.getJSONObject("result").getString("aoiTag")
          }
        }

      obj.put("src",src)
      obj.put("dept",dept)
      obj.put("groupid",groupid)
      obj.put("aoiid",aoiid)
      obj.put("atAoiSrc",atAoiSrc)
      obj.put("splitResult",splitResult)
      obj.put("filters",filters)
      obj.put("group",group)
      obj.put("key",key)
      obj.put("aoi_ks",aoi_ks)
      obj.put("aoitag_ks",aoitag_ks)
    }
    catch{
      case e: Exception => logger.error(e)
        obj.put("err_msg",e.getMessage)
    }
    obj
  }

  //并发调取接口并发请求，由于每个ak单分钟限制3000
  def Multi_address_query_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl = s"http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api"
    val httpAk="e4c049dfc856449aadf3c0aa19e662b7"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "953481", "极兔网点历史签收数据指标统计",
      "极兔网点历史签收数据指标统计",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val httpUrl2 = s"http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam"
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "953481", "极兔网点历史签收数据指标统计",
      "极兔网点历史签收数据指标统计",
      httpUrl2, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, address_query_url, 5, "e4c049dfc856449aadf3c0aa19e662b7", 3000)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId2)

    logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }

}
