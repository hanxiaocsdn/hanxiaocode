package com.sf.scala.eds.app.jt

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import com.sf.gis.scala.base.spark.{SparkNet, SparkUtils}
import org.apache.log4j.Logger
import com.sf.lbs.seg.normal.service.impl.LbsNormalServiceImpl
import com.sf.lbs.seg.normal.util.Response
import com.sf.lbs.seg.normal.vo.Normal
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{col, desc, lit, row_number, substring, udf, when}
import org.apache.spark.storage.StorageLevel
import scala.util.Random
import java.net.URLEncoder
import java.util.List
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.expressions.Window

import scala.collection.JavaConversions._
import java.util

/**
 *需求名称：极兔历史运单地址获取aoiid等信息
 *需求描述：从运单明细取出需要的运单以及明细地址，调取at派接口，获取需要的src，dept，groupid，aoiid，atAoiSrc，filters
 *需求方：01434056 唐巧亭
 *开发: 周勇(01390943)
 *任务创建时间：20240130
 *任务id：1006410
 **/
object JTGetAoiidCheck {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")

    //衡度平台
    //val spark = Spark.getSparkSession(className, null, false, 2)

    //科技平台
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    val inc_flag1="1"
    logger.error("inc_flag="+inc_flag1)
    start_fun(spark, inc_flag1)

    val inc_flag2="2"
    logger.error("inc_flag="+inc_flag2)
    start_fun(spark, inc_flag2)

    val inc_flag3="3"
    logger.error("inc_flag="+inc_flag3)
    start_fun(spark, inc_flag3)

    val inc_flag4="4"
    logger.error("inc_flag="+inc_flag4)
    start_fun(spark, inc_flag4)

    val inc_flag5="5"
    logger.error("inc_flag="+inc_flag5)
    start_fun(spark, inc_flag5)

    val inc_flag6="6"
    logger.error("inc_flag="+inc_flag6)
    start_fun(spark, inc_flag6)

    val inc_flag7="7"
    logger.error("inc_flag="+inc_flag7)
    start_fun(spark, inc_flag7)

    val inc_flag8="8"
    logger.error("inc_flag="+inc_flag8)
    start_fun(spark, inc_flag8)

    val inc_flag9="9"
    logger.error("inc_flag="+inc_flag9)
    start_fun(spark, inc_flag9)

    val inc_flag10="10"
    logger.error("inc_flag="+inc_flag10)
    start_fun(spark, inc_flag10)

    val inc_flag11="11"
    logger.error("inc_flag="+inc_flag11)
    start_fun(spark, inc_flag11)

    val inc_flag12="12"
    logger.error("inc_flag="+inc_flag12)
    start_fun(spark, inc_flag12)

    val inc_flag13="13"
    logger.error("inc_flag="+inc_flag13)
    start_fun(spark, inc_flag13)

   spark.close()

  }

  def start_fun(spark: SparkSession, inc_flag: String): Unit = {
    import spark.implicits._

    val flag_data = spark.sql(s"select * from dm_gis.dm_jt_waybillgetaoiid_af where flag='$inc_flag' ")
      .withColumn("threecode",three_split_udf($"terminaldispatchcode"))

    val flag_data2=flag_data.rdd.flatMap(Row=>{
      val  full_addr = Row.getAs[String]("full_addr")
      val receivercityname_tmp=Row.getAs[String]("receivercityname")
      var adcode=""
      try {
        adcode=GetAdcodes.getInstance(full_addr)
      }
      catch {
        case e:Exception =>logger.error("ee:"+e.getMessage)
      }
      val tmp = new JSONObject()
      tmp.put("full_addr", full_addr)
      tmp.put("receivercityname_tmp", receivercityname_tmp)
      tmp.put("adcode", adcode)
      val tmpList = new util.ArrayList[JSONObject]()
      tmpList.add(tmp)
      tmpList.iterator()
    }).map(obj=>{
      val full_addr=obj.getString("full_addr")
      val receivercityname_tmp=obj.getString("receivercityname_tmp")
      val adcode=obj.getString("adcode")
      (full_addr,receivercityname_tmp,adcode)
    }).toDF("full_addr","receivercityname_tmp","adcode")
      .withColumn("adcode_tmp",when($"receivercityname_tmp".like("%北京%") || $"receivercityname_tmp".like("%上海%")
        || $"receivercityname_tmp".like("%重庆%") || $"receivercityname_tmp".like("%天津%"),substring($"adcode",1,2)).otherwise(substring($"adcode",1,4)))

    val x_seq =flag_data.join(flag_data2,Seq("full_addr"),"left")

    val adcodeimport = spark.sql(
      s"""select case when name like '%北京%' or name like '%上海%'
         |or name like '%重庆%' or name like '%天津%'  then substr(adcode,1,2) else substr(adcode,1,4) end adcode_tmp,citycode from dm_gis.dm_csv_jt_adcodeimport_di """.stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("adcode_tmp").orderBy(desc("citycode"))))
      .filter($"rank"===1)
      .drop("rank")

    val x_seq2 = x_seq.join(adcodeimport, Seq("adcode_tmp"), "left")

    val x_seq3_rdd = SparkUtils.getDfToJson(spark, x_seq2)

    //获取接口

    val result_data=Multi_address_query_url(spark,x_seq3_rdd, 8)
      .map(obj=> {
        val full_addr = obj.getString("full_addr")
        val adcode = obj.getString("adcode")
        val citycode = obj.getString("citycode")
        val src = obj.getString("src")
        val dept = obj.getString("dept")
        val groupid = obj.getString("groupid")
        val aoiid = obj.getString("aoiid")
        val ataoisrc = obj.getString("atAoiSrc")
        val splitresult = obj.getString("splitResult")
        val filters = obj.getString("filters")
        val groups = obj.getString("group")
        val keys = obj.getString("key")
        (full_addr,adcode,citycode,src,dept,groupid,aoiid,ataoisrc,splitresult,filters,groups,keys)
      }).toDF ("full_addr","adcode","citycode","src","dept","groupid","aoiid","ataoisrc","splitresult","filters","groups","keys")

    val result_data2=flag_data.join(result_data,Seq("full_addr"),"left")
                     .withColumn("inc_flag",lit(inc_flag))

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_jt_waybillgetaoiid2_af limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    overwriteToHiveDynamics(spark,result_data2.select(table_cols: _*), Seq("inc_flag"), "dm_gis.dm_jt_waybillgetaoiid2_af")

    logger.error(">>>>任务已完成！")

  }

  //三段码切分
  def three_split(x:String): String ={
    val y=x.split(",")
    val s=y.size
    if(s==3){
      return y(2)
    }
    else
      {return ""}
  }

  val three_split_udf=udf(three_split _)
  //定义获取url数据
  def address_query_url(ak:String,obj:JSONObject): JSONObject = {
    Thread.sleep(Random.nextInt(200))
    try {

      val full_address = URLEncoder.encode(obj.getString("full_addr"), "UTF-8")
      val citycode = obj.getString("citycode")
      val ak = "e4c049dfc856449aadf3c0aa19e662b7"
      //获取接口数据
      val url = s"http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=$full_address&province=&cityName=&district=&city=$citycode&ak=$ak&opt=zh"
      val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 4)
      val ret: JSONObject = JSON.parseObject(retStr)

      val status=ret.getString("status")
      var src=""
      var dept=""
      var groupid=""
      var aoiid=""
      var atAoiSrc=""
      var splitResult=""
      var filters=""
      var group=""
      var key=""

      if(status==0 || status=="0"){
        try{
          src=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("src")
          dept=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("dept")
          groupid=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("groupid")
          aoiid=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid")
          atAoiSrc=ret.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("atAoiSrc")
        }
        catch{
          case e: Exception => logger.error(e)
            obj.put("err_msg1",e.getMessage)
            aoiid=e.getMessage

        }
      }
      else{
        aoiid=retStr
      }

      if(status==0 || status=="0"){
        try{
          splitResult=ret.getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult")
          val geocoder=ret.getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder")
          val s=geocoder.size()
          val filters_arry=new ArrayBuffer[String]()
          val group_arry=new ArrayBuffer[String]()
          val key_arry=new ArrayBuffer[String]()
          if(s>0){
            for(i<-0 until s){
              val filters_i=geocoder.getJSONObject(i).getString("filter")
              val group_i=geocoder.getJSONObject(i).getString("group")
              val key_i=geocoder.getJSONObject(i).getString("key")
              filters_arry.append(filters_i)
              group_arry.append(group_i)
              key_arry.append(key_i)
            }
          }
          filters=filters_arry.mkString("$")
          group=group_arry.mkString("$")
          key=key_arry.mkString("$")
        }
        catch{
          case e: Exception => logger.error(e)
            obj.put("err_msg2",e.getMessage)
            key=e.getMessage
        }
      }
      else{
        key=retStr
      }

      obj.put("src",src)
      obj.put("dept",dept)
      obj.put("groupid",groupid)
      obj.put("aoiid",aoiid)
      obj.put("atAoiSrc",atAoiSrc)
      obj.put("splitResult",splitResult)
      obj.put("filters",filters)
      obj.put("group",group)
      obj.put("key",key)
    }
    catch{
      case e: Exception => logger.error(e)
        obj.put("err_msg",e.getMessage)
    }
    obj
  }

  //并发调取接口并发请求，由于每个ak单分钟限制3000
  def Multi_address_query_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl = s"http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api"
    val httpAk="e4c049dfc856449aadf3c0aa19e662b7"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "1006410", "极兔历史运单地址获取aoiid等信息",
      "极兔历史运单地址获取aoiid等信息",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)


    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, address_query_url, 8, "e4c049dfc856449aadf3c0aa19e662b7", 3000)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }

  def getDfToJson( spark:SparkSession,sourDf:DataFrame ) ={
    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    })
    //println(s"共获取数据:${sourRdd.count()}")

    //sourDf.unpersist()

    sourRdd
  }


}
