package com.sf.scala.eds.app.jt

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, desc, lit, row_number,asc}
import scala.collection.JavaConversions._
import java.util

/**
 *需求名称：极兔运单明细清洗
 *需求描述：从kafka日志清洗运单明细
 *需求方：01436983 王艳
 *开发: 周勇(01390943)
 *任务创建时间：20240118
 *任务id：983581
 **/

object JtWaybillDetail {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")

    //衡度平台
    //val spark = Spark.getSparkSession(className, null, false, 2)

    //科技平台
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取传入参数日期:今天日期
    val dayvar1 = args(0)
    //获取传入参数日期:昨日日期
    val dayvar2 = args(1)
    logger.error("今天日期：" + dayvar1)
    logger.error("昨日日期：" + dayvar2)

    //从kafka提取所需要的数据：数组格式推送
    val sql=s"""
               |select regexp_replace(
               |regexp_replace(
               |regexp_replace(
               |regexp_replace(
               | regexp_replace(
               | regexp_replace(
               |regexp_replace(log,'\\\\{"data":"\\\\[\\\\{\\\\\\\\"','\\\\{"data":\\\\[\\\\{"'),
               | '\\\\\\\\"\\\\}\\\\]"\\\\}','"\\\\}\\\\]\\\\}'),
               |'\\\\\\\\":\\\\\\\\"','":"'),
               |'\\\\\\\\",\\\\\\\\"','","'),
               |'\\\\\\\\"\\\\},\\\\{\\\\\\\\"','"\\\\},\\\\{"'),
               |'\\\\\\\\":null,','":null,'),
               |'null,\\\\\\\\"','null,"')
               |  log,inc_day,
               |case when log like '[{%' then '1' when log like '{"data":%' then '2' else '' end typeflag from dm_gis.dm_kafka_jt_waybill_di
               |where inc_day>='$dayvar2' and inc_day<='$dayvar1'
               | and (log like '[{%' or log like '{"data":%')
               |""".stripMargin

    logger.error("sql查询：" + sql)


    val kafka_data_array=spark.sql(sql)
        .withColumn("rank",row_number().over(Window.partitionBy("log").orderBy(asc("inc_day")) ))
        .filter($"rank"===1 && ($"typeflag"==="1" || $"typeflag"==="2"))
        .drop("rank")

   // logger.error("sql查询数据量：" + kafka_data_array.count())

    //转成rdd数据
    val x_seq_rdd= SparkUtils.getDfToJson(spark, kafka_data_array, 20)

    val x_seq_result= x_seq_rdd.flatMap(obj => {
      val typeflag=obj.getString("typeflag")
      val tmpList = new util.ArrayList[JSONObject]()
      val inc_day=obj.getString("inc_day")
      val log =obj.getString("log")
      try{
        val obj_arr=if(typeflag=="1"){obj.getJSONArray("log")}else{obj.getJSONObject("log").getJSONArray("data")}
        val s=obj_arr.size()
        for (i <- 0 until(s)) {
          val tmp = new JSONObject()
          tmp.fluentPutAll(obj)
          val obj_i: JSONObject = obj_arr.getJSONObject(i)
          tmp.put("obj_i", obj_i)
          tmp.put("inc_day", inc_day)
          tmpList.add(tmp)
        }
      }
      catch {
        case e: Exception => logger.error("e1:"+e)
         logger.error("obj_arr:"+log)
      }
      Thread.sleep(50)
      tmpList.iterator()
    })

    val x_seq_result2=x_seq_result.map(obj=>{

      val obj_i=obj.getString("obj_i")
      val inc_day=obj.getString("inc_day")
      //以下是各个表的解析字段
      var waybillno=""
      var dispatchstaffcode=""
      var receiversortingcode=""
      var code=""
      var receiverdetailedaddress=""
      var signnetworkname=""
      var signnetworkcode=""
      var receivercityname=""
      var receiverstreet=""
      var receiverareaname=""
      var receivertownship=""
      var receiverprovincename=""
      var terminaldispatchcode=""
      var tailcode=""

      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)
        waybillno=obj_i_js.getString("waybillNo")
        dispatchstaffcode=obj_i_js.getString("dispatchStaffCode")
        receiversortingcode=obj_i_js.getString("receiverSortingCode")
        code=obj_i_js.getString("code")
        receiverdetailedaddress=obj_i_js.getString("receiverDetailedAddress")
        signnetworkname=obj_i_js.getString("signNetworkName")
        signnetworkcode=obj_i_js.getString("signNetworkCode")
        receivercityname=obj_i_js.getString("receiverCityName")
        receiverstreet=obj_i_js.getString("receiverStreet")
        receiverareaname=obj_i_js.getString("receiverAreaName")
        receivertownship=obj_i_js.getString("receiverTownship")
        receiverprovincename=obj_i_js.getString("receiverProvinceName")
        terminaldispatchcode=obj_i_js.getString("terminalDispatchCode")
        tailcode=obj_i_js.getString("tailCode")
      }
      (inc_day,waybillno,dispatchstaffcode,receiversortingcode,code,receiverdetailedaddress,
        signnetworkname,signnetworkcode,receivercityname,receiverstreet,receiverareaname,
        receivertownship,receiverprovincename,terminaldispatchcode,tailcode)
    }).toDF("inc_day","waybillno","dispatchstaffcode","receiversortingcode","code","receiverdetailedaddress",
      "signnetworkname","signnetworkcode","receivercityname","receiverstreet","receiverareaname",
      "receivertownship","receiverprovincename","terminaldispatchcode","tailcode")
      //运单是否去重
//      .withColumn("rank",row_number().over(Window.partitionBy("waybillno").orderBy(desc("inc_day")) ))
//      .filter($"rank"===1)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_jt_waybill_di limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    overwriteToHiveDynamics(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_jt_waybill_di")

    logger.error(">>>>任务已完成！")

    spark.close()

  }

}
