package com.sf.scala.eds.app.jt

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, lit}

import java.net.URLEncoder

/**
 *需求名称：极兔终端里程测算
 *需求描述：丰图将为极兔进行终端里程跑数，计算网点到门店的距离
 *需求方：01408947 刘雨婷
 *开发: 周勇(01390943)
 *任务创建时间：20240111
 *任务id：衡度bdp：1148
 **/

object Jtaddresscompare {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val flag=args(0)
    logger.error("初始化spark")
    //衡度平台
    val spark = Spark.getSparkSession(className, null, false, 2)

    val input_data=spark.sql(
      s"""
        |select *,case when cartype like '%面包%' then 1 when cartype like '%轻卡%' then 6 when cartype like '%三轮%' then 1  else '' end vehicle
        | from dm_gis.dm_jt_addresscompare_di
        |""".stripMargin)

    import spark.implicits._

    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = 1
    //转化rdd处理
    val resdata: RDD[JSONObject] = SparkUtils.getDfToJson(spark, input_data, 1)

    val resdata2=Multi_address_query_url(spark,resdata, calPartitions,"f7f1b0eda9841fd5ba7ecd91037b8046")
      .map(obj=>{
        val dailiqu = obj.getString("dailiqu")
        val province = obj.getString("province")
        val city = obj.getString("city")
        val county = obj.getString("county")
        val dept = obj.getString("dept")
        val dept_code = obj.getString("dept_code")
        val dept_address = obj.getString("dept_address")
        val dept_x = obj.getString("dept_x")
        val dept_y = obj.getString("dept_y")
        val cartype = obj.getString("cartype")
        val md_detail = obj.getString("md_detail")
        val mdtype = obj.getString("mdtype")
        val res_time = obj.getString("res_time")
        val res_dist = obj.getString("res_dist")
        val res_croods = obj.getString("res_croods")
        val err_msg1 = obj.getString("err_msg1")
        val err_msg2 = obj.getString("err_msg2")
        val ret = obj.getString("ret")
        (dailiqu,province,city,county,dept,dept_code,dept_address,dept_x,dept_y,cartype,md_detail,mdtype,res_time,res_dist,res_croods,err_msg1,err_msg2,ret)
      }).toDF("dailiqu","province","city","county","dept","dept_code","dept_address","dept_x","dept_y","cartype","md_detail","mdtype","res_time","res_dist","res_croods","err_msg1","err_msg2","ret")

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_jt_addresscompareall_di limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, resdata2.withColumn("inc_flag",lit(flag)).select(table_cols: _*), Seq("inc_flag"), "dm_gis.dm_jt_addresscompareall_di")

  }

  //定义获取url数据
  def address_query_url(ak:String,obj:JSONObject): JSONObject = {
    try {

      Thread.sleep(50)
      val origin = URLEncoder.encode(obj.getString("dept_address"), "UTF-8")
      val destination =URLEncoder.encode(obj.getString("md_detail"), "UTF-8")
      val Vehicle =obj.getString("vehicle")
      val ak="f7f1b0eda9841fd5ba7ecd91037b8046"
      val x1 =obj.getString("dept_x")
      val y1 =obj.getString("dept_y")

      //获取接口数据
      //val url = s"http://gis-apis.int.sfcloud.local:1080/rp/v2/api?&opt=gd2&Vehicle=$Vehicle&ak=$ak&origin=$origin&destination=$destination"
      val url = s"http://gis-apis.int.sfcloud.local:1080/rp/v2/api?&opt=gd2&Vehicle=$Vehicle&ak=$ak&x1=$x1&y1=$y1&destination=$destination"
      val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 3)
      val ret: JSONObject = JSON.parseObject(retStr)

      obj.put("ret",ret)
      //logger.error("ret:"+ret)

      val status=ret.getString("status")
      var res_time=""
      var res_dist=""
      var res_croods=""

      if(status==0 || status=="0"){
        try{
          res_time=ret.getJSONObject("result").getString("time")
          res_dist=ret.getJSONObject("result").getString("dist")
          res_croods=ret.getJSONObject("result").getJSONArray("coords").toString
        }
        catch{
          case e1: Exception => logger.error("e1:"+e1)
            obj.put("err_msg1",e1)
        }
      }

      obj.put("res_time",res_time)
      obj.put("res_dist",res_dist)
      obj.put("res_croods",res_croods)
    }
    catch{
      case e2: Exception => logger.error("e2:"+e2)
        obj.put("err_msg2",e2)
    }
    obj
  }

  //并发调取接口并发请求，由于每个ak单分钟限制3000
  def Multi_address_query_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int,ak:String) = {
    //调用开始上报
        val httpUrl = s"http://gis-apis.int.sfcloud.local:1080/rp/v2/api?"
        val httpAk="f7f1b0eda9841fd5ba7ecd91037b8046"
        val dataCnt=DataRdd.count()
        val invokeThreadCnt=DataRdd.getNumPartitions
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "1148", "极兔终端里程测算",
          "丰图将为极兔进行终端里程跑数，计算网点到门店的距离",
          httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, address_query_url, 1, ak, 100)

    //调用完成上报
        BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

        logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }

}
