package com.sf.scala.eds.app.jt

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, collect_list, concat, concat_ws, desc, lit, row_number, trim, udf, when}
import org.apache.spark.storage.StorageLevel
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

/**
 *需求名称：极兔虚假管控
 *需求描述：根据极兔运单地址和采集地址数据判断数据是否造假
 *需求方：01408947 刘雨婷
 *开发: 周勇(01390943)
 *任务创建时间：20240117
 *任务id：966843
 **/

object JtFalseControlOnline {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")

    //衡度平台
    //val spark = Spark.getSparkSession(className, null, false, 2)

    //科技平台
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取传入参数日期:轨迹开始日期
    val dayvar1 = args(0)
    //获取传入参数日期:轨迹结束日期
    val dayvar2 = args(1)
    //获取传入参数日期:结果存表分区日期
    val dayvar3 = args(2)
    //获取传入参数日期:跑数时的起始分区flag
    val minflag = args(3).toInt
    //获取传入参数日期:跑数时的结束分区flag
    val maxflag = args(4).toInt
    logger.error("轨迹开始日期："+dayvar1)
    logger.error("轨迹结束日期："+dayvar2)
    logger.error("结果存表分区日期："+dayvar3)
    logger.error("跑数时的起始分区flag："+minflag)
    logger.error("跑数时的结束分区flag："+maxflag)
    //按批次跑数据
    logger.error("按批次跑数据：")
    for(i<-minflag to maxflag){
      println("当前执行inc_flag="+i)
      //执行计算主体
      start_fun(spark,i,dayvar1,dayvar2)
    }
    logger.error("最终结果落表：")
    //最终结果落表
    val result_data=spark.sql(
      """
        |select * from dm_gis.dm_jt_falsecontrol_flag2_di
        |""".stripMargin)
      .withColumn("inc_day",lit(dayvar3))

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_jt_falsecontrol_di limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, result_data.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_jt_falsecontrol_di")
    logger.error("执行结束！")
    spark.close()
  }

  def start_fun(spark:SparkSession,flag:Int,dayvar1:String,dayvar2:String): Unit ={
    import spark.implicits._
    //获取运单明细
    val input_data = spark.sql(
      s"""
         |select * from dm_gis.dm_jt_falsecontrol_flag_di
         |where inc_flag ='$flag'
         |""".stripMargin)
      .withColumn("ptby",lit("1"))
      .withColumn("rank",row_number().over(Window.partitionBy("ptby").orderBy("ptby") ))
      .withColumn("address2",concat_ws("",$"city",$"county",$"address"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val input_data2=input_data.select("rank","emp_code","address2","delivered_time")
      .withColumn("bftime5",when($"delivered_time".isNotNull && trim($"delivered_time")=!="",getminisBeforeOrAfter5($"delivered_time",lit(-5))).otherwise($"delivered_time"))
      .withColumn("afttime5",when($"delivered_time".isNotNull && trim($"delivered_time")=!="",getminisBeforeOrAfter5($"delivered_time",lit(5))).otherwise($"delivered_time"))

    //获取小哥坐标
    val track_data = spark.sql(
      s"""
         |select un as emp_code,zx,zy,from_unixtime(cast(tm as bigint),'yyyy-MM-dd HH:mm:ss') trace_time from dm_gis.dm_jt_tracks_di
         |where inc_day >='$dayvar1' and  inc_day <='$dayvar2'
         |""".stripMargin)

    //合并数据
    val result_data =input_data2.join(track_data,Seq("emp_code"),"left")
      .filter($"trace_time">=$"bftime5" && $"trace_time"<=$"afttime5")
      .withColumn("xy",concat_ws(",",$"zx",$"zy"))
      .groupBy("rank","address2")
      .agg(concat_ws(";",collect_list($"xy")) as "tracks_record")
      .persist(StorageLevel.MEMORY_AND_DISK)

    //数据样例查看
    logger.error("result_data数据样例查看:")
    result_data.show(10,false)

    //转化rdd处理
    val res_rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, result_data, 10)

    //取派件地址对应的aoiid
    val adress_aoiid_rdd=Multi_adress_aoiid_url(spark,res_rdd,10)

    //数据样例查看
    //logger.error("adress_aoiid_rdd数据样例查看:")
    // adress_aoiid_rdd.take(3).foreach(println(_))

    //获取坐标轨迹判断
    val result_data2=Multi_get_aoiid_url(spark,adress_aoiid_rdd,10)
      .map(obj=>{
        val rank = obj.getString("rank")
        val tracks_record = obj.getString("tracks_record")
        val aoi_id = obj.getString("aoi_id")
        val is_true = obj.getString("is_true")
        val xy_coords = obj.getString("xy_coords")
        (rank,tracks_record,aoi_id,is_true,xy_coords)
      }
      ).toDF("rank","tracks_record","aoi_id","is_true","xy_coords")

    //数据合并
    val result_data3=input_data.join(result_data2,Seq("rank"),"left")
      .withColumn("inc_flag",lit(flag))
      .withColumn("is_true",when($"tracks_record".isNull || trim($"tracks_record")===""
        || $"aoi_id".isNull || trim($"aoi_id")===""  ,"").otherwise($"is_true"))

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_jt_falsecontrol_flag2_di limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, result_data3.select(table_cols: _*), Seq("inc_flag"), "dm_gis.dm_jt_falsecontrol_flag2_di")

  }


  //获取地址对应的aoiid
  def adress_aoiid_url(ak:String,obj:JSONObject): JSONObject = {
    try {

      Thread.sleep(50)
      val ak ="165539471e564b2fa5c257a55ae462ca"
      val address2 = URLEncoder.encode(obj.getString("address2"), "UTF-8")
      //获取接口数据
      val url = s"http://gis-int.int.sfdc.com.cn:1080/atdispatch/api?address=$address2&city=021&ak=$ak&opt=zh&showserver=true"
      val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 3)
      val ret: JSONObject = JSON.parseObject(retStr)

      val status=ret.getString("status")
      var aoi_id=""

      if(status==0 || status=="0"){
        try{
          val tcs=ret.getJSONObject("result").getJSONArray("tcs")
          val k=tcs.size()
          if(k>0){
            aoi_id=tcs.getJSONObject(0).getString("aoiid")
            obj.put("aoi_id:",aoi_id)
            logger.error("获取aoi_id:"+aoi_id)
          }
        }
        catch{
          case e1: Exception => logger.error("e1:"+e1)
            obj.put("err_msg1",e1)
        }
      }

      obj.put("aoi_id",aoi_id)
    }
    catch{
      case e2: Exception => logger.error("e2:"+e2)
        obj.put("err_msg2",e2)
    }
    obj
  }

  //并发调取接口并发请求
  def Multi_adress_aoiid_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl = s"http://gis-int.int.sfdc.com.cn:1080/atdispatch/api"
    val httpAk="165539471e564b2fa5c257a55ae462ca"
    val dataCnt=DataRdd.count()

    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "966843", "极兔虚假管控",
      "根据极兔运单地址和采集地址数据判断数据是否造假",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, adress_aoiid_url, 10, httpAk, 1500)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }

  // 推n分钟,负数是往前，正数是往后
  def getminisBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.MINUTE, num)
    dateFormat.format(cal.getTime)
  }

  val getminisBeforeOrAfter5=udf(getminisBeforeOrAfter _)

  //定义获取url数据
  def get_aoiid_url(ak:String,obj:JSONObject): JSONObject = {
    try {

      val xy=obj.getString("tracks_record")
      val aoi_id=obj.getString("aoi_id")
      //将轨迹拆分
      val xy_ayy=xy.split(";")
      //计算轨迹量大小
      val s=xy_ayy.size
      var res_aoiid=""
      var is_true="否"
      var xy_coords=""
      if(s>0){
        //遍历轨迹点判断
        var runflag=true
        for(i<-0 until s if runflag){
          Thread.sleep(25)
          val xy_i=xy_ayy(i)
          val x=xy_i.split(",")(0)
          val y=xy_i.split(",")(1)

          //获取接口数据
          val url = s"http://sds-core-datarun.sf-express.com/datarun/aoi/getAoiIdByPoint?x=$x&y=$y&radius=0"
          val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 3)
          val ret: JSONObject = JSON.parseObject(retStr)

          //obj.put("ret",ret)
          //logger.error("ret:"+ret)

          val status=ret.getString("code")

          if(status==200 || status=="200"){
            try{
              res_aoiid=ret.getJSONObject("data").getString("id")
              //判断是否符合
              if(aoi_id==res_aoiid & aoi_id !=null & aoi_id!=""){
                is_true="是"
                xy_coords=xy_i
                runflag=false
                logger.error("已获取到合适的坐标:"+xy_coords)
              }
            }
            catch{
              case e1: Exception => logger.error("e1:"+e1)
                obj.put("err_msg1",e1)
            }
          }
        }
      }

      obj.put("is_true",is_true)
      obj.put("xy_coords",xy_coords)
    }
    catch{
      case e2: Exception => logger.error("e2:"+e2)
        obj.put("err_msg2",e2)
    }
    obj
  }

  //并发调取接口并发请求
  def Multi_get_aoiid_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl = s"http://sds-core-datarun.sf-express.com/datarun/aoi/getAoiIdByPoint"
    val httpAk=""
    val dataCnt=DataRdd.count()

    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "966843", "极兔虚假管控",
      "根据极兔运单地址和采集地址数据判断数据是否造假",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, get_aoiid_url, 10, httpAk, 3000)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }


















}
