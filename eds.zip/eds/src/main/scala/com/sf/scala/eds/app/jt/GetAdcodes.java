package com.sf.scala.eds.app.jt;

import com.sf.lbs.seg.normal.service.impl.LbsNormalServiceImpl;
import com.sf.lbs.seg.normal.util.Response;
import com.sf.lbs.seg.normal.vo.Normal;

import java.util.List;

public class GetAdcodes {
    private static  final ThreadLocal<LbsNormalServiceImpl> treadlocalSingleton
            =new ThreadLocal<LbsNormalServiceImpl>(){
        @Override
        protected LbsNormalServiceImpl initialValue(){
            return new  LbsNormalServiceImpl();
        }
    };
    private GetAdcodes(){}

    public  static String getInstance(String address){
        Response<Normal> normalResponse = treadlocalSingleton.get().normal(address);
        Normal normal = normalResponse.getResult();
        List<String> adcode = normal.getAdcode();
        return adcode.get(0);
    }
}
