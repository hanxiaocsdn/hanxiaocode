package com.sf.scala.eds.app.jt

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkUtils
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{asc, col, row_number}

import scala.collection.JavaConversions._
import java.util

/**
 *需求名称：极兔轨迹明细清洗
 *需求描述：从kafka日志清洗轨迹明细
 *需求方：01430258 丁汀
 *开发: 周勇(01390943)
 *任务创建时间：20240122
 *任务id：983618
 **/
object JtTracksDetail {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")

    //衡度平台
    //val spark = Spark.getSparkSession(className, null, false, 2)

    //科技平台
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取传入参数日期:今天日期
    val dayvar1 = args(0)
    //获取传入参数日期:昨日日期
    val dayvar2 = args(1)
    logger.error("今天日期：" + dayvar1)
    logger.error("昨日日期：" + dayvar2)

    //从kafka提取所需要的数据：数组格式推送
    val kafka_data_array=spark.sql(
      s"""
         |select log,inc_day from dm_gis.dm_kafka_jt_tracks_di
         |where inc_day>='$dayvar2' and inc_day<='$dayvar1'
         | and log like '%[{%'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("log").orderBy(asc("inc_day")) ))
      .filter($"rank"===1)
      .drop("rank")

    //转成rdd数据
    val x_seq_rdd= SparkUtils.getDfToJson(spark, kafka_data_array, 20)

    //logger.error(">>>>筛选出数据量："+x_seq_rdd.count())

    val x_seq_result= x_seq_rdd.flatMap(obj => {

      val obj_arr=obj.getJSONArray("log")
      val inc_day=obj.getString("inc_day")
      val tmpList = new util.ArrayList[JSONObject]()
      val s=obj_arr.size()

      for (i <- 0 until(s)) {
        val tmp = new JSONObject()
        tmp.fluentPutAll(obj)
        val obj_i: JSONObject = obj_arr.getJSONObject(i)
        tmp.put("obj_i", obj_i)
        tmp.put("inc_day", inc_day)
        tmpList.add(tmp)
      }
      tmpList.iterator()
    })

    val x_seq_result2=x_seq_result.map(obj=>{

      val obj_i=obj.getString("obj_i")
      val inc_day=obj.getString("inc_day")
      //以下是各个表的解析字段
      var v=""
      var ak=""
      var xh=""
      var pc=""
      var cr=""
      var sl=""
      var un=""
      var id=""
      var state=""
      var dx=""
      var dy=""
      var ac=""
      var app=""
      var ad=""
      var sp=""
      var bk=""
      var sc=""
      var bt=""
      var bn=""
      var tm=""
      var be=""
      var tp=""
      var zx=""
      var zy=""
      if(obj_i !=null){
        val obj_i_js=JSON.parseObject(obj_i)
        v=obj_i_js.getString("v")
        ak=obj_i_js.getString("ak")
        xh=obj_i_js.getString("xh")
        pc=obj_i_js.getString("pc")
        cr=obj_i_js.getString("cr")
        sl=obj_i_js.getString("sl")
        un=obj_i_js.getString("un")
        id=obj_i_js.getString("id")
        state=obj_i_js.getString("state")
        dx=obj_i_js.getString("dx")
        dy=obj_i_js.getString("dy")
        ac=obj_i_js.getString("ac")
        app=obj_i_js.getString("app")
        ad=obj_i_js.getString("ad")
        sp=obj_i_js.getString("sp")
        bk=obj_i_js.getString("bk")
        sc=obj_i_js.getString("sc")
        bt=obj_i_js.getString("bt")
        bn=obj_i_js.getString("bn")
        tm=obj_i_js.getString("tm")
        be=obj_i_js.getString("be")
        tp=obj_i_js.getString("tp")
        zx=obj_i_js.getString("zx")
        zy=obj_i_js.getString("zy")

      }
      restb(inc_day, v, ak, xh, pc, cr, sl, un, id, state, dx, dy, ac, app,
        ad, sp, bk, sc, bt, bn, tm, be, tp, zx, zy)
    }).toDF()

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_jt_tracks_di limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    overwriteToHiveDynamics(spark,x_seq_result2.select(table_cols: _*), Seq("inc_day"), "dm_gis.dm_jt_tracks_di")

    logger.error(">>>>任务已完成！")

    spark.close()

  }

  case class restb(
                    inc_day	:String,
                    v	:String	,
                    ak	:String	,
                    xh	:String	,
                    pc	:String	,
                    cr	:String	,
                    sl	:String	,
                    un	:String	,
                    id	:String	,
                    state	:String	,
                    dx	:String	,
                    dy	:String	,
                    ac	:String	,
                    app	:String	,
                    ad	:String	,
                    sp	:String	,
                    bk	:String	,
                    sc	:String	,
                    bt	:String	,
                    bn	:String	,
                    tm	:String	,
                    be	:String	,
                    tp	:String	,
                    zx	:String	,
                    zy	:String
  )

}
