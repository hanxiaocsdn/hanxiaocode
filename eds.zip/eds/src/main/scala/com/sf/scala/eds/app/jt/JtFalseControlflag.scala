package com.sf.scala.eds.app.jt

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat, lit, row_number, when}
import org.apache.spark.storage.StorageLevel

/**
 *需求名称：极兔虚假管控
 *需求描述：将数据拆分为多份，方便后面计算，容错
 *需求方：01408947 刘雨婷
 *开发: 周勇(01390943)
 *任务创建时间：20240117
 *任务id：966843
 * **/
object JtFalseControlflag {


  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")

    //衡度平台
    //val spark = Spark.getSparkSession(className, null, false, 2)

    //科技平台
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取传入参数日期:今天日期
    val dayvar1 = args(0)
    val incint= args(1).toInt
    val incint2=incint*2
    val incint3=incint*3
    val incint4=incint*4
    val incint5=incint*5
    val incint6=incint*6

    //获取运单明细
    val input_data = spark.sql(
      s"""
         |select * from dm_gis.dm_csv_jt_waybillimport_di
         |where waybill_no !='运单号'
         |""".stripMargin)
      .withColumn("ptby",lit("1"))
      .withColumn("rank",row_number().over(Window.partitionBy("ptby").orderBy("ptby") ))
      .withColumn("inc_flag",when($"rank"<=incint,"1").when($"rank"<=incint2,"2").when($"rank"<=incint3,"3")
        .when($"rank"<=incint4,"4").when($"rank"<=incint5,"5").when($"rank"<=incint6,"6").otherwise("7"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_jt_falsecontrol_flag_di limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, input_data.select(table_cols: _*), Seq("inc_flag"), "dm_gis.dm_jt_falsecontrol_flag_di")

   spark.close()

  }

}
