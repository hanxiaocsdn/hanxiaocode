package com.sf.scala.eds.app.jt

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{asc, col, count, countDistinct, desc, lit, max, round, row_number, sum, trim, when}
import com.sf.gis.scala.base.spark.Spark


/**
 *需求名称：网点历史签收数据
 *需求描述：根据aoi统计签收二段ZC	签收三段码TC的出现规律，交叉分析数据的合理性
 *需求方：01434056唐巧亭
 *开发: 周勇(01390943)
 *任务创建时间：20231212
 *任务id：1095
 **/

object JtSigningHistoryDept {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    //科技
    //    val SparkInfo = SparkUtil.getSpark(className)
    //    val spark = SparkInfo.getSession
    //衡度
    val spark = Spark.getSparkSession(className, null, false, 2)
    import spark.implicits._
    //获取传入参数日期:昨日日期
    val dayvar1 = args(0)

    val signing_data=spark.sql(
      s"""
         |select * from dm_gis.jt_signing_history_dtl
         |where inc_day='$dayvar1' and province like '%上海%'
         |""".stripMargin)

    /*数据中AOI与二三段码可以一一对应（每个aoi只对应唯一一个tc和唯一一个zc）
    签收二段码:ZC	签收三段码:TC
    */

    //aoi、二段码、三段码去重
    val aoi_two_three=signing_data.select("aoiid","sign_two_codes","sign_three_codes","record_time")
      .withColumn("rank",row_number().over(Window.partitionBy("aoiid","sign_two_codes","sign_three_codes").orderBy(desc("record_time")) ))
      .filter($"rank"===1)
      .select("aoiid","sign_two_codes","sign_three_codes")

    //    logger.error("存储临时表：关联明细表")
    //    spark.sql("drop table if exists tmp_dm_gis.tempzy_aoi_two_three")
    //    aoi_two_three.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tempzy_aoi_two_three")

    //汇总所有的aoi去重统计
    val aoi_all=signing_data.select("aoiid","sign_two_codes","sign_three_codes","adrress_freq")
      .groupBy("aoiid")
      .agg(countDistinct($"sign_two_codes",$"sign_three_codes") as "all_ct",
        countDistinct($"sign_two_codes") as "two_codes_ct",
        countDistinct($"sign_three_codes") as "three_codes_ct"
      )
    //
    //    logger.error("存储临时表：关联明细表")
    //    spark.sql("drop table if exists tmp_dm_gis.tempzy_aoi_all")
    //    aoi_all.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tempzy_aoi_all")

    //数据标签
    val res1_all=signing_data.select("waybill_no","aoiid","sign_two_codes","sign_three_codes","record_time","adrress_freq")
      .join(aoi_all,Seq("aoiid"),"left")
      .withColumn("flag",when($"two_codes_ct">1,"多ZC").
        when($"three_codes_ct">1,"多tC").otherwise("一一对应"))
      .select("waybill_no","aoiid","sign_two_codes","sign_three_codes","adrress_freq","flag")
      .withColumn("inc_day",lit(dayvar1))

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.jt_signing_history_mid1 limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, res1_all.select(table_cols: _*), Seq("inc_day"), "dm_gis.jt_signing_history_mid1")

    val res1_all_flag=res1_all.groupBy("flag")
      .agg(count($"waybill_no") as "all_ct")

    logger.error("res1_all_flag统计情况：")

    res1_all_flag.show(false)

    //汇总所有的aoi、二段码去重统计
    val aoi_two=signing_data.select("aoiid","sign_two_codes","sign_three_codes","adrress_freq","record_time")
      .groupBy("aoiid","sign_two_codes")
      .agg(countDistinct($"sign_three_codes") as "two_ct",
        count($"aoiid") as "two_allct",
        sum($"adrress_freq") as "two_frq",
        max($"record_time") as "max_tm"
      )

    //    logger.error("存储临时表：关联明细表")
    //    spark.sql("drop table if exists tmp_dm_gis.tempzy_aoi_two")
    //    aoi_two.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tempzy_aoi_two")


    val aoi_two_result=aoi_two.withColumn("rank",row_number().over(Window.partitionBy("aoiid").orderBy(desc("two_frq")) ))

    aoi_two_result.createOrReplaceTempView("aoi_two_result_tb")

    //计算结果4保存
    spark.sql(
      s"""
         |insert overwrite table dm_gis.jt_signing_history_mid3
         |partition( inc_day='$dayvar1')
         |select t1.aoiid,
         |t1.sign_two_codes as sign_two_codes1,t1.two_frq as freq1,t1.max_tm as max_tm1,
         |t2.sign_two_codes as sign_two_codes2,t2.two_frq as freq2,t2.max_tm as max_tm2,
         |t3.sign_two_codes as sign_two_codes3,t3.two_frq as freq3,t3.max_tm as max_tm3,
         |t4.sign_two_codes as sign_two_codes4,t4.two_frq as freq4,t4.max_tm as max_tm4
         |from
         |(
         |select * from aoi_two_result_tb where rank=1
         |) t1
         |left join
         |(
         |select * from aoi_two_result_tb where rank=2
         |) t2 on t1.aoiid=t2.aoiid
         |left join
         |(
         |select * from aoi_two_result_tb where rank=3
         |) t3 on t1.aoiid=t3.aoiid
         |left join
         |(
         |select * from aoi_two_result_tb where rank=4
         |) t4 on t1.aoiid=t4.aoiid
         |""".stripMargin)



    //汇总所有的aoi、三段码去重统计
    val aoi_three=signing_data.select("aoiid","sign_two_codes","sign_three_codes","adrress_freq")
      .groupBy("aoiid","sign_three_codes")
      .agg(countDistinct($"sign_two_codes") as "three_ct",
        count($"aoiid") as "three_allct",
        sum($"adrress_freq") as "three_frq"
      )

    //    logger.error("存储临时表：关联明细表")
    //    spark.sql("drop table if exists tmp_dm_gis.tempzy_aoi_three")
    //    aoi_three.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tempzy_aoi_three")

    //一一对应筛选
    val r1=res1_all.filter($"flag"==="一一对应")
      .withColumn("rank",row_number().over(Window.partitionBy("aoiid","sign_two_codes","sign_three_codes").orderBy(desc("aoiid")) ))
      .filter($"rank"===1)
      .withColumn("flag1",lit("一一对应"))
      .select("aoiid","sign_two_codes","sign_three_codes","flag1")

    logger.error("数据量1，"+r1.count())

    //    logger.error("存储临时表：关联明细表")
    //    spark.sql("drop table if exists tmp_dm_gis.tempzy_r1")
    //    aoi_three.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tempzy_r1")

    //最高的
    val aoi_two_tmp=aoi_two.withColumn("rank",row_number().over(Window.partitionBy("aoiid").orderBy(desc("two_frq")) ))
      .filter($"rank"===1)
      .select("aoiid","sign_two_codes")

    val aoi_three_tmp=aoi_three
      .withColumn("sign_three_codes",when($"sign_three_codes"==="999" || $"sign_three_codes"==="N" || $"sign_three_codes"==="nan","").otherwise($"sign_three_codes"))
      .withColumn("rn",when($"sign_three_codes".isNull || trim($"sign_three_codes")==="",2).otherwise(1))
      .withColumn("rank",row_number().over(Window.partitionBy("aoiid").orderBy(asc("rn"),desc("three_frq")) ))
      .filter($"rank"===1)
      .select("aoiid","sign_three_codes")

    //    logger.error("存储临时表：关联明细表")
    //    spark.sql("drop table if exists tmp_dm_gis.tempzy_aoi_three_tmp")
    //    aoi_three_tmp.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tempzy_aoi_three_tmp")

    //筛选
    val data2=res1_all.filter($"flag" =!="一一对应")
      .select("aoiid")
      .withColumn("rank",row_number().over(Window.partitionBy("aoiid").orderBy(desc("aoiid")) ))
      .filter($"rank"===1)
      .join(aoi_two_tmp,Seq("aoiid"),"left")
      .join(aoi_three_tmp,Seq("aoiid"),"left")
      .withColumn("flag1",lit("其他"))
      .select("aoiid","sign_two_codes","sign_three_codes","flag1")

    logger.error("数据量2，"+data2.count())

    val data3=r1.union(data2)
      .withColumn("inc_day",lit(dayvar1))
      .withColumn("sign_three_codes",when($"sign_three_codes"==="999" || $"sign_three_codes"==="N" || $"sign_three_codes"==="nan","").otherwise($"sign_three_codes"))

    //选择所需列
    val table_cols2 = spark.sql("""select * from dm_gis.jt_signing_history_mid2 limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, data3.select(table_cols2: _*), Seq("inc_day"), "dm_gis.jt_signing_history_mid2")


  }

}
