drop table if  exists  `dm_gis.dm_ddjy_cluepoint_rlst_di_month_test`;
CREATE TABLE if not exists `dm_gis.dm_ddjy_cluepoint_rlst_di_month_test` (
    `clue_id` string COMMENT '集散地代码',
    `task_batch` string COMMENT '任务批次',
    `clue_name` string COMMENT '集散地名称',
    `clue_addr` string COMMENT '集散地地址',
    `dept_type_name` string COMMENT '网点类型名称',
    `dept_transfer_flag` string COMMENT '是否中转场',
    `clue_src` string COMMENT '线索来源',
    `adcode` string COMMENT '行政区代码',
    `province` string COMMENT '省份名称',
    `city` string COMMENT '城市名称',
    `district` string COMMENT '所属区县',
    `longitude` string COMMENT '经度',
    `latitude` string COMMENT '纬度',
    `country_name` string COMMENT '国家或地区名称',
    `area_name` string COMMENT '区部名称',
    `delete_flg` string COMMENT '是否已删除，1:是',
    `task_count` string COMMENT '任务数',
    `carrier_count` string COMMENT '车队数量',
    `vehicle_count` string COMMENT '车队车牌数量',
    `task_day_count` string COMMENT '执行天数',
    `plan_depart_tm_day_max` string COMMENT '最大执行日期',
    `plan_depart_tm_day_min` string COMMENT '最小执行日期',
    `dis_sum` string COMMENT '总里程',
    `task_count_per_day` string COMMENT '平均每天的任务数',
    `dis_sum_per_day` string COMMENT '平均每天的里程',
    `oil_sum` string COMMENT '总油耗',
    `oil_sum_per_day` string COMMENT '平均每天的油耗',
    `vehicle_load_count_distribution` string COMMENT '中转场不同车型占比',
    `gas_count` string COMMENT '5KM内油站数量',
    `national_gas_count` string COMMENT '国营油站数',
    `private_gas_count` string COMMENT '民营油站数',
    `active_status` string COMMENT '激活状态，0-未激活，1-已激活',
    `circle_id` string COMMENT '集散圈ID',
    `update_time` string COMMENT '更新时间',
    `clue_type` string COMMENT '',
    `center_x` string COMMENT '集散圈中心点X',
    `center_y` string COMMENT '集散圈中心点Y',
    `biz_day` String  comment  '业务日期'
  ) COMMENT '线索集散地数据月度表'
PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
stored as parquet tblproperties('parquet.compression' = 'snappy');


alter table dm_gis.dm_ddjy_cluepoint_rlst_di_month  add columns(center_x string comment '集散圈中心点X',
center_y string comment '集散圈中心点Y',
biz_day string comment '业务日期') CASCADE


drop table if  exists  `dm_gis.dwd_ddjy_clue_rel_gas_station_di_month_test`;
CREATE TABLE if not exists `dm_gis.dwd_ddjy_clue_rel_gas_station_di_month_test` (
    `gas_id` string COMMENT '加油站pid',
    `clue_id` string COMMENT '集散地ID',
    `task_batch` string COMMENT '任务批次',
    `name_chn` string COMMENT '加油站名称',
    `adcode` string COMMENT '行政区代码',
    `provinct_name` string COMMENT '集散地省份',
    `city` string COMMENT '集散地城市',
    `belong_county` string COMMENT '集散地区县',
    `clue_name` string COMMENT '集散地名称',
    `beeline_dist` string COMMENT '直线距离',
    `d_dist` string COMMENT '导航距离',
    `dist_rank` string COMMENT '距离等级',
    `active_status` string COMMENT '集散地激活状态，0-未激活，1-已激活',
    `cooperate_status` string COMMENT '油站合作状态（0-未签约；1-待签约 ；2-已签约；3-已上线）',
    `clue_src` string COMMENT '线索来源',
    `gas_type` string COMMENT '加油站类型',
    `update_time` string COMMENT '更新时间',
    `circle_id` string COMMENT '集散圈id',
    `center_x` string COMMENT '集散圈坐标x',
    `center_y` string COMMENT '集散圈坐标y',
    `biz_day` String  comment  '业务日期'
  ) COMMENT '集散地关联油站月度表'
PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
stored as parquet tblproperties('parquet.compression' = 'snappy');





drop table if  exists  `dm_gis.dm_ddjy_clue_rel_carrier_di_month_test`;
CREATE TABLE if not exists  `dm_gis.dm_ddjy_clue_rel_carrier_di_month_test` (
    `clue_id` string COMMENT '集散地ID',
    `carrier_id` string COMMENT '车队ID',
    `task_batch` string COMMENT '任务批次',
    `clue_name` string COMMENT '集散地名称',
    `carrier_name` string COMMENT '车队名称',
    `province` string COMMENT '集散地省份',
    `city` string COMMENT '集散地城市',
    `district` string COMMENT '集散地区县',
    `adcode` string COMMENT '集散地行政区代码',
    `task_count` string COMMENT '车队任务数',
    `vehicle_count` string COMMENT '车队车牌数',
    `task_day_count` string COMMENT '执行天数',
    `plan_depart_tm_day_max` string COMMENT '最大执行日期',
    `plan_depart_tm_day_min` string COMMENT '最小执行日期',
    `dis_sum` string COMMENT '总里程',
    `task_count_per_day` string COMMENT '平均每天任务数',
    `dis_sum_per_day` string COMMENT '平均每天里程',
    `oil_sum` string COMMENT '总油耗',
    `oil_sum_per_day` string COMMENT '平均每天油耗',
    `vehicle_load_count_distribution` string COMMENT '不同车型占比',
    `active_status` string COMMENT '集散地激活状态，0-未激活，1-已激活',
    `clue_src` string COMMENT '线索来源',
    `update_time` string COMMENT '更新时间',
    `circle_id` string COMMENT '集散圈id',
    `center_x` string COMMENT '集散圈坐标x',
    `center_y` string COMMENT '集散圈坐标y',
    `biz_day` String  comment  '业务日期'
  ) COMMENT '集散地关联车队表'
PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
stored as parquet tblproperties('parquet.compression' = 'snappy');



drop table if  exists  `dm_gis.dm_ddjy_clue_rel_car_di_month_test`;
CREATE TABLE if not exists  `dm_gis.dm_ddjy_clue_rel_car_di_month_test` (
    `vehicle` string COMMENT '车牌',
    `clue_id` string COMMENT '集散地ID',
    `task_batch` string COMMENT '任务批次',
    `clue_name` string COMMENT '集散地名称',
    `province` string COMMENT '集散地省份',
    `city` string COMMENT '集散地城市',
    `district` string COMMENT '集散地区县',
    `adcode` string COMMENT '集散地行政区代码',
    `task_count` string COMMENT '任务数',
    `task_day_count` string COMMENT '执行天数',
    `plan_depart_tm_day_max` string COMMENT '最大执行日期',
    `plan_depart_tm_day_min` string COMMENT '最小执行日期',
    `dis_sum` string COMMENT '总里程',
    `task_count_per_day` string COMMENT '平均每天的任务数',
    `dis_sum_per_day` string COMMENT '平均每天的里程',
    `oil_sum` string COMMENT '总油耗',
    `oil_sum_per_day` string COMMENT '平均每天的油耗',
    `mload` string COMMENT '核定载重',
    `clue_src` string COMMENT '线索来源',
    `carrier_id` string COMMENT '车队ID',
    `carrier_name` string COMMENT '车队名称',
    `update_time` string COMMENT '更新时间',
    `circle_id` string COMMENT '集散圈id',
    `center_x` string COMMENT '集散圈坐标x',
    `center_y` string COMMENT '集散圈坐标y',
    `active_status` string COMMENT '激活状态，0-未激活，1-已激活',
    `biz_day` String  comment  '业务日期'
  ) COMMENT '集散地关联车辆月度表'
PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
stored as parquet tblproperties('parquet.compression' = 'snappy');


drop table if  exists  `dm_gis.dwd_ddjy_clue_circle_rslt_di_month_test`;
CREATE TABLE if not exists  `dm_gis.dwd_ddjy_clue_circle_rslt_di_month_test`(
    `circle_id` string,
    `task_batch` string,
    `adcode` string,
    `province` string,
    `city` string,
    `district` string,
    `x` string,
    `y` string,
    `task_count` string,
    `carrier_count` string,
    `vehicle_count` string,
    `task_day_count` string,
    `plan_depart_tm_day_max` string,
    `plan_depart_tm_day_min` string,
    `dis_sum` string,
    `task_count_per_day` string,
    `dis_sum_per_day` string,
    `oil_sum` string,
    `oil_sum_per_day` string,
    `vehicle_distribution` string,
    `gas_count` string,
    `national_gas_count` string,
    `private_gas_count` string,
    `update_time` string COMMENT '更新时间',
    circle_name	 string COMMENT '集散圈名称',
    main_gas_count	 string COMMENT '主营油站数',
    main_gas_online_count	 string COMMENT '主营油站上线数',
    main_carrier_count	 string COMMENT '主营车队数',
    main_carrier_vehicle_count	 string COMMENT '主营车队车辆数',
    main_carrier_online_count	 string COMMENT '主营车队上线数',
    main_carrier_online_vehicle_count	 string COMMENT '主营车队上线车辆数',
    `biz_day` String  comment  '业务日期'
  ) COMMENT 'clue_circle_rslt月度表' PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
stored as parquet tblproperties('parquet.compression' = 'snappy');


drop table if  exists  `dm_gis.dm_ddjy_mid_carrier_rlst_di_month_test`;
CREATE TABLE if not exists  `dm_gis.dm_ddjy_mid_carrier_rlst_di_month_test`(
    `carrier_id` string,
    `carrier_name` string,
    `carrier_status` string,
    `carrier_tag` string,
    `carrier_circle_id` string,
    `legal_person_name` string,
    `content` string,
    `credit_code` string,
    `carrier_province` string,
    `carrier_city` string,
    `register_vehicle_count` string,
    `carrier_scale` string,
    `carrier_suspected_address` string,
    `carrier_priority` string,
    `task_count` string,
    `vehicle_count` string,
    `task_day_count` string,
    `plan_depart_tm_day_max` string,
    `plan_depart_tm_day_min` string,
    `dis_sum` string,
    `vehicle_load_count_distribution` string,
    `carrier_circle_task_count` string,
    `task_count_per_day` string,
    `dis_sum_per_day` string,
    oil_sum	 string,
    oil_sum_per_day	 string ,
    clue_distribution	 string,
    gas_distribution	 string,
    city_distribution	 string,
    update_time	 string,
    task_batch	 string ,
    `biz_day` String  comment  '业务日期'
) COMMENT '线索车队月度数据' PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
    stored as parquet tblproperties('parquet.compression' = 'snappy');



drop table if  exists  dm_gis.ods_t_invoice_company;
CREATE TABLE if not exists  dm_gis.ods_t_invoice_company(
    id string NOT NULL COMMENT 'ID',
    corp_name string NOT NULL COMMENT '企业名称',
    petrol_resources string  COMMENT '所属环境：2-顺象 3-演示',
    credit_code string NOT NULL COMMENT '统一社会信用代码',
    register_address string COMMENT '注册地址',
    legal_person string  COMMENT '法人姓名',
    legal_person_id_card string  COMMENT '法人身份证号',
    id_card_valid_date string COMMENT '身份证有效期',
    linkman string COMMENT '企业联系人',
    linkman_phone string COMMENT '联系人电话',
    linkman_phone_origin string COMMENT '原始联系人电话',
    linkman_phone_encode string COMMENT '加密联系人电话',
    org_id string COMMENT '组织机构id',
    remark string COMMENT '备注',
    capital_model string NOT NULL COMMENT '资金模式(1-应收应付,2-代收代付)',
    service_charge String NOT NULL  COMMENT '技术服务费',
    service_charge_unit string COMMENT '技术服务费单位(1-元/单,2-%/单)',
    bank_name string COMMENT '开户银行',
    bank_account string COMMENT '实体账户号',
    bank_code string COMMENT '开户银行编码',
    bank_default_tel string COMMENT '提现银行预留手机号',
    bank_default_tel_origin string COMMENT '原始提现银行预留手机号',
    bank_default_tel_encode string COMMENT '加密提现银行预留手机号',
    business_license_url string COMMENT '营业执照URL',
    id_card_front_url string COMMENT '身份证正面URL',
    id_card_back_url string COMMENT '身份证反面URL',
    create_date string COMMENT '创建时间',
    create_by string COMMENT '创建者',
    update_date string  COMMENT '修改时间',
    update_by string COMMENT '修改人',
    del_flag string  COMMENT '是否删除：0-否（默认），1-是',
    business_license_json string COMMENT '营业执照OCR识别JSON',
    id_card_front_json string COMMENT '身份证正面OCR识别JSON',
    id_card_back_json string COMMENT '身份证反面OCR识别JSON',
    link_station_type string COMMENT '关联油站类型(多个使用逗号分隔)',
    accnbr string COMMENT '主体账号',
    link_main_corp string COMMENT '关联签约主体(多个使用逗号分隔)',
    invoice_company_name string COMMENT '开票信息公司名称',
    invoice_tax_no string COMMENT '开票信息纳税人识别号',
    invoice_bank_name string COMMENT '开票信息开户银行',
    invoice_bank_no string COMMENT '开票信息开户银行编码',
    invoice_bank_account string COMMENT '开票信息账号',
    invoice_company_address string COMMENT '开票信息注册地址',
    invoice_company_phone string COMMENT '开票信息电话号码',
    invoice_company_phone_origin string COMMENT '开票信息电话号码原始值',
    invoice_company_phone_encode string COMMENT '加密开票信息电话号码',
    alias_corp_name string COMMENT '企业简称',
    business_time_valid_start string COMMENT '营业有效期开始时间',
    business_time_valid_end string COMMENT '营业有效期截止时间',
    business_place_file_url string COMMENT '营业场所图片id',
    team_pay_config_enable string COMMENT '车队代付分配状态(0-停用，1-启用(默认))',
    etl_time String commet '数据采集时间戳'
) COMMENT '开票公司数据' PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
stored as parquet tblproperties('parquet.compression' = 'snappy');





drop table if  exists  dm_gis.ddjy_dwd_Fleet_flow;
CREATE TABLE if not exists  dm_gis.ddjy_dwd_Fleet_flow(
    sup_code  string comment '区域code'
    ,sup_name  string comment '区域名称'
    ,sub_code  string comment '小组code'
    ,sub_name  string comment '小组名称'
    ,user_no  string comment '销售工号'
    ,user_name  string comment '销售名称'
    ,team_id  string comment '车队id'
    ,team_name  string comment '车队名称'
    ,month  string comment '月份'
    ,statistics_day  string comment '日期'
    ,gmv_daily string comment '当日GMV'
    ,etl_time string comment '数据采集时间戳'
) COMMENT '车队日流水明细' PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
    stored as parquet tblproperties('parquet.compression' = 'snappy');


drop table if  exists  dm_gis.ddjy_tyc_nonind_owner_info_df;
CREATE TABLE if not exists  dm_gis.ddjy_tyc_nonind_owner_info_df(
    owner_id String  comment '',
    credit_code String  comment '',
    name String  comment '',
    company_org_type_clean String  comment '',
    legal_person_name String  comment '',
    content String  comment '',
    city_adcode String  comment '',
    source_time String  comment '',
    type String  comment '',
    business_scope String  comment '',
    src String  comment '',
    city_code String  comment '',
    reg_location String  comment '',
    postal_address String  comment '',
    aoiid String  comment '',
    aoi_code String  comment '',
    aoi_name String  comment '',
    x String  comment '',
    y String  comment '',
    province String  comment '',
    city String  comment '',
    postal_province String  comment '',
    postal_city String  comment '',
    postal_city_adcode String  comment '',
    postal_aoiid String  comment '',
    postal_aoi_code String  comment '',
    postal_aoi_name String  comment '',
    postal_x String  comment '',
    postal_y String  comment '',
    postal_city_code String  comment '',
    inc_day  String  comment '',
) COMMENT '天眼查非个体企业信息表' PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
stored as parquet tblproperties('parquet.compression' = 'snappy');


alter table dm_gis.ddjy_sales_performance_monitor_di add columns (sign_customer_id_daily String comment '当日签约客户id') cascade ;



drop table if  exists  dm_gis.dm_ddjy_fleet_consumption_situation;
CREATE TABLE if not exists dm_gis.dm_ddjy_fleet_consumption_situation (
                                                                          id String comment '车队id'
    ,team_name	String comment '车队名称'
    ,sales	String comment '所属销售'
    ,sub_name	String comment '所属小组'
    ,sup_name	String comment '所属省区'
    ,team_create_date	String comment '签约日期'
    ,first_trade_date	String comment '首充日期'
    ,last_trade_date	String comment '最新充值日期（主动充值）'
    ,account_balance	String comment '账户余额'
    ,fleet_refund	String comment '待返现金额'
    ,first_pay_date	String comment '首单日期'
    ,last_pay_date	String comment '末单日期'
    ,contact_name	String comment '联系人'
    ,contact_phone	String comment '联系方式'
    ,chat_id	String comment '企微群id'
    ,group_name	String comment '企微群名称'
    ,external_userid_name	String comment '外部联系人账号id及名称'
    ,total_gmv	String comment '累计流水'
    ,top3_station	String comment '累计top3站点'
    ,consumed_car	String comment '累计消费车辆数'
    ,consumed_recency 	String comment '消费间隔'
    ,stop_consume_cnt	String comment '中断消费次数'
    ,tmonth_gmv	String comment '当月流水'
    ,tmonth_top3_station	String comment '当月top3站点'
    ,tmonth_consumed_car	String comment '当月消费车辆数'
    ,tmonth_consumed_recency 	String comment '当月消费间隔'
    ,last_month_gmv	String comment '上月流水'
    ,last_month_top3_station	String comment '上月top3站点'
    ,last_month_consumed_car	String comment '上月消费车辆数'
    ,last_month_consumed_recency 	String comment '上月消费间隔'
    ,before_lastmonth_gmv	String comment '上上月流水'
    ,before_lastmonth_top3_station	String comment '上上月top3站点'
    ,before_lastmonth_consumed_car	String comment '上上月消费车辆数'
    ,before_lastmonth_consumed_recency 	String comment '上上月消费间隔'
)COMMENT '车队消费情况表'
    PARTITIONED BY (`inc_day` string COMMENT 'inc_day')
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001' LINES TERMINATED BY '\n'
    stored as parquet tblproperties('parquet.compression' = 'snappy');



drop table if  exists  dm_gis.dm_ddjy_fleet_wechat_mapping;
CREATE TABLE if not exists dm_gis.dm_ddjy_fleet_wechat_mapping (
     team_id String comment '车队id'
    ,team_name	String comment '车队名称'
    ,chat_id	String comment '企微群id'
    ,group_name	String comment '企微群名称'
)COMMENT '车队微信群映射关系'
STORED as PARQUET;



