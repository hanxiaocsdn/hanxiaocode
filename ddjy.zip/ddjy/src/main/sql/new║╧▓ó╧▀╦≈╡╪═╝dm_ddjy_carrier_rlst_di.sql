--开启动态分区
set hive.exec.dynamic.partition=false;
set hive.exec.dynamic.partition.mode=strict;
--set hive.exec.max.dynamic.partitions=3000;
--set hive.exec.max.dynamic.partitions.pernode=1000;
--开启map结束后合并文件
set hive.merge.mapfiles=true;
--开启reduce结束后合并文件
set hive.merge.mapredfiles=true;
--每个任务合并后文件大小为256M
set hive.merge.size.per.task=268435456;
--合并后平均文件大小
set hive.merge.smallfiles.avgsize=2560000000;

--开启map端聚合
set hive.map.aggr=true;
--设置reduce个数
set mapred.reduce.tasks=100;
--开启并行计算
set hive.exec.parallel=false;
--并行任务的数量
--set hive.exec.parallel.thread.number=16;
--开启map输入端文件合并
--set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
--设置每个reduce处理文件的大小
--set hive.exec.reducers.bytes.per.reducer=128000000;
--开启mapjoin
set hive.auto.convert.join=true;

--设置每个map申请内存大小
set mapreduce.map.memory.mb=4096;
--设置每个map jvm内存大小
--set mapred.child.java.opts=-Xmx3276m;
set mapreduce.map.java.opts=-Xmx3276m;
--设置每个reduce申请内存大小
set mapreduce.reduce.memory.mb=8192;
set hive.tez.container.size=8192;
--设置每个reduce jvm内存大小
set mapreduce.reduce.java.opts=-Xmx6554m;

--开启中间输出压缩
set hive.exec.compress.intermediate=true;
set hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.intermediate.compression.type=BLOCK;

set hive.vectorized.execution.enabled=false;
set hive.vectorized.execution.reduce.enabled=false;

--last_friday=$[week_begin(yyyyMMdd,-3)]
--last_saturday=$[week_begin(yyyyMMdd,-2)]
--任务id:755

insert overwrite table dm_gis.dm_ddjy_carrier_rlst_di partition(inc_day='${last_friday}')
select
t2.carrier_id,task_batch,carrier_name,credit_code,legal_person_name,content,
'' as src1,
'' as linkman_phone,
'' as src2,
province_name as province,
city_name as city,
task_count,vehicle_count,
'7' as task_day_count,
'' as plan_depart_tm_day_max,
'' as plan_depart_tm_day_min,
'' as dis_sum,
ceiling(task_count/7) as task_count_per_day,
'' as dis_sum_per_day,
task_count*202 as oil_sum,
task_count*202/7 as oil_sum_per_day,
'' as vehicle_load_count_distribution,
clue_distribution,gas_distribution,city_distribution,
from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as update_time,
carrier_status,carrier_tag,register_vehicle_count,
city_adcode,carrier_circle_id,carrier_circle_task_count,carrier_scale,carrier_suspected_address,carrier_priority,pathway_city_distribution,
online_gas_top5,carrier_white_list,
online_gas_top10,online_gas_task_count,
nvl(reference_amount_pub,0) as whitelist_limit_corporate,
nvl(reference_amount_pri,0) as whitelist_limit_individual
from
(
	select
	carrier_id,task_batch,carrier_name,credit_code,legal_person_name,content,city_adcode,carrier_status,carrier_tag,carrier_circle_id,carrier_circle_task_count,
	register_vehicle_count,carrier_scale,carrier_suspected_address,carrier_priority,clue_distribution,pathway_city_distribution,city_distribution,
	online_gas_top5,carrier_white_list,online_gas_top10
	from
	(
		select
		carrier_id,task_batch,carrier_name,credit_code,
		if(replace(replace(legal_person_name,'()',''),',','')='','',legal_person_name) as legal_person_name,
		if(replace(replace(content,'()',''),',','')='','',content) as content,
		city_adcode,carrier_status,carrier_tag,carrier_circle_id,
		circle_task_count as carrier_circle_task_count,
		register_vehicle_count,carrier_scale,carrier_suspected_address,carrier_priority,clue_distribution,pathway_city_distribution,
		clue_city_distribution as city_distribution,
		online_gas_top5,carrier_white_list,
		online_gas_top10,
		row_number() over(partition by carrier_id order by carrier_scale desc) as rnk
		from dm_gis.dm_ddjy_gas_carrier_merge_di
		where inc_day='${last_friday}'
	) t0_1
	where rnk=1
) t2
left join
(
	select
	owner_id,
	max(province_name) as province_name,
	max(city_name) as city_name
	from dm_gis.dim_ddjy_vehicle_concat_yy_df
	where inc_day='${last_saturday}'
	and province_name is not null
	and province_name!=''
	group by owner_id
) t3
on t2.carrier_id=t3.owner_id
left join
(
	select
	carrier_id,
	count(distinct vehicle_no) as vehicle_count
	from dm_gis.dm_ddjy_gas_car_merge_di
	where inc_day='${last_friday}'
	group by carrier_id
) t4
on t2.carrier_id=t4.carrier_id
left join
(
	select
	carrier_id,
	concat_ws('、',collect_set(concat(gas_id,':',cooperatestatus))) as gas_distribution
	from
	(
		select
		carrier_id,gas_id,cooperatestatus,
		row_number() over(partition by carrier_id order by gas_id desc) as rnk
		from
		(
			select
			carrier_id,gas_id,
			max(cooperatestatus) as cooperatestatus
			from dm_gis.dm_ddjy_gas_carrier_merge_di
			where inc_day='${last_friday}'
			group by carrier_id,gas_id
		) t5
	) t5_1
	where rnk<=10
	group by carrier_id
) t6
on t2.carrier_id=t6.carrier_id
left join
(
	select
	company_name,reference_amount_pri,reference_amount_pub
	from dm_gis.guang_dong_province_white_list_df
) t7
on t2.carrier_name=t7.company_name
left join
(
	select
	carrier_id,
	sum(task_count) as task_count
	from dm_gis.dm_ddjy_clue_rel_carrier_di
	where inc_day='${last_friday}'
	group by carrier_id
) t8
on t2.carrier_id=t8.carrier_id
left join
(
    select
    carrier_id,sum(task_count) as online_gas_task_count
    from
    (
        select
        t9.clue_id,carrier_id,
        max(task_count) as task_count
        from
        (
            select
            clue_id,carrier_id,task_count
            from dm_gis.dm_ddjy_clue_rel_carrier_di
            where inc_day='${last_friday}'
        ) t9
        join
        (
            select
            clue_id,cooperate_status
            from dm_gis.dwd_ddjy_clue_rel_gas_station_di
            where inc_day='${last_friday}'
            and cooperate_status='3'
        ) t10
        on t9.clue_id=t10.clue_id
        group by t9.clue_id,carrier_id
    ) t11
    group by carrier_id
) t12
on t2.carrier_id=t12.carrier_id;