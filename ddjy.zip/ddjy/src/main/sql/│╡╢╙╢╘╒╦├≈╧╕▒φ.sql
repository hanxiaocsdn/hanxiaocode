--开启动态分区
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=3000;
set hive.exec.max.dynamic.partitions.pernode=1000;
--开启map结束后合并文件
set hive.merge.mapfiles=true;
--开启reduce结束后合并文件
set hive.merge.mapredfiles=true;
--每个任务合并后文件大小为256M
set hive.merge.size.per.task=268435456;
--合并后平均文件大小
set hive.merge.smallfiles.avgsize=2560000000;

--开启map端聚合
set hive.map.aggr=true;
--设置reduce个数
set mapred.reduce.tasks=5;
--开启并行计算
set hive.exec.parallel=false;
--并行任务的数量
--set hive.exec.parallel.thread.number=16;
--开启map输入端文件合并
--set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
--设置每个reduce处理文件的大小
--set hive.exec.reducers.bytes.per.reducer=128000000;
--开启mapjoin
set hive.auto.convert.join=true;

--设置每个map申请内存大小
set mapreduce.map.memory.mb=4096;
--设置每个map jvm内存大小
--set mapred.child.java.opts=-Xmx3276m;
set mapreduce.map.java.opts=-Xmx3276m;
--设置每个reduce申请内存大小
set mapreduce.reduce.memory.mb=8192;
--设置每个reduce jvm内存大小
set mapreduce.reduce.java.opts=-Xmx6554m;

--开启中间输出压缩
set hive.exec.compress.intermediate=true;
set hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.intermediate.compression.type=BLOCK;

--start_day=20220816
--end_day=$[yyyyMMdd-1]
--任务id:1072


insert overwrite table dm_gis.ddjy_team_balance_account_di partition(inc_day='${end_day}')
select
check_bill_no,bill_date,check_date,team_name,check_status,push_status,audit_result,remark,create_by,create_date,update_by,update_date,return_type,return_status,appeal_date,appeal_order_sn,order_sn,originator,station_name,car_team_name,invoice_company_name,capital_model,driver_name,driver_phone,appeal_reasons,appeal_status,before_petrol_type_name,before_oil_mass,before_order_amount,after_petrol_type_name,after_oil_mass,after_order_amount,appeal_explain,verify_result,reject_reason,new_order_sn,new_order_status,oil_sales_name,team_sales_name,
split(promote_check_bill_stage,'-')[1] as check_bill_stage,
split(promote_check_bill_stage,'-')[0] as promote,
max_create_date,business_time,team_sales_subname,return_time
from
(
	select
	check_bill_no,bill_date,check_date,team_name,
	case when check_status=1 then '待对账'
		 when check_status=2 then '对账中'
		 when check_status=3 then '已对账'
		 when check_status=4 then '已取消'
		 end as check_status,
	case when push_status=1 then '未下发'
		 when push_status=2 then '已下发'
		 end as push_status,
	case when audit_result=0 then '未审核'
		 when audit_result=1 then '无异议'
		 when audit_result=2 then '有异议'
		 end as audit_result,
	remark,create_by,create_date,update_by,
	update_date,
	case when return_type=0 then '订单返现'
		 when return_type=1 then '梯度返现'
		 end as return_type,
	case when return_status=1 then '待返现'
		 when return_status=2 then '已返现'
		 end as return_status,
	appeal_date,appeal_order_sn,order_sn,
	case when originator=1 then '油站'
		 when originator=2 then '车队'
		 when originator=3 then '油品贸易方'
		 end as originator,
	station_name,car_team_name,invoice_company_name,
	case when capital_model=1 then '应收应付'
		 when capital_model=2 then '代收代付'
		 when capital_model=3 then '应收应付&代收代付'
		 end as capital_model,
	driver_name,driver_phone,
	case when appeal_reasons=1 then '输错油量'
		 when appeal_reasons=99 then '退款'
		 when appeal_reasons=2 then '订单补录'
		 end as appeal_reasons,
	case when appeal_status=1 then '待车队核实'
		 when appeal_status=2 then '待油站核实'
		 when appeal_status=3 then '申诉成功'
		 when appeal_status=4 then '申诉失败'
		 end as appeal_status,
	before_petrol_type_name,before_oil_mass,before_order_amount,after_petrol_type_name,after_oil_mass,after_order_amount,appeal_explain,verify_result,reject_reason,new_order_sn,
	case when new_order_status=0 then '初始状态'
		 when new_order_status=1 then '待支付'
		 when new_order_status=2 then '支付成功'
		 when new_order_status=3 then '支付失败'
		 when new_order_status=4 then '订单超时'
		 when new_order_status=5 then '已取消'
		 when new_order_status=6 then '订单作废完成'
		 when new_order_status=7 then '作废中'
		 when new_order_status=8 then '作废失败'
		 when new_order_status=9 then '待审核'
		 when new_order_status=10 then '补录中'
		 end as new_order_status,
	oil_sales_name,team_sales_name,
	case when check_status=2 and push_status=2 and audit_result=0 then '车队-账单已下发，待车队审核'
			 when check_status in(1,2) and push_status=1 and audit_result=0 then '财务-待财务下发对账单'
			 when check_status=3 and push_status=2 and audit_result=1 and(return_status='' or return_status is null) then '财务-已对账待生成返现单'
			 when check_status=3 and push_status=2 and audit_result=1 and return_status=1 then '财务-对账完成，已生成返现单待返现'
			 when check_status=3 and push_status=2 and audit_result=1 and return_status=2 then '无-已对账已返现'
			 when max_all_create_date=create_date and check_status=4 and push_status in(1,2) and audit_result in(0,2) and new_order_status=2  then '财务-账单异常已处理，待财务重新下发对账单'
			 when max_all_create_date>create_date and check_status=4 and push_status in(1,2) and audit_result in(0,2) and new_order_status=2  then '无-账单异常已处理，财务已经重新下发对账单'
			 when check_status=4 and push_status in(1,2) and audit_result in(0,2) and appeal_status=4  then '客服-账单异常申诉失败'
			 when check_status=4 and push_status in(1,2) and audit_result in(0,2) and new_order_status=3  then '车队-账单异常支付失败,待车队处理'
			 when check_status=4 and push_status in(1,2) and audit_result in(0,2) and appeal_status=2 then '油站-账单异常待油站核实'
			 end as promote_check_bill_stage,
	max_create_date,business_time,team_sales_subname,
	return_time
	from
	(
		select
		check_bill_no,bill_date,check_date,team_name,check_status,push_status,audit_result,remark,
		nick_name as create_by,
		create_date,
		nick_name as update_by,
		update_date,return_type,return_status,
		appeal_date,appeal_order_sn,order_sn,originator,
		station_name,car_team_name,invoice_company_name,capital_model,driver_name,driver_phone,
		appeal_reasons,appeal_status,before_petrol_type_name,before_oil_mass,before_order_amount,after_petrol_type_name,after_oil_mass,after_order_amount,appeal_explain,verify_result,reject_reason,new_order_sn,
		case when new_order_sn='' or new_order_sn is null then ''
			 else new_order_status
			 end as new_order_status,
		oil_sales_name,
		user_name as team_sales_name,
		max_create_date,max_all_create_date,business_time,
		sub_name as team_sales_subname,
		return_time
		from
		(
			select
			check_bill_no,
			case when substr(start_check_date,0,6)=substr(end_check_date,0,6) and cast(substr(start_check_date,7,8) as int)<=25 then
			concat(substr(date_format(add_months(from_unixtime(unix_timestamp(start_check_date,'yyyyMMdd'),'yyyy-MM-dd'),-1),'yyyyMMdd'),0,6),'26','-',
			substr(end_check_date,0,6),'25')
			when substr(start_check_date,0,6)=substr(end_check_date,0,6) and cast(substr(start_check_date,7,8) as int)>25 then
			concat(substr(start_check_date,0,6),'26','-',
			substr(date_format(add_months(from_unixtime(unix_timestamp(end_check_date,'yyyyMMdd'),'yyyy-MM-dd'),1),'yyyyMMdd'),0,6),'25')
			when substr(start_check_date,0,6)!=substr(end_check_date,0,6) then
			concat(substr(start_check_date,0,6),'26','-',substr(end_check_date,0,6),'25')
			end as bill_date,
			check_date,team_name,check_status,push_status,audit_result,remark,create_by,
			create_date,update_date,return_type,return_status,team_id,
			max(if(check_status=4,create_date,null)) over(partition by team_id,check_date) as max_create_date,
			max(create_date) over(partition by team_id,check_date) as max_all_create_date,
			max(check_status) over(partition by team_id,check_date) as max_check_status,
			return_time
			from
			(
				select
				check_bill_no,
				split(check_date,'-')[0] as start_check_date,
				split(check_date,'-')[1] as end_check_date,
				check_date,team_name,check_status,push_status,audit_result,remark,create_by,
				create_date,update_date,return_type,return_status,team_id,return_time
				from dm_gis.ddjy_ods_team_check_bill_df
				where inc_day='${end_day}'
				and del_flag = 0
			) t1
		) t2
		left join
		(
			select
			id,nick_name
			from dm_gis.ddjy_ods_ua_sys_user_df
			where inc_day='${end_day}'
			and del_flag = 0
		) t3
		on t2.create_by=t3.id
		left join
		(
			select
			appeal_date,appeal_order_sn,t4.order_sn,originator,appeal_reasons,appeal_status,before_petrol_type_name,before_oil_mass,before_order_amount,after_petrol_type_name,after_oil_mass,after_order_amount,appeal_explain,verify_result,reject_reason,new_order_sn,team_id,
			station_name,car_team_name,invoice_company_name,capital_model,driver_name,driver_phone,new_order_status,business_time,oil_sales_name
			from
			(
				select
				order_sn_join,appeal_date,appeal_order_sn,order_sn,originator,appeal_reasons,appeal_status,before_petrol_type_name,before_oil_mass,before_order_amount,after_petrol_type_name,after_oil_mass,after_order_amount,appeal_explain,verify_result,reject_reason,new_order_sn,team_id,station_id,
				sales_name as oil_sales_name
				from
				(
					select
					if(new_order_sn is null or new_order_sn='',order_sn,new_order_sn) as order_sn_join,
					create_date  as appeal_date,
					id as appeal_order_sn,
					order_sn,originator,appeal_reasons,appeal_status,before_petrol_type_name,before_oil_mass,before_order_amount,after_petrol_type_name,after_oil_mass,after_order_amount,appeal_explain,
					case when new_order_sn!='' and new_order_sn is not null then concat(order_sn,'已作废,重新生成订单',new_order_sn)
						 when (new_order_sn is null or new_order_sn='') and appeal_status='3' then concat(order_sn,'已作废')
						 when (new_order_sn is null or new_order_sn='') and appeal_status!='3' then ''
						 end as verify_result,
					reject_reason,new_order_sn,team_id,station_id
					from dm_gis.ddjy_t_station_order_appeal
					where inc_day='${end_day}'
					and del_flag = 0
				) t4_1
				left join
				(
					select
					id,corp_id
					from dm_gis.ddjy_dim_station_info_filter
				) t4_2
				on t4_1.station_id=t4_2.id
				left join
				(
					select
					id,sales_name
					from dm_gis.ddjy_ods_corp_info_df
					where inc_day='${end_day}'
					and del_flag='0'
				) t4_3
				on t4_2.corp_id=t4_3.id
			) t4
			left join
			(
				select
				order_sn,station_name,car_team_name,invoice_company_name,capital_model,driver_name,driver_phone,
				order_status as new_order_status,
				inc_day as business_time,station_id
				from dm_gis.ddjy_dwd_station_order_repartition_di
				where inc_day>='${start_day}' and inc_day<='${end_day}'
			) t5
			on t4.order_sn_join=t5.order_sn
		) t6
		on t2.team_id=t6.team_id
		and (((order_sn is not null and order_sn!='')
		and ((max_check_status='4'
		and check_status='4'
		and max_create_date=create_date
		and business_time>=split(bill_date,'-')[0]
		and business_time<=split(bill_date,'-')[1])
		or (max_check_status!='4'
		and business_time>=split(bill_date,'-')[0]
		and business_time<=split(bill_date,'-')[1])))
		or ((order_sn is null or order_sn='')
		and ((max_check_status='4'
		and check_status='4'
		and max_create_date=create_date)
		or (max_check_status!='4'))))
		left join
		(
			select
			team_id,user_name,sub_name
			from dm_gis.ddjy_ods_sales_team
			where inc_day='${end_day}'
			and deleted = 0
		) t7
		on t2.team_id=t7.team_id
		join
		(
			select id
			from dm_gis.ddjy_dim_team_info_filter
			where inc_day='${end_day}'
		) t8
		on t2.team_id=t8.id
	) t9
) t10;