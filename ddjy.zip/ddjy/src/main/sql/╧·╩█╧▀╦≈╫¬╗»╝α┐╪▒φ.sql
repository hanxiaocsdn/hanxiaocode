--开启动态分区
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=3000;
set hive.exec.max.dynamic.partitions.pernode=1000;
--开启map结束后合并文件
set hive.merge.mapfiles=true;
--开启reduce结束后合并文件
set hive.merge.mapredfiles=true;
--每个任务合并后文件大小为256M
set hive.merge.size.per.task=268435456;
--合并后平均文件大小
set hive.merge.smallfiles.avgsize=2560000000;

--开启map端聚合
set hive.map.aggr=true;

--设置reduce个数
--set mapred.reduce.tasks=200;
--开启并行计算
set hive.exec.parallel=true;
--并行任务的数量
set hive.exec.parallel.thread.number=16;
--开启map输入端文件合并
--set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
--设置每个reduce处理文件的大小
--set hive.exec.reducers.bytes.per.reducer=128000000;
--开启mapjoin
set hive.auto.convert.join=true;

--设置每个map申请内存大小
set mapreduce.map.memory.mb=4096;
--设置每个map jvm内存大小
--set mapred.child.java.opts=-Xmx3276m;
set mapreduce.map.java.opts=-Xmx3276m;
--设置每个reduce申请内存大小
set mapreduce.reduce.memory.mb=8192;
--设置每个reduce jvm内存大小
set mapreduce.reduce.java.opts=-Xmx6554m;

--开启中间输出压缩
set hive.exec.compress.intermediate=true;
set hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.intermediate.compression.type=BLOCK;

--inc_day=$[yyyyMMdd-4/24]
--start_day=$[yyyyMMdd-120]
--任务id:812

with join_tmp1 as (
select
carrier_id,carrier_name,credit_code,id,tax_no,team_info_time,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,matching_degree
from
(
	select
	carrier_id,carrier_name,credit_code,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,matching_degree
	from
	(
		select
		carrier_id,carrier_name,credit_code,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,
		online_gas_task_count/task_count as matching_degree,
		row_number() over(partition by carrier_id order by inc_day desc) as rnk
		from dm_gis.dm_ddjy_carrier_rlst_di
		where inc_day<='${inc_day}' and inc_day>='${start_day}'
		and credit_code!=''
	) t5_1
	where rnk=1
) t5
left join
(
	select
	id,tax_no,create_date as team_info_time
	from dm_gis.ddjy_dim_team_info_filter
	where inc_day='${inc_day}'
) t6
on t5.credit_code=t6.tax_no
),join_tmp2 as (
select
t1.user_no,clue_pick_time,customer_source,team_name,t1.carrier_id,sub_status,
sup_code,sup_name,sub_code,sub_name,user_id,user_name,
t3.clue_team_station_id,clue_team_station_name,
clue_call_time,call_result,call_result_reason,call_description,
clue_interview_time,interview_result,interview_result_reason,interview_description,intend_grade,
carrier_name,credit_code,t7.id,tax_no,team_info_time,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,matching_degree,
update_time,business_type,frequent_route,ownCars,epibolyCars,refueling_strategy,need_station_point,estimated_monthly_refueling,legal_person_name,person_contact,max_clue_pick_time,customer_intention,clue_intend_id,
old_customer_team_id,old_customer_team_name,old_customer_phone,old_customer_discount_program
from
(
	select
	trim(current_user_name) as user_no,
	create_time as clue_pick_time,
	customer_source,team_name,
	team_id as carrier_id,
	sub_status,id,
	clue_team_station_id,
	contact as legal_person_name,
	contact_phone as person_contact,
	max(create_time) over(partition by trim(current_user_name),team_id) as max_clue_pick_time,
	clue_intend_id,
	old_customer_team_id,old_customer_team_name,old_customer_phone,old_customer_discount_program
	from dm_gis.ddjy_ods_clue_follow_up
	where inc_day='${inc_day}'
	and del_flag='0'
) t1
left join
(
	select
	trim(user_no) as user_no,sup_code,sup_name,sub_code,sub_name,user_id,user_name
	from dm_gis.ddjy_ods_sales_info
	where inc_day='${inc_day}'
	and deleted='0'
) t2
on t1.user_no=trim(t2.user_no)
left join
(
	select
	id,station_id as clue_team_station_id,
	station_name as clue_team_station_name
	from dm_gis.t_clue_team_station
	where inc_day='${inc_day}'
	and deleted='0'
) t3
on t1.clue_team_station_id=t3.id
left join
(
	select
	follow_up_id,clue_call_time,call_result,
	concat(nvl(sub_touch_result_analysis,''),nvl(get_json_object(sub_customer_intention,'$.no_intention'),'')) as call_result_reason,
	call_description,customer_intention
	from
	(
		select
		follow_up_id,
		create_date as clue_call_time,
		concat(nvl(get_json_object(touch_result,'$.touching_customer'),''),nvl(get_json_object(customer_intention,'$.preliminary_intention'),'')) as call_result,
		case when sub_touch_result like '%invalid_answer%' then get_json_object(sub_touch_result,'$.invalid_answer')
			 when sub_touch_result like '%no_answer%' then get_json_object(sub_touch_result,'$.no_answer')
			 when sub_touch_result like '%valid_answer%' then get_json_object(sub_touch_result,'$.valid_answer')
			 when sub_touch_result like '%no_connect%' then get_json_object(sub_touch_result,'$.no_connect')
			 end as sub_touch_result_analysis,
		sub_customer_intention,
		follow_up_description as call_description,customer_intention,
		row_number() over(partition by follow_up_id order by create_date desc) as rnk
		from dm_gis.ddjy_ods_clue_call_detail
		where inc_day='${inc_day}'
		and del_flag='0'
	) t4_1
	where rnk=1
) t4
on t1.id=t4.follow_up_id
left join
(
	select
	follow_up_id,clue_interview_time,interview_result,interview_result_reason,interview_description,intend_grade,
	update_time,business_type,frequent_route,ownCars,epibolyCars,refueling_strategy,need_station_point,estimated_monthly_refueling
	from
	(
		select
		follow_up_id,
		interview_time as clue_interview_time,
		interview_result,
		refuse_reason as interview_result_reason,
		follow_up_description as interview_description,
		intend_grade,
		update_date as update_time,business_type,frequent_route,
		get_json_object(scope,"$.ownCars") as ownCars,
		get_json_object(scope,"$.epibolyCars") as epibolyCars,
		refueling_strategy,need_station_point,estimated_monthly_refueling,
		row_number() over(partition by follow_up_id order by create_date desc) as rnk
		from dm_gis.ddjy_ods_clue_interview_detail
		where inc_day='${inc_day}'
		and del_flag='0'
	) t12_1
	where rnk=1
) t12
on t1.id=t12.follow_up_id
left join join_tmp1 t7
on t1.carrier_id=t7.carrier_id
),join_tmp3 as (
select
carrier_id,
nvl(carrier_name,name) as carrier_name,
credit_code,id,tax_no,team_info_time,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,matching_degree
from
(
	select
	carrier_id,carrier_name,credit_code,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,matching_degree
	from
	(
		select
		carrier_id,carrier_name,credit_code,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,
		online_gas_task_count/task_count as matching_degree,
		row_number() over(partition by carrier_name order by inc_day desc) as rnk
		from dm_gis.dm_ddjy_carrier_rlst_di
		where inc_day<='${inc_day}' and inc_day>='${start_day}'
		and credit_code!=''
	) t5_2
	where rnk=1
) t5_3
full join
(
	select
	id,tax_no,name,create_date as team_info_time
	from dm_gis.ddjy_dim_team_info_filter
	where inc_day='${inc_day}'
) t6_3
on t5_3.credit_code=t6_3.tax_no
)


insert overwrite table dm_gis.ddjy_sales_clue_conversion_monitor_di partition(inc_day='${inc_day}')
select
user_no,sup_code,sup_name,sub_code,sub_name,user_id,user_name,clue_team_station_id,clue_team_station_name,clue_pick_time,customer_source,carrier_id,team_name,sub_status,
clue_call_time,call_result,call_result_reason,call_description,clue_interview_time,
if(interview_result in('面谈成功','面谈拒绝','需继续拜访'),interview_result,'') as interview_result,
interview_result_reason,interview_description,
team_signed_time,team_recharge_time,team_consumed_time,car_team_id,team_info_time,
custom_remark,intend_level,intend_grade,
city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,
round(matching_degree,4) as matching_degree,
t13.update_time,business_type,frequent_route,ownCars,epibolyCars,refueling_strategy,need_station_point,estimated_monthly_refueling,
custom_address,wx_number,
if(team_signed_time is null or team_signed_time='','否','是') as is_signed,
legal_person_name,person_contact,customer_intention,
if((customer_source in('-1','6') and customer_intention like '%有意向%' and sub_status not in('已转交','超时作废')) or (customer_source not in('-1','6') and ((sub_status in('待约谈') and (clue_interview_time='' or clue_interview_time is null)) or (clue_interview_time!='' and clue_interview_time is not null and sub_status not in('已转交','超时作废')))),1,0) as is_intend,
is_same_person,
case when ((sub_status='待电话沟通' and clue_pick_time is not null and clue_call_time is null)
or (sub_status='待重call')
or (sub_status='未触达客户')
or (customer_source in (-1,6) and customer_intention like '%无意向%'))
and (team_signed_time is null or team_signed_time='')
and (team_recharge_time is null or team_recharge_time='')
and (team_consumed_time is null or team_consumed_time='') then '未确认意向'
when ((sub_status='待约谈' and clue_pick_time is not null and clue_interview_time is null)
or (sub_status='待约谈' and interview_result in('约谈拒绝','未约面谈时间需继续','未联系到客户需继续')))
and (team_signed_time is null or team_signed_time='')
and (team_recharge_time is null or team_recharge_time='')
and (team_consumed_time is null or team_consumed_time='') then '约谈阶段'
when (sub_status='待约谈' and interview_result in('面谈成功','面谈拒绝','需继续拜访','已约时间待面谈','仅约访未面谈'))
and (team_signed_time is null or team_signed_time='')
and (team_recharge_time is null or team_recharge_time='')
and (team_consumed_time is null or team_consumed_time='') then '面谈阶段'
when team_signed_time!='' and team_signed_time is not null
and (team_recharge_time is null or team_recharge_time='')
and (team_consumed_time is null or team_consumed_time='') then '签约待充值'
when team_signed_time!='' and team_signed_time is not null
and (team_recharge_time!='' and team_recharge_time is not null)
and (team_consumed_time is null or team_consumed_time='') then '充值待消费'
when team_signed_time!='' and team_signed_time is not null
and (team_recharge_time!='' and team_recharge_time is not null)
and (team_consumed_time!='' and team_consumed_time is not null) then '已消费'
end as customer_stage,
if(interview_result in('约谈拒绝','未约面谈时间需继续','未联系到客户需继续','已约时间待面谈','仅约访未面谈'),interview_result,'') as recall_result,
old_customer_team_id,old_customer_team_name,old_customer_phone,old_customer_discount_program
from
(
	select
	nvl(t11.user_no,t10.user_no) as user_no,
	sup_code,sup_name,sub_code,sub_name,user_id,user_name,
	clue_team_station_id,clue_team_station_name,
	clue_pick_time,
	if(customer_source='' and clue_call_time is not null,'-1',customer_source) as customer_source,
	t11.carrier_id,team_name,sub_status,
	clue_call_time,call_result,call_result_reason,call_description,clue_interview_time,interview_result,interview_result_reason,interview_description,
	team_info_time as team_signed_time,
	team_recharge_time,
	team_consumed_time,
	nvl(t11.id,t10.team_id) as car_team_id,
	team_info_time,
	intend_grade,
	city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,matching_degree,
	update_time,business_type,frequent_route,ownCars,epibolyCars,refueling_strategy,need_station_point,estimated_monthly_refueling,legal_person_name,person_contact,
	max_clue_pick_time,customer_intention,clue_intend_id,
	if(t11.user_no=t10.user_no,1,0) as is_same_person,
	old_customer_team_id,old_customer_team_name,old_customer_phone,old_customer_discount_program
	from
	(
		select
		user_no,clue_pick_time,customer_source,team_name,t11_1.carrier_id,sub_status,
		sup_code,sup_name,sub_code,sub_name,user_id,user_name,
		clue_team_station_id,clue_team_station_name,
		clue_call_time,call_result,call_result_reason,call_description,
		clue_interview_time,interview_result,interview_result_reason,interview_description,intend_grade,
		t11_1.carrier_name,credit_code,id,tax_no,team_info_time,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,matching_degree,
		update_time,business_type,frequent_route,ownCars,epibolyCars,refueling_strategy,need_station_point,estimated_monthly_refueling,legal_person_name,person_contact,max_clue_pick_time,customer_intention,clue_intend_id,
		old_customer_team_id,old_customer_team_name,old_customer_phone,old_customer_discount_program
		from
		(
			select
			user_no,clue_pick_time,customer_source,team_name,carrier_id,sub_status,
			sup_code,sup_name,sub_code,sub_name,user_id,user_name,
			clue_team_station_id,clue_team_station_name,
			clue_call_time,call_result,call_result_reason,call_description,
			clue_interview_time,interview_result,interview_result_reason,interview_description,intend_grade,
			carrier_name,
			update_time,business_type,frequent_route,ownCars,epibolyCars,refueling_strategy,need_station_point,estimated_monthly_refueling,legal_person_name,person_contact,max_clue_pick_time,customer_intention,clue_intend_id,
			old_customer_team_id,old_customer_team_name,old_customer_phone,old_customer_discount_program
			from join_tmp2
			where carrier_name is null
		) t11_1
		left join join_tmp3 t11_2
		on t11_1.team_name=t11_2.carrier_name
		union all
		select
		user_no,clue_pick_time,customer_source,team_name,carrier_id,sub_status,
		sup_code,sup_name,sub_code,sub_name,user_id,user_name,
		clue_team_station_id,clue_team_station_name,
		clue_call_time,call_result,call_result_reason,call_description,
		clue_interview_time,interview_result,interview_result_reason,interview_description,intend_grade,
		carrier_name,credit_code,id,tax_no,team_info_time,city,register_vehicle_count,online_gas_top10,city_distribution,whitelist_limit_individual,whitelist_limit_corporate,matching_degree,
		update_time,business_type,frequent_route,ownCars,epibolyCars,refueling_strategy,need_station_point,estimated_monthly_refueling,legal_person_name,person_contact,max_clue_pick_time,customer_intention,clue_intend_id,
		old_customer_team_id,old_customer_team_name,old_customer_phone,old_customer_discount_program
		from join_tmp2
		where carrier_name is not null
	) t11
	full join
	(

		select
		t8.team_id,user_no,
		first_trade_date as team_recharge_time,
		first_pay_date as team_consumed_time
		from
		(
			select
			user_no,team_id,create_date
			from
			(
				select
				user_no,team_id,create_date,
				row_number() over(partition by team_id order by create_date) as rnk
				from dm_gis.ddjy_ods_sales_team
				where inc_day='${inc_day}'
			) t8_1
			where rnk=1
		) t8
		left join
		(
			select
			car_team_id,
			min(first_trade_date) as first_trade_date,
			min(first_pay_date) as first_pay_date
			from dm_gis.ddjy_dwd_station_stream_detail
			where inc_day='${inc_day}'
			group by car_team_id
		) t9
		on t8.team_id=t9.car_team_id
	) t10
	on t11.id=t10.team_id
	where user_id is not null
	and user_name not like '%测试%'
	and sub_name not like '%测试%'
	and sup_name not like '%测试%'
	and sup_code!=''
	and sub_code!=''
	and user_name not in ('张楠','徐火全','刘芮')
) t13
left join
(
	select
	id,custom_remark,intend_level,
	if(update_time is null or update_time='',create_time,update_time) as update_time,
	custom_address,wx_number
	from dm_gis.ddjy_ods_clue_intend_detail_df
	where inc_day='${inc_day}'
	and sale_name!=''
	and sale_name is not null
	and deleted='0'
) t15
on t13.clue_intend_id=t15.id;