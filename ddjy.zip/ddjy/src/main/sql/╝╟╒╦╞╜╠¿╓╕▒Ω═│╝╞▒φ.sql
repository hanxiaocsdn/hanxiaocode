--开启动态分区
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=3000;
set hive.exec.max.dynamic.partitions.pernode=1000;
--开启map结束后合并文件
set hive.merge.mapfiles=true;
--开启reduce结束后合并文件
set hive.merge.mapredfiles=true;
--每个任务合并后文件大小为256M
set hive.merge.size.per.task=268435456;
--合并后平均文件大小
set hive.merge.smallfiles.avgsize=2560000000;

--开启map端聚合
set hive.map.aggr=true;

--设置reduce个数
--set mapred.reduce.tasks=200;
--开启并行计算
set hive.exec.parallel=true;
--并行任务的数量
set hive.exec.parallel.thread.number=16;
--开启map输入端文件合并
--set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
--设置每个reduce处理文件的大小
--set hive.exec.reducers.bytes.per.reducer=128000000;
--开启mapjoin
set hive.auto.convert.join=true;

--设置每个map申请内存大小
set mapreduce.map.memory.mb=4096;
--设置每个map jvm内存大小
--set mapred.child.java.opts=-Xmx3276m;
set mapreduce.map.java.opts=-Xmx3276m;
--设置每个reduce申请内存大小
set mapreduce.reduce.memory.mb=8192;
--设置每个reduce jvm内存大小
set mapreduce.reduce.java.opts=-Xmx6554m;

--开启中间输出压缩
set hive.exec.compress.intermediate=true;
set hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.intermediate.compression.type=BLOCK;

--start_day=$[yyyyMMdd]
--end_day=$[yyyyMMdd-16]
--任务id:1054

insert overwrite table dm_gis.dm_ddjy_jzpc_cost_statistic partition(inc_day)
select
cost_type,task_num,process_fail_num,review_fail_num,
round((task_num-process_fail_num)/task_num,2) as process_pass_rate,
round((task_num-review_fail_num)/task_num,2) as review_pass_rate,
inc_day
from
(
	select
	cost_type,
	count(1) as task_num,
	count(if(operate_ageing_new>60 and operate_ageing_new<120 and is_pend=0,1,null)) as process_fail_num,
	count(if(bill_status in(4,5),1,null)) as review_fail_num,
	inc_day
	from
	(
		select
		team_id,cost_type,is_pend,bill_status,
		case when operate_ageing like '%小时%' and operate_ageing like '%分%' then cast(split(operate_ageing,'小时')[0] as int)*60+cast(replace(split(operate_ageing,'小时')[1],'分','') as int)
			when operate_ageing like '%小时%' and operate_ageing not like '%分%' then cast(replace(operate_ageing,'小时','') as int)*60
			when operate_ageing not like '%小时%' and operate_ageing like '%分%' then cast(replace(operate_ageing,'分','') as int)
			else 0 end as operate_ageing_new,
		inc_day
		from dm_gis.ddjy_ods_jzpt_occ_cost_bill_di
		where inc_day>='${start_day}' and inc_day<='${end_day}'
		and revoke_flag=0
		and del_flag=0
		and data_source in('1','2','6')
		and operate_ageing is not null
		and operate_ageing!=''
	) t1
	join
	(
		select id
		from dm_gis.ddjy_dim_team_info_filter
		where inc_day='${end_day}'
		and petrol_resources=2
	) t2
	on t1.team_id=t2.id
	group by inc_day,cost_type
) t3;