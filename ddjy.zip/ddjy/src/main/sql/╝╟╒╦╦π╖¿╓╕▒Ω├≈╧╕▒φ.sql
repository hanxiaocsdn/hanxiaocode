--开启动态分区
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=3000;
set hive.exec.max.dynamic.partitions.pernode=1000;
--开启map结束后合并文件
set hive.merge.mapfiles=true;
--开启reduce结束后合并文件
set hive.merge.mapredfiles=true;
--每个任务合并后文件大小为256M
set hive.merge.size.per.task=268435456;
--合并后平均文件大小
set hive.merge.smallfiles.avgsize=2560000000;

--开启map端聚合
set hive.map.aggr=true;

--设置reduce个数
--set mapred.reduce.tasks=200;
--开启并行计算
set hive.exec.parallel=true;
--并行任务的数量
set hive.exec.parallel.thread.number=16;
--开启map输入端文件合并
--set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
--设置每个reduce处理文件的大小
--set hive.exec.reducers.bytes.per.reducer=128000000;
--开启mapjoin
set hive.auto.convert.join=true;

--设置每个map申请内存大小
set mapreduce.map.memory.mb=4096;
--设置每个map jvm内存大小
--set mapred.child.java.opts=-Xmx3276m;
set mapreduce.map.java.opts=-Xmx3276m;
--设置每个reduce申请内存大小
set mapreduce.reduce.memory.mb=8192;
--设置每个reduce jvm内存大小
set mapreduce.reduce.java.opts=-Xmx6554m;

--开启中间输出压缩
set hive.exec.compress.intermediate=true;
set hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.intermediate.compression.type=BLOCK;

--start_day=$[yyyyMMdd]
--end_day=$[yyyyMMdd-16]
--任务id:1055

insert overwrite table dm_gis.dm_ddjy_jzpc_algorithm_di partition(inc_day)
select
id,team_id,package_type,cal_flag,team_name,cost_category,cost_category_name,cost_time,carplate,mileage,oil_mass,data_source,input_oil_mass,oil_final,ocr_car_no,ocr_mileage,ocr_volumn,current_mileage,essential_car_flag,essential_mileage_flag,essential_oil_flag,
if(essential_car_flag=1 and ocr_car_no is not null and ocr_car_no!='',1,0) as identified_car_flag,
if(essential_mileage_flag=1 and ocr_mileage is not null and ocr_mileage!='',1,0) as identified_mileage_flag,
if(essential_oil_flag=1 and ocr_volumn is not null and ocr_volumn!='',1,0) as identified_oil_flag,
if(essential_car_flag=1 and ocr_car_no=carplate,1,0) as corrected_car_flag,
if(essential_mileage_flag=1 and ocr_mileage=mileage,1,0) as corrected_mileage_flag,
if(essential_oil_flag=1 and oil_final<=ocr_volumn+0.01 and oil_final>=ocr_volumn-0.01,1,0) as corrected_oil_flag,
inc_day
from
(
	select
	id,team_id,package_type,cal_flag,team_name,cost_category,cost_category_name,cost_time,carplate,mileage,oil_mass,data_source,input_oil_mass,oil_final,ocr_car_no,ocr_mileage,ocr_volumn,current_mileage,
	if(cal_flag=1 and carplate is not null and carplate!='',1,0) as essential_car_flag,
	if(cal_flag=1 and mileage is not null and mileage!='',1,0) as essential_mileage_flag,
	if(cal_flag=1 and oil_final is not null and oil_final!='',1,0) as essential_oil_flag,
  inc_day
	from
	(
		select
		t1.id,t1.team_id,
		if(status!=1,0,1) as package_type,
		if(status!=1 and data_source in(1,2),0,1) as cal_flag,
		team_name,cost_category,cost_category_name,cost_time,carplate,mileage,oil_mass,data_source,input_oil_mass,
		if(data_source=2,input_oil_mass,oil_mass) as oil_final,
		ocr_car_no,ocr_mileage,ocr_volumn,current_mileage,
		inc_day
		from
		(
			select
			*
			from dm_gis.ddjy_ods_jzpt_occ_cost_bill_di
			where inc_day>='${start_day}' and inc_day<='${end_day}'
			and revoke_flag=0
			and del_flag=0
			and data_source in(1,2,6)
			and bill_status in(3,5)
			and cost_type=1
		) t1
		join
		(
			select
			team_id,status
			from dm_gis.ddjy_ods_jzpt_occ_team_fee_package_df
			where inc_day='${end_day}'
			and petrol_resources=2
			and del_flag=0
		) t2
		on t1.team_id=t2.team_id
	) t3
) t4;