--开启动态分区
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=3000;
set hive.exec.max.dynamic.partitions.pernode=1000;
--开启map结束后合并文件
set hive.merge.mapfiles=true;
--开启reduce结束后合并文件
set hive.merge.mapredfiles=true;
--每个任务合并后文件大小为256M
set hive.merge.size.per.task=268435456;
--合并后平均文件大小
set hive.merge.smallfiles.avgsize=2560000000;

--开启map端聚合
set hive.map.aggr=true;

--设置reduce个数
--set mapred.reduce.tasks=200;
--开启并行计算
set hive.exec.parallel=true;
--并行任务的数量
set hive.exec.parallel.thread.number=16;
--开启map输入端文件合并
--set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
--设置每个reduce处理文件的大小
--set hive.exec.reducers.bytes.per.reducer=128000000;
--开启mapjoin
set hive.auto.convert.join=true;

--设置每个map申请内存大小
set mapreduce.map.memory.mb=4096;
--设置每个map jvm内存大小
--set mapred.child.java.opts=-Xmx3276m;
set mapreduce.map.java.opts=-Xmx3276m;
--设置每个reduce申请内存大小
set mapreduce.reduce.memory.mb=8192;
--设置每个reduce jvm内存大小
set mapreduce.reduce.java.opts=-Xmx6554m;

--开启中间输出压缩
set hive.exec.compress.intermediate=true;
set hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.intermediate.compression.type=BLOCK;
--start_day=$[yyyyMMdd]
--end_day=$[yyyyMMdd-16]
--任务id:1056

insert overwrite table dm_gis.dm_ddjy_jzpc_algorithm_statistic partition(inc_day)
select
team_id,essential_car_num,identified_car_num,corrected_car_num,
if(essential_car_num!=0,identified_car_num/essential_car_num,null) as car_identified_rate,
if(essential_car_num!=0,corrected_car_num/identified_car_num,null) as car_corrected_rate,
essential_mileage_num,identified_mileage_num,corrected_mileage_num,
if(essential_mileage_num!=0,identified_mileage_num/essential_mileage_num,null) as mileage_identified_rate,
if(essential_mileage_num!=0,corrected_mileage_num/identified_mileage_num,null) as mileage_corrected_rate,
essential_oil_num,identified_oil_num,corrected_oil_num,
if(essential_oil_num!=0,identified_oil_num/essential_oil_num,null) as oil_identified_rate,
if(essential_oil_num!=0,corrected_oil_num/identified_oil_num,null) as oil_corrected_rates,
inc_day
from
(
	select
	team_id,
	sum(essential_car_flag) as essential_car_num,
	sum(identified_car_flag) as identified_car_num,
	sum(corrected_car_flag) as corrected_car_num,
	sum(essential_mileage_flag) as essential_mileage_num,
	sum(identified_mileage_flag) as identified_mileage_num,
	sum(corrected_mileage_flag) as corrected_mileage_num,
	sum(essential_oil_flag) as essential_oil_num,
	sum(identified_oil_flag) as identified_oil_num,
	sum(corrected_oil_flag) as corrected_oil_num,
	inc_day
	from dm_gis.dm_ddjy_jzpc_algorithm_di
	where inc_day>='${start_day}' and inc_day<='${end_day}'
	group by team_id,inc_day
) t1;