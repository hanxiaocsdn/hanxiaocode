--开启动态分区
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=3000;
set hive.exec.max.dynamic.partitions.pernode=1000;
--开启map结束后合并文件
set hive.merge.mapfiles=true;
--开启reduce结束后合并文件
set hive.merge.mapredfiles=true;
--每个任务合并后文件大小为256M
set hive.merge.size.per.task=268435456;
--合并后平均文件大小
set hive.merge.smallfiles.avgsize=2560000000;

--开启map端聚合
set hive.map.aggr=true;

--设置reduce个数
--set mapred.reduce.tasks=200;
--开启并行计算
set hive.exec.parallel=true;
--并行任务的数量
set hive.exec.parallel.thread.number=16;
--开启map输入端文件合并
--set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
--设置每个reduce处理文件的大小
--set hive.exec.reducers.bytes.per.reducer=128000000;
--开启mapjoin
set hive.auto.convert.join=true;

--设置每个map申请内存大小
set mapreduce.map.memory.mb=4096;
--设置每个map jvm内存大小
--set mapred.child.java.opts=-Xmx3276m;
set mapreduce.map.java.opts=-Xmx3276m;
--设置每个reduce申请内存大小
set mapreduce.reduce.memory.mb=8192;
--设置每个reduce jvm内存大小
set mapreduce.reduce.java.opts=-Xmx6554m;

--开启中间输出压缩
set hive.exec.compress.intermediate=true;
set hive.intermediate.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.intermediate.compression.type=BLOCK;

--inc_day=$[yyyyMMdd-1]
--任务id:1057

insert overwrite table dm_gis.ddjy_intend_customer_process_management_di partition(inc_day='${inc_day}')
select
user_no,user_name,sub_code,sub_name,sup_code,sup_name,car_team_id,carrier_id,carrier_name,customer_source,
team_signed_time,team_recharge_time,team_consumed_time,intend_time,interview_time,is_same_person
from
(
	select
	distinct user_no,user_name,sub_code,sub_name,sup_code,sup_name,car_team_id,carrier_id,
	team_name as carrier_name,
	customer_source,
	if(is_same_person=1,team_signed_time,null) as team_signed_time,
	if(is_same_person=1,team_recharge_time,null) as team_recharge_time,
	if(is_same_person=1,team_consumed_time,null) as team_consumed_time,
	case when customer_source in('-1','6') and sub_status not in('已转交','超时作废') and customer_intention like '%有意向%' then clue_call_time
		 when customer_source not in('-1','6') and sub_status not in('已转交','超时作废') then clue_pick_time
		 end as intend_time,
	is_same_person,clue_pick_time
	from dm_gis.ddjy_sales_clue_conversion_monitor_di
	where inc_day='${inc_day}'
) t1
left join
(
	select
	team_id,create_time,id,
	trim(current_user_name) as current_user_name
	from dm_gis.ddjy_ods_clue_follow_up
	where inc_day='${inc_day}'
	and del_flag=0
) t2
on t1.carrier_id=t2.team_id and t1.clue_pick_time=t2.create_time and t1.user_no=t2.current_user_name
left join
(
	select
	follow_up_id,
	concat_ws(',',collect_list(update_date)) as interview_time
	from dm_gis.ddjy_ods_clue_interview_detail
	where inc_day='${inc_day}'
	and del_flag=0
	and interview_result in('面谈成功','面谈失败','需继续跟进')
	group by follow_up_id
) t3
on t2.id=t3.follow_up_id
union all
select
user_no,user_name,sub_code,sub_name,sup_code,sup_name,car_team_id,
'' as carrier_id,
'' as carrier_name,
'' as customer_source,
team_signed_time,team_recharge_time,team_consumed_time,
'' as intend_time,
'' as interview_time,
'' as is_same_person
from
(
	select
	t4.car_team_id,team_signed_time,team_recharge_time,team_consumed_time
	from
	(
		select car_team_id,
		min(team_create_date) as team_signed_time,
		min(first_trade_date) as team_recharge_time,
		min(first_pay_date) as team_consumed_time
		from dm_gis.ddjy_dwd_station_stream_detail
		where inc_day='${inc_day}'
		group by car_team_id
	) t4
	left join
	(
		select
		car_team_id
		from dm_gis.ddjy_sales_clue_conversion_monitor_di
		where inc_day='${inc_day}'
		group by car_team_id
	) t5
	on t4.car_team_id=t5.car_team_id
	where t5.car_team_id is null
) t6
left join
(
	select
	team_id,user_no,user_name,sub_code,sub_name,sup_code,sup_name
	from
	(
		select
		team_id,user_no,user_name,sub_code,sub_name,sup_code,sup_name,
		row_number() over(partition by team_id order by create_date) as rnk
		from dm_gis.ddjy_ods_sales_team
		where inc_day='${inc_day}'
	) t7
	where rnk=1
) t8
on t6.car_team_id=t8.team_id;