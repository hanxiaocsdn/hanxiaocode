package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 15:46 2022/12/5
 */
case class AoiPoiUnion(
                        agr_id:String,
                        agr_rs_id:String,
                        belong_name:String,
                        belong_x:String,
                        belong_y:String,
                        src:String,
                        unique_id:String
                      )
