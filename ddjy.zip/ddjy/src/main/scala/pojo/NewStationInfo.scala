package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 15:33 2022/11/26
 */
case class NewStationInfo(poiid:String,
                          srcid:String,
                          grpid:String,
                          name_chn:String,
                          province:String,
                          city:String,
                          district:String,
                          ad_code:String,
                          addr:String,
                          lng:Double,
                          lat:Double,
                          querybrandid:Int,
                          management_model:Int,
                          gaslocationtype:Int,
                          roadname:String,
                          roadid:String,
                          roadclass:Int,
                          hasoilname:String,
                          businesshours:String,
                          tel:String,
                          headlabellist:String,
                          station_src:Int,
                          delflag:Int,
                          updatetime:String,
                          createtime:String,
                          ss:String,
                          swid:String,
                          cooperatestatus:String
)
