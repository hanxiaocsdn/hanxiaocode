package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 17:40 2022/11/18
 */
case class StationInfo(
                        poiid:String,
                        ad_code:String,
                        province:String,
                        city:String,
                        district:String,
                        name_chn:String,
                        addr_chn:String,
                        x_coord:String,
                        y_coord:String,
                        telephone:String,
                        src:String,
                        cooperate_status:String,
                        management_model:String,
                        querybrandid:String
                      )
