package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2022/11/16
 */
case class BelongJoinOwn(
                          unique_id:String,
                          agr_id:String,
                          agr_rs_id:String,
                          belong_name:String,
                          belong_id:String,
                          belong_x:String,
                          belong_y:String,
                          src:String,
                          vehicle:String,
                          vehicle_time:String,
                          owner_id:String,
                          owner_name:String,
                          province_name:String,
                          city_name:String,
                          area_name:String,
                          area_manager_name:String,
                          org_type:String,
                          credit_code:String,
                          manager:String,
                          manager_phone:String,
                          contactor:String,
                          contactor_phone:String,
                          owner_type:String,
                          stay_adcode:String,
                          stay_province:String,
                          stay_city:String,
                          stay_district:String,
                          task_batch:String,
                          inc_day:String,
                          clue_type:String
                        )
