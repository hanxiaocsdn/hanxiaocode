package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 20:57 2022/11/16
 */
case class CantoneseClueUnqiueid(
                          agr_id:String,
                          agr_rs_id:String,
                          belong_name:String,
                          belong_x:String,
                          belong_y:String,
                          src:String,
                          unique_id:String,
                          stay_adcode:String,
                          stay_province:String,
                          stay_city:String,
                          stay_district:String,
                          task_batch:String,
                          clue_addr:String,
                          task_count:String,
                          carrier_count:String,
                          vehicle_count:String,
                          dept_transfer_flag:String,
                          clue_src:String,
                          country_name:String,
                          delete_flg:String,
                          task_day_count:String,
                          task_count_per_day:String,
                          oil_sum:String,
                          oil_sum_per_day:String,
                          gas_count:String,
                          national_gas_count:String,
                          private_gas_count:String,
                          active_status:String,
                          clue_type:String
                        )
