package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 9:52 2022/11/15
 */
case class LogisticsVehicleTag(
                                agr_id:String,
                                agr_cnt:String,
                                agr_dis:String,
                                agr_tm:String,
                                agr_lng:String,
                                agr_lat:String,
                                agr_dis2sp:String,
                                agr_gh:String,
                                agr_rs_id:String,
                                agr_rs_cnt:String,
                                vehicle_type:String,
                                data_src:String,
                                vehicle:String,
                                vehicle_time:String,
                                vehicle_no:String,
                                owner_id:String,
                                owner_name:String,
                                province_name:String,
                                city_name:String,
                                area_name:String,
                                area_manager_name:String,
                                org_type:String,
                                credit_code:String,
                                manager:String,
                                manager_phone:String,
                                contactor:String,
                                contactor_phone:String,
                                owner_type:String,
                                id:String,
                                name:String,
                                faType:String,
                                aoiCode:String,
                                znoCode:String,
                                dist:String,
                                city:String,
                                is_logistics:String,
                                distribute_passpoint:String,
                                big_category:String,
                                mid_category:String,
                                type_name:String,
                                tag:String,
                                clue_type:String
                              )
