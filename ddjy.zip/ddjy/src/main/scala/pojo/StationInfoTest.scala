package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 11:08 2022/12/26
 */
case class StationInfoTest(
                            GRPID:String,
                            PID:String,
                            POIID:String,
                            srcId:String,
                            stationName:String,
                            province:String,
                            city:String,
                            adcode:String,
                            district:String,
                            addr:String,
                            lng:String,
                            lat:String,
                            cooperateStatus:String
                          )
