package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 17:39 2022/11/16
 */
case class BelongJoinStation(
                              agr_id:String,
                              agr_rs_id:String,
                              belong_name:String,
                              belong_x:String,
                              belong_y:String,
                              src:String,
                              unique_id:String,
                              stay_adcode:String,
                              stay_province:String,
                              stay_city:String,
                              stay_district:String,
                              task_batch:String,
                              poiid:String,
                              srcid:String,
                              grpid:String,
                              stationname:String,
                              province:String,
                              city:String,
                              district:String,
                              adcode:String,
                              addr:String,
                              lng:Double,
                              lat:Double,
                              querybrandid:Int,
                              management_model:Int,
                              gaslocationtype:Int,
                              roadname:String,
                              roadid:String,
                              roadclass:Int,
                              hasoilname:String,
                              businesshours:String,
                              tel:String,
                              headlabellist:String,
                              station_src:Int,
                              delflag:Int,
                              updatetime:String,
                              createtime:String,
                              ss:String,
                              swid:String,
                              cooperatestatus:String,
                              distance:String,
                              d_dist:String,
                              dist_rank:String,
                              inc_day:String,
                              clue_type:String
                            )
