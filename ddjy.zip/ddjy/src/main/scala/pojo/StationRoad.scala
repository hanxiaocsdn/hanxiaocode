package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 17:36 2022/12/21
 */
case class StationRoad(
                        GRPID:String,
                        PID:String,
                        POIID:String,
                        srcId:String,
                        stationName:String,
                        province:String,
                        city:String,
                        cityCode:String,
                        district:String,
                        addr:String,
                        lng:String,
                        lat:String,
                        cooperateStatus:String,
                        swid:String,
                        roadClass:String,
                        length:String,
                        FC:String,
                        formway:String,
                        geolinkpoint:String,
                        star_point:String,
                        end_point:String,
                        star_dist:String,
                        end_dist:String,
                        line_dist:String,
                        state:String,
                        buildTime:String,
                        update_time:String,
                        star_dist_back:String,
                        end_dist_back:String
                      )
