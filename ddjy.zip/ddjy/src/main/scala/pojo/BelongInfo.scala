package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 22:18 2022/11/15
 */
case class BelongInfo(
                      agr_id:String,
                      agr_rs_id:String,
                      belong_name:String,
                      belong_x:String,
                      belong_y:String,
                      src:String,
                      unique_id:String,
                      stay_adcode:String,
                      stay_province:String,
                      stay_city:String,
                      stay_district:String,
                      task_batch:String,
                      inc_day:String,
                      clue_type:String
                     )
