package pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 12:49 2022/11/23
 */
case class GasRank(
                    poiid:String,
                    ad_code:String,
                    province:String,
                    city:String,
                    district:String,
                    name_chn:String,
                    addr_chn:String,
                    x_coord:String,
                    y_coord:String,
                    telephone:String,
                    src:String,
                    start_dept:String,
                    task_batch:String,
                    dept_code:String,
                    dept_name:String,
                    dept_addr:String,
                    dept_type_name:String,
                    dept_transfer_flag:String,
                    area_name:String,
                    country_name:String,
                    city_name_new:String,
                    provinct_name:String,
                    belong_county:String,
                    longitude:String,
                    latitude:String,
                    delete_flg:String,
                    task_count:String,
                    carrier_count:String,
                    vehicle_count:String,
                    task_day_count:String,
                    plan_depart_tm_day_max:String,
                    plan_depart_tm_day_min:String,
                    dis_sum:String,
                    task_count_per_day:String,
                    dis_sum_per_day:String,
                    oil_sum:String,
                    oil_sum_per_day:String,
                    vehicle_load_count_distribution:String,
                    beeline_dist:String,
                    d_dist:String,
                    cooperate_status:String,
                    management_model:String,
                    querybrandid:String
                  )
