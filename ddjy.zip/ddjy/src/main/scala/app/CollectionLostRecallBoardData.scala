package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description流失召回明细表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:439
 * 任务名称：流失召回明细表
 * 依赖任务：每日-原始油站信息过滤表 512、订单支付时间重分区表 387 每日-车队历史充值记录表 498、车队账单报表 316、每日-原始车队信息过滤表 501
 * 数据源：ddjy_dwd_station_order_pay_repartition_di、ddjy_dim_station_info_filter、dm_ddjy_carrier_rlst_di、dm_ddjy_gas_station_rlst_di、ddjy_dim_team_info_filter、ddjy_dwd_car_team_history_recharge、dm_ddjy_team_account_report_di、
 * 调用服务地址：无
 * 数据结果：dwd_ddjy_station_team_pay_di、ddjy_lost_team_detail_di、ddjy_team_lost_recall_di
 */
object CollectionLostRecallBoardData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def dateStream(fromDt:LocalDate):Stream[LocalDate]={
    fromDt #::dateStream(fromDt.plusDays(1))
  }

  def teamProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_thirty_day:String) = {
    //计算车队和油站对应表
    val teamStationSql=
      s"""
        |select
        |t3.province_name,
        |nvl(area_name,t3.city_name) as area_name,
        |t3.city_name,
        |station_id,
        |car_team_id,
        |min_pay_time,
        |max_pay_time,
        |pay_cnt,
        |sum_oil_mass,
        |sum_ft_sale_money,
        |petrol_station_name as station_name
        |from
        |(
        |	select
        |	province_name,
        |	city_name,
        |	station_id,
        |	car_team_id,
        |	min_pay_time,
        |	max_pay_time,
        |	pay_cnt,
        |	sum_oil_mass,
        |	sum_ft_sale_money,petrol_station_name
        |	from
        |	(
        |		select
        |		station_id,
        |		car_team_id,
        |		min(pay_time) as min_pay_time,
        |		max(pay_time) as max_pay_time,
        |		count(*) as pay_cnt,
        |		sum(oil_mass) as sum_oil_mass,
        |		sum(ft_sale_money) as sum_ft_sale_money
        |		FROM dm_gis.ddjy_dwd_station_order_pay_repartition_di
        |		WHERE inc_day<='$inc_day'
        |		and order_status='2'
        |		group by station_id,car_team_id
        |	) t1
        |	left join
        |	(
        |		select
        |		petrol_station_name,province_name,
        |		city_name,
        |		id,
        |		substr(create_date,1,10) as create_day
        |		from dm_gis.ddjy_dim_station_info_filter
        |		where inc_day='$inc_day'
        |	) t2
        |	on t1.station_id=t2.id
        |) t3
        |left join dm_gis.dim_ddjy_city_area t4
        |on t3.city_name=t4.city_name
        |""".stripMargin
    val stationTeamDf: DataFrame = spark.sql(teamStationSql)
    stationTeamDf.repartition(1).createOrReplaceTempView("stationTeamTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_station_team_pay_di partition(inc_day='$inc_day') select * from stationTeamTmp")
    //平台top3油站和油站所在城市的订单量
    val top3StationSql=
      s"""
        |select
        |t2.car_team_id,
        |concat_ws(',',collect_set(concat(station_name,'-',pay_cnt))) as station_pay_cnt,
        |concat_ws(',',collect_set(concat(t2.city_name,'-',sum_pay_cnt))) as platform_area_pay_cnt
        |from
        |(
        |	select
        |	city_name,
        |	station_name,
        |	car_team_id,
        |	pay_cnt
        |	from dm_gis.dwd_ddjy_station_team_pay_di
        |	where inc_day='${inc_day}'
        |) t2
        |left join
        |(
        |	select
        |	city_name,car_team_id,
        |	sum(pay_cnt) as sum_pay_cnt
        |	from dm_gis.dwd_ddjy_station_team_pay_di
        |	where inc_day='${inc_day}'
        |	group by city_name,car_team_id
        |) t3
        |on t2.city_name=t3.city_name and t2.car_team_id=t3.car_team_id
        |group by t2.car_team_id
        |""".stripMargin
    val top3StationDf: DataFrame = spark.sql(top3StationSql)
    top3StationDf.createOrReplaceTempView("top3StationTmp")
    //城市目标加油站
    val targetStationSql=
      s"""
        |select
        |carrier_name,
        |concat_ws(',',collect_set(station_name)) as target_stations
        |from
        |(
        |	select
        |	carrier_name,
        |	split(gas_distribution_new,':')[0] as station_name
        |	from
        |	(
        |		select *
        |		from dm_gis.dm_ddjy_carrier_rlst_di
        |		where inc_day in(select max(inc_day) as maxDay
        |   from dm_gis.dm_ddjy_carrier_rlst_di)
        |	) t1
        |	lateral view explode(split(gas_distribution,'、')) tmp as gas_distribution_new
        |) t2
        |join
        |(
        |select
        |name
        |from dm_gis.dm_ddjy_gas_station_rlst_di
        |where inc_day in(select max(inc_day) as maxDay
        |from dm_gis.dm_ddjy_carrier_rlst_di) and cooperate_status=3
        |) t3
        |on t2.station_name=t3.name
        |group by carrier_name
        |""".stripMargin
    val targetStationDf: DataFrame = spark.sql(targetStationSql)
    targetStationDf.createOrReplaceTempView("targetStationTmp")
    //城市top3油站
    val areaTop3StationSql=
      s"""
        |select
        |city_name,
        |car_team_id,
        |concat_ws(',',collect_set(concat(station_name,'-',pay_cnt))) as station_pay_cnt
        |from
        |(
        |	select
        |	*
        |	from dm_gis.dwd_ddjy_station_team_pay_di
        |	where inc_day='${inc_day}'
        |) t1
        |group by city_name,car_team_id
        |""".stripMargin
    val areaTop3StationDf: DataFrame = spark.sql(areaTop3StationSql)
    areaTop3StationDf.createOrReplaceTempView("areaTop3StationTmp")
    //平台流失情况
    val platformLostSql=
      s"""
        |select
        |t1.car_team_id,min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,lost_tag,lost_time,
        |contact_name,contact_phone,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,
        |end_balance,recharge_frequency,lately_recharge_internal,avg_trade_internal,
        |station_pay_cnt,platform_area_pay_cnt
        |from
        |(
        |	select
        |	car_team_id,min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,lost_tag,lost_time,
        |	contact_name,contact_phone
        |	from
        |	(
        |		select
        |		car_team_id,
        |		min(min_pay_time) as min_pay_time,
        |		max(max_pay_time) as max_pay_time,
        |		sum(pay_cnt) as pay_cnt,
        |		sum(sum_oil_mass) as sum_oil_mass,
        |		sum(sum_ft_sale_money) as sum_ft_sale_money,
        |		sum(sum_ft_sale_money)/(datediff(substr(max(max_pay_time),0,10),substr(min(min_pay_time),0,10))+1) as avg_ft_sale_money,
        |		if(replace(substr(max(max_pay_time),0,10),'-','')<'$last_seven_day','平台流失',null) as lost_tag,
        |		if(replace(substr(max(max_pay_time),0,10),'-','')<'$last_seven_day',max(max_pay_time),null) as lost_time
        |		from dm_gis.dwd_ddjy_station_team_pay_di
        |		where inc_day='${inc_day}'
        |		group by car_team_id
        |	) a2
        |	left join
        |	(
        |		select
        |		id,contact_name,contact_phone
        |		from dm_gis.ddjy_dim_team_info_filter
        |		where inc_day='${inc_day}'
        |	) a3
        |	on a2.car_team_id=a3.id
        |) t1
        |left join
        |(
        |	select
        |	team_id,
        |	min(trade_time) as min_trade_time,
        |	max(trade_time) as max_trade_time,
        |	count(trade_time) as trade_cnt,
        |	sum(trade_amount) as sum_trade_amount,
        |	sum(trade_internal)/count(trade_internal) as avg_trade_internal
        |	from
        |	(
        |		select
        |		team_id,trade_time,trade_amount,
        |		datediff(substr((lead(trade_time) over(partition by team_id order by trade_time)),0,10),substr(trade_time,0,10)) as trade_internal
        |		from dm_gis.ddjy_dwd_car_team_history_recharge
        |		where inc_day<='${inc_day}'
        |		and trade_description='车队充值上账'
        |	) a4
        |	group by team_id
        |) t2
        |on t1.car_team_id=t2.team_id
        |left join
        |(
        |	select
        |	team_id,end_balance
        |	from dm_gis.dm_ddjy_team_account_report_di
        |	where inc_day='${inc_day}'
        |) t3
        |on t1.car_team_id=t3.team_id
        |left join
        |(
        |select
        |team_id,
        |datediff(from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd'),substr(max(trade_time),0,10)) as lately_recharge_internal,
        |count(trade_time) as recharge_frequency
        |from dm_gis.ddjy_dwd_car_team_history_recharge
        |where inc_day<='${inc_day}' and inc_day>='${last_thirty_day}'
        |and trade_description='车队充值上账'
        |group by team_id
        |) t8
        |on t1.car_team_id=t8.team_id
        |left join top3StationTmp t9
        |on t1.car_team_id=t9.car_team_id
        |""".stripMargin
    val platformLostDf: DataFrame = spark.sql(platformLostSql)
    platformLostDf.createOrReplaceTempView("platformLostTmp")
    //城市流失情况
    val areaLostSql=
      s"""
        |select
        |t1.city_name,t1.car_team_id,area_min_pay_time,area_max_pay_time,area_pay_cnt,area_sum_oil_mass,area_sum_ft_sale_money,area_avg_ft_sale_money,area_lost_tag,area_lost_time,
        |station_pay_cnt as area_station_pay_cnt,target_stations
        |from
        |(
        |	select
        |	city_name,car_team_id,area_min_pay_time,area_max_pay_time,area_pay_cnt,area_sum_oil_mass,area_sum_ft_sale_money,area_avg_ft_sale_money,area_lost_tag,area_lost_time,team_name
        |	from
        |	(
        |		select
        |		city_name,
        |		car_team_id,
        |		min(min_pay_time) as area_min_pay_time,
        |		max(max_pay_time) as area_max_pay_time,
        |		sum(pay_cnt) as area_pay_cnt,
        |		sum(sum_oil_mass) as area_sum_oil_mass,
        |		sum(sum_ft_sale_money) as area_sum_ft_sale_money,
        |		sum(sum_ft_sale_money)/(datediff(substr(max(max_pay_time),0,10),substr(min(min_pay_time),0,10))+1) as area_avg_ft_sale_money,
        |		if(replace(substr(max(max_pay_time),0,10),'-','')<'$last_seven_day','非平台流失',null) as area_lost_tag,
        |		if(replace(substr(max(max_pay_time),0,10),'-','')<'$last_seven_day',max(max_pay_time),null) as area_lost_time
        |		from dm_gis.dwd_ddjy_station_team_pay_di
        |		where inc_day='${inc_day}'
        |		group by car_team_id,city_name
        |	) a2
        |	left join
        |	(
        |		select
        |		id,name as team_name
        |		from dm_gis.ddjy_dim_team_info_filter
        |		where inc_day='${inc_day}'
        |	) a3
        |	on a2.car_team_id=a3.id
        |) t1
        |left join areaTop3StationTmp t2
        |on t1.car_team_id=t2.car_team_id and t1.city_name=t2.city_name
        |left join targetStationTmp t3
        |on t1.team_name=t3.carrier_name
        |""".stripMargin
    val areaLostDf: DataFrame = spark.sql(areaLostSql)
    areaLostDf.createOrReplaceTempView("areaLostTmp")
    //平台流失和城市流失关联
    val joinPlatformAreaLostSql=
      s"""
        |select
        |t1.car_team_id,contact_name,contact_phone,
        |'' as sign_sale,
        |'' as sign_area,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,
        |platform_area_pay_cnt as platform_city_pay_cnt,
        |nvl(lost_tag,area_lost_tag) as lost_tag,
        |nvl(lost_time,area_lost_time) as lost_time,
        |city_name,
        |area_min_pay_time as city_min_pay_time,
        |area_max_pay_time as city_max_pay_time,
        |area_pay_cnt as city_pay_cnt,
        |area_sum_oil_mass as city_sum_oil_mass,
        |area_sum_ft_sale_money as city_sum_ft_sale_money,
        |area_avg_ft_sale_money as city_avg_ft_sale_money,
        |area_station_pay_cnt as city_station_pay_cnt,
        |target_stations
        |from platformLostTmp t1
        |left join areaLostTmp t2
        |on t1.car_team_id=t2.car_team_id
        |""".stripMargin
    val lostTeamDetailDf: DataFrame = spark.sql(joinPlatformAreaLostSql)
    lostTeamDetailDf.repartition(1).createOrReplaceTempView("lostTeamDetailTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_lost_team_detail_di partition(inc_day='${inc_day}') select * from lostTeamDetailTmp")
    //当天城市订单情况
    val areaOrderSql=
      s"""
        |select
        |t3.city_name as city_name,
        |car_team_id,
        |min_pay_time,
        |petrol_station_name as station_name
        |from
        |(
        |	select
        |	city_name,
        |	station_id,
        |	car_team_id,
        |	min_pay_time,
        |	petrol_station_name
        |	from
        |	(
        |		select
        |		station_id,
        |		car_team_id,
        |		min(pay_time) as min_pay_time
        |		FROM dm_gis.ddjy_dwd_station_order_pay_repartition_di
        |		WHERE inc_day='$inc_day'
        |		and order_status='2'
        |		group by station_id,car_team_id
        |	) t1
        |	left join
        |	(
        |		select
        |		petrol_station_name,
        |		city_name,
        |		id
        |		from dm_gis.ddjy_dim_station_info_filter
        |		where inc_day='$inc_day'
        |	) t2
        |	on t1.station_id=t2.id
        |) t3
        |""".stripMargin
    val areaOrderDf: DataFrame = spark.sql(areaOrderSql)
    areaOrderDf.createOrReplaceTempView("areaOrderTmp")
    //昨日平台流失关联今日订单车队
    val beforePlatformLostJoinOrderSql=
      s"""
        |select
        |t1.car_team_id,
        |lost_tag,lost_time,
        |city_name,city_min_pay_time,city_max_pay_time,city_pay_cnt,city_sum_oil_mass,city_sum_ft_sale_money,city_avg_ft_sale_money,city_station_pay_cnt,target_stations,
        |if(t2.car_team_id is null,'否','是') as is_recall,
        |nvl(t2.petrol_station_name,'') as recall_station_name,
        |nvl(t2.recall_pay_time,'') as recall_pay_time,
        |datediff(substr(recall_pay_time,0,10),substr(lost_time,0,10)) as recall_period,
        |if(max_trade_time>lost_time,'是','否') as is_recharge
        |from
        |(
        |	select
        |	*
        |	from dm_gis.ddjy_lost_team_detail_di
        |	where inc_day='${before_yesterday}'
        |	and lost_tag ='平台流失'
        |) t1
        |left join
        |(
        |	select
        |	car_team_id,petrol_station_name,recall_pay_time
        |	from
        |	(
        |		select
        |		car_team_id,
        |		split(min(concat(pay_time,'\001',station_id)),'\001')[1] as station_id,
        |		min(pay_time) as recall_pay_time
        |		FROM dm_gis.ddjy_dwd_station_order_pay_repartition_di
        |		WHERE inc_day='$inc_day'
        |		and order_status='2'
        |		group by car_team_id
        |	) a1
        |	left join
        |	(
        |		select
        |		petrol_station_name,
        |		id
        |		from dm_gis.ddjy_dim_station_info_filter
        |		where inc_day='$inc_day'
        |	) a2
        |	on a1.station_id=a2.id
        |) t2
        |on t1.car_team_id=t2.car_team_id
        |""".stripMargin
    val beforePlatformLostJoinOrderDf: DataFrame = spark.sql(beforePlatformLostJoinOrderSql)
    beforePlatformLostJoinOrderDf.createOrReplaceTempView("beforePlatformLostJoinOrderTmp")
    //平台昨日流失今日召回和平台今日流失情况
    val platformRecallSql=
      s"""
        |select
        |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
        |t3.car_team_id,contact_name,contact_phone,sign_sale,sign_area,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,platform_city_pay_cnt,
        |t3.lost_tag,t3.lost_time,
        |t3.city_name,t3.city_min_pay_time,t3.city_max_pay_time,t3.city_pay_cnt,t3.city_sum_oil_mass,t3.city_sum_ft_sale_money,t3.city_avg_ft_sale_money,t3.city_station_pay_cnt,t3.target_stations,
        |is_recall,recall_station_name,recall_pay_time,recall_period,is_recharge,
        |'否' as is_close_cycle
        |from
        |(
        |	select *
        |	from beforePlatformLostJoinOrderTmp
        |	where is_recall='是'
        |) t3
        |left join
        |(
        |	select
        |	*
        |	from dm_gis.ddjy_lost_team_detail_di
        |	where inc_day='${inc_day}'
        |	and lost_tag is null
        |) t4
        |on t3.car_team_id=t4.car_team_id
        |union all
        |select
        |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
        |car_team_id,contact_name,contact_phone,sign_sale,sign_area,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,platform_city_pay_cnt,
        |lost_tag,lost_time,
        |city_name,city_min_pay_time,city_max_pay_time,city_pay_cnt,city_sum_oil_mass,city_sum_ft_sale_money,city_avg_ft_sale_money,city_station_pay_cnt,target_stations,
        |'否' as is_recall,
        |'' as recall_station_name,
        |'' as recall_pay_time,
        |'' as recall_period,
        |if(max_trade_time>lost_time,'是','否') as is_recharge,
        |'否' as is_close_cycle
        |from dm_gis.ddjy_lost_team_detail_di
        |where inc_day='${inc_day}'
        |and lost_tag ='平台流失'
        |""".stripMargin
    val platformRecallDf: DataFrame = spark.sql(platformRecallSql)
    platformRecallDf.createOrReplaceTempView("platformRecallTmp")
    //昨日城市流失关联今日订单车队数据
    val beforeAreaLostJoinOrderSql=
      s"""
        |select
        |t1.car_team_id,lost_tag,lost_time,
        |t1.city_name,city_min_pay_time,city_max_pay_time,city_pay_cnt,city_sum_oil_mass,city_sum_ft_sale_money,city_avg_ft_sale_money,city_station_pay_cnt,target_stations,
        |if(t2.car_team_id is null,'否','是') as is_recall,
        |nvl(t2.station_name,'') as recall_station_name,
        |nvl(t2.recall_pay_time,'') as recall_pay_time,
        |datediff(substr(recall_pay_time,0,10),substr(lost_time,0,10)) as recall_period,
        |if(max_trade_time>lost_time,'是','否') as is_recharge
        |from
        |(
        |	select
        |	*
        |	from dm_gis.ddjy_lost_team_detail_di
        |	where inc_day='${before_yesterday}'
        |	and lost_tag ='非平台流失'
        |) t1
        |left join
        |(
        |	select
        |	city_name,car_team_id,min_pay_time as recall_pay_time,station_name
        |	FROM areaOrderTmp
        |) t2
        |on t1.car_team_id=t2.car_team_id and t1.city_name=t2.city_name
        |""".stripMargin
    val beforeAreaLostJoinOrderDf: DataFrame = spark.sql(beforeAreaLostJoinOrderSql)
    beforeAreaLostJoinOrderDf.createOrReplaceTempView("beforeAreaLostJoinOrderTmp")
    //城市昨日流失今日召回和城市今日流失情况
    val areaRecallSql=
      s"""
        |select
        |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
        |t4.car_team_id,contact_name,contact_phone,sign_sale,sign_area,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,platform_city_pay_cnt,
        |t4.lost_tag,t4.lost_time,
        |t4.city_name,t4.city_min_pay_time,t4.city_max_pay_time,t4.city_pay_cnt,t4.city_sum_oil_mass,t4.city_sum_ft_sale_money,t4.city_avg_ft_sale_money,t4.city_station_pay_cnt,t4.target_stations,
        |is_recall,recall_station_name,recall_pay_time,recall_period,is_recharge,
        |'否' as is_close_cycle
        |from
        |(
        |	select *
        |	from beforeAreaLostJoinOrderTmp
        |	where is_recall='是'
        |) t4
        |left join
        |(
        |	select
        |	distinct car_team_id,contact_name,contact_phone,sign_sale,sign_area,
        |	min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |	min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,platform_city_pay_cnt
        |	from dm_gis.ddjy_lost_team_detail_di
        |	where inc_day='${inc_day}'
        |	and lost_tag is null
        |) t3
        |on t4.car_team_id=t3.car_team_id
        |union all
        |select
        |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
        |car_team_id,contact_name,contact_phone,sign_sale,sign_area,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,platform_city_pay_cnt,
        |lost_tag,lost_time,
        |city_name,city_min_pay_time,city_max_pay_time,city_pay_cnt,city_sum_oil_mass,city_sum_ft_sale_money,city_avg_ft_sale_money,city_station_pay_cnt,target_stations,
        |'否' as is_recall,
        |'' as recall_station_name,
        |'' as recall_pay_time,
        |'' as recall_period,
        |if(max_trade_time>lost_time,'是','否') as is_recharge,
        |'否' as is_close_cycle
        |from dm_gis.ddjy_lost_team_detail_di
        |where inc_day='${inc_day}'
        |and lost_tag ='非平台流失'
        |""".stripMargin
    val areaRecallDf: DataFrame = spark.sql(areaRecallSql)
    areaRecallDf.createOrReplaceTempView("areaRecallTmp")
    val recallSql=
      s"""
        |select
        |distinct `date`,
        |car_team_id,contact_name,contact_phone,sign_sale,sign_area as sign_city,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,platform_city_pay_cnt,
        |lost_tag,lost_time,
        |city_name,city_min_pay_time,city_max_pay_time,city_pay_cnt,city_sum_oil_mass,city_sum_ft_sale_money,city_avg_ft_sale_money,city_station_pay_cnt,target_stations,
        |is_recall,recall_station_name,recall_pay_time,recall_period,is_recharge,
        |is_close_cycle
        |from
        |(
        |select *
        |from platformRecallTmp
        |union all
        |select *
        |from areaRecallTmp
        |union all
        |select
        |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
        |car_team_id,contact_name,contact_phone,sign_sale,sign_city as sign_area,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,platform_city_pay_cnt,
        |lost_tag,lost_time,
        |city_name,city_min_pay_time,city_max_pay_time,city_pay_cnt,city_sum_oil_mass,city_sum_ft_sale_money,city_avg_ft_sale_money,city_station_pay_cnt,target_stations,
        |is_recall,recall_station_name,recall_pay_time,recall_period,is_recharge,
        |if(replace(substr(recall_pay_time,0,10),'-','')>'${last_seven_day}','否','是') as is_close_cycle
        |from dm_gis.ddjy_team_lost_recall_di
        |where inc_day='${before_yesterday}'
        |and is_recall='是'
        |union all
        |select
        |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
        |car_team_id,contact_name,contact_phone,sign_sale,sign_area,
        |min_trade_time,max_trade_time,trade_cnt,sum_trade_amount,end_balance,lately_recharge_internal,recharge_frequency,avg_trade_internal,
        |min_pay_time,max_pay_time,pay_cnt,sum_oil_mass,sum_ft_sale_money,avg_ft_sale_money,station_pay_cnt,platform_city_pay_cnt,
        |lost_tag,lost_time,
        |city_name,city_min_pay_time,city_max_pay_time,city_pay_cnt,city_sum_oil_mass,city_sum_ft_sale_money,city_avg_ft_sale_money,city_station_pay_cnt,target_stations,
        |'' as is_recall,
        |'' as recall_station_name,
        |'' as recall_pay_time,
        |'' as recall_period,
        |'' as is_recharge,
        |'' as is_close_cycle
        |from dm_gis.ddjy_lost_team_detail_di
        |where inc_day='${inc_day}'
        |and lost_tag is null or lost_tag=''
        |) t1
        |""".stripMargin
    val teamLostRecallDf: DataFrame = spark.sql(recallSql)
    teamLostRecallDf.repartition(1).createOrReplaceTempView("teamLostRecallTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_team_lost_recall_di partition(inc_day='${inc_day}') select * from teamLostRecallTmp")
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    var before_yesterday=""
    var last_seven_day: String=""
    var last_thirty_day: String=""
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      before_yesterday = DateUtil.getDateStr(incDay, -1, "")
      last_seven_day = DateUtil.getDateStr(incDay, -6, "")
      last_thirty_day = DateUtil.getDateStr(incDay, -30, "")
      teamProcess(spark,incDay,before_yesterday,last_seven_day,last_thirty_day)
      logger.error("写入ddjy_team_lost_recall_di每日成功，日期为："+incDay)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>流失召回车队明细表 Execute Ok")
  }

}
