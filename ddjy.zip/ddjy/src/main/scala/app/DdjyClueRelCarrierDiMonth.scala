package app

import com.sf.gis.scala.base.spark.Spark
import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.{DateUtil, SparkUtils}
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import  org.apache.hadoop.mapreduce.lib.input.CombineFileInputFormat

/**
 *需求名称：GIS-RSS-DDJY：【吨吨加油】聚合线索工艺需求_V1.2_01405644_李相志 月维度集散地关联车队月度数据
 *需求方：周韵筹(01425211)
 *研发： 蔡国房(01420395)
 *任务创建时间：20240129
 *任务id：衡度平台 由原来的sql转成spark任务 1159
 **/
object DdjyClueRelCarrierDiMonth extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取T-1日期
    val inc_day: String = args(0)
    //取T-14日期,
    val last_day = DateUtil.getdaysBefore(inc_day,-6,"yyyyMMdd" ,"yyyyMMdd")

    val last_thrity_day = DateUtil.getdaysBefore(inc_day,-35,"yyyyMMdd" ,"yyyyMMdd")

    val tableName  = "dm_gis.dm_ddjy_clue_rel_carrier_di_month"


    val sourceSql =
      s"""
         |select
         |	clue_id,carrier_id,clue_name,carrier_name,province,city,district,adcode,active_status,clue_src,
         |	task_count,task_day_count,plan_depart_tm_day_max,plan_depart_tm_day_min,dis_sum,oil_sum,circle_id,center_x,center_y,biz_day
         |	from
         |	(
         |		select
         |		clue_id,carrier_id,clue_name,carrier_name,province,city,district,adcode,active_status,clue_src,
         |		sum(task_count) over(partition by clue_id,carrier_id) as task_count,
         |		sum(task_day_count) over(partition by clue_id,carrier_id) as task_day_count,
         |		if(clue_src='1','',max(plan_depart_tm_day_max) over(partition by clue_id,carrier_id)) as plan_depart_tm_day_max,
         |		if(clue_src='1','',min(plan_depart_tm_day_min) over(partition by clue_id,carrier_id)) as plan_depart_tm_day_min,
         |		if(clue_src='1','',sum(dis_sum) over(partition by clue_id,carrier_id)) as dis_sum,
         |		sum(oil_sum) over(partition by clue_id,carrier_id) as oil_sum,
         |		row_number() over(partition by clue_id,carrier_id order by inc_day desc) as rnk,circle_id,center_x,center_y,inc_day as biz_day
         |		from dm_gis.dm_ddjy_clue_rel_carrier_di
         |		where inc_day>='${last_thrity_day}' and inc_day<='${last_day}'
         |	) t1
         |	where rnk=1
         |""".stripMargin

    val sourceDF = spark.sql(sourceSql)

    logger.error(sourceSql)

    logger.error(sourceDF.count())

    sourceDF.persist(StorageLevel.MEMORY_AND_DISK)

    val dm_ddjy_clue_rel_car_di_sql  =
      s"""
         |
         |select
         |	clue_id,carrier_id,
         |	count(distinct vehicle) as vehicle_count
         |	from dm_gis.dm_ddjy_clue_rel_car_di
         |	where inc_day>='${last_thrity_day}' and inc_day<='${last_day}'
         |	group by clue_id,carrier_id
         |
         |""".stripMargin



    val  dm_ddjy_clue_rel_car_di_df = spark.sql(dm_ddjy_clue_rel_car_di_sql)
    dm_ddjy_clue_rel_car_di_df.persist(StorageLevel.MEMORY_AND_DISK)



    val  eta_std_line_recall1_sql=
      s"""
         |
         |				select
         |				start_dept,carrier_name,actual_capacity_load,
         |				vehicle_serial_cnt,
         |				sum(vehicle_serial_cnt) over(partition by start_dept,carrier_name) as vehicle_serial_sum
         |				from
         |				(
         |					select
         |					start_dept,carrier_name,
         |					actual_capacity_load,
         |					count(distinct vehicle_serial) as vehicle_serial_cnt
         |					from dm_gis.eta_std_line_recall1
         |					where inc_day>='${last_thrity_day}' and inc_day<='${last_day}'
         |					and plan_depart_tm>='${last_thrity_day}' and plan_depart_tm<='${last_day}'
         |					group by start_dept,carrier_name,actual_capacity_load
         |				) t5
         |
         |
         |""".stripMargin


    logger.error(eta_std_line_recall1_sql)

    val  eta_std_line_recall1_df = spark.sql(eta_std_line_recall1_sql)

    eta_std_line_recall1_df.persist(StorageLevel.MEMORY_AND_DISK)


    import spark.implicits._


    val eta_std_line_recall1_df1 = eta_std_line_recall1_df.repartition(2000)
      .withColumn("vehicle_load_count_distribution", concat(round('vehicle_serial_cnt*100/'vehicle_serial_sum,2),lit("%")))
      .orderBy('start_dept,'carrier_name,desc("vehicle_serial_cnt"))

    //partition by start_dept,carrier_name order by vehicle_serial_cnt desc 聚合操作
    val eta_std_line_recall1_df2 =  eta_std_line_recall1_df1.map(row  => {
      val  start_dept = row.getAs[String]("start_dept")
      val  carrier_name = row.getAs[String]("carrier_name")
      val  vehicle_load_count_distribution = row.getAs[String]("vehicle_load_count_distribution")
      val vehicle_serial_cnt  = row.getAs[Long]("vehicle_serial_cnt")

      val key = start_dept + "_" + carrier_name
      (key,(start_dept,carrier_name,vehicle_load_count_distribution,vehicle_serial_cnt))
    }).rdd.reduceByKey((x,y)=>{
      val vehicle_serial_cnt_x =   x._4
      val vehicle_serial_cnt_y =   y._4
      val vehicle_load_count_distribution_x =   x._3
      val vehicle_load_count_distribution_y =   y._3
      val start_dept  = x._1
      val carrier_name = x._2

      var vehicle_load_count_distribution_values =""
      if(vehicle_serial_cnt_x>vehicle_serial_cnt_y){
        vehicle_load_count_distribution_values = vehicle_load_count_distribution_x+","+vehicle_load_count_distribution_y
      }else{
        vehicle_load_count_distribution_values = vehicle_load_count_distribution_y +","+vehicle_load_count_distribution_x
      }
      (start_dept, carrier_name,vehicle_load_count_distribution_values, vehicle_serial_cnt_x)
    }).map(row  => row._2)
      .toDF("start_dept", "carrier_name","vehicle_load_count_distribution", "vehicle_serial_cnt").drop("vehicle_serial_cnt")
      .distinct()

    eta_std_line_recall1_df2.show(1,false)

    eta_std_line_recall1_df1.persist(StorageLevel.MEMORY_AND_DISK)
    val dm_ddjy_cluepoint_rlst_di_month_sql=
      s"""
         |
         |select circle_id,center_x,center_y,clue_id from  dm_gis.dm_ddjy_cluepoint_rlst_di_month  where inc_day='${last_day}'
         |
         |""".stripMargin
    val  dm_ddjy_cluepoint_rlst_di_month_df = spark.sql(dm_ddjy_cluepoint_rlst_di_month_sql)

    dm_ddjy_cluepoint_rlst_di_month_df.persist(StorageLevel.MEMORY_AND_DISK)

    val  dm_ddjy_clue_rel_carrier_di_max_sql=
      s"""
         |
         |	select
         |	substr (max(task_batch), 10,17) as max_task_batch,
         |	substr (min(task_batch), 0,8) as min_task_batch
         |	from  dm_gis.dm_ddjy_clue_rel_carrier_di
         |	where inc_day>='${last_thrity_day}' and inc_day<='${last_day}'
         |
         |""".stripMargin

    val  dm_ddjy_clue_rel_carrier_di_max_df = spark.sql(dm_ddjy_clue_rel_carrier_di_max_sql)

    val  max_task_batch  = dm_ddjy_clue_rel_carrier_di_max_df.collect()(0).getAs[String]("max_task_batch")
    val  min_task_batch  = dm_ddjy_clue_rel_carrier_di_max_df.collect()(0).getAs[String]("min_task_batch")



    val resultDF =  sourceDF.join(dm_ddjy_clue_rel_car_di_df,Seq("clue_id","carrier_id"),"left")
      .join(eta_std_line_recall1_df2,sourceDF("clue_id")=== eta_std_line_recall1_df2("start_dept") && sourceDF("carrier_name")=== eta_std_line_recall1_df2("carrier_name"),"left")
      .join(dm_ddjy_cluepoint_rlst_di_month_df,Seq("clue_id"),"left")
      .withColumn("max_task_batch",lit(max_task_batch))
      .withColumn("min_task_batch",lit(min_task_batch))
      .drop(eta_std_line_recall1_df2("carrier_name"))
      .drop(sourceDF("circle_id"))
      .drop(sourceDF("center_x"))
      .drop(sourceDF("center_y"))


    resultDF.show(1, false)

    logger.error("数据量 " +  resultDF.count())

    resultDF.persist(StorageLevel.MEMORY_AND_DISK)

   val resultDF1 =  resultDF.withColumn("task_batch", concat('min_task_batch,lit("-"),'max_task_batch))
      .withColumn("task_count_per_day", when(round('task_count/'task_day_count,0)===0,1).otherwise(round('task_count/'task_day_count,0)))
      .withColumn("dis_sum_per_day", when('clue_src==="1","").otherwise('dis_sum/'task_day_count))
      .withColumn("update_time", lit(from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss")))
     .withColumn("oil_sum_per_day", 'oil_sum/'task_day_count)
      .select('clue_id
        ,'carrier_id
        ,'task_batch
        ,'clue_name
        ,'carrier_name
        ,'province
        ,'city
        ,'district
        ,'adcode
        ,'task_count
        ,'vehicle_count
        ,'task_day_count
        ,'plan_depart_tm_day_max
        ,'plan_depart_tm_day_min
        ,'dis_sum
        ,'task_count_per_day
        ,'dis_sum_per_day
        ,'oil_sum
        ,'oil_sum_per_day
        ,'vehicle_load_count_distribution
        ,'active_status
        ,'clue_src
        ,'update_time
        ,'circle_id
        ,'center_x
        ,'center_y
        ,'biz_day
      ).withColumn("inc_day",lit(last_day))
    //数据存dm表

    resultDF1.show(1, false)
    writeToHive(spark, resultDF1, Seq("inc_day"), tableName)

  }



}
