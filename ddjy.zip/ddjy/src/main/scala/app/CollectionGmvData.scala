package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:累计gmv报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:374
 * 任务名称：油站累计gmv报表
 * 依赖任务：吨吨加油-订单过滤明细表去重 352、每日-原始油站信息过滤表 512
 * 数据源：ddjy_dwd_station_order_repartition_di、ddjy_dim_station_info_filter
 * 调用服务地址：无
 * 数据结果：dm_ddjy_uimp_station_gmv_report_di
 */
object CollectionGmvData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def dateStream(fromDt:LocalDate):Stream[LocalDate]={
    fromDt #::dateStream(fromDt.plusDays(1))
  }

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String) = {
    val stationGmvDf: DataFrame = spark.sql(
      s"""
         |select
         |province_name,
         |city_name,
         |id as station_id,
         |create_day,
         |(datediff(from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd'),create_day) +1) as online_count,
         |round(aggr_ft_sale_money,2) as aggr_ft_sale_money,
         |round(aggr_ft_sale_money/(datediff(from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd'),create_day) +1),2) as avg_ft_sale_money,
         |car_team_count,
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`
         |from
         |(
         |	select
         |	station_id,
         |	count(distinct car_team_id) as car_team_count,
         |	sum(ft_sale_money) as aggr_ft_sale_money
         |	FROM dm_gis.ddjy_dwd_station_order_repartition_di
         |	WHERE inc_day<='${inc_day}'
         |	and order_status='2'
         |	group by station_id
         |) t1
         |left join
         |(
         |	select
         |	petrol_station_name,
         |	province_name,
         |	city_name,
         |	id,
         |	substr(create_date,1,10) as create_day
         |	from dm_gis.ddjy_dim_station_info_filter
         |	where inc_day='$inc_day'
         |) t3
         |on t1.station_id=t3.id
         |""".stripMargin)
    stationGmvDf.repartition(1).createOrReplaceTempView("stationGmvTmp")
    spark.sql(s"insert overwrite table dm_gis.dm_ddjy_uimp_station_gmv_report_di partition(inc_day='${inc_day}') select * from stationGmvTmp")
    logger.error("写入dm_ddjy_uimp_station_gmv_report_di每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    var before_yesterday=""
    var last_seven_day: String=""
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      before_yesterday = DateUtil.getDateStr(incDay, -1, "")
      last_seven_day = DateUtil.getDateStr(incDay, -6, "")
      stationProcess(spark,incDay,before_yesterday,last_seven_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>累计gmv Execute Ok")
  }

}
