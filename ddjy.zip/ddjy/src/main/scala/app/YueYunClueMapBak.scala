package app

import java.util

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DistanceUtils}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import pojo._
import utils.SfNetInteface

import scala.collection.JavaConversions._
import scala.util.control.Breaks

/**
 * @Description:粤运线索地图
 * 需求人员：矫悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 18:40 2022/11/14
 * 任务id:259
 * 任务名称：粤运线索地图
 * 依赖任务：粤运集散地关联车队表 258
 * 数据源：single_agr_stat_all_drop_owner_tmp
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0
 *             http://gis-int.int.sfdc.com.cn:1080/rgeo/api?x=%s&y=%s&opt=sf1&ak=%s
 *             http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s
 *             http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/StationClusterRect?
 * 数据结果：dwd_ddjy_cantonese_station_clue_di、dwd_ddjy_cantonese_clue_info_di、dwd_ddjy_cantonese_carrier_clue_di、dwd_ddjy_cantonese_carrier_vehicle_di、dwd_ddjy_clue_circle_rslt_di、dwd_ddjy_clue_circle_seed、dwd_ddjy_cantonese_clue_seed_info_test、dwd_ddjy_cantonese_clue_gas_seed_info
 */
object YueYunClueMapBak {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readDropOwnerData(spark: SparkSession, incDay: String) = {

    val singleAgrSql=
      s"""
        |select *
        |from dm_gis.single_agr_stat_all_drop_owner_tmp
        |where inc_day='$incDay'
        |""".stripMargin
    val dropOwnerDf: DataFrame = spark.sql(singleAgrSql)
    val dropOwnerRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, dropOwnerDf).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dropOwner表数据量："+dropOwnerRdd.count())
    dropOwnerRdd
  }
  def readAoiNotKeyData(spark: SparkSession, incDay: String) = {
    val aoiNotKeySql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_aoi_not_key_di
         |--limit 10000
         |""".stripMargin
    val aoiNotKeyDf: DataFrame = spark.sql(aoiNotKeySql)
    aoiNotKeyDf
  }

  def aoiNotKeyPoiInterface(spark: SparkSession, aoiNotKeyDf: DataFrame, incDay: String) = {
    import spark.implicits._
    val aoiNotKeyMapRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, aoiNotKeyDf).map(obj => {
      (obj.getString("agr_rs_id"), obj)
    })
    val aoiNotKeyRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, aoiNotKeyDf)
      .groupBy(_.getString("agr_rs_id")).map(obj=>{
      val list: List[JSONObject] = obj._2.toList
      val agr_lng_sum: Double = list.map(_.getDoubleValue("agr_lng")).sum
      val agr_lat_sum: Double = list.map(_.getDoubleValue("agr_lat")).sum
      val agr_lng_avg: Double = agr_lng_sum / (list.size)
      val agr_lat_avg: Double = agr_lat_sum / (list.size)
      val tmpObj: JSONObject = list.minBy(_.getString("agr_id"))
      val newObj = new JSONObject()
      newObj.put("agr_rs_id",tmpObj.getString("agr_rs_id"))
      newObj.put("agr_lng",agr_lng_avg)
      newObj.put("agr_lat",agr_lat_avg)
      newObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调poi接口的数据量:"+aoiNotKeyRdd.count())
    val httpGeoPoi= BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "577", "粤运线索地图", "获取adcode信息", "http://gis-int.int.sfdc.com.cn:1080/rgeo/api?x=%s&y=%s&opt=sf1&ak=%s", "85874304df9d44fc9752a62b63453b30", aoiNotKeyRdd.count(), 50)

    val returnPoiRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,aoiNotKeyRdd, SfNetInteface.geoPoiInterface, 50, "85874304df9d44fc9752a62b63453b30", 20000)
    //returnPoiRdd.take(10).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpGeoPoi)

    val poiInterfaceRdd: RDD[JSONObject] = returnPoiRdd.repartition(600).flatMap(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val stay_adcode: String = result.getString("adcode")
      val stay_province: String = result.getString("province")
      val stay_city: String = result.getString("city")
      val stay_district: String = result.getString("district")
      val pois: JSONArray = JSONUtil.getJsonArrayMulti(result, "pois")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until (pois.size())) {
        val tmpObj = new JSONObject()
        val poisObj: JSONObject = pois.getJSONObject(i)
        val poi_name: String = JSONUtil.getJsonValSingle(poisObj, "name")
        val poi_addr: String = JSONUtil.getJsonValSingle(poisObj, "addr")
        val poi_x: String = JSONUtil.getJsonValSingle(poisObj, "x")
        val poi_y: String = JSONUtil.getJsonValSingle(poisObj, "y")
        val poi_distance: String = JSONUtil.getJsonValSingle(poisObj, "distance")
        val poi_type: String = JSONUtil.getJsonValSingle(poisObj, "type")
        tmpObj.fluentPutAll(obj)
        tmpObj.put("poi_name", poi_name)
        tmpObj.put("poi_addr", poi_addr)
        tmpObj.put("poi_x", poi_x)
        tmpObj.put("poi_y", poi_y)
        tmpObj.put("poi_distance", poi_distance)
        tmpObj.put("poi_type", poi_type)
        tmpObj.put("stay_adcode", stay_adcode)
        if (StringUtils.isNoneEmpty(stay_province)){
          tmpObj.put("stay_province", stay_province)
        }
        if (StringUtils.isNoneEmpty(stay_city)){
          tmpObj.put("stay_city", stay_city)
        }
        if (StringUtils.isNoneEmpty(stay_district)){
          tmpObj.put("stay_district", stay_district)
        }
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    }).filter(obj=>{
      obj.getDouble("poi_distance")<=500
    }).map(obj=>{
      (obj.getString("agr_rs_id"), obj)
    }).join(aoiNotKeyMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.remove("agr_lng")
      leftObj.remove("agr_lat")
      rightObj.fluentPutAll(leftObj)
      rightObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取poi接口返回数据量："+poiInterfaceRdd.count())
    val poiInterfaceDf: DataFrame = poiInterfaceRdd.map(obj => {
      AoiNotKeyPoiInterface(
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("fatype"),
        obj.getString("aoicode"),
        obj.getString("znocode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("is_logistics"),
        obj.getString("distribute_passpoint"),
        obj.getString("big_category"),
        obj.getString("mid_category"),
        obj.getString("type_name"),
        obj.getString("poi_name"),
        obj.getString("poi_addr"),
        obj.getString("poi_x"),
        obj.getString("poi_y"),
        obj.getString("poi_distance"),
        obj.getString("poi_type"),
        "",//clue_type
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调poi接口返回数据量："+poiInterfaceDf.count())
    poiInterfaceDf.createOrReplaceTempView("poiInterfaceTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_aoi_not_key_poi_di select * from poiInterfaceTmp")
    poiInterfaceRdd.unpersist()
    poiInterfaceDf.unpersist()
  }

  def readAoiNotKeyPoiData(spark: SparkSession, incDay: String) = {
    val aoiNotKeyPoiSql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_aoi_not_key_poi_di
         |""".stripMargin
    val aoiNotKeyPoiDf: DataFrame = spark.sql(aoiNotKeyPoiSql)
    aoiNotKeyPoiDf
  }

  def poiRecall(poiKeyInAoiRdd:RDD[JSONObject],poiNotKeyInAoiRdd:RDD[JSONObject],poiNotKeyNotInAoiRdd:RDD[JSONObject]) = {
    val poiKeyInAoiMapRdd: RDD[(String, JSONObject)] = poiKeyInAoiRdd.map(obj => {
      (obj.getString("id"), obj)
    })
    val poiNotKeyInAoiRecallRdd: RDD[JSONObject] = poiNotKeyInAoiRdd.map(obj => {
      (obj.getString("id"), obj)
    }).join(poiKeyInAoiMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      val agr_lng: Double = leftObj.getDoubleValue("agr_lng")
      val agr_lat: Double = leftObj.getDoubleValue("agr_lat")
      val poi_x_inAOI: Double = rightObj.getDoubleValue("poi_x_inAOI")
      val poi_y_inAOI: Double = rightObj.getDoubleValue("poi_y_inAOI")
      val poi_distance_inAOI: Double = DistanceUtils.getDistance(agr_lng, agr_lat, poi_x_inAOI, poi_y_inAOI)
      val poi_name_inAOI: String = rightObj.getString("poi_name_inAOI")
      val poi_addr_inAOI: String = rightObj.getString("poi_addr_inAOI")
      val poi_type_inAOI: String = rightObj.getString("poi_type_inAOI")
      leftObj.put("poi_distance_inAOI", poi_distance_inAOI)
      leftObj.put("poi_name", poi_name_inAOI)
      leftObj.put("poi_addr", poi_addr_inAOI)
      leftObj.put("poi_x", poi_x_inAOI)
      leftObj.put("poi_y", poi_y_inAOI)
      leftObj.put("poi_type", poi_type_inAOI)
      leftObj
    }).groupBy(_.getString("agr_id"))
      .map(obj => {
        obj._2.toList.minBy(json => {
          JSONUtil.getJsonDouble(json, "poi_distance_inAOI", Int.MaxValue)
        })
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("poiRecall内部poiNotKeyInAoiRecallRdd:"+poiNotKeyInAoiRecallRdd.count())
    val poiNotKeyInAoiRecallMapRdd: RDD[(String, JSONObject)] = poiNotKeyInAoiRecallRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    })
    val poiNotKeyInAoiNotRecallRdd: RDD[JSONObject] = poiNotKeyInAoiRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    }).leftOuterJoin(poiNotKeyInAoiRecallMapRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj == null
    }).map(obj => {
      obj._2._1
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("poiRecall内部poiNotKeyInAoiNotRecallRdd:"+poiNotKeyInAoiNotRecallRdd.count())
    val value: RDD[JSONObject] = poiNotKeyNotInAoiRdd.map(obj => {
      (obj.getString("id"), obj)
    }).join(poiKeyInAoiMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      val agr_lng: Double = leftObj.getDoubleValue("agr_lng")
      val agr_lat: Double = leftObj.getDoubleValue("agr_lat")
      val poi_x_inAOI: Double = rightObj.getDoubleValue("poi_x_inAOI")
      val poi_y_inAOI: Double = rightObj.getDoubleValue("poi_y_inAOI")
      val poi_distance_inAOI: Double = DistanceUtils.getDistance(agr_lng, agr_lat, poi_x_inAOI, poi_y_inAOI)
      val poi_name_inAOI: String = rightObj.getString("poi_name_inAOI")
      val poi_addr_inAOI: String = rightObj.getString("poi_addr_inAOI")
      val poi_type_inAOI: String = rightObj.getString("poi_type_inAOI")
      leftObj.put("poi_distance_inAOI", poi_distance_inAOI)
      leftObj.put("poi_name", poi_name_inAOI)
      leftObj.put("poi_addr", poi_addr_inAOI)
      leftObj.put("poi_x", poi_x_inAOI)
      leftObj.put("poi_y", poi_y_inAOI)
      leftObj.put("poi_type", poi_type_inAOI)
      leftObj
    })
    val poi_distance_inAOI_sum: Double = value.map(_.getDoubleValue("poi_distance_inAOI")).sum()
    val poi_distance_inAOI_cnt: Double = value.map(_.getDoubleValue("poi_distance_inAOI")).count()
    val poi_distance_inAOI_avg: Double = poi_distance_inAOI_sum / poi_distance_inAOI_cnt
    val value1: RDD[JSONObject] = value.map(obj => {
      obj.put("poi_distance_inAOI_avg", poi_distance_inAOI_avg)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("value1:"+value1.count())
    value1.take(10).foreach(println(_))
    val poiNotKeyNotInAoiRecallRdd: RDD[JSONObject] = value1.filter(obj => {
      val poi_distance_inAOI: Double = obj.getDoubleValue("poi_distance_inAOI")
      val poi_distance_inAOI_avg: Double = obj.getDoubleValue("poi_distance_inAOI_avg")
      poi_distance_inAOI <= poi_distance_inAOI_avg
    }).groupBy(_.getString("agr_id"))
      .map(obj => {
        obj._2.toList.minBy(json => {
          JSONUtil.getJsonDouble(json, "poi_distance_inAOI", Int.MaxValue)
        })
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("poiRecall内部poiNotKeyNotInAoiRecallRdd:"+poiNotKeyNotInAoiRecallRdd.count())
    val poiNotKeyNotInAoiRecallMapRdd: RDD[(String, JSONObject)] = poiNotKeyNotInAoiRecallRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    })
    val poiNotKeyNotInAoiNotRecallRdd: RDD[JSONObject] = poiNotKeyNotInAoiRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    }).leftOuterJoin(poiNotKeyNotInAoiRecallMapRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj == null
    }).map(obj => {
      obj._2._1
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("poiRecall内部poiNotKeyNotInAoiNotRecallRdd:"+poiNotKeyNotInAoiNotRecallRdd.count())
    (poiNotKeyInAoiRecallRdd,poiNotKeyInAoiNotRecallRdd,poiNotKeyNotInAoiRecallRdd,poiNotKeyNotInAoiNotRecallRdd)
  }

  def processPoiData(spark: SparkSession, poiInterfaceDf: DataFrame, incDay: String) = {
    import spark.implicits._
    //获取POI重点集散地数据，非重点数据向重点数据聚合
    val poiInterfaceRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, poiInterfaceDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val poi_name_str="油站|服务区|中国石化|中国石油|壳牌|美孚|加德士|东方|碧辟|道达尔|埃索|道达尔|中化|中石油|中油|BP|TOTAL|混凝土|水泥|沥青|家居|石膏|定制|供应链|沙场|石场|纺织|铝业|橡胶|机械|酒厂|啤酒|油站|服务区|石场|钢铁|矿业|木业|石化|塑料|金属|纺织|工业|塑胶|陶瓷|玻璃|材料|纸|五金|钢材|不锈钢|公司|家具|电器|家电|建材|市场|酒业|化肥|批发|钢贸|开发区|创业园|商贸园|科贸园|开发区|处理厂|厂区|厂房|工业园|工业区|工业城|产业园|科技园|研究院|基地|工业|工厂|厂|园区|中心|集团|分销中心|菜鸟|冷库|电商|电子商务|仓储|邮局|物流|货运|运输|快递|中转|集散点|分拨|分拨中心|韵达|申通|顺丰|中通|圆通|德邦|邮政|EMS|ems|京东|百世|龙邦|国通|龙邦|极兔|快递|大件|货场|仓库|工艺|集团|码头|口岸|口岸|港口|保税|港区|卸货|货运站|车站|南站|北站|西站|东站|客运站|火车站|机场|花园|花卉场|花场|农场|农田|牧场|菜场|菜园|菜地|养殖场|蔬菜基地|果业|果园|菜地|养鸡场|鱼塘|林场|渔场|猪场|果场|工地|项目部|项目分部|工程建设"
    val poi_name_list: Array[String] = poi_name_str.split("\\|")
    val poiKeyRdd: RDD[JSONObject] = poiInterfaceRdd.filter(obj => {
      val poi_name: String = obj.getString("poi_name")
      val nameLoop = new Breaks
      var name_bool = false
      nameLoop.breakable {
        for (k <- poi_name_list.indices) {
          val name_key: String = poi_name_list(k)
          if (poi_name.contains(name_key)) {
            name_bool = true
            nameLoop.break()
          }
        }
      }
      val poi_type_str="道路附属设施;服务区;高速服务区,道路附属设施;服务区;高速加油站服务区,道路附属设施;收费站;收费站,地名地址信息;地名地址信息;地名地址信息,地名地址信息;交通地名;桥,地名地址信息;普通地名;乡镇级地名,风景名胜;风景名胜;风景名胜,风景名胜;风景名胜相关;旅游景点,风景名胜;公园广场;城市广场,风景名胜;公园广场;公园,风景名胜;公园广场;植物园,公司企业;公司;公司,公司企业;公司企业;公司企业,公司企业;农林牧渔基地;其它农林牧渔基地,公司企业;知名企业;知名企业,购物服务;便民商店/便利店;便民商店/便利店,购物服务;超级市场;超市,购物服务;服装鞋帽皮具店;服装鞋帽皮具店,购物服务;购物相关场所;购物相关场所,购物服务;花鸟鱼虫市场;花卉市场,购物服务;花鸟鱼虫市场;花鸟鱼虫市场,购物服务;家电电子卖场;家电电子卖场,购物服务;家电电子卖场;数码电子,购物服务;家电电子卖场;综合家电商场,购物服务;家居建材市场;布艺市场,购物服务;家居建材市场;厨卫市场,购物服务;家居建材市场;灯具瓷器市场,购物服务;家居建材市场;家居建材市场,购物服务;家居建材市场;家具城,购物服务;家居建材市场;建材五金市场,购物服务;商场;商场,购物服务;特色商业街;步行街,购物服务;特色商业街;特色商业街,购物服务;体育用品店;体育用品店,购物服务;文化用品店;文化用品店,购物服务;专卖店;宠物用品店,购物服务;专卖店;烟酒专卖店,购物服务;专卖店;专营店,购物服务;综合市场;旧货市场,购物服务;综合市场;农副产品市场,购物服务;综合市场;蔬菜市场,购物服务;综合市场;小商品市场,购物服务;综合市场;综合市场,交通设施服务;地铁站;地铁站,交通设施服务;港口码头;港口码头,交通设施服务;火车站;火车站,交通设施服务;交通服务相关;交通服务相关,交通设施服务;停车场;停车场相关,交通设施服务;长途汽车站;长途汽车站,汽车服务;充电站;充电站,汽车服务;二手车交易;二手车交易,汽车服务;加油站;加德士,汽车服务;加油站;加油站,汽车服务;加油站;壳牌,汽车服务;加油站;中国石化,汽车服务;加油站;中国石油,汽车服务;加油站;中石油碧辟,汽车服务;汽车服务相关;汽车服务相关,汽车服务;汽车配件销售;汽车配件销售,汽车服务;汽车养护/装饰;汽车养护,汽车服务;汽车租赁;汽车租赁,汽车服务;洗车场;洗车场,汽车维修;汽车维修;汽车维修,汽车销售;奥迪特约销售;奥迪销售,汽车销售;大众特约销售;兰博基尼销售,汽车销售;东风特约销售;东风销售,汽车销售;丰田特约销售;一汽丰田销售,汽车销售;江淮销售;江淮销售,汽车销售;梅赛德斯-奔驰特约销售;梅赛德斯-奔驰销售,汽车销售;汽车销售;汽车销售,汽车销售;通用特约销售;别克销售,汽车销售;通用特约销售;凯迪拉克销售,商务住宅;产业园区;产业园区,商务住宅;楼宇;工业大厦建筑物,商务住宅;楼宇;楼宇相关,商务住宅;楼宇;商务写字楼,商务住宅;楼宇;商住两用楼宇,商务住宅;商务住宅相关;商务住宅相关,生活服务;物流速递;物流速递"
      val poi_type_list: Array[String] = poi_type_str.split(",")
      val poi_type: String = obj.getString("poi_type")
      val poiTypeLoop = new Breaks
      var type_bool = false
      poiTypeLoop.breakable {
        for (k <- poi_type_list.indices) {
          val poi_type_key: String = poi_type_list(k)
          if (poi_type.contains(poi_type_key)) {
            type_bool = true
            poiTypeLoop.break()
          }
        }
      }
      val poi_distance: Double = obj.getDouble("poi_distance")
      name_bool && (type_bool || StringUtils.isEmpty(poi_type)) && poi_distance <= 300
    }).groupBy(_.getString("agr_rs_id")).flatMap(obj=>{
      val list: List[JSONObject] = obj._2.toList
      val minObj: JSONObject = list.minBy(json => {
        JSONUtil.getJsonDouble(json, "poi_distance", Int.MaxValue)
      })
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("poi_name", minObj.getString("poi_name"))
        json.put("poi_addr", minObj.getString("poi_addr"))
        json.put("poi_x", minObj.getString("poi_x"))
        json.put("poi_y", minObj.getString("poi_y"))
        json.put("poi_distance", minObj.getString("poi_distance"))
        json.put("poi_type", minObj.getString("poi_type"))
        json.put("stay_adcode", minObj.getString("stay_adcode"))
        json.put("stay_province", minObj.getString("stay_province"))
        json.put("stay_city", minObj.getString("stay_city"))
        json.put("stay_district", minObj.getString("stay_district"))
        json.put("clue_type","POI_key_clue")
        json
      })
      tmpList
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("重点poi数据量："+poiKeyRdd.count())
    val poiFinalDf: DataFrame = poiKeyRdd.map(obj => {
      PoiFinal(
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("fatype"),
        obj.getString("aoicode"),
        obj.getString("znocode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("is_logistics"),
        obj.getString("distribute_passpoint"),
        obj.getString("big_category"),
        obj.getString("mid_category"),
        obj.getString("type_name"),
        obj.getString("poi_name"),
        obj.getString("poi_addr"),
        obj.getString("poi_x"),
        obj.getString("poi_y"),
        obj.getString("poi_distance_inAOI"),
        obj.getString("poi_type"),
        obj.getString("clue_type"),
        obj.getString("keyTag"),
        obj.getString("pinTag"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("poi中筛选出重点类型数据量："+poiFinalDf.count())
    poiFinalDf.createOrReplaceTempView("poiFinalTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_poi_final_di select * from poiFinalTmp")
    poiFinalDf.unpersist()
  }


  def aoiPoiInsertHiveTable(spark: SparkSession, aoiPoiRdd: RDD[JSONObject]) = {
    import spark.implicits._
    val aoiPoiDf: DataFrame = aoiPoiRdd.map(obj => {
      AoiPoiUnion(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id")
      )
    }).toDF()
    aoiPoiDf.createOrReplaceTempView("aoiPoiTmp")
    spark.sql("insert overwrite table dm_gis.dwd_ddjy_aoi_poi_di select * from aoiPoiTmp")
  }

  def readAoiKeyAndPoi(spark: SparkSession, incDay: String) = {
    val aoiKeySql=
      s"""
         |select
         |agr_id,agr_rs_id,
         |name as belong_name,
         |agr_lng as belong_x,
         |agr_lat as belong_y,
         |'AOI' as src,
         |id as unique_id,
         |clue_type,
         |stay_adcode,
         |stay_province,
         |stay_city,
         |stay_district
         |from dm_gis.dwd_ddjy_aoi_key_di
         |""".stripMargin
    val aoiKeyDf: DataFrame = spark.sql(aoiKeySql)
    val poiFinalSql=
      s"""
         |select
         |agr_id,agr_rs_id,
         |poi_name as belong_name,
         |poi_x as belong_x,
         |poi_y as belong_y,
         |'POI' as src,
         |concat(poi_name,poi_x,poi_y) as unique_id,
         |clue_type,
         |stay_adcode,
         |stay_province,
         |stay_city,
         |stay_district
         |from dm_gis.dwd_ddjy_poi_final_di
         |""".stripMargin
    val poiFinalDf: DataFrame = spark.sql(poiFinalSql)
    val aoiKeyRdd = SparkUtils.getDfToJson(spark,aoiKeyDf)
    val aoiPoiRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, poiFinalDf).map(obj => {
      var unique_id: String = obj.getString("unique_id")
      unique_id = DigestUtils.md2Hex(unique_id)
      obj.put("unique_id", unique_id)
      obj
    }).union(aoiKeyRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //aoiPoiInsertHiveTable(spark,aoiPoiRdd)
    logger.error("aoi和poi拼接后数据量："+aoiPoiRdd.count())
    aoiPoiRdd
  }

  def processAoiPoi(spark: SparkSession, aoiPoiRdd: RDD[JSONObject],task_batch:String, incDay: String) = {
    import spark.implicits._
    val belongNameRdd: RDD[JSONObject] = aoiPoiRdd
      .groupBy(_.getString("unique_id"))
      .flatMap(obj=>{
        val size: Int = obj._2.size
        val belong_x_sum: Double = obj._2.toList.map(_.getDoubleValue("belong_x")).sum
        val belong_y_sum: Double = obj._2.toList.map(_.getDoubleValue("belong_y")).sum
        val belong_x_avg: Double = belong_x_sum / size
        val belong_y_avg: Double = belong_y_sum / size
        val newList: Iterable[JSONObject] = obj._2.map(json => {
          json.put("belong_x_avg", belong_x_avg)
          json.put("belong_y_avg", belong_y_avg)
          json
        })
        newList
      })
    val belongInfoDf: DataFrame = belongNameRdd.map(obj => {
      obj.put("task_batch", task_batch)
      obj.put("inc_day", incDay)
      obj
    }).map(obj => {
      BelongInfo(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        obj.getString("task_batch"),
        obj.getString("inc_day"),
        obj.getString("clue_type"),
        obj.getString("belong_x_avg"),
        obj.getString("belong_y_avg")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    belongInfoDf.createOrReplaceTempView("belongInfoFilterTmp")
    val joinLastData=
      s"""
         |select
         |t1.*,
         |t2.unique_id as last_unique_id
         |from
         |(
         |	select
         |	*
         |	from belongInfoFilterTmp
         |) t1
         |left join
         |(
         |select
         |*
         |from dm_gis.dwd_ddjy_cantonese_clue_seed_info_test
         |) t2
         |on t1.unique_id=t2.unique_id
         |""".stripMargin
    val joinLastDataDf: DataFrame = spark.sql(joinLastData).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val noJoinLastDataDf: DataFrame = joinLastDataDf.filter(s"last_unique_id is null")
      .drop("last_unique_id").toDF()
    noJoinLastDataDf.createOrReplaceTempView("noJoinLastDataTmp")
    val noJoinLastDataSql=
      s"""
         |select
         |t1.*,
         |t2.belong_x_avg as last_belong_x,t2.belong_y_avg as last_belong_y,t2.unique_id as last_unique_id
         |from
         |(
         |	select
         |	*
         |	from noJoinLastDataTmp
         |) t1
         |left join
         |(
         |	select
         |	*
         |	from dm_gis.dwd_ddjy_cantonese_clue_seed_info_test
         |) t2
         |on t1.belong_name=t2.belong_name and t1.stay_city=t2.stay_city and t1.stay_district=t2.stay_district
         |""".stripMargin
    val noJoinLastDataAgainDf: DataFrame = spark.sql(noJoinLastDataSql)
    val yesJoinLastDataBelongDf: DataFrame = noJoinLastDataAgainDf.filter(s"last_belong_x is not null").toDF()
    val updateUniqueidRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, yesJoinLastDataBelongDf).map(obj => {
      val belong_x_avg: Double = obj.getDouble("belong_x_avg")
      val belong_y_avg: Double = obj.getDouble("belong_y_avg")
      val last_belong_x: Double = JSONUtil.getJsonDouble(obj,"last_belong_x",Int.MaxValue)
      val last_belong_y: Double = JSONUtil.getJsonDouble(obj,"last_belong_y",Int.MaxValue)
      val distance: Double = DistanceUtils.getDistance(belong_x_avg, belong_y_avg, last_belong_x, last_belong_y)
      obj.put("distance", distance)
      obj
    }).filter(obj => {
      val distance: Double = obj.getDouble("distance")
      distance < 500
    }).map(obj=>{
      val belong_name: String = obj.getString("belong_name")
      val stay_city: String = obj.getString("stay_city")
      val stay_district: String = obj.getString("stay_district")
      ((belong_name,stay_city,stay_district),obj)
    }).groupByKey().map(obj=>{
      obj._2.toList.minBy(_.getDouble("distance"))
    }).map(obj => {
      val last_unique_id: String = obj.getString("last_unique_id")
      val unique_id: String = obj.getString("unique_id")
      obj.put("old_unique_id", unique_id)
      obj.put("new_unique_id", last_unique_id)
      (obj.getString("old_unique_id"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("更新unique_id数据量："+updateUniqueidRdd.count())
    val updateUniqueidDf = SparkUtils.getDfToJson(spark, joinLastDataDf).map(obj => {
      (obj.getString("unique_id"), obj)
    }).leftOuterJoin(updateUniqueidRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val right_unique_id: String = rightObj.getString("new_unique_id")
        leftObj.put("unique_id", right_unique_id)
      }
      leftObj
    }).map(obj => {
      BelongInfo(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        obj.getString("task_batch"),
        obj.getString("inc_day"),
        obj.getString("clue_type"),
        obj.getString("belong_x_avg"),
        obj.getString("belong_y_avg")
      )
    }).distinct().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("更新完unique_id之后所有数据量："+updateUniqueidDf.count())
    updateUniqueidDf.createOrReplaceTempView("belongInfoTmpNew")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_belong_info_di select * from belongInfoTmpNew")
    belongInfoDf.unpersist()
  }
  def updateCantoneseClueSeed(spark: SparkSession, incDay: String) = {
    //更新线索种子表
    val half_year_day: String = DateUtil.getDateStr(incDay, -180, "")
    val updateUniqueidSeedInfo=
      s"""
         |insert overwrite table dm_gis.dwd_ddjy_cantonese_clue_seed_info_test
         |select
         |distinct unique_id,belong_name,belong_x,belong_y,stay_adcode,stay_province,stay_city,stay_district,task_batch,clue_type,create_time,last_join_time,belong_x_avg,belong_y_avg
         |from
         |(
         |	select
         |	nvl(t2.unique_id,t1.unique_id) as unique_id
         |	,nvl(t2.belong_name,t1.belong_name) as belong_name
         |	,nvl(t2.belong_x,t1.belong_x) as belong_x
         |	,nvl(t2.belong_y,t1.belong_y) as belong_y
         |	,nvl(t2.stay_adcode,t1.stay_adcode) as stay_adcode
         |	,nvl(t2.stay_province,t1.stay_province) as stay_province
         |	,nvl(t2.stay_city,t1.stay_city) as stay_city
         |	,nvl(t2.stay_district,t1.stay_district) as stay_district
         |	,nvl(t2.task_batch,t1.task_batch) as task_batch
         |	,nvl(t2.clue_type,t1.clue_type) as clue_type
         |	,if(t1.unique_id is null,from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss"),t1.create_time) as create_time
         |	,if(t2.unique_id is not null,from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss"),t1.last_join_time) as last_join_time
         | ,nvl(t1.belong_x_avg,t2.belong_x_avg) as belong_x_avg
         | ,nvl(t1.belong_y_avg,t2.belong_y_avg) as belong_y_avg
         |	from dm_gis.dwd_ddjy_cantonese_clue_seed_info_test t1
         |	full join
         |	(
         |		select
         |		*
         |		from
         |		(
         |			select *,
         |			row_number() over(partition by unique_id order by agr_id desc) as rnk
         |			from dm_gis.dwd_ddjy_belong_info_di
         |		) a1
         |		where rnk=1
         |	)t2
         |	on t1.unique_id=t2.unique_id
         |) t3
         |where replace(substr(last_join_time,0,10),'-','')>='${half_year_day}'
         |""".stripMargin
    spark.sql(updateUniqueidSeedInfo)
  }

  def readBelongInfoData(spark: SparkSession,incDay: String) = {
    val belongInfoSql=
      """
        |select *
        |from dm_gis.dwd_ddjy_belong_info_di
        |""".stripMargin
    val belongInfoDf: DataFrame = spark.sql(belongInfoSql)
    val belongInfoRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, belongInfoDf)
    belongInfoRdd
  }

  def joinAoiPoiBelongDropOwnerInfoData(spark: SparkSession, dropOwnerRdd: RDD[JSONObject], belongInfoRdd: RDD[JSONObject], task_batch:String, incDay: String) = {
    import spark.implicits._
    val belongInfoGroupRdd: RDD[(String, JSONObject)] = belongInfoRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    })
    val dropJoinAoiDf: Dataset[Row] = dropOwnerRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    }).repartition(2000).join(belongInfoGroupRdd).map(obj=>{
      val newObj = new JSONObject()
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      newObj.put("unique_id",rightObj.getString("unique_id"))
      newObj.put("agr_id",rightObj.getString("agr_id"))
      newObj.put("agr_rs_id",rightObj.getString("agr_rs_id"))
      newObj.put("belong_name",rightObj.getString("belong_name"))
      newObj.put("belong_id",rightObj.getString("belong_id"))
      newObj.put("belong_x",rightObj.getString("belong_x"))
      newObj.put("belong_y",rightObj.getString("belong_y"))
      newObj.put("src",rightObj.getString("src"))
      newObj.put("vehicle",leftObj.getString("vehicle"))
      newObj.put("vehicle_time",leftObj.getString("vehicle_time"))
      newObj.put("owner_id",leftObj.getString("owner_id"))
      newObj.put("owner_name",leftObj.getString("owner_name"))
      newObj.put("province_name",leftObj.getString("province_name"))
      newObj.put("city_name",leftObj.getString("city_name"))
      newObj.put("area_name",leftObj.getString("area_name"))
      newObj.put("area_manager_name",leftObj.getString("area_manager_name"))
      newObj.put("org_type",leftObj.getString("org_type"))
      newObj.put("credit_code",leftObj.getString("credit_code"))
      newObj.put("manager",leftObj.getString("manager"))
      newObj.put("manager_phone",leftObj.getString("manager_phone"))
      newObj.put("contactor",leftObj.getString("contactor"))
      newObj.put("contactor_phone",leftObj.getString("contactor_phone"))
      newObj.put("owner_type",leftObj.getString("owner_type"))
      newObj.put("clue_type",rightObj.getString("clue_type"))
      newObj.put("task_batch",rightObj.getString("task_batch"))
      newObj.put("inc_day",rightObj.getString("inc_day"))
      newObj.put("stay_adcode",rightObj.getString("stay_adcode"))
      newObj.put("stay_province",rightObj.getString("stay_province"))
      newObj.put("stay_city",rightObj.getString("stay_city"))
      newObj.put("stay_district",rightObj.getString("stay_district"))
      newObj.put("belong_x_avg",rightObj.getString("belong_x_avg"))
      newObj.put("belong_y_avg",rightObj.getString("belong_y_avg"))
      newObj
    }).filter(obj=>{
      val stay_adcode: String = obj.getString("stay_adcode")
      StringUtils.isNoneEmpty(stay_adcode)
    }).map(obj=>{
      obj.put("clue_src","1")
      obj
    }).map(obj => {
      BelongJoinOwn(
        obj.getString("unique_id"),
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_id"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        obj.getString("task_batch"),
        obj.getString("inc_day"),
        obj.getString("clue_type"),
        obj.getString("clue_src"),
        obj.getString("belong_x_avg"),
        obj.getString("belong_y_avg")
      )
    }).distinct().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("drop、belong关联后数据量："+dropJoinAoiDf.count())
    dropJoinAoiDf.createOrReplaceTempView("belongJoinOwnTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_belong_join_own_di partition(week_day='$incDay') select * from belongJoinOwnTmp")
  }



  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    val start_day: String = DateUtil.getDateStr(incDay, -6, "")
    val task_batch=start_day+"-"+incDay
    logger.error("task_batch:"+task_batch)
    //读取single_agr_stat_all_drop_owner_tmp数据
    val dropOwnerRdd: RDD[JSONObject] = readDropOwnerData(spark, incDay)
    //读取dwd_ddjy_aoi_not_key_di表数据
    val aoiNotKeyDf: DataFrame = readAoiNotKeyData(spark, incDay)
    //AOI非重点类型数据调用POI接口
    aoiNotKeyPoiInterface(spark, aoiNotKeyDf, incDay)
    //读取dwd_ddjy_aoi_not_key_poi_di表数据
    val aoiNotKeyPoiDf: DataFrame = readAoiNotKeyPoiData(spark, incDay)
    //过滤poi数据得出最终poi表
    processPoiData(spark,aoiNotKeyPoiDf,incDay)
    //读取dwd_ddjy_aoi_key_di和dwd_ddjy_poi_final_di表
    val aoiPoiRdd: RDD[JSONObject] = readAoiKeyAndPoi(spark, incDay)
    //处理aoi_poi数据
    processAoiPoi(spark,aoiPoiRdd,task_batch,incDay)
    //更新种子表
    updateCantoneseClueSeed(spark,incDay)
    //读取dwd_ddjy_belong_info_di表数据
    val belongInfoRdd: RDD[JSONObject] = readBelongInfoData(spark, incDay)
    //关联belong_info、aoiPoi、dropOwner
    joinAoiPoiBelongDropOwnerInfoData(spark,dropOwnerRdd,belongInfoRdd,task_batch,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    //execute()
    logger.error("======>>>>>>YueYunClueMap Execute Ok")
  }
  case class DistanceSeedInfo(belong_name:String,
                              belong_x:String,
                              belong_y:String,
                              src:String,
                              unique_id:String,
                              poiid:String,
                              stationname:String,
                              province:String,
                              city:String,
                              district:String,
                              adcode:String,
                              addr:String,
                              lng:String,
                              lat:String,
                              distance:String,
                              d_dist:String,
                              create_time:String
                             )
  case class AoiNotKeyPoiInterface(
                                    agr_id:String,
                                    agr_cnt:String,
                                    agr_dis:String,
                                    agr_tm:String,
                                    agr_lng:String,
                                    agr_lat:String,
                                    agr_dis2sp:String,
                                    agr_gh:String,
                                    agr_rs_id:String,
                                    agr_rs_cnt:String,
                                    vehicle_type:String,
                                    data_src:String,
                                    vehicle:String,
                                    vehicle_time:String,
                                    vehicle_no:String,
                                    owner_id:String,
                                    owner_name:String,
                                    province_name:String,
                                    city_name:String,
                                    area_name:String,
                                    area_manager_name:String,
                                    org_type:String,
                                    credit_code:String,
                                    manager:String,
                                    manager_phone:String,
                                    contactor:String,
                                    contactor_phone:String,
                                    owner_type:String,
                                    id:String,
                                    name:String,
                                    faType:String,
                                    aoiCode:String,
                                    znoCode:String,
                                    dist:String,
                                    city:String,
                                    is_logistics:String,
                                    distribute_passpoint:String,
                                    big_category:String,
                                    mid_category:String,
                                    type_name:String,
                                    poi_name:String,
                                    poi_addr:String,
                                    poi_x:String,
                                    poi_y:String,
                                    poi_distance:String,
                                    poi_type:String,
                                    clue_type:String,
                                    stay_adcode:String,
                                    stay_province:String,
                                    stay_city:String,
                                    stay_district:String
                                  )
  case class PoiFinal(
                                    agr_id:String,
                                    agr_cnt:String,
                                    agr_dis:String,
                                    agr_tm:String,
                                    agr_lng:String,
                                    agr_lat:String,
                                    agr_dis2sp:String,
                                    agr_gh:String,
                                    agr_rs_id:String,
                                    agr_rs_cnt:String,
                                    vehicle_type:String,
                                    data_src:String,
                                    vehicle:String,
                                    vehicle_time:String,
                                    vehicle_no:String,
                                    owner_id:String,
                                    owner_name:String,
                                    province_name:String,
                                    city_name:String,
                                    area_name:String,
                                    area_manager_name:String,
                                    org_type:String,
                                    credit_code:String,
                                    manager:String,
                                    manager_phone:String,
                                    contactor:String,
                                    contactor_phone:String,
                                    owner_type:String,
                                    id:String,
                                    name:String,
                                    faType:String,
                                    aoiCode:String,
                                    znoCode:String,
                                    dist:String,
                                    city:String,
                                    is_logistics:String,
                                    distribute_passpoint:String,
                                    big_category:String,
                                    mid_category:String,
                                    type_name:String,
                                    poi_name:String,
                                    poi_addr:String,
                                    poi_x:String,
                                    poi_y:String,
                                    poi_distance:String,
                                    poi_type:String,
                                    clue_type:String,
                                    keyTag:String,
                                    pinTag:String,
                                    stay_adcode:String,
                                    stay_province:String,
                                    stay_city:String,
                                    stay_district:String
                                  )
  case class BelongJoinOwn(
                            unique_id:String,
                            agr_id:String,
                            agr_rs_id:String,
                            belong_name:String,
                            belong_id:String,
                            belong_x:String,
                            belong_y:String,
                            src:String,
                            vehicle:String,
                            vehicle_time:String,
                            owner_id:String,
                            owner_name:String,
                            province_name:String,
                            city_name:String,
                            area_name:String,
                            area_manager_name:String,
                            org_type:String,
                            credit_code:String,
                            manager:String,
                            manager_phone:String,
                            contactor:String,
                            contactor_phone:String,
                            owner_type:String,
                            stay_adcode:String,
                            stay_province:String,
                            stay_city:String,
                            stay_district:String,
                            task_batch:String,
                            inc_day:String,
                            clue_type:String,
                            clue_src:String,
                            belong_x_avg:String,
                            belong_y_avg:String
                          )
  case class BelongInfo(
                         agr_id:String,
                         agr_rs_id:String,
                         belong_name:String,
                         belong_x:String,
                         belong_y:String,
                         src:String,
                         unique_id:String,
                         stay_adcode:String,
                         stay_province:String,
                         stay_city:String,
                         stay_district:String,
                         task_batch:String,
                         inc_day:String,
                         clue_type:String,
                         belong_x_avg:String,
                         belong_y_avg:String
                       )

}
