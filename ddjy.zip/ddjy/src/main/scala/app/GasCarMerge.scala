package app

import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkWrite

import scala.collection.mutable.ListBuffer

/**
 * Description:【吨吨加油】线索数据融合需求_V1.1-油站车辆融合周维度表
 * 需求方：娇悦 01404184
 * Author: 李相志 01405644
 * Date: 14:30 2023/2/15
 * 任务id:523
 * 任务名称：油站车辆融合周维度表
 * 依赖任务：车辆经过油站频次线索422
 * 数据源：dm_ddjy_gas_station_info_di、ddjy_station_near_road_clue_di、join_clue_pathway_frequency_di、dwd_ddjy_carrier_info_seed、ddjy_ods_dim_team_info、dm_ddjy_carrier_rlst_di
 * 调用服务地址：无
 * 数据结果：dm_ddjy_gas_car_merge_di
 */
object GasCarMerge {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def stationInfoProcess(spark: SparkSession, max_day: String) = {
    import spark.implicits._
    val stationInfoSql=
      """
        |select *
        |from dm_gis.dm_ddjy_gas_station_info_di
        |where delflag='0'
        |""".stripMargin
    val stationInfoDf: DataFrame = spark.sql(stationInfoSql)
    val gasCompetitorsDf: DataFrame = SparkUtils.getDfToJson(spark, stationInfoDf).map(obj => {
      val srclist: String = obj.getString("srclist")
      val poiid: String = obj.getString("poiid")
      val querybrandid: String = obj.getString("querybrandid")
      val management_model: String = obj.getString("management_model")
      val adcode: String = obj.getString("adcode")
      val province: String = obj.getString("province")
      val city: String = obj.getString("city")
      val district: String = obj.getString("district")
      val lng: String = obj.getString("lng")
      val lat: String = obj.getString("lat")
      val cooperatestatus: String = obj.getString("cooperatestatus")
      val tel: String = obj.getString("tel")
      val addr: String = obj.getString("addr")
      val src: String = obj.getString("src")
      val srclistArr: Array[String] = srclist.split(",")
      val diffArr: Array[String] = Array("0", "1")
      val srclistDiffArr: Array[String] = srclistArr.diff(diffArr)
      val list = new ListBuffer[String]
      var gas_competitors = ""
      if (srclistDiffArr.nonEmpty) {
        for (elem <- srclistDiffArr) {
          val elem_new: String = elem match {
            case "2" => "TYB"
            case "3" => "TYC"
            case "4" => "WJY"
            case "5" => "SF"
            case "6" => "DDJY"
            case _ => ""
          }
          list.append(elem_new)
        }
        gas_competitors = list.mkString(",")
      }
      (poiid, querybrandid, management_model, gas_competitors,adcode,province,city,district,lng,lat,cooperatestatus,tel,addr,src)
    }).toDF("poiid", "querybrandid", "management_model", "gas_competitors","adcode","province","city","district","lng","lat","cooperatestatus","tel","addr","src")
        .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站数据量："+gasCompetitorsDf.count())
    gasCompetitorsDf
  }

  def stationNearRoad(spark: SparkSession, max_day: String) = {
    import spark.implicits._
    val stationNearRoadSql=
      s"""
        |select poiid,swid,
        |roadClass as gas_road_type,
        |formway as gas_road_function_type
        |from
        |(
        |	select *,row_number() over(partition by poiid order by cast(dist_min as int) asc,cast(roadclass as int) asc,cast(dist_max as int),cast(line_dist as int) asc) as rank1
        |	from
        |	(
        |		select *,
        |		case when cast(star_dist as int) >= cast(end_dist as int) then end_dist
        |			 else star_dist end as dist_min,
        |		case when cast(star_dist as int) >= cast(end_dist as int) then star_dist
        |			 else end_dist end as dist_max
        |		from dm_gis.ddjy_station_near_road_clue_di
        |		where inc_day = '$max_day'
        |	) t1
        |) t2
        |where rank1 = 1
        |""".stripMargin
    val stationNearRoadDf: DataFrame = spark.sql(stationNearRoadSql)
    val stationNearRoadProcessDf: DataFrame = SparkUtils.getDfToJson(spark, stationNearRoadDf).map(obj => {
      val poiid: String = obj.getString("poiid")
      val swid: String = obj.getString("swid")
      var gas_road_type: String = obj.getString("gas_road_type")
      var gas_road_function_type: String = obj.getString("gas_road_function_type")
      gas_road_type = gas_road_type match {
        case "0" => "高速公路"
        case "1" => "国道"
        case "2" => "省道"
        case "3" => "县道"
        case "4" => "乡公路"
        case "5" => "县乡村内部道路"
        case "6" => "主要大街、城市快速道"
        case "7" => "主要道路"
        case "8" => "次要道路"
        case "9" => "普通道路"
        case "10" => "非导航道路"
        case _ => ""
      }
      gas_road_function_type = gas_road_function_type match {
        case "1" => "上下线分离"
        case "2" => "交叉点内道路"
        case "3" => "JCT（连接高速与高速的匝道）"
        case "4" => "环岛"
        case "5" => "服务区道路"
        case "6" => "引路（一般道路与一般道路或高速道路的连接路）"
        case "7" => "辅路"
        case "8" => "引路+JCT"
        case "9" => "出口"
        case "10" => "入口"
        case "11" => "提右道路A"
        case "12" => "提右道路B"
        case "13" => "提左道路A"
        case "14" => "提左道路B"
        case "15" => "普通道路"
        case _ => ""
      }
      (poiid, gas_road_type, gas_road_function_type)
    }).distinct().toDF("poiid", "gas_road_type", "gas_road_function_type")
        .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站周边道路信息表数据量："+stationNearRoadProcessDf.count())
    stationNearRoadProcessDf
  }

  def pathwayCostRank(spark: SparkSession, gasCompetitorsDf: DataFrame, stationNearRoadProcessDf: DataFrame, max_day: String,vehicle_max_day:String) = {
    val last_eleven_day = DateUtil.getDateStr(max_day, -6, "")
    val taskSumCountSql=
      s"""
        |select
        |gas_id,carrier_id,vehicle_no,
        |if(clue_task_count is null or clue_task_count='',0,clue_task_count)+if(pathway_cost_task_count is null or pathway_cost_task_count='',0,pathway_cost_task_count) as task_sum_count,
        |pathway_cost_task_count
        |from
        |(
        |	select gas_id,carrier_id,vehicle_no,clue_task_count,
        |	case when pathway_task_count is null or pathway_task_count='' or vehicle_pathway_cost is null or vehicle_pathway_cost='' then ''
        |		 when cast(vehicle_pathway_cost as double)>=0 and cast(vehicle_pathway_cost as double)<200 then ceiling(pathway_task_count*1)
        |		 when cast(vehicle_pathway_cost as double)>=200 and cast(vehicle_pathway_cost as double)<500 then ceiling(pathway_task_count*0.75)
        |		 when cast(vehicle_pathway_cost as double)>=500 and cast(vehicle_pathway_cost as double)<1000 then ceiling(pathway_task_count*0.5)
        |		 when cast(vehicle_pathway_cost as double)>=1000 and cast(vehicle_pathway_cost as double)<2000 then ceiling(pathway_task_count*0.1)
        |		 when cast(vehicle_pathway_cost as double)>=2000 then 0
        |		 end as pathway_cost_task_count
        |	from dm_gis.vehicle_join_clue_pathway_frequency_di
        | where inc_day='$max_day'
        |) t1
        |""".stripMargin
    val taskSumCountDf: DataFrame = spark.sql(taskSumCountSql).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("频次总和数据量："+taskSumCountDf.count())
    //中间表和车队联系方式表关联
    val midJoinConcatSql=
      s"""
        |select
        |gas_id
        |,stationname
        |,t1.vehicle_no
        |,clue_task_count
        |,clue_dist_avg
        |,pathway_task_count
        |,pathway_around_task_count
        |,pathway_dist_avg
        |,stay_task_count
        |,t2.owner_id as carrier_id
        |,t2.owner_name as carrier_name
        |,vehicle_pathway_cost
        |from
        |(
        |	select
        |	*
        |	from dm_gis.vehicle_join_clue_pathway_frequency_di
        |	where inc_day='$max_day'
        | and carrier_id is null or carrier_id=''
        |) t1
        |left join
        |(
        |	select
        |	vehicle_no,owner_id,owner_name
        |	from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |	where inc_day='$vehicle_max_day'
        |	group by vehicle_no,owner_id,owner_name
        |) t2
        |on t1.vehicle_no=t2.vehicle_no
        |where length(owner_name)>5
        |union all
        |select
        |gas_id
        |,stationname
        |,vehicle_no
        |,clue_task_count
        |,clue_dist_avg
        |,pathway_task_count
        |,pathway_around_task_count
        |,pathway_dist_avg
        |,stay_task_count
        |,carrier_id
        |,carrier_name
        |,vehicle_pathway_cost
        |from dm_gis.vehicle_join_clue_pathway_frequency_di
        |where inc_day='$max_day'
        |and carrier_id is not null and carrier_id!=''
        |""".stripMargin
    val midJoinConcatDf: DataFrame = spark.sql(midJoinConcatSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("剔除carrier_name长度小于等于5后剩余的数据量："+midJoinConcatDf.count())
    midJoinConcatDf.createOrReplaceTempView("midJoinConcatTmp")
    taskSumCountDf.createOrReplaceTempView("taskSumCountTmp")
    gasCompetitorsDf.createOrReplaceTempView("gasCompetitorsTmp")
    stationNearRoadProcessDf.createOrReplaceTempView("stationNearRoadProcessTmp")
    val allTableJoinSql=
      s"""
        |select
        |gas_id,stationname,adcode,province,city,district,lng,lat,cooperatestatus,tel,brand,gas_type,gas_road_type,gas_road_function_type,gas_competitors,carrier_id,carrier_name,credit_code,legal_person_name,content,city_adcode,carrier_status,carrier_tag,vehicle_no,clue_task_count,pathway_task_count,pathway_around_task_count,stay_task_count,clue_dist_avg,pathway_dist_avg,
        |rank() over(partition by vehicle_no order by task_sum_count desc) as one_car_gas_rank,
        |vehicle_pathway_cost,update_time,task_batch,task_sum_count,
        |ceiling(pathway_cost_task_count) as pathway_cost_task_count,
        |if(cast(task_sum_count as double) >=3,1,0) as tag,
        |addr,src
        |from
        |(
        |	select
        |	t1.gas_id
        |	,t1.stationname
        |	,adcode
        |	,province
        |	,city
        |	,district
        |	,lng
        |	,lat
        |	,cooperatestatus
        |	,tel
        |	,querybrandid as brand
        |	,management_model as gas_type
        |	,gas_road_type
        |	,gas_road_function_type
        |	,gas_competitors
        |	,t1.carrier_id
        |	,carrier_name
        |	,credit_code
        |	,legal_person_name
        |	,content
        |	,city_adcode
        |	,if(t5.name is null,0,1) as carrier_status
        |	,carrier_tag
        |	,t1.vehicle_no
        |	,clue_task_count
        |	,pathway_task_count
        |	,pathway_around_task_count
        |	,stay_task_count
        |	,clue_dist_avg
        |	,pathway_dist_avg
        |	,vehicle_pathway_cost
        |	,from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as update_time
        |	,concat('${last_eleven_day}','-','${max_day}')  as task_batch
        |	,task_sum_count
        |	,pathway_cost_task_count
        |	,row_number() over(partition by t1.gas_id,t1.carrier_id,t1.vehicle_no order by t1.gas_id) as rnk
        | ,sf_owner
        | ,addr
        | ,src
        |	from midJoinConcatTmp t1
        |	left join gasCompetitorsTmp t2
        |	on t1.gas_id=t2.poiid
        |	left join
        |	(
        |		select
        |   name,city_adcode,credit_code,
        |   concat('(',concat_ws('),(',collect_list(legal_person_name)),')') as legal_person_name,
        |   concat('(',concat_ws('),(',collect_list(content)),')') as content
        |   from
        |   (
        |	    select name,city_adcode,legal_person_name,content,credit_code,
        |	    row_number() over(partition by name,legal_person_name,content order by source_time desc) as rnk
        |	    from dm_gis.dwd_ddjy_carrier_info_di
        |     where inc_day='${max_day}'
        |    ) t3_1
        |   group by name,city_adcode,credit_code
        |	) t4
        |	on t1.carrier_name=t4.name
        |	left join
        |	(
        |		select name
        |	  from dm_gis.ddjy_ods_dim_team_info
        |	  where inc_day in(select max(inc_day) from dm_gis.ddjy_ods_dim_team_info)
        |	  and name!='' and name is not null
        |	  and del_flag = '0'
        |	  group by name
        |	) t5
        |	on t1.carrier_name=t5.name
        |	left join
        |	(
        |		select carrier_id,carrier_tag
        |		from dm_gis.dm_ddjy_mid_carrier_rlst_di
        |		where inc_day='${max_day}'
        |		group by carrier_id,carrier_tag
        |	) t6
        |	on t1.carrier_id=t6.carrier_id
        |	left join stationNearRoadProcessTmp t7
        |	on t1.gas_id=t7.poiid
        |	left join taskSumCountTmp t8
        |	on t1.carrier_id=t8.carrier_id and t1.gas_id=t8.gas_id and t1.vehicle_no=t8.vehicle_no
        | left join dm_gis.dim_sf_owner_df t10
        | on t1.carrier_name=t10.sf_owner
        |) t9
        |where rnk=1 and sf_owner is null
        |and carrier_name not like '%顺丰%'
        |and carrier_name not like '%顺路%'
        |""".stripMargin
    val resultDf: DataFrame = spark.sql(allTableJoinSql)
    SparkWrite.writeToHive(spark,resultDf,"inc_day",max_day,"dm_gis.dm_ddjy_gas_car_merge_di")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取分区最大值
    val station_pathway_statistic_clue_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.dm_ddjy_mid_carrier_rlst_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val station_pathway_statistic_clue_df: DataFrame = spark.sql(station_pathway_statistic_clue_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, station_pathway_statistic_clue_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    //获取车辆所属车队维表分区最大值
    val vehicle_max_day_sql=
      s"""
        |select
        |max(inc_day) as vehicle_max_day
        |from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |where inc_day<='$incDay'
        |""".stripMargin
    val vehicle_max_day_df: DataFrame = spark.sql(vehicle_max_day_sql)
    val vehicle_max_day: String = SparkUtils.getDfToJson(spark, vehicle_max_day_df).map(obj => {
      obj.getString("vehicle_max_day")
    }).collect().head
    logger.error("车辆所属车队维表数据分区最大值："+vehicle_max_day)
    //获取油站数据并处理
    val gasCompetitorsDf: DataFrame = stationInfoProcess(spark, max_day)
    //获取油站道路类型&功能类型数据
    val stationNearRoadProcessDf: DataFrame = stationNearRoad(spark, max_day)
    //按照途径频次进行排序
    pathwayCostRank(spark,gasCompetitorsDf,stationNearRoadProcessDf,max_day,vehicle_max_day)

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>GasCarMerge Execute Ok")
  }
}
