package app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.github.davidmoten.rtree.RTree
import com.github.davidmoten.rtree.geometry.{Geometries, Point}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DistanceTool, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.{Partitioner, RangePartitioner}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DateTimeUtil, JSONUtils, SparkUtils}

import scala.Array.range
import scala.collection.mutable.ArrayBuffer

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/12/9
*/

object StayPointToOil2 {

  @transient lazy val logger: Logger = Logger.getLogger(StayPointToOil2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  val fixUrl = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
//  val fixTestUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/post?url=http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"

//  val hisTestUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/post?url=http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"
  val hisUrl = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"



  case class traj(vehicle_serial: String, carrier_name: String, owner_id: String, jp_swid: String, jp_coords: String, jp_status: String, jp_time: String,
                  sum_dist: String, tl_time_periods: String, tl_durations: String, tl_stay_points: String, tl_road: String, tl_roadclass: String, tl_link: String,
                  tl_links: String, tl_length: String, source: String, date: String)


  case class jyzInfo(vehicle_serial: String, car_team_name: String, owner_id: String, date: String, jp_swid: String, jp_coords: String, jp_status: String,
                     stay_points: String, link: String, time_periods: String, durations: String, oilroadclass: String, links: String, length: String,
                     source: String, mark: String, tl_stay_points: String, dis_150: String,
                     pid: String, src: String, srcid: String, grpid: String, stationname: String, roadid: String, oilroadclass1: String, oilroadname: String,
                     sfgunpricevec: String, management_model: String, province: String, city: String, district: String, adcode: String, addr: String,
                     lng: String, lat: String, querybrandid: String, gaslocationtype: String, headlabellist: String, businesshours: String,
                     hasoilname: String, oilnamevec: String, poiid: String, ss: String, tel: String, discountmodelvec: String, gunpricevec: String,
                     priceactivityvec: String, pricechangetimevec: String, officialpricechangetimevec: String, officialpricevec: String,
                     createtime: String, cooperatestatus: String, businessstatus: String, effectivestartvec: String, effectiveendvec: String,
                     invoicedesc: String, maintainbegintime: String, maintainendtime: String, outsidedriverdesc: String, petrolstationqualify: String)



  class MyPartitioner(val num: Int) extends Partitioner {

    //这里定义partitioner个数
    override def numPartitions: Int = num

    def nonNegativeMod(x: Int, mod: Int): Int = {
      val rawMod = x % mod
      rawMod + (if (rawMod < 0) mod else 0)
    }

    //这里定义分区规则
    override def getPartition(key: Any): Int = {
      //key的类型为Any,需要转换为String
      var str: String = key.toString
      //取字符串的字符的key
      val reversKey: String = str.reverse.hashCode.toString
      reversKey match {
        case null => 0
        case _ => nonNegativeMod(key.hashCode, numPartitions)
      }
    }
//    override def equals(other: Any): Boolean = other match {
//      case h: HashPartitioner =>
//        h.numPartitions == numPartitions
//      case _ =>
//        false
//    }

  }

  def getSourceData1(spark: SparkSession, inc_day: String,ak:Int) = {

    val curTimeStamp = DateTimeUtil.getCurDayTimeStamp(inc_day)
    val preTimeStamp= DateTimeUtil.getCurDayTimeStamp(DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -7))



    val sourceSql =
      s"""
         |select
         |    a.un,zx,zy,tm,carrier_name,owner_id
         |from
         |(select
         | car_no un,lng zx,lat zy,tm
         |from
         |  dm_gis.ods_track_yy_di
         |where
         |  inc_day = '${inc_day}'
         |and tm >= '${preTimeStamp}'
         |and tm <= '${curTimeStamp}'
         |-- and car_no in ("粤T75392","粤T91378","粤T96379","粤T37397","粤T52477")
         |and PMOD(hash(car_no), 20) = '${ak}'
         |) a
         |left outer join
         |(
         |select
         |    owner_id,owner_name carrier_name,vehicle_no un
         |from
         |    dm_gis.dim_ddjy_vehicle_concat_yy_df
         |where
         |    inc_day = '${inc_day}'
         |) b
         |on a.un = b.un
       """.stripMargin



    logger.error("sourceSql为：" + sourceSql)

    val sourceDf = spark.sql(sourceSql)

    val sourceRdd = SparkUtils.getDfToJson(spark,sourceDf)

    sourceRdd.take(2).foreach(println(_))

    sourceRdd

  }


  def getSourceData1(spark: SparkSession, inc_day: String) = {

    val curTimeStamp = DateTimeUtil.getCurDayTimeStamp(inc_day)
    val preTimeStamp= DateTimeUtil.getCurDayTimeStamp(DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -7))



    val sourceSql =
      s"""
         |select
         |    a.un,zx,zy,tm,carrier_name,owner_id
         |from
         |(select
         | car_no un,lng zx,lat zy,tm
         |from
         |  dm_gis.ods_track_yy_di
         |where
         |  inc_day = '${inc_day}'
         |and tm >= '${preTimeStamp}'
         |and tm <= '${curTimeStamp}'
         |-- and car_no in ("粤T75392","粤T91378","粤T96379","粤T37397","粤T52477")
         |) a
         |left outer join
         |(
         |select
         |    owner_id,carrier_name,un
         |from
         |    dm_gis.dundun_vehicle_owner_id
         |) b
         |on a.un = b.un
       """.stripMargin



    logger.error("sourceSql为：" + sourceSql)

    val sourceDf = spark.sql(sourceSql)

    val sourceRdd = SparkUtils.getDfToJson(spark,sourceDf)

    sourceRdd.take(2).foreach(println(_))

    sourceRdd

  }




  def parseFixResponse(x: JSONObject) = {

    val jo = new JSONObject()
    val result = x.getJSONObject("result")
    val tracks = result.getJSONArray("tracks")
    val status = x.getString("status")
    val stay_points = result.getJSONArray("stay_points")

    val jp_swidBuff = new ArrayBuffer[String]()
    val jp_timeBuff = new ArrayBuffer[Long]()
    val jp_coordsBuff = new ArrayBuffer[String]()
    val jp_statusBuff = new ArrayBuffer[String]()
    val sum_distBuff = new ArrayBuffer[String]()
    //    val speedBuff = new ArrayBuffer[String]()
    val indexBuff = new ArrayBuffer[Int]()
    val time_periodsBuff = new ArrayBuffer[String]()
    val durationsBuff = new ArrayBuffer[String]()
    val stay_pointsBuff = new ArrayBuffer[String]()
    val roadBuff = new ArrayBuffer[String]()
    val roadclassBuff = new ArrayBuffer[String]()
    val linksBuff = new ArrayBuffer[String]()
    val linkBuff = new ArrayBuffer[String]()
    val lengthBuff = new ArrayBuffer[String]()
    val roadnameBuffTmp = new ArrayBuffer[String]()
    val roadclassBuffTmp = new ArrayBuffer[String]()
    val link_lengthBuffTmp = new ArrayBuffer[String]()



    for (i <- 0 until tracks.size()) {
      val t: JSONObject = tracks.getJSONObject(i)
      jp_swidBuff.append(t.getString("SWID"))
      jp_timeBuff.append(t.getLongValue("time"))

      val x: String = t.getString("x")
      val y: String = t.getString("y")
      jp_coordsBuff.append(x + "," + y)

      jp_statusBuff.append(t.getString("status"))
      sum_distBuff.append(t.getString("sum_dist"))

      roadnameBuffTmp.append(t.getString("roadname"))
      roadclassBuffTmp.append(t.getString("roadclass"))
      link_lengthBuffTmp.append(t.getString("link_length"))
    }

    for (i <- 0 until stay_points.size()) {
      val t: JSONObject = stay_points.getJSONObject(i)
      val start_index: Int = t.getIntValue("start_index")
      val end_index: Int = t.getIntValue("end_index")
      indexBuff.append(start_index)

      time_periodsBuff.append(DateTimeUtil.longToTime(jp_timeBuff(start_index) * 1000L, "yyyy-MM-dd HH:mm:ss")
        + "_" + DateTimeUtil.longToTime(jp_timeBuff(end_index) * 1000L, "yyyy-MM-dd HH:mm:ss"))

      durationsBuff.append(t.getString("duration"))

      stay_pointsBuff.append(jp_coordsBuff(start_index))
      roadBuff.append(roadnameBuffTmp(start_index))
      roadclassBuff.append(roadclassBuffTmp(start_index))
      linksBuff.append(jp_swidBuff.slice(start_index, end_index + 1).distinct.mkString("_"))
      linkBuff.append(jp_swidBuff(start_index))
      lengthBuff.append(link_lengthBuffTmp(start_index))
    }

    jo.put("jp_swid", jp_swidBuff.mkString("|"))
    jo.put("jp_time", jp_timeBuff.mkString("|"))
    jo.put("jp_coords", jp_coordsBuff.mkString("|"))
    jo.put("jp_status", jp_statusBuff.mkString("|"))
    jo.put("sum_dist", sum_distBuff.mkString("|"))
    jo.put("tl_index", indexBuff.mkString("|"))
    jo.put("tl_time_periods", "[" + time_periodsBuff.mkString(",") + "]")
    jo.put("tl_durations", "[" + durationsBuff.mkString(",") + "]")
    jo.put("tl_stay_points", stay_pointsBuff.mkString("|"))
    jo.put("tl_road", roadBuff.mkString("|"))
    jo.put("tl_roadclass", roadclassBuff.mkString("|"))
    jo.put("tl_links", linksBuff.mkString("|"))
    jo.put("tl_link", linkBuff.mkString("|"))
    jo.put("tl_length", lengthBuff.mkString("|"))

    jo
  }

  def calFixInterface(x: JSONObject):JSONObject= {

    //    val fixResponse = SparkUtils.doPost(fixUrl,x,logger)
    val un = x.getString("un")
    val carrier_name = x.getString("carrier_name")
    val date = x.getString("date")
    val owner_id = x.getString("owner_id")
    x.remove("un")
    x.remove("carrier_name")
    x.remove("date")
    x.remove("owner_id")

    val fixResponse = SparkUtils.doPost(fixUrl,x,logger)
    //    StringToCsv.stringToCsv("20221212","",fixResponse.toString())

//    println(fixResponse)

    val fixResponseParse = try {JSON.parseObject(fixResponse)} catch {case e:Exception => new JSONObject()}
    val json = try {parseFixResponse(fixResponseParse)} catch {case e:Exception => new JSONObject()}
    json.put("un",un)
    json.put("carrier_name",carrier_name)
    json.put("date",date)
    json.put("owner_id",owner_id)
    json.put("fixResponse",fixResponse)


    json
  }


  def getStdRdd(sourceRdd1: RDD[JSONObject]) = {

    val stdRdd = sourceRdd1.map(x => {
      val un = x.getString("un")
      val carrier_name = x.getString("carrier_name")
      val inc_day = x.getString("inc_day")
      val owner_id = x.getString("owner_id")
      ((un,carrier_name,owner_id,inc_day),x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
//      .partitionBy(new RangePartitioner(600,stdRdd))
      .map(x => {
        val (un,carrier_name,owner_id,date) = x._1
        val list = x._2
        val group_tm = list.toArray.map(x => {
          val json = x.asInstanceOf[JSONObject]
          val tm = json.getString("tm")
          (tm,json)
        }).toStream.sortBy(_._1)

        val tracks = new JSONArray()

        group_tm.zipWithIndex.toArray.map(x => {
          val joTracks = new JSONObject()
          val trajJson = x._1._2.asInstanceOf[JSONObject]
          val index = x._2.asInstanceOf[Int]
          val tm = JSONUtils.getJsonValueLong(trajJson,"tm",0)
          val zx = JSONUtils.getJsonValueDouble(trajJson,"zx",0)
          val zy = JSONUtils.getJsonValueDouble(trajJson,"zy",0)

          joTracks.put("index",index)
          joTracks.put("time",tm)
          //          joTracks.put("type",1)
          joTracks.put("x",zx)
          joTracks.put("y",zy)
          tracks.add(joTracks)
        })

        val process = new JSONObject()
        process.put("stay_time",300)
        process.put("stay_radius",0)
        process.put("stay_join_dist",20)

        val joPost = new JSONObject()

        joPost.put("ak","35a8f1a6a7b344339a91dc15d808293d")
        joPost.put("keeptype","1")
//        joPost.put("vehicle,",5)
        joPost.put("roadinfo",1)
        joPost.put("retflag",7)
        joPost.put("addpoint",1)
        joPost.put("only_primary",0)
        joPost.put("poiinfo",1)
        joPost.put("process",process)
        joPost.put("tracks",tracks)
        joPost.put("un",un)
        joPost.put("carrier_name",carrier_name)
        joPost.put("date",date)
        joPost.put("owner_id",owner_id)

        joPost
      })

    stdRdd
  }

  def calFixInterfaceRdd(sourceRdd1: RDD[JSONObject]) = {

    val stdRdd = getStdRdd(sourceRdd1)

    val limitMin = 6000
    val gjFixRdd = SparkUtils.akLimitMultiThreadRdd(stdRdd)(calFixInterface)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)
    gjFixRdd

  }

  def getSourceData2(spark: SparkSession, inc_day: String) = {

    val inc_day_pre7 = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -7)

    val sourceSql =
      s"""
         |select
         |  vehicle_serial un,carrier_name,inc_day
         |  from (
         |    select
         |      row_number() over(
         |        partition by vehicle_serial,carrier_name,inc_day
         |        order by
         |          vehicle_serial
         |      ) as rn, carrier_name,vehicle_serial,inc_day
         |    from
         |      dm_gis.eta_std_line_recall
         |    where
         |      inc_day >= '${inc_day_pre7}'
         |      and inc_day <= '${inc_day}'
         |      -- and vehicle_serial in ("沪EE7057", "赣C2919D")
         |  ) a
         | where
         |  rn = 1
       """.stripMargin

    val df = spark.sql(sourceSql)

    val sourceRdd = SparkUtils.getDfToJson(spark,df)


//    val sourceDf = spark.read.format("csv")
//      .option("header", "true")
//      .option("delimiter","\t")
//      .csv("d:\\user\\01401062\\桌面\\case_02.csv")
//    val sourceRdd = SparkUtils.getRowToJson(sourceDf,100)
//      .filter(x => {
//        val un = x.getString("un")
//        un.equals("赣C2919D") || un.equals("沪EE7057")
//      })
//    //      .filter(_.getString("un").equals("赣C2919D")  _.getString("un").equals("赣C2919D"))
//    //      .filter(_.getString("inc_day").equals("20221130"))



    sourceRdd

  }


  /**
    * 调用历史轨迹
    * @param hisRes
    * @param x
    * @return
    */

  def parseHisResponse(hisRes: JSONObject,x:JSONObject) = {
    val status = hisRes.getString("status")
    val his_tracks = new JSONArray()

    val result = hisRes.getJSONObject("result")
    val data = result.getJSONObject("data")
    val tracks = data.getJSONArray("track")

    for (i <- (0 until tracks.size()) if tracks.size() > 0) {
      val jo = new JSONObject()
      val track = tracks.getJSONObject(i)
      val ac = JSONUtils.getJsonValueInt(track,"ac",0)
      val be = JSONUtils.getJsonValueDouble(track,"be",0)
      val index = i
      val sp = JSONUtils.getJsonValueDouble(track,"sp",0)
      val time = JSONUtils.getJsonValueLong(track,"tm",0)
      val zx = JSONUtils.getJsonValueDouble(track,"zx",0)
      val zy = JSONUtils.getJsonValueDouble(track,"zy",0)

      jo.put("accuracy",ac)
      jo.put("azimuth",be)
      jo.put("index",index)
      jo.put("speed",sp)
      jo.put("time",time)
      jo.put("type",1)
      jo.put("x",zx)
      jo.put("y",zy)

      his_tracks.add(jo)

    }


    x.put("tracks",his_tracks)
    x.put("status",status)

    x
  }





  def saveToHisFixTable(gjFixRdd1: RDD[JSONObject],gjFixRdd2: RDD[JSONObject], spark: SparkSession, inc_day: String): Unit = {

    import spark.implicits._
    val saveTableName = "dm_gis.dundun_inner_outer_traj_info"

    val unionRdd = gjFixRdd1.map(x => {
      x.put("source","yy")
      x
    })
      .union(gjFixRdd2.map(x => {
      x.put("source","sf")
      x
    }))


    unionRdd.map(x => {


      val un= x.getString("un")
      val carrier_name= x.getString("carrier_name")
      val owner_id= x.getString("owner_id")
      val jp_swid= x.getString("jp_swid")
      val jp_coords= x.getString("jp_coords")
      val jp_status= x.getString("jp_status")
      val jp_time= x.getString("jp_time")
      val sum_dist= x.getString("sum_dist")
      val tl_time_periods= x.getString("tl_time_periods")
      val tl_durations= x.getString("tl_durations")
      val tl_stay_points= x.getString("tl_stay_points")
      val tl_road= x.getString("tl_road")
      val tl_roadclass= x.getString("tl_roadclass")
      val tl_link= x.getString("tl_link")
      val tl_links= x.getString("tl_links")
      val tl_length= x.getString("tl_length")
      val source= x.getString("source")
      val date= if (source.equals("sf")) x.getString("date") else ""

      traj(un,carrier_name,owner_id,jp_swid,jp_coords,jp_status,jp_time,sum_dist,
        tl_time_periods,tl_durations,tl_stay_points,tl_road,tl_roadclass,tl_link,tl_links,tl_length,source,date)
    }).repartition(1000).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)


  }

  def calOilStationRdd(spark: SparkSession, inc_day: String) = {

//    val sql =
//      s"""
//         |load data inpath '/user/01401062/upload/gis/data/dundun_oil_station_info.csv' overwrite into table dm_gis.dundun_oil_station_info
//       """.stripMargin
//  -- dm_gis.dundun_stay_points_oil_station_info
    //    spark.sql(sql)
//    logger.error("已更新最新吨吨加油站信息")

    val sql2 =
      s"""
         |select
         |  *
         |from
         |  dm_gis.dundun_stay_points_oil_station_info_week_tmp
         |where
         |  inc_day='${inc_day}'
       """.stripMargin

    val df = spark.sql(sql2)
    val sourceRdd = SparkUtils.getDfToJson(spark,df)
    sourceRdd

  }

  def getTrajRdd(spark: SparkSession, inc_day: String,ak:Int) = {

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.dundun_inner_outer_traj_info
         |where
         |  inc_day= '${inc_day}'
         |and PMOD(hash(un), 40) = '${ak}'
       """.stripMargin

    val frame = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJsonNoCache(frame).map(x => {

      val un = JSONUtils.getJsonValue(x,"un","-")
      (un,x)
    })
    val sourceRddNew = sourceRdd.partitionBy(new RangePartitioner(200,sourceRdd)).map(_._2)
//      .persist(StorageLevel.DISK_ONLY)
//    val sourceRddNew = sourceRdd.partitionBy(new MyPartitioner(1000)).map(_._2).persist(StorageLevel.DISK_ONLY)

//    sourceRdd.unpersist()


    sourceRddNew
  }



  /**
    * 1.0 展开停留点
    * @param sourceRdd
    * @return
    */
  def getRejectFlatMapRdd(sourceRdd: RDD[JSONObject]) = {

    val rejectFlatMapRdd = sourceRdd.flatMap(x => {

      val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
      val tl_index = JSONUtils.getJsonValue(x,"tl_index","")
      val tl_time_period = JSONUtils.getJsonValue(x,"tl_time_periods","")
      val tl_durations = JSONUtils.getJsonValue(x,"tl_durations","")
      val tl_road = JSONUtils.getJsonValue(x,"tl_road","")
      val tl_roadclass = JSONUtils.getJsonValue(x,"tl_roadclass","")
      val tl_link = JSONUtils.getJsonValue(x,"tl_link","")
      val tl_links = JSONUtils.getJsonValue(x,"tl_links","")
      val tl_length = JSONUtils.getJsonValue(x,"tl_length","")

      val un = x.getString("un")
      val carrier_name = x.getString("carrier_name")
      val date = x.getString("date")

      // TODO: 将字符串全部转换为数组 tl_stay_points、tl_index、tl_time_period、tl_durations、tl_road、tl_roadclasss、tl_link、tl_links、tl_length

      var tl_stay_points_array =
        if (StringUtils.nonEmpty(tl_stay_points)){
          tl_stay_points.split("\\|")
        } else {
          new Array[String](0)
        }

      if (tl_stay_points_array.size > 20000) tl_stay_points_array = tl_stay_points_array.slice(0,19998)

      var tl_index_array =
        if (StringUtils.nonEmpty(tl_index)){
          tl_index.split("\\|")
        } else {
          new Array[String](0)
        }
      if (tl_index_array.size > 20000) tl_index_array = tl_index_array.slice(0,19998)

      var tl_time_periods_array =
        if (StringUtils.nonEmpty(tl_time_period)){
          tl_time_period.replace("[","").replace("]","").split(",")
        } else {
          new Array[String](0)
        }
      if (tl_time_periods_array.size > 20000) tl_time_periods_array = tl_time_periods_array.slice(0,19998)

      var tl_durations_array =
        if (StringUtils.nonEmpty(tl_durations)){
          tl_durations.replace("[","").replace("]","").split(",")
        } else {
          new Array[String](0)
        }
      if (tl_durations_array.size > 20000) tl_durations_array = tl_durations_array.slice(0,19998)

      var tl_roads_array =
        if (StringUtils.nonEmpty(tl_road)){
          tl_road.split("\\|")
        } else {
          new Array[String](0)
        }

      if (tl_roads_array.size > 20000) tl_roads_array = tl_roads_array.slice(0,19998)


      var tl_roadclass_array =
        if (StringUtils.nonEmpty(tl_roadclass)){
          tl_roadclass.split("\\|")
        } else {
          new Array[String](0)
        }
      if (tl_roadclass_array.size > 20000) tl_roadclass_array = tl_roadclass_array.slice(0,19998)


      var tl_link_array =
        if (StringUtils.nonEmpty(tl_link)){
          tl_link.split("\\|")
        } else {
          new Array[String](0)
        }
      if (tl_link_array.size > 20000) tl_link_array = tl_link_array.slice(0,19998)


      var tl_links_array =
        if (StringUtils.nonEmpty(tl_links)){
          tl_links.split("\\|")
        } else {
          new Array[String](0)
        }
      if (tl_links_array.size > 20000) tl_links_array = tl_links_array.slice(0,29999)

      var tl_length_array =
        if (StringUtils.nonEmpty(tl_length)){
          tl_length.split("\\|")
        } else {
          new Array[String](0)
        }
      if (tl_length_array.size > 20000) tl_length_array = tl_length_array.slice(0,29999)


      val sum_dist = JSONUtils.getJsonValue(x,"sum_dist","")
      var sum_dist_array =
        if (StringUtils.nonEmpty(sum_dist)){
          sum_dist.split("\\|")
        } else {
          new Array[String](0)
        }
      if (sum_dist_array.size > 20000) sum_dist_array = sum_dist_array.slice(0,19998)


      x.remove("tl_stay_points")
      x.remove("tl_index")
      x.remove("tl_time_periods")
      x.remove("tl_durations")
      x.remove("tl_road")
      x.remove("tl_roadclass")
      x.remove("tl_link")
      x.remove("tl_links")
      x.remove("tl_length")

      x.remove("jp_time")
      x.remove("sum_dist")


//      val jp_status = JSONUtils.getJsonValue(x,"jp_status","")
//      val jp_coords = JSONUtils.getJsonValue(x,"jp_coords","")
//      val jp_swid = JSONUtils.getJsonValue(x,"jp_swid","")

      val buffer = new ArrayBuffer[JSONObject]()

      if (!tl_stay_points_array.isEmpty && tl_stay_points_array.length > 0){

        for (i <- (0 until(tl_stay_points_array.length))){

          val json  = new JSONObject()
          json.fluentPutAll(x)
          val tl_stay_points = tl_stay_points_array(i)
          val tl_index = try {tl_index_array(i).toInt} catch {case e:Exception => 0}
          val tl_time_period = tl_time_periods_array(i)
          val tl_durations = tl_durations_array(i)
          val tl_road = try {tl_roads_array(i)} catch {case e:Exception => ""}
          val tl_roadclass = tl_roadclass_array(i)
          val tl_link = tl_link_array(i)
          val tl_links = tl_links_array(i)
          val tl_length = tl_length_array(i)
          val start_road_dist = try {sum_dist_array(tl_index).toDouble} catch {case e:Exception => 0}
          val end_road_dist = try {math.abs(sum_dist_array(sum_dist_array.size -1).toDouble - start_road_dist)} catch {case e:Exception => 0}

          val plan_arrive_tm = JSONUtils.getJsonValue(x,"plan_arrive_tm","")
          val plan_depart_tm = JSONUtils.getJsonValue(x,"plan_depart_tm","")

          //          val plan_run_time2 = try {DateTimeUtil.parseFtTimeMin(plan_arrive_tm,plan_depart_tm,"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm:ss").toInt} catch {case e:Exception => 0}
          val tl_sort_num = i

          json.put("tl_stay_points",tl_stay_points)
          json.put("tl_index",tl_index)
          json.put("tl_time_period",tl_time_period)
          json.put("tl_durations",tl_durations)
          json.put("tl_road",tl_road)
          json.put("tl_roadclass",tl_roadclass)
          json.put("tl_link",tl_link)
          json.put("tl_links",tl_links)
          json.put("tl_length",tl_length)
          json.put("start_road_dist",start_road_dist)
          json.put("end_road_dist",end_road_dist)
          json.put("tl_sort_num",tl_sort_num)

          json.put("un",un)
          json.put("carrier_name",carrier_name)

          buffer.append(json)
        }
      }

      buffer

    })
//      .persist(StorageLevel.DISK_ONLY)


    rejectFlatMapRdd
  }


  /**
    * 剔除异常停留点
    * @param rejectFlatMapRdd
    * @return
    */

  def getCalRejectRdd1(rejectFlatMapRdd: RDD[JSONObject]) = {

    val calRejectRdd1 = rejectFlatMapRdd
      .map(x => {

        val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
        val tl_link = JSONUtils.getJsonValue(x,"tl_link","")
        val tl_index = JSONUtils.getJsonValue(x,"tl_index","")


        // TODO: 将jp_status，jp_coords，jp_swid 转换为数组
        val jp_status = JSONUtils.getJsonValue(x,"jp_status","")
        val jp_coords = JSONUtils.getJsonValue(x,"jp_coords","")
        val jp_swid = JSONUtils.getJsonValue(x,"jp_swid","")

        var jp_status_array =
          if (StringUtils.nonEmpty(jp_status)){
            jp_status.split("\\|")
          } else {
            new Array[String](0)
          }
        if (jp_status_array.size > 20000) jp_status_array = jp_status_array.slice(0,19998)

        var jp_coords_array =
          if (StringUtils.nonEmpty(jp_coords)){
            jp_coords.split("\\|")
          } else {
            new Array[String](0)
          }
        if (jp_coords_array.size > 20000) jp_coords_array = jp_coords_array.slice(0,19998)

        var jp_swid_array =
          if (StringUtils.nonEmpty(jp_swid)){
            jp_swid.split("\\|")
          } else {
            new Array[String](0)
          }
        if (jp_swid_array.size > 20000) jp_swid_array = jp_swid_array.slice(0,19998)

        // TODO: 标记mark
        var mark = 3
        var index = -1


        if (!jp_coords_array.isEmpty && jp_coords_array.contains(tl_stay_points)) {
          //找到相同的点，输出该点在jp_coords中的索引位置idx1
          val i = jp_coords_array.indexOf(tl_stay_points)
          index = i
          mark = 1
        }

        if (mark == 3 && !jp_swid_array.isEmpty && jp_swid_array.contains(tl_link)) {
          //如果在jp_coords_array未找到，用停留点对应的link即 link 字段，循环判断和jp_swid中的每个link是否相同，找到相同的link，输出该link在jp_swid中的索引位置idx2
          index = jp_swid_array.indexOf(tl_link)
          mark = 2
        }

        if (mark != 3 && index >= 1 && index != jp_status_array.size-1){


          // TODO: 判断是否是第一个点、最后一个点
          // 如果已找到索引位置，则找索引位置左右两边最近的点
          val jp_status_array0 = if (index < jp_status_array.length) jp_status_array.slice(0,index) else new Array[String](0)
          var stratIndex = jp_status_array0.lastIndexOf("0")

          var startTag =  try {if (jp_swid_array.size >= 0 && StringUtils.nonEmpty(tl_link) && (jp_swid_array(stratIndex).equals(tl_link) ||
            jp_swid_array(stratIndex).equals("0"))) 0 else 1} catch {case e:Exception => 1}

          for ( j <- (0 until(stratIndex)).reverse if (startTag == 0)){
            try {
              stratIndex = if (jp_status_array0(j).equals("0")) j else stratIndex
              startTag = if (jp_swid_array.size >= 0 && StringUtils.nonEmpty(tl_link) && (jp_swid_array(stratIndex).equals(tl_link) ||
                jp_swid_array(stratIndex).equals("0"))) 0 else 1
            }catch {
              case e:Exception => startTag = 1
            }
          }

          val jp_status_array1 = if (index + 1 < jp_status_array.length) jp_status_array.slice(index+1,jp_status_array.length) else new Array[String](0)
          var endIndex = jp_status_array1.indexOf("0") + index
          //        var endIndex = jp_status_array1.indexOf("0")

          var endTag = try { if (jp_swid_array.size >= 0 && StringUtils.nonEmpty(tl_link) && (jp_swid_array(endIndex).equals(tl_link) ||
            jp_swid_array(endIndex).equals("0"))) 0 else 1} catch {case e:Exception => 1}

          for ( j <- ((endIndex+1) until(jp_status_array.size)) if (endTag == 0)){
            try {
              endIndex = if (jp_status_array(j).equals("0")) j else endIndex
              endTag = if (jp_swid_array.size >= 0 && StringUtils.nonEmpty(tl_link) && (jp_swid_array(endIndex).equals(tl_link) ||
                jp_swid_array(endIndex).equals("0"))) 0 else 1
            }catch {
              case e:Exception => startTag = 1
            }
          }

          if (stratIndex != -1 && endIndex != -1){

            val start_x = try {jp_coords_array(stratIndex).split(",")(0).toDouble} catch {case e:Exception => 0.0}
            val start_y = try {jp_coords_array(stratIndex).split(",")(1).toDouble} catch {case e:Exception => 0.0}
            val end_x = try {jp_coords_array(endIndex).split(",")(0).toDouble} catch {case e:Exception => 0.0}
            val end_y = try {jp_coords_array(endIndex).split(",")(1).toDouble} catch {case e:Exception => 0.0}
            val dist = DistanceTool.getGreatCircleDistance(start_x,start_y,end_x,end_y)

            if (dist > 4000) mark = 6

          }

        }

        x.put("mark",mark)

        x
      }).filter(x => {
      val mark = x.getIntValue("mark")
      mark != 6
    }).persist(StorageLevel.DISK_ONLY)

    calRejectRdd1

  }


  /**
    * 加油站停留识别
    *
    * @param epidemicIndentifyRdd
    */

  def getFillingStation(spark: SparkSession, epidemicIndentifyRdd: RDD[JSONObject],oilStationInfoRdd:RDD[JSONObject], inc_day: String) = {

    val fillingPointDf = oilStationInfoRdd.map(x => {
      val index = x.getString("pid")
      //      val name_chn = x.getString(2)
      //      val point_name = index + "_" + name_chn
      val x_coord = x.getString("lng")
      val y_coord = x.getString("lat")
      val x_coords = x_coord.toDouble
      val y_coords = y_coord.toDouble
      (index,x_coords,y_coords)
    }).collect()

    val fillingList = spark.sparkContext.broadcast(fillingPointDf)


    val fillingStationRdd = epidemicIndentifyRdd.mapPartitionsWithIndex((index, iter) => {

      // 将加油站建立为rtree
      val tuplesList = fillingList.value.toList
      var tree:RTree[String,Point] = RTree.star().maxChildren(6).create()
      tuplesList.map(obj => {
        val point_name =obj._1
        val x_coord =obj._2
        val y_coord =obj._3
        tree = tree.add(point_name, Geometries.point(x_coord, y_coord))
      })

      iter.map(x => {
        val tl_stay_points = JSONUtils.getJsonValue(x,"tl_stay_points","")
        val stay_point_x = try {tl_stay_points.split(",")(0).toDouble} catch {case e:Exception =>  0.0}
        val stay_point_y = try {tl_stay_points.split(",")(1).toDouble} catch {case e:Exception =>  0.0}
        var if_jyz = 0
        try {

          val dis = getQuyu50Distance(stay_point_x,stay_point_y,2000)

          val points = tree.nearest(Geometries.point(stay_point_x, stay_point_y), dis, 1).toList().toBlocking().single().get(0)
          val jyz_x_1 = points.geometry().x()
          val jyz_y_1 = points.geometry().y()
          val pid = points.value()

          val dist = DistanceTool.getGreatCircleDistance(stay_point_x, stay_point_y, jyz_x_1, jyz_y_1)

          if_jyz = if (dist < 150) 1 else 0

//          if (dist < 150) {
            x.put("jyz_coords", jyz_x_1.toString + "," + jyz_y_1.toString)
            x.put("jyz_dis", dist)
            x.put("pid", pid)
//          }
        }catch {
          case e:Exception => e.printStackTrace()
        }
        x.put("if_jyz", if_jyz)
        x
      })

    }).persist(StorageLevel.DISK_ONLY)

    fillingStationRdd

  }


  //dis单位千米
  def getQuyu50Distance(x: Double, y: Double, dis: Double) = {
    val r = 6371 //地球半径千米
    val latitude = y
    val longitude = x
    var dlng = 2 * math.asin(math.sin(dis / (2 * r)) / math.cos(latitude * math.Pi / 180))
    dlng = dlng * 180 / math.Pi //角度转为弧度
    var dlat = dis / r
    dlat = dlat * 180 / math.Pi
    val minlat = latitude - dlat
    val maxlat = latitude + dlat
    val minlng = longitude - dlng
    val maxlng = longitude + dlng
    // println("dd:"+DistanceTool.getGreatCircleDistance(minlng,minlat,x,y))
    math.sqrt(dlng*dlng+dlat*dlat)
  }



  def getJoinStaionInfo(spark: SparkSession, fillingStaionRdd: RDD[JSONObject],oilStationInfoRdd:RDD[JSONObject], inc_day: String) = {

    val rightRdd = oilStationInfoRdd.map(obj => {
      val id = JSONUtils.getJsonValue(obj,"pid","")
      (id,obj)
    })


    val joinStationRdd = fillingStaionRdd.map(x => {
      val id = JSONUtils.getJsonValue(x,"pid","")
      (id,x)
    }).leftOuterJoin(rightRdd).map(x => {

      val left = x._2._1
      val rightOption = x._2._2

      if (!rightOption.isEmpty) {
        val rightJo = rightOption.get
        left.fluentPutAll(rightJo)
      }
      left

    })

    logger.error("joinStationRdd的数据量为：" + joinStationRdd.count())

    joinStationRdd

  }


  def saveTabel2(spark: SparkSession, inc_day: String, stayPointMarkTypeRdd: RDD[JSONObject],ak:String) = {

    import spark.implicits._

    val saveTable = "dm_gis.dundun_match_oil_station2"

    val stayPoinTableRdd = stayPointMarkTypeRdd.map(x => {

      val un = x.getString("un")
      val carrier_name= x.getString("carrier_name")
      val owner_id= x.getString("owner_id")
      val jp_swid= ""
      val jp_coords= ""
      val jp_time= ""
      val jp_status= ""
      val sum_dist= ""
      val tl_time_periods= x.getString("tl_time_period")
      val tl_durations= x.getString("tl_durations")
      val tl_stay_points= x.getString("tl_stay_points")
      val tl_road= x.getString("tl_road")
      val tl_roadclass= x.getString("tl_roadclass")
      val tl_link= x.getString("tl_link")
      val tl_links= x.getString("tl_links")
      val tl_length= x.getString("tl_length")
      val source= x.getString("source")
      val date = if (source.equals("sf")) x.getString("date") else ""

      val jyz_coords = x.getString("jyz_coords")
      val jyz_dis = x.getString("jyz_dis")
      val pid = x.getString("pid")
      val if_jyz = x.getString("if_jyz")


      (date,un,carrier_name,owner_id,jp_swid,jp_coords,jp_time,jp_status,sum_dist,tl_time_periods,tl_durations,tl_stay_points,
        tl_road,tl_roadclass,tl_link,tl_links,tl_length,source,jyz_coords,jyz_dis,pid,if_jyz)
    }).toDF("date","vehicle_serial","carrier_name","owner_id","jp_swid","jp_coords","jp_time","jp_status","sum_dist",
      "tl_time_periods","tl_durations","tl_stay_points","tl_road","tl_roadclass","tl_link","tl_links","tl_length","source","jyz_coords","jyz_dis","pid","if_jyz")
      .withColumn("inc_day",lit(inc_day)).withColumn("ak",lit(ak)).repartition(20).write.mode(SaveMode.Overwrite).insertInto(saveTable)
  }


  def saveTabelSource1(sourceRdd1: RDD[JSONObject], spark: SparkSession, inc_day: String,hash_ak:String) = {

    import spark.implicits._
    val saveTableName = "dm_gis.dundun_outer_traj_info"

    sourceRdd1.map(x => {
      val un= x.getString("un")
      val carrier_name= x.getString("carrier_name")
      val owner_id= x.getString("owner_id")
      val jp_swid= x.getString("jp_swid")
      val jp_coords= x.getString("jp_coords")
      val jp_status= x.getString("jp_status")
      val jp_time= x.getString("jp_time")
      val sum_dist= x.getString("sum_dist")
      val tl_time_periods= x.getString("tl_time_periods")
      val tl_durations= x.getString("tl_durations")
      val tl_stay_points= x.getString("tl_stay_points")
      val tl_road= x.getString("tl_road")
      val tl_roadclass= x.getString("tl_roadclass")
      val tl_link= x.getString("tl_link")
      val tl_links= x.getString("tl_links")
      val tl_length= x.getString("tl_length")
      val source= x.getString("source")
      val date = ""

      traj(un,carrier_name,owner_id,jp_swid,jp_coords,jp_status,jp_time,sum_dist,
        tl_time_periods,tl_durations,tl_stay_points,tl_road,tl_roadclass,tl_link,tl_links,tl_length,source,date)
    }).repartition(100).toDF().withColumn("inc_day",lit(inc_day)).withColumn("hash_ak",lit(hash_ak)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)


  }

  def processSourceRdd2(spark: SparkSession, inc_day: String,ak:Int) = {

    // TODO: 更新油站数据并获取最新数据(待改字段名)
    val oilStationInfoRdd = calOilStationRdd(spark,inc_day)

    // TODO: 获取轨迹停留点
    val trajHisFixRdd = getTrajRdd(spark,inc_day,ak)

    // TODO: 展开轨迹停留点
    val rejectFlatMapRdd = getRejectFlatMapRdd(trajHisFixRdd)

    // TODO: 剔除异常停留点
    val calRejectRdd = getCalRejectRdd1(rejectFlatMapRdd)
    logger.error("calRejectRdd的数据量为:" + calRejectRdd.count())
    calRejectRdd.take(1).foreach(println(_))

    // TODO: 计算加油站停留识别
    val fillingStaionRdd = getFillingStation(spark,calRejectRdd,oilStationInfoRdd,inc_day)
    fillingStaionRdd.take(2).foreach(println(_))
    saveTabel2(spark,inc_day,fillingStaionRdd,ak.toString)

    logger.error("写入外源表" + inc_day + "ak为：" + ak.toString + "成功")
    SparkUtils.clearCache(spark)
    spark.sqlContext.clearCache()

    val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
    ds.foreach(x => {
      x._2.unpersist()
    })
  }





  def staStat(spark: SparkSession, inc_day: String): Unit = {

//    val akList = range(0, 10)
    val akList = range(0, 40)

    for (ak <- akList){
      processSourceRdd2(spark, inc_day,ak)
    }


//    // TODO: 将识别到的加油站关联加油信息表
//    val joinStationInfoRdd = getJoinStaionInfo(spark,fillingStaionRdd,oilStationInfoRdd,inc_day)

//    // TODO: 存储为关联结果表
//    saveToJoinInfoTable(spark,inc_day,joinStationInfoRdd)

  }

  def start(inc_day: String): Unit = {
    val spark = Spark.getSparkSession(appName)
    spark.sparkContext.setLogLevel("ERROR")

    staStat(spark, inc_day)

  }

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
//    val inc_day =DateTimeUtil.getCurDayYesterDay()

    logger.error("当前计算日期为：" + args(0))

//    val inc_day = "20221224"
    logger.error("当前计算日期为：" + inc_day)

    start(inc_day)

    logger.error("统计结束")

  }



}
