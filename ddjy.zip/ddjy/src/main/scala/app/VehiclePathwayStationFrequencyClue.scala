package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SparkUtils, SparkWrite}

/**
 * @Description:车辆途径油站频次线索挖掘(粤运或顺丰)
 * 需求方：刘芮 01412988
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:422、555
 * 任务名称：粤运车辆经过油站频次表、顺丰车辆经过油站频次表
 * 依赖任务：经验库stat_swid_count mysql导入hive 475、顺丰经验库stat_swid_count mysql导入hive 553
 * 数据源：ddjy_stat_swid_count、ddjy_station_near_road_clue_di、ddjy_stat_swid_count_sf_wi
 * 调用服务地址：
 * 数据结果：ddjy_station_pathway_statistic_clue_di、ddjy_station_pathway_statistic_clue_sf_di
 */
object VehiclePathwayStationFrequencyClue {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def linkidCountSwid(spark: SparkSession, incDay: String, inputTable: String) = {
    val stationNearRoadSql=
      s"""
        |select
        |*
        |from dm_gis.ddjy_station_near_road_clue_di
        |where inc_day='$incDay'
        |and cast(line_vertical_dist as bigint)<=150
        |and overhead=0
        |and linktype=0
        |and formway in(1,5,6,7,15)
        |and !(gaslocationtype=0 and roadclass=0)
        |""".stripMargin
    val stationNearRoadRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, stationNearRoadSql).map(obj => {
      (obj.getString("swid"), obj)
    })
    val statSwidCountSql=
      s"""
        |select *
        |from dm_gis.ddjy_stat_swid_count
        |where inc_day='$incDay'
        |""".stripMargin
    val joinLinkidCountSwidRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, statSwidCountSql,2000).map(obj => {
      (obj.getString("swid"), obj)
    }).join(stationNearRoadRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.fluentPutAll(rightObj)
      leftObj
    }).filter(obj=>{
      val dir: String = obj.getString("dir")
      val direct: String = obj.getString("direct")
      val side: String = obj.getString("side")
      (dir=="1" && direct=="3" && side=="1") || (dir=="0" && direct=="3" && side=="2") || (dir=="0" && direct=="1" && side=="2")
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    joinLinkidCountSwidRdd
  }

  def stationRoadFrequency(spark: SparkSession, joinLinkidCountSwidRdd: RDD[JSONObject], incDay: String, outputTable: String) = {
    import spark.implicits._
    val direct3Rdd: RDD[JSONObject] = joinLinkidCountSwidRdd.filter(obj => {
      obj.getString("direct") == "3"
    }).map(obj => {
      val poiid: String = obj.getString("poiid")
      val trackno: String = obj.getString("trackno")
      val swid: String = obj.getString("swid")
      ((poiid, trackno, swid), obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.maxBy(_.getString("dir"))
      val count: Int = list.map(_.getIntValue("count")).sum
      tmpObj.put("count", count)
      tmpObj
    })
    val vehiclePathwayStationFrequencyDf: DataFrame = joinLinkidCountSwidRdd.filter(obj => {
      obj.getString("direct") != "3"
    }).union(direct3Rdd).map(obj => {
      ((obj.getString("poiid"), obj.getString("trackno")), obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val fws: List[String] = list.map(_.getString("formway")).distinct
      val main_road1 = List("1")
      val main_road615 = List("6", "15")
      val main_road = List("1", "6", "15")
      val auxiliary_road = List("5", "7")
      var main_road_fre = 0
      var auxiliary_road_fre = 0
      val main_road_list: List[JSONObject] = list.filter(json => {
        val formway: String = json.getString("formway")
        main_road.contains(formway)
      })
      val auxiliary_road_list: List[JSONObject] = list.filter(json => {
        val formway: String = json.getString("formway")
        auxiliary_road.contains(formway)
      })
      if (fws.intersect(main_road1).nonEmpty && fws.intersect(auxiliary_road).nonEmpty) {
        main_road_fre = main_road_list.maxBy(_.getIntValue("count")).getIntValue("count")
        auxiliary_road_fre = auxiliary_road_list.maxBy(_.getIntValue("count")).getIntValue("count")
      } else if (fws.intersect(main_road1).isEmpty && fws.intersect(main_road615).nonEmpty && fws.intersect(auxiliary_road).nonEmpty) {
        main_road_fre = main_road_list.sortBy(x => (
          x.getDoubleValue("line_vertical_dist"), x.getIntValue("count")
        ))(Ordering Tuple2(Ordering.Double, Ordering.Int.reverse)).head.getIntValue("count")
        auxiliary_road_fre = auxiliary_road_list.maxBy(_.getIntValue("count")).getIntValue("count")
      } else if (fws.intersect(main_road1).isEmpty && fws.intersect(main_road615).isEmpty && fws.intersect(auxiliary_road).nonEmpty) {
        auxiliary_road_fre = auxiliary_road_list.maxBy(_.getIntValue("count")).getIntValue("count")
      } else if (fws.intersect(main_road1).nonEmpty && fws.intersect(auxiliary_road).isEmpty) {
        main_road_fre = main_road_list.maxBy(_.getIntValue("count")).getIntValue("count")
      } else if (fws.intersect(main_road1).isEmpty && fws.intersect(main_road615).nonEmpty && fws.intersect(auxiliary_road).isEmpty) {
        main_road_fre = main_road_list.sortBy(x => (
          x.getDoubleValue("line_vertical_dist"), x.getIntValue("count")
        ))(Ordering Tuple2(Ordering.Double, Ordering.Int.reverse)).head.getIntValue("count")
      }
      val priority_tj: Int = main_road_fre + auxiliary_road_fre
      val tmpObj: JSONObject = list.maxBy(_.getString("trackno"))
      tmpObj.put("priority_tj", priority_tj)
      tmpObj
    }).map(obj => {
      VehiclePathwayStationFrequency(
        obj.getString("grpid"),
        obj.getString("pid"),
        obj.getString("poiid"),
        obj.getString("srcid"),
        obj.getString("stationname"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("citycode"),
        obj.getString("district"),
        obj.getString("addr"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperatestatus"),
        obj.getString("trackno"),
        obj.getString("priority_tj"),
        obj.getString("priority_zb"),
        obj.getString("line_dist"),
        obj.getString("dh_dist"),
        obj.getString("dh_dist_back"),
        obj.getString("dh_dist_sum"),
        obj.getString("gaslocationtype")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,vehiclePathwayStationFrequencyDf,"inc_day",incDay,"dm_gis.ddjy_station_pathway_statistic_clue_di")
  }

  def execute(incDay: String, inputTable:String, outputTable:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取linkdiCount表和swid映射表
    val joinLinkidCountSwidRdd = linkidCountSwid(spark, incDay,inputTable)
    //统计加油站绑定道路的途径频次
    stationRoadFrequency(spark,joinLinkidCountSwidRdd,incDay,outputTable)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val inputTable: String = args(1)
    val outputTable: String = args(2)
    execute(incDay,inputTable,outputTable)
    //execute()
    logger.error("======>>>>>>VehiclePathwayStationFrequencyClue Execute Ok")
  }

  case class VehiclePathwayStationFrequency(
                                            grpid:String,
                                            pid:String,
                                            poiid:String,
                                            srcid:String,
                                            stationname:String,
                                            province:String,
                                            city:String,
                                            citycode:String,
                                            district:String,
                                            addr:String,
                                            lng:String,
                                            lat:String,
                                            cooperatestatus:String,
                                            trackno:String,
                                            priority_tj:String,
                                            priority_zb:String,
                                            line_dist:String,
                                            dh_dist:String,
                                            dh_dist_back:String,
                                            dh_dist_sum:String,
                                            gaslocationtype:String
                                           )

}
