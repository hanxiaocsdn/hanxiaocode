package app

import java.text.SimpleDateFormat
import java.util.Calendar

import app.CarrierRlstMonth.logger
import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SparkUtils, SparkWrite}

/**
 * @Description:油站线索月维度表
 * 需求人员：周韵筹 01425211
 * @Author: lixiangzhi 01405644
 * @Date:20231207
 * 任务id:1093
 * 任务名称：油站线索月维度表
 * 依赖任务：756
 * 数据源：
 * 调用服务地址：
 * 数据结果：dm_ddjy_gas_station_rlst_di_month
 */
object GasStationRlstMonth {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readGasStationRlst(spark: SparkSession, incDay: String) = {
    val lastMonthDay: String = DateUtil.getDateStr(incDay, -30, "")
    val gasStationRlstSql=
      s"""
        |select
        |gas_id,name,adcode,province,city,district,addr,x,y,telephone,brand,gas_type,src,cooperate_status,circle_id,gas_circle_id,inc_day,task_batch,
        |update_time,task_count
        |from dm_gis.dm_ddjy_gas_station_rlst_di
        |where inc_day>='${lastMonthDay}' and inc_day<='${incDay}'
        |""".stripMargin
    val gasStationRlstMidRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, gasStationRlstSql).groupBy(_.getString("gas_id")).map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.maxBy(_.getString("inc_day"))
      val task_count: Int = list.map(_.getIntValue("task_count")).sum
      val biz_day: String = tmpObj.getString("inc_day")
      tmpObj.put("task_count", task_count)
      tmpObj.put("biz_day", biz_day)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站线索表根据gas_id去重后的数据量:"+gasStationRlstMidRdd.count())
    //计算task_batch
    val task_batch_min: String = gasStationRlstMidRdd.map(obj => {
      val task_batch: String = obj.getString("task_batch")
      task_batch
    }).min().split("-")(0)
    val task_batch_max: String = gasStationRlstMidRdd.map(obj => {
      val task_batch: String = obj.getString("task_batch")
      task_batch
    }).max().split("-")(1)
    val gasSatationInfoSql=
      """
        |select poiid,stationname as name,adcode,province,city,district,addr,
        |lng as x,
        |lat as y,
        |tel as telephone,
        |querybrandid as brand,
        |management_model as gas_type,src,
        |cooperatestatus as cooperate_status
        |from dm_gis.dm_ddjy_gas_station_info_di
        |where delflag = '0'
        |""".stripMargin
    val gasSatationInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, gasSatationInfoSql).map(obj => {
      (obj.getString("poiid"), obj)
    })
    val gasStationRlstRdd: RDD[(String, JSONObject)] = gasStationRlstMidRdd.map(obj => {
      obj.put("task_batch", task_batch_min + "-" + task_batch_max)
      (obj.getString("gas_id"), obj)
    }).leftOuterJoin(gasSatationInfoRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      (obj._1,leftObj)
    })
    gasStationRlstMidRdd.unpersist()
    gasStationRlstRdd
  }

  def gasStationRlstMonthCollect(spark: SparkSession, gasStationRlstRdd: RDD[(String, JSONObject)], incDay: String) = {
    import spark.implicits._
    val lastMonthDay: String = DateUtil.getDateStr(incDay, -30, "")
    //计算carrier_count
    val gasCarrierMergeMonthSql=
      s"""
         |select
         |gas_id,
         |count(distinct carrier_id) as carrier_count
         |from dm_gis.dm_ddjy_gas_carrier_merge_di_month
         |where inc_day='$incDay'
         |group by gas_id
         |""".stripMargin
    val gasCarrierMergeMonthRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, gasCarrierMergeMonthSql).map(obj => {
      (obj.getString("gas_id"), obj)
    })
    //计算vehicle_count
    val gasCarMergeSql=
      s"""
         |select
         |gas_id,
         |count(distinct vehicle_no) as vehicle_count
         |from dm_gis.dm_ddjy_gas_car_merge_di
         |where inc_day>='${lastMonthDay}' and inc_day<='${incDay}'
         |group by gas_id
         |""".stripMargin
    val gasCarMergeRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, gasCarMergeSql).map(obj => {
      (obj.getString("gas_id"), obj)
    })
    //计算oil_sum_per_day
    val cluepointMonthSql=
      s"""
         |select
         |clue_id,clue_id,oil_sum,task_day_count
         |from dm_gis.dm_ddjy_cluepoint_rlst_di_month
         |where inc_day='$incDay'
         |""".stripMargin
    val cluepointMonthRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, cluepointMonthSql).map(obj => {
      (obj.getString("clue_id"), obj)
    })
    val gasStationMonthSql=
      s"""
        |select
        |gas_id,clue_id
        |from dm_gis.dwd_ddjy_clue_rel_gas_station_di_month
        |where inc_day='$incDay'
        |""".stripMargin
    val gasStationMonthRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, gasStationMonthSql,2000).groupBy(_.getString("gas_id")).flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val clue_count: Int = list.map(_.getString("clue_id")).distinct.size
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("clue_count", clue_count)
        json
      })
      tmpList.iterator
    }).map(obj => {
      (obj.getString("clue_id"), obj)
    }).leftOuterJoin(cluepointMonthRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).groupBy(_.getString("gas_id")).map(obj=>{
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.maxBy(_.getIntValue("clue_count"))
      val oil_sum: Double = list.map(_.getDoubleValue("oil_sum")).sum
      val task_day_count: Int = list.map(_.getIntValue("task_day_count")).sum
      val oil_sum_per_day: Double = oil_sum / task_day_count
      tmpObj.put("oil_sum",oil_sum)
      tmpObj.put("task_day_count",task_day_count)
      tmpObj.put("oil_sum_per_day",oil_sum_per_day)
      (obj._1,tmpObj)
    })
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance.getTime)
    val gasStationRlstMonthDf: DataFrame = gasStationRlstRdd.leftOuterJoin(gasCarrierMergeMonthRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      (obj._1,leftObj)
    }).leftOuterJoin(gasCarMergeRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      (obj._1,leftObj)
    }).leftOuterJoin(gasStationMonthRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).map(obj => {
      CaseGasStationRlstMonth(
        obj.getString("gas_id"),
        obj.getString("task_batch"),
        obj.getString("name"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("addr"),
        obj.getString("x"),
        obj.getString("y"),
        obj.getString("telephone"),
        obj.getString("brand"),
        obj.getString("gas_type"),
        obj.getString("src"),
        obj.getString("clue_count"),
        obj.getString("task_count"),
        obj.getString("vehicle_count"),
        obj.getString("carrier_count"),
        obj.getString("oil_sum_per_day"),
        obj.getString("cooperate_status"),
        obj.getString("circle_id"),
        update_time,
        obj.getString("carrier_province"),
        obj.getString("carrier_city"),
        obj.getString("gas_circle_id"),
        obj.getString("biz_day")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,gasStationRlstMonthDf,"inc_day",incDay,"dm_gis.dm_ddjy_gas_station_rlst_di_month",50)


  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取dm_ddjy_gas_station_rlst_di
    val gasStationRlstRdd: RDD[(String, JSONObject)] = readGasStationRlst(spark, incDay)
    //汇总各指标
    gasStationRlstMonthCollect(spark,gasStationRlstRdd,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseGasStationRlstMonth(
                                      gas_id:String,
                                      task_batch:String,
                                      name:String,
                                      adcode:String,
                                      province:String,
                                      city:String,
                                      district:String,
                                      addr:String,
                                      x:String,
                                      y:String,
                                      telephone:String,
                                      brand:String,
                                      gas_type:String,
                                      src:String,
                                      clue_count:String,
                                      task_count:String,
                                      vehicle_count:String,
                                      carrier_count:String,
                                      oil_sum_per_day:String,
                                      cooperate_status:String,
                                      circle_id:String,
                                      update_time:String,
                                      carrier_province:String,
                                      carrier_city:String,
                                      gas_circle_id:String,
                                      biz_day:String

                                 )

}
