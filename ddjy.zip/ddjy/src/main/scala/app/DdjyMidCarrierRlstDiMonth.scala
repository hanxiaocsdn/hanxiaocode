package app

import common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import utils.{DateUtil,SparkUtils,StringUtils}

/**
 *需求名称：GIS-RSS-DDJY：【吨吨加油】聚合线索工艺需求_V1.2_01405644_李相志
 *需求方：周韵筹(01425211)
 *研发： 蔡国房(01420395)
 *任务创建时间：20231204
 *任务id：衡度平台 1083
 **/
object DdjyMidCarrierRlstDiMonth extends DataSourceCommon{

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkUtils.getSparkSession(className,"yarn")
    //获取T-1日期
    val inc_day: String = args(0)
    //取T-14日期,
    val last_thrity_day = DateUtil.getdaysBefore(inc_day,-35,"yyyyMMdd" ,"yyyyMMdd")

    val tableName  = "dm_gis.dm_ddjy_mid_carrier_rlst_di_month"

    val dm_ddjy_mid_carrier_rlst_di_Sql =
      s"""
         |
         |select legal_person_name,
         |		content,
         |		credit_code,
         |		carrier_province,
         |		carrier_city,
         |		carrier_id,
         |		carrier_name,
         |		carrier_status,
         |		carrier_tag,
         |		carrier_circle_id,
         |		register_vehicle_count,
         |		carrier_scale,
         |		carrier_suspected_address,
         |		carrier_priority,
         |		inc_day,
         |		oil_sum,
         |		sum(task_count)over(partition by carrier_id) as task_count,
         |		sum(task_day_count)over(partition by carrier_id) as task_day_count,
         |		plan_depart_tm_day_max,
         |		plan_depart_tm_day_min,
         |		dis_sum,
         |		sum(carrier_circle_task_count)over(partition by carrier_id) as carrier_circle_task_count,
         |		task_batch,
         |		row_number() over(partition by carrier_id order by inc_day desc) as rnk
         |	from  dm_gis.dm_ddjy_mid_carrier_rlst_di
         |	where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}'
         |
         |""".stripMargin

    logger.error("dm_ddjy_mid_carrier_rlst_di_Sql:"+dm_ddjy_mid_carrier_rlst_di_Sql)

    val dm_ddjy_mid_carrier_rlst_di_Df = spark.sql(dm_ddjy_mid_carrier_rlst_di_Sql).repartition(2000)


    logger.error("dm_ddjy_mid_carrier_rlst_di_Df 数据量: " + dm_ddjy_mid_carrier_rlst_di_Df.count() )

    val  dwd_ddjy_clue_vehicle_carrier_di_sql=
      s"""
         |	select actual_capacity_load,vehicle,
         |	clue_src,carrier_id,clue_id
         |	from dm_gis.dwd_ddjy_clue_vehicle_carrier_di  where and inc_day='${inc_day}'
         |
         |""".stripMargin

    logger.error("dwd_ddjy_clue_vehicle_carrier_di_sql:"+dwd_ddjy_clue_vehicle_carrier_di_sql)

    val  dwd_ddjy_clue_vehicle_carrier_di_df = spark.sql(dwd_ddjy_clue_vehicle_carrier_di_sql)


    logger.error("dwd_ddjy_clue_vehicle_carrier_di_df 数据量: " + dwd_ddjy_clue_vehicle_carrier_di_df.count())


    import org.apache.spark.sql.functions._
    import spark.implicits._


    // 计算 vehicle_load_count
    val  dwd_ddjy_clue_vehicle_carrier_di_rdd_vehicle_load = dwd_ddjy_clue_vehicle_carrier_di_df.rdd.map(row  =>{
      val carrier_id = row.getAs[String]("carrier_id")
      val actual_capacity_load = row.getAs[String]("actual_capacity_load")
      val rowkey = carrier_id +"_"+actual_capacity_load
      var countNum =0
      if(StringUtils.isEmpty(actual_capacity_load)){
        countNum =0
      }else{
        countNum =1
      }
      (rowkey, (row,countNum))
    }).reduceByKey((x,y) => {
      val vehicle_x  = x._1.getAs[String]("vehicle")
      val vehicle_y  = y._1.getAs[String]("vehicle")
      var countNum =0
      if(vehicle_x == vehicle_y){
        countNum =  x._2
      }else {
        countNum =  x._2+y._2
      }
      (x._1,countNum)
    }).map(x =>{
      val carrier_id =  x._2._1.getAs[String]("carrier_id")
      val vehicle_load_count =  x._2._2
      (carrier_id,vehicle_load_count)
    })

    val dwd_ddjy_clue_vehicle_carrier_di_df_vehicle_load =  spark.createDataset(dwd_ddjy_clue_vehicle_carrier_di_rdd_vehicle_load)
        .toDF("carrier_id","vehicle_load_count").distinct()

    dwd_ddjy_clue_vehicle_carrier_di_df_vehicle_load.show(1,false)

    logger.error("dwd_ddjy_clue_vehicle_carrier_di_df_vehicle_load 数据量: " + dwd_ddjy_clue_vehicle_carrier_di_df_vehicle_load.count())

    // 计算 vehicle_carrier_id_load_count

    val  dwd_ddjy_clue_vehicle_carrier_di_rdd_vehicle_carrier_id_load = dwd_ddjy_clue_vehicle_carrier_di_df.rdd.map(row  =>{
      val carrier_id = row.getAs[String]("carrier_id")
      val actual_capacity_load = row.getAs[String]("actual_capacity_load")
      val rowkey = carrier_id
      var countNum =0
      if(StringUtils.isEmpty(actual_capacity_load)){
        countNum =0
      }else{
        countNum =1
      }
      (rowkey, (row,countNum))
    }).reduceByKey((x,y) => {
      val vehicle_x  = x._1.getAs[String]("vehicle")
      val vehicle_y  = y._1.getAs[String]("vehicle")
      var countNum =0
      if(vehicle_x==vehicle_y){
        countNum =  x._2
      }else {
        countNum =  x._2+y._2
      }
      (x._1,countNum)
    }).map(x =>{
      val carrier_id =  x._2._1.getAs[String]("carrier_id")
      val vehicle_carrier_id_load_count =  x._2._2
      (carrier_id,vehicle_carrier_id_load_count)
    })



    val dwd_ddjy_clue_vehicle_carrier_di_df_vehicle_carrier_id_load =  spark.createDataset(dwd_ddjy_clue_vehicle_carrier_di_rdd_vehicle_carrier_id_load)
      .toDF("carrier_id","vehicle_carrier_id_load_count").distinct()
    dwd_ddjy_clue_vehicle_carrier_di_df_vehicle_carrier_id_load.show(1,false)

    // 计算 vehicle_count
    val  dwd_ddjy_clue_vehicle_carrier_di_rdd_vehicle = dwd_ddjy_clue_vehicle_carrier_di_df.rdd.map(row  =>{
      val carrier_id = row.getAs[String]("carrier_id")
      val rowkey = carrier_id
      (rowkey, (row,1))
    }).reduceByKey((x,y) => {
      var  countNum =  x._2
      val  vehicle_x  = x._1.getAs[String]("vehicle")
      val  vehicle_y  = y._1.getAs[String]("vehicle")
      if(vehicle_x != vehicle_y){
        countNum = x._2  + y._2
      }
      (x._1,countNum)
    }).map(x =>{
      val carrier_id =  x._2._1.getAs[String]("carrier_id")
      val vehicle_count =  x._2._2
      (carrier_id,vehicle_count)
    })

    val dwd_ddjy_clue_vehicle_carrier_di_df_vehicle =  spark.createDataset(dwd_ddjy_clue_vehicle_carrier_di_rdd_vehicle)
      .toDF("carrier_id","vehicle_count").distinct()

    dwd_ddjy_clue_vehicle_carrier_di_df_vehicle.show(1,false)

    logger.error("dwd_ddjy_clue_vehicle_carrier_di_df_vehicle 数据量: " + dwd_ddjy_clue_vehicle_carrier_di_df_vehicle.count())

    val dwd_ddjy_clue_vehicle_carrier_di_df1 =  dwd_ddjy_clue_vehicle_carrier_di_df
      .join(dwd_ddjy_clue_vehicle_carrier_di_df_vehicle_load,Seq("carrier_id"),"left")
      .join(dwd_ddjy_clue_vehicle_carrier_di_df_vehicle_carrier_id_load,Seq("carrier_id"),"left")
      .join(dwd_ddjy_clue_vehicle_carrier_di_df_vehicle,Seq("carrier_id"),"left")
      .select('carrier_id, 'clue_id,'clue_src, 'vehicle_count,'vehicle_carrier_id_load_count,'vehicle_load_count)
      .distinct()

    dwd_ddjy_clue_vehicle_carrier_di_df1.show(1,false)

    logger.error("dwd_ddjy_clue_vehicle_carrier_di_df1 数据量: " +  dwd_ddjy_clue_vehicle_carrier_di_df1.count())


    val  dm_ddjy_mid_carrier_rlst_di_Df1 =  dm_ddjy_mid_carrier_rlst_di_Df
      .join(dwd_ddjy_clue_vehicle_carrier_di_df1,Seq("carrier_id"),"left")
      .filter('rnk===1)
      .withColumn("oil_sum",sum('oil_sum).over(Window.partitionBy( 'clue_id,'carrier_id)))
      .withColumn("plan_depart_tm_day_max",max(when('clue_src===0,'plan_depart_tm_day_max ).otherwise(null)).over(Window.partitionBy( 'carrier_id)))
      .withColumn("plan_depart_tm_day_min",max(when('clue_src===0,'plan_depart_tm_day_min ).otherwise(null)).over(Window.partitionBy( 'carrier_id)))
      .withColumn("dis_sum",sum(when('clue_src===0,'dis_sum ).otherwise(null)).over(Window.partitionBy( 'carrier_id)))
      .select('legal_person_name,
        'content,
        'credit_code,
        'carrier_province,
        'carrier_city,
        'carrier_id,
        'carrier_name,
        'carrier_status,
        'carrier_tag,
        'carrier_circle_id,
        'register_vehicle_count,
        'carrier_scale,
        'carrier_suspected_address,
        'carrier_priority,
        'inc_day,
        'oil_sum,
        'task_count,
        'vehicle_count,
        'vehicle_load_count,
        'vehicle_carrier_id_load_count,
        'carrier_circle_task_count,
        'task_day_count,
        'clue_src,
        'plan_depart_tm_day_max,
        'plan_depart_tm_day_min,
        'dis_sum).repartition(2000)

    dm_ddjy_mid_carrier_rlst_di_Df1.show(1, false)
    logger.error("dm_ddjy_mid_carrier_rlst_di_Df1 数据量: " + dm_ddjy_mid_carrier_rlst_di_Df1.count())



    //    val  dwd_ddjy_clue_vehicle_carrier_diSql1 =
    //      s"""
    //         |
    //         |	select  concat_ws(",",collect_list(concat(POIID,':',cooperateStatus) ))  as gas_distribution,carrier_id  from (
    //         |	select distinct t0.carrier_id,POIID,cooperateStatus from
    //         |		(select *from  dm_gis.dwd_ddjy_clue_vehicle_carrier_di where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}') t0
    //         |		left join (select  * from dm_gis.dwd_ddjy_clue_gas_di where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}') t1
    //         |		on t0.clue_id=t1.clue_id
    //         |	)t group by  carrier_id
    //         |
    //         |""".stripMargin


    val  dwd_ddjy_clue_vehicle_carrier_diSql1 =
      s"""
         |
         |	select distinct t0.carrier_id,POIID,cooperateStatus from
         |		(select *from  dm_gis.dwd_ddjy_clue_vehicle_carrier_di where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}') t0
         |		left join (select  * from dm_gis.dwd_ddjy_clue_gas_di where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}') t1
         |		on t0.clue_id=t1.clue_id
         |""".stripMargin

    logger.error(dwd_ddjy_clue_vehicle_carrier_diSql1)

    val dwd_ddjy_clue_vehicle_carrier_diDF1= spark.sql(dwd_ddjy_clue_vehicle_carrier_diSql1)

    logger.error("dwd_ddjy_clue_vehicle_carrier_diDF1 数据量: " + dwd_ddjy_clue_vehicle_carrier_diDF1.count())

    val dwd_ddjy_clue_vehicle_carrier_di_rdd = dwd_ddjy_clue_vehicle_carrier_diDF1.rdd.map(row =>{
      val carrier_id  = row.getAs[String]("carrier_id")
      val POIID =  row.getAs[String]("POIID")
      val cooperateStatus =  row.getAs[String]("cooperateStatus")
      val concat  = POIID+":"+cooperateStatus
      (carrier_id,concat)
    }).reduceByKey((x,y)=>{
      val concat_x  = x
      val concat_y  = y
      concat_x + ","+ concat_y
    })

    val dwd_ddjy_clue_vehicle_carrier_di_df2 =  spark.createDataset(dwd_ddjy_clue_vehicle_carrier_di_rdd).toDF("carrier_id","gas_distribution")

    logger.error("dwd_ddjy_clue_vehicle_carrier_di_df2 数据量: " + dwd_ddjy_clue_vehicle_carrier_di_df2.count())


    //
    //    val dwd_ddjy_clue_vehicle_carrier_disql2=
    //      s"""
    //         |
    //         | select  concat_ws (",",sort_array(collect_list(concat(city,':',carrier_id_city_count))))  as city_distribution, carrier_id from (
    //         |	select  count(1) over(partition by carrier_id, city) as carrier_id_city_count, carrier_id, city
    //         |	from dm_gis.dwd_ddjy_clue_vehicle_carrier_di where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}' ) t
    //         |	group by carrier_id
    //         |
    //         |""".stripMargin



    val dwd_ddjy_clue_vehicle_carrier_disql2=
      s"""
         |	select  carrier_id, city
         |	from dm_gis.dwd_ddjy_clue_vehicle_carrier_di where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}'
         |""".stripMargin
    logger.error(dwd_ddjy_clue_vehicle_carrier_disql2)
    val dwd_ddjy_clue_vehicle_carrier_diDF22= spark.sql(dwd_ddjy_clue_vehicle_carrier_disql2)

    val dwd_ddjy_clue_vehicle_carrier_di_rdd22 = dwd_ddjy_clue_vehicle_carrier_diDF22.rdd.map(row  =>{
      val  carrier_id  = row.getAs[String]("carrier_id")
      val  city  = row.getAs[String]("city")
      val rowKey = carrier_id+"_"+city
      (rowKey,(row,1))
    }).reduceByKey((x,y)=>{
      (x._1,x._2+y._2)
    }).map(row  =>{
      val  carrier_id = row._2._1.getAs[String]("carrier_id")
      val  city = row._2._1.getAs[String]("city")
      val  carrier_id_city_count = row._2._2
      (carrier_id,city,carrier_id_city_count)
    })

    val dwd_ddjy_clue_vehicle_carrier_di_df22 =  spark.createDataFrame(dwd_ddjy_clue_vehicle_carrier_di_rdd22)
      .toDF("carrier_id","city","carrier_id_city_count")

    logger.error("dwd_ddjy_clue_vehicle_carrier_di_df22 数据量: " + dwd_ddjy_clue_vehicle_carrier_di_df22.count())


    val dwd_ddjy_clue_vehicle_carrier_diDF_rdd = dwd_ddjy_clue_vehicle_carrier_di_df22.rdd.map(row =>{
      val carrier_id  = row.getAs[String]("carrier_id")
      val city =  row.getAs[String]("city")
      val carrier_id_city_count =  row.getAs[Int]("carrier_id_city_count")
      val concat  = city+":"+carrier_id_city_count
      (carrier_id,(concat,row))
    }).reduceByKey((x,y)=>{
      val concat_x  = x._1
      val concat_y  = y._1
      val  carrier_id_city_count_x = x._2.getAs[Int]("carrier_id_city_count")
      val  carrier_id_city_count_y = y._2.getAs[Int]("carrier_id_city_count")
      var  concat =concat_x
      var  row  = x._2
      if (carrier_id_city_count_x>carrier_id_city_count_y){
        concat = concat_x + ","+ concat_y
        row =  x._2
      }else{
        concat = concat_y  + ","+ concat_x
        row =  y._2
      }
      (concat,row)
    }).map(row =>{
      val carrier_id  = row._1
      val city_distribution = row._2._1
      (carrier_id,city_distribution)
    })

    val dwd_ddjy_clue_vehicle_carrier_diDF_DF2=  spark.createDataset(dwd_ddjy_clue_vehicle_carrier_diDF_rdd).toDF("carrier_id","city_distribution")

    logger.error("dwd_ddjy_clue_vehicle_carrier_diDF_DF2 数据量: " + dwd_ddjy_clue_vehicle_carrier_diDF_DF2.count())



    val  dm_ddjy_mid_carrier_rlst_di_max_sql =
      s"""
         |
         |	select
         |	substr (max(task_batch), 10,17) as max_task_batch,
         |	substr (min(task_batch), 0,8) as min_task_batch
         |	from  dm_gis.dm_ddjy_mid_carrier_rlst_di
         |	where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}'
         |
         |""".stripMargin

    logger.error(dm_ddjy_mid_carrier_rlst_di_max_sql)
    val dm_ddjy_mid_carrier_rlst_di_max_DF= spark.sql(dm_ddjy_mid_carrier_rlst_di_max_sql)

    val max_task_batch_df  = dm_ddjy_mid_carrier_rlst_di_max_DF.withColumn("task_batch", concat('min_task_batch,lit("-"),'max_task_batch))
    val max_task_batch =  max_task_batch_df.takeAsList(1).get(0).getAs[String]("task_batch")

    logger.error("max_task_batch :  " + max_task_batch)

    val resultDF =  dm_ddjy_mid_carrier_rlst_di_Df1
      .join(dwd_ddjy_clue_vehicle_carrier_di_df2,Seq("carrier_id"),"left")
      .join(dwd_ddjy_clue_vehicle_carrier_diDF_DF2,Seq("carrier_id"),"left")
      .withColumn("vehicle_load_count_distribution",concat('vehicle_load_count,lit(":"),'vehicle_load_count/'vehicle_carrier_id_load_count*100,lit("%")))
      .withColumn("task_count_per_day",ceil('task_count/'task_day_count))
      .withColumn("dis_sum_per_day",when('clue_src===1,lit("")).otherwise('dis_sum/'task_day_count))
      .withColumn("oil_sum_per_day",'oil_sum/'task_day_count)
      .withColumn("task_batch",lit(max_task_batch))
      .withColumn("clue_distribution",lit(""))
      .withColumn("update_time",lit(DateUtil.getCurrentDate("yyyyMMdd HH:mm:ss")))
      .withColumn("biz_day",'inc_day)
      .withColumn("inc_day",lit(inc_day)).repartition(2000)

    val resultDF1 =   resultDF.select('carrier_id,
      'carrier_name,
      'carrier_status,
      'carrier_tag,
      'carrier_circle_id,
      'legal_person_name,
      'content,
      'credit_code,
      'carrier_province,
      'carrier_city,
      'register_vehicle_count,
      'carrier_scale,
      'carrier_suspected_address,
      'carrier_priority,
      'task_count,
      'vehicle_count,
      'task_day_count,
      'plan_depart_tm_day_max,
      'plan_depart_tm_day_min,
      'dis_sum,
      'vehicle_load_count_distribution,
      'carrier_circle_task_count,
      'task_count_per_day,
      'dis_sum_per_day,
      'oil_sum,
      'oil_sum_per_day,
      'clue_distribution,
      'gas_distribution,
      'city_distribution,
      'update_time ,
      'task_batch,
      'biz_day,
      'inc_day)


    logger.error("数据量: " + resultDF1.count())

    //数据存dm表
    writeToHive(spark, resultDF1, Seq("inc_day"), tableName)

  }



}
