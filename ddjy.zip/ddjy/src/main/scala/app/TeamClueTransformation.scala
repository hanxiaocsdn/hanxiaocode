package app

import java.text.SimpleDateFormat
import java.util.Date

import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.CommonTools.row2Json
/**
 * @Description:【吨吨加油】车队线索转化漏斗监控需求
 * 需求方：陶慧 01424177
 * @Author: 徐游飞 01417347、李相志 01405644
 * @Date: 14:13 2023/02/27
 * 任务id:551
 * 任务名称：车队线索转化漏斗监控
 * 依赖任务：无
 * 数据源：ddjy_ods_clue_follow_up、ddjy_ods_clue_interview_detail、ddjy_ods_clue_call_detail、ddjy_ods_clue_contract_detail、ddjy_ods_sales_info
 * 调用服务地址：
 * 数据结果：ddjy_team_clue_transformation
 */
object TeamClueTransformation {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    // inc_day 为业务时间，即跑数时间
    val inc_day = args(0)
    // 衡度大数据平台SparkConf
/*    val conf = getSparkConf_hd(className,null)
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()*/

    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    spark.sparkContext.setLogLevel("WARN")

    logger.error("++++++++  任务开始  ++++")
    run(spark, inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()

  }

  def run(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val follow_up_sql =
      s"""
         |select
         |  id,
         |  create_time,
         |  sub_status,
         |  current_user_name,
         |  change_to_user
         |from
         |  dm_gis.ddjy_ods_clue_follow_up
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println("获取follow_up表数据 sql语句：")
    println(follow_up_sql)

    val interview_detail_sql =
      s"""
         |select
         |  follow_up_id,
         |  interview_result,
         |  refuse_reason,
         |  create_date
         |from
         |  dm_gis.ddjy_ods_clue_interview_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println("获取interview_detail表数据 sql语句：")
    println(interview_detail_sql)

    val call_detail_sql =
      s"""
         |select
         |  follow_up_id,
         |  touch_result,
         |  customer_intention,
         |  sub_touch_result,
         |  sub_customer_intention,
         |  create_date
         |from
         |  dm_gis.ddjy_ods_clue_call_detail
         |where
         |  inc_day = '$dayBefore1'
         |  and id is not null
         |""".stripMargin

    println("获取call_detail表数据 sql语句：")
    println(call_detail_sql)

    val contract_detail_sql =
      s"""
         |select
         |  follow_up_id,
         |  task_id,
         |  create_date
         |from
         |  dm_gis.ddjy_ods_clue_contract_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println("获取contract_detail表数据 sql语句：")
    println(contract_detail_sql)

    val df_follow_up = spark.sql(follow_up_sql)
      .withColumn("user_id",when('sub_status === "已转交",'change_to_user).otherwise('current_user_name))
      .withColumn("day",timeToCustomTime2('create_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyy-MM-dd")))
      .withColumn("follow_up_id",'id)
      .withColumn("rn",row_number().over(Window.partitionBy("follow_up_id").orderBy(desc("day"))))
      .filter('rn === 1)
      .drop("rn")
      .persist(StorageLevel.MEMORY_AND_DISK)

    // follow_up表指标
    val df_follow_ret = df_follow_up
      .groupBy("user_id","day")
      .agg(
        count('id) as "clue_use_num",
        count(when('sub_status === "待电话沟通",'id).otherwise(null)) as "clue_need_call",
        count(when('sub_status === "已转交",'id).otherwise(null)) as "clue_transfer"
      )

    // call_detail表指标
    val df_call_detail = spark.sql(call_detail_sql)
      .withColumn("rn",row_number().over(Window.partitionBy("follow_up_id").orderBy(desc("create_date"))))
      .filter('rn === 1)
      .drop("rn")
      .join(df_follow_up.select("follow_up_id","user_id","day"),Seq("follow_up_id"),"left")
      .rdd
      .map(row=>{
        val obj = row2Json(row)
        val user_id = JSONUtil.getJsonVal(obj, "user_id", "")
        val day = JSONUtil.getJsonVal(obj, "day", "")
        ((user_id,day),obj)
      }).groupByKey()
      .map(obj=>{
        val user_id = obj._1._1
        val day = obj._1._2
        val arr_obj = obj._2
        // 统计字段
        val clue_follow = arr_obj.size
        var call_valid = 0
        var call_invalid = 0
        var call_reject = 0
        var valid_reject = 0
        var valid_intention = 0
        var valid_nointention = 0
        var valid_cooperated = 0
        var invalid_communicate = 0
        var invalid_notarget = 0
        var invalid_other = 0
        var invalid_telerro = 0
        var invalid_nopower = 0
        var invalid_reconnect = 0
        var reject_temporary = 0
        var reject_ever = 0
        var intention_discount = 0
        var intention_brand = 0
        var intention_method = 0
        var intention_consummode = 0
        var reject_nodemand = 0
        var reject_purchased = 0
        var reject_other = 0
        var reject_unknown = 0
        var nointention_lowdiscount = 0
        var nointention_mismatch = 0
        var nointention_cooperated = 0
        var nointention_brand = 0
        var nointention_oils = 0
        var nointention_city = 0

        for (elem <- arr_obj) {
          // 电话接听情况
          val touching_customer = JSONUtil.getJsonObjectMulti(elem,"touch_result").getString("touching_customer")
          if(touching_customer.contains("有效接听")) call_valid += 1
          if(touching_customer.contains("无效接听")) call_invalid += 1
          if(touching_customer.contains("未接听")) call_reject += 1
          // 有效接听情况
          val preliminary_intention = JSONUtil.getJsonObjectMulti(elem,"customer_intention").getString("preliminary_intention")
          if(touching_customer.equals("有效接听")){
            if(preliminary_intention.contains("已拒绝")) valid_reject += 1
            if(preliminary_intention.contains("有意向")) valid_intention += 1
            if(preliminary_intention.contains("暂无意向")) valid_nointention += 1
            if(preliminary_intention.contains("已合作")) valid_cooperated += 1
          }
          // 无效接听情况
          val invalid_answer = JSONUtil.getJsonObjectMulti(elem,"sub_touch_result").getString("invalid_answer")
          if(touching_customer.equals("无效接听")){
            if(invalid_answer.contains("不愿交流")) invalid_communicate += 1
            if(invalid_answer.contains("非目标客户")) invalid_notarget += 1
            if(invalid_answer.contains("其他")) invalid_other += 1
            if(invalid_answer.contains("电话错误")) invalid_telerro += 1
            if(invalid_answer.contains("非决策人")) invalid_nopower += 1
            if(invalid_answer.contains("再联系")) invalid_reconnect += 1
          }
          // 未接听情况
          val no_answer = JSONUtil.getJsonObjectMulti(elem,"sub_touch_result").getString("no_answer")
          if(touching_customer.equals("未接听")){
            if(no_answer.contains("暂未接通")) reject_temporary += 1
            if(no_answer.contains("无法接通")) reject_ever += 1
          }
          // 有意向情况
          val has_intention = JSONUtil.getJsonObjectMulti(elem,"sub_customer_intention").getString("has_intention")
          if(touching_customer.equals("有效接听") && preliminary_intention.equals("有意向")){
            if(has_intention.contains("优惠力度")) intention_discount += 1
            if(has_intention.contains("油站品牌")) intention_brand += 1
            if(has_intention.contains("返利方式")) intention_method += 1
            if(has_intention.contains("消费方式")) intention_consummode += 1
          }
          // 已拒绝情况
          val is_rejected = JSONUtil.getJsonObjectMulti(elem,"sub_customer_intention").getString("is_rejected")
          if(touching_customer.equals("有效接听") && preliminary_intention.equals("已拒绝")){
            if(is_rejected.contains("无需求")) reject_nodemand += 1
            if(is_rejected.contains("总部采购")) reject_purchased += 1
            if(is_rejected.contains("其他")) reject_other += 1
            if(is_rejected.contains("原因不明")) reject_unknown += 1
          }
          // 暂无意向情况
          val no_intention = JSONUtil.getJsonObjectMulti(elem,"sub_customer_intention").getString("no_intention")
          if(touching_customer.equals("有效接听") && preliminary_intention.equals("暂无意向")){
            if(no_intention.contains("优惠力度低")) nointention_lowdiscount += 1
            if(no_intention.contains("油站不匹配")) nointention_mismatch += 1
            if(no_intention.contains("已有合作商")) nointention_cooperated += 1
            if(no_intention.contains("指定品牌")) nointention_brand += 1
            if(no_intention.contains("指定油品")) nointention_oils += 1
            if(no_intention.contains("非需求城市")) nointention_city += 1
          }
        }
        CallDetail(user_id,day,clue_follow,call_valid,call_invalid,call_reject,valid_reject,valid_intention,valid_nointention,valid_cooperated,invalid_communicate,
          invalid_notarget,invalid_other,invalid_telerro,invalid_nopower,invalid_reconnect,reject_temporary,reject_ever,intention_discount,intention_brand,
          intention_method,intention_consummode,reject_nodemand,reject_purchased,reject_other,reject_unknown,nointention_lowdiscount,nointention_mismatch,
          nointention_cooperated,nointention_brand,nointention_oils,nointention_city)
      }).toDF()


    val df_interview_detail_tmp = spark.sql(interview_detail_sql)
      .withColumn("rn",row_number().over(Window.partitionBy("follow_up_id").orderBy(desc("create_date"))))
      .filter('rn === 1)
      .drop("rn")
      .join(df_follow_up.select("follow_up_id","user_id","day"),Seq("follow_up_id"),"left")
      .filter('user_id === "ft220135" and 'day === "2022-12-03")

    df_interview_detail_tmp.show(20000,false)

    // interview_detail表指标
    val df_interview_detail = spark.sql(interview_detail_sql)
      .withColumn("rn",row_number().over(Window.partitionBy("follow_up_id").orderBy(desc("create_date"))))
      .filter('rn === 1)
      .drop("rn")
      .join(df_follow_up.select("follow_up_id","user_id","day"),Seq("follow_up_id"),"left")
      .rdd
      .map(row=>{
        val obj = row2Json(row)
        val user_id = JSONUtil.getJsonVal(obj, "user_id", "")
        val day = JSONUtil.getJsonVal(obj, "day", "")
        ((user_id,day),obj)
      }).groupByKey()
      .map(obj=>{
        val user_id = obj._1._1
        val day = obj._1._2
        val arr_obj = obj._2
        // 统计字段
        val appointment = arr_obj.size
        var interview = 0
        var interview_success = 0
        var fail_lowdiscount = 0
        var fail_consummode = 0
        var fail_brand = 0

        for (elem <- arr_obj) {
          // 面谈情况
          val interview_result = JSONUtil.getJsonVal(elem,"interview_result","")
          if(interview_result.contains("面谈成功") || interview_result.contains("面谈拒绝")) interview += 1
          if(interview_result.contains("面谈成功")) interview_success += 1
          // 面谈拒绝原因
          val refuse_reason = JSONUtil.getJsonVal(elem,"refuse_reason","")
          if(interview_result.equals("面谈拒绝")){
            if(refuse_reason.contains("优惠力度")) fail_lowdiscount += 1
            if(refuse_reason.contains("消费方式")) fail_consummode += 1
            if(refuse_reason.contains("油站品牌")) fail_brand += 1
          }

        }
        (user_id,day,appointment,interview,interview_success,fail_lowdiscount,fail_consummode,fail_brand)
      }).toDF("user_id","day","appointment","interview","interview_success","fail_lowdiscount","fail_consummode","fail_brand")

    // contract_detail表指标
    val df_contract_detail = spark.sql(contract_detail_sql)
      .withColumn("rn", row_number().over(Window.partitionBy("follow_up_id").orderBy(desc("create_date"))))
      .filter('rn === 1)
      .drop("rn")
      .join(df_follow_up.select("follow_up_id", "user_id", "day"), Seq("follow_up_id"), "left")
      .groupBy("user_id", "day")
      .agg(
        count('task_id) as "settled"
      )
    //读取ddjy_ods_sales_info
    val salesTeamSql=
      s"""
         |select user_no as user_id,sup_code,sup_name,sub_code,sub_name,user_id as user_id_tmp,user_name
         |from dm_gis.ddjy_ods_sales_info
         |where inc_day='$dayBefore1'
         |and user_name not like '%测试%'
         |and sup_name not like '%测试%'
         |and sub_name not like '%测试%'
         |""".stripMargin
    val salesTeamDf: DataFrame = spark.sql(salesTeamSql).distinct()
    // 统计指标汇总
    val df_ret = df_follow_ret
      .join(df_call_detail, Seq("user_id", "day"), "left")
      .join(df_interview_detail, Seq("user_id", "day"), "left")
      .join(df_contract_detail, Seq("user_id", "day"), "left")
      .join(salesTeamDf,Seq("user_id"),"left")    //新增工号、组别、销售id等字段
      .withColumnRenamed("user_id","user_no")
      .withColumnRenamed("user_id_tmp","user_id")
      .withColumn("inc_day",lit(dayBefore1))
      .distinct()

    val cols_ret = spark.sql("""select * from dm_gis.ddjy_team_clue_transformation limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_ret: _*),Seq("inc_day"),"dm_gis.ddjy_team_clue_transformation")

    df_follow_up.unpersist()
  }

  /**
   * 把df数据按分区覆盖写入到hive
   * @param spark
   * @param dataframe
   * @param partitionCol 分区字段
   * @param resTableName hive表名
   */
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
    logger.error(s"$resTableName : 表数据写入完成")
  }

  /**
   * 两种不同格式时间字符串相互转换
   * @param
   * @param
   * @param
   * @throws
   * @return
   */

  def timeToCustomTime2 = udf((time: String,format1: String,format2: String) => {
    val format = new SimpleDateFormat(format1)
    val newFormat = new SimpleDateFormat(format2)

    var standardTime = new Date()
    var newTime = ""
    try{
      standardTime = format.parse(time)
      newTime = newFormat.format(standardTime)
    }catch {
      case e: Exception => println(">>>日期转换异常"+e)
    }
    newTime
  })

  case class CallDetail(
                         user_id : String,
                         day : String,
                         clue_follow : Int,
                         call_valid : Int,
                         call_invalid : Int,
                         call_reject : Int,
                         valid_reject : Int,
                         valid_intention : Int,
                         valid_nointention : Int,
                         valid_cooperated : Int,
                         invalid_communicate : Int,
                         invalid_notarget : Int,
                         invalid_other : Int,
                         invalid_telerro : Int,
                         invalid_nopower : Int,
                         invalid_reconnect : Int,
                         reject_temporary : Int,
                         reject_ever : Int,
                         intention_discount : Int,
                         intention_brand : Int,
                         intention_method : Int,
                         intention_consummode : Int,
                         reject_nodemand : Int,
                         reject_purchased : Int,
                         reject_other : Int,
                         reject_unknown : Int,
                         nointention_lowdiscount : Int,
                         nointention_mismatch : Int,
                         nointention_cooperated : Int,
                         nointention_brand : Int,
                         nointention_oils : Int,
                         nointention_city : Int)

}
