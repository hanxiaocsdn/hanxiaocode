package app

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DistanceUtils}
import com.sf.gis.scala.base.spark.{Spark, SparkJoin, SparkNet}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkUtils, SparkWrite}

import scala.collection.JavaConversions._

/**
 * @Description:【吨吨加油】聚合线索工艺需求V1.0
 * 需求人员：矫悦 01404184
 * @Author:lixiangzhi 01405644
 * @Date:11:40 2023/04/17
 * 任务id:739
 * 任务名称：顺丰和粤运线索地图合并基础表
 * 依赖任务：577 粤运线索地图、266 顺丰线索地图
 * 数据源：dwd_ddjy_belong_join_own_di、dwd_ddjy_dept_line_sf_di、dim_ddjy_vehicle_concat_yy_df、dwd_ddjy_carrier_info_di、city_name_map、ddjy_ods_dim_team_info、ddjy_suspected_business_address_di、dm_ddjy_gas_station_info_di
 * 调用服务地址：http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s
 * 数据结果：dwd_ddjy_clue_vehicle_carrier_di、dwd_ddjy_clue_gas_di、dwd_ddjy_clue_circle_seed
 */
object SfYyClueMapMerge {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def belongUnionDept(spark: SparkSession, incDay: String,task_batch:String) = {
    import spark.implicits._
    val belongSql=
      s"""
        |select
        |agr_id,agr_rs_id,
        |unique_id as clue_id,
        |belong_name as clue_name,
        |clue_type,
        |concat(stay_province,stay_city,stay_district,belong_name) as clue_addr,
        |'' as dept_type_name,
        |'' as dept_transfer_flag,
        |'' as area_name,
        |'' as country_name,
        |'' as delete_flg,
        |clue_src,
        |stay_adcode as adcode,
        |stay_province as province,
        |stay_city as city,
        |stay_district as district,
        |belong_y_avg as latitude,
        |belong_x_avg as longitude,
        |src,
        |'' as plan_depart_tm,
        |vehicle,
        |'' as actual_capacity_load,
        |owner_id as carrier_id,
        |owner_name as carrier_name,
        |'' as line_distance,
        |'$task_batch' as task_batch,
        |week_day as inc_day
        |from dm_gis.dwd_ddjy_belong_join_own_di
        |where week_day='$incDay'
        |""".stripMargin
    val belongDf: DataFrame = spark.sql(belongSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("belongOwn表数据量："+belongDf.count())
    val deptSql=
      s"""
         |select
         |'' as agr_id,
         |'' as agr_rs_id,
         |dept_code as clue_id,
         |dept_name as clue_name,
         |'' as clue_type,
         |dept_addr as clue_addr,
         |dept_type_name,dept_transfer_flag,area_name,country_name,delete_flg,clue_src,
         |belong_county_code as adcode,
         |provinct_name as province,
         |city_name as city,
         |belong_county as district,
         |latitude,longitude,
         |'' as src,
         |plan_depart_tm,
         |vehicle_serial as vehicle,
         |actual_capacity_load,
         |carrier_id,
         |carrier_name,
         |line_distance,
         |'$task_batch' as task_batch,
         |inc_day
         |from dm_gis.dwd_ddjy_dept_line_sf_di
         |where inc_day='$incDay'
         |""".stripMargin
    val deptDf: DataFrame = spark.sql(deptSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("deptLine表数据量："+deptDf.count())
    val belongUnionDeptDf: DataFrame = belongDf.union(deptDf).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    val tomorrow: String = DateUtil.getDateStr(incDay, 1, "")
    val vehicleYySql=
      s"""
        |select vehicle_no,owner_id,owner_name
        |from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |where inc_day='$tomorrow'
        |""".stripMargin
    val vehicleYyDf: DataFrame = spark.sql(vehicleYySql)
    val updateCarrieridDf: DataFrame = belongUnionDeptDf.as("t1")
      .join(vehicleYyDf.as("t2"), $"t1.vehicle" === $"t2.vehicle_no", "left")
      .withColumn("carrier_id", when($"t2.vehicle_no".isNull, $"carrier_id").otherwise($"owner_id"))
      .withColumn("carrier_name", when($"t2.vehicle_no".isNull, $"carrier_name").otherwise($"owner_name"))
      .drop($"vehicle_no")
      .drop($"owner_id")
      .drop($"owner_name")
    logger.error("belongUnionDept表数据量:"+updateCarrieridDf.count())
    belongDf.unpersist()
    deptDf.unpersist()
    belongUnionDeptDf.unpersist()
    updateCarrieridDf
  }

  def addFieldProcess(spark: SparkSession, circleidBackHangRdd: RDD[JSONObject], incDay: String) = {
    val carrierInfoSql=
      s"""
        |select * from dm_gis.dwd_ddjy_carrier_info_di where inc_day='$incDay'
        |""".stripMargin
    val carrierInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, carrierInfoSql,2000).groupBy(_.getString("owner_id")).flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val legal_person_name_agg: String = list.map(json => {
        val legal_person_name: String = "(" + json.getString("legal_person_name") + ")"
        legal_person_name
      }).mkString(";")
      val content_agg: String = list.map(json => {
        val content: String = "(" + json.getString("content") + ")"
        content
      }).mkString(";")
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("legal_person_name", legal_person_name_agg)
        json.put("content", content_agg)
        json
      })
      tmpList
    }).groupBy(_.getString("owner_id")).map(obj=>{
      val tmpObj: JSONObject = obj._2.maxBy(json=>{
        JSONUtil.getJsonValSingle(json,"city_adcode")
      })
      tmpObj
    }).map(obj=>{
      (obj.getString("owner_id"),obj)
    })
    //carrierInfoRdd.filter(_._1=="3").take(10).foreach(println(_))
    val cityNameSql=
      """
        |select * from dm_gis.city_name_map
        |""".stripMargin
    val cityNameDf: DataFrame = spark.sql(cityNameSql)
    val cityNameMap= SparkUtils.getDfToJson(spark, cityNameDf).groupBy(_.getString("adcode")).map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.minBy(_.getString("province"))
      (tmpObj.getString("adcode"),tmpObj)
    }).collectAsMap()
    val teamInfoSql=
      s"""
        |select name
        |from dm_gis.ddjy_ods_dim_team_info
        |where inc_day=(select max(inc_day) from dm_gis.ddjy_ods_dim_team_info)
        |and name!='' and name is not null
        |and del_flag = '0'
        |group by name
        |""".stripMargin
    val teamInfoDf: DataFrame = spark.sql(teamInfoSql)
    val teamInfoMap = SparkUtils.getDfToJson(spark, teamInfoDf).map(obj => {
      (obj.getString("name"), obj)
    }).collectAsMap()
    val tomorrow: String = DateUtil.getDateStr(incDay, 1, "")
    val vehicleConcatYySql=
      s"""
        |select owner_id as carrier_id,
        |count(distinct vehicle_no) as register_vehicle_count
        |from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |where inc_day = '$tomorrow'
        |group by owner_id
        |""".stripMargin
    logger.error(vehicleConcatYySql)
    val vehicleConcatYyRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, vehicleConcatYySql).map(obj=>{
      (obj.getString("carrier_id"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("vehicle_concat_yy数据量:"+vehicleConcatYyRdd.count())
    val suspectedBusinessAddressSql=
      s"""
        |select * from dm_gis.ddjy_suspected_business_address_di where inc_day='$incDay' and owner_id!='' and owner_id is not null
        |""".stripMargin
    val suspectedBusinessAddressRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, suspectedBusinessAddressSql).map(obj => {
      (obj.getString("owner_id"), obj)
    }).groupByKey().map(obj=>{
      val tmpObj: JSONObject = obj._2.minBy(json=>{
        val owner_id: String = JSONUtil.getJsonVal(json, "owner_id", "")
        owner_id
      })
      (tmpObj.getString("owner_id"),tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("suspected_business_address数据量:"+suspectedBusinessAddressRdd.count())
    val circleidBackHangMapRdd: RDD[(String, JSONObject)] = circleidBackHangRdd.map(obj => {
      (obj.getString("carrier_id"), obj)
    }).distinct()
    val cityNameBc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(cityNameMap)
    val teamInfoBc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(teamInfoMap)
    val addCarrierCircleIdRdd: RDD[(String, JSONObject)]  = SparkJoin.leftOuterJoinOfLeftLeanElemJSONObject(circleidBackHangMapRdd,carrierInfoRdd,50,40).repartition(10000)
      .map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val legal_person_name: String = rightObj.getString("legal_person_name")
        val content: String = rightObj.getString("content")
        val credit_code: String = rightObj.getString("credit_code")
        val city_adcode: String = rightObj.getString("city_adcode")
        leftObj.put("legal_person_name", legal_person_name)
        leftObj.put("content", content)
        leftObj.put("credit_code", credit_code)
        leftObj.put("city_adcode", city_adcode)
      }
      leftObj
    }).map(obj=>{
      val city_adcode: String = obj.getString("city_adcode")
      val cityNameValue: collection.Map[String, JSONObject] = cityNameBc.value
      val cityObj: JSONObject = cityNameValue.getOrElse(city_adcode, null)
      if (cityObj!=null){
        val province: String = cityObj.getString("province")
        val city: String = cityObj.getString("city")
        obj.put("carrier_province", province)
        obj.put("carrier_city", city)
      }
      val carrier_name: String = obj.getString("carrier_name")
      val teamInfoValue: collection.Map[String, JSONObject] = teamInfoBc.value
      val teamObj: JSONObject = teamInfoValue.getOrElse(carrier_name, null)
      if (teamObj != null) {
        obj.put("carrier_status", "1")
      } else {
        obj.put("carrier_status", "0")
      }
      obj
    }).groupBy(_.getString("carrier_id")).flatMap(obj => {
      val clue_src: Double = obj._2.minBy(_.getDoubleValue("clue_src")).getDoubleValue("clue_src")
      val tmpList: Iterable[JSONObject] = obj._2.map(json => {
        if (clue_src == 0) {
          json.put("carrier_tag", "sf_carrier_tag")
        } else {
          json.put("carrier_tag", "cantonese_carrier_tag")
        }
        json
      })
      tmpList
    }).repartition(1000).map(obj => {
      ((obj.getString("carrier_id"), obj.getString("circle_id")), obj)
    }).groupByKey().flatMap(obj => {
      val carrier_circle_task_count: Int = obj._2.size
      val tmpList: Iterable[JSONObject] = obj._2.map(json => {
        json.put("carrier_circle_task_count", carrier_circle_task_count)
        json
      })
      tmpList
    }).groupBy(_.getString("carrier_id")).flatMap(obj => {
      val tmpObj: JSONObject = obj._2.maxBy(_.getIntValue("carrier_circle_task_count"))
      val carrier_circle_task_count: String = tmpObj.getString("carrier_circle_task_count")
      val circle_id: String = tmpObj.getString("circle_id")
      val tmpList: Iterable[JSONObject] = obj._2.map(json => {
        json.put("carrier_circle_task_count", carrier_circle_task_count)
        json.put("carrier_circle_id", circle_id)
        json
      })
      tmpList
    }).map(obj => {
      (obj.getString("carrier_id"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加CarrierCircleId后数据量:"+addCarrierCircleIdRdd.count())
    val addFieldRdd: RDD[JSONObject] = addCarrierCircleIdRdd.leftOuterJoin(vehicleConcatYyRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val register_vehicle_count: String = rightObj.getString("register_vehicle_count")
        leftObj.put("register_vehicle_count", register_vehicle_count)
      }
      leftObj
    }).map(obj=>{
      val register_vehicle_count: Int = JSONUtil.getJsonValInt(obj,"register_vehicle_count",-1)
      var carrier_scale="数据缺失"
      if (register_vehicle_count>=0 && register_vehicle_count<=4){
        carrier_scale="4及以下"
      }else if(register_vehicle_count>=5 && register_vehicle_count<=10){
        carrier_scale="5~10"
      }else if(register_vehicle_count>=11 && register_vehicle_count<=20){
        carrier_scale="11~20"
      }else if(register_vehicle_count>=21 && register_vehicle_count<=30){
        carrier_scale="21~30"
      }else if(register_vehicle_count>=31 && register_vehicle_count<=40){
        carrier_scale="31~40"
      }else if(register_vehicle_count>=41 && register_vehicle_count<=50){
        carrier_scale="41~50"
      }else if(register_vehicle_count>=50){
        carrier_scale="50以上"
      }
      obj.put("carrier_scale",carrier_scale)
      (obj.getString("carrier_id"),obj)
    }).leftOuterJoin(suspectedBusinessAddressRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        val suspected_address: String = rightObj.getString("suspected_address")
        val priority: String = rightObj.getString("priority")
        leftObj.put("carrier_suspected_address",suspected_address)
        leftObj.put("carrier_priority",priority)
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("增加字段后数据量:"+addFieldRdd.count())
    suspectedBusinessAddressRdd.unpersist()
    addCarrierCircleIdRdd.unpersist()
    vehicleConcatYyRdd.unpersist()
    addFieldRdd
  }

  def stationClusterInterface(spark: SparkSession, belongUnionDeptDf:DataFrame, incDay: String) = {
    import spark.implicits._
    val belongUnionDeptRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, belongUnionDeptDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val clueidDistinctRdd: RDD[JSONObject] = belongUnionDeptRdd.groupBy(_.getString("clue_id")).map(obj => {
      val tmpObj: JSONObject = obj._2.toList.minBy(_.getString("adcode"))
      tmpObj
    })
    val returnRdd: RDD[(String, JSONObject)] = clueidDistinctRdd.repartition(1000).map(obj => {
      val tmpObj = new JSONObject()
      val clue_id: String = obj.getString("clue_id")
      val adcode: String = obj.getString("adcode")
      val x: Double = obj.getDouble("longitude")
      val y: Double = obj.getDouble("latitude")
      tmpObj.put("clue_id", clue_id)
      tmpObj.put("adcode", adcode)
      tmpObj.put("x", x)
      tmpObj.put("y", y)
      (adcode, tmpObj)
    }).groupByKey().repartition(5).flatMap(obj=>{
      val stations: Array[JSONObject] = obj._2.toArray
      val stationsObj = new JSONObject()
      stationsObj.put("stations",stations)
      val returnObj: JSONObject = SfNetInteface.stationClusterInterface(stationsObj)
      val resultsArray: JSONArray = JSONUtil.getJsonArrayMulti(returnObj, "api_result.results")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until resultsArray.size()) {
        val tmpObj = new JSONObject()
        val resultObj: JSONObject = resultsArray.getJSONObject(i)
        tmpObj.fluentPutAll(resultObj)
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    }).map(obj=>{
      (obj.getString("clue_id"),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取集散圈接口返回数据量："+returnRdd.count())
    //集散圈接口返回结果数据回挂
    val circleidBackHangRdd: RDD[JSONObject] = belongUnionDeptRdd.repartition(600).map(obj => {
      (obj.getString("clue_id"), obj)
    }).leftOuterJoin(returnRdd).map(obj=>{
      val rightObj: JSONObject = obj._2._2.getOrElse(new JSONObject())
      val leftObj: JSONObject = obj._2._1
      val center_x: String = JSONUtil.getJsonValSingle(rightObj,"center_x")
      val center_y: String = JSONUtil.getJsonValSingle(rightObj,"center_y")
      val circle_id: String = JSONUtil.getJsonValSingle(rightObj,"circle_id")
      leftObj.put("center_x", center_x)
      leftObj.put("center_y", center_y)
      leftObj.put("circle_id", circle_id)
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取集散圈接口并回挂后数据量："+circleidBackHangRdd.count())
    //关联相关表添加相应字段
    val addFieldRdd: RDD[JSONObject] = addFieldProcess(spark, circleidBackHangRdd, incDay)
    val cal = Calendar.getInstance
    val time = cal.getTime
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time)
    val vehicleCarrierDf: DataFrame = addFieldRdd.map(obj => {
      VehicleCarrier(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("clue_id"),
        obj.getString("clue_name"),
        obj.getString("clue_type"),
        obj.getString("clue_addr"),
        obj.getString("dept_type_name"),
        obj.getString("dept_transfer_flag"),
        obj.getString("area_name"),
        obj.getString("country_name"),
        obj.getString("delete_flg"),
        obj.getString("clue_src"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("latitude"),
        obj.getString("longitude"),
        obj.getString("src"),
        obj.getString("plan_depart_tm"),
        obj.getString("vehicle"),
        obj.getString("actual_capacity_load"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("line_distance"),
        obj.getString("circle_id"),
        obj.getString("center_x"),
        obj.getString("center_y"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("credit_code"),
        obj.getString("carrier_province"),
        obj.getString("carrier_city"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("carrier_circle_id"),
        obj.getString("carrier_circle_task_count"),
        obj.getString("register_vehicle_count"),
        obj.getString("carrier_scale"),
        obj.getString("carrier_suspected_address"),
        obj.getString("carrier_priority"),
        obj.getString("task_batch"),
        update_time
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("vehicleCarrier表数据量:"+vehicleCarrierDf.count())
    vehicleCarrierDf.createOrReplaceTempView("vehicleCarrierTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_clue_vehicle_carrier_di partition(inc_day='$incDay') select * from vehicleCarrierTmp")
    vehicleCarrierDf.distinct().createOrReplaceTempView("vehicleCarrierTmp1")
    //生成集散圈种子表
    val circleSeedSql=
      """
        |insert overwrite table dm_gis.dwd_ddjy_clue_circle_seed
        |select
        |distinct clue_id,clue_name,adcode,province,city,district,circle_id,center_x,center_y,
        |from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as create_time,
        |longitude,latitude,clue_type,
        |avg(longitude) over(partition by circle_id) as longitude_avg,
        |avg(latitude) over(partition by circle_id) as latitude_avg
        |from vehicleCarrierTmp1
        |""".stripMargin
    spark.sql(circleSeedSql)

  }

  def iterationStationClusterInterface(spark: SparkSession,belongUnionDeptDf:DataFrame,incDay: String) = {
    import spark.implicits._
    val vehicleCarrierRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark,belongUnionDeptDf)
    vehicleCarrierRdd.filter(_.getString("carrier_id")=="11391").map(obj=>{
      (obj.getString("carrier_id"),obj.getString("clue_src"))
    }).distinct().take(10).foreach(println(_))
    val circleSeedSql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_clue_circle_seed
         |""".stripMargin
    val circleSeedDf: DataFrame = spark.sql(circleSeedSql)
    val circleSeedMapRdd = SparkUtils.getDfToJson(spark, circleSeedDf).map(obj=>{
      ((obj.getString("unique_id"),obj.getString("stay_adcode")),obj)
    })
    val joinLastClueInfoRdd: RDD[JSONObject] = vehicleCarrierRdd.map(obj => {
      ((obj.getString("clue_id"),obj.getString("adcode")), obj)
    }).leftOuterJoin(circleSeedMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val circle_id: String = rightObj.getString("circle_id")
        val center_x: String = rightObj.getString("center_x")
        val center_y: String = rightObj.getString("center_y")
        leftObj.put("circle_id", circle_id)
        leftObj.put("center_x", center_x)
        leftObj.put("center_y", center_y)
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("vehicle关联seed后数据量："+joinLastClueInfoRdd.count())
    val nullCircleidRdd: RDD[(String, JSONObject)] = joinLastClueInfoRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("circle_id"))
    }).map(obj => {
      (obj.getString("adcode"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤circle_id为空的数据量："+nullCircleidRdd.count())
    val circleSeedDistinctSql=
      s"""
         |select distinct stay_adcode as adcode,circle_id,center_x,center_y
         |from dm_gis.dwd_ddjy_clue_circle_seed
         |""".stripMargin
    val circleSeedDistinctDf: DataFrame = spark.sql(circleSeedDistinctSql)
    val circleSeedDistinctRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark,circleSeedDistinctDf).map(obj=>{
      (obj.getString("adcode"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("circleSeed去重数据量:"+circleSeedDistinctRdd.count())
    var cantoneseClueRdd: RDD[JSONObject] = null
    var addCircleIdRdd: RDD[JSONObject]=null
    var interfaceReturnDataRdd: RDD[JSONObject]=null
    var minDistanceCircleidRdd: RDD[JSONObject]=null
    //1、不为空的Circleid
    val notNullCircleRdd: RDD[JSONObject] = joinLastClueInfoRdd.filter(obj=>{
      StringUtils.isNotEmpty(obj.getString("circle_id"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("notNullCircleRdd:"+notNullCircleRdd.count())
    if(nullCircleidRdd.count()!=0){
      val nullCircleidJoinSeedRdd: RDD[JSONObject] = nullCircleidRdd.leftOuterJoin(circleSeedDistinctRdd).map(obj => {
        val leftObj: JSONObject = obj._2._1
        val rightObj: JSONObject = obj._2._2.orNull
        if (rightObj != null) {
          val circle_id: String = rightObj.getString("circle_id")
          val center_x: Double = rightObj.getDouble("center_x")
          val center_y: Double = rightObj.getDouble("center_y")
          val longitude: Double = leftObj.getDouble("longitude")
          val latitude: Double = leftObj.getDouble("latitude")
          val distance: Double = DistanceUtils.getDistance(center_x, center_y, longitude, latitude)
          leftObj.put("distance", distance)
          leftObj.put("circle_id", circle_id)
          leftObj.put("center_x", center_x)
          leftObj.put("center_y", center_y)
        }
        leftObj
      })
      //2、最小distance的Circleid
      val notNullCircleAdcodeRdd: RDD[JSONObject] = nullCircleidJoinSeedRdd
        .filter(_.getString("circle_id") != null)
      minDistanceCircleidRdd = notNullCircleAdcodeRdd
        .groupBy(_.getString("clue_id"))
        .map(obj => {
          obj._2.toList.minBy(json=>JSONUtil.getJsonDouble(json,"distance",Int.MaxValue))
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("获取最小距离的circle_id的数据:"+minDistanceCircleidRdd.count())

      //3、调集散圈接口的Circleid
      val needCircleInterfaceDataRdd: RDD[JSONObject] = nullCircleidJoinSeedRdd.filter(obj=>{
        StringUtils.isEmpty(obj.getString("circle_id"))
      })
      logger.error("获取需要调集散圈接口的数据:"+needCircleInterfaceDataRdd.count())
      if(needCircleInterfaceDataRdd.count()!=0){
        val stationRdd: RDD[(String, JSONObject)] = needCircleInterfaceDataRdd.repartition(1000).map(obj => {
          val tmpObj = new JSONObject()
          val clue_id: String = obj.getString("clue_id")
          val adcode: String = obj.getString("adcode")
          val x: Double = obj.getDouble("longitude")
          val y: Double = obj.getDouble("latitude")
          tmpObj.put("clue_id", clue_id)
          tmpObj.put("adcode", adcode)
          tmpObj.put("x", x)
          tmpObj.put("y", y)
          ((adcode,clue_id), tmpObj)
        }).groupByKey().map(obj=>{
          val tmpObj: JSONObject = obj._2.minBy(_.getString("clue_id"))
          (tmpObj.getString("adcode"),tmpObj)
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        val returnRdd: RDD[((String, String), JSONObject)] = stationRdd.groupByKey().repartition(5).flatMap(obj=>{
          val stations: Array[JSONObject] = obj._2.toArray
          val stationsObj = new JSONObject()
          stationsObj.put("stations",stations)
          val returnObj: JSONObject = SfNetInteface.stationClusterInterface(stationsObj)
          val resultsArray: JSONArray = JSONUtil.getJsonArrayMulti(returnObj, "api_result.results")
          val tmpList = new util.ArrayList[JSONObject]()
          for (i <- 0 until resultsArray.size()) {
            val tmpObj = new JSONObject()
            val resultObj: JSONObject = resultsArray.getJSONObject(i)
            tmpObj.fluentPutAll(resultObj)
            tmpList.add(tmpObj)
          }
          tmpList.iterator()
        }).map(obj=>{
          ((obj.getString("clue_id"),obj.getString("adcode")),obj)
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("调取集散圈接口返回数据量："+returnRdd.count())
        /*val returnDf: DataFrame = returnRdd.map(obj => {
          val tmpObj: JSONObject = obj._2
          (
            tmpObj.getString("circle_id"),
            tmpObj.getString("adcode"),
            tmpObj.getString("clue_id"),
            tmpObj.getString("x"),
            tmpObj.getString("y"),
            tmpObj.getString("center_x"),
            tmpObj.getString("center_y")
          )
        }).toDF()
        SparkWrite.writeToHiveNoPart(spark,returnDf,"dm_gis.circle_infterface_tmp")
        returnRdd.take(10).foreach(println(_))*/
        //需求集散圈接口返回，并回挂的数据
        interfaceReturnDataRdd = needCircleInterfaceDataRdd.repartition(600).map(obj => {
          ((obj.getString("clue_id"),obj.getString("adcode")),obj)
        }).leftOuterJoin(returnRdd).map(obj=>{
          val rightObj: JSONObject = obj._2._2.getOrElse(new JSONObject())
          val leftObj: JSONObject = obj._2._1
          val center_x: String = JSONUtil.getJsonValSingle(rightObj,"center_x")
          val center_y: String = JSONUtil.getJsonValSingle(rightObj,"center_y")
          val circle_id: String = JSONUtil.getJsonValSingle(rightObj,"circle_id")
          leftObj.put("center_x", center_x)
          leftObj.put("center_y", center_y)
          leftObj.put("circle_id", circle_id)
          leftObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("调取集散圈接口并回挂后数据量："+interfaceReturnDataRdd.count())
        cantoneseClueRdd = notNullCircleRdd.union(notNullCircleAdcodeRdd).union(interfaceReturnDataRdd)
      }else{
        cantoneseClueRdd = notNullCircleRdd.union(notNullCircleAdcodeRdd)
      }
    }else{
      cantoneseClueRdd = notNullCircleRdd
    }
    if (minDistanceCircleidRdd!=null && interfaceReturnDataRdd!=null){
      addCircleIdRdd=minDistanceCircleidRdd.union(interfaceReturnDataRdd)
    }else if(minDistanceCircleidRdd==null && interfaceReturnDataRdd!=null){
      addCircleIdRdd=interfaceReturnDataRdd
    }else if(minDistanceCircleidRdd!=null && interfaceReturnDataRdd==null){
      addCircleIdRdd=minDistanceCircleidRdd
    }
    //更新Circel种子表
    if (addCircleIdRdd!=null){
      val cal = Calendar.getInstance
      val time = cal.getTime
      val create_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time)
      val addCircleIdDf: DataFrame = addCircleIdRdd.map(obj => {
        (
          obj.getString("clue_id"),
          obj.getString("clue_name"),
          obj.getString("adcode"),
          obj.getString("province"),
          obj.getString("city"),
          obj.getString("district"),
          obj.getString("circle_id"),
          obj.getString("center_x"),
          obj.getString("center_y"),
          create_time,
          obj.getString("longitude"),
          obj.getString("latitude"),
          obj.getString("clue_type")
        )
      }).toDF("unique_id", "belong_name", "stay_adcode", "stay_province", "stay_city", "stay_district", "circle_id", "center_x","center_y","create_time","longitude","latitude","clue_type")
      addCircleIdDf.createOrReplaceTempView("addCircleIdTmp")
      val updateCircleSeedSql=
        """
          |insert overwrite table dm_gis.dwd_ddjy_clue_circle_seed
          |select
          |unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type,longitude_avg,latitude_avg
          |from
          |(
          |	select
          |	unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type,
          |	avg(longitude) over(partition by circle_id) as longitude_avg,
          |	avg(latitude) over(partition by circle_id) as latitude_avg,
          |	row_number() over(partition by unique_id order by create_time desc) as rnk
          |	from
          |	(
          |		select * from addCircleIdTmp
          |		union
          |		select unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type
          |		from dm_gis.dwd_ddjy_clue_circle_seed
          |	) t1
          |) t2
          |where rnk=1
          |""".stripMargin
      spark.sql(updateCircleSeedSql)
    }
    //添加相关字段
    val addFieldRdd: RDD[JSONObject] = addFieldProcess(spark, cantoneseClueRdd, incDay)
    addFieldRdd.filter(_.getString("carrier_id")=="11391").map(obj=>{
      (obj.getString("carrier_id"),obj.getString("clue_src"))
    }).distinct().take(10).foreach(println(_))
    val seedSql=
      """
        |select distinct circle_id,longitude_avg,latitude_avg from dm_gis.dwd_ddjy_clue_circle_seed
        |""".stripMargin
    val updateSeedRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, seedSql).map(obj=>{
      (obj.getString("circle_id"),obj)
    })
    val vehicleCarrierReslutRdd: RDD[JSONObject] = addFieldRdd.map(obj => {
      (obj.getString("circle_id"), obj)
    }).leftOuterJoin(updateSeedRdd).map(obj => {
      val lefObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val longitude_avg: String = rightObj.getString("longitude_avg")
        val latitude_avg: String = rightObj.getString("latitude_avg")
        lefObj.put("center_x", longitude_avg)
        lefObj.put("center_y", latitude_avg)
      }
      lefObj
    })
    //写入vehicleCarrier表
    val vehicle_cal = Calendar.getInstance
    val vehicle_time = vehicle_cal.getTime
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(vehicle_time)
    val vehicleCarrierDf: DataFrame = vehicleCarrierReslutRdd.map(obj => {
      VehicleCarrier(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("clue_id"),
        obj.getString("clue_name"),
        obj.getString("clue_type"),
        obj.getString("clue_addr"),
        obj.getString("dept_type_name"),
        obj.getString("dept_transfer_flag"),
        obj.getString("area_name"),
        obj.getString("country_name"),
        obj.getString("delete_flg"),
        obj.getString("clue_src"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("latitude"),
        obj.getString("longitude"),
        obj.getString("src"),
        obj.getString("plan_depart_tm"),
        obj.getString("vehicle"),
        obj.getString("actual_capacity_load"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("line_distance"),
        obj.getString("circle_id"),
        obj.getString("center_x"),
        obj.getString("center_y"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("credit_code"),
        obj.getString("carrier_province"),
        obj.getString("carrier_city"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("carrier_circle_id"),
        obj.getString("carrier_circle_task_count"),
        obj.getString("register_vehicle_count"),
        obj.getString("carrier_scale"),
        obj.getString("carrier_suspected_address"),
        obj.getString("carrier_priority"),
        obj.getString("task_batch"),
        update_time
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("vehicleCarrier表数据量:"+vehicleCarrierDf.count())
    vehicleCarrierDf.createOrReplaceTempView("vehicleCarrierTmp")
    val vehicleCarrierSql=
      s"""
        |insert overwrite table dm_gis.dwd_ddjy_clue_vehicle_carrier_di partition(inc_day='$incDay') select * from vehicleCarrierTmp
        |""".stripMargin
    spark.sql(vehicleCarrierSql)
    joinLastClueInfoRdd.unpersist()
    nullCircleidRdd.unpersist()
    notNullCircleRdd.unpersist()
    vehicleCarrierDf.unpersist()
    addFieldRdd.unpersist()
  }

  def clueGas(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val stationInfoSql=
      """
        |select * from dm_gis.dm_ddjy_gas_station_info_di where delflag = '0'
        |--and poiid='9dff025d-0d08-4dae-a790-025d89472fa5_0'
        |""".stripMargin
    val stationInfoRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, stationInfoSql).map(obj=>{
      val lng: String = obj.getString("lng")
      val lat: String = obj.getString("lat")
      obj.put("agr_lng",lng)
      obj.put("agr_lat",lat)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //stationInfoRdd.take(10).foreach(println(_))
    val httpGeoPoi: String = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "739", "顺丰和粤运线索地图合并基础表", "获取adcode信息", "http://gis-int.int.sfdc.com.cn:1080/rgeo/api?x=%s&y=%s&opt=sf1&ak=%s", "85874304df9d44fc9752a62b63453b30", stationInfoRdd.count(), 50)

    val returnAdcodeRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,stationInfoRdd, SfNetInteface.geoPoiInterface, 50, "85874304df9d44fc9752a62b63453b30", 20000)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpGeoPoi)


    val stationInfoMapRdd = returnAdcodeRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val adcode_new: String = result.getString("adcode")
      obj.put("adcode_new", adcode_new)
      obj.remove("api_result")
      obj
    }).map(obj => {
      val gas_src: String = obj.getString("src")
      val gas_adcode: String = obj.getString("adcode")
      val gas_adcode_new: String = obj.getString("adcode_new")
      val gas_province: String = obj.getString("province")
      val gas_city: String = obj.getString("city")
      val gas_district: String = obj.getString("district")
      obj.put("gas_src",gas_src)
      obj.put("gas_adcode",gas_adcode)
      obj.put("gas_province",gas_province)
      obj.put("gas_city",gas_city)
      obj.put("gas_district",gas_district)
      obj.put("gas_adcode_new",gas_adcode_new)
      (obj.getString("gas_adcode_new"),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    /*val stationInfoMapDf: DataFrame = stationInfoMapRdd.map(obj => {
      val tmpObj: JSONObject = obj._2
      val gas_adcode: String = tmpObj.getString("gas_adcode")
      val gas_adcode_new: String = tmpObj.getString("gas_adcode_new")
      val poiid: String = tmpObj.getString("poiid")
      val lng: String = tmpObj.getString("lng")
      val lat: String = tmpObj.getString("lat")
      (poiid, gas_adcode, gas_adcode_new, lng, lat)
    }).toDF()
    stationInfoMapDf.createOrReplaceTempView("stationInfoMapTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_gas_info_adcode_di partition(inc_day='$incDay') select * from stationInfoMapTmp")*/
    val vehicleCarrierSql=
      s"""
        |select * from dm_gis.dwd_ddjy_clue_vehicle_carrier_di where inc_day='$incDay'
        |--and adcode='441323'
        |""".stripMargin
    val vehicleCarrierDf: DataFrame = spark.sql(vehicleCarrierSql)
    val value1: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleCarrierDf).groupBy(_.getString("clue_id")).map(obj => {
      val tmpObj: JSONObject = obj._2.minBy(_.getString("agr_id"))
      (tmpObj.getString("adcode"),tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("vehicleCarrier表根据clue_id去重后的数据量:"+value1.count())
    val stationInfoMapSegRdd: RDD[(String, JSONObject)] = stationInfoMapRdd.map(obj => {
      val tmpObj = new JSONObject()
      val poiid: String = obj._2.getString("poiid")
      val gas_adcode_new: String = obj._2.getString("gas_adcode_new")
      val lng: String = obj._2.getString("lng")
      val lat: String = obj._2.getString("lat")
      tmpObj.put("poiid", poiid)
      tmpObj.put("gas_adcode_new", gas_adcode_new)
      tmpObj.put("lng", lng)
      tmpObj.put("lat", lat)
      (gas_adcode_new, tmpObj)
    })
    val stationInfoMap: collection.Map[String, JSONObject] = stationInfoMapRdd.collectAsMap()
    val joinStationInfoRdd: RDD[JSONObject] = SparkJoin.leftOuterJoinOfLeftLeanElemJSONObject(value1, stationInfoMapSegRdd, 20, 40).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      (leftObj, rightObj)
    }).filter(_._2 != null).map(obj => {
      obj._1
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("关联后油站数据后数据量："+joinStationInfoRdd.count())
    /*joinStationInfoRdd.filter(obj=>{
      obj.getString("poiid")=="9dff025d-0d08-4dae-a790-025d89472fa5_0"
    }).take(200).foreach(println(_))*/
    value1.unpersist()
    val distanceLess5kmRdd: RDD[JSONObject] = joinStationInfoRdd.map(obj => {
      val longitude: Double = obj.getDoubleValue("longitude")
      val latitude: Double = obj.getDoubleValue("latitude")
      val lng: Double = obj.getDoubleValue("lng")
      val lat: Double = obj.getDoubleValue("lat")
      val distance: Double = DistanceUtils.getDistance(lng, lat, longitude, latitude)
      obj.put("belong_x", longitude)
      obj.put("belong_y", latitude)
      obj.put("distance", distance)
      obj
    }).filter(_.getDoubleValue("distance") < 5000.0).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("需要调高德规划接口的数据量："+distanceLess5kmRdd.count())
    joinStationInfoRdd.unpersist()
    val stationInfoMapBc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(stationInfoMap)
    val clueGasDf: DataFrame = distanceLess5kmRdd.map(obj=>{
      val poiid: String = obj.getString("poiid")
      val stationInfoMapValue: collection.Map[String, JSONObject] = stationInfoMapBc.value
      val rightObj: JSONObject = stationInfoMapValue.getOrElse(poiid, null)
      if (rightObj!=null){
        obj.fluentPutAll(rightObj)
      }
      obj
    }).map(obj => {
      MidClueGas(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("clue_id"),
        obj.getString("clue_name"),
        obj.getString("clue_type"),
        obj.getString("clue_addr"),
        obj.getString("dept_type_name"),
        obj.getString("dept_transfer_flag"),
        obj.getString("area_name"),
        obj.getString("country_name"),
        obj.getString("delete_flg"),
        obj.getString("clue_src"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("latitude"),
        obj.getString("longitude"),
        obj.getString("src"),
        obj.getString("plan_depart_tm"),
        obj.getString("vehicle"),
        obj.getString("actual_capacity_load"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("line_distance"),
        obj.getString("circle_id"),
        obj.getString("center_x"),
        obj.getString("center_y"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("credit_code"),
        obj.getString("carrier_province"),
        obj.getString("carrier_city"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("carrier_circle_id"),
        obj.getString("carrier_circle_task_count"),
        obj.getString("register_vehicle_count"),
        obj.getString("carrier_scale"),
        obj.getString("carrier_suspected_address"),
        obj.getString("carrier_priority"),
        obj.getString("poiid"),
        obj.getString("pid"),
        obj.getString("srcid"),
        obj.getString("grpid"),
        obj.getString("gas_src"),
        obj.getString("ss"),
        obj.getString("project_no"),
        obj.getString("url"),
        obj.getString("gas_adcode"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("stationname"),
        obj.getString("roadid"),
        obj.getString("roadclass"),
        obj.getString("roadname"),
        obj.getString("sfgunpricevec"),
        obj.getString("management_model"),
        obj.getString("gas_province"),
        obj.getString("gas_city"),
        obj.getString("gas_district"),
        obj.getString("addr"),
        obj.getString("tel"),
        obj.getString("querybrandid"),
        obj.getString("gaslocationtype"),
        obj.getString("headlabellist"),
        obj.getString("businesshours"),
        obj.getString("hasoilname"),
        obj.getString("oilnamevec"),
        obj.getString("discountmodelvec"),
        obj.getString("gunpricevec"),
        obj.getString("gappricevec"),
        obj.getString("priceactivityvec"),
        obj.getString("pricechangetimevec"),
        obj.getString("officialpricechangetimevec"),
        obj.getString("officialpricevec"),
        obj.getString("delflag"),
        obj.getString("createtime"),
        obj.getString("updatetime"),
        obj.getString("updatetimestamp"),
        obj.getString("cooperatestatus"),
        obj.getString("sfgunpricevec1"),
        obj.getString("businessstatus"),
        obj.getString("effectivestartvec"),
        obj.getString("effectiveendvec"),
        obj.getString("invoicedesc"),
        obj.getString("maintainbegintime"),
        obj.getString("maintainendtime"),
        obj.getString("outsidedriverdesc"),
        obj.getString("petrolstationqualify"),
        obj.getString("srcprice"),
        obj.getString("srclist"),
        obj.getString("dunprice"),
        obj.getString("skidmounted"),
        obj.getString("distance"),
        obj.getString("task_batch"),
        obj.getString("update_time"),
        obj.getString("gas_adcode_new")
      )
    }).distinct().toDF().repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("midClueGas表数据量:"+clueGasDf.count())
    distanceLess5kmRdd.unpersist()
    clueGasDf.createOrReplaceTempView("midClueGasTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_mid_clue_gas_di partition(inc_day='$incDay') select * from midClueGasTmp")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val start_day: String = DateUtil.getDateStr(incDay, -6, "")
    val task_batch=start_day+"-"+incDay
    logger.error("task_batch:"+task_batch)
    //读取dwd_ddjy_belong_join_own_di和dwd_ddjy_dept_line_sf_di处理并拼接
    val updateCarrieridDf: DataFrame = belongUnionDept(spark, incDay, task_batch)
    //调集散圈接口新增circle_id，center_x，center_y字段值（初始化流程）
    //stationClusterInterface(spark,updateCarrieridDf,incDay)
    //调集散圈接口新增circle_id，center_x，center_y字段值（迭代流程）
    iterationStationClusterInterface(spark,updateCarrieridDf,incDay)
    //生成粤运&顺丰合并线索关联油站数据表dm_gis.dwd_ddjy_clue_gas_di表
    clueGas(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
  case class VehicleCarrier (
                          agr_id:String,
                          agr_rs_id:String,
                          clue_id:String,
                          clue_name:String,
                          clue_type:String,
                          clue_addr:String,
                          dept_type_name:String,
                          dept_transfer_flag:String,
                          area_name:String,
                          country_name:String,
                          delete_flg:String,
                          clue_src:String,
                          adcode:String,
                          province:String,
                          city:String,
                          district:String,
                          latitude:String,
                          longitude:String,
                          src:String,
                          plan_depart_tm:String,
                          vehicle:String,
                          actual_capacity_load:String,
                          carrier_id:String,
                          carrier_name:String,
                          line_distance:String,
                          circle_id:String,
                          center_x:String,
                          center_y:String,
                          legal_person_name:String,
                          content:String,
                          credit_code:String,
                          carrier_province:String,
                          carrier_city:String,
                          carrier_status:String,
                          carrier_tag:String,
                          carrier_circle_id:String,
                          carrier_circle_task_count:String,
                          register_vehicle_count:String,
                          carrier_scale:String,
                          carrier_suspected_address:String,
                          carrier_priority:String,
                          task_batch:String,
                          update_time:String
  )
  case class MidClueGas (
                        agr_id:String,
                        agr_rs_id:String,
                        clue_id:String,
                        clue_name:String,
                        clue_type:String,
                        clue_addr:String,
                        dept_type_name:String,
                        dept_transfer_flag:String,
                        area_name:String,
                        country_name:String,
                        delete_flg:String,
                        clue_src:String,
                        adcode:String,
                        province:String,
                        city:String,
                        district:String,
                        latitude:String,
                        longitude:String,
                        src:String,
                        plan_depart_tm:String,
                        vehicle:String,
                        actual_capacity_load:String,
                        carrier_id:String,
                        carrier_name:String,
                        line_distance:String,
                        circle_id:String,
                        center_x:String,
                        center_y:String,
                        legal_person_name:String,
                        content:String,
                        credit_code:String,
                        carrier_province:String,
                        carrier_city:String,
                        carrier_status:String,
                        carrier_tag:String,
                        carrier_circle_id:String,
                        carrier_circle_task_count:String,
                        register_vehicle_count:String,
                        carrier_scale:String,
                        carrier_suspected_address:String,
                        carrier_priority:String,
                        poiid:String,
                        pid:String,
                        srcid:String,
                        grpid:String,
                        gas_src:String,
                        ss:String,
                        project_no:String,
                        url:String,
                        gas_adcode:String,
                        lng:String,
                        lat:String,
                        stationname:String,
                        roadid:String,
                        roadclass:String,
                        roadname:String,
                        sfgunpricevec:String,
                        management_model:String,
                        gas_province:String,
                        gas_city:String,
                        gas_district:String,
                        addr:String,
                        tel:String,
                        querybrandid:String,
                        gaslocationtype:String,
                        headlabellist:String,
                        businesshours:String,
                        hasoilname:String,
                        oilnamevec:String,
                        discountmodelvec:String,
                        gunpricevec:String,
                        gappricevec:String,
                        priceactivityvec:String,
                        pricechangetimevec:String,
                        officialpricechangetimevec:String,
                        officialpricevec:String,
                        delflag:String,
                        createtime:String,
                        updatetime:String,
                        updatetimestamp:String,
                        cooperatestatus:String,
                        sfgunpricevec1:String,
                        businessstatus:String,
                        effectivestartvec:String,
                        effectiveendvec:String,
                        invoicedesc:String,
                        maintainbegintime:String,
                        maintainendtime:String,
                        outsidedriverdesc:String,
                        petrolstationqualify:String,
                        srcprice:String,
                        srclist:String,
                        dunprice:String,
                        skidmounted:String,
                        distance:String,
                        task_batch:String,
                        update_time:String,
                        gas_adcode_new:String
                            )
}
