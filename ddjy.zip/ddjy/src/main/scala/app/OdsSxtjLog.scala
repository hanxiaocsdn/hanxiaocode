package app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.CommonTools.writeToHive

import java.text.SimpleDateFormat
import java.util.Date
/**
 *需求名称：推荐系统埋点行为：顺象推荐点击操作
 *需求方：马晶玲(01423372)
 *研发： 周勇(01390943)
 *任务创建时间：20230327
 *任务id：衡度平台698
 **/
object OdsSxtjLog {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)

    def main(args: Array[String]): Unit = {
      val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
      import spark.implicits._
      //跑数日期
      val dayvar: String = args(0)
      //获取log数据
      val logsql=s"""
                  |select replace(log,'\\\\','') log  from dm_gis.ods_ddjy_kafka_di
                  |where inc_day='$dayvar' and log like '%SXTJ%'
                  |""".stripMargin

      val log_data=spark.sql(logsql)
        .withColumn("log_a",when($"log".isNull || trim($"log")==="","").otherwise(clean_log_udf($"log")))
        .withColumn("message_a",get_json_object($"log_a","$.message"))
        .withColumn("ip",get_json_object($"message_a","$.ip"))
        .withColumn("message",get_json_object($"message_a","$.message"))
        .withColumn("ts",get_json_object($"message","$.ts"))
        .withColumn("allparams",get_json_object($"message","$.allparams"))
        .withColumn("clue_id_tmpa",get_json_object($"allparams","$.clueId"))
        .withColumn("clue_id_tmp",when($"clue_id_tmpa".isNull,"").otherwise($"clue_id_tmpa"))
        .withColumn("driver_phone",get_json_object($"allparams","$.driverPhone"))
        .withColumn("event_name",get_json_object($"allparams","$.eventName"))
        .withColumn("event_type",get_json_object($"allparams","$.eventType"))
        .withColumn("gas_id_tmpa",get_json_object($"allparams","$.gasId"))
        .withColumn("gas_id_tmp",when($"gas_id_tmpa".isNull,"").otherwise($"gas_id_tmpa"))
        .withColumn("operator_type",get_json_object($"allparams","$.operatorType"))
        .withColumn("vehicle_team_id",get_json_object($"allparams","$.vehicleTeamId"))
        .withColumn("vehicle_team_name",get_json_object($"allparams","$.vehicleTeamName"))
        .withColumn("operate_time",when($"ts".isNull || trim($"ts")==="","").otherwise(tranTimeToStringhm_udf($"ts")))
        .withColumn("duration",lit(""))
        .withColumn("extra_json",get_json_object($"allparams","$.extraJson"))
        .withColumn("extra_json",when($"extra_json".isNull || trim($"extra_json")==="","").otherwise($"extra_json"))
        .drop("log")

      //选择所需列
      val table_cols = spark.sql("""select * from dm_gis.ddjy_sys_operating_record_aaaaa limit 0""").schema.map(_.name).map(col)
      val resdata=log_data.withColumn("clue_id",explode(split($"clue_id_tmp","[,]")))
        .withColumn("gas_id",explode(split($"gas_id_tmp","[,]")))
        //分区日期
        .withColumn("inc_day",lit(dayvar))
        .withColumn("rank", row_number().over(Window.partitionBy("inc_day").orderBy(desc("inc_day"))))
        .withColumn("id",concat($"inc_day",$"rank"))

        .select(table_cols: _*)
      //数据存dm表
      writeToHive(spark, resdata, Seq("inc_day"), "dm_gis.ddjy_sys_operating_record_aaaaa")

      spark.close()


    }

  def clean_log(x:String): String ={
    x.replace("\\\\","")
      .replace("\",\"fields\"",",\"fields\"")
      .replace("\"message\":\"","\"message\":")
      .replace("extraJson\":\"","extraJson\":")
      .replace("","")
      .replace("}\"","}")
  }

  val clean_log_udf=udf(clean_log _)

  //时间戳转化：输入毫秒
  def tranTimeToStringhm(tm:String) :String={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val tim = fm.format(new Date(tm.toLong))
    tim
  }
  val tranTimeToStringhm_udf=udf(tranTimeToStringhm _)
}
