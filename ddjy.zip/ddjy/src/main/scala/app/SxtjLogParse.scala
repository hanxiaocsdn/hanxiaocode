package app

import java.util

import com.alibaba.druid.support.json.JSONUtils
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer


/**
 * @Description: 【顺象加油结算-加油推荐】系统日志解析V1.0
 * 需求人员：吕一锋 01410281
 * @Author: lixiangzhi 01405644
 * @Date: 2023.5.12 16:15
 * 任务id:792
 * 任务名称：加油推荐系统日志解析表
 * 依赖任务：697 Distcp-ods_ddjy_kafka_di
 * 数据源：ods_ddjy_kafka_di
 * 调用服务地址：
 * 数据结果：dm_ddjy_tj_log_parse_di
 */
object SxtjLogParse {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readTjLog(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val kafkaLogSql=
      s"""
        |select
        |log
        |from dm_gis.ods_ddjy_kafka_di
        |where inc_day='$incDay'
        |""".stripMargin
    val resultDf: DataFrame = SparkUtils.getRowToJson(spark, kafkaLogSql).filter(obj => {
      val log: String = obj.getString("log")
      val logObj: JSONObject = JSON.parseObject(log)
      val messageObj: JSONObject = JSONUtil.getJsonObjectMulti(logObj, "message")
      val appid: String = messageObj.getString("appid")
      appid == "SXTJ"
    }).flatMap(obj => {
      val log: String = obj.getString("log")
      val logObj: JSONObject = JSON.parseObject(log)
      val messageObj: JSONObject = JSONUtil.getJsonObjectMulti(logObj, "message")
      val message: JSONObject = JSONUtil.getJsonObjectMulti(messageObj, "message")
      val trackingRecoredList: JSONArray = JSONUtil.getJsonArrayMulti(message, "trackingRecoredList")
      val tmpList = new util.ArrayList[JSONObject]()

      for (i <- 0 until (trackingRecoredList.size())) {
        val tmpObj = new JSONObject()
        val trackingRecoredObj: JSONObject = trackingRecoredList.getJSONObject(i)
        val clueId: String = trackingRecoredObj.getString("clueId")
        val driverPhone: String = trackingRecoredObj.getString("driverPhone")
        val duration: String = trackingRecoredObj.getString("duration")
        val eventName: String = trackingRecoredObj.getString("eventName")
        val extraJson: String = trackingRecoredObj.getString("extraJson")
        val gasId: String = trackingRecoredObj.getString("gasId")
        val id: String = trackingRecoredObj.getString("id")
        val ip: String = trackingRecoredObj.getString("ip")
        val operateTime: String = trackingRecoredObj.getString("operateTime")
        val operatorType: String = trackingRecoredObj.getString("operatorType")
        val vehicleTeamId: String = trackingRecoredObj.getString("vehicleTeamId")
        val vehicleTeamName: String = trackingRecoredObj.getString("vehicleTeamName")
        val eventType: String = trackingRecoredObj.getString("eventType")
        tmpObj.put("clue_id", clueId)
        tmpObj.put("driver_phone", driverPhone)
        tmpObj.put("duration", duration)
        tmpObj.put("event_name", eventName)
        tmpObj.put("extra_json", extraJson)
        tmpObj.put("gas_id", gasId)
        tmpObj.put("id", id)
        tmpObj.put("ip", ip)
        tmpObj.put("operate_time", operateTime)
        tmpObj.put("operator_type", operatorType)
        tmpObj.put("vehicle_team_id", vehicleTeamId)
        tmpObj.put("vehicle_team_name", vehicleTeamName)
        tmpObj.put("event_type", eventType)
        println(tmpObj)
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    }).filter(obj=>{
      val operator_type: String = obj.getString("operator_type")
      operator_type=="1" || operator_type=="2"
    }).map(obj => {
      (
        obj.getString("clue_id"),
        obj.getString("driver_phone"),
        obj.getString("duration"),
        obj.getString("event_name"),
        obj.getString("extra_json"),
        obj.getString("gas_id"),
        obj.getString("id"),
        obj.getString("ip"),
        obj.getString("operate_time"),
        obj.getString("operator_type"),
        obj.getString("vehicle_team_id"),
        obj.getString("vehicle_team_name"),
        obj.getString("event_type")
      )
    })
      .toDF("clue_id", "driver_phone", "duration", "event_name", "extra_json", "gas_id", "id", "ip", "operate_time", "operator_type", "vehicle_team_id", "vehicle_team_name","event_type")
      //.distinct()
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("打印日志")
    logger.error("推荐系统日志解析结果数据量："+resultDf.count())
    resultDf.repartition(1).createOrReplaceTempView("resultTmp")
    spark.sql(s"insert overwrite table dm_gis.dm_ddjy_tj_log_parse_di partition(inc_day='$incDay') select * from resultTmp")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    readTjLog(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
}
