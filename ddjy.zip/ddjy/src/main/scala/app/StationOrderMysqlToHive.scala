package app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.CommonTools

/**
 * @Description:原始订单明细表mysql导入hive
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 10:46 2022/12/8
 * 任务id:515
 * 任务名称：new原始订单明细表mysql导入hive
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：ddjy_ods_station_order
 */
object StationOrderMysqlToHive {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def mysqlToHive(spark: SparkSession, mysqlTable: String,hiveTable:String,inc_day: String,mysqlDatabase:String,source:String,insertType:String): Unit = {
    import spark.implicits._
    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = s"jdbc:mysql://admin-m.dbdr.sfcloud.local:3306/$mysqlDatabase?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val userName = "bdpetl"
    val passWd = "bdp#etl@0922"
    logger.error(s"开始读取MySQL:$mysqlTable 表中数据")
    val orignal_df: Dataset[Row] = spark
      .read
      .format("jdbc")
      .option("url", url)
      .option("user", userName)
      .option("password", passWd)
      .option("dbtable", mysqlTable)
      .option("driver", driver)
      .load()
    //orignal_df.filter(s"order_sn in ('20221211201046001','20221210195012001','20221210185827001','20221210182622001')").show(10,false)
    val df: Dataset[Row] = orignal_df.withColumn("driver_name",regexp_replace($"driver_name","\t","_"))
      .withColumn("driver_name",regexp_replace($"driver_name","\r\n",""))
      .withColumn("driver_name",regexp_replace($"driver_name","\n",""))
      .withColumn("remark",regexp_replace($"remark","\t",""))
      .withColumn("remark",regexp_replace($"remark","\r\n",""))
      .withColumn("remark",regexp_replace($"remark","\n",""))
      .withColumn("carplate",regexp_replace($"carplate","\t",""))
      .withColumn("carplate",regexp_replace($"carplate","\r\n",""))
      .withColumn("carplate",regexp_replace($"carplate","\n",""))
      .withColumn("source",lit(s"$source"))
      .select("id","order_sn","code_id","petrol_card_id","petrol_card_sn","station_oper_id","carplate","station_oper_name",
        "driver_phone","station_name","station_id","update_by","driver_id","driver_name","distribute_oil_type","petrol_type","petrol_type_name",
        "oil_mass","official_price","station_price","ft_sale_price","ft_cost_price","ft_sale_money","ft_cost_money","discount_price","offical_pay_money",
        "station_pay_money","discount_pay_money","corp_id","car_team_id","car_team_name","order_status","pay_time","approval_status","approval_time",
        "approval_by","remit_status","remit_id","del_flag","create_date","create_by","update_date","discount_model","fleet_refund","station_refund",
        "ft_profit","fleet_refund_status","station_refund_status","transaction_amount","wallet_id","station_received_amount","remark","settle_model",
        "discard_time","limit_type","order_source","petrol_resources","pay_type","deduction_type","is_wx_send","stan","shell_pay_result","verification_status",
        "shell_discount","shell_qrcode","business_time","lock_status","driver_type","bdp_time","coupon_id","coupon_free_money","oil_no","gun_no","third_order_sn",
        "order_type","source","longitude","latitude","station_type","invoice_company_id","invoice_company_name","capital_model","service_charge","petrol_type_code",
        "main_corp_info_id","main_corp_info_name","three_station_pay_money","team_discount_model","is_full_oil","ocr_carplate","audit_result","team_audit_date"
      )
      .filter(s"replace(substr(update_date,0,10),'-','') = '$inc_day'")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //df.filter(s"order_sn in ('20221226231853001','20221210195012001','20221210185827001','20221210182622001')").show(10,false)
    //df.filter(s"id in ('19875')").show(10,false)
    logger.error(s"$mysqlTable"+"表数据量:"+df.count())
    // 存到hive备份
    val tempView=s"$mysqlTable"+"_tmp"
    df.createOrReplaceTempView(tempView)
    spark.sql(s"insert $insertType table $hiveTable partition(inc_day='$inc_day') select * from $tempView")
    df.unpersist()
  }
  def df2HiveByOverwrite(df: DataFrame, table: String): Unit = {
    logger.error(s"开始写入到 Hive：$table")
    df
      .write
      .mode(SaveMode.Overwrite)
      .insertInto(table)
    logger.error(s"写入 $table 成功！")
  }

  def execute(inc_day: String, mysqlTable: String, hiveTable: String,mysqlDatabase:String,source:String,insertType:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    mysqlToHive(spark,mysqlTable,hiveTable,inc_day,mysqlDatabase,source,insertType)
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val mysqlTable: String = args(1)
    val hiveTable: String = args(2)
    val mysqlDatabase: String = args(3)
    val source: String = args(4)
    val insertType: String = args(5)
    execute(inc_day,mysqlTable,hiveTable,mysqlDatabase,source,insertType)
    //execute()
    logger.error("======>>>>>>StationOrderMysqlToHive Execute Ok")
  }

}
