package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @Description:补录油站车队维表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:
 * 任务名称：补录油站车队维表
 * 依赖任务：一次性任务
 * 数据源：
 * 调用服务地址：无
 * 数据结果：
 */
object CollectionStationTeamInfoData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def dateStream(fromDt:LocalDate):Stream[LocalDate]={
    fromDt #::dateStream(fromDt.plusDays(1))
  }

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String) = {
    spark.sql(
      s"""
        |insert overwrite table dm_gis.ddjy_sales_target_df partition(inc_day)
        |select
        |id
        |,type
        |,outer_id
        |,name
        |,org_level
        |,org_code
        |,org_name
        |,sup_code
        |,sub_code
        |,sign_target
        |,sign_count
        |,sign_gap
        |,trade_target
        |,trade_amount
        |,trade_gap
        |,trade_achievement_rate
        |,sign_achievement_rate
        |,inc_trade_target
        |,inc_trade_amount
        |,inc_trade_achievement_rate
        |,month
        |,next_trade_target
        |,next_sign_target
        |,next_inc_trade_target
        |,create_date
        |,create_by
        |,create_by_name
        |,update_date
        |,update_by
        |,update_by_name
        |,deleted
        |,sale_role
        |,month_trade_achievement_rate
        |,month_trade_target
        |,month_trade_gap
        |,month_next_trade_target
        |,month_trade_amount
        |,'${inc_day}' as inc_day
        |from dm_gis.ddjy_sales_target_df
        |where inc_day='20230523'
        |""".stripMargin)
    logger.error("写入ddjy_dim_station_info_filter每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    var before_yesterday=""
    var last_seven_day: String=""
    for (i <- (0 to 70).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      before_yesterday = DateUtil.getDateStr(incDay, -1, "")
      last_seven_day = DateUtil.getDateStr(incDay, -6, "")
      stationProcess(spark,incDay,before_yesterday,last_seven_day)
    }
    /*var inc_day=""
    var before_yesterday=""
    while (iterator.hasNext) {
      inc_day = iterator.next()
      before_yesterday = DateUtil.getDateStr(inc_day, -1, "")
      var last_seven_day: String = DateUtil.getDateStr(inc_day, -6, "")
      //last_seven_day = DateUtil.changeDateSep(last_seven_day,"","-")
      //spark.sql("set hive.vectorized.execution.enabled = false")
      //stationTeamProcess(spark,inc_day,before_yesterday)
      stationProcess(spark,inc_day,before_yesterday,last_seven_day)
    }*/
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>补录车辆、油站、钱包维表 Execute Ok")
  }

}
