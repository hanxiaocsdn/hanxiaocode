package app

import java.sql.{Connection, DriverManager, PreparedStatement, ResultSet}

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql._
import org.apache.spark.sql.functions.udf

/**
 * @Description:粤运经验库LinkInfo表mysql导入hive
 * 需求方：左佳怡 01403789
 * @Author: lixiangzhi 01405644
 * @Date: 10:46 2022/12/8
 * 任务id:478
 * 任务名称：经验库linkinfo导入hive
 * 依赖任务：无
 * 数据源：linkinfo
 * 调用服务地址：
 * 数据结果：ddjy_linkinfo
 */
object LinkInfoMysqlToHive {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def mysqlToHive(spark: SparkSession, mysqlTable: String,hiveTable:String,inc_day: String): Unit = {
    import spark.implicits._
    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://100.96.162.85:3306/exprp?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val userName = "gas"
    val passWd = "Steve@1212"
    val maxLinkid: Long = getMaxLinkid(spark, mysqlTable)
    val tableName=s"(select linkid,dir,roadclass,linktype,formway,fc,ownership,srcid,tollid,state,timestamp,inserttime,linklength,tracktype,overhead,ST_asWkt(rect) as rect,ST_asWkt(geolinkpoint) as geolinkpoint,vehicle_type,max_weight,max_width,max_height,adcode,uniqueid,version_id,gasstation,road_name,rid,rversion,updatetime,tracktime,gridid,del_flag from $mysqlTable) as t"
    logger.error(s"开始读取MySQL:$mysqlTable 表中数据")
    val orignal_df: DataFrame = spark
      .read
      .format("jdbc")
      .option("encoding","utf-8")
      .option("url", url)
      .option("user", userName)
      .option("password", passWd)
      .option("dbtable", tableName)
      .option("driver", driver)
      .option("partitionColumn", "linkid")
      .option("numPartitions", 60)
      .option("lowerBound", 0)
      .option("upperBound", maxLinkid)
      .option("fetchsize", 100000)
      .option("batchsize", 100000)
      .load().toDF()
/*    val df: DataFrame = orignal_df
      .withColumn("rect", orignal_df("rect").cast(String))
      .withColumn("geolinkpoint", orignal_df("geolinkpoint").cast(String))*/
    // 存到hive备份
    val tempView=s"$mysqlTable"+"_tmp"
    orignal_df.createOrReplaceTempView(tempView)
    spark.sql(s"insert overwrite table $hiveTable select * from $tempView")
    orignal_df.unpersist()
  }
  def xtostring(x:Any):String={
    x.toString
  }
  val xtostring_udf=udf(xtostring _)
  def getMaxLinkid(spark: SparkSession, mysqlTableNew: String) = {
    //读取mysql数据
    val mysqlConn: Connection = mysqlConnection
    logger.error("mysql链接成功")
    val houseInfoSql=s"select max(linkid) as linkid from $mysqlTableNew"
    //查询view_house表信息
    val houseInfoPS: PreparedStatement = mysqlConn.prepareStatement(houseInfoSql)
    val houseInfoPSResult: ResultSet =houseInfoPS.executeQuery()
    var linkid:Long=0
    while (houseInfoPSResult.next()){
      linkid = houseInfoPSResult.getLong("linkid")
    }
    logger.error("linkid最大值："+linkid.toString)
    linkid
  }
  def mysqlConnection(): Connection ={
    //测试环境mysql
    val jdbcUrl=s"jdbc:mysql://100.96.162.85:3306/exprp?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val mysqlConn: Connection = DriverManager.getConnection(jdbcUrl, "gas", "Steve@1212")
    mysqlConn

  }
  def execute(inc_day: String, mysqlTable: String, hiveTable: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    mysqlToHive(spark,mysqlTable,hiveTable,inc_day)
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val mysqlTable: String = args(1)
    val hiveTable: String = args(2)
    execute(inc_day,mysqlTable,hiveTable)
    //execute()
    logger.error("======>>>>>>LinkInfoMysqlToHive Execute Ok")
  }

}
