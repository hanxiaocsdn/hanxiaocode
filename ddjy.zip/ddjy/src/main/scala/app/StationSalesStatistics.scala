package app

import app.TeamClueTransformation.writeToHive
import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.Functions.{getDateDiff, sortField, timeToCustomTime2}

import java.text.SimpleDateFormat
import scala.collection.mutable.ArrayBuffer

/**
 * 油站全量表需求
 * 需求方：陶慧（01424177）
 * @author 徐游飞（01417347）
 * 任务ID：568
 * 任务名称：油站全量数据指标报表_2
 */
object StationSalesStatistics {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def getDataSouse(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    // 获取油站表数据
    val info_filter_sql =
      s"""
         |select
         |  petrol_station_name,
         |  id,
         |  city_name,
         |  linkman_name,
         |  linkman_phone,
         |  create_date,
         |  country_price
         |from
         |  dm_gis.ddjy_dim_station_info_filter
         |where
         |  inc_day = '$incDay'
         |""".stripMargin
    println("获取info_filter表数据 sql语句：")
    println(info_filter_sql)
    val df_info_filter = spark.sql(info_filter_sql)

    // 获取订单表数据
    val repartition_di_sql =
      s"""
         |select
         |  station_id,
         |  order_status,
         |  ft_sale_money,
         |  car_team_id,
         |  pay_time,
         |  oil_mass,
         |  order_sn
         |from
         |  dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where
         |  inc_day <= '$incDay'
         |""".stripMargin
    println("获取repartition_di表数据 sql语句：")
    println(repartition_di_sql)
    val df_repartition_di = spark.sql(repartition_di_sql)
      .withColumn("id",'station_id)
      .drop("station_id")

    // 获取原始油品价格表数据
    val price_current_sql =
      s"""
         |select
         |  station_id,
         |  ft_sale_price,
         |  update_date,
         |  del_flag
         |from
         |  dm_gis.ddjy_ods_dim_petrol_price_current
         |where
         |  inc_day = '$incDay'
         |  and del_flag = 0
         |""".stripMargin
    println("获取price_current表数据 sql语句：")
    println(price_current_sql)
    val df_price_current = spark.sql(price_current_sql)
      .withColumn("id",'station_id)
      .withColumn("rn", row_number().over(Window.partitionBy('id).orderBy(desc("update_date"))))
      .filter('rn === 1)
      .drop("station_id","rn")

    // 获取最新分区的油站车队数据
    val merge_di_sql =
      s"""
         |select
         |	  stationname as petrol_station_name,
         |	  clue_task_count,
         |	  pathway_task_count,
         |	  carrier_id,
         |    inc_day as day
         |	from
         |	  dm_gis.dm_ddjy_gas_carrier_merge_di
         |	where
         |	  inc_day in (
         |	    select
         |	      max(inc_day)
         |	    from
         |	      dm_gis.dm_ddjy_gas_carrier_merge_di
         |       where inc_day <= '$incDay'
         |	  )
         |""".stripMargin
    println("获取merge_di表数据 sql语句：")
    println(merge_di_sql)
    val df_merge_di = spark.sql(merge_di_sql)

    // 获取油站历史数据
    val quota_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.ddjy_dwd_station_quota_dtl
         |where
         |  inc_day < '$incDay'
         |""".stripMargin

    println("获取油站历史数据 sql语句：")
    println(quota_sql)
    val df_station_quota_all = spark.sql(quota_sql)

    // 获取油站销售维表
    val user_info_sql =
      s"""
         |select
         |  petrol_station_name,
         |  user_name,
         |  '' as user_id,
         |  sub_name,
         |  '' as sub_code,
         |  sup_name,
         |  '' as sup_code
         |from
         |  dm_gis.ddjy_dim_station_sales_info
         |where
         |  station_num > 0
         |""".stripMargin

    println("获取油站销售维表数据 sql语句：")
    println(user_info_sql)
    val df_user_info = spark.sql(user_info_sql)

    //    // 获取油站每天的平均油价，暂时用不到
    //    val avg_break_sql =
    //      s"""
    //         |select
    //         |  sum(breaks) / count(distinct station_id) as avg_break
    //         |from
    //         |  (
    //         |    select
    //         |      (country_price - ft_sale_price) as breaks,
    //         |      station_id
    //         |    from
    //         |      dm_gis.ddjy_ods_dim_petrol_price_current
    //         |    where
    //         |      del_flag = 0
    //         |      and inc_day = '$incDay'
    //         |  ) t
    //         |""".stripMargin
    //    println("获取油站每天的平均油价数据 sql语句：")
    //    println(avg_break_sql)
    //    val df_avg_break = spark.sql(avg_break_sql)

    (df_info_filter,df_repartition_di,df_price_current,df_merge_di,df_station_quota_all,df_user_info)
  }

  def run(spark: SparkSession, incDay: String) = {
    import spark.implicits._

    // 获取数据
    val dataSouse = getDataSouse(spark, incDay)
    // 主表
    val df_info_filter = dataSouse._1
    val df_repartition_di = dataSouse._2
    val df_price_current = dataSouse._3
    val df_merge_di = dataSouse._4
    val df_station_quota = dataSouse._5
    val df_user_info = dataSouse._6

    val df_station_quota_all = df_station_quota
      .filter('is_off === "否")
      .select("id","task_type_real","exception_label_real","task_status","start_time","inc_day")
      .withColumnRenamed("task_type_real","task_type")
      .withColumnRenamed("exception_label_real","exception_label")
      .withColumn("ft_sale_money",lit(-99))
      .withColumn("last_pay_time_diff",lit(-99))
      .withColumn("consumer_cnt",lit(-99))
      .withColumn("task_status_di",lit(-99))

    // 单独计算 team_over3，fuel_frequency 字段
    val df_over3 = df_info_filter
      .join(df_merge_di,Seq("petrol_station_name"),"left")
      .groupBy("id")
      .agg(
        countDistinct(when('clue_task_count.cast("double") >= 3,'carrier_id).otherwise(null)) as "jisan_team_over3_cnt",
        countDistinct(when('pathway_task_count.cast("double") >= 3,'carrier_id).otherwise(null)) as "yantu_team_over3_cnt",
        sum(when('clue_task_count.cast("double") >= 3,'clue_task_count).otherwise(null)) as "jisan_fuel_frequency_sum",
        sum(when('pathway_task_count.cast("double") >= 3,'pathway_task_count).otherwise(null)) as "yantu_fuel_frequency_sum"
      )
      .withColumn("team_over3",dataToJsonArray(lit("集散点"),'jisan_team_over3_cnt,lit("沿途"),'yantu_team_over3_cnt))
      .withColumn("fuel_frequency",dataToJsonArray(lit("集散点"),'jisan_fuel_frequency_sum,lit("沿途"),'yantu_fuel_frequency_sum))
      .select("id","team_over3","fuel_frequency")

    // 油站关联订单表
    val df_info_all = df_info_filter
      .join(df_repartition_di,Seq("id"),"left")
      .join(df_price_current,Seq("id"),"left")

    // 按油站维度统计相关指标
    val df_statistics_dtl = df_info_all
      .withColumn("after_close_ft_sale_money",when('del_flag === 0,'ft_sale_price).otherwise(null))
      .withColumn("oline_days",getDateDiff(lit(incDay),timeToCustomTime2('create_date,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")),lit("yyyyMMdd"),lit(0))+1)
      .groupBy("id")
      .agg(
        sum(when('order_status === 2,'ft_sale_money).otherwise(null)) as "sum_gmv",
        countDistinct(when('order_status === 2,'car_team_id).otherwise(null)) as "consumer_cnt",
        min(when('order_status === 2,'pay_time).otherwise(null)) as "first_pay_time",
        max(when('order_status === 2,'pay_time).otherwise(null)) as "last_pay_time",
        sum(when('order_status === 2,'oil_mass).otherwise(null)) as "oil_mass_sum",
        count(when('order_status === 2,'order_sn).otherwise(null)) as "order_cnt",
        max('oline_days) as "oline_days",
        max('create_date) as "create_date",
        max('country_price) as "country_price",
        max(when('del_flag === 0,'ft_sale_price).otherwise(null)) as "ft_sale_price",
        max('petrol_station_name) as "petrol_station_name",
        max('city_name) as "city_name",
        max('linkman_name) as "linkman_name",
        max('linkman_phone) as "linkman_phone",
        max('ft_sale_money) as "ft_sale_money",
        max('after_close_ft_sale_money) as "after_close_ft_sale_money"
      )
      .withColumn("avg_daily_gmv",round('sum_gmv / 'oline_days,2))
      .withColumn("conversion_time",ceil(getDateDiff('first_pay_time,'create_date,lit("yyyy-MM-dd HH:mm:ss"),lit(2))))
      .withColumn("single_avg_oill_mass",round('oil_mass_sum / 'order_cnt,2))
      .withColumn("last_pay_time_yymmdd",timeToCustomTime2('last_pay_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd"))) //辅助字段
      .withColumn("last_pay_time_diff",getDateDiff(lit(incDay),'last_pay_time_yymmdd,lit("yyyyMMdd"),lit(0))) //辅助字段
      // 计算油站当天的 exception_label 标签，后面根据历史数据再重新赋值
      .withColumn("exception_label",getExceptionLabel('oline_days,'sum_gmv,'last_pay_time_diff,'country_price,'ft_sale_price,'conversion_time,'consumer_cnt))
      // 计算油站当天的 exception_label 标签，后面根据历史数据再重新赋值
      .withColumn("task_type",getTaskType('exception_label))
      // 计算油站当天的异常开始时间 start_time，后面根据历史数据再重新赋值
      .withColumn("start_time",when('task_type.contains("油站异常"),incDay).otherwise(null))
      .withColumn("main_problem",lit(""))
      .withColumn("problem_description",lit(""))
      // 关联获取油站指标 team_over3，fuel_frequency 字段
      .join(df_over3,Seq("id"),"left")
      .withColumn("inc_day",lit(incDay))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 根据历史数据计算任务状态，task_status
    val df_task_status = df_statistics_dtl
      .select("id","task_type","exception_label","ft_sale_money","last_pay_time_diff","consumer_cnt","inc_day")
      .union(df_station_quota_all.select("id","task_type","exception_label","ft_sale_money","last_pay_time_diff","consumer_cnt","inc_day"))
      .withColumn("time",'inc_day)
      .na.fill("null", Array("task_type","exception_label","time"))
      .withColumn("task_type",when('task_type === "","null").otherwise('task_type))
      .withColumn("exception_label",when('exception_label === "","null").otherwise('exception_label))
      .withColumn("num", row_number().over(Window.partitionBy('id).orderBy(asc("time"))))
      .groupBy("id")
      .agg(
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('task_type)) as "task_type_all",
        concat_ws("|",collect_list('time)) as "time_all",
        concat_ws("|",collect_list('exception_label)) as "exception_label_all",
        max('ft_sale_money) as "ft_sale_money",
        max('last_pay_time_diff) as "last_pay_time_diff",
        max('consumer_cnt) as "consumer_cnt"
      )
      // 分组内的字段拼接值按照num顺序重新排序
      .withColumn("task_type_all",sortField('num,'task_type_all))
      .withColumn("time_all",sortField('num,'time_all))
      .withColumn("exception_label_all",sortField('num,'exception_label_all))
      .withColumn("task_status",getTaskStatus('task_type_all,'time_all,'exception_label_all,'ft_sale_money,'last_pay_time_diff,'consumer_cnt))
      .select("id","task_status")

    // 根据历史数据重新油站异常开始时间和闭环时间以及最新的任务类型和状态，start_time，close_time，task_type_new，exception_label_new
    val df_start_time = df_statistics_dtl
      .drop("task_status")
      .join(df_task_status.select("id","task_status"),Seq("id"),"left")
      .withColumn("task_status_di",'task_status)
      .select("id","task_type","exception_label","start_time","task_status","task_status_di","inc_day")
      .union(df_station_quota_all.select("id","task_type","exception_label","start_time","task_status","task_status_di","inc_day"))
      .withColumn("time",'inc_day)
      .na.fill("null", Array("task_status","task_type","exception_label","time","start_time"))
      .withColumn("task_status",when('task_status === "","null").otherwise('task_status))
      .withColumn("task_type",when('task_type === "","null").otherwise('task_type))
      .withColumn("exception_label",when('exception_label === "","null").otherwise('exception_label))
      .withColumn("start_time",when('start_time === "","null").otherwise('start_time))
      .withColumn("num", row_number().over(Window.partitionBy('id).orderBy(asc("time"))))
      .groupBy("id")
      .agg(
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('time)) as "time_all",
        concat_ws("|",collect_list('task_status)) as "task_status_all",
        concat_ws("|",collect_list('task_type)) as "task_type_all",
        concat_ws("|",collect_list('exception_label)) as "exception_label_all",
        concat_ws("|",collect_list('start_time)) as "start_time_all",
        max('task_status_di) as "task_status_di"
      )
      // 分组内的字段拼接值按照num顺序重新排序
      .withColumn("time_all",sortField('num,'time_all))
      .withColumn("task_status_all",sortField('num,'task_status_all))
      .withColumn("task_type_all",sortField('num,'task_type_all))
      .withColumn("exception_label_all",sortField('num,'exception_label_all))
      .withColumn("start_time_all",sortField('num,'start_time_all))
      // 计算 start_time
      .withColumn("start_time",getStartTime('task_status_all,'task_type_all,'time_all,'start_time_all))
      // 计算 close_time
      .withColumn("close_time",getCloseTime('task_status_all,'task_type_all,'time_all))
      // 计算 task_type_new
      .withColumn("task_type_new",getTaskStatusNew('task_type_all,'exception_label_all,'time_all,'start_time,'task_status_di,lit("type")))
      // 计算 exception_label_new
      .withColumn("exception_label_new",getTaskStatusNew('task_type_all,'exception_label_all,'time_all,'start_time,'task_status_di,lit("label")))
      .select("id","start_time","close_time","task_type_new","exception_label_new")

    // 计算闭环后指标
    val df_after_close = df_info_all
      .join(df_start_time,Seq("id"),"left")
      .withColumn("pay_time_yyyyMMdd",timeToCustomTime2('pay_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("close_time_7",getTimeAfter('close_time,lit(7)))
      .groupBy("id")
      .agg(
        sum(when('pay_time_yyyyMMdd > 'close_time and 'pay_time_yyyyMMdd < 'close_time_7,'ft_sale_money).otherwise(null)) as "after_close_daily_gmv",
        countDistinct(when('pay_time_yyyyMMdd > 'close_time and 'pay_time_yyyyMMdd < 'close_time_7,'car_team_id).otherwise(null)) as "after_close_consumer"
      )
      .withColumn("after_close_daily_gmv",'after_close_daily_gmv / 7)
      .select("id","after_close_daily_gmv","after_close_consumer")

    // 将油站所有指标关联
    val df_station_data = df_statistics_dtl
      .drop("start_time")
      .join(df_task_status,Seq("id"),"left")
      .join(df_start_time,Seq("id"),"left")
      .join(df_after_close,Seq("id"),"left")
      .join(df_user_info,Seq("petrol_station_name"),"left")
      //
      .withColumn("close_cycle",getDateDiff('close_time,'start_time,lit("yyyyMMdd"),lit(0)))
      .withColumn("statistical_day",timeToCustomTime2(lit(incDay),lit("yyyyMMdd"),lit("yyyy-MM-dd")))
      .withColumn("close_time_diff",getDateDiff(lit(incDay),'close_time,lit("yyyyMMdd"),lit(0)))
      .withColumn("task_type_real",'task_type)
      .withColumn("exception_label_real",'exception_label)
      // 对task_type和exception_label重新赋值（闭环7天内值不变）
      .withColumn("task_type",when('task_type_new === "是",'task_type).otherwise('task_type_new))
      .withColumn("exception_label",when('exception_label_new === "是",'exception_label).otherwise('exception_label_new))
      .withColumn("is_closed",when('close_time_diff <= 7,"是"))
      //.withColumn("is_off",when('task_status === "已闭环" and 'close_time_diff === 6,"是").otherwise("否"))
      .withColumn("is_off",lit("否"))
      .withColumn("create_day",lit(incDay)) // 数据时间字段（数据最早生成的时间，为了union后区分方便）
      .withColumn("inc_day",lit(incDay))

    // 获取历史数据合并后落表
    val cols_ret = spark.sql("""select * from dm_gis.ddjy_dwd_station_quota_dtl limit 0""").schema.map(_.name).map(col)

    val df_station_quota_his = df_station_quota
      .withColumn("close_time_diff",getDateDiff('inc_day,'close_time,lit("yyyyMMdd"),lit(0)))
      .withColumn("is_off_flag",when('task_status === "已闭环" and 'close_time_diff === 6,"true"))
      .filter('is_off_flag === "true") // 获取历史已闭环油站第七天的数据
      .withColumn("is_off",lit("是"))
      .withColumn("rn",row_number().over(Window.partitionBy("id","create_day").orderBy(desc("inc_day"))))
      .filter('rn === 1)
      .select(cols_ret: _*)

    val df_ret = df_station_data
      .select(cols_ret: _*)
      .union(df_station_quota_his)  // 将历史已闭环油站第七天的数据union进来
      .withColumn("statistical_day",timeToCustomTime2(lit(incDay),lit("yyyyMMdd"),lit("yyyy-MM-dd")))
      .withColumn("inc_day",lit(incDay))

    // 结果数据落表
    writeToHive(spark,df_ret.select(cols_ret: _*),Seq("inc_day"),"dm_gis.ddjy_dwd_station_quota_dtl")

    df_statistics_dtl.unpersist()

  }

  // 生成 task_type 标签
  def getTaskType = udf((exception_label:String) => {
    var task_type = ""

    if (exception_label != null && exception_label.trim != "") {

      if(exception_label.contains("0流水油站") || exception_label.contains("流水异常") || exception_label.contains("客户量少"))
        task_type = "油站异常"
    }

    task_type
  })

  // 生成 exception_label 标签
  def getExceptionLabel = udf((oline_days:String,sum_gmv:Double,last_pay_time_diff:String,country_price:String,ft_sale_price:String,conversion_time:String,consumer_cnt:Int) => {
    val exception_label_arr = new ArrayBuffer[String]()

    if (last_pay_time_diff != null && last_pay_time_diff.trim != "") {

      var oline_days_diff = 0.0
      var time_diff = 0.0
      var country_p = 0.0
      var ft_p = 0.0
      var conversion_diff = 0.0
      try {
        oline_days_diff = oline_days.toDouble
        time_diff = last_pay_time_diff.toDouble
        country_p = country_price.toDouble
        ft_p = ft_sale_price.toDouble
        conversion_diff = conversion_time.toDouble
      } catch {
        case e: Exception => println(">>>转换异常" + e)
      }

      if (oline_days_diff > 5 && sum_gmv == 0.0) exception_label_arr.append("0流水油站")
      if (time_diff > 7) exception_label_arr.append("流水异常")
      if ((country_p - ft_p) < 0.3 && (country_p != 0.0 || ft_p != 0.0)) exception_label_arr.append("优惠少")
      if (conversion_diff > 5) exception_label_arr.append("转化周期长")
      if (consumer_cnt < 5) exception_label_arr.append("客户量少")
    }

    exception_label_arr.mkString(";")
  })

  // 数据转换为json格式
  def dataToJsonArray = udf((col1: String,col2: String,col3: String,col4: String) => {
    val obj = new JSONObject()

    obj.put(col1,col2)
    obj.put(col3,col4)

    obj.toJSONString
  })

  // 获取指定时间前七天日期函数
  def getTimeAfter = udf((time:String,afterCnt: Int) => {
    var ret_time = ""
    if(time != null && time.trim != ""){
      var t1 = 0L
      try{
        t1 = new SimpleDateFormat("yyyyMMdd").parse(time).getTime
        ret_time = new SimpleDateFormat("yyyyMMdd").format(t1 + 1000 * 60 * 60 * 24 * afterCnt)
      }catch {
        case e: Exception => println(">>>转换异常"+e)
      }
    }
    ret_time
  })

  // 获取 task_status 字段函数
  def getTaskStatus = udf((task_type_all:String,time_all:String,exception_label_all: String,ft_sale_money: String,exception_label_diff_min: String,consumer_cnt: String) => {
    var ret_task_status = ""

    if(task_type_all != null && task_type_all.trim != ""){

      val task_type_arr = task_type_all.split("\\|")
      val time_arr = time_all.split("\\|")
      val exception_label_arr = exception_label_all.split("\\|")
      var bihuan_time = "19000101"

      for(i <- 0 until task_type_arr.length) {

        val time_i = time_arr(i)
        var t1 = 0L
        var t2 = 0L
        try{
          t1 = new SimpleDateFormat("yyyyMMdd").parse(time_i).getTime
          t2 = new SimpleDateFormat("yyyyMMdd").parse(bihuan_time).getTime
        }catch {
          case e: Exception => println(">>>转换异常"+e)
        }
        val time_diff = ((t1 - t2) / (1000*60*60*24)).toInt

        if(time_diff >= 7 && i != 0){
          ret_task_status = ""

          val task_type_i = task_type_arr(i)  // 当天油站是否异常标签
          val task_type_i_1 = task_type_arr(i-1) // 前一天油站是否异常标签
          val exception_label_i_1 = exception_label_arr(i-1) // 前一天油站异常类型
          val time_ii = time_arr(i)

          if(task_type_i_1.equals("油站异常") && !task_type_i.equals("油站异常")){
            if(exception_label_i_1.contains("0流水油站") && ft_sale_money.toDouble > 0 ){
              ret_task_status = "已闭环"
              bihuan_time = time_ii
            }else if(!exception_label_i_1.contains("0流水油站") && !exception_label_i_1.contains("流水异常") && exception_label_i_1.contains("客户量少") && consumer_cnt.toDouble >= 5){
              ret_task_status = "已闭环"
              bihuan_time = time_ii
            }else if(!exception_label_i_1.contains("0流水油站") && !exception_label_i_1.contains("客户量少") && exception_label_i_1.contains("流水异常") && exception_label_diff_min.toDouble <= 7){
              ret_task_status = "已闭环"
              bihuan_time = time_ii
            }else if(!exception_label_i_1.contains("0流水油站") && exception_label_i_1.contains("客户量少") && exception_label_i_1.contains("流水异常") && (exception_label_diff_min.toDouble <= 7 || consumer_cnt.toDouble >= 5)){
              ret_task_status = "已闭环"
              bihuan_time = time_ii
            }
          }
        }
      }

    }

    ret_task_status
  })

  // 更新 start_status 字段函数
  def getTaskStatusNew = udf((task_type:String,exception_label:String,time_all: String,start_time: String,task_status:String,flag: String) => {
    var ret = "是"

    if(task_type != null && task_type.trim != "" && exception_label != null && exception_label.trim != ""){
      val type_arr = task_type.split("\\|")
      val label_arr = exception_label.split("\\|")
      val time_arr = time_all.split("\\|")

      if(task_status.equals("已闭环")){
        for(i <- 0 until time_arr.length) {
          val time_i = time_arr(i)
          val type_i = type_arr(i)
          val label_i = label_arr(i)
          if(start_time.equals(time_i) && flag.equals("type")){
            ret = type_i
          }else if(start_time.equals(time_i) && flag.equals("label")){
            ret = label_i
          }

        }

      }
    }

    ret
  })

  // 获取 start_time 字段函数
  def getStartTime = udf((task_status:String,task_type_all:String,time: String,start_time:String) => {
    var ret_time = ""

    if(task_status != null && task_status.trim != "" && time != null && time.trim != ""){
      val task_status_arr = task_status.split("\\|")
      val time_arr = time.split("\\|")
      val task_type_arr = task_type_all.split("\\|")
      val start_time_arr = start_time.split("\\|")

      var bihuan_time = "19000101"
      val arr_tmp = new ArrayBuffer[String]()
      for(i <- 0 until time_arr.length) {
        val task_status_i = task_status_arr(i)
        val time_i = time_arr(i)
        val task_type_i = task_type_arr(i)

        if(i != 0){
          val task_status_i_1 = task_status_arr(i-1)
          val start_time_i_1 = start_time_arr(i-1)

          if(task_status_i_1.equals("已闭环")){
            bihuan_time = start_time_i_1
          }
        }

        if(task_type_i.contains("油站异常")){
          arr_tmp.append("油站异常")

          if(i == 0 || arr_tmp.size == 1){
            ret_time = time_i
          }else{

            var t1 = 0L
            var t2 = 0L
            try{
              t1 = new SimpleDateFormat("yyyyMMdd").parse(time_i).getTime
              t2 = new SimpleDateFormat("yyyyMMdd").parse(bihuan_time).getTime
            }catch {
              case e: Exception => println(">>>转换异常"+e)
            }
            val time_diff = ((t1 - t2) / (1000*60*60*24)).toInt

            if(!task_status_i.equals("已闭环") && time_diff > 7 && !bihuan_time.equals("19000101") ){
              bihuan_time = "19000101"
              ret_time = time_i
            }
          }
        }else if(!task_status_i.equals("已闭环")){
          ret_time = ""
        }

      }
    }

    ret_time
  })

  // 获取 close_time 字段函数
  def getCloseTime = udf((task_status:String,task_type_all:String,time: String) => {
    var ret_time = ""
    if(task_status != null && task_status.trim != "" && time != null && time.trim != ""){
      val task_status_arr = task_status.split("\\|")
      val time_arr = time.split("\\|")

      var bihuan_time = "19000101"
      for(i <- 0 until time_arr.length) {
        val task_status_i = task_status_arr(i)
        val time_i = time_arr(i)

        if(task_status_i.equals("已闭环") && i != 0){
          val task_status_i_1 = task_status_arr(i-1)
          val time_i_1 = time_arr(i-1)

          if(task_status_i_1.equals("已闭环") && task_status_i.equals("已闭环")){
            bihuan_time = time_i_1
            var t1 = 0L
            var t2 = 0L
            try{
              t1 = new SimpleDateFormat("yyyyMMdd").parse(time_i).getTime
              t2 = new SimpleDateFormat("yyyyMMdd").parse(bihuan_time).getTime
            }catch {
              case e: Exception => println(">>>转换异常"+e)
            }
            val time_diff = ((t1 - t2) / (1000*60*60*24)).toInt

            if(task_status_i.equals("已闭环") && time_diff > 7 && !bihuan_time.equals("19000101") ){
              bihuan_time = "19000101"
              ret_time = time_i
            }
          }else if(!task_status_i_1.equals("已闭环") && task_status_i.equals("已闭环")){
            ret_time = time_i
          }

        }else{
          ret_time = ""
        }

      }
    }

    ret_time
  })


  def main(args: Array[String]): Unit = {

    // inc_day 为业务时间，即跑数时间
    val inc_day = args(0)
//    // 衡度大数据平台SparkConf
//    val conf = getSparkConf_hd(className,null)
//    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    spark.sparkContext.setLogLevel("WARN")

    logger.error("++++++++  任务开始  ++++")
    run(spark, inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()

  }

}
