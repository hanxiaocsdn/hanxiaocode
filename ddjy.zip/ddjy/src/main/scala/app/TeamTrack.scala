package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ListBuffer

/**
 * @Description:车队轨迹
 * 需求方：左佳怡 01403789
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:535
 * 任务名称：车队轨迹挖掘表
 * 依赖任务：车辆燃油停留点外源表 435、车辆燃油加油站信息表 445、车辆燃油停留点 386
 * 数据源：dundun_match_oil_station2、dundun_stay_points_oil_station_info_week_tmp、dim_ddjy_vehicle_concat_yy_df、dundun_inner_outer_traj_info、eta_std_line_recall
 * 调用服务地址：
 * 数据结果：ddjy_carteam_guiji
 */
object TeamTrack {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def calculateDetail3(spark: SparkSession, incDay: String): DataFrame = {
    import spark.implicits._
    val detail3Sql=
      s"""
        |select
        |un,car_team_name,owner_id,source,tl_stay_points,jyz_coords,
        |poiid,a.pid,stationname,oilprovince,oilcity,district,hasOilName,querybrandid,
        |case when b.querybrandid = 0 then '其他'
        |	 when b.querybrandid = 1 then '中国石油'
        |	 when b.querybrandid = 2 then '中国石化'
        |	 when b.querybrandid = 3 then '中国海油'
        |	 when b.querybrandid = 4 then '中化集团'
        |	 when b.querybrandid = 5 then '延长壳牌'
        |	 when b.querybrandid = 6 then '道达尔'
        |	 when b.querybrandid = 7 then '埃索'
        |	 when b.querybrandid = 8 then '加德士'
        |	 when b.querybrandid = 9 then '美孚'
        |	 when b.querybrandid = 10 then '中石油BP'
        |	 when b.querybrandid = 11 then '中石化BP'
        |	 when b.querybrandid = 12 then '美德森'
        |	 when b.querybrandid = 13 then '壳牌'
        |	 else '未知品牌'
        |	 end as jyz_label
        |from
        |(
        |	select
        |	un,
        |	carrier_name as car_team_name,
        |	owner_id,
        |	source,
        |	tl_stay_points,
        |	jyz_coords,
        |	pid
        |	from dm_gis.dundun_match_oil_station2
        |	where inc_day = '$incDay' and if_jyz = '1'
        |) a
        |left join
        |(
        |	select
        |	poiid,
        |	pid,
        |	stationname,
        |	oilprovince,
        |	oilcity,
        |	district,
        |	hasOilName,
        |	querybrandid
        |	from dm_gis.dundun_stay_points_oil_station_info_week_tmp
        |	where inc_day = '$incDay'
        |	and lng is not null
        |) b
        |on a.pid = b.pid
        |--limit 20000
        |""".stripMargin
    val detail3Df: DataFrame = spark.sql(detail3Sql)
    logger.error("读取轨迹数据量："+detail3Df.count())
    val detail3Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, detail3Df,600).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //详情3.1
    val jyzBrandNumRdd: RDD[JSONObject] = detail3Rdd.map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val jyz_label: String = obj.getString("jyz_label")
      val source: String = obj.getString("source")
      ((owner_id, car_team_name, jyz_label, source), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val num_jyz: Int = list.map(_.getString("tl_stay_points")).size
      val tmpList: List[JSONObject] = list.map(json => {
        val jyz_label: String = json.getString("jyz_label")
        val brand: String = jyz_label + '(' + num_jyz + ')'
        json.put("num_jyz", num_jyz)
        json.put("brand", brand)
        json
      })
      tmpList.toIterator
    }).map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      ((owner_id, car_team_name, source), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getLongValue("num_jyz")).reverse
      val Jyz_brand_num: String = list.map(_.getString("brand")).distinct.mkString("|")
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("Jyz_brand_num", Jyz_brand_num)
        json
      })
      tmpList.toIterator
    }).distinct()
    val jyzBrandNumDf: DataFrame = jyzBrandNumRdd
    .map(obj=>{
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      val Jyz_brand_num: String = obj.getString("Jyz_brand_num")
      (owner_id,car_team_name,source,Jyz_brand_num)
    }).distinct().toDF("owner_id","car_team_name","source","Jyz_brand_num").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情3.1数据量："+jyzBrandNumDf.count())
    //详情3.2
    val numTopJyzRdd: RDD[((String, String, String, String), JSONObject)] = detail3Rdd.map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val jyz_label: String = obj.getString("jyz_label")
      val poiid: String = obj.getString("poiid")
      val stationname: String = obj.getString("stationname")
      val oilprovince: String = obj.getString("oilprovince")
      val oilcity: String = obj.getString("oilcity")
      val district: String = obj.getString("district")
      val jyz_coords: String = obj.getString("jyz_coords")
      val source: String = obj.getString("source")
      ((owner_id, car_team_name, jyz_label, poiid, stationname, oilprovince, oilcity, district, jyz_coords, source), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val num_top_jyz: Int = list.map(_.getString("tl_stay_points")).size
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("num_top_jyz", num_top_jyz)
        json
      })
      tmpList.toIterator
    }).map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val jyz_label: String = obj.getString("jyz_label")
      val source: String = obj.getString("source")
      ((owner_id, car_team_name, jyz_label, source), obj)
    })
    val jyzBrandNumMapRdd: RDD[((String, String, String, String), String)] = jyzBrandNumRdd.map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val jyz_label: String = obj.getString("jyz_label")
      val source: String = obj.getString("source")
      val num_jyz: String = obj.getString("num_jyz")
      ((owner_id, car_team_name, jyz_label, source), num_jyz)
    }).distinct()
    val top1JyzBrandDf: DataFrame = numTopJyzRdd.leftOuterJoin(jyzBrandNumMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val num_jyz: String = obj._2._2.orNull
      leftObj.put("num_jyz", num_jyz)
      val owner_id: String = leftObj.getString("owner_id")
      val car_team_name: String = leftObj.getString("car_team_name")
      val jyz_label: String = leftObj.getString("jyz_label")
      val source: String = leftObj.getString("source")
      ((owner_id, car_team_name, jyz_label, num_jyz, source), leftObj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getLongValue("num_top_jyz")).reverse
      val list_first: JSONObject = list.head
      val owner_id: String = list_first.getString("owner_id")
      val car_team_name: String = list_first.getString("car_team_name")
      val jyz_label: String = list_first.getString("jyz_label")
      val source: String = list_first.getString("source")
      ((owner_id, car_team_name, jyz_label, source), list_first)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getLongValue("num_jyz")).reverse
      val tmpList: List[JSONObject] = list.map(json => {
        val stationname: String = json.getString("stationname")
        val num_top_jyz: String = json.getString("num_top_jyz")
        val top_jyz_stationname = stationname + '(' + num_top_jyz + ')'
        json.put("top_jyz_stationname", top_jyz_stationname)
        json
      })
      tmpList.toIterator
    }).map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      ((owner_id, car_team_name, source), obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getLongValue("num_jyz")).reverse
      val tmpObj = new JSONObject()
      val Top1_jyz_brand_name_num: String = list.map(_.getString("top_jyz_stationname")).distinct.mkString("|")
      val Top1_jyz_brand_poiid: String = list.map(_.getString("poiid")).mkString("|")
      val Top1_jyz_brand_province: String = list.map(_.getString("oilprovince")).mkString("|")
      val Top1_jyz_brand_city: String = list.map(_.getString("oilcity")).mkString("|")
      val Top1_jyz_brand_district: String = list.map(_.getString("district")).mkString("|")
      val Top1_jyz_brand_coords: String = list.map(_.getString("jyz_coords")).mkString("|")
      tmpObj.put("owner_id", obj._1._1)
      tmpObj.put("car_team_name", obj._1._2)
      tmpObj.put("source", obj._1._3)
      tmpObj.put("Top1_jyz_brand_name_num", Top1_jyz_brand_name_num)
      tmpObj.put("Top1_jyz_brand_poiid", Top1_jyz_brand_poiid)
      tmpObj.put("Top1_jyz_brand_province", Top1_jyz_brand_province)
      tmpObj.put("Top1_jyz_brand_city", Top1_jyz_brand_city)
      tmpObj.put("Top1_jyz_brand_district", Top1_jyz_brand_district)
      tmpObj.put("Top1_jyz_brand_coords", Top1_jyz_brand_coords)
      tmpObj
    }).map(obj=>{
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      val Top1_jyz_brand_name_num: String = obj.getString("Top1_jyz_brand_name_num")
      val Top1_jyz_brand_poiid: String = obj.getString("Top1_jyz_brand_poiid")
      val Top1_jyz_brand_province: String = obj.getString("Top1_jyz_brand_province")
      val Top1_jyz_brand_city: String = obj.getString("Top1_jyz_brand_city")
      val Top1_jyz_brand_district: String = obj.getString("Top1_jyz_brand_district")
      val Top1_jyz_brand_coords: String = obj.getString("Top1_jyz_brand_coords")
      (owner_id,car_team_name,source,Top1_jyz_brand_name_num,Top1_jyz_brand_poiid,Top1_jyz_brand_province,Top1_jyz_brand_city,Top1_jyz_brand_district,Top1_jyz_brand_coords)
    }).distinct().toDF("owner_id","car_team_name","source","Top1_jyz_brand_name_num","Top1_jyz_brand_poiid","Top1_jyz_brand_province","Top1_jyz_brand_city","Top1_jyz_brand_district","Top1_jyz_brand_coords")
        .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情3.2数据量："+top1JyzBrandDf.count())
    //详情3.3
    val jyzOilTypesDf: DataFrame = detail3Rdd.map(obj => {
      val hasOilName: String = obj.getString("hasOilName")
      val hasOilNameArray: Array[Char] = hasOilName.toCharArray
      val type1 = new ListBuffer[String]()
      val type2 = new ListBuffer[String]()
      if (hasOilNameArray(0).toString.toInt == 1) {
        type1.append("0#")
        type2.append("柴油")
      }
      if (hasOilNameArray(1).toString.toInt == 1) {
        type1.append("-10#")
        type2.append("柴油")
      }
      if (hasOilNameArray(2).toString.toInt == 1) {
        type1.append("-20#")
        type2.append("柴油")
      }
      if (hasOilNameArray(3).toString.toInt == 1) {
        type1.append("-35#")
        type2.append("柴油")
      }
      if (hasOilNameArray(4).toString.toInt == 1) {
        type1.append("92#")
        type2.append("汽油")
      }
      if (hasOilNameArray(5).toString.toInt == 1) {
        type1.append("95#")
        type2.append("汽油")
      }
      if (hasOilNameArray(6).toString.toInt == 1) {
        type1.append("98#")
        type2.append("汽油")
      }
      if (hasOilNameArray(7).toString.toInt == 1) {
        type1.append("CNG")
        type2.append("加气")
      }
      if (hasOilNameArray(8).toString.toInt == 1) {
        type1.append("CNG")
        type2.append("加气")
      }
      if (hasOilNameArray(9).toString.toInt == 1) {
        type1.append("尿素")
        type2.append("环保")
      }
      if (hasOilNameArray(10).toString.toInt == 1) {
        type1.append("昆仑尿素")
        type2.append("环保")
      }
      if (hasOilNameArray(11).toString.toInt == 1) {
        type1.append("可兰素")
        type2.append("环保")
      }
      if (hasOilNameArray(12).toString.toInt == 1) {
        type1.append("润滑油")
        type2.append("环保")
      }
      if (hasOilNameArray(13).toString.toInt == 1) {
        type1.append("机油")
        type2.append("环保")
      }
      if (hasOilName == "00000000000000") {
        type1.append("gd无法爬取油品")
        type2.append("gd无法爬取油品")
      }
      val type1Str: String = type1.mkString("|")
      val type2Str: String = type2.mkString("|")
      obj.put("type1", type1Str)
      obj.put("type2", type2Str)
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      ((owner_id, car_team_name, type1Str, source), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val num_type1: Int = list.map(_.getString("tl_stay_points")).size
      val tmpList: List[JSONObject] = list.map(json => {
        val type1: String = json.getString("type1")
        val oil_types1_num = type1 + "(" + num_type1 + ")"
        json.put("oil_types1_num", oil_types1_num)
        json.put("num_type1", num_type1)
        json
      })
      tmpList.toIterator
    }).map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      ((owner_id, car_team_name), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getLongValue("num_type1")).reverse
      val Jyz_oil_types1_num: String = list.map(_.getString("oil_types1_num")).distinct.mkString("|")
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("Jyz_oil_types1_num", Jyz_oil_types1_num)
        json
      })
      tmpList.toIterator
    }).map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val type2: String = obj.getString("type2")
      val source: String = obj.getString("source")
      ((owner_id, car_team_name, type2, source), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val num_type2: Int = list.map(_.getString("tl_stay_points")).size
      val tmpList: List[JSONObject] = list.map(json => {
        val type2: String = json.getString("type2")
        val oil_types2_num = type2 + "(" + num_type2 + ")"
        json.put("oil_types2_num", oil_types2_num)
        json.put("num_type2", num_type2)
        json
      })
      tmpList.toIterator
    }).map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      ((owner_id, car_team_name), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getLongValue("num_type2")).reverse
      val Jyz_oil_types2_num: String = list.map(_.getString("oil_types2_num")).distinct.mkString("|")
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("Jyz_oil_types2_num", Jyz_oil_types2_num)
        json
      })
      tmpList.toIterator
    }).map(obj=>{
      val owner_id: String = obj.getString("owner_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      val Jyz_oil_types1_num: String = obj.getString("Jyz_oil_types1_num")
      val Jyz_oil_types2_num: String = obj.getString("Jyz_oil_types2_num")
      (owner_id,car_team_name,source,Jyz_oil_types1_num,Jyz_oil_types2_num)
    }).distinct().toDF("owner_id","car_team_name","source","Jyz_oil_types1_num","Jyz_oil_types2_num").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情3.3数据量："+jyzOilTypesDf.count())
    jyzBrandNumDf.createOrReplaceTempView("jyzBrandNumTmp")
    top1JyzBrandDf.createOrReplaceTempView("top1JyzBrandTmp")
    jyzOilTypesDf.createOrReplaceTempView("jyzOilTypesTmp")
    //关联yy详情1-3
    val yyGuijiSql=
      s"""
        |select
        |t1.owner_id,
        |t1.car_team_name,
        |'yy' as source,
        |num_carno,
        |Normal_guiji_or_task_num,
        |Jyz_brand_num,
        |Top1_jyz_brand_name_num,
        |Top1_jyz_brand_poiid,
        |Top1_jyz_brand_province,
        |Top1_jyz_brand_city,
        |Top1_jyz_brand_district,
        |Top1_jyz_brand_coords,
        |Jyz_oil_types1_num,
        |Jyz_oil_types2_num
        |from
        |(
        |	select
        |	owner_id,
        |	owner_name as car_team_name,
        |	count(distinct vehicle_no) as num_carno
        |	from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |	where inc_day = '${incDay}'
        |	and owner_id is not null
        |	group by owner_id,owner_name
        |) t1
        |left join
        |(
        |	Select
        |	owner_id as owner_id,
        |	carrier_name as car_team_name,
        |	count(d.un) as Normal_guiji_or_task_num
        |	from
        |	(
        |		select distinct un,
        |		owner_id,
        |		carrier_name
        |		from dm_gis.dundun_inner_outer_traj_info
        |		where inc_day = '${incDay}'
        |		and source = 'yy'
        |		and owner_id is not null
        |	) d
        |	group by owner_id,carrier_name
        |) t2
        |on t1.owner_id=t2.owner_id
        |left join
        |(
        |	select
        |	*
        |	from jyzBrandNumTmp
        |	where source='yy'
        |) t3
        |on t1.owner_id=t3.owner_id
        |left join
        |(
        |	select
        |	*
        |	from top1JyzBrandTmp
        |	where source='yy'
        |) t4
        |on t1.owner_id=t4.owner_id
        |left join
        |(
        |	select
        |	*
        |	from jyzOilTypesTmp
        |	where source='yy'
        |) t5
        |on t1.owner_id=t5.owner_id
        |""".stripMargin
    logger.error(yyGuijiSql)
    val yyGuijiDf: DataFrame = spark.sql(yyGuijiSql)
    val end_day = DateUtil.getDateStr(incDay, -1, "")
    val start_day = DateUtil.getDateStr(incDay, -7, "")
    //关联sf详情1-3
    val sfGuijiSql=
      s"""
        |select
        |'' as owner_id,
        |t1.car_team_name,
        |'sf' as source,
        |num_carno,
        |Normal_guiji_or_task_num,
        |Jyz_brand_num,
        |Top1_jyz_brand_name_num,
        |Top1_jyz_brand_poiid,
        |Top1_jyz_brand_province,
        |Top1_jyz_brand_city,
        |Top1_jyz_brand_district,
        |Top1_jyz_brand_coords,
        |Jyz_oil_types1_num,
        |Jyz_oil_types2_num
        |from
        |(
        |	select
        |	a.carrier_name as car_team_name,
        |	count(distinct a.vehicle_serial) as num_carno,
        |	count(a.task_subid) as Normal_guiji_or_task_num
        |	from
        |	(
        |		select
        |		task_subid,
        |		vehicle_serial,
        |		carrier_name,
        |		actual_depart_tm,
        |		actual_arrive_tm,
        |		replace(substr(actual_depart_tm,0,10),'-','') actual_depart_date,
        |		inc_day,
        |		row_number() over(partition by task_subid order by inc_day DESC) as rn
        |		from dm_gis.eta_std_line_recall
        |		where inc_day >= '${start_day}' and inc_day <= '${end_day}'
        |		and replace(substr(actual_depart_tm,0,10),'-','')>='${start_day}' and replace(substr(actual_depart_tm,0,10),'-','')<='${end_day}'
        |		and carrier_type='1'
        |	) a
        |	where a.rn = 1
        |	group by carrier_name
        |) t1
        |left join
        |(
        |	select
        |	*
        |	from jyzBrandNumTmp
        |	where source='sf'
        |) t2
        |on t1.car_team_name=t2.car_team_name
        |left join
        |(
        |	select
        |	*
        |	from top1JyzBrandTmp
        |	where source='sf'
        |) t3
        |on t1.car_team_name=t3.car_team_name
        |left join
        |(
        |	select
        |	*
        |	from jyzOilTypesTmp
        |	where source='sf'
        |) t4
        |on t1.car_team_name=t4.car_team_name
        |""".stripMargin
    logger.error(sfGuijiSql)
    val sfGuijiDf: DataFrame = spark.sql(sfGuijiSql)
    //拼接yy和sf数据
    val guijiDf: DataFrame = yyGuijiDf.union(sfGuijiDf).distinct().toDF()
    guijiDf.createOrReplaceTempView("guijiTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_carteam_guiji partition(inc_day='$end_day') select * from guijiTmp")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val last_one_day = DateUtil.getDateStr(incDay, -1, "")
    //获取详情3数据
    calculateDetail3(spark, incDay)
    //计算3.1-3.3逻辑
    //calculateTeamTag(spark,orderDf,incDay)

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>TeamTrack Execute Ok")
  }
}
