package app



import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.CommonTools.writeToHive
import java.text.SimpleDateFormat
import java.util.Date
/**
 *需求名称：顺象ocr识别结果统计：顺象推荐点击操作
 *需求方：谢泽洲(01422977)
 *研发： 周勇(01390943)
 *任务创建时间：20230530
 *任务id：衡度平台
 **/
object OcrConfigResult {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    import spark.implicits._
    //跑数日期
    val dayvar: String = args(0)
    //获取log数据
    val logsql=s"""
                  |select log  from dm_gis.ods_ddjy_kafka_di
                  |where inc_day='$dayvar' and log like '%CommonOcrServiceImpl%'
                  |""".stripMargin

    val log_data=spark.sql(logsql)
      .withColumn("message",get_json_object($"log","$.message"))
      .withColumn("message_str",split($"message","[|]"))
      .withColumn("mobile",$"message_str"(6))
      .withColumn("reqtime",$"message_str"(1))
      .withColumn("result_str",$"message_str"(9))
      .withColumn("result_str_tmp",regexp_replace($"result_str","返回结果:","|"))
      .withColumn("result_str_tmp2",split($"result_str_tmp","[|]"))
      .withColumn("result_org",when($"result_str".like("%返回结果%"),$"result_str_tmp2"(1)).otherwise($"result_str_tmp2"(0)))
      .drop("log","message","message_str","result_str_tmp","result_str_tmp2")
      .withColumn("code",when($"result_org".like("%code%"),get_json_object($"result_org","$.code"))
        .when($"result_org".like("%Internal Server Error%"),"500")
        .when($"result_org".like("%仪表盘ocr识别报错文件名%"),"502")
        .otherwise(""))
      .withColumn("config_result",when($"result_org".like("%results%"),get_json_object($"result_org","$.results"))
        .when($"result_org".like("%Internal Server Error%"),"Internal Server Error")
        .when($"result_org".like("%connect timed out%"),"connect timed out")
        .otherwise(""))
      .withColumn("is_sucees",when($"result_org".like("%results%") &&
        get_json_object($"result_org","$.results").like("%[%"),"是").otherwise("否"))
      .withColumn("pic_str_tmp",regexp_replace($"result_str","报错文件名:","|"))
      .withColumn("pic_str_tmp2",split($"pic_str_tmp","[|]"))
      .withColumn("error_pic",when($"result_str".like("%报错文件名:%"),$"pic_str_tmp2"(1)).otherwise(""))
      .drop("pic_str_tmp","pic_str_tmp2")
      .withColumn("inc_day",lit(dayvar))


    log_data.limit(10).show(false)

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.ddjy_ocr_config_result limit 0""").schema.map(_.name).map(col)
    //数据存dm表
    writeToHive(spark, log_data.coalesce(1) .select(table_cols: _*), Seq("inc_day"), "dm_gis.ddjy_ocr_config_result")

    spark.close()


  }


}
