package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkWrite}

/**
 * @Description:粤运车队电话号码加密
 * 需求人员：
 * @Author: lixiangzhi 01405644
 * @Date:2023-08-10
 * 任务id:891
 * 任务名称：粤运车队电话号码加密
 * 依赖任务：256
 * 数据源：ods_firm_yy_df
 * 调用服务地址：无
 * 数据结果：ods_firm_yy_encrypt_df
 */
object CarrierInfoEncrypt {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def encryptYyCarrier(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val yyCarrierSql=
      s"""
        |select * from dm_gis.ods_firm_yy_df where inc_day='$incDay'
        |""".stripMargin
    val yyCarrierRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, yyCarrierSql).map(obj=>{
      val contactor_phone: String = obj.getString("contactor_phone")
      obj.put("phone_part",contactor_phone)
      obj
    })
    val httpEncryptPhone = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "891", "粤运车队电话号码加密", "电话号码加密", "http://gis-apis.int.sfcloud.local:1080/tals/tals/normalized?ak=%s&tel=%s&cityCode=", "95630c95a49f4ceca389c9bfa0fedd17", yyCarrierRdd.count(), 50)

    val returnEncryptYyRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, yyCarrierRdd, SfNetInteface.encryptPhoneInterface, 50, "95630c95a49f4ceca389c9bfa0fedd17", 3000)
    val encryptYyRdd: RDD[JSONObject] = returnEncryptYyRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val tels: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(result, "tels")
      val telNormalized: String = tels.getString("telNormalized")
      obj.put("contactor_phone", telNormalized)
      obj.remove("api_result")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpEncryptPhone)

    val encryptYyDf: DataFrame = encryptYyRdd.map(obj => {
      (
        obj.getString("province_id"),
        obj.getString("province_name"),
        obj.getString("city_id"),
        obj.getString("city_name"),
        obj.getString("area_id"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("status"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("access_date"),
        obj.getString("owner_type"),
        obj.getString("alarm_level")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,encryptYyDf,"inc_day",incDay,"dm_gis.ods_firm_yy_encrypt_df",1)
  }

  def encryptYzCarrier(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val yzCarrierSql=
      s"""
         |select * from dm_gis.dim_ddjy_yz_carrier_concat_di
         |""".stripMargin
    val yzCarrierRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, yzCarrierSql).map(obj=>{
      val contactor_phone: String = obj.getString("contactor_phone")
      obj.put("phone_part",contactor_phone)
      obj
    })
    val returnEncryptYzRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, yzCarrierRdd, SfNetInteface.encryptPhoneInterface, 50, "95630c95a49f4ceca389c9bfa0fedd17", 3000)
    val encryptYzRdd: RDD[JSONObject] = returnEncryptYzRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val tels: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(result, "tels")
      val telNormalized: String = tels.getString("telNormalized")
      obj.put("contactor_phone", telNormalized)
      obj.remove("api_result")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val encryptYzDf: DataFrame = encryptYzRdd.map(obj => {
      EncryptYz(
        obj.getString("city_code"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("district_code"),
        obj.getString("carrier_name"),
        obj.getString("business_scope"),
        obj.getString("business_license"),
        obj.getString("business_license_code"),
        obj.getString("business_certificate_date"),
        obj.getString("business_certificate_validity_date"),
        obj.getString("business_copy_date"),
        obj.getString("business_copy_validity_date"),
        obj.getString("business_license_authority"),
        obj.getString("org_type"),
        obj.getString("carrier_type"),
        obj.getString("qualification_level"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("carrier_status"),
        obj.getString("carrier_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("credit_code"),
        obj.getString("sys_timestamp"),
        obj.getString("address"),
        obj.getString("is_match"),
        obj.getString("carrier_number")
      )
    }).toDF()
    SparkWrite.writeToHiveNoPart(spark,encryptYzDf,"dm_gis.dim_ddjy_yz_carrier_concat_encrypt_di",1)
  }
  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //加密粤运车队信息表
    encryptYyCarrier(spark,incDay)
    //加密运政车队信息表
    //encryptYzCarrier(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class EncryptYz(
                        city_code:String,
                        city:String,
                        district:String,
                        district_code:String,
                        carrier_name:String,
                        business_scope:String,
                        business_license:String,
                        business_license_code:String,
                        business_certificate_date:String,
                        business_certificate_validity_date:String,
                        business_copy_date:String,
                        business_copy_validity_date:String,
                        business_license_authority:String,
                        org_type:String,
                        carrier_type:String,
                        qualification_level:String,
                        contactor:String,
                        contactor_phone:String,
                        carrier_status:String,
                        carrier_code:String,
                        manager:String,
                        manager_phone:String,
                        credit_code:String,
                        sys_timestamp:String,
                        address:String,
                        is_match:String,
                        carrier_number:String
                      )
}
