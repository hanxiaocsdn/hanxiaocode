package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkWrite

/**
 * @Description:油站统计报表
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:977
 * 任务名称：油站基础统计表
 * 依赖任务：无
 * 数据源：
 * 调用服务地址：无
 * 数据结果：ddjy_dwd_station_statistic_di
 */

object CollectionStationStatistic {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String, last_seven_day:String, last_fourteen_day:String, fri_day:String) = {
    import spark.implicits._
    //读取ddjy_ods_corp_info_df
    val corpInfoSql=
      """
        |select id as corp_id,name
        |from dm_gis.ddjy_ods_corp_info_df
        |where inc_day in(select max(inc_day) from dm_gis.ddjy_ods_corp_info_df)
        |and corp_type='2' and del_flag='0'
        |group by id,name
        |""".stripMargin
    val corpInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, corpInfoSql).map(obj => {
      (obj.getString("corp_id"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("corp_info表数据量:"+corpInfoRdd.count())
    //读取ddjy_uimp_dm_petrol_price_discount
    val priceDiscountSql=
      s"""
        |select
        |grpid,station_type,ft_sale_price,country_price,price_sales_type,effective_time,gradient,breaks,
        |sprice_sales_detail,sale_price
        |from
        |(
        |	select
        |	grpid,station_type,ft_sale_price,country_price,price_sales_type,effective_time,gradient,breaks,sale_price,
        |	concat_ws('；',collect_set(sprice_sales_detail) over(partition by grpid,station_type)) as sprice_sales_detail,
        |	row_number() over(partition by grpid,station_type order by update_date desc) as rnk
        |	from
        |	(
        |		select
        |		grpid,station_type,ft_sale_price,country_price,price_sales_type,effective_time,gradient,
        |		round(country_price-ft_sale_price,2) as breaks,
        |		case when price_sales_type='0' then round(country_price-ft_sale_price,2)
        |			 when price_sales_type='1' then concat(effective_time,':',round(country_price-ft_sale_price,2))
        |			 when price_sales_type='2' then concat(gradient,':',round(country_price-ft_sale_price,2))
        |			 when price_sales_type='11' then concat(effective_time,',',gradient,':',round(country_price-ft_sale_price,2))
        |			 end as sprice_sales_detail,
        |		sale_price,update_date
        |		from dm_gis.ddjy_uimp_dm_petrol_price_discount
        |		where inc_day = '$inc_day'
        |		and ft_sale_price is not null
        |		and petrol_type='0#柴油'
        |	) t1
        |) t2
        |where rnk=1
        |""".stripMargin
    val priceDiscountRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, priceDiscountSql).map(obj=>{
      var grpid: String = obj.getString("grpid")
      ((grpid,obj.getString("station_type")),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("petrol_price_discount表数据量:"+priceDiscountRdd.count())
    //读取ddjy_dim_station_info_on_shelf_time_df
    val onShelfTimeSql=
      s"""
         |select new_grpid as grpid,station_type,
         |min(on_shelf_time) as min_on_shelf_time,
         |max(on_shelf_time) as max_on_shelf_time
         |from dm_gis.ddjy_dim_station_info_on_shelf_time_df
         |where inc_day<='${inc_day}'
         |and on_shelf_time is not null
         |and on_shelf_time !=''
         |group by new_grpid,station_type
         |""".stripMargin
    val onShelfTimeRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, onShelfTimeSql).map(obj=>{
      var grpid: String = obj.getString("grpid")
      ((grpid,obj.getString("station_type")),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("on_shelf_time表数据量:"+onShelfTimeRdd.count())
    //计算当日流水
    val payRepartitionSql=
      s"""
         |select station_id,
         |sum(ft_sale_money) as day_ft_sale_money,
         |sum(oil_mass) as day_oil_mass
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day = '$inc_day'
         |group by station_id
         |""".stripMargin
    val payRepartitionRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, payRepartitionSql).map(obj=>{
      (obj.getString("station_id"),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("order_pay_repartition表数据量:"+payRepartitionRdd.count())
    //计算月累计流水
    val monthPayRepartitionSql=
      s"""
         |select station_id,
         |sum(ft_sale_money) as month_ft_sale_money,
         |sum(oil_mass) as month_oil_mass
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day <= '$inc_day' and substr(inc_day,0,6)=substr('$inc_day',0,6)
         |group by station_id
         |""".stripMargin
    val monthPayRepartitionRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, monthPayRepartitionSql).map(obj=>{
      (obj.getString("station_id"),obj)
    })
    //计算累计流水和首单时间
    val aggPayRepartitionSql=
      s"""
         |select station_id,
         |min(pay_time) as min_pay_time,
         |sum(ft_sale_money) as agg_ft_sale_money,
         |sum(oil_mass) as agg_oil_mass
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day <= '$inc_day'
         |group by station_id
         |""".stripMargin
    val aggPayRepartitionRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, aggPayRepartitionSql).map(obj=>{
      (obj.getString("station_id"),obj)
    })
    //读取 ddjy_ods_main_corp_info_df
    val mainCorpInfoSql=
      """
        |select id,corp_name as main_corp_name from dm_gis.ddjy_ods_main_corp_info_df
        |""".stripMargin
    val mainCorpInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, mainCorpInfoSql).map(obj=>{
      (obj.getString("id"),obj)
    })
    //修正部分油站的grpid
    val stationIdMap: Map[String, String] = Map(
      ("1573622599893053441", "7120659f-4c5c-4c28-9f3e-4ca2cfad3e6a"),
      ("1573625595792125953", "244f0f45-ef67-41c3-b467-e28ca72df14e"),
      ("1638010925280137218", "bff8a315-47b1-43d2-8b51-ee6400a33b90"),
      ("1657259528687194113", "91f5e9dd-ac95-4350-b218-482a44c28945"),
      ("1657262366595223553", "8cd0f93a-0eaa-4640-be7c-16940f7efede"),
      ("1657263776724422658", "7f96384b-712c-4c98-9997-991899123d8d"),
      ("1657266236847296513", "c658a2b7-8449-4a3a-af93-9455f4a2aeb8"),
      ("1657267206893342722", "f8cafde4-93f5-41da-bdb9-b1ce3d41499f"),
      ("1657268922191712257", "22477691-9781-4f83-a77e-3bfb635cbcca"),
      ("1657269813359677442", "4c2827a5-c3b3-4ba9-8bc8-84afb15bce8c"),
      ("1661328088170500097", "a5ab645c-2c18-44a4-a599-523c9cb2444e"),
      ("1657268067220590594", "b3147c09-8799-45bf-89af-88f278cfbdf2")
    )
    val stationIdBc: Broadcast[Map[String, String]] = spark.sparkContext.broadcast(stationIdMap)

    //读取ddjy_dim_station_info_filter
    val stationInfoSql=
      s"""
        |select src_grpid as grpid,petrol_station_name,station_type,corp_id,enable_flag,brand as brand_type,province_name,city_name,area_name,main_corp_info_id,
        |sales_name as station_sale,
        |concat(maintain_begin_time,'-',maintain_end_time) as maintain_time,
        |id
        |from dm_gis.ddjy_dim_station_info_filter
        |where inc_day ='$inc_day'
        |""".stripMargin
    val value: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, stationInfoSql).map(obj => {
      (obj.getString("corp_id"), obj)
    }).leftOuterJoin(corpInfoRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).map(obj => {
      var grpid: String = obj.getString("grpid")
      val station_type: String = JSONUtil.getJsonValSingle(obj, "station_type")
      var tag = Int.MaxValue
      var platform_name = ""
      station_type match {
        case "4" => {
          tag = 0
          platform_name = "顺象"
        }
        case "2" => {
          tag = 1
          platform_name = "团油"
        }
        case "3" => {
          tag = 2
          platform_name = "丰汇盟"
        }
        case "6" => {
          tag = 3
          platform_name = "车福通"
        }
        case "7" => {
          tag = 4
          platform_name = "优联可"
        }
        case "1" => {
          platform_name = "吨吨"
        }
        case "5" => {
          platform_name = "讯宏"
        }
        case _ => {
          platform_name = ""
        }
      }
      val stationIdValue: Map[String, String] = stationIdBc.value
      val id: String = obj.getString("id")
      val grpidReplace = stationIdValue.getOrElse(id, "")
      if(grpidReplace!=""){
        grpid = grpidReplace
      }
      obj.put("grpid", grpid)
      obj.put("tag", tag)
      obj.put("platform_name", platform_name)
      ((obj.getString("grpid"), obj.getString("station_type")), obj)
    }).leftOuterJoin(priceDiscountRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      ((leftObj.getString("grpid"), leftObj.getString("station_type")), leftObj)
    }).leftOuterJoin(onShelfTimeRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).map(obj => {
      val name: String = obj.getString("name")
      val enable_flag: String = obj.getString("enable_flag")
      var shelf_status = "未上架"
      if (enable_flag == "1") {
        shelf_status = "已上架"
      }
      obj.put("corp_name", name)
      obj.put("shelf_status", shelf_status)
      (obj.getString("id"), obj)
    }).leftOuterJoin(payRepartitionRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("day_ft_sale_money", rightObj.getString("day_ft_sale_money"))
        leftObj.put("day_oil_mass", rightObj.getString("day_oil_mass"))
      }
      leftObj.put("inc_day", inc_day)
      (leftObj.getString("main_corp_info_id"), leftObj)
    }).leftOuterJoin(mainCorpInfoRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("station_subject", rightObj.getString("main_corp_name"))
      }
      (leftObj.getString("id"), leftObj)
    }).leftOuterJoin(monthPayRepartitionRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("month_ft_sale_money", rightObj.getString("month_ft_sale_money"))
        leftObj.put("month_oil_mass", rightObj.getString("month_oil_mass"))
      }
      (leftObj.getString("id"), leftObj)
    }).leftOuterJoin(aggPayRepartitionRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("min_pay_time", rightObj.getString("min_pay_time"))
        leftObj.put("agg_ft_sale_money", rightObj.getString("agg_ft_sale_money"))
        leftObj.put("agg_oil_mass", rightObj.getString("agg_oil_mass"))
      }
      ((leftObj.getString("grpid"), leftObj.getString("station_type")), leftObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //logger.error("打印日志========")
    //value.take(10).foreach(println(_))
    //value.filter(_._2.getString("petrol_station_name")=="广州美孚小丰加油站").take(10).foreach(println(_))
    //value.filter(_._2.getString("petrol_station_name")=="【中石油】东莞大朗加油站").take(10).foreach(println(_))
    val stationStatisticRdd: RDD[JSONObject] = value.groupByKey().map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.minBy(json=>{
        val min_pay_time: String = JSONUtil.getJsonValSingle(json, "shelf_status")
        min_pay_time
      })
      val day_ft_sale_money: Double = obj._2.toList.map(json => {
        val day_ft_sale_money: Double = JSONUtil.getJsonDouble(json, "day_ft_sale_money", 0.0)
        day_ft_sale_money
      }).sum
      val day_oil_mass: Double = obj._2.toList.map(json => {
        val day_oil_mass: Double = JSONUtil.getJsonDouble(json, "day_oil_mass", 0.0)
        day_oil_mass
      }).sum
      val month_ft_sale_money: Double = obj._2.toList.map(json => {
        val month_ft_sale_money: Double = JSONUtil.getJsonDouble(json, "month_ft_sale_money", 0.0)
        month_ft_sale_money
      }).sum
      val month_oil_mass: Double = obj._2.toList.map(json => {
        val month_oil_mass: Double = JSONUtil.getJsonDouble(json, "month_oil_mass", 0.0)
        month_oil_mass
      }).sum
      val agg_ft_sale_money: Double = obj._2.toList.map(json => {
        val agg_ft_sale_money: Double = JSONUtil.getJsonDouble(json, "agg_ft_sale_money", 0.0)
        agg_ft_sale_money
      }).sum
      val agg_oil_mass: Double = obj._2.toList.map(json => {
        val agg_oil_mass: Double = JSONUtil.getJsonDouble(json, "agg_oil_mass", 0.0)
        agg_oil_mass
      }).sum
      val noNullMinPayTime: List[JSONObject] = obj._2.toList.filter(json => {
        StringUtils.isNoneEmpty(json.getString("min_pay_time"))
      })
      var min_pay_time: String = ""
      if (noNullMinPayTime.nonEmpty){
        min_pay_time = noNullMinPayTime.minBy(json => {
          val min_pay_time: String = JSONUtil.getJsonValSingle(json, "min_pay_time")
          min_pay_time
        }).getString("min_pay_time")
      }

      tmpObj.put("day_ft_sale_money",day_ft_sale_money)
      tmpObj.put("day_oil_mass",day_oil_mass)
      tmpObj.put("month_ft_sale_money",month_ft_sale_money)
      tmpObj.put("month_oil_mass",month_oil_mass)
      tmpObj.put("agg_ft_sale_money",agg_ft_sale_money)
      tmpObj.put("agg_oil_mass",agg_oil_mass)
      tmpObj.put("min_pay_time",min_pay_time)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("未合并station_type为1和4的数据量:"+stationStatisticRdd.count())
    //stationStatisticRdd.filter(_.getString("petrol_station_name")=="广州美孚小丰加油站").take(10).foreach(println(_))
    //stationStatisticRdd.filter(_.getString("petrol_station_name")=="【中石油】东莞大朗加油站").take(10).foreach(println(_))
    val stationStatistic4Rdd: RDD[JSONObject] = stationStatisticRdd.filter(obj => {
      val station_type: String = obj.getString("station_type")
      station_type == "1" || station_type == "4"
    }).groupBy(_.getString("grpid")).map(obj => {
      //val tmpObj: JSONObject = obj._2.toList.maxBy(_.getString("station_type"))
      val tmpObj: JSONObject = obj._2.toList.sortBy(x => (
        x.getString("station_type"), x.getString("shelf_status")
      ))(Ordering Tuple2(Ordering.String.reverse, Ordering.String)).head
      val day_ft_sale_money: Double = obj._2.toList.map(json => {
        val day_ft_sale_money: Double = JSONUtil.getJsonDouble(json, "day_ft_sale_money", 0.0)
        day_ft_sale_money
      }).sum
      val day_oil_mass: Double = obj._2.toList.map(json => {
        val day_oil_mass: Double = JSONUtil.getJsonDouble(json, "day_oil_mass", 0.0)
        day_oil_mass
      }).sum
      val month_ft_sale_money: Double = obj._2.toList.map(json => {
        val month_ft_sale_money: Double = JSONUtil.getJsonDouble(json, "month_ft_sale_money", 0.0)
        month_ft_sale_money
      }).sum
      val month_oil_mass: Double = obj._2.toList.map(json => {
        val month_oil_mass: Double = JSONUtil.getJsonDouble(json, "month_oil_mass", 0.0)
        month_oil_mass
      }).sum
      val agg_ft_sale_money: Double = obj._2.toList.map(json => {
        val agg_ft_sale_money: Double = JSONUtil.getJsonDouble(json, "agg_ft_sale_money", 0.0)
        agg_ft_sale_money
      }).sum
      val agg_oil_mass: Double = obj._2.toList.map(json => {
        val agg_oil_mass: Double = JSONUtil.getJsonDouble(json, "agg_oil_mass", 0.0)
        agg_oil_mass
      }).sum
      val noNullMinPayTime: List[JSONObject] = obj._2.toList.filter(json => {
        StringUtils.isNoneEmpty(json.getString("min_pay_time"))
      })
      var min_pay_time: String = ""
      if (noNullMinPayTime.nonEmpty){
        min_pay_time = noNullMinPayTime.minBy(json => {
          val min_pay_time: String = JSONUtil.getJsonValSingle(json, "min_pay_time")
          min_pay_time
        }).getString("min_pay_time")
      }
      val noNullShelfTime: List[JSONObject] = obj._2.toList.filter(json => {
        val min_on_shelf_time: String = JSONUtil.getJsonValSingle(json, "min_on_shelf_time")
        StringUtils.isNoneEmpty(min_on_shelf_time)
      })
      var min_on_shelf_time: String = ""
      if (noNullShelfTime.nonEmpty){
        min_on_shelf_time = noNullShelfTime.minBy(json => {
          val min_on_shelf_time: String = JSONUtil.getJsonValSingle(json, "min_on_shelf_time")
          min_on_shelf_time
        }).getString("min_on_shelf_time")
      }
      tmpObj.put("day_ft_sale_money", day_ft_sale_money)
      tmpObj.put("day_oil_mass", day_oil_mass)
      tmpObj.put("month_ft_sale_money", month_ft_sale_money)
      tmpObj.put("month_oil_mass", month_oil_mass)
      tmpObj.put("agg_ft_sale_money", agg_ft_sale_money)
      tmpObj.put("agg_oil_mass", agg_oil_mass)
      tmpObj.put("min_pay_time", min_pay_time)
      tmpObj.put("min_on_shelf_time", min_on_shelf_time)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //stationStatistic4Rdd.filter(_.getString("petrol_station_name")=="广州美孚小丰加油站").take(10).foreach(println(_))
    val stationStatisticNo4Rdd: RDD[JSONObject] = stationStatisticRdd.filter(obj => {
      val station_type: String = obj.getString("station_type")
      station_type != "1" && station_type != "4"
    })
    val resultDf: DataFrame = stationStatisticNo4Rdd.union(stationStatistic4Rdd).map(obj=>{
      var min_on_shelf_time: String = JSONUtil.getJsonValSingle(obj, "min_on_shelf_time")
      var max_on_shelf_time: String = JSONUtil.getJsonValSingle(obj, "max_on_shelf_time")
      var min_pay_time: String = JSONUtil.getJsonValSingle(obj, "min_pay_time")
      if((min_on_shelf_time>min_pay_time && StringUtils.isNoneEmpty(min_pay_time)) || (StringUtils.isEmpty(min_on_shelf_time) && StringUtils.isNoneEmpty(min_pay_time))){
        min_on_shelf_time = min_pay_time
      }
      if(StringUtils.isEmpty(max_on_shelf_time) && StringUtils.isNoneEmpty(min_pay_time)){
        max_on_shelf_time = min_pay_time
      }
      obj.put("min_on_shelf_time",min_on_shelf_time)
      obj.put("max_on_shelf_time",max_on_shelf_time)
      obj
    }).map(obj => {
      stationStatistic(
        obj.getString("grpid"),
        obj.getString("petrol_station_name"),
        obj.getString("corp_name"),
        obj.getString("brand_type"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("ft_sale_price"),
        obj.getString("breaks"),
        obj.getString("min_on_shelf_time"),
        obj.getString("max_on_shelf_time"),
        obj.getString("shelf_status"),
        obj.getString("min_pay_time"),
        obj.getString("agg_ft_sale_money"),
        obj.getString("day_ft_sale_money"),
        obj.getString("station_subject"),
        obj.getString("station_sale"),
        obj.getString("month_ft_sale_money"),
        obj.getString("maintain_time"),
        obj.getString("station_type"),
        obj.getString("price_sales_type"),
        obj.getString("sprice_sales_detail"),
        obj.getString("day_oil_mass"),
        obj.getString("month_oil_mass"),
        obj.getString("agg_oil_mass"),
        obj.getString("country_price"),
        obj.getString("sale_price")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站统计结果表数据量:"+resultDf.count())
    corpInfoRdd.unpersist()
    priceDiscountRdd.unpersist()
    onShelfTimeRdd.unpersist()
    payRepartitionRdd.unpersist()
    stationStatisticRdd.unpersist()
    stationStatistic4Rdd.unpersist()
    SparkWrite.writeToHive(spark,resultDf,"inc_day",inc_day,"dm_gis.ddjy_dwd_station_statistic_di")
    logger.error("写入ddjy_dwd_station_statistic_di每日成功，日期为："+inc_day)
    resultDf.unpersist()
  }

  def minStationOrderFilterPaytime(spark: SparkSession, inc_day: String,init_day:String) = {
    val stationOrderFilterSql=
      s"""
        |select substr(min(pay_time),0,10)as inc_day
        |from dm_gis.ddjy_dwd_station_order_filter
        |where inc_day='${inc_day}'
        |and pay_time is not null
        |and pay_time!=''
        |""".stripMargin
    var start_day: String = SparkUtils.getRowToJson(spark,stationOrderFilterSql).map(obj=>{
      val inc_day: String = obj.getString("inc_day").replace("-", "")
      inc_day
    }).collect().head
    if (init_day!=""){
      start_day=init_day
    }
    val dates: Int = DateUtil.daysDiff(start_day, inc_day).toInt
    logger.error("当天支付时间最早的时间:"+start_day)
    logger.error(start_day+"和"+inc_day+"时间间隔是:"+dates+"天")
    dates
  }

  def execute(inc_day:String,init_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取ddjy_dwd_station_order_filter，计算是否有补录订单，以及补录订单最早时间
    var dates = minStationOrderFilterPaytime(spark, inc_day,init_day)
    if (init_day == "" && dates>60){
      dates=60
    }
    for (i <- (0 to dates).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      val sdf = new SimpleDateFormat("yyyyMMdd")
      val actionTime = sdf.parse(incDay)
      val cal_5 = Calendar.getInstance
      cal_5.setTime(actionTime)
      cal_5.add(Calendar.WEEK_OF_MONTH, -1)
      cal_5.set(Calendar.DAY_OF_WEEK, 6)
      val fri_day = sdf.format(cal_5.getTime)
      stationProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day,fri_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val init_day: String = args(1)
    execute(inc_day,init_day)
    logger.error("======>>>>>>油站统计表 Execute Ok")
  }
  case class stationStatistic(
                              grpid:String,
                              petrol_station_name:String,
                              corp_name:String,
                              brand_type:String,
                              province_name:String,
                              city_name:String,
                              area_name:String,
                              platform_ft_sale_price:String,
                              platform_breaks:String,
                              min_on_shelf_time:String,
                              max_on_shelf_time:String,
                              shelf_status:String,
                              min_pay_time:String,
                              agg_ft_sale_money:String,
                              day_ft_sale_money:String,
                              station_subject:String,
                              station_sale:String,
                              month_ft_sale_money:String,
                              maintain_time:String,
                              station_type:String,
                              price_sales_type:String,
                              sprice_sales_detail:String,
                              day_oil_mass:String,
                              month_oil_mass:String,
                              agg_oil_mass:String,
                              country_price:String,
                              sale_price:String
                   )

}
