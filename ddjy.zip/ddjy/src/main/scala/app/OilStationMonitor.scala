package app
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
/**
 *需求名称：油站监控报表
 *需求方：陶慧(01424177)
 *研发： 周勇(01390943)
 *任务创建时间：20230221
 *任务id：衡度平台562
 **/

object OilStationMonitor {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args:Array[String]): Unit ={
    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._
    val inc_day: String = args(0)

    //获取数据
    val station_data=spark.sql(
      s"""
         |select * from dm_gis.ddjy_dwd_station_quota_dtl
         |where inc_day='$inc_day' and is_off='否'
         |""".stripMargin)
      .withColumn("sum_gmv",when($"sum_gmv".isNull || trim($"sum_gmv") ==="" || trim($"sum_gmv")==="null",0.0).otherwise($"sum_gmv".cast("double")))
      .withColumn("avg_daily_gmv",when($"avg_daily_gmv".isNull || trim($"avg_daily_gmv") ==="" || trim($"avg_daily_gmv")==="null",0.0).otherwise($"avg_daily_gmv".cast("double")))
      .withColumn("close_cycle_tmp",when($"close_cycle".isNull || trim($"close_cycle") ==="" || trim($"close_cycle")==="null",0).otherwise($"close_cycle"))
      .withColumn("close_cycle",when($"close_cycle".isNull || trim($"close_cycle") ==="" || trim($"close_cycle")==="null",null).otherwise($"close_cycle"))

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.ddjy_oil_station_monitor_df limit 0""").schema.map(_.name).map(col)

    //数据汇总
    val data_result=station_data.groupBy("user_name","sub_name","sup_name")
      .agg(
        //油站数量
        countDistinct( $"id") as "station_cnt",
        //消费油站数量
        countDistinct( when($"sum_gmv">0,$"id").otherwise(null)) as "consumed_station_cnt",
        //油站GMV
        round(sum($"sum_gmv"),6) as "sum_station_gmv",
        //油站日均GMV
        round(avg($"avg_daily_gmv"),6) as "avg_station_daily_gmv",
        //油站异常数量
        countDistinct( when($"exception_label".isNotNull && trim($"exception_label") =!="",$"id").otherwise(null)) as "exception_station_cnt",
        //0流水油站数量
        countDistinct( when($"exception_label".contains("0流水油站") ,$"id").otherwise(null)) as "no_gmv_cnt",
        //流水异常数量
        countDistinct( when($"exception_label".contains("流水异常"),$"id").otherwise(null)) as "abnormal_gmv_cnt",
        //优惠少数量
        countDistinct( when($"exception_label".contains("优惠少"),$"id").otherwise(null)) as "less_break_cnt",
        //转化周期长数量
        countDistinct( when($"exception_label".contains("转化周期长"),$"id").otherwise(null)) as "long_conversion_cnt",
        //客户量少数量
        countDistinct( when($"exception_label".contains("客户量少"),$"id").otherwise(null)) as "few_consumer_cnt",
        //已闭环数量
        countDistinct( when($"task_status"==="已闭环",$"id").otherwise(null)) as "closed_cnt",
        //已作业数量
        countDistinct( when($"task_status"==="已作业",$"id").otherwise(null)) as "processed_cnt",
        //未作业数量
        countDistinct( when($"task_status"==="未作业",$"id").otherwise(null)) as "unprocessed_cnt",
        //平均闭环周期
        round(avg(when($"task_status"==="已闭环",$"close_cycle").otherwise(null)),6) as "avg_closed_cycle",
        //总闭环周期: sum(close_cycle)  where  task_status=’已闭环’ group by user_name
        round(sum(when($"task_status"==="已闭环",$"close_cycle_tmp").otherwise(0)),6) as "sum_closed_cycle"
      )
      .withColumn("avg_closed_cycle",when($"avg_closed_cycle".isNull || trim($"avg_closed_cycle") ==="" || trim($"avg_closed_cycle")==="null","").otherwise($"avg_closed_cycle"))
      //油站消费率=消费油站数量/油站数量
      .withColumn("station_consumed_percent",round($"consumed_station_cnt"/$"station_cnt",6))
      //油站异常率
      .withColumn("station_exception_percent",round($"exception_station_cnt"/$"station_cnt",6))
      //销售id
      .withColumn("user_id",lit(""))
      //二级组别id
      .withColumn("sub_code",lit(""))
      //一级组别id
      .withColumn("sup_code",lit(""))
      .withColumn("statistical_day",lit(inc_day.substring(0,4).concat("-").concat(inc_day.substring(4,6)).concat("-").concat(inc_day.substring(6,8))))
      //分区日期
      .withColumn("inc_day",lit(inc_day))

      .select(table_cols: _*)

    //数据存dm表
    writeToHive(spark, data_result, Seq("inc_day"), "dm_gis.ddjy_oil_station_monitor_df")

    spark.close()
  }

  //定义函数存入数据
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

}