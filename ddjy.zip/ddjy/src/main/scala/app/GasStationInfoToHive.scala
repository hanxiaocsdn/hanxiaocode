package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SparkWrite, TrackUrlUtil}

/**
 * @Description:调油站信息接口落hive表
 * 需求方：娇悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:522
 * 任务名称：油站全量信息表
 * 依赖任务：无
 * 数据源：
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0
 * 数据结果：dm_ddjy_gas_station_info_di
 */
object GasStationInfoToHive {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def stationInterface(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    var num:Long = 50000
    var flag=0
    var dataVersion: Int = 0
    var updateTimeStamp: String =""
    var finalUrl: String =""
    var finalStationInfoRdd: RDD[JSONObject] = spark.sparkContext.emptyRDD
    while (num==50000){
      if (flag==0){
        val stationUrlStart="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0&limitCount=50000&dataVersion=0&switchCode=BESTEXPRESSSF"
        logger.error("初始化接口url:"+stationUrlStart)
        val startObj: JSONObject = TrackUrlUtil.httpGetJSON(stationUrlStart,3)
        dataVersion = startObj.getIntValue("dataVersion")
        val data = startObj.getJSONArray("data").toArray()
        val stationInfoRdd = spark.sparkContext.parallelize(data).map(obj=>{
          val tmpObj: JSONObject = obj.asInstanceOf[JSONObject]
          tmpObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("第一次查询油站数据量:"+stationInfoRdd.count())
        updateTimeStamp = stationInfoRdd.map(obj => {
          val updateTimeStamp: String = obj.getString("updateTimeStamp")
          updateTimeStamp
        }).max()
        finalStationInfoRdd=stationInfoRdd
        num = stationInfoRdd.count()
        stationInfoRdd.unpersist()
        flag=1
        Thread.sleep(5000)
      }else{
        val stationUrl="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=%s&limitCount=50000&dataVersion=%d&switchCode=BESTEXPRESSSF"
        finalUrl = stationUrl.format(updateTimeStamp,dataVersion)
        logger.error("接口url:"+finalUrl)
        val retObj: JSONObject = TrackUrlUtil.httpGetJSON(finalUrl,3)
        val data = retObj.getJSONArray("data").toArray()
        val stationInfoRdd = spark.sparkContext.parallelize(data).map(obj=>{
          val tmpObj: JSONObject = obj.asInstanceOf[JSONObject]
          tmpObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("查询油站数据量:"+stationInfoRdd.count())
        updateTimeStamp = stationInfoRdd.map(obj => {
          val updateTimeStamp: String = obj.getString("updateTimeStamp")
          updateTimeStamp
        }).max()
        finalStationInfoRdd=stationInfoRdd.union(finalStationInfoRdd)
        num = stationInfoRdd.count()
        stationInfoRdd.unpersist()
        Thread.sleep(5000)
      }
    }


    val finalStationInfoDf: DataFrame = finalStationInfoRdd.map(obj => {
      GasStationInfo(
        obj.getString("POIID"),
        obj.getString("PID"),
        obj.getString("srcId"),
        obj.getString("GRPID"),
        obj.getString("src"),
        obj.getString("ss"),
        obj.getString("project_no"),
        obj.getString("URL"),
        obj.getString("adcode"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("stationName"),
        obj.getString("roadID"),
        obj.getString("roadClass"),
        obj.getString("roadName"),
        obj.getString("sfGunPriceVec"),
        obj.getString("management_model"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("addr"),
        obj.getString("tel"),
        obj.getString("queryBrandID"),
        obj.getString("gasLocationType"),
        obj.getString("headLabelList"),
        obj.getString("businessHours"),
        obj.getString("hasOilName"),
        obj.getString("oilNameVec"),
        obj.getString("discountModelVec"),
        obj.getString("gunPriceVec"),
        obj.getString("gapPriceVec"),
        obj.getString("priceActivityVec"),
        obj.getString("priceChangeTimeVec"),
        obj.getString("officialPriceChangeTimeVec"),
        obj.getString("officialPriceVec"),
        obj.getString("delFlag"),
        obj.getString("createTime"),
        obj.getString("updateTime"),
        obj.getString("updateTimeStamp"),
        obj.getString("cooperateStatus"),
        obj.getString("sfGunPriceVec1"),
        obj.getString("businessStatus"),
        obj.getString("effectiveStartVec"),
        obj.getString("effectiveEndVec"),
        obj.getString("invoiceDesc"),
        obj.getString("maintainBeginTime"),
        obj.getString("maintainEndTime"),
        obj.getString("outsideDriverDesc"),
        obj.getString("petrolStationQualify"),
        obj.getString("srcPrice"),
        obj.getString("srcList"),
        obj.getString("dunPrice"),
        obj.getString("skidMounted"),
        obj.getString("stationAlias"),
        obj.getString("stationType"),
        obj.getString("priceDieselOut"),
        obj.getString("formway"),
        obj.getString("officialGapPrice")
      )
    }).toDF()
    SparkWrite.writeToHiveNoPart(spark,finalStationInfoDf,"dm_gis.dm_ddjy_gas_station_info_di")
    //finalStationInfoDf.createOrReplaceTempView("finalStationInfoTmp")
    //spark.sql(s"insert overwrite table dm_gis.dm_ddjy_gas_station_info_di select * from finalStationInfoTmp")
  }



  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取全量油站
    stationInterface(spark, incDay)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>GasStationInfoToHive Execute Ok")
  }
  case class GasStationInfo(POIID:String,
                            PID:String,
                            srcId:String,
                            GRPID:String,
                            src:String,
                            ss:String,
                            project_no:String,
                            URL:String,
                            adcode:String,
                            lng:String,
                            lat:String,
                            stationName:String,
                            roadID:String,
                            roadClass:String,
                            roadName:String,
                            sfGunPriceVec:String,
                            management_model:String,
                            province:String,
                            city:String,
                            district:String,
                            addr:String,
                            tel:String,
                            queryBrandID:String,
                            gasLocationType:String,
                            headLabelList:String,
                            businessHours:String,
                            hasOilName:String,
                            oilNameVec:String,
                            discountModelVec:String,
                            gunPriceVec:String,
                            gapPriceVec:String,
                            priceActivityVec:String,
                            priceChangeTimeVec:String,
                            officialPriceChangeTimeVec:String,
                            officialPriceVec:String,
                            delFlag:String,
                            createTime:String,
                            updateTime:String,
                            updateTimeStamp:String,
                            cooperateStatus:String,
                            sfGunPriceVec1:String,
                            businessStatus:String,
                            effectiveStartVec:String,
                            effectiveEndVec:String,
                            invoiceDesc:String,
                            maintainBeginTime:String,
                            maintainEndTime:String,
                            outsideDriverDesc:String,
                            petrolStationQualify:String,
                            srcPrice:String,
                            srcList:String,
                            dunPrice:String,
                            skidMounted:String,
                            stationAlias:String,
                            stationType:String,
                            priceDieselOut:String,
                            formway:String,
                            officialGapPrice:String
                              )
}
