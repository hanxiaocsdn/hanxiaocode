package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkWrite}

/**
 * @Description:
 * 需求人员：
 * @Author: lixiangzhi 01405644
 * @Date:
 * 任务id:
 * 任务名称：
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object StationAddressNormalPlan {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def execute(incDay: String) = {

    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取地址数据
    val sql=
      """
        |select * from dm_gis.ddjy_logistics_park_address_join_station
        |""".stripMargin
    import spark.implicits._
    val stationAddressRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, sql).map(obj=>{
      val belong_x: String = obj.getString("xcoord")
      val belong_y: String = obj.getString("ycoord")
      obj.put("belong_x",belong_x)
      obj.put("belong_y",belong_y)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调高德规划接口数据量:"+stationAddressRdd.count())
    val returnDisRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,stationAddressRdd, SfNetInteface.normalPlanInterface, 50, "f086106db05b48e6b8cb103ead38d06a", 20000)
    val addDistDf = returnDisRdd.repartition(600)
      .map(obj => {
        val d_dist: String = obj.getString("d_dist")
        obj.put("d_dist", d_dist)
        obj
      }).filter(_.getDoubleValue("d_dist") < 5000.0).map(obj=>{
      (
        obj.getString("id"),
        obj.getString("short_name"),
        obj.getString("address"),
        obj.getString("xcoord"),
        obj.getString("ycoord"),
        obj.getString("poiid"),
        obj.getString("stationname"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("d_dist")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addDistDf:"+addDistDf.count())
    SparkWrite.writeToHiveNoPart(spark,addDistDf,"dm_gis.logistics_park_address_station_5km_di",1)

    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
}
