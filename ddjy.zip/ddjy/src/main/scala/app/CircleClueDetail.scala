package app

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.DistanceUtils
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkUtils, SparkWrite}

import scala.collection.JavaConversions._

/**
 * @Description:沿途线索基础表
 * 需求人员：周韵筹 01425211
 * @Author: lixiangzhi 01405644
 * @Date:2023/11/08
 * 任务id:1026
 * 任务名称：沿途线索基础表
 * 依赖任务：524 油站车队融合周维度表
 * 数据源：dm_ddjy_gas_carrier_merge_di
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/StationClusterRect?
 * 数据结果：ddjy_dwd_pathway_clue_base_di
 */
object CircleClueDetail {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readClueData(spark: SparkSession, fri_day: String) = {
    val joinClueSql=
      s"""
        |select
        |gas_id as poiid,
        |carrier_id,carrier_name,
        |pathway_task_count,
        |pathway_around_vehicle_count,
        |task_sum_count as stay_task_count,
        |carrier_status,carrier_tag,register_vehicle_count,
        |stationname,
        |province as gas_province,
        |city as gas_city,
        |district as gas_district,
        |addr,
        |adcode as gas_adcode,
        |lng,
        |lat,
        |cooperatestatus,
        |gas_type as management_model,
        |brand as querybrandid,
        |'' as gappricevec,
        |'' as priceactivityvec,
        |clue_task_count,
        |if(clue_task_count is not null and clue_task_count != '',1,0) as clue_task_flag
        |from dm_gis.dm_ddjy_gas_carrier_merge_di
        |where inc_day='$fri_day'
        |and adcode is not null
        |and adcode!=''
        |""".stripMargin
    val joinClueRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, joinClueSql)
    joinClueRdd
  }

  def joinCircleSeed(spark: SparkSession, joinClueRdd: RDD[JSONObject], fri_day: String) = {
    import spark.implicits._
    val clueGasSql=
      s"""
        |select
        |poiid,gas_circle_id,
        |center_x as x,
        |center_y as y,
        |clue_name as circle_name
        |from
        |(
        |	select poiid,gas_circle_id,center_x,center_y,clue_name,
        |	row_number() over(partition by poiid order by cast(d_dist as double)) as rnk
        |	from dm_gis.dwd_ddjy_clue_gas_di
        |	where inc_day='$fri_day'
        | and gas_circle_id is not null
        | and gas_circle_id!=''
        |) t1
        |where rnk=1
        |""".stripMargin
    val clueGasRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, clueGasSql).map(obj => {
      (obj.getString("poiid"), obj)
    })
    val circleSeedDistinctSql=
      s"""
         |select
         |adcode,circle_id,center_x,center_y,circle_name
         |from
         |(
         |	select stay_adcode as adcode,circle_id,center_x,center_y,
         |	belong_name as circle_name,
         |	row_number() over(partition by circle_id order by belong_name desc) as rnk
         |	from dm_gis.dwd_ddjy_clue_circle_seed
         |) t1
         |where rnk=1
         |""".stripMargin
    val circleSeedDistinctRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark,circleSeedDistinctSql).map(obj=>{
      (obj.getString("adcode"), obj)
    })
    val joinClueGasRdd: RDD[JSONObject] = joinClueRdd.map(obj => {
      (obj.getString("poiid"), obj)
    }).leftOuterJoin(clueGasRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("关联油站线索基础表后数据量:"+joinClueGasRdd.count())
    clueGasRdd.unpersist()
    joinClueRdd.unpersist()
    val notNullCircleidRdd: RDD[JSONObject] = joinClueGasRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("gas_circle_id"))
    })

    val nullCircleidRdd: RDD[(String, JSONObject)] = joinClueGasRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("gas_circle_id"))
    }).map(obj=>{
      (obj.getString("gas_adcode"),obj)
    })
    var cantoneseClueRdd: RDD[JSONObject]=null
    var addCircleIdRdd: RDD[JSONObject]=null
    if(nullCircleidRdd.count()!=0){
      val nullCircleidJoinSeedRdd: RDD[JSONObject] = nullCircleidRdd.leftOuterJoin(circleSeedDistinctRdd).map(obj => {
        val leftObj: JSONObject = obj._2._1
        val rightObj: JSONObject = obj._2._2.orNull
        if (rightObj != null) {
          val circle_id: String = rightObj.getString("circle_id")
          val circle_name: String = rightObj.getString("circle_name")
          val center_x: Double = rightObj.getDouble("center_x")
          val center_y: Double = rightObj.getDouble("center_y")
          val longitude: Double = leftObj.getDouble("lng")
          val latitude: Double = leftObj.getDouble("lat")
          val distance: Double = DistanceUtils.getDistance(center_x, center_y, longitude, latitude)
          leftObj.put("distance", distance)
          leftObj.put("gas_circle_id", circle_id)
          leftObj.put("circle_id", circle_id)
          leftObj.put("x", center_x)
          leftObj.put("y", center_y)
          leftObj.put("circle_name", circle_name)
        }
        leftObj
      })
      //2、最小distance的Circleid
      val minDistanceCircleidRdd: RDD[JSONObject] = nullCircleidJoinSeedRdd
        .filter(_.getString("gas_circle_id") != null)
        .groupBy(_.getString("poiid"))
        .map(obj => {
          obj._2.toList.minBy(json=>JSONUtil.getJsonDouble(json,"distance",Int.MaxValue))
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("获取最小距离的circle_id的数据:"+minDistanceCircleidRdd.count())

      //3、调集散圈接口的Circleid
      val needCircleInterfaceDataRdd: RDD[JSONObject] = nullCircleidJoinSeedRdd.filter(obj=>{
        StringUtils.isEmpty(obj.getString("gas_circle_id"))
      })
      logger.error("获取需要调集散圈接口的数据:"+needCircleInterfaceDataRdd.count())
      needCircleInterfaceDataRdd.take(10).foreach(println(_))
      if(needCircleInterfaceDataRdd.count()!=0){
        val stationRdd: RDD[(String, JSONObject)] = needCircleInterfaceDataRdd.repartition(1000).map(obj => {
          val tmpObj = new JSONObject()
          val clue_id: String = obj.getString("poiid")
          val adcode: String = obj.getString("gas_adcode")
          val x: Double = JSONUtil.getJsonDouble(obj, "lng", 0.0)
          val y: Double = JSONUtil.getJsonDouble(obj, "lat", 0.0)
          tmpObj.put("clue_id", clue_id)
          tmpObj.put("adcode", adcode)
          tmpObj.put("x", x)
          tmpObj.put("y", y)
          ((adcode,clue_id), tmpObj)
        }).groupByKey().map(obj=>{
          val tmpObj: JSONObject = obj._2.minBy(_.getString("clue_id"))
          (tmpObj.getString("adcode"),tmpObj)
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        val returnRdd: RDD[((String, String), JSONObject)] = stationRdd.groupByKey().repartition(5).flatMap(obj=>{
          val stations: Array[JSONObject] = obj._2.toArray
          val stationsObj = new JSONObject()
          stationsObj.put("stations",stations)
          val returnObj: JSONObject = SfNetInteface.stationClusterInterface(stationsObj)
          val resultsArray: JSONArray = JSONUtil.getJsonArrayMulti(returnObj, "api_result.results")
          val tmpList = new util.ArrayList[JSONObject]()
          for (i <- 0 until resultsArray.size()) {
            val tmpObj = new JSONObject()
            val resultObj: JSONObject = resultsArray.getJSONObject(i)
            tmpObj.fluentPutAll(resultObj)
            tmpList.add(tmpObj)
          }
          tmpList.iterator()
        }).map(obj=>{
          ((obj.getString("clue_id"),obj.getString("adcode")),obj)
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("调取集散圈接口返回数据量："+returnRdd.count())
        returnRdd.take(10).foreach(println(_))
        //需求集散圈接口返回，并回挂的数据
        val interfaceReturnDataRdd = needCircleInterfaceDataRdd.repartition(600).map(obj => {
          ((obj.getString("poiid"),obj.getString("gas_adcode")), obj)
        }).leftOuterJoin(returnRdd).map(obj=>{
          val rightObj: JSONObject = obj._2._2.getOrElse(new JSONObject())
          val leftObj: JSONObject = obj._2._1
          val center_x: String = JSONUtil.getJsonValSingle(rightObj,"center_x")
          val center_y: String = JSONUtil.getJsonValSingle(rightObj,"center_y")
          val circle_id: String = JSONUtil.getJsonValSingle(rightObj,"circle_id")
          val stationname: String = leftObj.getString("stationname")
          leftObj.put("x", center_x)
          leftObj.put("y", center_y)
          leftObj.put("circle_id", circle_id)
          leftObj.put("gas_circle_id", circle_id)
          leftObj.put("circle_name", stationname)
          leftObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("调取集散圈接口并回挂后数据量："+interfaceReturnDataRdd.count())
        cantoneseClueRdd = notNullCircleidRdd.union(minDistanceCircleidRdd).union(interfaceReturnDataRdd)
        addCircleIdRdd = minDistanceCircleidRdd.union(interfaceReturnDataRdd)
      }else{
        cantoneseClueRdd = notNullCircleidRdd.union(minDistanceCircleidRdd)
        addCircleIdRdd = minDistanceCircleidRdd
      }
    }else{
      cantoneseClueRdd = notNullCircleidRdd
    }
    //更新Circel种子表
    if (addCircleIdRdd!=null){
      val cal = Calendar.getInstance
      val time = cal.getTime
      val create_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time)
      val addCircleIdDf: DataFrame = addCircleIdRdd.map(obj => {
        (
          obj.getString("poiid"),
          obj.getString("circle_name"),
          obj.getString("gas_adcode"),
          obj.getString("gas_province"),
          obj.getString("gas_city"),
          obj.getString("gas_district"),
          obj.getString("circle_id"),
          obj.getString("x"),
          obj.getString("y"),
          create_time,
          obj.getString("lng"),
          obj.getString("lat"),
          "pathway_clue"
        )
      }).toDF("unique_id", "belong_name", "stay_adcode", "stay_province", "stay_city", "stay_district", "circle_id", "center_x","center_y","create_time","longitude","latitude","clue_type")
      addCircleIdDf.createOrReplaceTempView("addCircleIdTmp")
      val updateCircleSeedSql=
        """
          |insert overwrite table dm_gis.dwd_ddjy_clue_circle_seed
          |select
          |unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type,longitude_avg,latitude_avg
          |from
          |(
          |	select
          |	unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type,
          |	avg(longitude) over(partition by circle_id) as longitude_avg,
          |	avg(latitude) over(partition by circle_id) as latitude_avg,
          |	row_number() over(partition by unique_id order by create_time desc) as rnk
          |	from
          |	(
          |		select * from addCircleIdTmp
          |		union
          |		select unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type
          |		from dm_gis.dwd_ddjy_clue_circle_seed
          |	) t1
          |) t2
          |where rnk=1
          |""".stripMargin
      spark.sql(updateCircleSeedSql)
    }
    //写入ddjy_dwd_pathway_clue_base_di基础表
    val circleSeedNewSql=
      s"""
         |select
         |adcode,circle_id,center_x,center_y,circle_name,stay_province,stay_city,stay_district
         |from
         |(
         |	select stay_adcode as adcode,circle_id,center_x,center_y,
         |	belong_name as circle_name,
         |  stay_province,stay_city,stay_district,
         |	row_number() over(partition by circle_id order by belong_name desc) as rnk
         |	from dm_gis.dwd_ddjy_clue_circle_seed
         |) t1
         |where rnk=1
         |""".stripMargin
    val circleSeedNewRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark,circleSeedNewSql).map(obj=>{
      (obj.getString("circle_id"), obj)
    })
    val clueCircleSql=
      s"""
         |select
         |circle_id,circle_name,adcode,province,city,district,x,y
         |from dm_gis.dwd_ddjy_clue_circle_rslt_di
         |where inc_day='$fri_day'
         |""".stripMargin
    val clueCircleRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, clueCircleSql).map(obj => {
      (obj.getString("circle_id"), obj)
    })
    val cantoneseClueDf: DataFrame = cantoneseClueRdd.map(obj=>{
      val adcode: String = obj.getString("gas_adcode")
      val province: String = obj.getString("gas_province")
      val city: String = obj.getString("gas_city")
      val district: String = obj.getString("gas_district")
      obj.put("adcode", adcode)
      obj.put("province", province)
      obj.put("city", city)
      obj.put("district", district)
      (obj.getString("gas_circle_id"),obj)
    }).leftOuterJoin(circleSeedNewRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if(rightObj!=null){
        leftObj.put("circle_name",rightObj.getString("circle_name"))
        leftObj.put("adcode",rightObj.getString("adcode"))
        leftObj.put("province",rightObj.getString("stay_province"))
        leftObj.put("city",rightObj.getString("stay_city"))
        leftObj.put("district",rightObj.getString("stay_district"))
        leftObj.put("x",rightObj.getString("center_x"))
        leftObj.put("y",rightObj.getString("center_y"))
      }
      (leftObj.getString("gas_circle_id"),leftObj)
    }).leftOuterJoin(clueCircleRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if(rightObj!=null){
        leftObj.put("circle_name",rightObj.getString("circle_name"))
        leftObj.put("adcode",rightObj.getString("adcode"))
        leftObj.put("province",rightObj.getString("province"))
        leftObj.put("city",rightObj.getString("city"))
        leftObj.put("district",rightObj.getString("district"))
        leftObj.put("x",rightObj.getString("x"))
        leftObj.put("y",rightObj.getString("y"))
      }
      leftObj
    }).map(obj => {
      PathwayClueBase(
        obj.getString("gas_circle_id"),
        obj.getString("circle_name"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("x"),
        obj.getString("y"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("register_vehicle_count"),
        obj.getString("gas_circle_id"),
        obj.getString("gas_province"),
        obj.getString("gas_city"),
        obj.getString("gas_district"),
        obj.getString("poiid"),
        obj.getString("stationname"),
        obj.getString("addr"),
        obj.getString("cooperatestatus"),
        obj.getString("management_model"),
        obj.getString("querybrandid"),
        obj.getString("gappricevec"),
        obj.getString("priceactivityvec"),
        obj.getString("pathway_task_count"),
        obj.getString("pathway_around_vehicle_count"),
        obj.getString("stay_task_count"),
        obj.getString("clue_task_count"),
        obj.getString("clue_task_flag")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,cantoneseClueDf,"inc_day",fri_day,"dm_gis.ddjy_dwd_pathway_clue_base_di",50)
    joinClueGasRdd.unpersist()

  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val team_way_frequency_sql=
      s"""
         |select
         |max(inc_day) as max_day
         |from dm_gis.dm_ddjy_gas_carrier_merge_di
         |where inc_day<='$incDay'
         |""".stripMargin
    val team_way_frequency_df: DataFrame = spark.sql(team_way_frequency_sql)
    val fri_day: String = SparkUtils.getDfToJson(spark, team_way_frequency_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+fri_day)
    //读取线索数据，关联相关表
    val joinClueRdd: RDD[JSONObject] = readClueData(spark, fri_day)
    //关联集散圈种子表，调集散圈接口
    joinCircleSeed(spark,joinClueRdd,fri_day)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class PathwayClueBase(
                              circle_id:String,
                              circle_name:String,
                              adcode:String,
                              province:String,
                              city:String,
                              district:String,
                              x:String,
                              y:String,
                              carrier_id:String,
                              carrier_name:String,
                              carrier_status:String,
                              carrier_tag:String,
                              register_vehicle_count:String,
                              gas_circle_id:String,
                              gas_province:String,
                              gas_city:String,
                              gas_district:String,
                              poiid:String,
                              stationname:String,
                              addr:String,
                              cooperatestatus:String,
                              management_model:String,
                              querybrandid:String,
                              gappricevec:String,
                              prIceactivityvec:String,
                              pathway_task_count:String,
                              pathway_around_vehicle_count:String,
                              stay_task_count:String,
                              clue_task_count:String,
                              clue_task_flag:String
                            )

}
