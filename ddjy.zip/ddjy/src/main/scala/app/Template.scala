package app

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import scala.collection.JavaConversions._
/**
 * @Description:
 * 需求人员：
 * @Author: lixiangzhi 01405644
 * @Date:
 * 任务id:
 * 任务名称：
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object Template {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)

    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
}
