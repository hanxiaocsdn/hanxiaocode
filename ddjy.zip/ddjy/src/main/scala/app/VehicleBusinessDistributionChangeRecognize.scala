package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.{ArrayBuffer, ListBuffer}
/**
 * Description:车队业务分布变化识别
 * 需求方：左佳怡 01403789
 * Author: 李相志 01405644
 * Date: 14:11 2023/2/20
 * 任务id:560
 * 任务名称：车队业务分布变化识别表
 * 依赖任务：车队业务分布统计表 481
 * 数据源：ddjy_carteam_business_distribution
 * 调用服务地址：
 * 数据结果：ddjy_carteam_business_distribution_change_recognition_wi
 */
object VehicleBusinessDistributionChangeRecognize {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def distributionChangeRecognize(spark: SparkSession, max_day: String,last_seven_day:String) = {
    import spark.implicits._
    //上周数据源获取
    val lastWeekDistributionSql=
      s"""
        |Select car_team_id,car_team_name,source,city_distribution_frequency,road_distribution_frequency
        |from dm_gis.ddjy_carteam_business_distribution
        |Where inc_day='$last_seven_day' and city_distribution_frequency is not null and city_distribution_frequency!=''
        |""".stripMargin
    val lastWeekDistributionDf: DataFrame = spark.sql(lastWeekDistributionSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("上周ddjy_carteam_business_distribution中city_distribution_frequency不为空数据量："+lastWeekDistributionDf.count())
    lastWeekDistributionDf.where("car_team_name = '海丰县公平镇东如货物运输户'").show(10,false)
    val lastWeekCityDistributionRdd: RDD[((String, String, String, String), JSONObject)] = SparkUtils.getDfToJson(spark, lastWeekDistributionDf).flatMap(obj => {
      val city_distribution_frequency: String = obj.getString("city_distribution_frequency")
      val tmpList= ListBuffer[JSONObject]()
      if (city_distribution_frequency!=null){
        val city_distribution_frequency_arr: Array[String] = city_distribution_frequency.split("\\|")
        for (json <- city_distribution_frequency_arr) {
          val tmpObj = new JSONObject()
          val city: String = json.replaceAll("\\)", "").split("\\(")(0)
          val frequency_str = json.replaceAll("\\)", "").split("\\(")(1)
          val car_team_id: String = obj.getString("car_team_id")
          val car_team_name: String = obj.getString("car_team_name")
          val source: String = obj.getString("source")
          tmpObj.put("city", city)
          tmpObj.put("frequency_str", frequency_str)
          tmpObj.put("car_team_id", car_team_id)
          tmpObj.put("car_team_name", car_team_name)
          tmpObj.put("source", source)
          tmpList.append(tmpObj)
        }
      }
      tmpList.toIterator
    }).map(obj => {
      val car_team_id: String = obj.getString("car_team_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      val city: String = obj.getString("city")
      ((car_team_id, car_team_name, source, city), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    lastWeekCityDistributionRdd.filter(obj=>{
      obj._1._2=="海丰县公平镇东如货物运输户"
    }).take(10).foreach(println(_))
    //本周数据获取
    val weekDistributionSql=
      s"""
         |Select car_team_id,car_team_name,source,city_distribution_frequency,road_distribution_frequency
         |from dm_gis.ddjy_carteam_business_distribution
         |Where inc_day='$max_day' and city_distribution_frequency is not null and city_distribution_frequency!=''
         |""".stripMargin
    val weekDistributionDf: DataFrame = spark.sql(weekDistributionSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("本周ddjy_carteam_business_distribution中city_distribution_frequency不为空数据量："+weekDistributionDf.count())
    //详情1
    val weekCityDistributionRdd: RDD[((String, String, String, String), JSONObject)] = SparkUtils.getDfToJson(spark, weekDistributionDf).flatMap(obj => {
      val city_distribution_frequency: String = obj.getString("city_distribution_frequency")
      val tmpList= ListBuffer[JSONObject]()
      if (city_distribution_frequency!=null){
        val city_distribution_frequency_arr: Array[String] = city_distribution_frequency.split("\\|")
        for (json <- city_distribution_frequency_arr) {
          val tmpObj = new JSONObject()
          val city: String = json.replaceAll("\\)", "").split("\\(")(0)
          val frequency_str = json.replaceAll("\\)", "").split("\\(")(1)
          val car_team_id: String = obj.getString("car_team_id")
          val car_team_name: String = obj.getString("car_team_name")
          val source: String = obj.getString("source")
          tmpObj.put("city", city)
          tmpObj.put("frequency_str", frequency_str)
          tmpObj.put("car_team_id", car_team_id)
          tmpObj.put("car_team_name", car_team_name)
          tmpObj.put("source", source)
          tmpList.append(tmpObj)
        }
      }
      tmpList.toIterator
    }).map(obj => {
      val car_team_id: String = obj.getString("car_team_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      val city: String = obj.getString("city")
      ((car_team_id, car_team_name, source, city), obj)
    })
    val detail1Rdd: RDD[((String, String, String), JSONObject)] = lastWeekCityDistributionRdd.fullOuterJoin(weekCityDistributionRdd).map(obj => {
      val tmpObj = new JSONObject()
      val leftObj: JSONObject = obj._2._1.orNull
      val rightObj: JSONObject = obj._2._2.orNull
      if (leftObj == null && rightObj != null) {
        val car_team_id: String = rightObj.getString("car_team_id")
        val car_team_name: String = rightObj.getString("car_team_name")
        val source: String = rightObj.getString("source")
        val city: String = rightObj.getString("city")
        val frequency_str_week: String = rightObj.getString("frequency_str")
        tmpObj.put("car_team_id", car_team_id)
        tmpObj.put("car_team_name", car_team_name)
        tmpObj.put("source", source)
        tmpObj.put("city", city)
        tmpObj.put("frequency_str_week", frequency_str_week)
      } else if (leftObj != null && rightObj == null) {
        val car_team_id: String = leftObj.getString("car_team_id")
        val car_team_name: String = leftObj.getString("car_team_name")
        val source: String = leftObj.getString("source")
        val city: String = leftObj.getString("city")
        val frequency_str_last_week: String = leftObj.getString("frequency_str")
        tmpObj.put("car_team_id", car_team_id)
        tmpObj.put("car_team_name", car_team_name)
        tmpObj.put("source", source)
        tmpObj.put("city", city)
        tmpObj.put("frequency_str_last_week", frequency_str_last_week)
      } else if (leftObj != null && rightObj != null) {
        val car_team_id: String = leftObj.getString("car_team_id")
        val car_team_name: String = leftObj.getString("car_team_name")
        val source: String = leftObj.getString("source")
        val city: String = leftObj.getString("city")
        val frequency_str_last_week: String = leftObj.getString("frequency_str")
        val frequency_str_week: String = rightObj.getString("frequency_str")
        tmpObj.put("car_team_id", car_team_id)
        tmpObj.put("car_team_name", car_team_name)
        tmpObj.put("source", source)
        tmpObj.put("city", city)
        tmpObj.put("frequency_str_last_week", frequency_str_last_week)
        tmpObj.put("frequency_str_week", frequency_str_week)
      }
      tmpObj
    }).map(obj => {
      val frequency_str_last_week: String = obj.getString("frequency_str_last_week")
      val frequency_str_week: String = obj.getString("frequency_str_week")
      var b1: Long = 0
      var b2: Long = 0
      var b3: Double = 0.0
      var b4: Double = 0.0
      var c1: Long = 0
      var c2: Long = 0
      var c3: Double = 0.0
      var c4: Double = 0.0
      if (frequency_str_last_week != null && frequency_str_week == null) {
        val frequency_last_week_arr: Array[String] = frequency_str_last_week.split(",")
        b1 = frequency_last_week_arr(0).toLong
        b2 = frequency_last_week_arr(1).toLong
        b3 = frequency_last_week_arr(2).toDouble
        if(frequency_last_week_arr(3)!="null"){
          b4 = frequency_last_week_arr(3).toDouble
        }
      } else if (frequency_str_last_week == null && frequency_str_week != null) {
        val frequency_week_arr: Array[String] = frequency_str_week.split(",")
        if (StringUtils.isNoneEmpty(frequency_week_arr(0))){
          c1 = frequency_week_arr(0).toLong
        }
        if (StringUtils.isNoneEmpty(frequency_week_arr(1))){
          c2 = frequency_week_arr(1).toLong
        }
        if (StringUtils.isNoneEmpty(frequency_week_arr(2)) && frequency_week_arr(2)!="null"){
          c3 = frequency_week_arr(2).toDouble
        }
        frequency_week_arr(3)
        if(frequency_week_arr(3)!="null" && StringUtils.isNoneEmpty(frequency_week_arr(3))){
          c4 = frequency_week_arr(3).toDouble
        }
      } else if (frequency_str_last_week != null && frequency_str_week != null) {
        val frequency_last_week_arr: Array[String] = frequency_str_last_week.split(",")
        b1 = frequency_last_week_arr(0).toLong
        b2 = frequency_last_week_arr(1).toLong
        b3 = frequency_last_week_arr(2).toDouble
        if(frequency_last_week_arr(3)!="null"){
          b4 = frequency_last_week_arr(3).toDouble
        }
        val frequency_week_arr: Array[String] = frequency_str_week.split(",")
        if (StringUtils.isNoneEmpty(frequency_week_arr(0))){
          c1 = frequency_week_arr(0).toLong
        }
        if (StringUtils.isNoneEmpty(frequency_week_arr(1))){
          c2 = frequency_week_arr(1).toLong
        }
        if (StringUtils.isNoneEmpty(frequency_week_arr(2)) && frequency_week_arr(2)!="null"){
          c3 = frequency_week_arr(2).toDouble
        }
        if(frequency_week_arr(3)!="null" && StringUtils.isNoneEmpty(frequency_week_arr(3))){
          c4 = frequency_week_arr(3).toDouble
        }
      }
      val a1: Long = c1 - b1
      var a2 = ""
      if (b2 == c2) {
        a2 = "相同"
      } else if (b2 == 0 || c2 == 0) {
        a2 = "有一周没有业务轨迹"
      } else {
        a2 = "不相同"
      }
      val a3: Double = (c3 - b3).formatted("%.2f").toDouble
      var a4="100"
      if(a2!="有一周没有业务轨迹"){
        a4 = (a3 / b3 * 100).formatted("%.2f")
      }
      val a5: Double = c4 - b4
      val city: String = obj.getString("city")
      val city_frequency: String = city + "(" + a1 + "," + a2 + "," + a3 + "(" + a4 + "%)," + a5 + ")"
      obj.put("a3", a3)
      obj.put("b3", b3)
      obj.put("c3", c3)
      obj.put("a4", a4)
      obj.put("a5", a5)
      obj.put("city_frequency", city_frequency)
      val car_team_id: String = obj.getString("car_team_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      ((car_team_id, car_team_name, source), obj)
    }).groupByKey().map(obj => {
      val tmpObj = new JSONObject()
      //详情1.2
      val list_sort_less: List[JSONObject] = obj._2.toList.sortBy(_.getDoubleValue("a3"))
      val list_less: List[JSONObject] = list_sort_less.filter(_.getDoubleValue("a3") < 0.0)
      val Business_down_city: String = list_less.map(_.getString("city_frequency")).mkString("|")
      val d3: Double = list_less.map(_.getDoubleValue("b3")).sum
      val d4: Double = list_less.map(_.getDoubleValue("c3")).sum
      var combined_mileage_decline_rate_tmp: Double = 0.0
      if(d3!=0.0){
        combined_mileage_decline_rate_tmp = ((d4 - d3) / d3).formatted("%.4f").toDouble
      }
      //详情1.1
      val list_sort_greater: List[JSONObject] = obj._2.toList.sortBy(_.getDoubleValue("a3")).reverse
      val list_greater: List[JSONObject] = list_sort_greater.filter(_.getDoubleValue("a3") > 0.0)
      val Business_up_city: String = list_greater.map(_.getString("city_frequency")).mkString("|")
      val d1: Double = list_greater.map(_.getDoubleValue("b3")).sum
      val d2: Double = list_greater.map(_.getDoubleValue("c3")).sum
      var combined_mileage_growth_rate_tmp: Double = 0.0
      if(list_greater.nonEmpty){
        if(d1!=0.0){
          combined_mileage_growth_rate_tmp = ((d2 - d1) / d1).formatted("%.4f").toDouble
        }else{
          combined_mileage_growth_rate_tmp = 1.0
        }
      }
      //详情1.3
      val Business_up_clear_city: String = list_sort_greater.filter(json => {
        val c3: Double = json.getDoubleValue("c3")
        val a4: Double = json.getDoubleValue("a4")
        val a5: Double = json.getDoubleValue("a5")
        c3 > 2500 && a4 >= 30 && a5 >= 1
      }).map(_.getString("city_frequency")).mkString("|")
      //详情1.4
      val Business_down_clear_city: String = list_sort_less.filter(json => {
        val b3: Double = json.getDoubleValue("b3")
        val a4: Double = json.getDoubleValue("a4")
        val a5: Double = json.getDoubleValue("a5")
        b3 > 1500 && a4 <= -25 && a5 <= -1
      }).map(_.getString("city_frequency")).mkString("|")
      var combined_mileage_growth_decline_rate_tmp:String="无法比较"
      if(combined_mileage_growth_rate_tmp!=0.0 && combined_mileage_decline_rate_tmp!=0.0){
        combined_mileage_growth_decline_rate_tmp = (combined_mileage_growth_rate_tmp / combined_mileage_decline_rate_tmp).abs.formatted("%.4f")
      }
      val combined_mileage_growth_rate: String = combined_mileage_growth_rate_tmp*100+"%"
      val combined_mileage_decline_rate: String = combined_mileage_decline_rate_tmp*100+"%"
      var combined_mileage_growth_decline_rate: String="无法比较"
      if(combined_mileage_growth_decline_rate_tmp!="无法比较"){
        combined_mileage_growth_decline_rate = combined_mileage_growth_decline_rate_tmp.toDouble * 100 + "%"
      }
      tmpObj.put("car_team_id", obj._1._1)
      tmpObj.put("car_team_name", obj._1._2)
      tmpObj.put("source", obj._1._3)
      tmpObj.put("Business_up_city", Business_up_city)
      tmpObj.put("combined_mileage_growth_rate", combined_mileage_growth_rate)
      tmpObj.put("Business_down_city", Business_down_city)
      tmpObj.put("combined_mileage_decline_rate", combined_mileage_decline_rate)
      tmpObj.put("Business_up_clear_city", Business_up_clear_city)
      tmpObj.put("Business_down_clear_city", Business_down_clear_city)
      tmpObj.put("combined_mileage_growth_decline_rate", combined_mileage_growth_decline_rate)
      ((obj._1._1,obj._1._2,obj._1._3),tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情1数据量："+detail1Rdd.count())
    detail1Rdd.filter(obj=>{
      obj._1._2=="海丰县公平镇东如货物运输户"
    }).take(10).foreach(println(_))
    logger.error("详情1海丰县公平镇东如货物运输户")
    //详情2
    val lastWeekRoadDistributionSql=
      s"""
         |Select car_team_id,car_team_name,source,city_distribution_frequency,road_distribution_frequency
         |from dm_gis.ddjy_carteam_business_distribution
         |Where inc_day='$last_seven_day' and road_distribution_frequency is not null and road_distribution_frequency!=''
         |""".stripMargin
    val lastWeekRoadDistributionDf: DataFrame = spark.sql(lastWeekRoadDistributionSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("上周ddjy_carteam_business_distribution中road_distribution_frequency不为空数据量："+lastWeekRoadDistributionDf.count())
    val lastWeekRoadDistributionRdd: RDD[((String, String, String, String), JSONObject)] = SparkUtils.getDfToJson(spark, lastWeekRoadDistributionDf,600).flatMap(obj => {
      val road_distribution_frequency: String = obj.getString("road_distribution_frequency")
      val tmpList: ListBuffer[JSONObject] = ListBuffer[JSONObject]()
      if(road_distribution_frequency!=null){
        val road_distribution_frequency_arr: Array[String] = road_distribution_frequency.split("\\|")
        for (json <- road_distribution_frequency_arr) {
          val tmpObj = new JSONObject()
          var road = ""
          var frequency_str = ""
          val json_arr: Array[String] = json.split("\\(")
          if(json_arr.length==3){
            road = json_arr(0)+")"+json_arr(1)
            frequency_str = json_arr(2).replaceAll("\\)", "")
          }else if(json_arr.length==2){
            road = json_arr(0)
            frequency_str = json_arr(1).replaceAll("\\)","")
          }
          val car_team_id: String = obj.getString("car_team_id")
          val car_team_name: String = obj.getString("car_team_name")
          val source: String = obj.getString("source")
          tmpObj.put("road", road)
          tmpObj.put("frequency_str", frequency_str)
          tmpObj.put("car_team_id", car_team_id)
          tmpObj.put("car_team_name", car_team_name)
          tmpObj.put("source", source)
          tmpList.append(tmpObj)
        }
      }
      tmpList.toIterator
    }).map(obj => {
      val car_team_id: String = obj.getString("car_team_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      val road: String = obj.getString("road")
      ((car_team_id, car_team_name, source, road), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("lastWeekRoadDistributionRdd数据量："+lastWeekRoadDistributionRdd.count())
    lastWeekRoadDistributionRdd.take(10).foreach(println(_))
    val weekRoadDistributionSql=
      s"""
         |Select car_team_id,car_team_name,source,city_distribution_frequency,road_distribution_frequency
         |from dm_gis.ddjy_carteam_business_distribution
         |Where inc_day='$max_day' and road_distribution_frequency is not null and road_distribution_frequency!=''
         |""".stripMargin
    val weekRoadDistributionDf: DataFrame = spark.sql(weekRoadDistributionSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("本周ddjy_carteam_business_distribution中road_distribution_frequency不为空数据量："+weekRoadDistributionDf.count())
    val weekRoadDistributionRdd: RDD[((String, String, String, String), JSONObject)] = SparkUtils.getDfToJson(spark, weekRoadDistributionDf,600).flatMap(obj => {
      val road_distribution_frequency: String = obj.getString("road_distribution_frequency")
      val tmpList: ListBuffer[JSONObject] = ListBuffer[JSONObject]()
      if(road_distribution_frequency!=null){
        val road_distribution_frequency_arr: Array[String] = road_distribution_frequency.split("\\|")
        for (json <- road_distribution_frequency_arr) {
          val tmpObj = new JSONObject()
          var road = ""
          var frequency_str = ""
          val json_arr: Array[String] = json.split("\\(")
          if(json_arr.length==3){
            road = json_arr(0)+")"+json_arr(1)
            frequency_str = json_arr(2).replaceAll("\\)", "")
          }else if(json_arr.length==2){
            road = json_arr(0)
            frequency_str = json_arr(1).replaceAll("\\)","")
          }
          val car_team_id: String = obj.getString("car_team_id")
          val car_team_name: String = obj.getString("car_team_name")
          val source: String = obj.getString("source")
          tmpObj.put("road", road)
          tmpObj.put("frequency_str", frequency_str)
          tmpObj.put("car_team_id", car_team_id)
          tmpObj.put("car_team_name", car_team_name)
          tmpObj.put("source", source)
          tmpList.append(tmpObj)
        }
      }
      tmpList.toIterator
    }).map(obj => {
      val car_team_id: String = obj.getString("car_team_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      val road: String = obj.getString("road")
      ((car_team_id, car_team_name, source, road), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("weekRoadDistributionRdd数据量："+weekRoadDistributionRdd.count())
    weekRoadDistributionRdd.take(10).foreach(println(_))
    val detail2Rdd: RDD[((String, String, String), JSONObject)] = lastWeekRoadDistributionRdd.fullOuterJoin(weekRoadDistributionRdd).map(obj => {
      val tmpObj = new JSONObject()
      val leftObj: JSONObject = obj._2._1.orNull
      val rightObj: JSONObject = obj._2._2.orNull
      if (leftObj == null && rightObj != null) {
        val car_team_id: String = rightObj.getString("car_team_id")
        val car_team_name: String = rightObj.getString("car_team_name")
        val source: String = rightObj.getString("source")
        val road: String = rightObj.getString("road")
        val frequency_str_week: String = rightObj.getString("frequency_str")
        tmpObj.put("car_team_id", car_team_id)
        tmpObj.put("car_team_name", car_team_name)
        tmpObj.put("source", source)
        tmpObj.put("road", road)
        tmpObj.put("frequency_str_week", frequency_str_week)
      } else if (leftObj != null && rightObj == null) {
        val car_team_id: String = leftObj.getString("car_team_id")
        val car_team_name: String = leftObj.getString("car_team_name")
        val source: String = leftObj.getString("source")
        val road: String = leftObj.getString("road")
        val frequency_str_last_week: String = leftObj.getString("frequency_str")
        tmpObj.put("car_team_id", car_team_id)
        tmpObj.put("car_team_name", car_team_name)
        tmpObj.put("source", source)
        tmpObj.put("road", road)
        tmpObj.put("frequency_str_last_week", frequency_str_last_week)
      } else if (leftObj != null && rightObj != null) {
        val car_team_id: String = leftObj.getString("car_team_id")
        val car_team_name: String = leftObj.getString("car_team_name")
        val source: String = leftObj.getString("source")
        val road: String = leftObj.getString("road")
        val frequency_str_last_week: String = leftObj.getString("frequency_str")
        val frequency_str_week: String = rightObj.getString("frequency_str")
        tmpObj.put("car_team_id", car_team_id)
        tmpObj.put("car_team_name", car_team_name)
        tmpObj.put("source", source)
        tmpObj.put("road", road)
        tmpObj.put("frequency_str_last_week", frequency_str_last_week)
        tmpObj.put("frequency_str_week", frequency_str_week)
      }
      tmpObj
    }).map(obj => {
      val frequency_str_last_week: String = obj.getString("frequency_str_last_week")
      val frequency_str_week: String = obj.getString("frequency_str_week")
      var b1: Long = 0
      var b2: Long = 0
      var b3: Double = 0.0
      var b4: Double = 0.0
      var c1: Long = 0
      var c2: Long = 0
      var c3: Double = 0.0
      var c4: Double = 0.0
      if (frequency_str_last_week != null && frequency_str_week == null) {
        val frequency_last_week_arr: Array[String] = frequency_str_last_week.split(",")
        b1 = frequency_last_week_arr(0).toLong
        b2 = frequency_last_week_arr(1).toLong
        b3 = frequency_last_week_arr(2).toDouble
        b4 = frequency_last_week_arr(3).toDouble
      } else if (frequency_str_last_week == null && frequency_str_week != null) {
        val frequency_week_arr: Array[String] = frequency_str_week.split(",")
        c1 = frequency_week_arr(0).toLong
        c2 = frequency_week_arr(1).toLong
        c3 = frequency_week_arr(2).toDouble
        c4 = frequency_week_arr(3).toDouble
      } else if (frequency_str_last_week != null && frequency_str_week != null) {
        val frequency_last_week_arr: Array[String] = frequency_str_last_week.split(",")
        b1 = frequency_last_week_arr(0).toLong
        b2 = frequency_last_week_arr(1).toLong
        b3 = frequency_last_week_arr(2).toDouble
        b4 = frequency_last_week_arr(3).toDouble
        val frequency_week_arr: Array[String] = frequency_str_week.split(",")
        c1 = frequency_week_arr(0).toLong
        c2 = frequency_week_arr(1).toLong
        c3 = frequency_week_arr(2).toDouble
        c4 = frequency_week_arr(3).toDouble
      }
      val a1: String = b1 + "-" + c1
      val a2: Long = c2 - b2
      var a3 = ""
      if (b3 == c3) {
        a3 = "相同"
      } else if (b3 == 0 || c3 == 0) {
        a3 = "有一周没有业务轨迹"
      } else {
        a3 = "不相同"
      }
      val a4: Double = (c4 - b4).formatted("%.2f").toDouble
      var a5="100"
      if(a3 != "有一周没有业务轨迹"){
        a5 = (a4 / b4 * 100).formatted("%.2f")
      }
      val road: String = obj.getString("road")
      val road_frequency: String = s"$road($a1,$a2,$a3,$a4($a5%))"
      obj.put("a4", a4)
      obj.put("b4", b4)
      obj.put("c4", c4)
      obj.put("a5", a5)
      obj.put("road_frequency", road_frequency)
      val car_team_id: String = obj.getString("car_team_id")
      val car_team_name: String = obj.getString("car_team_name")
      val source: String = obj.getString("source")
      ((car_team_id, car_team_name, source), obj)
    }).groupByKey().map(obj => {
      val tmpObj = new JSONObject()
      //详情2.1
      val list_sort_greater: List[JSONObject] = obj._2.toList.sortBy(_.getDoubleValue("a4")).reverse
      val list_greater: List[JSONObject] = list_sort_greater.filter(_.getDoubleValue("a4") >= 0.0)
      val Business_up_road: String = list_greater.map(_.getString("road_frequency")).mkString("|")
      //详情2.2
      val list_sort_less: List[JSONObject] = obj._2.toList.sortBy(_.getDoubleValue("a3"))
      val list_less: List[JSONObject] = list_sort_less.filter(_.getDoubleValue("a4") < 0.0)
      val Business_down_road: String = list_less.map(_.getString("road_frequency")).mkString("|")
      //详情2.3
      val Business_up_clear_road: String = list_sort_greater.filter(json => {
        val c4: Double = json.getDoubleValue("c4")
        val a5: Double = json.getDoubleValue("a5")
        c4 > 2500 && a5 >= 30
      }).map(_.getString("road_frequency")).mkString("|")
      //详情2.4
      val Business_down_clear_road: String = list_sort_less.filter(json => {
        val b4: Double = json.getDoubleValue("b4")
        val a5: Double = json.getDoubleValue("a5")
        b4 > 1500 && a5 <= -25
      }).map(_.getString("road_frequency")).mkString("|")
      tmpObj.put("car_team_id", obj._1._1)
      tmpObj.put("car_team_name", obj._1._2)
      tmpObj.put("source", obj._1._3)
      tmpObj.put("Business_up_road", Business_up_road)
      tmpObj.put("Business_down_road", Business_down_road)
      tmpObj.put("Business_up_clear_road", Business_up_clear_road)
      tmpObj.put("Business_down_clear_road", Business_down_clear_road)
      ((obj._1._1,obj._1._2,obj._1._3),tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情2数据量："+detail2Rdd.count())
    val distributionChangeRecDf: DataFrame = detail1Rdd.join(detail2Rdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.fluentPutAll(rightObj)
      leftObj
    }).map(obj => {
      DistributionChangeRec(
        obj.getString("car_team_id"),
        obj.getString("car_team_name"),
        obj.getString("source"),
        obj.getString("Business_up_city"),
        obj.getString("Business_down_city"),
        obj.getString("Business_up_clear_city"),
        obj.getString("Business_down_clear_city"),
        obj.getString("Business_up_road"),
        obj.getString("Business_down_road"),
        obj.getString("Business_up_clear_road"),
        obj.getString("Business_down_clear_road"),
        obj.getString("combined_mileage_growth_rate"),
        obj.getString("combined_mileage_decline_rate"),
        obj.getString("combined_mileage_growth_decline_rate")
      )
    }).toDF()
    distributionChangeRecDf.createOrReplaceTempView("distributionChangeRecTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_carteam_business_distribution_change_recognition_wi partition(inc_day='${max_day}') select * from distributionChangeRecTmp")

  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取分区最大值
    val carteam_business_distribution_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.ddjy_carteam_business_distribution
        |where inc_day<='$incDay'
        |""".stripMargin
    val carteam_business_distribution_df: DataFrame = spark.sql(carteam_business_distribution_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, carteam_business_distribution_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    val last_seven_day = DateUtil.getDateStr(max_day, -7, "")
    logger.error("分区最大值："+max_day)
    logger.error("分区最大值7天前的日期："+last_seven_day)
    //数据源获取并计算
    distributionChangeRecognize(spark, max_day,last_seven_day)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    //execute()
    logger.error("======>>>>>>VehicleBusinessDistributionChangeRecognize Execute Ok")
  }
  case class DistributionChangeRec(
              car_team_id:String,
              car_team_name:String,
              source:String,
              Business_up_city:String,
              Business_down_city:String,
              Business_up_clear_city:String,
              Business_down_clear_city:String,
              Business_up_road:String,
              Business_down_road:String,
              Business_up_clear_road:String,
              Business_down_clear_road:String,
              combined_mileage_growth_rate:String,
              combined_mileage_decline_rate:String,
              combined_mileage_growth_decline_rate:String
  )

}
