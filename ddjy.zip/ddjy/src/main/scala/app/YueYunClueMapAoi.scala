package app

import java.util

import cn.hutool.core.codec.Base64
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, GeometryUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import com.vividsolutions.jts.geom.{Coordinate, Geometry, Point}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SfNetInteface

import scala.collection.JavaConversions._
import scala.util.control.Breaks

/**
 * @Description:粤运线索地图
 * 需求人员：矫悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 18:40 2022/11/14
 * 任务id:577
 * 任务名称：粤运线索地图
 * 依赖任务：粤运集散地关联车队表 258
 * 数据源：single_agr_stat_all_drop_owner_tmp
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0
 *             http://gis-int.int.sfdc.com.cn:1080/rgeo/api?x=%s&y=%s&opt=sf1&ak=%s
 *             http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s
 *             http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/StationClusterRect?
 * 数据结果：ddjy_aoi_interface_tmp、dwd_ddjy_aoi_key_di、dwd_ddjy_aoi_not_key_di
 */
object YueYunClueMapAoi {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readDropOwnerData(spark: SparkSession, incDay: String) = {

    val singleAgrSql=
      s"""
        |select *
        |from dm_gis.single_agr_stat_all_drop_owner_tmp
        |where inc_day='$incDay'
        |""".stripMargin
    val dropOwnerDf: DataFrame = spark.sql(singleAgrSql)
    val dropOwnerRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, dropOwnerDf).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dropOwner表数据量："+dropOwnerRdd.count())
    dropOwnerRdd
  }

  def insertAoiInterfaceTable(spark: SparkSession, aoiInterfaceRdd: RDD[JSONObject]) = {
    import spark.implicits._
    val aoiInterfaceDf: DataFrame = aoiInterfaceRdd.map(obj => {
      DropAoiInterface(
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("faType"),
        obj.getString("aoiCode"),
        obj.getString("znoCode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("stay_adcode")
      )
    }).toDF()
    aoiInterfaceDf.createOrReplaceTempView("aoiInterfaceTmp")
    spark.sql("insert overwrite table dm_gis.ddjy_aoi_interface_tmp select * from aoiInterfaceTmp")
  }

  def dropOwnerAoiInterface(spark: SparkSession, dropOwnerRdd: RDD[JSONObject], incDay: String) = {
    import scala.collection.JavaConverters._
    val polygonRdd = dropOwnerRdd.map(obj => {
      val agr_lng: Double = obj.getDoubleValue("agr_lng")
      val agr_lat: Double = obj.getDoubleValue("agr_lat")
      val agr_rs_id: String = obj.getString("agr_rs_id")
      val point: Point = GeometryUtil.createPoint(agr_lng, agr_lat)
      (agr_rs_id.reverse, point)
    }).groupByKey()
      .repartition(400).map(obj => {
      val list: util.List[Point] = obj._2.toList.asJava
      val geometry: Geometry = GeometryUtil.getCoorPolygon(list)
      //多边形外扩500米
      val geometry_buffer = geometry.buffer(GeometryUtil.meterToDeg(500))
      val coordinates: Array[Coordinate] = geometry_buffer.getCoordinates
      val points: util.List[Point] = new util.ArrayList[Point]()
      for (elem <- coordinates) {
        val x3 = elem.x
        val y3 = elem.y
        val point: Point = GeometryUtil.createPoint(x3, y3)
        points.add(point)
      }
      var polygon=""
      if (points.size()==1){
        polygon = GeometryUtil.getPointStr(points.get(0))
      }else if(points.size()==2){
        polygon = GeometryUtil.getLineStrFromPointList(points)
      }else{
        polygon = GeometryUtil.getPolygonStrByPoints(points)
      }
      val agr_rs_id: String = obj._1.reverse
      (polygon,agr_rs_id)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("生成polygon格式数据量:"+polygonRdd.count())
    val httpAoiPolygon = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "577", "粤运线索地图", "获取adcode信息", "http://sds-core-datarun.sf-express.com/datarun/aoi/getWktAoi", "", polygonRdd.count(), 50)

    val aoiInterfaceRdd = polygonRdd.map(obj=>{
      val tmpObj = new JSONObject()
      val polygon: String = obj._1
      val agr_rs_id: String = obj._2
      tmpObj.put("polygon",polygon)
      tmpObj.put("agr_rs_id",agr_rs_id)
      tmpObj
    }).repartition(50).flatMap(obj => {
      val retObj: JSONObject = SfNetInteface.aoiPolygonInterface(obj)
      val api_result: JSONObject = JSONUtil.getJSONObject(retObj, "api_result")
      val dataArray: JSONArray = JSONUtil.getJsonArrayMulti(api_result, "data")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until dataArray.size()) {
        val tmpObj = new JSONObject()
        val dataObj: JSONObject = dataArray.getJSONObject(i)
        val id: String = dataObj.getString("id")
        val name: String = dataObj.getString("name")
        val faType: String = dataObj.getString("faType")
        val city: String = dataObj.getString("city")
        var adcode: String = JSONUtil.getJsonValSingle(dataObj, "adCode")
        if (StringUtils.isNotEmpty(adcode) && adcode.size >=6){
          adcode = adcode.substring(0, 6)
        }
        tmpObj.fluentPutAll(obj)
        tmpObj.put("id", id)
        tmpObj.put("name", name)
        tmpObj.put("faType", faType)
        tmpObj.put("city", city)
        tmpObj.put("stay_adcode", adcode)
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    })
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpAoiPolygon)

    //logger.error("调aoi接口返回数据量："+aoiInterfaceRdd.count())
    insertAoiInterfaceTable(spark,aoiInterfaceRdd)
    logger.error("====>>>>>>>插入aoi接口表成功")
    aoiInterfaceRdd.unpersist()
  }
  def readAoiInterfaceData(spark: SparkSession, incDay: String) = {
    val aoi_interface_sql=
      s"""
        |select *
        |from dm_gis.ddjy_aoi_interface_tmp
        |""".stripMargin
    val aoi_interface_df: DataFrame = spark.sql(aoi_interface_sql)
    aoi_interface_df
  }

  def getAreaKeyRdd(spark:SparkSession,aoiInterfaceRdd:RDD[JSONObject]) = {
    val name_key="油站|服务区|中国石化|中国石油|壳牌|美孚|加德士|东方|碧辟|道达尔|埃索|道达尔|中化|中石油|中油|BP|TOTAL|混凝土|水泥|沥青|家居|石膏|定制|供应链|沙场|石场|纺织|铝业|橡胶|机械|酒厂|啤酒|油站|服务区|石场|钢铁|矿业|木业|石化|塑料|金属|纺织|工业|塑胶|陶瓷|玻璃|材料|纸|五金|钢材|不锈钢|公司|家具|电器|家电|建材|市场|酒业|化肥|批发|钢贸|开发区|创业园|商贸园|科贸园|开发区|处理厂|厂区|厂房|工业园|工业区|工业城|产业园|科技园|研究院|基地|工业|工厂|厂|园区|中心|集团|分销中心|菜鸟|冷库|电商|电子商务|仓储|邮局|物流|货运|运输|快递|中转|集散点|分拨|分拨中心|韵达|申通|顺丰|中通|圆通|德邦|邮政|EMS|ems|京东|百世|龙邦|国通|龙邦|极兔|快递|大件|货场|仓库|工艺|集团|码头|口岸|口岸|港口|保税|港区|卸货|货运站|车站|南站|北站|西站|东站|客运站|火车站|机场|花园|花卉场|花场|农场|农田|牧场|菜场|菜园|菜地|养殖场|蔬菜基地|果业|果园|菜地|养鸡场|鱼塘|林场|渔场|猪场|果场|工地|项目部|项目分部|工程建设"
    val name_key_arr: Array[String] = name_key.split("\\|")
    val keyFilterRdd: RDD[JSONObject] = aoiInterfaceRdd.filter(obj => {
      val name: String = obj.getString("name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- name_key_arr.indices) {
          val name_key: String = name_key_arr(k)
          if (name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      val remove_name_key="工地|无名工地|工地（在建）|工地（建设中）"
      val remove_name_key_arr: Array[String] = remove_name_key.split("\\|")
      val fatype_key = "010000,010100,010101,010102,010103,010104,010105,010107,010108,010109,010110,010111,010112,060700,170400,060300,060600,060700,061000,061100,070400,070401,070500,070501,070502,070503,120100,120201,150200,150300,150400,150900,170300,170301,170302,170400,170401,170402,170403,170404,170405,170406,170407,170408,500000,510000"
      val fatype_key_arr: Array[String] = fatype_key.split(",")
      val fatype: String = obj.getString("fatype")
      //val dist: Double = obj.getDouble("dist")

      bool && (fatype_key_arr.contains(fatype) || StringUtils.isEmpty(fatype)) && !remove_name_key_arr.contains(name)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤出重点类型数据量："+keyFilterRdd.count())
    //keyFilterRdd.filter(_.getString("name").contains("公司")).take(10).foreach(println(_))
    //keyFilterRdd.take(10).foreach(println(_))
    val keyRdd: RDD[JSONObject] = keyFilterRdd
      .map(obj => {
        val agr_rs_id: String = obj.getString("agr_rs_id")
        (agr_rs_id, obj)
      }).groupByKey().map(obj => {
      obj._2.toList.maxBy((json: JSONObject) => {
        JSONUtil.getJsonValSingle(json,"stay_adcode")
      })
    }).map(obj => {
      obj.put("clue_type", "AOI_key_clue")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val keyMapRdd: RDD[(String, JSONObject)] = keyRdd.map(obj => {
      (obj.getString("agr_rs_id"),obj)
    })
    val notkeyRdd: RDD[JSONObject] = aoiInterfaceRdd.repartition(600).map(obj => {
      (obj.getString("agr_rs_id"), obj)
    }).leftOuterJoin(keyMapRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj == null
    }).map(obj => {
      val leftObj: JSONObject = obj._2._1
      (leftObj.getString("agr_rs_id"), leftObj)
    }).groupByKey().map(obj => {
      obj._2.toList.maxBy((json: JSONObject) => {
        JSONUtil.getJsonValSingle(json,"stay_adcode")
      })
    }).map(obj => {
      obj.put("clue_type", "AOI_not_key_clue")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    keyFilterRdd.unpersist()
    (keyRdd,notkeyRdd)
  }

  def addAoiProCity(spark: SparkSession, yOrNKeyRdd: RDD[JSONObject],dropOwnerRdd:RDD[JSONObject]) = {
    import spark.implicits._
    val cityMapSql=
      """
        |select
        |province_name,city_name,county_name,county_code
        |from
        |(
        |	select province_name,city_name,county_name,county_code,
        |	row_number() over(partition by county_code order by version desc) as rnk
        |	from dm_gis.gis_district
        |	where inc_day in(select max(inc_day) from dm_gis.gis_district)
        |) t1
        |where rnk=1
        |""".stripMargin
    val cityMapRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, cityMapSql).map(obj => {
      (obj.getString("county_code"), obj)
    })
    val addAoiProCityRdd: RDD[(String, JSONObject)] = yOrNKeyRdd.map(obj => {
      (obj.getString("stay_adcode"), obj)
    }).leftOuterJoin(cityMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("stay_province", rightObj.getString("province_name"))
        leftObj.put("stay_city", rightObj.getString("city_name"))
        leftObj.put("stay_district", rightObj.getString("county_name"))
      }
      (leftObj.getString("agr_rs_id"),leftObj)
    })
    val aoiYOrNKeyDf: DataFrame = dropOwnerRdd.map(obj=>{
      (obj.getString("agr_rs_id"),obj)
    }).join(addAoiProCityRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.put("id",rightObj.getString("id"))
      leftObj.put("name",rightObj.getString("name"))
      leftObj.put("faType",rightObj.getString("faType"))
      leftObj.put("city",rightObj.getString("city"))
      leftObj.put("stay_adcode",rightObj.getString("stay_adcode"))
      leftObj.put("stay_province", rightObj.getString("stay_province"))
      leftObj.put("stay_city", rightObj.getString("stay_city"))
      leftObj.put("stay_district", rightObj.getString("stay_district"))
      leftObj
    }).map(obj=>{
      LogisticsVehicleTag(
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("fatype"),
        obj.getString("aoicode"),
        obj.getString("znocode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("is_logistics"),
        obj.getString("distribute_passpoint"),
        obj.getString("big_category"),
        obj.getString("mid_category"),
        obj.getString("type_name"),
        obj.getString("tag"),
        obj.getString("clue_type"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        obj.getString("stay_adcode")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    aoiYOrNKeyDf
  }

  def joinAoiKeyType(spark: SparkSession, aoiInterfaceDf: DataFrame, dropOwnerRdd:RDD[JSONObject], incDay:String) = {
    val aoiInterfaceRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, aoiInterfaceDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val (keyRdd,notKeyRdd): (RDD[JSONObject], RDD[JSONObject]) = getAreaKeyRdd(spark,aoiInterfaceRdd)
    logger.error("重点类型数据量："+keyRdd.count())
    val aoiKeyDf: DataFrame = addAoiProCity(spark, keyRdd, dropOwnerRdd)
    logger.error("AOI关联的重点类型数据量："+aoiKeyDf.count())
    aoiKeyDf.createOrReplaceTempView("aoiKeyTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_aoi_key_di select * from aoiKeyTmp")
    logger.error("非重点类型数据量："+notKeyRdd.count())
    val aoiNotKeyDf: DataFrame = addAoiProCity(spark, notKeyRdd, dropOwnerRdd)
    logger.error("AOI关联的非重点类型数据量："+aoiNotKeyDf.count())
    aoiNotKeyDf.createOrReplaceTempView("aoiNotKeyTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_aoi_not_key_di select * from aoiNotKeyTmp")
  }

  def dropOwnerTmp(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val sp_dm_wi_sql=
      """
        |select
        |*
        |from dm_gis.dwd_ddjy_sp_dm_wi
        |where cmp_partition='20230601_20230607'
        |""".stripMargin
    val sp_dm_wi_df = SparkUtils.getRowToJson(spark, sp_dm_wi_sql).map(obj => {
      val vehicle_no: String = obj.getString("agr_id").split("_")(0)
      val timeStamp: String = obj.getString("agr_id").split("_")(1)
      val vehicle_no_new: String = Base64.decodeStr(vehicle_no,"utf-8")
      val agr_id_new: String = vehicle_no_new + "_" + timeStamp
      val vehicle_num: String = agr_id_new.substring(0, 1)
      obj.put("vehicle_no",vehicle_no_new)
      obj.put("vehicle_num",vehicle_num)
      obj.put("agr_id", agr_id_new)
      obj
    }).filter(obj=>{
      val vehicle_no: String = obj.getString("vehicle_no")
      //vehicle_no.startsWith("鲁")
      vehicle_no.startsWith("鲁B") ||
        vehicle_no.startsWith("鲁U") ||
        vehicle_no.startsWith("川A") ||
        vehicle_no.startsWith("苏E") ||
        vehicle_no.startsWith("湘A")
    }).map(obj=>{
      (
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src")
      )
    }).toDF("agr_id","agr_cnt","agr_dis","agr_tm","agr_lng","agr_lat","agr_dis2sp","agr_gh","agr_rs_id","agr_rs_cnt","type","data_src").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤出某些城市车牌号后数据量:"+sp_dm_wi_df.count())
    sp_dm_wi_df.createOrReplaceTempView("sp_dm_wi_tmp")
    val tomorrow_time: String = DateUtil.getDateStr(incDay, 1, "")
    val dropOwnerTmpSql=
      s"""
        |insert overwrite table dm_gis.single_agr_stat_all_drop_owner_tmp
        |select
        |agr_id,agr_cnt,agr_dis,agr_tm,agr_lng,agr_lat,agr_dis2sp,agr_gh,agr_rs_id,agr_rs_cnt,type,data_src,vehicle,vehicle_time,
        |vehicle_no,owner_id,owner_name,province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type
        |from
        |(
        |	select
        |	agr_id,agr_cnt,agr_dis,agr_tm,agr_lng,agr_lat,agr_dis2sp,agr_gh,agr_rs_id,agr_rs_cnt,t3.type,data_src,vehicle,vehicle_time,
        |	vehicle_no,owner_id,owner_name,province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,sf_owner
        |	from
        |	(
        |		select
        |		*,
        |		split(agr_id,'_')[0] as vehicle,
        |		if(agr_id like '粤%',from_unixtime(cast(split(agr_id,'_')[1] as bigint),'yyyy-MM-dd'),from_unixtime(cast(split(agr_id,'_')[2] as bigint),'yyyy-MM-dd')) as vehicle_time
        |		from dm_gis.dwd_ddjy_sp_dm_wi
        |   where cmp_partition='20230601_20230607'
        |		where type='DC'
        |		and cast(agr_tm as bigint)>=900
        |	) t3
        |	inner join
        |	(
        |		select
        |		*
        |		from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |		where inc_day='${tomorrow_time}'
        |		and owner_type != '危运'
        |   and owner_type != '客运'
        |		and owner_name not REGEXP '暂缺信息'
        |   and owner_name is not null
        |   and owner_name !=''
        |		and owner_name not REGEXP '中国邮政'
        |		and owner_name not REGEXP 'EMS'
        |		and owner_name not REGEXP '中通'
        |		and owner_name not REGEXP '京东'
        |		and owner_name not REGEXP '韵达'
        |		and owner_name not REGEXP '圆通'
        |		and owner_name not REGEXP '大众'
        |		and owner_name not REGEXP '申通'
        |		and owner_name not REGEXP '德邦'
        |		and owner_name not REGEXP '极兔'
        |		and owner_name not REGEXP '百世'
        |		and owner_name not REGEXP '丰巢'
        |		and owner_name not REGEXP '顺丰'
        |		and owner_name not REGEXP '顺路'
        |	) t4
        |	on t3.vehicle=t4.vehicle_no
        |	left join dm_gis.dim_sf_owner_df t5
        |	on t4.owner_name=t5.sf_owner
        |) t6
        |where t6.sf_owner is null
        |""".stripMargin
    spark.sql(dropOwnerTmpSql)
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //生成single_agr_stat_all_drop_owner_tmp
    //dropOwnerTmp(spark,incDay)
    //读取single_agr_stat_all_drop_owner_tmp数据
    val dropOwnerRdd: RDD[JSONObject] = readDropOwnerData(spark, incDay)
    //调aoi接口
    dropOwnerAoiInterface(spark,dropOwnerRdd,incDay)
    //读取dwd_ddjy_logistics_vehicle_di表数据
    val aoiInterfaceDf: DataFrame = readAoiInterfaceData(spark, incDay)
    //关联AOI重点类型数据
    joinAoiKeyType(spark,aoiInterfaceDf,dropOwnerRdd,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>YueYunClueMapAoi Execute Ok")
  }

  case class DropAoiInterface(
                               agr_id:String,
                               agr_cnt:String,
                               agr_dis:String,
                               agr_tm:String,
                               agr_lng:String,
                               agr_lat:String,
                               agr_dis2sp:String,
                               agr_gh:String,
                               agr_rs_id:String,
                               agr_rs_cnt:String,
                               agr_type:String,
                               data_src:String,
                               vehicle:String,
                               vehicle_time:String,
                               vehicle_no:String,
                               owner_id:String,
                               owner_name:String,
                               province_name:String,
                               city_name:String,
                               area_name:String,
                               area_manager_name:String,
                               org_type:String,
                               credit_code:String,
                               manager:String,
                               manager_phone:String,
                               contactor:String,
                               contactor_phone:String,
                               owner_type:String,
                               id:String,
                               name:String,
                               fatype:String,
                               aoicode:String,
                               znocode:String,
                               dist:String,
                               city:String,
                               adcode:String
                             )

  case class LogisticsVehicleTag(
                                  agr_id:String,
                                  agr_cnt:String,
                                  agr_dis:String,
                                  agr_tm:String,
                                  agr_lng:String,
                                  agr_lat:String,
                                  agr_dis2sp:String,
                                  agr_gh:String,
                                  agr_rs_id:String,
                                  agr_rs_cnt:String,
                                  vehicle_type:String,
                                  data_src:String,
                                  vehicle:String,
                                  vehicle_time:String,
                                  vehicle_no:String,
                                  owner_id:String,
                                  owner_name:String,
                                  province_name:String,
                                  city_name:String,
                                  area_name:String,
                                  area_manager_name:String,
                                  org_type:String,
                                  credit_code:String,
                                  manager:String,
                                  manager_phone:String,
                                  contactor:String,
                                  contactor_phone:String,
                                  owner_type:String,
                                  id:String,
                                  name:String,
                                  faType:String,
                                  aoiCode:String,
                                  znoCode:String,
                                  dist:String,
                                  city:String,
                                  is_logistics:String,
                                  distribute_passpoint:String,
                                  big_category:String,
                                  mid_category:String,
                                  type_name:String,
                                  tag:String,
                                  clue_type:String,
                                  stay_province:String,
                                  stay_city:String,
                                  stay_district:String,
                                  stay_adcode:String
                                )
}
