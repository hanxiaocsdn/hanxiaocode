package app

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:油站报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:448
 * 任务名称：油站报表
 * 依赖任务：每日-原始钱包信息表mysql导入hive 499、每日-原始钱包历史交易明细表mysql导入hive 500、每日-原始油站信息过滤表 512、订单支付时间重分区表 387、每日-原始油价表mysql导入hive 503
 * 数据源：ddjy_dim_station_info_filter、ddjy_dwd_station_order_pay_repartition_di、ddjy_ods_dim_wallet、ddjy_ods_wallet_history、ddjy_ods_dim_petrol_price_current
 * 调用服务地址：无
 * 数据结果：ddjy_uimp_dm_station_order_oil_report
 */
object CollectionStationReportData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String) = {
    val station_order_oil_df: DataFrame = spark.sql(
      s"""
         |
         |select
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |'' as petrol_station_name,
         |nvl(t8.sale_price,t1.sale_price) as sale_price,
         |nvl(t8.country_price,t1.country_price) as country_price,
         |province_name,city_name,area_name,address_name,create_date,settle_model,
         |'' as min_pay_time,
         |pay_success as pay_success,
         |'' as pay_fail,
         |'' as order_timeout,
         |'' as order_close,
         |'' as order_cancell,
         |'' as pay_success_rate,
         |'' as car_team_cnt,
         |'' as carplate_cnt,
         |'' as oil_mass,
         |'' as ft_sale_money,
         |'' as ft_profit,
         |round(total_amount,2) as total_amount,
         |round(trade_amount,2) as trade_amount,
         |'' as hour_time,
         |dd_update_time,
         |t1.id as station_id
         |from
         |(
         |	select *
         |	from dm_gis.ddjy_dim_station_info_filter
         |	where inc_day='${inc_day}'
         |	and (enable_flag=1 or enable_flag=4)
         |) t1
         |left join
         |(
         |	select
         |	nvl(t6.station_id,t7.user_id) as station_id,
         |	pay_success,total_amount,trade_amount,
         |	dd_update_time
         |	from
         |	(
         |		select
         |		station_id,
         |		count(order_sn) as pay_success,
         |		max(update_date) as dd_update_time
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day='${inc_day}'
         |		and order_status=2
         |		group by station_id
         |	) t6
         |	full join
         |	(
         |		select
         |		user_id,
         |		split(max(concat(wallet_date,'\001',abs(t3.total_amount))),'\001')[1] as total_amount,
         |		sum(t4.trade_amount) as trade_amount
         |		from
         |		(
         |			select *,from_unixtime(unix_timestamp(inc_day,'yyyyMMdd'),'yyyy-MM-dd') as wallet_date
         |			from dm_gis.ddjy_ods_dim_wallet
         |			where inc_day='${inc_day}' and
         |			account_type=11 and
         |			user_type=4
         |		) t3
         |		left join
         |		(
         |			select *
         |			from dm_gis.ddjy_ods_wallet_history
         |			where inc_day='${inc_day}'
         |			and inoutcome_type=2
         |		) t4
         |		on t3.id=t4.wallet_id
         |		group by t3.user_id
         |	) t7
         |	on t6.station_id=t7.user_id
         |) t2
         |on t1.id=t2.station_id
         |left join
         |(
         |	select station_id,sale_price,country_price
         |	from dm_gis.ddjy_ods_dim_petrol_price_current
         |	where inc_day='${inc_day}'
         | and del_flag=0
         |) t8
         |on t1.id=t8.station_id
         |""".stripMargin)
    station_order_oil_df.repartition(1).createOrReplaceTempView("station_order_oil_tmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_uimp_dm_station_order_oil_report partition(inc_day='${inc_day}') select * from station_order_oil_tmp")
    logger.error("写入ddjy_uimp_dm_station_order_oil_report每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      stationProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>油站报表 Execute Ok")
  }

}
