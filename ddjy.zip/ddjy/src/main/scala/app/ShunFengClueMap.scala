package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkJoin, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkWrite

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
 * 任务名称：顺丰线索地图
 * 任务ID：266
 * 需求人员：矫悦 01404184
 * 开发人员：王冬冬 01413698 lixiangzhi 01405644
 * 依赖任务：粤运车辆所属企业联系方式表 257
 * 数据源：eta_std_line_recall1、dim_department、dm_company_contact_tag_dtl、dm_company_dtl、dwd_ddjy_carrier_info_seed_copy、dim_ddjy_vehicle_concat_yy_df、ddjy_ods_dim_team_info、dwd_ddjy_dim_carrier_info_di、dwd_ddjy_carrier_info_di、dim_ddjy_sf_carrier_concat_di
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0
 *             http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s
 * 数据结果：dim_ddjy_sf_carrier_concat_di、dwd_ddjy_dim_carrier_info_di、dwd_ddjy_carrier_info_di、dwd_ddjy_carrier_info_seed_copy、dwd_ddjy_dept_gas_station_dis_sf_di、dwd_ddjy_dept_clue_sf_di、dwd_ddjy_dept_carrier_clue_sf_di
 */
object ShunFengClueMap {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  
  def vehicleConcatYyProcess(spark: SparkSession, end_time: String) = {

    val tomorrow_time: String = DateUtil.getDateStr(end_time, 1, "")
    val firm_day: String = DateUtil.getDateStr(end_time, 2, "")
    val yyFirmJoinVehicleSql=
      s"""
        |select
        |t1.vehicle_no,t1.owner_id,t1.owner_name,
        |t2.province_name,t2.city_name,t2.area_name,t2.area_manager_name,t2.org_type,t2.credit_code,t2.manager,t2.manager_phone,t2.contactor,t2.contactor_phone,t2.owner_type,t2.city_id,t2.access_date,
        |t1.inc_day
        |from
        |(
        |	select *
        |	from dm_gis.dwd_vehicle_yy_df
        |	where inc_day='${tomorrow_time}'
        |) t1
        |inner join
        |(
        |	select *
        |	from dm_gis.ods_firm_yy_df
        |	where inc_day='${firm_day}' and status='0'
        |) t2
        |on t1.owner_id=t2.owner_id
        |""".stripMargin
    val yyFirmJoinVehicleDf: DataFrame = spark.sql(yyFirmJoinVehicleSql)
    yyFirmJoinVehicleDf.createOrReplaceTempView("vehicle_firm_join_tmp")
    val other_vehicle_firm_join_sql=
      """
        |select
        |t10.*
        |from vehicle_firm_join_tmp t10
        |left join
        |(
        |	select
        |	owner_id
        |	from vehicle_firm_join_tmp
        |	where credit_code is not null and credit_code!=''
        |	group by owner_id
        |) t11
        |on t10.owner_id=t11.owner_id
        |where t11.owner_id is null
        |""".stripMargin
    val other_vehicle_firm_join_df: DataFrame = spark.sql(other_vehicle_firm_join_sql)
    other_vehicle_firm_join_df.createOrReplaceTempView("other_vehicle_firm_join_tmp")
    val mid_vehicle_concat_sql=
      s"""
        |select
        |vehicle_no,
        |nvl(t5.owner_id,t3.owner_id) as owner_id,
        |nvl(t5.owner_name,t3.owner_name) as owner_name,
        |province_name,city_name,area_name,area_manager_name,org_type,t3.credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,city_id,access_date
        |from
        |(
        |	select *
        |	from vehicle_firm_join_tmp
        |	where credit_code is not null and credit_code!=''
        |) t3
        |left join
        |(
        |	select
        |	owner_id,credit_code,owner_name
        |	from
        |	(
        |		select
        |		*,
        |		row_number() over(partition by credit_code order by access_date desc,length(owner_name) desc) as rnk
        |		from vehicle_firm_join_tmp
        |		where credit_code is not null and credit_code!='' and length(credit_code)=18
        |	) t4
        |	where rnk=1
        |) t5
        |on t3.credit_code=t5.credit_code
        |union all
        |select
        |vehicle_no,
        |nvl(t8.owner_id,t6.owner_id) as owner_id,
        |t6.owner_name,
        |province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,city_id,access_date
        |from
        |(
        |	select *
        |	from other_vehicle_firm_join_tmp
        |) t6
        |left join
        |(
        |	select
        |	owner_name,owner_id
        |	from
        |	(
        |		select
        |		*,
        |		row_number() over(partition by owner_name order by access_date desc) as rnk
        |		from other_vehicle_firm_join_tmp
        |	) t7
        |	where rnk=1
        |) t8
        |on t6.owner_name=t8.owner_name
        |""".stripMargin
    val mid_vehicle_concat_df: DataFrame = spark.sql(mid_vehicle_concat_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    mid_vehicle_concat_df.createOrReplaceTempView("mid_vehicle_concat_tmp")
    //粤运车辆信息数据处理
    val vehicleContactSql=
      s"""
         |select
         |owner_id,credit_code,
         |owner_name as name,
         |org_type as company_org_type_clean,
         |manager as legal_person_name,
         |manager_phone as content,
         |city_id as city_adcode,
         |owner_type as business_scope,
         |access_date as source_time,
         |case when length(manager_phone) in (7,8) or manager_phone REGEXP '-' then 'tel'
         |	 when length(manager_phone)=11 then 'mobile'
         |	 else  ''
         |	 end as type,
         |'' as business_scope,
         |'粤运' as src,
         |'' as carrier_status
         |from mid_vehicle_concat_tmp
         |where (owner_type is null or owner_type ='' or owner_type REGEXP '重货')
         |and (owner_name not REGEXP '暂缺信息')
         |union all
         |select
         |owner_id,credit_code,
         |owner_name as name,
         |org_type as company_org_type_clean,
         |contactor as legal_person_name,
         |contactor_phone as content,
         |city_id as city_adcode,
         |owner_type as business_scope,
         |access_date as source_time,
         |case when length(contactor_phone) in (7,8) or contactor_phone REGEXP '-' then 'tel'
         |	 when length(contactor_phone)=11 and contactor_phone like '1%' then 'mobile'
         |	 else  ''
         |	 end as type,
         |'' as business_scope,
         |'粤运' as src,
         |'' as carrier_status
         |from mid_vehicle_concat_tmp
         |where (owner_type is null or owner_type ='' or owner_type REGEXP '重货')
         |and (owner_name not REGEXP '暂缺信息')
         |""".stripMargin
    val vehicleContactRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, vehicleContactSql).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("粤运vehicleContact数据量："+vehicleContactRdd.count())
    (vehicleContactRdd,mid_vehicle_concat_df)
  }

  def carrierContact(spark: SparkSession,end_time:String) = {
    val contactInfoSql=
      """
        |select credit_code,content,source_time,type
        |from dm_gis.dm_company_contact_tag_dtl
        |where credit_code is not null and credit_code != '' and length(credit_code)=18
        |""".stripMargin
    val contactInfoDf: DataFrame = spark.sql(contactInfoSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val companyInfoSql=
      """
        |select
        |credit_code,name,company_org_type_clean,legal_person_name,city_adcode,business_scope
        |from
        |(
        |	select
        |	*,
        |	row_number() over(partition by credit_code order by updatetime desc) as rnk
        |	from dm_gis.dm_company_dtl
        |	where credit_code is not null and credit_code != '' and length(credit_code)=18
        |	--and (business_scope REGEXP '货物运输' or
        |	--business_scope REGEXP '物流' or
        |	--business_scope REGEXP '货运' or
        |	--business_scope REGEXP '储运' or
        |	--business_scope REGEXP '快递')
        |	and reg_status_clean='1'
        |) t1
        |where rnk=1
        |""".stripMargin
    val companyInfoDf: DataFrame = spark.sql(companyInfoSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    contactInfoDf.createOrReplaceTempView("contactInfoTmp")
    companyInfoDf.createOrReplaceTempView("companyInfoTmp")
    val companyJoinContactSql=
      """
        |select
        |'' as owner_id,
        |t1.credit_code,name,company_org_type_clean,legal_person_name,content,city_adcode,source_time,type,business_scope,
        |'丰数平台' as src,
        |'' as carrier_status
        |from contactInfoTmp t1
        |join companyInfoTmp t2
        |on t1.credit_code=t2.credit_code
        |""".stripMargin
    val companyJoinContactRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, companyJoinContactSql,2000).map(obj=>{
      val name: String = obj.getString("name")
      val content: String = obj.getString("content")
      ((name,content),obj)
    }).groupByKey().map(obj=>{
      val tmpObj: JSONObject = obj._2.maxBy(json=>{
        val source_time: String = JSONUtil.getJsonValSingle(json, "source_time")
        source_time
      })
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("丰数平台数据量："+companyJoinContactRdd.count())
    contactInfoDf.unpersist()
    companyInfoDf.unpersist()
    companyJoinContactRdd
  }


  def yzCarrierConcat(spark: SparkSession, end_time: String) = {
    val yzCarrierConcatSql=
      """
        |select
        |'' as owner_id,
        |credit_code,
        |carrier_name as name,
        |org_type as company_org_type_clean,
        |contactor as legal_person_name,
        |contactor_phone as content,
        |district as city_adcode,
        |business_certificate_date as source_time,
        |case when length(contactor_phone) in(7,8) or contactor_phone like '%-%' then 'tel'
        |     when length(contactor_phone)=11 then 'mobile'
        |     else '' end as type,
        |'' as business_scope,
        |'运政' as src,
        |'' as carrier_status
        |from dm_gis.dim_ddjy_yz_carrier_concat_di
        |""".stripMargin
    val yzCarrierConcatRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, yzCarrierConcatSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("运政数据处理后数据量:"+yzCarrierConcatRdd.count())
    yzCarrierConcatRdd
  }

  def tycCarrierConcat(spark: SparkSession, end_time: String) = {
    val tycCarrierSql=
      """
        |select
        |owner_id,
        |credit_code,
        |name,
        |company_org_type_clean,
        |legal_person_name,
        |content,
        |city_adcode,
        |source_time,
        |if(length(content)<11 or content like '0%' or content like '%-%','固定电话','移动电话') type,
        |business_scope,
        |src,
        |'' as carrier_status
        |from dm_gis.ddjy_tyc_owner_info_df
        |where inc_day in(select max(inc_day) from dm_gis.ddjy_tyc_owner_info_df)
        |""".stripMargin
    val tycCarrierConcatRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, tycCarrierSql,2000).map(obj=>{
      val name: String = obj.getString("name")
      val content: String = obj.getString("content")
      ((name,content),obj)
    }).groupByKey().map(obj=>{
      val tmpObj: JSONObject = obj._2.maxBy(json=>{
        val source_time: String = JSONUtil.getJsonValSingle(json, "source_time")
        source_time
      })
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("天眼查车队数据量:"+tycCarrierConcatRdd.count())
    tycCarrierConcatRdd
  }

  def qbCarrierConcat(spark: SparkSession, end_time: String) = {
    val qbCarrierSql=
      s"""
         |select
         |'' as owner_id,
         |'' as credit_code,
         |ownername as name,
         |'' as company_org_type_clean,
         |'' as legal_person_name,
         |'' as content,
         |'' as city_adcode,
         |ss as source_time,
         |'' as type,
         |businessscopedesc as business_scope,
         |'外省情报' as src,
         |'' as carrier_status
         |from dm_gis.ddjy_qd_vehicle_owner_info_di
         |where inc_day='20230615'
         |""".stripMargin
    val qbCarrierConcatRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, qbCarrierSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("外省情报车队数据量:"+qbCarrierConcatRdd.count())
    qbCarrierConcatRdd
  }

  def carrierInfo(spark: SparkSession, end_time: String,
                  vehicleContactRdd: RDD[JSONObject],
                  companyJoinContactRdd: RDD[JSONObject],
                  yzCarrierConcatRdd: RDD[JSONObject],
                  tycCarrierConcatRdd: RDD[JSONObject],
                  qbCarrierConcatRdd: RDD[JSONObject],
                  mid_vehicle_concat_df:DataFrame,
                  qyCarrierConcatRdd:RDD[JSONObject]) = {
    import spark.implicits._
    //合并6个车队信息数据源
    val aggrSrcRdd: RDD[JSONObject] = vehicleContactRdd.map(obj => {
      obj.put("tag", 1)
      obj
    }).union(companyJoinContactRdd.map(obj => {
      obj.put("tag", 2)
      obj
    })).union(yzCarrierConcatRdd.map(obj => {
      obj.put("tag", 5)
      obj
    })).union(tycCarrierConcatRdd.map(obj => {
      obj.put("tag", 3)
      obj
    })).union(qbCarrierConcatRdd.map(obj => {
      obj.put("tag", 4)
      obj
    })).union(qyCarrierConcatRdd.map(obj => {
      obj.put("tag", 6)
      obj
    })).repartition(20000).map(obj => {
      val name: String = obj.getString("name")
      val content: String = obj.getString("content")
      ((name, content), obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.minBy(_.getString("tag"))
      val src_aggr: String = list.map(json => {
        val src: String = json.getString("src")
        src
      }).distinct.mkString(",")
      tmpObj.put("src", src_aggr)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加tag标签后的数据量:"+aggrSrcRdd.count())
    vehicleContactRdd.unpersist()
    companyJoinContactRdd.unpersist()
    yzCarrierConcatRdd.unpersist()
    tycCarrierConcatRdd.unpersist()
    qbCarrierConcatRdd.unpersist()
    qyCarrierConcatRdd.unpersist()
    val notNullContentRdd: RDD[JSONObject] = aggrSrcRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("content"))
    })
    val nullContentRdd: RDD[JSONObject] = aggrSrcRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("content"))
    }).map(obj=>{
      obj.put("flag",0)
      obj
    })
    val noSimilarPersonCntRdd: RDD[(String, JSONObject)] = notNullContentRdd.map(obj => {
      (obj.getString("content"), obj.getString("legal_person_name"))
    }).distinct().groupByKey().map(obj => {
      val tmpObj = new JSONObject()
      val noSimilarPersonCnt: Int = obj._2.toList.size
      tmpObj.put("content",obj._1)
      tmpObj.put("noSimilarPersonCnt",noSimilarPersonCnt)
      (obj._1, tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("电话号码数据量:"+noSimilarPersonCntRdd.count())
    val notNullContentMapRdd: RDD[(String, JSONObject)] = notNullContentRdd.map(obj => {
      (obj.getString("content"), obj)
    })
    val unionCarrierInfoDf: DataFrame = SparkJoin.leftOuterJoinOfLeftLeanElemJSONObject(notNullContentMapRdd, noSimilarPersonCntRdd, 20, 40)
     .map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("noSimilarPersonCnt",rightObj.getString("noSimilarPersonCnt"))
      }
      leftObj
    }).map(obj=>{
      val carrier_type: String = obj.getString("type")
      var flag=0
      val phoneNumberRegex7 = """\d*(\d)\1{6}\d*"""
      val phoneNumberRegex8 = """\d*(\d)\1{7}\d*"""
      val idCardRegex = """^\d{17}(\d|X)$"""
      if (carrier_type=="email"){
        flag=0
      }else{
        val content: String = obj.getString("content")
        val noSimilarPersonCnt: Int = obj.getIntValue("noSimilarPersonCnt")
        val content_len: Int = content.length
        if(content_len<=6 || content_len==9 || content_len==10){
          flag = 0
        }else if((content_len==7 && content.matches(phoneNumberRegex7)) || ((content_len==8 || content_len>=11) && content.matches(phoneNumberRegex8)) ){
          flag = 0
        }else if(content_len==18 && content.matches(idCardRegex)){
          flag = 0
        }else if(noSimilarPersonCnt>10){
          flag = 999
        }else{
          if (carrier_type=="mobile" || carrier_type=="移动电话"){
            flag = 3
          }else if(carrier_type=="固定电话" || carrier_type=="tel"){
            flag = 2
          }else if(carrier_type.trim==""){
            flag = 1
          }
        }
      }
      obj.put("flag",flag)
      obj
    }).union(nullContentRdd).map(obj=>{
      (
        obj.getString("owner_id"),
        obj.getString("credit_code"),
        obj.getString("name"),
        obj.getString("company_org_type_clean"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("city_adcode"),
        obj.getString("source_time"),
        obj.getString("type"),
        obj.getString("business_scope"),
        obj.getString("src"),
        obj.getString("carrier_status"),
        obj.getString("flag")
      )
    }).toDF("owner_id","credit_code","name","company_org_type_clean","legal_person_name","content","city_adcode","source_time","type","business_scope","src","carrier_status","flag")
        .repartition(1000).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("合并5个数据源并去重后数据量:"+unionCarrierInfoDf.count())
    unionCarrierInfoDf.show(10,false)
    aggrSrcRdd.unpersist()
    noSimilarPersonCntRdd.unpersist()
    unionCarrierInfoDf.createOrReplaceTempView("unionCarrierInfoTmp")
    //关联种子表数据
    val joinLastCarrierConcatSql=
      s"""
         |select
         |credit_code,t1.name,company_org_type_clean,legal_person_name,city_adcode,business_scope,content,source_time,type,src,
         |t2.owner_id as owner_id,
         |carrier_status,flag
         |from unionCarrierInfoTmp t1
         |left join
         |(
         |	select name,owner_id
         |	from dm_gis.dwd_ddjy_carrier_info_seed_copy
         |  group by name,owner_id
         |) t2
         |on t1.name=t2.name
         |""".stripMargin
    val joinLastCarrierConcatDf: DataFrame = spark.sql(joinLastCarrierConcatSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("关联种子表后数据量:"+joinLastCarrierConcatDf.count())
    unionCarrierInfoDf.unpersist()
    val nullOwneridDf: DataFrame = joinLastCarrierConcatDf.filter($"owner_id".isNull || $"owner_id"==="").toDF()
    nullOwneridDf.createOrReplaceTempView("nullOwneridTmp")
    val maxOwneridSql=
      s"""
         |select
         |max(cast (nvl(split(owner_id,'-')[1],0) as bigint)) as max_owner_id
         |from dm_gis.dwd_ddjy_carrier_info_seed_copy
         |where owner_id like 'sf-%'
         |""".stripMargin
    val max_owner_id: Long = spark.sql(maxOwneridSql).collect().head.getLong(0)
    logger.error("获取最大ownerid："+max_owner_id)
    val null_ownerid_add_sql=
      s"""
         |select
         |t3.owner_id,credit_code,t2.name,company_org_type_clean,legal_person_name,content,city_adcode,business_scope,source_time,type,src,
         |from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as create_time,flag
         |from nullOwneridTmp t2
         |left join
         |(
         |	select
         |	name,
         |	concat('sf-',rnk+$max_owner_id) as owner_id
         |	from
         |	(
         |		select
         |		name,row_number() over(order by 1) as rnk
         |		from
         |		(
         |			select
         |			name
         |			from nullOwneridTmp
         |			group by name
         |		) t4
         |	) t1
         |) t3
         |on t2.name=t3.name
         |""".stripMargin
    val nullOwneridAddDf: DataFrame = spark.sql(null_ownerid_add_sql)
    nullOwneridAddDf.createOrReplaceTempView("nullOwneridAddTmp")
    //企业库车队源数据更新车队信息种子表
    /*val companyUpdateCarrierInfoSeedTmpSql=
      """
        |insert overwrite table dm_gis.dwd_ddjy_carrier_info_seed_copy
        |select * from nullOwneridAddTmp
        |union all
        |select * from dm_gis.dwd_ddjy_carrier_info_seed_copy
        |""".stripMargin
    spark.sql(companyUpdateCarrierInfoSeedTmpSql)*/
    val companyUpdateCarrierInfoSeedSql=
      """
        |select * from nullOwneridAddTmp
        |union all
        |select * from dm_gis.dwd_ddjy_carrier_info_seed_copy
        |""".stripMargin
    spark.sql(companyUpdateCarrierInfoSeedSql)
    val carrierInfoSeedDf: DataFrame = spark.sql(companyUpdateCarrierInfoSeedSql).distinct()
    SparkWrite.writeToHiveNoPart(spark,carrierInfoSeedDf,"dm_gis.dwd_ddjy_carrier_info_seed",100)
    val notNullOwneridDf: DataFrame = joinLastCarrierConcatDf.filter($"owner_id".isNotNull && $"owner_id"=!="").toDF()
    notNullOwneridDf.show(10,false)
    notNullOwneridDf.createOrReplaceTempView("notNullOwneridTmp")
    val carrierContactSql=
      s"""
         |select
         |owner_id,credit_code,name,company_org_type_clean,legal_person_name,content,city_adcode,business_scope,source_time,type,src,
         |carrier_status,flag,
         |is_call,is_connect,is_valid_number,month_connect_cnt,agg_connect_cnt,last_call_time,is_firm_number,is_manager_number,is_win_order,update_time
         |from
         |(
         |	select
         |	owner_id,credit_code,name,company_org_type_clean,legal_person_name,content,city_adcode,business_scope,source_time,type,src,
         |	'' as carrier_status,flag
         |	from nullOwneridAddTmp
         |	union all
         |	select
         |	owner_id,credit_code,name,company_org_type_clean,legal_person_name,content,city_adcode,business_scope,source_time,type,src,
         |	'' as carrier_status,flag
         |	from notNullOwneridTmp
         |) t1
         |left join
         |(
         |	select
         |	owner_name
         |	,phone
         |	,is_call
         |	,is_connect
         |	,is_valid_number
         |	,month_connect_cnt
         |	,agg_connect_cnt
         |	,last_call_time
         |	,is_firm_number
         |	,is_manager_number
         |	,is_win_order
         |	,update_time
         |	from dm_gis.ddjy_phone_call_clue_agg_mi
         |	where inc_day in(select max(inc_day) from dm_gis.ddjy_phone_call_clue_agg_mi)
         |) t2
         |on t1.name=t2.owner_name and t1.content=t2.phone
         |""".stripMargin
    val carrierContactDf: DataFrame = spark.sql(carrierContactSql).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("车队信息数据量："+carrierContactDf.count())
    SparkWrite.writeToHive(spark,carrierContactDf,"inc_day",end_time,"dm_gis.dwd_ddjy_carrier_info_di",200)
    carrierContactDf.unpersist()
    joinLastCarrierConcatDf.unpersist()
    val companyUpdateCarrierInfoSeedTmpSql=
      """
        |insert overwrite table dm_gis.dwd_ddjy_carrier_info_seed_copy
        |select * from dm_gis.dwd_ddjy_carrier_info_seed
        |""".stripMargin
    spark.sql(companyUpdateCarrierInfoSeedTmpSql)
    //关联外省数据，写入dim_ddjy_mid_vehicle_concat_yy_df
    mid_vehicle_concat_df.createOrReplaceTempView("mid_vehicle_concat_yy_tmp")
    val tomorrow_time: String = DateUtil.getDateStr(end_time, 1, "")
    val mid_vehicle_concat_yy_sql=
      s"""
        |insert overwrite table dm_gis.dim_ddjy_mid_vehicle_concat_yy_df partition(inc_day='$tomorrow_time')
        |select
        |vehicle_no,owner_id,owner_name,province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,city_id,access_date
        |from
        |(
        |	select
        |	vehicle_no,owner_id,owner_name,province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,city_id,access_date,
        |	row_number() over(partition by vehicle_no order by access_date desc) as rnk
        |	from
        |	(
        |		select
        |		vehicleno as vehicle_no,
        |		owner_id,
        |		ownername as owner_name,
        |		nvl(province,input_province) as province_name,
        |		nvl(city,city_name) as city_name,
        |		'' as area_name,
        |		'' as area_manager_name,
        |		company_org_type_clean as org_type,
        |		credit_code,
        |		'' as manager,
        |		'' as manager_phone,
        |		legal_person_name as contactor,
        |		content as contactor_phone,
        |		businessscopedesc as owner_type,
        |		'' as city_id,
        |		certificatebegindate as access_date
        |		from
        |		(
        |			select
        |			ownername,vehicleno,input_province,businessscopedesc,certificatebegindate,city_name
        |			from dm_gis.ddjy_qd_vehicle_owner_info_di
        |			where inc_day='20230615'
        |		) t1
        |		left join
        |		(
        |			select
        |			name,owner_id,legal_person_name,content,credit_code
        |			from
        |			(
        |				select
        |				name,owner_id,legal_person_name,content,credit_code,
        |				row_number() over(partition by name order by source_time desc) as rnk
        |				from dm_gis.dwd_ddjy_carrier_info_seed_copy
        |			) t2_1
        |			where rnk=1
        |		) t2
        |		on t1.ownername=t2.name
        |		left join
        |		(
        |			select
        |			company_org_type_clean,province,city,name
        |			from
        |			(
        |				select
        |				company_org_type_clean,province,city,name,
        |				row_number() over(partition by name order by company_org_type_clean desc) as rnk
        |				from dm_gis.ddjy_tyc_nonind_owner_info_df
        |				where inc_day in(select max(inc_day) from dm_gis.ddjy_tyc_nonind_owner_info_df)
        |				and company_org_type_clean not like '%个体%'
        |				and company_org_type_clean!='个人'
        |				and company_org_type_clean!='个人经营'
        |			) t5_1
        |			where rnk=1
        |		) t5
        |		on t1.ownername=t5.name
        |		union all
        |		select
        |		vehicle_no,
        |		nvl(t7.owner_id,t6.owner_id) as owner_id,
        |		owner_name,province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,city_id,access_date
        |		from mid_vehicle_concat_yy_tmp t6
        |		left join
        |		(
        |			select
        |			name,owner_id
        |			from
        |			(
        |				select
        |				name,owner_id,
        |				row_number() over(partition by name order by source_time desc) as rnk
        |				from dm_gis.dwd_ddjy_carrier_info_seed_copy
        |			) t7_1
        |			where rnk=1
        |		) t7
        |		on t6.owner_name=t7.name
        |	) t3
        |) t4
        |where rnk=1
        |""".stripMargin
    spark.sql(mid_vehicle_concat_yy_sql)
  }

  def deptLineSf(spark: SparkSession,start_time:String, end_time: String) = {
    import spark.implicits._
    DateUtil.changeDateSep(start_time,"","-")
    val start_time2: String = DateUtil.changeDateSep(start_time,"","-")+" 00:00:00"
    val end_time2: String = DateUtil.changeDateSep(end_time,"","-")+" 23:59:59"
    val lineJoinDeptSql=
      s"""
        |select t1.*,t2.*,
        |concat('$start_time','-','$end_time') as task_batch,
        |'0' as clue_src
        |from
        |(
        |	select *
        |	from dm_gis.eta_std_line_recall1
        |	where inc_day >= '$start_time' and inc_day <= '$end_time'
        |	and plan_depart_tm >= '$start_time2' and plan_depart_tm <= '$end_time2'
        |	and carrier_type != '0' and carrier_name not like '%丰驰%' and carrier_name not like '%顺丰%'
        |	and carrier_name not in (select sf_owner from dm_gis.dim_sf_owner_df)
        |) t1
        |join
        |(
        |	select dept_code,dept_name,dept_addr,dept_type_name,dept_transfer_flag,area_name,country_name,city_name,provinct_name,belong_county,belong_county_code,longitude,latitude,delete_flg
        |	from dim.dim_department
        |	where country_name='中国大陆' and delete_flg = '0' and dept_transfer_flag = '1' and longitude != '' and latitude != ''
        |) t2
        |on t1.start_dept = t2.dept_code
        |""".stripMargin
    val lineJoinDeptDf: DataFrame = spark.sql(lineJoinDeptSql)
    //关联车队信息种子表
    lineJoinDeptDf.createOrReplaceTempView("lineJoinDeptTmp")
    val joinCarrierInfoSeedSql=
      """
        |select
        |t1.*,t2.owner_id as carrier_id
        |from lineJoinDeptTmp t1
        |left join
        |(
        |	select *
        |	from dm_gis.dwd_ddjy_carrier_info_seed_copy
        |) t2
        |on t1.carrier_name=t2.name
        |""".stripMargin
    val joinCarrierInfoSeedDf: DataFrame = spark.sql(joinCarrierInfoSeedSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("顺丰线路关联表关联车队信息种子表后的数据量："+joinCarrierInfoSeedDf.count())
    val nullCarrieridDeptLineDf: DataFrame = joinCarrierInfoSeedDf.filter("carrier_id is null").toDF()
    nullCarrieridDeptLineDf.createOrReplaceTempView("nullCarrieridDeptLineTmp")
    val maxOwneridSql=
      s"""
         |select
         |max(cast (nvl(split(owner_id,'_')[2],0) as bigint)) as max_owner_id
         |from dm_gis.dwd_ddjy_carrier_info_seed_copy
         |where owner_id like 'sf_add%'
         |""".stripMargin
    val max_owner_id: Long = spark.sql(maxOwneridSql).collect().head.getLong(0)
    logger.error("获取最大ownerid："+max_owner_id)
    val nullCarrieridAddSql=
      s"""
        |select
        |task_area_code,task_id,t1.carrier_name,task_inc_day,start_dept,start_type,line_code,vehicle_serial,actual_capacity_load,plan_depart_tm,actual_depart_tm,
        |driver_id,driver_name,is_stop,transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,log_dist,if_evaluate_time,stop_over_zone_code,end_dept,end_type,
        |plan_arrive_tm,actual_arrive_tm,line_time,line_distance,actual_run_time,duration,time,rt_dist,highwaymileage,toll_charge,pns_dist,pns_time,std_toll_charge,
        |if_error,src,conduct_type,ac_is_run_ontime,diffdist_log_rt,diffratio_log_rt,accrual_dist,accrual_dist_type,last_update_tm,main_driver_account,road_fee,
        |line_require_id,dept_code,dept_name,dept_addr,dept_type_name,dept_transfer_flag,area_name,country_name,city_name,provinct_name,belong_county,longitude,latitude,
        |delete_flg,t3.owner_id as carrier_id,
        |belong_county_code
        |from nullCarrieridDeptLineTmp t1
        |left join
        |(
        |	select
        |	carrier_name,
        |	concat('sf_add_',rnk+$max_owner_id) as owner_id
        |	from
        |	(
        |		select
        |		carrier_name,
        |		row_number() over(order by 1) as rnk
        |		from nullCarrieridDeptLineTmp
        |		group by carrier_name
        |	) t2
        |) t3
        |on t1.carrier_name=t3.carrier_name
        |""".stripMargin
    val nullCarrieridAddDf: DataFrame = spark.sql(nullCarrieridAddSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("关联车队信息种子表之后空carrier_id的数据量："+nullCarrieridAddDf.count())
    nullCarrieridAddDf.createOrReplaceTempView("nullCarrieridAddTmp")
    //顺丰线路数据更新车队信息种子表
    val lineUpdateCarrierInfoSeedSql=
    """
      |insert overwrite table dm_gis.dwd_ddjy_carrier_info_seed
      |select
      |carrier_id as owner_id
      |,'' as credit_code
      |,carrier_name as name
      |,'' as company_org_type_clean
      |,'' as legal_person_name
      |,'' as content
      |,'' as city_adcode
      |,'' as business_scope
      |,'' as source_time
      |,'' as type
      |,'' as src
      |,from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as create_time
      |,'' as flag
      |from nullCarrieridAddTmp
      |union
      |select * from dm_gis.dwd_ddjy_carrier_info_seed_copy
      |""".stripMargin
    spark.sql(lineUpdateCarrierInfoSeedSql)
    val lineUpdateCarrierInfoSeedTestSql=
      """
        |insert overwrite table dm_gis.dwd_ddjy_carrier_info_seed_copy
        |select * from dm_gis.dwd_ddjy_carrier_info_seed
        |""".stripMargin
    spark.sql(lineUpdateCarrierInfoSeedTestSql)
    //生成顺丰任务明细表dwd_ddjy_dept_line_sf_di
    val notNullCarrieridDeptLineDf: DataFrame = joinCarrierInfoSeedDf
      .filter("carrier_id is not null")
      .select("task_area_code","task_id","carrier_name","task_inc_day","start_dept","start_type","line_code","vehicle_serial","actual_capacity_load","plan_depart_tm","actual_depart_tm","driver_id","driver_name","is_stop","transoport_level","carrier_type","plf_flag","vehicle_type","axls_number","log_dist","if_evaluate_time","stop_over_zone_code","end_dept","end_type","plan_arrive_tm","actual_arrive_tm","line_time","line_distance","actual_run_time","duration","time","rt_dist","highwaymileage","toll_charge","pns_dist","pns_time","std_toll_charge","if_error","src","conduct_type","ac_is_run_ontime","diffdist_log_rt","diffratio_log_rt","accrual_dist","accrual_dist_type","last_update_tm","main_driver_account","road_fee","line_require_id","dept_code","dept_name","dept_addr","dept_type_name","dept_transfer_flag","area_name","country_name","city_name","provinct_name","belong_county","longitude","latitude","delete_flg","carrier_id","belong_county_code")
      .toDF()
    val addCarrieridDeptLineDf: DataFrame = notNullCarrieridDeptLineDf.union(nullCarrieridAddDf).toDF()
    addCarrieridDeptLineDf.createOrReplaceTempView("addCarrieridDeptLineTmp")
    val notContainsSlashRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, addCarrieridDeptLineDf).filter(obj => {
      val city_name: String = obj.getString("city_name")
      !city_name.contains("/")
    })
    val deptLineSfDf: DataFrame = SparkUtils.getDfToJson(spark, addCarrieridDeptLineDf).filter(_.getString("city_name").contains("/")).map(obj => {
      val city_name_arr: Array[String] = obj.getString("city_name").split("/")
      val dept_addr: String = obj.getString("dept_addr")
      val tmpArr = new ArrayBuffer[String]()
      for (elem <- city_name_arr) {
        if (dept_addr.contains(elem)) {
          tmpArr.append(elem)
        }
      }
      if (tmpArr.nonEmpty) {
        val city_name: String = tmpArr(0)
        obj.put("city_name", city_name)
        obj.put("city_name_tag","0")
      }
      obj
    }).filter(_.getString("city_name_tag") != null).union(notContainsSlashRdd).map(obj => {
      obj.put("clue_src", "0")
      val task_batch: String = start_time + "-" + end_time
      obj.put("task_batch", task_batch)
      DeptLineSf(
        obj.getString("task_area_code"),
        obj.getString("task_id"),
        obj.getString("carrier_name"),
        obj.getString("task_inc_day"),
        obj.getString("start_dept"),
        obj.getString("start_type"),
        obj.getString("line_code"),
        obj.getString("vehicle_serial"),
        obj.getString("actual_capacity_load"),
        obj.getString("plan_depart_tm"),
        obj.getString("actual_depart_tm"),
        obj.getString("driver_id"),
        obj.getString("driver_name"),
        obj.getString("is_stop"),
        obj.getString("transoport_level"),
        obj.getString("carrier_type"),
        obj.getString("plf_flag"),
        obj.getString("vehicle_type"),
        obj.getString("axls_number"),
        obj.getString("log_dist"),
        obj.getString("if_evaluate_time"),
        obj.getString("stop_over_zone_code"),
        obj.getString("end_dept"),
        obj.getString("end_type"),
        obj.getString("plan_arrive_tm"),
        obj.getString("actual_arrive_tm"),
        obj.getString("line_time"),
        obj.getString("line_distance"),
        obj.getString("actual_run_time"),
        obj.getString("duration"),
        obj.getString("time"),
        obj.getString("rt_dist"),
        obj.getString("highwaymileage"),
        obj.getString("toll_charge"),
        obj.getString("pns_dist"),
        obj.getString("pns_time"),
        obj.getString("std_toll_charge"),
        obj.getString("if_error"),
        obj.getString("src"),
        obj.getString("conduct_type"),
        obj.getString("ac_is_run_ontime"),
        obj.getString("diffdist_log_rt"),
        obj.getString("diffratio_log_rt"),
        obj.getString("accrual_dist"),
        obj.getString("accrual_dist_type"),
        obj.getString("last_update_tm"),
        obj.getString("main_driver_account"),
        obj.getString("road_fee"),
        obj.getString("line_require_id"),
        obj.getString("dept_code"),
        obj.getString("dept_name"),
        obj.getString("dept_addr"),
        obj.getString("dept_type_name"),
        obj.getString("dept_transfer_flag"),
        obj.getString("area_name"),
        obj.getString("country_name"),
        obj.getString("city_name"),
        obj.getString("provinct_name"),
        obj.getString("belong_county"),
        obj.getString("longitude"),
        obj.getString("latitude"),
        obj.getString("delete_flg"),
        obj.getString("task_batch"),
        obj.getString("clue_src"),
        obj.getString("carrier_id"),
        obj.getString("belong_county_code")
      )
    }).distinct().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dept_line_sf表数据量："+deptLineSfDf.count())
    deptLineSfDf.createOrReplaceTempView("deptLineSfTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_dept_line_sf_di partition(inc_day='$end_time') select * from deptLineSfTmp")
  }

  def qyCarrierConcat(spark: SparkSession, end_time: String) = {
    val last_seven_day: String = DateUtil.getDateStr(end_time, -7, "")
    val qyCarrierConcatSql=
      s"""
        |select
        |t1.owner_id,
        |credit_code,
        |name,
        |company_org_type_clean,
        |legal_person_name,
        |content,
        |city_adcode,
        |source_time,
        |type,
        |business_scope,
        |'企业大数据' as src,
        |'' as carrier_status
        |from dm_gis.ddjy_dim_carrier_company_info_df t1
        |left join
        |(
        |	select
        |	owner_id,company_org_type_clean,legal_person_name,city_adcode,source_time,business_scope
        |	from
        |	(
        |		select
        |		owner_id,company_org_type_clean,legal_person_name,city_adcode,source_time,business_scope,
        |		row_number() over(partition by owner_id order by legal_person_name desc) as rnk
        |		from dm_gis.dwd_ddjy_carrier_info_di
        |		where inc_day='${last_seven_day}'
        |	) t2_1
        |	where rnk=1
        |) t2
        |on t1.owner_id=t2.owner_id
        |""".stripMargin
    val qyCarrierConcatRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, qyCarrierConcatSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("企业大数据车队数据量:"+qyCarrierConcatRdd.count())
    qyCarrierConcatRdd
  }

  def main(args: Array[String]): Unit = {
    if (args.length != 2) {
      logger.error(
        """
          |需要输入2个参数：
          |    start_time、end_time
          |""".stripMargin)
      sys.exit(-1)
    }
    // 接收外部传递进来的变量
    val start_time: String = args(0)
    val end_time: String = args(1)
    logger.error(s"开始日期:$start_time 结束日期:$end_time")
    // 创建spark
    val spark: SparkSession = Spark.getSparkSession(className,null,false)
    //读取粤运车辆源数据并处理
    val (vehicleContactRdd,mid_vehicle_concat_df) = vehicleConcatYyProcess(spark, end_time)
    //读取联系方式表和企业工商信息表生成CarrierContact表
    val companyJoinContactRdd: RDD[JSONObject] = carrierContact(spark, end_time)
    //读取运政系统车队数据表dim_ddjy_yz_carrier_concat_di
    val yzCarrierConcatRdd: RDD[JSONObject] = yzCarrierConcat(spark, end_time)
    //读取天眼查车队数据
    val tycCarrierConcatRdd: RDD[JSONObject] = tycCarrierConcat(spark, end_time)
    //读取外省情报数据
    val qbCarrierConcatRdd: RDD[JSONObject] = qbCarrierConcat(spark, end_time)
    //读取企业大数据表
    val qyCarrierConcatRdd: RDD[JSONObject] = qyCarrierConcat(spark, end_time)
    //拼接5份数据并去重生成carrierInfo表
    carrierInfo(spark, end_time,vehicleContactRdd,companyJoinContactRdd,yzCarrierConcatRdd,tycCarrierConcatRdd,qbCarrierConcatRdd,mid_vehicle_concat_df,qyCarrierConcatRdd)
    logger.error("运行结束！")
    //生成顺丰任务明细表
    deptLineSf(spark,start_time,end_time)
    // 程序运行结束,关闭spark
    spark.stop()
  }
  case class DeptLineSf(
                         task_area_code:String,
                         task_id:String,
                         carrier_name:String,
                         task_inc_day:String,
                         start_dept:String,
                         start_type:String,
                         line_code:String,
                         vehicle_serial:String,
                         actual_capacity_load:String,
                         plan_depart_tm:String,
                         actual_depart_tm:String,
                         driver_id:String,
                         driver_name:String,
                         is_stop:String,
                         transoport_level:String,
                         carrier_type:String,
                         plf_flag:String,
                         vehicle_type:String,
                         axls_number:String,
                         log_dist:String,
                         if_evaluate_time:String,
                         stop_over_zone_code:String,
                         end_dept:String,
                         end_type:String,
                         plan_arrive_tm:String,
                         actual_arrive_tm:String,
                         line_time:String,
                         line_distance:String,
                         actual_run_time:String,
                         duration:String,
                         time:String,
                         rt_dist:String,
                         highwaymileage:String,
                         toll_charge:String,
                         pns_dist:String,
                         pns_time:String,
                         std_toll_charge:String,
                         if_error:String,
                         src:String,
                         conduct_type:String,
                         ac_is_run_ontime:String,
                         diffdist_log_rt:String,
                         diffratio_log_rt:String,
                         accrual_dist:String,
                         accrual_dist_type:String,
                         last_update_tm:String,
                         main_driver_account:String,
                         road_fee:String,
                         line_require_id:String,
                         dept_code:String,
                         dept_name:String,
                         dept_addr:String,
                         dept_type_name:String,
                         dept_transfer_flag:String,
                         area_name:String,
                         country_name:String,
                         city_name:String,
                         provinct_name:String,
                         belong_county:String,
                         longitude:String,
                         latitude:String,
                         delete_flg:String,
                         task_batch:String,
                         clue_src:String,
                         carrier_id:String,
                         belong_county_code:String
                       )
}
