package app

import common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.{DateUtil, SparkUtils}

/**
 *需求名称：GIS-RSS-DDJY：【吨吨加油】聚合线索工艺需求_V1.2_01405644_李相志
 *需求方：周韵筹(01425211)
 *研发： 蔡国房(01420395)
 *任务创建时间：20231204
 *任务id：衡度平台
 **/
object DdjyClueCircleRsltDiMonth extends DataSourceCommon {

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkUtils.getSparkSession(className,"yarn")
    //获取T-1日期
    val inc_day: String = args(0)
    //取T-14日期,
    val last_thrity_day = DateUtil.getdaysBefore(inc_day, -29, "yyyyMMdd", "yyyyMMdd")


    val tableName = "dm_gis.dwd_ddjy_clue_circle_rslt_di_month"

    val dwdDdjyClueCircleRsltDiDF = getdwdDdjyClueCircleRsltDi(spark, last_thrity_day, inc_day)

    val dm_ddjy_clue_rel_carrier_di_month_sql =
      s"""
         |
         |	select
         |	circle_id,
         |	count(distinct carrier_id) as carrier_count
         |	from
         |	(
         |		select
         |		clue_id,carrier_id
         |		from dm_gis.dm_ddjy_clue_rel_carrier_di_month
         |		where inc_day='${inc_day}'
         |	) t3
         |	join
         |	(
         |		select
         |		clue_id,circle_id
         |		from dm_gis.dm_ddjy_cluepoint_rlst_di_month
         |		where inc_day='${inc_day}'
         |	) t4 on t3.clue_id=t4.clue_id
         |	group by circle_id
         |
         |""".stripMargin


    val dm_ddjy_clue_rel_carrier_di_month_DF = spark.sql(dm_ddjy_clue_rel_carrier_di_month_sql)


    val dm_ddjy_clue_rel_car_di_month_sql =
      s"""
         |
         |	select
         |	circle_id,
         |	count(distinct vehicle) as vehicle_count
         |	from
         |	(
         |		select
         |		clue_id,vehicle
         |		from dm_gis.dm_ddjy_clue_rel_car_di_month
         |		where inc_day='${inc_day}'
         |	) t4
         |	join
         |	(
         |		select
         |		clue_id,circle_id
         |		from dm_gis.dm_ddjy_cluepoint_rlst_di_month
         |		where inc_day='${inc_day}'
         |	) t5
         |	on t4.clue_id=t5.clue_id
         |	group by circle_id
         |
         |
         |
         |
         |""".stripMargin


    val dm_ddjy_clue_rel_car_di_month_DF = spark.sql(dm_ddjy_clue_rel_car_di_month_sql)


    val dwd_ddjy_clue_rel_gas_station_di_month_sql =
      s"""
         |
         |	select
         |	circle_id,
         |	count(distinct gas_id) as gas_count
         |	from
         |	(
         |		select
         |		clue_id,gas_id
         |		from dm_gis.dwd_ddjy_clue_rel_gas_station_di_month
         |		where inc_day='${inc_day}'
         |	) t7
         |	join
         |	(
         |		select
         |		clue_id,circle_id
         |		from dm_gis.dm_ddjy_cluepoint_rlst_di_month
         |		where inc_day='${inc_day}'
         |	) t8
         |	on t7.clue_id=t8.clue_id
         |	group by circle_id
         |
         |
         |""".stripMargin


    val dwd_ddjy_clue_rel_gas_station_di_month_DF = spark.sql(dwd_ddjy_clue_rel_gas_station_di_month_sql)


    val dwd_ddjy_clue_rel_gas_station_di_month_sql1 =
      s"""
         |
         |	select
         |	circle_id,
         |	count(distinct if(gas_type=0,gas_id,null)) as national_gas_count,
         |	count(distinct if(gas_type=1,gas_id,null)) as private_gas_count
         |	from
         |	(
         |		select
         |		gas_id,clue_id,gas_type
         |		from dm_gis.dwd_ddjy_clue_rel_gas_station_di_month
         |		where inc_day='${inc_day}'
         |	) t12
         |	join
         |	(
         |		select
         |		clue_id,circle_id
         |		from dm_gis.dm_ddjy_cluepoint_rlst_di_month
         |		where inc_day='${inc_day}'
         |	) t13
         |	on t12.clue_id=t13.clue_id
         |	group by circle_id
         |
         |
         |
         |""".stripMargin

    val dwd_ddjy_clue_rel_gas_station_di_month_DF1 = spark.sql(dwd_ddjy_clue_rel_gas_station_di_month_sql1)


    //总查询
    val resultDF = dwdDdjyClueCircleRsltDiDF.join(dm_ddjy_clue_rel_carrier_di_month_DF, Seq("circle_id"), "left")
      .join(dm_ddjy_clue_rel_car_di_month_DF, Seq("circle_id"), "left")
      .join(dwd_ddjy_clue_rel_gas_station_di_month_DF, Seq("circle_id"), "left")
      .join(dwd_ddjy_clue_rel_gas_station_di_month_DF1, Seq("circle_id"), "left")


    val dwd_ddjy_clue_circle_rslt_di_max_sql =
      s"""
         |
         |	select
         |	substr (max(task_batch), 10,17) as max_task_batch,
         |	substr (min(task_batch), 0,8) as min_task_batch
         |	from  dm_gis.dwd_ddjy_clue_circle_rslt_di
         |	where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}'
         |
         |""".stripMargin
    import spark.implicits._

    logger.error(dwd_ddjy_clue_circle_rslt_di_max_sql)
    val dwd_ddjy_clue_circle_rslt_di_max_max_DF = spark.sql(dwd_ddjy_clue_circle_rslt_di_max_sql)

    val max_task_batch_df = dwd_ddjy_clue_circle_rslt_di_max_max_DF.withColumn("task_batch", concat('min_task_batch, lit("-"), 'max_task_batch))
    val max_task_batch = max_task_batch_df.takeAsList(1).get(0).getAs[String]("task_batch")

    logger.error("max_task_batch " + max_task_batch)


    val dm_ddjy_cluepoint_rlst_di_month_sql  =
      s"""
         |
         | select  row_number()over(partition by circle_id  order by task_count desc ) rn ,  circle_id , clue_name from  dm_gis.dm_ddjy_cluepoint_rlst_di_month  where inc_day in (select max(inc_day) from dm_gis.dm_ddjy_cluepoint_rlst_di_month)
         |
         |""".stripMargin

    val dm_ddjy_cluepoint_rlst_di_month_DF = spark.sql(dm_ddjy_cluepoint_rlst_di_month_sql)

    val dm_ddjy_cluepoint_rlst_di_month_clue_name_DF  = dm_ddjy_cluepoint_rlst_di_month_DF.filter('rn ===1 ).select('circle_id, 'clue_name)


    val resultDF1 = resultDF.join(dm_ddjy_cluepoint_rlst_di_month_clue_name_DF, Seq("circle_id"), "left")
      .withColumn("national_gas_count", nanvl('national_gas_count, lit(0)))
      .withColumn("private_gas_count", nanvl('private_gas_count, lit(0)))
      .withColumn("update_time", lit(from_unixtime(unix_timestamp(), "yyyy-MM-dd HH:mm:ss")))
      .withColumn("circle_name", 'clue_name)
      .withColumn("task_batch", lit(max_task_batch))
      .withColumn("inc_day", lit(inc_day))
      .select('circle_id
        , 'task_batch
        , 'adcode
        , 'province
        , 'city
        , 'district
        , 'x
        , 'y
        , 'task_count
        , 'carrier_count
        , 'vehicle_count
        , 'task_day_count
        , 'plan_depart_tm_day_max
        , 'plan_depart_tm_day_min
        , 'dis_sum
        , 'task_count_per_day
        , 'dis_sum_per_day
        , 'oil_sum
        , 'oil_sum_per_day
        , 'vehicle_distribution
        , 'gas_count
        , 'national_gas_count
        , 'private_gas_count
        , 'update_time
        , 'circle_name
        , 'main_gas_count
        , 'main_gas_online_count
        , 'main_carrier_count
        , 'main_carrier_vehicle_count
        , 'main_carrier_online_count
        , 'main_carrier_online_vehicle_count
        , 'biz_day
        , 'inc_day
      )




    //数据存dm表
    writeToHive(spark, resultDF1, Seq("inc_day"), tableName)

  }

  // 获取集散圈数据
  def getdwdDdjyClueCircleRsltDi(sparkSession: SparkSession, last_thrity_day: String, inc_day: String): DataFrame = {

    //从dm_gis.dwd_ddjy_clue_circle_rslt_di表中 取当前分区及往前三个分区的数据
    //获取以下字段，并按照circle_id字段去重，保留 inc_day 最新的一条数据
    //circle_id，adcode，province，city，main_gas_online_count，x，y，inc_day
    val dwd_ddjy_clue_circle_rslt_di_sql =
    s"""
       |			select
       |			circle_id,adcode stay_adcode,province stay_province,city stay_city,district stay_district,x center_x, y center_y,inc_day as biz_day,
       |			sum(task_count) over(partition by circle_id) as task_count,
       |			'' as plan_depart_tm_day_max,
       |			'' as plan_depart_tm_day_min,
       |			'' as dis_sum,
       |			'' as dis_sum_per_day,
       |			row_number() over(partition by circle_id order by inc_day desc) as rnk
       |			from dm_gis.dwd_ddjy_clue_circle_rslt_di
       |			where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}'
       |""".stripMargin

    logger.error("dwd_ddjy_clue_circle_rslt_di_sql :" + dwd_ddjy_clue_circle_rslt_di_sql)

    import sparkSession.implicits._
    val dwd_ddjy_clue_circle_rslt_di_DF = sparkSession.sql(dwd_ddjy_clue_circle_rslt_di_sql).filter('rnk===1).repartition(2000)



    //获取
    val dwd_ddjy_clue_circle_rslt_di_task_day_count_sql =
      s"""
         |		select
         |    circle_id,
         |    sum(task_day_count) as task_day_count
         |    from
         |    (
         |      select
         |        circle_id,
         |        max(task_day_count) as task_day_count
         |        from dm_gis.dwd_ddjy_clue_circle_rslt_di
         |        where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}'
         |    group by circle_id,inc_day
         |    ) t11_1
         |    group by circle_id
         |""".stripMargin

    logger.error("dwd_ddjy_clue_circle_rslt_di_task_day_count_sql :" + dwd_ddjy_clue_circle_rslt_di_task_day_count_sql)

    val dwd_ddjy_clue_circle_rslt_di_task_day_count_DF = sparkSession.sql(dwd_ddjy_clue_circle_rslt_di_task_day_count_sql)




    //新增main_gas_count，main_gas_online_count字段 dm_gis.dwd_ddjy_clue_gas_di

    val dwd_ddjy_clue_gas_di_sql =
      s"""
         |		select
         |   gas_circle_id
         |  ,t0.poiid
         |  ,cooperateStatus
         |		from
         |		(select poiid,gas_circle_id from  dm_gis.dwd_ddjy_clue_gas_di where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}' ) t0
         |		left join
         |		(select cooperateStatus,poiid from  dm_gis.dm_ddjy_gas_station_info_di where delFlag=0 ) t1 on  t0.poiid  = t1.poiid
         |""".stripMargin

    logger.error("dwd_ddjy_clue_gas_di_sql :" + dwd_ddjy_clue_gas_di_sql)


    val dwd_ddjy_clue_gas_di_DF = sparkSession.sql(dwd_ddjy_clue_gas_di_sql)


    val dwd_ddjy_clue_gas_di_DF1 = dwd_ddjy_clue_gas_di_DF
    val  dwd_ddjy_clue_gas_di_rdd_main_gas = dwd_ddjy_clue_gas_di_DF1.rdd.map(row  =>{
      val gas_circle_id = row.getAs[String]("gas_circle_id")
      val poiid = row.getAs[String]("poiid")
      val rowkey = gas_circle_id+"_"+poiid
      (rowkey, row)
    }).reduceByKey((x,y) => {
      y
    }).map(x =>{
      val gas_circle_id =  x._2.getAs[String]("gas_circle_id")
      (gas_circle_id,1)
    }).reduceByKey((x,y) => {
      x+y
    })
    val dwd_ddjy_clue_gas_di_df_main_gas =  sparkSession.createDataset(dwd_ddjy_clue_gas_di_rdd_main_gas)
      .toDF("gas_circle_id","main_gas_count").select('gas_circle_id.as("circle_id"),'main_gas_count)
      .distinct()



    val  dwd_ddjy_clue_gas_di_rdd_main_gas_online = dwd_ddjy_clue_gas_di_DF1.rdd.filter(row=>{
      val  cooperateStatus =  row.getAs[String]("cooperateStatus")
      "2".equalsIgnoreCase(cooperateStatus) || "3".equalsIgnoreCase(cooperateStatus)

    }).map(row  =>{
      val gas_circle_id = row.getAs[String]("gas_circle_id")
      val poiid = row.getAs[String]("poiid")
      val rowkey = gas_circle_id +"_" + poiid
      (rowkey, row)
    }).reduceByKey((x,y) => {
      x
    }).map(x =>{
      val gas_circle_id =  x._2.getAs[String]("gas_circle_id")
      (gas_circle_id,1)
    }).reduceByKey((x,y) => {
      x+y
    })
    val dwd_ddjy_clue_gas_di_df_main_gas_online =  sparkSession.createDataset(dwd_ddjy_clue_gas_di_rdd_main_gas_online)
      .toDF("gas_circle_id","main_gas_online_count").select('gas_circle_id.as("circle_id"),'main_gas_online_count)


    //新增 main_carrier_count , main_carrier_vehicle_count 字段


    val dwd_ddjy_clue_vehicle_carrier_di_sql =
      s"""
         |
         |		select distinct t0.carrier_id, vehicle ,carrier_circle_id, case when  t1.name is null then  0 else 1 end carrier_status
         |
         |		from (select  * from  dm_gis.dwd_ddjy_clue_vehicle_carrier_di  where inc_day>='${last_thrity_day}' and inc_day<='${inc_day}') t0
         |
         |		left join
         |
         |		(select  * from  dm_gis.ddjy_ods_dim_team_info   where  inc_day  = '${inc_day}' and  del_flag = '0' and  name is not null ) t1
         |
         |		on t0.carrier_name = t1.name
         |
         |
         |""".stripMargin


    val dwd_ddjy_clue_vehicle_carrier_di_df = sparkSession.sql(dwd_ddjy_clue_vehicle_carrier_di_sql)


    val  dwd_ddjy_clue_gas_di_rdd_main_gas_1 = dwd_ddjy_clue_vehicle_carrier_di_df.rdd.map(row  =>{
      val carrier_circle_id = row.getAs[String]("carrier_circle_id")
      val carrier_id = row.getAs[String]("carrier_id")
      val rowkey = carrier_circle_id + "_" + carrier_id
      (rowkey, row)
    }).reduceByKey((x,y) => {
      x
    }).map(x =>{
      val carrier_circle_id =  x._2.getAs[String]("carrier_circle_id")
      (carrier_circle_id,1)
    }).reduceByKey((x,y)=>{
      x+y
    }
    )

    val dwd_ddjy_clue_gas_di_df_main_gas_1 =  sparkSession.createDataset(dwd_ddjy_clue_gas_di_rdd_main_gas_1)
      .toDF("carrier_circle_id","main_carrier_count").select('carrier_circle_id.as("circle_id"),'main_carrier_count)



    val  dwd_ddjy_clue_gas_di_rdd_main_gas_2 = dwd_ddjy_clue_vehicle_carrier_di_df.rdd.map(row  =>{
      val carrier_circle_id = row.getAs[String]("carrier_circle_id")
      val vehicle = row.getAs[String]("vehicle")
      val rowkey = carrier_circle_id +"_" +vehicle
      (rowkey, row)
    }).reduceByKey((x,y) => {
      x
    }).map(x =>{
      val carrier_circle_id =  x._2.getAs[String]("carrier_circle_id")
      (carrier_circle_id,1)
    }).reduceByKey((x,y) => {
      x+y
    })

    val dwd_ddjy_clue_gas_di_df_main_gas_2 =  sparkSession.createDataset(dwd_ddjy_clue_gas_di_rdd_main_gas_2)
      .toDF("carrier_circle_id","main_carrier_vehicle_count").select('carrier_circle_id.as("circle_id"),'main_carrier_vehicle_count)




    val  dwd_ddjy_clue_gas_di_rdd_main_gas_31 = dwd_ddjy_clue_vehicle_carrier_di_df.rdd
      .filter(row  =>{
        val carrier_status = row.getAs[Int]("carrier_status")
        1==carrier_status
      })

    val  dwd_ddjy_clue_gas_di_rdd_main_gas_3 = dwd_ddjy_clue_gas_di_rdd_main_gas_31
      .map(row  =>{
        val carrier_circle_id = row.getAs[String]("carrier_circle_id")
        val carrier_id = row.getAs[String]("carrier_id")
        val rowkey = carrier_circle_id + "_" + carrier_id
        (rowkey, row)
      }).reduceByKey((x,y) => {
      x
    }).map(x =>{
      val carrier_circle_id =  x._2.getAs[String]("carrier_circle_id")
      (carrier_circle_id,1)
    }).reduceByKey((x,y) => {
      x+y
    })
    val dwd_ddjy_clue_gas_di_df_main_gas_3 =  sparkSession.createDataset(dwd_ddjy_clue_gas_di_rdd_main_gas_3)
      .toDF("carrier_circle_id","main_carrier_online_count").select('carrier_circle_id.as("circle_id"),'main_carrier_online_count)


    val  dwd_ddjy_clue_gas_di_rdd_main_gas_4 = dwd_ddjy_clue_gas_di_rdd_main_gas_31
      .map(row  =>{
        val carrier_circle_id = row.getAs[String]("carrier_circle_id")
        val vehicle = row.getAs[String]("vehicle")

        val rowkey = carrier_circle_id + "_" + vehicle
        (rowkey, row)
      }).reduceByKey((x,y) => {x
    }).map(x =>{
      val carrier_circle_id =  x._2.getAs[String]("carrier_circle_id")
      (carrier_circle_id,1)
    }).reduceByKey((x,y) => {x+y
    })
    val dwd_ddjy_clue_gas_di_df_main_gas_4 =  sparkSession.createDataset(dwd_ddjy_clue_gas_di_rdd_main_gas_4)
      .toDF("carrier_circle_id","main_carrier_online_vehicle_count").select('carrier_circle_id.as("circle_id"),'main_carrier_online_vehicle_count)


    val result_df_t1 = dwd_ddjy_clue_circle_rslt_di_DF
      .join(dwd_ddjy_clue_circle_rslt_di_task_day_count_DF, Seq("circle_id"), "left")
      .join(dwd_ddjy_clue_gas_di_df_main_gas, Seq("circle_id"), "left")
      .join(dwd_ddjy_clue_gas_di_df_main_gas_online, Seq("circle_id"), "left")
      .join(dwd_ddjy_clue_gas_di_df_main_gas_1, Seq("circle_id"), "left")
      .join(dwd_ddjy_clue_gas_di_df_main_gas_2, Seq("circle_id"), "left")
      .join(dwd_ddjy_clue_gas_di_df_main_gas_3, Seq("circle_id"), "left")
      .join(dwd_ddjy_clue_gas_di_df_main_gas_4, Seq("circle_id"), "left")


    val result_df_t2 = result_df_t1
      .withColumn("main_carrier_count", when('main_carrier_count.isNull,lit(0)).otherwise('main_carrier_count))
      .withColumn("main_carrier_vehicle_count",  when('main_carrier_vehicle_count.isNull,lit(0)).otherwise('main_carrier_vehicle_count))
      .withColumn("main_carrier_online_count",  when('main_carrier_online_count.isNull,lit(0)).otherwise('main_carrier_online_count))
      .withColumn("main_carrier_online_vehicle_count",  when('main_carrier_online_vehicle_count.isNull,lit(0)).otherwise('main_carrier_online_vehicle_count))
      .withColumn("main_gas_online_count",  when('main_gas_online_count.isNull,lit(0)).otherwise('main_gas_online_count))
      .select(
        'circle_id
        , 'stay_adcode
        , 'stay_province
        , 'stay_city
        , 'stay_district
        , 'center_x
        , 'center_y
        , 'task_count
        , 'task_day_count
        , 'plan_depart_tm_day_max
        , 'plan_depart_tm_day_min
        , 'dis_sum
        , 'dis_sum_per_day
        , 'rnk
        , 'main_gas_count
        , 'main_gas_online_count
        , 'biz_day
        , 'main_carrier_count
        , 'main_carrier_vehicle_count
        , 'main_carrier_online_count
        , 'main_carrier_online_vehicle_count
      )
    result_df_t2.show(1, false)

    val result_df_t3 = result_df_t2
      .withColumn("adcode", 'stay_adcode)
      .withColumn("province", 'stay_province)
      .withColumn("city", 'stay_city)
      .withColumn("district", 'stay_district)
      .withColumn("x", 'center_x)
      .withColumn("y", 'center_y)
      .withColumn("task_count_per_day", when(round('task_count / 'task_day_count, 0) === 0, 1).otherwise(round('task_count / 'task_day_count)))
      .withColumn("oil_sum", 'task_count * 202)
      .withColumn("oil_sum_per_day", 'task_count * 202 / 7)
      .withColumn("vehicle_distribution", lit(""))


      .select(
        'circle_id,
        'adcode,
        'province,
        'city,
        'district,
        'x,
        'y,
        'task_count,
        'task_day_count,
        'plan_depart_tm_day_max,
        'plan_depart_tm_day_min,
        'dis_sum,
        'task_count_per_day,
        'dis_sum_per_day,
        'oil_sum,
        'oil_sum_per_day,
        'vehicle_distribution,
        'main_gas_count,
        'main_gas_online_count,
        'main_carrier_count,
        'main_carrier_vehicle_count,
        'main_carrier_online_count,
        'main_carrier_online_vehicle_count,
        'biz_day
      )

    result_df_t3.repartition(2000)
  }

}