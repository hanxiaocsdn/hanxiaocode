package app

import java.{lang, util}

import com.alibaba.fastjson.JSONObject
import com.github.davidmoten.rtree.RTree
import com.github.davidmoten.rtree.geometry.{Geometries, Geometry}
import com.sf.gis.java.base.util.{DistanceUtils, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.commons.codec.digest.DigestUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{PointArea, SparkWrite}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks

/**
 * @Description:油站加油场景挖掘
 * 需求人员：刘芮 01412988
 * @Author:lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:569
 * 任务名称：油站加油场景挖掘
 * 依赖任务：250 粤运车辆轨迹中间表导入ods_track_yy_di
 * 数据源：ods_track_yy_di
 * 调用服务地址：
 * 数据结果：ddjy_vehicle_suspect_way_info_di
 */
object StationRefuelingSceneMining{
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def stationInterface(spark: SparkSession, incDay: String) = {
    val stationUrl="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0&adcode=1:440000&excludeDel=1"
    //val payload="{}"
    //val headers="{}"
    //val finalUrl: String = stationUrl.format(payload,headers)
    val retObj: JSONObject = HttpInvokeUtil.httpGetJSON(stationUrl,3)
    val data = retObj.getJSONArray("data").toArray()
    val finalStationInfoRdd: RDD[JSONObject] = spark.sparkContext.parallelize(data).map(obj=>{
      val tmpObj: JSONObject = obj.asInstanceOf[JSONObject]
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取油站数据量："+finalStationInfoRdd.count())
    finalStationInfoRdd
  }
  def splitNation(nationFileArray: Array[JSONObject]) = {
    var maxlng = 0.0
    var maxlat = 0.0
    var minlng = 99999999.0
    var minlat = 99999999.0
    for(index <- 0 until nationFileArray.size){
      val item = nationFileArray(index)
      val tmpMinlng: Double = item.getDoubleValue("minlng")
      val tmpMaxlng: Double = item.getDoubleValue("maxlng")
      val tmpMinlat: Double = item.getDoubleValue("minlat")
      val tmpMaxlat: Double = item.getDoubleValue("maxlat")

      if(tmpMaxlng > maxlng){
        maxlng = tmpMaxlng
      }
      if(tmpMaxlat > maxlat){
        maxlat = tmpMaxlat
      }
      if(tmpMinlng < minlng){
        minlng = tmpMinlng
      }
      if(tmpMinlat < minlat){
        minlat = tmpMinlat
      }
    }
    val splitMap = new util.HashMap[(String,String,String,String),ArrayBuffer[JSONObject]]()
    //1342  30 50 1154 9 585  8 605
    val maxSplitCnt = 9
    val increaseLng = (maxlng-minlng)/maxSplitCnt
    val increaseLat = (maxlat-minlat)/maxSplitCnt
    for(i <- 0 to maxSplitCnt){
      for(j<- 0 to maxSplitCnt){
        val minSplitLng = (j)*increaseLng+minlng
        val minSplitLat = (i)*increaseLat+minlat
        val maxSplitLng = (j+1)*increaseLng+minlng
        var maxSplitLat = (i+1)*increaseLat+minlat
        val tmpArrayBuffer = new ArrayBuffer[JSONObject]()
        splitMap.put((minSplitLng.toString,minSplitLat.toString,maxSplitLng.toString,maxSplitLat.toString),tmpArrayBuffer)
      }
    }
    val key = splitMap.keySet().toArray()
    for(index <- 0 until nationFileArray.size){
      val item = nationFileArray(index)
      val tmpMinlng: Double = item.getDoubleValue("minlng")
      val tmpMaxlng: Double = item.getDoubleValue("maxlng")
      val tmpMinlat: Double = item.getDoubleValue("minlat")
      val tmpMaxlat: Double = item.getDoubleValue("maxlat")
      val tmpArray = Array((tmpMinlat,tmpMinlng),(tmpMinlat,tmpMaxlng),(tmpMaxlat,tmpMaxlng),(tmpMaxlat,tmpMinlng))
      for (i <- 0 until key.size) {
        //50米边界范围的四个点，只要其中一个在里面就添加到网格里面
        val coordinateLoop = new Breaks
        coordinateLoop.breakable {
          for (j <- tmpArray.indices) {
            val (tmpLat, tmpLng) = tmpArray(j)
            val (minSplitLng: String, minSplitLat: String, maxSplitLng: String, maxSplitLat: String) = key(i)
            if (tmpLat >= minSplitLat.toDouble && tmpLng >= minSplitLng.toDouble
              && tmpLat <= maxSplitLat.toDouble && tmpLng <= maxSplitLng.toDouble
            ) {
              splitMap.get(key(i)).append(item)
              coordinateLoop.break()
            }
          }
        }

      }
    }
    splitMap
  }
  def loadByRTree(nationFileArray: Array[JSONObject]) = {
    var tree:RTree[(Int,Double,Double,String), Geometry] = RTree.star.minChildren(3)
      .maxChildren(6).create.asInstanceOf[RTree[(Int,Double,Double,String), Geometry]]
    for(i<- nationFileArray.indices){
      val item = nationFileArray(i)
      val minlng: lang.Double = item.getDouble("minlng")
      val minlat: lang.Double = item.getDouble("minlat")
      val maxlng: lang.Double = item.getDouble("maxlng")
      val maxlat: lang.Double = item.getDouble("maxlat")
      tree = tree.add((i,item.getDouble("lng"),item.getDouble("lat"),item.getString("POIID")),Geometries.rectangle(minlng, minlat, maxlng, maxlat))
    }
    val tree_size: Int = tree.size()
    logger.error("tree_size:"+tree_size)
    tree
  }
  def calculateStayData(spark: SparkSession, finalStationInfoRdd: RDD[JSONObject],stationSquareRdd:RDD[JSONObject],incDay:String, last_one_day: String,car_no_filter:String,insertType:String) = {
    import spark.implicits._
    val last_seven_day = DateUtil.getDateStr(incDay, -7, "")
    val stationSquareArray: Array[JSONObject] = stationSquareRdd.collect()
    logger.error("stationSquare："+stationSquareArray.size)
    //val nationFileMap: util.HashMap[(String, String, String, String), ArrayBuffer[JSONObject]] = splitNation(stationSquareArray)
    //val nationTreeArray = loadByRTree(stationSquareArray)
    /*val array: Array[((String, String, String, String), String, Int)] = nationFileMap.map(obj => {
      val key: (String, String, String, String) = obj._1
      val value: String = obj._2.toList.map(json => {
        val stationName: String = json.getString("stationName")
        val lng: String = json.getString("lng")
        val lat: String = json.getString("lat")
        (stationName, lng, lat)
      }).mkString(";")
      val size: Int = obj._2.toList.size
      (key, value, size)
    }).toArray
    val stationDf: DataFrame = spark.sparkContext.parallelize(array).toDF("square", "station_info", "size")
    stationDf.createOrReplaceTempView("stationTmp")
    spark.sql(s"insert overwrite table dm_gis.station_square_info_di select * from stationTmp")*/
    val station_minlng: Double = stationSquareArray.minBy(_.getDoubleValue("minlng")).getDoubleValue("minlng")
    val station_maxlng: Double = stationSquareArray.maxBy(_.getDoubleValue("maxlng")).getDoubleValue("maxlng")
    val station_minlat: Double = stationSquareArray.minBy(_.getDoubleValue("minlat")).getDoubleValue("minlat")
    val station_maxlat: Double = stationSquareArray.maxBy(_.getDoubleValue("maxlat")).getDoubleValue("maxlat")
    //val stationSquareBC: Broadcast[RTree[(Int, Double, Double, String), Geometry]] = spark.sparkContext.broadcast(nationTree)
    val trackSql=
      s"""
         |select
         |*
         |from dm_gis.ods_track_yy_di
         |where inc_day='$incDay'
         |and tm>=unix_timestamp(concat('$last_seven_day',' 00:00:00'),'yyyyMMdd HH:mm:ss')
         |and tm<=unix_timestamp(concat('$incDay',' 00:00:00'),'yyyyMMdd HH:mm:ss') and $car_no_filter
         |""".stripMargin
    val trackDf: DataFrame = spark.sql(trackSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(trackSql)
    logger.error("轨迹信息数据量："+trackDf.count())
    val filterMidTrackRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, trackDf, 1000).mapPartitions(it=>{
      val nationTreeArray = loadByRTree(stationSquareArray)
      it.map(obj => {
        val lng: Double = obj.getDoubleValue("lng")
        val lat: Double = obj.getDoubleValue("lat")
        //val nationTreeArray: RTree[(Int, Double, Double, String), Geometry] = stationSquareBC.value
        val entries = nationTreeArray.search(Geometries.point(lng, lat)).toList().toBlocking().single()
        if (lng >= station_minlng && lng <= station_maxlng && lat >= station_minlat && lat <= station_maxlat) {
          if (entries.size() > 0) {
            val entry = entries.get(0)
            val POIID: String = entry.value()._4
            val station_lng: Double = entry.value()._2
            val station_lat: Double = entry.value()._3
            obj.put("coordinate_tag", 1)
            obj.put("POIID", POIID)
            obj.put("station_lng", station_lng)
            obj.put("station_lat", station_lat)
          }
        } else {
          obj.put("coordinate_tag", 0)
        }
        (obj.getString("car_no"), obj)
      })
    }).filter(obj => {
      //obj._2.getIntValue("coordinate_tag")!=0
      obj._2.getIntValue("coordinate_tag") == 1
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤轨迹后数据量："+filterMidTrackRdd.count()+s",范围为$last_seven_day 和 $last_one_day 之间")
    val frame: DataFrame = filterMidTrackRdd.groupByKey().map(obj => {
      val car_no: String = obj._1
      val size: Int = obj._2.size
      (car_no, size)
    }).toDF()
    SparkWrite.writeToHiveNoPart(spark,frame,"dm_gis.ddjy_track_scene_mining_tmp")
    val coordinateTagRdd: RDD[util.ArrayList[JSONObject]] = filterMidTrackRdd
      .groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getString("tm"))
      val tmpArray = new ArrayBuffer[util.ArrayList[JSONObject]]()
      var tmpList = new util.ArrayList[JSONObject]()
      for (i <- list.indices) {
        if (list.length==1){
          tmpList.append(list(i))
          tmpArray.append(tmpList)
        } else if (i < list.length - 1 && list.length!=1) {
          val tm_i: Int = list(i).getIntValue("tm")
          val tm_j: Int = list(i + 1).getIntValue("tm")
          if (tm_j-tm_i < 600) {
            tmpList.append(list(i))
          }else{
            tmpList.append(list(i))
            tmpArray.append(tmpList)
            tmpList=new util.ArrayList[JSONObject]()
          }
        } else {
          val tm_i: Int = list(i-1).getIntValue("tm")
          val tm_j: Int = list(i).getIntValue("tm")
          if (tm_j-tm_i < 600) {
            tmpList.append(list(i))
            tmpArray.append(tmpList)
          }else{
            tmpArray.append(tmpList)
            tmpList=new util.ArrayList[JSONObject]()
            tmpList.append(list(i))
            tmpArray.append(tmpList)
          }
        }
      }
      tmpArray.toIterator
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("打是否在油站50m范围内的标签并分组后的数据量："+coordinateTagRdd.count())
    //value.take(20).foreach(println(_))
    val addIdRdd: RDD[JSONObject] = coordinateTagRdd
      .flatMap(obj => {
        val tmpArray = new ArrayBuffer[JSONObject]()
        if (obj.toList.nonEmpty) {
          val tm: String = obj.toList.minBy(_.getString("tm")).getLongValue("tm").toString
          val id: String = DigestUtils.md2Hex(tm)
          for (elem <- obj.toList) {
            val car_no: String = elem.getString("car_no")
            elem.put("id", car_no + id)
            tmpArray.append(elem)
          }
        }
        tmpArray.toIterator
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加id后的数据量："+addIdRdd.count())
    //value1.take(20).foreach(println(_))
    val stayInfoRdd: RDD[JSONObject] = addIdRdd
      .map(obj=>{
      (obj.getString("id"),obj)
    }).groupByKey().map(obj=>{
      val end_time: Long = obj._2.toList.maxBy(_.getString("tm")).getLongValue("tm")
      val start_time: Long = obj._2.toList.minBy(_.getString("tm")).getLongValue("tm")
      val interval: Long = (end_time - start_time) / 60
      val list: List[JSONObject] = obj._2.toList.map(json => {
        val station_lng: Double = json.getDoubleValue("station_lng")
        val station_lat: Double = json.getDoubleValue("station_lat")
        val lng: Double = json.getDoubleValue("lng")
        val lat: Double = json.getDoubleValue("lat")
        val dist_i: Double = DistanceUtils.getDistance(station_lng, station_lat, lng, lat)
        json.put("dist_i", dist_i)
        json
      })
      val dist_sum: Double = list.map(json => {
        val dist_i: Double = json.getDoubleValue("dist_i")
        dist_i
      }).sum
      val dist: Double = dist_sum / (list.size)
      val poiid: String = list.maxBy(_.getString("tm")).getString("POIID")
      val car_no: String = list.maxBy(_.getString("tm")).getString("car_no")
      val tmpObj = new JSONObject()
      val id: String = obj._1

      tmpObj.put("id", id)
      tmpObj.put("car_no", car_no)
      tmpObj.put("poiid", poiid)
      tmpObj.put("start_time", start_time)
      tmpObj.put("end_time", end_time)
      tmpObj.put("interval", interval)
      tmpObj.put("dist", dist)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("计算各个轨迹区间的停留信息数据量："+stayInfoRdd.count())
    val stayInfoDf: DataFrame = stayInfoRdd.map(obj => {
      (
        obj.getString("id"),
        obj.getString("car_no"),
        obj.getString("poiid"),
        obj.getString("start_time"),
        obj.getString("end_time"),
        obj.getString("interval"),
        obj.getString("dist")
      )
    }).toDF("id", "car_no", "poiid", "start_time", "end_time", "interval", "dist")
    //stayInfoDf.createOrReplaceTempView("stayInfoTmp")
    //spark.sql(s"insert into table dm_gis.ddjy_mid_stay_info_di partition(inc_day='$last_one_day') select * from stayInfoTmp")
    val updateWayInfoRdd: RDD[(String, JSONObject)] = stayInfoRdd.map(obj => {
      val car_no: String = obj.getString("car_no")
      val poiid: String = obj.getString("poiid")
      ((car_no, poiid), obj)
    }).groupByKey().flatMap(obj => {
      var list: List[JSONObject] = obj._2.toList.sortBy(_.getString("start_time"))
      for (i <- list.indices) {
        if (i < list.length - 1) {
          val end_time: Long = list(i).getLongValue("end_time")
          val start_time: Long = list(i + 1).getLongValue("start_time")
          if ((start_time - end_time) < 600) {
            val list_j: JSONObject = list(i + 1)
            val id: String = list(i).getString("id")
            list_j.put("id", id)
            list = list.updated(i + 1, list_j)
          }
        }
      }
      list.toIterator
    }).map(obj => {
      (obj.getString("id"), obj)
    }).groupByKey().map(obj => {
      val tmpObj = new JSONObject()
      val id: String = obj._1
      val car_no: String = obj._2.toList.maxBy(_.getString("end_time")).getString("car_no")
      val poiid: String = obj._2.toList.maxBy(_.getString("end_time")).getString("poiid")
      val end_time: Long = obj._2.toList.maxBy(_.getString("end_time")).getLongValue("end_time")
      val start_time: Long = obj._2.toList.minBy(_.getString("start_time")).getLongValue("start_time")
      val interval: Double = (end_time - start_time) / 60
      val dist_sum: Double = obj._2.map(json => {
        val dist: Double = json.getDoubleValue("dist")
        dist
      }).sum
      val dist: Double = dist_sum / (obj._2.size)
      tmpObj.put("id", id)
      tmpObj.put("car_no", car_no)
      tmpObj.put("poiid", poiid)
      tmpObj.put("start_time", start_time)
      tmpObj.put("end_time", end_time)
      tmpObj.put("interval", interval)
      tmpObj.put("dist", dist)
      tmpObj
    }).filter(_.getDoubleValue("interval")>3)
      .map(obj=>{
        (obj.getString("poiid"),obj)
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("更新油站周边停留信息数据量："+updateWayInfoRdd.count())
    val stationMapRdd: RDD[(String, JSONObject)] = finalStationInfoRdd.map(obj => {
      (obj.getString("POIID"), obj)
    })
    val vehicleWayInfoDf: DataFrame = updateWayInfoRdd.leftOuterJoin(stationMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      val stationName: String = rightObj.getString("stationName")
      val province: String = rightObj.getString("province")
      val city: String = rightObj.getString("city")
      val district: String = rightObj.getString("district")
      val lng: String = rightObj.getString("lng")
      val lat: String = rightObj.getString("lat")
      val cooperateStatus: String = rightObj.getString("cooperateStatus")
      val GRPID: String = rightObj.getString("GRPID")
      val PID: String = rightObj.getString("PID")
      val srcId: String = rightObj.getString("srcId")
      val start_time: Long = leftObj.getLongValue("start_time")
      val end_time: Long = leftObj.getLongValue("end_time")
      val start_time_new: String = DateUtil.longToTime(start_time * 1000, "yyyy-MM-dd HH:mm:ss")
      val end_time_new: String = DateUtil.longToTime(end_time * 1000, "yyyy-MM-dd HH:mm:ss")
      leftObj.put("start_time",start_time_new)
      leftObj.put("end_time",end_time_new)
      leftObj.put("stationName", stationName)
      leftObj.put("province", province)
      leftObj.put("city", city)
      leftObj.put("district", district)
      leftObj.put("lng", lng)
      leftObj.put("lat", lat)
      leftObj.put("cooperateStatus", cooperateStatus)
      leftObj.put("grpid", GRPID)
      leftObj.put("pid", PID)
      leftObj.put("srcid", srcId)
      leftObj
    }).map(obj => {
      VehicleSuspectWay(
        obj.getString("poiid"),
        obj.getString("stationName"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperateStatus"),
        obj.getString("car_no"),
        obj.getString("start_time"),
        obj.getString("end_time"),
        obj.getString("interval"),
        obj.getString("dist"),
        obj.getString("grpid"),
        obj.getString("pid"),
        obj.getString("srcid")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("车辆疑似加油停留数据量："+vehicleWayInfoDf.count())
    vehicleWayInfoDf.createOrReplaceTempView("vehicleWayInfoTmp")
    spark.sql(s"insert $insertType table dm_gis.ddjy_vehicle_suspect_way_info_di partition(inc_day='$last_one_day') select * from vehicleWayInfoTmp")
  }

  def getStationArea(spark: SparkSession, finalStationInfoRdd: RDD[JSONObject], incDay: String) = {
    val stationSquareRdd: RDD[JSONObject] = finalStationInfoRdd.map(obj => {
      try{
        val lng: Double = obj.getDouble("lng")
        val lat: Double = obj.getDouble("lat")
        val minMaxSquare: ((Double, Double), (Double, Double)) = PointArea.getQuyu50(lng, lat,0.05)
        val minlng: Double = minMaxSquare._1._1
        val minlat: Double = minMaxSquare._1._2
        val maxlng: Double = minMaxSquare._2._1
        val maxlat: Double = minMaxSquare._2._2
        obj.put("minlng", minlng)
        obj.put("minlat", minlat)
        obj.put("maxlng", maxlng)
        obj.put("maxlat", maxlat)
      } catch {
        case _: Exception =>
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取正方形区域后数据量："+stationSquareRdd.count())
    stationSquareRdd
  }


  def execute(incDay: String,car_no_filter:String,insert:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val last_one_day = DateUtil.getDateStr(incDay, -1, "")
    //获取全量油站
    val finalStationInfoRdd: RDD[JSONObject] = stationInterface(spark, last_one_day)
    //计算油站周边50m区间经纬度
    val stationSquareRdd: RDD[JSONObject] = getStationArea(spark, finalStationInfoRdd, last_one_day)
    //获取落入区间的轨迹点，计算停留数据
    calculateStayData(spark, finalStationInfoRdd,stationSquareRdd,incDay, last_one_day,car_no_filter,insert:String)

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    var car_no_filter: String = args(1)
    if(car_no_filter.contains("and")){
      val arr: Array[String] = car_no_filter.split("and")
      car_no_filter = arr(0) + " and " + arr(1)
    }
    val insert= args(2)
    car_no_filter = car_no_filter.replaceAll("大于",">").replaceAll("小于","<")
    execute(incDay,car_no_filter,insert)
    logger.error("======>>>>>>StationRefuelingSceneMining Execute Ok")
  }
  case class VehicleSuspectWay(
                                poiid:String,
                                stationName:String,
                                province:String,
                                city:String,
                                district:String,
                                lng:String,
                                lat:String,
                                cooperateStatus:String,
                                car_no:String,
                                start_time:String,
                                end_time:String,
                                interval:String,
                                dist:String,
                                grpid:String,
                                pid:String,
                                srcid:String
                              )
}
