package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.control.Breaks

/**
 * @Description:车队转化异常
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 17:21 2022/9/30
 * 任务id:215
 * 任务名称：吨吨加油-车队转化异常表
 * 依赖任务：车队报表 447
 * 数据源：ddjy_dim_holiday_legal_cn_yi、ddjy_uimp_dm_station_order_car_team_report
 * 调用服务地址：
 * 数据结果：ddjy_uimp_dm_car_team_conversion_exception
 */
object TeamConversionException {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  /**
   * 读取车队报表数据，并关联法定节假日维表
   * @param spark
   * @param inc_day
   */
  def readSourceData(spark: SparkSession, inc_day: String) = {

    //读取法定节假日数据
    var end_date: String = DateUtil.changeDateSep(inc_day, "", "-")
    val holidaySql=
      s"""
         |select *
         |from dm_gis.ddjy_dim_holiday_legal_cn_yi
         |where date<='$end_date'
         |""".stripMargin
    val holidayDf: DataFrame = spark.sql(holidaySql)
    val holidayArray: Array[(String, String)] = holidayDf.orderBy(holidayDf("date").desc).rdd.map(obj=>{
      (obj.getString(0),obj.getString(1))
    }).collect()
    var dateTag=0
    var start_date=""
    val dateLoop = new Breaks
    dateLoop.breakable{
      for (i <- holidayArray.indices){
        val date: String = holidayArray(i)._1
        //logger.error("date:"+date)
        val holiday_legal_cn: String = holidayArray(i)._2
        if (holiday_legal_cn=="非法定节假日"){
          dateTag+=1
          if (dateTag==2){
            start_date=date
            dateLoop.break()
          }
        }
      }
    }
    //logger.error("start_date:"+start_date+",end_date:"+end_date)
    //根据车队聚合最近非法定节假日的2天订单数据，然后关联昨日、近3日、近7日的订单数据
    var yesterday: String = DateUtil.getDateStr(end_date, 0, "-")
    var last_three_day: String = DateUtil.getDateStr(end_date, -2, "-")
    var last_seven_day: String = DateUtil.getDateStr(end_date, -6, "-")
    start_date = DateUtil.changeDateSep(start_date,"-","")
    end_date = DateUtil.changeDateSep(end_date,"-","")
    yesterday = DateUtil.changeDateSep(yesterday,"-","")
    last_three_day = DateUtil.changeDateSep(last_three_day,"-","")
    last_seven_day = DateUtil.changeDateSep(last_seven_day,"-","")
    val stationSql=
      s"""
         |select
         |from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |t3.car_team_name,
         |nvl(recharge_money,0.00) as recharge_money,
         |recharge_time,
         |nvl(total_amount,0.00) as total_amount,
         |nvl(yesterday_valid_order_cnt,0) as yesterday_valid_order_cnt,
         |nvl(threedays_valid_order_cnt,0) as threedays_valid_order_cnt,
         |nvl(sevendays_valid_order_cnt,0) as sevendays_valid_order_cnt,
         |t3.team_id
         |from
         |(
         |	select
         |	t1.car_team_name,recharge_money,recharge_time,total_amount,t1.team_id
         |	from
         |	(
         |		select car_team_name,team_id,
         |		split(max(concat(`date`,';',total_amount)),';')[1] as total_amount,
         |		split(max(concat(recharge_time,';',recharge_money)),';')[1] as recharge_money,
         |		split(max(concat(recharge_time,';',recharge_money)),';')[0] as recharge_time,
         |    min(min_recharge_time) as min_recharge_time
         |		from dm_gis.ddjy_uimp_dm_station_order_car_team_report
         |		where inc_day<='$inc_day'
         |		group by car_team_name,team_id
         |	) t1
         |	left join
         |	(
         |		select car_team_name,team_id,
         |		sum(pay_success) as pay_success
         |		from dm_gis.ddjy_uimp_dm_station_order_car_team_report
         |		where inc_day>='$start_date' and inc_day<='$end_date'
         |		group by car_team_name,team_id
         |	) t2
         |	on t1.team_id=t2.team_id
         |	where total_amount>0 and (pay_success = 0 or pay_success is null) and substr(min_recharge_time,0,10) <=from_unixtime(unix_timestamp('$last_three_day','yyyyMMdd'),'yyyy-MM-dd')
         |) t3
         |left join
         |(
         |	select car_team_name,team_id,
         |	sum(pay_success) as yesterday_valid_order_cnt
         |	from dm_gis.ddjy_uimp_dm_station_order_car_team_report
         |	where inc_day='$yesterday'
         |	group by car_team_name,team_id
         |) t4
         |on t3.team_id=t4.team_id
         |left join
         |(
         |	select car_team_name,team_id,
         |	sum(pay_success) as threedays_valid_order_cnt
         |	from dm_gis.ddjy_uimp_dm_station_order_car_team_report
         |	where inc_day>='$last_three_day' and inc_day<='$end_date'
         |	group by car_team_name,team_id
         |) t5
         |on t3.team_id=t5.team_id
         |left join
         |(
         |	select car_team_name,team_id,
         |	sum(pay_success) as sevendays_valid_order_cnt
         |	from dm_gis.ddjy_uimp_dm_station_order_car_team_report
         |	where inc_day>='$last_seven_day' and inc_day<='$end_date'
         |	group by car_team_name,team_id
         |) t6
         |on t3.team_id=t6.team_id
         |""".stripMargin
    //logger.error(stationSql)
    val sourceDf: DataFrame = spark.sql(stationSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //logger.error("根据车队聚合最近非法定节假日的2天以及关联昨日、近3日、近7日有效订单量后数据量："+sourceDf.count())
    sourceDf
  }


  def insertHiveTable(spark: SparkSession, sourceDf: DataFrame, inc_day: String) = {
    sourceDf.repartition(1).createOrReplaceTempView("tmpResult")
    spark.sql(s"insert overwrite table dm_gis.ddjy_uimp_dm_car_team_conversion_exception partition(inc_day='$inc_day') select * from tmpResult")
  }

  def execute(inc_day: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    val sourceDf: DataFrame = readSourceData(spark, inc_day)
    insertHiveTable(spark,sourceDf,inc_day)
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>TeamConversionException Execute Ok")
  }
}
