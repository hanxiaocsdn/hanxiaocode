package app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 16:09 2022/6/8
 */
object IcMergePointParse {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readStreetAndTimestampData(spark: SparkSession,start_day:String,end_day:String,filter_day:String) = {
    logger.error("过滤数据的日期:"+filter_day)
    val ic_sql=
      s"""
        |select
        |*
        |from dm_gis.insurance_model_duration_dist_daily_qgzh_kafka
        |where  inc_day>='$start_day' and inc_day<='$end_day'
        |""".stripMargin
    val filterRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, ic_sql, 4000).filter(obj => {
      val log: JSONObject = obj.getJSONObject("log")
      val dataType: String = log.getString("dataType")
      val time: String = log.getString("time")
      obj.put("time",time)
      dataType == "dundun"
    }).persist(StorageLevel.DISK_ONLY)
    val addTimeRdd: RDD[JSONObject] = filterRdd.flatMap(obj => {
      val log: JSONObject = obj.getJSONObject("log")
      val data: String = log.getString("data")
      val dataArray: JSONArray = JSON.parseArray(data)
      val array = new ArrayBuffer[JSONObject]()
      if (dataArray.nonEmpty){
        for (i <- 0 until(dataArray.size())) {
          val tmpObj: JSONObject = dataArray.getJSONObject(i)
          array.append(tmpObj)
        }
      }
      array.iterator()
    }).filter(obj=>{
      val cmp_partition: String = obj.getString("cmp_partition").split("_")(1)
      cmp_partition>=s"$filter_day"
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("聚集点和车辆疑似停留油站数据总量:"+addTimeRdd.count())
    logger.error("车辆疑似经停油站数据")
    val oilHookCarRdd: RDD[JSONObject] = addTimeRdd.filter(_.getString("data_src") == "oilHookCar")
    oilHookCarRdd.take(10).foreach(println(_))
    logger.error("车辆聚集点数据")
    val carAggrRdd: RDD[JSONObject] = addTimeRdd.filter(_.getString("data_src") != "oilHookCar")
    carAggrRdd.take(10).foreach(println(_))
    (oilHookCarRdd,carAggrRdd)
  }

  def insertHiveTable(spark: SparkSession, carAggrRdd: RDD[JSONObject],oilHookCarRdd: RDD[JSONObject],start_day:String) = {
    import spark.implicits._
    val filter_day: String = DateUtil.getDateStr(start_day, -2, "")
    val carAggrDf: DataFrame = carAggrRdd.map(obj => {
      (
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        "",
        obj.getString("agr_gh"),
        "",
        "",
        obj.getString("type"),
        "IC",
        obj.getString("cmp_partition").replace("YY_","")
      )
    }).toDF("agr_id","agr_cnt","agr_dis","agr_tm","agr_lng","agr_lat","agr_dis2sp","agr_gh","agr_rs_id","agr_rs_cnt","type","data_src","cmp_partition")
    carAggrDf.createOrReplaceTempView("carAggrTmp")
    spark.sql(
      s"""
         |insert overwrite table dm_gis.dwd_ddjy_mid_track_ic_dm_sgl_di partition(cmp_partition)
         |select
         |agr_id,agr_cnt,agr_dis,agr_tm,agr_lng,agr_lat,agr_dis2sp,agr_gh,agr_rs_id,agr_rs_cnt,type,data_src,cmp_partition
         |from
         |(
         |	select * from carAggrTmp
         |	union all
         |	select * from dm_gis.dwd_ddjy_mid_track_ic_dm_sgl_di where cmp_partition>='$filter_day'
         |) t1
         |group by agr_id,agr_cnt,agr_dis,agr_tm,agr_lng,agr_lat,agr_dis2sp,agr_gh,agr_rs_id,agr_rs_cnt,type,data_src,cmp_partition
         |""".stripMargin)
    logger.error("车辆聚集点数据写入完成！！！")

    val oilHookCarDf: DataFrame = oilHookCarRdd.map(obj => {
      (
        obj.getString("agr_gh"),
        obj.getString("agr_cnt"),
        obj.getString("agr_id").split("_")(0),
        obj.getString("data_src"),
        obj.getString("type"),
        obj.getString("cmp_partition").split("_")(1)
      )
    }).toDF("poiid","frequency_tl","car_no","data_src","type","inc_day")
    oilHookCarDf.createOrReplaceTempView("oilHookCarTmp")

    spark.sql(
      s"""
         |insert overwrite table dm_gis.ddjy_vehicle_suspect_way_info_ic_di partition(inc_day)
         |select
         |poiid,frequency_tl,car_no,data_src,type,inc_day
         |from
         |(
         |	select * from oilHookCarTmp
         |	union all
         |	select * from dm_gis.ddjy_vehicle_suspect_way_info_ic_di where inc_day>='$filter_day'
         |) t1
         |group by poiid,frequency_tl,car_no,data_src,type,inc_day
         |""".stripMargin)
    logger.error("车辆疑似停留油站数据写入完成！！！")
  }

  def execute(start_day:String,end_day:String,filter_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    val (oilHookCarRdd,carAggrRdd) = readStreetAndTimestampData(spark,start_day,end_day,filter_day)
    insertHiveTable(spark,carAggrRdd,oilHookCarRdd,start_day)


  }

  def main(args: Array[String]): Unit = {
    val start_day: String = args(0)
    val end_day: String = args(1)
    val filter_day: String = args(2)
    execute(start_day,end_day,filter_day)
    logger.error("======>>>>>>IcMergePointToHive Execute Ok")
  }

}
