package app

import java.sql.{Connection, DriverManager, PreparedStatement, ResultSet}

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql._
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel

/**
 * @Description:原始油站信息表mysql导入hive
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 10:46 2022/12/8
 * 任务id:198
 * 任务名称：原始油站信息表mysql导入hive
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：ddjy_ods_dim_station_info
 */
object StationInfoToHive {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def mysqlToHive(spark: SparkSession, mysqlTable: String,hiveTable:String,inc_day: String,mysqlDatabase:String,source:String,insertType:String): Unit = {
    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = s"jdbc:mysql://admin-m.dbdr.sfcloud.local:3306/$mysqlDatabase?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val userName = "bdpetl"
    val passWd = "bdp#etl@0922"
    val tableName=
      s"""
         |(select
         |id
         |,petrol_station_name
         |,station_code
         |,petrol_resources
         |,petrol_type
         |,province_name
         |,city_name
         |,city_code
         |,area_name
         |,address_name
         |,x
         |,y
         |,ST_asWkt(geom) as geom
         |,country_price
         |,sale_price
         |,ft_sale_price
         |,ft_cost_price
         |,discount_price
         |,petrol_station_status
         |,business_hours
         |,invoice_desc
         |,petrol_station_pic
         |,petrol_station_qualify
         |,settle_model
         |,discount_model
         |,enable_flag
         |,outside_driver_desc
         |,create_date
         |,create_by
         |,update_time
         |,update_by
         |,del_flag
         |,org_id
         |,bank_account
         |,bank_account_name
         |,open_bank
         |,open_place
         |,inter_bank_no
         |,corp_name
         |,tax_no
         |,register_address_phone
         |,opening_bank_account
         |,linkman_name
         |,linkman_phone
         |,fixed_phone
         |,maintain_begin_time
         |,maintain_end_time
         |,fill_oil_end_time
         |,CAST(is_balance_warn_send AS SIGNED)  AS is_balance_warn_send
         |,CAST(account_prop AS SIGNED)  AS account_prop
         |,CAST(is_corp_account AS SIGNED)  AS is_corp_account
         |,org_name
         |,corp_id
         |,CAST(pay_mode AS SIGNED)  AS pay_mode
         |,shell_station_code
         |,brand
         |,business_status
         |,grpid
         |,'' as tuanyou_gas_id
         |,station_type
         |,third_gas_id
         |,pay_type
         |,'$source'
         |,fleet_free_price
         |,station_free_price
         |,main_corp_info_id
         |,pay_oil_fee_type
         |,road_class
         |,gas_location_type
         |,road_name
         |,third_gas_enable
         |from $mysqlTable) as t
         |""".stripMargin
    logger.error(s"开始读取MySQL:$mysqlTable 表中数据")
    val orignal_df: DataFrame = spark
      .read
      .format("jdbc")
      .option("encoding","utf-8")
      .option("url", url)
      .option("user", userName)
      .option("password", passWd)
      .option("dbtable", tableName)
      .option("driver", driver)
      .option("numPartitions", 2)
      .option("fetchsize", 100000)
      .option("batchsize", 100000)
      .load().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站信息数据量："+orignal_df.count())
    orignal_df.show(10,false)
    // 存到hive备份
    val tempView=s"$mysqlTable"+"_tmp"
    orignal_df.createOrReplaceTempView(tempView)
    spark.sql(s"insert $insertType table $hiveTable partition(inc_day='$inc_day') select * from $tempView")
  }
  def execute(inc_day: String, mysqlTable: String, hiveTable: String,mysqlDatabase:String,source:String,insertType:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    mysqlToHive(spark,mysqlTable,hiveTable,inc_day,mysqlDatabase,source,insertType)
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val mysqlTable: String = args(1)
    val hiveTable: String = args(2)
    val mysqlDatabase: String = args(3)
    val source: String = args(4)
    val insertType: String = args(5)
    execute(inc_day,mysqlTable,hiveTable,mysqlDatabase,source,insertType)
    //execute()
    logger.error("======>>>>>>StationInfoToHive Execute Ok")
  }

}
