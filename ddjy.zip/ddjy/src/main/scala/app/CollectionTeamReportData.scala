package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:车队报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:447
 * 任务名称：车队报表
 * 依赖任务：每日-原始钱包历史交易明细表mysql导入hive 500、每日-车队历史充值记录表 498、每日-原始钱包信息表mysql导入hive 499、每日-原始车队信息过滤表 501、订单支付时间重分区表 387
 * 数据源：ddjy_dim_team_info_filter、ddjy_dwd_station_order_pay_repartition_di、ddjy_ods_dim_wallet、ddjy_ods_wallet_history、ddjy_dwd_car_team_history_recharge
 * 调用服务地址：无
 * 数据结果：ddjy_uimp_dm_station_order_car_team_report
 */
object CollectionTeamReportData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String) = {
    val car_team_df: DataFrame = spark.sql(
      s"""
         |
         |select
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |'' as car_team_name,
         |province,city,
         |pay_success,
         |'' as pay_fail,
         |'' as order_timeout,
         |'' as order_close,
         |'' as order_cancell,
         |'' as carplate_cnt,
         |'' as station_cnt,
         |'' as oil_mass,
         |'' as ft_sale_money,
         |'' as ft_profit,
         |round(trade_amount,2) as trade_amount,
         |round(total_amount,2) as total_amount,
         |round(recharge_money,2) as recharge_money,
         |recharge_time,
         |min_recharge_time,
         |'' as hour_time,
         |dd_update_time,
         |nvl(t10.team_id,t11.team_id) as team_id
         |from
         |(
         |	select
         |	id as team_id,name as car_team_name,province,city,pay_success,trade_amount,total_amount,dd_update_time
         |	from
         |	(
         |		select *
         |		from dm_gis.ddjy_dim_team_info_filter
         |		where inc_day='${inc_day}'
         |	) t8
         |	left join
         |	(
         |		select
         |		nvl(t6.car_team_id,t7.user_id) as car_team_id,
         |		pay_success,total_amount,trade_amount,dd_update_time
         |		from
         |		(
         |			select
         |			car_team_id,
         |			count(distinct order_sn) as pay_success,
         |			max(update_date) as dd_update_time
         |			from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |			where inc_day='${inc_day}'
         |			and order_status=2
         |			group by car_team_id
         |		) t6
         |		full join
         |		(
         |			select
         |			user_id,
         |			split(max(concat(t1.wallet_date,'\001',total_amount)),'\001')[1] as total_amount,
         |			sum(trade_amount) as trade_amount
         |			from
         |			(
         |				select *,from_unixtime(unix_timestamp(inc_day,'yyyyMMdd'),'yyyy-MM-dd') as wallet_date
         |				from dm_gis.ddjy_ods_dim_wallet
         |				where inc_day='${inc_day}'
         |				and account_type=10
         |				and user_type=2
         |			) t1
         |			left join
         |			(
         |				select trade_amount,wallet_id
         |				from dm_gis.ddjy_ods_wallet_history
         |				where inc_day='${inc_day}'
         |				and inoutcome_type = 1
         |                and trade_type = 1
         |			) t2
         |			on t1.id=t2.wallet_id
         |			group by t1.user_id
         |		) t7
         |		on t6.car_team_id=t7.user_id
         |	) t9
         |	on t8.id=t9.car_team_id
         |) t10
         |full join
         |(
         |	select
         |	team_id,
         |	split(max(concat(trade_time,'\001',trade_amount)),'\001')[1] as recharge_money,
         |	split(max(concat(trade_time,'\001',trade_amount)),'\001')[0] as recharge_time,
         |	min(trade_time) as min_recharge_time
         |	from dm_gis.ddjy_dwd_car_team_history_recharge
         |	where inc_day='${inc_day}'
         |	and account_name not REGEXP '测试'
         |	and account_name not REGEXP 'FT'
         |	and account_name not REGEXP '商务演示'
         |	group by team_id
         |) t11
         |on t10.team_id=t11.team_id
         |""".stripMargin)
    car_team_df.repartition(1).createOrReplaceTempView("car_team_tmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_uimp_dm_station_order_car_team_report partition(inc_day='${inc_day}') select * from car_team_tmp")
    logger.error("写入ddjy_uimp_dm_station_order_car_team_report每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      stationProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>车队报表 Execute Ok")
  }

}
