package app

import java.awt.geom.Point2D
import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DistanceUtils, GeometryUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import com.vividsolutions.jts.geom.{LineString, Point}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{PointArea, SfNetInteface, SparkWrite}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * @Description:油站周边道路线索挖掘
 * 需求方：刘芮 01412988
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:421
 * 任务名称：油站周边道路线索
 * 依赖任务：
 * 数据源：ddjy_station_near_road_clue_di
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0&adcode=1:440000&excludeDel=1
 *             http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/qRoad?ak=%s&x1=%s&y1=%s&x2=%s&y2=%s&toll=0&inner=0&furniture=0&fw2=0&poi=0&exprIndex=-1&mask=35&gzip=0&output=json&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED
 *             http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s
 * 数据结果：ddjy_station_near_road_clue_di
 */
object StationNearRoadClue {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def stationInterface(spark: SparkSession, incDay: String) = {
    val gasStationInfoSql=
      """
        |select
        |*
        |from dm_gis.dm_ddjy_gas_station_info_di
        |where delflag='0'
        |and province='广东省'
        |""".stripMargin
    val finalStationInfoRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, gasStationInfoSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取油站数据量："+finalStationInfoRdd.count())
    finalStationInfoRdd
  }

  def getStationArea(spark: SparkSession, stationInfoRdd: RDD[JSONObject], incDay: String) = {
    val stationSquareRdd: RDD[JSONObject] = stationInfoRdd.map(obj => {
      try{
        val lng: Double = obj.getDouble("lng")
        val lat: Double = obj.getDouble("lat")
        val minMaxSquare: ((Double, Double), (Double, Double)) = PointArea.getQuyu50(lng, lat,0.3)
        val minlng: Double = minMaxSquare._1._1
        val minlat: Double = minMaxSquare._1._2
        val maxlng: Double = minMaxSquare._2._1
        val maxlat: Double = minMaxSquare._2._2
        obj.put("minlng", minlng)
        obj.put("minlat", minlat)
        obj.put("maxlng", maxlng)
        obj.put("maxlat", maxlat)
      } catch {
        case _: Exception =>
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取正方形区域后数据量："+stationSquareRdd.count())
    stationSquareRdd.filter(_.getString("grpid")=="cc29d67e-c582-446d-80dc-c79cacc89c10").take(10).foreach(println(_))
    stationSquareRdd
  }

  def getSquareSwid(spark: SparkSession, stationSquareRdd: RDD[JSONObject], incDay: String) = {
    val httpSwid = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "421", "油站周边道路线索", "获取油站周边道路信息和swid", "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/qRoad?ak=%s&x1=%s&y1=%s&x2=%s&y2=%s&toll=0&inner=0&furniture=0&fw2=0&poi=0&exprIndex=-1&mask=35&gzip=0&output=json&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED", "539535c1183b44b6b0d7828375881f5a", stationSquareRdd.count(), 20)

    val returnStationSwidRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,stationSquareRdd, SfNetInteface.swidInterface, 1, "539535c1183b44b6b0d7828375881f5a", 2000)
    returnStationSwidRdd.filter(_.getString("grpid")=="cc29d67e-c582-446d-80dc-c79cacc89c10").take(10).foreach(println(_))
    val stationSwidRdd: RDD[JSONObject] = returnStationSwidRdd.repartition(200).flatMap(obj => {
      val lines: JSONArray = JSONUtil.getJsonArrayMulti(obj, "api_result.lines")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until (lines.size())) {
        val tmpObj = new JSONObject()
        tmpObj.fluentPutAll(obj)
        val lineObj: JSONObject = lines.getJSONObject(i)
        val swID: String = lineObj.getString("swID")
        val roadClass: String = lineObj.getString("roadClass")
        val length: String = lineObj.getString("length")
        val FC: String = lineObj.getString("FC")
        val formway: String = lineObj.getString("formway")
        val linktype: String = lineObj.getString("linkType")
        val ownership: String = lineObj.getString("ownerShip")
        val overhead: String = lineObj.getString("overhead")
        val direct: String = lineObj.getString("direct")
        val polyline: JSONArray = lineObj.getJSONArray("polyline")
        var x: Double = 0
        var y: Double = 0
        var origin_x: Double = 0
        var origin_y: Double = 0
        val points = new ArrayBuffer[String]()
        val pointArray = new JSONArray()
        for (i <- 0 until (polyline.size())) {
          val pointObj = new JSONObject()
          val polylineObj: JSONObject = polyline.getJSONObject(i)
          origin_x = polylineObj.getDoubleValue("x") + origin_x
          origin_y = polylineObj.getDoubleValue("y") + origin_y
          x = origin_x / 3600000
          y = origin_y / 3600000
          val xAndY: String = x + " " + y
          pointObj.put("x",x)
          pointObj.put("y",y)
          points.append(xAndY)
          pointArray.append(pointObj)
        }
        val pointsStr: String = points.mkString(",")
        val geolinkpoint: String = "LINESTRING(" + pointsStr + ")"
        val startpos: JSONObject = JSONUtil.getJSONObject(lineObj, "startpos")
        val star_point = new JSONObject()
        val startpos_x: Double = startpos.getDoubleValue("x") / 3600000
        val startpos_y: Double = startpos.getDoubleValue("y") / 3600000
        star_point.put("x", startpos_x)
        star_point.put("y", startpos_y)
        val endpos: JSONObject = JSONUtil.getJSONObject(lineObj, "endpos")
        val end_point = new JSONObject()
        val endpos_x: Double = endpos.getDoubleValue("x") / 3600000
        val endpos_y: Double = endpos.getDoubleValue("y") / 3600000
        end_point.put("x", endpos_x)
        end_point.put("y", endpos_y)
        tmpObj.put("swID", swID)
        tmpObj.put("swid_roadClass", roadClass)
        tmpObj.put("length", length)
        tmpObj.put("FC", FC)
        tmpObj.put("formway", formway)
        tmpObj.put("geolinkpoint", geolinkpoint)
        tmpObj.put("star_point", star_point)
        tmpObj.put("end_point", end_point)
        tmpObj.put("linktype", linktype)
        tmpObj.put("ownership", ownership)
        tmpObj.put("overhead", overhead)
        tmpObj.put("direct", direct)
        tmpObj.put("pointArray", pointArray)
        tmpList.append(tmpObj)
      }
      tmpList.iterator()
    }).filter(obj=>{
      val swid_roadClass: String = obj.getString("swid_roadClass")
      val roadclass: String = obj.getString("roadclass")
      !((swid_roadClass=="0" &&  roadclass!="0") || (swid_roadClass!="0" &&  roadclass=="0"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取经纬度区间范围内的所有swid后数据量："+stationSwidRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpSwid)
    stationSwidRdd.filter(_.getString("grpid")=="cc29d67e-c582-446d-80dc-c79cacc89c10").take(10).foreach(println(_))
    stationSwidRdd
  }

  def navigateDistanceInterface(spark: SparkSession, stationSwidRdd: RDD[JSONObject], incDay: String) = {
    val stationPointDisRdd: RDD[JSONObject] = stationSwidRdd.map(obj => {
      val geolinkpoint: String = obj.getString("geolinkpoint")
      val geolinkpointLine: LineString = GeometryUtil.createLineByWKT(geolinkpoint)
      val lng: Double = obj.getDoubleValue("lng")
      val lat: Double = obj.getDoubleValue("lat")
      //val pointArray: JSONArray = obj.getJSONArray("pointArray")
      /*val distanceArr = new ArrayBuffer[Double]()
      for (i <- 0 until(pointArray.size())){
        val pointObj: JSONObject = pointArray.getJSONObject(i)
        val x: Double = pointObj.getDoubleValue("x")
        val y: Double = pointObj.getDoubleValue("y")
        val distance: Double = DistanceUtils.getDistance(lng, lat, x, y)
        distanceArr.append(distance)
      }*/
      val point: Point = GeometryUtil.createPoint(lng, lat)
      val line_vertical_dist: Double = GeometryUtil.getDistance(point, geolinkpointLine)

      /*val pointArray2D: util.List[Point2D] = GeometryUtil.parseJsonLineSegment(pointArray)
      val line_vertical_dist: Double = GeometryUtil.pointToLineSegmentDistance(lng, lat, pointArray2D)*/
      //val line_vertical_dist: Double = distanceArr.min
      //val line_vertical_dist: Double = GeometryUtil.pointToLineStringDistance(stationPoint, geolinkpointLine)*100000
      val star_point: JSONObject = obj.getJSONObject("star_point")
      val end_point: JSONObject = obj.getJSONObject("end_point")
      val lineStartX: Double = star_point.getDoubleValue("x")
      val lineStartY: Double = star_point.getDoubleValue("y")
      val lineEndX: Double = end_point.getDoubleValue("x")
      val lineEndY: Double = end_point.getDoubleValue("y")
      val position: String = GeometryUtil.calDir(lineStartX, lineStartY, lineEndX, lineEndY, lng, lat)
      var side = "0"
      if (position=="LEFT") {
        side = "1"
      } else if (position=="RIGHT") {
        side = "2"
      }
      obj.put("line_vertical_dist", line_vertical_dist)
      obj.put("side", side)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("计算油站和始终点距离后数据量："+stationPointDisRdd.count())
    stationPointDisRdd
  }

  def versionAndInsertStationRoadTable(spark: SparkSession, pointStationDisRdd: RDD[JSONObject], incDay: String) = {
    import spark.implicits._
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance.getTime)
    val pointStationDisDf: DataFrame = pointStationDisRdd.map(obj => {
      obj.put("buildTime", "")
      obj
    }).map(obj => {
      StationRoad(
        obj.getString("grpid"),
        obj.getString("pid"),
        obj.getString("poiid"),
        obj.getString("srcid"),
        obj.getString("stationname"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("adcode"),
        obj.getString("district"),
        obj.getString("addr"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperatestatus"),
        obj.getString("swID"),
        obj.getString("swid_roadClass"),
        obj.getString("length"),
        obj.getString("FC"),
        obj.getString("formway"),
        obj.getString("geolinkpoint"),
        obj.getString("star_point"),
        obj.getString("end_point"),
        obj.getString("star_dist"),
        obj.getString("end_dist"),
        obj.getString("line_dist"),
        obj.getString("state"),
        obj.getString("buildTime"),
        update_time,
        obj.getString("star_dist_back"),
        obj.getString("end_dist_back"),
        obj.getString("roadclass"),
        obj.getString("linktype"),
        obj.getString("ownership"),
        obj.getString("overhead"),
        obj.getString("direct"),
        obj.getString("line_vertical_dist"),
        obj.getString("side"),
        obj.getString("gaslocationtype")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("写入结果表数据量："+pointStationDisDf.count())
    SparkWrite.writeToHive(spark,pointStationDisDf,"inc_day",incDay,"dm_gis.ddjy_station_near_road_clue_di")

  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取全量油站
    val needUpdateStationInfoRdd: RDD[JSONObject] = stationInterface(spark, incDay)
    //获取油站周边500m区间经纬度（正方形区间）
    val stationSquareRdd: RDD[JSONObject] = getStationArea(spark, needUpdateStationInfoRdd, incDay)
    //获取经纬度区间范围内的所有swid
    val stationSwidRdd: RDD[JSONObject] = getSquareSwid(spark, stationSquareRdd, incDay)
    //计算swid的起终点距油站的导航距离和终点距油站的直线距离
    val pointStationDisRdd: RDD[JSONObject] = navigateDistanceInterface(spark, stationSwidRdd, incDay)
    //获取底图的版本号并插入油站绑定道路表
    versionAndInsertStationRoadTable(spark,pointStationDisRdd,incDay)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    //execute()
    logger.error("======>>>>>>StationNearRoadClue Execute Ok")
  }
  case class StationRoad(
                          grpid:String,
                          pid:String,
                          poiid:String,
                          srcid:String,
                          stationname:String,
                          province:String,
                          city:String,
                          citycode:String,
                          district:String,
                          addr:String,
                          lng:String,
                          lat:String,
                          cooperatestatus:String,
                          swid:String,
                          roadClass:String,
                          length:String,
                          FC:String,
                          formway:String,
                          geolinkpoint:String,
                          star_point:String,
                          end_point:String,
                          star_dist:String,
                          end_dist:String,
                          line_dist:String,
                          state:String,
                          buildTime:String,
                          update_time:String,
                          star_dist_back:String,
                          end_dist_back:String,
                          station_roadclass:String,
                          linktype:String,
                          ownership:String,
                          overhead:String,
                          direct:String,
                          line_vertical_dist:String,
                          side:String,
                          gaslocationtype:String
                        )
}
