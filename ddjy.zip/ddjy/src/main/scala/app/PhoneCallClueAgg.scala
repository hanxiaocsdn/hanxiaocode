package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SparkUtils, SparkWrite}

/**
 * @Description:外呼线索累计表
 * 需求人员：周韵筹 01425211
 * @Author: lixiangzhi 01405644
 * @Date:2023/11/16
 * 任务id:1048
 * 任务名称：外呼线索累计表
 * 依赖任务：无
 * 数据源：ddjy_phone_call_clue_mi
 * 调用服务地址：无
 * 数据结果：ddjy_phone_call_clue_agg_mi
 */
object PhoneCallClueAgg {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  val stagArr: Array[String] = Array("有效沟通待跟进", "强意向待转化", "电销转跟进", "未加V—未有效触达", "已加V—未有效触达")
  val endArr1: Array[String] = Array("非目标客户—挂靠/小油/批油","非目标客户—不要票","平台信任度","已签约","优惠&油站均不匹配","优惠不合适","非目标客户—小油批油","客户业务问题","非目标客户—挂靠","合作模式不匹配","无匹配油站","公司倒闭（无业务）")
  val endArr2: Array[String] = Array("打错了/不是的", "公司不对", "联系人不对")
  def phoneCallClue(spark: SparkSession, incDay: String,lastDay:String) = {
    import spark.implicits._
    val phoneCallClueSql=
      s"""
        |select
        |owner_id
        |,trim(owner_name) as owner_name
        |,phone
        |,customer_stage
        |,end_follow_up_reason
        |,last_call_time
        |,call_connect_cnt
        |,inc_day as right_inc_day
        |from dm_gis.ddjy_phone_call_clue_mi
        |where inc_day='$incDay'
        |""".stripMargin
    val phoneCallClueRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, phoneCallClueSql).map(obj => {
      ((obj.getString("phone"), obj.getString("owner_name")), obj)
    })
    val phone_cal = Calendar.getInstance
    val phone_time = phone_cal.getTime
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(phone_time)
    val phoneCallClueAggSql=
      s"""
         |select
         |*
         |from dm_gis.ddjy_phone_call_clue_agg_mi
         |where inc_day='$lastDay'
         |""".stripMargin
    val fullJoinAggRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, phoneCallClueAggSql).map(obj => {
      ((obj.getString("phone"), obj.getString("owner_name")), obj)
    }).fullOuterJoin(phoneCallClueRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1.orNull
      val rightObj: JSONObject = obj._2._2.orNull
      val tmpObj = new JSONObject()
      if (leftObj != null) {
        tmpObj.fluentPutAll(leftObj)
      }
      if (rightObj != null) {
        tmpObj.fluentPutAll(rightObj)
      }
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val leftAggRdd: RDD[JSONObject] = fullJoinAggRdd.filter(obj => {
      obj.getString("inc_day") != null && obj.getString("right_inc_day") == null
    })
    val rightAggRdd: RDD[JSONObject] = fullJoinAggRdd.filter(obj => {
      obj.getString("inc_day") == null && obj.getString("right_inc_day") != null
    }).map(obj => {
      val customer_stage: String = JSONUtil.getJsonValSingle(obj, "customer_stage")
      val call_connect_cnt: Int = JSONUtil.getJsonValInt(obj, "call_connect_cnt", 0)
      val end_follow_up_reason: String = JSONUtil.getJsonValSingle(obj, "end_follow_up_reason")
      val last_call_time: String = JSONUtil.getJsonValSingle(obj, "last_call_time")
      var is_call = ""
      var is_connect = ""
      var is_valid_number = ""
      var is_firm_number = ""
      var is_manager_number = ""
      var is_win_order = ""
      var month_connect_cnt = 0
      var agg_connect_cnt = 0
      if (customer_stage == "赢单（已提供地址）") {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        is_manager_number = "1"
        is_win_order = "1"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      } else if ((stagArr.contains(customer_stage) || (customer_stage == "输单" && endArr1.contains(end_follow_up_reason)))) {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        is_manager_number = "1"
        is_win_order = "0"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      }else if (customer_stage == "输单" && end_follow_up_reason == "非目标客户—非决策人无业务") {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        is_manager_number = "0"
        is_win_order = "0"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt + agg_connect_cnt
      } else if (customer_stage == "输单" && end_follow_up_reason == "空号/停机") {
        is_call = "1"
        is_connect = "0"
        is_valid_number = "0"
        is_firm_number = "0"
        is_manager_number = "0"
        is_win_order = "0"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      } else if (customer_stage == "输单" && endArr2.contains(end_follow_up_reason)) {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "0"
        is_manager_number = "0"
        is_win_order = "0"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      } else if (customer_stage == "新线索" || (customer_stage == "输单" && (end_follow_up_reason == "不需要不明原因" || end_follow_up_reason.trim == ""))) {
        is_call = "1"
        if (call_connect_cnt > 0) {
          is_connect = "1"
        } else if (call_connect_cnt == 0) {
          is_connect = "0"
        }
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      }
      obj.put("is_call", is_call)
      obj.put("is_connect", is_connect)
      obj.put("is_valid_number", is_valid_number)
      obj.put("month_connect_cnt", month_connect_cnt)
      obj.put("agg_connect_cnt", agg_connect_cnt)
      obj.put("last_call_time", last_call_time)
      obj.put("is_firm_number", is_firm_number)
      obj.put("is_manager_number", is_manager_number)
      obj.put("is_win_order", is_win_order)
      obj.put("update_time", update_time)
      obj
    })

    val leftRightAggRdd: RDD[JSONObject] = fullJoinAggRdd.filter(obj => {
      obj.getString("inc_day") != null && obj.getString("right_inc_day") != null
    }).map(obj => {
      val customer_stage: String = JSONUtil.getJsonValSingle(obj, "customer_stage")
      val call_connect_cnt: Int = JSONUtil.getJsonValInt(obj, "call_connect_cnt", 0)
      var month_connect_cnt: Int = JSONUtil.getJsonValInt(obj, "month_connect_cnt", 0)
      var agg_connect_cnt: Int = JSONUtil.getJsonValInt(obj, "agg_connect_cnt", 0)
      val end_follow_up_reason: String = JSONUtil.getJsonValSingle(obj, "end_follow_up_reason")
      val last_call_time: String = JSONUtil.getJsonValSingle(obj, "last_call_time")
      var is_win_order: String = JSONUtil.getJsonValSingle(obj, "is_win_order")
      var is_connect: String = JSONUtil.getJsonValSingle(obj, "is_connect")
      var is_valid_number: String = JSONUtil.getJsonValSingle(obj, "is_valid_number")
      var is_firm_number: String = JSONUtil.getJsonValSingle(obj, "is_firm_number")
      var is_manager_number: String = JSONUtil.getJsonValSingle(obj, "is_manager_number")
      var is_call = ""
      if (customer_stage == "赢单（已提供地址）") {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        is_manager_number = "1"
        is_win_order = "1"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt + agg_connect_cnt
      } else if ((stagArr.contains(customer_stage) || (customer_stage == "输单" && endArr1.contains(end_follow_up_reason)))) {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        is_manager_number = "1"
        if (is_win_order != "1") {
          is_win_order = "0"
        }
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt + agg_connect_cnt
      }else if (customer_stage == "输单" && end_follow_up_reason == "非目标客户—非决策人无业务") {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        if (is_manager_number == "") {
          is_manager_number = "0"
        }
        if (is_win_order == "") {
          is_win_order = "0"
        }
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt + agg_connect_cnt
      }else if (customer_stage == "输单" && end_follow_up_reason == "空号/停机") {
        is_call = "1"
        if (is_connect != "1") {
          is_connect = "0"
        }
        if (is_valid_number != "1") {
          is_valid_number = "0"
        }
        if (is_firm_number == "") {
          is_firm_number = "0"
        }
        if (is_manager_number == "") {
          is_manager_number = "0"
        }
        if (is_win_order == "") {
          is_win_order = "0"
        }
      } else if (customer_stage == "输单" && endArr2.contains(end_follow_up_reason)) {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        if (is_firm_number != "1") {
          is_firm_number = "0"
        }
        if (is_manager_number == "") {
          is_manager_number = "0"
        }
        if (is_win_order == "") {
          is_win_order = "0"
        }
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt + agg_connect_cnt
      } else if (customer_stage == "新线索" || (customer_stage == "输单" && (end_follow_up_reason == "不需要不明原因" || end_follow_up_reason.trim == ""))) {
        is_call = "1"
        if (is_connect != "1") {
          if ((is_connect == "0" || is_connect == "") && call_connect_cnt > 0) {
            is_connect = "1"
          } else if (call_connect_cnt == 0) {
            is_connect = "0"
          }
        }
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt + agg_connect_cnt
      }
      obj.put("is_call", is_call)
      obj.put("is_connect", is_connect)
      obj.put("is_valid_number", is_valid_number)
      obj.put("month_connect_cnt", month_connect_cnt)
      obj.put("agg_connect_cnt", agg_connect_cnt)
      obj.put("last_call_time", last_call_time)
      obj.put("is_firm_number", is_firm_number)
      obj.put("is_manager_number", is_manager_number)
      obj.put("is_win_order", is_win_order)
      obj.put("update_time", update_time)
      obj
    })
    val phoneCallClueDf: DataFrame = leftAggRdd.union(rightAggRdd).union(leftRightAggRdd).filter(obj=>{
      obj.getString("owner_id")!="线索id"
    }).map(obj => {
      PhoneCallClue(
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("phone"),
        obj.getString("is_call"),
        obj.getString("is_connect"),
        obj.getString("is_valid_number"),
        obj.getString("month_connect_cnt"),
        obj.getString("agg_connect_cnt"),
        obj.getString("last_call_time"),
        obj.getString("is_firm_number"),
        obj.getString("is_manager_number"),
        obj.getString("is_win_order"),
        obj.getString("update_time")
      )
    }).toDF()
    logger.error("迭代外呼线索累计表数据量："+phoneCallClueDf.count())
    SparkWrite.writeToHive(spark,phoneCallClueDf,"inc_day",incDay,"dm_gis.ddjy_phone_call_clue_agg_mi")

  }

  def phoneCallClueInitialize(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val phoneCallClueSql=
      """
        |select
        |owner_id
        |,trim(owner_name) as owner_name
        |,phone
        |,customer_stage
        |,end_follow_up_reason
        |,last_call_time
        |,call_connect_cnt
        |from dm_gis.ddjy_phone_call_clue_mi
        |where inc_day='202307'
        |""".stripMargin
    val phone_cal = Calendar.getInstance
    val phone_time = phone_cal.getTime
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(phone_time)
    val phoneCallClueInitializeDf: DataFrame = SparkUtils.getRowToJson(spark, phoneCallClueSql).map(obj => {
      val customer_stage: String = JSONUtil.getJsonValSingle(obj, "customer_stage")
      val call_connect_cnt: Int = JSONUtil.getJsonValInt(obj, "call_connect_cnt", 0)
      val end_follow_up_reason: String = JSONUtil.getJsonValSingle(obj, "end_follow_up_reason")
      val last_call_time: String = JSONUtil.getJsonValSingle(obj, "last_call_time")
      var is_call = ""
      var is_connect = ""
      var is_valid_number = ""
      var is_firm_number = ""
      var is_manager_number = ""
      var is_win_order = ""
      var month_connect_cnt = 0
      var agg_connect_cnt = 0
      val stagArr: Array[String] = Array("有效沟通待跟进", "强意向待转化", "电销转跟进", "未加V—未有效触达", "已加V—未有效触达")
      val endArr1: Array[String] = Array("非目标客户—挂靠/小油/批油","非目标客户—不要票","平台信任度","已签约","优惠&油站均不匹配","优惠不合适","非目标客户—小油批油","客户业务问题","非目标客户—挂靠","合作模式不匹配","无匹配油站","公司倒闭（无业务）")
      val endArr2: Array[String] = Array("打错了/不是的", "公司不对", "联系人不对")
      if (customer_stage == "赢单（已提供地址）") {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        is_manager_number = "1"
        is_win_order = "1"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      } else if ((stagArr.contains(customer_stage) || (customer_stage == "输单" && endArr1.contains(end_follow_up_reason)))) {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        is_manager_number = "1"
        is_win_order = "0"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      }else if (customer_stage == "输单" && end_follow_up_reason == "非目标客户—非决策人无业务") {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "1"
        is_manager_number = "0"
        is_win_order = "0"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt + agg_connect_cnt
      }else if (customer_stage == "输单" && end_follow_up_reason == "空号/停机") {
        is_call = "1"
        is_connect = "0"
        is_valid_number = "0"
        is_firm_number = "0"
        is_manager_number = "0"
        is_win_order = "0"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      } else if (customer_stage == "输单" && endArr2.contains(end_follow_up_reason)) {
        is_call = "1"
        is_connect = "1"
        is_valid_number = "1"
        is_firm_number = "0"
        is_manager_number = "0"
        is_win_order = "0"
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      } else if (customer_stage == "新线索" || (customer_stage == "输单" && (end_follow_up_reason == "不需要不明原因" || end_follow_up_reason.trim == ""))) {
        is_call = "1"
        if (call_connect_cnt > 0) {
          is_connect = "1"
        } else if (call_connect_cnt == 0) {
          is_connect = "0"
        }
        month_connect_cnt = call_connect_cnt
        agg_connect_cnt = call_connect_cnt
      }
      obj.put("is_call", is_call)
      obj.put("is_connect", is_connect)
      obj.put("is_valid_number", is_valid_number)
      obj.put("month_connect_cnt", month_connect_cnt)
      obj.put("agg_connect_cnt", agg_connect_cnt)
      obj.put("last_call_time", last_call_time)
      obj.put("is_firm_number", is_firm_number)
      obj.put("is_manager_number", is_manager_number)
      obj.put("is_win_order", is_win_order)
      obj.put("update_time", update_time)
      obj
    }).filter(obj=>{
      obj.getString("owner_id")!="线索id"
    }).map(obj => {
      PhoneCallClue(
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("phone"),
        obj.getString("is_call"),
        obj.getString("is_connect"),
        obj.getString("is_valid_number"),
        obj.getString("month_connect_cnt"),
        obj.getString("agg_connect_cnt"),
        obj.getString("last_call_time"),
        obj.getString("is_firm_number"),
        obj.getString("is_manager_number"),
        obj.getString("is_win_order"),
        obj.getString("update_time")
      )
    }).toDF()
    logger.error("初始化外呼线索累计表数据量："+phoneCallClueInitializeDf.count())
    SparkWrite.writeToHive(spark,phoneCallClueInitializeDf,"inc_day",incDay.substring(0,6),"dm_gis.ddjy_phone_call_clue_agg_mi")
  }

  def execute(lastDay:String, incDay: String, initialize:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取ddjy_phone_call_clue_mi
    if (initialize=="yes"){
      phoneCallClueInitialize(spark,incDay)
    }else{
      phoneCallClue(spark,incDay,lastDay)
    }

    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val lastDay: String = args(0)
    val incDay: String = args(1)
    val initialize: String = args(2)
    execute(lastDay,incDay,initialize)
    logger.error("======>>>>>>Execute Ok")
  }

  case class PhoneCallClue(
                            owner_id:String,
                            owner_name:String,
                            phone:String,
                            is_call:String,
                            is_connect:String,
                            is_valid_number:String,
                            month_connect_cnt:String,
                            agg_connect_cnt:String,
                            last_call_time:String,
                            is_firm_number:String,
                            is_manager_number:String,
                            is_win_order:String,
                            update_time:String
                          )

}
