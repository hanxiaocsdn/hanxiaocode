package app

import java.util.{LinkedList, List}
import java.{lang, util}

import cn.hutool.core.codec.Base64
import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SfNetInteface
import cn.hutool.core.codec.Base64.decodeStr
import com.vividsolutions.jts.algorithm.ConvexHull
import com.vividsolutions.jts.geom.{Coordinate, Geometry, Point}

import scala.collection.JavaConversions._
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks

/**
 * @Description:粤运线索地图
 * 需求人员：矫悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 18:40 2022/11/14
 * 任务id:259
 * 任务名称：粤运线索地图
 * 依赖任务：粤运集散地关联车队表 258
 * 数据源：single_agr_stat_all_drop_owner_tmp
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0
 *             http://gis-int.int.sfdc.com.cn:1080/rgeo/api?x=%s&y=%s&opt=sf1&ak=%s
 *             http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s
 *             http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/StationClusterRect?
 * 数据结果：ddjy_aoi_interface_tmp、dwd_ddjy_aoi_key_di、dwd_ddjy_aoi_not_key_di
 */
object YueYunClueMapAoiPolygon {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readSpDmData(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val sp_dm_wi_sql=
      """
        |select *
        |from dm_gis.dwd_ddjy_sp_dm_wi
        |where cmp_partition='20230601_20230607'
        |--and agr_id like '鲁%'
        |--limit 100000
        |""".stripMargin
    val provinceMap = Map("皖" -> "安徽省","京" -> "北京市","闽" -> "福建省","甘" -> "甘肃省","粤" -> "广东省","桂" -> "广西壮族自治区","贵" -> "贵州省","琼" -> "海南省","冀" -> "河北省","豫" -> "河南省","黑" -> "黑龙江省","鄂" -> "湖北省","湘" -> "湖南省","吉" -> "吉林省","苏" -> "江苏省","赣" -> "江西省","辽" -> "辽宁省","蒙" -> "内蒙古自治区","宁" -> "宁夏回族自治区","青" -> "青海省","鲁" -> "山东省","晋" -> "山西省","陕" -> "陕西省","沪" -> "上海市","川" -> "四川省","津" -> "天津市","藏" -> "西藏自治区","新" -> "新疆维吾尔自治区","云" -> "云南省","浙" -> "浙江省","渝" -> "重庆市")
    val provinceMapBr: Broadcast[Map[String, String]] = spark.sparkContext.broadcast(provinceMap)
    val value: RDD[JSONObject] = SparkUtils.getRowToJson(spark, sp_dm_wi_sql).map(obj => {
      val vehicle_no: String = obj.getString("agr_id").split("_")(0)
      val timeStamp: String = obj.getString("agr_id").split("_")(1)
      val vehicle_no_new: String = Base64.decodeStr(vehicle_no,"utf-8")
      val agr_id_new: String = vehicle_no_new + "_" + timeStamp
      val vehicle_num: String = agr_id_new.substring(0, 1)
      val vehicle_province: String = provinceMapBr.value.get(vehicle_num).orNull
      obj.put("vehicle_province", vehicle_province)
      obj.put("vehicle_no",vehicle_no_new)
      obj.put("vehicle_num",vehicle_num)
      obj.put("agr_id", agr_id_new)
      obj
    }).filter(!_.getString("vehicle_num").endsWith("_2")).persist(StorageLevel.MEMORY_AND_DISK_SER)
    value.take(10).foreach(println(_))
    val addProvinceRdd: RDD[JSONObject] = value
      .filter(obj=>{
      val vehicle_num: String = obj.getString("vehicle_num")
      val array: Array[String] = Array("鲁", "冀", "苏", "豫", "皖", "晋", "川", "辽", "浙", "赣", "鄂", "桂", "陕", "湘", "云", "粤")
      //val array: Array[String] = Array("粤")
      array.contains(vehicle_num)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addProvince表数据量："+addProvinceRdd.count())
    value.unpersist()
    val addProvinceDf: DataFrame = addProvinceRdd.map(obj => {
      (
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("cmp_partition"),
        obj.getString("vehicle_no"),
        obj.getString("vehicle_num"),
        obj.getString("vehicle_province")
      )
    }).toDF()
    addProvinceDf.createOrReplaceTempView("addProvinceTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_vehicle_province_tmp_di partition(inc_day='$incDay') select * from addProvinceTmp")
    addProvinceRdd
  }

  def insertAoiInterfaceTable(spark: SparkSession, aoiInterfaceRdd: RDD[JSONObject],incDay:String) = {
    import spark.implicits._
    val aoiInterfaceDf: DataFrame = aoiInterfaceRdd.map(obj => {
      AoiInterface(
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("cmp_partition"),
        obj.getString("vehicle_no"),
        obj.getString("vehicle_num"),
        obj.getString("vehicle_province"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("faType"),
        obj.getString("aoiCode"),
        obj.getString("znoCode"),
        obj.getString("dist"),
        obj.getString("aoi_city"),
        obj.getString("polygon"),
        obj.getString("adcode")
      )
    }).toDF()
    aoiInterfaceDf.createOrReplaceTempView("aoiInterfaceTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_aoi_interface_result_tmp partition(inc_day='$incDay') select * from aoiInterfaceTmp")
  }

  def dropOwnerAoiInterface(spark: SparkSession, addProvinceRdd: RDD[JSONObject], incDay: String) = {
    import scala.collection.JavaConverters._
    val value: RDD[(String, String)] = addProvinceRdd.map(obj => {
      val agr_lng: Double = obj.getDoubleValue("agr_lng")
      val agr_lat: Double = obj.getDoubleValue("agr_lat")
      val agr_rs_id: String = obj.getString("agr_rs_id")
      val point: Point = GeometryUtil.createPoint(agr_lng, agr_lat)
      (agr_rs_id.reverse, point)
    }).groupByKey()
      .repartition(400).map(obj => {
      val list: util.List[Point] = obj._2.toList.asJava
      val geometry: Geometry = GeometryUtil.getCoorPolygon(list)
      //多边形外扩500米
      val geometry_buffer = geometry.buffer(GeometryUtil.meterToDeg(500))
      val coordinates: Array[Coordinate] = geometry_buffer.getCoordinates
      val points: util.List[Point] = new util.ArrayList[Point]()
      for (elem <- coordinates) {
        val x3 = elem.x
        val y3 = elem.y
        val point: Point = GeometryUtil.createPoint(x3, y3)
        points.add(point)
      }
      var polygon=""
      if (points.size()==1){
        polygon = GeometryUtil.getPointStr(points.get(0))
      }else if(points.size()==2){
        polygon = GeometryUtil.getLineStrFromPointList(points)
      }else{
        polygon = GeometryUtil.getPolygonStrByPoints(points)
      }
      val agr_rs_id: String = obj._1.reverse
      (polygon,agr_rs_id)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("生成polygon格式数据量:"+value.count())
    val aoiInterfaceRdd = value.map(obj=>{
      val tmpObj = new JSONObject()
      val polygon: String = obj._1
      val agr_rs_id: String = obj._2
      tmpObj.put("polygon",polygon)
      tmpObj.put("agr_rs_id",agr_rs_id)
      tmpObj
    }).repartition(50).flatMap(obj => {
      val retObj: JSONObject = SfNetInteface.aoiPolygonInterface(obj)
      val api_result: JSONObject = JSONUtil.getJSONObject(retObj, "api_result")
      val dataArray: JSONArray = JSONUtil.getJsonArrayMulti(api_result, "data")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until dataArray.size()) {
        val tmpObj = new JSONObject()
        val dataObj: JSONObject = dataArray.getJSONObject(i)
        val id: String = dataObj.getString("id")
        val name: String = dataObj.getString("name")
        val faType: String = dataObj.getString("faType")
        val city: String = dataObj.getString("city")
        var adcode: String = JSONUtil.getJsonValSingle(dataObj, "adCode")
        if (StringUtils.isNotEmpty(adcode) && adcode.size >=6){
          adcode = adcode.substring(0, 6)
        }
        tmpObj.fluentPutAll(obj)
        tmpObj.put("id", id)
        tmpObj.put("name", name)
        tmpObj.put("faType", faType)
        tmpObj.put("aoi_city", city)
        tmpObj.put("adcode", adcode)
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    })
    //logger.error("调aoi接口返回数据量："+aoiInterfaceRdd.count())

    insertAoiInterfaceTable(spark,aoiInterfaceRdd,incDay)
    logger.error("====>>>>>>>插入aoi接口表成功")
    aoiInterfaceRdd.unpersist()
  }
  def readAoiInterfaceData(spark: SparkSession, incDay: String) = {
    val aoi_interface_sql=
      s"""
        |select *
        |from dm_gis.ddjy_aoi_interface_result_tmp
        |where inc_day='$incDay'
        |""".stripMargin
    val aoi_interface_df: DataFrame = spark.sql(aoi_interface_sql)
    aoi_interface_df
  }

  def getAreaKeyRdd(spark:SparkSession,aoiInterfaceRdd:RDD[JSONObject]) = {
    val name_key="油站|服务区|中国石化|中国石油|壳牌|美孚|加德士|东方|碧辟|道达尔|埃索|道达尔|中化|中石油|中油|BP|TOTAL|混凝土|水泥|沥青|家居|石膏|定制|供应链|沙场|石场|纺织|铝业|橡胶|机械|酒厂|啤酒|油站|服务区|石场|钢铁|矿业|木业|石化|塑料|金属|纺织|工业|塑胶|陶瓷|玻璃|材料|纸|五金|钢材|不锈钢|公司|家具|电器|家电|建材|市场|酒业|化肥|批发|钢贸|开发区|创业园|商贸园|科贸园|开发区|处理厂|厂区|厂房|工业园|工业区|工业城|产业园|科技园|研究院|基地|工业|工厂|厂|园区|中心|集团|分销中心|菜鸟|冷库|电商|电子商务|仓储|邮局|物流|货运|运输|快递|中转|集散点|分拨|分拨中心|韵达|申通|顺丰|中通|圆通|德邦|邮政|EMS|ems|京东|百世|龙邦|国通|龙邦|极兔|快递|大件|货场|仓库|工艺|集团|码头|口岸|口岸|港口|保税|港区|卸货|货运站|车站|南站|北站|西站|东站|客运站|火车站|机场|花园|花卉场|花场|农场|农田|牧场|菜场|菜园|菜地|养殖场|蔬菜基地|果业|果园|菜地|养鸡场|鱼塘|林场|渔场|猪场|果场|工地|项目部|项目分部|工程建设"
    val name_key_arr: Array[String] = name_key.split("\\|")
    val keyFilterRdd: RDD[JSONObject] = aoiInterfaceRdd.filter(obj => {
      val name: String = obj.getString("name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- name_key_arr.indices) {
          val name_key: String = name_key_arr(k)
          if (name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      val remove_name_key="工地|无名工地|工地（在建）|工地（建设中）"
      val remove_name_key_arr: Array[String] = remove_name_key.split("\\|")
      val fatype_key = "010000,010100,010101,010102,010103,010104,010105,010107,010108,010109,010110,010111,010112,060700,170400,060300,060600,060700,061000,061100,070400,070401,070500,070501,070502,070503,120100,120201,150200,150300,150400,150900,170300,170301,170302,170400,170401,170402,170403,170404,170405,170406,170407,170408,500000,510000"
      val fatype_key_arr: Array[String] = fatype_key.split(",")
      val fatype: String = obj.getString("fatype")
      //val dist: Double = obj.getDouble("dist")

      bool && (fatype_key_arr.contains(fatype) || StringUtils.isEmpty(fatype))  && !remove_name_key_arr.contains(name)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤出重点类型数据量："+keyFilterRdd.count())
    //keyFilterRdd.filter(_.getString("name").contains("公司")).take(10).foreach(println(_))
    //keyFilterRdd.take(10).foreach(println(_))
    val keyRdd: RDD[JSONObject] = keyFilterRdd
      .map(obj => {
        val agr_rs_id: String = obj.getString("agr_rs_id")
        (agr_rs_id, obj)
      }).groupByKey().map(obj => {
      obj._2.toList.minBy((json: JSONObject) => {
        JSONUtil.getJsonDouble(json,"dist",Int.MaxValue)
      })
    }).map(obj => {
      obj.put("clue_type", "AOI_key_clue")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    /*val keyMapRdd: RDD[(String, JSONObject)] = keyRdd.map(obj => {
      (obj.getString("agr_id"),obj)
    })*/
    /*val notkeyRdd: RDD[JSONObject] = aoiInterfaceRdd.repartition(600).map(obj => {
      (obj.getString("agr_id"), obj)
    }).leftOuterJoin(keyMapRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj == null
    }).map(obj => {
      val leftObj: JSONObject = obj._2._1
      (leftObj.getString("agr_id"), leftObj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val head: JSONObject = list.minBy(json => {
        JSONUtil.getJsonDouble(json, "dis", Int.MaxValue)
      })
      head
    }).map(obj => {
      obj.put("clue_type", "AOI_not_key_clue")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)*/
    keyFilterRdd.unpersist()
    //(keyRdd,notkeyRdd)
    keyRdd
  }

  def joinAoiKeyType(spark: SparkSession, aoiInterfaceDf: DataFrame,incDay:String) = {
    import spark.implicits._
    val aoiInterfaceRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, aoiInterfaceDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val keyRdd: RDD[JSONObject] = getAreaKeyRdd(spark,aoiInterfaceRdd)
    logger.error("重点类型数据量："+keyRdd.count())
    val cityMapSql=
      """
        |select * from dm_gis.city_name_map
        |""".stripMargin
    val cityMapRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, cityMapSql).map(obj => {
      (obj.getString("adcode"), obj)
    })
    val aoiKeyDf: DataFrame = keyRdd.map(obj=>{
      (obj.getString("adcode"), obj)
    }).leftOuterJoin(cityMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("province",rightObj.getString("province"))
        leftObj.put("city",rightObj.getString("city"))
        leftObj.put("region",rightObj.getString("region"))
      }
      leftObj
    }).map(obj=>{
      AoiKey(
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("cmp_partition"),
        obj.getString("vehicle_no"),
        obj.getString("vehicle_num"),
        obj.getString("vehicle_province"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("fatype"),
        obj.getString("aoicode"),
        obj.getString("znocode"),
        obj.getString("dist"),
        obj.getString("aoi_city"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("region"),
        obj.getString("polygon"),
        obj.getString("adcode")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("AOI关联的重点类型数据量："+aoiKeyDf.count())
    aoiKeyDf.createOrReplaceTempView("aoiKeyTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_aoi_key_tmp_di partition(inc_day='$incDay') select * from aoiKeyTmp")
    val joinSql=
      s"""
        |insert overwrite table dm_gis.ddjy_vehicle_province_aoi_tmp_di partition(inc_day='$incDay')
        |select
        |t2.agr_id
        |,t2.agr_cnt
        |,t2.agr_dis
        |,t2.agr_tm
        |,t2.agr_lng
        |,t2.agr_lat
        |,t2.agr_dis2sp
        |,t2.agr_gh
        |,t2.agr_rs_id
        |,t2.agr_rs_cnt
        |,t2.type
        |,t2.data_src
        |,t2.cmp_partition
        |,t2.vehicle_no
        |,t2.vehicle_num
        |,t2.vehicle_province
        |,t1.polygon
        |,t1.id
        |,t1.name
        |,t1.fatype
        |,t1.aoi_city
        |,t1.adcode
        |,t1.province
        |,t1.city
        |,t1.region
        |from (
        |select * from dm_gis.dwd_ddjy_aoi_key_tmp_di
        |where inc_day='$incDay'
        |) t1
        |join (
        |select * from dm_gis.ddjy_vehicle_province_tmp_di
        |where inc_day='$incDay'
        |) t2
        |on t1.agr_rs_id=t2.agr_rs_id
        |""".stripMargin
    spark.sql(joinSql)

  }
  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //dwd_ddjy_sp_dm_wi
    val addProvinceRdd: RDD[JSONObject] = readSpDmData(spark, incDay)
    //调aoi接口
    dropOwnerAoiInterface(spark,addProvinceRdd,incDay)
    //读取dwd_ddjy_logistics_vehicle_di表数据
    val aoiInterfaceDf: DataFrame = readAoiInterfaceData(spark, incDay)
    //关联AOI重点类型数据
    joinAoiKeyType(spark,aoiInterfaceDf,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>YueYunClueMapAoi Execute Ok")
  }
  case class AoiInterface(
                               agr_id:String,
                               agr_cnt:String,
                               agr_dis:String,
                               agr_tm:String,
                               agr_lng:String,
                               agr_lat:String,
                               agr_dis2sp:String,
                               agr_gh:String,
                               agr_rs_id:String,
                               agr_rs_cnt:String,
                               aoi_type:String,
                               data_src:String,
                               cmp_partition:String,
                               vehicle_no:String,
                               vehicle_num:String,
                               vehicle_province:String,
                               id:String,
                               name:String,
                               faType:String,
                               aoiCode:String,
                               znoCode:String,
                               dist:String,
                               aoi_city:String,
                               polygon:String,
                               adcode:String
                             )
  case class AoiKey(
                                  agr_id:String,
                                  agr_cnt:String,
                                  agr_dis:String,
                                  agr_tm:String,
                                  agr_lng:String,
                                  agr_lat:String,
                                  agr_dis2sp:String,
                                  agr_gh:String,
                                  agr_rs_id:String,
                                  agr_rs_cnt:String,
                                  aoi_type:String,
                                  data_src:String,
                                  cmp_partition:String,
                                  vehicle_no:String,
                                  vehicle_num:String,
                                  vehicle_province:String,
                                  id:String,
                                  name:String,
                                  faType:String,
                                  aoiCode:String,
                                  znoCode:String,
                                  dist:String,
                                  aoi_city:String,
                                  province:String,
                                  city:String,
                                  region:String,
                                  polygon:String,
                                  adcode:String
                                )
}
