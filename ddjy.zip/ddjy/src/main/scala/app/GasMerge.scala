package app

import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.SparkWrite

/**
 * @Description:油站融合表
 * 需求人员：娇悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2022/11/26
 * 任务id:684
 * 任务名称：油站融合表
 * 依赖任务：油站车队融合周维度表524 油站车辆融合周维度表523
 * 数据源：dm_ddjy_gas_carrier_merge_di、dm_ddjy_gas_car_merge_di
 * 调用服务地址：无
 * 数据结果：dm_ddjy_gas_merge_clue_di
 */
object GasMerge {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def updateGasMerge(spark: SparkSession, max_day: String) = {
    logger.error("正在执行 dm_ddjy_gas_merge_clue_di 任务.........")
    val gas_merge_clue_sql=
      s"""
        |
        |select
        |t2.gas_id,stationname,adcode,province,t2.city,district,lng,lat,cooperatestatus,tel,brand,gas_type,gas_competitors,gas_road_type,gas_road_function_type,clue_task_count,clue_vehicle_count,pathway_task_count,pathway_vehicle_count,pathway_around_task_count,pathway_around_vehicle_count,stay_task_count,stay_vehicle_count,task_sum_count,carrier_pathway_cost,gas_city_count,carrier_count_3,city_rank,
        |task_sum_count/gas_city_count as city_cover_rate,
        |round(sum(task_sum_count/gas_city_count) over(partition by t2.city order by task_sum_count desc,t2.gas_id desc),6) as city_cover_rate_sum,
        |from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as update_time,
        |task_batch
        |from
        |(
        |	select
        |	gas_id,stationname,adcode,province,city,district,lng,lat,cooperatestatus,tel,brand,gas_type,gas_competitors,gas_road_type,gas_road_function_type
        |	from
        |	(
        |		select
        |		gas_id,stationname,adcode,province,city,district,lng,lat,cooperatestatus,tel,brand,gas_type,gas_competitors,gas_road_type,gas_road_function_type,
        |		row_number() over(partition by gas_id order by stationname desc) as rnk
        |		from dm_gis.dm_ddjy_gas_carrier_merge_di
        |		where inc_day='${max_day}'
        |	) t1
        |	where rnk=1
        |) t2
        |left join
        |(
        |	select
        |	gas_id,clue_task_count,pathway_task_count,pathway_around_task_count,stay_task_count,task_sum_count,carrier_pathway_cost,carrier_count_3
        |	from
        |	(
        |		select gas_id,
        |		sum(clue_task_count) as clue_task_count,
        |		sum(pathway_task_count) as pathway_task_count,
        |		sum(pathway_around_task_count) as pathway_around_task_count,
        |		sum(stay_task_count) as stay_task_count,
        |		sum(task_sum_count) as task_sum_count,
        |		avg(carrier_pathway_cost) as carrier_pathway_cost,
        |		count(distinct carrier_id) as carrier_count_3
        |		from dm_gis.dm_ddjy_gas_carrier_merge_di
        |		where inc_day='${max_day}'
        |		group by gas_id
        |	) t3
        |	where task_sum_count>=3
        |) t4
        |on t2.gas_id=t4.gas_id
        |left join
        |(
        |	select
        |	city,gas_city_count,
        |	row_number() over(partition by city order by gas_city_count desc) as city_rank
        |	from
        |	(
        |		select city,sum(task_sum_count) as gas_city_count
        |		from dm_gis.dm_ddjy_gas_car_merge_di
        |		where inc_day = '${max_day}'
        |		group by city
        |	) t5
        |) t6
        |on t2.city=t6.city
        |left join
        |(
        |	select gas_id,task_batch,
        |	count(distinct if(clue_task_count is not null and clue_task_count != '',vehicle_no,null)) as clue_vehicle_count,
        |	count(distinct if(pathway_task_count is not null and pathway_task_count != '',vehicle_no,null)) as pathway_vehicle_count,
        |	count(distinct if(pathway_around_task_count is not null and pathway_around_task_count != '',vehicle_no,null)) as pathway_around_vehicle_count,
        |	count(distinct if(stay_task_count is not null and stay_task_count != '',vehicle_no,null)) as stay_vehicle_count
        |	from dm_gis.dm_ddjy_gas_car_merge_di
        |	where inc_day = '${max_day}'
        |	group by gas_id,task_batch
        |) t7
        |on t2.gas_id=t7.gas_id
        |""".stripMargin
    val resultDf: DataFrame = spark.sql(gas_merge_clue_sql)
    SparkWrite.writeToHive(spark,resultDf,"inc_day",max_day,"dm_gis.dm_ddjy_gas_merge_clue_di")
  }

  def execute(incDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val gas_carrier_merge_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.dm_ddjy_gas_carrier_merge_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val gas_carrier_merge_df: DataFrame = spark.sql(gas_carrier_merge_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, gas_carrier_merge_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    updateGasMerge(spark,max_day)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>GasMerge Execute Ok")
  }
}
