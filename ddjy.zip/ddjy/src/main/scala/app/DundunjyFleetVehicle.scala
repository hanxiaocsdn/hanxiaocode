package app

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 540 (新平台)
 * @description: 车队全量表 V1.0/V1.1 dm_gis.ddjy_dwd_team_quota_dtl
 * @demander: 01424177 陶慧
 * @author 01418539 曹佳 迭代修改 01390943 周勇
 * @date 2023/2/7 17:16
 */
object DundunjyFleetVehicle   {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    // val spark = SparkBuilder.initSparkNew(this.getClass.getSimpleName)
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //    val spark = SparkSession
    //      .builder()
    //      .appName(className)
    //      .config("spark.shuffle.useOldFetchProtocol", "true")
    //      .config("spark.dynamicAllocation.enabled", "false")
    //      .config("hive.exec.dynamic.partition", "true")
    //      .config("hive.exec.dynamic.partition.mode", "nonstrict")
    //      .enableHiveSupport()
    //      .getOrCreate()
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val if_first_day = args(1)
    val first_day = args(2) // 首次设置初始日期："20230120"
    val stat_day = args(3)
    processDDJY(spark, inc_day, if_first_day, first_day,stat_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }



  def processDDJY(spark: SparkSession, inc_day: String, if_first_day: String, first_day: String, stat_day:String): Unit = {
    import spark.implicits._
    val o_day = "20220816"
    val days_1_ago = getdaysBeforeOrAfter(inc_day, -1)
    val days_10_ago = getdaysBeforeOrAfter(inc_day, -10)
    //1111 车队表(F全量) ddjy_dim_team_info_filter（id--车队id,  tax_no--纳税识别号）---del_flag='0'
    val o_chedui = spark.sql(
      s"""select id team_id,name,contact_name,contact_phone,tax_no,inc_day,substr(create_date,0,10) as create_date from dm_gis.ddjy_dim_team_info_filter
         |where inc_day = '$inc_day' and del_flag= '0'
         |and id is not null and trim(id)!=''""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //2222 销售表(F全量)  ddjy_ods_sales_team（team_id）
    val o_sales = spark.sql(
      s"""select team_id,max(user_name) user_name,max(user_id) user_id,max(sub_name) sub_name,max(sub_code) sub_code,max(sup_name) sup_name,
         |max(sup_code) sup_code,inc_day from dm_gis.ddjy_ods_sales_team
         |where inc_day = '$inc_day' and deleted='0'
         |group by team_id,inc_day
         |""".stripMargin)

    //3333 充值表(I增量) ddjy_dwd_car_team_history_recharge（team_id） --trade_description = '车队充值上账'
    val o_recharge_initial = spark.sql(
      s"""select team_id,trade_time,trade_amount,inc_day from dm_gis.ddjy_dwd_car_team_history_recharge
         |where inc_day between '$o_day' and '$inc_day' and trade_description in ('车队充值上账','代收代付充值','顺手付充值')""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val o_recharge = o_recharge_initial
      .filter('trade_amount.cast("double") > 0)
      .groupBy("team_id")
      .agg(min('trade_time) as "first_trade_time_tmp",
        count('trade_time) as "cnt_trade_time",
        sum('trade_amount) as "total_trade_amount")
      .withColumn("first_mon_trade_time", substring('first_trade_time_tmp, 1, 7))
      .select("team_id", "cnt_trade_time", "total_trade_amount", "first_mon_trade_time")

    //4444 账单表(F全量) dm_ddjy_team_account_report_di（team_id）
    /*val o_bill = spark.sql(
      s"""select team_id,max(end_balance) total_end_balance from dm_gis.dm_ddjy_team_account_report_di
         |where inc_day = '$inc_day' and tag= '每日' group by team_id""".stripMargin)*/

    //5555 订单表(I增量) ddjy_dwd_station_order_pay_repartition_di（car_team_id --- 车队id, station_id --- 所属油站id） order_sn 唯一 order_status=2，petrol_resources=2
    val o_order = spark.sql( //pay_time 2023-02-06 00:07:00
      s"""select car_team_id team_id,station_id,station_name,order_sn,ft_sale_money,pay_time,inc_day,grpid
         | from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day between '$o_day' and '$inc_day' and order_status='2' and petrol_resources='2'""".stripMargin)
      .withColumn("grpid_new",grpidProcess('grpid))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //6666 油站信息表(F全量) ddjy_dim_station_info_filter(id---加油站点id,petrol_station_name--油站名称)
    val o_station = spark.sql(
      s"""select id station_id,city_name,petrol_station_name stationname,station_type,grpid from dm_gis.ddjy_dim_station_info_filter
         |where inc_day = '$inc_day' and del_flag='0' """.stripMargin) // and enable_flag ='1'
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //7777 平台流水明细表(I增量)(包含区域--城市维度的信息) ddjy_dwd_station_stream_detail(car_team_id---车队id,last_pay_date--末单日期'2022-01-01')
    val o_plat_stream = spark.sql(
      s"""select car_team_id team_id,*
         |from dm_gis.ddjy_dwd_station_stream_detail
         |where inc_day = '$inc_day'""".stripMargin)
      .groupBy("team_id", "city_name")
      .agg(min("first_pay_date") as "first_pay_date_tmp",
        max("team_vehicle_cnt") as "team_vehicle_cnt_tmp",
        max("fixed_team_vehicle_cnt") as "fixed_team_vehicle_cnt_tmp",
        max("last_trade_date") as "last_trade_date_tmp",
        max("last_trade_amount") as "last_trade_amount_tmp",
        min("team_create_date") as "team_create_date_tmp",
        max("last_pay_date") as "city_last_pay_time",
        max("end_balance") as "end_balance_tmp",
        max("first_trade_date") as "first_trade_date_tmp",
        max("tag") as "tag_tmp"
      )
      .withColumn("city_and_last_pay_time", concat_ws(":", 'city_name, 'city_last_pay_time))
      .groupBy("team_id")
      .agg(
        concat_ws(";", collect_set("city_last_pay_time")) as "city_last_pay_time",
        concat_ws(";", collect_set("city_and_last_pay_time")) as "city_and_last_pay_time",
        min("first_pay_date_tmp") as "first_pay_date",
        max("team_vehicle_cnt_tmp") as "team_vehicle_cnt",
        max("fixed_team_vehicle_cnt_tmp") as "fixed_team_vehicle_cnt",
        max("last_trade_date_tmp") as "last_trade_date",
        max("city_last_pay_time") as "last_pay_time",
        min("team_create_date_tmp") as "team_create_date",
        max("last_trade_amount_tmp") as "last_trade_amount",
        max("end_balance_tmp") as "total_end_balance",
        max("first_trade_date_tmp") as "first_trade_time",
        max("tag_tmp") as "team_id_label_show"
      )
      .select("team_id", "city_last_pay_time", "city_and_last_pay_time","first_pay_date","team_vehicle_cnt","fixed_team_vehicle_cnt","last_trade_date","last_trade_amount","last_pay_time","team_create_date","total_end_balance","first_trade_time","team_id_label_show") //获得车队维度 最后支付日期 + 车队{城市维度 最后支付日期的集合}
    //当月流水
    val inc_month: String = inc_day.substring(0,6)
    val o_plat_stream_month = spark.sql(
      s"""select car_team_id team_id,total_sales
         |from dm_gis.ddjy_dwd_station_stream_detail
         |where inc_day<='$inc_day' and substr(inc_day,0,6) ='$inc_month'""".stripMargin)
      .groupBy("team_id")
      .agg(sum("total_sales") as "month_total_sales")
    //8888 线索车队周数据表(T-7 周更新-I增量) dm_ddjy_carrier_rlst_di  -- credit_code--统一社会信用代码 city_distribution（东莞市:1.0、惠州市:12.0、河源市:2.0）
    //val o_week_day = spark.sql(s"""select max(inc_day) inc_day from dm_gis.dm_ddjy_carrier_rlst_di where inc_day between '$days_10_ago' and '$inc_day'""")
    //  .select("inc_day").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    //修改inc_day = $o_week_day
    val carrier_rlst_di = spark.sql(
      s"""select credit_code tax_no,(online_gas_task_count/task_count)*100 as online_gas_match_rate,online_gas_top10,whitelist_limit_individual,whitelist_limit_corporate
         |from dm_gis.dm_ddjy_carrier_rlst_di
         |where inc_day in (select max(inc_day) as inc_day from dm_gis.dm_ddjy_carrier_rlst_di)
         |and credit_code is not null and trim(credit_code) !=''
          """.stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("tax_no").orderBy(asc("online_gas_match_rate")) ))
      .filter($"rank"===1)
      .select("tax_no","online_gas_match_rate","online_gas_top10","whitelist_limit_individual","whitelist_limit_corporate")
    //ddjy_dwd_station_stream_detail近七天的数据
    val last_seven_day: String = DateUtil.getDateStr(inc_day, -6, "")
    val o_seven_plat_stream = spark.sql(
      s"""select car_team_id team_id,consume_carplate_aggr
         |from dm_gis.ddjy_dwd_station_stream_detail
         |where inc_day between '$last_seven_day' and '$inc_day'""".stripMargin)
      .withColumn("consume_carplate",explode(split($"consume_carplate_aggr",",")))
      .groupBy("team_id")
      .agg(countDistinct($"consume_carplate") as "consume_carplate_aggr_seven")
    val vehicle_week_cnt_sql=
      s"""
        |select team_id,max(cast(vehicle_week_cnt as int)) as max_vehicle_week_cnt
        |from dm_gis.ddjy_dwd_team_vehicle_week_cnt_di
        |where inc_day<='$inc_day'
        |group by team_id
        |""".stripMargin
    val vehicle_week_cnt_df: DataFrame = spark.sql(vehicle_week_cnt_sql)


    //取ddjy_ods_clue_follow_up当天的数据
    val clue_follow_up_df = spark.sql(
      s"""
         |select
         |team_name as name,customer_source
         |from
         |(
         |	select team_name,customer_source,
         |	row_number() over(partition by team_name order by create_time desc) as rnk
         |	from dm_gis.ddjy_ods_clue_follow_up
         |	where inc_day ='$inc_day'
         |) t1
         |where rnk=1
         |""".stripMargin)
    //取ddjy_ods_team_intend_grade_df的数据
    val intend_grade_df = spark.sql(
      s"""
         |select team_id,
         |from_unixtime(unix_timestamp(inc_day,'yyyyMMdd'),'yyyy-MM-dd') as statistical_day,
         |case when intend_grade='2' then 'A'
         |	 when intend_grade='1' then 'B'
         |	 when intend_grade='0' then 'C'
         |	 end as intend_grade
         |from dm_gis.ddjy_ods_team_intend_grade_df
         |where inc_day ='$inc_day'
         |and deleted='0'
         |""".stripMargin)

    //取ddjy_ods_dws_team_lost_recall_filling_df的数据
    val recall_filling_df = spark.sql(
      s"""
         |select
         |team_id,lost_reason,recal_wish,communication,statistical_day,recall_day
         |from
         |(
         |	select team_id,lost_reason,recal_wish,communication,
         |	substring(create_date,0,10) as statistical_day,
         |	substring(create_date,0,10) as recall_day,
         |	row_number() over(partition by substring(create_date,0,10),team_id order by update_date desc) as rnk
         |	from dm_gis.ddjy_ods_dws_team_lost_recall_filling_df
         |	where inc_day in (select max(inc_day) as inc_day from dm_gis.ddjy_ods_dws_team_lost_recall_filling_df)
         |	and deleted='0'
         |) t1
         |where rnk=1
         |""".stripMargin)

    //取ddjy_team_return_visit的数据
    val return_visit_df = spark.sql(
      s"""
         |select
         |team_id,remark,statistical_day,visit_day
         |from
         |(
         |	select team_id,remark,
         |	substring(create_time,0,10) as statistical_day,
         |	substring(create_time,0,10) as visit_day,
         |	row_number() over(partition by substring(create_time,0,10),team_id order by update_time desc) as rnk
         |	from dm_gis.ddjy_team_return_visit
         |	where inc_day in (select max(inc_day) as inc_day from dm_gis.ddjy_team_return_visit)
         |	and deleted='0'
         |) t1
         |where rnk=1
         |""".stripMargin)
    //修改inc_day = $o_week_day
    val o_rlst_di = spark.sql("select * from default.ddjy_test1")

    /*
        //修改inc_day = $o_week_day
        val temp_day="20230303"
        val sql=   s"""select credit_code tax_no,city_distribution,inc_day as inc_daya from dm_gis.dm_ddjy_carrier_rlst_di
                      |where inc_day='${temp_day}'
                      |and credit_code is not null and trim(credit_code) !=''
                      |""".stripMargin
        val o_rlst_di = spark.sql(sql)
        println("sql:")
        println(sql)

        o_rlst_di.show(10)

    */

    //9999 油站车队周维度聚合表(T-7 周更新-I增量) dm_ddjy_gas_carrier_merge_di  （stationname ---油站名称 	 credit_code--统一社会信用代码 one_carrier_gas_rank--车队推荐加油油站排序）
    //修改inc_day = $o_week_day
    val o_gas_merge = spark.sql(
      s"""select stationname,credit_code tax_no,one_carrier_gas_rank from dm_gis.dm_ddjy_gas_carrier_merge_di
         |where inc_day in (select max(inc_day) as inc_day from dm_gis.dm_ddjy_gas_carrier_merge_di)""".stripMargin)


    //111100000车队标签表(F全量)  dm_gis.ddjy_carteam_label
    //修改label_easy_rj
    val o_label = spark.sql(
      s"""select car_team_id team_id,max(label_easy_rj) label_easy from dm_gis.ddjy_carteam_label
         |where inc_day ='$inc_day' group by car_team_id""".stripMargin)
    //修改oil_dimension2获取

    //'$stat_day'
    val carteam_oil_dimension2 = spark.sql(
      s"""select car_team_id_dd team_id,oil_dimension2 from dm_gis.ddjy_carteam
         |where inc_day ='$stat_day' """.stripMargin)
      .withColumn("rank", row_number().over(Window.partitionBy("team_id").orderBy(desc("team_id"))))
      .filter($"rank"===1)
      .drop("rank")

    //====================================JOIN========================================================
    //-------------step1-------------------
    val chedui_sales_df = o_chedui.join(broadcast(o_sales), Seq("team_id", "inc_day"), "left")
      .join(broadcast(o_rlst_di), Seq("tax_no"), "left")
      .na.fill("", Seq("city_distribution"))
      //.withColumn("freq_city_distribution", getFreqCityUdf('city_distribution))
      .withColumn("freq_city_distribution", getFreq_udf('city_distribution))
      .withColumn("freq_city_distribution", regexp_replace(regexp_replace('freq_city_distribution, "\\(|\\)", ""), ",", ":"))
      .select("team_id", "name", "contact_name", "contact_phone", "user_name", "user_id", "sub_name", "sub_code", "sup_name", "sup_code", "freq_city_distribution", "inc_day","tax_no")


    /*val rec_stream_df = o_recharge.join(broadcast(o_plat_stream), Seq("team_id"), "left")
      .select("team_id", "cnt_trade_time", "total_trade_amount", "first_mon_trade_time")*/

    //-------------step2-------------------
    //从全量表中获取 已上线的油站信息
    val rec_statiton = o_gas_merge.join(broadcast(o_station), Seq("stationname"))
      .withColumn("rank",row_number().over(Window.partitionBy("grpid").orderBy(asc("station_type")) ))
      .filter($"rank"===1)
      .select("stationname", "tax_no", "one_carrier_gas_rank")


    val top_station_df = o_chedui.select("team_id", "tax_no").join(broadcast(rec_statiton), Seq("tax_no"), "left")
      .withColumn("num", row_number().over(Window.partitionBy("team_id").orderBy('one_carrier_gas_rank.cast("int"))))
      .filter('num <= 3)
      .groupBy("team_id")
      .agg(concat_ws(";", collect_list("stationname")) as "top_stationname")
      .select("team_id", "top_stationname")

    //-------------step3-------------------
    //截至筛选时间，车队消费总额
    val money_order_df = o_order.select("team_id", "ft_sale_money", "pay_time")
      .groupBy("team_id")
      .agg(
        sum('ft_sale_money) as "total_ft_sale_money"
      ).select("team_id", "total_ft_sale_money")

    //-------------step4-------------------
    //城市维度  历史累积的订单量 及 当天订单量
    val station_order_cnt_df = o_order.select("team_id", "station_id", "ft_sale_money", "order_sn", "inc_day")
      .join(broadcast(o_station), Seq("station_id"), "left")
      .groupBy("team_id", "city_name")
      .agg(
        sum("ft_sale_money") as "total_ft_sale_money",
        count("order_sn") as "total_cnt_order_sn"
      )
      .withColumn("total_city_ft_sale_money", concat_ws(":", 'city_name, 'total_ft_sale_money))
      .withColumn("total_city_order_cnt", concat_ws(":", 'city_name, 'total_cnt_order_sn))
      .groupBy("team_id")
      .agg(
        concat_ws(";", collect_list("total_city_ft_sale_money")) as "total_city_ft_sale_money",
        concat_ws(";", collect_list("total_city_order_cnt")) as "total_city_order_cnt"
      ).select("team_id", "total_city_order_cnt", "total_city_ft_sale_money")

    val day_city_order_df = o_order.filter('inc_day === inc_day)
      .join(broadcast(o_station), Seq("station_id"), "left")
      .select("team_id", "city_name", "order_sn")
      .groupBy("team_id", "city_name")
      .agg(count("order_sn") as "day_cnt_order_sn")
      .withColumn("day_city_order_cnt", concat_ws(":", 'city_name, 'day_cnt_order_sn))
      .groupBy("team_id")
      .agg(concat_ws(";", collect_list("day_city_order_cnt")) as "day_city_order_cnt")
      .select("team_id", "day_city_order_cnt")



    //历史全量加油站all_station_info
    val all_station_df = o_order.select("team_id", "grpid_new", "order_sn")
      .groupBy("team_id", "grpid_new")
      .agg(
        count('order_sn) as "order_sn_cnt"
      )
      .withColumn("gripid_ordercnt", concat_ws(":", 'grpid_new, 'order_sn_cnt))
      .groupBy("team_id")
      .agg(concat_ws(";", collect_list("gripid_ordercnt")) as "all_station_info_temp")
      .withColumn("all_station_info",getall_station_udf($"all_station_info_temp"))
      .select("team_id", "all_station_info_temp","all_station_info")

    /*
    //获取历史主要加油站
    val station_money_df = o_order.select("team_id", "station_id", "station_name", "order_sn")
      .groupBy("team_id", "station_id", "station_name")
      .agg(
        count('station_id) as "station_id_cnt",
        count('order_sn) as "order_sn_cnt"
      )
      .withColumn("num", row_number().over(Window.partitionBy("team_id").orderBy(desc("station_id_cnt"))))
      .filter('num <= 3)
      .withColumn("top_station_info", concat_ws(":", 'station_name, 'order_sn_cnt))
      .groupBy("team_id")
      .agg(concat_ws(";", collect_list("top_station_info")) as "top_station_info")
      .select("team_id", "top_station_info")
   */
    // 取订单表的最后一个名称
    val last_stationname=o_order.withColumn("rank", row_number().over(Window.partitionBy("grpid_new").orderBy(desc("pay_time"))))
      .filter($"rank"===1)
      .select("grpid_new","station_name")
    //获取 历史主要加油站
    val station_money_df = o_order.select("team_id", "station_id", "grpid_new", "order_sn")
      .groupBy("team_id", "grpid_new")
      .agg(
        count('order_sn) as "order_sn_cnt"
      )
      .withColumn("num", row_number().over(Window.partitionBy("team_id").orderBy(desc("order_sn_cnt"))))
      .filter('num <= 3)
      .join(last_stationname,Seq("grpid_new"),"left")
      .withColumn("top_station_info_tmp", concat_ws(":", 'station_name, 'order_sn_cnt))
      .groupBy("team_id")
      .agg(concat_ws(";", collect_list("top_station_info_tmp")) as "top_station_info")
      .select("team_id", "top_station_info")
    /*
        val o_order = spark.sql( //pay_time 2023-02-06 00:07:00
          s"""select car_team_id team_id,station_id,station_name,order_sn,ft_sale_money,pay_time,inc_day,grpid
             | from dm_gis.ddjy_dwd_station_order_pay_repartition_di
             |where inc_day between '$o_day' and '$inc_day' and order_status='2' and petrol_resources='2'""".stripMargin)
          .persist(StorageLevel.MEMORY_AND_DISK_SER)
        */

    //结果条件拼接
    val res_cols = spark.sql(s"""select * from dm_gis.ddjy_dwd_team_quota_dtl limit 0""").schema.map(_.name).map(col)
    val p5_infos_str = splitFun("&&")('team_id_label_info)
    var res_df: DataFrame = null
    val today_df: DataFrame = chedui_sales_df
      //.join(broadcast(o_bill), Seq("team_id"), "left")
      .join(broadcast(o_recharge), Seq("team_id"), "left")
      .join(broadcast(top_station_df), Seq("team_id"), "left")
      .join(broadcast(money_order_df), Seq("team_id"), "left")
      .join(broadcast(station_order_cnt_df), Seq("team_id"), "left")
      .join(broadcast(day_city_order_df), Seq("team_id"), "left")
      .join(broadcast(station_money_df), Seq("team_id"), "left")
      .join(broadcast(o_label), Seq("team_id"), "left")
      .join(carteam_oil_dimension2, Seq("team_id"), "left")
      .join(broadcast(all_station_df), Seq("team_id"), "left")
      .join(carrier_rlst_di, Seq("tax_no"), "left")
      .join(o_seven_plat_stream, Seq("team_id"), "left")
      .join(o_plat_stream, Seq("team_id"), "left")
      .join(vehicle_week_cnt_df, Seq("team_id"), "left")
      .join(clue_follow_up_df, Seq("name"), "left")
      //.join(o_day_plat_stream, Seq("team_id"), "left")
      .join(o_plat_stream_month, Seq("team_id"), "left")
      .na.fill("", Seq("first_trade_time", "first_pay_time", "last_pay_time", "city_last_pay_time", "team_id_label", "total_city_ft_sale_money", "city_and_last_pay_time","online_gas_top10","whitelist_limit_individual","whitelist_limit_corporate","consume_carplate_aggr"))
      .na.fill("0.0", Seq("total_ft_sale_money","online_gas_match_rate"))
      .withColumn("oil_dimension2",when($"oil_dimension2".isNull || trim($"oil_dimension2")==="" || trim($"oil_dimension2")==="inf",99999.00).otherwise($"oil_dimension2"))
      .withColumn("statistical_day", lit(inc_day.substring(0, 4) + "-" + inc_day.substring(4, 6) + "-" + inc_day.substring(6, 8)))
      .join(intend_grade_df, Seq("team_id","statistical_day"), "left")
      .join(recall_filling_df, Seq("team_id","statistical_day"), "left")
      .join(return_visit_df, Seq("team_id","statistical_day"), "left")
      .withColumn("max_consume_carplate_aggr_seven",'max_vehicle_week_cnt)
      .withColumn("inc_day", lit(inc_day))
    today_df.filter('team_id==="1685521048441303042").show(10,false)
    if (if_first_day == "Y") {
      val first_df: DataFrame = today_df
        .drop("max_consume_carplate_aggr_seven")
        .withColumn("max_consume_carplate_aggr_seven", 'max_vehicle_week_cnt)
      res_df = isOffRequota(spark, first_df, p5_infos_str, res_cols)
    }

    /**
     * 第1天数据---全部为无标签数据
     * 第2+数据--分为4部分，逻辑单独处理
     * （1）比第1天新增车队信息---完全走原始逻辑即可 1/2
     * （2）两天同份数据，但是【已关闭】的任务，标签替换 1/2
     * （3）两天同份数据，但是【满足】车队任务关闭的车队---部分标签更换 1/2 * 1/2
     * （4）两天同份数据，但是【不满足】车队任务关闭的车队---直接原始逻辑 1/2 * 1/2
     */
    if (if_first_day == "N") {
      val close_filter_1_cond = 'task_type.isin("充值-超7天未消费", "流失客户") && dealPayTime('last_pay_time) === inc_day
      val close_filter_2_cond = 'task_type === "注册-超7天未充值" && 'first_trade_time =!="" && 'first_trade_time.isNotNull
      val close_filter_cond = close_filter_1_cond || close_filter_2_cond
      val select_cols = Seq("team_id", "team_id_label", "task_type", "close_time", "run_off_citys", "consumption_citys", "task_status", "city_ft_sale_money_ratio", "start_time", "is_off").map(col)

      val yesday_df = spark.sql(s"""select * from dm_gis.ddjy_dwd_team_quota_dtl where inc_day = '$days_1_ago'""".stripMargin)
      val yesday_no_df = yesday_df.filter('is_off === "否").select(select_cols: _*).withColumn("yes_team_id", 'team_id).persist(StorageLevel.MEMORY_AND_DISK_SER)
      val yesday_yes_df = yesday_df.filter('is_off === "是").persist(StorageLevel.MEMORY_AND_DISK_SER)
      val yesday_aggr_seven_df: DataFrame = yesday_df
        .withColumn("max_consume_carplate_aggr_seven_yes",'max_consume_carplate_aggr_seven)
        .withColumn("is_off_yes",'is_off)
        .withColumn("intend_grade_yes",'intend_grade)
        .withColumn("lost_reason_yes",'lost_reason)
        .withColumn("recal_wish_yes",'recal_wish)
        .withColumn("communication_yes",'communication)
        .withColumn("recall_day_yes",'recall_day)
        .select("team_id", "max_consume_carplate_aggr_seven_yes","is_off_yes","close_time","intend_grade_yes","lost_reason_yes","recal_wish_yes","communication_yes","recall_day_yes")

      //1 将is_off = 是 的数据 单独取出
      val close_df_1 = yesday_yes_df
        .withColumn("statistical_day", lit(inc_day.substring(0, 4) + "-" + inc_day.substring(4, 6) + "-" + inc_day.substring(6, 8)))
        .withColumn("inc_day", lit(inc_day))
        //初始化task_type_code
        .withColumn("task_type_code",lit(""))
        .select(res_cols: _*)

      val today_com_yesday_df = today_df.join(yesday_no_df.select("yes_team_id").distinct(), expr("team_id = yes_team_id"), "left").persist(StorageLevel.MEMORY_AND_DISK_SER)
      //2 相比于昨天 新增车队信息
      val today_add_df = today_com_yesday_df.filter('yes_team_id.isNull)
        .withColumn("team_id_label_info", getTeamLabelUdf('first_trade_time, 'first_pay_date, 'last_pay_time, 'city_and_last_pay_time, 'inc_day,'total_end_balance,'team_create_date))
        .withColumn("team_id_label", p5_infos_str(0))
        //.withColumn("team_id_label",'tag)
        .withColumn("run_off_citys", p5_infos_str(1))
        .withColumn("consumption_citys", getConsumptionCitys('total_city_ft_sale_money))
        .withColumn("city_ft_sale_money_ratio", getCityRatioUdf('total_city_ft_sale_money, 'total_ft_sale_money))
        .withColumn("task_type", getTaskType('team_id_label, 'oil_dimension2, 'label_easy))
        .na.fill("", Seq("task_type"))
        .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
        .withColumn("start_time", getStartTimeUdf('task_type, 'last_trade_date, 'last_pay_time, 'team_create_date))
        .withColumn("task_status", lit("未闭环"))
        .withColumn("close_time", lit(""))
        .withColumn("is_recharge", lit(""))
        .withColumn("is_consume", lit(""))
        .na.fill("", Seq("start_time", "close_time"))
        .withColumn("close_cycle", lit(""))
        .withColumn("after_close_station", lit(""))
        .withColumn("after_close_recharge", lit(""))
        .withColumn("after_close_order", lit(""))
        .withColumn("after_close_gmv", lit(""))
        .withColumn("after_close_city_gmv", lit(""))
        .withColumn("prob_reason", lit(""))
        .withColumn("prob_descrip", lit(""))
        .withColumn("is_off", lit("否"))
        //初始化task_type_code
        .withColumn("task_type_code",lit(""))
        .select(res_cols: _*)

      //2 相比于昨天 相同车队信息
      val today_same_yes_df = today_com_yesday_df.filter('yes_team_id.isNotNull)
      //今天和昨天完全一致的数据量 需要对标签进行判断(yes_today_df 包含的字段：正常今天的字段 +  昨天的部分判断字段)
      val today_need_rejudge_df = today_same_yes_df.join(yesday_no_df.drop("yes_team_id"), Seq("team_id"), "left")

      val yesday_closed_df = today_need_rejudge_df.filter('is_off === "否" && 'task_status === "已闭环")
        .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
        .na.fill("", Seq("start_time", "close_time"))
        .withColumn("close_cycle", getCloseCycleUdf('start_time, 'close_time))
        .withColumn("prob_reason", lit(""))
        .withColumn("prob_descrip", lit("")).persist(StorageLevel.MEMORY_AND_DISK_SER)

      val yesday_closed_remark_df = processMultiDf_is_Close(spark, yesday_closed_df, o_order, o_recharge_initial, o_station, res_cols, inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)
      //已闭合满7天的数据 当天即 重派任务
      val if_off_closed_df = yesday_closed_remark_df.filter('is_off === "是").select("team_id")
      val remark_if_off_closed_df = today_df.join(if_off_closed_df,Seq("team_id"))
      val today_if_off_closed_remark_df = isOffRequota(spark, remark_if_off_closed_df, p5_infos_str, res_cols)

      //未闭环的数据
      val today_close_1_df = today_need_rejudge_df.filter('is_off === "否" && 'task_status === "未闭环").filter(close_filter_cond)
        .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
        .withColumn("task_status", lit("已闭环"))
        .withColumn("close_time", lit(inc_day))
        .withColumn("is_recharge", getIsRechargeUdf('task_type, 'last_trade_date, 'close_time))
        .withColumn("is_consume", getIsConsumeUdf('task_type, 'last_pay_time, 'close_time))
        .na.fill("", Seq("start_time", "close_time"))
        .withColumn("close_cycle", getCloseCycleUdf('start_time, 'close_time))
        .withColumn("prob_reason", lit(""))
        .withColumn("prob_descrip", lit("")).persist(StorageLevel.MEMORY_AND_DISK_SER)
      val part_3_1_df = processMultiDf_no_Close(spark, today_close_1_df, o_order, o_recharge_initial, o_station, res_cols, inc_day)

      val today_no_close_df = today_need_rejudge_df.filter('is_off === "否" && 'task_status === "未闭环").filter(!close_filter_cond)
        .withColumn("team_id_label_info", getTeamLabelUdf('first_trade_time, 'first_pay_date, 'last_pay_time, 'city_and_last_pay_time, 'inc_day,'total_end_balance,'team_create_date))
        .withColumn("team_id_label", p5_infos_str(0))
        //.withColumn("team_id_label",'tag)
        .withColumn("run_off_citys", p5_infos_str(1))
        .withColumn("consumption_citys", getConsumptionCitys('total_city_ft_sale_money))
        .withColumn("city_ft_sale_money_ratio", getCityRatioUdf('total_city_ft_sale_money, 'total_ft_sale_money))
        .withColumn("task_type", getTaskType('team_id_label, 'oil_dimension2, 'label_easy))
        .na.fill("", Seq("task_type"))
        .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
        .withColumn("start_time", getStartTimeUdf('task_type, 'last_trade_date, 'last_pay_time, 'team_create_date))
        //第1天 能打上4类标签的数据 均未闭环
        .withColumn("task_status", lit("未闭环"))
        .withColumn("close_time", lit(""))
        .na.fill("", Seq("start_time", "close_time"))
        .withColumn("close_cycle", lit(""))
        .withColumn("is_recharge", lit(""))
        .withColumn("is_consume", lit(""))
        .withColumn("after_close_station", lit(""))
        .withColumn("after_close_recharge", lit(""))
        .withColumn("after_close_order", lit(""))
        .withColumn("after_close_gmv", lit(""))
        .withColumn("after_close_city_gmv", lit(""))
        .withColumn("prob_reason", lit(""))
        .withColumn("prob_descrip", lit(""))
        .withColumn("is_off", lit("否"))
        //初始化task_type_code
        .withColumn("task_type_code",lit(""))
        .select(res_cols: _*)
      val showList1 = List("签约未充值-7天内", "充值未消费-小额充值", "充值未消费-7天内", "正常消费-7天内消费")
      val showList2 = List("签约未充值-超7天","充值未消费-超7天","流失客户-7天未消费","充值未消费-账户为0")
      val mid_df: DataFrame = close_df_1.union(today_add_df).union(today_no_close_df).union(yesday_closed_remark_df).union(part_3_1_df).union(today_if_off_closed_remark_df)
        .withColumn("num", row_number().over(Window.partitionBy("team_id", "start_time", "close_time", "is_off").orderBy("inc_day")))
        .withColumn("oil_dimension2", when($"oil_dimension2".isNull || trim($"oil_dimension2") === "" || trim($"oil_dimension2") === "inf", 99999.00).otherwise($"oil_dimension2"))
        .withColumn("task_type_code", when($"task_type" === "流失客户", "3").when($"task_type" === "充值-超7天未消费", "4")
          .when($"task_type" === "超7天未充值", "5")
          .otherwise("")
        )
      val no_off_df = mid_df.filter('is_off === "否")
        .join(yesday_aggr_seven_df.drop("close_time").filter('is_off_yes==="否"),Seq("team_id"),"left")
        .withColumn("max_consume_carplate_aggr_seven",
          when('max_consume_carplate_aggr_seven.isNotNull && 'max_consume_carplate_aggr_seven_yes.isNull ,'max_consume_carplate_aggr_seven)
            .when('max_consume_carplate_aggr_seven.isNotNull && 'max_consume_carplate_aggr_seven_yes.isNotNull && 'max_consume_carplate_aggr_seven.cast("int")>'max_consume_carplate_aggr_seven_yes.cast("int"),'max_consume_carplate_aggr_seven)
            .when('max_consume_carplate_aggr_seven.isNotNull && 'max_consume_carplate_aggr_seven_yes.isNotNull && 'max_consume_carplate_aggr_seven.cast("int")<='max_consume_carplate_aggr_seven_yes.cast("int"),'max_consume_carplate_aggr_seven_yes)
            .when('max_consume_carplate_aggr_seven.isNull && 'max_consume_carplate_aggr_seven_yes.isNotNull,'max_consume_carplate_aggr_seven_yes)
            .otherwise(null)
        )
        .withColumn("intend_grade",'intend_grade)
        .withColumn("lost_reason",when('team_id_label_show.isin(showList1:_*),"")
          .when('team_id_label_show.isin(showList2:_*),'lost_reason))
        .withColumn("recal_wish",when('team_id_label_show.isin(showList1:_*),"")
          .when('team_id_label_show.isin(showList2:_*),'recal_wish))
        .withColumn("communication",when('team_id_label_show.isin(showList1:_*),'remark)
          .when('team_id_label_show.isin(showList2:_*),'communication))
        .withColumn("recall_day",when('team_id_label_show.isin(showList1:_*),'visit_day)
          .when('team_id_label_show.isin(showList2:_*),'recall_day))
        .select(res_cols: _*)
      val off_df = mid_df.filter('is_off==="是")
        .join(yesday_aggr_seven_df,Seq("team_id","close_time"),"left")
          .withColumn("max_consume_carplate_aggr_seven",
            when('is_off_yes==="是",'max_consume_carplate_aggr_seven_yes)
            .when('is_off_yes==="否" && 'max_consume_carplate_aggr_seven.isNotNull && 'max_consume_carplate_aggr_seven_yes.isNotNull && 'max_consume_carplate_aggr_seven.cast("int")>'max_consume_carplate_aggr_seven_yes.cast("int"),'max_consume_carplate_aggr_seven)
            .when('is_off_yes==="否" && 'max_consume_carplate_aggr_seven.isNotNull && 'max_consume_carplate_aggr_seven_yes.isNotNull && 'max_consume_carplate_aggr_seven.cast("int")<='max_consume_carplate_aggr_seven_yes.cast("int"),'max_consume_carplate_aggr_seven_yes)
            .otherwise(null)
          )
          .withColumn("intend_grade",'intend_grade_yes)
          .withColumn("lost_reason",'lost_reason_yes)
          .withColumn("recal_wish",'recal_wish_yes)
          .withColumn("communication",'communication_yes)
          .withColumn("recall_day",'recall_day_yes)
          .select(res_cols: _*)
      res_df = off_df.union(no_off_df).distinct().select(res_cols: _*)
    }
    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.ddjy_dwd_team_quota_dtl")
    o_chedui.unpersist()
    o_order.unpersist()
    o_recharge_initial.unpersist()
    o_station.unpersist()
  }

  def isOffRequota(spark: SparkSession, df: DataFrame, p5_infos_str: Column, res_cols: Seq[Column]): DataFrame = {
    import spark.implicits._
    val res_df = df
      .withColumn("team_id_label_info", getTeamLabelUdf('first_trade_time, 'first_pay_date, 'last_pay_time, 'city_and_last_pay_time, 'inc_day,'total_end_balance,'team_create_date))
      .withColumn("team_id_label", p5_infos_str(0))
      //.withColumn("team_id_label",'tag)
      .withColumn("run_off_citys", p5_infos_str(1))
      .withColumn("consumption_citys", getConsumptionCitys('total_city_ft_sale_money))
      .withColumn("city_ft_sale_money_ratio", getCityRatioUdf('total_city_ft_sale_money, 'total_ft_sale_money))
      .withColumn("task_type", getTaskType('team_id_label, 'oil_dimension2, 'label_easy))
      .na.fill("", Seq("task_type"))
      .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
      .withColumn("start_time", getStartTimeUdf('task_type, 'last_trade_date, 'last_pay_time, 'team_create_date))
      //第1天 能打上4类标签的数据 均未闭环
      .withColumn("task_status", lit("未闭环"))
      .withColumn("close_time", lit(""))
      .withColumn("is_recharge", lit(""))
      .withColumn("is_consume", lit(""))
      .na.fill("", Seq("start_time", "close_time"))
      .withColumn("close_cycle", lit(""))
      .withColumn("after_close_station", lit(""))
      .withColumn("after_close_recharge", lit(""))
      .withColumn("after_close_order", lit(""))
      .withColumn("after_close_gmv", lit(""))
      .withColumn("after_close_city_gmv", lit(""))
      .withColumn("prob_reason", lit(""))
      .withColumn("prob_descrip", lit(""))
      .withColumn("is_off", lit("否"))
      //初始化task_type_code
      .withColumn("task_type_code",lit(""))
      .select(res_cols: _*)
    res_df
  }

  def processMultiDf_is_Close(spark: SparkSession, today_close_df: DataFrame, o_order: DataFrame, o_recharge_initial: DataFrame, o_station: DataFrame, res_cols: Seq[Column], inc_day: String): DataFrame = {
    import spark.implicits._
    val days_8_ago = getdaysBeforeOrAfter(inc_day, -8)
    val close_order_df = o_order.filter('inc_day >= days_8_ago && 'inc_day <= inc_day)
      .join(today_close_df.select("team_id", "close_time"), Seq("team_id"))
      .filter('inc_day >= 'close_time).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val recharge_df = o_recharge_initial.filter('inc_day >= days_8_ago && 'inc_day <= inc_day)
      .join(today_close_df.select("team_id", "close_time"), Seq("team_id"))
      .filter('inc_day >= 'close_time)

    val after_close_order_df = close_order_df
      .groupBy("team_id")
      .agg(
        concat_ws(";", collect_set('station_name)) as "after_close_station",
        count("order_sn") as "after_close_order",
        sum("ft_sale_money") as "after_close_gmv"
      ).select("team_id", "after_close_station", "after_close_order", "after_close_gmv")


    val after_close_city_gmv_df = close_order_df
      .join(o_station.select("station_id", "city_name"), Seq("station_id"))
      .groupBy("team_id", "city_name")
      .agg(
        sum("ft_sale_money") as "tmp_ft_sale_money"
      )
      .withColumn("after_close_city_gmv", concat_ws(":", 'city_name, 'tmp_ft_sale_money))
      .groupBy("team_id").agg(concat_ws(";", collect_set('after_close_city_gmv)) as "after_close_city_gmv")
      .select("team_id", "after_close_city_gmv")

    val close_recharge_cnt = recharge_df
      .filter(getFilterCloseUdf('trade_time, 'close_time) === true)
      .groupBy("team_id")
      .agg(
        count("trade_time") as "after_close_recharge"
      ).select("team_id", "after_close_recharge")

    val yesday_closed_remark_df = today_close_df
      .join(broadcast(after_close_order_df), Seq("team_id"), "left")
      .join(broadcast(after_close_city_gmv_df), Seq("team_id"), "left")
      .join(broadcast(close_recharge_cnt), Seq("team_id"), "left")
      .withColumn("is_recharge", getIsRechargeUdf('task_type, 'last_trade_date, 'close_time))
      .withColumn("is_consume", getIsConsumeUdf('task_type, 'last_pay_time, 'close_time))
      .withColumn("is_off", getIsOffUdf('task_status, 'close_time, 'inc_day))
      //初始化task_type_code
      .withColumn("task_type_code",lit(""))
      .select(res_cols: _*)

    yesday_closed_remark_df
  }


  def processMultiDf_no_Close(spark: SparkSession, today_close_df: DataFrame, o_order: DataFrame, o_recharge_initial: DataFrame, o_station: DataFrame, res_cols: Seq[Column], inc_day: String): DataFrame = {
    import spark.implicits._
    val close_order_df = o_order.filter('inc_day === inc_day).join(today_close_df.select("team_id"), Seq("team_id")).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val recharge_df = o_recharge_initial.filter('inc_day === inc_day).join(today_close_df.select("team_id"), Seq("team_id"))
    val after_close_order_df = close_order_df
      .groupBy("team_id")
      .agg(
        concat_ws(";", collect_set('station_name)) as "after_close_station",
        count("order_sn") as "after_close_order",
        sum("ft_sale_money") as "after_close_gmv"
      ).select("team_id", "after_close_station", "after_close_order", "after_close_gmv")


    val after_close_city_gmv_df = close_order_df
      .join(o_station.select("station_id", "city_name"), Seq("station_id"))
      .groupBy("team_id", "city_name")
      .agg(
        sum("ft_sale_money") as "tmp_ft_sale_money"
      )
      .withColumn("after_close_city_gmv", concat_ws(":", 'city_name, 'tmp_ft_sale_money))
      .groupBy("team_id").agg(concat_ws(";", collect_set('after_close_city_gmv)) as "after_close_city_gmv")
      .select("team_id", "after_close_city_gmv")

    val close_recharge_cnt = recharge_df
      .withColumn("close_time", lit(inc_day))
      .filter(getFilterCloseUdf('trade_time, 'close_time) === true)
      .groupBy("team_id")
      .agg(
        count("trade_time") as "after_close_recharge"
      ).select("team_id", "after_close_recharge")

    val part_3_df = today_close_df
      .join(broadcast(after_close_order_df), Seq("team_id"), "left")
      .join(broadcast(after_close_city_gmv_df), Seq("team_id"), "left")
      .join(broadcast(close_recharge_cnt), Seq("team_id"), "left")
      .withColumn("is_off", getIsOffUdf('task_status, 'close_time, 'inc_day))
      //初始化task_type_code
      .withColumn("task_type_code",lit(""))
      .select(res_cols: _*)

    part_3_df
  }


  def dealPayTime(last_pay_time: Column): Column = {
    //格式切换 last_pay_time 2023-02-07 03:40:26  20230207
    regexp_replace(substring(last_pay_time, 0, 10), "-", "")
  }

  def getConsumptionCitys = udf((total_city_ft_sale_money: String) => {
    val arr_buf = new ArrayBuffer[String]()
    if (strNotNull(total_city_ft_sale_money)) {
      val aa_arr = total_city_ft_sale_money.split(";")
      for (i <- 0 until (aa_arr.length)) {
        arr_buf += aa_arr(i).split(":")(0)
      }
    }
    arr_buf.mkString(";")
  })

  def getCityRatioUdf = udf((total_city_ft_sale_money: String, total_ft_sale_money: String) => {
    val arr_buf = new ArrayBuffer[String]()
    if (strNotNull(total_city_ft_sale_money) && total_ft_sale_money.toDouble > 0) {
      val aa_arr = total_city_ft_sale_money.split(";")
      for (i <- 0 until aa_arr.length) {
        val city = aa_arr(i).split(":")(0)
        val money = try {
          aa_arr(i).split(":")(1)
        } catch {
          case e: Exception => "0.0"
        }
        if (total_ft_sale_money.toDouble > 0) {
          val money_ratio = money.toDouble / total_ft_sale_money.toDouble
          arr_buf += (city + ":" + money_ratio)
        }
      }
    }
    arr_buf.mkString(";")
  })

  def getIsOffUdf = udf((task_status: String, close_time: String, inc_day: String) => {
    var is_off = "否"
    if (strNotNull(close_time)) {
      if (daysBetweenDate(close_time, inc_day) >= 7 && task_status == "已闭环") {
        is_off = "是"
      }
    }
    is_off
  })

  def getFilterCloseUdf = udf((pay_time: String, close_time: String) => {
    var res: Boolean = false
    var ft_pay_time = ""
    val after_7_days = getDaysApartDate("yyyyMMdd", close_time, 7)
    if (strNotNull(pay_time)) {
      ft_pay_time = pay_time.substring(0, 10).replaceAll("-", "")
    }
    if (ft_pay_time > close_time && ft_pay_time < after_7_days) {
      res = true
    }
    res
  })

  def getCloseCycleUdf = udf((start_time: String, close_time: String) => {
    var close_cycle = ""
    if (strNotNull(close_time) && strNotNull(start_time)) {
      close_cycle = daysBetweenDate(close_time, start_time).toString
    }
    close_cycle
  })

  def getStartTimeUdf = udf((task_type: String, last_trade_date: String, last_pay_date: String, team_create_date: String) => {
    var start_time = ""
    if (strNotNull(task_type)) {
      if (task_type == "充值-超7天未消费") {
        val ft_trade_time = last_trade_date.replaceAll("-", "")
        start_time = getDaysApartDate("yyyyMMdd", ft_trade_time, 7)
      } else if (task_type == "流失客户") {
        val ft_pay_date = last_pay_date.replaceAll("-", "")
        start_time = getDaysApartDate("yyyyMMdd", ft_pay_date, 7)
      } else if (task_type == "注册-超7天未充值") {
        if (StringUtils.isNoneEmpty(team_create_date)){
          val ft_create_date = team_create_date.replaceAll("-", "")
          start_time = getDaysApartDate("yyyyMMdd", ft_create_date, 7)
        }
      }
    }
    start_time
  })

  def getTaskType = udf((team_id_label: String, oil_dimension2: String, label_easy: String) => {
    var task_type = ""
    if (team_id_label == "流失客户-7天未消费") {
      task_type = "流失客户"
    } else if (team_id_label == "充值未消费-超7天") {
      task_type = "充值-超7天未消费"
    } else if (team_id_label == "签约未充值-超7天") {
      task_type = "注册-超7天未充值"
    }
    task_type
  })

  def getUnconsumDaysUdf = udf((first_trade_time: String, last_pay_time: String, inc_day: String) => {
    var unconsum_days, ft_trade_time, ft_pay_time = ""
    if (strNotNull(first_trade_time)) {
      if (strNotNull(last_pay_time)) {
        ft_pay_time = last_pay_time.substring(0, 10).replaceAll("-", "")
        unconsum_days = daysBetweenDate(ft_pay_time, inc_day).toString
      } else {
        ft_trade_time = first_trade_time.substring(0, 10).replaceAll("-", "")
        unconsum_days = daysBetweenDate(ft_trade_time, inc_day).toString
      }
    }
    unconsum_days
  })
  def getIsRechargeUdf = udf((task_type: String, last_trade_date: String, close_time: String) => {
    val exclude_quota = Seq("流失客户", "充值-超7天未消费", "注册-超7天未充值")
    var is_recharge = ""
    if (exclude_quota.contains(task_type)) {
      if (close_time > last_trade_date.replaceAll("-", "")) {
        is_recharge = "否"
      } else {
        is_recharge = "是"
      }
    }
    is_recharge
  })

  def getIsConsumeUdf = udf((task_type: String, last_pay_date: String, close_time: String) => {
    val exclude_quota = Seq("流失客户", "充值-超7天未消费", "注册-超7天未充值")
    var is_recharge = ""
    if (exclude_quota.contains(task_type)) {
      if (close_time > last_pay_date.replaceAll("-", "")) {
        is_recharge = "否"
      } else {
        is_recharge = "是"
      }
    }
    is_recharge
  })
  /**
   * 用户标签带出  城市city_name维度标签
   *
   * @return
   */
  def getTeamLabelUdf = udf((first_trade_time: String, first_pay_time: String, last_pay_time: String, city_and_last_pay_time: String, inc_day: String,total_end_balance:String,team_create_date:String) => {
    var team_id_label, city_team_id_label, ft_trade_time, ft_first_pay_time, ft_last_pay_time,first_trade_date,first_pay_date,last_pay_date = ""
    val lose_city = new ArrayBuffer[String]()

    if (StringUtils.isNoneEmpty(first_trade_time)) ft_trade_time = first_trade_time.substring(0, 10).replaceAll("-", "")
    if (StringUtils.isNoneEmpty(first_pay_time)) ft_first_pay_time = first_pay_time.substring(0, 10).replaceAll("-", "")
    if (StringUtils.isNoneEmpty(last_pay_time)) ft_last_pay_time = last_pay_time.substring(0, 10).replaceAll("-", "")
    val check_trade_days = daysBetweenDate(ft_trade_time, inc_day)
    val check_last_pay_days = daysBetweenDate(ft_last_pay_time, inc_day)

    if (StringUtils.isNoneEmpty(city_and_last_pay_time)) {
      val date_arr = city_and_last_pay_time.split(";")
      var flag = true
      for (i <- 0 until date_arr.length) {
        try {
          val city = date_arr(i).split(":")(0)
          val day = date_arr(i).split(":")(1).replaceAll("-", "")
          val city_inter = daysBetweenDate(day, inc_day)
          if (city_team_id_label != "城市流失预警" && day != "" && city_inter >= 7 && flag) {
            city_team_id_label = "城市流失"
            flag = false
          }
          if (city_team_id_label != "城市流失预警" && day != "" && city_inter >= 7) {
            lose_city += city
          }
          if (city_team_id_label != "城市流失" && day != "" && city_inter >= 5 && city_inter < 7 && flag) {
            city_team_id_label = "城市流失预警"
            flag = false
          }
          if (city_team_id_label != "城市流失" && city_inter >= 5 && city_inter < 7) {
            lose_city += city
          }
        } catch {
          case e: Exception => ""
        }
      }
    }
    if (StringUtils.isNoneEmpty(first_trade_time)) first_trade_date = first_trade_time.substring(0, 10).replace("-", "")
    var trade_diff:Long = -1
    if (StringUtils.isNoneEmpty(first_trade_date)){
      trade_diff = DateUtil.daysDiff(first_trade_date, inc_day)
    }

    if (StringUtils.isNoneEmpty(first_pay_time)) first_pay_date = first_pay_time.substring(0, 10).replace("-", "")
    if (StringUtils.isNoneEmpty(last_pay_time))  last_pay_date = last_pay_time.substring(0, 10).replace("-", "")
    var last_pay_diff:Long = -1
    if (StringUtils.isNoneEmpty(last_pay_date)){
      last_pay_diff = DateUtil.daysDiff(last_pay_date, inc_day)
    }
    var create_diff:Long = -1
    if (StringUtils.isNoneEmpty(team_create_date)){
      create_diff = DateUtil.daysDiff(team_create_date, inc_day)
    }
    var end_balance:Double=0.0
    if (StringUtils.isNoneEmpty(total_end_balance)){
      end_balance=total_end_balance.toDouble
    }
    if (create_diff < 7 && create_diff != -1 && StringUtils.isEmpty(first_trade_date)) {
      team_id_label = "签约未充值-7天内"
    } else if (create_diff >= 7 && StringUtils.isEmpty(first_trade_date)) {
      team_id_label = "签约未充值-超7天"
    } else if (StringUtils.isNoneEmpty(first_trade_date) && StringUtils.isEmpty(first_pay_date) && end_balance == 0.0) {
      team_id_label = "充值未消费-账户为0"
    } else if (trade_diff >= 7 && StringUtils.isEmpty(first_pay_date) && end_balance > 0.0) {
      team_id_label = "充值未消费-超7天"
    } else if (StringUtils.isNoneEmpty(first_trade_date) && StringUtils.isEmpty(first_pay_date) && end_balance > 0.0 && end_balance <= 1000) {
      team_id_label = "充值未消费-小额充值"
    } else if (trade_diff < 7 && trade_diff != -1 && StringUtils.isEmpty(first_pay_date) && end_balance > 1000) {
      team_id_label = "充值未消费-7天内"
    } else if (StringUtils.isNoneEmpty(first_pay_date) && last_pay_diff >= 7) {
      team_id_label = "流失客户-7天未消费"
    } else if (StringUtils.isNoneEmpty(first_pay_date) && last_pay_diff < 7 && last_pay_diff != -1) {
      team_id_label = "正常消费-7天内消费"
    }
    /*if (ft_trade_time != "") {
      if (ft_first_pay_time == "" && check_trade_days > 5) {
        team_id_label = "超5天未消费"
      } else if (ft_first_pay_time != "" && check_last_pay_days >= 7) {
        team_id_label = "平台流失"
      } else if (city_team_id_label == "城市流失") {
        team_id_label = "城市流失"
      } else if (ft_first_pay_time != "" && check_last_pay_days >= 5 && check_last_pay_days < 7) {
        team_id_label = "平台流失预警"
      } else if (city_team_id_label == "城市流失预警") {
        team_id_label = "城市流失预警"
      } else if (ft_first_pay_time == "" && check_trade_days > 3 && check_trade_days <= 5) {
        team_id_label = "未消费预警"
      } else if (ft_first_pay_time == "" && check_trade_days <= 3) {
        team_id_label = "暂未消费新客"
      } else {
        team_id_label = "稳定消费"
      }
    }*/
    team_id_label + "&&" + lose_city.mkString(",")
  })

  def getFreq(city_distribution: String) :String={
    var freq_city = "" //city_distribution（东莞市:1.0、惠州市:12.0、河源市:2.0、河源aaa:1.0、河源市rr:0.0、河源市2323:9.0）
    if (!city_distribution.isEmpty && city_distribution.trim != "") {
      val city_arr = city_distribution.split("、")
      val cnt_city = new mutable.HashMap[String, Double]()
      //val cnt_city: ListBuffer[String] = new ListBuffer[String]
      for (i <- 0 until city_arr.length) {
        val city_name = city_arr(i).split(":")(0)
        var city_cnt: Double = 0.0
        try {
          city_cnt = city_arr(i).split(":")(1).toDouble
        } catch {
          case e: Exception => ""
        }
        cnt_city.put(city_name, city_cnt)
      }
      val xx=cnt_city.toList
      val yy=xx.sortBy(x=>{x._2}).reverse
      freq_city=yy.mkString(";")
        //freq_city = cnt_city.toArray.sortBy(x=>{x._2}).reverse.mkString(";")
        .replaceAll("\\(","")
        .replaceAll("\\)","")
        .replaceAll("\\,",":")
    }
    freq_city
  }

  val getFreq_udf=udf(getFreq _)

  //全量加油站排序

  def getall_station(all_station_info_temp: String) :String={
    var freq_city = "" //all_station_info_temp（asa:1;dfdf:12;ghgh:2;jkjkjk:1）
    if (!all_station_info_temp.isEmpty && all_station_info_temp.trim != "") {
      val city_arr = all_station_info_temp.split(";")
      val cnt_city = new mutable.HashMap[String, Int]()
      //val cnt_city: ListBuffer[String] = new ListBuffer[String]
      for (i <- 0 until city_arr.length) {
        val city_name = city_arr(i).split(":")(0)
        var city_cnt: Int = 0
        try {
          city_cnt = city_arr(i).split(":")(1).toInt
        } catch {
          case e: Exception => ""
        }
        cnt_city.put(city_name, city_cnt)
      }
      val xx=cnt_city.toList
      val yy=xx.sortBy(x=>{x._2}).reverse
      freq_city=yy.mkString(";")
        .replaceAll("\\(","")
        .replaceAll("\\)","")
        .replaceAll("\\,",":")
    }
    freq_city
  }

  val getall_station_udf=udf(getall_station _)

  def getFreqCityUdf = udf((city_distribution: String) => {
    var freq_city = "" //city_distribution（东莞市:1.0、惠州市:12.0、河源市:2.0）
    if (!city_distribution.isEmpty && city_distribution.trim != "") {
      val city_arr = city_distribution.split("、")
      val cnt_city = new mutable.HashMap[String, Double]()
      for (i <- 0 until city_arr.length) {
        val city_name = city_arr(i).split(":")(0)
        var city_cnt: Double = 0.0
        try {
          city_cnt = city_arr(i).split(":")(1).toDouble
        } catch {
          case e: Exception => ""
        }
        cnt_city.put(city_name, city_cnt)
      }
      val cnt_city_arr = filterSort(cnt_city, Ordering.Double.reverse, Ordering.String)
      freq_city = cnt_city_arr.mkString(";")
    }
    freq_city
  })
  def grpidProcess=udf((grpid: String)=> {
    var tmpGrpid=grpid
    if (grpid==null){
      tmpGrpid=""
    }
    if (tmpGrpid.startsWith("cft_")){
      tmpGrpid = tmpGrpid.replace("cft_","")
    }else if(tmpGrpid.startsWith("ty_")){
      tmpGrpid = tmpGrpid.replace("ty_","")
    }else if(tmpGrpid.startsWith("fhm_")){
      tmpGrpid = tmpGrpid.replace("fhm_","")
    }else if(tmpGrpid.startsWith("ylk_")){
      tmpGrpid = tmpGrpid.replace("ylk_","")
    }else if(tmpGrpid.startsWith("JT_")){
      tmpGrpid = tmpGrpid.replace("JT_","")
    }
    tmpGrpid.replaceAll("_","")
  })

  def aggrConsumeCarplate = udf((consume_carplate_aggr: String) => {
    val caplateArray = new ArrayBuffer[String]()
    val consume_carplate_aggr_arr: Array[String] = consume_carplate_aggr.split(",")
    for (elem <- consume_carplate_aggr_arr) {
      caplateArray.append(elem)
    }
    val caplateSize: Int = caplateArray.distinct.size
  })

  /**
   * 自定义排序：map指定排序字段及顺序
   *
   * @param hm
   * @param order1
   * @param order2
   * @return
   */
  def filterSort(hm: mutable.HashMap[String, Double], order1: Ordering[Double] = Ordering.Double.reverse, order2: Ordering[String] = Ordering.String): Array[(String, Double)] = {
    hm.filter(!_._1.equals("0")).toArray
      .sortBy(x => (x._2, x._1))(Ordering.Tuple2(order1, order2))
  }

  //定义函数存入数据
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  def strNotNull(str: String): Boolean = {
    !str.isEmpty && str.trim != ""
  }

  def strHandle(str: String, sep: String, flag: Boolean = true): Array[String] = {
    var res: Array[String] = Array()
    try {
      if (flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep)
      //是否需要排序
      if (!flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep).sortWith(_.compareTo(_) < 0)
    } catch {
      case e: NullPointerException => logger.error("原始数据为空" + e.getMessage)
      case e: ArrayIndexOutOfBoundsException => logger.error("指标越界" + e.getMessage)
    }
    res
  }

  //对返回的5类数据切分
  def splitFun(sep: String) = udf((ds_tl_infos: String) => {
    var res: Array[String] = Array()
    try {
      if (strNotNull(ds_tl_infos)) {
        res = strHandle(ds_tl_infos, sep)
      }
    } catch {
      case e: Exception => logger.error("101 检查返回的结果值", e)
    }
    res
  })

  val sdf_inc = FastDateFormat.getInstance("yyyyMMdd")
  val MS_PERDAY = 1000 * 60 * 60 * 24

  def daysBetweenDate(start_day: String, end_day: String): Int = {
    var day: Int = 0
    try {
      val start = sdf_inc.parse(start_day)
      val end = sdf_inc.parse(end_day)
      day = if (end.getTime - start.getTime >= 0) ((end.getTime - start.getTime) / MS_PERDAY).toInt else ((start.getTime - end.getTime) / MS_PERDAY).toInt //20220101-20220116  一起16天
    } catch {
      case e: Exception => logger.error("检查传入日期格式" + e.getMessage)
    }
    day
  }

  def getDaysApartDate(dateFormat: String, inputDateStr: String, days: Integer): String = {
    val simpleDateFormat = new SimpleDateFormat(dateFormat)
    val inputDate: Date = simpleDateFormat.parse(inputDateStr)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDate)
    calendar.add(Calendar.DAY_OF_YEAR, days)
    val date = calendar.getTime
    val dateStr = simpleDateFormat.format(date).trim
    dateStr
  }

  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime())
  }

}