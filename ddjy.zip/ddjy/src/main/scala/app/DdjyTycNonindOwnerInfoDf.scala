package app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.HttpInvokeUtil
import common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DateUtil, SparkUtils,StringUtils}

import java.util


/**
 *需求名称：GIS-RSS-DDJY：【吨吨加油】天眼查非个体企业信息数据需求_V1.0
 *需求方： 周邦耀(ft220622)
 *研发： 蔡国房(01420395)
 *任务创建时间：20231218
 *任务id：944302
 **/
object DdjyTycNonindOwnerInfoDf extends DataSourceCommon {

  val className: String = this.getClass.getSimpleName.replace("$", "")

  var url  = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get"

  val ak = "156402fd097d4ff59779181139f59887"
  val tableName = "dm_gis.ddjy_tyc_nonind_owner_info_df"

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkUtils.getSparkSession(className,"yarn")
    //获取T-1日期
    val inc_day: String = args(0)
    var startBatch: Int = 0

    if(args.length>1 && !StringUtils.isEmpty(args(1))){
      startBatch =  args(1).toInt
    }

    for (batch  <- startBatch.until(100)){

      logger.error("开始批次: " +  batch )

      val (ddjyTycOwnerInfoDF,sourceDF) = getddjyTycOwnerInfo(spark, batch)
      val GisDistricDF = getGisDistric(spark)

      import spark.implicits._
      val gtsourceDF = sourceDF.filter('company_org_type_clean =!="个体工商户")


      val resultDF =  getddjy_tyc_nonind_owner_info_df(spark,ddjyTycOwnerInfoDF,gtsourceDF,GisDistricDF,inc_day).union(sourceDF.filter('company_org_type_clean ==="个体工商户"))
        .withColumn("batch",lit("%04d".format(batch)))

      logger.error("数据量: " + resultDF.count())

      writeToHive(spark,resultDF, Seq("inc_day","batch"),tableName)

      //更新前一天的数据

      //    取dm_gis.ddjy_tyc_owner_info_df表最新分区company_org_type_clean != ‘个体工商户’数据，左关联结果表 dm_gis.ddjy_tyc_nonind_owner_info_df上一分区，
      // 关联字段：左表credit_code = 右表credit_code。
      //    取右表credit_code is not null ,所有字段 union all
      //    右表credit_code is null,执行上述1-5步骤操作，获取左表city、province更新后的所有字段。
      //    更新分区为dm_gis.ddjy_tyc_owner_info_df表最新分区


      //获取上一分区的数据

      val ddjy_tyc_nonind_owner_info_Sql  =
        s"""
           |
           |select  max(inc_day) as inc_day from  dm_gis.ddjy_tyc_nonind_owner_info_df  where inc_day < '${inc_day}'
           |
           |""".stripMargin

      val ddjy_tyc_nonind_owner_info_df = spark.sql(ddjy_tyc_nonind_owner_info_Sql)


      val max_inc_day  = ddjy_tyc_nonind_owner_info_df.collectAsList().get(0).getAs[String]("inc_day")
      if(!StringUtils.isEmpty( max_inc_day)){
        val ddjy_tyc_nonind_owner_info_sql1  =
          s"""
             |
             |select *  from  dm_gis.ddjy_tyc_nonind_owner_info_df  where inc_day =  '${max_inc_day}' and  batch = '${batch}'
             |""".stripMargin

        val ddjy_tyc_nonind_owner_info_df1 = spark.sql(ddjy_tyc_nonind_owner_info_sql1)

        logger.error("ddjy_tyc_nonind_owner_info_sql1 " + ddjy_tyc_nonind_owner_info_sql1)


        val  jionDF  = sourceDF.select("credit_code")
          .join(ddjy_tyc_nonind_owner_info_df1, Seq("credit_code"),"left")

        logger.error("jionDF  " + jionDF.count())

        val noNeedHttpDF=  jionDF.filter(ddjy_tyc_nonind_owner_info_df1("credit_code")=!= null)
        val needHttpDF=  jionDF.filter(ddjy_tyc_nonind_owner_info_df1("credit_code")=== null)


        val  needHttpDF1 = builderDDjyTycOwner(spark,needHttpDF)

        import spark.implicits._

        val resultDF1 =  getddjy_tyc_nonind_owner_info_df(spark,needHttpDF1.select(
          'credit_code
          ,'reg_location
          ,'name
          ,'city
          ,'city_code
          ,'credit_code_result
        ),needHttpDF,GisDistricDF,inc_day)

        val resulte2 =  noNeedHttpDF.union(resultDF1)
          .withColumn("inc_day", lit(inc_day))
          .withColumn("batch",lit("%04d".format(batch)))

        writeToHive(spark,resulte2, Seq("inc_day", "batch"),tableName)

        spark.close()
      }
      logger.error("完成批次: " +  batch )
    }

  }


  def getddjy_tyc_nonind_owner_info_df(spark: SparkSession , ddjyTycOwnerInfoDF:DataFrame, sourceDF:DataFrame, GisDistricDF:DataFrame,inc_day:String ):DataFrame ={

    import spark.implicits._
    //    1. credit_code reg_location name city city_code credit_code_result
    //    2. city_code city_name name province_name
    val joinDF = ddjyTycOwnerInfoDF.join(GisDistricDF, Seq("city_code"), "left")


    val jsonDF = SparkUtils.getRowToJson(joinDF,"")


    val resultDF = jsonDF.map(row => {
      val city_name = row.getString("city_name")
      val city = row.getString("city")
      val province_name = row.getString("province_name")

      if ( !StringUtils.isEmpty(city_name) && city_name.equalsIgnoreCase(city)) {
        row.put("status", 1)
        row.put("credit_city", city)
        row.put("credit_province", province_name)
        row.put("province_http", province_name)
        row.put("city_http", city)
        row.put("city_1_http", "")
        row.put("status_http", "")
      }else{
        //调用接口获取对应数据
        row.put("status", 0)
        row.put("credit_city", "")
        row.put("credit_province", "")
        row.put("province_http", "")
        row.put("city_http", "")
        row.put("city_1_http", "")
        row.put("status_http", "")
      }
      row
    })

    //需要进行接口访问的数据
    val noDeedHttpJson = resultDF.filter(row => {
      row.getInteger("status") == 1
    })

    //需要进行接口访问的数据
    val needHttpJson = resultDF.filter(row => {
      row.getInteger("status") == 0
    }).repartition(100)

    //第一次使用接口
    val limitMin = 10000

    logger.error("需要调用量: " + needHttpJson.count())


    val startTime  = System.currentTimeMillis()
    val ddjyTycOwnerInfoResponseJson1  = SparkUtils.akLimitMultiThreadRdd(needHttpJson)(getDdjyTycOwnerInfoDF)(limitMin,100).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("返回数据条数 : " + ddjyTycOwnerInfoResponseJson1.count() )

    logger.error("耗时 : " + (System.currentTimeMillis() - startTime ))

    //ddjyTycOwnerInfoDF1 数据一分为2 , 返回成功并且城市[1]不为空,

    val  ddjyTycOwnerInfoResponseJson11 = ddjyTycOwnerInfoResponseJson1.filter(row  => {
      val status_http  = row.getString("status_http")
      "0".equalsIgnoreCase(status_http)
    }).map(row => {
      getProvinceCityByResponse(row)
    })

    ddjyTycOwnerInfoResponseJson11.foreach(println(_))

    val  ddjyTycOwnerInfoResponseJson12 = ddjyTycOwnerInfoResponseJson1.filter(row  => {
      val status_http = row.getString("status_http")
      val province_http = row.getString("province_http")
      "1".equalsIgnoreCase(status_http) || StringUtils.isEmpty(province_http)
    }).map(row => {
      row.put("reg_location",row.getString("name"))
      row
    }).repartition(100)


    val ddjyTycOwnerInfoResponseJson2  = SparkUtils.akLimitMultiThreadRdd(ddjyTycOwnerInfoResponseJson12)(getDdjyTycOwnerInfoDF)(limitMin,100).persist(StorageLevel.MEMORY_AND_DISK_SER)


    val  ddjyTycOwnerInfoResponseJson21 = ddjyTycOwnerInfoResponseJson2.filter(row  => {
      val status_http  = row.getString("status_http")
      "0".equalsIgnoreCase(status_http)
    }).map(row => {
      getProvinceCityByResponse(row)
    })


    val  ddjyTycOwnerInfoResponseJson22 = ddjyTycOwnerInfoResponseJson2.filter(row  => {
      val status_http = row.getString("status_http")
      val province_http = row.getString("province_http")
      "1".equalsIgnoreCase(status_http) || StringUtils.isEmpty(province_http)
    }).map(row => {

      val city_name = row.getString("city_name")
      val province_name = row.getString("province_name")
      row.put("credit_city",city_name)
      row.put("credit_province",province_name)
      row
    })


    val  result = noDeedHttpJson.union(ddjyTycOwnerInfoResponseJson11).union(ddjyTycOwnerInfoResponseJson21).union(ddjyTycOwnerInfoResponseJson22)

      .map(row =>{
        val  credit_code  = row.getString("credit_code")
        val reg_location  = row.getString("reg_location")
        val name  = row.getString("name")
        val city  = row.getString("city")
        val city_code   = row.getString("city_code")
        val credit_code_result   = row.getString("credit_code_result")
        val city_name   = row.getString("city_name")
        val province_name   = row.getString("province_name")
        val status   = row.getString("status")
        val credit_city   = row.getString("credit_city")
        val credit_province   = row.getString("credit_province")
        val province_http  = row.getString("province_http")
        val city_http   = row.getString("city_http")
        val city_1_http   = row.getString("city_1_http")
        val status_http   = row.getString("status_http")
        (credit_code, reg_location, name, city, city_code, credit_code_result, city_name, province_name, status, credit_city, credit_province, province_http
          , city_http, city_1_http, status_http)
      })


    //    1. credit_code reg_location name city city_code credit_code_result
    //    2. city_code city_name name province_name

    //转成对应的df对象
    val resultdf =  spark.createDataFrame(result)
      .toDF("credit_code","reg_location","name","city", "city_code", "credit_code_result", "city_name", "province_name",
        "status", "credit_city", "credit_province", "province_http", "city_http", "city_1_http", "status_http")


    println("resultdf" + resultdf.count())


    val resultdf1 =  resultdf.select("credit_code","credit_city","credit_province")

    println("resultdf1 " + resultdf1.count())

    val resultJoinDF1  = sourceDF.join(resultdf1,Seq("credit_code"),"left")


    val resultJoinDF2 = resultJoinDF1
      .withColumn("province",'credit_province)
      .withColumn("city",'credit_city)
      .withColumn("inc_day",lit(inc_day))
      .withColumn("etl_time",lit(DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")))
      .withColumn("rn", row_number() over(Window.partitionBy('credit_code ).orderBy(desc("province"))))

    val resultJoinDF3 = resultJoinDF2.filter('rn  ===1)
      .select('owner_id,
        'credit_code,
        'name,
        'company_org_type_clean,
        'legal_person_name,
        'content,
        'city_adcode,
        'source_time,
        'type,
        'business_scope,
        'src,
        'city_code,
        'reg_location,
        'postal_address,
        'aoiid,
        'aoi_code,
        'aoi_name,
        'x,
        'y,
        'province,
        'city,
        'postal_province,
        'postal_city,
        'postal_city_adcode,
        'postal_aoiid,
        'postal_aoi_code,
        'postal_aoi_name,
        'postal_x,
        'postal_y,
        'postal_city_code,
        'etl_time,
        'inc_day)

    resultJoinDF3.persist(StorageLevel.MEMORY_AND_DISK)

    resultJoinDF3

  }





  /**
   * 全量接口返回解析
   * @param x
   * @return
   */

  def getProvinceCityByResponse(row:JSONObject):JSONObject = {
    val status_http = row.getString("status_http")
    val province_http = row.getString("province_http") //0
    val city_http = row.getString("city_http") //1
    val city_1_http = row.getString("city_1_http") //2

    //3
    if ("0".equalsIgnoreCase(status_http)) {
      //若status= 0 & result[adname][1] != ‘’ ,credit_city = result[adname][1]，credit_province = result[adname][0]
      if (!StringUtils.isEmpty(city_http)) {
        row.put("credit_city", city_http)
        row.put("credit_province", province_http)
      } else {
        //若status = 0 & result[adname][1] = ‘’ & result[adname][0] !=’’ & result[adname][0] in [‘北京市’,’上海市’,’重庆市’,’天津市’]，credit_city = result[adname][0]，credit_province = result[adname][0]；
        val provinceList = Seq("北京市", "上海市", "重庆市", "天津市")
        if (!StringUtils.isEmpty(province_http)) {
          if (provinceList.contains(province_http)) {
            logger.error("==========================" +  province_http )
            row.put("credit_province", province_http)
            row.put("credit_city", province_http)

            //若status = 0 & result[adname][1] = ‘’ & result[adname][0] !=’’ & result[adname][0] not in [‘北京市’,’上海市’,’重庆市’,’天津市’]，credit_city = result[adname][2]，credit_province = result[adname][0]；
          } else {
            row.put("credit_city", city_1_http)
            row.put("credit_province", province_http)
          }
        }
      }
    }
    row
  }





  /**
   * 全量接口返回解析
   * @param x
   * @return
   */

  def getDdjyTycOwnerInfoDF(x:JSONObject):JSONObject = {

    val  reg_location = x.getString("reg_location")
    val postJson   = new util.HashMap[String , String]()
    postJson.put("address",reg_location)
    postJson.put("ak",ak)
    postJson.put("url","http://gis-int.int.sfdc.com.cn:1080/geo/api")

    // 地址获取省市信息
    //    val response = SparkUtils.doPost(url,postJson,logger,ak)
    logger.error("请求数据:" + postJson )
    val response =HttpInvokeUtil.sendPost(url,postJson.toString,3)
    logger.error("返回数据:" + response )
    val responseJSON = try {JSON.parseObject(response)} catch {case e:Exception => new JSONObject()}

    val json = try {parseResponse(x,responseJSON)} catch {case e:Exception => new JSONObject()}
    logger.error("解析的数据"+ json)

    json
  }




  def parseResponse(x: JSONObject, response:JSONObject) = {

    val status = response.getString("status")
    x.put("status_http", status)

    val result = response.getJSONObject("result")
    if("0".equals(status)){
      val adnames  = result.getJSONArray("adname")
      val province =  adnames.getString(0)
      val city =  adnames.getString(1)
      val city_1 =  adnames.getString(2)
      x.put("province_http", province)
      x.put("city_http", city)
      x.put("city_1_http", city_1)
    }
    x
  }





  //获取dm_gis.ddjy_tyc_owner_info_df表最新分区
  def getGisDistric(sparkSession: SparkSession): DataFrame = {

    val gisDistricSql =
      s"""
         | select distinct  city_code,city_name,province_name from dm_gis.gis_district where inc_day  in (select max(inc_day) from dm_gis.gis_district)
         |""".stripMargin

    val gisDistricDF = sparkSession.sql(gisDistricSql)

    gisDistricDF

  }


  //获取dm_gis.ddjy_tyc_owner_info_df表最新分区
  def getddjyTycOwnerInfo(sparkSession: SparkSession, batch: Int): (DataFrame,DataFrame) ={

    val ddjyTycOwnerInfoSql  =
      s"""
        |select owner_id,
        |credit_code
        |,name
        |,company_org_type_clean
        |,legal_person_name
        |,content
        |,city_adcode
        |,source_time
        |,type
        |,business_scope
        |,src
        |,city_code
        |,reg_location
        |,postal_address
        |,aoiid
        |,aoi_code
        |,aoi_name
        |,x
        |,y
        |,province
        |,city
        |,postal_province
        |,postal_city
        |,postal_city_adcode
        |,postal_aoiid
        |,postal_aoi_code
        |,postal_aoi_name
        |,postal_x
        |,postal_y
        |,postal_city_code
        |,inc_day
        |from dm_gis.ddjy_tyc_owner_info_df where inc_day  in (select max(inc_day) from dm_gis.ddjy_tyc_owner_info_df)
        | and ABS(HASH(credit_code)%100) = ${batch}
        |""".stripMargin



    logger.error("ddjyTycOwnerInfoSql" +  ddjyTycOwnerInfoSql)

    val ddjyTycOwnerInfoDF =  sparkSession.sql(ddjyTycOwnerInfoSql)

    ddjyTycOwnerInfoDF.persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("ddjyTycOwnerInfoDF" +  ddjyTycOwnerInfoDF.count())

    import sparkSession.implicits._
    val  resultDF = builderDDjyTycOwner(sparkSession,ddjyTycOwnerInfoDF)

    logger.error("resultDF" +  resultDF.count())


    (resultDF.select(
      'credit_code
      ,'reg_location
      ,'name
      ,'city
      ,'city_code
      ,'credit_code_result
    ),ddjyTycOwnerInfoDF)

  }

  def builderDDjyTycOwner(sparkSession: SparkSession , ddjyTycOwnerInfoDF: DataFrame)={

    import sparkSession.implicits._
    val ddjyTycOwnerInfoDF1 = ddjyTycOwnerInfoDF.select('credit_code,'reg_location,'name,'city, 'city_code).withColumn("reg_location", when ('reg_location isNull,'name).otherwise('reg_location))


    // 根据credit_code去重，优先获取 name、reg_location都不为null的一条数据，其次获取name不为null的一条数据，否则随机获取一条数据，取去重后的credit_code、reg_location、name、city作为临时表A
    //以credit_code开窗函数, 并且以name , regLoaction 排序 todo 注意 null排序的顺序 是放到最大还是最小
    val  ddjyTycOwnerInfoDF_1 =  ddjyTycOwnerInfoDF1
      .withColumn("rn",row_number() over(Window.partitionBy('credit_code).orderBy(desc("name"),desc("reg_location"))))
      .filter('rn ===1)


    //    截取credit_code第3-4位，substring(credit_code, 3, 2) ，若in ('11','31','12','50'),截取3-4位，并补充’0100’,concat(substring(credit_code,3,2),'0100')；
    //    否则截取第3-6位，substring(credit_code, 3, 4)，若in('4290','4690','6590'),截取第3-8位，substring(credit_code, 3, 6)；
    //    若不在，截取第3-6位，补2个’0’至6位，concat(substring(credit_code,3,4),'00')。
    val ddjyTycOwnerInfoDF_2=  ddjyTycOwnerInfoDF_1
      .withColumn("credit_code_3", substring('credit_code, 3, 2))
      .withColumn("credit_code_6", substring('credit_code, 3, 4))
    import org.apache.spark.sql.functions._


    val resultDF= ddjyTycOwnerInfoDF_2
      .withColumn("credit_code_result",when('credit_code_3==="11" ||'credit_code_3==="31" || 'credit_code_3==="12" || 'credit_code_3==="50" ,concat(substring('credit_code,3,2),lit("0100")))
        .when('credit_code_6==="4290" || 'credit_code_6==="4690" || 'credit_code_6==="6590" , substring('credit_code, 3, 6) )
        .otherwise(concat(substring('credit_code,3,4),lit("00"))))
      .withColumn("city_code",'credit_code_result)

    resultDF

  }

}