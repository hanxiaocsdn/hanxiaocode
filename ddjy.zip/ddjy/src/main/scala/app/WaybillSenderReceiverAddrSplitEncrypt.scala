package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkWrite}

/**
 * @Description:车队名称分词和电话加密
 * 需求人员：
 * @Author: lixiangzhi 01405644
 * @Date:2023-08-10
 * 任务id:899
 * 任务名称：车队名称分词和电话加密
 * 依赖任务：898
 * 数据源：dm_ddjy_carrier_rlst_explode_di
 * 调用服务地址：http://10.119.82.211:5025/api/seg
 *             http://gis-int.int.sfdc.com.cn:1080/tals/tals/normalized?ak=%s&tel=%s&cityCode=
 * 数据结果：dwd_ddjy_carrier_name_participle_mi、dwd_ddjy_carrier_contactor_phone_encrypt_mi
 */
object WaybillSenderReceiverAddrSplitEncrypt {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readVehicleConcat(spark: SparkSession, incDay: String) = {
    val carrierRlstExplodeSql=
      s"""
        |select carrier_name as owner_name,phone as contactor_phone from dm_gis.dm_ddjy_carrier_rlst_explode_di where inc_day='$incDay'
        |""".stripMargin
    logger.error("carrierRlstExplodeSql:"+carrierRlstExplodeSql)
    val carrierRlstExplodeRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, carrierRlstExplodeSql)persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("carrierRlstExplode表数据量:"+carrierRlstExplodeRdd.count())
    carrierRlstExplodeRdd
  }

  def companySplit(spark: SparkSession, carrierRlstExplodeRdd: RDD[JSONObject], incDay: String) = {
    import spark.implicits._
    val cluePrepSql=
      s"""
        |select * from dm_gis.dwd_ddjy_carrier_name_participle_mi where inc_day in(select max(inc_day) from dm_gis.dwd_ddjy_carrier_name_participle_mi)
        |""".stripMargin
    val cluePrepRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, cluePrepSql).map(obj => {
      (obj.getString("owner_name"), obj)
    })
    val vehicleJoinClueRdd: RDD[JSONObject] = carrierRlstExplodeRdd.groupBy(_.getString("owner_name")).map(obj=>{
      val contactor_phone: String = obj._2.toList.map(_.getString("contactor_phone")).mkString(",")
      val tmpObj = new JSONObject()
      tmpObj.put("contactor_phone",contactor_phone)
      tmpObj.put("owner_name",obj._1)
      (tmpObj.getString("owner_name"), tmpObj)
    }).leftOuterJoin(cluePrepRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("province", rightObj.getString("province"))
        leftObj.put("city", rightObj.getString("city"))
        leftObj.put("district", rightObj.getString("district"))
        leftObj.put("street", rightObj.getString("street"))
        leftObj.put("community", rightObj.getString("community"))
        leftObj.put("main", rightObj.getString("main"))
        leftObj.put("industry", rightObj.getString("industry"))
        leftObj.put("suffix", rightObj.getString("suffix"))
        leftObj.put("sub_main", rightObj.getString("sub_main"))
        leftObj.put("sub_industry", rightObj.getString("sub_industry"))
        leftObj.put("sub_suffix", rightObj.getString("sub_suffix"))
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val nullVehicleJoinClueRdd: RDD[JSONObject] = vehicleJoinClueRdd.filter(_.getString("province") == null).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("需要调分词接口的数据量:"+nullVehicleJoinClueRdd.count())
    nullVehicleJoinClueRdd.take(10).foreach(println(_))
    val notNullVehicleJoinClueRdd: RDD[JSONObject] = vehicleJoinClueRdd.filter(_.getString("province") != null).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("不需要调分词接口的数据量:"+notNullVehicleJoinClueRdd.count())
    if (notNullVehicleJoinClueRdd!=null){

    }
    val companySplitDf: DataFrame = nullVehicleJoinClueRdd.repartition(30).map(obj => {
      val returnObj: JSONObject = SfNetInteface.companySplitInterface(obj)
      val result: JSONObject = JSONUtil.getJsonObjectMulti(returnObj, "api_result.result")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(result, "data")
      val province: String = data.getString("province")
      val city: String = data.getString("city")
      val district: String = data.getString("district")
      val street: String = data.getString("street")
      val community: String = data.getString("community")
      val mainPart: String = data.getString("mainPart")
      val industry: String = data.getString("industry")
      val suffix: String = data.getString("suffix")
      val branch_mainPart: String = data.getString("branch_mainPart")
      val branch_industry: String = data.getString("branch_industry")
      val branch_suffix: String = data.getString("branch_suffix")
      obj.put("province", province)
      obj.put("city", city)
      obj.put("district", district)
      obj.put("street", street)
      obj.put("community", community)
      obj.put("main", mainPart)
      obj.put("industry", industry)
      obj.put("suffix", suffix)
      obj.put("sub_main", branch_mainPart)
      obj.put("sub_industry", branch_industry)
      obj.put("sub_suffix", branch_suffix)
      obj
    }).union(notNullVehicleJoinClueRdd).map(obj=>{
      (
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("street"),
        obj.getString("community"),
        obj.getString("main"),
        obj.getString("industry"),
        obj.getString("suffix"),
        obj.getString("sub_main"),
        obj.getString("sub_industry"),
        obj.getString("sub_suffix")
      )
    }).toDF("owner_id","owner_name","contactor","contactor_phone","province","city","district","street","community","main","industry","suffix","sub_main","sub_industry","sub_suffix")
    SparkWrite.writeToHive(spark,companySplitDf,"inc_day",incDay,"dm_gis.dwd_ddjy_carrier_name_participle_mi")

  }

  def encryptPhone(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val companySplitSql=
      s"""
        |select *
        |from
        |(
        |	select *
        |	from dm_gis.dwd_ddjy_carrier_name_participle_mi
        |	where inc_day='$incDay'
        |) t1
        |lateral view explode(split(contactor_phone,',')) t2 as contactor_phone_ex
        |""".stripMargin
    //关联上周电话加密结果表数据，剔除已经加密的车队电话
    val encryptPhoneLastWeekSql=
      s"""
        |select * from dm_gis.dwd_ddjy_carrier_contactor_phone_encrypt_mi where inc_day in(select max(inc_day) from dm_gis.dwd_ddjy_carrier_contactor_phone_encrypt_mi)
        |""".stripMargin
    val encryptPhoneLastWeekRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, encryptPhoneLastWeekSql).map(obj => {
      ((obj.getString("owner_name"), obj.getString("contactor_phone")), obj)
    })
    val getLastWeekEncryptPhoneRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, companySplitSql).map(obj => {
      ((obj.getString("owner_name"), obj.getString("contactor_phone_ex")), obj)
    }).leftOuterJoin(encryptPhoneLastWeekRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("encrypt_phone", rightObj.getString("encrypt_phone"))
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //未关联上的车队电话，进行调加密接口
    val nullEncryptPhoneRdd: RDD[JSONObject] = getLastWeekEncryptPhoneRdd.filter(_.getString("encrypt_phone") == null)
    val phonePartRdd: RDD[JSONObject] = nullEncryptPhoneRdd.map(obj=>{
      obj.put("phone_part",obj.getString("contactor_phone_ex"))
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("encrypt_phone调加密接口的数据量:"+phonePartRdd.count())
    val httpEncryptPhone = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "899", "车队名称分词和电话加密", "电话号码加密", "http://gis-apis.int.sfcloud.local:1080/tals/tals/normalized?ak=%s&tel=%s&cityCode=", "95630c95a49f4ceca389c9bfa0fedd17", phonePartRdd.count(), 50)

    val returnEncryptPhoneRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, phonePartRdd, SfNetInteface.encryptPhoneInterface, 50, "95630c95a49f4ceca389c9bfa0fedd17", 3000)
    returnEncryptPhoneRdd.take(10).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpEncryptPhone)

    val encryptPhoneRdd: RDD[JSONObject] = returnEncryptPhoneRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val tels: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(result, "tels")
      val telNormalized: String = tels.getString("telNormalized")
      obj.put("encrypt_phone", telNormalized)
      obj.remove("api_result")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调解密接口后的数据量:"+encryptPhoneRdd.count())
    //关联上的车队电话
    val notNullEncryptPhoneRdd: RDD[JSONObject] = getLastWeekEncryptPhoneRdd.filter(_.getString("encrypt_phone") != null)
    //拼接掉解密接口的数据和关联上的数据
    val encryptPhoneDf: DataFrame = encryptPhoneRdd.union(notNullEncryptPhoneRdd).map(obj => {
      (
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("contactor"),
        obj.getString("phone_part"),
        obj.getString("encrypt_phone"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("street"),
        obj.getString("community"),
        obj.getString("main"),
        obj.getString("industry"),
        obj.getString("suffix"),
        obj.getString("sub_main"),
        obj.getString("sub_industry"),
        obj.getString("sub_suffix")
      )
    }).toDF("owner_id", "owner_name", "contactor", "contactor_phone", "encrypt_phone", "province", "city", "district", "street", "community", "main", "industry", "suffix", "sub_main", "sub_industry", "sub_suffix")
    SparkWrite.writeToHive(spark,encryptPhoneDf,"inc_day",incDay,"dm_gis.dwd_ddjy_carrier_contactor_phone_encrypt_mi")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val carrierRlstExplodeRdd: RDD[JSONObject] = readVehicleConcat(spark, incDay)
    //调公司分词接口
    companySplit(spark,carrierRlstExplodeRdd,incDay)
    //加密电话号码
    encryptPhone(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
}
