package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DistanceUtils}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkWrite}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
 * @Description:车队途径线索挖掘
 * 需求人员：刘芮 01412988
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2023/03/31
 * 任务id:721
 * 任务名称：车辆归属表调高德接口
 * 依赖任务：
 * 数据源：dim_ddjy_vehicle_concat_yy_df、dm_company_dtl、city_name_map、ddjy_sender_receiver_mining_statistics_df
 * 调用服务地址：
 * http://gis-gw.int.sfdc.com.cn:9080/transform/gd/queryPoi?keywords=%s&city=
 * 数据结果：gd_interface_return_pois_data_di
 */
object GdInterface {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def getVehicleMaxDay(spark: SparkSession, incDay: String) = {
    val vehicle_max_day_sql=
      s"""
         |select
         |max(inc_day) as vehicle_max_day
         |from dm_gis.dim_ddjy_vehicle_concat_yy_df
         |where inc_day<='$incDay'
         |""".stripMargin
    val vehicle_max_day_df: DataFrame = spark.sql(vehicle_max_day_sql)
    val vehicle_max_day: String = SparkUtils.getDfToJson(spark, vehicle_max_day_df).map(obj => {
      obj.getString("vehicle_max_day")
    }).collect().head
    logger.error("车辆所属车队维表数据分区最大值："+vehicle_max_day)
    vehicle_max_day
  }

  def getVehicleMaxDayData(spark: SparkSession, sat_day: String) = {
    val vehicle_max_day_sql=
      s"""
         |select
         |owner_id,owner_name,credit_code,province_name,city_name
         |from dm_gis.dim_ddjy_vehicle_concat_yy_df
         |where inc_day='$sat_day' and length(owner_name)>=5
         |group by owner_id,owner_name,credit_code,province_name,city_name
         |--limit 100
         |""".stripMargin
    /*val vehicle_max_day_sql=
      s"""
         |select
         |owner_id,owner_name,credit_code,province_name,city_name
         |from
         |(
         |	select
         |	owner_id,owner_name,credit_code,province_name,city_name
         |	from dm_gis.dim_ddjy_vehicle_concat_yy_df
         |	where inc_day='$vehicle_max_day'
         |  group by owner_id,owner_name,credit_code,province_name,city_name
         |) t1
         |join dm_gis.dim_circle_id_main_business_carrier_di t2
         |on t1.owner_id=t2.carrier_id
         |--where owner_id in ('63060','224683')
         |--limit 500
         |""".stripMargin*/
    val vehicleMaxDayDf: DataFrame = spark.sql(vehicle_max_day_sql)
    logger.error("车辆所属车队维表最大分区数据量："+vehicleMaxDayDf.count())
    vehicleMaxDayDf
  }


  def carrierGDAddressDetail(spark: SparkSession, vehicleMaxDayDf: DataFrame, incDay: String) = {
    import spark.implicits._
    val city_name_map_sql=
      s"""
         |select
         |city,citycode
         |from dm_gis.city_name_map
         |""".stripMargin
    val cityNameDf: DataFrame = spark.sql(city_name_map_sql)
    val cityNameMapRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, cityNameDf).map(obj => {
      (obj.getString("city"), obj)
    })
    val vehicleJoinCityNameRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).map(obj => {
      (obj.getString("city_name"), obj)
    }).leftOuterJoin(cityNameMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    })
    val ownerNameRdd: RDD[JSONObject] = vehicleJoinCityNameRdd.map(obj => {
      val tmpObj = new JSONObject()
      val owner_name: String = obj.getString("owner_name")
      val citycode: String = obj.getString("citycode")
      tmpObj.put("owner_name", owner_name)
      tmpObj.put("citycode", citycode)
      tmpObj
    }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("根据owner_name和citycode去重后数据量:"+ownerNameRdd.count())
    //调高德地址接口
    val httpGdAddresss = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "721", "车辆归属表调高德接口", "获取高德接口地址相关信息", "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/queryPoi?keywords=%s&city=", "4ef7ec53690d40baa4143855383af419", ownerNameRdd.count(), 50)

    val returnGdAddressRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, ownerNameRdd, SfNetInteface.gdAddresssInterface, 50, "4ef7ec53690d40baa4143855383af419", 2000)
    //returnGdAddressRdd.take(10).foreach(println(_))
    val gdAddressDetailRdd: RDD[JSONObject] = returnGdAddressRdd.repartition(200).flatMap(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val pois: JSONArray = JSONUtil.getJsonArrayMulti(result, "pois")
      val owner_name: String = obj.getString("owner_name")
      val citycode: String = obj.getString("citycode")
      val poisArr = new ArrayBuffer[JSONObject]()
      for (i <- 0 until (pois.size())) {
        val tmpObj: JSONObject = pois.getJSONObject(i)
        tmpObj.put("owner_name",owner_name)
        tmpObj.put("citycode",citycode)
        poisArr.append(tmpObj)
      }
      poisArr
    })
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpGdAddresss)

    val gdAddressDetailDf: DataFrame = gdAddressDetailRdd.map(obj => {
      val biz_ext: String = JSONUtil.getJsonObjectMulti(obj, "biz_ext").toJSONString
      val photos: String = JSONUtil.getJsonArrayMulti(obj, "photos").toJSONString
      GdInterfacePois(
        obj.getString("address"),
        obj.getString("pname"),
        biz_ext,
        obj.getString("cityname"),
        obj.getString("type"),
        photos,
        obj.getString("typecode"),
        obj.getString("shopinfo"),
        obj.getString("adname"),
        obj.getString("name"),
        obj.getString("location"),
        obj.getString("tel"),
        obj.getString("id"),
        obj.getString("owner_name"),
        obj.getString("citycode")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("车队返回高德地址明细表数据量:"+gdAddressDetailDf.count())
    SparkWrite.writeToHive(spark,gdAddressDetailDf,"inc_day",incDay,"dm_gis.gd_interface_return_pois_data_di")
    //gdAddressDetailDf.createOrReplaceTempView("gdAddressDetailTmp")
    //spark.sql(s"insert overwrite table dm_gis.gd_interface_return_pois_data_di partition(inc_day='$incDay') select * from gdAddressDetailTmp")
  }

  def execute(incDay:String,sat_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)

    //获取车辆所属车队维表分区最大值
    val vehicle_max_day: String = getVehicleMaxDay(spark, incDay)
    //读取车辆所属车队维表最大分区数据
    val vehicleMaxDayDf: DataFrame = getVehicleMaxDayData(spark, sat_day)
    //车队返回高德地址明细表
    carrierGDAddressDetail(spark, vehicleMaxDayDf, incDay)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val sat_day: String = args(1)
    execute(incDay,sat_day)
    logger.error("======>>>>>>VehicleClueDetail Execute Ok")
  }
  case class GdInterfacePois( address:String,
                              pname:String,
                              biz_ext:String,
                              cityname:String,
                              pois_type:String,
                              photos:String,
                              typecode:String,
                              shopinfo:String,
                              adname:String,
                              name:String,
                              location:String,
                              tel:String,
                              id:String,
                              owner_name:String,
                              citycode:String
                             )


}
