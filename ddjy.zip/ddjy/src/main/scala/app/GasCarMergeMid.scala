package app

import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:油站车辆融合中间表
 * 需求人员：娇悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2022/11/26
 * 任务id:523
 * 任务名称：油站车辆融合周维度表
 * 依赖任务：车辆经过油站频次线索422
 * 数据源：dm_ddjy_gas_station_info_di、ddjy_station_near_road_clue_di、join_clue_pathway_frequency_di、dwd_ddjy_carrier_info_seed、ddjy_ods_dim_team_info、dm_ddjy_carrier_rlst_di
 * 调用服务地址：无
 * 数据结果：join_clue_pathway_frequency_di
 */
object GasCarMergeMid {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def updateVehicleJoinCluePathwayFrequency(spark: SparkSession, max_day: String) = {
    val sat_day: String = DateUtil.getDateStr(max_day, 1, "")
    val start_day: String = DateUtil.getDateStr(max_day, -6, "")
    val icJoinCarrierYySql=
      s"""
         |select
         |poiid,frequency_tl,car_no,data_src,type,owner_id,owner_name
         |from
         |(
         |	select
         |	*
         |	from dm_gis.ddjy_vehicle_suspect_way_info_ic_di
         |	where inc_day>='${start_day}' and inc_day<='${max_day}'
         |) t1
         |left join
         |(
         |	select
         |	vehicle_no,owner_id,owner_name
         |	from dm_gis.dim_ddjy_vehicle_concat_yy_df
         |	where inc_day='${sat_day}'
         |) t2
         |on t1.car_no=t2.vehicle_no
         |""".stripMargin
    val icJoinCarrierYyDf: DataFrame = spark.sql(icJoinCarrierYySql)
    icJoinCarrierYyDf.createOrReplaceTempView("icJoinCarrierYyTmp")
    val icPassAndStopSql=
      s"""
         |select
         |poiid,stationname,owner_id,owner_name,pathway_task_count,pathway_around_task_count,stay_task_count,car_no
         |from
         |(
         |	select
         |	t3.poiid,stationname,owner_id,owner_name,pathway_task_count,pathway_around_task_count,stay_task_count,car_no,
         |	row_number() over(partition by t3.poiid,car_no order by pathway_task_count desc) as rnk
         |	from
         |	(
         |		select
         |		nvl(t1.poiid,t2.poiid) as poiid,
         |		nvl(t1.owner_id,t2.owner_id) as owner_id,
         |		nvl(t1.owner_name,t2.owner_name) as owner_name,
         |		nvl(t1.car_no,t2.car_no) as car_no,
         |		pathway_task_count,pathway_around_task_count,
         |		stay_task_count
         |		from
         |		(
         |			select
         |			poiid,owner_id,owner_name,car_no,
         |			sum(frequency_tl) as pathway_task_count,
         |			'' as pathway_around_task_count
         |			from icJoinCarrierYyTmp
         |			where type='PS'
         |			group by poiid,owner_id,owner_name,car_no
         |		) t1
         |		full join
         |		(
         |			select
         |			poiid,owner_id,owner_name,car_no,
         |			sum(frequency_tl) as stay_task_count
         |			from icJoinCarrierYyTmp
         |			where type='SP'
         |			group by poiid,owner_id,owner_name,car_no
         |		) t2
         |		on t1.poiid=t2.poiid
         |		and t1.owner_id=t2.owner_id
         |		and t1.owner_name=t2.owner_name
         |		and t1.car_no=t2.car_no
         |	) t3
         |	inner join
         |	(
         |		select
         |		poiid,stationname
         |		from dm_gis.dm_ddjy_gas_station_info_di
         |		where delflag = '0'
         |	) t4
         |	on t3.poiid=t4.poiid
         |) t5
         |where rnk=1
         |""".stripMargin
    val icPassAndStopDf: DataFrame = spark.sql(icPassAndStopSql)
    icPassAndStopDf.createOrReplaceTempView("icPassAndStopTmp")
    logger.error("正在执行 join_clue_pathway_frequency_di 任务.........")
    val join_clue_pathway_frequency_sql=
      s"""
        |select
        |nvl(t7.gas_id,t8.poiid) as gas_id,
        |nvl(t7.stationname,t8.stationname) as stationname,
        |nvl(t7.vehicle_no,t8.car_no) as vehicle_no,
        |clue_task_count,clue_dist_avg,
        |nvl(t7.pathway_task_count,t8.pathway_task_count) as pathway_task_count,
        |nvl(t7.pathway_around_task_count,t8.pathway_around_task_count) as pathway_around_task_count,
        |pathway_dist_avg,
        |nvl(t7.stay_task_count,t8.stay_task_count) as stay_task_count,
        |nvl(t7.carrier_id,t8.owner_id) as carrier_id,
        |nvl(t7.carrier_name,t8.owner_name) as carrier_name,
        |vehicle_pathway_cost
        |from
        |(
        |	select
        |	nvl(t5.gas_id,t6.gas_id) as gas_id,
        |	nvl(t5.stationname,t6.stationname) as stationname,
        |	nvl(t5.vehicle_no,t6.vehicle_no) as vehicle_no,
        |	clue_task_count,clue_dist_avg,pathway_task_count,pathway_around_task_count,pathway_dist_avg,
        |	stay_task_count,carrier_id,carrier_name,vehicle_pathway_cost
        |	from
        |	(
        |		select
        |		nvl(t3.gas_id,t4.gas_id) as gas_id,
        |		nvl(t3.stationname,t4.stationname) as stationname,
        |		nvl(t3.vehicle_no,t4.vehicle_no) as vehicle_no,
        |		clue_task_count,clue_dist_avg,pathway_task_count,pathway_around_task_count,pathway_dist_avg,carrier_id,carrier_name,vehicle_pathway_cost
        |		from
        |		(
        |			select t1.gas_id,t1.name_chn as stationname,t2.carrier_id,t2.carrier_name,t2.vehicle as vehicle_no,
        |			sum(t2.task_count) as clue_task_count,
        |			avg(t1.d_dist) as clue_dist_avg
        |			from
        |			(
        |				select clue_id,gas_id,name_chn,d_dist
        |				from dm_gis.dwd_ddjy_clue_rel_gas_station_di
        |				where inc_day = '${max_day}'
        |			) t1
        |			join
        |			(
        |				select clue_id,carrier_id,carrier_name,vehicle,task_count
        |				from dm_gis.dm_ddjy_clue_rel_car_di
        |				where inc_day = '${max_day}'
        |			) t2
        |			on t1.clue_id = t2.clue_id
        |			group by t1.gas_id,t1.name_chn,t2.carrier_id,t2.carrier_name,t2.vehicle
        |		) t3
        |		full join
        |		(
        |			select distinct poiid as gas_id,stationname,trackno as vehicle_no,priority_tj as pathway_task_count,
        |			priority_zb as pathway_around_task_count,
        |			dh_dist as pathway_dist_avg,
        |			dh_dist_sum as vehicle_pathway_cost
        |			from dm_gis.ddjy_station_pathway_statistic_clue_di
        |			where inc_day = '${max_day}'
        |			and trackno is not null and trackno != ''
        |		) t4
        |		on t3.gas_id=t4.gas_id and t3.vehicle_no=t4.vehicle_no
        |	) t5
        |	full join
        |	(
        |		select distinct poiid as gas_id,stationName,trackno as vehicle_no,frequency_tl as stay_task_count
        |		from dm_gis.ddjy_vehicle_way_frequency_di
        |		where inc_day = '${max_day}'
        |		and trackno is not null and trackno != ''
        |	) t6
        |	on t5.gas_id=t6.gas_id and t5.vehicle_no=t6.vehicle_no
        |) t7
        |full join icPassAndStopTmp t8
        |on t7.gas_id=t8.poiid and t7.vehicle_no=t8.car_no
        |""".stripMargin
    val join_clue_pathway_frequency_df: DataFrame = spark.sql(join_clue_pathway_frequency_sql)
    join_clue_pathway_frequency_df.repartition(10).createOrReplaceTempView("join_clue_pathway_frequency_tmp")
    spark.sql(s"insert overwrite table dm_gis.vehicle_join_clue_pathway_frequency_di partition(inc_day='${max_day}') select * from join_clue_pathway_frequency_tmp")

  }

  def execute(incDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val station_pathway_statistic_clue_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.dwd_ddjy_clue_rel_gas_station_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val station_pathway_statistic_clue_df: DataFrame = spark.sql(station_pathway_statistic_clue_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, station_pathway_statistic_clue_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    //车队停留油站频次表
    updateVehicleJoinCluePathwayFrequency(spark,max_day)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>GasCarMergeMid Execute Ok")
  }
}
