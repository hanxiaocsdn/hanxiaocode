package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:油站看板报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:391
 * 任务名称：油站看板报表
 * 依赖任务：订单支付时间重分区表 387、每日-原始油站信息过滤表 512
 * 数据源：ddjy_dwd_station_order_pay_repartition_di、ddjy_dim_station_info_filter
 * 调用服务地址：无
 * 数据结果：ddjy_uimp_dm_petrol_kanban_report
 */
object CollectionStationBoardData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String) = {
    val petrol_kanban_df: DataFrame = spark.sql(
      s"""
         |select
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |t1.station_id,
         |create_day,
         |round(nvl(agg_ft_sale_money,0.00),2) as agg_ft_sale_money,
         |nvl(agg_order_cnt,0) as agg_order_cnt,
         |round(nvl(agg_oil_mass,0.00),2) as agg_oil_mass,
         |round(nvl(month_ft_sale_money,0.00),2) as month_ft_sale_money,
         |round(nvl(month_ft_sale_money,0.00)-nvl(last_month_ft_sale_money,0.00),2) as month_sequential_ft_sale_money,
         |round(nvl(seven_ft_sale_money,0.00),2) as seven_ft_sale_money,
         |round(nvl(seven_ft_sale_money,0.00)-nvl(fourteen_ft_sale_money,0.00),2) as seven_sequential_ft_sale_money,
         |round(nvl(day_ft_sale_money,0.00),2) as day_ft_sale_money,
         |round(nvl(day_ft_sale_money,0.00)-nvl(yersterday_ft_sale_money,0.00),2) as day_sequential_ft_sale_money,
         |nvl(month_order_cnt,0) as month_order_cnt,
         |nvl(month_order_cnt,0)-nvl(last_month_order_cnt,0) as month_sequential_order_cnt,
         |nvl(seven_order_cnt,0) as seven_order_cnt,
         |nvl(seven_order_cnt,0)-nvl(fourteen_order_cnt,0) as seven_sequential_order_cnt,
         |nvl(day_order_cnt,0) as day_order_cnt,
         |nvl(day_order_cnt,0)-nvl(yersterday_order_cnt,0) as day_sequential_order_cnt
         |from
         |(
         |select
         |station_id,
         |sum(ft_sale_money) as agg_ft_sale_money,
         |count(order_sn) as agg_order_cnt,
         |sum(oil_mass) as agg_oil_mass
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day<='${inc_day}'
         |and order_status=2
         |group by station_id
         |) t1
         |left join
         |(
         |select
         |station_id,
         |sum(ft_sale_money) as yersterday_ft_sale_money,
         |count(order_sn) as yersterday_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day='${before_yesterday}'
         |and order_status=2
         |group by station_id
         |) t2
         |on t1.station_id=t2.station_id
         |left join
         |(
         |select station_id,
         |sum(ft_sale_money) as day_ft_sale_money,
         |count(order_sn) as day_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day='${inc_day}'
         |and order_status=2
         |group by station_id
         |) t3
         |on t1.station_id=t3.station_id
         |left join
         |(
         |select station_id,
         |sum(ft_sale_money) as month_ft_sale_money,
         |count(order_sn) as month_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day>=replace(trunc(from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','') and inc_day<='${inc_day}'
         |and order_status=2
         |group by station_id
         |) t4
         |on t1.station_id=t4.station_id
         |left join
         |(
         |select station_id,
         |sum(ft_sale_money) as last_month_ft_sale_money,
         |count(order_sn) as last_month_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day>=replace(concat(SUBSTR(DATE_SUB(FROM_UNIXTIME(unix_timestamp('${inc_day}','yyyyMMdd')),DAY(FROM_UNIXTIME(unix_timestamp('${inc_day}','yyyyMMdd')))),1,7) ,'-01'),'-','')
         |and inc_day<=replace(DATE_SUB(FROM_UNIXTIME(unix_timestamp('${inc_day}','yyyyMMdd')),DAY(FROM_UNIXTIME(unix_timestamp('${inc_day}','yyyyMMdd')))),'-','')
         |and order_status=2
         |group by station_id
         |) t5
         |on t1.station_id=t5.station_id
         |left join
         |(
         |select station_id,
         |sum(ft_sale_money) as seven_ft_sale_money,
         |count(order_sn) as seven_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day>='${last_seven_day}' and inc_day<='${inc_day}'
         |and order_status=2
         |group by station_id
         |) t6
         |on t1.station_id=t6.station_id
         |left join
         |(
         |select station_id,
         |sum(ft_sale_money) as fourteen_ft_sale_money,
         |count(order_sn) as fourteen_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day>='${last_fourteen_day}' and inc_day<'${last_seven_day}'
         |and order_status=2
         |group by station_id
         |) t7
         |on t1.station_id=t7.station_id
         |left join
         |(
         |select id,
         |substr(create_date,0,10) as create_day
         |from dm_gis.ddjy_dim_station_info_filter
         |where inc_day='${inc_day}'
         |) t8
         |on t1.station_id=t8.id
         |""".stripMargin)
    petrol_kanban_df.repartition(1).createOrReplaceTempView("petrol_kanban_tmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_uimp_dm_petrol_kanban_report partition(inc_day='${inc_day}') select * from petrol_kanban_tmp")
    logger.error("写入ddjy_uimp_dm_petrol_kanban_report每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      stationProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>油站看板报表 Execute Ok")
  }

}
