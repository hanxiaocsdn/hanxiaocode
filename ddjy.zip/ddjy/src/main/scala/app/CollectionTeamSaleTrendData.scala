package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{lit, row_number, when}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import java.text.SimpleDateFormat
import java.util.Calendar

import utils.DataSourceCommon

/**
 * @Description:车队消费趋势报表
 * @Author: lixiangzhi 01405644 迭代修改：周勇 01390943
 * @Date: 11:05 2022/11/29
 * 任务id:417
 * 任务名称：吨吨加油平台流水明细
 * 依赖任务：每日-车队历史充值记录表 498、每日-原始油站信息过滤表 512、每日-原始车队信息过滤表 501、订单支付时间重分区表 387
 * 数据源：ddjy_dim_team_info_filter、ddjy_dwd_station_order_pay_repartition_di、ddjy_dim_station_info_filter、ddjy_dwd_station_stream_detail、ddjy_dwd_car_team_history_recharge
 * 调用服务地址：无
 * 数据结果：ddjy_dwd_station_stream_detail
 */

object CollectionTeamSaleTrendData extends DataSourceCommon{
  val className: String = this.getClass.getSimpleName.replace("$", "")
  def teamProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String,fri_day:String) = {
    import spark.implicits._
    //计算end_balance
    val end_balance_greater_sql=
      s"""
         |select
         |team_id,end_balance
         |from
         |(
         |	select
         |	user_id as team_id,
         |	total_amount as end_balance,
         |	row_number() over(partition by user_id order by source desc) as rnk
         |	from dm_gis.ddjy_ods_dim_wallet
         |	where inc_day='${inc_day}'
         |	and user_type='2'
         |	and account_type ='10'
         |) t1
         |where rnk=1
         |""".stripMargin
    val end_balance_df:DataFrame=spark.sql(end_balance_greater_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    end_balance_df.createOrReplaceTempView("end_balance_Tmp")

    val stationStreamSql=
      s"""
         |select
         |province_name,
         |area_name,
         |city_name,
         |car_team_id,
         |station_id,
         |'' as sign_province,
         |'' as sign_city,
         |first_trade_date,
         |first_pay_date,
         |last_pay_date,
         |total_order,
         |total_sales,
         |is_lost,
         |from_unixtime(unix_timestamp('${inc_day}', 'yyyyMMdd'), 'yyyy-MM-dd') as date,
         |sum_order,
         |sum_sales,
         |last_trade_date,
         |last_trade_amount,
         |sum_trade_amount,
         |end_balance,
         |label_easy,oil_dimension2,team_id_label,grpid,station_type
         |from
         |(
         |	select
         |	t6.province_name,
         |	t6.area_name,
         |	t6.city_name,
         |	t6.car_team_id,
         |	t6.station_id,
         |	t2.first_trade_date,
         |	t6.first_pay_date,
         |	t6.last_pay_date,
         |	t6.total_order,
         |	t6.total_sales,
         |	t6.is_lost,
         |	count(car_team_id) over(partition by car_team_id) cnt,
         |	sum_order,
         |	sum_sales,
         |	y1.last_trade_date,
         |	y1.last_trade_amount,
         |	t2.sum_trade_amount,
         |	y2.end_balance,
         |	y3.label_easy,y3a.oil_dimension2,'' team_id_label,
         |	y4.station_type,y4.grpid
         |	from
         |	(
         |		select
         |		province_name,
         |		area_name,
         |		city_name,
         |		car_team_id,
         |		station_id,
         |		min(first_pay_date) first_pay_date,
         |		max(last_pay_date) last_pay_date,
         |		sum(total_order) total_order,
         |		sum(total_sales) total_sales,
         |		case when min(first_pay_date) is null then null
         |			 when replace(max(substr(last_pay_date,0,10)),'-','') < '${last_seven_day}' then '1'
         |			 else '0' end is_lost,
         |		sum(sum_order) as sum_order,
         |		sum(sum_sales) as sum_sales
         |		from
         |		(
         |			select
         |			province_name,
         |			area_name,
         |			city_name,
         |			car_team_id,
         |			station_id,
         |			min(pay_time) first_pay_date,
         |			max(pay_time) last_pay_date,
         |			count(distinct order_sn) total_order,
         |			sum(ft_sale_money) total_sales,
         |			count(distinct order_sn) sum_order,
         |			sum(ft_sale_money) sum_sales,
         |			'${inc_day}' inc_day
         |			from
         |			(
         |				select
         |				t.id car_team_id,
         |				t1.station_id,
         |				t1.order_sn,
         |				t1.pay_time,
         |				t1.ft_sale_money,
         |				nvl(t3.province_name,'') as province_name,
         |				nvl(t3.city_name,'') as city_name,
         |				nvl(nvl(t4.area_name, if(length(t3.city_name) < 3, t3.city_name, replace(t3.city_name, '市', ''))),'') area_name
         |				from
         |				(
         |					select id
         |					from dm_gis.ddjy_dim_team_info_filter
         |					where inc_day = '${inc_day}' and del_flag = '0'
         |				) t
         |				left join
         |				(	select station_id, car_team_id, order_sn, pay_time, ft_sale_money
         |					from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |					where inc_day = '${inc_day}'
         |				) t1
         |				on t.id = t1.car_team_id
         |				left join
         |				(	select id, province_name, city_name
         |					from dm_gis.ddjy_dim_station_info_filter
         |					where inc_day = '${inc_day}' and del_flag = '0'
         |					group by id, province_name, city_name
         |				) t3
         |				on t1.station_id = t3.id
         |				left join dm_gis.dim_ddjy_city_area t4
         |				on t3.province_name = t4.province_name and t3.city_name = t4.city_name
         |			) a1
         |			group by province_name, area_name, city_name, car_team_id, station_id
         |
         |			union all
         |
         |			select
         |			nvl(province_name,'') as province_name,
         |			nvl(area_name,'') as area_name,
         |			nvl(city_name,'') as city_name,
         |			car_team_id,
         |			station_id,
         |			first_pay_date,
         |			last_pay_date,
         |			0 as total_order,
         |			0 as total_sales,
         |			sum_order,
         |			sum_sales,
         |			inc_day
         |			from dm_gis.ddjy_dwd_station_stream_detail where inc_day = '${before_yesterday}'
         |		) t5
         |		group by province_name, area_name, city_name, car_team_id, station_id
         |	) t6
         |	left join
         |	(
         |		select team_id, min(trade_time) first_trade_date,sum(trade_amount) sum_trade_amount
         |		from dm_gis.ddjy_dwd_car_team_history_recharge
         |		where inc_day <= '${inc_day}' and trade_description in('车队充值上账','代收代付充值','顺手付充值')
         |		group by team_id
         |	) t2
         |	on t6.car_team_id = t2.team_id
         |	left join
         |	(
         |		select *
         |		from
         |		(
         |			select team_id,trade_time as last_trade_date,trade_amount as last_trade_amount,
         |			ROW_NUMBER() OVER (PARTITION BY team_id ORDER BY trade_time DESC ) AS rn
         |			from dm_gis.ddjy_dwd_car_team_history_recharge
         |			where inc_day <= '${inc_day}' and trade_description in('车队充值上账','代收代付充值','顺手付充值')
         |		)x
         |		where x.rn=1
         |	) y1
         |	on t6.car_team_id = y1.team_id
         |	left join
         |	(
         |		select team_id,end_balance
         |		from end_balance_Tmp
         |	) y2
         |	on t6.car_team_id = y2.team_id
         |	left join
         |	(
         |		select team_id,label_easy
         |    from
         |    (
         |       select  car_team_id as team_id,label_easy,
         |       row_number() over(partition by car_team_id order by label_easy) as rnk
         |		   from dm_gis.ddjy_carteam_label
         |		   where  inc_day = '${inc_day}'
         |    ) y3_1
         |    where rnk=1
         |	) y3
         |	on t6.car_team_id = y3.team_id
         |	left join
         |	(
         |		select team_id,oil_dimension2
         |    from
         |    (
         |      select car_team_id_dd as team_id,oil_dimension2,
         |      row_number() over(partition by car_team_id_dd order by oil_dimension2) as rnk
         |		  from dm_gis.ddjy_carteam
         |		  where  inc_day = '${fri_day}'
         |    ) y3_1
         |    where rnk=1
         |	) y3a
         |	on t6.car_team_id = y3a.team_id
         |	left join
         |	(
         |		select *
         |		from
         |		(
         |			select station_id,station_type,grpid,
         |			ROW_NUMBER() OVER (PARTITION BY station_id ORDER BY update_date DESC ) AS rank
         |			from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		) x
         |		where rank =1
         |	) y4
         |	on t6.station_id = y4.station_id
         |) t7
         |where !(cnt > 1 and is_lost is null)
         """.stripMargin
    //logger.error(stationStreamSql)
    val stationStreamRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, stationStreamSql).map(obj => {
      ((obj.getString("car_team_id"),obj.getString("station_id")), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("第一版逻辑数据量:"+stationStreamRdd.count())
    val consumeCarplateSql=
      s"""
        |select
        |car_team_id,station_id,
        |if(new_carplate!='' and new_carplate is not null,new_carplate,driver_phone) as consume_carplate,
        |if(ocr_carplate!='' and ocr_carplate is not null,ocr_carplate,driver_phone) as consume_ocr_carplate
        |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
        |where inc_day='${inc_day}'
        |and order_status='2'
        |""".stripMargin
    val consumeCarplateRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, consumeCarplateSql).map(obj => {
      val car_team_id: String = obj.getString("car_team_id")
      val station_id: String = obj.getString("station_id")
      ((car_team_id, station_id), obj)
    }).groupByKey().map(obj => {
      val tmpObj = new JSONObject()
      val list: List[JSONObject] = obj._2.toList
      val consume_carplate_aggr: String = list.filter(json=>{
        StringUtils.isNoneEmpty(json.getString("consume_carplate"))
      }).map(json => {
        val consume_carplate: String = json.getString("consume_carplate")
        consume_carplate
      }).distinct.mkString(",")
      val consume_carplate_ocr_aggr: String = list.filter(json=>{
        StringUtils.isNoneEmpty(json.getString("consume_ocr_carplate"))
      }).map(json => {
        val consume_ocr_carplate: String = json.getString("consume_ocr_carplate")
        consume_ocr_carplate
      }).distinct.mkString(",")
      tmpObj.put("car_team_id",obj._1._1)
      tmpObj.put("station_id",obj._1._2)
      tmpObj.put("consume_carplate_aggr",consume_carplate_aggr)
      tmpObj.put("consume_carplate_ocr_aggr",consume_carplate_ocr_aggr)
      tmpObj
    }).map(obj => {
      ((obj.getString("car_team_id"),obj.getString("station_id")), obj)
    })
    val consumeDailyRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, consumeCarplateSql)
      .groupBy(_.getString("car_team_id")).map(obj => {
      val tmpObj = new JSONObject()
      val list: List[JSONObject] = obj._2.toList
      val consume_vehicle_daily_cnt: Int = list.filter(json => {
        StringUtils.isNoneEmpty(json.getString("consume_carplate"))
      }).map(json => {
        val consume_carplate: String = json.getString("consume_carplate")
        consume_carplate
      }).distinct.size
      tmpObj.put("car_team_id",obj._1)
      tmpObj.put("consume_vehicle_daily_cnt", consume_vehicle_daily_cnt)
      (obj._1,tmpObj)
    })
    val rechargeSql=
      s"""
        |select
        |team_id,
        |count(1) as recharge_cnt
        |from dm_gis.ddjy_dwd_car_team_history_recharge
        |where inc_day='${inc_day}'
        |and trade_description in ('车队充值上账','代收代付充值','顺手付充值') and cast(trade_amount as double)>0
        |group by team_id
        |""".stripMargin
    val rechargeRdd= SparkUtils.getRowToJson(spark, rechargeSql).map(obj => {
      (obj.getString("team_id"),obj)
    })
    val teamInfoFilterSql=
      s"""
         |select
         |id,
         |province as team_province,
         |city as team_city,
         |create_date as team_create_date,
         |tax_no,
         |name
         |from dm_gis.ddjy_dim_team_info_filter
         |where inc_day='${inc_day}'
         |""".stripMargin
    val teamInfoFilterRdd= SparkUtils.getRowToJson(spark, teamInfoFilterSql).map(obj => {
      (obj.getString("id"),obj)
    })
    val last_thirty_day: String = DateUtil.getDateStr(inc_day, -30, "")
    val carrierRlstSql=
      s"""
         |select
         |credit_code,
         |register_vehicle_count as team_vehicle_cnt,
         |inc_day
         |from dm_gis.dm_ddjy_carrier_rlst_di
         |where inc_day in(select max(inc_day) from dm_gis.dm_ddjy_carrier_rlst_di)
         |""".stripMargin
    val carrierRlstRdd= SparkUtils.getRowToJson(spark, carrierRlstSql).groupBy(_.getString("credit_code")).map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.maxBy(json => {
        val inc_day: String = json.getString("inc_day")
        inc_day
      })
      (tmpObj.getString("credit_code"),tmpObj)
    })
    //读取dim_ddjy_vehicle_concat_yy_df
    val carrierYySql=
      s"""
        |select owner_name,credit_code,count(distinct vehicle_no) as fixed_team_vehicle_cnt
        |from dm_gis.ddjy_vehicle_ownership_day_dtl
        |where inc_day='$before_yesterday'
        |group by credit_code,owner_name
        |""".stripMargin
    val carrierYyRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, carrierYySql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val carrierYyCreditcodeRdd: RDD[(String, JSONObject)] = carrierYyRdd.map(obj => {
      (obj.getString("credit_code"), obj)
    })
    //读取ddjy_ods_sales_team表
    val salesTeamSql=
      s"""
        |select
        |t1.team_id,create_date,update_date,user_name,
        |split(max_create_date,'_')[0] as max_create_date,
        |split(max_create_date,'_')[1] as max_user_name,
        |split(min_create_date,'_')[0] as min_create_date,
        |split(min_create_date,'_')[1] as min_user_name
        |from
        |(
        |	select team_id,create_date,update_date,user_name
        |	from dm_gis.ddjy_ods_sales_team
        |	where inc_day='$inc_day'
        |) t1
        |left join
        |(
        |	select
        |	team_id,
        |	max(concat(create_date,'_',user_name)) as max_create_date,
        |	min(concat(create_date,'_',user_name)) as min_create_date
        |	from dm_gis.ddjy_ods_sales_team
        |	where inc_day='$inc_day'
        |	group by team_id
        |) t2
        |on t1.team_id=t2.team_id
        |""".stripMargin
    val salesTeamRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, salesTeamSql).map(obj => {
      (obj.getString("team_id"), obj)
    })

    val addIsConsumedRdd: RDD[JSONObject] = stationStreamRdd.leftOuterJoin(consumeCarplateRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      (leftObj.getString("car_team_id"), leftObj)
    }).leftOuterJoin(rechargeRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      (leftObj.getString("car_team_id"), leftObj)
    }).leftOuterJoin(teamInfoFilterRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      (leftObj.getString("car_team_id"), leftObj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val min_first_pay_date: String = list.minBy(_.getString("first_pay_date")).getString("first_pay_date")
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("min_first_pay_date", min_first_pay_date)
        json
      })
      tmpList.iterator
    }).map(obj => {
      (obj.getString("car_team_id"), obj)
    }).leftOuterJoin(salesTeamRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      val min_first_pay_date: String = JSONUtil.getJsonValSingle(leftObj, "min_first_pay_date")
      if (rightObj != null) {
        val create_date: String = rightObj.getString("create_date")
        val update_date: String = rightObj.getString("update_date")
        var user_name: String = rightObj.getString("user_name")
        val max_create_date: String = rightObj.getString("max_create_date")
        val min_create_date: String = rightObj.getString("min_create_date")
        val max_user_name: String = rightObj.getString("max_user_name")
        val min_user_name: String = rightObj.getString("min_user_name")
        var distinct_tag = Int.MaxValue
        if (StringUtils.isNoneEmpty(min_first_pay_date) && min_first_pay_date >= create_date && min_first_pay_date <= update_date){
          user_name = user_name
          distinct_tag = 0
        }else if (StringUtils.isNoneEmpty(min_first_pay_date) && !(min_first_pay_date >= create_date && min_first_pay_date <= update_date) && min_first_pay_date > max_create_date) {
          user_name = max_user_name
          distinct_tag = 1
        } else if (StringUtils.isNoneEmpty(min_first_pay_date) && !(min_first_pay_date >= create_date && min_first_pay_date <= update_date) && min_first_pay_date < min_create_date) {
          user_name = min_user_name
          distinct_tag = 2
        }
        leftObj.put("team_first_order_sales", user_name)
        leftObj.put("distinct_tag",distinct_tag)
      }
      ((leftObj.getString("car_team_id"), leftObj.getString("station_id")), leftObj)
    }).groupByKey().map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.minBy(json=>{
        JSONUtil.getJsonValInt(json,"distinct_tag",Int.MinValue)
      })
      val first_pay_date: String = tmpObj.getString("first_pay_date")
      val min_first_pay_date: String = tmpObj.getString("min_first_pay_date")
      var team_first_order_sales: String = tmpObj.getString("team_first_order_sales")
      if (StringUtils.isEmpty(first_pay_date) || min_first_pay_date != first_pay_date){
        team_first_order_sales = ""
      }
      tmpObj.put("team_first_order_sales",team_first_order_sales)
      (obj._1._1,tmpObj)
    }).leftOuterJoin(consumeDailyRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      var is_consumed_team_daily = "0"
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
        is_consumed_team_daily = "1"
      }
      leftObj.put("is_consumed_team_daily", is_consumed_team_daily)
      (leftObj.getString("tax_no"), leftObj)
    }).leftOuterJoin(carrierRlstRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val notNullTaxnoRdd: RDD[(String, JSONObject)] = addIsConsumedRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("tax_no"))
    }).map(obj => {
      (obj.getString("tax_no"), obj)
    })
    val notNullTaxnoJoinYyRdd: RDD[JSONObject] = notNullTaxnoRdd.leftOuterJoin(carrierYyCreditcodeRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("fixed_team_vehicle_cnt", rightObj.getString("fixed_team_vehicle_cnt"))
      }
      leftObj
    })
    val nullTaxnoRdd: RDD[(String, JSONObject)] = addIsConsumedRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("tax_no"))
    }).map(obj => {
      (obj.getString("name"), obj)
    })
    val carrierYyOwnerNameRdd: RDD[(String, JSONObject)] = carrierYyRdd.map(obj => {
      (obj.getString("owner_name"), obj)
    })
    val nullTaxnoJoinYyRdd: RDD[JSONObject] = nullTaxnoRdd.leftOuterJoin(carrierYyOwnerNameRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("fixed_team_vehicle_cnt", rightObj.getString("fixed_team_vehicle_cnt"))
      }
      leftObj
    })
    val addTagDf: DataFrame = notNullTaxnoJoinYyRdd.union(nullTaxnoJoinYyRdd).groupBy(_.getString("car_team_id")).flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val first_pay_date: String = list.minBy(json => {
        val first_pay_date: String = JSONUtil.getJsonValSingle(json, "first_pay_date")
        first_pay_date
      }).getString("first_pay_date")
      val tmpObj: JSONObject = list.maxBy(json => {
        val last_pay_date: String = JSONUtil.getJsonValSingle(json, "last_pay_date")
        last_pay_date
      })
      var last_pay_date: String = tmpObj.getString("last_pay_date")
      var first_trade_date: String = tmpObj.getString("first_trade_date")
      var trade_diff:Long = -1
      if (StringUtils.isNoneEmpty(first_trade_date)){
        first_trade_date = first_trade_date.substring(0, 10).replace("-", "")
        trade_diff = DateUtil.daysDiff(first_trade_date, inc_day)
      }
      var last_pay_diff:Long = -1
      if (StringUtils.isNoneEmpty(last_pay_date)){
        last_pay_date = last_pay_date.substring(0, 10).replace("-", "")
        last_pay_diff = DateUtil.daysDiff(last_pay_date, inc_day)
      }
      val end_balance: Double = tmpObj.getDoubleValue("end_balance")
      var team_create_date: String = tmpObj.getString("team_create_date")
      var create_diff:Long = -1
      if (StringUtils.isNoneEmpty(team_create_date)){
        team_create_date = team_create_date.substring(0, 10).replace("-", "")
        create_diff = DateUtil.daysDiff(team_create_date, inc_day)
      }
      var tag = ""
      if (create_diff < 7 && create_diff != -1 && StringUtils.isEmpty(first_trade_date)) {
        tag = "签约未充值-7天内"
      } else if (create_diff >= 7 && StringUtils.isEmpty(first_trade_date)) {
        tag = "签约未充值-超7天"
      } else if (StringUtils.isNoneEmpty(first_trade_date) && StringUtils.isEmpty(first_pay_date) && end_balance == 0.0) {
        tag = "充值未消费-账户为0"
      } else if (trade_diff >= 7 && StringUtils.isEmpty(first_pay_date) && end_balance > 0.0) {
        tag = "充值未消费-超7天"
      } else if (StringUtils.isNoneEmpty(first_trade_date) && StringUtils.isEmpty(first_pay_date) && end_balance > 0.0 && end_balance <= 1000) {
        tag = "充值未消费-小额充值"
      } else if (trade_diff < 7 && trade_diff != -1 && StringUtils.isEmpty(first_pay_date) && end_balance > 1000) {
        tag = "充值未消费-7天内"
      } else if (StringUtils.isNoneEmpty(first_pay_date) && last_pay_diff >= 7) {
        tag = "流失客户-7天未消费"
      } else if (StringUtils.isNoneEmpty(first_pay_date) && last_pay_diff < 7 && last_pay_diff != -1) {
        tag = "正常消费-7天内消费"
      }
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("tag", tag)
        json
      })
      tmpList
    }).map(obj=>{
      val recharge_cnt: Int = JSONUtil.getJsonValInt(obj, "recharge_cnt", 0)
      obj.put("recharge_cnt",recharge_cnt)

      val first_trade_date = obj.getString("first_trade_date")
      val first_pay_date = obj.getString("first_pay_date")

      if(StringUtils.isNoneEmpty(first_trade_date) && StringUtils.isNoneEmpty(first_pay_date)){
        val first_trade_date_long = DateUtil.dateToStamp(first_trade_date,"yyyy-MM-dd HH:mm:ss")
        val first_pay_date_long = DateUtil.dateToStamp(first_pay_date,"yyyy-MM-dd HH:mm:ss")

        if(first_pay_date_long < first_trade_date_long){
          obj.put("first_trade_date",first_pay_date)
        }
      }

      obj
    }).map(obj=>{
      AddTag(
        obj.getString("province_name"),
        obj.getString("area_name"),
        obj.getString("city_name"),
        obj.getString("car_team_id"),
        obj.getString("station_id"),
        obj.getString("sign_province"),
        obj.getString("sign_city"),
        obj.getString("first_trade_date"),
        obj.getString("first_pay_date"),
        obj.getString("last_pay_date"),
        obj.getString("total_order"),
        obj.getString("total_sales"),
        obj.getString("is_lost"),
        obj.getString("date"),
        obj.getString("sum_order"),
        obj.getString("sum_sales"),
        obj.getString("last_trade_date"),
        obj.getString("last_trade_amount"),
        obj.getString("sum_trade_amount"),
        obj.getString("end_balance"),
        obj.getString("label_easy"),
        obj.getString("oil_dimension2"),
        obj.getString("team_id_label"),
        obj.getString("grpid"),
        obj.getString("station_type"),
        obj.getString("team_province"),
        obj.getString("team_city"),
        obj.getString("team_create_date"),
        obj.getString("consume_vehicle_daily_cnt"),
        obj.getString("is_consumed_team_daily"),
        obj.getString("consume_carplate_aggr"),
        obj.getString("recharge_cnt"),
        obj.getString("tag"),
        obj.getString("team_vehicle_cnt"),
        obj.getString("fixed_team_vehicle_cnt"),
        inc_day.substring(0,6),
        obj.getString("consume_carplate_ocr_aggr"),
        obj.getString("team_first_order_sales")
      )
    }).distinct().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER).withColumn("inc_day",lit(inc_day))
    logger.error("添加tag后数据量:"+addTagDf.count())


   // addTagDf.filter('car_team_id==="3").show(1000,false)

    //首冲时间有两个值的情况下进行最小值

    val scDf = addTagDf.filter('first_trade_date.isNotNull)
      .withColumn("rn", row_number().over(Window.partitionBy('car_team_id ).orderBy('first_trade_date.asc)))
      .filter('rn===1).select('first_trade_date.as("first_trade_date_new"),'car_team_id).distinct()

   // scDf.filter('car_team_id==="3").show(1000,false)

   val resultDF =  addTagDf.join(scDf,Seq("car_team_id"),"left")
     .withColumn("first_trade_date", when('first_trade_date_new.isNotNull, 'first_trade_date_new).otherwise('first_trade_date))
      .select('province_name,
        'area_name,
        'city_name,
        'car_team_id,
        'station_id,
        'sign_province,
        'sign_city,
        'first_trade_date,
        'first_pay_date,
        'last_pay_date,
        'total_order,
        'total_sales,
        'is_lost,
        'date,
        'sum_order,
        'sum_sales,
        'last_trade_date,
        'last_trade_amount,
        'sum_trade_amount,
        'end_balance,
        'label_easy,
        'oil_dimension2,
        'team_id_label,
        'grpid,
        'station_type,
        'team_province,
        'team_city,
        'team_create_date,
        'consume_vehicle_daily_cnt,
        'is_consumed_team_daily,
        'consume_carplate_aggr,
        'recharge_cnt,
        'tag,
        'team_vehicle_cnt,
        'fixed_team_vehicle_cnt,
        'month_tag,
        'consume_carplate_ocr_aggr,
        'team_first_order_sales)
      .withColumn("inc_day",lit(inc_day))


    writeToHive(spark,resultDF,Seq("inc_day"),"dm_gis.ddjy_dwd_station_stream_detail")
    stationStreamRdd.unpersist()
    consumeCarplateRdd.unpersist()
    rechargeRdd.unpersist()
    teamInfoFilterRdd.unpersist()
    carrierRlstRdd.unpersist()
    resultDF.unpersist()
    addIsConsumedRdd.unpersist()
    carrierYyRdd.unpersist()
    logger.error("写入ddjy_dwd_station_stream_detail每日成功，日期为："+inc_day)
  }

  def minStationOrderFilterPaytime(spark: SparkSession, inc_day: String,init_day:String) = {
    val stationOrderFilterSql=
      s"""
         |select substr(min(pay_time),0,10)as inc_day
         |from dm_gis.ddjy_dwd_station_order_filter
         |where inc_day='${inc_day}'
         |and pay_time is not null
         |and pay_time!=''
         |""".stripMargin
    var start_day: String = SparkUtils.getRowToJson(spark,stationOrderFilterSql).map(obj=>{
      val inc_day: String = obj.getString("inc_day").replace("-", "")
      inc_day
    }).collect().head
    if (init_day!=""){
      start_day=init_day
    }
    val dates: Int = DateUtil.daysDiff(start_day, inc_day).toInt
    logger.error("当天支付时间最早的时间:"+start_day)
    logger.error(start_day+"和"+inc_day+"时间间隔是:"+dates+"天")
    dates
  }

  def execute(inc_day:String,init_day:String,is_init:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取ddjy_dwd_station_order_filter，计算是否有补录订单，以及补录订单最早时间
    var dates = minStationOrderFilterPaytime(spark, inc_day,init_day)
    if (dates>60 && is_init=="N"){
      dates=60
    }
    for (i <- (0 to dates).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      val sdf = new SimpleDateFormat("yyyyMMdd")
      val actionTime = sdf.parse(incDay)
      val cal_5 = Calendar.getInstance
      cal_5.setTime(actionTime)
      cal_5.add(Calendar.WEEK_OF_MONTH, -1)
      cal_5.set(Calendar.DAY_OF_WEEK, 6)
      val fri_day = sdf.format(cal_5.getTime)
      teamProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day,fri_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val init_day: String = args(1)
    val is_init: String = args(2)
    execute(inc_day,init_day,is_init)
    logger.error("======>>>>>>车队消费趋势报表 Execute Ok")
  }
  case class AddTag(province_name:String,
                    area_name:String,
                    city_name:String,
                    car_team_id:String,
                    station_id:String,
                    sign_province:String,
                    sign_city:String,
                    first_trade_date:String,
                    first_pay_date:String,
                    last_pay_date:String,
                    total_order:String,
                    total_sales:String,
                    is_lost:String,
                    date:String,
                    sum_order:String,
                    sum_sales:String,
                    last_trade_date:String,
                    last_trade_amount:String,
                    sum_trade_amount:String,
                    end_balance:String,
                    label_easy:String,
                    oil_dimension2:String,
                    team_id_label:String,
                    grpid:String,
                    station_type:String,
                    team_province:String,
                    team_city:String,
                    team_create_date:String,
                    consume_vehicle_daily_cnt:String,
                    is_consumed_team_daily:String,
                    consume_carplate_aggr:String,
                    recharge_cnt:String,
                    tag:String,
                    team_vehicle_cnt:String,
                    fixed_team_vehicle_cnt:String,
                    month_tag:String,
                    consume_carplate_ocr_aggr:String,
                    team_first_order_sales:String
                   )

}
