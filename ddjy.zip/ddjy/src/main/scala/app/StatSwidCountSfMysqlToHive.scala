package app

import java.sql.{Connection, DriverManager, PreparedStatement, ResultSet}

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel

/**
 * Description:【吨吨加油】用户画像-车队画像-潜力标签_V1.2-顺丰StatSwidCount数据导入hive
 * 需求方：左佳怡 01403789
 * Author: 李相志 01405644
 * Date: 14:30 2023/2/16
 * 任务id:553
 * 任务名称：顺丰经验库stat_swid_count mysql导入hive
 * 依赖任务：经验库mysql数据
 * 数据源：stat_swid_count
 * 调用服务地址：无
 * 数据结果：ddjy_stat_swid_count_sf_wi
 */
object StatSwidCountSfMysqlToHive {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def mysqlToHive(spark: SparkSession, mysqlTable: String,hiveTable:String,inc_day: String): Unit = {
    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://100.96.162.85:3306/exprp_sf?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val userName = "gas"
    val passWd = "Steve@1212"
    val tomorrow: String = DateUtil.getDateStr(inc_day, 1, "")
    val mysqlTableNew: String = mysqlTable + "_" + tomorrow
    val maxRid: Long = getMaxRid(spark, mysqlTableNew)
    logger.error(s"开始读取MySQL:$mysqlTableNew 表中数据")
    val orignal_df: DataFrame = spark
      .read
      .format("jdbc")
      .option("url", url)
      .option("user", userName)
      .option("password", passWd)
      .option("dbtable", mysqlTableNew)
      .option("driver", driver)
      .option("partitionColumn", "rid")
      .option("numPartitions", 60)
      .option("lowerBound", 0)
      .option("upperBound", maxRid)
      .option("fetchsize", 100000)
      .option("batchsize", 100000)
      .load().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("读取表数据量："+orignal_df.count())
    // 存到hive备份
    val tempView=s"$mysqlTableNew"+"_tmp"
    orignal_df.createOrReplaceTempView(tempView)
    spark.sql(s"insert overwrite table $hiveTable partition(inc_day='$inc_day') select * from $tempView")
    orignal_df.unpersist()
  }
  def getMaxRid(spark: SparkSession, mysqlTableNew: String) = {
    //读取mysql数据
    val mysqlConn: Connection = mysqlConnection
    logger.error("mysql链接成功")
    val houseInfoSql=s"select max(rid) as rid from $mysqlTableNew"
    //查询view_house表信息
    val houseInfoPS: PreparedStatement = mysqlConn.prepareStatement(houseInfoSql)
    val houseInfoPSResult: ResultSet =houseInfoPS.executeQuery()
    var rid:Long=0
    while (houseInfoPSResult.next()){
      rid = houseInfoPSResult.getLong("rid")
    }
    logger.error("rid最大值："+rid.toString)
    rid
  }
  def mysqlConnection(): Connection ={
    //测试环境mysql
    val jdbcUrl=s"jdbc:mysql://100.96.162.85:3306/exprp_sf?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val mysqlConn: Connection = DriverManager.getConnection(jdbcUrl, "gas", "Steve@1212")
    mysqlConn

  }
  def execute(inc_day: String, mysqlTable: String, hiveTable: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    mysqlToHive(spark,mysqlTable,hiveTable,inc_day)
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val mysqlTable: String = args(1)
    val hiveTable: String = args(2)
    execute(inc_day,mysqlTable,hiveTable)
    //execute()
    logger.error("======>>>>>>StatSwidCountSfMysqlToHive Execute Ok")
  }

}
