package app


import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.CommonTools.{getdaysBeforeOrAfter, writeToHive}

/**
 *需求名称：加油推荐转化监控V1.0：日表
 *需求方：马晶玲(01423372)
 *研发： 周勇(01390943)
 *任务创建时间：20230322
 *任务id：衡度平台699
 **/
object AddFuelTurnPertDay {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    import spark.implicits._
    //获取T-1日期
    val dayvar: String = args(0)
    //取T-14日期,
    val dayvar14 = getdaysBeforeOrAfter(dayvar, -13)
    //取T+7日期,
    val dayvar7 = getdaysBeforeOrAfter(dayvar, 7)
    //车队集散地明细
    val clue_general=spark.sql(
      s"""
         |select team_id,team_name,clue_id,clue_name,rank clue_rank,effect_flag from dm_gis.dm_sxjy_recommend_clue_general
         |where inc_day='${dayvar}'
         |""".stripMargin)
      .filter($"effect_flag"==="1")
      .drop("effect_flag")

    //油站信息
    val clue2station_general=spark.sql(
      s"""
         |select clue_id,team_id,station_id,station_name,rank station_rank from dm_gis.dm_sxjy_recommend_clue2station_general
         |where inc_day='${dayvar}'
         |""".stripMargin)
      .filter($"effect_flag"==="1")
      .drop("effect_flag")

    //订单支付流水
    val order_pay=spark.sql(
      s"""
         |select station_id,car_team_id,oil_mass,pay_time,order_status,inc_day
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |""".stripMargin)
      .filter($"order_status"==="2")
      .drop("order_status")
      .withColumn("team_id",$"car_team_id")
      .withColumn("order_team_id",$"car_team_id")
      .withColumn("order_station_id",$"station_id")
    //操作日志
    val operating_record=spark.sql(
      s"""
         |select event_type as operate_event_type,clue_id,clue_id as operate_clue_id,gas_id as operate_gas_id,operate_time,vehicle_team_id as team_id
         | from dm_gis.ddjy_sys_operating_record
         |where inc_day='${dayvar}'
         |""".stripMargin)
      .filter($"operate_event_type".like("3%") && $"clue_id".isNotNull && trim($"clue_id") =!="")
      .withColumn("operate_time",$"operate_time".substr(0,10))

    //车队详细信息表
    val carrier_rlst=spark.sql(
      s"""
         |select carrier_id team_id,oil_sum from dm_gis.dm_ddjy_carrier_rlst_di
         |where inc_day in (select max(inc_day) inc_day from dm_gis.dm_ddjy_carrier_rlst_di)
         |and inc_day<='${dayvar}'
         |""".stripMargin)

    //表1.1：明细表a
    val detail_table_a1=clue_general.join(clue2station_general, Seq("clue_id","team_id"), "left")
      .withColumn("station_type",when($"station_rank"==="0","推荐").otherwise("非推荐"))
      .join(operating_record,Seq("clue_id","team_id"), "left")

    val detail_table_a2=detail_table_a1.as("a")
      .join(order_pay.as("c"), $"a.station_id"===$"c.station_id" &&  $"a.team_id"===$"c.team_id", "left")
      .drop($"c.station_id")
      .drop($"c.team_id")
      .withColumn("inc_day",lit(dayvar))
      .withColumn("source_type",lit("pc"))
      .select("team_id","team_name","clue_id","clue_name","clue_rank","station_id",
        "station_name","station_rank","station_type","operate_event_type",
        "operate_clue_id","operate_gas_id","order_team_id","order_station_id","operate_time","source_type","inc_day")
    //数据存dm表
    writeToHive(spark, detail_table_a2, Seq("inc_day"), "dm_gis.ddjy_addfuel_turn_dtl1")

    //表1.2：明细表b
    val detail_table_b1=order_pay.filter($"inc_day"===dayvar)
      .groupBy("team_id","station_id")
      .agg(count($"inc_day") as "order_num",
        sum($"oil_mass") as "order_oil_mass"
      )

    val detail_table_b2=order_pay.filter($"inc_day"===dayvar)
      .withColumn("rank",row_number().over(Window.partitionBy("team_id","station_id").orderBy(desc("pay_time")) ))
      .filter($"rank"===1)
      .withColumn("last_pay_time",$"pay_time")
      .select("team_id","station_id","last_pay_time")

    val detail_table_b3=order_pay.filter($"inc_day"<=dayvar && $"inc_day">=dayvar14)
      .groupBy("team_id","station_id")
      .agg(count($"inc_day") as "order_cnt_flag")

    //计算未来7天的订单情况
    val detail_table_b4=order_pay.filter($"inc_day"<=dayvar7 && $"inc_day">=dayvar)
      .groupBy("team_id","station_id")
      .agg(count($"inc_day") as "order_cnt_flag7",
        sum($"oil_mass") as "oil_mass7"
      )

    //计算未来7天的订单加油情况
    val detail_table_b5=order_pay.filter($"inc_day"<=dayvar7 && $"inc_day">=dayvar)
      .groupBy("team_id")
      .agg(
        sum($"oil_mass") as "oil_mass7"
      )

    val detail_table_b_all=order_pay
      .groupBy("team_id","station_id")
      .agg(count($"inc_day") as "order_cnt")

    val detail_table_b=detail_table_b_all.join(detail_table_b1,Seq("team_id","station_id"),"left")
      .join(detail_table_b2,Seq("team_id","station_id"),"left")
      .join(detail_table_b3,Seq("team_id","station_id"),"left")
      .join(detail_table_b4,Seq("team_id","station_id"),"left")
      .withColumn("if_order_14",when($"order_cnt_flag".isNotNull && $"order_cnt_flag">0,"是").otherwise("否"))
      .withColumn("inc_day",lit(dayvar))
      .select("team_id" ,"station_id","order_num","order_oil_mass",
        "last_pay_time" ,"if_order_14" ,"order_cnt_flag7"  ,"inc_day")

    //数据存dm表
    writeToHive(spark, detail_table_b, Seq("inc_day"), "dm_gis.ddjy_addfuel_turn_dtl2")

   //日表计算
    val day_data1=spark.sql(
      s"""
        |select * from dm_gis.ddjy_addfuel_turn_dtl1
        |where inc_day='${dayvar}'
        |""".stripMargin)

    val day_data2=spark.sql(
      s"""
         |select * from dm_gis.ddjy_addfuel_turn_dtl2
         |where inc_day='${dayvar}'
         |""".stripMargin)

    val res_cols = spark.sql(s"""select * from dm_gis.ddjy_addfuel_turnpert_day limit 0""").schema.map(_.name).map(col)

    val day_data3=day_data1.join(day_data2,Seq("team_id" ,"station_id","inc_day"),"left")
      .na.fill("否",Seq("if_order_14"))
      .na.fill(0,Seq("order_cnt_flag7"))
      .groupBy("team_id","team_name","source_type")
      .agg(
        //推荐集散地数
        countDistinct($"clue_id") as "recommend_clue_num",
//推荐油站数
        countDistinct(when($"station_type"==="推荐",$"station_id").otherwise(null)) as "recommend_sta_num",
//非推荐油站数
        countDistinct(when($"station_type"==="非推荐",$"station_id").otherwise(null)) as "non_recommend_sta_num",
//曝光集散地数
        countDistinct(when($"operate_event_type"==="34015",$"clue_id").otherwise(null)) as "expo_clue_num",
//曝光推荐油站数
        countDistinct(when($"station_type"==="推荐" && (($"operate_clue_id" === $"clue_id" && $"operate_event_type" =!= "34015") || $"operate_event_type"==="34015"),$"station_id").otherwise(null)) as "expo_recommend_sta_num",
//曝光非推荐油站数
        countDistinct(when($"station_type"==="非推荐" && (($"operate_clue_id" === $"clue_id" && $"operate_event_type" =!= "34015") || $"operate_event_type"==="34015"),$"station_id").otherwise(null)) as "expo_non_recommend_sta_num",
//集散地转化数
        countDistinct(when($"operate_event_type"==="34015" && $"if_order_14"==="否" && $"order_cnt_flag7">0,$"clue_id").otherwise(null)) as "convert_clue_num",
//推荐油站转化数
        countDistinct(when(($"station_type"==="推荐" && (($"operate_clue_id" === $"clue_id" && $"operate_event_type" =!= "34015") || $"operate_event_type"==="34015"))
          && $"if_order_14"==="否" && $"order_cnt_flag7">0,$"station_id").otherwise(null)) as "convert_recommend_sta_num",
//非推荐油站转化数
        countDistinct(when(($"station_type"==="非推荐" && (($"operate_clue_id" === $"clue_id" && $"operate_event_type" =!= "34015") || $"operate_event_type"==="34015"))
          && $"if_order_14"==="否" && $"order_cnt_flag7">0,$"station_id").otherwise(null)) as "convert_non_recommend_sta_num"
      )
      //推荐集散地关联油站数
      .withColumn("rele_sta_num",$"recommend_sta_num"+$"non_recommend_sta_num")
      //曝光关联油站数
      .withColumn("expo_rele_sta_num",$"expo_recommend_sta_num"+$"expo_non_recommend_sta_num")
      //关联油站转化数
      .withColumn("convert_rele_sta_num",$"convert_recommend_sta_num"+$"convert_non_recommend_sta_num")
      //订单加油总量
      .join(detail_table_b5,Seq("team_id"),"left")
      .na.fill(0.0,Seq("oil_mass7"))
      .withColumn("order_oil_sum",$"oil_mass7")
      //预估一周油量
      .join(carrier_rlst,Seq("team_id"),"left")
      .na.fill(0.0,Seq("oil_sum"))
      //集散地曝光率
      .withColumn("expo_clue_rate",round($"expo_clue_num"/$"recommend_clue_num",6))
      //集散地转化率
      .withColumn("convert_clue_rate",round($"convert_clue_num"/$"expo_clue_num",6))
      //关联油站曝光率
      .withColumn("expo_rele_sta_rate",round($"expo_rele_sta_num"/$"rele_sta_num",6))
      //关联油站转化率
      .withColumn("convert_rele_sta_rate",round($"convert_rele_sta_num"/$"expo_rele_sta_num",6))
      //推荐油站曝光率
      .withColumn("expo_recrele_sta_rate",round($"expo_recommend_sta_num"/$"recommend_sta_num",6))
      //推荐油站转化率
      .withColumn("convert_recrele_sta_rate",round($"convert_recommend_sta_num"/$"expo_recommend_sta_num",6))
      //非推荐油站曝光率
      .withColumn("non_expo_rele_sta_rate",round($"expo_non_recommend_sta_num"/$"non_recommend_sta_num",6))
      //非推荐油站转化率
      .withColumn("non_convert_rele_sta_rate",round($"convert_non_recommend_sta_num"/$"expo_non_recommend_sta_num",6))
      //油量吻合率
      .withColumn("oil_accu_rate",round($"order_oil_sum"/$"oil_sum",6))
      .withColumn("inc_day",lit(dayvar))
      .select(res_cols: _*)

    //数据存dm表
    writeToHive(spark, day_data3, Seq("inc_day"), "dm_gis.ddjy_addfuel_turnpert_day")

  }



}
