package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkWrite,SparkUtils}

/**
 * @Description:
 * 需求人员：01425211 周韵筹
 * @Author: lixiangzhi 01405644
 * @Date:20231013
 * 任务id:1025
 * 任务名称：顺丰和粤运线索地图合并基础表Flow
 * 依赖任务：577粤运线索地图 266顺丰线索地图 803监控dwd_ddjy_belong_join_own_di最新分区
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object SfYyClueMapMergeGas {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def processClueGas(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val midClueGasSql=
      s"""
        |select * from dm_gis.dwd_ddjy_mid_clue_gas_di where inc_day='$incDay'
        |""".stripMargin
    val midClueGasRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, midClueGasSql)
    val segMentRdd: RDD[JSONObject] = midClueGasRdd.map(obj => {
      val tmpObj = new JSONObject()
      tmpObj.put("clue_id", obj.getString("clue_id"))
      tmpObj.put("poiid", obj.getString("poiid"))
      tmpObj.put("lng", obj.getString("lng"))
      tmpObj.put("lat", obj.getString("lat"))
      tmpObj.put("belong_x", obj.getString("longitude"))
      tmpObj.put("belong_y", obj.getString("latitude"))
      tmpObj.put("circle_id", obj.getString("circle_id"))
      tmpObj
    }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("segMentRdd数据量:"+segMentRdd.count())
    val normalDistSeedSql=
      """
        |select * from dm_gis.ddjy_normal_dist_seed_df
        |""".stripMargin
    val normalDistSeedDf: DataFrame = spark.sql(normalDistSeedSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val normalDistSeedRdd: RDD[((String, String), JSONObject)] = SparkUtils.getDfToJson(spark, normalDistSeedDf).map(obj => {
      ((obj.getString("clue_id"), obj.getString("poiid")), obj)
    })
    val joinNormalDistRdd: RDD[JSONObject] = segMentRdd.map(obj => {
      ((obj.getString("clue_id"), obj.getString("poiid")), obj)
    }).leftOuterJoin(normalDistSeedRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("d_dist", rightObj.getString("d_dist"))
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val nullNormalDistRdd: RDD[JSONObject] = joinNormalDistRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("d_dist"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("需要调高德规划接口的数据量："+nullNormalDistRdd.count())
    val httpNormalPlan = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "739", "顺丰和粤运线索地图合并基础表", "获取集散地和油站之间的规划距离", "http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s", "f086106db05b48e6b8cb103ead38d06a", segMentRdd.count(), 50)

    val returnDisRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,nullNormalDistRdd, SfNetInteface.normalPlanInterface, 50, "f086106db05b48e6b8cb103ead38d06a", 20000)
    returnDisRdd.take(10).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpNormalPlan)

    val distanceLess5kmMapRdd: RDD[((String, String), JSONObject)] = midClueGasRdd.map(obj => {
      ((obj.getString("clue_id"), obj.getString("poiid")), obj)
    })

    //更新停留点油站距离种子表
    val addDistDf: DataFrame = returnDisRdd.map(obj => {
      (
        obj.getString("clue_id"),
        obj.getString("poiid"),
        obj.getString("d_dist")
      )
    }).toDF()

    val updateNornalDistDf: Dataset[Row] = addDistDf.union(normalDistSeedDf)
    updateNornalDistDf.createOrReplaceTempView("updateNornalDistTmp")
    SparkWrite.writeToHiveNoPart(spark,updateNornalDistDf,"dm_gis.ddjy_normal_dist_seed_df",100)
    //拼接未调接口和调接口的数据
    val addDistRdd: RDD[JSONObject] = joinNormalDistRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("d_dist"))
    }).union(returnDisRdd).repartition(600)
      .map(obj => {
        val d_dist: String = obj.getString("d_dist")
        obj.put("d_dist", d_dist)
        obj
      }).filter(_.getDoubleValue("d_dist") < 5000.0)
      .map(obj=>{
        obj.put("dist_rank","0-5")
        obj
      }).groupBy(_.getString("poiid")).flatMap(obj=>{
      val gas_circle_id: String = obj._2.minBy(_.getDoubleValue("d_dist")).getString("circle_id")
      val tmpList: Iterable[JSONObject] = obj._2.map(json => {
        json.put("gas_circle_id", gas_circle_id)
        json
      })
      tmpList
    }).map(obj=>{
      ((obj.getString("clue_id"),obj.getString("poiid")),obj)
    }).join(distanceLess5kmMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      rightObj.fluentPutAll(leftObj)
      rightObj
    })
    val clueGasDf: DataFrame = addDistRdd.map(obj => {
      ClueGas(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("clue_id"),
        obj.getString("clue_name"),
        obj.getString("clue_type"),
        obj.getString("clue_addr"),
        obj.getString("dept_type_name"),
        obj.getString("dept_transfer_flag"),
        obj.getString("area_name"),
        obj.getString("country_name"),
        obj.getString("delete_flg"),
        obj.getString("clue_src"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("latitude"),
        obj.getString("longitude"),
        obj.getString("src"),
        obj.getString("plan_depart_tm"),
        obj.getString("vehicle"),
        obj.getString("actual_capacity_load"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("line_distance"),
        obj.getString("circle_id"),
        obj.getString("center_x"),
        obj.getString("center_y"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("credit_code"),
        obj.getString("carrier_province"),
        obj.getString("carrier_city"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("carrier_circle_id"),
        obj.getString("carrier_circle_task_count"),
        obj.getString("register_vehicle_count"),
        obj.getString("carrier_scale"),
        obj.getString("carrier_suspected_address"),
        obj.getString("carrier_priority"),
        obj.getString("poiid"),
        obj.getString("pid"),
        obj.getString("srcid"),
        obj.getString("grpid"),
        obj.getString("gas_src"),
        obj.getString("ss"),
        obj.getString("project_no"),
        obj.getString("url"),
        obj.getString("gas_adcode"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("stationname"),
        obj.getString("roadid"),
        obj.getString("roadclass"),
        obj.getString("roadname"),
        obj.getString("sfgunpricevec"),
        obj.getString("management_model"),
        obj.getString("gas_province"),
        obj.getString("gas_city"),
        obj.getString("gas_district"),
        obj.getString("addr"),
        obj.getString("tel"),
        obj.getString("querybrandid"),
        obj.getString("gaslocationtype"),
        obj.getString("headlabellist"),
        obj.getString("businesshours"),
        obj.getString("hasoilname"),
        obj.getString("oilnamevec"),
        obj.getString("discountmodelvec"),
        obj.getString("gunpricevec"),
        obj.getString("gappricevec"),
        obj.getString("priceactivityvec"),
        obj.getString("pricechangetimevec"),
        obj.getString("officialpricechangetimevec"),
        obj.getString("officialpricevec"),
        obj.getString("delflag"),
        obj.getString("createtime"),
        obj.getString("updatetime"),
        obj.getString("updatetimestamp"),
        obj.getString("cooperatestatus"),
        obj.getString("sfgunpricevec1"),
        obj.getString("businessstatus"),
        obj.getString("effectivestartvec"),
        obj.getString("effectiveendvec"),
        obj.getString("invoicedesc"),
        obj.getString("maintainbegintime"),
        obj.getString("maintainendtime"),
        obj.getString("outsidedriverdesc"),
        obj.getString("petrolstationqualify"),
        obj.getString("srcprice"),
        obj.getString("srclist"),
        obj.getString("dunprice"),
        obj.getString("skidmounted"),
        obj.getString("gas_circle_id"),
        obj.getString("distance"),
        obj.getString("d_dist"),
        obj.getString("dist_rank"),
        obj.getString("task_batch"),
        obj.getString("update_time"),
        obj.getString("gas_adcode_new")
      )
    }).distinct().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("clueGas表数据量:"+clueGasDf.count())
    clueGasDf.createOrReplaceTempView("clueGasTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_clue_gas_di partition(inc_day='$incDay') select * from clueGasTmp")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    processClueGas(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
  case class ClueGas (
                          agr_id:String,
                          agr_rs_id:String,
                          clue_id:String,
                          clue_name:String,
                          clue_type:String,
                          clue_addr:String,
                          dept_type_name:String,
                          dept_transfer_flag:String,
                          area_name:String,
                          country_name:String,
                          delete_flg:String,
                          clue_src:String,
                          adcode:String,
                          province:String,
                          city:String,
                          district:String,
                          latitude:String,
                          longitude:String,
                          src:String,
                          plan_depart_tm:String,
                          vehicle:String,
                          actual_capacity_load:String,
                          carrier_id:String,
                          carrier_name:String,
                          line_distance:String,
                          circle_id:String,
                          center_x:String,
                          center_y:String,
                          legal_person_name:String,
                          content:String,
                          credit_code:String,
                          carrier_province:String,
                          carrier_city:String,
                          carrier_status:String,
                          carrier_tag:String,
                          carrier_circle_id:String,
                          carrier_circle_task_count:String,
                          register_vehicle_count:String,
                          carrier_scale:String,
                          carrier_suspected_address:String,
                          carrier_priority:String,
                          poiid:String,
                          pid:String,
                          srcid:String,
                          grpid:String,
                          gas_src:String,
                          ss:String,
                          project_no:String,
                          url:String,
                          gas_adcode:String,
                          lng:String,
                          lat:String,
                          stationname:String,
                          roadid:String,
                          roadclass:String,
                          roadname:String,
                          sfgunpricevec:String,
                          management_model:String,
                          gas_province:String,
                          gas_city:String,
                          gas_district:String,
                          addr:String,
                          tel:String,
                          querybrandid:String,
                          gaslocationtype:String,
                          headlabellist:String,
                          businesshours:String,
                          hasoilname:String,
                          oilnamevec:String,
                          discountmodelvec:String,
                          gunpricevec:String,
                          gappricevec:String,
                          priceactivityvec:String,
                          pricechangetimevec:String,
                          officialpricechangetimevec:String,
                          officialpricevec:String,
                          delflag:String,
                          createtime:String,
                          updatetime:String,
                          updatetimestamp:String,
                          cooperatestatus:String,
                          sfgunpricevec1:String,
                          businessstatus:String,
                          effectivestartvec:String,
                          effectiveendvec:String,
                          invoicedesc:String,
                          maintainbegintime:String,
                          maintainendtime:String,
                          outsidedriverdesc:String,
                          petrolstationqualify:String,
                          srcprice:String,
                          srclist:String,
                          dunprice:String,
                          skidmounted:String,
                          gas_circle_id:String,
                          distance:String,
                          d_dist:String,
                          dist_rank:String,
                          task_batch:String,
                          update_time:String,
                          gas_adcode_new:String
                        )
}
