package app

import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:油站车队融合月维度中间表
 * 需求人员：娇悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2022/11/26
 * 任务id:525
 * 任务名称：油站车队融合月维度表
 * 依赖任务：沿途线索月维度聚合表492
 * 数据源：ddjy_carteam_business_distribution、ddjy_pathway_clue_month_statistic_di、dm_ddjy_gas_station_info_di、ddjy_station_near_road_clue_di、join_clue_pathway_frequency_month_di、dwd_ddjy_carrier_info_seed、ddjy_ods_dim_team_info、dm_ddjy_carrier_rlst_di_month
 * 调用服务地址：无
 * 数据结果：join_clue_pathway_frequency_month_di
 */
object GasCarrierMergeMonthMid {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def updateJoinCluePathwayFrequencyMonth(spark: SparkSession, max_day: String) = {
    logger.error("正在执行 join_clue_pathway_frequency_month_di 任务.........")
    val join_clue_pathway_frequency_month_sql=
      s"""
        |insert overwrite table dm_gis.join_clue_pathway_frequency_month_di partition(inc_day='${max_day}')
        |select
        |nvl(t9.gas_id,t10.gas_id) as gas_id,
        |nvl(t9.stationName,t10.stationName) as stationname,
        |nvl(t9.carrier_id,t10.carrier_id) as carrier_id,
        |nvl(t9.carrier_name,t10.carrier_name) as carrier_name,
        |clue_task_count,clue_dist_avg,clue_vehicle_count,pathway_task_count,pathway_vehicle_count,pathway_around_task_count,pathway_around_vehicle_count,
        |stay_task_count,stay_vehicle_count,carrier_pathway_cost
        |from
        |(
        |	select
        |	nvl(t7.gas_id,t8.gas_id) as gas_id,
        |	nvl(t7.stationName,t8.stationName) as stationName,
        |	nvl(t7.carrier_id,t8.carrier_id) as carrier_id,
        |	nvl(t7.carrier_name,t8.carrier_name) as carrier_name,
        |	clue_task_count,clue_dist_avg,clue_vehicle_count,pathway_task_count,pathway_vehicle_count,pathway_around_task_count,pathway_around_vehicle_count,carrier_pathway_cost
        |	from
        |	(
        |		select t5.gas_id,t5.stationName,t5.carrier_id,t5.carrier_name,t5.clue_task_count,t5.clue_dist_avg,t6.clue_vehicle_count
        |		from
        |		(
        |			select t1.gas_id,t1.name_chn as stationName,t2.carrier_id,t2.carrier_name,
        |			sum(t2.task_count) as clue_task_count,avg(t1.d_dist) as clue_dist_avg
        |			from
        |			(
        |				select clue_id,gas_id,name_chn,adcode,provinct_name,city,belong_county,d_dist
        |				from dm_gis.dwd_ddjy_clue_rel_gas_station_di_month
        |				where inc_day = '${max_day}'
        |			) t1
        |			join
        |			(
        |				select clue_id,carrier_id,carrier_name,task_count
        |				from dm_gis.dm_ddjy_clue_rel_carrier_di_month
        |				where inc_day = '${max_day}'
        |			) t2
        |			on t1.clue_id = t2.clue_id
        |			group by t1.gas_id,t1.name_chn,t2.carrier_id,t2.carrier_name
        |		) t5
        |		join
        |		(
        |			select t3.gas_id,t4.carrier_id,
        |			count(distinct t4.vehicle) as clue_vehicle_count
        |			from
        |			(
        |				select clue_id,gas_id,name_chn,d_dist
        |				from dm_gis.dwd_ddjy_clue_rel_gas_station_di_month
        |				where inc_day = '${max_day}'
        |			) t3
        |			join
        |			(
        |				select clue_id,carrier_id,vehicle,task_count
        |				from dm_gis.dm_ddjy_clue_rel_car_di_month
        |				where inc_day = '${max_day}'
        |			) t4
        |			on t3.clue_id = t4.clue_id
        |			group by t3.gas_id,t4.carrier_id
        |		) t6
        |		on t5.gas_id = t6.gas_id and t5.carrier_id = t6.carrier_id
        |	) t7
        |	full join
        |	(
        |		select distinct poiid as gas_id,stationName,
        |		owner_id as carrier_id,
        |		owner_name as carrier_name,
        |		frequency_tj as pathway_task_count,
        |		vehicle_count_tj as pathway_vehicle_count,
        |		frequency_zb as pathway_around_task_count,
        |		vehicle_count_zb as pathway_around_vehicle_count,
        |		dh_dist_sum as carrier_pathway_cost
        |		from dm_gis.ddjy_pathway_clue_month_statistic_di
        |		where inc_day = '${max_day}'
        |		and length(owner_name) > 5 and owner_name not like '%暂缺信息%'
        |	) t8
        |	on t7.gas_id=t8.gas_id and t7.carrier_id=t8.carrier_id
        |) t9
        |full join
        |(
        |	select distinct poiid as gas_id,stationName,
        |	owner_id as carrier_id,
        |	owner_name as carrier_name,
        |	frequency_tl as stay_task_count,
        |	vehicle_count_tl as stay_vehicle_count
        |	from dm_gis.ddjy_team_way_frequency_month_di
        |	where inc_day = '${max_day}'
        |	and length(owner_name) > 5 and owner_name not like '%暂缺信息%'
        |) t10
        |on t9.gas_id=t10.gas_id and t9.carrier_id=t10.carrier_id
        |""".stripMargin
    spark.sql(join_clue_pathway_frequency_month_sql)

  }

  def execute(incDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val pathway_clue_month_statistic_sql=
      """
        |select
        |max(inc_day) as max_day
        |from dm_gis.ddjy_pathway_clue_month_statistic_di
        |""".stripMargin
    val pathway_clue_month_statistic_df: DataFrame = spark.sql(pathway_clue_month_statistic_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, pathway_clue_month_statistic_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    //车队停留油站频次表
    updateJoinCluePathwayFrequencyMonth(spark,max_day)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>GasCarrierMergeMonthMid Execute Ok")
  }
}
