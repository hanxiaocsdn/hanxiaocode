package app

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.csvreader.CsvReader
import com.github.davidmoten.rtree.{Entry, RTree}
import com.github.davidmoten.rtree.geometry.{Geometries, Geometry, Point}
import com.sf.gis.scala.base.util.DistanceTool
import org.apache.spark.sql.SparkSession
import rx.Observable

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks


/**
  * Created by 01374443 on 2020/3/25.
  * 优化点1:json修改成数组,减少key带来的内存消耗,以及查询的时间开销
  */
object Test {
  val nationFilePath = "d:\\user\\01405644\\桌面\\station.csv"
  val trackFilePath = "d:\\user\\01405644\\桌面\\track.csv"

  //dis单位千米
  def getQuyu50(x: Double, y: Double, dis: Double) = {
    val r = 6371 //地球半径千米
    //val dis = 0.05  //0.5千米距离
    val latitude = y
    val longitude = x
    var dlng = 2 * math.asin(math.sin(dis / (2 * r)) / math.cos(latitude * math.Pi / 180))
    dlng = dlng * 180 / math.Pi //角度转为弧度
    var dlat = dis / r
    dlat = dlat * 180 / math.Pi
    val minlat = latitude - dlat
    val maxlat = latitude + dlat
    val minlng = longitude - dlng
    val maxlng = longitude + dlng
    ((minlng, minlat), (maxlng, maxlat))
  }

  def loadNationData() = {
    val csvReader = new CsvReader(nationFilePath)
    if (csvReader.readRecord()) {
      val csvHeader = csvReader.getValues
      println("headers:" + csvHeader.mkString(","))
    }
    val arrayBuffer = new ArrayBuffer[JSONObject]()
    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val json = new JSONObject()
      json.put("lng", row(0).toDouble)
      json.put("lat", row(1).toDouble)
      val ((minlng, minlat), (maxlng, maxlat)) = getQuyu50(row(0).toDouble, row(1).toDouble, 0.05)
      json.put("minlng", minlng)
      json.put("minlat", minlat)
      json.put("maxlng", maxlng)
      json.put("maxlat", maxlat)
//      if(){
        arrayBuffer.append(json)
//      }

    }
    arrayBuffer
  }


  def loadTrackData() = {
    val csvReader = new CsvReader(trackFilePath)
    if (csvReader.readRecord()) {
      val csvHeader = csvReader.getValues
      println("headers:" + csvHeader.mkString(","))
    }
    val arrayBuffer = new ArrayBuffer[JSONObject]()
    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val json = new JSONObject()
      json.put("lng", row(1).toDouble)
      json.put("lat", row(2).toDouble)
      json.put("tm", row(3).toLong)

//      if(arrayBuffer.length <50){
        arrayBuffer.append(json)
//      }
    }
    arrayBuffer
  }

  def filterData(stationSquareArr: ArrayBuffer[JSONObject], trackArray: ArrayBuffer[JSONObject]): Unit = {
    val timestamp = System.currentTimeMillis()
    trackArray.foreach(obj => {
      val lng: Double = obj.getDoubleValue("lng")
      val lat: Double = obj.getDoubleValue("lat")
      val coordinateLoop = new Breaks
      coordinateLoop.breakable {
        for (elem <- stationSquareArr) {
          val minlng: Double = elem.getDoubleValue("minlng")
          val maxlng: Double = elem.getDoubleValue("maxlng")
          val minlat: Double = elem.getDoubleValue("minlat")
          val maxlat: Double = elem.getDoubleValue("maxlat")
          val station_lng: String = elem.getString("lng")
          val station_lat: String = elem.getString("lat")
          if (lng >= minlng && lng <= maxlng && lat >= minlat && lat <= maxlat) {
            obj.put("coordinate_tag", 1)
            obj.put("station_lng", station_lng)
            obj.put("station_lat", station_lat)
            coordinateLoop.break()
          }
        }
      }
//      println(obj)
      (obj.getString("car_no"), obj)
    })
    println("消耗:"+(System.currentTimeMillis()-timestamp))
  }

  def splitNation(nationFileArray: ArrayBuffer[JSONObject]) = {
    var maxlng = 0.0
    var maxlat = 0.0
    var minlng = 99999999.0
    var minlat = 99999999.0
    for(index <- 0 until nationFileArray.size){
      val item = nationFileArray(index)
      val tmpMinlng: Double = item.getDoubleValue("minlng")
      val tmpMaxlng: Double = item.getDoubleValue("maxlng")
      val tmpMinlat: Double = item.getDoubleValue("minlat")
      val tmpMaxlat: Double = item.getDoubleValue("maxlat")

      if(tmpMaxlng > maxlng){
        maxlng = tmpMaxlng
      }
      if(tmpMaxlat > maxlat){
        maxlat = tmpMaxlat
      }
      if(tmpMinlng < minlng){
        minlng = tmpMinlng
      }
      if(tmpMinlat < minlat){
        minlat = tmpMinlat
      }
    }
    val splitMap = new util.HashMap[(String,String,String,String),ArrayBuffer[JSONObject]]()
    //1342  30 50 1154 9 585  8 605
    val maxSplitCnt = 9
    val increaseLng = (maxlng-minlng)/maxSplitCnt
    val increaseLat = (maxlat-minlat)/maxSplitCnt
    for(i <- 0 to maxSplitCnt){
      for(j<- 0 to maxSplitCnt){
        val minSplitLng = (j)*increaseLng+minlng
        val minSplitLat = (i)*increaseLat+minlat
        val maxSplitLng = (j+1)*increaseLng+minlng
        var maxSplitLat = (i+1)*increaseLat+minlat
        val tmpArrayBuffer = new ArrayBuffer[JSONObject]()
        splitMap.put((minSplitLng.toString,minSplitLat.toString,maxSplitLng.toString,maxSplitLat.toString),tmpArrayBuffer)
      }
    }
    val key = splitMap.keySet().toArray()
    for(index <- 0 until nationFileArray.size){
      val item = nationFileArray(index)
      val tmpMinlng: Double = item.getDoubleValue("minlng")
      val tmpMaxlng: Double = item.getDoubleValue("maxlng")
      val tmpMinlat: Double = item.getDoubleValue("minlat")
      val tmpMaxlat: Double = item.getDoubleValue("maxlat")
      val tmpArray = Array((tmpMinlat,tmpMinlng),(tmpMinlat,tmpMaxlng),(tmpMaxlat,tmpMaxlng),(tmpMaxlat,tmpMinlng))
//      var flag = true
        for (i <- 0 until key.size) {
          //50米边界范围的四个点，只要其中一个在里面就添加到网格里面
          val coordinateLoop = new Breaks
          coordinateLoop.breakable {
            for (j <- tmpArray.indices) {
              val (tmpLat, tmpLng) = tmpArray(j)
              val (minSplitLng: String, minSplitLat: String, maxSplitLng: String, maxSplitLat: String) = key(i)
              if (tmpLat >= minSplitLat.toDouble && tmpLng >= minSplitLng.toDouble
                && tmpLat <= maxSplitLat.toDouble && tmpLng <= maxSplitLng.toDouble
              ) {
                splitMap.get(key(i)).append(item)
                coordinateLoop.break()
              }
            }
          }

        }
    }
//    for (i <- 0 until key.size) {
//      val item = splitMap.get(key(i))
//      println(key(i),item)
//    }
    splitMap
  }

  def filterData1(nationFileArray1: util.HashMap[(String, String, String, String),
    ArrayBuffer[JSONObject]], trackArray: ArrayBuffer[JSONObject]): Unit = {
    val timestamp = System.currentTimeMillis()
    trackArray.foreach(obj => {
      val lng: Double = obj.getDoubleValue("lng")
      val lat: Double = obj.getDoubleValue("lat")
      val keys = nationFileArray1.keySet().toArray()


      val coordinateLoop1 = new Breaks
      coordinateLoop1.breakable {
        for (i <- 0 until keys.size) {
          val (minSplitLng: String, minSplitLat: String, maxSplitLng: String, maxSplitLat: String) = keys(i)
          if (lat >= minSplitLat.toDouble && lng >= minSplitLng.toDouble
            && lat < maxSplitLat.toDouble && lng < maxSplitLng.toDouble
          ) {
            val  subArray  = nationFileArray1.get(keys(i))
            val coordinateLoop = new Breaks
            coordinateLoop.breakable {
              for (elem <- subArray) {
                val minlng: Double = elem.getDoubleValue("minlng")
                val maxlng: Double = elem.getDoubleValue("maxlng")
                val minlat: Double = elem.getDoubleValue("minlat")
                val maxlat: Double = elem.getDoubleValue("maxlat")
                val station_lng: String = elem.getString("lng")
                val station_lat: String = elem.getString("lat")
                if (lng >= minlng && lng <= maxlng && lat >= minlat && lat <= maxlat) {
                  obj.put("coordinate_tag", 1)
                  obj.put("station_lng", station_lng)
                  obj.put("station_lat", station_lat)
                  coordinateLoop.break()
                }
              }
            }
            coordinateLoop1.break()
          }
        }
      }
//      println(obj)
      (obj.getString("car_no"), obj)
    })

    println("消耗:"+(System.currentTimeMillis()-timestamp))
  }

  def loadNationData1() = {

    val arrayBuffer = new ArrayBuffer[JSONObject]()
    val csvReader = new CsvReader("d:\\user\\01374443\\desktop\\test\\station.csv",'\t')
    csvReader.setSafetySwitch(false)
    if (csvReader.readRecord()) {
      val csvHeader = csvReader.getValues
      val dataJson = JSON.parseObject(csvHeader(0))
      val data = dataJson.getJSONArray("data")
      for(i<- 0 until data.size()){
        val item = data.getJSONObject(i)
        val json = new JSONObject()
        json.put("lng", item.getDouble("lng"))
        json.put("lat", item.getDouble("lat"))
        val ((minlng, minlat), (maxlng, maxlat)) = getQuyu50(item.getDouble("lng"), item.getDouble("lat"), 0.05)
        json.put("minlng", minlng)
        json.put("minlat", minlat)
        json.put("maxlng", maxlng)
        json.put("maxlat", maxlat)
        //      if(){
        arrayBuffer.append(json)
//        println(json.toJSONString)
      }

    }
    println(arrayBuffer.size)
//    System.exit(0)

    arrayBuffer
  }
  def loadByRTree() = {
    var tree:RTree[(Int,Double,Double), Geometry] = RTree.star.minChildren(3)
      .maxChildren(6).create.asInstanceOf[RTree[(Int,Double,Double), Geometry]]
    //    val arrayBuffer = new ArrayBuffer[JSONObject]()
    val tree1:RTree[String, Geometry] = RTree.star
      .maxChildren(6).create.asInstanceOf[RTree[String, Geometry]]
    val csvReader = new CsvReader("d:\\user\\01405644\\桌面\\station.csv",'\t')
    csvReader.setSafetySwitch(false)
    if (csvReader.readRecord()) {
      val csvHeader = csvReader.getValues
      val dataJson = JSON.parseObject(csvHeader(0))
      val data = dataJson.getJSONArray("data")
      for(i<- 0 until data.size()){
        val item = data.getJSONObject(i)
        val json = new JSONObject()
        json.put("lng", item.getDouble("lng"))
        json.put("lat", item.getDouble("lat"))
        val ((minlng, minlat), (maxlng, maxlat)) = getQuyu50(item.getDouble("lng"), item.getDouble("lat"), 0.05)
        json.put("minlng", minlng)
        json.put("minlat", minlat)
        json.put("maxlng", maxlng)
        json.put("maxlat", maxlat)
        //      if(){
        //        arrayBuffer.append(json)
        //        println((i,item.getDouble("lng"),item.getDouble("lat")))
        //        println(minlng, minlat, maxlng, maxlat)
        tree = tree.add((i,item.getDouble("lng"),item.getDouble("lat")),Geometries.rectangle(minlng, minlat, maxlng, maxlat))
        //        println(json.toJSONString)
        //        tree1.add(""+i,Geometries.rectangle(minlng, minlat, maxlng, maxlat))
        //        println(tree1.size())
      }

    }

    //    System.exit(0)

    tree
  }
  def loadByRTree1() = {
    var tree:RTree[(Int,Double,Double), Geometry] = RTree.star.minChildren(3)
      .maxChildren(6).create.asInstanceOf[RTree[(Int,Double,Double), Geometry]]
    //    val arrayBuffer = new ArrayBuffer[JSONObject]()
    val csvReader = new CsvReader(nationFilePath)
    if (csvReader.readRecord()) {
      val csvHeader = csvReader.getValues
      println("headers:" + csvHeader.mkString(","))
    }
    val arrayBuffer = new ArrayBuffer[JSONObject]()
    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val json = new JSONObject()
      json.put("lng", row(0).toDouble)
      json.put("lat", row(1).toDouble)
      //      if(){
      arrayBuffer.append(json)
      //      }
     // println(json)
      //println(arrayBuffer.size)
    }
    for(i<- 0 until arrayBuffer.size){
      val item = arrayBuffer(i)
      val json = new JSONObject()
      json.put("lng", item.getDouble("lng"))
      json.put("lat", item.getDouble("lat"))
      val ((minlng, minlat), (maxlng, maxlat)) = getQuyu50(item.getDouble("lng"), item.getDouble("lat"), 0.05)
      json.put("minlng", minlng)
      json.put("minlat", minlat)
      json.put("maxlng", maxlng)
      json.put("maxlat", maxlat)
      //      if(){
      //        arrayBuffer.append(json)
      //        println((i,item.getDouble("lng"),item.getDouble("lat")))
      //        println(minlng, minlat, maxlng, maxlat)
      tree = tree.add((i,item.getDouble("lng"),item.getDouble("lat")),Geometries.rectangle(minlng, minlat, maxlng, maxlat))
      //        println(json.toJSONString)
      //        tree1.add(""+i,Geometries.rectangle(minlng, minlat, maxlng, maxlat))
      //        println(tree1.size())
    }

    println(tree.size())
      //  System.exit(0)
    tree
  }
  def splitNation1(nationFileArray: ArrayBuffer[JSONObject]) = {
    var maxlng = 0.0
    var maxlat = 0.0
    var minlng = 99999999.0
    var minlat = 99999999.0
    val minMaxLat = new ArrayBuffer[(Double,Double)]()
    val minMaxLng = new ArrayBuffer[(Double,Double)]()
    for(index <- 0 until nationFileArray.size){
      val item = nationFileArray(index)
      val tmpMinlng: Double = item.getDoubleValue("minlng")
      val tmpMaxlng: Double = item.getDoubleValue("maxlng")
      val tmpMinlat: Double = item.getDoubleValue("minlat")
      val tmpMaxlat: Double = item.getDoubleValue("maxlat")
      minMaxLat.append((tmpMinlat,tmpMaxlat))
      minMaxLng.append((tmpMinlng,tmpMaxlng))
      if(tmpMaxlng > maxlng){
        maxlng = tmpMaxlng
      }
      if(tmpMaxlat > maxlat){
        maxlat = tmpMaxlat
      }
      if(tmpMinlng < minlng){
        minlng = tmpMinlng
      }
      if(tmpMinlat < minlat){
        minlat = tmpMinlat
      }
    }
    val splitMap = new util.HashMap[(String,String,String,String),ArrayBuffer[JSONObject]]()
    //1342  30 50 1154 9 585  8 605
    val maxSplitCnt = 9
    val increaseLng = (maxlng-minlng)/maxSplitCnt
    val increaseLat = (maxlat-minlat)/maxSplitCnt
    var lastMinLat = -1.0
    for(i <- 0 to maxSplitCnt){
      var lastMinLng = -1.0
      if(lastMinLat <0){
        lastMinLat = (i)*increaseLat+minlat
      }
      var maxSplitLat = (i+1)*increaseLat+minlat
      val minSplitLat = lastMinLat
      if(minSplitLat < maxSplitLat){
        for(i1<- 0 until minMaxLat.size){
          val (tmpMinLat,tmpMaxLat) = minMaxLat(i1)
          if(tmpMinLat>=minSplitLat && tmpMinLat < maxSplitLat && tmpMaxLat>=maxSplitLat){
            maxSplitLat = tmpMaxLat
          }
        }

        for(j<- 0 to maxSplitCnt){
          if(lastMinLng <0){
            lastMinLng = (j)*increaseLng+minlng
          }
          val minSplitLng = lastMinLng
          var maxSplitLng = (j+1)*increaseLng+minlng
          if(minSplitLng < maxSplitLng){
            for(j1<- 0 until minMaxLng.size){
              val (tmpMinLng,tmpMaxLng) = minMaxLng(j1)
              if(tmpMinLng>=minSplitLng && tmpMinLng < maxSplitLng && tmpMaxLng>=maxSplitLng){
                maxSplitLng = tmpMaxLng
              }
            }
            val tmpArrayBuffer = new ArrayBuffer[JSONObject]()
            splitMap.put((minSplitLng.toString,minSplitLat.toString,maxSplitLng.toString,maxSplitLat.toString),tmpArrayBuffer)
            lastMinLng = maxSplitLng
          }
        }
        lastMinLat = maxSplitLat
      }


    }
    val key = splitMap.keySet().toArray()
    for(index <- 0 until nationFileArray.size){
      val item = nationFileArray(index)
      val tmpMinlng: Double = item.getDoubleValue("minlng")
      val tmpMaxlng: Double = item.getDoubleValue("maxlng")
      val tmpMinlat: Double = item.getDoubleValue("minlat")
      val tmpMaxlat: Double = item.getDoubleValue("maxlat")
      val tmpArray = Array((tmpMinlat,tmpMinlng),(tmpMinlat,tmpMaxlng),(tmpMaxlat,tmpMaxlng),(tmpMaxlat,tmpMinlng))
      //      var flag = true
      for (i <- 0 until key.size) {
        val coordinateLoop = new Breaks
        coordinateLoop.breakable {
          //50米边界范围的四个点，只要其中一个在里面就添加到网格里面
          for (j <- tmpArray.indices) {
            val (tmpLat, tmpLng) = tmpArray(j)
            val (minSplitLng: String, minSplitLat: String, maxSplitLng: String, maxSplitLat: String) = key(i)
            if (tmpLat >= minSplitLat.toDouble && tmpLng >= minSplitLng.toDouble
              && tmpLat <= maxSplitLat.toDouble && tmpLng <= maxSplitLng.toDouble
            ) {
              splitMap.get(key(i)).append(item)
              coordinateLoop.break()
            }
          }
        }

      }
    }
    //    for (i <- 0 until key.size) {
    //      val item = splitMap.get(key(i))
    //      println(key(i),item)
    //    }
    splitMap
  }
  def parseMessageObject(line: String): (String, String, String, String, JSONObject, JSONArray) = {
    val jObj = JSON.parseObject(line.trim)
    var createTime = jObj.getString("createTime")
    if (createTime != null) {
      createTime = createTime.replace(".", " ")
    }
    val ip = jObj.getString("ip")
    val message = JSON.parseObject(jObj.getString("message").trim)
    val chkDisLogType = message.getString("chkDisLogType").trim
    var chkDisLogObj: JSONObject = null
    var chkDisLogArray: JSONArray = null
    var chkDisLogMsg: String = null
    if (message.containsKey("chkDisLogArray")) {
      val tmpArray = message.getJSONArray("chkDisLogArray")
      if (tmpArray != null && tmpArray.size() != 0) {
        chkDisLogArray = new JSONArray()
        for (i <- 0 until tmpArray.size()) {
          chkDisLogArray.add(JSON.parseObject(tmpArray.getString(i).trim))
        }
      }
    } else if (message.containsKey("chkDisLogMsg")) {
      chkDisLogMsg = message.getString("chkDisLogMsg").trim
    } else {
      chkDisLogObj = message
    }
    (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray)
  }

  def filterTree(nationTree: RTree[(Int, Double, Double), Geometry], trackArray: ArrayBuffer[JSONObject]): Unit = {

      val timestamp = System.currentTimeMillis()
    trackArray.map(obj => {
      val lng: Double = obj.getDoubleValue("lng")
      val lat: Double = obj.getDoubleValue("lat")
      //        val keys = nationFileArray1.keySet().toArray()

      val entries = nationTree.search(Geometries.point(lng,lat)).toList().toBlocking().single()
      if(entries.size()>0){
        val entry = entries.get(0)
        obj.put("coordinate_tag", 1)
        obj.put("station_lng", entry.value()._2+"")
        obj.put("station_lat", entry.value()._3+"")
      }
      println(obj)
      obj
    })
      .filter(obj=>{
      obj.getString("station_lng")!=null
    }).map(obj=>{
      println(obj)
    })
      println("消耗:"+(System.currentTimeMillis()-timestamp))
  }

  def main(args: Array[String]): Unit = {
    //    val nationFileArray = loadNationData()
//    val nationFileArray = loadNationData1()
val timestamp = System.currentTimeMillis()
//    val nationFileArray1 = splitNation(nationFileArray)
val d: Double = DistanceTool.getGreatCircleDistance(113.281136, 22.644245, 113.281435, 22.644452)
    println(d)
    val c: Double = DistanceTool.getGreatCircleDistance(113.281435, 22.644452, 113.281503, 22.644439)
    println(c)
    return
    val nationTree = loadByRTree1()
    println("消耗:"+(System.currentTimeMillis()-timestamp))
    val trackArray = loadTrackData()
//    println(nationTree.size+","+trackArray.size)
    //8932毫秒
    //    filterData(nationFileArray, trackArray)
//    filterData1(nationFileArray1, trackArray)
    filterTree(nationTree,trackArray)

  }
}
