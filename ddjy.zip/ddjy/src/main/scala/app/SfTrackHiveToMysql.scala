package app

import java.sql.{Connection, DriverManager, PreparedStatement, ResultSet}

import com.alibaba.druid.support.json.JSONUtils
import com.mysql.cj.MysqlConnection
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql._
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel

/**
 * @Description:顺丰轨迹表hive导入mysql
 * 需求方：左佳怡 01403789
 * @Author: lixiangzhi 01405644
 * @Date: 10:46 2022/12/8
 * 任务id:538
 * 任务名称：顺丰轨迹表hive导入mysql
 * 依赖任务：无
 * 数据源：ddjy_sf_track
 * 调用服务地址：
 * 数据结果：ddjy_sf_track
 */
object SfTrackHiveToMysql {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def sfTrack(spark: SparkSession, inc_day: String, mysqlTable: String, hiveTable: String) = {
    val sfTrackSql=
      s"""
        |select
        |*
        |from $hiveTable
        |where inc_day='$inc_day'
        |""".stripMargin
    val sfTrackDf: DataFrame = spark.sql(sfTrackSql)
    sfTrackDf.coalesce(1).write
      .format("jdbc")
      .mode(SaveMode.Overwrite)
      .option("driver","com.mysql.cj.jdbc.Driver")
      .option("url","jdbc:mysql://100.96.162.85:3306/exprp_sf?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false")
      .option("dbtable",s"$mysqlTable")
      .option("user","gas")
      .option("password","Steve@1212")
      .save()

  }


  def sfTrackId(spark: SparkSession, inc_day: String, mysqlTable: String, hiveTable: String) = {
    val sfTrackSql=
      s"""
         |select
         |*
         |from $hiveTable
         |where inc_day='$inc_day'
         |""".stripMargin
    val sfTrackDf: DataFrame = spark.sql(sfTrackSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("顺丰轨迹数据量:"+sfTrackDf.count())
    //进行数据库链接
    val mysqlConn1: Connection = mysqlConnection
    val truncateSql = s"truncate table $mysqlTable"
    val truncatePS: PreparedStatement = mysqlConn1.prepareStatement(truncateSql)
    truncatePS.execute()
    mysqlConn1.close()
    SparkUtils.getDfToJson(spark,sfTrackDf,20).foreachPartition(line => {
      //进行数据库链接
      val mysqlConn: Connection = mysqlConnection
      //插入数据
      val sql = s"replace into $mysqlTable (un,jp_coords,jp_time,inc_day) values(?,?,?,?)"
      line.foreach(obj=>{
        val warningPS: PreparedStatement = mysqlConn.prepareStatement(sql)
        val un: String = obj.getString("un")
        val jp_coords: String = obj.getString("jp_coords")
        val jp_time: String = obj.getString("jp_time")
        val inc_day: String = obj.getString("inc_day")
        warningPS.setString(1,un)
        warningPS.setString(2,jp_coords)
        warningPS.setString(3,jp_time)
        warningPS.setString(4,inc_day)
        warningPS.executeUpdate()
      })
      mysqlConn.close()
    })
  }
  def mysqlConnection(): Connection ={
    val jdbcUrl=s"jdbc:mysql://100.96.162.85:3306/exprp_sf?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true&useSSL=false"
    val mysqlConn: Connection = DriverManager.getConnection(jdbcUrl, "gas", "Steve@1212")
    mysqlConn

  }
  def execute(inc_day: String, mysqlTable: String, hiveTable: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //sfTrack(spark,inc_day,mysqlTable,hiveTable)
    sfTrackId(spark,inc_day,mysqlTable,hiveTable)
    logger.error("写入"+s"$mysqlTable"+"完成,分区为"+s"$inc_day")
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val mysqlTable: String = args(1)
    val hiveTable: String = args(2)
    execute(inc_day,mysqlTable,hiveTable)
    logger.error("======>>>>>>SfTrackHiveToMysql Execute Ok")
  }

}
