package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SparkUtils, SparkWrite}

/**
 * @Description:车队线索结果表
 * 需求人员：周韵筹 01425211
 * @Author: lixiangzhi 01405644
 * @Date:20231207
 * 任务id:1092
 * 任务名称：车队线索月维度表
 * 依赖任务：1091
 * 数据源：
 * 调用服务地址：无
 * 数据结果：dm_ddjy_carrier_rlst_di_month
 */
object CarrierRlstMonth {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readCarrierRlst(spark: SparkSession, incDay: String) = {
    val lastMonthDay: String = DateUtil.getDateStr(incDay, -30, "")
    val carrierRlstSql=
      s"""
        |select
        |carrier_id,carrier_name,credit_code,legal_person_name,content,src1,linkman_phone,src2,province,city,carrier_status,carrier_tag,inc_day,task_batch
        |from dm_gis.dm_ddjy_carrier_rlst_di
        |where inc_day>='${lastMonthDay}' and inc_day<='${incDay}'
        |""".stripMargin
    val carrierRlstMidRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, carrierRlstSql,2000).groupBy(_.getString("carrier_id")).map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.maxBy(_.getString("inc_day"))
      val biz_day: String = tmpObj.getString("inc_day")
      val carrier_tag_arr: List[String] = list.map(_.getString("carrier_tag"))
      var carrier_tag: String = tmpObj.getString("carrier_tag")
      if (carrier_tag_arr.contains("sf_carrier_tag")){
        carrier_tag = "sf_carrier_tag"
      }
      tmpObj.put("biz_day", biz_day)
      tmpObj.put("carrier_tag", carrier_tag)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("线索车队表根据carrierid去重后的数据量:"+carrierRlstMidRdd.count())
    //计算task_batch
    val task_batch_min: String = carrierRlstMidRdd.map(obj => {
      val task_batch: String = obj.getString("task_batch")
      task_batch
    }).min().split("-")(0)
    val task_batch_max: String = carrierRlstMidRdd.map(obj => {
      val task_batch: String = obj.getString("task_batch")
      task_batch
    }).max().split("-")(1)
    val carrierRlstRdd: RDD[(String, JSONObject)] = carrierRlstMidRdd.map(obj => {
      obj.put("task_batch", task_batch_min + "-" + task_batch_max)
      (obj.getString("carrier_id"), obj)
    })
    carrierRlstMidRdd.unpersist()
    carrierRlstRdd
  }

  def readCarrierMergeMonth(spark: SparkSession, incDay: String) = {
    val carrierMergeMonthSql=
      s"""
        |select
        |carrier_id,clue_distribution,
        |clue_city_distribution as city_distribution,
        |carrier_circle_id,register_vehicle_count,carrier_scale,carrier_suspected_address,carrier_priority,online_gas_top5,online_gas_top10,city_adcode,carrier_white_list,
        |circle_task_count as carrier_circle_task_count
        |from dm_gis.dm_ddjy_gas_carrier_merge_di_month
        |where inc_day='${incDay}'
        |""".stripMargin
    val carrierMergeMonthRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, carrierMergeMonthSql).groupBy(_.getString("carrier_id")).map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.maxBy(_.getIntValue("register_vehicle_count"))
      (obj._1, tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站车队融合表根据carrierid去重后的数据量:"+carrierMergeMonthRdd.count())
    carrierMergeMonthRdd
  }

  def onlineGasTaskCount(spark: SparkSession, incDay: String) = {
    val onlineGasTaskCountSql=
      s"""
        |select
        |carrier_id,
        |sum(task_count) as online_gas_task_count
        |from
        |(
        |	select
        |	t1.clue_id,carrier_id,
        |	max(task_count) as task_count
        |	from
        |	(
        |		select
        |		clue_id,carrier_id,
        |		max(cast(task_count as bigint)) as task_count
        |		from dm_gis.dm_ddjy_clue_rel_carrier_di_month
        |		where inc_day='$incDay'
        |		group by clue_id,carrier_id
        |	)t1
        |	inner join
        |	(
        |		select clue_id,gas_id
        |		from dm_gis.dwd_ddjy_clue_rel_gas_station_di_month
        |		where inc_day='$incDay' and gas_id in (select poiid from dm_gis.dm_ddjy_gas_station_info_di where delflag = '0' and cooperatestatus=3)
        |		group by clue_id,gas_id
        |	)t2
        |	on t1.clue_id=t2.clue_id
        |	group by t1.clue_id,carrier_id
        |) t3
        |group by carrier_id
        |""".stripMargin
    val onlineGasTaskCountRdd: RDD[(String, Int)] = SparkUtils.getRowToJson(spark, onlineGasTaskCountSql).map(obj => {
      (obj.getString("carrier_id"), obj.getIntValue("online_gas_task_count"))
    })
    logger.error("计算online_gas_task_count数据量:"+onlineGasTaskCountRdd.count())
    onlineGasTaskCountRdd.filter(_._1=="100216").take(10).foreach(println(_))
    onlineGasTaskCountRdd
  }

  def carrierRlstMonthCollect(spark: SparkSession, carrierRlstRdd: RDD[(String, JSONObject)], carrierMergeMonthRdd: RDD[(String, JSONObject)], onlineGasTaskCountRdd: RDD[(String, Int)], incDay: String) = {
    import spark.implicits._
    val saturDay: String = DateUtil.getDateStr(incDay, 1, "")
    //计算vehicle_count
    val vehicleCountSql=
      s"""
        |select
        |carrier_id,
        |count(distinct vehicle) as vehicle_count
        |from dm_gis.dm_ddjy_clue_rel_car_di_month
        |where inc_day='${incDay}'
        |group by carrier_id
        |""".stripMargin
    val vehicleCountRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, vehicleCountSql).map(obj => {
      (obj.getString("carrier_id"), obj)
    })
    //读取guang_dong_province_white_list_df
    val whiteListSql=
      """
        |select company_name,
        |reference_amount_pub as whitelist_limit_corporate,
        |reference_amount_pri as whitelist_limit_individual
        |from dm_gis.guang_dong_province_white_list_df
        |""".stripMargin
    val whiteListRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, whiteListSql).map(obj => {
      (obj.getString("company_name"), obj)
    })
    //读取 dim_ddjy_vehicle_concat_yy_df
    val vehicleConcatYySql=
      s"""
        |select
        |owner_id,province_name,city_name
        |from
        |(
        |	select
        |	owner_id,province_name,city_name,
        |	row_number() over(partition by owner_id order by update_date desc) as rnk
        |	from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |	where inc_day='$saturDay'
        |	and province_name!=''
        |	and province_name is not null
        |) t1
        |where rnk=1
        |""".stripMargin
    val vehicleConcatYyRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, vehicleConcatYySql).map(obj => {
      (obj.getString("owner_id"), obj)
    })

    //读取 dm_ddjy_clue_rel_carrier_di_month
    val clueRelCarrierMonthSql=
      s"""
        |select carrier_id,task_count,task_day_count,plan_depart_tm_day_max,plan_depart_tm_day_min,
        |dis_sum,oil_sum,inc_day
        |from dm_gis.dm_ddjy_clue_rel_carrier_di_month
        |where inc_day='$incDay'
        |""".stripMargin
    val clueRelCarrierMonthRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, clueRelCarrierMonthSql).groupBy(_.getString("carrier_id")).map(obj=>{
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.maxBy(_.getString("inc_day"))
      val task_count: Int = list.map(_.getIntValue("task_count")).sum
      val task_day_count: Int = list.map(_.getIntValue("task_day_count")).sum
      val plan_depart_tm_day_max: String = list.map(_.getString("plan_depart_tm_day_max")).max
      val plan_depart_tm_day_min: String = list.map(_.getString("plan_depart_tm_day_min")).min
      val dis_sum: Double = list.map(_.getDoubleValue("dis_sum")).sum
      val oil_sum: Double = list.map(_.getDoubleValue("oil_sum")).sum
      var task_count_per_day: Int = task_count / task_day_count
      if (task_count_per_day == 0) {
        task_count_per_day = 1
      }
      val dis_sum_per_day: Double = dis_sum / task_day_count
      val oil_sum_per_day: Double = oil_sum / task_day_count
      tmpObj.put("task_count", task_count)
      tmpObj.put("task_day_count", task_day_count)
      tmpObj.put("plan_depart_tm_day_max", plan_depart_tm_day_max)
      tmpObj.put("plan_depart_tm_day_min", plan_depart_tm_day_min)
      tmpObj.put("dis_sum", dis_sum)
      tmpObj.put("oil_sum", oil_sum)
      tmpObj.put("task_count_per_day", task_count_per_day)
      tmpObj.put("dis_sum_per_day", dis_sum_per_day)
      tmpObj.put("oil_sum_per_day", oil_sum_per_day)
      (obj._1,tmpObj)
    })

    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance.getTime)
    val carrierRlstMonthDf: DataFrame = carrierRlstRdd.leftOuterJoin(carrierMergeMonthRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      (obj._1, leftObj)
    }).leftOuterJoin(onlineGasTaskCountRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val online_gas_task_count: Int = obj._2._2.getOrElse(0)
      leftObj.put("online_gas_task_count", online_gas_task_count)
      (obj._1, leftObj)
    }).leftOuterJoin(vehicleCountRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      (leftObj.getString("carrier_name"), leftObj)
    }).leftOuterJoin(whiteListRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).map(obj=>{
      (obj.getString("carrier_id"),obj)
    }).leftOuterJoin(vehicleConcatYyRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("province",rightObj.getString("province_name"))
        leftObj.put("city",rightObj.getString("city_name"))
      }
      (leftObj.getString("carrier_id"),leftObj)
    }).leftOuterJoin(clueRelCarrierMonthRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).map(obj => {
      CasecarrierRlstMonth(
        obj.getString("carrier_id"),
        obj.getString("task_batch"),
        obj.getString("carrier_name"),
        obj.getString("credit_code"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("src1"),
        obj.getString("linkman_phone"),
        obj.getString("src2"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("task_count"),
        obj.getString("vehicle_count"),
        obj.getString("task_day_count"),
        obj.getString("plan_depart_tm_day_max"),
        obj.getString("plan_depart_tm_day_min"),
        obj.getString("dis_sum"),
        obj.getString("task_count_per_day"),
        obj.getString("dis_sum_per_day"),
        obj.getString("oil_sum"),
        obj.getString("oil_sum_per_day"),
        obj.getString("vehicle_load_count_distribution"),
        obj.getString("clue_distribution"),
        obj.getString("gas_distribution"),
        obj.getString("city_distribution"),
        update_time,
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("register_vehicle_count"),
        obj.getString("city_adcode"),
        obj.getString("carrier_circle_id"),
        obj.getString("carrier_circle_task_count"),
        obj.getString("carrier_scale"),
        obj.getString("carrier_suspected_address"),
        obj.getString("carrier_priority"),
        obj.getString("pathway_city_distribution"),
        obj.getString("online_gas_top5"),
        obj.getString("carrier_white_list"),
        obj.getString("online_gas_top10"),
        obj.getString("online_gas_task_count"),
        obj.getString("whitelist_limit_corporate"),
        obj.getString("whitelist_limit_individual"),
        obj.getString("biz_day")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,carrierRlstMonthDf,"inc_day",incDay,"dm_gis.dm_ddjy_carrier_rlst_di_month",50)
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取dm_ddjy_carrier_rlst_di表
    val carrierRlstRdd: RDD[(String, JSONObject)] = readCarrierRlst(spark, incDay)
    //读取dm_ddjy_gas_carrier_merge_di_month
    val carrierMergeMonthRdd: RDD[(String, JSONObject)] = readCarrierMergeMonth(spark, incDay)
    //计算online_gas_task_count
    val onlineGasTaskCountRdd: RDD[(String, Int)] = onlineGasTaskCount(spark, incDay)
    //汇总各指标
    carrierRlstMonthCollect(spark,carrierRlstRdd,carrierMergeMonthRdd,onlineGasTaskCountRdd,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CasecarrierRlstMonth(carrier_id:String,
                                  task_batch:String,
                                  carrier_name:String,
                                  credit_code:String,
                                  legal_person_name:String,
                                  content:String,
                                  src1:String,
                                  linkman_phone:String,
                                  src2:String,
                                  province:String,
                                  city:String,
                                  task_count:String,
                                  vehicle_count:String,
                                  task_day_count:String,
                                  plan_depart_tm_day_max:String,
                                  plan_depart_tm_day_min:String,
                                  dis_sum:String,
                                  task_count_per_day:String,
                                  dis_sum_per_day:String,
                                  oil_sum:String,
                                  oil_sum_per_day:String,
                                  vehicle_load_count_distribution:String,
                                  clue_distribution:String,
                                  gas_distribution:String,
                                  city_distribution:String,
                                  update_time:String,
                                  carrier_status:String,
                                  carrier_tag:String,
                                  register_vehicle_count:String,
                                  city_adcode:String,
                                  carrier_circle_id:String,
                                  carrier_circle_task_count:String,
                                  carrier_scale:String,
                                  carrier_suspected_address:String,
                                  carrier_priority:String,
                                  pathway_city_distribution:String,
                                  online_gas_top5:String,
                                  carrier_white_list:String,
                                  online_gas_top10:String,
                                  online_gas_task_count:String,
                                  whitelist_limit_corporate:String,
                                  whitelist_limit_individual:String,
                                  biz_day:String
                                 )

}
