package app

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{CarrierInfoInterfacce, SfNetInteface, SparkWrite}

/**
 * @Description:
 * 需求人员：
 * @Author: lixiangzhi 01405644
 * @Date:
 * 任务id:
 * 任务名称：车牌号获取车队信息
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object CarnoGetCarrierInfo {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readCarNoAndColor(spark: SparkSession, incDay: String) = {
    /*val sourceSql=
      """
        |select * from dm_gis.
        |""".stripMargin
    val sourceRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, sourceSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调车队信息接口数据量:"+sourceRdd.count())*/
    val sourceDf: DataFrame = spark.read
      .option("inferschema", "false")
      .option("header", "true")
      .option("encoding", "UTF-8")
      .csv("/dolphinscheduler/user/01405644/cars_hb (2).csv")
    val sourceRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, sourceDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调车队信息接口数据量:"+sourceRdd.count())
    sourceRdd
  }

  def getCarrierInfoInterface(spark: SparkSession, sourceRdd: RDD[JSONObject], incDay: String) = {
    import spark.implicits._
    val resultDf: DataFrame = sourceRdd.repartition(50).map(obj => {
      val vehicle_no: String = obj.getString("vehicle_no")
      val plate_color: Int = obj.getIntValue("plate_color")
      obj.put("car_no", vehicle_no)
      obj.put("car_plate_color", plate_color)
      val retObj: JSONObject = CarrierInfoInterfacce.getCarrierInfo(obj)
      val data: JSONObject = JSONUtil.getJsonObjectMulti(retObj, "data")
      val frame_no: String = data.getString("frameNo")
      val is_guest_danger: String = data.getString("isLwlk")
      val load: String = data.getString("approvedLoad")
      val owner_name: String = data.getString("companyName")
      val car_no: String = data.getString("plateNo")
      val car_plate_color: String = data.getString("plateColor")
      (car_no, car_plate_color, frame_no, load, owner_name, is_guest_danger)
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取车队信息数据量:"+resultDf.count())
    //resultDf.repartition(1).write.save("d:\\user\\01405644\\桌面\\carrier_info")
    SparkWrite.writeTypeToHive(spark,resultDf,"into","inc_day","20230620","dm_gis.ddjy_qd_owner_info_di_test",1)

  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取车牌号和车牌颜色信息
    val sourceRdd: RDD[JSONObject] = readCarNoAndColor(spark, incDay)
    //调车队信息接口
    getCarrierInfoInterface(spark,sourceRdd,incDay)

    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
}
