package app

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:油站看板报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:
 * 任务名称：
 * 依赖任务：
 * 数据源：
 * 调用服务地址：无
 * 数据结果：
 */
object SalesPerformanceMonitorBulu {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def salesPerformance(spark: SparkSession, inc_day: String, other_day: String) = {
    //userid维度
    val now_day="20230615"
    val useridDf: DataFrame = spark.sql(
      s"""
         |select
         |sup_code,sub_code,t0.user_id,month,gmv_target,new_customer_target,
         |gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
         |sup_name,sub_name,user_name,
         |new_customer_id_daily,fisrt_consumed_id_daily
         |from
         |(
         |	select
         |	sup_code,sub_code,user_id,month,gmv_target,new_customer_target
         |	from
         |	(
         |		select
         |		sup_code,sub_code,
         |		outer_id as user_id,
         |		substr('${inc_day}',0,6) as month,
         |		month_trade_target as gmv_target,
         |		sign_target as new_customer_target,
         |		row_number() over(partition by outer_id order by update_date desc) as rnk
         |		from dm_gis.ddjy_sales_target_df
         |		where inc_day='${now_day}' and month=substr('${other_day}',0,7)
         |		and type='0'
         |		and name not like '%测试%'
         |		and org_name not like '%测试%'
         |	) t0_1
         |	where rnk=1
         |) t0
         |left join
         |(
         |	select
         |	user_id,
         |	sum(team_ft_sale_money) as gmv_daily,
         |	count(distinct t3.car_team_id) as new_customer_daily,
         |	concat_ws(',',collect_set(t2.car_team_id)) as consumed_id_daily,
         |	count(distinct t4.car_team_id) as fisrt_consumed_daily,
         |	count(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}',t1.team_id,null)) as sign_customer_daily,
         |	sum(team_total_sales) as new_customer_gmv_daily,
         |	concat_ws(',',collect_set(t3.car_team_id)) as new_customer_id_daily,
         |	concat_ws(',',collect_set(t4.car_team_id)) as fisrt_consumed_id_daily
         |	from
         |	(
         |		select
         |		user_id,team_id,create_date
         |		from dm_gis.ddjy_ods_sales_team
         |		where inc_day='${now_day}'
         |    and deleted='0'
         |	) t1
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(ft_sale_money) as team_ft_sale_money
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day='${inc_day}'
         |		and order_status='2'
         |		group by car_team_id
         |	) t2
         |	on t1.team_id=t2.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMMdd')='${inc_day}'
         |		group by car_team_id
         |	) t3
         |	on t1.team_id=t3.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id
         |		from
         |		(
         |			select
         |			car_team_id,
         |			date_format(min(first_pay_date),'yyyyMMdd') as min_first_pay_date
         |			from dm_gis.ddjy_dwd_station_stream_detail
         |			where inc_day='${inc_day}'
         |			group by car_team_id
         |		) t4_1
         |		where min_first_pay_date='${inc_day}'
         |	) t4
         |	on t1.team_id=t4.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(total_sales)  as team_total_sales
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMM')=substr('${inc_day}',0,6)
         |		group by car_team_id
         |	) t5
         |	on t1.team_id=t5.car_team_id
         |	group by user_id
         |) t6
         |on t0.user_id=t6.user_id
         |left join
         |(
         |	select
         |	user_id,sup_name,sub_name,user_name
         |	from dm_gis.ddjy_ods_sales_info
         |	where inc_day='${now_day}'
         |) t7
         |on t0.user_id=t7.user_id
         |""".stripMargin)
    useridDf.createOrReplaceTempView("useridTmp")
    //supcode维度
    val supcodeDf: DataFrame = spark.sql(
      s"""
         |select
         |t0.sup_code,sub_code,user_id,month,gmv_target,new_customer_target,
         |gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
         |sup_name,
         |'' as sub_name,
         |'' as user_name,
         |new_customer_id_daily,fisrt_consumed_id_daily
         |from
         |(
         |	select
         |	sup_code,sub_code,user_id,month,gmv_target,new_customer_target
         |	from
         |	(
         |		select
         |		sup_code,
         |		'' as sub_code,
         |		'' as user_id,
         |		substr('${inc_day}',0,6) as month,
         |		month_trade_target as gmv_target,
         |		sign_target as new_customer_target,
         |		row_number() over(partition by outer_id order by update_date desc) as rnk
         |		from dm_gis.ddjy_sales_target_df
         |		where inc_day='${now_day}' and month=substr('${other_day}',0,7)
         |		and type='1' and org_level='1'
         |		and name not like '%测试%'
         |		and org_name not like '%测试%'
         |	) t0_1
         |	where rnk=1
         |) t0
         |left join
         |(
         |	select
         |	sup_code,
         |	sum(team_ft_sale_money) as gmv_daily,
         |	count(distinct t3.car_team_id) as new_customer_daily,
         |	concat_ws(',',collect_set(t2.car_team_id)) as consumed_id_daily,
         |	count(distinct t4.car_team_id) as fisrt_consumed_daily,
         |	count(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}',t1.team_id,null)) as sign_customer_daily,
         |	sum(team_total_sales) as new_customer_gmv_daily,
         |	concat_ws(',',collect_set(t3.car_team_id)) as new_customer_id_daily,
         |	concat_ws(',',collect_set(t4.car_team_id)) as fisrt_consumed_id_daily
         |	from
         |	(
         |		select
         |		sup_code,team_id,create_date
         |		from
         |		(
         |			select
         |			sup_code,team_id,create_date,
         |			row_number() over(partition by sup_code,team_id order by create_date desc) as rnk
         |			from dm_gis.ddjy_ods_sales_team
         |			where inc_day='${now_day}'
         |      and deleted='0'
         |		) t1_1
         |		where rnk=1
         |	) t1
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(ft_sale_money) as team_ft_sale_money
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day='${inc_day}'
         |		and order_status='2'
         |		group by car_team_id
         |	) t2
         |	on t1.team_id=t2.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMMdd')='${inc_day}'
         |		group by car_team_id
         |	) t3
         |	on t1.team_id=t3.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id
         |		from
         |		(
         |			select
         |			car_team_id,
         |			date_format(min(first_pay_date),'yyyyMMdd') as min_first_pay_date
         |			from dm_gis.ddjy_dwd_station_stream_detail
         |			where inc_day='${inc_day}'
         |			group by car_team_id
         |		) t4_1
         |		where min_first_pay_date='${inc_day}'
         |	) t4
         |	on t1.team_id=t4.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(total_sales)  as team_total_sales
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMM')=substr('${inc_day}',0,6)
         |		group by car_team_id
         |	) t5
         |	on t1.team_id=t5.car_team_id
         |	group by sup_code
         |) t6
         |on t0.sup_code=t6.sup_code
         |left join
         |(
         |	select
         |	sup_code,sup_name
         |	from dm_gis.ddjy_ods_sales_info
         |	where inc_day='${now_day}'
         |  group by sup_code,sup_name
         |) t7
         |on t0.sup_code=t7.sup_code
         |""".stripMargin)
    supcodeDf.createOrReplaceTempView("supcodeTmp")
    //subcode维度
    val subcodeDf: DataFrame = spark.sql(
      s"""
         |select
         |sup_code,t0.sub_code,user_id,month,gmv_target,new_customer_target,
         |gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
         |sup_name,
         |sub_name,
         |'' as user_name,
         |new_customer_id_daily,fisrt_consumed_id_daily
         |from
         |(
         |	select
         |	sup_code,sub_code,user_id,month,gmv_target,new_customer_target
         |	from
         |	(
         |		select
         |		sup_code,
         |		sub_code,
         |		'' as user_id,
         |		substr('${inc_day}',0,6) as month,
         |		month_trade_target as gmv_target,
         |		sign_target as new_customer_target,
         |		row_number() over(partition by outer_id order by update_date desc) as rnk
         |		from dm_gis.ddjy_sales_target_df
         |		where inc_day='${now_day}' and month=substr('${other_day}',0,7)
         |		and type='1' and org_level='2'
         |		and name not like '%测试%'
         |		and org_name not like '%测试%'
         |	) t0_1
         |	where rnk=1
         |) t0
         |left join
         |(
         |	select
         |	sub_code,
         |	sum(team_ft_sale_money) as gmv_daily,
         |	count(distinct t3.car_team_id) as new_customer_daily,
         |	concat_ws(',',collect_set(t2.car_team_id)) as consumed_id_daily,
         |	count(distinct t4.car_team_id) as fisrt_consumed_daily,
         |	count(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}',t1.team_id,null)) as sign_customer_daily,
         |	sum(team_total_sales) as new_customer_gmv_daily,
         |	concat_ws(',',collect_set(t3.car_team_id)) as new_customer_id_daily,
         |	concat_ws(',',collect_set(t4.car_team_id)) as fisrt_consumed_id_daily
         |	from
         |	(
         |		select
         |		sub_code,team_id,create_date
         |		from
         |		(
         |			select
         |			sub_code,team_id,create_date,
         |			row_number() over(partition by sub_code,team_id order by create_date desc) as rnk
         |			from dm_gis.ddjy_ods_sales_team
         |			where inc_day='${now_day}'
         |      and deleted='0'
         |		) t1_1
         |		where rnk=1
         |	) t1
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(ft_sale_money) as team_ft_sale_money
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day='${inc_day}'
         |		and order_status='2'
         |		group by car_team_id
         |	) t2
         |	on t1.team_id=t2.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMMdd')='${inc_day}'
         |		group by car_team_id
         |	) t3
         |	on t1.team_id=t3.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id
         |		from
         |		(
         |			select
         |			car_team_id,
         |			date_format(min(first_pay_date),'yyyyMMdd') as min_first_pay_date
         |			from dm_gis.ddjy_dwd_station_stream_detail
         |			where inc_day='${inc_day}'
         |			group by car_team_id
         |		) t4_1
         |		where min_first_pay_date='${inc_day}'
         |	) t4
         |	on t1.team_id=t4.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(total_sales)  as team_total_sales
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMM')=substr('${inc_day}',0,6)
         |		group by car_team_id
         |	) t5
         |	on t1.team_id=t5.car_team_id
         |	group by sub_code
         |) t6
         |on t0.sub_code=t6.sub_code
         |left join
         |(
         |	select
         |	sup_name,sub_code,sub_name
         |	from dm_gis.ddjy_ods_sales_info
         |	where inc_day='${now_day}'
         |	group by sup_name,sub_code,sub_name
         |) t7
         |on t0.sub_code=t7.sub_code
         |""".stripMargin)
    subcodeDf.createOrReplaceTempView("subcodeTmp")
    val performanceSql=
      s"""
        |select
        |sup_code,sub_code,user_id,month,gmv_target,new_customer_target,gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
        |sup_name,sub_name,user_name,type,new_customer_id_daily,fisrt_consumed_id_daily
        |from
        |(
        |	select
        |	*,'1' as type
        |	from supcodeTmp
        |	union all
        |	select
        |	*,'2' as type
        |	from subcodeTmp
        |	union all
        |	select
        |	*,'3' as type
        |	from useridTmp
        |)  t1
        |where user_name not like '%测试%'
        |and user_name not like '%产品%'
        |and user_name not like '%张楠%'
        |and user_name not like '%李晗%'
        |and user_name not like '%刘芮%'
        |and user_name not like '%火全%'
        |and sub_code!='LIZHI'
        |and (sup_code!='' or sub_code!='')
        |and sup_name not like '%测试%'
        |""".stripMargin
    val performanceDf: DataFrame = spark.sql(performanceSql)
    performanceDf.repartition(1).createOrReplaceTempView("performanceTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_sales_performance_monitor_di partition(inc_day='${inc_day}') select * from performanceTmp")
    logger.error("写入ddjy_sales_performance_monitor_di每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    for (i <- (23 to 165).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val other_day: String = DateUtil.changeDateSep(incDay, "", "-")
      salesPerformance(spark,incDay,other_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>销售业绩监控表 Execute Ok")
  }

}
