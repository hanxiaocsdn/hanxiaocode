package app

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkJoin}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkWrite
import utils.SparkUtils

import scala.collection.mutable.ListBuffer

/**
 * Description:【吨吨加油】线索数据融合需求_V1.1-油站车队融合周维度表
 * 需求方：娇悦 01404184
 * Author: 李相志 01405644
 * Date: 14:30 2023/2/15
 * 任务id:524
 * 任务名称：油站车队融合周维度表
 * 依赖任务：车队业务分布统计表481、沿途线索聚合表482
 * 数据源：ddjy_carteam_business_distribution、ddjy_pathway_clue_statistic_di、dm_ddjy_gas_station_info_di、ddjy_station_near_road_clue_di、join_clue_pathway_frequency_di、dwd_ddjy_carrier_info_seed、ddjy_ods_dim_team_info、dm_ddjy_carrier_rlst_di
 * 调用服务地址：无
 * 数据结果：dm_ddjy_gas_carrier_merge_di
 */
object GasCarrierMergeBak {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def stationInfoProcess(spark: SparkSession, max_day: String) = {
    import spark.implicits._
    val stationInfoSql=
      """
        |select *
        |from dm_gis.dm_ddjy_gas_station_info_di
        |where delflag='0'
        |""".stripMargin
    val stationInfoDf: DataFrame = spark.sql(stationInfoSql)
    val gasCompetitorsDf: DataFrame = SparkUtils.getDfToJson(spark, stationInfoDf).map(obj => {
      val srclist: String = obj.getString("srclist")
      val poiid: String = obj.getString("poiid")
      val querybrandid: String = obj.getString("querybrandid")
      val management_model: String = obj.getString("management_model")
      val adcode: String = obj.getString("adcode")
      val province: String = obj.getString("province")
      val city: String = obj.getString("city")
      val district: String = obj.getString("district")
      val lng: String = obj.getString("lng")
      val lat: String = obj.getString("lat")
      val cooperatestatus: String = obj.getString("cooperatestatus")
      val tel: String = obj.getString("tel")
      val addr: String = obj.getString("addr")
      val src: String = obj.getString("src")
      val stationalias: String = obj.getString("stationalias")
      val stationtype: String = obj.getString("stationtype")
      val pricedieselout: String = obj.getString("pricedieselout")
      val srclistArr: Array[String] = srclist.split(",")
      val diffArr: Array[String] = Array("0", "1")
      val srclistDiffArr: Array[String] = srclistArr.diff(diffArr)
      val list = new ListBuffer[String]
      var gas_competitors = ""
      if (srclistDiffArr.nonEmpty) {
        for (elem <- srclistDiffArr) {
          val elem_new: String = elem match {
            case "2" => "TYB"
            case "3" => "TYC"
            case "4" => "WJY"
            case "5" => "SF"
            case "6" => "DDJY"
            case _ => ""
          }
          list.append(elem_new)
        }
        gas_competitors = list.mkString(",")
      }
      (poiid, querybrandid, management_model, gas_competitors,adcode,province,city,district,lng,lat,cooperatestatus,tel,addr,src,stationalias,stationtype,pricedieselout)
    }).toDF("poiid", "querybrandid", "management_model", "gas_competitors","adcode","province","city","district","lng","lat","cooperatestatus","tel","addr","src","stationalias","stationtype","pricedieselout")
        .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站数据量："+gasCompetitorsDf.count())
    gasCompetitorsDf
  }

  def stationNearRoad(spark: SparkSession, max_day: String) = {
    import spark.implicits._
    val stationNearRoadSql=
      s"""
        |select poiid,swid,
        |roadClass as gas_road_type,
        |formway as gas_road_function_type
        |from
        |(
        |	select *,row_number() over(partition by poiid order by cast(dist_min as int) asc,cast(roadclass as int) asc,cast(dist_max as int),cast(line_dist as int) asc) as rank1
        |	from
        |	(
        |		select *,
        |		case when cast(star_dist as int) >= cast(end_dist as int) then end_dist
        |			 else star_dist end as dist_min,
        |		case when cast(star_dist as int) >= cast(end_dist as int) then star_dist
        |			 else end_dist end as dist_max
        |		from dm_gis.ddjy_station_near_road_clue_di
        |		where inc_day = '$max_day'
        |	) t1
        |) t2
        |where rank1 = 1
        |""".stripMargin
    val stationNearRoadDf: DataFrame = spark.sql(stationNearRoadSql)
    val stationNearRoadProcessDf: DataFrame = SparkUtils.getDfToJson(spark, stationNearRoadDf).map(obj => {
      val poiid: String = obj.getString("poiid")
      val swid: String = obj.getString("swid")
      var gas_road_type: String = obj.getString("gas_road_type")
      var gas_road_function_type: String = obj.getString("gas_road_function_type")
      gas_road_type = gas_road_type match {
        case "0" => "高速公路"
        case "1" => "国道"
        case "2" => "省道"
        case "3" => "县道"
        case "4" => "乡公路"
        case "5" => "县乡村内部道路"
        case "6" => "主要大街、城市快速道"
        case "7" => "主要道路"
        case "8" => "次要道路"
        case "9" => "普通道路"
        case "10" => "非导航道路"
        case _ => ""
      }
      gas_road_function_type = gas_road_function_type match {
        case "1" => "上下线分离"
        case "2" => "交叉点内道路"
        case "3" => "JCT（连接高速与高速的匝道）"
        case "4" => "环岛"
        case "5" => "服务区道路"
        case "6" => "引路（一般道路与一般道路或高速道路的连接路）"
        case "7" => "辅路"
        case "8" => "引路+JCT"
        case "9" => "出口"
        case "10" => "入口"
        case "11" => "提右道路A"
        case "12" => "提右道路B"
        case "13" => "提左道路A"
        case "14" => "提左道路B"
        case "15" => "普通道路"
        case _ => ""
      }
      (poiid, gas_road_type, gas_road_function_type)
    }).distinct().toDF("poiid", "gas_road_type", "gas_road_function_type")
        .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站周边道路信息表数据量："+stationNearRoadProcessDf.count())
    stationNearRoadProcessDf
  }

  def pathwayCostRank(spark: SparkSession, max_day: String,inc_day:String) = {
    import spark.implicits._
    val aggContentNameSql=
      """
        |select * from dm_gis.ddjy_mid_agg_content_name_di
        |""".stripMargin
    val aggContentNameRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, aggContentNameSql, 2000)
    val cooperatestatusEqual3Rdd: RDD[JSONObject] = aggContentNameRdd.filter(_.getString("cooperatestatus") == "3").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("cooperatestatus==3的数据量:"+cooperatestatusEqual3Rdd.count())
    val stationInfoSql=
      """
        |select poiid,gappricevec,roadname
        |from dm_gis.dm_ddjy_gas_station_info_di
        |where delflag = '0'
        |and stationtype!='12'
        |and querybrandid!='2'
        |""".stripMargin
    val stationInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, stationInfoSql).map(obj => {
      (obj.getString("poiid"), obj)
    })
    val whiteListSql=
      """
        |select company_name from dm_gis.guang_dong_province_white_list_df
        |""".stripMargin
    val whiteListMap: collection.Map[String, Int] = SparkUtils.getRowToJson(spark, whiteListSql).map(obj => {
      (obj.getString("company_name"), 1)
    }).collectAsMap()

    val addOnlineGasTop5Map: collection.Map[String, JSONObject] = cooperatestatusEqual3Rdd.map(obj => {
      (obj.getString("gas_id"), obj)
    }).join(stationInfoRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.put("gappricevec", rightObj.getString("gappricevec"))
      leftObj.put("roadname", rightObj.getString("roadname"))
      leftObj
    }).groupBy(_.getString("carrier_id")).flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val stationNameConcatList: List[(Double, String,String)] = list.map(json => {
        val stationname: String = json.getString("stationname")
        val roadname: String = json.getString("roadname")
        val gappricevec: String = json.getString("gappricevec")
        var gappricevec_new: String = ""
        if(StringUtils.isNoneEmpty(gappricevec)){
          gappricevec_new = gappricevec.replace("[", "").replace("]", "").split(",")(0).toDouble.formatted("%.2f")
        }
        val task_sum_count: Double = json.getDoubleValue("task_sum_count")
        val stationNameConcat: String = stationname + ":" + roadname + "["+gappricevec_new+"]"
        val stationNameConcat10: String = stationname + "["+gappricevec_new+"]:" + task_sum_count
        (task_sum_count, stationNameConcat,stationNameConcat10)
      }).distinct
      val online_gas_top5: String = stationNameConcatList.sortBy(_._1).reverse.take(5).map(_._2).mkString(";")
      val online_gas_top10: String = stationNameConcatList.sortBy(_._1).reverse.take(10).map(_._3).mkString(";")
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("online_gas_top5", online_gas_top5)
        json.put("online_gas_top10", online_gas_top10)
        json
      })
      tmpList
    }).map(obj => {
      val tmpObj = new JSONObject()
      val carrier_id: String = obj.getString("carrier_id")
      val online_gas_top5: String = obj.getString("online_gas_top5")
      val online_gas_top10: String = obj.getString("online_gas_top10")
      tmpObj.put("carrier_id",carrier_id)
      tmpObj.put("online_gas_top5",online_gas_top5)
      tmpObj.put("online_gas_top10",online_gas_top10)
      (carrier_id,tmpObj)
    }).distinct().collectAsMap()
    logger.error("增加online_gas_top5字段后数据量:"+addOnlineGasTop5Map.size)
    val addOnlineGasTop5Bc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(addOnlineGasTop5Map)
    val whiteListBc: Broadcast[collection.Map[String, Int]] = spark.sparkContext.broadcast(whiteListMap)

    val carrierMergeDf: DataFrame =  aggContentNameRdd.map(obj=>{
      val carrier_id: String = obj.getString("carrier_id")
      val addOnlineGasTop5Value: collection.Map[String, JSONObject] = addOnlineGasTop5Bc.value
      val rightObj: JSONObject = addOnlineGasTop5Value.getOrElse(carrier_id, null)
      if (rightObj!=null){
        obj.fluentPutAll(rightObj)
      }
      obj
    }).map(obj => {
      val carrier_name: String = obj.getString("carrier_name")
      val whiteListValue: collection.Map[String, Int] = whiteListBc.value
      val tag: Int = whiteListValue.getOrElse(carrier_name, 0)
      var carrier_white_list = "0"
      if (tag ==1) {
        carrier_white_list = "1"
      }
      obj.put("carrier_white_list", carrier_white_list)
      obj
    }).map(obj => {
      CarrierMerge(
        obj.getString("gas_id"),
        obj.getString("stationname"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperatestatus"),
        obj.getString("tel"),
        obj.getString("brand"),
        obj.getString("gas_type"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("credit_code"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("city_adcode"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("clue_task_count"),
        obj.getString("clue_vehicle_count"),
        obj.getString("pathway_task_count"),
        obj.getString("pathway_vehicle_count"),
        obj.getString("pathway_around_task_count"),
        obj.getString("pathway_around_vehicle_count"),
        obj.getString("stay_task_count"),
        obj.getString("stay_vehicle_count"),
        obj.getString("one_carrier_gas_rank"),
        obj.getString("one_gas_carrier_rank"),
        obj.getString("clue_distribution"),
        obj.getString("clue_city_distribution"),
        obj.getString("pathway_city_distribution"),
        obj.getString("clue_dist_avg"),
        obj.getString("carrier_pathway_cost"),
        obj.getString("update_time"),
        obj.getString("task_batch"),
        obj.getString("gas_competitors"),
        obj.getString("gas_road_type"),
        obj.getString("gas_road_function_type"),
        obj.getString("task_sum_count"),
        obj.getString("pathway_cost_task_count"),
        obj.getString("tag"),
        obj.getString("carrier_circle_id"),
        obj.getString("carrier_scale"),
        obj.getString("carrier_suspected_address"),
        obj.getString("carrier_priority"),
        obj.getString("addr"),
        obj.getString("src"),
        obj.getString("circle_task_count"),
        obj.getString("register_vehicle_count"),
        obj.getString("suspected_adcode"),
        obj.getString("online_gas_top5"),
        obj.getString("carrier_white_list"),
        obj.getString("online_gas_top10"),
        obj.getString("stationalias"),
        obj.getString("stationtype"),
        obj.getString("pricedieselout")
      )
    }).toDF().repartition(50)
    carrierMergeDf.createOrReplaceTempView("carrierMergeTmp")
    spark.sql(s"insert overwrite table dm_gis.dm_ddjy_gas_carrier_merge_di partition(inc_day='${max_day}') select * from carrierMergeTmp")
    cooperatestatusEqual3Rdd.unpersist()
  }


  def carrierMergeMid(spark: SparkSession, gasCompetitorsDf: DataFrame, stationNearRoadProcessDf: DataFrame, inc_day: String,max_day:String) = {
    import spark.implicits._
    val last_eleven_day = DateUtil.getDateStr(max_day, -6, "")
    val taskSumCountSql=
      s"""
         |select
         |gas_id,carrier_id,
         |if(clue_task_count is null or clue_task_count='',0,clue_task_count)+if(pathway_cost_task_count is null or pathway_cost_task_count='',0,pathway_cost_task_count) as task_sum_count,
         |pathway_cost_task_count
         |from
         |(
         |	select gas_id,carrier_id,clue_task_count,
         |	case when pathway_task_count is null or pathway_task_count='' or carrier_pathway_cost is null or carrier_pathway_cost='' then ''
         |		 when cast(carrier_pathway_cost as double)>=0 and cast(carrier_pathway_cost as double)<200 then ceiling(pathway_task_count*1)
         |		 when cast(carrier_pathway_cost as double)>=200 and cast(carrier_pathway_cost as double)<500 then ceiling(pathway_task_count*0.75)
         |		 when cast(carrier_pathway_cost as double)>=500 and cast(carrier_pathway_cost as double)<1000 then ceiling(pathway_task_count*0.5)
         |		 when cast(carrier_pathway_cost as double)>=1000 and cast(carrier_pathway_cost as double)<2000 then ceiling(pathway_task_count*0.1)
         |		 when cast(carrier_pathway_cost as double)>=2000 then 0
         |		 end as pathway_cost_task_count
         |	from dm_gis.join_clue_pathway_frequency_di
         |	where inc_day = '$max_day'
         |) t1
         |""".stripMargin
    val taskSumCountDf: DataFrame = spark.sql(taskSumCountSql).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("频次总和数据量："+taskSumCountDf.count())
    taskSumCountDf.createOrReplaceTempView("taskSumCountTmp")
    //spark.sql(s"insert overwrite table dm_gis.task_sum_count_tmp partition(inc_day='${incDay}') select * from taskSumCountTmp")
    gasCompetitorsDf.createOrReplaceTempView("gasCompetitorsTmp")
    stationNearRoadProcessDf.createOrReplaceTempView("stationNearRoadProcessTmp")
    val tomorrow_time: String = DateUtil.getDateStr(max_day, 1, "")
    val allTableJoinSql=
      s"""
         |select
         |gas_id,stationname,adcode,province,city,district,lng,lat,cooperatestatus,tel,brand,gas_type,carrier_id,carrier_name,carrier_status,carrier_tag,clue_task_count,clue_vehicle_count,pathway_task_count,pathway_vehicle_count,pathway_around_task_count,pathway_around_vehicle_count,stay_task_count,stay_vehicle_count,
         |rank() over(partition by carrier_id order by task_sum_count desc) as one_carrier_gas_rank,
         |rank() over(partition by gas_id order by task_sum_count desc) as one_gas_carrier_rank,
         |clue_distribution,clue_city_distribution,pathway_city_distribution,clue_dist_avg,carrier_pathway_cost,update_time,task_batch,gas_competitors,gas_road_type,gas_road_function_type,task_sum_count,
         |ceiling(pathway_cost_task_count) as pathway_cost_task_count,
         |if(cast(task_sum_count as double) >=3,1,0) as tag,
         |carrier_circle_id,carrier_scale,carrier_suspected_address,carrier_priority,
         |addr,src,circle_task_count,register_vehicle_count,
         |suspected_adcode,
         |stationalias,stationtype,pricedieselout
         |from
         |(
         |	select
         |	t1.gas_id
         |	,t1.stationname
         |	,adcode
         |	,province
         |	,city
         |	,district
         |	,lng
         |	,lat
         |	,cooperatestatus
         |	,tel
         |	,querybrandid as brand
         |	,management_model as gas_type
         |	,t1.carrier_id
         |	,carrier_name
         |	,if(t4.name is null,0,1) as carrier_status
         |	,carrier_tag
         |	,clue_task_count
         |	,clue_vehicle_count
         |	,pathway_task_count
         |	,pathway_vehicle_count
         |	,pathway_around_task_count
         |	,pathway_around_vehicle_count
         |	,stay_task_count
         |	,stay_vehicle_count
         |	,clue_distribution
         |	,clue_city_distribution
         |	,pathway_city_distribution
         |	,clue_dist_avg
         |	,carrier_pathway_cost
         |	,from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as update_time
         |	,concat('${last_eleven_day}','-','${max_day}')  as task_batch
         |	,gas_competitors
         |	,gas_road_type
         |	,gas_road_function_type
         |	,task_sum_count
         |	,pathway_cost_task_count
         |	,row_number() over(partition by t1.gas_id,t1.carrier_id order by t1.gas_id) as rnk
         |	,sf_owner
         |	,carrier_circle_id
         |	,case when register_vehicle_count is null then '数据缺失'
         |	   when register_vehicle_count<=4 then '4及以下'
         |	   when register_vehicle_count>=5 and register_vehicle_count<=10 then '5~10'
         |	   when register_vehicle_count>=11 and register_vehicle_count<=20 then '11~20'
         |	   when register_vehicle_count>=21 and register_vehicle_count<=30 then '21~30'
         |	   when register_vehicle_count>=31 and register_vehicle_count<=40 then '31~40'
         |	   when register_vehicle_count>=41 and register_vehicle_count<=50 then '41~50'
         |	   when register_vehicle_count>=50 then '50以上'
         |	   end as carrier_scale
         |	,suspected_address as carrier_suspected_address
         |	,priority as carrier_priority
         |	,addr
         |	,src
         |	,circle_task_count
         |	,register_vehicle_count
         | ,suspected_adcode
         | ,stationalias,stationtype,pricedieselout
         |	from
         |	(
         |		select
         |		gas_id
         |		,stationname
         |		,carrier_id
         |		,carrier_name
         |		,clue_task_count
         |		,clue_dist_avg
         |		,cast(clue_vehicle_count as double) as clue_vehicle_count
         |		,cast(pathway_task_count as double) as pathway_task_count
         |		,cast(pathway_vehicle_count as double) as pathway_vehicle_count
         |		,cast(pathway_around_task_count as double) as pathway_around_task_count
         |		,cast(pathway_around_vehicle_count as double) as pathway_around_vehicle_count
         |		,cast(stay_task_count as double) as stay_task_count
         |		,cast(stay_vehicle_count as double) as stay_vehicle_count
         |		,carrier_pathway_cost
         |		from dm_gis.join_clue_pathway_frequency_di
         |		where inc_day='${max_day}'
         |	) t1
         |	left join gasCompetitorsTmp t2
         |	on t1.gas_id=t2.poiid
         |	left join
         |	(
         |		select name
         |	  from dm_gis.ddjy_ods_dim_team_info
         |	  where inc_day in(select max(inc_day) from dm_gis.ddjy_ods_dim_team_info)
         |	  and name!='' and name is not null
         |	  and del_flag = '0'
         |	  group by name
         |	) t4
         |	on t1.carrier_name=t4.name
         |	left join
         |	(
         |		select car_team_id,
         |    max(city_distribution_frequency) as pathway_city_distribution
         |		from dm_gis.ddjy_carteam_business_distribution
         |		where inc_day='${max_day}'
         |		group by car_team_id
         |	) t5
         |	on t1.carrier_id=t5.car_team_id
         |	left join
         |	(
         |		select carrier_id,carrier_tag,city_distribution as clue_city_distribution,clue_distribution,carrier_circle_id,carrier_circle_task_count as circle_task_count
         |		from dm_gis.dm_ddjy_mid_carrier_rlst_di
         |		where inc_day='${max_day}'
         |		group by carrier_id,carrier_tag,city_distribution,clue_distribution,carrier_circle_id,carrier_circle_task_count
         |	) t6
         |	on t1.carrier_id=t6.carrier_id
         |	left join stationNearRoadProcessTmp t7
         |	on t1.gas_id=t7.poiid
         |	left join taskSumCountTmp t8
         |	on t1.carrier_id=t8.carrier_id and t1.gas_id=t8.gas_id
         | left join dm_gis.dim_sf_owner_df t10
         | on t1.carrier_name=t10.sf_owner
         | left join
         | (
         |	  select owner_id as carrier_id,
         |	  count(distinct vehicle_no) as register_vehicle_count
         |	  from dm_gis.dim_ddjy_vehicle_concat_yy_df
         |	  where inc_day = '$tomorrow_time'
         |	  group by owner_id
         | ) t11
         | on t1.carrier_id=t11.carrier_id
         | left join
         | (
         |	  select owner_id,suspected_address,priority,adcode as suspected_adcode
         |	  from dm_gis.ddjy_suspected_business_address_di
         |	  where inc_day=(select max(inc_day) from dm_gis.ddjy_suspected_business_address_di where inc_day<='${inc_day}')
         |    and owner_id is not null
         | ) t12
         | on t1.carrier_id=t12.owner_id
         |) t9
         |where rnk=1 and sf_owner is null
         |and carrier_name not like '%顺丰%'
         |and carrier_name not like '%顺路%'
         |""".stripMargin
    val allTableJoinRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, allTableJoinSql, 2000).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("关联结果表数据量:"+allTableJoinRdd.count())
    taskSumCountDf.unpersist()
    gasCompetitorsDf.unpersist()
    stationNearRoadProcessDf.unpersist()
    val carriernNameArr: collection.Map[String, Int] = allTableJoinRdd.map(obj => {
      val carrier_name: String = obj.getString("carrier_name")
      (carrier_name,1)
    }).distinct().collectAsMap()
    val carriernNameBc: Broadcast[collection.Map[String, Int]] = spark.sparkContext.broadcast(carriernNameArr)
    val carrierInfoSql=
      s"""
         |select
         |name,legal_person_name,content,flag,credit_code,city_adcode
         |from
         |(
         |	select name,legal_person_name,content,flag,credit_code,city_adcode,
         |	row_number() over(partition by name,legal_person_name,content order by flag desc) as rnk
         |	from dm_gis.dwd_ddjy_carrier_info_di
         |	where inc_day='${max_day}'
         |	and flag!='0'
         |  and ((is_valid_number is null or is_valid_number ='') or (is_valid_number=1 and is_firm_number=1))
         |) t1
         |where rnk=1
         |""".stripMargin
    val addContentMap: collection.Map[String, JSONObject] = SparkUtils.getRowToJson(spark, carrierInfoSql).groupBy(_.getString("name")).map(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getIntValue("flag")).reverse
      val credit_code: String = list.maxBy(_.getString("credit_code")).getString("credit_code")
      val city_adcode: String = list.maxBy(_.getString("credit_code")).getString("city_adcode")
      val maxFlag: Int = list.maxBy(_.getIntValue("flag")).getIntValue("flag")
      val minFlag: Int = list.minBy(_.getIntValue("flag")).getIntValue("flag")
      var nameArray = new util.ArrayList[String]()
      var contentArray = new util.ArrayList[String]()
      list.foreach(json => {
        val legal_person_name: String = json.getString("legal_person_name")
        val content: String = json.getString("content")
        val content_agg: String = "(" + content + ")"
        val legal_person_name_agg: String = "(" + legal_person_name + ")"
        val flag: Int = json.getIntValue("flag")
        if (!(maxFlag==999 && minFlag!=999 && flag==999)){
          contentArray.add(content_agg)
          nameArray.add(legal_person_name_agg)
        }
      })
      var content: String = contentArray.toArray().mkString(",")
      if (contentArray.size()>=5){
        content = contentArray.toArray().take(5).mkString(",")
      }
      var legal_person_name: String = nameArray.toArray().mkString(",")
      if (nameArray.size()>5){
        legal_person_name = nameArray.toArray().take(5).mkString(",")
      }
      val tmpObj = new JSONObject()
      tmpObj.put("name", obj._1)
      tmpObj.put("content", content)
      tmpObj.put("legal_person_name", legal_person_name)
      tmpObj.put("credit_code", credit_code)
      tmpObj.put("city_adcode", city_adcode)
      tmpObj
    }).filter(obj=>{
      val name: String = obj.getString("name")
      val carriernNameValue: collection.Map[String, Int] = carriernNameBc.value
      val tag: Int = carriernNameValue.getOrElse(name, 0)
      tag==1
    }).map(obj=>{
      (obj.getString("name"),obj)
    }).collectAsMap()
    logger.error("聚合联系人和电话后数据量:"+addContentMap.size)
    carriernNameBc.unpersist()
    val addContentBc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(addContentMap)
    val aggContentAndNameDf: DataFrame = allTableJoinRdd.map(obj=>{
      val addContentValue: collection.Map[String, JSONObject] = addContentBc.value
      val carrier_name: String = obj.getString("carrier_name")
      val addContentObj: JSONObject = addContentValue.getOrElse(carrier_name, null)
      if (addContentObj!=null){
        obj.fluentPutAll(addContentObj)
      }
      obj
    }).map(obj => {
      AggContentAndName(
        obj.getString("gas_id"),
        obj.getString("stationname"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperatestatus"),
        obj.getString("tel"),
        obj.getString("brand"),
        obj.getString("gas_type"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("credit_code"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("city_adcode"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("clue_task_count"),
        obj.getString("clue_vehicle_count"),
        obj.getString("pathway_task_count"),
        obj.getString("pathway_vehicle_count"),
        obj.getString("pathway_around_task_count"),
        obj.getString("pathway_around_vehicle_count"),
        obj.getString("stay_task_count"),
        obj.getString("stay_vehicle_count"),
        obj.getString("one_carrier_gas_rank"),
        obj.getString("one_gas_carrier_rank"),
        obj.getString("clue_distribution"),
        obj.getString("clue_city_distribution"),
        obj.getString("pathway_city_distribution"),
        obj.getString("clue_dist_avg"),
        obj.getString("carrier_pathway_cost"),
        obj.getString("update_time"),
        obj.getString("task_batch"),
        obj.getString("gas_competitors"),
        obj.getString("gas_road_type"),
        obj.getString("gas_road_function_type"),
        obj.getString("task_sum_count"),
        obj.getString("pathway_cost_task_count"),
        obj.getString("tag"),
        obj.getString("carrier_circle_id"),
        obj.getString("carrier_scale"),
        obj.getString("carrier_suspected_address"),
        obj.getString("carrier_priority"),
        obj.getString("addr"),
        obj.getString("src"),
        obj.getString("circle_task_count"),
        obj.getString("register_vehicle_count"),
        obj.getString("suspected_adcode"),
        obj.getString("stationalias"),
        obj.getString("stationtype"),
        obj.getString("pricedieselout")
      )
    }).toDF()
    SparkWrite.writeToHiveNoPart(spark,aggContentAndNameDf,"dm_gis.ddjy_mid_agg_content_name_di",50)
    allTableJoinRdd.unpersist()
    addContentBc.unpersist()
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取分区最大值
    val join_clue_pathway_frequency_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.join_clue_pathway_frequency_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val join_clue_pathway_frequency_df: DataFrame = spark.sql(join_clue_pathway_frequency_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, join_clue_pathway_frequency_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    //获取油站数据并处理
    val gasCompetitorsDf: DataFrame = stationInfoProcess(spark, max_day)
    //获取油站道路类型&功能类型数据
    val stationNearRoadProcessDf: DataFrame = stationNearRoad(spark, max_day)
    carrierMergeMid(spark,gasCompetitorsDf,stationNearRoadProcessDf,incDay,max_day)
    //按照途径频次进行排序
    pathwayCostRank(spark,max_day,incDay)


  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>GasCarrierMerge Execute Ok")
  }
  case class CarrierMerge(gas_id:String,
                          stationname:String,
                          adcode:String,
                          province:String,
                          city:String,
                          district:String,
                          lng:String,
                          lat:String,
                          cooperatestatus:String,
                          tel:String,
                          brand:String,
                          gas_type:String,
                          carrier_id:String,
                          carrier_name:String,
                          credit_code:String,
                          legal_person_name:String,
                          content:String,
                          city_adcode:String,
                          carrier_status:String,
                          carrier_tag:String,
                          clue_task_count:String,
                          clue_vehicle_count:String,
                          pathway_task_count:String,
                          pathway_vehicle_count:String,
                          pathway_around_task_count:String,
                          pathway_around_vehicle_count:String,
                          stay_task_count:String,
                          stay_vehicle_count:String,
                          one_carrier_gas_rank:String,
                          one_gas_carrier_rank:String,
                          clue_distribution:String,
                          clue_city_distribution:String,
                          pathway_city_distribution:String,
                          clue_dist_avg:String,
                          carrier_pathway_cost:String,
                          update_time:String,
                          task_batch:String,
                          gas_competitors:String,
                          gas_road_type:String,
                          gas_road_function_type:String,
                          task_sum_count:String,
                          pathway_cost_task_count:String,
                          tag:String,
                          carrier_circle_id:String,
                          carrier_scale:String,
                          carrier_suspected_address:String,
                          carrier_priority:String,
                          addr:String,
                          src:String,
                          circle_task_count:String,
                          register_vehicle_count:String,
                          suspected_adcode:String,
                          online_gas_top5:String,
                          carrier_white_list:String,
                          online_gas_top10:String,
                          stationalias:String,
                          stationtype:String,
                          pricedieselout:String
                         )
  case class AggContentAndName(gas_id:String,
                          stationname:String,
                          adcode:String,
                          province:String,
                          city:String,
                          district:String,
                          lng:String,
                          lat:String,
                          cooperatestatus:String,
                          tel:String,
                          brand:String,
                          gas_type:String,
                          carrier_id:String,
                          carrier_name:String,
                          credit_code:String,
                          legal_person_name:String,
                          content:String,
                          city_adcode:String,
                          carrier_status:String,
                          carrier_tag:String,
                          clue_task_count:String,
                          clue_vehicle_count:String,
                          pathway_task_count:String,
                          pathway_vehicle_count:String,
                          pathway_around_task_count:String,
                          pathway_around_vehicle_count:String,
                          stay_task_count:String,
                          stay_vehicle_count:String,
                          one_carrier_gas_rank:String,
                          one_gas_carrier_rank:String,
                          clue_distribution:String,
                          clue_city_distribution:String,
                          pathway_city_distribution:String,
                          clue_dist_avg:String,
                          carrier_pathway_cost:String,
                          update_time:String,
                          task_batch:String,
                          gas_competitors:String,
                          gas_road_type:String,
                          gas_road_function_type:String,
                          task_sum_count:String,
                          pathway_cost_task_count:String,
                          tag:String,
                          carrier_circle_id:String,
                          carrier_scale:String,
                          carrier_suspected_address:String,
                          carrier_priority:String,
                          addr:String,
                          src:String,
                          circle_task_count:String,
                          register_vehicle_count:String,
                          suspected_adcode:String,
                          stationalias:String,
                          stationtype:String,
                          pricedieselout:String
                         )
}
