package app

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.{SparkUtils, SparkWrite}
import scala.collection.JavaConversions._
/**
 * @Description:企业微信客户群详情表
 * 需求人员：ft220534 陈治仁
 * @Author: lixiangzhi 01405644
 * @Date:20231213
 * 任务id:
 * 任务名称：企业微信客户群详情表
 * 依赖任务：
 * 数据源：
 * 调用服务地址：无
 * 数据结果：
 */
object WeComCustomerBaseDetailsAnalyze {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readCustomerBaseDetails(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val customerBaseDetailsSql=
      s"""
        |select * from dm_gis.ods_wecom_customer_base_details_di where inc_day='$incDay'
        |""".stripMargin
    val customerBaseDetailsDf: DataFrame = SparkUtils.getRowToJson(spark, customerBaseDetailsSql).flatMap(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val group_chat: JSONObject = JSONUtil.getJsonObjectMulti(dataObj, "group_chat")
      val member_list: JSONArray = JSONUtil.getJsonArrayMulti(group_chat, "member_list")
      val chat_id: String = dataObj.getString("chat_id")
      var group_name: String = group_chat.getString("name")
      if (StringUtils.isEmpty(group_name)) {
        group_name = "群聊"
      }else if(group_name.contains("【吨吨】")){
        group_name = "【吨吨】"+group_name.split("【吨吨】")(1)
      }else if(group_name.contains("【顺象】")){
        group_name = "【顺象】"+group_name.split("【顺象】")(1)
      }
      val group_owner: String = group_chat.getString("owner")
      var group_create_time: String = group_chat.getString("create_time")
      if (StringUtils.isNoneEmpty(group_create_time)){
        group_create_time = DateUtil.longToTimes(group_create_time.toLong)
      }
      var group_notice: String = group_chat.getString("notice")
      if (StringUtils.isNoneEmpty(group_notice)){
        group_notice = group_notice.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "").replaceAll("\r\n", "")
      }
      val member_version: String = group_chat.getString("member_version")
      val admin_list: JSONArray = JSONUtil.getJsonArrayMulti(group_chat, "admin_list")
      val userid_list = new util.ArrayList[String]()
      if (admin_list.size() != 0) {
        for (j <- 0 until (admin_list.size())) {
          val admin_list_obj: JSONObject = admin_list.getJSONObject(j)
          val userid: String = admin_list_obj.getString("userid")
          userid_list.append(userid)
        }
      }
      val admin_userid: String = userid_list.mkString(",")
      var group_status: String = dataObj.getString("status")
      if (group_status=="0"){
        group_status="跟进人正常"
      }else if(group_status=="1"){
        group_status="跟进人离职"
      }else if(group_status=="2"){
        group_status="离职继承中"
      }else if(group_status=="3"){
        group_status="离职继承完成"
      }
      val errcode: String = dataObj.getString("errcode")
      val errmsg: String = dataObj.getString("errmsg")
      val tmpList = new util.ArrayList[JSONObject]()
      if (member_list.size() != 0) {
        for (i <- 0 until (member_list.size())) {
          val tmpObj = new JSONObject()
          val member_list_obj: JSONObject = member_list.getJSONObject(i)
          val group_member_userid: String = member_list_obj.getString("userid")
          var member_type: String = member_list_obj.getString("type")
          if (member_type=="1"){
            member_type="企业成员"
          }else if(member_type=="2"){
            member_type="外部联系人"
          }
          val group_member_unionid: String = member_list_obj.getString("unionid")
          var join_time: String = member_list_obj.getString("join_time")
          if (StringUtils.isNoneEmpty(join_time)){
            join_time = DateUtil.longToTimes(join_time.toLong)
          }
          var join_scene: String = member_list_obj.getString("join_scene")
          if (join_scene=="1"){
            join_scene = "由群成员邀请入群（直接邀请入群）"
          }else if(join_scene=="2"){
            join_scene = "由群成员邀请入群（通过邀请链接入群）"
          }else if(join_scene=="3"){
            join_scene = "通过扫描群二维码入群"
          }
          val invitor: JSONObject = JSONUtil.getJsonObjectMulti(member_list_obj, "invitor")
          val invitor_userid: String = invitor.getString("userid")
          val group_nickname: String = member_list_obj.getString("group_nickname")
          val name: String = member_list_obj.getString("name")
          tmpObj.put("group_member_userid", group_member_userid)
          tmpObj.put("member_type", member_type)
          tmpObj.put("group_member_unionid", group_member_unionid)
          tmpObj.put("join_time", join_time)
          tmpObj.put("join_scene", join_scene)
          tmpObj.put("invitor", invitor)
          tmpObj.put("invitor_userid", invitor_userid)
          tmpObj.put("group_nickname", group_nickname)
          tmpObj.put("name", name)
          tmpObj.put("chat_id", chat_id)
          tmpObj.put("group_name", group_name)
          tmpObj.put("group_owner", group_owner)
          tmpObj.put("group_create_time", group_create_time)
          tmpObj.put("group_notice", group_notice)
          tmpObj.put("member_version", member_version)
          tmpObj.put("admin_userid", admin_userid)
          tmpObj.put("group_status", group_status)
          tmpObj.put("errcode", errcode)
          tmpObj.put("errmsg", errmsg)
          tmpList.append(tmpObj)
        }
      }else{
        val tmpObj = new JSONObject()
        tmpObj.put("errcode", errcode)
        tmpObj.put("errmsg", errmsg)
        tmpObj.put("chat_id", chat_id)
        tmpObj.put("group_status", group_status)
        tmpList.append(tmpObj)
      }
      tmpList.iterator()
    }).map(obj => {
      CaseCustomerBase(
        obj.getString("chat_id"),
        obj.getString("group_name"),
        obj.getString("group_owner"),
        obj.getString("group_create_time"),
        obj.getString("group_notice"),
        obj.getString("group_member_userid"),
        obj.getString("member_type"),
        obj.getString("group_member_unionid"),
        obj.getString("join_time"),
        obj.getString("join_scene"),
        obj.getString("invitor"),
        obj.getString("invitor_userid"),
        obj.getString("group_nickname"),
        obj.getString("name"),
        obj.getString("admin_userid"),
        obj.getString("member_version"),
        obj.getString("group_status"),
        obj.getString("errcode"),
        obj.getString("errmsg")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,customerBaseDetailsDf,"inc_day",incDay,"dm_gis.dm_ddjy_wecom_customer_base_details_di")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取ods_wecom_customer_base_details_di
    readCustomerBaseDetails(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }


  case class CaseCustomerBase(
                              chat_id:String,
                              group_name:String,
                              group_owner:String,
                              group_create_time:String,
                              group_notice:String,
                              group_member_userid:String,
                              member_type:String,
                              group_member_unionid:String,
                              join_time:String,
                              join_scene:String,
                              invitor:String,
                              invitor_userid:String,
                              group_nickname:String,
                              name:String,
                              admin_userid:String,
                              member_version:String,
                              group_status:String,
                              errcode:String,
                              errmsg:String
                             )

}
