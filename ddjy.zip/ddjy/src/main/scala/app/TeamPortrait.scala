package app

import java.math.RoundingMode
import java.text.NumberFormat
import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{DistanceUtils, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.PointArea

import scala.collection.JavaConversions._
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks

/**
 * @Description:车队标签
 * 需求方：左佳怡 01403789
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:526
 * 任务名称：车队标签表
 * 依赖任务：吨吨加油-订单过滤明细表去重 352、每日-原始油站信息过滤表 512、每日-原始车队信息过滤表 501
 * 数据源：ddjy_dwd_station_order_repartition_di、ddjy_dim_station_info_filter、ddjy_ods_dim_team_info、dim_ddjy_vehicle_concat_yy_df、ddjy_carteam_business_distribution
 * 调用服务地址：
 * 数据结果：ddjy_carteam_label
 */
object TeamPortrait {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readOrderData(spark: SparkSession, incDay: String) = {
    val orderSql=
      s"""
        |select
        |station_id,car_team_id,create_date,ft_sale_money,station_pay_money,car_team_name,province_name,city_name,coords,t2.inc_day,station_name,oil_mass
        |from
        |(
        |	select
        |	  station_id,car_team_id,create_date,ft_sale_money,station_pay_money,car_team_name,oil_mass
        |	from
        |	(
        |		select
        |		station_id,car_team_id,create_date,ft_sale_money,station_pay_money,
        |		row_number() over(partition by order_sn order by update_date desc) as rownum,
        |		case when car_team_name REGEXP '弘大' then '汕头市弘大物流有限公司'
        |			 when car_team_name REGEXP '鑫连汇' then '汕头市鑫连汇物流有限公司'
        |			 when car_team_name REGEXP '广逸' then '东莞市广逸物流有限公司'
        |			 when car_team_name REGEXP '鸿琪' then '深圳市鸿琪物流有限公司'
        |			 when car_team_name REGEXP '宜送' then '福建宜送物流有限公司'
        |			 when car_team_name REGEXP '程飞运输' then '汕头市程飞运输有限公司'
        |			 when car_team_name REGEXP '宇轩' then '广州市宇轩物流有限公司'
        |		else car_team_name end as car_team_name,
        |   oil_mass
        |		from dm_gis.ddjy_dwd_station_order_repartition_di
        |		where inc_day <= '${incDay}'
        |		and order_sn != '1'
        |		and discard_time is null
        |		and car_team_name is not null
        |		and del_flag = '0'
        |		and order_status in ('1','2')
        |		and car_team_name not REGEXP 'FT'
        |		and car_team_name not REGEXP '测试'
        |		and car_team_name not REGEXP '商务'
        |		and car_team_name not REGEXP '演示'
        |		and car_team_name not REGEXP '吨吨'
        |		and car_team_name not REGEXP '深圳登联'
        |		and car_team_name not REGEXP '深圳现代物流园'
        |		and station_name not REGEXP 'FT'
        |		and station_name not REGEXP '测试'
        |		and station_name not REGEXP '商务'
        |		and station_name not REGEXP '演示'
        |		and station_name not REGEXP '吨吨'
        |		and station_name not REGEXP '深圳登联'
        |		and station_name not REGEXP '深圳现代物流园'
        |	) a
        |	where a.rownum = 1
        |) t1
        |left join
        |(
        |	select
        |	id,
        |	petrol_station_name as station_name,
        |	province_name,
        |	city_name,
        |	concat(x,',',y) as coords,
        | inc_day
        |	from dm_gis.ddjy_dim_station_info_filter
        |	where inc_day = '${incDay}'
        |	and petrol_resources = '2'
        |	and del_flag = '0'
        |) t2
        |on t1.station_id=t2.id
        |""".stripMargin
    logger.error(orderSql)
    val orderDf: DataFrame = spark.sql(orderSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("订单关联油站后数据量："+orderDf.count())
    orderDf.createOrReplaceTempView("orderTmp")
    spark.sql(s"insert overwrite table dm_gis.order_join_station_tmp select * from orderTmp")
    orderDf
  }

  def calculateTeamTag(spark: SparkSession, orderDf: DataFrame, incDay: String) = {
    import spark.implicits._
    val sum_team_id: Int = SparkUtils.getDfToJson(spark, orderDf).map(obj => {
      obj.getString("car_team_id")
    }).distinct().count().toInt
    logger.error("车队数量："+sum_team_id)
    val addFieldRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, orderDf).map(obj => {
      (obj.getString("car_team_id"), obj)
    }).groupByKey().map(obj => {
      val tmpObj = new JSONObject()
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getString("create_date"))
      val car_team_name: String = list.head.getString("car_team_name")
      val create_date_detail: String = list.map(_.getString("create_date")).mkString("|")
      val create_date2_detail: String = list.map(json => {
        json.getString("create_date").substring(0, 10)
      }).mkString("|")
      val create_date_stamp_detail: String = list.map(json => {
        val create_date: String = json.getString("create_date")
        val create_date_tm: Long = DateUtil.dateToStamp(create_date, "yyyy-MM-dd HH:mm:ss") / 1000
        create_date_tm
      }).mkString("|")
      val ft_sale_money_detail: String = list.map(_.getString("ft_sale_money")).mkString("|")
      val station_pay_money_detail: String = list.map(_.getString("station_pay_money")).mkString("|")
      val ft_sale_money: Double = list.map(_.getDoubleValue("ft_sale_money")).sum
      val station_pay_money: Double = list.map(_.getDoubleValue("station_pay_money")).sum
      val Oilmass: Double = list.map(_.getDoubleValue("oil_mass")).sum
      val order_count: Int = list.length
      val Last_date: String = list.map(_.getString("create_date")).last
      val First_date: String = list.map(_.getString("create_date")).head
      val inc_day: String = list.map(_.getString("inc_day")).head
      val Inc_day_second: String = DateUtil.changeDateSep(inc_day, "", "-") + " 23:59:59"
      val Last_date_days: Int = ((DateUtil.dateToStamp(Inc_day_second, "yyyy-MM-dd HH:mm:ss") / 1000 - DateUtil.dateToStamp(Last_date, "yyyy-MM-dd HH:mm:ss") / 1000) / (3600 * 24)).floor.toInt
      val first_date_days: Int = ((DateUtil.dateToStamp(Inc_day_second, "yyyy-MM-dd HH:mm:ss") / 1000 - DateUtil.dateToStamp(First_date, "yyyy-MM-dd HH:mm:ss") / 1000) / (3600 * 24)).floor.toInt
      val create_date2: String = list.map(json => {
        json.getString("create_date").substring(0, 10)
      }).distinct.mkString("|")
      val list_create_day: List[String] = list.map(json => {
        json.getString("create_date").substring(0, 10)
      }).distinct
      var Diff_days: String = "只充值过一次,不存在加油间隔"
      val listbf: ListBuffer[Int] = ListBuffer()
      if (list_create_day.length > 1) {
        for (i <- list_create_day.indices) {
          if (i < list_create_day.length - 1) {
            val Diff_day: Int = ((DateUtil.dateToStamp(list_create_day(i+1), "yyyy-MM-dd") / 1000 - DateUtil.dateToStamp(list_create_day(i), "yyyy-MM-dd") / 1000) / (3600 * 24)).floor.toInt
            listbf.append(Diff_day)
          }
        }
      }
      if (listbf.nonEmpty) {
        Diff_days = listbf.mkString("|")
        val Diff_days_min: Int = listbf.min
        val Diff_days_max: Int = listbf.max
        val Diff_days_avg = (listbf.sum / listbf.size)
        tmpObj.put("Diff_days_min", Diff_days_min)
        tmpObj.put("Diff_days_max", Diff_days_max)
        tmpObj.put("Diff_days_avg", Diff_days_avg)
      }
      var Rscore = 1
      var Rscore_threshold = "[30,+∞)"
      if (Last_date_days >= 0 && Last_date_days <= 1) {
        Rscore = 5
        Rscore_threshold = "[0,1]"
      } else if (Last_date_days >= 2 && Last_date_days <= 7) {
        Rscore = 4
        Rscore_threshold = "[2,7]"
      } else if (Last_date_days >= 8 && Last_date_days <= 15) {
        Rscore = 3
        Rscore_threshold = "[8,15]"
      } else if (Last_date_days >= 16 && Last_date_days <= 29) {
        Rscore = 2
        Rscore_threshold = "[16,29]"
      }
      tmpObj.put("car_team_id", obj._1)
      tmpObj.put("car_team_name", car_team_name)
      tmpObj.put("create_date_detail", create_date_detail)
      tmpObj.put("create_date2_detail", create_date2_detail)
      tmpObj.put("create_date_stamp_detail", create_date_stamp_detail)
      tmpObj.put("ft_sale_money_detail", ft_sale_money_detail)
      tmpObj.put("station_pay_money_detail", station_pay_money_detail)
      tmpObj.put("ft_sale_money", ft_sale_money)
      tmpObj.put("station_pay_money", station_pay_money)
      tmpObj.put("order_count", order_count)
      tmpObj.put("Last_date", Last_date)
      tmpObj.put("First_date", First_date)
      tmpObj.put("Inc_day_second", Inc_day_second)
      tmpObj.put("Last_date_days", Last_date_days)
      tmpObj.put("first_date_days", first_date_days)
      tmpObj.put("create_date2", create_date2)
      tmpObj.put("Diff_days", Diff_days)
      tmpObj.put("Rscore", Rscore)
      tmpObj.put("Rscore_threshold", Rscore_threshold)
      tmpObj.put("sum_team_id", sum_team_id)
      tmpObj.put("Oilmass", Oilmass)
      (tmpObj.getString("car_team_id"), tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加部分标签后数据量："+addFieldRdd.count())
    val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
    val vehicleConcatSql=
      s"""
        |select
        |b.id as id,
        |c.owner_id as owner_id,
        |'yy' as source
        |from
        |(
        |	select
        |	distinct id,
        |	name,
        |	tax_no
        |	from dm_gis.ddjy_ods_dim_team_info
        |	where inc_day = '${incDay}'
        |	and del_flag = '0'
        |	and tax_no is not null
        |) b
        |join
        |(
        |	select
        |	distinct owner_id,
        |	owner_name,
        |	credit_code
        |	from dm_gis.ddjy_vehicle_ownership_day_dtl
        |	where inc_day='$before_yesterday'
        |	and credit_code is not null and credit_code != ''
        |) c
        |on b.tax_no = c.credit_code
        |""".stripMargin
    val vehicleConcatDf: DataFrame = spark.sql(vehicleConcatSql).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("车队联系方式表数据量："+vehicleConcatDf.count())

    val vehicleConcatRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleConcatDf).map(obj => {
      (obj.getString("id"), obj)
    })
    val addTeamTagRdd: RDD[JSONObject] = addFieldRdd.leftOuterJoin(vehicleConcatRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val owner_id: String = rightObj.getString("owner_id")
        val source: String = rightObj.getString("source")
        leftObj.put("owner_id", owner_id)
        leftObj.put("source", source)
      }
      (1, leftObj)
    }).groupByKey()
      .flatMap(obj => {
        val tmpList: ListBuffer[JSONObject] = ListBuffer()
        val list: List[JSONObject] = obj._2.toList.sortBy(_.getDoubleValue("order_count")).reverse
        for (i <- list.indices) {
          val c1: Int = (sum_team_id * 0.0359).round.toInt
          val c2: Int = (sum_team_id * 0.0838).round.toInt
          val c3: Int = (sum_team_id * 0.1078).round.toInt
          val c4: Int = (sum_team_id * 0.2216).round.toInt
          val c5: Int = sum_team_id - (c1 + c2 + c3 + c4)
          var Fscore = 0
          val j = i + 1
          if (j <= c1) {
            Fscore = 5
          } else if (j > c1 && j <= c1 + c2) {
            Fscore = 4
          } else if (j > c1 + c2 && j <= c1 + c2 + c3) {
            Fscore = 3
          } else if (j > c1 + c2 + c3 && j <= c1 + c2 + c3 + c4) {
            Fscore = 2
          } else if (j > c1 + c2 + c3 + c4 && j <= c1 + c2 + c3 + c4 + c5) {
            Fscore = 1
          }
          val a1: Int = list(c1 - 1).getIntValue("order_count")
          val a2: Int = list(c1 + c2 - 1).getIntValue("order_count")
          val a3: Int = list(c1 + c2 + c3 - 1).getIntValue("order_count")
          val a4: Int = list(c1 + c2 + c3 + c4 - 1).getIntValue("order_count")
          //val a5: Int = list(c1+c2+c3+c4+c5).getIntValue("order_count")
          val order_count: Int = list(i).getIntValue("order_count")
          var Fscore_threshold = ""
          if (order_count >= a1) {
            Fscore_threshold = s"[$a1,+∞)"
          } else if (order_count >= a2 && order_count < a1) {
            Fscore_threshold = s"[$a2,$a1)"
          } else if (order_count >= a3 && order_count < a2) {
            Fscore_threshold = s"[$a3,$a2)"
          } else if (order_count >= a4 && order_count < a3) {
            Fscore_threshold = s"[$a4,$a3)"
          } else if (order_count >= 0 && order_count < a4) {
            Fscore_threshold = s"[0,$a4)"
          }
          list(i).put("Fscore", Fscore)
          list(i).put("Fscore_threshold", Fscore_threshold)
          tmpList.append(list(i))
        }
        tmpList.toIterator
      }).map(obj => {
      (1, obj)
    }).groupByKey().flatMap(obj => {
      val tmpList: ListBuffer[JSONObject] = ListBuffer()
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getDoubleValue("ft_sale_money")).reverse
      for (i <- list.indices) {
        val c1: Int = (sum_team_id * 0.0539).round.toInt
        val c2: Int = (sum_team_id * 0.0838).round.toInt
        val c3: Int = (sum_team_id * 0.1557).round.toInt
        val c4: Int = (sum_team_id * 0.2515).round.toInt
        val c5: Int = sum_team_id - (c1 + c2 + c3 + c4)
        var Mscore = 0
        val j = i + 1
        if (j <= c1) {
          Mscore = 5
        } else if (j > c1 && j <= c1 + c2) {
          Mscore = 4
        } else if (j > c1 + c2 && j <= c1 + c2 + c3) {
          Mscore = 3
        } else if (j > c1 + c2 + c3 && j <= c1 + c2 + c3 + c4) {
          Mscore = 2
        } else if (j > c1 + c2 + c3 + c4 && j <= c1 + c2 + c3 + c4 + c5) {
          Mscore = 1
        }
        val a1: Double = list(c1 - 1).getDoubleValue("ft_sale_money")
        val a2: Double = list(c1 + c2 - 1).getDoubleValue("ft_sale_money")
        val a3: Double = list(c1 + c2 + c3 - 1).getDoubleValue("ft_sale_money")
        val a4: Double = list(c1 + c2 + c3 + c4 - 1).getDoubleValue("ft_sale_money")
        //val a5: Double = list(c1+c2+c3+c4+c5).getDoubleValue("ft_sale_money")
        val ft_sale_money: Double = list(i).getDoubleValue("ft_sale_money")
        var Mscore_threshold = ""
        if (ft_sale_money >= a1) {
          Mscore_threshold = s"[$a1,+∞)"
        } else if (ft_sale_money >= a2 && ft_sale_money < a1) {
          Mscore_threshold = s"[$a2,$a1)"
        } else if (ft_sale_money >= a3 && ft_sale_money < a2) {
          Mscore_threshold = s"[$a3,$a2)"
        } else if (ft_sale_money >= a4 && ft_sale_money < a3) {
          Mscore_threshold = s"[$a4,$a3)"
        } else if (ft_sale_money >= 0 && ft_sale_money < a4) {
          Mscore_threshold = s"[0,$a4)"
        }
        list(i).put("Mscore", Mscore)
        list(i).put("Mscore_threshold", Mscore_threshold)
        tmpList.append(list(i))
      }
      tmpList.toIterator
    }).map(obj => {
      (1, obj)
    }).groupByKey().flatMap(obj => {
      val tmpList: ListBuffer[JSONObject] = ListBuffer()
      val list: List[JSONObject] = obj._2.toList
      val sum_rscore: Int = list.map(_.getIntValue("Rscore")).sum
      val size_score: Int = list.size
      val Rscore_avg: Double = sum_rscore / size_score
      val sum_Fscore: Int = list.map(_.getIntValue("Fscore")).sum
      val size_Fscore: Int = list.size
      val Fscore_avg: Double = sum_Fscore / size_Fscore
      val sum_Mscore: Int = list.map(_.getIntValue("Mscore")).sum
      val size_Mscore: Int = list.size
      val Mscore_avg: Double = sum_Mscore / size_Mscore
      for (elem <- list) {
        val Rscore: Int = elem.getIntValue("Rscore")
        var If_Rscore_avg = 0
        if (Rscore > Rscore_avg) {
          If_Rscore_avg = 1
        }
        elem.put("If_Rscore_avg", If_Rscore_avg)
        val Fscore: Int = elem.getIntValue("Fscore")
        var If_Fscore_avg = 0
        if (Fscore > Fscore_avg) {
          If_Fscore_avg = 1
        }
        elem.put("If_Fscore_avg", If_Fscore_avg)
        val Mscore: Int = elem.getIntValue("Mscore")
        var If_Mscore_avg = 0
        if (Mscore > Mscore_avg) {
          If_Mscore_avg = 1
        }
        elem.put("If_Mscore_avg", If_Mscore_avg)
        tmpList.append(elem)
      }
      tmpList.toIterator
    }).map(obj => {
      val If_Rscore_avg: Int = obj.getIntValue("If_Rscore_avg")
      val If_Fscore_avg: Int = obj.getIntValue("If_Fscore_avg")
      val If_Mscore_avg: Int = obj.getIntValue("If_Mscore_avg")
      val Last_date_days: Int = obj.getIntValue("Last_date_days")
      val first_date_days: Int = obj.getIntValue("first_date_days")
      val Diff_days_avg: Int = obj.getIntValue("Diff_days_avg")
      val order_count: Int = obj.getIntValue("order_count")
      var Label_easy = ""
      if (If_Fscore_avg == 1 && If_Mscore_avg == 1) {
        Label_easy = "重要价值客户"
        if (order_count < 34 && Diff_days_avg >= 7) {
          Label_easy = "低频客户"
        } else if (order_count <= 10) {
          Label_easy = "低频客户"
        }
      } else {
        Label_easy = "一般客户"
        if (order_count < 34 && Diff_days_avg >= 7) {
          Label_easy = "低频客户"
        } else if (order_count <= 10) {
          Label_easy = "低频客户"
        }
      }
      var Label = ""
      if (If_Rscore_avg == 1 && If_Fscore_avg == 1 && If_Mscore_avg == 1) {
        Label = "重要价值客户"
      } else if (If_Rscore_avg == 1 && If_Fscore_avg == 1 && If_Mscore_avg == 0) {
        Label = "潜力客户"
      } else if (If_Rscore_avg == 1 && If_Fscore_avg == 0 && If_Mscore_avg == 1) {
        Label = "重要深耕客户"
      } else if (If_Rscore_avg == 1 && If_Fscore_avg == 0 && If_Mscore_avg == 0) {
        Label = "新客户"
      } else if (If_Rscore_avg == 0 && If_Fscore_avg == 1 && If_Mscore_avg == 1) {
        Label = "重要唤回客户"
      } else if (If_Rscore_avg == 0 && If_Fscore_avg == 1 && If_Mscore_avg == 0) {
        Label = "一般客户"
      } else if (If_Rscore_avg == 0 && If_Fscore_avg == 0 && If_Mscore_avg == 1) {
        Label = "重要挽回客户"
      } else if (If_Rscore_avg == 0 && If_Fscore_avg == 0 && If_Mscore_avg == 0) {
        Label = "流失客户"
      }
      val Diff_days: String = obj.getString("Diff_days")
      val diff_days_last_str: String = Diff_days.split("\\|").last
      var diff_days_last = 0
      if (diff_days_last_str != "只充值过一次,不存在加油间隔") {
        diff_days_last = diff_days_last_str.toInt
      }

      var Label_optimize = ""
      if (If_Rscore_avg == 1 && If_Fscore_avg == 1 && If_Mscore_avg == 1) {
        Label_optimize = "重要价值客户"
        if (Last_date_days <= 10 && Last_date_days >= 6) {
          Label_optimize = "重要唤回客户"
        } else if (Last_date_days > 10) {
          Label_optimize = "流失客户"
        }
      } else if (If_Rscore_avg == 1 && If_Fscore_avg == 1 && If_Mscore_avg == 0) {
        Label_optimize = "潜力客户"
        if (Last_date_days > 10) {
          Label_optimize = "流失客户"
        }
      } else if (If_Rscore_avg == 1 && If_Fscore_avg == 0 && If_Mscore_avg == 1) {
        Label_optimize = "重要深耕客户"
      } else if (If_Rscore_avg == 1 && If_Fscore_avg == 0 && If_Mscore_avg == 0) {
        Label_optimize = "新客户"
        if (first_date_days <= 14) {
          Label_optimize = "新客户"
        } else if (diff_days_last >= 20 && Last_date_days <= 10) {
          Label_optimize = "普通召回客户"
        } else if (first_date_days > 14 && Diff_days_avg < 6) {
          Label_optimize = "潜力客户"
        }
      } else if (If_Rscore_avg == 0 && If_Fscore_avg == 1 && If_Mscore_avg == 1) {
        Label_optimize = "重要唤回客户"
        if (Last_date_days > 10) {
          Label_optimize = "流失客户"
        }
      } else if (If_Rscore_avg == 0 && If_Fscore_avg == 1 && If_Mscore_avg == 0) {
        Label_optimize = "一般客户"
        if (Last_date_days > 10) {
          Label_optimize = "流失客户"
        }
      } else if (If_Rscore_avg == 0 && If_Fscore_avg == 0 && If_Mscore_avg == 1) {
        Label_optimize = "重要挽回客户"
        if (Last_date_days > 10) {
          Label_optimize = "流失客户"
        }
      } else if (If_Rscore_avg == 0 && If_Fscore_avg == 0 && If_Mscore_avg == 0) {
        Label_optimize = "流失客户"
        if (diff_days_last >= 20 && Last_date_days <= 10) {
          Label_optimize = "普通召回客户"
        }
      }
      obj.put("Label_easy", Label_easy)
      obj.put("Label", Label)
      obj.put("Label_optimize", Label_optimize)
      obj
    })//1.2版本结果表新增字段
      .map(obj=>{
        val station_pay_money: Double = obj.getDoubleValue("station_pay_money")
        val first_date_days: Double = obj.getDoubleValue("first_date_days")
        val Last_date_days: Double = obj.getDoubleValue("Last_date_days")
        val order_count: Double = obj.getDoubleValue("order_count")
        val Rj_amount: Double = station_pay_money / (first_date_days - Last_date_days + 1)
        val Rj_jycs: Double = order_count / (first_date_days - Last_date_days + 1)
        obj.put("Rj_amount",Rj_amount)
        obj.put("Rj_jycs",Rj_jycs)
        (1,obj)
      }).groupByKey()
      .flatMap(obj => {
        val tmpList: ListBuffer[JSONObject] = ListBuffer()
        val list: List[JSONObject] = obj._2.toList.sortBy(_.getDoubleValue("Rj_amount")).reverse
        for (i <- list.indices) {
          val c1: Int = (sum_team_id * 0.061).round.toInt
          val c2: Int = (sum_team_id * 0.0691).round.toInt
          val c3: Int = (sum_team_id * 0.1341).round.toInt
          val c4: Int = (sum_team_id * 0.3333).round.toInt
          val c5: Int = sum_team_id - (c1 + c2 + c3 + c4)
          var M_rj_score = 0
          val j=i+1
          if (j <= c1) {
            M_rj_score = 5
          } else if (j > c1 && j <= c1+c2) {
            M_rj_score = 4
          } else if (j > c1+c2 && j <= c1+c2+c3) {
            M_rj_score = 3
          } else if (j > c1+c2+c3 && j <= c1+c2+c3+c4) {
            M_rj_score = 2
          } else if (j > c1+c2+c3+c4 && j <= c1+c2+c3+c4+c5) {
            M_rj_score = 1
          }
          val a1: Int = list(c1-1).getDoubleValue("Rj_amount").floor.toInt
          val a2: Int = list(c1+c2-1).getDoubleValue("Rj_amount").floor.toInt
          val a3: Int = list(c1+c2+c3-1).getDoubleValue("Rj_amount").floor.toInt
          val a4: Int = list(c1+c2+c3+c4-1).getDoubleValue("Rj_amount").floor.toInt
          //val a5: Int = list(c1+c2+c3+c4+c5).getIntValue("order_count")
          val Rj_amount: Double = list(i).getDoubleValue("Rj_amount")
          var M_rj_score_threshold = ""
          if (Rj_amount >= a1) {
            M_rj_score_threshold = s"[$a1,+∞)"
          } else if (Rj_amount >= a2 && Rj_amount < a1) {
            M_rj_score_threshold = s"[$a2,$a1)"
          } else if (Rj_amount >= a3 && Rj_amount < a2) {
            M_rj_score_threshold = s"[$a3,$a2)"
          } else if (Rj_amount >= a4 && Rj_amount < a3) {
            M_rj_score_threshold = s"[$a4,$a3)"
          } else if (Rj_amount >= 0 && Rj_amount < a4) {
            M_rj_score_threshold = s"[0,$a4)"
          }
          list(i).put("M_rj_score", M_rj_score)
          list(i).put("M_rj_score_threshold", M_rj_score_threshold)
          tmpList.append(list(i))
        }
        tmpList.toIterator
      }).map(obj => {
      (1, obj)
    }).groupByKey()
      .flatMap(obj => {
        val tmpList: ListBuffer[JSONObject] = ListBuffer()
        val list: List[JSONObject] = obj._2.toList.sortBy(_.getDoubleValue("Rj_jycs")).reverse
        for (i <- list.indices) {
          val c1: Int = (sum_team_id * 0.0447).round.toInt
          val c2: Int = (sum_team_id * 0.0569).round.toInt
          val c3: Int = (sum_team_id * 0.1301).round.toInt
          val c4: Int = (sum_team_id * 0.3008).round.toInt
          val c5: Int = sum_team_id - (c1 + c2 + c3 + c4)
          var Rj_jycs_score = 0
          val j=i+1
          if (j <= c1) {
            Rj_jycs_score = 5
          } else if (j > c1 && j <= c1+c2) {
            Rj_jycs_score = 4
          } else if (j > c1+c2 && j <= c1+c2+c3) {
            Rj_jycs_score = 3
          } else if (j > c1+c2+c3 && j <= c1+c2+c3+c4) {
            Rj_jycs_score = 2
          } else if (j > c1+c2+c3+c4 && j <= c1+c2+c3+c4+c5) {
            Rj_jycs_score = 1
          }
          val nf: NumberFormat = NumberFormat.getNumberInstance()
          nf.setMaximumFractionDigits(2)
          nf.setRoundingMode(RoundingMode.FLOOR)
          val a1_tmp: Double = list(c1-1).getDoubleValue("Rj_jycs")
          val a1: Double = nf.format(a1_tmp).toDouble
          val a2_tmp: Double = list(c1+c2-1).getDoubleValue("Rj_jycs")
          val a2: Double = nf.format(a2_tmp).toDouble
          val a3_tmp: Double = list(c1+c2+c3-1).getDoubleValue("Rj_jycs")
          val a3: Double = nf.format(a3_tmp).toDouble
          val a4_tmp: Double = list(c1+c2+c3+c4-1).getDoubleValue("Rj_jycs")
          val a4: Double = nf.format(a4_tmp).toDouble
          val Rj_jycs: Int = list(i).getIntValue("Rj_jycs")
          var Rj_jycs_score_threshold = ""
          if (Rj_jycs >= a1) {
            Rj_jycs_score_threshold = s"[$a1,+∞)"
          } else if (Rj_jycs >= a2 && Rj_jycs < a1) {
            Rj_jycs_score_threshold = s"[$a2,$a1)"
          } else if (Rj_jycs >= a3 && Rj_jycs < a2) {
            Rj_jycs_score_threshold = s"[$a3,$a2)"
          } else if (Rj_jycs >= a4 && Rj_jycs < a3) {
            Rj_jycs_score_threshold = s"[$a4,$a3)"
          } else if (Rj_jycs >= 0 && Rj_jycs < a4) {
            Rj_jycs_score_threshold = s"[0,$a4)"
          }
          list(i).put("Rj_jycs_score", Rj_jycs_score)
          list(i).put("Rj_jycs_score_threshold", Rj_jycs_score_threshold)
          tmpList.append(list(i))
        }
        tmpList.toIterator
      }).map(obj=>{
      val Diff_days_avg: Double = JSONUtil.getJsonDouble(obj, "Diff_days_avg", Int.MaxValue)
      var Diff_days_avg_score=0
      if (Diff_days_avg>=0 && Diff_days_avg<=1) {
        Diff_days_avg_score = 5
      }else if(Diff_days_avg >= 2 && Diff_days_avg < 4){
        Diff_days_avg_score = 4
      }else if(Diff_days_avg >= 4 && Diff_days_avg < 6){
        Diff_days_avg_score = 3
      }else if(Diff_days_avg >= 6 && Diff_days_avg < 10){
        Diff_days_avg_score = 2
      }else if(Diff_days_avg >= 10){
        Diff_days_avg_score = 1
      }
      var Diff_days_avg_score_threshold = ""
      if(Diff_days_avg >= 0 && Diff_days_avg <= 1) {
        Diff_days_avg_score_threshold = "[0,1]"
      }else if(Diff_days_avg >= 2 && Diff_days_avg <= 4){
        Diff_days_avg_score_threshold = "[2,4)"
      }else if(Diff_days_avg >= 4 && Diff_days_avg <= 6){
        Diff_days_avg_score_threshold = "[4,6)"
      }else if(Diff_days_avg >= 6 && Diff_days_avg <= 10){
        Diff_days_avg_score_threshold = "[6,10)"
      }else if(Diff_days_avg >= 10){
        Diff_days_avg_score_threshold = "[10,+∞)"
      }
      obj.put("Diff_days_avg_score",Diff_days_avg_score)
      obj.put("Diff_days_avg_score_threshold",Diff_days_avg_score_threshold)
      (1,obj)
    }).groupByKey().flatMap(obj => {
      val tmpList: ListBuffer[JSONObject] = ListBuffer()
      val list: List[JSONObject] = obj._2.toList
      val sum_m_rj_score: Int = list.map(_.getIntValue("M_rj_score")).sum
      val size_m_rj_score: Int = list.size
      val M_rj_score_avg: Double = sum_m_rj_score / size_m_rj_score
      val sum_rj_jycs_score: Int = list.map(_.getIntValue("Rj_jycs_score")).sum
      val size_rj_jycs_score: Int = list.size
      val Rj_jycs_score_avg: Double = sum_rj_jycs_score / size_rj_jycs_score
      val sum_diff_days_avg_score: Int = list.map(_.getIntValue("Diff_days_avg_score")).sum
      val size_diff_days_avg_score: Int = list.size
      val Diff_days_avg_score_avg: Double = sum_diff_days_avg_score / size_diff_days_avg_score
      for (elem <- list) {
        val M_rj_score: Int = elem.getIntValue("M_rj_score")
        var If_Rj_amount_score_avg = 0
        if (M_rj_score > M_rj_score_avg) {
          If_Rj_amount_score_avg = 1
        }
        elem.put("If_Rj_amount_score_avg", If_Rj_amount_score_avg)
        val Rj_jycs_score: Int = elem.getIntValue("Rj_jycs_score")
        var If_Rj_jycs_score_avg = 0
        if (Rj_jycs_score > Rj_jycs_score_avg) {
          If_Rj_jycs_score_avg = 1
        }
        elem.put("If_Rj_jycs_score_avg", If_Rj_jycs_score_avg)
        val Diff_days_avg_score: Int = elem.getIntValue("Diff_days_avg_score")
        var If_diff_days_score_avg = 0
        if (Diff_days_avg_score > Diff_days_avg_score_avg) {
          If_diff_days_score_avg = 1
        }
        elem.put("If_diff_days_score_avg", If_diff_days_score_avg)
        tmpList.append(elem)
      }
      tmpList.toIterator
    }).map(obj=>{
      val If_Rj_amount_score_avg: Int = obj.getIntValue("If_Rj_amount_score_avg")
      val If_Rj_jycs_score_avg: Int = obj.getIntValue("If_Rj_jycs_score_avg")
      val If_diff_days_score_avg: Int = obj.getIntValue("If_diff_days_score_avg")
      var Label_easy_rj = ""
      if (If_Rj_amount_score_avg == 1 && If_Rj_jycs_score_avg == 1 && If_diff_days_score_avg == 1){
        Label_easy_rj = "重要价值客户"
      }else if(If_Rj_jycs_score_avg == 0 && If_diff_days_score_avg == 0){
        Label_easy_rj = "低频客户"
      }else{
        Label_easy_rj = "一般客户"
        if(If_diff_days_score_avg == 0){
          Label_easy_rj = "低频客户"
        }
      }
      obj.put("Label_easy_rj",Label_easy_rj)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加所有标签后的数据量："+addTeamTagRdd.count())
    //addTeamTagRdd.filter(_.getString("car_team_name")=="东莞市程语物业管理有限公司").take(10).foreach(println(_))
    orderDf.createOrReplaceTempView("orderTmp")
    val detail4Sql=
      """
        |select
        |car_team_id,station_id,station_name,province_name,city_name,coords,
        |count(1) as order_num
        |from orderTmp
        |group by car_team_id,station_id,station_name,province_name,city_name,coords
        |""".stripMargin
    val detail4Df: DataFrame = spark.sql(detail4Sql)
    val detail4Rdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, detail4Df).map(obj => {
      (obj.getString("car_team_id"), obj)
    }).groupByKey().map(obj => {
      val tmpObj = new JSONObject()
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getIntValue("order_num")).reverse
      val Oiled_ddyz_name_num: String = list.map(json => {
        val station_name: String = json.getString("station_name")
        val order_num: String = json.getString("order_num")
        val ddyz_id: String = station_name + "(" + order_num + ")"
        ddyz_id
      }).mkString("|")
      val Oiled_ddyz_id: String = list.map(_.getString("station_id")).mkString("|")
      val Oiled_ddyz_province: String = list.map(_.getString("province_name")).mkString("|")
      val Oiled_ddyz_city: String = list.map(_.getString("city_name")).mkString("|")
      val Oiled_ddyz_coords: String = list.map(_.getString("coords")).mkString("|")
      tmpObj.put("car_team_id", obj._1)
      tmpObj.put("Oiled_ddyz_name_num", Oiled_ddyz_name_num)
      tmpObj.put("Oiled_ddyz_id", Oiled_ddyz_id)
      tmpObj.put("Oiled_ddyz_province", Oiled_ddyz_province)
      tmpObj.put("Oiled_ddyz_city", Oiled_ddyz_city)
      tmpObj.put("Oiled_ddyz_coords", Oiled_ddyz_coords)
      (tmpObj.getString("car_team_id"), tmpObj)
    })

    val teamTag1Rdd: RDD[JSONObject] = addTeamTagRdd.map(obj => {
      (obj.getString("car_team_id"), obj)
    }).leftOuterJoin(detail4Rdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        rightObj.remove("car_team_id")
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    teamTag1Rdd.map(obj => {
      (obj.getString("car_team_id"), obj)
    }).groupByKey()
    logger.error("车队标签添加1数据量："+teamTag1Rdd.count())
   /* val carteamBusinessDistributionSql=
      """
        |Select 
        |car_team_id,car_team_name,city_distribution_frequency,source
        |from dm_gis.ddjy_carteam_business_distribution
        |Where inc_day in(
        |select max(inc_day) from dm_gis.ddjy_carteam_business_distribution)
        |""".stripMargin
    val carteamBusinessDistributionDf: DataFrame = spark.sql(carteamBusinessDistributionSql)
    val sfCarteamBDRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, carteamBusinessDistributionDf).map(obj => {
      (obj.getString("car_team_name"), obj)
    })
    //标签Total_dist
    val sfTotalDistRdd: RDD[JSONObject] = teamTag1Rdd.filter(_.getString("source")=="sf").map(obj => {
      (obj.getString("car_team_name"), obj)
    }).leftOuterJoin(sfCarteamBDRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if(rightObj!=null){
        val city_distribution_frequency: String = rightObj.getString("city_distribution_frequency")
        val city_distribution_frequency_array: Array[String] = city_distribution_frequency.split("\\|")
        val Oiled_ddyz_city: String = leftObj.getString("Oiled_ddyz_city")
        val Oiled_ddyz_city_array: Array[String] = Oiled_ddyz_city.split("\\|").distinct
        var Total_dist=0.0
        var Total_dist_online_city=0.0
        for (elem <- city_distribution_frequency_array) {
          val dist: Double = elem.split(",")(2).toDouble
          Total_dist+=dist
          for (elem1 <- Oiled_ddyz_city_array) {
            if(elem.contains(elem1)){
              Total_dist_online_city+=dist
            }
          }
        }
        leftObj.put("Total_dist", Total_dist)
        leftObj.put("Total_dist_online_city", Total_dist_online_city)
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("顺丰数据量："+sfTotalDistRdd.count())
    val yyCarteamBDRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, carteamBusinessDistributionDf).map(obj => {
      (obj.getString("car_team_id"), obj)
    })
    val yyTotalDistRdd: RDD[JSONObject] = teamTag1Rdd.filter(_.getString("source")=="yy").map(obj => {
      (obj.getString("car_team_id"), obj)
    }).leftOuterJoin(yyCarteamBDRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if(rightObj!=null){
        val city_distribution_frequency: String = rightObj.getString("city_distribution_frequency")
        val city_distribution_frequency_array: Array[String] = city_distribution_frequency.split("\\|")
        val Oiled_ddyz_city: String = leftObj.getString("Oiled_ddyz_city")
        val Oiled_ddyz_city_array: Array[String] = Oiled_ddyz_city.split("\\|").distinct
        var Total_dist=0.0
        var Total_dist_online_city=0.0
        for (elem <- city_distribution_frequency_array) {
          val dist: Double = elem.split(",")(2).toDouble
          Total_dist+=dist
          for (elem1 <- Oiled_ddyz_city_array) {
            if(elem.contains(elem1)){
              Total_dist_online_city+=dist
            }
          }
        }
        leftObj.put("Total_dist", Total_dist)
        leftObj.put("Total_dist_online_city", Total_dist_online_city)
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("粤运数据量："+yyTotalDistRdd.count())
    val carteamGuijiSql=
      """
        |Select owner_id,car_team_name,num_carno,source
        |From dm_gis.ddjy_carteam_guiji
        |Where inc_day in(
        |select max(inc_day) from dm_gis.ddjy_carteam_guiji)
        |""".stripMargin
    val carteamGuijiDf: DataFrame = spark.sql(carteamGuijiSql)
    val sfCarteamGuijiRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, carteamGuijiDf)
      .filter(_.getString("source")=="sf")
      .map(obj => {
      (obj.getString("car_team_name"), obj)
    })
    val sfNumCarnoRdd: RDD[JSONObject] = sfTotalDistRdd.map(obj => {
      (obj.getString("car_team_name"), obj)
    }).leftOuterJoin(sfCarteamGuijiRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val num_carno: String = rightObj.getString("num_carno")
        leftObj.put("num_carno", num_carno)
      }
      leftObj
    })
    val yyCarteamGuijiRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, carteamGuijiDf)
      .filter(_.getString("source")=="yy")
      .map(obj => {
      (obj.getString("owner_id"), obj)
    })
    val yyNumCarnoRdd: RDD[JSONObject] = yyTotalDistRdd.map(obj => {
      (obj.getString("car_team_id"), obj)
    }).leftOuterJoin(yyCarteamGuijiRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val num_carno: String = rightObj.getString("num_carno")
        leftObj.put("num_carno", num_carno)
      }
      leftObj
    })
    val teamTagRdd: RDD[JSONObject] = yyNumCarnoRdd.union(sfNumCarnoRdd).map(obj => {
      val Oilmass: Double = obj.getDoubleValue("Oilmass")
      val Total_dist: Double = obj.getDoubleValue("Total_dist")
      val Total_dist_online_city: Double = obj.getDoubleValue("Total_dist_online_city")
      val Carplate: Double = obj.getDoubleValue("Carplate")
      val num_carno: Double = obj.getDoubleValue("num_carno")
      val Oil_dimension1: Double = Oilmass / (Total_dist * 0.22)
      val Oil_dimension2: Double = Oilmass / (Total_dist_online_city * 0.22)
      val Car_dimension: Double = Carplate / num_carno
      obj.put("Oil_dimension1", Oil_dimension1)
      obj.put("Oil_dimension2", Oil_dimension2)
      obj.put("Car_dimension", Car_dimension)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)*/

    val teamTagDf: DataFrame = teamTag1Rdd.map(obj => {
      TeamTag(
        obj.getString("car_team_id"),
        obj.getString("owner_id"),
        obj.getString("car_team_name"),
        obj.getString("create_date_detail"),
        obj.getString("create_date2_detail"),
        obj.getString("create_date_stamp_detail"),
        obj.getString("ft_sale_money_detail"),
        obj.getString("station_pay_money_detail"),
        obj.getString("ft_sale_money"),
        obj.getString("station_pay_money"),
        obj.getString("order_count"),
        obj.getString("Last_date"),
        obj.getString("First_date"),
        obj.getString("Inc_day_second"),
        obj.getString("Last_date_days"),
        obj.getString("first_date_days"),
        obj.getString("create_date2"),
        obj.getString("Diff_days"),
        obj.getString("Diff_days_min"),
        obj.getString("Diff_days_max"),
        obj.getString("Diff_days_avg"),
        obj.getString("Rscore"),
        obj.getString("Rscore_threshold"),
        obj.getString("Fscore"),
        obj.getString("Fscore_threshold"),
        obj.getString("Mscore"),
        obj.getString("Mscore_threshold"),
        obj.getString("If_Rscore_avg"),
        obj.getString("If_Fscore_avg"),
        obj.getString("If_Mscore_avg"),
        obj.getString("Label_easy"),
        obj.getString("Label"),
        obj.getString("Label_optimize"),
        obj.getString("Oiled_ddyz_name_num"),
        obj.getString("Oiled_ddyz_id"),
        obj.getString("Oiled_ddyz_province"),
        obj.getString("Oiled_ddyz_city"),
        obj.getString("Oiled_ddyz_coords"),
        obj.getString("Oilmass"),
        obj.getString("Carplate"),//Carplate预留字段 默认为空
        obj.getString("Total_dist"),
        obj.getString("Total_dist_online_city"),
        obj.getString("num_carno"),
        obj.getString("Oil_dimension1"),
        obj.getString("Oil_dimension2"),
        obj.getString("Car_dimension"),
        obj.getString("Rj_amount"),
        obj.getString("Rj_jycs"),
        obj.getString("M_rj_score"),
        obj.getString("M_rj_score_threshold"),
        obj.getString("Rj_jycs_score"),
        obj.getString("Rj_jycs_score_threshold"),
        obj.getString("Diff_days_avg_score"),
        obj.getString("Diff_days_avg_score_threshold"),
        obj.getString("If_Rj_amount_score_avg"),
        obj.getString("If_Rj_jycs_score_avg"),
        obj.getString("If_diff_days_score_avg"),
        obj.getString("Label_easy_rj")
      )
    }).distinct().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("车队标签数据量："+teamTagDf.count())
    teamTagDf.repartition(1).createOrReplaceTempView("teamTagTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_carteam_label partition(inc_day='$incDay') select * from teamTagTmp")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val last_one_day = DateUtil.getDateStr(incDay, -1, "")
    //获取订单数据
    val orderDf: DataFrame = readOrderData(spark, incDay)
    //计算车队标签
    calculateTeamTag(spark,orderDf,incDay)

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>TeamPortrait Execute Ok")
  }
  case class TeamTag(
                      car_team_id:String,
                      owner_id:String,
                      car_team_name:String,
                      create_date_detail:String,
                      create_date2_detail:String,
                      create_date_stamp_detail:String,
                      ft_sale_money_detail:String,
                      station_pay_money_detail:String,
                      ft_sale_money:String,
                      station_pay_money:String,
                      order_count:String,
                      Last_date:String,
                      First_date:String,
                      Inc_day_second:String,
                      Last_date_days:String,
                      first_date_days:String,
                      create_date2:String,
                      Diff_days:String,
                      Diff_days_min:String,
                      Diff_days_max:String,
                      Diff_days_avg:String,
                      Rscore:String,
                      Rscore_threshold:String,
                      Fscore:String,
                      Fscore_threshold:String,
                      Mscore:String,
                      Mscore_threshold:String,
                      If_Rscore_avg:String,
                      If_Fscore_avg:String,
                      If_Mscore_avg:String,
                      Label_easy:String,
                      Label:String,
                      Label_optimize:String,
                      Oiled_ddyz_name_num:String,
                      Oiled_ddyz_id:String,
                      Oiled_ddyz_province:String,
                      Oiled_ddyz_city:String,
                      Oiled_ddyz_coords:String,
                      Oilmass:String,
                      Carplate:String,
                      Total_dist:String,
                      Total_dist_online_city:String,
                      num_carno:String,
                      Oil_dimension1:String,
                      Oil_dimension2:String,
                      Car_dimension:String,
                      Rj_amount:String,
                      Rj_jycs:String,
                      M_rj_score:String,
                      M_rj_score_threshold:String,
                      Rj_jycs_score:String,
                      Rj_jycs_score_threshold:String,
                      Diff_days_avg_score:String,
                      Diff_days_avg_score_threshold:String,
                      If_Rj_amount_score_avg:String,
                      If_Rj_jycs_score_avg:String,
                      If_diff_days_score_avg:String,
                      Label_easy_rj:String
                              )
}
