package app

import common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DateUtil, SparkBuilder, SparkUtil, SparkUtils}

import scala.collection.mutable.{ArrayBuffer,HashMap}

/**
 * @author 01420395 caiguofang
 *
 * @DESCRIPTION
 * 任务id:
 * 任务名称:
 *
 *
 * 需求id: 2245976
 * 需求负责人: 陈治仁(ft220534)
 * 需求描述:GIS-RSS-DDJY：【吨吨加油】车队消费情况表_数据侧_V1.0_01405644_李相志
 * @create 2024/2/21 11:03 by caiguofang 01420395
 *
 */

import com.sf.gis.scala.base.spark.{Spark}

object FleetConsumptionSituation extends DataSourceCommon  {

  val className: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    //    val sparkSession = SparkBuilder.initSpark
    //    val sparkSession = SparkUtils.getSparkSession(className,"yarn")
    val confMap  = Map[String, String]("spark.sql.crossJoin.enabled" -> "true")
    val sparkSession: SparkSession = Spark.getSparkSession(className, confMap, false, 2)
    //val sparkSession: SparkSession = SparkBuilder.initSpark(className)
    //    val sparkSession: SparkSession = Spark.getSparkSession(className, confMap, false, 2)
    val inc_day = args(0)

    start(sparkSession, inc_day)

  }

  def  start(sparkSession: SparkSession, inc_day:String)={
    //获取 原始表数据

    val   (ddjy_dim_team_info_filter_df,ddjy_ods_sales_team_df, ddjy_dwd_station_order_repartition_di_df,ddjy_ods_dim_wallet_df,
    dm_ddjy_wecom_customer_base_details_di_df, dm_ddjy_wecom_customer_details_di_df,ddjy_ods_team_recharge_order_df
    ,ddjy_dwd_car_team_history_recharge_df, dm_ddjy_fleet_wechat_mapping_df)   =  builderSourceData(sparkSession, inc_day)

    import sparkSession.implicits._
    import org.apache.spark.sql.functions._

    ddjy_dwd_station_order_repartition_di_df.persist(StorageLevel.MEMORY_AND_DISK)

    val fleet_refund_df  =  ddjy_dwd_station_order_repartition_di_df.filter('fleet_refund_status === 0)
      .groupBy('car_team_id).agg(sum("fleet_refund").as("fleet_refund")).persist(StorageLevel.MEMORY_AND_DISK).withColumn("id",'car_team_id)



    // 获取微信群数据
    val dm_ddjy_wecom_customer_base_details_di_df1 = dm_ddjy_wecom_customer_base_details_di_df  // chat_id,group_name
      .withColumn("group_name_new", explode(split(regexp_replace('group_name,"【顺象】&|【吨吨】&|【顺象】|【顺象】＆|市|加油业务沟通群|加油沟通群",""),"/&+、")))
      .withColumn("chat_id_1", 'chat_id)
      .withColumn("name_new_1", 'group_name)
      .drop("chat_id","group_name").persist(StorageLevel.MEMORY_AND_DISK)

    val dm_ddjy_wecom_customer_base_details_di_df2 = dm_ddjy_wecom_customer_base_details_di_df // chat_id,group_name
      .withColumn("group_name_new_2", explode(split(regexp_replace('group_name,"【顺象】&|【吨吨】&|【顺象】|【顺象】＆|市|加油业务沟通群|加油沟通群",""),"/&+、")))
      .withColumn("chat_id_2", 'chat_id)
      .withColumn("name_new_2", 'group_name)
      .drop("chat_id","group_name").persist(StorageLevel.MEMORY_AND_DISK)

    val dm_ddjy_fleet_wechat_mapping_df1 =dm_ddjy_fleet_wechat_mapping_df.drop("team_name")

    val  ddjy_dim_team_info_filter_df_1 =  ddjy_dim_team_info_filter_df
      .join(dm_ddjy_fleet_wechat_mapping_df1, Seq("id") , "left")
      .filter('team_id.isNull)
      .select("team_id","team_name","chat_id","group_name").distinct().persist(StorageLevel.MEMORY_AND_DISK)



    //需要更新微信数据
    val wecomDf21 =  ddjy_dim_team_info_filter_df_1
      .withColumn("name_new_1", regexp_replace('team_name,"市|有限公司|股份有限公司|有限责任公司|科技有限公司",""))

    val wecomDf1 =  wecomDf21
      .withColumn("name_new_2",regexp_replace('name_new_1,"供应链管理|供应链|国际货运|国际物流|物流运输|物流科技|物流|货运代理|货运代理服务","")).persist(StorageLevel.MEMORY_AND_DISK)

    val wecomDf2 =wecomDf1
      .join(dm_ddjy_wecom_customer_base_details_di_df1,Seq("name_new_1") ,"left")
      .join(dm_ddjy_wecom_customer_base_details_di_df2,Seq("name_new_2")  ,"left")
      .persist(StorageLevel.MEMORY_AND_DISK)

    val wecomDf = wecomDf2
      .withColumn("group_name",when('chat_id_1.isNotNull,'name_new_1).otherwise('name_new_2))
      .withColumn("chat_id",when('chat_id_1.isNotNull,'chat_id_1).otherwise('chat_id_2))
      .select("team_id","team_name","chat_id","group_name").distinct().persist(StorageLevel.MEMORY_AND_DISK)

    wecomDf.filter('chat_id === "wrDN-XZwAAwtW76uJuz9h4QioRE4wBJg").show(10,false)

    //保存新加的数据
    val xxResultDf =  wecomDf.filter( 'chat_id.isNotNull).union(dm_ddjy_fleet_wechat_mapping_df.drop("id")).persist(StorageLevel.MEMORY_AND_DISK)


    val  xxResultDf1 = xxResultDf.drop("team_name").persist(StorageLevel.MEMORY_AND_DISK).withColumn("id",'team_id)

    //    writeToHiveNoP(sparkSession,xxResultDf,"dm_gis.dm_ddjy_fleet_wechat_mapping")
    xxResultDf1.filter('chat_id === "wrDN-XZwAAwtW76uJuz9h4QioRE4wBJg").show(10,false)


    // 获取微信客户数据
    val remark_corp_name_df = dm_ddjy_wecom_customer_details_di_df
      .withColumn("pin", concat('external_userid, lit("("), 'name, lit(")")))
      .withColumn("id_name", concat_ws(";",collect_list('pin)over(Window.partitionBy('remark_corp_name))))
      .withColumn("team_name", explode(split('remark_corp_name,"/"))).repartition(1000)


    val ddjy_dwd_station_order_repartition_di_df1 = ddjy_dwd_station_order_repartition_di_df.filter('order_status === 2)
    ddjy_dwd_station_order_repartition_di_df1.persist(StorageLevel.MEMORY_AND_DISK)

    val  currentDataDF= builderCurrentDataDF(ddjy_dwd_station_order_repartition_di_df1.coalesce(2000), sparkSession)
      .select('car_team_id
        ,'first_pay_date
        ,'last_pay_date
        ,'total_gmv
        ,'consumed_car
        ,'top3_station
        ,'consumed_recency
        ,'stop_consume_cnt
      ).distinct().persist(StorageLevel.MEMORY_AND_DISK).withColumn("id", 'car_team_id)

    currentDataDF.filter('id === "1734101985388421122").show(10,false)

    //月维度
    val ddjy_dwd_station_order_repartition_di_df2 = ddjy_dwd_station_order_repartition_di_df1
      .filter((regexp_replace(substring('business_time,0,7),"-","") === DateUtil.getMonthsBeforeOrAfter(inc_day,2).substring(0,6)))

    ddjy_dwd_station_order_repartition_di_df2.show(1,false)
    val monthDataDF= builderCurrentDataDF(ddjy_dwd_station_order_repartition_di_df2.coalesce(2000), sparkSession)
      .select('car_team_id
        ,'total_gmv.as("tmonth_gmv")
        ,'consumed_car.as("tmonth_consumed_car")
        ,'top3_station.as("tmonth_top3_station")
        ,'consumed_recency.as("tmonth_consumed_recency")
      ).persist(StorageLevel.MEMORY_AND_DISK).withColumn("id", 'car_team_id)
    logger.error( "数据量  ddjy_dwd_station_order_repartition_di_df2" + ddjy_dwd_station_order_repartition_di_df2.count)

    //上月维度
    val ddjy_dwd_station_order_repartition_di_df3 = ddjy_dwd_station_order_repartition_di_df1.filter(regexp_replace(substring('business_time,0,7),"-","") === DateUtil.getMonthsBeforeOrAfter(inc_day,1).substring(0,6))
    val lashMonthDataDF= builderCurrentDataDF(ddjy_dwd_station_order_repartition_di_df3.coalesce(2000), sparkSession)
      .select('car_team_id
        ,'total_gmv.as("last_month_gmv")
        ,'consumed_car.as("last_month_consumed_car")
        ,'top3_station.as("last_month_top3_station")
        ,'consumed_recency.as("last_month_consumed_recency")
      ).persist(StorageLevel.MEMORY_AND_DISK).withColumn("id", 'car_team_id)
    logger.error( "数据量  ddjy_dwd_station_order_repartition_di_df3" + ddjy_dwd_station_order_repartition_di_df3.count)

    //上上月维度
    val ddjy_dwd_station_order_repartition_di_df4 = ddjy_dwd_station_order_repartition_di_df1.filter((regexp_replace(substring('business_time,0,7),"-","") === DateUtil.getMonthsBeforeOrAfter(inc_day,1).substring(0,6)))
    val beforeMonthDataDF= builderCurrentDataDF(ddjy_dwd_station_order_repartition_di_df4.coalesce(2000), sparkSession)
      .select('car_team_id
        ,'total_gmv.as("before_lastmonth_gmv")
        ,'consumed_car.as("before_lastmonth_consumed_car")
        ,'top3_station.as("before_lastmonth_top3_station")
        ,'consumed_recency.as("before_lastmonth_consumed_recency")
      ).persist(StorageLevel.MEMORY_AND_DISK).withColumn("id", 'car_team_id)

    val resultDf = ddjy_dim_team_info_filter_df.repartition(2000)
      .join(ddjy_ods_sales_team_df, Seq("id"),"left")
      .join(ddjy_dwd_car_team_history_recharge_df, Seq("id"),"left") // first_trade_date
      .join(ddjy_ods_team_recharge_order_df, Seq("id"),"left") // last_trade_date
      .join(ddjy_ods_dim_wallet_df,  Seq("id"),"left") // account_balance
      .join(fleet_refund_df, Seq("id"),"left") // fleet_refund
      .join(currentDataDF, Seq("id"),"left") // first_pay_date  last_pay_date total_gmv  consumed_car consumed_recency  stop_consume_cnt
      .join(monthDataDF, Seq("id"),"left") //  tmonth_gmv tmonth_consumed_car tmonth_top3_station  tmonth_consumed_recency
      .join(lashMonthDataDF, Seq("id"),"left") // last_month_gmv last_month_consumed_car last_month_top3_station last_month_consumed_recency
      .join(beforeMonthDataDF, Seq("id"),"left") // last_month_gmv last_month_consumed_car last_month_top3_station last_month_consumed_recency
      .join(xxResultDf1, Seq("id") ,"left") // last_month_gmv last_month_consumed_car last_month_top3_station last_month_consumed_recency
      .join(remark_corp_name_df, Seq("team_name"),"left") // last_month_gmv last_month_consumed_car last_month_top3_station last_month_consumed_recency
      .repartition(2000)
      .select('id
        ,'team_name
        ,'sales
        ,'sub_name
        ,'sup_name
        ,'team_create_date
        ,'first_trade_date
        ,'last_trade_date
        ,'account_balance
        ,'fleet_refund
        ,'first_pay_date
        ,'last_pay_date
        ,'contact_name
        ,'contact_phone
        ,'chat_id
        ,'group_name
        ,'id_name.as("external_userid_name")
        ,'total_gmv
        ,'top3_station
        ,'consumed_car
        ,'consumed_recency
        ,'stop_consume_cnt
        ,'tmonth_gmv
        ,'tmonth_top3_station
        ,'tmonth_consumed_car
        ,'tmonth_consumed_recency
        ,'last_month_gmv
        ,'last_month_top3_station
        ,'last_month_consumed_car
        ,'last_month_consumed_recency
        ,'before_lastmonth_gmv
        ,'before_lastmonth_top3_station
        ,'before_lastmonth_consumed_car
        ,'before_lastmonth_consumed_recency
      ).withColumn("inc_day",lit(inc_day)).distinct()
    //     logger.error( "数据量  resultDf" + resultDf.count)

    writeToHive(sparkSession,resultDf,Seq("inc_day"),"dm_gis.dm_ddjy_fleet_consumption_situation")

  }


  def  builderCurrentDataDF (sourceDf1: DataFrame ,  sparkSession: SparkSession)={

    import sparkSession.implicits._
    val  sourceDf = sourceDf1.repartition(2000)
    val consumed_car_df  = sourceDf.groupBy('car_team_id)
      .agg(min("business_time").as("first_pay_date")
        , max("business_time").as("last_pay_date")
        , sum("transaction_amount").as("total_gmv")
        , countDistinct(when('new_carplate.isNull, 'driver_phone).otherwise('new_carplate)).as("consumed_car") //  累计消费车辆数
      ).persist(StorageLevel.MEMORY_AND_DISK)


    val top3_station_df = sourceDf
      .groupBy("car_team_id","grpid","station_name").agg(sum("transaction_amount").as("transaction_amount"))
      .withColumn("rn", row_number()over(Window.partitionBy("car_team_id").orderBy(desc("transaction_amount"))))
      .filter('rn <= 3)
      .groupBy("car_team_id").agg(concat_ws(";",collect_list("station_name")).as("top3_station"))
      .persist(StorageLevel.MEMORY_AND_DISK)// top3_station

    val ddjy_dwd_station_order_repartition_di_df4 = sourceDf
      .select("car_team_id", "business_time").distinct().orderBy('business_time.asc)
      .withColumn("rn",count(lit(1))over(Window.partitionBy("car_team_id")))
      .persist(StorageLevel.MEMORY_AND_DISK)// consumed_recency


    var consumed_receny_df2 = ddjy_dwd_station_order_repartition_di_df4
      .filter('rn > 1)
      .groupBy("car_team_id").agg(concat_ws("|", collect_list("business_time")).as("business_time_list"))
      .persist(StorageLevel.MEMORY_AND_DISK)
    val  consumed_receny_json  =  SparkUtils.getDfToJson(sparkSession,consumed_receny_df2,2000)

    consumed_receny_df2.filter('car_team_id==="1734101985388421122").show(1,false)

    val  consumed_receny_df3 = consumed_receny_json.map(row  => {
      val business_time_list_str = row.getString("business_time_list")
      val business_time_list = business_time_list_str.split("\\|").toList.sortBy(b=>b)

      logger.error(business_time_list_str + "===========")

      val  car_team_id = row.getString ("car_team_id")
      var j =0
      var isZero  = true
      val totalDays = new ArrayBuffer[Long]()
      val stop_consume_cnts = new ArrayBuffer[Long]()

      for(i  <- 0.until(business_time_list.length-1)){
        j = i+1
        val business_time_start  =   business_time_list(i)
        val business_time_end  =   business_time_list(j)
        val dateNums = DateUtil.interDayStartToEnd1(business_time_start.replaceAll("-",""),business_time_end.replaceAll("-","")) -2
        logger.error(j + "===" + business_time_start + "===========" + business_time_end + "===" + dateNums)
        //是否都是相隔1
        if (dateNums>0){
          isZero = false
        }

        if(dateNums>=14 ){
          stop_consume_cnts.append(dateNums)
        }
        if(dateNums<14 &&  dateNums>=0 ){
          totalDays.append(dateNums)
        }
      }

      //相隔天数
      if  (isZero){
        row.put("consumed_recency","0")
      }else{
        if(totalDays.isEmpty){
          row.put("consumed_recency","0")
        }else{
          var totalDates  = 0.0
          for  (datenum <- totalDays){
            totalDates = totalDates + datenum
          }
          // 四舍五入取整, -0.5向上取整
          row.put("consumed_recency",Math.round(totalDates/totalDays.length - 0.5).toString)
        }
      }

      if(stop_consume_cnts.isEmpty){
        row.put("stop_consume_cnt","0")
      }else{
        row.put("stop_consume_cnt",stop_consume_cnts.size.toString)
      }
      (car_team_id, row.getString("consumed_recency"), row.getString("stop_consume_cnt"))

    }).toDF("car_team_id", "consumed_recency", "stop_consume_cnt")

    consumed_receny_df3.show (1,false )
    logger.error(" consumed_receny_df3 数据量 " +  consumed_receny_df3.count() )

    var  consumed_receny_df1  =   ddjy_dwd_station_order_repartition_di_df4.filter('rn <= 1)
      .persist(StorageLevel.MEMORY_AND_DISK)

    consumed_receny_df1.show(10, false)

    var consumed_receny_df = consumed_receny_df3

    if(consumed_receny_df1.count()>0){
      consumed_receny_df1 =consumed_receny_df1
        .withColumn("stop_consume_cnt",lit("0"))
        .withColumn("consumed_recency",lit(""))
        .select("car_team_id","consumed_recency","stop_consume_cnt")
      consumed_receny_df =  consumed_receny_df1.union(consumed_receny_df3).persist(StorageLevel.MEMORY_AND_DISK)
    }



    val resultDf = consumed_car_df
      .join(top3_station_df, Seq("car_team_id"),"left")
      .join(consumed_receny_df, Seq("car_team_id"),"left")
      .select('car_team_id
        ,'first_pay_date
        ,'last_pay_date
        ,'total_gmv
        ,'consumed_car
        ,'top3_station
        ,'consumed_recency
        ,'stop_consume_cnt
      ).distinct().persist(StorageLevel.MEMORY_AND_DISK)


    resultDf.show(10,false)
    resultDf
  }




  def builderSourceData(sparkSession: SparkSession, inc_day :String)={

    val ddjy_dim_team_info_filter_Sql =
      s"""
         |select  id, name as team_name,create_date  as team_create_date , contact_name  as contact_name
         |, contact_phone as contact_phone
         |from  dm_gis.ddjy_dim_team_info_filter  where  inc_day  =${inc_day} and del_flag =0
         |""".stripMargin
    val ddjy_dim_team_info_filter_df = sparkSession.sql(ddjy_dim_team_info_filter_Sql).repartition(2000)


    ddjy_dim_team_info_filter_df.persist(StorageLevel.MEMORY_AND_DISK)
    import sparkSession.implicits._
    val ddjy_ods_sales_team_Sql =
      s"""
         |select  team_id as id,sub_name, user_name as sales, sup_name  as sup_name  from  dm_gis.ddjy_ods_sales_team  where  inc_day  =${inc_day} and deleted =0
         |""".stripMargin
    val ddjy_ods_sales_team_df = sparkSession.sql(ddjy_ods_sales_team_Sql)

    ddjy_ods_sales_team_df.persist(StorageLevel.MEMORY_AND_DISK)

    val ddjy_dwd_station_order_repartition_di_Sql =
      s"""
         |select  *  from  dm_gis.ddjy_dwd_station_order_repartition_di  where del_flag =0  and  inc_day < '${inc_day}'
         |""".stripMargin
    val ddjy_dwd_station_order_repartition_di_df = sparkSession.sql(ddjy_dwd_station_order_repartition_di_Sql)

    ddjy_dwd_station_order_repartition_di_df.filter('car_team_id === "1734101985388421122").show(1,false)

    ddjy_dwd_station_order_repartition_di_df.persist(StorageLevel.MEMORY_AND_DISK)
    val ddjy_ods_dim_wallet_Sql =
      s"""
         |select  total_amount as account_balance, row_number()over(partition by  user_id order by source desc  ) rn  , user_id as id  from  dm_gis.ddjy_ods_dim_wallet  where  inc_day  =${inc_day} and del_flag =0 and user_type = 2 and account_type = 10
         |""".stripMargin
    import  sparkSession.implicits._
    val ddjy_ods_dim_wallet_df = sparkSession.sql(ddjy_ods_dim_wallet_Sql).filter('rn  ===1)

    //企微群id
    val dm_ddjy_wecom_customer_base_details_di_Sql =
      s"""
         |select  distinct chat_id, group_name  from  dm_gis.dm_ddjy_wecom_customer_base_details_di  where  inc_day  =${inc_day} and errcode=0 and group_name!='群聊' and group_name not like"%加油站合作%"
         |""".stripMargin
    val dm_ddjy_wecom_customer_base_details_di_df = sparkSession.sql(dm_ddjy_wecom_customer_base_details_di_Sql)

    val dm_ddjy_wecom_customer_details_di_Sql =
      s"""
         |select  external_userid ,  name ,  remark_corp_name  from  dm_gis.dm_ddjy_wecom_customer_details_di  where  inc_day  =${inc_day} and (remark_corp_name!=''  and remark_corp_name is not null) and remark_corp_name!='销售'
         |""".stripMargin
    val dm_ddjy_wecom_customer_details_di_df = sparkSession.sql(dm_ddjy_wecom_customer_details_di_Sql)
    dm_ddjy_wecom_customer_details_di_df.persist(StorageLevel.MEMORY_AND_DISK)
    val ddjy_ods_team_recharge_order_Sql =
      s"""
         |select  max(recharge_time) as last_trade_date ,target_id as id from  dm_gis.ddjy_ods_team_recharge_order  where inc_day ='${inc_day}' and user_type=2 and  recharge_flag=4 group by  target_id
         |""".stripMargin
    val ddjy_ods_team_recharge_order_df = sparkSession.sql(ddjy_ods_team_recharge_order_Sql)

    ddjy_ods_team_recharge_order_df.persist(StorageLevel.MEMORY_AND_DISK)
    val ddjy_dwd_car_team_history_recharge_Sql =
      s"""
         |select  team_id as id , min(trade_time) as first_trade_date  from  dm_gis.ddjy_dwd_car_team_history_recharge group by team_id
         |""".stripMargin
    val ddjy_dwd_car_team_history_recharge_df = sparkSession.sql(ddjy_dwd_car_team_history_recharge_Sql)

    ddjy_dwd_car_team_history_recharge_df.persist(StorageLevel.MEMORY_AND_DISK)
    val dm_ddjy_fleet_wechat_mapping_Sql =
      s"""
         |select team_id,
team_name,
chat_id,
group_name, team_id as id
         |from  dm_gis.dm_ddjy_fleet_wechat_mapping
         |""".stripMargin
    val dm_ddjy_fleet_wechat_mapping_df = sparkSession.sql(dm_ddjy_fleet_wechat_mapping_Sql)

    dm_ddjy_fleet_wechat_mapping_df.persist(StorageLevel.MEMORY_AND_DISK)
    (ddjy_dim_team_info_filter_df,ddjy_ods_sales_team_df, ddjy_dwd_station_order_repartition_di_df,ddjy_ods_dim_wallet_df,
      dm_ddjy_wecom_customer_base_details_di_df, dm_ddjy_wecom_customer_details_di_df,ddjy_ods_team_recharge_order_df
      ,ddjy_dwd_car_team_history_recharge_df, dm_ddjy_fleet_wechat_mapping_df )

  }
}