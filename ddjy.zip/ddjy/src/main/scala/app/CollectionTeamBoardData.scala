package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:车队看板报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:389
 * 任务名称：车队看板报表
 * 依赖任务：订单支付时间重分区表 387、每日-车队销售管理表 497
 * 数据源：ddjy_dwd_station_order_pay_repartition_di、ddjy_uimp_dm_car_sale_manage_report
 * 调用服务地址：无
 * 数据结果：ddjy_uimp_dm_car_kanban_report
 */
object CollectionTeamBoardData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def dateStream(fromDt:LocalDate):Stream[LocalDate]={
    fromDt #::dateStream(fromDt.plusDays(1))
  }

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String) = {
    val car_kanban_df: DataFrame = spark.sql(
      s"""
         |
         |select
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |t1.car_team_id,
         |min_trade_day,
         |max_trade_day,
         |round(nvl(agg_ft_sale_money,0.00),2) as agg_ft_sale_money,
         |nvl(agg_order_cnt,0) as agg_order_cnt,
         |round(nvl(agg_oil_mass,0.00),2) as agg_oil_mass,
         |round(nvl(month_ft_sale_money,0.00),2) as month_ft_sale_money,
         |round(nvl(month_ft_sale_money,0.00)-nvl(last_month_ft_sale_money,0.00),2) as month_sequential_ft_sale_money,
         |round(nvl(seven_ft_sale_money,0.00),2) as seven_ft_sale_money,
         |round(nvl(seven_ft_sale_money,0.00)-nvl(fourteen_ft_sale_money,0.00),2) as seven_sequential_ft_sale_money,
         |round(nvl(day_ft_sale_money,0.00),2) as day_ft_sale_money,
         |round(nvl(day_ft_sale_money,0.00)-nvl(yersterday_ft_sale_money,0.00),2) as day_sequential_ft_sale_money,
         |nvl(month_order_cnt,0) as month_order_cnt,
         |nvl(month_order_cnt,0)-nvl(last_month_order_cnt,0) as month_sequential_order_cnt,
         |nvl(seven_order_cnt,0) as seven_order_cnt,
         |nvl(seven_order_cnt,0)-nvl(fourteen_order_cnt,0) as seven_sequential_order_cnt,
         |nvl(day_order_cnt,0) as day_order_cnt,
         |nvl(day_order_cnt,0)-nvl(yersterday_order_cnt,0) as day_sequential_order_cnt
         |from
         |(
         |select
         |car_team_id,
         |sum(ft_sale_money) as agg_ft_sale_money,
         |count(order_sn) as agg_order_cnt,
         |sum(oil_mass) as agg_oil_mass
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day<='${inc_day}'
         |and order_status=2
         |group by car_team_id
         |) t1
         |left join
         |(
         |select
         |car_team_id,
         |sum(ft_sale_money) as yersterday_ft_sale_money,
         |count(order_sn) as yersterday_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day='${before_yesterday}'
         |and order_status=2
         |group by car_team_id
         |) t2
         |on t1.car_team_id=t2.car_team_id
         |left join
         |(
         |select
         |car_team_id,
         |sum(ft_sale_money) as day_ft_sale_money,
         |count(order_sn) as day_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day='${inc_day}'
         |and order_status=2
         |group by car_team_id
         |) t3
         |on t1.car_team_id=t3.car_team_id
         |left join
         |(
         |select
         |car_team_id,
         |sum(ft_sale_money) as month_ft_sale_money,
         |count(order_sn) as month_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day>=replace(trunc(from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','') and inc_day<='${inc_day}'
         |and order_status=2
         |group by car_team_id
         |) t4
         |on t1.car_team_id=t4.car_team_id
         |left join
         |(
         |select
         |car_team_id,
         |sum(ft_sale_money) as last_month_ft_sale_money,
         |count(order_sn) as last_month_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day>=replace(concat(SUBSTR(DATE_SUB(FROM_UNIXTIME(unix_timestamp('${inc_day}','yyyyMMdd')),DAY(FROM_UNIXTIME(unix_timestamp('${inc_day}','yyyyMMdd')))),1,7) ,'-01'),'-','')
         |and inc_day<=replace(DATE_SUB(FROM_UNIXTIME(unix_timestamp('${inc_day}','yyyyMMdd')),DAY(FROM_UNIXTIME(unix_timestamp('${inc_day}','yyyyMMdd')))),'-','')
         |and order_status=2
         |group by car_team_id
         |) t5
         |on t1.car_team_id=t5.car_team_id
         |left join
         |(
         |select
         |car_team_id,
         |sum(ft_sale_money) as seven_ft_sale_money,
         |count(order_sn) as seven_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day>='${last_seven_day}' and inc_day<='${inc_day}'
         |and order_status=2
         |group by car_team_id
         |) t6
         |on t1.car_team_id=t6.car_team_id
         |left join
         |(
         |select
         |car_team_id,
         |sum(ft_sale_money) as fourteen_ft_sale_money,
         |count(order_sn) as fourteen_order_cnt
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day>='${last_fourteen_day}' and inc_day<'${last_seven_day}'
         |and order_status=2
         |group by car_team_id
         |) t7
         |on t1.car_team_id=t7.car_team_id
         |left join
         |(
         |select
         |team_id,
         |substr(min_trade_time,0,10) as min_trade_day,
         |substr(max_trade_time,0,10) as max_trade_day
         |from dm_gis.ddjy_uimp_dm_car_sale_manage_report
         |where inc_day='${inc_day}'
         |and min_trade_time!='' and min_trade_time is not null
         |) t8
         |on t1.car_team_id=t8.team_id
         |""".stripMargin)
    car_kanban_df.repartition(1).createOrReplaceTempView("car_kanban_tmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_uimp_dm_car_kanban_report partition(inc_day='${inc_day}') select * from car_kanban_tmp")
    logger.error("写入ddjy_uimp_dm_car_kanban_report每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      stationProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>车队看板报表 Execute Ok")
  }

}
