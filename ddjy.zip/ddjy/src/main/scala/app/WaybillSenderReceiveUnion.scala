package app

import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:运单表收寄件地址表
 * 需求人员：周韵筹
 * @Author: lixiangzhi 01405644
 * @Date:2023-08-10
 * 任务id:845
 * 任务名称：运单表收寄件地址表
 * 依赖任务：96、95、85
 * 数据源：tt_waybill_info
 * 调用服务地址：无
 * 数据结果：dm_comp_clue_waybillinfo_di
 */
object WaybillSenderReceiveUnion {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def waybillSenderReceiveUnion(spark: SparkSession, incDay: String) = {
    val wayibllSql=
      s"""
        |select
        |consignee_comp_name as comp_name,
        |consignee_addr_decrypt as addr,
        |consignee_phone as phone,
        |consignee_mobile as mobile,
        |consignee_cont_name as cont_name,
        |'1' as type,
        |inc_day,
        |dest_dist_code as city_code
        |from dm_gis.dwd_waybill_info_dtl_di
        |where inc_day = '${incDay}' and length(consignee_comp_name)>=3
        |union all
        |select
        |consignor_comp_name as comp_name,
        |consignor_addr_decrypt as addr,
        |consignor_phone as phone,
        |consignor_mobile as mobile,
        |consignor_cont_name as cont_name,
        |'2' as type,
        |inc_day,
        |src_dist_code as city_code
        |from dm_gis.dwd_waybill_info_dtl_di
        |where inc_day = '${incDay}'  and length(consignor_comp_name)>=3
        |""".stripMargin
    val wayibllDf: DataFrame = spark.sql(wayibllSql).distinct().repartition(1)
    val parSeq: Array[String] = "inc_day,city_code".split(",")
    SparkWrite.overwriteToHiveDynamics(spark,wayibllDf,parSeq,"dm_gis.dm_comp_clue_waybillinfo_di")
    val delete_day: String = DateUtil.getDateStr(incDay, -60, "")
    spark.sql(s"alter table dm_gis.dm_comp_clue_waybillinfo_di drop if exists partition(inc_day='${delete_day}')")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    waybillSenderReceiveUnion(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
}
