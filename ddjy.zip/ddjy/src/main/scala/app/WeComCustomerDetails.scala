package app

import java.io.{BufferedWriter, FileWriter, IOException}
import java.net.URLEncoder
import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.util.JSONUtil
import com.sun.net.ssl.{SSLContext, TrustManager}
import org.apache.log4j.Logger
import utils.TrackUrlUtil

import java.net.InetSocketAddress
import java.net.Proxy
import scala.collection.JavaConversions._
/**
 * Description:调客户群详情接口
 * 需求方：ft220534 陈治仁
 * Author: 李相志 01405644
 * Date: 10:53 2023/3/13
 * 任务信息：运维刘任部署
 */
object WeComCustomerDetails {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def customerDetailsInterface(cursor:String,finalUrl:String,proxyHost:String,proxyPort:Int) = {
    val json = new JSONObject()
    val userid_list = new util.ArrayList[String]()
    userid_list.add("LiuBo")
    userid_list.add("CaiYingWei")
    json.put("userid_list",userid_list)
    json.put("cursor",cursor)
    json.put("limit",100)
    //println(json)
    val retStr: String = TrackUrlUtil.sendPostWithProxies(finalUrl,json.toString(),proxyHost,proxyPort)
    //val retStr: String = TrackUrlUtil.sendPost(finalUrl,json.toJSONString,3)
    val ret: JSONObject = JSON.parseObject(retStr)
    //logger.error(ret)
    ret
  }

  def main(args: Array[String]): Unit = {
    //定义代理
    val proxyHost="sfproxy.int.sfcloud.local"
    val proxyPort:Int=80

    /*val testUrl="https://www.baidu.com/"
    val testRet: String = TrackUrlUtil.sendGetWithProxies(testUrl,"utf-8",proxyHost,proxyPort)
    logger.error(testRet)*/
    //获取access_token
    val tokenUrl="https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=ww389059b0120e6648&corpsecret=ChyQ5bDDdFAyg77fPAgwqWHeTC139H5Px79ZCDDT3s0"
    var access_token = ""
    try {
      val retTokenStr: String = TrackUrlUtil.sendGetWithProxies(tokenUrl,"utf-8",proxyHost,proxyPort)
      val retToken: JSONObject = JSON.parseObject(retTokenStr)
      access_token = retToken.getString("access_token")
      println(retToken)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调token接口异常:"+e.getMessage)
    }
    val url="https://qyapi.weixin.qq.com/cgi-bin/externalcontact/batch/get_by_user?access_token=%s"
    val finalUrl: String = url.format(access_token)
    //初始化
    var externalContactList: JSONArray = new JSONArray()
    val customerDetailsList: util.ArrayList[String] = new util.ArrayList[String]()
    var cursor = ""
    val ret: JSONObject = customerDetailsInterface(cursor, finalUrl,proxyHost,proxyPort)
    cursor = ret.getString("next_cursor")
    externalContactList = JSONUtil.getJsonArrayMulti(ret, "external_contact_list")
    customerDetailsList.add(ret.toJSONString)
    //分页查询
    while (externalContactList.size()!=0 && externalContactList.size()%100==0){
      val interRet: JSONObject = customerDetailsInterface(cursor, finalUrl,proxyHost,proxyPort)
      cursor = interRet.getString("next_cursor")
      customerDetailsList.add(interRet.toJSONString)
      externalContactList = JSONUtil.getJsonArrayMulti(interRet, "external_contact_list")
    }
    // 指定输出文件路径及名称
    val filePath = "/app/tools/weComCustomerInterface/CUSTOMER/1.csv_file/WeComCustomerDetails.csv"
    try {
      val writer = new FileWriter(filePath)
      /*for (i <- 0 until(customerDetailsList.size())){
        customerDetailsList(i)
      }*/
      for (elem <- customerDetailsList) {
        writer.write(elem + "\n") // 每行写入一个元素并换行
      }

      writer.close() // 关闭文件写入流
    } catch {
      case e: IOException => println("写入文件时发生错误：" + e.getMessage())
    }

  }
}
