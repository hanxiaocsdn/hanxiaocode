package app

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import utils.SparkWrite

/**
 *需求名称：用户画像-消费比例
 *需求方：左佳怡(01403789)
 *开发: 周勇(01390943)
 *任务创建时间：20230330
 *任务id：618
 **/

object CarTeamPersonal {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args:Array[String] )= {

    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.locality.wait", "0")
      .config("spark.executor.memoryOverhead", "10G")
      .config("spark.sql.crossJoin.enabled", "true")
      .enableHiveSupport()
      .getOrCreate()

    val dayvar0: String = args(0)
    val dayvar1: String = args(1)
    val dayvar2: String = args(2)
    val dayvar3: String = args(3)
    val dayvar4: String = args(4)
    //存临时表1

   val ddjy_car_team_name_dt=spark.sql(
     s"""
       |  Select   car_team_name
       |    from(
       |        select  *  from (
       |            select row_number() over( partition by  order_sn order by  UNIX_TIMESTAMP(update_date, 'yyyy-MM-dd HH:mm:ss') desc ) as rownum,
       |              order_sn,car_team_name
       |            from   dm_gis.ddjy_dwd_station_order_repartition_di
       |            Where inc_day >=  replace(date_sub(from_unixtime(unix_timestamp('${dayvar0}','yyyymmdd'),'yyyy-mm-dd'),27),'-','')
       |              and inc_day <= '${dayvar0}'
       |              and order_sn != '1'
       |              and discard_time is null
       |              and car_team_name is not null
       |              and del_flag = '0'
       |              and order_status in ('1', '2')
       |          ) a
       |        where  a.rownum = 1
       |      ) b
       |      Left join (
       |        select * from  (
       |			select  order_sn,case when carplate is null or trim(carplate)='' or length(carplate)<=3 then null else carplate end carplate,
       |			  row_number() over( partition by order_sn order by  UNIX_TIMESTAMP(update_time, 'yyyy-MM-dd HH:mm:ss') desc) rownum
       |			from  dm_gis.ddjy_station_order_pics_carplate
       |			             where inc_day in
       |  (select max(inc_day) inc_day from dm_gis.ddjy_station_order_pics_carplate where id is not null)
       |          ) e where e.rownum = 1
       |      ) c On b.order_sn = c.order_sn
       |  group by car_team_name
       |""".stripMargin)

    ddjy_car_team_name_dt.createOrReplaceTempView("car_team_name_dt")

    //存临时表2
    val ddjy_detail1_bf=spark.sql(
      s"""
        |select  trackno,  car_team_id,  car_team_name,  sum(dist)*0.001 as dist
        |from (
        |select trackno,car_team_id,dist,
        |case when car_team_name like '%弘大%' then '汕头市弘大物流有限公司'
        |when car_team_name like '%鑫连汇%' then '汕头市鑫连汇物流有限公司'
        |when car_team_name like '%广逸%' then '东莞市广逸物流有限公司'
        |when car_team_name like '%鸿琪%' then '深圳市鸿琪物流有限公司'
        |when car_team_name like '%宜送%' then '福建宜送物流有限公司'
        |when car_team_name like '%程飞运输%' then '汕头市程飞运输有限公司'
        |when car_team_name like '%宇轩%' then '广州市宇轩物流有限公司' else car_team_name end car_team_name
        |from  dm_gis.ddjy_vehicle_clue_detail_di
        |where inc_day in ('${dayvar0}', '${dayvar1}', '${dayvar2}', '${dayvar3}')
        |  and source = 'yy'
        |   ) x
        |group by trackno, car_team_id, car_team_name
        |""".stripMargin)

    ddjy_detail1_bf.createOrReplaceTempView("detail1_bf")

    //存中间表
    spark.sql(
      """
        |insert overwrite table dm_gis.ddjy_detail_bf_mid
        |select t1.* from detail1_bf t1
        |left semi join car_team_name_dt t2
        |on t1.car_team_name=t2.car_team_name
        |""".stripMargin)


    val car_team_name_dt2_tmpsql=
      s"""
         |    Select distinct car_team_name
         |    from
         |      ( select   *  from
         |          (select row_number() over(partition by order_sn order by UNIX_TIMESTAMP(update_date, 'yyyy-MM-dd HH:mm:ss') desc
         |              ) as rownum,*
         |            from  dm_gis.ddjy_dwd_station_order_repartition_di
         |            Where inc_day >=  replace(date_sub(from_unixtime(unix_timestamp('${dayvar0}','yyyymmdd'),'yyyy-mm-dd'),27),'-','')
         |              and inc_day <= '${dayvar0}'
         |              and order_sn != '1'
         |              and discard_time is null
         |              and car_team_name is not null
         |              and del_flag = '0'
         |              and order_status in ('1', '2')
         |          ) a where a.rownum = 1
         |      ) b
         |      Left join (
         |        select * from
         |          ( select order_sn,case when carplate is null or trim(carplate)='' or length(carplate)<=3 then null else carplate end carplate,
         |              row_number() over(partition by order_sn order by UNIX_TIMESTAMP(update_time, 'yyyy-MM-dd HH:mm:ss') desc
         |              ) rownum
         |            from dm_gis.ddjy_station_order_pics_carplate
         |             where inc_day in
         |  (select max(inc_day) inc_day from dm_gis.ddjy_station_order_pics_carplate where id is not null)
         |          ) e  where  e.rownum = 1
         |      ) c On b.order_sn = c.order_sn
         |""".stripMargin

    val car_team_name_dt2_tmp=spark.sql(car_team_name_dt2_tmpsql)

    car_team_name_dt2_tmp.createOrReplaceTempView("car_team_name_dt2")

    val city_bf_tmpsql=
      s"""
         |    select distinct city_name  from  dm_gis.ddjy_dim_station_info_filter
         | 			             where inc_day in
         |  (select max(inc_day) inc_day from dm_gis.ddjy_dim_station_info_filter where id is not null)
         |      and petrol_resources = '2'
         |      and del_flag = '0'
         |""".stripMargin

    val city_bf_tmp=spark.sql(city_bf_tmpsql)

    city_bf_tmp.createOrReplaceTempView("city_bf")

    //存入表
    spark.sql(
      s"""
         |insert overwrite table dm_gis.ddjy_detail_bf_mid2
         |select  trackno,  car_team_id,  car_team_name,  sum(dist)*0.001 as dist
         |from (
         |
         |select a1.*
         |from (
         |select trackno,car_team_id,dist,city,
         |case when car_team_name like '%弘大%' then '汕头市弘大物流有限公司'
         |when car_team_name like '%鑫连汇%' then '汕头市鑫连汇物流有限公司'
         |when car_team_name like '%广逸%' then '东莞市广逸物流有限公司'
         |when car_team_name like '%鸿琪%' then '深圳市鸿琪物流有限公司'
         |when car_team_name like '%宜送%' then '福建宜送物流有限公司'
         |when car_team_name like '%程飞运输%' then '汕头市程飞运输有限公司'
         |when car_team_name like '%宇轩%' then '广州市宇轩物流有限公司' else car_team_name end car_team_name
         |from dm_gis.ddjy_vehicle_clue_detail_di
         |where inc_day in ('${dayvar0}', '${dayvar1}', '${dayvar2}', '${dayvar3}')
         |  and source = 'yy'
         |) a1
         |left semi join city_bf a2
         |on a1.city=a2.city_name
         |left semi join car_team_name_dt2 a3
         |on a1.car_team_name=a3.car_team_name
         | ) x
         |group by  trackno,car_team_id,car_team_name
         |""".stripMargin)


    //结果表一存储
    val yygj_carplate_df=spark.sql(
      s"""
         |select
         |t1.trackno,t1.car_team_id,t1.car_team_name,
         |t1.dist as total_dist,
         |t2.dist as total_dist_online_city
         |from dm_gis.ddjy_detail_bf_mid t1
         |left join dm_gis.ddjy_detail_bf_mid2 t2
         |on t1.trackno=t2.trackno
         |and t1.car_team_id=t2.car_team_id
         |and t1.car_team_name=t2.car_team_name
         |""".stripMargin)

    SparkWrite.writeToHive(spark,yygj_carplate_df.coalesce(5),"inc_day",dayvar0,"dm_gis.ddjy_yygj_carplate")

    //结果表二存储
    val order_carplate_df=spark.sql(
      s"""
         |Select  f.carplate as trackno,f.car_team_id,f.car_team_name,sum(f.oil_mass) as oilmass
         |from
         |  ( Select  b.car_team_id,b.car_team_name,b.oil_mass,if(c.carplate is not null, c.carplate, b.carplate) as carplate
         |    from  (
         |        select * from
         |          (select row_number() over(
         |                partition by  order_sn
         |                order by  UNIX_TIMESTAMP(update_date, 'yyyy-MM-dd HH:mm:ss') desc
         |              ) as rownum, car_team_id,oil_mass,order_sn,
         |			  case when trim(carplate)='' or carplate='null' or carplate is null then '' else carplate end carplate,
         |			  case when car_team_name like '%弘大%' then '汕头市弘大物流有限公司'
         |				when car_team_name like '%鑫连汇%' then '汕头市鑫连汇物流有限公司'
         |				when car_team_name like '%广逸%' then '东莞市广逸物流有限公司'
         |				when car_team_name like '%鸿琪%' then '深圳市鸿琪物流有限公司'
         |				when car_team_name like '%宜送%' then '福建宜送物流有限公司'
         |				when car_team_name like '%程飞运输%' then '汕头市程飞运输有限公司'
         |				when car_team_name like '%宇轩%' then '广州市宇轩物流有限公司' else car_team_name end car_team_name
         |            from  dm_gis.ddjy_dwd_station_order_repartition_di
         |            Where inc_day >=  replace(date_sub(from_unixtime(unix_timestamp('${dayvar0}','yyyymmdd'),'yyyy-mm-dd'),27),'-','')
         |              and inc_day <= '${dayvar0}'
         |              and order_sn != '1'
         |              and discard_time is null
         |              and car_team_name is not null
         |              and del_flag = '0'
         |              and order_status in ('1', '2')
         |          ) a
         |        where   a.rownum = 1
         |      ) b
         |      Left join (
         |        select  * from
         |          ( select  order_sn,case when carplate is null or trim(carplate)='' or length(carplate)<=3 then null else carplate end carplate,
         |              row_number() over(
         |                partition by    order_sn
         |                order by  UNIX_TIMESTAMP(update_time, 'yyyy-MM-dd HH:mm:ss') desc
         |              ) rownum
         |            from  dm_gis.ddjy_station_order_pics_carplate
         |                         where inc_day in
         |  (select max(inc_day) inc_day from dm_gis.ddjy_station_order_pics_carplate where id is not null)
         |          ) e
         |        where  e.rownum = 1
         |      ) c On b.order_sn = c.order_sn
         |  ) f
         |group by f.car_team_id, f.car_team_name, f.carplate
         |""".stripMargin)

    SparkWrite.writeToHive(spark,order_carplate_df.coalesce(5),"inc_day",dayvar0,"dm_gis.ddjy_order_carplate")

    //结果表三存储
    spark.sql(
      s"""
         |insert overwrite table dm_gis.ddjy_overlap_carplate
         |partition(inc_day=${dayvar0})
         |Select
         |  a.trackno,
         |  b.car_team_id as car_team_id_dd,
         |  b.car_team_name as car_team_name_dd,
         |  b.oilmass,
         |  a.car_team_id as car_team_id_yy,
         |  a.car_team_name as car_team_name_yy,
         |  a.total_dist,
         |  a.total_dist_online_city,
         |  case when b.car_team_name is not null and b.car_team_name !='' then b.car_team_name else a.car_team_name end
         |  as  actual_carteam,
         |  round(a.total_dist/(b.oilmass/0.22),6) as ratio_online_dist
         |
         |from
         |    (
         |      Select  *  from  dm_gis.ddjy_yygj_carplate
         |      Where inc_day = ${dayvar0} and trackno not in ('','null') and trackno is not null
         |    ) a
         |    Inner join (
         |      Select *  from  dm_gis.ddjy_order_carplate
         |      Where inc_day = ${dayvar0} and trackno not in ('','null') and trackno is not null
         |    ) b On a.trackno = b.trackno
         |""".stripMargin)



    //---表四：车队维度表
//    val ownerid_sql=  s"""
//                         |	select  b.id as id,c.owner_id as owner_id
//                         |	from  (
//                         |		select  distinct id,name,tax_no
//                         |		from dm_gis.ddjy_ods_dim_team_info
//                         |        where inc_day in
//                         |      (select max(inc_day) inc_day from dm_gis.ddjy_ods_dim_team_info where id is not null)
//                         |		  and del_flag = '0'
//                         |		  and tax_no is not null
//                         |	  ) b
//                         |	   join (
//                         |		select  distinct owner_id,owner_name,credit_code
//                         |		from  dm_gis.dim_ddjy_vehicle_concat_yy_df
//                         |		where
//                         |		 credit_code not in ('','null') and credit_code is not null
//                         |		 and inc_day in
//                         |	   (select max(inc_day) inc_day from dm_gis.dim_ddjy_vehicle_concat_yy_df where inc_day is not null and inc_day !='')
//                         |	  ) c on b.tax_no = c.credit_code
//                         |""".stripMargin

    val ownerid_sql=  s"""
                         |	select  b.id as id,c.owner_id as owner_id
                         |	from  (
                         |		select  distinct id,name,tax_no
                         |		from dm_gis.ddjy_ods_dim_team_info
                         |        where inc_day in
                         |      (select max(inc_day) inc_day from dm_gis.ddjy_ods_dim_team_info where id is not null)
                         |		  and del_flag = '0'
                         |		  and tax_no is not null
                         |	  ) b
                         |	   join (
                         |		select  distinct owner_id,owner_name,credit_code
                         |		from  dm_gis.ddjy_vehicle_ownership_day_dtl
                         |		where
                         |		 credit_code not in ('','null') and credit_code is not null
                         |		 and inc_day ='$dayvar4'
                         |	  ) c on b.tax_no = c.credit_code
                         |""".stripMargin
    println("ownerid_sql:")
    println(ownerid_sql)
    val owner_id_tb=spark.sql(ownerid_sql)

    owner_id_tb.createOrReplaceTempView("owner_id_tb_view")

    spark.sql(
      """
        |insert overwrite table dm_gis.ddjy_towner_id_tb
        |select * from owner_id_tb_view
        |""".stripMargin)




    val tb_all_1_tmp=spark.sql(
      s"""
         |select
         |coalesce(t1.car_team_id_dd,t2.car_team_id,t3.car_team_id,t3a.id) car_team_id_dd,
         |
         |coalesce(t1.actual_carteam,t2.car_team_name,t3.car_team_name) as  actual_carteam,
         |
         |t1.oilmass, t2.oilmass_null,t3.oilmass_all,t3a.owner_id
         |
         |from
         |(
         |	Select car_team_id_dd,actual_carteam,sum(Oilmass) as Oilmass
         |	from dm_gis.ddjy_overlap_carplate
         |	Where inc_day = '${dayvar0}'
         |	and Ratio_Online_dist > 0.07
         |	Group by car_team_id_dd,actual_carteam
         |) t1
         |full join
         |(
         |	Select car_team_id ,car_team_name,sum(oilmass) as oilmass_null
         |	from dm_gis.ddjy_order_carplate
         |	Where (trackno in('','null') or trackno is null) and inc_day =  '${dayvar0}'
         |	Group by car_team_id ,car_team_name
         |) t2 on t1.car_team_id_dd=t2.car_team_id
         |full join
         |(
         |	select car_team_id,car_team_name,sum(oilmass) as oilmass_all
         |	from dm_gis.ddjy_order_carplate
         |	where inc_day='${dayvar0}'
         |	group by car_team_id,car_team_name
         |) t3 on coalesce(t1.car_team_id_dd,t2.car_team_id)=t3.car_team_id
         |full join owner_id_tb_view t3a
         |on coalesce(t1.car_team_id_dd,t2.car_team_id,t3.car_team_id)=t3a.id
         |""".stripMargin)

    tb_all_1_tmp.createOrReplaceTempView("tb_all_1")

    spark.sql(
      """
        |insert overwrite table dm_gis.ddjy_tb_all_1_tmp
        |select * from tb_all_1
        |""".stripMargin)

    val tb_all_2_tmp=spark.sql(
      s"""
         |select coalesce(y1.car_team_id_dd,y3.car_team_id,y5.car_team_id_dd,y6.car_team_id,y7.car_team_id_dd)  car_team_id_dd,
         |coalesce(y1.actual_carteam,y2.car_team_name,y3.car_team_name,y4.car_team_name) actual_carteam,
         |
         |y1.oilmass, y1.oilmass_null,y1.oilmass_all,
         |coalesce(y1.owner_id,y2.car_team_id,y4.owner_id) owner_id,
         |
         |y2.total_dist,y2.total_dist_online_city,
         |
         |case when nvl(y2.total_dist,0)=0 then 'inf' else (nvl(y1.oilmass,0)+nvl(y1.oilmass_null,0))/(y2.total_dist*0.22) end as oil_dimension1,
         |case when nvl(y2.total_dist_online_city,0)=0 then 'inf' else (nvl(y1.oilmass,0)+nvl(y1.oilmass_null,0))/(y2.total_dist_online_city*0.22) end as oil_dimension2,
         |
         |y3.carplate,y4.num_carno,
         |y3.carplate/y4.num_carno car_dimension,
         |y5.del_carnum,y6.yy_carnum,y7.overlap_carnum,
         |'1' flag
         |
         |from  tb_all_1 y1
         |full join
         |(
         |
         |	select car_team_id,car_team_name,sum(Total_dist) as total_dist,sum(Total_dist_online_city) as total_dist_online_city
         |	from dm_gis.ddjy_yygj_carplate
         |	where inc_day='${dayvar0}' and trackno not in
         |	(select distinct trackno from dm_gis.ddjy_overlap_carplate where inc_day='${dayvar0}' and Ratio_Online_dist <= 0.07)
         |	group by car_team_id,car_team_name
         |
         |) y2 on y1.owner_id=y2.car_team_id
         |full join
         |(
         |
         |	select car_team_id ,car_team_name,count(distinct trackno) as carplate
         |	from dm_gis.ddjy_order_carplate
         |	where inc_day='${dayvar0}' and trackno not in ('','null') and trackno is not null
         |	group by car_team_id ,car_team_name
         |
         |) y3 on y1.car_team_id_dd=y3.car_team_id
         |
         |left join
         |(
         |
         |	select owner_id,car_team_name,num_carno
         |	from dm_gis.ddjy_carteam_guiji
         |	where inc_day='${dayvar0}'
         |	and source='yy'
         |
         |) y4 on y1.owner_id=y4.owner_id
         |
         |left join
         |(
         |	select car_team_id_dd,actual_carteam,
         |	count(distinct trackno) as del_carnum
         |	from dm_gis.ddjy_overlap_carplate
         |  where inc_day='${dayvar0}'
         |	and Ratio_Online_dist <= 0.07
         |	group by car_team_id_dd,actual_carteam
         |) y5 on y1.car_team_id_dd =y5.car_team_id_dd
         |
         |left join
         |(
         |	select
         |	car_team_id, car_team_name,
         |	count(distinct trackno) as yy_carnum
         |	from dm_gis.ddjy_yygj_carplate
         |	 where inc_day='${dayvar0}'
         |	and trackno not in ('','null') and trackno is not null
         |	group by car_team_id, car_team_name
         |) y6 on y1.owner_id =y6.car_team_id
         |
         |left join
         |(
         |	select car_team_id_dd,actual_carteam,
         |	count(distinct trackno) as overlap_carnum
         |	from dm_gis.ddjy_overlap_carplate
         |	where inc_day='${dayvar0}'
         |	group by car_team_id_dd,actual_carteam
         |) y7 on y1.car_team_id_dd =y7.car_team_id_dd
         |""".stripMargin)

    tb_all_2_tmp.createOrReplaceTempView("tb_all_2")

    spark.sql(
      """
        |insert overwrite table dm_gis.ddjy_tb_all_2_tmp
        |select * from tb_all_2
        |""".stripMargin)

    val ct_tmp=spark.sql(
      s"""
         |select flag,concat_ws(',',collect_set(city_name)) online_city
         |from (
         |select '1' flag,city_name from dm_gis.ddjy_dim_station_info_filter
         | 			             where inc_day in
         |  (select max(inc_day) inc_day from dm_gis.ddjy_dim_station_info_filter where id is not null)
         |  and petrol_resources = '2' and del_flag='0'
         |) x
         |group by flag
         |""".stripMargin)

    ct_tmp.createOrReplaceTempView("ct")

    val carteam_df=spark.sql(
      s"""
         |select t1.car_team_id_dd,t1.actual_carteam,nvl(t1.oilmass,0) oilmass,nvl(t1.oilmass_null,0) oilmass_null,t1.oilmass_all,
         |t1.owner_id,nvl(t1.total_dist,0) total_dist,nvl(t1.total_dist_online_city,0) total_dist_online_city,
         |nvl(t1.oil_dimension1,0) oil_dimension1,nvl(t1.oil_dimension2,0) oil_dimension2,
         |nvl(t1.carplate,0) carplate,nvl(t1.num_carno,0) num_carno,nvl(t1.car_dimension,0) car_dimension,
         |nvl(t1.del_carnum,0) del_carnum,nvl(t1.yy_carnum,0) yy_carnum,nvl(t1.overlap_carnum,0) overlap_carnum,t2.online_city from tb_all_2 t1
         |left join ct t2
         |on t1.flag=t2.flag
         |where oilmass_all is not null
         |""".stripMargin)

    SparkWrite.writeToHive(spark,carteam_df.coalesce(5),"inc_day",dayvar0,"dm_gis.ddjy_carteam")

    spark.close()
  }
}
