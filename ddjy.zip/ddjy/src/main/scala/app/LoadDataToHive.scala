package app

import app.TeamClueTransformation.writeToHive
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * 油站全量表需求_油站销售组织架构表导入hive
 * 需求方：陶慧（01424177）
 * @author 徐游飞（01417347）
 * 任务ID：559 (一次性任务)
 * 任务名称：油站销售组织架构表导入hive
 */
object LoadDataToHive {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    // inc_day 为业务时间，即跑数时间
    val inc_day = args(0)
//    // 衡度大数据平台SparkConf
//    val conf = getSparkConf_hd(className,null)
//    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    spark.sparkContext.setLogLevel("WARN")

    logger.error("++++++++  任务开始  ++++")
    val dataframe: DataFrame = spark.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("/dolphinscheduler/user/01417347/test.csv")

    val df_ret = dataframe
      .select("petrol_station_name","sup_name","sub_name","user_name","user_phone","user_job_id","station_num")
      .withColumn("inc_day", lit(inc_day))

    val cols_ret = spark.sql("""select * from dm_gis.ddjy_dim_station_sales_info limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_ret: _*),Seq("inc_day"),"dm_gis.ddjy_dim_station_sales_info")

    logger.error("++++++++  任务完成  ++++")

    spark.stop()

  }

}
