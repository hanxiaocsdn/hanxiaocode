package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:补录车队销售报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:
 * 任务名称：一次性任务
 * 依赖任务：
 * 数据源：ddjy_dim_team_info_filter、ddjy_dwd_car_team_history_recharge、ddjy_ods_dim_wallet
 * 调用服务地址：无
 * 数据结果：ddjy_uimp_dm_car_sale_manage_report
 */
object CollectionTeamSaleData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String) = {
    val car_sale_manage_df: DataFrame = spark.sql(
      s"""
         |
         |select
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |org_id,
         |t1.name,
         |t1.create_date,
         |t2.min_trade_time,
         |t2.max_trade_time,
         |t2.max_trade_amount as max_trade_amount,
         |t2.sum_trade_amount as sum_trade_amount,
         |t3.available_amount as available_amount,
         |t3.freeze_amount as freeze_amount,
         |t1.province,
         |t1.city,
         |case when register_date=inc_day then '当天注册'
         |when register_date<inc_day and register_date>='${last_seven_day}' then '7天注册'
         |else '历史注册'
         |end as register_tag,
         |case when substr(min_trade_time,0,10)=inc_day then '当天首充'
         |when substr(min_trade_time,0,10)>='${last_seven_day}' and substr(min_trade_time,0,10)<inc_day then '7天首充'
         |when substr(min_trade_time,0,10)<'${last_seven_day}' and substr(min_trade_time,0,7)=substr(inc_day,0,7) then '当月首充'
         |when substr(min_trade_time,0,10)<'${last_seven_day}' and substr(min_trade_time,0,7)!=substr(inc_day,0,7) then '历史首充'
         |when min_trade_time is null and register_date>='${last_seven_day}' then '暂未充值'
         |when min_trade_time is null and register_date<'${last_seven_day}' then '注册超7天未充值'
         |end as first_recharge_tag,
         |case when substr(max_trade_time,0,10)=inc_day then '当天充值'
         |when substr(max_trade_time,0,10)>='${last_seven_day}' and substr(max_trade_time,0,10)<inc_day then '7天充值'
         |when substr(max_trade_time,0,10)<'${last_seven_day}' then '7天未充值'
         |when max_trade_time is null and register_date>='${last_seven_day}' then '暂未充值'
         |when max_trade_time is null and register_date<'${last_seven_day}' then '注册超7天未充值'
         |end as latest_recharge_tag,
         |case when inc_day=substr(min_trade_time,0,10) then '当天新增'
         |when register_date=inc_day and max_trade_time is null then '当天注册'
         |when substr(min_trade_time,0,10)<inc_day and substr(max_trade_time,0,10)>='${last_seven_day}' then '稳定车队'
         |when min_trade_time is not null and substr(max_trade_time,0,10)<'${last_seven_day}' then '流失车队'
         |when min_trade_time is null and register_date>='${last_seven_day}' then '待激活'
         |when min_trade_time is null and register_date<'${last_seven_day}' then '历史未激活'
         |end as client_tag,
         |round(sum_trade_amount-available_amount-freeze_amount,2) as sum_consume_amount,
         |'2022121415' as hour_time,
         |id as team_id
         |from
         |(
         |select org_id,name,
         |create_date,
         |substr(create_date,0,10) as register_date,
         |province,city,
         |from_unixtime(unix_timestamp(inc_day,'yyyyMMdd'),'yyyy-MM-dd') as inc_day,id
         |from dm_gis.ddjy_dim_team_info_filter
         |where inc_day='${inc_day}'
         |) as t1
         |left join
         |(
         |select
         |sum(trade_amount)as sum_trade_amount,
         |split(max(concat(trade_time,'\001',trade_amount)),'\001')[1] as max_trade_amount,
         |max(trade_time)as max_trade_time,
         |min(trade_time)as min_trade_time,
         |team_id
         |from dm_gis.ddjy_dwd_car_team_history_recharge
         |where inc_day <= '${inc_day}'
         |and locate(account_name,'测试')=0
         |and locate(account_name,'FT')=0
         |and trade_description = '车队充值上账'
         |group by team_id
         |) as t2
         |on t1.id=t2.team_id
         |left join
         |(
         |select available_amount,freeze_amount,user_id as team_id
         |from dm_gis.ddjy_ods_dim_wallet
         |where inc_day='${inc_day}' and user_type='2' and account_type='10'
         |and locate(account_name,'测试')=0
         |and locate(account_name,'FT')=0
         |and del_flag='0'
         |) t3
         |on t1.id=t3.team_id
         |""".stripMargin)
    car_sale_manage_df.repartition(1).createOrReplaceTempView("car_sale_manage_tmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_uimp_dm_car_sale_manage_report partition(inc_day='${inc_day}') select * from car_sale_manage_tmp")
    logger.error("写入ddjy_uimp_dm_car_sale_manage_report每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    var before_yesterday=""
    var last_seven_day: String=""
    for (i <- (0 to 62).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      before_yesterday = DateUtil.getDateStr(incDay, -1, "")
      last_seven_day = DateUtil.getDateStr(incDay, -6, "")
      stationProcess(spark,incDay,before_yesterday,last_seven_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>补录车队销售报表 Execute Ok")
  }

}
