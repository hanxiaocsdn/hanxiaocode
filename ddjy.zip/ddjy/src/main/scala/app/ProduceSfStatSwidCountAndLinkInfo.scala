package app

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkNet, SparkWrite}

import scala.collection.JavaConversions._


/**
 * @Description:未上线
 * 需求人员：
 * @Author: lixiangzhi 01405644
 * @Date:
 * 任务id:无
 * 任务名称：无
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object ProduceSfStatSwidCountAndLinkInfo {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  case class LinkInfo(
                        linkid:String,
                        dir:String,
                        roadclass:String,
                        linktype:String,
                        formway:String,
                        fc:String,
                        ownership:String,
                        srcid:String,
                        tollid:String,
                        state:String,
                        timestamps:String,
                        inserttime:String,
                        linklength:String,
                        tracktype:String,
                        overhead:String,
                        rect:String,
                        geolinkpoint:String,
                        vehicle_type:String,
                        max_weight:String,
                        max_width:String,
                        max_height:String,
                        adcode:String,
                        uniqueid:String,
                        version_id:String,
                        gasstation:String,
                        road_name:String,
                        rid:String,
                        rversion:String,
                        updatetime:String,
                        tracktime:String,
                        gridid:String,
                        del_flag:String
                     )
  def trackQueryService(spark: SparkSession, incDay: String,start_car_no:String,end_car_no:String) = {
    import spark.implicits._
    val fri_day: String = DateUtil.getDateStr(incDay, -1, "")
    val yyTrackSql=
      s"""
        |select
        |car_no,lng,lat,tm,
        |row_number() over(partition by car_no order by tm) as rnk
        |from
        |(
        |	select *,
        |	row_number() over(partition by car_no,tm order by tm) as rnk
        |	from dm_gis.ods_track_yy_di
        |	where inc_day='$incDay'
        |	and car_no>='$start_car_no' and car_no<'$end_car_no'
        |	and lng is not null
        |	and lng!=''
        |	and lat is not null
        |	and lat!=''
        |) t1
        |where rnk=1
        |""".stripMargin
//    val yyTrackSql=
//      s"""
//         |select
//         |car_no,lng,lat,tm,
//         |row_number() over(partition by car_no order by tm) as rnk
//         |from
//         |(
//         |	select *,
//         |	row_number() over(partition by car_no,tm order by tm) as rnk
//         |	from dm_gis.ods_track_yy_di
//         |	where inc_day='$incDay'
//         |	and car_no='粤AFM162'
//         |	and lng is not null
//         |	and lng!=''
//         |	and lat is not null
//         |	and lat!=''
//         |) t1
//         |where rnk=1
//         |""".stripMargin
    val yyTrackRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, yyTrackSql).repartition(600).map(obj=>{
      val car_no: String = obj.getString("car_no")
      val rnk: Long = obj.getLongValue("rnk")
      val repart_tag: Long = rnk / 5000
      ((car_no,repart_tag),obj)
    }).groupByKey().map(obj=>{
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getString("tm"))
      val tracks = new util.ArrayList[JSONObject]()
      for (i <- list.indices){
        if (i<list.size-1){
          if (i==0){
            val tmpObj0 = new JSONObject()
            tmpObj0.put("time", list(0).getLongValue("tm"))
            tmpObj0.put("x", list(0).getDoubleValue("lng"))
            tmpObj0.put("y", list(0).getDoubleValue("lat"))
            tmpObj0.put("accuracy", 15)
            tmpObj0.put("type", 1)
            tracks.append(tmpObj0)
          }
          val lngi: Double = list(i).getDoubleValue("lng")
          val lati: Double = list(i).getDoubleValue("lat")
          val lngi1: Double = list(i+1).getDoubleValue("lng")
          val lati1: Double = list(i+1).getDoubleValue("lat")
          if (lngi!=lngi1 || lati!=lati1){
            val tmpObj = new JSONObject()
            tmpObj.put("time", list(i+1).getLongValue("tm"))
            tmpObj.put("x", lngi1)
            tmpObj.put("y", lati1)
            tmpObj.put("accuracy", 15)
            tmpObj.put("type", 1)
            tracks.append(tmpObj)
          }
        }
      }

      val newObj = new JSONObject()
      newObj.put("tracks",tracks.toArray())
      newObj.put("car_no",obj._1._1)
      newObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调纠偏接口的数据量:"+yyTrackRdd.count())

    val returnTrackRectifyRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, yyTrackRdd, SfNetInteface.trackRectifySfInterface, 100, "", 5000)
    //returnTrackRectifyRdd.take(1).foreach(println(_))
    val trackRectifyRdd: RDD[JSONObject] = returnTrackRectifyRdd.flatMap(obj => {
      val paths: JSONArray = JSONUtil.getJsonArrayMulti(obj, "paths")
      val tmpListi = new util.ArrayList[JSONObject]()
      for (i <- 0 until (paths.size())) {
        val pathsi: JSONObject = paths.getJSONObject(i)
        val steps: JSONArray = JSONUtil.getJsonArrayMulti(pathsi, "steps")
        val tmpListj = new util.ArrayList[JSONObject]()
        for (j <- 0 until (steps.size())) {
          val stepsj: JSONObject = steps.getJSONObject(j)
          val links: JSONArray = JSONUtil.getJsonArrayMulti(stepsj, "links")
          val tmpList = new util.ArrayList[JSONObject]()
          for (m <- 0 until (links.size())) {
            val linksm: JSONObject = links.getJSONObject(m)
            val tmpObj = new JSONObject()
            val car_no: String = obj.getString("car_no")
            val dir: String = linksm.getString("dir")
            val roadclass: String = linksm.getString("roadclass")
            val linktype: String = linksm.getString("lnk_type")
            val formway: String = linksm.getString("formway")
            val fc: String = linksm.getString("fc")
            val ownership: String = linksm.getString("ownership")
            val linklength: String = linksm.getString("length")
            val overhead: String = linksm.getString("overhead")
            val adcode: String = linksm.getString("adcode")
            val road_name: String = linksm.getString("name")
            val swid: String = linksm.getString("sw_id")
            tmpObj.put("dir", dir)
            tmpObj.put("roadclass", roadclass)
            tmpObj.put("linktype", linktype)
            tmpObj.put("formway", formway)
            tmpObj.put("fc", fc)
            tmpObj.put("ownership", ownership)
            tmpObj.put("linklength", linklength)
            tmpObj.put("overhead", overhead)
            tmpObj.put("adcode", adcode)
            tmpObj.put("road_name", road_name)
            tmpObj.put("swid", swid)
            tmpObj.put("car_no", car_no)
            tmpList.add(tmpObj)
          }
          tmpListj.addAll(tmpList)
        }
        tmpListi.addAll(tmpListj)
      }
      tmpListi.iterator()
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    yyTrackRdd.unpersist()
    val statSwidCountDf: DataFrame = trackRectifyRdd.map(obj => {
      ((obj.getString("car_no"), obj.getString("swid")), obj)
    }).groupByKey().map(obj => {
      val count: Int = obj._2.toList.size
      val car_no: String = obj._1._1
      val swid: String = obj._1._2
      (car_no + "_" + swid, car_no, swid, count)
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("statSwidCount表数据量:"+statSwidCountDf.count())
    SparkWrite.writeTypeToHive(spark,statSwidCountDf,"into","inc_day",fri_day,"dm_gis.tmp_ddjy_stat_swid_count",10)
    statSwidCountDf.unpersist()
    val cal = Calendar.getInstance
    val updatetime: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(cal.getTime)
    val linkInfoDf: DataFrame = trackRectifyRdd.map(obj=>{
      val swid: String = obj.getString("swid")
      obj.put("linkid",swid)
      obj.put("srcid",swid)
      obj.put("updatetime",updatetime)
      obj
    }).groupBy(_.getString("srcid")).map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.maxBy(_.getString("updatetime"))
      tmpObj
    }).map(obj => {
      LinkInfo(
        obj.getString("linkid"),
        obj.getString("dir"),
        obj.getString("roadclass"),
        obj.getString("linktype"),
        obj.getString("formway"),
        obj.getString("fc"),
        obj.getString("ownership"),
        obj.getString("srcid"),
        obj.getString("tollid"),
        obj.getString("state"),
        obj.getString("timestamps"),
        obj.getString("inserttime"),
        obj.getString("linklength"),
        obj.getString("tracktype"),
        obj.getString("overhead"),
        obj.getString("rect"),
        obj.getString("geolinkpoint"),
        obj.getString("vehicle_type"),
        obj.getString("max_weight"),
        obj.getString("max_width"),
        obj.getString("max_height"),
        obj.getString("adcode"),
        obj.getString("uniqueid"),
        obj.getString("version_id"),
        obj.getString("gasstation"),
        obj.getString("road_name"),
        obj.getString("rid"),
        obj.getString("rversion"),
        obj.getString("updatetime"),
        obj.getString("tracktime"),
        obj.getString("gridid"),
        obj.getString("del_flag")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    SparkWrite.writeTypeToHiveNoPart(spark,linkInfoDf,"into","dm_gis.ddjy_linkinfo_1223")
    trackRectifyRdd.unpersist()
    linkInfoDf.unpersist()
  }

  def trackNoGroup(spark: SparkSession, incDay: String) = {
    val yyTrackGroupSql=
      s"""
         |select
         |car_no,
         |dense_rank() over(order by car_no) as car_no_rnk
         |from
         |(
         |	select car_no
         |	from dm_gis.ods_track_yy_di
         |	where inc_day='$incDay'
         |	group by car_no
         |) t1
         |""".stripMargin
    val carNoMap: collection.Map[Int,String] = SparkUtils.getRowToJson(spark, yyTrackGroupSql).map(obj => {
      val car_no_rnk: Int = obj.getIntValue("car_no_rnk")
      val car_no: String = obj.getString("car_no")
      (car_no_rnk, car_no)
    }).collectAsMap()
    carNoMap
  }

  def distinctLinfo(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val linkInfoSql=
      """
        |select * from dm_gis.ddjy_linkinfo
        |union all
        |select * from dm_gis.ddjy_linkinfo_1223
        |""".stripMargin
    val historyLinkInfoRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, linkInfoSql)
    val linkInfoDf: DataFrame = historyLinkInfoRdd.groupBy(_.getString("srcid")).map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.maxBy(_.getString("updatetime"))
      tmpObj
    }).map(obj => {
      LinkInfo(
        obj.getString("linkid"),
        obj.getString("dir"),
        obj.getString("roadclass"),
        obj.getString("linktype"),
        obj.getString("formway"),
        obj.getString("fc"),
        obj.getString("ownership"),
        obj.getString("srcid"),
        obj.getString("tollid"),
        obj.getString("state"),
        obj.getString("timestamps"),
        obj.getString("inserttime"),
        obj.getString("linklength"),
        obj.getString("tracktype"),
        obj.getString("overhead"),
        obj.getString("rect"),
        obj.getString("geolinkpoint"),
        obj.getString("vehicle_type"),
        obj.getString("max_weight"),
        obj.getString("max_width"),
        obj.getString("max_height"),
        obj.getString("adcode"),
        obj.getString("uniqueid"),
        obj.getString("version_id"),
        obj.getString("gasstation"),
        obj.getString("road_name"),
        obj.getString("rid"),
        obj.getString("rversion"),
        obj.getString("updatetime"),
        obj.getString("tracktime"),
        obj.getString("gridid"),
        obj.getString("del_flag")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    SparkWrite.writeToHiveNoPart(spark,linkInfoDf,"dm_gis.ddjy_linkinfo_1223")
  }

  def execute(incDay: String,startInt:Int) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //循环调用接口
    val carNoMap: collection.Map[Int,String] = trackNoGroup(spark, incDay)
    val maxRnk: Int = carNoMap.max._1
    //for循环,startInt为1,10001,20001,.....
    for (i <- startInt to(maxRnk) by 10000){
      val start_car_no: String = carNoMap.getOrElse(i,null)
      var end_car_no: String = carNoMap.getOrElse(maxRnk,null)
      if (i+10000<maxRnk){
        end_car_no = carNoMap.getOrElse(i+10000,null)
      }
      logger.error("跑数车辆区间:"+start_car_no+"-"+end_car_no+","+start_car_no+"编号是"+i)
      //调用历史轨迹查询服务接口
      trackQueryService(spark,incDay,start_car_no,end_car_no)
    }
//    trackQueryService(spark,incDay,"","")
    //对linkinfo去重
    distinctLinfo(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val startInt: Int = args(1).toInt
    execute(incDay,startInt)
    logger.error("======>>>>>>Execute Ok")
  }
}
