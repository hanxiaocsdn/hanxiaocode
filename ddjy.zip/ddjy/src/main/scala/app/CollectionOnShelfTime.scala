package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkWrite

/**
 * @Description:车队消费趋势报表
 * @Author: lixiangzhi 01405644 迭代修改：周勇 01390943
 * @Date: 11:05 2022/11/29
 * 任务id:417
 * 任务名称：吨吨加油平台流水明细
 * 依赖任务：每日-车队历史充值记录表 498、每日-原始油站信息过滤表 512、每日-原始车队信息过滤表 501、订单支付时间重分区表 387
 * 数据源：ddjy_dim_team_info_filter、ddjy_dwd_station_order_pay_repartition_di、ddjy_dim_station_info_filter、ddjy_dwd_station_stream_detail、ddjy_dwd_car_team_history_recharge
 * 调用服务地址：无
 * 数据结果：ddjy_dwd_station_stream_detail
 */

object CollectionOnShelfTime {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def teamProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String,fri_day:String) = {
    import spark.implicits._
    //生成 ddjy_dim_station_info_on_shelf_time_df
    val on_shelf_time_sql=
      s"""
        |select
        |t1.id
        |,name
        |,grpid
        |,province_name
        |,city_name
        |,city_code
        |,area_name
        |,address_name
        |,x
        |,y
        |,geom
        |,station_type
        |,brand
        |,account_prop
        |,tax_no
        |,del_flag
        |,enable_flag
        |,case when enable_flag='1' and t2.on_shelf_time is not null and t2.on_shelf_time!='' then on_shelf_time
        |	  when enable_flag='1' and (t2.on_shelf_time is null or t2.on_shelf_time ='') then from_unixtime(unix_timestamp(inc_day,'yyyyMMdd'),'yyyy-MM-dd')
        |	  when enable_flag!='1' then ''
        |	  end as on_shelf_time
        |,discount_model
        |,petrol_station_status
        |,business_status
        |,pay_type
        |,case when grpid like 'ty_%' then replace(replace(grpid,'ty_',''),'_','')
        |	  when grpid like 'fhm_%' then replace(replace(grpid,'fhm_',''),'_','')
        |	  when grpid like 'cft_%' then replace(replace(grpid,'cft_',''),'_','')
        |    when grpid like 'ylk_%' then replace(replace(grpid,'ylk_',''),'_','')
        |	  else grpid
        |	  end as new_grpid,
        |if(t1.sales_name is not null and t1.sales_name!='',t1.sales_name,t3.sales_name) as sales_name,
        |if(t1.sales_phone is not null and t1.sales_phone!='',t1.sales_phone,t3.sales_phone) as sales_phone
        |from
        |(
        |	select
        |	id
        |	,petrol_station_name as name
        |	,grpid
        |	,province_name
        |	,city_name
        |	,city_code
        |	,area_name
        |	,address_name
        |	,x
        |	,y
        |	,geom
        |	,station_type
        |	,brand
        |	,account_prop
        |	,tax_no
        |	,del_flag
        |	,enable_flag
        |	,discount_model
        |	,petrol_station_status
        |	,business_status
        |	,pay_type
        |	,sales_name
        |	,corp_id
        |	,sales_phone
        |	,inc_day
        |	from dm_gis.ddjy_dim_station_info_filter
        |	where inc_day='${inc_day}'
        |	and del_flag='0'
        |) t1
        |left join
        |(
        |	select
        |	id,on_shelf_time
        |	from dm_gis.ddjy_dim_station_info_on_shelf_time_df
        |	where inc_day='${before_yesterday}'
        |) t2
        |on t1.id=t2.id
        |left join
        |(
        |	select
        |	id,sales_name,sales_phone
        |	from dm_gis.ddjy_ods_corp_info_df
        |	where inc_day='${inc_day}'
        |	and del_flag='0'
        |) t3
        |on t1.corp_id=t3.id
        |""".stripMargin
    val on_shelf_time_df: DataFrame = spark.sql(on_shelf_time_sql)
    logger.error("ddjy_dim_station_info_on_shelf_time_df表数据量:"+on_shelf_time_df.count())
    SparkWrite.writeToHive(spark,on_shelf_time_df,"inc_day",inc_day,"dm_gis.ddjy_dim_station_info_on_shelf_time_df",1)
    logger.error("写入ddjy_dim_station_info_on_shelf_time_df每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String,dates:Int) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    for (i <- (0 to dates).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      val sdf = new SimpleDateFormat("yyyyMMdd")
      val actionTime = sdf.parse(incDay)
      val cal_5 = Calendar.getInstance
      cal_5.setTime(actionTime)
      cal_5.add(Calendar.WEEK_OF_MONTH, -1)
      cal_5.set(Calendar.DAY_OF_WEEK, 6)
      val fri_day = sdf.format(cal_5.getTime)
      teamProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day,fri_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val dates: Int = args(1).toInt
    execute(inc_day,dates)
    logger.error("======>>>>>>油站上线时间表 Execute Ok")
  }

}
