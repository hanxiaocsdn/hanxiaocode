package app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.SparkWrite

/**
 * @Description:车队油站融合表去重
 * 需求人员：
 * @Author: lixiangzhi 01405644
 * @Date:
 * 任务id:临时任务
 * 任务名称：
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object MergeDistinct {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val mergeDsitinctSql=
      s"""
        |
        |select
        |gas_id
        |,stationname
        |,adcode
        |,province
        |,city
        |,district
        |,lng
        |,lat
        |,cooperatestatus
        |,tel
        |,brand
        |,gas_type
        |,carrier_id
        |,carrier_name
        |,credit_code
        |,legal_person_name
        |,content
        |,city_adcode
        |,carrier_status
        |,carrier_tag
        |,clue_task_count
        |,clue_vehicle_count
        |,pathway_task_count
        |,pathway_vehicle_count
        |,pathway_around_task_count
        |,pathway_around_vehicle_count
        |,stay_task_count
        |,stay_vehicle_count
        |,one_carrier_gas_rank
        |,one_gas_carrier_rank
        |,clue_distribution
        |,clue_city_distribution
        |,pathway_city_distribution
        |,clue_dist_avg
        |,carrier_pathway_cost
        |,update_time
        |,task_batch
        |,gas_competitors
        |,gas_road_type
        |,gas_road_function_type
        |,task_sum_count
        |,pathway_cost_task_count
        |,tag
        |,carrier_circle_id
        |,carrier_scale
        |,carrier_suspected_address
        |,carrier_priority
        |,addr
        |,src
        |,circle_task_count
        |,register_vehicle_count
        |,suspected_adcode
        |,online_gas_top5
        |,carrier_white_list
        |,online_gas_top10
        |,stationalias
        |,stationtype
        |,pricedieselout
        |from
        |(
        |	select
        |	*,
        |	row_number() over(partition by gas_id,carrier_id order by cast(clue_task_count as bigint) desc) as rnk
        |	from dm_gis.dm_ddjy_gas_carrier_merge_di
        |	where inc_day='$incDay'
        |) t1
        |where rnk=1
        |""".stripMargin
    val mergeDsitinctDf: DataFrame = spark.sql(mergeDsitinctSql)
    SparkWrite.writeToHive(spark,mergeDsitinctDf,"inc_day",incDay,"dm_gis.dm_ddjy_gas_carrier_merge_di",100)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
}
