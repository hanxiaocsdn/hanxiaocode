package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SparkUtils, SparkWrite}

/**
 * Description:【吨吨加油】线索数据融合需求_V1.1-油站车队融合月维度表
 * 需求方：娇悦 01404184
 * Author: 李相志 01405644
 * Date: 14:30 2023/2/15
 * 任务id:1091
 * 任务名称：油站车队融合月维度表
 * 依赖任务：524
 * 数据源：ddjy_carteam_business_distribution、ddjy_pathway_clue_month_statistic_di、dm_ddjy_gas_station_info_di、ddjy_station_near_road_clue_di、join_clue_pathway_frequency_month_di、dwd_ddjy_carrier_info_seed、ddjy_ods_dim_team_info、dm_ddjy_carrier_rlst_di_month
 * 调用服务地址：无
 * 数据结果：dm_ddjy_gas_carrier_merge_di_month
 *
 */
object GasCarrierMergeMonthBak {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def stationInfoProcess(spark: SparkSession, max_day: String) = {
    val stationInfoSql=
      """
        |select *
        |from dm_gis.dm_ddjy_gas_station_info_di
        |where delflag='0'
        |""".stripMargin
    val gasCompetitorsRdd: RDD[(String, GasCompetitor)] = SparkUtils.getRowToJson(spark, stationInfoSql).map(obj => {
      val poiid: String = obj.getString("poiid")
      val stationname: String = obj.getString("stationname")
      val cooperatestatus: String = obj.getString("cooperatestatus")
      val stationtype: String = obj.getString("stationtype")
      val pricedieselout: String = obj.getString("pricedieselout")
      val adcode: String = obj.getString("adcode")
      val province: String = obj.getString("province")
      val city: String = obj.getString("city")
      val district: String = obj.getString("district")
      val lng: String = obj.getString("lng")
      val lat: String = obj.getString("lat")
      val tel: String = obj.getString("tel")
      val brand: String = obj.getString("querybrandid")
      val gas_type: String = obj.getString("management_model")
      GasCompetitor(
        poiid,
        stationname,
        cooperatestatus,
        stationtype,
        pricedieselout,
        adcode,
        province,
        city,
        district,
        lng,
        lat,
        tel,
        brand,
        gas_type
      )
    }).map(obj=>{
      (obj.poiid,obj)
    })
    gasCompetitorsRdd
  }

  def pathwayCostRank(spark: SparkSession, gasCompetitorsRdd: RDD[(String, GasCompetitor)], max_day: String) = {
    import spark.implicits._
    val lastMonthDay: String = DateUtil.getDateStr(max_day, -30, "")
    val tomorrowDay: String = DateUtil.getDateStr(max_day, 1, "")
    //读取车队信息表 ddjy_ods_dim_team_info
    val teamInfoSql=
      s"""
        |select name from dm_gis.ddjy_ods_dim_team_info where inc_day in(select max(inc_day) from dm_gis.ddjy_ods_dim_team_info) and del_flag=0
        |""".stripMargin
    val teamInfoMap: collection.Map[String, JSONObject] = SparkUtils.getRowToJson(spark, teamInfoSql).map(obj => {
      (obj.getString("name"), obj)
    }).collectAsMap()
    //计算city_distribution
    val vehicleCarrierSql=
      s"""
        |select
        |carrier_id,city,
        |count(1) as city_cnt
        |from dm_gis.dwd_ddjy_clue_vehicle_carrier_di
        |where inc_day>='$lastMonthDay' and inc_day<='$max_day'
        |group by carrier_id,city
        |""".stripMargin
    val vehicleCarrierRdd: RDD[(String, String)] = SparkUtils.getRowToJson(spark, vehicleCarrierSql).groupBy(_.getString("carrier_id")).map(obj => {
      val city_distribution: String = obj._2.toList.sortBy(_.getIntValue("city_cnt")).reverse.map(json => {
        val city: String = json.getString("city")
        val city_cnt: String = json.getString("city_cnt")
        val cityCntConcat: String = city + ":" + city_cnt
        cityCntConcat
      }).mkString("、")
      (obj._1, city_distribution)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("vehicle_carrier车队数量:"+vehicleCarrierRdd.count())
    vehicleCarrierRdd.unpersist()
    val teamInfoBc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(teamInfoMap)
    //计算clue_vehicle_count
    val clueVehicleCountSql=
      s"""
        |select t1.gas_id,t2.carrier_id,
        |count(distinct t2.vehicle) as clue_vehicle_count
        |from
        |(
        |	select clue_id,gas_id
        |	from dm_gis.dwd_ddjy_clue_rel_gas_station_di_month
        |	where inc_day = '$max_day'
        |) t1
        |join
        |(
        |	select clue_id,carrier_id,vehicle
        |	from dm_gis.dm_ddjy_clue_rel_car_di_month
        |	where inc_day = '$max_day'
        |) t2
        |on t1.clue_id = t2.clue_id
        |group by t1.gas_id,t2.carrier_id
        |""".stripMargin
    val clueVehicleCountRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, clueVehicleCountSql).map(obj => {
      val gas_id: String = obj.getString("gas_id")
      val carrier_id: String = obj.getString("carrier_id")
      ((gas_id, carrier_id), obj)
    })
    //计算register_vehicle_count
    val vehicleYySql=
      s"""
        |select owner_id as carrier_id,
        |count(distinct vehicle_no) as register_vehicle_count
        |from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |where inc_day = '$tomorrowDay'
        |group by owner_id
        |""".stripMargin
    val vehicleYyMap: collection.Map[String, JSONObject] = SparkUtils.getRowToJson(spark, vehicleYySql).map(obj => {
      (obj.getString("carrier_id"), obj)
    }).collectAsMap()
    val vehicleYyBc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(vehicleYyMap)
    //计算one_carrier_gas_rank和one_gas_carrier_rank
    val rankSql=
      s"""
         |select
         |gas_id,carrier_id,
         |row_number() over(partition by carrier_id order by task_sum_count desc) as one_carrier_gas_rank,
         |row_number() over(partition by gas_id order by task_sum_count desc) as one_gas_carrier_rank
         |from
         |(
         |	select
         |	gas_id,carrier_id,
         |	sum(task_sum_count) as task_sum_count
         |	from dm_gis.dm_ddjy_gas_carrier_merge_di
         |	where inc_day>='$lastMonthDay' and inc_day<='$max_day'
         |	group by gas_id,carrier_id
         |) t1
         |""".stripMargin
    val rankRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, rankSql,2000).map(obj=>{
      ((obj.getString("gas_id"),obj.getString("carrier_id")),obj)
    })
    //计算carrier_white_list
    val carrierWhiteListSql=
      s"""
         |select company_name from dm_gis.guang_dong_province_white_list_df
         |""".stripMargin
    val carrierWhiteListMap: collection.Map[String, Int] = SparkUtils.getRowToJson(spark, carrierWhiteListSql).map(obj => {
      (obj.getString("company_name"), 1)
    }).collectAsMap()
    val carrierWhiteListBc: Broadcast[collection.Map[String, Int]] = spark.sparkContext.broadcast(carrierWhiteListMap)
    val carrierMergeSql=
      s"""
        |select
        |gas_id,adcode,province,city,district,lng,lat,tel,brand,gas_type,carrier_id,carrier_name,credit_code,legal_person_name,content,city_adcode,carrier_tag,
        |gas_competitors,gas_road_type,gas_road_function_type,clue_dist_avg,carrier_pathway_cost,carrier_circle_id,carrier_scale,carrier_suspected_address,carrier_priority,addr,src,register_vehicle_count,suspected_adcode,
        |stationalias,inc_day,task_batch,
        |case when pathway_task_count is null or pathway_task_count='' or carrier_pathway_cost is null or carrier_pathway_cost='' then ''
        |		 when cast(carrier_pathway_cost as double)>=0 and cast(carrier_pathway_cost as double)<200 then ceiling(pathway_task_count*1)
        |		 when cast(carrier_pathway_cost as double)>=200 and cast(carrier_pathway_cost as double)<500 then ceiling(pathway_task_count*0.75)
        |		 when cast(carrier_pathway_cost as double)>=500 and cast(carrier_pathway_cost as double)<1000 then ceiling(pathway_task_count*0.5)
        |		 when cast(carrier_pathway_cost as double)>=1000 and cast(carrier_pathway_cost as double)<2000 then ceiling(pathway_task_count*0.1)
        |		 when cast(carrier_pathway_cost as double)>=2000 then 0
        |		 end as pathway_cost_task_count,
        |carrier_white_list,circle_task_count,
        |clue_task_count,pathway_task_count,pathway_around_task_count,stay_task_count,task_sum_count
        |from dm_gis.dm_ddjy_gas_carrier_merge_di
        |where inc_day>='$lastMonthDay' and inc_day<='$max_day'
        |""".stripMargin
    val carrierMergeRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, carrierMergeSql,2000)
    //计算carrier_circle_task_count
    val carrierCircleTaskCountMap: collection.Map[String, Double] = carrierMergeRdd.map(obj => {
      ((obj.getString("carrier_circle_id"), obj.getString("inc_day")), obj.getDoubleValue("circle_task_count"))
    }).groupByKey().map(obj => {
      val circle_task_count: Double = obj._2.toList.max
      (obj._1._1, circle_task_count)
    }).groupByKey().map(obj => {
      val circle_task_count: Double = obj._2.toList.sum
      (obj._1, circle_task_count)
    }).collectAsMap()
    val carrierCircleTaskCountBc: Broadcast[collection.Map[String, Double]] = spark.sparkContext.broadcast(carrierCircleTaskCountMap)
    //计算task_batch
    val task_batch_min: String = carrierMergeRdd.map(obj => {
      val task_batch: String = obj.getString("task_batch")
      task_batch
    }).min().split("-")(0)
    val task_batch_max: String = carrierMergeRdd.map(obj => {
      val task_batch: String = obj.getString("task_batch")
      task_batch
    }).max().split("-")(1)

    val carrierMergeMidRdd: RDD[JSONObject] = carrierMergeRdd.map(obj => {
      ((obj.getString("gas_id"), obj.getString("carrier_id")), obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val clue_task_count: Int = list.map(_.getIntValue("clue_task_count")).sum
      val pathway_task_count: Int = list.map(_.getIntValue("pathway_task_count")).sum
      val pathway_around_task_count: Int = list.map(_.getIntValue("pathway_around_task_count")).sum
      val stay_task_count: Int = list.map(_.getIntValue("stay_task_count")).sum
      val task_sum_count: Int = list.map(_.getIntValue("task_sum_count")).sum
      val tmpObj: JSONObject = list.maxBy(_.getString("inc_day"))
      val biz_day: String = tmpObj.getString("inc_day")
      var tag = 0
      if (clue_task_count>=3 || pathway_task_count>=5 || stay_task_count>=3){
        tag=1
      }
      val carrier_tag_arr: List[String] = list.map(_.getString("carrier_tag"))
      var carrier_tag: String = tmpObj.getString("carrier_tag")
      if (carrier_tag_arr.contains("sf_carrier_tag")){
        carrier_tag = "sf_carrier_tag"
      }
      tmpObj.put("biz_day", biz_day)
      tmpObj.put("clue_task_count", clue_task_count)
      tmpObj.put("pathway_task_count", pathway_task_count)
      tmpObj.put("pathway_around_task_count", pathway_around_task_count)
      tmpObj.put("stay_task_count", stay_task_count)
      tmpObj.put("task_sum_count", task_sum_count)
      tmpObj.put("tag", tag)
      tmpObj.put("carrier_tag", carrier_tag)
      tmpObj
    }).map(obj=>{
      ((obj.getString("gas_id"),obj.getString("carrier_id")),obj)
    }).leftOuterJoin(rankRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).map(obj => {
      (obj.getString("gas_id"), obj)
    }).leftOuterJoin(gasCompetitorsRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: GasCompetitor = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("cooperatestatus", rightObj.cooperatestatus)
        leftObj.put("stationname", rightObj.stationname)
        leftObj.put("stationtype", rightObj.stationtype)
        leftObj.put("pricedieselout", rightObj.pricedieselout)
        leftObj.put("adcode", rightObj.adcode)
        leftObj.put("province", rightObj.province)
        leftObj.put("city", rightObj.city)
        leftObj.put("district", rightObj.district)
        leftObj.put("lng", rightObj.lng)
        leftObj.put("lat", rightObj.lat)
        leftObj.put("tel", rightObj.tel)
        leftObj.put("brand", rightObj.brand)
        leftObj.put("gas_type", rightObj.gas_type)
      }
      leftObj
    }).map(obj => {
      val carrier_name: String = obj.getString("carrier_name")
      val teamInfoValue: collection.Map[String, JSONObject] = teamInfoBc.value
      val teamInfoObj: JSONObject = teamInfoValue.getOrElse(carrier_name, null)
      var carrier_status = 0
      if (teamInfoObj != null) {
        carrier_status = 1
      }
      obj.put("carrier_status", carrier_status)
      (obj.getString("carrier_id"), obj)
    }).leftOuterJoin(vehicleCarrierRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val city_distribution: String = obj._2._2.orNull
      leftObj.put("clue_city_distribution", city_distribution)
      ((leftObj.getString("gas_id"), leftObj.getString("carrier_id")), leftObj)
    }).leftOuterJoin(clueVehicleCountRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("clue_vehicle_count", rightObj.getString("clue_vehicle_count"))
      }
      leftObj.put("pathway_vehicle_count", "")
      leftObj.put("pathway_around_vehicle_count", "")
      leftObj.put("stay_vehicle_count", "")
      (leftObj.getString("carrier_circle_id"), leftObj)
      leftObj
    }).map(obj => {
      val carrier_circle_id: String = obj.getString("carrier_circle_id")
      val carrierCircleTaskCountValue: collection.Map[String, Double] = carrierCircleTaskCountBc.value
      val circle_task_count: Double = carrierCircleTaskCountValue.getOrElse(carrier_circle_id, 0.0)
      obj.put("circle_task_count", circle_task_count)
      obj
    }).map(obj => {
      val carrier_id: String = obj.getString("carrier_id")
      val vehicleYyValue: collection.Map[String, JSONObject] = vehicleYyBc.value
      val vehicleYyObj: JSONObject = vehicleYyValue.getOrElse(carrier_id, null)
      if (vehicleYyObj != null) {
        val register_vehicle_count: String = vehicleYyObj.getString("register_vehicle_count")
        obj.put("register_vehicle_count", register_vehicle_count)
      }
      obj
    }).map(obj=>{
      val carrier_name: String = obj.getString("carrier_name")
      val carrierWhiteListValue: collection.Map[String, Int] = carrierWhiteListBc.value
      val tag: Int = carrierWhiteListValue.getOrElse(carrier_name, 0)
      var carrier_white_list = "0"
      if (tag ==1) {
        carrier_white_list = "1"
      }
      obj.put("carrier_white_list", carrier_white_list)
      obj
    }).map(obj => {
      val register_vehicle_count: Int = JSONUtil.getJsonValInt(obj, "register_vehicle_count", -1)
      var carrier_scale = "数据缺失"
      if (register_vehicle_count >= 0 && register_vehicle_count <= 4) {
        carrier_scale = "4及以下"
      } else if (register_vehicle_count >= 5 && register_vehicle_count <= 10) {
        carrier_scale = "5~10"
      } else if (register_vehicle_count >= 11 && register_vehicle_count <= 20) {
        carrier_scale = "11~20"
      } else if (register_vehicle_count >= 21 && register_vehicle_count <= 30) {
        carrier_scale = "21~30"
      } else if (register_vehicle_count >= 31 && register_vehicle_count <= 40) {
        carrier_scale = "31~40"
      } else if (register_vehicle_count >= 41 && register_vehicle_count <= 50) {
        carrier_scale = "41~50"
      } else if (register_vehicle_count > 50) {
        carrier_scale = "50以上"
      }
      obj.put("carrier_scale", carrier_scale)
      obj.put("task_batch", task_batch_min + "-" + task_batch_max)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("车队油站融合表去重关联后数据量:"+carrierMergeMidRdd.count())
    //计算online_gas_top5和online_gas_top10
    val cooperatestatusEqual3Rdd: RDD[JSONObject] = carrierMergeMidRdd.filter(_.getString("cooperatestatus") == "3").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("cooperatestatus==3的数据量:"+cooperatestatusEqual3Rdd.count())
    val stationInfoSql=
      """
        |select poiid,gappricevec,roadname
        |from dm_gis.dm_ddjy_gas_station_info_di
        |where delflag = '0'
        |and stationtype!='12'
        |and querybrandid!='2'
        |""".stripMargin
    val stationInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, stationInfoSql).map(obj => {
      (obj.getString("poiid"), obj)
    })

    val addOnlineGasTop5Map = cooperatestatusEqual3Rdd.repartition(10000).map(obj => {
      (obj.getString("gas_id"), obj)
    }).join(stationInfoRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.put("gappricevec", rightObj.getString("gappricevec"))
      leftObj.put("roadname", rightObj.getString("roadname"))
      leftObj
    }).groupBy(_.getString("carrier_id")).repartition(10000).flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val stationNameConcatList: List[(Double, String,String)] = list.map(json => {
        val stationname: String = json.getString("stationname")
        val roadname: String = json.getString("roadname")
        val gappricevec: String = json.getString("gappricevec")
        var gappricevec_new: String = ""
        if(StringUtils.isNoneEmpty(gappricevec)){
          gappricevec_new = gappricevec.replace("[", "").replace("]", "").split(",")(0).toDouble.formatted("%.2f")
        }
        val task_sum_count: Double = json.getDoubleValue("task_sum_count")
        val stationNameConcat: String = stationname + ":" + roadname + "["+gappricevec_new+"]"
        val stationNameConcat10: String = stationname + "["+gappricevec_new+"]:" + task_sum_count
        (task_sum_count, stationNameConcat,stationNameConcat10)
      }).distinct
      val online_gas_top5: String = stationNameConcatList.sortBy(_._1).reverse.take(5).map(_._2).mkString(";")
      val online_gas_top10: String = stationNameConcatList.sortBy(_._1).reverse.take(10).map(_._3).mkString(";")
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("online_gas_top5", online_gas_top5)
        json.put("online_gas_top10", online_gas_top10)
        json
      })
      tmpList
    }).map(obj => {
      val tmpObj = new JSONObject()
      val carrier_id: String = obj.getString("carrier_id")
      val online_gas_top5: String = obj.getString("online_gas_top5")
      val online_gas_top10: String = obj.getString("online_gas_top10")
      tmpObj.put("carrier_id",carrier_id)
      tmpObj.put("online_gas_top5",online_gas_top5)
      tmpObj.put("online_gas_top10",online_gas_top10)
      (carrier_id,tmpObj)
    }).distinct().collectAsMap()
    logger.error("增加online_gas_top5字段后数据量:"+addOnlineGasTop5Map.size)
    cooperatestatusEqual3Rdd.unpersist()
    /*val carrierMergeMidMapRdd: RDD[(String, JSONObject)] = carrierMergeMidRdd.map(obj => {
      (obj.getString("carrier_id"), obj)
    })*/
    val addOnlineGasTop5Bc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(addOnlineGasTop5Map)
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance.getTime)

    val carrierMergeDf: DataFrame =  carrierMergeMidRdd.map(obj=>{
      val carrier_id: String = obj.getString("carrier_id")
      val addOnlineGasTop5Value: collection.Map[String, JSONObject] = addOnlineGasTop5Bc.value
      val rightObj: JSONObject = addOnlineGasTop5Value.getOrElse(carrier_id, null)
      if (rightObj!=null){
        obj.fluentPutAll(rightObj)
      }
      obj
    }).map(obj => {
      CarrierMerge(
        obj.getString("gas_id"),
        obj.getString("stationname"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperatestatus"),
        obj.getString("tel"),
        obj.getString("brand"),
        obj.getString("gas_type"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("credit_code"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("city_adcode"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("clue_task_count"),
        obj.getString("clue_vehicle_count"),
        obj.getString("pathway_task_count"),
        obj.getString("pathway_vehicle_count"),
        obj.getString("pathway_around_task_count"),
        obj.getString("pathway_around_vehicle_count"),
        obj.getString("stay_task_count"),
        obj.getString("stay_vehicle_count"),
        obj.getString("one_carrier_gas_rank"),
        obj.getString("one_gas_carrier_rank"),
        obj.getString("clue_distribution"),
        obj.getString("clue_city_distribution"),
        obj.getString("pathway_city_distribution"),
        obj.getString("clue_dist_avg"),
        obj.getString("carrier_pathway_cost"),
        update_time,
        obj.getString("task_batch"),
        obj.getString("gas_competitors"),
        obj.getString("gas_road_type"),
        obj.getString("gas_road_function_type"),
        obj.getString("task_sum_count"),
        obj.getString("pathway_cost_task_count"),
        obj.getString("tag"),
        obj.getString("carrier_circle_id"),
        obj.getString("carrier_scale"),
        obj.getString("carrier_suspected_address"),
        obj.getString("carrier_priority"),
        obj.getString("addr"),
        obj.getString("src"),
        obj.getString("circle_task_count"),
        obj.getString("register_vehicle_count"),
        obj.getString("suspected_adcode"),
        obj.getString("online_gas_top5"),
        obj.getString("carrier_white_list"),
        obj.getString("online_gas_top10"),
        obj.getString("stationalias"),
        obj.getString("stationtype"),
        obj.getString("pricedieselout"),
        obj.getString("biz_day")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,carrierMergeDf,"inc_day",max_day,"dm_gis.dm_ddjy_gas_carrier_merge_di_month",50)
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val gas_carrier_merge_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.dm_ddjy_gas_carrier_merge_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val max_day: String = SparkUtils.getRowToJson(spark, gas_carrier_merge_sql).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    //获取油站数据并处理
    val gasCompetitorsRdd: RDD[(String, GasCompetitor)] = stationInfoProcess(spark, max_day)
    //按照途径频次进行排序
    pathwayCostRank(spark,gasCompetitorsRdd,max_day)

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>GasCarrierMergeMonth Execute Ok")
  }


  case class GasCompetitor(poiid: String,
                           stationname: String,
                           cooperatestatus: String,
                           stationtype: String,
                           pricedieselout:String,
                           adcode:String,
                           province:String,
                           city:String,
                           district:String,
                           lng:String,
                           lat:String,
                           tel:String,
                           brand:String,
                           gas_type:String)
  case class CarrierMerge(gas_id:String,
                          stationname:String,
                          adcode:String,
                          province:String,
                          city:String,
                          district:String,
                          lng:String,
                          lat:String,
                          cooperatestatus:String,
                          tel:String,
                          brand:String,
                          gas_type:String,
                          carrier_id:String,
                          carrier_name:String,
                          credit_code:String,
                          legal_person_name:String,
                          content:String,
                          city_adcode:String,
                          carrier_status:String,
                          carrier_tag:String,
                          clue_task_count:String,
                          clue_vehicle_count:String,
                          pathway_task_count:String,
                          pathway_vehicle_count:String,
                          pathway_around_task_count:String,
                          pathway_around_vehicle_count:String,
                          stay_task_count:String,
                          stay_vehicle_count:String,
                          one_carrier_gas_rank:String,
                          one_gas_carrier_rank:String,
                          clue_distribution:String,
                          clue_city_distribution:String,
                          pathway_city_distribution:String,
                          clue_dist_avg:String,
                          carrier_pathway_cost:String,
                          update_time:String,
                          task_batch:String,
                          gas_competitors:String,
                          gas_road_type:String,
                          gas_road_function_type:String,
                          task_sum_count:String,
                          pathway_cost_task_count:String,
                          tag:String,
                          carrier_circle_id:String,
                          carrier_scale:String,
                          carrier_suspected_address:String,
                          carrier_priority:String,
                          addr:String,
                          src:String,
                          circle_task_count:String,
                          register_vehicle_count:String,
                          suspected_adcode:String,
                          online_gas_top5:String,
                          carrier_white_list:String,
                          online_gas_top10:String,
                          stationalias:String,
                          stationtype:String,
                          pricedieselout:String,
                          biz_day:String
                         )

}
