package app

import java.util

import com.alibaba.druid.support.json.JSONUtils
import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.reflect.ClassTag

/**
 * @Description:车队业务分布
 * 需求方：左佳怡 01403789
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:481
 * 任务名称：车队业务分布统计表
 * 依赖任务：粤运车辆经过油站频次表 422、顺丰车辆经过油站频次表 555
 * 数据源：ddjy_vehicle_clue_detail_di、ddjy_pathway_statistic_join_vehicle_concat_di、dm_ddjy_carrier_rlst_di
 * 调用服务地址：
 * 数据结果：ddjy_carteam_business_distribution
 */
object VehicleBusinessDistribution {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def yyVehicleDistribution(spark: SparkSession, max_day: String) = {
    import spark.implicits._
    val tomorrow: String = DateUtil.getDateStr(max_day, 1, "")
    //详情1
    val details1Sql=
      s"""
        |select
        |car_team_id,city,sumcount,sumdist,checi,srcid,checi
        |from
        |(
        |	select
        |	t1.car_team_id,t1.city,sumcount,sumdist*0.001 as sumdist,checi,srcid,
        |	row_number() over(partition by t1.car_team_id,t1.city order by sumcount desc,linklength desc) as rnk
        |	from
        |	(
        |		select car_team_id,city,linklength,srcid,
        |		sum(`count`) over(partition by car_team_id,city,srcid,linklength) as sumcount,
        |		sum(dist) over(partition by car_team_id,city) as sumdist
        |		from dm_gis.ddjy_vehicle_clue_detail_di
        |		where inc_day='$max_day' and source ='yy'
        |	) t1
        |	left join
        |	(
        |		select car_team_id,city,
        |		count(distinct trackno) as checi
        |		from dm_gis.ddjy_vehicle_clue_detail_di
        |		where inc_day='$max_day' and source ='yy'
        |		group by car_team_id,city
        |	) t0
        |	on t1.car_team_id=t0.car_team_id and t1.city=t0.city
        |) t2
        |where rnk=1
        |""".stripMargin
    val details1Df: DataFrame = spark.sql(details1Sql)
    logger.error(details1Sql)
    val details1AggDf = SparkUtils.getDfToJson(spark, details1Df).map(obj=>{
      val car_team_id: String = obj.getString("car_team_id")
      (car_team_id,obj)
    }).groupByKey().map(f = obj => {
      val list: List[JSONObject] = obj._2.toList
      val sortList: List[JSONObject] = list.sortWith((x, y) =>{
        val x_sumcount: Double = JSONUtil.getJsonDouble(x, "sumcount", 0.0)
        val y_sumcount: Double = JSONUtil.getJsonDouble(y, "sumcount", 0.0)
        val x_sumdist: Double = JSONUtil.getJsonDouble(x, "sumdist", 0.0)
        val y_sumdist: Double = JSONUtil.getJsonDouble(y, "sumdist", 0.0)
        val x_checi: Double = JSONUtil.getJsonDouble(x, "checi", 0.0)
        val y_checi: Double = JSONUtil.getJsonDouble(y, "checi", 0.0)
        if (x_sumcount > y_sumcount) {
          true
        } else  {
          if (x_sumcount<y_sumcount){
            false
          }else{
            if (x_sumdist > y_sumdist) {
              true
            } else {
              if(x_sumdist < y_sumdist){
                false
              }else{
                if (x_checi > y_checi) {
                  true
                } else {
                  false
                }
              }
            }
          }
        }
      })
      val city_distribution_array = new ArrayBuffer[String]()
      for (elem <- sortList) {
        val city: String = elem.getString("city")
        val sumcount: String = elem.getString("sumcount")
        val srcid: String = elem.getString("srcid")
        val sumdist: String = elem.getString("sumdist")
        val checi: String = elem.getString("checi")
        val city_distribution = city + "(" + sumcount + "," + srcid + "," + sumdist + "," + checi + ")"
        city_distribution_array.append(city_distribution)
      }
      val city_distribution_frequency: String = city_distribution_array.mkString("|")
      (obj._1, city_distribution_frequency)
    }).toDF("car_team_id","city_distribution_frequency").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情1数据量："+details1AggDf.count())
    details1AggDf.createOrReplaceTempView("details1Tmp")
    //详情2
    val details2Sql=
      s"""
         |select
         |car_team_id,road_name,roadclass,sumcount,sumdist,srcid
         |from
         |(
         |	select
         |	car_team_id,road_name,roadclass,sumcount,sumdist*0.001 as sumdist,srcid,
         |	row_number() over(partition by car_team_id,road_name order by sumcount desc,linklength desc,roadclass asc) as rnk
         |	from
         |	(
         |		select car_team_id,road_name,roadclass,srcid,linklength,
         |		sum(`count`) over(partition by car_team_id,road_name,srcid,linklength) as sumcount,
         |		sum(dist) over(partition by car_team_id,road_name) as sumdist
         |		from dm_gis.ddjy_vehicle_clue_detail_di
         |		where inc_day='$max_day' and source ='yy'
         |	) t1
         |) t2
         |where rnk=1
         |""".stripMargin
    val details2Df: DataFrame = spark.sql(details2Sql)
    val details2AggDf: DataFrame = SparkUtils.getDfToJson(spark, details2Df).map(obj => {
      val car_team_id: String = obj.getString("car_team_id")
      (car_team_id, obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val sortList: List[JSONObject] = list.sortWith((x, y) => {
        val x_sumdist: Double = JSONUtil.getJsonDouble(x, "sumdist", 0.0)
        val y_sumdist: Double = JSONUtil.getJsonDouble(y, "sumdist", 0.0)
        val x_sumcount: Double = JSONUtil.getJsonDouble(x, "sumcount", 0.0)
        val y_sumcount: Double = JSONUtil.getJsonDouble(y, "sumcount", 0.0)
        val x_roadclass: Double = JSONUtil.getJsonDouble(x, "roadclass", Int.MaxValue)
        val y_roadclass: Double = JSONUtil.getJsonDouble(y, "roadclass", Int.MaxValue)
        if (x_sumdist > y_sumdist) {
          true
        } else {
          if (x_sumdist < y_sumdist) {
            false
          } else {
            if (x_sumcount > y_sumcount) {
              true
            } else {
              if (x_sumcount < y_sumcount) {
                false
              } else {
                if (x_roadclass < y_roadclass) {
                  true
                } else {
                  false
                }
              }
            }
          }
        }
      })
      val road_distribution_array = new ArrayBuffer[String]()
      for (elem <- sortList) {
        val road_name: String = elem.getString("road_name")
        val roadclass: String = elem.getString("roadclass")
        val sumcount: String = elem.getString("sumcount")
        val srcid: String = elem.getString("srcid")
        val sumdist: String = elem.getString("sumdist")
        val road_distribution = road_name + "(" + roadclass + "," + sumcount + "," + srcid + "," + sumdist + ")"
        road_distribution_array.append(road_distribution)
      }
      val road_distribution_frequency: String = road_distribution_array.mkString("|")
      (obj._1, road_distribution_frequency)
    }).toDF("car_team_id", "road_distribution_frequency").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情2数据量："+details2AggDf.count())
    details2AggDf.createOrReplaceTempView("details2Tmp")
    //详情3
    val details3Sql=
      s"""
         |select
         |car_team_id,stationname,poiid,province,city,coords,sumpriority_tj
         |from
         |(
         |	select
         |	car_team_id,stationname,poiid,province,city,coords,
         |	sum(priority_tj) as sumpriority_tj
         |	from dm_gis.ddjy_pathway_statistic_join_vehicle_concat_di
         |  where source ='yy'
         |	group  by car_team_id,stationname,poiid,province,city,coords
         |) t1
         |where sumpriority_tj is not null and sumpriority_tj!=0
         |""".stripMargin
    val details3Df: DataFrame = spark.sql(details3Sql)
    val details3AggDf: DataFrame = SparkUtils.getDfToJson(spark, details3Df).map(obj => {
      val car_team_id: String = obj.getString("car_team_id")
      (car_team_id, obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val sortList: List[JSONObject] = list.sortBy(json => {
        JSONUtil.getJsonDouble(json, "sumpriority_tj", 0.0)
      }).reverse
      val oil_distribution_array = new ArrayBuffer[String]()
      for (elem <- sortList) {
        val stationname: String = elem.getString("stationname")
        val sumpriority_tj: String = elem.getString("sumpriority_tj")
        val province: String = elem.getString("province")
        val city: String = elem.getString("city")
        val poiid: String = elem.getString("poiid")
        val coords: String = elem.getString("coords")
        val oil_distribution = stationname + "(" + sumpriority_tj + "," + province + "," + city + "," + poiid +","+ coords + ")"
        oil_distribution_array.append(oil_distribution)
      }
      val oil_distribution_frequency: String = oil_distribution_array.mkString("|")
      (obj._1, oil_distribution_frequency)
    }).toDF("car_team_id", "oil_distribution_frequency").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情3数据量："+details3AggDf.count())
    details3AggDf.createOrReplaceTempView("details3Tmp")
    //详情4
    val details4Sql=
      s"""
         |select
         |car_team_id,stationname,poiid,province,city,coords,sumpriority_zb
         |from
         |(
         |	select
         |	car_team_id,stationname,poiid,province,city,coords,
         |	sum(priority_zb) as sumpriority_zb
         |	from dm_gis.ddjy_pathway_statistic_join_vehicle_concat_di
         |  where source='yy'
         |	group by car_team_id,stationname,poiid,province,city,coords
         |) t1
         |where sumpriority_zb is not null and sumpriority_zb!=0
         |""".stripMargin
    val details4Df: DataFrame = spark.sql(details4Sql)
    val details4AggDf: DataFrame = SparkUtils.getDfToJson(spark, details4Df).map(obj => {
      val car_team_id: String = obj.getString("car_team_id")
      (car_team_id, obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val sortList: List[JSONObject] = list.sortBy(json => {
        val sumpriority_zb: Double = JSONUtil.getJsonDouble(json, "sumpriority_zb", 0.0)
        sumpriority_zb
      }).reverse
      val around_oil_distribution_array = new ArrayBuffer[String]()
      for (elem <- sortList) {
        val stationname: String = elem.getString("stationname")
        val sumpriority_zb: String = elem.getString("sumpriority_zb")
        val province: String = elem.getString("province")
        val city: String = elem.getString("city")
        val poiid: String = elem.getString("poiid")
        val coords: String = elem.getString("coords")
        val around_oil_distribution = stationname + "(" + sumpriority_zb + "," + province + "," + city + "," + poiid +","+ coords + ")"
        around_oil_distribution_array.append(around_oil_distribution)
      }
      val around_oil_distribution_frequency: String = around_oil_distribution_array.mkString("|")
      (obj._1, around_oil_distribution_frequency)
    }).toDF("car_team_id", "around_oil_distribution_frequency").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情4数据量："+details4AggDf.count())
    details4AggDf.createOrReplaceTempView("details4Tmp")
    //关联合并字段
    val vehivcleClueStatisticSql=
      s"""
         |select
         |t1.car_team_id,car_team_name,
         |city_distribution_frequency,
         |road_distribution_frequency,
         |oil_distribution_frequency,
         |around_oil_distribution_frequency,
         |stay_city_distribution,
         |stay_jsd_distribution,
         |'yy' as source
         |from
         |(
         |select car_team_id,car_team_name
         |from dm_gis.ddjy_vehicle_clue_detail_di
         |where inc_day='${max_day}' and source='yy'
         |group by car_team_id,car_team_name
         |)t1
         |left join details1Tmp t2
         |on t1.car_team_id=t2.car_team_id
         |left join details2Tmp t3
         |on t1.car_team_id=t3.car_team_id
         |left join details3Tmp t4
         |on t1.car_team_id=t4.car_team_id
         |left join details4Tmp t5
         |on t1.car_team_id=t5.car_team_id
         |left join
         |(
         |	select carrier_id,
         |	city_distribution as stay_city_distribution,
         |	clue_distribution as stay_jsd_distribution
         |	from dm_gis.dm_ddjy_carrier_rlst_di
         |	where inc_day = '${max_day}'
         |  group by carrier_id,city_distribution,clue_distribution
         |) t6
         |on t1.car_team_id=t6.carrier_id
         |""".stripMargin
    val yyVehivcleClueStatisticDf: DataFrame = spark.sql(vehivcleClueStatisticSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("粤运车辆线索统计结果表数据量："+yyVehivcleClueStatisticDf.count())
    yyVehivcleClueStatisticDf
  }

  def sfVehicleDistribution(spark: SparkSession, max_day: String) = {
    import spark.implicits._
    //详情1
    val details1Sql=
      s"""
         |select
         |car_team_name,city,sumcount,sumdist,checi,srcid,checi
         |from
         |(
         |	select
         |	t1.car_team_name,t1.city,sumcount,sumdist*0.001 as sumdist,checi,srcid,
         |	row_number() over(partition by t1.car_team_name,t1.city order by sumcount desc,linklength desc) as rnk
         |	from
         |	(
         |		select car_team_name,city,linklength,srcid,
         |		sum(`count`) over(partition by car_team_name,city,srcid,linklength) as sumcount,
         |		sum(dist) over(partition by car_team_name,city) as sumdist
         |		from dm_gis.ddjy_vehicle_clue_detail_di
         |		where inc_day='$max_day' and source ='sf'
         |	) t1
         |	left join
         |	(
         |		select car_team_name,city,
         |		count(distinct trackno) as checi
         |		from dm_gis.ddjy_vehicle_clue_detail_di
         |		where inc_day='$max_day' and source ='sf'
         |		group by car_team_name,city
         |	) t0
         |	on t1.car_team_name=t0.car_team_name and t1.city=t0.city
         |) t2
         |where rnk=1
         |""".stripMargin
    val details1Df: DataFrame = spark.sql(details1Sql)
    val details1AggDf = SparkUtils.getDfToJson(spark, details1Df).map(obj=>{
      val car_team_name: String = obj.getString("car_team_name")
      (car_team_name,obj)
    }).groupByKey().map(f = obj => {
      val list: List[JSONObject] = obj._2.toList
      val sortList: List[JSONObject] = list.sortWith((x, y) =>{
        val x_sumcount: Double = JSONUtil.getJsonDouble(x, "sumcount", 0.0)
        val y_sumcount: Double = JSONUtil.getJsonDouble(y, "sumcount", 0.0)
        val x_sumdist: Double = JSONUtil.getJsonDouble(x, "sumdist", 0.0)
        val y_sumdist: Double = JSONUtil.getJsonDouble(y, "sumdist", 0.0)
        val x_checi: Double = JSONUtil.getJsonDouble(x, "checi", 0.0)
        val y_checi: Double = JSONUtil.getJsonDouble(y, "checi", 0.0)
        if (x_sumcount > y_sumcount) {
          true
        } else  {
          if (x_sumcount<y_sumcount){
            false
          }else{
            if (x_sumdist > y_sumdist) {
              true
            } else {
              if(x_sumdist < y_sumdist){
                false
              }else{
                if (x_checi > y_checi) {
                  true
                } else {
                  false
                }
              }
            }
          }
        }
      })
      val city_distribution_array = new ArrayBuffer[String]()
      for (elem <- sortList) {
        val city: String = elem.getString("city")
        val sumcount: String = elem.getString("sumcount")
        val srcid: String = elem.getString("srcid")
        val sumdist: String = elem.getString("sumdist")
        val checi: String = elem.getString("checi")
        val city_distribution = city + "(" + sumcount + "," + srcid + "," + sumdist + "," + checi + ")"
        city_distribution_array.append(city_distribution)
      }
      val city_distribution_frequency: String = city_distribution_array.mkString("|")
      (obj._1, city_distribution_frequency)
    }).toDF("car_team_name","city_distribution_frequency").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情1数据量："+details1AggDf.count())
    details1AggDf.createOrReplaceTempView("details1Tmp")
    //详情2
    val details2Sql=
      s"""
         |select
         |car_team_name,road_name,roadclass,sumcount,sumdist,srcid
         |from
         |(
         |	select
         |	car_team_name,road_name,roadclass,sumcount,sumdist*0.001 as sumdist,srcid,
         |	row_number() over(partition by car_team_name,road_name order by sumcount desc,linklength desc,roadclass asc) as rnk
         |	from
         |	(
         |		select car_team_name,road_name,roadclass,srcid,linklength,
         |		sum(`count`) over(partition by car_team_name,road_name,srcid,linklength) as sumcount,
         |		sum(dist) over(partition by car_team_name,road_name) as sumdist
         |		from dm_gis.ddjy_vehicle_clue_detail_di
         |		where inc_day='$max_day' and source ='sf'
         |	) t1
         |) t2
         |where rnk=1
         |""".stripMargin
    val details2Df: DataFrame = spark.sql(details2Sql)
    val details2AggDf: DataFrame = SparkUtils.getDfToJson(spark, details2Df).map(obj => {
      val car_team_name: String = obj.getString("car_team_name")
      (car_team_name, obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val sortList: List[JSONObject] = list.sortWith((x, y) => {
        val x_sumdist: Double = JSONUtil.getJsonDouble(x, "sumdist", 0.0)
        val y_sumdist: Double = JSONUtil.getJsonDouble(y, "sumdist", 0.0)
        val x_sumcount: Double = JSONUtil.getJsonDouble(x, "sumcount", 0.0)
        val y_sumcount: Double = JSONUtil.getJsonDouble(y, "sumcount", 0.0)
        val x_roadclass: Double = JSONUtil.getJsonDouble(x, "roadclass", Int.MaxValue)
        val y_roadclass: Double = JSONUtil.getJsonDouble(y, "roadclass", Int.MaxValue)
        if (x_sumdist > y_sumdist) {
          true
        } else {
          if (x_sumdist < y_sumdist) {
            false
          } else {
            if (x_sumcount > y_sumcount) {
              true
            } else {
              if (x_sumcount < y_sumcount) {
                false
              } else {
                if (x_roadclass < y_roadclass) {
                  true
                } else {
                  false
                }
              }
            }
          }
        }
      })
      val road_distribution_array = new ArrayBuffer[String]()
      for (elem <- sortList) {
        val road_name: String = elem.getString("road_name")
        val roadclass: String = elem.getString("roadclass")
        val sumcount: String = elem.getString("sumcount")
        val srcid: String = elem.getString("srcid")
        val sumdist: String = elem.getString("sumdist")
        val road_distribution = road_name + "(" + roadclass + "," + sumcount + "," + srcid + "," + sumdist + ")"
        road_distribution_array.append(road_distribution)
      }
      val road_distribution_frequency: String = road_distribution_array.mkString("|")
      (obj._1, road_distribution_frequency)
    }).toDF("car_team_name", "road_distribution_frequency").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情2数据量："+details2AggDf.count())
    details2AggDf.createOrReplaceTempView("details2Tmp")
    //详情3
    val details3Sql=
      s"""
         |select
         |car_team_name,stationname,poiid,province,city,coords,sumpriority_tj
         |from
         |(
         |	select
         |	car_team_name,stationname,poiid,province,city,coords,
         |	sum(priority_tj) as sumpriority_tj
         |	from dm_gis.ddjy_pathway_statistic_join_vehicle_concat_di
         |  where source ='sf'
         |	group  by car_team_name,stationname,poiid,province,city,coords
         |) t1
         |where sumpriority_tj is not null and sumpriority_tj!=0
         |""".stripMargin
    val details3Df: DataFrame = spark.sql(details3Sql)
    val details3AggDf: DataFrame = SparkUtils.getDfToJson(spark, details3Df).map(obj => {
      val car_team_name: String = obj.getString("car_team_name")
      (car_team_name, obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val sortList: List[JSONObject] = list.sortBy(json => {
        JSONUtil.getJsonDouble(json, "sumpriority_tj", 0.0)
      }).reverse
      val oil_distribution_array = new ArrayBuffer[String]()
      for (elem <- sortList) {
        val stationname: String = elem.getString("stationname")
        val sumpriority_tj: String = elem.getString("sumpriority_tj")
        val province: String = elem.getString("province")
        val city: String = elem.getString("city")
        val poiid: String = elem.getString("poiid")
        val coords: String = elem.getString("coords")
        val oil_distribution = stationname + "(" + sumpriority_tj + "," + province + "," + city + "," + poiid +","+ coords + ")"
        oil_distribution_array.append(oil_distribution)
      }
      val oil_distribution_frequency: String = oil_distribution_array.mkString("|")
      (obj._1, oil_distribution_frequency)
    }).toDF("car_team_name", "oil_distribution_frequency").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情3数据量："+details3AggDf.count())
    details3AggDf.createOrReplaceTempView("details3Tmp")
    //详情4
    val details4Sql=
      s"""
         |select
         |car_team_name,stationname,poiid,province,city,coords,sumpriority_zb
         |from
         |(
         |	select
         |	car_team_name,stationname,poiid,province,city,coords,
         |	sum(priority_zb) as sumpriority_zb
         |	from dm_gis.ddjy_pathway_statistic_join_vehicle_concat_di
         |  where source='sf'
         |	group by car_team_name,stationname,poiid,province,city,coords
         |) t1
         |where sumpriority_zb is not null and sumpriority_zb!=0
         |""".stripMargin
    val details4Df: DataFrame = spark.sql(details4Sql)
    val details4AggDf: DataFrame = SparkUtils.getDfToJson(spark, details4Df).map(obj => {
      val car_team_name: String = obj.getString("car_team_name")
      (car_team_name, obj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val sortList: List[JSONObject] = list.sortBy(json => {
        val sumpriority_zb: Double = JSONUtil.getJsonDouble(json, "sumpriority_zb", 0.0)
        sumpriority_zb
      }).reverse
      val around_oil_distribution_array = new ArrayBuffer[String]()
      for (elem <- sortList) {
        val stationname: String = elem.getString("stationname")
        val sumpriority_zb: String = elem.getString("sumpriority_zb")
        val province: String = elem.getString("province")
        val city: String = elem.getString("city")
        val poiid: String = elem.getString("poiid")
        val coords: String = elem.getString("coords")
        val around_oil_distribution = stationname + "(" + sumpriority_zb + "," + province + "," + city + "," + poiid +","+ coords + ")"
        around_oil_distribution_array.append(around_oil_distribution)
      }
      val around_oil_distribution_frequency: String = around_oil_distribution_array.mkString("|")
      (obj._1, around_oil_distribution_frequency)
    }).toDF("car_team_name", "around_oil_distribution_frequency").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("详情4数据量："+details4AggDf.count())
    details4AggDf.createOrReplaceTempView("details4Tmp")
    //关联合并字段
    val vehivcleClueStatisticSql=
      s"""
         |select
         |car_team_id,t1.car_team_name,
         |city_distribution_frequency,
         |road_distribution_frequency,
         |oil_distribution_frequency,
         |around_oil_distribution_frequency,
         |stay_city_distribution,
         |stay_jsd_distribution,
         |'sf' as source
         |from
         |(
         |select car_team_id,car_team_name
         |from dm_gis.ddjy_vehicle_clue_detail_di
         |where inc_day='${max_day}' and source='sf'
         |group by car_team_id,car_team_name
         |)t1
         |left join details1Tmp t2
         |on t1.car_team_name=t2.car_team_name
         |left join details2Tmp t3
         |on t1.car_team_name=t3.car_team_name
         |left join details3Tmp t4
         |on t1.car_team_name=t4.car_team_name
         |left join details4Tmp t5
         |on t1.car_team_name=t5.car_team_name
         |left join
         |(
         |	select carrier_name,
         |	city_distribution as stay_city_distribution,
         |	clue_distribution as stay_jsd_distribution
         |	from dm_gis.dm_ddjy_carrier_rlst_di
         |	where inc_day = '${max_day}'
         |  group by carrier_name,city_distribution,clue_distribution
         |) t6
         |on t1.car_team_name=t6.carrier_name
         |""".stripMargin
    val sfVehivcleClueStatisticDf: DataFrame = spark.sql(vehivcleClueStatisticSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("顺丰车辆线索统计结果表数据量："+sfVehivcleClueStatisticDf.count())
    sfVehivcleClueStatisticDf
  }

  def unionSfYyVehicleDistribution(spark: SparkSession, yyVehivcleClueStatisticDf: DataFrame, sfVehivcleClueStatisticDf: DataFrame, max_day: String) = {
    val vehivcleClueStatisticDf: DataFrame = yyVehivcleClueStatisticDf.union(sfVehivcleClueStatisticDf).toDF()
    vehivcleClueStatisticDf.createOrReplaceTempView("vehivcleClueStatisticTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_carteam_business_distribution partition(inc_day='${max_day}') select * from vehivcleClueStatisticTmp")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取分区最大值
    val vehicle_clue_detail_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.ddjy_vehicle_clue_detail_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val vehicle_clue_detail_df: DataFrame = spark.sql(vehicle_clue_detail_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, vehicle_clue_detail_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    //粤运数据计算
    val yyVehivcleClueStatisticDf: DataFrame = yyVehicleDistribution(spark, max_day)
    //顺丰数据计算
    val sfVehivcleClueStatisticDf: DataFrame = sfVehicleDistribution(spark, max_day)
    //顺丰和粤运数据合并
    unionSfYyVehicleDistribution(spark,yyVehivcleClueStatisticDf,sfVehivcleClueStatisticDf,max_day)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    //execute()
    logger.error("======>>>>>>VehicleBusinessDistribution Execute Ok")
  }
}
