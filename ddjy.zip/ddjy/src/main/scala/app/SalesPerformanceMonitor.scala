package app

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:销售业绩监控表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:833
 * 任务名称：销售业绩监控表new
 * 依赖任务：
 * 数据源：
 * 调用服务地址：无
 * 数据结果：
 * 迭代需求 2216653  销售业绩监控情况表-数据侧_V1.7 caiguofang  01420395  20270117
 */
object SalesPerformanceMonitor {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def salesPerformance(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String,other_day:String) = {
    //userid维度
    val useridSql=
      s"""
       |select
       |sup_code,sub_code,t0.user_id,month,gmv_target,new_customer_target,
       |gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
       |sup_name,sub_name,user_name,
       |new_customer_id_daily,fisrt_consumed_id_daily,
       |month_active_vehicle_cnt,week_active_vehicle_cnt,month_active_team_cnt,week_active_team_cnt,new_pay_customer_gmv_daily,sign_customer_id_daily
       |from
       |(
       |	select
       |	sup_code,sub_code,user_id,month,gmv_target,new_customer_target
       |	from
       |	(
       |		select
       |		sup_code,sub_code,
       |		outer_id as user_id,
       |		substr('${inc_day}',0,6) as month,
       |		month_trade_target as gmv_target,
       |		sign_target as new_customer_target,
       |		row_number() over(partition by outer_id order by update_date desc) as rnk
       |		from dm_gis.ddjy_sales_target_df
       |		where inc_day='${inc_day}' and month=substr('${other_day}',0,7)
       |		and type='0'
       |		and name not like '%测试%'
       |		and org_name not like '%测试%'
       |	) t0_1
       |	where rnk=1
       |) t0
       |left join
       |(
       |	select
       |	user_id,
       |	sum(if(deleted='0', team_ft_sale_money, null)) as gmv_daily,
       |	count(distinct if(deleted='0', t3.car_team_id, null)) as new_customer_daily,
       |	concat_ws(',',collect_set(if(deleted='0', t2.car_team_id, null))) as consumed_id_daily,
       |	count(distinct if(min_first_pay_date='${inc_day}' and deleted='0',t4.car_team_id,null)) as fisrt_consumed_daily,
       |	count(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}' and rn=1,t1.team_id,null)) as sign_customer_daily,
       |  concat_ws(',',collect_set(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}' and rn=1,t1.team_id,null))) as sign_customer_id_daily,
       |	sum(if(deleted='0', team_total_sales,null)) as new_customer_gmv_daily,
       |	concat_ws(',',collect_set(if(deleted='0', t3.car_team_id,null))) as new_customer_id_daily,
       |	concat_ws(',',collect_set(if(min_first_pay_date='${inc_day}',t4.car_team_id,null))) as fisrt_consumed_id_daily,
       |	sum(if(deleted='0', t6_1.new_carplate_cnt,null)) as month_active_vehicle_cnt,
       |	sum(if(deleted='0', t6_2.new_carplate_cnt,null)) as week_active_vehicle_cnt,
       |	count(distinct if(deleted='0', t6_1.car_team_id,null)) as month_active_team_cnt,
       |	count(distinct if(deleted='0', t6_2.car_team_id,null)) as week_active_team_cnt,
       |	sum(if(substr(min_first_pay_date,0,6)=substr('${inc_day}',0,6) and deleted='0' ,t4.total_sales,null)) as new_pay_customer_gmv_daily
       |	from
       |	(
       |		select
       |		user_id,team_id,create_date,deleted,team_id_cnt,rn
       |		from
       |		(
       |			select
       |			user_id,team_id,create_date,deleted,
       |			count(team_id) over(partition by team_id) as team_id_cnt,
       |      row_number () over(partition by team_id  order by  create_date  asc) as rn
       |			from dm_gis.ddjy_ods_sales_team
       |			where inc_day='${inc_day}'
       |		) t1_1
       |	) t1
       |	left join
       |	(
       |		select
       |		car_team_id,
       |		sum(ft_sale_money) as team_ft_sale_money
       |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
       |		where inc_day='${inc_day}'
       |		and order_status='2'
       |		group by car_team_id
       |	) t2
       |	on t1.team_id=t2.car_team_id
       |	left join
       |	(
       |		select
       |		car_team_id
       |		from dm_gis.ddjy_dwd_station_stream_detail
       |		where inc_day='${inc_day}'
       |		and date_format(first_trade_date,'yyyyMMdd')='${inc_day}'
       |		group by car_team_id
       |	) t3
       |	on t1.team_id=t3.car_team_id
       |	left join
       |	(
       |		select
       |		car_team_id,
       |		sum(total_sales) as total_sales,
       |		date_format(min(first_pay_date),'yyyyMMdd') as min_first_pay_date
       |		from dm_gis.ddjy_dwd_station_stream_detail
       |		where inc_day='${inc_day}'
       |		group by car_team_id
       |	) t4
       |	on t1.team_id=t4.car_team_id
       |	left join
       |	(
       |		select
       |		car_team_id,
       |		sum(total_sales)  as team_total_sales
       |		from dm_gis.ddjy_dwd_station_stream_detail
       |		where inc_day='${inc_day}'
       |		and date_format(first_trade_date,'yyyyMM')=substr('${inc_day}',0,6)
       |		group by car_team_id
       |	) t5
       |	on t1.team_id=t5.car_team_id
       |	left join
       |	(
       |		select
       |		car_team_id,
       |		count(distinct if(new_carplate is null or new_carplate='',driver_phone,new_carplate)) as new_carplate_cnt
       |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
       |		where inc_day<='${inc_day}' and substr(inc_day,0,6)=substr('${inc_day}',0,6)
       |		group by car_team_id
       |	) t6_1
       |	on t1.team_id=t6_1.car_team_id
       |	left join
       |	(
       |		select
       |		car_team_id,
       |		count(distinct if(new_carplate is null or new_carplate='',driver_phone,new_carplate)) as new_carplate_cnt
       |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
       |		where inc_day>='${last_seven_day}' and inc_day<='${inc_day}'
       |		group by car_team_id
       |	) t6_2
       |	on t1.team_id=t6_2.car_team_id
       |	group by user_id
       |) t6
       |on t0.user_id=t6.user_id
       |left join
       |(
       |	select
       |	user_id,sup_name,sub_name,user_name
       |	from dm_gis.ddjy_ods_sales_info
       |	where inc_day='${inc_day}'
       |) t7
       |on t0.user_id=t7.user_id
       |""".stripMargin
    logger.error(useridSql)
    val useridDf: DataFrame = spark.sql(useridSql)
    useridDf.createOrReplaceTempView("useridTmp")

    //supcode维度
    val supcodeDf: DataFrame = spark.sql(
      s"""
         |select
         |t0.sup_code,sub_code,user_id,month,gmv_target,new_customer_target,
         |gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
         |sup_name,
         |'' as sub_name,
         |'' as user_name,
         |new_customer_id_daily,fisrt_consumed_id_daily,
         |month_active_vehicle_cnt,week_active_vehicle_cnt,month_active_team_cnt,week_active_team_cnt,new_pay_customer_gmv_daily,sign_customer_id_daily
         |from
         |(
         |	select
         |	sup_code,sub_code,user_id,month,gmv_target,new_customer_target
         |	from
         |	(
         |		select
         |		sup_code,
         |		'' as sub_code,
         |		'' as user_id,
         |		substr('${inc_day}',0,6) as month,
         |		month_trade_target as gmv_target,
         |		sign_target as new_customer_target,
         |		row_number() over(partition by outer_id order by update_date desc) as rnk
         |		from dm_gis.ddjy_sales_target_df
         |		where inc_day='${inc_day}' and month=substr('${other_day}',0,7)
         |		and type='1' and org_level='1'
         |		and name not like '%测试%'
         |		and org_name not like '%测试%'
         |	) t0_1
         |	where rnk=1
         |) t0
         |left join
         |(
         |	select
         |	sup_code,
         |	sum(if(deleted='0',team_ft_sale_money,null)) as gmv_daily,
         |	count(distinct if(deleted='0',t3.car_team_id, null)) as new_customer_daily,
         |	concat_ws(',',collect_set(if(deleted='0',t2.car_team_id, null))) as consumed_id_daily,
         |	count(distinct if(min_first_pay_date='${inc_day}' and deleted='0',t4.car_team_id,null)) as fisrt_consumed_daily,
         |  count(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}' and rn=1,t1.team_id,null)) as sign_customer_daily,
         |  concat_ws(',',collect_set(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}' and rn=1,t1.team_id,null))) as sign_customer_id_daily,
         |	sum(if(deleted='0',team_total_sales,null)) as new_customer_gmv_daily,
         |	concat_ws(',',collect_set(if(deleted='0',t3.car_team_id,null))) as new_customer_id_daily,
         |	concat_ws(',',collect_set(if(min_first_pay_date='${inc_day}' and deleted ='0',t4.car_team_id,null))) as fisrt_consumed_id_daily,
         |	sum(if(deleted='0',t6_1.new_carplate_cnt,null )) as month_active_vehicle_cnt,
         |	sum(if(deleted='0',t6_2.new_carplate_cnt,null )) as week_active_vehicle_cnt,
         |	count(distinct if(deleted='0',t6_1.car_team_id,null )) as month_active_team_cnt,
         |	count(distinct if(deleted='0',t6_2.car_team_id,null )) as week_active_team_cnt,
         |	sum(if(substr(min_first_pay_date,0,6)=substr('${inc_day}',0,6) and deleted='0',t4.total_sales,null)) as new_pay_customer_gmv_daily
         |	from
         |	(
         |		select
         |		sup_code,team_id,create_date,team_id_cnt, rn,deleted
         |		from
         |		(
         |			select
         |			sup_code,team_id,create_date,deleted,
         |			count(team_id) over(partition by team_id) as team_id_cnt,
         |			row_number() over(partition by team_id order by create_date asc) as rn
         |			from dm_gis.ddjy_ods_sales_team
         |			where inc_day='${inc_day}'
         |		) t1_1
         |	) t1
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(ft_sale_money) as team_ft_sale_money
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day='${inc_day}'
         |		and order_status='2'
         |		group by car_team_id
         |	) t2
         |	on t1.team_id=t2.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMMdd')='${inc_day}'
         |		group by car_team_id
         |	) t3
         |	on t1.team_id=t3.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(total_sales) as total_sales,
         |		date_format(min(first_pay_date),'yyyyMMdd') as min_first_pay_date
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		group by car_team_id
         |	) t4
         |	on t1.team_id=t4.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(total_sales)  as team_total_sales
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMM')=substr('${inc_day}',0,6)
         |		group by car_team_id
         |	) t5
         |	on t1.team_id=t5.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		count(distinct if(new_carplate is null or new_carplate='',driver_phone,new_carplate)) as new_carplate_cnt
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day<='${inc_day}' and substr(inc_day,0,6)=substr('${inc_day}',0,6)
         |		group by car_team_id
         |	) t6_1
         |	on t1.team_id=t6_1.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		count(distinct if(new_carplate is null or new_carplate='',driver_phone,new_carplate)) as new_carplate_cnt
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day>='${last_seven_day}' and inc_day<='${inc_day}'
         |		group by car_team_id
         |	) t6_2
         |	on t1.team_id=t6_2.car_team_id
         |	group by sup_code
         |) t6
         |on t0.sup_code=t6.sup_code
         |left join
         |(
         |	select
         |	sup_code,sup_name
         |	from dm_gis.ddjy_ods_sales_info
         |	where inc_day='${inc_day}'
         |  group by sup_code,sup_name
         |) t7
         |on t0.sup_code=t7.sup_code
         |""".stripMargin)
    supcodeDf.createOrReplaceTempView("supcodeTmp")


    //subcode维度
    val subcodeDf: DataFrame = spark.sql(
      s"""
         |select
         |sup_code,t0.sub_code,user_id,month,gmv_target,new_customer_target,
         |gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
         |sup_name,
         |sub_name,
         |'' as user_name,
         |new_customer_id_daily,fisrt_consumed_id_daily,
         |month_active_vehicle_cnt,week_active_vehicle_cnt,month_active_team_cnt,week_active_team_cnt,new_pay_customer_gmv_daily,sign_customer_id_daily
         |from
         |(
         |	select
         |	sup_code,sub_code,user_id,month,gmv_target,new_customer_target
         |	from
         |	(
         |		select
         |		sup_code,
         |		sub_code,
         |		'' as user_id,
         |		substr('${inc_day}',0,6) as month,
         |		month_trade_target as gmv_target,
         |		sign_target as new_customer_target,
         |		row_number() over(partition by outer_id order by update_date desc) as rnk
         |		from dm_gis.ddjy_sales_target_df
         |		where inc_day='${inc_day}' and month=substr('${other_day}',0,7)
         |		and type='1' and org_level='2'
         |		and name not like '%测试%'
         |		and org_name not like '%测试%'
         |	) t0_1
         |	where rnk=1
         |) t0
         |left join
         |(
         |	select
         |	sub_code,
         |	sum(if(deleted = '0',team_ft_sale_money, null)) as gmv_daily,
         |	count(distinct if(deleted = '0',t3.car_team_id,null)) as new_customer_daily,
         |	concat_ws(',',collect_set(if(deleted = '0',t2.car_team_id,null))) as consumed_id_daily,
         |	count(distinct if(min_first_pay_date='${inc_day}' and  deleted ='0',t4.car_team_id,null)) as fisrt_consumed_daily,
         |	count(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}' and rn=1,t1.team_id,null)) as sign_customer_daily,
         |  concat_ws(',',collect_set(distinct if(date_format(create_date,'yyyyMMdd')='${inc_day}' and rn=1,t1.team_id,null))) as sign_customer_id_daily,
         |	sum(if(deleted = '0',team_total_sales,null)) as new_customer_gmv_daily,
         |	concat_ws(',',collect_set(if(deleted = '0',t3.car_team_id,null))) as new_customer_id_daily,
         |	concat_ws(',',collect_set(if(min_first_pay_date='${inc_day}' and deleted ='0',t4.car_team_id,null))) as fisrt_consumed_id_daily,
         |	sum(if(deleted = '0',t6_1.new_carplate_cnt,null)) as month_active_vehicle_cnt,
         |	sum(if(deleted = '0',t6_2.new_carplate_cnt,null)) as week_active_vehicle_cnt,
         |	count(distinct if(deleted = '0',t6_1.car_team_id,null)) as month_active_team_cnt,
         |	count(distinct if(deleted = '0',t6_2.car_team_id,null)) as week_active_team_cnt,
         |	sum(if(substr(min_first_pay_date,0,6)=substr('${inc_day}',0,6) and deleted ='0',t4.total_sales,null)) as new_pay_customer_gmv_daily
         |	from
         |	(
         |		select
         |		sub_code,team_id,create_date,deleted,rn
         |		from
         |		(
         |			select
         |			sub_code,team_id,create_date,deleted,
         |			count(team_id) over(partition by team_id) as team_id_cnt,
         |			row_number() over(partition by team_id order by create_date asc) as rn
         |			from dm_gis.ddjy_ods_sales_team
         |			where inc_day='${inc_day}'
         |		) t1_1
         |	) t1
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(ft_sale_money) as team_ft_sale_money
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day='${inc_day}'
         |		and order_status='2'
         |		group by car_team_id
         |	) t2
         |	on t1.team_id=t2.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMMdd')='${inc_day}'
         |		group by car_team_id
         |	) t3
         |	on t1.team_id=t3.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(total_sales) as total_sales,
         |		date_format(min(first_pay_date),'yyyyMMdd') as min_first_pay_date
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		group by car_team_id
         |	) t4
         |	on t1.team_id=t4.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		sum(total_sales)  as team_total_sales
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		and date_format(first_trade_date,'yyyyMM')=substr('${inc_day}',0,6)
         |		group by car_team_id
         |	) t5
         |	on t1.team_id=t5.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		count(distinct if(new_carplate is null or new_carplate='',driver_phone,new_carplate)) as new_carplate_cnt
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day<='${inc_day}' and substr(inc_day,0,6)=substr('${inc_day}',0,6)
         |		group by car_team_id
         |	) t6_1
         |	on t1.team_id=t6_1.car_team_id
         |	left join
         |	(
         |		select
         |		car_team_id,
         |		count(distinct if(new_carplate is null or new_carplate='',driver_phone,new_carplate)) as new_carplate_cnt
         |		from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |		where inc_day>='${last_seven_day}' and inc_day<='${inc_day}'
         |		group by car_team_id
         |	) t6_2
         |	on t1.team_id=t6_2.car_team_id
         |	group by sub_code
         |) t6
         |on t0.sub_code=t6.sub_code
         |left join
         |(
         |	select
         |	sup_name,sub_code,sub_name
         |	from dm_gis.ddjy_ods_sales_info
         |	where inc_day='${inc_day}'
         |  and deleted='0'
         |	group by sup_name,sub_code,sub_name
         |) t7
         |on t0.sub_code=t7.sub_code
         |""".stripMargin)
    subcodeDf.createOrReplaceTempView("subcodeTmp")
    //总维度
    val allDf: DataFrame = spark.sql(
      s"""
         |select
         |'' as sup_code,
         |'' as sub_code,
         |'' as user_id,
         |substr('${inc_day}',0,6) as month,
         |'' as gmv_target,
         |'' as new_customer_target,
         |gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
         |'' as sup_name,
         |'' as sub_name,
         |'' as user_name,
         |new_customer_id_daily,fisrt_consumed_id_daily,
         |month_active_vehicle_cnt,week_active_vehicle_cnt,month_active_team_cnt,week_active_team_cnt,new_pay_customer_gmv_daily,sign_customer_id_daily
         |from
         |(
         |	select
         |	count(distinct team_id) as sign_customer_daily,
         |  concat_ws(',',collect_set(team_id)) as sign_customer_id_daily
         |	from
         |	(
         |		select
         |		id,create_date,team_id,deleted,
         |		row_number() over(partition by team_id order by create_date asc) as rn
         |		from dm_gis.ddjy_ods_sales_team
         |		where inc_day='${inc_day}'
         |		and user_name not like '%测试%'
         |		and user_name not like '%产品%'
         |		and user_name not like '%张楠%'
         |		and user_name not like '%李晗%'
         |		and user_name not like '%刘芮%'
         |		and user_name not like '%火全%'
         |		and sub_code!='LIZHI'
         |		and sup_name not like '%测试%'
         |	) t1_1
         |	where date_format(create_date,'yyyyMMdd')='${inc_day}' and rn=1
         |) t1
         |left join
         |(
         |	select
         |	sum(ft_sale_money) as gmv_daily,
         |	concat_ws(',',collect_set(car_team_id)) as consumed_id_daily
         |	from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |	where inc_day='${inc_day}'
         |	and order_status='2'
         |) t2
         |on 1=1
         |left join
         |(
         |	select
         |	count(distinct car_team_id) as new_customer_daily,
         |	concat_ws(',',collect_set(car_team_id)) as new_customer_id_daily
         |	from dm_gis.ddjy_dwd_station_stream_detail
         |	where inc_day='${inc_day}'
         |	and date_format(first_trade_date,'yyyyMMdd')='${inc_day}'
         |) t3
         |on 1=1
         |left join
         |(
         |	select
         |	count(distinct if(min_first_pay_date='${inc_day}',car_team_id,null)) as fisrt_consumed_daily,
         |	concat_ws(',',collect_set(if(min_first_pay_date='${inc_day}',car_team_id,null))) as fisrt_consumed_id_daily,
         |	sum(if(substr(min_first_pay_date,0,6)=substr('${inc_day}',0,6),total_sales,null)) as new_pay_customer_gmv_daily
         |	from
         |	(
         |		select
         |		car_team_id,
         |    sum(total_sales) as total_sales,
         |		date_format(min(first_pay_date),'yyyyMMdd') as min_first_pay_date
         |		from dm_gis.ddjy_dwd_station_stream_detail
         |		where inc_day='${inc_day}'
         |		group by car_team_id
         |	) t4_1
         |) t4
         |on 1=1
         |left join
         |(
         |	select
         |	sum(total_sales) as new_customer_gmv_daily
         |	from dm_gis.ddjy_dwd_station_stream_detail
         |	where inc_day='${inc_day}'
         |	and date_format(first_trade_date,'yyyyMM')=substr('${inc_day}',0,6)
         |) t5
         |on 1=1
         |left join
         |(
         |	select
         |	count(distinct if(new_carplate is null or new_carplate='',driver_phone,new_carplate)) as month_active_vehicle_cnt,
         |	count(distinct car_team_id) as month_active_team_cnt
         |	from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |	where inc_day<='${inc_day}' and substr(inc_day,0,6)=substr('${inc_day}',0,6)
         |) t6_1
         |on 1=1
         |left join
         |(
         |	select
         |	count(distinct if(new_carplate is null or new_carplate='',driver_phone,new_carplate)) as week_active_vehicle_cnt,
         |	count(distinct car_team_id) as week_active_team_cnt
         |	from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |	where inc_day>='${last_seven_day}' and inc_day<='${inc_day}'
         |) t6_2
         |on 1=1
         |""".stripMargin)
    allDf.createOrReplaceTempView("allTmp")

    val performanceSql=
      s"""
        |select
        |sup_code,sub_code,user_id,month,gmv_target,new_customer_target,gmv_daily,new_customer_daily,consumed_id_daily,fisrt_consumed_daily,sign_customer_daily,new_customer_gmv_daily,
        |sup_name,sub_name,user_name,type,new_customer_id_daily,fisrt_consumed_id_daily,
        |month_active_vehicle_cnt,week_active_vehicle_cnt,month_active_team_cnt,week_active_team_cnt,new_pay_customer_gmv_daily,sign_customer_id_daily
        |from
        |(
        |	select
        |	*,'1' as type
        |	from supcodeTmp
        |	union all
        |	select
        |	*,'2' as type
        |	from subcodeTmp
        |	union all
        |	select
        |	*,'3' as type
        |	from useridTmp
        | union all
        |	select
        |	*,'0' as type
        |	from allTmp
        |)  t1
        |where user_name not like '%测试%'
        |and user_name not like '%产品%'
        |and user_name not like '%张楠%'
        |and user_name not like '%李晗%'
        |and user_name not like '%刘芮%'
        |and user_name not like '%火全%'
        |and sub_code!='LIZHI'
        |and sup_name not like '%测试%'
        |""".stripMargin
    val performanceDf: DataFrame = spark.sql(performanceSql)
    performanceDf.repartition(1).createOrReplaceTempView("performanceTmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_sales_performance_monitor_di partition(inc_day='${inc_day}') select * from performanceTmp")
    logger.error("写入ddjy_sales_performance_monitor_di每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String,dates:Int) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    for (i <- (0 to dates).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      val other_day: String = DateUtil.changeDateSep(incDay, "", "-")
      salesPerformance(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day,other_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val dates: Int = args(1).toInt
    execute(inc_day,dates)
    //execute()
    logger.error("======>>>>>>销售业绩监控表 Execute Ok")
  }

}
