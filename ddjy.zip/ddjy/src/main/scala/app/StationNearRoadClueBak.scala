package app

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DistanceUtils, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{PointArea, SfNetInteface, SparkWrite}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * @Description:油站周边道路线索挖掘
 * 需求方：刘芮 01412988
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:421
 * 任务名称：油站周边道路线索
 * 依赖任务：
 * 数据源：ddjy_station_near_road_clue_di
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0&adcode=1:440000&excludeDel=1
 *             http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/qRoad?ak=%s&x1=%s&y1=%s&x2=%s&y2=%s&toll=0&inner=0&furniture=0&fw2=0&poi=0&exprIndex=-1&mask=35&gzip=0&output=json&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED
 *             http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s
 * 数据结果：ddjy_station_near_road_clue_di
 */
object StationNearRoadClueBak {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def stationInterface(spark: SparkSession, incDay: String) = {
    val last_seven_day: String = DateUtil.getDateStr(incDay, -7, "")
    val stationUrl="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0&adcode=1:440000&excludeDel=1"
    //val payload="{}"
    //val headers="{}"
    //val finalUrl: String = stationUrl.format(payload,headers)
    val retObj: JSONObject = HttpInvokeUtil.httpGetJSON(stationUrl,3)
    val data = retObj.getJSONArray("data").toArray()
      //.take(10)
    val finalStationInfoRdd: RDD[JSONObject] = spark.sparkContext.parallelize(data).map(obj=>{
      val tmpObj: JSONObject = obj.asInstanceOf[JSONObject]
      tmpObj
    }).filter(obj=>{
      obj.getInteger("delFlag")==0
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取油站数据量："+finalStationInfoRdd.count())

    val stationNearRoadSql=
      s"""
        |select *
        |from dm_gis.ddjy_station_near_road_clue_di
        |where inc_day='${last_seven_day}'
        |""".stripMargin
    val stationNearRoadDf: DataFrame = spark.sql(stationNearRoadSql)
    val stationNearRoadAllRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, stationNearRoadDf)
    val stationNearRoadRdd: RDD[(String, JSONObject)] = stationNearRoadAllRdd.map(obj => {
      (obj.getString("poiid"), obj)
    })
    val joinStationNearRoadRdd: RDD[(JSONObject, JSONObject)] = finalStationInfoRdd
      .map(obj => {
      (obj.getString("POIID"), obj)
    }).fullOuterJoin(stationNearRoadRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1.orNull
      val rightObj: JSONObject = obj._2._2.orNull
      (leftObj, rightObj)
    })
    val zeroStateRdd: RDD[JSONObject] = joinStationNearRoadRdd.filter(obj => {
      val leftObj: JSONObject = obj._1
      val rightObj: JSONObject = obj._2
      leftObj == null && rightObj != null
    }).map(obj => {
      obj._2.put("state", "0")
      obj._2
    })
    val notUpdateStationRdd: RDD[JSONObject] = joinStationNearRoadRdd.filter(obj => {
      val leftObj: JSONObject = obj._1
      val rightObj: JSONObject = obj._2
      leftObj != null && rightObj != null
    }).map(obj => {
      obj._2
    })
    val finalStationInfoMapRdd: RDD[(String, JSONObject)] = finalStationInfoRdd.map(obj => {
      (obj.getString("POIID"), obj)
    })
    val notUpdateStationInfoRdd: RDD[JSONObject] = zeroStateRdd.union(notUpdateStationRdd).map(obj=>{
      (obj.getString("poiid"),obj)
    }).leftOuterJoin(finalStationInfoMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("stationname",rightObj.getString("stationName"))
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("不需要调接口油站信息数据量："+notUpdateStationInfoRdd.count())
    val needUpdateStationRdd: RDD[JSONObject] = joinStationNearRoadRdd.filter(obj => {
      val leftObj: JSONObject = obj._1
      val rightObj: JSONObject = obj._2
      leftObj != null && rightObj == null
    }).map(obj => {
      obj._1
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("需要调接口油站信息数据量："+needUpdateStationRdd.count())
    /*val stationDf: DataFrame = needUpdateStationRdd.map(obj => {
      StationInfoTest(
        obj.getString("GRPID"),
        obj.getString("PID"),
        obj.getString("POIID"),
        obj.getString("srcId"),
        obj.getString("stationName"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("adcode"),
        obj.getString("district"),
        obj.getString("addr"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperateStatus")
      )
    }).toDF()
    stationDf.createOrReplaceTempView("stationTmp")
    spark.sql("insert overwrite table dm_gis.ddjy_station_info_test select * from stationTmp")*/
    //(notUpdateStationInfoRdd,needUpdateStationRdd)
    (notUpdateStationInfoRdd,needUpdateStationRdd)
  }

  def getStationArea(spark: SparkSession, stationInfoRdd: RDD[JSONObject], incDay: String) = {
    val stationSquareRdd: RDD[JSONObject] = stationInfoRdd.map(obj => {
      try{
        val lng: Double = obj.getDouble("lng")
        val lat: Double = obj.getDouble("lat")
        val minMaxSquare: ((Double, Double), (Double, Double)) = PointArea.getQuyu(lng, lat)
        val minlng: Double = minMaxSquare._1._1
        val minlat: Double = minMaxSquare._1._2
        val maxlng: Double = minMaxSquare._2._1
        val maxlat: Double = minMaxSquare._2._2
        obj.put("minlng", minlng)
        obj.put("minlat", minlat)
        obj.put("maxlng", maxlng)
        obj.put("maxlat", maxlat)
      } catch {
        case _: Exception =>
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取正方形区域后数据量："+stationSquareRdd.count())
    stationSquareRdd
  }

  def getSquareSwid(spark: SparkSession, stationSquareRdd: RDD[JSONObject], incDay: String) = {
    val httpSwid = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "421", "油站周边道路线索", "获取油站周边道路信息和swid", "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/qRoad?ak=%s&x1=%s&y1=%s&x2=%s&y2=%s&toll=0&inner=0&furniture=0&fw2=0&poi=0&exprIndex=-1&mask=35&gzip=0&output=json&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED", "539535c1183b44b6b0d7828375881f5a", stationSquareRdd.count(), 1)

    val returnStationSwidRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,stationSquareRdd, SfNetInteface.swidInterface, 1, "539535c1183b44b6b0d7828375881f5a", 5000)
    returnStationSwidRdd.take(10).foreach(println(_))
    val stationSwidRdd: RDD[JSONObject] = returnStationSwidRdd.repartition(200).flatMap(obj => {
      val lines: JSONArray = JSONUtil.getJsonArrayMulti(obj, "api_result.lines")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until (lines.size())) {
        val tmpObj = new JSONObject()
        tmpObj.fluentPutAll(obj)
        val lineObj: JSONObject = lines.getJSONObject(i)
        val swID: String = lineObj.getString("swID")
        val roadClass: String = lineObj.getString("roadClass")
        val length: String = lineObj.getString("length")
        val FC: String = lineObj.getString("FC")
        val formway: String = lineObj.getString("formway")
        val polyline: JSONArray = lineObj.getJSONArray("polyline")
        var x: Double = 0
        var y: Double = 0
        var origin_x: Double = 0
        var origin_y: Double = 0
        val points = new ArrayBuffer[String]()
        for (i <- 0 until (polyline.size())) {
          val polylineObj: JSONObject = polyline.getJSONObject(i)
          origin_x = polylineObj.getDoubleValue("x") + origin_x
          origin_y = polylineObj.getDoubleValue("y") + origin_y
          x = origin_x / 3600000
          y = origin_y / 3600000
          val xAndY: String = x + " " + y
          points.append(xAndY)
        }
        val pointsStr: String = points.mkString(",")
        val geolinkpoint: String = "LINESTRING(" + pointsStr + ")"
        val startpos: JSONObject = JSONUtil.getJSONObject(lineObj, "startpos")
        val star_point = new JSONObject()
        val startpos_x: Double = startpos.getDoubleValue("x") / 3600000
        val startpos_y: Double = startpos.getDoubleValue("y") / 3600000
        star_point.put("x", startpos_x)
        star_point.put("y", startpos_y)
        val endpos: JSONObject = JSONUtil.getJSONObject(lineObj, "endpos")
        val end_point = new JSONObject()
        val endpos_x: Double = endpos.getDoubleValue("x") / 3600000
        val endpos_y: Double = endpos.getDoubleValue("y") / 3600000
        end_point.put("x", endpos_x)
        end_point.put("y", endpos_y)
        tmpObj.put("swID", swID)
        tmpObj.put("swid_roadClass", roadClass)
        tmpObj.put("length", length)
        tmpObj.put("FC", FC)
        tmpObj.put("formway", formway)
        tmpObj.put("geolinkpoint", geolinkpoint)
        tmpObj.put("star_point", star_point)
        tmpObj.put("end_point", end_point)
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    }).filter(obj=>{
      val swid_roadClass: String = obj.getString("swid_roadClass")
      val roadClass: String = obj.getString("roadClass")
      !((swid_roadClass=="0" &&  roadClass!="0") || (swid_roadClass!="0" &&  roadClass=="0"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取经纬度区间范围内的所有swid后数据量："+stationSwidRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpSwid)

    stationSwidRdd
  }

  def navigateDistanceInterface(spark: SparkSession, stationSwidRdd: RDD[JSONObject], incDay: String) = {
    val startPointRdd: RDD[JSONObject] = stationSwidRdd.map(obj => {
      val star_point_x: String = obj.getJSONObject("star_point").getString("x")
      val star_point_y: String = obj.getJSONObject("star_point").getString("y")
      obj.put("belong_x", star_point_x)
      obj.put("belong_y", star_point_y)
      obj
    })
    val httpStartNormalPlan = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "421", "油站周边道路线索", "获取坐标之间的规划距离", "http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s&type=0&cc=1&strategy=0&opt=sf2&passport=100000&tolls=1&test=0&stype=0&etype=0&pathCount=1&rarefy=0&fencedist=50&merge=4&fixedroute=2", "f086106db05b48e6b8cb103ead38d06a", startPointRdd.count(), 50)

    val returnStartDisRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,startPointRdd, SfNetInteface.normalPlanInterfaceStation, 50, "f086106db05b48e6b8cb103ead38d06a", 20000)
    returnStartDisRdd.take(10).foreach(println(_))

    val endPointRdd: RDD[JSONObject] = returnStartDisRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val dist: String = result.getString("dist")
      obj.remove("api_result")
      obj.put("star_dist", dist)
      val end_point_x: String = obj.getJSONObject("end_point").getString("x")
      val end_point_y: String = obj.getJSONObject("end_point").getString("y")
      obj.put("belong_x", end_point_x)
      obj.put("belong_y", end_point_y)
      obj
    })

    val returnEndDisRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,endPointRdd, SfNetInteface.normalPlanInterfaceStation, 50, "f086106db05b48e6b8cb103ead38d06a", 20000)
    returnEndDisRdd.take(10).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpStartNormalPlan)

    val pointStationDisRdd: RDD[JSONObject] = returnEndDisRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val dist: String = result.getString("dist")
      obj.remove("api_result")
      obj.put("end_dist", dist)
      val end_point_x: Double = obj.getJSONObject("end_point").getDoubleValue("x")
      val end_point_y: Double = obj.getJSONObject("end_point").getDoubleValue("y")
      val lng: Double = obj.getDoubleValue("lng")
      val lat: Double = obj.getDoubleValue("lat")
      val line_dist: Double = DistanceUtils.getDistance(end_point_x, end_point_y, lng, lat)
      obj.put("line_dist", line_dist)
      obj
    })

    val stationStartPointRdd: RDD[JSONObject] = pointStationDisRdd.map(obj => {
      val lng: String = obj.getString("lng")
      val lat: String = obj.getString("lat")
      val star_point_x: String = obj.getJSONObject("star_point").getString("x")
      val star_point_y: String = obj.getJSONObject("star_point").getString("y")
      obj.put("x1", lng)
      obj.put("y1", lat)
      obj.put("x2", star_point_x)
      obj.put("y2", star_point_y)
      obj
    })
    val returnStationStartDisRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,stationStartPointRdd, SfNetInteface.normalPlanInterface2, 50, "f086106db05b48e6b8cb103ead38d06a", 20000)
    returnStationStartDisRdd.take(10).foreach(println(_))
    val stationEndPointRdd: RDD[JSONObject] = returnStationStartDisRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val dist: String = result.getString("dist")
      obj.remove("api_result")
      obj.put("star_dist_back", dist)
      val end_point_x: String = obj.getJSONObject("end_point").getString("x")
      val end_point_y: String = obj.getJSONObject("end_point").getString("y")
      obj.put("x2", end_point_x)
      obj.put("y2", end_point_y)
      obj
    })
    val returnStationEndDisRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,stationEndPointRdd, SfNetInteface.normalPlanInterface2, 50, "f086106db05b48e6b8cb103ead38d06a", 20000)
    returnStationEndDisRdd.take(10).foreach(println(_))
    val stationPointDisRdd: RDD[JSONObject] = returnStationEndDisRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val dist: String = result.getString("dist")
      obj.remove("api_result")
      obj.put("end_dist_back", dist)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("计算油站和始终点距离后数据量："+stationPointDisRdd.count())
    stationPointDisRdd
  }

  def versionAndInsertStationRoadTable(spark: SparkSession, pointStationDisRdd: RDD[JSONObject],oldStationInfoRdd: RDD[JSONObject], incDay: String) = {
    import spark.implicits._
    val cal = Calendar.getInstance
    val time = cal.getTime
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time)
    //val versionUrl="http://10.202.43.227:8170/about?"
    //val retStr: String = HttpGetUtil.httpGetJSON(versionUrl, 3)
    //val buildTime: String = retStr.split("<buildTime>")(1)
    //logger.error("版本:"+retStr)
    //logger.error("buildTime:"+buildTime)
    val buildTime: String = ""
    val pointStationDisDf: DataFrame = pointStationDisRdd.map(obj => {
      obj.put("buildTime", buildTime)
      obj
    }).map(obj => {
      StationRoad(
        obj.getString("GRPID"),
        obj.getString("PID"),
        obj.getString("POIID"),
        obj.getString("srcId"),
        obj.getString("stationName"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("adcode"),
        obj.getString("district"),
        obj.getString("addr"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperateStatus"),
        obj.getString("swID"),
        obj.getString("swid_roadClass"),
        obj.getString("length"),
        obj.getString("FC"),
        obj.getString("formway"),
        obj.getString("geolinkpoint"),
        obj.getString("star_point"),
        obj.getString("end_point"),
        obj.getString("star_dist"),
        obj.getString("end_dist"),
        obj.getString("line_dist"),
        obj.getString("state"),
        obj.getString("buildTime"),
        update_time,
        obj.getString("star_dist_back"),
        obj.getString("end_dist_back"),
        obj.getString("roadClass")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    val oldStationInfoDf: DataFrame = oldStationInfoRdd.map(obj => {
      StationRoad(
        obj.getString("grpid"),
        obj.getString("pid"),
        obj.getString("poiid"),
        obj.getString("srcid"),
        obj.getString("stationname"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("citycode"),
        obj.getString("district"),
        obj.getString("addr"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("cooperatestatus"),
        obj.getString("swid"),
        obj.getString("roadclass"),
        obj.getString("length"),
        obj.getString("fc"),
        obj.getString("formway"),
        obj.getString("geolinkpoint"),
        obj.getString("star_point"),
        obj.getString("end_point"),
        obj.getString("star_dist"),
        obj.getString("end_dist"),
        obj.getString("line_dist"),
        obj.getString("state"),
        obj.getString("buildtime"),
        update_time,
        obj.getString("star_dist_back"),
        obj.getString("end_dist_back"),
        obj.getString("station_roadclass")
      )
    }).toDF()
    val allStationInfoDf: DataFrame = oldStationInfoDf.union(pointStationDisDf).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("写入结果表数据量："+allStationInfoDf.count())
    SparkWrite.writeToHive(spark,allStationInfoDf,"inc_day",incDay,"dm_gis.ddjy_station_near_road_clue_di")


    //allStationInfoDf.createOrReplaceTempView("allStationInfoTmp")
    //logger.error("写入结果表数据量："+pointStationDisDf.count())
    //pointStationDisDf.createOrReplaceTempView("allStationInfoTmp")
    //spark.sql(s"insert overwrite table dm_gis.ddjy_station_near_road_clue_di partition(inc_day='$incDay') select * from allStationInfoTmp")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取全量油站
    val (oldStationInfoRdd,needUpdateStationInfoRdd): (RDD[JSONObject], RDD[JSONObject]) = stationInterface(spark, incDay)
    //获取油站周边500m区间经纬度（正方形区间）
    val stationSquareRdd: RDD[JSONObject] = getStationArea(spark, needUpdateStationInfoRdd, incDay)
    //获取经纬度区间范围内的所有swid
    val stationSwidRdd: RDD[JSONObject] = getSquareSwid(spark, stationSquareRdd, incDay)
    //计算swid的起终点距油站的导航距离和终点距油站的直线距离
    val pointStationDisRdd: RDD[JSONObject] = navigateDistanceInterface(spark, stationSwidRdd, incDay)
    //获取底图的版本号并插入油站绑定道路表
    versionAndInsertStationRoadTable(spark,pointStationDisRdd,oldStationInfoRdd,incDay)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    //execute()
    logger.error("======>>>>>>StationNearRoadClue Execute Ok")
  }
  case class StationRoad(
                          GRPID:String,
                          PID:String,
                          POIID:String,
                          srcId:String,
                          stationName:String,
                          province:String,
                          city:String,
                          cityCode:String,
                          district:String,
                          addr:String,
                          lng:String,
                          lat:String,
                          cooperateStatus:String,
                          swid:String,
                          roadClass:String,
                          length:String,
                          FC:String,
                          formway:String,
                          geolinkpoint:String,
                          star_point:String,
                          end_point:String,
                          star_dist:String,
                          end_dist:String,
                          line_dist:String,
                          state:String,
                          buildTime:String,
                          update_time:String,
                          star_dist_back:String,
                          end_dist_back:String,
                          station_roadclass:String
                        )
}
