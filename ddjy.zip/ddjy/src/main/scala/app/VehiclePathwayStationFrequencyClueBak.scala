package app

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DistanceUtils, HttpInvokeUtil}
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import pojo.StationRoad
import utils.PointArea

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * @Description:车辆途径油站频次线索挖掘(粤运或顺丰)
 * 需求方：刘芮 01412988
 * @Author: lixiangzhi 01405644
 * @Date: 14:13 2022/12/21
 * 任务id:422、555
 * 任务名称：粤运车辆经过油站频次表、顺丰车辆经过油站频次表
 * 依赖任务：经验库stat_swid_count mysql导入hive 475、顺丰经验库stat_swid_count mysql导入hive 553
 * 数据源：ddjy_stat_swid_count、ddjy_station_near_road_clue_di、ddjy_stat_swid_count_sf_wi
 * 调用服务地址：
 * 数据结果：ddjy_station_pathway_statistic_clue_di、ddjy_station_pathway_statistic_clue_sf_di
 */
object VehiclePathwayStationFrequencyClueBak {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def linkidCountSwid(spark: SparkSession, incDay: String,inputTable:String) = {
    val joinLinkidCountSwidSql=
      s"""
        |select
        |rid,trackno,swid,count as priority
        |from $inputTable
        |where inc_day='${incDay}'
        |""".stripMargin
    val joinLinkidCountSwidDf: DataFrame = spark.sql(joinLinkidCountSwidSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("关联linkidCount和swid后数据量："+joinLinkidCountSwidDf.count())
    joinLinkidCountSwidDf
  }

  def stationRoadFrequency(spark: SparkSession, joinLinkidCountSwidDf: DataFrame, incDay: String,outputTable:String) = {
    joinLinkidCountSwidDf.createOrReplaceTempView("joinLinkidCountSwidTmp")
    val joinStationNearRoadSql=
      s"""
        |select
        |t1.*,trackno,priority,
        |sum(priority) over(partition by poiid,trackno,t1.swid) as sum_priority
        |from
        |(
        |	select
        |	*,
        |	if(cast(end_dist as double)>cast(star_dist as double)-cast(length as double),cast(star_dist as double)-cast(length as double),cast(end_dist as double)) as dh_dist,
        |	if(cast(star_dist_back as double)>cast(end_dist_back as double)-cast(length as double),cast(end_dist_back as double)-cast(length as double),cast(star_dist_back as double)) as dh_dist_back
        |	from dm_gis.ddjy_station_near_road_clue_di
        |	where inc_day='${incDay}'
        |) t1
        |left join joinLinkidCountSwidTmp t2
        |on t1.swid=t2.swid
        |""".stripMargin
    val joinStationNearRoadDf: DataFrame = spark.sql(joinStationNearRoadSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站周边道路和经验库道路段关联后数据量："+joinStationNearRoadDf.count())
    joinStationNearRoadDf.createOrReplaceTempView("joinStationNearRoadTmp")
    //spark.sql(s"insert overwrite table dm_gis.ddjy_mid_station_pathway_statistic_clue_di select * from joinStationNearRoadTmp")
    val insertStationPathwaySql=
      s"""
        |insert overwrite table $outputTable partition(inc_day='$incDay')
        |select
        |grpid,pid,t2.poiid,srcid,stationname,province,city,citycode,district,addr,lng,lat,cooperatestatus,
        |t2.trackno,priority_tj,priority_zb,line_dist,
        |dh_dist,
        |dh_dist_back,
        |dh_dist_sum
        |from
        |(
        |	select
        |	grpid,pid,poiid,srcid,stationname,province,city,citycode,district,addr,lng,lat,cooperatestatus,
        |	trackno,line_dist,dh_dist,dh_dist_back,dh_dist_sum,
        |	sum_priority as priority_zb
        |	from
        |	(
        |		select *,
        |		row_number() over(partition by poiid,trackno order by sum_priority desc,dh_dist asc) as rnk
        |		from
        |		(
        |			select
        |			grpid,pid,poiid,srcid,stationname,province,city,citycode,district,addr,lng,lat,cooperatestatus,
        |			trackno,line_dist,sum_priority,
        |			if(dh_dist<0,0,dh_dist) as dh_dist,
        |			if(dh_dist_back<0,0,dh_dist_back) as dh_dist_back,
        |			nvl(if(dh_dist<0,0,dh_dist),0)+nvl(if(dh_dist_back<0,0,dh_dist_back),0) as dh_dist_sum
        |			from
        |			(
        |				select *,
        |				row_number() over(partition by poiid,trackno order by sum_priority desc,dh_dist_back asc) as rnk
        |				from joinStationNearRoadTmp
        |				where cast(line_dist as double)<500
        |			) c1
        |			where c1.rnk=1
        |		) c2
        |		where cast(line_dist as double)<500 and dh_dist_sum<2000
        |	) b1
        |	where b1.rnk=1
        |) t2
        |left join
        |(
        |	select
        |	poiid,trackno,sum_priority as priority_tj
        |	from
        |	(
        |		select *,
        |		row_number() over(partition by poiid,trackno order by sum_priority desc,dh_dist asc) as rnk
        |		from joinStationNearRoadTmp
        |		where cast(line_dist as double)<150 and dh_dist<200
        |	) a1
        |	where a1.rnk=1
        |) t3
        |on t2.poiid=t3.poiid and t2.trackno=t3.trackno
        |where t2.trackno is not null
        |""".stripMargin
    spark.sql(insertStationPathwaySql)
  }

  def execute(incDay: String,inputTable:String,outputTable:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //获取linkdiCount表和swid映射表
    val joinLinkidCountSwidDf: DataFrame = linkidCountSwid(spark, incDay,inputTable)
    //统计加油站绑定道路的途径频次
    stationRoadFrequency(spark,joinLinkidCountSwidDf,incDay,outputTable)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val inputTable: String = args(1)
    val outputTable: String = args(2)
    execute(incDay,inputTable,outputTable)
    //execute()
    logger.error("======>>>>>>VehiclePathwayStationFrequencyClue Execute Ok")
  }
}
