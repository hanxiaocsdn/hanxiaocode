package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkWrite

import scala.collection.mutable.ArrayBuffer

/**
 * @Description:油站统计报表sx
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:1003
 * 任务名称：油站基础统计表-sx
 * 依赖任务：无
 * 数据源：
 * 调用服务地址：无
 * 数据结果：ddjy_dwd_station_statistic_sx_di
 */

object CollectionStationStatisticSx {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def grpidProcess(grpid: String) = {
    var tmpGrpid=grpid
    if (grpid==null){
      tmpGrpid=""
    }
    if (tmpGrpid.startsWith("cft_")){
      tmpGrpid = tmpGrpid.replace("cft_","")
    }else if(tmpGrpid.startsWith("ty_")){
      tmpGrpid = tmpGrpid.replace("ty_","")
    }else if(tmpGrpid.startsWith("fhm_")){
      tmpGrpid = tmpGrpid.replace("fhm_","")
    }else if(tmpGrpid.startsWith("ylk_")){
      tmpGrpid = tmpGrpid.replace("ylk_","")
    }else if(tmpGrpid.startsWith("JT_")){
      tmpGrpid = tmpGrpid.replace("JT_","")
    }
    tmpGrpid.replaceAll("_","")
  }

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String, last_seven_day:String, last_fourteen_day:String, fri_day:String) = {
    import spark.implicits._
    //读取ddjy_ods_corp_info_df
    val corpInfoSql=
      """
        |select id,name
        |from dm_gis.ddjy_ods_corp_info_df
        |where inc_day in(select max(inc_day) from dm_gis.ddjy_ods_corp_info_df)
        |and corp_type='2' and del_flag='0'
        |group by id,name
        |""".stripMargin
    val corpInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, corpInfoSql).map(obj => {
      (obj.getString("id"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("corp_info表数据量:"+corpInfoRdd.count())
    //读取ddjy_uimp_dm_petrol_price_discount
    val priceDiscountSql=
      s"""
        |select grpid,ft_sale_price,station_type,sale_price
        |from dm_gis.ddjy_uimp_dm_petrol_price_discount
        |where inc_day = '$inc_day'
        |and station_type in('4','7')
        |group by grpid,ft_sale_price,station_type,sale_price
        |""".stripMargin
    val priceDiscountRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, priceDiscountSql).map(obj=>{
      var grpid: String = obj.getString("grpid")
      grpid = grpidProcess(grpid)
      obj.put("grpid",grpid)
      ((grpid,obj.getString("station_type")),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("petrol_price_discount表数据量:"+priceDiscountRdd.count())
    //读取ddjy_dim_station_info_on_shelf_time_df
    val onShelfTimeSql=
      s"""
         |select grpid,station_type,min(on_shelf_time) as min_on_shelf_time,
         |max(on_shelf_time) as max_on_shelf_time
         |from dm_gis.ddjy_dim_station_info_on_shelf_time_df
         |where inc_day<='${inc_day}'
         |and station_type in('4','7')
         |and on_shelf_time !=''
         |and on_shelf_time is not null
         |group by grpid,station_type
         |""".stripMargin
    val onShelfTimeRdd: RDD[((String, String), JSONObject)] = SparkUtils.getRowToJson(spark, onShelfTimeSql).map(obj=>{
      var grpid: String = obj.getString("grpid")
      grpid = grpidProcess(grpid)
      obj.put("grpid",grpid)
      ((grpid,obj.getString("station_type")),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("on_shelf_time表数据量:"+onShelfTimeRdd.count())
    //读取ddjy_dim_station_info_on_shelf_time_df
    val payRepartitionSql=
      s"""
         |select grpid,
         |min(pay_time) as pay_time,
         |sum(ft_sale_money) as ft_sale_money
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day = '$inc_day'
         |and station_type in('4','7')
         |group by grpid
         |""".stripMargin
    val payRepartitionRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, payRepartitionSql).map(obj=>{
      var grpid: String = obj.getString("grpid")
      grpid = grpidProcess(grpid)
      obj.put("grpid",grpid)
      obj
    }).groupBy(_.getString("grpid")).map(obj=>{
      val list: List[JSONObject] = obj._2.toList
      val day_pay_time: String = list.minBy(_.getString("pay_time")).getString("pay_time")
      val day_ft_sale_money: Double = list.map(_.getDoubleValue("ft_sale_money")).sum
      val tmpObj = new JSONObject()
      tmpObj.put("grpid",obj._1)
      tmpObj.put("day_pay_time",day_pay_time)
      tmpObj.put("day_ft_sale_money",day_ft_sale_money)
      (obj._1,tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("order_pay_repartition表数据量:"+payRepartitionRdd.count())
    //计算月累计流水
    val monthPayRepartitionSql=
      s"""
         |select grpid,
         |sum(ft_sale_money) as ft_sale_money
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day <= '$inc_day' and substr(inc_day,0,6)=substr('$inc_day',0,6)
         |and station_type in('4','7')
         |group by grpid
         |""".stripMargin
    val monthPayRepartitionRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, monthPayRepartitionSql).map(obj => {
      var grpid: String = obj.getString("grpid")
      grpid = grpidProcess(grpid)
      obj.put("grpid", grpid)
      obj
    }).groupBy(_.getString("grpid")).map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val month_ft_sale_money: Double = list.map(_.getDoubleValue("ft_sale_money")).sum
      val tmpObj = new JSONObject()
      tmpObj.put("grpid", obj._1)
      tmpObj.put("month_ft_sale_money", month_ft_sale_money)
      (obj._1, tmpObj)
    })

    //计算累计流水
    val aggPayRepartitionSql=
      s"""
         |select grpid,
         |sum(ft_sale_money) as ft_sale_money,
         |min(pay_time) as min_pay_time
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day <= '$inc_day' and inc_day>='20230228'
         |and station_type in('4','7')
         |group by grpid
         |""".stripMargin
    val aggPayRepartitionRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, aggPayRepartitionSql).map(obj => {
      var grpid: String = obj.getString("grpid")
      grpid = grpidProcess(grpid)
      obj.put("grpid", grpid)
      obj
    }).groupBy(_.getString("grpid")).map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val agg_ft_sale_money: Double = list.map(_.getDoubleValue("ft_sale_money")).sum
      val min_pay_time: String = list.minBy(_.getString("min_pay_time")).getString("min_pay_time")
      val tmpObj = new JSONObject()
      tmpObj.put("grpid", obj._1)
      tmpObj.put("agg_ft_sale_money", agg_ft_sale_money)
      tmpObj.put("min_pay_time", min_pay_time)
      (obj._1, tmpObj)
    })
    //读取 ddjy_ods_main_corp_info_df
    val mainCorpInfoSql=
      """
        |select id,corp_name as main_corp_name from dm_gis.ddjy_ods_main_corp_info_df
        |""".stripMargin
    val mainCorpInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, mainCorpInfoSql).map(obj=>{
      (obj.getString("id"),obj)
    })
    //读取ddjy_dim_station_info_filter
    val stationInfoSql=
      s"""
        |select grpid,petrol_station_name,station_type,corp_id,enable_flag,brand as brand_type,province_name,city_name,area_name,main_corp_info_id,
        |sales_name as station_sale,
        |concat(maintain_begin_time,'-',maintain_end_time) as maintain_time
        |from dm_gis.ddjy_dim_station_info_filter
        |where inc_day='$inc_day'
        |and station_type in('4','7')
        |""".stripMargin
    val stationInfoRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, stationInfoSql).groupBy(_.getString("grpid")).map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.minBy(_.getString("enable_flag"))
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站信息过滤表数据量:"+stationInfoRdd.count())
    val stationStasticDf: DataFrame = stationInfoRdd.map(obj => {
      (obj.getString("corp_id"), obj)
    }).leftOuterJoin(corpInfoRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).map(obj => {
      var grpid: String = obj.getString("grpid")
      grpid = grpidProcess(grpid)
      val station_type: String = JSONUtil.getJsonValSingle(obj, "station_type")
      var tag = Int.MaxValue
      var platform_name = ""
      station_type match {
        case "4" => {
          tag = 0
          platform_name = "顺象"
        }
        case "2" => {
          tag = 1
          platform_name = "团油"
        }
        case "3" => {
          tag = 2
          platform_name = "丰汇盟"
        }
        case "6" => {
          tag = 3
          platform_name = "车福通"
        }
        case "7" => {
          tag = 4
          platform_name = "优联可"
        }
        case "1" => {
          platform_name = "吨吨"
        }
        case "5" => {
          platform_name = "讯宏"
        }
        case _ =>{
          platform_name = ""
        }
      }
      obj.put("grpid", grpid)
      obj.put("tag", tag)
      obj.put("platform_name", platform_name)
      ((obj.getString("grpid"), obj.getString("station_type")), obj)
    }).leftOuterJoin(priceDiscountRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      ((leftObj.getString("grpid"), leftObj.getString("station_type")), leftObj)
    }).leftOuterJoin(onShelfTimeRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).groupBy(_.getString("grpid")).map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val minObj: JSONObject = list.minBy(_.getIntValue("tag"))
      val petrol_station_name: String = minObj.getString("petrol_station_name")
      val name: String = minObj.getString("name")
      val brandList: List[JSONObject] = list.filter(json => {
        val brand_type: String = json.getString("brand_type")
        StringUtils.isNoneEmpty(brand_type)
      })
      var brand_type = ""
      if (brandList.nonEmpty){
        brand_type = brandList.minBy(json=>{
          val brand_type: String = JSONUtil.getJsonValSingle(json, "brand_type")
          brand_type
        }).getString("brand_type")
      }
      val provinceList: List[JSONObject] = list.filter(json => {
        val province_name: String = json.getString("province_name")
        StringUtils.isNoneEmpty(province_name)
      })
      var province_name: String = ""
      if (provinceList.nonEmpty){
        province_name = provinceList.minBy(_.getString("province_name")).getString("province_name")
      }
      val cityList: List[JSONObject] = list.filter(json => {
        val city_name: String = json.getString("city_name")
        StringUtils.isNoneEmpty(city_name)
      })
      var city_name: String = ""
      if (cityList.nonEmpty){
        city_name = cityList.minBy(_.getString("city_name")).getString("city_name")
      }

      val area_name_list: List[JSONObject] = list.filter(json => {
        val area_name: String = json.getString("area_name")
        StringUtils.isNoneEmpty(area_name)
      })
      var area_name: String = ""
      if (area_name_list.nonEmpty){
        area_name = area_name_list.minBy(_.getString("area_name")).getString("area_name")
      }
      val platform_ft_sale_price: Double = minObj.getDoubleValue("ft_sale_price")
      val sale_price: Double = minObj.getDoubleValue("sale_price")
      val platform_breaks: Double = sale_price - platform_ft_sale_price

      val min_on_shelf_time_list: List[JSONObject] = list.filter(json => {
        val min_on_shelf_time: String = json.getString("min_on_shelf_time")
        StringUtils.isNoneEmpty(min_on_shelf_time)
      })
      var min_on_shelf_time: String = ""
      if (min_on_shelf_time_list.nonEmpty){
        min_on_shelf_time = min_on_shelf_time_list.minBy(json => {
          val min_on_shelf_time: String = JSONUtil.getJsonValSingle(json, "min_on_shelf_time")
          min_on_shelf_time
        }).getString("min_on_shelf_time")
      }
      val max_on_shelf_time_list: List[JSONObject] = list.filter(json => {
        val max_on_shelf_time: String = json.getString("max_on_shelf_time")
        StringUtils.isNoneEmpty(max_on_shelf_time)
      })
      var max_on_shelf_time: String = ""
      if(max_on_shelf_time_list.nonEmpty){
        max_on_shelf_time = max_on_shelf_time_list.maxBy(json => {
          val max_on_shelf_time: String = JSONUtil.getJsonValSingle(json, "max_on_shelf_time")
          max_on_shelf_time
        }).getString("max_on_shelf_time")
      }

      val enable_flag_list: List[String] = list.map(_.getString("enable_flag"))
      var shelf_status = "未上架"
      if (enable_flag_list.contains("1")) {
        shelf_status = "已上架"
      }
      val midObj: JSONObject = list.maxBy(_.getString("grpid"))
      val main_corp_info_id: String = midObj.getString("main_corp_info_id")
      val station_sale: String = midObj.getString("station_sale")
      val maintain_time: String = midObj.getString("maintain_time")
      val tmpObj = new JSONObject()
      tmpObj.put("grpid", obj._1)
      tmpObj.put("petrol_station_name", petrol_station_name)
      tmpObj.put("corp_name", name)
      tmpObj.put("brand_type", brand_type)
      tmpObj.put("province_name", province_name)
      tmpObj.put("city_name", city_name)
      tmpObj.put("area_name", area_name)
      tmpObj.put("platform_ft_sale_price", platform_ft_sale_price)
      tmpObj.put("platform_breaks", platform_breaks)
      tmpObj.put("min_on_shelf_time", min_on_shelf_time)
      tmpObj.put("max_on_shelf_time", max_on_shelf_time)
      tmpObj.put("shelf_status", shelf_status)
      tmpObj.put("main_corp_info_id", main_corp_info_id)
      tmpObj.put("station_sale", station_sale)
      tmpObj.put("maintain_time", maintain_time)
      (obj._1,tmpObj)
    }).leftOuterJoin(aggPayRepartitionRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      (obj._1,leftObj)
    }).leftOuterJoin(payRepartitionRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("day_ft_sale_money",rightObj.getString("day_ft_sale_money"))
      }
      val day_ft_sale_money: Double = JSONUtil.getJsonDouble(leftObj, "day_ft_sale_money", 0.0)
      var shelf_status: String = JSONUtil.getJsonValSingle(leftObj, "shelf_status")
      if (shelf_status=="未上架" && day_ft_sale_money!=0.0){
        shelf_status="已上架"
      }
      var min_on_shelf_time: String = JSONUtil.getJsonValSingle(leftObj, "min_on_shelf_time")
      var max_on_shelf_time: String = JSONUtil.getJsonValSingle(leftObj, "max_on_shelf_time")
      val min_pay_time: String = JSONUtil.getJsonValSingle(leftObj, "min_pay_time")
      if ((StringUtils.isEmpty(min_on_shelf_time) && StringUtils.isNoneEmpty(min_pay_time)) ||
        (StringUtils.isNoneEmpty(min_pay_time) && StringUtils.isNoneEmpty(min_on_shelf_time) && min_on_shelf_time>min_pay_time.substring(0,10))){
        min_on_shelf_time = min_pay_time.substring(0,10)
      }
      if (StringUtils.isEmpty(max_on_shelf_time) && StringUtils.isNoneEmpty(min_pay_time)){
        max_on_shelf_time = min_pay_time.substring(0,10)
      }
      leftObj.put("min_on_shelf_time",min_on_shelf_time)
      leftObj.put("max_on_shelf_time",max_on_shelf_time)
      leftObj.put("shelf_status",shelf_status)
      (leftObj.getString("main_corp_info_id"),leftObj)
    }).leftOuterJoin(mainCorpInfoRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("station_subject",rightObj.getString("main_corp_name"))
      }
      (leftObj.getString("grpid"),leftObj)
    }).leftOuterJoin(monthPayRepartitionRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("month_ft_sale_money",rightObj.getString("month_ft_sale_money"))
      }
      leftObj.put("inc_day",inc_day)
      leftObj
    }).map(obj => {
      stationStatistic(
        obj.getString("grpid"),
        obj.getString("petrol_station_name"),
        obj.getString("corp_name"),
        obj.getString("brand_type"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("platform_ft_sale_price"),
        obj.getString("platform_breaks"),
        obj.getString("min_on_shelf_time"),
        obj.getString("max_on_shelf_time"),
        obj.getString("shelf_status"),
        obj.getString("min_pay_time"),
        obj.getString("agg_ft_sale_money"),
        obj.getString("day_ft_sale_money"),
        obj.getString("station_subject"),
        obj.getString("station_sale"),
        obj.getString("month_ft_sale_money"),
        obj.getString("maintain_time")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("油站统计结果表数据量:"+stationStasticDf.count())
    corpInfoRdd.unpersist()
    priceDiscountRdd.unpersist()
    onShelfTimeRdd.unpersist()
    payRepartitionRdd.unpersist()
    stationInfoRdd.unpersist()
    SparkWrite.writeToHive(spark,stationStasticDf,"inc_day",inc_day,"dm_gis.ddjy_dwd_station_statistic_sx_di")
    logger.error("写入ddjy_dwd_station_statistic_sx_di每日成功，日期为："+inc_day)
    stationStasticDf.unpersist()
  }

  def minStationOrderFilterPaytime(spark: SparkSession, inc_day: String) = {
    val stationOrderFilterSql=
      s"""
        |select substr(min(pay_time),0,10)as inc_day
        |from dm_gis.ddjy_dwd_station_order_filter
        |where inc_day='${inc_day}'
        |and pay_time is not null
        |and pay_time!=''
        |""".stripMargin
    val start_day: String = SparkUtils.getRowToJson(spark,stationOrderFilterSql).map(obj=>{
      val inc_day: String = obj.getString("inc_day").replace("-", "")
      inc_day
    }).collect().head
    val dates: Int = DateUtil.daysDiff(start_day, inc_day).toInt
    logger.error("当天支付时间最早的时间:"+start_day)
    logger.error(start_day+"和"+inc_day+"时间间隔是:"+dates+"天")
    dates
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取ddjy_dwd_station_order_filter，计算是否有补录订单，以及补录订单最早时间
    var dates = minStationOrderFilterPaytime(spark, inc_day)
    if (dates>60){
      dates=60
    }
    for (i <- (0 to dates).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      val sdf = new SimpleDateFormat("yyyyMMdd")
      val actionTime = sdf.parse(incDay)
      val cal_5 = Calendar.getInstance
      cal_5.setTime(actionTime)
      cal_5.add(Calendar.WEEK_OF_MONTH, -1)
      cal_5.set(Calendar.DAY_OF_WEEK, 6)
      val fri_day = sdf.format(cal_5.getTime)
      stationProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day,fri_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val dates: Int = args(1).toInt
    execute(inc_day)
    logger.error("======>>>>>>油站统计表 Execute Ok")
  }
  case class stationStatistic(
                              grpid:String,
                              petrol_station_name:String,
                              corp_name:String,
                              brand_type:String,
                              province_name:String,
                              city_name:String,
                              area_name:String,
                              platform_ft_sale_price:String,
                              platform_breaks:String,
                              min_on_shelf_time:String,
                              max_on_shelf_time:String,
                              shelf_status:String,
                              min_pay_time:String,
                              agg_ft_sale_money:String,
                              day_ft_sale_money:String,
                              station_subject:String,
                              station_sale:String,
                              month_ft_sale_money:String,
                              maintain_time:String
                   )

}
