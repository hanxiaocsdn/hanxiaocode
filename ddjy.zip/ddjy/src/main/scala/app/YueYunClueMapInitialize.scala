package app

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, DistanceUtils, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import pojo._
import utils.SfNetInteface

import scala.collection.JavaConversions._
import scala.util.control.Breaks

/**
 * @Description:粤运线索地图初始化
 * 需求人员：矫悦 01404184
 * @Author: lixiangzhi 01405644
 * @Date: 18:40 2022/11/14
 * 任务id:259
 * 任务名称：粤运线索地图
 * 依赖任务：粤运集散地关联车队表 258
 * 数据源：single_agr_stat_all_drop_owner_tmp
 * 调用服务地址：http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0
 *             http://gis-int.int.sfdc.com.cn:1080/rgeo/api?x=%s&y=%s&opt=sf1&ak=%s
 *             http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s
 *             http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/StationClusterRect?
 * 数据结果：dwd_ddjy_cantonese_station_clue_di、dwd_ddjy_cantonese_clue_info_di、dwd_ddjy_cantonese_carrier_clue_di、dwd_ddjy_cantonese_carrier_vehicle_di等
 */
object YueYunClueMapInitialize {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readDropOwnerData(spark: SparkSession, incDay: String) = {

    val singleAgrSql=
      """
        |select *
        |from dm_gis.single_agr_stat_all_drop_owner_tmp
        |""".stripMargin
    val dropOwnerDf: DataFrame = spark.sql(singleAgrSql)
    val dropOwnerRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, dropOwnerDf).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dropOwner表数据量："+dropOwnerRdd.count())
    dropOwnerRdd
  }

  def insertAoiInterfaceTable(spark: SparkSession, aoiInterfaceRdd: RDD[JSONObject]) = {
    import spark.implicits._
    val aoiInterfaceDf: DataFrame = aoiInterfaceRdd.map(obj => {
      DropAoiInterface(obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("fatype"),
        obj.getString("aoicode"),
        obj.getString("znocode"),
        obj.getString("dist"),
        obj.getString("city"))
    }).toDF()
    aoiInterfaceDf.createOrReplaceTempView("aoiInterfaceTmp")
    spark.sql("insert overwrite table dm_gis.ddjy_aoi_interface_tmp select * from aoiInterfaceTmp")
  }

  def dropOwnerAoiInterface(spark: SparkSession, dropOwnerRdd: RDD[JSONObject], incDay: String) = {
    import spark.implicits._
    val aoiInterfaceRdd = dropOwnerRdd.repartition(50).flatMap(obj => {
      val retObj: JSONObject = SfNetInteface.aoiCircleInterface(obj)
      val api_result: JSONObject = JSONUtil.getJSONObject(retObj, "api_result")
      val dataArray: JSONArray = JSONUtil.getJsonArrayMulti(api_result, "data")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until dataArray.size()) {
        val tmpObj = new JSONObject()
        val dataObj: JSONObject = dataArray.getJSONObject(i)
        val id: String = dataObj.getString("id")
        val name: String = dataObj.getString("name")
        val faType: String = dataObj.getString("faType")
        val aoiCode: String = dataObj.getString("aoiCode")
        val znoCode: String = dataObj.getString("znoCode")
        val dist: String = dataObj.getString("dist")
        val city: String = dataObj.getString("city")
        tmpObj.fluentPutAll(obj)
        tmpObj.put("id", id)
        tmpObj.put("name", name)
        tmpObj.put("faType", faType)
        tmpObj.put("aoiCode", aoiCode)
        tmpObj.put("znoCode", znoCode)
        tmpObj.put("dist", dist)
        tmpObj.put("city", city)
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调aoi接口返回数据量："+aoiInterfaceRdd.count())
    insertAoiInterfaceTable(spark,aoiInterfaceRdd)
    logger.error("====>>>>>>>插入aoi接口表成功")
    //aoiInterfaceRdd.take(10).foreach(println(_))
    val aoiKeySql=
      """
        |select *
        |from dm_gis.dim_aoi_key_type_df
        |""".stripMargin
    val aoiKeyDf: DataFrame = spark.sql(aoiKeySql)
    val aoiKeyMap: collection.Map[String, JSONObject] = SparkUtils.getDfToJson(spark, aoiKeyDf).map(obj => {
      val fa_type: String = obj.getString("fa_type")
      (fa_type, obj)
    }).collectAsMap()
    val aoiKeyBR: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(aoiKeyMap)
    val logisticsDf: DataFrame = aoiInterfaceRdd.repartition(600).map(obj => {
      val aoiKeyMapValue: collection.Map[String, JSONObject] = aoiKeyBR.value
      val faType: String = obj.getString("faType")
      if (aoiKeyMapValue.contains(faType)){
        val aoiKeyObj: JSONObject = aoiKeyMapValue(faType)
        val is_logistics: String = aoiKeyObj.getString("is_logistics")
        val distribute_passpoint: String = aoiKeyObj.getString("distribute_passpoint")
        val big_category: String = aoiKeyObj.getString("big_category")
        val mid_category: String = aoiKeyObj.getString("mid_category")
        val type_name: String = aoiKeyObj.getString("type_name")
        obj.put("is_logistics", is_logistics)
        obj.put("distribute_passpoint", distribute_passpoint)
        obj.put("big_category", big_category)
        obj.put("mid_category", mid_category)
        obj.put("type_name", type_name)
      }
      obj
    }).filter(obj => {
      val is_logistics: String = obj.getString("is_logistics")
      is_logistics == "是"
    }).map(obj=>{
      LogisticsVehicle(obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("faType"),
        obj.getString("aoiCode"),
        obj.getString("znoCode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("is_logistics"),
        obj.getString("distribute_passpoint"),
        obj.getString("big_category"),
        obj.getString("mid_category"),
        obj.getString("type_name"))
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("与物流相关的数据量："+logisticsDf.count())
    logisticsDf.createOrReplaceTempView("logistics_tmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_logistics_vehicle_di select * from logistics_tmp")
    aoiInterfaceRdd.unpersist()
    logisticsDf.unpersist()
  }
  def readLogicticsData(spark: SparkSession, incDay: String) = {
    val logicticsSql=
      s"""
        |select *
        |from dm_gis.dwd_ddjy_logistics_vehicle_di
        |""".stripMargin
    val logicticsDf: DataFrame = spark.sql(logicticsSql)
    logicticsDf
  }

  def getAreaKeyRdd(spark:SparkSession,InAreaRdd:RDD[JSONObject],leyTag:String,notKeyTag:String) = {
    val name_key="电商|电子商务|仓储|邮局|物流|货运|运输|快递|中转|集散点|分拨中心|韵达|申通|顺丰|中通|圆通|德邦|邮政|EMS|ems|京东|百世|龙邦|国通|龙邦|工业园|工业区|工业城|厂区|产业园|科技园|工厂|厂房|油站|服务区|石场|钢铁|矿业|木业|石化|塑料|金属|纺织|工业|塑胶|陶瓷|玻璃|材料|五金|钢材|不锈钢|公司|家具|电器|家电|建材|市场|码头|口岸|快递|口岸|港口|码头|进口|出口"
    val name_key_arr: Array[String] = name_key.split("\\|")
    val keyFilterRdd: RDD[JSONObject] = InAreaRdd.filter(obj => {
      val name: String = obj.getString("name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- name_key_arr.indices) {
          val name_key: String = name_key_arr(k)
          if (name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      val fatype_key = "170300,120201,120100,150300,70400,70401,70500,70501,70502,70503,10000,10100,10101,10102,10103,10104,10105,10107,10108,10109,10110,10111,10112,150900"
      val fatype_key_arr: Array[String] = fatype_key.split(",")
      val fatype: String = obj.getString("fatype")
      val dist: Double = obj.getDouble("dist")
      bool && !name.contains("公司") && fatype_key_arr.contains(fatype) && dist <= 150
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤出重点类型数据量："+keyFilterRdd.count())
    keyFilterRdd.take(10).foreach(println(_))
    val keyRdd: RDD[JSONObject] = keyFilterRdd
      .map(obj => {
        val agr_id: String = obj.getString("agr_id")
        (agr_id, obj)
      }).groupByKey().map(obj => {
      obj._2.toList.minBy((json: JSONObject) => {
        JSONUtil.getJsonDouble(json,"dis",Int.MaxValue)
      })
    }).map(obj => {
      val tag: String = obj.getString("tag")
      obj.put(leyTag, tag)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val keyMapRdd: RDD[(String, JSONObject)] = keyRdd.map(obj => {
      (obj.getString("agr_id"),obj)
    })
    val notkeyRdd: RDD[JSONObject] = InAreaRdd.repartition(600).map(obj => {
      (obj.getString("agr_id"), obj)
    }).leftOuterJoin(keyMapRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj == null
    }).map(obj => {
      val leftObj: JSONObject = obj._2._1
      (leftObj.getString("agr_id"), leftObj)
    }).groupByKey().map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val head: JSONObject = list.minBy(json => {
        JSONUtil.getJsonDouble(json, "dis", Int.MaxValue)
      })
      head
    }).map(obj => {
      val tag: String = obj.getString("tag")
      obj.put(notKeyTag, tag)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    keyFilterRdd.unpersist()
    (keyRdd,notkeyRdd)
  }

  def joinAoiKeyType(spark: SparkSession, logicticsDf: DataFrame,incDay:String) = {
    import spark.implicits._
    val logicticsRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, logicticsDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val notGetAoiRdd: RDD[JSONObject] = logicticsRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("id"))
    }).map(obj => {
      val tag = "notGetAoi"
      obj.put("tag", tag)
      obj
    })
    val dotInAreaRdd: RDD[JSONObject] = logicticsRdd.filter(obj => {
      obj.getDouble("dist") == 0
    }).map(obj => {
      obj.put("tag", "dotInArea")
      (obj.getString("agr_id"), obj)
    }).groupByKey().map(obj => {
      obj._2.toList.maxBy(json => {
        JSONUtil.getJsonValSingle(json, "vehicle_time")
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("点落面数据量："+dotInAreaRdd.count())
    val dotInAreaGroupRdd: RDD[(String, JSONObject)] = dotInAreaRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    })
    val dotNotInAreaRdd: RDD[JSONObject] = logicticsRdd.map(obj=>{
      (obj.getString("agr_id"), obj)
    }).leftOuterJoin(dotInAreaGroupRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj==null
    }).map(obj => {
      val leftObj: JSONObject = obj._2._1
      leftObj.put("tag", "dotNotInArea")
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("未能点落面数据量："+dotNotInAreaRdd.count())

    val dotNotInAreaKeyTag="dotNotInAreaKey"
    val dotNotInAreaNotKeyTag="dotNotInAreaNotKey"
    val (dotNotInAreaKeyRdd,dotNotInAreaNotKeyRdd): (RDD[JSONObject], RDD[JSONObject]) = getAreaKeyRdd(spark,dotNotInAreaRdd,dotNotInAreaKeyTag,dotNotInAreaNotKeyTag)
    logger.error("未能点落面重点类型数据量："+dotNotInAreaKeyRdd.count())
    logger.error("未能点落面非重点类型数据量："+dotNotInAreaNotKeyRdd.count())
    val dotInAreaKeyTag="dotInAreaKey"
    val dotInAreaNotKeyTag="dotInAreaNotKey"
    val (dotInAreaKeyRdd,dotInAreaNotKeyRdd): (RDD[JSONObject], RDD[JSONObject]) = getAreaKeyRdd(spark,dotInAreaRdd,dotInAreaKeyTag,dotInAreaNotKeyTag)
    logger.error("点落面重点类型数据量："+dotInAreaKeyRdd.count())
    logger.error("点落面非重点类型数据量："+dotInAreaNotKeyRdd.count())
    val aoiKeyDf: DataFrame = dotInAreaKeyRdd.union(dotNotInAreaKeyRdd).map(obj=>{
      LogisticsVehicleTag(obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("fatype"),
        obj.getString("aoicode"),
        obj.getString("znocode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("is_logistics"),
        obj.getString("distribute_passpoint"),
        obj.getString("big_category"),
        obj.getString("mid_category"),
        obj.getString("type_name"),
        obj.getString("tag"),
        "key_clue"
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("AOI关联的重点类型数据量："+aoiKeyDf.count())
    aoiKeyDf.createOrReplaceTempView("aoiKeyTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_aoi_key_di select * from aoiKeyTmp")
    val aoiNotKeyDf: DataFrame = dotInAreaNotKeyRdd.union(dotNotInAreaNotKeyRdd).union(notGetAoiRdd).map(obj=>{
      LogisticsVehicleTag(obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("fatype"),
        obj.getString("aoicode"),
        obj.getString("znocode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("is_logistics"),
        obj.getString("distribute_passpoint"),
        obj.getString("big_category"),
        obj.getString("mid_category"),
        obj.getString("type_name"),
        obj.getString("tag"),
        "not_key_clue"
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("AOI关联的非重点类型数据量："+aoiNotKeyDf.count())
    aoiNotKeyDf.createOrReplaceTempView("aoiNotKeyTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_aoi_not_key_di select * from aoiNotKeyTmp")
    dotInAreaRdd.unpersist()
    dotNotInAreaRdd.unpersist()
    dotNotInAreaKeyRdd.unpersist()
    dotNotInAreaNotKeyRdd.unpersist()
    dotInAreaKeyRdd.unpersist()
    dotInAreaNotKeyRdd.unpersist()

  }

  def readAoiNotKeyData(spark: SparkSession, incDay: String) = {
    val aoiNotKeySql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_aoi_not_key_di
         |--limit 10000
         |""".stripMargin
    val aoiNotKeyDf: DataFrame = spark.sql(aoiNotKeySql)
    aoiNotKeyDf
  }

  def aoiNotKeyPoiInterface(spark: SparkSession, aoiNotKeyDf: DataFrame, incDay: String) = {
    import spark.implicits._
    val aoiNotKeyRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, aoiNotKeyDf)
    val returnPoiRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,aoiNotKeyRdd, SfNetInteface.geoPoiInterface, 50, "85874304df9d44fc9752a62b63453b30", 20000)
    returnPoiRdd.take(10).foreach(println(_))
    val poiInterfaceRdd: RDD[JSONObject] = returnPoiRdd.repartition(200).flatMap(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val pois: JSONArray = JSONUtil.getJsonArrayMulti(result, "pois")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until (pois.size())) {
        val tmpObj = new JSONObject()
        val poisObj: JSONObject = pois.getJSONObject(i)
        val poi_name: String = JSONUtil.getJsonValSingle(poisObj, "name")
        val poi_addr: String = JSONUtil.getJsonValSingle(poisObj, "addr")
        val poi_x: String = JSONUtil.getJsonValSingle(poisObj, "x")
        val poi_y: String = JSONUtil.getJsonValSingle(poisObj, "y")
        val poi_distance: String = JSONUtil.getJsonValSingle(poisObj, "distance")
        val poi_type: String = JSONUtil.getJsonValSingle(poisObj, "type")
        tmpObj.fluentPutAll(obj)
        tmpObj.put("poi_name", poi_name)
        tmpObj.put("poi_addr", poi_addr)
        tmpObj.put("poi_x", poi_x)
        tmpObj.put("poi_y", poi_y)
        tmpObj.put("poi_distance", poi_distance)
        tmpObj.put("poi_type", poi_type)
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    }).filter(obj=>{
      obj.getDouble("poi_distance")<=500
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取poi接口返回数据量："+poiInterfaceRdd.count())
    val poiInterfaceDf: DataFrame = poiInterfaceRdd.map(obj => {
      AoiNotKeyPoiInterface(obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("fatype"),
        obj.getString("aoicode"),
        obj.getString("znocode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("is_logistics"),
        obj.getString("distribute_passpoint"),
        obj.getString("big_category"),
        obj.getString("mid_category"),
        obj.getString("type_name"),
        obj.getString("poi_name"),
        obj.getString("poi_addr"),
        obj.getString("poi_x"),
        obj.getString("poi_y"),
        obj.getString("poi_distance"),
        obj.getString("poi_type"),
        ""
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调poi接口返回数据量："+poiInterfaceDf.count())
    poiInterfaceDf.createOrReplaceTempView("poiInterfaceTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_aoi_not_key_poi_di select * from poiInterfaceTmp")
    poiInterfaceRdd.unpersist()
    poiInterfaceDf.unpersist()
  }

  def readAoiNotKeyPoiData(spark: SparkSession, incDay: String) = {
    val aoiNotKeyPoiSql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_aoi_not_key_poi_di
         |""".stripMargin
    val aoiNotKeyPoiDf: DataFrame = spark.sql(aoiNotKeyPoiSql)
    aoiNotKeyPoiDf
  }

  def processPoiData(spark: SparkSession, poiInterfaceDf: DataFrame, incDay: String) = {
    import spark.implicits._
    val poiInterfaceRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, poiInterfaceDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val poi_name_express="电商|仓储|物流|货运|运输|快递|中转场|集散点|分拨中心|韵达|申通|顺丰|中通|圆通|德邦|邮政|EMS|ems|京东|百世|龙邦|国通|龙邦"
    val poi_name_express_list: Array[String] = poi_name_express.split("\\|")

    val poiExpressRdd: RDD[JSONObject] = poiInterfaceRdd.filter(obj => {
      val poi_name: String = obj.getString("poi_name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- poi_name_express_list.indices) {
          val name_key: String = poi_name_express_list(k)
          if (poi_name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      val poi_type: String = obj.getString("poi_type")
      val name: String = obj.getString("name")
      val poi_distance: Double = obj.getDouble("poi_distance")
      bool && !poi_name.contains("公司") && poi_type == "生活服务;物流速递;物流速递" && (((name.endsWith("村") || name.endsWith("镇")) && poi_distance <= 200) || (!(name.endsWith("村") && name.endsWith("镇")) && poi_distance <= 100))
    })
    val poi_name_industry="工业园|工业区|工业城|工厂区|产业园|科技园|工厂|厂区|厂房"
    val poi_name_industry_list: Array[String] = poi_name_industry.split("\\|")
    val poiIndustryRdd: RDD[JSONObject] = poiInterfaceRdd.filter(obj => {
      val poi_name: String = obj.getString("poi_name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- poi_name_industry_list.indices) {
          val name_key: String = poi_name_industry_list(k)
          if (poi_name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      val poi_type: String = obj.getString("poi_type")
      val name: String = obj.getString("name")
      val poi_distance: Double = obj.getDouble("poi_distance")
      bool && poi_type == "商务住宅;产业园区;产业园区" && (((name.endsWith("村") || name.endsWith("镇")) && poi_distance <= 200) || (!(name.endsWith("村") && name.endsWith("镇")) && poi_distance <= 100))
    })
    val poi_name_gas="服务区|油站"
    val poi_name_gas_list: Array[String] = poi_name_gas.split("\\|")
    val poiGasRdd: RDD[JSONObject] = poiInterfaceRdd.filter(obj => {
      val poi_name: String = obj.getString("poi_name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- poi_name_gas_list.indices) {
          val name_key: String = poi_name_gas_list(k)
          if (poi_name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      val poi_type: String = obj.getString("poi_type")
      val name: String = obj.getString("name")
      val poi_distance: Double = obj.getDouble("poi_distance")
      bool && poi_type == "道路附属设施;服务区;高速服务区'或'汽车服务;加油站" && (((name.endsWith("村") || name.endsWith("镇")) && poi_distance <= 200) || (!(name.endsWith("村") && name.endsWith("镇")) && poi_distance <= 100))
    })
    val poiKeyRdd: RDD[JSONObject] = poiExpressRdd.union(poiIndustryRdd).union(poiGasRdd).map(obj => {
      obj.put("clue_type","key_clue")
      (obj.getString("agr_id"), obj)
    }).groupByKey().map(obj => {
      obj._2.toList.minBy(json => {
        JSONUtil.getJsonDouble(json,"poi_distance",Int.MaxValue)
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("物流园区、工业园区、服务区和加油站总数据量："+poiKeyRdd.count())
    val poi_name_other="工业园|工业区|工业城|工厂区|产业园|科技园|工厂|厂区|厂|厂房|石场|钢铁|矿业|木业|石化|塑料|金属|纺织|工业|塑胶|陶瓷|玻璃|材料|五金|钢材|不锈钢|公司|家具|电器|家电|建材|市场|码头|口岸|港|湾|服务区|加油站|邮局|快递|电商|仓储|物流|货运|运输|中转场|集散点|分拨中心|韵达|申通|顺丰|中通|圆通|德邦|邮政|EMS|ems|京东|百世|龙邦|国通|龙邦|口岸|港口|码头|客运|进口|出口"
    val poi_name_other_list: Array[String] = poi_name_other.split("\\|")
    val poi_key = "生活服务;物流速递;物流速递,商务住宅;产业园区;产业园区,道路附属设施;服务区;高速服务区,公司企业;公司企业;公司企业,公司企业;公司;公司,公司企业;农林牧渔基地;其它农林牧渔基地,购物服务;家居建材市场;家具城,购物服务;购物相关场所;购物相关场所,购物服务;家居建材市场;建材五金市场,交通设施服务;港口码头;港口码头,道路附属设施;收费站;收费站,购物服务;家居建材市场;家居建材市场,通行设施;通行设施;通行设施,生活服务;邮局;邮局,交通设施服务;过境口岸;过境口岸"
    val poi_list: Array[String] = poi_key.split(",")
    val poiKeyGroup: RDD[(String, JSONObject)] = poiKeyRdd.map(obj => {
      (obj.getString("agr_id"),obj)
    })
    val poiOherRdd: RDD[JSONObject] = poiInterfaceRdd.map(obj=>{
      (obj.getString("agr_id"),obj)
    }).repartition(600).leftOuterJoin(poiKeyGroup).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj==null
    }).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      leftObj
    }).filter(obj => {
      val poi_name: String = obj.getString("poi_name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- poi_name_other_list.indices) {
          val name_key: String = poi_name_other_list(k)
          if (poi_name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      val poi_type: String = obj.getString("poi_type")
      val name: String = obj.getString("name")
      val poi_distance: Double = obj.getDouble("poi_distance")
      bool && poi_list.contains(poi_type) && (((name.endsWith("村") || name.endsWith("镇")) && poi_distance <= 200) || (!(name.endsWith("村") && name.endsWith("镇")) && poi_distance <= 100))
    }).map(obj => {
      obj.put("clue_type","key_clue")
      (obj.getString("agr_id"), obj)
    }).groupByKey().map(obj => {
      obj._2.toList.minBy(json => {
        JSONUtil.getJsonDouble(json,"poi_distance",Int.MaxValue)
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其他重点类型数据量："+poiOherRdd.count())
    val poiKeyMapRdd: RDD[(String, JSONObject)] = poiKeyRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    })
    val poiOherMapRdd: RDD[(String, JSONObject)] = poiOherRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    })
    val poi_not_key="幼儿园|小学|公园|银行|广场|工地"
    val poi_not_key_list: Array[String] = poi_not_key.split("\\|")
    val poiNotKeyRdd: RDD[JSONObject] = poiInterfaceRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    }).leftOuterJoin(poiKeyMapRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj == null
    }).map(obj => {
      val leftObj: JSONObject = obj._2._1
      (leftObj.getString("agr_id"), leftObj)
    }).leftOuterJoin(poiOherMapRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj == null
    }).map(obj => {
      val leftObj: JSONObject = obj._2._1
      leftObj.put("clue_type","not_key_clue")
      (leftObj.getString("agr_id"), leftObj)
    }).groupByKey().map(obj => {
      obj._2.toList.minBy(json => {
        JSONUtil.getJsonDouble(json, "poi_distance", Int.MaxValue)
      })
    }).filter(obj => {
      val poi_name: String = obj.getString("poi_name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- poi_not_key_list.indices) {
          val name_key: String = poi_not_key_list(k)
          if (!poi_name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      bool
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("非重点类型数据量："+poiNotKeyRdd.count())
    val poiFinalDf: DataFrame = poiKeyRdd.union(poiOherRdd).union(poiNotKeyRdd).map(obj => {
      AoiNotKeyPoiInterface(obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        obj.getString("agr_dis2sp"),
        obj.getString("agr_gh"),
        obj.getString("agr_rs_id"),
        obj.getString("agr_rs_cnt"),
        obj.getString("type"),
        obj.getString("data_src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("vehicle_no"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("id"),
        obj.getString("name"),
        obj.getString("faType"),
        obj.getString("aoiCode"),
        obj.getString("znoCode"),
        obj.getString("dist"),
        obj.getString("city"),
        obj.getString("is_logistics"),
        obj.getString("distribute_passpoint"),
        obj.getString("big_category"),
        obj.getString("mid_category"),
        obj.getString("type_name"),
        obj.getString("poi_name"),
        obj.getString("poi_addr"),
        obj.getString("poi_x"),
        obj.getString("poi_y"),
        obj.getString("poi_distance"),
        obj.getString("poi_type"),
        obj.getString("clue_type")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("poi中筛选出重点类型数据量："+poiFinalDf.count())
    poiFinalDf.createOrReplaceTempView("poiFinalTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_poi_final_di select * from poiFinalTmp")
    poiKeyRdd.unpersist()
    poiOherRdd.unpersist()
    poiFinalDf.unpersist()
  }


  def aoiPoiInsertHiveTable(spark: SparkSession, aoiPoiRdd: RDD[JSONObject]) = {
    import spark.implicits._
    val aoiPoiDf: DataFrame = aoiPoiRdd.map(obj => {
      AoiPoiUnion(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id")
      )
    }).toDF()
    aoiPoiDf.createOrReplaceTempView("aoiPoiTmp")
    spark.sql("insert overwrite table dm_gis.dwd_ddjy_aoi_poi_di select * from aoiPoiTmp")
  }

  def readAoiKeyAndPoi(spark: SparkSession, incDay: String) = {
    val aoiKeySql=
      s"""
         |select
         |agr_id,agr_rs_id,
         |name as belong_name,
         |agr_lng as belong_x,
         |agr_lat as belong_y,
         |'AOI' as src,
         |id as unique_id,
         |clue_type
         |from dm_gis.dwd_ddjy_aoi_key_di
         |""".stripMargin
    val aoiKeyDf: DataFrame = spark.sql(aoiKeySql)
    val poiFinalSql=
      s"""
         |select
         |agr_id,agr_rs_id,
         |poi_name as belong_name,
         |poi_x as belong_x,
         |poi_y as belong_y,
         |'POI' as src,
         |concat(poi_name,poi_x,poi_y) as unique_id,
         |clue_type
         |from dm_gis.dwd_ddjy_poi_final_di
         |""".stripMargin
    val poiFinalDf: DataFrame = spark.sql(poiFinalSql)
    val aoiKeyRdd = SparkUtils.getDfToJson(spark,aoiKeyDf)
    val aoiPoiRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, poiFinalDf).map(obj => {
      var unique_id: String = obj.getString("unique_id")
      unique_id = DigestUtils.md2Hex(unique_id)
      obj.put("unique_id", unique_id)
      obj
    }).union(aoiKeyRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //aoiPoiInsertHiveTable(spark,aoiPoiRdd)
    logger.error("aoi和poi拼接后数据量："+aoiPoiRdd.count())
    aoiPoiRdd
  }

  def processAoiPoi(spark: SparkSession, aoiPoiRdd: RDD[JSONObject],task_batch:String, incDay: String) = {
    import spark.implicits._
    logger.error("task_batch:"+task_batch)
    val belong_name_key="银行|住宅|社区|居民|小区|广场|银行|工地|建设中|在建|施工|拆迁"
    val belong_name_key_list: Array[String] = belong_name_key.split("\\|")
    val belongNameRdd: RDD[JSONObject] = aoiPoiRdd
      /*.filter(obj => {
      val belong_name: String = obj.getString("belong_name")
      val nameLoop = new Breaks
      var bool = false
      nameLoop.breakable {
        for (k <- belong_name_key_list.indices) {
          val name_key: String = belong_name_key_list(k)
          if (!belong_name.contains(name_key)) {
            bool = true
            nameLoop.break()
          }
        }
      }
      !belong_name.endsWith("村") && !belong_name.endsWith("屯") && bool && belong_name.length > 3
    })*/
      .map(obj=>{
      obj.put("agr_lng",obj.getString("belong_x"))
      obj.put("agr_lat",obj.getString("belong_y"))
      obj
    })
    val returnPoiRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,belongNameRdd, SfNetInteface.geoPoiInterface, 50, "85874304df9d44fc9752a62b63453b30", 20000)
    returnPoiRdd.take(10).foreach(println(_))
    val belongInfoDf: DataFrame = returnPoiRdd.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val stay_adcode: String = JSONUtil.getJsonValSingle(result, "adcode")
      val stay_province: String = JSONUtil.getJsonValSingle(result, "province")
      val stay_city: String = JSONUtil.getJsonValSingle(result, "city")
      val stay_district: String = JSONUtil.getJsonValSingle(result, "district")
      val stay_town: String = JSONUtil.getJsonValSingle(result, "town")
      obj.put("stay_adcode", stay_adcode)
      obj.put("stay_province", stay_province)
      obj.put("stay_city", stay_city)
      if (stay_district==""){
        obj.put("stay_district", stay_town)
      }else{
        obj.put("stay_district", stay_district)
      }
      obj.put("task_batch", task_batch)
      obj.put("inc_day", incDay)
      obj
    }).map(obj => {
      BelongInfo(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        obj.getString("task_batch"),
        obj.getString("inc_day"),
        obj.getString("clue_type")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤不满足belongname数据并调用poi返回数据量："+belongInfoDf.count())
    belongInfoDf.createOrReplaceTempView("belongInfoTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_belong_info_di select * from belongInfoTmp")
    belongInfoDf.unpersist()
  }

  def readBelongInfoData(spark: SparkSession,incDay: String) = {
    val belongInfoSql=
      """
        |select *
        |from dm_gis.dwd_ddjy_belong_info_di
        |""".stripMargin
    val belongInfoDf: DataFrame = spark.sql(belongInfoSql)
    val belongInfoRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, belongInfoDf)
    belongInfoRdd
  }


  def belongJoinOwnInsertTable(spark: SparkSession, belongJoinOwnDf: DataFrame) = {
    belongJoinOwnDf.createOrReplaceTempView("belongJoinOwnTmp2")
    spark.sql("insert overwrite table dm_gis.dwd_ddjy_belong_join_own_di select * from belongJoinOwnTmp2")
  }

  def joinAoiPoiBelongDropOwnerInfoData(spark: SparkSession, aoiPoiRdd: RDD[JSONObject], dropOwnerRdd: RDD[JSONObject], belongInfoRdd: RDD[JSONObject], task_batch:String, incDay: String) = {
    import spark.implicits._
    val aoiPoiGroupRdd: RDD[(String, JSONObject)] = aoiPoiRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    })
    val dropJoinAoiRdd: RDD[(String, JSONObject)] = dropOwnerRdd.map(obj => {
      (obj.getString("agr_id"), obj)
    }).repartition(600).join(aoiPoiGroupRdd).map(obj=>{
      val newObj = new JSONObject()
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      newObj.put("unique_id",rightObj.getString("unique_id"))
      newObj.put("agr_id",rightObj.getString("agr_id"))
      newObj.put("agr_rs_id",rightObj.getString("agr_rs_id"))
      newObj.put("belong_name",rightObj.getString("belong_name"))
      newObj.put("belong_id",rightObj.getString("belong_id"))
      newObj.put("belong_x",rightObj.getString("belong_x"))
      newObj.put("belong_y",rightObj.getString("belong_y"))
      newObj.put("src",rightObj.getString("src"))
      newObj.put("vehicle",leftObj.getString("vehicle"))
      newObj.put("vehicle_time",leftObj.getString("vehicle_time"))
      newObj.put("owner_id",leftObj.getString("owner_id"))
      newObj.put("owner_name",leftObj.getString("owner_name"))
      newObj.put("province_name",leftObj.getString("province_name"))
      newObj.put("city_name",leftObj.getString("city_name"))
      newObj.put("area_name",leftObj.getString("area_name"))
      newObj.put("area_manager_name",leftObj.getString("area_manager_name"))
      newObj.put("org_type",leftObj.getString("org_type"))
      newObj.put("credit_code",leftObj.getString("credit_code"))
      newObj.put("manager",leftObj.getString("manager"))
      newObj.put("manager_phone",leftObj.getString("manager_phone"))
      newObj.put("contactor",leftObj.getString("contactor"))
      newObj.put("contactor_phone",leftObj.getString("contactor_phone"))
      newObj.put("owner_type",leftObj.getString("owner_type"))
      newObj.put("clue_type",rightObj.getString("clue_type"))
      newObj
    }).map(obj=>{
      (obj.getString("unique_id"),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("aoi、drop关联后数据量："+dropJoinAoiRdd.count())
    //dropJoinAoiRdd.take(10).foreach(println(_))
    val belongJoinOwnDf: DataFrame = belongInfoRdd.repartition(600).map(obj => {
      (obj.getString("unique_id"), obj)
    }).join(dropJoinAoiRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      rightObj.put("stay_adcode", leftObj.getString("stay_adcode"))
      rightObj.put("stay_province", leftObj.getString("stay_province"))
      rightObj.put("stay_city", leftObj.getString("stay_city"))
      rightObj.put("stay_district", leftObj.getString("stay_district"))
      rightObj
    }).map(obj => {
      BelongJoinOwn(
        obj.getString("unique_id"),
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_id"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("vehicle"),
        obj.getString("vehicle_time"),
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        obj.getString("area_name"),
        obj.getString("area_manager_name"),
        obj.getString("org_type"),
        obj.getString("credit_code"),
        obj.getString("manager"),
        obj.getString("manager_phone"),
        obj.getString("contactor"),
        obj.getString("contactor_phone"),
        obj.getString("owner_type"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        obj.getString("task_batch"),
        obj.getString("inc_day"),
        obj.getString("clue_type")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("aoi、drop、belong关联后数据量："+belongJoinOwnDf.count())
    dropJoinAoiRdd.unpersist()
    belongJoinOwnInsertTable(spark,belongJoinOwnDf)
    //belongJoinOwnDf.createOrReplaceTempView("belongJoinOwnTmp")
    //belongJoinOwnDf.createOrReplaceTempView("belongJoinOwnTmp1")
    val belongJoinOwnSql=
      s"""
        |insert overwrite table dm_gis.dwd_ddjy_belong_owner_info_di
        |select
        |unique_id,agr_id,agr_rs_id,belong_name,belong_id,belong_x,belong_y,src,vehicle,vehicle_time,owner_id,owner_name,province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,stay_adcode,stay_province,stay_city,stay_district,task_count,vehicle_count,
        |if(round(task_count/7,0)=0,1,round(task_count/7,0)) as task_count_per_day,
        |task_count*202 as oil_sum,
        |task_count*202/7 as oil_sum_per_day,
        |'' as active_status,
        |'7' as task_day_count,
        |'1' as clue_src,
        |'$task_batch' as task_batch,
        |'$incDay' as incDay,
        |clue_type
        |from
        |(
        |	select
        |	t1.*,task_count,vehicle_count,
        |	row_number() over(partition by t1.unique_id,t1.owner_id order by vehicle_time desc) as rnk
        |	from dm_gis.dwd_ddjy_belong_join_own_di t1
        |	left join
        |	(
        |		select unique_id,owner_id,
        |		count(agr_id) as task_count,
        |		count(distinct vehicle) as vehicle_count
        |		from dm_gis.dwd_ddjy_belong_join_own_di
        |		group by unique_id,owner_id
        |	) t2
        |	on t1.unique_id=t2.unique_id and t1.owner_id=t2.owner_id
        |) t3
        |where rnk=1
        |""".stripMargin
    spark.sql(belongJoinOwnSql)
    belongJoinOwnDf.unpersist()
  }

  def readGasInfoData(spark: SparkSession, incDay: String) = {
    //调油站接口返回数据
    val url="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData?src=0&lastTimeStamp=0"
    val ret: JSONObject = HttpInvokeUtil.httpGetJSON(url,3)
    val data = JSONUtil.getJsonArrayMulti(ret, "data").toArray()
    val stationInfoRdd: RDD[JSONObject] = spark.sparkContext.parallelize(data).map(obj=>{
      val tmpObj: JSONObject = obj.asInstanceOf[JSONObject]
      tmpObj
    }).filter(obj=>{
      obj.getInteger("delFlag")==0
    }).map(obj=>{
      val addr: String = obj.getString("addr").replace("\t", "")
      val src: Int = obj.getInteger("src")
      obj.put("addr",addr)
      obj.put("station_src",src)
      obj.remove("src")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调油站接口返回数据量："+stationInfoRdd.count())
    stationInfoRdd.take(10).foreach(println(_))
    stationInfoRdd
  }

  def joinBelongStation(spark: SparkSession, belongInfoRdd: RDD[JSONObject], stationInfoRdd: RDD[JSONObject],task_batch:String, incDay: String) = {
    import spark.implicits._
    val cal = Calendar.getInstance
    val time = cal.getTime
    val create_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time)

    val belongInfoMapRdd: RDD[(String, JSONObject)] = belongInfoRdd.map(obj => {
      (obj.getString("stay_city"), obj)
    })
    val filterDistanceRdd: RDD[JSONObject] = stationInfoRdd.repartition(600).map(obj => {
      (obj.getString("city"), obj)
    }).join(belongInfoMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.fluentPutAll(rightObj)
      leftObj
    }).filter(obj => {
      val belong_x: Double = obj.getDouble("belong_x")
      val belong_y: Double = obj.getDouble("belong_y")
      val lng: Double = obj.getDouble("lng")
      val lat: Double = obj.getDouble("lat")
      val distance: Double = DistanceUtils.getDistance(belong_x, belong_y, lng, lat)
      obj.put("distance", distance)
      distance < 5000.0
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("过滤直线距离小于5000的数据："+filterDistanceRdd.count())
    filterDistanceRdd.take(100).foreach(println(_))
    val belongGasRdd: RDD[JSONObject] = filterDistanceRdd.repartition(600)
      .map(obj=>{
        ((obj.getString("unique_id"),obj.getString("POIID")),obj)
      }).groupByKey().map(obj=>{
      obj._2.toList.minBy(_.getString("stay_city"))
    }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("根据unique_id和POIID去重后数据量："+belongGasRdd.count())
    val returnDisRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,belongGasRdd, SfNetInteface.normalPlanInterface, 50, "f086106db05b48e6b8cb103ead38d06a", 20000)
    returnDisRdd.take(10).foreach(println(_))

    val addDistanceRdd: RDD[JSONObject] = returnDisRdd.repartition(600).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val d_dist: Double = JSONUtil.getJsonDouble(result, "dist",Int.MaxValue)
      obj.put("d_dist", d_dist)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调高德规划接口后的数据量："+addDistanceRdd.count())
    //写入距离种子表
    val distanceSeedInfoDf: DataFrame = addDistanceRdd.map(obj => {
      DistanceSeedInfo(
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id"),
        obj.getString("POIID"),
        obj.getString("stationName"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("adcode"),
        obj.getString("addr"),
        obj.getString("lng"),
        obj.getString("lat"),
        obj.getString("distance"),
        obj.getString("d_dist"),
        create_time
      )
    }).toDF()
    distanceSeedInfoDf.createOrReplaceTempView("distanceSeedInfoTmp")
    spark.sql("insert overwrite table dm_gis.dwd_ddjy_cantonese_clue_gas_seed_info select * from distanceSeedInfoTmp")
    val distanceDf: DataFrame = addDistanceRdd.filter(obj => {
      val d_dist: Double = obj.getDoubleValue("d_dist")
      d_dist < 5000
    }).map(obj => {
      obj.put("dist_rank", "0-5")
      obj.put("task_batch", task_batch)
      obj.put("inc_day", incDay)
      obj
    }).map(obj => {
      BelongJoinStation(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        obj.getString("task_batch"),
        obj.getString("POIID"),
        obj.getString("srcId"),
        obj.getString("GRPID"),
        obj.getString("stationName"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("adcode"),
        obj.getString("addr"),
        obj.getDouble("lng"),
        obj.getDouble("lat"),
        obj.getInteger("queryBrandID"),
        obj.getInteger("management_model"),
        obj.getInteger("gasLocationType"),
        obj.getString("roadName"),
        obj.getString("roadID"),
        obj.getInteger("roadClass"),
        obj.getString("hasOilName"),
        obj.getString("businessHours"),
        obj.getString("tel"),
        obj.getString("headLabelList"),
        obj.getInteger("station_src"),
        obj.getInteger("delFlag"),
        obj.getString("updateTime"),
        obj.getString("createTime"),
        obj.getString("ss"),
        obj.getString("swid"),
        obj.getString("cooperateStatus"),
        obj.getString("distance"),
        obj.getString("d_dist"),
        obj.getString("dist_rank"),
        obj.getString("inc_day"),
        obj.getString("clue_type")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调高德规划并过滤距离小于5000后的数据量："+distanceDf.count())
    distanceDf.createOrReplaceTempView("distanceTmp")
    val stationClueSql=
      s"""
        |insert overwrite table dm_gis.dwd_ddjy_cantonese_station_clue_di partition(inc_day)
        |select
        |agr_id,agr_rs_id,belong_name,belong_x,belong_y,src,unique_id,stay_adcode,stay_province,stay_city,stay_district,
        |'$task_batch' as task_batch,
        |poiid,srcid,grpid,stationname,province,city,district,adcode,addr,lng,lat,querybrandid,management_model,gaslocationtype,roadname,roadid,roadclass,hasoilname,businesshours,tel,headlabellist,station_src,delflag,updatetime,createtime,ss,swid,cooperatestatus,distance,d_dist,dist_rank,
        |if(max_cooperatestatus>=2,'1','0') as active_status,
        |'1' as clue_src,
        |clue_type,
        |'$incDay' as inc_day
        |from
        |(
        |	select
        |	*,
        |	max(cooperatestatus) over(partition by unique_id) as max_cooperatestatus
        |	from distanceTmp
        |) t1
        |""".stripMargin
    spark.sql(stationClueSql)
    filterDistanceRdd.unpersist()
    belongGasRdd.unpersist()
    addDistanceRdd.unpersist()
    distanceDf.unpersist()
  }

  def readCntoneseStationData(spark: SparkSession, incDay: String) = {
    val cntoneseStationSql=
      s"""
        |select *
        |from dm_gis.dwd_ddjy_cantonese_station_clue_di
        |where inc_day='$incDay'
        |""".stripMargin
    val cntoneseStationDf: DataFrame = spark.sql(cntoneseStationSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val cntoneseStationRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, cntoneseStationDf)
    (cntoneseStationDf,cntoneseStationRdd)
  }

  def readBelongOwnerData(spark: SparkSession, inc_day: String) = {
    val belongOwnerSql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_belong_owner_info_di
         |""".stripMargin
    val belongOwnerDf: DataFrame = spark.sql(belongOwnerSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    belongOwnerDf
  }



  def cantoneseClueInfo(spark: SparkSession, belongInfoRdd: RDD[JSONObject], cntoneseStationRdd: RDD[JSONObject], belongOwnerDf: DataFrame, cntoneseStationDf: DataFrame, task_batch:String, incDay: String) = {
    import spark.implicits._
    val cntoneseStationGroupRdd: RDD[(String, JSONObject)] = cntoneseStationRdd.map(obj => {
      (obj.getString("unique_id"), obj)
    }).groupByKey().map(obj=>{
      (obj._1,obj._2.toList.minBy(json=>{JSONUtil.getJsonValSingle(json,"createtime") }))
    })
    val belongInfoFilterDf: DataFrame = belongInfoRdd
     /* .map(obj => {
      (obj.getString("unique_id"), obj)
    }).leftOuterJoin(cntoneseStationGroupRdd).filter(obj => {
      val rightObj: JSONObject = obj._2._2.orNull
      rightObj != null
    }).map(obj => {
      val leftObj: JSONObject = obj._2._1
      leftObj
    })*/
      .map(obj => {
      BelongInfo(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        obj.getString("task_batch"),
        obj.getString("inc_day"),
        obj.getString("clue_type")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤belonginfo后数据量："+belongInfoFilterDf.count())
    belongInfoFilterDf.where("unique_id='00074f9be2305daecf26614cae6fdc27'").show(10)
    //belongInfoFilterDf.show(10,false)
    belongInfoFilterDf.createOrReplaceTempView("belongInfoFilterTmp")

    belongOwnerDf.createOrReplaceTempView("belongOwnerTmp")
    cntoneseStationDf.createOrReplaceTempView("cntoneseStationTmp")
    val joinBelongOwnerStationSql=
      """
        |select
        |t1.*,
        |concat(stay_province,stay_city,stay_district,belong_name) as clue_addr,
        |task_count,carrier_count,vehicle_count,
        |'0' as dept_transfer_flag,
        |'1' as clue_src,
        |'中国大陆' as country_name,
        |'0' as delete_flg,
        |'7' as task_day_count,
        |if(round(task_count/7,0)=0,'1',round(task_count/7,0)) as task_count_per_day,
        |task_count*202 as oil_sum,
        |task_count*202/7 as oil_sum_per_day,
        |nvl(gas_count,0) as gas_count,
        |nvl(national_gas_count,0) as national_gas_count,
        |nvl(private_gas_count,0) as private_gas_count,
        |nvl(active_status,0) as active_status
        |from belongInfoFilterTmp t1
        |join
        |(
        |	select unique_id,
        |	sum(task_count) as task_count,
        |	count(distinct owner_id) as carrier_count,
        |	count(distinct vehicle) as vehicle_count
        |	from belongOwnerTmp
        |	group by unique_id
        |) t2
        |on t1.unique_id=t2.unique_id
        |left join
        |(
        |	select unique_id,
        |	count(distinct srcId) as gas_count,
        |	count(distinct if(management_model=0,srcId,null)) as national_gas_count,
        |	count(distinct if(management_model=1,srcId,null)) as private_gas_count,
        |	max(active_status) as active_status
        |	from cntoneseStationTmp
        |	group by unique_id
        |) t3
        |on t1.unique_id=t3.unique_id
        |""".stripMargin
    val joinBelongOwnerStationDf: DataFrame = spark.sql(joinBelongOwnerStationSql)
    val joinBelongOwnerStationRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, joinBelongOwnerStationDf).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("belongInfo、belongOwner和cntoneseStation关联后的数据量："+joinBelongOwnerStationRdd.count())
    val noDuplicateUniqueidRdd: RDD[JSONObject] = joinBelongOwnerStationRdd.map(obj => {
      (obj.getString("unique_id"), obj)
    }).groupByKey().map(obj => {
      obj._2.toList.minBy(json => JSONUtil.getJsonValSingle(json, "unique_id"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val stationRdd: RDD[(String, JSONObject)] = noDuplicateUniqueidRdd.map(obj => {
      val tmpObj = new JSONObject()
      val clue_id: String = obj.getString("unique_id")
      val adcode: String = obj.getString("stay_adcode")
      val x: Double = obj.getDouble("belong_x")
      val y: Double = obj.getDouble("belong_y")
      tmpObj.put("clue_id", clue_id)
      tmpObj.put("adcode", adcode)
      tmpObj.put("x", x)
      tmpObj.put("y", y)
      (adcode, tmpObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val returnRdd: RDD[(String, JSONObject)] = stationRdd.groupByKey().repartition(5).flatMap(obj=>{
      val stations: Array[JSONObject] = obj._2.toArray
      val stationsObj = new JSONObject()
      stationsObj.put("stations",stations)
      val returnObj: JSONObject = SfNetInteface.stationClusterInterface(stationsObj)
      val resultsArray: JSONArray = JSONUtil.getJsonArrayMulti(returnObj, "api_result.results")
      val tmpList = new util.ArrayList[JSONObject]()
      for (i <- 0 until resultsArray.size()) {
        val tmpObj = new JSONObject()
        val resultObj: JSONObject = resultsArray.getJSONObject(i)
        tmpObj.fluentPutAll(resultObj)
        tmpList.add(tmpObj)
      }
      tmpList.iterator()
    }).map(obj=>{
      (obj.getString("clue_id"),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取集散圈接口返回数据量："+returnRdd.count())
    //returnRdd.take(10).foreach(println(_))
    val cantoneseClueDf: DataFrame = noDuplicateUniqueidRdd.repartition(600).map(obj => {
      (obj.getString("unique_id"), obj)
    }).leftOuterJoin(returnRdd).map(obj=>{
      val rightObj: JSONObject = obj._2._2.getOrElse(new JSONObject())
      val leftObj: JSONObject = obj._2._1
      val center_x: String = JSONUtil.getJsonValSingle(rightObj,"center_x")
      val center_y: String = JSONUtil.getJsonValSingle(rightObj,"center_y")
      val circle_id_old: String = JSONUtil.getJsonValSingle(rightObj,"circle_id")
      val stay_adcode: String = leftObj.getString("stay_adcode")
      val circle_id:String=stay_adcode+"-"+circle_id_old
      leftObj.put("center_x", center_x)
      leftObj.put("center_y", center_y)
      leftObj.put("circle_id", circle_id)
      leftObj
    }).map(obj => {
      CantoneseClue(
        obj.getString("agr_id"),
        obj.getString("agr_rs_id"),
        obj.getString("belong_name"),
        obj.getString("belong_x"),
        obj.getString("belong_y"),
        obj.getString("src"),
        obj.getString("unique_id"),
        obj.getString("stay_adcode"),
        obj.getString("stay_province"),
        obj.getString("stay_city"),
        obj.getString("stay_district"),
        s"$task_batch",
        obj.getString("clue_addr"),
        obj.getString("task_count"),
        obj.getString("carrier_count"),
        obj.getString("vehicle_count"),
        obj.getString("dept_transfer_flag"),
        obj.getString("clue_src"),
        obj.getString("country_name"),
        obj.getString("delete_flg"),
        obj.getString("task_day_count"),
        obj.getString("task_count_per_day"),
        obj.getString("oil_sum"),
        obj.getString("oil_sum_per_day"),
        obj.getString("gas_count"),
        obj.getString("national_gas_count"),
        obj.getString("private_gas_count"),
        obj.getString("active_status"),
        obj.getString("circle_id"),
        obj.getDouble("center_x"),
        obj.getDouble("center_y"),
        obj.getString("clue_type")
      )
    }).toDF().distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调取集散圈接口并回挂后数据量："+cantoneseClueDf.count())
    cantoneseClueDf.createOrReplaceTempView("cantoneseClueTmp")
    val sql=s"insert overwrite table dm_gis.dwd_ddjy_cantonese_clue_info_di partition(inc_day='$incDay') select * from cantoneseClueTmp"
    logger.error(sql)
    spark.sql(sql)
    joinBelongOwnerStationRdd.unpersist()
    cantoneseClueDf.unpersist()
  }


  def cantoneseCarrierVehicle(spark: SparkSession, belongOwnerDf: DataFrame,cantoneseCarrierClueDf:DataFrame,task_batch:String, inc_day: String) = {
    cantoneseCarrierClueDf.createOrReplaceTempView("cantoneseCarrierClueTmp")
    belongOwnerDf.createOrReplaceTempView("belongOwnerTmp")
    logger.error("写入dwd_ddjy_cantonese_carrier_vehicle_di......")
    val cantoneseCarrierVehicleSql=
      s"""
        |insert overwrite table dm_gis.dwd_ddjy_cantonese_carrier_vehicle_di partition(inc_day='$inc_day')
        |select
        |t2.*
        |from
        |(
        |	select
        |	vehicle,
        |	'$task_batch' as task_batch,
        |	task_count,
        |	task_day_count,
        |	if(round(task_count/7,0)=0,'1',round(task_count/7,0)) as task_count_per_day,
        |	task_count*202 as oil_sum,
        |	task_count*202/7 as oil_sum_per_day,
        |	clue_src,
        |	carrier_id,
        |	carrier_name,
        |	clue_id,
        |	clue_name,
        |	province,
        |	city,
        |	district,
        |	adcode,
        | clue_type
        |	from
        |	(
        |		select
        |		vehicle,
        |		task_batch,
        |		sum(task_count) as task_count,
        |		'7' as task_day_count,
        |		'1' as clue_src,
        |		owner_id as carrier_id,
        |		owner_name as carrier_name,
        |		unique_id as clue_id,
        |		belong_name as clue_name,
        |		stay_province as province,
        |		stay_city as city,
        |		stay_district as district,
        |		stay_adcode as adcode,
        |   clue_type
        |		from belongOwnerTmp
        |		group by vehicle,task_batch,owner_id,owner_name,unique_id,belong_name,stay_province,stay_city,stay_district,stay_adcode,clue_type
        |	) t1
        |) t2
        |join
        |(
        |select
        |unique_id,owner_id
        |from cantoneseCarrierClueTmp
        |group by unique_id,owner_id
        |)
        |t3
        |on t2.clue_id=t3.unique_id and t2.carrier_id=t3.owner_id
        |""".stripMargin
    spark.sql(cantoneseCarrierVehicleSql)
  }

  def readCantoneseClueInfo(spark: SparkSession, inc_day: String) = {
    val cantoneseClueInfoSql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_cantonese_clue_info_di
         |where inc_day='$inc_day'
         |""".stripMargin
    val cantoneseClueInfoDf: DataFrame = spark.sql(cantoneseClueInfoSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    cantoneseClueInfoDf
  }

  def cantoneseCarrierClue(spark: SparkSession, belongOwnerDf: DataFrame, cantoneseClueInfoDf: DataFrame, cntoneseStationDf: DataFrame,task_batch:String, inc_day: String) = {
    belongOwnerDf.createOrReplaceTempView("belongOwnerTmp")
    cantoneseClueInfoDf.createOrReplaceTempView("cantoneseClueInfoTmp")
    cntoneseStationDf.createOrReplaceTempView("cntoneseStationTmp")
    logger.error("写入dwd_ddjy_cantonese_carrier_clue_di......")
    val cantoneseCarrierClueSql=
      s"""
         |insert overwrite table dm_gis.dwd_ddjy_cantonese_carrier_clue_di partition(inc_day='$inc_day')
         |select
         |unique_id,agr_id,agr_rs_id,belong_name,belong_id,belong_x,belong_y,src,vehicle,vehicle_time,owner_id,owner_name,province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,stay_adcode,stay_province,stay_city,stay_district,task_count,vehicle_count,task_count_per_day,oil_sum,oil_sum_per_day,active_status,task_day_count,clue_src,
         |'$task_batch' as task_batch,
         |clue_type
         |from belongOwnerTmp
         |""".stripMargin
    spark.sql(cantoneseCarrierClueSql)
  }

  def readCantoneseCarrierVehicle(spark: SparkSession, inc_day: String) = {
    val cantoneseCarrierVehicleSql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_cantonese_carrier_vehicle_di
         |where inc_day='$inc_day'
         |""".stripMargin
    val cantoneseCarrierVehicleDf: DataFrame = spark.sql(cantoneseCarrierVehicleSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    cantoneseCarrierVehicleDf
  }

  def readCantoneseCarrierClue(spark: SparkSession, inc_day: String): DataFrame = {
    val cantoneseCarrierClueSql=
      s"""
         |select *
         |from dm_gis.dwd_ddjy_cantonese_carrier_clue_di
         |where inc_day='$inc_day'
         |""".stripMargin
    val cantoneseCarrierClueDf: DataFrame = spark.sql(cantoneseCarrierClueSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    cantoneseCarrierClueDf
  }

  def clueCircleRslt(spark: SparkSession, cantoneseClueInfoDf: DataFrame, cantoneseCarrierClueDf: DataFrame, cantoneseCarrierVehicleDf: DataFrame, cntoneseStationDf: DataFrame,task_batch:String, inc_day: String) = {
    cantoneseClueInfoDf.createOrReplaceTempView("cantoneseClueInfoTmp")
    cantoneseClueInfoDf.createOrReplaceTempView("cantoneseClueInfoTmp1")
    cantoneseCarrierClueDf.createOrReplaceTempView("cantoneseCarrierClueTmp")
    cantoneseCarrierVehicleDf.createOrReplaceTempView("cantoneseCarrierVehicleTmp")
    cntoneseStationDf.createOrReplaceTempView("cntoneseStationTmp")
    logger.error("写入dwd_ddjy_clue_circle_rslt_di......")
    val clueCircleRsltSql=
      s"""
        |insert overwrite table dm_gis.dwd_ddjy_clue_circle_rslt_di partition(inc_day='$inc_day')
        |select
        |nvl(circle_id,''),
        |'$task_batch' as task_batch,
        |nvl(adcode,''),
        |nvl(province,''),
        |nvl(city,''),
        |nvl(district,''),
        |nvl(x,''),
        |nvl(y,''),
        |nvl(task_count,''),
        |nvl(carrier_count,''),
        |nvl(vehicle_count,''),
        |nvl(task_day_count,''),
        |nvl(plan_depart_tm_day_max,''),
        |nvl(plan_depart_tm_day_min,''),
        |nvl(dis_sum,''),
        |nvl(task_count_per_day,''),
        |nvl(dis_sum_per_day,''),
        |nvl(oil_sum,''),
        |nvl(oil_sum_per_day,''),
        |nvl(vehicle_distribution,''),
        |nvl(gas_count,''),
        |nvl(national_gas_count,''),
        |nvl(private_gas_count,''),
        |from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as update_time
        |from
        |(
        |	select
        |	t1.circle_id,
        |	task_batch,
        |	stay_adcode as adcode,
        |	stay_province as province,
        |	stay_city as city,
        |	stay_district as district,
        |	center_x as x,
        |	center_y as y,
        |	task_count,
        |	carrier_count,
        |	vehicle_count,
        |	'7' as task_day_count,
        |	'' as plan_depart_tm_day_max,
        |	'' as plan_depart_tm_day_min,
        |	'' as dis_sum,
        |	if(round(task_count/7,0)=0,'1',round(task_count/7,0)) as task_count_per_day,
        |	'' as dis_sum_per_day,
        |	task_count*202 as oil_sum,
        |	task_count*202/7 as oil_sum_per_day,
        |	'' as vehicle_distribution,
        |	gas_count,
        |	national_gas_count,
        |	private_gas_count,
        |	row_number() over(partition by t1.circle_id order by task_batch) as rnk
        |	from
        |	(
        |		select
        |		circle_id,task_batch,stay_adcode,stay_province,stay_city,stay_district,center_x,center_y
        |		from dm_gis.dwd_ddjy_cantonese_clue_info_di
        |		where inc_day='$inc_day'
        |		group by circle_id,task_batch,stay_adcode,stay_province,stay_city,stay_district,center_x,center_y
        |	) t1
        |	join
        |	(
        |		select
        |		e.circle_id,task_count,carrier_count,vehicle_count,
        |   nvl(gas_count,0) as gas_count,
        |   nvl(national_gas_count,0) as national_gas_count,
        |   nvl(private_gas_count,0) as private_gas_count
        |		from
        |		(
        |			select
        |			circle_id,
        |			count(distinct owner_id) as carrier_count,
        |			count(distinct vehicle) as vehicle_count,
        |			count(distinct poiid) as gas_count,
        |			count(distinct if(management_model=0,poiid,null)) as national_gas_count,
        |			count(distinct if(management_model=1,poiid,null)) as private_gas_count
        |			from
        |			(
        |			select
        |			circle_id,unique_id,task_count
        |			from dm_gis.dwd_ddjy_cantonese_clue_info_di
        |			where inc_day='$inc_day'
        |			group by circle_id,unique_id,task_count
        |			) a
        |			join
        |			(
        |			select
        |			unique_id,owner_id
        |			from cantoneseCarrierClueTmp
        |			group by unique_id,owner_id
        |			) b
        |			on a.unique_id=b.unique_id
        |			join
        |			(
        |			select
        |			clue_id,vehicle
        |			from cantoneseCarrierVehicleTmp
        |			group by clue_id,vehicle
        |			) c
        |			on a.unique_id==c.clue_id
        |			left join
        |			(
        |			select
        |			unique_id,poiid,management_model
        |			from cntoneseStationTmp
        |			group by unique_id,poiid,management_model
        |			) d
        |			on a.unique_id=d.unique_id
        |			group by circle_id
        |		) e
        |		left join
        |		(
        |			select
        |			circle_id,
        |			sum(task_count) as task_count
        |			from dm_gis.dwd_ddjy_cantonese_clue_info_di
        |			where inc_day='$inc_day'
        |			group by circle_id
        |		) f
        |		on e.circle_id=f.circle_id
        |	) t2
        |	on t1.circle_id=t2.circle_id
        |) t3
        |where rnk=1
        |""".stripMargin
    spark.sql(clueCircleRsltSql)
  }

  def clueCircleSeed(spark: SparkSession, incDay: String) = {
    //生成线索种子表
    val clueSeedSql=
      s"""
        |insert overwrite table dm_gis.dwd_ddjy_cantonese_clue_seed_info
        |select
        |unique_id
        |,belong_name
        |,belong_x
        |,belong_y
        |,stay_adcode
        |,stay_province
        |,stay_city
        |,stay_district
        |,task_batch
        |,clue_type
        |,from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as create_time
        |,from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as last_join_time
        |from dm_gis.dwd_ddjy_cantonese_clue_info_di
        |where inc_day='$incDay'
        |""".stripMargin
    spark.sql(clueSeedSql)
    //生成集散圈种子表
    val circleSeedSql=
      s"""
         |insert overwrite table dm_gis.dwd_ddjy_clue_circle_seed
         |select
         |unique_id
         |,belong_name
         |,stay_adcode
         |,stay_province
         |,stay_city
         |,stay_district
         |,circle_id
         |,center_x
         |,center_y
         |,from_unixtime(unix_timestamp(),"yyyy-MM-dd HH:mm:ss") as create_time
         |from dm_gis.dwd_ddjy_cantonese_clue_info_di
         |where inc_day='$incDay'
         |group by unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y
         |""".stripMargin
    spark.sql(circleSeedSql)
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    val start_day: String = DateUtil.getDayBefore(incDay, "yyyyMMdd", 6)
    val task_batch=start_day+"-"+incDay
    //读取single_agr_stat_all_drop_owner_tmp数据
    val dropOwnerRdd: RDD[JSONObject] = readDropOwnerData(spark, incDay)
    //调aoi接口
    dropOwnerAoiInterface(spark,dropOwnerRdd,incDay)
    //读取dwd_ddjy_logistics_vehicle_di表数据
    val logicticsDf: DataFrame = readLogicticsData(spark, incDay)
    //关联AOI重点类型数据
    joinAoiKeyType(spark,logicticsDf,incDay)
    //读取dwd_ddjy_aoi_not_key_di表数据
    val aoiNotKeyDf: DataFrame = readAoiNotKeyData(spark, incDay)
    //AOI非重点类型数据调用POI接口
    aoiNotKeyPoiInterface(spark, aoiNotKeyDf, incDay)
    //读取dwd_ddjy_aoi_not_key_poi_di表数据
    val aoiNotKeyPoiDf: DataFrame = readAoiNotKeyPoiData(spark, incDay)
    //过滤poi数据得出最终poi表
    processPoiData(spark,aoiNotKeyPoiDf,incDay)
    //读取dwd_ddjy_aoi_key_di和dwd_ddjy_poi_final_di表
    val aoiPoiRdd: RDD[JSONObject] = readAoiKeyAndPoi(spark, incDay)
    //处理aoi_poi数据
    processAoiPoi(spark,aoiPoiRdd,task_batch,incDay)
    //读取dwd_ddjy_belong_info_di表数据
    val belongInfoRdd: RDD[JSONObject] = readBelongInfoData(spark, incDay)
    //关联belong_info、aoiPoi、dropOwner
    joinAoiPoiBelongDropOwnerInfoData(spark,aoiPoiRdd,dropOwnerRdd,belongInfoRdd,task_batch,incDay)
    //读取油站信息表
    val stationInfoRdd: RDD[JSONObject] = readGasInfoData(spark, incDay)
    //关联belong_info和station_info表
    joinBelongStation(spark,belongInfoRdd,stationInfoRdd,task_batch,incDay)
    //读取dwd_ddjy_cantonese_station_clue_di表数据
    val (cntoneseStationDf,cntoneseStationRdd) = readCntoneseStationData(spark, incDay)
    //读取dwd_ddjy_belong_owner_info_di表数据
    val belongOwnerDf: DataFrame = readBelongOwnerData(spark, incDay)
    //生成cantonese_clue_info表
    cantoneseClueInfo(spark,belongInfoRdd,cntoneseStationRdd,belongOwnerDf,cntoneseStationDf,task_batch,incDay)
    //读取dwd_ddjy_cantonese_clue_info_di表数据
    val cantoneseClueInfoDf: DataFrame = readCantoneseClueInfo(spark, incDay)
    //生成Cantonese_carrier_clue_info表
    cantoneseCarrierClue(spark,belongOwnerDf,cantoneseClueInfoDf,cntoneseStationDf,task_batch,incDay)
    //读取Cantonese_carrier_clue_info表
    val cantoneseCarrierClueDf: DataFrame = readCantoneseCarrierClue(spark, incDay)
    //生成Cantonese_carrier_vehicle_info表
    cantoneseCarrierVehicle(spark,belongOwnerDf,cantoneseCarrierClueDf,task_batch,incDay)
    //读取Cantonese_carrier_vehicle_info表
    val cantoneseCarrierVehicleDf: DataFrame = readCantoneseCarrierVehicle(spark, incDay)
    //生成clue_circle_rslt表
    clueCircleRslt(spark,cantoneseClueInfoDf,cantoneseCarrierClueDf,cantoneseCarrierVehicleDf,cntoneseStationDf,task_batch,incDay)
    //生成线索种子表和集散圈种子表
    clueCircleSeed(spark,incDay)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    //execute()
    logger.error("======>>>>>>YueYunClueMap Execute Ok")
  }

  case class DistanceSeedInfo(belong_name:String,
                              belong_x:String,
                              belong_y:String,
                              src:String,
                              unique_id:String,
                              poiid:String,
                              stationname:String,
                              province:String,
                              city:String,
                              district:String,
                              adcode:String,
                              addr:String,
                              lng:String,
                              lat:String,
                              distance:String,
                              d_dist:String,
                              create_time:String
                             )
}
