package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description新老车队报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:360
 * 任务名称：新老车队报表
 * 依赖任务：每日-车队历史充值记录表 498、吨吨加油-订单过滤明细表去重 352、每日-原始油站信息过滤表 512、流失车队报表 359
 * 数据源：ddjy_dwd_station_order_pay_repartition_di、dwd_ddjy_station_team_di、ddjy_dwd_car_team_history_recharge
 * 调用服务地址：无
 * 数据结果：dm_ddjy_uimp_old_new_team_gmv_di
 */
object CollectionNewOldTeamData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def dateStream(fromDt:LocalDate):Stream[LocalDate]={
    fromDt #::dateStream(fromDt.plusDays(1))
  }

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String) = {
    val oldNewTeamDf: DataFrame = spark.sql(
      s"""
         |select
         |province_name,city_name,t6.car_team_id,
         |round(nvl(sum(ft_sale_money),0.00),2) as ft_sale_money,
         |tag,
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`
         |from
         |(
         |	select
         |	car_team_id,station_id,
         |	sum(ft_sale_money) as ft_sale_money
         |	FROM dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |	WHERE inc_day='${inc_day}'
         |	and order_status='2'
         |	group by car_team_id,station_id
         |) t6
         |left join
         |(
         |	select
         |	province_name,city_name,car_team_id,tag,station_id
         |	from
         |	(
         |		select
         |		province_name,city_name,car_team_id,station_id,tag,station_id
         |		from
         |		(
         |			select
         |			province_name,city_name,
         |			station_id,
         |			car_team_id
         |			FROM dm_gis.dwd_ddjy_station_team_di
         |			WHERE inc_day='${inc_day}' and replace(max_pay_day,'-','')='${inc_day}'
         |			group by province_name,city_name,station_id,car_team_id
         |		) t2
         |		left join
         |		(
         |			select
         |			team_id,tag
         |			from
         |			(
         |				select
         |				team_id,
         |				case when substr(replace(substr(min_trade_time,0,10),'-',''),0,6)<substr('${inc_day}',0,6) then 'old_client'
         |					 when substr(replace(substr(min_trade_time,0,10),'-',''),0,6)=substr('${inc_day}',0,6) then 'new_client'
         |					 end as tag
         |				from
         |				(
         |					select
         |					team_id,
         |					min(trade_time) as min_trade_time
         |					from dm_gis.ddjy_dwd_car_team_history_recharge
         |					where inc_day<='${inc_day}'
         |					and account_name not REGEXP 'FT'
         |					and account_name not REGEXP '测试'
         |					and account_name not REGEXP '演示'
         |					and account_name not REGEXP '商务车队'
         |					and trade_description = '车队充值上账'
         |					group by team_id
         |				) t1
         |			) t2
         |			where tag is not null and tag!=''
         |			group by team_id,tag
         |		) t3
         |		on t2.car_team_id=t3.team_id
         |	) t4
         |	group by province_name,city_name,car_team_id,tag,station_id
         |) t7
         |on t6.car_team_id=t7.car_team_id and t6.station_id=t7.station_id
         |group by province_name,city_name,t6.car_team_id,tag
         |""".stripMargin)
    oldNewTeamDf.repartition(1).createOrReplaceTempView("oldNewTeamTmp")
    spark.sql(s"insert overwrite table dm_gis.dm_ddjy_uimp_old_new_team_gmv_di partition(inc_day='${inc_day}') select * from oldNewTeamTmp")
    logger.error("写入dm_ddjy_uimp_old_new_team_gmv_di每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    var before_yesterday=""
    var last_seven_day: String=""
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      before_yesterday = DateUtil.getDateStr(incDay, -1, "")
      last_seven_day = DateUtil.getDateStr(incDay, -6, "")
      stationProcess(spark,incDay,before_yesterday,last_seven_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>新老车队 Execute Ok")
  }

}
