package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SparkUtils, SparkWrite}

/**
 * @Description:集散圈线索明细月维度表
 * 需求人员：周韵筹 01425211
 * @Author: lixiangzhi 01405644
 * @Date:20231213
 * 任务id:1096
 * 任务名称：集散圈线索明细月维度表
 * 依赖任务：
 * 数据源：
 * 调用服务地址：无
 * 数据结果：dm_ddjy_circle_gas_carrier_info_di_month
 */
object CircleGasCarrierInfoMonth {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)



  def readCircleGasCarrierInfo(spark: SparkSession, incDay: String) = {
    val lastMonthDay: String = DateUtil.getDateStr(incDay, -30, "")
    val circleGasCarrierInfoSql=
      s"""
        |select
        |poiid,gas_circle_id,inc_day
        |from dm_gis.dm_ddjy_circle_gas_carrier_info_di
        |where inc_day>='${lastMonthDay}' and inc_day<='${incDay}'
        |""".stripMargin
    val circleGasCarrierInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, circleGasCarrierInfoSql, 2000).groupBy(_.getString("poiid")).map(obj => {
      val tmpObj: JSONObject = obj._2.toList.maxBy(_.getString("inc_day"))
      tmpObj.put("biz_day", tmpObj.getString("inc_day"))
      (obj._1,tmpObj)
    })
    circleGasCarrierInfoRdd
  }

  def summaryIndicator(spark: SparkSession, circleGasCarrierInfoRdd: RDD[(String, JSONObject)], incDay: String) = {
    import spark.implicits._
    //读取dm_ddjy_gas_station_info_di
    val gasStationInfoSql=
      """
        |select poiid,
        |stationname,
        |province as gas_province,
        |city as gas_city,
        |district as gas_district,
        |addr,cooperatestatus,
        |management_model,
        |querybrandid,
        |gappricevec,priceactivityvec,stationtype,stationalias,pricedieselout,officialGapPrice
        |from dm_gis.dm_ddjy_gas_station_info_di
        |where delflag = '0'
        |""".stripMargin
    val gasStationInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, gasStationInfoSql).map(obj => {
      (obj.getString("poiid"), obj)
    })
    val lastMonthDay: String = DateUtil.getDateStr(incDay, -30, "")
    //读取dm_ddjy_circle_gas_carrier_info_di
    val circleIdInfoSql=
      s"""
         |select
         |circle_id,circle_name,adcode,province,city,district,x,y,inc_day
         |from dm_gis.dm_ddjy_circle_gas_carrier_info_di
         |where inc_day>='${lastMonthDay}' and inc_day<='${incDay}'
         |""".stripMargin
    val circleInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, circleIdInfoSql, 2000).groupBy(_.getString("circle_id")).map(obj => {
      val tmpObj: JSONObject = obj._2.toList.maxBy(json=>{
        JSONUtil.getJsonValSingle(json,"inc_day")
      })
      (obj._1,tmpObj)
    })
    //读取dm_ddjy_carrier_rlst_di_month
    val carrierRsltMonthSql=
      s"""
         |select
         |carrier_id,carrier_name,carrier_status,carrier_tag,register_vehicle_count,
         |province as carrier_province,
         |city as carrier_city
         |from dm_gis.dm_ddjy_carrier_rlst_di_month
         |where inc_day='$incDay'
         |""".stripMargin
    val carrierRsltMonthRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, carrierRsltMonthSql).map(obj => {
      (obj.getString("carrier_id"), obj)
    })
    //读取ddjy_dwd_station_stream_detail
    val stationStreamSql=
      s"""
         |select
         |car_team_id,first_trade_date,first_pay_date
         |from dm_gis.ddjy_dwd_station_stream_detail
         |where inc_day='$incDay'
         |""".stripMargin
    val stationStreamRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, stationStreamSql).groupBy(_.getString("car_team_id")).map(obj => {
      val tmpObj: JSONObject = obj._2.toList.minBy(_.getString("first_pay_date"))
      (obj._1, tmpObj)
    })
    //读取ddjy_dim_team_info_filter
    val teamInfoSql=
      """
        |select
        |id,name
        |from dm_gis.ddjy_dim_team_info_filter
        |where inc_day in(select max(inc_day) from dm_gis.ddjy_dim_team_info_filter)
        |and del_flag='0'
        |and name!=''
        |and name is not null
        |""".stripMargin
    val teamInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, teamInfoSql).map(obj => {
      (obj.getString("id"), obj)
    })
    val nameRdd: RDD[(String, JSONObject)] = stationStreamRdd.join(teamInfoRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.put("name", rightObj.getString("name"))
      (leftObj.getString("name"),leftObj)
    })
    //读取ddjy_ods_sales_team
    val salesTeamSql=
      s"""
         |select
         |team_id,sup_name
         |from dm_gis.ddjy_ods_sales_team
         |where inc_day in(select max(inc_day) from dm_gis.ddjy_ods_sales_team)
         |and deleted=0
         |and sup_name not like '%FT%'
         |""".stripMargin
    val salesTeamRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, salesTeamSql).map(obj => {
      (obj.getString("team_id"), obj)
    })
    val supnameRdd: RDD[(String, JSONObject)] = teamInfoRdd.leftOuterJoin(salesTeamRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      (leftObj.getString("name"),leftObj)
    })
    val update_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance.getTime)
    //读取dm_ddjy_gas_carrier_merge_di_month
    val gasCarrierMergeMonthSql=
      s"""
        |select
        |carrier_id,gas_id,task_sum_count,clue_task_count
        |from dm_gis.dm_ddjy_gas_carrier_merge_di_month
        |where inc_day='$incDay'
        |""".stripMargin
    val gasCarrierMergeMonthRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, gasCarrierMergeMonthSql, 2000).map(obj => {
      ((obj.getString("carrier_id"), obj.getString("gas_id")), obj)
    }).groupByKey().map(obj => {
      val tmpObj: JSONObject = obj._2.toList.maxBy(_.getIntValue("task_sum_count"))
      val clue_task_count: Int = tmpObj.getIntValue("clue_task_count")
      var clue_task_flag=0
      if (clue_task_count!=0){
        clue_task_flag=1
      }
      tmpObj.put("clue_task_flag",clue_task_flag)
      tmpObj
    })

    val circleGasCarrierInfoMonthDf: DataFrame = gasCarrierMergeMonthRdd.map(obj => {
      (obj.getString("gas_id"), obj)
    }).join(circleGasCarrierInfoRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.fluentPutAll(rightObj)
      (obj._1,leftObj)
    }).join(gasStationInfoRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.fluentPutAll(rightObj)
      (leftObj.getString("gas_circle_id"), leftObj)
    }).leftOuterJoin(circleInfoRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      (leftObj.getString("carrier_id"),leftObj)
    }).leftOuterJoin(carrierRsltMonthRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.fluentPutAll(rightObj)
      }
      (leftObj.getString("carrier_name"),leftObj)
    }).leftOuterJoin(nameRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      (obj._1, leftObj)
    }).leftOuterJoin(supnameRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("org_district", rightObj.getString("sup_name"))
      }
      val register_vehicle_count: Int = leftObj.getIntValue("register_vehicle_count")
      var carrier_scale = "暂无信息"
      if (register_vehicle_count == 1) {
        carrier_scale = "1"
      } else if (register_vehicle_count >= 2 && register_vehicle_count <= 3) {
        carrier_scale = "2~3"
      } else if (register_vehicle_count >= 4 && register_vehicle_count <= 8) {
        carrier_scale = "4~8"
      } else if (register_vehicle_count >= 9 && register_vehicle_count <= 14) {
        carrier_scale = "9~14"
      } else if (register_vehicle_count >= 15 && register_vehicle_count <= 20) {
        carrier_scale = "15~20"
      } else if (register_vehicle_count >= 21) {
        carrier_scale = "20+"
      }
      val name: String = leftObj.getString("name")
      var carrier_status = 0
      if (StringUtils.isNoneEmpty(name)) {
        carrier_status = 1
      }
      leftObj.put("carrier_status",carrier_status)
      leftObj.put("carrier_scale",carrier_scale)
      leftObj
    }).map(obj => {
      CaseCircleGasCarrierInfoMonth(
        obj.getString("circle_id"),
        obj.getString("circle_name"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("x"),
        obj.getString("y"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("register_vehicle_count"),
        obj.getString("carrier_province"),
        obj.getString("carrier_city"),
        obj.getString("carrier_scale"),
        obj.getString("gas_circle_id"),
        obj.getString("gas_province"),
        obj.getString("gas_city"),
        obj.getString("gas_district"),
        obj.getString("poiid"),
        obj.getString("stationname"),
        obj.getString("addr"),
        obj.getString("cooperatestatus"),
        obj.getString("management_model"),
        obj.getString("querybrandid"),
        obj.getString("gappricevec"),
        obj.getString("priceactivityvec"),
        obj.getString("task_sum_count"),
        obj.getString("org_district"),
        obj.getString("first_trade_date"),
        obj.getString("first_pay_date"),
        obj.getString("clue_task_flag"),
        obj.getString("stationalias"),
        obj.getString("stationtype"),
        obj.getString("pricedieselout"),
        update_time,
        obj.getString("biz_day"),
        obj.getString("officialGapPrice")
      )
    }).toDF().select('circle_id
    ,'circle_name
    ,'adcode
    ,'province
    ,'city
    ,'district
    ,'x
    ,'y
    ,'carrier_id
    ,'carrier_name
    ,'carrier_status
    ,'carrier_tag
    ,'register_vehicle_count
    ,'carrier_province
    ,'carrier_city
    ,'carrier_scale
    ,'gas_circle_id
    ,'gas_province
    ,'gas_city
    ,'gas_district
    ,'poiid
    ,'stationname
    ,'addr
    ,'cooperatestatus
    ,'management_model
    ,'querybrandid
    ,'gappricevec
    ,'priceactivityvec
    ,'task_count
    ,'org_district
    ,'first_trade_date
    ,'first_pay_date
    ,'clue_task_flag
    ,'stationalias
    ,'stationtype
    ,'pricedieselout
    ,'update_time
    ,'biz_day
    ,'officialgapprice
    )

    circleGasCarrierInfoMonthDf.show(1,false)
    SparkWrite.writeToHive(spark,circleGasCarrierInfoMonthDf,"inc_day",incDay,"dm_gis.dm_ddjy_circle_gas_carrier_info_di_month",50)

  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取dm_ddjy_circle_gas_carrier_info_di
    val circleGasCarrierInfoRdd: RDD[(String, JSONObject)] = readCircleGasCarrierInfo(spark, incDay)
    //汇总各指标
    summaryIndicator(spark,circleGasCarrierInfoRdd,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseCircleGasCarrierInfoMonth(
                                            circle_id:String,
                                            circle_name:String,
                                            adcode:String,
                                            province:String,
                                            city:String,
                                            district:String,
                                            x:String,
                                            y:String,
                                            carrier_id:String,
                                            carrier_name:String,
                                            carrier_status:String,
                                            carrier_tag:String,
                                            register_vehicle_count:String,
                                            carrier_province:String,
                                            carrier_city:String,
                                            carrier_scale:String,
                                            gas_circle_id:String,
                                            gas_province:String,
                                            gas_city:String,
                                            gas_district:String,
                                            poiid:String,
                                            stationname:String,
                                            addr:String,
                                            cooperatestatus:String,
                                            management_model:String,
                                            querybrandid:String,
                                            gappricevec:String,
                                            priceactivityvec:String,
                                            task_count:String,
                                            org_district:String,
                                            first_trade_date:String,
                                            first_pay_date:String,
                                            clue_task_flag:String,
                                            stationalias:String,
                                            stationtype:String,
                                            pricedieselout:String,
                                            update_time:String,
                                            biz_day:String,
                                            officialGapPrice:String
                                 )

}
