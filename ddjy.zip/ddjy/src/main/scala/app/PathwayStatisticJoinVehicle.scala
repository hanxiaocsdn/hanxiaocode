package app

import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.SparkWrite

/**
 * @Description:车队业务分布中间表
 * 需求人员：左佳怡 01403789
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2022/11/26
 * 任务id:481
 * 任务名称：车队业务分布统计表
 * 依赖任务：车辆归属更新638
 * 数据源：ddjy_station_pathway_statistic_clue_di、dim_ddjy_vehicle_concat_yy_df、ddjy_station_pathway_statistic_clue_sf_di、dundun_inner_outer_traj_info
 * 调用服务地址：
 * 数据结果：ddjy_pathway_statistic_join_vehicle_concat_di
 */
object PathwayStatisticJoinVehicle {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def updatePathwayStatisticJoinVehicle(spark: SparkSession, max_day: String, vehicle_max_day: String,after_one_day:String,incDay:String) = {
    logger.error("正在执行 ddjy_pathway_statistic_join_vehicle_concat_di 任务.........")
    val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
    val vehicle_clue_detail_sql=
      s"""
        |
        |select
        |poiid,stationname,province,city,district,coords,trackno,priority_tj,priority_zb,
        |owner_id as car_team_id,
        |owner_name as car_team_name,
        |'yy' as source
        |from
        |(
        |	select
        |	poiid,
        |	stationname,
        |	province,
        |	city,
        |	district,
        |	concat(lng,',',lat) as coords,
        |	trackno,
        |	priority_tj,
        |	priority_zb
        |	from dm_gis.ddjy_station_pathway_statistic_clue_di
        |	where inc_day='${max_day}'
        |) t1
        |left join
        |(
        |	select
        |	vehicle_no,
        |	owner_id,
        |	owner_name
        |	from dm_gis.ddjy_vehicle_ownership_day_dtl
        |	where inc_day='${before_yesterday}'
        |) t2
        |on t1.trackno=t2.vehicle_no
        |union all
        |select
        |a.poiid as poiid,
        |a.stationname as stationname,
        |a.province as province,
        |a.city as city,
        |a.district as district,
        |a.coords as coords,
        |a.trackno as trackno,
        |a.priority_tj as priority_tj,
        |a.priority_zb as priority_zb,
        |'' as car_team_id,
        |b.carrier_name as car_team_name,
        |'sf' as source
        |from
        |(
        |	select
        |	poiid,
        |	stationname,
        |	province,
        |	city,
        |	district,
        |	concat(lng, ',' ,lat) as coords,
        |	trackno,
        |	priority_tj,
        |	priority_zb
        |	from dm_gis.ddjy_station_pathway_statistic_clue_sf_di
        |	where inc_day = '${max_day}'
        |) a
        |left join (
        |	select
        |	Distinct un, carrier_name
        |	from dm_gis.dundun_inner_outer_traj_info
        |	where inc_day = '${after_one_day}'
        |	and source = 'sf'
        |	and un is not null
        |) b on a.trackno = b.un
        |""".stripMargin
    val resultDf: DataFrame = spark.sql(vehicle_clue_detail_sql)
    SparkWrite.writeToHiveNoPart(spark,resultDf,"dm_gis.ddjy_pathway_statistic_join_vehicle_concat_di")

    //insert overwrite table dm_gis.ddjy_pathway_statistic_join_vehicle_concat_di
  }

  def execute(incDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val pathway_statistic_clue_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.ddjy_station_pathway_statistic_clue_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val pathway_statistic_clue_df: DataFrame = spark.sql(pathway_statistic_clue_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, pathway_statistic_clue_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    val after_one_day = DateUtil.getDateStr(max_day, 1, "")
    logger.error("分区最大值1天后的日期："+after_one_day)
    //获取车辆所属车队维表分区最大值
    val vehicle_max_day_sql=
      s"""
        |select
        |max(inc_day) as vehicle_max_day
        |from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |where inc_day<='$incDay'
        |""".stripMargin
    val vehicle_max_day_df: DataFrame = spark.sql(vehicle_max_day_sql)
    val vehicle_max_day: String = SparkUtils.getDfToJson(spark, vehicle_max_day_df).map(obj => {
      obj.getString("vehicle_max_day")
    }).collect().head
    logger.error("车辆所属车队维表数据分区最大值："+vehicle_max_day)
    //车队停留油站频次表
    updatePathwayStatisticJoinVehicle(spark,max_day,vehicle_max_day,after_one_day,incDay)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>PathwayStatisticJoinVehicle Execute Ok")
  }
}
