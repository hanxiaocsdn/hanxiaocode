package app


import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.CommonTools.{getdaysBeforeOrAfter, writeToHive}

/**
 *需求名称：加油推荐转化监控V1.0：周表
 *需求方：马晶玲(01423372)
 *研发： 周勇(01390943)
 *任务创建时间：20230322
 *任务id：衡度平台700
 **/
object AddFuelTurnPertWeek {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    import spark.implicits._
    //获取T-1日期
    val dayvar: String = args(0)
    //取T-14日期,
    val dayvar14 = getdaysBeforeOrAfter(dayvar, -13)
    //取T+6日期,
    val dayvar6 = getdaysBeforeOrAfter(dayvar, 6)
    //取T+7日期,
    val dayvar7 = getdaysBeforeOrAfter(dayvar, 7)

    //周表计算

    val sql1=s"""select * from dm_gis.ddjy_addfuel_turn_dtl1
               |where inc_day>='${dayvar}' and inc_day<='${dayvar6}'
               |""".stripMargin

    println("sql1:"+sql1)
    val day_data1=spark.sql(sql1)

    val sql2=
      """
        |select * from dm_gis.ddjy_addfuel_turn_dtl2
        |where inc_day>='${dayvar}' and inc_day<='${dayvar6}'
        |""".stripMargin
    println("sql2:"+sql2)

    val day_data2=spark.sql(sql2)

    //一周加油量
    val day_data2_oil= day_data2.groupBy("team_id")
      .agg(sum($"order_oil_mass") as "order_oil_mass_week")

    //预测加油量
    val yuce_oil=spark.sql( s"""
                           |select * from dm_gis.ddjy_addfuel_turnpert_day
                           |where inc_day>='${dayvar}' and inc_day<='${dayvar6}'
                           |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("team_id","inc_day").orderBy(desc("inc_day")) ))
      .filter($"rank"===1)
      .groupBy("team_id")
      .agg(sum($"oil_sum") as "oil_sum_week")
      .withColumn("oil_sum",$"oil_sum_week")

    //订单支付流水
    val order_pay_week=spark.sql(
      s"""
         |select station_id,car_team_id,oil_mass,pay_time,order_status,inc_day
         |from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |""".stripMargin)
      .filter($"order_status"==="2")
      .drop("order_status")
      .withColumn("team_id",$"car_team_id")
      .withColumn("order_team_id",$"car_team_id")
      .withColumn("order_station_id",$"station_id")
      .filter($"inc_day"<=dayvar7 && $"inc_day">=dayvar)
      .groupBy("team_id")
      .agg(
        sum($"oil_mass") as "oil_mass7"
      )

    val res_cols = spark.sql(s"""select * from dm_gis.ddjy_addfuel_turnpert_week limit 0""").schema.map(_.name).map(col)

    val day_data3=day_data1.join(day_data2,Seq("team_id" ,"station_id","inc_day"),"left")
      .na.fill("否",Seq("if_order_14"))
      .na.fill(0,Seq("order_cnt_flag7"))
      .groupBy("team_id","team_name","source_type")
      .agg(
        //推荐集散地数
        countDistinct($"clue_id") as "recommend_clue_num",
        //推荐油站数
        countDistinct(when($"station_type"==="推荐",$"station_id").otherwise(null)) as "recommend_sta_num",
        //非推荐油站数
        countDistinct(when($"station_type"==="非推荐",$"station_id").otherwise(null)) as "non_recommend_sta_num",
        //曝光集散地数
        countDistinct(when($"operate_event_type"==="34015",$"clue_id").otherwise(null)) as "expo_clue_num",
        //曝光推荐油站数
        countDistinct(when($"station_type"==="推荐" && (($"operate_clue_id" === $"clue_id" && $"operate_event_type" =!= "34015") || $"operate_event_type"==="34015"),$"station_id").otherwise(null)) as "expo_recommend_sta_num",
        //曝光非推荐油站数
        countDistinct(when($"station_type"==="非推荐" && (($"operate_clue_id" === $"clue_id" && $"operate_event_type" =!= "34015") || $"operate_event_type"==="34015"),$"station_id").otherwise(null)) as "expo_non_recommend_sta_num",
        //集散地转化数
        countDistinct(when($"operate_event_type"==="34015" && $"if_order_14"==="否" && $"order_cnt_flag7">0,$"clue_id").otherwise(null)) as "convert_clue_num",
        //推荐油站转化数
        countDistinct(when(($"station_type"==="推荐" && (($"operate_clue_id" === $"clue_id" && $"operate_event_type" =!= "34015") || $"operate_event_type"==="34015"))
          && $"if_order_14"==="否" && $"order_cnt_flag7">0,$"station_id").otherwise(null)) as "convert_recommend_sta_num",
        //非推荐油站转化数
        countDistinct(when(($"station_type"==="非推荐" && (($"operate_clue_id" === $"clue_id" && $"operate_event_type" =!= "34015") || $"operate_event_type"==="34015"))
          && $"if_order_14"==="否" && $"order_cnt_flag7">0,$"station_id").otherwise(null)) as "convert_non_recommend_sta_num"
      )
      //推荐集散地关联油站数
      .withColumn("rele_sta_num",$"recommend_sta_num"+$"non_recommend_sta_num")
      //曝光关联油站数
      .withColumn("expo_rele_sta_num",$"expo_recommend_sta_num"+$"expo_non_recommend_sta_num")
      //关联油站转化数
      .withColumn("convert_rele_sta_num",$"convert_recommend_sta_num"+$"convert_non_recommend_sta_num")
      //订单加油总量
      .join(order_pay_week,Seq("team_id"),"left")
      .na.fill(0.0,Seq("oil_mass7"))
      .withColumn("order_oil_sum",$"oil_mass7")
      //预估一周油量
      .join(day_data2_oil,Seq("team_id"),"left")
      .na.fill(0.0,Seq("order_oil_mass_week"))
      //预估一周油量
      .join(yuce_oil,Seq("team_id"),"left")
      .na.fill(0.0,Seq("oil_sum"))
      .withColumn("oil_mass",$"order_oil_mass_week")
      //集散地曝光率
      .withColumn("expo_clue_rate",round($"expo_clue_num"/$"recommend_clue_num",6))
      //集散地转化率
      .withColumn("convert_clue_rate",round($"convert_clue_num"/$"expo_clue_num",6))
      //关联油站曝光率
      .withColumn("expo_rele_sta_rate",round($"expo_rele_sta_num"/$"rele_sta_num",6))
      //关联油站转化率
      .withColumn("convert_rele_sta_rate",round($"convert_rele_sta_num"/$"expo_rele_sta_num",6))
      //推荐油站曝光率
      .withColumn("expo_recrele_sta_rate",round($"expo_recommend_sta_num"/$"recommend_sta_num",6))
      //推荐油站转化率
      .withColumn("convert_recrele_sta_rate",round($"convert_recommend_sta_num"/$"expo_recommend_sta_num",6))
      //非推荐油站曝光率
      .withColumn("non_expo_rele_sta_rate",round($"expo_non_recommend_sta_num"/$"non_recommend_sta_num",6))
      //非推荐油站转化率
      .withColumn("non_convert_rele_sta_rate",round($"convert_non_recommend_sta_num"/$"expo_non_recommend_sta_num",6))
      //油量吻合率
      .withColumn("oil_accu_rate",round($"order_oil_sum"/$"oil_sum",6))
      .withColumn("inc_day",lit(dayvar))
      .select(res_cols: _*)

    //数据存dm表
    writeToHive(spark, day_data3, Seq("inc_day"), "dm_gis.ddjy_addfuel_turnpert_week")

  }



}
