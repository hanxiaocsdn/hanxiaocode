package app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.SparkWrite

/**
 *需求名称：车辆归属更新
 *需求描述：结合、订单、订单图片、手动填报数据、旧的粤运表，更新一张新的车辆归属表。
 *需求方：刘芮(01412988)
 *研发： 周勇(01390943)
 *任务创建时间：20230310
 *任务id：衡度平台638
 **/
object VehicleConcatOwnership {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    import spark.implicits._
    //跑数日期参数
    val dayvar0: String = args(0)
    val dayvar1: String = args(1)
    val dayvar2: String = args(2)

    //----全表查询order表
    val station_order_df =spark.sql(
      s"""
        |select *,car_team_id as team_id ,create_date as update_time
        |from dm_gis.ddjy_dwd_station_order_repartition_di
        |where inc_day<='$dayvar0'
        |""".stripMargin)
      .filter($"order_status"==="2")
      .withColumn("carplate",$"new_carplate")

//    val station_order_df =spark.sql(
//      """
//        |select *,car_team_id as team_id ,create_date as update_time
//        |from dm_gis.dm_ddjy_station_order_tmp
//        |""".stripMargin)
//      .filter($"order_status"==="2")


    station_order_df.createOrReplaceTempView("station_order")

    logger.error("输出:station_order_df")
    station_order_df.show(10)


//获取订单车牌号对应的车队信息
    val order_pics_df=spark.sql(s"""
       |select * from (
       |select *,row_number() over(partition by order_sn order by update_time desc) as rank
       |from dm_gis.ddjy_station_order_pics_carplate
       |where inc_day<='$dayvar0' and inc_day in
       |(select max(inc_day) inc_day from dm_gis.ddjy_station_order_pics_carplate)
       |) x where x.rank=1""".stripMargin)

    order_pics_df.createOrReplaceTempView("order_pics")

    spark.sql(
      """
        |insert overwrite table dm_gis.dm_ddjy_carplate_orderpics_pp
        |select * from order_pics
        |""".stripMargin)

    logger.error("输出:order_pics_df")
    order_pics_df.show(10)

    //车队配置表
    val team_info_df=spark.sql(
      s"""
         |select * from (
         |select *,row_number() over(partition by id order by update_date desc) as rank
         |from dm_gis.ddjy_dim_team_info_filter
         |where inc_day='${dayvar0}'
         |) x where x.rank=1
         |""".stripMargin)

    team_info_df.createOrReplaceTempView("team_info")

    logger.error("输出:team_info_df")
    team_info_df.show(10)

    //获取车队填报车牌号对应的车队信息
    val team_car_df_og=spark.sql(s"""
                                |select car_plate,team_id,update_time,inc_day,del_flag
                                |from dm_gis.ddjy_t_team_car
                                |where inc_day<='$dayvar0'
                                |""".stripMargin)

    team_car_df_og.createOrReplaceTempView("team_car_df_og")

    val team_car_df=spark.sql("""
         |select car_plate as vehicle_no,cast(team_id as String) team_id,update_time,'2' as source
         |from team_car_df_og
         |where  inc_day in
         |(select max(inc_day) inc_day from team_car_df_og)
         |and del_flag='0'
         |and car_plate REGEXP  '(([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁台琼使领军北南成广沈济空海]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂领学警港澳]{1}(?!\d))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁台琼使领军北南成广沈济空海]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂领学警港澳]{2}(?!\d)))'
         |""".stripMargin)
      .drop("inc_day")

//    val team_car_df=spark.sql("""
//                                |select car_plate as vehicle_no,cast(team_id as String) team_id,update_time,'2' as source
//                                |from dm_gis.ddjy_t_team_car
//                                |where inc_day<='$dayvar0' and inc_day in
//                                |(select max(inc_day) inc_day from dm_gis.ddjy_t_team_car)
//                                |and del_flag='0'
//                                |and car_plate REGEXP  '(([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁台琼使领军北南成广沈济空海]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂领学警港澳]{1}(?!\d))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁台琼使领军北南成广沈济空海]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂领学警港澳]{2}(?!\d)))'
//                                |""".stripMargin)

    team_car_df.createOrReplaceTempView("team_car")

    logger.error("输出:team_car_df")
    team_car_df.show(10)

    //订单数据匹配
    val order_pp_df=spark.sql("""
         |select case when t2.carplate is null or trim(t2.carplate)='' then t1.carplate else t2.carplate end vehicle_no,
         |t1.team_id,t1.update_time,'1' as source
         |from station_order as t1
         |left join order_pics as t2
         |on t1.order_sn = t2.order_sn""".stripMargin)

    order_pp_df.createOrReplaceTempView("order_pp")

    spark.sql(
      """
        |insert overwrite table dm_gis.dm_ddjy_carplate_order_pp
        |select * from order_pp
        |""".stripMargin)

    logger.error("输出:order_pp_df")
    order_pp_df.show(10)

    //经营代码匹配表credit_code
    val info_seed_code_df=spark.sql(
      s"""
         |select * from (
         |select credit_code,owner_id,row_number() over(partition by credit_code order by source_time desc) as rank
         | from dm_gis.dwd_ddjy_carrier_info_seed_dtl
         | where inc_day<'${dayvar2}' and credit_code is not null and trim(credit_code) !=''
         | ) x where x.rank=1
         |""".stripMargin)

    info_seed_code_df.createOrReplaceTempView("info_seed_code")

    logger.error("输出:info_seed_code_df")
    info_seed_code_df.show(10)

    //经营代码匹配表name
    val info_seed_name_df=spark.sql(
      s"""
        |select * from (
        |select name,owner_id,row_number() over(partition by name order by source_time desc) as rank
        | from dm_gis.dwd_ddjy_carrier_info_seed_dtl
        |  where inc_day<'${dayvar2}' and name is not null and trim(name) !=''
        | ) x where x.rank=1
        |""".stripMargin)

    info_seed_name_df.createOrReplaceTempView("info_seed_name")

    logger.error("输出:info_seed_name_df")
    info_seed_name_df.show(10)

    //合并去重
    val carplate_cq_df=spark.sql(
      """
        |select * from (
        |select *,row_number() over(partition by vehicle_no order by update_time desc) as rank
        |from (
        |select * from order_pp
        |union all
        |select * from team_car
        |) x
        |) y where y.rank=1
        |and y.vehicle_no REGEXP  '(([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁台琼使领军北南成广沈济空海]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂领学警港澳]{1}(?!\d))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁台琼使领军北南成广沈济空海]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂领学警港澳]{2}(?!\d)))'
        |
        |""".stripMargin)

    carplate_cq_df.createOrReplaceTempView("carplate_cq")

    spark.sql(
      """
        |insert overwrite table dm_gis.dm_ddjy_carplate_cq
        |select * from carplate_cq
        |""".stripMargin)

    logger.error("输出:carplate_cq_df")
    carplate_cq_df.show(10)

//粤运车辆归属信息
    val old_info_df=spark.sql(
      s"""
        |select *,'' as is_need
        |from dm_gis.dim_ddjy_mid_vehicle_concat_yy_df
        |where inc_day in(select max(inc_day) inc_day from dm_gis.dim_ddjy_mid_vehicle_concat_yy_df
        |where inc_day<='${dayvar0}')
        |and owner_type!='危运'
        |and owner_type!='客运'
        |and owner_name not like '%暂缺信息%'
        |and owner_name!=''
        |and owner_name is not null
        |""".stripMargin)
    old_info_df.filter($"vehicle_no"==="苏BB1215").show(10)
    old_info_df.createOrReplaceTempView("old_info")


    spark.sql(
      """
        |insert overwrite table dm_gis.dim_ddjy_tmp_mid_vehicle_concat_yy_df
        |select * from old_info
        |""".stripMargin)

    logger.error("输出:old_info_df")
    old_info_df.show(10)

    //匹配车辆归属信息
    val ppresult_df=spark.sql(
      """
        |select t1.vehicle_no,
        |case when t3.owner_id is not null then t3.owner_id
        |when t4.owner_id is not null then t4.owner_id
        |else concat_ws('_','xz',t2.id) end owner_id,
        |t2.name as owner_name,
        |t2.province as province_name,
        |t2.city as city_name,
        |t2.district as area_name,
        |concat_ws(','
        |,case when trim(t2.province)='' then null else t2.province end
        |,case when trim(t2.city)='' then null else t2.city end
        |,case when trim(t2.district)='' then null else t2.district end) as area_manager_name,
        |'' org_type,
        |t2.tax_no as credit_code,
        |'' manager,
        |'' manager_phone,
        |t2.contact_name as contactor,
        |t2.contact_phone as contactor_phone,
        |'' owner_type,
        |'' city_id,
        |'' access_date,
        |t1.source,
        |case when t2.tax_no != t5.credit_code then '1'
        |when t5.vehicle_no is null then '2' else '' end type,
        |t1.update_time as update_date
        |
        |from carplate_cq t1
        |inner join team_info t2
        |on t1.team_id=t2.id
        |left join info_seed_code t3
        |on t2.tax_no=t3.credit_code
        |left join info_seed_name t4
        |on t2.name=t4.name
        |left join old_info t5
        |on t1.vehicle_no=t5.vehicle_no
        |""".stripMargin)
    ppresult_df.filter($"vehicle_no"==="苏BB1215").show(10)
    ppresult_df.createOrReplaceTempView("ppresult")

    logger.error("输出:ppresult_df")
    ppresult_df.show(10)

    //粤运车辆过滤
    val old_info_result_df=spark.sql(
      """
        |select t1.vehicle_no,
        |t1.owner_id,
        |t1.owner_name,
        |t1.province_name,
        |t1.city_name,
        |t1.area_name,
        |t1.area_manager_name,
        |t1.org_type,
        |t1.credit_code,
        |t1.manager,
        |t1.manager_phone,
        |t1.contactor,
        |t1.contactor_phone,
        |t1.owner_type,
        |t1.city_id,
        |t1.access_date,
        |'3' source,
        |'' type,
        |'' update_date
        |from old_info t1
        |left join ppresult t2
        |on t1.vehicle_no=t2.vehicle_no
        |where t2.vehicle_no is null
        |""".stripMargin)
    logger.error("旧的车队信息：")
    old_info_result_df.filter($"vehicle_no"==="苏BB1215").show(10)
    old_info_result_df.createOrReplaceTempView("old_info_result")
    val new_info_result_df=spark.sql(
      """
        |select t1.vehicle_no,
        |t1.owner_id,
        |t1.owner_name,
        |t1.province_name,
        |t1.city_name,
        |t1.area_name,
        |t1.area_manager_name,
        |t1.org_type,
        |t1.credit_code,
        |t1.manager,
        |t1.manager_phone,
        |t1.contactor,
        |t1.contactor_phone,
        |t1.owner_type,
        |t1.city_id,
        |t1.access_date,
        |'3' source,
        |'' type,
        |'' update_date
        |from old_info t1
        |left join ppresult t2
        |on t1.vehicle_no=t2.vehicle_no
        |where t2.vehicle_no is not null
        |""".stripMargin)
    logger.error("新的车队信息：")
    new_info_result_df.filter($"vehicle_no"==="苏BB1215").show(10)
    logger.error("执行插入vehicle_concat表：")

    old_info_result_df.show(10)

  //存入正式表
  val concat_yy_df: DataFrame = spark.sql(
    s"""
       |select * from ppresult
       |union all
       |select * from old_info_result
       |""".stripMargin)

    SparkWrite.writeToHive(spark,concat_yy_df.coalesce(5),"inc_day",dayvar1,"dm_gis.dim_ddjy_vehicle_concat_yy_df")

    //按天存储
    val concat_yy_day_df=spark.sql(
      s"""
        |select
        |vehicle_no,
        |owner_id,
        |owner_name,
        |province_name,
        |city_name,
        |area_name,
        |area_manager_name,
        |org_type,
        |credit_code,
        |manager,
        |manager_phone,
        |contactor,
        |contactor_phone,
        |owner_type,
        |city_id,
        |access_date,
        | source,
        |type,
        |update_date from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |where inc_day='${dayvar1}'
        |""".stripMargin)

    SparkWrite.writeToHive(spark,concat_yy_day_df.coalesce(5),"inc_day",dayvar2,"dm_gis.ddjy_vehicle_ownership_day_dtl")

    //匹配昨日新数据
    val pp1_df=spark.sql(
      """
        |select t1.vehicle_no,t2.id as owner_id_update,t2.name as owner_name_update,t2.tax_no as credit_code_update,t1.source,t1.update_time
        |from carplate_cq t1
        |left join team_info t2
        |on t1.team_id=t2.id
        |""".stripMargin)

    pp1_df.createOrReplaceTempView("pp1")

    //归属更新结果表
    val ownership_df=spark.sql(
      s"""
         |select * from dm_gis.ddjy_vehicle_ownership_day_dtl
         |where inc_day='${dayvar0}'
         |""".stripMargin)

    ownership_df.createOrReplaceTempView("ownership")

    //匹配结果2
    val pp2_df=spark.sql(
      """
        |select *,
        |case when (credit_code_original is null or trim(credit_code_original)='' or trim(credit_code_original)='null')
        |     and (credit_code_update is null or trim(credit_code_update)='' or trim(credit_code_update)='null')  then 1
        |   when credit_code_original=credit_code_update
        |   or owner_name_original=owner_name_update   then 1
        |   else 0 end is_delete
        |from (
        |select t1.vehicle_no,t1.owner_id_update,t1.owner_name_update,t1.credit_code_update,
        |t2.owner_id as owner_id_original,t2.owner_name as owner_name_original,t2.credit_code as credit_code_original,
        |t1.source,t1.update_time as update_date
        |from pp1 t1
        |left join ownership t2
        |on t1.vehicle_no=t2.vehicle_no
        |) x
        |""".stripMargin)

    pp2_df.createOrReplaceTempView("pp2")

    logger.error("执行插入change表：")

    //存入dm表
    val ownership_change_df=spark.sql(
      s"""
        |select vehicle_no,owner_id_original,owner_name_original,credit_code_original,
        |owner_id_update,owner_name_update,credit_code_update,
        |source,update_date
        |from pp2
        |where is_delete=0
        |""".stripMargin)

    SparkWrite.writeToHive(spark,ownership_change_df.coalesce(5),"inc_day",dayvar2,"dm_gis.ddjy_vehicle_ownership_change_dtl")


    logger.error("执行插入seed表：")

    //存入dm表
    val info_seed_df=spark.sql(
      s"""
         |select distinct owner_id,
         |credit_code,
         |owner_name as name,
         |org_type as company_org_type_clean,
         |contactor as legal_person_name,
         |contactor_phone as content,
         |city_id as city_adcode,
         |owner_type as business_scope,
         |access_date as source_time,
         |case when length(contactor_phone) in (7,8) or contactor_phone like '%-%' then 'tel' when length(contactor_phone) = 11 then 'mobile' else '' end as type,
         |'订单平台' as  src,
         |update_date as create_time
         | from  dm_gis.ddjy_vehicle_ownership_day_dtl
         |where inc_day='${dayvar2}' and owner_id like 'xz%'
         |""".stripMargin)

    SparkWrite.writeToHive(spark,info_seed_df.coalesce(5),"inc_day",dayvar2,"dm_gis.dwd_ddjy_carrier_info_seed_dtl")
    //更新种子表
    info_seed_df.createOrReplaceTempView("info_seed_tmp")
    val updateSeedSql=
      """
        |select  t1.owner_id,t1.credit_code,t1.name,t1.company_org_type_clean,
        |t1.legal_person_name, t1.content,
        |t1.city_adcode,t1.business_scope,t1.source_time, t1.type,t1.src,t1.create_time,'' flag
        |from info_seed_tmp t1
        |left join dm_gis.dwd_ddjy_carrier_info_seed_copy t2
        |on t1.owner_id=t2.owner_id
        |where t2.owner_id is null
        |union all
        |select  owner_id,credit_code,name,company_org_type_clean,
        |legal_person_name, content,
        |city_adcode,business_scope,source_time, type,src,create_time,flag from dm_gis.dwd_ddjy_carrier_info_seed_copy
        |""".stripMargin
    val updateSeedDf: DataFrame = spark.sql(updateSeedSql)
    SparkWrite.writeToHiveNoPart(spark,updateSeedDf.coalesce(5),"dm_gis.dwd_ddjy_carrier_info_seed")
    //更新种子copy表
    val updateSeedCopySql=
      """
        |insert overwrite table dm_gis.dwd_ddjy_carrier_info_seed_copy
        |select * from dm_gis.dwd_ddjy_carrier_info_seed
        |""".stripMargin
    spark.sql(updateSeedCopySql)

    //运行结束
    spark.close()
  }

}
