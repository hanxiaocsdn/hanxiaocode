package app

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.DistanceUtils
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkWrite}

import scala.collection.JavaConversions._
/**
 * @Description:
 * 需求人员：周韵筹 01425211
 * @Author: lixiangzhi 01405644
 * @Date:
 * 任务id:1026
 * 任务名称：沿途线索基础表
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object CircleClueDetailBak {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readClueData(spark: SparkSession, fri_day: String) = {
    val satur_day: String = DateUtil.getDateStr(fri_day, 1, "")
    val start_day: String = DateUtil.getDateStr(fri_day, -6, "")
    val joinClueSql=
      s"""
        |select
        |t7.poiid,
        |owner_id as carrier_id,
        |owner_name as carrier_name,
        |frequency_tj as pathway_task_count,
        |frequency_zb as pathway_around_vehicle_count,
        |frequency_tl as stay_task_count,
        |carrier_status,carrier_tag,register_vehicle_count,
        |stationname,
        |province as gas_province,
        |city as gas_city,
        |district as gas_district,
        |addr,
        |adcode as gas_adcode,
        |lng,lat,cooperatestatus,management_model,querybrandid,gappricevec,priceactivityvec
        |from
        |(
        |	select
        |	nvl(t5.poiid,t6.poiid) as poiid,
        |	nvl(t5.owner_id,t6.owner_id) as owner_id,
        |	nvl(t5.owner_name,t6.owner_name) as owner_name,
        |	frequency_tj,frequency_zb,frequency_tl
        |	from
        |	(
        |		select
        |		poiid,owner_id,owner_name,
        |		cast(frequency_tj as double),
        |		frequency_zb
        |		from dm_gis.ddjy_pathway_clue_statistic_di
        |		where inc_day='${fri_day}'
        |		union all
        |		select
        |		poiid,owner_id,owner_name,
        |		sum(frequency_tl) as frequency_tj,
        |		'0' as frequency_zb
        |		from
        |		(
        |			select
        |			car_no,poiid,frequency_tl
        |			from dm_gis.ddjy_vehicle_suspect_way_info_ic_di
        |			where inc_day>='${start_day}' and inc_day<='${fri_day}'
        |			and type='PS'
        |		) t1
        |		join
        |		(
        |			select
        |			vehicle_no,owner_id,owner_name
        |			from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |			where inc_day='${satur_day}'
        |		) t2
        |		on t1.car_no=t2.vehicle_no
        |		group by poiid,owner_id,owner_name
        |	) t5
        |	full join
        |	(
        |		select
        |		poiid,owner_id,owner_name,
        |		cast(frequency_tl as double)
        |		from dm_gis.ddjy_team_way_frequency_di
        |		where inc_day='${fri_day}'
        |		union all
        |		select
        |		poiid,owner_id,owner_name,
        |		sum(frequency_tl) as frequency_tl
        |		from
        |		(
        |			select
        |			car_no,poiid,frequency_tl
        |			from dm_gis.ddjy_vehicle_suspect_way_info_ic_di
        |			where inc_day>='${start_day}' and inc_day<='${fri_day}'
        |			and type='SP'
        |		) t3
        |		join
        |		(
        |			select
        |			vehicle_no,owner_id,owner_name
        |			from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |			where inc_day='${satur_day}'
        |		) t4
        |		on t3.car_no=t4.vehicle_no
        |		group by poiid,owner_id,owner_name
        |	) t6
        |	on t5.poiid=t6.poiid and t5.owner_id=t6.owner_id
        |) t7
        |left join
        |(
        |	select
        |	carrier_id,carrier_status,carrier_tag,register_vehicle_count
        |	from dm_gis.dwd_ddjy_clue_gas_di
        |	where inc_day='${fri_day}'
        | group by carrier_id,carrier_status,carrier_tag,register_vehicle_count
        |) t8
        |on t7.owner_id=t8.carrier_id
        |left join
        |(
        |	select
        |	poiid,stationname,province,city,district,addr,adcode,lng,lat,cooperatestatus,management_model,querybrandid,gappricevec,priceactivityvec
        |	from dm_gis.dm_ddjy_gas_station_info_di
        |) t9
        |on t7.poiid=t9.poiid
        |""".stripMargin
    val joinClueRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, joinClueSql)
    joinClueRdd
  }

  def joinCircleSeed(spark: SparkSession, joinClueRdd: RDD[JSONObject], fri_day: String) = {
    import spark.implicits._
    val clueGasSql=
      s"""
        |select
        |poiid,gas_circle_id,
        |center_x as x,
        |center_y as y,
        |clue_name as circle_name
        |from
        |(
        |	select poiid,gas_circle_id,center_x,center_y,clue_name,
        |	row_number() over(partition by poiid order by cast(d_dist as double)) as rnk
        |	from dm_gis.dwd_ddjy_clue_gas_di
        |	where inc_day='$fri_day'
        |) t1
        |where rnk=1
        |""".stripMargin
    val clueGasRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, clueGasSql).map(obj => {
      (obj.getString("poiid"), obj)
    })
    val circleSeedDistinctSql=
      s"""
         |select stay_adcode as adcode,circle_id,center_x,center_y,
         |max(belong_name) as circle_name
         |from dm_gis.dwd_ddjy_clue_circle_seed_test
         |group by stay_adcode,circle_id,center_x,center_y
         |""".stripMargin
    val circleSeedDistinctRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark,circleSeedDistinctSql).map(obj=>{
      (obj.getString("adcode"), obj)
    })
    val joinClueGasRdd: RDD[JSONObject] = joinClueRdd.map(obj => {
      (obj.getString("poiid"), obj)
    }).leftOuterJoin(clueGasRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("关联油站线索基础表后数据量:"+joinClueGasRdd.count())
    clueGasRdd.unpersist()
    joinClueRdd.unpersist()
    val notNullCircleidRdd: RDD[JSONObject] = joinClueGasRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("gas_circle_id"))
    })

    val nullCircleidRdd: RDD[(String, JSONObject)] = joinClueGasRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("gas_circle_id"))
    }).map(obj=>{
      (obj.getString("gas_adcode"),obj)
    })
    var cantoneseClueRdd: RDD[JSONObject]=null
    var addCircleIdRdd: RDD[JSONObject]=null
    if(nullCircleidRdd.count()!=0){
      val nullCircleidJoinSeedRdd: RDD[JSONObject] = nullCircleidRdd.leftOuterJoin(circleSeedDistinctRdd).map(obj => {
        val leftObj: JSONObject = obj._2._1
        val rightObj: JSONObject = obj._2._2.orNull
        if (rightObj != null) {
          val circle_id: String = rightObj.getString("circle_id")
          val circle_name: String = rightObj.getString("circle_name")
          val center_x: Double = rightObj.getDouble("center_x")
          val center_y: Double = rightObj.getDouble("center_y")
          val longitude: Double = leftObj.getDouble("lng")
          val latitude: Double = leftObj.getDouble("lat")
          val distance: Double = DistanceUtils.getDistance(center_x, center_y, longitude, latitude)
          leftObj.put("distance", distance)
          leftObj.put("gas_circle_id", circle_id)
          leftObj.put("circle_id", circle_id)
          leftObj.put("x", center_x)
          leftObj.put("y", center_y)
          leftObj.put("circle_name", circle_name)
        }
        leftObj
      })
      //2、最小distance的Circleid
      val minDistanceCircleidRdd: RDD[JSONObject] = nullCircleidJoinSeedRdd
        .filter(_.getString("gas_circle_id") != null)
        .groupBy(_.getString("poiid"))
        .map(obj => {
          obj._2.toList.minBy(json=>JSONUtil.getJsonDouble(json,"distance",Int.MaxValue))
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("获取最小距离的circle_id的数据:"+minDistanceCircleidRdd.count())

      //3、调集散圈接口的Circleid
      val needCircleInterfaceDataRdd: RDD[JSONObject] = nullCircleidJoinSeedRdd.filter(obj=>{
        StringUtils.isEmpty(obj.getString("gas_circle_id"))
      })
      logger.error("获取需要调集散圈接口的数据:"+needCircleInterfaceDataRdd.count())
      needCircleInterfaceDataRdd.take(10).foreach(println(_))
      if(needCircleInterfaceDataRdd.count()!=0){
        val stationRdd: RDD[(String, JSONObject)] = needCircleInterfaceDataRdd.repartition(1000).map(obj => {
          val tmpObj = new JSONObject()
          val clue_id: String = obj.getString("poiid")
          val adcode: String = obj.getString("gas_adcode")
          val x: Double = obj.getDouble("lng")
          val y: Double = obj.getDouble("lat")
          tmpObj.put("clue_id", clue_id)
          tmpObj.put("adcode", adcode)
          tmpObj.put("x", x)
          tmpObj.put("y", y)
          (adcode, tmpObj)
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
        val returnRdd: RDD[(String, JSONObject)] = stationRdd.groupByKey().repartition(5).flatMap(obj=>{
          val stations: Array[JSONObject] = obj._2.toArray
          val stationsObj = new JSONObject()
          stationsObj.put("stations",stations)
          val returnObj: JSONObject = SfNetInteface.stationClusterInterface(stationsObj)
          val resultsArray: JSONArray = JSONUtil.getJsonArrayMulti(returnObj, "api_result.results")
          val tmpList = new util.ArrayList[JSONObject]()
          for (i <- 0 until resultsArray.size()) {
            val tmpObj = new JSONObject()
            val resultObj: JSONObject = resultsArray.getJSONObject(i)
            tmpObj.fluentPutAll(resultObj)
            tmpList.add(tmpObj)
          }
          tmpList.iterator()
        }).map(obj=>{
          (obj.getString("clue_id"),obj)
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("调取集散圈接口返回数据量："+returnRdd.count())
        returnRdd.take(10).foreach(println(_))
        //需求集散圈接口返回，并回挂的数据
        val interfaceReturnDataRdd = needCircleInterfaceDataRdd.repartition(600).map(obj => {
          (obj.getString("poiid"), obj)
        }).leftOuterJoin(returnRdd).map(obj=>{
          val rightObj: JSONObject = obj._2._2.getOrElse(new JSONObject())
          val leftObj: JSONObject = obj._2._1
          val center_x: String = JSONUtil.getJsonValSingle(rightObj,"center_x")
          val center_y: String = JSONUtil.getJsonValSingle(rightObj,"center_y")
          val circle_id: String = JSONUtil.getJsonValSingle(rightObj,"circle_id")
          val stationname: String = leftObj.getString("stationname")
          leftObj.put("x", center_x)
          leftObj.put("y", center_y)
          leftObj.put("circle_id", circle_id)
          leftObj.put("gas_circle_id", circle_id)
          leftObj.put("circle_name", stationname)
          leftObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER)
        logger.error("调取集散圈接口并回挂后数据量："+interfaceReturnDataRdd.count())
        cantoneseClueRdd = notNullCircleidRdd.union(minDistanceCircleidRdd).union(interfaceReturnDataRdd)
        addCircleIdRdd = minDistanceCircleidRdd.union(interfaceReturnDataRdd)
      }else{
        cantoneseClueRdd = notNullCircleidRdd.union(minDistanceCircleidRdd)
        addCircleIdRdd = minDistanceCircleidRdd
      }
    }else{
      cantoneseClueRdd = notNullCircleidRdd
    }
    val cantoneseClueDf: DataFrame = cantoneseClueRdd.map(obj => {
      val adcode: String = obj.getString("gas_adcode")
      val province: String = obj.getString("gas_province")
      val city: String = obj.getString("gas_city")
      val district: String = obj.getString("gas_district")
      obj.put("adcode", adcode)
      obj.put("province", province)
      obj.put("city", city)
      obj.put("district", district)
      PathwayClueBase(
        obj.getString("gas_circle_id"),
        obj.getString("circle_name"),
        obj.getString("adcode"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("district"),
        obj.getString("x"),
        obj.getString("y"),
        obj.getString("carrier_id"),
        obj.getString("carrier_name"),
        obj.getString("carrier_status"),
        obj.getString("carrier_tag"),
        obj.getString("register_vehicle_count"),
        obj.getString("gas_circle_id"),
        obj.getString("gas_province"),
        obj.getString("gas_city"),
        obj.getString("gas_district"),
        obj.getString("poiid"),
        obj.getString("stationname"),
        obj.getString("addr"),
        obj.getString("cooperatestatus"),
        obj.getString("management_model"),
        obj.getString("querybrandid"),
        obj.getString("gappricevec"),
        obj.getString("priceactivityvec"),
        obj.getString("pathway_task_count"),
        obj.getString("pathway_around_vehicle_count"),
        obj.getString("stay_task_count")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,cantoneseClueDf,"inc_day",fri_day,"dm_gis.ddjy_dwd_pathway_clue_base_di",50)
    joinClueGasRdd.unpersist()
    //更新Circel种子表
    if (addCircleIdRdd!=null){
      val cal = Calendar.getInstance
      val time = cal.getTime
      val create_time: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time)
      val addCircleIdDf: DataFrame = addCircleIdRdd.map(obj => {
        (
          obj.getString("poiid"),
          obj.getString("circle_name"),
          obj.getString("gas_adcode"),
          obj.getString("gas_province"),
          obj.getString("gas_city"),
          obj.getString("gas_district"),
          obj.getString("circle_id"),
          obj.getString("x"),
          obj.getString("y"),
          create_time,
          obj.getString("lng"),
          obj.getString("lat"),
          "pathway_clue"
        )
      }).toDF("unique_id", "belong_name", "stay_adcode", "stay_province", "stay_city", "stay_district", "circle_id", "center_x","center_y","create_time","longitude","latitude","clue_type")
      addCircleIdDf.createOrReplaceTempView("addCircleIdTmp")
      val updateCircleSeedSql=
        """
          |insert overwrite table dm_gis.dwd_ddjy_clue_circle_seed_test
          |select
          |distinct unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type,longitude_avg,latitude_avg
          |from
          |(
          |	select
          |	unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type,
          |	avg(longitude) over(partition by circle_id) as longitude_avg,
          |	avg(latitude) over(partition by circle_id) as latitude_avg
          |	from
          |	(
          |		select * from addCircleIdTmp
          |		union
          |		select unique_id,belong_name,stay_adcode,stay_province,stay_city,stay_district,circle_id,center_x,center_y,create_time,longitude,latitude,clue_type
          |   from dm_gis.dwd_ddjy_clue_circle_seed_test
          |	) t1
          |) t2
          |""".stripMargin
      spark.sql(updateCircleSeedSql)
    }
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val team_way_frequency_sql=
      s"""
         |select
         |max(inc_day) as max_day
         |from dm_gis.ddjy_team_way_frequency_di
         |where inc_day<='$incDay'
         |""".stripMargin
    val team_way_frequency_df: DataFrame = spark.sql(team_way_frequency_sql)
    val fri_day: String = SparkUtils.getDfToJson(spark, team_way_frequency_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+fri_day)
    //读取线索数据，关联相关表
    val joinClueRdd: RDD[JSONObject] = readClueData(spark, fri_day)
    //关联集散圈种子表，调集散圈接口
    joinCircleSeed(spark,joinClueRdd,fri_day)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class PathwayClueBase(
                              circle_id:String,
                              circle_name:String,
                              adcode:String,
                              province:String,
                              city:String,
                              district:String,
                              x:String,
                              y:String,
                              carrier_id:String,
                              carrier_name:String,
                              carrier_status:String,
                              carrier_tag:String,
                              register_vehicle_count:String,
                              gas_circle_id:String,
                              gas_province:String,
                              gas_city:String,
                              gas_district:String,
                              poiid:String,
                              stationname:String,
                              addr:String,
                              cooperatestatus:String,
                              management_model:String,
                              querybrandid:String,
                              gappricevec:String,
                              prIceactivityvec:String,
                              pathway_task_count:String,
                              pathway_around_vehicle_count:String,
                              stay_task_count:String
                            )

}
