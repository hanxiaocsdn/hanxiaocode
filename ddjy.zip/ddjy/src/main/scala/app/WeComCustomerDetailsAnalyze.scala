package app

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.{SparkUtils, SparkWrite}

import scala.collection.JavaConversions._

/**
 * @Description:企业微信客户详情表
 * 需求人员：ft220534 陈治仁
 * @Author: lixiangzhi 01405644
 * @Date:20231213
 * 任务id:
 * 任务名称：企业微信客户详情表
 * 依赖任务：
 * 数据源：
 * 调用服务地址：无
 * 数据结果：
 */
object WeComCustomerDetailsAnalyze {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readCustomerDetails(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val customerDetailsSql=
      s"""
        |select * from dm_gis.ods_wecom_customer_details_di where inc_day='$incDay'
        |""".stripMargin
    val customerDetailsDf: DataFrame = SparkUtils.getRowToJson(spark, customerDetailsSql).flatMap(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val external_contact_list: JSONArray = JSONUtil.getJsonArrayMulti(dataObj, "external_contact_list")
      val errcode: String = dataObj.getString("errcode")
      val errmsg: String = dataObj.getString("errmsg")
      val tmpList = new util.ArrayList[JSONObject]()
      if (external_contact_list.size() != 0) {
        for (i <- 0 until (external_contact_list.size())) {
          val tmpObj = new JSONObject()
          val external_contact_list_obj: JSONObject = external_contact_list.getJSONObject(i)
          val external_contact: JSONObject = JSONUtil.getJsonObjectMulti(external_contact_list_obj, "external_contact")
          val external_userid: String = external_contact.getString("external_userid")
          val name: String = external_contact.getString("name")
          var typeStr: String = external_contact.getString("type")
          if (typeStr=="1"){
            typeStr = "微信用户"
          }else if(typeStr=="2"){
            typeStr = "企业微信用户"
          }
          var gender: String = external_contact.getString("gender")
          if (gender=="0"){
            gender = "未知"
          }else if(gender=="1"){
            gender = "男性"
          }else if(gender=="2"){
            gender = "女性"
          }
          val unionid: String = external_contact.getString("unionid")
          val follow_info: JSONObject = JSONUtil.getJsonObjectMulti(external_contact_list_obj, "follow_info")
          val userid: String = follow_info.getString("userid")
          val remark_corp_name: String = follow_info.getString("remark_corp_name")
          tmpObj.put("external_userid", external_userid)
          tmpObj.put("name", name)
          tmpObj.put("typeStr", typeStr)
          tmpObj.put("gender", gender)
          tmpObj.put("unionid", unionid)
          tmpObj.put("userid", userid)
          tmpObj.put("errcode", errcode)
          tmpObj.put("errmsg", errmsg)
          tmpObj.put("remark_corp_name", remark_corp_name)
          tmpList.append(tmpObj)
        }
      }
      tmpList.iterator()
    }).map(obj => {
      CaseCustomer(
        obj.getString("external_userid"),
        obj.getString("name"),
        obj.getString("typeStr"),
        obj.getString("gender"),
        obj.getString("unionid"),
        obj.getString("userid"),
        obj.getString("errcode"),
        obj.getString("errmsg"),
        obj.getString("remark_corp_name")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,customerDetailsDf,"inc_day",incDay,"dm_gis.dm_ddjy_wecom_customer_details_di")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取ods_wecom_customer_details_di
    readCustomerDetails(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }


  case class CaseCustomer(
                              external_userid:String,
                              name:String,
                              typeStr:String,
                              gender:String,
                              unionid:String,
                              userid:String,
                              errcode:String,
                              errmsg:String,
                              remark_corp_name:String
                             )

}
