package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DistanceUtils}
import com.sf.gis.scala.base.spark.{Spark, SparkJoin, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SfNetInteface, SparkWrite, StrSimilarityUtils}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
 * @Description:车队经营地址挖掘需求
 * 需求人员：刘芮 01412988
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2023/03/31
 * 任务id:715
 * 任务名称：车队途径线索挖掘地址检验
 * 依赖任务：车辆归属更新638
 * 数据源：dim_ddjy_vehicle_concat_yy_df、dm_company_dtl、city_name_map、ddjy_sender_receiver_mining_statistics_df
 * 调用服务地址：
 * http://gis-int.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=zh&showserver=true
 * http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=&city=&address=%s
 * 数据结果：ddjy_suspected_business_address_di
 */
object CarrierPathClueMiningBak {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def getVehicleMaxDayData(spark: SparkSession, fri_day: String,city:String) = {
    val vehicle_max_day_sql=
      s"""
         |select
         |carrier_id as owner_id,
         |carrier_name as owner_name,
         |credit_code,
         |content as contactor
         |from dm_gis.dm_ddjy_carrier_rlst_di
         |where inc_day='$fri_day'
         |""".stripMargin
    val vehicleMaxDayDf: DataFrame = spark.sql(vehicle_max_day_sql)
    logger.error("车辆所属车队维表最大分区数据量："+vehicleMaxDayDf.count())
    vehicleMaxDayDf
  }


  def companyDatabaseDetail(spark: SparkSession, vehicleMaxDayDf: DataFrame, incDay: String) = {
    val company_dtl_sql=
      s"""
         |select
         |credit_code,name,reg_location,city_adcode
         |from
         |(
         |	select
         |	credit_code,name,reg_location,city_adcode,
         |	row_number() over(partition by credit_code order by updatetime desc) as rnk
         |	from dm_gis.dm_company_dtl
         |  where reg_location is not null and reg_location!=''
         |) t1
         |where rnk=1
         |--and (reg_location like '%深圳市%' or reg_location like '%佛山市%')
         |""".stripMargin
    val companyDtlRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, company_dtl_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val notNullCreditcodeRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("credit_code"))
    }).map(obj=>{
      (obj.getString("credit_code"), obj)
    })
    val companyDtlCreditcodeRdd: RDD[JSONObject] = companyDtlRdd.map(obj => {
      (obj.getString("credit_code"), obj)
    }).join(notNullCreditcodeRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.put("province_name",rightObj.getString("province_name"))
      leftObj.put("city_name",rightObj.getString("city_name"))
      leftObj.put("owner_id",rightObj.getString("owner_id"))
      leftObj.put("credit_code",rightObj.getString("credit_code"))
      leftObj.put("owner_name",rightObj.getString("owner_name"))
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("企业库credit_code关联数据量:"+companyDtlCreditcodeRdd.count())
    companyDtlCreditcodeRdd.take(10).foreach(println(_))
    companyDtlCreditcodeRdd.filter(_.getString("city_name")!=null).take(10).foreach(println(_))
    val nullCreditcodeRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).filter(obj => {
      StringUtils.isEmpty(obj.getString("credit_code"))
    }).map(obj=>{
      (obj.getString("owner_name"), obj)
    })
    val companyDtlNameRdd: RDD[JSONObject] = companyDtlRdd.map(obj => {
      (obj.getString("name"), obj)
    }).join(nullCreditcodeRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._1
      leftObj.put("province_name",rightObj.getString("province_name"))
      leftObj.put("city_name",rightObj.getString("city_name"))
      leftObj.put("owner_id",rightObj.getString("owner_id"))
      leftObj.put("owner_name",rightObj.getString("owner_name"))
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("企业库owner_name关联数据量:"+companyDtlCreditcodeRdd.count())
    companyDtlCreditcodeRdd.filter(_.getString("city_name")!=null).take(10).foreach(println(_))
    val companyDtlProcessRdd: RDD[JSONObject] = companyDtlCreditcodeRdd.union(companyDtlNameRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("企业库地址数据量:"+companyDtlProcessRdd.count())
    val city_name_map_sql=
      s"""
         |select
         |adcode,citycode
         |from dm_gis.city_name_map
         |""".stripMargin
    val cityNameDf: DataFrame = spark.sql(city_name_map_sql)
    val cityNameMapRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, cityNameDf).map(obj => {
      (obj.getString("adcode"), obj)
    })
    val companyDtlCreditcodeTmpRdd: RDD[JSONObject] = companyDtlProcessRdd.map(obj => {
      (obj.getString("city_adcode"), obj)
    }).leftOuterJoin(cityNameMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val citycode: String = rightObj.getString("citycode")
        leftObj.put("citycode", citycode)
      }
      leftObj
    }).map(obj => {
      val tmpObj = new JSONObject()
      val owner_name: String = obj.getString("name")
      val addr: String = obj.getString("reg_location")
      val city_code: String = obj.getString("citycode")
      tmpObj.put("owner_name", owner_name)
      tmpObj.put("addr", addr)
      tmpObj.put("city_code", city_code)
      tmpObj.put("src", 9)
      tmpObj.put("priority", 5)
      val province_name: String = obj.getString("province_name")
      val city_name: String = obj.getString("city_name")
      val owner_id: String = obj.getString("owner_id")
      val credit_code: String = obj.getString("credit_code")
      tmpObj.put("province_name", province_name)
      tmpObj.put("city_name", city_name)
      tmpObj.put("owner_id", owner_id)
      tmpObj.put("credit_code", credit_code)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("企业库地址临时表F数据量："+companyDtlCreditcodeTmpRdd.count())
    (companyDtlCreditcodeTmpRdd,companyDtlProcessRdd)
  }

  def carrierGDAddressDetail(spark: SparkSession, vehicleMaxDayDf: DataFrame, incDay: String,sat_day:String) = {
    val sun_day: String = DateUtil.getDateStr(sat_day, 2, "")
    val gd_interface_sql=
      s"""
         |select
         |*
         |from dm_gis.gd_interface_return_pois_data_di
         |where inc_day ='$sun_day'
         |and address is not null and address!=''
         |and type like '%物流%'
         |and length(name)>=5
         |""".stripMargin
    logger.error(gd_interface_sql)
    val vehicleMaxDayMapRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).map(obj => {
      (obj.getString("owner_name"), obj)
    })
    val gdInterfaceTmpRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark,gd_interface_sql).map(obj=>{
      (obj.getString("owner_name"), obj)
    }).join(vehicleMaxDayMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      leftObj
    }).filter(obj => {
      val pname: String = obj.getString("pname")
      val cityname: String = obj.getString("cityname")
      var address: String = obj.getString("address")
      var name: String = obj.getString("name")
      var owner_name: String = obj.getString("owner_name")
      address = pname + cityname + address
      val invalid_word_str="广州市,韶关市,深圳市,珠海市,汕头市,佛山市,江门市,湛江市,茂名市,肇庆市,惠州市,梅州市,汕尾市,河源市,阳江市,清远市,东莞市,中山市,潮州市,揭阳市,云浮市,顺德区,龙岗区,运输有限公司,供应链管理有限公司,货运有限公司,货运服务有限公司,货运代理服务部,货物运输服务部,货运服务部,物流有限公司,运输服务有限公司,建筑工程有限公司,发展有限公司,工程有限公司,建材有限公司,汽车贸易有限公司,汽车服务有限公司,科技有限公司,实业有限公司,贸易有限公司,有限公司"
      val invalid_word_arr: Array[String] = invalid_word_str.split(",")
      for (elem <- invalid_word_arr) {
        if (name.contains(elem)){
          name = name.replaceAll(elem,"")
        }
        if (owner_name.contains(elem)){
          owner_name = owner_name.replaceAll(elem,"")
        }
      }
      val nameSimilar: Double = StrSimilarityUtils.similarity(name, owner_name)
      obj.put("address", address)
      nameSimilar > 0.9
    }).map(obj => {
      val tmpObj = new JSONObject()
      val owner_name: String = obj.getString("owner_name")
      val addr: String = obj.getString("address")
      val city_code: String = obj.getString("citycode")
      tmpObj.put("owner_name", owner_name)
      tmpObj.put("addr", addr)
      tmpObj.put("city_code", city_code)
      tmpObj.put("src", 5)
      tmpObj.put("priority", 3)
      val province_name: String = obj.getString("pname")
      val city_name: String = obj.getString("cityname")
      tmpObj.put("province_name", province_name)
      tmpObj.put("city_name", city_name)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("高德地址临时表G数据量:"+gdInterfaceTmpRdd.count())
    gdInterfaceTmpRdd
  }

  def senderReceiverDetail(spark: SparkSession,cityNameRdd:RDD[JSONObject],vehicleMaxDayDf:DataFrame, incDay: String) = {
    val sender_receiver_mining_sql=
      s"""
         |select
         |*
         |from dm_gis.dwd_ddjy_carrier_sender_receiver_addr_mi
         |where inc_month in(select max(inc_month) from dm_gis.dwd_ddjy_carrier_sender_receiver_addr_mi)
         |and addr is not null and addr!=''
         |--and (owner_name like '%深圳市%' or owner_name like '%佛山市%')
         |--and (owner_name='深圳市安强物流有限公司' or owner_name='佛山市陈志物流有限公司' or owner_name='深圳市华赢物流有限公司')
         |""".stripMargin
    //关联citymap映射表，获取省份和城市
    val cityNameMapRdd: RDD[(String, JSONObject)] = cityNameRdd.groupBy(_.getString("citycode")).map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.minBy(_.getString("citycode"))
      tmpObj
    })map(obj => {
      (obj.getString("citycode"), obj)
    })
    val senderReceiverMiningRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, sender_receiver_mining_sql).map(obj => {
      (obj.getString("city_code"), obj)
    }).repartition(20000).persist(StorageLevel.DISK_ONLY)
    val senderJoinCityRdd: RDD[JSONObject] = SparkJoin.leftOuterJoinOfLeftLeanElemJSONObject(senderReceiverMiningRdd, cityNameMapRdd, 50, 50).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      var addr: String = leftObj.getString("addr")
      if (rightObj != null) {
        val province: String = rightObj.getString("province")
        val city: String = rightObj.getString("city")
        if (!addr.contains(province) && !addr.contains(city)) {
          addr = province + city + addr
        } else if (!addr.contains(province) && addr.contains(city)) {
          addr = province + addr
        } else if (addr.contains(province) && !addr.contains(city)) {
          val addrSplit: Array[String] = addr.split(province)
          addr = province + city + addrSplit(1)
        }
        leftObj.put("province",province)
        leftObj.put("city",city)
      }
      leftObj.put("addr", addr)
      leftObj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("收寄件关联city映射表后数据量:"+senderJoinCityRdd.count())
    //一、筛选owner_name长度大于等于5的数据，处理tag1、tag2、tag3的逻辑
    val greater5OwnerNameRdd: RDD[JSONObject] = senderJoinCityRdd.filter(obj => {
      val owner_name: String = obj.getString("owner_name")
      owner_name.length >= 5
    }).distinct().persist(StorageLevel.DISK_ONLY)
    logger.error("owner_name长度大于等于5收寄件地址数据量:"+greater5OwnerNameRdd.count())
    //1、筛选公司名称一致地址
    val ownerNameEqualCompNameRdd: RDD[JSONObject] = greater5OwnerNameRdd.filter(obj => {
      val owner_name: String = obj.getString("owner_name")
      val comp_name: String = obj.getString("comp_name")
      owner_name == comp_name
    }).groupBy(_.getString("owner_name")).map(obj => {
      var list: List[JSONObject] = obj._2.toList
      val compAddrCnt: Int = list.size
      list = list.groupBy(_.getString("addr")).flatMap(json => {
        val list1: List[JSONObject] = json._2
        val addrCnt: Int = list1.size
        val tmpList1: List[JSONObject] = list1.map(json1 => {
          json1.put("addrCnt", addrCnt)
          json1
        })
        tmpList1
      }).map(json => {
        val contactor: String = json.getString("contactor")
        val cont_name: String = json.getString("cont_name")
        var isSamePerson = 1
        if(contactor==cont_name){
          isSamePerson = 0
        }
        json.put("isSamePerson", isSamePerson)
        json.put("compAddrCnt", compAddrCnt)
        json
      }).toList
      var tmpObj = new JSONObject()
      if (compAddrCnt >= 2) {
        tmpObj = list.sortBy(x => (
          x.getString("isSamePerson"), x.getString("inc_day"), x.getIntValue("addrCnt"), x.getString("addr")
        ))(Ordering Tuple4(Ordering.String, Ordering.String.reverse, Ordering.Int.reverse, Ordering.String.reverse)).head
      } else {
        tmpObj = list.head
      }
      tmpObj
    }).map(obj=>{
      obj.put("tag1",1)
      obj
    })
    //2、去除1中已获取到地址的车队，筛选联系人名称一致且source=name地址
    val contactorEqualContNameRdd: RDD[JSONObject] = greater5OwnerNameRdd.filter(obj => {
      val owner_name: String = obj.getString("owner_name")
      val comp_name: String = obj.getString("comp_name")
      val contactor: String = obj.getString("contactor")
      val cont_name: String = obj.getString("cont_name")
      val source: String = obj.getString("source")
      owner_name != comp_name && contactor == cont_name && source == "comp"
    }).groupBy(_.getString("owner_name")).map(obj => {
      var list: List[JSONObject] = obj._2.toList
      val compAddrCnt: Int = list.size
      list = list.groupBy(_.getString("addr")).flatMap(json => {
        val list1: List[JSONObject] = json._2
        val addrCnt: Int = list1.size
        val tmpList1: List[JSONObject] = list1.map(json1 => {
          json1.put("addrCnt", addrCnt)
          json1
        })
        tmpList1
      }).map(json => {
        json.put("compAddrCnt", compAddrCnt)
        json
      }).toList
      var tmpObj = new JSONObject()
      if (compAddrCnt >= 2) {
        tmpObj = list.sortBy(x => (
          x.getString("inc_day"), x.getIntValue("addrCnt"), x.getString("addr")
        ))(Ordering Tuple3(Ordering.String.reverse, Ordering.Int.reverse, Ordering.String.reverse)).head
      } else {
        tmpObj = list.head
      }
      tmpObj
    }).map(obj=>{
      obj.put("tag2",2)
      obj
    })
    //3、去除1&2已获取到地址的车队，筛选联系人名称一致且公司名称文本相似度0.8以上地址
    val ownerNameAndCompName8Rdd: RDD[JSONObject] = greater5OwnerNameRdd.filter(obj => {
      var owner_name: String = obj.getString("owner_name")
      var comp_name: String = obj.getString("comp_name")
      val contactor: String = obj.getString("contactor")
      val cont_name: String = obj.getString("cont_name")
      val source: String = obj.getString("source")
      val invalid_word_str="广州市,韶关市,深圳市,珠海市,汕头市,佛山市,江门市,湛江市,茂名市,肇庆市,惠州市,梅州市,汕尾市,河源市,阳江市,清远市,东莞市,中山市,潮州市,揭阳市,云浮市,顺德区,龙岗区,运输有限公司,供应链管理有限公司,货运有限公司,货运服务有限公司,货运代理服务部,货物运输服务部,货运服务部,物流有限公司,运输服务有限公司,建筑工程有限公司,发展有限公司,工程有限公司,建材有限公司,汽车贸易有限公司,汽车服务有限公司,科技有限公司,实业有限公司,贸易有限公司,有限公司"
      val invalid_word_arr: Array[String] = invalid_word_str.split(",")
      for (elem <- invalid_word_arr) {
        if (owner_name.contains(elem)){
          owner_name = owner_name.replaceAll(elem,"")
        }
        if (comp_name.contains(elem)){
          comp_name = comp_name.replaceAll(elem,"")
        }
      }
      val nameSimilar: Double = StrSimilarityUtils.similarity(owner_name, comp_name)
      !((owner_name == comp_name) || (owner_name != comp_name && contactor == cont_name && source == "comp")) && contactor == cont_name && nameSimilar > 0.8
    }).groupBy(_.getString("owner_name")).map(obj => {
      var list: List[JSONObject] = obj._2.toList
      val compAddrCnt: Int = list.size
      list = list.groupBy(_.getString("addr")).flatMap(json => {
        val list1: List[JSONObject] = json._2
        val addrCnt: Int = list1.size
        val tmpList1: List[JSONObject] = list1.map(json1 => {
          json1.put("addrCnt", addrCnt)
          json1
        })
        tmpList1
      }).map(json => {
        json.put("compAddrCnt", compAddrCnt)
        json
      }).toList
      var tmpObj = new JSONObject()
      if (compAddrCnt >= 2) {
        tmpObj = list.sortBy(x => (
          x.getString("inc_day"), x.getIntValue("addrCnt"), x.getString("addr")
        ))(Ordering Tuple3(Ordering.String.reverse, Ordering.Int.reverse, Ordering.String.reverse)).head
      } else {
        tmpObj = list.head
      }
      tmpObj
    }).map(obj=>{
      obj.put("tag3",3)
      obj
    })
    //二、4、owner_name长度小于5的车队（电话匹配且联系人一致），获取日期最新的一条地址
    val less5OwnerNameRdd: RDD[JSONObject] = senderJoinCityRdd.filter(obj => {
      val owner_name: String = obj.getString("owner_name")
      val encode_phone: String = obj.getString("encode_phone")
      val phone: String = obj.getString("phone")
      val contactor: String = obj.getString("contactor")
      val cont_name: String = obj.getString("cont_name")
      StringUtils.isNoneEmpty(owner_name) && owner_name.length < 5 && encode_phone==phone && contactor==cont_name
    }).groupBy(_.getString("owner_name")).map(obj=>{
      val tmpObj: JSONObject = obj._2.toList.maxBy(_.getString("inc_day"))
      tmpObj.put("tag4",4)
      tmpObj
    })
    val senderReceiveAddrTmpRdd: RDD[JSONObject] = ownerNameEqualCompNameRdd.union(contactorEqualContNameRdd).union(ownerNameAndCompName8Rdd).union(less5OwnerNameRdd)
      .groupBy(_.getString("owner_name"))
      .map(obj=>{
        obj._2.toList.sortBy(x => (
          x.getIntValue("tag1"), x.getIntValue("tag2"), x.getIntValue("tag3"), x.getIntValue("tag4")
        ))(Ordering Tuple4(Ordering.Int, Ordering.Int, Ordering.Int,Ordering.Int)).head
      }).map(obj => {
      val tmpObj = new JSONObject()
      val owner_name: String = obj.getString("owner_name")
      val addr: String = obj.getString("addr")
      val city_code: String = obj.getString("city_code")
      val province: String = obj.getString("province")
      val city: String = obj.getString("city")
      tmpObj.put("owner_name", owner_name)
      tmpObj.put("addr", addr)
      tmpObj.put("city_code", city_code)
      tmpObj.put("src", 1)
      tmpObj.put("priority", 1)
      tmpObj.put("province_name", province)
      tmpObj.put("city_name", city)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("收寄件地址临时表数据量:"+senderReceiveAddrTmpRdd.count())
    senderJoinCityRdd.unpersist()
    greater5OwnerNameRdd.unpersist()
    senderReceiveAddrTmpRdd
  }

  def cityMap(spark: SparkSession, incDay: String) = {
    val city_name_map_sql=
      s"""
         |select
         |*
         |from dm_gis.city_name_map
         |""".stripMargin
    val cityNameRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, city_name_map_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("citycode和城市映射表数据量:"+cityNameRdd.count())
    cityNameRdd
  }

  def whDigAddr(spark: SparkSession,cityNameRdd: RDD[JSONObject],vehicleMaxDayDf:DataFrame, incDay: String) = {
    val miningAddressSql=
      s"""
         |select
         |*
         |from dm_gis.dwd_mining_address_detail
         |where business_address is not null and business_address!=''
         |""".stripMargin
    val vehicleMaxDayMapRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).map(obj => {
      (obj.getString("owner_name"), obj)
    })
    val miningAddressRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, miningAddressSql).map(obj=>{
      (obj.getString("owner_name"),obj)
    }).join(vehicleMaxDayMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._1
      leftObj.put("province_name",rightObj.getString("province_name"))
      leftObj.put("city_name",rightObj.getString("city_name"))
      leftObj.put("owner_id",rightObj.getString("owner_id"))
      leftObj.put("credit_code",rightObj.getString("credit_code"))
      leftObj.put("reg_location",leftObj.getString("business_address"))
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("武汉挖掘地址数据量:"+miningAddressRdd.count())

    val returnGeocoderRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, miningAddressRdd, SfNetInteface.addressGeocoderInterface, 50, "156402fd097d4ff59779181139f59887", 2000)
    returnGeocoderRdd.take(10).foreach(println(_))
    /*val cityNameMapRdd: RDD[(String, JSONObject)] = cityNameRdd.map(obj => {
      (obj.getString("city"), obj)
    })*/
    val miningAddressTmpRdd: RDD[JSONObject] = returnGeocoderRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val citycode: String = result.getString("regcode")
      obj.put("citycode", citycode)
      obj
    }).map(obj => {
      val tmpObj = new JSONObject()
      val owner_name: String = obj.getString("owner_name")
      val addr: String = obj.getString("business_address")
      val city_code: String = obj.getString("citycode")
      tmpObj.put("owner_name", owner_name)
      tmpObj.put("addr", addr)
      tmpObj.put("city_code", city_code)
      tmpObj.put("src", 2)
      tmpObj.put("priority", 2)

      val province_name: String = obj.getString("province_name")
      val city_name: String = obj.getString("city_name")
      val owner_id: String = obj.getString("owner_id")
      val credit_code: String = obj.getString("credit_code")
      tmpObj.put("province_name", province_name)
      tmpObj.put("city_name", city_name)
      tmpObj.put("owner_id", owner_id)
      tmpObj.put("credit_code", credit_code)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("武汉挖掘地址临时表B数据量:"+miningAddressTmpRdd.count())
    miningAddressTmpRdd
  }

  def prcocessInterface(spark: SparkSession, baTransportCompanyAddressRdd: RDD[JSONObject], incDay: String) = {
    val returnGeocoderRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, baTransportCompanyAddressRdd, SfNetInteface.addressGeocoderInterface, 50, "156402fd097d4ff59779181139f59887", 2000)
    returnGeocoderRdd.take(10).foreach(println(_))
    val citycodeRdd: RDD[JSONObject] = returnGeocoderRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val citycode: String = result.getString("regcode")
      obj.put("citycode", citycode)
      obj
    })
    val returnAoiRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, citycodeRdd, SfNetInteface.addressAoiInterface, 50, "156402fd097d4ff59779181139f59887", 5000)
    returnAoiRdd.take(10).foreach(println(_))
    val filterCityVillageRdd: RDD[JSONObject] = returnAoiRdd.map(obj => {
      val api_result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result")
      val result: JSONObject = JSONUtil.getJsonObjectMulti(api_result, "result")
      val other: JSONObject = JSONUtil.getJsonObjectMulti(result, "other")
      val normresp: JSONObject = JSONUtil.getJsonObjectMulti(other, "normresp")
      val result_normresp: JSONObject = JSONUtil.getJsonObjectMulti(normresp, "result")
      val addrSplitInfo: JSONArray = JSONUtil.getJsonArrayMulti(result_normresp, "addrSplitInfo")
      val cityArray = new ArrayBuffer[String]()
      val roadArray = new ArrayBuffer[String]()
      val roomArray = new ArrayBuffer[String]()
      for (i <- 0 until (addrSplitInfo.size())) {
        val addrSplitInfoObj: JSONObject = addrSplitInfo.getJSONObject(i)
        val level: String = addrSplitInfoObj.getString("level")
        if (level == "2") {
          val city_name: String = addrSplitInfoObj.getString("name")
          cityArray.append(city_name)
        } else if (level == "10") {
          val road_name: String = addrSplitInfoObj.getString("name")
          roadArray.append(road_name)
        } else if (level == "17") {
          val room_name: String = addrSplitInfoObj.getString("name")
          roomArray.append(room_name)
        }
      }
      val cityStr: String = cityArray.mkString("|")
      val roadStr: String = roadArray.mkString("|")
      val roomStr: String = roomArray.mkString("|")
      obj.put("cityStr", cityStr)
      obj.put("roadStr", roadStr)
      obj.put("roomStr", roomStr)
      obj.remove("api_result")
      obj
    }).filter(obj => {
      val cityStr: String = obj.getString("cityStr")
      val roadStr: String = obj.getString("roadStr")
      val roomStr: String = obj.getString("roomStr")
      !(cityStr.contains("深圳市") && roadStr.contains("巷") && !roomStr.contains("商铺"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    filterCityVillageRdd.filter(_.getString("owner_name")=="深圳市华赢物流有限公司").take(10).foreach(println(_))
    filterCityVillageRdd.filter(_.getString("owner_name")=="佛山市陈志物流有限公司").take(10).foreach(println(_))
    filterCityVillageRdd
  }

  def baTransportAddr(spark: SparkSession, vehicleMaxDayDf:DataFrame, incDay: String,cityNameRdd: RDD[JSONObject]) = {
    val baTransportCompanySql=
      s"""
         |select
         |*
         |from dm_gis.dwd_ba_transport_company_registered_address
         |where addr is not null and addr!=''
         |""".stripMargin
    val vehicleMaxDayMapRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).map(obj => {
      (obj.getString("owner_name"), obj)
    })
    val baTransportCompanyAddressRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, baTransportCompanySql).map(obj=>{
      (obj.getString("owner_name"),obj)
    }).join(vehicleMaxDayMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._1
      leftObj.put("province_name",rightObj.getString("province_name"))
      leftObj.put("city_name",rightObj.getString("city_name"))
      leftObj.put("owner_id",rightObj.getString("owner_id"))
      leftObj.put("credit_code",rightObj.getString("credit_code"))
      leftObj.put("reg_location",leftObj.getString("addr"))
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("宝安区注册地址数据量:"+baTransportCompanyAddressRdd.count())
    val filterCityVillageRdd: RDD[JSONObject] = prcocessInterface(spark, baTransportCompanyAddressRdd, incDay)
    val baTransportCompanyAddressTmpRdd: RDD[JSONObject] = filterCityVillageRdd.map(obj => {
      val tmpObj = new JSONObject()
      val owner_name: String = obj.getString("owner_name")
      val addr: String = obj.getString("addr")
      val city_code: String = obj.getString("citycode")
      tmpObj.put("owner_name", owner_name)
      tmpObj.put("addr", addr)
      tmpObj.put("city_code", city_code)
      tmpObj.put("src", 3)
      tmpObj.put("priority", 5)
      val province_name: String = obj.getString("province_name")
      val city_name: String = obj.getString("city_name")
      val owner_id: String = obj.getString("owner_id")
      val credit_code: String = obj.getString("credit_code")
      tmpObj.put("province_name", province_name)
      tmpObj.put("city_name", city_name)
      tmpObj.put("owner_id", owner_id)
      tmpObj.put("credit_code", credit_code)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("宝安区注册地址临时表C数据量:"+baTransportCompanyAddressTmpRdd.count())
    baTransportCompanyAddressTmpRdd
  }

  def lgRegisteredAddr(spark: SparkSession, vehicleMaxDayDf: DataFrame, incDay: String) = {
    val lgTransportCompanySql=
      s"""
         |select
         |*
         |from dm_gis.dwd_lg_transport_company_registered_address
         |where addr is not null and addr!=''
         |""".stripMargin
    val vehicleMaxDayMapRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).map(obj => {
      (obj.getString("owner_name"), obj)
    })
    val lgTransportCompanyAddressRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, lgTransportCompanySql).map(obj=>{
      (obj.getString("owner_name"),obj)
    }).join(vehicleMaxDayMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._1
      leftObj.put("province_name",rightObj.getString("province_name"))
      leftObj.put("city_name",rightObj.getString("city_name"))
      leftObj.put("owner_id",rightObj.getString("owner_id"))
      leftObj.put("credit_code",rightObj.getString("credit_code"))
      leftObj.put("reg_location",leftObj.getString("addr"))
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("龙岗区注册地址数据量:"+lgTransportCompanyAddressRdd.count())
    val filterCityVillageRdd: RDD[JSONObject] = prcocessInterface(spark, lgTransportCompanyAddressRdd, incDay)
    val lgTransportCompanyAddressTmpRdd: RDD[JSONObject] = filterCityVillageRdd.map(obj => {
      val tmpObj = new JSONObject()
      val owner_name: String = obj.getString("owner_name")
      val addr: String = obj.getString("addr")
      val city_code: String = obj.getString("citycode")
      tmpObj.put("owner_name", owner_name)
      tmpObj.put("addr", addr)
      tmpObj.put("city_code", city_code)
      tmpObj.put("src", 4)
      tmpObj.put("priority", 5)
      val province_name: String = obj.getString("province_name")
      val city_name: String = obj.getString("city_name")
      val owner_id: String = obj.getString("owner_id")
      val credit_code: String = obj.getString("credit_code")
      tmpObj.put("province_name", province_name)
      tmpObj.put("city_name", city_name)
      tmpObj.put("owner_id", owner_id)
      tmpObj.put("credit_code", credit_code)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("龙岗区注册地址临时表D数据量:"+lgTransportCompanyAddressTmpRdd.count())
    lgTransportCompanyAddressTmpRdd
  }

  def yzCarrierAddr(spark: SparkSession, vehicleMaxDayDf: DataFrame, incDay: String) = {
    val yzTransportCompanySql=
      s"""
         |select
         |*
         |from dm_gis.dim_ddjy_yz_carrier_concat_di
         |where address is not null and address!=''
         |--and city in('深圳市','佛山市')
         |""".stripMargin
    val vehicleMaxDayMapRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).map(obj => {
      (obj.getString("owner_name"), obj)
    })
    val yzTransportCompanyAddressRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, yzTransportCompanySql).map(obj=>{
      (obj.getString("carrier_name"),obj)
    }).join(vehicleMaxDayMapRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._1
      leftObj.put("province_name",rightObj.getString("province_name"))
      leftObj.put("city_name",rightObj.getString("city_name"))
      leftObj.put("owner_id",rightObj.getString("owner_id"))
      leftObj.put("credit_code",rightObj.getString("credit_code"))
      leftObj.put("reg_location",leftObj.getString("address"))
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("运政系统地址数据量:"+yzTransportCompanyAddressRdd.count())
    val filterCityVillageRdd: RDD[JSONObject] = prcocessInterface(spark, yzTransportCompanyAddressRdd, incDay)
    val yzTransportCompanyAddressTmpRdd: RDD[JSONObject] = filterCityVillageRdd.map(obj => {
      val tmpObj = new JSONObject()
      val owner_name: String = obj.getString("carrier_name")
      val addr: String = obj.getString("address")
      val city_code: String = obj.getString("citycode")
      tmpObj.put("owner_name", owner_name)
      tmpObj.put("addr", addr)
      tmpObj.put("city_code", city_code)
      tmpObj.put("src", 6)
      tmpObj.put("priority", 5)
      val province_name: String = obj.getString("province_name")
      val city_name: String = obj.getString("city_name")
      val owner_id: String = obj.getString("owner_id")
      val credit_code: String = obj.getString("credit_code")
      tmpObj.put("province_name", province_name)
      tmpObj.put("city_name", city_name)
      tmpObj.put("owner_id", owner_id)
      tmpObj.put("credit_code", credit_code)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("运政系统地址临时表E数据量:"+yzTransportCompanyAddressTmpRdd.count())
    yzTransportCompanyAddressTmpRdd
  }

  def unionAllAddress(spark: SparkSession, senderReceiveAddrTmpRdd: RDD[JSONObject],
                      miningAddressTmpRdd: RDD[JSONObject],
                      baTransportCompanyAddressTmpRdd: RDD[JSONObject],
                      lgTransportCompanyAddressTmpRdd: RDD[JSONObject],
                      yzTransportCompanyAddressTmpRdd: RDD[JSONObject],
                      companyDtlCreditcodeTmpRdd: RDD[JSONObject],
                      gdInterfaceTmpRdd: RDD[JSONObject],
                      postalAddressRdd: RDD[JSONObject],
                      regLocationRdd: RDD[JSONObject],
                      incDay: String) = {
    import spark.implicits._
    val invariantAddresssDf: DataFrame = baTransportCompanyAddressTmpRdd
      .union(lgTransportCompanyAddressTmpRdd)
      .union(yzTransportCompanyAddressTmpRdd)
      .union(companyDtlCreditcodeTmpRdd)
      .map(obj=>{
        val owner_name: String = obj.getString("carrier_name")
        val addr: String = obj.getString("address")
        val city_code: String = obj.getString("citycode")
        val province_name: String = obj.getString("province_name")
        val city_name: String = obj.getString("city_name")
        val owner_id: String = obj.getString("owner_id")
        val credit_code: String = obj.getString("credit_code")
        val src=4
        val priority=6
        (owner_name,owner_id,credit_code,province_name,city_name,city_code,addr,src,priority)
      }).toDF("owner_name","owner_id","credit_code","province_name","city_name","city_code","addr","src","priority")
    SparkWrite.writeToHive(spark,invariantAddresssDf,"inc_day",incDay,"dm_gis.ddjy_invariant_addresss_di")
    //invariantAddresssDf.createOrReplaceTempView("invariantAddresssTmp")
    //spark.sql(s"insert overwrite table dm_gis.ddjy_invariant_addresss_di partition(inc_day='$incDay') select * from invariantAddresssTmp")
    val unionAllAddressRdd: RDD[JSONObject] = senderReceiveAddrTmpRdd
      .union(miningAddressTmpRdd)
      .union(baTransportCompanyAddressTmpRdd)
      .union(lgTransportCompanyAddressTmpRdd)
      .union(yzTransportCompanyAddressTmpRdd)
      .union(companyDtlCreditcodeTmpRdd)
      .union(gdInterfaceTmpRdd)
      .union(postalAddressRdd)
      .union(regLocationRdd)
      .distinct()
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("7个地址临时表汇总数据量:"+unionAllAddressRdd.count())
    senderReceiveAddrTmpRdd.unpersist()
    unionAllAddressRdd
  }

  def allAddressCheck(spark: SparkSession, unionAllAddressRdd: RDD[JSONObject],vehicleMaxDayDf:DataFrame, incDay: String) = {
    import spark.implicits._
    val updateFieldRdd: RDD[JSONObject] = unionAllAddressRdd
      .map(obj => {
        var citycode: String = obj.getString("city_code")
        if (citycode!=null && citycode.length==2){
          citycode = "0"+citycode
        }
        obj.put("reg_location", obj.getString("addr"))
        obj.put("citycode",citycode)
        obj
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val needProcessAddrRdd: RDD[JSONObject] = updateFieldRdd.filter(obj => {
      val aoicode: String = obj.getString("aoicode")
      val x: String = obj.getString("x")
      val y: String = obj.getString("y")
      val adcode: String = obj.getString("adcode")
      val aoiid: String = obj.getString("aoiid")
      val aoi_name: String = obj.getString("aoi_name")
      //StringUtils.isEmpty(aoicode) ||
      StringUtils.isEmpty(x) ||
        StringUtils.isEmpty(y) ||
        StringUtils.isEmpty(adcode)
      //||
      //StringUtils.isEmpty(aoiid) ||
      //StringUtils.isEmpty(aoi_name)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调地理编码获取aoi坐标接口数据量:"+needProcessAddrRdd.count())
    needProcessAddrRdd.take(10).foreach(println(_))
    val httpAddressGeocoder = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "715", "车队途径线索挖掘地址检验", "获取地址坐标信息", "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=&city=&address=%s", "156402fd097d4ff59779181139f59887", needProcessAddrRdd.count(), 50)

    val returnGeocoderRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, needProcessAddrRdd, SfNetInteface.addressGeocoderInterface, 50, "156402fd097d4ff59779181139f59887", 10000)
    val addressGeocoderRdd: RDD[JSONObject] = returnGeocoderRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val x: String = result.getString("xcoord")
      val y: String = result.getString("ycoord")
      val adcode: String = result.getString("adcode")
      val adname: JSONArray = JSONUtil.getJsonArrayMulti(result, "adname")
      var province_name: String = result.getString("province_name")
      var city_name: String = result.getString("city_name")
      if (adname.size()!=0){
        province_name = adname.getString(0)
        city_name = adname.getString(1)
      }
      obj.put("province_name",province_name)
      obj.put("city_name",city_name)
      obj.put("x", x)
      obj.put("y", y)
      obj.put("adcode", adcode)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调地理编码接口后数据量："+addressGeocoderRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpAddressGeocoder)

    val emptyGeocoderRdd: RDD[JSONObject] = addressGeocoderRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("x"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调地址aoi接口数据量:"+emptyGeocoderRdd.count())
    val httpAddressAoi = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "715", "车队途径线索挖掘地址检验", "获取地址坐标信息", "http://gis-int.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=zh&showserver=true", "156402fd097d4ff59779181139f59887", emptyGeocoderRdd.count(), 50)

    val returnAoiRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, emptyGeocoderRdd, SfNetInteface.addressAoiInterface, 50, "156402fd097d4ff59779181139f59887", 5000)
    val addAoicodeRdd: RDD[JSONObject] = returnAoiRdd.repartition(200).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val tcsObj: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(result, "tcs")
      val aoicode: String = tcsObj.getString("aoicode")
      obj.put("aoicode", aoicode)
      val other: JSONObject = JSONUtil.getJSONObject(result, "other")
      val normresp: JSONObject = JSONUtil.getJSONObject(other, "normresp")
      val resultObj: JSONObject = JSONUtil.getJSONObject(normresp, "result")
      val geocoder: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(resultObj, "geocoder")
      val x: String = geocoder.getString("x")
      val y: String = geocoder.getString("y")
      val adcode: String = geocoder.getString("adcode")
      obj.put("x", x)
      obj.put("y", y)
      obj.put("adcode", adcode)
      obj
    })
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpAddressAoi)

    val notNeedProcessAddrRdd: RDD[JSONObject] = updateFieldRdd.filter(obj => {
      val aoicode: String = obj.getString("aoicode")
      val x: String = obj.getString("x")
      val y: String = obj.getString("y")
      val adcode: String = obj.getString("adcode")
      val aoiid: String = obj.getString("aoiid")
      val aoi_name: String = obj.getString("aoi_name")
      //StringUtils.isNoneEmpty(aoicode) &&
      StringUtils.isNoneEmpty(x) &&
        StringUtils.isNoneEmpty(y) &&
        StringUtils.isNoneEmpty(adcode)
      //&&
      // StringUtils.isNoneEmpty(aoiid) &&
      //StringUtils.isNoneEmpty(aoi_name)
    })
    val addGeocoderRdd: RDD[JSONObject] = addAoicodeRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("x"))
    }).union(addAoicodeRdd).union(notNeedProcessAddrRdd).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加坐标信息后数据量:"+addGeocoderRdd.count())
    /*val addGeocoderDf: DataFrame = addGeocoderRdd.groupBy(_.getString("owner_name")).map(obj => {
      val owner_name: String = obj._1
      val size: Int = obj._2.toList.size
      (owner_name, size)
    }).toDF("owner_name", "size")
    addGeocoderDf.createOrReplaceTempView("addGeocoderTmp")
    spark.sql("insert overwrite table dm_gis.add_geocoder_di select * from addGeocoderTmp")*/
    //添加分组id
    val addIdRdd: RDD[JSONObject] = addGeocoderRdd.groupBy(_.getString("owner_name")).flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList.sortBy(_.getString("reg_location"))
      val owner_name: String = obj._1
      for (i <- list.indices) {
        val iObj: JSONObject = list(i)
        var id: String = iObj.getString("id")
        if (id == null) {
          iObj.put("id", owner_name + "_" + i)
        }
        id = iObj.getString("id")
        for (j <- (i + 1).until(list.size)) {
          val jObj: JSONObject = list(j)
          val iX: Double = JSONUtil.getJsonDouble(iObj, "x", 0.0)
          val iY: Double = JSONUtil.getJsonDouble(iObj, "y", 0.0)
          val jX: Double = JSONUtil.getJsonDouble(jObj, "x", Int.MaxValue)
          val jY: Double = JSONUtil.getJsonDouble(jObj, "y", Int.MaxValue)
          val distance: Double = DistanceUtils.getDistance(iX, iY, jX, jY)
          // val similar: Double = KeyWordUtil.similarity(iAddr, jAddr)
          if (distance <= 500) {
            jObj.put("id", id)
          }
        }
      }
      list
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addIdRdd:"+addIdRdd.count())
    //计算地址可信度
    val priorityRdd: RDD[(String, JSONObject)] = addIdRdd.groupBy(_.getString("owner_name")).flatMap(obj => {
      val list: List[(String, String)] = obj._2.toList.map(json => {
        val id: String = json.getString("id")
        val priority: String = json.getString("priority")
        (id, priority)
      }).distinct
      val cnt: Double = list.size
      val priorityList = list.groupBy(_._1).map(json => {
        val tmpObj = new JSONObject()
        val size: Double = json._2.size
        val priority_new: Double = size / cnt
        tmpObj.put("id", json._1)
        tmpObj.put("priority_new", priority_new)
        tmpObj
      }).toList
      priorityList
    }).map(obj=>{
      (obj.getString("id"),obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("priorityRdd:"+priorityRdd.count())
    priorityRdd.take(10).foreach(println(_))
    //将可信度关联回原表
    val addPriorityNewRdd: RDD[JSONObject] = addIdRdd.map(obj => {
      (obj.getString("id"), obj)
    }).leftOuterJoin(priorityRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("priority_new", rightObj.getString("priority_new"))
      }
      leftObj
    }).groupBy(_.getString("id")).flatMap(obj=>{
      val list: List[JSONObject] = obj._2.toList
      val min_src: String = list.minBy(_.getString("src")).getString("src")
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("min_src", min_src)
        json
      })
      tmpList
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //生成rank字段
    val produceRankRdd: RDD[(String, JSONObject)] = addPriorityNewRdd.map(obj => {
      val owner_name: String = obj.getString("owner_name")
      val id: String = obj.getString("id")
      val priority_new: Double = obj.getDoubleValue("priority_new")
      val src: Int = obj.getIntValue("src")
      (owner_name, (id, priority_new, src))
    }).groupByKey().flatMap(obj => {
      val list: List[(String, Double, Int)] = obj._2.toList
      val min_src: Int = list.minBy(_._3)._3
      val tmpList = list.map(json => {
        val id: String = json._1
        val priority_new: Double = json._2
        (id, priority_new, min_src)
      }).distinct.sortBy(json => {
        (json._2, json._3)
      })(Ordering Tuple2(Ordering.Double.reverse, Ordering.Int))
      val tmpArray = new ArrayBuffer[JSONObject]()
      for (i <- tmpList.indices) {
        val tmpObj = new JSONObject()
        val id: String = tmpList(i)._1
        val priority_new: Double = tmpList(i)._2
        tmpObj.put("priority_new", priority_new)
        tmpObj.put("id", id)
        tmpObj.put("rank", i + 1)
        tmpArray.append(tmpObj)
      }
      tmpArray.distinct
    }).map(obj => {
      (obj.getString("id"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("生成rank")
    produceRankRdd.take(10).foreach(println(_))
    //添加rank
    val addRankRdd: RDD[JSONObject] = addPriorityNewRdd.map(obj=>{
      (obj.getString("id"), obj)
    }).leftOuterJoin(produceRankRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("rank",rightObj.getString("rank"))
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加rank")
    addRankRdd.take(10).foreach(println(_))
    //调aoi接口获取aoiname、aoiid
    val httpAoiArea = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "715", "车队途径线索挖掘地址检验", "获取aoi信息", "http://sds-core-datarun.sf-express.com/datarun/aoi/getCircleAoiBase?x=%s&y=%s&radius=0.1", "", addRankRdd.count(), 100)

    val addDistRdd: RDD[JSONObject] = addRankRdd.repartition(100).flatMap(obj => {
      val agr_lng: String = obj.getString("x")
      val agr_lat: String = obj.getString("y")
      obj.put("agr_lng", agr_lng)
      obj.put("agr_lat", agr_lat)
      val retObj: JSONObject = SfNetInteface.aoiAreaInterface(obj)
      val api_result: JSONObject = JSONUtil.getJSONObject(retObj, "api_result")
      val dataArray: JSONArray = JSONUtil.getJsonArrayMulti(api_result, "data")
      val tmpList = new ArrayBuffer[JSONObject]()
      if (dataArray.size()!=0){
        for (i <- 0 until dataArray.size()) {
          val tmpObj = new JSONObject()
          val dataObj: JSONObject = dataArray.getJSONObject(i)
          val name: String = dataObj.getString("name")
          val dist: String = dataObj.getString("dist")
          val aoiid: String = dataObj.getString("id")
          tmpObj.fluentPutAll(obj)
          tmpObj.put("aoi_name", name)
          tmpObj.put("dist", dist)
          tmpObj.put("aoiid", aoiid)
          tmpList.append(tmpObj)
        }
      }else{
        tmpList.append(obj)
      }
      tmpList
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调aoi接口增加dist字段数据量:"+addDistRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpAoiArea)

    addDistRdd.take(10).foreach(println(_))
    //聚合添加suspectedAddress
    val suspectedAddressRdd= addDistRdd
      .groupBy(_.getString("id")).map(obj=>{
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.maxBy(json=>{
        JSONUtil.getJsonDouble(json,"priority_new",0.0)
      })
      val addresObj = new JSONObject()
      val addressArray = new ArrayBuffer[JSONObject]()
      list.foreach(json=>{
        val senderObj = new JSONObject()
        val addressName: String = json.getString("addr")
        val lng: String = json.getString("x")
        val lat: String = json.getString("y")
        val source: String = json.getString("src")
        val aoi_name: String = json.getString("aoi_name")
        val aoiid: String = json.getString("aoiid")
        senderObj.put("addressName", addressName)
        senderObj.put("lng", lng)
        senderObj.put("lat", lat)
        senderObj.put("source", source)
        senderObj.put("aoi_name", aoi_name)
        senderObj.put("aoiid", aoiid)
        addressArray.append(senderObj)
      })
      val addressJsonArray = new JSONArray()
      for (elem <- addressArray.distinct) {
        addressJsonArray.add(elem)
      }
      addresObj.put("address",addressJsonArray.toJSONString)
      tmpObj.put("suspected_address", addresObj.toJSONString)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("聚合添加suspected_address字段数据量:"+suspectedAddressRdd.count())

    val cal = Calendar.getInstance
    val time = cal.getTime
    val updatetime: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time)
    val resultDf: DataFrame = suspectedAddressRdd.map(obj => {
      (
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("credit_code"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        updatetime,
        obj.getString("suspected_address"),
        obj.getString("priority_new"),
        obj.getString("adcode"),
        obj.getString("rank")
      )
    }).toDF("owner_id", "owner_name", "credit_code", "province_name", "city_name", "updatetime", "suspected_address", "priority","adcode","rank")
    SparkWrite.writeToHive(spark,resultDf,"inc_day",incDay,"dm_gis.ddjy_mid_suspected_business_address_di")
    //resultDf.repartition(5).createOrReplaceTempView("resultTmp")
    //spark.sql(s"insert overwrite table dm_gis.ddjy_mid_suspected_business_address_di partition(inc_day='$incDay') select * from resultTmp")
    //对每个公司地址，按可信度降序-src升序排序，取第一条ID
    val filterMaxIdRdd: RDD[JSONObject] = addDistRdd.groupBy(_.getString("owner_name")).flatMap(obj => {
      val maxObj: JSONObject = obj._2.toList.sortBy(x => {
        val priority_new: Double = JSONUtil.getJsonDouble(x, "priority_new", 0.0)
        val src: Double = JSONUtil.getJsonDouble(x, "src", 9999)
        (priority_new, src)
      })(Ordering Tuple2(Ordering.Double.reverse, Ordering.Double)).head
      val maxId: String = maxObj.getString("id")
      val tmpList: List[JSONObject] = obj._2.toList.filter(json => {
        val id: String = json.getString("id")
        id == maxId
      })
      tmpList
    })
    filterMaxIdRdd
  }

  def insertHiveTable(spark: SparkSession,filterMaxIdRdd:RDD[JSONObject] ,incDay: String) = {
    import spark.implicits._
    val resultRdd: RDD[JSONObject] = filterMaxIdRdd.map(obj => {
      val addressName: String = obj.getString("addr")
      val id: String = obj.getString("id")
      ((addressName, id), obj)
    }).groupByKey().map(obj => {
      val tmpObj: JSONObject = obj._2.toList.minBy(_.getString("src"))
      tmpObj
    }).groupBy(_.getString("id")).map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val tmpObj: JSONObject = list.maxBy(json => {
        JSONUtil.getJsonDouble(json, "priority_new", 0.0)
      })
      val addresObj = new JSONObject()
      val addressArray = new ArrayBuffer[JSONObject]()
      list.foreach(json => {
        val senderObj = new JSONObject()
        val addressName: String = json.getString("addr")
        val lng: String = json.getString("x")
        val lat: String = json.getString("y")
        val source: String = json.getString("src")
        val aoi_name: String = json.getString("aoi_name")
        val aoiid: String = json.getString("aoiid")
        senderObj.put("addressName", addressName)
        senderObj.put("lng", lng)
        senderObj.put("lat", lat)
        senderObj.put("source", source)
        senderObj.put("aoi_name", aoi_name)
        senderObj.put("aoiid", aoiid)
        addressArray.append(senderObj)
      })
      val addressJsonArray = new JSONArray()
      for (elem <- addressArray.distinct) {
        addressJsonArray.add(elem)
      }
      addresObj.put("address", addressJsonArray.toJSONString)
      tmpObj.put("suspected_address", addresObj.toJSONString)
      tmpObj
    })
    val cal1 = Calendar.getInstance
    val time1 = cal1.getTime
    val updatetime1: String = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time1)
    val businessAddressDf: DataFrame = resultRdd.map(obj => {
      (
        obj.getString("owner_id"),
        obj.getString("owner_name"),
        obj.getString("credit_code"),
        obj.getString("province_name"),
        obj.getString("city_name"),
        updatetime1,
        obj.getString("suspected_address"),
        obj.getString("priority_new"),
        obj.getString("adcode")
      )
    }).toDF("owner_id", "owner_name", "credit_code", "province_name", "city_name", "updatetime", "suspected_address", "priority","adcode")
    SparkWrite.writeToHive(spark,businessAddressDf,"inc_day",incDay,"dm_gis.ddjy_suspected_business_address_di")
    //businessAddressDf.repartition(5).createOrReplaceTempView("businessAddressTmp")
    //spark.sql(s"insert overwrite table dm_gis.ddjy_suspected_business_address_di partition(inc_day='$incDay') select * from businessAddressTmp")
  }


  def tycCarrierAddr(spark: SparkSession, vehicleMaxDayDf: DataFrame, incDay: String, cityNameRdd: RDD[JSONObject],companyDtlCreditcodeRdd: RDD[JSONObject]) = {
    val tycAddrSql=
      """
        |select
        |credit_code,name,reg_location,postal_address,city_adcode,aoiid,aoi_code,aoi_name,x,y,city_code
        |from dm_gis.ddjy_tyc_owner_info_df
        |where inc_day in(select max(inc_day) from dm_gis.ddjy_tyc_owner_info_df)
        |--and (name like '%深圳市%' or name like '%佛山市%')
        |""".stripMargin
    val tycAddrRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, tycAddrSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    tycAddrRdd.filter(_.getString("credit_code")=="913702035720880446").foreach(println(_))
    logger.error("天眼查车队地址数据量:"+tycAddrRdd.count())
    val vehicleCreditCodeRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).map(obj => {
      (obj.getString("credit_code"), obj)
    })
    val cityNameMapRdd: RDD[(String, JSONObject)] = cityNameRdd.map(obj => {
      (obj.getString("city"), obj)
    })
    val tycJoinVehicleCreditcodeRdd: RDD[JSONObject] = tycAddrRdd.map(obj => {
      (obj.getString("credit_code"), obj)
    }).leftOuterJoin(vehicleCreditCodeRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("city_name", rightObj.getString("city_name"))
        leftObj.put("province_name", rightObj.getString("province_name"))
        leftObj.put("owner_id", rightObj.getString("owner_id"))
        leftObj.put("name", rightObj.getString("owner_name"))
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("credit_code关联车队信息表后数据量:"+tycJoinVehicleCreditcodeRdd.count())
    val vehicleOwnerNameRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, vehicleMaxDayDf).map(obj => {
      (obj.getString("owner_name"), obj)
    })
    val nullCityNameRdd = tycJoinVehicleCreditcodeRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("owner_id"))
    }).map(obj=>{
      (obj.getString("name"), obj)
    }).join(vehicleOwnerNameRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2
      leftObj.put("city_name", rightObj.getString("city_name"))
      leftObj.put("province_name", rightObj.getString("province_name"))
      leftObj.put("owner_id", rightObj.getString("owner_id"))
      leftObj
    })
    val notNullCityNameRdd: RDD[JSONObject] = tycJoinVehicleCreditcodeRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("owner_id"))
    })
    val addCityNameRdd: RDD[JSONObject] = nullCityNameRdd.union(notNullCityNameRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("owner_name关联车队信息表后数据量:"+addCityNameRdd.count())
    addCityNameRdd.take(10).foreach(println(_))
    val nullCitycodeRdd: RDD[(String, JSONObject)] = addCityNameRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("city_code"))
    }).map(obj=>{
      (obj.getString("city_name"), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("空citycode数据量:"+nullCitycodeRdd.count())
    nullCitycodeRdd.take(10).foreach(println(_))
    val notNullCitycodeRdd: RDD[JSONObject] = addCityNameRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("city_code"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("非空citycode数据量:"+notNullCitycodeRdd.count())
    notNullCitycodeRdd.take(10).foreach(println(_))
    val addCityCodeRdd: RDD[JSONObject] = nullCitycodeRdd.leftOuterJoin(cityNameMapRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("city_code", rightObj.getString("citycode"))
      }
      leftObj
    }).union(notNullCitycodeRdd).filter(obj=>{
      StringUtils.isNoneEmpty(obj.getString("name"))
    }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    val postalAddressRdd: RDD[JSONObject] = addCityCodeRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("postal_address"))
    }).map(obj=>{
      val owner_name: String = obj.getString("name")
      val addr: String = obj.getString("postal_address")
      val aoicode: String = obj.getString("aoi_code")
      val adcode: String = obj.getString("city_adcode")
      obj.put("owner_name", owner_name)
      obj.put("addr", addr)
      obj.put("src",7)
      obj.put("priority",5)
      obj.put("aoicode",aoicode)
      obj.put("adcode",adcode)
      obj
    }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("天眼查postalAddress临时表M数据量:"+postalAddressRdd.count())
    val regLocationRdd: RDD[JSONObject] = addCityCodeRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("reg_location"))
    }).map(obj=>{
      val owner_name: String = obj.getString("name")
      val addr: String = obj.getString("reg_location")
      val aoicode: String = obj.getString("aoi_code")
      val adcode: String = obj.getString("city_adcode")
      obj.put("owner_name", owner_name)
      obj.put("addr", addr)
      obj.put("src",8)
      obj.put("priority",5)
      obj.put("aoicode",aoicode)
      obj.put("adcode",adcode)
      obj
    }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("天眼查regLocation临时表N数据量:"+regLocationRdd.count())
    (postalAddressRdd,regLocationRdd)
  }

  def execute(incDay:String,fri_day:String,city:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取车辆所属车队维表最大分区数据
    val vehicleMaxDayDf: DataFrame = getVehicleMaxDayData(spark, fri_day,city)
    //获取citymap数据
    val cityNameRdd: RDD[JSONObject] = cityMap(spark, incDay)
    //获取收寄件地址
    val senderReceiveAddrTmpRdd: RDD[JSONObject] = senderReceiverDetail(spark,cityNameRdd,vehicleMaxDayDf, incDay)
    //获取武汉挖掘地址
    val miningAddressTmpRdd: RDD[JSONObject] = whDigAddr(spark, cityNameRdd,vehicleMaxDayDf, incDay)
    //获取宝安区运输企业登记地址表
    val baTransportCompanyAddressTmpRdd: RDD[JSONObject] = baTransportAddr(spark, vehicleMaxDayDf, incDay,cityNameRdd)
    //获取龙岗区注册地址表
    val lgTransportCompanyAddressTmpRdd: RDD[JSONObject] = lgRegisteredAddr(spark, vehicleMaxDayDf, incDay)
    //获取运政系统地址表
    val yzTransportCompanyAddressTmpRdd: RDD[JSONObject] = yzCarrierAddr(spark, vehicleMaxDayDf, incDay)
    //企业库地址明细表
    val (companyDtlCreditcodeTmpRdd,companyDtlCreditcodeRdd) = companyDatabaseDetail(spark, vehicleMaxDayDf, incDay)
    //车队返回高德地址明细表
    val gdInterfaceTmpRdd: RDD[JSONObject] = carrierGDAddressDetail(spark, vehicleMaxDayDf, incDay,fri_day)
    //天眼查地址明细表
    val (postalAddressRdd,regLocationRdd) = tycCarrierAddr(spark, vehicleMaxDayDf, incDay, cityNameRdd, companyDtlCreditcodeRdd)
    //汇总7个临时表并进行地址校验和地址可信度计算
    val unionAllAddressRdd: RDD[JSONObject] = unionAllAddress(spark, senderReceiveAddrTmpRdd,
      miningAddressTmpRdd,
      baTransportCompanyAddressTmpRdd,
      lgTransportCompanyAddressTmpRdd,
      yzTransportCompanyAddressTmpRdd,
      companyDtlCreditcodeTmpRdd,
      gdInterfaceTmpRdd,
      postalAddressRdd,
      regLocationRdd,
      incDay)
    val filterMaxIdRdd: RDD[JSONObject] = allAddressCheck(spark, unionAllAddressRdd, vehicleMaxDayDf, incDay)
    //写入经营地址表
    insertHiveTable(spark,filterMaxIdRdd,incDay)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val fri_day: String = args(1)
    val city: String = args(2)
    execute(incDay,fri_day,city)
    logger.error("======>>>>>>CarrierPathClueMining Execute Ok")
  }


}
