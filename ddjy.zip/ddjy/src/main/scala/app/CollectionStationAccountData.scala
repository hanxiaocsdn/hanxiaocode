package app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.time.LocalDate

import com.sf.gis.scala.base.util.DateUtil
/**
 * @Description:油站账单报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:375
 * 任务名称：油站账单报表
 * 依赖任务：吨吨加油-订单过滤明细表去重 352、每日-原始油站信息过滤表 512、每日-原始钱包历史交易明细表mysql导入hive 500、每日-原始钱包信息表mysql导入hive 499
 * 数据源：ddjy_dim_station_info_filter、ddjy_dwd_station_order_repartition_di、ddjy_ods_wallet_history、ddjy_ods_dim_wallet、dm_ddjy_station_account_report_di
 * 调用服务地址：无
 * 数据结果：dm_ddjy_station_account_report_di
 */
object CollectionStationAccountData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String) = {
    val daySql=
      s"""
         |select
         |from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |'' as account_month,
         |corp_id,t1.id,account_prop,
         |round(nvl(begin_balance,0.00),2) as begin_balance,
         |round(nvl(station_received_amount,0.00),2) as station_received_amount,
         |round(nvl(ft_sale_money,0.00),2) as ft_sale_money,
         |round(nvl(need_fleet_refund,0.00),2) as need_fleet_refund,
         |round(nvl(yes_fleet_refund,0.00),2) as yes_fleet_refund,
         |round(nvl(trade_amount,0.00),2) as trade_amount,
         |round(nvl(t7.aggr_fleet_refund,0.00)+nvl(t8.aggr_fleet_refund,0.00),2) as aggr_fleet_refund,
         |round((nvl(begin_balance,0.00)+nvl(trade_amount,0.00)-nvl(station_received_amount,0.00)+nvl(yes_fleet_refund,0.00)),2) as end_balance,
         |'每日' as tag
         |from
         |(
         |	select
         |	id,account_prop,corp_id,station_received_amount,ft_sale_money,need_fleet_refund,yes_fleet_refund
         |	from
         |	(
         |		select id,
         |		account_prop,
         |		corp_id as corp_id
         |		from dm_gis.ddjy_dim_station_info_filter
         |		where inc_day='$inc_day'
         |
         |	) t0
         |	left join
         |	(
         |		select station_id,
         |		sum(station_received_amount) as station_received_amount,
         |		sum(ft_sale_money) as ft_sale_money,
         |		sum(if(discount_model=2 and station_refund_status=0,station_refund,null)) as need_fleet_refund,
         |		sum(if(discount_model=2 and station_refund_status=1,station_refund,null)) as yes_fleet_refund
         |		from dm_gis.ddjy_dwd_station_order_repartition_di
         |		where inc_day='$inc_day'
         |		and order_status=2
         |		group by station_id
         |	) t2
         |	on t0.id=t2.station_id
         |	where account_prop!='2'
         |) t1
         |left join
         |(
         |	select
         |	user_id,
         |	sum(trade_amount) as trade_amount
         |	from
         |	(
         |		select
         |		wallet_id,
         |		trade_amount
         |		from dm_gis.ddjy_ods_wallet_history
         |		where inc_day='$inc_day' and inoutcome_type = 2
         |	) t3
         |	left join
         |	(
         |		select id,
         |		user_id
         |		from dm_gis.ddjy_ods_dim_wallet
         |		where inc_day='$inc_day' and user_type =4 and account_type = 4
         |	) t4
         |	on t3.wallet_id=t4.id
         |	group by user_id
         |) t5
         |on t1.id=t5.user_id
         |left join
         |(
         |	select
         |	station_id,
         |	sum(station_refund) as aggr_fleet_refund
         |	from dm_gis.ddjy_dwd_station_order_repartition_di
         |	where inc_day='$inc_day'
         |	and order_status=2
         |	and discount_model=2 and station_refund_status=0
         |	group by station_id
         |) t7
         |on t1.id=t7.station_id
         |left join
         |(
         |	select station_id,
         |	end_balance as begin_balance,
         |	aggr_fleet_refund
         |	from dm_gis.dm_ddjy_station_account_report_di
         |	where inc_day='$before_yesterday'
         |	and tag='每日'
         |) t8
         |on t1.id=t8.station_id
         |union all
         |select
         |`date`,account_month,corp_id,id,account_prop,
         |begin_balance,
         |station_received_amount,
         |ft_sale_money,
         |need_fleet_refund,
         |yes_fleet_refund,
         |trade_amount,
         |aggr_fleet_refund,
         |round((begin_balance+trade_amount-sum_station_received_amount+sum_yes_fleet_refund),2) as end_balance,
         |tag
         |from
         |(
         |	select
         |	from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |	'' as account_month,
         |	corp_id,a1.id,account_prop,
         |	max(round(nvl(begin_balance,0.00),2)) over(partition by corp_id) as begin_balance,
         |	round(nvl(station_received_amount,0.00),2) as station_received_amount,
         |	round(nvl(ft_sale_money,0.00),2) as ft_sale_money,
         |	round(nvl(need_fleet_refund,0.00),2) as need_fleet_refund,
         |	round(nvl(yes_fleet_refund,0.00),2) as yes_fleet_refund,
         |	round(nvl(trade_amount,0.00),2) as trade_amount,
         |	round(nvl(a7.aggr_fleet_refund,0.00)+nvl(a8.aggr_fleet_refund,0.00),2) as aggr_fleet_refund,
         |	sum(round(nvl(station_received_amount,0.00),2)) over(partition by corp_id) as sum_station_received_amount,
         |	sum(round(nvl(yes_fleet_refund,0.00),2)) over(partition by corp_id) as sum_yes_fleet_refund,
         |	'每日' as tag
         |	from
         |	(
         |		select
         |		id,account_prop,corp_id,station_received_amount,ft_sale_money,need_fleet_refund,yes_fleet_refund
         |		from
         |		(
         |			select id,
         |			account_prop,
         |			corp_id as corp_id
         |			from dm_gis.ddjy_dim_station_info_filter
         |			where inc_day='$inc_day'
         |		) a0
         |		left join
         |		(
         |			select station_id,
         |			sum(station_received_amount) as station_received_amount,
         |			sum(ft_sale_money) as ft_sale_money,
         |			sum(if(discount_model=2 and station_refund_status=0,station_refund,null)) as need_fleet_refund,
         |			sum(if(discount_model=2 and station_refund_status=1,station_refund,null)) as yes_fleet_refund
         |			from dm_gis.ddjy_dwd_station_order_repartition_di
         |			where inc_day='$inc_day'
         |			and order_status=2
         |			group by station_id
         |		) a2
         |		on a0.id=a2.station_id
         |		where account_prop='2'
         |	) a1
         |	left join
         |	(
         |		select
         |		user_id,
         |		sum(trade_amount) as trade_amount
         |		from
         |		(
         |			select
         |			wallet_id,
         |			trade_amount
         |			from dm_gis.ddjy_ods_wallet_history
         |			where inc_day='$inc_day' and inoutcome_type = 2
         |		) a3
         |		left join
         |		(
         |			select id,
         |			user_id
         |			from dm_gis.ddjy_ods_dim_wallet
         |			where inc_day='$inc_day' and user_type =4 and account_type = 4
         |		) a4
         |		on a3.wallet_id=a4.id
         |		group by user_id
         |	) a5
         |	on a1.corp_id=a5.user_id
         |	left join
         |	(
         |		select
         |		station_id,
         |		sum(station_refund) as aggr_fleet_refund
         |		from dm_gis.ddjy_dwd_station_order_repartition_di
         |		where inc_day='$inc_day'
         |		and order_status=2
         |		and discount_model=2 and station_refund_status=0
         |		group by station_id
         |	) a7
         |	on a1.id=a7.station_id
         |	left join
         |	(
         |		select station_id,
         |		end_balance as begin_balance,
         |		aggr_fleet_refund
         |		from dm_gis.dm_ddjy_station_account_report_di
         |		where inc_day='$before_yesterday'
         |		and tag='每日'
         |	) a8
         |	on a1.id=a8.station_id
         |) a9
         |""".stripMargin
    val station_account_df: DataFrame = spark.sql(daySql)
    station_account_df.repartition(1).createOrReplaceTempView("station_account_tmp")
    spark.sql(s"insert overwrite table dm_gis.dm_ddjy_station_account_report_di partition(inc_day='$inc_day') select * from station_account_tmp")
    logger.error("写入dm_ddjy_station_account_report_di每日成功，日期为："+inc_day)
    val monthSql=
      s"""
         |select
         |from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |substr('$inc_day',0,6) as account_month,
         |corp_id,t1.station_id,account_prop,
         |round(nvl(begin_balance,0.00),2) as begin_balance,
         |round(nvl(station_received_amount,0.00),2) as station_received_amount,
         |round(nvl(ft_sale_money,0.00),2) as ft_sale_money,
         |round(nvl(need_fleet_refund,0.00),2) as need_fleet_refund,
         |round(nvl(yes_fleet_refund,0.00),2) as yes_fleet_refund,
         |round(nvl(trade_amount,0.00),2) as trade_amount,
         |round(nvl(aggr_fleet_refund,0.00),2) as aggr_fleet_refund,
         |round((nvl(begin_balance,0.00)+nvl(trade_amount,0.00)-nvl(station_received_amount,0.00)+nvl(yes_fleet_refund,0.00)),2) as end_balance,
         |'每月' as tag
         |from
         |(
         |	select corp_id,
         |	station_id,
         |	account_prop,
         |	sum(station_received_amount) as station_received_amount,
         |	sum(ft_sale_money) as ft_sale_money,
         |	split(max(concat(`date`,'\001',aggr_fleet_refund)),'\001')[1] as aggr_fleet_refund
         |	from dm_gis.dm_ddjy_station_account_report_di
         |	where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','')
         |	and tag='每日'
         |	and account_prop!=2
         |	group by corp_id,station_id,account_prop
         |) t1
         |left join
         |(
         |	select
         |	station_id,need_fleet_refund,yes_fleet_refund
         |	from
         |	(
         |		select
         |		station_id,
         |		sum(if(discount_model=2 and station_refund_status=0,station_refund,null)) as need_fleet_refund,
         |		sum(if(discount_model=2 and station_refund_status=1,station_refund,null)) as yes_fleet_refund
         |		from dm_gis.ddjy_dwd_station_order_repartition_di
         |		where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','')
         |		and order_status=2
         |		group by station_id
         |	) t3
         |	group by station_id,need_fleet_refund,yes_fleet_refund
         |) t4
         |on t1.station_id=t4.station_id
         |left join
         |(
         |	select
         |	station_id,
         |	end_balance as begin_balance
         |	from dm_gis.dm_ddjy_station_account_report_di
         |	where inc_day=replace(date_sub(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),1),'-','')
         |	and tag='每日'
         |) t5
         |on t1.station_id=t5.station_id
         |left join
         |(
         |	select
         |	user_id,
         |	sum(trade_amount) as trade_amount
         |	from
         |	(
         |		select
         |		wallet_id,
         |		trade_amount
         |		from dm_gis.ddjy_ods_wallet_history
         |		where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','') and inoutcome_type = 2
         |	) t6
         |	left join
         |	(
         |		select id,
         |		user_id
         |		from dm_gis.ddjy_ods_dim_wallet
         |		where inc_day='$inc_day' and user_type =4 and account_type = 4
         |	) t7
         |	on t6.wallet_id=t7.id
         |	group by user_id
         |) t8
         |on t1.station_id=t8.user_id
         |union all
         |select
         |`date`,account_month,corp_id,station_id,account_prop,begin_balance,station_received_amount,
         |ft_sale_money,need_fleet_refund,yes_fleet_refund,trade_amount,aggr_fleet_refund,
         |round((nvl(begin_balance,0.00)+nvl(trade_amount,0.00)-nvl(sum_station_received_amount,0.00)+nvl(sum_yes_fleet_refund,0.00)),2) as end_balance,
         |tag
         |from
         |(
         |	select
         |	from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |	substr('$inc_day',0,6) as account_month,
         |	a1.corp_id,a1.station_id,account_prop,
         |	max(round(nvl(begin_balance,0.00),2)) over(partition by a1.corp_id) as begin_balance,
         |	round(nvl(station_received_amount,0.00),2) as station_received_amount,
         |	round(nvl(ft_sale_money,0.00),2) as ft_sale_money,
         |	round(nvl(need_fleet_refund,0.00),2) as need_fleet_refund,
         |	round(nvl(yes_fleet_refund,0.00),2) as yes_fleet_refund,
         |	round(nvl(trade_amount,0.00),2) as trade_amount,
         |	round(nvl(aggr_fleet_refund,0.00),2) as aggr_fleet_refund,
         |	sum(round(nvl(station_received_amount,0.00),2)) over(partition by a1.corp_id) as sum_station_received_amount,
         |	sum(round(nvl(yes_fleet_refund,0.00),2)) over(partition by a1.corp_id) as sum_yes_fleet_refund,
         |	'每月' as tag
         |	from
         |	(
         |		select corp_id,
         |		station_id,
         |		account_prop,
         |		sum(station_received_amount) as station_received_amount,
         |		sum(ft_sale_money) as ft_sale_money,
         |		split(max(concat(`date`,'\001',aggr_fleet_refund)),'\001')[1] as aggr_fleet_refund
         |		from dm_gis.dm_ddjy_station_account_report_di
         |		where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','')
         |		and tag='每日'
         |		and account_prop=2
         |		group by corp_id,station_id,account_prop
         |	) a1
         |	left join
         |	(
         |		select
         |		station_id,need_fleet_refund,yes_fleet_refund
         |		from
         |		(
         |			select
         |			station_id,
         |			sum(if(discount_model=2 and station_refund_status=0,station_refund,null)) over(partition by station_id) as need_fleet_refund,
         |			sum(if(discount_model=2 and station_refund_status=1,station_refund,null)) over(partition by station_id) as yes_fleet_refund
         |			from dm_gis.ddjy_dwd_station_order_repartition_di
         |			where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','')
         |			and order_status=2
         |		) a3
         |		group by station_id,need_fleet_refund,yes_fleet_refund
         |	) a4
         |	on a1.station_id=a4.station_id
         |	left join
         |	(
         |		select
         |		station_id,
         |		end_balance as begin_balance
         |		from dm_gis.dm_ddjy_station_account_report_di
         |		where inc_day=replace(date_sub(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),1),'-','')
         |		and tag='每日'
         |	) a5
         |	on a1.station_id=a5.station_id
         |	left join
         |	(
         |		select
         |		user_id,
         |		sum(trade_amount) as trade_amount
         |		from
         |		(
         |			select
         |			wallet_id,
         |			trade_amount
         |			from dm_gis.ddjy_ods_wallet_history
         |			where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','') and inoutcome_type = 2
         |		) a6
         |		left join
         |		(
         |			select id,
         |			user_id
         |			from dm_gis.ddjy_ods_dim_wallet
         |			where inc_day='$inc_day' and user_type =4 and account_type = 4
         |		) a7
         |		on a6.wallet_id=a7.id
         |		group by user_id
         |	) a8
         |	on a1.corp_id=a8.user_id
         |) a6
         |""".stripMargin
    val station_account_month_df: DataFrame = spark.sql(monthSql)
    station_account_month_df.repartition(1).createOrReplaceTempView("station_account_month_tmp")
    spark.sql(s"insert into table dm_gis.dm_ddjy_station_account_report_di partition(inc_day='$inc_day') select * from station_account_month_tmp")
    logger.error("写入dm_ddjy_station_account_report_di每月成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    var before_yesterday=""
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      before_yesterday = DateUtil.getDateStr(incDay, -1, "")
      stationProcess(spark,incDay,before_yesterday)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>CollectionAccountData Execute Ok")
  }

}
