package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.{countDistinct, explode, split}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkWrite



object StationStreamMaxSevenCnt {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def teamProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String,fri_day:String) = {
    import spark.implicits._
    val o_seven_plat_stream = spark.sql(
      s"""select car_team_id team_id,consume_carplate_aggr
         |from dm_gis.ddjy_dwd_station_stream_detail
         |where inc_day between '$last_seven_day' and '$inc_day'""".stripMargin)
      .withColumn("consume_carplate",explode(split($"consume_carplate_aggr",",")))
      .groupBy("team_id")
      .agg(countDistinct($"consume_carplate") as "vehicle_week_cnt")
    SparkWrite.writeToHive(spark,o_seven_plat_stream,"inc_day",inc_day,"dm_gis.ddjy_dwd_team_vehicle_week_cnt_di",1)
    logger.error("写入ddjy_dwd_team_vehicle_week_cnt_di每日成功，日期为："+inc_day)
  }


  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    for (i <- (0 to 90).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      val sdf = new SimpleDateFormat("yyyyMMdd")
      val actionTime = sdf.parse(incDay)
      val cal_5 = Calendar.getInstance
      cal_5.setTime(actionTime)
      cal_5.add(Calendar.WEEK_OF_MONTH, -1)
      cal_5.set(Calendar.DAY_OF_WEEK, 6)
      val fri_day = sdf.format(cal_5.getTime)
      teamProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day,fri_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    execute(inc_day)
    logger.error("======>>>>>>车队车辆周活表 Execute Ok")
  }

}
