package app


import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.CommonTools.writeToHive

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}
import scala.collection.mutable.{ArrayBuffer, ListBuffer}


/**
 *需求名称：推荐系统产品使用指标数据端v1.0
 *需求方：陶慧(01424177)
 *@author: 周勇(01390943)
 *任务创建时间：20230320
 *任务id：衡度平台680
 **/

object RecProdUsedIndex {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .config("spark.debug.maxToStringFields", 1000)
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._
    //获取T-1日期
    val dayvar: String = args(0)
    //最近7天
    //取T-7日期,
    val dayvar7 = getdaysBeforeOrAfter(dayvar, -6)
    //取T-30日期,
    val dayvar30 = getdaysBeforeOrAfter(dayvar, -29)
    //计算日期、月份
    val statistical_date=dayvar.substring(0,4).concat("-").concat(dayvar.substring(4,6)).concat("-").concat(dayvar.substring(6,8))
    val statistical_mon=dayvar.substring(0,4).concat("-").concat(dayvar.substring(4,6))
    //获取数据源
    val operating_record=spark.sql(
      s"""
         |select * from dm_gis.ddjy_sys_operating_record
         |where inc_day=${dayvar}
         |""".stripMargin)
      .withColumn("is_filter",when($"event_type".isin("32000","34007"),1).when($"vehicle_team_name".like("%测试%"),1)
        .when($"vehicle_team_name".like("%演示%"),1).when($"vehicle_team_name".like("%吨吨%"),1)
        .when($"vehicle_team_name".like("%商务%"),1).otherwise(0))
      .filter($"is_filter"===0)
      //统计日期
      .withColumn("statistical_date",lit(statistical_date))
      //统计月份
      .withColumn("statistical_mon",lit(statistical_mon))
      //数据来源
      .withColumn("source",when($"event_type".like("3%"),"tjpc").when($"event_type".like("1%"),"cgxcx").otherwise(""))
      //步骤
      .withColumn("step",when($"source"==="tjpc" && $"event_type".isin("34015","34005"),"1.1.1")
        .when($"source"==="tjpc","1")
        .when($"source"==="tjpc","1.1")
        .when($"source"==="cgxcx","2")
        .otherwise(""))
      .drop("is_filter")

    //由于pc的1.1目前没有，所以取1的值替代，后期有了之后再修改
    //维度去重
    val operating_ob1=operating_record.groupBy("inc_day","statistical_date","statistical_mon","source","step")
      .agg(count($"inc_day") as "all_ct")

//    println("aaa:")
//    operating_ob1.show()
//    println("aaa:")
    //取1的值替代pc的1.1
    val operating_ob2=operating_ob1.filter($"source"==="tjpc" && $"step"==="1")
      .withColumn("step",lit("1.1"))

    //维度数据合并
    val operating_ob=operating_ob1.union(operating_ob2)

    //计算指标：每日车队总数
    val team_info=spark.sql(
      s"""
         |select * from dm_gis.ddjy_dim_team_info_filter
         |where inc_day=${dayvar}
         |""".stripMargin)
      .withColumn("is_filter",when($"del_flag"==="1",1).otherwise(0))
      .filter($"is_filter"===0)
      .drop("is_filter")
      .groupBy("inc_day")
      .agg(countDistinct($"id") as "team_cnt_daily" )

//    println("aaa2:")
//    team_info.show()
//    println("aaa2:")
    //每日登录次数
    val log_ct_pc1=operating_record.filter($"event_type"==="30001").
      groupBy("inc_day","statistical_date","statistical_mon","source","step")
      .agg(count($"inc_day") as "login_cnt_daily")

    val log_ct_pc11=log_ct_pc1.
      withColumn("step",lit("1.1"))

    val log_ct_pc111=operating_record.filter($"event_type"==="34005").
      groupBy("inc_day","statistical_date","statistical_mon","source","step")
      .agg(count($"inc_day") as "login_cnt_daily")

    val log_ct_xcx1=operating_record.filter($"event_type"==="10030").
      groupBy("inc_day","statistical_date","statistical_mon","source","step")
      .agg(count($"inc_day") as "login_cnt_daily")

    val log_ct=log_ct_pc1.union(log_ct_pc11).union(log_ct_pc111).union(log_ct_xcx1)

//    println("aaa3:")
//    log_ct.show()
//    println("aaa3:")
    //计算有效使用
    //将数据清洗，去掉中间无效数据行，用;合并---source是tjpc（步骤1、1.1）的计算逻辑
    val operating_1=operating_record.filter($"operate_time".isNotNull && trim($"operate_time") =!="" && $"event_type".isNotNull && trim($"event_type") =!="")
      .select("vehicle_team_id","event_type","operate_time")
      .withColumn("event_type",when($"event_type"==="30001","30001").otherwise("99999"))
      .withColumn("rank",row_number().over(Window.partitionBy("vehicle_team_id").orderBy(asc("operate_time")) ))

    val operating_2=operating_1.withColumn("rank1",$"rank"+1)
      .withColumn("event_type2",$"event_type")

    val operating_2a = operating_1.withColumn("rank2", $"rank" -1)
      .withColumn("event_type3", $"event_type")
      .drop("rank")

    val operating_3 = operating_1.as("a").join(operating_2.as("b"), $"a.vehicle_team_id" === $"b.vehicle_team_id" &&
      $"a.rank" === $"b.rank1", "left")
      .join(operating_2a.as("c"), $"a.vehicle_team_id" === $"c.vehicle_team_id" &&
        $"a.rank" === $"c.rank2", "left")
      .select($"a.vehicle_team_id", $"a.event_type", $"a.operate_time", $"b.event_type2", $"c.event_type3")
      .withColumn("flag", when($"event_type" === $"event_type2", 1).otherwise(2))
      .withColumn("if_filter", when($"event_type" === "30001" && ($"event_type2".isNull || $"event_type2"==="99999") , 1)
        .when($"event_type" === "99999" && ($"event_type3".isNull || $"event_type3"==="30001"), 1)
        .otherwise(0))
      .filter($"if_filter" === 1)

    val operating_hebing_pc1=operating_3
      .groupBy("vehicle_team_id")
      .agg(concat_ws(";",sort_array(collect_list(concat($"operate_time",lit("_"),$"event_type")),asc=true) ) as "hebing")
      .withColumn("use_cnt",is_active_udf($"hebing",lit("30001")))
      .withColumn("source",lit("tjpc"))
      .withColumn("step",lit("1"))

    val operating_hebing_pc11=operating_hebing_pc1
      .withColumn("source",lit("tjpc"))
      .withColumn("step",lit("1.1"))



    //将数据清洗，去掉中间无效数据行，用;合并---source是tjpc（步骤1.1.1）的计算逻辑
    val operating_1x=operating_record.filter($"operate_time".isNotNull && trim($"operate_time") =!="" && $"event_type".isNotNull && trim($"event_type") =!="")
      .select("vehicle_team_id","event_type","operate_time")
      .withColumn("event_type",when($"event_type"==="34015","34015").otherwise("99999"))
      .withColumn("rank",row_number().over(Window.partitionBy("vehicle_team_id").orderBy(asc("operate_time")) ))

    val operating_2x=operating_1x.withColumn("rank1",$"rank"+1)
      .withColumn("event_type2",$"event_type")

    val operating_2ax = operating_1x.withColumn("rank2", $"rank" -1)
      .withColumn("event_type3", $"event_type")
      .drop("rank")

    val operating_3x = operating_1x.as("a").join(operating_2x.as("b"), $"a.vehicle_team_id" === $"b.vehicle_team_id" &&
      $"a.rank" === $"b.rank1", "left")
      .join(operating_2ax.as("c"), $"a.vehicle_team_id" === $"c.vehicle_team_id" &&
        $"a.rank" === $"c.rank2", "left")
      .select($"a.vehicle_team_id", $"a.event_type", $"a.operate_time", $"b.event_type2", $"c.event_type3")
      .withColumn("flag", when($"event_type" === $"event_type2", 1).otherwise(2))
      .withColumn("if_filter", when($"event_type" === "34015" && ($"event_type2".isNull || $"event_type2"==="99999") , 1)
        .when($"event_type" === "99999" && ($"event_type3".isNull || $"event_type3"==="34015"), 1)
        .otherwise(0))
      .filter($"if_filter" === 1)

    val operating_hebing_pc111=operating_3x
      .groupBy("vehicle_team_id")
      .agg(concat_ws(";",sort_array(collect_list(concat($"operate_time",lit("_"),$"event_type")),asc=true) ) as "hebing")
      .withColumn("use_cnt",is_active_udf($"hebing",lit("34015")))
      .withColumn("source",lit("tjpc"))
      .withColumn("step",lit("1.1.1"))

    //将数据清洗，去掉中间无效数据行，用;合并---Source是xcx的计算逻辑
    val operating_1y=operating_record.filter($"operate_time".isNotNull && trim($"operate_time") =!="" && $"event_type".isNotNull && trim($"event_type") =!="")
      .select("vehicle_team_id","event_type","operate_time")
      .withColumn("event_type",when($"event_type"==="10030","10030").otherwise("99999"))
      .withColumn("rank",row_number().over(Window.partitionBy("vehicle_team_id").orderBy(asc("operate_time")) ))

    val operating_2y=operating_1y.withColumn("rank1",$"rank"+1)
      .withColumn("event_type2",$"event_type")

    val operating_2ay = operating_1y.withColumn("rank2", $"rank" -1)
      .withColumn("event_type3", $"event_type")
      .drop("rank")

    val operating_3y = operating_1y.as("a").join(operating_2y.as("b"), $"a.vehicle_team_id" === $"b.vehicle_team_id" &&
      $"a.rank" === $"b.rank1", "left")
      .join(operating_2ay.as("c"), $"a.vehicle_team_id" === $"c.vehicle_team_id" &&
        $"a.rank" === $"c.rank2", "left")
      .select($"a.vehicle_team_id", $"a.event_type", $"a.operate_time", $"b.event_type2", $"c.event_type3")
      .withColumn("flag", when($"event_type" === $"event_type2", 1).otherwise(2))
      .withColumn("if_filter", when($"event_type" === "10030" && ($"event_type2".isNull || $"event_type2"==="99999") , 1)
        .when($"event_type" === "99999" && ($"event_type3".isNull || $"event_type3"==="10030"), 1)
        .otherwise(0))
      .filter($"if_filter" === 1)

    val operating_hebing_xcx1=operating_3y
      .groupBy("vehicle_team_id")
      .agg(concat_ws(";",sort_array(collect_list(concat($"operate_time",lit("_"),$"event_type")),asc=true) ) as "hebing")
      .withColumn("use_cnt",is_active_udf($"hebing",lit("10030")))
      .withColumn("source",lit("cgxcx"))
      .withColumn("step",lit("2"))
    //活跃车队以及次数合并
    val active_hebing=operating_hebing_pc1.union(operating_hebing_pc11).union(operating_hebing_pc111).union(operating_hebing_xcx1)

    val active_res=active_hebing.filter($"use_cnt">0)
      .groupBy("source","step")
      .agg(sum($"use_cnt") as "valid_use_cnt_daily")

//    println("aaa4:")
//    active_res.show()
//    println("aaa4:")
    //每日活跃车队
    val active_team=active_hebing.filter($"use_cnt">0)
      .groupBy("source","step")
      .agg(concat_ws(";",collect_set($"vehicle_team_id")) as "active_team_daily",
        countDistinct($"vehicle_team_id") as "active_team_cnt_daily")

//    println("aaa5:")
//    active_team.show()
//    println("aaa5:")
    //结果合并
    val static_result=operating_ob.join(team_info,Seq("inc_day"),"left")
      .join(log_ct,Seq("inc_day","statistical_date","statistical_mon","source","step"),"left")
      .join(active_res,Seq("source","step"),"left")
      .join(active_team,Seq("source","step"),"left")
      .withColumn("use_rate_daily",round($"valid_use_cnt_daily"/$"login_cnt_daily",6))

    //用于计算7和30天数据
    val static_result_temp=static_result.select("inc_day","source","step","active_team_daily")

    //近7日活跃车队数
    val recent7=spark.sql(
      s"""
         |select inc_day,source,step,active_team_daily from dm_gis.ddjy_recprod_usedindex_df
         |where inc_day>='${dayvar7}' and inc_day<'${dayvar}'
         |""".stripMargin)

    val recent7_hb=static_result_temp.union(recent7)
      .groupBy("source","step")
      .agg(concat_ws(";",collect_list($"active_team_daily")) as "active_team_daily_new")
      .withColumn("active_team_detail",explode(split($"active_team_daily_new",";")))
      .groupBy("source","step")
      .agg(countDistinct($"active_team_detail") as "active_team_cnt_weekly")
      .withColumnRenamed("source","source7")
      .withColumnRenamed("step","step7")
//    println("aaa6:")
//    recent7_hb.show()
//    println("aaa6:")
    //近30日活跃车队数
    val recent30=spark.sql(
      s"""
         |select inc_day,source,step,active_team_daily from dm_gis.ddjy_recprod_usedindex_df
         |where inc_day>='${dayvar30}' and inc_day<'${dayvar}'
         |""".stripMargin)

    val recent30_hb= static_result_temp.union(recent30)
      .groupBy("source","step")
      .agg(concat_ws(";",collect_list($"active_team_daily")) as "active_team_daily_new")
      .withColumn("active_team_detail",explode(split($"active_team_daily_new",";")))
      .groupBy("source","step")
      .agg(countDistinct($"active_team_detail") as "active_team_cnt_monthly")
      .withColumnRenamed("source","source30")
      .withColumnRenamed("step","step30")

//    println("aaa7:")
//    recent30_hb.show()
//    println("aaa7:")
    //近7日留存率分母
    val recent7_liucun_fm=spark.sql(
      s"""
         |select inc_day,source,step,active_team_daily from dm_gis.ddjy_recprod_usedindex_df
         |where inc_day='${dayvar7}'
         |""".stripMargin)
      .withColumn("active_team_detail",explode(split($"active_team_daily",";")))
      .distinct()

    //近7日留存率分子
    val recent7_liucun_fz=recent7.union(static_result_temp)
      .filter($"inc_day">=dayvar7)
      .groupBy("source","step")
      .agg(concat_ws(";",collect_list($"active_team_daily")) as "active_team_daily_new")
      .withColumn("active_team_detail",explode(split($"active_team_daily_new",";")))
      .withColumn("active_team_detail_x",$"active_team_detail")
      .select("active_team_detail","active_team_detail_x")
      .distinct()

    val liucun=recent7_liucun_fm.join(recent7_liucun_fz,Seq("active_team_detail"),"left")
      .groupBy("source","step")
      .agg(
        countDistinct($"active_team_detail") as "all_ct",
        countDistinct($"active_team_detail_x") as "x_ct"
      )
      .withColumn("day_retention_rate_7",round($"x_ct"/$"all_ct",6))
      .drop("all_ct","x_ct")

//    println("aaa8:")
//    liucun.show()
//    println("aaa8:")

    val table_cols = spark.sql("""select * from dm_gis.ddjy_recprod_usedindex_df limit 0""").schema.map(_.name).map(col)
    val static_result2=static_result.as("t1").join(recent7_hb.as("t2"),
      $"t1.source" === $"t2.source7" && $"t1.step" === $"t2.step7","left")
      .join(recent30_hb.as("t3"),$"t1.source" === $"t3.source30" && $"t1.step" === $"t3.step30","left")
      .join(liucun.as("t4"),$"t1.source" === $"t4.source" && $"t1.step" === $"t4.step","left")
      .withColumn("active_team_rate_weekly",round($"active_team_cnt_weekly" / $"team_cnt_daily",6))
      .withColumn("active_team_rate_monthly",round($"active_team_cnt_monthly" / $"team_cnt_daily",6))
      .drop($"t4.source")
      .drop($"t4.step")
      .na.fill(0,Seq("team_cnt_daily","login_cnt_daily","valid_use_cnt_daily","active_team_cnt_daily","active_team_cnt_weekly","active_team_cnt_monthly"))
      .select(table_cols: _*)

    //数据存dm表
    writeToHive(spark, static_result2.coalesce(1), Seq("inc_day"), "dm_gis.ddjy_recprod_usedindex_df")

  }


  //定义时间差计算：秒，str2比str1大,传入格式：2022-09-30 15:30:18，例如返回结果：300
  def TimeDiffSecond(str1: String, str2: String): Long = {
    var datedf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    //转换时间戳：毫秒
    val x1 = datedf.parse(str1).getTime
    val x2 = datedf.parse(str2).getTime
    //除以1000就是秒为单位
    val x3 = (x2 - x1) / 1000
    return x3
  }

  //判断活跃使用,input_event_type是根据具体情况输入
  def is_active(x: String, input_event_type: String): Int = {
    val x_arr = x.split(";")
    val l = x_arr.length
    val time_List: ListBuffer[ArrayBuffer[String]] = new ListBuffer[ArrayBuffer[String]]
    val ct_List: ListBuffer[Long] = new ListBuffer[Long]
    //假如是一个时间
    if (l < 2) {
      return 0
    }
    else {
      for (i <- 0 until l - 1) {
        val y_arr_0 = x_arr(i).split("_")(0)
        val y_arr_1 = x_arr(i).split("_")(1)
        val period_arr = new ArrayBuffer[String]
        if (y_arr_1 == input_event_type) {
          period_arr.append(y_arr_0)
        }
        //往后判断一位
        val z_arr_0 = x_arr(i + 1).split("_")(0)
        val z_arr_1 = x_arr(i + 1).split("_")(1)
        if (z_arr_1 != input_event_type) {
          period_arr.append(z_arr_0)
        }
        //拼接list
        time_List.append(period_arr)
      }

      for (s <- time_List) {
        val s_len = s.length
        println("s:"+s)
        if (s_len == 2) {
          val x1 = s(0)
          val x2 = s(1)
          val timedif = TimeDiffSecond(x1, x2)
          if (timedif > 10) {
            ct_List.append(timedif)
          }
        }
      }

      return ct_List.length
    }
  }
  val is_active_udf=udf(is_active _)
  //往前推n天
  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }
}