package app

import java.text.SimpleDateFormat
import java.util.Calendar

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.SparkWrite

/**
 * @Description:车队消费趋势报表
 * @Author: lixiangzhi 01405644 迭代修改：周勇 01390943
 * @Date: 11:05 2022/11/29
 * 任务id:417
 * 任务名称：吨吨加油平台流水明细
 * 依赖任务：每日-车队历史充值记录表 498、每日-原始油站信息过滤表 512、每日-原始车队信息过滤表 501、订单支付时间重分区表 387
 * 数据源：ddjy_dim_team_info_filter、ddjy_dwd_station_order_pay_repartition_di、ddjy_dim_station_info_filter、ddjy_dwd_station_stream_detail、ddjy_dwd_car_team_history_recharge
 * 调用服务地址：无
 * 数据结果：ddjy_dwd_station_stream_detail
 */

object CollectionOrderPay {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def teamProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_two_month:String,fri_day:String) = {
    //生成 ddjy_dim_station_info_on_shelf_time_df
    val on_shelf_time_sql=
      s"""
        |select
        |t2.id,order_sn,code_id,petrol_card_id,petrol_card_sn,station_oper_id,carplate,station_oper_name,driver_phone,station_name,station_id,update_by,driver_id,driver_name,distribute_oil_type,petrol_type,petrol_type_name,oil_mass,official_price,station_price,ft_sale_price,ft_cost_price,ft_sale_money,ft_cost_money,discount_price,offical_pay_money,station_pay_money,discount_pay_money,corp_id,car_team_id,car_team_name,order_status,pay_time,approval_status,approval_time,approval_by,remit_status,remit_id,del_flag,create_date,create_by,update_date,discount_model,fleet_refund,station_refund,ft_profit,fleet_refund_status,station_refund_status,transaction_amount,wallet_id,station_received_amount,remark,settle_model,discard_time,limit_type,order_source,petrol_resources,pay_type,deduction_type,is_wx_send,stan,shell_pay_result,verification_status,shell_discount,shell_qrcode,business_time,lock_status,driver_type,bdp_time,coupon_id,coupon_free_money,oil_no,gun_no,third_order_sn,order_type,source,station_type,grpid,
        |longitude,latitude,station_type_original,invoice_company_id,invoice_company_name,capital_model,service_charge,petrol_type_code,main_corp_info_id,main_corp_info_name,three_station_pay_money,team_discount_model,is_full_oil,ocr_carplate,audit_result,team_audit_date,
        |new_carplate,
        |inc_day
        |from
        |(
        |	select
        |	id,order_sn,code_id,petrol_card_id,petrol_card_sn,station_oper_id,carplate,station_oper_name,driver_phone,station_name,station_id,update_by,driver_id,driver_name,distribute_oil_type,petrol_type,petrol_type_name,oil_mass,official_price,station_price,ft_sale_price,ft_cost_price,ft_sale_money,ft_cost_money,discount_price,offical_pay_money,station_pay_money,discount_pay_money,corp_id,car_team_id,car_team_name,order_status,pay_time,approval_status,approval_time,approval_by,remit_status,remit_id,del_flag,create_date,create_by,update_date,discount_model,fleet_refund,station_refund,ft_profit,fleet_refund_status,station_refund_status,transaction_amount,wallet_id,station_received_amount,remark,settle_model,discard_time,limit_type,order_source,petrol_resources,pay_type,deduction_type,is_wx_send,stan,shell_pay_result,verification_status,shell_discount,shell_qrcode,business_time,lock_status,driver_type,bdp_time,coupon_id,coupon_free_money,oil_no,gun_no,third_order_sn,order_type,source,longitude,latitude,
        |	station_type as station_type_original,
        |	invoice_company_id,invoice_company_name,capital_model,service_charge,petrol_type_code,main_corp_info_id,main_corp_info_name,three_station_pay_money,team_discount_model,is_full_oil,ocr_carplate,audit_result,team_audit_date,
        |	new_carplate,
        |  replace(substr(pay_time,0,10),'-','') as inc_day
        |	from
        |	(
        |		select
        |		*,
        |		row_number() over(partition by order_sn order by update_date desc) as rnk
        |		from dm_gis.ddjy_dwd_station_order_filter
        |		where inc_day>='${last_two_month}' and inc_day<='${inc_day}'
        |		and replace(substr(pay_time,0,10),'-','')>='${last_two_month}' and replace(substr(pay_time,0,10),'-','')<='${inc_day}'
        |	) t1
        |	where rnk=1 and order_status='2' and pay_time!='' and pay_time is not null
        |) t2
        |left join
        |(
        |	select id,station_type,grpid
        |	from dm_gis.ddjy_dim_station_info_filter
        |	where inc_day='${inc_day}'
        |) t3
        |on t2.station_id=t3.id
        |""".stripMargin
    val on_shelf_time_df: DataFrame = spark.sql(on_shelf_time_sql)
    logger.error("ddjy_dwd_station_order_pay_repartition_di 表数据量:"+on_shelf_time_df.count())
    SparkWrite.writeToHiveDynamic(spark,on_shelf_time_df,"inc_day","dm_gis.ddjy_dwd_station_order_pay_repartition_di",1)
    logger.error("写入 ddjy_dwd_station_order_pay_repartition_di 每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String,dates:Int) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    for (i <- (0 to dates).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_sixty_day: String = DateUtil.getDateStr(incDay, -60, "")
      val sdf = new SimpleDateFormat("yyyyMMdd")
      val actionTime = sdf.parse(incDay)
      val cal_5 = Calendar.getInstance
      cal_5.setTime(actionTime)
      cal_5.add(Calendar.WEEK_OF_MONTH, -1)
      cal_5.set(Calendar.DAY_OF_WEEK, 6)
      val fri_day = sdf.format(cal_5.getTime)
      teamProcess(spark,incDay,before_yesterday,last_seven_day,last_sixty_day,fri_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val dates: Int = args(1).toInt
    execute(inc_day,dates)
    logger.error("======>>>>>>油站上线时间表 Execute Ok")
  }

}
