package app

import java.io.{FileWriter, IOException}
import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import utils.TrackUrlUtil

import scala.collection.JavaConversions._
import scala.collection.mutable.Seq
/**
 * Description:调客户群详情接口
 * 需求方：ft220534 陈治仁
 * Author: 李相志 01405644
 * Date: 10:53 2023/3/13
 * 任务信息：运维刘任部署
 */
object WeComCustomerBaseDetails {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def customerBaseListInterface(cursor:String,finalUrl:String,proxyHost:String,proxyPort:Int) = {
    val json = new JSONObject()
    val userid_list = new util.ArrayList[String]()
    userid_list.add("LiuBo")
    userid_list.add("CaiYingWei")
    json.put("userid_list",userid_list)
    json.put("cursor",cursor)
    json.put("limit",100)
    //println(json)
    val chat_id_list = new JSONArray()
    val retStr: String = TrackUrlUtil.sendPostWithProxies(finalUrl,json.toJSONString,proxyHost,proxyPort)
    //val retStr: String = TrackUrlUtil.sendPost(finalUrl,json.toJSONString,3)
    val ret: JSONObject = JSON.parseObject(retStr)
    //logger.error(ret)
    val group_chat_list: JSONArray = JSONUtil.getJsonArrayMulti(ret, "group_chat_list")
    val next_cursor: String = ret.getString("next_cursor")
    val tmpObj = new JSONObject()
    for (i <- 0 until(group_chat_list.size())){
      val interObj = new JSONObject()
      val group_chat_list_obj: JSONObject = group_chat_list.getJSONObject(i)
      val chat_id: String = group_chat_list_obj.getString("chat_id")
      val status: String = group_chat_list_obj.getString("status")
      interObj.put("chat_id",chat_id)
      interObj.put("status",status)
      chat_id_list.append(interObj)
    }
    tmpObj.put("next_cursor",next_cursor)
    tmpObj.put("chat_id_list",chat_id_list)
    tmpObj
  }
  def customerBaseDetailInterface(chat_id:String,customer_base_detail_url:String,status:String,proxyHost:String,proxyPort:Int) = {
    val json = new JSONObject()
    json.put("chat_id",chat_id)
    json.put("need_name",1)
    //println(json)
    val retStr: String = TrackUrlUtil.sendPostWithProxies(customer_base_detail_url,json.toJSONString,proxyHost,proxyPort)
    val ret: JSONObject = JSON.parseObject(retStr)
    ret.put("status",status)
    ret.put("chat_id",chat_id)
    ret
  }

  def main(args: Array[String]): Unit = {
    val proxyHost="sfproxy.int.sfcloud.local"
    val proxyPort:Int=80
    //获取access_token
    val tokenUrl="https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=ww389059b0120e6648&corpsecret=ChyQ5bDDdFAyg77fPAgwqWHeTC139H5Px79ZCDDT3s0"
    var access_token = ""
    try {
      val retTokenStr: String = TrackUrlUtil.sendGetWithProxies(tokenUrl,"utf-8",proxyHost,proxyPort)
      val retToken: JSONObject = JSON.parseObject(retTokenStr)
      access_token = retToken.getString("access_token")
      println(retToken)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调token接口异常:"+e.getMessage)
    }
    val url="https://qyapi.weixin.qq.com/cgi-bin/externalcontact/groupchat/list?access_token=%s"
    val finalUrl: String = url.format(access_token)
    //调客户群列表接口
      //初始化
    val chat_id_array: util.ArrayList[JSONObject] = new util.ArrayList[JSONObject]()
    var cursor = ""
    val tmpObj: JSONObject = customerBaseListInterface(cursor, finalUrl,proxyHost,proxyPort)
    cursor = tmpObj.getString("next_cursor")
    var chat_id_list = tmpObj.getJSONArray("chat_id_list")
    for (i <- 0 until(chat_id_list.size())){
      val chat_id_list_obj: JSONObject = chat_id_list.getJSONObject(i)
      chat_id_array.append(chat_id_list_obj)
    }
    logger.error("chat_id_list:"+chat_id_list.size())
      //分页查询
    while (chat_id_list.size()!=0 && chat_id_list.size()%100==0){
      val interObj: JSONObject = customerBaseListInterface(cursor, finalUrl,proxyHost,proxyPort)
      cursor = interObj.getString("next_cursor")
      val chat_id_list_inter: JSONArray = interObj.getJSONArray("chat_id_list")
      for (i <- 0 until(chat_id_list_inter.size())){
        val chat_id_list_inter_obj: JSONObject = chat_id_list_inter.getJSONObject(i)
        chat_id_array.append(chat_id_list_inter_obj)
      }
      chat_id_list = chat_id_list_inter
    }
    //调客户群详情接口
    var customer_base_detail_url="https://qyapi.weixin.qq.com/cgi-bin/externalcontact/groupchat/get?access_token=%s"
    customer_base_detail_url = customer_base_detail_url.format(access_token)
    val customerBaseDetailList = new util.ArrayList[String]()
    logger.error("chat_id_list:"+chat_id_array.size())
    for (i <- 0 until(chat_id_array.size())){
      if (i%1000==0){
        println(i)
      }
      val chat_id_list_obj: JSONObject = chat_id_array(i)
      val chat_id: String = chat_id_list_obj.getString("chat_id")
      val status: String = chat_id_list_obj.getString("status")
      val customerBaseDetailObj: JSONObject = customerBaseDetailInterface(chat_id, customer_base_detail_url, status,proxyHost,proxyPort)
      customerBaseDetailList.append(customerBaseDetailObj.toJSONString)
    }
    logger.error("customerBaseDetailList的size:"+customerBaseDetailList.size())
    // 指定输出文件路径及名称
    val filePath = "/app/tools/weComCustomerInterface/CUSTOMER_BASE/1.csv_file/WeComCustomerBaseDetails.csv"
    //val filePath = "D:\\WeComCustomerBaseDetails.csv"
    try {
      val writer = new FileWriter(filePath)

      for (elem <- customerBaseDetailList) {
        writer.write(elem + "\n") // 每行写入一个元素并换行
      }

      writer.close() // 关闭文件写入流
    } catch {
      case e: IOException => println("写入文件时发生错误：" + e.getMessage())
    }

  }
}
