package app

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * @Description:车队账单报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:316
 * 任务名称：车队账单报表
 * 依赖任务：每日-原始钱包信息表mysql导入hive 499、每日-原始钱包历史交易明细表mysql导入hive 500、每日-原始车队信息过滤表 501、每日-车队历史充值记录表 498、吨吨加油-订单过滤明细表去重 352
 * 数据源：ddjy_ods_wallet_history、ddjy_ods_dim_wallet、ddjy_dim_team_info_filter、ddjy_dwd_station_order_repartition_di、ddjy_dwd_car_team_history_recharge、dm_ddjy_team_account_report_di
 * 调用服务地址：无
 * 数据结果：dm_ddjy_team_account_report_di
 */
object CollectionTeamAccountData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def teamprocess(spark: SparkSession, inc_day: String, before_yesterday: String): Unit = {
    val yes_fleet_refund_sql=
      s"""
        |select
        |user_id,
        |nvl(sum(yes_fleet_refund),0.00) as yes_fleet_refund
        |from
        |(
        |	select
        |	wallet_id,
        |	sum(trade_amount) as yes_fleet_refund
        |	from dm_gis.ddjy_ods_wallet_history
        |	where inc_day='${inc_day}' and account_type=5 and trade_type=11
        |  group by wallet_id
        |) a1
        |left join
        |(
        |	select
        |	id,
        |	user_id
        |	from dm_gis.ddjy_ods_dim_wallet
        |	where inc_day='${inc_day}' and user_type =2 and account_type = 5
        |) a2
        |on a1.wallet_id=a2.id
        |group by user_id
        |""".stripMargin
    val yes_fleet_refund_df: DataFrame = spark.sql(yes_fleet_refund_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    yes_fleet_refund_df.createOrReplaceTempView("yes_fleet_refund_tmp")
    val agg_yes_fleet_refund_sql=
      s"""
        |select
        |user_id,
        |nvl(sum(yes_fleet_refund),0.00) as agg_yes_fleet_refund
        |from
        |(
        |	select
        |	wallet_id,
        |	sum(trade_amount) as yes_fleet_refund
        |	from dm_gis.ddjy_ods_wallet_history
        |	where inc_day<='${inc_day}' and account_type=5 and trade_type=11
        |	group by wallet_id
        |) a1
        |left join
        |(
        |	select
        |	id,
        |	user_id
        |	from dm_gis.ddjy_ods_dim_wallet
        |	where inc_day='${inc_day}' and user_type =2 and account_type = 5
        |) a2
        |on a1.wallet_id=a2.id
        |group by user_id
        |""".stripMargin
    val agg_yes_fleet_refund_df: DataFrame = spark.sql(agg_yes_fleet_refund_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    agg_yes_fleet_refund_df.createOrReplaceTempView("agg_yes_fleet_refund_tmp")
    //计算end_balance
    val end_balance_greater_sql=
      s"""
        |select
        |team_id,end_balance
        |from
        |(
        |	select
        |	user_id as team_id,
        |	total_amount as end_balance,
        |	row_number() over(partition by user_id order by source desc) as rnk
        |	from dm_gis.ddjy_ods_dim_wallet
        |	where inc_day='${inc_day}'
        |	and user_type='2'
        |	and account_type ='10'
        |) t1
        |where rnk=1
        |""".stripMargin
    val end_balance_df:DataFrame=spark.sql(end_balance_greater_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    end_balance_df.createOrReplaceTempView("end_balance_Tmp")
    val daySql=
      s"""
         |select
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |'' as account_month,
         |crop_name,t1.id,account_prop,
         |nvl(t12.end_balance,0.00) as begin_balance,
         |round(nvl(t2.transaction_amount,0.00),2) as transaction_amount,
         |round(nvl(t2.ft_sale_money,0.00),2) as ft_sale_money,
         |round(nvl(t2.need_fleet_refund,0.00),2) as need_fleet_refund,
         |round(nvl(t9.yes_fleet_refund,0.00),2) as yes_fleet_refund,
         |round(nvl(t3.trade_amount,0.00),2) as trade_amount,
         |round(nvl(t5.aggr_fleet_refund,0.00)-nvl(t10.agg_yes_fleet_refund,0.00),2) as aggr_fleet_refund,
         |round(nvl(t11.end_balance,0.00),2) as end_balance,
         |'每日' as tag
         |from
         |(
         |	select id,
         |	crop_name,
         |	account_prop
         |	from dm_gis.ddjy_dim_team_info_filter
         |	where inc_day='${inc_day}'
         |) t1
         |left join
         |(
         |	select car_team_id,
         |	sum(transaction_amount) as transaction_amount,
         |	sum(ft_sale_money) as ft_sale_money,
         |	sum(if(discount_model=2,fleet_refund,null)) as need_fleet_refund
         |	from dm_gis.ddjy_dwd_station_order_repartition_di
         |	where inc_day='${inc_day}'
         |	and order_status=2
         |	group by car_team_id
         |) t2
         |on t1.id=t2.car_team_id
         |left join
         |(
         |	select
         |	team_id,
         |	sum(trade_amount) as trade_amount
         |	from dm_gis.ddjy_dwd_car_team_history_recharge
         |	where inc_day='${inc_day}'
         |	group by team_id
         |) t3
         |on t1.id=t3.team_id
         |left join
         |(
         |	select
         |	car_team_id,
         |	sum(if(discount_model=2,fleet_refund,null)) as aggr_fleet_refund
         |	from dm_gis.ddjy_dwd_station_order_repartition_di
         |	where inc_day<='${inc_day}'
         |	and order_status=2
         |	group by car_team_id
         |) t5
         |on t1.id=t5.car_team_id
         |left join yes_fleet_refund_tmp t9
         |on t1.id=t9.user_id
         |left join agg_yes_fleet_refund_tmp t10
         |on t1.id=t10.user_id
         |left join
         |(
         |	select team_id,end_balance
         |	from end_balance_Tmp
         |) t11
         |on t1.id=t11.team_id
         |left join
         |(
         |	select team_id,end_balance
         |	from dm_gis.dm_ddjy_team_account_report_di
         |	where inc_day='$before_yesterday'
         |	and tag='每日'
         |) t12
         |on t1.id=t12.team_id
         |""".stripMargin
    val teamAccountDf: DataFrame = spark.sql(daySql)
    teamAccountDf.repartition(1).createOrReplaceTempView("teamAccountTmp")
    spark.sql(s"insert overwrite table dm_gis.dm_ddjy_team_account_report_di partition(inc_day='${inc_day}') select * from teamAccountTmp")
    logger.error("写入dm_ddjy_team_account_report_di每日成功，日期为："+inc_day)
    val month_yes_fleet_refund_sql=
      s"""
        |select
        |user_id,
        |nvl(sum(yes_fleet_refund),0.00) as yes_fleet_refund
        |from
        |(
        |	select
        |	wallet_id,
        |	sum(trade_amount) as yes_fleet_refund
        |	from dm_gis.ddjy_ods_wallet_history
        |	where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','')
        |	and account_type=5 and trade_type=11
        |  group by wallet_id
        |) a1
        |left join
        |(
        |	select
        |	id,
        |	user_id
        |	from dm_gis.ddjy_ods_dim_wallet
        |	where inc_day='${inc_day}' and user_type =2 and account_type = 5
        |) a2
        |on a1.wallet_id=a2.id
        |group by user_id
        |""".stripMargin
    val month_yes_fleet_refund_df: DataFrame = spark.sql(month_yes_fleet_refund_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    month_yes_fleet_refund_df.createOrReplaceTempView("month_yes_fleet_refund_tmp")
    val monthSql=
      s"""
         |
         |select
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |substr('$inc_day',0,6) as account_month,
         |crop_name,t1.id,account_prop,
         |nvl(begin_balance,0.00) as begin_balance,
         |round(nvl(t2.transaction_amount,0.00),2) as transaction_amount,
         |round(nvl(t2.ft_sale_money,0.00),2) as ft_sale_money,
         |round(nvl(t2.need_fleet_refund,0.00),2) as need_fleet_refund,
         |round(nvl(t9.yes_fleet_refund,0.00),2) as yes_fleet_refund,
         |round(nvl(t3.trade_amount,0.00),2) as trade_amount,
         |round(nvl(t5.aggr_fleet_refund,0.00)-nvl(t10.agg_yes_fleet_refund,0.00),2) as aggr_fleet_refund,
         |round(nvl(end_balance,0.00),2) as end_balance,
         |'每月' as tag
         |from
         |(
         |	select id,
         |	crop_name,
         |	account_prop
         |	from dm_gis.ddjy_dim_team_info_filter
         |	where inc_day='${inc_day}'
         |) t1
         |left join
         |(
         |	select car_team_id,
         |	sum(transaction_amount) as transaction_amount,
         |	sum(ft_sale_money) as ft_sale_money,
         |	sum(if(discount_model=2,fleet_refund,null)) as need_fleet_refund
         |	from dm_gis.ddjy_dwd_station_order_repartition_di
         |	where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','')
         |	and order_status=2
         |	group by car_team_id
         |) t2
         |on t1.id=t2.car_team_id
         |left join
         |(
         |	select
         |	team_id,
         |	sum(trade_amount) as trade_amount
         |	from dm_gis.ddjy_dwd_car_team_history_recharge
         |	where inc_day<='$inc_day' and inc_day>=replace(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),'-','')
         |	group by team_id
         |) t3
         |on t1.id=t3.team_id
         |left join
         |(
         |	select
         |	car_team_id,
         |	sum(if(discount_model=2,fleet_refund,null)) as aggr_fleet_refund
         |	from dm_gis.ddjy_dwd_station_order_repartition_di
         |	where inc_day<='$inc_day'
         |	and order_status=2
         |	group by car_team_id
         |) t5
         |on t1.id=t5.car_team_id
         |left join
         |(
         |	select
         |	team_id,
         |	end_balance as begin_balance
         |	from dm_gis.dm_ddjy_team_account_report_di
         |	where inc_day=replace(date_sub(trunc(from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd'),'MM'),1),'-','')
         |	and tag='每日'
         |) t6
         |on t1.id=t6.team_id
         |left join month_yes_fleet_refund_tmp t9
         |on t1.id=t9.user_id
         |left join agg_yes_fleet_refund_tmp t10
         |on t1.id=t10.user_id
         |left join
         |(
         |	select
         |	team_id,
         |	end_balance
         |	from dm_gis.dm_ddjy_team_account_report_di
         |	where inc_day='$inc_day'
         |	and tag='每日'
         |) t11
         |on t1.id=t11.team_id
         |""".stripMargin
    val teamAccountMonthDf: DataFrame = spark.sql(monthSql)
    teamAccountMonthDf.repartition(1).createOrReplaceTempView("teamAccountMonthTmp")
    spark.sql(s"insert into table dm_gis.dm_ddjy_team_account_report_di partition(inc_day='${inc_day}') select * from teamAccountMonthTmp")
    logger.error("写入dm_ddjy_team_account_report_di每月成功，日期为："+inc_day)
    yes_fleet_refund_df.unpersist()
    agg_yes_fleet_refund_df.unpersist()
    end_balance_df.unpersist()
    month_yes_fleet_refund_df.unpersist()
  }


  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    var before_yesterday=""
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      before_yesterday = DateUtil.getDateStr(incDay, -1, "")
      teamprocess(spark,incDay,before_yesterday)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>CollectionTeamAccountData Execute Ok")
  }

}
