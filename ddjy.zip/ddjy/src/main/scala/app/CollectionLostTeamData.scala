package app

import java.time.LocalDate

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:流失车队报表
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:359
 * 任务名称：流失车队报表
 * 依赖任务：吨吨加油-订单过滤明细表去重 352、每日-原始油站信息过滤表 512
 * 数据源：ddjy_dwd_station_order_repartition_di、ddjy_dim_station_info_filter
 * 调用服务地址：无
 * 数据结果：dwd_ddjy_station_team_di、dm_ddjy_uimp_lost_team_detail_di
 */
object CollectionLostTeamData {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def dateStream(fromDt:LocalDate):Stream[LocalDate]={
    fromDt #::dateStream(fromDt.plusDays(1))
  }

  def stationProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String) = {
    val tmpSql=
      s"""
        |select
        |from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd') as `date`,
        |province_name,city_name,car_team_id,min_pay_day,max_pay_day,order_count,agg_ft_sale_money,avg_agg_ft_sale_money,his_station_name
        |from
        |(
        |	select
        |	t1.province_name,t1.city_name,car_team_id,
        |	min(min_pay_day) as min_pay_day,
        |	max(max_pay_day) as max_pay_day,
        |	sum(order_count) as order_count,
        |	round(sum(agg_ft_sale_money),2) as agg_ft_sale_money,
        |	round(sum(agg_ft_sale_money)/(datediff(max(max_pay_day),min(min_pay_day))+1),2) as avg_agg_ft_sale_money,
        |	concat_ws(',',collect_set(petrol_station_name)) as his_station_name
        |	from
        |	(
        |		select
        |		province_name,
        |		city_name,
        |		station_id,
        |		car_team_id,
        |		min_pay_day,
        |		max_pay_day,
        |		order_count,
        |		agg_ft_sale_money
        |		from dm_gis.dwd_ddjy_station_team_di
        |		where inc_day='$inc_day'
        |	) t1
        |	left join
        |	(
        |		select *
        |		from dm_gis.ddjy_dim_station_info_filter
        |		where inc_day='$inc_day'
        |	) t2
        |	on t1.station_id=t2.id
        |	group by t1.province_name,t1.city_name,car_team_id
        |) t3
        |where replace(max_pay_day,'-','')<'$last_seven_day'
        |""".stripMargin
    val tmpDf: DataFrame = spark.sql(tmpSql)
    val tmp="tmp"+s"$inc_day"
    tmpDf.createOrReplaceTempView(tmp)
    val lostTeamDf: DataFrame = spark.sql(
      s"""
         |select
         |t4.*,
         |if(t3.car_team_id is null,'是','否') as is_increased
         |from $tmp t4
         |left join
         |(
         |	select
         |	city_name,car_team_id
         |	from dm_gis.dm_ddjy_uimp_lost_team_detail_di
         |	where inc_day='$before_yesterday'
         | group by city_name,car_team_id
         |) t3
         |on t4.city_name=t3.city_name and t4.car_team_id=t3.car_team_id
         |""".stripMargin)
    lostTeamDf.repartition(1).createOrReplaceTempView("lostTeamTmp")
    spark.sql(s"insert overwrite table dm_gis.dm_ddjy_uimp_lost_team_detail_di partition(inc_day='$inc_day') select * from lostTeamTmp")
    logger.error("写入dm_ddjy_uimp_lost_team_detail_di每日成功，日期为："+inc_day)
  }

  def stationTeamProcess(spark: SparkSession, inc_day: String, before_yesterday: String) = {
    val sql=
      s"""
        |select
        |from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd') as `date`,
        |province_name,
        |city_name,
        |station_id,
        |car_team_id,
        |min_pay_day,
        |max_pay_day,
        |order_count,
        |round(aggr_ft_sale_money,2) as aggr_ft_sale_money
        |from
        |(
        |	select
        |	station_id,
        |	car_team_id,
        |	min(substr(pay_time,1,10)) as min_pay_day,
        |	max(substr(pay_time,1,10)) as max_pay_day,
        |	count(order_status) as order_count,
        |	sum(ft_sale_money) as aggr_ft_sale_money
        |	FROM dm_gis.ddjy_dwd_station_order_repartition_di
        |	WHERE inc_day<='$inc_day'
        |	and order_status='2'
        |	group by station_id,car_team_id
        |) t3
        |left join
        |(
        |	select
        |	petrol_station_name,province_name,
        |	city_name,
        |	id,
        |	substr(create_date,1,10) as create_day
        |	from dm_gis.ddjy_dim_station_info_filter
        |	where inc_day='$inc_day'
        |) t5
        |on t3.station_id=t5.id
        |""".stripMargin
    val stationTeamDf: DataFrame = spark.sql(sql)
    stationTeamDf.repartition(1).createOrReplaceTempView("stationTeamTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_station_team_di partition(inc_day='$inc_day') select * from stationTeamTmp")
    logger.error("写入dwd_ddjy_station_team_di每日成功，日期为："+inc_day)
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    for (i <- (0 to 60).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      stationTeamProcess(spark,incDay,before_yesterday)
      stationProcess(spark,incDay,before_yesterday,last_seven_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>流失车队 Execute Ok")
  }

}
