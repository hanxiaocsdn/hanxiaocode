package app

import app.TeamClueTransformation.writeToHive
import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.Functions.{doubleToPercent, timeToCustomTime2}

import java.text.SimpleDateFormat
import java.util.Calendar

/**
 * 车队消费情况统计
 * 需求方：陶慧（01424177）
 * @author 徐游飞（01417347）
 * 任务ID：554
 * 任务名称：车队消费情况统计
 */
object TeamMorningReportDtl {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )


  def getDataSouse(spark: SparkSession, dayBefore1: String, firstDay: String, monthLasttDay: String) = {
    import spark.implicits._
    // 获取车队全量报表数据
    val team_quota_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.ddjy_dwd_team_quota_dtl
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println("获取team_quota_dtl表数据 sql语句：")
    println(team_quota_sql)

    // 获取车队上个月最后一天的数据
    val monthLastDay_Sql =
      s"""
         |select
         |  user_id,
         |  total_ft_sale_money,
         |  total_city_ft_sale_money
         |from
         |  dm_gis.ddjy_dwd_team_quota_dtl
         |where
         |  inc_day = '$monthLasttDay'
         |""".stripMargin

    println("获取monthLasttDay取数 sql语句：")
    println(monthLastDay_Sql)

    val df_team_quota = spark.sql(team_quota_sql)
      .withColumn("first_trade_time",timeToCustomTime2('first_trade_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("statistical_day_old",'statistical_day)
      .withColumn("statistical_day",timeToCustomTime2('statistical_day,lit("yyyy-MM-dd"),lit("yyyyMMdd")))

    val df_month_last_day = spark.sql(monthLastDay_Sql)


    (df_team_quota,df_month_last_day)
  }

  def run(spark: SparkSession, incDay: String) = {
    import spark.implicits._

    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    // dayBefore1时间当月的第一天
    val firstDay = getMonthFirstDay(dayBefore1, "yyyyMMdd")
    // dayBefore1时间上月的最后一天
    val monthLasttDay = DateUtil.getDayBefore(firstDay, "yyyyMMdd", 1)

    // 获取数据
    val dataSouse = getDataSouse(spark, dayBefore1, firstDay, monthLasttDay)
    val df_month_last_day = dataSouse._2.persist(StorageLevel.MEMORY_AND_DISK)
    val df_team_quota = dataSouse._1.persist(StorageLevel.MEMORY_AND_DISK)

    // 统计上月最后一天的累计数据（user_id 维度）
    val df_month_last_day_id = df_month_last_day
      .groupBy("user_id")
      .agg(
        sum('total_ft_sale_money.cast("double")) as "month_last_day_gmv"
      )
    // 统计上月最后一天的累计数据（user_id city_name 维度）
    val df_month_last_day_name = df_month_last_day
      .withColumn("city_name_sale",explode(split('total_city_ft_sale_money, ";")))
      .withColumn("city_name",split('city_name_sale, ":")(0))
      .withColumn("total_ft_sale_money_2",split('city_name_sale, ":")(1))
      .filter('city_name.isNotNull)
      .groupBy("user_id","city_name")
      .agg(
        sum('total_ft_sale_money_2.cast("double")) as "month_last_day_city_gmv"
      )

    // user_id 维度统计指标
    val df_group_id = df_team_quota
      .groupBy("user_id")
      .agg(
        countDistinct('team_id) as "team_no",
        countDistinct(when('total_ft_sale_money.cast("double") > 0, 'team_id).otherwise(null)) as "consumer_cnt",
        //round(sum('total_ft_sale_money.cast("double")),2) as "sum_gmv",
        round(sum(when('is_off === "否",'total_ft_sale_money.cast("double")).otherwise(0.0)),2) as "sum_gmv",
        countDistinct(when('team_id_label === "平台流失" and 'task_status =!= "已闭环", 'team_id).otherwise(null)) as "lost_cnt",
        countDistinct(when('team_id_label === "城市流失" and 'task_status =!= "已闭环", 'team_id).otherwise(null)) as "city_lost_cnt",
        countDistinct(when('team_id_label === "平台流失" and 'task_status =!= "已闭环" and 'start_time >= firstDay and 'start_time <= dayBefore1, 'team_id).otherwise(null)) as "current_month_lost_cnt",
        countDistinct(when('team_id_label === "城市流失" and 'task_status =!= "已闭环" and 'start_time >= firstDay and 'start_time <= dayBefore1, 'team_id).otherwise(null)) as "city_current_month_lost_cnt",
        countDistinct(when('team_id_label === "平台流失" and 'task_status === "已闭环" and 'is_off === "否", 'team_id).otherwise(null)) as "lost_closed_cnt",
        countDistinct(when('team_id_label === "平台流失" and 'task_status === "已作业", 'team_id).otherwise(null)) as "lost_processed_cnt",
        countDistinct(when('team_id_label === "平台流失" and 'task_status === "未作业", 'team_id).otherwise(null)) as "lost_unprocessed_cnt",
        round(avg(when('team_id_label === "平台流失" and 'task_status === "已闭环" and 'is_off === "否", 'close_cycle.cast("double")).otherwise(null)),2) as "lost_avg_close_cycle",
        countDistinct(when('team_id_label === "超5天未消费" and 'task_status =!= "已闭环", 'team_id).otherwise(null)) as "sum_unconsumed",
        countDistinct(when('team_id_label === "超5天未消费" and 'task_status =!= "已闭环" and 'first_trade_time >= firstDay and 'first_trade_time <= dayBefore1 and 'start_time >= firstDay and 'start_time <= dayBefore1, 'team_id).otherwise(null)) as "month_new_unconsumed_team",
        countDistinct(when('total_ft_sale_money.cast("double") > 0 and 'first_trade_time >= firstDay and 'first_trade_time <= dayBefore1, 'team_id).otherwise(null)) as "month_new_consumed_team",
        countDistinct(when('first_trade_time >= firstDay and 'first_trade_time <= dayBefore1, 'team_id).otherwise(null)) as "month_new_team",
        countDistinct(when('team_id_label === "超5天未消费" and 'task_status === "已闭环" and 'is_off === "否", 'team_id).otherwise(null)) as "consumed_closed_cnt",
        countDistinct(when('team_id_label === "超5天未消费" and 'task_status === "已作业", 'team_id).otherwise(null)) as "consumed_processed_cnt",
        countDistinct(when('team_id_label === "超5天未消费" and 'task_status === "未作业", 'team_id).otherwise(null)) as "consumed_unprocessed_cnt",
        round(avg(when('team_id_label === "超5天未消费" and 'task_status === "已闭环" and 'is_off === "否", 'close_cycle.cast("double")).otherwise(null)),2) as "consumed_avg_close_cycle",
        countDistinct(when('task_type === "潜力拓展任务" and 'task_status =!= "已闭环", 'team_id).otherwise(null)) as "potential_consumer_cnt",
        //round(avg('oil_dimension2.cast("double")),2) as "avg_potential_ratio",
        round(avg(when('is_off === "否",'oil_dimension2.cast("double")).otherwise(null)),2) as "avg_potential_ratio",
        countDistinct(when('task_type === "潜力拓展任务" and 'task_status =!= "已闭环" and 'start_time >= firstDay and 'start_time <= dayBefore1, 'team_id).otherwise(null)) as "month_potential_consumer_cnt",
        round(avg(when('start_time >= firstDay and 'start_time <= dayBefore1, 'oil_dimension2.cast("double")).otherwise(null)),2) as "month_avg_potential_ratio",
        countDistinct(when('task_type === "潜力拓展任务" and 'task_status === "已闭环" and 'is_off === "否", 'team_id).otherwise(null)) as "potential_closed_cnt",
        countDistinct(when('task_type === "潜力拓展任务" and 'task_status === "已作业", 'team_id).otherwise(null)) as "potential_processed_cnt",
        countDistinct(when('task_type === "潜力拓展任务" and 'task_status === "未作业", 'team_id).otherwise(null)) as "potential_unprocessed_cnt",
        round(avg(when('task_type === "潜力拓展任务" and 'task_status === "已闭环" and 'is_off === "否", 'close_cycle.cast("double")).otherwise(null)),2) as "potential_avg_close_cycle",
        countDistinct(when('task_type === "重要回访任务" and 'is_off === "否", 'team_id).otherwise(null)) as "important_consumer_cnt",
        round(sum(when('task_type === "重要回访任务" and 'is_off === "否", 'total_ft_sale_money.cast("double")).otherwise(null)),2) as "important_gmv",
        countDistinct(when('task_type === "重要回访任务" and 'start_time >= firstDay and 'start_time <= dayBefore1, 'team_id).otherwise(null)) as "month_important_consumer_cnt",
        round(sum('total_ft_sale_money.cast("double")),2) as "all_sum_gmv",
        round(sum(when('task_type === "重要回访任务" and 'start_time >= firstDay and 'start_time <= dayBefore1, 'total_ft_sale_money.cast("double")).otherwise(null)),2) as "month_important_gmv",
        countDistinct(when('task_type === "重要回访任务" and 'task_status === "已闭环" and 'is_off === "否", 'team_id).otherwise(null)) as "important_closed_cnt",
        countDistinct(when('task_type === "重要回访任务" and 'task_status === "已作业", 'team_id).otherwise(null)) as "important_processed_cnt",
        countDistinct(when('task_type === "重要回访任务" and 'task_status === "未作业", 'team_id).otherwise(null)) as "important_unprocessed_cnt",
        round(avg(when('task_type === "重要回访任务" and 'task_status === "已闭环" and 'is_off === "否", 'close_cycle.cast("double")).otherwise(null)),2) as "important_avg_close_cycle",
        count(when('team_id_label === "平台流失" and 'is_off === "否",'prob_reason).otherwise(null)) as "lost_reason_top3_2",
        count(when('team_id_label === "平台流失" and 'task_status === "未闭环",'prob_reason).otherwise(null)) as "lost_no_closed_reason_top3_2",
        count(when('team_id_label === "超5天未消费" and 'is_off === "否",'prob_reason).otherwise(null)) as "unconsumed_reason_top3_2",
        count(when('team_id_label === "超5天未消费" and 'task_status === "未闭环",'prob_reason).otherwise(null)) as "unconsumend_no_closed_reason_top3_2",
        count(when('task_type === "潜力拓展任务" and 'task_status === "未闭环",'prob_reason).otherwise(null)) as "potential_no_closed_reason_top3_2"
      )
      .join(df_month_last_day_id,Seq("user_id"),"left")
      .withColumn("month_new_consumed_percent", round('month_new_consumed_team / 'month_new_team,2))
      .withColumn("important_consumed_percent", round('important_gmv / 'sum_gmv,2))
      .withColumn("month_important_consumed_percent", round('month_important_gmv / ('all_sum_gmv - 'month_last_day_gmv),2))
      .withColumn("sum_consumed_percent",round('consumer_cnt / 'team_no,2))
      .withColumn("important_improved_reason_top3",lit(""))
      .withColumn("important_no_closed_reason_top3",lit(""))
      .withColumn("potential_improved_reason_top3",lit(""))

    // user_id city_name 维度统计指标
    val df_group_id_name = df_team_quota
      .withColumn("city_name_sale",explode(split('total_city_ft_sale_money, ";")))
      .withColumn("city_name",split('city_name_sale, ":")(0))
      .withColumn("total_ft_sale_money_2",split('city_name_sale, ":")(1))
      .filter('city_name.isNotNull)
      .groupBy("user_id","city_name")
      .agg(
        countDistinct('team_id) as "city_consumer_cnt",
        //round(sum('total_ft_sale_money_2.cast("double")),2) as "city_sum_gmv",
        round(sum(when('is_off === "否",'total_ft_sale_money_2.cast("double")).otherwise(0.0)),2) as "city_sum_gmv",
        countDistinct(when('total_ft_sale_money_2.cast("double") > 0 and 'first_trade_time >= firstDay and 'first_trade_time <= dayBefore1, 'team_id).otherwise(null)) as "city_month_new_consumed",
        countDistinct(when('first_trade_time >= firstDay and 'first_trade_time <= dayBefore1, 'team_id).otherwise(null)) as "city_month_new_team",
        //round(avg('oil_dimension2.cast("double")),2) as "city_avg_potential_ratio",
        round(avg(when('is_off === "否",'oil_dimension2.cast("double")).otherwise(null)),2) as "city_avg_potential_ratio",
        round(avg(when('start_time >= firstDay and 'start_time <= dayBefore1,'oil_dimension2.cast("double")).otherwise(null)),2) as "month_city_avg_potential_ratio",
        round(sum(when('task_type === "重要回访任务" and 'is_off === "否",'total_ft_sale_money_2.cast("double")).otherwise(null)),2) as "important_consumer_city_gmv",
        round(sum(when('task_type === "重要回访任务" and 'start_time >= firstDay and 'start_time <= dayBefore1,'total_ft_sale_money_2.cast("double")).otherwise(null)),2) as "month_important_city_gmv",
        sum(when('start_time >= firstDay and 'start_time <= dayBefore1,'total_ft_sale_money_2.cast("double")).otherwise(null)) as "all_month_city_gmv"
      )
      .join(df_month_last_day_name,Seq("user_id","city_name"),"left")
      .withColumn("month_city_gmv",'all_month_city_gmv - 'month_last_day_city_gmv)

    // user_id prob_reason 维度统计指标
    val df_group_id_reason = df_team_quota
      .groupBy("user_id","prob_reason")
      .agg(
        count(when('team_id_label === "平台流失" and 'is_off === "否",'prob_reason).otherwise(null)) as "lost_reason_top3_1",
        count(when('team_id_label === "平台流失" and 'task_status === "未闭环",'prob_reason).otherwise(null)) as "lost_no_closed_reason_top3_1",
        count(when('team_id_label === "超5天未消费" and 'is_off === "否",'prob_reason).otherwise(null)) as "unconsumed_reason_top3_1",
        count(when('team_id_label === "超5天未消费" and 'task_status === "未闭环",'prob_reason).otherwise(null)) as "unconsumend_no_closed_reason_top3_1",
        count(when('task_type === "潜力拓展任务" and 'task_status === "未闭环",'prob_reason).otherwise(null)) as "potential_no_closed_reason_top3_1"
      )

    // 获取原始字段
    val df_heand = df_team_quota.select("user_id","sup_name","sup_code","sub_name","sub_code","user_name","statistical_day_old").distinct()

    // 所有维度数据关联
    val df_ret = df_heand
      .join(df_group_id,Seq("user_id"),"left")
      .join(df_group_id_name,Seq("user_id"),"left")
      .join(df_group_id_reason,Seq("user_id"),"left")
      .withColumn("inc_day",lit(dayBefore1))
      .withColumn("lost_reason_top3",concat_ws(":",'prob_reason,doubleToPercent(round('lost_reason_top3_1 / 'lost_reason_top3_2,2))))
      .withColumn("lost_no_closed_reason_top3",concat_ws(":",'prob_reason,doubleToPercent(round('lost_no_closed_reason_top3_1 / 'lost_no_closed_reason_top3_2,2))))
      .withColumn("unconsumed_reason_top3",concat_ws(":",'prob_reason,doubleToPercent(round('unconsumed_reason_top3_1 / 'unconsumed_reason_top3_2,2))))
      .withColumn("unconsumend_no_closed_reason_top3",concat_ws(":",'prob_reason,doubleToPercent(round('unconsumend_no_closed_reason_top3_1 / 'unconsumend_no_closed_reason_top3_2,2))))
      .withColumn("potential_no_closed_reason_top3",dataToJson('prob_reason,doubleToPercent(round('potential_no_closed_reason_top3_1 / 'potential_no_closed_reason_top3_2,2))))
      .withColumn("statistical_day",'statistical_day_old)
      .na.fill(0, Array("team_no"
      ,"consumer_cnt"
      ,"city_consumer_cnt"
      ,"lost_cnt"
      ,"city_lost_cnt"
      ,"current_month_lost_cnt"
      ,"city_current_month_lost_cnt"
      ,"lost_closed_cnt"
      ,"lost_processed_cnt"
      ,"lost_unprocessed_cnt"
      ,"sum_unconsumed"
      ,"month_new_unconsumed_team"
      ,"city_month_new_consumed"
      ,"city_month_new_team"
      ,"consumed_closed_cnt"
      ,"consumed_processed_cnt"
      ,"consumed_unprocessed_cnt"
      ,"potential_consumer_cnt"
      ,"month_potential_consumer_cnt"
      ,"potential_closed_cnt"
      ,"potential_processed_cnt"
      ,"potential_unprocessed_cnt"
      ,"important_consumer_cnt"
      ,"month_important_consumer_cnt"
      ,"important_closed_cnt"
      ,"important_processed_cnt"
      ,"important_unprocessed_cnt"))
      .na.fill(0.0, Array("sum_gmv"
      ,"city_sum_gmv"
      ,"lost_avg_close_cycle"
      ,"lost_reason_top3"
      ,"lost_no_closed_reason_top3"
      ,"sum_consumed_percent"
      ,"month_new_consumed_percent"
      ,"consumed_avg_close_cycle"
      ,"unconsumed_reason_top3"
      ,"unconsumend_no_closed_reason_top3"
      ,"avg_potential_ratio"
      ,"city_avg_potential_ratio"
      ,"month_avg_potential_ratio"
      ,"month_city_avg_potential_ratio"
      ,"potential_avg_close_cycle"
      ,"potential_improved_reason_top3"
      ,"potential_no_closed_reason_top3"
      ,"important_consumed_percent"
      ,"important_consumer_city_gmv"
      ,"month_important_consumed_percent"
      ,"month_important_city_gmv"
      ,"month_city_gmv"
      ,"important_avg_close_cycle"
      ,"important_improved_reason_top3"
      ,"important_no_closed_reason_top3"))

    // 数据落表
    val cols_ret = spark.sql("""select * from dm_gis.ddjy_sale_city_index_monitor_df limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_ret: _*),Seq("inc_day"),"dm_gis.ddjy_sale_city_index_monitor_df")

    df_team_quota.unpersist()
    df_month_last_day.unpersist()
  }

  /**
   * 数据转换为json格式
   * @return
   */
  def dataToJson = udf((col1: String,col2: String) => {
    var obj = new JSONObject()
    if(col1 == null || col1.trim == ""){
      obj.put("null",col2)
    }else{
      obj.put(col1,col2)
    }
    obj.toJSONString
  })

  /**
   *  获取当前时间的这个月第一天
   * @param incDay   格式：yyyyMMdd
   * @param dateFormat
   * @return firstDay 格式：yyyyMMdd
   */
  def getMonthFirstDay(incDay: String, dateFormat: String) = {
    val sdf = new SimpleDateFormat(dateFormat)
    val date = sdf.parse(incDay)
    val  cal_1 =Calendar.getInstance()//获取当前日期
    cal_1.setTime(date)
    cal_1.set(Calendar.DAY_OF_MONTH, 1)
    val firstDay = sdf.format(cal_1.getTime())
    firstDay
  }

  def main(args: Array[String]): Unit = {

    // inc_day 为业务时间，即跑数时间
    val inc_day = args(0)
//    // 衡度大数据平台SparkConf
//    val conf = getSparkConf_hd(className,null)
//    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    spark.sparkContext.setLogLevel("WARN")

    logger.error("++++++++  任务开始  ++++")
    run(spark, inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()

  }

}
