package app

import com.sf.gis.scala.base.spark.Spark
import common.DataSourceCommon
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.{SparkUtil, SparkUtils}


/**
 * @author 01420395 caiguofang
 *
 * @DESCRIPTION
 * 任务id:
 * 任务名称: 初始化车队和微信群数据信息 一次性任务
 * 需求id: 2245976
 * 需求负责人: 陈治仁(ft220534)
 * 需求描述:GIS-RSS-DDJY：【吨吨加油】车队消费情况表_数据侧_V1.0_01405644_李相志
 * @create 2024/2/21 11:03 by caiguofang 01420395
 *
 */


object ImportTeamFleetFromFile extends DataSourceCommon{
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val cols = Seq("team_id","team_name","chat_id","chat_name")

    val sparkSession: SparkSession = SparkUtil.getSparkSession(appName)

    val inputPath = "/dolphinscheduler/user/01420395//team_fleet.csv"

    import org.apache.spark.sql.functions._

    val df1 = sparkSession.read.option("header", "true")
      .option("delimiter", "\\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .coalesce(1)
      .select(cols.map(col): _*)

    df1.show(1, false)

    writeToHiveNoP(sparkSession, df1, "dm_gis.dm_ddjy_fleet_wechat_mapping")

  }


}
