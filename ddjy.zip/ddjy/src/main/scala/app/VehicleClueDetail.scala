package app

import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:车队线索明细表
 * 需求人员：左佳怡 01403789
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2022/11/26
 * 任务id:481
 * 任务名称：车队业务分布统计表
 * 依赖任务：车辆归属更新638
 * 数据源：ddjy_stat_swid_count、ddjy_linkinfo、dim_ddjy_vehicle_concat_yy_df、ddjy_stat_swid_count_sf_wi、ddjy_linkinfo_sf_wf、dundun_inner_outer_traj_info、dim_adcode_city_info
 * 调用服务地址：
 * 数据结果：ddjy_vehicle_clue_detail_di
 */
object VehicleClueDetail {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def updateVehicleClueDetail(spark: SparkSession, max_day: String, vehicle_max_day: String,after_one_day:String) = {
    logger.error("正在执行 ddjy_vehicle_clue_detail_di 任务.........")
    val vehicle_clue_detail_sql=
      s"""
        |insert overwrite table dm_gis.ddjy_vehicle_clue_detail_di partition(inc_day='${max_day}')
        |Select
        |c1.trackno as trackno,
        |c1.srcid as srcid,
        |c1.`count` as `count`,
        |c1.roadclass as roadclass,
        |c1.linklength as linklength,
        |c1.adcode as adcode,
        |c1.road_name as road_name,
        |c1.delflag as delflag,
        |c1.geolinkpoint as geolinkpoint,
        |c1.formway as formway,
        |c1.fc as fc,
        |c1.overhead as overhead,
        |c1.ownership as ownership,
        |d1.owner_id as car_team_id,
        |d1.owner_name as car_team_name,
        |`count`*linklength as dist,
        |e1.province,
        |e1.city,
        |e1.district,
        |'yy' as source
        |From
        |(
        |	SELECT
        |	  a1.trackno as trackno,
        |	  b1.srcid as srcid,
        |	  a1.`count` as `count`,
        |	  b1.roadclass as roadclass,
        |	  b1.linklength as linklength,
        |	  b1.adcode as adcode,
        |	  b1.road_name as road_name,
        |	  b1.del_flag as delflag,
        |	  b1.geolinkpoint as geolinkpoint,
        |	  b1.formway as formway,
        |	  b1.fc as fc,
        |	  b1.overhead as overhead,
        |	  b1.ownership as ownership
        |	FROM
        |	(
        |		SELECT
        |		*
        |		FROM dm_gis.ddjy_stat_swid_count
        |		where inc_day = '${max_day}'
        |	) a1
        |	LEFT JOIN (
        |		SELECT
        |		*
        |		FROM dm_gis.ddjy_linkinfo
        |	) b1
        |	ON a1.swid = b1.srcid
        |	WHERE b1.roadclass IN ('0','1','2','6','7')
        |) c1
        |Left join
        |(
        |	Select
        |	vehicle_no,
        |	owner_id,
        |	owner_name
        |	from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |	where inc_day = '${vehicle_max_day}'
        |) d1
        |on c1.trackno = d1.vehicle_no
        |left join dm_gis.dim_adcode_city_info e1
        |on c1.adcode=e1.adcode
        |union all
        |select
        |c.trackno as trackno,
        |c.srcid as srcid,
        |c.count as count,
        |c.roadclass as roadclass,
        |c.linklength as linklength,
        |c.adcode as adcode,
        |c.road_name as road_name,
        |c.delflag as delflag,
        |c.geolinkpoint as geolinkpoint,
        |c.formway as formway,
        |c.fc as fc,
        |c.overhead as overhead,
        |c.ownership as ownership,
        |'' as car_team_id,
        |d.carrier_name as car_team_name,
        |`count`*linklength as dist,
        |e.province,
        |e.city,
        |e.district,
        |'sf' as source
        |from
        |(
        |	SELECT
        |	a.trackno as trackno,
        |	a.swid as swid,
        |	a.count as count,
        |	b.srcid as srcid,
        |	b.roadclass as roadclass,
        |	b.linklength as linklength,
        |	b.adcode as adcode,
        |	b.road_name as road_name,
        |	b.del_flag as delflag,
        |	b.geolinkpoint as geolinkpoint,
        |	b.formway as formway,
        |	b.fc as fc,
        |	b.overhead as overhead,
        |	b.ownership as ownership
        |	FROM
        |	(
        |		SELECT
        |		*
        |		FROM dm_gis.ddjy_stat_swid_count_sf_wi
        |		where inc_day = '${max_day}'
        |	) a
        |	LEFT JOIN
        |	(
        |		SELECT
        |		*
        |		FROM dm_gis.ddjy_linkinfo_sf_wf
        |	) b
        |	ON a.swid = b.srcid
        |	WHERE b.roadclass IN ('0','1','2','6','7')
        |) c
        |Left join
        |(
        |	select
        |	Distinct un, carrier_name
        |	from dm_gis.dundun_inner_outer_traj_info
        |	where inc_day = '${after_one_day}'
        |	and source = 'sf'
        |	and un is not null
        |) d
        |on c.trackno = d.un
        |left join dm_gis.dim_adcode_city_info e
        |on c.adcode=e.adcode
        |""".stripMargin
    spark.sql(vehicle_clue_detail_sql)

  }

  def execute(incDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val stat_swid_count_sf_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.ddjy_stat_swid_count
        |where inc_day<='$incDay'
        |""".stripMargin
    val stat_swid_count_sf_df: DataFrame = spark.sql(stat_swid_count_sf_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, stat_swid_count_sf_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    val after_one_day = DateUtil.getDateStr(max_day, 1, "")
    logger.error("分区最大值1天后的日期："+after_one_day)
    //获取车辆所属车队维表分区最大值
    val vehicle_max_day_sql=
      s"""
        |select
        |max(inc_day) as vehicle_max_day
        |from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |where inc_day<='$incDay'
        |""".stripMargin
    val vehicle_max_day_df: DataFrame = spark.sql(vehicle_max_day_sql)
    val vehicle_max_day: String = SparkUtils.getDfToJson(spark, vehicle_max_day_df).map(obj => {
      obj.getString("vehicle_max_day")
    }).collect().head
    logger.error("车辆所属车队维表数据分区最大值："+vehicle_max_day)
    //车队停留油站频次表
    updateVehicleClueDetail(spark,max_day,vehicle_max_day,after_one_day)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>VehicleClueDetail Execute Ok")
  }
}
