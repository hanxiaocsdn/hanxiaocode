package app

import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * @Description:车队停留油站频次表
 * 需求人员：刘芮 01412988
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2022/11/26
 * 任务id:674
 * 任务名称：车队停留油站频次表
 * 依赖任务：车辆归属更新638
 * 数据源：ddjy_vehicle_way_frequency_di、dim_ddjy_vehicle_concat_yy_df
 * 调用服务地址：
 * 数据结果：ddjy_team_way_frequency_di
 */
object TeamWayFrequency {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def updateTeamWayFrequency(spark: SparkSession, max_day: String, vehicle_max_day: String) = {
    logger.error("正在执行 ddjy_team_way_frequency_di 任务.........")
    val team_way_frequency_sql=
      s"""
        |insert overwrite table dm_gis.ddjy_team_way_frequency_di partition(inc_day='${max_day}')
        |select
        |grpid,pid,poiid,srcId,stationname,province,city,district,lng,lat,cooperatestatus,owner_id,owner_name,province_name,city_name,area_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,frequency_tl,vehicle_count_tl
        |from
        |(
        |	select
        |	grpid,pid,poiid,srcId,stationname,province,city,district,lng,lat,cooperatestatus,
        |	owner_id,owner_name,province_name,city_name,area_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,
        |	sum(frequency_tl) over(partition by poiid,owner_id) as frequency_tl,
        |	count(*) over(partition by poiid,owner_id) as vehicle_count_tl
        |	from
        |	(
        |		select
        |		grpid,pid,poiid,srcId,stationname,province,city,district,lng,lat,cooperatestatus,frequency_tl,trackno
        |		from dm_gis.ddjy_vehicle_way_frequency_di
        |		where inc_day='${max_day}'
        |	) t1
        |	left join
        |	(
        |		select
        |		owner_id,owner_name,province_name,city_name,area_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,vehicle_no
        |		from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |		where inc_day='${vehicle_max_day}'
        |	) t2
        |	on t1.trackno=t2.vehicle_no
        |) t3
        |group by grpid,pid,poiid,srcId,stationname,province,city,district,lng,lat,cooperatestatus,owner_id,owner_name,province_name,city_name,area_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,frequency_tl,vehicle_count_tl
        |""".stripMargin
    spark.sql(team_way_frequency_sql)

  }

  def execute(incDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val vehicle_way_frequency_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.ddjy_vehicle_way_frequency_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val vehicle_way_frequency_df: DataFrame = spark.sql(vehicle_way_frequency_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, vehicle_way_frequency_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    //获取车辆所属车队维表分区最大值
    val vehicle_max_day_sql=
      s"""
        |select
        |max(inc_day) as vehicle_max_day
        |from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |where inc_day<='$incDay'
        |""".stripMargin
    val vehicle_max_day_df: DataFrame = spark.sql(vehicle_max_day_sql)
    val vehicle_max_day: String = SparkUtils.getDfToJson(spark, vehicle_max_day_df).map(obj => {
      obj.getString("vehicle_max_day")
    }).collect().head
    logger.error("车辆所属车队维表数据分区最大值："+vehicle_max_day)
    //车队停留油站频次表
    updateTeamWayFrequency(spark,max_day,vehicle_max_day)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>TeamWayFrequency Execute Ok")
  }
}
