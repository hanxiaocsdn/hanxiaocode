package app

import java.text.SimpleDateFormat
import java.util.Calendar

import app.CarrierInfoSeed.className
import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{lit, row_number, when}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{DataSourceCommon, SparkWrite}

/**
 * @Description:车队消费情况表
 * @Author: lixiangzhi 01405644
 * @Date: 11:05 2022/11/29
 * 任务id:
 * 任务名称：车队消费情况表
 * 依赖任务：
 * 数据源：
 * 调用服务地址：无
 * 数据结果：
 */

object CarrierConsumeSituation{
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  def teamProcess(spark: SparkSession, inc_day: String, before_yesterday: String,last_seven_day:String,last_fourteen_day:String,fri_day:String) = {
    import spark.implicits._
    //读取ddjy_ods_sales_team
    val salesTeamSql=
      s"""
        |select
        |
        |from dm_gis.ddjy_ods_sales_team
        |where inc_day='$inc_day'
        |""".stripMargin
    val teamInfoSql=
      s"""
        |select id,name from dm_gis.ddjy_dim_team_info_filter where inc_day='$inc_day'
        |""".stripMargin
    SparkUtils.getRowToJson(spark,teamInfoSql).map(obj=>{
      (obj.getString("id"),obj)
    })


    //SparkWrite.writeToHiveDynamic(spark,resultDF,"inc_day","dm_gis.ddjy_dwd_station_stream_detail")
    logger.error("写入ddjy_dwd_station_stream_detail每日成功，日期为："+inc_day)
  }

  def minStationOrderFilterPaytime(spark: SparkSession, inc_day: String,init_day:String) = {
    val stationOrderFilterSql=
      s"""
         |select substr(min(business_time),0,10)as inc_day
         |from dm_gis.ddjy_dwd_station_order_filter
         |where inc_day='${inc_day}'
         |""".stripMargin
    var start_day: String = SparkUtils.getRowToJson(spark,stationOrderFilterSql).map(obj=>{
      val inc_day: String = obj.getString("inc_day").replace("-", "")
      inc_day
    }).collect().head
    if (init_day!=""){
      start_day=init_day
    }
    val dates: Int = DateUtil.daysDiff(start_day, inc_day).toInt
    logger.error("当天支付时间最早的时间:"+start_day)
    logger.error(start_day+"和"+inc_day+"时间间隔是:"+dates+"天")
    dates
  }

  def execute(inc_day:String,init_day:String,is_init:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取ddjy_dwd_station_order_filter，计算是否有补录订单，以及补录订单最早时间
    var dates = minStationOrderFilterPaytime(spark, inc_day,init_day)
    if (dates>60 && is_init=="N"){
      dates=60
    }
    for (i <- (0 to dates).reverse){
      var incDay:String=inc_day
      incDay = DateUtil.getDateStr(incDay, -i, "")
      val before_yesterday: String = DateUtil.getDateStr(incDay, -1, "")
      val last_seven_day: String = DateUtil.getDateStr(incDay, -6, "")
      val last_fourteen_day: String = DateUtil.getDateStr(incDay, -13, "")
      val sdf = new SimpleDateFormat("yyyyMMdd")
      val actionTime = sdf.parse(incDay)
      val cal_5 = Calendar.getInstance
      cal_5.setTime(actionTime)
      cal_5.add(Calendar.WEEK_OF_MONTH, -1)
      cal_5.set(Calendar.DAY_OF_WEEK, 6)
      val fri_day = sdf.format(cal_5.getTime)
      teamProcess(spark,incDay,before_yesterday,last_seven_day,last_fourteen_day,fri_day)
    }
    logger.error("写入全部成功")


  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    val init_day: String = args(1)
    val is_init: String = args(2)
    execute(inc_day,init_day,is_init)
    logger.error("======>>>>>>车队消费情况表 Execute Ok")
  }
  case class AddTag(province_name:String,
                    area_name:String,
                    city_name:String,
                    car_team_id:String,
                    station_id:String,
                    sign_province:String,
                    sign_city:String,
                    first_trade_date:String,
                    first_pay_date:String,
                    last_pay_date:String,
                    total_order:String,
                    total_sales:String,
                    is_lost:String,
                    date:String,
                    sum_order:String,
                    sum_sales:String,
                    last_trade_date:String,
                    last_trade_amount:String,
                    sum_trade_amount:String,
                    end_balance:String,
                    label_easy:String,
                    oil_dimension2:String,
                    team_id_label:String,
                    grpid:String,
                    station_type:String,
                    team_province:String,
                    team_city:String,
                    team_create_date:String,
                    consume_vehicle_daily_cnt:String,
                    is_consumed_team_daily:String,
                    consume_carplate_aggr:String,
                    recharge_cnt:String,
                    tag:String,
                    team_vehicle_cnt:String,
                    fixed_team_vehicle_cnt:String,
                    month_tag:String,
                    consume_carplate_ocr_aggr:String,
                    team_first_order_sales:String
                   )

}
