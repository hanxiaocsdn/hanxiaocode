package app

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.{SparkUtils, SparkWrite}

import scala.collection.JavaConversions._
import scala.util.matching.Regex

/**
 * @Description:更新车队信息种子表
 * 需求人员：ft220622 周邦耀
 * @Author: lixiangzhi 01405644
 * @Date:20231213
 * 任务id:
 * 任务名称：更新车队信息种子表
 * 依赖任务：
 * 数据源：
 * 调用服务地址：无
 * 数据结果：
 */
object CarrierInfoSeed {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readCarrierInfoSeed(spark: SparkSession, start_day: String,end_day:String) = {
    import spark.implicits._
    //读取dwd_ddjy_dept_line_sf_di近6个月的数据
    val lineSfSql=
      s"""
         |select carrier_id
         |from dm_gis.dwd_ddjy_dept_line_sf_di
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |group by carrier_id
         |""".stripMargin
    val lineSfMap = SparkUtils.getRowToJson(spark, lineSfSql).map(obj => {
      (obj.getString("carrier_id"), obj)
    }).collectAsMap()
    val seedFilterSql=
      """
        |select
        |max(cast (nvl(split(owner_id,'-')[1],0) as bigint)) as max_owner_id
        |from dm_gis.dwd_ddjy_carrier_info_seed
        |where owner_id like 'sa-%'
        |""".stripMargin
    val seedFilterDf: DataFrame = spark.sql(seedFilterSql)
    seedFilterDf.show(10,false)
    var max_owner_id: Long = 0
    if (seedFilterDf.count()>1){
      max_owner_id = seedFilterDf.collect().head.getLong(0)
    }
    logger.error("获取sa开头最大ownerid："+max_owner_id)
    val lineSfBC: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(lineSfMap)
    val carrierInfoSeedSql=
      s"""
        |select * from dm_gis.dwd_ddjy_carrier_info_seed
        |""".stripMargin
    val delflagRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, carrierInfoSeedSql).map(obj => {
      val owner_id: String = obj.getString("owner_id")
      val lineSfValue: collection.Map[String, JSONObject] = lineSfBC.value
      val rightObj: JSONObject = lineSfValue.getOrElse(owner_id, null)
      var carrier_tag = "cantonese_carrier_tag"
      if (rightObj != null) {
        carrier_tag = "sf_carrier_tag"
      }
      obj.put("carrier_tag", carrier_tag)
      obj
    }).map(obj => {
      val name: String = obj.getString("name")
      var company_org_type_clean: String = JSONUtil.getJsonValSingle(obj, "company_org_type_clean")
      var credit_code: String = JSONUtil.getJsonValSingle(obj, "credit_code")
      val regex = new Regex("[a-zA-Z0-9]+")
      val companyResult: String = regex.findAllIn(company_org_type_clean).mkString(",")
      val regex1 = new Regex("[^a-zA-Z0-9]")
      val creditResult: String = regex1.findAllIn(credit_code).mkString(",")
      val regex2 = new Regex("[^0-9]")
      val creditResult15: String = regex2.findAllIn(credit_code).mkString(",")
      val regex3 = new Regex("^[^\\u4e00-\\u9fa5a-zA-Z0-9]*$")
      val nameResult: String = regex3.findAllIn(name).mkString(",")


      var delflag = 0
      if (StringUtils.isEmpty(name) || nameResult.length==0) {
        delflag = 1
      }
      if (companyResult.length != 0 && company_org_type_clean.length == 18) {
        credit_code = company_org_type_clean
        company_org_type_clean = ""
        delflag = 1
      }
      if (creditResult.length != 0 || !(credit_code.length == 18 || (credit_code.length == 15 && creditResult15.length == 0))) {
        credit_code = ""
      }
      obj.put("credit_code", credit_code)
      obj.put("company_org_type_clean", company_org_type_clean)
      obj.put("delflag", delflag)
      val owner_id: String = JSONUtil.getJsonValSingle(obj, "owner_id")
      var order_tag = 0
      if (owner_id.contains("xz")) {
        order_tag = 1
      }
      obj.put("order_tag", order_tag)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val nullCreditCodeRdd: RDD[JSONObject] = delflagRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("credit_code"))
    })

    val rnkCreditCodeDf = delflagRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("credit_code"))
    }).map(obj=>{
      CaseRnkCreditCode(
        obj.getString("owner_id"),
        obj.getString("credit_code"),
        obj.getString("name"),
        obj.getString("company_org_type_clean"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("city_adcode"),
        obj.getString("business_scope"),
        obj.getString("source_time"),
        obj.getString("type"),
        obj.getString("src"),
        obj.getString("create_time"),
        obj.getString("flag"),
        obj.getString("delflag"),
        obj.getString("carrier_tag"),
        obj.getString("order_tag")
      )
    }).toDF()
    rnkCreditCodeDf.createOrReplaceTempView("rnkCreditCodeTmp")
    val rankSql=
      s"""
        |select
        |*,
        |row_number() over(partition by credit_code order by order_tag desc,create_time) as credit_code_rnk
        |from rnkCreditCodeTmp
        |""".stripMargin
    val rankDf: DataFrame = spark.sql(rankSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val firstCarrierInfoSeedDf: Dataset[Row] = rankDf.filter('credit_code_rnk === 1).toDF()
    firstCarrierInfoSeedDf.createOrReplaceTempView("firstCarrierInfoSeedTmp")
    val rnkFirstCarrierInfoSeedSql=
      """
        |select
        |*,
        |row_number() over(partition by owner_id order by create_time) as owner_id_rnk
        |from firstCarrierInfoSeedTmp
        |""".stripMargin
    val rnkFirstCarrierInfoSeedDf: DataFrame = spark.sql(rnkFirstCarrierInfoSeedSql)
    val oldCarrierInfoSeedDf: DataFrame = rnkFirstCarrierInfoSeedDf.filter('owner_id_rnk === 1).toDF()
    val oldCarrierInfoSeedRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, oldCarrierInfoSeedDf)
    val otherCarrierInfoSeedDf: DataFrame = rnkFirstCarrierInfoSeedDf.filter('owner_id_rnk > 1).toDF()
    otherCarrierInfoSeedDf.createOrReplaceTempView("otherCarrierInfoSeedTmp")
    val owneridSql=
      s"""
        |select
        |concat('sa-',rnk+$max_owner_id) as owner_id
        |,credit_code
        |,name
        |,company_org_type_clean
        |,legal_person_name
        |,content
        |,city_adcode
        |,business_scope
        |,source_time
        |,typeStr as type
        |,src
        |,create_time
        |,flag
        |,delflag
        |,carrier_tag
        |from
        |(
        |	select
        |	*,
        |	row_number() over(order by 1) as rnk
        |	from otherCarrierInfoSeedTmp
        |) t2
        |""".stripMargin
    val owneridRdd = SparkUtils.getRowToJson(spark, owneridSql).union(oldCarrierInfoSeedRdd).map(obj=>{
      (obj.getString("credit_code"),obj.getString("owner_id"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("不重复的ownder_id数据量:"+owneridRdd.count())
    val carrierInfoSeedDf: DataFrame = delflagRdd.map(obj=>{
      (obj.getString("credit_code"),obj)
    }).leftOuterJoin(owneridRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val owner_id: String = obj._2._2.orNull
      leftObj.put("owner_id",owner_id)
      leftObj
    }).map(obj => {
      CaseUpdateCarrierInfoSeed(
        obj.getString("owner_id"),
        obj.getString("credit_code"),
        obj.getString("name"),
        obj.getString("company_org_type_clean"),
        obj.getString("legal_person_name"),
        obj.getString("content"),
        obj.getString("city_adcode"),
        obj.getString("business_scope"),
        obj.getString("source_time"),
        obj.getString("type"),
        obj.getString("src"),
        obj.getString("create_time"),
        obj.getString("flag"),
        obj.getString("delflag"),
        obj.getString("carrier_tag")
      )
    }).toDF()
    SparkWrite.writeToHiveNoPart(spark,carrierInfoSeedDf,"dm_gis.dwd_ddjy_carrier_info_seed_two")
    //更新种子复制表
    /*val lineUpdateCarrierInfoSeedTestSql=
      """
        |insert overwrite table dm_gis.dwd_ddjy_carrier_info_seed_copy
        |select * from dm_gis.dwd_ddjy_carrier_info_seed
        |""".stripMargin
    spark.sql(lineUpdateCarrierInfoSeedTestSql)*/
  }

  def execute(start_day: String,end_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    readCarrierInfoSeed(spark,start_day,end_day)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val start_day: String = args(0)
    val end_day: String = args(1)
    execute(start_day,end_day)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseUpdateCarrierInfoSeed(
                                        owner_id:String,
                                        credit_code:String,
                                        name:String,
                                        company_org_type_clean:String,
                                        legal_person_name:String,
                                        content:String,
                                        city_adcode:String,
                                        business_scope:String,
                                        source_time:String,
                                        typeStr:String,
                                        src:String,
                                        create_time:String,
                                        flag:String,
                                        delflag:String,
                                        carrier_tag:String
                                      )
  case class CaseRnkCreditCode(
                                        owner_id:String,
                                        credit_code:String,
                                        name:String,
                                        company_org_type_clean:String,
                                        legal_person_name:String,
                                        content:String,
                                        city_adcode:String,
                                        business_scope:String,
                                        source_time:String,
                                        typeStr:String,
                                        src:String,
                                        create_time:String,
                                        flag:String,
                                        delflag:String,
                                        carrier_tag:String,
                                        order_tag:String
                                      )

}
