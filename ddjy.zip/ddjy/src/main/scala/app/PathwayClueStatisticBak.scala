package app

import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.SparkWrite

/**
 * @Description:沿途线索聚合表
 * 需求人员：刘芮 01412988
 * @Author: lixiangzhi 01405644
 * @Date: 13:53 2022/11/26
 * 任务id:672
 * 任务名称：沿途线索聚合表
 * 依赖任务：车辆归属更新638
 * 数据源：ddjy_station_pathway_statistic_clue_di、dim_ddjy_vehicle_concat_yy_df
 * 调用服务地址：无
 * 数据结果：ddjy_pathway_clue_statistic_di
 */
object PathwayClueStatisticBak {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def updatePathwayStatisticClue(spark: SparkSession, max_day: String, vehicle_max_day: String) = {
    logger.error("正在执行 ddjy_pathway_clue_statistic_di 任务.........")
    val pathway_clue_statistic_sql=
      s"""
        |
        |select
        |distinct grpid,pid,t1.poiid,srcid,stationname,province,city,district,lng,lat,cooperatestatus,
        |t1.owner_id,owner_name,province_name,city_name,area_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,
        |frequency_tj,frequency_zb,
        |vehicle_count_tj,
        |vehicle_count_zb,
        |dh_dist_sum
        |from
        |(
        |	select poiid,owner_id,
        |	sum(priority_tj) as frequency_tj,
        |	sum(priority_zb) as frequency_zb,
        |  sum(dh_dist_sum*priority_zb)/sum(priority_zb) as dh_dist_sum
        |	from
        |	(
        |	select poiid,trackno,priority_tj,priority_zb,dh_dist_sum
        |	from dm_gis.ddjy_station_pathway_statistic_clue_di
        |	where inc_day = '${max_day}'
        |	) a
        |	left join
        |	(
        |	 select vehicle_no,owner_id,owner_name
        |	 from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |	 where inc_day = '${vehicle_max_day}'
        |	) b on a.trackno = b.vehicle_no
        |	group by poiid,owner_id
        |) t1
        |left join
        |(
        |	select poiid,owner_id,
        |	count(*) as vehicle_count_tj
        |	from
        |	(
        |	select distinct poiid,trackno
        |	from dm_gis.ddjy_station_pathway_statistic_clue_di
        |	where inc_day = '${max_day}' and  priority_tj>0
        |	) c
        |	left join
        |	(
        |	 select vehicle_no,owner_id,owner_name
        |	 from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |	 where inc_day = '${vehicle_max_day}'
        |	) d
        |	on c.trackno = d.vehicle_no
        |	group by poiid,owner_id
        |) t2
        |on t1.poiid=t2.poiid and t1.owner_id=t2.owner_id
        |left join
        |(
        |	select poiid,owner_id,
        |	count(*) as vehicle_count_zb
        |	from
        |	(
        |	select distinct poiid,trackno
        |	from dm_gis.ddjy_station_pathway_statistic_clue_di
        |	where inc_day ='${max_day}' and priority_zb>0
        |	) e
        |	left join
        |	(
        |	select vehicle_no,owner_id,owner_name
        |	from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |	where inc_day = '${vehicle_max_day}'
        |	) f
        |	on e.trackno = f.vehicle_no
        |	group by poiid,owner_id
        |) t3
        |on t1.poiid=t3.poiid and t1.owner_id=t3.owner_id
        |left join
        |(
        |	select
        |	distinct owner_id,owner_name,province_name,city_name,area_name,area_manager_name,org_type,credit_code,manager,manager_phone,contactor,contactor_phone,owner_type,city_id,access_date
        |	from dm_gis.dim_ddjy_vehicle_concat_yy_df
        |	where inc_day = '${vehicle_max_day}'
        |) t4
        |on t1.owner_id=t4.owner_id
        |left join
        |(
        |	select distinct grpid,pid,poiid,srcid,stationname,province,city,citycode,district,addr,lng,lat,cooperatestatus
        |	from dm_gis.ddjy_station_pathway_statistic_clue_di
        |	where inc_day = '${max_day}'
        |) t5
        |on t1.poiid=t5.poiid
        |where t1.owner_id is not null
        |""".stripMargin
    val resultDf: DataFrame = spark.sql(pathway_clue_statistic_sql)
    SparkWrite.writeToHive(spark,resultDf,"inc_day",max_day,"dm_gis.ddjy_pathway_clue_statistic_di")

    //insert overwrite table dm_gis.ddjy_pathway_clue_statistic_di partition(inc_day='${max_day}')

  }

  def execute(incDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //获取分区最大值
    val pathway_statistic_clue_day_sql=
      s"""
        |select
        |max(inc_day) as max_day
        |from dm_gis.ddjy_station_pathway_statistic_clue_di
        |where inc_day<='$incDay'
        |""".stripMargin
    val pathway_statistic_clue_day_df: DataFrame = spark.sql(pathway_statistic_clue_day_sql)
    val max_day: String = SparkUtils.getDfToJson(spark, pathway_statistic_clue_day_df).map(obj => {
      obj.getString("max_day")
    }).collect().head
    logger.error("分区最大值："+max_day)
    //获取车辆所属车队维表分区最大值
    val vehicle_max_day: String = DateUtil.getDateStr(max_day, 1, "")
    logger.error("车辆所属车队维表数据分区最大值："+vehicle_max_day)
    //更新车队状态
    updatePathwayStatisticClue(spark,max_day,vehicle_max_day)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    //execute()
    logger.error("======>>>>>>PathwayClueStatistic Execute Ok")
  }
}
