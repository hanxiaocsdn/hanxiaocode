package app

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 16:09 2022/6/8
 */
object IcMergePointToHive {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readStreetAndTimestampData(spark: SparkSession,incDay:String) = {
    val ic_sql=
      """
        |select
        |*
        |from dm_gis.ods_ic_track_merge_data_di
        |""".stripMargin
    val addTimeRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark,ic_sql).flatMap(obj => {
      val data: String = obj.getString("data")
      val dataArray: JSONArray = JSON.parseArray(data)
      val array = new ArrayBuffer[JSONObject]()
      for (i <- 0 until(dataArray.size())) {
        val tmpObj: JSONObject = dataArray.getJSONObject(i)
        array.append(tmpObj)
      }
      array.iterator()
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("车辆疑似经停油站数据")
    val oilHookCarRdd: RDD[JSONObject] = addTimeRdd.filter(_.getString("data_src") == "oilHookCar")
    oilHookCarRdd.take(10).foreach(println(_))
    logger.error("车辆聚集点数据")
    val carAggrRdd: RDD[JSONObject] = addTimeRdd.filter(_.getString("data_src") != "oilHookCar")
    carAggrRdd.take(10).foreach(println(_))
    (oilHookCarRdd,carAggrRdd)
  }

  def insertHiveTable(spark: SparkSession, carAggrRdd: RDD[JSONObject],oilHookCarRdd: RDD[JSONObject]) = {
    import spark.implicits._
    val carAggrDf: DataFrame = carAggrRdd.map(obj => {
      (
        obj.getString("agr_id"),
        obj.getString("agr_cnt"),
        obj.getString("agr_dis"),
        obj.getString("agr_tm"),
        obj.getString("agr_lng"),
        obj.getString("agr_lat"),
        "",
        obj.getString("agr_gh"),
        "",
        "",
        obj.getString("type"),
        "IC",
        obj.getString("cmp_partition").replace("YY_","")
      )
    }).toDF()
    carAggrDf.createOrReplaceTempView("carAggrTmp")
    spark.sql(s"insert overwrite table dm_gis.dwd_ddjy_mid_track_ic_dm_sgl_di partition(cmp_partition) select * from carAggrTmp")
    logger.error("车辆聚集点数据写入完成！！！")

    val oilHookCarDf: DataFrame = oilHookCarRdd.map(obj => {
      (
        obj.getString("agr_gh"),
        obj.getString("agr_cnt"),
        obj.getString("agr_id").split("_")(0),
        obj.getString("data_src"),
        obj.getString("type"),
        obj.getString("cmp_partition").split("_")(1)
      )
    }).toDF()
    oilHookCarDf.createOrReplaceTempView("oilHookCarTmp")

    spark.sql(s"insert overwrite table dm_gis.ddjy_vehicle_suspect_way_info_ic_di partition(inc_day) select * from oilHookCarTmp")
    logger.error("车辆疑似停留油站数据写入完成！！！")
  }

  def execute(inc_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    val (oilHookCarRdd,carAggrRdd) = readStreetAndTimestampData(spark,inc_day)
    insertHiveTable(spark,carAggrRdd,oilHookCarRdd)


  }

  def main(args: Array[String]): Unit = {
    var inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>IcMergePointToHive Execute Ok")
  }

}
