package app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.control.Breaks

/**
 * @Description:订单油站引流异常
 * 需求方：陶慧 01424177
 * @Author: lixiangzhi 01405644
 * @Date: 17:21 2022/9/30
 * 任务id:216
 * 任务名称：吨吨加油-油站引流异常表
 * 依赖任务：油站报表 448
 * 数据源：ddjy_dim_holiday_legal_cn_yi、ddjy_uimp_dm_station_order_oil_report、ddjy_dim_station_info_filter、ddjy_ods_dim_petrol_price_current
 * 调用服务地址：
 * 数据结果：ddjy_uimp_dm_station_drainage_exception
 */
object StationDrainageException {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  /**
   * 读取油站报表数据，并关联法定节假日维表（每年生成一次，使用工具类HolidaytUtils）
   * @param spark
   * @param inc_day
   */
  def readSourceData(spark: SparkSession, inc_day: String) = {

    //读取法定节假日数据
    var end_date: String = DateUtil.changeDateSep(inc_day, "", "-")
    val holidaySql=
      s"""
        |select *
        |from dm_gis.ddjy_dim_holiday_legal_cn_yi
        |where date<='$end_date'
        |""".stripMargin
    val holidayDf: DataFrame = spark.sql(holidaySql)
    val holidayArray: Array[(String, String)] = holidayDf.orderBy(holidayDf("date").desc).rdd.map(obj=>{
      (obj.getString(0),obj.getString(1))
    }).collect()
    var dateTag=0
    var start_date=""
    val dateLoop = new Breaks
    dateLoop.breakable{
      for (i <- holidayArray.indices){
        val date: String = holidayArray(i)._1
        //logger.error("date:"+date)
        val holiday_legal_cn: String = holidayArray(i)._2
        if (holiday_legal_cn=="非法定节假日"){
          dateTag+=1
          if (dateTag==7){
            start_date=date
            dateLoop.break()
          }
        }
      }
    }
    //logger.error("start_date:"+start_date+",end_date:"+end_date)
    start_date = DateUtil.changeDateSep(start_date,"-","")
    end_date = DateUtil.changeDateSep(end_date,"-","")
    //根据油站聚合最近非法定节假日的7天报表数据
    val stationSql=
      s"""
         |select station_id,
         |sum(pay_success) as pay_success
         |from dm_gis.ddjy_uimp_dm_station_order_oil_report
         |where inc_day>='$start_date' and inc_day<='$end_date'
         |group by station_id
         |""".stripMargin
    //logger.error(stationSql)
    val sourceDf: DataFrame = spark.sql(stationSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //logger.error("根据油站聚合最近非法定节假日的7天后数据量："+sourceDf.count())
    sourceDf
  }


  def insertHiveTable(spark: SparkSession, sourceDf: DataFrame, inc_day: String) = {
    val noSuccessOrderDf: Dataset[Row] = sourceDf.where("pay_success==0 or pay_success is null").persist(StorageLevel.MEMORY_AND_DISK_SER)
    //logger.error("支付成功订单数量为0的油站数据量："+noSuccessOrderDf.count())
    noSuccessOrderDf.createOrReplaceTempView("tmpNoSuccessOrder")
    val successOrderDf: Dataset[Row] = sourceDf.where("pay_success!=0").persist(StorageLevel.MEMORY_AND_DISK_SER)
    //logger.error("支付成功订单数量不为0的油站数据量："+successOrderDf.count())
    successOrderDf.createOrReplaceTempView("tmpSuccessOrder")
    val station_drainage_df: DataFrame = spark.sql(
      s"""
         |
         |select from_unixtime(unix_timestamp('$inc_day','yyyyMMdd'),'yyyy-MM-dd') as `date`,
         |'' as petrol_station_name,
         |nvl(t3.sale_price,0.00) as sale_price,
         |nvl(t3.country_price,0.00) as country_price,
         |t2.create_date,t2.province_name,t2.city_name,t2.area_name,t2.address_name,t1.station_id
         |from tmpNoSuccessOrder t1
         |left join
         |(
         |	select *
         |	from dm_gis.ddjy_dim_station_info_filter
         |	where inc_day='${inc_day}'
         |) t2
         |on t1.station_id=t2.id
         |left join
         |(
         |	select station_id,sale_price,country_price
         |	from dm_gis.ddjy_ods_dim_petrol_price_current
         |	where inc_day='${inc_day}'
         |	and del_flag=0
         |) t3
         |on t1.station_id=t3.station_id
         |""".stripMargin)
    station_drainage_df.repartition(1).createOrReplaceTempView("station_drainage_tmp")
    spark.sql(s"insert overwrite table dm_gis.ddjy_uimp_dm_station_drainage_exception partition(inc_day='$inc_day') select * from station_drainage_tmp")
  }

  def execute(inc_day: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    val sourceDf: DataFrame = readSourceData(spark, inc_day)
    insertHiveTable(spark,sourceDf,inc_day)
  }

  def main(args: Array[String]): Unit = {
    val inc_day: String = args(0)
    execute(inc_day)
    //execute()
    logger.error("======>>>>>>StationDrainageException Execute Ok")
  }
}
