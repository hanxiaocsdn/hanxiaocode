package utils

import com.alibaba.fastjson.JSONObject
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}

/**
 * Created by 01368978 on 2020/8/3.
 */
object SparkUtil {

  /**
   * 配置spark的conf
   * 默认超时等待时间为60秒
   *
   * @param appName
   * @return
   */
  def getSparkConf(appName: String): SparkConf = {
    getSparkConf(appName, "180000") //
  }

  /**
   * 配置spark的conf
   *
   * @param appName
   * @return
   */
  def getSparkConf(appName: String, timeOut: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("mapreduce.input.fileinputformat.split.maxsize", 4194304.toString)
    conf.set("mapreduce.input.fileinputformat.split.minsize.per.node", 4194304.toString)
    conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", timeOut)
    conf
  }


  // 将df的每一行数据转为json
  def row2Json(r: Row): JSONObject = {
    val rowMap_tmp: Map[String, String] = r.getValuesMap(r.schema.fieldNames)
    val rowMap: Map[String, String] = rowMap_tmp.map(v => {
      if (v._2 == null) (v._1, "") else v
    })

    val obj: JSONObject = new JSONObject()
    for (m <- rowMap) obj.put(m._1, m._2)
    obj
  }

  /**
   * 获取spark程序入口
   *
   * @param appName
   * @return
   */
  def getSparkSession(appName: String): SparkSession = {
    val spark = SparkSession.builder().config(getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("error")
    spark
  }

  def getLocalSpark(appName: String, master: String = "local[4]"): SparkSession = {
    val sparkConf = getSparkConf(appName)
    //    if(sparkConf.get("spark.master")==null)sparkConf.setMaster(master)
    if (sparkConf.getOption("spark.master").isEmpty) sparkConf.setMaster(master)
    val spark = SparkSession.builder().config(sparkConf).getOrCreate()
    //    val spark = SparkSession.builder().config(sparkConf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    spark
  }

  def getSparkContext(appName: String): SparkContext = {
    val sparkConf = getSparkConf(appName)
    val sc = new SparkContext(sparkConf)
    sc
  }


}
