package utils

import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date}

import scala.collection.mutable.ArrayBuffer
import scala.util.matching.Regex

import org.apache.commons.lang3.StringUtils

object DateTimeUtil extends Serializable {

    def main(args: Array[String]): Unit = {
         println(timestampConvertDate(1639150177,"yyyyMMdd"))
    }



    def getCurDayBeforeYesterDay() = {

        val date = new Date()
        val sdf = new SimpleDateFormat("yyyyMMdd")
        val date2 = sdf.format(date)
        val yesterDay = getDaysApartDate("yyyyMMdd",date2 ,-2)

        yesterDay

    }



    def getCurDayYesterDay() = {

        val date = new Date()
        val sdf = new SimpleDateFormat("yyyyMMdd")
        val date2 = sdf.format(date)
        val yesterDay = getDaysApartDate("yyyyMMdd",date2 ,-1)

        yesterDay

    }



    /**
      * 根据时间判断，将一天分为96个时段，每15分钟一个时段
      */

    def getPeriodTimeIndex(curTm:Int,inc_day:String): Int ={
        import Array._
        var indexList =  range(1, 97)
        var falg = 0
        var periodIndex = 0

        val concatTime = inc_day + " " + "00:00:00"
        val startTm = timeToLong(concatTime,"yyyyMMdd HH:mm:ss") / 1000


        for (i <-  indexList if falg == 0){
            var startTmNew = startTm + (i-1) * 900
            var endTmNew = startTm + i * 900
            if (curTm >= startTmNew && curTm < endTmNew){
                periodIndex = i -1
                falg = 1
            }
        }

        periodIndex
    }



    /**
      * 拼接日期时间转换为时间戳
      */

    def getIncDayToTimeStamp(inc_day:String,concat_time:String): Int ={

        val concatTime = inc_day + " " + concat_time

        val timeStamp = timeToLong(concatTime,"yyyyMMdd HH:mm:ss") / 1000

        timeStamp.toInt
    }


    /**
      * 拼接日期时间转换为时间戳
      */

    def getIncDayToTimeStamp2(inc_day:String,concat_time:String,DateFormat:String): Int ={

        val concatTime = inc_day + " " + concat_time

        val timeStamp = timeToLong(concatTime,DateFormat) / 1000

        timeStamp.toInt
    }



    /**
      * 获取当天时间戳
      */

    def getCurDayTimeStamp(inc_day:String) ={

        val sdf = new SimpleDateFormat("yyyyMMdd")
        val date = sdf.parse(inc_day)
        val time = date.getTime / 1000

        time
    }


    /**
      * 获取当天时间戳
      */

    def getNextDayTimeStamp(inc_day:String) ={

        val sdf = new SimpleDateFormat("yyyyMMdd")
        val date = sdf.parse(inc_day)
        val time = date.getTime / 1000

        time
    }


    def timestampConvertDateMin(timeStamp:Long, format:String){
        new SimpleDateFormat(format).format(timeStamp * 1000)
    }


    /**
      *  给定两个时间戳，判断时间戳之间夜间驾驶时长，夜间行车时间是指22点至次日6点行车的时间,返回秒（s）
      */

    def calNightDriveDurationTime(timeStampStart:Long,timeStampEnd:Long) ={

        var allDuration = 0L
        val startDate = timestampConvertDate(timeStampStart,"yyyy-MM-dd HH:mm:ss")
        val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val date1 = sdf.parse(startDate)

        val day1 = transformDateFormat(startDate,"yyyy-MM-dd HH:mm:ss","yyyyMMdd")
        val staN = "22:00:00"
        val etaN = "06:00:00"

        val nextDay = getDaysApartDate("yyyyMMdd",day1 ,1)
        println(nextDay)
        //拼接计算得的当天22点时间戳
        val nightStart = day1 + " " + staN
        val nightEnd = nextDay + " " + staN
        println((nightStart,nightEnd))

        val nigthStartStamp = timeToLong(nightStart,"yyyyMMdd HH:mm:ss") / 1000
        val nigthEndStamp = timeToLong(nightEnd,"yyyyMMdd HH:mm:ss") / 1000
        // TODO: 判断时间戳和起始终止时间间隔 如果起始时间比夜间起始时间大，则需要判断终止时间是否超过夜间终止时间，如果超过则取夜间终止时间最大值
        if (timeStampStart >= nigthStartStamp){
            if (timeStampEnd < nigthEndStamp) {
                allDuration = timeStampEnd - timeStampStart
            } else {
                allDuration = nigthEndStamp - timeStampStart
            }
        } else if (timeStampEnd > nigthStartStamp){
            if (timeStampEnd < nigthEndStamp){
                allDuration = timeStampEnd - nigthStartStamp
            } else{
                allDuration = nigthEndStamp - nigthStartStamp
            }
        }
        allDuration
    }


    /**
      *
      * 给定两个时间戳，判断时间戳之间夜间驾驶时长，夜间行车时间是指22点到24点，或0点到6点行车的时间,返回秒（s）
      */
    def calNightDriveDurationTime2(timeStampStart:Long,timeStampEnd:Long) ={

        var allDuration = 0L
        val startDate = timestampConvertDate(timeStampStart,"yyyy-MM-dd HH:mm:ss")
        val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val date1 = sdf.parse(startDate)

        val day1 = transformDateFormat(startDate,"yyyy-MM-dd HH:mm:ss","yyyyMMdd")

        val staN1 = "00:00:00"
        val etaN1 = "06:00:00"

        val staN2 = "22:00:00"
        val etaN2 = "24:00:00"


//        val nextDay = getDaysApartDate("yyyyMMdd",day1 ,1)
//        println(nextDay)
        //拼接计算得的当天22点时间戳
        val nightStart1 = day1 + " " + staN1
        val nightEnd1 = day1 + " " + etaN1

        val nightStart2 = day1 + " " + staN2
        val nightEnd2 = day1 + " " + etaN2

        val nigthStartStamp1 = timeToLong(nightStart1,"yyyyMMdd HH:mm:ss") / 1000
        val nigthEndStamp1 = timeToLong(nightEnd1,"yyyyMMdd HH:mm:ss") / 1000

        val nigthStartStamp2 = timeToLong(nightStart2,"yyyyMMdd HH:mm:ss") / 1000
        val nigthEndStamp2 = timeToLong(nightEnd2,"yyyyMMdd HH:mm:ss") / 1000

        // TODO: 判断时间戳和起始终止时间间隔 如果起始时间比夜间起始时间大，则需要判断终止时间是否超过夜间终止时间，如果超过则取夜间终止时间最大值

        if (timeStampStart <= nigthEndStamp1){
            //start,end <=6
            if (timeStampEnd <= nigthEndStamp1){
                allDuration += (timeStampEnd - timeStampStart)
            } else if (timeStampEnd >6 && timeStampEnd <= nigthStartStamp2){
                //start <=6 && end > 6 end <= 22
                allDuration += (nigthEndStamp1 - timeStampStart)
            }else if (timeStampEnd > nigthStartStamp2){
                // start <=6 && end >22
                allDuration += (nigthEndStamp1 - timeStampStart)
                allDuration += (timeStampEnd - nigthStartStamp2)
            }
        } else if (timeStampStart > nigthEndStamp1 && timeStampStart <= nigthStartStamp2){
            // start > 6 && <22 && end > 22
            if (timeStampEnd >= nigthStartStamp2){
                allDuration += (timeStampEnd - nigthStartStamp2)
            }
        } else {
            // start >22
                allDuration += (timeStampEnd - timeStampStart)
        }

        allDuration
    }



    /**
      * 计算两日期的差(分钟)
      */




    def parseFtTime(startDate: String,endDate:String,srcDateFormat:String): Int = {


        val cal = Calendar.getInstance()
        val sdf = new SimpleDateFormat(srcDateFormat)
        val sdf2 = new SimpleDateFormat(srcDateFormat)


        val startDateFormat = sdf.parse(startDate)
        val endDateFormat = sdf2.parse(endDate)


        val diff =  Math.abs((endDateFormat.getTime - startDateFormat.getTime) / 60000)

        diff.toInt
//        val cal = Calendar.getInstance()
//        val sdf = new SimpleDateFormat(srcDateFormat)
//
////        val diff =  (sdf.parse(endDate).getDay - sdf.parse(startDate).getDay ) * 1440 + (sdf.parse(endDate).getHours - sdf.parse(startDate).getHours ) * 60 + (sdf.parse(endDate).getMinutes - sdf.parse(startDate).getMinutes)
//        val diff =  (sdf.parse(endDate).getDay - sdf.parse(startDate).getDay ) * 1440 +  (sdf.parse(endDate).getHours - sdf.parse(startDate).getHours ) * 60 + (sdf.parse(endDate).getMinutes - sdf.parse(startDate).getMinutes)
//
//        println(".....")
//        println((sdf.parse(startDate).getDay))
//        println(".....")
//        println((sdf.parse(endDate).getHours - sdf.parse(startDate).getHours ) * 60)
//        println(".....")
//        println((sdf.parse(endDate).getMinutes - sdf.parse(startDate).getMinutes))
//
//        Math.abs(diff)
    }

    /**
      * 计算两日期的差(天)
      */

    def parseFtTimeDay(startDate: String,endDate:String,srcDateFormat:String,srcDateFormat2:String): Int = {
        val cal = Calendar.getInstance()
        val sdf = new SimpleDateFormat(srcDateFormat)
        val sdf2 = new SimpleDateFormat(srcDateFormat2)


        val startDateFormat = sdf.parse(startDate)
        val endDateFormat = sdf2.parse(endDate)

        startDateFormat.setHours(0)
        startDateFormat.setMinutes(0)
        startDateFormat.setSeconds(0)

        endDateFormat.setHours(0)
        endDateFormat.setMinutes(0)
        endDateFormat.setSeconds(0)


        val diff =  Math.abs((endDateFormat.getTime - startDateFormat.getTime) / 86400000)

        diff.toInt

    }
    /**
      * 计算两日期的差(小时)
      */

    def parseFtTimeHour(startDate: String,endDate:String,srcDateFormat:String,srcDateFormat2:String) = {
        val cal = Calendar.getInstance()
        val sdf = new SimpleDateFormat(srcDateFormat)
        val sdf2 = new SimpleDateFormat(srcDateFormat2)


        val startDateFormat = sdf.parse(startDate)
        val endDateFormat = sdf2.parse(endDate)

        val diff =  Math.abs((endDateFormat.getTime - startDateFormat.getTime) / 3600000.0)

        diff.toInt

    }



    /**
      * 计算两日期的差(分钟)
      */

    def parseFtTimeMin(startDate: String,endDate:String,srcDateFormat:String,srcDateFormat2:String) = {
        val cal = Calendar.getInstance()
        val sdf = new SimpleDateFormat(srcDateFormat)
        val sdf2 = new SimpleDateFormat(srcDateFormat2)


        val startDateFormat = sdf.parse(startDate)
        val endDateFormat = sdf2.parse(endDate)


        val diff =  Math.abs((endDateFormat.getTime - startDateFormat.getTime) / 60000.0)

        diff

    }



    /**
      * 解析2H2M时间数据到数值
      * @param ft_time
      * @return
      */
    def parseFtTime(ft_time: String): Int = {

        if (StringUtils.isEmpty(ft_time)) {
            return 0
        } else {
            var hour = 0
            var min = 0

            try {
                val patternH = new Regex("([0-9]*)H.*")
                val patternM = new Regex("([0-9]*)M")
                if (patternH.findFirstIn(ft_time) != None) {
                    hour = patternH.findAllMatchIn(ft_time).map(_.group(1)).toList.mkString("").toInt
                }
                if (patternM.findFirstIn(ft_time) != None) {
                    min = patternM.findAllMatchIn(ft_time).map(_.group(1)).toList.mkString("").toInt
                }
            } catch {
                case e: Exception => e.printStackTrace()
            }

            hour * 60 + min
        }
    }

    /**
      * 判断当前日期是星期几
      */

    def judgeWeekDay(inc_day: String, srcDateFormat: String): Int = {

        val cal = Calendar.getInstance()
        val sdf = new SimpleDateFormat(srcDateFormat)


        var dayForWeek = 0
        try {
            cal.setTime(sdf.parse(inc_day))
            val w = cal.get(Calendar.DAY_OF_WEEK) - 1
            if (cal.get(Calendar.DAY_OF_WEEK) == 1) {
                dayForWeek = 7
            } else {
                dayForWeek = cal.get(Calendar.DAY_OF_WEEK) - 1
            }
        } catch {
            case e: Exception => e.printStackTrace()
        }

        dayForWeek

    }



    /**
      * 给一个时间戳，判断当前日期是星期几
      */

    def judgeWeekDayTimeStamp(timeStamp: Long): Int = {


        val inc_day = timestampConvertDate(timeStamp,"yyyyMMdd HH:mm:ss")

        val cal = Calendar.getInstance()
        val sdf = new SimpleDateFormat("yyyyMMdd HH:mm:ss")


        var dayForWeek = 0
        try {
            cal.setTime(sdf.parse(inc_day))
            val w = cal.get(Calendar.DAY_OF_WEEK) - 1
            if (cal.get(Calendar.DAY_OF_WEEK) == 1) {
                dayForWeek = 7
            } else {
                dayForWeek = cal.get(Calendar.DAY_OF_WEEK) - 1
            }
        } catch {
            case e: Exception => e.printStackTrace()
        }

        dayForWeek

    }



    /**
      * 循环日期区间
      */

    def getDateInterval(inc_day1:String,inc_day2:String,srcDateFormat:String,targetDateFormat:String):ArrayBuffer[String]={

        val sdf = new SimpleDateFormat(srcDateFormat)
        val sdfNew = new SimpleDateFormat(targetDateFormat)
        val buffer = new ArrayBuffer[String]()

        try {
            val d1 = sdf.parse(inc_day1)
            val d2 = sdf.parse(inc_day2)
            var tmp = d1
            val dd = Calendar.getInstance()

            dd.setTime(d1)
            while (tmp.getTime < d2.getTime) {
                tmp = dd.getTime()
                buffer.append(sdfNew.format(tmp))
                dd.add(Calendar.DAY_OF_MONTH, 1)
            }
        } catch {
            case e: Exception => e.printStackTrace()
        }

        buffer
    }






    /**
      * 转换日期格式
      */

    def transformDateFormat(srcDate:String,srcDateFormat:String,targetDateFormat:String):String={

        val sdf = new SimpleDateFormat(srcDateFormat)
        val sdfNew = new SimpleDateFormat(targetDateFormat)

        val inputDate: Date = sdf.parse(srcDate)
        sdfNew.format(inputDate)

    }


    /**
      * 获取上一个月第一天和最后一天
      */
    def getMonthBeginEnd(srcDate:String,srcDateFormat:String):(String,String) ={

        val sdf = new SimpleDateFormat(srcDateFormat)
        val inputDate: Date = sdf.parse(srcDate)
        val calendar = Calendar.getInstance()
        calendar.setTime(inputDate)
        calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) - 1)
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        val beginDay = sdf.format(calendar.getTime())
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        val endDay = sdf.format(calendar.getTime())
        (beginDay,endDay)
    }

    /**
      * 获取上一个月第15天和本月15天
      */
    def getMonthMidBeginEnd(srcDate:String,srcDateFormat:String):(String,String) ={

        val sdf = new SimpleDateFormat(srcDateFormat)
        val inputDate: Date = sdf.parse(srcDate)
        val calendar = Calendar.getInstance()
        calendar.setTime(inputDate)
        calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) - 1)
        calendar.set(Calendar.DAY_OF_MONTH, 15)
        val beginDay = sdf.format(calendar.getTime())
        calendar.set(Calendar.MONTH,calendar.get(Calendar.MONTH) + 1)
        val endDay = sdf.format(calendar.getTime())
        (beginDay,endDay)
    }






    /**
      * 获取往后两周的周一和周日
      */

    def getLastTwoWeekMS(srcDate:String,srcDateFormat:String) ={
        val sdf = new SimpleDateFormat(srcDateFormat)
        val inputDate: Date = sdf.parse(srcDate)
        val calendar = Calendar.getInstance()

        calendar.setFirstDayOfWeek(Calendar.MONDAY)
        calendar.setTime(inputDate)
        calendar.add(Calendar.DAY_OF_YEAR, 14)

        var dayWeek = calendar.get(Calendar.DAY_OF_WEEK)
        if(dayWeek==1){
            dayWeek = 8
        }


        calendar.add(Calendar.DATE, calendar.getFirstDayOfWeek() - dayWeek)
        val firstDay = sdf.format(calendar.getTime())

        calendar.add(Calendar.DATE, 4 +calendar.getFirstDayOfWeek())
        val weekEnd = sdf.format(calendar.getTime)


        (firstDay,weekEnd)

    }








    /**
      * 获取后一个月的第二周周一
      */
    def getLastMonthMonday(srcDate:String,srcDateFormat:String): String ={

        val sdf = new SimpleDateFormat(srcDateFormat)
        val inputDate: Date = sdf.parse(srcDate)
        val calendar = Calendar.getInstance()
        calendar.setTime(inputDate)
        calendar.add(Calendar.MONTH, 1)
        calendar.set(Calendar.WEEK_OF_MONTH, 2)
        calendar.set(Calendar.DAY_OF_WEEK, 2);//本周第一天，以星期日开始
        val firstDay = sdf.format(calendar.getTime())
        firstDay

    }





    /**
      * 计算前几分钟的时间格式
      */

    def getMinBeforeAfter(srcDate:String,srcDateFormat:String,intervel:Int):String = {

        var minBeforeAfter = srcDate
        try{
            val sdf = new SimpleDateFormat(srcDateFormat)
            val inputDate: Date = sdf.parse(srcDate)
            val calendar = Calendar.getInstance()
            calendar.setTime(inputDate)
            calendar.add(Calendar.MINUTE, intervel)
            minBeforeAfter = sdf.format(calendar.getTime())
        }catch {
            case e:Exception => println(e.printStackTrace())
        }
        minBeforeAfter
    }



    /**
      * @note 获取前一个月的第一天
      * @param srcDate  源日期
      * @param srcDateFormat   源日期格式
      * @return
      */
    def getPreMonthFirstDay(srcDate:String,srcDateFormat:String):String={

        val sdf = new SimpleDateFormat(srcDateFormat)
        val inputDate: Date = sdf.parse(srcDate)
        //获取前一个月第一天
        val calendar = Calendar.getInstance()
        calendar.setTime(inputDate)
        calendar.add(Calendar.MONTH, -1)
        calendar.set(Calendar.DAY_OF_MONTH,1)
        val firstDay = sdf.format(calendar.getTime())
        firstDay
    }



    /**
      * @note 获取当月的第一天
      * @param srcDate  源日期
      * @param srcDateFormat   源日期格式
      * @return
      */
    def getCurMonthFirstDay(srcDate:String,srcDateFormat:String):String={

        val sdf = new SimpleDateFormat(srcDateFormat)
        val inputDate: Date = sdf.parse(srcDate)
        //获取前一个月第一天
        val calendar = Calendar.getInstance()
        calendar.setTime(inputDate)
        calendar.set(Calendar.DAY_OF_MONTH,1)
        val firstDay = sdf.format(calendar.getTime())
        firstDay
    }




    /**
      * @note 获取前一个月的最后一天
      * @param srcDate  源日期
      * @param srcDateFormat   源日期格式
      * @return
      */
    def getPreMonthLastDay(srcDate:String,srcDateFormat:String):String={
        val sdf = new SimpleDateFormat(srcDateFormat)
        val inputDate: Date = sdf.parse(srcDate)

        //获取前一个月最后一天
        val calendar = Calendar.getInstance()
        calendar.setTime(inputDate)
        calendar.set(Calendar.DAY_OF_MONTH, 0)
        val lastDay = sdf.format(calendar.getTime())

        lastDay

    }


    /**
      * @note 将日期转换为指定的日期格式
      * @param srcDate  源日期
      * @param srcDateFormat   源日期格式
      * @param destDateFormat   目标日期格式
      * @return
      */
    def getConvertFormatDate(srcDate: String, srcDateFormat: String, destDateFormat: String): String = {
        val date = new SimpleDateFormat(srcDateFormat).parse(srcDate)
        val destDate = new SimpleDateFormat(destDateFormat).format(date)
        destDate
    }

    /**
      * 获得两个字符串日期中所有日期的字符格式集合
      * @param startDateStr
      * @param endDateStr
      * @return
      */
    def getBetweenDatesStr(startDateStr: String, endDateStr: String): ArrayBuffer[String] = {
        val sdf = new SimpleDateFormat("yyyy-MM-dd")
        val dateListStr = new ArrayBuffer[String]
        try {
            val startDate = sdf.parse(startDateStr)
            val endDate = sdf.parse(endDateStr)
            val dateList = getBetweenDates(startDate, endDate)
            for (date <- dateList)
                dateListStr += sdf.format(date)
        } catch {
            case e: ParseException => println(">>>Date Convert Exception..." + e)
        }
        dateListStr
    }

    def getBetweenDatesStr(startDateStr: String, endDateStr: String, dateFormat:String): ArrayBuffer[String] = {
        val sdf = new SimpleDateFormat(dateFormat)
        val dateListStr = new ArrayBuffer[String]
        try {
            val startDate: Date = sdf.parse(startDateStr)
            val endDate: Date = sdf.parse(endDateStr)
            val dateList = getBetweenDates(startDate, endDate)
            for (date <- dateList)
                dateListStr += sdf.format(date)
        } catch {
            case e: ParseException => println(">>>Date Convert Exception..." + e)
        }
        dateListStr
    }


    /**
      * 获得两个日期之间的所有日期列表
      * @param start
      * @param end
      * @return
      */
    def getBetweenDates(start: Date, end: Date): ArrayBuffer[Date] = {
        val result = new ArrayBuffer[Date]
        val tempStart = Calendar.getInstance
        tempStart.setTime(start)
        tempStart.add(Calendar.DAY_OF_YEAR, 1)
        val tempEnd = Calendar.getInstance
        tempEnd.setTime(end)
        while (tempStart.before(tempEnd)) {
            result += tempStart.getTime
            tempStart.add(Calendar.DAY_OF_YEAR, 1)
        }
        result
    }

    /**
      * 获取本机日历日期
      * @param delta
      * @return
      */
    def dateDelta(delta: Int): String = {
        dateDelta(delta, "-")
    }

    /**
      * 获取本机日历日期
      * @param delta
      * @return
      */
    def dateDelta(delta: Int, separator: String): String = {
        val sdf = new SimpleDateFormat("yyyy" + separator + "MM" + separator + "dd")
        val cal = Calendar.getInstance()
        cal.add(Calendar.DATE, delta)
        val date = sdf.format(cal.getTime)
        date
    }

    /**
      * 获取本机当前系统时间并转换为指定日期格式
      * @param  format 日期格式
      * @return
      */
    def getCurrentSystemTime(format: String): String ={
        val simpleDateFormat = new SimpleDateFormat(format)
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DATE, 0)
        val dateTime = simpleDateFormat.format(calendar.getTime)
        dateTime
    }


    /**
      * @note   获取距离指定日期相隔days天的的日期：
      * @param inputDateStr 指定日期
      * @param days          相隔天数 正数表示在之后n天，负数表示在之前n天
      * @param dateFormat   日期格式(eg：yyyy-MM-dd, yyyy/MM/dd)
      * @return
      **/
    def getDaysApartDateSetHour(inputDateStr: String,dateFormat: String, days: Integer): String = {

        val cal = Calendar.getInstance()
        val sdf = new SimpleDateFormat(dateFormat)

        val parseDateFormat = sdf.parse(inputDateStr)

        parseDateFormat.setHours(0)
        parseDateFormat.setMinutes(0)
        parseDateFormat.setSeconds(0)

        val calendar = Calendar.getInstance
        calendar.setTime(parseDateFormat)
        calendar.add(Calendar.DAY_OF_YEAR, days)

        val date = calendar.getTime
        val dateStr = sdf.format(date).trim
        dateStr
    }





    /**
      * @note   获取距离指定日期相隔days天的的日期：
      * @param inputDateStr 指定日期
      * @param days          相隔天数 正数表示在之后n天，负数表示在之前n天
      * @param dateFormat   日期格式(eg：yyyy-MM-dd, yyyy/MM/dd)
      * @return
      **/
    def getDaysApartDate(dateFormat: String, inputDateStr: String, days: Integer): String = {
        val simpleDateFormat = new SimpleDateFormat(dateFormat)
        val inputDate: Date = simpleDateFormat.parse(inputDateStr)
        val calendar = Calendar.getInstance
        calendar.setTime(inputDate)
        calendar.add(Calendar.DAY_OF_YEAR, days)
        val date = calendar.getTime
        val dateStr = simpleDateFormat.format(date).trim
        dateStr
    }

    /**
      * 时间字符串转换成毫秒值
      * @param time
      * @return
      */
    @throws[ParseException]
    def timeToLong(time: String, format: String): Long = {
        val sf = new SimpleDateFormat(format)
        sf.parse(time).getTime
    }

    /**
      * @note   时间戳转换为时分秒
      * @param timestamp
      * @param format
      * @return
      */
    def longToTime(timestamp:Long,format:String, duration:Long=0L ): String ={
        var datetime = ""
        try {
            val simpleDateFormat = new SimpleDateFormat(format)
            datetime = simpleDateFormat.format(new Date(timestamp + duration))
        } catch {
            case e:Exception =>println(">>>>>>时间戳解析异常Exception: " + e)
        }
        datetime
    }

    /**
      * @note   时间戳转换为指定的日期格式
      * @param timestamp
      * @param format 指定的日期格式
      * @return
      */
    def timestampConvertDate(timestamp:Long, format:String): String ={
        var datetime = timestamp.toString
        try {
            val simpleDateFormat = new SimpleDateFormat(format)
            datetime = simpleDateFormat.format(timestamp * 1000)
        } catch {
            case e:Exception =>println(">>>>>>时间戳解析异常Exception: " + e)
        }
        datetime
    }


    /**
      * @note   时间戳转换为指定的日期格式
      * @param timestamp
      * @param format 指定的日期格式
      * @return
      */
    def timestampConvertDate2(timestamp:Long, format:String): String ={
        var datetime = timestamp.toString
        try {
            val simpleDateFormat = new SimpleDateFormat(format)
            datetime = simpleDateFormat.format(timestamp)
        } catch {
            case e:Exception =>println(">>>>>>时间戳解析异常Exception: " + e)
        }
        datetime
    }



}
