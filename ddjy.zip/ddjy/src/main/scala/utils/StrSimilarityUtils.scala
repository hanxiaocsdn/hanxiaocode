package utils

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @作者：Alpha.SK.LXY
 * @时间：2022/6/2 14:09
 * @描述：文本处理工具集
 */
object StrSimilarityUtils {

  /**
   * 向量的模长
   *
   * @param vec
   */
  def module(vec: Vector[Double]): Double = {
    // math.sqrt( vec.map(x=>x*x).sum )
    math.sqrt(vec.map(math.pow(_, 2)).sum)
  }

  /**
   * 求两个向量的内积
   *
   * @param v1
   * @param v2
   */
  def innerProduct(v1: Vector[Double], v2: Vector[Double]): Double = {
    val listBuffer = ListBuffer[Double]()
    for (i <- 0 until v1.length; j <- 0 until v2.length; if i == j) {
      if (i == j) {
        listBuffer.append(v1(i) * v2(j))
      }
    }
    listBuffer.sum
  }

  /**
   * 求两个向量的余弦值
   *
   * @param v1
   * @param v2
   */
  def cosvec(v1: Vector[Double], v2: Vector[Double]): Double = {
    val cos = innerProduct(v1, v2) / (module(v1) * module(v2))
    val v1d: Vector[Double] = v1.distinct
    val v2d: Vector[Double] = v2.distinct
    println(v1d.length)
    println(v2d.length)
    println(cos)
    if (cos <= 1 && v1d(0)!=0.0 && v2d(0)!=0.0){
      cos
    }else if ((v1d.nonEmpty && v2d.nonEmpty && v1d(0)==0.0 && v2d(0)!=0.0)||(v1d.nonEmpty && v2d.nonEmpty && v1d(0)!=0.0 && v2d(0)==0.0)){
      0.0
    }else{
      1.0
    }
  }

  def similarity(str1: String, str2: String): Double = {
    val set = mutable.Set[Char]() //统计两句话所有的字
    str1.foreach(set += _)
    str2.foreach(set += _)
    //println(set)
    val ints1: Vector[Double] = set.toList.sorted.map(ch => {
      str1.count(s => s == ch).toDouble
    }).toVector
    println("===ints1: " + ints1)
    val ints2: Vector[Double] = set.toList.sorted.map(ch => {
      str2.count(s => s == ch).toDouble
    }).toVector
    println("===ints2: " + ints2)
    cosvec(ints1, ints2)

  }
}
