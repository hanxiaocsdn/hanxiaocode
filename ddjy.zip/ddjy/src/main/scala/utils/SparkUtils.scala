package utils

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{HttpInvokeUtil}
import org.apache.log4j.Logger
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import java.text.SimpleDateFormat
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.{Calendar, Date, Map}

import scala.collection.mutable.ArrayBuffer
import scala.reflect.ClassTag
import scala.util.Random

object SparkUtils {


  def getSparkSession(appName: String, mode: String) = {

    val spark =
      if (mode.contains("local")) {
        SparkSession
          .builder()
          .appName(appName)
          .master(mode)
          .getOrCreate()
      } else {
        SparkSession
          .builder()
          .appName(appName)
          .master("yarn")
          .enableHiveSupport()
          .config("hive.exec.dynamic.partition", true)
          .config("hive.exec.dynamic.partition.mode", "nonstrict")
          .config("spark.sql.hive.convertInsertingPartitionedTable", "false")
          .config("spark.cleaner.referenceTracking.cleanCheckpoints", "true")
          .config("spark.sql.crossJoin.enabled", "true")
        .getOrCreate()
      }

    spark.sparkContext.setLogLevel("ERROR")
    spark
  }

  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  //aggregateByKey的柯里化函数,将JSONObject聚合成List[JSONObject]
  val seqOp = (a: List[JSONObject], b: JSONObject) => a.size match {
    case 0 => List(b)
    case _ => b :: a
  }

  val combOp = (a: List[JSONObject], b: List[JSONObject]) => {
    a ::: b
  }

  val seqOpRow = (a: List[Row], b: Row) => a.size match {
    case 0 => List(b)
    case _ => b :: a
  }

  val combOpRow = (a: List[Row], b: List[Row]) => {
    a ::: b
  }


  var t0 = 0l
  var t0Total = 0l

  def memTime() = {
    t0 = new Date().getTime
  }

  def showCost(title: String = "", enter: Boolean = true) = {
    val mss = new Date().getTime - t0
    val s = formatTime(mss)
    System.err.println((if (title.indexOf("耗时") == -1) title + "，耗时：" else title) + s + (if (enter) "\n" else ""))
    SparkUtils.memTime()
    s
  }

  def memTimeTotal() = {
    t0Total = new Date().getTime
    memTime()
  }

  def showCostTotal(title: String = "") = {
    val mss = new Date().getTime - t0Total
    val s = formatTime(mss)
    System.err.println((if (title.indexOf("总耗时") == -1) title + "，总耗时：" else title) + s + "\n")
    SparkUtils.memTimeTotal()
    s
  }


  def formatTime(mss: Long, showCurrentTime: Boolean = true) = {
    val days = mss / (1000 * 60 * 60 * 24)
    val hours = (mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
    val minutes = (mss % (1000 * 60 * 60)) / (1000 * 60)
    val seconds = (mss % (1000 * 60)) / 1000
    var s = if (days > 0) days + "天 " else ""
    s = s + (if (hours > 0) hours + "小时 " else "")
    s = s + (if (minutes > 0) minutes + "分钟 " else "")
    s = s + (if (seconds > 0) seconds + "秒" else (mss % (1000 * 60) + "毫秒"))
    if (showCurrentTime)
      s = s + " [" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime()) + "]"
    s
  }



  def getRowToJson2(sourDf: DataFrame, parNum: Int = 200) = {

    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map(obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns, obj.getAs[String](columns))
      }
      jsonObj
    })
    //      .persist(StorageLevel.DISK_ONLY)
    println(s"共获取数据:${sourRdd.count()}")
    //sourRdd.take(2).foreach(println(_))
    sourDf.unpersist()

    sourRdd
  }

  //进行post请求，失败后重试一次
  def doPost(url: String, reqJson: JSONObject, logger: Logger) = {
    var resbonseBody = "{}"

    try {
      resbonseBody = HttpInvokeUtil.sendPost(url, reqJson.toJSONString)
    } catch {
      case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
        try {
          resbonseBody = HttpInvokeUtil.sendPost(url, reqJson.toJSONString)
        } catch {
          case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
            resbonseBody = "发送post请求失败:" + e.toString
        }
    }
    resbonseBody
  }


  def clearCache(spark: SparkSession) = {
    spark.sqlContext.clearCache()

    val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
    ds.foreach(x => {
      x._2.unpersist()
    })
  }


  def df2Hive(spark: SparkSession, rdd: RDD[Row], schema: StructType, saveMode: String, descTable: String, partitionSchm: String, incDay: String, logger: Logger): Unit = {
    logger.error(s"写入hive ${descTable}中...")
    val df = spark.sqlContext.createDataFrame(rdd, schema)
    //写入前删除分区数据
    val dropSql = s"alter table $descTable drop if exists partition($partitionSchm='$incDay')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(partitionSchm).saveAsTable(descTable)

    logger.error(s"写入分区${incDay}成功")
  }

  def df2HivePs(spark: SparkSession, rdd: RDD[Row], schema: StructType, saveMode: String, descTable: String, incDay: String, region: String, logger: Logger, partitionDay: String, partitionRegion: String): Unit = {
    logger.error(s"写入hive ${descTable}中...")
    val df = spark.sqlContext.createDataFrame(rdd, schema)
    //写入前删除分区数据
    val dropSql = s"alter table $descTable drop if exists partition($incDay='$partitionDay',$region='$partitionRegion')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(incDay, region).saveAsTable(descTable)

    logger.error(s"写入分区 $partitionDay,$partitionRegion 成功")
  }

  def df2Hive(spark: SparkSession, df: DataFrame, saveMode: String, descTable: String, partitionSchm: String, incDay: String, logger: Logger): Unit = {
    logger.error(s"写入hive ${descTable}中...")

    //写入前删除分区数据
    val dropSql = s"alter table ${descTable} drop if exists partition($partitionSchm='$incDay')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(partitionSchm).saveAsTable(descTable)

    logger.error(s"写入分区${partitionSchm}成功")
  }


  def getRowToJson( spark:SparkSession,querySql:String,parNum:Int=200 ) ={
    val sourDf = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    println(s"共获取数据:${sourDf.count()}")
    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    })
    sourDf.unpersist()
    sourRdd
  }

  def getDfToJson( spark:SparkSession,sourDf:DataFrame,parNum:Int=200 ) ={
    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    })
    println(s"共获取数据:${sourRdd.count()}")

    sourDf.unpersist()

    sourRdd
  }


  def getRowToJsonNoCache(sourDf: DataFrame, parNum: Int = 200) = {

    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map(obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns, obj.getAs[String](columns))
      }
      jsonObj
    })
    //      .persist(StorageLevel.DISK_ONLY)

    //    println(s"共获取数据:${sourRdd.count()}")
    //sourRdd.take(2).foreach(println(_))
    sourDf.unpersist()

    sourRdd
  }


  def getRowToJson(sourDf: DataFrame, persistLevel: String) = {
    val parNum = 200
    var storageLevel = StorageLevel.MEMORY_AND_DISK_SER

    if (persistLevel.equals("DISK_ONLY")) {
      storageLevel = StorageLevel.DISK_ONLY
    }


    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map(obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns, obj.getAs[String](columns))
      }
      jsonObj
    }).persist(storageLevel)

    println(s"共获取数据:${sourRdd.count()}")
    //sourRdd.take(2).foreach(println(_))
    sourDf.unpersist()

    sourRdd
  }

  def getRowToJsonLevel(sourDf: DataFrame, persistLevel: String, parNum: Int) = {
    var storageLevel = StorageLevel.MEMORY_AND_DISK_SER

    if (persistLevel.equals("DISK_ONLY")) {
      storageLevel = StorageLevel.DISK_ONLY
    }


    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map(obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns, obj.getAs[String](columns))
      }
      jsonObj
    }).persist(storageLevel)

    println(s"共获取数据:${sourRdd.count()}")
    //sourRdd.take(2).foreach(println(_))
    sourDf.unpersist()

    sourRdd
  }

  // join优化
  def leftOuterJoinOfLeftLeanElemJSONObject(left: RDD[(String, JSONObject)], right: RDD[(String, JSONObject)], hashNum: Int, topLean: Int = 10): RDD[(String, (JSONObject, Option[JSONObject]))] = {
    val keyCounts = left.map(obj => (obj._1, 1)).reduceByKey(_ + _).sortBy(-_._2).take(topLean)
    val keys = keyCounts.map(obj => obj._1)
    val counts = keyCounts.map(obj => obj._2).sum
    logger.error("单独处理的keys:" + keyCounts.mkString(","))
    logger.error("单独处理的总数量:" + counts)
    //拆分数据为独立处理的key和非独立处理的key
    val leftHashKeyData = left.filter(obj => keys.contains(obj._1))
    val leftOtherData = left.filter(obj => !keys.contains(obj._1))
    val rightHashKeyData = right.filter(obj => keys.contains(obj._1))
    val rightOtherData = right.filter(obj => !keys.contains(obj._1))
    //先关联其他key数据
    val otherJoin: RDD[(String, (JSONObject, Option[JSONObject]))] = leftOtherData.leftOuterJoin(rightOtherData)
    //扩展单独处理的数据
    val leftHashKeyDataExpand: RDD[((Int, String), JSONObject)] = leftHashKeyData.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      ((hashPrefix, obj._1), obj._2)
    })
    val rightHashKeyDataExpand: RDD[((Int, String), JSONObject)] = rightHashKeyData.flatMap(obj => {
      val dataArray = new ArrayBuffer[((Int, String), JSONObject)]()
      for (i <- 0 until hashNum) {
        dataArray.append(((i, obj._1), obj._2))
      }
      dataArray.iterator
    })
    //关联数据
    val hashKeyJoin: RDD[(String, (JSONObject, Option[JSONObject]))] = leftHashKeyDataExpand.leftOuterJoin(rightHashKeyDataExpand).map(obj => (obj._1._2, obj._2))
    hashKeyJoin.union(otherJoin)
  }


  /**
   * 随机散列数据后做聚合
   *
   * @param obj     输入数据
   * @param hashNum 散列倍数，将随机一定范围内的随机值作为散列前缀
   */
  def groupByKeyTwoStep(obj: RDD[(String, Object)], hashNum: Int): Unit = {
    // 先添加随机值散列，第一次聚合
    val hashData = obj.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      ((hashPrefix, obj._1), obj._2)
    }).groupByKey().map(obj => {
      (obj._1._2, obj._2.toArray)
    })
    //再去除散列进行第二次聚合
    hashData.groupByKey().map(obj => {
      val key = obj._1
      val valueIterator = obj._2.iterator
      val ret = new ArrayBuffer[Object]
      while (valueIterator.hasNext) {
        val tmpArray = valueIterator.next()
        ret.appendAll(tmpArray)
      }
      (key, ret)
    })
  }


  def akLimitMultiThreadRdd[T: ClassTag](body: RDD[T])(fun: T => T)(limitMin: Int, partitionCnt: Int = body.getNumPartitions): RDD[T] = {

    val resRdd = body.mapPartitions(iter => {

      val partitionLimitMinu = limitMin * 0.9 / partitionCnt
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)
      for (obj <- iter) yield {

        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }
        fun(obj)
      }
    })

    resRdd

  }


  def akLimitMultiThreadDetail(partitionLimitMinu: Int, partitionsCount: AtomicInteger, lastMin: AtomicInteger,
                               timeInt: AtomicInteger, fun: (String, JSONObject, Map[String, String]) => JSONObject,
                               retList: LinkedBlockingQueue[JSONObject], ak: String,
                               obj: JSONObject, keyMap: Map[String, String]): Unit = {
    if (partitionsCount.incrementAndGet() % 100 == 0) {
      logger.error(partitionsCount)
    }
    val second = Calendar.getInstance().get(Calendar.SECOND)
    val cur = Calendar.getInstance().get(Calendar.MINUTE)
    if (cur == lastMin.get()) {
      if (timeInt.incrementAndGet() >= partitionLimitMinu) {
        logger.error("分钟数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
        Thread.sleep((60 - second) * 1000)
      }
    } else {
      //不能精细控制，set存在并发问题
      timeInt.set(1)
      lastMin.set(cur)
    }
    retList.add(fun(ak, obj, keyMap))
  }


  /**
   * 释放指定set的rdd
   *
   * @param rddString
   * @param sc
   */
  def unpersistUnuse(rddString: Set[String], sc: SparkContext) = {
    var persistRdds = sc.getPersistentRDDs
    persistRdds.foreach(truple => {

      if (rddString.contains(truple._2.toString())) {
        truple._2.unpersist()
      }
    })
  }

  /**
   * 清理全部的rdd
   *
   * @param sc
   */
  def unpersistAllUnuse(sc: SparkContext) = {
    var persistRdds = sc.getPersistentRDDs
    persistRdds.foreach(truple => {
      truple._2.unpersist()
    })
  }


}
