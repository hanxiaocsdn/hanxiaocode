package utils

import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * Description:
 * 需求方：
 * Author: 李相志 01405644
 * Date: 11:12 2023/8/4
 * 任务信息：
 */
object SparkWrite {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  //定义函数存入数据
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol:String,partitionVal:String, resTableName: String,repart:Int=5): Unit = {
    dataframe.repartition(repart).createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert overwrite table %s partition($partitionCol='$partitionVal') select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }
  //动态分区
  def writeToHiveDynamic(spark: SparkSession, dataframe: DataFrame, partitionCol:String, resTableName: String,repart:Int=5): Unit = {
    dataframe.repartition(repart).createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert overwrite table %s partition($partitionCol) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }
  //定义函数存入数据
  def writeTypeToHive(spark: SparkSession, dataframe: DataFrame,insertType:String, partitionCol:String,partitionVal:String, resTableName: String,repart:Int=5): Unit = {
    dataframe.repartition(repart).createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert $insertType table %s partition($partitionCol='$partitionVal') select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  def writeToHiveNoPart(spark: SparkSession, dataframe: DataFrame, resTableName: String,repart:Int=5): Unit = {
    dataframe.repartition(repart).createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert overwrite table %s select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }
  def writeTypeToHiveNoPart(spark: SparkSession, dataframe: DataFrame,insertType:String, resTableName: String,repart:Int=5): Unit = {
    dataframe.repartition(repart).createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert $insertType table %s select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }
}
