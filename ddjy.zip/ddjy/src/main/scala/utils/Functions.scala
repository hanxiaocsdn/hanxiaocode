package utils

import org.apache.log4j.Logger
import org.apache.spark.sql.functions.udf

import java.text.SimpleDateFormat
import java.util.Date
import scala.collection.mutable.ListBuffer

object Functions {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  /**
   * 分组收集后的排序函数，保证分组收集的所有字段顺序一一对应
   * @return
   */
  def sortField = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("\\|")
      val other_arr = other.split("\\|")
      val new_arr = num_arr.zip(other_arr).sortWith((x,y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })

  /**
   * 两种不同格式时间字符串相互转换
   * @return
   */
  def timeToCustomTime2 = udf((time: String,format1: String,format2: String) => {
    val format = new SimpleDateFormat(format1)
    val newFormat = new SimpleDateFormat(format2)

    var standardTime = new Date()
    var newTime = ""
    try{
      standardTime = format.parse(time)
      newTime = newFormat.format(standardTime)
    }catch {
      case e: Exception => println(">>>日期转换异常"+e)
    }
    newTime
  })

  /**
   * 计算两个日期的时间差，单位为天，保留指定位小数
   * date1: 时间字段1
   * date2: 时间字段2
   * dateFormat：时间格式
   * decimal：保留几位小数
   * @return 时间差 单位为天，保留指定位小数
   */
  def getDateDiff = udf((date1: String, date2: String, dateFormat: String, decimal: Int) => {
    var date1_time: Double = 0.0
    var date2_time: Double = 0.0
    var datediff = ""
    try {
      date1_time = new SimpleDateFormat(dateFormat).parse(date1).getTime
      date2_time = new SimpleDateFormat(dateFormat).parse(date2).getTime
    } catch {
      case e: Exception => println("date1时间格式错误：" + e.getMessage)
    }
    if(!date1_time.equals(0.0) && !date2_time.equals(0.0)){
      datediff = ((date1_time - date2_time) / (1000*60*60*24)).formatted(s"%.${decimal}f")
    }
    datediff
  })

  /**
   * 小数转化成百分数函数，保留两位
   * @return
   */
  def doubleToPercent = udf((col1: String) => {
    var percent = "0.0%"
    if(col1 != null && col1.trim != ""){
      try{
        percent = f"${col1.toDouble*100}%.2f%%"
      }catch {
        case e: Exception => println(">>>小数转换成百分数异常："+e)
      }
    }
    percent
  })

}
