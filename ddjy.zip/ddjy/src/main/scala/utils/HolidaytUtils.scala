//package utils
//
//import com.alibaba.fastjson.{JSONArray, JSONObject}
//import com.sf.gis.scala.base.spark.Spark
//import com.sf.gis.scala.base.util.DateUtil
//import org.apache.log4j.Logger
//import org.apache.spark.sql.{DataFrame, SparkSession}
//
//import scala.collection.mutable.ArrayBuffer
//
///**
// * @Description:获取日历和法定节假日
// * @Author: lixiangzhi 01405644
// * @Date: 15:09 2022/9/30
// */
//object HolidaytUtils {
//  val className: String = this.getClass.getSimpleName.replace("$", "")
//  @transient
//  val logger: Logger = Logger.getLogger(className)
//  def getHolidays(arr: Array[Int]) = {
//    val spark: SparkSession = Spark.getSparkSession(className, null, true, 2)
//    import spark.implicits._
//    val (excutors, cores) = Spark.getExcutorInfo(spark)
//    //val arr: Array[String] = Array("202201", "202202", "202203", "202204", "202205", "202206", "202207", "202208", "202209", "202210", "202211", "202212")
//    var df: DataFrame=null
//    for (i <- 0 until(arr.length)){
//      val retObj: JSONObject = SfNetInteface.holidaysInterface(arr(i).toString)
//      val list: JSONArray = retObj.getJSONObject("ret").getJSONObject("data").getJSONArray("list")
//      val cal = new ArrayBuffer[(String, String)]()
//      for (i <- 0 until(list.size())){
//        val listObj: JSONObject = list.getJSONObject(i)
//        val date: String = listObj.getString("date")
//        val holiday_legal_cn: String = listObj.getString("holiday_legal_cn")
//        cal.append((date,holiday_legal_cn))
//      }
//      var df1 = spark.sparkContext.parallelize(cal).toDF("date", "holiday_legal_cn").coalesce(1)
//      if (df != null){
//        df = df.union(df1).toDF()
//      }else{
//        df = df1
//      }
//      Thread.sleep(3000)
//    }
//    val frame: DataFrame = df.rdd.map(obj => {
//      val date: String = obj.getString(0)
//      val date_new: String = DateUtil.changeDateSep(date, "", "-")
//      (date_new, obj.getString(1))
//    }).toDF("date", "holiday_legal_cn").orderBy("date")
//    frame.coalesce(1).write.mode("append").option("header","false").option("encoding","utf-8").csv("d:\\user\\01405644\\桌面\\吨吨加油\\订单报表\\法定节假日维表")
//  }
//
//  def main(args: Array[String]): Unit = {
//    val arr: Array[Int] =202401.to(202412).toArray
//    getHolidays(arr)
//
//
//  }
//
//}
