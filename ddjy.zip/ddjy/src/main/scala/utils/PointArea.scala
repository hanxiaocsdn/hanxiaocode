package utils

/**
 * @Description:获取点的正方形区域
 * @Author: lixiangzhi 01405644
 * @Date: 14:55 2022/12/21
 */
object PointArea {
  def getQuyu(x:Double,y:Double) ={
    val r = 6371  //地球半径千米
    val dis = 0.5  //0.3千米距离
    val latitude = y
    val longitude = x
    var dlng = 2 * math.asin(math.sin(dis / (2 * r)) / math.cos(latitude * math.Pi / 180))
    dlng = dlng * 180 / math.Pi  //角度转为弧度
    var dlat = dis / r
    dlat = dlat * 180 / math.Pi
    val minlat = latitude - dlat
    val maxlat = latitude + dlat
    val minlng = longitude - dlng
    val maxlng = longitude + dlng
    ((minlng,minlat),(maxlng,maxlat))
  }
  //dis单位千米
  def getQuyu50(x:Double,y:Double,dis:Double) ={
    val r = 6371  //地球半径千米
    //val dis = 0.05  //0.5千米距离
    val latitude = y
    val longitude = x
    var dlng = 2 * math.asin(math.sin(dis / (2 * r)) / math.cos(latitude * math.Pi / 180))
    dlng = dlng * 180 / math.Pi  //角度转为弧度
    var dlat = dis / r
    dlat = dlat * 180 / math.Pi
    val minlat = latitude - dlat
    val maxlat = latitude + dlat
    val minlng = longitude - dlng
    val maxlng = longitude + dlng
    ((minlng,minlat),(maxlng,maxlat))
  }

}
