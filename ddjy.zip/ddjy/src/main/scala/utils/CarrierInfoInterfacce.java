package utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.util.*;

/**
 * Description:
 * 需求方：
 * Author: 李相志 01405644
 * Date: 12:37 2023/9/7
 * 任务信息：
 */
public class CarrierInfoInterfacce {
    public static JSONObject getCarrierInfo(JSONObject obj) throws Exception {
        String url = "https://dvopenapi.sense-map.cn/openapi/proxy/car/info/get";
        String plateNo = obj.getString("car_no");
        int plateColor = obj.getIntValue("car_plate_color");
        Map<String, Object> params = new HashMap<>();
        params.put("plateNo", plateNo);
        params.put("plateColor", plateColor);
        params.put("appId", "GIS-RSS-DDJY");
        params.put("timestamp", new Date().getTime());
        String computeSign = Md5SignUtil.signRequest(params, "TjVTNHdhTndtLmV0anFFRkxrZmQ5RGlPYWNyRmMw");
        params.put("sign", computeSign);
        String res = doPostForm(url, params);
        return JSON.parseObject(res);
    }
    public static String doPostForm(String url, Map<String, Object> map) throws Exception {
        String result = "";
        CloseableHttpResponse response;
        RequestConfig defaultRequestConfig = RequestConfig.custom().setSocketTimeout(550000).setConnectTimeout(550000)
                .setConnectionRequestTimeout(550000).setStaleConnectionCheckEnabled(true).build();
        CloseableHttpClient client = HttpClients.custom().setDefaultRequestConfig(defaultRequestConfig).build();
        // client = HttpClients.createDefault();
        URIBuilder uriBuilder = new URIBuilder(url);

        HttpPost httpPost = new HttpPost(uriBuilder.build());
        httpPost.setHeader("Connection", "Keep-Alive");
        httpPost.setHeader("Charset", "UTF-8");
        httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded");
        Iterator<Map.Entry<String, Object>> it = map.entrySet().iterator();
        List<NameValuePair> params = new ArrayList<>();

        while (it.hasNext()) {
            Map.Entry<String, Object> entry = it.next();
            NameValuePair pair = new BasicNameValuePair(entry.getKey(), entry.getValue().toString());
            params.add(pair);
        }

        httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
        try {
            response = client.execute(httpPost);
            if (response != null) {
                HttpEntity resEntity = response.getEntity();
                if (resEntity != null) {
                    result = EntityUtils.toString(resEntity, "UTF-8");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("创建连接失败" + e);
        }

        return result;
    }


}
