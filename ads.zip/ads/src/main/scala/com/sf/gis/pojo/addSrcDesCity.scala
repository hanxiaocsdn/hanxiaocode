package com.sf.gis.pojo

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 11:34 2022/7/26
 */
case class addSrcDesCity(
                          province: String,
                          province_adcode: String,
                          city_name: String,
                          city_code: String,
                          city_adcode: String,
                          aoi: String,
                          un: String,
                          lng: String,
                          lat: String,
                          sp: Double,
                          tm: String,
                          ak: String,
                          rpt_cnt: Int,
                          key_gh: String,
                          key05: String,
                          dis2oil: Double,
                          oil: String,
                          oil_lng: String,
                          oil_lat: String,
                          tm_in_oil: String,
                          src_dest_city_name: String,
                          pass_city_name:String
                        )
