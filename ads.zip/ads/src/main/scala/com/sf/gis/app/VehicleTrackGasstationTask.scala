package com.sf.gis.app

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.pojo.addSrcDesCity
import com.sf.gis.scala.base.spark.{Spark, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 14:46 2022/7/22
 */
object VehicleTrackGasstationTask {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readSourceData(spark: SparkSession, start_day: String,end_day:String) = {
    /*val taskDetailDf: DataFrame = spark.read
      .option("inferschema", "false")
      .option("header", "true")
      .option("encoding", "UTF-8")
      .csv("d:\\user\\01405644\\桌面\\货车加油站\\grd_new_task_detail.csv")
    taskDetailDf.createOrReplaceTempView("taskDetailTmp")
    taskDetailDf.printSchema()
    val coTrackOilDf: DataFrame = spark.read
      .option("inferschema", "false")
      .option("header", "true")
      .option("encoding", "UTF-8")
      .csv("d:\\user\\01405644\\桌面\\货车加油站\\co_track_oil.csv")
    coTrackOilDf.createOrReplaceTempView("coTrackOilTmp")
    coTrackOilDf.printSchema()*/
    val task_start_day: String = DateUtil.getDayBefore(start_day, "yyyyMMdd", 3)
    val sourceSql=
      s"""
        |select
        |province,province_adcode,city_name,city_code,city_adcode,aoi,un,lng,lat,sp,tm,ak,rpt_cnt,key_gh,key05,dis2oil,oil,oil_lng,oil_lat,tm_in_oil,tm_new,
        |t2.actual_depart_tm,
        |concat(t2.src_city_name,'-',t2.dest_city_name) as src_dest_city_name,
        |concat(tm_new,'-',t1.city_name) as pass_city_name
        |from
        |(
        | select
        | *,substring(tm,0,10) as tm_new
        | from
        | --coTrackOilTmp
        | dm_gis.co_track_oil
        | where inc_day>='$start_day'
        | and inc_day<='$end_day'
        |) t1
        |left join
        |(
        | select
        | vehicle_serial,unix_timestamp(actual_depart_tm) as actual_depart_tm,unix_timestamp(actual_arrive_tm) as actual_arrive_tm,src_city_name,dest_city_name
        | from
        | --taskDetailTmp
        | dm_grd.grd_new_task_detail
        | where inc_day>='$task_start_day'
        | and inc_day<='$end_day'
        | and actual_depart_tm!=''
        | and actual_arrive_tm!=''
        | group by vehicle_serial,actual_depart_tm,actual_arrive_tm,src_city_name,dest_city_name
        |) t2
        |on t1.un=t2.vehicle_serial and t1.tm_new=t2.actual_depart_tm
        |""".stripMargin
    val sourceDf: DataFrame = spark.sql(sourceSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("轨迹和任务明细数据关联后数据量:"+sourceDf.count())
    import spark.implicits._
    val passCityNameRdd: RDD[(String, ArrayBuffer[String])] = sourceDf.rdd
      .map(obj=>(obj.getString(6),obj.getString(23)))
      .groupBy(obj => obj._1)
      .map(obj => {
        val row_array: Array[(String, String)] = obj._2.toArray
        val pass_city_array = new ArrayBuffer[String]()
        for (i <- row_array.indices) {
          val pass_city_name: String = row_array(i)._2
          pass_city_array.append(pass_city_name)
        }
        (obj._1, pass_city_array)
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //passCityNameRdd.take(10).foreach(println(_))
    logger.error("将经过城市按照车辆分组聚合数据量："+passCityNameRdd.count())
    //passCityNameRdd.take(10).foreach(println(_))
    val sourceLeftRdd: RDD[(String, JSONObject)] = SparkUtils.getDfToJson(spark, sourceDf).map(obj => {
      val un: String = obj.getString("un")
      (un, obj)
    })
    val passCityNameJoinDf: DataFrame = sourceLeftRdd.leftOuterJoin(passCityNameRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: ArrayBuffer[String] = obj._2._2.getOrElse(new ArrayBuffer[String]()).sorted
      val pass_city_name_buffer: ArrayBuffer[String] = new ArrayBuffer[String]()
      if (rightObj.nonEmpty){
        for (i <- rightObj.indices) {
          val tm_city_name: Array[String] = rightObj(i).split("-")
          if (tm_city_name.length==2){
            val city_name: String = tm_city_name(1)
            if (!pass_city_name_buffer.contains(city_name)) {
              pass_city_name_buffer.append(city_name)
            }
          }
        }
      }
      val pass_city_name: String = pass_city_name_buffer.mkString("-")
      addSrcDesCity(
        leftObj.getString("province"),
        leftObj.getString("province_adcode"),
        leftObj.getString("city_name"),
        leftObj.getString("city_code"),
        leftObj.getString("city_adcode"),
        leftObj.getString("aoi"),
        leftObj.getString("un"),
        leftObj.getString("lng"),
        leftObj.getString("lat"),
        leftObj.getDouble("sp"),
        leftObj.getString("tm"),
        leftObj.getString("ak"),
        leftObj.getIntValue("rpt_cnt"),
        leftObj.getString("key_gh"),
        leftObj.getString("key05"),
        JSONUtil.getJsonDouble(leftObj,"dis2oil",0.0),
        JSONUtil.getJsonVal(leftObj,"oil",""),
        JSONUtil.getJsonVal(leftObj,"oil_lng",""),
        JSONUtil.getJsonVal(leftObj,"oil_lat",""),
        JSONUtil.getJsonVal(leftObj,"tm_in_oil",""),
        JSONUtil.getJsonVal(leftObj,"src_dest_city_name",""),
        pass_city_name
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加经过城市字段数据量："+passCityNameJoinDf.count())
    //passCityNameJoinDf.show(10)
    val groupByUnRdd: RDD[(String, List[JSONObject])] = SparkUtils.getDfToJson(spark, passCityNameJoinDf).groupBy(obj => obj.getString("un")).map(obj => {
      (obj._1, obj._2.toList.sortBy(obj => (obj.getString("un"), obj.getString("tm"))))
    })
    sourceDf.unpersist()
    //groupByUnRdd.filter(obj=>{obj._1=="粤ADX918"}).take(1).foreach(println(_))
    //println("==============================")
    val addSrcDesCityRdd: RDD[JSONObject] = groupByUnRdd.flatMap(obj => {
      val sourceList: Array[JSONObject] = obj._2.toArray
      for (i <- sourceList.indices) {
        if (i!=0){
          val jsnObj_i: JSONObject = sourceList(i-1)
          val src_dest_city_name_i: String = jsnObj_i.getString("src_dest_city_name")
          val jsnObj_i1: JSONObject = sourceList(i)
          var src_dest_city_name_i1: String = jsnObj_i1.getString("src_dest_city_name")
          if (StringUtils.isNoneEmpty(src_dest_city_name_i) && StringUtils.isEmpty(src_dest_city_name_i1)) {
            src_dest_city_name_i1 = src_dest_city_name_i
          }
          jsnObj_i1.put("src_dest_city_name",src_dest_city_name_i1)
          sourceList.update(i,jsnObj_i1)
        }
      }
      sourceList
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("添加始发站目的站字段数据量："+addSrcDesCityRdd.count())
    addSrcDesCityRdd.take(10).foreach(println(_))
    val nearGasStationTrajectoryRDD: RDD[JSONObject] = addSrcDesCityRdd.filter(obj => {
      val oil: String = JSONUtil.getJsonVal(obj, "oil", "")
      val dis2oil: Double = JSONUtil.getJsonDouble(obj, "dis2oil", 0.0)
      oil != "" && dis2oil < 100
    }).map(obj=>{
      val tm: String = JSONUtil.getJsonVal(obj, "tm", "")
      val tmArray: Array[String] = tm.split("_")
      obj.put("tmArray",tmArray)
      obj
    })
    import spark.implicits._
    val addSrcDesCityDf: DataFrame = nearGasStationTrajectoryRDD.map(obj => {
      val province: String = JSONUtil.getJsonVal(obj, "province", "")
      val province_adcode: String = JSONUtil.getJsonVal(obj, "province_adcode", "")
      val city_name: String = JSONUtil.getJsonVal(obj, "city_name", "")
      val city_code: String = JSONUtil.getJsonVal(obj, "city_code", "")
      val city_adcode: String = JSONUtil.getJsonVal(obj, "city_adcode", "")
      val aoi: String = JSONUtil.getJsonVal(obj, "aoi", "")
      val un: String = JSONUtil.getJsonVal(obj, "un", "")
      val lng: String = JSONUtil.getJsonVal(obj, "lng", "")
      val lat: String = JSONUtil.getJsonVal(obj, "lat", "")
      val sp: Double = JSONUtil.getJsonDouble(obj, "sp", 0.0)
      val tm: String = JSONUtil.getJsonVal(obj, "tm", "")
      val ak: String = JSONUtil.getJsonVal(obj, "ak", "")
      val rpt_cnt: Int = JSONUtil.getJsonValInt(obj, "rpt_cnt", 0)
      val key_gh: String = JSONUtil.getJsonVal(obj, "key_gh", "")
      val key05: String = JSONUtil.getJsonVal(obj, "key05", "")
      val dis2oil: Double = JSONUtil.getJsonDouble(obj, "dis2oil", 0.0)
      val oil: String = JSONUtil.getJsonVal(obj, "oil", "")
      val oil_lng: String = JSONUtil.getJsonVal(obj, "oil_lng", "")
      val oil_lat: String = JSONUtil.getJsonVal(obj, "oil_lat", "")
      val tm_in_oil: String = JSONUtil.getJsonVal(obj, "tm_in_oil", "")
      val src_dest_city_name: String = JSONUtil.getJsonVal(obj, "src_dest_city_name", "")
      val pass_city_name: String = JSONUtil.getJsonVal(obj, "pass_city_name", "")
      addSrcDesCity(province, province_adcode, city_name, city_code, city_adcode, aoi, un, lng, lat, sp, tm, ak, rpt_cnt, key_gh, key05, dis2oil, oil, oil_lng, oil_lat, tm_in_oil, src_dest_city_name,pass_city_name)
    }).toDF()
    addSrcDesCityDf.createOrReplaceTempView("addSrcDesCityTmp")
    val addSrcDesCitySql=
      """
        |select
        |province, province_adcode, city_name, city_code, city_adcode, aoi, un,ak,key_gh, key05,oil, oil_lng, oil_lat,src_dest_city_name,
        |collect_set(concat(lng,'_',lat)) as lng_lat,
        |collect_set(sp) as sp,
        |collect_set(tm) as tm,
        |sum(rpt_cnt) as rpt_cnt,
        |collect_set(dis2oil) as dis2oil,
        |pass_city_name
        |from addSrcDesCityTmp
        |group by province, province_adcode, city_name, city_code, city_adcode, aoi, un,ak,key_gh, key05,oil, oil_lng, oil_lat,src_dest_city_name,pass_city_name
        |""".stripMargin
    val addSrcDesCityAggDf: DataFrame = spark.sql(addSrcDesCitySql)
    //addSrcDesCityAggDf.show(100)
    val nearGasStationTrajectoryAggRdd: RDD[Row] = addSrcDesCityAggDf.rdd.map(obj => {
      val lng_lat: String = obj.getAs[Iterator[String]](14).mkString("|")
      val min_sp: Double = obj.getAs[Iterator[Double]](15).min
      val max_sp: Double = obj.getAs[Iterator[Double]](15).max
      var sp_tag = ""
      if (min_sp == 0.0) {
        sp_tag = "1"
      }
      val min_max_sp = min_sp + "_" + max_sp
      val tmArray: Array[String] = obj.getAs[Iterator[String]](16).toArray
      var tm_set: Set[String] = Set()
      for (i <- tmArray.indices) {
        val tm: String = tmArray(i)
        val tm_arr: Array[String] = tm.split("_")
        tm_set ++= tm_arr
      }
      val min_tm: String = tm_set.min
      val max_tm: String = tm_set.max
      val diff_tm: Long =max_tm.toLong-min_tm.toLong
      var oil_tag=""
      if (diff_tm>300 && sp_tag=="1" && StringUtils.isNoneEmpty(obj.getString(13))){
        oil_tag="有加油"
      }
      val min_max_tm = min_tm + "_" + max_tm
      val min_disOil: Double = obj.getAs[Iterator[Double]](18).min
      val max_disOil: Double = obj.getAs[Iterator[Double]](18).max
      val min_max_disOil = min_disOil + "_" + max_disOil
      val tm: String = tmArray.mkString("|")
      Row(obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4), obj.getString(5), obj.getString(6), obj.getString(7), obj.getString(8), obj.getString(9), obj.getString(10),
        obj.getString(11), obj.getString(12), obj.getString(13),obj.getString(19), lng_lat, min_max_sp, sp_tag, min_max_tm, obj.getLong(17).toString, min_max_disOil,oil_tag,tm,diff_tm.toString)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("距离加油站少于100m的车辆轨迹压缩后数据量:"+nearGasStationTrajectoryAggRdd.count())
    val noNearGasStationTrajectoryRdd: RDD[Row] = addSrcDesCityRdd.filter(obj => {
      val oil: String = JSONUtil.getJsonVal(obj, "oil", "")
      val dis2oil: Double = JSONUtil.getJsonDouble(obj, "dis2oil", 0.0)
      oil == "" || dis2oil >= 100
    }).map(obj=>{
      Row(obj.getString("province"), obj.getString("province_adcode"), obj.getString("city_name"), obj.getString("city_code"),
        obj.getString("city_adcode"),obj.getString("aoi"), obj.getString("un"), obj.getString("ak"), obj.getString("key_gh"),
        obj.getString("key05"), obj.getString("oil"), obj.getString("oil_lng"),obj.getString("oil_lat"),
        obj.getString("src_dest_city_name"),obj.getString("pass_city_name"), "","","","",obj.getString("rpt_cnt"),"","",obj.getString("tm"),"")
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("距离加油站大于100m的车辆轨迹数据量:"+noNearGasStationTrajectoryRdd.count())
    addSrcDesCityRdd.unpersist()
    val resultRdd: RDD[Row] = nearGasStationTrajectoryAggRdd.union(noNearGasStationTrajectoryRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    nearGasStationTrajectoryAggRdd.unpersist()
    noNearGasStationTrajectoryRdd.unpersist()
    logger.error("压缩和打标签后的车辆轨迹总数据量："+resultRdd.count())
    resultRdd
  }

  def insertHiveTable(spark: SparkSession, resultRdd: RDD[Row],end_day:String) = {
    import spark.implicits._
    val resultDf: DataFrame = resultRdd.map(obj => {
      CoTrackOilTask(
        obj.getString(0),
        obj.getString(1),
        obj.getString(2),
        obj.getString(3),
        obj.getString(4),
        obj.getString(5),
        obj.getString(6),
        obj.getString(7),
        obj.getString(8),
        obj.getString(9),
        obj.getString(10),
        obj.getString(11),
        obj.getString(12),
        obj.getString(13),
        obj.getString(14),
        obj.getString(15),
        obj.getString(16),
        obj.getString(17),
        obj.getString(18),
        obj.getString(19),
        obj.getString(20),
        obj.getString(21),
        obj.getString(22),
        obj.getString(23)
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("结果数据量："+resultDf.count())
    resultDf.createOrReplaceTempView("resultTmp")
    spark.sql(s"insert overwrite table dm_gis.co_track_oil_task partition(inc_day='$end_day') select * from resultTmp")
  }

  def execute(start_day:String, end_day:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    val resultRdd: RDD[Row] = readSourceData(spark, start_day, end_day)
    insertHiveTable(spark,resultRdd,end_day)
    spark.stop()
  }
  def main(args: Array[String]): Unit = {
    val start_day: String = args(0)
    val end_day: String = args(1)
    execute(start_day,end_day)
    //execute()
    logger.error("======>>>>>>VehicleTrackGasstationTask Execute Ok")
  }
  case class CoTrackOilTask(var province:String,
                            var province_adcode:String,
                            var city_name:String,
                            var city_code:String,
                            var city_adcode:String,
                            var aoi:String,
                            var un:String,
                            var ak:String,
                            var key_gh:String,
                            var key05:String,
                            var oil:String,
                            var oil_lng:String,
                            var oil_lat:String,
                            var src_dest_city_name:String,
                            var pass_city_name:String,
                            var lng_lat:String,
                            var min_max_sp:String,
                            var sp_tag:String,
                            var min_max_tm:String,
                            var rpt_cnt:String,
                            var min_max_disOil:String,
                            var oil_tag:String,
                            var tm:String,
                            var diff_tm:String
                           )
}
