package com.sf.gis.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import com.sf.gis.scala.base.util.JSONUtil;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

public class IpadMapFunction extends RichMapFunction<String,String> {
    private static Logger logger = LoggerFactory.getLogger(IpadMapFunction.class);
    private String mapData(String sourceData) {
        JSONObject resultObj = JSON.parseObject(sourceData);
        JSONObject message = JSONUtil.getJSONObject(resultObj, "message");
        JSONObject message_data = JSONUtil.getJSONObject(message, "data");
        JSONObject result = JSONUtil.getJSONObject(message_data, "result");
        JSONObject query = JSONUtil.getJSONObject(result, "query");
        String opt = JSONUtil.getJsonVal(query, "opt","");
        String type = JSONUtil.getJsonVal(query, "type","");

        String status = JSONUtil.getJsonVal(message_data, "status","");
        JSONObject result_data = JSONUtil.getJSONObject(result, "data");
        String explicit = JSONUtil.getJsonVal(result_data, "explicit","");
        String multi = JSONUtil.getJsonVal(result_data, "multi","");
        String precision = JSONUtil.getJsonVal(result_data, "precision","");
        String level = JSONUtil.getJsonVal(result_data, "level","");
        String match_level = JSONUtil.getJsonVal(result_data, "match_level","");
        String level_name = JSONUtil.getJsonVal(result_data, "level_name","");
        String max_level = JSONUtil.getJsonVal(result_data, "max_level","");
        String sn = JSONUtil.getJsonVal(message, "sn","");
        String time = JSONUtil.getJsonVal(message, "time","");
        JSONObject message_url = JSONUtil.getJSONObject(message, "url");
        String citycode = JSONUtil.getJsonVal(message_url, "citycode","");
        String province = JSONUtil.getJsonVal(message_url, "province","");
        String city = JSONUtil.getJsonVal(message_url, "city","");
        String county = JSONUtil.getJsonVal(message_url, "county","");
        String town = JSONUtil.getJsonVal(message_url, "town","");
        String address = JSONUtil.getJsonVal(message_url, "address","").replaceAll("\n", "").replaceAll("\r","").replaceAll("\001", "").replaceAll("\r\n", "");
        String remoteIp = JSONUtil.getJsonVal(message_url, "remoteIp","");
        String createTime = JSONUtil.getJsonVal(message_url, "createTime","");
        String url = JSONUtil.getJsonVal(message_url, "url","").replaceAll("\n", "").replaceAll("\r","").replaceAll("\001", "").replaceAll("\r\n", "");
        String dateTime = JSONUtil.getJsonVal(message, "dateTime","");
        String message_type = JSONUtil.getJsonVal(message, "type","");
        String log = sourceData.replaceAll("\n", "").replaceAll("\r","").replaceAll("\001", "").replaceAll("\r\n", "");

        ArrayList<String> res = new ArrayList<>();
        res.add(message_type);
        res.add(url);
        res.add(opt);
        res.add(type);
        res.add(citycode);
        res.add(province);
        res.add(city);
        res.add(county);
        res.add(town);
        res.add(address);
        res.add(status);
        res.add(explicit);
        res.add(multi);
        res.add(precision);
        res.add(level);
        res.add(match_level);
        res.add(level_name);
        res.add(max_level);
        res.add(sn);
        res.add(time);
        res.add(remoteIp);
        res.add(createTime);
        res.add(dateTime);
        res.add(log);
        String res_message = String.join("\001", res);
        return res_message;
    }

    @Override
    public String map(String sourceData) {
        if(sourceData==null){
            return null;
        }
        String ret = null;
        ret = mapData(sourceData);
        return ret;
    }
}
