package com.sf.gis.app;

import org.apache.flink.api.common.functions.RichFilterFunction;

public class IpadFilterFunction extends RichFilterFunction<String> {
    @Override
    public boolean filter(String res) {
        String[] resArray = res.split("\001");
        String message_type = resArray[0];
        String url = resArray[1];
        if (!message_type.equals("url_e") || !url.contains("/iad/api?")){
            return false;
        }
        return true;
    }

}
