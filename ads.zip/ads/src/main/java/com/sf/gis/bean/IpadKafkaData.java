package com.sf.gis.bean;

import com.alibaba.fastjson.JSONObject;

/**
 * @Description:
 * @Author: lixiangzhi 01405644
 * @Date: 14:52 2022/7/14
 */
public class IpadKafkaData {
    private JSONObject message;

    public JSONObject getMessage() {
        return message;
    }

    public void setMessage(JSONObject message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "IpadKafkaData{" +
                "message=" + message +
                '}';
    }
}
