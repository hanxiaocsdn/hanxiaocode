package app.runLimitedV2

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.GetDFCountAndSampleData
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable.ListBuffer

/**
  * 合并 纠偏 和 规划 的闯行数据，为效果对比做准备
  */
object MergeLimitedDataFromPlanAndJP {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")

    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        // 获取规划的闯行数据
        val planSql: String =
            s"""
               |select
               |--相同的字段
               |uuid,task_id,start_dept,end_dept,his_coords,start_type,end_type,start_tm,end_tm,actual_run_time,plan_run_time,sort_num,start_longitude,end_longitude,start_latitude,end_latitude,line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,id,is_stop,ground_task_id,start_time,carrier_type,plf_flag,log_dist,line_distance,vehicle_serial2,hko_vehicle_code,trailer_vehicle_code,source,is_trailer,vehicle_type,vehicle_length,width,height,color,energy,license,emission,axls_number,vehicle_full_load_weight,vehicle_load_weight,line,xy,order,grp0,grp1,grp2,plandate,grp2_order,data_source,flag,status,rdist,rtime,rhighway,rtralightcount,rtolls,rtollsdistance,qstartxy,qendxy,rcoords,rsteps,rflen,rtlen,rulecount,ruleorder,ruleid,ruletype,rulepos,ruleroadid,ruleoutroadid,ruleroadname,limitweight,limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,limitvehicletype,limitoutflag,limitemitstand,limittailchar,limitstartdate,limitenddate,limitweek,limittime,guid,ruletimedesc,ruleregiondesc,rulevehicle,rulestrategy,coords,
               |--没有有的字段
               |'' as uuid2,
               |'' as his_abnormal,
               |'' as abnormal,
               |'' as jp_swid,
               |'' as jp_status,
               |--独有的字段
               |d_url,d_status,d_dist,d_time,d_tolls,d_src,d_flen,d_tlen,d_plan_order,d_query,d_highway,d_tralightcount,d_frequency,d_frequencycost,d_frequencytype,d_freqratio,d_route_id,d_src_routeids,
               |v,city,version,inc_day
               |from
               |  dm_gis.mms_car_route_plan_detail_and_limited_info_v2
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        val jpSql: String =
            s"""
               |select
               |--相同的字段
               |uuid,task_id,start_dept,end_dept,his_coords,start_type,end_type,start_tm,end_tm,actual_run_time,plan_run_time,sort_num,start_longitude,end_longitude,start_latitude,end_latitude,line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,id,is_stop,ground_task_id,start_time,carrier_type,plf_flag,log_dist,line_distance,vehicle_serial2,hko_vehicle_code,trailer_vehicle_code,source,is_trailer,vehicle_type,vehicle_length,width,height,color,energy,license,emission,axls_number,vehicle_full_load_weight,vehicle_load_weight,line,xy,order,grp0,grp1,grp2,plandate,grp2_order,data_source,flag,status,rdist,rtime,rhighway,rtralightcount,rtolls,rtollsdistance,qstartxy,qendxy,rcoords,rsteps,rflen,rtlen,rulecount,ruleorder,ruleid,ruletype,rulepos,ruleroadid,ruleoutroadid,ruleroadname,limitweight,limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,limitvehicletype,limitoutflag,limitemitstand,limittailchar,limitstartdate,limitenddate,limitweek,limittime,guid,ruletimedesc,ruleregiondesc,rulevehicle,rulestrategy,coords,
               |--独有的字段
               |uuid2,his_abnormal,abnormal,jp_swid,jp_status,
               |--添加没有的字段
               |'' as d_url,
               |'' as d_status,
               |'' as d_dist,
               |'' as d_time,
               |'' as d_tolls,
               |'' as d_src,
               |'' as d_flen,
               |'' as d_tlen,
               |0 as d_plan_order,
               |'' as d_query,
               |'' as d_highway,
               |'' as d_tralightcount,
               |'' as d_frequency,
               |'' as d_frequencycost,
               |'' as d_frequencytype,
               |'' as d_freqratio,
               |'' as d_route_id,
               |'' as d_src_routeids,
               |v,city,version,inc_day
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info_v2
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(planSql)
        logger.error(jpSql)

        val planDF: DataFrame = spark.sql(planSql)
        val jpDF: DataFrame = spark.sql(jpSql)

        logger.error("合并纠偏的闯行数据 和 规划的闯行数据")
        val limitedDF: Dataset[Row] = planDF
          .union(jpDF)
          .filter("ruleid is not null and ruleid != ''")
          .filter("limitsize is null or limitsize = '' or cast(limitsize as double) <= 4.2")
          .dropDuplicates(Seq("uuid", "data_source", "d_plan_order", "v"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 所有的闯行数据
        GetDFCountAndSampleData(logger, limitedDF, "纠偏的闯行数据 和 规划的闯行数据 合并过滤之后的数据")


        val adcodeAndPlineDF: DataFrame = limitedDF
          .repartition(20)
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val data_source: String = r.getAs[String]("data_source")
              val d_plan_order: Int = r.getAs[Int]("d_plan_order")
              val rulepos: String = r.getAs[String]("rulepos")
              val ruleroadid: String = r.getAs[String]("ruleroadid")
              val city: String = r.getAs[String]("city")
              val version: String = r.getAs[String]("version")
              val v: String = r.getAs[String]("v")
              val inc_day: String = r.getAs[String]("inc_day")
              var adcode: String = ""
              var pline: String = ""

              if (ruleroadid != null && ruleroadid.nonEmpty) {
                  val json: JSONObject = call_match_service(ruleroadid)
                  val tp: (String, String) = get_match_abnormal_data(json)
                  adcode = tp._1
                  pline = tp._2
              }
              (uuid, data_source, d_plan_order, rulepos, adcode,pline, city, version, v, inc_day)
          })
          .toDF("uuid", "data_source", "d_plan_order", "rulepos", "adcode","pline", "city", "version", "v", "inc_day")
          .filter("adcode != ''")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger,adcodeAndPlineDF,"获得的adcode 和 pline ")

        //  关联上原始数据
        val allLimitedAndAdcodePlineDF: DataFrame = limitedDF
          .drop("city", "version", "inc_day")
          .join(adcodeAndPlineDF, Seq("uuid", "data_source", "d_plan_order", "rulepos", "v"))

        GetDFCountAndSampleData(logger,allLimitedAndAdcodePlineDF,"最终的数据")


        logger.error("合并后的闯行数据写入hive：dm_gis.mms_car_route_plan_and_jp_limited_result_info_v2")
        allLimitedAndAdcodePlineDF
          .write
          .mode(SaveMode.Overwrite)
          .insertInto("dm_gis.mms_car_route_plan_and_jp_limited_result_info_v2")


        limitedDF.unpersist()

        logger.error("运行结束")

        // 关闭spark
        spark.stop()


    }


    // 调用 匹配的接口，获取对应的数据
    def call_match_service(ruleroadid: String): JSONObject = {
        val sw_id: String = ruleroadid
        val date: String = ""

        val parm: String = s"date=$date&sw_id=$sw_id&test=1&stype=0&etype=0&passport=100000&mode=2&speed=1&Toll=1"
        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonStr: String = mapData.get("content").toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:"+e.getMessage)
        }

        json
    }

    // 解析 匹配接口返回的json数据
    def get_match_abnormal_data(json: JSONObject): (String, String) = {
        var adcode: String = ""
        var pline: String = ""
        val polylineList: ListBuffer[String] = new ListBuffer[String]

        if(json != null){
            val status: String = json.getString("status")
            if (status == "0") {
                val route: JSONObject = json.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")
                if (paths != null && paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val path: JSONObject = paths.getJSONObject(i)

                        val polyline: String = path.getString("polyline")
                        polylineList.append(polyline)

                        val steps: JSONArray = path.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            for (j <- 0 until steps.size()) {
                                val step: JSONObject = steps.getJSONObject(j)
                                if (step != null && step.size() > 0) {
                                    val links: JSONArray = step.getJSONArray("links")
                                    if (links != null && links.size() > 0) {
                                        val link: JSONObject = links.getJSONObject(0)
                                        adcode = link.getString("adcode")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (polylineList != null && polylineList.nonEmpty) pline = polylineList.mkString(";")
        (adcode, pline)
    }

}
