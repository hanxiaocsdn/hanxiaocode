package app.runLimitedV2

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.RunTrafficControlDataFromInterV2
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, Dataset, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getVersion}
import utils.HttpClientUtil.getJsonByGet2
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable.ListBuffer

/**
  * 获取纠偏的闯行数据
  */
object GetLimitedDataForJP {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url1: String = config.getString("qm_url")
    val qm_url2: String = config.getString("qm_url2")
    val version_url1: String = config.getString("version_url")
    val version_url2: String = config.getString("version_url2")


    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        if (args.length != 3) {
            logger.error(
                """
                  |需要输入3个参数：
                  |    start_time、end_time、flag
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val flag: String = args(2)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"flag:$flag")

        var qm_url:String =""
        var version_url:String =""
        if(flag == "1"){
            qm_url = qm_url1
            version_url =version_url1
        } else {
            qm_url = qm_url2
            version_url =version_url2
        }


        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        // 获取纠偏的数据 his_abnormal 、abnormal
        val jpsql1: String =
            s"""
               |select
               |  *
               |from
               |(select
               |  t1.*,
               |  t2.his_abnormal,
               |  t3.abnormal,
               |  '0' data_source
               |from
               |  (select t.*,concat(task_id,'_',start_dept,'_',end_dept) uuid,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.mms_car_locus_task_detail_para_plan_info t where inc_day >= '$start_time' and inc_day < '$end_time') t1
               |join
               |  (select t.*,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_his_traj_ab_info t where t.his_abnormal != '-1' and inc_day >= '$start_time' and inc_day < '$end_time' ) t2
               |on t1.uuid2 = t2.uuid2
               |join
               |  (select t.*, concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_traj_simgroup_info t where !(t.abnormal regexp '4|5') and inc_day >= '$start_time' and inc_day < '$end_time' ) t3
               |on t1.uuid2 = t3.uuid2
               |) t
               |""".stripMargin

        //获取纠偏的数据 coords 、jp_swid、jp_status
        val dlr = '$'
        val jpsql2: String =
            s"""
               |select
               |  info
               |from
               |  dm_gis.eta_traj_info t
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and get_json_object(info, '$dlr.carrier_type') = 0
               |""".stripMargin

        logger.error(jpsql1)
        logger.error(jpsql2)

        val df1: DataFrame = spark.sql(jpsql1)
        val df2: DataFrame = spark
          .sql(jpsql2)
          .rdd
          .map(r => {
              val info: String = r.getAs[String]("info")
              val jsonObj: JSONObject = JSON.parseObject(info)

              val task_id: String = jsonObj.getString("task_id")
              val start_dept: String = jsonObj.getString("start_dept")
              val end_dept: String = jsonObj.getString("end_dept")
              val uuid2: String = task_id + start_dept + end_dept

              val jp_swid_tmp: String = jsonObj.getString("jp_swid")
              val coords_tmp: String = jsonObj.getString("rt_coords")
              val jp_status_tmp: String = jsonObj.getString("status")

              var coords = ""
              var jp_swid = ""
              var jp_status = ""
              if (jp_swid_tmp != null && jp_swid_tmp.nonEmpty && coords_tmp != null && coords_tmp.nonEmpty && jp_status_tmp != null && jp_status_tmp.nonEmpty) {
                  coords = coords_tmp.replaceAll("\"", "")
                    .replaceAll("\\[", "")
                    .replaceAll("],", "|")
                    .replaceAll("]", "")

                  jp_swid = jp_swid_tmp
                    .replaceAll("\\[", "")
                    .replaceAll("]", "")

                  jp_status = jp_status_tmp
                    .replaceAll("\\[", "")
                    .replaceAll("]", "")
              }

              (uuid2, coords, jp_swid, jp_status)
          })
          .toDF("uuid2", "coords", "jp_swid", "jp_status")
          .filter("coords !=''")

        val xmlStr: String = getJsonByGet2(version_url, 6, "utf-8")
        val version: String = getVersion(xmlStr)

        val origJPDataDF: DataFrame = df1
          .join(df2, Seq("uuid2"))
          .withColumn("version", lit(version))
          .withColumn("incday",$"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday","inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)


        // 跑路径规划数据信息： -- 纠偏的数据源
        GetDFCountAndSampleData(logger, origJPDataDF, "【纠偏的数据源】用于跑闯行的数据")
        if(flag=="1") df2HiveByOverwrite(logger,origJPDataDF,"dm_gis.mms_car_route_jp_detail_info_v2")


        // 跑闯行服务，获取相应的数据，并对数据做解析
        val RunTrafficContrDataFromInterJPDS: Dataset[RunTrafficControlDataFromInterV2] = origJPDataDF
          .repartition(20)
          .flatMap(r => {
              val (uuid, data_source, d_plan_order, jsonData) = call_limited_route(r,qm_url)
              val listBuf: ListBuffer[RunTrafficControlDataFromInterV2] = parse_limited_data(uuid, data_source, d_plan_order, jsonData)
              listBuf
          })
          .persist(StorageLevel.MEMORY_AND_DISK)

        logger.error(s"【纠偏的数据源】结果数据总量：${RunTrafficContrDataFromInterJPDS.count()} 条")
        logger.error(s"【纠偏的数据源】从接口获取到的数据，处理过后的样例数据：")
        RunTrafficContrDataFromInterJPDS.take(2).foreach(r => logger.error(r.toString))

        // 接口解析出的数据  和  原始数据关联上  --纠偏的数据
        val ResultRunTrafficContrDataFromInterJPDF: DataFrame = origJPDataDF
          .drop("data_source")
          .join(RunTrafficContrDataFromInterJPDS, "uuid")
          .withColumn("v",lit(flag))
          .select("uuid", "task_id", "start_dept", "end_dept", "his_coords", "start_type", "end_type",
              "start_tm", "end_tm", "actual_run_time", "plan_run_time", "sort_num", "start_longitude",
              "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code",
              "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id",
              "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2",
              "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type", "vehicle_length",
              "width", "height", "color", "energy", "license", "emission", "axls_number", "vehicle_full_load_weight",
              "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2", "plandate", "grp2_order",
              "uuid2", "his_abnormal", "abnormal", "coords", "jp_swid", "jp_status", "data_source", "flag", "status",
              "rdist", "rtime", "rhighway", "rtralightcount", "rtolls", "rtollsdistance", "qstartxy", "qendxy",
              "rcoords", "rsteps", "rflen", "rtlen", "rulecount", "ruleorder", "ruleid", "ruletype", "rulepos",
              "ruleroadid", "ruleoutroadid", "ruleroadname", "limitweight", "limitsize", "limitwidth", "limitaxload",
              "limitload", "limitaxcnt", "limitpassport", "limitholiday", "limitvehicletype", "limitoutflag",
              "limitemitstand", "limittailchar", "limitstartdate", "limitenddate", "limitweek", "limittime",
              "guid", "ruletimedesc", "ruleregiondesc", "rulevehicle", "rulestrategy", "city", "version", "v","inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        logger.error(s"【纠偏的数据源】最终的结果数据总量：${ResultRunTrafficContrDataFromInterJPDF.count()} 条")
        logger.error("【纠偏的数据源】最终的结果数据样例：")
        ResultRunTrafficContrDataFromInterJPDF.take(2).foreach(r => logger.error(r.toString))

        // 释放缓存
        origJPDataDF.unpersist()
        RunTrafficContrDataFromInterJPDS.unpersist()

        // 对闯行的数据写入hive表   -- 纠偏的数据
        logger.error("【闯行的数据】开始写入到hive表：dm_gis.mms_car_route_jp_detail_and_limited_info_v2")
        ResultRunTrafficContrDataFromInterJPDF
          .filter("flag==true")
          .write
          .mode(SaveMode.Overwrite)
          .insertInto("dm_gis.mms_car_route_jp_detail_and_limited_info_v2")

        // 释放缓存
        ResultRunTrafficContrDataFromInterJPDF.unpersist()

        logger.error("运行结束！")


        // 程序运行结束
        spark.stop()
    }

    // 调用闯行的接口
    def call_limited_route(r: Row,qm_url:String): (String, String, Int, JSONObject) = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = 0

        var origin: String = ""
        var destination: String = ""
        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
        val coordsArr: Array[String] = coords.split("\\|")
        for (i <- coordsArr.indices) {
            if (i == 0) origin = coordsArr(i)
            if (i == coordsArr.length - 1) destination = coordsArr(i)
        }

        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val emitStand: String = r.getAs[String]("emission")
        val energy: String = r.getAs[String]("energy")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val Mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val width: Double = r.getAs[Double]("width")
        val Size: String = r.getAs[String]("vehicle_length")
        val axlenumber: String = r.getAs[String]("axls_number")
        val No: String = r.getAs[String]("task_id")
        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&origin=$origin&destination=$destination&stype=0&etype=0&plate=$plate" +
          s"&plateColor=$plateColor&emitStand=$emitStand&energy=$energy&weight=$weight&vehicle=$vehicle&Mload=$Mload" +
          s"&height=$height&width=$width&Size=$Size&axlenumber=$axlenumber&passport=100000&mode=2&speed=1&No=$No&Toll=1&date=$date"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonStr: String = mapData.get("content").toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:"+e.getMessage)
        }

        (uuid, data_source, d_plan_order, json)
    }

    // 解析接口返回的json,获取相应的字段值
    def parse_limited_data(uuid: String, data_source: String, d_plan_order: Int, j: JSONObject): ListBuffer[RunTrafficControlDataFromInterV2] = {
        // 存放闯行的数据
        val rules: ListBuffer[RunTrafficControlDataFromInterV2] = new ListBuffer[RunTrafficControlDataFromInterV2]

        if(j != null){
            val status: String = j.getString("status")
            if (status == "0") {
                val route: JSONObject = j.getJSONObject("route")
                val qstartxy: String = route.getString("origin")
                val qendxy: String = route.getString("destination")
                val paths: JSONArray = route.getJSONArray("paths")

                // 判断这个json数据是否闯行，默认false：不闯行
                var flag: Boolean = false
                if (paths.size() > 0) {
                    for (i <- 0 until paths.size() if !flag) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        if (obj.containsKey("voi_rule") && obj.getJSONArray("voi_rule").size() > 0) flag = true
                    }
                }

                // 闯行 与 不闯行 的公共解析字段
                // 开始解析公共字段
                var rdist: Int = 0
                var rtime: Double = 0.0
                var rhighway: Int = 0
                var rtraLightCount: Int = 0
                var rtolls: Int = 0
                var rtollsDistance: Int = 0
                val rcoords_tmp = new ListBuffer[String]
                val rsteps: String = null
                val rulecount: Int = 0
                var rflen: Int = 0
                var rtlen: Int = 0

                if (paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        rdist += obj.getInteger("distance")
                        rtime += obj.getDouble("duration")
                        rhighway += obj.getInteger("highspeed_distance")
                        rtraLightCount += obj.getInteger("trafficlight_count")
                        rtolls += obj.getInteger("tolls")
                        rtollsDistance += obj.getInteger("toll_distance")
                        rcoords_tmp.append(obj.getString("polyline"))

                        if (i == 0) rflen = obj.getInteger("flen")
                        if (i == paths.size() - 1) rtlen = obj.getInteger("tlen")
                    }
                }
                val rcoords: String = rcoords_tmp.mkString(";")
                // 公共字段解析结束


                // 如果未闯行，写入未闯行的表
                if (!flag) {
                    val line: RunTrafficControlDataFromInterV2 = RunTrafficControlDataFromInterV2(uuid, data_source, d_plan_order, flag, status, rdist, rtime, rhighway, rtraLightCount, rtolls,
                        rtollsDistance, qstartxy, qendxy, rcoords, rsteps, rflen, rtlen, rulecount, "", "", "", "", "", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", "", "", "", "", "", "", "", "", "")
                    rules.append(line)
                } else {
                    // 对闯行的数据做处理
                    for (i <- 0 until paths.size()) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        if (obj.containsKey("voi_rule") && obj.getJSONArray("voi_rule").size() > 0) {
                            for (j <- 0 until obj.getJSONArray("voi_rule").size()) {
                                val rule: JSONObject = obj.getJSONArray("voi_rule").getJSONObject(j)
                                val ruleorder: String = j.toString
                                val ruletype: String = rule.getString("type")
                                val rulepos: String = rule.getString("pos")
                                val ruleroadid: String = rule.getString("road_id")
                                val ruleoutroadid: String = rule.getString("out_road_id")
                                val ruleroadname: String = rule.getString("name")

                                val limit: JSONObject = rule.getJSONObject("limit")
                                var ruleid: String = ""
                                var Guid: String = ""
                                var limitweight: String = ""
                                var limitsize: String = ""
                                var limitwidth: String = ""
                                var limitaxload: String = ""
                                var limitload: String = ""
                                var limitaxcnt: String = ""
                                var limitpassport: String = ""
                                var limitholiday: String = ""
                                var limitvehicletype: String = ""
                                var limitoutflag: String = ""
                                var limitemitStand: String = ""
                                var limittailchar: String = ""
                                var limitstartdate: String = ""
                                var limitenddate: String = ""
                                var limitweek: String = ""
                                var limittime: String = ""
                                if (limit != null && limit.size() > 0) {
                                    ruleid = limit.getString("RuleID")
                                    Guid = limit.getString("Guid")
                                    limitweight = limit.getString("限重")
                                    limitsize = limit.getString("限高")
                                    limitwidth = limit.getString("限宽")
                                    limitaxload = limit.getString("限轴重")
                                    limitload = limit.getString("限载重")
                                    limitaxcnt = limit.getString("限轴数")
                                    limitpassport = limit.getString("通行证")
                                    limitholiday = limit.getString("节假日")
                                    limitvehicletype = limit.getString("车辆类型")
                                    limitoutflag = limit.getString("限车辆属地")
                                    limitemitStand = limit.getString("限燃油标号")
                                    limittailchar = limit.getString("限尾号")
                                    limitstartdate = limit.getString("开始日期")
                                    limitenddate = limit.getString("结束日期")
                                    limitweek = limit.getString("限星期")
                                    limittime = limit.getString("限时段")
                                }


                                var ruletimedesc: String = ""
                                var ruleregiondesc: String = ""
                                var rulevehicle: String = ""
                                var rulestrategy: String = ""
                                val region_rule: JSONArray = rule.getJSONArray("region_rule")
                                if (region_rule != null && region_rule.size() > 0) {
                                    ruletimedesc = region_rule.getJSONObject(0).getString("time")
                                    ruleregiondesc = region_rule.getJSONObject(0).getString("region")
                                    rulevehicle = region_rule.getJSONObject(0).getString("vehicle")
                                    rulestrategy = region_rule.getJSONObject(0).getString("strategy")
                                }

                                val line: RunTrafficControlDataFromInterV2 = RunTrafficControlDataFromInterV2(uuid, data_source, d_plan_order, flag, status, rdist, rtime, rhighway, rtraLightCount, rtolls,
                                    rtollsDistance, qstartxy, qendxy, rcoords, rsteps, rflen, rtlen, rulecount, ruleorder, ruleid, ruletype, rulepos, ruleroadid, ruleoutroadid,
                                    ruleroadname, limitweight, limitsize, limitwidth, limitaxload, limitload, limitaxcnt, limitpassport, limitholiday, limitvehicletype,
                                    limitoutflag, limitemitStand, limittailchar, limitstartdate, limitenddate, limitweek, limittime, Guid, ruletimedesc, ruleregiondesc,
                                    rulevehicle, rulestrategy)

                                rules.append(line)
                            }
                        }
                    }
                }

                rules
            }
            else rules
        } else rules


    }


}
