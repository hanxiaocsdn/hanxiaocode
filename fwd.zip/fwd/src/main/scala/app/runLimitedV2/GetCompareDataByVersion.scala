package app.runLimitedV2

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.functions.{concat_ws, lit}
import org.apache.spark.sql.{DataFrame, Dataset, Row,SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getVersion}
import utils.HttpClientUtil.getJsonByGet2
import utils.SparkConfigUtil

import java.sql.{Connection, PreparedStatement}

/**
  * 比对不同版本的数据
  */
object GetCompareDataByVersion {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val version_url1: String = config.getString("version_url")
    val version_url2: String = config.getString("version_url2")

    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useUnicode=true&amp;characterEncoding=utf-8"
    val userName = "gis_oms_pns"
    val passWd = "gis_oms_pns@123@"

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 3) {
            logger.error(
                """
                  |需要输入3个参数：
                  |    start_time、end_time、today
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val today: String = args(2)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"当前日期：$today ")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 导入隐式转换
        import spark.implicits._

        // 获取闯行数据
        val limitedSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_and_jp_limited_result_info_v2
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 获取聚合结果
        val aggSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_and_jp_limited_aggre_result_info_v2
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin
        // 获取核实结果
        val checkSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_aggre_data_checked_result_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 获取纠偏的轨迹数据
        val jpSql: String =
            s"""
               |--获取城市维度信息
               |with t_cityinfo as(
               |select
               |  city,
               |  province_name,
               |  city_name,
               |  area_code
               |from
               |  dm_gis.province_city_info
               |),
               |-- 获取每个城市的纠偏轨迹数据
               |t_jpinfo as(
               |select
               |  substr(start_dept,1,3) city,
               |  count(distinct uuid) all_locus_num
               |from
               |  dm_gis.mms_car_route_jp_detail_info_v2
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |group by
               |  substr(start_dept,1,3)
               |)
               |
               |select
               |  t2.area_code as area_code,
               |  t2.city,
               |  t2.city_name,
               |  t2.province_name,
               |  t1.all_locus_num as all_locus_num
               |from
               |  t_jpinfo t1
               |join
               |  t_cityinfo t2
               |on t1.city = t2.city
               |""".stripMargin

        logger.error(limitedSql)
        logger.error(aggSql)
        logger.error(checkSql)
        logger.error(jpSql)

        val xmlStr1: String = getJsonByGet2(version_url1, 6, "utf-8")
        val xmlStr2: String = getJsonByGet2(version_url2, 6, "utf-8")
        val version1: String = getVersion(xmlStr1)
        val version2: String = getVersion(xmlStr2)

        logger.error(version1)
        logger.error(version2)

        val orglimitedDF: DataFrame = spark.sql(limitedSql)
        val jpDF: DataFrame = spark.sql(jpSql)


        val limitedDF: Dataset[Row] = orglimitedDF
          .filter("ruleid is not null and ruleid != ''")
          .filter("data_source = '0'")
          .filter("limitsize is null or limitsize = '' or cast(limitsize as double) <= 4.2")
          .dropDuplicates(Seq("uuid", "data_source", "d_plan_order","v"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, limitedDF, "纠偏的闯行数据 和 规划的闯行数据 合并过滤之后")

        // 获取区域、单点限行数据
        val areaAndPointDF: DataFrame = limitedDF
          .rdd
          .map(r => {
              val area_code: String = r.getAs[String]("adcode").substring(0, 4)
              val v: String = r.getAs[String]("v")
              val ruleid: Int = r.getAs[String]("ruleid").toInt
              var flag: Int = 1
              if (ruleid >= 100000) flag = 0

              ((area_code, v), flag)
          })
          .groupByKey()
          .map(r => {
              val (area_code, v): (String, String) = r._1
              val flag_iter: Iterable[Int] = r._2

              var area_num: Int = 0
              var point_num: Int = 0
              var limit_num: Int = 0
              for (iter <- flag_iter)
                  if (iter == 1) point_num = point_num + 1 else area_num = area_num + 1

              limit_num = area_num + point_num

              (area_code, v, limit_num, area_num, point_num)
          })
          .toDF("area_code", "v", "limit_num", "area_num", "point_num")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, areaAndPointDF, "每个城市 每个版本 的区域、单点限行")

        // 获取 闯行频次、聚合后数据条数
        val lenAndFreNumDF: DataFrame = orglimitedDF
          .filter("ruleid is not null and ruleid != ''")
          .filter("limitsize is null or limitsize = '' or cast(limitsize as double) <= 4.2")
          .rdd
          .map(r => {
              val area_code: String = r.getAs[String]("adcode").substring(0, 4)
              val v: String = r.getAs[String]("v")
              val ruleid: String = r.getAs[String]("ruleid")
              val rulepos: String = r.getAs[String]("rulepos")
              ((area_code, v, ruleid, rulepos), 1)
          })
          .groupByKey()
          .map(r => {
              val k: (String, String, String, String) = r._1
              val size: Int = r._2.size
              ((k._1, k._2), (1, size))
          })
          .reduceByKey((r1, r2) => (r1._1 + r2._1, r1._2 + r2._2))
          .map(r => (r._1._1, r._1._2, r._2._1, r._2._2))
          .toDF("area_code", "v", "len_num", "fre_num")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, lenAndFreNumDF, "每个城市 每个版本 的聚合后数据条数、闯行频次")

        limitedDF.unpersist()

        // 获取 聚合结果表
        val aggDF: DataFrame = spark.sql(aggSql)

        // 获取 核实结果表
        val checkDF: DataFrame = spark.sql(checkSql).drop("area_code", "city", "version", "inc_day")

        // 每个城市、不同版本 状态为 数据错误 的数量
        val wrongNumDF: DataFrame = aggDF.join(checkDF, Seq("rulepos", "guid"))
          .filter($"work_status" === "数据错误")
          .rdd
          .map(r => {
              val area_code: String = r.getAs[String]("area_code")
              val rulepos: String = r.getAs[String]("rulepos")
              val freqcnt: Int = r.getAs[Int]("freqcnt")
              val guid: String = r.getAs[String]("guid")
              ((area_code, rulepos, guid), (1, freqcnt))
          })
          .reduceByKey((r1, r2) => (r1._1 + r2._1, r1._2))
          .filter(_._2._1 == 2)
          .map(r => {
              val area_code: String = r._1._1
              val freqcnt: Int = r._2._2
              (area_code, (1, freqcnt))
          })
          .reduceByKey((r1, r2) => (r1._1 + r2._1, r1._2 + r2._2))
          .map(r => {
              val area_code: String = r._1
              val (wrong_num, fre_wrong): (Int, Int) = r._2
              (area_code, wrong_num, fre_wrong)
          })
          .toDF("area_code", "wrong_num", "fre_wrong")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, wrongNumDF, "每个城市、不同版本 状态为 数据错误")

        val oldAggDF: Dataset[Row] = aggDF.filter("v = '1'").select("guid", "rulepos")
        val newAggDF: Dataset[Row] = aggDF.filter("v = '2'")

        // 每个城市 新版本 新增的闯行数量 和 频次
        val newLimitedNumDF: DataFrame = newAggDF.join(oldAggDF, Seq("guid", "rulepos"), "left_anti")
          .rdd
          .map(r => {
              val area_code: String = r.getAs[String]("area_code")
              val v: String = r.getAs[String]("v")
              val freqcnt: Int = r.getAs[Int]("freqcnt")
              ((area_code, v), (1, freqcnt))
          })
          .reduceByKey((r1, r2) => (r1._1 + r2._1, r1._2 + r2._2))
          .map(r => {
              val (area_code, v): (String, String) = r._1
              val (not_in_old_num, fre_not_in): (Int, Int) = r._2
              (area_code, v, not_in_old_num, fre_not_in)
          })
          .toDF("area_code", "v", "not_in_old_num", "fre_not_in")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, newLimitedNumDF, "每个城市 新版本 新增的闯行数量 和 频次")


        val DF1: DataFrame = areaAndPointDF
          .join(lenAndFreNumDF, Seq("area_code", "v"), "left")
          .filter("v = '1'")
          .withColumnRenamed("limit_num", "limit_num_v1")
          .withColumnRenamed("point_num", "point_num_v1")
          .withColumnRenamed("area_num", "area_num_v1")
          .withColumnRenamed("fre_num", "fre_num_v1")
          .withColumnRenamed("len_num", "len_num_v1")
          .drop("v")
          .withColumn("version1", lit(version1))

        val DF2: DataFrame = areaAndPointDF
          .join(lenAndFreNumDF, Seq("area_code", "v"), "left")
          .join(wrongNumDF, Seq("area_code"), "left")
          .join(jpDF, Seq("area_code"), "left")
          .filter("v = '2'")
          .join(newLimitedNumDF, Seq("area_code", "v"), "left")
          .withColumnRenamed("limit_num", "limit_num_v2")
          .withColumnRenamed("point_num", "point_num_v2")
          .withColumnRenamed("area_num", "area_num_v2")
          .withColumnRenamed("fre_num", "fre_num_v2")
          .withColumnRenamed("len_num", "len_num_v2")
          .drop("v")
          .withColumn("version2", lit(version2))
          .withColumn("id",concat_ws("_",lit(today),$"area_code"))
          .withColumn("inc_day", lit(today))

        val cityDF: DataFrame = DF1.join(DF2, Seq("area_code"))
          .coalesce(10)
          .na
          .fill(0)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, cityDF, "最终的对比指标")
        areaAndPointDF.unpersist()
        lenAndFreNumDF.unpersist()
        wrongNumDF.unpersist()

        // 最终的指标数据写入hive
        df2HiveByOverwrite(logger,cityDF,"dm_gis.mms_car_locus_version_compara_info")

        // 最终的指标数据写入mysql
        logger.error("最终的对比指标写入MySQL：MMS_CAR_LOCUS_VERSION_COMPARA_INFO")
        compareToMysql(cityDF)
        logger.error("写入MySQL成功!")


        logger.error("运行结束！")

        // 关闭spark
        spark.stop()


    }

    // 讲df写入到MySQL
    def compareToMysql(df: DataFrame): Unit = {
        df.rdd
          .foreachPartition(iter => {
              Class.forName(driver)
              val connection: Connection = java.sql.DriverManager.getConnection(url, userName, passWd)
              iter.foreach(r => {
                  val id: String = r.getAs[String]("id")
                  val inc_day: String = r.getAs[String]("inc_day")
                  val area_code: String = r.getAs[String]("area_code")
                  val city: String = r.getAs[String]("city")
                  val city_name: String = r.getAs[String]("city_name")
                  val  province_name: String = r.getAs[String]("province_name")
                  val  limit_num_v1: Int = r.getAs[Int]("limit_num_v1")
                  val  area_num_v1: Int = r.getAs[Int]("area_num_v1")
                  val  point_num_v1: Int = r.getAs[Int]("point_num_v1")
                  val  len_num_v1: Int = r.getAs[Int]("len_num_v1")
                  val  fre_num_v1: Int = r.getAs[Int]("fre_num_v1")
                  val  version1: String = r.getAs[String]("version1")
                  val  limit_num_v2: Int = r.getAs[Int]("limit_num_v2")
                  val  area_num_v2: Int = r.getAs[Int]("area_num_v2")
                  val  point_num_v2: Int = r.getAs[Int]("point_num_v2")
                  val  len_num_v2: Int = r.getAs[Int]("len_num_v2")
                  val  fre_num_v2: Int = r.getAs[Int]("fre_num_v2")
                  val  wrong_num: Int = r.getAs[Int]("wrong_num")
                  val  fre_wrong: Int = r.getAs[Int]("fre_wrong")
                  val  all_locus_num: Long = r.getAs[Long]("all_locus_num")
                  val  not_in_old_num: Int = r.getAs[Int]("not_in_old_num")
                  val  fre_not_in: Int = r.getAs[Int]("fre_not_in")
                  val  version2: String = r.getAs[String]("version2")


                  val del_sql: String = s"DELETE FROM MMS_CAR_LOCUS_VERSION_COMPARA_INFO WHERE ID =?"
                  val statement0: PreparedStatement = connection.prepareStatement(del_sql)

                  statement0.setString(1, id)
                  statement0.executeUpdate()
                  statement0.close()

                  val insert_sql: String = "INSERT INTO MMS_CAR_LOCUS_VERSION_COMPARA_INFO(" +
                    "ID," +
                    "STATDATE," +
                    "AREA_CODE," +
                    "CITY," +
                    "CITY_NAME," +
                    "PROVINCE_NAME," +
                    "LIMIT_NUM_V1," +
                    "AREA_NUM_V1," +
                    "POINT_NUM_V1," +
                    "LEN_NUM_V1," +
                    "FRE_NUM_V1," +
                    "VERSION1," +
                    "LIMIT_NUM_V2," +
                    "AREA_NUM_V2," +
                    "POINT_NUM_V2," +
                    "LEN_NUM_V2," +
                    "FRE_NUM_V2," +
                    "WRONG_NUM," +
                    "FRE_WRONG," +
                    "ALL_LOCUS_NUM," +
                    "NOT_IN_OLD_NUM," +
                    "FRE_NOT_IN," +
                    "VERSION2" +
                    ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                  val statement: PreparedStatement = connection.prepareStatement(insert_sql)

                  statement.setString(1, id)
                  statement.setString(2, inc_day)
                  statement.setString(3, area_code)
                  statement.setString(4, city)
                  statement.setString(5, city_name)
                  statement.setString(6, province_name)

                  statement.setInt(7, limit_num_v1)
                  statement.setInt(8, area_num_v1)
                  statement.setInt(9, point_num_v1)
                  statement.setInt(10, len_num_v1)
                  statement.setInt(11, fre_num_v1)
                  statement.setString(12, version1)
                  statement.setInt(13, limit_num_v2)
                  statement.setInt(14, area_num_v2)
                  statement.setInt(15, point_num_v2)
                  statement.setInt(16, len_num_v2)
                  statement.setInt(17, fre_num_v2)
                  statement.setInt(18, wrong_num)
                  statement.setInt(19, fre_wrong)
                  statement.setLong(20, all_locus_num)
                  statement.setInt(21, not_in_old_num)
                  statement.setInt(22, fre_not_in)
                  statement.setString(23, version2)

                  statement.executeUpdate()
                  statement.close()

              })

              connection.close()
          })

    }

}
