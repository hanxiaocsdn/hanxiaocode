package app.runLimitedV2

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.RunTrafficControlDataFromInterV2
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, getVersion}
import utils.HttpClientUtil.{getJsonByGet, getJsonByGet2}
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
  * 获取规划的闯行数据
  */
object GetLimitedDataFromPlan {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val gd_url: String = config.getString("gd_url")
    val ct_url: String = config.getString("ct_url")
    val jy_url: String = config.getString("jy_url")
    val qm_url1: String = config.getString("qm_url")
    val qm_url2: String = config.getString("qm_url2")
    val version_url1: String = config.getString("version_url")
    val version_url2: String = config.getString("version_url2")
    val wuxi_area: String = config.getString("wuxi_area")
    val jizhou_area: String = config.getString("jizhou_area")
    val guangzhou_area: String = config.getString("guangzhou_area")
    val quanzhou_area: String = config.getString("quanzhou_area")
    val jilin_area: String = config.getString("jilin_area")
//    val sichuan_area: String = config.getString("sichuan_area")
//    val lujin_area: String = config.getString("lujin_area")

    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        if (args.length != 3) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time、flag
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val flag: String = args(2)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"flag:$flag")

        var qm_url:String =""
        var version_url:String =""
        if(flag == "1"){
            qm_url = qm_url1
            version_url =version_url1
        } else {
            qm_url = qm_url2
            version_url =version_url2
        }

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        logger.error("<================ 开始取数 ================>")

        // 车辆历史轨迹及任务明细合并
        val dlr = '$'
        val carLocusAndTaskDetailSQL: String =
            s"""
               |--车辆历史轨迹数据
               |with carLocus as (
               |select
               |  *
               |from
               |  (select
               |    get_json_object(info, '$dlr.task_id')                   as task_id,
               |    get_json_object(info, '$dlr.start_dept')                as start_dept,
               |    get_json_object(info, '$dlr.end_dept')                  as end_dept,
               |    ""                                                      as his_coords,
               |    substr(get_json_object(info, '$dlr.start_dept'),1,3)    as city,
               |    inc_day
               |  from
               |    dm_gis.eta_traj_info
               |  where
               |    inc_day >= '$start_time'
               |    and inc_day < '$end_time'
               |    and get_json_object(info, '$dlr.carrier_type') = 0
               |    and(
               |       (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $wuxi_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $wuxi_area)
               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $jizhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $jizhou_area)
               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $guangzhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $guangzhou_area)
               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $quanzhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $quanzhou_area)
               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $jilin_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $jilin_area)
               |    )
               |  ) t
               |),
               |--车辆任务明细数据
               |carTaskDetail as (
               |select
               |  *
               |from
               |  dm_gis.eta_grd_middle0
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and(
               |     (substr(start_dept, 1, 3) in $wuxi_area and substr(end_dept, 1, 3) in $wuxi_area)
               |  or (substr(start_dept, 1, 3) in $jizhou_area and substr(end_dept, 1, 3) in $jizhou_area)
               |  or (substr(start_dept, 1, 3) in $guangzhou_area and substr(end_dept, 1, 3) in $guangzhou_area)
               |  or (substr(start_dept, 1, 3) in $quanzhou_area and substr(end_dept, 1, 3) in $quanzhou_area)
               |  or (substr(start_dept, 1, 3) in $jilin_area and substr(end_dept, 1, 3) in $jilin_area)
               |  )
               |)
               |--合并轨迹和任务明细数据
               |select
               |  a.task_id,
               |  a.start_dept,
               |  a.end_dept,
               |  a.his_coords,
               |  a.inc_day,
               |  a.city,
               |  b.start_type,
               |  b.end_type,
               |  b.start_tm,
               |  b.end_tm,
               |  b.actual_run_time,
               |  b.plan_run_time,
               |  b.sort_num,
               |  b.start_longitude,
               |  b.end_longitude,
               |  b.start_latitude,
               |  b.end_latitude,
               |  b.line_code,
               |  b.line_id,
               |  b.task_area_code,
               |  b.vehicle_serial,
               |  b.conveyance_type,
               |  b.transoport_level,
               |  b.id,
               |  b.is_stop,
               |  b.ground_task_id,
               |  b.vehicle_type,
               |  b.axis_number,
               |  b.start_time,
               |  b.carrier_type,
               |  b.plf_flag,
               |  b.log_dist,
               |  b.line_distance
               |from
               |  carLocus a join carTaskDetail b
               |on a.task_id = b.task_id
               |  and a.start_dept = b.start_dept
               |  and a.end_dept = b.end_dept
               |""".stripMargin

        // 获取车辆参数信息
        val carParameterInfoSQL: String =
            s"""
               |select
               |  vehicle_serial2,
               |  hko_vehicle_code,
               |  trailer_vehicle_code,
               |  source,
               |  is_trailer,
               |  vehicle_type,
               |  vehicle_length,
               |  width,
               |  height,
               |  color,
               |  energy,
               |  license,
               |  emission,
               |  axls_number,
               |  vehicle_full_load_weight,
               |  vehicle_load_weight
               |from
               |  (
               |    SELECT
               |      row_number() over(
               |        partition by regexp_replace(vehicle, '[\\r\\n\\0, \\s, \\.*。、,]+', '')
               |        order by
               |          source,case
               |            when vehicle_type = 4 then 1
               |            when vehicle_type = 8 then 2
               |            when vehicle_type = 7 then 3
               |            when vehicle_type = 6 then 4
               |            when vehicle_type = 5 then 5
               |            else 6
               |          end,
               |          inc_day,
               |          vehicle_length + 0 desc
               |      ) num,
               |      regexp_replace(vehicle, '[\\r\\n\\0, \\s, \\.*。、,]+', '') vehicle_serial2,
               |      hko_vehicle_code,
               |      trailer_vehicle_code,
               |      source,
               |      vehicle_type,
               |      length,
               |      vehicle_length,
               |      vehicle_full_load_weight,
               |      outer_length,
               |      outer_width,
               |      outer_height,
               |      inner_length,
               |      inner_width,
               |      inner_height,
               |      axis,
               |      weight,
               |      load_weight,
               |      full_load_weight,
               |      color,
               |      energy,
               |      license,
               |      emission,
               |      is_trailer,
               |      vehicle_type_ground,
               |      exception_axis,
               |      exception_weight,
               |      exception_length,
               |      exception_width,
               |      exception_height,
               |      cast(load_weight as float)/1000 as vehicle_load_weight,
               |    cast(if(outer_width > inner_width,outer_width,inner_width) as float)/1000 as width,
               |    cast(if(outer_height > inner_height,outer_height,inner_height) as float)/1000 as height,
               |    case
               |        when axis is not null then axis
               |	    when axis is null and vehicle_full_load_weight <= 18 then '2'
               |	    when axis is null and vehicle_full_load_weight <= 27 then '3'
               |	    when axis is null and vehicle_full_load_weight <= 36 then '4'
               |	    when axis is null and vehicle_full_load_weight <= 43 then '5'
               |	    when axis is null and vehicle_full_load_weight > 43 then '6'
               |	    when axis is null and vehicle_full_load_weight is null then '2'
               |    end as axls_number,
               |      inc_day
               |    FROM
               |      dm_gis.gis_tm_vehicle
               |    WHERE
               |      inc_day >= '$start_time'
               |      and inc_day < '$end_time'
               |  ) t
               |where
               |  t.num = 1
               |""".stripMargin

        logger.error(carLocusAndTaskDetailSQL)
        logger.error(carParameterInfoSQL)

        val carLocusAndTaskDetailDF: DataFrame = spark
          .sql(carLocusAndTaskDetailSQL)
          .repartition(200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        val carParameterInfoDF: DataFrame = spark
          .sql(carParameterInfoSQL)
          .repartition(200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 车辆历史轨迹及任务明细：
        GetDFCountAndSampleData(logger,carLocusAndTaskDetailDF,"车辆历史轨迹及任务明细")

        // 车辆参数信息：
        GetDFCountAndSampleData(logger,carParameterInfoDF,"车辆参数信息")

        // 车辆历史轨迹及任务明细 左关联 参数数据
        val w1: WindowSpec = Window.orderBy($"xy")
        val w2: WindowSpec = Window.partitionBy("grp2").orderBy($"inc_day".desc)

        val carLocusAndTaskDetailAndParamRunPlanDF: DataFrame = carLocusAndTaskDetailDF
          .select("task_id", "start_dept", "end_dept", "his_coords", "inc_day",
              "start_type", "end_type", "start_tm", "end_tm", "actual_run_time", "plan_run_time",
              "sort_num", "start_longitude", "end_longitude", "start_latitude", "end_latitude",
              "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type",
              "transoport_level", "id", "is_stop", "ground_task_id", "start_time", "carrier_type",
              "plf_flag", "log_dist", "line_distance", "city"
          )
          .join(carParameterInfoDF, $"vehicle_serial" === $"vehicle_serial2", "left")
          .withColumn("line", concat($"start_dept", lit("_"), $"end_dept"))
          .withColumn("xy", concat(lit("x1="), $"start_longitude", lit("&y1="),
              $"start_latitude", lit("&x2="), $"end_longitude", lit("&y2="), $"end_latitude"))
          .withColumn("order", dense_rank().over(w1))
          .withColumn("grp0", concat($"line", lit("_"), $"order"))
          .withColumn("grp1", concat($"grp0", lit("_"), $"start_time"))
          .withColumn("grp2", concat($"grp1", lit("_"), $"vehicle_type", lit("_"), $"axls_number"))
          .withColumn("planDate", regexp_replace($"start_tm", "-| |:", ""))
          .withColumn("grp2_order", row_number().over(w2))
          .select("task_id", "start_dept", "end_dept", "his_coords", "start_type", "end_type",
              "start_tm", "end_tm", "actual_run_time", "plan_run_time", "sort_num", "start_longitude",
              "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code",
              "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id",
              "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2",
              "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type",
              "vehicle_length", "width", "height", "color", "energy", "license", "emission", "axls_number",
              "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2",
              "plandate", "grp2_order", "city", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑规划数据源信息：
        GetDFCountAndSampleData(logger,carLocusAndTaskDetailAndParamRunPlanDF,"用于跑规划的数据")

        // 释放缓存
        carLocusAndTaskDetailDF.unpersist()
        carParameterInfoDF.unpersist()

        if(flag == "1") {
            logger.error("开始写入hive表：dm_gis.mms_car_locus_task_detail_para_plan_info_v2")
            carLocusAndTaskDetailAndParamRunPlanDF
              .write
              .mode(SaveMode.Overwrite)
              .insertInto("dm_gis.mms_car_locus_task_detail_para_plan_info_v2")

            carLocusAndTaskDetailAndParamRunPlanDF.unpersist()
        }

        logger.error("<================ 取数完成 ================>")


        logger.error("<================ 开始跑规划 ================>")

        // 获取跑路径规划的数据
        val planSQL: String =
            s"""
               |select
               |  t1.*,
               |  t2.his_abnormal,
               |  t3.abnormal
               |from
               |  (select t.*,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.mms_car_locus_task_detail_para_plan_info_v2 t where inc_day >= '$start_time' and inc_day < '$end_time') t1
               |join
               |  (select t.*,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_his_traj_ab_info t where t.his_abnormal != '-1' and inc_day >= '$start_time' and inc_day < '$end_time') t2
               |on t1.uuid2 = t2.uuid2
               |join
               |  (select t.*, concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_traj_simgroup_info t where !(t.abnormal regexp '4|5') and inc_day >= '$start_time' and inc_day < '$end_time') t3
               |on t1.uuid2 = t3.uuid2
               |""".stripMargin

        logger.error(planSQL)

        val xmlStr: String = getJsonByGet2(version_url, 6, "utf-8")
        val version: String = getVersion(xmlStr)

        val planDF: DataFrame = spark
          .sql(planSQL)
          .withColumn("uuid", concat_ws("_",$"task_id",  $"start_dept",  $"end_dept"))
          .withColumn("version",lit(version))
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑路径规划数据信息：
        GetDFCountAndSampleData(logger,planDF,"用于跑规划的数据")

        // 跑高德规划
        val dataFromGDdf: DataFrame = planDF
          .repartition(10)
          .map(r => {
              val tp: (String, String, String, String, String, String, String, String, String, Int, String, String) = call_gd_service(r)
              tp
          })
          .repartition(200)
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen", "d_tlen",
              "d_plan_order", "d_query", "coords")

        // 从高德获取到的数据，关联原始数据
        val ResultDataFromGDdf: DataFrame = dataFromGDdf
          .join(planDF, "uuid")
          .withColumn("d_highway", lit(""))
          .withColumn("d_traLightCount", lit(""))
          .withColumn("d_frequency", lit(""))
          .withColumn("d_frequencycost", lit(""))
          .withColumn("d_frequencytype", lit(""))
          .withColumn("d_freqratio", lit(""))
          .withColumn("d_route_id", lit(""))
          .withColumn("d_src_routeids", lit(""))
          .withColumn("data_source", lit("2"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id",
              "start_dept", "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm",
              "actual_run_time", "plan_run_time", "sort_num", "start_longitude", "end_longitude", "start_latitude",
              "end_latitude", "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type",
              "transoport_level", "id", "is_stop", "ground_task_id", "start_time", "carrier_type", "plf_flag",
              "log_dist", "line_distance", "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source",
              "is_trailer", "vehicle_type", "vehicle_length", "width", "height", "color", "energy", "license",
              "emission", "axls_number", "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order",
              "grp0", "grp1", "grp2", "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype",
              "d_freqratio", "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑高德服务获取到的最终结果
        GetDFCountAndSampleData(logger,ResultDataFromGDdf,"跑高德服务最终的结果")


        // 跑传统服务接口 获取相应的字段
        val dataFromCTdf: Dataset[Row] = planDF
          .flatMap(r => {
              val listBuff: ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)] = call_ct_service(r)
              listBuff
          })
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑传统规划获取到的数据
        GetDFCountAndSampleData(logger,dataFromCTdf,"跑传统服务获取到的数据")

        // 从传统获取到的数据，关联原始数据
        val ResultDataFromCTdf: DataFrame = dataFromCTdf
          .join(planDF, "uuid")
          .withColumn("d_frequency", lit(""))
          .withColumn("d_frequencycost", lit(""))
          .withColumn("d_frequencytype", lit(""))
          .withColumn("d_freqratio", lit(""))
          .withColumn("d_route_id", lit(""))
          .withColumn("d_src_routeids", lit(""))
          .withColumn("data_source", lit("1"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id", "start_dept",
              "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm", "actual_run_time",
              "plan_run_time", "sort_num", "start_longitude", "end_longitude", "start_latitude", "end_latitude",
              "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type", "transoport_level",
              "id", "is_stop", "ground_task_id", "start_time", "carrier_type", "plf_flag", "log_dist",
              "line_distance", "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer",
              "vehicle_type", "vehicle_length", "width", "height", "color", "energy", "license", "emission",
              "axls_number", "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0",
              "grp1", "grp2", "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype",
              "d_freqratio", "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger,ResultDataFromCTdf,"跑传统服务最终的结果")

        // 释放缓存
        dataFromCTdf.unpersist()

        // 跑经验服务接口 获取相应的字段
        val dataFromJYdf: Dataset[Row] = planDF
          .flatMap(r => {
              val mylist: ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)] = call_jy_service(r)
              mylist
          })
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "d_frequency",
              "d_frequencycost", "d_frequencytype", "d_freqratio", "d_route_id", "d_src_routeids")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑经验规划获取到的数据
        GetDFCountAndSampleData(logger,dataFromJYdf,"跑经验服务获取到的数据")

        // 从经验获取到的数据，关联原始数据
        val ResultDataFromJYdf: DataFrame = dataFromJYdf
          .join(planDF, "uuid")
          .withColumn("data_source", lit("3"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen", "d_tlen",
              "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id", "start_dept", "end_dept",
              "his_coords", "start_type", "end_type", "start_tm", "end_tm", "actual_run_time", "plan_run_time",
              "sort_num", "start_longitude", "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id",
              "task_area_code", "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop",
              "ground_task_id", "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance",
              "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type",
              "vehicle_length", "width", "height", "color", "energy", "license", "emission", "axls_number",
              "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2",
              "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype", "d_freqratio",
              "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger,ResultDataFromJYdf,"跑经验服务最终的结果数据")

        // 释放缓存
        dataFromJYdf.unpersist()
        planDF.unpersist()


        // 高德、传统、经验 3个结果数据合并在一起
        val GDAndCTAndJYDataDF: DataFrame = ResultDataFromGDdf
          .union(ResultDataFromCTdf)
          .union(ResultDataFromJYdf)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 3个结果数据合并在一起的示例
        GetDFCountAndSampleData(logger,GDAndCTAndJYDataDF,"高德、传统、经验 3个服务的数据合并之后的数据")

        logger.error("<================ 跑规划完成 ================>")


        logger.error("<================ 【规划的数据】开始跑闯行 ================>")

        // 跑闯行服务，获取相应的数据，并对数据做解析
        val RunTrafficContrDataFromInterDS: Dataset[RunTrafficControlDataFromInterV2] = GDAndCTAndJYDataDF
          .repartition(10)
          .filter("d_status = 0")
          .flatMap(r => {
              val (uuid, data_source, d_plan_order, jsonData) = call_limited_route(r,qm_url)
              val listBuf: ListBuffer[RunTrafficControlDataFromInterV2] = parse_limited_data(uuid, data_source, d_plan_order, jsonData)
              listBuf
          })
          .repartition(200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        logger.error(s"【规划的数据源】结果数据总量：${RunTrafficContrDataFromInterDS.count()} 条")
        logger.error(s"【规划的数据源】从接口获取到的数据，处理过后的样例数据：")
        RunTrafficContrDataFromInterDS.take(2).foreach(r => logger.error(r.toString))


        // 接口解析出的数据  和  原始数据关联上  -- 规划的数据
        val ResultRunTrafficContrDataFromInterDF: DataFrame = GDAndCTAndJYDataDF
          .join(RunTrafficContrDataFromInterDS, Seq("uuid", "data_source", "d_plan_order"))
          .withColumn("v",lit(flag))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_tralightcount", "task_id",
              "start_dept", "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm",
              "actual_run_time", "plan_run_time", "sort_num", "start_longitude", "end_longitude",
              "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code", "vehicle_serial",
              "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id", "start_time",
              "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2", "hko_vehicle_code",
              "trailer_vehicle_code", "source", "is_trailer", "vehicle_type", "vehicle_length", "width", "height",
              "color", "energy", "license", "emission", "axls_number", "vehicle_full_load_weight",
              "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2", "plandate", "grp2_order",
              "d_frequency", "d_frequencycost", "d_frequencytype", "d_freqratio", "d_route_id", "d_src_routeids",
              "data_source", "flag", "status", "rdist", "rtime", "rhighway", "rtralightcount", "rtolls",
              "rtollsdistance", "qstartxy", "qendxy", "rcoords", "rsteps", "rflen", "rtlen", "rulecount",
              "ruleorder", "ruleid", "ruletype", "rulepos", "ruleroadid", "ruleoutroadid", "ruleroadname",
              "limitweight", "limitsize", "limitwidth", "limitaxload", "limitload", "limitaxcnt", "limitpassport",
              "limitholiday", "limitvehicletype", "limitoutflag", "limitemitstand", "limittailchar",
              "limitstartdate", "limitenddate", "limitweek", "limittime", "guid", "ruletimedesc", "ruleregiondesc",
              "rulevehicle", "rulestrategy","city", "version", "v","inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger,ResultRunTrafficContrDataFromInterDF,"【规划的数据源】最终的结果数据")

        // 释放缓存
        GDAndCTAndJYDataDF.unpersist()
        RunTrafficContrDataFromInterDS.unpersist()

        // 闯行的数据
        val LimitedResultRunTrafficContrDataFromInterDS: Dataset[Row] = ResultRunTrafficContrDataFromInterDF
          .filter("flag==true")
          .persist(StorageLevel.MEMORY_AND_DISK)

        logger.error(s"【规划的数据源】闯行的数据总量：${LimitedResultRunTrafficContrDataFromInterDS.count()} 条")
        LimitedResultRunTrafficContrDataFromInterDS.take(3).foreach(r => logger.error(r.mkString("|")))

        ResultRunTrafficContrDataFromInterDF.unpersist()

        logger.error("开始写入hive表：dm_gis.mms_car_route_plan_detail_and_limited_info_v2")
        LimitedResultRunTrafficContrDataFromInterDS
          .write
          .mode(SaveMode.Overwrite)
          .insertInto("dm_gis.mms_car_route_plan_detail_and_limited_info_v2")

        LimitedResultRunTrafficContrDataFromInterDS.unpersist()



        logger.error("运行成功！")

        // 程序运行结束,关闭spark
        spark.stop()


    }


    // 调高德的服务，获取对应字段的值
    def call_gd_service(r: Row): (String, String, String, String, String, String, String, String, String, Int, String, String) = {

        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val planDate: String = r.getAs[String]("plandate")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val emitStand: String = r.getAs[String]("emission")

        val plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("planDate", planDate)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("emitStand", emitStand)

        val url: String = gd_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url = url, 6, "utf-8")
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            val result: JSONObject = jsonData.getJSONObject("result")
            val dist: String = result.getString("dist")
            val time: String = result.getString("time")
            val tolls: String = result.getString("tolls")
            val src: String = result.getString("src")
            val flen: String = result.getString("flen")
            val tlen: String = result.getString("tlen")

            val query_tmp: JSONObject = result.getJSONObject("query")
            val coords_tmp: JSONArray = result.getJSONArray("coords")
            var query: String = ""
            var coords: String = ""
            if (query_tmp != null) {
                query = query_tmp.toJSONString
            }
            if (coords_tmp != null) {
                coords = coords_tmp.toJSONString
            }

            (uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords)
        } else {
            (uuid, url, "", "", "", "", "", "", "", plan_order, "", "")
        }
    }

    // 调用传统服务，获取对应字段的值
    def call_ct_service(r: Row): ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)] = {
        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val planDate: String = r.getAs[String]("plandate")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val emitStand: String = r.getAs[String]("emission")

        var plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("planDate", planDate)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("emitStand", emitStand)

        val url: String = ct_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url, 6, "utf-8")

        val listBuff = new ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)]
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")

                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    for (j <- 0 until list.size()) {
                        val obj: JSONObject = list.getJSONObject(j)
                        val dist: String = obj.getString("dist")
                        val time: String = obj.getString("time")
                        val highway: String = obj.getString("highway")
                        val traLightCount: String = obj.getString("traLightCount")
                        val tolls: String = obj.getString("tolls")
                        val src: String = obj.getString("src")
                        val flen: String = obj.getString("flen")
                        val tlen: String = obj.getString("tlen")
                        val query_tmp: JSONObject = obj.getJSONObject("query")
                        val coords_tmp: JSONArray = obj.getJSONArray("coords")
                        var query: String = ""
                        var coords: String = ""
                        if (query_tmp != null) query = query_tmp.toJSONString
                        if (coords_tmp != null) coords = coords_tmp.toJSONString

                        plan_order = j

                        listBuff.append((uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords, highway, traLightCount))
                    }
                } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))
            } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))
        } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))

        listBuff
    }

    // 调用经验服务，获取对应字段的值
    def call_jy_service(r: Row): ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)] = {

        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val planDate: String = r.getAs[String]("plandate")
        val emitStand: String = r.getAs[String]("emission")

        var plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("planDate", planDate)
        parMap.put("emitStand", emitStand)

        val url: String = jy_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url, 3, "utf-8")

        val mylist = new ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)]
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")
                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    for (j <- 0 until list.size()) {
                        val json: JSONObject = list.getJSONObject(j)
                        val dist: String = json.getString("dist")
                        val time: String = json.getString("time")
                        val highway: String = json.getString("highway")
                        val traLightCount: String = json.getString("traLightCount")
                        val tolls: String = json.getString("tolls")
                        val src: String = json.getString("src")
                        val flen: String = json.getString("flen")
                        val tlen: String = json.getString("tlen")
                        val query_tmp: JSONObject = json.getJSONObject("query")
                        val coords_tmp: JSONArray = json.getJSONArray("coords")
                        var query: String = ""
                        var coords: String = ""

                        if (query_tmp != null) query = query_tmp.toJSONString
                        if (coords_tmp != null) coords = coords_tmp.toJSONString

                        val frequency: String = json.getString("frequency")
                        val frequencycost: String = json.getString("frequencycost")
                        val frequencytype: String = json.getString("frequencytype")
                        val freqratio: String = json.getString("freqratio")
                        val route_id: String = json.getString("route_id")
                        val src_routeids: String = json.getString("src_routeids")

                        plan_order = j

                        mylist.append((uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords,
                          highway, traLightCount, frequency, frequencycost, frequencytype, freqratio, route_id, src_routeids))
                    }
                } else mylist.append((uuid, url, status, "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))
            } else mylist.append((uuid, url, status, "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))
        } else mylist.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))

        mylist
    }

    // 将map转化为string，剔除值为null的数据
    def map2String(parMap: mutable.HashMap[String, Any]): String = {
        for (elem <- parMap)
            if (elem._2 == null) parMap.remove(elem._1)
        val parStr: String = parMap.mkString("&").replaceAll(" -> ", "=")
        parStr
    }

    /// 调用闯行的接口
    def call_limited_route(r: Row,qm_url:String): (String, String, Int, JSONObject) = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = r.getAs[Int]("d_plan_order")

        var origin: String = ""
        var destination: String = ""
        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
        val coordsArr: Array[String] = coords.split("\\|")
        for (i <- coordsArr.indices) {
            if (i == 0) origin = coordsArr(i)
            if (i == coordsArr.length - 1) destination = coordsArr(i)
        }

        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val emitStand: String = r.getAs[String]("emission")
        val energy: String = r.getAs[String]("energy")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val Mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val width: Double = r.getAs[Double]("width")
        val Size: String = r.getAs[String]("vehicle_length")
        val axlenumber: String = r.getAs[String]("axls_number")
        val No: String = r.getAs[String]("task_id")
        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&origin=$origin&destination=$destination&stype=0&etype=0&plate=$plate" +
          s"&plateColor=$plateColor&emitStand=$emitStand&energy=$energy&weight=$weight&vehicle=$vehicle&Mload=$Mload" +
          s"&height=$height&width=$width&Size=$Size&axlenumber=$axlenumber&passport=100000&mode=2&speed=1&No=$No&Toll=1&date=$date"


        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonStr: String = mapData.get("content").toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:"+e.getMessage)
        }

        (uuid, data_source, d_plan_order, json)
    }

    // 解析接口返回的json,获取相应的字段值
    def parse_limited_data(uuid: String, data_source: String, d_plan_order: Int, j: JSONObject): ListBuffer[RunTrafficControlDataFromInterV2] = {
        // 存放闯行的数据
        val rules: ListBuffer[RunTrafficControlDataFromInterV2] = new ListBuffer[RunTrafficControlDataFromInterV2]

        if(j != null){
            val status: String = j.getString("status")
            if (status == "0") {
                val route: JSONObject = j.getJSONObject("route")
                val qstartxy: String = route.getString("origin")
                val qendxy: String = route.getString("destination")
                val paths: JSONArray = route.getJSONArray("paths")

                // 判断这个json数据是否闯行，默认false：不闯行
                var flag: Boolean = false
                if (paths.size() > 0) {
                    for (i <- 0 until paths.size() if !flag) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        if (obj.containsKey("voi_rule") && obj.getJSONArray("voi_rule").size() > 0) flag = true
                    }
                }

                // 闯行 与 不闯行 的公共解析字段
                // 开始解析公共字段
                var rdist: Int = 0
                var rtime: Double = 0.0
                var rhighway: Int = 0
                var rtraLightCount: Int = 0
                var rtolls: Int = 0
                var rtollsDistance: Int = 0
                val rcoords_tmp = new ListBuffer[String]
                val rsteps: String = ""
                var rulecount: Int = 0
                var rflen: Int = 0
                var rtlen: Int = 0
                val polyline_buff = new ListBuffer[String]
                val steps_links_swid_buff = new ListBuffer[String]
                var rmultiPathPos: String = ""
                var rmultiPathSwid: String = ""
                var first_swid:String=""
                var last_swid:String=""

                if (paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        rdist += obj.getInteger("distance")
                        rtime += obj.getDouble("duration")
                        rhighway += obj.getInteger("highspeed_distance")
                        rtraLightCount += obj.getInteger("trafficlight_count")
                        rtolls += obj.getInteger("tolls")
                        rtollsDistance += obj.getInteger("toll_distance")
                        rcoords_tmp.append(obj.getString("polyline"))

                        if (i == 0) rflen = obj.getInteger("flen")
                        if (i == paths.size() - 1) rtlen = obj.getInteger("tlen")

                        val polylineArr: Array[String] = obj.getString("polyline").split(";", -1)
                        val posStr: String = polylineArr.head + "_" + polylineArr.last
                        polyline_buff.append(posStr)

                        val steps: JSONArray = obj.getJSONArray("steps")
                        if(steps != null && steps.size()>0){
                            val first_step: JSONObject = steps.getJSONObject(0)
                            val last_step: JSONObject = steps.getJSONObject(steps.size()-1)

                            val first_links: JSONArray = first_step.getJSONArray("links")
                            val last_links: JSONArray = last_step.getJSONArray("links")

                            if(first_links != null && first_links.size()>0) first_swid= first_links.getJSONObject(0).getString("sw_id")
                            if(last_links != null && last_links.size()>0) last_swid= last_links.getJSONObject(last_links.size-1).getString("sw_id")

                            steps_links_swid_buff.append(first_swid + "_" + last_swid)
                        }

                        if (obj.containsKey("voi_rule")) rulecount += obj.getJSONArray("voi_rule").size()

                    }
                }
                val rcoords: String = rcoords_tmp.mkString(";")
                if (polyline_buff.size > 1) rmultiPathPos = polyline_buff.mkString("|")
                if (steps_links_swid_buff.size > 1) rmultiPathSwid = steps_links_swid_buff.mkString("|")


                // 公共字段解析结束

                // 如果未闯行，写入未闯行的表
                if (!flag) {
                    val line: RunTrafficControlDataFromInterV2 = RunTrafficControlDataFromInterV2(uuid, data_source, d_plan_order, flag, status, rdist, rtime, rhighway, rtraLightCount, rtolls,
                        rtollsDistance, qstartxy, qendxy, rcoords, rsteps, rflen, rtlen, rulecount, "", "", "", "", "", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", "", "", "", "", "", "", "", "", "")
                    rules.append(line)
                } else {
                    // 对闯行的数据做处理
                    var ruleorder = 0
                    for (i <- 0 until paths.size()) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        if (obj.containsKey("voi_rule") && obj.getJSONArray("voi_rule").size() > 0) {
                            for (j <- 0 until obj.getJSONArray("voi_rule").size()) {
                                val rule: JSONObject = obj.getJSONArray("voi_rule").getJSONObject(j)
                                ruleorder = ruleorder + j + 1
                                val ruletype: String = rule.getString("type")
                                val rulepos: String = rule.getString("pos")
                                val ruleroadid: String = rule.getString("road_id")
                                val ruleoutroadid: String = rule.getString("out_road_id")
                                val ruleroadname: String = rule.getString("name")

                                val limit: JSONObject = rule.getJSONObject("limit")
                                var ruleid: String = ""
                                var Guid: String = ""
                                var limitweight: String = ""
                                var limitsize: String = ""
                                var limitwidth: String = ""
                                var limitaxload: String = ""
                                var limitload: String = ""
                                var limitaxcnt: String = ""
                                var limitpassport: String = ""
                                var limitholiday: String = ""
                                var limitvehicletype: String = ""
                                var limitoutflag: String = ""
                                var limitemitStand: String = ""
                                var limittailchar: String = ""
                                var limitstartdate: String = ""
                                var limitenddate: String = ""
                                var limitweek: String = ""
                                var limittime: String = ""
                                if (limit != null && limit.size() > 0) {
                                    ruleid = limit.getString("RuleID")
                                    Guid = limit.getString("Guid")
                                    limitweight = limit.getString("限重")
                                    limitsize = limit.getString("限高")
                                    limitwidth = limit.getString("限宽")
                                    limitaxload = limit.getString("限轴重")
                                    limitload = limit.getString("限载重")
                                    limitaxcnt = limit.getString("限轴数")
                                    limitpassport = limit.getString("通行证")
                                    limitholiday = limit.getString("节假日")
                                    limitvehicletype = limit.getString("车辆类型")
                                    limitoutflag = limit.getString("限车辆属地")
                                    limitemitStand = limit.getString("限燃油标号")
                                    limittailchar = limit.getString("限尾号")
                                    limitstartdate = limit.getString("开始日期")
                                    limitenddate = limit.getString("结束日期")
                                    limitweek = limit.getString("限星期")
                                    limittime = limit.getString("限时段")
                                }


                                var ruletimedesc: String = ""
                                var ruleregiondesc: String = ""
                                var rulevehicle: String = ""
                                var rulestrategy: String = ""
                                val region_rule: JSONArray = rule.getJSONArray("region_rule")
                                if (region_rule != null && region_rule.size() > 0) {
                                    ruletimedesc = region_rule.getJSONObject(0).getString("time")
                                    ruleregiondesc = region_rule.getJSONObject(0).getString("region")
                                    rulevehicle = region_rule.getJSONObject(0).getString("vehicle")
                                    rulestrategy = region_rule.getJSONObject(0).getString("strategy")
                                }

                                val ruleorder_tmp: String = ruleorder.toString
                                val line: RunTrafficControlDataFromInterV2 = RunTrafficControlDataFromInterV2(uuid, data_source, d_plan_order, flag, status, rdist, rtime, rhighway, rtraLightCount, rtolls,
                                    rtollsDistance, qstartxy, qendxy, rcoords, rsteps, rflen, rtlen, rulecount, ruleorder_tmp, ruleid, ruletype, rulepos, ruleroadid, ruleoutroadid,
                                    ruleroadname, limitweight, limitsize, limitwidth, limitaxload, limitload, limitaxcnt, limitpassport, limitholiday, limitvehicletype,
                                    limitoutflag, limitemitStand, limittailchar, limitstartdate, limitenddate, limitweek, limittime, Guid, ruletimedesc, ruleregiondesc,
                                    rulevehicle, rulestrategy)

                                rules.append(line)
                            }
                        }
                    }
                }

                rules
            } else rules
        } else rules


    }


}
