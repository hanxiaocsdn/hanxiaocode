package app.runLimited

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getDataFrame}
import utils.SparkConfigUtil


/**
  * 闯限行分析
  * 整体流程：1.取数 → 2.数据处理 → 3.跑规划数据、纠偏数据 → 4.跑闯行 → 5.处理异常数据
  *
  * 1.取数
  */
object GetOriginalDataForAllProject {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val wuxi_area: String = config.getString("wuxi_area")
    val jizhou_area: String = config.getString("jizhou_area")
    val guangzhou_area: String = config.getString("guangzhou_area")
    val quanzhou_area: String = config.getString("quanzhou_area")
    val jilin_area: String = config.getString("jilin_area")
    val sichuan_area: String = config.getString("sichuan_area")
    val lujin_area: String = config.getString("lujin_area")


    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 车辆历史轨迹及任务明细合并
        val dlr = '$'
//        val carLocusAndTaskDetailSQL: String =
//            s"""
//               |--车辆历史轨迹数据
//               |with carLocus as (
//               |select
//               |  *
//               |from
//               |  (select
//               |    get_json_object(info, '$dlr.task_id')                   as task_id,
//               |    get_json_object(info, '$dlr.start_dept')                as start_dept,
//               |    get_json_object(info, '$dlr.end_dept')                  as end_dept,
//               |    ""                                                      as his_coords,
//               |    substr(get_json_object(info, '$dlr.start_dept'),1,3)    as city,
//               |    inc_day
//               |  from
//               |    dm_gis.eta_traj_info
//               |  where
//               |    inc_day >= '$start_time'
//               |    and inc_day < '$end_time'
//               |    and get_json_object(info, '$dlr.carrier_type') = 0
//               |    and (
//               |       (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $wuxi_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $wuxi_area)
//               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $jizhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $jizhou_area)
//               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $guangzhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $guangzhou_area)
//               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $quanzhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $quanzhou_area)
//               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $jilin_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $jilin_area)
//               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $sichuan_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $sichuan_area)
//               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $lujin_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $lujin_area)
//               |    )
//               |  ) t
//               |),
//               |--车辆任务明细数据
//               |carTaskDetail as (
//               |select
//               |  *
//               |from
//               |  dm_gis.eta_grd_middle0
//               |where
//               |  inc_day >= '$start_time'
//               |  and inc_day < '$end_time'
//               |  and(
//               |     (substr(start_dept, 1, 3) in $wuxi_area and substr(end_dept, 1, 3) in $wuxi_area)
//               |  or (substr(start_dept, 1, 3) in $jizhou_area and substr(end_dept, 1, 3) in $jizhou_area)
//               |  or (substr(start_dept, 1, 3) in $guangzhou_area and substr(end_dept, 1, 3) in $guangzhou_area)
//               |  or (substr(start_dept, 1, 3) in $quanzhou_area and substr(end_dept, 1, 3) in $quanzhou_area)
//               |  or (substr(start_dept, 1, 3) in $jilin_area and substr(end_dept, 1, 3) in $jilin_area)
//               |  or (substr(start_dept, 1, 3) in $sichuan_area and substr(end_dept, 1, 3) in $sichuan_area)
//               |  or (substr(start_dept, 1, 3) in $lujin_area and substr(end_dept, 1, 3) in $lujin_area)
//               |  )
//               |)
//               |--合并轨迹和任务明细数据
//               |select
//               |  a.task_id,
//               |  a.start_dept,
//               |  a.end_dept,
//               |  a.his_coords,
//               |  a.inc_day,
//               |  a.city,
//               |  b.start_type,
//               |  b.end_type,
//               |  b.start_tm,
//               |  b.end_tm,
//               |  b.actual_run_time,
//               |  b.plan_run_time,
//               |  b.sort_num,
//               |  b.start_longitude,
//               |  b.end_longitude,
//               |  b.start_latitude,
//               |  b.end_latitude,
//               |  b.line_code,
//               |  b.line_id,
//               |  b.task_area_code,
//               |  b.vehicle_serial,
//               |  b.conveyance_type,
//               |  b.transoport_level,
//               |  b.id,
//               |  b.is_stop,
//               |  b.ground_task_id,
//               |  b.start_time,
//               |  b.carrier_type,
//               |  b.plf_flag,
//               |  b.log_dist,
//               |  b.line_distance
//               |from
//               |  carLocus a join carTaskDetail b
//               |on a.task_id = b.task_id
//               |  and a.start_dept = b.start_dept
//               |  and a.end_dept = b.end_dept
//               |""".stripMargin

        val carLocusAndTaskDetailSQL: String =
            s"""
               |--车辆历史轨迹数据
               |with carLocus as (
               |select
               |  *
               |from
               |  (select
               |    get_json_object(info, '$dlr.task_id')                   as task_id,
               |    get_json_object(info, '$dlr.start_dept')                as start_dept,
               |    get_json_object(info, '$dlr.end_dept')                  as end_dept,
               |    ""                                                      as his_coords,
               |    substr(get_json_object(info, '$dlr.start_dept'),1,3)    as city,
               |    inc_day
               |  from
               |    dm_gis.eta_traj_info
               |  where
               |    inc_day >= '$start_time'
               |    and inc_day < '$end_time'
               |    and get_json_object(info, '$dlr.carrier_type') = 0
               |    and (
               |        get_json_object(info, '$dlr.task_area_code') = '020Y'
               |    )
               |  ) t
               |),
               |--车辆任务明细数据
               |carTaskDetail as (
               |select
               |  *
               |from
               |  dm_gis.eta_grd_middle0
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and (
               |    task_area_code = '020Y'
               |  )
               |)
               |--合并轨迹和任务明细数据
               |select
               |  a.task_id,
               |  a.start_dept,
               |  a.end_dept,
               |  a.his_coords,
               |  a.inc_day,
               |  a.city,
               |  b.start_type,
               |  b.end_type,
               |  b.start_tm,
               |  b.end_tm,
               |  b.actual_run_time,
               |  b.plan_run_time,
               |  b.sort_num,
               |  b.start_longitude,
               |  b.end_longitude,
               |  b.start_latitude,
               |  b.end_latitude,
               |  b.line_code,
               |  b.line_id,
               |  b.task_area_code,
               |  b.vehicle_serial,
               |  b.conveyance_type,
               |  b.transoport_level,
               |  b.id,
               |  b.is_stop,
               |  b.ground_task_id,
               |  b.start_time,
               |  b.carrier_type,
               |  b.plf_flag,
               |  b.log_dist,
               |  b.line_distance
               |from
               |  carLocus a join carTaskDetail b
               |on a.task_id = b.task_id
               |  and a.start_dept = b.start_dept
               |  and a.end_dept = b.end_dept
               |""".stripMargin

        // 获取车辆参数信息
        val carParameterInfoSQL: String =
            s"""
               |select
               |  vehicle_serial2,
               |  hko_vehicle_code,
               |  trailer_vehicle_code,
               |  source,
               |  is_trailer,
               |  vehicle_type,
               |  vehicle_length,
               |  width,
               |  height,
               |  color,
               |  energy,
               |  license,
               |  emission,
               |  axls_number,
               |  vehicle_full_load_weight,
               |  vehicle_load_weight
               |from
               |  (
               |    SELECT
               |      row_number() over(
               |        partition by regexp_replace(vehicle, '[\\r\\n\\0, \\s, \\.*。、,]+', '')
               |        order by
               |          source,case
               |            when vehicle_type = 4 then 1
               |            when vehicle_type = 8 then 2
               |            when vehicle_type = 7 then 3
               |            when vehicle_type = 6 then 4
               |            when vehicle_type = 5 then 5
               |            else 6
               |          end,
               |          inc_day,
               |          vehicle_length + 0 desc
               |      ) num,
               |      regexp_replace(vehicle, '[\\r\\n\\0, \\s, \\.*。、,]+', '') vehicle_serial2,
               |      hko_vehicle_code,
               |      trailer_vehicle_code,
               |      source,
               |      vehicle_type,
               |      length,
               |      vehicle_length,
               |      vehicle_full_load_weight,
               |      outer_length,
               |      outer_width,
               |      outer_height,
               |      inner_length,
               |      inner_width,
               |      inner_height,
               |      axis,
               |      weight,
               |      load_weight,
               |      full_load_weight,
               |      color,
               |      energy,
               |      license,
               |      emission,
               |      is_trailer,
               |      vehicle_type_ground,
               |      exception_axis,
               |      exception_weight,
               |      exception_length,
               |      exception_width,
               |      exception_height,
               |      cast(load_weight as float)/1000 as vehicle_load_weight,
               |    cast(if(outer_width > inner_width,outer_width,inner_width) as float)/1000 as width,
               |    cast(if(outer_height > inner_height,outer_height,inner_height) as float)/1000 as height,
               |    case
               |        when axis is not null then axis
               |	    when axis is null and vehicle_full_load_weight <= 18 then '2'
               |	    when axis is null and vehicle_full_load_weight <= 27 then '3'
               |	    when axis is null and vehicle_full_load_weight <= 36 then '4'
               |	    when axis is null and vehicle_full_load_weight <= 43 then '5'
               |	    when axis is null and vehicle_full_load_weight > 43 then '6'
               |	    when axis is null and vehicle_full_load_weight is null then '2'
               |    end as axls_number,
               |      inc_day
               |    FROM
               |      dm_gis.gis_tm_vehicle
               |    WHERE
               |      inc_day >= '$start_time'
               |      and inc_day < '$end_time'
               |  ) t
               |where
               |  t.num = 1
               |""".stripMargin

        val carParameterInfoDF: DataFrame = getDataFrame(logger, spark, carParameterInfoSQL)
        val carLocusAndTaskDetailDF: DataFrame = getDataFrame(logger, spark, carLocusAndTaskDetailSQL)


        // 车辆历史轨迹及任务明细 左关联 参数数据
        getcarLocusAndParamDetail(logger, spark, carLocusAndTaskDetailDF, carParameterInfoDF)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()
    }

    // 车辆历史轨迹及任务明细 左关联 参数数据
    def getcarLocusAndParamDetail(logger: Logger, spark: SparkSession, carLocusAndTaskDetailDF: DataFrame, carParameterInfoDF: DataFrame): Unit = {
        import spark.implicits._

        val w1: WindowSpec = Window.orderBy($"xy")
        val w2: WindowSpec = Window.partitionBy("grp2").orderBy($"inc_day".desc)

        val carLocusAndTaskDetailAndParamRunPlanDF: DataFrame = carLocusAndTaskDetailDF
          .join(carParameterInfoDF, $"vehicle_serial" === $"vehicle_serial2", "left")
          .withColumn("line", concat_ws("_", $"start_dept", $"end_dept"))
          .withColumn("xy", concat(lit("x1="), $"start_longitude", lit("&y1="),
              $"start_latitude", lit("&x2="), $"end_longitude", lit("&y2="), $"end_latitude"))
          .withColumn("order", dense_rank().over(w1))
          .withColumn("grp0", concat_ws("_", $"line", $"order"))
          .withColumn("grp1", concat_ws("_", $"grp0", $"start_time"))
          .withColumn("grp2", concat_ws("_", $"grp1", $"vehicle_type", $"axls_number"))
          .withColumn("planDate", regexp_replace($"start_tm", "-| |:", ""))
          .withColumn("grp2_order", row_number().over(w2))
          .select("task_id", "start_dept", "end_dept", "his_coords", "start_type", "end_type",
              "start_tm", "end_tm", "actual_run_time", "plan_run_time", "sort_num", "start_longitude",
              "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code",
              "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id",
              "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2",
              "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type",
              "vehicle_length", "width", "height", "color", "energy", "license", "emission", "axls_number",
              "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2",
              "plandate", "grp2_order", "city", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑规划数据源信息：
        GetDFCountAndSampleData(logger, carLocusAndTaskDetailAndParamRunPlanDF, "用于跑规划的数据")
        // 跑规划的数据存入hive
        df2HiveByOverwrite(logger, carLocusAndTaskDetailAndParamRunPlanDF, "dm_gis.mms_car_locus_task_detail_para_plan_info")


        // 释放缓存
        carLocusAndTaskDetailDF.unpersist()
        carParameterInfoDF.unpersist()
        carLocusAndTaskDetailAndParamRunPlanDF.unpersist()
    }

}
