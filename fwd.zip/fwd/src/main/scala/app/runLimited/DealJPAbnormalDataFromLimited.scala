package app.runLimited

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.HttpConnection.{httpPost, sendPost}
import utils.SparkConfigUtil

import java.text.SimpleDateFormat
import java.util
import scala.collection.mutable.ListBuffer

/**
  * 对闯行的数据，进行纠偏异常处理 （已删除车参异常的闯行数据）
  *
  * 输入源：规划的闯行数据、纠偏的闯行数据
  *
  * 6.纠偏异常处理
  */
object DealJPAbnormalDataFromLimited {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")
    val jpyc_url: String = config.getString("jpyc_url")

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 获取规划的闯行数据
        val planLimitedlDataSQL: String =
            s"""
               |select
               |  concat(uuid,'_', data_source,'_', d_plan_order,'_',ruleroadid) as mynew,
               |  *
               |from
               |  dm_gis.mms_car_route_plan_detail_and_limited_info_his
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and data_source = '3'
               |""".stripMargin
        logger.error("规划的闯行数据："+planLimitedlDataSQL)

        // 规划的数据进行纠偏异常处理
        planJPAbnormalDeal(logger,spark,planLimitedlDataSQL)

        // 获取纠偏的闯行数据
        val JPLimitedDataSQL: String =
            s"""
               |select
               |  concat(uuid,'_', data_source,'_', 0,'_',ruleroadid) as mynew,
               |  0 as d_plan_order,
               |  *
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info_his
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin
        logger.error("纠偏的闯行数据："+JPLimitedDataSQL)

        // 纠偏的数据进行纠偏异常处理
        jpJPAbnormalDeal(logger,spark,JPLimitedDataSQL)


        logger.error("运行结束！")

        // 程序运行结束
        spark.stop()
    }

    // 调用匹配的接口
    def call_match_service(r: Row): (String, String, Int, String, JSONObject) = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = r.getAs[Int]("d_plan_order")
        val rulepos: String = r.getAs[String]("rulepos")
        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
          .replaceAll(" ", "")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val Mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val width: Double = r.getAs[Double]("width")
        val Size: String = r.getAs[String]("vehicle_length")
        val axlenumber: String = r.getAs[String]("axls_number")
        val date: String = r.getAs[String]("plandate")

        val parm: String = s"points=$coords&test=1&stype=0&etype=0&plate=&axleweight=" +
          s"&plateColor=&weight=$weight&vehicle=$vehicle&Mload=$Mload" +
          s"&height=$height&width=$width&Size=$Size&axlenumber=$axlenumber&passport=100000&mode=2&speed=1" +
          s"&No=$uuid&Toll=1&date=$date"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)

        var json: JSONObject = null

        try {
            val jsonStr: String = mapData.get("content").toString
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:"+e.getMessage)
        }

        (uuid, data_source, d_plan_order, rulepos, json)
    }

    // 解析匹配接口返回的json,获取相应的字段值和逻辑处理
    def get_match_abnormal_data(uuid: String, data_source: String, d_plan_order: Int, rulepos: String, js: JSONObject): (String, String, Int, String, String, String, String, String, String, Int, Double, Int, Int, Int, Int, Int, String, String) = {
        // 存放每个step 下的link字段
        val stepLinkBuff = new ListBuffer[(String, String, String, String, String, String, String, String)]
        // 存放每个outinfo 下的link字段
        val OutinfoLinkBuff = new ListBuffer[(String, String, String, String)]

        var flen: String = ""
        var tlen: String = ""
        var distance: Int = 0
        var duration: Double = 0.0
        var highspeed_distance: Int = 0
        var trafficlight_count: Int = 0
        var tolls: Int = 0
        var etc_toll: Int = 0
        var toll_distance: Int = 0
        var origin: String = ""
        var destination: String = ""
        var rc_distance: String = ""

        if(js != null){
            val status: String = js.getString("status")
            if (status == "0") {
                origin = js.getString("origin")
                destination = js.getString("destination")
                val route: JSONObject = js.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")
                val rc_distance_buff: ListBuffer[Int] = ListBuffer(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

                if (paths != null && paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val path: JSONObject = paths.getJSONObject(i)

                        if (i == 0) flen = path.getString("flen")
                        if (i == paths.size() - 1) tlen = path.getString("tlen")

                        distance += path.getInteger("distance")
                        duration += path.getDouble("duration")
                        highspeed_distance += path.getInteger("highspeed_distance")
                        trafficlight_count += path.getInteger("trafficlight_count")
                        tolls += path.getInteger("tolls")
                        etc_toll += path.getInteger("etc_toll")
                        toll_distance += path.getInteger("toll_distance")

                        val rc_distance: JSONArray = path.getJSONArray("rc_distance")
                        for (ii <- 0 to 10) rc_distance_buff(ii) = rc_distance_buff(ii) + rc_distance.getInteger(ii)

                        val steps: JSONArray = path.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            for (j <- 0 until steps.size()) {
                                val step: JSONObject = steps.getJSONObject(j)
                                if (step != null && step.size() > 0) {
                                    val links: JSONArray = step.getJSONArray("links")
                                    if (links != null && links.size() > 0) {
                                        for (i <- 0 until links.size()) {
                                            val link: JSONObject = links.getJSONObject(i)
                                            val sw_id: String = link.getString("sw_id")
                                            val id: String = link.getString("id")
                                            val name: String = link.getString("name")
                                            val formway: String = link.getString("formway")
                                            val roadclass: String = link.getString("roadclass")
                                            val coorindex: String = link.getString("coorindex")
                                            val pointnum: String = link.getString("pointnum")
                                            val dr_length: String = link.getString("dr_length")
                                            stepLinkBuff.append((sw_id, id, name, formway, roadclass, coorindex, pointnum, dr_length))
                                        }
                                    }
                                }
                            }
                        }

                        val outinfo: JSONObject = path.getJSONObject("outinfo")
                        if (outinfo != null && outinfo.size() > 0) {
                            val links: JSONArray = outinfo.getJSONArray("links")
                            if (links != null && links.size() > 0) {
                                for (j <- 0 until links.size()) {
                                    val link: JSONObject = links.getJSONObject(j)
                                    val lnk_type: String = link.getString("lnk_type")
                                    val mainaction: String = link.getString("mainaction")
                                    val ownership: String = link.getString("ownership")
                                    val dir: String = link.getString("dir")
                                    OutinfoLinkBuff.append((lnk_type, mainaction, ownership, dir))
                                }
                            }
                        }

                    }
                }

                rc_distance = rc_distance_buff.mkString(",")

                val n: Int = math.min(stepLinkBuff.size, OutinfoLinkBuff.size)
                val listBuff: ListBuffer[String] = new ListBuffer[String]
                if (n > 0) {
                    for (i <- 0 until n) {
                        listBuff.append(
                            s"${stepLinkBuff(i)._1},${stepLinkBuff(i)._2},${stepLinkBuff(i)._3},${stepLinkBuff(i)._4}," +
                              s"${stepLinkBuff(i)._5},${stepLinkBuff(i)._6},${stepLinkBuff(i)._7},${stepLinkBuff(i)._8}," +
                              s"${OutinfoLinkBuff(i)._1},${OutinfoLinkBuff(i)._2},${OutinfoLinkBuff(i)._3},${OutinfoLinkBuff(i)._4}"
                        )
                    }
                    val link_union: String = listBuff.mkString("|")
                    (uuid, data_source, d_plan_order, rulepos, status, origin, destination, flen, tlen, distance, duration, highspeed_distance, trafficlight_count,
                      tolls, etc_toll, toll_distance, link_union, rc_distance)
                } else {
                    (uuid, data_source, d_plan_order, rulepos, status, origin, destination, flen, tlen, distance, duration, highspeed_distance, trafficlight_count,
                      tolls, etc_toll, toll_distance, "", "")
                }

            } else {
                (uuid, data_source, d_plan_order, rulepos, status, origin, destination, flen, tlen, distance, duration, highspeed_distance, trafficlight_count,
                  tolls, etc_toll, toll_distance, "", "")
            }
        }else {
            (uuid, data_source, d_plan_order, rulepos, "", origin, destination, flen, tlen, distance, duration, highspeed_distance, trafficlight_count,
              tolls, etc_toll, toll_distance, "", "")
        }

    }

    // 调用纠偏异常接口
    def call_jpyc_service(r: Row, check_option: Int): JSONObject = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = r.getAs[Int]("d_plan_order")
        val lineid: String = uuid + "_" + data_source + "_" + d_plan_order

        val r_links_union: String = r.getAs[String]("r_links_union")
        val vehicle_type: Int = r.getAs[Int]("vehicle_type")
        val vehicle: String = ""
        val ft_coords: String = r.getAs[String]("coords")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axle_weight: String = ""
        val length: String = r.getAs[String]("vehicle_length")
        val width: Double = r.getAs[Double]("width")
        val plate_color: String = ""

        var req_time: String = ""
        val start_tm: String = r.getAs[String]("start_tm")
        if (start_tm != null && start_tm.nonEmpty) {
            val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            req_time = fm.parse(start_tm).getTime.toString
        }

        val turn_bypass_ratio_limit: Double = 1.5
        val sennior_primary_road_ratio_limit: Double = 1.2

        val parms: JSONObject = new JSONObject()

        parms.put("lineid", lineid)
        parms.put("links_union", r_links_union)
        parms.put("vehicle_type", vehicle_type)
        parms.put("vehicle", vehicle)
        parms.put("ft_coords", ft_coords)
        parms.put("weight", weight)
        parms.put("mload", mload)
        parms.put("height", height)
        parms.put("axle_weight", axle_weight)
        parms.put("length", length)
        parms.put("width", width)
        parms.put("plate_color", plate_color)
        parms.put("axle_weight", axle_weight)
        parms.put("check_option", check_option)
        parms.put("req_time", req_time)
        parms.put("turn_bypass_ratio_limit", turn_bypass_ratio_limit)
        parms.put("sennior_primary_road_ratio_limit", sennior_primary_road_ratio_limit)

//        val jsonStr: String = httpPost(3, jpyc_url, parms.toJSONString)
        val jsonStr: String = ""
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:"+e.getMessage)
        }
        json
    }

    // 解析纠偏异常接口返回的json,获取相应的字段值和逻辑处理
    def get_jpyc_data(js: JSONObject): ListBuffer[(String, String, String, String, String, String, String, String, String)] = {
        val myList = new ListBuffer[(String, String, String, String, String, String, String, String, String)]
        if (js != null) {
            val ret: Integer = js.getInteger("ret")
            if (ret == 0) {
                val bypassResult: JSONArray = js.getJSONArray("bypassResult")
                if (bypassResult != null && bypassResult.size() > 0) {
                    for (i <- 0 until bypassResult.size()) {
                        val obj: JSONObject = bypassResult.getJSONObject(i)
                        val angle: String = obj.getString("angle")
                        val existlimit: String = obj.getString("existlimit")
                        val lineid: String = obj.getString("lineid")
                        val linkid: String = obj.getString("linkid")
                        val mark_jp: String = obj.getString("mark")
                        val originroadclasslist: String = obj.getString("originroadclasslist")
                        val srcIdfrom: String = obj.getString("srcIdfrom")
                        val srcid: String = obj.getString("srcid")

                        val mynew: String = lineid + "_" + srcIdfrom
                        myList.append((mynew, angle, existlimit, lineid, linkid, mark_jp, originroadclasslist, srcIdfrom, srcid))
                    }
                }
            }

        }
        myList

    }

    // 规划的数据进行纠偏异常处理
    def planJPAbnormalDeal(logger: Logger,spark:SparkSession,planLimitedlDataSQL:String): Unit ={
        import spark.implicits._

        val planLimitedlDataDF: DataFrame = spark.sql(planLimitedlDataSQL)

        val planLimitedlMatchedResultDataDF: DataFrame = planLimitedlDataDF
          .repartition(20)
          .map(r => {
              val (uuid, data_source, d_plan_order, rulepos, json) = call_match_service(r)
              val tp: (String, String, Int, String, String, String, String, String, String, Int, Double, Int, Int, Int, Int, Int, String, String) = get_match_abnormal_data(uuid, data_source, d_plan_order, rulepos, json)
              tp
          })
          .toDF("uuid", "data_source", "d_plan_order", "rulepos", "r_status", "r_origin", "r_destination",
              "r_flen", "r_tlen", "r_distance", "r_duration", "r_highspeed_distance", "r_trafficlight_count",
              "r_tolls", "r_etc_toll", "r_toll_distance", "r_links_union", "r_rc_distance")
          .join(planLimitedlDataDF, Seq("uuid", "data_source", "d_plan_order", "rulepos"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedlMatchedResultDataDF, "规划的闯行数据,调用匹配服务之后的最终数据")


        val planLimitedlJPYCResultDataDF: DataFrame = planLimitedlMatchedResultDataDF
          .flatMap(r => {
              val arr: Array[Int] = Array(8, 81, 128, 130)
              val buff: ListBuffer[ListBuffer[(String, String, String, String, String, String, String, String, String)]] = new ListBuffer[ListBuffer[(String, String, String, String, String, String, String, String, String)]]
              for (elem <- arr) {
                  val json: JSONObject = call_jpyc_service(r, elem)
                  val myList: ListBuffer[(String, String, String, String, String, String, String, String, String)] = get_jpyc_data(json)
                  buff.append(myList)
              }

              val flattenBuff: ListBuffer[(String, String, String, String, String, String, String, String, String)] = buff.flatten
              flattenBuff
          })
          .repartition(200)
          .toDF("mynew", "angle", "existlimit", "lineid", "linkid", "mark_jp", "originroadclasslist", "srcIdfrom", "srcid")
          .dropDuplicates("mynew")
          .join(planLimitedlMatchedResultDataDF, Seq("mynew"), "right")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedlJPYCResultDataDF, "规划的数据，跑纠偏异常服务之后的数据")

        // 1.7 规划的数据  最终的数据 写入hive
        df2HiveByOverwrite(logger, planLimitedlJPYCResultDataDF, "dm_gis.mms_car_route_plan_detail_and_limited_info_his2")
        planLimitedlMatchedResultDataDF.unpersist()
    }

    // 纠偏的数据进行纠偏异常处理
    def jpJPAbnormalDeal(logger: Logger,spark:SparkSession,JPLimitedDataSQL:String): Unit={
        import spark.implicits._

        val JPLimitedDataDF: DataFrame = spark.sql(JPLimitedDataSQL)

        val JPLimitedlMatchedResultDataDF: DataFrame =JPLimitedDataDF
          .repartition(20)
          .map(r => {
              val (uuid, data_source, d_plan_order, rulepos, json) = call_match_service(r)
              val tp: (String, String, Int, String, String, String, String, String, String, Int, Double, Int, Int, Int, Int, Int, String, String) = get_match_abnormal_data(uuid, data_source, d_plan_order, rulepos, json)
              tp
          })
          .toDF("uuid", "data_source", "d_plan_order", "rulepos", "r_status", "r_origin", "r_destination",
              "r_flen", "r_tlen", "r_distance", "r_duration", "r_highspeed_distance", "r_trafficlight_count",
              "r_tolls", "r_etc_toll", "r_toll_distance", "r_links_union", "r_rc_distance")
          .join(JPLimitedDataDF, Seq("uuid", "data_source", "d_plan_order", "rulepos"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, JPLimitedlMatchedResultDataDF, "纠偏的闯行数据，调用匹配服务之后的最终数据")


        // 2.5 纠偏的数据 跑纠偏异常服务
        val JPLimitedlJPYCResultDataDF: DataFrame = JPLimitedlMatchedResultDataDF
          .flatMap(r => {
              val arr: Array[Int] = Array(8, 81, 128, 130)
              val buff: ListBuffer[ListBuffer[(String, String, String, String, String, String, String, String, String)]] = new ListBuffer[ListBuffer[(String, String, String, String, String, String, String, String, String)]]
              for (elem <- arr) {
                  val json: JSONObject = call_jpyc_service(r, elem)
                  val myList: ListBuffer[(String, String, String, String, String, String, String, String, String)] = get_jpyc_data(json)
                  buff.append(myList)
              }

              val flattenBuff: ListBuffer[(String, String, String, String, String, String, String, String, String)] = buff.flatten
              flattenBuff
          })
          .toDF("mynew", "angle", "existlimit", "lineid", "linkid", "mark_jp", "originroadclasslist", "srcIdfrom", "srcid")
          .dropDuplicates("mynew")
          .join(JPLimitedlMatchedResultDataDF, Seq("mynew"), "right")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, JPLimitedlJPYCResultDataDF, "纠偏的数据，跑纠偏异常服务之后的数据")

        // 2.7 纠偏的数据 最终的数据写入hive
        df2HiveByOverwrite(logger, JPLimitedlJPYCResultDataDF, "dm_gis.mms_car_route_jp_detail_and_limited_info_his2")
        JPLimitedlMatchedResultDataDF.unpersist()
    }

}
