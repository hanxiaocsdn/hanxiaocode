package app.runLimited

import app.runLimited.GetRoutePlanDataFromGDAndCTAndJY.interStatus2Hive
import app.runLimited.RunningLimitedServiceDataFromPlan.parseLimitedData
import com.alibaba.fastjson.{JSON, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.RunTrafficControlDataFromInter
import org.apache.spark.SparkContext
import org.apache.spark.sql._
import org.apache.spark.sql.functions.lit
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getVersion, testDF2Hive}
import utils.HttpClientUtil.getJsonByGet2
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable.ListBuffer

/**
  * 使用 纠偏的数据 跑闯行
  *
  * 4. 关联纠偏的数据，使用纠偏数据 跑闯行
  */
object RunningLimitedServiceDataFromJPV2 {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url2")
    val version_url: String = config.getString("version_url")


    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        // 接收外部传递进来的变量
        val UNIT_CSV_FILE_PATH: String = args(0)

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)
        val sc: SparkContext = spark.sparkContext

        // 获取csv文件数据
        val origJPDataDF: DataFrame = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("sep","\t")
          .load(UNIT_CSV_FILE_PATH)
          .cache()

        GetDFCountAndSampleData(logger,origJPDataDF,"CSV中的数据")

        // 跑闯行服务，获取相应的数据，并对数据做解析
        runLimitedServiceFromJP(logger, spark, origJPDataDF)


        logger.error("运行结束！")


        // 程序运行结束
        spark.stop()
    }

    // 调用闯行的接口
    def callLimitedRoute(r: Row): (String, String, Int, JSONObject) = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = 0

        var origin: String = ""
        var destination: String = ""
        val coords: String = r.getAs[String]("coords")
        val coordsArr: Array[String] = coords.split("\\|")
        for (i <- coordsArr.indices) {
            if (i == 0) origin = coordsArr(i)
            if (i == coordsArr.length - 1) destination = coordsArr(i)
        }

        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val emitStand: String = r.getAs[String]("emission")
        val energy: String = r.getAs[String]("energy")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val vehicle: String = r.getAs[String]("vehicle_type")
        val Mload: String = r.getAs[String]("vehicle_load_weight")
        val height: String = r.getAs[String]("height")
        val width: String = r.getAs[String]("width")
        val Size: String = r.getAs[String]("vehicle_length")
        val axlenumber: String = r.getAs[String]("axls_number")
        val No: String = r.getAs[String]("task_id")
        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&origin=$origin&destination=$destination&stype=0&etype=0&plate=$plate" +
          s"&plateColor=$plateColor&emitStand=$emitStand&energy=$energy&weight=$weight&vehicle=$vehicle&Mload=$Mload" +
          s"&height=$height&width=$width&Size=$Size&axlenumber=$axlenumber&passport=100000&mode=2&speed=1&No=$No&Toll=1&date=$date&len_diff=50&len_percent=0.5"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonStr: String = mapData.get("content").toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }

        (uuid, data_source, d_plan_order, json)
    }



    // 纠偏的数据跑闯行服务
    def runLimitedServiceFromJP(logger: Logger, spark: SparkSession, origJPDataDF: DataFrame): Unit = {
        import spark.implicits._

        val jpLimited: DataFrame = origJPDataDF
          .repartition(10)
          .flatMap(r => {
              val (uuid, data_source, d_plan_order, jsonData) = callLimitedRoute(r)
              val listBuf: ListBuffer[RunTrafficControlDataFromInter] = parseLimitedData(uuid, data_source, d_plan_order, jsonData)
              listBuf
          })
          .withColumn("inc_day",lit("20220624"))
          .repartition(200)
          .toDF()

        // 接口解析出的数据  和  原始数据关联上  --纠偏的数据
        val jpResultDF: DataFrame = origJPDataDF
          .drop("data_source")
          .join(jpLimited, "uuid")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger,jpResultDF,"纠偏的结果数据")

        // 对未闯行的数据写入hive表   -- 纠偏的数据
        val unLimited: Dataset[Row] = jpResultDF
          .filter("flag==false")

        testDF2Hive(logger, unLimited, "dm_gis.mms_car_route_jp_detail_and_unlimited_info_tmp20220624")

        // 对闯行的数据写入hive表   -- 纠偏的数据

        val limitedDF: Dataset[Row] = jpResultDF
          .filter("flag==true")

        testDF2Hive(logger, limitedDF, "dm_gis.mms_car_route_jp_detail_and_limited_info_tmp20220624")
    }

}