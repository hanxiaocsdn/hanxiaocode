package app.intelligentArea

import java.sql.{Connection, DriverManager, PreparedStatement}
import java.text.SimpleDateFormat
import java.util
import java.util.{Calendar, Properties}

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{DateUtil, DbUtil, SparkUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.hadoop.hdfs.web.JsonUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SaveMode, SparkSession}

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * 485968
 */
object AoiRecStat {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)
  val format = FastDateFormat.getInstance("yyyyMMdd")
  val formater = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
  var partition = 1

  var url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8mb4&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"

  case class StatObj(undercall:String, nocall:String, stat_type:String, stat_type_content:String, statdate:String, area:String, region:String, city:String, city_code:String, s_merge_cnt:Int, zc_cnt:Int, aoi_cnt:Int, gis_overview_cnt:Int, ks_cnt:Int, word_no_addr:Int, none_three_num:Int, no_three_num:Int, no_citycode:Int, dispatch_norm_cnt:Int, chk_cnt:Int, dispatch_chkn_cnt:Int, monthacc_cnt:Int, dispatch_normhp_cnt:Int, dispatch_tc2_cnt:Int, dispatch_road_cnt:Int, dispatch_phone_cnt:Int, dispatch_normcompany_cnt:Int, tc2_cnt:Int, norm_cnt:Int, dispatch_normhphd_cnt:Int, tel_his_cnt:Int, gd_poi_cnt:Int, y4_cnt:Int, y2_cnt:Int, company_cnt:Int, aoi_name_cnt:Int, n4_cnt:Int, y1_cnt:Int, tcmodel_cnt:Int, y5_cnt:Int, n2_cnt:Int, ks12_cnt:Int, tsxy_3_cnt:Int, standard_cnt:Int, n1_cnt:Int, aoi_80_similar_unique_cnt:Int, address_80_n:Int, n5_cnt:Int, tsxy_4_cnt:Int, aoi_80_recent_cnt:Int, aoi_80_similar_rate:Int, address_80_y_cnt:Int, y3_cnt:Int, translate_cnt:Int, n3_cnt:Int, tsxy_5_cnt:Int, sys_cnt:Int, aoiModel : Int, dispatch_phone_tel_cnt : Int, dispatch_phone_whitelist_cnt : Int)

  def main(args: Array[String]): Unit = {
    val date = args(0)
    logger.error(">>>处理日期:" + date)

    //val spark = SparkUtil.getSparkSession(appName)
    val spark = Spark.getSparkSession(appName)


//    val resultRdd = getCsvData(spark)
//    saveJSONObjectRDDToHiveNoPartition(spark,resultRdd,"citycode_area_map",Array("citycode","area"),Array("citycode","area"),"")


    if(args.length > 1 && "pj".equalsIgnoreCase(args(1))){
      logger.error("#######################"+args(1))
      sendPJ(spark, date)
    }
    else{
      //var saveMysqlF:(RDD[Array[Any]],String,Array[String],String)=>Unit = saveToMysql
      var saveMysqlF:(RDD[Array[Any]],String,Array[String],String)=>Unit = null
      var table = ""
      var structs:Array[String] = null
      var keys:Array[String] = null
      var table1 = ""
      var structs1:Array[String] = null
      var table2 = ""
      var structs2:Array[String] = null

      table1 = "SA_AOI_REC_DETAIL"
      structs1 = Array("UNDERCALL","NOCALL","STAT_TYPE","STAT_TYPE_CONTENT","STATDATE","AREA","REGION","CITY","CITY_CODE","S_MERGE_CNT","ZC_CNT","AOI_CNT","GIS_OVERVIEW_CNT","KS_CNT","WORD_NO_ADDR","NONE_THREE_NUM","NO_THREE_NUM","NO_CITYCODE","DISPATCH_NORM_CNT","CHK_CNT","DISPATCH_CHKN_CNT","MONTHACC_CNT","DISPATCH_NORMHP_CNT","DISPATCH_TC2_CNT","DISPATCH_ROAD_CNT","DISPATCH_PHONE_CNT","DISPATCH_NORMCOMPANY_CNT","TC2_CNT","NORM_CNT","DISPATCH_NORMHPHD_CNT","TEL_HIS_CNT","GD_POI_CNT","Y4_CNT","Y2_CNT","COMPANY_CNT","AOI_NAME_CNT","N4_CNT","Y1_CNT","TCMODEL_CNT","Y5_CNT","N2_CNT","KS12_CNT","TSXY_3_CNT","STANDARD_CNT","N1_CNT","AOI_80_SIMILAR_UNIQUE_CNT","ADDRESS_80_N","N5_CNT","TSXY_4_CNT","AOI_80_RECENT_CNT","AOI_80_SIMILAR_RATE","ADDRESS_80_Y_CNT","Y3_CNT","TRANSLATE_CNT","N3_CNT","TSXY_5_CNT","SYS_CNT","AOI_MODEL")
      table2 = "sa_aoi_rec_detail"
      structs2 = Array("undercall","nocall","stat_type","stat_type_content","statdate","area","region","city","city_code","s_merge_cnt","zc_cnt","aoi_cnt","gis_overview_cnt","ks_cnt","word_no_addr","none_three_num","no_three_num","no_citycode","dispatch_norm_cnt","chk_cnt","dispatch_chkn_cnt","monthacc_cnt","dispatch_normhp_cnt","dispatch_tc2_cnt","dispatch_road_cnt","dispatch_phone_cnt","dispatch_normcompany_cnt","tc2_cnt","norm_cnt","dispatch_normhphd_cnt","tel_his_cnt","gd_poi_cnt","y4_cnt","y2_cnt","company_cnt","aoi_name_cnt","n4_cnt","y1_cnt","tcmodel_cnt","y5_cnt","n2_cnt","ks12_cnt","tsxy_3_cnt","standard_cnt","n1_cnt","aoi_80_similar_unique_cnt","address_80_n","n5_cnt","tsxy_4_cnt","aoi_80_recent_cnt","aoi_80_similar_rate","address_80_y_cnt","y3_cnt","translate_cnt","n3_cnt","tsxy_5_cnt","sys_cnt","aoi_model","dispatch_phone_tel_cnt","dispatch_phone_whitelist_cnt")
      statSaveIndex(spark,null,statData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,date)

      val fields = "undercall,nocall,statdate,area,region,city,city_code,s_merge_cnt,zc_cnt,aoi_cnt,sys_cnt,gis_overview_cnt,ks_cnt,word_no_addr,none_three_num,no_three_num,no_citycode,dispatch_norm_cnt,chk_cnt,dispatch_chkn_cnt,monthacc_cnt,dispatch_normhp_cnt,dispatch_tc2_cnt,dispatch_road_cnt,dispatch_phone_cnt,dispatch_normcompany_cnt,tc2_cnt,norm_cnt,dispatch_normhphd_cnt,tel_his_cnt,gd_poi_cnt,y4_cnt,y2_cnt,company_cnt,aoi_name_cnt,n4_cnt,y1_cnt,tcmodel_cnt,y5_cnt,n2_cnt,ks12_cnt,tsxy_3_cnt,standard_cnt,n1_cnt,aoi_80_similar_unique_cnt,address_80_n,n5_cnt,tsxy_4_cnt,aoi_80_recent_cnt,aoi_80_similar_rate,address_80_y_cnt,y3_cnt,translate_cnt,n3_cnt,tsxy_5_cnt,aoi_model,dispatch_phone_tel_cnt,dispatch_phone_whitelist_cnt"
      val cond = " and stat_type='CITY' and undercall<>'ALL' and nocall<>'ALL'"
      hiveToClickhouse(spark, "gis_oms_uimp_rds.SA_AOI_REC_DETAIL", "dm_gis.sa_aoi_rec_detail", date, fields, cond)

//      for(_date<-"20221001,20221002,20221003,20221004,20221005,20221006,20221007,20221008,20221009,20221010,20221011,20221012,20221013,20221014".split(",")){
//        logger.error(">>>处理日期:" + _date)
//        statSaveIndex(spark,null,statData,saveMysqlF,saveArrayRDDToHive,table1,structs1,table2,structs2,_date)
//        hiveToClickhouse(spark, "gis_oms_uimp_rds.SA_AOI_REC_DETAIL", "dm_gis.sa_aoi_rec_detail", _date, fields, cond)
//      }
    }


    spark.stop()
    logger.error(">>>处理完毕---------------")
  }

  def sendPJ(spark:SparkSession, date:String): Unit = {
    val fields = "ordertype as order_type,inc_day as statdate,area,region,city,citycode as city_code,dispatch_cnt,dispatch_identify_cnt,system_identify_cnt,gis_identify_cnt,ks_identify_cnt,split_cnt,big_group_cnt,tc2_cnt,norm_cnt,chk_cnt,monthacc_cnt,dispatch_norm_cnt,dispatch_normhp_cnt,dispatch_chkn_cnt,dispatch_tc2_cnt,dispatch_road_cnt,dispatch_phone_cnt,dispatch_normhphd_cnt,dispatch_normcompany_cnt,n1_cnt,n2_cnt,n3_cnt,n4_cnt,n5_cnt,y1_cnt,y2_cnt,y3_cnt,y4_cnt,y5_cnt,ks12_cnt,tsxy3_cnt,tsxy4_cnt,tsxy5_cnt,company_cnt,tcmodel_cnt,standard_cnt,translate_cnt,tel_his_cnt,gd_poi_cnt,aoi_name_cnt,address80_n_cnt,address80_y_cnt,aoi_80_recent_cnt,aoi_80_similar_rate_cnt,aoi_80_similar_unique_cnt,aoi_model,dispatch_phone_tel_cnt,dispatch_phone_whitelist_cnt"
    //val fields = "ordertype,inc_day,area,region,city,citycode,dispatch_cnt,dispatch_identify_cnt,system_identify_cnt,gis_identify_cnt,ks_identify_cnt,split_cnt,big_group_cnt,tc2_cnt,norm_cnt,chk_cnt,monthacc_cnt,dispatch_norm_cnt,dispatch_normhp_cnt,dispatch_chkn_cnt,dispatch_tc2_cnt,dispatch_road_cnt,dispatch_phone_cnt,dispatch_normhphd_cnt,dispatch_normcompany_cnt,n1_cnt,n2_cnt,n3_cnt,n4_cnt,n5_cnt,y1_cnt,y2_cnt,y3_cnt,y4_cnt,y5_cnt,ks12_cnt,tsxy3_cnt,tsxy4_cnt,tsxy5_cnt,company_cnt,tcmodel_cnt,standard_cnt,translate_cnt,tel_his_cnt,gd_poi_cnt,aoi_name_cnt,address80_n_cnt,address80_y_cnt,aoi_80_recent_cnt,aoi_80_similar_rate_cnt,aoi_80_similar_unique_cnt,aoi_model"
    val cond = " and stat_type='CITY'"
    hiveToClickhouse(spark, "gis_oms_uimp_rds.SA_AOI_REC_DETAIL_PJ", "dm_gis.dispatch_idenfify_index", date, fields, cond)
  }


  def statSaveIndex(spark:SparkSession, parseRdd:RDD[JSONObject], statRddF:(SparkSession,String)=>RDD[Array[Any]], saveMysqlF:(RDD[Array[Any]],String,Array[String],String)=>Unit, saveHiveF:(SparkSession,RDD[Array[String]],String,Array[String],String,String)=>Unit, table1:String, structs1:Array[String], table2:String, structs2:Array[String], date:String): Unit ={
    var indexRdd:RDD[Array[Any]] = null
    indexRdd = statRddF(spark, date)
    if(saveMysqlF!=null){
      saveMysqlF(indexRdd,table1,structs1,date)
    }
    val indexRdd2 = indexRdd.map(array=>array.map(_.toString))
    indexRdd.unpersist()
    saveHiveF(spark,indexRdd2,table2,structs2,date,"")
    indexRdd2.unpersist()
  }


  def getCsvData(spark:SparkSession):RDD[JSONObject] ={
    val readDF = spark.read.format("csv").option("header","false").option("delimiter",",").option("multiLine","true").load("/user/01368978/upload/csv/citycode_area.csv")
    val resultRdd = readDF.na.fill("").rdd
      .map(row =>{
        val json = new JSONObject()
        json.put("citycode", row.getString(0))
        json.put("area", row.getString(1))
        json
      })
      .repartition(1).persist()
    logger.error(">>>数据量：" + resultRdd.count())

    resultRdd
  }


  def saveJSONObjectRDDToHiveNoPartition(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs:Array[String], keys:Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if(StringUtils.isEmpty(dataBase)) database = "dm_gis"
    else database = dataBase
    logger.error(">>>table=" + database + "." + table)
    spark.sql(s"use $database")
    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    val structType = DataTypes.createStructType(structFileds)
    val rowRdd = resultRdd.filter(_!=null).map(obj => {
      var row: Row = null
      try {
        val v = new Array[String](keys.length)
        for (i <- keys.indices) v(i) = JSONUtil.getJsonVal(obj, keys(i), "")
        row = RowFactory.create(v: _*)
      } catch {
        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
      }
      row
    }).filter(_ != null)
    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
    val tempView = String.format("%s_temp_view", table)
    df.createOrReplaceTempView(tempView)
    val deleteSql = String.format("truncate table %s", table)
    logger.error(">>>删除数据：" + deleteSql)
    spark.sql(deleteSql)
    spark.sql(String.format("insert overwrite table %s select * from %s", table, tempView))
    logger.error(">>>数据入hive库结束!")
  }


  def statData(spark:SparkSession, date:String):RDD[Array[Any]] ={
    //val date2 = DateUtil.getDateStr(date, -1)
    val date2 = com.sf.gis.scala.base.util.DateUtil.getDateStr(-4)
    val date3 = com.sf.gis.scala.base.util.DateUtil.getDateStr(-1)
    //val date3 = DateUtil.getDateStr(date, 2)
    var sql=""
    sql =
      s"""
         |select t4.area,t4.region,t4.city,get_json_object(t1.extra,'$$.citycode') as city_code,'CITY' as stat_type,t4.city as stat_type_content,t1.isnotundercall,t1.syssource as nocall,t1.split_info,case when t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end s_merge_cnt,case when t1.finalzc is not null and t1.finalzc<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end zc_cnt,case when ((t1.finalaoiid is not null and t1.finalaoiid<>'') or (get_json_object(t1.extra,'$$.zc_aoi') is not null and get_json_object(t1.extra,'$$.zc_aoi')<> '')) and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_cnt,case when t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end gis_overview_cnt,case when t1.ksaoicode is not null and t1.ksaoicode<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end ks_cnt,case when get_json_object(t1.extra,'$$.customeraccount') is not null and get_json_object(t1.extra,'$$.customeraccount')<>'' and get_json_object(t1.extra,'$$.customeraccount')<>'1234567890' and t2.p_customer_code is null and t3.p_customer_code is null and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end none_three_num,case when get_json_object(t1.extra,'$$.customeraccount') is not null and get_json_object(t1.extra,'$$.customeraccount')<>'' and get_json_object(t1.extra,'$$.customeraccount')<>'1234567890' and t2.p_customer_code is null and t3.p_customer_code is null and (t1.gisaoicode_rds is null or t1.gisaoicode_rds='') and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end no_three_num,case when t1.req_citycode='000' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end no_citycode,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-norm' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_norm_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='chk' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end chk_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-chkn' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_chkn_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='monthAcc' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end monthacc_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normhp' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normhp_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-tc2' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_tc2_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-road' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_road_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-phone' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_phone_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normcompany' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normcompany_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='tc2' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tc2_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='norm' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end norm_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normhphd' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normhphd_cnt,case when t1.ks_aoi_src='tel_His' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tel_his_cnt,case when t1.ks_aoi_src='gd_poi' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end gd_poi_cnt,case when t1.ks_aoi_src='Y4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y4_cnt,case when t1.ks_aoi_src='Y2' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y2_cnt,case when t1.ks_aoi_src='company' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end company_cnt,case when t1.ks_aoi_src='aoi_name' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_name_cnt,case when t1.ks_aoi_src='N4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n4_cnt,case when t1.ks_aoi_src='Y1' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y1_cnt,case when t1.ks_aoi_src='tcModel' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tcmodel_cnt,case when t1.ks_aoi_src='Y5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y5_cnt,case when t1.ks_aoi_src='N2' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n2_cnt,case when t1.ks_aoi_src='KS12' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end ks12_cnt,case when t1.ks_aoi_src='tsxy-3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_3_cnt,case when t1.ks_aoi_src='standard' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end standard_cnt,case when t1.ks_aoi_src='N1' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n1_cnt,case when t1.ks_aoi_src='aoi_80_similar_unique' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_similar_unique_cnt,case when t1.ks_aoi_src='80_address_N' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end address_80_n,case when t1.ks_aoi_src='N5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n5_cnt,case when t1.ks_aoi_src='tsxy-4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_4_cnt,case when t1.ks_aoi_src='aoi_80_recent' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_recent_cnt,case when t1.ks_aoi_src='aoi_80_similar_rate' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_similar_rate,case when t1.ks_aoi_src='80_address_Y' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end address_80_y_cnt,case when t1.ks_aoi_src='Y3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y3_cnt,case when t1.ks_aoi_src='translate' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end translate_cnt,case when t1.ks_aoi_src='N3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n3_cnt,case when t1.ks_aoi_src='tsxy-5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_5_cnt,case when ((t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'') or (t1.ksaoicode is not null and t1.ksaoicode<>'')) and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end sys_cnt
         |,case when t1.ks_aoi_src='aoiModel' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoiModel from
         |(select * from (select *,row_number() over (partition by waybillno order by operatime_new desc) rnk from dm_gis.aoi_accuracy_54_aoiname_ret_bsp where inc_day='$date') t where rnk=1) t1
         |left join (select distinct p_customer_code from dm_share.dm_share_cmdm_th_prot_result where is_valuable='是' and p_customer_code is not null and p_customer_code<>'') t2 on get_json_object(t1.extra,'$$.customeraccount')=t2.p_customer_code
         |left join (select distinct p_customer_code from dm_share.dm_share_cmdm_out_th_port where is_valuable='是' and p_customer_code is not null and p_customer_code<>'' and inc_day='$date2') t3 on get_json_object(t1.extra,'$$.customeraccount')=t3.p_customer_code
         |left join (select citycode,region,concat_ws('|', collect_list(city)) as city,max(area) as area from dm_gis.city_name_map group by citycode,region) t4 on get_json_object(t1.extra,'$$.citycode')=t4.citycode
       """.stripMargin
    sql =
      s"""
         |select t4.area,t4.region,t4.city,get_json_object(t1.extra,'$$.citycode') as city_code,'CITY' as stat_type,t4.city as stat_type_content,t1.isnotundercall,t1.syssource as nocall,t1.split_info,case when (t1.gisaoicode_rds is null or t1.gisaoicode_rds='') and (t1.ksaoicode is null or t1.ksaoicode='') then '1' else '0' end split_info_flag,case when t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end s_merge_cnt,case when t1.finalzc is not null and t1.finalzc<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end zc_cnt,case when ((t1.finalaoiid is not null and t1.finalaoiid<>'') or (get_json_object(t1.extra,'$$.zc_aoi') is not null and get_json_object(t1.extra,'$$.zc_aoi')<> '')) and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_cnt,case when t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end gis_overview_cnt,case when t1.ksaoicode is not null and t1.ksaoicode<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end ks_cnt,case when get_json_object(t1.extra,'$$.customeraccount') is not null and get_json_object(t1.extra,'$$.customeraccount')<>'' and get_json_object(t1.extra,'$$.customeraccount')<>'1234567890' and t2.p_customer_code is null and t3.p_customer_code is null and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end none_three_num,case when get_json_object(t1.extra,'$$.customeraccount') is not null and get_json_object(t1.extra,'$$.customeraccount')<>'' and get_json_object(t1.extra,'$$.customeraccount')<>'1234567890' and t2.p_customer_code is null and t3.p_customer_code is null and (t1.gisaoicode_rds is null or t1.gisaoicode_rds='') and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end no_three_num,case when t1.req_citycode='000' and (t1.gisaoicode_rds is null or t1.gisaoicode_rds='') and (t1.ksaoicode is null or t1.ksaoicode='') and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end no_citycode,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-norm' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_norm_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='chk' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end chk_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-chkn' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_chkn_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='monthAcc' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end monthacc_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normhp' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normhp_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-tc2' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_tc2_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-road' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_road_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-phone' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_phone_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normcompany' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normcompany_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='tc2' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tc2_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='norm' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end norm_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normhphd' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normhphd_cnt,case when t1.ks_aoi_src='tel_His' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tel_his_cnt,case when t1.ks_aoi_src='gd_poi' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end gd_poi_cnt,case when t1.ks_aoi_src='Y4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y4_cnt,case when t1.ks_aoi_src='Y2' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y2_cnt,case when t1.ks_aoi_src='company' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end company_cnt,case when t1.ks_aoi_src='aoi_name' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_name_cnt,case when t1.ks_aoi_src='N4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n4_cnt,case when t1.ks_aoi_src='Y1' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y1_cnt,case when t1.ks_aoi_src='tcModel' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tcmodel_cnt,case when t1.ks_aoi_src='Y5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y5_cnt,case when t1.ks_aoi_src='N2' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n2_cnt,case when t1.ks_aoi_src='KS12' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end ks12_cnt,case when t1.ks_aoi_src='tsxy-3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_3_cnt,case when t1.ks_aoi_src='standard' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end standard_cnt,case when t1.ks_aoi_src='N1' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n1_cnt,case when t1.ks_aoi_src='aoi_80_similar_unique' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_similar_unique_cnt,case when t1.ks_aoi_src='80_address_N' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end address_80_n,case when t1.ks_aoi_src='N5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n5_cnt,case when t1.ks_aoi_src='tsxy-4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_4_cnt,case when t1.ks_aoi_src='aoi_80_recent' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_recent_cnt,case when t1.ks_aoi_src='aoi_80_similar_rate' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_similar_rate,case when t1.ks_aoi_src='80_address_Y' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end address_80_y_cnt,case when t1.ks_aoi_src='Y3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y3_cnt,case when t1.ks_aoi_src='translate' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end translate_cnt,case when t1.ks_aoi_src='N3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n3_cnt,case when t1.ks_aoi_src='tsxy-5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_5_cnt,case when ((t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'') or (t1.ksaoicode is not null and t1.ksaoicode<>'')) and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end sys_cnt
         |,case when t1.ks_aoi_src='aoiModel' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoiModel from
         |(select * from (select *,row_number() over (partition by waybillno order by operatime_new desc) rnk from dm_gis.aoi_accuracy_54_aoiname_ret_bsp where inc_day='$date') t where rnk=1) t1
         |left join (select distinct p_customer_code from dm_share.dm_share_cmdm_th_prot_result where is_valuable='是' and p_customer_code is not null and p_customer_code<>'') t2 on get_json_object(t1.extra,'$$.customeraccount')=t2.p_customer_code
         |left join (select distinct p_customer_code from dm_share.dm_share_cmdm_out_th_port where is_valuable='是' and p_customer_code is not null and p_customer_code<>'' and inc_day='$date2') t3 on get_json_object(t1.extra,'$$.customeraccount')=t3.p_customer_code
         |left join (select citycode,region,concat_ws('|', collect_list(city)) as city,max(area) as area from dm_gis.city_name_map group by citycode,region) t4 on get_json_object(t1.extra,'$$.citycode')=t4.citycode
       """.stripMargin
    sql =
      s"""
         |select t5.area,t4.region,t4.city,get_json_object(t1.extra,'$$.citycode') as city_code,'CITY' as stat_type,t4.city as stat_type_content,t1.isnotundercall,t1.syssource as nocall,t1.split_info,case when (t1.gisaoicode_rds is null or t1.gisaoicode_rds='') and (t1.ksaoicode is null or t1.ksaoicode='') then '1' else '0' end split_info_flag,case when t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end s_merge_cnt,case when t1.finalzc is not null and t1.finalzc<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end zc_cnt,case when ((t1.finalaoiid is not null and t1.finalaoiid<>'') or (get_json_object(t1.extra,'$$.zc_aoi') is not null and get_json_object(t1.extra,'$$.zc_aoi')<> '')) and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_cnt,case when t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end gis_overview_cnt,case when t1.ksaoicode is not null and t1.ksaoicode<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end ks_cnt,case when get_json_object(t1.extra,'$$.customeraccount') is not null and get_json_object(t1.extra,'$$.customeraccount')<>'' and get_json_object(t1.extra,'$$.customeraccount')<>'1234567890' and t2.p_customer_code is null and t3.p_customer_code is null and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end none_three_num,case when get_json_object(t1.extra,'$$.customeraccount') is not null and get_json_object(t1.extra,'$$.customeraccount')<>'' and get_json_object(t1.extra,'$$.customeraccount')<>'1234567890' and t2.p_customer_code is null and t3.p_customer_code is null and (t1.gisaoicode_rds is null or t1.gisaoicode_rds='') and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end no_three_num,case when t1.req_citycode='000' and (t1.gisaoicode_rds is null or t1.gisaoicode_rds='') and (t1.ksaoicode is null or t1.ksaoicode='') and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end no_citycode,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-norm' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_norm_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='chk' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end chk_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-chkn' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_chkn_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='monthAcc' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end monthacc_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normhp' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normhp_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-tc2' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_tc2_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-road' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_road_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-phone' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_phone_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normcompany' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normcompany_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='tc2' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tc2_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='norm' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end norm_cnt,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-normhphd' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_normhphd_cnt,case when t1.ks_aoi_src='tel_His' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tel_his_cnt,case when t1.ks_aoi_src='gd_poi' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end gd_poi_cnt,case when t1.ks_aoi_src='Y4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y4_cnt,case when t1.ks_aoi_src='Y2' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y2_cnt,case when t1.ks_aoi_src='company' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end company_cnt,case when t1.ks_aoi_src='aoi_name' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_name_cnt,case when t1.ks_aoi_src='N4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n4_cnt,case when t1.ks_aoi_src='Y1' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y1_cnt,case when t1.ks_aoi_src='tcModel' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tcmodel_cnt,case when t1.ks_aoi_src='Y5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y5_cnt,case when t1.ks_aoi_src='N2' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n2_cnt,case when t1.ks_aoi_src='KS12' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end ks12_cnt,case when t1.ks_aoi_src='tsxy-3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_3_cnt,case when t1.ks_aoi_src='standard' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end standard_cnt,case when t1.ks_aoi_src='N1' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n1_cnt,case when t1.ks_aoi_src='aoi_80_similar_unique' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_similar_unique_cnt,case when t1.ks_aoi_src='80_address_N' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end address_80_n,case when t1.ks_aoi_src='N5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n5_cnt,case when t1.ks_aoi_src='tsxy-4' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_4_cnt,case when t1.ks_aoi_src='aoi_80_recent' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_recent_cnt,case when t1.ks_aoi_src='aoi_80_similar_rate' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoi_80_similar_rate,case when t1.ks_aoi_src='80_address_Y' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end address_80_y_cnt,case when t1.ks_aoi_src='Y3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end y3_cnt,case when t1.ks_aoi_src='translate' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end translate_cnt,case when t1.ks_aoi_src='N3' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end n3_cnt,case when t1.ks_aoi_src='tsxy-5' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end tsxy_5_cnt,case when ((t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'') or (t1.ksaoicode is not null and t1.ksaoicode<>'')) and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end sys_cnt
         |,case when t1.ks_aoi_src='aoiModel' and t1.ksaoicode is not null and t1.ksaoicode<>''and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end aoiModel
         |,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-phone-tel' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_phone_tel_cnt
         |,case when get_json_object(t1.extra,'$$.aoisrc')='dispatch-phone-whitelist' and t1.gisaoicode_rds is not null and t1.gisaoicode_rds<>'' and t1.waybillno is not null and t1.waybillno<>'' then '1' else '0' end dispatch_phone_whitelist_cnt
         |from
         |(select * from (select *,row_number() over (partition by waybillno order by operatime_new desc) rnk from dm_gis.aoi_accuracy_54_aoiname_ret_bsp where inc_day='$date') t where rnk=1) t1
         |left join (select distinct p_customer_code from dm_share.dm_share_cmdm_th_prot_result where is_valuable='是' and p_customer_code is not null and p_customer_code<>'') t2 on get_json_object(t1.extra,'$$.customeraccount')=t2.p_customer_code
         |left join (select distinct p_customer_code from dm_share.dm_share_cmdm_out_th_port where is_valuable='是' and p_customer_code is not null and p_customer_code<>'' and inc_day='$date2') t3 on get_json_object(t1.extra,'$$.customeraccount')=t3.p_customer_code
         |left join (select dist_code as citycode,area_name as region,city_name as city from dim.dim_city_info_df where inc_day ='$date3' and dist_code regexp '^\\\\d{3,4}$$') t4 on get_json_object(t1.extra,'$$.citycode')=t4.citycode
         |left join (select citycode,area from dm_gis.citycode_area_map) t5 on get_json_object(t1.extra,'$$.citycode')=t5.citycode
       """.stripMargin
    val logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()

        if(StringUtils.isEmpty(json.getString("nocall"))) json.put("nocall","")
        var word_no_addr = 1
        val split_info = json.getString("split_info")
        if(!StringUtils.isEmpty(split_info)){
          val splits = split_info.split(";")(0).split("\\|")
          if(splits!=null && splits.size >0){
            breakable(
              for(i<-0.until(splits.size)){
                val split = splits(splits.size - 1 - i)
                if(!StringUtils.isEmpty(split)){
                  val temps = split.split("\\^")
                  if(temps!=null && temps.size >1){
                    val level = temps(1)
                    if(!StringUtils.isEmpty(level)){
                      val value = level.substring(1).toInt
                      if(value > 10) {
                        word_no_addr = 0
                        break
                      }
                    }
                  }
                }
              }
            )
          }
        }

        if(word_no_addr == 1){
          val split_info_flag = json.getString("split_info_flag")
          if("0".equalsIgnoreCase(split_info_flag)) word_no_addr = 0
        }

        var undercall = ""
        if("1".equalsIgnoreCase(json.getString("isnotundercall"))) undercall = "非call"
        else{
          undercall = "下call"
          json.put("nocall","")
        }

        json.put("word_no_addr", word_no_addr)
        json.put("undercall", undercall)

        list += json
        val city_code = json.getString("city_code")
        if(StringUtils.isEmpty(city_code) || !"886,853,852".split(",").contains(city_code)){

          val newJson1 = new JSONObject()
          newJson1.fluentPutAll(json)
          newJson1.put("stat_type", "ALL")
          newJson1.put("stat_type_content", "ALL")
          newJson1.put("area", "ALL")
          newJson1.put("region", "ALL")
          newJson1.put("city", "ALL")
          newJson1.put("city_code", "ALL")
          list += newJson1

          val newJson2 = new JSONObject()
          newJson2.fluentPutAll(json)
          newJson2.put("stat_type", "AREA")
          newJson2.put("stat_type_content", json.getString("area"))
          newJson2.put("region", "ALL")
          newJson2.put("city", "ALL")
          newJson2.put("city_code", "ALL")
          list += newJson2

          val newJson3 = new JSONObject()
          newJson3.fluentPutAll(json)
          newJson3.put("stat_type", "REGION")
          newJson3.put("stat_type_content", json.getString("region"))
          newJson3.put("city", "ALL")
          newJson3.put("city_code", "ALL")
          list += newJson3

          val newJson4 = new JSONObject()
          newJson4.fluentPutAll(json)
          newJson4.put("stat_type", "ALL")
          newJson4.put("stat_type_content", "ALL")
          newJson4.put("area", "ALL")
          newJson4.put("region", "ALL")
          newJson4.put("city", "ALL")
          newJson4.put("city_code", "ALL")
          newJson4.put("undercall", "ALL")
          newJson4.put("nocall", "ALL")
          list += newJson4

          val newJson5 = new JSONObject()
          newJson5.fluentPutAll(json)
          newJson5.put("stat_type", "AREA")
          newJson5.put("stat_type_content", json.getString("area"))
          newJson5.put("region", "ALL")
          newJson5.put("city", "ALL")
          newJson5.put("city_code", "ALL")
          newJson5.put("undercall", "ALL")
          newJson5.put("nocall", "ALL")
          list += newJson5

          val newJson6 = new JSONObject()
          newJson6.fluentPutAll(json)
          newJson6.put("stat_type", "REGION")
          newJson6.put("stat_type_content", json.getString("region"))
          newJson6.put("city", "ALL")
          newJson6.put("city_code", "ALL")
          newJson6.put("undercall", "ALL")
          newJson6.put("nocall", "ALL")
          list += newJson6

          val newJson7 = new JSONObject()
          newJson7.fluentPutAll(json)
          newJson7.put("undercall", "ALL")
          newJson7.put("nocall", "ALL")
          list += newJson7

          if("1".equalsIgnoreCase(json.getString("isnotundercall"))){
            val newJson8 = new JSONObject()
            newJson8.fluentPutAll(json)
            newJson8.put("stat_type", "ALL")
            newJson8.put("stat_type_content", "ALL")
            newJson8.put("area", "ALL")
            newJson8.put("region", "ALL")
            newJson8.put("city", "ALL")
            newJson8.put("city_code", "ALL")
            newJson8.put("nocall", "ALL")
            list += newJson8

            val newJson9 = new JSONObject()
            newJson9.fluentPutAll(json)
            newJson9.put("stat_type", "AREA")
            newJson9.put("stat_type_content", json.getString("area"))
            newJson9.put("region", "ALL")
            newJson9.put("city", "ALL")
            newJson9.put("city_code", "ALL")
            newJson9.put("nocall", "ALL")
            list += newJson9

            val newJson10 = new JSONObject()
            newJson10.fluentPutAll(json)
            newJson10.put("stat_type", "REGION")
            newJson10.put("stat_type_content", json.getString("region"))
            newJson10.put("city", "ALL")
            newJson10.put("city_code", "ALL")
            newJson10.put("nocall", "ALL")
            list += newJson10

            val newJson11 = new JSONObject()
            newJson11.fluentPutAll(json)
            newJson11.put("nocall", "ALL")
            list += newJson11
          }

        }

        list
      })

      .map(json=>{
        var undercall = json.getString("undercall")
        var nocall = json.getString("nocall")
        var stat_type = json.getString("stat_type")
        var stat_type_content = json.getString("stat_type_content")
        var area = json.getString("area")
        var region = json.getString("region")
        var city = json.getString("city")
        var city_code = json.getString("city_code")

        val obj = StatObj(undercall,nocall,stat_type,stat_type_content,date,area,region,city,city_code,json.getIntValue("s_merge_cnt"),json.getIntValue("zc_cnt"),json.getIntValue("aoi_cnt"),json.getIntValue("gis_overview_cnt"),json.getIntValue("ks_cnt"),json.getIntValue("word_no_addr"),json.getIntValue("none_three_num"),json.getIntValue("no_three_num"),json.getIntValue("no_citycode"),json.getIntValue("dispatch_norm_cnt"),json.getIntValue("chk_cnt"),json.getIntValue("dispatch_chkn_cnt"),json.getIntValue("monthacc_cnt"),json.getIntValue("dispatch_normhp_cnt"),json.getIntValue("dispatch_tc2_cnt"),json.getIntValue("dispatch_road_cnt"),json.getIntValue("dispatch_phone_cnt"),json.getIntValue("dispatch_normcompany_cnt"),json.getIntValue("tc2_cnt"),json.getIntValue("norm_cnt"),json.getIntValue("dispatch_normhphd_cnt"),json.getIntValue("tel_his_cnt"),json.getIntValue("gd_poi_cnt"),json.getIntValue("y4_cnt"),json.getIntValue("y2_cnt"),json.getIntValue("company_cnt"),json.getIntValue("aoi_name_cnt"),json.getIntValue("n4_cnt"),json.getIntValue("y1_cnt"),json.getIntValue("tcmodel_cnt"),json.getIntValue("y5_cnt"),json.getIntValue("n2_cnt"),json.getIntValue("ks12_cnt"),json.getIntValue("tsxy_3_cnt"),json.getIntValue("standard_cnt"),json.getIntValue("n1_cnt"),json.getIntValue("aoi_80_similar_unique_cnt"),json.getIntValue("address_80_n"),json.getIntValue("n5_cnt"),json.getIntValue("tsxy_4_cnt"),json.getIntValue("aoi_80_recent_cnt"),json.getIntValue("aoi_80_similar_rate"),json.getIntValue("address_80_y_cnt"),json.getIntValue("y3_cnt"),json.getIntValue("translate_cnt"),json.getIntValue("n3_cnt"),json.getIntValue("tsxy_5_cnt"),json.getIntValue("sys_cnt"),json.getIntValue("aoiModel"),json.getIntValue("dispatch_phone_tel_cnt"),json.getIntValue("dispatch_phone_whitelist_cnt"))
        ((undercall,nocall,stat_type,stat_type_content,date,area,region,city,city_code),obj)
      })
      .reduceByKey((o1,o2)=>{
        StatObj(o1.undercall,o1.nocall,o1.stat_type,o1.stat_type_content,o1.statdate,o1.area,o1.region,o1.city,o1.city_code,o1.s_merge_cnt + o2.s_merge_cnt,o1.zc_cnt + o2.zc_cnt,o1.aoi_cnt + o2.aoi_cnt,o1.gis_overview_cnt + o2.gis_overview_cnt,o1.ks_cnt + o2.ks_cnt,o1.word_no_addr + o2.word_no_addr,o1.none_three_num + o2.none_three_num,o1.no_three_num + o2.no_three_num,o1.no_citycode + o2.no_citycode,o1.dispatch_norm_cnt + o2.dispatch_norm_cnt,o1.chk_cnt + o2.chk_cnt,o1.dispatch_chkn_cnt + o2.dispatch_chkn_cnt,o1.monthacc_cnt + o2.monthacc_cnt,o1.dispatch_normhp_cnt + o2.dispatch_normhp_cnt,o1.dispatch_tc2_cnt + o2.dispatch_tc2_cnt,o1.dispatch_road_cnt + o2.dispatch_road_cnt,o1.dispatch_phone_cnt + o2.dispatch_phone_cnt,o1.dispatch_normcompany_cnt + o2.dispatch_normcompany_cnt,o1.tc2_cnt + o2.tc2_cnt,o1.norm_cnt + o2.norm_cnt,o1.dispatch_normhphd_cnt + o2.dispatch_normhphd_cnt,o1.tel_his_cnt + o2.tel_his_cnt,o1.gd_poi_cnt + o2.gd_poi_cnt,o1.y4_cnt + o2.y4_cnt,o1.y2_cnt + o2.y2_cnt,o1.company_cnt + o2.company_cnt,o1.aoi_name_cnt + o2.aoi_name_cnt,o1.n4_cnt + o2.n4_cnt,o1.y1_cnt + o2.y1_cnt,o1.tcmodel_cnt + o2.tcmodel_cnt,o1.y5_cnt + o2.y5_cnt,o1.n2_cnt + o2.n2_cnt,o1.ks12_cnt + o2.ks12_cnt,o1.tsxy_3_cnt + o2.tsxy_3_cnt,o1.standard_cnt + o2.standard_cnt,o1.n1_cnt + o2.n1_cnt,o1.aoi_80_similar_unique_cnt + o2.aoi_80_similar_unique_cnt,o1.address_80_n + o2.address_80_n,o1.n5_cnt + o2.n5_cnt,o1.tsxy_4_cnt + o2.tsxy_4_cnt,o1.aoi_80_recent_cnt + o2.aoi_80_recent_cnt,o1.aoi_80_similar_rate + o2.aoi_80_similar_rate,o1.address_80_y_cnt + o2.address_80_y_cnt,o1.y3_cnt + o2.y3_cnt,o1.translate_cnt + o2.translate_cnt,o1.n3_cnt + o2.n3_cnt,o1.tsxy_5_cnt + o2.tsxy_5_cnt,o1.sys_cnt + o2.sys_cnt,o1.aoiModel + o2.aoiModel,o1.dispatch_phone_tel_cnt + o2.dispatch_phone_tel_cnt,o1.dispatch_phone_whitelist_cnt + o2.dispatch_phone_whitelist_cnt)
      }).values
      .map(o1=>{
        Array(o1.undercall,o1.nocall,o1.stat_type,o1.stat_type_content,o1.statdate,o1.area,o1.region,o1.city,o1.city_code,o1.s_merge_cnt,o1.zc_cnt,o1.aoi_cnt,o1.gis_overview_cnt,o1.ks_cnt,o1.word_no_addr,o1.none_three_num,o1.no_three_num,o1.no_citycode,o1.dispatch_norm_cnt,o1.chk_cnt,o1.dispatch_chkn_cnt,o1.monthacc_cnt,o1.dispatch_normhp_cnt,o1.dispatch_tc2_cnt,o1.dispatch_road_cnt,o1.dispatch_phone_cnt,o1.dispatch_normcompany_cnt,o1.tc2_cnt,o1.norm_cnt,o1.dispatch_normhphd_cnt,o1.tel_his_cnt,o1.gd_poi_cnt,o1.y4_cnt,o1.y2_cnt,o1.company_cnt,o1.aoi_name_cnt,o1.n4_cnt,o1.y1_cnt,o1.tcmodel_cnt,o1.y5_cnt,o1.n2_cnt,o1.ks12_cnt,o1.tsxy_3_cnt,o1.standard_cnt,o1.n1_cnt,o1.aoi_80_similar_unique_cnt,o1.address_80_n,o1.n5_cnt,o1.tsxy_4_cnt,o1.aoi_80_recent_cnt,o1.aoi_80_similar_rate,o1.address_80_y_cnt,o1.y3_cnt,o1.translate_cnt,o1.n3_cnt,o1.tsxy_5_cnt,o1.sys_cnt,o1.aoiModel,o1.dispatch_phone_tel_cnt,o1.dispatch_phone_whitelist_cnt)
      })
      .repartition(1).persist()
    logger.error(">>>指标统计后的数据量："+resultRdd.count())

    logRdd.unpersist()
    resultRdd
  }


  def getValidJson(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(6400).map(row=>{
      val json = new JSONObject()
      for(i<-fields.indices){
        json.put(header(i),row.get(i))
      }
      json
    }).filter(_!=null).repartition(6400).persist()
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }


  def saveArrayRDDToHive(spark: SparkSession, resultRdd: RDD[Array[String]], table: String, structs:Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if(StringUtils.isEmpty(dataBase)) database = "dm_gis"
    else database = dataBase
    try {
      logger.error(">>>table=" + database + "." + table)
      spark.sql(s"use $database")
      //1 构造DataFrame的元数据 StructField
      val structFileds = new util.ArrayList[StructField]()
      for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
      //2 构建StructType用于DataFrame的元数据描述
      val structType = DataTypes.createStructType(structFileds)
      //3 构建Row格式数据集RDD[Row]
      val rowRdd = resultRdd.filter(_!=null).map(v => {
        var row: Row = null
        try {
          row = RowFactory.create(v: _*)
        } catch {
          case e: Exception => logger.error(">>>构造row异常:" + e + "," + v)
        }
        row
      }).filter(_ != null)
      // 4 构建DataFrame
      val df: DataFrame = spark.createDataFrame(rowRdd, structType)
      //5 基于Datarame创建临时表
      val tempView = String.format("%s_temp_view", table)
      df.createOrReplaceTempView(tempView)
      //6 分区、表等操作
      val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
      logger.error(">>>删除分区：" + deleteSql)
      spark.sql(deleteSql)
      val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
      logger.error(">>>新建分区：" + createPartitionSql)
      spark.sql(createPartitionSql)
      //7 把临时表的数据刷进hive表中
      spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
      logger.error(">>>数据入hive库结束!")
    }
    catch {
      case e:Exception =>logger.error(">>>" + database + "." + table + "数据入库异常："+e)
    }
  }


  /*def saveToMysql(indexRdd:RDD[Array[Any]],table:String,structs:Array[String],date:String): Unit ={
    try {
      val connection = getConnection()
      val fields = structs.mkString(",")
      val values = structs.map(_=>"?").mkString(",")
      val deleteSql = s"DELETE FROM $table WHERE STATDATE='$date'"
      println(">>>清除当日数据："+deleteSql)
      DbUtil.execute(connection,deleteSql,null)
      val params = indexRdd.collect().toList
      logger.error(">>>当日统计指标数据量："+params.size)
      val insertSql =
        s"""
           |INSERT INTO $table ($fields)
           |VALUES ($values)
             """.stripMargin
      DbUtil.batchListExecute(connection,insertSql,params)
      connection.close()
      logger.error(">>>指标入mysql库的" + table + "表结束！")
    } catch {
      case e:Exception=>logger.error(">>>指标mysql库的" + table + "异常："+e)
    }
  }*/


  def getConnection(): Connection ={
    Class.forName("com.mysql.jdbc.Driver").newInstance()
    @transient val connection = DriverManager.getConnection(url,"gis_oms_rds","gis_oms_rds@123@")
    connection
  }

  def hiveToClickhouse(spark: SparkSession, chTable: String, hiveTable: String, date: String, fields:String, cond:String=""): Unit = {
    val driver = "ru.yandex.clickhouse.ClickHouseDriver"
    val base_url = "jdbc:clickhouse://10.216.162.10:8123/"//todo
    val db = "gis_oms_uimp_rds"//todo
    val ch_url = s"$base_url$db"
    val user = "gis_oms_rds"//todo
    val password = "gis_oms_rds@123@"//todo
    val conn: Connection = getCHConnect(driver,ch_url,user,password)
    val params = Map[String, String]("driver" -> driver, "batchsize" -> "20000", "isolationLevel" -> "NONE", "numPartitions" -> "1", "user" -> user, "password" -> password)


    val delSql = s"alter table $chTable drop partition '$date'"//todo
    val hiveSelectSql =
      s"""
         |select $fields from $hiveTable where inc_day='$date' $cond
         """.stripMargin//todo inc_day

    execute(conn, delSql)
    write(spark, hiveSelectSql, ch_url, params, chTable)
  }

  def execute(conn: Connection, sql: String): Unit = {
    logger.error(">>>execute-sql:" + sql)
    conn.prepareStatement(sql).execute()
  }

  def write(spark: SparkSession, sql: String, url:String, params:Map[String, String], table:String): Unit = {
    logger.error(">>>write-data-sql:" + sql)
    spark.sql(sql).write.mode(SaveMode.Append).options(params).jdbc(url, table, new Properties())
  }

  def getCHConnect(driver:String, url:String, username:String, password:String): Connection = {
    Class.forName(driver)
    DriverManager.getConnection(url, username, password)
  }


}
