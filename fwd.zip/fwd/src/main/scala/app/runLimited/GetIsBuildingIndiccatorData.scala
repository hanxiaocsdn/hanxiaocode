package app.runLimited

import app.runLimited.DealLocusAbnormalDataFromLimited.get_distance2
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.{IsBuilding, SwidAndPoint}
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window, WindowSpec}
import org.apache.spark.sql.functions.{collect_list, concat_ws, lead, lit, row_number, substring, udf}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.HttpClientUtil.getJsonByGet
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable.ListBuffer

/**
  * 每日自动获取状态为在建的道路数据，发送到线下作业
  */
object GetIsBuildingIndiccatorData {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")
    val road_attr_url: String = config.getString("road_attr_url")

    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        if (args.length != 4) {
            logger.error(
                """
                  |需要输入4个参数：
                  |    start_time、end_time、two_month_ago、current_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val two_month_ago: String = args(2)
        val current_time: String = args(3)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"2个月前的日期：$two_month_ago ")
        logger.error(s"当前日期：$current_time ")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        // 获取在建的数据
        val isBuildingSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_and_jp_limited_result_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day <'$end_time'
               |  and data_source='0'
               |  and ruletype = '在建'
               |  and mark_dist = 0
               |  and (srcIdfrom = '' or srcIdfrom is null)
               |  and mark in(-1,0,4)
               |  and (d_frequency ='' or cast(d_frequency as int) > 3)
               |  and (limitsize is null or limitsize = '' or cast(limitsize as double) <= 4.2)
               |""".stripMargin

        // 获取近2个月已经下发的数据
        val issuSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_isbuilding_data_issue_info
               |where
               |  inc_day >= '$two_month_ago'
               |  and inc_day <'$start_time'
               |""".stripMargin

        logger.error(isBuildingSql)
        logger.error(issuSql)

        val isBuildingDF: DataFrame = spark
          .sql(isBuildingSql)
          .persist(StorageLevel.MEMORY_AND_DISK)

        val issuDF: DataFrame = spark
          .sql(issuSql)

        // 获取在建道路数据
        GetDFCountAndSampleData(logger, isBuildingDF, "在建道路")

        // isbuilding_swid 和 轨迹起始点
        val isbuilding_swidDF: DataFrame = isBuildingDF
          .dropDuplicates("rulepos", "ruleroadid")
          .repartition(5)
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val data_source: String = r.getAs[String]("data_source")
              val d_plan_order: Int = r.getAs[Int]("d_plan_order")
              val rulepos: String = r.getAs[String]("rulepos")
              val ruleroadid: String = r.getAs[String]("ruleroadid")
              val start_dept: String = r.getAs[String]("start_dept")
              val end_dept: String = r.getAs[String]("end_dept")
              val adcode: String = r.getAs[String]("adcode")
              val version: String = r.getAs[String]("version")
              val inc_day: String = r.getAs[String]("inc_day")

              val json: JSONObject = call_match_route(r)
              val isbuilding_swid_Buff: ListBuffer[String] = get_match_data(json)

              var isbuilding_swid: String = ""
              if (isbuilding_swid_Buff.nonEmpty) {
                  isbuilding_swid = isbuilding_swid_Buff.mkString("|")
              }

              val j: JSONObject = call_road_attr_inter(ruleroadid)
              val (startpos_x, startpos_y, endpos_x, endpos_y) = get_road_attr_data2(j)

              SwidAndPoint(uuid, data_source, d_plan_order, rulepos, ruleroadid, start_dept, end_dept, isbuilding_swid,
                  startpos_x, startpos_y, endpos_x, endpos_y, adcode, version, inc_day)
          })
          .repartition(200)
          .toDF
          .filter("isbuilding_swid != ''")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 获取在建道路的isbuilding_swid 和 轨迹起始点
        GetDFCountAndSampleData(logger, isbuilding_swidDF, "在建道路的isbuilding_swid 和 轨迹起始点")

        // 按照距离添加groupby_id
        val groupByIdDF1: DataFrame = isbuilding_swidDF
          .rdd
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val data_source: String = r.getAs[String]("data_source")
              val d_plan_order: Int = r.getAs[Int]("d_plan_order")
              ((uuid, data_source, d_plan_order), r)
          })
          .groupByKey()
          .flatMap(r => {
              val (uuid, data_source, d_plan_order) = r._1
              val uid: String = uuid + "_" + data_source + "_" + d_plan_order
              val rowsList: List[Row] = r._2.toList

              var groupby_id: String = uid + "_0"

              val rowsBuff = new ListBuffer[IsBuilding]
              if (rowsList.size >= 2) {
                  val rows: ListBuffer[Row] = get_ordered_rows(rowsList)
                  var num: Int = 0
                  var dist: Double = 0.0
                  for (i <- rows.indices) {
                      val rulepos: String = rows(i).getAs[String]("rulepos")
                      val ruleroadid: String = rows(i).getAs[String]("ruleroadid")
                      val start_dept: String = rows(i).getAs[String]("start_dept")
                      val end_dept: String = rows(i).getAs[String]("end_dept")
                      val isbuilding_swid: String = rows(i).getAs[String]("isbuilding_swid")
                      val adcode: String = rows(i).getAs[String]("adcode")
                      val version: String = rows(i).getAs[String]("version")
                      val inc_day: String = rows(i).getAs[String]("inc_day")

                      // 第1个点的起始坐标
                      val startpos_x: Double = rows(i).getAs[Double]("startpos_x")
                      val startpos_y: Double = rows(i).getAs[Double]("startpos_y")
                      val endpos_x: Double = rows(i).getAs[Double]("endpos_x")
                      val endpos_y: Double = rows(i).getAs[Double]("endpos_y")

                      if (i < rows.size - 1) {
                          // 第2个点的起始坐标
                          val startpos_x2: Double = rows(i + 1).getAs[Double]("startpos_x")
                          val startpos_y2: Double = rows(i + 1).getAs[Double]("startpos_y")
                          val endpos_x2: Double = rows(i + 1).getAs[Double]("endpos_x")
                          val endpos_y2: Double = rows(i + 1).getAs[Double]("endpos_y")


                          val dist1: Double = get_distance2(startpos_x2, startpos_y2, endpos_x, endpos_y) * 1000
                          val dist2: Double = get_distance2(startpos_x, startpos_y, endpos_x2, endpos_y2) * 1000

                          dist = math.min(dist1, dist2)
                          if (dist > 100) {
                              groupby_id = uid + "_" + +num
                              num += 1
                          } else groupby_id = uid + "_" + +num

                      } else groupby_id = uid + "_" + num

                      rowsBuff.append(IsBuilding(rulepos, ruleroadid, uid, start_dept, end_dept, isbuilding_swid, groupby_id, adcode, version, inc_day))
                  }
              } else {
                  val list: List[Row] = rowsList
                  val row: Row = list.head

                  val rulepos: String = row.getAs[String]("rulepos")
                  val ruleroadid: String = row.getAs[String]("ruleroadid")
                  val start_dept: String = row.getAs[String]("start_dept")
                  val end_dept: String = row.getAs[String]("end_dept")
                  val isbuilding_swid: String = row.getAs[String]("isbuilding_swid")
                  val adcode: String = row.getAs[String]("adcode")
                  val version: String = row.getAs[String]("version")
                  val inc_day: String = row.getAs[String]("inc_day")

                  rowsBuff.append(IsBuilding(rulepos, ruleroadid, uid, start_dept, end_dept, isbuilding_swid, groupby_id, adcode, version, inc_day))
              }

              rowsBuff
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, groupByIdDF1, "添加groupby_id后的数据")

        // 添加 isbuilding_point
        val w1: WindowSpec = Window.partitionBy("uid").orderBy($"groupby_id".asc)
        val groupByIdDF2: DataFrame = groupByIdDF1
          .withColumn("next_ruleroadid", lead("ruleroadid", 1, "-1").over(w1))
          .withColumn("rn", row_number().over(w1))
          .withColumn("ruleroadid2", get_ruleroadid2($"ruleroadid", $"rn", $"isbuilding_swid"))
          .withColumn("isbuilding_swid_tmp", get_isbuilding_swid($"ruleroadid2", $"next_ruleroadid", $"isbuilding_swid"))
          .groupBy("groupby_id")
          .agg(concat_ws("|", collect_list("isbuilding_swid_tmp")).alias("isbuilding_swid"))
          .coalesce(5)
          .withColumn("isbuilding_point", get_isbuilding_point($"isbuilding_swid"))
          .repartition(300)


        val groupByIdDF: Dataset[Row] = groupByIdDF1
          .drop("isbuilding_swid")
          .join(groupByIdDF2, Seq("groupby_id"))
          .filter("adcode != ''")
          .select("rulepos", "ruleroadid", "uid", "start_dept", "end_dept", "isbuilding_swid", "isbuilding_point", "groupby_id", "adcode", "version", "inc_day")
          .withColumn("area_code", substring($"adcode", 1, 4))
          .withColumn("sample_batch", concat_ws("_", $"inc_day", $"inc_day"))
          .withColumn("tast_tm", lit(current_time))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .coalesce(200)
          .persist(StorageLevel.MEMORY_AND_DISK)


        // 获取在建道路的swid 和 轨迹起始点
        GetDFCountAndSampleData(logger, groupByIdDF, "groupby_id的数据")
        isbuilding_swidDF.unpersist()
        isBuildingDF.unpersist()

        // 根据groupby_id去重
        val groupByIddDropDupedDF: Dataset[Row] = groupByIdDF
          .join(issuDF, Seq("rulepos", "ruleroadid"), "leftanti")
          .dropDuplicates("groupby_id")
          .coalesce(100)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, groupByIddDropDupedDF, "根据groupby_id去重之后的数据")

        // 写入到hive
        df2HiveByOverwrite(logger, groupByIdDF, "dm_gis.mms_isbuilding_data_info")
        groupByIdDF.unpersist()

        df2HiveByOverwrite(logger, groupByIddDropDupedDF, "dm_gis.mms_isbuilding_data_issue_info")
        groupByIddDropDupedDF.unpersist()



        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 调用线路匹配的接口
    def call_match_route(r: Row): JSONObject = {

        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")

        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&date=$date&test=1&stype=0&etype=0&passport=100000&mode=2&speed=1&Toll=1"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonStr: String = mapData.get("content").toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:"+e.getMessage)
        }

        json
    }

    // 解析匹配接口返回的json,获取相应的字段值和逻辑处理
    def get_match_data(js: JSONObject): ListBuffer[String] = {
        val isbuilding_swid: ListBuffer[String] = new ListBuffer[String]

        if(js != null){
            val status: String = js.getString("status")
            if (status == "0") {
                val route: JSONObject = js.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")
                if (paths != null && paths.size() > 0) {
                    val pathsLen: Int = paths.size()
                    for (i <- 0 until pathsLen) {
                        val path: JSONObject = paths.getJSONObject(i)
                        val outinfo: JSONObject = path.getJSONObject("outinfo")
                        if (outinfo != null && outinfo.size() > 0) {
                            val links: JSONArray = outinfo.getJSONArray("links")
                            if (links != null && links.size() > 0) {
                                val linksLen: Int = links.size()
                                for (i <- 0 until linksLen) {
                                    val link: JSONObject = links.getJSONObject(i)
                                    if (link.containsKey("isbuilding") && link.getString("isbuilding") == "1") isbuilding_swid.append(link.getString("swid"))
                                }
                            }
                        }

                    }


                }

            }
        }

        isbuilding_swid
    }

    // 调用road_attr接口
    def call_road_attr_inter(swid: String): JSONObject = {
        val sd: String = "swId=" + swid
        val url: String = road_attr_url + sd
        val jsonData: JSONObject = getJsonByGet(url = url, 6, "utf-8")
        jsonData
    }

    // 解析road_attr接口返回的json
    def get_road_attr_data(js: JSONObject): ListBuffer[String] = {
        var xy_listBuff: ListBuffer[String] = new ListBuffer[String]

        val line: JSONObject = js.getJSONObject("line")
        if (line != null && line.size() > 0) {
            val polyline: JSONArray = line.getJSONArray("polyline")
            if (!polyline.isEmpty) {
                val tp: ListBuffer[(Int, Int)] = new ListBuffer[(Int, Int)]
                for (i <- 0 until polyline.size()) {
                    if (i == 0) {
                        val x: Int = polyline.getJSONObject(i).getIntValue("x")
                        val y: Int = polyline.getJSONObject(i).getIntValue("y")
                        tp.append((x, y))
                    } else {
                        val x1: Int = polyline.getJSONObject(i).getIntValue("x")
                        val y1: Int = polyline.getJSONObject(i).getIntValue("y")

                        val x2: Int = tp(i - 1)._1
                        val y2: Int = tp(i - 1)._2

                        tp.append((x1 + x2, y1 + y2))
                    }

                }
                xy_listBuff = tp.map(r => (r._1 / 3600000.00).formatted("%.6f") + "," + (r._2 / 3600000.00).formatted("%.6f"))
            }


        }

        xy_listBuff
    }

    def get_road_attr_data2(js: JSONObject): (Double, Double, Double, Double) = {

        var startpos_x: Double = 0.00
        var startpos_y: Double = 0.00
        var endpos_x: Double = 0.00
        var endpos_y: Double = 0.00

        val line: JSONObject = js.getJSONObject("line")
        if (line != null && line.size() > 0) {

            val startpos: JSONObject = line.getJSONObject("startpos")
            val endpos: JSONObject = line.getJSONObject("endpos")

            startpos_x = startpos.getDoubleValue("x") / 3600000
            startpos_y = startpos.getDoubleValue("y") / 3600000

            endpos_x = endpos.getDoubleValue("x") / 3600000
            endpos_y = endpos.getDoubleValue("y") / 3600000
        }

        (startpos_x, startpos_y, endpos_x, endpos_y)
    }

    //对多行数据按swid进行排序
    def get_ordered_rows(rowsList: List[Row]): ListBuffer[Row] = {
        val ruleroadid_index_listBuff = new ListBuffer[(Int, Row)]
        for (r <- rowsList) {
            val ruleroadid: String = r.getAs[String]("ruleroadid")
            val isbuilding_swid_arr: Array[String] = r.getAs[String]("isbuilding_swid").split("\\|")
            val i: Int = isbuilding_swid_arr.indexOf(ruleroadid)
            ruleroadid_index_listBuff.append((i, r))
        }
        val rows: ListBuffer[Row] = ruleroadid_index_listBuff.sortWith(_._1 < _._1).map(_._2)
        rows
    }

    // 根据 ruleroadid 对 isbuilding_swid 进行切割
    def get_isbuilding_swid: UserDefinedFunction = udf((ruleroadid: String, next_ruleroadid: String, isbuilding_swid: String) => {
        val isbuilding_swid_arr: Array[String] = isbuilding_swid.split("\\|")
        val start_index: Int = isbuilding_swid_arr.indexOf(ruleroadid)

        var swid: String = ""
        if (next_ruleroadid != "-1") {
            val end_index: Int = isbuilding_swid_arr.indexOf(next_ruleroadid)
            swid = isbuilding_swid_arr.slice(start_index, end_index).mkString("|")
        } else {
            swid = isbuilding_swid_arr.slice(start_index, isbuilding_swid_arr.length + 1).mkString("|")
        }

        swid
    })

    // 根据 isbuilding_swid 获取对应的 isbuilding_point
    def get_isbuilding_point: UserDefinedFunction = udf((isbuilding_swid: String) => {
        val isbuilding_swid_arr: Array[String] = isbuilding_swid.split("\\|")

        var isbuilding_point: String = ""
        val isbuilding_point_buff: ListBuffer[String] = new ListBuffer[String]
        for (swid <- isbuilding_swid_arr) {
            val json: JSONObject = call_road_attr_inter(swid)
            val xy_listBuff: ListBuffer[String] = get_road_attr_data(json)
            if (xy_listBuff.nonEmpty) isbuilding_point_buff.append(xy_listBuff.mkString(";"))
        }
        isbuilding_point = isbuilding_point_buff.mkString(";")

        isbuilding_point
    })

    def get_ruleroadid2: UserDefinedFunction = udf((ruleroadid: String, rn: Int, isbuilding_swid: String) => {
        val firtst_swid: String = isbuilding_swid.split("\\|")(0)

        var ruleroadid2: String = ruleroadid
        if (rn == 1 && firtst_swid != ruleroadid) ruleroadid2 = firtst_swid

        ruleroadid2
    })

}
