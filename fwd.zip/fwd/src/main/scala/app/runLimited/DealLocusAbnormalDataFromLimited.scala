package app.runLimited

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.JpgjLimitedAndLinksAll
import org.apache.spark.Partitioner
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.concat
import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.HttpClientUtil.getJsonByGet
import utils.SparkConfigUtil

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.Random

/**
  * 目标：处理轨迹异常数据
  *
  * 数据源：纠偏跑出来的闯行数据 （已完成 纠偏异常处理逻辑）
  *
  * 7.轨迹质量异常
  */
object DealLocusAbnormalDataFromLimited {
    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val ct2_url: String = config.getString("ct2_url")

    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        // 纠偏获取到的闯行数据
        val jpgjLimitedDataSQL: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info_his2
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(jpgjLimitedDataSQL)

        // 获取纠偏的数据
        val jpgjLimitedDF: DataFrame = spark.sql(jpgjLimitedDataSQL)
          .dropDuplicates("uuid", "rulepos")
          .repartition(1200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 纠偏的数据源
        GetDFCountAndSampleData(logger, jpgjLimitedDF, "纠偏的数据")

        // 纠偏异常的数据，获取对应的点和mark
        val jpgjLimitedAndPointAndMarkDF: DataFrame = jpgjLimitedDF
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val rulepos: String = r.getAs[String]("rulepos")
              val axleNumber: String = r.getAs[String]("axls_number")
              val vehicle: Int = r.getAs[Int]("vehicle_type")
              val plandate: String = r.getAs[String]("plandate")
              val vehicle_full_load_weight: String = r.getAs[String]("vehicle_full_load_weight")
              val vehicle_load_weight: Double = r.getAs[Double]("vehicle_load_weight")
              val height: Double = r.getAs[Double]("height")
              val vehicle_serial: String = r.getAs[String]("vehicle_serial")
              val color: String = r.getAs[String]("color")
              val width: Double = r.getAs[Double]("width")
              val vehicle_length: String = r.getAs[String]("vehicle_length")
              val energy: String = r.getAs[String]("energy")
              val emission: String = r.getAs[String]("emission")
              val tp: (String, Double, Double, Double, Double, Int, BigDecimal, Double, Double) = getDistAndPointAndMark(r)
              (uuid, rulepos, axleNumber, vehicle, plandate, vehicle_full_load_weight, vehicle_load_weight, height, vehicle_serial, color, width, vehicle_length, energy, emission,
                tp._2, tp._3, tp._4, tp._5, tp._6, tp._7, tp._8, tp._9)
          })
          .toDF("uuid", "rulepos", "axleNumber", "vehicle", "plandate", "vehicle_full_load_weight",
              "vehicle_load_weight", "height", "vehicle_serial", "color", "width", "vehicle_length", "energy",
              "emission", "x1", "y1", "x2", "y2", "mark", "dist", "s_dist", "d_dist")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 查看处理过后的纠偏轨迹数据
        GetDFCountAndSampleData(logger, jpgjLimitedAndPointAndMarkDF, "纠偏异常的数据，获取对应的点和mark")

        val jpgjLimitedAndPointAndMarkDFHis: Dataset[Row] = jpgjLimitedAndPointAndMarkDF
          .filter("mark not in (1,2,3,6)")
          .persist(StorageLevel.MEMORY_AND_DISK)

        logger.error(s"[0,4,5]的数据量：${jpgjLimitedAndPointAndMarkDFHis.count()} 条")

        // 不做 cntAndMark 的数据
        val jpgjLimitedAndPointAndMarkDFHis2: Dataset[Row] = jpgjLimitedAndPointAndMarkDF
          .filter("mark in (1,2,3,6)")
          .persist(StorageLevel.MEMORY_AND_DISK)

        logger.error(s"[1,2,3,6]的数据量：${jpgjLimitedAndPointAndMarkDFHis2.count()} 条")


        val jpgjLimitedAndLinks2: DataFrame = jpgjLimitedAndPointAndMarkDFHis2
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val mark: Int = r.getAs[Int]("mark")
              val rulepos: String = r.getAs[String]("rulepos")
              val jyrt_links_union: String = null
              val x1: String = r.getAs[Double]("x1").toString
              val y1: String = r.getAs[Double]("y1").toString
              val x2: String = r.getAs[Double]("x2").toString
              val y2: String = r.getAs[Double]("y2").toString
              val s_dist: String = r.getAs[Double]("s_dist").toString
              val d_dist: String = r.getAs[Double]("d_dist").toString
              val jyrt_url: String = null
              (uuid, mark, rulepos, jyrt_links_union, x1, y1, x2, y2, s_dist, d_dist, jyrt_url)
          })
          .toDF("uuid", "mark", "rulepos", "jyrt_links_union", "x1", "y1", "x2", "y2", "s_dist", "d_dist", "jyrt_url")

        // 纠偏异常的数据和对应的links
        val jpgjLimitedAndLinks: DataFrame = jpgjLimitedAndPointAndMarkDFHis
          .flatMap(r => {
              val listBuff: ListBuffer[String] = call_ct2_service(r)
              listBuff
          })
          .map(r => {
              val uuid: String = r.split(";;")(0)
              val mark: Int = r.split(";;")(1).toInt
              val rulepos: String = r.split(";;")(2)
              val jyrt_links_union: String = r.split(";;")(3)
              val x1: String = r.split(";;")(4)
              val y1: String = r.split(";;")(5)
              val x2: String = r.split(";;")(6)
              val y2: String = r.split(";;")(7)
              val s_dist: String = r.split(";;")(8)
              val d_dist: String = r.split(";;")(9)
              val jyrt_url: String = r.split(";;")(10)
              (uuid, mark, rulepos, jyrt_links_union, x1, y1, x2, y2, s_dist, d_dist, jyrt_url)
          })
          .toDF("uuid", "mark", "rulepos", "jyrt_links_union", "x1", "y1", "x2", "y2", "s_dist", "d_dist", "jyrt_url")


        val jpgjLimitedAndLinksAll: DataFrame = jpgjLimitedAndLinks
          .union(jpgjLimitedAndLinks2)
          .join(jpgjLimitedDF, Seq("uuid", "rulepos"))
          .withColumn("ana_key", concat($"uuid", $"rulepos"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpgjLimitedAndLinksAll, "纠偏异常的数据和对应的links")
        jpgjLimitedAndPointAndMarkDF.unpersist()


        val jpgjLimitedCntMarkAndLinksResultDF: DataFrame = jpgjLimitedAndLinksAll
          .rdd
          .groupBy(r => r.getAs[String]("ana_key"))
          .map(pair => {
              val ana_key: String = pair._1
              val rows: Iterable[Row] = pair._2
              val rows_cnt: Int = rows.size
              val one_row: Row = rows.toList.head

              val uuid: String = one_row.getAs[String]("uuid")
              val rulepos: String = one_row.getAs[String]("rulepos")
              val jyrt_links_union: String = one_row.getAs[String]("jyrt_links_union")
              val x1: String = one_row.getAs[String]("x1")
              val y1: String = one_row.getAs[String]("y1")
              val x2: String = one_row.getAs[String]("x2")
              val y2: String = one_row.getAs[String]("y2")
              val s_dist: String = one_row.getAs[String]("s_dist")
              val d_dist: String = one_row.getAs[String]("d_dist")
              val jyrt_url: String = one_row.getAs[String]("jyrt_url")
              val data_source: String = one_row.getAs[String]("data_source")
              val d_plan_order: Integer = one_row.getAs[Integer]("d_plan_order")
              val mynew: String = one_row.getAs[String]("mynew")
              val angle: String = one_row.getAs[String]("angle")
              val existlimit: String = one_row.getAs[String]("existlimit")
              val lineid: String = one_row.getAs[String]("lineid")
              val linkid: String = one_row.getAs[String]("linkid")
              val mark_jp: String = one_row.getAs[String]("mark_jp")
              val originroadclasslist: String = one_row.getAs[String]("originroadclasslist")
              val srcidfrom: String = one_row.getAs[String]("srcidfrom")
              val srcid: String = one_row.getAs[String]("srcid")
              val r_status: String = one_row.getAs[String]("r_status")
              val r_origin: String = one_row.getAs[String]("r_origin")
              val r_destination: String = one_row.getAs[String]("r_destination")
              val r_flen: String = one_row.getAs[String]("r_flen")
              val r_tlen: String = one_row.getAs[String]("r_tlen")
              val r_distance: Integer = one_row.getAs[Integer]("r_distance")
              val r_duration: Double = one_row.getAs[Double]("r_duration")
              val r_highspeed_distance: Integer = one_row.getAs[Integer]("r_highspeed_distance")
              val r_trafficlight_count: Integer = one_row.getAs[Integer]("r_trafficlight_count")
              val r_tolls: Integer = one_row.getAs[Integer]("r_tolls")
              val r_etc_toll: Integer = one_row.getAs[Integer]("r_etc_toll")
              val r_toll_distance: Integer = one_row.getAs[Integer]("r_toll_distance")
              val r_links_union: String = one_row.getAs[String]("r_links_union")
              val r_rc_distance: String = one_row.getAs[String]("r_rc_distance")
              val task_id: String = one_row.getAs[String]("task_id")
              val start_dept: String = one_row.getAs[String]("start_dept")
              val end_dept: String = one_row.getAs[String]("end_dept")
              val his_coords: String = one_row.getAs[String]("his_coords")
              val start_type: String = one_row.getAs[String]("start_type")
              val end_type: String = one_row.getAs[String]("end_type")
              val start_tm: String = one_row.getAs[String]("start_tm")
              val end_tm: String = one_row.getAs[String]("end_tm")
              val actual_run_time: String = one_row.getAs[String]("actual_run_time")
              val plan_run_time: String = one_row.getAs[String]("plan_run_time")
              val sort_num: String = one_row.getAs[String]("sort_num")
              val start_longitude: String = one_row.getAs[String]("start_longitude")
              val end_longitude: String = one_row.getAs[String]("end_longitude")
              val start_latitude: String = one_row.getAs[String]("start_latitude")
              val end_latitude: String = one_row.getAs[String]("end_latitude")
              val line_code: String = one_row.getAs[String]("line_code")
              val line_id: String = one_row.getAs[String]("line_id")
              val task_area_code: String = one_row.getAs[String]("task_area_code")
              val vehicle_serial: String = one_row.getAs[String]("vehicle_serial")
              val conveyance_type: String = one_row.getAs[String]("conveyance_type")
              val transoport_level: String = one_row.getAs[String]("transoport_level")
              val id: String = one_row.getAs[String]("id")
              val is_stop: String = one_row.getAs[String]("is_stop")
              val ground_task_id: String = one_row.getAs[String]("ground_task_id")
              val start_time: String = one_row.getAs[String]("start_time")
              val carrier_type: String = one_row.getAs[String]("carrier_type")
              val plf_flag: String = one_row.getAs[String]("plf_flag")
              val log_dist: String = one_row.getAs[String]("log_dist")
              val line_distance: String = one_row.getAs[String]("line_distance")
              val vehicle_serial2: String = one_row.getAs[String]("vehicle_serial2")
              val hko_vehicle_code: String = one_row.getAs[String]("hko_vehicle_code")
              val trailer_vehicle_code: String = one_row.getAs[String]("trailer_vehicle_code")
              val source: Integer = one_row.getAs[Integer]("source")
              val is_trailer: String = one_row.getAs[String]("is_trailer")
              val vehicle_type: Integer = one_row.getAs[Integer]("vehicle_type")
              val vehicle_length: String = one_row.getAs[String]("vehicle_length")
              val width: Double = one_row.getAs[Double]("width")
              val height: Double = one_row.getAs[Double]("height")
              val color: String = one_row.getAs[String]("color")
              val energy: String = one_row.getAs[String]("energy")
              val license: String = one_row.getAs[String]("license")
              val emission: String = one_row.getAs[String]("emission")
              val axls_number: String = one_row.getAs[String]("axls_number")
              val vehicle_full_load_weight: String = one_row.getAs[String]("vehicle_full_load_weight")
              val vehicle_load_weight: Double = one_row.getAs[Double]("vehicle_load_weight")
              val line: String = one_row.getAs[String]("line")
              val xy: String = one_row.getAs[String]("xy")
              val order: Integer = one_row.getAs[Integer]("order")
              val grp0: String = one_row.getAs[String]("grp0")
              val grp1: String = one_row.getAs[String]("grp1")
              val grp2: String = one_row.getAs[String]("grp2")
              val plandate: String = one_row.getAs[String]("plandate")
              val grp2_order: Integer = one_row.getAs[Integer]("grp2_order")
              val uuid2: String = one_row.getAs[String]("uuid2")
              val his_abnormal: String = one_row.getAs[String]("his_abnormal")
              val abnormal: String = one_row.getAs[String]("abnormal")
              val coords: String = one_row.getAs[String]("coords")
              val jp_swid: String = one_row.getAs[String]("jp_swid")
              val jp_status: String = one_row.getAs[String]("jp_status")
              val flag: Boolean = one_row.getAs[Boolean]("flag")
              val status: String = one_row.getAs[String]("status")
              val rdist: Integer = one_row.getAs[Integer]("rdist")
              val rtime: Double = one_row.getAs[Double]("rtime")
              val rhighway: Integer = one_row.getAs[Integer]("rhighway")
              val rtralightcount: Integer = one_row.getAs[Integer]("rtralightcount")
              val rtolls: Integer = one_row.getAs[Integer]("rtolls")
              val rtollsdistance: Integer = one_row.getAs[Integer]("rtollsdistance")
              val qstartxy: String = one_row.getAs[String]("qstartxy")
              val qendxy: String = one_row.getAs[String]("qendxy")
              val rcoords: String = one_row.getAs[String]("rcoords")
              val rsteps: String = one_row.getAs[String]("rsteps")
              val rflen: Integer = one_row.getAs[Integer]("rflen")
              val rtlen: Integer = one_row.getAs[Integer]("rtlen")
              val rulecount: Integer = one_row.getAs[Integer]("rulecount")
              val ruleorder: String = one_row.getAs[String]("ruleorder")
              val ruleid: String = one_row.getAs[String]("ruleid")
              val ruletype: String = one_row.getAs[String]("ruletype")
              val ruleroadid: String = one_row.getAs[String]("ruleroadid")
              val ruleoutroadid: String = one_row.getAs[String]("ruleoutroadid")
              val ruleroadname: String = one_row.getAs[String]("ruleroadname")
              val limitweight: String = one_row.getAs[String]("limitweight")
              val limitsize: String = one_row.getAs[String]("limitsize")
              val limitwidth: String = one_row.getAs[String]("limitwidth")
              val limitaxload: String = one_row.getAs[String]("limitaxload")
              val limitload: String = one_row.getAs[String]("limitload")
              val limitaxcnt: String = one_row.getAs[String]("limitaxcnt")
              val limitpassport: String = one_row.getAs[String]("limitpassport")
              val limitholiday: String = one_row.getAs[String]("limitholiday")
              val limitvehicletype: String = one_row.getAs[String]("limitvehicletype")
              val limitoutflag: String = one_row.getAs[String]("limitoutflag")
              val limitemitstand: String = one_row.getAs[String]("limitemitstand")
              val limittailchar: String = one_row.getAs[String]("limittailchar")
              val limitstartdate: String = one_row.getAs[String]("limitstartdate")
              val limitenddate: String = one_row.getAs[String]("limitenddate")
              val limitweek: String = one_row.getAs[String]("limitweek")
              val limittime: String = one_row.getAs[String]("limittime")
              val guid: String = one_row.getAs[String]("guid")
              val ruletimedesc: String = one_row.getAs[String]("ruletimedesc")
              val ruleregiondesc: String = one_row.getAs[String]("ruleregiondesc")
              val rulevehicle: String = one_row.getAs[String]("rulevehicle")
              val rulestrategy: String = one_row.getAs[String]("rulestrategy")
              val mark_dist: Integer = one_row.getAs[Integer]("mark_dist")
              val min_dist: Double = one_row.getAs[Double]("min_dist")
              val city: String = one_row.getAs[String]("city")
              val version: String = one_row.getAs[String]("version")
              val inc_day: String = one_row.getAs[String]("inc_day")

              var cnt: Int = 0

              var matched_jyrt_links_union: String = ""
              for (row <- rows) {
                  val jyrt_links_union: String = row.getAs[String]("jyrt_links_union")
                  val ruleroadid: String = row.getAs[String]("ruleroadid")
                  if (jyrt_links_union != null && jyrt_links_union != "") {
                      val union: Array[String] = jyrt_links_union.split("\\|")
                      var flag: Boolean = true
                      for (i <- union.indices if flag) {
                          if (ruleroadid == union(i)) {
                              matched_jyrt_links_union = matched_jyrt_links_union + jyrt_links_union + ";"
                              cnt += 1
                              flag = false
                          }
                      }
                  }
              }

              var mark: Int = one_row.getAs[Int]("mark")

              if (mark != 1 && mark != 2 && mark != 3 && mark != 6) {
                  if (cnt == 0) {
                      mark = 4
                  } else if (cnt < rows.size) {
                      mark = 5
                  }
              }

              JpgjLimitedAndLinksAll(
                  uuid,ana_key, rulepos, mark, jyrt_links_union,matched_jyrt_links_union, x1, y1, x2, y2, s_dist, d_dist, jyrt_url, mynew, angle, existlimit, lineid, linkid,
                  mark_jp, originroadclasslist, srcidfrom, srcid, data_source, d_plan_order, r_status, r_origin, r_destination, r_flen,
                  r_tlen, r_distance, r_duration, r_highspeed_distance, r_trafficlight_count, r_tolls, r_etc_toll, r_toll_distance, r_links_union,
                  r_rc_distance, task_id, start_dept, end_dept, his_coords, start_type, end_type, start_tm, end_tm, actual_run_time,
                  plan_run_time, sort_num, start_longitude, end_longitude, start_latitude, end_latitude, line_code, line_id, task_area_code,
                  vehicle_serial, conveyance_type, transoport_level, id, is_stop, ground_task_id, start_time, carrier_type, plf_flag,
                  log_dist, line_distance, vehicle_serial2, hko_vehicle_code, trailer_vehicle_code, source, is_trailer, vehicle_type,
                  vehicle_length, width, height, color, energy, license, emission, axls_number, vehicle_full_load_weight, vehicle_load_weight,
                  line, xy, order, grp0, grp1, grp2, plandate, grp2_order, uuid2, his_abnormal, abnormal, coords, jp_swid, jp_status,
                  flag, status, rdist, rtime, rhighway, rtralightcount, rtolls, rtollsdistance, qstartxy, qendxy, rcoords, rsteps,
                  rflen, rtlen, rulecount, ruleorder, ruleid, ruletype, ruleroadid, ruleoutroadid, ruleroadname, limitweight, limitsize,
                  limitwidth, limitaxload, limitload, limitaxcnt, limitpassport, limitholiday, limitvehicletype, limitoutflag, limitemitstand,
                  limittailchar, limitstartdate, limitenddate, limitweek, limittime, guid, ruletimedesc, ruleregiondesc, rulevehicle,
                  rulestrategy, mark_dist, min_dist,rows_cnt,cnt, city,version, inc_day
              )
          })
          .toDF()
          .coalesce(100)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 最终的数据
        GetDFCountAndSampleData(logger, jpgjLimitedCntMarkAndLinksResultDF, "异常数据处理完成之后的最终数据")

        // 最终的数据落表
        df2HiveByOverwrite(logger,jpgjLimitedCntMarkAndLinksResultDF,"dm_gis.mms_car_route_jp_detail_and_limited_info_his3")
        jpgjLimitedAndLinks.unpersist()


        logger.error("运行结束")

        // 程序运行结束，关闭spark
        spark.stop()
    }

    // 对每一行数据进行标记
    def getDistAndPointAndMark(r: Row): (String, Double, Double, Double, Double, Int, BigDecimal, Double, Double) = {
        val uuid: String = r.getAs[String]("uuid")

        // 定义返回的变量
        var dist: BigDecimal = 0
        var x1: Double = 0.00
        var y1: Double = 0.00
        var x2: Double = 0.00
        var y2: Double = 0.00
        var s_dist: Double = 0.0
        var d_dist: Double = 0.0
        var mark: Int = 0

        val coords: String = r.getAs[String]("coords")
        val rulepos: String = r.getAs[String]("rulepos")
        val jp_swid: String = r.getAs[String]("jp_swid")
        val jp_status: String = r.getAs[String]("jp_status")
        val ruleroadid: String = r.getAs[String]("ruleroadid")

        val coordsArr: Array[String] = coords.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
          .replaceAll(" ", "")
          .split("\\|")

        val jp_swidArr: Array[String] = jp_swid
          .replaceAll("\\[", "")
          .replaceAll("]", "")
          .split("\\|")

        val jp_statusArr: Array[String] = jp_status
          .replaceAll("\\[", "")
          .replaceAll("]", "")
          .split("\\|")

        // 当前row的限行点的坐标
        var x0: String = rulepos.split(",")(0)
        var y0: String = rulepos.split(",")(1)

        var idx: Int = -1
        var flag: Int = 0

        if (coordsArr.length == jp_swidArr.length && coordsArr.length == jp_statusArr.length) {
            for (i <- coordsArr.indices) {
                val x: String = coordsArr(i).split(",")(0)
                val y: String = coordsArr(i).split(",")(1)

                val swid: String = jp_swidArr(i)

                if (flag == 0) {
                    if (x == x0 && y == y0) {
                        flag = 1
                        idx = i
                    } else if (swid == ruleroadid) {
                        flag = 1
                        idx = i
                        x0 = x
                        y0 = y
                    }
                }


            }
        }


        if (flag == 0) {
            mark = 3
        } else {
            // 限行起点 经纬度
            val lng1: Double = coordsArr(0).split(",")(0).toDouble
            val lat1: Double = coordsArr(0).split(",")(1).toDouble

            // 限行终点 经纬度
            val lng2: Double = coordsArr(coordsArr.length - 1).split(",")(0).toDouble
            val lat2: Double = coordsArr(coordsArr.length - 1).split(",")(1).toDouble

            // 计算2点间的距离
            s_dist = get_distance2(lng1, lat1, x0.toDouble, y0.toDouble) * 1000
            d_dist = get_distance2(lng2, lat2, x0.toDouble, y0.toDouble) * 1000

            // 判断起点 或 终点 是否在阀值范围
            if (s_dist <= 200) {
                mark = 1
            } else if (d_dist <= 200) {
                mark = 2
            } else if (mark == 0) {
                if (jp_statusArr(idx) != "0") {
                    if (jp_statusArr(idx) == "100") {
                        mark = 100
                    } else {
                        val jp_statusArrSlice1: Array[String] = jp_statusArr.slice(0, idx)
                        val jp_statusArrSlice2: Array[String] = jp_statusArr.slice(idx, jp_statusArr.length + 1)

                        val idex1: Int = jp_statusArrSlice1.lastIndexOf("0")
                        val idex2: Int = jp_statusArrSlice2.indexOf("0") + idx

                        val start_point: String = coordsArr(idex1)
                        val end_point: String = coordsArr(idex2)

                        x1 = start_point.split(",")(0).toDouble
                        y1 = start_point.split(",")(1).toDouble
                        x2 = end_point.split(",")(0).toDouble
                        y2 = end_point.split(",")(1).toDouble

                        // 计算2点间的距离
                        dist = get_distance2(x1, y1, x2, y2) * 1000
                        if (dist >= 4000) mark = 6
                    }

                }
            }


        }
        (uuid, x1, y1, x2, y2, mark, dist, s_dist, d_dist)
    }

    // 根据经纬度，计算2点之间的距离 返回值的单位：km
    def get_distance2(longitude1: Double, latitude1: Double, longitude2: Double, latitude2: Double): Double = { // 纬度
        val R = 6371.00

        val lat1: Double = Math.toRadians(latitude1)
        val lat2: Double = Math.toRadians(latitude2)
        // 经度
        val lng1: Double = Math.toRadians(longitude1)
        val lng2: Double = Math.toRadians(longitude2)
        // 纬度之差
        val a: Double = lat1 - lat2
        // 经度之差
        val b: Double = lng1 - lng2
        // 计算两点距离的公式
        var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(b / 2), 2)))
        // 弧长乘地球半径, 返回单位: 千米
        s = s * R
        s
    }

    // 调用 传统规划2 ，获取相应的数据
    def call_ct2_service(r: Row): ListBuffer[String] = {

        val uuid: String = r.getAs[String]("uuid")
        val rulepos: String = r.getAs[String]("rulepos")
        val axleNumber: String = r.getAs[String]("axleNumber")
        val x1: String = r.getAs[Double]("x1").toString
        val y1: String = r.getAs[Double]("y1").toString
        val x2: String = r.getAs[Double]("x2").toString
        val y2: String = r.getAs[Double]("y2").toString

        val s_dist: String = r.getAs[Double]("s_dist").toString
        val d_dist: String = r.getAs[Double]("d_dist").toString

        val xy: String = x1 + ";;" + y1 + ";;" + x2 + ";;" + y2

        val vehicle: Int = r.getAs[Int]("vehicle")
        val planDate: String = r.getAs[String]("plandate")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val energy: String = r.getAs[String]("energy")
        val emitStand: String = r.getAs[String]("emission")

        val mark: Int = r.getAs[Int]("mark")

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("planDate", planDate)
        parMap.put("emitStand", emitStand)
        parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

        val url: String = ct2_url + map2String(parMap)


        val jsonData: JSONObject = getJsonByGet(url, 3, "utf-8")

        // 存放每个轨迹的数据，可能返回2条轨迹，也可能返回3条轨迹
        val uuid_and_jyrt_links_union: ListBuffer[String] = new ListBuffer[String]

        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")
                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    for (i <- 0 until list.size()) {
                        // 存放每个steps → link 下的所有值
                        val stepsLinksBuff: ListBuffer[String] = new ListBuffer[String]

                        val obj: JSONObject = list.getJSONObject(i)

                        val steps: JSONArray = obj.getJSONArray("steps")
                        for (j <- 0 until steps.size()) {
                            val step: JSONObject = steps.getJSONObject(j)
                            val links: JSONArray = step.getJSONArray("links")
                            for (k <- 0 until links.size()) {
                                val link: JSONObject = links.getJSONObject(k)
                                val uid: String = link.getString("uid")
                                stepsLinksBuff.append(uid)
                            }
                        }

                        val links_union: String = stepsLinksBuff.mkString("|")
                        uuid_and_jyrt_links_union.append(uuid + ";;" + mark + ";;" + rulepos + ";;" + links_union + ";;" + xy + ";;" + s_dist + ";;" + d_dist + ";;" + url)
                    }
                } else {
                    uuid_and_jyrt_links_union.append(uuid + ";;" + mark + ";;" + rulepos + ";;" + "" + ";;" + xy + ";;" + s_dist + ";;" + d_dist + ";;" + url)
                }
            } else {
                uuid_and_jyrt_links_union.append(uuid + ";;" + mark + ";;" + rulepos + ";;" + "" + ";;" + xy + ";;" + s_dist + ";;" + d_dist + ";;" + url)
            }
        } else {
            uuid_and_jyrt_links_union.append(uuid + ";;" + mark + ";;" + rulepos + ";;" + "" + ";;" + xy + ";;" + s_dist + ";;" + d_dist + ";;" + url)
        }

        uuid_and_jyrt_links_union
    }

    // 获取闯行点 到  2个point 的垂直距离
    // rulepos, firstPoint, secondPoint 都是 经纬度 组成的字符串，通过逗号分隔
    def getPoint2LinkDist(rulepos: String, firstPoint: String, secondPoint: String): Double = {

        val rulepos_x: Double = rulepos.split(",")(0).toDouble
        val rulepos_y: Double = rulepos.split(",")(1).toDouble

        val firstPoint_x: Double = firstPoint.split(",")(0).toDouble
        val firstPoint_y: Double = firstPoint.split(",")(1).toDouble

        val secondPoint_x: Double = secondPoint.split(",")(0).toDouble
        val secondPoint_y: Double = secondPoint.split(",")(1).toDouble

        if (math.abs(firstPoint_x - secondPoint_x) < 0.0000001 && math.abs(firstPoint_y - secondPoint_y) < 0.0000001)
            return getPoint2PointDist(rulepos, firstPoint)

        val va_x: Double = rulepos_x - firstPoint_x
        val va_y: Double = rulepos_y - firstPoint_y

        val vb_x: Double = secondPoint_x - firstPoint_x
        val vb_y: Double = secondPoint_y - firstPoint_y

        val dot: Double = getDot((va_x, va_y), (vb_x, vb_y))
        if (dot < 0) return getPoint2PointDist(rulepos, firstPoint)

        val square: Double = getDot((vb_x, vb_y), (vb_x, vb_y))
        val s: Double = dot / square
        if (s > 1) return getPoint2PointDist(rulepos, secondPoint)

        val middlePoint_x: Double = firstPoint_x + vb_x * s
        val middlePoint_y: Double = firstPoint_y + vb_y * s
        val middlePoint: String = middlePoint_x + "," + middlePoint_y
        getPoint2PointDist(rulepos, middlePoint)
    }

    // 获取2个点之间的最短距离
    def getPoint2PointDist(firstPoint: String, secondPoint: String): Double = {
        val firstPoint_x: Double = firstPoint.split(",")(0).toDouble
        val firstPoint_y: Double = firstPoint.split(",")(1).toDouble

        val secondPoint_x: Double = secondPoint.split(",")(0).toDouble
        val secondPoint_y: Double = secondPoint.split(",")(1).toDouble

        val dx: Double = secondPoint_x - firstPoint_x
        val dy: Double = secondPoint_y - firstPoint_y

        val sx: Double = dx * math.cos(firstPoint_y * 0.01745329252)
        val dist: Double = math.sqrt(sx * sx + dy * dy) * 111195.0
        dist
    }

    def getDot(u: (Double, Double), v: (Double, Double)): Double = {
        u._1 * v._1 + u._2 * v._2
    }

    // 将map转化为string，剔除值为null的数据
    def map2String(parMap: mutable.HashMap[String, Any]): String = {
        for (elem <- parMap)
            if (elem._2 == null) parMap.remove(elem._1)
        val parStr: String = parMap.mkString("&").replaceAll(" -> ", "=")
        parStr
    }


    def leftOuterJoinOfLeftLeanElem1(logger: Logger, left: RDD[(String, Row)], right: RDD[(String, Row)], hashNum: Int, topLean: Int = 50): RDD[(String, (Row, Row))] = {
        val keyCounts: Array[(String, Int)] = left
          .map(obj => (obj._1, 1))
          .reduceByKey(_ + _)
          .sortBy(-_._2)
          .take(topLean)

        val keys: Array[String] = keyCounts.map(obj => obj._1)

        val counts: Int = keyCounts.map(obj => obj._2).sum
        logger.error("单独处理的keys:" + keyCounts.mkString(","))
        logger.error("单独处理的总数量:" + counts)
        //拆分数据为独立处理的key和非独立处理的key
        val leftHashKeyData: RDD[(String, Row)] = left.filter(obj => keys.contains(obj._1))
        val leftOtherData: RDD[(String, Row)] = left.filter(obj => !keys.contains(obj._1))
        val rightHashKeyData: RDD[(String, Row)] = right.filter(obj => keys.contains(obj._1))
        val rightOtherData: RDD[(String, Row)] = right.filter(obj => !keys.contains(obj._1))

        //先关联其他key数据
        val otherJoin: RDD[(String, (Row, Row))] = leftOtherData
          .join(rightOtherData)
          .partitionBy(new myPartiton(1200))

        //        val otherJoin: RDD[(String, (Row, Row))] = otherJoin_tmp
        //          .partitionBy(new RangePartitioner(300, otherJoin_tmp))

        //扩展单独处理的数据
        val leftHashKeyDataExpand: RDD[((Int, String), Row)] = leftHashKeyData.map(obj => {
            val hashPrefix: Int = new Random().nextInt(hashNum)
            ((hashPrefix, obj._1), obj._2)
        })

        val rightHashKeyDataExpand: RDD[((Int, String), Row)] = rightHashKeyData
          .flatMap(obj => {
              val dataArray = new ArrayBuffer[((Int, String), Row)]()
              for (i <- 0 until hashNum) {
                  dataArray.append(((i, obj._1), obj._2))
              }
              dataArray.iterator
          })
        //关联数据
        val hashKeyJoin: RDD[(String, (Row, Row))] = leftHashKeyDataExpand
          .join(rightHashKeyDataExpand)
          .map(obj => (obj._1._2, obj._2))
          .partitionBy(new myPartiton(1200))

        //        val hashKeyJoin: RDD[(String, (Row, Row))] = hashKeyJoin_tmp
        //          .partitionBy(new RangePartitioner(300, hashKeyJoin_tmp))


        hashKeyJoin.union(otherJoin)

    }

    class myPartiton(numParts: Int) extends Partitioner {

        override def numPartitions: Int = numParts

        override def getPartition(key: Any): Int = {
            val i: Int = new Random().nextInt(numParts)
            val str: String = i.toString + key
            var num: Int = str.hashCode % numParts
            num = num + (if (num < 0) numParts else 0)
            num
        }

    }


}
