package app.runLimited

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.SparkContext
import org.apache.spark.sql.functions.{concat_ws, lit}
import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByAppend, df2HiveByOverwrite, getNowTime, getVersion}
import utils.HttpClientUtil.{getJsonByGet, getJsonByGet2}
import utils.SparkConfigUtil

import java.lang
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * (临时执行) 已下线
  * 根据路径规划信息，分别调用高德、传统、经验接口获取相应的数据，并对最终的结果做合并
  *
  * 2. 跑规划
  */
object GetRoutePlanDataFromGDAndCTAndJY {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val gd_url: String = config.getString("gd_url")
    val ct_url: String = config.getString("ct_url")
    val jy_url: String = config.getString("jy_url")
    val version_url: String = config.getString("version_url")


    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)
        val sc: SparkContext = spark.sparkContext

        // 记录调用高德接口的成功、失败次数
        val gd_success_acc: LongAccumulator = sc.longAccumulator
        val gd_fail_acc: LongAccumulator = sc.longAccumulator

        // 获取跑路径规划的数据
        val sql: String =
            s"""
               |select
               |  t1.*,
               |  t2.his_abnormal,
               |  t3.abnormal
               |from
               |  (select t.*,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.mms_car_locus_task_detail_para_plan_info t where inc_day >= '$start_time' and inc_day < '$end_time') t1
               |join
               |  (select his_abnormal,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_his_traj_ab_info t where t.his_abnormal != '-1' and inc_day >= '$start_time' and inc_day < '$end_time') t2
               |on t1.uuid2 = t2.uuid2
               |join
               |  (select abnormal, concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_traj_simgroup_info t where !(t.abnormal regexp '4|5') and inc_day >= '$start_time' and inc_day < '$end_time') t3
               |on t1.uuid2 = t3.uuid2
               |""".stripMargin
        val planDF: DataFrame = getPlanData(logger, spark, sql)

        // 跑高德规划
//        runGDService(logger, spark, planDF, gd_success_acc, gd_fail_acc)
        // 跑传统服务接口 获取相应的字段
        runCTService(logger, spark, planDF)
        // 跑经验服务接口 获取相应的字段
        runJYService(logger, spark, planDF)

        planDF.unpersist()

//        interStatus2Hive(logger, spark, "gd_url", gd_url, className, gd_success_acc, gd_fail_acc)

        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 调高德的服务，获取对应字段的值
    def callGDService(r: Row): (String, String, String, String, String, String, String, String, String, Int, String, String) = {

        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val planDate: String = r.getAs[String]("plandate")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val emitStand: String = r.getAs[String]("emission")


        val plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("planDate", planDate)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("emitStand", emitStand)
        parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

        val url: String = gd_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url = url, 6, "utf-8")
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            val result: JSONObject = jsonData.getJSONObject("result")
            val dist: String = result.getString("dist")
            val time: String = result.getString("time")
            val tolls: String = result.getString("tolls")
            val src: String = result.getString("src")
            val flen: String = result.getString("flen")
            val tlen: String = result.getString("tlen")

            val query_tmp: JSONObject = result.getJSONObject("query")
            val coords_tmp: JSONArray = result.getJSONArray("coords")
            var query: String = ""
            var coords: String = ""
            if (query_tmp != null) query = query_tmp.toJSONString
            if (coords_tmp != null) coords = coords_tmp.toJSONString
            (uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords)
        } else
            (uuid, url, "", "", "", "", "", "", "", plan_order, "", "")
    }

    // 调用传统服务，获取对应字段的值
    def callCTService(r: Row): ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)] = {
        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val planDate: String = r.getAs[String]("plandate")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val emitStand: String = r.getAs[String]("emission")

        var plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("planDate", planDate)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("emitStand", emitStand)
        parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

        val url: String = ct_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url, 6, "utf-8")

        val listBuff = new ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)]
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")

                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    for (j <- 0 until list.size()) {
                        val obj: JSONObject = list.getJSONObject(j)
                        val dist: String = obj.getString("dist")
                        val time: String = obj.getString("time")
                        val highway: String = obj.getString("highway")
                        val traLightCount: String = obj.getString("traLightCount")
                        val tolls: String = obj.getString("tolls")
                        val src: String = obj.getString("src")
                        val flen: String = obj.getString("flen")
                        val tlen: String = obj.getString("tlen")
                        val query_tmp: JSONObject = obj.getJSONObject("query")
                        val coords_tmp: JSONArray = obj.getJSONArray("coords")
                        var query: String = ""
                        var coords: String = ""
                        if (query_tmp != null) query = query_tmp.toJSONString
                        if (coords_tmp != null) coords = coords_tmp.toJSONString

                        plan_order = j

                        listBuff.append((uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords, highway, traLightCount))
                    }
                } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))
            } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))
        } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))

        listBuff
    }

    // 调用经验服务，获取对应字段的值
    def callJYService(r: Row): ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)] = {

        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val planDate: String = r.getAs[String]("plandate")
        val emitStand: String = r.getAs[String]("emission")

        var plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("planDate", planDate)
        parMap.put("emitStand", emitStand)
        parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

        val url: String = jy_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url, 6, "utf-8")

        val mylist = new ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)]
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")
                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    for (j <- 0 until list.size()) {
                        val json: JSONObject = list.getJSONObject(j)
                        val dist: String = json.getString("dist")
                        val time: String = json.getString("time")
                        val highway: String = json.getString("highway")
                        val traLightCount: String = json.getString("traLightCount")
                        val tolls: String = json.getString("tolls")
                        val src: String = json.getString("src")
                        val flen: String = json.getString("flen")
                        val tlen: String = json.getString("tlen")
                        val query_tmp: JSONObject = json.getJSONObject("query")
                        val coords_tmp: JSONArray = json.getJSONArray("coords")
                        var query: String = ""
                        var coords: String = ""

                        if (query_tmp != null) query = query_tmp.toJSONString
                        if (coords_tmp != null) coords = coords_tmp.toJSONString

                        val frequency: String = json.getString("frequency")
                        val frequencycost: String = json.getString("frequencycost")
                        val frequencytype: String = json.getString("frequencytype")
                        val freqratio: String = json.getString("freqratio")
                        val route_id: String = json.getString("route_id")
                        val src_routeids: String = json.getString("src_routeids")

                        plan_order = j

                        mylist.append((uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords,
                          highway, traLightCount, frequency, frequencycost, frequencytype, freqratio, route_id, src_routeids))
                    }
                } else mylist.append((uuid, url, status, "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))
            } else mylist.append((uuid, url, status, "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))
        } else mylist.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))

        mylist
    }

    // 将map转化为string，剔除值为null的数据
    def map2String(parMap: mutable.HashMap[String, Any]): String = {
        for (elem <- parMap)
            if (elem._2 == null) parMap.remove(elem._1)
        val parStr: String = parMap.mkString("&").replaceAll(" -> ", "=")
        parStr
    }

    // 讲接口调用成功、失败次数写入相应的表
    def interStatus2Hive(logger: Logger, spark: SparkSession, url_name: String, url: String, className: String, success_acc: LongAccumulator, fail_acc: LongAccumulator): Unit = {
        val success_cnt: lang.Long = success_acc.value
        val fail_cnt: lang.Long = fail_acc.value
        val all_cnt: Long = success_cnt + fail_cnt

        val table: String = "dm_gis.mms_route_interface_state"
        logger.error(s"开始写入到 Hive：$table")

        spark.createDataFrame(Seq(
            (getNowTime + "_" + url_name + "_" + className, getNowTime, url_name, url, className, all_cnt.toString, success_cnt.toString, fail_cnt.toString)
        ))
          .toDF("uid", "inc_day", "url_name", "url", "class_name", "all_cnt", "success_cnt", "fail_cnt")
          .write
          .mode(SaveMode.Append)
          .insertInto(table)

        logger.error(s"写入 $table 成功！")
    }

    // 跑高德服务
    def runGDService(logger: Logger, spark: SparkSession, planDF: DataFrame, gd_success_acc: LongAccumulator, gd_fail_acc: LongAccumulator): Unit = {
        import spark.implicits._

        // 从高德获取到的数据，关联原始数据
        val ResultDataFromGDdf: DataFrame = planDF
          .coalesce(10)
          .map(r => {
              val tp: (String, String, String, String, String, String, String, String, String, Int, String, String) = callGDService(r)
              if (tp._3 == "0") gd_success_acc.add(1L)
              else gd_fail_acc.add(1L)

              tp
          })
          .repartition(200)
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen", "d_tlen",
              "d_plan_order", "d_query", "coords")
          .filter("coords != ''")
          .join(planDF, "uuid")
          .withColumn("d_highway", lit(""))
          .withColumn("d_traLightCount", lit(""))
          .withColumn("d_frequency", lit(""))
          .withColumn("d_frequencycost", lit(""))
          .withColumn("d_frequencytype", lit(""))
          .withColumn("d_freqratio", lit(""))
          .withColumn("d_route_id", lit(""))
          .withColumn("d_src_routeids", lit(""))
          .withColumn("data_source", lit("2"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id",
              "start_dept", "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm",
              "actual_run_time", "plan_run_time", "sort_num", "start_longitude", "end_longitude", "start_latitude",
              "end_latitude", "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type",
              "transoport_level", "id", "is_stop", "ground_task_id", "start_time", "carrier_type", "plf_flag",
              "log_dist", "line_distance", "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source",
              "is_trailer", "vehicle_type", "vehicle_length", "width", "height", "color", "energy", "license",
              "emission", "axls_number", "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order",
              "grp0", "grp1", "grp2", "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype",
              "d_freqratio", "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ResultDataFromGDdf, "跑高德服务最终的结果数据")
        df2HiveByOverwrite(logger, ResultDataFromGDdf, "dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info")

        ResultDataFromGDdf.unpersist()
    }

    // 跑传统服务
    def runCTService(logger: Logger, spark: SparkSession, planDF: DataFrame): Unit = {
        import spark.implicits._

        // 从传统获取到的数据，关联原始数据
        val ResultDataFromCTdf: DataFrame = planDF
          .flatMap(r => {
              val listBuff: ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)] = callCTService(r)
              listBuff
          })
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount")
          .filter("coords != ''")
          .join(planDF, "uuid")
          .withColumn("d_frequency", lit(""))
          .withColumn("d_frequencycost", lit(""))
          .withColumn("d_frequencytype", lit(""))
          .withColumn("d_freqratio", lit(""))
          .withColumn("d_route_id", lit(""))
          .withColumn("d_src_routeids", lit(""))
          .withColumn("data_source", lit("1"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id", "start_dept",
              "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm", "actual_run_time",
              "plan_run_time", "sort_num", "start_longitude", "end_longitude", "start_latitude", "end_latitude",
              "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type", "transoport_level",
              "id", "is_stop", "ground_task_id", "start_time", "carrier_type", "plf_flag", "log_dist",
              "line_distance", "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer",
              "vehicle_type", "vehicle_length", "width", "height", "color", "energy", "license", "emission",
              "axls_number", "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0",
              "grp1", "grp2", "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype",
              "d_freqratio", "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ResultDataFromCTdf, "跑传统服务获取到的结果数据")
        df2HiveByAppend(logger, ResultDataFromCTdf, "dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info")


        ResultDataFromCTdf.unpersist()
    }

    // 跑经验服务
    def runJYService(logger: Logger, spark: SparkSession, planDF: DataFrame): Unit = {
        import spark.implicits._

        // 从经验获取到的数据，关联原始数据
        val ResultDataFromJYdf: DataFrame = planDF
          .flatMap(r => {
              val mylist: ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)] = callJYService(r)
              mylist
          })
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "d_frequency",
              "d_frequencycost", "d_frequencytype", "d_freqratio", "d_route_id", "d_src_routeids")
          .filter("coords != ''")
          .join(planDF, "uuid")
          .withColumn("data_source", lit("3"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen", "d_tlen",
              "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id", "start_dept", "end_dept",
              "his_coords", "start_type", "end_type", "start_tm", "end_tm", "actual_run_time", "plan_run_time",
              "sort_num", "start_longitude", "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id",
              "task_area_code", "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop",
              "ground_task_id", "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance",
              "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type",
              "vehicle_length", "width", "height", "color", "energy", "license", "emission", "axls_number",
              "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2",
              "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype", "d_freqratio",
              "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ResultDataFromJYdf, "跑经验服务最终的结果数据")
        df2HiveByAppend(logger, ResultDataFromJYdf, "dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info")

        ResultDataFromJYdf.unpersist()
    }

    // 获取跑规划的原始数据
    def getPlanData(logger: Logger,spark:SparkSession,sql:String):DataFrame={
        import spark.implicits._

        val xmlStr: String = getJsonByGet2(version_url, 10, "utf-8")
        val version: String = getVersion(xmlStr)

        logger.error(sql)

        val planDF: DataFrame = spark
          .sql(sql)
          .withColumn("uuid", concat_ws("_", $"task_id", $"start_dept", $"end_dept"))
          .withColumn("version", lit(version))
          .repartition(200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑路径规划数据信息：
        GetDFCountAndSampleData(logger, planDF, "用于跑规划的数据")

        planDF
    }

}
