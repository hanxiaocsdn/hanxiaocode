package app.runLimited

import utils.HttpConnection.sendPost
import utils.SparkConfigUtil
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.RunTrafficControlDataFromInter
import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getDataFrame}

import java.util
import scala.collection.mutable.ListBuffer

/**
  * 使用规划数据 跑闯行
  *
  * 3. 使用规划数据 跑闯行
  */
object RunningLimitedServiceDataFromPlan {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")


    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 获取用于跑闯行的数据   -- 规划的数据
        val originalDataSQL: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and d_status = '0'
               |""".stripMargin

        val originalDataDF: DataFrame = getDataFrame(logger, spark, originalDataSQL)

        // 跑闯行服务，获取相应的数据，并对数据做解析
        runLimitedService(logger, spark, originalDataDF)


        logger.error("运行结束！")

        // 程序运行结束
        spark.stop()
    }

    // 调用闯行的接口
    def callLimitedRoute(r: Row): (String, String, Int, JSONObject) = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = r.getAs[Int]("d_plan_order")

        var origin: String = ""
        var destination: String = ""
        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
          .replaceAll("'", "")
        val coordsArr: Array[String] = coords.split("\\|")
        for (i <- coordsArr.indices) {
            if (i == 0) origin = coordsArr(i)
            if (i == coordsArr.length - 1) destination = coordsArr(i)
        }

        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val emitStand: String = r.getAs[String]("emission")
        val energy: String = r.getAs[String]("energy")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val Mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val width: Double = r.getAs[Double]("width")
        val Size: String = r.getAs[String]("vehicle_length")
        val axlenumber: String = r.getAs[String]("axls_number")
        val No: String = r.getAs[String]("task_id")
        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&origin=$origin&destination=$destination&stype=0&etype=0&plate=$plate" +
          s"&plateColor=$plateColor&emitStand=$emitStand&energy=$energy&weight=$weight&vehicle=$vehicle&Mload=$Mload" +
          s"&height=$height&width=$width&Size=$Size&axlenumber=$axlenumber&passport=100000&mode=2&speed=1&No=$No&Toll=1&date=$date&len_diff=50&len_percent=0.5"


        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        var json: JSONObject = null

        try {
            val jsonStr: String = mapData.get("content").toString
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }

        (uuid, data_source, d_plan_order, json)
    }

    // 解析接口返回的json,获取相应的字段值
    def parseLimitedData(uuid: String, data_source: String, d_plan_order: Int, j: JSONObject): ListBuffer[RunTrafficControlDataFromInter] = {
        // 存放闯行的数据
        val rules: ListBuffer[RunTrafficControlDataFromInter] = new ListBuffer[RunTrafficControlDataFromInter]

        if (j != null) {
            val status: String = j.getString("status")
            if (status == "0") {
                val route: JSONObject = j.getJSONObject("route")
                val qstartxy: String = route.getString("origin")
                val qendxy: String = route.getString("destination")
                val paths: JSONArray = route.getJSONArray("paths")

                // 判断这个json数据是否闯行，默认false：不闯行
                var flag: Boolean = false
                if (paths.size() > 0) {
                    for (i <- 0 until paths.size() if !flag) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        if (obj.containsKey("voi_rule") && obj.getJSONArray("voi_rule").size() > 0) flag = true
                    }
                }

                // 闯行 与 不闯行 的公共解析字段
                // 开始解析公共字段
                var rdist: Int = 0
                var rtime: Double = 0.0
                var rhighway: Int = 0
                var rtraLightCount: Int = 0
                var rtolls: Int = 0
                var rtollsDistance: Int = 0
                val rcoords_tmp = new ListBuffer[String]
                val rsteps: String = ""
                var rulecount: Int = 0
                var rflen: Int = 0
                var rtlen: Int = 0
                val polyline_buff = new ListBuffer[String]
                val steps_links_swid_buff = new ListBuffer[String]
                var rmultiPathPos: String = ""
                var rmultiPathSwid: String = ""
                var first_swid: String = ""
                var last_swid: String = ""

                if (paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        rdist += obj.getInteger("distance")
                        rtime += obj.getDouble("duration")
                        rhighway += obj.getInteger("highspeed_distance")
                        rtraLightCount += obj.getInteger("trafficlight_count")
                        rtolls += obj.getInteger("tolls")
                        rtollsDistance += obj.getInteger("toll_distance")
                        rcoords_tmp.append(obj.getString("polyline"))

                        if (i == 0) rflen = obj.getInteger("flen")
                        if (i == paths.size() - 1) rtlen = obj.getInteger("tlen")

                        val polylineArr: Array[String] = obj.getString("polyline").split(";", -1)
                        val posStr: String = polylineArr.head + "_" + polylineArr.last
                        polyline_buff.append(posStr)

                        val steps: JSONArray = obj.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            val first_step: JSONObject = steps.getJSONObject(0)
                            val last_step: JSONObject = steps.getJSONObject(steps.size() - 1)

                            val first_links: JSONArray = first_step.getJSONArray("links")
                            val last_links: JSONArray = last_step.getJSONArray("links")

                            if (first_links != null && first_links.size() > 0) first_swid = first_links.getJSONObject(0).getString("sw_id")
                            if (last_links != null && last_links.size() > 0) last_swid = last_links.getJSONObject(last_links.size - 1).getString("sw_id")

                            steps_links_swid_buff.append(first_swid + "_" + last_swid)
                        }

                        if (obj.containsKey("voi_rule")) rulecount += obj.getJSONArray("voi_rule").size()

                    }
                }
                val rcoords: String = rcoords_tmp.mkString(";")
                if (polyline_buff.size > 1) rmultiPathPos = polyline_buff.mkString("|")
                if (steps_links_swid_buff.size > 1) rmultiPathSwid = steps_links_swid_buff.mkString("|")


                // 公共字段解析结束

                // 如果未闯行，写入未闯行的表
                if (!flag) {
                    val line: RunTrafficControlDataFromInter = RunTrafficControlDataFromInter(uuid, data_source, d_plan_order, flag, status, rdist, rtime, rhighway, rtraLightCount, rtolls,
                        rtollsDistance, qstartxy, qendxy, rcoords, rsteps, rflen, rtlen, rulecount, "", "", "", "", "", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", "", "", "", "", "", "", "", "", "", rmultiPathPos, rmultiPathSwid)
                    rules.append(line)
                } else {
                    // 对闯行的数据做处理
                    var ruleorder = 0
                    for (i <- 0 until paths.size()) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        if (obj.containsKey("voi_rule") && obj.getJSONArray("voi_rule").size() > 0) {
                            for (j <- 0 until obj.getJSONArray("voi_rule").size()) {
                                val rule: JSONObject = obj.getJSONArray("voi_rule").getJSONObject(j)
                                ruleorder = ruleorder + j + 1
                                val ruletype: String = rule.getString("type")
                                val rulepos: String = rule.getString("pos")
                                val ruleroadid: String = rule.getString("road_id")
                                val ruleoutroadid: String = rule.getString("out_road_id")
                                val ruleroadname: String = rule.getString("name")

                                val limit: JSONObject = rule.getJSONObject("limit")
                                var ruleid: String = ""
                                var Guid: String = ""
                                var limitweight: String = ""
                                var limitsize: String = ""
                                var limitwidth: String = ""
                                var limitaxload: String = ""
                                var limitload: String = ""
                                var limitaxcnt: String = ""
                                var limitpassport: String = ""
                                var limitholiday: String = ""
                                var limitvehicletype: String = ""
                                var limitoutflag: String = ""
                                var limitemitStand: String = ""
                                var limittailchar: String = ""
                                var limitstartdate: String = ""
                                var limitenddate: String = ""
                                var limitweek: String = ""
                                var limittime: String = ""
                                if (limit != null && limit.size() > 0) {
                                    ruleid = limit.getString("RuleID")
                                    Guid = limit.getString("Guid")
                                    limitweight = limit.getString("限重")
                                    limitsize = limit.getString("限高")
                                    limitwidth = limit.getString("限宽")
                                    limitaxload = limit.getString("限轴重")
                                    limitload = limit.getString("限载重")
                                    limitaxcnt = limit.getString("限轴数")
                                    limitpassport = limit.getString("通行证")
                                    limitholiday = limit.getString("节假日")
                                    limitvehicletype = limit.getString("车辆类型")
                                    limitoutflag = limit.getString("限车辆属地")
                                    limitemitStand = limit.getString("限燃油标号")
                                    limittailchar = limit.getString("限尾号")
                                    limitstartdate = limit.getString("开始日期")
                                    limitenddate = limit.getString("结束日期")
                                    limitweek = limit.getString("限星期")
                                    limittime = limit.getString("限时段")
                                }


                                var ruletimedesc: String = ""
                                var ruleregiondesc: String = ""
                                var rulevehicle: String = ""
                                var rulestrategy: String = ""
                                val region_rule: JSONArray = rule.getJSONArray("region_rule")
                                if (region_rule != null && region_rule.size() > 0) {
                                    ruletimedesc = region_rule.getJSONObject(0).getString("time")
                                    ruleregiondesc = region_rule.getJSONObject(0).getString("region")
                                    rulevehicle = region_rule.getJSONObject(0).getString("vehicle")
                                    rulestrategy = region_rule.getJSONObject(0).getString("strategy")
                                }

                                val ruleorder_tmp: String = ruleorder.toString
                                val line: RunTrafficControlDataFromInter = RunTrafficControlDataFromInter(uuid, data_source, d_plan_order, flag, status, rdist, rtime, rhighway, rtraLightCount, rtolls,
                                    rtollsDistance, qstartxy, qendxy, rcoords, rsteps, rflen, rtlen, rulecount, ruleorder_tmp, ruleid, ruletype, rulepos, ruleroadid, ruleoutroadid,
                                    ruleroadname, limitweight, limitsize, limitwidth, limitaxload, limitload, limitaxcnt, limitpassport, limitholiday, limitvehicletype,
                                    limitoutflag, limitemitStand, limittailchar, limitstartdate, limitenddate, limitweek, limittime, Guid, ruletimedesc, ruleregiondesc,
                                    rulevehicle, rulestrategy, rmultiPathPos, rmultiPathSwid)

                                rules.append(line)
                            }
                        }
                    }
                }

                rules
            } else rules
        } else rules

    }

    // 跑闯行服务
    def runLimitedService(logger: Logger, spark: SparkSession, originalDataDF: DataFrame): Unit = {
        import spark.implicits._

        val df: DataFrame = originalDataDF
          .repartition(10)
          .flatMap(r => {
              val (uuid, data_source, d_plan_order, jsonData) = callLimitedRoute(r)
              val listBuf: ListBuffer[RunTrafficControlDataFromInter] = parseLimitedData(uuid, data_source, d_plan_order, jsonData)
              listBuf
          })
          .repartition(200)
          .toDF()

        // 接口解析出的数据  和  原始数据关联上  -- 规划的数据
        val runLimitedResultDF: DataFrame = originalDataDF
          .join(df, Seq("uuid", "data_source", "d_plan_order"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_tralightcount", "task_id",
              "start_dept", "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm",
              "actual_run_time", "plan_run_time", "sort_num", "start_longitude", "end_longitude",
              "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code", "vehicle_serial",
              "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id", "start_time",
              "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2", "hko_vehicle_code",
              "trailer_vehicle_code", "source", "is_trailer", "vehicle_type", "vehicle_length", "width", "height",
              "color", "energy", "license", "emission", "axls_number", "vehicle_full_load_weight",
              "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2", "plandate", "grp2_order",
              "d_frequency", "d_frequencycost", "d_frequencytype", "d_freqratio", "d_route_id", "d_src_routeids",
              "data_source", "flag", "status", "rdist", "rtime", "rhighway", "rtralightcount", "rtolls",
              "rtollsdistance", "qstartxy", "qendxy", "rcoords", "rsteps", "rflen", "rtlen", "rulecount",
              "ruleorder", "ruleid", "ruletype", "rulepos", "ruleroadid", "ruleoutroadid", "ruleroadname",
              "limitweight", "limitsize", "limitwidth", "limitaxload", "limitload", "limitaxcnt", "limitpassport",
              "limitholiday", "limitvehicletype", "limitoutflag", "limitemitstand", "limittailchar",
              "limitstartdate", "limitenddate", "limitweek", "limittime", "guid", "ruletimedesc", "ruleregiondesc",
              "rulevehicle", "rulestrategy", "rmultipathpos", "rmultipathswid", "city", "version", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, runLimitedResultDF, "【规划的数据源】最终的结果数据")

        // 未闯行的数据
        val unLimitedDF: Dataset[Row] = runLimitedResultDF
          .filter("flag==false")
        df2HiveByOverwrite(logger, unLimitedDF, "dm_gis.mms_car_route_plan_detail_and_unlimited_info")

        // 闯行的数据
        val limitedDF: Dataset[Row] = runLimitedResultDF
          .filter("flag==true")
        df2HiveByOverwrite(logger, limitedDF, "dm_gis.mms_car_route_plan_detail_and_limited_info")

        runLimitedResultDF.unpersist()
    }

}
