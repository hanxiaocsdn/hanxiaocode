package app.runLimited

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.SparkConfigUtil

object GetIsBuildingReguIndicatorData {

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)


        // 统计匹配中断 轨迹维度 指标数据【统计近30天的数据】
        get_match_breakoff_indicator_by_locus(spark, logger, start_time, end_time)

        // 统计匹配中断 任务维度 指标数据【统计近30天的数据】
        get_match_breakoff_indicator_by_task(spark, logger, start_time, end_time)

        // 统计在建闯行 轨迹维度 指标数据【统计近30天的数据】
        get_isBuilding_indicator_by_locus(spark, logger, start_time, end_time)

        // 统计在建闯行 任务维度 指标数据【统计近30天的数据】
        get_isBuilding_indicator_by_task(spark, logger, start_time, end_time)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 匹配中断 轨迹维度 指标数据
    def get_match_breakoff_indicator_by_locus(spark: SparkSession, logger: Logger, start_time: String, end_time: String): Unit = {

        val sql: String =
            s"""
               |with t1 as(
               |  select
               |    version,
               |    city,
               |    groupby_id,
               |    inc_day,
               |    max(gd_match_break_track_num) as gd_match_break_track_num,
               |    max(jp_match_break_track_num) as jp_match_break_track_num
               |  from
               |    (
               |      select
               |        version,
               |        start_dept,
               |        substring(start_dept, 1, 3) as city,
               |        groupby_id,
               |        inc_day,
               |        if(data_source = '2', 1, 0) as gd_match_break_track_num,
               |        if(data_source = '0', 1, 0) as jp_match_break_track_num
               |      from
               |        dm_gis.gd_breakpoint_union_match
               |      where
               |        inc_day >= '$start_time'
               |        and inc_day <= '$end_time'
               |        and data_source in('0', '2')
               |    ) tmp1
               |  group by
               |    version,
               |    city,
               |    groupby_id,
               |    inc_day
               |),
               |t11 as(
               |  select
               |    version,
               |    city,
               |    inc_day,
               |    sum(gd_match_break_track_num) as gd_match_break_track_num,
               |    sum(jp_match_break_track_num) as jp_match_break_track_num
               |  from
               |    t1
               |  group by
               |    version,
               |    city,
               |    inc_day
               |),
               |t21 as(
               |  select
               |    version,
               |    city,
               |    inc_day,
               |    sum(gd_all_track_num) as gd_all_track_num
               |  from
               |    (
               |      select
               |        version,
               |        city,
               |        uuid,
               |        inc_day,
               |        max(gd_all_track_num) as gd_all_track_num
               |      from
               |        (
               |          select
               |            version,
               |            start_dept,
               |            substring(start_dept, 1, 3) as city,
               |            uuid,
               |            inc_day,
               |            if(data_source = '2', 1, 0) as gd_all_track_num
               |          from
               |            dm_gis.mms_car_route_plan_detail_and_unlimited_info
               |          where
               |            inc_day >= '$start_time'
               |            and inc_day <= '$end_time'
               |            and data_source = '2'
               |          union all
               |          select
               |            version,
               |            start_dept,
               |            substring(start_dept, 1, 3) as city,
               |            uuid,
               |            inc_day,
               |            if(data_source = '2', 1, 0) as gd_all_track_num
               |          from
               |            dm_gis.mms_car_route_plan_detail_and_limited_info
               |          where
               |            inc_day >= '$start_time'
               |            and inc_day <= '$end_time'
               |            and data_source = '2'
               |        ) tmp21
               |      group by
               |        version,
               |        city,
               |        uuid,
               |        inc_day
               |    ) tmp021
               |  group by
               |    version,
               |    city,
               |    inc_day
               |),
               |t22 as(
               |  select
               |    version,
               |    city,
               |    inc_day,
               |    sum(jp_all_track_num) as jp_all_track_num
               |  from
               |    (
               |      select
               |        version,
               |        city,
               |        uuid,
               |        inc_day,
               |        max(jp_all_track_num) as jp_all_track_num
               |      from
               |        (
               |          select
               |            version,
               |            start_dept,
               |            substring(start_dept, 1, 3) as city,
               |            uuid,
               |            inc_day,
               |            if(data_source = '0', 1, 0) as jp_all_track_num
               |          from
               |            dm_gis.mms_car_route_jp_detail_and_unlimited_info
               |          where
               |            inc_day >= '$start_time'
               |            and inc_day <= '$end_time'
               |            and data_source = '0'
               |          union all
               |          select
               |            version,
               |            start_dept,
               |            substring(start_dept, 1, 3) as city,
               |            uuid,
               |            inc_day,
               |            if(data_source = '0', 1, 0) as jp_all_track_num
               |          from
               |            dm_gis.mms_car_route_jp_detail_and_limited_info
               |          where
               |            inc_day >= '$start_time'
               |            and inc_day <= '$end_time'
               |            and data_source = '0'
               |        ) tmp22
               |      group by
               |        version,
               |        city,
               |        uuid,
               |        inc_day
               |    ) tmp022
               |  group by
               |    version,
               |    city,
               |    inc_day
               |),
               |t10 as(
               |-- 获取 每个轨迹的最终状态
               |select
               |  t2.inc_day,
               |  t2.version,
               |  t2.city,
               |  t2.data_source,
               |  t2.groupby_id,
               |  if(array_contains(collect_set(t1.work_status),'2'),'e','0') as mark1,
               |  if(array_contains(collect_set(t1.work_status),'1') and size(collect_set(t1.work_status)) = 1,'r','0') as mark2
               |from
               |  dm_gis.all_result_gd_breakpoint_check_rt_info t1
               |join
               |  dm_gis.gd_breakpoint_union_match t2
               |where
               |  t2.inc_day >='$start_time'
               |  and t2.inc_day <='$end_time'
               |  and t1.inc_day >='$start_time'
               |  and t1.inc_day <='$end_time'
               |  and t2.data_source in('0','2')
               |  and t1.swid = t2.swid
               |  and t1.next_swid = t2.next_swid
               |group by
               |  t2.inc_day,
               |  t2.version,
               |  t2.city,
               |  t2.data_source,
               |  t2.groupby_id
               |),
               |
               |t20 as(
               |-- 获取 高德、纠偏 数据正确、数据错误数量
               |select
               |  inc_day,
               |  version,
               |  city,
               |  sum(if(data_source='0' and mark2 = 'r',1,0)) as jp_right_num,
               |  sum(if(data_source='0' and mark1 = 'e',1,0)) as jp_error_num,
               |  sum(if(data_source='2' and mark2 = 'r',1,0)) as gd_right_num,
               |  sum(if(data_source='2' and mark1 = 'e',1,0)) as gd_error_num
               |from
               |  t10
               |group by
               |  inc_day,
               |  version,
               |  city
               |),
               |
               |t30 as(
               |  -- 维表信息
               |  select
               |    province_name,
               |    city_name,
               |    city
               |  from
               |    dm_gis.province_city_info
               |),
               |t40 as(
               |  -- 关联上维表信息
               |  select
               |    t30.province_name,
               |    t30.city_name,
               |    t11.inc_day,
               |    t11.version,
               |    t11.city,
               |    t11.gd_match_break_track_num,
               |    t11.jp_match_break_track_num
               |  from
               |    t30
               |    join t11 on t30.city = t11.city
               |),
               |t3 as(
               |  select
               |    t40.province_name,
               |    t40.city_name,
               |    t40.city,
               |    t40.version,
               |    t20.jp_right_num,
               |    t20.jp_error_num,
               |    t20.gd_right_num,
               |    t20.gd_error_num,
               |    t40.gd_match_break_track_num,
               |    t21.gd_all_track_num,
               |    t40.jp_match_break_track_num,
               |    t22.jp_all_track_num,
               |    t40.inc_day
               |  from
               |    t40
               |    left join t21 on t40.version = t21.version
               |    and t40.city = t21.city
               |    and t40.inc_day = t21.inc_day
               |    left join t22 on t40.version = t22.version
               |    and t40.city = t22.city
               |    and t40.inc_day = t22.inc_day
               |    left join t20 on t40.version = t20.version
               |    and t40.city = t20.city
               |    and t40.inc_day = t20.inc_day
               |)
               |
               |select
               |  concat_ws('_', inc_day, city, version) as id,
               |  province_name,
               |  city_name,
               |  city,
               |  version,
               |  jp_right_num,
               |  jp_error_num,
               |  gd_right_num,
               |  gd_error_num,
               |  gd_match_break_track_num,
               |  gd_all_track_num,
               |  jp_match_break_track_num,
               |  jp_all_track_num,
               |  inc_day
               |from
               |  t3
               |""".stripMargin

        logger.error(sql)
        val df: DataFrame = spark
          .sql(sql)
          .na.fill(0, Array(
            "jp_right_num",
            "jp_error_num",
            "gd_right_num",
            "gd_error_num",
            "gd_match_break_track_num",
            "gd_all_track_num",
            "jp_match_break_track_num",
            "jp_all_track_num"
        ))
          .coalesce(3)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, df, "匹配中断轨迹维度指标数据")

        df2HiveByOverwrite(logger, df, "dm_gis.gd_track_road_complete")
        df.unpersist()

    }

    // 匹配中断 任务维度 指标数据
    def get_match_breakoff_indicator_by_task(spark: SparkSession, logger: Logger, start_time: String, end_time: String): Unit = {

        val sql: String =
            s"""
               |with t1 as(
               |-- 获取高德、纠偏 数据正确、数据错误、已核实数量
               |select
               |  inc_day,
               |  version,
               |  substring(adcode,1,4) as area_code,
               |  sum(if(data_source = '0',1,0)) as jp_verify_num,
               |  sum(if(data_source = '2',1,0)) as gd_verify_num,
               |  sum(if(data_source = '0' and work_status='1',1,0)) as jp_right_num,
               |  sum(if(data_source = '0' and work_status='2',1,0)) as jp_error_num,
               |  sum(if(data_source = '2' and work_status='1',1,0)) as gd_right_num,
               |  sum(if(data_source = '2' and work_status='2',1,0)) as gd_error_num
               |from
               |  dm_gis.all_result_gd_breakpoint_check_rt_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day <= '$end_time'
               |  and data_source in('0','2')
               |group by
               |  inc_day,
               |  version,
               |  substring(adcode,1,4)
               | ),
               |
               | t2 as(
               | -- 获取高德、纠偏 任务数量
               |select
               |  inc_day,
               |  version,
               |  substring(adcode,1,4) as area_code,
               |  sum(if(data_source = '0',1,0)) as jp_task_cnt,
               |  sum(if(data_source = '2',1,0)) as gd_task_cnt
               |from
               |  dm_gis.all_result_gd_breakpoint_swid_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day <= '$end_time'
               |  and data_source in('0','2')
               |group by
               |  inc_day,
               |  version,
               |  substring(adcode,1,4)
               |),
               |
               |t3 as(
               |-- 维表信息
               |select
               |  province_name,
               |  city_name,
               |  city,
               |  area_code
               |from
               |  dm_gis.province_city_info
               |),
               |
               |t4 as(
               |-- 任务数 关联上维表
               |select
               |  t3.*,
               |  t2.inc_day,
               |  t2.version,
               |  t2.jp_task_cnt,
               |  t2.gd_task_cnt
               |from
               |  t3
               |inner join t2 on t3.area_code = t2.area_code
               |),
               |
               |t5 as(
               |-- t4 关联上t1
               |select
               |  t4.province_name,
               |  t4.city_name,
               |  t4.city,
               |  t4.jp_task_cnt,
               |  t4.gd_task_cnt,
               |  t1.jp_verify_num,
               |  t1.gd_verify_num,
               |  t1.jp_right_num,
               |  t1.jp_error_num,
               |  t1.gd_right_num,
               |  t1.gd_error_num,
               |  t4.version,
               |  t4.inc_day
               |from
               |  t4
               |left join t1
               |on t4.area_code = t1.area_code and t4.inc_day = t1.inc_day and t4.version = t1.version
               |)
               |
               |select
               |  concat_ws('_', inc_day, city, version) as id,
               |  province_name,
               |  city_name,
               |  city,
               |  jp_task_cnt,
               |  gd_task_cnt,
               |  jp_verify_num,
               |  gd_verify_num,
               |  jp_right_num,
               |  jp_error_num,
               |  gd_right_num,
               |  gd_error_num,
               |  version,
               |  inc_day
               |from
               |  t5
               |""".stripMargin

        logger.error(sql)
        val df: DataFrame = spark
          .sql(sql)
          .na.fill(0, Array(
            "jp_task_cnt",
            "gd_task_cnt",
            "jp_verify_num",
            "gd_verify_num",
            "jp_right_num",
            "jp_error_num",
            "gd_right_num",
            "gd_error_num"
        ))
          .coalesce(3)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, df, "匹配中断任务维度指标数据")

        df2HiveByOverwrite(logger, df, "dm_gis.gd_track_road_tast_complete")
        df.unpersist()

    }

    // 在建闯行 轨迹维度 指标数据
    def get_isBuilding_indicator_by_locus(spark: SparkSession, logger: Logger, start_time: String, end_time: String): Unit = {

        val sql: String =
            s"""
               |with t3 as(
               |  -- 维表信息
               |  select
               |    province_name,
               |    city_name,
               |    city
               |  from
               |    dm_gis.province_city_info
               |),
               |-- 轨迹维度
               |t1 as(
               |  select
               |    version,
               |    substring(start_dept, 1, 3) as city,
               |    uuid,
               |    inc_day,
               |    1 as isbuilding_track_num
               |  from
               |    dm_gis.mms_car_route_plan_and_jp_limited_result_info
               |  where
               |    inc_day >= '$start_time'
               |    and inc_day <= '$end_time'
               |  group by
               |    version,
               |    substring(start_dept, 1, 3),
               |    uuid,
               |    inc_day
               |),
               |t11 as(
               |  select
               |    t3.province_name,
               |    t3.city_name,
               |    t1.version,
               |    t1.inc_day,
               |    t1.city,
               |    sum(isbuilding_track_num) as isbuilding_track_num
               |  from
               |    t1
               |    join t3
               |  where
               |    t1.city = t3.city
               |  group by
               |    t1.version,
               |    t1.city,
               |    t1.inc_day,
               |    t3.province_name,
               |    t3.city_name
               |),
               |t2 as(
               |  select
               |    version,
               |    substring(start_dept, 1, 3) as city,
               |    inc_day,
               |    uuid,
               |    1 as all_track_num
               |  from
               |    dm_gis.mms_car_route_jp_detail_info
               |  where
               |    inc_day >= '$start_time'
               |    and inc_day <= '$end_time'
               |  group by
               |    version,
               |    substring(start_dept, 1, 3),
               |    uuid,
               |    inc_day
               |),
               |t21 as(
               |  select
               |    version,
               |    city,
               |    inc_day,
               |    sum(all_track_num) as all_track_num
               |  from
               |    t2
               |  group by
               |    city,
               |    version,
               |    inc_day
               |),
               |t10 as(
               |  -- 获取 每个轨迹的最终状态
               |  select
               |    t2.inc_day,
               |    t2.version,
               |    substring(t2.start_dept, 1, 3) as city,
               |    t2.uuid,
               |    if(
               |      array_contains(collect_set(t1.work_status), '2'),
               |      'e',
               |      '0'
               |    ) mark1,
               |    if(
               |      array_contains(collect_set(t1.work_status), '1')
               |      and size(collect_set(t1.work_status)) = 1,
               |      'r',
               |      '0'
               |    ) mark2
               |  from
               |    dm_gis.mms_isbuilding_data_result_info t1
               |    join dm_gis.mms_car_route_plan_and_jp_limited_result_info t2
               |  where
               |    t2.inc_day >= '$start_time'
               |    and t2.inc_day <= '$end_time'
               |    and t1.inc_day >= '$start_time'
               |    and t1.inc_day <= '$end_time'
               |    and t1.rulepos = t2.rulepos
               |    and t1.ruleroadid = t2.ruleroadid
               |    and t2.ruletype = '在建'
               |  group by
               |    t2.inc_day,
               |    t2.version,
               |    substring(t2.start_dept, 1, 3),
               |    t2.uuid
               |),
               |t20 as(
               |  -- 获取数据正确、数据错误数量
               |  select
               |    inc_day,
               |    version,
               |    city,
               |    sum(if(mark2 = 'r', 1, 0)) right_num,
               |    sum(if(mark1 = 'e', 1, 0)) error_num
               |  from
               |    t10
               |  group by
               |    inc_day,
               |    version,
               |    city
               |),
               |t4 as(
               |  select
               |    t11.province_name,
               |    t11.city_name,
               |    t11.version,
               |    t11.city,
               |    t11.isbuilding_track_num,
               |    t21.all_track_num,
               |    t20.right_num,
               |    t20.error_num,
               |    t11.inc_day
               |  from
               |    t11
               |    left join t21 on t11.version = t21.version
               |    and t11.city = t21.city
               |    and t11.inc_day = t21.inc_day
               |    left join t20 on t11.version = t20.version
               |    and t11.city = t20.city
               |    and t11.inc_day = t20.inc_day
               |)
               |
               |select
               |  concat_ws('_', inc_day, city, version) as id,
               |  province_name,
               |  city_name,
               |  version,
               |  city,
               |  isbuilding_track_num,
               |  all_track_num,
               |  right_num,
               |  error_num,
               |  inc_day
               |from
               |  t4
               |""".stripMargin

        logger.error(sql)
        val df: DataFrame = spark
          .sql(sql)
          .na.fill(0, Array(
            "isbuilding_track_num",
            "all_track_num",
            "right_num",
            "error_num"
        ))
          .coalesce(3)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, df, "在建闯行轨迹维度指标数据")

        df2HiveByOverwrite(logger, df, "dm_gis.isbuilding_track_quota")
        df.unpersist()

    }

    // 在建闯行 任务维度 指标数据
    def get_isBuilding_indicator_by_task(spark: SparkSession, logger: Logger, start_time: String, end_time: String): Unit = {

        val sql: String =
            s"""
               |with t3 as(
               |-- 维表信息
               |select
               |  province_name,
               |  city_name,
               |  city,
               |  area_code
               |from
               |  dm_gis.province_city_info
               |),
               |--任务维度
               |t30 as(
               |-- 获取
               |select
               |  t2.inc_day,
               |  t2.version,
               |  substring(t2.adcode, 1, 4) as area_code,
               |  if(array_contains(collect_set(t1.work_status),'2'),'e','0') as mark1,
               |  if(array_contains(collect_set(t1.work_status),'1') and size(collect_set(t1.work_status)) = 1,'r','0') as mark2
               |from
               |  dm_gis.mms_isbuilding_data_result_info t1
               |join
               |  dm_gis.mms_isbuilding_data_issue_info t2
               |where
               |  t2.inc_day >='$start_time'
               |  and t2.inc_day <='$end_time'
               |  and t1.inc_day >='$start_time'
               |  and t1.inc_day <='$end_time'
               |  and t1.rulepos = t2.rulepos
               |  and t1.ruleroadid = t2.ruleroadid
               |group by
               |  t2.inc_day,
               |  t2.version,
               |  substring(t2.adcode, 1, 4)
               |),
               |
               |t40 as(
               |-- 获取数据正确、数据错误数量
               |select
               |  inc_day,
               |  version,
               |  area_code,
               |  sum(if(mark2 = 'r',1,0)) right_num,
               |  sum(if(mark1 = 'e',1,0)) error_num,
               |  count(1) verify_num
               |from
               |  t30
               |group by
               |  inc_day,
               |  version,
               |  area_code
               |),
               |
               |t50 as(
               | select
               |  t3.province_name,
               |  t3.city_name,
               |  t3.city,
               |  t3.area_code,
               |  t40.version,
               |  t40.right_num,
               |  t40.error_num,
               |  t40.verify_num,
               |  t40.inc_day
               | from
               |   t3
               | join
               |   t40
               | on t3.area_code = t40.area_code
               |)
               |
               |select
               |  concat_ws('_', inc_day, city, version) as id,
               |  province_name,
               |  city_name,
               |  city,
               |  area_code,
               |  version,
               |  right_num,
               |  error_num,
               |  verify_num,
               |  inc_day
               |from
               |  t50
               |""".stripMargin

        logger.error(sql)
        val df: DataFrame = spark
          .sql(sql)
          .na.fill(0, Array(
            "right_num",
            "error_num",
            "verify_num"
        ))
          .coalesce(3)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, df, "在建闯行任务维度指标数据")

        df2HiveByOverwrite(logger, df, "dm_gis.isbuilding_track_tast_quota")
        df.unpersist()

    }

}
