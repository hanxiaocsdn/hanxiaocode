package app.runLimited

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.SparkConfigUtil

import java.text.SimpleDateFormat


/**
  * 聚合结果 下发生产核实
  *
  * 8. 任务下发流程
  */
object GetTaskIssueDataFromAggreResult {

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 5) {
            logger.error(
                """
                  |需要输入5个参数：
                  |    start_time、end_time、current_time、two_month_ago、three_month_ago
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val current_time: String = args(2)
        val two_month_ago: String = args(3)
        val three_month_ago: String = args(4)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"当前任务下发日期：$current_time")
        logger.error(s"开始日期60天之前的日期：$two_month_ago")
        logger.error(s"3个月之前的日期：$three_month_ago")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 获取聚合后的闯行数据
        val aggrLimitedSql: String =
            s"""
               |select
               |  *,
               |  concat_ws('_',
               |    if(rulepos == '' or rulepos is null,'n',	rulepos),
               |    if(ruleroadid == '' or ruleroadid is null,'n',	ruleroadid),
               |    if(ruleoutroadid == '' or ruleoutroadid is null,'n',	ruleoutroadid),
               |    if(ruletype == '' or ruletype is null,'n',	ruletype),
               |    if(limitweight == '' or limitweight is null,'n',	limitweight),
               |    if(limitsize == '' or limitsize is null,'n',	limitsize),
               |    if(limitwidth == '' or limitwidth is null,'n',	limitwidth),
               |    if(limitaxload == '' or limitaxload is null,'n',	limitaxload),
               |    if(limitload == '' or limitload is null,'n',	limitload),
               |    if(limitaxcnt == '' or limitaxcnt is null,'n',	limitaxcnt),
               |    if(limitpassport == '' or limitpassport is null,'n',	limitpassport),
               |    if(limitholiday == '' or limitholiday is null,'n',	limitholiday),
               |    if(limitoutflag == '' or limitoutflag is null,'n',	limitoutflag),
               |    if(limitemitstand == '' or limitemitstand is null,'n',	limitemitstand),
               |    if(limitweek == '' or limitweek is null,'n',	limitweek),
               |    if(limittime == '' or limittime is null,'n',	limittime)
               |  ) rtk
               |from
               |  dm_gis.mms_car_route_plan_and_jp_limited_aggre_result_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 最近2个月下发过的数据
        val aggrLimited2Sql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_aggre_data_issue_info
               |where
               |  inc_day >= '$two_month_ago'
               |  and inc_day < '$start_time'
               |""".stripMargin

        // 最近3个月累计核实结果数据
        val hisCheckResultSql: String =
            s"""
               |-- 对字段为空 和 null做预处理
               |with t1 as(
               |select
               |  rulepos,
               |  guid,
               |  work_status,
               |  class_first,
               |  task_tm,
               |  if(ruleroadid == '' or ruleroadid is null,'n',	ruleroadid)	ruleroadid,
               |  if(ruleoutroadid == '' or ruleoutroadid is null,'n',	ruleoutroadid)	ruleoutroadid,
               |  if(ruletype == '' or ruletype is null,'n',	ruletype)	ruletype,
               |  if(limitweight == '' or limitweight is null,'n',	limitweight)	limitweight,
               |  if(limitsize == '' or limitsize is null,'n',	limitsize)	limitsize,
               |  if(limitwidth == '' or limitwidth is null,'n',	limitwidth)	limitwidth,
               |  if(limitaxload == '' or limitaxload is null,'n',	limitaxload)	limitaxload,
               |  if(limitload == '' or limitload is null,'n',	limitload)	limitload,
               |  if(limitaxcnt == '' or limitaxcnt is null,'n',	limitaxcnt)	limitaxcnt,
               |  if(limitpassport == '' or limitpassport is null,'n',	limitpassport)	limitpassport,
               |  if(limitholiday == '' or limitholiday is null,'n',	limitholiday)	limitholiday,
               |  if(limitoutflag == '' or limitoutflag is null,'n',	limitoutflag)	limitoutflag,
               |  if(limitemitstand == '' or limitemitstand is null,'n',	limitemitstand)	limitemitstand,
               |  if(limitweek == '' or limitweek is null,'n',	limitweek)	limitweek,
               |  if(limittime == '' or limittime is null,'n',	limittime)	limittime
               |from
               |  dm_gis.mms_car_route_aggre_data_checked_result_info
               |where
               |  inc_day >= '$three_month_ago'
               |  and inc_day < '$end_time'
               |),
               |
               |-- 生产唯一key:rtk
               |t2 as(
               |select
               |  concat_ws('_',rulepos,ruleroadid,ruleoutroadid,ruletype,limitweight,limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,limitoutflag,limitemitstand,limitweek,limittime) rtk,
               |  rulepos,
               |  guid,
               |  work_status,
               |  class_first,
               |  task_tm
               |from
               | t1
               |)
               |
               | -- 按key排序取最新
               |select
               |  rtk,
               |  rulepos,
               |  guid,
               |  work_status,
               |  class_first,
               |  task_tm
               |from(
               |  select
               |    rtk,
               |    rulepos,
               |    guid,
               |    work_status,
               |    class_first,
               |    task_tm,
               |	row_number() over(partition by rtk order by task_tm desc) as rn
               |  from
               |    t2
               |) t
               |where rn = 1
               |""".stripMargin

        // 版本对比获取到的数据
        val compareSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_aggre_data_issue_info_v2
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin


        // 进行剔除
        val aggrLimitedFisrtFilterDS: DataFrame = firstFilter(logger, spark, aggrLimitedSql)

        // 第二次过滤
        val (aggrLimitedSeconrdFilterHisDS1, aggrLimitedSeconrdFilterHisDS2) = secondFilter(logger, spark, aggrLimitedFisrtFilterDS, hisCheckResultSql, current_time)

        // 第三次过滤：过滤最近已经下发过的数据
        val aggrLimitedThreeFilterHisDF: DataFrame = thirdFilter(logger, spark, aggrLimitedSeconrdFilterHisDS1, aggrLimitedSeconrdFilterHisDS2, aggrLimited2Sql, current_time)

        //最终下发的数据
        finalIssueData(logger, spark, aggrLimitedFisrtFilterDS, aggrLimitedThreeFilterHisDF, aggrLimited2Sql, compareSql, start_time, end_time)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()
    }

    // 判断该条数据是否应该下发
    def mark_flag(r: Row, current_time: String): (String, Boolean, Boolean) = {
        // flag 标识这个条数据是否应该下发，true → 下发   false → 不下发
        // is_send = true 表示已经下发过，默认都没下发过
        var flag: Boolean = false
        var is_send: Boolean = true
        val class_first_list: List[String] = List("路段规制缺失", "路段规制冗余", "路段规制信息错误",
            "路口禁止信息缺失", "路口禁止信息冗余", "路口禁止信息错误")

        val rtk: String = r.getAs[String]("rtk")
        val task_tm: String = r.getAs[String]("task_tm")

        if (task_tm == null) {
            /*
            没有关联上的数据，分2种情况：
            1、这条数据从来都没有下发过
            2、这条数据之前下发过，但是核实结果还没有推送过来
             */
            flag = true
            is_send = false
        }
        else {
            // 能关联上的数据，说明之前已经下发过
            val fm = new SimpleDateFormat("yyyyMMdd")
            val task_tm_timestamp: Long = fm.parse(task_tm).getTime
            val current_time_timestamp: Long = fm.parse(current_time).getTime
            val d: Long = (current_time_timestamp - task_tm_timestamp) / (1000 * 3600 * 24)
            val work_status: String = r.getAs[String]("work_status")
            val class_first: String = r.getAs[String]("class_first")

            if ((work_status == "5" || work_status == "6") && d == 60) flag = true
            else if (work_status == "2" && class_first_list.contains(class_first) && d == 30) flag = true
            else if (work_status == "2" && !class_first_list.contains(class_first) && d == 30) flag = true
            else if ((work_status == "4" || work_status == "3") && d == 15) flag = true
        }

        (rtk, flag, is_send)
    }

    // 第一次过滤
    def firstFilter(logger: Logger, spark: SparkSession, aggrLimitedSql: String): DataFrame = {
        logger.error(aggrLimitedSql)

        val aggrLimitedFisrtFilterDS: DataFrame = spark
          .sql(aggrLimitedSql)
          .dropDuplicates("guid", "rulepos")
          .where("cast(ruleid as int) < 100000")
          .where("cast(limitsize as double) <= 4.2 or limitsize = ''")
          .where("data_source not in('1','2','3')")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, aggrLimitedFisrtFilterDS, "第一次过滤后的数据")

        aggrLimitedFisrtFilterDS
    }

    // 第二次过滤
    def secondFilter(logger: Logger, spark: SparkSession, aggrLimitedFisrtFilterDS: DataFrame, hisCheckResultSql: String, current_time: String): (DataFrame, DataFrame) = {
        import spark.implicits._

        logger.error(hisCheckResultSql)

        val hisCheckResultDF: DataFrame = spark
          .sql(hisCheckResultSql)
          .select("rtk", "rulepos", "guid", "task_tm", "work_status", "class_first")

        val df: DataFrame = aggrLimitedFisrtFilterDS
          .select("rtk")
          .join(hisCheckResultDF, Seq("rtk"), "left")
          .map(r => {
              val (rtk, flag, is_send) = mark_flag(r, current_time)
              (rtk, flag, is_send)
          })
          .toDF("rtk", "flag", "is_send")
          .persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, df, "第二次过滤的中间临时数据")

        val aggrLimitedSeconrdFilterHisDS1: DataFrame = df
          .filter("flag = true")
          .filter("is_send = true")
          .drop("flag", "is_send")
          .persist(StorageLevel.MEMORY_AND_DISK)

        aggrLimitedSeconrdFilterHisDS1.count()

        val aggrLimitedSeconrdFilterHisDS2: DataFrame = df
          .filter("is_send = false")
          .persist(StorageLevel.MEMORY_AND_DISK)

        aggrLimitedSeconrdFilterHisDS2.count()

        (aggrLimitedSeconrdFilterHisDS1, aggrLimitedSeconrdFilterHisDS2)
    }

    // 第三次过滤
    def thirdFilter(logger: Logger, spark: SparkSession, aggrLimitedSeconrdFilterHisDS1: DataFrame, aggrLimitedSeconrdFilterHisDS2: DataFrame, aggrLimited2Sql: String, current_time: String): DataFrame = {
        logger.error(aggrLimited2Sql)

        val aggrLimited2DS: Dataset[Row] = spark.sql(aggrLimited2Sql)
          .dropDuplicates("rtk")

        val aggrLimitedThreeFilterHisDF: DataFrame = aggrLimitedSeconrdFilterHisDS2
          .join(aggrLimited2DS, Seq("rtk"), "left")
          .filter("ruleid is null")
          .select("rtk")
          .union(aggrLimitedSeconrdFilterHisDS1)
          .withColumn("task_tm", lit(current_time))
          .withColumn("task_mark", lit("0"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, aggrLimitedThreeFilterHisDF, "第三次过滤后的数据量")

        aggrLimitedThreeFilterHisDF
    }

    // 最终下发的数据
    def finalIssueData(logger: Logger, spark: SparkSession, aggrLimitedFisrtFilterDS: DataFrame, aggrLimitedThreeFilterHisDF: DataFrame, aggrLimited2Sql: String, compareSql: String, start_time: String, end_time: String): Unit = {
        import spark.implicits._

        // 线上每日生产的作业数据
        val resultDF1: DataFrame = aggrLimitedFisrtFilterDS
          .join(aggrLimitedThreeFilterHisDF, Seq("rtk"))
          .withColumn("area_code2", $"area_code")
          .withColumn("version2", $"version")
          .withColumn("inc_day2", $"inc_day")
          .drop("area_code", "version", "inc_day")

        // 线下获取到的作业数据
        val aggrLimited2DF: DataFrame = spark.sql(aggrLimited2Sql)
          .select("rtk", "ruleid")
          .withColumnRenamed("ruleid", "ruleid2")

        val resultDF2: DataFrame = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("sep", "\t")
          .load("/user/89018313/upload/rule_orign.csv")
          .filter(s"inc_day >= '$start_time' and inc_day < '$end_time' ")
          .join(aggrLimited2DF, Seq("rtk"), "left")
          .filter("ruleid2 is null")
          .drop("ruleid2")

        // 版本对比获取的作业数据
        val resultDF3: DataFrame = spark
          .sql(compareSql)
          .filter("cast(ruleid as int) < 100000")
          .filter("cast(limitsize as double) <= 4.2 or limitsize = ''")
          .filter("data_source not in('1','2','3')")
          .join(aggrLimited2DF, Seq("rtk"), "left")
          .filter("ruleid2 is null")
          .drop("ruleid2")

        val resultDF: DataFrame = resultDF1
          .union(resultDF2)
          .union(resultDF3)
          .dropDuplicates("rtk")
          .persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, resultDF, "最终下发的数据")

        // 最终的数据落表
        df2HiveByOverwrite(logger, resultDF, "dm_gis.mms_car_route_aggre_data_issue_info")

        aggrLimitedFisrtFilterDS.unpersist()
        aggrLimitedThreeFilterHisDF.unpersist()
        resultDF.unpersist()
    }

}
