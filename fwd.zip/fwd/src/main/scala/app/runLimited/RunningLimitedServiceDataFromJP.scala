package app.runLimited

import app.runLimited.GetRoutePlanDataFromGDAndCTAndJY.interStatus2Hive
import app.runLimited.RunningLimitedServiceDataFromPlan.parseLimitedData
import com.alibaba.fastjson.{JSON, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.RunTrafficControlDataFromInter
import org.apache.spark.SparkContext
import org.apache.spark.sql._
import org.apache.spark.sql.functions.lit
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getVersion}
import utils.HttpClientUtil.getJsonByGet2
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable.ListBuffer

/**
  * 使用 纠偏的数据 跑闯行
  *
  * 4. 关联纠偏的数据，使用纠偏数据 跑闯行
  */
object RunningLimitedServiceDataFromJP {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")
    val version_url: String = config.getString("version_url")


    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)
        val sc: SparkContext = spark.sparkContext

        // 记录调用qm接口的成功、失败次数
        val qm_success_acc: LongAccumulator = sc.longAccumulator
        val qm_fail_acc: LongAccumulator = sc.longAccumulator

        // 获取纠偏的数据 his_abnormal 、abnormal
        val jpsql1: String =
            s"""
               |select
               |  t1.*,
               |  t2.his_abnormal,
               |  t3.abnormal,
               |  '0' data_source
               |from
               |  (select t.*,concat(task_id,'_',start_dept,'_',end_dept) uuid,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.mms_car_locus_task_detail_para_plan_info t where inc_day >= '$start_time' and inc_day < '$end_time') t1
               |join
               |  (select his_abnormal,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_his_traj_ab_info t where t.his_abnormal != '-1' and inc_day >= '$start_time' and inc_day < '$end_time' ) t2
               |on t1.uuid2 = t2.uuid2
               |join
               |  (select abnormal, concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_traj_simgroup_info t where !(t.abnormal regexp '4|5') and inc_day >= '$start_time' and inc_day < '$end_time' ) t3
               |on t1.uuid2 = t3.uuid2
               |""".stripMargin

        //获取纠偏的数据 coords 、jp_swid、jp_status
        val dlr = '$'
        val jpsql2: String =
            s"""
               |select
               |  info
               |from
               |  dm_gis.eta_traj_info t
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and get_json_object(info, '$dlr.carrier_type') = 0
               |""".stripMargin

        val origJPDataDF: DataFrame = getJPData(logger, spark, jpsql1, jpsql2)

        // 跑闯行服务，获取相应的数据，并对数据做解析
        runLimitedServiceFromJP(logger, spark, origJPDataDF, qm_success_acc, qm_fail_acc, className)


        logger.error("运行结束！")


        // 程序运行结束
        spark.stop()
    }

    // 调用闯行的接口
    def callLimitedRoute(r: Row): (String, String, Int, JSONObject) = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = 0

        var origin: String = ""
        var destination: String = ""
        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
          .replaceAll("'", "")
        val coordsArr: Array[String] = coords.split("\\|")
        for (i <- coordsArr.indices) {
            if (i == 0) origin = coordsArr(i)
            if (i == coordsArr.length - 1) destination = coordsArr(i)
        }

        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val emitStand: String = r.getAs[String]("emission")
        val energy: String = r.getAs[String]("energy")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val Mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val width: Double = r.getAs[Double]("width")
        val Size: String = r.getAs[String]("vehicle_length")
        val axlenumber: String = r.getAs[String]("axls_number")
        val No: String = r.getAs[String]("task_id")
        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&origin=$origin&destination=$destination&stype=0&etype=0&plate=$plate" +
          s"&plateColor=$plateColor&emitStand=$emitStand&energy=$energy&weight=$weight&vehicle=$vehicle&Mload=$Mload" +
          s"&height=$height&width=$width&Size=$Size&axlenumber=$axlenumber&passport=100000&mode=2&speed=1&No=$No&Toll=1&date=$date&len_diff=50&len_percent=0.5"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonStr: String = mapData.get("content").toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }

        (uuid, data_source, d_plan_order, json)
    }

    // 获取纠偏的原始数据
    def getJPData(logger: Logger, spark: SparkSession, jpsql1: String, jpsql2: String): DataFrame = {
        import spark.implicits._

        logger.error(jpsql1)
        logger.error(jpsql2)

        val df1: DataFrame = spark.sql(jpsql1)
        val df2: DataFrame = spark
          .sql(jpsql2)
          .rdd
          .map(r => {
              val info: String = r.getAs[String]("info")
              val jsonObj: JSONObject = JSON.parseObject(info)

              val task_id: String = jsonObj.getString("task_id")
              val start_dept: String = jsonObj.getString("start_dept")
              val end_dept: String = jsonObj.getString("end_dept")
              val uuid2: String = task_id + start_dept + end_dept

              val jp_swid_tmp: String = jsonObj.getString("jp_swid")
              val coords_tmp: String = jsonObj.getString("rt_coords")
              val jp_status_tmp: String = jsonObj.getString("status")

              var coords = ""
              var jp_swid = ""
              var jp_status = ""
              if (jp_swid_tmp != null && jp_swid_tmp.nonEmpty && coords_tmp != null && coords_tmp.nonEmpty && jp_status_tmp != null && jp_status_tmp.nonEmpty) {
                  coords = coords_tmp.replaceAll("\"", "")
                    .replaceAll("\\[", "")
                    .replaceAll("],", "|")
                    .replaceAll("]", "")

                  jp_swid = jp_swid_tmp
                    .replaceAll("\\[", "")
                    .replaceAll("]", "")

                  jp_status = jp_status_tmp
                    .replaceAll("\\[", "")
                    .replaceAll("]", "")
              }

              (uuid2, coords, jp_swid, jp_status)
          })
          .toDF("uuid2", "coords", "jp_swid", "jp_status")
          .filter("coords !=''")

        // 获取用于跑闯行的数据   -- 纠偏的数据

        val xmlStr: String = getJsonByGet2(version_url, 10, "utf-8")
        val version: String = getVersion(xmlStr)

        val origJPDataDF: DataFrame = df1
          .join(df2, Seq("uuid2"))
          .withColumn("version", lit(version))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑路径规划数据信息： -- 纠偏的数据源
        GetDFCountAndSampleData(logger, origJPDataDF, "【纠偏的数据源】用于跑闯行的数据")
        df2HiveByOverwrite(logger, origJPDataDF, "dm_gis.mms_car_route_jp_detail_info")

        origJPDataDF
    }

    // 纠偏的数据跑闯行服务
    def runLimitedServiceFromJP(logger: Logger, spark: SparkSession, origJPDataDF: DataFrame, qm_success_acc: LongAccumulator, qm_fail_acc: LongAccumulator, className: String): Unit = {
        import spark.implicits._

        val jpLimited: DataFrame = origJPDataDF
          .repartition(10)
          .flatMap(r => {
              val (uuid, data_source, d_plan_order, jsonData) = callLimitedRoute(r)
              val listBuf: ListBuffer[RunTrafficControlDataFromInter] = parseLimitedData(uuid, data_source, d_plan_order, jsonData)
              if (listBuf.nonEmpty) {
                  if (listBuf.head.status == "0") qm_success_acc.add(1L)
                  else qm_fail_acc.add(1L)
              } else qm_fail_acc.add(1L)

              listBuf
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 接口解析出的数据  和  原始数据关联上  --纠偏的数据
        val jpResultDF: DataFrame = origJPDataDF
          .drop("data_source")
          .join(jpLimited, "uuid")
          .select("uuid", "task_id", "start_dept", "end_dept", "his_coords", "start_type", "end_type",
              "start_tm", "end_tm", "actual_run_time", "plan_run_time", "sort_num", "start_longitude",
              "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code",
              "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id",
              "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2",
              "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type", "vehicle_length",
              "width", "height", "color", "energy", "license", "emission", "axls_number", "vehicle_full_load_weight",
              "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2", "plandate", "grp2_order",
              "uuid2", "his_abnormal", "abnormal", "coords", "jp_swid", "jp_status", "data_source", "flag", "status",
              "rdist", "rtime", "rhighway", "rtralightcount", "rtolls", "rtollsdistance", "qstartxy", "qendxy",
              "rcoords", "rsteps", "rflen", "rtlen", "rulecount", "ruleorder", "ruleid", "ruletype", "rulepos",
              "ruleroadid", "ruleoutroadid", "ruleroadname", "limitweight", "limitsize", "limitwidth", "limitaxload",
              "limitload", "limitaxcnt", "limitpassport", "limitholiday", "limitvehicletype", "limitoutflag",
              "limitemitstand", "limittailchar", "limitstartdate", "limitenddate", "limitweek", "limittime",
              "guid", "ruletimedesc", "ruleregiondesc", "rulevehicle", "rulestrategy", "rmultipathpos", "rmultipathswid", "city", "version", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpResultDF, "【纠偏的数据源】最终的结果数据")


        // 对未闯行的数据写入hive表   -- 纠偏的数据
        val unLimited: Dataset[Row] = jpResultDF
          .filter("flag==false")

        df2HiveByOverwrite(logger, unLimited, "dm_gis.mms_car_route_jp_detail_and_unlimited_info")

        // 对闯行的数据写入hive表   -- 纠偏的数据

        val limitedDF: Dataset[Row] = jpResultDF
          .filter("flag==true")

        df2HiveByOverwrite(logger, limitedDF, "dm_gis.mms_car_route_jp_detail_and_limited_info")

        // 释放缓存
        jpResultDF.unpersist()

        interStatus2Hive(logger, spark, "qm_url", qm_url, className, qm_success_acc, qm_fail_acc)
    }

}