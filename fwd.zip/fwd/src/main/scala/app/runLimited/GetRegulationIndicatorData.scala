package app.runLimited

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{concat_ws, count}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getDataFrame, getVersion}
import utils.HttpClientUtil.getJsonByGet2
import utils.SparkConfigUtil

import java.sql.{Connection, PreparedStatement}
import scala.collection.mutable

/**
  * 输出 规制指标数据
  *
  * 9. 输出每日规制指标数据
  */
object GetRegulationIndicatorData {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val version_url: String = config.getString("version_url")

    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useUnicode=true&amp;characterEncoding=utf-8"
    val userName = "gis_oms_pns"
    val passWd = "gis_oms_pns@123@"

    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入3个参数：
                  |    thirty_day_ago_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }
        // 接收外部传递进来的变量
        val thirty_day_ago_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"thirty_day_ago_time:$thirty_day_ago_time")
        logger.error(s"end_time:$end_time")

//        val xmlStr: String = getJsonByGet2(version_url, 10, "utf-8")
//        val version: String = getVersion(xmlStr)
//
//        logger.error(s"今日底图版本号：$version")
//
//        logger.error("<============ 以下是基于轨迹维度的统计指标 ============>")
//
//        // 纠偏的数据闯行过后最终的结果数据 【取近30天的数据】
//        val jpLimitedDataSql: String =
//            s"""
//               |select
//               |  concat_ws('_',
//               |    if(rulepos == '' or rulepos is null,'n',	rulepos),
//               |    if(ruleroadid == '' or ruleroadid is null,'n',	ruleroadid),
//               |    if(ruleoutroadid == '' or ruleoutroadid is null,'n',	ruleoutroadid),
//               |    if(ruletype == '' or ruletype is null,'n',	ruletype),
//               |    if(limitweight == '' or limitweight is null,'n',	limitweight),
//               |    if(limitsize == '' or limitsize is null,'n',	limitsize),
//               |    if(limitwidth == '' or limitwidth is null,'n',	limitwidth),
//               |    if(limitaxload == '' or limitaxload is null,'n',	limitaxload),
//               |    if(limitload == '' or limitload is null,'n',	limitload),
//               |    if(limitaxcnt == '' or limitaxcnt is null,'n',	limitaxcnt),
//               |    if(limitpassport == '' or limitpassport is null,'n',	limitpassport),
//               |    if(limitholiday == '' or limitholiday is null,'n',	limitholiday),
//               |    if(limitoutflag == '' or limitoutflag is null,'n',	limitoutflag),
//               |    if(limitemitstand == '' or limitemitstand is null,'n',	limitemitstand),
//               |    if(limitweek == '' or limitweek is null,'n',	limitweek),
//               |    if(limittime == '' or limittime is null,'n',	limittime)
//               |  ) as rtk,
//               |  *
//               |from
//               |  dm_gis.mms_car_route_plan_and_jp_limited_result_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |  and length(ruleid) < 6
//               |  and (limitsize is null or limitsize = '' or cast(limitsize as double) <= 4.2)
//               |  and data_source='0'
//               |  and mark_dist = 0
//               |  and ruletype != '在建'
//               |  and mark in('-1','0','4')
//               |""".stripMargin
//        // 获取历史核查数据 【近30天的数据】
//        val resultCheckDataSql: String =
//            s"""
//               |select
//               |  case work_status
//               |  when '0' then '未作业'
//               |  when '1' then '数据正确'
//               |  when '2' then '数据错误'
//               |  when '3' then '图片模糊无法核实'
//               |  when '4' then '缺少资料无法核实'
//               |  when '5' then '施工'
//               |  when '6' then '其他'
//               |  when '7' then '不需作业的未创建资料'
//               |  else '未知'
//               |  end as work_status2,
//               |  concat_ws('_',
//               |    if(rulepos == '' or rulepos is null,'n',	rulepos),
//               |    if(ruleroadid == '' or ruleroadid is null,'n',	ruleroadid),
//               |    if(ruleoutroadid == '' or ruleoutroadid is null,'n',	ruleoutroadid),
//               |    if(ruletype == '' or ruletype is null,'n',	ruletype),
//               |    if(limitweight == '' or limitweight is null,'n',	limitweight),
//               |    if(limitsize == '' or limitsize is null,'n',	limitsize),
//               |    if(limitwidth == '' or limitwidth is null,'n',	limitwidth),
//               |    if(limitaxload == '' or limitaxload is null,'n',	limitaxload),
//               |    if(limitload == '' or limitload is null,'n',	limitload),
//               |    if(limitaxcnt == '' or limitaxcnt is null,'n',	limitaxcnt),
//               |    if(limitpassport == '' or limitpassport is null,'n',	limitpassport),
//               |    if(limitholiday == '' or limitholiday is null,'n',	limitholiday),
//               |    if(limitoutflag == '' or limitoutflag is null,'n',	limitoutflag),
//               |    if(limitemitstand == '' or limitemitstand is null,'n',	limitemitstand),
//               |    if(limitweek == '' or limitweek is null,'n',	limitweek),
//               |    if(limittime == '' or limittime is null,'n',	limittime)
//               |  ) as rtk,
//               |  *
//               |from
//               |  dm_gis.mms_car_route_aggre_data_checked_result_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |""".stripMargin
//        // 近30天任务下发的数据
//        val taskSql: String =
//            s"""
//               |select
//               |  ruleid,
//               |  rulepos,
//               |  inc_day
//               |from
//               |  dm_gis.mms_car_route_aggre_data_issue_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |""".stripMargin
//        // 获取闯行的数据
//        val jpLimitedDS: Dataset[Row] = getDataFrame(logger,spark,jpLimitedDataSql)
//        // 当天下发的任务数据
//        val taskDS: Dataset[Row] = getDataFrame(logger,spark,taskSql)
//
//        // 获取核实结果数据
//        val resultCheckDS: Dataset[Row] = spark
//          .sql(resultCheckDataSql)
//          .drop("work_status")
//          .withColumnRenamed("work_status2", "work_status")
//          .drop("data_source", "inc_day", "version", "area_code", "city")
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//        GetDFCountAndSampleData(logger, resultCheckDS, "核实结果的数据")
//
//        // 获取每天每个底图版本每个城市的数据正确、错误、无法识别 数量
//        val jpLimitedAccuracyDF: DataFrame = jpLimitedDS
//          .join(resultCheckDS, Seq("rtk"), "left")
//          .rdd
//          .map(r => {
//              val uuid: String = r.getAs[String]("uuid")
//              val data_source: String = r.getAs[String]("data_source")
//              val d_plan_order: Int = r.getAs[Int]("d_plan_order")
//              val work_status: String = r.getAs[String]("work_status")
//              ((uuid, data_source, d_plan_order), work_status)
//          })
//          .groupByKey()
//          .map(r => {
//              val (uuid, data_source, d_plan_order) = r._1
//              val work_status_iter: Iterable[String] = r._2
//
//              val data_status_all: mutable.HashSet[String] = new mutable.HashSet[String]()
//              for (work_status <- work_status_iter) data_status_all.add(work_status)
//
//              val his_track_status: String = get_his_track_status(data_status_all)
//              (uuid, data_source, d_plan_order, his_track_status)
//          })
//          .toDF("uuid", "data_source", "d_plan_order", "his_track_status")
//          .join(jpLimitedDS, Seq("uuid", "data_source", "d_plan_order"))
//          .dropDuplicates("uuid", "data_source", "d_plan_order")
//          .rdd
//          .map(r => {
//              val inc_day: String = r.getAs[String]("inc_day")
//              val version: String = r.getAs[String]("version")
//              val city: String = r.getAs[String]("city")
//              val his_track_status: String = r.getAs[String]("his_track_status")
//              ((inc_day, version, city), his_track_status)
//          })
//          .groupByKey()
//          .map(r => {
//              val (inc_day, version, city) = r._1
//              val his_track_status_iter: Iterable[String] = r._2
//
//              var his_correct_num: Int = 0
//              var his_error_num: Int = 0
//              var unverify_num: Int = 0
//
//              for (his_track_status <- his_track_status_iter) {
//                  if (his_track_status == "数据正确") his_correct_num += 1
//                  else if (his_track_status == "数据错误") his_error_num += 1
//                  else if (his_track_status == "无法核实") unverify_num += 1
//              }
//
//              (inc_day, version, city, his_correct_num, his_error_num, unverify_num)
//          })
//          .toDF("inc_day", "version", "city", "his_correct_num", "his_error_num", "unverify_num")
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//        GetDFCountAndSampleData(logger, jpLimitedAccuracyDF, "每天、每个底图版本、每个城市 数据正确、错误以及无法核实的数量")
//
//        // 每天、每个版本、每个城市 新增的闯行轨迹数
//        val addLocusCnt: Dataset[Row] = taskDS
//          .join(jpLimitedDS, Seq("ruleid", "rulepos", "inc_day"))
//          .dropDuplicates("uuid")
//          .groupBy("inc_day", "version", "city")
//          .agg(count("city").alias("new_add_cnt"))
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//        GetDFCountAndSampleData(logger, addLocusCnt, "每天、每个底图版本、每个城市 新增闯行轨迹数")
//
//
//        // 获取 纠偏 轨迹数 【每个城市 每一天 的数据】
//        val jpSql: String =
//            s"""
//               |select
//               |  inc_day,
//               |  city,
//               |  count(distinct task_id,start_dept,end_dept) his_cnt
//               |from
//               |  dm_gis.mms_car_route_jp_detail_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |group by
//               |  inc_day,city
//               |""".stripMargin
//        // 获取 纠偏闯限行轨迹数 【每个城市 每一天 每个底图版本 的数据】
//        val jpLimitedSql: String =
//            s"""
//               |select
//               |  inc_day,
//               |  version,
//               |  city,
//               |  count(distinct task_id,start_dept,end_dept) his_limited_cnt
//               |from
//               |  dm_gis.mms_car_route_plan_and_jp_limited_result_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |  and length(ruleid) < 6
//               |  and (limitsize is null or limitsize = '' or cast(limitsize as double) <= 4.2)
//               |  and data_source='0'
//               |  and mark_dist = 0
//               |  and ruletype != '在建'
//               |  and mark in('-1','0','4')
//               |group by
//               |   inc_day,version,city
//               |""".stripMargin
//        // 获取 省-市 维表信息
//        val proCityInfoSql: String =
//            """
//              |select
//              |  *
//              |from
//              |  dm_gis.province_city_info
//              |""".stripMargin
//
//        val jpDF: DataFrame = getDataFrame(logger,spark,jpSql)
//        val jpLimitedDF: DataFrame = getDataFrame(logger,spark,jpLimitedSql)
//        val proCityInfoDF: DataFrame = getDataFrame(logger,spark,proCityInfoSql)
//
//        // 轨迹维度 的最终指标数据
//        val resultDF1: DataFrame = proCityInfoDF
//          .join(jpDF, Seq("city"))
//          .join(jpLimitedDF, Seq("inc_day", "city"), "left")
//          .join(jpLimitedAccuracyDF, Seq("inc_day", "city", "version"), "left")
//          .join(addLocusCnt, Seq("inc_day", "city", "version"), "left")
//          .na.fill(version, Array("version"))
//          .na.fill(0, Array("his_cnt", "his_limited_cnt", "his_correct_num",
//            "his_error_num", "unverify_num", "new_add_cnt"))
//          .withColumn("sample_batch", concat_ws("_", $"inc_day", $"inc_day"))
//          .withColumn("start_dept", $"city")
//          .withColumn("end_dept", $"city")
//          .withColumn("id", concat_ws("_", $"inc_day", $"version", $"city"))
//          .withColumn("incday", $"inc_day")
//          .drop("inc_day")
//          .withColumnRenamed("incday", "inc_day")
//          .coalesce(3)
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//        GetDFCountAndSampleData(logger, resultDF1, "轨迹维度 最终的指标数据")
//
//        df2HiveByOverwrite(logger, resultDF1, "dm_gis.mms_car_route_jp_limited_locus_indicator_info")
//
//        // 写入到MySQL
//        logger.error("开始写入到MySQL：MMS_CAR_ROUTE_JP_LIMITED_LOCUS_INDICATOR_INFO")
//        locusToMysql(resultDF1)
//        logger.error("写入MySQL成功！")
//
//
//        logger.error("<============ 以下是基于闯行点维度的统计指标 ============>")
//
//        // 获取每天下发的闯行任务数量 【取近30天的数据】
//        val jpLimitedIssueDataSql: String =
//            s"""
//               |select
//               |  inc_day,
//               |  version,
//               |  area_code,
//               |  count(1) as limit_task_num
//               |from
//               |  dm_gis.mms_car_route_aggre_data_issue_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |group by
//               |  inc_day,
//               |  version,
//               |  area_code
//               |""".stripMargin
//        // 获取历史核查数据 【近30天的数据】
//        val resultCheckAggDataSql: String =
//            s"""
//               |select
//               |  inc_day,
//               |  version,
//               |  area_code,
//               |  count(work_status) as verify_num,
//               |  sum(if(work_status == '1',1,0)) as data_right_num,
//               |  sum(if(work_status == '2',1,0)) as data_error_num
//               |from
//               |  dm_gis.mms_car_route_aggre_data_checked_result_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |group by
//               |  inc_day,
//               |  version,
//               |  area_code
//               |""".stripMargin
//        // 获取历史核查数据 【近30天的数据】
//        val pointResultSql: String =
//            s"""
//               |-- 近30天的聚合数据
//               |with t1 as(
//               |select
//               |  inc_day,
//               |  version,
//               |  area_code,
//               |  concat_ws('_',
//               |    if(rulepos == '' or rulepos is null,'n',	rulepos),
//               |    if(ruleroadid == '' or ruleroadid is null,'n',	ruleroadid),
//               |    if(ruleoutroadid == '' or ruleoutroadid is null,'n',	ruleoutroadid),
//               |    if(ruletype == '' or ruletype is null,'n',	ruletype),
//               |    if(limitweight == '' or limitweight is null,'n',	limitweight),
//               |    if(limitsize == '' or limitsize is null,'n',	limitsize),
//               |    if(limitwidth == '' or limitwidth is null,'n',	limitwidth),
//               |    if(limitaxload == '' or limitaxload is null,'n',	limitaxload),
//               |    if(limitload == '' or limitload is null,'n',	limitload),
//               |    if(limitaxcnt == '' or limitaxcnt is null,'n',	limitaxcnt),
//               |    if(limitpassport == '' or limitpassport is null,'n',	limitpassport),
//               |    if(limitholiday == '' or limitholiday is null,'n',	limitholiday),
//               |    if(limitoutflag == '' or limitoutflag is null,'n',	limitoutflag),
//               |    if(limitemitstand == '' or limitemitstand is null,'n',	limitemitstand),
//               |    if(limitweek == '' or limitweek is null,'n',	limitweek),
//               |    if(limittime == '' or limittime is null,'n',	limittime)
//               |  ) as rtk
//               |from
//               |  dm_gis.mms_car_route_plan_and_jp_limited_aggre_result_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |  and cast(ruleid as int) < 100000
//               |  and (cast(limitsize as double) <= 4.2 or limitsize = '')
//               |  and data_source not in('1','2','3')
//               |  ),
//               |
//               |-- 近30天的历史核实数据
//               |t2 as(
//               |select
//               |  concat_ws('_',
//               |    if(rulepos == '' or rulepos is null,'n',	rulepos),
//               |    if(ruleroadid == '' or ruleroadid is null,'n',	ruleroadid),
//               |    if(ruleoutroadid == '' or ruleoutroadid is null,'n',	ruleoutroadid),
//               |    if(ruletype == '' or ruletype is null,'n',	ruletype),
//               |    if(limitweight == '' or limitweight is null,'n',	limitweight),
//               |    if(limitsize == '' or limitsize is null,'n',	limitsize),
//               |    if(limitwidth == '' or limitwidth is null,'n',	limitwidth),
//               |    if(limitaxload == '' or limitaxload is null,'n',	limitaxload),
//               |    if(limitload == '' or limitload is null,'n',	limitload),
//               |    if(limitaxcnt == '' or limitaxcnt is null,'n',	limitaxcnt),
//               |    if(limitpassport == '' or limitpassport is null,'n',	limitpassport),
//               |    if(limitholiday == '' or limitholiday is null,'n',	limitholiday),
//               |    if(limitoutflag == '' or limitoutflag is null,'n',	limitoutflag),
//               |    if(limitemitstand == '' or limitemitstand is null,'n',	limitemitstand),
//               |    if(limitweek == '' or limitweek is null,'n',	limitweek),
//               |    if(limittime == '' or limittime is null,'n',	limittime)
//               |  ) as rtk,
//               |  work_status
//               |from
//               |  dm_gis.mms_car_route_aggre_data_checked_result_info
//               |where
//               |  inc_day >= '$thirty_day_ago_time'
//               |  and inc_day < '$end_time'
//               |)
//               |
//               |select
//               |  inc_day,
//               |  version,
//               |  area_code,
//               |  count(1) all_task_num,
//               |  sum(if(work_status == '1',1,0)) as data_right_num_all,
//               |  sum(if(work_status == '2',1,0)) as data_error_num_all,
//               |  sum(if(work_status == '3' or work_status == '4',1,0)) as unable2verify,
//               |  sum(if(work_status is null,1,0)) as undo_his_task_num,
//               |  sum(if(work_status == '6',1,0)) as other_num
//               |from t1
//               |  left join t2
//               |on t1.rtk = t2.rtk
//               |group by
//               |  inc_day,
//               |  version,
//               |  area_code
//               |""".stripMargin
//
//        // 获取每天下发的任务数据
//        val jpLimitedIssueDS: DataFrame = getDataFrame(logger,spark,jpLimitedIssueDataSql)
//        // 获取轨迹结果数据
//        val resultCheckAggDS: DataFrame = getDataFrame(logger,spark,resultCheckAggDataSql)
//        // 获取任务聚合结果数据
//        val pointResultDS: DataFrame = getDataFrame(logger,spark,pointResultSql)
//
//        // 闯行点位最终的指标数据
//        val result2: DataFrame = proCityInfoDF
//          .join(pointResultDS, Seq("area_code"))
//          .join(jpLimitedIssueDS, Seq("inc_day", "version", "area_code"), "left")
//          .join(resultCheckAggDS, Seq("inc_day", "version", "area_code"), "left")
//          .na.fill(version, Array("version"))
//          .na.fill(0, Array("all_task_num", "data_right_num_all", "data_error_num_all", "unable2verify",
//            "undo_his_task_num", "other_num", "limit_task_num", "verify_num", "data_right_num", "data_error_num"))
//          .withColumn("feedback_task_num", $"all_task_num" - $"limit_task_num")
//          .withColumn("id", concat_ws("_", $"inc_day", $"version", $"area_code"))
//          .withColumn("incday", 'inc_day)
//          .drop("inc_day")
//          .withColumnRenamed("incday", "inc_day")
//          .coalesce(3)
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//        GetDFCountAndSampleData(logger, result2, "闯行点位维度的指标数据")
//        df2HiveByOverwrite(logger, result2, "dm_gis.mms_car_route_jp_limited_task_indicator_info")
//
//        // 写入到MySQL
//        logger.error("开始写入到MySQL：MMS_CAR_ROUTE_JP_LIMITED_TASK_INDICATOR_INFO")
//        taskToMysql(result2)
//        logger.error("写入MySQL成功！")


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 获得每条轨迹的最终状态
    def get_his_track_status(data_status_all: mutable.HashSet[String]): String = {
        var his_track_status: String = ""

        if (data_status_all.contains("数据错误") || data_status_all.contains("施工")) his_track_status = "数据错误"
        else if (data_status_all.size == 1 && data_status_all.contains("数据正确")) his_track_status = "数据正确"
        else if (data_status_all.contains("数据正确") && (data_status_all.contains("缺少资料无法核实") || data_status_all.contains("图片模糊无法核实"))) his_track_status = "无法核实"
        else if (data_status_all.size == 1 && (data_status_all.contains("缺少资料无法核实") || data_status_all.contains("图片模糊无法核实"))) his_track_status = "无法核实"
        else if (data_status_all.size == 2 && (data_status_all.contains("缺少资料无法核实") && data_status_all.contains("图片模糊无法核实"))) his_track_status = "无法核实"

        his_track_status
    }

    // 讲df写入到MySQL(轨迹维度)
    def locusToMysql(df: DataFrame): Unit = {
        df.rdd
          .foreachPartition(iter => {
              Class.forName(driver)
              val connection: Connection = java.sql.DriverManager.getConnection(url, userName, passWd)
              iter.foreach(r => {
                  val id: String = r.getAs[String]("id")
                  val inc_day: String = r.getAs[String]("inc_day")
                  val area_code: String = r.getAs[String]("area_code")
                  val version: String = r.getAs[String]("version")
                  val city: String = r.getAs[String]("city")
                  val province_name: String = r.getAs[String]("province_name")
                  val city_name: String = r.getAs[String]("city_name")

                  val his_cnt: Long = r.getAs[Long]("his_cnt")
                  val his_limited_cnt: Long = r.getAs[Long]("his_limited_cnt")
                  val his_correct_num: Int = r.getAs[Int]("his_correct_num")
                  val his_error_num: Int = r.getAs[Int]("his_error_num")
                  val unverify_num: Int = r.getAs[Int]("unverify_num")
                  val new_add_cnt: Long = r.getAs[Long]("new_add_cnt")

                  val sample_batch: String = r.getAs[String]("sample_batch")
                  val start_dept: String = r.getAs[String]("start_dept")
                  val end_dept: String = r.getAs[String]("end_dept")

                  val del_sql: String = s"delete from MMS_CAR_ROUTE_JP_LIMITED_LOCUS_INDICATOR_INFO where id =?"
                  val statement0: PreparedStatement = connection.prepareStatement(del_sql)
                  statement0.setString(1, id)
                  statement0.executeUpdate()
                  statement0.close()

                  val insert_sql: String = "insert into MMS_CAR_ROUTE_JP_LIMITED_LOCUS_INDICATOR_INFO(" +
                    "ID," +
                    "STATDATE," +
                    "AREA_CODE," +
                    "VERSION," +
                    "CITY," +
                    "PROVINCE_NAME," +
                    "CITY_NAME," +
                    "HIS_CNT," +
                    "HIS_LIMITED_CNT," +
                    "HIS_CORRECT_NUM," +
                    "HIS_ERROR_NUM," +
                    "UNVERIFY_NUM," +
                    "NEW_ADD_CNT," +
                    "SAMPLE_BATCH," +
                    "START_DEPT," +
                    "END_DEPT" +
                    ") values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                  val statement: PreparedStatement = connection.prepareStatement(insert_sql)

                  statement.setString(1, id)
                  statement.setString(2, inc_day)
                  statement.setString(3, area_code)
                  statement.setString(4, version)
                  statement.setString(5, city)
                  statement.setString(6, province_name)
                  statement.setString(7, city_name)

                  statement.setLong(8, his_cnt)
                  statement.setLong(9, his_limited_cnt)
                  statement.setInt(10, his_correct_num)
                  statement.setInt(11, his_error_num)
                  statement.setInt(12, unverify_num)
                  statement.setLong(13, new_add_cnt)

                  statement.setString(14, sample_batch)
                  statement.setString(15, start_dept)
                  statement.setString(16, end_dept)


                  statement.executeUpdate()
                  statement.close()

              })

              connection.close()
          })

    }

    // 讲df写入到MySQL(任务维度)
    def taskToMysql(df: DataFrame): Unit = {
        df.rdd
          .foreachPartition(iter => {
              Class.forName(driver)
              val connection: Connection = java.sql.DriverManager.getConnection(url, userName, passWd)
              iter.foreach(r => {
                  val id: String = r.getAs[String]("id")
                  val inc_day: String = r.getAs[String]("inc_day")
                  val area_code: String = r.getAs[String]("area_code")
                  val version: String = r.getAs[String]("version")
                  val province_name: String = r.getAs[String]("province_name")
                  val city_name: String = r.getAs[String]("city_name")
                  val city: String = r.getAs[String]("city")

                  val all_task_num: Long = r.getAs[Long]("all_task_num")
                  val data_right_num_all: Long = r.getAs[Long]("data_right_num_all")
                  val data_error_num_all: Long = r.getAs[Long]("data_error_num_all")
                  val unable2verify: Long = r.getAs[Long]("unable2verify")
                  val undo_his_task_num: Long = r.getAs[Long]("undo_his_task_num")
                  val other_num: Long = r.getAs[Long]("other_num")
                  val limit_task_num: Long = r.getAs[Long]("limit_task_num")
                  val verify_num: Long = r.getAs[Long]("verify_num")
                  val data_right_num: Long = r.getAs[Long]("data_right_num")
                  val data_error_num: Long = r.getAs[Long]("data_error_num")
                  val feedback_task_num: Long = r.getAs[Long]("feedback_task_num")

                  val del_sql: String = s"delete from MMS_CAR_ROUTE_JP_LIMITED_TASK_INDICATOR_INFO where id =?"
                  val statement0: PreparedStatement = connection.prepareStatement(del_sql)
                  statement0.setString(1, id)
                  statement0.executeUpdate()
                  statement0.close()

                  val insert_sql: String = "insert into MMS_CAR_ROUTE_JP_LIMITED_TASK_INDICATOR_INFO(" +
                    "ID," +
                    "STATDATE," +
                    "AREA_CODE," +
                    "VERSION," +
                    "PROVINCE_NAME," +
                    "CITY_NAME," +
                    "CITY," +
                    "ALL_TASK_NUM," +
                    "DATA_RIGHT_NUM_ALL," +
                    "DATA_ERROR_NUM_ALL," +
                    "UNABLE2VERIFY," +
                    "UNDO_HIS_TASK_NUM," +
                    "OTHER_NUM," +
                    "LIMIT_TASK_NUM," +
                    "VERIFY_NUM," +
                    "DATA_RIGHT_NUM," +
                    "DATA_ERROR_NUM," +
                    "FEEDBACK_TASK_NUM" +
                    ") values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                  val statement: PreparedStatement = connection.prepareStatement(insert_sql)

                  statement.setString(1, id)
                  statement.setString(2, inc_day)
                  statement.setString(3, area_code)
                  statement.setString(4, version)
                  statement.setString(5, province_name)
                  statement.setString(6, city_name)
                  statement.setString(7, city)

                  statement.setLong(8, all_task_num)
                  statement.setLong(9, data_right_num_all)
                  statement.setLong(10, data_error_num_all)
                  statement.setLong(11, unable2verify)
                  statement.setLong(12, undo_his_task_num)
                  statement.setLong(13, other_num)
                  statement.setLong(14, limit_task_num)
                  statement.setLong(15, verify_num)
                  statement.setLong(16, data_right_num)
                  statement.setLong(17, data_error_num)
                  statement.setLong(18, feedback_task_num)

                  statement.executeUpdate()
                  statement.close()

              })

              connection.close()
          })

    }


}
