package app.runLimited

import entry.AggreRuleidAndRuleposResult
import org.apache.spark.sql.{DataFrame, Dataset, Row,SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.SparkConfigUtil

import scala.collection.mutable


/**
  * 按照 ruleid 和 rulepos 汇总聚合数据
  *
  * 7. 分组聚合数据
  */
object AggreRuleidAndRuleposData {

    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        // 1. 获取所有的闯行数据
        val origDataSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_and_jp_limited_result_info
               |  where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and mark_dist = 0
               |  and (srcIdfrom = '' or srcIdfrom is null)
               |  and mark in(-1,0,4)
               |  and (d_frequency ='' or cast(d_frequency as int) > 3)
               |""".stripMargin

        logger.error(origDataSql)

        val origDataDS: Dataset[Row] = spark
          .sql(origDataSql)
          .repartition(600)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, origDataDS, "原始数据")

        // 2. 根据 ruleid 和 rulepos分组聚合
        val ResultAggDataDF: DataFrame = origDataDS
          .filter("ruleid != '' and rulepos != ''")
          .filter("adcode != ''")
          .rdd
          .map(r => {
              val ruleid: String = r.getAs[String]("ruleid")
              val rulepos: String = r.getAs[String]("rulepos")
              ((ruleid, rulepos), r)
          })
          .groupByKey()
          .map(r => {
              val res: AggreRuleidAndRuleposResult = aggre_limit_data(r)
              res
          })
          .toDF()
          .coalesce(100)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ResultAggDataDF, "聚合之后的数据 ")

        // 最终的数据落表
        df2HiveByOverwrite(logger,ResultAggDataDF,"dm_gis.mms_car_route_plan_and_jp_limited_aggre_result_info")




        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()


    }


    // 聚合闯行数据
    def aggre_limit_data(r: ((String, String), Iterable[Row])): AggreRuleidAndRuleposResult = {
        val ruleid: String = r._1._1
        val rulepos: String = r._1._2
        val rows: Iterable[Row] = r._2

        val freqCnt: Int = rows.size
        val gd_freqCnt: Int = freqCnt

        val ruleroadidSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val ruleoutroadidSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val ruletypeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_serialSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_typeSet: mutable.HashSet[Int] = new mutable.HashSet[Int]()
        val limitweightSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitsizeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitwidthSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitaxloadSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitloadSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitaxcntSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitvehicletypeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitpassportSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitholidaySet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitoutflagSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitemitstandSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limittailcharSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitstartdateSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitenddateSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitweekSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limittimeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val ruleregiondescSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val data_sourceSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val heightSet: mutable.HashSet[Double] = new mutable.HashSet[Double]()
        val widthSet: mutable.HashSet[Double] = new mutable.HashSet[Double]()
        val vehicle_lengthSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_full_load_weightSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_load_weightSet: mutable.HashSet[Double] = new mutable.HashSet[Double]()
        val axls_numberSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_serial_head2Set: mutable.HashSet[String] = new mutable.HashSet[String]()
        val energySet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val colorSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val emissionSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val adcodeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_serial_last2Set: mutable.HashSet[String] = new mutable.HashSet[String]()
        val plineSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val guidSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val citySet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val AreaCodeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val versionSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val inc_daySet: mutable.HashSet[String] = new mutable.HashSet[String]()

        for (r <- rows) {
            ruleroadidSet.add(r.getAs[String]("ruleroadid"))
            ruleoutroadidSet.add(r.getAs[String]("ruleoutroadid"))
            ruletypeSet.add(r.getAs[String]("ruletype"))
            vehicle_serialSet.add(r.getAs[String]("vehicle_serial"))
            vehicle_typeSet.add(r.getAs[Int]("vehicle_type"))
            limitweightSet.add(r.getAs[String]("limitweight"))
            limitsizeSet.add(r.getAs[String]("limitsize"))
            limitwidthSet.add(r.getAs[String]("limitwidth"))
            limitaxloadSet.add(r.getAs[String]("limitaxload"))
            limitloadSet.add(r.getAs[String]("limitload"))
            limitaxcntSet.add(r.getAs[String]("limitaxcnt"))
            limitvehicletypeSet.add(r.getAs[String]("limitvehicletype"))
            limitpassportSet.add(r.getAs[String]("limitpassport"))
            limitholidaySet.add(r.getAs[String]("limitholiday"))
            limitoutflagSet.add(r.getAs[String]("limitoutflag"))
            limitemitstandSet.add(r.getAs[String]("limitemitstand"))
            limittailcharSet.add(r.getAs[String]("limittailchar"))
            limitstartdateSet.add(r.getAs[String]("limitstartdate"))
            limitenddateSet.add(r.getAs[String]("limitenddate"))
            limitweekSet.add(r.getAs[String]("limitweek"))
            limittimeSet.add(r.getAs[String]("limittime"))
            ruleregiondescSet.add(r.getAs[String]("ruleregiondesc"))
            data_sourceSet.add(r.getAs[String]("data_source"))
            heightSet.add(r.getAs[Double]("height"))
            widthSet.add(r.getAs[Double]("width"))
            vehicle_lengthSet.add(r.getAs[String]("vehicle_length"))
            vehicle_full_load_weightSet.add(r.getAs[String]("vehicle_full_load_weight"))
            vehicle_load_weightSet.add(r.getAs[Double]("vehicle_load_weight"))
            axls_numberSet.add(r.getAs[String]("axls_number"))
            vehicle_serial_head2Set.add(r.getAs[String]("vehicle_serial").substring(0, 2))
            energySet.add(r.getAs[String]("energy"))
            colorSet.add(r.getAs[String]("color"))
            vehicle_serial_last2Set.add(r.getAs[String]("vehicle_serial").reverse.substring(0, 1))
            emissionSet.add(r.getAs[String]("emission"))
            adcodeSet.add(r.getAs[String]("adcode"))
            plineSet.add(r.getAs[String]("pline"))
            guidSet.add(r.getAs[String]("guid"))
            citySet.add(r.getAs[String]("city"))
            AreaCodeSet.add(r.getAs[String]("adcode").substring(0, 4))
            versionSet.add(r.getAs[String]("version"))
            inc_daySet.add(r.getAs[String]("inc_day"))
        }

        AggreRuleidAndRuleposResult(ruleid, rulepos, freqCnt, gd_freqCnt, check_set_empty(ruleroadidSet), check_set_empty(ruleoutroadidSet),
            check_set_empty(ruletypeSet), vehicle_serialSet.size, vehicle_typeSet.toList.sorted.mkString("|"), check_set_empty(limitweightSet), check_set_empty(limitsizeSet),
            check_set_empty(limitwidthSet), check_set_empty(limitaxloadSet), check_set_empty(limitloadSet), check_set_empty(limitaxcntSet), check_set_empty(limitvehicletypeSet),
            check_set_empty(limitpassportSet), check_set_empty(limitholidaySet), check_set_empty(limitoutflagSet), check_set_empty(limitemitstandSet),
            check_set_empty(limittailcharSet), check_set_empty(limitstartdateSet), check_set_empty(limitenddateSet), check_set_empty(limitweekSet),
            check_set_empty(limittimeSet), check_set_empty(ruleregiondescSet), check_set_empty(data_sourceSet), get_set_max(heightSet), get_set_max(widthSet),
            get_set_max(vehicle_lengthSet), get_set_max(vehicle_full_load_weightSet), get_set_max(vehicle_load_weightSet), get_set_max(axls_numberSet), check_set_empty(vehicle_serial_head2Set),
            check_set_empty(energySet), check_set_empty(colorSet), check_set_empty(vehicle_serial_last2Set), check_set_empty(emissionSet),
            check_set_empty(adcodeSet), check_set_empty(plineSet), check_set_empty(guidSet), inc_daySet.min + "_" + inc_daySet.max, check_set_empty(citySet), check_set_empty(AreaCodeSet), check_set_empty(versionSet), inc_daySet.head
        )
    }

    // 判断 set集合是否为空，如果是空，就返回字符串""
    def check_set_empty(s: mutable.HashSet[String]): String = {
        if (s.isEmpty) ""
        else if (s.size == 1 && s.head == null) ""
        else if (s.contains(null)) {
            s.remove(null)
            s.toList.sortBy(x => (x.length, x.head)).mkString("|")
        }
        else s.toList.sortBy(x => (x.length, x.head)).mkString("|")
    }

    def get_set_max(s: mutable.HashSet[String]): String = {
        if (s.isEmpty) ""
        else if (s.size == 1 && s.head == null) ""
        else if (s.contains(null)) {
            s.remove(null)
            s.max
        }
        else s.max
    }


    def get_set_max(s: mutable.HashSet[Double]): Double = {
        if (s.isEmpty) 0.0
        else s.max
    }
}
