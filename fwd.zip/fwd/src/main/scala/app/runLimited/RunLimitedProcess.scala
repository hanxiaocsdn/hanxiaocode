package app.runLimited

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import entry._
import org.apache.spark.Partitioner
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.HttpClientUtil.{getJsonByGet, getJsonByGet2}
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.text.SimpleDateFormat
import java.{lang, util}
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.Random

/**
  * 任务名称：闯行/路网工艺 全流程
  * 任务ID：(临时执行) 已下线 479216
  * 需求人员：李建飞 01413751
  * 开发人员：王冬冬 01413698
  */
object RunLimitedProcess {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    // 初始化配置文件
//    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = "http://rp-c-gd.int.sfcloud.local:1090/qm_point"
    val gd_url: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api?&passport=100000&tolls=1&test=0&stype=0&etype=2&pathCount=1&fencedist=50&merge=4&fixedroute=2&frequency=1&type=0&cc=1&strategy=0&opt=gd3&"
    val ct_url: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api?&passport=100000&tolls=1&test=0&stype=0&etype=2&pathCount=2&fencedist=50&merge=4&fixedroute=2&frequency=1&type=0&cc=1&strategy=0&opt=sf2&"
    val ct2_url: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api?&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&pathCount=3&cc=1&merge=4&etype=2&opt=sf4&frequency=1&passport=100000&tolls=1&"
    val jy_url: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api?&passport=100000&tolls=1&stype=0&etype=2&pathCount=3&fencedist=50&merge=4&fixedroute=2&frequency=0&type=0&cc=1&strategy=6&opt=jy2&"
    val version_url: String = "http://gis-rss-rp-c-green.int.sfdc.com.cn:1090/about?detail=1"
    val jpyc_url: String = "http://rh-gd.int.sfcloud.local:1080/inspectbypassroute"
    val road_attr_url: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/roadAttr?mask=31&gzip=0&output=json&ak=39681f679699410b9ecc8dbcc5c98bde&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED&"


    def main(args: Array[String]): Unit = {

        val inc_day: String = args(0)
        logger.error(s"取数日期：$inc_day")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 取数
        getcarLocusAndParamDetail(spark, inc_day)

        // 跑规划
        // 跑传统服务接口 获取相应的字段
        runCTService(spark, inc_day)
        // 跑经验服务接口 获取相应的字段
        runJYService(spark, inc_day)

        // 跑闯行
        // 规划的数据跑闯行
        runLimitedService(spark, inc_day)
        // 纠偏的数据跑闯行
        runLimitedServiceFromJP(spark, inc_day)

        // 匹配中断
        getmatchBreakoffData(spark, inc_day)

        // 车参异常剔除和匹配异常处理
        dealCarParamAbnorma(spark, inc_day)

        // 纠偏异常处理
        // 规划的数据进行纠偏异常处理
        planJPAbnormalDeal(spark, inc_day)
        // 纠偏的数据进行纠偏异常处理
        jpJPAbnormalDeal(spark, inc_day)

        // 轨迹质量异常
        deallocusAbnormalData(spark, inc_day)

        // 规划的数据 和 纠偏的数据 合并在一起
        saveLimitedData2Hive(spark, inc_day)

        // 在建道路数据下发
        isbuildingIndiccatorData(spark, inc_day)

        // 按闯行点聚合
        aggreRuleidAndRuleposData(spark, inc_day)

        // 任务下发
        taskIssueDataFromAggreResult(spark, inc_day)


        logger.error("运行结束！")

        // 程序运行结束
        spark.stop()

    }


    // 车辆历史轨迹及任务明细 左关联 参数数据
    def getcarLocusAndParamDetail(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 车辆历史轨迹及任务明细合并
        val dlr = '$'
        //        val carLocusAndTaskDetailSQL: String =
        //            s"""
        //               |--车辆历史轨迹数据
        //               |with carLocus as (
        //               |select
        //               |  *
        //               |from
        //               |  (select
        //               |    get_json_object(info, '$dlr.task_id')                   as task_id,
        //               |    get_json_object(info, '$dlr.start_dept')                as start_dept,
        //               |    get_json_object(info, '$dlr.end_dept')                  as end_dept,
        //               |    ""                                                      as his_coords,
        //               |    substr(get_json_object(info, '$dlr.start_dept'),1,3)    as city,
        //               |    inc_day
        //               |  from
        //               |    dm_gis.eta_traj_info
        //               |  where
        //               |    inc_day >= '$start_time'
        //               |    and inc_day < '$end_time'
        //               |    and get_json_object(info, '$dlr.carrier_type') = 0
        //               |    and (
        //               |       (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $wuxi_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $wuxi_area)
        //               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $jizhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $jizhou_area)
        //               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $guangzhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $guangzhou_area)
        //               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $quanzhou_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $quanzhou_area)
        //               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $jilin_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $jilin_area)
        //               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $sichuan_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $sichuan_area)
        //               |    or (substr(get_json_object(info, '$dlr.start_dept'), 1, 3) in $lujin_area and substr(get_json_object(info, '$dlr.end_dept'), 1, 3) in $lujin_area)
        //               |    )
        //               |  ) t
        //               |),
        //               |--车辆任务明细数据
        //               |carTaskDetail as (
        //               |select
        //               |  *
        //               |from
        //               |  dm_gis.eta_grd_middle0
        //               |where
        //               |  inc_day >= '$start_time'
        //               |  and inc_day < '$end_time'
        //               |  and(
        //               |     (substr(start_dept, 1, 3) in $wuxi_area and substr(end_dept, 1, 3) in $wuxi_area)
        //               |  or (substr(start_dept, 1, 3) in $jizhou_area and substr(end_dept, 1, 3) in $jizhou_area)
        //               |  or (substr(start_dept, 1, 3) in $guangzhou_area and substr(end_dept, 1, 3) in $guangzhou_area)
        //               |  or (substr(start_dept, 1, 3) in $quanzhou_area and substr(end_dept, 1, 3) in $quanzhou_area)
        //               |  or (substr(start_dept, 1, 3) in $jilin_area and substr(end_dept, 1, 3) in $jilin_area)
        //               |  or (substr(start_dept, 1, 3) in $sichuan_area and substr(end_dept, 1, 3) in $sichuan_area)
        //               |  or (substr(start_dept, 1, 3) in $lujin_area and substr(end_dept, 1, 3) in $lujin_area)
        //               |  )
        //               |)
        //               |--合并轨迹和任务明细数据
        //               |select
        //               |  a.task_id,
        //               |  a.start_dept,
        //               |  a.end_dept,
        //               |  a.his_coords,
        //               |  a.inc_day,
        //               |  a.city,
        //               |  b.start_type,
        //               |  b.end_type,
        //               |  b.start_tm,
        //               |  b.end_tm,
        //               |  b.actual_run_time,
        //               |  b.plan_run_time,
        //               |  b.sort_num,
        //               |  b.start_longitude,
        //               |  b.end_longitude,
        //               |  b.start_latitude,
        //               |  b.end_latitude,
        //               |  b.line_code,
        //               |  b.line_id,
        //               |  b.task_area_code,
        //               |  b.vehicle_serial,
        //               |  b.conveyance_type,
        //               |  b.transoport_level,
        //               |  b.id,
        //               |  b.is_stop,
        //               |  b.ground_task_id,
        //               |  b.start_time,
        //               |  b.carrier_type,
        //               |  b.plf_flag,
        //               |  b.log_dist,
        //               |  b.line_distance
        //               |from
        //               |  carLocus a join carTaskDetail b
        //               |on a.task_id = b.task_id
        //               |  and a.start_dept = b.start_dept
        //               |  and a.end_dept = b.end_dept
        //               |""".stripMargin

        val carLocusAndTaskDetailSQL: String =
            s"""
               |--车辆历史轨迹数据
               |with carLocus as (
               |select
               |  *
               |from
               |  (select
               |    get_json_object(info, '$dlr.task_id')                   as task_id,
               |    get_json_object(info, '$dlr.start_dept')                as start_dept,
               |    get_json_object(info, '$dlr.end_dept')                  as end_dept,
               |    ""                                                      as his_coords,
               |    substr(get_json_object(info, '$dlr.start_dept'),1,3)    as city,
               |    inc_day
               |  from
               |    dm_gis.eta_traj_info
               |  where
               |    inc_day = '$inc_day'
               |    and get_json_object(info, '$dlr.carrier_type') = 0
               |    and get_json_object(info, '$dlr.task_area_code') in('311Y','371Y','531Y','551Y','571Y','731Y','024Y','577Y','574Y','592Y','871Y','752Y','029Y','023Y','532Y','351Y','757Y','771Y','791Y','931Y','595Y','760Y','591Y','471Y','111Y','451Y','513Y','431Y','991Y','851Y','222Y','579Y','517Y','536Y','333Y','510Y','999Y','888Y','300Y','666Y','316Y','898Y','555Y','700Y','777Y')
               |  ) t
               |),
               |--车辆任务明细数据
               |carTaskDetail as (
               |select
               |  *
               |from
               |  dm_gis.eta_grd_middle0
               |where
               |  inc_day = '$inc_day'
               |  and task_area_code in('311Y','371Y','531Y','551Y','571Y','731Y','024Y','577Y','574Y','592Y','871Y','752Y','029Y','023Y','532Y','351Y','757Y','771Y','791Y','931Y','595Y','760Y','591Y','471Y','111Y','451Y','513Y','431Y','991Y','851Y','222Y','579Y','517Y','536Y','333Y','510Y','999Y','888Y','300Y','666Y','316Y','898Y','555Y','700Y','777Y')
               |)
               |--合并轨迹和任务明细数据
               |select
               |  a.task_id,
               |  a.start_dept,
               |  a.end_dept,
               |  a.his_coords,
               |  a.inc_day,
               |  a.city,
               |  b.start_type,
               |  b.end_type,
               |  b.start_tm,
               |  b.end_tm,
               |  b.actual_run_time,
               |  b.plan_run_time,
               |  b.sort_num,
               |  b.start_longitude,
               |  b.end_longitude,
               |  b.start_latitude,
               |  b.end_latitude,
               |  b.line_code,
               |  b.line_id,
               |  b.task_area_code,
               |  b.vehicle_serial,
               |  b.conveyance_type,
               |  b.transoport_level,
               |  b.id,
               |  b.is_stop,
               |  b.ground_task_id,
               |  b.start_time,
               |  b.carrier_type,
               |  b.plf_flag,
               |  b.log_dist,
               |  b.line_distance
               |from
               |  carLocus a join carTaskDetail b
               |on a.task_id = b.task_id
               |  and a.start_dept = b.start_dept
               |  and a.end_dept = b.end_dept
               |""".stripMargin

        // 获取车辆参数信息
        val carParameterInfoSQL: String =
            s"""
               |select
               |  vehicle_serial2,
               |  hko_vehicle_code,
               |  trailer_vehicle_code,
               |  source,
               |  is_trailer,
               |  vehicle_type,
               |  vehicle_length,
               |  width,
               |  height,
               |  color,
               |  energy,
               |  license,
               |  emission,
               |  axls_number,
               |  vehicle_full_load_weight,
               |  vehicle_load_weight
               |from
               |  (
               |    SELECT
               |      row_number() over(
               |        partition by regexp_replace(vehicle, '[\\r\\n\\0, \\s, \\.*。、,]+', '')
               |        order by
               |          source,case
               |            when vehicle_type = 4 then 1
               |            when vehicle_type = 8 then 2
               |            when vehicle_type = 7 then 3
               |            when vehicle_type = 6 then 4
               |            when vehicle_type = 5 then 5
               |            else 6
               |          end,
               |          inc_day,
               |          vehicle_length + 0 desc
               |      ) num,
               |      regexp_replace(vehicle, '[\\r\\n\\0, \\s, \\.*。、,]+', '') vehicle_serial2,
               |      hko_vehicle_code,
               |      trailer_vehicle_code,
               |      source,
               |      vehicle_type,
               |      length,
               |      vehicle_length,
               |      vehicle_full_load_weight,
               |      outer_length,
               |      outer_width,
               |      outer_height,
               |      inner_length,
               |      inner_width,
               |      inner_height,
               |      axis,
               |      weight,
               |      load_weight,
               |      full_load_weight,
               |      color,
               |      energy,
               |      license,
               |      emission,
               |      is_trailer,
               |      vehicle_type_ground,
               |      exception_axis,
               |      exception_weight,
               |      exception_length,
               |      exception_width,
               |      exception_height,
               |      cast(load_weight as float)/1000 as vehicle_load_weight,
               |    cast(if(outer_width > inner_width,outer_width,inner_width) as float)/1000 as width,
               |    cast(if(outer_height > inner_height,outer_height,inner_height) as float)/1000 as height,
               |    case
               |        when axis is not null then axis
               |	    when axis is null and vehicle_full_load_weight <= 18 then '2'
               |	    when axis is null and vehicle_full_load_weight <= 27 then '3'
               |	    when axis is null and vehicle_full_load_weight <= 36 then '4'
               |	    when axis is null and vehicle_full_load_weight <= 43 then '5'
               |	    when axis is null and vehicle_full_load_weight > 43 then '6'
               |	    when axis is null and vehicle_full_load_weight is null then '2'
               |    end as axls_number,
               |      inc_day
               |    FROM
               |      dm_gis.gis_tm_vehicle
               |    WHERE
               |      inc_day = '$inc_day'
               |  ) t
               |where
               |  t.num = 1
               |""".stripMargin

        val carParameterInfoDF: DataFrame = getDataFrame(logger, spark, carParameterInfoSQL, "车辆参数信息")
        val carLocusAndTaskDetailDF: DataFrame = getDataFrame(logger, spark, carLocusAndTaskDetailSQL, "辆历史轨迹及任务")


        val w1: WindowSpec = Window.orderBy($"xy")
        val w2: WindowSpec = Window.partitionBy("grp2").orderBy($"inc_day".desc)

        val carLocusAndTaskDetailAndParamRunPlanDF: DataFrame = carLocusAndTaskDetailDF
          .join(carParameterInfoDF, $"vehicle_serial" === $"vehicle_serial2", "left")
          .withColumn("line", concat_ws("_", $"start_dept", $"end_dept"))
          .withColumn("xy", concat(lit("x1="), $"start_longitude", lit("&y1="),
              $"start_latitude", lit("&x2="), $"end_longitude", lit("&y2="), $"end_latitude"))
          .withColumn("order", dense_rank().over(w1))
          .withColumn("grp0", concat_ws("_", $"line", $"order"))
          .withColumn("grp1", concat_ws("_", $"grp0", $"start_time"))
          .withColumn("grp2", concat_ws("_", $"grp1", $"vehicle_type", $"axls_number"))
          .withColumn("planDate", regexp_replace($"start_tm", "-| |:", ""))
          .withColumn("grp2_order", row_number().over(w2))
          .select("task_id", "start_dept", "end_dept", "his_coords", "start_type", "end_type",
              "start_tm", "end_tm", "actual_run_time", "plan_run_time", "sort_num", "start_longitude",
              "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code",
              "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id",
              "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2",
              "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type",
              "vehicle_length", "width", "height", "color", "energy", "license", "emission", "axls_number",
              "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2",
              "plandate", "grp2_order", "city", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑规划数据源信息：
        GetDFCountAndSampleData(logger, carLocusAndTaskDetailAndParamRunPlanDF, "用于跑规划的数据")
        // 跑规划的数据存入hive
        df2HiveByOverwrite(logger, carLocusAndTaskDetailAndParamRunPlanDF, "dm_gis.mms_car_locus_task_detail_para_plan_info")


        // 释放缓存
        carLocusAndTaskDetailDF.unpersist()
        carParameterInfoDF.unpersist()
        carLocusAndTaskDetailAndParamRunPlanDF.unpersist()
    }

    // 调高德的服务，获取对应字段的值
    def callGDService(r: Row): (String, String, String, String, String, String, String, String, String, Int, String, String) = {

        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val planDate: String = r.getAs[String]("plandate")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val emitStand: String = r.getAs[String]("emission")


        val plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("planDate", planDate)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("emitStand", emitStand)
        parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

        val url: String = gd_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url = url, 6, "utf-8")
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            val result: JSONObject = jsonData.getJSONObject("result")
            val dist: String = result.getString("dist")
            val time: String = result.getString("time")
            val tolls: String = result.getString("tolls")
            val src: String = result.getString("src")
            val flen: String = result.getString("flen")
            val tlen: String = result.getString("tlen")

            val query_tmp: JSONObject = result.getJSONObject("query")
            val coords_tmp: JSONArray = result.getJSONArray("coords")
            var query: String = ""
            var coords: String = ""
            if (query_tmp != null) query = query_tmp.toJSONString
            if (coords_tmp != null) coords = coords_tmp.toJSONString
            (uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords)
        } else
            (uuid, url, "", "", "", "", "", "", "", plan_order, "", "")
    }

    // 调用传统服务，获取对应字段的值
    def callCTService(r: Row): ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)] = {
        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val planDate: String = r.getAs[String]("plandate")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val emitStand: String = r.getAs[String]("emission")

        var plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("planDate", planDate)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("emitStand", emitStand)
        parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

        val url: String = ct_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url, 6, "utf-8")

        val listBuff = new ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)]
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")

                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    for (j <- 0 until list.size()) {
                        val obj: JSONObject = list.getJSONObject(j)
                        val dist: String = obj.getString("dist")
                        val time: String = obj.getString("time")
                        val highway: String = obj.getString("highway")
                        val traLightCount: String = obj.getString("traLightCount")
                        val tolls: String = obj.getString("tolls")
                        val src: String = obj.getString("src")
                        val flen: String = obj.getString("flen")
                        val tlen: String = obj.getString("tlen")
                        val query_tmp: JSONObject = obj.getJSONObject("query")
                        val coords_tmp: JSONArray = obj.getJSONArray("coords")
                        var query: String = ""
                        var coords: String = ""
                        if (query_tmp != null) query = query_tmp.toJSONString
                        if (coords_tmp != null) coords = coords_tmp.toJSONString

                        plan_order = j

                        listBuff.append((uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords, highway, traLightCount))
                    }
                } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))
            } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))
        } else listBuff.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", ""))

        listBuff
    }

    // 调用经验服务，获取对应字段的值
    def callJYService(r: Row): ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)] = {

        // task_id,grp2 作为确定每一行row数据的唯一值
        val uuid: String = r.getAs[String]("uuid")

        val No: String = r.getAs[String]("task_id")
        val x1: String = r.getAs[String]("start_longitude")
        val y1: String = r.getAs[String]("start_latitude")
        val x2: String = r.getAs[String]("end_longitude")
        val y2: String = r.getAs[String]("end_latitude")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axleNumber: String = r.getAs[String]("axls_number")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val energy: String = r.getAs[String]("energy")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val planDate: String = r.getAs[String]("plandate")
        val emitStand: String = r.getAs[String]("emission")

        var plan_order: Int = 0

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("No", No)
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("planDate", planDate)
        parMap.put("emitStand", emitStand)
        parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

        val url: String = jy_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url, 6, "utf-8")

        val mylist = new ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)]
        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")
                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    for (j <- 0 until list.size()) {
                        val json: JSONObject = list.getJSONObject(j)
                        val dist: String = json.getString("dist")
                        val time: String = json.getString("time")
                        val highway: String = json.getString("highway")
                        val traLightCount: String = json.getString("traLightCount")
                        val tolls: String = json.getString("tolls")
                        val src: String = json.getString("src")
                        val flen: String = json.getString("flen")
                        val tlen: String = json.getString("tlen")
                        val query_tmp: JSONObject = json.getJSONObject("query")
                        val coords_tmp: JSONArray = json.getJSONArray("coords")
                        var query: String = ""
                        var coords: String = ""

                        if (query_tmp != null) query = query_tmp.toJSONString
                        if (coords_tmp != null) coords = coords_tmp.toJSONString

                        val frequency: String = json.getString("frequency")
                        val frequencycost: String = json.getString("frequencycost")
                        val frequencytype: String = json.getString("frequencytype")
                        val freqratio: String = json.getString("freqratio")
                        val route_id: String = json.getString("route_id")
                        val src_routeids: String = json.getString("src_routeids")

                        plan_order = j

                        mylist.append((uuid, url, status, dist, time, tolls, src, flen, tlen, plan_order, query, coords,
                          highway, traLightCount, frequency, frequencycost, frequencytype, freqratio, route_id, src_routeids))
                    }
                } else mylist.append((uuid, url, status, "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))
            } else mylist.append((uuid, url, status, "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))
        } else mylist.append((uuid, url, "", "", "", "", "", "", "", plan_order, "", "", "", "", "", "", "", "", "", ""))

        mylist
    }


    // 讲接口调用成功、失败次数写入相应的表
    def interStatus2Hive(spark: SparkSession, url_name: String, url: String, className: String, success_acc: LongAccumulator, fail_acc: LongAccumulator): Unit = {
        val success_cnt: lang.Long = success_acc.value
        val fail_cnt: lang.Long = fail_acc.value
        val all_cnt: Long = success_cnt + fail_cnt

        val table: String = "dm_gis.mms_route_interface_state"
        logger.error(s"开始写入到 Hive：$table")

        spark.createDataFrame(Seq(
            (getNowTime + "_" + url_name + "_" + className, getNowTime, url_name, url, className, all_cnt.toString, success_cnt.toString, fail_cnt.toString)
        ))
          .toDF("uid", "inc_day", "url_name", "url", "class_name", "all_cnt", "success_cnt", "fail_cnt")
          .write
          .mode(SaveMode.Append)
          .insertInto(table)

        logger.error(s"写入 $table 成功！")
    }

    // 跑高德服务
    def runGDService(spark: SparkSession, planDF: DataFrame, gd_success_acc: LongAccumulator, gd_fail_acc: LongAccumulator): Unit = {
        import spark.implicits._

        // 从高德获取到的数据，关联原始数据
        val ResultDataFromGDdf: DataFrame = planDF
          .coalesce(10)
          .map(r => {
              val tp: (String, String, String, String, String, String, String, String, String, Int, String, String) = callGDService(r)
              if (tp._3 == "0") gd_success_acc.add(1L)
              else gd_fail_acc.add(1L)

              tp
          })
          .repartition(200)
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen", "d_tlen",
              "d_plan_order", "d_query", "coords")
          .filter("coords != ''")
          .join(planDF, "uuid")
          .withColumn("d_highway", lit(""))
          .withColumn("d_traLightCount", lit(""))
          .withColumn("d_frequency", lit(""))
          .withColumn("d_frequencycost", lit(""))
          .withColumn("d_frequencytype", lit(""))
          .withColumn("d_freqratio", lit(""))
          .withColumn("d_route_id", lit(""))
          .withColumn("d_src_routeids", lit(""))
          .withColumn("data_source", lit("2"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id",
              "start_dept", "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm",
              "actual_run_time", "plan_run_time", "sort_num", "start_longitude", "end_longitude", "start_latitude",
              "end_latitude", "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type",
              "transoport_level", "id", "is_stop", "ground_task_id", "start_time", "carrier_type", "plf_flag",
              "log_dist", "line_distance", "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source",
              "is_trailer", "vehicle_type", "vehicle_length", "width", "height", "color", "energy", "license",
              "emission", "axls_number", "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order",
              "grp0", "grp1", "grp2", "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype",
              "d_freqratio", "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ResultDataFromGDdf, "跑高德服务最终的结果数据")
        df2HiveByOverwrite(logger, ResultDataFromGDdf, "dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info")

        ResultDataFromGDdf.unpersist()
    }

    // 跑传统服务
    def runCTService(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 获取跑路径规划的数据
        val sql: String =
            s"""
               |select
               |  t1.*,
               |  t2.his_abnormal,
               |  t3.abnormal
               |from
               |  (select t.*,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.mms_car_locus_task_detail_para_plan_info t where inc_day = '$inc_day') t1
               |join
               |  (select his_abnormal,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_his_traj_ab_info t where t.his_abnormal != '-1' and inc_day = '$inc_day') t2
               |on t1.uuid2 = t2.uuid2
               |join
               |  (select abnormal, concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_traj_simgroup_info t where !(t.abnormal regexp '4|5') and inc_day = '$inc_day') t3
               |on t1.uuid2 = t3.uuid2
               |""".stripMargin
        val planDF: DataFrame = getPlanData(spark, sql)

        // 从传统获取到的数据，关联原始数据
        val ResultDataFromCTdf: DataFrame = planDF
          .flatMap(r => {
              val listBuff: ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String)] = callCTService(r)
              listBuff
          })
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount")
          .filter("coords != ''")
          .join(planDF, "uuid")
          .withColumn("d_frequency", lit(""))
          .withColumn("d_frequencycost", lit(""))
          .withColumn("d_frequencytype", lit(""))
          .withColumn("d_freqratio", lit(""))
          .withColumn("d_route_id", lit(""))
          .withColumn("d_src_routeids", lit(""))
          .withColumn("data_source", lit("1"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id", "start_dept",
              "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm", "actual_run_time",
              "plan_run_time", "sort_num", "start_longitude", "end_longitude", "start_latitude", "end_latitude",
              "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type", "transoport_level",
              "id", "is_stop", "ground_task_id", "start_time", "carrier_type", "plf_flag", "log_dist",
              "line_distance", "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer",
              "vehicle_type", "vehicle_length", "width", "height", "color", "energy", "license", "emission",
              "axls_number", "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0",
              "grp1", "grp2", "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype",
              "d_freqratio", "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ResultDataFromCTdf, "跑传统服务获取到的结果数据")
        df2HiveByOverwrite(logger, ResultDataFromCTdf, "dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info")


        ResultDataFromCTdf.unpersist()
        planDF.unpersist()
    }

    // 跑经验服务
    def runJYService(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 获取跑路径规划的数据
        val sql: String =
            s"""
               |select
               |  t1.*,
               |  t2.his_abnormal,
               |  t3.abnormal
               |from
               |  (select t.*,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.mms_car_locus_task_detail_para_plan_info t where inc_day = '$inc_day') t1
               |join
               |  (select his_abnormal,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_his_traj_ab_info t where t.his_abnormal != '-1' and inc_day = '$inc_day') t2
               |on t1.uuid2 = t2.uuid2
               |join
               |  (select abnormal, concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_traj_simgroup_info t where !(t.abnormal regexp '4|5') and inc_day = '$inc_day') t3
               |on t1.uuid2 = t3.uuid2
               |""".stripMargin
        val planDF: DataFrame = getPlanData(spark, sql)

        // 从经验获取到的数据，关联原始数据
        val ResultDataFromJYdf: DataFrame = planDF
          .flatMap(r => {
              val mylist: ListBuffer[(String, String, String, String, String, String, String, String, String, Int, String, String, String, String, String, String, String, String, String, String)] = callJYService(r)
              mylist
          })
          .toDF("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "d_frequency",
              "d_frequencycost", "d_frequencytype", "d_freqratio", "d_route_id", "d_src_routeids")
          .filter("coords != ''")
          .join(planDF, "uuid")
          .withColumn("data_source", lit("3"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen", "d_tlen",
              "d_plan_order", "d_query", "coords", "d_highway", "d_traLightCount", "task_id", "start_dept", "end_dept",
              "his_coords", "start_type", "end_type", "start_tm", "end_tm", "actual_run_time", "plan_run_time",
              "sort_num", "start_longitude", "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id",
              "task_area_code", "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop",
              "ground_task_id", "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance",
              "vehicle_serial2", "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type",
              "vehicle_length", "width", "height", "color", "energy", "license", "emission", "axls_number",
              "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2",
              "planDate", "grp2_order", "d_frequency", "d_frequencycost", "d_frequencytype", "d_freqratio",
              "d_route_id", "d_src_routeids", "data_source", "city", "version", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ResultDataFromJYdf, "跑经验服务最终的结果数据")
        df2HiveByAppend(logger, ResultDataFromJYdf, "dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info")

        ResultDataFromJYdf.unpersist()
        planDF.unpersist()
    }

    // 获取跑规划的原始数据
    def getPlanData(spark: SparkSession, sql: String): DataFrame = {
        import spark.implicits._

        val xmlStr: String = getJsonByGet2(version_url, 10, "utf-8")
        val version: String = getVersion(xmlStr)

        logger.error(sql)

        val planDF: DataFrame = spark
          .sql(sql)
          .withColumn("uuid", concat_ws("_", $"task_id", $"start_dept", $"end_dept"))
          .withColumn("version", lit(version))
          .repartition(200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑路径规划数据信息：
        GetDFCountAndSampleData(logger, planDF, "用于跑规划的数据")

        planDF
    }

    // 调用闯行的接口
    def callLimitedRoute(r: Row, i: Int = 1): (String, String, Int, JSONObject) = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        var d_plan_order: Int = 0
        if (i == 2) d_plan_order = r.getAs[Int]("d_plan_order")

        var origin: String = ""
        var destination: String = ""
        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
          .replaceAll("'", "")
        val coordsArr: Array[String] = coords.split("\\|")
        for (i <- coordsArr.indices) {
            if (i == 0) origin = coordsArr(i)
            if (i == coordsArr.length - 1) destination = coordsArr(i)
        }

        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val emitStand: String = r.getAs[String]("emission")
        val energy: String = r.getAs[String]("energy")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val Mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val width: Double = r.getAs[Double]("width")
        val Size: String = r.getAs[String]("vehicle_length")
        val axlenumber: String = r.getAs[String]("axls_number")
        val No: String = r.getAs[String]("task_id")
        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&origin=$origin&destination=$destination&stype=0&etype=0&plate=$plate" +
          s"&plateColor=$plateColor&emitStand=$emitStand&energy=$energy&weight=$weight&vehicle=$vehicle&Mload=$Mload" +
          s"&height=$height&width=$width&Size=$Size&axlenumber=$axlenumber&passport=100000&mode=2&speed=1&No=$No&Toll=1&date=$date&len_diff=50&len_percent=0.5"


        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        var json: JSONObject = null

        try {
            val jsonStr: String = mapData.get("content").toString
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }

        (uuid, data_source, d_plan_order, json)
    }

    // 解析接口返回的json,获取相应的字段值
    def parseLimitedData(uuid: String, data_source: String, d_plan_order: Int, j: JSONObject): ListBuffer[RunTrafficControlDataFromInter] = {
        // 存放闯行的数据
        val rules: ListBuffer[RunTrafficControlDataFromInter] = new ListBuffer[RunTrafficControlDataFromInter]

        if (j != null) {
            val status: String = j.getString("status")
            if (status == "0") {
                val route: JSONObject = j.getJSONObject("route")
                val qstartxy: String = route.getString("origin")
                val qendxy: String = route.getString("destination")
                val paths: JSONArray = route.getJSONArray("paths")

                // 判断这个json数据是否闯行，默认false：不闯行
                var flag: Boolean = false
                if (paths.size() > 0) {
                    for (i <- 0 until paths.size() if !flag) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        if (obj.containsKey("voi_rule") && obj.getJSONArray("voi_rule").size() > 0) flag = true
                    }
                }

                // 闯行 与 不闯行 的公共解析字段
                // 开始解析公共字段
                var rdist: Int = 0
                var rtime: Double = 0.0
                var rhighway: Int = 0
                var rtraLightCount: Int = 0
                var rtolls: Int = 0
                var rtollsDistance: Int = 0
                val rcoords_tmp = new ListBuffer[String]
                val rsteps: String = ""
                var rulecount: Int = 0
                var rflen: Int = 0
                var rtlen: Int = 0
                val polyline_buff = new ListBuffer[String]
                val steps_links_swid_buff = new ListBuffer[String]
                var rmultiPathPos: String = ""
                var rmultiPathSwid: String = ""
                var first_swid: String = ""
                var last_swid: String = ""

                if (paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        rdist += obj.getInteger("distance")
                        rtime += obj.getDouble("duration")
                        rhighway += obj.getInteger("highspeed_distance")
                        rtraLightCount += obj.getInteger("trafficlight_count")
                        rtolls += obj.getInteger("tolls")
                        rtollsDistance += obj.getInteger("toll_distance")
                        rcoords_tmp.append(obj.getString("polyline"))

                        if (i == 0) rflen = obj.getInteger("flen")
                        if (i == paths.size() - 1) rtlen = obj.getInteger("tlen")

                        val polylineArr: Array[String] = obj.getString("polyline").split(";", -1)
                        val posStr: String = polylineArr.head + "_" + polylineArr.last
                        polyline_buff.append(posStr)

                        val steps: JSONArray = obj.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            val first_step: JSONObject = steps.getJSONObject(0)
                            val last_step: JSONObject = steps.getJSONObject(steps.size() - 1)

                            val first_links: JSONArray = first_step.getJSONArray("links")
                            val last_links: JSONArray = last_step.getJSONArray("links")

                            if (first_links != null && first_links.size() > 0) first_swid = first_links.getJSONObject(0).getString("sw_id")
                            if (last_links != null && last_links.size() > 0) last_swid = last_links.getJSONObject(last_links.size - 1).getString("sw_id")

                            steps_links_swid_buff.append(first_swid + "_" + last_swid)
                        }

                        if (obj.containsKey("voi_rule")) rulecount += obj.getJSONArray("voi_rule").size()

                    }
                }
                val rcoords: String = rcoords_tmp.mkString(";")
                if (polyline_buff.size > 1) rmultiPathPos = polyline_buff.mkString("|")
                if (steps_links_swid_buff.size > 1) rmultiPathSwid = steps_links_swid_buff.mkString("|")


                // 公共字段解析结束

                // 如果未闯行，写入未闯行的表
                if (!flag) {
                    val line: RunTrafficControlDataFromInter = RunTrafficControlDataFromInter(uuid, data_source, d_plan_order, flag, status, rdist, rtime, rhighway, rtraLightCount, rtolls,
                        rtollsDistance, qstartxy, qendxy, rcoords, rsteps, rflen, rtlen, rulecount, "", "", "", "", "", "", "", "", "", "", "", "", "", "",
                        "", "", "", "", "", "", "", "", "", "", "", "", "", "", rmultiPathPos, rmultiPathSwid)
                    rules.append(line)
                } else {
                    // 对闯行的数据做处理
                    var ruleorder = 0
                    for (i <- 0 until paths.size()) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        if (obj.containsKey("voi_rule") && obj.getJSONArray("voi_rule").size() > 0) {
                            for (j <- 0 until obj.getJSONArray("voi_rule").size()) {
                                val rule: JSONObject = obj.getJSONArray("voi_rule").getJSONObject(j)
                                ruleorder = ruleorder + j + 1
                                val ruletype: String = rule.getString("type")
                                val rulepos: String = rule.getString("pos")
                                val ruleroadid: String = rule.getString("road_id")
                                val ruleoutroadid: String = rule.getString("out_road_id")
                                val ruleroadname: String = rule.getString("name")

                                val limit: JSONObject = rule.getJSONObject("limit")
                                var ruleid: String = ""
                                var Guid: String = ""
                                var limitweight: String = ""
                                var limitsize: String = ""
                                var limitwidth: String = ""
                                var limitaxload: String = ""
                                var limitload: String = ""
                                var limitaxcnt: String = ""
                                var limitpassport: String = ""
                                var limitholiday: String = ""
                                var limitvehicletype: String = ""
                                var limitoutflag: String = ""
                                var limitemitStand: String = ""
                                var limittailchar: String = ""
                                var limitstartdate: String = ""
                                var limitenddate: String = ""
                                var limitweek: String = ""
                                var limittime: String = ""
                                if (limit != null && limit.size() > 0) {
                                    ruleid = limit.getString("RuleID")
                                    Guid = limit.getString("Guid")
                                    limitweight = limit.getString("限重")
                                    limitsize = limit.getString("限高")
                                    limitwidth = limit.getString("限宽")
                                    limitaxload = limit.getString("限轴重")
                                    limitload = limit.getString("限载重")
                                    limitaxcnt = limit.getString("限轴数")
                                    limitpassport = limit.getString("通行证")
                                    limitholiday = limit.getString("节假日")
                                    limitvehicletype = limit.getString("车辆类型")
                                    limitoutflag = limit.getString("限车辆属地")
                                    limitemitStand = limit.getString("限燃油标号")
                                    limittailchar = limit.getString("限尾号")
                                    limitstartdate = limit.getString("开始日期")
                                    limitenddate = limit.getString("结束日期")
                                    limitweek = limit.getString("限星期")
                                    limittime = limit.getString("限时段")
                                }


                                var ruletimedesc: String = ""
                                var ruleregiondesc: String = ""
                                var rulevehicle: String = ""
                                var rulestrategy: String = ""
                                val region_rule: JSONArray = rule.getJSONArray("region_rule")
                                if (region_rule != null && region_rule.size() > 0) {
                                    ruletimedesc = region_rule.getJSONObject(0).getString("time")
                                    ruleregiondesc = region_rule.getJSONObject(0).getString("region")
                                    rulevehicle = region_rule.getJSONObject(0).getString("vehicle")
                                    rulestrategy = region_rule.getJSONObject(0).getString("strategy")
                                }

                                val ruleorder_tmp: String = ruleorder.toString
                                val line: RunTrafficControlDataFromInter = RunTrafficControlDataFromInter(uuid, data_source, d_plan_order, flag, status, rdist, rtime, rhighway, rtraLightCount, rtolls,
                                    rtollsDistance, qstartxy, qendxy, rcoords, rsteps, rflen, rtlen, rulecount, ruleorder_tmp, ruleid, ruletype, rulepos, ruleroadid, ruleoutroadid,
                                    ruleroadname, limitweight, limitsize, limitwidth, limitaxload, limitload, limitaxcnt, limitpassport, limitholiday, limitvehicletype,
                                    limitoutflag, limitemitStand, limittailchar, limitstartdate, limitenddate, limitweek, limittime, Guid, ruletimedesc, ruleregiondesc,
                                    rulevehicle, rulestrategy, rmultiPathPos, rmultiPathSwid)

                                rules.append(line)
                            }
                        }
                    }
                }

                rules
            } else rules
        } else rules

    }

    // 跑闯行服务
    def runLimitedService(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 获取用于跑闯行的数据   -- 规划的数据
        val originalDataSQL: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info
               |where
               |  inc_day = '$inc_day'
               |  and d_status = '0'
               |""".stripMargin

        val originalDataDF: DataFrame = getDataFrame(logger, spark, originalDataSQL)

        val df: DataFrame = originalDataDF
          .repartition(10)
          .flatMap(r => {
              val (uuid, data_source, d_plan_order, jsonData) = callLimitedRoute(r, 2)
              val listBuf: ListBuffer[RunTrafficControlDataFromInter] = parseLimitedData(uuid, data_source, d_plan_order, jsonData)
              listBuf
          })
          .repartition(200)
          .toDF()

        // 接口解析出的数据  和  原始数据关联上  -- 规划的数据
        val runLimitedResultDF: DataFrame = originalDataDF
          .join(df, Seq("uuid", "data_source", "d_plan_order"))
          .select("uuid", "d_url", "d_status", "d_dist", "d_time", "d_tolls", "d_src", "d_flen",
              "d_tlen", "d_plan_order", "d_query", "coords", "d_highway", "d_tralightcount", "task_id",
              "start_dept", "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm",
              "actual_run_time", "plan_run_time", "sort_num", "start_longitude", "end_longitude",
              "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code", "vehicle_serial",
              "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id", "start_time",
              "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2", "hko_vehicle_code",
              "trailer_vehicle_code", "source", "is_trailer", "vehicle_type", "vehicle_length", "width", "height",
              "color", "energy", "license", "emission", "axls_number", "vehicle_full_load_weight",
              "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2", "plandate", "grp2_order",
              "d_frequency", "d_frequencycost", "d_frequencytype", "d_freqratio", "d_route_id", "d_src_routeids",
              "data_source", "flag", "status", "rdist", "rtime", "rhighway", "rtralightcount", "rtolls",
              "rtollsdistance", "qstartxy", "qendxy", "rcoords", "rsteps", "rflen", "rtlen", "rulecount",
              "ruleorder", "ruleid", "ruletype", "rulepos", "ruleroadid", "ruleoutroadid", "ruleroadname",
              "limitweight", "limitsize", "limitwidth", "limitaxload", "limitload", "limitaxcnt", "limitpassport",
              "limitholiday", "limitvehicletype", "limitoutflag", "limitemitstand", "limittailchar",
              "limitstartdate", "limitenddate", "limitweek", "limittime", "guid", "ruletimedesc", "ruleregiondesc",
              "rulevehicle", "rulestrategy", "rmultipathpos", "rmultipathswid", "city", "version", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, runLimitedResultDF, "【规划的数据源】最终的结果数据")

        // 未闯行的数据
        val unLimitedDF: Dataset[Row] = runLimitedResultDF
          .filter("flag==false")
        df2HiveByOverwrite(logger, unLimitedDF, "dm_gis.mms_car_route_plan_detail_and_unlimited_info")

        // 闯行的数据
        val limitedDF: Dataset[Row] = runLimitedResultDF
          .filter("flag==true")
        df2HiveByOverwrite(logger, limitedDF, "dm_gis.mms_car_route_plan_detail_and_limited_info")

        runLimitedResultDF.unpersist()
        originalDataDF.unpersist()
    }

    // 获取纠偏的原始数据
    def getJPData(spark: SparkSession, jpsql1: String, jpsql2: String): DataFrame = {
        import spark.implicits._

        logger.error(jpsql1)
        logger.error(jpsql2)

        val df1: DataFrame = spark.sql(jpsql1)
        val df2: DataFrame = spark
          .sql(jpsql2)
          .rdd
          .map(r => {
              val info: String = r.getAs[String]("info")
              val jsonObj: JSONObject = JSON.parseObject(info)

              val task_id: String = jsonObj.getString("task_id")
              val start_dept: String = jsonObj.getString("start_dept")
              val end_dept: String = jsonObj.getString("end_dept")
              val uuid2: String = task_id + start_dept + end_dept

              val jp_swid_tmp: String = jsonObj.getString("jp_swid")
              val coords_tmp: String = jsonObj.getString("rt_coords")
              val jp_status_tmp: String = jsonObj.getString("status")

              var coords = ""
              var jp_swid = ""
              var jp_status = ""
              if (jp_swid_tmp != null && jp_swid_tmp.nonEmpty && coords_tmp != null && coords_tmp.nonEmpty && jp_status_tmp != null && jp_status_tmp.nonEmpty) {
                  coords = coords_tmp.replaceAll("\"", "")
                    .replaceAll("\\[", "")
                    .replaceAll("],", "|")
                    .replaceAll("]", "")

                  jp_swid = jp_swid_tmp
                    .replaceAll("\\[", "")
                    .replaceAll("]", "")

                  jp_status = jp_status_tmp
                    .replaceAll("\\[", "")
                    .replaceAll("]", "")
              }

              (uuid2, coords, jp_swid, jp_status)
          })
          .toDF("uuid2", "coords", "jp_swid", "jp_status")
          .filter("coords !=''")

        // 获取用于跑闯行的数据   -- 纠偏的数据

        val xmlStr: String = getJsonByGet2(version_url, 10, "utf-8")
        val version: String = getVersion(xmlStr)

        val origJPDataDF: DataFrame = df1
          .join(df2, Seq("uuid2"))
          .withColumn("version", lit(version))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 跑路径规划数据信息： -- 纠偏的数据源
        GetDFCountAndSampleData(logger, origJPDataDF, "【纠偏的数据源】用于跑闯行的数据")
        df2HiveByOverwrite(logger, origJPDataDF, "dm_gis.mms_car_route_jp_detail_info")

        origJPDataDF
    }

    // 纠偏的数据跑闯行服务
    def runLimitedServiceFromJP(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 获取纠偏的数据 his_abnormal 、abnormal
        val jpsql1: String =
            s"""
               |select
               |  t1.*,
               |  t2.his_abnormal,
               |  t3.abnormal,
               |  '0' data_source
               |from
               |  (select t.*,concat(task_id,'_',start_dept,'_',end_dept) uuid,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.mms_car_locus_task_detail_para_plan_info t where inc_day = '$inc_day') t1
               |join
               |  (select his_abnormal,concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_his_traj_ab_info t where t.his_abnormal != '-1' and inc_day = '$inc_day' ) t2
               |on t1.uuid2 = t2.uuid2
               |join
               |  (select abnormal, concat(task_id,start_dept,end_dept) uuid2 from dm_gis.eta_traj_simgroup_info t where !(t.abnormal regexp '4|5') and inc_day = '$inc_day' ) t3
               |on t1.uuid2 = t3.uuid2
               |""".stripMargin

        //获取纠偏的数据 coords 、jp_swid、jp_status
        val dlr = '$'
        val jpsql2: String =
            s"""
               |select
               |  info
               |from
               |  dm_gis.eta_traj_info t
               |where
               |  inc_day = '$inc_day'
               |  and get_json_object(info, '$dlr.carrier_type') = 0
               |""".stripMargin

        val origJPDataDF: DataFrame = getJPData(spark, jpsql1, jpsql2)

        val jpLimited: DataFrame = origJPDataDF
          .repartition(10)
          .flatMap(r => {
              val (uuid, data_source, d_plan_order, jsonData) = callLimitedRoute(r)
              val listBuf: ListBuffer[RunTrafficControlDataFromInter] = parseLimitedData(uuid, data_source, d_plan_order, jsonData)
              listBuf
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 接口解析出的数据  和  原始数据关联上  --纠偏的数据
        val jpResultDF: DataFrame = origJPDataDF
          .drop("data_source")
          .join(jpLimited, "uuid")
          .select("uuid", "task_id", "start_dept", "end_dept", "his_coords", "start_type", "end_type",
              "start_tm", "end_tm", "actual_run_time", "plan_run_time", "sort_num", "start_longitude",
              "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code",
              "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id",
              "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance", "vehicle_serial2",
              "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type", "vehicle_length",
              "width", "height", "color", "energy", "license", "emission", "axls_number", "vehicle_full_load_weight",
              "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "grp2", "plandate", "grp2_order",
              "uuid2", "his_abnormal", "abnormal", "coords", "jp_swid", "jp_status", "data_source", "flag", "status",
              "rdist", "rtime", "rhighway", "rtralightcount", "rtolls", "rtollsdistance", "qstartxy", "qendxy",
              "rcoords", "rsteps", "rflen", "rtlen", "rulecount", "ruleorder", "ruleid", "ruletype", "rulepos",
              "ruleroadid", "ruleoutroadid", "ruleroadname", "limitweight", "limitsize", "limitwidth", "limitaxload",
              "limitload", "limitaxcnt", "limitpassport", "limitholiday", "limitvehicletype", "limitoutflag",
              "limitemitstand", "limittailchar", "limitstartdate", "limitenddate", "limitweek", "limittime",
              "guid", "ruletimedesc", "ruleregiondesc", "rulevehicle", "rulestrategy", "rmultipathpos", "rmultipathswid", "city", "version", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpResultDF, "【纠偏的数据源】最终的结果数据")


        // 对未闯行的数据写入hive表   -- 纠偏的数据
        val unLimited: Dataset[Row] = jpResultDF
          .filter("flag==false")

        df2HiveByOverwrite(logger, unLimited, "dm_gis.mms_car_route_jp_detail_and_unlimited_info")

        // 对闯行的数据写入hive表   -- 纠偏的数据

        val limitedDF: Dataset[Row] = jpResultDF
          .filter("flag==true")

        df2HiveByOverwrite(logger, limitedDF, "dm_gis.mms_car_route_jp_detail_and_limited_info")

        // 释放缓存
        jpResultDF.unpersist()
        origJPDataDF.unpersist()
        jpLimited.unpersist()
    }

    // 获取swid、next_swid、point、next_pint、adcode 的值
    def get_swid_and_point(r: Row): ListBuffer[SwidPoint] = {
        val groupby_id: String = r.getAs[String]("groupby_id")
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = r.getAs[Int]("d_plan_order")
        val coords: String = r.getAs[String]("coords")
        val rcoords: String = r.getAs[String]("rcoords")
        val rmultipathpos: String = r.getAs[String]("rmultipathpos")
        val rmultipathswid: String = r.getAs[String]("rmultipathswid")
        val start_dept: String = r.getAs[String]("start_dept")
        val end_dept: String = r.getAs[String]("end_dept")
        val start_longitude: String = r.getAs[String]("start_longitude")
        val end_longitude: String = r.getAs[String]("end_longitude")
        val start_latitude: String = r.getAs[String]("start_latitude")
        val end_latitude: String = r.getAs[String]("end_latitude")
        val jp_status: String = r.getAs[String]("jp_status")
        val jp_swid: String = r.getAs[String]("jp_swid")
        val city: String = r.getAs[String]("city")
        val version: String = r.getAs[String]("version")
        val inc_day: String = r.getAs[String]("inc_day")

        val pointBuff: ListBuffer[String] = new ListBuffer[String]
        val swidBuff: ListBuffer[String] = new ListBuffer[String]
        val next_pointBuff: ListBuffer[String] = new ListBuffer[String]
        val next_swidBuff: ListBuffer[String] = new ListBuffer[String]


        val posArr: Array[String] = rmultipathpos.split("\\|", -1)
        val swidArr: Array[String] = rmultipathswid.split("\\|", -1)

        for (i <- posArr.indices) {
            if (i != posArr.length - 1) {
                pointBuff.append(posArr(i).split("_", -1)(1))
                swidBuff.append(swidArr(i).split("_", -1)(1))
            }

            if (i != 0) {
                next_pointBuff.append(posArr(i).split("_", -1)(0))
                next_swidBuff.append(swidArr(i).split("_", -1)(0))
            }
        }

        val firstSwid: String = swidArr(0).split("_", -1)(0)
        val lastSwid: String = swidArr(swidArr.length - 1).split("_", -1)(1)

        val allBuff: ListBuffer[SwidPoint] = new ListBuffer[SwidPoint]
        var points_type: String = "0"
        for (i <- swidBuff.indices) {
            val swid: String = swidBuff(i)
            val next_swid: String = next_swidBuff(i)
            val point: String = pointBuff(i)
            val next_point: String = next_pointBuff(i)

            if (swid == next_swid && swid == firstSwid) points_type = "1"
            else if (swid == next_swid && swid == lastSwid) points_type = "2"
            else if (point == next_point) points_type = "3"

            var adcode: String = ""
            if (swid != null && swid.nonEmpty) {
                val json: JSONObject = callMatchService(swid)
                val tp: (String, String) = getMatchAbnormalData(json)
                adcode = tp._1

            }

            allBuff.append(
                SwidPoint(groupby_id, uuid, data_source, d_plan_order, coords, rcoords, rmultipathpos, rmultipathswid, swid, next_swid, point,
                    next_point, points_type, start_dept, end_dept, start_longitude, end_longitude, start_latitude, end_latitude, jp_status, jp_swid, city, version, adcode, inc_day)
            )
        }

        allBuff
    }


    // 匹配中断
    def getmatchBreakoffData(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        val thirty_day_ago: String = getdaysBeforeOrAfter(inc_day, -30)

        // 规划的未闯行数据
        val unlimitedSql: String =
            s"""
               |select
               |  concat_ws('_',uuid,string(d_plan_order),data_source) as groupby_id,
               |  uuid,
               |  data_source,
               |  d_plan_order,
               |  regexp_replace(regexp_replace(regexp_replace(regexp_replace(coords,'\\\\]',''),',\\\\[','|'),'\\\\"',''),'\\\\[','') as coords,
               |  regexp_replace(rcoords,';','|') as rcoords,
               |  rmultipathpos,
               |  rmultipathswid,
               |  start_dept,
               |  end_dept,
               |  start_longitude,
               |  end_longitude,
               |  start_latitude,
               |  end_latitude,
               |  '' as jp_status,
               |  '' as jp_swid,
               |  city,
               |  version,
               |  inc_day
               |from
               |  dm_gis.mms_car_route_plan_detail_and_unlimited_info
               |where
               |  data_source = '2'
               |  and inc_day = '$inc_day'
               |""".stripMargin

        // 规划的闯行数据
        val limitedSql: String =
            s"""
               |select
               |  concat_ws('_',uuid,string(d_plan_order),data_source) as groupby_id,
               |  uuid,
               |  data_source,
               |  d_plan_order,
               |  regexp_replace(regexp_replace(regexp_replace(regexp_replace(coords,'\\\\]',''),',\\\\[','|'),'\\\\"',''),'\\\\[','') as coords,
               |  regexp_replace(rcoords,';','|') as rcoords,
               |  rmultipathpos,
               |  rmultipathswid,
               |  start_dept,
               |  end_dept,
               |  start_longitude,
               |  end_longitude,
               |  start_latitude,
               |  end_latitude,
               |  '' as jp_status,
               |  '' as jp_swid,
               |  city,
               |  version,
               |  inc_day
               |from
               |  dm_gis.mms_car_route_plan_detail_and_limited_info
               |where
               |  data_source = '2'
               |  and inc_day = '$inc_day'
               |""".stripMargin

        // 纠偏的闯行数据
        val jplimitedSql: String =
            s"""
               |select
               |  concat_ws('_',uuid,'0',data_source) as groupby_id,
               |  uuid,
               |  data_source,
               |  0 as d_plan_order,
               |  regexp_replace(regexp_replace(regexp_replace(regexp_replace(coords,'\\\\]',''),',\\\\[','|'),'\\\\"',''),'\\\\[','') as coords,
               |  regexp_replace(rcoords,';','|') as rcoords,
               |  rmultipathpos,
               |  rmultipathswid,
               |  start_dept,
               |  end_dept,
               |  start_longitude,
               |  end_longitude,
               |  start_latitude,
               |  end_latitude,
               |  jp_status,
               |  jp_swid,
               |  city,
               |  version,
               |  inc_day
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin

        // 纠偏的未闯行数据
        val jpunlimitedSql: String =
            s"""
               |select
               |  concat_ws('_',uuid,'0',data_source) as groupby_id,
               |  uuid,
               |  data_source,
               |  0 as d_plan_order,
               |  regexp_replace(regexp_replace(regexp_replace(regexp_replace(coords,'\\\\]',''),',\\\\[','|'),'\\\\"',''),'\\\\[','') as coords,
               |  regexp_replace(rcoords,';','|') as rcoords,
               |  rmultipathpos,
               |  rmultipathswid,
               |  start_dept,
               |  end_dept,
               |  start_longitude,
               |  end_longitude,
               |  start_latitude,
               |  end_latitude,
               |  jp_status,
               |  jp_swid,
               |  city,
               |  version,
               |  inc_day
               |from
               |  dm_gis.mms_car_route_jp_detail_and_unlimited_info
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin

        // 最近30天已经下发的数据
        val gdBreakpointSwindSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.all_result_gd_breakpoint_swid_info
               |where
               |  inc_day >= '$thirty_day_ago'
               |  and inc_day <= '$inc_day'
               |""".stripMargin

        logger.error(unlimitedSql)
        logger.error(limitedSql)
        logger.error(jplimitedSql)
        logger.error(jpunlimitedSql)
        logger.error(gdBreakpointSwindSql)

        val unlimitedDF: DataFrame = spark.sql(unlimitedSql)
        val limitedDF: DataFrame = spark.sql(limitedSql)
        val jpunlimitedDF: DataFrame = spark.sql(jpunlimitedSql)
        val jplimitedDF: DataFrame = spark.sql(jplimitedSql)

        val ft_url: String = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&ak=ebf48ecaa1fd436fa3d40c4600aa051f&x1=113.9213889&y1=22.673595&x2=114.036305&y2=22.638273&type=0&cc=1&strategy=0&opt=gd3&vehicle=6&weight=3.0&mload=3.0&height=2.4&axleNumber=2&plate=%E7%B2%A4C5909S&plateColor=1&energy=2&width=2.4&size=5.2&passport=100000&tolls=1&test=0&stype=0&etype=2&pathCount=1&fencedist=50&merge=4&fixedroute=2&frequency=1"

        // 合并所有的数据
        val limitedAllDF: DataFrame = unlimitedDF
          .union(limitedDF)
          .union(jpunlimitedDF)
          .union(jplimitedDF)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, limitedAllDF, "闯行+未闯行数据")

        // 生产协助作业需要的数据
        val union_navidemoDF: DataFrame = limitedAllDF
          .filter("rmultipathpos != '' and rmultipathswid != ''")
          .withColumn("ft_url", lit(ft_url))
          .withColumn("tracks1", $"coords")
          .withColumn("tracks2", $"rcoords")
          .withColumnRenamed("groupby_id", "reqid")
          .withColumnRenamed("coords", "ft_coords")
          .withColumnRenamed("rcoords", "gd_coords")
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 查看样例数据
        GetDFCountAndSampleData(logger, union_navidemoDF, "union_navidemo")
        // 写入到 Hive
        df2HiveByOverwrite(logger, union_navidemoDF, "dm_gis.gd_breakpoint_union_navidemo")
        union_navidemoDF.unpersist()

        // 获取 swid、point
        val limitedAndSwidAndPointDS: Dataset[SwidPoint] = limitedAllDF
          .filter("rmultipathpos != '' and rmultipathswid != ''")
          .filter(r => {
              val rmultipathpos: String = r.getAs[String]("rmultipathpos")
              val rmultipathswid: String = r.getAs[String]("rmultipathswid")

              val posLen: Int = rmultipathpos.split("\\|", -1).length
              val swidLen: Int = rmultipathswid.split("\\|", -1).length

              if (posLen == swidLen) true else false
          })
          .rdd
          .repartition(5)
          .flatMap(r => {
              val swidAndPoint: ListBuffer[SwidPoint] = get_swid_and_point(r)
              swidAndPoint
          })
          .toDS()
          .filter(r => r.adcode != "")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDSCountAndSampleData(logger, limitedAndSwidAndPointDS, "limitedAndSwidAndPointDS 数据")

        // 写入到 Hive
        ds2HiveByOverwrite(logger, limitedAndSwidAndPointDS, "dm_gis.gd_breakpoint_union_match")

        // 根据 swid，next_swid和pointType 进行聚合

        // 处理纠偏的数据
        val ruleroadidDF: DataFrame = limitedAndSwidAndPointDS
          .filter("data_source = '0'")
          .select("groupby_id", "swid", "point", "uuid", "coords", "jp_swid", "jp_status")

        val pointDF: DataFrame = limitedAndSwidAndPointDS
          .filter("data_source = '0'")
          .select("groupby_id", "next_swid", "next_point", "uuid", "coords", "jp_swid", "jp_status")

        val ruleroadidAndPointDF: DataFrame = ruleroadidDF
          .union(pointDF)
          .toDF("groupby_id", "ruleroadid", "rulepos", "uuid", "coords", "jp_swid", "jp_status")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // ruleroadidAndPoint 数据
        GetDFCountAndSampleData(logger, ruleroadidAndPointDF, "ruleroadidAndPoint 数据")

        // 每个ruleroadid 对应的数量
        val ruleroadidDF2: DataFrame = ruleroadidAndPointDF
          .rdd
          .map(r => {
              val ruleroadid: String = r.getAs[String]("ruleroadid")
              (ruleroadid, r)
          })
          .groupByKey()
          .flatMap(r => {
              val rows: Iterable[Row] = r._2
              val cnt: Int = r._2.size

              val groupby_idSet: mutable.HashSet[String] = new mutable.HashSet[String]
              for (r <- rows) {
                  val groupby_id: String = r.getAs[String]("groupby_id")
                  groupby_idSet.add(groupby_id)
              }
              val buff: ListBuffer[(String, Int)] = new ListBuffer[(String, Int)]
              val arr: Array[String] = groupby_idSet.toArray
              for (i <- arr.indices) buff.append((arr(i), cnt))
              buff
          })
          .toDF("groupby_id", "cnt")
          .filter("cnt < 10")

        // 剔除 cnt 小于10之后的groupby_id 数据，再找到 mark in(1,2,3) 的那些数据
        val ruleroadidAndPointDF2: DataFrame = ruleroadidAndPointDF
          .join(ruleroadidDF2, Seq("groupby_id"), "leftanti")
          .map(r => {
              val groupby_id: String = r.getAs[String]("groupby_id")
              val rulepos: String = r.getAs[String]("rulepos")
              val tp: (String, Double, Double, Double, Double, Int, BigDecimal, Double, Double) = getDistAndPointAndMark(r)
              (groupby_id, rulepos, tp._6)
          })
          .toDF("groupby_id", "rulepos", "mark")
          .filter("mark in(1,2,3)")
          .join(limitedAndSwidAndPointDS, Seq("groupby_id"), "right")
          .filter("mark is null")
          .drop("rulepos", "mark")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 查看样例数据
        GetDFCountAndSampleData(logger, ruleroadidAndPointDF2, "纠偏的数据")

        // 纠偏的数据  获取swids_freq
        val swid_freqDF1: DataFrame = ruleroadidAndPointDF2
          .groupByKey(r => {
              val inc_day: String = r.getAs[String]("inc_day")
              val swid: String = r.getAs[String]("swid")
              val next_swid: String = r.getAs[String]("next_swid")
              val points_type: String = r.getAs[String]("points_type")
              val point: String = r.getAs[String]("point")
              val next_point: String = r.getAs[String]("next_point")
              val data_source: String = r.getAs[String]("data_source")
              val city: String = r.getAs[String]("city")
              val version: String = r.getAs[String]("version")
              (inc_day, swid, next_swid, points_type, point, next_point, data_source, city, version)
          })
          .count()
          .map(r => {
              val (inc_day, swid, next_swid, points_type, point, next_point, data_source, city, version) = r._1
              val swids_freq: Long = r._2
              (swid, next_swid, point, next_point, points_type, data_source, swids_freq, swids_freq, city, version, inc_day)
          })
          .toDF("swid", "next_swid", "point", "next_point", "points_type", "data_source", "swids_freq", "points_freq", "city", "version", "inc_day")


        // 规划的数据  获取swids_freq
        val swid_freqDF2: DataFrame = limitedAndSwidAndPointDS
          .filter("data_source = '2'")
          .groupByKey(r => (r.inc_day, r.swid, r.next_swid, r.points_type, r.point, r.next_point, r.data_source, r.city, r.version))
          .count()
          .map(r => {
              val (inc_day, swid, next_swid, points_type, point, next_point, data_source, city, version) = r._1
              val swids_freq: Long = r._2
              (swid, next_swid, point, next_point, points_type, data_source, swids_freq, swids_freq, city, version, inc_day)
          })
          .toDF("swid", "next_swid", "point", "next_point", "points_type", "data_source", "swids_freq", "points_freq", "city", "version", "inc_day")


        // 合并在一起
        val ruleroadidAndPointResultDF: DataFrame = swid_freqDF1.union(swid_freqDF2)

        // 已经下发过的 swid 和 points
        val thirtyAgoSwid: DataFrame = getDataFrame(logger, spark, gdBreakpointSwindSql)

        // 合并在一起，然后 过滤已经下发过的数据
        val groupbyDF: DataFrame = limitedAndSwidAndPointDS.select("swid", "next_swid", "groupby_id", "adcode")

        val swidFreAndPointsFreDF: Dataset[Row] = groupbyDF
          .join(ruleroadidAndPointResultDF, Seq("swid", "next_swid"))
          .join(thirtyAgoSwid, Seq("swid", "next_swid"), "leftanti")
          .dropDuplicates("swid", "next_swid")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)


        // 查看样例数据
        GetDFCountAndSampleData(logger, swidFreAndPointsFreDF, "swidFreAndPointsFre")
        // 写入到 Hive
        df2HiveByOverwrite(logger, swidFreAndPointsFreDF, "dm_gis.all_result_gd_breakpoint_swid_info")

        limitedAndSwidAndPointDS.unpersist()
        swidFreAndPointsFreDF.unpersist()
        limitedAllDF.unpersist()
    }

    // 车参异常处理
    def dealCarParamAbnorma(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        val dist: Int = 5

        logger.error("<================ 纠偏的数据进行车参异常剔除和匹配异常处理 ================>")

        // 1.1 纠偏获取到的闯行数据
        val jpLimitedDataSQL: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin

        logger.error(jpLimitedDataSQL)

        // 1.2 获取纠偏的数据
        val jpLimitedDF: DataFrame = spark.sql(jpLimitedDataSQL)
          .drop("rmultipathpos", "rmultipathswid")
          .repartition(600)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 1.3 纠偏的数据源
        GetDFCountAndSampleData(logger, jpLimitedDF, "纠偏的数据")

        // 1.4 删除纠偏数据里 车参异常的数据
        val jpLimitedAfterDealDF: Dataset[Row] = jpLimitedDF
          // 删除宽度异常
          .where("!(limitwidth !='' and limitwidth is not null and width > 2.60)")
          // 删除高度异常
          .where("!(limitsize !='' and limitsize is not null and height > 5)")
          // 删除重量异常
          .where("!(axls_number = '2' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '18')")
          .where("!(axls_number = '3' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '27')")
          .where("!(axls_number = '4' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '37')")
          .where("!(axls_number = '5' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '43')")
          .where("!(axls_number = '6' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '49')")
          // 删除轴重异常
          .where("!(axls_number = '2' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '18')")
          .where("!(axls_number = '3' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '27')")
          .where("!(axls_number = '4' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '37')")
          .where("!(axls_number = '5' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '43')")
          .where("!(axls_number = '6' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '49')")
          // 删除轴数异常
          .where("!(axls_number = '4' and limitaxcnt !='' and limitaxcnt is not null and vehicle_type in (5,6,7))")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpLimitedAfterDealDF, "【纠偏数据】剔除异常数据之后的闯行数据")

        // 1.5 做 匹配异常处理
        val jpLimitedMatchedDealDF: DataFrame = jpLimitedAfterDealDF
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val rulepos: String = r.getAs[String]("rulepos")
              val coords: String = r.getAs[String]("coords")
              val city: String = r.getAs[String]("city")
              val version: String = r.getAs[String]("version")
              val inc_day: String = r.getAs[String]("inc_day")
              val coordsArr: Array[String] = coords
                .replaceAll("\"", "")
                .replaceAll("\\[", "")
                .replaceAll("],", "|")
                .replaceAll("]", "")
                .replaceAll(" ", "")
                .split("\\|")

              var min_dist: Double = 0.0
              try {
                  for (i <- 0 to coordsArr.length - 2) {
                      val dist: Double = getPoint2LinkDist(rulepos, coordsArr(i), coordsArr(i + 1))
                      if (i == 0) min_dist = dist
                      if (min_dist >= dist) min_dist = dist
                  }
              } catch {
                  case e: Exception => logger.error("出错了" + e.getMessage)
              }


              var mark_dist: Int = 0
              if (min_dist > dist) mark_dist = 1
              (uuid, rulepos, mark_dist, min_dist, city, version, inc_day)
          })
          .toDF("uuid", "rulepos", "mark_dist", "min_dist", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpLimitedMatchedDealDF, "【纠偏数据】匹配异常的数据")

        // 1.6 关联上原始数据
        val jpLimitedResultDF: DataFrame = jpLimitedAfterDealDF
          .drop("version", "inc_day", "city")
          .join(jpLimitedMatchedDealDF, Seq("uuid", "rulepos"))
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpLimitedResultDF, "【纠偏数据】最终的数据")

        // 1.7 纠偏的数据写入hive
        df2HiveByOverwrite(logger, jpLimitedResultDF, "dm_gis.mms_car_route_jp_detail_and_limited_info_his")
        // 1.8 释放纠偏的缓存
        jpLimitedDF.unpersist()
        jpLimitedAfterDealDF.unpersist()
        jpLimitedMatchedDealDF.unpersist()
        jpLimitedResultDF.unpersist()


        logger.error("<================ 规划的数据进行车参异常剔除和匹配异常处理 ================>")

        // 规划的数据 做车参异常处理逻辑
        // 2.1 规划获取到的闯行数据
        val palnLimitedDataSQL: String =
        s"""
           |select
           |  *
           |from
           |  dm_gis.mms_car_route_plan_detail_and_limited_info
           |where
           |  inc_day = '$inc_day'
           |""".stripMargin

        logger.error(palnLimitedDataSQL)

        // 2.2 获取规划的数据
        val planLimitedDF: DataFrame = spark.sql(palnLimitedDataSQL)
          .drop("rmultipathpos", "rmultipathswid")
          .repartition(600)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 2.3 规划的数据源
        GetDFCountAndSampleData(logger, planLimitedDF, "规划的数据")

        // 2.4 删除规划数据里 车参异常的数据
        val planLimitedAfterDealDF: Dataset[Row] = planLimitedDF
          // 删除宽度异常
          .where("!(limitwidth !='' and limitwidth is not null and width > 2.60)")
          // 删除高度异常
          .where("!(limitsize !='' and limitsize is not null and height > 5)")
          // 删除重量异常
          .where("!(axls_number = '2' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '18')")
          .where("!(axls_number = '3' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '27')")
          .where("!(axls_number = '4' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '37')")
          .where("!(axls_number = '5' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '43')")
          .where("!(axls_number = '6' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '49')")
          // 删除轴重异常
          .where("!(axls_number = '2' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '18')")
          .where("!(axls_number = '3' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '27')")
          .where("!(axls_number = '4' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '37')")
          .where("!(axls_number = '5' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '43')")
          .where("!(axls_number = '6' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '49')")
          // 删除轴数异常
          .where("!(axls_number = '4' and limitaxcnt !='' and limitaxcnt is not null and vehicle_type in (5,6,7))")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedAfterDealDF, "【规划数据】剔除异常数据之后的闯行数据")

        // 2.5 规划的数据 做匹配异常处理
        val planLimitedMatchedDealDF: DataFrame = planLimitedAfterDealDF
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val data_source: String = r.getAs[String]("data_source")
              val d_plan_order: Int = r.getAs[Int]("d_plan_order")
              val rulepos: String = r.getAs[String]("rulepos")
              val coords: String = r.getAs[String]("coords")
              val city: String = r.getAs[String]("city")
              val version: String = r.getAs[String]("version")
              val inc_day: String = r.getAs[String]("inc_day")
              val coordsArr: Array[String] = coords
                .replaceAll("\"", "")
                .replaceAll("\\[", "")
                .replaceAll("],", "|")
                .replaceAll("]", "")
                .replaceAll(" ", "")
                .split("\\|")

              var min_dist: Double = 0.0
              try {
                  for (i <- 0 to coordsArr.length - 2) {
                      val dist: Double = getPoint2LinkDist(rulepos, coordsArr(i), coordsArr(i + 1))
                      if (i == 0) min_dist = dist
                      if (min_dist >= dist) min_dist = dist
                  }
              } catch {
                  case e: Exception => logger.error("出错了" + e.getMessage)
              }

              var mark_dist: Int = 0
              if (min_dist > dist) mark_dist = 1
              (uuid, data_source, d_plan_order, rulepos, mark_dist, min_dist, city, version, inc_day)
          })
          .toDF("uuid", "data_source", "d_plan_order", "rulepos", "mark_dist", "min_dist", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedMatchedDealDF, "【规划数据】匹配异常的数据")

        // 2.6 关联上原始数据
        val planLimitedResultDF: DataFrame = planLimitedAfterDealDF
          .drop("version", "inc_day", "city")
          .join(planLimitedMatchedDealDF, Seq("uuid", "data_source", "d_plan_order", "rulepos"))
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedResultDF, "【规划的数据】最终的数据")

        //2.7 规划的数据写入hive
        df2HiveByOverwrite(logger, planLimitedResultDF, "dm_gis.mms_car_route_plan_detail_and_limited_info_his")

        // 释放纠偏的缓存
        planLimitedDF.unpersist()
        planLimitedAfterDealDF.unpersist()
        planLimitedMatchedDealDF.unpersist()
        planLimitedResultDF.unpersist()
    }


    // 调用匹配的接口
    def call_match_service(r: Row): (String, String, Int, String, JSONObject) = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = r.getAs[Int]("d_plan_order")
        val rulepos: String = r.getAs[String]("rulepos")
        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
          .replaceAll(" ", "")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val vehicle: Int = r.getAs[Int]("vehicle_type")
        val Mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val width: Double = r.getAs[Double]("width")
        val Size: String = r.getAs[String]("vehicle_length")
        val axlenumber: String = r.getAs[String]("axls_number")
        val date: String = r.getAs[String]("plandate")

        val parm: String = s"points=$coords&test=1&stype=0&etype=0&plate=&axleweight=" +
          s"&plateColor=&weight=$weight&vehicle=$vehicle&Mload=$Mload" +
          s"&height=$height&width=$width&Size=$Size&axlenumber=$axlenumber&passport=100000&mode=2&speed=1" +
          s"&No=$uuid&Toll=1&date=$date"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)

        var json: JSONObject = null

        try {
            val jsonStr: String = mapData.get("content").toString
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }

        (uuid, data_source, d_plan_order, rulepos, json)
    }

    // 解析匹配接口返回的json,获取相应的字段值和逻辑处理
    def get_match_abnormal_data(uuid: String, data_source: String, d_plan_order: Int, rulepos: String, js: JSONObject): (String, String, Int, String, String, String, String, String, String, Int, Double, Int, Int, Int, Int, Int, String, String) = {
        // 存放每个step 下的link字段
        val stepLinkBuff = new ListBuffer[(String, String, String, String, String, String, String, String)]
        // 存放每个outinfo 下的link字段
        val OutinfoLinkBuff = new ListBuffer[(String, String, String, String)]

        var flen: String = ""
        var tlen: String = ""
        var distance: Int = 0
        var duration: Double = 0.0
        var highspeed_distance: Int = 0
        var trafficlight_count: Int = 0
        var tolls: Int = 0
        var etc_toll: Int = 0
        var toll_distance: Int = 0
        var origin: String = ""
        var destination: String = ""
        var rc_distance: String = ""

        if (js != null) {
            val status: String = js.getString("status")
            if (status == "0") {
                origin = js.getString("origin")
                destination = js.getString("destination")
                val route: JSONObject = js.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")
                val rc_distance_buff: ListBuffer[Int] = ListBuffer(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

                if (paths != null && paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val path: JSONObject = paths.getJSONObject(i)

                        if (i == 0) flen = path.getString("flen")
                        if (i == paths.size() - 1) tlen = path.getString("tlen")

                        distance += path.getInteger("distance")
                        duration += path.getDouble("duration")
                        highspeed_distance += path.getInteger("highspeed_distance")
                        trafficlight_count += path.getInteger("trafficlight_count")
                        tolls += path.getInteger("tolls")
                        etc_toll += path.getInteger("etc_toll")
                        toll_distance += path.getInteger("toll_distance")

                        val rc_distance: JSONArray = path.getJSONArray("rc_distance")
                        for (ii <- 0 to 10) rc_distance_buff(ii) = rc_distance_buff(ii) + rc_distance.getInteger(ii)

                        val steps: JSONArray = path.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            for (j <- 0 until steps.size()) {
                                val step: JSONObject = steps.getJSONObject(j)
                                if (step != null && step.size() > 0) {
                                    val links: JSONArray = step.getJSONArray("links")
                                    if (links != null && links.size() > 0) {
                                        for (i <- 0 until links.size()) {
                                            val link: JSONObject = links.getJSONObject(i)
                                            val sw_id: String = link.getString("sw_id")
                                            val id: String = link.getString("id")
                                            val name: String = link.getString("name")
                                            val formway: String = link.getString("formway")
                                            val roadclass: String = link.getString("roadclass")
                                            val coorindex: String = link.getString("coorindex")
                                            val pointnum: String = link.getString("pointnum")
                                            val dr_length: String = link.getString("dr_length")
                                            stepLinkBuff.append((sw_id, id, name, formway, roadclass, coorindex, pointnum, dr_length))
                                        }
                                    }
                                }
                            }
                        }

                        val outinfo: JSONObject = path.getJSONObject("outinfo")
                        if (outinfo != null && outinfo.size() > 0) {
                            val links: JSONArray = outinfo.getJSONArray("links")
                            if (links != null && links.size() > 0) {
                                for (j <- 0 until links.size()) {
                                    val link: JSONObject = links.getJSONObject(j)
                                    val lnk_type: String = link.getString("lnk_type")
                                    val mainaction: String = link.getString("mainaction")
                                    val ownership: String = link.getString("ownership")
                                    val dir: String = link.getString("dir")
                                    OutinfoLinkBuff.append((lnk_type, mainaction, ownership, dir))
                                }
                            }
                        }

                    }
                }

                rc_distance = rc_distance_buff.mkString(",")

                val n: Int = math.min(stepLinkBuff.size, OutinfoLinkBuff.size)
                val listBuff: ListBuffer[String] = new ListBuffer[String]
                if (n > 0) {
                    for (i <- 0 until n) {
                        listBuff.append(
                            s"${stepLinkBuff(i)._1},${stepLinkBuff(i)._2},${stepLinkBuff(i)._3},${stepLinkBuff(i)._4}," +
                              s"${stepLinkBuff(i)._5},${stepLinkBuff(i)._6},${stepLinkBuff(i)._7},${stepLinkBuff(i)._8}," +
                              s"${OutinfoLinkBuff(i)._1},${OutinfoLinkBuff(i)._2},${OutinfoLinkBuff(i)._3},${OutinfoLinkBuff(i)._4}"
                        )
                    }
                    val link_union: String = listBuff.mkString("|")
                    (uuid, data_source, d_plan_order, rulepos, status, origin, destination, flen, tlen, distance, duration, highspeed_distance, trafficlight_count,
                      tolls, etc_toll, toll_distance, link_union, rc_distance)
                } else {
                    (uuid, data_source, d_plan_order, rulepos, status, origin, destination, flen, tlen, distance, duration, highspeed_distance, trafficlight_count,
                      tolls, etc_toll, toll_distance, "", "")
                }

            } else {
                (uuid, data_source, d_plan_order, rulepos, status, origin, destination, flen, tlen, distance, duration, highspeed_distance, trafficlight_count,
                  tolls, etc_toll, toll_distance, "", "")
            }
        } else {
            (uuid, data_source, d_plan_order, rulepos, "", origin, destination, flen, tlen, distance, duration, highspeed_distance, trafficlight_count,
              tolls, etc_toll, toll_distance, "", "")
        }

    }

    // 调用纠偏异常接口
    def call_jpyc_service(r: Row, check_option: Int): JSONObject = {
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = r.getAs[Int]("d_plan_order")
        val lineid: String = uuid + "_" + data_source + "_" + d_plan_order

        val r_links_union: String = r.getAs[String]("r_links_union")
        val vehicle_type: Int = r.getAs[Int]("vehicle_type")
        val vehicle: String = ""
        val ft_coords: String = r.getAs[String]("coords")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val axle_weight: String = ""
        val length: String = r.getAs[String]("vehicle_length")
        val width: Double = r.getAs[Double]("width")
        val plate_color: String = ""

        var req_time: String = ""
        val start_tm: String = r.getAs[String]("start_tm")
        if (start_tm != null && start_tm.nonEmpty) {
            val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            req_time = fm.parse(start_tm).getTime.toString
        }

        val turn_bypass_ratio_limit: Double = 1.5
        val sennior_primary_road_ratio_limit: Double = 1.2

        val parms: JSONObject = new JSONObject()

        parms.put("lineid", lineid)
        parms.put("links_union", r_links_union)
        parms.put("vehicle_type", vehicle_type)
        parms.put("vehicle", vehicle)
        parms.put("ft_coords", ft_coords)
        parms.put("weight", weight)
        parms.put("mload", mload)
        parms.put("height", height)
        parms.put("axle_weight", axle_weight)
        parms.put("length", length)
        parms.put("width", width)
        parms.put("plate_color", plate_color)
        parms.put("axle_weight", axle_weight)
        parms.put("check_option", check_option)
        parms.put("req_time", req_time)
        parms.put("turn_bypass_ratio_limit", turn_bypass_ratio_limit)
        parms.put("sennior_primary_road_ratio_limit", sennior_primary_road_ratio_limit)

        //        val jsonStr: String = httpPost(3, jpyc_url, parms.toJSONString)
        val jsonStr: String = ""
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }
        json
    }

    // 解析纠偏异常接口返回的json,获取相应的字段值和逻辑处理
    def get_jpyc_data(js: JSONObject): ListBuffer[(String, String, String, String, String, String, String, String, String)] = {
        val myList = new ListBuffer[(String, String, String, String, String, String, String, String, String)]
        if (js != null) {
            val ret: Integer = js.getInteger("ret")
            if (ret == 0) {
                val bypassResult: JSONArray = js.getJSONArray("bypassResult")
                if (bypassResult != null && bypassResult.size() > 0) {
                    for (i <- 0 until bypassResult.size()) {
                        val obj: JSONObject = bypassResult.getJSONObject(i)
                        val angle: String = obj.getString("angle")
                        val existlimit: String = obj.getString("existlimit")
                        val lineid: String = obj.getString("lineid")
                        val linkid: String = obj.getString("linkid")
                        val mark_jp: String = obj.getString("mark")
                        val originroadclasslist: String = obj.getString("originroadclasslist")
                        val srcIdfrom: String = obj.getString("srcIdfrom")
                        val srcid: String = obj.getString("srcid")

                        val mynew: String = lineid + "_" + srcIdfrom
                        myList.append((mynew, angle, existlimit, lineid, linkid, mark_jp, originroadclasslist, srcIdfrom, srcid))
                    }
                }
            }

        }
        myList

    }

    // 规划的数据进行纠偏异常处理
    def planJPAbnormalDeal(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 获取规划的闯行数据
        val planLimitedlDataSQL: String =
            s"""
               |select
               |  concat(uuid,'_', data_source,'_', d_plan_order,'_',ruleroadid) as mynew,
               |  *
               |from
               |  dm_gis.mms_car_route_plan_detail_and_limited_info_his
               |where
               |  inc_day = '$inc_day'
               |  and data_source = '3'
               |""".stripMargin
        logger.error("规划的闯行数据：" + planLimitedlDataSQL)

        val planLimitedlDataDF: DataFrame = spark.sql(planLimitedlDataSQL).dropDuplicates("uuid", "data_source", "d_plan_order", "rulepos")

        val planLimitedlMatchedResultDataDF: DataFrame = planLimitedlDataDF
          .repartition(20)
          .map(r => {
              val (uuid, data_source, d_plan_order, rulepos, json) = call_match_service(r)
              val tp: (String, String, Int, String, String, String, String, String, String, Int, Double, Int, Int, Int, Int, Int, String, String) = get_match_abnormal_data(uuid, data_source, d_plan_order, rulepos, json)
              tp
          })
          .toDF("uuid", "data_source", "d_plan_order", "rulepos", "r_status", "r_origin", "r_destination",
              "r_flen", "r_tlen", "r_distance", "r_duration", "r_highspeed_distance", "r_trafficlight_count",
              "r_tolls", "r_etc_toll", "r_toll_distance", "r_links_union", "r_rc_distance")
          .join(planLimitedlDataDF, Seq("uuid", "data_source", "d_plan_order", "rulepos"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedlMatchedResultDataDF, "规划的闯行数据,调用匹配服务之后的最终数据")


        val planLimitedlJPYCResultDataDF: DataFrame = planLimitedlMatchedResultDataDF
          .flatMap(r => {
              val arr: Array[Int] = Array(8, 81, 128, 130)
              val buff: ListBuffer[ListBuffer[(String, String, String, String, String, String, String, String, String)]] = new ListBuffer[ListBuffer[(String, String, String, String, String, String, String, String, String)]]
              for (elem <- arr) {
                  val json: JSONObject = call_jpyc_service(r, elem)
                  val myList: ListBuffer[(String, String, String, String, String, String, String, String, String)] = get_jpyc_data(json)
                  buff.append(myList)
              }

              val flattenBuff: ListBuffer[(String, String, String, String, String, String, String, String, String)] = buff.flatten
              flattenBuff
          })
          .repartition(200)
          .toDF("mynew", "angle", "existlimit", "lineid", "linkid", "mark_jp", "originroadclasslist", "srcIdfrom", "srcid")
          .dropDuplicates("mynew")
          .join(planLimitedlMatchedResultDataDF, Seq("mynew"), "right")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedlJPYCResultDataDF, "规划的数据，跑纠偏异常服务之后的数据")

        // 1.7 规划的数据  最终的数据 写入hive
        df2HiveByOverwrite(logger, planLimitedlJPYCResultDataDF, "dm_gis.mms_car_route_plan_detail_and_limited_info_his2")
        planLimitedlMatchedResultDataDF.unpersist()
        planLimitedlJPYCResultDataDF.unpersist()
    }

    // 纠偏的数据进行纠偏异常处理
    def jpJPAbnormalDeal(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 获取纠偏的闯行数据
        val JPLimitedDataSQL: String =
            s"""
               |select
               |  concat(uuid,'_', data_source,'_', 0,'_',ruleroadid) as mynew,
               |  0 as d_plan_order,
               |  *
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info_his
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin
        logger.error("纠偏的闯行数据：" + JPLimitedDataSQL)

        val JPLimitedDataDF: DataFrame = spark.sql(JPLimitedDataSQL).dropDuplicates("uuid", "data_source", "rulepos")

        val JPLimitedlMatchedResultDataDF: DataFrame = JPLimitedDataDF
          .repartition(20)
          .map(r => {
              val (uuid, data_source, d_plan_order, rulepos, json) = call_match_service(r)
              val tp: (String, String, Int, String, String, String, String, String, String, Int, Double, Int, Int, Int, Int, Int, String, String) = get_match_abnormal_data(uuid, data_source, d_plan_order, rulepos, json)
              tp
          })
          .toDF("uuid", "data_source", "d_plan_order", "rulepos", "r_status", "r_origin", "r_destination",
              "r_flen", "r_tlen", "r_distance", "r_duration", "r_highspeed_distance", "r_trafficlight_count",
              "r_tolls", "r_etc_toll", "r_toll_distance", "r_links_union", "r_rc_distance")
          .join(JPLimitedDataDF, Seq("uuid", "data_source", "d_plan_order", "rulepos"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, JPLimitedlMatchedResultDataDF, "纠偏的闯行数据，调用匹配服务之后的最终数据")


        // 2.5 纠偏的数据 跑纠偏异常服务
        val JPLimitedlJPYCResultDataDF: DataFrame = JPLimitedlMatchedResultDataDF
          .flatMap(r => {
              val arr: Array[Int] = Array(8, 81, 128, 130)
              val buff: ListBuffer[ListBuffer[(String, String, String, String, String, String, String, String, String)]] = new ListBuffer[ListBuffer[(String, String, String, String, String, String, String, String, String)]]
              for (elem <- arr) {
                  val json: JSONObject = call_jpyc_service(r, elem)
                  val myList: ListBuffer[(String, String, String, String, String, String, String, String, String)] = get_jpyc_data(json)
                  buff.append(myList)
              }

              val flattenBuff: ListBuffer[(String, String, String, String, String, String, String, String, String)] = buff.flatten
              flattenBuff
          })
          .toDF("mynew", "angle", "existlimit", "lineid", "linkid", "mark_jp", "originroadclasslist", "srcIdfrom", "srcid")
          .dropDuplicates("mynew")
          .join(JPLimitedlMatchedResultDataDF, Seq("mynew"), "right")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, JPLimitedlJPYCResultDataDF, "纠偏的数据，跑纠偏异常服务之后的数据")

        // 2.7 纠偏的数据 最终的数据写入hive
        df2HiveByOverwrite(logger, JPLimitedlJPYCResultDataDF, "dm_gis.mms_car_route_jp_detail_and_limited_info_his2")
        JPLimitedlMatchedResultDataDF.unpersist()
        JPLimitedlJPYCResultDataDF.unpersist()
    }

    // 对每一行数据进行标记
    def getDistAndPointAndMark(r: Row): (String, Double, Double, Double, Double, Int, BigDecimal, Double, Double) = {
        val uuid: String = r.getAs[String]("uuid")

        // 定义返回的变量
        var dist: BigDecimal = 0
        var x1: Double = 0.00
        var y1: Double = 0.00
        var x2: Double = 0.00
        var y2: Double = 0.00
        var s_dist: Double = 0.0
        var d_dist: Double = 0.0
        var mark: Int = 0

        val coords: String = r.getAs[String]("coords")
        val rulepos: String = r.getAs[String]("rulepos")
        val jp_swid: String = r.getAs[String]("jp_swid")
        val jp_status: String = r.getAs[String]("jp_status")
        val ruleroadid: String = r.getAs[String]("ruleroadid")

        val coordsArr: Array[String] = coords.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")
          .replaceAll(" ", "")
          .split("\\|")

        val jp_swidArr: Array[String] = jp_swid
          .replaceAll("\\[", "")
          .replaceAll("]", "")
          .split("\\|")

        val jp_statusArr: Array[String] = jp_status
          .replaceAll("\\[", "")
          .replaceAll("]", "")
          .split("\\|")

        // 当前row的限行点的坐标
        var x0: String = rulepos.split(",")(0)
        var y0: String = rulepos.split(",")(1)

        var idx: Int = -1
        var flag: Int = 0

        if (coordsArr.length == jp_swidArr.length && coordsArr.length == jp_statusArr.length) {
            for (i <- coordsArr.indices) {
                val x: String = coordsArr(i).split(",")(0)
                val y: String = coordsArr(i).split(",")(1)

                val swid: String = jp_swidArr(i)

                if (flag == 0) {
                    if (x == x0 && y == y0) {
                        flag = 1
                        idx = i
                    } else if (swid == ruleroadid) {
                        flag = 1
                        idx = i
                        x0 = x
                        y0 = y
                    }
                }


            }
        }


        if (flag == 0) {
            mark = 3
        } else {
            // 限行起点 经纬度
            val lng1: Double = coordsArr(0).split(",")(0).toDouble
            val lat1: Double = coordsArr(0).split(",")(1).toDouble

            // 限行终点 经纬度
            val lng2: Double = coordsArr(coordsArr.length - 1).split(",")(0).toDouble
            val lat2: Double = coordsArr(coordsArr.length - 1).split(",")(1).toDouble

            // 计算2点间的距离
            s_dist = get_distance2(lng1, lat1, x0.toDouble, y0.toDouble) * 1000
            d_dist = get_distance2(lng2, lat2, x0.toDouble, y0.toDouble) * 1000

            // 判断起点 或 终点 是否在阀值范围
            if (s_dist <= 200) {
                mark = 1
            } else if (d_dist <= 200) {
                mark = 2
            } else if (mark == 0) {
                if (jp_statusArr(idx) != "0") {
                    if (jp_statusArr(idx) == "100") {
                        mark = 100
                    } else {
                        val jp_statusArrSlice1: Array[String] = jp_statusArr.slice(0, idx)
                        val jp_statusArrSlice2: Array[String] = jp_statusArr.slice(idx, jp_statusArr.length + 1)

                        val idex1: Int = jp_statusArrSlice1.lastIndexOf("0")
                        val idex2: Int = jp_statusArrSlice2.indexOf("0") + idx

                        val start_point: String = coordsArr(idex1)
                        val end_point: String = coordsArr(idex2)

                        x1 = start_point.split(",")(0).toDouble
                        y1 = start_point.split(",")(1).toDouble
                        x2 = end_point.split(",")(0).toDouble
                        y2 = end_point.split(",")(1).toDouble

                        // 计算2点间的距离
                        dist = get_distance2(x1, y1, x2, y2) * 1000
                        if (dist >= 4000) mark = 6
                    }

                }
            }


        }
        (uuid, x1, y1, x2, y2, mark, dist, s_dist, d_dist)
    }

    // 根据经纬度，计算2点之间的距离 返回值的单位：km
    def get_distance2(longitude1: Double, latitude1: Double, longitude2: Double, latitude2: Double): Double = { // 纬度
        val R = 6371.00

        val lat1: Double = Math.toRadians(latitude1)
        val lat2: Double = Math.toRadians(latitude2)
        // 经度
        val lng1: Double = Math.toRadians(longitude1)
        val lng2: Double = Math.toRadians(longitude2)
        // 纬度之差
        val a: Double = lat1 - lat2
        // 经度之差
        val b: Double = lng1 - lng2
        // 计算两点距离的公式
        var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(b / 2), 2)))
        // 弧长乘地球半径, 返回单位: 千米
        s = s * R
        s
    }

    // 调用 传统规划2 ，获取相应的数据
    def call_ct2_service(r: Row): ListBuffer[String] = {

        val uuid: String = r.getAs[String]("uuid")
        val rulepos: String = r.getAs[String]("rulepos")
        val axleNumber: String = r.getAs[String]("axleNumber")
        val x1: String = r.getAs[Double]("x1").toString
        val y1: String = r.getAs[Double]("y1").toString
        val x2: String = r.getAs[Double]("x2").toString
        val y2: String = r.getAs[Double]("y2").toString

        val s_dist: String = r.getAs[Double]("s_dist").toString
        val d_dist: String = r.getAs[Double]("d_dist").toString

        val xy: String = x1 + ";;" + y1 + ";;" + x2 + ";;" + y2

        val vehicle: Int = r.getAs[Int]("vehicle")
        val planDate: String = r.getAs[String]("plandate")
        val weight: String = r.getAs[String]("vehicle_full_load_weight")
        val mload: Double = r.getAs[Double]("vehicle_load_weight")
        val height: Double = r.getAs[Double]("height")
        val plate: String = r.getAs[String]("vehicle_serial")
        val plateColor: String = r.getAs[String]("color")
        val width: Double = r.getAs[Double]("width")
        val size: String = r.getAs[String]("vehicle_length")
        val energy: String = r.getAs[String]("energy")
        val emitStand: String = r.getAs[String]("emission")

        val mark: Int = r.getAs[Int]("mark")

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("vehicle", vehicle)
        parMap.put("weight", weight)
        parMap.put("mload", mload)
        parMap.put("height", height)
        parMap.put("axleNumber", axleNumber)
        parMap.put("plate", plate)
        parMap.put("plateColor", plateColor)
        parMap.put("energy", energy)
        parMap.put("width", width)
        parMap.put("size", size)
        parMap.put("planDate", planDate)
        parMap.put("emitStand", emitStand)
        parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

        val url: String = ct2_url + map2String(parMap)


        val jsonData: JSONObject = getJsonByGet(url, 3, "utf-8")

        // 存放每个轨迹的数据，可能返回2条轨迹，也可能返回3条轨迹
        val uuid_and_jyrt_links_union: ListBuffer[String] = new ListBuffer[String]

        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")
                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    for (i <- 0 until list.size()) {
                        // 存放每个steps → link 下的所有值
                        val stepsLinksBuff: ListBuffer[String] = new ListBuffer[String]

                        val obj: JSONObject = list.getJSONObject(i)

                        val steps: JSONArray = obj.getJSONArray("steps")
                        for (j <- 0 until steps.size()) {
                            val step: JSONObject = steps.getJSONObject(j)
                            val links: JSONArray = step.getJSONArray("links")
                            for (k <- 0 until links.size()) {
                                val link: JSONObject = links.getJSONObject(k)
                                val uid: String = link.getString("uid")
                                stepsLinksBuff.append(uid)
                            }
                        }

                        val links_union: String = stepsLinksBuff.mkString("|")
                        uuid_and_jyrt_links_union.append(uuid + ";;" + mark + ";;" + rulepos + ";;" + links_union + ";;" + xy + ";;" + s_dist + ";;" + d_dist + ";;" + url)
                    }
                } else {
                    uuid_and_jyrt_links_union.append(uuid + ";;" + mark + ";;" + rulepos + ";;" + "" + ";;" + xy + ";;" + s_dist + ";;" + d_dist + ";;" + url)
                }
            } else {
                uuid_and_jyrt_links_union.append(uuid + ";;" + mark + ";;" + rulepos + ";;" + "" + ";;" + xy + ";;" + s_dist + ";;" + d_dist + ";;" + url)
            }
        } else {
            uuid_and_jyrt_links_union.append(uuid + ";;" + mark + ";;" + rulepos + ";;" + "" + ";;" + xy + ";;" + s_dist + ";;" + d_dist + ";;" + url)
        }

        uuid_and_jyrt_links_union
    }

    // 获取闯行点 到  2个point 的垂直距离
    // rulepos, firstPoint, secondPoint 都是 经纬度 组成的字符串，通过逗号分隔
    def getPoint2LinkDist(rulepos: String, firstPoint: String, secondPoint: String): Double = {

        val rulepos_x: Double = rulepos.split(",")(0).toDouble
        val rulepos_y: Double = rulepos.split(",")(1).toDouble

        val firstPoint_x: Double = firstPoint.split(",")(0).toDouble
        val firstPoint_y: Double = firstPoint.split(",")(1).toDouble

        val secondPoint_x: Double = secondPoint.split(",")(0).toDouble
        val secondPoint_y: Double = secondPoint.split(",")(1).toDouble

        if (math.abs(firstPoint_x - secondPoint_x) < 0.0000001 && math.abs(firstPoint_y - secondPoint_y) < 0.0000001)
            return getPoint2PointDist(rulepos, firstPoint)

        val va_x: Double = rulepos_x - firstPoint_x
        val va_y: Double = rulepos_y - firstPoint_y

        val vb_x: Double = secondPoint_x - firstPoint_x
        val vb_y: Double = secondPoint_y - firstPoint_y

        val dot: Double = getDot((va_x, va_y), (vb_x, vb_y))
        if (dot < 0) return getPoint2PointDist(rulepos, firstPoint)

        val square: Double = getDot((vb_x, vb_y), (vb_x, vb_y))
        val s: Double = dot / square
        if (s > 1) return getPoint2PointDist(rulepos, secondPoint)

        val middlePoint_x: Double = firstPoint_x + vb_x * s
        val middlePoint_y: Double = firstPoint_y + vb_y * s
        val middlePoint: String = middlePoint_x + "," + middlePoint_y
        getPoint2PointDist(rulepos, middlePoint)
    }

    // 获取2个点之间的最短距离
    def getPoint2PointDist(firstPoint: String, secondPoint: String): Double = {
        val firstPoint_x: Double = firstPoint.split(",")(0).toDouble
        val firstPoint_y: Double = firstPoint.split(",")(1).toDouble

        val secondPoint_x: Double = secondPoint.split(",")(0).toDouble
        val secondPoint_y: Double = secondPoint.split(",")(1).toDouble

        val dx: Double = secondPoint_x - firstPoint_x
        val dy: Double = secondPoint_y - firstPoint_y

        val sx: Double = dx * math.cos(firstPoint_y * 0.01745329252)
        val dist: Double = math.sqrt(sx * sx + dy * dy) * 111195.0
        dist
    }

    def getDot(u: (Double, Double), v: (Double, Double)): Double = {
        u._1 * v._1 + u._2 * v._2
    }

    // 将map转化为string，剔除值为null的数据
    def map2String(parMap: mutable.HashMap[String, Any]): String = {
        for (elem <- parMap)
            if (elem._2 == null) parMap.remove(elem._1)
        val parStr: String = parMap.mkString("&").replaceAll(" -> ", "=")
        parStr
    }


    def leftOuterJoinOfLeftLeanElem1(logger: Logger, left: RDD[(String, Row)], right: RDD[(String, Row)], hashNum: Int, topLean: Int = 50): RDD[(String, (Row, Row))] = {
        val keyCounts: Array[(String, Int)] = left
          .map(obj => (obj._1, 1))
          .reduceByKey(_ + _)
          .sortBy(-_._2)
          .take(topLean)

        val keys: Array[String] = keyCounts.map(obj => obj._1)

        val counts: Int = keyCounts.map(obj => obj._2).sum
        logger.error("单独处理的keys:" + keyCounts.mkString(","))
        logger.error("单独处理的总数量:" + counts)
        //拆分数据为独立处理的key和非独立处理的key
        val leftHashKeyData: RDD[(String, Row)] = left.filter(obj => keys.contains(obj._1))
        val leftOtherData: RDD[(String, Row)] = left.filter(obj => !keys.contains(obj._1))
        val rightHashKeyData: RDD[(String, Row)] = right.filter(obj => keys.contains(obj._1))
        val rightOtherData: RDD[(String, Row)] = right.filter(obj => !keys.contains(obj._1))

        //先关联其他key数据
        val otherJoin: RDD[(String, (Row, Row))] = leftOtherData
          .join(rightOtherData)
          .partitionBy(new myPartiton(1200))

        //        val otherJoin: RDD[(String, (Row, Row))] = otherJoin_tmp
        //          .partitionBy(new RangePartitioner(300, otherJoin_tmp))

        //扩展单独处理的数据
        val leftHashKeyDataExpand: RDD[((Int, String), Row)] = leftHashKeyData.map(obj => {
            val hashPrefix: Int = new Random().nextInt(hashNum)
            ((hashPrefix, obj._1), obj._2)
        })

        val rightHashKeyDataExpand: RDD[((Int, String), Row)] = rightHashKeyData
          .flatMap(obj => {
              val dataArray = new ArrayBuffer[((Int, String), Row)]()
              for (i <- 0 until hashNum) {
                  dataArray.append(((i, obj._1), obj._2))
              }
              dataArray.iterator
          })
        //关联数据
        val hashKeyJoin: RDD[(String, (Row, Row))] = leftHashKeyDataExpand
          .join(rightHashKeyDataExpand)
          .map(obj => (obj._1._2, obj._2))
          .partitionBy(new myPartiton(1200))

        //        val hashKeyJoin: RDD[(String, (Row, Row))] = hashKeyJoin_tmp
        //          .partitionBy(new RangePartitioner(300, hashKeyJoin_tmp))


        hashKeyJoin.union(otherJoin)

    }

    class myPartiton(numParts: Int) extends Partitioner {

        override def numPartitions: Int = numParts

        override def getPartition(key: Any): Int = {
            val i: Int = new Random().nextInt(numParts)
            val str: String = i.toString + key
            var num: Int = str.hashCode % numParts
            num = num + (if (num < 0) numParts else 0)
            num
        }

    }

    def deallocusAbnormalData(spark: SparkSession, inc_day: String): Unit = {
        // 导入隐式转换
        import spark.implicits._

        // 纠偏获取到的闯行数据
        val jpgjLimitedDataSQL: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info_his2
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin

        logger.error(jpgjLimitedDataSQL)

        // 获取纠偏的数据
        val jpgjLimitedDF: DataFrame = spark.sql(jpgjLimitedDataSQL)
          .dropDuplicates("uuid", "rulepos")
          .repartition(1200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 纠偏的数据源
        GetDFCountAndSampleData(logger, jpgjLimitedDF, "纠偏的数据")

        // 纠偏异常的数据，获取对应的点和mark
        val jpgjLimitedAndPointAndMarkDF: DataFrame = jpgjLimitedDF
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val rulepos: String = r.getAs[String]("rulepos")
              val axleNumber: String = r.getAs[String]("axls_number")
              val vehicle: Int = r.getAs[Int]("vehicle_type")
              val plandate: String = r.getAs[String]("plandate")
              val vehicle_full_load_weight: String = r.getAs[String]("vehicle_full_load_weight")
              val vehicle_load_weight: Double = r.getAs[Double]("vehicle_load_weight")
              val height: Double = r.getAs[Double]("height")
              val vehicle_serial: String = r.getAs[String]("vehicle_serial")
              val color: String = r.getAs[String]("color")
              val width: Double = r.getAs[Double]("width")
              val vehicle_length: String = r.getAs[String]("vehicle_length")
              val energy: String = r.getAs[String]("energy")
              val emission: String = r.getAs[String]("emission")
              val tp: (String, Double, Double, Double, Double, Int, BigDecimal, Double, Double) = getDistAndPointAndMark(r)
              (uuid, rulepos, axleNumber, vehicle, plandate, vehicle_full_load_weight, vehicle_load_weight, height, vehicle_serial, color, width, vehicle_length, energy, emission,
                tp._2, tp._3, tp._4, tp._5, tp._6, tp._7, tp._8, tp._9)
          })
          .toDF("uuid", "rulepos", "axleNumber", "vehicle", "plandate", "vehicle_full_load_weight",
              "vehicle_load_weight", "height", "vehicle_serial", "color", "width", "vehicle_length", "energy",
              "emission", "x1", "y1", "x2", "y2", "mark", "dist", "s_dist", "d_dist")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 查看处理过后的纠偏轨迹数据
        GetDFCountAndSampleData(logger, jpgjLimitedAndPointAndMarkDF, "纠偏异常的数据，获取对应的点和mark")

        val jpgjLimitedAndPointAndMarkDFHis: Dataset[Row] = jpgjLimitedAndPointAndMarkDF
          .filter("mark not in (1,2,3,6)")
          .persist(StorageLevel.MEMORY_AND_DISK)

        logger.error(s"[0,4,5]的数据量：${jpgjLimitedAndPointAndMarkDFHis.count()} 条")

        // 不做 cntAndMark 的数据
        val jpgjLimitedAndPointAndMarkDFHis2: Dataset[Row] = jpgjLimitedAndPointAndMarkDF
          .filter("mark in (1,2,3,6)")
          .persist(StorageLevel.MEMORY_AND_DISK)

        logger.error(s"[1,2,3,6]的数据量：${jpgjLimitedAndPointAndMarkDFHis2.count()} 条")


        val jpgjLimitedAndLinks2: DataFrame = jpgjLimitedAndPointAndMarkDFHis2
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val mark: Int = r.getAs[Int]("mark")
              val rulepos: String = r.getAs[String]("rulepos")
              val jyrt_links_union: String = null
              val x1: String = r.getAs[Double]("x1").toString
              val y1: String = r.getAs[Double]("y1").toString
              val x2: String = r.getAs[Double]("x2").toString
              val y2: String = r.getAs[Double]("y2").toString
              val s_dist: String = r.getAs[Double]("s_dist").toString
              val d_dist: String = r.getAs[Double]("d_dist").toString
              val jyrt_url: String = null
              (uuid, mark, rulepos, jyrt_links_union, x1, y1, x2, y2, s_dist, d_dist, jyrt_url)
          })
          .toDF("uuid", "mark", "rulepos", "jyrt_links_union", "x1", "y1", "x2", "y2", "s_dist", "d_dist", "jyrt_url")

        // 纠偏异常的数据和对应的links
        val jpgjLimitedAndLinks: DataFrame = jpgjLimitedAndPointAndMarkDFHis
          .flatMap(r => {
              val listBuff: ListBuffer[String] = call_ct2_service(r)
              listBuff
          })
          .map(r => {
              val uuid: String = r.split(";;")(0)
              val mark: Int = r.split(";;")(1).toInt
              val rulepos: String = r.split(";;")(2)
              val jyrt_links_union: String = r.split(";;")(3)
              val x1: String = r.split(";;")(4)
              val y1: String = r.split(";;")(5)
              val x2: String = r.split(";;")(6)
              val y2: String = r.split(";;")(7)
              val s_dist: String = r.split(";;")(8)
              val d_dist: String = r.split(";;")(9)
              val jyrt_url: String = r.split(";;")(10)
              (uuid, mark, rulepos, jyrt_links_union, x1, y1, x2, y2, s_dist, d_dist, jyrt_url)
          })
          .toDF("uuid", "mark", "rulepos", "jyrt_links_union", "x1", "y1", "x2", "y2", "s_dist", "d_dist", "jyrt_url")


        val jpgjLimitedAndLinksAll: DataFrame = jpgjLimitedAndLinks
          .union(jpgjLimitedAndLinks2)
          .join(jpgjLimitedDF, Seq("uuid", "rulepos"))
          .withColumn("ana_key", concat($"uuid", $"rulepos"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpgjLimitedAndLinksAll, "纠偏异常的数据和对应的links")

        val jpgjLimitedCntMarkAndLinksResultDF: DataFrame = jpgjLimitedAndLinksAll
          .rdd
          .groupBy(r => r.getAs[String]("ana_key"))
          .map(pair => {
              val ana_key: String = pair._1
              val rows: Iterable[Row] = pair._2
              val rows_cnt: Int = rows.size
              val one_row: Row = rows.toList.head

              val uuid: String = one_row.getAs[String]("uuid")
              val rulepos: String = one_row.getAs[String]("rulepos")
              val jyrt_links_union: String = one_row.getAs[String]("jyrt_links_union")
              val x1: String = one_row.getAs[String]("x1")
              val y1: String = one_row.getAs[String]("y1")
              val x2: String = one_row.getAs[String]("x2")
              val y2: String = one_row.getAs[String]("y2")
              val s_dist: String = one_row.getAs[String]("s_dist")
              val d_dist: String = one_row.getAs[String]("d_dist")
              val jyrt_url: String = one_row.getAs[String]("jyrt_url")
              val data_source: String = one_row.getAs[String]("data_source")
              val d_plan_order: Integer = one_row.getAs[Integer]("d_plan_order")
              val mynew: String = one_row.getAs[String]("mynew")
              val angle: String = one_row.getAs[String]("angle")
              val existlimit: String = one_row.getAs[String]("existlimit")
              val lineid: String = one_row.getAs[String]("lineid")
              val linkid: String = one_row.getAs[String]("linkid")
              val mark_jp: String = one_row.getAs[String]("mark_jp")
              val originroadclasslist: String = one_row.getAs[String]("originroadclasslist")
              val srcidfrom: String = one_row.getAs[String]("srcidfrom")
              val srcid: String = one_row.getAs[String]("srcid")
              val r_status: String = one_row.getAs[String]("r_status")
              val r_origin: String = one_row.getAs[String]("r_origin")
              val r_destination: String = one_row.getAs[String]("r_destination")
              val r_flen: String = one_row.getAs[String]("r_flen")
              val r_tlen: String = one_row.getAs[String]("r_tlen")
              val r_distance: Integer = one_row.getAs[Integer]("r_distance")
              val r_duration: Double = one_row.getAs[Double]("r_duration")
              val r_highspeed_distance: Integer = one_row.getAs[Integer]("r_highspeed_distance")
              val r_trafficlight_count: Integer = one_row.getAs[Integer]("r_trafficlight_count")
              val r_tolls: Integer = one_row.getAs[Integer]("r_tolls")
              val r_etc_toll: Integer = one_row.getAs[Integer]("r_etc_toll")
              val r_toll_distance: Integer = one_row.getAs[Integer]("r_toll_distance")
              val r_links_union: String = one_row.getAs[String]("r_links_union")
              val r_rc_distance: String = one_row.getAs[String]("r_rc_distance")
              val task_id: String = one_row.getAs[String]("task_id")
              val start_dept: String = one_row.getAs[String]("start_dept")
              val end_dept: String = one_row.getAs[String]("end_dept")
              val his_coords: String = one_row.getAs[String]("his_coords")
              val start_type: String = one_row.getAs[String]("start_type")
              val end_type: String = one_row.getAs[String]("end_type")
              val start_tm: String = one_row.getAs[String]("start_tm")
              val end_tm: String = one_row.getAs[String]("end_tm")
              val actual_run_time: String = one_row.getAs[String]("actual_run_time")
              val plan_run_time: String = one_row.getAs[String]("plan_run_time")
              val sort_num: String = one_row.getAs[String]("sort_num")
              val start_longitude: String = one_row.getAs[String]("start_longitude")
              val end_longitude: String = one_row.getAs[String]("end_longitude")
              val start_latitude: String = one_row.getAs[String]("start_latitude")
              val end_latitude: String = one_row.getAs[String]("end_latitude")
              val line_code: String = one_row.getAs[String]("line_code")
              val line_id: String = one_row.getAs[String]("line_id")
              val task_area_code: String = one_row.getAs[String]("task_area_code")
              val vehicle_serial: String = one_row.getAs[String]("vehicle_serial")
              val conveyance_type: String = one_row.getAs[String]("conveyance_type")
              val transoport_level: String = one_row.getAs[String]("transoport_level")
              val id: String = one_row.getAs[String]("id")
              val is_stop: String = one_row.getAs[String]("is_stop")
              val ground_task_id: String = one_row.getAs[String]("ground_task_id")
              val start_time: String = one_row.getAs[String]("start_time")
              val carrier_type: String = one_row.getAs[String]("carrier_type")
              val plf_flag: String = one_row.getAs[String]("plf_flag")
              val log_dist: String = one_row.getAs[String]("log_dist")
              val line_distance: String = one_row.getAs[String]("line_distance")
              val vehicle_serial2: String = one_row.getAs[String]("vehicle_serial2")
              val hko_vehicle_code: String = one_row.getAs[String]("hko_vehicle_code")
              val trailer_vehicle_code: String = one_row.getAs[String]("trailer_vehicle_code")
              val source: Integer = one_row.getAs[Integer]("source")
              val is_trailer: String = one_row.getAs[String]("is_trailer")
              val vehicle_type: Integer = one_row.getAs[Integer]("vehicle_type")
              val vehicle_length: String = one_row.getAs[String]("vehicle_length")
              val width: Double = one_row.getAs[Double]("width")
              val height: Double = one_row.getAs[Double]("height")
              val color: String = one_row.getAs[String]("color")
              val energy: String = one_row.getAs[String]("energy")
              val license: String = one_row.getAs[String]("license")
              val emission: String = one_row.getAs[String]("emission")
              val axls_number: String = one_row.getAs[String]("axls_number")
              val vehicle_full_load_weight: String = one_row.getAs[String]("vehicle_full_load_weight")
              val vehicle_load_weight: Double = one_row.getAs[Double]("vehicle_load_weight")
              val line: String = one_row.getAs[String]("line")
              val xy: String = one_row.getAs[String]("xy")
              val order: Integer = one_row.getAs[Integer]("order")
              val grp0: String = one_row.getAs[String]("grp0")
              val grp1: String = one_row.getAs[String]("grp1")
              val grp2: String = one_row.getAs[String]("grp2")
              val plandate: String = one_row.getAs[String]("plandate")
              val grp2_order: Integer = one_row.getAs[Integer]("grp2_order")
              val uuid2: String = one_row.getAs[String]("uuid2")
              val his_abnormal: String = one_row.getAs[String]("his_abnormal")
              val abnormal: String = one_row.getAs[String]("abnormal")
              val coords: String = one_row.getAs[String]("coords")
              val jp_swid: String = one_row.getAs[String]("jp_swid")
              val jp_status: String = one_row.getAs[String]("jp_status")
              val flag: Boolean = one_row.getAs[Boolean]("flag")
              val status: String = one_row.getAs[String]("status")
              val rdist: Integer = one_row.getAs[Integer]("rdist")
              val rtime: Double = one_row.getAs[Double]("rtime")
              val rhighway: Integer = one_row.getAs[Integer]("rhighway")
              val rtralightcount: Integer = one_row.getAs[Integer]("rtralightcount")
              val rtolls: Integer = one_row.getAs[Integer]("rtolls")
              val rtollsdistance: Integer = one_row.getAs[Integer]("rtollsdistance")
              val qstartxy: String = one_row.getAs[String]("qstartxy")
              val qendxy: String = one_row.getAs[String]("qendxy")
              val rcoords: String = one_row.getAs[String]("rcoords")
              val rsteps: String = one_row.getAs[String]("rsteps")
              val rflen: Integer = one_row.getAs[Integer]("rflen")
              val rtlen: Integer = one_row.getAs[Integer]("rtlen")
              val rulecount: Integer = one_row.getAs[Integer]("rulecount")
              val ruleorder: String = one_row.getAs[String]("ruleorder")
              val ruleid: String = one_row.getAs[String]("ruleid")
              val ruletype: String = one_row.getAs[String]("ruletype")
              val ruleroadid: String = one_row.getAs[String]("ruleroadid")
              val ruleoutroadid: String = one_row.getAs[String]("ruleoutroadid")
              val ruleroadname: String = one_row.getAs[String]("ruleroadname")
              val limitweight: String = one_row.getAs[String]("limitweight")
              val limitsize: String = one_row.getAs[String]("limitsize")
              val limitwidth: String = one_row.getAs[String]("limitwidth")
              val limitaxload: String = one_row.getAs[String]("limitaxload")
              val limitload: String = one_row.getAs[String]("limitload")
              val limitaxcnt: String = one_row.getAs[String]("limitaxcnt")
              val limitpassport: String = one_row.getAs[String]("limitpassport")
              val limitholiday: String = one_row.getAs[String]("limitholiday")
              val limitvehicletype: String = one_row.getAs[String]("limitvehicletype")
              val limitoutflag: String = one_row.getAs[String]("limitoutflag")
              val limitemitstand: String = one_row.getAs[String]("limitemitstand")
              val limittailchar: String = one_row.getAs[String]("limittailchar")
              val limitstartdate: String = one_row.getAs[String]("limitstartdate")
              val limitenddate: String = one_row.getAs[String]("limitenddate")
              val limitweek: String = one_row.getAs[String]("limitweek")
              val limittime: String = one_row.getAs[String]("limittime")
              val guid: String = one_row.getAs[String]("guid")
              val ruletimedesc: String = one_row.getAs[String]("ruletimedesc")
              val ruleregiondesc: String = one_row.getAs[String]("ruleregiondesc")
              val rulevehicle: String = one_row.getAs[String]("rulevehicle")
              val rulestrategy: String = one_row.getAs[String]("rulestrategy")
              val mark_dist: Integer = one_row.getAs[Integer]("mark_dist")
              val min_dist: Double = one_row.getAs[Double]("min_dist")
              val city: String = one_row.getAs[String]("city")
              val version: String = one_row.getAs[String]("version")
              val inc_day: String = one_row.getAs[String]("inc_day")

              var cnt: Int = 0

              var matched_jyrt_links_union: String = ""
              for (row <- rows) {
                  val jyrt_links_union: String = row.getAs[String]("jyrt_links_union")
                  val ruleroadid: String = row.getAs[String]("ruleroadid")
                  if (jyrt_links_union != null && jyrt_links_union != "") {
                      val union: Array[String] = jyrt_links_union.split("\\|")
                      var flag: Boolean = true
                      for (i <- union.indices if flag) {
                          if (ruleroadid == union(i)) {
                              matched_jyrt_links_union = matched_jyrt_links_union + jyrt_links_union + ";"
                              cnt += 1
                              flag = false
                          }
                      }
                  }
              }

              var mark: Int = one_row.getAs[Int]("mark")

              if (mark != 1 && mark != 2 && mark != 3 && mark != 6) {
                  if (cnt == 0) {
                      mark = 4
                  } else if (cnt < rows.size) {
                      mark = 5
                  }
              }

              JpgjLimitedAndLinksAll(
                  uuid, ana_key, rulepos, mark, jyrt_links_union, matched_jyrt_links_union, x1, y1, x2, y2, s_dist, d_dist, jyrt_url, mynew, angle, existlimit, lineid, linkid,
                  mark_jp, originroadclasslist, srcidfrom, srcid, data_source, d_plan_order, r_status, r_origin, r_destination, r_flen,
                  r_tlen, r_distance, r_duration, r_highspeed_distance, r_trafficlight_count, r_tolls, r_etc_toll, r_toll_distance, r_links_union,
                  r_rc_distance, task_id, start_dept, end_dept, his_coords, start_type, end_type, start_tm, end_tm, actual_run_time,
                  plan_run_time, sort_num, start_longitude, end_longitude, start_latitude, end_latitude, line_code, line_id, task_area_code,
                  vehicle_serial, conveyance_type, transoport_level, id, is_stop, ground_task_id, start_time, carrier_type, plf_flag,
                  log_dist, line_distance, vehicle_serial2, hko_vehicle_code, trailer_vehicle_code, source, is_trailer, vehicle_type,
                  vehicle_length, width, height, color, energy, license, emission, axls_number, vehicle_full_load_weight, vehicle_load_weight,
                  line, xy, order, grp0, grp1, grp2, plandate, grp2_order, uuid2, his_abnormal, abnormal, coords, jp_swid, jp_status,
                  flag, status, rdist, rtime, rhighway, rtralightcount, rtolls, rtollsdistance, qstartxy, qendxy, rcoords, rsteps,
                  rflen, rtlen, rulecount, ruleorder, ruleid, ruletype, ruleroadid, ruleoutroadid, ruleroadname, limitweight, limitsize,
                  limitwidth, limitaxload, limitload, limitaxcnt, limitpassport, limitholiday, limitvehicletype, limitoutflag, limitemitstand,
                  limittailchar, limitstartdate, limitenddate, limitweek, limittime, guid, ruletimedesc, ruleregiondesc, rulevehicle,
                  rulestrategy, mark_dist, min_dist, rows_cnt, cnt, city, version, inc_day
              )
          })
          .toDF()
          .coalesce(100)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 最终的数据
        GetDFCountAndSampleData(logger, jpgjLimitedCntMarkAndLinksResultDF, "异常数据处理完成之后的最终数据")

        // 最终的数据落表
        df2HiveByOverwrite(logger, jpgjLimitedCntMarkAndLinksResultDF, "dm_gis.mms_car_route_jp_detail_and_limited_info_his3")
        jpgjLimitedDF.unpersist()
        jpgjLimitedAndPointAndMarkDF.unpersist()
        jpgjLimitedAndPointAndMarkDFHis.unpersist()
        jpgjLimitedAndPointAndMarkDFHis2.unpersist()
        jpgjLimitedAndLinksAll.unpersist()
        jpgjLimitedCntMarkAndLinksResultDF.unpersist()

    }

    // 调用 匹配的接口，获取对应的数据
    def callMatchService(ruleroadid: String): JSONObject = {
        val sw_id: String = ruleroadid
        val date: String = ""

        val parm: String = s"date=$date&sw_id=$sw_id&test=1&stype=0&etype=0&passport=100000&mode=2&speed=1&Toll=1"
        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonObj: Object = mapData.get("content")

        var jsonStr: String = null
        if (jsonObj != null) jsonStr = jsonObj.toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }
        json
    }

    // 解析 匹配接口返回的json数据
    def getMatchAbnormalData(json: JSONObject): (String, String) = {
        var adcode: String = ""
        var pline: String = ""
        val polylineList: ListBuffer[String] = new ListBuffer[String]

        if (json != null) {
            val status: String = json.getString("status")
            if (status == "0") {
                val route: JSONObject = json.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")
                if (paths != null && paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val path: JSONObject = paths.getJSONObject(i)

                        val polyline: String = path.getString("polyline")
                        polylineList.append(polyline)

                        val steps: JSONArray = path.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            for (j <- 0 until steps.size()) {
                                val step: JSONObject = steps.getJSONObject(j)
                                if (step != null && step.size() > 0) {
                                    val links: JSONArray = step.getJSONArray("links")
                                    if (links != null && links.size() > 0) {
                                        val link: JSONObject = links.getJSONObject(0)
                                        adcode = link.getString("adcode")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (polylineList != null && polylineList.nonEmpty) pline = polylineList.mkString(";")
        (adcode, pline)
    }

    def getAacodeAndPline: UserDefinedFunction = udf((ruleroadid: String, ruleoutroadid: String, city: String, version: String, inc_day: String) => {

        var adcode: String = ""
        var pline: String = ""
        var pline1: String = ""
        var pline2: String = ""
        if (ruleroadid != null && ruleroadid.nonEmpty) {
            val json: JSONObject = callMatchService(ruleroadid)
            val tp: (String, String) = getMatchAbnormalData(json)
            adcode = tp._1
            pline1 = tp._2
        }

        if (ruleoutroadid != null && ruleoutroadid.nonEmpty) {
            val json: JSONObject = callMatchService(ruleoutroadid)
            val tp: (String, String) = getMatchAbnormalData(json)
            pline2 = tp._2
        }

        if (pline2.nonEmpty) pline = pline1 + ";" + pline2 else pline = pline1
        (adcode, pline, city, version, inc_day)
    })

    def getPlanLimitedData(spark: SparkSession, sql1: String, sql2: String): DataFrame = {
        val df1: DataFrame = spark.sql(sql1)
        val df2: DataFrame = spark.sql(sql2)

        // 【规划的数据】 合并 2份数据
        val df3: Dataset[Row] = df1
          .union(df2)

        // 将规划的数据注册成临时表，进行字段调整，方便后面 和 纠偏的数据合并在一起
        df3.createOrReplaceTempView("mms_car_route_plan_detail_and_limited_info_his2_tmp")
        val origDataSql4: String =
            """
              |--相同的字段：
              |select
              |  uuid,data_source,d_plan_order,rulepos,d_dist,mynew,angle,existlimit,lineid,linkid,mark_jp,
              |  originroadclasslist,srcidfrom,srcid,r_status,r_origin,r_destination,r_flen,r_tlen,r_distance,
              |  r_duration,r_highspeed_distance,r_trafficlight_count,r_tolls,r_etc_toll,r_toll_distance,
              |  r_links_union,r_rc_distance,start_dept,end_dept,his_coords,start_type,end_type,start_tm,
              |  end_tm,actual_run_time,plan_run_time,sort_num,start_longitude,end_longitude,start_latitude,
              |  end_latitude,line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,
              |  id,is_stop,ground_task_id,start_time,carrier_type,plf_flag,log_dist,line_distance,
              |  vehicle_serial2,hko_vehicle_code,trailer_vehicle_code,source,is_trailer,vehicle_type,
              |  vehicle_length,width,height,color,energy,license,emission,axls_number,vehicle_full_load_weight,
              |  vehicle_load_weight,line,xy,`order`,grp0,grp1,grp2,plandate,grp2_order,coords,flag,status,
              |  rdist,rtime,rhighway,rtralightcount,rtolls,rtollsdistance,qstartxy,qendxy,rcoords,rsteps,
              |  rflen,rtlen,rulecount,ruleorder,ruleid,ruletype,ruleroadid,ruleoutroadid,ruleroadname,
              |  limitweight,limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,
              |  limitvehicletype,limitoutflag,limitemitstand,limittailchar,limitstartdate,limitenddate,
              |  limitweek,limittime,guid,ruletimedesc,ruleregiondesc,rulevehicle,rulestrategy,mark_dist,
              |  min_dist,task_id,
              |  -- 新增的字段
              |  '' as ana_key,
              |  -1 as mark,
              |  '' as jyrt_links_union,
              |  '' as matched_jyrt_links_union,
              |  '' as x1,
              |  '' as y1,
              |  '' as x2,
              |  '' as y2,
              |  '' as s_dist,
              |  '' as jyrt_url,
              |  regexp_replace(uuid,'_','') as uuid2,
              |  '' as his_abnormal,
              |  '' as abnormal,
              |  '' as jp_swid,
              |  '' as jp_status,
              |  0 as rows_cnt,
              |  0 as cnt,
              |  -- 相同的的字段
              |  d_url,d_status,d_time,d_tolls,d_src,d_flen,d_tlen,d_query,d_highway,d_tralightcount,
              |  d_frequency,d_frequencycost,d_frequencytype,d_freqratio,d_route_id,d_src_routeids,
              |  city,version,inc_day
              |from
              |  mms_car_route_plan_detail_and_limited_info_his2_tmp
              |""".stripMargin

        val planLimited: DataFrame = getDataFrame(logger, spark, origDataSql4)
        planLimited
    }

    def saveLimitedData2Hive(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 1. 获取 data_source = 1或2 的数据 【规划的数据】
        val sql1: String =
            s"""
               |select
               |  concat(uuid,'_', data_source,'_', d_plan_order,'_',ruleroadid) as mynew,
               |  '' as angle,
               |  '' as existlimit,
               |  '' as lineid,
               |  '' as linkid,
               |  '' as mark_jp,
               |  '' as originroadclasslist,
               |  '' as srcidfrom,
               |  '' as srcid,
               |  uuid,data_source,d_plan_order,rulepos,
               |  '' as r_status,
               |  '' as r_origin,
               |  '' as r_destination,
               |  '' as r_flen,
               |  '' as r_tlen,
               |  0 as r_distance,
               |  0.0 as r_duration,
               |  0 as r_highspeed_distance,
               |  0 as r_trafficlight_count,
               |  0 as r_tolls,
               |  0 as r_etc_toll,
               |  0 as r_toll_distance,
               |  '' as r_links_union,
               |  '' as r_rc_distance,
               |  d_url,d_status,d_dist,d_time,d_tolls,d_src,d_flen,d_tlen,d_query,coords,d_highway,
               |  d_tralightcount,task_id,start_dept,end_dept,his_coords,start_type,end_type,start_tm,
               |  end_tm,actual_run_time,plan_run_time,sort_num,start_longitude,end_longitude,start_latitude,
               |  end_latitude,line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,
               |  id,is_stop,ground_task_id,start_time,carrier_type,plf_flag,log_dist,line_distance,
               |  vehicle_serial2,hko_vehicle_code,trailer_vehicle_code,source,is_trailer,vehicle_type,
               |  vehicle_length,width,height,color,energy,license,emission,axls_number,vehicle_full_load_weight,
               |  vehicle_load_weight,line,xy,`order`,grp0,grp1,grp2,plandate,grp2_order,d_frequency,
               |  d_frequencycost,d_frequencytype,d_freqratio,d_route_id,d_src_routeids,flag,status,rdist,rtime,
               |  rhighway,rtralightcount,rtolls,rtollsdistance,qstartxy,qendxy,rcoords,rsteps,rflen,rtlen,
               |  rulecount,ruleorder,ruleid,ruletype,ruleroadid,ruleoutroadid,ruleroadname,limitweight,
               |  limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,
               |  limitvehicletype,limitoutflag,limitemitstand,limittailchar,limitstartdate,limitenddate,
               |  limitweek,limittime,guid,ruletimedesc,ruleregiondesc,rulevehicle,rulestrategy,mark_dist,
               |  min_dist,city,version,inc_day
               |from dm_gis.mms_car_route_plan_detail_and_limited_info_his
               |  where
               |    data_source in('1','2')
               |    and inc_day = '$inc_day'
               |""".stripMargin

        // 2. 获取data_source = 3 的数据 【规划的数据】
        val sql2: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_detail_and_limited_info_his2
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin

        // 3. 获取纠偏的闯行数据
        val sql3: String =
            s"""
               |--相同的字段：
               |select
               |  uuid,data_source,d_plan_order,rulepos,d_dist,mynew,angle,existlimit,lineid,linkid,mark_jp,
               |  originroadclasslist,srcidfrom,srcid,r_status,r_origin,r_destination,r_flen,r_tlen,r_distance,
               |  r_duration,r_highspeed_distance,r_trafficlight_count,r_tolls,r_etc_toll,r_toll_distance,
               |  r_links_union,r_rc_distance,start_dept,end_dept,his_coords,start_type,end_type,start_tm,
               |  end_tm,actual_run_time,plan_run_time,sort_num,start_longitude,end_longitude,start_latitude,
               |  end_latitude,line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,
               |  id,is_stop,ground_task_id,start_time,carrier_type,plf_flag,log_dist,line_distance,
               |  vehicle_serial2,hko_vehicle_code,trailer_vehicle_code,source,is_trailer,vehicle_type,
               |  vehicle_length,width,height,color,energy,license,emission,axls_number,vehicle_full_load_weight,
               |  vehicle_load_weight,line,xy,`order`,grp0,grp1,grp2,plandate,grp2_order,coords,flag,status,
               |  rdist,rtime,rhighway,rtralightcount,rtolls,rtollsdistance,qstartxy,qendxy,rcoords,rsteps,
               |  rflen,rtlen,rulecount,ruleorder,ruleid,ruletype,ruleroadid,ruleoutroadid,ruleroadname,
               |  limitweight,limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,
               |  limitvehicletype,limitoutflag,limitemitstand,limittailchar,limitstartdate,limitenddate,
               |  limitweek,limittime,guid,ruletimedesc,ruleregiondesc,rulevehicle,rulestrategy,mark_dist,
               |  min_dist,task_id,
               |-- 不同的字段
               |  ana_key,mark,jyrt_links_union,matched_jyrt_links_union,x1,y1,x2,y2,s_dist,jyrt_url,
               |  uuid2,his_abnormal,abnormal,jp_swid,jp_status,rows_cnt,cnt,
               |-- 新增的字段
               |  '' as d_url,
               |  '' as d_status,
               |  '' as d_time,
               |  '' as d_tolls,
               |  '' as d_src,
               |  '' as d_flen,
               |  '' as d_tlen,
               |  '' as d_query,
               |  '' as d_highway,
               |  '' as d_tralightcount,
               |  '' as d_frequency,
               |  '' as d_frequencycost,
               |  '' as d_frequencytype,
               |  '' as d_freqratio,
               |  '' as d_route_id,
               |  '' as d_src_routeids,
               |  city,version,inc_day
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info_his3
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin

        // 获取规划的数据
        val planLimitedDS2: DataFrame = getPlanLimitedData(spark, sql1, sql2)

        // 获取纠偏的数据
        val jpLimitedDF: DataFrame = getDataFrame(logger, spark, sql3)

        val allLimitedAndAdcodePlineDF: DataFrame = planLimitedDS2
          .union(jpLimitedDF)
          .repartition(10)
          .withColumn("ap", getAacodeAndPline($"ruleroadid", $"ruleoutroadid", $"city", $"version", $"inc_day"))
          .drop("city", "version", "inc_day")
          .withColumn("adcode", $"ap._1")
          .withColumn("pline", $"ap._2")
          .withColumn("city", $"ap._3")
          .withColumn("version", $"ap._4")
          .withColumn("inc_day", $"ap._5")
          .drop("ap")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, allLimitedAndAdcodePlineDF, "调用接口过后最终的数据")

        // 所有的闯行数据 写入hive
        df2HiveByOverwrite(logger, allLimitedAndAdcodePlineDF, "dm_gis.mms_car_route_plan_and_jp_limited_result_info")

        planLimitedDS2.unpersist()
        jpLimitedDF.unpersist()
        allLimitedAndAdcodePlineDF.unpersist()
    }

    // 调用线路匹配的接口
    def call_match_route(r: Row): JSONObject = {

        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")

        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&date=$date&test=1&stype=0&etype=0&passport=100000&mode=2&speed=1&Toll=1"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonStr: String = mapData.get("content").toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }

        json
    }

    // 解析匹配接口返回的json,获取相应的字段值和逻辑处理
    def get_match_data(js: JSONObject): ListBuffer[String] = {
        val isbuilding_swid: ListBuffer[String] = new ListBuffer[String]

        if (js != null) {
            val status: String = js.getString("status")
            if (status == "0") {
                val route: JSONObject = js.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")
                if (paths != null && paths.size() > 0) {
                    val pathsLen: Int = paths.size()
                    for (i <- 0 until pathsLen) {
                        val path: JSONObject = paths.getJSONObject(i)
                        val outinfo: JSONObject = path.getJSONObject("outinfo")
                        if (outinfo != null && outinfo.size() > 0) {
                            val links: JSONArray = outinfo.getJSONArray("links")
                            if (links != null && links.size() > 0) {
                                val linksLen: Int = links.size()
                                for (i <- 0 until linksLen) {
                                    val link: JSONObject = links.getJSONObject(i)
                                    if (link.containsKey("isbuilding") && link.getString("isbuilding") == "1") isbuilding_swid.append(link.getString("swid"))
                                }
                            }
                        }

                    }


                }

            }
        }

        isbuilding_swid
    }

    // 调用road_attr接口
    def call_road_attr_inter(swid: String): JSONObject = {
        val sd: String = "swId=" + swid
        val url: String = road_attr_url + sd
        val jsonData: JSONObject = getJsonByGet(url = url, 6, "utf-8")
        jsonData
    }

    // 解析road_attr接口返回的json
    def get_road_attr_data(js: JSONObject): ListBuffer[String] = {
        var xy_listBuff: ListBuffer[String] = new ListBuffer[String]

        val line: JSONObject = js.getJSONObject("line")
        if (line != null && line.size() > 0) {
            val polyline: JSONArray = line.getJSONArray("polyline")
            if (!polyline.isEmpty) {
                val tp: ListBuffer[(Int, Int)] = new ListBuffer[(Int, Int)]
                for (i <- 0 until polyline.size()) {
                    if (i == 0) {
                        val x: Int = polyline.getJSONObject(i).getIntValue("x")
                        val y: Int = polyline.getJSONObject(i).getIntValue("y")
                        tp.append((x, y))
                    } else {
                        val x1: Int = polyline.getJSONObject(i).getIntValue("x")
                        val y1: Int = polyline.getJSONObject(i).getIntValue("y")

                        val x2: Int = tp(i - 1)._1
                        val y2: Int = tp(i - 1)._2

                        tp.append((x1 + x2, y1 + y2))
                    }

                }
                xy_listBuff = tp.map(r => (r._1 / 3600000.00).formatted("%.6f") + "," + (r._2 / 3600000.00).formatted("%.6f"))
            }


        }

        xy_listBuff
    }

    def get_road_attr_data2(js: JSONObject): (Double, Double, Double, Double) = {

        var startpos_x: Double = 0.00
        var startpos_y: Double = 0.00
        var endpos_x: Double = 0.00
        var endpos_y: Double = 0.00

        val line: JSONObject = js.getJSONObject("line")
        if (line != null && line.size() > 0) {

            val startpos: JSONObject = line.getJSONObject("startpos")
            val endpos: JSONObject = line.getJSONObject("endpos")

            startpos_x = startpos.getDoubleValue("x") / 3600000
            startpos_y = startpos.getDoubleValue("y") / 3600000

            endpos_x = endpos.getDoubleValue("x") / 3600000
            endpos_y = endpos.getDoubleValue("y") / 3600000
        }

        (startpos_x, startpos_y, endpos_x, endpos_y)
    }

    //对多行数据按swid进行排序
    def get_ordered_rows(rowsList: List[Row]): ListBuffer[Row] = {
        val ruleroadid_index_listBuff = new ListBuffer[(Int, Row)]
        for (r <- rowsList) {
            val ruleroadid: String = r.getAs[String]("ruleroadid")
            val isbuilding_swid_arr: Array[String] = r.getAs[String]("isbuilding_swid").split("\\|")
            val i: Int = isbuilding_swid_arr.indexOf(ruleroadid)
            ruleroadid_index_listBuff.append((i, r))
        }
        val rows: ListBuffer[Row] = ruleroadid_index_listBuff.sortWith(_._1 < _._1).map(_._2)
        rows
    }

    // 根据 ruleroadid 对 isbuilding_swid 进行切割
    def get_isbuilding_swid: UserDefinedFunction = udf((ruleroadid: String, next_ruleroadid: String, isbuilding_swid: String) => {
        val isbuilding_swid_arr: Array[String] = isbuilding_swid.split("\\|")
        val start_index: Int = isbuilding_swid_arr.indexOf(ruleroadid)

        var swid: String = ""
        if (next_ruleroadid != "-1") {
            val end_index: Int = isbuilding_swid_arr.indexOf(next_ruleroadid)
            swid = isbuilding_swid_arr.slice(start_index, end_index).mkString("|")
        } else {
            swid = isbuilding_swid_arr.slice(start_index, isbuilding_swid_arr.length + 1).mkString("|")
        }

        swid
    })

    // 根据 isbuilding_swid 获取对应的 isbuilding_point
    def get_isbuilding_point: UserDefinedFunction = udf((isbuilding_swid: String) => {
        val isbuilding_swid_arr: Array[String] = isbuilding_swid.split("\\|")

        var isbuilding_point: String = ""
        val isbuilding_point_buff: ListBuffer[String] = new ListBuffer[String]
        for (swid <- isbuilding_swid_arr) {
            val json: JSONObject = call_road_attr_inter(swid)
            val xy_listBuff: ListBuffer[String] = get_road_attr_data(json)
            if (xy_listBuff.nonEmpty) isbuilding_point_buff.append(xy_listBuff.mkString(";"))
        }
        isbuilding_point = isbuilding_point_buff.mkString(";")

        isbuilding_point
    })

    def get_ruleroadid2: UserDefinedFunction = udf((ruleroadid: String, rn: Int, isbuilding_swid: String) => {
        val firtst_swid: String = isbuilding_swid.split("\\|")(0)

        var ruleroadid2: String = ruleroadid
        if (rn == 1 && firtst_swid != ruleroadid) ruleroadid2 = firtst_swid

        ruleroadid2
    })

    //在建任务下发
    def isbuildingIndiccatorData(spark: SparkSession, inc_day: String): Unit = {
        // 导入隐式转换
        import spark.implicits._

        val two_month_ago: String = getdaysBeforeOrAfter(inc_day, -60)
        val current_time: String = getdaysBeforeOrAfter(inc_day, 4)

        // 获取在建的数据
        val isBuildingSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_and_jp_limited_result_info
               |where
               |  inc_day = '$inc_day'
               |  and data_source='0'
               |  and ruletype = '在建'
               |  and mark_dist = 0
               |  and (srcIdfrom = '' or srcIdfrom is null)
               |  and mark in(-1,0,4)
               |  and (d_frequency ='' or cast(d_frequency as int) > 3)
               |  and (limitsize is null or limitsize = '' or cast(limitsize as double) <= 4.2)
               |""".stripMargin

        // 获取近2个月已经下发的数据
        val issuSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_isbuilding_data_issue_info
               |where
               |  inc_day >= '$two_month_ago'
               |  and inc_day <'$inc_day'
               |""".stripMargin

        logger.error(isBuildingSql)
        logger.error(issuSql)

        val isBuildingDF: DataFrame = spark
          .sql(isBuildingSql)
          .persist(StorageLevel.MEMORY_AND_DISK)

        val issuDF: DataFrame = spark
          .sql(issuSql)

        // 获取在建道路数据
        GetDFCountAndSampleData(logger, isBuildingDF, "在建道路")

        // isbuilding_swid 和 轨迹起始点
        val isbuilding_swidDF: DataFrame = isBuildingDF
          .dropDuplicates("rulepos", "ruleroadid")
          .repartition(5)
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val data_source: String = r.getAs[String]("data_source")
              val d_plan_order: Int = r.getAs[Int]("d_plan_order")
              val rulepos: String = r.getAs[String]("rulepos")
              val ruleroadid: String = r.getAs[String]("ruleroadid")
              val start_dept: String = r.getAs[String]("start_dept")
              val end_dept: String = r.getAs[String]("end_dept")
              val adcode: String = r.getAs[String]("adcode")
              val version: String = r.getAs[String]("version")
              val inc_day: String = r.getAs[String]("inc_day")

              val json: JSONObject = call_match_route(r)
              val isbuilding_swid_Buff: ListBuffer[String] = get_match_data(json)

              var isbuilding_swid: String = ""
              if (isbuilding_swid_Buff.nonEmpty) {
                  isbuilding_swid = isbuilding_swid_Buff.mkString("|")
              }

              val j: JSONObject = call_road_attr_inter(ruleroadid)
              val (startpos_x, startpos_y, endpos_x, endpos_y) = get_road_attr_data2(j)

              SwidAndPoint(uuid, data_source, d_plan_order, rulepos, ruleroadid, start_dept, end_dept, isbuilding_swid,
                  startpos_x, startpos_y, endpos_x, endpos_y, adcode, version, inc_day)
          })
          .repartition(200)
          .toDF
          .filter("isbuilding_swid != ''")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 获取在建道路的isbuilding_swid 和 轨迹起始点
        GetDFCountAndSampleData(logger, isbuilding_swidDF, "在建道路的isbuilding_swid 和 轨迹起始点")

        // 按照距离添加groupby_id
        val groupByIdDF1: DataFrame = isbuilding_swidDF
          .rdd
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val data_source: String = r.getAs[String]("data_source")
              val d_plan_order: Int = r.getAs[Int]("d_plan_order")
              ((uuid, data_source, d_plan_order), r)
          })
          .groupByKey()
          .flatMap(r => {
              val (uuid, data_source, d_plan_order) = r._1
              val uid: String = uuid + "_" + data_source + "_" + d_plan_order
              val rowsList: List[Row] = r._2.toList

              var groupby_id: String = uid + "_0"

              val rowsBuff = new ListBuffer[IsBuilding]
              if (rowsList.size >= 2) {
                  val rows: ListBuffer[Row] = get_ordered_rows(rowsList)
                  var num: Int = 0
                  var dist: Double = 0.0
                  for (i <- rows.indices) {
                      val rulepos: String = rows(i).getAs[String]("rulepos")
                      val ruleroadid: String = rows(i).getAs[String]("ruleroadid")
                      val start_dept: String = rows(i).getAs[String]("start_dept")
                      val end_dept: String = rows(i).getAs[String]("end_dept")
                      val isbuilding_swid: String = rows(i).getAs[String]("isbuilding_swid")
                      val adcode: String = rows(i).getAs[String]("adcode")
                      val version: String = rows(i).getAs[String]("version")
                      val inc_day: String = rows(i).getAs[String]("inc_day")

                      // 第1个点的起始坐标
                      val startpos_x: Double = rows(i).getAs[Double]("startpos_x")
                      val startpos_y: Double = rows(i).getAs[Double]("startpos_y")
                      val endpos_x: Double = rows(i).getAs[Double]("endpos_x")
                      val endpos_y: Double = rows(i).getAs[Double]("endpos_y")

                      if (i < rows.size - 1) {
                          // 第2个点的起始坐标
                          val startpos_x2: Double = rows(i + 1).getAs[Double]("startpos_x")
                          val startpos_y2: Double = rows(i + 1).getAs[Double]("startpos_y")
                          val endpos_x2: Double = rows(i + 1).getAs[Double]("endpos_x")
                          val endpos_y2: Double = rows(i + 1).getAs[Double]("endpos_y")


                          val dist1: Double = get_distance2(startpos_x2, startpos_y2, endpos_x, endpos_y) * 1000
                          val dist2: Double = get_distance2(startpos_x, startpos_y, endpos_x2, endpos_y2) * 1000

                          dist = math.min(dist1, dist2)
                          if (dist > 100) {
                              groupby_id = uid + "_" + +num
                              num += 1
                          } else groupby_id = uid + "_" + +num

                      } else groupby_id = uid + "_" + num

                      rowsBuff.append(IsBuilding(rulepos, ruleroadid, uid, start_dept, end_dept, isbuilding_swid, groupby_id, adcode, version, inc_day))
                  }
              } else {
                  val list: List[Row] = rowsList
                  val row: Row = list.head

                  val rulepos: String = row.getAs[String]("rulepos")
                  val ruleroadid: String = row.getAs[String]("ruleroadid")
                  val start_dept: String = row.getAs[String]("start_dept")
                  val end_dept: String = row.getAs[String]("end_dept")
                  val isbuilding_swid: String = row.getAs[String]("isbuilding_swid")
                  val adcode: String = row.getAs[String]("adcode")
                  val version: String = row.getAs[String]("version")
                  val inc_day: String = row.getAs[String]("inc_day")

                  rowsBuff.append(IsBuilding(rulepos, ruleroadid, uid, start_dept, end_dept, isbuilding_swid, groupby_id, adcode, version, inc_day))
              }

              rowsBuff
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, groupByIdDF1, "添加groupby_id后的数据")

        // 添加 isbuilding_point
        val w1: WindowSpec = Window.partitionBy("uid").orderBy($"groupby_id".asc)
        val groupByIdDF2: DataFrame = groupByIdDF1
          .withColumn("next_ruleroadid", lead("ruleroadid", 1, "-1").over(w1))
          .withColumn("rn", row_number().over(w1))
          .withColumn("ruleroadid2", get_ruleroadid2($"ruleroadid", $"rn", $"isbuilding_swid"))
          .withColumn("isbuilding_swid_tmp", get_isbuilding_swid($"ruleroadid2", $"next_ruleroadid", $"isbuilding_swid"))
          .groupBy("groupby_id")
          .agg(concat_ws("|", collect_list("isbuilding_swid_tmp")).alias("isbuilding_swid"))
          .coalesce(5)
          .withColumn("isbuilding_point", get_isbuilding_point($"isbuilding_swid"))
          .repartition(300)


        val groupByIdDF: Dataset[Row] = groupByIdDF1
          .drop("isbuilding_swid")
          .join(groupByIdDF2, Seq("groupby_id"))
          .filter("adcode != ''")
          .select("rulepos", "ruleroadid", "uid", "start_dept", "end_dept", "isbuilding_swid", "isbuilding_point", "groupby_id", "adcode", "version", "inc_day")
          .withColumn("area_code", substring($"adcode", 1, 4))
          .withColumn("sample_batch", concat_ws("_", $"inc_day", $"inc_day"))
          .withColumn("tast_tm", lit(current_time))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .coalesce(10)
          .persist(StorageLevel.MEMORY_AND_DISK)


        // 获取在建道路的swid 和 轨迹起始点
        GetDFCountAndSampleData(logger, groupByIdDF, "groupby_id的数据")


        // 根据groupby_id去重
        val groupByIddDropDupedDF: Dataset[Row] = groupByIdDF
          .join(issuDF, Seq("rulepos", "ruleroadid"), "leftanti")
          .dropDuplicates("groupby_id")
          .coalesce(10)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, groupByIddDropDupedDF, "根据groupby_id去重之后的数据")

        // 写入到hive
        df2HiveByOverwrite(logger, groupByIdDF, "dm_gis.mms_isbuilding_data_info")
        df2HiveByOverwrite(logger, groupByIddDropDupedDF, "dm_gis.mms_isbuilding_data_issue_info")
        groupByIddDropDupedDF.unpersist()
        groupByIdDF.unpersist()
        isbuilding_swidDF.unpersist()
        isBuildingDF.unpersist()
        groupByIdDF1.unpersist()
    }

    // 按点位聚合
    def aggreRuleidAndRuleposData(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        // 1. 获取所有的闯行数据
        val origDataSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_and_jp_limited_result_info
               |  where
               |  inc_day = '$inc_day'
               |  and mark_dist = 0
               |  and (srcIdfrom = '' or srcIdfrom is null)
               |  and mark in(-1,0,4)
               |  and (d_frequency ='' or cast(d_frequency as int) > 3)
               |""".stripMargin

        logger.error(origDataSql)

        // 2. 根据 ruleid 和 rulepos分组聚合
        val ResultAggDataDF: DataFrame = spark
          .sql(origDataSql)
          .filter("ruleid != '' and rulepos != ''")
          .filter("adcode != ''")
          .rdd
          .map(r => {
              val ruleid: String = r.getAs[String]("ruleid")
              val rulepos: String = r.getAs[String]("rulepos")
              ((ruleid, rulepos), r)
          })
          .groupByKey()
          .map(r => {
              val res: AggreRuleidAndRuleposResult = aggre_limit_data(r)
              res
          })
          .toDF()
          .coalesce(100)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ResultAggDataDF, "聚合之后的数据 ")

        // 最终的数据落表
        df2HiveByOverwrite(logger, ResultAggDataDF, "dm_gis.mms_car_route_plan_and_jp_limited_aggre_result_info")
        ResultAggDataDF.unpersist()
    }

    // 聚合闯行数据
    def aggre_limit_data(r: ((String, String), Iterable[Row])): AggreRuleidAndRuleposResult = {
        val ruleid: String = r._1._1
        val rulepos: String = r._1._2
        val rows: Iterable[Row] = r._2

        val freqCnt: Int = rows.size
        val gd_freqCnt: Int = freqCnt

        val ruleroadidSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val ruleoutroadidSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val ruletypeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_serialSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_typeSet: mutable.HashSet[Int] = new mutable.HashSet[Int]()
        val limitweightSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitsizeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitwidthSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitaxloadSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitloadSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitaxcntSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitvehicletypeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitpassportSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitholidaySet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitoutflagSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitemitstandSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limittailcharSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitstartdateSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitenddateSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limitweekSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val limittimeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val ruleregiondescSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val data_sourceSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val heightSet: mutable.HashSet[Double] = new mutable.HashSet[Double]()
        val widthSet: mutable.HashSet[Double] = new mutable.HashSet[Double]()
        val vehicle_lengthSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_full_load_weightSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_load_weightSet: mutable.HashSet[Double] = new mutable.HashSet[Double]()
        val axls_numberSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_serial_head2Set: mutable.HashSet[String] = new mutable.HashSet[String]()
        val energySet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val colorSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val emissionSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val adcodeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val vehicle_serial_last2Set: mutable.HashSet[String] = new mutable.HashSet[String]()
        val plineSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val guidSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val citySet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val AreaCodeSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val versionSet: mutable.HashSet[String] = new mutable.HashSet[String]()
        val inc_daySet: mutable.HashSet[String] = new mutable.HashSet[String]()

        for (r <- rows) {
            ruleroadidSet.add(r.getAs[String]("ruleroadid"))
            ruleoutroadidSet.add(r.getAs[String]("ruleoutroadid"))
            ruletypeSet.add(r.getAs[String]("ruletype"))
            vehicle_serialSet.add(r.getAs[String]("vehicle_serial"))
            vehicle_typeSet.add(r.getAs[Int]("vehicle_type"))
            limitweightSet.add(r.getAs[String]("limitweight"))
            limitsizeSet.add(r.getAs[String]("limitsize"))
            limitwidthSet.add(r.getAs[String]("limitwidth"))
            limitaxloadSet.add(r.getAs[String]("limitaxload"))
            limitloadSet.add(r.getAs[String]("limitload"))
            limitaxcntSet.add(r.getAs[String]("limitaxcnt"))
            limitvehicletypeSet.add(r.getAs[String]("limitvehicletype"))
            limitpassportSet.add(r.getAs[String]("limitpassport"))
            limitholidaySet.add(r.getAs[String]("limitholiday"))
            limitoutflagSet.add(r.getAs[String]("limitoutflag"))
            limitemitstandSet.add(r.getAs[String]("limitemitstand"))
            limittailcharSet.add(r.getAs[String]("limittailchar"))
            limitstartdateSet.add(r.getAs[String]("limitstartdate"))
            limitenddateSet.add(r.getAs[String]("limitenddate"))
            limitweekSet.add(r.getAs[String]("limitweek"))
            limittimeSet.add(r.getAs[String]("limittime"))
            ruleregiondescSet.add(r.getAs[String]("ruleregiondesc"))
            data_sourceSet.add(r.getAs[String]("data_source"))
            heightSet.add(r.getAs[Double]("height"))
            widthSet.add(r.getAs[Double]("width"))
            vehicle_lengthSet.add(r.getAs[String]("vehicle_length"))
            vehicle_full_load_weightSet.add(r.getAs[String]("vehicle_full_load_weight"))
            vehicle_load_weightSet.add(r.getAs[Double]("vehicle_load_weight"))
            axls_numberSet.add(r.getAs[String]("axls_number"))
            vehicle_serial_head2Set.add(r.getAs[String]("vehicle_serial").substring(0, 2))
            energySet.add(r.getAs[String]("energy"))
            colorSet.add(r.getAs[String]("color"))
            vehicle_serial_last2Set.add(r.getAs[String]("vehicle_serial").reverse.substring(0, 1))
            emissionSet.add(r.getAs[String]("emission"))
            adcodeSet.add(r.getAs[String]("adcode"))
            plineSet.add(r.getAs[String]("pline"))
            guidSet.add(r.getAs[String]("guid"))
            citySet.add(r.getAs[String]("city"))
            AreaCodeSet.add(r.getAs[String]("adcode").substring(0, 4))
            versionSet.add(r.getAs[String]("version"))
            inc_daySet.add(r.getAs[String]("inc_day"))
        }

        AggreRuleidAndRuleposResult(ruleid, rulepos, freqCnt, gd_freqCnt, check_set_empty(ruleroadidSet), check_set_empty(ruleoutroadidSet),
            check_set_empty(ruletypeSet), vehicle_serialSet.size, vehicle_typeSet.toList.sorted.mkString("|"), check_set_empty(limitweightSet), check_set_empty(limitsizeSet),
            check_set_empty(limitwidthSet), check_set_empty(limitaxloadSet), check_set_empty(limitloadSet), check_set_empty(limitaxcntSet), check_set_empty(limitvehicletypeSet),
            check_set_empty(limitpassportSet), check_set_empty(limitholidaySet), check_set_empty(limitoutflagSet), check_set_empty(limitemitstandSet),
            check_set_empty(limittailcharSet), check_set_empty(limitstartdateSet), check_set_empty(limitenddateSet), check_set_empty(limitweekSet),
            check_set_empty(limittimeSet), check_set_empty(ruleregiondescSet), check_set_empty(data_sourceSet), get_set_max(heightSet), get_set_max(widthSet),
            get_set_max(vehicle_lengthSet), get_set_max(vehicle_full_load_weightSet), get_set_max(vehicle_load_weightSet), get_set_max(axls_numberSet), check_set_empty(vehicle_serial_head2Set),
            check_set_empty(energySet), check_set_empty(colorSet), check_set_empty(vehicle_serial_last2Set), check_set_empty(emissionSet),
            check_set_empty(adcodeSet), plineSet.mkString(";"), check_set_empty(guidSet), inc_daySet.min + "_" + inc_daySet.max, check_set_empty(citySet), check_set_empty(AreaCodeSet), check_set_empty(versionSet), inc_daySet.head
        )
    }

    // 判断 set集合是否为空，如果是空，就返回字符串""
    def check_set_empty(s: mutable.HashSet[String]): String = {
        if (s.isEmpty) ""
        else if (s.size == 1 && s.head == null) ""
        else if (s.contains(null)) {
            s.remove(null)
            s.toList.sortBy(x => (x.length, x.head)).mkString("|")
        }
        else s.toList.sortBy(x => (x.length, x.head)).mkString("|")
    }

    def get_set_max(s: mutable.HashSet[String]): String = {
        if (s.isEmpty) ""
        else if (s.size == 1 && s.head == null) ""
        else if (s.contains(null)) {
            s.remove(null)
            s.max
        }
        else s.max
    }

    def get_set_max(s: mutable.HashSet[Double]): Double = {
        if (s.isEmpty) 0.0
        else s.max
    }

    // 判断该条数据是否应该下发
    def mark_flag(r: Row, current_time: String): (String, Boolean, Boolean) = {
        // flag 标识这个条数据是否应该下发，true → 下发   false → 不下发
        // is_send = true 表示已经下发过，默认都没下发过
        var flag: Boolean = false
        var is_send: Boolean = true
        val class_first_list: List[String] = List("路段规制缺失", "路段规制冗余", "路段规制信息错误",
            "路口禁止信息缺失", "路口禁止信息冗余", "路口禁止信息错误")

        val rtk: String = r.getAs[String]("rtk")
        val task_tm: String = r.getAs[String]("task_tm")

        if (task_tm == null) {
            /*
            没有关联上的数据，分2种情况：
            1、这条数据从来都没有下发过
            2、这条数据之前下发过，但是核实结果还没有推送过来
             */
            flag = true
            is_send = false
        }
        else {
            // 能关联上的数据，说明之前已经下发过
            val fm = new SimpleDateFormat("yyyyMMdd")
            val task_tm_timestamp: Long = fm.parse(task_tm).getTime
            val current_time_timestamp: Long = fm.parse(current_time).getTime
            val d: Long = (current_time_timestamp - task_tm_timestamp) / (1000 * 3600 * 24)
            val work_status: String = r.getAs[String]("work_status")
            val class_first: String = r.getAs[String]("class_first")

            if ((work_status == "5" || work_status == "6") && d == 60) flag = true
            else if (work_status == "2" && class_first_list.contains(class_first) && d == 30) flag = true
            else if (work_status == "2" && !class_first_list.contains(class_first) && d == 30) flag = true
            else if ((work_status == "4" || work_status == "3") && d == 15) flag = true
        }

        (rtk, flag, is_send)
    }

    // 第一次过滤
    def firstFilter(spark: SparkSession, aggrLimitedSql: String): DataFrame = {
        logger.error(aggrLimitedSql)

        val aggrLimitedFisrtFilterDS: DataFrame = spark
          .sql(aggrLimitedSql)
          .dropDuplicates("guid", "rulepos")
          .where("ruletype != '区域限行'")
          .where("cast(limitsize as double) <= 4.2 or limitsize = ''")
          .where("data_source not in('1','2','3')")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, aggrLimitedFisrtFilterDS, "第一次过滤后的数据")

        aggrLimitedFisrtFilterDS
    }

    // 第二次过滤
    def secondFilter(spark: SparkSession, aggrLimitedFisrtFilterDS: DataFrame, hisCheckResultSql: String, current_time: String): (DataFrame, DataFrame) = {
        import spark.implicits._

        logger.error(hisCheckResultSql)

        val hisCheckResultDF: DataFrame = spark
          .sql(hisCheckResultSql)
          .select("rtk", "rulepos", "guid", "task_tm", "work_status", "class_first")

        val df: DataFrame = aggrLimitedFisrtFilterDS
          .select("rtk")
          .join(hisCheckResultDF, Seq("rtk"), "left")
          .map(r => {
              val (rtk, flag, is_send) = mark_flag(r, current_time)
              (rtk, flag, is_send)
          })
          .toDF("rtk", "flag", "is_send")
          .persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, df, "第二次过滤的中间临时数据")

        val aggrLimitedSeconrdFilterHisDS1: DataFrame = df
          .filter("flag = true")
          .filter("is_send = true")
          .drop("flag", "is_send")
          .persist(StorageLevel.MEMORY_AND_DISK)

        aggrLimitedSeconrdFilterHisDS1.count()

        val aggrLimitedSeconrdFilterHisDS2: DataFrame = df
          .filter("is_send = false")
          .persist(StorageLevel.MEMORY_AND_DISK)

        aggrLimitedSeconrdFilterHisDS2.count()

        (aggrLimitedSeconrdFilterHisDS1, aggrLimitedSeconrdFilterHisDS2)
    }

    // 第三次过滤
    def thirdFilter(spark: SparkSession, aggrLimitedSeconrdFilterHisDS1: DataFrame, aggrLimitedSeconrdFilterHisDS2: DataFrame, aggrLimited2Sql: String, current_time: String): DataFrame = {
        logger.error(aggrLimited2Sql)

        val aggrLimited2DS: Dataset[Row] = spark.sql(aggrLimited2Sql)
          .dropDuplicates("rtk")

        val aggrLimitedThreeFilterHisDF: DataFrame = aggrLimitedSeconrdFilterHisDS2
          .join(aggrLimited2DS, Seq("rtk"), "left")
          .filter("ruleid is null")
          .select("rtk")
          .union(aggrLimitedSeconrdFilterHisDS1)
          .withColumn("task_tm", lit(current_time))
          .withColumn("task_mark", lit("0"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, aggrLimitedThreeFilterHisDF, "第三次过滤后的数据量")

        aggrLimitedThreeFilterHisDF
    }

    // 最终下发的数据
    def finalIssueData(spark: SparkSession, aggrLimitedFisrtFilterDS: DataFrame, aggrLimitedThreeFilterHisDF: DataFrame, aggrLimited2Sql: String, compareSql: String, start_time: String, end_time: String): Unit = {
        import spark.implicits._

        // 线上每日生产的作业数据
        val resultDF1: DataFrame = aggrLimitedFisrtFilterDS
          .join(aggrLimitedThreeFilterHisDF, Seq("rtk"))
          .withColumn("area_code2", $"area_code")
          .withColumn("version2", $"version")
          .withColumn("inc_day2", $"inc_day")
          .drop("area_code", "version", "inc_day")

        // 线下获取到的作业数据
        val aggrLimited2DF: DataFrame = spark.sql(aggrLimited2Sql)
          .select("rtk", "ruleid")
          .withColumnRenamed("ruleid", "ruleid2")

        val resultDF2: DataFrame = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("sep", "\t")
          .load("/user/89018313/upload/rule_orign.csv")
          .filter(s"inc_day >= '$start_time' and inc_day < '$end_time' ")
          .join(aggrLimited2DF, Seq("rtk"), "left")
          .filter("ruleid2 is null")
          .drop("ruleid2")

        // 版本对比获取的作业数据
        val resultDF3: DataFrame = spark
          .sql(compareSql)
          .filter("cast(ruleid as int) < 100000")
          .filter("cast(limitsize as double) <= 4.2 or limitsize = ''")
          .filter("data_source not in('1','2','3')")
          .join(aggrLimited2DF, Seq("rtk"), "left")
          .filter("ruleid2 is null")
          .drop("ruleid2")

        val resultDF: DataFrame = resultDF1
          .union(resultDF2)
          .union(resultDF3)
          .dropDuplicates("rtk")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, resultDF, "最终下发的数据")

        // 最终的数据落表
        df2HiveByOverwrite(logger, resultDF, "dm_gis.mms_car_route_aggre_data_issue_info")

        aggrLimitedFisrtFilterDS.unpersist()
        aggrLimitedThreeFilterHisDF.unpersist()
        resultDF.unpersist()
    }

    // 任务下发
    def taskIssueDataFromAggreResult(spark: SparkSession, inc_day: String): Unit = {

        val current_time: String = getdaysBeforeOrAfter(inc_day, 4)
        val two_month_ago: String = getdaysBeforeOrAfter(inc_day, -60)
        val three_month_ago: String = getdaysBeforeOrAfter(inc_day, -90)
        val end_time: String = getdaysBeforeOrAfter(inc_day, 1)

        // 获取聚合后的闯行数据
        val aggrLimitedSql: String =
            s"""
               |select
               |  *,
               |  concat_ws('_',
               |    if(rulepos == '' or rulepos is null,'n',	rulepos),
               |    if(ruleroadid == '' or ruleroadid is null,'n',	ruleroadid),
               |    if(ruleoutroadid == '' or ruleoutroadid is null,'n',	ruleoutroadid),
               |    if(ruletype == '' or ruletype is null,'n',	ruletype),
               |    if(limitweight == '' or limitweight is null,'n',	limitweight),
               |    if(limitsize == '' or limitsize is null,'n',	limitsize),
               |    if(limitwidth == '' or limitwidth is null,'n',	limitwidth),
               |    if(limitaxload == '' or limitaxload is null,'n',	limitaxload),
               |    if(limitload == '' or limitload is null,'n',	limitload),
               |    if(limitaxcnt == '' or limitaxcnt is null,'n',	limitaxcnt),
               |    if(limitpassport == '' or limitpassport is null,'n',	limitpassport),
               |    if(limitholiday == '' or limitholiday is null,'n',	limitholiday),
               |    if(limitoutflag == '' or limitoutflag is null,'n',	limitoutflag),
               |    if(limitemitstand == '' or limitemitstand is null,'n',	limitemitstand),
               |    if(limitweek == '' or limitweek is null,'n',	limitweek),
               |    if(limittime == '' or limittime is null,'n',	limittime)
               |  ) rtk
               |from
               |  dm_gis.mms_car_route_plan_and_jp_limited_aggre_result_info
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin

        // 最近2个月下发过的数据
        val aggrLimited2Sql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_aggre_data_issue_info
               |where
               |  inc_day >= '$two_month_ago'
               |  and inc_day < '$inc_day'
               |""".stripMargin

        // 最近3个月累计核实结果数据
        val hisCheckResultSql: String =
            s"""
               |-- 对字段为空 和 null做预处理
               |with t1 as(
               |select
               |  rulepos,
               |  guid,
               |  work_status,
               |  class_first,
               |  task_tm,
               |  if(ruleroadid == '' or ruleroadid is null,'n',	ruleroadid)	ruleroadid,
               |  if(ruleoutroadid == '' or ruleoutroadid is null,'n',	ruleoutroadid)	ruleoutroadid,
               |  if(ruletype == '' or ruletype is null,'n',	ruletype)	ruletype,
               |  if(limitweight == '' or limitweight is null,'n',	limitweight)	limitweight,
               |  if(limitsize == '' or limitsize is null,'n',	limitsize)	limitsize,
               |  if(limitwidth == '' or limitwidth is null,'n',	limitwidth)	limitwidth,
               |  if(limitaxload == '' or limitaxload is null,'n',	limitaxload)	limitaxload,
               |  if(limitload == '' or limitload is null,'n',	limitload)	limitload,
               |  if(limitaxcnt == '' or limitaxcnt is null,'n',	limitaxcnt)	limitaxcnt,
               |  if(limitpassport == '' or limitpassport is null,'n',	limitpassport)	limitpassport,
               |  if(limitholiday == '' or limitholiday is null,'n',	limitholiday)	limitholiday,
               |  if(limitoutflag == '' or limitoutflag is null,'n',	limitoutflag)	limitoutflag,
               |  if(limitemitstand == '' or limitemitstand is null,'n',	limitemitstand)	limitemitstand,
               |  if(limitweek == '' or limitweek is null,'n',	limitweek)	limitweek,
               |  if(limittime == '' or limittime is null,'n',	limittime)	limittime
               |from
               |  dm_gis.mms_car_route_aggre_data_checked_result_info
               |where
               |  inc_day >= '$three_month_ago'
               |  and inc_day <= '$inc_day'
               |),
               |
               |-- 生产唯一key:rtk
               |t2 as(
               |select
               |  concat_ws('_',rulepos,ruleroadid,ruleoutroadid,ruletype,limitweight,limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,limitoutflag,limitemitstand,limitweek,limittime) rtk,
               |  rulepos,
               |  guid,
               |  work_status,
               |  class_first,
               |  task_tm
               |from
               | t1
               |)
               |
               | -- 按key排序取最新
               |select
               |  rtk,
               |  rulepos,
               |  guid,
               |  work_status,
               |  class_first,
               |  task_tm
               |from(
               |  select
               |    rtk,
               |    rulepos,
               |    guid,
               |    work_status,
               |    class_first,
               |    task_tm,
               |	row_number() over(partition by rtk order by task_tm desc) as rn
               |  from
               |    t2
               |) t
               |where rn = 1
               |""".stripMargin

        // 版本对比获取到的数据
        val compareSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_aggre_data_issue_info_v2
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin


        // 进行剔除
        val aggrLimitedFisrtFilterDS: DataFrame = firstFilter(spark, aggrLimitedSql)

        // 第二次过滤
        val (aggrLimitedSeconrdFilterHisDS1, aggrLimitedSeconrdFilterHisDS2) = secondFilter(spark, aggrLimitedFisrtFilterDS, hisCheckResultSql, current_time)

        // 第三次过滤：过滤最近已经下发过的数据
        val aggrLimitedThreeFilterHisDF: DataFrame = thirdFilter(spark, aggrLimitedSeconrdFilterHisDS1, aggrLimitedSeconrdFilterHisDS2, aggrLimited2Sql, current_time)

        //最终下发的数据
        finalIssueData(spark, aggrLimitedFisrtFilterDS, aggrLimitedThreeFilterHisDF, aggrLimited2Sql, compareSql, inc_day, end_time)

        aggrLimitedFisrtFilterDS.unpersist()
        aggrLimitedSeconrdFilterHisDS1.unpersist()
        aggrLimitedSeconrdFilterHisDS2.unpersist()
        aggrLimitedThreeFilterHisDF.unpersist()

    }


}
