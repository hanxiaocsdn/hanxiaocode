package app.runLimited

import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.SparkConfigUtil
import app.runLimited.DealLocusAbnormalDataFromLimited.getPoint2LinkDist
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}

/**
  * 删除闯行数据中 车参异常的数据,然后做匹配异常处理
  *
  * 数据源：规划跑出来的闯行数据、纠偏跑出来的闯行数据
  *
  * 5. 删除车参异常的闯行数据  & 匹配异常处理
  */
object DealCarParamAbnormalDataFromLimited {

    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        if (args.length != 3) {
            logger.error(
                """
                  |需要输入4个参数：
                  |    start_time、end_time、dist
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val dist: Double = args(2).toDouble
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"dist：$dist ")


        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        logger.error("<================ 纠偏的数据进行车参异常剔除和匹配异常处理 ================>")

        // 1.1 纠偏获取到的闯行数据
        val jpLimitedDataSQL: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(jpLimitedDataSQL)

        // 1.2 获取纠偏的数据
        val jpLimitedDF: DataFrame = spark.sql(jpLimitedDataSQL)
          .drop("rmultipathpos","rmultipathswid")
          .repartition(600)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 1.3 纠偏的数据源
        GetDFCountAndSampleData(logger, jpLimitedDF, "纠偏的数据")

        // 1.4 删除纠偏数据里 车参异常的数据
        val jpLimitedAfterDealDF: Dataset[Row] = jpLimitedDF
          // 删除宽度异常
          .where("!(limitwidth !='' and limitwidth is not null and width > 2.60)")
          // 删除高度异常
          .where("!(limitsize !='' and limitsize is not null and height > 5)")
          // 删除重量异常
          .where("!(axls_number = '2' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '18')")
          .where("!(axls_number = '3' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '27')")
          .where("!(axls_number = '4' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '37')")
          .where("!(axls_number = '5' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '43')")
          .where("!(axls_number = '6' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '49')")
          // 删除轴重异常
          .where("!(axls_number = '2' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '18')")
          .where("!(axls_number = '3' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '27')")
          .where("!(axls_number = '4' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '37')")
          .where("!(axls_number = '5' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '43')")
          .where("!(axls_number = '6' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '49')")
          // 删除轴数异常
          .where("!(axls_number = '4' and limitaxcnt !='' and limitaxcnt is not null and vehicle_type in (5,6,7))")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpLimitedAfterDealDF, "【纠偏数据】剔除异常数据之后的闯行数据")

        // 1.5 做 匹配异常处理
        val jpLimitedMatchedDealDF: DataFrame = jpLimitedAfterDealDF
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val rulepos: String = r.getAs[String]("rulepos")
              val coords: String = r.getAs[String]("coords")
              val city: String = r.getAs[String]("city")
              val version: String = r.getAs[String]("version")
              val inc_day: String = r.getAs[String]("inc_day")
              val coordsArr: Array[String] = coords
                .replaceAll("\"", "")
                .replaceAll("\\[", "")
                .replaceAll("],", "|")
                .replaceAll("]", "")
                .replaceAll(" ", "")
                .split("\\|")

              var min_dist: Double = 0.0
              try {
                  for (i <- 0 to coordsArr.length - 2) {
                      val dist: Double = getPoint2LinkDist(rulepos, coordsArr(i), coordsArr(i + 1))
                      if (i == 0) min_dist = dist
                      if (min_dist >= dist) min_dist = dist
                  }
              } catch {
                  case e:Exception => logger.error("出错了"+e.getMessage)
              }


              var mark_dist: Int = 0
              if (min_dist > dist) mark_dist = 1
              (uuid, rulepos, mark_dist, min_dist, city, version, inc_day)
          })
          .toDF("uuid", "rulepos", "mark_dist", "min_dist", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpLimitedMatchedDealDF, "【纠偏数据】匹配异常的数据")

        // 1.6 关联上原始数据
        val jpLimitedResultDF: DataFrame = jpLimitedAfterDealDF
          .drop("version", "inc_day", "city")
          .join(jpLimitedMatchedDealDF, Seq("uuid", "rulepos"))
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpLimitedResultDF, "【纠偏数据】最终的数据")

        // 1.7 纠偏的数据写入hive
        df2HiveByOverwrite(logger,jpLimitedResultDF,"dm_gis.mms_car_route_jp_detail_and_limited_info_his")
        // 1.8 释放纠偏的缓存
        jpLimitedDF.unpersist()


        logger.error("<================ 规划的数据进行车参异常剔除和匹配异常处理 ================>")

        // 规划的数据 做车参异常处理逻辑
        // 2.1 规划获取到的闯行数据
        val palnLimitedDataSQL: String =
        s"""
           |select
           |  *
           |from
           |  dm_gis.mms_car_route_plan_detail_and_limited_info
           |where
           |  inc_day >= '$start_time'
           |  and inc_day < '$end_time'
           |""".stripMargin

        logger.error(palnLimitedDataSQL)

        // 2.2 获取规划的数据
        val planLimitedDF: DataFrame = spark.sql(palnLimitedDataSQL)
          .drop("rmultipathpos","rmultipathswid")
          .repartition(600)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 2.3 规划的数据源
        GetDFCountAndSampleData(logger, planLimitedDF, "规划的数据")

        // 2.4 删除规划数据里 车参异常的数据
        val planLimitedAfterDealDF: Dataset[Row] = planLimitedDF
          // 删除宽度异常
          .where("!(limitwidth !='' and limitwidth is not null and width > 2.60)")
          // 删除高度异常
          .where("!(limitsize !='' and limitsize is not null and height > 5)")
          // 删除重量异常
          .where("!(axls_number = '2' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '18')")
          .where("!(axls_number = '3' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '27')")
          .where("!(axls_number = '4' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '37')")
          .where("!(axls_number = '5' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '43')")
          .where("!(axls_number = '6' and limitweight !='' and limitweight is not null and vehicle_full_load_weight > '49')")
          // 删除轴重异常
          .where("!(axls_number = '2' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '18')")
          .where("!(axls_number = '3' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '27')")
          .where("!(axls_number = '4' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '37')")
          .where("!(axls_number = '5' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '43')")
          .where("!(axls_number = '6' and limitaxload !='' and limitaxload is not null and vehicle_full_load_weight > '49')")
          // 删除轴数异常
          .where("!(axls_number = '4' and limitaxcnt !='' and limitaxcnt is not null and vehicle_type in (5,6,7))")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedAfterDealDF, "【规划数据】剔除异常数据之后的闯行数据")

        // 2.5 规划的数据 做匹配异常处理
        val planLimitedMatchedDealDF: DataFrame = planLimitedAfterDealDF
          .map(r => {
              val uuid: String = r.getAs[String]("uuid")
              val data_source: String = r.getAs[String]("data_source")
              val d_plan_order: Int = r.getAs[Int]("d_plan_order")
              val rulepos: String = r.getAs[String]("rulepos")
              val coords: String = r.getAs[String]("coords")
              val city: String = r.getAs[String]("city")
              val version: String = r.getAs[String]("version")
              val inc_day: String = r.getAs[String]("inc_day")
              val coordsArr: Array[String] = coords
                .replaceAll("\"", "")
                .replaceAll("\\[", "")
                .replaceAll("],", "|")
                .replaceAll("]", "")
                .replaceAll(" ", "")
                .split("\\|")

              var min_dist: Double = 0.0
              try {
                  for (i <- 0 to coordsArr.length - 2) {
                      val dist: Double = getPoint2LinkDist(rulepos, coordsArr(i), coordsArr(i + 1))
                      if (i == 0) min_dist = dist
                      if (min_dist >= dist) min_dist = dist
                  }
              } catch {
                  case e:Exception => logger.error("出错了"+e.getMessage)
              }

              var mark_dist: Int = 0
              if (min_dist > dist) mark_dist = 1
              (uuid, data_source, d_plan_order, rulepos, mark_dist, min_dist, city, version, inc_day)
          })
          .toDF("uuid", "data_source", "d_plan_order", "rulepos", "mark_dist", "min_dist", "city", "version", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedMatchedDealDF, "【规划数据】匹配异常的数据")

        // 2.6 关联上原始数据
        val planLimitedResultDF: DataFrame = planLimitedAfterDealDF
          .drop("version", "inc_day", "city")
          .join(planLimitedMatchedDealDF, Seq("uuid", "data_source", "d_plan_order", "rulepos"))
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planLimitedResultDF, "【规划的数据】最终的数据")

        //2.7 规划的数据写入hive
        df2HiveByOverwrite(logger,planLimitedResultDF,"dm_gis.mms_car_route_plan_detail_and_limited_info_his")

        // 释放纠偏的缓存
        planLimitedDF.unpersist()


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()
    }
}
