package app.runLimited

import app.runLimited.DealLocusAbnormalDataFromLimited.getDistAndPointAndMark
import app.runLimited.MergeLimitedDataFromPlanAndJP.{callMatchService, getMatchAbnormalData}
import com.alibaba.fastjson.JSONObject
import entry.SwidPoint
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, Dataset, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, GetDSCountAndSampleData, df2HiveByOverwrite, getDataFrame}
import utils.SparkConfigUtil

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * (临时执行) 已下线
  * 匹配中断 逻辑处理
  */

object GetMatchBreakoffData {

    def main(args: Array[String]): Unit = {

        // 初始化
        val ClassName: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(ClassName)

        if (args.length != 3) {
            logger.error(
                """
                  |需要输入3个参数：
                  |    start_time、end_time、thirty_day_ago
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val thirty_day_ago: String = args(2)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"30天以前的日期：$thirty_day_ago ")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(ClassName)

        // 导入隐式转换
        import spark.implicits._

        // 规划的未闯行数据
        val unlimitedSql: String =
            s"""
               |select
               |  concat_ws('_',uuid,string(d_plan_order),data_source) as groupby_id,
               |  uuid,
               |  data_source,
               |  d_plan_order,
               |  regexp_replace(regexp_replace(regexp_replace(regexp_replace(coords,'\\\\]',''),',\\\\[','|'),'\\\\"',''),'\\\\[','') as coords,
               |  regexp_replace(rcoords,';','|') as rcoords,
               |  rmultipathpos,
               |  rmultipathswid,
               |  start_dept,
               |  end_dept,
               |  start_longitude,
               |  end_longitude,
               |  start_latitude,
               |  end_latitude,
               |  '' as jp_status,
               |  '' as jp_swid,
               |  city,
               |  version,
               |  inc_day
               |from
               |  dm_gis.mms_car_route_plan_detail_and_unlimited_info
               |where
               |  data_source = '2'
               |  and inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 规划的闯行数据
        val limitedSql: String =
            s"""
               |select
               |  concat_ws('_',uuid,string(d_plan_order),data_source) as groupby_id,
               |  uuid,
               |  data_source,
               |  d_plan_order,
               |  regexp_replace(regexp_replace(regexp_replace(regexp_replace(coords,'\\\\]',''),',\\\\[','|'),'\\\\"',''),'\\\\[','') as coords,
               |  regexp_replace(rcoords,';','|') as rcoords,
               |  rmultipathpos,
               |  rmultipathswid,
               |  start_dept,
               |  end_dept,
               |  start_longitude,
               |  end_longitude,
               |  start_latitude,
               |  end_latitude,
               |  '' as jp_status,
               |  '' as jp_swid,
               |  city,
               |  version,
               |  inc_day
               |from
               |  dm_gis.mms_car_route_plan_detail_and_limited_info
               |where
               |  data_source = '2'
               |  and inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 纠偏的闯行数据
        val jplimitedSql: String =
            s"""
               |select
               |  concat_ws('_',uuid,'0',data_source) as groupby_id,
               |  uuid,
               |  data_source,
               |  0 as d_plan_order,
               |  regexp_replace(regexp_replace(regexp_replace(regexp_replace(coords,'\\\\]',''),',\\\\[','|'),'\\\\"',''),'\\\\[','') as coords,
               |  regexp_replace(rcoords,';','|') as rcoords,
               |  rmultipathpos,
               |  rmultipathswid,
               |  start_dept,
               |  end_dept,
               |  start_longitude,
               |  end_longitude,
               |  start_latitude,
               |  end_latitude,
               |  jp_status,
               |  jp_swid,
               |  city,
               |  version,
               |  inc_day
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 纠偏的未闯行数据
        val jpunlimitedSql: String =
            s"""
               |select
               |  concat_ws('_',uuid,'0',data_source) as groupby_id,
               |  uuid,
               |  data_source,
               |  0 as d_plan_order,
               |  regexp_replace(regexp_replace(regexp_replace(regexp_replace(coords,'\\\\]',''),',\\\\[','|'),'\\\\"',''),'\\\\[','') as coords,
               |  regexp_replace(rcoords,';','|') as rcoords,
               |  rmultipathpos,
               |  rmultipathswid,
               |  start_dept,
               |  end_dept,
               |  start_longitude,
               |  end_longitude,
               |  start_latitude,
               |  end_latitude,
               |  jp_status,
               |  jp_swid,
               |  city,
               |  version,
               |  inc_day
               |from
               |  dm_gis.mms_car_route_jp_detail_and_unlimited_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 最近30天已经下发的数据
        val gdBreakpointSwindSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.all_result_gd_breakpoint_swid_info
               |where
               |  inc_day >= '$thirty_day_ago'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(unlimitedSql)
        logger.error(limitedSql)
        logger.error(jplimitedSql)
        logger.error(jpunlimitedSql)
        logger.error(gdBreakpointSwindSql)

        val unlimitedDF: DataFrame = spark.sql(unlimitedSql)
        val limitedDF: DataFrame = spark.sql(limitedSql)
        val jpunlimitedDF: DataFrame = spark.sql(jpunlimitedSql)
        val jplimitedDF: DataFrame = spark.sql(jplimitedSql)

        val ft_url: String = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&ak=ebf48ecaa1fd436fa3d40c4600aa051f&x1=113.9213889&y1=22.673595&x2=114.036305&y2=22.638273&type=0&cc=1&strategy=0&opt=gd3&vehicle=6&weight=3.0&mload=3.0&height=2.4&axleNumber=2&plate=%E7%B2%A4C5909S&plateColor=1&energy=2&width=2.4&size=5.2&passport=100000&tolls=1&test=0&stype=0&etype=2&pathCount=1&fencedist=50&merge=4&fixedroute=2&frequency=1"

        // 合并所有的数据
        val limitedAllDF: DataFrame = unlimitedDF
          .union(limitedDF)
          .union(jpunlimitedDF)
          .union(jplimitedDF)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, limitedAllDF, "闯行+未闯行数据")

        // 生产协助作业需要的数据
        val union_navidemoDF: DataFrame = limitedAllDF
          .filter("rmultipathpos != '' and rmultipathswid != ''")
          .withColumn("ft_url", lit(ft_url))
          .withColumn("tracks1", $"coords")
          .withColumn("tracks2", $"rcoords")
          .withColumnRenamed("groupby_id", "reqid")
          .withColumnRenamed("coords", "ft_coords")
          .withColumnRenamed("rcoords", "gd_coords")
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 查看样例数据
        GetDFCountAndSampleData(logger, union_navidemoDF, "union_navidemo")
        // 写入到 Hive
        df2HiveByOverwrite(logger, union_navidemoDF, "dm_gis.gd_breakpoint_union_navidemo")
        union_navidemoDF.unpersist()

        // 获取 swid、point
        val limitedAndSwidAndPointDS: Dataset[SwidPoint] = limitedAllDF
          .filter("rmultipathpos != '' and rmultipathswid != ''")
          .filter(r => {
              val rmultipathpos: String = r.getAs[String]("rmultipathpos")
              val rmultipathswid: String = r.getAs[String]("rmultipathswid")

              val posLen: Int = rmultipathpos.split("\\|", -1).length
              val swidLen: Int = rmultipathswid.split("\\|", -1).length

              if (posLen == swidLen) true else false
          })
          .rdd
          .repartition(5)
          .flatMap(r => {
              val swidAndPoint: ListBuffer[SwidPoint] = get_swid_and_point(r)
              swidAndPoint
          })
          .toDS()
          .filter(r => r.adcode != "")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDSCountAndSampleData(logger,limitedAndSwidAndPointDS,"limitedAndSwidAndPointDS 数据")

        // 写入到 Hive
        logger.error("开始写入到 Hive：dm_gis.gd_breakpoint_union_match")
        limitedAndSwidAndPointDS
          .write
          .mode(SaveMode.Overwrite)
          .insertInto("dm_gis.gd_breakpoint_union_match")
        logger.error("写入到 Hive：dm_gis.gd_breakpoint_union_match 成功！")

        // 根据 swid，next_swid和pointType 进行聚合

        // 处理纠偏的数据
        val ruleroadidDF: DataFrame = limitedAndSwidAndPointDS
          .filter("data_source = '0'")
          .select("groupby_id", "swid", "point", "uuid", "coords", "jp_swid", "jp_status")

        val pointDF: DataFrame = limitedAndSwidAndPointDS
          .filter("data_source = '0'")
          .select("groupby_id", "next_swid", "next_point", "uuid", "coords", "jp_swid", "jp_status")

        val ruleroadidAndPointDF: DataFrame = ruleroadidDF
          .union(pointDF)
          .toDF("groupby_id", "ruleroadid", "rulepos", "uuid", "coords", "jp_swid", "jp_status")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // ruleroadidAndPoint 数据
        GetDFCountAndSampleData(logger, ruleroadidAndPointDF, "ruleroadidAndPoint 数据")

        // 每个ruleroadid 对应的数量
        val ruleroadidDF2: DataFrame = ruleroadidAndPointDF
          .rdd
          .map(r => {
              val ruleroadid: String = r.getAs[String]("ruleroadid")
              (ruleroadid, r)
          })
          .groupByKey()
          .flatMap(r => {
              val rows: Iterable[Row] = r._2
              val cnt: Int = r._2.size

              val groupby_idSet: mutable.HashSet[String] = new mutable.HashSet[String]
              for (r <- rows) {
                  val groupby_id: String = r.getAs[String]("groupby_id")
                  groupby_idSet.add(groupby_id)
              }
              val buff: ListBuffer[(String, Int)] = new ListBuffer[(String, Int)]
              val arr: Array[String] = groupby_idSet.toArray
              for (i <- arr.indices) buff.append((arr(i), cnt))
              buff
          })
          .toDF("groupby_id", "cnt")
          .filter("cnt < 10")

        // 剔除 cnt 小于10之后的groupby_id 数据，再找到 mark in(1,2,3) 的那些数据
        val ruleroadidAndPointDF2: DataFrame = ruleroadidAndPointDF
          .join(ruleroadidDF2, Seq("groupby_id"), "leftanti")
          .map(r => {
              val groupby_id: String = r.getAs[String]("groupby_id")
              val rulepos: String = r.getAs[String]("rulepos")
              val tp: (String, Double, Double, Double, Double, Int, BigDecimal, Double, Double) = getDistAndPointAndMark(r)
              (groupby_id, rulepos, tp._6)
          })
          .toDF("groupby_id", "rulepos", "mark")
          .filter("mark in(1,2,3)")
          .join(limitedAndSwidAndPointDS, Seq("groupby_id"), "right")
          .filter("mark is null")
          .drop("rulepos", "mark")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 查看样例数据
        GetDFCountAndSampleData(logger, ruleroadidAndPointDF2, "纠偏的数据")

        // 纠偏的数据  获取swids_freq
        val swid_freqDF1: DataFrame = ruleroadidAndPointDF2
          .groupByKey(r => {
              val inc_day: String = r.getAs[String]("inc_day")
              val swid: String = r.getAs[String]("swid")
              val next_swid: String = r.getAs[String]("next_swid")
              val points_type: String = r.getAs[String]("points_type")
              val point: String = r.getAs[String]("point")
              val next_point: String = r.getAs[String]("next_point")
              val data_source: String = r.getAs[String]("data_source")
              val city: String = r.getAs[String]("city")
              val version: String = r.getAs[String]("version")
              (inc_day, swid, next_swid, points_type, point, next_point, data_source, city, version)
          })
          .count()
          .map(r => {
              val (inc_day, swid, next_swid, points_type, point, next_point, data_source, city, version) = r._1
              val swids_freq: Long = r._2
              (swid, next_swid, point, next_point, points_type, data_source, swids_freq, swids_freq, city, version, inc_day)
          })
          .toDF("swid", "next_swid", "point", "next_point", "points_type", "data_source", "swids_freq", "points_freq", "city", "version", "inc_day")


        // 规划的数据  获取swids_freq
        val swid_freqDF2: DataFrame = limitedAndSwidAndPointDS
          .filter("data_source = '2'")
          .groupByKey(r => (r.inc_day, r.swid, r.next_swid, r.points_type, r.point, r.next_point, r.data_source, r.city, r.version))
          .count()
          .map(r => {
              val (inc_day, swid, next_swid, points_type, point, next_point, data_source, city, version) = r._1
              val swids_freq: Long = r._2
              (swid, next_swid, point, next_point, points_type, data_source, swids_freq, swids_freq, city, version, inc_day)
          })
          .toDF("swid", "next_swid", "point", "next_point", "points_type", "data_source", "swids_freq", "points_freq", "city", "version", "inc_day")


        // 合并在一起
        val ruleroadidAndPointResultDF: DataFrame = swid_freqDF1.union(swid_freqDF2)

        // 已经下发过的 swid 和 points
        val thirtyAgoSwid: DataFrame = getDataFrame(logger,spark,gdBreakpointSwindSql)

        // 合并在一起，然后 过滤已经下发过的数据
        val groupbyDF: DataFrame = limitedAndSwidAndPointDS.select("swid", "next_swid", "groupby_id","adcode")

        val swidFreAndPointsFreDF: Dataset[Row] = groupbyDF
          .join(ruleroadidAndPointResultDF, Seq("swid", "next_swid"))
          .join(thirtyAgoSwid, Seq("swid", "next_swid"), "leftanti")
          .dropDuplicates("swid", "next_swid")
          .coalesce(300)
          .persist(StorageLevel.MEMORY_AND_DISK)


        // 查看样例数据
        GetDFCountAndSampleData(logger, swidFreAndPointsFreDF, "swidFreAndPointsFre")
        // 写入到 Hive
        df2HiveByOverwrite(logger, swidFreAndPointsFreDF, "dm_gis.all_result_gd_breakpoint_swid_info")

        limitedAndSwidAndPointDS.unpersist()
        swidFreAndPointsFreDF.unpersist()


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 获取swid、next_swid、point、next_pint、adcode 的值
    def get_swid_and_point(r: Row): ListBuffer[SwidPoint] = {
        val groupby_id: String = r.getAs[String]("groupby_id")
        val uuid: String = r.getAs[String]("uuid")
        val data_source: String = r.getAs[String]("data_source")
        val d_plan_order: Int = r.getAs[Int]("d_plan_order")
        val coords: String = r.getAs[String]("coords")
        val rcoords: String = r.getAs[String]("rcoords")
        val rmultipathpos: String = r.getAs[String]("rmultipathpos")
        val rmultipathswid: String = r.getAs[String]("rmultipathswid")
        val start_dept: String = r.getAs[String]("start_dept")
        val end_dept: String = r.getAs[String]("end_dept")
        val start_longitude: String = r.getAs[String]("start_longitude")
        val end_longitude: String = r.getAs[String]("end_longitude")
        val start_latitude: String = r.getAs[String]("start_latitude")
        val end_latitude: String = r.getAs[String]("end_latitude")
        val jp_status: String = r.getAs[String]("jp_status")
        val jp_swid: String = r.getAs[String]("jp_swid")
        val city: String = r.getAs[String]("city")
        val version: String = r.getAs[String]("version")
        val inc_day: String = r.getAs[String]("inc_day")

        val pointBuff: ListBuffer[String] = new ListBuffer[String]
        val swidBuff: ListBuffer[String] = new ListBuffer[String]
        val next_pointBuff: ListBuffer[String] = new ListBuffer[String]
        val next_swidBuff: ListBuffer[String] = new ListBuffer[String]


        val posArr: Array[String] = rmultipathpos.split("\\|", -1)
        val swidArr: Array[String] = rmultipathswid.split("\\|", -1)

        for (i <- posArr.indices) {
            if (i != posArr.length - 1) {
                pointBuff.append(posArr(i).split("_", -1)(1))
                swidBuff.append(swidArr(i).split("_", -1)(1))
            }

            if (i != 0) {
                next_pointBuff.append(posArr(i).split("_", -1)(0))
                next_swidBuff.append(swidArr(i).split("_", -1)(0))
            }
        }

        val firstSwid: String = swidArr(0).split("_", -1)(0)
        val lastSwid: String = swidArr(swidArr.length - 1).split("_", -1)(1)

        val allBuff: ListBuffer[SwidPoint] = new ListBuffer[SwidPoint]
        var points_type: String = "0"
        for (i <- swidBuff.indices) {
            val swid: String = swidBuff(i)
            val next_swid: String = next_swidBuff(i)
            val point: String = pointBuff(i)
            val next_point: String = next_pointBuff(i)

            if (swid == next_swid && swid == firstSwid) points_type = "1"
            else if (swid == next_swid && swid == lastSwid) points_type = "2"
            else if (point == next_point) points_type = "3"

            var adcode: String = ""
            if (swid != null && swid.nonEmpty) {
                val json: JSONObject = callMatchService(swid)
                val tp: (String, String) = getMatchAbnormalData(json)
                adcode = tp._1

            }

            allBuff.append(
                SwidPoint(groupby_id, uuid, data_source, d_plan_order, coords, rcoords, rmultipathpos, rmultipathswid, swid, next_swid, point,
                    next_point, points_type, start_dept, end_dept, start_longitude, end_longitude, start_latitude, end_latitude, jp_status, jp_swid, city, version, adcode, inc_day)
            )
        }

        allBuff
    }


}
