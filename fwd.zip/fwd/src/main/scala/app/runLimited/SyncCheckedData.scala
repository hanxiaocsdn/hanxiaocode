package app.runLimited

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByAppend}
import utils.SparkConfigUtil

/**
  * 同步每日下发的核实结果数据 到相应的分区中去
  */
object SyncCheckedData {

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 获取每日的核实结果
        val checkedSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_aggre_data_checked_result_info_his
               |where
               |  dt >= '$start_time'
               |  and dt < '$end_time'
               |""".stripMargin

        logger.error(checkedSql)

        // 获取每日的核实结果
        val checkedDF: DataFrame = spark.sql(checkedSql)
          .drop("dt")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, checkedDF, "核实结果")

        // 同步到相应的分区里去
        logger.error("开始同步数据到hive：dm_gis.mms_car_route_aggre_data_checked_result_info")
        df2HiveByAppend(logger,checkedDF,"dm_gis.mms_car_route_aggre_data_checked_result_info")

        checkedDF.unpersist()

        logger.error("运行结束！")

        // 程序运行结束
        spark.stop()
    }

}
