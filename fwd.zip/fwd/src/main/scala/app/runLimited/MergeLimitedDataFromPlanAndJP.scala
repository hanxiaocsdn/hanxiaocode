package app.runLimited

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getDataFrame}
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable.ListBuffer

/**
  * 讲 规划 和 纠偏闯行的最终数据合并在一起,调用匹配接口，获取adcode 和 pline
  *
  * 规划 + 纠偏 最终的闯行数据合并,获取adcode 和 pline
  */
object MergeLimitedDataFromPlanAndJP {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)


        // 1. 获取 data_source = 1或2 的数据 【规划的数据】
        val sql1: String =
            s"""
               |select
               |  concat(uuid,'_', data_source,'_', d_plan_order,'_',ruleroadid) as mynew,
               |  '' as angle,
               |  '' as existlimit,
               |  '' as lineid,
               |  '' as linkid,
               |  '' as mark_jp,
               |  '' as originroadclasslist,
               |  '' as srcidfrom,
               |  '' as srcid,
               |  uuid,data_source,d_plan_order,rulepos,
               |  '' as r_status,
               |  '' as r_origin,
               |  '' as r_destination,
               |  '' as r_flen,
               |  '' as r_tlen,
               |  0 as r_distance,
               |  0.0 as r_duration,
               |  0 as r_highspeed_distance,
               |  0 as r_trafficlight_count,
               |  0 as r_tolls,
               |  0 as r_etc_toll,
               |  0 as r_toll_distance,
               |  '' as r_links_union,
               |  '' as r_rc_distance,
               |  d_url,d_status,d_dist,d_time,d_tolls,d_src,d_flen,d_tlen,d_query,coords,d_highway,
               |  d_tralightcount,task_id,start_dept,end_dept,his_coords,start_type,end_type,start_tm,
               |  end_tm,actual_run_time,plan_run_time,sort_num,start_longitude,end_longitude,start_latitude,
               |  end_latitude,line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,
               |  id,is_stop,ground_task_id,start_time,carrier_type,plf_flag,log_dist,line_distance,
               |  vehicle_serial2,hko_vehicle_code,trailer_vehicle_code,source,is_trailer,vehicle_type,
               |  vehicle_length,width,height,color,energy,license,emission,axls_number,vehicle_full_load_weight,
               |  vehicle_load_weight,line,xy,`order`,grp0,grp1,grp2,plandate,grp2_order,d_frequency,
               |  d_frequencycost,d_frequencytype,d_freqratio,d_route_id,d_src_routeids,flag,status,rdist,rtime,
               |  rhighway,rtralightcount,rtolls,rtollsdistance,qstartxy,qendxy,rcoords,rsteps,rflen,rtlen,
               |  rulecount,ruleorder,ruleid,ruletype,ruleroadid,ruleoutroadid,ruleroadname,limitweight,
               |  limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,
               |  limitvehicletype,limitoutflag,limitemitstand,limittailchar,limitstartdate,limitenddate,
               |  limitweek,limittime,guid,ruletimedesc,ruleregiondesc,rulevehicle,rulestrategy,mark_dist,
               |  min_dist,city,version,inc_day
               |from dm_gis.mms_car_route_plan_detail_and_limited_info_his
               |  where
               |    data_source in('1','2')
               |    and inc_day >= '$start_time'
               |    and inc_day < '$end_time'
               |""".stripMargin

        // 2. 获取data_source = 3 的数据 【规划的数据】
        val sql2: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_detail_and_limited_info_his2
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 3. 获取纠偏的闯行数据
        val sql3: String =
            s"""
               |--相同的字段：
               |select
               |  uuid,data_source,d_plan_order,rulepos,d_dist,mynew,angle,existlimit,lineid,linkid,mark_jp,
               |  originroadclasslist,srcidfrom,srcid,r_status,r_origin,r_destination,r_flen,r_tlen,r_distance,
               |  r_duration,r_highspeed_distance,r_trafficlight_count,r_tolls,r_etc_toll,r_toll_distance,
               |  r_links_union,r_rc_distance,start_dept,end_dept,his_coords,start_type,end_type,start_tm,
               |  end_tm,actual_run_time,plan_run_time,sort_num,start_longitude,end_longitude,start_latitude,
               |  end_latitude,line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,
               |  id,is_stop,ground_task_id,start_time,carrier_type,plf_flag,log_dist,line_distance,
               |  vehicle_serial2,hko_vehicle_code,trailer_vehicle_code,source,is_trailer,vehicle_type,
               |  vehicle_length,width,height,color,energy,license,emission,axls_number,vehicle_full_load_weight,
               |  vehicle_load_weight,line,xy,`order`,grp0,grp1,grp2,plandate,grp2_order,coords,flag,status,
               |  rdist,rtime,rhighway,rtralightcount,rtolls,rtollsdistance,qstartxy,qendxy,rcoords,rsteps,
               |  rflen,rtlen,rulecount,ruleorder,ruleid,ruletype,ruleroadid,ruleoutroadid,ruleroadname,
               |  limitweight,limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,
               |  limitvehicletype,limitoutflag,limitemitstand,limittailchar,limitstartdate,limitenddate,
               |  limitweek,limittime,guid,ruletimedesc,ruleregiondesc,rulevehicle,rulestrategy,mark_dist,
               |  min_dist,task_id,
               |-- 不同的字段
               |  ana_key,mark,jyrt_links_union,matched_jyrt_links_union,x1,y1,x2,y2,s_dist,jyrt_url,
               |  uuid2,his_abnormal,abnormal,jp_swid,jp_status,rows_cnt,cnt,
               |-- 新增的字段
               |  '' as d_url,
               |  '' as d_status,
               |  '' as d_time,
               |  '' as d_tolls,
               |  '' as d_src,
               |  '' as d_flen,
               |  '' as d_tlen,
               |  '' as d_query,
               |  '' as d_highway,
               |  '' as d_tralightcount,
               |  '' as d_frequency,
               |  '' as d_frequencycost,
               |  '' as d_frequencytype,
               |  '' as d_freqratio,
               |  '' as d_route_id,
               |  '' as d_src_routeids,
               |  city,version,inc_day
               |from
               |  dm_gis.mms_car_route_jp_detail_and_limited_info_his3
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 获取规划的数据
        val planLimitedDS2: DataFrame = getPlanLimitedData(logger,spark,sql1,sql2)

        // 获取纠偏的数据
        val jpLimitedDF: DataFrame = getDataFrame(logger,spark,sql3)

        // 规划的数据 和 纠偏的数据 合并在一起
        saveLimitedData2Hive(logger,spark,planLimitedDS2,jpLimitedDF)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 调用 匹配的接口，获取对应的数据
    def callMatchService(ruleroadid: String): JSONObject = {
        val sw_id: String = ruleroadid
        val date: String = ""

        val parm: String = s"date=$date&sw_id=$sw_id&test=1&stype=0&etype=0&passport=100000&mode=2&speed=1&Toll=1"
        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        val jsonObj: Object = mapData.get("content")

        var jsonStr:String=null
        if(jsonObj != null) jsonStr = jsonObj.toString
        var json: JSONObject = null

        try {
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:"+e.getMessage)
        }
        json
    }

    // 解析 匹配接口返回的json数据
    def getMatchAbnormalData(json: JSONObject): (String, String) = {
        var adcode: String = ""
        var pline: String = ""
        val polylineList: ListBuffer[String] = new ListBuffer[String]

        if(json != null){
            val status: String = json.getString("status")
            if (status == "0") {
                val route: JSONObject = json.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")
                if (paths != null && paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val path: JSONObject = paths.getJSONObject(i)

                        val polyline: String = path.getString("polyline")
                        polylineList.append(polyline)

                        val steps: JSONArray = path.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            for (j <- 0 until steps.size()) {
                                val step: JSONObject = steps.getJSONObject(j)
                                if (step != null && step.size() > 0) {
                                    val links: JSONArray = step.getJSONArray("links")
                                    if (links != null && links.size() > 0) {
                                        val link: JSONObject = links.getJSONObject(0)
                                        adcode = link.getString("adcode")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (polylineList != null && polylineList.nonEmpty) pline = polylineList.mkString(";")
        (adcode, pline)
    }

    def getAacodeAndPline: UserDefinedFunction = udf((ruleroadid: String, ruleoutroadid: String,city: String,version: String,inc_day: String) => {

        var adcode: String = ""
        var pline: String = ""
        var pline1: String = ""
        var pline2: String = ""
        if (ruleroadid != null && ruleroadid.nonEmpty) {
            val json: JSONObject = callMatchService(ruleroadid)
            val tp: (String, String) = getMatchAbnormalData(json)
            adcode = tp._1
            pline1 = tp._2
        }

        if (ruleoutroadid != null && ruleoutroadid.nonEmpty) {
            val json: JSONObject = callMatchService(ruleoutroadid)
            val tp: (String, String) = getMatchAbnormalData(json)
            pline2 = tp._2
        }

        if (pline2.nonEmpty) pline = pline1 + ";" + pline2 else pline = pline1
        (adcode, pline, city, version, inc_day)
    })

    def getPlanLimitedData(logger: Logger, spark:SparkSession, sql1:String, sql2:String):DataFrame={
        val df1: DataFrame = spark.sql(sql1)
        val df2: DataFrame = spark.sql(sql2)

        // 【规划的数据】 合并 2份数据
        val df3: Dataset[Row] = df1
          .union(df2)

        // 将规划的数据注册成临时表，进行字段调整，方便后面 和 纠偏的数据合并在一起
        df3.createOrReplaceTempView("mms_car_route_plan_detail_and_limited_info_his2_tmp")
        val origDataSql4: String =
            """
              |--相同的字段：
              |select
              |  uuid,data_source,d_plan_order,rulepos,d_dist,mynew,angle,existlimit,lineid,linkid,mark_jp,
              |  originroadclasslist,srcidfrom,srcid,r_status,r_origin,r_destination,r_flen,r_tlen,r_distance,
              |  r_duration,r_highspeed_distance,r_trafficlight_count,r_tolls,r_etc_toll,r_toll_distance,
              |  r_links_union,r_rc_distance,start_dept,end_dept,his_coords,start_type,end_type,start_tm,
              |  end_tm,actual_run_time,plan_run_time,sort_num,start_longitude,end_longitude,start_latitude,
              |  end_latitude,line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,
              |  id,is_stop,ground_task_id,start_time,carrier_type,plf_flag,log_dist,line_distance,
              |  vehicle_serial2,hko_vehicle_code,trailer_vehicle_code,source,is_trailer,vehicle_type,
              |  vehicle_length,width,height,color,energy,license,emission,axls_number,vehicle_full_load_weight,
              |  vehicle_load_weight,line,xy,`order`,grp0,grp1,grp2,plandate,grp2_order,coords,flag,status,
              |  rdist,rtime,rhighway,rtralightcount,rtolls,rtollsdistance,qstartxy,qendxy,rcoords,rsteps,
              |  rflen,rtlen,rulecount,ruleorder,ruleid,ruletype,ruleroadid,ruleoutroadid,ruleroadname,
              |  limitweight,limitsize,limitwidth,limitaxload,limitload,limitaxcnt,limitpassport,limitholiday,
              |  limitvehicletype,limitoutflag,limitemitstand,limittailchar,limitstartdate,limitenddate,
              |  limitweek,limittime,guid,ruletimedesc,ruleregiondesc,rulevehicle,rulestrategy,mark_dist,
              |  min_dist,task_id,
              |  -- 新增的字段
              |  '' as ana_key,
              |  -1 as mark,
              |  '' as jyrt_links_union,
              |  '' as matched_jyrt_links_union,
              |  '' as x1,
              |  '' as y1,
              |  '' as x2,
              |  '' as y2,
              |  '' as s_dist,
              |  '' as jyrt_url,
              |  regexp_replace(uuid,'_','') as uuid2,
              |  '' as his_abnormal,
              |  '' as abnormal,
              |  '' as jp_swid,
              |  '' as jp_status,
              |  0 as rows_cnt,
              |  0 as cnt,
              |  -- 相同的的字段
              |  d_url,d_status,d_time,d_tolls,d_src,d_flen,d_tlen,d_query,d_highway,d_tralightcount,
              |  d_frequency,d_frequencycost,d_frequencytype,d_freqratio,d_route_id,d_src_routeids,
              |  city,version,inc_day
              |from
              |  mms_car_route_plan_detail_and_limited_info_his2_tmp
              |""".stripMargin

        val planLimited: DataFrame = getDataFrame(logger,spark,origDataSql4)
        planLimited
    }

    def saveLimitedData2Hive(logger: Logger,spark:SparkSession,planLimitedDS2:DataFrame,jpLimitedDF:DataFrame): Unit ={
        import spark.implicits._

        val allLimitedAndAdcodePlineDF: DataFrame = planLimitedDS2
          .union(jpLimitedDF)
          .repartition(10)
          .withColumn("ap", getAacodeAndPline($"ruleroadid", $"ruleoutroadid", $"city", $"version", $"inc_day"))
          .drop("city", "version", "inc_day")
          .withColumn("adcode", $"ap._1")
          .withColumn("pline", $"ap._2")
          .withColumn("city", $"ap._3")
          .withColumn("version", $"ap._4")
          .withColumn("inc_day", $"ap._5")
          .drop("ap")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, allLimitedAndAdcodePlineDF, "调用接口过后最终的数据")

        // 所有的闯行数据 写入hive
        df2HiveByOverwrite(logger,allLimitedAndAdcodePlineDF,"dm_gis.mms_car_route_plan_and_jp_limited_result_info")

        planLimitedDS2.unpersist()
        jpLimitedDF.unpersist()
    }

}
