package com.sf.gis.scala.rds.app

import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 *
 * Created by 01417629 on 2021-12-02
 */
//noinspection DuplicatedCode
object UpdateAddrMd5AoiCheck {
  @transient lazy val logger: Logger = Logger.getLogger(UpdateAddrMd5AoiCheck.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val updateAddrMd5AoiCheck_url = "http://gisasscmsbgintface-gis-ass-cms.dcn2.k8s.sfcloud.local:1080/cms/api/address/updateAddrMd5AoiCheck"
  val limitMin = 50000 / 10


  def main(args: Array[String]): Unit = {
    val spark =  Spark.getSparkSession(appName)
    val parDay_1 = args(0)
    val cnyzAoiPath = args(1)
    run(spark, parDay_1, cnyzAoiPath)
    spark.close()
  }


  def run(spark: SparkSession, parDay_1: String, cnyzAoiPath: String): Unit = {
    val res = updateAddress(spark, cnyzAoiPath)
    saveResult2Hive(spark, res, parDay_1)
    res.unpersist()
  }

  def updateAddress(spark: SparkSession, cnyzAoiPath: String): RDD[JSONObject] = {
    val df = spark.read
      .option("inferschema", "false")
      .option("header", false)
      .option("encoding", "UTF-8")
      .csv(cnyzAoiPath)
      .toDF("aoiCheckTag", "addressMd5s", "cityCode")
      .persist(StorageLevel.MEMORY_AND_DISK)
    df.show(5)
    println(df.count())
    val res = df.rdd.map(obj => {
      val json = new JSONObject()
      val aoiCheckTag = obj.getString(0)
      val addressMd5s = obj.getString(1)
      val cityCode = obj.getString(2)
      json.put("aoiCheckTag", aoiCheckTag)
      json.put("addressMd5s", addressMd5s)
      json.put("cityCode", cityCode)
      json
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val aoiCheckTag = JSONUtil.getJsonVal(o, "aoiCheckTag", "")
        val groupid1 = JSONUtil.getJsonVal(o, "addressMd5s", "")
        var cityCode = JSONUtil.getJsonVal(o, "cityCode", "")
        if(cityCode.nonEmpty && cityCode.length == 2){
          cityCode = "0" + cityCode
        }
        val jsonObject = new JSONObject()
        jsonObject.put("cityCode", cityCode)
        jsonObject.put("aoiCheckTag", aoiCheckTag)
        jsonObject.put("addressMd5s", Array(groupid1))
        val toJSONString = jsonObject.toJSONString
        val json: JSONObject = updateAoiCheck(updateAddrMd5AoiCheck_url, toJSONString)
        if (json != null) {
          val success = JSONUtil.getJsonVal(json, "success", "")
          val message = JSONUtil.getJsonVal(json, "message", "")
          if (success == "true" || success == "True") {
            o.put("updateaoicheck_result", "True")
          } else if (success == "false" || success == "False") {
            o.put("updateaoicheck_result", message)
          } else {
            o.put("updateaoicheck_result", json.toJSONString)
          }
        } else {
          o.put("updateaoicheck_result", "null")
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>res共 ${res.count()} 条s<<<")
    res
  }

  def updateAoiCheck(url: String, toJSONString: String): JSONObject = {
    var ret: JSONObject = new JSONObject()
    try {
      if (!toJSONString.isEmpty) {
        val response = HttpInvokeUtil.sendPost(url, toJSONString, FixedConstant.MAX_TRY_TIME_ONCE)
        if (response != null) {
          ret = JSONUtil.parseStr2Json(response)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  /**
   * 写入Hive表
   *
   * @param spark
   */
  def saveResult2Hive(spark: SparkSession, ret: RDD[JSONObject], parDay_1: String): Unit = {
    val descDBName = "dm_gis"
    val descTableName = "update_addr_md5_aoi_check"
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION (inc_day = '$parDay_1')
         |SELECT
         |	 *
         |FROM update_addr_md5_aoi_check_tmp
         |""".stripMargin
    try {
      val schemaString = "aoiCheckTag,addressMd5s,cityCode,updateaoicheck_result"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
      )
      val schema = StructType(fields)
      val rdd = ret.coalesce(1).map(obj => {
        val sb = new StringBuilder()
        sb.append(obj.getString("aoiCheckTag")).append("\t\t\t")
        sb.append(obj.getString("addressMd5s")).append("\t\t\t")
        sb.append(obj.getString("cityCode")).append("\t\t\t")
        sb.append(obj.getString("updateaoicheck_result")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3)))
      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.createOrReplaceTempView("update_addr_md5_aoi_check_tmp")
      df.show(5)
      //插入数据
      logger.error(">>>>>>>>>>入hive库开始")
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }


}
