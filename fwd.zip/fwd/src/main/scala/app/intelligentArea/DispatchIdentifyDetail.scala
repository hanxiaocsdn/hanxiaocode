package app.intelligentArea

import com.alibaba.fastjson.JSONObject
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.SparkConfigUtil
import java.sql.{Connection, PreparedStatement}
import java.sql.{Connection, PreparedStatement}

import com.sf.gis.scala.base.spark.Spark
import org.apache.commons.lang.StringUtils

/**
  * 任务名称：派件识别率明细报表
  * 任务ID：485180
  * 需求人员：潘文辉 01425213
  * 开发人员：王冬冬 01413698
  */
object DispatchIdentifyDetail {

  // 初始化
  val className: String = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)

  // mysql的参数
  val driver = "com.mysql.jdbc.Driver"
  val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useUnicode=true&amp;characterEncoding=utf-8"
  val userName = "gis_oms_rds"
  val passWd = "gis_oms_rds@123@"

  def main(args: Array[String]): Unit = {

    if (args.length != 1) {
      logger.error(
        """
          |需要输入1个参数：
          |    inc_day
          |""".stripMargin)
      sys.exit(-1)
    }

    // 接收外部传递进来的变量
    val inc_day: String = args(0)
    //        val inc_day: String = "20220919"
    logger.error(s"取数日期:$inc_day")

    // 创建spark
    val spark: SparkSession = Spark.getSparkSession("DispatchIdentifyDetail")

    // 数据初始化
    val origRDD: RDD[JSONObject] = getOrigData(spark, inc_day)

    // 派件识别率汇总指标
    val dispaIndexDF: DataFrame = getDispaIndex(spark, origRDD, inc_day)

    // 指标写入到MySQL
    //DispaToMysql(dispaIndexDF: DataFrame)

    dispaIndexDF.unpersist()

    logger.error("运行结束！")

    // 程序运行结束,关闭spark
    spark.stop()
  }

  // 数据初始化
  def getOrigData(spark: SparkSession, inc_day: String): RDD[JSONObject] = {
    import spark.implicits._

    val seven_day_before: String = getdaysBeforeOrAfter(inc_day, -7)

    val two_day_after: String = getdaysBeforeOrAfter(inc_day, 1)

    val aoiSql: String =
      s"""
         |select
         |  req_waybillno,
         |  finalaoicode,
         |  gisaoicode,
         |  ksaoicode,
         |  gisaoisrc,
         |  finalaoiby,
         |  splitresult,
         |  gis_to_sys_groupid,
         |  req_destcitycode as citycode
         |from
         |  dm_gis.aoi_recognition_rate_delivery_dimensionality_detail_di
         |where
         |  inc_day = '$inc_day'
         |""".stripMargin
    val omsSql: String =
      s"""
         |select
         |  req_waybillno,
         |  finalaoidetailsrc,
         |  req_time
         |from
         |  dm_gis.gis_rds_omsto
         |where
         |  inc_day >= '$seven_day_before'
         |  and inc_day <= '$inc_day'
         |  and req_waybillno != ''
         |  and req_comp_name != 'baison'
         |""".stripMargin
    val ttSql: String =
      s"""
         |select
         |  waybill_no as req_waybillno,
         |  order_type,
         |  modified_tm
         |from
         |  --dm_gis.tt_waybill_info
         |  dm_gis.dwd_waybill_info_dtl_di
         |where
         |  inc_day >= '$seven_day_before'
         |  and inc_day <= '$inc_day'
         |""".stripMargin
    /*val citySql: String =
      s"""
         |select b.area,a.region,a.city,a.citycode from
         |(select dist_code as citycode,area_name as region,city_name as city from dim.dim_city_info_df where inc_day ='$two_day_after' and dist_code regexp '^\\\\d{3,4}$$') a
         |left join (select citycode,area from dm_gis.citycode_area_map) b on a.citycode=b.citycode
              """.stripMargin*/
    val citySql: String =
      s"""
         |select b.area,a.region,a.city,a.citycode from
         |(select dist_code as citycode,area_name as region,city_name as city from dm_gis.dim_city_info_df where inc_day ='$two_day_after') a
         |left join
         |(select citycode,area from dm_gis.citycode_area_map) b
         |on a.citycode=b.citycode
              """.stripMargin
    //      |where
    //        |  city not in('台湾','澳门特别行政区','香港特别行政区','铁岭市','抚顺市','眉山市','资阳市','咸阳市','辛集市','保定市','焦作市','亳州市','神农架林区','潜江市','仙桃市','崇左市','来宾市','梧州市','贵港市','那曲地区','屯昌县','临高县','儋州市','琼海市','定安县','昌江黎族自治县','文昌市','澄迈县','琼中黎族苗族自治县','白沙黎族自治县','三沙市','东方市','乐东黎族自治县','陵水黎族自治县','万宁市','保亭黎族苗族自治县','五指山市','哈密地区','和田地区','阿勒泰地区','博尔塔拉蒙古自治州','武威市','嘉峪关市','昌吉回族自治州','巴音郭楞蒙古自治州','阿克苏地区','喀什地区','伊犁哈萨克自治州')

    logger.error("派件明细数据：" + aoiSql)
    logger.error("派件日志数据：" + omsSql)
    logger.error("运单宽表数据：" + ttSql)
    logger.error("城市维表数据：" + citySql)

    val w1: WindowSpec = Window.partitionBy("req_waybillno").orderBy($"modified_tm".desc)
    val w2: WindowSpec = Window.partitionBy("req_waybillno").orderBy($"req_time".desc)
    val aoiDF: DataFrame = spark.sql(aoiSql)
    val ttDF: DataFrame = spark.sql(ttSql)
      .withColumn("rk", row_number() over w1)
      .filter("rk = 1")

    val omsDF: DataFrame = spark.sql(omsSql)
      .withColumn("rn", row_number() over w2)
      .filter("rn = 1")

    val cityDF: DataFrame = spark.sql(citySql)

    val origRDD: RDD[JSONObject] = aoiDF
      .join(omsDF, Seq("req_waybillno"), "left")
      .join(ttDF, Seq("req_waybillno"), "left")
      .join(cityDF, Seq("citycode"))
      .withColumn("ordertype", when($"order_type" === "CX", "CX").otherwise("非CX"))
      .rdd
      .map(row2Json)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetRDDCountAndSampleData(logger, origRDD, "初始化数据")
    origRDD
  }

  // 派件识别率汇总指标
  def getDispaIndex(spark: SparkSession, origRDD: RDD[JSONObject], inc_day: String): DataFrame = {

    val cityDF: DataFrame = getCityIndex(spark, origRDD, inc_day)
    val regionDF: DataFrame = getRegionIndex(spark, cityDF, inc_day)
    val areaDF: DataFrame = getAreaIndex(spark, regionDF, inc_day)
    val allDF: DataFrame = getALLIndex(spark, areaDF, inc_day)

    val dispaIndexDF: Dataset[Row] = cityDF
      .union(regionDF)
      .union(areaDF)
      .union(allDF)
      .coalesce(1)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, dispaIndexDF, "派件识别率汇总指标")
    df2HiveByOverwrite(logger, dispaIndexDF, "dm_gis.dispatch_idenfify_index")

    dispaIndexDF
  }

  // 派件指标写入到MySQL
  def DispaToMysql(dispaIndexDF: DataFrame): Unit = {
    logger.error("开始写入到MySQL……")
    dispaIndexDF.rdd
      .foreachPartition(iter => {
        Class.forName(driver)
        val connection: Connection = java.sql.DriverManager.getConnection(url, userName, passWd)
        iter.foreach(r => {
          val id: String = r.getAs[String]("uid")
          val del_sql: String = s"delete from SA_AOI_REC_DETAIL_PJ where id =?"
          val statement0: PreparedStatement = connection.prepareStatement(del_sql)
          statement0.setString(1, id)
          statement0.executeUpdate()
          statement0.close()

          val insert_sql: String = "insert into SA_AOI_REC_DETAIL_PJ(id,order_type,stat_type,stat_type_content,statdate,area,region,city,city_code,dispatch_cnt,dispatch_identify_cnt,system_identify_cnt,gis_identify_cnt,ks_identify_cnt,split_cnt,big_group_cnt,tc2_cnt,norm_cnt,chk_cnt,monthacc_cnt,dispatch_norm_cnt,dispatch_normhp_cnt,dispatch_chkn_cnt,dispatch_tc2_cnt,dispatch_road_cnt,dispatch_phone_cnt,dispatch_normhphd_cnt,dispatch_normcompany_cnt,n1_cnt,n2_cnt,n3_cnt,n4_cnt,n5_cnt,y1_cnt,y2_cnt,y3_cnt,y4_cnt,y5_cnt,ks12_cnt,tsxy3_cnt,tsxy4_cnt,tsxy5_cnt,company_cnt,tcmodel_cnt,standard_cnt,translate_cnt,tel_his_cnt,gd_poi_cnt,aoi_name_cnt,address80_n_cnt,address80_y_cnt,aoi_80_recent_cnt,aoi_80_similar_rate_cnt,aoi_80_similar_unique_cnt) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
          val statement: PreparedStatement = connection.prepareStatement(insert_sql)

          val arr: Array[String] = Array("uid", "ordertype", "stat_type", "stat_type_content", "inc_day", "area", "region", "city", "citycode")
          for (i <- arr.indices) statement.setString(1 + i, r.getAs[String](arr(i)))

          val fieldArr: Array[String] = Array("dispatch_cnt", "dispatch_identify_cnt", "system_identify_cnt", "gis_identify_cnt", "ks_identify_cnt", "split_cnt", "big_group_cnt", "tc2_cnt", "norm_cnt", "chk_cnt", "monthacc_cnt", "dispatch_norm_cnt", "dispatch_normhp_cnt", "dispatch_chkn_cnt", "dispatch_tc2_cnt", "dispatch_road_cnt", "dispatch_phone_cnt", "dispatch_normhphd_cnt", "dispatch_normcompany_cnt", "n1_cnt", "n2_cnt", "n3_cnt", "n4_cnt", "n5_cnt", "y1_cnt", "y2_cnt", "y3_cnt", "y4_cnt", "y5_cnt", "ks12_cnt", "tsxy3_cnt", "tsxy4_cnt", "tsxy5_cnt", "company_cnt", "tcmodel_cnt", "standard_cnt", "translate_cnt", "tel_his_cnt", "gd_poi_cnt", "aoi_name_cnt", "address80_n_cnt", "address80_y_cnt", "aoi_80_recent_cnt", "aoi_80_similar_rate_cnt", "aoi_80_similar_unique_cnt")
          for (i <- fieldArr.indices) statement.setLong(10 + i, r.getAs[Long](fieldArr(i)))

          statement.executeUpdate()
          statement.close()
        })

        connection.close()
      })

    logger.error("成功写入到MySQL！")

  }

  // gis识别
  def getGisIdetify(arr: Array[JSONObject], gisaoisrc: String = "all"): Int = {
    if (gisaoisrc == "all") arr.count(o => !isEmptyOrNull(o.getString("gisaoicode")))
    else arr.count(o => !isEmptyOrNull(o.getString("gisaoicode")) && o.getString("gisaoisrc") == gisaoisrc)
  }

  // gis识别明细
  def getgisIdetifyDetail(arr: Array[JSONObject], o: JSONObject): Unit = {
    val tc2_cnt: Int = getGisIdetify(arr, "tc2")
    val norm_cnt: Int = getGisIdetify(arr, "norm")
    val chk_cnt: Int = getGisIdetify(arr, "chk-norm")
    val monthacc_cnt: Int = getGisIdetify(arr, "monthAcc")
    val dispatch_norm_cnt: Int = getGisIdetify(arr, "dispatch-norm")
    val dispatch_normhp_cnt: Int = getGisIdetify(arr, "normhp")
    val dispatch_chkn_cnt: Int = getGisIdetify(arr, "chkn")
    val dispatch_tc2_cnt: Int = getGisIdetify(arr, "dispatch-tc2")
    val dispatch_road_cnt: Int = getGisIdetify(arr, "road")
    val dispatch_phone_cnt: Int = getGisIdetify(arr, "phone")
    val dispatch_normhphd_cnt: Int = getGisIdetify(arr, "normhphd")
    val dispatch_normcompany_cnt: Int = getGisIdetify(arr, "normcompany")
    val dispatch_phone_tel_cnt: Int = getGisIdetify(arr, "phone-tel")
    val dispatch_phone_whitelist_cnt: Int = getGisIdetify(arr, "phone-whitelist")
    o.put("tc2_cnt", tc2_cnt)
    o.put("norm_cnt", norm_cnt)
    o.put("chk_cnt", chk_cnt)
    o.put("monthacc_cnt", monthacc_cnt)
    o.put("dispatch_norm_cnt", dispatch_norm_cnt)
    o.put("dispatch_normhp_cnt", dispatch_normhp_cnt)
    o.put("dispatch_chkn_cnt", dispatch_chkn_cnt)
    o.put("dispatch_tc2_cnt", dispatch_tc2_cnt)
    o.put("dispatch_road_cnt", dispatch_road_cnt)
    o.put("dispatch_phone_cnt", dispatch_phone_cnt)
    o.put("dispatch_normhphd_cnt", dispatch_normhphd_cnt)
    o.put("dispatch_normcompany_cnt", dispatch_normcompany_cnt)
    o.put("dispatch_phone_tel_cnt", dispatch_phone_tel_cnt)
    o.put("dispatch_phone_whitelist_cnt", dispatch_phone_whitelist_cnt)
  }

  // ks识别
  def getKsIdetify(arr: Array[JSONObject], finalaoidetailsrc: String = "all"): Int = {
    if (finalaoidetailsrc == "all") {
      arr.count(o =>
        o.getString("finalaoiby") == "ks" && !isEmptyOrNull(o.getString("ksaoicode"))
      )
    }
    else {
      arr.count(o =>
        o.getString("finalaoiby") == "ks" && o.getString("finalaoidetailsrc") == finalaoidetailsrc && !isEmptyOrNull(o.getString("ksaoicode"))
      )
    }
  }

  // ks识别明细
  def getksIdetifyDetail(arr: Array[JSONObject], o: JSONObject): Unit = {
    val n1_cnt: Int = getKsIdetify(arr, "N1")
    val n2_cnt: Int = getKsIdetify(arr, "N2")
    val n3_cnt: Int = getKsIdetify(arr, "N3")
    val n4_cnt: Int = getKsIdetify(arr, "N4")
    val n5_cnt: Int = getKsIdetify(arr, "N5")
    val y1_cnt: Int = getKsIdetify(arr, "Y1")
    val y2_cnt: Int = getKsIdetify(arr, "Y2")
    val y3_cnt: Int = getKsIdetify(arr, "Y3")
    val y4_cnt: Int = getKsIdetify(arr, "Y4")
    val y5_cnt: Int = getKsIdetify(arr, "Y5")
    val ks12_cnt: Int = getKsIdetify(arr, "KS12")
    val tsxy3_cnt: Int = getKsIdetify(arr, "tsxy-3")
    val tsxy4_cnt: Int = getKsIdetify(arr, "tsxy-4")
    val tsxy5_cnt: Int = getKsIdetify(arr, "tsxy-5")
    val company_cnt: Int = getKsIdetify(arr, "company")
    val tcmodel_cnt: Int = getKsIdetify(arr, "tcModel")
    val standard_cnt: Int = getKsIdetify(arr, "standard")
    val translate_cnt: Int = getKsIdetify(arr, "translate")
    val tel_his_cnt: Int = getKsIdetify(arr, "tel_His")
    val gd_poi_cnt: Int = getKsIdetify(arr, "gd_poi")
    val aoi_name_cnt: Int = getKsIdetify(arr, "aoi_name")
    val address80_n_cnt: Int = getKsIdetify(arr, "80_address_N")
    val address80_y_cnt: Int = getKsIdetify(arr, "80_address_Y")
    val aoi_80_recent_cnt: Int = getKsIdetify(arr, "aoi_80_recent")
    val aoi_80_similar_rate_cnt: Int = getKsIdetify(arr, "aoi_80_similar_rate")
    val aoi_80_similar_unique_cnt: Int = getKsIdetify(arr, "aoi_80_similar_unique")
    val aoiModel: Int = getKsIdetify(arr, "aoiModel")
    o.put("n1_cnt", n1_cnt)
    o.put("n2_cnt", n2_cnt)
    o.put("n3_cnt", n3_cnt)
    o.put("n4_cnt", n4_cnt)
    o.put("n5_cnt", n5_cnt)
    o.put("y1_cnt", y1_cnt)
    o.put("y2_cnt", y2_cnt)
    o.put("y3_cnt", y3_cnt)
    o.put("y4_cnt", y4_cnt)
    o.put("y5_cnt", y5_cnt)
    o.put("ks12_cnt", ks12_cnt)
    o.put("tsxy3_cnt", tsxy3_cnt)
    o.put("tsxy4_cnt", tsxy4_cnt)
    o.put("tsxy5_cnt", tsxy5_cnt)
    o.put("company_cnt", company_cnt)
    o.put("tcmodel_cnt", tcmodel_cnt)
    o.put("standard_cnt", standard_cnt)
    o.put("translate_cnt", translate_cnt)
    o.put("tel_his_cnt", tel_his_cnt)
    o.put("gd_poi_cnt", gd_poi_cnt)
    o.put("aoi_name_cnt", aoi_name_cnt)
    o.put("address80_n_cnt", address80_n_cnt)
    o.put("address80_y_cnt", address80_y_cnt)
    o.put("aoi_80_recent_cnt", aoi_80_recent_cnt)
    o.put("aoi_80_similar_rate_cnt", aoi_80_similar_rate_cnt)
    o.put("aoi_80_similar_unique_cnt", aoi_80_similar_unique_cnt)
    o.put("aoiModel", aoiModel)
  }

  // 获取最大的分词级别
  def getMaxSplitLevel(splitresult: String): Int = {
    var i: Int = 0
    try {
      i = splitresult
        .split(";")(0)
        .split("\\|")
        .map(r => {
          val k: Int = r.split("\\^")(1).toInt
          if (k > 99) k % 100 else k % 10
        })
        .max
    }
    catch {
      case e: Exception => logger.error("获取最大分词等级异常：" + splitresult + ";" + e.getMessage)
    }
    i
  }

  // region维度指标
  def getCityIndex(spark: SparkSession, origRDD: RDD[JSONObject], inc_day: String): DataFrame = {
    import spark.implicits._

    val groupDS: Dataset[String] = origRDD
      .groupBy(o => (
        "CITY",
        o.getString("ordertype"),
        o.getString("area"),
        o.getString("region"),
        o.getString("city"),
        o.getString("citycode")
      ))
      .map(r => {
        val (stat_type, ordertype, area, region, city, citycode) = r._1
        val arr: Array[JSONObject] = r._2.toArray

        val o: JSONObject = new JSONObject()
        o.put("stat_type", stat_type)
        o.put("stat_type_content", city)
        o.put("ordertype", ordertype)
        o.put("area", area)
        o.put("region", region)
        o.put("city", city)
        o.put("citycode", citycode)
        o.put("inc_day", inc_day)
        o.put("uid", ordertype + "_" + area + "_" + region + "_" + city + "_" + inc_day)

        // 派件总量
        o.put("dispatch_cnt", arr.length)

        // 派件识别量
        val dispatch_identify_cnt: Int = arr.count(o => !isEmptyOrNull(o.getString("finalaoicode")))
        o.put("dispatch_identify_cnt", dispatch_identify_cnt)

        // gis识别量
        val gis_identify_cnt: Int = getGisIdetify(arr)
        o.put("gis_identify_cnt", gis_identify_cnt)

        //ks识别量
        val ks_identify_cnt: Int = getKsIdetify(arr)
        o.put("ks_identify_cnt", ks_identify_cnt)

        // 系统识别量
        val system_identify_cnt: Int = arr.count(o => !isEmptyOrNull(o.getString("ksaoicode")) || !isEmptyOrNull(o.getString("gisaoicode")))
        o.put("system_identify_cnt", system_identify_cnt)

        // 分词地址不详
        val split_cnt: Int = arr.count(o => getMaxSplitLevel(o.getString("splitresult")) <= 10 && StringUtils.isEmpty(o.getString("ksaoicode")) && StringUtils.isEmpty(o.getString("gisaoicode")))
        o.put("split_cnt", split_cnt)

        // 匹配到大组来源非norm
        val gisSrcArr: Array[String] = Array("dispatch-norm", "normhp", "norm", "normhphd", "normcompany")
        val big_group_cnt: Int = arr.count(o => !StringUtils.isEmpty(o.getString("gis_to_sys_groupid")) && !gisSrcArr.contains(o.getString("gisaoisrc")) && StringUtils.isEmpty(o.getString("ksaoicode")) && StringUtils.isEmpty(o.getString("gisaoicode")))
        o.put("big_group_cnt", big_group_cnt)

        // gis识别量明细
        getgisIdetifyDetail(arr, o)

        // ks识别明细
        getksIdetifyDetail(arr, o)

        o.toJSONString
      })
      .toDS
      .persist(StorageLevel.MEMORY_AND_DISK)

    val cityDF: DataFrame = spark.read.json(groupDS)
      .select("uid", "stat_type", "stat_type_content", "ordertype", "area", "region", "city", "citycode", "dispatch_cnt", "dispatch_identify_cnt", "system_identify_cnt", "gis_identify_cnt", "ks_identify_cnt", "split_cnt", "big_group_cnt", "tc2_cnt", "norm_cnt", "chk_cnt", "monthacc_cnt", "dispatch_norm_cnt", "dispatch_normhp_cnt", "dispatch_chkn_cnt", "dispatch_tc2_cnt", "dispatch_road_cnt", "dispatch_phone_cnt", "dispatch_normhphd_cnt", "dispatch_normcompany_cnt", "n1_cnt", "n2_cnt", "n3_cnt", "n4_cnt", "n5_cnt", "y1_cnt", "y2_cnt", "y3_cnt", "y4_cnt", "y5_cnt", "ks12_cnt", "tsxy3_cnt", "tsxy4_cnt", "tsxy5_cnt", "company_cnt", "tcmodel_cnt", "standard_cnt", "translate_cnt", "tel_his_cnt", "gd_poi_cnt", "aoi_name_cnt", "address80_n_cnt", "address80_y_cnt", "aoi_80_recent_cnt", "aoi_80_similar_rate_cnt", "aoi_80_similar_unique_cnt","aoiModel","dispatch_phone_tel_cnt","dispatch_phone_whitelist_cnt", "inc_day")
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, cityDF, "[city]派件识别率指标")
    origRDD.unpersist()
    groupDS.unpersist()

    cityDF
  }

  // region维度指标
  def getRegionIndex(spark: SparkSession, cityDF: DataFrame, inc_day: String): DataFrame = {
    import spark.implicits._
    val regionDF: DataFrame = cityDF
      .groupBy("ordertype", "area", "region")
      .agg(
        sum("dispatch_cnt").as("dispatch_cnt"),
        sum("dispatch_identify_cnt").as("dispatch_identify_cnt"),
        sum("system_identify_cnt").as("system_identify_cnt"),
        sum("gis_identify_cnt").as("gis_identify_cnt"),
        sum("ks_identify_cnt").as("ks_identify_cnt"),
        sum("split_cnt").as("split_cnt"),
        sum("big_group_cnt").as("big_group_cnt"),
        sum("tc2_cnt").as("tc2_cnt"),
        sum("norm_cnt").as("norm_cnt"),
        sum("chk_cnt").as("chk_cnt"),
        sum("monthacc_cnt").as("monthacc_cnt"),
        sum("dispatch_norm_cnt").as("dispatch_norm_cnt"),
        sum("dispatch_normhp_cnt").as("dispatch_normhp_cnt"),
        sum("dispatch_chkn_cnt").as("dispatch_chkn_cnt"),
        sum("dispatch_tc2_cnt").as("dispatch_tc2_cnt"),
        sum("dispatch_road_cnt").as("dispatch_road_cnt"),
        sum("dispatch_phone_cnt").as("dispatch_phone_cnt"),
        sum("dispatch_normhphd_cnt").as("dispatch_normhphd_cnt"),
        sum("dispatch_normcompany_cnt").as("dispatch_normcompany_cnt"),
        sum("n1_cnt").as("n1_cnt"),
        sum("n2_cnt").as("n2_cnt"),
        sum("n3_cnt").as("n3_cnt"),
        sum("n4_cnt").as("n4_cnt"),
        sum("n5_cnt").as("n5_cnt"),
        sum("y1_cnt").as("y1_cnt"),
        sum("y2_cnt").as("y2_cnt"),
        sum("y3_cnt").as("y3_cnt"),
        sum("y4_cnt").as("y4_cnt"),
        sum("y5_cnt").as("y5_cnt"),
        sum("ks12_cnt").as("ks12_cnt"),
        sum("tsxy3_cnt").as("tsxy3_cnt"),
        sum("tsxy4_cnt").as("tsxy4_cnt"),
        sum("tsxy5_cnt").as("tsxy5_cnt"),
        sum("company_cnt").as("company_cnt"),
        sum("tcmodel_cnt").as("tcmodel_cnt"),
        sum("standard_cnt").as("standard_cnt"),
        sum("translate_cnt").as("translate_cnt"),
        sum("tel_his_cnt").as("tel_his_cnt"),
        sum("gd_poi_cnt").as("gd_poi_cnt"),
        sum("aoi_name_cnt").as("aoi_name_cnt"),
        sum("address80_n_cnt").as("address80_n_cnt"),
        sum("address80_y_cnt").as("address80_y_cnt"),
        sum("aoi_80_recent_cnt").as("aoi_80_recent_cnt"),
        sum("aoi_80_similar_rate_cnt").as("aoi_80_similar_rate_cnt"),
        sum("aoi_80_similar_unique_cnt").as("aoi_80_similar_unique_cnt"),
        sum("aoiModel").as("aoiModel"),
        sum("dispatch_phone_tel_cnt").as("dispatch_phone_tel_cnt"),
        sum("dispatch_phone_whitelist_cnt").as("dispatch_phone_whitelist_cnt")
      )
      .withColumn("city", lit("ALL"))
      .withColumn("citycode", lit("ALL"))
      .withColumn("stat_type", lit("REGION"))
      .withColumn("stat_type_content", $"region")
      .withColumn("inc_day", lit(inc_day))
      .withColumn("uid", concat_ws("_", $"ordertype", $"area", $"region", $"city", $"inc_day"))
      .select("uid", "stat_type", "stat_type_content", "ordertype", "area", "region", "city", "citycode", "dispatch_cnt", "dispatch_identify_cnt", "system_identify_cnt", "gis_identify_cnt", "ks_identify_cnt", "split_cnt", "big_group_cnt", "tc2_cnt", "norm_cnt", "chk_cnt", "monthacc_cnt", "dispatch_norm_cnt", "dispatch_normhp_cnt", "dispatch_chkn_cnt", "dispatch_tc2_cnt", "dispatch_road_cnt", "dispatch_phone_cnt", "dispatch_normhphd_cnt", "dispatch_normcompany_cnt", "n1_cnt", "n2_cnt", "n3_cnt", "n4_cnt", "n5_cnt", "y1_cnt", "y2_cnt", "y3_cnt", "y4_cnt", "y5_cnt", "ks12_cnt", "tsxy3_cnt", "tsxy4_cnt", "tsxy5_cnt", "company_cnt", "tcmodel_cnt", "standard_cnt", "translate_cnt", "tel_his_cnt", "gd_poi_cnt", "aoi_name_cnt", "address80_n_cnt", "address80_y_cnt", "aoi_80_recent_cnt", "aoi_80_similar_rate_cnt", "aoi_80_similar_unique_cnt","aoiModel","dispatch_phone_tel_cnt","dispatch_phone_whitelist_cnt", "inc_day")
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, regionDF, "[region]派件识别率指标")
    regionDF
  }

  // area维度指标
  def getAreaIndex(spark: SparkSession, regionDF: DataFrame, inc_day: String): DataFrame = {
    import spark.implicits._
    val areaDF: DataFrame = regionDF
      .groupBy("ordertype", "area")
      .agg(
        sum("dispatch_cnt").as("dispatch_cnt"),
        sum("dispatch_identify_cnt").as("dispatch_identify_cnt"),
        sum("system_identify_cnt").as("system_identify_cnt"),
        sum("gis_identify_cnt").as("gis_identify_cnt"),
        sum("ks_identify_cnt").as("ks_identify_cnt"),
        sum("split_cnt").as("split_cnt"),
        sum("big_group_cnt").as("big_group_cnt"),
        sum("tc2_cnt").as("tc2_cnt"),
        sum("norm_cnt").as("norm_cnt"),
        sum("chk_cnt").as("chk_cnt"),
        sum("monthacc_cnt").as("monthacc_cnt"),
        sum("dispatch_norm_cnt").as("dispatch_norm_cnt"),
        sum("dispatch_normhp_cnt").as("dispatch_normhp_cnt"),
        sum("dispatch_chkn_cnt").as("dispatch_chkn_cnt"),
        sum("dispatch_tc2_cnt").as("dispatch_tc2_cnt"),
        sum("dispatch_road_cnt").as("dispatch_road_cnt"),
        sum("dispatch_phone_cnt").as("dispatch_phone_cnt"),
        sum("dispatch_normhphd_cnt").as("dispatch_normhphd_cnt"),
        sum("dispatch_normcompany_cnt").as("dispatch_normcompany_cnt"),
        sum("n1_cnt").as("n1_cnt"),
        sum("n2_cnt").as("n2_cnt"),
        sum("n3_cnt").as("n3_cnt"),
        sum("n4_cnt").as("n4_cnt"),
        sum("n5_cnt").as("n5_cnt"),
        sum("y1_cnt").as("y1_cnt"),
        sum("y2_cnt").as("y2_cnt"),
        sum("y3_cnt").as("y3_cnt"),
        sum("y4_cnt").as("y4_cnt"),
        sum("y5_cnt").as("y5_cnt"),
        sum("ks12_cnt").as("ks12_cnt"),
        sum("tsxy3_cnt").as("tsxy3_cnt"),
        sum("tsxy4_cnt").as("tsxy4_cnt"),
        sum("tsxy5_cnt").as("tsxy5_cnt"),
        sum("company_cnt").as("company_cnt"),
        sum("tcmodel_cnt").as("tcmodel_cnt"),
        sum("standard_cnt").as("standard_cnt"),
        sum("translate_cnt").as("translate_cnt"),
        sum("tel_his_cnt").as("tel_his_cnt"),
        sum("gd_poi_cnt").as("gd_poi_cnt"),
        sum("aoi_name_cnt").as("aoi_name_cnt"),
        sum("address80_n_cnt").as("address80_n_cnt"),
        sum("address80_y_cnt").as("address80_y_cnt"),
        sum("aoi_80_recent_cnt").as("aoi_80_recent_cnt"),
        sum("aoi_80_similar_rate_cnt").as("aoi_80_similar_rate_cnt"),
        sum("aoi_80_similar_unique_cnt").as("aoi_80_similar_unique_cnt"),
        sum("aoiModel").as("aoiModel"),
        sum("dispatch_phone_tel_cnt").as("dispatch_phone_tel_cnt"),
        sum("dispatch_phone_whitelist_cnt").as("dispatch_phone_whitelist_cnt")
      )
      .withColumn("city", lit("ALL"))
      .withColumn("citycode", lit("ALL"))
      .withColumn("region", lit("ALL"))
      .withColumn("stat_type", lit("AREA"))
      .withColumn("stat_type_content", $"area")
      .withColumn("inc_day", lit(inc_day))
      .withColumn("uid", concat_ws("_", $"ordertype", $"area", $"region", $"city", $"inc_day"))
      .select("uid", "stat_type", "stat_type_content", "ordertype", "area", "region", "city", "citycode", "dispatch_cnt", "dispatch_identify_cnt", "system_identify_cnt", "gis_identify_cnt", "ks_identify_cnt", "split_cnt", "big_group_cnt", "tc2_cnt", "norm_cnt", "chk_cnt", "monthacc_cnt", "dispatch_norm_cnt", "dispatch_normhp_cnt", "dispatch_chkn_cnt", "dispatch_tc2_cnt", "dispatch_road_cnt", "dispatch_phone_cnt", "dispatch_normhphd_cnt", "dispatch_normcompany_cnt", "n1_cnt", "n2_cnt", "n3_cnt", "n4_cnt", "n5_cnt", "y1_cnt", "y2_cnt", "y3_cnt", "y4_cnt", "y5_cnt", "ks12_cnt", "tsxy3_cnt", "tsxy4_cnt", "tsxy5_cnt", "company_cnt", "tcmodel_cnt", "standard_cnt", "translate_cnt", "tel_his_cnt", "gd_poi_cnt", "aoi_name_cnt", "address80_n_cnt", "address80_y_cnt", "aoi_80_recent_cnt", "aoi_80_similar_rate_cnt", "aoi_80_similar_unique_cnt","aoiModel","dispatch_phone_tel_cnt","dispatch_phone_whitelist_cnt", "inc_day")
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, areaDF, "[area]派件识别率指标")
    areaDF
  }

  // all维度指标
  def getALLIndex(spark: SparkSession, areaDF: DataFrame, inc_day: String): DataFrame = {
    import spark.implicits._
    val allDF: DataFrame = areaDF
      .groupBy("ordertype")
      .agg(
        sum("dispatch_cnt").as("dispatch_cnt"),
        sum("dispatch_identify_cnt").as("dispatch_identify_cnt"),
        sum("system_identify_cnt").as("system_identify_cnt"),
        sum("gis_identify_cnt").as("gis_identify_cnt"),
        sum("ks_identify_cnt").as("ks_identify_cnt"),
        sum("split_cnt").as("split_cnt"),
        sum("big_group_cnt").as("big_group_cnt"),
        sum("tc2_cnt").as("tc2_cnt"),
        sum("norm_cnt").as("norm_cnt"),
        sum("chk_cnt").as("chk_cnt"),
        sum("monthacc_cnt").as("monthacc_cnt"),
        sum("dispatch_norm_cnt").as("dispatch_norm_cnt"),
        sum("dispatch_normhp_cnt").as("dispatch_normhp_cnt"),
        sum("dispatch_chkn_cnt").as("dispatch_chkn_cnt"),
        sum("dispatch_tc2_cnt").as("dispatch_tc2_cnt"),
        sum("dispatch_road_cnt").as("dispatch_road_cnt"),
        sum("dispatch_phone_cnt").as("dispatch_phone_cnt"),
        sum("dispatch_normhphd_cnt").as("dispatch_normhphd_cnt"),
        sum("dispatch_normcompany_cnt").as("dispatch_normcompany_cnt"),
        sum("n1_cnt").as("n1_cnt"),
        sum("n2_cnt").as("n2_cnt"),
        sum("n3_cnt").as("n3_cnt"),
        sum("n4_cnt").as("n4_cnt"),
        sum("n5_cnt").as("n5_cnt"),
        sum("y1_cnt").as("y1_cnt"),
        sum("y2_cnt").as("y2_cnt"),
        sum("y3_cnt").as("y3_cnt"),
        sum("y4_cnt").as("y4_cnt"),
        sum("y5_cnt").as("y5_cnt"),
        sum("ks12_cnt").as("ks12_cnt"),
        sum("tsxy3_cnt").as("tsxy3_cnt"),
        sum("tsxy4_cnt").as("tsxy4_cnt"),
        sum("tsxy5_cnt").as("tsxy5_cnt"),
        sum("company_cnt").as("company_cnt"),
        sum("tcmodel_cnt").as("tcmodel_cnt"),
        sum("standard_cnt").as("standard_cnt"),
        sum("translate_cnt").as("translate_cnt"),
        sum("tel_his_cnt").as("tel_his_cnt"),
        sum("gd_poi_cnt").as("gd_poi_cnt"),
        sum("aoi_name_cnt").as("aoi_name_cnt"),
        sum("address80_n_cnt").as("address80_n_cnt"),
        sum("address80_y_cnt").as("address80_y_cnt"),
        sum("aoi_80_recent_cnt").as("aoi_80_recent_cnt"),
        sum("aoi_80_similar_rate_cnt").as("aoi_80_similar_rate_cnt"),
        sum("aoi_80_similar_unique_cnt").as("aoi_80_similar_unique_cnt"),
        sum("aoiModel").as("aoiModel"),
        sum("dispatch_phone_tel_cnt").as("dispatch_phone_tel_cnt"),
        sum("dispatch_phone_whitelist_cnt").as("dispatch_phone_whitelist_cnt")
      )
      .withColumn("city", lit("ALL"))
      .withColumn("citycode", lit("ALL"))
      .withColumn("region", lit("ALL"))
      .withColumn("area", lit("ALL"))
      .withColumn("stat_type", lit("ALL"))
      .withColumn("stat_type_content", lit("ALL"))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("uid", concat_ws("_", $"ordertype", $"area", $"region", $"city", $"inc_day"))
      .select("uid", "stat_type", "stat_type_content", "ordertype", "area", "region", "city", "citycode", "dispatch_cnt", "dispatch_identify_cnt", "system_identify_cnt", "gis_identify_cnt", "ks_identify_cnt", "split_cnt", "big_group_cnt", "tc2_cnt", "norm_cnt", "chk_cnt", "monthacc_cnt", "dispatch_norm_cnt", "dispatch_normhp_cnt", "dispatch_chkn_cnt", "dispatch_tc2_cnt", "dispatch_road_cnt", "dispatch_phone_cnt", "dispatch_normhphd_cnt", "dispatch_normcompany_cnt", "n1_cnt", "n2_cnt", "n3_cnt", "n4_cnt", "n5_cnt", "y1_cnt", "y2_cnt", "y3_cnt", "y4_cnt", "y5_cnt", "ks12_cnt", "tsxy3_cnt", "tsxy4_cnt", "tsxy5_cnt", "company_cnt", "tcmodel_cnt", "standard_cnt", "translate_cnt", "tel_his_cnt", "gd_poi_cnt", "aoi_name_cnt", "address80_n_cnt", "address80_y_cnt", "aoi_80_recent_cnt", "aoi_80_similar_rate_cnt", "aoi_80_similar_unique_cnt","aoiModel","dispatch_phone_tel_cnt","dispatch_phone_whitelist_cnt", "inc_day")
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, allDF, "[all]派件识别率指标")
    allDF
  }

}
