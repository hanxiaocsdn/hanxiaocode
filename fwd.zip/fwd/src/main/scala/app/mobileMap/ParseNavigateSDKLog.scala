//package app.mobileMap
//
//import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
//import com.typesafe.config.{Config, ConfigFactory}
//import entry.TrackSimilarity
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.{DataFrame, SparkSession}
//import org.apache.spark.storage.StorageLevel
//import org.slf4j.{Logger, LoggerFactory}
//import utils.CommonTools._
//import utils.HttpConnection.httpPost
//import utils.SparkConfigUtil
//
//import scala.collection.mutable.{ArrayBuffer, ListBuffer}
//
///**
//  * 任务名称：导航SDK日志解析
//  * 任务ID：444182
//  * 需求人员：孟帅 80005715
//  * 开发人员：王冬冬 01413698
//  */
//object ParseNavigateSDKLog {
//    // 初始化
//    val className: String = this.getClass.getSimpleName.stripSuffix("$")
//    val logger: Logger = LoggerFactory.getLogger(className)
//
//    // 初始化配置文件
//    val config: Config = ConfigFactory.load()
//    // 获取配置文件信息
//    val track_similarity_url: String = config.getString("track_similarity_url")
//    val fusion_track_url: String = config.getString("fusion_track_url")
//    val track_jp_url: String = config.getString("track_jp_url")
//
//    def main(args: Array[String]): Unit = {
//
//        if (args.length != 1) {
//            logger.error(
//                """
//                  |需要输入1个参数：
//                  |    inc_day
//                  |""".stripMargin)
//            sys.exit(-1)
//        }
//
//        // 接收外部传递进来的变量
//        val inc_day: String = args(0)
//        logger.error(s"取数日期:$inc_day")
//
//        // 创建spark
//        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)
//
//        // 获取原始数据
//        val naviLogRDD: RDD[JSONObject] = getNaviLogDetail(spark, inc_day)
//
//        // 获取轨迹相似度
//        gettrackSimilDetail(spark, naviLogRDD, inc_day)
//
//
//        logger.error("运行结束！")
//
//        // 程序运行结束,关闭spark
//        spark.stop()
//
//    }
//
//    // 获取轨迹完相似度
//    def gettrackSimilarity(ak: String, o: JSONObject): Unit = {
//        val coord_list: String = o.getString("coord_list")
//        val coordArr: JSONArray = formatCoordList(coord_list)
//
//        val polyline: String = o.getString("polyline")
//        val tracks2: String = o.getString("tracks2")
//
//        val parm: JSONObject = new JSONObject()
//        parm.put("ak", ak)
//        parm.put("vehicle", 6)
//        parm.put("retflag", 5)
//        parm.put("tracktype", 0)
//        parm.put("tracks1", coordArr)
//
//        if (!isEmptyOrNull(polyline)) {
//            val polylineArr: JSONArray = JSON.parseArray(polyline)
//            for (i <- 0 until polylineArr.size()) polylineArr.getJSONObject(i).put("type", 1)
//            parm.put("tracks2", polylineArr)
//            val jsonStr: String = httpPost(3, track_similarity_url, parm.toJSONString)
//            val similArr: Array[String] = parseSimiJson(jsonStr)
//
//            o.put("similarity1_polyline", similArr(0))
//            o.put("similarity2_polyline", similArr(1))
//        }
//
//        if (!isEmptyOrNull(tracks2) && tracks2 != "[]") {
//            val tracksArr: JSONArray = formatTracks2(tracks2)
//            parm.put("tracks2", tracksArr)
//
//            val jsonStr: String = httpPost(3, track_similarity_url, parm.toJSONString)
//            val similArr: Array[String] = parseSimiJson(jsonStr)
//
//            o.put("similarity1_tracks", similArr(0))
//            o.put("similarity2_tracks", similArr(1))
//        }
//
//    }
//
//    // 格式化 tracks2
//    def formatTracks2(tracks2: String): JSONArray = {
//        val tracks2Arr: Array[String] = tracks2
//          .replaceAll("\\[", "")
//          .replaceAll("],", ";")
//          .replaceAll("]]", "")
//          .split(";")
//
//        val tracksArr: JSONArray = new JSONArray()
//        for (i <- tracks2Arr.indices) {
//            val xy: Array[Double] = tracks2Arr(i).split(",").map(_.toDouble)
//            val obj = new JSONObject()
//            obj.put("x", xy(0))
//            obj.put("y", xy(1))
//            obj.put("type", 1)
//            tracksArr.add(obj)
//        }
//
//        tracksArr
//    }
//
//    // 格式化 coord_list
//    def formatCoordList(coord_list: String): JSONArray = {
//        val coordArr: Array[String] = coord_list.split(";")
//        val coorArr: JSONArray = new JSONArray()
//        for (i <- coordArr) {
//            val obj: JSONObject = new JSONObject()
//            val xy: Array[Double] = i.split(",").map(_.toDouble)
//            obj.put("x", xy(0))
//            obj.put("y", xy(1))
//            obj.put("type", 1)
//            coorArr.add(obj)
//        }
//
//        coorArr
//    }
//
//    // 解析接口返回的json
//    def parseSimiJson(jsonStr: String): Array[String] = {
//        val arr = new Array[String](2)
//        try {
//            val o2: JSONObject = JSON.parseObject(jsonStr)
//            val status: String = o2.getString("status")
//            if (status == "0") {
//                val result: JSONObject = o2.getJSONObject("result")
//                arr(0) = result.getString("similarity1")
//                arr(1) = result.getString("similarity2")
//            }
//        } catch {
//            case e: Exception => println("相似度接口调用失败:" + e.getMessage)
//        }
//        arr
//    }
//
//    // 调用融合轨迹接口
//    def gettracks1Info(ak: String, o: JSONObject): Unit = {
//        val un: String = o.getString("vehicle")
//        val navi_starttime: String = o.getString("navi_starttime")
//        val navi_endtime: String = o.getString("navi_endtime")
//
//        val parm: JSONObject = new JSONObject()
//        parm.put("ak", ak)
//        parm.put("un", un)
//        parm.put("beginDateTime", navi_starttime)
//        parm.put("endDateTime", navi_endtime)
//
//        parm.put("type", 0)
//        parm.put("rectify", false)
//        parm.put("hasRate", true)
//
//        // 融合轨迹查询
//        val jsonStr: String = httpPost(3, fusion_track_url, parm.toJSONString)
//        parseJsonStr(o, jsonStr)
//    }
//
//    // 解析融合轨迹接口返回的json
//    def parseJsonStr(o: JSONObject, jsonStr: String): Unit = {
//        try {
//            val o2: JSONObject = JSON.parseObject(jsonStr)
//            val status: String = o2.getString("status")
//            if (status == "0") {
//                val result: JSONObject = o2.getJSONObject("result")
//                val data: JSONObject = result.getJSONObject("data")
//
//                val track: JSONArray = data.getJSONArray("track")
//
//                val tracksBuff = new ArrayBuffer[String]()
//                val tracksBuff2 = new JSONArray()
//                for (i <- 0 until track.size()) {
//                    val t: JSONObject = track.getJSONObject(i)
//                    val zx: String = t.getString("zx")
//                    val zy: String = t.getString("zy")
//                    tracksBuff.append("[" + zx + "," + zy + "]")
//
//                    val obj = new JSONObject()
//                    obj.put("type", t.getIntValue("tp"))
//                    obj.put("x", zx.toDouble)
//                    obj.put("y", zy.toDouble)
//                    obj.put("accuracy", t.getIntValue("ac"))
//                    obj.put("speed", t.getDoubleValue("sp"))
//                    obj.put("azimuth", t.getDoubleValue("be"))
//                    obj.put("time", t.getLongValue("tm"))
//                    obj.put("index", i)
//                    tracksBuff2.add(i, obj)
//                }
//
//                o.put("tracks1", "[" + tracksBuff.mkString(",") + "]")
//                o.put("tracks", tracksBuff2)
//            }
//        } catch {
//            case e: Exception => println("融合轨迹接口调用失败:" + e.getMessage)
//        }
//    }
//
//    // 获取纠偏轨迹信息
//    def getjPTracksInfo(ak: String, o: JSONObject): Unit = {
//        val vehicle_type: String = o.getString("vehicle_type")
//        val load: Int = o.getDoubleValue("mload").toInt
//        val axis: Int = o.getDoubleValue("axle_number").toInt
//        val weight: Int = o.getDoubleValue("weight").toInt
//        val length: Int = o.getDoubleValue("length").toInt
//        val tracks: JSONArray = o.getJSONArray("tracks")
//
//        val parm: JSONObject = new JSONObject()
//        val vehicleInfo: JSONObject = new JSONObject()
//        if (!isEmptyOrNull(load.toString)) vehicleInfo.put("load", load)
//        if (!isEmptyOrNull(axis.toString)) vehicleInfo.put("axis", axis)
//        if (!isEmptyOrNull(weight.toString)) vehicleInfo.put("weight", weight)
//        if (!isEmptyOrNull(length.toString)) vehicleInfo.put("length", length)
//
//        parm.put("ak", ak)
//        parm.put("vehicle", if (isEmptyOrNull(vehicle_type)) "6" else vehicle_type)
//        parm.put("retflag", 7)
//        parm.put("addpoint", 1)
//        parm.put("poiinfo", 1)
//        parm.put("mat_ratio", 1)
//        parm.put("tracks", tracks)
//        parm.put("vehicleInfo", vehicleInfo)
//
//        val process: JSONObject = new JSONObject()
//        process.put("stay_time", 180)
//        process.put("poi_range", 500)
//        parm.put("process", process)
//
//        // 获取纠偏轨迹
//        val jsonStr: String = httpPost(3, track_jp_url, parm.toJSONString)
//        parseJPJsonStr(o, jsonStr)
//
//        o.remove("tracks")
//    }
//
//    // 解析纠偏接口返回的json
//    def parseJPJsonStr(o: JSONObject, jsonStr: String): Unit = {
//        try {
//            val o2: JSONObject = JSON.parseObject(jsonStr)
//            val status: String = o2.getString("status")
//            if (status == "0") {
//                val result: JSONObject = o2.getJSONObject("result")
//                val len: String = result.getString("len")
//                val tracks: JSONArray = result.getJSONArray("tracks")
//
//                val tracksBuff = new ArrayBuffer[String]()
//                for (i <- 0 until tracks.size()) {
//                    val t: JSONObject = tracks.getJSONObject(i)
//                    val x: String = t.getString("x")
//                    val y: String = t.getString("y")
//                    tracksBuff.append("[" + x + "," + y + "]")
//                }
//
//                o.put("tracks2", "[" + tracksBuff.mkString(",") + "]")
//                o.put("navi_distinct", len)
//            }
//        } catch {
//            case e: Exception => println("轨迹纠偏接口调用失败:" + e.getMessage)
//        }
//    }
//
//    // 导航SDK日志数据
//    def getNaviLogDetail(spark: SparkSession, inc_day: String): RDD[JSONObject] = {
//        import spark.implicits._
//
//        val dlr: String = "$"
//        val sql1: String =
//            s"""
//               |select
//               |  get_json_object(get_json_object(data, '$dlr.data.operateInfo.content'),'$dlr.oldPathId') as oldpath_id,
//               |  get_json_object(data, '$dlr.data.naviId') as navi_id,
//               |  get_json_object(data, '$dlr.data.reportTime') as report_time,
//               |  get_json_object(data, '$dlr.data.type') as type,
//               |  data
//               |from
//               |  dm_gis.gis_eta_navi_query_hive
//               |where
//               |  inc_day = '$inc_day'
//               |  and get_json_object(data, '$dlr.subType') = 'sdkNaviLog'
//               |  and get_json_object(data, '$dlr.data.type')  in(1,3,25)
//               |""".stripMargin
//
//        logger.error(sql1)
//
//        spark
//          .sql(sql1)
//          .rdd
//          .map(r => {
//              val o: JSONObject = row2Json(r)
//              val navi_id: String = o.getString("navi_id")
//              val report_time: Long = o.getLongValue("report_time")
//              val `type`: Long = o.getLongValue("type")
//              (navi_id, (report_time, `type`, o))
//          })
//          .groupByKey()
//          .flatMap(r => {
//              val list: List[(Long, Long, JSONObject)] = r._2.toList.sortBy(_._1)
//              val report_timeList: List[Long] = list.map(_._1)
//              val typeList: List[Long] = list.map(_._2)
//              val dataList: List[JSONObject] = list.map(_._3)
//
//              val dataList2: ListBuffer[JSONObject] = new ListBuffer[JSONObject]
//              try {
//                  val start: Int = typeList.indexOf(1)
//                  val end: Int = typeList.indexOf(3)
//
//                  val navi_starttime: Long = report_timeList(start)
//                  val navi_endtime: Long = report_timeList(end)
//
//                  dataList
//                    .slice(start - 1, end + 1)
//                    .foreach(o => {
//                        o.put("navi_starttime", navi_starttime)
//                        o.put("navi_endtime", navi_endtime)
//                        dataList2.append(o)
//                    })
//
//              } catch {
//                  case e: Exception => logger.error("不能同时满足type为1和3：" + e.getMessage)
//              }
//
//              dataList2
//          })
//          .map(o => {
//              val oldpath_id: String = o.getString("oldpath_id")
//              val navi_id: String = o.getString("navi_id")
//              val data: String = o.getString("data")
//              val navi_starttime: String = getDateStr(o.getLongValue("navi_starttime"), "yyyyMMddHHmmss")
//              val navi_endtime: String = getDateStr(o.getLongValue("navi_endtime"), "yyyyMMddHHmmss")
//              (oldpath_id, navi_id, data, navi_starttime, navi_endtime)
//          })
//          .toDF("oldpath_id", "navi_id", "data", "navi_starttime", "navi_endtime")
//          .createOrReplaceTempView("t1")
//
//        val sql2: String =
//            s"""
//               |with t2 as(
//               |  select
//               |    routeid,
//               |    polyline
//               |  from
//               |    dm_gis.gis_navi_top3_yaw_result_parse
//               |  where
//               |    inc_day = '$inc_day'
//               |),
//               |t3 as(
//               |  select
//               |    navi_id,
//               |    vehicle,
//               |    vehicle_type
//               |  from
//               |    dm_gis.gis_navi_top3_parse
//               |  where
//               |    inc_day = '$inc_day'
//               |)
//               |select
//               |  t1.*,
//               |  t2.polyline,
//               |  t3.vehicle,
//               |  t3.vehicle_type
//               |from
//               |  t1
//               |  left join t2 on t1.oldpath_id = t2.routeid
//               |  left join t3 on t1.navi_id = t3.navi_id
//               |""".stripMargin
//
//        val naviLogRDD: RDD[JSONObject] = getJsonRDD(logger, spark, sql2, 4)
//        naviLogRDD
//    }
//
//    // log解析后的最终数据
//    def gettrackSimilDetail(spark: SparkSession, naviLogRDD: RDD[JSONObject], inc_day: String): Unit = {
//        import spark.implicits._
//
//        val simiDF: DataFrame = naviLogRDD
//          .repartition(6)
//          .map(r => {
//              try {
//                  val data: JSONObject = r.getJSONObject("data").getJSONObject("data")
//                  r.put("task_id", data.getString("taskId"))
//                  r.put("navi_id", data.getString("naviId"))
//                  r.put("sdk_version", data.getString("sdkVersion"))
//                  r.put("navi_type", data.getString("naviType"))
//                  val myType: String = data.getString("type")
//                  val report_time: String = getDateStr(data.getTimestamp("reportTime").getTime, "yyyyMMddHHmmss")
//                  r.put("type", myType)
//                  r.put("report_time", report_time)
//
//                  if (myType == "25") {
//                      val operateInfo: JSONObject = data.getJSONObject("operateInfo")
//                      val operate: String = operateInfo.getString("operate")
//
//                      r.put("operate", operate)
//
//                      val c: JSONObject = operateInfo.getJSONObject("content")
//                      val isTop3: String = c.getString("isTop3")
//                      r.put("is_top3", isTop3)
//                      if (isTop3 != "true") r.put("navi_starttime", report_time)
//
//                      r.put("path_length", c.getString("pathLength"))
//                      r.put("path_time", c.getString("pathTime"))
//                      r.put("start_x", c.getString("startX"))
//                      r.put("start_y", c.getString("startY"))
//                      r.put("end_x", c.getString("endX"))
//                      r.put("end_y", c.getString("endY"))
//                      r.put("cameras_count", c.getString("camerasCount"))
//
//                      if (operate == "还原线路上传") {
//                          val pathLabelArr: JSONArray = c.getJSONArray("pathLabel")
//                          val listBuff = new ListBuffer[String]
//                          for (i <- 0 until pathLabelArr.size()) {
//                              val content: String = pathLabelArr.getJSONObject(i).getString("content")
//                              listBuff.append(content)
//                          }
//                          r.put("path_label", listBuff.mkString("|"))
//                      } else r.put("path_label", c.getString("pathLabel"))
//
//                      val coordList: JSONArray = c.getJSONArray("coordList")
//                      val coordsArr = new ListBuffer[String]
//                      for (i <- 0 until coordList.size()) {
//                          val o2: JSONObject = coordList.getJSONObject(i)
//                          val x: String = o2.getString("longitude")
//                          val y: String = o2.getString("latitude")
//                          coordsArr.append(x + "," + y)
//                      }
//                      r.put("coord_list", coordsArr.mkString(";"))
//                      r.put("old_path_id", c.getString("oldPathId"))
//                      r.put("path_id", c.getString("pathid"))
//                      r.put("toll_cost", c.getString("tollCost"))
//                      r.put("traffic_incident_info", c.getString("trafficIncidentInfo"))
//                      r.put("traffic_status", c.getString("trafficStatuses"))
//                  }
//
//                  // 调用调融合轨迹
//                  gettracks1Info("e640de2b47394b19862ee134d817bbc7", r)
//                  // 调用纠偏轨迹
//                  getjPTracksInfo("e640de2b47394b19862ee134d817bbc7", r)
//                  // 2个轨迹接口对比
//                  if (myType == "25") gettrackSimilarity("d9c28a860af34836973480542dc11d83", r)
//
//                  r.remove("data")
//              } catch {
//                  case e: Exception => println("解析原始SDK异常:" + e.getMessage)
//              }
//
//              r
//          })
//          .filter(_.getString("data") == null)
//          .map(o => {
//              val task_id: String = o.getString("task_id")
//              val navi_id: String = o.getString("navi_id")
//              val sdk_version: String = o.getString("sdk_version")
//              val navi_type: String = o.getString("navi_type")
//              val operate: String = o.getString("operate")
//              val report_time: String = o.getString("report_time")
//              val is_top3: String = o.getString("is_top3")
//              val path_length: String = o.getString("path_length")
//              val path_time: String = o.getString("path_time")
//              val start_x: String = o.getString("start_x")
//              val start_y: String = o.getString("start_y")
//              val end_x: String = o.getString("end_x")
//              val end_y: String = o.getString("end_y")
//              val cameras_count: String = o.getString("cameras_count")
//              val path_label: String = o.getString("path_label")
//              val coord_list: String = o.getString("coord_list")
//              val old_path_id: String = o.getString("old_path_id")
//              val path_id: String = o.getString("path_id")
//              val toll_cost: String = o.getString("toll_cost")
//              val traffic_incident_info: String = o.getString("traffic_incident_info")
//              val traffic_status: String = o.getString("traffic_status")
//              val similarity1_polyline: String = o.getString("similarity1_polyline")
//              val similarity2_polyline: String = o.getString("similarity2_polyline")
//              val similarity1_tracks: String = o.getString("similarity1_tracks")
//              val similarity2_tracks: String = o.getString("similarity2_tracks")
//              val polyline: String = o.getString("polyline")
//              val navi_starttime: String = o.getString("navi_starttime")
//              val navi_endtime: String = o.getString("navi_endtime")
//              val vehicle: String = o.getString("vehicle")
//              val vehicle_type: String = o.getString("vehicle_type")
//              val tracks1: String = o.getString("tracks1")
//              val tracks2: String = o.getString("tracks2")
//              val navi_distinct: String = o.getString("navi_distinct")
//              val `type`: String = o.getString("type")
//
//              TrackSimilarity(
//                  task_id, navi_id, sdk_version, navi_type, operate, report_time, is_top3, path_length, path_time,
//                  start_x, start_y, end_x, end_y, cameras_count, path_label, coord_list, old_path_id, path_id,
//                  toll_cost, traffic_incident_info, traffic_status, similarity1_polyline, similarity2_polyline, similarity1_tracks,
//                  similarity2_tracks, polyline, navi_starttime, navi_endtime, vehicle, vehicle_type, tracks1, tracks2, navi_distinct, `type`, inc_day
//              )
//          })
//          .toDF()
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//
//        GetDFCountAndSampleData(logger, simiDF, "最终的结果数据")
//        df2HiveByOverwrite(logger, simiDF, "dm_gis.gis_navi_gdwl_coord")
//
//        naviLogRDD.unpersist()
//
//    }
//
//
//}
