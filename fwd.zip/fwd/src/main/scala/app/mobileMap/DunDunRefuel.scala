package app.mobileMap

import com.alibaba.fastjson._
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.HttpClientUtil.getJsonByGet
import utils.SparkConfigUtil

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
 * 任务名称：【吨吨加油】顺丰线索挖掘流程
 * 任务ID：481662  已冻结
 * 需求人员：矫悦 01404184
 * 开发人员：王冬冬 01413698
 */
object DunDunRefuel {

  // 初始化配置文件
  val config: Config = ConfigFactory.load()
  // 获取配置文件信息
  val ct_url: String = config.getString("ct_url")

  // 初始化
  val className: String = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)

  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      logger.error(
        """
          |需要输入2个参数：
          |    start_time、end_time
          |""".stripMargin)
      sys.exit(-1)
    }

    // 接收外部传递进来的变量
    val start_time: String = args(0)
    val end_time: String = args(1)
    logger.error(s"开始日期:$start_time 结束日期:$end_time")

    // 创建spark
    val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

    // 任务初始化数据
    val (origDF, deptDF) = getOrigData(spark, start_time, end_time)
    // 统计中转场车队维度的数据
    val carIndexDF: DataFrame = MotorcadeIndex(spark, origDF, deptDF)
    // 获取中转场车队联系方式
    MotorcadeContact(spark, carIndexDF)
    // 统计中转场维度的数据
    val indexDF: DataFrame = TransitIndex(spark, origDF, deptDF)
    // 挖掘中转场附近油站数据
    GetGasStationInfo(spark, indexDF)

    origDF.unpersist()
    deptDF.unpersist()

    logger.error("运行结束！")

    // 程序运行结束,关闭spark
    spark.stop()

  }

  // 获取传统规划距离
  def getDist: UserDefinedFunction = udf((x_coord: String, y_coord: String, longitude: String, latitude: String) => {
    val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
    parMap.put("x1", longitude)
    parMap.put("y1", latitude)
    parMap.put("x2", x_coord)
    parMap.put("y2", y_coord)
    parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

    val url: String = ct_url + map2String(parMap)

    val jsonData: JSONObject = getJsonByGet(url, 2, "utf-8")

    var d_dist: Double = 0.0

    if (jsonData != null) {
      val status: String = jsonData.getString("status")
      if (status == "0") {
        logger.error("调用传统接口成功,数据处理中……")
        val result: JSONObject = jsonData.getJSONObject("result")
        val list: JSONArray = result.getJSONArray("list")
        if (list != null && list.size() > 0) {
          val obj: JSONObject = list.getJSONObject(0)
          d_dist = obj.getDoubleValue("dist")
        }
      }
    } else logger.error("调用传统接口失败!")

    d_dist
  })

  // 数据预处理
  def getOrigData(spark: SparkSession, start_time: String, end_time: String): (DataFrame, DataFrame) = {
    import spark.implicits._

    val start_time2: String = getDateStr(getTimestamp(start_time, "yyyyMMdd"), "yyyy-MM-dd HH:mm:ss")
    val end_time2: String = getDateStr(getTimestamp(end_time, "yyyyMMdd"), "yyyy-MM-dd HH:mm:ss")

    val lineSql: String =
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  carrier_name,
         |  task_inc_day,
         |  start_dept,
         |  start_type,
         |  line_code,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  plan_depart_tm,
         |  actual_depart_tm,
         |  driver_id,
         |  driver_name,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  plf_flag,
         |  vehicle_type,
         |  axls_number,
         |  log_dist,
         |  if_evaluate_time,
         |  stop_over_zone_code,
         |  end_dept,
         |  end_type,
         |  plan_arrive_tm,
         |  actual_arrive_tm,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  duration,
         |  time,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge,
         |  pns_dist,
         |  pns_time,
         |  std_toll_charge,
         |  if_error,
         |  src,
         |  conduct_type,
         |  ac_is_run_ontime,
         |  diffdist_log_rt,
         |  diffratio_log_rt,
         |  accrual_dist,
         |  accrual_dist_type,
         |  last_update_tm,
         |  main_driver_account,
         |  road_fee,
         |  line_require_id
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day >= '$start_time'
         |  and inc_day <= '$end_time'
         |  and carrier_type != '0'
         |  and carrier_name not like '%顺丰%'
         |  and carrier_name not like '%丰驰%'
         |""".stripMargin
    val deptSql: String =
      """
        |select
        |  dept_code,
        |  dept_name,
        |  dept_addr,
        |  dept_type_name,
        |  dept_transfer_flag,
        |  area_name,
        |  country_name,
        |  city_name,
        |  provinct_name,
        |  belong_county,
        |  longitude,
        |  latitude,
        |  delete_flg
        |from
        |  dim.dim_department
        |where
        |  country_name = '中国大陆'
        |  and delete_flg = '0'
        |  and dept_transfer_flag = '1'
        |  and longitude is not null
        |  and longitude != ''
        |  and latitude is not null
        |  and latitude != ''
        |""".stripMargin

    logger.error(s"线路数据：$lineSql")
    logger.error(s"维表数据：$deptSql")

    val deptDF: DataFrame = spark.sql(deptSql).persist(StorageLevel.MEMORY_AND_DISK)

    val origDF: DataFrame = spark.sql(lineSql)
      .filter($"plan_depart_tm" >= start_time2 and $"plan_depart_tm" <= end_time2)
      .withColumn("plan_depart_tm_day", split($"plan_depart_tm", " ")(0))
      .withColumn("task_batch", lit(start_time + "-" + end_time))
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, deptDF, "维表数据")
    GetDFCountAndSampleData(logger, origDF, "初始化数据")

    (origDF, deptDF)
  }

  // 统计中转场维度的数据
  def TransitIndex(spark: SparkSession, origDF: DataFrame, deptDF: DataFrame): DataFrame = {
    import spark.implicits._

    val indexDF1: DataFrame = origDF
      .groupBy("start_dept", "task_batch")
      .agg(
        size(collect_list("task_id")).as("task_count"),
        size(collect_set("carrier_name")).as("carrier_count"),
        size(collect_set("vehicle_serial")).as("vehicle_count"),
        size(collect_set("plan_depart_tm_day")).as("task_day_count"),
        max("plan_depart_tm_day").as("plan_depart_tm_day_max"),
        min("plan_depart_tm_day").as("plan_depart_tm_day_min"),
        round(sum($"line_distance".cast("double")), 2).as("dis_sum")
      )
      .withColumn("task_count_per_day", floor($"task_count".cast("double") / $"task_day_count"))
      .withColumn("dis_sum_per_day", round($"dis_sum" / $"task_day_count"))

    val indexDF2: DataFrame = origDF
      .groupBy("start_dept", "actual_capacity_load", "task_batch")
      .agg(
        count("task_id").as("task_capacity_count"),
        size(collect_set("vehicle_serial")).as("vehicle_count")
      )
      .withColumn("total_oil",
        when($"actual_capacity_load".cast("double") === 1.0, $"task_capacity_count" * 58.25)
          .when($"actual_capacity_load".cast("double") === 1.5, $"task_capacity_count" * 40.87)
          .when($"actual_capacity_load".cast("double") === 3.0, $"task_capacity_count" * 51.84)
          .when($"actual_capacity_load".cast("double") === 5.0, $"task_capacity_count" * 129.92)
          .when($"actual_capacity_load".cast("double") === 7.0, $"task_capacity_count" * 205.58)
          .when($"actual_capacity_load".cast("double") === 14.0, $"task_capacity_count" * 202.80)
          .when($"actual_capacity_load".cast("double") === 20.0, $"task_capacity_count" * 417.74)
          .when($"actual_capacity_load".cast("double") === 30.0, $"task_capacity_count" * 520.61)
      )
      .rdd
      .map(row2Json)
      .groupBy(r => (r.getString("start_dept"), r.getString("task_batch")))
      .map(r => {
        val (start_dept, task_batch) = r._1
        val arr: Array[JSONObject] = r._2
          .toArray
          .sortWith((o1, o2) => o1.getDoubleValue("actual_capacity_load") < o2.getDoubleValue("actual_capacity_load"))

        val vehicle_sm: Int = arr.map(_.getIntValue("vehicle_count")).sum
        val perArr = new ArrayBuffer[String]()
        for (i <- arr.indices) {
          val vehicle_count: Double = arr(i).getDoubleValue("vehicle_count")
          val actual_capacity_load: Double = arr(i).getDoubleValue("actual_capacity_load")
          val s: String = (vehicle_count * 100 / vehicle_sm).formatted("%.2f") + "%"
          perArr.append(actual_capacity_load + ":" + s)
        }

        val oil_sum: Double = arr.map(_.getDoubleValue("total_oil")).sum.formatted("%.2f").toDouble

        (start_dept, task_batch, oil_sum, 0.00, perArr.mkString(","))
      })
      .toDF("start_dept", "task_batch", "oil_sum", "oil_sum_per_day", "vehicle_load_count_distribution")

    val indexDF3: DataFrame = deptDF
      .join(indexDF1, indexDF1("start_dept") === deptDF("dept_code"))
      .join(indexDF2, Seq("start_dept", "task_batch"))
      .withColumn("oil_sum_per_day", round($"oil_sum" / $"task_day_count", 2))
      .withColumn("inc_day", lit(getNowTime))
      .coalesce(1)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, indexDF3, "中转场不同维度的数据")
    df2HiveByOverwrite(logger, indexDF3, "dm_gis.dept_clue_result")
    indexDF3
  }

  // 统计中转场车队维度的数据
  def MotorcadeIndex(spark: SparkSession, origDF: DataFrame, deptDF: DataFrame): DataFrame = {
    import spark.implicits._

    val indexDF1: DataFrame = origDF
      .groupBy("start_dept", "carrier_name", "task_batch")
      .agg(
        size(collect_list("task_id")).as("task_count"),
        size(collect_set("vehicle_serial")).as("vehicle_count"),
        size(collect_set("plan_depart_tm_day")).as("task_day_count"),
        max("plan_depart_tm_day").as("plan_depart_tm_day_max"),
        min("plan_depart_tm_day").as("plan_depart_tm_day_min"),
        round(sum($"line_distance".cast("double")), 2).as("dis_sum")
      )
      .withColumn("task_count_per_day", floor($"task_count".cast("double") / $"task_day_count"))
      .withColumn("dis_sum_per_day", round($"dis_sum" / $"task_day_count"))

    val indexDF2: DataFrame = origDF
      .groupBy("start_dept", "carrier_name", "actual_capacity_load", "task_batch")
      .agg(
        count("task_id").as("task_capacity_count"),
        size(collect_set("vehicle_serial")).as("vehicle_count")
      )
      .withColumn("total_oil",
        when($"actual_capacity_load".cast("double") === 1.0, $"task_capacity_count" * 58.25)
          .when($"actual_capacity_load".cast("double") === 1.5, $"task_capacity_count" * 40.87)
          .when($"actual_capacity_load".cast("double") === 3.0, $"task_capacity_count" * 51.84)
          .when($"actual_capacity_load".cast("double") === 5.0, $"task_capacity_count" * 129.92)
          .when($"actual_capacity_load".cast("double") === 7.0, $"task_capacity_count" * 205.58)
          .when($"actual_capacity_load".cast("double") === 14.0, $"task_capacity_count" * 202.80)
          .when($"actual_capacity_load".cast("double") === 20.0, $"task_capacity_count" * 417.74)
          .when($"actual_capacity_load".cast("double") === 30.0, $"task_capacity_count" * 520.61)
      )
      .rdd
      .map(row2Json)
      .groupBy(r => (r.getString("start_dept"), r.getString("carrier_name"), r.getString("task_batch")))
      .map(r => {
        val (start_dept, carrier_name, task_batch) = r._1
        val arr: Array[JSONObject] = r._2
          .toArray
          .sortWith((o1, o2) => o1.getDoubleValue("actual_capacity_load") < o2.getDoubleValue("actual_capacity_load"))

        val vehicle_sm: Int = arr.map(_.getIntValue("vehicle_count")).sum
        val perArr = new ArrayBuffer[String]()
        for (i <- arr.indices) {
          val vehicle_count: Double = arr(i).getDoubleValue("vehicle_count")
          val actual_capacity_load: Double = arr(i).getDoubleValue("actual_capacity_load")
          val s: String = (vehicle_count * 100 / vehicle_sm).formatted("%.2f") + "%"
          perArr.append(actual_capacity_load + ":" + s)
        }

        val oil_sum: Double = arr.map(_.getDoubleValue("total_oil")).sum.formatted("%.2f").toDouble

        (start_dept, carrier_name, task_batch, oil_sum, 0.00, perArr.mkString(","))
      })
      .toDF("start_dept", "carrier_name", "task_batch", "oil_sum", "oil_sum_per_day", "vehicle_load_count_distribution")

    val indexDF3: DataFrame = deptDF
      .join(indexDF1, indexDF1("start_dept") === deptDF("dept_code"))
      .join(indexDF2, Seq("start_dept", "carrier_name", "task_batch"))
      .withColumn("oil_sum_per_day", round($"oil_sum" / $"task_day_count", 2))
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, indexDF3, "中转场车队维度的数据")

    indexDF3
  }

  // 获取中转场车队联系方式
  def MotorcadeContact(spark: SparkSession, carIndexDF: DataFrame): Unit = {
    import spark.implicits._

    val sql1: String =
      """
        |select
        |  max(inc_day) as inc_day
        |from
        |  dm_gis.dm_company_dtl
        |group by
        |  inc_day
        |""".stripMargin
    val sql2: String =
      """
        |select
        |  max(inc_day) as inc_day
        |from
        |  dm_gis.dm_company_contact_tag_dtl
        |group by
        |  inc_day
        |""".stripMargin
    val inc_day1: String = spark.sql(sql1).collect().head.getAs[String]("inc_day")
    val inc_day2: String = spark.sql(sql2).collect().head.getAs[String]("inc_day")

    val companySql: String =
      s"""
         |select
         |  name,
         |  credit_code,
         |  concat_ws(';',collect_set(legal_person_name)) as legal_person_name
         |from
         |  dm_gis.dm_company_dtl
         |where
         |  inc_day = '$inc_day1'
         |group by
         |  name,
         |  credit_code
         |""".stripMargin
    val contactSql: String =
      s"""
         |select
         |  credit_code,
         |  concat_ws(';',collect_set(content)) as content
         |from
         |  dm_gis.dm_company_contact_tag_dtl
         |where
         |  type != 'email'
         |  and inc_day = '$inc_day2'
         |group by
         |  credit_code
         |""".stripMargin
    val linkSql: String =
      """
        |select
        |  owner_name,
        |  concat_ws(';',collect_set(linkman_phone)) as linkman_phone
        |from
        |  dm_gis.yue_owner_link_info
        |where
        |  owner_name not like '%暂缺%'
        |  and owner_name not like '%缺失%'
        |  and length(owner_name) > 4
        |group by
        |  owner_name
        |""".stripMargin

    logger.error(s"工商信息：$companySql")
    logger.error(s"联系方式：$contactSql")
    logger.error(s"业户联系方式：$linkSql")

    val companyDF: Dataset[Row] = spark.sql(companySql)
    val contactDF: Dataset[Row] = spark.sql(contactSql)
    val linkDF: Dataset[Row] = spark.sql(linkSql)

    val contactDF2: Dataset[Row] = companyDF.join(contactDF, Seq("credit_code")).dropDuplicates("name")
    val res_cols = spark.sql("""select * from dm_arss.dept_carrier_clue_result limit 1""").schema.map(_.name).map(col)
    val indexDF: DataFrame = carIndexDF
      .join(contactDF2, carIndexDF("carrier_name") === contactDF2("name"), "left")
      .withColumn("src1", when($"name".isNotNull, "丰数平台").otherwise(""))
      .join(linkDF, carIndexDF("carrier_name") === linkDF("owner_name"), "left")
      .withColumn("src2", when($"owner_name".isNotNull, "粤运").otherwise(""))
      .drop("name", "owner_name")
      .withColumn("content", lit(""))
      .withColumn("inc_day", lit(getNowTime))
      .select(res_cols: _*)
      .coalesce(1)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, indexDF, "中转场车队维度的数据(关联联系方式)")
    df2HiveByOverwrite(logger, indexDF, "dm_gis.dept_carrier_clue_result")
    carIndexDF.unpersist()
  }

  // 挖掘中转场附近油站数据
  def GetGasStationInfo(spark: SparkSession, indexDF: DataFrame): Unit = {
    import spark.implicits._

    val gasSql: String =
      """
        |select
        |  pid,
        |  ad_code,
        |  province,
        |  city,
        |  district,
        |  name_chn,
        |  addr_chn,
        |  x_coord,
        |  y_coord,
        |  priceactivity,
        |  priceofficial,
        |  discount,
        |  telephone,
        |  tag,
        |  brand,
        |  src
        |from
        |  dm_gis.gas_station_info
        |""".stripMargin
    logger.error(s"加油站数据：$gasSql")

    val gasDF: DataFrame = spark.sql(gasSql)

    val gasDF2: DataFrame = gasDF
      .join(indexDF, indexDF("city_name") === gasDF("city"))
      .withColumn("beeline_dist", getDistance(
        $"x_coord".cast("double"),
        $"y_coord".cast("double"),
        $"longitude".cast("double"),
        $"latitude".cast("double")
      ))
      .filter($"beeline_dist" <= 10000.00)
      .repartition(10)
      .withColumn("d_dist", getDist($"x_coord", $"y_coord", $"longitude", $"latitude"))
      .withColumn("dist_rank",
        when($"d_dist" <= 5000, "0-5")
          .when($"d_dist" <= 10000, "5-10")
          .when($"d_dist" <= 15000, "10-15")
          .when($"d_dist" <= 20000, "15-20")
          .otherwise("20+")
      )
      .withColumn("gas_dept_frequency", count($"pid").over(Window.partitionBy("pid")))
      .drop("inc_day")
      .withColumn("inc_day", lit(getNowTime))
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, gasDF2, "中转场附近的加油站信息")
    df2HiveByOverwrite(logger, gasDF2, "dm_gis.dept_gas_station_dis_result")

    indexDF.unpersist()
    gasDF2.unpersist()
  }

}
