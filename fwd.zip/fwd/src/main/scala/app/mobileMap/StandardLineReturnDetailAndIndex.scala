//package app.mobileMap
//
//import com.alibaba.fastjson._
//import com.typesafe.config.{Config, ConfigFactory}
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.expressions.UserDefinedFunction
//import org.apache.spark.sql.functions._
//import org.apache.spark.sql.{DataFrame, SparkSession}
//import org.apache.spark.storage.StorageLevel
//import org.slf4j.{Logger, LoggerFactory}
//import utils.CommonTools._
//import utils.HttpConnection.httpPost
//import utils.SparkConfigUtil
//
//import java.sql.{Connection, PreparedStatement}
//import scala.collection.mutable.ArrayBuffer
//
///**
//  * 任务名称：标准线路返回明细和指标数据
//  * 任务ID：459252
//  * 需求人员：杨汶铭 80006323
//  * 开发人员：王冬冬 01413698
//  */
//object StandardLineReturnDetailAndIndex {
//
//    // 初始化配置文件
//    val config: Config = ConfigFactory.load()
//    // 获取配置文件信息
//    val track_url: String = config.getString("track_url")
//
//    // 初始化
//    val className: String = this.getClass.getSimpleName.stripSuffix("$")
//    val logger: Logger = LoggerFactory.getLogger(className)
//
//    def main(args: Array[String]): Unit = {
//
//        if (args.length != 1) {
//            logger.error(
//                """
//                  |需要输入1个参数：
//                  |    inc_day
//                  |""".stripMargin)
//            sys.exit(-1)
//        }
//
//        // 接收外部传递进来的变量
//        val inc_day: String = args(0)
//        logger.error(s"取数日期:$inc_day")
//
//        // 创建spark
//        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)
//
//        // 获取标准线路初始化数据
//        val lineDF: DataFrame = getLineData(spark, inc_day)
//        // 标准线路返回明细
//        val lineDetailDF: DataFrame = getLineDetail(spark, lineDF, inc_day)
//        // 标准线路返回率指标
//        val indexDF: DataFrame = getLineReturnIndex(spark, lineDetailDF, inc_day)
//        // 标准线路返回率指标写入MySQL
//        indexToMysql(indexDF)
//
//        lineDF.unpersist()
//
//        logger.error("运行结束！")
//
//        // 程序运行结束,关闭spark
//        spark.stop()
//
//    }
//
//
//    // 获取线路数据
//    def getLineData(spark: SparkSession, inc_day: String): DataFrame = {
//
//        // top3请求的入参
//        val top3Sql: String =
//            s"""
//               |select
//               |  task_id,
//               |  navi_id,
//               |  src_deptcode,
//               |  dest_deptcode,
//               |  startx,
//               |  starty,
//               |  endx,
//               |  endy,
//               |  line_code,
//               |  req_time,
//               |  vehicle,
//               |  vehicle_type,
//               |  weight,
//               |  length,
//               |  height,
//               |  ft_url,
//               |  request_id,
//               |  econ_id
//               |from
//               |  dm_gis.gis_navi_top3_parse
//               |where
//               |  inc_day = '$inc_day'
//               |  and service_id = 'SL'
//               |  and stdline = '1'
//               |""".stripMargin
//        // top3以及偏航请求的出参
//        val top3yawSql: String =
//            s"""
//               |select
//               |  request_id,
//               |  strategy
//               |from
//               |  dm_gis.gis_navi_top3_yaw_result_parse
//               |where
//               |  inc_day='$inc_day'
//               |  and subtype = 'naviTop3V2LogResult'
//               |  and strategy in('20','21','22')
//               |""".stripMargin
//        // 导航线路筛选
//        val dlr: String = "$"
//        val selectSql: String =
//            s"""
//               |select
//               |  get_json_object(data,'$dlr.requestId')            as request_id,
//               |  get_json_object(data,'$dlr.noStdReasonType')      as no_std_reason_type,
//               |  get_json_object(data,'$dlr.noStdReasonDetail')    as no_std_reason_detail
//               |from
//               |  dm_gis.gis_rss_pns_navi_select
//               |where
//               |  inc_day = '$inc_day'
//               |""".stripMargin
//        // 客户端日志记录
//        val sdkSql: String =
//            s"""
//               |select
//               |  navi_id,
//               |  navi_strategy
//               |from
//               |  dm_gis.gis_navi_sdk_navi_parse
//               |where
//               |  inc_day='$inc_day'
//               |  and type = '1'
//               |""".stripMargin
//
//        logger.error(s"top3请求的入参:$top3Sql")
//        logger.error(s"top3以及偏航请求的出参:$top3yawSql")
//        logger.error(s"导航线路筛选:$selectSql")
//        logger.error(s"客户端日志记录:$sdkSql")
//
//        val top3DF: DataFrame = spark.sql(top3Sql)
//        val top3yawDF: DataFrame = spark.sql(top3yawSql)
//        val selectDF: DataFrame = spark.sql(selectSql)
//        val sdkDF: DataFrame = spark.sql(sdkSql)
//
//        val lineDF: DataFrame = top3DF
//          .join(top3yawDF, Seq("request_id"), "left")
//          .join(selectDF, Seq("request_id"), "left")
//          .join(sdkDF, Seq("navi_id"), "left")
//          .repartition(3)
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//        GetDFCountAndSampleData(logger, lineDF, "标准线路初始化数据")
//
//        lineDF
//    }
//
//    // 线路监控详情
//    def getLineDetail(spark: SparkSession, lineDF: DataFrame, inc_day: String): DataFrame = {
//        import spark.implicits._
//
//        val lineDetailDF: DataFrame = lineDF
//          .withColumn("res", explode(parseResult($"task_id", $"endx", $"endy")))
//          .withColumn("capacity_load", $"res._1")
//          .withColumn("actual_capacity_load", $"res._2")
//          .withColumn("grd_vehicle_type", $"res._3")
//          .withColumn("start_srcx_dept", $"res._4")
//          .withColumn("start_srcy_dept", $"res._5")
//          .withColumn("end_srcx_dept", $"res._6")
//          .withColumn("end_srcy_dept", $"res._7")
//          .withColumn("src_outer_addr_code", $"res._8")
//          .withColumn("dest_outer_addr_code", $"res._9")
//          .withColumn("actual_reach_tm", $"res._10")
//          .withColumn("reach_navi", when($"req_time" >= $"actual_reach_tm", "否").otherwise("是"))
//          .withColumn("dist", getDist($"startx", $"starty", $"start_srcx_dept", $"start_srcy_dept"))
//          .withColumn("start_dist", when($"dist" <= 500.0 and $"no_std_reason_type" =!= "10", "是").otherwise("否"))
//          .withColumn("distance_end", getDist($"endx", $"endy", $"end_srcx_dept", $"end_srcy_dept"))
//          .withColumn("distance", getDist($"endx", $"endy", $"startx", $"starty"))
//          .withColumn("pull_navi_type", lit(0))
//          .withColumn("line_require_id", $"res._11")
//          .drop("res")
//          .withColumn("inc_day", lit(inc_day))
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//        GetDFCountAndSampleData(logger, lineDetailDF, "线路详情")
//        df2HiveByOverwrite(logger, lineDetailDF, "dm_gis.gis_eta_pns_std_return")
//
//        lineDetailDF
//    }
//
//    // 获取线路返回率指标
//    def getLineReturnIndex(spark: SparkSession, lineDetailDF: DataFrame, inc_day: String): DataFrame = {
//        import spark.implicits._
//
//        val dimDF: DataFrame = spark.sql("select area_code,area_name from dm_gis.dim_area_code_mapping")
//        val lineDetailDF2: DataFrame = lineDetailDF
//          .filter("start_dist in ('是','否') and reach_navi = '否' and src_outer_addr_code != '' and dest_outer_addr_code != '' " +
//            "and src_outer_addr_code != '0' and length(src_outer_addr_code) <16 and length(dest_outer_addr_code) <16 and line_code is not null and line_code != ''")
//          .withColumn("task_area_code", substring($"task_id", 1, 4))
//          .withColumn("distance2",
//              when($"distance" <= 100.0, "100")
//                .when($"distance" <= 500, "500")
//                .when($"distance" <= 1000, "1000")
//                .otherwise("1000+")
//          )
//
//        val lineDetailRDD: RDD[((String, String, Int, String), JSONObject)] = lineDetailDF2
//          .join(dimDF, lineDetailDF2("task_area_code") === dimDF("area_code"))
//          .rdd
//          .map(r => {
//              val o: JSONObject = row2Json(r)
//              val start_dist: String = o.getString("start_dist")
//              val task_area_code: String = o.getString("area_name")
//              val pull_navi_type: Int = r.getAs[Int]("pull_navi_type")
//              val distance2: String = r.getAs[String]("distance2")
//              ((start_dist, task_area_code, pull_navi_type, distance2), o)
//          })
//
//        val indexDF: DataFrame = getLineIndexInfo(spark, lineDetailRDD)
//          .withColumn("id", concat_ws("_", lit(inc_day), $"start_dist", $"task_area_code", $"pull_navi_type", $"distance"))
//          .withColumn("inc_day", lit(inc_day))
//          .coalesce(1)
//          .persist(StorageLevel.MEMORY_AND_DISK)
//
//        GetDFCountAndSampleData(logger, indexDF, "标准线路返回率指标详情")
//        df2HiveByOverwrite(logger, indexDF, "dm_gis.gis_eta_pns_std_return_index")
//
//        indexDF
//    }
//
//    // 解析接口
//    def parseResult: UserDefinedFunction = udf((task_id: String, endx: String, endy: String) => {
//        val parm = new JSONObject()
//        parm.put("task_id", task_id)
//        val jsonStr: String = httpPost(3, track_url, parm.toJSONString)
//
//        var capacity_load: Int = 0
//        var actual_capacity_load: Double = 0.0
//        var grd_vehicle_type: Int = 0
//        var src_outer_addr_code: String = ""
//        var start_srcx_dept: String = ""
//        var start_srcy_dept: String = ""
//        var dest_outer_addr_code: String = ""
//        var end_srcx_dept: String = ""
//        var end_srcy_dept: String = ""
//        var actual_reach_tm: String = ""
//        var line_require_id: String = ""
//
//        try {
//            val o: JSONObject = JSON.parseObject(jsonStr)
//            val success: Boolean = o.getBooleanValue("success")
//            if (success) {
//                logger.error("接口返回成功,处理业务逻辑中……")
//                val result: JSONObject = o.getJSONObject("result")
//                capacity_load = result.getIntValue("capacityLoad")
//                actual_capacity_load = result.getDoubleValue("actualCapacityLoad")
//                actual_reach_tm = result.getString("actualReachTm")
//
//                line_require_id = result.getString("lineRequireId")
//
//                grd_vehicle_type = getGrdVehicleType(actual_capacity_load)
//
//                val groundTaskPassZoneResults: JSONArray = result.getJSONArray("groundTaskPassZoneResults")
//                if (!groundTaskPassZoneResults.isEmpty) {
//                    val n: Int = groundTaskPassZoneResults.size()
//
//                    val distBuff = new ArrayBuffer[(Int, Double)]()
//                    for (i <- 0 until n) {
//                        val o2: JSONObject = groundTaskPassZoneResults.getJSONObject(i)
//
//                        var d: Double = -1.0
//                        val tp: (String, String, String) = getZoneCodeAndXY(o2)
//                        val x: String = tp._2
//                        val y: String = tp._3
//                        if (!isEmptyOrNull(endx) && !isEmptyOrNull(endy) && !isEmptyOrNull(x) && !isEmptyOrNull(y)) d = getDistance(x.toDouble, y.toDouble, endx.toDouble, endy.toDouble)
//                        distBuff.append((i, d))
//                    }
//
//                    val index: Int = distBuff.filter(_._2 > -1.0).minBy(_._2)._1
//
//                    val o2: JSONObject = groundTaskPassZoneResults.getJSONObject(index)
//                    val tp: (String, String, String) = getZoneCodeAndXY(o2)
//
//                    src_outer_addr_code = "0"
//                    start_srcx_dept = "0"
//                    start_srcy_dept = "0"
//
//                    dest_outer_addr_code = tp._1
//                    end_srcx_dept = tp._2
//                    end_srcy_dept = tp._3
//
//                    if (index > 0) {
//                        val o3: JSONObject = groundTaskPassZoneResults.getJSONObject(index - 1)
//                        val tp2: (String, String, String) = getZoneCodeAndXY(o3)
//                        src_outer_addr_code = tp2._1
//                        start_srcx_dept = tp2._2
//                        start_srcy_dept = tp2._3
//                    }
//                }
//            }
//        } catch {
//            case e: Exception => logger.error("接口解析异常！" + e.getMessage)
//        }
//
//        val res = new Array[(Int, Double, Int, String, String, String, String, String, String, String, String)](1)
//        res(0) = (capacity_load, actual_capacity_load, grd_vehicle_type, start_srcx_dept, start_srcy_dept, end_srcx_dept, end_srcy_dept, src_outer_addr_code, dest_outer_addr_code, actual_reach_tm, line_require_id)
//        res
//    })
//
//    // 获取网点及坐标
//    def getZoneCodeAndXY(o: JSONObject): (String, String, String) = {
//        var zone_code: String = ""
//        var x: String = ""
//        var y: String = ""
//
//        val outerAddrCode: String = o.getString("outerAddrCode")
//        val actualPassZoneCode: String = o.getString("actualPassZoneCode")
//        val passZoneCode: String = o.getString("passZoneCode")
//        if (!isEmptyOrNull(outerAddrCode)) {
//            zone_code = outerAddrCode
//        } else if (!isEmptyOrNull(actualPassZoneCode)) {
//            zone_code = actualPassZoneCode
//        } else if (!isEmptyOrNull(passZoneCode)) {
//            zone_code = passZoneCode
//        }
//
//        val passZoneCoordinate: String = o.getString("passZoneCoordinate")
//        if (!isEmptyOrNull(passZoneCoordinate)) {
//            val xyArr: Array[String] = passZoneCoordinate.split(",")
//            x = xyArr(0)
//            y = xyArr(1)
//        }
//
//        (zone_code, x, y)
//    }
//
//    // 获取grd车型
//    def getGrdVehicleType(actual_capacity_load: Double): Int = {
//        if (actual_capacity_load <= 1.0) 5
//        else if (actual_capacity_load <= 3.0) 6
//        else if (actual_capacity_load < 7.0) 7
//        else 8
//    }
//
//    // 获取起点与终点的距离
//    def getDist: UserDefinedFunction = udf((startx: String, starty: String, start_srcx_dept: String, start_srcy_dept: String) => {
//        var dist: Double = 0.0
//        try {
//            dist = getDistance(startx.toDouble, starty.toDouble, start_srcx_dept.toDouble, start_srcy_dept.toDouble)
//        } catch {
//            case e: Exception => println("经纬度异常" + e.getMessage)
//        }
//        dist
//    })
//
//    // 获取typeN
//    def getTypeN(arr: Array[JSONObject], i: String): Int = {
//        val typeArr: Array[String] = Array("1", "2", "4", "5", "6", "7", "8", "10", "11")
//        val strategyArr: Array[String] = Array("20", "21", "22")
//
//        val n: Int = arr
//          .filter(o => {
//              val no_std_reason_type: String = o.getString("no_std_reason_type")
//              val econ_id: String = o.getString("econ_id")
//              val strategy: String = o.getString("strategy")
//
//              if (typeArr.contains(i)) {
//                  if (no_std_reason_type == i) true else false
//              } else if (i == "12") {
//                  if (isEmptyOrNull(no_std_reason_type)) true else false
//              } else if (i == "13") {
//                  if (!isEmptyOrNull(econ_id) && !strategyArr.contains(strategy) && no_std_reason_type == "0") true else false
//              } else false
//          })
//          .map(_.getString("navi_id")).distinct.length
//        n
//    }
//
//    // 获取click
//    def getClick(arr: Array[JSONObject], s: String): Int = {
//        val strategyArr: Array[String] = Array("20", "21", "22")
//
//        val n: Int = arr
//          .filter(o => {
//              val strategy: String = o.getString("strategy")
//              val navi_strategy: String = o.getString("navi_strategy")
//
//              if (s == "std") {
//                  if (strategyArr.contains(strategy) && strategyArr.contains(navi_strategy)) true else false
//              } else if (s == "") {
//                  if (strategyArr.contains(strategy) && !isEmptyOrNull(navi_strategy) && !strategyArr.contains(navi_strategy)) true else false
//              } else if (s == "str") {
//                  if (strategyArr.contains(strategy) && isEmptyOrNull(navi_strategy)) true else false
//              } else false
//          })
//          .map(_.getString("navi_id")).distinct.length
//
//        n
//    }
//
//    //  获取线路指标详情信息
//    def getLineIndexInfo(spark: SparkSession, lineDetailRDD: RDD[((String, String, Int, String), JSONObject)]): DataFrame = {
//        import spark.implicits._
//
//        val lineIndex: DataFrame = lineDetailRDD
//          .groupByKey()
//          .map(r => {
//              val (start_dist, task_area_code, pull_navi_type, distance2) = r._1
//              val arr: Array[JSONObject] = r._2.toArray
//
//              val stdrequest: Int = arr.map(_.getString("navi_id")).distinct.length
//
//              val strategyArr: Array[String] = Array("20", "21", "22")
//              val stdreturn: Int = arr
//                .filter(o => {
//                    val econ_id: String = o.getString("econ_id")
//                    val strategy: String = o.getString("strategy")
//                    if (!isEmptyOrNull(econ_id) && strategyArr.contains(strategy)) true else false
//                })
//                .map(_.getString("navi_id")).distinct.length
//
//              val top3_stdclick: Int = getClick(arr, "std")
//              val top3_click: Int = getClick(arr, "")
//              val top3_strclick: Int = getClick(arr, "str")
//
//              val type9: Int = getTypeN(arr, "9")
//              val type8: Int = getTypeN(arr, "8")
//              val type2: Int = getTypeN(arr, "2")
//              val type10: Int = getTypeN(arr, "10")
//              val type5: Int = getTypeN(arr, "5")
//              val type7: Int = getTypeN(arr, "7")
//              val type4: Int = getTypeN(arr, "4")
//              val type1: Int = getTypeN(arr, "1")
//              val type6: Int = getTypeN(arr, "6")
//              val type11: Int = getTypeN(arr, "11")
//              val type12: Int = getTypeN(arr, "12")
//              val type13: Int = getTypeN(arr, "13")
//
//              ("", start_dist, task_area_code, pull_navi_type, distance2, stdrequest, stdreturn, top3_stdclick, top3_click, top3_strclick, type9, type8, type2, type10,
//                type5, type7, type4, type1, type6, type11, type12, type13)
//          })
//          .toDF("id", "start_dist", "task_area_code", "pull_navi_type", "distance", "stdrequest", "stdreturn", "top3_stdclick", "top3_click", "top3_strclick",
//              "type9", "type8", "type2", "type10", "type5", "type7", "type4", "type1", "type6", "type11", "type12", "type13")
//          .withColumn("std_return", getRate2($"stdreturn", $"stdrequest"))
//          .withColumn("stdclick", getRate2($"top3_stdclick", $"stdreturn"))
//          .withColumn("click", getRate2($"top3_click", $"stdreturn"))
//          .withColumn("stdexit", getRate2($"top3_strclick", $"stdreturn"))
//          .withColumn("not_return9", getRate2($"type9", $"stdrequest"))
//          .withColumn("not_return8", getRate2($"type8", $"stdrequest"))
//          .withColumn("not_return2", getRate2($"type2", $"stdrequest"))
//          .withColumn("not_return10", getRate2($"type10", $"stdrequest"))
//          .withColumn("not_return5", getRate2($"type5", $"stdrequest"))
//          .withColumn("not_return7", getRate2($"type7", $"stdrequest"))
//          .withColumn("not_return4", getRate2($"type4", $"stdrequest"))
//          .withColumn("not_return1", getRate2($"type1", $"stdrequest"))
//          .withColumn("not_return6", getRate2($"type6", $"stdrequest"))
//          .withColumn("not_return11", getRate2($"type11", $"stdrequest"))
//          .withColumn("not_return12", getRate2($"type12", $"stdrequest"))
//          .withColumn("not_return13", getRate2($"type13", $"stdrequest"))
//
//        lineIndex
//
//    }
//
//    // 将返回率指标写到mysql
//    def indexToMysql(indexDF: DataFrame): Unit = {
//        // mysql的参数
//        val driver = "com.mysql.cj.jdbc.Driver"
//        val url = "jdbc:mysql://naviqueryindex-m.db.sfcloud.local:3306/navi_index?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
//        val userName = "navi_index"
//        val passWd = "hs9x+nh8u"
//
//        logger.error("返回率指标开始写入到MySQL！")
//        indexDF
//          .foreachPartition(iter => {
//              Class.forName(driver)
//              val connection: Connection = java.sql.DriverManager.getConnection(url, userName, passWd)
//              iter.foreach(r => {
//                  val id: String = r.getAs[String]("id")
//                  val start_dist: String = r.getAs[String]("start_dist")
//                  val task_area_code: String = r.getAs[String]("task_area_code")
//                  val pull_navi_type: Int = r.getAs[Int]("pull_navi_type")
//                  val distance: String = r.getAs[String]("distance")
//                  val stdrequest: Int = r.getAs[Int]("stdrequest")
//                  val stdreturn: Int = r.getAs[Int]("stdreturn")
//                  val top3_stdclick: Int = r.getAs[Int]("top3_stdclick")
//                  val top3_click: Int = r.getAs[Int]("top3_click")
//                  val top3_strclick: Int = r.getAs[Int]("top3_strclick")
//                  val type9: Int = r.getAs[Int]("type9")
//                  val type8: Int = r.getAs[Int]("type8")
//                  val type2: Int = r.getAs[Int]("type2")
//                  val type10: Int = r.getAs[Int]("type10")
//                  val type5: Int = r.getAs[Int]("type5")
//                  val type7: Int = r.getAs[Int]("type7")
//                  val type4: Int = r.getAs[Int]("type4")
//                  val type1: Int = r.getAs[Int]("type1")
//                  val type6: Int = r.getAs[Int]("type6")
//                  val type11: Int = r.getAs[Int]("type11")
//                  val type12: Int = r.getAs[Int]("type12")
//                  val type13: Int = r.getAs[Int]("type13")
//                  val std_return: String = r.getAs[String]("std_return")
//                  val stdclick: String = r.getAs[String]("stdclick")
//                  val click: String = r.getAs[String]("click")
//                  val stdexit: String = r.getAs[String]("stdexit")
//                  val not_return9: String = r.getAs[String]("not_return9")
//                  val not_return8: String = r.getAs[String]("not_return8")
//                  val not_return2: String = r.getAs[String]("not_return2")
//                  val not_return10: String = r.getAs[String]("not_return10")
//                  val not_return5: String = r.getAs[String]("not_return5")
//                  val not_return7: String = r.getAs[String]("not_return7")
//                  val not_return4: String = r.getAs[String]("not_return4")
//                  val not_return1: String = r.getAs[String]("not_return1")
//                  val not_return6: String = r.getAs[String]("not_return6")
//                  val not_return11: String = r.getAs[String]("not_return11")
//                  val not_return12: String = r.getAs[String]("not_return12")
//                  val not_return13: String = r.getAs[String]("not_return13")
//                  val inc_day: String = r.getAs[String]("inc_day")
//
//                  val del_sql: String = s"delete from gis_eta_pns_std_return_index where id =?"
//                  val statement0: PreparedStatement = connection.prepareStatement(del_sql)
//                  statement0.setString(1, id)
//                  statement0.executeUpdate()
//                  statement0.close()
//
//                  val insert_sql: String = "insert into gis_eta_pns_std_return_index values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
//                  val statement: PreparedStatement = connection.prepareStatement(insert_sql)
//
//                  statement.setString(1, id)
//                  statement.setString(2, start_dist)
//                  statement.setString(3, task_area_code)
//                  statement.setInt(4, pull_navi_type)
//                  statement.setString(5, distance)
//                  statement.setInt(6, stdrequest)
//                  statement.setInt(7, stdreturn)
//                  statement.setInt(8, top3_stdclick)
//                  statement.setInt(9, top3_click)
//                  statement.setInt(10, top3_strclick)
//                  statement.setInt(11, type9)
//                  statement.setInt(12, type8)
//                  statement.setInt(13, type2)
//                  statement.setInt(14, type10)
//                  statement.setInt(15, type5)
//                  statement.setInt(16, type7)
//                  statement.setInt(17, type4)
//                  statement.setInt(18, type1)
//                  statement.setInt(19, type6)
//                  statement.setInt(20, type11)
//                  statement.setInt(21, type12)
//                  statement.setInt(22, type13)
//                  statement.setString(23, std_return)
//                  statement.setString(24, stdclick)
//                  statement.setString(25, click)
//                  statement.setString(26, stdexit)
//                  statement.setString(27, not_return9)
//                  statement.setString(28, not_return8)
//                  statement.setString(29, not_return2)
//                  statement.setString(30, not_return10)
//                  statement.setString(31, not_return5)
//                  statement.setString(32, not_return7)
//                  statement.setString(33, not_return4)
//                  statement.setString(34, not_return1)
//                  statement.setString(35, not_return6)
//                  statement.setString(36, not_return11)
//                  statement.setString(37, not_return12)
//                  statement.setString(38, not_return13)
//                  statement.setString(39, inc_day)
//
//                  statement.executeUpdate()
//                  statement.close()
//              })
//
//              connection.close()
//          })
//
//        logger.error("成功写入到MySQL！")
//    }
//
//}
