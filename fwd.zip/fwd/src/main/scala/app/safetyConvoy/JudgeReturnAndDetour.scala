package app.safetyConvoy

import com.alibaba.fastjson._
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.HttpConnection.httpPost
import utils.SparkConfigUtil

import scala.collection.mutable.ArrayBuffer

/**
 * 任务名称：任务停留点及低速段识别
 * 任务ID：462234
 * 需求人员：邵一馨 01408890
 * 开发人员：王冬冬 01413698
 */
object JudgeReturnAndDetour {
  val qm_url3: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf?"
  val fusion_track_url: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrate"
  val fusion_track_url2: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"
  val track_jp_url: String = "http://gis-int2.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val vta_url: String = "http://gis-int.int.sfdc.com.cn:1080/lsssearch/api/vta?"

  // 初始化
  val className: String = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)

  def main(args: Array[String]): Unit = {
    // 接收外部传递进来的变量
    val inc_day: String = args(0)
    logger.error(s"取数日期：$inc_day ")
    // 创建spark
    val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)
    // 获取原始数据
    val origRDD: RDD[JSONObject] = getOrigData(spark, inc_day)
    // 获取纠偏轨迹、低速段
    val lineInfoDF: DataFrame = getLineInfo(spark, origRDD)
    // 最近30天的聚合数据
    val hisDF: DataFrame = getRecallData(spark, inc_day)
    // 判断绕行 和 是否经过疫情检查站
    isdetourOrJcz(spark, lineInfoDF, hisDF, inc_day)

    logger.error("运行结束！")
    // 程序运行结束,关闭spark
    spark.stop()
  }

  // 解析时效监控数据
  def getOrigData(spark: SparkSession, inc_day: String): RDD[JSONObject] = {
    import spark.implicits._

    val lineSql: String =
      s"""
         |select
         |  task_id,
         |  task_area_code,
         |  sort_num,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  start_type,
         |  end_type,
         |  line_code,
         |  vehicle_serial,
         |  plan_depart_tm,
         |  actual_depart_tm,
         |  plan_arrive_tm,
         |  actual_arrive_tm,
         |  driver_id,
         |  driver_name,
         |  line_time,
         |  actual_run_time,
         |  cast(ac_difftime_line_rt as double) / 60  as difftime_plan_actual,
         |  ac_is_run_ontime,
         |  line_distance,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  x1,
         |  y1,
         |  x2,
         |  y2,
         |  duration,
         |  time,
         |  rt_dist,
         |  vehicle_type,
         |  error_type,
         |  task_inc_day,
         |  halfway_integrate_rate,
         |  carrier_name,
         |  stop_over_zone_code,
         |  biz_type,
         |  require_category,
         |  to_ground,
         |  sim1,
         |  sim5,
         |  std_id,
         |  std_coords,
         |  last_update_tm,
         |  start_outer_add_code,
         |  end_outer_add_code,
         |  line_require_id,
         |  ac_is_run_ontime_std,
         |  conduct_type,
         |  highwaymileage,
         |  actual_capacity_load,
         |  if_evaluate_time
         |from
         |  (
         |    select
         |      row_number() over(partition by task_subid order by task_inc_day desc) as rn,
         |      *
         |    from
         |      dm_gis.eta_std_line_recall
         |    where
         |      inc_day = '$inc_day'
         |  ) a
         |where
         |  rn = 1
         |""".stripMargin
    val reportSql: String =
      s"""
         |select
         |  own_dept_code,
         |  driver_task_id,
         |  type,
         |  longitude,
         |  latitude,
         |  regexp_replace(description,'\n|\r|\t|','')    as description
         |from
         |  ods_shiva_ground.tm_abnormity_report
         |where
         |  inc_day >= '$inc_day'
         |""".stripMargin
    val confSql: String =
      """
        |select
        |  std_id         as std_id,
        |  highway        as std_highway,
        |  rt_distance    as std_dist
        |from
        |  dm_gis.eta_std_line_conf
        |""".stripMargin

    logger.error("相关任务数据：" + lineSql)
    logger.error("司机上报数据：" + reportSql)
    logger.error("线路配置数据：" + confSql)

    val lineDF: DataFrame = spark.sql(lineSql)
    val confDF: DataFrame = spark.sql(confSql)

    val reportDF: DataFrame = spark.sql(reportSql)
      .withColumn("task_id", concat($"own_dept_code", $"driver_task_id"))
      .withColumn("report_point", concat_ws(",", $"longitude", $"latitude"))
      .groupBy("task_id")
      .agg(
        concat_ws("|", collect_list("type")).as("report_type"),
        concat_ws("|", collect_list("report_point")).as("report_point"),
        concat_ws("|", collect_list("description")).as("report_description")
      )

    val origRDD: RDD[JSONObject] = lineDF
      .join(reportDF, Seq("task_id"), "left")
      .join(confDF, Seq("std_id"), "left")
      .withColumn("group", concat_ws("_", $"line_code", $"start_dept", $"end_dept", $"start_type", $"end_type"))
      .na.fill("没有值", Seq("report_type", "report_point", "report_description"))
      .na.fill("0", Seq("std_id", "std_highway", "std_dist"))
      .rdd
      .map(row2Json)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetRDDCountAndSampleData(logger, origRDD, "时效定责跑数数据")

    origRDD
  }

  // 调用融合轨迹接口
  def gettracksInfo(ak: String, o: JSONObject): Unit = {
    val un: String = o.getString("vehicle_serial")
    val actual_depart_tm: String = getDateStr(getTimestamp(o.getString("actual_depart_tm"), "yyyy-MM-dd HH:mm:ss"), "yyyyMMddHHmmss")
    val actual_arrive_tm: String = getDateStr(getTimestamp(o.getString("actual_arrive_tm"), "yyyy-MM-dd HH:mm:ss"), "yyyyMMddHHmmss")

    val parm: JSONObject = new JSONObject()
    parm.put("ak", ak)
    parm.put("un", un)
    parm.put("beginDateTime", actual_depart_tm)
    parm.put("endDateTime", actual_arrive_tm)
    parm.put("type", 0)
    parm.put("rectify", false)

    // 融合轨迹查询
    val jsonStr1: String = httpPost(3, fusion_track_url, parm.toJSONString)
    parseJsonStr(o, jsonStr1)

    // 融合轨迹查询
    parm.remove("rectify")
    parm.put("addpoint", 1)
    parm.put("stayDuration", 240)
    parm.put("stayRadius", 2000)
    parm.put("opt", "all")

    val jsonStr2: String = httpPost(3, fusion_track_url2, parm.toJSONString)
    parseJsonStr(o, jsonStr2, 2)
  }

  // 解析融合轨迹接口返回的json
  def parseJsonStr(o: JSONObject, jsonStr: String, flag: Int = 1): Unit = {
    val tracksBuff = new JSONArray()
    val pointsBuff = new ArrayBuffer[String]()

    try {
      val o2: JSONObject = JSON.parseObject(jsonStr)
      val status: String = o2.getString("status")
      if (status == "0") {
        logger.error("调用融合轨迹接口成功,进行业务逻辑处理中……")
        val result: JSONObject = o2.getJSONObject("result")
        val data: JSONObject = result.getJSONObject("data")

        val track: JSONArray = data.getJSONArray("track")
        val stayPoints: JSONArray = data.getJSONArray("stayPoints")

        if (flag == 1) {
          for (i <- 0 until track.size()) {
            val t: JSONObject = track.getJSONObject(i)

            val obj = new JSONObject()
            obj.put("type", 1)
            obj.put("x", t.getDoubleValue("zx"))
            obj.put("y", t.getDoubleValue("zy"))
            obj.put("accuracy", t.getIntValue("ac"))
            obj.put("speed", t.getDoubleValue("sp"))
            obj.put("azimuth", t.getDoubleValue("be"))
            obj.put("time", t.getLongValue("tm"))
            obj.put("index", i)
            tracksBuff.add(i, obj)
          }
        } else {
          for (i <- 0 until stayPoints.size()) {
            val t: JSONObject = stayPoints.getJSONObject(i)
            val startTime: Long = t.getLongValue("startTime")
            val endTime: Long = t.getLongValue("endTime")

            pointsBuff.append(getDateStr(startTime * 1000, "yyyy-MM-dd HH:mm:ss")
              + "_" + getDateStr(endTime * 1000, "yyyy-MM-dd HH:mm:ss"))
          }
        }
      }
    } catch {
      case e: Exception => logger.error("融合轨迹接口调用失败:" + e.getMessage)
    }

    if (flag == 1) o.put("his_tracks", tracksBuff.toJSONString)
    else o.put("disu_periods", "[" + pointsBuff.mkString(",") + "]")
  }

  // 获取纠偏轨迹信息
  def getjPTracksInfo(ak: String, o: JSONObject): Unit = {

    val parm: JSONObject = new JSONObject()

    val his_tracks: JSONArray = o.getJSONArray("his_tracks")

    parm.put("ak", ak)
    parm.put("poiinfo", 1)
    parm.put("keeptype", 1)
    parm.put("addpoint", 1)
    parm.put("roadinfo", 1)
    parm.put("retflag", 7)
    parm.put("only_primary", 0)

    val process: JSONObject = new JSONObject()
    process.put("stay_time", 900)
    process.put("stay_radius", 0)
    process.put("stay_join_dist", 20)
    parm.put("process", process)
    parm.put("tracks", his_tracks)

    // 获取纠偏轨迹
    val jsonStr: String = httpPost(3, track_jp_url, parm.toJSONString)
    o.remove("his_tracks")
    parseJPJsonStr(o, jsonStr)
  }

  // 解析纠偏接口返回的json
  def parseJPJsonStr(o: JSONObject, jsonStr: String): Unit = {
    val jp_swidBuff = new ArrayBuffer[String]()
    val jp_timeBuff = new ArrayBuffer[Long]()
    val jp_coordsBuff = new ArrayBuffer[String]()
    val jp_statusBuff = new ArrayBuffer[String]()
    val sum_distBuff = new ArrayBuffer[String]()
    val speedBuff = new ArrayBuffer[String]()
    val indexBuff = new ArrayBuffer[Int]()
    val time_periodsBuff = new ArrayBuffer[String]()
    val durationsBuff = new ArrayBuffer[String]()
    val stay_pointsBuff = new ArrayBuffer[String]()
    val roadBuff = new ArrayBuffer[String]()
    val roadclassBuff = new ArrayBuffer[String]()
    val linksBuff = new ArrayBuffer[String]()
    val linkBuff = new ArrayBuffer[String]()
    val lengthBuff = new ArrayBuffer[String]()

    val roadnameBuffTmp = new ArrayBuffer[String]()
    val roadclassBuffTmp = new ArrayBuffer[String]()
    val link_lengthBuffTmp = new ArrayBuffer[String]()

    try {
      val o2: JSONObject = JSON.parseObject(jsonStr)
      val status: String = o2.getString("status")
      if (status == "0") {
        logger.error("调用纠偏接口成功,进行业务逻辑处理中……")
        val result: JSONObject = o2.getJSONObject("result")
        val tracks: JSONArray = result.getJSONArray("tracks")
        val stay_points: JSONArray = result.getJSONArray("stay_points")

        for (i <- 0 until tracks.size()) {
          val t: JSONObject = tracks.getJSONObject(i)
          jp_swidBuff.append(t.getString("SWID"))
          jp_timeBuff.append(t.getLongValue("time"))

          val x: String = t.getString("x")
          val y: String = t.getString("y")
          jp_coordsBuff.append(x + "," + y)

          jp_statusBuff.append(t.getString("status"))
          sum_distBuff.append(t.getString("sum_dist"))
          speedBuff.append(t.getString("speed"))

          roadnameBuffTmp.append(t.getString("roadname"))
          roadclassBuffTmp.append(t.getString("roadclass"))
          link_lengthBuffTmp.append(t.getString("link_length"))
        }

        for (i <- 0 until stay_points.size()) {
          val t: JSONObject = stay_points.getJSONObject(i)
          val start_index: Int = t.getIntValue("start_index")
          val end_index: Int = t.getIntValue("end_index")
          indexBuff.append(start_index)

          time_periodsBuff.append(getDateStr(jp_timeBuff(start_index) * 1000L, "yyyy-MM-dd HH:mm:ss")
            + "_" + getDateStr(jp_timeBuff(end_index) * 1000L, "yyyy-MM-dd HH:mm:ss"))

          durationsBuff.append(t.getString("duration"))

          stay_pointsBuff.append(jp_coordsBuff(start_index))
          roadBuff.append(roadnameBuffTmp(start_index))
          roadclassBuff.append(roadclassBuffTmp(start_index))
          linksBuff.append(jp_swidBuff.slice(start_index, end_index + 1).distinct.mkString("_"))
          linkBuff.append(jp_swidBuff(start_index))
          lengthBuff.append(link_lengthBuffTmp(start_index))

        }
      }
    } catch {
      case e: Exception => logger.error("轨迹纠偏接口调用失败:" + e.getMessage)
    }

    o.put("jp_swid", jp_swidBuff.mkString("|"))
    o.put("jp_time", jp_timeBuff.mkString("|"))
    o.put("jp_coords", jp_coordsBuff.mkString("|"))
    o.put("jp_status", jp_statusBuff.mkString("|"))
    o.put("sum_dist", sum_distBuff.mkString("|"))
    o.put("speed", speedBuff.mkString("|"))
    o.put("tl_index", indexBuff.mkString("|"))
    o.put("tl_time_periods", "[" + time_periodsBuff.mkString(",") + "]")
    o.put("tl_durations", "[" + durationsBuff.mkString(",") + "]")
    o.put("tl_stay_points", stay_pointsBuff.mkString("|"))
    o.put("tl_road", roadBuff.mkString("|"))
    o.put("tl_roadclass", roadclassBuff.mkString("|"))
    o.put("tl_links", linksBuff.mkString("|"))
    o.put("tl_link", linkBuff.mkString("|"))
    o.put("tl_length", lengthBuff.mkString("|"))
  }

  // 调匹配接口
  def getqmInfo(ak: String, o: JSONObject): Unit = {
    val actual_depart_tm: String = getDateStr(getTimestamp(o.getString("actual_depart_tm"), "yyyy-MM-dd HH:mm:ss"), "yyyyMMddHHmmss")
    val jp_coords: String = o.getString("jp_coords")

    val parm: JSONObject = new JSONObject()
    parm.put("ak", ak)
    parm.put("date", actual_depart_tm)
    parm.put("points", jp_coords)
    parm.put("test", 1)
    parm.put("stype", 0)
    parm.put("etype", 0)
    parm.put("mode", 2)
    parm.put("rtic", 1)
    parm.put("output", "json")
    parm.put("opt", "sf4")

    // 融合轨迹查询
    val jsonStr: String = httpPost(3, qm_url3, parm.toJSONString)
    parseQMJsonStr(o, jsonStr)
  }

  // 解析融合轨迹接口返回的json
  def parseQMJsonStr(o: JSONObject, jsonStr: String): Unit = {
    val t_distanceBuff = new ArrayBuffer[Long]()
    val t_durationBuff = new ArrayBuffer[Double]()
    val toll_stationBuff = new ArrayBuffer[String]()
    val serviceBuff = new ArrayBuffer[String]()
    val toll_station_linkpointinfoBuff = new ArrayBuffer[String]()
    val service_station_linkpointinfoBuff = new ArrayBuffer[String]()
    val t_links_unionBuff = new ArrayBuffer[String]()
    var rt_event_info = ""
    var rt_event_cnt: Int = 0

    try {
      val o2: JSONObject = JSON.parseObject(jsonStr)
      val status: String = o2.getString("status")
      if (status == "0") {
        logger.error("调用匹配接口成功,进行业务逻辑处理中……")
        val route: JSONObject = o2.getJSONObject("route")
        val paths: JSONArray = route.getJSONArray("paths")

        val eventArr = new JSONArray()
        var m: Int = 0

        val arr1 = new ArrayBuffer[String]()
        val arr2 = new ArrayBuffer[String]()
        for (i <- 0 until paths.size()) {
          val path: JSONObject = paths.getJSONObject(i)
          t_distanceBuff.append(path.getLongValue("distance"))
          t_durationBuff.append(path.getDoubleValue("duration"))

          val polylineArr: Array[String] = path.getString("polyline").split(";")


          val steps: JSONArray = path.getJSONArray("steps")
          if (!steps.isEmpty) {
            for (j <- 0 until steps.size()) {
              val step: JSONObject = steps.getJSONObject(j)
              val links: JSONArray = step.getJSONArray("links")
              if (!links.isEmpty) {
                for (k <- 0 until links.size()) {
                  val link: JSONObject = links.getJSONObject(k)
                  val lnk_type: String = link.getString("lnk_type")
                  val formway: String = link.getString("formway")
                  val coorindex: Int = link.getIntValue("coorindex")
                  val pointnum: Int = link.getIntValue("pointnum")
                  val length: String = link.getString("length")

                  val id: String = link.getString("id")
                  val name: String = link.getString("name")
                  val roadclass: String = link.getString("roadclass")
                  val dr_length: String = link.getString("dr_length")

                  val start2EndPoint: String = polylineArr(coorindex) + ";" + polylineArr(coorindex + pointnum - 1)

                  val swid: String = link.getString("sw_id")
                  if (lnk_type == "2") {
                    toll_stationBuff.append(swid)
                    toll_station_linkpointinfoBuff.append(start2EndPoint)
                  }
                  if (formway == "5") {
                    serviceBuff.append(swid)
                    service_station_linkpointinfoBuff.append(start2EndPoint)
                  }

                  val rtic_event: JSONArray = link.getJSONArray("rtic_event")
                  if (!rtic_event.isEmpty) {
                    for (n <- 0 until rtic_event.size()) {
                      val r: JSONObject = rtic_event.getJSONObject(n)
                      val o3 = new JSONObject()
                      val x: String = r.getString("x")
                      val y: String = r.getString("y")

                      o3.put("event_code", r.getString("code"))
                      o3.put("event_title", r.getString("title"))
                      o3.put("event_content", r.getString("content"))
                      o3.put("event_xy1", x + "," + y)
                      o3.put("event_xy2", polylineArr(coorindex + pointnum))
                      o3.put("event_length", length)
                      o3.put("event_orCode", r.getString("orCode"))
                      o3.put("event_swids", swid)

                      eventArr.add(m, o3)
                      m = m + 1
                    }
                  }

                  arr1.append(swid + "," + id + "," + name + "," + formway + "," + roadclass + "," + coorindex + "," + pointnum + "," + dr_length)
                }
              }
            }
          }

          val outinfo: JSONObject = path.getJSONObject("outinfo")
          val links: JSONArray = outinfo.getJSONArray("links")


          if (!links.isEmpty) {
            for (i <- 0 until links.size()) {
              val link: JSONObject = links.getJSONObject(i)
              val lnk_type: String = link.getString("lnk_type")
              val mainaction: String = link.getString("mainaction")
              val ownership: String = link.getString("ownership")
              val dir: String = link.getString("dir")
              arr2.append(lnk_type + "," + mainaction + "," + ownership + "," + dir)
            }
          }
        }

        if (arr1.nonEmpty && arr2.nonEmpty) {
          val n: Int = math.min(arr1.length, arr2.length)
          for (i <- 0 until n) t_links_unionBuff.append(arr1(i) + "," + arr2(i))
        }


        rt_event_info = eventArr.toJSONString
        rt_event_cnt = eventArr.size()
      }
    } catch {
      case e: Exception => logger.error("匹配接口接口调用失败:" + e.getMessage)
    }
    o.put("t_distance", t_distanceBuff.sum)
    o.put("t_duration", t_durationBuff.sum)
    o.put("toll_station", toll_stationBuff.mkString("|"))
    o.put("service", serviceBuff.mkString("|"))
    o.put("toll_station_linkpointinfo", toll_station_linkpointinfoBuff.mkString("|"))
    o.put("service_station_linkpointinfo", service_station_linkpointinfoBuff.mkString("|"))
    o.put("t_links_union", t_links_unionBuff.mkString("|"))
    o.put("rt_event_info", rt_event_info)
    o.put("rt_event_cnt", rt_event_cnt)
  }

  // 调用高速接口
  def getvtaInfo(ak: String, o: JSONObject): Unit = {
    val vehicle_serial: String = o.getString("vehicle_serial")
    val std_dist: Int = o.getIntValue("std_dist")
    val std_highway: Int = o.getIntValue("std_highway")
    val task_id: String = o.getString("task_id")
    val actual_depart_tm: String = getDateStr(getTimestamp(o.getString("actual_depart_tm"), "yyyy-MM-dd HH:mm:ss"), "yyyyMMddHHmmss")
    val actual_arrive_tm: String = getDateStr(getTimestamp(o.getString("actual_arrive_tm"), "yyyy-MM-dd HH:mm:ss"), "yyyyMMddHHmmss")

    val parm: JSONObject = new JSONObject()
    parm.put("ak", ak)
    parm.put("vehicle", vehicle_serial)
    parm.put("taskId", task_id)
    parm.put("startDate", actual_depart_tm)
    parm.put("endDate", actual_arrive_tm)
    parm.put("retflag", 5)
    parm.put("planMileage", std_dist)
    parm.put("planHighwayMileage", std_highway)
    parm.put("threshold", 0.5)

    // 调用高速接口
    val jsonStr: String = httpPost(3, vta_url, parm.toJSONString)
    parseVtaJsonStr(o, jsonStr)
  }

  // 解析高速接口返回的json
  def parseVtaJsonStr(o: JSONObject, jsonStr: String): Unit = {
    try {
      val o2: JSONObject = JSON.parseObject(jsonStr)
      val status: String = o2.getString("status")
      if (status == "0") {
        logger.error("调用高速接口成功,进行业务逻辑处理中……")
        val result: JSONObject = o2.getJSONObject("result")
        o.put("highwaymileagepercentage", result.getString("highwayMileagePercentage"))
        o.put("mileagepercentage", result.getString("mileagePercentage"))
        o.put("trackreliable", result.getString("trackReliable"))
        o.put("highwaymileagepercentagevalid", result.getString("highwayMileagePercentageValid"))
      }
    } catch {
      case e: Exception => logger.error("匹配高速接口调用失败:" + e.getMessage)
    }
  }

  // 获取纠偏轨迹、低速段
  def getLineInfo(spark: SparkSession, origRDD: RDD[JSONObject]): DataFrame = {
    import spark.implicits._
    val httpInvoke_qm_url3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "462234", "任务停留点及低速段识别", "基础服务", qm_url3, "8bb09e5e110845f39a000391668e3e80", origRDD.count(), 8)
    val httpInvoke_fusion_track_url = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "462234", "任务停留点及低速段识别", "基础服务", fusion_track_url, "ef789d00926d46cdae8fc721608557ad", origRDD.count(), 8)
    val httpInvoke_fusion_track_url2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "462234", "任务停留点及低速段识别", "基础服务", fusion_track_url2, "ef789d00926d46cdae8fc721608557ad", origRDD.count(), 8)
    val httpInvoke_track_jp_url = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "462234", "任务停留点及低速段识别", "基础服务", track_jp_url, "ef789d00926d46cdae8fc721608557ad", origRDD.count(), 8)
    val httpInvoke_vta_url = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "462234", "任务停留点及低速段识别", "基础服务", vta_url, "ebf48ecaa1fd436fa3d40c4600aa051f", origRDD.count(), 8)
    val origDS: Dataset[String] = origRDD.repartition(8)
      .map(o => {
        gettracksInfo("ef789d00926d46cdae8fc721608557ad", o)
        getjPTracksInfo("ef789d00926d46cdae8fc721608557ad", o)
        getqmInfo("8bb09e5e110845f39a000391668e3e80", o)
        getvtaInfo("ebf48ecaa1fd436fa3d40c4600aa051f", o)
        o.toJSONString
      })
      .repartition(100)
      .toDS()
      .persist(StorageLevel.MEMORY_AND_DISK)

    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_qm_url3)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_fusion_track_url)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_fusion_track_url2)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_track_jp_url)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_vta_url)

    val lineDF: DataFrame = spark.read.json(origDS).persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, lineDF, "纠偏轨迹和低速段信息")
    origRDD.unpersist()
    origDS.unpersist()

    lineDF
  }

  // 获取起点与终点的距离
  def getDist: UserDefinedFunction = udf((startx: String, starty: String, endx: String, endy: String) => {
    var dist: Double = 0.0
    try {
      dist = getDistance(startx.toDouble, starty.toDouble, endx.toDouble, endy.toDouble)
    } catch {
      case e: Exception => logger.error("经纬度异常" + e.getMessage)
    }
    dist
  })

  // 疫情检查站判断
  def getJczInfo: UserDefinedFunction = udf((rt_event_info: String) => {
    val jczBuff = new ArrayBuffer[String]()
    val jcz_pointBuff = new ArrayBuffer[String]()
    val jcz_swidBuff = new ArrayBuffer[String]()

    try {
      val oa: JSONArray = JSON.parseArray(rt_event_info)
      for (i <- 0 until oa.size()) {
        val o: JSONObject = oa.getJSONObject(i)
        val event_orCode: String = o.getString("event_orCode")
        val event_title: String = o.getString("event_title")
        if (event_orCode == "0,0,6,16" || event_title == "疫情") {
          val event_content: String = o.getString("event_content")
          if (!isEmptyOrNull(event_content)) jczBuff.append(event_content.split("：")(0))
          jcz_pointBuff.append(o.getString("event_xy1"))
          jcz_swidBuff.append(o.getString("event_swids"))
        }
      }
    } catch {
      case e: Exception => logger.error("rt_event_info异常：" + e.getMessage)
    }

    val res = new Array[(String, String, String)](1)
    res(0) = (jczBuff.mkString("|"), jcz_pointBuff.mkString("|"), jcz_swidBuff.mkString("|"))
    res
  })

  // 获取近30天的数据
  def getRecallData(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._

    val task_inc_day: String = getdaysBeforeOrAfter(inc_day, 1)
    val inc_day2: String = getdaysBeforeOrAfter(inc_day, -30)
    val task_inc_day2: String = getdaysBeforeOrAfter(inc_day, -29)

    val recallSql: String =
      s"""
         |select
         |  *
         |from
         |  (
         |    select
         |      task_subid,
         |      start_dept,
         |      end_dept,
         |      start_type,
         |      end_type,
         |      line_code,
         |      ac_is_run_ontime,
         |      start_longitude,
         |      start_latitude,
         |      end_longitude,
         |      end_latitude,
         |      x1,
         |      y1,
         |      x2,
         |      y2,
         |      rt_dist,
         |      error_type,
         |      if_evaluate_time,
         |      row_number() over(partition by task_subid order by task_inc_day desc) as rn
         |    from
         |      dm_gis.eta_std_line_recall
         |    where
         |      inc_day >= '$inc_day2'
         |      and task_inc_day >= '$task_inc_day2'
         |      and task_inc_day <= '$task_inc_day'
         |  ) a
         |where
         |  rn = 1
         |  and if_evaluate_time = '1'
         |""".stripMargin

    logger.error("过去30天的数据：" + recallSql)

    val recallDF: Dataset[Row] = spark
      .sql(recallSql)
      .filter(!array_contains(split($"error_type", "|"), "4"))
      .filter($"rt_dist".cast("double") > 0.0)
      .withColumn("start_dist", getDist($"x1", $"y1", $"start_longitude", $"start_latitude"))
      .withColumn("end_dist", getDist($"x2", $"y2", $"end_longitude", $"end_latitude"))
      .filter("start_dist < 5000.0 and end_dist < 5000.0")
      .withColumn("group", concat_ws("_", $"line_code", $"start_dept", $"end_dept", $"start_type", $"end_type"))
      .groupBy("group")
      .agg(
        size(collect_set("task_subid")).as("group_count"),
        max($"rt_dist".cast("double")).as("group_max"),
        min($"rt_dist".cast("double")).as("group_min"),
        round(avg($"rt_dist".cast("double")), 2).as("group_mean"),
        round(stddev_pop($"rt_dist".cast("double")), 2).as("group_std"),
        size(collect_set(when($"ac_is_run_ontime" === "1.0", $"task_subid"))).as("group_ontime_count"),
        max(when($"ac_is_run_ontime" === "1.0", $"rt_dist".cast("double"))).as("group_ontime_max"),
        min(when($"ac_is_run_ontime" === "1.0", $"rt_dist".cast("double"))).as("group_ontime_min"),
        round(avg(when($"ac_is_run_ontime" === "1.0", $"rt_dist".cast("double"))), 2).as("group_ontime_mean"),
        round(stddev_pop(when($"ac_is_run_ontime" === "1.0", $"rt_dist".cast("double"))), 2).as("group_ontime_std")
      )
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, recallDF, "分组后的数据")
    recallDF
  }

  // 判断绕行 和 是否经过疫情检查站
  def isdetourOrJcz(spark: SparkSession, lineInfoDF: DataFrame, hisDF: DataFrame, inc_day: String): Unit = {
    import spark.implicits._

    val monitorDF: DataFrame = lineInfoDF.join(hisDF, Seq("group"), "left")
      .withColumn("distance_mean_std", $"rt_dist".cast("double") - $"group_mean" - $"group_std")
      .withColumn("ontime_distance_mean_std", $"rt_dist".cast("double") - $"group_ontime_mean" - $"group_ontime_std")
      .withColumn("raoxing_label",
        when($"distance_mean_std" > 0.0 and $"group_count" > 3 and $"ontime_distance_mean_std" > 0.0 and $"group_ontime_count" > 3, "30天内绕行|30天内准点绕行")
          .when($"distance_mean_std" > 0.0 and $"group_count" > 3, "30天内绕行")
          .when($"ontime_distance_mean_std" > 0.0 and $"group_ontime_count" > 3, "30天内准点绕行")
          .otherwise("无法判断")
      )
      .withColumn("info", explode(getJczInfo($"rt_event_info")))
      .withColumn("jcz", $"info._1")
      .withColumn("jcz_point", $"info._2")
      .withColumn("jcz_swid", $"info._3")
      .withColumn("inc_day", lit(inc_day))
      .drop("info")
      .select("group", "ac_is_run_ontime", "actual_arrive_tm", "actual_depart_tm", "actual_run_time", "biz_type", "carrier_name", "carrier_type", "difftime_plan_actual", "disu_periods", "driver_id", "driver_name", "duration", "end_dept", "end_latitude", "end_longitude", "end_type", "error_type", "halfway_integrate_rate", "is_stop", "jp_coords", "jp_status", "jp_swid", "jp_time", "line_code", "line_distance", "line_time", "plan_arrive_tm", "plan_depart_tm", "report_description", "report_point", "report_type", "require_category", "rt_dist", "rt_event_cnt", "rt_event_info", "service", "service_station_linkpointinfo", "sort_num", "speed", "start_dept", "start_latitude", "start_longitude", "start_type", "stop_over_zone_code", "sum_dist", "t_distance", "t_duration", "t_links_union", "task_area_code", "task_id", "task_inc_day", "task_subid", "time", "tl_durations", "tl_index", "tl_length", "tl_link", "tl_links", "tl_road", "tl_roadclass", "tl_stay_points", "tl_time_periods", "to_ground", "toll_station", "toll_station_linkpointinfo", "transoport_level", "vehicle_serial", "vehicle_type", "x1", "x2", "y1", "y2", "group_count", "group_max", "group_min", "group_mean", "group_std", "group_ontime_count", "group_ontime_max", "group_ontime_min", "group_ontime_mean", "group_ontime_std", "distance_mean_std", "ontime_distance_mean_std", "raoxing_label", "jcz", "jcz_point", "jcz_swid", "sim1", "sim5", "std_id", "std_coords", "last_update_tm", "start_outer_add_code", "end_outer_add_code", "line_require_id", "ac_is_run_ontime_std", "conduct_type", "highwaymileage", "actual_capacity_load", "if_evaluate_time", "std_highway", "std_dist", "highwaymileagepercentage", "mileagepercentage", "trackreliable", "highwaymileagepercentagevalid", "inc_day")
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, monitorDF, "绕行和检查站判断")
    df2HiveByOverwrite(logger, monitorDF, "dm_gis.eta_time_monitor")

    lineInfoDF.unpersist()
    hisDF.unpersist()
  }


}
