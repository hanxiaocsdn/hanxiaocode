package app.safetyConvoy

import com.alibaba.fastjson.JSONObject
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.SparkConfigUtil

import scala.util.control.Breaks

/**
 * 任务名称：告警分类明细和相应指标
 * 任务ID：453028
 * 需求人员：黄晓冰 01422522
 * 开发人员：王冬冬 01413698
 */
object AlarmClassDetailAndIndex {
  // 初始化
  val className: String = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)

  def main(args: Array[String]): Unit = {

    if (args.length != 1) {
      logger.error(
        """
          |需要输入1个参数：
          |    inc_day
          |""".stripMargin)
      sys.exit(-1)
    }

    // 接收外部传递进来的变量
    val inc_day: String = args(0)
    logger.error(s"取数日期：$inc_day ")
    // 创建spark
    val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

    // 告警分类明细
    val alarmDetailDF: DataFrame = getAlarmClassDetail(spark, inc_day)
    // 告警分类指标
    getalarmClassIndex(spark, alarmDetailDF, inc_day)


    logger.error("运行结束！")
    // 程序运行结束,关闭spark
    spark.stop()
  }

  // 当前日期往前1个小时的日期
  def oneHoursBeforeTime(alarm_time: String): String = {
    val l: Long = getTimestamp(alarm_time, "yyyy-MM-dd HH:mm:ss")
    val t: String = getDateStr(l - 60 * 60 * 1000, "yyyy-MM-dd HH:mm:ss")
    t
  }

  // 当前日期往后1个小时的日期
  def oneHoursLaterTime(alarm_time: String): String = {
    val l: Long = getTimestamp(alarm_time, "yyyy-MM-dd HH:mm:ss")
    val t: String = getDateStr(l + 60 * 60 * 1000, "yyyy-MM-dd HH:mm:ss")
    t
  }

  def getisRecall(carInfoList: List[JSONObject]): Unit = {
    for (o <- carInfoList) {
      o.put("is_recall", "0")
      val current_defend_status: String = o.getString("defend_status")

      if (current_defend_status == "1" || current_defend_status == "2") {
        val current_alarm_time: String = o.getString("alarm_time")
        val one_hours_before_time: String = oneHoursBeforeTime(current_alarm_time)

        val carInfoList2: List[JSONObject] = carInfoList
          .filter(o2 => {
            val alarm_time: String = o2.getString("alarm_time")
            if (alarm_time > one_hours_before_time && alarm_time <= current_alarm_time) true else false
          })

        if (carInfoList2.nonEmpty) {
          Breaks.breakable(
            for (o3 <- carInfoList2) {
              val risk_level: String = o3.getString("risk_level")
              if (risk_level == "1") {
                o.put("is_recall", "1")
                Breaks.break()
              }
            }
          )
        }

      }

    }
  }

  def getisCorret(carInfoList: List[JSONObject]): Unit = {
    for (o <- carInfoList) {
      o.put("is_correct", "0")
      val current_risk_level: String = o.getString("risk_level")

      if (current_risk_level == "1") {
        val current_alarm_time: String = o.getString("alarm_time")
        val one_hours_later_time: String = oneHoursLaterTime(current_alarm_time)

        val carInfoList2: List[JSONObject] = carInfoList
          .filter(o2 => {
            val alarm_time: String = o2.getString("alarm_time")
            if (alarm_time < one_hours_later_time && alarm_time >= current_alarm_time) true else false
          })

        if (carInfoList2.nonEmpty) {
          Breaks.breakable(
            for (o3 <- carInfoList2) {
              val defend_status: String = o3.getString("defend_status")
              if (defend_status == "1" || defend_status == "2") {
                o.put("is_correct", "1")
                Breaks.break()
              }
            }
          )
        }

      }

    }
  }

  def aggIndex(spark: SparkSession, df: DataFrame): DataFrame = {
    import spark.implicits._

    val aggDF: DataFrame = df.
      groupBy("cate", "type")
      .agg(
        sum($"is_recall".cast("int")).as("tp1"),
        sum($"is_correct".cast("int")).as("tp2"),
        sum(when($"defend_status".isin("1", "2"), 1).otherwise(0)).as("defend_num"),
        sum(when($"risk_level" === "1", 1).otherwise(0)).as("h_risk_num")
      )
      .withColumn("recall", round($"tp1".cast("double") / $"defend_num", 2))
      .withColumn("precision", round($"tp2".cast("double") / $"h_risk_num", 2))
      .na.fill(0.0, Seq("recall", "precision"))

    aggDF
  }

  // 告警过程明细
  def getAlarmClassDetail(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._

    val alarmSql: String =
      s"""
         |select
         |  *
         |from
         |  dm_arss.dm_alarm_detail_dtl_di
         |where
         |  inc_day='$inc_day'
         |""".stripMargin
    val wbSql: String =
      s"""
         |select
         |  *
         |from
         |  dm_arss.dm_alarm_detail_wb_dtl_di
         |where
         |  inc_day='$inc_day'
         |""".stripMargin
    val deviceSql: String =
      s"""
         |select
         |  carplate                      as car_no,
         |  substring(data_code,0,8)      as project
         |from
         |  dm_arss.dm_device_hh_dtl_di
         |where
         |  inc_day='$inc_day'
         |  and data_code is not null
         |  and data_code != ''
         |""".stripMargin

    logger.error(alarmSql)
    logger.error(wbSql)
    logger.error(deviceSql)

    val alarmDF: DataFrame = spark.sql(alarmSql).drop("alarm_meddle_messages", "process_logs", "defend_records", "driver_infos", "alarm_meddles",
      "alarm_audits", "alarm_media_entitys", "attribute1", "attribute2", "lng", "lat", "inc_day")
    val deviceDF: DataFrame = spark.sql(deviceSql)

    val wbDF: DataFrame = spark.sql(wbSql)
      .drop("alarm_meddle_messages", "process_logs", "defend_records", "driver_infos", "alarm_meddles",
        "alarm_audits", "alarm_media_entitys", "attribute1", "attribute2", "lng", "lat", "inc_day")
      .withColumn("attribute6", lit(""))
      .withColumn("attribute7", lit(""))

    val alarmDetailDS: Dataset[String] = alarmDF
      .union(wbDF)
      .join(deviceDF, Seq("car_no"), "left")
      .rdd
      .map(r => {
        val o: JSONObject = row2Json(r)
        val car_no: String = o.getString("car_no")
        (car_no, o)
      })
      .groupByKey()
      .flatMap(r => {
        val carInfoList: List[JSONObject] = r._2.toList
        getisRecall(carInfoList)
        getisCorret(carInfoList)
        carInfoList.map(_.toJSONString)
      })
      .toDS()
      .persist(StorageLevel.MEMORY_AND_DISK)

    val res_cols = spark.sql("""select * from dm_gis.alarm_class_detail limit 1""").schema.map(_.name).map(col)

    val alarmDetailDF: DataFrame = spark.read.json(alarmDetailDS)
      .select("id", "alarm_id", "ft_alarm_id", "car_no", "imei", "zy_type", "alarm_time", "alarm_name", "ft_p_type", "ft_sub_type", "p_type", "sub_type", "p_type_r", "sub_type_r", "r_flag", "tf_flag", "warn_id", "create_time", "update_time", "speed", "driver_name", "mobile", "risk_level", "risk_score", "status", "audit_status", "defend_status", "flow_type", "to_flow_type", "emp_code", "emp_id", "audit_emp_code", "audit_emp_id", "defend_emp_code", "defend_emp_id", "data_code", "dept_code", "dept_name", "parent_id", "serial_no", "recieve_time", "submit_time", "audit_recieve_time", "audit_submit_time", "defend_recieve_time", "defend_submit_time", "is_meddle", "no_meddle_remark", "attribute6", "attribute7", "project", "is_recall", "is_correct")
      .withColumn("mobile", lit(""))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
      .coalesce(50)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, alarmDetailDF, "告警分类明细数据")
    df2HiveByOverwrite(logger, alarmDetailDF, "dm_gis.alarm_class_detail")

    alarmDetailDS.unpersist()
    alarmDetailDF
  }

  // 告警汇总指标
  def getalarmClassIndex(spark: SparkSession, alarmDetailDF: DataFrame, inc_day: String): Unit = {
    import spark.implicits._

    // 按项目编号统计指标
    val alarmDetailDF1: DataFrame = alarmDetailDF
      .withColumn("cate", $"project")
      .withColumn("type", lit("1"))
    val alarmIndex1: DataFrame = aggIndex(spark, alarmDetailDF1)

    // 按设备类型统计指标
    val alarmDetailDF2: DataFrame = alarmDetailDF
      .withColumn("cate", $"zy_type")
      .withColumn("type", lit("2"))
    val alarmIndex2: DataFrame = aggIndex(spark, alarmDetailDF2)

    // 统计所有类型指标
    val alarmDetailDF3: DataFrame = alarmDetailDF
      .withColumn("cate", lit("all"))
      .withColumn("type", lit("0"))
    val alarmIndex3: DataFrame = aggIndex(spark, alarmDetailDF3)

    val alarmIndex: Dataset[Row] = alarmIndex1
      .union(alarmIndex2)
      .union(alarmIndex3)
      .withColumn("inc_day", lit(inc_day))
      .coalesce(1)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, alarmIndex, "告警分类指标明细")
    df2HiveByOverwrite(logger, alarmIndex, "dm_gis.alarm_class_index")
    alarmDetailDF.unpersist()
    alarmIndex.unpersist()
  }

}
