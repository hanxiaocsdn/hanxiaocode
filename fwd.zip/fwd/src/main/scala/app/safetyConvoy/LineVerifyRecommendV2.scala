package app.safetyConvoy

import app.safetyConvoy.LineVerifyRecommend.{getHisLineData, verifyRecommend}
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.SparkConfigUtil

import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.{Calendar, Date}

/**
 * 任务名称：线路推荐时长验证
 * 任务ID：471666
 * 需求人员：邵一馨 01408890
 * 开发人员：王冬冬 01413698、周勇 01390943
 */

object LineVerifyRecommendV2 {
  val className: String = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)

  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }
  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)
//    val spark = SparkSession
//      .builder()
//      .appName(className)
//      .config("spark.shuffle.useOldFetchProtocol", "true")
//      .config("spark.dynamicAllocation.enabled", "false")
//      .enableHiveSupport()
//      .getOrCreate()
    val inc_day: String = args(0)
    logger.error(s"取数日期：$inc_day")
    //第2部分 获取原始数据
    getorigData2(spark, inc_day)
    //第2部分  历史30天的数据
    val hisDF: DataFrame = getHisLineData2(spark, inc_day)
    //第2部分  验证推荐时长
    verifyRecommend2(spark, hisDF, inc_day)

    //第1部分 获取历史30天数据 + 验证推荐时长
    val (p1_hisDF, allDF) = getHisLineData(spark, inc_day)
    verifyRecommend(spark, p1_hisDF, inc_day)
    allDF.unpersist()

    logger.error("运行结束！")
    // 程序运行结束,关闭spark
    spark.stop()
  }

  // 汇总前面几个表的数据
  def getorigData2(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val yesterday: String = getdaysBeforeOrAfter(inc_day, -1)

    val monitorSql: String =
      s"""
         |select
         |  group,
         |  ac_is_run_ontime,
         |  actual_arrive_tm,
         |  actual_depart_tm,
         |  actual_run_time,
         |  biz_type,
         |  carrier_name,
         |  carrier_type,
         |  difftime_plan_actual,
         |  disu_periods,
         |  driver_id,
         |  driver_name,
         |  duration,
         |  end_dept,
         |  end_latitude,
         |  end_longitude,
         |  end_type,
         |  error_type,
         |  halfway_integrate_rate,
         |  is_stop,
         |  line_code,
         |  line_distance,
         |  line_time,
         |  plan_arrive_tm,
         |  plan_depart_tm,
         |  report_description,
         |  report_point,
         |  report_type,
         |  require_category,
         |  rt_dist,
         |  rt_event_cnt,
         |  rt_event_info,
         |  service,
         |  service_station_linkpointinfo,
         |  sort_num,
         |  start_dept,
         |  start_latitude,
         |  start_longitude,
         |  start_type,
         |  stop_over_zone_code,
         |  t_distance,
         |  t_duration,
         |  task_area_code,
         |  task_id,
         |  task_inc_day,
         |  task_subid,
         |  time,
         |  tl_durations,
         |  tl_index,
         |  tl_length,
         |  tl_link,
         |  tl_links,
         |  tl_road,
         |  tl_roadclass,
         |  tl_stay_points,
         |  tl_time_periods,
         |  to_ground,
         |  toll_station,
         |  toll_station_linkpointinfo,
         |  transoport_level,
         |  vehicle_serial,
         |  vehicle_type,
         |  x1,
         |  x2,
         |  y1,
         |  y2,
         |  group_count,
         |  group_max,
         |  group_min,
         |  group_mean,
         |  group_std,
         |  group_ontime_count,
         |  group_ontime_max,
         |  group_ontime_min,
         |  group_ontime_mean,
         |  group_ontime_std,
         |  distance_mean_std,
         |  ontime_distance_mean_std,
         |  raoxing_label,
         |  jcz,
         |  jcz_point,
         |  jcz_swid,
         |  sim1,
         |  sim5,
         |  std_id,
         |  std_coords,
         |  last_update_tm,
         |  start_outer_add_code,
         |  end_outer_add_code,
         |  line_require_id,
         |  ac_is_run_ontime_std,
         |  conduct_type,
         |  highwaymileage,
         |  actual_capacity_load,
         |  if_evaluate_time,
         |  std_highway,
         |  std_dist,
         |  highwaymileagepercentage,
         |  mileagepercentage,
         |  trackreliable,
         |  highwaymileagepercentagevalid
         |from
         |  dm_gis.eta_time_monitor
         |where
         |  inc_day = '$inc_day'
         |""".stripMargin
    val tingliuSql: String =
      s"""
         |select
         |  task_subid,
         |  plan_run_time,
         |  service_rest_times,
         |  service_plan_stay_duration,
         |  total_stay_points_sort_num,
         |  total_stay_points_label,
         |  total_stay_points,
         |  total_stay_points_duration,
         |  total_stay_points_delay_ratio,
         |  suspected_abnormal_tingliu,
         |  service_label_sort_num,
         |  service_label_points,
         |  service_total_stay_points_duration,
         |  service_more_stay_duration,
         |  service_total_stay_points_duration_ratio,
         |  service_total_stay_points_duration_delay_ratio,
         |  toll_station_sub_label_sort_num,
         |  toll_station_sub_label_points,
         |  toll_station_sub_total_stay_points_duration,
         |  toll_station_sub_total_stay_points_duration_ratio,
         |  toll_station_ob_label_sort_num,
         |  toll_station_ob_label_points,
         |  toll_station_ob_total_stay_points_duration,
         |  toll_station_ob_total_stay_points_duration_ratio,
         |  epidemic_sub_label_sort_num,
         |  epidemic_sub_label_points,
         |  epidemic_sub_total_stay_points_duration,
         |  epidemic_sub_total_stay_points_duration_ratio,
         |  epidemic_sub_total_stay_points_duration_delay_ratio,
         |  epidemic_ob_label_sort_num,
         |  epidemic_ob_label_points,
         |  epidemic_ob_total_stay_points_duration,
         |  epidemic_ob_total_stay_points_duration_ratio,
         |  start_label_sort_num,
         |  start_label_points,
         |  start_total_stay_points_duration,
         |  start_total_stay_points_duration_ratio,
         |  start_total_stay_points_duration_delay_ratio,
         |  end_label_sort_num,
         |  end_label_points,
         |  end_total_stay_points_duration,
         |  end_total_stay_points_duration_ratio,
         |  end_total_stay_points_duration_delay_ratio,
         |  jyz_label_sort_num,
         |  jyz_label_points,
         |  jyz_total_stay_points_duration,
         |  jyz_total_stay_points_duration_ratio,
         |  jyz_total_stay_points_duration_delay_ratio,
         |  other_event_label_sort_num,
         |  other_event_label_points,
         |  other_event_total_stay_points_duration,
         |  other_event_total_stay_points_duration_ratio,
         |  highlow_level_label_sort_num,
         |  highlow_level_label_points,
         |  highlow_level_total_stay_points_duration,
         |  highlow_level_total_stay_points_duration_ratio,
         |  highlow_level_total_stay_points_duration_delay_ratio,
         |  gaosu_sub_label_sort_num,
         |  gaosu_sub_label_points,
         |  gaosu_sub_total_stay_points_duration,
         |  gaosu_sub_total_stay_points_duration_ratio,
         |  gaosu_sub_total_stay_points_duration_delay_ratio,
         |  gaosu_ob_label_sort_num,
         |  gaosu_ob_label_points,
         |  gaosu_ob_total_stay_points_duration,
         |  gaosu_ob_total_stay_points_duration_ratio,
         |  no_sub_label_sort_num,
         |  no_sub_label_points,
         |  no_sub_total_stay_points_duration,
         |  no_sub_total_stay_points_duration_ratio,
         |  no_sub_total_stay_points_duration_delay_ratio,
         |  no_ob_label_sort_num,
         |  no_ob_label_points,
         |  no_ob_total_stay_points_duration,
         |  no_ob_total_stay_points_duration_ratio,
         |  no_label_sort_num,
         |  no_label_points,
         |  no_total_stay_points_duration,
         |  no_total_stay_points_duration_ratio,
         |  no_total_stay_points_duration_delay_ratio,
         |  total_stay_points_contents,
         |  total_stay_points_eventcode,
         |  peak_congestion_label_sort_num,
         |  peak_congestion_label_points,
         |  peak_congestion_total_stay_points_duration,
         |  peak_congestion_total_stay_points_duration_ratio,
         |  peak_congestion_total_stay_points_duration_delay_ratio
         |from  dm_gis.eta_time_monitor_tingliu
         |where  inc_day = '$inc_day'
         |""".stripMargin
    val disuSql: String =
      s"""
         |select
         |  task_subid,
         |  service_ob_lowspeed_duration,
         |  service_sub_lowspeed_duration,
         |  service_ob_sub_lowspeed_duration,
         |  service_ob_lowspeed_duration_delay_ratio,
         |  service_sub_lowspeed_duration_delay_ratio,
         |  service_ob_sub_lowspeed_duration_delay_ratio,
         |  tollstation_ob_lowspeed_duration,
         |  tollstation_sub_lowspeed_duration,
         |  tollstation_ob_sub_lowspeed_duration,
         |  tollstation_ob_lowspeed_duration_delay_ratio,
         |  tollstation_sub_lowspeed_duration_delay_ratio,
         |  tollstation_ob_sub_lowspeed_duration_delay_ratio,
         |  epidemic_ob_lowspeed_duration,
         |  epidemic_sub_lowspeed_duration,
         |  epidemic_ob_sub_lowspeed_duration,
         |  epidemic_ob_lowspeed_duration_delay_ratio,
         |  epidemic_sub_lowspeed_duration_delay_ratio,
         |  epidemic_ob_sub_lowspeed_duration_delay_ratio,
         |  other_ob_lowspeed_duration,
         |  other_sub_lowspeed_duration,
         |  other_ob_sub_lowspeed_duration,
         |  other_ob_lowspeed_duration_delay_ratio,
         |  other_sub_lowspeed_duration_delay_ratio,
         |  other_ob_sub_lowspeed_duration_delay_ratio,
         |  end_ob_lowspeed_duration,
         |  end_sub_lowspeed_duration,
         |  end_ob_sub_lowspeed_duration,
         |  end_ob_lowspeed_duration_delay_ratio,
         |  end_sub_lowspeed_duration_delay_ratio,
         |  end_ob_sub_lowspeed_duration_delay_ratio,
         |  start_ob_lowspeed_duration,
         |  start_sub_lowspeed_duration,
         |  start_ob_sub_lowspeed_duration,
         |  start_ob_lowspeed_duration_delay_ratio,
         |  start_sub_lowspeed_duration_delay_ratio,
         |  start_ob_sub_lowspeed_duration_delay_ratio,
         |  no_ob_lowspeed_duration,
         |  no_sub_lowspeed_duration,
         |  no_ob_sub_lowspeed_duration,
         |  no_ob_lowspeed_duration_delay_ratio,
         |  no_sub_lowspeed_duration_delay_ratio,
         |  no_ob_sub_lowspeed_duration_delay_ratio,
         |  disu_cnt,
         |  disu_rank,
         |  disu_periods as disu_periods_final,
         |  disu_duration,
         |  disu_dis,
         |  disu_speed,
         |  if_tl_in_disu,
         |  disu_duration_tl,
         |  disu_label_3,
         |  disu_sub_oj,
         |  disu_label_sub_oj,
         |peak_congestion_lowspeed_duration,
         |peak_congestion_lowspeed_duration_delay_ratio,
         |other_event_content,
         |other_event_code,
         |disu_duration_sub_ob
         |from dm_gis.eta_time_monitor_disu_2
         |where inc_day = '$inc_day'
         |""".stripMargin
    val recSql: String =
      s"""
         |select
         |  group,
         |  task_count                            as rec_task_count,
         |  new_task_count                        as rec_new_task_count,
         |  new_task_ontime_ratio_before          as rec_new_task_ontime_ratio_before,
         |  new_task_ontime_ratio_after           as rec_new_task_ontime_ratio_after,
         |  ontime_increase                       as rec_ontime_increase,
         |  rec_time                              as rec_time,
         |  time_change                           as rec_time_change,
         |  task_ontime_ratio2                    as rec_task_ontime_ratio2,
         |  task_ontime_ratio3                    as rec_task_ontime_ratio3,
         |  new_30min_ratio                       as rec_new_30min_ratio,
         |  new_60min_ratio                       as rec_new_60min_ratio,
         |  new_10per_ratio                       as rec_new_10per_ratio
         |From
         |  dm_gis.eta_time_recommendation
         |where
         |  inc_day ='$yesterday'
         |""".stripMargin

    logger.error("监控数据:" + monitorSql)
    logger.error("停留数据:" + tingliuSql)
    logger.error("低速数据:" + disuSql)
    logger.error("推荐数据:" + recSql)

    val monitorDF: DataFrame = spark.sql(monitorSql)
    val tingliuDF: DataFrame = spark.sql(tingliuSql)
    val disuDF: DataFrame = spark.sql(disuSql)
    val recDF: DataFrame = spark.sql(recSql)

    val taskDF: DataFrame = monitorDF
      .join(tingliuDF, Seq("task_subid"), "left")
      .join(disuDF, Seq("task_subid"), "left")
      .join(recDF, Seq("group"), "left")
      .na.fill("0.0", Array(
      "total_stay_points_duration", "gaosu_sub_total_stay_points_duration", "service_plan_stay_duration", "start_total_stay_points_duration", "actual_run_time", "highlow_level_total_stay_points_duration",
      "jyz_total_stay_points_duration", "service_total_stay_points_duration", "end_total_stay_points_duration", "toll_station_ob_total_stay_points_duration", "epidemic_ob_total_stay_points_duration", "other_event_total_stay_points_duration", "gaosu_ob_total_stay_points_duration",
      "no_ob_total_stay_points_duration", "toll_station_sub_total_stay_points_duration", "epidemic_sub_total_stay_points_duration", "jyz_total_stay_points_duration_delay_ratio", "service_sub_lowspeed_duration", "service_ob_lowspeed_duration", "service_ob_sub_lowspeed_duration", "tollstation_sub_lowspeed_duration",
      "tollstation_ob_lowspeed_duration", "tollstation_ob_sub_lowspeed_duration", "epidemic_sub_lowspeed_duration", "epidemic_ob_lowspeed_duration", "epidemic_ob_sub_lowspeed_duration", "start_sub_lowspeed_duration",
      "start_ob_lowspeed_duration", "start_ob_sub_lowspeed_duration", "end_sub_lowspeed_duration", "end_ob_lowspeed_duration", "end_ob_sub_lowspeed_duration", "other_ob_lowspeed_duration", "other_sub_lowspeed_duration",
      "other_ob_sub_lowspeed_duration", "no_sub_total_stay_points_duration", "no_sub_lowspeed_duration", "no_ob_lowspeed_duration", "no_ob_sub_lowspeed_duration","peak_congestion_total_stay_points_duration","peak_congestion_lowspeed_duration"
    ))
      .na.fill(0, Array("rec_task_count", "rec_time_change", "rec_ontime_increase", "rec_time"))
      .na.fill(0.0, Array("rec_task_ontime_ratio2", "rec_task_ontime_ratio3", "rec_new_30min_ratio", "rec_new_60min_ratio", "rec_new_10per_ratio"))
      .withColumn("total_stay_points_duration", when($"total_stay_points_duration" === "", "0.0").otherwise($"total_stay_points_duration"))
      .withColumn("gaosu_sub_total_stay_points_duration", when($"gaosu_sub_total_stay_points_duration" === "", "0.0").otherwise($"gaosu_sub_total_stay_points_duration"))
      .withColumn("service_plan_stay_duration", when($"service_plan_stay_duration" === "", "0.0").otherwise($"service_plan_stay_duration"))
      .withColumn("difftime_plan_actual", when($"difftime_plan_actual".isNull or $"difftime_plan_actual" === "", 0.0).otherwise($"difftime_plan_actual"))
      .withColumn("start_total_stay_points_duration", when($"start_total_stay_points_duration" === "", "0.0").otherwise($"start_total_stay_points_duration"))
      .withColumn("actual_run_time", when($"actual_run_time" === "", "0.0").otherwise($"actual_run_time"))
      .withColumn("highlow_level_total_stay_points_duration", when($"highlow_level_total_stay_points_duration" === "", "0.0").otherwise($"highlow_level_total_stay_points_duration"))
      .withColumn("jyz_total_stay_points_duration", when($"jyz_total_stay_points_duration" === "", "0.0").otherwise($"jyz_total_stay_points_duration"))
      .withColumn("is_rec", when($"rec_task_count" > 3 and $"rec_task_ontime_ratio3" <= 0.8 and $"rec_task_ontime_ratio2" <= 0.7
        and $"rec_time_change" > 0 and $"rec_ontime_increase" > 0, 1)
        .otherwise(0)
      )
      .withColumn("is_rec_satisfied",
        when($"rec_time" <= 240 and $"rec_new_30min_ratio" >= 0.9, 1)
          .when($"rec_time" > 240 and $"rec_time" <= 480 and $"rec_new_60min_ratio" >= 0.8, 1)
          .when($"rec_time" > 480 and $"rec_new_10per_ratio" >= 0.7, 1)
          .otherwise(0)
      ).persist(StorageLevel.MEMORY_AND_DISK_SER)
     //service_final+service_ob_final+jyz_total_stay_points_duration/60
    val r1 = taskDF.withColumn("service_final", round(($"service_total_stay_points_duration".cast("double") + $"service_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("service_ob_final", round(($"service_ob_lowspeed_duration".cast("double") + $"service_ob_sub_lowspeed_duration") / 60, 2))
      //20221125修改service_gaosu_final
      .withColumn("service_gaosu_final", round($"service_final".cast("double") + $"service_ob_final".cast("double") + $"jyz_total_stay_points_duration".cast("double") / 60, 2))
      .withColumn("tollstation_sub_final", round(($"toll_station_sub_total_stay_points_duration".cast("double") + $"tollstation_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("tollstation_sub_final_ratio", round($"tollstation_sub_final" / $"difftime_plan_actual", 2))
      .withColumn("tollstation_ob_final", round(($"toll_station_ob_total_stay_points_duration".cast("double") + $"tollstation_ob_lowspeed_duration".cast("double") + $"tollstation_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("tollstation_ob_final_ratio", round($"tollstation_ob_final" / $"difftime_plan_actual", 2))
      .withColumn("epidemic_sub_final", round(($"epidemic_sub_total_stay_points_duration".cast("double") + $"epidemic_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("epidemic_sub_final_ratio", round($"epidemic_sub_final" / $"difftime_plan_actual", 2))
      .withColumn("epidemic_ob_final", round(($"epidemic_ob_total_stay_points_duration".cast("double") + $"epidemic_ob_lowspeed_duration".cast("double") + $"epidemic_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("epidemic_ob_final_ratio", round($"epidemic_ob_final" / $"difftime_plan_actual", 2))
      .withColumn("start_sub_final", round(($"start_total_stay_points_duration".cast("double") + $"start_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("start_sub_final_ratio", round($"start_sub_final" / $"difftime_plan_actual", 2))
      .withColumn("start_ob_final", round(($"start_ob_lowspeed_duration".cast("double") + $"start_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("start_ob_final_ratio", round($"start_ob_final" / $"difftime_plan_actual", 2))
      .withColumn("end_sub_final", round(($"end_total_stay_points_duration".cast("double") + $"end_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("end_sub_final_ratio", round($"end_sub_final" / $"difftime_plan_actual", 2))
      .withColumn("end_ob_final", round(($"end_ob_lowspeed_duration".cast("double") + $"end_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("end_ob_final_ratio", round($"end_ob_final" / $"difftime_plan_actual", 2))
      //20221125修改other_event_final
      .withColumn("other_event_final", round(($"other_event_total_stay_points_duration".cast("double") + $"other_ob_lowspeed_duration".cast("double") +
         $"other_sub_lowspeed_duration".cast("double") + $"other_ob_sub_lowspeed_duration".cast("double") + $"gaosu_ob_total_stay_points_duration".cast("double")) / 60, 2))
      .withColumn("other_event_final_ratio", round($"other_event_final" / $"difftime_plan_actual", 2))
      .withColumn("no_label_sub_final", round(($"no_sub_total_stay_points_duration".cast("double") + $"no_sub_lowspeed_duration".cast("double")) / 60, 2))
      .withColumn("no_label_sub_final_ratio", round($"no_label_sub_final" / $"difftime_plan_actual", 2))
      //20221125修改no_label_ob_final (no_ob_total_stay_points_duration+no_ob_lowspeed_duration+no_ob_sub_lowspeed_duration)/60
      .withColumn("no_label_ob_final", round(($"no_ob_total_stay_points_duration".cast("double") + $"no_ob_lowspeed_duration".cast("double") + $"no_ob_sub_lowspeed_duration".cast("double") ) / 60, 2))
      .withColumn("no_label_ob_final_ratio", round($"no_label_ob_final" / $"difftime_plan_actual", 2))
      //.withColumn("service_rest_times", floor($"line_time".cast("double") / 240))
      //20230213修改
      .withColumn("service_rest_times", when($"vehicle_serial".contains("粤") && $"plan_depart_tm".isNotNull && trim($"plan_depart_tm") =!=""
        && $"plan_arrive_tm".isNotNull && trim($"plan_arrive_tm") =!="",rest_ct_udf($"plan_depart_tm",$"plan_arrive_tm"))
        .otherwise(floor($"line_time".cast("double") / 240)))

      //修改20221125字段service_plan_stay_duration
      //重新赋值service_plan_stay_duration
      //20221125新增字段
      .withColumn("service_tl_cn_test",service_tl_cn_udf($"total_stay_points_label"))
      .withColumn("jiayouzhan_tl_cn_test",jiayouzhan_tl_cn_udf($"total_stay_points_label"))
      .withColumn("gaosu_tl_sub_cn_test",gaosu_tl_sub_cn_udf($"total_stay_points_label"))
      .withColumn("service_ds_sub_cn_test",service_ds_sub_cn_udf($"disu_label_sub_oj"))
      .withColumn("service_ds_ob_cn_test",service_ds_ob_cn_udf($"disu_label_sub_oj"))
      .withColumn("service_sj_rest_times_test",$"jiayouzhan_tl_cn_test"+$"service_ds_sub_cn_test"+$"service_ds_ob_cn_test")

      .withColumn("service_plan_stay_duration_test", when($"service_rest_times">$"service_sj_rest_times_test",$"service_sj_rest_times_test").otherwise($"service_rest_times") )
      .withColumn("service_plan_stay_duration", ($"service_plan_stay_duration_test"* 1200).cast("string"))
      .drop("service_plan_stay_duration_test")
      //20111129修改zhuguan_fuwuqu
      .withColumn("zhuguan_fuwuqu_test", round($"service_gaosu_final" - $"service_plan_stay_duration".cast("double") / 60, 2))
      .withColumn("zhuguan_fuwuqu", when($"zhuguan_fuwuqu_test"<0,0.0).otherwise($"zhuguan_fuwuqu_test"))
      .drop("zhuguan_fuwuqu_test")
      .withColumn("zhuguan_fuwuqu_ratio", $"zhuguan_fuwuqu" / $"difftime_plan_actual")
      .withColumn("actual_run_tm3", round($"actual_run_time".cast("double") - $"zhuguan_fuwuqu" - $"start_sub_final" - $"end_sub_final", 2))
      .withColumn("actual_run_tm4", round($"actual_run_time".cast("double") - $"service_gaosu_final" - $"start_sub_final" - $"end_sub_final" - $"highlow_level_total_stay_points_duration".cast("double") / 60 - $"jyz_total_stay_points_duration".cast("double") / 60, 2))
      .na.fill(0.0, Array("actual_run_tm3", "actual_run_tm4"))
      .withColumn("t_duration2", round($"t_duration" * 1.1, 2))
      .withColumn("time_diff_gaode", round($"actual_run_tm3" - $"t_duration2" / 60, 2))
      .withColumn("time_diff_gaode_ratio", round($"time_diff_gaode" * 60 / $"t_duration2", 2))
      .withColumn("time_diff_gaode2", round($"actual_run_tm4" - $"t_duration2" / 60, 2))
      .withColumn("time_diff_gaode2_ratio", round($"time_diff_gaode2" * 60 / $"t_duration2", 2))
      .withColumn("task_final_label", when(array_contains(split($"error_type", "|"), "4") or array_contains(split($"error_type", "|"), "5") or $"rt_dist".cast("double") === 0.0, "轨迹异常")
        .when($"raoxing_label".isNotNull and $"raoxing_label" =!= "无法判断", "线路绕行")
        .when($"time_diff_gaode2_ratio" > 0.2, "与高德校验异常")
        .otherwise("无法判断"))
      //20230214修改total_keguan
      //.withColumn("peak_congestion_total_stay_points_duration",when($"peak_congestion_total_stay_points_duration".isNull || trim($"peak_congestion_total_stay_points_duration")==="",0.0).otherwise($"peak_congestion_total_stay_points_duration").cast("double"))
      //.withColumn("peak_congestion_lowspeed_duration",when($"peak_congestion_lowspeed_duration".isNull || trim($"peak_congestion_lowspeed_duration")==="",0.0).otherwise($"peak_congestion_lowspeed_duration").cast("double"))
      .withColumn("peak_congestion_final", round(($"peak_congestion_lowspeed_duration"+$"peak_congestion_total_stay_points_duration")/60, 2))
      .withColumn("total_keguan", round($"epidemic_ob_final".cast("double") + $"other_event_final" +
        $"tollstation_ob_final" + $"no_label_ob_final" + $"peak_congestion_final" , 2))
      .withColumn("total_keguan_ratio", round($"total_keguan" / $"difftime_plan_actual", 2))

      //20221125修改total_zhuguan
      .withColumn("total_zhuguan", when(round($"zhuguan_fuwuqu" + $"tollstation_sub_final" + $"epidemic_sub_final" + $"start_sub_final" + $"no_label_sub_final"+ $"gaosu_sub_total_stay_points_duration"/60 , 2)<0 , 0)
        .otherwise(round($"zhuguan_fuwuqu" + $"tollstation_sub_final" + $"epidemic_sub_final" + $"start_sub_final" + $"no_label_sub_final"+ $"gaosu_sub_total_stay_points_duration"/60, 2)))
      //20221021修改total_zhuguan
      //.withColumn("total_zhuguan", round($"zhuguan_fuwuqu" + $"tollstation_sub_final" + $"epidemic_sub_final" + $"start_sub_final" + $"end_sub_final" + $"no_label_sub_final", 2))
      .withColumn("total_zhuguan_ratio", round($"total_zhuguan" / $"difftime_plan_actual", 2))
      //20221125修改task_label1
      .withColumn("task_label1", when($"ac_is_run_ontime" === "0.0" and ($"total_zhuguan_ratio" <= -0.5 or ($"trackreliable" === "true" and $"highwaymileagepercentagevalid" === "false" and 'std_highway.cast("int") > 2000 and 'std_dist.cast("int") > 10000 and 'std_highway.cast("double") / 'std_dist.cast("int") > 0.05 and 'conduct_type === "3")), "主观")
        .when($"ac_is_run_ontime" === "0.0" and $"end_sub_final_ratio" <= -0.5,"终点异常")
        .when($"ac_is_run_ontime" === "0.0" and $"is_rec" === 1 and $"is_rec_satisfied" === 1 and ($"rec_time".cast("double") - 'line_time.cast("double")) / $"difftime_plan_actual" <= -0.5, "规划时长不足")
        .when($"ac_is_run_ontime" === "0.0" and 'total_keguan_ratio <= -0.5, "客观")
        .when($"ac_is_run_ontime" === "0.0" , "系统未识别")
        .otherwise(""))
      //20230213新增
      .withColumn("dept_pro", round($"start_total_stay_points_duration"/60, 2)+$"end_sub_final"+$"end_ob_final")
      .withColumn("dept_pro_ratio", round($"dept_pro"/$"difftime_plan_actual", 2))
      .withColumn("peak_congestion_final_ratio", round($"peak_congestion_final"/$"difftime_plan_actual", 2))
      .withColumn("total_keguan1", round($"epidemic_ob_final".cast("double") + $"start_ob_final" +$"other_event_final" +
        $"tollstation_ob_final" + $"no_label_ob_final" + $"peak_congestion_final" , 2))
      .withColumn("total_keguan_ratio1", round($"total_keguan1"/$"difftime_plan_actual", 2))
      .withColumn("total_zhuguan1", when(round($"zhuguan_fuwuqu" + $"tollstation_sub_final" + $"epidemic_sub_final" + $"start_sub_lowspeed_duration"/60+
        $"no_label_sub_final"+ $"gaosu_sub_total_stay_points_duration"/60, 2)<0 , 0)
        .otherwise(round($"zhuguan_fuwuqu" + $"tollstation_sub_final" + $"epidemic_sub_final" + $"start_sub_lowspeed_duration"/60+
           $"no_label_sub_final"+ $"gaosu_sub_total_stay_points_duration"/60, 2)))
      .withColumn("total_zhuguan_ratio1", round($"total_zhuguan1" / $"difftime_plan_actual", 2))

    //选择所需列
    //val table_cols = spark.sql("""select * from dm_gis.eta_task_time_information limit 0""").schema.map(_.name).map(col)
    val table_cols = spark.sql("""select * from dm_gis.eta_task_time_information limit 0""").schema.map(_.name).map(col)

    val r2 = r1.withColumn("keguan1", when($"task_label1" === "客观" and $"tollstation_ob_final_ratio" <= -0.5, "收费站客观停留/低速"))
      .withColumn("keguan2", when($"task_label1" === "客观" and $"epidemic_ob_final_ratio" <= -0.5, "疫情检查"))
      .withColumn("keguan4", when($"task_label1" === "客观" and $"other_event_final_ratio" <= -0.5, "其他事件"))
      .withColumn("keguan5", when($"task_label1" === "客观" and $"no_label_ob_final_ratio" <= -0.5, "路况拥堵"))
      //20230210修改
      .withColumn("keguan6", when($"task_label1" === "客观" and $"peak_congestion_final_ratio" <= -0.5, "高峰拥堵"))
      //20221125修改task_label_keguan，删除keguan3,keguan8
      .withColumn("task_label_keguan", concat_ws("|", $"keguan1", $"keguan2", $"keguan4", $"keguan5", $"keguan6"))
      .withColumn("flag1", when($"task_label1" === "主观" and $"zhuguan_fuwuqu_ratio" <= -0.5, "服务区主观停留/低速"))
      .withColumn("flag2", when($"task_label1" === "主观" and $"start_sub_final_ratio" <= -0.5, "起点主观停留/低速"))
      .withColumn("flag2a", when($"task_label1" === "主观" and $"gaosu_sub_total_stay_points_duration_delay_ratio" <= -0.5, "高速主观停留"))
      .withColumn("flag2b", when($"task_label1" === "主观" and $"no_label_sub_final_ratio" <= -0.5, "其他主观停留/低速"))
      .withColumn("flag4", when($"task_label1" === "主观" and $"tollstation_sub_final_ratio" <= -0.5, "收费站主观停留/低速"))
      .withColumn("flag5", when($"task_label1" === "主观" and $"epidemic_sub_final_ratio" <= -0.5, "疫情检查站主观停留/低速"))
      .withColumn("flag6", when($"task_label1" === "主观" and $"trackreliable" === "true" and $"highwaymileagepercentagevalid" === "false" and 'std_highway.cast("int") > 2000 and 'std_dist.cast("int") > 10000 and 'std_highway.cast("double") / 'std_dist.cast("int") > 0.05 and 'conduct_type === "3", "未全程高速"))
      //20221125修改task_label_zhuguan
      .withColumn("task_label_zhuguan", concat_ws("|", $"flag1", $"flag2",$"flag2a",$"flag2b", $"flag4", $"flag5", $"flag6"))
      .withColumn("task_label_other", when($"task_label1" === "系统未识别" and (array_contains(split($"error_type", "|"), "4") or array_contains(split($"error_type", "|"), "5") or $"rt_dist".cast("double") === 0.0), "轨迹异常")
        .otherwise("")
      )
      .withColumn("task_label2", concat($"task_label_keguan", $"task_label_zhuguan", $"task_label_other"))
      .drop("keguan1", "keguan2", "keguan4", "keguan5", "keguan6", "flag1", "flag2","flag2a","flag2b", "flag4", "flag5", "flag6")
      //20221125新增字段
      .withColumn("service_tl_cn",$"service_tl_cn_test")
      .withColumn("jiayouzhan_tl_cn",$"jiayouzhan_tl_cn_test")
      .withColumn("gaosu_tl_sub_cn",$"gaosu_tl_sub_cn_test")
      .withColumn("service_ds_sub_cn",$"service_ds_sub_cn_test")
      .withColumn("service_ds_ob_cn",$"service_ds_ob_cn_test")
      .withColumn("service_sj_rest_times",$"service_sj_rest_times_test")
      .drop("service_tl_cn_test","jiayouzhan_tl_cn_test","gaosu_tl_sub_cn_test","service_ds_sub_cn_test","service_ds_ob_cn_test","service_sj_rest_times_test")
      //20230210修改
      .withColumn("total_keguan_koufa",$"epidemic_ob_final"+$"peak_congestion_final"+$"other_event_final")
      .withColumn("zhuguan_max",zhukeguan_max_udf($"zhuguan_fuwuqu",$"tollstation_sub_final",$"epidemic_sub_final",$"start_sub_final",$"no_label_sub_final",$"gaosu_sub_total_stay_points_duration"/60))
      .withColumn("keguan_max",zhukeguan_max_udf($"epidemic_ob_final",$"start_ob_final",$"other_event_final",$"tollstation_ob_final",$"no_label_ob_final",$"end_ob_final"))
      //20230210修改
      .withColumn("total_ob_tl",$"toll_station_ob_total_stay_points_duration"+$"epidemic_ob_total_stay_points_duration"+$"other_event_total_stay_points_duration"
                +$"no_ob_total_stay_points_duration"+$"gaosu_ob_total_stay_points_duration"+$"Peak_congestion_total_stay_points_duration")
      .withColumn("total_sub_tl",$"service_total_stay_points_duration"+$"toll_station_sub_total_stay_points_duration"+$"jyz_total_stay_points_duration"+
        $"epidemic_sub_total_stay_points_duration"+$"start_total_stay_points_duration"+$"gaosu_sub_total_stay_points_duration"+$"no_sub_total_stay_points_duration")
      //20230210修改
      .withColumn("total_ob_disu",$"tollstation_ob_lowspeed_duration"+$"tollstation_ob_sub_lowspeed_duration"+$"epidemic_ob_lowspeed_duration"+
        $"epidemic_ob_sub_lowspeed_duration"+$"other_ob_lowspeed_duration"+$"other_sub_lowspeed_duration"
        +$"other_ob_sub_lowspeed_duration"+$"no_ob_lowspeed_duration"+$"no_ob_sub_lowspeed_duration"
        +$"peak_congestion_lowspeed_duration")
      .withColumn("total_sub_disu",$"service_sub_lowspeed_duration"+$"service_ob_lowspeed_duration"+$"service_ob_sub_lowspeed_duration"
        +$"tollstation_sub_lowspeed_duration"+$"epidemic_sub_lowspeed_duration"+$"start_sub_lowspeed_duration"+$"no_sub_lowspeed_duration")
      .withColumn("end_tl_start_tm",get_timerow_udf($"end_label_sort_num",$"tl_time_periods")(0))
      .withColumn("end_tl_end_tm",get_timerow_udf($"end_label_sort_num",$"tl_time_periods")(1))
      .withColumn("end_ds_start_tm",get_timerow_zd_udf($"disu_label_sub_oj",$"disu_periods_final")(0))
      .withColumn("end_ds_end_tm",get_timerow_zd_udf($"disu_label_sub_oj",$"disu_periods_final")(1))
      .withColumn("task_label_keguan_max",task_label_keguan_max_udf($"task_label1",
        $"epidemic_ob_final",$"other_event_final",$"tollstation_ob_final",$"no_label_ob_final",$"peak_congestion_final"))
      .withColumn("task_label_zhuguan_max",task_label_zhuguan_max_udf($"task_label1", $"zhuguan_fuwuqu",$"tollstation_sub_final",
        $"epidemic_sub_final",$"gaosu_sub_total_stay_points_duration"/60,$"start_sub_final",$"no_label_sub_final",$"total_zhuguan_ratio"
      ))
      //20230210新增
      .withColumn("total_code_name_tmp",total_code_udf($"other_event_code",$"total_stay_points_eventcode"))
      .withColumn("other_event_total_code",$"total_code_name_tmp.str_code")
      .withColumn("other_event_total_code_title",$"total_code_name_tmp.str_name")
      .drop("total_code_name_tmp")
      .withColumn("task_label_test",when($"ac_is_run_ontime"==="0.0" && ($"total_zhuguan_ratio1" <= -0.5
      || ($"trackreliable"==="true" && $"highwaymileagepercentagevalid"==="false" && $"std_highway">2000 && $"std_dist">10000 && $"std_highway"/$"std_dist">0.05 && $"conduct_type"==="3"))
      ,"主观").when($"ac_is_run_ontime"==="0.0" && $"dept_pro_ratio" <= -0.5,"疑似场地问题")
      .when($"ac_is_run_ontime"==="0.0" && $"is_rec"==="1" && $"is_rec_satisfied"==="1" && ($"rec_time"-$"line_time")/$"difftime_plan_actual" <= -0.5,"规划时长不足")
        .when($"ac_is_run_ontime"==="0.0" && $"total_keguan_ratio1" <= -0.5,"客观")
        .when($"ac_is_run_ontime"==="0.0","系统未识别").otherwise("")
      )
      .withColumn("inc_day", lit(inc_day))
      .coalesce(10)
      .select(table_cols: _*)

    //数据存dm表
   writeToHive(spark, r2, Seq("inc_day"), "dm_gis.eta_task_time_information")
   //writeToHive(spark, r2, Seq("inc_day"), "dm_gis.eta_task_time_information")
  }

   //计算粤牌车休息次数
   val rest_ct_udf=udf(rest_ct _)

  //20230210新增函数
  def total_code(x:String,y:String):total_code_name={
    val str_arr = new ArrayBuffer[String]()
    val str_arr_name = new ArrayBuffer[String]()
    if(x != null  && !x.isEmpty &&x.trim != ""){
      val x_arr=x.split("[|]")
      val l=x_arr.length
      for(i<-0 until l){if (x_arr(i) != "-" && x_arr(i) !="null" && !x_arr(i).isEmpty && x_arr(i) !=null && x_arr(i).trim != "") {str_arr.append(x_arr(i))}}
    }
    if(y != null  && !y.isEmpty &&y.trim != ""){
      val y_arr=y.split("[|]")
      val k=y_arr.length
      for(j<-0 until k){if (y_arr(j) != "-" && y_arr(j) !="null" && !y_arr(j).isEmpty && y_arr(j) !=null && y_arr(j).trim != "") {str_arr.append(y_arr(j))}}
    }
  val str_arr2=str_arr.distinct
  val str_code= str_arr2.mkString("|")
  val s=str_arr2.size
  for(i<-0 until s) {
    str_arr_name.append(event_code(str_arr2(i)))
  }
  val str_name= str_arr_name.mkString("|")
    total_code_name(str_code,str_name)
  }

  case class total_code_name(
                              str_code:String,
                              str_name:String
                            )



  val total_code_udf=udf(total_code _)

  // 20221125新增udf函数
  def service_tl_cn_str(x:String): Int ={
    if(x != null  && !x.isEmpty &&x.trim != ""){x.split("[|]",0).count({i:String=>i=="服务区停留"})} else{0}}
  val service_tl_cn_udf=udf(service_tl_cn_str _)
  def jiayouzhan_tl_cn_str(x:String): Int ={
    if(x != null  && !x.isEmpty &&x.trim != ""){x.split("[|]",0).count({i:String=>i=="加油站停留"})} else{0}}
  val jiayouzhan_tl_cn_udf=udf(jiayouzhan_tl_cn_str _)
  def gaosu_tl_sub_cn_str(x:String): Int ={
    if(x != null  && !x.isEmpty &&x.trim != ""){x.split("[|]",0).count({i:String=>i=="高速主观停留"})}else{0}}
  val gaosu_tl_sub_cn_udf=udf(gaosu_tl_sub_cn_str _)
  def service_ds_sub_cn_str(x:String): Int ={
    if(x != null  && !x.isEmpty &&x.trim != ""){x.split("[|]",0).count({i:String=>i=="服务区主观"})}else{0}}
  val service_ds_sub_cn_udf=udf(service_ds_sub_cn_str _)
  def service_ds_ob_cn_str(x:String): Int ={
    if(x != null  && !x.isEmpty &&x.trim != ""){x.split("[|]",0).count({i:String=>i=="服务区客观" ||i=="服务区无法识别" })}else{0}}
  val service_ds_ob_cn_udf=udf(service_ds_ob_cn_str _)
  def zhukeguan_max_fun(x1:Double,x2:Double,x3:Double,x4:Double,x5:Double,x6:Double): Double ={Set(x1,x2,x3,x4,x5,x6).max}
  val zhukeguan_max_udf=udf(zhukeguan_max_fun _)

  //***********20221125新增，将对应的下标值取出来，用下划线分割，组成list
  def get_timerow(x:String,y:String):List[String]={
    var time_min=""
    var time_max=""
    if(x != null && y != null && !x.isEmpty&& !y.isEmpty &&x.trim != "" &&y.trim != "") {

      val x_str = x.split("[|]")
      val y_str = y.replace("[", "").replace("]", "").split(",")
      val x_len = x_str.size
      val y_len = y_str.size
      //定义一个list存储各个时间点
      val y_list: ListBuffer[String] = new ListBuffer[String]
      if (x_len <= y_len && y_len > 0 && x_len > 0) {
        for (i <- 0 until x_len) {
          val j = x_str(i).toInt
          y_list.append(y_str(j).split("_")(0))
          y_list.append(y_str(j).split("_")(1))
        }
      }
      if(y_list != null  && !y_list.isEmpty )
      {  time_min=y_list.min
        time_max=y_list.max
      }
    }
    List(time_min,time_max)
  }
  //注册udf函数
  val get_timerow_udf=udf(get_timerow _)

  //***********20221125新增，将‘终点主观’对应的下标值取出来，用下划线分割，组成list
  def get_timerow_zd(x:String,y:String):List[String]={
    var time_min=""
    var time_max=""
    if(x != null && y != null && !x.isEmpty&& !y.isEmpty &&x.trim != "" &&y.trim != ""){
      val x_str=x.split("[|]")
      val y_str=y.replace("[","").replace("]","").split("[|]")
      val x_len=x_str.size
      val y_len=y_str.size
      //定义一个list存储各个时间点
      val y_list: ListBuffer[String] = new ListBuffer[String]
      if(x_len<=y_len&&y_len>0&&x_len>0){
        for(i<-0 until x_len){
          if(x_str(i)=="终点主观"){
            y_list.append(y_str(i).split("_")(0))
            y_list.append(y_str(i).split("_")(1))
          }
        }
      }
      if(y_list != null  && !y_list.isEmpty )
        {  time_min=y_list.min
          time_max=y_list.max
        }
    }
    List(time_min,time_max)
  }
  //注册udf函数
  val get_timerow_zd_udf=udf(get_timerow_zd _)

 //定义函数计算task_label_keguan_max
  def task_label_keguan_max_fun(y:String,x1:Double,x2:Double,x3:Double,x4:Double,x5:Double):String={
    if(y=="客观"){
      val x=Set(x1,x2,x3,x4,x5)
      if(x1==x.max){return "疫情检查"}
      else if(x2==x.max){return "其他事件"}
      else if(x3==x.max){return "收费站客观停留/低速"}
      else if(x4==x.max){return "路况拥堵"}
      else if(x5==x.max){return "高峰拥堵"}
      else ""
    }
    else ""
  }
  //注册udf函数
  val task_label_keguan_max_udf=udf(task_label_keguan_max_fun _)

  //定义函数计算task_label_zhuguan_max
  def task_label_zhuguan_max_fun(y:String,x1:Double,x2:Double,x3:Double,x4:Double,x5:Double,x6:Double,x7:Double):String={
    if(y=="主观"){
      val x=Set(x1,x2,x3,x4,x5,x6)

      if(x7> -0.5){return "未全程高速"}
      else if(x7<= -0.5 && x.max !=0&&x1==x.max){return "服务区主观停留/低速"}
      else if(x7<= -0.5 && x.max !=0&&x2==x.max){return "收费站主观停留/低速"}
      else if(x7<= -0.5 && x.max !=0&&x3==x.max){return "疫情检查站主观停留/低速"}
      else if(x7<= -0.5 && x.max !=0&&x4==x.max){return "高速主观停留"}
      else if(x7<= -0.5 && x.max !=0&&x5==x.max){return "起点主观停留/低速"}
      else if(x7<= -0.5 && x.max !=0&&x6==x.max){return "其他主观停留/低速"}
      else ""
    }
    else ""
  }
  //注册udf函数
  val task_label_zhuguan_max_udf=udf(task_label_zhuguan_max_fun _)


  // 历史30天的数据
  def getHisLineData2(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._

    val rec_start_inc_day: String = getdaysBeforeOrAfter(inc_day, -30)
    val rec_end_inc_day: String = inc_day
    val rec_delete_inc_day: String = ""
    val vef_start_inc_day: String = rec_start_inc_day
    val vef_end_inc_day: String = inc_day
    val vef_delete_inc_day: String = ""

    val inc_day2: String = getdaysBeforeOrAfter(inc_day, -30)
    val task_inc_day: String = inc_day

    val taskSql: String =
      s"""
         |select
         |  *
         |from
         |(
         |  select
         |    concat_ws('_',line_code,start_dept,end_dept,start_type,end_type,start_outer_add_code,end_outer_add_code) as `group`,
         |    line_code,
         |    start_dept,
         |    end_dept,
         |    task_subid,
         |    start_type,
         |    end_type,
         |    start_outer_add_code,
         |    end_outer_add_code,
         |    actual_run_tm3,
         |    actual_run_time,
         |    ac_is_run_ontime,
         |    last_update_tm,
         |    line_time,
         |    task_final_label,
         |    vehicle_type as vehicle_typea,
         |    row_number() over(partition by task_subid order by inc_day desc) as rn
         |  from
         |    dm_gis.eta_task_time_information
         |  where
         |    inc_day > '$rec_start_inc_day'
         |    and inc_day <= '$rec_end_inc_day'
         |    and task_inc_day > '$rec_start_inc_day'
         |    and task_inc_day <= '$rec_end_inc_day'
         |    and task_inc_day not in ('$rec_delete_inc_day')
         |    and actual_run_tm3 > 0.0
         |    and if_evaluate_time = '1'
         |) a
         |where
         |  rn = 1
         |""".stripMargin
    logger.error("历史30天的任务数据：" + taskSql)

    val taskDF: DataFrame = spark.sql(taskSql).persist(StorageLevel.MEMORY_AND_DISK)

    val w1: WindowSpec = Window.partitionBy("group").orderBy($"last_update_tm".desc)
    val tmDF: DataFrame = taskDF
      .withColumn("rn", row_number() over w1)
      .filter("rn = 1")
      .withColumn("future_plan_run_tm", 'line_time.cast("double"))
      .select("group", "future_plan_run_tm")
      .dropDuplicates()
      .persist(StorageLevel.MEMORY_AND_DISK)

    val allDF: DataFrame = tmDF
      .join(taskDF, Seq("group"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val allDF2: DataFrame = allDF
      .groupBy("group")
      .agg(
        expr("percentile(actual_run_tm3, array(0.5))[0]").alias("zws")
      )

    val allDF3: DataFrame = allDF
      .join(allDF2, Seq("group"))
      .withColumn("difftime_plan_actual2", round($"future_plan_run_tm" - $"actual_run_time".cast("double"), 2))
      .withColumn("ac_is_run_ontime2", when($"difftime_plan_actual2" + 1 >= 0, 1).otherwise(0))
      .withColumn("difftime_plan_actual3", round($"future_plan_run_tm" - $"actual_run_tm3", 2))
      .withColumn("ac_is_run_ontime3", when($"difftime_plan_actual3" + 1 >= 0, 1).otherwise(0))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val allDF31: DataFrame = allDF3
      .groupBy("group")
      .agg(
        size(collect_set("task_subid")).as("task_count_before"),
        size(collect_set(when($"ac_is_run_ontime" === 1, $"task_subid"))).as("task_ontime_count1"),
        size(collect_set(when($"ac_is_run_ontime" === 0, $"task_subid"))).as("task_late_count1"),
        size(collect_set(when($"ac_is_run_ontime2" === 1, $"task_subid"))).as("task_ontime_count2"),
        size(collect_set(when($"ac_is_run_ontime2" === 0, $"task_subid"))).as("task_late_count2"),
        size(collect_set(when($"ac_is_run_ontime3" === 1, $"task_subid"))).as("task_ontime_count3_before"),
        size(collect_set(when($"ac_is_run_ontime3" === 0, $"task_subid"))).as("task_late_count3_before")

      )
      .withColumn("task_ontime_ratio1", round($"task_ontime_count1".cast("double") / $"task_count_before", 2))
      .withColumn("task_ontime_ratio2", round($"task_ontime_count2".cast("double") / $"task_count_before", 2))
      .withColumn("task_ontime_ratio3_before", round($"task_ontime_count3_before".cast("double") / $"task_count_before", 2))

    //20221021修改，新增allDF32，后面匹配增加字段
    val allDF32: DataFrame = allDF3
      .groupBy("group")
      .agg(
        collect_set("vehicle_typea")(0) as ("vehicle_type")
      )

    val allDF4: DataFrame = allDF3
      .filter("zws*1.8 > actual_run_tm3 and zws * 0.2 < actual_run_tm3 and task_final_label not in ('劝返','轨迹异常','线路绕行','与高德校验异常')")
      .groupBy("group")
      .agg(
        concat_ws("|", collect_list("task_subid")).as("task_subids"),
        concat_ws("|", collect_list("actual_run_tm3")).as("total_actual_run_tm3"),
        size(collect_set("task_subid")).as("task_count"),
        size(collect_set(when($"ac_is_run_ontime3" === 1, $"task_subid"))).as("task_ontime_count3"),
        size(collect_set(when($"ac_is_run_ontime3" === 0, $"task_subid"))).as("task_late_count3"),
        round(skewness("actual_run_tm3"), 2).as("skewness"),
        round(max("actual_run_tm3") - min("actual_run_tm3"), 2).as("minmax"),
        round(stddev_pop("actual_run_tm3"), 2).as("std"),
        round(mean("actual_run_tm3"), 2).as("mean"),
        round(expr("percentile(actual_run_tm3, array(0.5))[0]"), 2).as("percentile50"),
        round(expr("percentile(actual_run_tm3, array(0.6))[0]"), 2).as("percentile60"),
        round(expr("percentile(actual_run_tm3, array(0.7))[0]"), 2).as("percentile70"),
        round(expr("percentile(actual_run_tm3, array(0.8))[0]"), 2).as("percentile80"),
        round(expr("percentile(actual_run_tm3, array(0.9))[0]"), 2).as("percentile90"),
        round(expr("percentile(actual_run_tm3, array(0.94))[0]"), 2).as("percentile94")
      )
      .withColumn("task_ontime_ratio3", round($"task_ontime_count3".cast("double") / $"task_count", 2))
      .withColumn("rec_time", when($"skewness" > -0.2 or $"minmax" <= 30, $"percentile90".cast("int")).otherwise($"percentile80".cast("int")))
      .withColumn("rec_time_final", concat(floor($"rec_time" / 60), lit("小时"), $"rec_time" % 60, lit("分")))
      .join(allDF31, Seq("group"))
      .join(tmDF, Seq("group"))
      .withColumn("time_change", $"rec_time" - $"future_plan_run_tm".cast("int"))
      .withColumn("rec_label", when('time_change > 0 and 'task_count > 3 and 'task_ontime_ratio2 <= 0.7 and 'task_ontime_ratio3 <= 0.8, 1).otherwise(0))
      //20221021修改，增加allDF32
      .join(allDF32,Seq("group"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    allDF4
  }

  // 验证推荐时长
  def verifyRecommend2(spark: SparkSession, hisDF: DataFrame, inc_day: String): Unit = {
    import spark.implicits._
    val task_inc_day: String = getdaysBeforeOrAfter(inc_day, -15)
    val taskSql: String =
      s"""
         |select
         |  *
         |from
         |(
         |  select
         |    concat_ws('_',line_code,start_dept,end_dept,start_type,end_type,start_outer_add_code,end_outer_add_code) as group,
         |    task_subid,
         |    actual_run_tm3,
         |    actual_run_time,
         |    row_number() over(partition by task_subid order by task_inc_day desc) as rn
         |  from
         |    dm_gis.eta_task_time_information
         |  where
         |    inc_day > '$task_inc_day'
         |    and inc_day <= '$inc_day'
         |    and task_inc_day > '$task_inc_day'
         |    and task_inc_day <= '$inc_day'
         |) a
         |where
         |  rn = 1
         |""".stripMargin
    logger.error(s"历史15天的数据:$taskSql")
    val taskDF: DataFrame = spark.sql(taskSql).drop("rn")

    //val res_cols = spark.sql("""select * from dm_gis.eta_time_recommendation1 limit 0""").schema.map(_.name).map(col)
    val res_cols = spark.sql("""select * from dm_gis.eta_time_recommendation1 limit 0""").schema.map(_.name).map(col)

    //20221021修改，这里的group是已经去重的
    val hisDF_vehicle_type=hisDF.select("group","vehicle_type")

    val resultDF: DataFrame = hisDF
      .join(taskDF, Seq("group"), "left")
      .withColumn("difftime_plan_actual_before", $"future_plan_run_tm" - $"actual_run_time".cast("int"))
      .withColumn("difftime_plan_actual_before2", $"future_plan_run_tm" - $"actual_run_tm3".cast("int"))
      .withColumn("difftime_plan_actual_after", $"rec_time" - $"actual_run_time".cast("int"))
      .withColumn("difftime_plan_actual_after2", $"rec_time" - $"actual_run_tm3".cast("int"))
      .withColumn("difftime_plan_actual_ratio_after", round($"difftime_plan_actual_after".cast("double") / $"rec_time", 2))
      .withColumn("difftime_plan_actual_ratio_after2", round($"difftime_plan_actual_after2".cast("double") / $"rec_time", 2))
      .withColumn("ac_is_run_ontime_before", when($"difftime_plan_actual_before" + 1 >= 0, 1).otherwise(0))
      .withColumn("ac_is_run_ontime_before2", when($"difftime_plan_actual_before2" + 1 >= 0, 1).otherwise(0))
      .withColumn("ac_is_run_ontime_after", when($"difftime_plan_actual_after" + 1 >= 0, 1).otherwise(0))
      .withColumn("ac_is_run_ontime_after2", when($"difftime_plan_actual_after2" + 1 >= 0, 1).otherwise(0))
      .groupBy("group")
      .agg(
        concat_ws("|", collect_list("task_subid")).as("new_task_subids"),
        concat_ws("|", collect_list("actual_run_tm3")).as("new_total_actual_run_tm3"),
        size(collect_set("task_subid")).as("new_task_count"),
        size(collect_set(when($"ac_is_run_ontime_before" === 1, $"task_subid"))).as("new_task_ontime_count_before"),
        size(collect_set(when($"ac_is_run_ontime_before2" === 1, $"task_subid"))).as("new_task_ontime_count_before2"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1, $"task_subid"))).as("new_task_ontime_count_after"),
        size(collect_set(when($"ac_is_run_ontime_after2" === 1, $"task_subid"))).as("new_task_ontime_count_after2"),
        size(collect_set(when($"ac_is_run_ontime_before" === 0, $"task_subid"))).as("new_task_late_count_before"),
        size(collect_set(when($"ac_is_run_ontime_before2" === 0, $"task_subid"))).as("new_task_late_count_before2"),
        size(collect_set(when($"ac_is_run_ontime_after" === 0, $"task_subid"))).as("new_task_late_count_after"),
        size(collect_set(when($"ac_is_run_ontime_after2" === 0, $"task_subid"))).as("new_task_late_count_after2"),
        sort_array(collect_set(when($"ac_is_run_ontime_after" === 1, abs($"difftime_plan_actual_after")).otherwise(0)))(0).as("new_min"),
        sort_array(collect_set(when($"ac_is_run_ontime_after" === 1, abs($"difftime_plan_actual_after")).otherwise(0)), asc = false)(0).as("new_max"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_after") <= 30, $"task_subid"))).as("new_30minl_count"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_after") > 30, $"task_subid"))).as("new_30minh_count"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_after") <= 60, $"task_subid"))).as("new_60minl_count"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_after") > 60, $"task_subid"))).as("new_60minh_count"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_ratio_after") <= 0.05, $"task_subid"))).as("new_5per_l_count"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_ratio_after") > 0.05, $"task_subid"))).as("new_5per_h_count"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_ratio_after") <= 0.1, $"task_subid"))).as("new_10per_l_count"),
        size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_ratio_after") > 0.1, $"task_subid"))).as("new_10per_h_count")
      )
      .withColumn("new_task_ontime_ratio_before", round($"new_task_ontime_count_before".cast("double") / $"new_task_count", 2))
      .withColumn("new_task_ontime_ratio_before2", round($"new_task_ontime_count_before2".cast("double") / $"new_task_count", 2))
      .withColumn("new_task_ontime_ratio_after", round($"new_task_ontime_count_after".cast("double") / $"new_task_count", 2))
      .withColumn("new_task_ontime_ratio_after2", round($"new_task_ontime_count_after2".cast("double") / $"new_task_count", 2))
      .withColumn("new_30min_ratio", round($"new_30minl_count".cast("double") / $"new_task_ontime_count_after", 2))
      .withColumn("new_60min_ratio", round($"new_60minl_count".cast("double") / $"new_task_ontime_count_after", 2))
      .withColumn("new_5per_ratio", round($"new_5per_l_count".cast("double") / $"new_task_ontime_count_after", 2))
      .withColumn("new_10per_ratio", round($"new_10per_l_count".cast("double") / $"new_task_ontime_count_after", 2))
      .withColumn("ontime_increase", $"new_task_ontime_count_after" - $"new_task_ontime_count_before")
      .withColumn("ontime_increase2", $"new_task_ontime_count_after2" - $"new_task_ontime_count_before2")
      .withColumn("is_increase", when($"ontime_increase" > 0, 1).otherwise(0))
      .join(hisDF, Seq("group"))
      //20221021修改
      .drop("vehicle_type")
      .withColumn("rec_satisfied_label",
        when($"rec_time" <= 240 and $"new_30min_ratio" >= 0.9, 1)
          .when($"rec_time" > 240 and $"rec_time" <= 480 and $"new_60min_ratio" >= 0.8, 1)
          .when($"rec_time" > 480 and $"new_10per_ratio" >= 0.7, 1)
          .otherwise(0)
      )
      //20221021修改
      .join(hisDF_vehicle_type, Seq("group"))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
    //    resultDF.printSchema()


    //writeToHive(spark, resultDF, Seq("inc_day"), "dm_gis.eta_time_recommendation1")
    writeToHive(spark, resultDF, Seq("inc_day"), "dm_gis.eta_time_recommendation1")

    resultDF.unpersist()
  }

  /**
   * 将数据写入hive表中【OVERWRITE】
   *
   * @param spark
   * @param dataframe
   * @param partitionCol
   * @param resTableName
   */
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }


  //关系映射
  def event_code(x:String): String ={
    val x_name=x match{
      case "0,0,18,1" => "流量"
      case "0,0,18,2" => "流量"
      case "0,0,18,3" => "流量"
      case "0,0,18,4" => "流量"
      case "0,0,18,5" => "流量"
      case "0,0,18,6" => "流量"
      case "0,0,100,101" => "交通事故"
      case "0,0,100,102" => "交通事故"
      case "0,0,100,103" => "交通事故"
      case "0,0,100,104" => "交通事故"
      case "0,0,200,201" => "道路施工"
      case "0,0,200,202" => "道路施工"
      case "0,0,200,203" => "道路施工"
      case "1,1,200,399" => "道路施工"
      case "0,0,300,301" => "交通管制"
      case "1,1,300,302" => "交通管制"
      case "5,1,300,303" => "交通管制"
      case "4,1,300,304" => "交通管制"
      case "1,0,300,305" => "交通管制"
      case "1,0,300,306" => "交通管制"
      case "1,0,300,307" => "交通管制"
      case "1,0,300,308" => "交通管制"
      case "1,2,300,309" => "交通管制"
      case "1,2,300,310" => "交通管制"
      case "1,2,300,311" => "交通管制"
      case "1,2,300,312" => "交通管制"
      case "1,2,300,313" => "交通管制"
      case "1,3,300,314" => "交通管制"
      case "1,3,300,315" => "交通管制"
      case "1,3,300,316" => "交通管制"
      case "1,1,300,399" => "交通管制"
      case "0,0,400,401" => "天气"
      case "0,0,400,402" => "天气"
      case "0,0,400,403" => "天气"
      case "0,0,400,404" => "天气"
      case "0,0,400,405" => "天气"
      case "0,0,400,406" => "天气"
      case "0,0,400,407" => "天气"
      case "0,0,400,408" => "天气"
      case "0,0,400,409" => "天气"
      case "0,0,400,410" => "天气"
      case "0,0,400,411" => "天气"
      case "0,0,400,412" => "天气"
      case "0,0,400,413" => "天气"
      case "0,0,400,414" => "天气"
      case "0,0,400,415" => "天气"
      case "0,0,400,416" => "天气"
      case "0,0,400,417" => "天气"
      case "0,0,400,418" => "天气"
      case "0,0,400,419" => "天气"
      case "0,0,400,420" => "天气"
      case "0,0,400,421" => "天气"
      case "0,0,400,422" => "天气"
      case "0,0,400,423" => "天气"
      case "0,0,400,424" => "天气"
      case "0,0,400,425" => "天气"
      case "0,0,400,426" => "天气"
      case "0,0,400,427" => "天气"
      case "0,0,400,428" => "天气"
      case "0,0,400,429" => "天气"
      case "0,0,400,430" => "天气"
      case "0,0,400,431" => "天气"
      case "0,0,400,432" => "天气"
      case "0,0,400,433" => "天气"
      case "0,0,400,434" => "天气"
      case "0,0,400,435" => "天气"
      case "0,0,400,436" => "天气"
      case "0,0,400,437" => "天气"
      case "0,0,400,438" => "天气"
      case "0,0,400,439" => "天气"
      case "0,0,400,440" => "天气"
      case "0,0,500,501" => "路面"
      case "0,0,500,502" => "路面"
      case "0,0,500,503" => "路面"
      case "0,0,500,504" => "路面"
      case "0,0,500,505" => "路面"
      case "0,0,500,506" => "路面"
      case "0,0,500,507" => "路面"
      case "0,0,500,508" => "路面"
      case "0,0,500,509" => "路面"
      case "0,0,500,510" => "路面"
      case "0,0,500,511" => "路面"
      case "0,0,500,512" => "路面"
      case "0,0,500,531" => "路面"
      case "0,0,500,532" => "路面"
      case "0,0,500,534" => "路面"
      case "0,0,500,535" => "路面"
      case "0,0,600,601" => "活动"
      case "0,0,600,602" => "活动"
      case "0,0,600,603" => "活动"
      case "0,0,600,604" => "活动"
      case "0,0,600,605" => "活动"
      case "0,0,600,606" => "活动"
      case "0,0,600,607" => "活动"
      case "0,0,700,701" => "灾害"
      case "0,0,700,702" => "灾害"
      case "0,0,700,703" => "灾害"
      case "0,0,700,704" => "灾害"
      case "0,0,700,705" => "灾害"
      case "0,0,800,901" => "公告"
      case "0,0,900,902" => "其他"
      case "0,0,900,903" => "其他"
      case "0,0,900,904" => "其他"
      case "0,0,900,905" => "其他"
      case "0,0,900,906" => "其他"
      case "0,0,900,907" => "其他"
      case "0,0,900,908" => "其他"
      case "0,0,900,909" => "其他"
      case "0,0,900,910" => "其他"
      case "0,0,900,911" => "其他"
      case "1,1,100,101" => "交通事故"
      case "1,1,100,102" => "交通事故"
      case "1,1,200,201" => "道路施工"
      case "1,1,400,404" => "天气"
      case "1,1,400,406" => "天气"
      case "1,1,400,409" => "天气"
      case "1,1,400,410" => "天气"
      case "1,1,500,501" => "路面"
      case "1,1,500,502" => "路面"
      case "1,1,500,503" => "路面"
      case "1,1,500,504" => "路面"
      case "1,1,500,505" => "路面"
      case "1,1,500,506" => "路面"
      case "1,1,600,601" => "活动"
      case "1,1,600,602" => "活动"
      case "1,1,600,603" => "活动"
      case "1,1,600,604" => "活动"
      case "1,1,600,605" => "活动"
      case "1,1,600,606" => "活动"
      case "1,1,600,607" => "活动"
      case "1,1,700,701" => "灾害"
      case "1,1,700,702" => "灾害"
      case "1,1,700,703" => "灾害"
      case "1,1,700,704" => "灾害"
      case "1,1,700,705" => "灾害"
      case "1,1,6,16" => "疫情"
      case "0,0,6,16" => "疫情"
      case "1,1,19,201" => "未来事件"
      case "1,1,19,302" => "未来事件"
      case "1,1,0,255" => "无原因现象"
      case x => x
    }
    x_name
  }


  def rest_ct(sttm:String,edtm:String): Int ={
    val st_hour=sttm.substring(11,13)
    val s=List("18","19","20","21","22","23","24","00","01","02","03","04","05")
    //替换整点、防止报错，不影响判断
    var sttm_a=sttm.replace(":00:00",":00:01")
    var m=0
    //起始时间是晚上
    if(s.contains(st_hour)){
      var iflag=1
      while (iflag==1){
        val ws1=wanshang(sttm_a:String,edtm:String)
        sttm_a=ws1.st
        m=m+ws1.n
        //println("当前sttm1a："+sttm+","+"当前sttm_a："+sttm_a+","+"当前iflag："+iflag+","+"当前m:"+m)
        if(sttm_a == "1900-01-01 11:11:11"){iflag=0
          // println("当前sttm1："+sttm+","+"当前sttm_a："+sttm_a+","+"当前iflag："+iflag+","+"当前m:"+m)
        }
        else{
          val ws2=baitian(sttm_a:String,edtm:String)
          sttm_a=ws2.st
          m=m+ws2.n
          //println("当前sttm1b："+sttm+","+"当前sttm_a："+sttm_a+","+"当前iflag："+iflag+","+"当前m:"+m)
          if(sttm_a == "1900-01-01 11:11:11"){iflag=0
            //println("当前sttm2："+sttm+","+"当前sttm_a："+sttm_a+","+"当前iflag："+iflag+","+"当前m:"+m)
          }
          else{iflag=1
            // println("当前sttm3："+sttm+","+"当前sttm_a："+sttm_a+","+"当前iflag："+iflag+","+"当前m:"+m)
          }
        }
        Thread.sleep(1000)
      }
    }
    //起始时间是白天
    else {
      var iflag2=1
      while (iflag2==1){
        val ws3=baitian(sttm_a:String,edtm:String)
        sttm_a=ws3.st
        m=m+ws3.n
        //println("2a当前sttm："+sttm+","+"2当前sttm_a："+sttm_a+","+"2当前iflag2："+iflag2+","+"2当前m:"+m)
        if(sttm_a == "1900-01-01 11:11:11"){iflag2=0
          // println("2b当前sttm："+sttm+","+"2当前sttm_a："+sttm_a+","+"2当前iflag2："+iflag2+","+"2当前m:"+m)
        }
        else{
          //  println("2b1当前sttm："+sttm+","+"2当前sttm_a："+sttm_a+","+"2当前iflag2："+iflag2+","+"2当前m:"+m)
          val ws4=wanshang(sttm_a:String,edtm:String)
          sttm_a=ws4.st
          m=m+ws4.n
          //  println("2b2当前sttm："+sttm+","+"2当前sttm_a："+sttm_a+","+"2当前iflag2："+iflag2+","+"2当前m:"+m)
          if(sttm_a == "1900-01-01 11:11:11"){iflag2=0
            //  println("2c当前sttm："+sttm+","+"2当前sttm_a："+sttm_a+","+"2当前iflag2："+iflag2+","+"2当前m:"+m)
          }
          else{iflag2=1
            //   println("2d当前sttm："+sttm+","+"2当前sttm_a："+sttm_a+","+"2当前iflag2："+iflag2+","+"2当前m:"+m)
          }
        }
        Thread.sleep(1000)
      }
    }
    m
  }



  //白天休息次数判断
  def baitian(sttm:String,edtm:String): day_factor ={
    var st=sttm.replace(":00:00",":00:01")
    var md=sttm.replace(":00:00",":00:01")
    var n=0
    //如果结束时间没到晚上
    if(edtm<=md.substring(0,11).concat("22:00:00")){
      val minidif=getminisdif(edtm,sttm)
      n=scala.math.round(minidif/240)
      st="1900-01-01 11:11:11"
    }
    //如果结束时间超过当晚22点,起始时间是18-22点之间
    if(edtm>md.substring(0,11).concat("22:00:00") && gethourBeforeOrAfter(st,4)>=md.substring(0,11).concat("22:00:00")){
      n=n+0
      val minidif=getminisdif(md.substring(0,11).concat("22:00:00"),md)
      if(minidif>120){st=md} else {st=md.substring(0,11).concat("22:00:00")}
    }
    //如果结束时间超过当晚22点,起始时间是14-18点之间
    if(edtm>md.substring(0,11).concat("22:00:00") && gethourBeforeOrAfter(st,8)>=md.substring(0,11).concat("22:00:00")
      && gethourBeforeOrAfter(st,4)<md.substring(0,11).concat("22:00:00")){
      n=n+1
      md=gethourBeforeOrAfter(st,4)
      val minidif=getminisdif(md.substring(0,11).concat("22:00:00"),md)
      if(minidif>120){st=md} else {st=md.substring(0,11).concat("22:00:00")}
    }
    //如果结束时间超过当晚22点,起始时间是10-14点之间
    if(edtm>md.substring(0,11).concat("22:00:00") && gethourBeforeOrAfter(st,12)>=md.substring(0,11).concat("22:00:00")
      && gethourBeforeOrAfter(st,8)<md.substring(0,11).concat("22:00:00")){
      n=n+2
      md=gethourBeforeOrAfter(st,8)
      val minidif=getminisdif(md.substring(0,11).concat("22:00:00"),md)
      if(minidif>120){st=md} else {st=md.substring(0,11).concat("22:00:00")}
    }
    //如果结束时间超过当晚22点,起始时间是06-10点之间
    if(edtm>md.substring(0,11).concat("22:00:00") && gethourBeforeOrAfter(st,16)>=md.substring(0,11).concat("22:00:00")
      && gethourBeforeOrAfter(st,12)<md.substring(0,11).concat("22:00:00")){
      n=n+3
      md=gethourBeforeOrAfter(st,12)
      val minidif=getminisdif(md.substring(0,11).concat("22:00:00"),md)
      if(minidif>120){st=md}
      else {st=md.substring(0,11).concat("22:00:00")}
    }
    //如果结束时间超过当晚22点,起始时间是04-06点之间
    if(edtm>md.substring(0,11).concat("22:00:00") && gethourBeforeOrAfter(st,20)>=md.substring(0,11).concat("22:00:00")
      && gethourBeforeOrAfter(st,16)<md.substring(0,11).concat("22:00:00")){
      n=n+4
      md=gethourBeforeOrAfter(st,16)
      val minidif=getminisdif(md.substring(0,11).concat("22:00:00"),md)
      if(minidif>120){st=md}
      else {st=md.substring(0,11).concat("22:00:00")}
    }
    return day_factor(st,n)
  }



  case class day_factor(
                         st:String,
                         n:Int
                       )



  //晚上休息次数判断
  def wanshang(sttm:String,edtm:String): day_factor ={
    var st=sttm.replace(":00:00",":00:01")
    var n=0
    val st_hour=st.substring(11,13)
    var st_day=st.substring(0,10)
    if(st_hour=="18" || st_hour=="19" || st_hour=="20" || st_hour=="21" || st_hour=="22" || st_hour=="23")
    { st_day= getdaysBeforeOrAftera(st_day,1)}
    //如果结束时间没到白天
    if(edtm<=st_day.concat(" 06:00:00")){
      val minidif=getminisdif(edtm,sttm)
      n=scala.math.round(minidif/120)
      st="1900-01-01 11:11:11"
    }
    //如果结束时间超过当晚06点,起始时间是04-06点之间
    if(edtm>st_day.concat(" 06:00:00") && gethourBeforeOrAfter(st,2)>=st_day.concat(" 06:00:00")){
      n=n+0
      st=st
    }
    //如果结束时间超过当晚06点,起始时间是02-04点之间
    if(edtm>st_day.concat(" 06:00:00") && gethourBeforeOrAfter(st,4)>=st_day.concat(" 06:00:00")
      && gethourBeforeOrAfter(st,2)<st_day.concat(" 06:00:00")){
      n=n+1
      st=gethourBeforeOrAfter(st,2)
    }
    //如果结束时间超过当晚06点,起始时间是00-02点之间
    if(edtm>st_day.concat(" 06:00:00") && gethourBeforeOrAfter(st,6)>=st_day.concat(" 06:00:00")
      && gethourBeforeOrAfter(st,4)<st_day.concat(" 06:00:00")){
      n=n+2
      st=gethourBeforeOrAfter(st,4)
    }
    //如果结束时间超过当晚06点,起始时间是22-00点之间
    if(edtm>st_day.concat(" 06:00:00") && gethourBeforeOrAfter(st,8)>=st_day.concat(" 06:00:00")
      && gethourBeforeOrAfter(st,6)<st_day.concat(" 06:00:00")){
      n=n+3
      st=gethourBeforeOrAfter(st,6)
    }
    //如果结束时间超过当晚06点,起始时间是20-22点之间
    if(edtm>st_day.concat(" 06:00:00") && gethourBeforeOrAfter(st,10)>=st_day.concat(" 06:00:00")
      && gethourBeforeOrAfter(st,8)<st_day.concat(" 06:00:00")){
      n=n+4
      st=gethourBeforeOrAfter(st,8)
    }
    //如果结束时间超过当晚06点,起始时间是18-20点之间
    if(edtm>st_day.concat(" 06:00:00") && gethourBeforeOrAfter(st,12)>=st_day.concat(" 06:00:00")
      && gethourBeforeOrAfter(st,10)<st_day.concat(" 06:00:00")){
      n=n+5
      st=gethourBeforeOrAfter(st,10)
    }
    return day_factor(st,n)
  }

  // 推n小时,负数是往前，正数是往后
  def gethourBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.HOUR, num)
    dateFormat.format(cal.getTime)
  }



  //往前推n天
  def getdaysBeforeOrAftera(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

  // 推n分钟,负数是往前，正数是往后t1和t2格式：2023-02-16 13:07:02
  def getminisdif(t1: String,t2: String): Long = {
    val l1 = LocalDateTime.parse(t1,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    val l2 = LocalDateTime.parse(t2,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    val l3 = l1.minusSeconds(l1.getSecond)
    val l4 = l2.minusSeconds(l2.getSecond)
    ChronoUnit.MINUTES.between(l4,l3)
  }
}
