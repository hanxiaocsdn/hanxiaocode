package app.safetyConvoy

import com.alibaba.fastjson._
import entry.{EtaTimeRes, EtaTsWmpInfo}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.SparkConfigUtil

import scala.collection.mutable.ArrayBuffer

/**
  * 任务名称：时效监控挽救定责详情
  * 任务ID：458926
  * 需求人员：王润泽 01422002
  * 开发人员：王冬冬 01413698
  */
object ParsEtaTsTimeResLog {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {


        if (args.length != 1) {
            logger.error(
                """
                  |需要输入1个参数：
                  |    inc_day
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val inc_day: String = args(0)
        logger.error(s"取数日期：$inc_day ")
        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 解析时效监控数据
        parseAgingMonData(spark, inc_day)
        // 解析定责结果数据
        parseJudgeRespData(spark, inc_day)

        logger.error("运行结束！")
        // 程序运行结束,关闭spark
        spark.stop()
    }

    // 解析时效监控数据
    def parseAgingMonData(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        val sql: String =
            s"""
               |select
               |  info
               |from
               |  dm_gis.eta_ts_wmp_info_to_hive
               |where
               |  inc_day='$inc_day'
               |""".stripMargin

        val origDF: DataFrame = spark
          .sql(sql)
          .map(r => {

              val info: String = r.getAs[String]("info")
              val o: JSONObject = JSON.parseObject(info)

              val task_id: String = o.getString("taskId")
              val line_require_id: String = o.getString("lineRequireId")
              val driver_id: String = o.getString("driverId")
              val vehicle_serial: String = o.getString("vehicleSerial")
              val src_zone_code: String = o.getString("srcZoneCode")
              val src_zone_coordinate: String = o.getString("srcZoneCoordinate")
              val dest_zone_code: String = o.getString("destZoneCode")
              val dest_zone_coordinate: String = o.getString("destZoneCoordinate")
              val start_end_state: String = o.getString("startEndState")
              val send_tm: String = o.getString("sendTm")
              val plan_arrive_tm: String = o.getString("planArriveTm")
              val predict_tm: String = o.getString("predictTm")
              val pick_up_lng: String = o.getString("pickUpLng")
              val pick_up_lat: String = o.getString("pickUpLat")
              val pick_up_tm: String = o.getString("pickUpTm")
              val remain_distance: String = o.getString("remainDistance")
              val remain_time: String = o.getString("remainTime")
              val arrival_tm: String = o.getString("arrivalTm")
              val latest_arrived_time: String = o.getString("latestArrivedTime")
              val status: String = o.getString("status")
              val plan_arrived_tm_state: String = o.getString("planArrivedTmState")
              val latest_arrived_tm_state: String = o.getString("latestArrivedTmState")
              val task_save_state: String = o.getString("taskSaveState")
              val `type`: String = o.getString("type")
              val plan_depart_tm: String = o.getString("planDepartTm")
              val abnormal_label: String = o.getString("abnormalLabel")
              val replan_arrive_time: String = o.getString("replanArriveTime")
              val replan_distance: String = o.getString("replanDistance")
              val yaw_cause: String = o.getString("yawCause")
              val solution: String = o.getString("solution")
              val is_selected_save_plan: String = o.getString("isSelectedSavePlan")
              val source: String = o.getString("source")

              EtaTsWmpInfo(
                  task_id, line_require_id, driver_id, vehicle_serial, src_zone_code, src_zone_coordinate, dest_zone_code, dest_zone_coordinate, start_end_state,
                  send_tm, plan_arrive_tm, predict_tm, pick_up_lng, pick_up_lat, pick_up_tm, remain_distance, remain_time, arrival_tm, latest_arrived_time,
                  status, plan_arrived_tm_state, latest_arrived_tm_state, task_save_state, `type`, plan_depart_tm, abnormal_label, replan_arrive_time,
                  replan_distance, yaw_cause, solution, is_selected_save_plan,source
              )
          })
          .withColumn("inc_day", lit(inc_day))
          .toDF()
          .coalesce(50)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, origDF, "原始数据")
        df2HiveByOverwrite(logger, origDF, "dm_gis.eta_ts_wmp_info_detail")
        origDF.unpersist()
    }

    // 解析定责结果数据
    def parseJudgeRespData(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        val sql: String =
            s"""
               |select
               |  info
               |from
               |  dm_gis.eta_ts_time_res_to_hive
               |where
               |  inc_day='$inc_day'
               |""".stripMargin

        val origDF: DataFrame = spark
          .sql(sql)
          .flatMap(r => {
              val info: String = r.getAs[String]("info")
              val o: JSONObject = JSON.parseObject(info)

              val task_id: String = o.getString("taskId")
              val delay_time: String = o.getString("delayTime")
              val if_evaluate_time: String = o.getString("ifEvaluateTime")
              val is_run_ontime: String = o.getString("isRunOnTime")

              val arrBuff = new ArrayBuffer[EtaTimeRes]()

              val subTaskInfoList: JSONArray = o.getJSONArray("subTaskInfoList")
              if (!subTaskInfoList.isEmpty) {
                  for (i <- 0 until subTaskInfoList.size()) {
                      val o2: JSONObject = subTaskInfoList.getJSONObject(i)

                      val combin_id: String = o2.getString("combinId")
                      val sub_task_id: String = o2.getString("taskId")
                      val sort_num: String = o2.getString("sortNum")
                      val start_dept: String = o2.getString("startDept")
                      val end_dept: String = o2.getString("endDept")
                      val actual_depart_tm: String = o2.getString("actualDepartTm")
                      val actual_arrive_tm: String = o2.getString("actualArriveTm")
                      val plan_run_time: String = o2.getString("planRunTime")
                      val actual_run_time: String = o2.getString("actualRunTime")
                      val sub_is_run_ontime: String = o2.getString("isRunOnTime")
                      val sub_delay_time: String = o2.getString("delayTime")
                      val vehicle_serial: String = o2.getString("vehicleSerial")
                      val service_rest_times: String = o2.getString("serviceRestTimes")
                      val service_plan_stay_duration: String = o2.getString("servicePlanStayDuration")
                      val service_label_sort_num: String = o2.getString("serviceLabelSortNum")
                      val service_label_points: String = o2.getString("serviceLabelPoints")
                      val service_label_total_duration: String = o2.getString("serviceLabelTotalDuration")
                      val total_service_total_duration_ratio: String = o2.getString("totalServiceTotalDurationRatio")
                      val total_service_delay_duration_ratio: String = o2.getString("totalServiceDelayDurationRatio")
                      val epidemic_label_sort_num: String = o2.getString("epidemicLabelSortNum")
                      val epidemic_label_points: String = o2.getString("epidemicLabelPoints")
                      val epidemic_label_total_duration: String = o2.getString("epidemicLabelTotalDuration")
                      val total_epidemic_total_duration_ratio: String = o2.getString("totalEpidemicTotalDurationRatio")
                      val total_epidemic_delay_duration_ratio: String = o2.getString("totalEpidemicDelayDurationRatio")
                      val toll_station_label_sort_num: String = o2.getString("tollStationLabelSortNum")
                      val toll_station_label_points: String = o2.getString("tollStationLabelPoints")
                      val toll_station_label_total_duration: String = o2.getString("tollStationLabelTotalDuration")
                      val total_toll_station_total_duration_ratio: String = o2.getString("totalTollStationTotalDurationRatio")
                      val total_toll_station_delay_duration_ratio: String = o2.getString("totalTollStationDelayDurationRatio")
                      val start_label_sort_num: String = o2.getString("startLabelSortNum")
                      val start_label_points: String = o2.getString("startLabelPoints")
                      val start_label_total_duration: String = o2.getString("startLabelTotalDuration")
                      val start_station_total_duration_ratio: String = o2.getString("startStationTotalDurationRatio")
                      val total_start_delay_duration_ratio: String = o2.getString("totalStartDelayDurationRatio")
                      val end_label_sort_num: String = o2.getString("endLabelSortNum")
                      val end_label_points: String = o2.getString("endLabelPoints")
                      val end_label_total_duration: String = o2.getString("endLabelTotalDuration")
                      val end_station_total_duration_ratio: String = o2.getString("endStationTotalDurationRatio")
                      val total_end_delay_duration_ratio: String = o2.getString("totalEndDelayDurationRatio")
                      val no_label_sort_num: String = o2.getString("noLabelSortNum")
                      val no_label_points: String = o2.getString("noLabelPoints")
                      val no_label_total_duration: String = o2.getString("noLabelTotalDuration")
                      val no_station_total_duration_ratio: String = o2.getString("noStationTotalDurationRatio")
                      val total_no_delay_duration_ratio: String = o2.getString("totalNoDelayDurationRatio")

                      arrBuff.append(
                          EtaTimeRes(
                              task_id, delay_time, if_evaluate_time, is_run_ontime, combin_id, sub_task_id, sort_num, start_dept, end_dept, actual_depart_tm, actual_arrive_tm,
                              plan_run_time, actual_run_time, sub_is_run_ontime, sub_delay_time, vehicle_serial, service_rest_times, service_plan_stay_duration, service_label_sort_num,
                              service_label_points, service_label_total_duration, total_service_total_duration_ratio, total_service_delay_duration_ratio, epidemic_label_sort_num,
                              epidemic_label_points, epidemic_label_total_duration, total_epidemic_total_duration_ratio, total_epidemic_delay_duration_ratio, toll_station_label_sort_num,
                              toll_station_label_points, toll_station_label_total_duration, total_toll_station_total_duration_ratio, total_toll_station_delay_duration_ratio,
                              start_label_sort_num, start_label_points, start_label_total_duration, start_station_total_duration_ratio, total_start_delay_duration_ratio,
                              end_label_sort_num, end_label_points, end_label_total_duration, end_station_total_duration_ratio, total_end_delay_duration_ratio, no_label_sort_num,
                              no_label_points, no_label_total_duration, no_station_total_duration_ratio, total_no_delay_duration_ratio
                          )
                      )
                  }
              }
              arrBuff
          })
          .withColumn("inc_day", lit(inc_day))
          .toDF()
          .coalesce(30)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, origDF, "原始数据")
        df2HiveByOverwrite(logger, origDF, "dm_gis.eta_ts_time_res_detail")
        origDF.unpersist()
    }


}
