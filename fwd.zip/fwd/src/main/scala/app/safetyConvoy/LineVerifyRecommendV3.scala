package app.safetyConvoy

import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.SparkConfigUtil

/**
  * 任务名称：线路推荐时长验证
  * 任务ID：471666
  * 需求人员：邵一馨 01408890
  * 开发人员：王冬冬 01413698
  */
object LineVerifyRecommendV3 {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {

        if (args.length != 1) {
            logger.error(
                """
                  |需要输入1个参数：
                  |    inc_day
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val inc_day: String = args(0)
        logger.error(s"取数日期：$inc_day")


        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 获取原始数据
        //        getorigData(spark, inc_day)

        // 生成推荐日期
        //        produceRecDate(spark: SparkSession, inc_day: String)
        // 历史30天的数据
        val hisDF: DataFrame = getHisLineData(spark, inc_day)
        // 验证推荐时长
        verifyRecommend(spark, hisDF, inc_day)
        //        allDF.unpersist()


        logger.error("运行结束！")
        // 程序运行结束,关闭spark
        spark.stop()
    }

    def getorigData(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        val yesterday: String = getdaysBeforeOrAfter(inc_day, -1)

        val monitorSql: String =
            s"""
               |select
               |  group,
               |  ac_is_run_ontime,
               |  actual_arrive_tm,
               |  actual_depart_tm,
               |  actual_run_time,
               |  biz_type,
               |  carrier_name,
               |  carrier_type,
               |  difftime_plan_actual,
               |  disu_periods,
               |  driver_id,
               |  driver_name,
               |  duration,
               |  end_dept,
               |  end_latitude,
               |  end_longitude,
               |  end_type,
               |  error_type,
               |  halfway_integrate_rate,
               |  is_stop,
               |  line_code,
               |  line_distance,
               |  line_time,
               |  plan_arrive_tm,
               |  plan_depart_tm,
               |  report_description,
               |  report_point,
               |  report_type,
               |  require_category,
               |  rt_dist,
               |  rt_event_cnt,
               |  rt_event_info,
               |  service,
               |  service_station_linkpointinfo,
               |  sort_num,
               |  start_dept,
               |  start_latitude,
               |  start_longitude,
               |  start_type,
               |  stop_over_zone_code,
               |  t_distance,
               |  t_duration,
               |  task_area_code,
               |  task_id,
               |  task_inc_day,
               |  task_subid,
               |  time,
               |  tl_durations,
               |  tl_index,
               |  tl_length,
               |  tl_link,
               |  tl_links,
               |  tl_road,
               |  tl_roadclass,
               |  tl_stay_points,
               |  tl_time_periods,
               |  to_ground,
               |  toll_station,
               |  toll_station_linkpointinfo,
               |  transoport_level,
               |  vehicle_serial,
               |  vehicle_type,
               |  x1,
               |  x2,
               |  y1,
               |  y2,
               |  group_count,
               |  group_max,
               |  group_min,
               |  group_mean,
               |  group_std,
               |  group_ontime_count,
               |  group_ontime_max,
               |  group_ontime_min,
               |  group_ontime_mean,
               |  group_ontime_std,
               |  distance_mean_std,
               |  ontime_distance_mean_std,
               |  raoxing_label,
               |  jcz,
               |  jcz_point,
               |  jcz_swid,
               |  sim1,
               |  sim5,
               |  std_id,
               |  std_coords,
               |  last_update_tm,
               |  start_outer_add_code,
               |  end_outer_add_code,
               |  line_require_id,
               |  ac_is_run_ontime_std,
               |  conduct_type,
               |  highwaymileage,
               |  actual_capacity_load,
               |  if_evaluate_time,
               |  std_highway,
               |  std_dist,
               |  highwaymileagepercentage,
               |  mileagepercentage,
               |  trackreliable,
               |  highwaymileagepercentagevalid
               |from
               |  dm_gis.eta_time_monitor
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin
        val tingliuSql: String =
            s"""
               |select
               |  task_subid,
               |  plan_run_time,
               |  service_rest_times,
               |  service_plan_stay_duration,
               |  total_stay_points_sort_num,
               |  total_stay_points_label,
               |  total_stay_points,
               |  total_stay_points_duration,
               |  total_stay_points_delay_ratio,
               |  suspected_abnormal_tingliu,
               |  service_label_sort_num,
               |  service_label_points,
               |  service_total_stay_points_duration,
               |  service_more_stay_duration,
               |  service_total_stay_points_duration_ratio,
               |  service_total_stay_points_duration_delay_ratio,
               |  toll_station_sub_label_sort_num,
               |  toll_station_sub_label_points,
               |  toll_station_sub_total_stay_points_duration,
               |  toll_station_sub_total_stay_points_duration_ratio,
               |  toll_station_ob_label_sort_num,
               |  toll_station_ob_label_points,
               |  toll_station_ob_total_stay_points_duration,
               |  toll_station_ob_total_stay_points_duration_ratio,
               |  epidemic_sub_label_sort_num,
               |  epidemic_sub_label_points,
               |  epidemic_sub_total_stay_points_duration,
               |  epidemic_sub_total_stay_points_duration_ratio,
               |  epidemic_sub_total_stay_points_duration_delay_ratio,
               |  epidemic_ob_label_sort_num,
               |  epidemic_ob_label_points,
               |  epidemic_ob_total_stay_points_duration,
               |  epidemic_ob_total_stay_points_duration_ratio,
               |  start_label_sort_num,
               |  start_label_points,
               |  start_total_stay_points_duration,
               |  start_total_stay_points_duration_ratio,
               |  start_total_stay_points_duration_delay_ratio,
               |  end_label_sort_num,
               |  end_label_points,
               |  end_total_stay_points_duration,
               |  end_total_stay_points_duration_ratio,
               |  end_total_stay_points_duration_delay_ratio,
               |  jyz_label_sort_num,
               |  jyz_label_points,
               |  jyz_total_stay_points_duration,
               |  jyz_total_stay_points_duration_ratio,
               |  jyz_total_stay_points_duration_delay_ratio,
               |  other_event_label_sort_num,
               |  other_event_label_points,
               |  other_event_total_stay_points_duration,
               |  other_event_total_stay_points_duration_ratio,
               |  highlow_level_label_sort_num,
               |  highlow_level_label_points,
               |  highlow_level_total_stay_points_duration,
               |  highlow_level_total_stay_points_duration_ratio,
               |  highlow_level_total_stay_points_duration_delay_ratio,
               |  gaosu_sub_label_sort_num,
               |  gaosu_sub_label_points,
               |  gaosu_sub_total_stay_points_duration,
               |  gaosu_sub_total_stay_points_duration_ratio,
               |  gaosu_sub_total_stay_points_duration_delay_ratio,
               |  gaosu_ob_label_sort_num,
               |  gaosu_ob_label_points,
               |  gaosu_ob_total_stay_points_duration,
               |  gaosu_ob_total_stay_points_duration_ratio,
               |  no_sub_label_sort_num,
               |  no_sub_label_points,
               |  no_sub_total_stay_points_duration,
               |  no_sub_total_stay_points_duration_ratio,
               |  no_sub_total_stay_points_duration_delay_ratio,
               |  no_ob_label_sort_num,
               |  no_ob_label_points,
               |  no_ob_total_stay_points_duration,
               |  no_ob_total_stay_points_duration_ratio,
               |  no_label_sort_num,
               |  no_label_points,
               |  no_total_stay_points_duration,
               |  no_total_stay_points_duration_ratio,
               |  no_total_stay_points_duration_delay_ratio
               |from
               |  dm_gis.eta_time_monitor_tingliu
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin
        val disuSql: String =
            s"""
               |select
               |  task_subid,
               |  service_ob_lowspeed_duration,
               |  service_sub_lowspeed_duration,
               |  service_ob_sub_lowspeed_duration,
               |  service_ob_lowspeed_duration_delay_ratio,
               |  service_sub_lowspeed_duration_delay_ratio,
               |  service_ob_sub_lowspeed_duration_delay_ratio,
               |  tollstation_ob_lowspeed_duration,
               |  tollstation_sub_lowspeed_duration,
               |  tollstation_ob_sub_lowspeed_duration,
               |  tollstation_ob_lowspeed_duration_delay_ratio,
               |  tollstation_sub_lowspeed_duration_delay_ratio,
               |  tollstation_ob_sub_lowspeed_duration_delay_ratio,
               |  epidemic_ob_lowspeed_duration,
               |  epidemic_sub_lowspeed_duration,
               |  epidemic_ob_sub_lowspeed_duration,
               |  epidemic_ob_lowspeed_duration_delay_ratio,
               |  epidemic_sub_lowspeed_duration_delay_ratio,
               |  epidemic_ob_sub_lowspeed_duration_delay_ratio,
               |  other_ob_lowspeed_duration,
               |  other_sub_lowspeed_duration,
               |  other_ob_sub_lowspeed_duration,
               |  other_ob_lowspeed_duration_delay_ratio,
               |  other_sub_lowspeed_duration_delay_ratio,
               |  other_ob_sub_lowspeed_duration_delay_ratio,
               |  end_ob_lowspeed_duration,
               |  end_sub_lowspeed_duration,
               |  end_ob_sub_lowspeed_duration,
               |  end_ob_lowspeed_duration_delay_ratio,
               |  end_sub_lowspeed_duration_delay_ratio,
               |  end_ob_sub_lowspeed_duration_delay_ratio,
               |  start_ob_lowspeed_duration,
               |  start_sub_lowspeed_duration,
               |  start_ob_sub_lowspeed_duration,
               |  start_ob_lowspeed_duration_delay_ratio,
               |  start_sub_lowspeed_duration_delay_ratio,
               |  start_ob_sub_lowspeed_duration_delay_ratio,
               |  no_ob_lowspeed_duration,
               |  no_sub_lowspeed_duration,
               |  no_ob_sub_lowspeed_duration,
               |  no_ob_lowspeed_duration_delay_ratio,
               |  no_sub_lowspeed_duration_delay_ratio,
               |  no_ob_sub_lowspeed_duration_delay_ratio,
               |  disu_cnt,
               |  disu_rank,
               |  disu_periods as disu_periods_final,
               |  disu_duration,
               |  disu_dis,
               |  disu_speed,
               |  if_tl_in_disu,
               |  disu_duration_tl,
               |  disu_label_3,
               |  disu_sub_oj,
               |  disu_label_sub_oj
               |from
               |  dm_gis.eta_time_monitor_disu_2
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin
        val recSql: String =
            s"""
               |select
               |  group,
               |  task_count                            as rec_task_count,
               |  new_task_count                        as rec_new_task_count,
               |  new_task_ontime_ratio_before          as rec_new_task_ontime_ratio_before,
               |  new_task_ontime_ratio_after           as rec_new_task_ontime_ratio_after,
               |  ontime_increase                       as rec_ontime_increase,
               |  rec_time                              as rec_time,
               |  time_change                           as rec_time_change,
               |  task_ontime_ratio2                    as rec_task_ontime_ratio2,
               |  task_ontime_ratio3                    as rec_task_ontime_ratio3,
               |  new_30min_ratio                       as rec_new_30min_ratio,
               |  new_60min_ratio                       as rec_new_60min_ratio,
               |  new_10per_ratio                       as rec_new_10per_ratio
               |From
               |  dm_gis.eta_time_recommendation
               |where
               |  inc_day ='$yesterday'
               |""".stripMargin

        logger.error("监控数据:" + monitorSql)
        logger.error("停留数据:" + tingliuSql)
        logger.error("低速数据:" + disuSql)
        logger.error("推荐数据:" + recSql)

        val monitorDF: DataFrame = spark.sql(monitorSql)
        val tingliuDF: DataFrame = spark.sql(tingliuSql)
        val disuDF: DataFrame = spark.sql(disuSql)
        val recDF: DataFrame = spark.sql(recSql)

        val taskDF: DataFrame = monitorDF
          .join(tingliuDF, Seq("task_subid"), "left")
          .join(disuDF, Seq("task_subid"), "left")
          .join(recDF, Seq("group"), "left")
          .na.fill("0.0", Array(
            "total_stay_points_duration", "gaosu_sub_total_stay_points_duration", "service_plan_stay_duration", "start_total_stay_points_duration", "actual_run_time", "highlow_level_total_stay_points_duration",
            "jyz_total_stay_points_duration", "service_total_stay_points_duration", "end_total_stay_points_duration", "toll_station_ob_total_stay_points_duration", "epidemic_ob_total_stay_points_duration", "other_event_total_stay_points_duration", "gaosu_ob_total_stay_points_duration",
            "no_ob_total_stay_points_duration", "toll_station_sub_total_stay_points_duration", "epidemic_sub_total_stay_points_duration", "jyz_total_stay_points_duration_delay_ratio", "service_sub_lowspeed_duration", "service_ob_lowspeed_duration", "service_ob_sub_lowspeed_duration", "tollstation_sub_lowspeed_duration",
            "tollstation_ob_lowspeed_duration", "tollstation_ob_sub_lowspeed_duration", "epidemic_sub_lowspeed_duration", "epidemic_ob_lowspeed_duration", "epidemic_ob_sub_lowspeed_duration", "start_sub_lowspeed_duration",
            "start_ob_lowspeed_duration", "start_ob_sub_lowspeed_duration", "end_sub_lowspeed_duration", "end_ob_lowspeed_duration", "end_ob_sub_lowspeed_duration", "other_ob_lowspeed_duration", "other_sub_lowspeed_duration",
            "other_ob_sub_lowspeed_duration", "no_sub_total_stay_points_duration", "no_sub_lowspeed_duration", "no_ob_lowspeed_duration", "no_ob_sub_lowspeed_duration"
        ))
          .na.fill(0, Array("rec_task_count", "rec_time_change", "rec_ontime_increase", "rec_time"))
          .na.fill(0.0, Array("rec_task_ontime_ratio2", "rec_task_ontime_ratio3", "rec_new_30min_ratio", "rec_new_60min_ratio", "rec_new_10per_ratio"))
          .withColumn("total_stay_points_duration", when($"total_stay_points_duration" === "", "0.0").otherwise($"total_stay_points_duration"))
          .withColumn("gaosu_sub_total_stay_points_duration", when($"gaosu_sub_total_stay_points_duration" === "", "0.0").otherwise($"gaosu_sub_total_stay_points_duration"))
          .withColumn("service_plan_stay_duration", when($"service_plan_stay_duration" === "", "0.0").otherwise($"service_plan_stay_duration"))
          .withColumn("difftime_plan_actual", when($"difftime_plan_actual".isNull or $"difftime_plan_actual" === "", 0.0).otherwise($"difftime_plan_actual"))
          .withColumn("start_total_stay_points_duration", when($"start_total_stay_points_duration" === "", "0.0").otherwise($"start_total_stay_points_duration"))
          .withColumn("actual_run_time", when($"actual_run_time" === "", "0.0").otherwise($"actual_run_time"))
          .withColumn("highlow_level_total_stay_points_duration", when($"highlow_level_total_stay_points_duration" === "", "0.0").otherwise($"highlow_level_total_stay_points_duration"))
          .withColumn("jyz_total_stay_points_duration", when($"jyz_total_stay_points_duration" === "", "0.0").otherwise($"jyz_total_stay_points_duration"))
          .withColumn("is_rec", when($"rec_task_count" > 3 and $"rec_task_ontime_ratio3" <= 0.8 and $"rec_task_ontime_ratio2" <= 0.7
            and $"rec_time_change" > 0 and $"rec_ontime_increase" > 0, 1)
            .otherwise(0)
          )
          .withColumn("is_rec_satisfied",
              when($"rec_time" <= 240 and $"rec_new_30min_ratio" >= 0.9, 1)
                .when($"rec_time" > 240 and $"rec_time" <= 480 and $"rec_new_60min_ratio" >= 0.8, 1)
                .when($"rec_time" > 480 and $"rec_new_10per_ratio" >= 0.7, 1)
                .otherwise(0)
          )
          .withColumn("service_final", round(($"service_total_stay_points_duration".cast("double") + $"service_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("service_ob_final", round(($"service_ob_lowspeed_duration".cast("double") + $"service_ob_sub_lowspeed_duration") / 60, 2))
          .withColumn("service_gaosu_final", round(($"service_total_stay_points_duration".cast("double") + $"service_sub_lowspeed_duration".cast("double") + $"gaosu_sub_total_stay_points_duration").cast("double") / 60, 2))
          .withColumn("tollstation_sub_final", round(($"toll_station_sub_total_stay_points_duration".cast("double") + $"tollstation_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("tollstation_sub_final_ratio", round($"tollstation_sub_final" / $"difftime_plan_actual", 2))
          .withColumn("tollstation_ob_final", round(($"toll_station_ob_total_stay_points_duration".cast("double") + $"tollstation_ob_lowspeed_duration".cast("double") + $"tollstation_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("tollstation_ob_final_ratio", round($"tollstation_ob_final" / $"difftime_plan_actual", 2))
          .withColumn("epidemic_sub_final", round(($"epidemic_sub_total_stay_points_duration".cast("double") + $"epidemic_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("epidemic_sub_final_ratio", round($"epidemic_sub_final" / $"difftime_plan_actual", 2))
          .withColumn("epidemic_ob_final", round(($"epidemic_ob_total_stay_points_duration".cast("double") + $"epidemic_ob_lowspeed_duration".cast("double") + $"epidemic_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("epidemic_ob_final_ratio", round($"epidemic_ob_final" / $"difftime_plan_actual", 2))
          .withColumn("start_sub_final", round(($"start_total_stay_points_duration".cast("double") + $"start_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("start_sub_final_ratio", round($"start_sub_final" / $"difftime_plan_actual", 2))
          .withColumn("start_ob_final", round(($"start_ob_lowspeed_duration".cast("double") + $"start_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("start_ob_final_ratio", round($"start_ob_final" / $"difftime_plan_actual", 2))
          .withColumn("end_sub_final", round(($"end_total_stay_points_duration".cast("double") + $"end_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("end_sub_final_ratio", round($"end_sub_final" / $"difftime_plan_actual", 2))
          .withColumn("end_ob_final", round(($"end_ob_lowspeed_duration".cast("double") + $"end_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("end_ob_final_ratio", round($"end_ob_final" / $"difftime_plan_actual", 2))
          .withColumn("other_event_final", round(($"other_event_total_stay_points_duration".cast("double") + $"other_ob_lowspeed_duration".cast("double") + $"other_sub_lowspeed_duration".cast("double") + $"other_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("other_event_final_ratio", round($"other_event_final" / $"difftime_plan_actual", 2))
          .withColumn("no_label_sub_final", round(($"no_sub_total_stay_points_duration".cast("double") + $"no_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("no_label_sub_final_ratio", round($"no_label_sub_final" / $"difftime_plan_actual", 2))
          .withColumn("no_label_ob_final", round(($"no_ob_total_stay_points_duration".cast("double") + $"gaosu_ob_total_stay_points_duration".cast("double") + $"no_ob_lowspeed_duration".cast("double") + $"no_ob_sub_lowspeed_duration".cast("double")) / 60, 2))
          .withColumn("no_label_ob_final_ratio", round($"no_label_ob_final" / $"difftime_plan_actual", 2))
          .withColumn("service_rest_times", floor($"line_time".cast("double") / 240))
          .withColumn("service_plan_stay_duration", ($"service_rest_times" * 1200).cast("string"))
          .withColumn("zhuguan_fuwuqu", round($"service_final" - $"service_plan_stay_duration".cast("double") / 60, 2))
          .withColumn("zhuguan_fuwuqu_ratio", $"zhuguan_fuwuqu" / $"difftime_plan_actual")
          .withColumn("actual_run_tm3", round($"actual_run_time".cast("double") - $"zhuguan_fuwuqu" - $"start_sub_final" - $"end_sub_final", 2))
          .withColumn("actual_run_tm4", round($"actual_run_time".cast("double") - $"service_gaosu_final" - $"start_sub_final" - $"end_sub_final" - $"highlow_level_total_stay_points_duration".cast("double") / 60 - $"jyz_total_stay_points_duration".cast("double") / 60, 2))
          .na.fill(0.0, Array("actual_run_tm3", "actual_run_tm4"))
          .withColumn("t_duration2", round($"t_duration" * 1.1, 2))
          .withColumn("time_diff_gaode", round($"actual_run_tm3" - $"t_duration2" / 60, 2))
          .withColumn("time_diff_gaode_ratio", round($"time_diff_gaode" * 60 / $"t_duration2", 2))
          .withColumn("time_diff_gaode2", round($"actual_run_tm4" - $"t_duration2" / 60, 2))
          .withColumn("time_diff_gaode2_ratio", round($"time_diff_gaode2" * 60 / $"t_duration2", 2))
          .withColumn("task_final_label", when(array_contains(split($"error_type", "|"), "4") or array_contains(split($"error_type", "|"), "5") or $"rt_dist".cast("double") === 0.0, "轨迹异常")
            .when($"raoxing_label".isNotNull and $"raoxing_label" =!= "无法判断", "线路绕行")
            .when($"time_diff_gaode2_ratio" > 0.2, "与高德校验异常")
            .otherwise("无法判断")
          )
          .withColumn("total_keguan", round($"jyz_total_stay_points_duration".cast("double") / 60 + $"service_ob_final" + $"tollstation_ob_final" +
            $"epidemic_ob_final" + $"start_ob_final" + $"end_ob_final" + $"no_label_ob_final" + $"other_event_final", 2))
          .withColumn("total_keguan_ratio", round($"total_keguan" / $"difftime_plan_actual", 2))
          .withColumn("total_zhuguan", round($"zhuguan_fuwuqu" + $"tollstation_sub_final" + $"epidemic_sub_final" + $"start_sub_final" + $"end_sub_final" + $"no_label_sub_final", 2))
          .withColumn("total_zhuguan_ratio", round($"total_zhuguan" / $"difftime_plan_actual", 2))
          .withColumn("task_label1", when($"ac_is_run_ontime" === "0.0" and ($"total_zhuguan_ratio" <= -0.5 or ($"trackreliable" === "true" and $"highwaymileagepercentagevalid" === "false" and 'std_highway.cast("int") > 2000 and 'std_dist.cast("int") > 10000 and 'std_highway.cast("double") / 'std_dist.cast("int") > 0.05 and 'conduct_type === "3")), "主观")
            .when($"ac_is_run_ontime" === "0.0" and $"is_rec" === 1 and $"is_rec_satisfied" === 1 and ($"rec_time_change".cast("double") - 'line_time.cast("double")) / $"difftime_plan_actual" <= -0.5, "规划时长不足")
            .when('ac_is_run_ontime === "0.0" and 'total_keguan_ratio <= -0.5, "客观")
            .otherwise("系统未识别")
          )
          .withColumn("keguan1", when($"task_label1" === "客观" and $"tollstation_ob_final_ratio" <= -0.5, "收费站客观停留/低速"))
          .withColumn("keguan2", when($"task_label1" === "客观" and $"epidemic_ob_final_ratio" <= -0.5, "疫情检查"))
          .withColumn("keguan3", when($"task_label1" === "客观" and $"jyz_total_stay_points_duration_delay_ratio".cast("double") <= -0.5, "加油站客观停留/低速"))
          .withColumn("keguan4", when($"task_label1" === "客观" and $"other_event_final_ratio" <= -0.5, "其他事件"))
          .withColumn("keguan5", when($"task_label1" === "客观" and $"no_label_ob_final_ratio" <= -0.5, "路况拥堵"))
          .withColumn("keguan6", when($"task_label1" === "客观" and $"start_ob_final_ratio" <= -0.5, "起点拥堵"))
          .withColumn("keguan7", when($"task_label1" === "客观" and $"end_ob_final_ratio" <= -0.5, "终点拥堵"))
          .withColumn("keguan8", when($"task_label1" === "客观" and $"service_ob_final" / 'difftime_plan_actual <= -0.5, "服务区拥堵"))
          .withColumn("task_label_keguan", concat_ws("|", $"keguan1", $"keguan2", $"keguan3", $"keguan4", $"keguan5", $"keguan6", 'keguan7, 'keguan8))
          .withColumn("flag1", when($"task_label1" === "主观" and $"zhuguan_fuwuqu_ratio" <= -0.5, "服务区主观停留/低速"))
          .withColumn("flag2", when($"task_label1" === "主观" and $"start_sub_final_ratio" <= -0.5, "起点主观停留/低速"))
          .withColumn("flag3", when($"task_label1" === "主观" and $"end_sub_final_ratio" <= -0.5, "终点主观停留/低速"))
          .withColumn("flag4", when($"task_label1" === "主观" and $"tollstation_sub_final_ratio" <= -0.5, "收费站主观停留/低速"))
          .withColumn("flag5", when($"task_label1" === "主观" and $"epidemic_sub_final_ratio" <= -0.5, "疫情检查站主观停留/低速"))
          .withColumn("flag6", when($"task_label1" === "主观" and $"trackreliable" === "true" and $"highwaymileagepercentagevalid" === "false" and 'std_highway.cast("int") > 2000 and 'std_dist.cast("int") > 10000 and 'std_highway.cast("double") / 'std_dist.cast("int") > 0.05 and 'conduct_type === "3", "未全程高速"))
          .withColumn("task_label_zhuguan", concat_ws("|", $"flag1", $"flag2", $"flag3", $"flag4", $"flag5", $"flag6"))
          .withColumn("task_label_other", when($"task_label1" === "系统未识别" and (array_contains(split($"error_type", "|"), "4") or array_contains(split($"error_type", "|"), "5") or $"rt_dist".cast("double") === 0.0), "轨迹异常")
            .otherwise("")
          )
          .withColumn("task_label2", concat($"task_label_keguan", $"task_label_zhuguan", $"task_label_other"))
          .drop("keguan1", "keguan2", "keguan3", "keguan4", "keguan5", "keguan6", "keguan7", "keguan8", "flag1", "flag2", "flag3", "flag4", "flag5", "flag6")
          .withColumn("zhuguan_fuwuqu", round($"service_final" - $"service_plan_stay_duration".cast("double") / 60, 2))
          .withColumn("inc_day", lit(inc_day))
          .coalesce(100)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, taskDF, "汇总后的数据")
        testDF2Hive(logger, taskDF, "dm_gis.eta_task_time_information_tmp")
        taskDF.unpersist()
    }

    // 生成时长推荐日期表
    def produceRecDate(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._

        val rec_start_inc_day: String = getdaysBeforeOrAfter(inc_day, -30)
        val rec_end_inc_day: String = inc_day
        val rec_delete_inc_day: String = ""
        val vef_start_inc_day: String = rec_start_inc_day
        val vef_end_inc_day: String = inc_day
        val vef_delete_inc_day: String = ""

        val dateDF: DataFrame = Seq(rec_start_inc_day, rec_end_inc_day, rec_delete_inc_day, vef_start_inc_day, vef_end_inc_day, vef_delete_inc_day, inc_day)
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, dateDF, "生成的推荐日期数据")
        df2HiveByOverwrite(logger, dateDF, "dm_gis.std_time_recommendation_date")
        dateDF.unpersist()
    }

    // 历史30天的数据
    def getHisLineData(spark: SparkSession, inc_day: String): DataFrame = {
        import spark.implicits._

        val rec_start_inc_day: String = getdaysBeforeOrAfter(inc_day, -30)
        val rec_end_inc_day: String = inc_day
        val rec_delete_inc_day: String = ""
        val vef_start_inc_day: String = rec_start_inc_day
        val vef_end_inc_day: String = inc_day
        val vef_delete_inc_day: String = ""

        val inc_day2: String = getdaysBeforeOrAfter(inc_day, -30)
        val task_inc_day: String = inc_day

        val taskSql: String =
            s"""
               |select
               |  *
               |from
               |(
               |  select
               |    concat_ws('_',line_code,start_dept,end_dept,start_type,end_type,start_outer_add_code,end_outer_add_code) as group,
               |    line_code,
               |    start_dept,
               |    end_dept,
               |    task_subid,
               |    start_type,
               |    end_type,
               |    start_outer_add_code,
               |    end_outer_add_code,
               |    actual_run_tm3,
               |    actual_run_time,
               |    ac_is_run_ontime,
               |    last_update_tm,
               |    line_time,
               |    task_final_label,
               |    row_number() over(partition by task_subid order by task_inc_day desc) as rn
               |  from
               |    dm_gis.eta_task_time_information
               |  where
               |    inc_day > '$rec_start_inc_day'
               |    and inc_day <= '$rec_end_inc_day'
               |    and task_inc_day > '$rec_start_inc_day'
               |    and task_inc_day <= '$rec_end_inc_day'
               |    and task_inc_day not in '$rec_delete_inc_day'
               |    and actual_run_tm3 > 0.0
               |    and if_evaluate_time = '1'
               |) a
               |where
               |  rn = 1
               |""".stripMargin
        logger.error("历史30天的任务数据：" + taskSql)

        val taskDF: DataFrame = spark.sql(taskSql).persist(StorageLevel.MEMORY_AND_DISK)

        val w1: WindowSpec = Window.partitionBy("group").orderBy($"last_update_tm".desc)
        val tmDF: DataFrame = taskDF
          .withColumn("rn", row_number() over w1)
          .filter("rn = 1")
          .withColumn("future_plan_run_tm", 'line_time.cast("double"))
          .select("group", "future_plan_run_tm")
          .dropDuplicates()
          .persist(StorageLevel.MEMORY_AND_DISK)

        val allDF: DataFrame = tmDF
          .join(taskDF, Seq("group"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        val allDF2: DataFrame = allDF
          .groupBy("group")
          .agg(
              expr("percentile(actual_run_tm3, array(0.5))[0]").alias("zws")
          )

        val allDF3: DataFrame = allDF
          .join(allDF2, Seq("group"))
          .withColumn("difftime_plan_actual2", round($"future_plan_run_tm" - $"actual_run_time".cast("double"), 2))
          .withColumn("ac_is_run_ontime2", when($"difftime_plan_actual2" + 1 >= 0, 1).otherwise(0))
          .withColumn("difftime_plan_actual3", round($"future_plan_run_tm" - $"actual_run_tm3", 2))
          .withColumn("ac_is_run_ontime3", when($"difftime_plan_actual3" + 1 >= 0, 1).otherwise(0))
          .persist(StorageLevel.MEMORY_AND_DISK)

        val allDF31: DataFrame = allDF3
          .groupBy("group")
          .agg(
              size(collect_set("task_subid")).as("task_count_before"),
              size(collect_set(when($"ac_is_run_ontime" === 1, $"task_subid"))).as("task_ontime_count1"),
              size(collect_set(when($"ac_is_run_ontime" === 0, $"task_subid"))).as("task_late_count1"),
              size(collect_set(when($"ac_is_run_ontime2" === 1, $"task_subid"))).as("task_ontime_count2"),
              size(collect_set(when($"ac_is_run_ontime2" === 0, $"task_subid"))).as("task_late_count2"),
              size(collect_set(when($"ac_is_run_ontime3" === 1, $"task_subid"))).as("task_ontime_count3_before"),
              size(collect_set(when($"ac_is_run_ontime3" === 0, $"task_subid"))).as("task_late_count3_before")

          )
          .withColumn("task_ontime_ratio1", round($"task_ontime_count1".cast("double") / $"task_count_before", 2))
          .withColumn("task_ontime_ratio2", round($"task_ontime_count2".cast("double") / $"task_count_before", 2))
          .withColumn("task_ontime_ratio3_before", round($"task_ontime_count3_before".cast("double") / $"task_count_before", 2))

        val allDF4: DataFrame = allDF3
          .filter("zws*1.8 > actual_run_tm3 and zws * 0.2 < actual_run_tm3 and task_final_label not in ('劝返','轨迹异常','线路绕行','与高德校验异常')")
          .groupBy("group")
          .agg(
              concat_ws("|", collect_list("task_subid")).as("task_subids"),
              concat_ws("|", collect_list("actual_run_tm3")).as("total_actual_run_tm3"),
              size(collect_set("task_subid")).as("task_count"),
              size(collect_set(when($"ac_is_run_ontime3" === 1, $"task_subid"))).as("task_ontime_count3"),
              size(collect_set(when($"ac_is_run_ontime3" === 0, $"task_subid"))).as("task_late_count3"),
              round(skewness("actual_run_tm3"), 2).as("skewness"),
              round(max("actual_run_tm3") - min("actual_run_tm3"), 2).as("minmax"),
              round(stddev_pop("actual_run_tm3"), 2).as("std"),
              round(mean("actual_run_tm3"), 2).as("mean"),
              round(expr("percentile(actual_run_tm3, array(0.5))[0]"), 2).as("percentile50"),
              round(expr("percentile(actual_run_tm3, array(0.6))[0]"), 2).as("percentile60"),
              round(expr("percentile(actual_run_tm3, array(0.7))[0]"), 2).as("percentile70"),
              round(expr("percentile(actual_run_tm3, array(0.8))[0]"), 2).as("percentile80"),
              round(expr("percentile(actual_run_tm3, array(0.9))[0]"), 2).as("percentile90"),
              round(expr("percentile(actual_run_tm3, array(0.94))[0]"), 2).as("percentile94")
          )
          .withColumn("task_ontime_ratio3", round($"task_ontime_count3".cast("double") / $"task_count", 2))
          .withColumn("rec_time", when($"skewness" > -0.2 or $"minmax" <= 30, $"percentile90".cast("int")).otherwise($"percentile80".cast("int")))
          .withColumn("rec_time_final", concat(floor($"rec_time" / 60), lit("小时"), $"rec_time" % 60, lit("分")))
          .join(allDF31, Seq("group"))
          .join(tmDF, Seq("group"))
          .withColumn("time_change", $"rec_time" - $"future_plan_run_tm".cast("int"))
          .withColumn("rec_label", when('time_change > 0 and 'task_count > 3 and 'task_ontime_ratio2 <= 0.7 and 'task_ontime_ratio3 <= 0.8, 1).otherwise(0))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, allDF4, "历史30天的推荐数据")
        allDF4
    }

    // 验证推荐时长
    def verifyRecommend(spark: SparkSession, hisDF: DataFrame, inc_day: String): Unit = {
        import spark.implicits._

        val task_inc_day: String = getdaysBeforeOrAfter(inc_day, -15)

        val taskSql: String =
            s"""
               |select
               |  *
               |from
               |(
               |  select
               |    concat_ws('_',line_code,start_dept,end_dept,start_type,end_type,start_outer_add_code,end_outer_add_code) as group,
               |    task_subid,
               |    actual_run_tm3,
               |    actual_run_time,
               |    row_number() over(partition by task_subid order by task_inc_day desc) as rn
               |  from
               |    dm_gis.eta_task_time_information
               |  where
               |    inc_day > '$task_inc_day'
               |    and inc_day <= '$inc_day'
               |    and task_inc_day > '$task_inc_day'
               |    and task_inc_day <= '$inc_day'
               |) a
               |where
               |  rn = 1
               |""".stripMargin
        logger.error(s"历史15天的数据:$taskSql")
        val taskDF: DataFrame = spark.sql(taskSql).drop("rn")

        val resultDF: DataFrame = hisDF
          .join(taskDF, Seq("group"), "left")
          .withColumn("difftime_plan_actual_before", $"future_plan_run_tm" - $"actual_run_time".cast("int"))
          .withColumn("difftime_plan_actual_before2", $"future_plan_run_tm" - $"actual_run_tm3".cast("int"))
          .withColumn("difftime_plan_actual_after", $"rec_time" - $"actual_run_time".cast("int"))
          .withColumn("difftime_plan_actual_after2", $"rec_time" - $"actual_run_tm3".cast("int"))
          .withColumn("difftime_plan_actual_ratio_after", round($"difftime_plan_actual_after".cast("double") / $"rec_time", 2))
          .withColumn("difftime_plan_actual_ratio_after2", round($"difftime_plan_actual_after2".cast("double") / $"rec_time", 2))
          .withColumn("ac_is_run_ontime_before", when($"difftime_plan_actual_before" + 1 >= 0, 1).otherwise(0))
          .withColumn("ac_is_run_ontime_before2", when($"difftime_plan_actual_before2" + 1 >= 0, 1).otherwise(0))
          .withColumn("ac_is_run_ontime_after", when($"difftime_plan_actual_after" + 1 >= 0, 1).otherwise(0))
          .withColumn("ac_is_run_ontime_after2", when($"difftime_plan_actual_after2" + 1 >= 0, 1).otherwise(0))
          .groupBy("group")
          .agg(
              concat_ws("|", collect_list("task_subid")).as("new_task_subids"),
              concat_ws("|", collect_list("actual_run_tm3")).as("new_total_actual_run_tm3"),
              size(collect_set("task_subid")).as("new_task_count"),
              size(collect_set(when($"ac_is_run_ontime_before" === 1, $"task_subid"))).as("new_task_ontime_count_before"),
              size(collect_set(when($"ac_is_run_ontime_before2" === 1, $"task_subid"))).as("new_task_ontime_count_before2"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1, $"task_subid"))).as("new_task_ontime_count_after"),
              size(collect_set(when($"ac_is_run_ontime_after2" === 1, $"task_subid"))).as("new_task_ontime_count_after2"),
              size(collect_set(when($"ac_is_run_ontime_before" === 0, $"task_subid"))).as("new_task_late_count_before"),
              size(collect_set(when($"ac_is_run_ontime_before2" === 0, $"task_subid"))).as("new_task_late_count_before2"),
              size(collect_set(when($"ac_is_run_ontime_after" === 0, $"task_subid"))).as("new_task_late_count_after"),
              size(collect_set(when($"ac_is_run_ontime_after2" === 0, $"task_subid"))).as("new_task_late_count_after2"),
              sort_array(collect_set(when($"ac_is_run_ontime_after" === 1, abs($"difftime_plan_actual_after")).otherwise(0)))(0).as("new_min"),
              sort_array(collect_set(when($"ac_is_run_ontime_after" === 1, abs($"difftime_plan_actual_after")).otherwise(0)), asc = false)(0).as("new_max"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_after") <= 30, $"task_subid"))).as("new_30minl_count"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_after") > 30, $"task_subid"))).as("new_30minh_count"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_after") <= 60, $"task_subid"))).as("new_60minl_count"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_after") > 60, $"task_subid"))).as("new_60minh_count"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_ratio_after") <= 0.05, $"task_subid"))).as("new_5per_l_count"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_ratio_after") > 0.05, $"task_subid"))).as("new_5per_h_count"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_ratio_after") <= 0.1, $"task_subid"))).as("new_10per_l_count"),
              size(collect_set(when($"ac_is_run_ontime_after" === 1 and abs($"difftime_plan_actual_ratio_after") > 0.1, $"task_subid"))).as("new_10per_h_count")
          )
          .withColumn("new_task_ontime_ratio_before", round($"new_task_ontime_count_before".cast("double") / $"new_task_count", 2))
          .withColumn("new_task_ontime_ratio_before2", round($"new_task_ontime_count_before2".cast("double") / $"new_task_count", 2))
          .withColumn("new_task_ontime_ratio_after", round($"new_task_ontime_count_after".cast("double") / $"new_task_count", 2))
          .withColumn("new_task_ontime_ratio_after2", round($"new_task_ontime_count_after2".cast("double") / $"new_task_count", 2))
          .withColumn("new_30min_ratio", round($"new_30minl_count".cast("double") / $"new_task_ontime_count_after", 2))
          .withColumn("new_60min_ratio", round($"new_60minl_count".cast("double") / $"new_task_ontime_count_after", 2))
          .withColumn("new_5per_ratio", round($"new_5per_l_count".cast("double") / $"new_task_ontime_count_after", 2))
          .withColumn("new_10per_ratio", round($"new_10per_l_count".cast("double") / $"new_task_ontime_count_after", 2))
          .withColumn("ontime_increase", $"new_task_ontime_count_after" - $"new_task_ontime_count_before")
          .withColumn("ontime_increase2", $"new_task_ontime_count_after2" - $"new_task_ontime_count_before2")
          .withColumn("is_increase", when($"ontime_increase" > 0, 1).otherwise(0))
          .join(hisDF, Seq("group"))
          .withColumn("rec_satisfied_label",
              when($"rec_time" <= 240 and $"new_30min_ratio" >= 0.9, 1)
                .when($"rec_time" > 240 and $"rec_time" <= 480 and $"new_60min_ratio" >= 0.8, 1)
                .when($"rec_time" > 480 and $"new_10per_ratio" >= 0.7, 1)
                .otherwise(0)
          )
          .withColumn("inc_day", lit(inc_day))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, resultDF, "最终的结果")
        testDF2Hive(logger, resultDF, "dm_gis.eta_time_recommendation")//todo

        resultDF.unpersist()
    }


}
