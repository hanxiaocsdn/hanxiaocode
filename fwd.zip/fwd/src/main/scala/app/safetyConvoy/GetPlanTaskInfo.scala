package app.safetyConvoy

import com.alibaba.fastjson._
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.HttpConnection.httpPost2
import utils.SparkConfigUtil

/**
 * 任务名称：获取未来2周的任务信息
 * 任务ID：464403
 * 需求人员：邵一馨 01408890
 * 开发人员：王冬冬 01413698
 */
object GetPlanTaskInfo {

  // 初始化
  val className: String = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)
  val url: String = "http://gis-gw.int.sfdc.com.cn:9080/etawmp/api/queryLatestSchedule"
  def main(args: Array[String]): Unit = {

    if (args.length != 1) {
      logger.error(
        """
          |需要输入1个参数：
          |    inc_day
          |""".stripMargin)
      sys.exit(-1)
    }

    // 接收外部传递进来的变量
    val inc_day: String = args(0)
    logger.error(s"取数日期：$inc_day ")

    // 创建spark
    val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

    // 获取原始数据
    getorigData(spark, inc_day)


    logger.error("运行结束！")
    // 程序运行结束,关闭spark
    spark.stop()
  }

  // 解析时效监控数据
  def getorigData(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._

    val plan_run_dt_start: String = getdaysBeforeOrAfter(inc_day, 1)
    val plan_run_dt_end: String = getdaysBeforeOrAfter(inc_day, 14)

    val proSql: String =
      s"""
         |select
         |  a.id                      as future_task_id,
         |  a.planning_main_id        as task_future_planning_main_id,
         |  a.line_code               as task_line_code,
         |  a.omcs_line_code          as task_omcs_line_code,
         |  a.plan_run_dt             as task_plan_run_dt,
         |  a.oper_type               as task_oper_type,
         |  a.status                  as task_status,
         |  bb.start_dept             as start_dept,
         |  bb.job_type               as job_type,
         |  bb.end_dept               as end_dept,
         |  bb.plan_depart_tm         as future_plan_depart_tm,
         |  bb.arrive_tm              as future_plan_arrive_tm,
         |  bb.plan_main_id           as plan_main_id,
         |  bb.arrive_batch           as plan_arrive_batch
         |from
         |  dm_pass_rss.scha_tt_plan_main_pro a
         |left join (
         |  select
         |    lag(b.dept_code, 1) over(partition by b.plan_main_id order by b.docking_sequence asc)   as start_dept,
         |    lag(b.send_tm, 1) over(partition by b.plan_main_id order by b.docking_sequence asc)     as plan_depart_tm,
         |    b.job_type,
         |    b.dept_code                                                                             as end_dept,
         |    b.arrive_tm,
         |    b.plan_main_id,
         |    b.arrive_batch
         |  from
         |    (
         |      select
         |        dept_code,
         |        plan_main_id,
         |        docking_sequence,
         |        send_tm,
         |        arrive_tm,
         |        job_type,
         |        arrive_batch
         |      from
         |        dm_pass_rss.scha_tt_plan_point_pro
         |      where
         |        inc_day = '$inc_day'
         |        and regexp_replace(cast(plan_run_dt as string),'-','') >= '$plan_run_dt_start'
         |        and regexp_replace(cast(plan_run_dt as string),'-','') <= '$plan_run_dt_end'
         |    ) b
         |) bb on a.id = bb.plan_main_id
         |where
         |  inc_day = '$inc_day'
         |  and regexp_replace(cast(plan_run_dt as string),'-','') >= '$plan_run_dt_start'
         |  and regexp_replace(cast(plan_run_dt as string),'-','') <= '$plan_run_dt_end'
         |  and bb.start_dept is not null
         |  and oper_type in (1, 2)
         |  and require_category in (0, 1, 2, 17, 18)
         |  and status = 1
         |""".stripMargin
    logger.error("未来2周的计划数据：" + proSql)


    val org_planTmpDF: DataFrame = spark
      .sql(proSql)
      .withColumn("future_plan_depart_tm2", split($"future_plan_depart_tm", " ")(1))
      .withColumn("future_plan_arrive_tm2", split($"future_plan_arrive_tm", " ")(1))
      .withColumn("future_plan_run_tm", getTimeDiff($"future_plan_arrive_tm", $"future_plan_depart_tm"))
      .dropDuplicates("task_omcs_line_code", "start_dept", "end_dept", "future_plan_depart_tm2", "future_plan_arrive_tm2")
      .withColumn("plan_tm", getTimestamp($"future_plan_arrive_tm"))
      .repartition(3).persist()

    val httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "464403", "获取未来2周的任务信息", "基础服务", url, "b61f6c427934416dbc3248dbefef5eb0", org_planTmpDF.count(), 2)
    val planTmpDF = org_planTmpDF.withColumn("futrue_tm", explode(futureArriveTime($"end_dept", $"plan_tm")))
      .withColumn("future_latest_arrival_tm", $"futrue_tm._1")
      .withColumn("future_latest_arrival_tm2", $"futrue_tm._2")
      .drop("futrue_tm", "plan_tm")
      .withColumn("inc_day", lit(inc_day))
      .persist(StorageLevel.MEMORY_AND_DISK)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke)

    GetDFCountAndSampleData(logger, planTmpDF, "未来规划数据")
    testDF2Hive(logger, planTmpDF, "dm_gis.plan_pro_infomation_tmp")
    planTmpDF.unpersist()

    val planDF: DataFrame = spark.sql("select * from dm_gis.plan_pro_infomation_tmp").drop("inc_day").cache()

    val planDF2: DataFrame = planDF
      .groupBy("task_omcs_line_code", "start_dept", "end_dept")
      .agg(
        concat_ws("|", collect_set("future_plan_depart_tm2")).as("total_future_plan_depart_tm2"),
        concat_ws("|", collect_set("future_plan_arrive_tm2")).as("total_future_plan_arrive_tm2"),
        concat_ws("|", collect_set("future_latest_arrival_tm2")).as("total_future_latest_arrival_tm2")
      )

    val planDF3: DataFrame = planDF
      .join(planDF2, Seq("task_omcs_line_code", "start_dept", "end_dept"))
      .withColumn("inc_day", lit(inc_day))
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, planDF3, "规划的最终数据")
    df2HiveByOverwrite(logger, planDF3, "dm_gis.plan_pro_infomation")
    planDF.unpersist()
  }

  // 获取未来最近到时间
  def futureArriveTime: UserDefinedFunction = udf((end_dept: String, plan_tm: Long) => {
    val parm = new JSONObject()

    parm.put("endDept", end_dept)
    parm.put("planArriveTm", plan_tm)
    parm.put("queryType", 1)

    val str: String = httpPost2(2, url, parm.toJSONString, "6073c46090264a9ea4d4e899cdee8b62")

    var future_latest_arrival_tm: String = ""
    var future_latest_arrival_tm2: String = ""
    try {
      val o: JSONObject = JSON.parseObject(str)
      val status: String = o.getString("status")
      if (status == "0") future_latest_arrival_tm = o.getJSONObject("result").getString("latestArrivalTm")
      if (!isEmptyOrNull(future_latest_arrival_tm)) future_latest_arrival_tm2 = future_latest_arrival_tm.split(" ")(1)
    } catch {
      case e: Exception => logger.error("接口解析失败" + e.getMessage)
    }

    logger.error("future_latest_arrival_tm:" + future_latest_arrival_tm)
    logger.error("future_latest_arrival_tm2:" + future_latest_arrival_tm2)

    val res = new Array[(String, String)](1)
    res(0) = (future_latest_arrival_tm, future_latest_arrival_tm2)
    res
  })


}
