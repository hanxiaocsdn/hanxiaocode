package app.detour

import app.runLimited.DealLocusAbnormalDataFromLimited.get_distance2
import app.runLimited.GetRoutePlanDataFromGDAndCTAndJY.interStatus2Hive
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.CompareLimited
import org.apache.spark.Partitioner
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, row2Json}
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.Random


/**
 * (临时执行) 已下线
  * 4.解析限行信息
  */
object AnalysisLimitedInfo {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")

    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://plan-m.db.sfcloud.local:3306/other"
    val userName = "other"
    val passWd = "other20211227#"

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 记录调用高德接口的成功、失败次数
        val qm_success_acc: LongAccumulator = spark.sparkContext.longAccumulator
        val qm_fail_acc: LongAccumulator = spark.sparkContext.longAccumulator

        // 导入隐式转换
        import spark.implicits._

        // 从MySQL里获取循环过程的得到数据 存到hive上
        mysqlToHive(logger, spark, "raoxing_waypoints_drop_duplicates_gdapp_out", start_time, end_time)
        mysqlToHive(logger, spark, "raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_multi", start_time, end_time)
        mysqlToHive(logger, spark, "raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_ratio", start_time, end_time)
        mysqlToHive(logger, spark, "raoxing_waypoints_drop_duplicates_gdapp_out_waypoints_all", start_time, end_time)

        // 循环结束之后，表八最终的数据
        saveToHive(logger, spark, start_time, end_time)


        // (表十二)
        val compareRatioSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_ratio
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        val compareRatioDF: Dataset[Row] = spark
          .sql(compareRatioSql)
          .repartition(1200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, compareRatioDF, "循环跑数后的结果数据")

        // 获取传统路线信息
        val leftDF: DataFrame = compareRatioDF
          .filter("data_source2='ct'")
          .withColumnRenamed("coords", "coords_ct")
          .withColumnRenamed("t_coords_xy", "t_coords_xy_ct")
          .withColumnRenamed("t_coords_xy_swid", "t_coords_xy_swid_ct")


        // 获取高德路线信息
        val rightDF: DataFrame = compareRatioDF
          .filter("data_source2='gd'")
          .select("groupby_id", "coords", "t_coords_xy", "t_coords_xy_swid")
          .withColumnRenamed("coords", "coords_gd")
          .withColumnRenamed("t_coords_xy", "t_coords_xy_gd")
          .withColumnRenamed("t_coords_xy_swid", "t_coords_xy_swid_gd")


        val ft_url_value: String = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=" +
          "http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&ak=ebf48ecaa1fd436fa3d40c4600aa051f&x1=113.9213889&y1=22.673595&x2=114.036305&y2=22.638273" +
          "&type=0&cc=1&strategy=0&opt=gd3&vehicle=6&weight=3.0&mload=3.0&height=2.4&axleNumber=2&plate=%E7%B2%A4C5909S&plateColor=1&energy=2&width=2.4" +
          "&size=5.2&passport=100000&tolls=1&test=0&stype=0&etype=2&pathCount=1&fencedist=50&merge=4&fixedroute=2&frequency=1"
        val navidemoDF: DataFrame = leftDF
          .join(rightDF, Seq("groupby_id"))
          .withColumnRenamed("groupby_id", "reqid")
          .withColumnRenamed("t_coords_xy_ct", "ft_coords")
          .withColumnRenamed("t_coords_xy_gd", "gd_coords")
          .withColumnRenamed("coords_ct", "tracks1")
          .withColumnRenamed("coords_gd", "tracks2")
          .withColumnRenamed("d_url", "ft_url")
          .na.fill(ft_url_value, Array("ft_url"))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)


        GetDFCountAndSampleData(logger, navidemoDF, "表十五的数据")
        // 表十五的数据写入hive
        df2HiveByOverwrite(logger, navidemoDF, "dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_navidemo")

        compareRatioDF.unpersist()


        // 解析 json 字段里的数据
        val limitedDF: DataFrame = navidemoDF
          .rdd
          .flatMap(r => {
              val o: JSONObject = row2Json(r)

              val listBuff = new ListBuffer[ListBuffer[JSONObject]]
              val json: String = r.getAs[String]("json")
              val obj: JSONObject = JSON.parseObject(json)
              val summary: JSONObject = obj.getJSONObject("summary")
              val pathArray: JSONArray = summary.getJSONArray("pathArray")

              if (pathArray != null && pathArray.size() > 0) {
                  val path: JSONObject = pathArray.getJSONObject(0)

                  val restriction: String = path.getJSONObject("restriction").toJSONString
                  o.put("restriction", restriction)

                  val avoidLimitReasonArray: JSONArray = path.getJSONArray("avoidLimitReasonArray")
                  if (avoidLimitReasonArray != null && avoidLimitReasonArray.size() > 0) {
                      val point: ListBuffer[JSONObject] = get_avoidLimitReasonArray_data(o, avoidLimitReasonArray)
                      listBuff.append(point)
                  }

                  val forbiddens: JSONArray = path.getJSONArray("forbiddens")
                  if (forbiddens != null && forbiddens.size() > 0) {
                      val point: ListBuffer[JSONObject] = get_forbiddens_data(o, forbiddens)
                      listBuff.append(point)
                  }

                  val incidentsOnPath: JSONArray = path.getJSONArray("incidentsOnPath")
                  if (incidentsOnPath != null && incidentsOnPath.size() > 0) {
                      val point: ListBuffer[JSONObject] = get_incidentsOnPath_data(o, incidentsOnPath)
                      listBuff.append(point)
                  }

                  val incidentsOutOfPath: JSONArray = path.getJSONArray("incidentsOutOfPath")
                  if (incidentsOutOfPath != null && incidentsOutOfPath.size() > 0) {
                      val point: ListBuffer[JSONObject] = get_incidentsOutOfPath_data(o, incidentsOutOfPath)
                      listBuff.append(point)
                  }
              }

              listBuff.flatten
          })
          .coalesce(20)
          .map(o => {

              val code: String = o.getString("code")
              val type_gd: String = o.getString("type_gd")
              val id_gd: String = o.getString("id_gd")
              val wkt: String = o.getString("wkt")
              val pos: String = o.getString("pos")
              val gd_coords: String = o.getString("gd_coords")
              val t_coords_xy_swid_gd: String = o.getString("t_coords_xy_swid_gd")
              val t_coords_xy_swid_ct: String = o.getString("t_coords_xy_swid_ct")

              val t_coords_xy_swid_ct_distnct: String = t_coords_xy_swid_ct
                .split(",")
                .distinct
                .mkString(",")

              o.remove("wkt")

              // 需要返回的字段
              var point_dist: String = "0.00"
              var swid1: String = ""
              var swid2: String = ""
              var swid3: String = ""
              var swid4: String = ""
              var is_in_ct: String = ""
              var wkt2: String = wkt
              var coords_list: String = ""
              var swid_list: String = ""
              var adcode: String = ""
              var links_union_direction: String = ""

              if (type_gd != "incident_out") {
                  if (type_gd != "avoid") {
                      val tp: (Double, Int) = get_min_dist_and_index(pos, gd_coords)
                      point_dist = tp._1.toString
                      val index: Int = tp._2
                      swid1 = get_swid(t_coords_xy_swid_gd, index, -1)
                      swid2 = get_swid(t_coords_xy_swid_gd, index, 0)
                      swid3 = get_swid(t_coords_xy_swid_gd, index, 1)
                      swid4 = get_swid(t_coords_xy_swid_gd, index, 2)

                      val swid: String = Array(swid1, swid2, swid3, swid4).distinct.mkString(",")
                      if (t_coords_xy_swid_ct_distnct.contains(swid)) is_in_ct = "是" else is_in_ct = "否"

                      wkt2 = get_gd_coords_slice(gd_coords, index - 2, index + 3)
                      coords_list = get_gd_coords_slice(gd_coords, index - 4, index + 4)
                      swid_list = get_gd_swid_slice(t_coords_xy_swid_gd, index - 4, index + 4)

                      val point: String = coords_list
                        .replaceAll("LINESTRING", "")
                        .replaceAll("\\(", "")
                        .replaceAll("\\)", "")
                        .replaceAll(",", "|")
                        .replaceAll(" ", ",")

                      val j: JSONObject = call_qm_point_interface(point)
                      val tp2: (String, String, String) = get_adcode_and_links_union_direction(j)
                      adcode = tp2._1
                      links_union_direction = tp2._2

                      val status: String = tp2._3
                      if (status == "0") qm_success_acc.add(1L) else qm_fail_acc.add(1L)

                  } else {
                      // type_gd = "avoid" 时调用qm_point 获取 adcode
                      val point: String = wkt
                        .replaceAll("LINESTRING", "")
                        .replaceAll("\\(", "")
                        .replaceAll("\\)", "")
                        .replaceAll(",", "|")
                        .replaceAll(" ", ",")

                      val j: JSONObject = call_qm_point_interface(point)
                      val tp2: (String, String, String) = get_adcode_and_links_union_direction(j)
                      adcode = tp2._1

                      val status: String = tp2._3
                      if (status == "0") qm_success_acc.add(1L) else qm_fail_acc.add(1L)

                      val links: String = tp2._2
                      val swidBuff: ListBuffer[String] = new ListBuffer[String]
                      if (links != "") {
                          val arr: Array[String] = links.split("\\|")
                          for (i <- arr.indices) {
                              val swid: String = arr(i).split(",")(0)
                              swidBuff.append(swid)
                          }

                          swid_list = swidBuff.mkString(",")
                          swid1 = swidBuff.head
                          swid4 = swidBuff.last
                      }
                  }

              }

              o.put("point_dist", point_dist)
              o.put("swid1", swid1)
              o.put("swid2", swid2)
              o.put("swid3", swid3)
              o.put("swid4", swid4)
              o.put("is_in_ct", is_in_ct)
              o.put("wkt", wkt2)
              o.put("coords_list", coords_list)
              o.put("swid_list", swid_list)
              o.put("adcode", adcode)
              o.put("links_union_direction", links_union_direction)
              o.put("code_limited", code + "_" + type_gd + "_" + id_gd)

              val limited: CompareLimited = get_compare_limitedDF(o)
              limited
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, limitedDF, "表十五的结果数据")
        interStatus2Hive(logger, spark, "qm_url", qm_url, className, qm_success_acc, qm_fail_acc)

        // 表十六的数据写入hive
        df2HiveByOverwrite(logger, limitedDF, "dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_limited")

        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 每条路规避限行内容
    def get_avoidLimitReasonArray_data(o: JSONObject, avoidLimitReasonArray: JSONArray): ListBuffer[JSONObject] = {
        val buff = new ListBuffer[JSONObject]

        val limitPointArray1: JSONObject = avoidLimitReasonArray.getJSONObject(0)
        val limitPointArray: JSONArray = limitPointArray1.getJSONArray("limitPointArray")
        if (limitPointArray != null && limitPointArray.size() > 0) {
            for (i <- 0 until limitPointArray.size()) {
                val arr: JSONObject = limitPointArray.getJSONObject(i)
                val x: String = arr.getJSONObject("pos").getString("x")
                val y: String = arr.getJSONObject("pos").getString("y")

                val pos: String = x + "," + y
                val type_gd: String = "avoid"
                val id_gd: String = arr.getString("id")
                var direction_type_gd: String = arr.getString("type")
                val vehicle_type_gd: String = arr.getString("vehicleType")
                val timedescription_gd: String = arr.getString("timeDescription")
                val roadname_gd: String = arr.getString("roadName")
                val roadnamestring_gd: String = arr.getString("inRoadName")
                val nextroadnamestring_gd: String = arr.getString("outRoadName")
                val limit_gd: String = arr.toJSONString
                var wkt: String = ""

                if (direction_type_gd == "0") direction_type_gd = "255"
                else if (direction_type_gd == "1") direction_type_gd = "255"
                else if (direction_type_gd == "2") direction_type_gd = "256"
                else if (direction_type_gd == "3") direction_type_gd = "0"
                else if (direction_type_gd == "4") direction_type_gd = "1"
                else if (direction_type_gd == "5") direction_type_gd = "2"
                else if (direction_type_gd == "7") direction_type_gd = "4"


                val inCoorArray: JSONArray = arr.getJSONArray("inCoorArray")
                val outCoorArray: JSONArray = arr.getJSONArray("outCoorArray")

                val wktBuff: ArrayBuffer[String] = new ArrayBuffer[String]
                if (inCoorArray != null && inCoorArray.size() > 0) {
                    for (i <- 0 until inCoorArray.size()) {
                        val inCoor: JSONObject = inCoorArray.getJSONObject(i)
                        val x: String = inCoor.getString("x")
                        val y: String = inCoor.getString("y")
                        wktBuff.append(x + " " + y)
                    }
                }

                if (outCoorArray != null && outCoorArray.size() > 0) {
                    for (i <- 0 until outCoorArray.size()) {
                        val inCoor: JSONObject = outCoorArray.getJSONObject(i)
                        val x: String = inCoor.getString("x")
                        val y: String = inCoor.getString("y")
                        wktBuff.append(x + " " + y)
                    }
                }

                if (wktBuff.nonEmpty) {
                    val wkt1: String = wktBuff.mkString(",")
                    wkt = "LINESTRING(" + wkt1 + ")"
                }

                val o1 = new JSONObject()
                o1.fluentPutAll(o)

                o1.put("pos", pos)
                o1.put("type_gd", type_gd)
                o1.put("id_gd", id_gd)
                o1.put("direction_type_gd", direction_type_gd)
                o1.put("vehicle_type_gd", vehicle_type_gd)
                o1.put("timedescription_gd", timedescription_gd)
                o1.put("roadname_gd", roadname_gd)
                o1.put("roadnamestring_gd", roadnamestring_gd)
                o1.put("nextroadnamestring_gd", nextroadnamestring_gd)
                o1.put("limit_gd", limit_gd)
                o1.put("wkt", wkt)

                buff.append(o1)
            }
        }


        buff
    }

    // 每条路闯限行具体内容，（包括点位、道路名称、限制内容）
    def get_forbiddens_data(o: JSONObject, forbiddens: JSONArray): ListBuffer[JSONObject] = {
        val buff = new ListBuffer[JSONObject]

        for (i <- 0 until forbiddens.size()) {
            val forbidden: JSONObject = forbiddens.getJSONObject(i)
            val x: String = forbidden.getJSONObject("pos").getString("x")
            val y: String = forbidden.getJSONObject("pos").getString("y")

            val pos: String = x + "," + y
            val type_gd: String = "forbidden"
            val id_gd: String = forbidden.getString("id")
            val direction_type_gd: String = forbidden.getString("type")
            val vehicle_type_gd: String = forbidden.getString("vehicleType")
            val timedescription_gd: String = forbidden.getString("timeDescription")
            val roadname_gd: String = ""
            val roadnamestring_gd: String = forbidden.getString("roadNameString")
            val nextroadnamestring_gd: String = forbidden.getString("nextRoadNameString")
            val limit_gd: String = forbidden.toJSONString
            val wkt: String = ""

            val o1 = new JSONObject()
            o1.fluentPutAll(o)

            o1.put("pos", pos)
            o1.put("type_gd", type_gd)
            o1.put("id_gd", id_gd)
            o1.put("direction_type_gd", direction_type_gd)
            o1.put("vehicle_type_gd", vehicle_type_gd)
            o1.put("timedescription_gd", timedescription_gd)
            o1.put("roadname_gd", roadname_gd)
            o1.put("roadnamestring_gd", roadnamestring_gd)
            o1.put("nextroadnamestring_gd", nextroadnamestring_gd)
            o1.put("limit_gd", limit_gd)
            o1.put("wkt", wkt)

            buff.append(o1)
        }

        buff
    }

    def get_incidentsOnPath_data(o: JSONObject, incidentsOnPath: JSONArray): ListBuffer[JSONObject] = {
        val buff = new ListBuffer[JSONObject]

        for (i <- 0 until incidentsOnPath.size()) {
            val incidents: JSONObject = incidentsOnPath.getJSONObject(i)
            val x: String = incidents.getJSONObject("pos").getString("x")
            val y: String = incidents.getJSONObject("pos").getString("y")

            val pos: String = x + "," + y
            val type_gd: String = "incident_on"
            val id_gd: String = incidents.getString("id")
            val direction_type_gd: String = incidents.getString("type")
            val vehicle_type_gd: String = ""
            val timedescription_gd: String = ""
            val roadname_gd: String = ""
            val roadnamestring_gd: String = incidents.getString("title")
            val nextroadnamestring_gd: String = ""
            val limit_gd: String = incidents.toJSONString
            val wkt: String = ""

            val o1 = new JSONObject()
            o1.fluentPutAll(o)

            o1.put("pos", pos)
            o1.put("type_gd", type_gd)
            o1.put("id_gd", id_gd)
            o1.put("direction_type_gd", direction_type_gd)
            o1.put("vehicle_type_gd", vehicle_type_gd)
            o1.put("timedescription_gd", timedescription_gd)
            o1.put("roadname_gd", roadname_gd)
            o1.put("roadnamestring_gd", roadnamestring_gd)
            o1.put("nextroadnamestring_gd", nextroadnamestring_gd)
            o1.put("limit_gd", limit_gd)
            o1.put("wkt", wkt)

            buff.append(o1)
        }

        buff
    }

    def get_incidentsOutOfPath_data(o: JSONObject, incidentsOutOfPath: JSONArray): ListBuffer[JSONObject] = {
        val buff = new ListBuffer[JSONObject]

        for (i <- 0 until incidentsOutOfPath.size()) {
            val incidents: JSONObject = incidentsOutOfPath.getJSONObject(i)
            val x: String = incidents.getJSONObject("pos").getString("x")
            val y: String = incidents.getJSONObject("pos").getString("y")

            val pos: String = x + "," + y
            val type_gd: String = "incident_out"
            val id_gd: String = incidents.getString("id")
            val direction_type_gd: String = incidents.getString("type")
            val vehicle_type_gd: String = ""
            val timedescription_gd: String = ""
            val roadname_gd: String = ""
            val roadnamestring_gd: String = incidents.getString("title")
            val nextroadnamestring_gd: String = ""
            val limit_gd: String = incidents.toJSONString
            val wkt: String = ""

            val o1 = new JSONObject()
            o1.fluentPutAll(o)

            o1.put("pos", pos)
            o1.put("type_gd", type_gd)
            o1.put("id_gd", id_gd)
            o1.put("direction_type_gd", direction_type_gd)
            o1.put("vehicle_type_gd", vehicle_type_gd)
            o1.put("timedescription_gd", timedescription_gd)
            o1.put("roadname_gd", roadname_gd)
            o1.put("roadnamestring_gd", roadnamestring_gd)
            o1.put("nextroadnamestring_gd", nextroadnamestring_gd)
            o1.put("limit_gd", limit_gd)
            o1.put("wkt", wkt)

            buff.append(o1)
        }

        buff
    }

    def get_min_dist_and_index(pos: String, gd_coords: String): (Double, Int) = {
        val gd_coordsArr: Array[String] = gd_coords.split(";")
        val posArr: Array[Double] = pos
          .split(",")
          .map(r => r.toDouble)

        val distBuff: ArrayBuffer[(Double, Int)] = new ArrayBuffer[(Double, Int)]
        for (i <- gd_coordsArr.indices) {
            val xyArr: Array[Double] = gd_coordsArr(i)
              .split(",")
              .map(r => r.toDouble)

            val dist: Double = get_distance2(posArr(0), posArr(1), xyArr(0), xyArr(1)) * 1000
            distBuff.append((dist, i))
        }

        val tp: (Double, Int) = distBuff.sortWith(_._1 < _._1)(0)
        tp
    }

    // 获取对应 index 偏移 n 之后的 swid
    def get_swid(t_coords_xy_swid_gd: String, index: Int, n: Int): String = {
        val swidArr: Array[String] = t_coords_xy_swid_gd.split(",")
        var swid: String = ""
        if (index + n > -1 && index + n < swidArr.length) swid = swidArr(index + n) else swid = swidArr(index)
        swid
    }

    // 获取 gd_coords 的切片数据
    def get_gd_coords_slice(gd_coords: String, n: Int, m: Int): String = {
        val gd_coordsArr: Array[String] = gd_coords.split(";")
        val start: Int = math.max(0, n)
        val end: Int = math.min(m, gd_coordsArr.length)
        val gd_coordsStr: String = gd_coordsArr
          .slice(start, end)
          .distinct
          .mkString(";")
          .replaceAll(",", " ")
          .replaceAll(";", ",")

        val wkt: String = "LINESTRING(" + gd_coordsStr + ")"
        wkt
    }

    // 获取 t_coords_xy_swid_gd 的切片数据
    def get_gd_swid_slice(t_coords_xy_swid_gd: String, n: Int, m: Int): String = {
        val swidArr: Array[String] = t_coords_xy_swid_gd.split(",")
        val start: Int = math.max(0, n)
        val end: Int = math.min(m, swidArr.length)
        val swid_list: String = swidArr
          .slice(start, end)
          .mkString(",")

        swid_list
    }

    // 调用 qm_point 接口
    def call_qm_point_interface(point: String): JSONObject = {
        val parm: String = s"points=$point&test=1&stype=0&etype=0&passport=100000&mode=2&speed=1&Toll=1"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        var json: JSONObject = null

        try {
            val jsonStr: String = mapData.get("content").toString
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:" + e.getMessage)
        }

        json
    }

    // 解析 qm_point 接口返回的数据，获取 adcode 和 links_union_direction
    def get_adcode_and_links_union_direction(j: JSONObject): (String, String, String) = {

        var adcode: String = ""
        var links_union_direction: String = ""
        var status: String = ""

        if (j != null) {
            status = j.getString("status")
            if (status == "0") {
                val route: JSONObject = j.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")

                // 获取 adcode、sw_id 字段的值
                val swidBuff: ListBuffer[String] = new ListBuffer[String]
                if (paths != null && paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val path: JSONObject = paths.getJSONObject(i)
                        val steps: JSONArray = path.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            for (k <- 0 until steps.size()) {
                                val step: JSONObject = steps.getJSONObject(k)
                                val links: JSONArray = step.getJSONArray("links")
                                if (links != null && links.size() > 0) {
                                    for (m <- 0 until links.size()) {
                                        val link: JSONObject = links.getJSONObject(m)
                                        adcode = link.getString("adcode")
                                        val sw_id: String = link.getString("sw_id")
                                        swidBuff.append(sw_id)
                                    }
                                }
                            }
                        }
                    }
                }

                // 获取 mainaction 字段的值
                val mainactionBuff: ListBuffer[String] = new ListBuffer[String]
                if (paths != null && paths.size() > 0) {
                    for (i <- 0 until paths.size()) {
                        val path: JSONObject = paths.getJSONObject(i)
                        val outinfo: JSONObject = path.getJSONObject("outinfo")
                        if (outinfo != null && outinfo.size() > 0) {
                            val links: JSONArray = outinfo.getJSONArray("links")
                            if (links != null && links.size() > 0) {
                                for (j <- 0 until links.size()) {
                                    val link: JSONObject = links.getJSONObject(j)
                                    val mainaction: String = link.getString("mainaction")
                                    mainactionBuff.append(mainaction)
                                }
                            }
                        }
                    }
                }

                // 将 sw_id、mainaction拼接起来
                if (swidBuff.nonEmpty && mainactionBuff.nonEmpty) {
                    val n: Int = math.min(swidBuff.size, mainactionBuff.size)

                    val listBuff: ListBuffer[String] = new ListBuffer[String]
                    for (i <- 0 until n) listBuff.append(swidBuff(i) + "," + mainactionBuff(i))

                    links_union_direction = listBuff.mkString("|")
                }

            }
        }

        (adcode, links_union_direction, status)
    }

    // 把MySQL里的数据备份到hive上
    def mysqlToHive(logger: Logger, spark: SparkSession, table: String, start_time: String, end_time: String): Unit = {
        logger.error(s"开始读取MySQL:$table 表中数据")
        val hiveTable: String = "dm_gis." + table
        val df: Dataset[Row] = spark
          .read
          .format("jdbc")
          .option("url", url)
          .option("user", userName)
          .option("password", passWd)
          .option("dbtable", table)
          .option("driver", driver)
          .load()
          .filter(s"inc_day >= '$start_time' and inc_day <'$end_time'")
          .withColumn("incday", col("inc_day"))
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, df, s"$table 表中数据")
        // 存到hive备份
        df2HiveByOverwrite(logger, df, hiveTable)

        df.unpersist()
    }

    // 把循环之后，表八的最终数据存到hive
    def saveToHive(logger: Logger, spark: SparkSession, start_time: String, end_time: String): Unit = {
        logger.error(s"开始读取MySQL:raoxing_waypoints_drop_duplicates_gdapp 表中数据")
        val gdappDF: DataFrame = spark
          .read
          .format("jdbc")
          .option("url", url)
          .option("user", userName)
          .option("password", passWd)
          .option("dbtable", "raoxing_waypoints_drop_duplicates_gdapp")
          .option("driver", driver)
          .load()
          .filter(s"inc_day >= '$start_time' and inc_day <'$end_time'")
          .drop("create_time", "update_time", "request_name")
          .withColumn("incday", col("inc_day"))
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, gdappDF, "循环跑数后表八最终的数据")
        // 存到hive
        df2HiveByOverwrite(logger, gdappDF, "dm_gis.raoxing_waypoints_drop_duplicates_gdapp_after")
        gdappDF.unpersist()
    }

    // 讲最后的结果rdd转df
    def get_compare_limitedDF(o: JSONObject): CompareLimited = {
        val code: String = o.getString("code")
        val limit_gd: String = o.getString("limit_gd")
        val reqid: String = o.getString("reqid")
        val id: Int = o.getInteger("id")
        val code_ratio: String = o.getString("code_ratio")
        val jp_swid: String = o.getString("jp_swid")
        val label: String = o.getString("label")
        val vehicle_type: String = o.getString("vehicle_type")
        val all_data_source: String = o.getString("all_data_source")
        val all_height: String = o.getString("all_height")
        val max_height: String = o.getString("max_height")
        val all_hour: String = o.getString("all_hour")
        val start_dept: String = o.getString("start_dept")
        val end_dept: String = o.getString("end_dept")
        val start_tm: String = o.getString("start_tm")
        val end_tm: String = o.getString("end_tm")
        val round: String = o.getString("round")
        val version: String = o.getString("version")
        val appropriate_waypoints: String = o.getString("appropriate_waypoints")
        val waypoints_swid: String = o.getString("waypoints_swid")
        val from_x: String = o.getString("from_x")
        val from_y: String = o.getString("from_y")
        val to_x: String = o.getString("to_x")
        val to_y: String = o.getString("to_y")
        val waypoint_new: String = o.getString("waypoint_new")
        val via1_x: String = o.getString("via1_x")
        val via1_y: String = o.getString("via1_y")
        val via2_x: String = o.getString("via2_x")
        val via2_y: String = o.getString("via2_y")
        val via3_x: String = o.getString("via3_x")
        val via3_y: String = o.getString("via3_y")
        val model_id: String = o.getString("model_id")
        val data_source_type: String = o.getString("data_source_type")
        val all_avoid_pos_gd: String = o.getString("all_avoid_pos_gd")
        val avoid_dist: String = o.getString("avoid_dist")
        val json: String = o.getString("json")
        val pathcount: String = o.getString("pathcount")
        val forbiddencount: String = o.getString("forbiddencount")
        val avoidlimitreasoncount: String = o.getString("avoidlimitreasoncount")
        val startpoi: String = o.getString("startpoi")
        val endpoi: String = o.getString("endpoi")
        val incidentcountoutofpath: String = o.getString("incidentcountoutofpath")
        val incidentcountonpath: String = o.getString("incidentcountonpath")
        val coords2: String = o.getString("coords2")
        val x1: String = o.getString("x1")
        val y1: String = o.getString("y1")
        val x2: String = o.getString("x2")
        val y2: String = o.getString("y2")
        val waypoints2: String = o.getString("waypoints2")
        val d_status: String = o.getString("d_status")
        val d_dist: String = o.getString("d_dist")
        val ft_url: String = o.getString("ft_url")
        val tracks1: String = o.getString("tracks1")
        val data_source2: String = o.getString("data_source2")
        val uid: String = o.getString("uid")
        val `type`: String = o.getString("type")
        val t_status: String = o.getString("t_status")
        val t_links_union: String = o.getString("t_links_union")
        val t_distance: String = o.getString("t_distance")
        val t_duration: String = o.getString("t_duration")
        val t_highspeed_distance: String = o.getString("t_highspeed_distance")
        val t_trafficlight_count: String = o.getString("t_trafficlight_count")
        val ft_coords: String = o.getString("ft_coords")
        val t_coords_xy_swid_ct: String = o.getString("t_coords_xy_swid_ct")
        val t_linkpointinfo: String = o.getString("t_linkpointinfo")
        val t_origin: String = o.getString("t_origin")
        val t_destination: String = o.getString("t_destination")
        val t_flen: String = o.getString("t_flen")
        val t_tlen: String = o.getString("t_tlen")
        val standard_id: String = o.getString("standard_id")
        val different_num: String = o.getString("different_num")
        val different_dist: String = o.getString("different_dist")
        val different_real_dist: String = o.getString("different_real_dist")
        val different_basic_dist: String = o.getString("different_basic_dist")
        val different_add_dist: String = o.getString("different_add_dist")
        val different_dist_ratio: String = o.getString("different_dist_ratio")
        val different_compare_dist_ratio: String = o.getString("different_compare_dist_ratio")
        val different_weighted_compare_dist_ratio: String = o.getString("different_weighted_compare_dist_ratio")
        val tracks2: String = o.getString("tracks2")
        val restriction: String = o.getString("restriction")
        val t_coords_xy_swid_gd: String = o.getString("t_coords_xy_swid_gd")
        val gd_coords: String = o.getString("gd_coords")
        val pos: String = o.getString("pos")
        val type_gd: String = o.getString("type_gd")
        val id_gd: String = o.getString("id_gd")
        val direction_type_gd: String = o.getString("direction_type_gd")
        val vehicle_type_gd: String = o.getString("vehicle_type_gd")
        val timedescription_gd: String = o.getString("timedescription_gd")
        val roadname_gd: String = o.getString("roadname_gd")
        val roadnamestring_gd: String = o.getString("roadnamestring_gd")
        val nextroadnamestring_gd: String = o.getString("nextroadnamestring_gd")
        val point_dist: String = o.getString("point_dist")
        val swid1: String = o.getString("swid1")
        val swid2: String = o.getString("swid2")
        val swid3: String = o.getString("swid3")
        val swid4: String = o.getString("swid4")
        val is_in_ct: String = o.getString("is_in_ct")
        val wkt: String = o.getString("wkt")
        val coords_list: String = o.getString("coords_list")
        val swid_list: String = o.getString("swid_list")
        val adcode: String = o.getString("adcode")
        val links_union_direction: String = o.getString("links_union_direction")
        val code_limited: String = o.getString("code_limited")
        val inc_day: String = o.getString("inc_day")

        CompareLimited(code, limit_gd, reqid, id, code_ratio, jp_swid, label, vehicle_type, all_data_source, all_height, max_height, all_hour,
            start_dept, end_dept, start_tm, end_tm, round, version, appropriate_waypoints, waypoints_swid, from_x, from_y, to_x, to_y, waypoint_new,
            via1_x, via1_y, via2_x, via2_y, via3_x, via3_y, model_id, data_source_type, all_avoid_pos_gd, avoid_dist, json, pathcount,
            forbiddencount, avoidlimitreasoncount, startpoi, endpoi, incidentcountoutofpath, incidentcountonpath, coords2, x1, y1, x2, y2,
            waypoints2, d_status, d_dist, ft_url, tracks1, data_source2, uid, `type`, t_status, t_links_union, t_distance, t_duration,
            t_highspeed_distance, t_trafficlight_count, ft_coords, t_coords_xy_swid_ct, t_linkpointinfo, t_origin, t_destination, t_flen,
            t_tlen, standard_id, different_num, different_dist, different_real_dist, different_basic_dist, different_add_dist,
            different_dist_ratio, different_compare_dist_ratio, different_weighted_compare_dist_ratio, tracks2, restriction,
            t_coords_xy_swid_gd, gd_coords, pos, type_gd, id_gd, direction_type_gd, vehicle_type_gd, timedescription_gd, roadname_gd,
            roadnamestring_gd, nextroadnamestring_gd, point_dist, swid1, swid2, swid3, swid4, is_in_ct, wkt, coords_list, swid_list, adcode,
            links_union_direction, code_limited, inc_day
        )
    }


    /**
      * 左关联，左表存在少部分key倾斜，采用单独处理部分key的方式
      *
      * @param left    左表
      * @param right   右表
      * @param hashNum 散列系数，扩容倍数
      * @param topLean 需要单独处理的倾斜数据量
      */
    def leftOuterJoinOfLeftLeanElem1(logger: Logger, left: RDD[(String, Row)], right: RDD[(String, Row)], hashNum: Int, topLean: Int = 50): RDD[(String, (Row, Row))] = {
        val keyCounts: Array[(String, Int)] = left
          .map(obj => (obj._1, 1))
          .reduceByKey(_ + _)
          .sortBy(-_._2)
          .take(topLean)

        val keys: Array[String] = keyCounts.map(obj => obj._1)

        val counts: Int = keyCounts.map(obj => obj._2).sum
        logger.error("单独处理的keys:" + keyCounts.mkString(","))
        logger.error("单独处理的总数量:" + counts)
        //拆分数据为独立处理的key和非独立处理的key
        val leftHashKeyData: RDD[(String, Row)] = left.filter(obj => keys.contains(obj._1))
        val leftOtherData: RDD[(String, Row)] = left.filter(obj => !keys.contains(obj._1))
        val rightHashKeyData: RDD[(String, Row)] = right.filter(obj => keys.contains(obj._1))
        val rightOtherData: RDD[(String, Row)] = right.filter(obj => !keys.contains(obj._1))

        //先关联其他key数据
        val otherJoin: RDD[(String, (Row, Row))] = leftOtherData
          .join(rightOtherData)
          .partitionBy(new myPartiton(1200))

        //        val otherJoin: RDD[(String, (Row, Row))] = otherJoin_tmp
        //          .partitionBy(new RangePartitioner(300, otherJoin_tmp))

        //扩展单独处理的数据
        val leftHashKeyDataExpand: RDD[((Int, String), Row)] = leftHashKeyData.map(obj => {
            val hashPrefix: Int = new Random().nextInt(hashNum)
            ((hashPrefix, obj._1), obj._2)
        })

        val rightHashKeyDataExpand: RDD[((Int, String), Row)] = rightHashKeyData
          .flatMap(obj => {
              val dataArray = new ArrayBuffer[((Int, String), Row)]()
              for (i <- 0 until hashNum) {
                  dataArray.append(((i, obj._1), obj._2))
              }
              dataArray.iterator
          })
        //关联数据
        val hashKeyJoin: RDD[(String, (Row, Row))] = leftHashKeyDataExpand
          .join(rightHashKeyDataExpand)
          .map(obj => (obj._1._2, obj._2))
          .partitionBy(new myPartiton(1200))

        //        val hashKeyJoin: RDD[(String, (Row, Row))] = hashKeyJoin_tmp
        //          .partitionBy(new RangePartitioner(300, hashKeyJoin_tmp))


        hashKeyJoin.union(otherJoin)

    }

    class myPartiton(numParts: Int) extends Partitioner {

        override def numPartitions: Int = numParts

        override def getPartition(key: Any): Int = {
            val i: Int = new Random().nextInt(numParts)
            val str: String = i.toString + key
            var num: Int = str.hashCode % numParts
            num = num + (if (num < 0) numParts else 0)
            num
        }

    }

}