package app.detour

import app.runLimited.DealLocusAbnormalDataFromLimited.get_distance2
import app.runLimited.GetRoutePlanDataFromGDAndCTAndJY.interStatus2Hive
import com.alibaba.fastjson.JSONObject
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window, WindowSpec}
import org.apache.spark.sql.functions.{collect_set, concat_ws, lit, monotonically_increasing_id, row_number, split, substring, udf, when}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.HttpClientUtil.getJsonByGet
import utils.SparkConfigUtil

import java.text.SimpleDateFormat
import scala.collection.mutable

/**
 * (临时执行) 已下线
  * 5.按点位聚合
  */
object AggrePoint {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val gd_url: String = config.getString("gd_url")

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 5) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time、current_time、one_month_ago、three_month_ago
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val current_time: String = args(2)
        val one_month_ago: String = args(3)
        val three_month_ago: String = args(4)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"当前任务下发日期：$current_time")
        logger.error(s"1个月之前的日期：$one_month_ago")
        logger.error(s"3个月之前的日期：$three_month_ago")


        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 记录调用高德接口的成功、失败次数
        val gd_success_acc: LongAccumulator = spark.sparkContext.longAccumulator
        val gd_fail_acc: LongAccumulator = spark.sparkContext.longAccumulator

        // 导入隐式转换
        import spark.implicits._


        // 循环跑数结果数据
        val forbidden1Sql: String =
            s"""
               |select
               |  code as code_x,
               |  limit_gd as limit_gd_x,
               |  reqid as reqid,
               |  id as id_x,
               |  code_ratio as code_ratio_x,
               |  jp_swid as jp_swid_x,
               |  label as label_x,
               |  vehicle_type as vehicle_type_x,
               |  all_data_source as all_data_source_x,
               |  all_height as all_height_x,
               |  max_height as max_height_x,
               |  all_hour as all_hour_x,
               |  start_dept as start_dept_x,
               |  end_dept as end_dept_x,
               |  start_tm as start_tm_x,
               |  end_tm as end_tm_x,
               |  `round` as round_x,
               |  version as version_x,
               |  appropriate_waypoints as appropriate_waypoints_x,
               |  waypoints_swid as waypoints_swid_x,
               |  from_x as from_x_x,
               |  from_y as from_y_x,
               |  to_x as to_x_x,
               |  to_y as to_y_x,
               |  waypoint_new as waypoint_new_x,
               |  via1_x as via1_x_x,
               |  via1_y as via1_y_x,
               |  via2_x as via2_x_x,
               |  via2_y as via2_y_x,
               |  via3_x as via3_x_x,
               |  via3_y as via3_y_x,
               |  model_id as model_id_x,
               |  data_source_type as data_source_type_x,
               |  all_avoid_pos_gd as all_avoid_pos_gd_x,
               |  avoid_dist as avoid_dist_x,
               |  json as json_x,
               |  pathCount as pathcount_x,
               |  forbiddenCount as forbiddencount_x,
               |  avoidLimitReasonCount as avoidlimitreasoncount_x,
               |  startPoi as startpoi_x,
               |  endPoi as endpoi_x,
               |  incidentCountOutOfPath as incidentcountoutofpath_x,
               |  incidentCountOnPath as incidentcountonpath_x,
               |  coords2 as coords2_x,
               |  x1 as x1_x,
               |  y1 as y1_x,
               |  x2 as x2_x,
               |  y2 as y2_x,
               |  waypoints2 as waypoints2_x,
               |  d_status as d_status_x,
               |  d_dist as d_dist_x,
               |  ft_url as ft_url_x,
               |  tracks1 as tracks1_x,
               |  data_source2 as data_source2_x,
               |  uid as uid_x,
               |  `type` as type_x,
               |  t_status as t_status_x,
               |  t_links_union as t_links_union_x,
               |  t_distance as t_distance_x,
               |  t_duration as t_duration_x,
               |  t_highspeed_distance as t_highspeed_distance_x,
               |  t_trafficlight_count as t_trafficlight_count_x,
               |  ft_coords as ft_coords_x,
               |  t_coords_xy_swid_ct as t_coords_xy_swid_ct_x,
               |  t_linkpointinfo as t_linkpointinfo_x,
               |  t_origin as t_origin_x,
               |  t_destination as t_destination_x,
               |  t_flen as t_flen_x,
               |  t_tlen as t_tlen_x,
               |  standard_id as standard_id_x,
               |  different_num as different_num_x,
               |  different_dist as different_dist_x,
               |  different_real_dist as different_real_dist_x,
               |  different_basic_dist as different_basic_dist_x,
               |  different_add_dist as different_add_dist_x,
               |  different_dist_ratio as different_dist_ratio_x,
               |  different_compare_dist_ratio as different_compare_dist_ratio_x,
               |  different_weighted_compare_dist_ratio as different_weighted_compare_dist_ratio_x,
               |  tracks2 as tracks2_x,
               |  restriction as restriction_x,
               |  t_coords_xy_swid_gd as t_coords_xy_swid_gd_x,
               |  gd_coords as gd_coords_x,
               |  pos as pos_x,
               |  type_gd as type_gd,
               |  id_gd as id_gd_x,
               |  direction_type_gd as direction_type_gd_x,
               |  vehicle_type_gd as vehicle_type_gd,
               |  timedescription_gd as timedescription_gd,
               |  roadname_gd as roadname_gd_x,
               |  roadnamestring_gd as roadnamestring_gd_x,
               |  nextroadnamestring_gd as road_nextroadnamestring_gd,
               |  point_dist as point_dist_x,
               |  swid1 as swid1_x,
               |  swid2 as swid2_x,
               |  swid3 as swid3_x,
               |  swid4 as swid4_x,
               |  is_in_ct as is_in_ct_x,
               |  wkt as wkt_x,
               |  coords_list as coords_list_x,
               |  swid_list as swid_list_x,
               |  adcode as adcode_x,
               |  links_union_direction as links_union_direction_x,
               |  code_limited as code_limited_x,
               |  inc_day as inc_day_x
               |from
               |  dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_limited
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and type_gd = 'forbidden'
               |  and is_in_ct = '是'
               |""".stripMargin

        // 循环跑数结果数据
        val forbidden2Sql: String =
            s"""
               |select
               |  code as code_y,
               |  limit_gd as limit_gd_y,
               |  reqid as reqid,
               |  id as id_y,
               |  code_ratio as code_ratio_y,
               |  jp_swid as jp_swid_y,
               |  label as label_y,
               |  vehicle_type as vehicle_type_y,
               |  all_data_source as all_data_source_y,
               |  all_height as all_height_y,
               |  max_height as max_height_y,
               |  all_hour as all_hour_y,
               |  start_dept as start_dept_y,
               |  end_dept as end_dept_y,
               |  start_tm as start_tm_y,
               |  end_tm as end_tm_y,
               |  round as round_y,
               |  version as version_y,
               |  appropriate_waypoints as appropriate_waypoints_y,
               |  waypoints_swid as waypoints_swid_y,
               |  from_x as from_x_y,
               |  from_y as from_y_y,
               |  to_x as to_x_y,
               |  to_y as to_y_y,
               |  waypoint_new as waypoint_new_y,
               |  via1_x as via1_x_y,
               |  via1_y as via1_y_y,
               |  via2_x as via2_x_y,
               |  via2_y as via2_y_y,
               |  via3_x as via3_x_y,
               |  via3_y as via3_y_y,
               |  model_id as model_id_y,
               |  data_source_type as data_source_type_y,
               |  all_avoid_pos_gd as all_avoid_pos_gd_y,
               |  avoid_dist as avoid_dist_y,
               |  json as json_y,
               |  pathCount as pathcount_y,
               |  forbiddenCount as forbiddencount_y,
               |  avoidLimitReasonCount as avoidlimitreasoncount_y,
               |  startPoi as startpoi_y,
               |  endPoi as endpoi_y,
               |  incidentCountOutOfPath as incidentcountoutofpath_y,
               |  incidentCountOnPath as incidentcountonpath_y,
               |  coords2 as coords2_y,
               |  x1 as x1_y,
               |  y1 as y1_y,
               |  x2 as x2_y,
               |  y2 as y2_y,
               |  waypoints2 as waypoints2_y,
               |  d_status as d_status_y,
               |  d_dist as d_dist_y,
               |  ft_url as ft_url_y,
               |  tracks1 as tracks1_y,
               |  data_source2 as data_source2_y,
               |  uid as uid_y,
               |  type as type_y,
               |  t_status as t_status_y,
               |  t_links_union as t_links_union_y,
               |  t_distance as t_distance_y,
               |  t_duration as t_duration_y,
               |  t_highspeed_distance as t_highspeed_distance_y,
               |  t_trafficlight_count as t_trafficlight_count_y,
               |  ft_coords as ft_coords_y,
               |  t_coords_xy_swid_ct as t_coords_xy_swid_ct_y,
               |  t_linkpointinfo as t_linkpointinfo_y,
               |  t_origin as t_origin_y,
               |  t_destination as t_destination_y,
               |  t_flen as t_flen_y,
               |  t_tlen as t_tlen_y,
               |  standard_id as standard_id_y,
               |  different_num as different_num_y,
               |  different_dist as different_dist_y,
               |  different_real_dist as different_real_dist_y,
               |  different_basic_dist as different_basic_dist_y,
               |  different_add_dist as different_add_dist_y,
               |  different_dist_ratio as different_dist_ratio_y,
               |  different_compare_dist_ratio as different_compare_dist_ratio_y,
               |  different_weighted_compare_dist_ratio as different_weighted_compare_dist_ratio_y,
               |  tracks2 as tracks2_y,
               |  restriction as restriction_y,
               |  t_coords_xy_swid_gd as t_coords_xy_swid_gd_y,
               |  gd_coords as gd_coords_y,
               |  pos as pos_y,
               |  type_gd as type_gd,
               |  id_gd as id_gd_y,
               |  direction_type_gd as direction_type_gd_y,
               |  vehicle_type_gd as vehicle_type_gd,
               |  timedescription_gd as timedescription_gd,
               |  roadname_gd as roadname_gd_y,
               |  roadnamestring_gd as road_nextroadnamestring_gd,
               |  nextroadnamestring_gd as nextroadnamestring_gd_y,
               |  point_dist as point_dist_y,
               |  swid1 as swid1_y,
               |  swid2 as swid2_y,
               |  swid3 as swid3_y,
               |  swid4 as swid4_y,
               |  is_in_ct as is_in_ct_y,
               |  wkt as wkt_y,
               |  coords_list as coords_list_y,
               |  swid_list as swid_list_y,
               |  adcode as adcode_y,
               |  links_union_direction as links_union_direction_y,
               |  code_limited as code_limited_y,
               |  inc_day as inc_day_y
               |from
               |  dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_limited
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and type_gd = 'forbidden'
               |  and is_in_ct = '是'
               |""".stripMargin

        // 表十六的数据
        val limitedSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_limited
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 近1个月每天下发的数据
        val issueSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.raoxing_daily_issue_data
               |where
               |  inc_day >= '$one_month_ago'
               |  and inc_day < '$start_time'
               |""".stripMargin

        // 近3个月历史核实结果数据
        val checkedSql: String =
            s"""
               |select
               |  pos,
               |  vehicle_type_gd,
               |  timedescription_gd,
               |  roadnamestring_gd,
               |  nextroadnamestring_gd,
               |  direction_type_gd,
               |  work_status,
               |  class_first,
               |  task_tm
               |from
               |  dm_gis.raoxing_zuoye
               |where
               |  inc_day >= '$three_month_ago'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(forbidden1Sql)
        logger.error(forbidden2Sql)
        logger.error(limitedSql)

        // 获取关联的左表
        val forbidden1DF: DataFrame = spark.sql(forbidden1Sql)
        // 获取关联的右表
        val forbidden2DF: DataFrame = spark.sql(forbidden2Sql)
        // 获表十六的数据(原始数据，未命别名)
        val limitedDF: DataFrame = spark.sql(limitedSql)
        // 近1个月下发过的数据
        val issueDF: DataFrame = spark.sql(issueSql)
        // 历史核实结果数据
        val hisCheckResultDF: DataFrame = spark.sql(checkedSql)


        // 数据预处理：筛选、去重、新增字段
        val forbidden3DF: DataFrame = forbidden1DF
          .join(forbidden2DF, Seq("reqid", "vehicle_type_gd", "type_gd", "timedescription_gd", "road_nextroadnamestring_gd"))
          .filter(r => {
              val id_gd_x: String = r.getAs[String]("id_gd_x")
              val id_gd_y: String = r.getAs[String]("id_gd_y")

              var flag: Boolean = false
              if (id_gd_x.toInt == id_gd_y.toInt - 1) flag = true

              flag
          })
          .dropDuplicates(
              Array("reqid", "pos_x", "pos_y", "id_gd_x", "id_gd_y", "vehicle_type_gd", "type_gd",
                  "direction_type_gd_x", "timedescription_gd", "roadname_gd_x", "roadnamestring_gd_x",
                  "road_nextroadnamestring_gd", "roadname_gd_y", "direction_type_gd_y", "nextroadnamestring_gd_y",
                  "swid1_x", "swid2_x", "swid3_x", "swid4_x", "swid1_y", "swid2_y", "swid3_y", "swid4_y", "limit_gd_x", "limit_gd_y"
              )
          )
          .withColumn("group_point_dist", get_dist($"pos_x", $"pos_y"))
          .withColumn("group_type", get_group_type($"roadnamestring_gd_x", $"road_nextroadnamestring_gd", $"nextroadnamestring_gd_y"))
          .withColumn("is_interchange_entry_exit", get_is_interchange_entry_exit($"road_nextroadnamestring_gd"))
          .withColumn("group", get_string(monotonically_increasing_id))
          .repartition(10)
          .withColumn("sdn", get_staus_and_dist_and_steps_num(gd_success_acc, gd_fail_acc)($"reqid", $"pos_x", $"pos_y"))
          .withColumn("group_d_status", $"sdn._1")
          .withColumn("group_d_dist", $"sdn._2")
          .withColumn("group_d_steps_num", $"sdn._3")
          .withColumn("inc_day", $"inc_day_x")
          .drop("sdn", "inc_day_x", "inc_day_y")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, forbidden3DF, "数据预处理过后的数据")
        interStatus2Hive(logger, spark, "gd_url", gd_url, className, gd_success_acc, gd_fail_acc)

        // 最终的数据写入 hive (表十七)
        df2HiveByOverwrite(logger, forbidden3DF, "dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_limited_group")

        // 筛选符合条件的数据
        val limitedFinalDF: DataFrame = limitedDF
          .filter(r => {
              val flag: Boolean = get_flag(r)
              flag
          })
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, limitedFinalDF, "筛选过后的闯行数据")

        // 最终的数据写入 hive (表十九)
        df2HiveByOverwrite(logger, limitedFinalDF, "dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_limited_final")

        //
        val w1: WindowSpec = Window
          .partitionBy("pos", "vehicle_type_gd", "timedescription_gd",
              "roadnamestring_gd", "nextroadnamestring_gd", "direction_type_gd")
          .orderBy($"type_gd_rn".asc)

        val leftDF: DataFrame = limitedFinalDF
          .withColumn("type_gd_rn",
              when($"type_gd" === "forbidden", 1)
                .when($"type_gd" === "incident_on", 2)
                .when($"type_gd" === "incident_out", 3)
                .when($"type_gd" === "avoid", 4)
          )
          .withColumn("rn", row_number().over(w1))
          .filter("rn = 1")
          .drop("type_gd_rn", "rn")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, leftDF, "闯行数据去重之后的数据")
        df2HiveByOverwrite(logger, leftDF, "dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_limited_group_distinct")


        val rightDF1: Dataset[Row] = forbidden3DF
          .filter(r => {
              var flag: Boolean = false

              val group_d_status: String = r.getAs[String]("group_d_status")
              val group_d_dist: String = r.getAs[String]("group_d_dist")
              val group_d_steps_num: String = r.getAs[String]("group_d_steps_num")
              val group_type: String = r.getAs[String]("group_type")
              val is_interchange_entry_exit: String = r.getAs[String]("is_interchange_entry_exit")

              if (group_d_status == "0" && group_d_dist.toDouble < 1000.00 && group_d_steps_num.toInt == 1) {
                  if (group_type == "AAAA" || group_type == "ABBB") flag = true
                  else if (is_interchange_entry_exit == "是") flag = true
              }

              flag
          })
          .selectExpr(
              "pos_x                as pos",
              "type_gd                      as type_gd",
              "vehicle_type_gd              as vehicle_type_gd",
              "direction_type_gd_x          as direction_type_gd",
              "timedescription_gd           as timedescription_gd",
              "roadnamestring_gd_x          as roadnamestring_gd",
              "road_nextroadnamestring_gd   as nextroadnamestring_gd",
              "swid1_x                      as swid1",
              "swid2_x                      as swid2",
              "swid3_x                      as swid3",
              "swid4_x                      as swid4",
              "group                        as group"
          )

        val rightDF2: Dataset[Row] = forbidden3DF
          .filter(r => {
              var flag: Boolean = false

              val group_d_status: String = r.getAs[String]("group_d_status")
              val group_d_dist: String = r.getAs[String]("group_d_dist")
              val group_d_steps_num: String = r.getAs[String]("group_d_steps_num")
              val group_type: String = r.getAs[String]("group_type")
              val is_interchange_entry_exit: String = r.getAs[String]("is_interchange_entry_exit")

              if (group_d_status == "0" && group_d_dist.toDouble < 1000.00 && group_d_steps_num.toInt == 1) {
                  if (group_type == "AAAA" || group_type == "ABBB") flag = true
                  else if (is_interchange_entry_exit == "是") flag = true
              }

              flag
          })
          .selectExpr(
              "pos_y                as pos",
              "type_gd                      as type_gd",
              "vehicle_type_gd              as vehicle_type_gd",
              "direction_type_gd_y          as direction_type_gd",
              "timedescription_gd           as timedescription_gd",
              "road_nextroadnamestring_gd   as roadnamestring_gd",
              "nextroadnamestring_gd_y      as nextroadnamestring_gd",
              "swid1_y                      as swid1",
              "swid2_y                      as swid2",
              "swid3_y                      as swid3",
              "swid4_y                      as swid4",
              "group                        as group"
          )

        val groupDF: DataFrame = rightDF1
          .union(rightDF2)
          .join(leftDF, Seq("pos", "type_gd", "vehicle_type_gd", "direction_type_gd", "timedescription_gd",
              "roadnamestring_gd", "nextroadnamestring_gd", "swid1", "swid2", "swid3", "swid4")
          )
          .groupBy("pos", "vehicle_type_gd", "timedescription_gd", "roadnamestring_gd", "nextroadnamestring_gd", "direction_type_gd")
          .agg(concat_ws("|", collect_set("group")).alias("group2"))
          .join(leftDF, Seq("pos", "vehicle_type_gd", "timedescription_gd", "roadnamestring_gd", "nextroadnamestring_gd", "direction_type_gd"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, groupDF, "添加group之后的数据")


        // 第二次过滤
        val df: DataFrame = groupDF
          .join(hisCheckResultDF, Seq("pos", "vehicle_type_gd", "timedescription_gd", "roadnamestring_gd", "nextroadnamestring_gd", "direction_type_gd"), "left")
          .withColumn("flag_and_is_send", mark_flag($"work_status", $"class_first", $"task_tm", lit(current_time)))
          .withColumn("flag", split($"flag_and_is_send", "_")(0))
          .withColumn("is_send", split($"flag_and_is_send", "_")(1))
          .drop("flag_and_is_send", "work_status", "class_first")
          .persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, df, "第二次过滤的中间临时数据")

        val aggrLimitedSeconrdFilterHisDS1: DataFrame = df
          .filter("flag = '1'")
          .filter("is_send = '1'")
          .drop("flag", "is_send")

        val aggrLimitedSeconrdFilterHisDS2: DataFrame = df
          .filter("is_send = '0'")
          .drop("flag", "is_send")

        // 第三次过滤：过滤最近已经下发过的数据
        val aggrLimitedThreeFilterHisDF: DataFrame = aggrLimitedSeconrdFilterHisDS2
          .join(issueDF, Seq("pos", "vehicle_type_gd", "timedescription_gd", "roadnamestring_gd", "nextroadnamestring_gd", "direction_type_gd"), "leftanti")
          .union(aggrLimitedSeconrdFilterHisDS1)
          .withColumn("task_tm", lit(current_time))
          .withColumn("task_mark", lit("0"))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, aggrLimitedThreeFilterHisDF, "第三次过滤后的数据量")

        // 每日最终下发的数据
        df2HiveByOverwrite(logger, aggrLimitedThreeFilterHisDF, "dm_gis.raoxing_daily_issue_data")


        val aggrLimitedThreeFilterHisDF2: DataFrame = aggrLimitedThreeFilterHisDF
          .withColumn("type_gd",
              when($"type_gd" === "forbidden", "规制")
                .when($"type_gd" === "incident_on", "事件")
                .when($"type_gd" === "avoid", "规避的规制")
          )
          .withColumn("direction_type_gd",
              when($"direction_type_gd" === "0", "左转")
                .when($"direction_type_gd" === "1", "右转")
                .when($"direction_type_gd" === "2", "调头")
                .when($"direction_type_gd" === "4", "直行")
          )
          .withColumn("vehicle_type_gd",
              when($"vehicle_type_gd" === "4", "微型货车")
                .when($"vehicle_type_gd" === "8", "轻型货车")
                .when($"vehicle_type_gd" === "12", "小型货车")
                .when($"vehicle_type_gd" === "16", "中型货车")
                .when($"vehicle_type_gd" === "32", "重型货车")
                .when($"vehicle_type_gd" === "48", "大型货车")
                .when($"vehicle_type_gd" === "56", "轻型|中型|重型")
                .when($"vehicle_type_gd" === "60", "所有货车")
          )
          .withColumnRenamed("pos", "rulepos")
          .withColumnRenamed("swid1", "ruleroadid")
          .withColumnRenamed("swid4", "ruleoutroadid")
          .withColumnRenamed("vehicle_type_gd", "limitvehicletype")
          .withColumnRenamed("timedescription_gd", "limitwidth")
          .withColumnRenamed("roadnamestring_gd", "limitaxload")
          .withColumnRenamed("nextroadnamestring_gd", "limitaxcnt")
          .withColumnRenamed("direction_type_gd", "limitsize")
          .withColumnRenamed("group2", "ruleid")
          .withColumnRenamed("wkt", "pline")
          .withColumnRenamed("type_gd", "ruletype")
          .withColumn("freqcnt", lit(0))
          .withColumn("gd_freqcnt", lit(0))
          .withColumn("vehiclecnt", lit(0))
          .withColumn("limitweight", lit(""))
          .withColumn("limitload", lit(""))
          .withColumn("limitpassport", lit(""))
          .withColumn("limitholiday", lit(""))
          .withColumn("limitoutflag", lit(""))
          .withColumn("limitemitstand", lit(""))
          .withColumn("limittailchar", lit(""))
          .withColumn("limitstartdate", lit(""))
          .withColumn("limitenddate", lit(""))
          .withColumn("limitweek", lit(""))
          .withColumn("limittime", lit(""))
          .withColumn("ruleregiondesc", lit(""))
          .withColumn("data_source", lit(""))
          .withColumn("height", lit(0.00))
          .withColumn("width", lit(0.00))
          .withColumn("vehicle_length", lit(""))
          .withColumn("vehicle_full_load_weight", lit(""))
          .withColumn("vehicle_load_weight", lit(0.00))
          .withColumn("axls_number", lit(""))
          .withColumn("vehicle_serial_head2", lit(""))
          .withColumn("energy", lit(""))
          .withColumn("color", lit(""))
          .withColumn("vehicle_serial_last2", lit(""))
          .withColumn("emission", lit(""))
          .withColumn("guid", lit(""))
          .withColumn("sample_batch", lit(""))
          .withColumn("city", lit(""))
          .withColumn("area_code", substring($"adcode",1,4))
          .withColumn("rtk",
              concat_ws("_",$"rulepos", $"ruleroadid", $"ruleoutroadid", $"ruletype",
                  $"limitweight", $"limitsize", $"limitwidth", $"limitaxload", $"limitload",
                  $"limitaxcnt", $"limitpassport", $"limitholiday", $"limitoutflag", $"limitemitstand",
                  $"limitweek", $"limittime")
          )
          .select("rtk","ruleid","rulepos","freqcnt","gd_freqcnt","ruleroadid","ruleoutroadid","ruletype","vehiclecnt","vehicle_type",
              "limitweight","limitsize","limitwidth","limitaxload","limitload","limitaxcnt","limitvehicletype","limitpassport","limitholiday",
              "limitoutflag","limitemitstand","limittailchar","limitstartdate","limitenddate","limitweek","limittime","ruleregiondesc",
              "data_source","height","width","vehicle_length","vehicle_full_load_weight","vehicle_load_weight","axls_number","vehicle_serial_head2",
              "energy","color","vehicle_serial_last2","emission","adcode","pline","guid","sample_batch","city","task_tm","task_mark","area_code","version","incday")

        // 每日最终下发的数据
        df2HiveByOverwrite(logger, aggrLimitedThreeFilterHisDF2, "dm_gis.raoxing_daily_issue_data2")


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 计算 pos_x 到 pos_y 的距离
    def get_dist: UserDefinedFunction = udf((pos_x: String, pos_y: String) => {
        val x_lng: Double = pos_x.split(",")(0).toDouble
        val x_lat: Double = pos_x.split(",")(1).toDouble

        val y_lng: Double = pos_y.split(",")(0).toDouble
        val y_lat: Double = pos_y.split(",")(1).toDouble

        val d: Double = get_distance2(x_lng, x_lat, y_lng, y_lat) * 1000
        d.toString
    })

    // 根据 roadNameString_gd_x、road_nextroadnamestring_gd、nextRoadNameString_gd_y 返回组类型
    def get_group_type: UserDefinedFunction = udf((roadnamestring_gd_x: String, road_nextroadnamestring_gd: String, nextroadnamestring_gd_y: String) => {
        var group_type: String = ""

        if (roadnamestring_gd_x == road_nextroadnamestring_gd && road_nextroadnamestring_gd == nextroadnamestring_gd_y) group_type = "AAAA"
        else if (roadnamestring_gd_x == road_nextroadnamestring_gd && road_nextroadnamestring_gd != nextroadnamestring_gd_y) group_type = "AAAB"
        else if (roadnamestring_gd_x != road_nextroadnamestring_gd && road_nextroadnamestring_gd == nextroadnamestring_gd_y) group_type = "ABBB"
        else if (roadnamestring_gd_x == nextroadnamestring_gd_y && roadnamestring_gd_x != road_nextroadnamestring_gd) group_type = "ABBA"
        else if (roadnamestring_gd_x != road_nextroadnamestring_gd && road_nextroadnamestring_gd != nextroadnamestring_gd_y) group_type = "ABBC"
        else if (roadnamestring_gd_x == "" && road_nextroadnamestring_gd != nextroadnamestring_gd_y) group_type = "BBC"
        else if (roadnamestring_gd_x != road_nextroadnamestring_gd && nextroadnamestring_gd_y == "") group_type = "ABB"

        group_type
    })

    // 根据 road_nextroadnamestring_gd 判断 立交、出入口
    def get_is_interchange_entry_exit: UserDefinedFunction = udf((road_nextroadnamestring_gd: String) => {
        var is_interchange_entry_exit: String = "否"

        if (road_nextroadnamestring_gd.contains("立交")) is_interchange_entry_exit = "是"
        else if (road_nextroadnamestring_gd.contains("入口")) is_interchange_entry_exit = "是"
        else if (road_nextroadnamestring_gd.contains("出口")) is_interchange_entry_exit = "是"

        is_interchange_entry_exit
    })

    // 调用高德API获取 group_d_status、group_d_dist、group_d_steps_num
    def get_staus_and_dist_and_steps_num(gd_success_acc: LongAccumulator, gd_fail_acc: LongAccumulator): UserDefinedFunction = udf((reqid: String, pos_x: String, pos_y: String) => {
        val x_lng: String = pos_x.split(",")(0)
        val x_lat: String = pos_x.split(",")(1)

        val y_lng: String = pos_y.split(",")(0)
        val y_lat: String = pos_y.split(",")(1)

        val reqid2: String = reqid
          .replaceAll("&", "_")
          .replaceAll("\\|", "_")

        val url: String = gd_url + s"No=$reqid2&x1=$x_lng&y1=$x_lat&x2=$y_lng&y2=$y_lat&ak=f086106db05b48e6b8cb103ead38d06a"
        val jsonData: JSONObject = getJsonByGet(url = url, 6, "utf-8")


        var group_d_status, group_d_dist: String = ""
        var group_d_steps_num: Int = 0

        if (jsonData != null) {
            group_d_status = jsonData.getString("status")
            if (group_d_status == "0") {
                gd_success_acc.add(1L)
                val result: JSONObject = jsonData.getJSONObject("result")
                group_d_dist = result.getString("dist")
                group_d_steps_num = result.getJSONArray("steps").size()
            }
        } else gd_fail_acc.add(1L)

        (group_d_status, group_d_dist, group_d_steps_num.toString)

    })

    // 把所有类型的字段转换为string类型
    def get_string: UserDefinedFunction = udf((X: Any) => {
        X.toString
    })

    // 通过几个字段判断某行数据的flag值
    def get_flag(r: Row): Boolean = {
        var flag: Boolean = false

        val type_gd: String = r.getAs[String]("type_gd")
        val vehicle_type_gd: String = r.getAs[String]("vehicle_type_gd")
        val is_in_ct: String = r.getAs[String]("is_in_ct")
        val point_dist: String = r.getAs[String]("point_dist")
        val direction_type_gd: String = r.getAs[String]("direction_type_gd")
        val links_union_direction: String = r.getAs[String]("links_union_direction")
        val roadnamestring_gd: String = r.getAs[String]("roadnamestring_gd")
        val nextroadnamestring_gd: String = r.getAs[String]("nextroadnamestring_gd")
        val code: String = r.getAs[String]("code")
        val pos: String = r.getAs[String]("pos")

        // 条件一
        if (type_gd == "forbidden" && vehicle_type_gd != "255" && is_in_ct == "是"
          && point_dist.toDouble <= 100.00 && direction_type_gd != "1") {
            flag = true
        } // 条件二
        else if (type_gd == "forbidden" && vehicle_type_gd != "255" && is_in_ct == "是"
          && point_dist.toDouble <= 100.00 && direction_type_gd == "1") {

            val mainactionSet: mutable.HashSet[String] = new mutable.HashSet[String]()
            if (links_union_direction.nonEmpty) {
                val linkArr: Array[String] = links_union_direction.split("\\|")
                for (i <- linkArr.indices) {
                    val mainaction: String = linkArr(i).split(",")(1)
                    mainactionSet.add(mainaction)
                }
            }

            var mainaction_flag: Boolean = true
            if (mainactionSet.size == 1 && (mainactionSet.contains("0") || mainactionSet.contains("8"))) mainaction_flag = false
            else if (mainactionSet.size == 2 && (mainactionSet.contains("0") && mainactionSet.contains("8"))) mainaction_flag = false

            if (!roadnamestring_gd.contains("入口") && !roadnamestring_gd.contains("出口") && roadnamestring_gd != nextroadnamestring_gd &&
              mainaction_flag) flag = false else flag = true
        } // 条件三
        else if (type_gd == "incident_on" && is_in_ct == "是" && point_dist.toDouble <= 100.00 && roadnamestring_gd.contains("封路")) {
            flag = true
        } // 条件四
        else if (code.contains("|") && type_gd == "avoid" && vehicle_type_gd != "255" && vehicle_type_gd != "256") {
            val codeArr: Array[String] = code.split("\\|")
            if (codeArr.last == pos) flag = true
        }

        flag
    }

    // 通过几个字段判断某行数据的flag值
    def mark_flag: UserDefinedFunction = udf((work_status: String, class_first: String, task_tm: String, current_time: String) => {
        // flag 标识这个条数据是否应该下发，true 1→ 下发   false 0→ 不下发
        // is_send = true 表示已经下发过，默认都没下发过,true 1→ 已经下发过  false 0 →  未下发过
        var flag: String = "0"
        var is_send: String = "1"
        val class_first_list: List[String] = List("路段规制缺失", "路段规制冗余", "路段规制信息错误",
            "路口禁止信息缺失", "路口禁止信息冗余", "路口禁止信息错误")

        if (task_tm == null) {
            /*
            没有关联上的数据，分2种情况：
            1、这条数据从来都没有下发过
            2、这条数据之前下发过，但是核实结果还没有推送过来
             */
            flag = "1"
            is_send = "0"
        }
        else {
            // 能关联上的数据，说明之前已经下发过
            val fm = new SimpleDateFormat("yyyyMMdd")
            val task_tm_timestamp: Long = fm.parse(task_tm).getTime
            val current_time_timestamp: Long = fm.parse(current_time).getTime
            val d: Long = (current_time_timestamp - task_tm_timestamp) / (1000 * 3600 * 24)


            if ((work_status == "5" || work_status == "6") && d == 60) flag = "1"
            else if (work_status == "2" && class_first_list.contains(class_first) && d == 30) flag = "1"
            else if (work_status == "2" && !class_first_list.contains(class_first) && d == 30) flag = "1"
            else if ((work_status == "4" || work_status == "3") && d == 15) flag = "1"
        }

        flag + "_" + is_send
    })

}
