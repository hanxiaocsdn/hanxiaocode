package app.detour

import app.runLimited.GetIsBuildingIndiccatorData.call_road_attr_inter
import com.alibaba.fastjson.{JSONArray, JSONObject}
import entry.RoutePoint
import org.apache.spark.sql.functions.{concat_ws, lit}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.SparkConfigUtil

import java.sql.{Connection, PreparedStatement}
import scala.collection.mutable
import scala.collection.mutable.ListBuffer


/**
  * 3 筛选初始化绕行段 & 选取途径点
  */
object FilerDetourLineAndAddPoint {

    // mysql的参数
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://plan-m.db.sfcloud.local:3306/other"
    val userName = "other"
    val passWd = "other20211227#"

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 导入隐式转换
        import spark.implicits._

        // 获取multi数据
        val multiSql: String =
            s"""
               |select
               |  t.*,
               |  case
               |  when hour2 >= 0 and hour2 < 6 then '1'
               |  when hour2 >= 6 and hour2 < 7 then '2'
               |  when hour2 >= 7 and hour2 < 9 then '3'
               |  when hour2 >= 9 and hour2 < 10 then '4'
               |  when hour2 >= 10 and hour2 < 11 then '5'
               |  when hour2 >= 11 and hour2 < 13 then '6'
               |  when hour2 >= 13 and hour2 < 16 then '7'
               |  when hour2 >= 16 and hour2 < 17 then '8'
               |  when hour2 >= 17 and hour2 < 18 then '9'
               |  when hour2 >= 18 and hour2 < 19 then '10'
               |  when hour2 >= 19 and hour2 < 20 then '11'
               |  when hour2 >= 20 and hour2 < 21 then '12'
               |  when hour2 >= 21 and hour2 < 22 then '13'
               |  when hour2 >= 22 and hour2 < 23 then '14'
               |  when hour2 >= 23 and hour2 < 24 then '15'
               |  else '1'
               |  end as label
               |from
               |(
               |	select
               |      *,
               |	  different_dist / different_compare_dist_ratio                 as different_dist_basic,
               |	  if(
               |		  cast(split(split(start_tm,' ')[1],':')[1] as int)<30,
               |		  cast(split(split(start_tm,' ')[1],':')[0] as int),
               |		  cast(split(split(start_tm,' ')[1],':')[0] as int)+1
               |	   )                                                            as hour,
               |    cast(split(split(start_tm,' ')[1],':')[0] as int)               as hour2
               |	from
               |	  dm_gis.raoxing_union_multi
               |	where
               |	  split(standard_id,'_')[2] = '1'
               |	  and different_dist > 0.00
               |      and different_compare_dist_ratio != 0.00
               |	  and !((different_start_swid = '' or different_end_swid = '') and different_dist / different_compare_dist_ratio <= 500.00)
               |	  and !((different_start_line_dist < 200.00 or different_end_line_dist < 200.00) and different_dist / different_compare_dist_ratio <= 500.00)
               |	  and different_compare_dist_ratio > 1.30
               |	  and different_weighted_compare_dist_ratio > 1.00
               |	  and inc_day >= '$start_time'
               |	  and inc_day < '$end_time'
               |) t
               |""".stripMargin

        // 获取ratio数据
        val ratioSql: String =
            s"""
               |select
               |  uid               as standard_id,
               |  t_coords_xy       as t_coords_xy_ct,
               |  t_coords_xy_swid  as t_coords_xy_swid_ct
               |from
               |  dm_gis.raoxing_union_ratio
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(multiSql)
        logger.error(ratioSql)

        // 获取multi数据
        val multiDF: DataFrame = spark
          .sql(multiSql)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, multiDF, "multi数据")

        // 获取ratio数据
        val ratioDF: DataFrame = spark
          .sql(ratioSql)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, ratioDF, "ratio数据")

        val multiAndRatioDF: DataFrame = multiDF
          .join(ratioDF, Seq("standard_id"))
          .withColumn("uid_new", concat_ws("_", $"uid", $"standard_id", $"different_route_id"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, multiAndRatioDF, "multiAndRatioDF数据")
        multiDF.unpersist()
        ratioDF.unpersist()

        // 截取绕行段对应的传统路线
        val multiAndRatioDF2: DataFrame = multiAndRatioDF
          .map(r => {
              val uid_new: String = r.getAs[String]("uid_new")
              val t_coords_xy_ct: String = r.getAs[String]("t_coords_xy_ct")
              val t_coords_xy_swid_ct: String = r.getAs[String]("t_coords_xy_swid_ct")
              val different_start_swid: String = r.getAs[String]("different_start_swid")
              val different_end_swid: String = r.getAs[String]("different_end_swid")

              var jp_tracks = ""
              var jp_swid = ""
              if (t_coords_xy_ct.nonEmpty) {
                  val tp: (String, String) = get_jp_tracks_and_swid(t_coords_xy_ct, t_coords_xy_swid_ct, different_start_swid, different_end_swid)
                  jp_tracks = tp._1
                  jp_swid = tp._2
              }

              (uid_new, jp_tracks, jp_swid)
          })
          .toDF("uid_new", "jp_tracks", "jp_swid")
          .filter("jp_swid != ''")

        // 关联上原始数据
        val multiAndRatioDF3: DataFrame = multiAndRatioDF
          .join(multiAndRatioDF2, Seq("uid_new"))
          .withColumn("code", concat_ws("_", $"uid_new", $"vehicle_type", $"label"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, multiAndRatioDF3, "获得的jp_tracks、jp_swid 数据")


        // 临时去重表
        val multiAndRatioDropDupDF: DataFrame = multiAndRatioDF3
          .select("jp_swid", "vehicle_type", "label", "code")
          .dropDuplicates("jp_swid", "vehicle_type", "label")
          .withColumnRenamed("code", "drop_duplicates_code")

        // 表六（总表）
        val waypointsDF: DataFrame = multiAndRatioDF3
          .join(multiAndRatioDropDupDF, Seq("jp_swid", "vehicle_type", "label"))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .repartition(200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, waypointsDF, "表六的数据")
        multiAndRatioDF3.unpersist()

        // 表六写入到hive
        df2HiveByOverwrite(logger, waypointsDF, "dm_gis.raoxing_waypoints_all")


        // 在waypoints基础上新增几个聚合字段
        val waypointsDF2: DataFrame = waypointsDF
          .rdd
          .map(r => {
              val jp_swid: String = r.getAs[String]("jp_swid")
              val vehicle_type: Int = r.getAs[Int]("vehicle_type")
              val label: String = r.getAs[String]("label")
              ((jp_swid, vehicle_type, label), r)
          })
          .groupByKey()
          .map(r => {
              val (jp_swid, vehicle_type, label) = r._1
              val lists: List[Row] = r._2.toList

              val startTableNumSet: mutable.HashSet[Int] = new mutable.HashSet[Int]()
              val allDataSourceSet: mutable.HashSet[String] = new mutable.HashSet[String]()
              val allHeightSet: mutable.HashSet[Double] = new mutable.HashSet[Double]()
              val allHourSet: mutable.HashSet[String] = new mutable.HashSet[String]()

              for (i <- lists.indices) {
                  val r: Row = lists(i)
                  val data_source: String = r.getAs[String]("data_source")
                  val height: Double = r.getAs[Double]("height")
                  val hour: String = r.getAs[String]("start_tm")

                  if (data_source == "0") startTableNumSet.add(i)
                  allDataSourceSet.add(data_source)
                  allHeightSet.add(height)
                  allHourSet.add(hour)
              }

              (jp_swid, vehicle_type, label, startTableNumSet.size, allDataSourceSet.mkString("|"), allHeightSet.mkString("|"), allHeightSet.max, allHourSet.mkString("|"), "1")

          })
          .toDF("jp_swid", "vehicle_type", "label", "start_table_num", "all_data_source", "all_height", "max_height", "all_hour", "round")
          .repartition(300)

        // 表七
        val waypointsAndDropDF: DataFrame = waypointsDF
          .filter("code = drop_duplicates_code")
          .join(waypointsDF2, Seq("jp_swid", "vehicle_type", "label"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, waypointsAndDropDF, "表七的数据")

        val waypointsAndDropDF2: DataFrame = waypointsAndDropDF
          .repartition(5)
          .map(r => {
              val code: String = r.getAs[String]("code")
              val jp_swid: String = r.getAs[String]("jp_swid")
              val jp_tracks: String = r.getAs[String]("jp_tracks")
              val vehicle_type: Int = r.getAs[Int]("vehicle_type")

              val point: RoutePoint = get_rote_points(code, jp_swid, jp_tracks, vehicle_type)
              point
          })
          .repartition(300)
          .toDF
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, waypointsAndDropDF2, "添加的途经点")

        val waypoints_drop_duplicates_gdapp: DataFrame = waypointsAndDropDF
          .join(waypointsAndDropDF2, Seq("code"))
          .withColumn("is_send", lit(0))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .repartition(200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, waypoints_drop_duplicates_gdapp, "最终的数据")

        //写入到hive
        df2HiveByOverwrite(logger, waypoints_drop_duplicates_gdapp, "dm_gis.raoxing_waypoints_drop_duplicates_gdapp")

        // 写入到MySQL
        logger.error("开始写入到MySQL：raoxing_waypoints_drop_duplicates_gdapp")
        gdappToMysql(waypoints_drop_duplicates_gdapp)
        logger.error("写入MySQL成功！")


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()


    }

    // 截取绕行段的传统路线
    def get_jp_tracks_and_swid(t_coords_xy_ct: String, t_coords_xy_swid_ct: String, different_start_swid: String, different_end_swid: String): (String, String) = {

        val xyArr: Array[String] = t_coords_xy_ct.split(";", -1)
        val swidArr: Array[String] = t_coords_xy_swid_ct.split(",", -1)

        var jp_tracks: String = ""
        var jp_swid: String = ""
        if (different_start_swid == "" && different_end_swid == "") {
            jp_tracks = xyArr.mkString(";")
            jp_swid = swidArr.mkString(",")
        } else if (different_start_swid == "" && different_end_swid != "") {
            val index2: Int = swidArr.indexOf(different_end_swid)
            val n: Int = math.min(index2 + 6, swidArr.length)
            jp_tracks = xyArr.slice(0, n).mkString(";")
            jp_swid = swidArr.slice(0, n).mkString(",")
        } else if (different_start_swid != "" && different_end_swid == "") {
            val index1: Int = swidArr.indexOf(different_start_swid)
            val m: Int = math.max(index1 - 5, 0)
            jp_tracks = xyArr.slice(m, xyArr.length).mkString(";")
            jp_swid = swidArr.slice(m, xyArr.length).mkString(",")
        } else if (different_start_swid != "" && different_end_swid != "") {
            val index1: Int = swidArr.indexOf(different_start_swid)
            val index2: Int = swidArr.indexOf(different_end_swid)
            if (index1 < index2) {
                val m: Int = math.max(index1 - 5, 0)
                val n: Int = math.min(index2 + 6, swidArr.length)
                jp_tracks = xyArr.slice(m, n).mkString(";")
                jp_swid = swidArr.slice(m, n).mkString(",")
            }
        }

        (jp_tracks, jp_swid)
    }

    // 筛选核实的途经点
    def get_rote_points(code: String, jp_swid: String, jp_tracks: String, vehicle_type: Int): RoutePoint = {

        val jp_swidArr: Array[String] = jp_swid.split(",")
        val jp_tracksArr: Array[String] = jp_tracks.split(";")

        val from_x: String = jp_tracksArr.head.split(",", -1)(0)
        val from_y: String = jp_tracksArr.head.split(",", -1)(1)
        val to_x: String = jp_tracksArr.last.split(",", -1)(0)
        val to_y: String = jp_tracksArr.last.split(",", -1)(1)

        var model_id: String = "1"
        if (vehicle_type == 6) model_id = "2"
        else if (vehicle_type == 7) model_id = "3"
        else if (vehicle_type == 4 || vehicle_type == 8) model_id = "4"

        // 存放不需要的swid对应的index集合
        val indexSet: mutable.HashSet[Int] = new mutable.HashSet[Int]
        for (i <- jp_swidArr.indices) {
            val obj: JSONObject = call_road_attr_inter(jp_swidArr(i))

            var formway: Int = 0
            var inMaatSize: Int = 0
            var outMaatSize: Int = 0
            if (obj != null && !obj.isEmpty) {
                val line: JSONObject = obj.getJSONObject("line")
                if (line != null && !line.isEmpty) formway = line.getIntValue("formway")

                val inMaat: JSONArray = obj.getJSONArray("inMaat")
                val outMaat: JSONArray = obj.getJSONArray("outMaat")
                if (inMaat != null && !inMaat.isEmpty) inMaatSize = inMaat.size()
                if (outMaat != null && !outMaat.isEmpty) outMaatSize = outMaat.size()

                if (formway > 10 && formway < 15) {
                    indexSet.add(i)
                    indexSet.add(i - 1)
                    indexSet.add(i - 2)
                    indexSet.add(i - 3)
                    indexSet.add(i - 4)
                } else if (inMaatSize >= 2 || outMaatSize >= 2) indexSet.add(i)
            }
        }

        val indexList: List[Int] = indexSet.toList.filter(_ >= 0)
        val myList: List[Int] = jp_swidArr.indices.toList.diff(indexList).sortWith(_ < _)

        var waypoints_newBuff: ListBuffer[String] = new ListBuffer[String]
        val appropriate_waypointsBuff_tmp: ListBuffer[String] = new ListBuffer[String]
        val waypoints_swidBuff_tmp: ListBuffer[String] = new ListBuffer[String]
        var appropriate_waypointsBuff1: ListBuffer[String] = new ListBuffer[String]
        var waypoints_swidBuff: ListBuffer[String] = new ListBuffer[String]

        if (myList.nonEmpty) {
            for (i <- myList) {
                appropriate_waypointsBuff_tmp.append(jp_tracksArr(i))
                waypoints_swidBuff_tmp.append(jp_swidArr(i))
            }

            val (waypoints_swidBuff1, appropriate_waypointsBuff) = get_distinc_swid_point(waypoints_swidBuff_tmp, appropriate_waypointsBuff_tmp)
            waypoints_swidBuff = waypoints_swidBuff1
            appropriate_waypointsBuff1 = appropriate_waypointsBuff

            if (appropriate_waypointsBuff.nonEmpty && appropriate_waypointsBuff.size <= 3) waypoints_newBuff = appropriate_waypointsBuff
            else if (appropriate_waypointsBuff.size == 4) waypoints_newBuff = appropriate_waypointsBuff.slice(0, 3)
            else if (appropriate_waypointsBuff.size == 5 || appropriate_waypointsBuff.size == 6) waypoints_newBuff = appropriate_waypointsBuff.slice(1, 4)
            else if (appropriate_waypointsBuff.size == 7 || appropriate_waypointsBuff.size == 8) {
                for (i <- Range(1, 6, 2)) waypoints_newBuff.append(appropriate_waypointsBuff(i))
            }
            else {
                val step: Int = math.floor((appropriate_waypointsBuff.size - 2) / 3 - 0.1).toInt + 2
                for (i <- Range(1, appropriate_waypointsBuff.size - 1, step)) waypoints_newBuff.append(appropriate_waypointsBuff(i))
            }
        }


        var via1_x: String = ""
        var via1_y: String = ""
        var via2_x: String = ""
        var via2_y: String = ""
        var via3_x: String = ""
        var via3_y: String = ""
        if (waypoints_newBuff.size == 1) {
            via1_x = waypoints_newBuff.head.split(",", -1)(0)
            via1_y = waypoints_newBuff.head.split(",", -1)(1)
        } else if (waypoints_newBuff.size == 2) {
            via1_x = waypoints_newBuff.head.split(",", -1)(0)
            via1_y = waypoints_newBuff.head.split(",", -1)(1)
            via2_x = waypoints_newBuff(1).split(",", -1)(0)
            via2_y = waypoints_newBuff(1).split(",", -1)(1)
        } else if (waypoints_newBuff.size == 3) {
            via1_x = waypoints_newBuff.head.split(",", -1)(0)
            via1_y = waypoints_newBuff.head.split(",", -1)(1)
            via2_x = waypoints_newBuff(1).split(",", -1)(0)
            via2_y = waypoints_newBuff(1).split(",", -1)(1)
            via3_x = waypoints_newBuff.last.split(",", -1)(0)
            via3_y = waypoints_newBuff.last.split(",", -1)(1)
        }

        var appropriate_waypoints: String = ""
        var waypoints_swid: String = ""
        var waypoints_new: String = ""
        if (appropriate_waypointsBuff1.nonEmpty) appropriate_waypoints = appropriate_waypointsBuff1.mkString(";")
        if (waypoints_swidBuff.nonEmpty) waypoints_swid = waypoints_swidBuff.mkString(",")
        if (waypoints_newBuff.nonEmpty) waypoints_new = waypoints_newBuff.mkString(";")

        RoutePoint(code, appropriate_waypoints, waypoints_swid, waypoints_new, model_id, "", "", "", from_x, from_y, to_x, to_y, via1_x, via1_y, via2_x, via2_y, via3_x, via3_y)
    }

    // 对swid 和 point 进行去重
    def get_distinc_swid_point(swid: ListBuffer[String], point: ListBuffer[String]): (ListBuffer[String], ListBuffer[String]) = {

        // 每个元素连续出现的最后下标
        val buff: ListBuffer[Int] = new ListBuffer[Int]

        var first: String = swid.head
        var next: String = first

        for (i <- swid.indices) {
            if (i == swid.length - 1) next = swid(i)
            if (i < swid.length - 1) next = swid(i + 1)
            if (next != first) {
                buff.append(i)
                first = next
            }

            if (i == swid.length - 1) buff.append(i)
        }

        // 每个元素连续出现的中间位置
        val buff2: ListBuffer[Int] = new ListBuffer[Int]
        for (i <- buff.indices) {
            if (i == 0) buff2.append(buff(i) / 2)
            else {
                val first: Int = buff(i)
                val before: Int = buff(i - 1)
                buff2.append((before + 1 + first) / 2)
            }
        }

        // 获取中间位置对应的元素
        val swid_buff = new ListBuffer[String]
        val point_buff = new ListBuffer[String]
        for (i <- buff2.indices) {
            val index: Int = buff2(i)
            swid_buff.append(swid(index))
            point_buff.append(point(index))
        }

        (swid_buff, point_buff)
    }

    // waypoints_drop_duplicates_gdapp 数据写入MySQL
    def gdappToMysql(df: DataFrame): Unit = {
        df.rdd
          .foreachPartition(iter => {
              Class.forName(driver)
              val connection: Connection = java.sql.DriverManager.getConnection(url, userName, passWd)
              iter.foreach(r => {

                  val code: String = r.getAs[String]("code")
                  val jp_swid: String = r.getAs[String]("jp_swid")
                  val vehicle_type: Int = r.getAs[Int]("vehicle_type")
                  val label: String = r.getAs[String]("label")
                  val uid_new: String = r.getAs[String]("uid_new")
                  val standard_id: String = r.getAs[String]("standard_id")
                  val uid: String = r.getAs[String]("uid")
                  val task_id: String = r.getAs[String]("task_id")
                  val sort_num: String = r.getAs[String]("sort_num")
                  val start_dept: String = r.getAs[String]("start_dept")
                  val end_dept: String = r.getAs[String]("end_dept")
                  val his_coords: String = r.getAs[String]("his_coords")
                  val start_type: String = r.getAs[String]("start_type")
                  val end_type: String = r.getAs[String]("end_type")
                  val start_tm: String = r.getAs[String]("start_tm")
                  val end_tm: String = r.getAs[String]("end_tm")
                  val actual_run_time: String = r.getAs[String]("actual_run_time")
                  val plan_run_time: String = r.getAs[String]("plan_run_time")
                  val start_longitude: String = r.getAs[String]("start_longitude")
                  val end_longitude: String = r.getAs[String]("end_longitude")
                  val start_latitude: String = r.getAs[String]("start_latitude")
                  val end_latitude: String = r.getAs[String]("end_latitude")
                  val line_code: String = r.getAs[String]("line_code")
                  val line_id: String = r.getAs[String]("line_id")
                  val task_area_code: String = r.getAs[String]("task_area_code")
                  val vehicle_serial: String = r.getAs[String]("vehicle_serial")
                  val conveyance_type: String = r.getAs[String]("conveyance_type")
                  val transoport_level: String = r.getAs[String]("transoport_level")
                  val id: String = r.getAs[String]("id")
                  val is_stop: String = r.getAs[String]("is_stop")
                  val ground_task_id: String = r.getAs[String]("ground_task_id")
                  val start_time: String = r.getAs[String]("start_time")
                  val carrier_type: String = r.getAs[String]("carrier_type")
                  val plf_flag: String = r.getAs[String]("plf_flag")
                  val log_dist: String = r.getAs[String]("log_dist")
                  val line_distance: String = r.getAs[String]("line_distance")
                  val hko_vehicle_code: String = r.getAs[String]("hko_vehicle_code")
                  val trailer_vehicle_code: String = r.getAs[String]("trailer_vehicle_code")
                  val source: Int = r.getAs[Int]("source")
                  val is_trailer: String = r.getAs[String]("is_trailer")
                  val vehicle_length: String = r.getAs[String]("vehicle_length")
                  val width: Double = r.getAs[Double]("width")
                  val height: Double = r.getAs[Double]("height")
                  val color: String = r.getAs[String]("color")
                  val energy: String = r.getAs[String]("energy")
                  val license: String = r.getAs[String]("license")
                  val emission: String = r.getAs[String]("emission")
                  val axls_number: String = r.getAs[String]("axls_number")
                  val vehicle_full_load_weight: String = r.getAs[String]("vehicle_full_load_weight")
                  val vehicle_load_weight: Double = r.getAs[Double]("vehicle_load_weight")
                  val line: String = r.getAs[String]("line")
                  val xy: String = r.getAs[String]("xy")
                  val order: Int = r.getAs[Int]("order")
                  val grp0: String = r.getAs[String]("grp0")
                  val grp1: String = r.getAs[String]("grp1")
                  val groupby_id: String = r.getAs[String]("groupby_id")
                  val plandate: String = r.getAs[String]("plandate")
                  val grp2_order: Int = r.getAs[Int]("grp2_order")
                  val uuid: String = r.getAs[String]("uuid")
                  val his_abnormal: String = r.getAs[String]("his_abnormal")
                  val abnormal: String = r.getAs[String]("abnormal")
                  val coords: String = r.getAs[String]("coords")
                  val data_source: String = r.getAs[String]("data_source")
                  val city: String = r.getAs[String]("city")
                  val d_plan_order: Int = r.getAs[Int]("d_plan_order")
                  val `type`: String = r.getAs[String]("type")
                  val version: String = r.getAs[String]("version")
                  val d_url: String = r.getAs[String]("d_url")
                  val d_status: String = r.getAs[String]("d_status")
                  val d_dist: String = r.getAs[String]("d_dist")
                  val d_time: String = r.getAs[String]("d_time")
                  val d_highway: String = r.getAs[String]("d_highway")
                  val d_tralightcount: String = r.getAs[String]("d_tralightcount")
                  val d_src: String = r.getAs[String]("d_src")
                  val d_frequency: String = r.getAs[String]("d_frequency")
                  val d_frequencycost: String = r.getAs[String]("d_frequencycost")
                  val d_frequencytype: String = r.getAs[String]("d_frequencytype")
                  val d_freqratio: String = r.getAs[String]("d_freqratio")
                  val d_flen: String = r.getAs[String]("d_flen")
                  val d_tlen: String = r.getAs[String]("d_tlen")
                  val d_route_id: String = r.getAs[String]("d_route_id")
                  val d_src_routeids: String = r.getAs[String]("d_src_routeids")
                  val t_status: String = r.getAs[String]("t_status")
                  val t_links_union: String = r.getAs[String]("t_links_union")
                  val t_distance: Int = r.getAs[Int]("t_distance")
                  val t_duration: Double = r.getAs[Double]("t_duration")
                  val t_highspeed_distance: Int = r.getAs[Int]("t_highspeed_distance")
                  val t_trafficlight_count: Int = r.getAs[Int]("t_trafficlight_count")
                  val t_coords_xy: String = r.getAs[String]("t_coords_xy")
                  val t_coords_xy_swid: String = r.getAs[String]("t_coords_xy_swid")
                  val t_linkpointinfo: String = r.getAs[String]("t_linkpointinfo")
                  val t_origin: String = r.getAs[String]("t_origin")
                  val t_destination: String = r.getAs[String]("t_destination")
                  val t_flen: String = r.getAs[String]("t_flen")
                  val t_tlen: String = r.getAs[String]("t_tlen")
                  val different_route_id: Int = r.getAs[Int]("different_route_id")
                  val different_num: Int = r.getAs[Int]("different_num")
                  val different_start_swid: String = r.getAs[String]("different_start_swid")
                  val different_start_poi: String = r.getAs[String]("different_start_poi")
                  val different_end_poi: String = r.getAs[String]("different_end_poi")
                  val different_end_swid: String = r.getAs[String]("different_end_swid")
                  val different_start_dist: Double = r.getAs[Double]("different_start_dist")
                  val different_end_dist: Double = r.getAs[Double]("different_end_dist")
                  val different_dist: Double = r.getAs[Double]("different_dist")
                  val different_basic_dist: Double = r.getAs[Double]("different_basic_dist")
                  val different_add_dist: Double = r.getAs[Double]("different_add_dist")
                  val different_real_dist: Double = r.getAs[Double]("different_real_dist")
                  val different_dist_ratio: Double = r.getAs[Double]("different_dist_ratio")
                  val different_start_line_dist: Double = r.getAs[Double]("different_start_line_dist")
                  val different_end_line_dist: Double = r.getAs[Double]("different_end_line_dist")
                  val different_compare_dist_ratio: Double = r.getAs[Double]("different_compare_dist_ratio")
                  val different_weighted_compare_dist_ratio: Double = r.getAs[Double]("different_weighted_compare_dist_ratio")
                  val stand_road_dist: Double = r.getAs[Double]("stand_road_dist")
                  val stand_add_dist: Double = r.getAs[Double]("stand_add_dist")
                  // 正式用的
                  val t_distance2: Double = r.getAs[Double]("nostandard_t_distance")
                  //临时用的
//                  val t_distance2: Double = r.getAs[Double]("t_distance2")
                  val different_dist_basic: Double = r.getAs[Double]("different_dist_basic")
                  val hour: Int = r.getAs[Int]("hour")
                  val hour2: Int = r.getAs[Int]("hour2")
                  val t_coords_xy_ct: String = r.getAs[String]("t_coords_xy_ct")
                  val t_coords_xy_swid_ct: String = r.getAs[String]("t_coords_xy_swid_ct")
                  val jp_tracks: String = r.getAs[String]("jp_tracks")
                  val drop_duplicates_code: String = r.getAs[String]("drop_duplicates_code")
                  val start_table_num: Int = r.getAs[Int]("start_table_num")
                  val all_data_source: String = r.getAs[String]("all_data_source")
                  val all_height: String = r.getAs[String]("all_height")
                  val max_height: Double = r.getAs[Double]("max_height")
                  val all_hour: String = r.getAs[String]("all_hour")
                  val round: String = r.getAs[String]("round")
                  val appropriate_waypoints: String = r.getAs[String]("appropriate_waypoints")
                  val waypoints_swid: String = r.getAs[String]("waypoints_swid")
                  val waypoints_new: String = r.getAs[String]("waypoints_new")
                  val model_id: String = r.getAs[String]("model_id")
                  val data_source_type: String = r.getAs[String]("data_source_type")
                  val all_avoid_pos_gd: String = r.getAs[String]("all_avoid_pos_gd")
                  val avoid_dist: String = r.getAs[String]("avoid_dist")
                  val from_x: String = r.getAs[String]("from_x")
                  val from_y: String = r.getAs[String]("from_y")
                  val to_x: String = r.getAs[String]("to_x")
                  val to_y: String = r.getAs[String]("to_y")
                  val via1_x: String = r.getAs[String]("via1_x")
                  val via1_y: String = r.getAs[String]("via1_y")
                  val via2_x: String = r.getAs[String]("via2_x")
                  val via2_y: String = r.getAs[String]("via2_y")
                  val via3_x: String = r.getAs[String]("via3_x")
                  val via3_y: String = r.getAs[String]("via3_y")
                  val is_send: Int = r.getAs[Int]("is_send")
                  val inc_day: String = r.getAs[String]("inc_day")


                  val del_sql: String = s"delete from raoxing_waypoints_drop_duplicates_gdapp where code =?"
                  val statement0: PreparedStatement = connection.prepareStatement(del_sql)
                  statement0.setString(1, code)
                  statement0.executeUpdate()
                  statement0.close()

                  val insert_sql: String = "insert into raoxing_waypoints_drop_duplicates_gdapp(" +
                    "code," +
                    "jp_swid," +
                    "vehicle_type," +
                    "label," +
                    "uid_new," +
                    "standard_id," +
                    "uid," +
                    "task_id," +
                    "sort_num," +
                    "start_dept," +
                    "end_dept," +
                    "his_coords," +
                    "start_type," +
                    "end_type," +
                    "start_tm," +
                    "end_tm," +
                    "actual_run_time," +
                    "plan_run_time," +
                    "start_longitude," +
                    "end_longitude," +
                    "start_latitude," +
                    "end_latitude," +
                    "line_code," +
                    "line_id," +
                    "task_area_code," +
                    "vehicle_serial," +
                    "conveyance_type," +
                    "transoport_level," +
                    "id," +
                    "is_stop," +
                    "ground_task_id," +
                    "start_time," +
                    "carrier_type," +
                    "plf_flag," +
                    "log_dist," +
                    "line_distance," +
                    "hko_vehicle_code," +
                    "trailer_vehicle_code," +
                    "source," +
                    "is_trailer," +
                    "vehicle_length," +
                    "width," +
                    "height," +
                    "color," +
                    "energy," +
                    "license," +
                    "emission," +
                    "axls_number," +
                    "vehicle_full_load_weight," +
                    "vehicle_load_weight," +
                    "line," +
                    "xy," +
                    "`order`," +
                    "grp0," +
                    "grp1," +
                    "groupby_id," +
                    "plandate," +
                    "grp2_order," +
                    "uuid," +
                    "his_abnormal," +
                    "abnormal," +
                    "coords," +
                    "data_source," +
                    "city," +
                    "d_plan_order," +
                    "`type`," +
                    "version," +
                    "d_url," +
                    "d_status," +
                    "d_dist," +
                    "d_time," +
                    "d_highway," +
                    "d_tralightcount," +
                    "d_src," +
                    "d_frequency," +
                    "d_frequencycost," +
                    "d_frequencytype," +
                    "d_freqratio," +
                    "d_flen," +
                    "d_tlen," +
                    "d_route_id," +
                    "d_src_routeids," +
                    "t_status," +
                    "t_links_union," +
                    "t_distance," +
                    "t_duration," +
                    "t_highspeed_distance," +
                    "t_trafficlight_count," +
                    "t_coords_xy," +
                    "t_coords_xy_swid," +
                    "t_linkpointinfo," +
                    "t_origin," +
                    "t_destination," +
                    "t_flen," +
                    "t_tlen," +
                    "different_route_id," +
                    "different_num," +
                    "different_start_swid," +
                    "different_start_poi," +
                    "different_end_poi," +
                    "different_end_swid," +
                    "different_start_dist," +
                    "different_end_dist," +
                    "different_dist," +
                    "different_basic_dist," +
                    "different_add_dist," +
                    "different_real_dist," +
                    "different_dist_ratio," +
                    "different_start_line_dist," +
                    "different_end_line_dist," +
                    "different_compare_dist_ratio," +
                    "different_weighted_compare_dist_ratio," +
                    "stand_road_dist," +
                    "stand_add_dist," +
                    "t_distance2," +
                    "different_dist_basic," +
                    "hour," +
                    "hour2," +
                    "t_coords_xy_ct," +
                    "t_coords_xy_swid_ct," +
                    "jp_tracks," +
                    "drop_duplicates_code," +
                    "start_table_num," +
                    "all_data_source," +
                    "all_height," +
                    "max_height," +
                    "all_hour," +
                    "round," +
                    "appropriate_waypoints," +
                    "waypoints_swid," +
                    "waypoints_new," +
                    "model_id," +
                    "data_source_type," +
                    "all_avoid_pos_gd," +
                    "avoid_dist," +
                    "from_x," +
                    "from_y," +
                    "to_x," +
                    "to_y," +
                    "via1_x," +
                    "via1_y," +
                    "via2_x," +
                    "via2_y," +
                    "via3_x," +
                    "via3_y," +
                    "is_send," +
                    "inc_day" +
                    ") values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                  val statement: PreparedStatement = connection.prepareStatement(insert_sql)

                  statement.setString(1, code)
                  statement.setString(2, jp_swid)
                  statement.setInt(3, vehicle_type)
                  statement.setString(4, label)
                  statement.setString(5, uid_new)
                  statement.setString(6, standard_id)
                  statement.setString(7, uid)
                  statement.setString(8, task_id)
                  statement.setString(9, sort_num)
                  statement.setString(10, start_dept)
                  statement.setString(11, end_dept)
                  statement.setString(12, his_coords)
                  statement.setString(13, start_type)
                  statement.setString(14, end_type)
                  statement.setString(15, start_tm)
                  statement.setString(16, end_tm)
                  statement.setString(17, actual_run_time)
                  statement.setString(18, plan_run_time)
                  statement.setString(19, start_longitude)
                  statement.setString(20, end_longitude)
                  statement.setString(21, start_latitude)
                  statement.setString(22, end_latitude)
                  statement.setString(23, line_code)
                  statement.setString(24, line_id)
                  statement.setString(25, task_area_code)
                  statement.setString(26, vehicle_serial)
                  statement.setString(27, conveyance_type)
                  statement.setString(28, transoport_level)
                  statement.setString(29, id)
                  statement.setString(30, is_stop)
                  statement.setString(31, ground_task_id)
                  statement.setString(32, start_time)
                  statement.setString(33, carrier_type)
                  statement.setString(34, plf_flag)
                  statement.setString(35, log_dist)
                  statement.setString(36, line_distance)
                  statement.setString(37, hko_vehicle_code)
                  statement.setString(38, trailer_vehicle_code)
                  statement.setInt(39, source)
                  statement.setString(40, is_trailer)
                  statement.setString(41, vehicle_length)
                  statement.setDouble(42, width)
                  statement.setDouble(43, height)
                  statement.setString(44, color)
                  statement.setString(45, energy)
                  statement.setString(46, license)
                  statement.setString(47, emission)
                  statement.setString(48, axls_number)
                  statement.setString(49, vehicle_full_load_weight)
                  statement.setDouble(50, vehicle_load_weight)
                  statement.setString(51, line)
                  statement.setString(52, xy)
                  statement.setInt(53, order)
                  statement.setString(54, grp0)
                  statement.setString(55, grp1)
                  statement.setString(56, groupby_id)
                  statement.setString(57, plandate)
                  statement.setInt(58, grp2_order)
                  statement.setString(59, uuid)
                  statement.setString(60, his_abnormal)
                  statement.setString(61, abnormal)
                  statement.setString(62, coords)
                  statement.setString(63, data_source)
                  statement.setString(64, city)
                  statement.setInt(65, d_plan_order)
                  statement.setString(66, `type`)
                  statement.setString(67, version)
                  statement.setString(68, d_url)
                  statement.setString(69, d_status)
                  statement.setString(70, d_dist)
                  statement.setString(71, d_time)
                  statement.setString(72, d_highway)
                  statement.setString(73, d_tralightcount)
                  statement.setString(74, d_src)
                  statement.setString(75, d_frequency)
                  statement.setString(76, d_frequencycost)
                  statement.setString(77, d_frequencytype)
                  statement.setString(78, d_freqratio)
                  statement.setString(79, d_flen)
                  statement.setString(80, d_tlen)
                  statement.setString(81, d_route_id)
                  statement.setString(82, d_src_routeids)
                  statement.setString(83, t_status)
                  statement.setString(84, t_links_union)
                  statement.setInt(85, t_distance)
                  statement.setDouble(86, t_duration)
                  statement.setInt(87, t_highspeed_distance)
                  statement.setInt(88, t_trafficlight_count)
                  statement.setString(89, t_coords_xy)
                  statement.setString(90, t_coords_xy_swid)
                  statement.setString(91, t_linkpointinfo)
                  statement.setString(92, t_origin)
                  statement.setString(93, t_destination)
                  statement.setString(94, t_flen)
                  statement.setString(95, t_tlen)
                  statement.setInt(96, different_route_id)
                  statement.setInt(97, different_num)
                  statement.setString(98, different_start_swid)
                  statement.setString(99, different_start_poi)
                  statement.setString(100, different_end_poi)
                  statement.setString(101, different_end_swid)
                  statement.setDouble(102, different_start_dist)
                  statement.setDouble(103, different_end_dist)
                  statement.setDouble(104, different_dist)
                  statement.setDouble(105, different_basic_dist)
                  statement.setDouble(106, different_add_dist)
                  statement.setDouble(107, different_real_dist)
                  statement.setDouble(108, different_dist_ratio)
                  statement.setDouble(109, different_start_line_dist)
                  statement.setDouble(110, different_end_line_dist)
                  statement.setDouble(111, different_compare_dist_ratio)
                  statement.setDouble(112, different_weighted_compare_dist_ratio)
                  statement.setDouble(113, stand_road_dist)
                  statement.setDouble(114, stand_add_dist)
                  statement.setDouble(115, t_distance2)
                  statement.setDouble(116, different_dist_basic)
                  statement.setInt(117, hour)
                  statement.setInt(118, hour2)
                  statement.setString(119, t_coords_xy_ct)
                  statement.setString(120, t_coords_xy_swid_ct)
                  statement.setString(121, jp_tracks)
                  statement.setString(122, drop_duplicates_code)
                  statement.setInt(123, start_table_num)
                  statement.setString(124, all_data_source)
                  statement.setString(125, all_height)
                  statement.setDouble(126, max_height)
                  statement.setString(127, all_hour)
                  statement.setString(128, round)
                  statement.setString(129, appropriate_waypoints)
                  statement.setString(130, waypoints_swid)
                  statement.setString(131, waypoints_new)
                  statement.setString(132, model_id)
                  statement.setString(133, data_source_type)
                  statement.setString(134, all_avoid_pos_gd)
                  statement.setString(135, avoid_dist)
                  statement.setString(136, from_x)
                  statement.setString(137, from_y)
                  statement.setString(138, to_x)
                  statement.setString(139, to_y)
                  statement.setString(140, via1_x)
                  statement.setString(141, via1_y)
                  statement.setString(142, via2_x)
                  statement.setString(143, via2_y)
                  statement.setString(144, via3_x)
                  statement.setString(145, via3_y)
                  statement.setInt(146, is_send)
                  statement.setString(147, inc_day)


                  statement.executeUpdate()
                  statement.close()

              })

              connection.close()
          })

    }


}
