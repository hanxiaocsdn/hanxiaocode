package app.detour

import entry.{PosCount, UidCount}
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window, WindowSpec}
import org.apache.spark.sql.functions.{collect_set, concat_ws, row_number, udf}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.GetDFCountAndSampleData
import utils.SparkConfigUtil

/**
  * 规制召回率指标输出
  */
object GetRegulationParsingIndicator {

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    thirty_day_ago_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val thirty_day_ago_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$thirty_day_ago_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 导入隐式转换
        import spark.implicits._


        // 表一
        val unionRatioSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.raoxing_union_ratio
               |where
               |  inc_day >= '$thirty_day_ago_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 表二
        val waypointsAllSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.raoxing_waypoints_all
               |where
               |  inc_day >= '$thirty_day_ago_time'
               |  and inc_day < '$end_time'
               |  and data_source = '0'
               |""".stripMargin

        // 表三
        val compareLimitedFinalSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.raoxing_waypoints_drop_duplicates_gdapp_out_route_compare_limited_final
               |where
               |  inc_day >= '$thirty_day_ago_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        // 表四
        val checkedSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.raoxing_zuoye
               |where
               |  inc_day >= '$thirty_day_ago_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(unionRatioSql)
        logger.error(waypointsAllSql)
        logger.error(compareLimitedFinalSql)
        logger.error(checkedSql)

        val unionRatioDF: DataFrame = spark.sql(unionRatioSql).persist(StorageLevel.MEMORY_AND_DISK)
        val waypointsAllDF: DataFrame = spark.sql(waypointsAllSql).persist(StorageLevel.MEMORY_AND_DISK)
        val compareLimitedFinalDF: DataFrame = spark.sql(compareLimitedFinalSql).persist(StorageLevel.MEMORY_AND_DISK)
        val checkedDF: DataFrame = spark.sql(checkedSql).persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, unionRatioDF, "表一的数据")
        GetDFCountAndSampleData(logger, waypointsAllDF, "表二的数据")
        GetDFCountAndSampleData(logger, compareLimitedFinalDF, "表三的数据")
        GetDFCountAndSampleData(logger, checkedDF, "表四的数据")


        // 计算 有效轨迹样本
        val tracks_originDF: DataFrame = unionRatioDF
          .filter(r => {
              var flag: Boolean = false

              val data_source: String = r.getAs[String]("data_source")
              val standard_id: String = r.getAs[String]("standard_id")
              if (standard_id.nonEmpty) {
                  val arr: Array[String] = standard_id.split("_")
                  if (data_source == "0" && arr(2) == "1") flag = true
              }

              flag
          })
          .dropDuplicates("uid")
          .groupBy("inc_day", "city")
          .count()
          .withColumnRenamed("count", "tracks_origin")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, tracks_originDF, "每一天、每个城市 对应的有效轨迹数")


        // 计算 绕行轨迹数
        val compareLimitedFinalDF2: DataFrame = compareLimitedFinalDF
          .withColumn("drop_duplicates_code", get_code_origin($"code"))

        val tracks_detourDF: DataFrame = waypointsAllDF
          .join(compareLimitedFinalDF2, Seq("drop_duplicates_code"), "leftsemi")
          .dropDuplicates("uid")
          .groupBy("inc_day", "city", "version")
          .count()
          .withColumnRenamed("count", "tracks_detour")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, tracks_detourDF, "每一天、每个城市、每个版本 对应的绕行轨迹数")


        // 统计 pos 维度的相应指标
        val w1: WindowSpec = Window
          .partitionBy("pos", "vehicle_type_gd", "timedescription_gd", "roadnamestring_gd", "nextroadnamestring_gd", "direction_type_gd")
          .orderBy($"inc_day".desc)

        val checkedDF2: DataFrame = checkedDF
          .select("pos", "vehicle_type_gd", "timedescription_gd", "roadnamestring_gd", "nextroadnamestring_gd", "direction_type_gd", "work_status", "inc_day")
          .withColumn("rn", row_number().over(w1))
          .filter("rn = 1")
          .drop("rn", "inc_day")

        val limitedAndCheckedDF: DataFrame = compareLimitedFinalDF
          .join(checkedDF2, Seq("pos", "vehicle_type_gd", "timedescription_gd", "roadnamestring_gd", "nextroadnamestring_gd", "direction_type_gd"), "left")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, limitedAndCheckedDF, "闯行关联上核实结果的数据")

        val posDF: DataFrame = limitedAndCheckedDF
          .rdd
          .map(r => {
              val inc_day: String = r.getAs[String]("inc_day")
              val version: String = r.getAs[String]("version")
              val area_code: String = r.getAs[String]("adcode").substring(0, 4)
              ((inc_day, version, area_code), r)
          })
          .groupByKey()
          .map(r => {
              val pc: PosCount = get_pos_count(r)
              pc
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, posDF, "【pos维度】每一天、每个城市、每个版本 对应的指标数据")


        // 统计 uid 维度的相应指标
        val limitedAndCheckedDF2: DataFrame = limitedAndCheckedDF
          .withColumn("drop_duplicates_code", get_code_origin($"code"))
          .select("work_status", "drop_duplicates_code")

        val uidDF: DataFrame = waypointsAllDF
          .join(limitedAndCheckedDF2, Seq("drop_duplicates_code"), "left")
          .groupBy("uid")
          .agg(concat_ws("|", collect_set("work_status")).alias("data_status_all"))
          .withColumn("work_status", get_final_status($"data_status_all"))
          .join(waypointsAllDF, Seq("uid"))
          .rdd
          .map(r => {
              val inc_day: String = r.getAs[String]("inc_day")
              val version: String = r.getAs[String]("version")
              val city: String = r.getAs[String]("city")
              ((inc_day, version, city), r)
          })
          .groupByKey()
          .map(r => {
              val uc: UidCount = get_uid_count(r)
              uc
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, uidDF, "【uid维度】每一天、每个城市、每个版本 对应的指标数据")



        // 以上3份指标数据汇总










        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    def get_code_origin: UserDefinedFunction = udf((code: String) => {
        code.split("\\|")(0).split("_").slice(0, 11).mkString("_")
    })

    // 统计 pos 维度的相应指标
    def get_pos_count(r: ((String, String, String), Iterable[Row])): PosCount = {
        val (inc_day, version, area_code) = r._1
        val iters: Iterable[Row] = r._2

        var pos_wrong, pos_other, pos_incident, pos_fuzzy, pos_correct, pos_ungauged, pos_undo, pos_not_required: Int = 0
        for (iter <- iters) {
            val work_status: String = iter.getAs[String]("work_status")
            work_status match {
                case "1" => pos_correct += 1
                case "2" => pos_wrong += 1
                case "3" => pos_fuzzy += 1
                case "4" => pos_ungauged += 1
                case "5" => pos_incident += 1
                case "6" => pos_other += 1
                case "7" => pos_not_required += 1
                case _ => pos_undo += 1
            }
        }

        PosCount(inc_day, version, area_code, pos_wrong, pos_other, pos_incident, pos_fuzzy, pos_correct, pos_ungauged, pos_undo, pos_not_required)
    }

    // 统计 pos 维度的相应指标
    def get_uid_count(r: ((String, String, String), Iterable[Row])): UidCount = {
        val (inc_day, version, city) = r._1
        val iters: Iterable[Row] = r._2

        var pos_wrong, pos_other, pos_incident, pos_fuzzy, pos_correct, pos_ungauged, pos_undo, pos_not_required: Int = 0
        for (iter <- iters) {
            val work_status: String = iter.getAs[String]("work_status")
            work_status match {
                case "1" => pos_correct += 1
                case "2" => pos_wrong += 1
                case "3" => pos_fuzzy += 1
                case "4" => pos_ungauged += 1
                case "5" => pos_incident += 1
                case "6" => pos_other += 1
                case "7" => pos_not_required += 1
                case _ => pos_undo += 1
            }
        }

        UidCount(inc_day, version, city, pos_wrong, pos_other, pos_incident, pos_fuzzy, pos_correct, pos_ungauged, pos_undo, pos_not_required)
    }

    // 根据 data_status_all判断该轨迹的最终状态
    def get_final_status: UserDefinedFunction = udf((data_status_all: String) => {
        var status: String = null
        if (data_status_all.nonEmpty) {
            val work_statusArr: Array[String] = data_status_all.split("\\|")

            work_statusArr match {
                case _ if work_statusArr.contains("2") => status = "2"
                case _ if work_statusArr.contains("6") => status = "6"
                case _ if work_statusArr.contains("5") => status = "5"
                case _ if work_statusArr.contains("3") => status = "3"
                case _ if work_statusArr.contains("4") => status = "4"
                case _ if work_statusArr.contains("7") => status = "7"
                case _ if work_statusArr.contains("1") && work_statusArr.length == 1 => status = "1"
            }

        }
        status
    })


}
