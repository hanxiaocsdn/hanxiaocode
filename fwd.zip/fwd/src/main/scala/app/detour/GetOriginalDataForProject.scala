package app.detour

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.functions.{concat_ws, lit, regexp_replace}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getVersion}
import utils.HttpClientUtil.getJsonByGet2
import utils.SparkConfigUtil

/**
  * 1.取数：获取纠偏 和 规划的数据，合并在一起 做完项目的输入数据源
  */
object GetOriginalDataForProject {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val version_url: String = config.getString("version_url")
    val sichuan_area: String = config.getString("sichuan_area")
    val lujin_area: String = config.getString("lujin_area")

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 导入隐式转换
        import spark.implicits._

        // 纠偏的车辆轨迹信息
        val jpRouteDetailSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_jp_detail_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and
               |  city in $sichuan_area
               |""".stripMargin

        // 规划的车辆路径信息
        val planRouteDetailSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.mms_car_route_plan_detail_from_gd_ct_jy_info
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |  and
               |  city in $sichuan_area
               |""".stripMargin

        logger.error(jpRouteDetailSql)
        logger.error(planRouteDetailSql)

        val jpOrgiDF: DataFrame = spark.sql(jpRouteDetailSql)
        val planOrgiDF: DataFrame = spark.sql(planRouteDetailSql)

        val xmlStr: String = getJsonByGet2(version_url, 10, "utf-8")
        val version: String = getVersion(xmlStr)

        // 获取纠偏的数据
        val jpDF: DataFrame = jpOrgiDF
          .drop("jp_swid", "jp_status", "uuid2")
          .filter("vehicle_type is not null and cast(vehicle_type as string) !=''")
          .filter("grp2 is not null and grp2 != ''")
          .filter("coords is not null and coords != ''")
          .withColumn("d_plan_order", lit(0))
          .withColumn("type", lit("1000"))
          .withColumn("version", lit(version))
          .withColumn("uid", concat_ws("_",$"task_id", $"sort_num",$"data_source",$"d_plan_order"))
          .withColumn("d_url", lit(""))
          .withColumn("d_status", lit(""))
          .withColumn("d_dist", lit(""))
          .withColumn("d_time", lit(""))
          .withColumn("d_highway", lit(""))
          .withColumn("d_tolls", lit(""))
          .withColumn("d_query", lit(""))
          .withColumn("d_tralightcount", lit(""))
          .withColumn("d_src", lit(""))
          .withColumn("d_frequency", lit(""))
          .withColumn("d_frequencycost", lit(""))
          .withColumn("d_frequencytype", lit(""))
          .withColumn("d_freqratio", lit(""))
          .withColumn("d_flen", lit(""))
          .withColumn("d_tlen", lit(""))
          .withColumn("d_route_id", lit(""))
          .withColumn("d_src_routeids", lit(""))
          .withColumnRenamed("grp2", "groupby_id")
          .select("task_id", "sort_num", "start_dept", "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm", "actual_run_time", "plan_run_time", "start_longitude", "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id", "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance", "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type", "vehicle_length", "width", "height", "color", "energy", "license", "emission", "axls_number", "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "groupby_id", "plandate", "grp2_order", "uuid", "his_abnormal", "abnormal", "coords", "data_source", "city", "d_plan_order", "type", "version", "uid", "d_url", "d_status", "d_dist", "d_time", "d_highway", "d_tralightcount", "d_src", "d_frequency", "d_frequencycost", "d_frequencytype", "d_freqratio", "d_flen", "d_tlen", "d_route_id", "d_src_routeids", "inc_day")
          .repartition(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, jpDF, "纠偏的数据")

        // 获取规划的数据
        val planDFHis: DataFrame = planOrgiDF
          .filter("vehicle_type is not null and cast(vehicle_type as string) !=''")
          .filter("grp2 is not null and grp2 != ''")
          .filter("coords is not null and coords != ''")
          .filter("grp2_order = 1")
          .withColumn("his_abnormal", lit("0"))
          .withColumn("abnormal", lit("0"))
          .withColumn("uid", concat_ws("_",$"task_id", $"sort_num",$"data_source",$"d_plan_order"))
          .withColumnRenamed("grp2", "groupby_id")
          .withColumn("coords",regexp_replace($"coords","\"",""))

        val planDF1: DataFrame = planDFHis
          .filter("data_source = 1")
          .withColumn("type", lit("1"))

        val planDF2: DataFrame = planDFHis
          .filter("data_source != 1")
          .withColumn("type", lit("1000"))

        // 规划的最终数据
        val planDF: Dataset[Row] = planDF1
          .union(planDF2)
          .select("task_id", "sort_num", "start_dept", "end_dept", "his_coords", "start_type", "end_type", "start_tm", "end_tm", "actual_run_time", "plan_run_time", "start_longitude", "end_longitude", "start_latitude", "end_latitude", "line_code", "line_id", "task_area_code", "vehicle_serial", "conveyance_type", "transoport_level", "id", "is_stop", "ground_task_id", "start_time", "carrier_type", "plf_flag", "log_dist", "line_distance", "hko_vehicle_code", "trailer_vehicle_code", "source", "is_trailer", "vehicle_type", "vehicle_length", "width", "height", "color", "energy", "license", "emission", "axls_number", "vehicle_full_load_weight", "vehicle_load_weight", "line", "xy", "order", "grp0", "grp1", "groupby_id", "plandate", "grp2_order", "uuid", "his_abnormal", "abnormal", "coords", "data_source", "city", "d_plan_order", "type", "version", "uid", "d_url", "d_status", "d_dist", "d_time", "d_highway", "d_tralightcount", "d_src", "d_frequency", "d_frequencycost", "d_frequencytype", "d_freqratio", "d_flen", "d_tlen", "d_route_id", "d_src_routeids", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, planDF, "规划的数据")

        // 纠偏的数据 与 规划的数据 合并在一起
        val resultDF: DataFrame = jpDF
          .union(planDF)
          .coalesce(200)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, resultDF, "纠偏 + 规划 的数据")

        jpDF.unpersist()
        planDF.unpersist()

        // 最终的数据写入hive
        df2HiveByOverwrite(logger,resultDF,"dm_gis.raoxing_ctbase")


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

}
