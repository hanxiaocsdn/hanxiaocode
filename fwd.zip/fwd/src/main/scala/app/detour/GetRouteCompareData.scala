package app.detour

import app.runLimited.DealLocusAbnormalDataFromLimited.get_distance2
import app.runLimited.GetRoutePlanDataFromGDAndCTAndJY.interStatus2Hive
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.{RoudePathInfo, UnionMulti, UnionRatio}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.HttpConnection.sendPost
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
  * 2.进行 线路对比
  *
  * 输出差异段明细 和 差异段汇总
  */
object GetRouteCompareData {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")

    def main(args: Array[String]): Unit = {

        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 记录调用高德接口的成功、失败次数
        val qm_success_acc1: LongAccumulator = spark.sparkContext.longAccumulator
        val qm_success_acc2: LongAccumulator = spark.sparkContext.longAccumulator
        val qm_fail_acc1: LongAccumulator = spark.sparkContext.longAccumulator
        val qm_fail_acc2: LongAccumulator = spark.sparkContext.longAccumulator

        // 导入隐式转换
        import spark.implicits._

        // 获取基础数据
        val jpAndPlanSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.raoxing_ctbase
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(jpAndPlanSql)

        // 获取基础数据
        val orgDF: DataFrame = spark.sql(jpAndPlanSql).persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, orgDF, "原始数据")

        val df1: Dataset[Row] = orgDF.filter("data_source in('0','2','3')")
        val df2: Dataset[Row] = orgDF.filter("data_source = '1' and d_plan_order = 0")
        val df3: Dataset[Row] = orgDF.filter("data_source = '1' and d_plan_order = 1")

        // 获取 第1个表的数据
        val firstDF: Dataset[Row] = df1.union(df2).persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, firstDF, "第一个表")

        // 获取 第2个表的数据
        val secondDF: Dataset[Row] = df1.union(df3).persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, secondDF, "第二个表")

        orgDF.unpersist()

        logger.error("<------ 开始处理第一个表的数据 ------>")
        val firstMatchedDF: DataFrame = firstDF
          .coalesce(20)
          .map(r => {
              val uid: String = r.getAs[String]("uid")
              val groupby_id: String = r.getAs[String]("groupby_id")
              val my_type: String = r.getAs[String]("type")
              val inc_day: String = r.getAs[String]("inc_day")
              val json: JSONObject = call_match_route(r)
              val pathInfo: RoudePathInfo = get_match_data(uid, groupby_id, my_type, inc_day, json)

              if(pathInfo.t_status=="0") qm_success_acc1.add(1L) else qm_fail_acc1.add(1L)
              pathInfo
          })
          .repartition(200)
          .toDF
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 第一个表 调用匹配接口 过后的数据
        GetDFCountAndSampleData(logger, firstMatchedDF, "第一个表调用匹配接口过后的数据")
        interStatus2Hive(logger, spark, "qm_url1", qm_url, className, qm_success_acc1, qm_fail_acc1)

        // 第一个表 进行 线路差异段对比,获取差异明细
        val first_union_multiDF: DataFrame = firstMatchedDF
          .filter("t_status='0'")
          .filter("t_links_union!=''")
          .rdd
          .map(r => {
              val groupby_id: String = r.getAs[String]("groupby_id")
              (groupby_id, r)
          })
          .groupByKey
          .flatMap(r => {
              val iters: Iterable[Row] = r._2
              val union_multi_listBuff: ListBuffer[UnionMulti] = get_route_difference(iters)
              union_multi_listBuff
          })
          .toDF
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, first_union_multiDF, "第一个表 union_multi差异明细")


        // 第一个表 差异明细进行汇总
        val first_union_ratioDF: DataFrame = first_union_multiDF
          .rdd
          .map(r => {
              val uid: String = r.getAs[String]("uid")
              val standard_id: String = r.getAs[String]("standard_id")
              ((uid, standard_id), r)
          })
          .groupByKey
          .map(r => {
              val ratio: UnionRatio = get_route_diff_summary(r)
              ratio
          })
          .toDF
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, first_union_ratioDF, "第一个表 union_ratio差异汇总")

        logger.error("<------ 第一个表的数据处理完毕 ------>")


        logger.error("<------ 开始处理第二个表的数据 ------>")
        val secondMatchedDF: DataFrame = secondDF
          .coalesce(20)
          .map(r => {
              val uid: String = r.getAs[String]("uid")
              val groupby_id: String = r.getAs[String]("groupby_id")
              val my_type: String = r.getAs[String]("type")
              val inc_day: String = r.getAs[String]("inc_day")
              val json: JSONObject = call_match_route(r)
              val pathInfo: RoudePathInfo = get_match_data(uid, groupby_id, my_type, inc_day, json)

              if(pathInfo.t_status=="0") qm_success_acc2.add(1L) else qm_fail_acc2.add(1L)
              pathInfo
          })
          .repartition(200)
          .toDF
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 第二个表 调用匹配接口 过后的数据
        GetDFCountAndSampleData(logger, secondMatchedDF, "第二个表调用匹配接口过后的数据")
        interStatus2Hive(logger, spark, "qm_url2", qm_url, className, qm_success_acc2, qm_fail_acc2)

        // 第二个表 进行 线路差异段对比,获取差异明细
        val second_union_multiDF: DataFrame = secondMatchedDF
          .filter("t_status='0'")
          .filter("t_links_union!=''")
          .rdd
          .map(r => {
              val groupby_id: String = r.getAs[String]("groupby_id")
              (groupby_id, r)
          })
          .groupByKey
          .flatMap(r => {
              val iters: Iterable[Row] = r._2
              val union_multi_listBuff: ListBuffer[UnionMulti] = get_route_difference(iters)
              union_multi_listBuff
          })
          .toDF
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, second_union_multiDF, "第二个表 union_multi差异明细")


        // 第二个表 差异明细进行汇总
        val second_union_ratioDF: DataFrame = second_union_multiDF
          .rdd
          .map(r => {
              val uid: String = r.getAs[String]("uid")
              val standard_id: String = r.getAs[String]("standard_id")
              ((uid, standard_id), r)
          })
          .groupByKey
          .map(r => {
              val ratio: UnionRatio = get_route_diff_summary(r)
              ratio
          })
          .toDF
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, second_union_ratioDF, "第二个表 union_ratio差异汇总")

        logger.error("<------ 第二个表的数据处理完毕 ------>")


        // 第一个表 线路差异段明细 关联原始数据
        val firstDF2: DataFrame = firstDF.select("uid", "inc_day")
        val secondDF2: DataFrame = secondDF.select("uid", "inc_day")

        val firstMatchedDF2: DataFrame = firstMatchedDF.drop("groupby_id", "my_type", "inc_day")
        val secondMatchedDF2: DataFrame = secondMatchedDF.drop("groupby_id", "my_type", "inc_day")

        val first_union_multi_resultDF: DataFrame = firstDF
          .drop("inc_day")
          .join(firstMatchedDF2, Seq("uid"))
          .join(first_union_multiDF, Seq("uid"))

        // 第一个表 线路差异段汇总 关联原始数据
        val first_union_ratio_resultDF: DataFrame = firstDF
          .drop("inc_day")
          .join(firstMatchedDF2, Seq("uid"))
          .join(first_union_ratioDF, Seq("uid"), "left")
          .join(firstDF2, Seq("uid"))

        // 第二个表 线路差异段明细 关联原始数据
        val second_union_multi_resultDF: DataFrame = secondDF
          .drop("inc_day")
          .join(secondMatchedDF2, Seq("uid"))
          .join(second_union_multiDF, Seq("uid"))

        // 第二个表 线路差异段汇总 关联原始数据
        val second_union_ratio_resultDF: DataFrame = secondDF
          .drop("inc_day")
          .join(secondMatchedDF2, Seq("uid"))
          .join(second_union_ratioDF, Seq("uid"), "left")
          .join(secondDF2, Seq("uid"))

        // 最终的 union_multi 数据
        val union_multiDF: DataFrame = first_union_multi_resultDF.union(second_union_multi_resultDF).dropDuplicates().coalesce(200)
        // 最终的 union_ratio 数据
        val union_ratioDF: DataFrame = first_union_ratio_resultDF.union(second_union_ratio_resultDF).dropDuplicates().coalesce(200)

        // 明细数据写入 hive
        df2HiveByOverwrite(logger, union_multiDF, "dm_gis.raoxing_union_multi")
        // 汇总数据写入 hive
        df2HiveByOverwrite(logger, union_ratioDF, "dm_gis.raoxing_union_ratio")


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()
    }

    // 调用线路匹配的接口
    def call_match_route(r: Row): JSONObject = {

        val coords_tmp: String = r.getAs[String]("coords")
        val coords: String = coords_tmp.replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")

        val date: String = r.getAs[String]("start_tm")
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val parm: String = s"points=$coords&date=$date&test=1&stype=0&etype=0&passport=100000&mode=2&speed=1&Toll=1"

        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)
        var json: JSONObject = null

        try {
            val jsonStr: String = mapData.get("content").toString
            json = JSON.parseObject(jsonStr)
        } catch {
            case e: Exception => println("劳资不开心:"+e.getMessage)
        }

        json
    }

    // 解析匹配接口返回的json,获取相应的字段值和逻辑处理
    def get_match_data(uid: String, groupby_id: String, my_type: String, inc_day: String, js: JSONObject): RoudePathInfo = {
        // 存放每个step 下的link字段
        val stepLinkBuff = new ListBuffer[(String, String, String, String, String, String)]
        // 存放每个outinfo 下的link字段
        val outinfoLinkBuff = new ListBuffer[(String, String, String, String, String, String)]
        // 存放每个polyline的值
        val polylineBuff = new ListBuffer[String]
        // 存放每个polyline的值
        val swidBuff = new ListBuffer[String]
        // 存放每个polyline的值
        val pointInfoBuff = new ListBuffer[String]

        var t_status, t_links_union, t_coords_xy, t_coords_xy_swid, t_linkPointInfo, t_origin, t_destination, t_flen, t_tlen: String = ""
        var t_distance, t_highspeed_distance, t_trafficlight_count: Int = 0
        var t_duration: Double = 0.0

        if(js != null){
            t_status = js.getString("status")
            if (t_status == "0") {
                val route: JSONObject = js.getJSONObject("route")
                t_origin = route.getString("origin")
                t_destination = route.getString("destination")

                val paths: JSONArray = route.getJSONArray("paths")
                if (paths != null && paths.size() > 0) {
                    val pathsLen: Int = paths.size()
                    t_flen = paths.getJSONObject(0).getString("flen")
                    t_tlen = paths.getJSONObject(pathsLen - 1).getString("flen")

                    for (i <- 0 until pathsLen) {
                        val path: JSONObject = paths.getJSONObject(i)
                        t_distance += path.getInteger("distance")
                        t_duration += path.getDouble("duration")
                        t_highspeed_distance += path.getInteger("highspeed_distance")
                        t_trafficlight_count += path.getInteger("trafficlight_count")

                        val polyline: String = path.getString("polyline")
                        val polylineArr: Array[String] = polyline.split(";")

                        val steps: JSONArray = path.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            for (j <- 0 until steps.size()) {
                                val step: JSONObject = steps.getJSONObject(j)
                                if (step != null && step.size() > 0) {
                                    val links: JSONArray = step.getJSONArray("links")
                                    if (links != null && links.size() > 0) {
                                        for (i <- 0 until links.size()) {
                                            val link: JSONObject = links.getJSONObject(i)

                                            val sw_id: String = link.getString("sw_id")
                                            val id: String = link.getString("id")
                                            val name: String = link.getString("name")
                                            val formway: String = link.getString("formway")
                                            val roadclass: String = link.getString("roadclass")
                                            val dr_length: String = link.getString("dr_length")

                                            val coorindex: Int = link.getIntValue("coorindex")
                                            val pointnum: Int = link.getIntValue("pointnum")

                                            if (coorindex < 0 || coorindex + pointnum > polylineArr.length)
                                                pointInfoBuff.append("0.0000,0.0000")
                                            else {
                                                for (i <- coorindex until coorindex + pointnum) polylineBuff.append(polylineArr(i))
                                                val start: String = polylineArr(coorindex)
                                                val end: String = polylineArr(coorindex + pointnum - 1)
                                                pointInfoBuff.append(start + ";" + end)
                                            }

                                            for (_ <- 1 to pointnum) swidBuff.append(sw_id)

                                            stepLinkBuff.append((sw_id, id, name, formway, roadclass, dr_length))
                                        }
                                    }
                                }
                            }
                        }

                        val outinfo: JSONObject = path.getJSONObject("outinfo")
                        if (outinfo != null && outinfo.size() > 0) {
                            val links: JSONArray = outinfo.getJSONArray("links")
                            if (links != null && links.size() > 0) {
                                for (j <- 0 until links.size()) {
                                    val link: JSONObject = links.getJSONObject(j)
                                    val lnk_type: String = link.getString("lnk_type")
                                    val ownership: String = link.getString("ownership")
                                    val fc: String = link.getString("FC")
                                    val mainaction: String = link.getString("mainaction")
                                    val lanenum: String = link.getString("lanenum")
                                    val trafficlight: String = link.getString("trafficlight")
                                    outinfoLinkBuff.append((lnk_type, ownership, fc, mainaction, lanenum, trafficlight))
                                }
                            }
                        }

                    }

                    val n: Int = math.min(stepLinkBuff.size, outinfoLinkBuff.size)
                    val listBuff: ListBuffer[String] = new ListBuffer[String]
                    if (n > 0) {
                        for (i <- 0 until n)
                            listBuff.append(
                                s"${stepLinkBuff(i)._1},${stepLinkBuff(i)._2},${stepLinkBuff(i)._3},${stepLinkBuff(i)._4}," +
                                  s"${stepLinkBuff(i)._5},${stepLinkBuff(i)._6},${outinfoLinkBuff(i)._1},${outinfoLinkBuff(i)._2}," +
                                  s"${outinfoLinkBuff(i)._3},${outinfoLinkBuff(i)._4},${outinfoLinkBuff(i)._5},${outinfoLinkBuff(i)._6}"
                            )

                        t_links_union = listBuff.mkString("|")
                    }

                }

            }
        }

        t_coords_xy = polylineBuff.mkString(";")
        t_coords_xy_swid = swidBuff.mkString(",")
        t_linkPointInfo = pointInfoBuff.mkString("|")

        RoudePathInfo(uid, groupby_id, my_type, t_status, t_links_union, t_distance, t_duration, t_highspeed_distance, t_trafficlight_count,
            t_coords_xy, t_coords_xy_swid, t_linkPointInfo, t_origin, t_destination, t_flen, t_tlen, inc_day)

    }

    // 根据index,把连续的index首位组合起来
    def get_first_and_last_index(arrBuff: ArrayBuffer[Int]): ListBuffer[(Int, Int)] = {
        val arr = new ListBuffer[(Int, Int)]
        val tmp = new ListBuffer[Int]

        if (arrBuff.nonEmpty) {
            if (arrBuff.length == 1) {
                arr.append((arrBuff.head, arrBuff.head))
            } else if (arrBuff.last - arrBuff.head == arrBuff.length - 1) {
                arr.append((arrBuff.head, arrBuff.last))
            } else {
                for (i <- arrBuff.indices) {
                    tmp.append(arrBuff(i))
                    var end = 0
                    var sta = 0
                    if (i == arrBuff.size - 1) {
                        end = arrBuff(i)
                        sta = arrBuff(i - 1)
                    } else {
                        end = arrBuff(i + 1)
                        sta = arrBuff(i)
                    }

                    if (i == arrBuff.size - 1) arr.append((tmp.head, tmp.last))
                    else if (end - sta > 1) {
                        if (tmp.nonEmpty) arr.append((tmp.head, tmp.last)) else arr.append((tmp.head, tmp.head))
                        tmp.clear()
                    }
                }
            }


        }
        arr
    }

    // 根据roadclass、fc、ownership、dr_length 计算基础加权里程
    def get_base_mileage(roadclass: String, fc: String, ownership: String, dr_length: String): Double = {
        var mileage: Double = 0.00
        val length: Double = dr_length.toDouble
        if (ownership == "0") {
            if (roadclass == "0" && fc == "0") mileage = length * 1.00
            if (roadclass == "0" && fc == "1") mileage = length * 1.10
            if (roadclass == "0" && fc == "2") mileage = length * 1.20
            if (roadclass == "0" && fc == "3") mileage = length * 1.20

            if (roadclass == "1" && fc == "0") mileage = length * 1.10
            if (roadclass == "1" && fc == "1") mileage = length * 1.20
            if (roadclass == "1" && fc == "2") mileage = length * 1.30
            if (roadclass == "1" && fc == "3") mileage = length * 1.30

            if (roadclass == "2" && fc == "0") mileage = length * 1.20
            if (roadclass == "2" && fc == "1") mileage = length * 1.25
            if (roadclass == "2" && fc == "2") mileage = length * 1.30
            if (roadclass == "2" && fc == "3") mileage = length * 1.40

            if (roadclass == "3" && fc == "0") mileage = length * 1.30
            if (roadclass == "3" && fc == "1") mileage = length * 1.35
            if (roadclass == "3" && fc == "2") mileage = length * 1.40
            if (roadclass == "3" && fc == "3") mileage = length * 1.45

            if (roadclass == "4" && fc == "0") mileage = length * 1.30
            if (roadclass == "4" && fc == "1") mileage = length * 1.40
            if (roadclass == "4" && fc == "2") mileage = length * 1.50
            if (roadclass == "5" && fc == "3") mileage = length * 1.60

            if (roadclass == "5" && fc == "0") mileage = length * 1.60
            if (roadclass == "5" && fc == "1") mileage = length * 1.60
            if (roadclass == "5" && fc == "2") mileage = length * 1.70
            if (roadclass == "5" && fc == "3") mileage = length * 1.80

            if (roadclass == "6" && fc == "0") mileage = length * 1.05
            if (roadclass == "6" && fc == "1") mileage = length * 1.10
            if (roadclass == "6" && fc == "2") mileage = length * 1.20
            if (roadclass == "6" && fc == "3") mileage = length * 1.20

            if (roadclass == "7" && fc == "0") mileage = length * 1.20
            if (roadclass == "7" && fc == "1") mileage = length * 1.20
            if (roadclass == "7" && fc == "2") mileage = length * 1.30
            if (roadclass == "7" && fc == "3") mileage = length * 1.35

            if (roadclass == "8" && fc == "0") mileage = length * 1.40
            if (roadclass == "8" && fc == "1") mileage = length * 1.45
            if (roadclass == "8" && fc == "2") mileage = length * 1.50
            if (roadclass == "8" && fc == "3") mileage = length * 1.55

            if (roadclass == "9" && fc == "0") mileage = length * 1.60
            if (roadclass == "9" && fc == "1") mileage = length * 1.60
            if (roadclass == "9" && fc == "2") mileage = length * 1.65
            if (roadclass == "9" && fc == "3") mileage = length * 1.70

            if (roadclass == "10") mileage = length * 2
        } else mileage = length * 2

        mileage
    }

    // 根据 mainaction、trafficlight 计算附加里程
    def get_subjoin_mileage(mainaction: String, trafficlight: String): Double = {
        var mileage: Double = 0.00
        if (trafficlight == "0") {
            if (mainaction == "0") mileage = 0.00
            if (mainaction == "1") mileage = 10.00
            if (mainaction == "2") mileage = 5.00
            if (mainaction == "3") mileage = 0.00
            if (mainaction == "4") mileage = 0.00
            if (mainaction == "5") mileage = 20.00
            if (mainaction == "6") mileage = 15.00
            if (mainaction == "7") mileage = 20.00
            if (mainaction == "8") mileage = 0.00
            if (mainaction == "9") mileage = 0.00
            if (mainaction == "10") mileage = 0.00
            if (mainaction == "11") mileage = 5.00
            if (mainaction == "12") mileage = 5.00
            if (mainaction == "13") mileage = 5.00
            if (mainaction == "14") mileage = 10.00
        } else if (trafficlight == "1") {
            if (mainaction == "0") mileage = 20.00
            if (mainaction == "1") mileage = 30.00
            if (mainaction == "2") mileage = 5.00
            if (mainaction == "3") mileage = 20.00
            if (mainaction == "4") mileage = 20.00
            if (mainaction == "5") mileage = 30.00
            if (mainaction == "6") mileage = 15.00
            if (mainaction == "7") mileage = 30.00
            if (mainaction == "8") mileage = 20.00
            if (mainaction == "9") mileage = 20.00
            if (mainaction == "10") mileage = 20.00
            if (mainaction == "11") mileage = 25.00
            if (mainaction == "12") mileage = 25.00
            if (mainaction == "13") mileage = 25.00
            if (mainaction == "14") mileage = 20.00
        }

        mileage
    }

    // 进行线路差异对比
    def get_route_difference(iters: Iterable[Row]): ListBuffer[UnionMulti] = {
        val union_multi_listBuff = new ListBuffer[UnionMulti]

        // 标准的线路
        var standard_rote: String = ""
        var standard_rote_uid: String = ""
        var standard_rote_linkPoint: String = ""

        // 非标准的线路列表
        val noStandard_rote_list: ListBuffer[String] = new ListBuffer[String]
        val nostandard_rote_uid: ListBuffer[String] = new ListBuffer[String]
        val nostandard_rote_linkPoint: ListBuffer[String] = new ListBuffer[String]
        val nostandard_origin_and_destination: ListBuffer[(String, String)] = new ListBuffer[(String, String)]
        val nostandard_t_distance_listBuff: ListBuffer[String] = new ListBuffer[String]
        val inc_day_listBuff: ListBuffer[String] = new ListBuffer[String]

        for (it <- iters) {
            val my_type: String = it.getAs[String]("my_type")
            val t_links_union: String = it.getAs[String]("t_links_union")
            val uid: String = it.getAs[String]("uid")
            val t_linkPointInfo: String = it.getAs[String]("t_linkPointInfo")
            val t_origin: String = it.getAs[String]("t_origin")
            val t_destination: String = it.getAs[String]("t_destination")
            val t_distance: String = it.getAs[Int]("t_distance").toString
            inc_day_listBuff.append(it.getAs[String]("inc_day"))

            if (my_type == "1") {
                // 标准线路
                standard_rote = t_links_union
                standard_rote_uid = uid
                standard_rote_linkPoint = t_linkPointInfo
            }
            else {
                // 非标准线路
                noStandard_rote_list.append(t_links_union)
                nostandard_rote_uid.append(uid)
                nostandard_rote_linkPoint.append(t_linkPointInfo)
                nostandard_origin_and_destination.append((t_origin, t_destination))
                nostandard_t_distance_listBuff.append(t_distance)
            }
        }

        if (standard_rote != "" && noStandard_rote_list.nonEmpty) {
            // 标准线路的swid数组
            val standard_rote_swidArr: Array[String] = standard_rote
              .split("\\|")
              .map(_.split(",")(0))

            for (k <- noStandard_rote_list.indices) {
                // 非标准线路的swid数组
                val noStandard_rote_swidArr: Array[String] = noStandard_rote_list(k)
                  .split("\\|")
                  .map(_.split(",")(0))

                // 相同的swid
                val same_swid_arr: Array[String] = standard_rote_swidArr
                  .intersect(noStandard_rote_swidArr)

                // 比较2条线路差异段
                // 1. 标准线路中 有差异swid位置下标
                val standard_diff: Array[String] = standard_rote_swidArr.diff(same_swid_arr)
                val standard_index_buff: ArrayBuffer[Int] = new ArrayBuffer[Int]

                // 2. 非标准线路中 有差异swid位置下标
                val noStandard_diff: Array[String] = noStandard_rote_swidArr.diff(same_swid_arr)
                val noStandard_index_buff: ArrayBuffer[Int] = new ArrayBuffer[Int]

                if (standard_diff.nonEmpty && noStandard_diff.nonEmpty) {

                    for (i <- standard_diff) {
                        val index: Int = standard_rote_swidArr.indexOf(i)
                        standard_index_buff.append(index)
                    }

                    for (i <- noStandard_diff) {
                        val index: Int = noStandard_rote_swidArr.indexOf(i)
                        noStandard_index_buff.append(index)
                    }

                    // 标准线路的index
                    var tp1 = new ListBuffer[(Int, Int)]
                    // 非标准线路的index
                    var tp2 = new ListBuffer[(Int, Int)]

                    tp1 = get_first_and_last_index(standard_index_buff.sortWith(_ < _))
                    tp2 = get_first_and_last_index(noStandard_index_buff.sortWith(_ < _))

                    if (tp1.nonEmpty && tp2.nonEmpty) {

                        // 标准线路每个差异段前后的swid
                        val buff_tmp = new ListBuffer[(String, (Int, Int), String)]
                        for (i <- tp1.indices) {
                            val tp: (Int, Int) = tp1(i)
                            val i1: Int = tp._1 - 1
                            val i2: Int = tp._2 + 1
                            var start: String = "没有swid"
                            var end: String = "没有swid"
                            if (i1 > -1 && i1 < standard_rote_swidArr.length) start = standard_rote_swidArr(i1)
                            if (i2 > -1 && i2 < standard_rote_swidArr.length) end = standard_rote_swidArr(i2)
                            buff_tmp.append((start, tp, end))
                        }

                        // 非标准线路每个差异段前后的swid
                        val buff2_tmp = new ListBuffer[(String, (Int, Int), String)]
                        for (i <- tp2.indices) {
                            val tp: (Int, Int) = tp2(i)
                            val i1: Int = tp._1 - 1
                            val i2: Int = tp._2 + 1
                            var start: String = "没有swid"
                            var end: String = "没有swid"
                            if (i1 > -1 && i1 < noStandard_rote_swidArr.length) start = noStandard_rote_swidArr(i1)
                            if (i2 > -1 && i2 < noStandard_rote_swidArr.length) end = noStandard_rote_swidArr(i2)
                            buff2_tmp.append((start, tp, end))
                        }

                        // 标准线路 和 非标准线路 组成的每个差异段 一一对应起来的集合
                        val setBuff2 = new mutable.HashSet[((Int, Int), (Int, Int))]
                        for (i <- buff_tmp.indices) {
                            var flag: Int = 0
                            for (j <- buff2_tmp.indices) {
                                if (buff_tmp(i)._1 == buff2_tmp(j)._1 && buff_tmp(i)._3 == buff2_tmp(j)._3) {
                                    setBuff2.add(buff_tmp(i)._2, buff2_tmp(j)._2)
                                    flag = 1
                                }
                            }

                            if (flag == 0) setBuff2.add(buff_tmp(i)._2, (888888888, 888888888))
                        }

                        for (i <- buff2_tmp.indices) {
                            var flag: Int = 0
                            for (j <- buff_tmp.indices) {
                                if (buff2_tmp(i)._1 == buff_tmp(j)._1 && buff2_tmp(i)._3 == buff_tmp(j)._3) {
                                    setBuff2.add(buff_tmp(j)._2, buff2_tmp(i)._2)
                                    flag = 1
                                }
                            }

                            if (flag == 0) setBuff2.add((888888888, 888888888), buff2_tmp(i)._2)
                        }

                        val list1: List[((Int, Int), (Int, Int))] = setBuff2.toList

                        // 标准差异段的index集合
                        val stand_index: ListBuffer[(Int, Int)] = new ListBuffer[(Int, Int)]
                        // 非标准差异段的index集合
                        val noStand_index: ListBuffer[(Int, Int)] = new ListBuffer[(Int, Int)]

                        for (i <- list1.indices) {
                            stand_index.append(list1(i)._1)
                            noStand_index.append(list1(i)._2)
                        }

                        // 对非标准差异段 的每个差异段进行处理
                        for (i <- noStand_index.indices) {

                            val different_route_id: Int = i
                            val t_links_unionArr: Array[String] = noStandard_rote_list(k).split("\\|")
                            val dr_lengthArr: Array[Double] = t_links_unionArr.map(_.split(",", -1)(5).toDouble)
                            val t_linkPointInfoArr: Array[String] = nostandard_rote_linkPoint(k).split("\\|")
                            val start_end_xy: (String, String) = nostandard_origin_and_destination(k)

                            // 每条轨迹的起点 和 终点经纬度
                            val route_start_xy: Array[String] = start_end_xy._1.split(",", -1)
                            val route_end_xy: Array[String] = start_end_xy._2.split(",", -1)

                            // 需要计算的指标
                            // 关联的uid
                            val uid: String = nostandard_rote_uid(k)
                            val inc_day: String = inc_day_listBuff(k)

                            val different_num: Int = tp2.size
                            val standard_id: String = standard_rote_uid
                            var different_start_swid: String = ""
                            var different_start_poi: String = ""
                            var different_end_poi: String = ""
                            var different_end_swid: String = ""
                            var different_start_dist: Double = 0.00
                            var different_end_dist: Double = 0.00
                            var different_dist: Double = 0.00
                            var different_basic_dist: Double = 0.00
                            var different_add_dist: Double = 0.00
                            var different_real_dist: Double = 0.00
                            var different_dist_ratio: Double = 0.00
                            var different_start_line_dist: Double = 0.00
                            var different_end_line_dist: Double = 0.00
                            var different_compare_dist_ratio: Double = 0.00
                            var different_weighted_compare_dist_ratio: Double = 0.00

                            var noStandard_t_distance: Double = 0.00

                            // 基准道路差异段道路里程
                            var stand_dist: Double = 0.00
                            // 基准道路差异段加权里程
                            var stand_dist2: Double = 0.00

                            val (stand_start, stand_end) = stand_index(i)
                            val (start, end) = noStand_index(i)
                            if (start != 888888888) {
                                different_start_poi = t_linkPointInfoArr(start).split(";")(0)
                                different_end_poi = t_linkPointInfoArr(end).split(";")(1)
                                val start_xy: Array[Double] = different_start_poi.split(",").map(_.toDouble)
                                val end_xy: Array[Double] = different_end_poi.split(",").map(_.toDouble)

                                if (start >= 1) different_start_swid = noStandard_rote_swidArr(start - 1)
                                if (end + 1 <= noStandard_rote_swidArr.length - 1) different_end_swid = noStandard_rote_swidArr(end + 1)
                                for (i <- 0 until start) different_start_dist += dr_lengthArr(i)
                                for (i <- end + 1 until dr_lengthArr.length) different_end_dist += dr_lengthArr(i)
                                different_start_line_dist = get_distance2(start_xy(0), start_xy(1), route_start_xy(0).toDouble, route_start_xy(1).toDouble) * 1000
                                different_end_line_dist = get_distance2(end_xy(0), end_xy(1), route_end_xy(0).toDouble, route_end_xy(1).toDouble) * 1000

                                for (i <- start to end) {
                                    different_dist += dr_lengthArr(i)

                                    val linksArr: Array[String] = t_links_unionArr(i).split(",", -1)
                                    different_basic_dist += get_base_mileage(linksArr(4), linksArr(8), linksArr(7), linksArr(5))
                                    different_add_dist += get_subjoin_mileage(linksArr(9), linksArr(11))
                                }

                                val stand_links_unionArr: Array[String] = standard_rote
                                  .split("\\|")

                                val stand_dr_length: Array[Double] = stand_links_unionArr.map(_.split(",", -1)(5).toDouble)

                                if (stand_start != 888888888) {
                                    for (i <- stand_start to stand_end) {
                                        stand_dist += stand_dr_length(i)

                                        val stand_linksArr: Array[String] = stand_links_unionArr(i).split(",", -1)
                                        stand_dist2 += get_base_mileage(stand_linksArr(4), stand_linksArr(8), stand_linksArr(7), stand_linksArr(5))
                                        stand_dist2 += get_subjoin_mileage(stand_linksArr(9), stand_linksArr(11))
                                    }
                                }

                                if (stand_dist != 0) different_compare_dist_ratio = different_dist / stand_dist

                                different_real_dist = different_basic_dist + different_add_dist
                                noStandard_t_distance = nostandard_t_distance_listBuff(k).toDouble
                                different_dist_ratio = different_dist / noStandard_t_distance


                                if (stand_dist2 != 0) different_weighted_compare_dist_ratio = different_real_dist / stand_dist2
                            }

                            union_multi_listBuff.append(UnionMulti(uid, different_route_id, different_num, standard_id, different_start_swid, different_start_poi, different_end_poi,
                                different_end_swid, different_start_dist, different_end_dist, different_dist, different_basic_dist, different_add_dist, different_real_dist,
                                different_dist_ratio, different_start_line_dist, different_end_line_dist, different_compare_dist_ratio, different_weighted_compare_dist_ratio,
                                stand_dist, stand_dist2, noStandard_t_distance, inc_day)
                            )

                        }

                    }
                }
            }
        }

        union_multi_listBuff
    }

    // 差异明细汇总
    def get_route_diff_summary(r: ((String, String), Iterable[Row])): UnionRatio = {
        val (uid, standard_id) = r._1
        val iters: Iterable[Row] = r._2

        // 差异段的数据
        var different_num: Int = 0
        var different_dist: Double = 0.00
        var different_basic_dist: Double = 0.00
        var different_add_dist: Double = 0.00
        var different_real_dist: Double = 0.00
        var different_dist_ratio: Double = 0.00
        var different_compare_dist_ratio: Double = 0.00
        var different_weighted_compare_dist_ratio: Double = 0.00

        var t_distance: Double = 0.00

        // 基准线路数据
        var stand_road_dist: Double = 0.00
        var stand_add_dist: Double = 0.00
        for (elem <- iters) {
            different_dist += elem.getAs[Double]("different_dist")
            different_real_dist += elem.getAs[Double]("different_real_dist")
            different_basic_dist += elem.getAs[Double]("different_basic_dist")
            different_add_dist += elem.getAs[Double]("different_add_dist")

            stand_road_dist += elem.getAs[Double]("stand_road_dist")
            stand_add_dist += elem.getAs[Double]("stand_add_dist")

            t_distance = elem.getAs[Double]("noStandard_t_distance")
            different_num = elem.getAs[Int]("different_num")
        }

        if (t_distance != 0.00) different_dist_ratio = different_dist / t_distance
        if (stand_road_dist != 0.00) different_compare_dist_ratio = different_dist / stand_road_dist
        if (stand_add_dist != 0.00) different_weighted_compare_dist_ratio = different_real_dist / stand_add_dist

        UnionRatio(uid, standard_id, different_num, different_dist, different_basic_dist, different_add_dist,
            different_real_dist, different_dist_ratio, different_compare_dist_ratio, different_weighted_compare_dist_ratio)
    }

}
