package app.supplyMap

import com.alibaba.fastjson.{JSON, JSONObject}
import entry.LineNavi
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.SparkConfigUtil

/**
  * 任务名称：导航里程结算数据明细汇总
  * 任务ID：422807
  * 需求人员：
  * 开发人员：王冬冬 01413698
  */
object GetLineNaviData {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 获取Kafka log信息
        val dlr = '$'
        val logSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.gis_eta_navi_query_hive
               |where
               |  get_json_object(data, '$dlr.subType') = 'sdkNaviLog'
               |  and get_json_object(data, '$dlr.data.type') = '19'
               |  and inc_day >= '$start_time'
               |  and inc_day <= '$end_time'
               |""".stripMargin

        logger.error(logSql)

        // 解析原始数据
        getlineNaviData(spark, logSql)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 解析kafak数据
    def getlineNaviData(spark: SparkSession, sql: String): Unit = {
        import spark.implicits._

        val line_naviDF: DataFrame = spark
          .sql(sql)
          .map(r => {
              val data: String = r.getAs[String]("data")
              val inc_day: String = r.getAs[String]("inc_day")

              val o: JSONObject = JSON.parseObject(data)
              val req_id: String = o.getString("reqId")

              val data2: JSONObject = o.getJSONObject("data")
              val task_id: String = data2.getString("taskId")
              val navi_id: String = data2.getString("naviId")
              val sdk_version: String = data2.getString("sdkVersion")
              val report_time: String = data2.getString("reportTime")
              val navi_strategy: String = data2.getString("naviStrategy")

              var is_return_sta_line: String = ""
              var is_navi_at_start: String = ""
              var is_navi_by_sta_line: String = ""
              var dest_dept_code: String = ""
              var route_time: String = ""
              var drive_time: String = ""
              var is_yaw_by_driver: String = ""

              val operateInfo: JSONObject = data2.getJSONObject("operateInfo")
              if (operateInfo != null && !operateInfo.isEmpty) {
                  val content: String = operateInfo.getString("content")
                  if (content != null && content.nonEmpty) {
                      val o: JSONObject = JSON.parseObject(content)
                      is_return_sta_line = o.getString("isReturnStaLine")
                      is_navi_at_start = o.getString("isNaviAtStart")
                      is_navi_by_sta_line = o.getString("isNaviByStaLine")
                      dest_dept_code = o.getString("destDeptCode")
                      route_time = o.getString("routeTime")
                      drive_time = o.getString("driveTime")
                      is_yaw_by_driver = o.getString("isYawByDriver")
                  }
              }

              LineNavi(task_id, navi_id, sdk_version, req_id, report_time, navi_strategy, is_return_sta_line,
                  is_navi_at_start, is_navi_by_sta_line, dest_dept_code, route_time, drive_time, is_yaw_by_driver, inc_day)
          })
          .toDF()
          .coalesce(10)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, line_naviDF, "从JSON中解析出来的数据")
        df2HiveByOverwrite(logger, line_naviDF, "dm_gis.gis_lind_navi_result")

        line_naviDF.unpersist()
    }

}
