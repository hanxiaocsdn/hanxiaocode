package app.supplyMap

import org.apache.spark.sql.functions.{count, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.SparkConfigUtil

/**
  * 任务名称：每个城市每天AOI的变化量
  * 任务ID：470131
  * 需求人员：金立达 01423784
  * 开发人员：王冬冬 01413698
  */
object AOIChangeIndex {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {

        if (args.length != 1) {
            logger.error(
                """
                  |需要输入1个参数：
                  |    inc_day
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val inc_day: String = args(0)
        logger.error(s"取数日期：$inc_day")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 每个城市AOI发生变化的指标
        getaoiChangeIndex(spark, inc_day)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 每个城市AOI发生变化的指标
    def getaoiChangeIndex(spark: SparkSession, inc_day: String): Unit = {
        val sql: String =
            s"""
               |select
               |  id,
               |  city_code
               |from
               |  dm_gis.cms_aoi_change
               |where
               |  inc_day = '$inc_day'
               |  and change_type = '2'
               |""".stripMargin
        val origDF: DataFrame = getDataFrame(logger, spark, sql, "网点发生变化的原始数据")

        val changeDF: DataFrame = origDF
          .groupBy("city_code")
          .agg(
              count("id").as("change_cnt")
          )
          .withColumn("inc_day", lit(inc_day))
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, changeDF, "每个城市变化网点数")
        df2HiveByOverwrite(logger, changeDF, "dm_gis.cms_aoi_change_index")

        origDF.unpersist()
        changeDF.unpersist()

    }


}
