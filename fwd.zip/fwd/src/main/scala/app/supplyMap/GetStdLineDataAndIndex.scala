package app.supplyMap

import app.runLimited.DealLocusAbnormalDataFromLimited.get_distance2
import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{col, lit, udf}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, GetRDDCountAndSampleData, df2HiveByOverwrite, getRate, getRate2, isEmptyOrNull}
import utils.SparkConfigUtil

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
  * 任务名称：标准线路服务日志解析和指标统计
  * 任务ID：423731
  * 需求人员：
  * 开发人员：王冬冬 01413698
  */
object GetStdLineDataAndIndex {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {
        if (args.length != 4) {
            logger.error(
                """
                  |需要输入3个参数：
                  |    start_time、end_time、one_month_before
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val one_month_before: String = args(2)
        val start_time2: String = args(3)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"30天之前的日期：$one_month_before ")
        logger.error(s"另外一个格式的开始日期：$start_time2 ")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 解析原始数据
        val parseRDD: RDD[JSONObject] = getOrigData(spark, start_time,end_time)

        // type=url_s 请求记录
        parseRequestDetail(spark,parseRDD)

        // type=url_e 返回结果
        parseResultDetail(spark,parseRDD)

        // 指标统计：线路使用率
        getlineUseIndex(spark,parseRDD, one_month_before, end_time)

        // 指标统计: 线路新增率
        getlineIncreaseIndex(spark,parseRDD, start_time2, start_time)

        // 指标统计: 线路一致率
        getlineSameIndex(spark,parseRDD, start_time)

        // 指标统计：线路异常率
        getlineAbnormalIndex(spark,parseRDD, start_time)


        parseRDD.unpersist()

        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 获取原始数据
    def getOrigData(spark: SparkSession, start_time: String,end_time:String): RDD[JSONObject] = {
        // 获取log信息
        val logSql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.eta_std_line_log
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin
        logger.error("解析的原始数据:" + logSql)

        val parseRDD: RDD[JSONObject] = spark
          .sql(logSql)
          .rdd
          .map(r => {
              val inc_day: String = r.getAs[String]("inc_day")
              val d: String = r.getAs[String]("data")

              val res: JSONObject = new JSONObject()

              val data_json: JSONObject = JSON.parseObject(d)
              val message: JSONObject = data_json.getJSONObject("message")

              val sn: String = message.getString("sn")
              val ak: String = message.getJSONObject("url").getString("ak")
              res.put("sn", sn)
              res.put("ak", ak)
              res.put("inc_day", inc_day)

              val `type`: String = message.getString("type")
              res.put("type", `type`)

              if (`type` == "url_s") {
                  val url: String = message.getJSONObject("url").getString("url")
                  val o: JSONObject = parseUrl(url)
                  res.fluentPutAll(o)
              } else if (`type` == "url_e") {
                  val o: JSONObject = parseMessage(message)
                  res.fluentPutAll(o)
              }

              res
          })
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetRDDCountAndSampleData(logger,parseRDD,"解析过后的数据")

        parseRDD
    }

    // 把url的k v 封装成JSON
    def parseUrl(url: String): JSONObject = {
        val o: JSONObject = new JSONObject()

        val url_arr: Array[String] = url.split("\\?")
        try {
            val arr: Array[String] = url_arr(1).split("&")
            arr.foreach(i => {
                val kv: Array[String] = i.split("=")
                o.put(kv(0), kv(1))
            })
        } catch {
            case e: Exception => println("url:" + e.getMessage)
        }

        o
    }

    def parseMessage(message: JSONObject): JSONObject = {
        val o: JSONObject = new JSONObject()

        val data: JSONObject = message.getJSONObject("data")
        val status: String = data.getString("status")
        o.put("status", status)
        val mload: String = message.getJSONObject("url").getString("mload")
        o.put("mload", mload)

        var vehicle: String = ""
        if (mload != null) {
            if (mload <= "1.0") vehicle = "5"
            else if (mload <= "3.0") vehicle = "6"
            else if (mload < "7.0") vehicle = "7"
            else vehicle = "8"
        } else vehicle = message.getJSONObject("url").getString("vehicle")

        o.put("vehicle", vehicle)

        val result: JSONObject = data.getJSONObject("result")
        val src: String = result.getString("src")
        val stdId: String = result.getString("stdId")
        o.put("src", src)
        o.put("stdId", stdId)

        val query: JSONObject = result.getJSONObject("query")
        if (query != null && !query.isEmpty) {
            val lineCode: String = query.getString("lineCode")
            val planTime: String = query.getString("planTime")

            val start: JSONObject = query.getJSONObject("start")
            val end: JSONObject = query.getJSONObject("end")

            val start_x: String = start.getString("x")
            val start_y: String = start.getString("y")
            val start_zoneCode: String = start.getString("zoneCode")
            val end_x: String = end.getString("x")
            val end_y: String = end.getString("y")
            val end_zoneCode: String = end.getString("zoneCode")

            o.put("start_x", start_x)
            o.put("start_y", start_y)
            o.put("start_zoneCode", start_zoneCode)
            o.put("end_x", end_x)
            o.put("end_y", end_y)
            o.put("end_zoneCode", end_zoneCode)
            o.put("lineCode", lineCode)
            o.put("planTime", planTime)
        }

        o
    }

    // 获取线路总数
    def getLineCnt(spark: SparkSession): DataFrame = {
        val sql: String =
            """
              |select
              |  count(std_id) line_cnt
              |from
              |  dm_gis.eta_std_line_conf
              |where
              |  delete_flag = '0'
              |""".stripMargin
        val cnt: DataFrame = spark.sql(sql)
        cnt
    }

    // 获取std_id去重后的总数(近1个月)
    def getStdidCnt(spark: SparkSession, one_month_before: String, end_time: String): DataFrame = {
        val sql: String =
            s"""
               |select
               |  size(collect_set(std_id)) std_id_cnt
               |from
               |  dm_gis.eta_std_line_result_detail
               |where
               |  status = '0'
               |  and inc_day >= '$one_month_before'
               |  and inc_day < '$end_time'
               |""".stripMargin
        val cnt: DataFrame = spark.sql(sql)
        cnt
    }

    // 配置表中is_econ来源占比、新增数量
    def getIseconRate(spark: SparkSession, start_time2: String, start_time: String): DataFrame = {
        val sql: String =
            s"""
               |select
               |  count(1) conf_cnt,
               |  sum(if(is_econ='1',1,0)) src1_cnt,
               |  sum(if(is_econ='2',1,0)) src2_cnt,
               |  sum(if(is_econ='3',1,0)) src3_cnt,
               |  sum(if(is_econ='4',1,0)) src4_cnt,
               |  sum(if(is_econ='5',1,0)) src5_cnt,
               |  sum(if(is_econ='6',1,0)) src6_cnt
               |from
               |(
               |select
               |  distinct(std_id),
               |  is_econ
               |from
               |  dm_gis.eta_std_line_conf
               |where
               |  create_time >= '$start_time2 00:00:00'
               |  and create_time <= '$start_time2 23:59:59'
               |) t
               |
               |""".stripMargin

        val df: DataFrame = spark
          .sql(sql)
          .withColumn("src1", getRate2(col("src1_cnt"), col("conf_cnt")))
          .withColumn("src2", getRate2(col("src2_cnt"), col("conf_cnt")))
          .withColumn("src3", getRate2(col("src3_cnt"), col("conf_cnt")))
          .withColumn("src4", getRate2(col("src4_cnt"), col("conf_cnt")))
          .withColumn("src5", getRate2(col("src5_cnt"), col("conf_cnt")))
          .withColumn("src6", getRate2(col("src6_cnt"), col("conf_cnt")))
          .withColumn("inc_day", lit(start_time))
          .drop("src1_cnt", "src2_cnt", "src3_cnt", "src4_cnt", "src5_cnt", "src6_cnt")

        df
    }

    // 返回2个ak一直率
    def getSameRate(ds1: Dataset[Row], ds2: Dataset[Row]): String = {
        // 线路一致的数量
        val cnt1: Long = ds1
          .join(ds2, Seq("lineCode", "start_zoneCode", "end_zoneCode", "vehicle"))
          .count()

        // stdId一致的数量
        val cnt2: Long = ds1
          .join(ds2, Seq("lineCode", "start_zoneCode", "end_zoneCode", "vehicle", "stdId", "inc_day"))
          .count()

        val rate: String = getRate(cnt2, cnt1)
        rate
    }

    // 获取长期未使用线路比例
    def getLongUnuseRate: UserDefinedFunction = udf((line_cnt: Int, std_id_cnt: Int) => {
        val request_sn2: Double = (line_cnt - std_id_cnt).toDouble
        val rate: String = (request_sn2 * 100 / line_cnt).formatted("%.2f") + "%"
        rate
    })

    // 判断2个网点距离是否大于500米
    def getZoneCodeDist: UserDefinedFunction = udf((x1: String, y1: String, x2: String, y2: String) => {
        var flag: Int = 0

        if (!isEmptyOrNull(x1) && !isEmptyOrNull(x2) && !isEmptyOrNull(y1) && !isEmptyOrNull(y2)) {
            val d: Double = get_distance2(x1.toDouble, y1.toDouble, x2.toDouble, y2.toDouble) * 1000
            if (d > 500) flag = 1
        }

        flag
    })

    // 根据ak 对线路编码 始终网点 车型去重
    def getDistantedLineByAk(spark: SparkSession, parseRDD: RDD[JSONObject], ak: String): Dataset[Row] = {
        import spark.implicits._

        val df: Dataset[Row] = parseRDD
          .filter(_.getString("type") == "url_e")
          .filter(_.getString("status") == "0")
          .filter(_.getString("ak") == ak)
          .map(o => {

              val lineCode: String = o.getString("lineCode")
              val start_zoneCode: String = o.getString("start_zoneCode")
              val end_zoneCode: String = o.getString("end_zoneCode")
              val vehicle: String = o.getString("vehicle")
              val stdId: String = o.getString("stdId")
              val inc_day: String = o.getString("inc_day")

              (lineCode, start_zoneCode, end_zoneCode, vehicle, stdId, inc_day)
          })
          .toDF("lineCode", "start_zoneCode", "end_zoneCode", "vehicle", "stdId", "inc_day")
          .dropDuplicates("lineCode", "start_zoneCode", "end_zoneCode", "vehicle", "inc_day")

        df
    }

    // 标准线路导航返回率
    def getNaviReturnRate(parseRDD: RDD[JSONObject], ak: String): String = {
        val cnt1: Long = parseRDD
          .filter(_.getString("type") == "url_e")
          .filter(_.getString("status") == "0")
          .filter(_.getString("ak") == ak)
          .count()

        val cnt2: Long = parseRDD
          .filter(_.getString("type") == "url_s")
          .filter(_.getString("ak") == ak)
          .count()

        val rate: String = getRate(cnt1, cnt2)
        rate
    }

    // 标准线路日志请求记录表网点数
    def getZoneCodeCnt(spark: SparkSession, parseRDD: RDD[JSONObject]): Long = {
        import spark.implicits._

        val df: DataFrame = parseRDD
          .filter(_.getString("type") == "url_s")
          .map(o => {
              val srcZoneCode: String = o.getString("srcZoneCode")
              val destZoneCode: String = o.getString("destZoneCode")
              (srcZoneCode, destZoneCode)
          })
          .toDF("srcZoneCode", "destZoneCode")

        val df2: DataFrame = df.select("srcZoneCode")
        val df3: DataFrame = df.select("destZoneCode")

        val cnt: Long = df2
          .union(df3)
          .dropDuplicates("srcZoneCode")
          .count()
        cnt
    }

    // 网点经纬度不一致数量
    def getZoneCodeUnsameCnt(spark: SparkSession, parseRDD: RDD[JSONObject]): Long = {
        import spark.implicits._

        // 请求数据
        val df1: DataFrame = parseRDD
          .filter(_.getString("type") == "url_s")
          .map(o => {

              val srcZoneCode: String = o.getString("srcZoneCode")
              val destZoneCode: String = o.getString("destZoneCode")
              val x1: String = o.getString("x1")
              val y1: String = o.getString("y1")
              val x2: String = o.getString("x2")
              val y2: String = o.getString("y2")

              (srcZoneCode, x1, y1, destZoneCode, x2, y2)
          })
          .toDF("srcZoneCode", "x1", "y1", "destZoneCode", "x2", "y2")


        val df11: DataFrame = df1.select("srcZoneCode", "x1", "y1")
        val df12: DataFrame = df1.select("destZoneCode", "x2", "y2")
        val df13: Dataset[Row] = df11
          .union(df12)
          .dropDuplicates("srcZoneCode")

        // 返回结果数据
        val df2: DataFrame = parseRDD
          .filter(_.getString("type") == "url_e")
          .filter(_.getString("status") == "0")
          .map(o => {

              val start_zoneCode: String = o.getString("start_zoneCode")
              val start_x: String = o.getString("start_x")
              val start_y: String = o.getString("start_y")
              val end_zoneCode: String = o.getString("end_zoneCode")
              val end_x: String = o.getString("end_x")
              val end_y: String = o.getString("end_y")
              (start_zoneCode, start_x, start_y, end_zoneCode, end_x, end_y)
          })
          .toDF("start_zoneCode", "start_x", "start_y", "end_zoneCode", "end_x", "end_y")

        val df21: DataFrame = df2.select("start_zoneCode", "start_x", "start_y")
        val df22: DataFrame = df2.select("end_zoneCode", "end_x", "end_y")
        val df23: Dataset[Row] = df21
          .union(df22)
          .dropDuplicates("start_zoneCode")

        val cnt: Long = df13
          .join(df23, df13("srcZoneCode") === df23("start_zoneCode"), "inner")
          .withColumn("start_flag", getZoneCodeDist($"x1", $"y1", $"start_x", $"start_y"))
          .filter("start_flag=1")
          .count()

        cnt
    }

    // 调用无返回数量 及 占比
    def getNoReturnCntAndRate(spark: SparkSession, parseRDD: RDD[JSONObject]): (Long, String) = {
        import spark.implicits._

        // 调用无返回数量
        val cnt1: Long = parseRDD
          .filter(_.getString("type") == "url_e")
          .filter(_.getString("status") == "1")
          .map(_.getString("sn"))
          .toDF("sn")
          .dropDuplicates()
          .count()

        // 标准线路日志结果表sn去重
        val cnt2: Long = parseRDD
          .filter(_.getString("type") == "url_e")
          .map(_.getString("sn"))
          .toDF("sn")
          .dropDuplicates()
          .count()

        val rate: String = getRate(cnt1, cnt2)
        (cnt1, rate)
    }

    // 解析请求记录 type=url_s
    def parseRequestDetail(spark: SparkSession, parseRDD: RDD[JSONObject]): Unit = {
        import spark.implicits._

        val requestDF: DataFrame = parseRDD
          .filter(_.getString("type") == "url_s")
          .map(o => {
              val sn: String = o.getString("sn")
              val ak: String = o.getString("ak")
              val lineCode: String = o.getString("lineCode")
              val srcZoneCode: String = o.getString("srcZoneCode")
              val destZoneCode: String = o.getString("destZoneCode")
              val planTime: String = o.getString("planTime")
              val mLoad: String = o.getString("mLoad")
              val x1: String = o.getString("x1")
              val y1: String = o.getString("y1")
              val x2: String = o.getString("x2")
              val y2: String = o.getString("y2")
              val inc_day: String = o.getString("inc_day")

              (sn, ak, lineCode, srcZoneCode, destZoneCode, planTime, mLoad, x1, y1, x2, y2, inc_day)
          })
          .toDF()
          .coalesce(50)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, requestDF, "请求记录数据")
        df2HiveByOverwrite(logger, requestDF, "dm_gis.eta_std_line_request_detail")
        requestDF.unpersist()
    }

    // 解析返回结果 type=url_e
    def parseResultDetail(spark: SparkSession, parseRDD: RDD[JSONObject]): Unit = {
        import spark.implicits._

        val resultDF: DataFrame = parseRDD
          .filter(_.getString("type") == "url_e")
          .map(o => {
              val sn: String = o.getString("sn")
              val ak: String = o.getString("ak")
              val status: String = o.getString("status")
              val stdId: String = o.getString("stdId")
              val start_zoneCode: String = o.getString("start_zoneCode")
              val start_x: String = o.getString("start_x")
              val start_y: String = o.getString("start_y")
              val end_zoneCode: String = o.getString("end_zoneCode")
              val end_x: String = o.getString("end_x")
              val end_y: String = o.getString("end_y")
              val src: String = o.getString("src")
              val lineCode: String = o.getString("lineCode")
              val planTime: String = o.getString("planTime")
              val mload: String = o.getString("mload")
              val vehicle: String = o.getString("vehicle")
              val inc_day: String = o.getString("inc_day")

              (sn, ak, status, stdId, start_zoneCode, start_x, start_y, end_zoneCode, end_x, end_y, src, lineCode, planTime, mload, vehicle, inc_day)
          })
          .toDF()
          .coalesce(50)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, resultDF, "返回结果数据")
        df2HiveByOverwrite(logger, resultDF, "dm_gis.eta_std_line_result_detail")

        resultDF.unpersist()
    }

    // 计算线路使用率指标
    def getlineUseIndex(spark: SparkSession, parseRDD: RDD[JSONObject], one_month_before: String, end_time: String): Unit = {
        import spark.implicits._

        val line_useDF: DataFrame = parseRDD
          .filter(_.getString("type") == "url_e")
          .filter(_.getString("status") == "0")
          .groupBy(o => {
              val inc_day: String = o.getString("inc_day")
              val ak: String = o.getString("ak")
              (inc_day, ak)
          })
          .map(r => {
              val (inc_day, ak) = r._1
              val iters: Iterable[JSONObject] = r._2

              val stdId_listBuff = new ListBuffer[String]
              val sn_set = new mutable.HashSet[String]()
              val src_listBuff = new ListBuffer[String]
              for (o <- iters) {
                  val stdId: String = o.getString("stdId")
                  val src: String = o.getString("src")
                  if (!stdId_listBuff.contains(stdId)) {
                      stdId_listBuff.append(stdId)
                      src_listBuff.append(src)
                  }

                  val sn: String = o.getString("sn")
                  sn_set.add(sn)
              }

              // 线路使用量
              val line_use_cnt: Int = stdId_listBuff.size
              // 返回结果中的sn数量
              val result_sn: Int = sn_set.size

              // 线路来源占比
              val src1: String = getRate(src_listBuff.count(_ == "1"), line_use_cnt)
              val src2: String = getRate(src_listBuff.count(_ == "2"), line_use_cnt)
              val src3: String = getRate(src_listBuff.count(_ == "3"), line_use_cnt)
              val src4: String = getRate(src_listBuff.count(_ == "4"), line_use_cnt)
              val src5: String = getRate(src_listBuff.count(_ == "5"), line_use_cnt)
              val src6: String = getRate(src_listBuff.count(_ == "6"), line_use_cnt)

              (inc_day, ak, line_use_cnt, result_sn, src1, src2, src3, src4, src5, src6)
          })
          .toDF("inc_day", "ak", "line_use_cnt", "result_sn", "src1", "src2", "src3", "src4", "src5", "src6")

        val request_snDF: DataFrame = parseRDD
          .filter(_.getString("type") == "url_s")
          .groupBy(o => {
              val inc_day: String = o.getString("inc_day")
              val ak: String = o.getString("ak")
              (inc_day, ak)
          })
          .map(r => {
              val (inc_day, ak) = r._1
              val iters: Iterable[JSONObject] = r._2

              val sn_set = new mutable.HashSet[String]()
              for (o <- iters) sn_set.add(o.getString("sn"))
              val request_sn: Int = sn_set.size

              (inc_day, ak, request_sn)
          })
          .toDF("inc_day", "ak", "request_sn")

        val line_stdDF: DataFrame = getLineCnt(spark).crossJoin(getStdidCnt(spark, one_month_before, end_time))

        val line_use_rateDF: DataFrame = line_useDF
          .join(request_snDF, Seq("inc_day", "ak"))
          .crossJoin(line_stdDF)
          .withColumn("line_use_rate", getRate2($"line_use_cnt", $"line_cnt"))
          .withColumn("line_return_rate", getRate2($"result_sn", $"request_sn"))
          .withColumn("long_unuse_rate", getLongUnuseRate($"line_cnt", $"std_id_cnt"))
          .withColumn("incday", $"inc_day")
          .drop("result_sn", "request_sn", "std_id_cnt", "inc_day")
          .withColumnRenamed("incday", "inc_day")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, line_use_rateDF, "线路使用率数据")
        df2HiveByOverwrite(logger, line_use_rateDF, "dm_gis.eta_std_line_use_rate_index")

        line_use_rateDF.unpersist()
    }

    // 计算线路新增率指标
    def getlineIncreaseIndex(spark: SparkSession, parseRDD: RDD[JSONObject], start_time2: String, start_time: String): Unit = {
        import spark.implicits._

        val confDF: DataFrame = getIseconRate(spark, start_time2, start_time)

        val resultDF: DataFrame = parseRDD
          .filter(_.getString("type") == "url_e")
          .filter(_.getString("status") == "0")
          .filter(_.getString("stdId") == null)
          .groupBy(o => {
              val inc_day: String = o.getString("inc_day")
              val ak: String = o.getString("ak")
              (inc_day, ak)
          })
          .map(r => {
              val (inc_day, ak) = r._1
              val temp_line_cnt: Int = r._2.size
              (inc_day, ak, temp_line_cnt)
          })
          .toDF("inc_day", "ak", "temp_line_cnt")

        val line_increaseDF: Dataset[Row] = confDF
          .join(resultDF, Seq("inc_day"))
          .withColumn("increase_cnt", $"temp_line_cnt" + $"conf_cnt")
          .withColumn("temp_line_rate", getRate2($"temp_line_cnt", $"increase_cnt"))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, line_increaseDF, "线路新增率数据")
        df2HiveByOverwrite(logger, line_increaseDF, "dm_gis.eta_std_line_increase_rate_index")

        line_increaseDF.unpersist()
    }

    // 计算线路一致率
    def getlineSameIndex(spark: SparkSession, parseRDD: RDD[JSONObject], start_time: String): Unit = {
        val (pass, omss, navi) = ("bf8b2794a73f42e9b0a3db295d229cb0", "01b136b4864ae489be25c900c2c4c871", "734b659565764b0f99bc6533da1a2b91")

        val passDS: Dataset[Row] = getDistantedLineByAk(spark, parseRDD, pass).persist(StorageLevel.MEMORY_AND_DISK)
        val omssDS: Dataset[Row] = getDistantedLineByAk(spark, parseRDD, omss).persist(StorageLevel.MEMORY_AND_DISK)
        val naviDS: Dataset[Row] = getDistantedLineByAk(spark, parseRDD, navi).persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, passDS, "pass线路的数据", 3)
        GetDFCountAndSampleData(logger, omssDS, "omss线路的数据", 3)
        GetDFCountAndSampleData(logger, naviDS, "navi线路的数据", 3)

        val p_o_same_rate: String = getSameRate(passDS, omssDS)
        val p_n_same_rate: String = getSameRate(passDS, naviDS)
        val o_n_same_rate: String = getSameRate(omssDS, naviDS)

        val line_sameDF: Dataset[Row] = spark
          .createDataFrame(Seq(
              (p_o_same_rate, p_n_same_rate, o_n_same_rate, start_time)
          ))
          .toDF("p_o_same_rate", "p_n_same_rate", "o_n_same_rate", "inc_day")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, line_sameDF, "线路一致率数据")
        df2HiveByOverwrite(logger, line_sameDF, "dm_gis.eta_std_line_same_rate_index")

        passDS.unpersist()
        omssDS.unpersist()
        naviDS.unpersist()
        line_sameDF.unpersist()
    }

    // 计算线路异常率
    def getlineAbnormalIndex(spark: SparkSession, parseRDD: RDD[JSONObject], start_time: String): Unit = {

        val navi_return_rate: String = getNaviReturnRate(parseRDD, "734b659565764b0f99bc6533da1a2b91")
        val zone_code_unsame_cnt: Long = getZoneCodeUnsameCnt(spark: SparkSession, parseRDD: RDD[JSONObject])
        val zone_cnt: Long = getZoneCodeCnt(spark, parseRDD)
        val zone_code_unsame_rate: String = getRate(zone_code_unsame_cnt, zone_cnt)
        val (no_return_cnt, no_return_rate) = getNoReturnCntAndRate(spark: SparkSession, parseRDD: RDD[JSONObject])

        val line_abnormalDF: Dataset[Row] = spark
          .createDataFrame(Seq(
              (navi_return_rate, zone_code_unsame_cnt, zone_code_unsame_rate, no_return_cnt, no_return_rate, start_time)
          ))
          .toDF("navi_return_rate", "zone_code_unsame_cnt", "zone_unsame_rate", "no_return_cnt", "no_return_cnt_rate", "start_time")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, line_abnormalDF, "线路异常率数据")
        df2HiveByOverwrite(logger, line_abnormalDF, "dm_gis.eta_std_line_abnormal_rate_index")

        line_abnormalDF.unpersist()
    }

}
