package app.supplyMap

import org.apache.spark.sql.functions.trim
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByAppend}
import utils.SparkConfigUtil

/**
  * 任务名称：标准线路任务监控数据回溯
  * 任务ID：429725
  * 需求人员：王润泽 01422002
  * 开发人员：王冬冬 01413698
  */
object GetEtaStdLineRecallData {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {

        if (args.length != 1) {
            logger.error(
                """
                  |需要输入1个参数：
                  |    inc_day
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val inc_day: String = args(0)
        logger.error(s"取数日期：$inc_day")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)


        val sql1: String =
            s"""
               |select
               |  task_area_code,
               |  task_id,
               |  sort_num,
               |  task_subid,
               |  start_dept,
               |  end_dept,
               |  start_type,
               |  end_type,
               |  line_code,
               |  vehicle_serial,
               |  actual_capacity_load,
               |  plan_depart_tm,
               |  actual_depart_tm,
               |  plan_arrive_tm,
               |  actual_arrive_tm,
               |  driver_id,
               |  driver_name,
               |  line_time,
               |  line_distance,
               |  actual_run_time,
               |  start_longitude,
               |  start_latitude,
               |  end_longitude,
               |  end_latitude,
               |  is_stop,
               |  transoport_level,
               |  carrier_type,
               |  plf_flag,
               |  vehicle_type,
               |  axls_number,
               |  log_dist,
               |  rt_coords,
               |  x1,
               |  y1,
               |  x2,
               |  y2,
               |  duration,
               |  time,
               |  rt_dist,
               |  highwaymileage,
               |  toll_charge,
               |  start_distance,
               |  end_distance,
               |  error_type,
               |  pns_dist,
               |  pns_time,
               |  src,
               |  std_coords,
               |  line_distance_std,
               |  line_time_std,
               |  sim1,
               |  sim5,
               |  diffdist_rt_line,
               |  diffratio_rt_line,
               |  diffdist_rt_std,
               |  diffratio_rt_std,
               |  diffdist_rt_log,
               |  diffratio_rt_log,
               |  diffdist_line_log,
               |  diffratio_line_log,
               |  diffdist_line_std,
               |  diffratio_line_std,
               |  diffdist_log_std,
               |  diffratio_log_std,
               |  conduct_type,
               |  difftime_line_std,
               |  diffratio1_line_std,
               |  difftime_line_std_10min,
               |  difftime_line_rt,
               |  diffratio1_line_rt,
               |  difftime_rt_gh_10min,
               |  is_run_ontime_std,
               |  is_run_ontime,
               |  if_dist_equal,
               |  if_time_equal,
               |  pns_error,
               |  task_inc_day,
               |  difftime_std_rt,
               |  diffratio1_std_rt,
               |  difftime_std_rt_10min,
               |  tl_time,
               |  halfway_integrate_rate,
               |  std_x1,
               |  std_y1,
               |  std_x2,
               |  std_y2,
               |  start_distance_std,
               |  end_distance_std,
               |  std_line_error,
               |  ac_difftime_line_rt,
               |  ac_diffratio1_line_rt,
               |  ac_difftime_rt_gh_10min,
               |  ac_difftime_std_rt,
               |  ac_diffratio1_std_rt,
               |  ac_difftime_std_rt_10min,
               |  ac_is_run_ontime_std,
               |  ac_is_run_ontime,
               |  if_evaluate_time,
               |  carrier_name,
               |  stop_over_zone_code,
               |  biz_type,
               |  require_category,
               |  to_ground,
               |  std_toll_charge,
               |  std_id,
               |  navi_strategy,
               |  is_return_std_line,
               |  is_navi_at_start,
               |  is_navi_by_std_line,
               |  route_time,
               |  drive_time,
               |  is_yaw_by_driver,
               |  navi_complete_rate,
               |  accrual_dist,
               |  accrual_dist_type,
               |  last_update_tm,
               |  main_driver_account,
               |  sf_outer_vehicle_from
               |from
               |  dm_gis.eta_std_line_recall
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin
        val sql2: String =
            s"""
               |select
               |  task_area_code,
               |  task_id,
               |  carrier_name,
               |  task_inc_day,
               |  start_dept,
               |  start_type,
               |  line_code,
               |  vehicle_serial,
               |  actual_capacity_load,
               |  plan_depart_tm,
               |  actual_depart_tm,
               |  driver_id,
               |  driver_name,
               |  is_stop,
               |  transoport_level,
               |  carrier_type,
               |  plf_flag,
               |  vehicle_type,
               |  axls_number,
               |  log_dist,
               |  if_evaluate_time,
               |  stop_over_zone_code,
               |  end_dept,
               |  end_type,
               |  plan_arrive_tm,
               |  actual_arrive_tm,
               |  line_time,
               |  line_distance,
               |  actual_run_time,
               |  duration,
               |  time,
               |  rt_dist,
               |  highwaymileage,
               |  toll_charge,
               |  pns_dist,
               |  pns_time,
               |  std_toll_charge,
               |  if_error,
               |  src,
               |  conduct_type,
               |  ac_is_run_ontime,
               |  diffdist_log_rt,
               |  diffratio_log_rt,
               |  accrual_dist,
               |  accrual_dist_type,
               |  last_update_tm,
               |  main_driver_account
               |from
               |  dm_gis.eta_std_line_recall1
               |where
               |  inc_day = '$inc_day'
               |""".stripMargin

        logger.error(sql1)
        logger.error(sql2)

        // 回溯表1
        repartitionTable(spark, sql1, "dm_gis.eta_std_line_recall_result")
        // 回溯表2
        repartitionTable(spark, sql2, "dm_gis.eta_std_line_recall_result2")


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    def repartitionTable(spark: SparkSession, sql: String, table: String): Unit = {
        import spark.implicits._

        val df: DataFrame = spark
          .sql(sql)
          .withColumn("inc_day", trim($"task_inc_day"))
          .drop( "task_inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, df, "原始数据")
        df2HiveByAppend(logger, df.coalesce(3), table)
        df.unpersist()
    }


}
