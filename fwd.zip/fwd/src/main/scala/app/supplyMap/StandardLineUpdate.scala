package app.supplyMap

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.HttpClientUtil.getJsonByGet
import utils.HttpConnection.{httpPost, sendPost}
import utils.SparkConfigUtil

import java.util
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}


/**
  * 名称：标准线路更新
  * 任务ID：467757
  * 需求人员：李建飞 01413751
  * 开发人员：王冬冬 01413698
  */
object StandardLineUpdate {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val track_similarity_url: String = config.getString("track_similarity_url")
    val std_service_url: String = config.getString("std_service_url")
    val std_service_url2: String = config.getString("std_service_url2")
    val std_update_service_url: String = config.getString("std_update_service_url")
    val qm_url: String = config.getString("qm_url")

    def main(args: Array[String]): Unit = {

        // 接收外部传递进来的变量
        val inc_day: String = args(0)
        logger.error(s"跑数日期：$inc_day")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 原始数据预处理
        val origRDD: RDD[JSONObject] = getOrigData(spark, inc_day)
        // 原始数据做tag
        val origTagDF: DataFrame = getOrigTagData(spark, origRDD, inc_day)
        // 每条数据打grp
        val origGrpsDF: DataFrame = getGrpsDetail(spark, origTagDF, inc_day)
        // 异常数据标记
        val grpAllDF: DataFrame = getGrpMark(spark, origTagDF, origGrpsDF, inc_day)
        // 匹配服务 之后的数据
        val checkLineDF: DataFrame = getCheckLine(spark, origGrpsDF, inc_day)
        // 筛选线路
        val replaceDF: DataFrame = getReplaceLine(spark, grpAllDF, checkLineDF, inc_day)
        // 更新线路
        val updateDF: DataFrame = updateLineData(spark, replaceDF, inc_day)

        // 修复原始线路
        lineFixed(spark, updateDF, inc_day)


        logger.error("运行结束！")
        // 程序运行结束,关闭spark
        spark.stop()
    }

    def getTag(d: Double): String = {
        if (d == 0) "0%"
        else if (d <= 0.1) "0%~10%"
        else if (d <= 0.2) "10%~20%"
        else if (d <= 0.3) "20%~30%"
        else if (d <= 0.4) "30%~40%"
        else if (d <= 0.5) "40%~50%"
        else if (d <= 0.6) "50%~60%"
        else if (d <= 0.7) "60%~70%"
        else if (d <= 0.8) "70%~80%"
        else if (d <= 0.9) "80%~90%"
        else if (d < 1.0) "90%~99.99%"
        else if (d == 1) "100%"
        else ""
    }

    def getNumberByID(arr: Array[JSONObject]): (Int, Int, Int, Int, Double, Double) = {
        val num: Int = arr.length
        val conduct_num: Int = arr.count(_.getString("conduct_type") == "1")
        val not_conduct_num: Int = arr.count(_.getString("conduct_type") == "3")
        val ontime_num: Int = arr.count(_.getString("ac_is_run_ontime") == "1.0")

        val conduct_rate: Double = (conduct_num.toDouble / num).formatted("%.2f").toDouble
        val ontime_rate: Double = (ontime_num.toDouble / num).formatted("%.2f").toDouble

        (num, conduct_num, not_conduct_num, ontime_num, conduct_rate, ontime_rate)
    }

    // 格式化 coords
    def formatCoords(coords: String): JSONArray = {

        val tracks2Arr: Array[String] = coords
          .replaceAll("\\[", "")
          .replaceAll("],", ";")
          .replaceAll("]]", "")
          .split(";")

        val tracksArr: JSONArray = new JSONArray()
        for (i <- tracks2Arr.indices) {
            val xy: Array[Double] = tracks2Arr(i).split(",").map(_.toDouble)
            val obj = new JSONObject()
            obj.put("x", xy(0))
            obj.put("y", xy(1))
            obj.put("type", 1)
            tracksArr.add(obj)
        }

        tracksArr
    }

    // 格式化 coords
    def formatCoords2(coords: String): JSONArray = {
        val tracks2Arr: Array[String] = coords.split("\\|")

        val tracksArr: JSONArray = new JSONArray()
        for (i <- tracks2Arr.indices) {
            val xy: Array[Double] = tracks2Arr(i).split(",").map(_.toDouble)
            val obj = new JSONObject()
            obj.put("x", xy(0))
            obj.put("y", xy(1))
            obj.put("type", 1)
            tracksArr.add(obj)
        }

        tracksArr
    }

    // 解析接口返回的json
    def parseSimiJson(jsonStr: String): Array[Double] = {
        val arr = new Array[Double](2)
        try {
            val o2: JSONObject = JSON.parseObject(jsonStr)
            val status: String = o2.getString("status")
            if (status == "0") {
                logger.error("相似度接口调用成功，业务逻辑处理中……")
                val result: JSONObject = o2.getJSONObject("result")
                arr(0) = result.getDoubleValue("similarity1")
                arr(1) = result.getDoubleValue("similarity2")
            }
        } catch {
            case e: Exception => logger.error("相似度接口调用失败:" + e.getMessage)
        }
        arr
    }

    // 获取2条轨迹的相似度
    def gettrackSimilarity(ak: String, o1: JSONObject, o2: JSONObject): Double = {
        val coord_list1: String = o1.getString("rt_coords")
        val coord_list2: String = o2.getString("rt_coords")

        val coordArr1: JSONArray = formatCoords(coord_list1)
        val coordArr2: JSONArray = formatCoords(coord_list2)

        val parm: JSONObject = new JSONObject()
        parm.put("ak", ak)
        parm.put("vehicle", 5)
        parm.put("retflag", 5)
        parm.put("tracktype", 0)
        parm.put("tracks1", coordArr1)
        parm.put("tracks2", coordArr2)
        val jsonStr: String = httpPost(3, track_similarity_url, parm.toJSONString)
        val similArr: Array[Double] = parseSimiJson(jsonStr)

        val simil: Double = similArr.max
        simil
    }

    // 按key打grp
    def groupRoute2(ak: String, arr: Array[JSONObject]): ArrayBuffer[ArrayBuffer[JSONObject]] = {

        val groupArray2 = new ArrayBuffer[ArrayBuffer[JSONObject]]()
        var grp2_cnt = 0

        for (o <- arr) {
            var tag2: Int = 0
            if (grp2_cnt == 0) {
                grp2_cnt = grp2_cnt + 1
                o.put("grp2", o.getString("grp1") + "_" + grp2_cnt)
                val arr_tmp = new ArrayBuffer[JSONObject]()
                arr_tmp.append(o)
                groupArray2.append(arr_tmp)
            } else {

                breakable {

                    for (array2 <- groupArray2) {
                        val rt_coords: String = o.getString("rt_coords")
                        val rt_coords2: String = array2(0).getString("rt_coords")
                        if (!isEmptyOrNull(rt_coords) && rt_coords.length > 3 && !isEmptyOrNull(rt_coords2) && rt_coords2.length > 3) {
                            val simil: Double = gettrackSimilarity(ak, o, array2(0))
                            if (simil >= 0.85) {
                                val grp2: String = array2(0).getString("grp2")
                                o.put("grp2", grp2)
                                array2.append(o)
                                tag2 = 1
                                break()
                            }
                        }
                    }

                    if (tag2 == 0) {
                        grp2_cnt = grp2_cnt + 1
                        o.put("grp2", o.getString("grp1") + "_" + grp2_cnt)
                        val arr_tmp = new ArrayBuffer[JSONObject]()
                        arr_tmp.append(o)
                        groupArray2.append(arr_tmp)
                    }


                }

            }


        }


        groupArray2
    }

    // 按key打grp
    def groupRoute3(ak: String, arr: Array[JSONObject]): ArrayBuffer[ArrayBuffer[JSONObject]] = {

        val groupArray3 = new ArrayBuffer[ArrayBuffer[JSONObject]]()
        var grp3_cnt = 0

        for (o <- arr) {
            var tag3: Int = 0
            if (grp3_cnt == 0) {
                grp3_cnt = grp3_cnt + 1
                val o_tmp = new JSONObject()
                o_tmp.put("grp3", o.getString("grp2") + "_" + grp3_cnt)
                o_tmp.fluentPutAll(o)
                val arr_tmp = new ArrayBuffer[JSONObject]()
                arr_tmp.append(o_tmp)
                groupArray3.append(arr_tmp)
            } else {

                breakable {

                    val rt_coords: String = o.getString("rt_coords")
                    for (array2 <- groupArray3) {
                        val rt_coords2: String = array2(0).getString("rt_coords")
                        if (!isEmptyOrNull(rt_coords) && rt_coords.length > 3 && !isEmptyOrNull(rt_coords2) && rt_coords2.length > 3) {
                            val simil: Double = gettrackSimilarity(ak, o, array2(0))
                            if (simil >= 0.9) {
                                val o_tmp = new JSONObject()
                                val grp3: String = array2(0).getString("grp3")
                                o_tmp.put("grp3", grp3)
                                o_tmp.fluentPutAll(o)
                                array2.append(o_tmp)
                                tag3 = 1
                                break()
                            }
                        }
                    }

                    if (tag3 == 0) {
                        grp3_cnt = grp3_cnt + 1
                        val o_tmp = new JSONObject()
                        o_tmp.put("grp3", o.getString("grp2") + "_" + grp3_cnt)
                        o_tmp.fluentPutAll(o)
                        val arr_tmp = new ArrayBuffer[JSONObject]()
                        arr_tmp.append(o_tmp)
                        groupArray3.append(arr_tmp)
                    }


                }

            }


        }

        groupArray3

    }


    def gettrackSimilarity: UserDefinedFunction = udf((coord_list1: String, coord_list2: String) => {

        val coordArr1: JSONArray = formatCoords2(coord_list1)
        val coordArr2: JSONArray = formatCoords2(coord_list2)

        val parm: JSONObject = new JSONObject()
        parm.put("ak", "b924ad13e89f4912b8cde16e10ef18b7")
        parm.put("vehicle", 5)
        parm.put("retflag", 5)
        parm.put("tracktype", 0)
        parm.put("tracks1", coordArr1)
        parm.put("tracks2", coordArr2)
        val jsonStr: String = httpPost(3, track_similarity_url, parm.toJSONString)
        val similArr: Array[Double] = parseSimiJson(jsonStr)

        val simil: Double = similArr.max
        simil
    })

    // 调用标准线路服务接口
    def getStdService: UserDefinedFunction = udf((start_dept: String, end_dept: String, line_code: String, vehicle_type: String, src: String) => {

        val parm = new JSONObject()
        parm.put("optUserId", "01413751")
        parm.put("srcDeptcode", start_dept)
        parm.put("destDeptcode", end_dept)
        parm.put("lineCode", line_code)
        parm.put("vehicle", vehicle_type)
        parm.put("containDeleted", false)
        parm.put("ak", "5e86b3e45f664ecea1d59e6c591aa006")
        val jsonstr: String = httpPost(3, std_service_url, parm.toJSONString)

        // 需要返回的数据集
        val lineArr = new ArrayBuffer[checkLine]()

        try {
            val o: JSONObject = JSON.parseObject(jsonstr)
            val check_status: String = o.getString("status")
            if (check_status == "0") {
                logger.error("标准线路服务接口调用成功,进行业务逻辑处理中……")
                val result: JSONObject = o.getJSONObject("result")
                val list: JSONArray = result.getJSONArray("list")

                var check_right: String = ""
                if (list != null && list.size() == 0) {
                    check_right = "无效配置"
                    lineArr.append(checkLine(check_status, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", check_right))
                } else if (list != null && list.size() > 0) {
                    val i: Int = list.size()
                    if (i == 1) check_right = "匹配单条" else check_right = "匹配多条"
                    for (i <- 0 until i) {
                        val o3: JSONObject = list.getJSONObject(i)
                        val isEcon: String = o3.getString("isEcon")
                        if (isEcon == src || isEcon == "3") {
                            val check_stdid: String = o3.getString("stdId")
                            val check_coords: String = o3.getString("jyTrack2")
                            val check_line_distance: String = o3.getString("lineDistance")
                            val check_line_time: String = o3.getString("lineTime")
                            val check_rtdistance: String = o3.getString("rtDistance")
                            val check_rttime: String = o3.getString("rtTime")
                            val check_start_time: String = o3.getString("planTime")

                            val check_vehicle: String = o3.getString("vehicle")
                            val check_line_code: String = o3.getString("lineCode")
                            val check_srcdeptcode: String = o3.getString("srcDeptcode")
                            val check_destdeptcode: String = o3.getString("destDeptcode")
                            val check_createtime: String = o3.getString("createTime")
                            val check_routeindex: String = o3.getString("routeIndex")
                            val check_confsrc: String = o3.getString("confSrc")
                            val check_deleteflag: String = o3.getString("deleteFlag")
                            val check_updatetime: String = o3.getString("updateTime")
                            val check_addreason: String = o3.getString("addReason")
                            val check_deletereason: String = o3.getString("deleteReason")
                            lineArr.append(
                                checkLine(check_status, check_stdid, check_coords, check_line_distance, check_line_time, check_rtdistance, check_rttime,
                                    check_start_time, isEcon, check_vehicle, check_line_code, check_srcdeptcode, check_destdeptcode, check_createtime, check_routeindex, check_confsrc, check_deleteflag, check_updatetime,
                                    check_addreason, check_deletereason, check_right)
                            )
                        }

                    }
                }
            }
        } catch {
            case e: Exception => logger.error("调用标准线路服务:" + e.getMessage)
        }

        lineArr
    })

    // 调匹配接口qm
    def getMatch: UserDefinedFunction = udf((rt_coords: String) => {
        val coords: String = rt_coords
          .replaceAll("\"", "")
          .replaceAll("\\[", "")
          .replaceAll("],", "|")
          .replaceAll("]", "")

        val parm: String = s"points=$coords&test=1&stype=0&etype=0&passport=100000&date=''&mode=2&speed=1&Toll=1&point_src=1"
        val mapData: util.Map[String, Object] = sendPost(qm_url, parm)

        var status: String = "-1"
        var new_distance: Int = 0
        var new_duration: Double = 0.0
        var new_highspeed_distance: Int = 0
        var new_trafficlight_count: Int = 0
        var new_tolls: Int = 0
        var new_etc_toll: Double = 0.0
        var new_toll_distance: Int = 0

        val swidArr = new ArrayBuffer[String]()
        val coordArr = new ArrayBuffer[String]()
        var paths_num: Int = 0

        try {
            val jsonStr: String = mapData.get("content").toString
            val o: JSONObject = JSON.parseObject(jsonStr)

            status = o.getString("status")
            if (status == "0") {
                logger.error("调匹配接口成功,进行业务逻辑处理中……")
                val route: JSONObject = o.getJSONObject("route")
                val paths: JSONArray = route.getJSONArray("paths")

                if (paths != null && paths.size() > 0) {
                    val n: Int = paths.size()
                    for (i <- 0 until n) {
                        val obj: JSONObject = paths.getJSONObject(i)
                        new_distance += obj.getInteger("distance")
                        new_duration += obj.getDoubleValue("duration")
                        new_highspeed_distance += obj.getInteger("highspeed_distance")
                        new_trafficlight_count += obj.getInteger("trafficlight_count")
                        new_tolls += obj.getInteger("tolls")
                        new_etc_toll += obj.getDoubleValue("etc_toll")
                        new_toll_distance += obj.getInteger("toll_distance")
                        coordArr.append(obj.getString("polyline").replaceAll(";", "|"))

                        val steps: JSONArray = obj.getJSONArray("steps")
                        if (steps != null && steps.size() > 0) {
                            val m: Int = steps.size()
                            for (j <- 0 until m) {
                                val step: JSONObject = steps.getJSONObject(j)
                                val links: JSONArray = step.getJSONArray("links")
                                if (links != null && links.size() > 0) {
                                    val k: Int = links.size()
                                    for (h <- 0 until k) swidArr.append(links.getJSONObject(h).getString("sw_id"))
                                }
                            }
                        }
                    }
                }
            }

        } catch {
            case e: Exception => logger.error("匹配接口调用失败:" + e.getMessage)
        }

        val new_links: String = swidArr.mkString("|")
        val new_coords: String = coordArr.mkString("|")
        paths_num = coordArr.size

        val res = new Array[(String, Int, Double, Int, Int, Int, Double, Int, String, String, Int)](1)
        res(0) = (status, new_distance, new_duration.formatted("%.2f").toDouble, new_highspeed_distance, new_trafficlight_count, new_tolls, new_etc_toll.formatted("%.2f").toDouble, new_toll_distance, new_links, new_coords, paths_num)
        res
    })

    // 回调标准线路
    def callBackStdLine: UserDefinedFunction = udf((check_start_time: String, line_code: String, start_dept: String, end_dept: String, vehicle_type: String) => {
        val url: String = std_service_url2 + s"?&ak=5e86b3e45f664ecea1d59e6c591aa006&opt=std2&interfaceControl=1&planTime=$check_start_time&lineCode=$line_code&" +
          s"srcZoneCode=$start_dept&destZoneCode=$end_dept&vehicle=$vehicle_type"
        val obj: JSONObject = getJsonByGet(url = url, 3, "utf-8")

        var qy_status, qy_url, qy_src, qy_query, qy_dist, qy_compensatetime, qy_stdid, qy_time, qy_error_log, qy_coords = ""
        try {
            qy_status = obj.getString("status")
            if (qy_status == "0") {
                val result: JSONObject = obj.getJSONObject("result")
                qy_src = result.getString("src")
                qy_query = result.getString("query")
                qy_dist = result.getString("dist")
                qy_compensatetime = result.getString("compensateTime")
                qy_stdid = result.getString("stdId")
                qy_time = result.getString("time")
                qy_error_log = obj.toJSONString
                qy_url = url
                val coords: JSONArray = result.getJSONArray("coords")
                if (coords != null && !coords.isEmpty) {
                    val xyArr = new ArrayBuffer[String]()
                    for (i <- 0 until coords.size()) {
                        val coord: JSONArray = coords.getJSONArray(i)
                        val x: String = coord.getString(0)
                        val y: String = coord.getString(1)
                        xyArr.append(x + "," + y)
                    }
                    qy_coords = xyArr.mkString("|")
                }
            }
        } catch {
            case e: Exception => logger.error("线路更新失败：" + e.getMessage)
        }

        val res = new Array[(String, String, String, String, String, String, String, String, String, String)](1)
        res(0) = (qy_status, qy_url, qy_src, qy_query, qy_dist, qy_compensatetime, qy_stdid, qy_time, qy_error_log, qy_coords)
        res
    })

    // 调用更新线路接口
    def getupdateLine: UserDefinedFunction = udf((p: String) => {
        val arr: Array[String] = p.split("_")

        val parmStr: String =
            s"""
               |{
               |    "ak":"5e86b3e45f664ecea1d59e6c591aa006",
               |    "updateReason":"${arr(0)}执行率less0.3",
               |    "optUserId":"01413751",
               |    "deleteLine":{
               |        "stdId":"${arr(1)}"
               |    },
               |    "addLine":{
               |        "srcDeptcode":"${arr(2)}",
               |        "destDeptcode":"${arr(3)}",
               |        "lineCode":"${arr(4)}",
               |        "planTime":"${arr(5).toDouble.toInt}",
               |        "vehicle":${arr(6).toDouble.toInt},
               |        "isEcon":3,
               |        "routeIndex":${arr(7).toDouble.toInt},
               |        "jyTrack2":"${arr(8)}",
               |        "rtDistance":${arr(9).toDouble.toInt},
               |        "rtTime":${arr(10).toDouble.toInt},
               |        "lineDistance":${arr(11).toDouble.toInt},
               |        "lineTime":${arr(12).toDouble.toInt},
               |        "highway":${arr(13).toDouble.toInt},
               |        "tolls":${arr(14).toDouble.toInt},
               |        "tollsDistance":${arr(15).toDouble.toInt},
               |        "confSrc":10
               |    }
               |}
               |""".stripMargin

        val jsonStr: String = httpPost(1, std_update_service_url, parmStr)
        var repair_status, repair_code, repair_info, repair_err, repair_msg, repair_stdid = ""
        try {
            val obj: JSONObject = JSON.parseObject(jsonStr)
            repair_status = obj.getString("status")
            val result: JSONObject = obj.getJSONObject("result")
            repair_code = result.getString("code")
            repair_info = result.getString("info")
            repair_err = result.getString("err")
            repair_msg = result.getString("msg")
            repair_stdid = result.getString("stdId")
        } catch {
            case e: Exception => logger.error("线路更新失败：" + e.getMessage)
        }

        val res = new Array[(String, String, String, String, String, String)](1)
        res(0) = (repair_status, repair_code, repair_info, repair_err, repair_msg, repair_stdid)
        res
    })

    // 原始数据初始化
    def getOrigData(spark: SparkSession, inc_day: String): RDD[JSONObject] = {
        import spark.implicits._

        val start_time: String = getdaysBeforeOrAfter(inc_day, -15)
        val end_time: String = getdaysBeforeOrAfter(inc_day, -1)

        val sql: String =
            s"""
               |select
               |  task_area_code,
               |  task_id,
               |  sort_num,
               |  task_subid,
               |  start_dept,
               |  end_dept,
               |  start_type,
               |  end_type,
               |  line_code,
               |  vehicle_serial,
               |  actual_capacity_load,
               |  plan_depart_tm,
               |  actual_depart_tm,
               |  plan_arrive_tm,
               |  actual_arrive_tm,
               |  driver_id,
               |  driver_name,
               |  line_time,
               |  line_distance,
               |  actual_run_time,
               |  start_longitude,
               |  start_latitude,
               |  end_longitude,
               |  end_latitude,
               |  is_stop,
               |  transoport_level,
               |  carrier_type,
               |  plf_flag,
               |  vehicle_type,
               |  axls_number,
               |  log_dist,
               |  rt_coords,
               |  x1,
               |  y1,
               |  x2,
               |  y2,
               |  duration,
               |  time,
               |  rt_dist,
               |  highwaymileage,
               |  toll_charge,
               |  start_distance,
               |  end_distance,
               |  error_type,
               |  pns_dist,
               |  pns_time,
               |  src,
               |  line_distance_std,
               |  line_time_std,
               |  sim1,
               |  sim5,
               |  diffdist_rt_line,
               |  diffratio_rt_line,
               |  diffdist_rt_std,
               |  diffratio_rt_std,
               |  diffdist_rt_log,
               |  diffratio_rt_log,
               |  diffdist_line_log,
               |  diffratio_line_log,
               |  diffdist_line_std,
               |  diffratio_line_std,
               |  diffdist_log_std,
               |  diffratio_log_std,
               |  conduct_type,
               |  difftime_line_std,
               |  diffratio1_line_std,
               |  difftime_line_std_10min,
               |  difftime_line_rt,
               |  diffratio1_line_rt,
               |  difftime_rt_gh_10min,
               |  is_run_ontime_std,
               |  is_run_ontime,
               |  if_dist_equal,
               |  if_time_equal,
               |  pns_error,
               |  task_inc_day,
               |  difftime_std_rt,
               |  diffratio1_std_rt,
               |  difftime_std_rt_10min,
               |  tl_time,
               |  halfway_integrate_rate,
               |  std_x1,
               |  std_y1,
               |  std_x2,
               |  std_y2,
               |  start_distance_std,
               |  end_distance_std,
               |  std_line_error,
               |  ac_difftime_line_rt,
               |  ac_diffratio1_line_rt,
               |  ac_difftime_rt_gh_10min,
               |  ac_difftime_std_rt,
               |  ac_diffratio1_std_rt,
               |  ac_difftime_std_rt_10min,
               |  ac_is_run_ontime_std,
               |  ac_is_run_ontime,
               |  if_evaluate_time,
               |  carrier_name,
               |  stop_over_zone_code,
               |  biz_type,
               |  require_category,
               |  to_ground,
               |  std_toll_charge,
               |  std_id,
               |  navi_strategy,
               |  is_return_std_line,
               |  is_navi_at_start,
               |  is_navi_by_std_line,
               |  route_time,
               |  drive_time,
               |  is_yaw_by_driver,
               |  navi_complete_rate,
               |  accrual_dist,
               |  accrual_dist_type,
               |  last_update_tm,
               |  main_driver_account,
               |  road_fee,
               |  inc_day as orig_inc_day
               |from
               |  dm_gis.eta_std_line_recall
               |where
               |  inc_day >= '$start_time'
               |  and inc_day <= '$end_time'
               |  and error_type ='0'
               |  and carrier_type ='0'
               |  and start_longitude is not null and start_longitude != ''
               |  and start_latitude is not null and start_latitude != ''
               |  and end_longitude is not null and end_longitude != ''
               |  and end_latitude is not null and end_latitude != ''
               |""".stripMargin
        logger.error("原始数据：" + sql)

        val sql2: String =
            s"""
               |select
               |  task_subid
               |from
               |  dm_gis.gis_eta_stdline_abnormal_daily_result
               |where
               |  inc_day >= '$start_time'
               |  and inc_day <= '$end_time'
               |  and roadcdt_type != '0'
               |  and type in('7','8','16')
               |  and conduct_type = '3'
               |group by
               |  task_subid
               |""".stripMargin
        logger.error("剔除数据：" + sql2)

        val lineDF: DataFrame = spark.sql(sql)
        val abnormalDF: DataFrame = spark.sql(sql2)

        val w: WindowSpec = Window.partitionBy($"task_subid").orderBy($"orig_inc_day".desc)
        val origRDD: RDD[JSONObject] = lineDF
          .join(abnormalDF, Seq("task_subid"), "leftanti")
          .withColumn("dist",
              getDistance($"start_longitude".cast("double"),
                  $"start_latitude".cast("double"),
                  $"end_longitude".cast("double"),
                  $"end_latitude".cast("double")
              ))
          .withColumn("is_same_point", when($"dist" < 400.0, 1).otherwise(0))
          .filter($"rt_dist".cast("double") > 0
            and $"pns_dist".cast("double") > 0
            and $"sim1".isNotNull
            and $"sim5".isNotNull
            and $"sim1".cast("double") =!= "-1"
            and $"sim5".cast("double") =!= "-1"
            and $"is_same_point" === 0
            and $"halfway_integrate_rate".cast("double") > 0.9
          )
          .withColumn("rn", row_number().over(w))
          .filter("rn = 1")
          .withColumn("line_id", concat_ws("_", $"line_code", $"start_dept", $"end_dept", $"vehicle_type"))
          .withColumn("line_std_id", concat_ws("_", $"line_id", $"std_id"))
          .rdd
          .map(row2Json)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetRDDCountAndSampleData(logger, origRDD, "原始数据预处理之后")

        origRDD
    }

    // 原始数据打tag之后的最终数据
    def getOrigTagData(spark: SparkSession, origRDD: RDD[JSONObject], inc_day: String): DataFrame = {
        import spark.implicits._
        val five_day_ago: String = getdaysBeforeOrAfter(inc_day, -5)

        val origDS: Dataset[String] = origRDD
          .groupBy(_.getString("line_id"))
          .flatMap(r => {
              val arr: Array[JSONObject] = r._2.toArray

              val (lineid_num, lineid_conduct_num, lineid_not_conduct_num, lineid_ontime_num, lineid_conduct_rate, lineid_ontime_rate) = getNumberByID(arr)

              arr.foreach(o => {
                  o.put("lineid_num", lineid_num)
                  o.put("lineid_conduct_num", lineid_conduct_num)
                  o.put("lineid_not_conduct_num", lineid_not_conduct_num)
                  o.put("lineid_ontime_num", lineid_ontime_num)
                  o.put("lineid_conduct_rate", lineid_conduct_rate)
                  o.put("lineid_ontime_rate", lineid_ontime_rate)
                  o.put("lineid_tag", getTag(lineid_conduct_rate))
              })

              arr
          })
          .groupBy(_.getString("line_std_id"))
          .flatMap(r => {
              val arr: Array[JSONObject] = r._2.toArray

              val (stdid_num, stdid_conduct_num, stdid_not_conduct_num, stdid_ontime_num, stdid_conduct_rate, stdid_ontime_rate) = getNumberByID(arr)

              val arr2: Array[JSONObject] = arr.filter(_.getString("task_inc_day") >= five_day_ago)
              val stdid_num_5days: Int = arr2.length
              val stdid_conduct_num_5days: Int = arr2.count(_.getString("conduct_type") == "1")
              var stdid_conduct_rate_5days: Double = -1.0
              if (stdid_num_5days != 0) stdid_conduct_rate_5days = (stdid_conduct_num_5days.toDouble / stdid_num_5days).formatted("%.2f").toDouble

              arr.foreach(o => {
                  o.put("stdid_num", stdid_num)
                  o.put("stdid_conduct_num", stdid_conduct_num)
                  o.put("stdid_not_conduct_num", stdid_not_conduct_num)
                  o.put("stdid_ontime_num", stdid_ontime_num)
                  o.put("stdid_conduct_rate", stdid_conduct_rate)
                  o.put("stdid_ontime_rate", stdid_ontime_rate)
                  o.put("stdid_tag", getTag(stdid_conduct_rate))

                  o.put("stdid_num_5days", stdid_num_5days)
                  o.put("stdid_conduct_num_5days", stdid_conduct_num_5days)
                  o.put("stdid_conduct_rate_5days", stdid_conduct_rate_5days)
                  o.put("stdid_5days_tag", getTag(stdid_conduct_rate_5days))
              })

              arr.map(_.toJSONString)
          })
          .toDS()
          .persist(StorageLevel.MEMORY_AND_DISK)

        val origTagDF: DataFrame = spark.read.json(origDS)
          .withColumnRenamed("inc_day", "orig_inc_day")
          .select("task_area_code", "task_id", "sort_num", "task_subid", "start_dept", "end_dept", "start_type", "end_type", "line_code", "vehicle_serial", "actual_capacity_load", "plan_depart_tm", "actual_depart_tm", "plan_arrive_tm", "actual_arrive_tm", "driver_id", "driver_name", "line_time", "line_distance", "actual_run_time", "start_longitude", "start_latitude", "end_longitude", "end_latitude", "is_stop", "transoport_level", "carrier_type", "plf_flag", "vehicle_type", "axls_number", "log_dist", "rt_coords", "x1", "y1", "x2", "y2", "duration", "time", "rt_dist", "highwaymileage", "toll_charge", "start_distance", "end_distance", "error_type", "pns_dist", "pns_time", "src", "line_distance_std", "line_time_std", "sim1", "sim5", "diffdist_rt_line", "diffratio_rt_line", "diffdist_rt_std", "diffratio_rt_std", "diffdist_rt_log", "diffratio_rt_log", "diffdist_line_log", "diffratio_line_log", "diffdist_line_std", "diffratio_line_std", "diffdist_log_std", "diffratio_log_std", "conduct_type", "difftime_line_std", "diffratio1_line_std", "difftime_line_std_10min", "difftime_line_rt", "diffratio1_line_rt", "difftime_rt_gh_10min", "is_run_ontime_std", "is_run_ontime", "if_dist_equal", "if_time_equal", "pns_error", "task_inc_day", "difftime_std_rt", "diffratio1_std_rt", "difftime_std_rt_10min", "tl_time", "halfway_integrate_rate", "std_x1", "std_y1", "std_x2", "std_y2", "start_distance_std", "end_distance_std", "std_line_error", "ac_difftime_line_rt", "ac_diffratio1_line_rt", "ac_difftime_rt_gh_10min", "ac_difftime_std_rt", "ac_diffratio1_std_rt", "ac_difftime_std_rt_10min", "ac_is_run_ontime_std", "ac_is_run_ontime", "if_evaluate_time", "carrier_name", "stop_over_zone_code", "biz_type", "require_category", "to_ground", "std_toll_charge", "std_id", "navi_strategy", "is_return_std_line", "is_navi_at_start", "is_navi_by_std_line", "route_time", "drive_time", "is_yaw_by_driver", "navi_complete_rate", "accrual_dist", "accrual_dist_type", "last_update_tm", "main_driver_account", "road_fee", "dist", "is_same_point", "rn", "line_id", "line_std_id", "lineid_num", "lineid_conduct_num", "lineid_not_conduct_num", "lineid_ontime_num", "lineid_conduct_rate", "lineid_ontime_rate", "lineid_tag", "stdid_num", "stdid_conduct_num", "stdid_not_conduct_num", "stdid_ontime_num", "stdid_conduct_rate", "stdid_ontime_rate", "stdid_tag", "stdid_num_5days", "stdid_conduct_num_5days", "stdid_conduct_rate_5days", "stdid_5days_tag", "orig_inc_day")
          .withColumn("inc_day", lit(inc_day))
          .coalesce(100)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, origTagDF, "原始数据打tag之后")
        df2HiveByOverwrite(logger, origTagDF, "dm_gis.econ_task_detail_origin_data")

        origRDD.unpersist()
        origDS.unpersist()

        origTagDF
    }

    // 每条数据添加 grp1 grp2 grp3
    def getGrpsDetail(spark: SparkSession, origTagDF: DataFrame, inc_day: String): DataFrame = {
        import spark.implicits._

        val origGrpDS: Dataset[String] = origTagDF
          .drop("inc_day")
          .filter("lineid_conduct_rate <= 0.3 and stdid_conduct_rate <= 0.3 and lineid_num >= 3")
          .rdd
          .groupBy(_.getAs[String]("line_std_id"))
          .repartition(3)
          .flatMap(r => {
              val line_std_id: String = r._1
              val arr: Array[JSONObject] = r._2.toArray.map(row2Json)
              arr.foreach(_.put("grp1", line_std_id + "_1"))

              val arr2: ArrayBuffer[ArrayBuffer[JSONObject]] = groupRoute2("b924ad13e89f4912b8cde16e10ef18b7", arr)

              val arr3: ArrayBuffer[ArrayBuffer[ArrayBuffer[JSONObject]]] = new ArrayBuffer[ArrayBuffer[ArrayBuffer[JSONObject]]]
              for (a <- arr2) {
                  arr3.append(groupRoute3("b924ad13e89f4912b8cde16e10ef18b7", a.toArray))
              }

              arr3.flatten.flatten.map(_.toJSONString)
          })
          .repartition(10)
          .toDS()
          .persist(StorageLevel.MEMORY_AND_DISK)

        val origGrpsDF: DataFrame = spark.read.json(origGrpDS)
          .select("task_area_code", "task_id", "sort_num", "task_subid", "start_dept", "end_dept", "start_type", "end_type", "line_code", "vehicle_serial", "actual_capacity_load", "plan_depart_tm", "actual_depart_tm", "plan_arrive_tm", "actual_arrive_tm", "driver_id", "driver_name", "line_time", "line_distance", "actual_run_time", "start_longitude", "start_latitude", "end_longitude", "end_latitude", "is_stop", "transoport_level", "carrier_type", "plf_flag", "vehicle_type", "axls_number", "log_dist", "rt_coords", "x1", "y1", "x2", "y2", "duration", "time", "rt_dist", "highwaymileage", "toll_charge", "start_distance", "end_distance", "error_type", "pns_dist", "pns_time", "src", "line_distance_std", "line_time_std", "sim1", "sim5", "diffdist_rt_line", "diffratio_rt_line", "diffdist_rt_std", "diffratio_rt_std", "diffdist_rt_log", "diffratio_rt_log", "diffdist_line_log", "diffratio_line_log", "diffdist_line_std", "diffratio_line_std", "diffdist_log_std", "diffratio_log_std", "conduct_type", "difftime_line_std", "diffratio1_line_std", "difftime_line_std_10min", "difftime_line_rt", "diffratio1_line_rt", "difftime_rt_gh_10min", "is_run_ontime_std", "is_run_ontime", "if_dist_equal", "if_time_equal", "pns_error", "task_inc_day", "difftime_std_rt", "diffratio1_std_rt", "difftime_std_rt_10min", "tl_time", "halfway_integrate_rate", "std_x1", "std_y1", "std_x2", "std_y2", "start_distance_std", "end_distance_std", "std_line_error", "ac_difftime_line_rt", "ac_diffratio1_line_rt", "ac_difftime_rt_gh_10min", "ac_difftime_std_rt", "ac_diffratio1_std_rt", "ac_difftime_std_rt_10min", "ac_is_run_ontime_std", "ac_is_run_ontime", "if_evaluate_time", "carrier_name", "stop_over_zone_code", "biz_type", "require_category", "to_ground", "std_toll_charge", "std_id", "navi_strategy", "is_return_std_line", "is_navi_at_start", "is_navi_by_std_line", "route_time", "drive_time", "is_yaw_by_driver", "navi_complete_rate", "accrual_dist", "accrual_dist_type", "last_update_tm", "main_driver_account", "road_fee", "dist", "is_same_point", "rn", "line_id", "line_std_id", "lineid_num", "lineid_conduct_num", "lineid_not_conduct_num", "lineid_ontime_num", "lineid_conduct_rate", "lineid_ontime_rate", "lineid_tag", "stdid_num", "stdid_conduct_num", "stdid_not_conduct_num", "stdid_ontime_num", "stdid_conduct_rate", "stdid_ontime_rate", "stdid_tag", "stdid_num_5days", "stdid_conduct_num_5days", "stdid_conduct_rate_5days", "stdid_5days_tag", "orig_inc_day", "grp1", "grp2", "grp3")
          .withColumn("inc_day", lit(inc_day))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, origGrpsDF, "添加grp之后的数据")
        df2HiveByOverwrite(logger, origGrpsDF, "dm_gis.econ_task_detail_grp")

        origGrpDS.unpersist()
        origGrpsDF
    }

    // 异常数据标记
    def getGrpMark(spark: SparkSession, origTagDF: DataFrame, origGrpsDF: DataFrame, inc_day: String): DataFrame = {
        import spark.implicits._

        val origTagDF2: DataFrame = origTagDF
          .select("line_id", "line_std_id", "lineid_num", "lineid_conduct_num", "stdid_num", "stdid_conduct_num", "lineid_conduct_rate",
              "stdid_conduct_rate", "stdid_conduct_rate_5days", "stdid_ontime_rate", "lineid_ontime_rate", "lineid_tag", "stdid_tag", "stdid_5days_tag",
              "start_dept", "end_dept")

        val stdDF: DataFrame = origGrpsDF
          .groupBy("line_std_id")
          .agg(
              count("line_std_id").as("task_num"),
              round(mean($"actual_run_time".cast("double")), 2).as("mean_cost_time"),
              collect_set($"pns_dist".cast("double"))(0).as("std_pns_dist"),
              sum(when($"ac_is_run_ontime" === "1.0", 1).otherwise(0)).as("ontime_num")
          )
          .withColumn("ontime_rate", round($"ontime_num".cast("double") / $"task_num", 2))

        val grpDF: DataFrame = origGrpsDF
          .groupBy("grp2")
          .agg(
              collect_set($"line_std_id")(0).as("line_std_id"),
              round(mean($"rt_dist".cast("double")), 2).as("rt_mean_dist"),
              count("grp2").as("rt_route_num"),
              round(mean($"actual_run_time".cast("double")), 2).as("rt_mean_cost_time"),
              sum(when($"ac_is_run_ontime" === "1.0", 1).otherwise(0)).as("rt_ontime_num")
          )
          .withColumn("rt_ontime_rate", round($"rt_ontime_num".cast("double") / $"rt_route_num", 2))

        val grpAllDF: DataFrame = stdDF
          .join(grpDF, Seq("line_std_id"))
          .withColumn("rt_conduct_rate", round($"rt_route_num".cast("double") / $"task_num", 2))
          .join(origTagDF2, Seq("line_std_id"), "left")
          .dropDuplicates("grp2")
          .withColumn("air_mark", when(length($"start_dept") > 8 or length($"end_dept") > 8, 9).otherwise(0))
          .withColumn("if_detour",
              when($"rt_mean_dist" - $"std_pns_dist" < 6000.0
                or round(($"rt_mean_dist" - $"std_pns_dist") / $"std_pns_dist", 2) <= 0.06, 1).otherwise(0)
          )
          .withColumn("fre_mark", when($"rt_route_num" >= 3, 1).otherwise(0))
          .withColumn("ontime_mark", when($"rt_ontime_rate" < 0.7, 0)
            .when($"rt_ontime_rate" <= 0.8, 1)
            .when($"rt_ontime_rate" <= 0.9, 2)
            .when($"rt_ontime_rate" < 1, 3)
            .when($"rt_ontime_rate" === 1, 4)
            .otherwise(99)
          )
          .na.fill(0.0, Array("stdid_conduct_rate_5days"))
          .withColumn("stdid_rate_com5_mark", when($"stdid_conduct_rate_5days".cast("double") > $"stdid_conduct_rate", 1).otherwise(0))
          .withColumn("rt_rate_com1_mark", when($"rt_conduct_rate" > $"stdid_conduct_rate_5days".cast("double"), 1).otherwise(0))
          .withColumn("rt_rate_com2_mark", when($"rt_conduct_rate" > $"stdid_conduct_rate", 1).otherwise(0))
          .withColumn("rt_std_ontime_mark",
              when($"rt_conduct_rate" >= $"stdid_ontime_rate" and $"rt_ontime_rate" < $"lineid_ontime_rate", 1)
                .when($"rt_ontime_rate" >= $"lineid_ontime_rate" and $"rt_ontime_rate" < $"stdid_ontime_rate", 2)
                .when($"rt_ontime_rate" >= $"lineid_ontime_rate" and $"rt_ontime_rate" >= $"stdid_ontime_rate", 3)
                .otherwise(0)
          )
          .withColumn("inc_day", lit(inc_day))
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, grpAllDF, "异常数据标记")
        df2HiveByOverwrite(logger, grpAllDF, "dm_gis.econ_task_detail_grp_all")
        grpAllDF
    }

    // 筛选线路
    def getReplaceLine(spark: SparkSession, grpAllDF: DataFrame, checkLineDF: DataFrame, inc_day: String): DataFrame = {
        import spark.implicits._

        val thewenty_before: String = getdaysBeforeOrAfter(inc_day, -20)
        val fourtyfive_before: String = getdaysBeforeOrAfter(inc_day, -30)

        val replacedDF: DataFrame = spark.sql(s"select line_std_id as line_std_id2 from dm_gis.already_replace_data where inc_day >= '$thewenty_before' and inc_day < '$inc_day'").dropDuplicates()
        val trailDF: DataFrame = spark.sql(s"select concat_ws('_', line_code, start_dept, end_dept, vehicle) as line_id2 from dm_gis.exception_report_trail where inc_day >= '$fourtyfive_before' and inc_day < '$inc_day'").dropDuplicates()

        val w: WindowSpec = Window.partitionBy($"line_std_id").orderBy($"rt_conduct_rate".desc, $"rt_route_num".desc)
        val grpAllDS: Dataset[String] = grpAllDF
          .filter("air_mark = 9 " +
            "or (fre_mark = 1 and rt_ontime_rate >= 0.9 and stdid_conduct_rate <= 0.1 and stdid_conduct_rate >= 0 and !(stdid_rate_com5_mark = 1 and cast(stdid_conduct_rate_5days as double) >= 0.4)) " +
            "or (fre_mark = 1 and rt_ontime_rate >= 0.9 and stdid_conduct_rate <= 0.3 and stdid_conduct_rate > 0.1 and rt_rate_com2_mark = 1 and !(stdid_rate_com5_mark = 1 and cast(stdid_conduct_rate_5days as double) >= 0.4)) " +
            "or (rt_std_ontime_mark = 3 and rt_route_num > 3)"
          )
          .withColumn("rn", row_number().over(w))
          .filter("rn = 1")
          .drop("rn")
          .select("grp2")
          .join(checkLineDF.filter("paths_num = 1"), Seq("grp2"))
          .withColumn("repair_categray", lit("less_0.3_replace"))
          .rdd
          .groupBy(_.getAs[String]("line_std_id"))
          .map(r => {
              val arr: Array[JSONObject] = r._2.
                toArray
                .map(row2Json)
                .sortWith((o1, o2) => o1.getDoubleValue("rt_dist") > o2.getDoubleValue("rt_dist"))

              val n: Int = arr.length
              val o: JSONObject = if (n % 2 == 0) arr(n / 2 - 1) else arr((n + 1) / 2 - 1)
              o.toJSONString
          })
          .toDS()
          .persist(StorageLevel.MEMORY_AND_DISK)

        val grpAllDF2: DataFrame = spark.read.json(grpAllDS)
          .select("task_area_code", "task_id", "sort_num", "task_subid", "start_dept", "end_dept", "start_type", "end_type", "line_code", "vehicle_serial", "actual_capacity_load", "plan_depart_tm", "actual_depart_tm", "plan_arrive_tm", "actual_arrive_tm", "driver_id", "driver_name", "line_time", "line_distance", "actual_run_time", "start_longitude", "start_latitude", "end_longitude", "end_latitude", "is_stop", "transoport_level", "carrier_type", "plf_flag", "vehicle_type", "axls_number", "log_dist", "rt_coords", "x1", "y1", "x2", "y2", "duration", "time", "rt_dist", "highwaymileage", "toll_charge", "start_distance", "end_distance", "error_type", "pns_dist", "pns_time", "src", "line_distance_std", "line_time_std", "sim1", "sim5", "diffdist_rt_line", "diffratio_rt_line", "diffdist_rt_std", "diffratio_rt_std", "diffdist_rt_log", "diffratio_rt_log", "diffdist_line_log", "diffratio_line_log", "diffdist_line_std", "diffratio_line_std", "diffdist_log_std", "diffratio_log_std", "conduct_type", "difftime_line_std", "diffratio1_line_std", "difftime_line_std_10min", "difftime_line_rt", "diffratio1_line_rt", "difftime_rt_gh_10min", "is_run_ontime_std", "is_run_ontime", "if_dist_equal", "if_time_equal", "pns_error", "task_inc_day", "difftime_std_rt", "diffratio1_std_rt", "difftime_std_rt_10min", "tl_time", "halfway_integrate_rate", "std_x1", "std_y1", "std_x2", "std_y2", "start_distance_std", "end_distance_std", "std_line_error", "ac_difftime_line_rt", "ac_diffratio1_line_rt", "ac_difftime_rt_gh_10min", "ac_difftime_std_rt", "ac_diffratio1_std_rt", "ac_difftime_std_rt_10min", "ac_is_run_ontime_std", "ac_is_run_ontime", "if_evaluate_time", "carrier_name", "stop_over_zone_code", "biz_type", "require_category", "to_ground", "std_toll_charge", "std_id", "navi_strategy", "is_return_std_line", "is_navi_at_start", "is_navi_by_std_line", "route_time", "drive_time", "is_yaw_by_driver", "navi_complete_rate", "accrual_dist", "accrual_dist_type", "last_update_tm", "main_driver_account", "road_fee", "dist", "is_same_point", "rn", "line_id", "line_std_id", "lineid_num", "lineid_conduct_num", "lineid_not_conduct_num", "lineid_ontime_num", "lineid_conduct_rate", "lineid_ontime_rate", "lineid_tag", "stdid_num", "stdid_conduct_num", "stdid_not_conduct_num", "stdid_ontime_num", "stdid_conduct_rate", "stdid_ontime_rate", "stdid_tag", "stdid_num_5days", "stdid_conduct_num_5days", "stdid_conduct_rate_5days", "stdid_5days_tag", "orig_inc_day", "grp1", "grp2", "grp3", "status", "new_distance", "new_duration", "new_highspeed_distance", "new_trafficlight_count", "new_tolls", "new_etc_toll", "new_toll_distance", "new_links", "new_coords", "paths_num", "repair_categray")
          .withColumn("cl", explode(getStdService($"start_dept", $"end_dept", $"line_code", $"vehicle_type", $"src")))
          .withColumn("check_status", $"cl.check_status")
          .withColumn("check_stdid", $"cl.check_stdid")
          .withColumn("check_coords", $"cl.check_coords")
          .withColumn("check_line_distance", $"cl.check_line_distance")
          .withColumn("check_line_time", $"cl.check_line_time")
          .withColumn("check_rtdistance", $"cl.check_rtdistance")
          .withColumn("check_rttime", $"cl.check_rttime")
          .withColumn("check_start_time", $"cl.check_start_time")
          .withColumn("check_isecon", $"cl.check_isecon")
          .withColumn("check_vehicle", $"cl.check_vehicle")
          .withColumn("check_line_code", $"cl.check_line_code")
          .withColumn("check_srcdeptcode", $"cl.check_srcdeptcode")
          .withColumn("check_destdeptcode", $"cl.check_destdeptcode")
          .withColumn("check_createtime", $"cl.check_createtime")
          .withColumn("check_routeindex", $"cl.check_routeindex")
          .withColumn("check_confsrc", $"cl.check_confsrc")
          .withColumn("check_deleteflag", $"cl.check_deleteflag")
          .withColumn("check_updatetime", $"cl.check_updatetime")
          .withColumn("check_addreason", $"cl.check_addreason")
          .withColumn("check_deletereason", $"cl.check_deletereason")
          .withColumn("check_right", $"cl.check_right")
          .drop("cl")
          .filter("check_right != '无效配置' and check_isecon != '0'")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 最近20天是否替换过的线路
        val replaceDF1: DataFrame = grpAllDF2
          .join(replacedDF, grpAllDF2("line_std_id") === replacedDF("line_std_id2"), "left")
          .withColumn("replace_mark", when(replacedDF("line_std_id2").isNotNull, 1).otherwise(0))
          .drop("line_std_id2")
          .persist(StorageLevel.MEMORY_AND_DISK)

        // 最近45天已经替换过的线路
        val replaceDF21: DataFrame = replaceDF1
          .filter("replace_mark = 0")
          .join(trailDF, replaceDF1("line_id") === trailDF("line_id2"), "leftsemi")
          .withColumn("replace_mark", lit(2))

        // 最近45天未替换过的线路
        val replaceDF22: DataFrame = replaceDF1
          .filter("replace_mark = 0")
          .join(trailDF, replaceDF1("line_id") === trailDF("line_id2"), "leftanti")

        val replaceDF: Dataset[Row] = replaceDF1
          .filter("replace_mark = 1")
          .union(replaceDF21)
          .union(replaceDF22)
          .withColumn("inc_day", lit(inc_day))
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)
        GetDFCountAndSampleData(logger, replaceDF, "筛选出来的线路")

        df2HiveByOverwrite(logger, replaceDF, "dm_gis.replace_std_route_data")

        grpAllDS.unpersist()
        replaceDF
    }

    // 匹配服务 之后的数据
    def getCheckLine(spark: SparkSession, origGrpsDF: DataFrame, inc_day: String): DataFrame = {
        import spark.implicits._

        val checkLine: DataFrame = origGrpsDF
          .withColumn("mc", explode(getMatch($"rt_coords")))
          .withColumn("status", $"mc._1")
          .withColumn("new_distance", $"mc._2")
          .withColumn("new_duration", $"mc._3")
          .withColumn("new_highspeed_distance", $"mc._4")
          .withColumn("new_trafficlight_count", $"mc._5")
          .withColumn("new_tolls", $"mc._6")
          .withColumn("new_etc_toll", $"mc._7")
          .withColumn("new_toll_distance", $"mc._8")
          .withColumn("new_links", $"mc._9")
          .withColumn("new_coords", $"mc._10")
          .withColumn("paths_num", $"mc._11")
          .drop("mc", "inc_day")
          .withColumn("inc_day", lit(inc_day))
          .coalesce(5)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, checkLine, "匹配服务之后的数据")
        df2HiveByOverwrite(logger, checkLine, "dm_gis.replace_std_route_data_check_union")

        checkLine
    }

    // 更新线路数据
    def updateLineData(spark: SparkSession, replaceDF: DataFrame, inc_day: String): DataFrame = {
        import spark.implicits._

        val updateDF: DataFrame = replaceDF
          .filter("replace_mark = 0")
          .withColumn("p", concat_ws("_", $"inc_day", $"check_stdid", $"check_srcdeptcode", $"check_destdeptcode", $"check_line_code", $"check_start_time", $"check_vehicle",
              $"check_routeindex", $"new_coords", $"new_distance", $"new_duration", $"check_line_distance", $"check_line_time", $"new_highspeed_distance", $"new_tolls", $"new_toll_distance"))
          .withColumn("res", explode(getupdateLine($"p")))
          .withColumn("repair_status", $"res._1")
          .withColumn("repair_code", $"res._2")
          .withColumn("repair_info", $"res._3")
          .withColumn("repair_err", $"res._4")
          .withColumn("repair_msg", $"res._5")
          .withColumn("repair_stdid", $"res._6")
          .withColumn("replace_time", lit(inc_day))
          .drop("inc_day", "p", "res")
          .withColumn("inc_day", lit(inc_day))
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)


        GetDFCountAndSampleData(logger, updateDF, "已正常更新的线路")
        df2HiveByOverwrite(logger, replaceDF, "dm_gis.already_replace_data")

        updateDF
    }

    // 回调标准线路，比较相似度
    def lineFixed(spark: SparkSession, updateDF: DataFrame, inc_day: String): Unit = {
        import spark.implicits._

        val fixedDF: DataFrame = updateDF
          .filter("repair_status='0'")
          .withColumn("qy", explode(callBackStdLine($"check_start_time", $"line_code", $"start_dept", $"end_dept", $"vehicle_type")))
          .withColumn("qy_status", $"qy._1")
          .withColumn("qy_url", $"qy._2")
          .withColumn("qy_src", $"qy._3")
          .withColumn("qy_query", $"qy._4")
          .withColumn("qy_dist", $"qy._5")
          .withColumn("qy_compensatetime", $"qy._6")
          .withColumn("qy_stdid", $"qy._7")
          .withColumn("qy_time", $"qy._8")
          .withColumn("qy_error_log", $"qy._9")
          .withColumn("qy_coords", $"qy._10")
          .filter("qy_coords != '' and new_coords != ''")
          .withColumn("simi_max", gettrackSimilarity($"new_coords", $"qy_coords"))
          .withColumn("if_fixed", when($"simi_max" >= 0.98, 1).otherwise(0))
          .drop("qy", "simi_max", "inc_day")
          .withColumn("inc_day", lit(inc_day))
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, fixedDF, "修复过后的线路数据")
        df2HiveByOverwrite(logger, fixedDF, "dm_gis.std_line_fixed_data")
    }

    // 标准线路服务返回数据case class
    case class checkLine(check_status: String, check_stdid: String, check_coords: String, check_line_distance: String, check_line_time: String, check_rtdistance: String, check_rttime: String, check_start_time: String, check_isecon: String, check_vehicle: String, check_line_code: String, check_srcdeptcode: String, check_destdeptcode: String, check_createtime: String, check_routeindex: String, check_confsrc: String, check_deleteflag: String, check_updatetime: String, check_addreason: String, check_deletereason: String, check_right: String)

}