package app.supplyMap

import com.alibaba.fastjson.{JSON, JSONObject}
import entry.ScmPlanRecall
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.df2HiveByOverwrite
import utils.SparkConfigUtil


/**
 * 任务名称：解析recall log日志
 * 任务ID：420128
 * 需求人员：
 * 开发人员：王冬冬 01413698
 */
object GetScmPlanRecallData {
  val className: String = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

    // 接收外部传递进来的变量
    val start_time: String = args(0)
    val end_time: String = args(1)
    val ten_day_before: String = args(2)
    logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
    logger.error(s"10天之前的日期：$ten_day_before")


    // 获取Kafka log信息
    val logSql: String =
      s"""
         |select
         |  *
         |from
         |  dm_gis.scm_plan_recall_to_bdp_his
         |where
         |  inc_day >= '$start_time'
         |  and inc_day < '$end_time'
         |""".stripMargin

    // 删除 10天前的分区数据
    val delSql: String = s"alter table dm_gis.scm_plan_recall_to_bdp_his drop if exists partition (inc_day = '$ten_day_before')"

    logger.error("解析的原始数据:" + logSql)
    logger.error("需要删除的分区数据:" + delSql)

    // 解析昨天的log数据
    getplanRecallDetail(spark, logSql)

    // 删除十天前的分区数据
    try {
//      spark.sql(delSql)
    } catch {
      case e: Exception => logger.error(e.getMessage)
    }
    logger.error("运行结束！")

  }

  def getplanRecallDetail(spark: SparkSession, sql: String): Unit = {
    import spark.implicits._

    val plan_recallDF: DataFrame = spark
      .sql(sql)
      .repartition(300)
      .map(r => {
        val log: String = r.getAs[String]("log")
        val inc_day: String = r.getAs[String]("inc_day")

        var o: JSONObject = null

        try {
          o = JSON.parseObject(log)
        } catch {
          case e: Exception => logger.error(e.getMessage)
        }
        var task_subid, task_id, sort_num, task_area_code, line_code, start_dept, start_dept_site_id, start_outer_add_code, start_type, end_dept, end_dept_site_id, end_outer_add_code, end_type, plan_depart_tm, actual_depart_tm, plan_arrive_tm, actual_arrive_tm, line_time, line_distance, actual_run_time, start_longitude, start_latitude, end_longitude, end_latitude, require_category, stop_over_zone_code, vehicle_serial, driver_id, driver_name, actual_capacity_load, capacity_load, transoport_level, to_ground, biz_type, carrier_name, is_stop, carrier_type, plf_flag, state, last_update_tm, full_load_weight, votes_l, votes_lw, votes_s, votes_n, votes_d, votes_w, votes_sp, votes_dp, votes_pw, contnr_code, push_bdp_count, main_driver_account, line_require_id, start_sortnum, end_sortnum, `type`, time_type, carrier_code, carrier_id, src_city_name, dest_city_name, sf_outer_vehicle_from,child_carrier_name,child_carrier_id,child_carrier_code,deputy_driver_account,deputy_driver_name = ""
        if (o != null) {
          task_subid = o.getString("taskSubid")
          task_id = o.getString("taskId")
          sort_num = o.getString("sortNum")
          task_area_code = o.getString("taskAreaCode")
          line_code = o.getString("lineCode")
          start_dept = o.getString("startDept")
          start_dept_site_id = o.getString("startDeptSiteId")
          start_outer_add_code = o.getString("startOuterAddrCode")
          start_type = o.getString("startType")
          end_dept = o.getString("endDept")
          end_dept_site_id = o.getString("endDeptSiteId")
          end_outer_add_code = o.getString("endOuterAddrCode")
          end_type = o.getString("endType")
          plan_depart_tm = o.getString("planDepartTm")
          actual_depart_tm = o.getString("actualDepartTm")
          plan_arrive_tm = o.getString("planArriveTm")
          actual_arrive_tm = o.getString("actualArriveTm")
          line_time = o.getString("lineTime")
          line_distance = o.getString("lineDistance")
          actual_run_time = o.getString("actualRunTime")
          start_longitude = o.getString("startLongitude")
          start_latitude = o.getString("startLatitude")
          end_longitude = o.getString("endLongitude")
          end_latitude = o.getString("endLatitude")
          require_category = o.getString("requireCategory")
          stop_over_zone_code = o.getString("stopOverZoneCode")
          vehicle_serial = o.getString("vehicleSerial")
          driver_id = o.getString("driverId")
          driver_name = o.getString("driverName")
          actual_capacity_load = o.getString("actualCapacityLoad")
          capacity_load = o.getString("capacityLoad")
          transoport_level = o.getString("transoportLevel")
          to_ground = o.getString("toGround")
          biz_type = o.getString("bizType")
          carrier_name = o.getString("carrierName")
          is_stop = o.getString("isStop")
          carrier_type = o.getString("carrierType")
          plf_flag = ""
          state = o.getString("state")
          last_update_tm = o.getString("lastUpdateTm")
          full_load_weight = o.getString("fullLoadWeight")
          votes_l = o.getString("votesL")
          votes_lw = o.getString("votesLw")
          votes_s = o.getString("votesS")
          votes_n = o.getString("votesN")
          votes_d = o.getString("votesD")
          votes_w = o.getString("votesW")
          votes_sp = o.getString("votesSp")
          votes_dp = o.getString("votesDp")
          votes_pw = o.getString("votesPw")
          contnr_code = o.getString("contnrCode")
          push_bdp_count = o.getString("pushBdpCount")
          main_driver_account = o.getString("mainDriverAccount")
          line_require_id = o.getString("lineRequireId")
          start_sortnum = o.getString("startSortnum")
          end_sortnum = o.getString("endSortnum")
          `type` = o.getString("type")
          time_type = o.getString("timeType")
          carrier_code = o.getString("carrierCode")
          carrier_id = o.getString("carrierId")
          src_city_name = o.getString("srcCityName")
          dest_city_name = o.getString("destCityName")
          sf_outer_vehicle_from = o.getString("sfOuterVehicleFrom")
          child_carrier_name = o.getString("childCarrierName")
          child_carrier_id = o.getString("childCarrierId")
          child_carrier_code = o.getString("childCarrierCode")
          deputy_driver_account = o.getString("childCarrierCode")
          deputy_driver_name = o.getString("deputyDriverName")
        }

        ScmPlanRecall(
          task_subid, task_id, sort_num, task_area_code, line_code, start_dept, start_dept_site_id, start_outer_add_code, start_type, end_dept, end_dept_site_id, end_outer_add_code, end_type, plan_depart_tm, actual_depart_tm, plan_arrive_tm, actual_arrive_tm, line_time, line_distance, actual_run_time, start_longitude, start_latitude, end_longitude, end_latitude, require_category, stop_over_zone_code, vehicle_serial, driver_id, driver_name, actual_capacity_load, capacity_load, transoport_level, to_ground, biz_type, carrier_name, is_stop, carrier_type, plf_flag, state, last_update_tm, full_load_weight, votes_l, votes_lw, votes_s, votes_n, votes_d, votes_w, votes_sp, votes_dp, votes_pw, contnr_code, push_bdp_count, main_driver_account, line_require_id,
          start_sortnum, end_sortnum, `type`, time_type, carrier_code, carrier_id,src_city_name,dest_city_name,sf_outer_vehicle_from,child_carrier_name,child_carrier_id,child_carrier_code,deputy_driver_account,deputy_driver_name,
          inc_day
        )
      })
      .filter(o => o.task_id != "")
      .toDF()
      .persist(StorageLevel.MEMORY_AND_DISK)
    //    GetDFCountAndSampleData(logger, plan_recallDF, "写入hive的结果数据")
    df2HiveByOverwrite(logger, plan_recallDF.coalesce(3), "dm_gis.scm_plan_recall")
    plan_recallDF.unpersist()
  }

}
