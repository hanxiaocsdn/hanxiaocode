package app.routeLabel

import app.runLimited.DealLocusAbnormalDataFromLimited.get_distance2
import com.alibaba.fastjson.JSONObject
import entry.TrackQuality
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByAppend, df2HiveByOverwrite}
import utils.SparkConfigUtil

import scala.collection.mutable.ListBuffer
import scala.util.Random

/**
  * 任务名称：轨迹质量明细和相应指标数据
  * 任务ID：443334
  * 需求人员：陈俏秀 80006160
  * 开发人员：王冬冬 01413698
  */
object TrackQualityDetailFromDeviceAndLoc {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)


    def main(args: Array[String]): Unit = {

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)


        val device_sql: String =
            s"""
               |select
               |  inc_day,
               |  un,
               |  zx,
               |  zy,
               |  dx,
               |  dy,
               |  state,
               |  ak,
               |  tm,
               |  '' as xh,
               |  lead(tm,1,'') over(partition by un,ak order by tm) tm2,
               |  lead(zx,1,'') over(partition by un,ak order by tm) zx2,
               |  lead(zy,1,'') over(partition by un,ak order by tm) zy2
               |from
               |  dm_gis.gis_vms_track_device_track_flatmap
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        val loc_sql: String =
            s"""
               |select
               |  inc_day,
               |  un,
               |  zx,
               |  zy,
               |  dx,
               |  dy,
               |  state,
               |  ak,
               |  tm,
               |  xh,
               |  lead(tm,1,'') over(partition by un,ak order by tm) tm2,
               |  lead(zx,1,'') over(partition by un,ak order by tm) zx2,
               |  lead(zy,1,'') over(partition by un,ak order by tm) zy2
               |from
               |  dm_gis.esg_gis_loc_trajectory_ewl
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin


        logger.error(device_sql)
        logger.error(loc_sql)


        // 全国硬件采集设备数据,按ak、un聚合后明细
        val deviceDF: DataFrame = getQualityDetail(spark, device_sql)
        df2HiveByOverwrite(logger, deviceDF, "dm_gis.track_quality_detail")
        deviceDF.unpersist()

        // 全国车行骑行GPS轨迹数据,按ak、un聚合后明细
        val locDF: DataFrame = getQualityDetail(spark, loc_sql)
        df2HiveByAppend(logger, locDF, "dm_gis.track_quality_detail")
        locDF.unpersist()


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }


    // 判断延迟时间
    def getDelayTime: UserDefinedFunction = udf((xh: String, tm: String) => {
        var delay_time: Long = 0 // 0：表示延迟时间为空

        try {
            val xh2: Long = xh.toLong / 1000
            val tm2: Long = tm.toLong
            delay_time = xh2 - tm2
        } catch {
            case e: Exception => println(e.getMessage)
        }

        delay_time
    })

    // 判断是否飘逸
    def isSlide: UserDefinedFunction = udf((state: String, zx: String, zy: String, dx: String, dy: String) => {
        var is_slide: Boolean = false

        val state_list = List("19", "1000", "1001", "1002")
        if (state_list.contains(state)) {
            try {
                val zx2: Double = zx.toDouble
                val zy2: Double = zy.toDouble
                val dx2: Double = dx.toDouble
                val dy2: Double = dy.toDouble

                val d: Double = get_distance2(zx2, zy2, dx2, dy2)

                if (d > 5) is_slide = true
            } catch {
                case e: Exception => println("劳资不开心:" + e.getMessage)
            }
        }

        is_slide
    })

    // 总的缺失时间
    def getTrackLoseTime(iters: Iterable[Row]): (Long, String, String) = {
        var track_lose_time: Long = 0

        // 按时间戳对轨迹从小到大排序排序
        val order_ist: List[Row] = iters
          .toList
          .sortWith((r1, r2) => {
              val tm1: Long = r1.getAs[String]("tm").toLong
              val tm2: Long = r2.getAs[String]("tm").toLong
              tm1 < tm2
          })

        // 轨迹开始和结束时间
        val tracks_start_time: String = order_ist.head.getAs[String]("tm")
        val tracks_end_time: String = order_ist.last.getAs[String]("tm")

        for (elem <- iters) {
            val front_zx: Double = elem.getAs[String]("zx").toDouble
            val front_zy: Double = elem.getAs[String]("zy").toDouble
            val front_tm: Long = elem.getAs[String]("tm").toLong

            try {
                val end_zx: Double = elem.getAs[String]("zx2").toDouble
                val end_zy: Double = elem.getAs[String]("zy2").toDouble
                val end_tm: Long = elem.getAs[String]("tm2").toLong

                val d: Double = get_distance2(front_zx, front_zy, end_zx, end_zy)
                val l: Long = end_tm - front_tm

                if (d > 5 && l > 600) track_lose_time += l
            } catch {
                case e: Exception => println("劳资不开心:" + e.getMessage)
            }
        }


        (track_lose_time, tracks_start_time, tracks_end_time)
    }

    // 获取所有的轨迹点
    def getTracks(iters: Iterable[Row]): String = {
        val tracksBuff: ListBuffer[String] = new ListBuffer[String]

        for (iter <- iters) {
            val zx: String = iter.getAs[String]("zx")
            val zy: String = iter.getAs[String]("zy")
            tracksBuff.append(zx + zy)
        }
        val str: String = tracksBuff.mkString(";")
        str
    }

    // 获取延迟时间阶段数据
    def getDelayNTracksCn(iters: Iterable[Row]): (Int, Int, Int, Int, Int) = {
        val delay_time_1: ListBuffer[Long] = new ListBuffer[Long]
        val delay_time_5: ListBuffer[Long] = new ListBuffer[Long]
        val delay_time_30: ListBuffer[Long] = new ListBuffer[Long]
        val delay_time_6h: ListBuffer[Long] = new ListBuffer[Long]
        val delay_time_6hup: ListBuffer[Long] = new ListBuffer[Long]

        for (iter <- iters) {
            val delay_time: Long = iter.getAs[Long]("delay_time")
            if (delay_time > 0 && delay_time <= 1 * 60) delay_time_1.append(delay_time)
            else if (delay_time <= 5 * 60) delay_time_5.append(delay_time)
            else if (delay_time <= 30 * 60) delay_time_30.append(delay_time)
            else if (delay_time <= 6 * 60 * 60) delay_time_6h.append(delay_time)
            else delay_time_6hup.append(delay_time)
        }

        val delay1min_tracks_cn: Int = delay_time_1.size
        val delay5min_tracks_cn: Int = delay_time_5.size
        val delay30min_tracks_cn: Int = delay_time_30.size
        val delay6h_tracks_cn: Int = delay_time_6h.size
        val delay6hup_tracks_cn: Int = delay_time_6hup.size

        (delay1min_tracks_cn, delay5min_tracks_cn, delay30min_tracks_cn, delay6h_tracks_cn, delay6hup_tracks_cn)
    }

    // 按ak、un聚合之后的明细数据
    def getQualityDetail(spark: SparkSession, sql: String): DataFrame = {
        import spark.implicits._

        val df: DataFrame = spark
          .sql(sql)
          .withColumn("delay_time", getDelayTime($"xh", $"tm"))
          .withColumn("is_slide", isSlide($"state", $"zx", $"zy", $"dx", $"dy"))
          .rdd
          .groupBy(r => {
              val ak: String = r.getAs[String]("ak")
              val un: String = r.getAs[String]("un")
              val inc_day: String = r.getAs[String]("inc_day")
              val random: Random = new Random()
              (ak, un, inc_day, random.nextInt(1000))
          })
          .map(r => {
              val (ak, un, inc_day, random) = r._1
              val iters: Iterable[Row] = r._2
              val (track_lose_time, tracks_start_time, tracks_end_time) = getTrackLoseTime(iters)

              // 所有的轨迹点
              val tracks: String = getTracks(iters)

              val (delay1min_tracks_cn, delay5min_tracks_cn,
              delay30min_tracks_cn, delay6h_tracks_cn, delay6hup_tracks_cn) = getDelayNTracksCn(iters)

              // 飘逸的轨迹数
              val drift_tracks_cn: Int = iters
                .toList
                .count(iter => iter.getAs[Boolean]("is_slide"))

              val o: JSONObject = new JSONObject()
              o.put("track_lose_time", track_lose_time)
              o.put("delay1min_tracks_cn", delay1min_tracks_cn)
              o.put("delay5min_tracks_cn", delay5min_tracks_cn)
              o.put("delay30min_tracks_cn", delay30min_tracks_cn)
              o.put("delay6h_tracks_cn", delay6h_tracks_cn)
              o.put("delay6hup_tracks_cn", delay6hup_tracks_cn)
              o.put("drift_tracks_cn", drift_tracks_cn)
              o.put("tracks_start_time", tracks_start_time)
              o.put("tracks_end_time", tracks_end_time)
              o.put("tracks", tracks)
              o.put("random", random)

              ((ak, un, inc_day), o)
          })
          .groupByKey()
          .map(r => {
              val (ak, un, inc_day) = r._1
              val iter: Iterable[JSONObject] = r._2

              val track_lose_timeBuff: ListBuffer[Long] = new ListBuffer[Long]
              val tracks_timeBuff: ListBuffer[String] = new ListBuffer[String]
              val tracksBuff: ListBuffer[(String, Int)] = new ListBuffer[(String, Int)]
              val delay_time_1: ListBuffer[Int] = new ListBuffer[Int]
              val delay_time_5: ListBuffer[Int] = new ListBuffer[Int]
              val delay_time_30: ListBuffer[Int] = new ListBuffer[Int]
              val delay_time_6h: ListBuffer[Int] = new ListBuffer[Int]
              val delay_time_6hup: ListBuffer[Int] = new ListBuffer[Int]
              val drift_tracksBuff: ListBuffer[Int] = new ListBuffer[Int]

              for (o <- iter) {
                  track_lose_timeBuff.append(o.getLong("track_lose_time"))
                  tracks_timeBuff.append(o.getString("tracks_start_time"))
                  tracks_timeBuff.append(o.getString("tracks_end_time"))

                  delay_time_1.append(o.getInteger("delay1min_tracks_cn"))
                  delay_time_5.append(o.getInteger("delay5min_tracks_cn"))
                  delay_time_30.append(o.getInteger("delay30min_tracks_cn"))
                  delay_time_6h.append(o.getInteger("delay6h_tracks_cn"))
                  delay_time_6hup.append(o.getInteger("delay6hup_tracks_cn"))

                  drift_tracksBuff.append(o.getInteger("drift_tracks_cn"))

                  val tracks: String = o.getString("tracks")
                  val arr: Array[String] = tracks.split(";")
                  for (elem <- arr) tracksBuff.append((elem, 1))
              }


              var is_track_lose: String = "0"
              val track_lose_time: Long = track_lose_timeBuff.sum
              if (track_lose_time > 0) is_track_lose = "-1"
              val tracks_start_time: String = tracks_timeBuff.min
              val tracks_end_time: String = tracks_timeBuff.max

              val delay1min_tracks_cn: Int = delay_time_1.sum
              val delay5min_tracks_cn: Int = delay_time_5.sum
              val delay30min_tracks_cn: Int = delay_time_30.sum
              val delay6h_tracks_cn: Int = delay_time_6h.sum
              val delay6hup_tracks_cn: Int = delay_time_6hup.sum

              val drift_tracks_cn: Int = drift_tracksBuff.sum


              var is_re_upload: String = "0" // 0 表示不存在打转 -1 表示存在原地打转
              val tracks_cn: Int = tracksBuff.size // 所有轨迹点

              val upload_fre: Double = ((tracks_end_time.toDouble - tracks_start_time.toDouble - track_lose_time.toDouble) / tracks_cn).formatted("%.2f").toDouble

              val track_max: Double = tracksBuff
                .groupBy(r => r._1)
                .map(r => r._2.size)
                .max
                .toDouble

              val d: Double = track_max / tracks_cn
              if (d > 0.9) is_re_upload = "-1"

              TrackQuality(ak, un, is_track_lose, track_lose_time, is_re_upload, tracks_cn, delay1min_tracks_cn,
                  delay5min_tracks_cn, delay30min_tracks_cn, delay6h_tracks_cn, delay6hup_tracks_cn,
                  drift_tracks_cn, tracks_start_time, tracks_end_time, upload_fre, inc_day
              )
          })
          .toDF()
          .coalesce(100)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, df, "按ak+un聚合后的明细数据")

        df
    }

}
