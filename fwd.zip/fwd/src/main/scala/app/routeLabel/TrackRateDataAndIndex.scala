package app.routeLabel

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.TaskRate
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.HttpConnection.httpPost
import utils.SparkConfigUtil

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
  * 任务名称：车辆轨迹完整明细和指标
  * 任务ID：422391(已下线20230626)
  * 需求人员：陈俏秀 80006160
  * 开发人员：王冬冬 01413698
  */
object TrackRateDataAndIndex {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val track_rate_url: String = config.getString("track_rate_url")

    def main(args: Array[String]): Unit = {

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 获取任务明细
        val rateDF: DataFrame = getRateDetail(spark, start_time, end_time)
        // 按 type，阈值 统计相应指标
        getrateIndex(spark, rateDF)

        rateDF.unpersist()


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }


    // 调用完整率计算接口
    def callTrackRate(r: Row): ListBuffer[TaskRate] = {
        val listBuff = new ListBuffer[TaskRate]()

        val task_area_code: String = r.getAs[String]("task_area_code")
        val task_id: String = r.getAs[String]("task_id")
        val vehicle_serial: String = r.getAs[String]("vehicle_serial")
        val src_longitude: String = r.getAs[String]("src_longitude")
        val src_latitude: String = r.getAs[String]("src_latitude")
        val dest_longitude: String = r.getAs[String]("dest_longitude")
        val dest_latitude: String = r.getAs[String]("dest_latitude")
        val plan_depart_tm: String = r.getAs[String]("plan_depart_tm")
        val plan_arrive_tm: String = r.getAs[String]("plan_arrive_tm")
        val actual_depart_tm: String = r.getAs[String]("actual_depart_tm")
        val actual_arrive_tm: String = r.getAs[String]("actual_arrive_tm")
        val inc_day: String = r.getAs[String]("inc_day")

        val actual_depart_tm2: String = actual_depart_tm
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")

        val actual_arrive_tm2: String = actual_arrive_tm
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .replaceAll(":", "")


        val parm: JSONObject = new JSONObject()

        val arr: JSONArray = new JSONArray()
        val parm2: JSONObject = new JSONObject()
        parm2.put("beginDateTime", actual_depart_tm2)
        parm2.put("endDateTime", actual_arrive_tm2)
        parm2.put("beginLon", src_longitude)
        parm2.put("beginLat", src_latitude)
        parm2.put("endLon", dest_longitude)
        parm2.put("endLat", dest_latitude)
        parm2.put("index", "1")

        arr.add(0, parm2)
        parm.put("stopList", arr)

        parm.put("ak", "87a1347bc3944718911a05c21ec888a9")
        parm.put("taskId", task_id)
        parm.put("un", vehicle_serial)

        val type_list = List("0", "305", "401", "1010", "1011")
        for (i <- type_list) {
            parm.put("type", i)
            parm.put("timeThreshold", "120")
            parm.put("disThreshold", "1000")

            val jsonStr: String = httpPost(3, track_rate_url, parm.toJSONString)
            try {
                val o: JSONObject = JSON.parseObject(jsonStr)
                val status: String = o.getString("status")
                if (status == "0") {
                    val result: JSONObject = o.getJSONObject("result")
                    if (result != null && !result.isEmpty) {
                        val data: JSONObject = result.getJSONObject("data")
                        if (data != null && !data.isEmpty) {
                            val vir_dis: Double = data.getDouble("virDis")
                            val real_dis: Double = data.getDouble("realDis")
                            var track_rate: Double = 0.0
                            if (vir_dis != 0.0) track_rate = real_dis / vir_dis

                            listBuff.append(TaskRate(
                                task_area_code, task_id, vehicle_serial, src_longitude, src_latitude, dest_longitude, dest_latitude,
                                actual_depart_tm, actual_arrive_tm, plan_depart_tm, plan_arrive_tm, i,
                                "120", "1000", vir_dis.toString, real_dis.toString, track_rate.toString, inc_day
                            ))
                        }
                    }
                }
            } catch {
                case e: Exception => logger.error("劳资不开心:" + e.getMessage)
            }

            if (i == "0") {
                parm.put("type", i)
                parm.put("timeThreshold", "600")
                parm.put("disThreshold", "5000")

                val jsonStr: String = httpPost(3, track_rate_url, parm.toJSONString)
                try {
                    val o: JSONObject = JSON.parseObject(jsonStr)
                    val status: String = o.getString("status")
                    if (status == "0") {
                        val result: JSONObject = o.getJSONObject("result")
                        if (result != null && !result.isEmpty) {
                            val data: JSONObject = result.getJSONObject("data")
                            if (data != null && !data.isEmpty) {
                                val vir_dis: Double = data.getDouble("virDis")
                                val real_dis: Double = data.getDouble("realDis")
                                var track_rate: Double = 0.0
                                if (vir_dis != 0.0) track_rate = real_dis / vir_dis

                                listBuff.append(TaskRate(
                                    task_area_code, task_id, vehicle_serial, src_longitude, src_latitude, dest_longitude, dest_latitude,
                                    actual_depart_tm, actual_arrive_tm, plan_depart_tm, plan_arrive_tm, i,
                                    "600", "5000", vir_dis.toString, real_dis.toString, track_rate.toString, inc_day
                                ))
                            }
                        }
                    }
                } catch {
                    case e: Exception => logger.error("劳资不开心:" + e.getMessage)
                }
            }

        }

        listBuff
    }

    // 获取任务完整率明细
    def getRateDetail(spark: SparkSession, start_time: String, end_time: String): DataFrame = {
        import spark.implicits._

        val sql: String =
            s"""
               |select
               |  task_area_code,
               |  task_id,
               |  vehicle_serial,
               |  src_longitude,
               |  src_latitude,
               |  dest_longitude,
               |  dest_latitude,
               |  actual_depart_tm,
               |  actual_arrive_tm,
               |  plan_depart_tm,
               |  plan_arrive_tm,
               |  inc_day
               |from
               |  dm_grd.grd_new_task_detail
               |where
               |  state = 6
               |  and task_area_code in('010Y','020Y','021Y','027Y','028Y','111Y','333Y')
               |  and (actual_depart_tm != '' and actual_depart_tm is not null)
               |  and (actual_arrive_tm != '' and actual_arrive_tm is not null)
               |  and inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin
        logger.error(sql)

        val rateDF: DataFrame = spark
          .sql(sql)
          .repartition(600)
          .flatMap(r => {
              val rates: ListBuffer[TaskRate] = callTrackRate(r)
              rates
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, rateDF, "任务完整率明细数据")
        df2HiveByOverwrite(logger, rateDF, "dm_gis.task_integrity_rate_detail")

        rateDF
    }

    // 获取任务完整率指标
    def getrateIndex(spark: SparkSession, rateDF: DataFrame): Unit = {
        import spark.implicits._

        val indexDF: DataFrame = rateDF
          .rdd
          .groupBy(r => {
              val my_type: String = r.getAs[String]("type")
              val inc_day: String = r.getAs[String]("inc_day")
              val time_threshold: String = r.getAs[String]("time_threshold")
              val dis_threshold: String = r.getAs[String]("dis_threshold")
              val threshold: String = dis_threshold + "m," + time_threshold + "s"
              (my_type, threshold, inc_day)
          })
          .map(r => {
              val (my_type, threshold, inc_day) = r._1
              val iters: Iterable[Row] = r._2
              val cnt: Int = iters.size

              var ver_trackrate: Double = 0.0
              val task_id_set = new mutable.HashSet[String]
              val task_id_set_30 = new mutable.HashSet[String]
              val task_id_set_60 = new mutable.HashSet[String]
              val task_id_set_90 = new mutable.HashSet[String]
              val task_id_set_95 = new mutable.HashSet[String]
              val task_id_set_100 = new mutable.HashSet[String]
              for (r <- iters) {
                  val track_rate: Double = r.getAs[String]("track_rate").toDouble
                  ver_trackrate += track_rate

                  val task_id: String = r.getAs[String]("task_id")
                  task_id_set.add(task_id)

                  if (track_rate <= 0.3) task_id_set_30.add(task_id)
                  else if (track_rate <= 0.6) task_id_set_60.add(task_id)
                  else if (track_rate <= 0.9) task_id_set_90.add(task_id)
                  else if (track_rate <= 0.95) task_id_set_95.add(task_id)
                  else task_id_set_100.add(task_id)
              }

              ver_trackrate = ver_trackrate / cnt
              val task_cn: Int = task_id_set.size
              val task30_cn: Int = task_id_set_30.size
              val task60_cn: Int = task_id_set_60.size
              val task90_cn: Int = task_id_set_90.size
              val task95_cn: Int = task_id_set_95.size
              val task100_cn: Int = task_id_set_100.size

              (my_type, threshold, ver_trackrate, task_cn, task30_cn, task60_cn, task90_cn, task95_cn, task100_cn, inc_day)
          })
          .toDF("type", "threshold", "ver_trackrate", "task_cn", "task30_cn", "task60_cn", "task90_cn", "task95_cn", "task100_cn", "inc_day")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, indexDF, "任务完整率指标数据")
        df2HiveByOverwrite(logger, indexDF, "dm_gis.task_integrity_rate_index")

        indexDF.unpersist()
    }


}
