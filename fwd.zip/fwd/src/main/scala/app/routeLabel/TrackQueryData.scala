package app.routeLabel

import com.alibaba.fastjson.{JSON, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByAppend, getNowTime2}
import utils.HttpConnection.httpPost
import utils.SparkConfigUtil

import scala.collection.mutable.ListBuffer

/**
  * 任务名称：车辆轨迹查询结果监控
  * 任务ID：421934 (已下线20230616)
  * 需求人员：陈俏秀 80006160
  * 开发人员：王冬冬 01413698
  */
object TrackQueryData {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val track_query_url: String = config.getString("track_query_url")

    def main(args: Array[String]): Unit = {

        if (args.length != 4) {
            logger.error(
                """
                  |需要输入4个参数：
                  |    start_time、end_time、arrive_tm_start、arrive_tm_start_end
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val arrive_tm_start: String = args(2)
        val arrive_tm_start_end: String = args(3)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")
        logger.error(s"计划到车开始日期：$arrive_tm_start " + s"计划到车结束日期：$arrive_tm_start_end")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        val sql: String =
            s"""
               |select
               |  task_area_code,
               |  task_id,
               |  vehicle_serial,
               |  plan_depart_tm,
               |  plan_arrive_tm,
               |  inc_day
               |from
               |  dm_grd.grd_new_task_detail
               |where
               |  state = '4'
               |  and task_area_code in('010Y','020Y','021Y','027Y','028Y','111Y','333Y')
               |  and inc_day >= '$start_time'
               |  and inc_day <= '$end_time'
               |  and plan_arrive_tm >= '$arrive_tm_start 00:00:00'
               |  and plan_arrive_tm < '$arrive_tm_start_end 00:00:00'
               |""".stripMargin
        logger.error(sql)

        // 获取轨迹查询明细
        gettrackQueryDetail(spark,sql)



        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }


    // 调用轨迹查询接口
    def callTrackQuery(vehicle_serial: String): ListBuffer[(String, String, JSONObject)] = {

        val type_list = List("0", "305", "401", "1010", "1011")
        val tmRange_list = List("1", "5", "10")

        // 存放每次返回的JSON
        val listBuff = new ListBuffer[(String, String, JSONObject)]
        for (i <- type_list) {
            for (j <- tmRange_list) {
                val parm: JSONObject = new JSONObject()
                parm.put("un", vehicle_serial)
                parm.put("ak", "87a1347bc3944718911a05c21ec888a9")
                parm.put("rectify", "true")
                parm.put("unType", "0")
                parm.put("type", i)
                parm.put("tmRange", j)

                val jsonStr: String = httpPost(3, track_query_url, parm.toJSONString)

                try {
                    val json: JSONObject = JSON.parseObject(jsonStr)
                    listBuff.append((i, j, json))
                } catch {
                    case e: Exception => logger.error("劳资不开心:" + e.getMessage)
                }
            }
        }

        listBuff
    }

    // 调用接口过后的最终数据
    def gettrackQueryDetail(spark: SparkSession,sql:String): Unit ={
        // 导入隐式转换
        import spark.implicits._

        // 调用接口获取相应数据
        val resultDF: DataFrame = spark
          .sql(sql)
          .repartition(5)
          .flatMap(r => {
              val queryBuff = new ListBuffer[(String, String, String, String, String, String, String, String, String, String)]

              val task_area_code: String = r.getAs[String]("task_area_code")
              val task_id: String = r.getAs[String]("task_id")
              val vehicle_serial: String = r.getAs[String]("vehicle_serial")
              val plan_depart_tm: String = r.getAs[String]("plan_depart_tm")
              val plan_arrive_tm: String = r.getAs[String]("plan_arrive_tm")
              val inc_day: String = r.getAs[String]("inc_day")

              var listBuff = new ListBuffer[(String, String, JSONObject)]
              val current_time: String = getNowTime2
              if (plan_arrive_tm > current_time) listBuff = callTrackQuery(vehicle_serial)

              if (listBuff != null && listBuff.nonEmpty) {
                  for (list <- listBuff) {
                      val (my_type, tmRange, o) = list
                      val status: String = o.getString("status")
                      if (status == "0") {
                          val result: JSONObject = o.getJSONObject("result")
                          if (result != null) {
                              val jsonStr: String = result.toJSONString
                              queryBuff.append((task_area_code, task_id, vehicle_serial, plan_depart_tm, plan_arrive_tm, my_type, tmRange, jsonStr, current_time, inc_day))
                          }
                      }
                  }
              }

              queryBuff
          })
          .toDF("task_area_code", "task_id", "vehicle_serial", "plan_depart_tm", "plan_arrive_tm", "type", "tm_range", "result", "time", "inc_day")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, resultDF, "调用接口之后的最终数据")
        df2HiveByAppend(logger, resultDF, "dm_gis.vehicle_serial_track_rtquery")

        resultDF.unpersist()
    }

}
