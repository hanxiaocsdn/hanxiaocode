package app.routeLabel

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, GetRDDCountAndSampleData, df2HiveByOverwrite, getNowTime, row2Json, runInterfaceWithAkLimit, testDF2Hive}
import utils.HttpConnection.httpPost
import utils.SparkConfigUtil

import scala.util.control.Breaks.{break, breakable}

/**
  * 任务名称：获取小哥轨迹完整率数据明细
  * 任务ID：437713（已下线2022年）
  * 需求人员：陈俏秀 80006160
  * 开发人员：王冬冬 01413698
  */
object CourierTrackRateAndDritData {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    val courier_track_url: String = config.getString("courier_track_url")
    //    val courier_track_url2: String = config.getString("courier_track_url2")
    val courier_track_url2: String = "gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrateDetail"

    def main(args: Array[String]): Unit = {

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    csvpath、csvpath2
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val csvpath: String = args(0)
        val csvpath2: String = args(1)
        logger.error(s"csv文件路径：$csvpath ")
        logger.error(s"csv文件路径：$csvpath2 ")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)


        // 小哥轨迹完整率信息
        getcourierTrackRateInfo(spark, csvpath)

        // 小哥轨迹漂移信息
        CourierTrackDrift(spark, csvpath)
        CourierTrackDrift(spark, csvpath2, 2)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()
    }

    // 获取小哥信息
    def getCourierInfo(spark: SparkSession, csvpath: String): RDD[JSONObject] = {
        val csvRDD: RDD[JSONObject] = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("sep", ",")
          .load(csvpath)
          .rdd
          .map(row2Json)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetRDDCountAndSampleData(logger, csvRDD, "小哥信息")

        csvRDD
    }

    // 获取小哥轨迹完整率数据
    def getCourierInfo(ak: String, o: JSONObject): JSONObject = {
        val un: String = o.getString("un")
        val actual_depart_tm: String = o.getString("actual_depart_tm")
        val actual_arrive_tm: String = o.getString("actual_arrive_tm")

        val parm: JSONObject = new JSONObject()
        parm.put("ak", ak)
        parm.put("un", un)
        parm.put("beginDateTime", actual_depart_tm)
        parm.put("endDateTime", actual_arrive_tm)

        parm.put("type", 1)
        parm.put("addpoint", 1)
        parm.put("compensate", true)
        parm.put("unType", 0)
        parm.put("hasRate", 1)

        val jsonStr: String = httpPost(3, courier_track_url, parm.toJSONString)
        try {
            val o2: JSONObject = JSON.parseObject(jsonStr)
            val status: String = o2.getString("status")
            if (status == "0") {
                val result: JSONObject = o2.getJSONObject("result")
                val data: JSONObject = result.getJSONObject("data")
                val rate: JSONObject = data.getJSONObject("rate")
                o.put("min1", rate.getString("min1"))
                o.put("min3", rate.getString("min3"))
                o.put("min5", rate.getString("min5"))
                o.put("min10", rate.getString("min10"))
                o.put("min15", rate.getString("min15"))

            }
        } catch {
            case e: Exception => logger.error("小哥轨迹完成率调用失败:" + e.getMessage)
        }

        o
    }

    // 获取小哥数据
    def getcourierTrackRateInfo(spark: SparkSession, csvpath: String): Unit = {
        import spark.implicits._

        val csvRDD: RDD[JSONObject] = getCourierInfo(spark, csvpath)

        val courierDF: DataFrame = runInterfaceWithAkLimit(logger, spark, csvRDD, getCourierInfo, 100, "87a1347bc3944718911a05c21ec888a9", 2000)
          .map(o => {
              val un: String = o.getString("un")
              val actual_depart_tm: String = o.getString("actual_depart_tm")
              val actual_arrive_tm: String = o.getString("actual_arrive_tm")
              val min1: String = o.getString("min1")
              val min3: String = o.getString("min3")
              val min5: String = o.getString("min5")
              val min10: String = o.getString("min10")
              val min15: String = o.getString("min15")
              (un, actual_depart_tm, actual_arrive_tm, min1, min3, min5, min10, min15)
          })
          .toDF("un", "actual_depart_tm", "actual_arrive_tm", "min1", "min3", "min5", "min10", "min15")
          .withColumn("inc_day", lit(getNowTime))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, courierDF, "小哥轨迹完整率数据")
        df2HiveByOverwrite(logger, courierDF, "dm_gis.courier_track_rate_detail")

        csvRDD.unpersist()
        courierDF.unpersist()

    }

    // 获取小哥轨迹数据
    def getCourierTrackData(ak: String, o: JSONObject): JSONObject = {
        val un: String = o.getString("un")
        val actual_depart_tm: String = o.getString("actual_depart_tm")
        val actual_arrive_tm: String = o.getString("actual_arrive_tm")

        val parm: JSONObject = new JSONObject()
        parm.put("ak", ak)
        parm.put("un", un)
        parm.put("beginDateTime", actual_depart_tm)
        parm.put("endDateTime", actual_arrive_tm)

        parm.put("type", 0)
        parm.put("addpoint", 1)
        parm.put("compensate", true)
        parm.put("unType", 0)
        parm.put("opt", 1)

        val jsonStr: String = httpPost(2, courier_track_url2, parm.toJSONString)
        try {
            val o2: JSONObject = JSON.parseObject(jsonStr)
            val status: String = o2.getString("status")
            if (status == "0") {
                val result: JSONObject = o2.getJSONObject("result")
                val data: JSONObject = result.getJSONObject("data")
                val track: JSONArray = data.getJSONArray("track")
                o.put("track", track)
            }
        } catch {
            case e: Exception => println("小哥轨迹调用失败:" + e.getMessage)
        }

        o
    }

    // 判断小哥轨迹是否异常飘逸
    def CourierTrackDrift(spark: SparkSession, csvpath: String, flag: Int = 1): Unit = {
        import spark.implicits._

        val csvRDD: RDD[JSONObject] = getCourierInfo(spark, csvpath)

        val trackDriftRDD: RDD[JSONObject] = runInterfaceWithAkLimit(logger, spark, csvRDD, getCourierTrackData, 100, "87a1347bc3944718911a05c21ec888a9", 2000)

        val trackDriftDS: Dataset[String] = trackDriftRDD
          .map(o => {
              val track: JSONArray = o.getJSONArray("track")

              val arr: Array[Int] = Array(0)
              val arr2: Array[Int] = Array(0)
              try {
                  val n: Int = track.size()
                  breakable({
                      for (i <- 0 until n - 1) {
                          val o1: JSONObject = track.getJSONObject(i)
                          val o2: JSONObject = track.getJSONObject(i + 1)

                          val sumDist1: Double = o1.getDouble("sumDist")
                          val sumDist2: Double = o2.getDouble("sumDist")

                          val tm1: Long = o1.getLong("tm")
                          val tm2: Long = o2.getLong("tm")

                          val s: Double = sumDist2 - sumDist1
                          val t: Long = tm2 - tm1

                          if (s > 1000 && 3.6 * s / t > 300) {
                              arr(0) = 1
                              break()
                          }

                      }
                  })

                  breakable({
                      for (i <- 0 until n - 1) {
                          val o1: JSONObject = track.getJSONObject(i)
                          val o2: JSONObject = track.getJSONObject(i + 1)

                          val sumDist1: Double = o1.getDouble("sumDist")
                          val sumDist2: Double = o2.getDouble("sumDist")

                          val tm1: Long = o1.getLong("tm")
                          val tm2: Long = o2.getLong("tm")

                          val s: Double = sumDist2 - sumDist1
                          val t: Long = tm2 - tm1

                          if (s > 5000 && t > 600) {
                              arr2(0) = 1
                              break()
                          }

                      }
                  })

              } catch {
                  case e: Exception => logger.error("小哥轨迹track数据异常:" + e.getMessage)
              }

              val is_yc_drift: String = if (arr.contains(1)) "1" else "0"
              val is_lost: String = if (arr2.contains(1)) "1" else "0"
              o.remove("track")

              o.put("is_yc_drift", is_yc_drift)
              o.put("is_lost", is_lost)
              o.put("inc_day", getNowTime)
              o.toJSONString
          })
          .toDS()

        val trackDriftDF: DataFrame = spark.read.json(trackDriftDS).persist()
        GetDFCountAndSampleData(logger, trackDriftDF, "轨迹飘逸样例数据")

        if (flag == 1) testDF2Hive(logger, trackDriftDF, "default.courier_track_drift_detail1") else testDF2Hive(logger, trackDriftDF, "default.courier_track_drift_detail2")

    }


}
