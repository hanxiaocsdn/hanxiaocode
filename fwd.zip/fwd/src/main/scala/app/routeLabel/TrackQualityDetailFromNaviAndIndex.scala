package app.routeLabel

import app.routeLabel.TrackQualityDetailFromDeviceAndLoc.getQualityDetail
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByAppend, df2HiveByOverwrite}
import utils.SparkConfigUtil

/**
  * 任务名称：轨迹质量明细和相应指标数据
  * 任务ID：443334
  * 需求人员：陈俏秀 80006160
  * 开发人员：王冬冬 01413698
  */
object TrackQualityDetailFromNaviAndIndex {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        val navi_sql: String =
            s"""
               |select
               |  inc_day,
               |  carno as un,
               |  x  as zx,
               |  y  as zy,
               |  '' as dx,
               |  '' as dy,
               |  '' as state,
               |  ak,
               |  tm,
               |  xh,
               |  lead(tm,1,'') over(partition by carno,ak order by tm) tm2,
               |  lead(x,1,'') over(partition by carno,ak order by tm) zx2,
               |  lead(y,1,'') over(partition by carno,ak order by tm) zy2
               |from
               |  dm_gis.gis_rss_eta_navi_track_flatmap
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin
        val quality_sql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.track_quality_detail
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin

        logger.error(navi_sql)
        logger.error(quality_sql)

        // 全国车行路径规划数据,按ak、un聚合后明细
        val naviDF: DataFrame = getQualityDetail(spark, navi_sql)
        df2HiveByAppend(logger, naviDF, "dm_gis.track_quality_detail")
        naviDF.unpersist()

        // 按ak汇总计算监控指标
        trackQualityIndex(spark,quality_sql)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 按ak汇总指标
    def trackQualityIndex(spark:SparkSession,sql:String): Unit = {
        val track_quality_indexDF: DataFrame = spark
          .sql(sql)
          .groupBy("ak", "inc_day")
          .agg(
              avg("upload_fre").alias("ver_upload_fre"),
              size(collect_set("un")).alias("un_cn"),
              sum(when(col("is_track_lose") === "-1", 1).otherwise(0)).alias("lose_track_cn"),
              sum(when(col("is_re_upload") === "-1", 1).otherwise(0)).alias("re_upload_track_cn"),
              sum("tracks_cn").alias("tracks_cn"),
              sum("delay1min_tracks_cn").alias("delay1min_tracks_cn"),
              sum("delay5min_tracks_cn").alias("delay5min_tracks_cn"),
              sum("delay30min_tracks_cn").alias("delay30min_tracks_cn"),
              sum("delay6h_tracks_cn").alias("delay6h_tracks_cn"),
              sum("delay6hup_tracks_cn").alias("delay6hup_tracks_cn"),
              sum("drift_tracks_cn").alias("drift_tracks_cn")
          )
          .withColumn("incday", col("inc_day"))
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, track_quality_indexDF, "按ak汇总指标")
        df2HiveByOverwrite(logger, track_quality_indexDF, "dm_gis.track_quality_index")

        track_quality_indexDF.unpersist()
    }

}
