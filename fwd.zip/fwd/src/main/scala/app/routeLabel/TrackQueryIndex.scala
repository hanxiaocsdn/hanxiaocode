package app.routeLabel

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite}
import utils.SparkConfigUtil

/**
  * 任务名称：车辆轨迹查询结果指标
  * 任务ID：422334
  * 需求人员：陈俏秀 80006160
  * 开发人员：王冬冬 01413698
  */
object TrackQueryIndex {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)

        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 获取轨迹查询指标
        gettrackQueryIndex(spark, start_time, end_time)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 按type tm_range 聚合
    def gettrackQueryIndex(spark: SparkSession, start_time: String, end_time: String): Unit = {
        import spark.implicits._

        val sql: String =
            s"""
               |select
               |  *
               |from
               |  dm_gis.vehicle_serial_track_rtquery
               |where
               |  inc_day >= '$start_time'
               |  and inc_day < '$end_time'
               |""".stripMargin
        logger.error(sql)

        val resultDF: DataFrame = spark
          .sql(sql)
          .rdd
          .groupBy(r => {
              val `type`: String = r.getAs[String]("type")
              val tm_range: String = r.getAs[String]("tm_range")
              val inc_day: String = r.getAs[String]("inc_day")
              (`type`, tm_range, inc_day)
          })
          .map(r => {
              val (my_type, tm_range, inc_day) = r._1

              val dy_cn: Int = r._2.size

              var dysuc_cn: Int = 0
              for (iter <- r._2) {
                  val result: String = iter.getAs[String]("result")
                  val obj: JSONObject = JSON.parseObject(result)
                  if (!obj.isEmpty) dysuc_cn += 1
              }

              var re_rate: Double = 0.00
              if (dysuc_cn != 0) re_rate = dysuc_cn.toDouble / dy_cn

              (my_type, tm_range, dy_cn.toString, dysuc_cn.toString, re_rate.toString, inc_day)
          })
          .toDF("type", "tm_range", "dy_cn", "dysuc_cn", "re_rate", "inc_day")
          .coalesce(1)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, resultDF, "最终的聚合数据")
        df2HiveByOverwrite(logger, resultDF, "dm_gis.vehicle_serial_track_rtquery_index")

        resultDF.unpersist()
    }


}
