package app.routeLabel

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.TrackSimilarity2
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.HttpConnection.httpPost
import utils.SparkConfigUtil

import scala.collection.mutable.ArrayBuffer

/**
  * 任务名称：导航点轨迹相似度
  * 任务ID：446908（已下线2022）
  * 需求人员：陈俏秀 80006160
  * 开发人员：王冬冬 01413698
  */
object TrackLegitimateDetailV2 {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val fusion_track_url: String = config.getString("fusion_track_url")
    val courier_track_url: String = config.getString("courier_track_url")
    val track_jp_url: String = config.getString("track_jp_url")
    val track_similarity_url: String = config.getString("track_similarity_url")

    def main(args: Array[String]): Unit = {


        if (args.length != 2) {
            logger.error(
                """
                  |需要输入4个参数：
                  |    start_time、end_time
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        logger.error(s"开始日期：$start_time " + s"结束日期：$end_time")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        val sql: String =
            s"""
               |select
               |  a.task_id,
               |  a.navi_count,
               |  a.navi_order,
               |  a.navi_id,
               |  a.route_count,
               |  a.route_order,
               |  a.routeid,
               |  a.req_count,
               |  a.req_order,
               |  a.request_id,
               |  a.navi_starttime,
               |  a.req_time,
               |  a.req_type,
               |  a.x1,
               |  a.y1,
               |  a.x2,
               |  a.y2,
               |  a.vehicle,
               |  a.vehicle_type,
               |  a.weight,
               |  a.mload,
               |  a.length,
               |  a.width,
               |  a.height,
               |  a.axle_weight,
               |  a.axle_number,
               |  a.plate_color,
               |  a.energy,
               |  a.emit_stand,
               |  a.passport,
               |  a.driver_id,
               |  a.ft_url,
               |  a.plan_date,
               |  a.stype,
               |  a.path_count,
               |  a.opt,
               |  a.strategy,
               |  a.merge,
               |  a.routeid_in,
               |  a.fixed_route,
               |  a.fencedist,
               |  a.reroute,
               |  a.status,
               |  a.pns_status,
               |  a.distance,
               |  a.duration,
               |  a.toll_distance,
               |  a.tolls,
               |  a.src,
               |  a.trafficlight_count,
               |  a.highspeed_distance,
               |  a.flen,
               |  a.tlen,
               |  a.routeid_out,
               |  a.linknum,
               |  a.rc_distance,
               |  a.rdynsdlen,
               |  a.rdynsdcnt,
               |  a.navi_endstatus,
               |  a.navi_endtime,
               |  a.navi_endx,
               |  a.navi_endy,
               |  a.navi_time,
               |  a.diff_time,
               |  a.ft_right,
               |  a.tl_times,
               |  a.tl_navi_time,
               |  a.tl_diff_time,
               |  a.tl_ft_right,
               |  a.req_status,
               |  a.ret,
               |  a.offtime_ratio,
               |  a.yawpoints,
               |  a.yawpoints_count,
               |  a.inc_day,
               |  b.src_province,
               |  b.src_citycode,
               |  b.src_deptcode,
               |  b.dest_province,
               |  b.dest_citycode,
               |  b.dest_deptcode,
               |  b.swid,
               |  b.starts,
               |  b.polyline,
               |  b.links,
               |  b.tracks1,
               |  b.tracks2,
               |  b.navi_distance,
               |  b.similarity1,
               |  b.similarity5,
               |  b.trackstart_distance,
               |  b.trackend_distance,
               |  a.service_id,
               |  a.strategy2
               |from
               |  (
               |    select
               |      *
               |    from
               |      dm_gis.gis_navi_eta_result1
               |    where
               |      inc_day >= '$start_time'
               |      and inc_day <= '$end_time'
               |      and req_type = 'top3'
               |  ) a
               |  join (
               |    select
               |      *
               |    from
               |      dm_gis.gis_navi_eta_result2
               |    where
               |      inc_day >= '$start_time'
               |      and inc_day <= '$end_time'
               |      and req_type = 'top3'
               |      and navi_endtime != ''
               |      and (polyline is not null and polyline != '')
               |  ) b on a.id = b.id
               |""".stripMargin

        // 获取原始数据
        val origRDD: RDD[JSONObject] = getJsonRDD(logger, spark, sql)

        // 获取轨迹查询明细
        gettrackQueryDetail(spark, origRDD)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }


    // 获取offTime信息
    def getoffTimeInfo(ak: String, o: JSONObject): Unit = {
        val un: String = o.getString("vehicle")
        val req_time: String = getDateStr(o.getLongValue("req_time"), "yyyyMMddHHmmss")
        val navi_endtime: String = getDateStr(o.getLongValue("navi_endtime") + 300000, "yyyyMMddHHmmss")

        val parm: JSONObject = new JSONObject()
        parm.put("ak", ak)
        parm.put("un", un)
        parm.put("beginDateTime", req_time)
        parm.put("endDateTime", navi_endtime)

        parm.put("type", 0)
        parm.put("rectify", false)
        parm.put("hasRate", true)

        // 融合轨迹查询
        val jsonStr: String = httpPost(3, fusion_track_url, parm.toJSONString)
        parseJsonStr(o, jsonStr)

        // 单源轨迹查询
        if (o.getString("offtime_min1") == null) {
            parm.put("type", 400)
            val jsonStr: String = httpPost(3, courier_track_url, parm.toJSONString)
            parseJsonStr(o, jsonStr)
        }
    }

    // 解析融合轨迹接口返回的json
    def parseJsonStr(o: JSONObject, jsonStr: String): Unit = {
        try {
            val o2: JSONObject = JSON.parseObject(jsonStr)
            val status: String = o2.getString("status")
            if (status == "0") {
                val result: JSONObject = o2.getJSONObject("result")
                val data: JSONObject = result.getJSONObject("data")
                val rate: JSONObject = data.getJSONObject("rate")
                o.put("offtime_min1", rate.getString("min1"))
                o.put("offtime_min3", rate.getString("min3"))
                o.put("offtime_min5", rate.getString("min5"))
                o.put("offtime_min10", rate.getString("min10"))
                o.put("offtime_min15", rate.getString("min15"))

                val track: JSONArray = data.getJSONArray("track")
                val aklist: String = data.getString("aklist")
                if (aklist != null) o.put("aklist", aklist) else o.put("aklist", track.getJSONObject(0).getString("ak"))

                val tracksBuff = new ArrayBuffer[String]()
                val tracksBuff2 = new JSONArray()
                for (i <- 0 until track.size()) {
                    val t: JSONObject = track.getJSONObject(i)
                    val zx: String = t.getString("zx")
                    val zy: String = t.getString("zy")
                    tracksBuff.append("[" + zx + "," + zy + "]")

                    val obj = new JSONObject()
                    obj.put("type", t.getIntValue("tp"))
                    obj.put("x", zx.toDouble)
                    obj.put("y", zy.toDouble)
                    obj.put("accuracy", t.getIntValue("ac"))
                    obj.put("speed", t.getDoubleValue("sp"))
                    obj.put("azimuth", t.getDoubleValue("be"))
                    obj.put("time", t.getLongValue("tm"))
                    obj.put("index", i)
                    tracksBuff2.add(i, obj)
                }

                o.put("tracks1_new", "[" + tracksBuff.mkString(",") + "]")
                o.put("tracks", tracksBuff2)

            }
        } catch {
            case e: Exception => println("融合轨迹接口调用失败:" + e.getMessage)
        }
    }

    // 获取纠偏轨迹信息
    def getjPTracksInfo(ak: String, o: JSONObject): Unit = {
        val vehicle_type: String = o.getString("vehicle_type")
        val load: Int = o.getDoubleValue("mload").toInt
        val axis: Int = o.getDoubleValue("axle_number").toInt
        val weight: Int = o.getDoubleValue("weight").toInt
        val length: Int = o.getDoubleValue("length").toInt
        val tracks: JSONArray = o.getJSONArray("tracks")

        val parm: JSONObject = new JSONObject()
        val vehicleInfo: JSONObject = new JSONObject()
        if (!isEmptyOrNull(load.toString)) vehicleInfo.put("load", load)
        if (!isEmptyOrNull(axis.toString)) vehicleInfo.put("axis", axis)
        if (!isEmptyOrNull(weight.toString)) vehicleInfo.put("weight", weight)
        if (!isEmptyOrNull(length.toString)) vehicleInfo.put("length", length)

        parm.put("ak", ak)
        parm.put("vehicle", if (isEmptyOrNull(vehicle_type)) 6 else vehicle_type.toDouble.toInt)
        parm.put("retflag", 7)
        parm.put("addpoint", 1)
        parm.put("poiinfo", 1)
        parm.put("mat_ratio", 1)
        parm.put("tracks", tracks)
        parm.put("vehicleInfo", vehicleInfo)

        // 获取纠偏轨迹
        val jsonStr: String = httpPost(3, track_jp_url, parm.toJSONString)
        parseJPJsonStr(o, jsonStr)

        o.remove("tracks")
    }

    // 解析纠偏接口返回的json
    def parseJPJsonStr(o: JSONObject, jsonStr: String): Unit = {
        try {
            val o2: JSONObject = JSON.parseObject(jsonStr)
            val status: String = o2.getString("status")
            if (status == "0") {
                val result: JSONObject = o2.getJSONObject("result")
                val tracks: JSONArray = result.getJSONArray("tracks")

                val tracksBuff = new ArrayBuffer[String]()
                for (i <- 0 until tracks.size()) {
                    val t: JSONObject = tracks.getJSONObject(i)
                    val x: String = t.getString("x")
                    val y: String = t.getString("y")
                    tracksBuff.append("[" + x + "," + y + "]")
                }

                o.put("tracks2_new", "[" + tracksBuff.mkString(",") + "]")
                o.put("distance_new", result.getString("len"))
            }
        } catch {
            case e: Exception => println("轨迹纠偏接口调用失败:" + e.getMessage)
        }
    }

    // 获取轨迹完相似度
    def gettrackSimilarity(ak: String, o: JSONObject): Unit = {
        val vehicle_type: Int = o.getIntValue("vehicle_type")
        val tracks2_new: String = o.getString("tracks2_new")
        val polyline: String = o.getString("polyline")

        val tracks2Arr: JSONArray = formatTracks(tracks2_new)
        val polylineArr: JSONArray = formatTracks(polyline)

        val parm: JSONObject = new JSONObject()
        parm.put("ak", ak)
        parm.put("vehicle", if (isEmptyOrNull(vehicle_type.toString)) 6 else vehicle_type)
        parm.put("retflag", 5)
        parm.put("tracktype", 0)
        parm.put("tracks1", polylineArr)
        parm.put("tracks2", tracks2Arr)

        val jsonStr: String = httpPost(3, track_similarity_url, parm.toJSONString)
        val similArr: Array[String] = parseSimiJson(jsonStr)

        o.put("sim1", similArr(0))
        o.put("sim5", similArr(1))
    }

    // 格式化 tracks
    def formatTracks(tracks: String): JSONArray = {
        val tracks2Arr: Array[String] = tracks
          .replaceAll("\\[", "")
          .replaceAll("],", ";")
          .replaceAll("]]", "")
          .split(";")

        val tracksArr: JSONArray = new JSONArray()
        for (i <- tracks2Arr.indices) {
            val xy: Array[Double] = tracks2Arr(i).split(",").map(_.toDouble)
            val obj = new JSONObject()
            obj.put("x", xy(0))
            obj.put("y", xy(1))
            obj.put("type", 1)
            tracksArr.add(obj)
        }

        tracksArr
    }

    // 解析接口返回的json
    def parseSimiJson(jsonStr: String): Array[String] = {
        val arr = new Array[String](2)
        try {
            val o2: JSONObject = JSON.parseObject(jsonStr)
            val status: String = o2.getString("status")
            if (status == "0") {
                val result: JSONObject = o2.getJSONObject("result")
                arr(0) = result.getString("similarity1")
                arr(1) = result.getString("similarity2")
            }
        } catch {
            case e: Exception => println("相似度接口调用失败:" + e.getMessage)
        }
        arr
    }

    // 合并3个接口
    def getAllInterface(ak: String, o: JSONObject): JSONObject = {
        getoffTimeInfo(ak, o)
        getjPTracksInfo(ak, o)

        val tracks2_new: String = o.getString("tracks2_new")
        if ( tracks2_new != null && tracks2_new != "[]") {
            gettrackSimilarity(ak, o)
        } else {
            o.put("sim1", "0.0")
            o.put("sim5", "0.0")
        }

        o
    }

    // 调用接口过后的最终数据
    def gettrackQueryDetail(spark: SparkSession, origRDD: RDD[JSONObject]): Unit = {
        // 导入隐式转换
        import spark.implicits._

        // 调用接口获取相应数据
        val origDF: DataFrame = runInterfaceWithAkLimit(logger, spark, origRDD, getAllInterface, 100, "e640de2b47394b19862ee134d817bbc7", 3333)
          .map(o=>{
              val aklist: String = o.getString("aklist")
              val axle_number: String = o.getString("axle_number")
              val axle_weight: String = o.getString("axle_weight")
              val dest_citycode: String = o.getString("dest_citycode")
              val dest_deptcode: String = o.getString("dest_deptcode")
              val dest_province: String = o.getString("dest_province")
              val diff_time: String = o.getString("diff_time")
              val distance: String = o.getString("distance")
              val distance_new: String = o.getString("distance_new")
              val driver_id: String = o.getString("driver_id")
              val duration: String = o.getString("duration")
              val emit_stand: String = o.getString("emit_stand")
              val energy: String = o.getString("energy")
              val fencedist: String = o.getString("fencedist")
              val fixed_route: String = o.getString("fixed_route")
              val flen: String = o.getString("flen")
              val ft_right: String = o.getString("ft_right")
              val ft_url: String = o.getString("ft_url")
              val height: String = o.getString("height")
              val highspeed_distance: String = o.getString("highspeed_distance")
              val length: String = o.getString("length")
              val linknum: String = o.getString("linknum")
              val links: String = o.getString("links")
              val merge: String = o.getString("merge")
              val mload: String = o.getString("mload")
              val navi_count: String = o.getString("navi_count")
              val navi_distance: String = o.getString("navi_distance")
              val navi_endstatus: String = o.getString("navi_endstatus")
              val navi_endtime: String = o.getString("navi_endtime")
              val navi_endx: String = o.getString("navi_endx")
              val navi_endy: String = o.getString("navi_endy")
              val navi_id: String = o.getString("navi_id")
              val navi_order: String = o.getString("navi_order")
              val navi_starttime: String = o.getString("navi_starttime")
              val navi_time: String = o.getString("navi_time")
              val offtime_min1: String = o.getString("offtime_min1")
              val offtime_min10: String = o.getString("offtime_min10")
              val offtime_min15: String = o.getString("offtime_min15")
              val offtime_min3: String = o.getString("offtime_min3")
              val offtime_min5: String = o.getString("offtime_min5")
              val offtime_ratio: String = o.getString("offtime_ratio")
              val opt: String = o.getString("opt")
              val passport: String = o.getString("passport")
              val path_count: String = o.getString("path_count")
              val plan_date: String = o.getString("plan_date")
              val plate_color: String = o.getString("plate_color")
              val pns_status: String = o.getString("pns_status")
              val polyline: String = o.getString("polyline")
              val rc_distance: String = o.getString("rc_distance")
              val rdynsdcnt: String = o.getString("rdynsdcnt")
              val rdynsdlen: String = o.getString("rdynsdlen")
              val req_count: String = o.getString("req_count")
              val req_order: String = o.getString("req_order")
              val req_status: String = o.getString("req_status")
              val req_time: String = o.getString("req_time")
              val req_type: String = o.getString("req_type")
              val request_id: String = o.getString("request_id")
              val reroute: String = o.getString("reroute")
              val ret: String = o.getString("ret")
              val route_count: String = o.getString("route_count")
              val route_order: String = o.getString("route_order")
              val routeid: String = o.getString("routeid")
              val routeid_in: String = o.getString("routeid_in")
              val routeid_out: String = o.getString("routeid_out")
              val sim1: String = o.getString("sim1")
              val sim5: String = o.getString("sim5")
              val similarity1: String = o.getString("similarity1")
              val similarity5: String = o.getString("similarity5")
              val src: String = o.getString("src")
              val src_citycode: String = o.getString("src_citycode")
              val src_deptcode: String = o.getString("src_deptcode")
              val src_province: String = o.getString("src_province")
              val starts: String = o.getString("starts")
              val status: String = o.getString("status")
              val strategy: String = o.getString("strategy")
              val stype: String = o.getString("stype")
              val swid: String = o.getString("swid")
              val service_id: String = o.getString("service_id")
              val strategy2: String = o.getString("strategy2")
              val task_id: String = o.getString("task_id")
              val tl_diff_time: String = o.getString("tl_diff_time")
              val tl_ft_right: String = o.getString("tl_ft_right")
              val tl_navi_time: String = o.getString("tl_navi_time")
              val tl_times: String = o.getString("tl_times")
              val tlen: String = o.getString("tlen")
              val toll_distance: String = o.getString("toll_distance")
              val tolls: String = o.getString("tolls")
              val tracks1: String = o.getString("tracks1")
              val tracks1_new: String = o.getString("tracks1_new")
              val tracks2: String = o.getString("tracks2")
              val tracks2_new: String = o.getString("tracks2_new")
              val trafficlight_count: String = o.getString("trafficlight_count")
              val trackstart_distance : String = o.getString("trackstart_distance")
              val trackend_distance: String = o.getString("trackend_distance")
              val vehicle: String = o.getString("vehicle")
              val vehicle_type: String = o.getString("vehicle_type")
              val weight: String = o.getString("weight")
              val width: String = o.getString("width")
              val x1: String = o.getString("x1")
              val x2: String = o.getString("x2")
              val y1: String = o.getString("y1")
              val y2: String = o.getString("y2")
              val yawpoints: String = o.getString("yawpoints")
              val yawpoints_count: String = o.getString("yawpoints_count")
              val sim15_new: String = o.getString("sim15_new")
              val inc_day: String = o.getString("inc_day")
              TrackSimilarity2(aklist,axle_number,axle_weight,dest_citycode,dest_deptcode,dest_province,diff_time,distance,
                  distance_new,driver_id,duration,emit_stand,energy,fencedist,fixed_route,flen,ft_right,ft_url,height,
                  highspeed_distance,length,linknum,links,merge,mload,navi_count,navi_distance,navi_endstatus,navi_endtime,
                  navi_endx,navi_endy,navi_id,navi_order,navi_starttime,navi_time,offtime_min1,offtime_min10,offtime_min15,
                  offtime_min3,offtime_min5,offtime_ratio,opt,passport,path_count,plan_date,plate_color,pns_status,polyline,
                  rc_distance,rdynsdcnt,rdynsdlen,req_count,req_order,req_status,req_time,req_type,request_id,reroute,ret,
                  route_count,route_order,routeid,routeid_in,routeid_out,sim1,sim5,similarity1,similarity5,src,src_citycode,
                  src_deptcode,src_province,starts,status,strategy,stype,swid,service_id,strategy2,task_id,tl_diff_time,
                  tl_ft_right,tl_navi_time, tl_times,tlen,toll_distance,tolls,tracks1,tracks1_new,tracks2,tracks2_new,
                  trafficlight_count,trackstart_distance, trackend_distance,vehicle, vehicle_type,weight,width,x1,x2,y1,y2,
                  yawpoints,yawpoints_count,sim15_new,inc_day)
          })
          .toDF()
          .withColumn("sim15_new", when($"sim1" >= "0.8" or ($"sim5" >= "0.8"), "true").otherwise("false"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, origDF, "调轨迹相似度之后的数据")
        df2HiveByOverwrite(logger, origDF, "dm_gis.track_simi_detail")
    }

}
