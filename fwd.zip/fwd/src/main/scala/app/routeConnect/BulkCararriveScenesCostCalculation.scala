package app.routeConnect

import com.alibaba.fastjson.JSONObject
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window, WindowSpec}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.SparkConfigUtil

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}
import scala.util.matching.Regex

/**
  * 任务名称：【集货】执行成本价值计算
  * 任务ID：467312
  * 需求人员：矫悦 01404184
  * 开发人员：王冬冬 01413698
  */
object BulkCararriveScenesCostCalculation {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {

        // 接收外部传递进来的变量
        val yesterday: String = args(0)
        val now: String = args(1)
        logger.error(s"昨天的日期：$yesterday")
        logger.error(s"今天的日期：$now")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)


        var i: Int = 1
        val inc_dayBuff: Array[String] = Array("20220407")
        logger.error("所有的批次信息：" + inc_dayBuff.mkString(","))

        for (inc_day <- inc_dayBuff) {
            val start_time: String = getFirstDayofMonthBeforeOrAfter(inc_day, 0)
            val end_time: String = now

            logger.error(s"开始第${i}次循环：inc_day:$inc_day,start_time:$start_time,end_time:$end_time")

            // 获取 线路输出数据、计划日需数据、历史运力数据
            val (optRDD1, optRDD2, planDF, hisDF, optDF) = getOptPlanHisData(spark, start_time, end_time, yesterday, inc_day)
            // 广播 计划日需数据、历史运力数据
            val (planArrBC, hisArrBC) = broadcastPlanHis(spark, planDF, hisDF)
            // 取消线路处理逻辑
            val cancelDF: DataFrame = getCancelLine(spark, optRDD1, planArrBC, hisArrBC, inc_day, yesterday, now)
            // 保留线路逻辑处理
            val keepDF: DataFrame = getKeepLine(spark, optRDD2, planArrBC, hisArrBC, inc_day, yesterday, now)

            // 取消线路计算频次和距离
            val cancelDF3: DataFrame = getFreqAndSavaDistBy3(spark, cancelDF)
            val cancelDF4: DataFrame = getFreqAndSavaDistBy4(spark, cancelDF, hisDF)
            val cancelDF6: DataFrame = getFreqAndSavaDistBy6(spark, cancelDF)

            // 保留线路计算频次和距离
            val keepDF1: DataFrame = getFreqAndSavaDistBy1(spark, keepDF)
            val keepDF2: DataFrame = getFreqAndSavaDistBy2(spark, keepDF, hisDF)
            val keepDF5: DataFrame = getFreqAndSavaDistBy5(spark, keepDF)

            // 合并所有tag
            mergeAllTag(spark, cancelDF, cancelDF3, cancelDF4, cancelDF6, keepDF, keepDF1, keepDF2, keepDF5, optDF, inc_day)


            logger.error(s"第${i}次循环结束！")
            i = i + 1


            optDF.unpersist()
            planDF.unpersist()
            hisDF.unpersist()
            planArrBC.unpersist()
            hisArrBC.unpersist()
            optRDD1.unpersist()
            optRDD2.unpersist()

        }

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 获取inc_day
    def getIncday(spark: SparkSession): Array[String] = {
        val inc_dayBuff = new ArrayBuffer[String]()

        val sql: String =
            """
              |select
              |  inc_day
              |from
              |  dm_gis.pick_up_approved_data
              |group by
              |  inc_day
              |""".stripMargin
        spark.sql(sql).collect().foreach(r => inc_dayBuff.append(r.getAs[String]("inc_day")))
        inc_dayBuff.toArray.sortWith(_ > _)
    }

    // 获取 计划需求数据、历史运力数据、输出线路数据
    def getOptPlanHisData(spark: SparkSession, start_time: String, end_time: String, yesterday: String, inc_day: String): (RDD[JSONObject], RDD[JSONObject], DataFrame, DataFrame, DataFrame) = {
        val dlr: String = "$"
        val planSql: String =
            s"""
               |select
               |  line_code,
               |  planning_main_id,
               |  oper_type,
               |  has_pass,
               |  plan_run_dt,
               |  pass_codes,
               |  src_upper_dept_code,
               |  distribution_type,
               |  edit_reason,
               |  reverse(substring(reverse(line_code),5,20))  as line_code2
               |from
               |  dm_pass_rss.scha_tt_plan_main_pro
               |where
               |  inc_day = '$yesterday'
               |  and regexp_replace(cast(plan_run_dt as string), '-', '') >= '$start_time'
               |  and regexp_replace(cast(plan_run_dt as string), '-', '') <= '$end_time'
               |  and transport_level = 3
               |  and oper_type != 3
               |  and has_pass = 1
               |""".stripMargin
        val optSql: String =
            s"""
               |select
               |  *,
               |  reverse(substring(reverse(line_code_s2_e),5,20))  as line_code_s2_e2,
               |  reverse(substring(reverse(line_code_s1_e),5,20))  as line_code_s1_e2
               |from
               |  dm_gis.pick_up_approved_data
               |where
               |  inc_day='$inc_day'
               |""".stripMargin
        val historySql: String =
            s"""
               |select
               |  t1.line_code,
               |  t1.plan_depart_tm,
               |  t1.car_status,
               |  t1.new_line_code,
               |  t1.line_distance
               |from
               |(
               |	select
               |       line_code,
               |       plan_depart_tm,
               |       car_status,
               |       src_zone_code,
               |       dest_zone_code,
               |       reverse(substring(reverse(line_code),5,30))  as new_line_code,
               |       line_distance
               |	from
               |	  dm_ops.pass_forecast_road_convy_monitor_dtl
               |    where
               |      substr(src_zone_code, 1, 1) not in ('s', 'p', 'm')
               |      and substr(dest_zone_code, 1, 1) not in ('s', 'p', 'm')
               |      and regexp_replace(translate(lower(src_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |      and regexp_replace(translate(lower(dest_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |      and src_zone_code != ''
               |      and dest_zone_code != ''
               |      and transoport_level = '三级运输'
               |      and vehicle != '虚拟车'
               |      and src_zone_code != dest_zone_code
               |      and inc_day >= '$start_time'
               |      and inc_day <= '$end_time'
               |  ) t1
               |  join (
               |    select
               |      dept_code,
               |      dept_transfer_flag
               |    from
               |      dim.dim_department
               |  ) t2 on t1.src_zone_code = t2.dept_code
               |  join (
               |    select
               |      dept_code,
               |      dept_transfer_flag
               |    from
               |      dim.dim_department
               |  ) t3 on t1.dest_zone_code = t3.dept_code
               |where
               |  t2.dept_transfer_flag = '1'
               |  and t3.dept_transfer_flag = '0'
               |""".stripMargin

        // 输出线路数据
        val optDF: DataFrame = getDataFrame(logger, spark, optSql, "输出线路数据")
        // 计划需求数据
        val planDF: DataFrame = getDataFrame(logger, spark, planSql, "计划需求数据")
        // 历史运力数据
        val hisDF: DataFrame = getDataFrame(logger, spark, historySql, "历史运力数据")

        val planDF1: DataFrame = planDF
          .groupBy("line_code")
          .agg(
              concat_ws(",", collect_set("planning_main_id")).as("planning_main_id_list")
          )

        val planDF2: DataFrame = planDF
          .groupBy("line_code2")
          .agg(
              concat_ws(",", collect_set("planning_main_id")).as("planning_main_id_list2")
          )

        val optRDD1: RDD[JSONObject] = optDF
          .join(planDF1, planDF1("line_code") === optDF("line_code_s2_e"), "left")
          .join(planDF2, planDF2("line_code2") === optDF("line_code_s2_e2"), "left")
          .rdd
          .repartition(100)
          .map(row2Json)
          .cache()

        val optRDD2: RDD[JSONObject] = optDF
          .join(planDF1, planDF1("line_code") === optDF("line_code_s1_e"), "left")
          .join(planDF2, planDF2("line_code2") === optDF("line_code_s1_e2"), "left")
          .rdd
          .repartition(100)
          .map(row2Json)
          .cache()

        logger.error("取消线路optRDD1 数据量:" + optRDD1.count())
        logger.error("保留线路optRDD2 数据量:" + optRDD2.count())

        (optRDD1, optRDD2, planDF, hisDF, optDF)
    }

    // 广播 历史运力数据、计划日需数据
    def broadcastPlanHis(spark: SparkSession, planDF: DataFrame, hisDF: DataFrame): (Broadcast[Array[Row]], Broadcast[Array[Row]]) = {
        logger.error("开始拉取【计划需求数据】到driver！")
        val planArrtmp: Array[Row] = planDF.collect()
        logger.error("数据拉取完毕，开始广播数据到workNode！")
        val planArrBC: Broadcast[Array[Row]] = spark.sparkContext.broadcast(planArrtmp)
        logger.error("【计划需求数据】广播完毕！")

        logger.error("开始拉取【历史运力数据】到driver！")
        val hisArrtmp: Array[Row] = hisDF.collect()
        logger.error("数据拉取完毕，开始广播数据到workNode！")
        val hisArrBC: Broadcast[Array[Row]] = spark.sparkContext.broadcast(hisArrtmp)
        logger.error("【历史运力数据】广播完毕！")
        (planArrBC, hisArrBC)
    }

    // 取消线路最终数据
    def getCancelLine(spark: SparkSession, optRDD1: RDD[JSONObject], planArrBC: Broadcast[Array[Row]], hisArrBC: Broadcast[Array[Row]], inc_day: String, yesterday: String, now: String): DataFrame = {
        import spark.implicits._

        val cancelDF: DataFrame = optRDD1
          .map(o => {
              val planArr: Array[JSONObject] = planArrBC.value.map(row2Json)

              val line_code: String = o.getString("line_code_s2_e")
              val planning_main_id_list: String = o.getString("planning_main_id_list")

              var pointFlag: Int = 0 //pointFlag = 0 表示不存在串点

              if (!isEmptyOrNull(planning_main_id_list)) {
                  val ids: Array[Long] = planning_main_id_list.split(",").map(_.toLong)
                  logger.error(s"line_code:$line_code,ids:$planning_main_id_list")
                  // 判断 某条线路是否有串点 pointFlag = 0 表示不存在串点
                  pointFlag = dealSerialPoint(o, logger, ids, planArr, inc_day)
                  logger.error("*******************************************************************")
              }

              if (pointFlag == 0) {
                  logger.error(s"line_code:$line_code,所有的 id 都不存在串点,进入【同向线路】是否有串点环节！")
                  val planning_main_id_list2: String = o.getString("planning_main_id_list2")

                  var pointFlag2: Int = 0 //pointFlag = 0 表示不存在串点
                  if (!isEmptyOrNull(planning_main_id_list2)) {
                      val ids2: Array[Long] = planning_main_id_list2.split(",").map(_.toLong)
                      logger.error(s"line_code:$line_code,ids2:$planning_main_id_list2")

                      pointFlag2 = dealSerialPoint(o, logger, ids2, planArr, inc_day)
                      logger.error("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
                  }


                  if (pointFlag2 == 0) {
                      logger.error(s"line_code:$line_code,所有的 id 都不存在【同向线路】串点,进入【班次是否停用】环节！")

                      val hisArr: Array[JSONObject] = hisArrBC.value.map(row2Json)
                      val flag3: Int = bacthDisabl(hisArr, o, line_code, yesterday)

                      if (flag3 == 1) {
                          logger.error(s"line_code:$line_code,【建议取消班次】已经停用,进入【是否被其他线路经停】环节！")

                          val src_zone_code_s2_e: String = o.getString("src_zone_code_s2_e")
                          val planArr2: Array[JSONObject] = planArr.filter(o => {
                              val pass_codes: String = o.getString("pass_codes")
                              val oper_type: String = o.getString("oper_type")
                              if (!isEmptyOrNull(pass_codes) && pass_codes.split(",").contains(src_zone_code_s2_e) && oper_type != "3") true else false
                          })

                          val ids: Array[String] = planArr2.map(_.getString("planning_main_id")).distinct

                          if (ids.nonEmpty) {
                              val (line_code_keep, start_tm, end_tm) = bacthDisabl(planArr2, o, ids)
                              o.put("line_code_2_keep", line_code_keep)
                              o.put("start_tm2", start_tm)
                              o.put("end_tm2", end_tm)

                              if (!isEmptyOrNull(line_code_keep)) o.put("tag2", 6)

                          } else {
                              val b: Boolean = isMove(planArr, line_code)
                              if (b) o.put("tag2", 7) else o.put("tag2", 10)
                          }


                      } else {
                          val update_time: String = o.getString("update_time")
                          val arr: Array[String] = update_time.split("/")
                          for (i <- arr.indices) if (arr(i).length == 1) arr(i) = "0" + arr(i)
                          val update_time2: String = arr.mkString

                          if (now < update_time2) o.put("tag2", "8") else o.put("tag2", "9")
                      }
                  }

              }

              logger.error("===================================================================\n")

              val dest_zone_code: String = o.getString("dest_zone_code")
              val line_distance_s1_e: String = o.getString("line_distance_s1_e")
              val line_distance_s2_e: String = o.getString("line_distance_s2_e")
              val tag2: String = o.getString("tag2")
              val line_code_2_stop: String = o.getString("line_code_2_stop")
              val start_stop_tm_2: String = o.getString("start_stop_tm_2")
              val end_stop_tm_2: String = o.getString("end_stop_tm_2")
              val last_done_time: String = o.getString("last_done_time")
              val line_code_2_keep: String = o.getString("line_code_2_keep")
              val start_tm2: String = o.getString("start_tm2")
              val end_tm2: String = o.getString("end_tm2")

              (line_code, dest_zone_code, line_distance_s1_e, line_distance_s2_e, tag2, line_code_2_stop, start_stop_tm_2, end_stop_tm_2, last_done_time, line_code_2_keep, start_tm2, end_tm2)
          })
          .toDF("line_code1", "dest_zone_code", "line_distance_s1_e", "line_distance_s2_e", "tag2", "line_code_2_stop", "start_stop_tm_2",
              "end_stop_tm_2", "last_done_time1", "line_code_2_keep", "start_tm2", "end_tm2")
          .cache()

        GetDFCountAndSampleData(logger, cancelDF, "取消线路最终数据")

        cancelDF.show(false)

        cancelDF
    }

    // 判断是否有串点(0:表示 没有串点   1:表示有串点)
    def isSerialPoint(planArr: Array[JSONObject], id: Long, inc_day: String): (Int, JSONObject, JSONObject) = {
        val planArr2: Array[JSONObject] = planArr.filter(_.getLongValue("planning_main_id") == id)

        // flag:0 表示 没有串点   1 表示有串点
        var flag: Int = 0
        var head: JSONObject = null
        var last: JSONObject = null
        if (planArr2.nonEmpty) {
            val planArr3: Array[JSONObject] = planArr2
              .sortBy(_.getString("plan_run_dt"))

            val headObj: JSONObject = planArr3.head
            val lastObj: JSONObject = planArr3.last

            val plan_run_dt: String = headObj.getString("plan_run_dt").replaceAll("-", "")
            if (plan_run_dt >= inc_day) {
                flag = 1
                head = headObj
                last = lastObj
            }
        }

        (flag, head, last)
    }

    // 是否搬迁
    def isMove(planArr: Array[JSONObject], line_code: String): Boolean = {

        val b: Boolean = planArr
          .filter(_.getString("line_code") == line_code)
          .map(o => {
              val p1: Regex = new Regex("搬迁")
              val p2: Regex = new Regex("变迁")
              val edit_reason: String = o.getString("edit_reason")

              val s1: String = p1.findFirstIn(edit_reason).getOrElse("1")
              val s2: String = p2.findFirstIn(edit_reason).getOrElse("2")

              if (s1 == "1" && s2 == "2") 10 else 20
          })
          .contains(20)

        b
    }

    // 建议取消班次是否被停用
    def bacthDisabl(planArr2: Array[JSONObject], o: JSONObject, ids: Array[String]): (String, String, String) = {

        val line_code_set = new mutable.HashSet[String]()
        val start_tm_set = new mutable.HashSet[String]()
        val end_tm_set = new mutable.HashSet[String]()

        try {
            for (id <- ids) {
                val lineMin: JSONObject = planArr2
                  .filter(_.getString("planning_main_id") == id)
                  .minBy(_.getString("plan_run_dt"))

                val lineMax: JSONObject = planArr2
                  .filter(_.getString("planning_main_id") == id)
                  .maxBy(_.getString("plan_run_dt"))

                val last_done_time: String = o.getString("last_done_time")
                val dest_zone_code: String = o.getString("dest_zone_code")

                val line_code: String = lineMin.getString("line_code")
                val plan_run_dt_min: String = lineMin.getString("plan_run_dt")
                val distribution_type: String = lineMin.getString("distribution_type")
                val dest_upper_dept_code: String = lineMin.getString("dest_upper_dept_code")
                var plan_run_dt_max: String = lineMax.getString("plan_run_dt")
                plan_run_dt_max = if (plan_run_dt_max >= getNowTime3) getNowTime3 else plan_run_dt_max

                if (plan_run_dt_min >= last_done_time && distribution_type == "1" && dest_upper_dept_code == dest_zone_code) {
                    line_code_set.add(line_code)
                    start_tm_set.add(plan_run_dt_min)
                    end_tm_set.add(plan_run_dt_max)
                }
            }
        } catch {
            case e: Exception => println(e.getMessage)
        }

        (line_code_set.mkString(","), start_tm_set.mkString(","), end_tm_set.mkString(","))
    }

    // 建议取消班次是否被停用
    def bacthDisabl(hisArr: Array[JSONObject], o: JSONObject, line_code: String, yesterday: String): Int = {

        var flag3: Int = 0 // 0:未停用  1：停用

        val hisArr2: Array[JSONObject] = hisArr
          .filter(_.getString("line_code") == line_code)

        if (hisArr2.nonEmpty) {
            val hisObj: JSONObject = hisArr2.maxBy(_.getString("plan_depart_tm"))

            val car_status: String = hisObj.getString("car_status")
            val plan_depart_tm: String = hisObj.getString("plan_depart_tm")

            val plan_depart_tm2: String = plan_depart_tm.split(" ")(0).replaceAll("-", "")
            if (car_status == "取消" || (car_status == "已完成" && plan_depart_tm2 < yesterday)) {
                o.put("last_done_time", plan_depart_tm)
                flag3 = 1
            }
        } else flag3 = 1


        flag3
    }

    // 串点的网点是否包含 src_zone_code_s1_e
    def iscontainsDestCode(o: JSONObject, pass_codes: String, logger: Logger, id: Long, line_code: String): Unit = {
        if (!isEmptyOrNull(pass_codes)) {
            val codeArr: Array[String] = pass_codes.split(",")
            val src_zone_code_s1_e: String = o.getString("src_zone_code_s1_e")

            // 串点的网点是否包含 src_zone_code_s1_e
            if (codeArr.contains(src_zone_code_s1_e)) {
                o.put("tag2", 3)
                logger.error(s"line_code:$line_code,id:$id 满足【串点的网点包含】条件:tag2 = 3 中断本轮循环！")
                break()
            } else {
                o.put("tag2", 4)
                logger.error(s"line_code:$line_code,id:$id 不满足【串点的网点包含】条件:tag2 = 4,进入下个 id 进行循环！")
            }
        }
    }

    // 串点的处理逻辑
    def dealSerialPoint(o: JSONObject, logger: Logger, ids2: Array[Long], planArr: Array[JSONObject], inc_day: String): Int = {
        //(0:表示 没有串点   1:表示有串点)
        var pointFlag2: Int = 0

        val line_code: String = o.getString("line_code_s2_e")
        breakable(
            for (k <- ids2.indices) {
                val id: Long = ids2(k)
                logger.error(s"line_code:$line_code,第${k + 1}次循环,id:$id")
                val (i, head, last) = isSerialPoint(planArr, id, inc_day)

                // 某条线路存在串点的情况
                if (i == 1) {
                    pointFlag2 = 1
                    val pass_codes: String = head.getString("pass_codes")
                    o.put("line_code_2_stop", pass_codes)
                    o.put("line_code_2_keep", head.getString("line_code"))
                    val plan_run_dt: String = head.getString("plan_run_dt")
                    o.put("start_stop_tm_2", plan_run_dt)

                    if (plan_run_dt <= getNowTime3) o.put("end_stop_tm_2", getNowTime3) else o.put("end_stop_tm_2", last.getString("plan_run_dt"))

                    // 判断串点的网点是否包含 src_zone_code_s1_e
                    iscontainsDestCode(o, pass_codes, logger, id, line_code)

                } // 不存在串点的情况
                else logger.error(s"line_code:$line_code,id:$id 不满足【是否串点】条件,进入下个id进行循环！")
            }
        )

        pointFlag2
    }

    // 串点的网点是否包含 src_zone_code_s2_e
    def iscontainsDestCode2(o: JSONObject, pass_codes: String, logger: Logger, id: Long, line_code: String): Unit = {
        if (!isEmptyOrNull(pass_codes)) {
            val codeArr: Array[String] = pass_codes.split(",")
            val src_zone_code_s2_e: String = o.getString("src_zone_code_s2_e")

            // 串点的网点是否包含 src_zone_code_s2_e
            if (codeArr.contains(src_zone_code_s2_e)) {
                o.put("tag1", 1)
                logger.error(s"line_code:$line_code,id:$id 满足【串点的网点包含】条件:tag1 = 1 中断本轮循环！")
                break()
            } else {
                o.put("tag1", 2)
                logger.error(s"line_code:$line_code,id:$id 不满足【串点的网点包含】条件:tag1 = 2,进入下个 id 进行循环！")
            }
        }
    }

    // 串点的处理逻辑
    def dealSerialPoint2(o: JSONObject, logger: Logger, ids2: Array[Long], planArr: Array[JSONObject], inc_day: String): Int = {
        //(0:表示 没有串点   1:表示有串点)
        var pointFlag2: Int = 0

        val line_code: String = o.getString("line_code_s1_e")
        breakable(
            for (k <- ids2.indices) {
                val id: Long = ids2(k)
                logger.error(s"line_code:$line_code,第${k + 1}次循环,id:$id")
                val (i, head, last) = isSerialPoint(planArr, id, inc_day)

                // 某条线路存在串点的情况
                if (i == 1) {
                    pointFlag2 = 1
                    val pass_codes: String = head.getString("pass_codes")
                    o.put("line_code_1_stop", pass_codes)
                    o.put("line_code_1_keep", head.getString("line_code"))
                    val plan_run_dt: String = head.getString("plan_run_dt")
                    o.put("start_stop_tm_1", plan_run_dt)

                    if (plan_run_dt <= getNowTime3) o.put("end_stop_tm_1", getNowTime3) else o.put("end_stop_tm_1", last.getString("plan_run_dt"))

                    // 判断串点的网点是否包含 src_zone_code_s2_e
                    iscontainsDestCode2(o, pass_codes, logger, id, line_code)

                } // 不存在串点的情况
                else logger.error(s"line_code:$line_code,id:$id 不满足【是否串点】条件,进入下个id进行循环！")
            }
        )

        pointFlag2
    }

    // 保留线路最终数据
    def getKeepLine(spark: SparkSession, optRDD2: RDD[JSONObject], planArrBC: Broadcast[Array[Row]], hisArrBC: Broadcast[Array[Row]], inc_day: String, yesterday: String, now: String): DataFrame = {
        import spark.implicits._

        val keepDF: DataFrame = optRDD2
          .map(o => {
              val planArr: Array[JSONObject] = planArrBC.value.map(row2Json)

              val line_code: String = o.getString("line_code_s1_e")
              val planning_main_id_list: String = o.getString("planning_main_id_list")

              var pointFlag: Int = 0 //pointFlag = 0 表示不存在串点

              if (!isEmptyOrNull(planning_main_id_list)) {
                  val ids: Array[Long] = planning_main_id_list.split(",").map(_.toLong)
                  logger.error(s"line_code:$line_code,ids:$planning_main_id_list")

                  // 判断 某条线路是否有串点 pointFlag = 0 表示不存在串点
                  pointFlag = dealSerialPoint2(o, logger, ids, planArr, inc_day)
                  logger.error("*******************************************************************")
              }

              if (pointFlag == 0) {
                  logger.error(s"line_code:$line_code,所有的 id 都不存在串点,进入【同向线路】是否有串点环节！")
                  val planning_main_id_list2: String = o.getString("planning_main_id_list2")

                  var pointFlag2: Int = 0 //pointFlag = 0 表示不存在串点
                  if (!isEmptyOrNull(planning_main_id_list2)) {
                      val ids2: Array[Long] = planning_main_id_list2.split(",").map(_.toLong)
                      logger.error(s"line_code:$line_code,ids2:$planning_main_id_list2")

                      pointFlag2 = dealSerialPoint2(o, logger, ids2, planArr, inc_day)
                      logger.error("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
                  }


                  if (pointFlag2 == 0) {
                      logger.error(s"line_code:$line_code,所有的 id 都不存在【同向线路】串点,进入【班次是否停用】环节！")

                      val hisArr: Array[JSONObject] = hisArrBC.value.map(row2Json)
                      val flag3: Int = bacthDisabl(hisArr, o, line_code, yesterday)

                      if (flag3 == 1) {
                          logger.error(s"line_code:$line_code,【建议取消班次】已经停用,进入【是否被其他线路经停】环节！")

                          val src_zone_code_s1_e: String = o.getString("src_zone_code_s1_e")
                          val planArr2: Array[JSONObject] = planArr.filter(o => {
                              val pass_codes: String = o.getString("pass_codes")
                              val oper_type: String = o.getString("oper_type")
                              if (!isEmptyOrNull(pass_codes) && pass_codes.split(",").contains(src_zone_code_s1_e) && oper_type != "3") true else false
                          })

                          val ids: Array[String] = planArr2.map(_.getString("planning_main_id")).distinct

                          if (ids.nonEmpty) {
                              val (line_code_keep, start_tm, end_tm) = bacthDisabl(planArr2, o, ids)
                              o.put("line_code_1_keep", line_code_keep)
                              o.put("start_tm1", start_tm)
                              o.put("end_tm1", end_tm)

                              if (!isEmptyOrNull(line_code_keep)) o.put("tag1", 5)

                          } else {
                              val b: Boolean = isMove(planArr, line_code)
                              if (b) o.put("tag1", 7) else o.put("tag1", 10)
                          }


                      } else {
                          val update_time: String = o.getString("update_time")
                          val arr: Array[String] = update_time.split("/")
                          for (i <- arr.indices) if (arr(i).length == 1) arr(i) = "0" + arr(i)
                          val update_time2: String = arr.mkString

                          if (now < update_time2) o.put("tag1", "8") else o.put("tag1", "9")
                      }

                  }
              }

              logger.error("===================================================================\n")

              val dest_zone_code: String = o.getString("dest_zone_code")
              val line_distance_s1_e: String = o.getString("line_distance_s1_e")
              val line_distance_s2_e: String = o.getString("line_distance_s2_e")
              val tag1: String = o.getString("tag1")
              val line_code_1_stop: String = o.getString("line_code_1_stop")
              val start_stop_tm_1: String = o.getString("start_stop_tm_1")
              val end_stop_tm_1: String = o.getString("end_stop_tm_1")
              val last_done_time: String = o.getString("last_done_time")
              val line_code_1_keep: String = o.getString("line_code_1_keep")
              val start_tm1: String = o.getString("start_tm1")
              val end_tm1: String = o.getString("end_tm1")

              (line_code, dest_zone_code, line_distance_s1_e, line_distance_s2_e, tag1, line_code_1_stop, start_stop_tm_1, end_stop_tm_1, last_done_time, line_code_1_keep, start_tm1, end_tm1)
          })
          .toDF("line_code2", "dest_zone_code", "line_distance_s1_e", "line_distance_s2_e", "tag1", "line_code_1_stop", "start_stop_tm_1",
              "end_stop_tm_1", "last_done_time2", "line_code_1_keep", "start_tm1", "end_tm1")
          .cache()

        GetDFCountAndSampleData(logger, keepDF, "保留线路最终数据")
        keepDF.show(false)

        keepDF
    }

    // 出去以Y结尾 或者 全是数字 的经停点
    def getLineCodeStop: UserDefinedFunction = udf((line_code_n_stop: String) => {
        val arr = new ArrayBuffer[String]()

        val linesArr: Array[String] = line_code_n_stop.split(",")
        for (line <- linesArr) {
            val r: Regex = "[a-zA-Z]".r
            if (line.endsWith("Y") || r.findFirstIn(line).getOrElse("") == "") {} else arr.append(line)
        }
        arr.toArray
    })

    // 计算start_tm 与 end_tm 相隔的累积天数
    def getStart2EndDays: UserDefinedFunction = udf((start_tm: String, end_tm: String) => {
        val arr = new ArrayBuffer[Long]()

        val startArr: Array[String] = start_tm.split(",")
        val endArr: Array[String] = end_tm.split(",")
        for (i <- startArr.indices) {
            val d: Long = getTimeDiffDay(endArr(i), startArr(i)) + 1
            arr.append(d)
        }
        arr.sum
    })

    // tag1 = 1 的线路
    def getFreqAndSavaDistBy1(spark: SparkSession, keepDF: DataFrame): DataFrame = {
        import spark.implicits._

        val keepDF2: DataFrame = keepDF
          .filter("tag1 = '1'")
          .withColumn("execution_frequency1", getTimeDiffDay($"end_stop_tm_1", $"start_stop_tm_1") + 1)
          .withColumn("sum_save_distance1", $"line_distance_s2_e".cast("double") * $"execution_frequency1")
          .cache()

        GetDFCountAndSampleData(logger, keepDF2, "tag1=1的数据")
        keepDF2.show(false)

        keepDF2
    }

    // tag1 = 2 的线路
    def getFreqAndSavaDistBy2(spark: SparkSession, keepDF: DataFrame, hisDF: DataFrame): DataFrame = {
        import spark.implicits._

        val w: WindowSpec = Window.partitionBy($"new_line_code").orderBy($"plan_depart_tm".desc)
        val hisDF2: Dataset[Row] = hisDF
          .select("new_line_code", "plan_depart_tm", "line_distance")
          .withColumn("rn", row_number().over(w))
          .filter("rn = 1")

        val keepDF1: Dataset[Row] = keepDF.filter("tag1 = '2'")

        val keepDF2: DataFrame = keepDF1
          .withColumn("new_stop", explode(getLineCodeStop($"line_code_1_stop")))
          .withColumn("new_line_code", concat($"new_stop", $"dest_zone_code"))

        val keepDF22: DataFrame = keepDF2
          .join(hisDF2, Seq("new_line_code"), "left")
          .na.fill("0", Array("line_distance"))
          .groupBy("line_code2")
          .agg(
              sum($"line_distance".cast("double")).as("line_distance2")
          )

        val keepDF3: DataFrame = keepDF1
          .join(keepDF22, Seq("line_code2"), "left")
          .withColumn("execution_frequency1", getTimeDiffDay($"end_stop_tm_1", $"start_stop_tm_1") + 1)
          .withColumn("sum_save_distance1", $"line_distance2" * $"execution_frequency1")
          .drop("line_distance2")
          .cache()

        GetDFCountAndSampleData(logger, keepDF3, "tag1=2的数据")
        keepDF3.show(false)

        keepDF3
    }

    // tag1 = 5 的线路
    def getFreqAndSavaDistBy5(spark: SparkSession, keepDF: DataFrame): DataFrame = {
        import spark.implicits._

        val keepDF2: DataFrame = keepDF
          .filter("tag1 = '5'")
          .withColumn("execution_frequency1", getStart2EndDays($"start_tm1", $"end_tm1"))
          .withColumn("sum_save_distance1", $"line_distance_s1_e".cast("double") * $"execution_frequency1")
          .cache()

        GetDFCountAndSampleData(logger, keepDF2, "tag1=5的数据")
        keepDF2.show(false)

        keepDF2
    }

    // tag2 = 3的线路
    def getFreqAndSavaDistBy3(spark: SparkSession, cancelDF: DataFrame): DataFrame = {
        import spark.implicits._

        val cancelDF2: DataFrame = cancelDF
          .filter("tag2 = '3'")
          .withColumn("execution_frequency2", getTimeDiffDay($"end_stop_tm_2", $"start_stop_tm_2") + 1)
          .withColumn("sum_save_distance2", $"line_distance_s1_e".cast("double") * $"execution_frequency2")
          .cache()

        GetDFCountAndSampleData(logger, cancelDF2, "tag2=3的数据")
        cancelDF2.show(false)

        cancelDF2
    }

    // tag2 = 4 的线路
    def getFreqAndSavaDistBy4(spark: SparkSession, cancelDF: DataFrame, hisDF: DataFrame): DataFrame = {
        import spark.implicits._

        val w: WindowSpec = Window.partitionBy($"new_line_code").orderBy($"plan_depart_tm".desc)
        val hisDF2: Dataset[Row] = hisDF
          .select("new_line_code", "plan_depart_tm", "line_distance")
          .withColumn("rn", row_number().over(w))
          .filter("rn = 1")

        val cancelDF1: Dataset[Row] = cancelDF.filter("tag2 = '4'")

        val cancelDF2: DataFrame = cancelDF1
          .withColumn("new_stop", explode(getLineCodeStop($"line_code_2_stop")))
          .withColumn("new_line_code", concat($"new_stop", $"dest_zone_code"))

        val cancelDF22: DataFrame = cancelDF2
          .join(hisDF2, Seq("new_line_code"), "left")
          .na.fill("0", Array("line_distance"))
          .groupBy("line_code1")
          .agg(
              sum($"line_distance".cast("double")).as("line_distance2")
          )

        val cancelDF3: DataFrame = cancelDF1
          .join(cancelDF22, Seq("line_code1"), "left")
          .withColumn("execution_frequency2", getTimeDiffDay($"end_stop_tm_2", $"start_stop_tm_2") + 1)
          .withColumn("sum_save_distance2", $"line_distance2" * $"execution_frequency2")
          .drop("line_distance2")
          .cache()

        GetDFCountAndSampleData(logger, cancelDF3, "tag2=4的数据")
        cancelDF3.show(false)

        cancelDF3
    }

    // tag2 = 6 的线路
    def getFreqAndSavaDistBy6(spark: SparkSession, cancelDF: DataFrame): DataFrame = {
        import spark.implicits._

        val cancelDF2: DataFrame = cancelDF
          .filter("tag2 = '6'")
          .withColumn("execution_frequency2", getStart2EndDays($"start_tm2", $"end_tm2"))
          .withColumn("sum_save_distance2", $"line_distance_s2_e".cast("double") * $"execution_frequency2")
          .cache()

        GetDFCountAndSampleData(logger, cancelDF2, "tag2=6的数据")
        cancelDF2.show(false)

        cancelDF2
    }

    // 合并所有的tag
    def mergeAllTag(spark: SparkSession, cancelDF: DataFrame, cancelDF3: DataFrame, cancelDF4: DataFrame, cancelDF6: DataFrame,
                    keepDF: DataFrame, keepDF1: DataFrame, keepDF2: DataFrame, keepDF5: DataFrame, optDF: DataFrame, inc_day: String): Unit = {
        import spark.implicits._

        val cancelDF1: Dataset[Row] = cancelDF
          .filter("tag2 not in('3','4','6')")
          .withColumn("execution_frequency2", lit(0))
          .withColumn("sum_save_distance2", lit(0.0))

        val cancelAllDF: Dataset[Row] = cancelDF3.union(cancelDF4).union(cancelDF6).union(cancelDF1)
          .drop("dest_zone_code", "line_distance_s1_e", "line_distance_s2_e")

        val keepDF0: Dataset[Row] = keepDF
          .filter("tag1 not in('1','2','5')")
          .withColumn("execution_frequency1", lit(0))
          .withColumn("sum_save_distance1", lit(0.0))

        val keepAllDF: Dataset[Row] = keepDF1.union(keepDF2).union(keepDF5).union(keepDF0)
          .drop("dest_zone_code", "line_distance_s1_e", "line_distance_s2_e")

        val optResultDF: DataFrame = optDF
          .join(cancelAllDF, optDF("line_code_s2_e") === cancelAllDF("line_code1"), "left")
          .join(keepAllDF, optDF("line_code_s1_e") === keepAllDF("line_code2"), "left")
          .na.fill(0,Array("execution_frequency1","execution_frequency2"))
          .na.fill(0.0,Array("sum_save_distance1","sum_save_distance2"))
          .withColumn("execution_frequency", $"execution_frequency1" + $"execution_frequency2")
          .withColumn("sum_save_distance", $"sum_save_distance1" + $"sum_save_distance2")
          .withColumn("tag",
              when($"tag1" === "1" or $"tag2" === "3", "done")
                .when($"tag1".isin("2", "5") or $"tag2".isin("4", "6"), "partially_done")
                .when($"tag1" === "7" or $"tag2" === "7", "dept_remove")
                .when($"tag1" === "8" or $"tag2" === "8", "not_time")
                .when($"tag1".isin("9", "10") or $"tag2".isin("9", "10"), "not_done")
                .otherwise("unconfirmed")
          )
          .drop("line_code_s1_e2", "line_code_s2_e2", "line_code1", "line_code2", "inc_day")
          .withColumn("inc_day", lit(inc_day))
          .coalesce(1)
          .cache()

        GetDFCountAndSampleData(logger, optResultDF, "最终的结果数据")
        optResultDF.show(100,truncate = false)
        df2HiveByOverwrite(logger, optResultDF, "dm_gis.pick_up_approved_data_worth")
        optResultDF.unpersist()
    }


}
