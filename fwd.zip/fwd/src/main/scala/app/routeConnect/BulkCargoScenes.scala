package app.routeConnect

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.typesafe.config.{Config, ConfigFactory}
import entry.StopScenes2
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.HttpClientUtil.getJsonByGet
import utils.SparkConfigUtil

import java.{lang, util}
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
  * 任务名称：【散货】经停融通散货场景
  * 任务ID：440060
  * 需求人员：矫悦 01404184
  * 开发人员：王冬冬 01413698
  */
object BulkCargoScenes {
    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)
    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    val ct_url: String = config.getString("ct_url")

    def main(args: Array[String]): Unit = {

        if (args.length != 10) {
            logger.error(
                """
                  |需要输入10个参数：
                  |    start_time、end_time、three_moth_start、three_moth_end、six_moth_start、last_year_start、last_year_end、yesterday
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val three_moth_start: String = args(2)
        val three_moth_end: String = args(3)
        val six_moth_start: String = args(4)
        val last_year_start: String = args(5)
        val last_year_end: String = args(6)
        val next_month_start: String = args(7)
        val next_month_end: String = args(8)
        val yesterday: String = args(9)
        val inc_day: String = getNowTime
        logger.error(s"开始日期：$start_time 结束日期：$end_time")
        logger.error(s"历史3个月的日期：$three_moth_start 至 $three_moth_end")
        logger.error(s"历史6个月的日期：$six_moth_start 至 $three_moth_end")
        logger.error(s"去年同期的日期：$last_year_start 至 $last_year_end")
        logger.error(s"下个月的日期：$next_month_start 至 $next_month_end")
        logger.error(s"昨天的日期：$yesterday")
        logger.error(s"inc_day:$inc_day")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        // 原始数据
        val origDF: Dataset[Row] = getBranchLineData(spark, start_time, end_time, three_moth_start, three_moth_end, six_moth_start, last_year_start, last_year_end, inc_day)
        //        val origDF: Dataset[Row] = spark.sql("select * from  dm_gis.deliver_line_data").cache()
        val optDF: Dataset[Row] = getOptimizationData(spark, origDF, inc_day)
        //        val optDF: Dataset[Row] = spark.sql("select * from dm_gis.join_ct_time_data where d_dist is not null").cache()
        // 合并派仓、收仓、日需、航管数据
        val bacthDF: Dataset[Row] = mergeAllData(spark, start_time, end_time)
        val bacthDF2: Dataset[Row] = mergeAllData2(spark, start_time, end_time)
        //        val bacthDF: Dataset[Row] = spark.sql("select * from  dm_gis.batch_concat_data").cache()
        // 获取满足最大延迟时间的线路数据
        val lineDelayDF: Dataset[Row] = getLineDelayTime(spark, optDF, bacthDF, bacthDF2)
        // 短线满足条件的线路
        val shortDF: Dataset[Row] = getShortOptLine(spark, lineDelayDF)
        // 长线不压缩的线路
        val longDF: Dataset[Row] = getLongOptLine(spark, lineDelayDF)
        // 长线压缩的线路
        val longDF2: Dataset[Row] = getLongOptLine2(spark, lineDelayDF, origDF)

        //        val shortDF: Dataset[Row] = spark.sql("select * from dm_gis.short_time_ok_data")
        //        val longDF: Dataset[Row] = spark.sql("select * from dm_gis.long_not_compress_time_ok_data")
        //        val longDF2: Dataset[Row] = spark.sql("select * from dm_gis.long_compress_time_ok_data")
        // 更换车型
        val (changeTypeDF, noChangeTypeDF) = getChangeTypeLine(spark, shortDF, longDF, longDF2)
        // 最终满足条件的线路数据(未去重)
        getresultLine1(spark, changeTypeDF)
        getresultLine1(spark, noChangeTypeDF, 2)
        val resultDF1: Dataset[Row] = spark.sql("select * from dm_gis.stop_line_deliver_optimize_data")
        val resultDF11: Dataset[Row] = spark.sql("select * from dm_gis.stop_line_deliver_optimize_nochange_data")
        // 最终满足条件的线路数据(去重之后的数据)
        val resultDF2: Dataset[Row] = getDuplicatesResultLine2(spark, resultDF1)
        val resultDF22: Dataset[Row] = getDuplicatesResultLine2(spark, resultDF11, 2)
        // 下个月仍在运行的线路数据
        val nextDF: Dataset[Row] = getNextMonthLineStatus(spark, yesterday, next_month_start, next_month_end)
        // 最终满足条件的线路数据(下个月仍在运行的线路数据)
        getresultLine3(spark, resultDF2, nextDF, inc_day)
        getresultLine3(spark, resultDF22, nextDF, inc_day, 2)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()
    }

    // 获取历史装载率
    def getHistoryLoadRate(spark: SparkSession, start_time: String, end_time: String, name: String): Dataset[Row] = {
        import spark.implicits._

        val dlr: String = "$"
        val origSql: String =
            s"""
               |select
               |  line_code,
               |  load_rate
               |from
               |  (
               |    select
               |      *
               |    from
               |      dm_ops.pass_forecast_road_convy_monitor_dtl
               |    where
               |      car_status = '已完成'
               |      and substr(src_zone_code, 1, 1) not in ('s', 'p', 'm')
               |      and substr(dest_zone_code, 1, 1) not in ('s', 'p', 'm')
               |      and regexp_replace(translate(lower(src_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |      and regexp_replace(translate(lower(dest_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |      and src_zone_code != ''
               |      and dest_zone_code != ''
               |      and transoport_level = '三级运输'
               |      and is_stop_over = '直发'
               |      and vehicle != '虚拟车'
               |      and src_zone_code != dest_zone_code
               |      and inc_day >= '$start_time'
               |      and inc_day <= '$end_time'
               |  ) t1
               |  join (
               |    select
               |      id
               |    from
               |      dm_pass_rss.scha_tt_plan_main_pro
               |    where
               |      inc_day = '$end_time'
               |      and oper_type in (1, 2)
               |      and status != 3
               |      and regexp_replace(cast(plan_run_dt as string), '-', '') >= '$start_time'
               |      and regexp_replace(cast(plan_run_dt as string), '-', '') <= '$end_time'
               |    group by
               |      id
               |  ) b on t1.line_require_id = b.id
               |  join (
               |    select
               |      dept_code,
               |      dept_transfer_flag
               |    from
               |      dim.dim_department
               |  ) t2 on t1.src_zone_code = t2.dept_code
               |  join (
               |    select
               |      dept_code,
               |      dept_transfer_flag
               |    from
               |      dim.dim_department
               |  ) t3 on t1.dest_zone_code = t3.dept_code
               |where
               |  t2.dept_transfer_flag = '1'
               |  and t3.dept_transfer_flag = '0'
               |""".stripMargin

        logger.error(origSql)
        val df: DataFrame = spark.sql(origSql)
          .groupBy("line_code")
          .agg(
              count("line_code").as("line_code_count"),
              sum(when($"load_rate" > "0.5", 1).otherwise(0)).cast("double").as("load_rate_count")
          )
          .withColumn("load_rate_proportion_" + name, ($"load_rate_count" / $"line_code_count").cast("string"))
          .drop("load_rate_count", "line_code_count")
        df
    }

    // 获取支线散货运力数据(剔除网外地址)
    def getBranchLineData(spark: SparkSession, start_time: String, end_time: String, three_moth_start: String, three_moth_end: String,
                          six_moth_start: String, last_year_start: String, last_year_end: String, inc_day: String): Dataset[Row] = {
        import spark.implicits._

        val dlr: String = "$"
        val origSql: String =
            s"""
               |select
               |  line_code,
               |  owndeptcode,
               |  line_require_id,
               |  cvy_name,
               |  load_rate,
               |  src_zone_code,
               |  dest_zone_code,
               |  full_load_weight,
               |  load_bweight,
               |  src_area_code,
               |  dest_area_code,
               |  should_load_bnum,
               |  actual_load_bnum,
               |  is_stop_over,
               |  vehicle_serial,
               |  vehicle,
               |  capacityload,
               |  line_distance,
               |  plan_depart_tm,
               |  actual_depart_tm,
               |  plan_send_batch,
               |  actual_send_batch,
               |  plan_arrive_tm,
               |  actual_arrive_tm,
               |  plan_arrive_batch,
               |  actual_arrive_batch,
               |  plan_time_cost,
               |  actual_time_cost,
               |  transoport_level,
               |  car_status,
               |  src_hq_code,
               |  dest_hq_code,
               |  actualcapacityload,
               |  distribution_type,
               |  mode_type,
               |  running_mod,
               |  is_late,
               |  is_late1,
               |  is_late2,
               |  lastest_arrive_tm,
               |  lastest_reach_tm,
               |  line_require_type
               |from
               |  (
               |    select
               |      *
               |    from
               |      dm_ops.pass_forecast_road_convy_monitor_dtl
               |    where
               |      car_status = '已完成'
               |      and substr(src_zone_code, 1, 1) not in ('s', 'p', 'm')
               |      and substr(dest_zone_code, 1, 1) not in ('s', 'p', 'm')
               |      and regexp_replace(translate(lower(src_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |      and regexp_replace(translate(lower(dest_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |      and src_zone_code != ''
               |      and dest_zone_code != ''
               |      and transoport_level = '三级运输'
               |      and is_stop_over = '直发'
               |      and vehicle != '虚拟车'
               |      and src_zone_code != dest_zone_code
               |      and inc_day >= '$start_time'
               |      and inc_day <= '$end_time'
               |  ) t1
               |  join (
               |    select
               |      id
               |    from
               |      dm_pass_rss.scha_tt_plan_main_pro
               |    where
               |      inc_day = '$end_time'
               |      and oper_type in (1, 2)
               |      and status != 3
               |      and regexp_replace(cast(plan_run_dt as string), '-', '') >= '$start_time'
               |      and regexp_replace(cast(plan_run_dt as string), '-', '') <= '$end_time'
               |    group by
               |      id
               |  ) b on t1.line_require_id = b.id
               |  join (
               |    select
               |      dept_code,
               |      dept_transfer_flag
               |    from
               |      dim.dim_department
               |  ) t2 on t1.src_zone_code = t2.dept_code
               |  join (
               |    select
               |      dept_code,
               |      dept_transfer_flag
               |    from
               |      dim.dim_department
               |  ) t3 on t1.dest_zone_code = t3.dept_code
               |where
               |  t2.dept_transfer_flag = '1'
               |  and t3.dept_transfer_flag = '0'
               |order by
               |  line_code,
               |  plan_depart_tm
               |""".stripMargin
        val delSql: String =
            s"""
               |select
               |  line_code
               |from
               |  dm_ops.pass_forecast_road_convy_monitor_dtl a
               |  inner join (
               |    select
               |      line_require_id as id
               |    from
               |      ods_russ.tt_rs_vehicle_task_pass_zone_monitor
               |    where
               |      inc_day >= '$start_time'
               |      and inc_day <= '$end_time'
               |      and regexp_replace(line_require_date, '-', '') >= '$start_time'
               |      and regexp_replace(line_require_date, '-', '') <= '$end_time'
               |      and dept_site_id != pass_zone_code
               |    group by
               |      line_require_id
               |  ) b on a.line_require_id = b.id
               |where
               |  a.inc_day >= '$start_time'
               |  and a.inc_day <= '$end_time'
               |  and a.car_status = '已完成'
               |  and substr(a.src_zone_code, 1, 1) not in ('S', 'P', 'M')
               |  and substr(a.dest_zone_code, 1, 1) not in ('S', 'P', 'M')
               |  and regexp_replace(translate(lower(a.src_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |  and regexp_replace(translate(lower(a.dest_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |group by
               |  line_code
               |""".stripMargin

        logger.error(origSql)
        logger.error(delSql)

        // 散货运力数据
        val origDF1: DataFrame = spark.sql(origSql)
        // 需要剔除的数据
        val delDF: DataFrame = spark.sql(delSql)
        // 出发+到达网点的经纬度信息
        val (srcDF, destDF) = getDeptLonLat(spark)

        val origDF2: DataFrame = origDF1
          .join(delDF, Seq("line_code"), "leftanti")
          .join(srcDF, Seq("src_zone_code"))
          .join(destDF, Seq("dest_zone_code"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        origDF2.count()

        val origDF3: DataFrame = origDF2
          .groupBy("line_code")
          .agg(
              count("line_code").cast("string").as("line_code_count"),
              avg("load_bweight").cast("string").as("load_bweight_avg"),
              max("load_rate").as("load_rate_max"),
              sum(when($"load_rate" > "0.5", 1).otherwise(0)).cast("double").as("load_rate_count")
          )
          .withColumn("load_rate_proportion_now", ($"load_rate_count" / $"line_code_count".cast("int")).cast("string"))
          .drop("load_rate_count")
          .withColumn("inc_day", lit(inc_day))

        // 历史装载率
        val threeDF: DataFrame = getHistoryLoadRate(spark, three_moth_start, three_moth_end, "3")
        val sixDF: DataFrame = getHistoryLoadRate(spark, six_moth_start, three_moth_end, "6")
        val lastDF: DataFrame = getHistoryLoadRate(spark, last_year_start, last_year_end, "last")

        val origDF: DataFrame = origDF2.join(origDF3, Seq("line_code"), "left")
          .join(threeDF, Seq("line_code"), "left")
          .join(sixDF, Seq("line_code"), "left")
          .join(lastDF, Seq("line_code"), "left")
          .filter("src_zone_code is not null and src_zone_code != ''")
          .filter("plan_arrive_batch is not null and plan_arrive_batch != ''")
          .filter("dest_zone_code is not null and dest_zone_code != ''")
          .repartition(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, origDF, "按line_code聚合后的最终数据")
        testDF2Hive(logger, origDF, "dm_gis.deliver_line_data")

        origDF
    }

    def getOptimizationData(spark: SparkSession, origDF: Dataset[Row], inc_day: String): Dataset[Row] = {
        import spark.implicits._

        val w1: WindowSpec = Window.partitionBy("line_code_s_e1", "line_code_s_e2", "plan_depart_tm_s_e11", "plan_depart_tm_s_e22")
          .orderBy($"line_code_s_e1".asc, $"line_code_s_e2".asc, $"plan_depart_tm_s_e1".desc, $"plan_depart_tm_s_e2".desc)

        val origDF2: DataFrame = origDF
          .withColumn("key", getUniqueKey($"src_zone_code", $"plan_arrive_batch", $"dest_zone_code"))
          .selectExpr(
              "key              as key",
              "line_code                as line_code_s_e1",
              "dest_zone_code           as dest_zone_code_s_e1",
              "src_zone_code            as src_zone_code",
              "owndeptcode              as owndeptcode_s_e1",
              "line_require_id          as line_require_id_s_e1",
              "cvy_name                 as cvy_name_s_e1",
              "load_rate                as load_rate_s_e1",
              "full_load_weight         as full_load_weight_s_e1",
              "load_bweight             as load_bweight_s_e1",
              "src_area_code            as src_area_code_s_e1",
              "dest_area_code           as dest_area_code_s_e1",
              "should_load_bnum         as should_load_bnum_s_e1",
              "actual_load_bnum         as actual_load_bnum_s_e1",
              "is_stop_over             as is_stop_over_s_e1",
              "vehicle_serial           as vehicle_serial_s_e1",
              "vehicle                  as vehicle_s_e1",
              "capacityload             as capacityload_s_e1",
              "line_distance            as line_distance_s_e1",
              "plan_depart_tm           as plan_depart_tm_s_e1",
              "split(plan_depart_tm,' ')[1]           as plan_depart_tm_s_e11",
              "actual_depart_tm         as actual_depart_tm_s_e1",
              "plan_send_batch          as plan_send_batch_s_e1",
              "actual_send_batch        as actual_send_batch_s_e1",
              "plan_arrive_tm           as plan_arrive_tm_s_e1",
              "actual_arrive_tm         as actual_arrive_tm_s_e1",
              "plan_arrive_batch        as plan_arrive_batch_s_e1",
              "actual_arrive_batch      as actual_arrive_batch_s_e1",
              "plan_time_cost           as plan_time_cost_s_e1",
              "actual_time_cost         as actual_time_cost_s_e1",
              "transoport_level         as transoport_level_s_e1",
              "car_status               as car_status_s_e1",
              "src_hq_code              as src_hq_code_s_e1",
              "dest_hq_code             as dest_hq_code_s_e1",
              "actualcapacityload       as actualcapacityload_s_e1",
              "distribution_type        as distribution_type_s_e1",
              "mode_type                as mode_type_s_e1",
              "running_mod              as running_mod_s_e1",
              "is_late                  as is_late_s_e1",
              "is_late1                 as is_late1_s_e1",
              "is_late2                 as is_late2_s_e1",
              "lastest_arrive_tm        as lastest_arrive_tm_s_e1",
              "lastest_reach_tm         as lastest_reach_tm_s_e1",
              "src_longitude            as src_longitude_s_e1",
              "src_latitude             as src_latitude_s_e1",
              "dest_longitude           as dest_longitude_s_e1",
              "dest_latitude            as dest_latitude_s_e1",
              "line_code_count          as line_code_count_s_e1",
              "load_bweight_avg         as load_bweight_avg_s_e1",
              "load_rate_max            as load_rate_max_s_e1",
              "line_require_type        as line_require_type_s_e1",
              "load_rate_proportion_now as load_rate_proportion_now_s_e1",
              "load_rate_proportion_3   as load_rate_proportion_3_s_e1",
              "load_rate_proportion_6   as load_rate_proportion_6_s_e1",
              "load_rate_proportion_last as load_rate_proportion_last_s_e1",
              "inc_day                  as inc_day"
          )

        val origDF3: DataFrame = origDF
          .withColumn("key", getUniqueKey($"src_zone_code", $"plan_arrive_batch", $"dest_zone_code"))
          .selectExpr(
              "key              as key",
              "line_code                as line_code_s_e2",
              "dest_zone_code           as dest_zone_code_s_e2",
              "owndeptcode              as owndeptcode_s_e2",
              "line_require_id          as line_require_id_s_e2",
              "cvy_name                 as cvy_name_s_e2",
              "load_rate                as load_rate_s_e2",
              "full_load_weight         as full_load_weight_s_e2",
              "load_bweight             as load_bweight_s_e2",
              "src_area_code            as src_area_code_s_e2",
              "dest_area_code           as dest_area_code_s_e2",
              "should_load_bnum         as should_load_bnum_s_e2",
              "actual_load_bnum         as actual_load_bnum_s_e2",
              "is_stop_over             as is_stop_over_s_e2",
              "vehicle_serial           as vehicle_serial_s_e2",
              "vehicle                  as vehicle_s_e2",
              "capacityload             as capacityload_s_e2",
              "line_distance            as line_distance_s_e2",
              "plan_depart_tm           as plan_depart_tm_s_e2",
              "split(plan_depart_tm,' ')[1]           as plan_depart_tm_s_e22",
              "actual_depart_tm         as actual_depart_tm_s_e2",
              "plan_send_batch          as plan_send_batch_s_e2",
              "actual_send_batch        as actual_send_batch_s_e2",
              "plan_arrive_tm           as plan_arrive_tm_s_e2",
              "actual_arrive_tm         as actual_arrive_tm_s_e2",
              "plan_arrive_batch        as plan_arrive_batch_s_e2",
              "actual_arrive_batch      as actual_arrive_batch_s_e2",
              "plan_time_cost           as plan_time_cost_s_e2",
              "actual_time_cost         as actual_time_cost_s_e2",
              "transoport_level         as transoport_level_s_e2",
              "car_status               as car_status_s_e2",
              "src_hq_code              as src_hq_code_s_e2",
              "dest_hq_code             as dest_hq_code_s_e2",
              "actualcapacityload       as actualcapacityload_s_e2",
              "distribution_type        as distribution_type_s_e2",
              "mode_type                as mode_type_s_e2",
              "running_mod              as running_mod_s_e2",
              "is_late                  as is_late_s_e2",
              "is_late1                 as is_late1_s_e2",
              "is_late2                 as is_late2_s_e2",
              "lastest_arrive_tm        as lastest_arrive_tm_s_e2",
              "lastest_reach_tm         as lastest_reach_tm_s_e2",
              "src_longitude            as src_longitude_s_e2",
              "src_latitude             as src_latitude_s_e2",
              "dest_longitude           as dest_longitude_s_e2",
              "dest_latitude            as dest_latitude_s_e2",
              "line_code_count          as line_code_count_s_e2",
              "load_bweight_avg         as load_bweight_avg_s_e2",
              "load_rate_max            as load_rate_max_s_e2",
              "line_require_type        as line_require_type_s_e2",
              "load_rate_proportion_now as load_rate_proportion_now_s_e2",
              "load_rate_proportion_3   as load_rate_proportion_3_s_e2",
              "load_rate_proportion_6   as load_rate_proportion_6_s_e2",
              "load_rate_proportion_last as load_rate_proportion_last_s_e2"
          )

        val optRDD: RDD[JSONObject] = origDF2.join(origDF3, Seq("key"))
          .filter(r => {
              val line_distance_s_e1: Double = r.getAs[String]("line_distance_s_e1").toDouble
              val line_distance_s_e2: Double = r.getAs[String]("line_distance_s_e2").toDouble
              val line_code_s_e1: String = r.getAs[String]("line_code_s_e1")
              val line_code_s_e2: String = r.getAs[String]("line_code_s_e2")
              line_distance_s_e1 <= line_distance_s_e2 && line_code_s_e1 != line_code_s_e2
          })
          .filter(r => {
              val plan_depart_tm1: String = r.getAs[String]("plan_depart_tm_s_e1")
              val plan_depart_tm2: String = r.getAs[String]("plan_depart_tm_s_e2")
              val t1: Long = getTimestamp(plan_depart_tm1, "yyyy-MM-dd HH:mm:ss")
              val t2: Long = getTimestamp(plan_depart_tm2, "yyyy-MM-dd HH:mm:ss")

              var b: Boolean = false
              val t: Long = t2 - t1
              if (t >= -3600 * 1000 * 24 && t <= 3600 * 1000 * 24) {
                  val d: Double = getLineCos(r)
                  if (d >= 0.0 && d < 1.0) b = true
              }
              b
          })
          .withColumn("st", explode(getStopTime($"plan_depart_tm_s_e1", $"plan_depart_tm_s_e2", $"capacityload_s_e2", $"should_load_bnum_s_e1", $"should_load_bnum_s_e2", $"plan_time_cost_s_e1")))
          .withColumn("stop_plan_depart_tm", $"st._1")
          .withColumn("stop_time", $"st._2")
          .withColumn("rn", row_number() over w1)
          .filter("rn = 1")
          .drop("rn", "plan_depart_tm_s_e11", "plan_depart_tm_s_e22", "st", "key")
          .dropDuplicates("dest_zone_code_s_e1", "dest_zone_code_s_e2", "stop_plan_depart_tm", "capacityload_s_e2")
          .rdd
          .map(row2Json)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetRDDCountAndSampleData(logger, optRDD, "调接口前的数据线路")


        val optDF: DataFrame = runInterfaceWithAkLimit(logger, spark, optRDD, getPlanDistAndTime, 300, "f086106db05b48e6b8cb103ead38d06a", 9500)
          .map(o => {
              val line_code_s_e1: String = o.getString("line_code_s_e1")
              val line_code_s_e2: String = o.getString("line_code_s_e2")
              val dest_zone_code_s_e1: String = o.getString("dest_zone_code_s_e1")
              val dest_zone_code_s_e2: String = o.getString("dest_zone_code_s_e2")
              val src_zone_code: String = o.getString("src_zone_code")
              val owndeptcode_s_e1: String = o.getString("owndeptcode_s_e1")
              val owndeptcode_s_e2: String = o.getString("owndeptcode_s_e2")
              val line_require_id_s_e1: String = o.getString("line_require_id_s_e1")
              val line_require_id_s_e2: String = o.getString("line_require_id_s_e2")
              val cvy_name_s_e1: String = o.getString("cvy_name_s_e1")
              val cvy_name_s_e2: String = o.getString("cvy_name_s_e2")
              val load_rate_s_e1: String = o.getString("load_rate_s_e1")
              val load_rate_s_e2: String = o.getString("load_rate_s_e2")
              val full_load_weight_s_e1: String = o.getString("full_load_weight_s_e1")
              val full_load_weight_s_e2: String = o.getString("full_load_weight_s_e2")
              val load_bweight_s_e1: String = o.getString("load_bweight_s_e1")
              val load_bweight_s_e2: String = o.getString("load_bweight_s_e2")
              val src_area_code_s_e1: String = o.getString("src_area_code_s_e1")
              val src_area_code_s_e2: String = o.getString("src_area_code_s_e2")
              val dest_area_code_s_e1: String = o.getString("dest_area_code_s_e1")
              val dest_area_code_s_e2: String = o.getString("dest_area_code_s_e2")
              val should_load_bnum_s_e1: String = o.getString("should_load_bnum_s_e1")
              val should_load_bnum_s_e2: String = o.getString("should_load_bnum_s_e2")
              val actual_load_bnum_s_e1: String = o.getString("actual_load_bnum_s_e1")
              val actual_load_bnum_s_e2: String = o.getString("actual_load_bnum_s_e2")
              val is_stop_over_s_e1: String = o.getString("is_stop_over_s_e1")
              val is_stop_over_s_e2: String = o.getString("is_stop_over_s_e2")
              val vehicle_serial_s_e1: String = o.getString("vehicle_serial_s_e1")
              val vehicle_serial_s_e2: String = o.getString("vehicle_serial_s_e2")
              val vehicle_s_e1: String = o.getString("vehicle_s_e1")
              val vehicle_s_e2: String = o.getString("vehicle_s_e2")
              val capacityload_s_e1: String = o.getString("capacityload_s_e1")
              val capacityload_s_e2: String = o.getString("capacityload_s_e2")
              val line_distance_s_e1: String = o.getString("line_distance_s_e1")
              val line_distance_s_e2: String = o.getString("line_distance_s_e2")
              val plan_depart_tm_s_e1: String = o.getString("plan_depart_tm_s_e1")
              val plan_depart_tm_s_e2: String = o.getString("plan_depart_tm_s_e2")
              val actual_depart_tm_s_e1: String = o.getString("actual_depart_tm_s_e1")
              val actual_depart_tm_s_e2: String = o.getString("actual_depart_tm_s_e2")
              val plan_send_batch_s_e1: String = o.getString("plan_send_batch_s_e1")
              val plan_send_batch_s_e2: String = o.getString("plan_send_batch_s_e2")
              val actual_send_batch_s_e1: String = o.getString("actual_send_batch_s_e1")
              val actual_send_batch_s_e2: String = o.getString("actual_send_batch_s_e2")
              val plan_arrive_tm_s_e1: String = o.getString("plan_arrive_tm_s_e1")
              val plan_arrive_tm_s_e2: String = o.getString("plan_arrive_tm_s_e2")
              val actual_arrive_tm_s_e1: String = o.getString("actual_arrive_tm_s_e1")
              val actual_arrive_tm_s_e2: String = o.getString("actual_arrive_tm_s_e2")
              val plan_arrive_batch_s_e1: String = o.getString("plan_arrive_batch_s_e1")
              val plan_arrive_batch_s_e2: String = o.getString("plan_arrive_batch_s_e2")
              val actual_arrive_batc_s_e1: String = o.getString("actual_arrive_batc_s_e1")
              val actual_arrive_batc_s_e2: String = o.getString("actual_arrive_batc_s_e2")
              val plan_time_cost_s_e1: String = o.getString("plan_time_cost_s_e1")
              val plan_time_cost_s_e2: String = o.getString("plan_time_cost_s_e2")
              val actual_time_cost_s_e1: String = o.getString("actual_time_cost_s_e1")
              val actual_time_cost_s_e2: String = o.getString("actual_time_cost_s_e2")
              val transoport_level_s_e1: String = o.getString("transoport_level_s_e1")
              val transoport_level_s_e2: String = o.getString("transoport_level_s_e2")
              val car_status_s_e1: String = o.getString("car_status_s_e1")
              val car_status_s_e2: String = o.getString("car_status_s_e2")
              val src_hq_code_s_e1: String = o.getString("src_hq_code_s_e1")
              val src_hq_code_s_e2: String = o.getString("src_hq_code_s_e2")
              val dest_hq_code_s_e1: String = o.getString("dest_hq_code_s_e1")
              val dest_hq_code_s_e2: String = o.getString("dest_hq_code_s_e2")
              val actualcapacityload_s_e1: String = o.getString("actualcapacityload_s_e1")
              val actualcapacityload_s_e2: String = o.getString("actualcapacityload_s_e2")
              val distribution_type_s_e1: String = o.getString("distribution_type_s_e1")
              val distribution_type_s_e2: String = o.getString("distribution_type_s_e2")
              val mode_type_s_e1: String = o.getString("mode_type_s_e1")
              val mode_type_s_e2: String = o.getString("mode_type_s_e2")
              val running_mod_s_e1: String = o.getString("running_mod_s_e1")
              val running_mod_s_e2: String = o.getString("running_mod_s_e2")
              val is_late_s_e1: String = o.getString("is_late_s_e1")
              val is_late_s_e2: String = o.getString("is_late_s_e2")
              val is_late1_s_e1: String = o.getString("is_late1_s_e1")
              val is_late1_s_e2: String = o.getString("is_late1_s_e2")
              val is_late2_s_e1: String = o.getString("is_late2_s_e1")
              val is_late2_s_e2: String = o.getString("is_late2_s_e2")
              val lastest_arrive_tm_s_e1: String = o.getString("lastest_arrive_tm_s_e1")
              val lastest_arrive_tm_s_e2: String = o.getString("lastest_arrive_tm_s_e2")
              val lastest_reach_tm_s_e1: String = o.getString("lastest_reach_tm_s_e1")
              val lastest_reach_tm_s_e2: String = o.getString("lastest_reach_tm_s_e2")
              val src_longitude_s_e1: String = o.getString("src_longitude_s_e1")
              val src_longitude_s_e2: String = o.getString("src_longitude_s_e2")
              val src_latitude_s_e1: String = o.getString("src_latitude_s_e1")
              val src_latitude_s_e2: String = o.getString("src_latitude_s_e2")
              val dest_longitude_s_e1: String = o.getString("dest_longitude_s_e1")
              val dest_longitude_s_e2: String = o.getString("dest_longitude_s_e2")
              val dest_latitude_s_e1: String = o.getString("dest_latitude_s_e1")
              val dest_latitude_s_e2: String = o.getString("dest_latitude_s_e2")
              val line_code_count_s_e1: String = o.getString("line_code_count_s_e1")
              val line_code_count_s_e2: String = o.getString("line_code_count_s_e2")
              val load_bweight_avg_s_e1: String = o.getString("load_bweight_avg_s_e1")
              val load_bweight_avg_s_e2: String = o.getString("load_bweight_avg_s_e2")
              val load_rate_max_s_e1: String = o.getString("load_rate_max_s_e1")
              val load_rate_max_s_e2: String = o.getString("load_rate_max_s_e2")
              val stop_plan_depart_tm: String = o.getString("stop_plan_depart_tm")
              val stop_time: String = o.getString("stop_time")
              val d_dist: String = o.getString("d_dist")
              val time_e1_e2: String = o.getString("time_e1_e2")
              val line_require_type_s_e1: String = o.getString("line_require_type_s_e1")
              val line_require_type_s_e2: String = o.getString("line_require_type_s_e2")
              val load_rate_proportion_now_s_e1: String = o.getString("load_rate_proportion_now_s_e1")
              val load_rate_proportion_now_s_e2: String = o.getString("load_rate_proportion_now_s_e2")
              val load_rate_proportion_3_s_e1: String = o.getString("load_rate_proportion_3_s_e1")
              val load_rate_proportion_3_s_e2: String = o.getString("load_rate_proportion_3_s_e2")
              val load_rate_proportion_6_s_e1: String = o.getString("load_rate_proportion_6_s_e1")
              val load_rate_proportion_6_s_e2: String = o.getString("load_rate_proportion_6_s_e2")
              val load_rate_proportion_last_s_e1: String = o.getString("load_rate_proportion_last_s_e1")
              val load_rate_proportion_last_s_e2: String = o.getString("load_rate_proportion_last_s_e2")
              val inc_day: String = o.getString("inc_day")

              StopScenes2(line_code_s_e1, line_code_s_e2, dest_zone_code_s_e1, dest_zone_code_s_e2, src_zone_code, owndeptcode_s_e1, owndeptcode_s_e2, line_require_id_s_e1,
                  line_require_id_s_e2, cvy_name_s_e1, cvy_name_s_e2, load_rate_s_e1, load_rate_s_e2, full_load_weight_s_e1, full_load_weight_s_e2, load_bweight_s_e1,
                  load_bweight_s_e2, src_area_code_s_e1, src_area_code_s_e2, dest_area_code_s_e1, dest_area_code_s_e2, should_load_bnum_s_e1, should_load_bnum_s_e2,
                  actual_load_bnum_s_e1, actual_load_bnum_s_e2, is_stop_over_s_e1, is_stop_over_s_e2, vehicle_serial_s_e1, vehicle_serial_s_e2, vehicle_s_e1, vehicle_s_e2,
                  capacityload_s_e1, capacityload_s_e2, line_distance_s_e1, line_distance_s_e2, plan_depart_tm_s_e1, plan_depart_tm_s_e2, actual_depart_tm_s_e1,
                  actual_depart_tm_s_e2, plan_send_batch_s_e1, plan_send_batch_s_e2, actual_send_batch_s_e1, actual_send_batch_s_e2, plan_arrive_tm_s_e1,
                  plan_arrive_tm_s_e2, actual_arrive_tm_s_e1, actual_arrive_tm_s_e2, plan_arrive_batch_s_e1, plan_arrive_batch_s_e2, actual_arrive_batc_s_e1,
                  actual_arrive_batc_s_e2, plan_time_cost_s_e1, plan_time_cost_s_e2, actual_time_cost_s_e1, actual_time_cost_s_e2, transoport_level_s_e1,
                  transoport_level_s_e2, car_status_s_e1, car_status_s_e2, src_hq_code_s_e1, src_hq_code_s_e2, dest_hq_code_s_e1, dest_hq_code_s_e2,
                  actualcapacityload_s_e1, actualcapacityload_s_e2, distribution_type_s_e1, distribution_type_s_e2, mode_type_s_e1, mode_type_s_e2, running_mod_s_e1,
                  running_mod_s_e2, is_late_s_e1, is_late_s_e2, is_late1_s_e1, is_late1_s_e2, is_late2_s_e1, is_late2_s_e2, lastest_arrive_tm_s_e1, lastest_arrive_tm_s_e2,
                  lastest_reach_tm_s_e1, lastest_reach_tm_s_e2, src_longitude_s_e1, src_longitude_s_e2, src_latitude_s_e1, src_latitude_s_e2, dest_longitude_s_e1,
                  dest_longitude_s_e2, dest_latitude_s_e1, dest_latitude_s_e2, line_code_count_s_e1, line_code_count_s_e2, load_bweight_avg_s_e1, load_bweight_avg_s_e2,
                  load_rate_max_s_e1, load_rate_max_s_e2, stop_plan_depart_tm, stop_time, d_dist, time_e1_e2, line_require_type_s_e1, line_require_type_s_e2,
                  load_rate_proportion_now_s_e1, load_rate_proportion_now_s_e2, load_rate_proportion_3_s_e1, load_rate_proportion_3_s_e2, load_rate_proportion_6_s_e1,
                  load_rate_proportion_6_s_e2, load_rate_proportion_last_s_e1, load_rate_proportion_last_s_e2, inc_day)
          })
          .toDF()
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, optDF, "可能进行优化的线路")
        testDF2Hive(logger, optDF, "dm_gis.join_ct_time_data")

        optRDD.unpersist()

        val optDF2: DataFrame = spark.sql(s"select * from dm_gis.join_ct_time_data where inc_day=$inc_day and d_dist is not null").persist(StorageLevel.MEMORY_AND_DISK)
        optDF2.count()

        optDF2
    }

    // 获取每个网点对应的经纬度
    def getDeptLonLat(spark: SparkSession): (Dataset[Row], Dataset[Row]) = {
        val srcSql: String =
            """
              |select
              |  dept_code as src_zone_code,
              |  longitude as src_longitude,
              |  latitude as src_latitude
              |from
              |  dim.dim_department
              |where
              |  delete_flg = '0'
              |  and longitude is not null
              |  and latitude is not null
              |""".stripMargin

        val destSql: String =
            """
              |select
              |  dept_code as dest_zone_code,
              |  longitude as dest_longitude,
              |  latitude as dest_latitude
              |from
              |  dim.dim_department
              |where
              |  delete_flg = '0'
              |  and longitude is not null
              |  and latitude is not null
              |""".stripMargin

        logger.error(srcSql)
        logger.error(destSql)

        val srcDF: DataFrame = spark
          .sql(srcSql)
          .dropDuplicates("src_zone_code")

        val destDF: DataFrame = spark
          .sql(destSql)
          .dropDuplicates("dest_zone_code")

        (srcDF, destDF)
    }

    // 获取2条线路的余弦值 o1:短线  o2:长线
    def getLineCos(r: Row): Double = {
        val src_longitude1: Double = r.getAs[String]("src_longitude_s_e1").toDouble
        val src_latitude1: Double = r.getAs[String]("src_latitude_s_e1").toDouble
        val dest_longitude1: Double = r.getAs[String]("dest_longitude_s_e1").toDouble
        val dest_latitude1: Double = r.getAs[String]("dest_latitude_s_e1").toDouble

        val dest_longitude2: Double = r.getAs[String]("dest_longitude_s_e2").toDouble
        val dest_latitude2: Double = r.getAs[String]("dest_latitude_s_e2").toDouble

        // 短线 起点 → 终点 的距离
        val dist1: Double = getDistance(src_longitude1, src_latitude1, dest_longitude1, dest_latitude1)
        // 长线 起点 → 终点 的距离
        val dist2: Double = getDistance(src_longitude1, src_latitude1, dest_longitude2, dest_latitude2)
        // 短线终点 → 长线终点 的距离
        val dist3: Double = getDistance(dest_longitude1, dest_latitude1, dest_longitude2, dest_latitude2)

        val d: Double = (dist1 * dist1 + dist2 * dist2 - dist3 * dist3) / (2 * dist1 * dist2)
        d
    }

    // 把2条线路数据合并在一起
    def mergeLineJson(o1: JSONObject, o2: JSONObject): JSONObject = {
        val keys1: util.Iterator[String] = o1.keySet().iterator()
        val keys2: util.Iterator[String] = o2.keySet().iterator()

        val arr: Array[String] = Array("inc_day", "src_zone_code")
        val o: JSONObject = new JSONObject()
        while (keys1.hasNext) {
            val k: String = keys1.next()
            if (!arr.contains(k)) o.put(k + "_s_e1", o1.getString(k))
            else o.put(k, o1.getString(k))
        }

        while (keys2.hasNext) {
            val k: String = keys2.next()
            if (!arr.contains(k)) o.put(k + "_s_e2", o2.getString(k))
        }
        o
    }

    // 获取经停点计划发车时间
    def getStopTime: UserDefinedFunction = udf((plan_depart_tm_s_e1: String, plan_depart_tm_s_e2: String, capacityload_s_e2: String, should_load_bnum_s_e1: String, should_load_bnum_s_e2: String, plan_time_cost_s_e1: String) => {

        val plan_depart_tm: String = if (plan_depart_tm_s_e1 > plan_depart_tm_s_e2) plan_depart_tm_s_e1 else plan_depart_tm_s_e2
        var stop_time: Long = 0
        try {
            stop_time = if (capacityload_s_e2.toDouble < 7.0 && should_load_bnum_s_e1.toDouble + should_load_bnum_s_e2.toDouble < 600.00) 15 * 60 * 1000 else 30 * 60 * 1000
        } catch {
            case e: Exception => logger.error("抛异常了:" + e.getMessage)
        }

        val plan_time_cost_s_e11: Long = plan_time_cost_s_e1.toLong * 60 * 1000

        val stop_plan_depart_tm: Long = getTimestamp(plan_depart_tm, "yyyy-MM-dd HH:mm:ss") + plan_time_cost_s_e11 + stop_time
        val stop_plan_depart_tm2: String = getDateStr(stop_plan_depart_tm, "yyyyMMddHHmm")

        val res = new Array[(String, String)](1)
        res(0) = (stop_plan_depart_tm2, stop_time.toString)
        res
    })

    // 获取规划里程和时长
    def getPlanDistAndTime(ak: String, o: JSONObject): JSONObject = {
        val x1: String = o.getString("dest_longitude_s_e1")
        val y1: String = o.getString("dest_latitude_s_e1")

        val x2: String = o.getString("dest_longitude_s_e2")
        val y2: String = o.getString("dest_latitude_s_e2")

        val planDate: String = o.getString("stop_plan_depart_tm")
        val mload: String = o.getString("capacityload_s_e2")

        val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]

        parMap.put("x1", x1)
        parMap.put("y1", y1)
        parMap.put("x2", x2)
        parMap.put("y2", y2)
        parMap.put("planDate", planDate)
        parMap.put("mload", mload)
        parMap.put("ak", ak)

        val url: String = ct_url + map2String(parMap)

        val jsonData: JSONObject = getJsonByGet(url, 2, "utf-8")

        if (jsonData != null) {
            val status: String = jsonData.getString("status")
            if (status == "0") {
                val result: JSONObject = jsonData.getJSONObject("result")
                val list: JSONArray = result.getJSONArray("list")
                if (list != null && list.size() > 0) {
                    val obj: JSONObject = list.getJSONObject(0)
                    val d_dist: lang.Double = obj.getDouble("dist")
                    var d_time: Long = obj.getLong("time")

                    val plan_speed: Double = (3.6 * d_dist) / d_time
                    val speed: Double = getMinSpeed(d_dist, plan_speed)

                    if (speed < plan_speed) d_time = ((3.6 * d_dist) / speed).toLong

                    val time_e1_e2: Long = d_time / (3600 * 4) * 20 + d_time / 60

                    o.put("d_dist", d_dist)
                    o.put("time_e1_e2", time_e1_e2)
                }
            }
        }

        o
    }

    // 获取规划时速和最高时速的较小者
    def getMinSpeed(d_dist: Double, plan_speed: Double): Double = {
        var min_speed: Double = 0.0

        if (d_dist <= 10000) min_speed = math.min(45, plan_speed)
        else if (d_dist <= 50000) min_speed = math.min(50, plan_speed)
        else if (d_dist <= 100000) min_speed = math.min(60, plan_speed)
        else if (d_dist <= 200000) min_speed = math.min(70, plan_speed)
        else if (d_dist <= 1000000) min_speed = math.min(75, plan_speed)
        else min_speed = math.min(80, plan_speed)

        min_speed
    }

    // 获取日需求班次数据
    def getRequireBatchInfo(spark: SparkSession, start_time: String, end_time: String): Dataset[Row] = {
        val requireBathSql: String =
            s"""
               |with a as(
               |select
               |  latest_arrival_tm,
               |  plan_main_id,
               |  dept_code,
               |  arrive_batch,
               |  send_batch,
               |  send_tm,
               |  inc_day
               |from
               |  dm_pass_rss.scha_tt_plan_point_pro
               |where
               |  regexp_replace(cast(plan_run_dt as string),'-','') >= '$start_time'
               |  and regexp_replace(cast(plan_run_dt as string),'-','') <= '$end_time'
               |  and inc_day = '$end_time'
               |  and latest_arrival_tm is not null
               |  and send_batch is not null
               |  and send_batch != ''
               |  and job_type in ('1', '2', '3')
               |  and point_mean != 3
               |  and point_type = 1
               |),
               |
               |b as(
               |select
               |  id
               |from
               |  dm_pass_rss.scha_tt_plan_main_pro
               |where
               |  inc_day = '$end_time'
               |  and oper_type in (1, 2)
               |group by
               |  id
               |),
               |
               |t1 as(
               |select
               |  row_number() over(
               |    partition by dept_code,
               |    send_batch,
               |    latest_arrival_tm,
               |    send_tm
               |    order by
               |      inc_day desc
               |  ) as rn,
               |  a.*
               |from
               |   a
               |join
               |  b on a.plan_main_id = b.id
               |)
               |
               |select
               |  *
               |from
               |   t1
               |where
               |  rn = 1
               |order by
               |  dept_code,
               |  latest_arrival_tm,
               |  send_batch
               |""".stripMargin

        val batchDF: DataFrame = spark.sql(requireBathSql)
        batchDF
    }

    // 获取航管班次数据
    def getAviationBatchInfo(spark: SparkSession, start_time: String, end_time: String): Dataset[Row] = {
        val AviationBathSql: String =
            s"""
               |select
               |  *
               |from
               |  (
               |    select
               |      row_number() over(
               |        partition by src_dept_code,
               |        src_send_batch,
               |        src_send_tm,
               |        lastest_arrive_tm
               |        order by
               |          inc_day desc
               |      )						as rn,
               |      lastest_arrive_tm		as latest_arrival_tm,
               |      cvy_name				as plan_main_id,
               |      src_dept_code			as dept_code,
               |      dest_arrive_batch		as arrive_batch,
               |      src_send_batch		as send_batch,
               |      src_send_tm			as send_tm,
               |      inc_day
               |    from
               |      dm_pass_rss.aira_tm_air_transport_batch_pro
               |    where
               |	  regexp_replace(cast(send_date as string),'-','') >= '$start_time'
               |	  and regexp_replace(cast(send_date as string),'-','') <= '$end_time'
               |      and practical_cvy_type = 1
               |      and lastest_arrive_tm !=''
               |      and inc_day = '$end_time'
               |  ) a
               |where
               | rn = 1
               |""".stripMargin

        val batchDF: DataFrame = spark.sql(AviationBathSql)
        batchDF
    }

    // 获收仓数据
    def getIncomeWarehouseInfo(spark: SparkSession, start_time: String, end_time: String): Dataset[Row] = {
        val incomeSql: String =
            s"""
               |select
               |  *
               |from
               |  (
               |    select
               |      row_number() over(
               |        partition by batch_code,
               |        workday,
               |        last_indepot_tm
               |        order by
               |          inc_day desc
               |      )                                     as rn,
               |      substring(last_indepot_tm, 2, 5)      as latest_arrival_tm,
               |      operate_zone_code                     as dept_code,
               |      batch_code                            as send_batch,
               |      cast(un_effective_tm as string)       as un_effective_tm,
               |      cast(effective_tm as string)          as effective_tm,
               |      workday,
               |      inc_day
               |    from
               |      dm_pass_rss.sbsa_tm_pickup_depot_pro
               |    where
               |      inc_day = '$end_time'
               |      and data_state = 1
               |      and delete_flg = 0
               |	  and regexp_replace(cast(un_effective_tm as string),'-','') >= '$start_time'
               |  ) a
               |where
               |  rn= 1
               |""".stripMargin

        val incomeDF: DataFrame = spark.sql(incomeSql)
        incomeDF
    }

    // 获派仓数据
    def getSendWarehouseInfo(spark: SparkSession, start_time: String, end_time: String): Dataset[Row] = {
        val sendSql: String =
            s"""
               |select
               |  *
               |from
               |  (
               |    select
               |      row_number() over(
               |        partition by batch_code,
               |        workday,
               |        last_arrive_tm
               |        order by
               |          inc_day desc
               |      )										as rn,
               |      substring(last_arrive_tm, 2, 5)		as latest_arrival_tm,
               |      operate_zone_code						as dept_code,
               |      batch_code							as send_batch,
               |      cast(un_effective_tm as string)       as un_effective_tm,
               |      cast(effective_tm as string)          as effective_tm,
               |      workday,
               |      inc_day
               |    from
               |      dm_pass_rss.sbsa_tm_deliver_depot_pro
               |    where
               |      inc_day = '$end_time'
               |      and delete_flg = 0
               |	  and regexp_replace(cast(un_effective_tm as string),'-','') >= '$start_time'
               |  ) a
               |where
               |  rn = 1
               |""".stripMargin
        val sendDF: DataFrame = spark.sql(sendSql)
        sendDF
    }

    // 获取日期数据
    def getDateInfo(logger: Logger, spark: SparkSession, start_time: String, end_time: String): Dataset[Row] = {
        val dates: List[String] = getBetweenDates(start_time, end_time)

        val dateBuff = new ListBuffer[(String, String)]
        for (d <- dates) {
            val i: String = getdayOfWeek(d).toString
            dateBuff.append((d, i))
        }

        val dateDF: DataFrame = spark.createDataFrame(dateBuff)
          .toDF("date", "weekday_type")
          .withColumn("merge_col", lit("1"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, dateDF, "日期数据")

        dateDF
    }

    // 派仓 和 收仓 数据的预处理
    def prevDeal(whDF: Dataset[Row], dateDF: Dataset[Row], tp: String): Dataset[Row] = {

        val df: DataFrame = whDF
          .withColumn("type", lit(tp))
          .withColumn("arrive_batch", lit(""))
          .withColumn("merge_col", lit("1"))
          .join(dateDF, Seq("merge_col"), "left")
          .filter(r => {
              val date: String = r.getAs[String]("date")
              val effective_tm: String = r.getAs[String]("effective_tm")
              val un_effective_tm: String = r.getAs[String]("un_effective_tm")

              if (date >= effective_tm && date <= un_effective_tm) true else false
          })
          .withColumn("del", isContain(col("weekday_type"), col("workday")))
          .filter("del = 0")
          .withColumn("latest_arrival_tm", concat(col("date"), lit(" "), col("latest_arrival_tm"), lit(":00")))
          .withColumn("plan_main_id", lit(""))
          .withColumn("send_tm", lit(""))
          .drop("merge_col", "date", "weekday_type", "del")
          .select("rn", "latest_arrival_tm", "plan_main_id", "dept_code", "arrive_batch", "send_batch", "send_tm", "inc_day", "type")

        df
    }

    def isContain: UserDefinedFunction = udf((weekday_type: String, weekday: String) => {
        if (weekday.contains(weekday_type)) 0 else 1
    })

    def getUniqueKey: UserDefinedFunction = udf((src_zone_code: String, plan_arrive_batch: String, dest_zone_code: String) => {
        val k: String = src_zone_code + plan_arrive_batch.split(dest_zone_code)(1)
        k
    })

    // 最大延长时间(单位：分钟)
    def getMaxDelayTime: UserDefinedFunction = udf((latest_arrival_tm_s_e1: String, plan_arrive_tm_s_e1: String) => {
        val l1: Long = getTimestamp(latest_arrival_tm_s_e1, "yyyy-MM-dd HH:mm:ss")
        val l2: Long = getTimestamp(plan_arrive_tm_s_e1, "yyyy-MM-dd HH:mm:ss")
        val m: Long = (l1 - l2) / (1000 * 60)
        m
    })

    // 获取到达时间
    def getArriveTime: UserDefinedFunction = udf((plan_arrive_tm_s_e2: String, plan_time_cost_s_e1: String) => {
        val l1: Long = getTimestamp(plan_arrive_tm_s_e2, "yyyy-MM-dd HH:mm:ss")
        val l2: Long = plan_time_cost_s_e1.toLong * 1000 * 60
        val t: String = getDateStr(l1 + l2, "yyyy-MM-dd HH:mm:ss")
        t
    })

    def getArriveTime2: UserDefinedFunction = udf((plan_arrive_tm_s_e2: String, plan_time_cost_s_e1: Double) => {
        val l1: Long = getTimestamp(plan_arrive_tm_s_e2, "yyyy-MM-dd HH:mm:ss")
        val l2: Long = plan_time_cost_s_e1.toLong * 1000 * 60
        val t: String = getDateStr(l1 + l2, "yyyy-MM-dd HH:mm:ss")
        t
    })

    def getFomatDate: UserDefinedFunction = udf((s: String) => {
        val l1: Long = getTimestamp(s, "yyyyMMddHHmm")
        val t: String = getDateStr(l1, "yyyy-MM-dd HH:mm:ss")
        t
    })

    // 获取0.8范围内最大车型
    def getMaxCarType: UserDefinedFunction = udf((load_bweight_avg_sum: Double, capacityload_s_e2: String, load_rate_sum_before: Double) => {
        var c: Double = 0.0 // 0.0 表示 "不更换车型"

        if (load_rate_sum_before > 0.8) {
            val d: Double = load_bweight_avg_sum / 0.8
            if (d <= 300) c = 0.3
            else if (d <= 500) c = 0.5
            else if (d <= 1000) c = 1.0
            else if (d <= 1500) c = 1.5
            else if (d <= 2000) c = 3.0
            else if (d <= 3500) c = 5.0
            else if (d <= 5300) c = 7.0
            else if (d <= 6500) c = 14.0
            else if (d <= 8300) c = 17.0
            else if (d <= 9000) c = 20.0
            else if (d <= 11000) c = 30.0

            c = if (c <= capacityload_s_e2.toDouble) 0.0 else c
        }

        c
    })

    // 判断更换的车型是否合理
    def isLegitimate: UserDefinedFunction = udf((change_type: Double, capacityload_s_e2: String) => {
        var b: Boolean = false

        val c: Double = capacityload_s_e2.toDouble
        if (c == 0.3 && change_type > 0 && change_type <= 0.5) b = true
        else if (c == 0.5 && change_type >= 0.3 && change_type <= 1) b = true
        else if (c == 1 && change_type >= 0.5 && change_type <= 1.5) b = true
        else if (c == 1.5 && change_type >= 1 && change_type <= 3) b = true
        else if (c == 3 && change_type >= 1.5 && change_type <= 5) b = true
        else if (c == 5 && change_type >= 3 && change_type <= 7) b = true
        else if (c == 7 && change_type >= 5 && change_type <= 14) b = true
        else if (c == 14 && change_type >= 7 && change_type <= 17) b = true
        else if (c == 17 && change_type >= 14 && change_type <= 20) b = true
        else if (c == 20 && change_type >= 17 && change_type <= 30) b = true
        else if (c == 30 && change_type >= 20 && change_type <= 40) b = true

        b
    })

    // 获取 起点→ s1、s1→s2 的时长和里程
    def getDistAndTime: UserDefinedFunction = udf((src_longitude_s_e1: String, src_latitude_s_e1: String, dest_longitude_s_e1: String,
                                                   dest_latitude_s_e1: String, dest_longitude_s_e2: String, dest_latitude_s_e2: String,
                                                   plan_depart_tm: String, src_stop_tm: String, stop_time: String, cc: String) => {
        val date1: String = plan_depart_tm
          .replaceAll("-", "")
          .replaceAll(" ", "")
          .split(":")
          .slice(0, 2)
          .mkString

        val l1: Long = getTimestamp(plan_depart_tm, "yyyy-MM-dd HH:mm:ss") + src_stop_tm.toDouble.toLong * 60 * 1000 + stop_time.toLong
        val date2: String = getDateStr(l1, "yyyyMMddHHmm")

        val longLatArr: Array[(String, String, String, String, String)] = Array(
            (src_longitude_s_e1, src_latitude_s_e1, dest_longitude_s_e1, dest_latitude_s_e1, date1),
            (dest_longitude_s_e1, dest_latitude_s_e1, dest_longitude_s_e2, dest_latitude_s_e2, date2)
        )

        val distArr: Array[(String, String)] = Array(("0", "0"), ("0", "0"))

        val ccArr: Array[String] = cc.split(";")
        val change_type: Double = ccArr(0).toDouble
        val capacityload_s_e2: String = ccArr(1)
        if (change_type != 0.0) {
            for (i <- longLatArr.indices) {
                val x1: String = longLatArr(i)._1
                val y1: String = longLatArr(i)._2
                val x2: String = longLatArr(i)._3
                val y2: String = longLatArr(i)._4
                val planDate: String = longLatArr(i)._5
                val mload: Double = change_type

                val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
                parMap.put("x1", x1)
                parMap.put("y1", y1)
                parMap.put("x2", x2)
                parMap.put("y2", y2)
                parMap.put("planDate", planDate)
                parMap.put("mload", mload)
                parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

                val url: String = ct_url + map2String(parMap)

                val jsonData: JSONObject = getJsonByGet(url, 2, "utf-8")

                if (jsonData != null) {
                    val status: String = jsonData.getString("status")
                    if (status == "0") {
                        val result: JSONObject = jsonData.getJSONObject("result")
                        val list: JSONArray = result.getJSONArray("list")
                        if (list != null && list.size() > 0) {
                            val obj: JSONObject = list.getJSONObject(0)
                            val d_dist: Double = obj.getDouble("dist")
                            var d_time: Long = obj.getLong("time")

                            val plan_speed: Double = (3.6 * d_dist) / d_time
                            val speed: Double = getMinSpeed(d_dist, plan_speed)

                            if (speed < plan_speed) d_time = ((3.6 * d_dist) / speed).toLong

                            val time_e1_e2: Long = d_time / 3600 * 20 + d_time / 60

                            distArr(i) = (d_dist.toString, time_e1_e2.toString)
                        }
                    }
                }

            }
        } else {

            val x1: String = longLatArr(0)._1
            val y1: String = longLatArr(0)._2
            val x2: String = longLatArr(0)._3
            val y2: String = longLatArr(0)._4
            val planDate: String = longLatArr(0)._5
            val mload: String = capacityload_s_e2

            val parMap: mutable.HashMap[String, Any] = new mutable.HashMap[String, Any]
            parMap.put("x1", x1)
            parMap.put("y1", y1)
            parMap.put("x2", x2)
            parMap.put("y2", y2)
            parMap.put("planDate", planDate)
            parMap.put("mload", mload)
            parMap.put("ak", "f086106db05b48e6b8cb103ead38d06a")

            val url: String = ct_url + map2String(parMap)

            val jsonData: JSONObject = getJsonByGet(url, 2, "utf-8")

            if (jsonData != null) {
                val status: String = jsonData.getString("status")
                if (status == "0") {
                    val result: JSONObject = jsonData.getJSONObject("result")
                    val list: JSONArray = result.getJSONArray("list")
                    if (list != null && list.size() > 0) {
                        val obj: JSONObject = list.getJSONObject(0)
                        val d_dist: Double = obj.getDouble("dist")
                        var d_time: Long = obj.getLong("time")

                        val plan_speed: Double = (3.6 * d_dist) / d_time
                        val speed: Double = getMinSpeed(d_dist, plan_speed)

                        if (speed < plan_speed) d_time = ((3.6 * d_dist) / speed).toLong

                        val time_e1_e2: Long = d_time / 3600 * 20 + d_time / 60

                        distArr(0) = (d_dist.toString, time_e1_e2.toString)
                    }
                }


            }
        }

        distArr
    })

    // 单位是分钟
    def getTimeDiff: UserDefinedFunction = udf((plan_arrive_tm: String, plan_arrive_tm_s_e2: String) => {
        val l1: Long = getTimestamp(plan_arrive_tm, "yyyy-MM-dd HH:mm:ss")
        val l2: Long = getTimestamp(plan_arrive_tm_s_e2, "yyyy-MM-dd HH:mm:ss")
        ((l1 - l2) / (1000 * 60)).toString
    })

    def getSrcStopTime: UserDefinedFunction = udf((latest_arrival_tm_s_e1: String, plan_depart_tm_s_e2: String) => {
        val l1: Long = getTimestamp(latest_arrival_tm_s_e1, "yyyy-MM-dd HH:mm:ss")
        val l2: Long = getTimestamp(plan_depart_tm_s_e2, "yyyy-MM-dd HH:mm:ss")
        ((l1 - l2) / (1000 * 60)).toDouble
    })

    // 合并 派仓、收仓、日需、航管数据
    def mergeAllData2(spark: SparkSession, start_time: String, end_time: String): Dataset[Row] = {
        val incomeDF: DataFrame = getIncomeWarehouseInfo(spark, start_time, end_time).select("latest_arrival_tm", "send_batch")
        val sendDF: DataFrame = getSendWarehouseInfo(spark, start_time, end_time).select("latest_arrival_tm", "send_batch")
        val requireDF: DataFrame = getRequireBatchInfo(spark, start_time, end_time).select("latest_arrival_tm", "send_batch")
        val aviDF: DataFrame = getAviationBatchInfo(spark, start_time, end_time).select("latest_arrival_tm", "send_batch")

        val allDF: Dataset[Row] = incomeDF
          .union(sendDF)
          .withColumn("latest_arrival_tm", concat(lit(start_time), lit(" "), col("latest_arrival_tm"), lit(":00")))
          .union(requireDF)
          .union(aviDF)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, allDF, "所有的班次数据2")
        allDF
    }

    // 合并 派仓、收仓、日需、航管数据
    def mergeAllData(spark: SparkSession, start_time: String, end_time: String): Dataset[Row] = {
        import spark.implicits._

        val incomeDF: DataFrame = getIncomeWarehouseInfo(spark, start_time, end_time)
        val sendDF: DataFrame = getSendWarehouseInfo(spark, start_time, end_time)
        val dateDF: DataFrame = getDateInfo(logger, spark, start_time, end_time)

        val incomeDF2: DataFrame = prevDeal(incomeDF, dateDF, "收仓")
        val sendDF2: DataFrame = prevDeal(sendDF, dateDF, "派仓")

        val requireDF: DataFrame = getRequireBatchInfo(spark, start_time, end_time)
        val aviDF: DataFrame = getAviationBatchInfo(spark, start_time, end_time)

        val w1: WindowSpec = Window.partitionBy("dept_code", "send_batch", "latest_arrival_tm", "send_tm").orderBy($"inc_day".desc)
        val w2: WindowSpec = Window.partitionBy("dept_code", "latest_arrival_tm", "send_batch", "send_tm").orderBy($"inc_day".desc)
        val allDF: Dataset[Row] = requireDF
          .union(aviDF)
          .filter(r => {
              val latest_arrival_tm: String = r.getAs[String]("latest_arrival_tm")
              val send_batch: String = r.getAs[String]("send_batch")
              val inc_day: String = r.getAs[String]("inc_day")

              if (!isEmptyOrNull(latest_arrival_tm) && !isEmptyOrNull(send_batch) && inc_day != "inc_day" && inc_day > "20211001") true else false
          })
          .withColumn("rn2", row_number() over w1)
          .filter("rn2 = 1")
          .drop("rn2")
          .orderBy("dept_code", "latest_arrival_tm", "send_batch")
          .withColumn("type", lit("中转"))
          .union(incomeDF2)
          .union(sendDF2)
          .withColumn("incday", $"inc_day")
          .withColumn("rn3", row_number() over w2)
          .filter("rn3 = 1")
          .drop("rn3", "inc_day")
          .withColumnRenamed("incday", "inc_day")
          .orderBy("dept_code", "send_tm", "latest_arrival_tm", "send_batch")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, allDF, "所有的班次数据")
        testDF2Hive(logger, allDF, "dm_gis.batch_concat_data")

        allDF
    }

    // 获取长线、短线 的最大延长时间
    def getLineDelayTime(spark: SparkSession, optDF: Dataset[Row], bacthDF: Dataset[Row], bacthDF2: Dataset[Row]): Dataset[Row] = {
        import spark.implicits._

        val w1: WindowSpec = Window.partitionBy("line_code_s_e1", "line_code_s_e2").orderBy($"latest_arrival_tm")
        val w2: WindowSpec = Window.partitionBy("line_code_s_e1", "line_code_s_e2").orderBy($"latest_arrival_tm2")

        // 能从 bacthDF 关联上的数据
        val latestDF1: DataFrame = optDF.join(bacthDF, optDF("plan_arrive_batch_s_e1") === bacthDF("send_batch"), "left")
          .drop(bacthDF("inc_day"))
          .filter("latest_arrival_tm >= plan_arrive_tm_s_e1")
          .withColumn("r1", row_number().over(w1))
          .filter("r1 = 1")
          .withColumn("latest_arrival_tm_s_e1", $"latest_arrival_tm")
          .withColumn("later_time_s_e1", getMaxDelayTime($"latest_arrival_tm_s_e1", $"plan_arrive_tm_s_e1"))
          .drop("rn", "latest_arrival_tm", "plan_main_id", "dept_code", "arrive_batch", "send_batch", "send_tm", "type", "r1")
          .join(bacthDF, optDF("plan_arrive_batch_s_e2") === bacthDF("send_batch"))
          .drop(bacthDF("inc_day"))
          .filter("latest_arrival_tm >= plan_arrive_tm_s_e2")
          .withColumn("r2", row_number().over(w1))
          .filter("r2 = 1")
          .withColumn("latest_arrival_tm_s_e2", $"latest_arrival_tm")
          .withColumn("later_time_s_e2", getMaxDelayTime($"latest_arrival_tm_s_e2", $"plan_arrive_tm_s_e2"))
          .drop("rn", "latest_arrival_tm", "plan_main_id", "dept_code", "arrive_batch", "send_batch", "send_tm", "type", "r2")
          .persist(StorageLevel.MEMORY_AND_DISK)

        //        GetDFCountAndSampleData(logger, latestDF1, "满足最大延迟时间的线路数据1")
        //        testDF2Hive(logger, latestDF1, "dm_gis.join_latest_arrival_tm_data_notnull")


        // 从 bacthDF 关联不上的数据
        val latestDF2: DataFrame = optDF.join(latestDF1, Seq("line_code_s_e1", "line_code_s_e2"), "leftanti")
          .join(bacthDF2, optDF("plan_arrive_batch_s_e1") === bacthDF2("send_batch"), "left")
          .withColumn("plan_arrive_tm_s_e11", split($"plan_arrive_tm_s_e1", " ")(1))
          .withColumn("latest_arrival_tm2", split($"latest_arrival_tm", " ")(1))
          .filter("latest_arrival_tm2 >= plan_arrive_tm_s_e11")
          .withColumn("r1", row_number().over(w2))
          .filter("r1 = 1")
          .withColumn("latest_arrival_tm_s_e1", concat_ws(" ", split($"plan_arrive_tm_s_e1", " ")(0), $"latest_arrival_tm2"))
          .withColumn("later_time_s_e1", getMaxDelayTime($"latest_arrival_tm_s_e1", $"plan_arrive_tm_s_e1"))
          .drop("rn", "latest_arrival_tm", "plan_main_id", "dept_code", "arrive_batch", "send_batch", "send_tm", "type", "r1", "plan_arrive_tm_s_e11", "latest_arrival_tm2")
          .join(bacthDF2, optDF("plan_arrive_batch_s_e2") === bacthDF2("send_batch"), "left")
          .withColumn("plan_arrive_tm_s_e22", split($"plan_arrive_tm_s_e2", " ")(1))
          .withColumn("latest_arrival_tm2", split($"latest_arrival_tm", " ")(1))
          .filter("latest_arrival_tm2 >= plan_arrive_tm_s_e22")
          .withColumn("r2", row_number().over(w2))
          .filter("r2 = 1")
          .withColumn("latest_arrival_tm_s_e2", concat_ws(" ", split($"plan_arrive_tm_s_e2", " ")(0), $"latest_arrival_tm2"))
          .withColumn("later_time_s_e2", getMaxDelayTime($"latest_arrival_tm_s_e2", $"plan_arrive_tm_s_e2"))
          .drop("rn", "latest_arrival_tm", "plan_main_id", "dept_code", "arrive_batch", "send_batch", "send_tm", "type", "r2", "plan_arrive_tm_s_e22", "latest_arrival_tm2")
          .persist(StorageLevel.MEMORY_AND_DISK)

        //        GetDFCountAndSampleData(logger, latestDF2, "满足最大延迟时间的线路数据2")
        //        testDF2Hive(logger, latestDF2, "dm_gis.join_latest_arrival_tm_data_null")

        val latestDF: Dataset[Row] = latestDF1
          .union(latestDF2)
          .filter("later_time_s_e1 <= 200 and later_time_s_e2 <= 200")
          .repartition(300)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, latestDF, "满足最大延迟时间的线路数据3")
        testDF2Hive(logger, latestDF, "dm_gis.join_latest_arrival_tm_less200_data")

        latestDF
    }

    // 获取短线满足优化的路线
    def getShortOptLine(spark: SparkSession, lineDelayDF: Dataset[Row]): Dataset[Row] = {
        import spark.implicits._

        val shortDF: Dataset[Row] = lineDelayDF
          .filter("plan_depart_tm_s_e1 >= plan_depart_tm_s_e2")
          .withColumn("plan_depart_tm", $"plan_depart_tm_s_e1")
          .withColumn("src_stop_tm", $"plan_time_cost_s_e1")
          .withColumn("src_dest_tm", $"plan_time_cost_s_e1".cast("int") + $"stop_time".cast("int") / (1000 * 60) + $"time_e1_e2".cast("int"))
          .withColumn("stop_arrive_tm", $"plan_arrive_tm_s_e1")
          .filter(r => {
              val src_dest_tm: Double = r.getAs[Double]("src_dest_tm")

              val plan_time_cost_s_e2: Int = r.getAs[String]("plan_time_cost_s_e2").toInt
              val later_time_s_e2: Long = r.getAs[Long]("later_time_s_e2")

              val plan_depart_tm_s_e1: String = r.getAs[String]("plan_depart_tm_s_e1")
              val plan_depart_tm_s_e2: String = r.getAs[String]("plan_depart_tm_s_e2")

              val m1: Long = getTimestamp(plan_depart_tm_s_e1, "yyyy-MM-dd HH:mm:ss") / (1000 * 60)
              val m2: Long = getTimestamp(plan_depart_tm_s_e2, "yyyy-MM-dd HH:mm:ss") / (1000 * 60)

              if (src_dest_tm <= plan_time_cost_s_e2 + later_time_s_e2 - m1 + m2) true else false
          })
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, shortDF, "短线满足优化的线路")
        testDF2Hive(logger, shortDF, "dm_gis.short_time_ok_data")

        shortDF
    }

    // 获取长线满足优化条件的线路(不压缩时间)
    def getLongOptLine(spark: SparkSession, lineDelayDF: Dataset[Row]): Dataset[Row] = {
        import spark.implicits._

        val longDF: Dataset[Row] = lineDelayDF
          .filter("plan_depart_tm_s_e2 > plan_depart_tm_s_e1")
          .withColumn("plan_depart_tm", $"plan_depart_tm_s_e2")
          .withColumn("src_stop_tm", $"plan_time_cost_s_e1")
          .withColumn("src_dest_tm", $"plan_time_cost_s_e1".cast("int") + $"stop_time".cast("int") / (1000 * 60) + $"time_e1_e2".cast("int"))
          .withColumn("stop_arrive_tm", getArriveTime($"plan_arrive_tm_s_e2", $"plan_time_cost_s_e1"))
          .filter(r => {
              val src_dest_tm: Double = r.getAs[Double]("src_dest_tm")

              val plan_time_cost_s_e1: Int = r.getAs[String]("plan_time_cost_s_e1").toInt
              val plan_time_cost_s_e2: Int = r.getAs[String]("plan_time_cost_s_e2").toInt
              val later_time_s_e2: Long = r.getAs[Long]("later_time_s_e2")

              val latest_arrival_tm_s_e1: String = r.getAs[String]("latest_arrival_tm_s_e1")
              val plan_depart_tm_s_e2: String = r.getAs[String]("plan_depart_tm_s_e2")
              val m1: Long = getTimestamp(latest_arrival_tm_s_e1, "yyyy-MM-dd HH:mm:ss") / (1000 * 60)
              val m2: Long = getTimestamp(plan_depart_tm_s_e2, "yyyy-MM-dd HH:mm:ss") / (1000 * 60)

              if (plan_time_cost_s_e1 <= m1 - m2 && src_dest_tm <= plan_time_cost_s_e2 + later_time_s_e2) true else false
          })
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, longDF, "长线不压缩时间的线路")
        testDF2Hive(logger, longDF, "dm_gis.long_not_compress_time_ok_data")

        longDF
    }

    // 获取长线满足优化条件的线路(压缩时间)
    def getLongOptLine2(spark: SparkSession, lineDelayDF: Dataset[Row], origDF: Dataset[Row]): Dataset[Row] = {
        import spark.implicits._

        val origDF2: Dataset[Row] = origDF
          .filter("actual_time_cost is not null and actual_time_cost != ''")
          .selectExpr("line_code", "cast(actual_time_cost as double) as actual_time_cost")
          .groupBy("line_code")
          .agg(max("actual_time_cost").as("max_actual_time_cost"))

        val longDF: Dataset[Row] = lineDelayDF
          .filter("plan_depart_tm_s_e2 > plan_depart_tm_s_e1")
          .withColumn("plan_depart_tm", $"plan_depart_tm_s_e2")
          .withColumn("src_stop_tm", getSrcStopTime($"latest_arrival_tm_s_e1", $"plan_depart_tm_s_e2").cast("string"))
          .withColumn("src_dest_tm", $"src_stop_tm".cast("int") + $"stop_time".cast("int") / (1000 * 60) + $"time_e1_e2".cast("int"))
          .withColumn("stop_arrive_tm", getArriveTime2($"plan_depart_tm", $"src_stop_tm"))
          .filter(r => {
              val plan_time_cost_s_e1: Int = r.getAs[String]("plan_time_cost_s_e1").toInt
              val latest_arrival_tm_s_e1: String = r.getAs[String]("latest_arrival_tm_s_e1")
              val plan_depart_tm_s_e2: String = r.getAs[String]("plan_depart_tm_s_e2")
              val m1: Long = getTimestamp(latest_arrival_tm_s_e1, "yyyy-MM-dd HH:mm:ss") / (1000 * 60)
              val m2: Long = getTimestamp(plan_depart_tm_s_e2, "yyyy-MM-dd HH:mm:ss") / (1000 * 60)

              val src_dest_tm: Double = r.getAs[Double]("src_dest_tm")
              val plan_time_cost_s_e2: Int = r.getAs[String]("plan_time_cost_s_e2").toInt
              val later_time_s_e2: Long = r.getAs[Long]("later_time_s_e2")

              if (plan_time_cost_s_e1 > m1 - m2 && src_dest_tm <= plan_time_cost_s_e2 + later_time_s_e2) true else false
          })
          .join(origDF2, lineDelayDF("line_code_s_e1") === origDF2("line_code"))
          .filter(r => {
              val src_stop_tm: Double = r.getAs[String]("src_stop_tm").toDouble
              val max_actual_time_cost: Double = r.getAs[Double]("max_actual_time_cost")
              if (src_stop_tm > max_actual_time_cost) true else false
          })
          .drop("line_code", "max_actual_time_cost")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, longDF, "长线压缩时间的线路")
        testDF2Hive(logger, longDF, "dm_gis.long_compress_time_ok_data")

        longDF
    }

    // 获取更换车型合理的线路
    def getChangeTypeLine(spark: SparkSession, shortDF: Dataset[Row], longDF: Dataset[Row], longDF2: Dataset[Row]): (Dataset[Row], Dataset[Row]) = {
        import spark.implicits._

        val changeDF: DataFrame = shortDF
          .union(longDF)
          .union(longDF2)
          .withColumn("plan_arrive_tm", getArriveTime2($"plan_depart_tm", $"src_dest_tm"))
          .withColumn("time_diff", getTimeDiff($"plan_arrive_tm", $"plan_arrive_tm_s_e2"))
          .withColumn("line_distance_diff", $"d_dist".cast("double") / 1000 - $"line_distance_s_e2".cast("double"))
          .withColumn("load_bweight_avg_sum", $"load_bweight_avg_s_e1".cast("double") + $"load_bweight_avg_s_e2".cast("double"))
          .withColumn("load_rate_sum_before", $"load_bweight_avg_sum" / $"full_load_weight_s_e2".cast("double"))
          .withColumn("change_type", getMaxCarType($"load_bweight_avg_sum", $"capacityload_s_e2", $"load_rate_sum_before"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, changeDF, "更换车型的线路数据")

        val changeTypeDF: Dataset[Row] = changeDF
          .filter(isLegitimate($"change_type", $"capacityload_s_e2"))
          .persist(StorageLevel.MEMORY_AND_DISK)

        val noChangeTypeDF: Dataset[Row] = changeDF
          .filter("change_type=0.0 and running_mod_s_e1='单边'")
          .persist(StorageLevel.MEMORY_AND_DISK)

        testDF2Hive(logger, noChangeTypeDF, "dm_gis.stop_line_optimize_notchange_data")
        GetDFCountAndSampleData(logger, noChangeTypeDF, "不需要更换车型的线路数据")

        GetDFCountAndSampleData(logger, changeTypeDF, "更换车型合理的线路数据")
        testDF2Hive(logger, changeTypeDF, "dm_gis.change_type_result_data")

        (changeTypeDF, noChangeTypeDF)
    }

    // 获取下一个月线路状态情况
    def getNextMonthLineStatus(spark: SparkSession, yesterday: String, next_month_start: String, next_month_end: String): Dataset[Row] = {

        val origSql: String =
            s"""
               |select
               |  line_code,
               |  plan_run_dt
               |from
               |  (
               |    select
               |      line_code,
               |	  plan_run_dt,
               |      row_number() over(partition by line_code order by plan_run_dt desc) as rn
               |    from
               |      dm_pass_rss.scha_tt_plan_main_pro
               |    where
               |      inc_day = '$yesterday'
               |      and regexp_replace(cast(plan_run_dt as string), '-', '') >= '$next_month_start'
               |      and regexp_replace(cast(plan_run_dt as string), '-', '') <= '$next_month_end'
               |      and oper_type != 3
               |      and transport_level = 3
               |  ) t
               |where
               |  t.rn = 1
               |""".stripMargin

        val nextDF: DataFrame = getDataFrame(logger, spark, origSql)
        nextDF
    }

    // 获取最终的线路数据(未去重)
    def getresultLine1(spark: SparkSession, changeTypeDF: Dataset[Row], flag: Int = 1): Unit = {
        import spark.implicits._

        val changeTypeDF1: Dataset[Row] = changeTypeDF
          .filter("change_type = 0.0 and capacityload_s_e2 =capacityload_s_e1")
          .withColumn("dist_src_stop", lit("0"))

        val changeTypeDF2: DataFrame = changeTypeDF
          .filter("change_type != 0.0")
          .withColumn("cc", concat_ws(";", $"change_type", $"capacityload_s_e2"))
          .repartition(10)
          .withColumn("ssdt", getDistAndTime($"src_longitude_s_e1", $"src_latitude_s_e1",
              $"dest_longitude_s_e1", $"dest_latitude_s_e1", $"dest_longitude_s_e2", $"dest_latitude_s_e2",
              $"plan_depart_tm", $"src_stop_tm", $"stop_time", $"cc"))
          .withColumn("dt1", $"ssdt"(0))
          .withColumn("dist_src_stop", $"dt1._1")
          .withColumn("src_stop_tm", $"dt1._2")
          .withColumn("dt2", $"ssdt"(1))
          .withColumn("d_dist", $"dt1._1")
          .withColumn("time_e1_e2", $"dt1._2")
          .drop("ssdt", "dt1", "dt2", "cc")
          .filter(r => {
              val plan_depart_tm: Long = getTimestamp(r.getAs[String]("plan_depart_tm"), "yyyy-MM-dd HH:mm:ss")
              val src_stop_tm: Long = r.getAs[String]("src_stop_tm").toLong * 60 * 1000
              val latest_arrival_tm_s_e1: Long = getTimestamp(r.getAs[String]("latest_arrival_tm_s_e1"), "yyyy-MM-dd HH:mm:ss")
              val stop_time: Long = r.getAs[String]("stop_time").toLong
              val time_e1_e2: Long = r.getAs[String]("time_e1_e2").toLong * 60 * 1000
              val latest_arrival_tm_s_e2: Long = getTimestamp(r.getAs[String]("latest_arrival_tm_s_e2"), "yyyy-MM-dd HH:mm:ss")

              if (plan_depart_tm + src_stop_tm < latest_arrival_tm_s_e1 && plan_depart_tm + src_stop_tm + stop_time + time_e1_e2 < latest_arrival_tm_s_e2) true else false
          })
          .withColumn("src_dest_tm", $"src_stop_tm".cast("double") + $"stop_time".cast("double") / (1000 * 60) + $"time_e1_e2".cast("double"))

        val changeTypeDF3: Dataset[Row] = changeTypeDF
          .filter("change_type = 0.0 and capacityload_s_e2 !=capacityload_s_e1")
          .withColumn("cc", concat_ws(";", $"change_type", $"capacityload_s_e2"))
          .repartition(10)
          .withColumn("ssdt", getDistAndTime($"src_longitude_s_e1", $"src_latitude_s_e1",
              $"dest_longitude_s_e1", $"dest_latitude_s_e1", $"dest_longitude_s_e2", $"dest_latitude_s_e2",
              $"plan_depart_tm", $"src_stop_tm", $"stop_time", $"cc"))
          .withColumn("dt1", $"ssdt"(0))
          .withColumn("dist_src_stop", $"dt1._1")
          .withColumn("src_stop_tm", $"dt1._2")
          .drop("ssdt", "dt1", "cc")
          .filter(r => {
              val plan_depart_tm: Long = getTimestamp(r.getAs[String]("plan_depart_tm"), "yyyy-MM-dd HH:mm:ss")
              val src_stop_tm: Long = r.getAs[String]("src_stop_tm").toLong * 60 * 1000
              val latest_arrival_tm_s_e1: Long = getTimestamp(r.getAs[String]("latest_arrival_tm_s_e1"), "yyyy-MM-dd HH:mm:ss")
              val stop_time: Long = r.getAs[String]("stop_time").toLong
              val time_e1_e2: Long = r.getAs[String]("time_e1_e2").toLong * 60 * 1000
              val latest_arrival_tm_s_e2: Long = getTimestamp(r.getAs[String]("latest_arrival_tm_s_e2"), "yyyy-MM-dd HH:mm:ss")

              if (plan_depart_tm + src_stop_tm < latest_arrival_tm_s_e1 && plan_depart_tm + src_stop_tm + stop_time + time_e1_e2 < latest_arrival_tm_s_e2) true else false
          })

        val resultDF1: DataFrame = changeTypeDF1
          .union(changeTypeDF2)
          .union(changeTypeDF3)
          .filter("load_rate_proportion_now_s_e1 <= '0.5' and load_rate_proportion_now_s_e2 <='0.5' and load_rate_proportion_3_s_e1 <= '0.5'" +
            "and load_rate_proportion_3_s_e2<='0.5' and load_rate_proportion_6_s_e1<='0.5' and load_rate_proportion_6_s_e2<='0.5' and load_rate_proportion_last_s_e1<='0.5'" +
            "and load_rate_proportion_last_s_e2<='0.5'")
          .withColumn("plan_arrive_tm", getArriveTime2($"plan_depart_tm", $"src_dest_tm"))
          .withColumn("time_diff", getTimeDiff($"plan_arrive_tm", $"plan_arrive_tm_s_e2"))
          .withColumn("line_distance_diff", $"dist_src_stop".cast("double") / 1000 + $"d_dist".cast("double") / 1000 - $"line_distance_s_e1".cast("double") - $"line_distance_s_e2".cast("double"))
          .withColumn("stop_plan_depart_tm", getFomatDate($"stop_plan_depart_tm"))
          .withColumn("stop_time", ($"stop_time".cast("int") / 60000).cast("string"))
          .withColumn("d_dist", ($"d_dist".cast("double") / 1000).cast("string"))
          .withColumn("dist_src_stop", ($"dist_src_stop".cast("double") / 1000).cast("string"))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, resultDF1, "最终的结果数据")

        if (flag == 1) testDF2Hive(logger, resultDF1, "dm_gis.stop_line_deliver_optimize_data") else testDF2Hive(logger, resultDF1, "dm_gis.stop_line_deliver_optimize_nochange_data")

        resultDF1.unpersist()
    }

    // 获取最终的线路数据(去重之后的数据)
    def getDuplicatesResultLine2(spark: SparkSession, resultDF1: Dataset[Row], flag: Int = 1): Dataset[Row] = {
        import spark.implicits._

        val w2: WindowSpec = Window.partitionBy("line_code_s_e2").orderBy($"d_dist")
        val w1: WindowSpec = Window.partitionBy("line_code_s_e1").orderBy($"d_dist")

        val resultDF2: Dataset[Row] = resultDF1
          .withColumn("r1", row_number().over(w2))
          .filter("r1 =1")
          .withColumn("r2", row_number().over(w1))
          .filter("r2 =1")
          .drop("r1", "r2")
          .persist(StorageLevel.MEMORY_AND_DISK)

        resultDF2.count()

        val resultDF3: Dataset[Row] = resultDF1
          .join(resultDF2, resultDF1("line_code_s_e2") === resultDF2("line_code_s_e2"), "leftanti")
          .join(resultDF2, resultDF1("line_code_s_e1") === resultDF2("line_code_s_e1"), "leftanti")
          .withColumn("r1", row_number().over(w2))
          .filter("r1 =1")
          .drop("r1")
          .dropDuplicates("line_code_s_e1")

        val resultDF4: Dataset[Row] = resultDF2.union(resultDF3).persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, resultDF4, "去重后的最终数据")

        if (flag == 1) testDF2Hive(logger, resultDF4, "dm_gis.stop_line_deliver_optimize_drop_duplicates_data") else testDF2Hive(logger, resultDF4, "dm_gis.stop_line_deliver_optimize_nochange_drop_duplicates_data")

        resultDF4
    }

    // 获取最终的线路数据(下个月仍在运行的数据)
    def getresultLine3(spark: SparkSession, resultDF2: Dataset[Row], nextDF: Dataset[Row], inc_day: String, flag: Int = 1): Unit = {
        import spark.implicits._

        val resultDF3: DataFrame = resultDF2
          .join(nextDF, $"line_code_s_e1" === $"line_code")
          .withColumnRenamed("plan_run_dt", "plan_run_dt_s_e1")
          .drop("line_code")
          .join(nextDF, $"line_code_s_e2" === $"line_code")
          .withColumnRenamed("plan_run_dt", "plan_run_dt_s_e2")
          .drop("line_code", "inc_day")
          .withColumn("inc_day", lit(inc_day))
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, resultDF3, "下个月仍在运行的最终数据")
        if (flag == 1) df2HiveByOverwrite(logger, resultDF3, "dm_gis.stop_line_deliver_optimize_next_data") else df2HiveByOverwrite(logger, resultDF3, "dm_gis.stop_line_deliver_optimize_nochange_next_data")
    }

}
