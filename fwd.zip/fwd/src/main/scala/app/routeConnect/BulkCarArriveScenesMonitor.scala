package app.routeConnect

import com.alibaba.fastjson._
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools._
import utils.SparkConfigUtil

import scala.collection.mutable
import scala.util.control.Breaks.{break, breakable}
import scala.util.matching.Regex

/**
  * 任务名称：【集货】场景线路执行监控
  * 任务ID：461151
  * 需求人员：矫悦 01404184
  * 开发人员：王冬冬 01413698
  */
object BulkCarArriveScenesMonitor {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {

        if (args.length != 2) {
            logger.error(
                """
                  |需要输入2个参数：
                  |    yesterday、now
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val yesterday: String = args(0)
        val now: String = args(1)
        logger.error(s"昨天的日期：$yesterday")
        logger.error(s"今天的日期：$now")

        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        val inc_day: String = getIncday(spark)
        val start_time: String = getFirstDayofMonthBeforeOrAfter(inc_day, 0)
        val start_time2: String = getFirstDayofMonthBeforeOrAfter(inc_day, -1)
        val end_time: String = getLastDayofMonthBeforeOrAfter(inc_day, 1)

        // 获取 线路输出数据、计划日需数据、历史运力数据
        val (optRDD1, optRDD2, planDF, hisDF, optDF) = getOptPlanHisData(spark, start_time, start_time2, end_time, yesterday, inc_day)
        // 广播 计划日需数据、历史运力数据
        val (planArrBC, hisArrBC) = broadcastPlanHis(spark, planDF, hisDF)
        // 取消线路处理逻辑
        val cancelDF: DataFrame = getCancelLine(spark, optRDD1, planArrBC, hisArrBC, inc_day, yesterday,now)
        // 保留线路逻辑处理
        val keepDF: DataFrame = getKeepLine(spark, optRDD2, planArrBC, hisArrBC, inc_day, yesterday)
        // 取消线路 保留线路 关联回原始数据
        getcancelAndKeepResultLine(spark, optDF, cancelDF, keepDF)


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()
    }

    // 获取inc_day
    def getIncday(spark: SparkSession): String = {
        var inc_day: String = ""

        val sql: String =
            """
              |select
              |  max(inc_day) as inc_day
              |from
              |  dm_gis.stop_line_deliver_optimize_nochange_next_data
              |""".stripMargin
        spark.sql(sql).collect().foreach(r => inc_day = r.getAs[String]("inc_day"))
        inc_day
    }

    // 获取 计划需求数据、历史运力数据、输出线路数据
    def getOptPlanHisData(spark: SparkSession, start_time: String, start_time2: String, end_time: String, yesterday: String, inc_day: String): (RDD[JSONObject],RDD[JSONObject], DataFrame, DataFrame,DataFrame) = {
        val dlr: String = "$"
        val planSql: String =
            s"""
               |select
               |  line_code,
               |  planning_main_id,
               |  oper_type,
               |  has_pass,
               |  plan_run_dt,
               |  pass_codes,
               |  src_upper_dept_code,
               |  distribution_type,
               |  edit_reason,
               |  reverse(substring(reverse(line_code),5,20))  as line_code2
               |from
               |  dm_pass_rss.scha_tt_plan_main_pro
               |where
               |  inc_day = '$yesterday'
               |  and regexp_replace(cast(plan_run_dt as string), '-', '') >= '$start_time'
               |  and regexp_replace(cast(plan_run_dt as string), '-', '') <= '$end_time'
               |  and transport_level = 3
               |  and oper_type != 3
               |  and has_pass = 1
               |""".stripMargin
        val optSql: String =
            s"""
               |select
               |  *,
               |  reverse(substring(reverse(line_code_s2_e),5,20))  as line_code_s2_e2,
               |  reverse(substring(reverse(line_code_s1_e),5,20))  as line_code_s1_e2
               |from
               |  dm_gis.stop_line_deliver_optimize_nochange_next_data2
               |where
               |  inc_day='$inc_day'
               |""".stripMargin
        val historySql: String =
            s"""
               |select
               |  t1.line_code,
               |  t1.plan_depart_tm,
               |  t1.car_status
               |from
               |(
               |	select
               |       line_code,
               |       plan_depart_tm,
               |       car_status,
               |       src_zone_code,
               |       dest_zone_code
               |	from
               |	  dm_ops.pass_forecast_road_convy_monitor_dtl
               |    where
               |      substr(src_zone_code, 1, 1) not in ('s', 'p', 'm')
               |      and substr(dest_zone_code, 1, 1) not in ('s', 'p', 'm')
               |      and regexp_replace(translate(lower(src_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |      and regexp_replace(translate(lower(dest_zone_code),'abcdefghijklmnopqrstuvwxyz',repeat('$dlr', 26)),'\\$dlr','') not in ('852', '853', '886')
               |      and src_zone_code != ''
               |      and dest_zone_code != ''
               |      and transoport_level = '三级运输'
               |      and vehicle != '虚拟车'
               |      and src_zone_code != dest_zone_code
               |      and inc_day >= '$start_time2'
               |      and inc_day <= '$end_time'
               |  ) t1
               |  join (
               |    select
               |      dept_code,
               |      dept_transfer_flag
               |    from
               |      dim.dim_department
               |  ) t2 on t1.src_zone_code = t2.dept_code
               |  join (
               |    select
               |      dept_code,
               |      dept_transfer_flag
               |    from
               |      dim.dim_department
               |  ) t3 on t1.dest_zone_code = t3.dept_code
               |where
               |  t2.dept_transfer_flag = '1'
               |  and t3.dept_transfer_flag = '0'
               |""".stripMargin

        // 输出线路数据
        val optDF: DataFrame = getDataFrame(logger, spark, optSql,"输出线路数据")
        // 计划需求数据
        val planDF: DataFrame = getDataFrame(logger, spark, planSql,"计划需求数据")
        // 历史运力数据
        val hisDF: DataFrame = getDataFrame(logger, spark, historySql,"历史运力数据")

        val planDF1: DataFrame = planDF
          .groupBy("line_code")
          .agg(
              concat_ws(",", collect_set("planning_main_id")).as("planning_main_id_list")
          )

        val planDF2: DataFrame = planDF
          .groupBy("line_code2")
          .agg(
              concat_ws(",", collect_set("planning_main_id")).as("planning_main_id_list2")
          )

        val optRDD1: RDD[JSONObject] = optDF
          .join(planDF1, planDF1("line_code") === optDF("line_code_s2_e"))
          .join(planDF2, planDF2("line_code2") === optDF("line_code_s2_e2"))
          .filter("planning_main_id_list is not null and planning_main_id_list != ''")
          .rdd
          .map(row2Json)
          .repartition(300)
          .cache()

        val optRDD2: RDD[JSONObject] = optDF
          .join(planDF1, planDF1("line_code") === optDF("line_code_s1_e"))
          .join(planDF2, planDF2("line_code2") === optDF("line_code_s1_e2"))
          .filter("planning_main_id_list is not null and planning_main_id_list != ''")
          .rdd
          .map(row2Json)
          .repartition(300)
          .cache()

        logger.error("取消线路optRDD1 数据量" + optRDD1.count())
        logger.error("保留线路optRDD2 数据量:" + optRDD2.count())

        (optRDD1, optRDD2, planDF, hisDF, optDF)
    }

    // 广播 历史运力数据、计划日需数据
    def broadcastPlanHis(spark: SparkSession, planDF: DataFrame, hisDF: DataFrame): (Broadcast[Array[Row]], Broadcast[Array[Row]]) = {
        logger.error("开始拉取【计划需求数据】到driver！")
        val planArrtmp: Array[Row] = planDF.collect()
        logger.error("数据拉取完毕，开始广播数据到workNode！")
        val planArrBC: Broadcast[Array[Row]] = spark.sparkContext.broadcast(planArrtmp)
        logger.error("【计划需求数据】广播完毕！")

        logger.error("开始拉取【历史运力数据】到driver！")
        val hisArrtmp: Array[Row] = hisDF.collect()
        logger.error("数据拉取完毕，开始广播数据到workNode！")
        val hisArrBC: Broadcast[Array[Row]] = spark.sparkContext.broadcast(hisArrtmp)
        logger.error("【历史运力数据】广播完毕！")
        (planArrBC, hisArrBC)
    }

    // 判断是否有串点(0:表示 没有串点   1:表示有串点)
    def isSerialPoint(planArr: Array[JSONObject], id: Long, inc_day: String): (Int, JSONObject, JSONObject) = {
        val planArr2: Array[JSONObject] = planArr.filter(_.getLongValue("planning_main_id") == id)

        // flag:0 表示 没有串点   1 表示有串点
        var flag: Int = 0
        var head: JSONObject = null
        var last: JSONObject = null
        if (planArr2.nonEmpty) {
            val planArr3: Array[JSONObject] = planArr2
              .sortBy(_.getString("plan_run_dt"))

            val headObj: JSONObject = planArr3.head
            val lastObj: JSONObject = planArr3.last

            val plan_run_dt: String = headObj.getString("plan_run_dt").replaceAll("-", "")
            if (plan_run_dt >= inc_day) {
                flag = 1
                head = headObj
                last = lastObj
            }
        }

        (flag, head, last)
    }

    // 串点的网点是否包含 src_zone_code_s1_e
    def iscontainsDestCode(o: JSONObject, pass_codes: String, logger: Logger, id: Long, line_code: String): Unit = {
        if (!isEmptyOrNull(pass_codes)) {
            val codeArr: Array[String] = pass_codes.split(",")
            val src_zone_code_s1_e: String = o.getString("src_zone_code_s1_e")

            // 串点的网点是否包含 src_zone_code_s1_e
            if (codeArr.contains(src_zone_code_s1_e)) {
                o.put("tag2", 3)
                logger.error(s"line_code:$line_code,id:$id 满足【串点的网点包含】条件:tag2 = 3 中断本轮循环！")
                break()
            } else {
                o.put("tag2", 4)
                logger.error(s"line_code:$line_code,id:$id 不满足【串点的网点包含】条件:tag2 = 4,进入下个 id 进行循环！")
            }
        }
    }

    // 串点的网点是否包含 src_zone_code_s2_e
    def iscontainsDestCode2(o: JSONObject, pass_codes: String, logger: Logger, id: Long, line_code: String): Unit = {
        if (!isEmptyOrNull(pass_codes)) {
            val codeArr: Array[String] = pass_codes.split(",")
            val src_zone_code_s2_e: String = o.getString("src_zone_code_s2_e")

            // 串点的网点是否包含 src_zone_code_s2_e
            if (codeArr.contains(src_zone_code_s2_e)) {
                o.put("tag1", 1)
                logger.error(s"line_code:$line_code,id:$id 满足【串点的网点包含】条件:tag1 = 1 中断本轮循环！")
                break()
            } else {
                o.put("tag1", 2)
                logger.error(s"line_code:$line_code,id:$id 不满足【串点的网点包含】条件:tag1 = 2,进入下个 id 进行循环！")
            }
        }
    }

    // 串点的处理逻辑
    def dealSerialPoint(o: JSONObject, logger: Logger, ids2: Array[Long], planArr: Array[JSONObject], inc_day: String): Int = {
        //(0:表示 没有串点   1:表示有串点)
        var pointFlag2: Int = 0

        val line_code: String = o.getString("line_code")
        breakable(
            for (k <- ids2.indices) {
                val id: Long = ids2(k)
                logger.error(s"line_code:$line_code,第${k + 1}次循环,id:$id")
                val (i, head, last) = isSerialPoint(planArr, id, inc_day)

                // 某条线路存在串点的情况
                if (i == 1) {
                    pointFlag2 = 1
                    val pass_codes: String = head.getString("pass_codes")
                    o.put("line_code_2_stop", pass_codes)
                    o.put("line_code_2_keep", head.getString("line_code"))
                    val plan_run_dt: String = head.getString("plan_run_dt")
                    o.put("start_stop_tm_2", plan_run_dt)

                    if (plan_run_dt <= getNowTime3) o.put("end_stop_tm_2", getNowTime3) else o.put("end_stop_tm_2", last.getString("plan_run_dt"))

                    // 判断串点的网点是否包含 src_zone_code_s1_e
                    iscontainsDestCode(o, pass_codes, logger, id, line_code)

                } // 不存在串点的情况
                else logger.error(s"line_code:$line_code,id:$id 不满足【是否串点】条件,进入下个id进行循环！")
            }
        )

        pointFlag2
    }

    // 串点的处理逻辑
    def dealSerialPoint2(o: JSONObject, logger: Logger, ids2: Array[Long], planArr: Array[JSONObject], inc_day: String): Int = {
        //(0:表示 没有串点   1:表示有串点)
        var pointFlag2: Int = 0

        val line_code: String = o.getString("line_code")
        breakable(
            for (k <- ids2.indices) {
                val id: Long = ids2(k)
                logger.error(s"line_code:$line_code,第${k + 1}次循环,id:$id")
                val (i, head, last) = isSerialPoint(planArr, id, inc_day)

                // 某条线路存在串点的情况
                if (i == 1) {
                    pointFlag2 = 1
                    val pass_codes: String = head.getString("pass_codes")
                    o.put("line_code_1_stop", pass_codes)
                    o.put("line_code_1_keep", head.getString("line_code"))
                    val plan_run_dt: String = head.getString("plan_run_dt")
                    o.put("start_stop_tm_1", plan_run_dt)

                    if (plan_run_dt <= getNowTime3) o.put("end_stop_tm_1", getNowTime3) else o.put("end_stop_tm_1", last.getString("plan_run_dt"))

                    // 判断串点的网点是否包含 src_zone_code_s2_e
                    iscontainsDestCode2(o, pass_codes, logger, id, line_code)

                } // 不存在串点的情况
                else logger.error(s"line_code:$line_code,id:$id 不满足【是否串点】条件,进入下个id进行循环！")
            }
        )

        pointFlag2
    }

    // 建议取消班次是否被停用
    def bacthDisabl(hisArr: Array[JSONObject], o: JSONObject, yesterday: String): Int = {

        var flag3: Int = 0 // 0:未停用  1：停用

        val line_code: String = o.getString("line_code")

        val hisArr2: Array[JSONObject] = hisArr
          .filter(_.getString("line_code") == line_code)

        if (hisArr2.nonEmpty) {
            val hisObj: JSONObject = hisArr2.maxBy(_.getString("plan_depart_tm"))

            val car_status: String = hisObj.getString("car_status")
            val plan_depart_tm: String = hisObj.getString("plan_depart_tm")

            val plan_depart_tm2: String = plan_depart_tm.split(" ")(0).replaceAll("-", "")
            if (car_status == "取消" || (car_status == "已完成" && plan_depart_tm2 < yesterday)) {
                o.put("last_done_time", plan_depart_tm)
                flag3 = 1
            }
        } else flag3 = 1


        flag3
    }

    // 建议取消班次是否被停用
    def bacthDisabl(planArr2: Array[JSONObject], o: JSONObject, ids: Array[String]): (String, String, String) = {

        val line_code_set = new mutable.HashSet[String]()
        val start_tm_set = new mutable.HashSet[String]()
        val end_tm_set = new mutable.HashSet[String]()

        try {
            for (id <- ids) {
                val lineMin: JSONObject = planArr2
                  .filter(_.getString("planning_main_id") == id)
                  .minBy(_.getString("plan_run_dt"))

                val lineMax: JSONObject = planArr2
                  .filter(_.getString("planning_main_id") == id)
                  .maxBy(_.getString("plan_run_dt"))

                val last_done_time: String = o.getString("last_done_time")
                val dest_zone_code: String = o.getString("dest_zone_code")

                val line_code: String = lineMin.getString("line_code")
                val plan_run_dt_min: String = lineMin.getString("plan_run_dt")
                val distribution_type: String = lineMin.getString("distribution_type")
                val dest_upper_dept_code: String = lineMin.getString("dest_upper_dept_code")
                var plan_run_dt_max: String = lineMax.getString("plan_run_dt")
                plan_run_dt_max = if (plan_run_dt_max >= getNowTime3) getNowTime3 else plan_run_dt_max

                if (plan_run_dt_min >= last_done_time && distribution_type == "1" && dest_upper_dept_code == dest_zone_code) {
                    line_code_set.add(line_code)
                    start_tm_set.add(plan_run_dt_min)
                    end_tm_set.add(plan_run_dt_max)
                }
            }
        } catch {
            case e: Exception => println(e.getMessage)
        }

        (line_code_set.mkString(","), start_tm_set.mkString(","), end_tm_set.mkString(","))
    }

    // 是否搬迁
    def isMove(planArr: Array[JSONObject], o: JSONObject): Boolean = {
        val line_code: String = o.getString("line_code")

        val b: Boolean = planArr
          .filter(_.getString("line_code") == line_code)
          .map(o => {
              val p1: Regex = new Regex("搬迁")
              val p2: Regex = new Regex("变迁")
              val edit_reason: String = o.getString("edit_reason")

              val s1: String = p1.findFirstIn(edit_reason).getOrElse("1")
              val s2: String = p2.findFirstIn(edit_reason).getOrElse("2")

              if (s1 == "1" && s2 == "2") 10 else 20
          })
          .contains(20)

        b
    }

    // 取消线路最终数据
    def getCancelLine(spark: SparkSession, optRDD1: RDD[JSONObject], planArrBC: Broadcast[Array[Row]], hisArrBC: Broadcast[Array[Row]], inc_day: String, yesterday: String,now:String): DataFrame = {
        import spark.implicits._

        val cancelDF: DataFrame = optRDD1
          .map(o => {
              val planArr: Array[JSONObject] = planArrBC.value.map(row2Json)

              val line_code: String = o.getString("line_code")
              val planning_main_id_list: String = o.getString("planning_main_id_list")

              var pointFlag: Int = 0 //pointFlag = 0 表示不存在串点
              val ids: Array[Long] = planning_main_id_list.split(",").map(_.toLong)
              logger.error(s"line_code:$line_code,ids:$planning_main_id_list")

              // 判断 某条线路是否有串点 pointFlag = 0 表示不存在串点
              pointFlag = dealSerialPoint(o, logger, ids, planArr, inc_day)
              logger.error("*******************************************************************")
              if (pointFlag == 0) {
                  logger.error(s"line_code:$line_code,所有的 id 都不存在串点,进入【同向线路】是否有串点环节！")
                  val planning_main_id_list2: String = o.getString("planning_main_id_list2")

                  var pointFlag2: Int = 0 //pointFlag = 0 表示不存在串点
                  if (!isEmptyOrNull(planning_main_id_list2)) {
                      val ids2: Array[Long] = planning_main_id_list2.split(",").map(_.toLong)
                      logger.error(s"line_code:$line_code,ids2:$planning_main_id_list2")

                      pointFlag2 = dealSerialPoint(o, logger, ids2, planArr, inc_day)
                      logger.error("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
                  }


                  if (pointFlag2 == 0) {
                      logger.error(s"line_code:$line_code,所有的 id 都不存在【同向线路】串点,进入【班次是否停用】环节！")

                      val hisArr: Array[JSONObject] = hisArrBC.value.map(row2Json)
                      val flag3: Int = bacthDisabl(hisArr, o, yesterday)

                      if (flag3 == 1) {
                          logger.error(s"line_code:$line_code,【建议取消班次】已经停用,进入【是否被其他线路经停】环节！")

                          val src_zone_code_s2_e: String = o.getString("src_zone_code_s2_e")
                          val planArr2: Array[JSONObject] = planArr.filter(o => {
                              val pass_codes: String = o.getString("pass_codes")
                              val oper_type: String = o.getString("oper_type")
                              if (!isEmptyOrNull(pass_codes) && pass_codes.split(",").contains(src_zone_code_s2_e) && oper_type != "3") true else false
                          })

                          val ids: Array[String] = planArr2.map(_.getString("planning_main_id")).distinct

                          if (ids.nonEmpty) {
                              val (line_code_keep, start_tm, end_tm) = bacthDisabl(planArr2, o, ids)
                              o.put("line_code_2_keep", line_code_keep)
                              o.put("start_tm2", start_tm)
                              o.put("end_tm2", end_tm)

                              if (!isEmptyOrNull(line_code_keep)) o.put("tag2", 6)

                          } else {
                              val b:Boolean = isMove(planArr, o)
                              if (b) o.put("tag2", 7) else o.put("tag2", 10)
                          }


                      } else {
                          val update_time: String = o.getString("update_time")
                          val arr: Array[String] = update_time.split("/")
                          for (i <- arr.indices) if (arr(i).length == 1) arr(i) = "0" + arr(i)
                          val update_time2: String = arr.mkString

                          if (now < update_time2) o.put("tag2", "8") else o.put("tag2", "9")
                      }
                  }

              }

              logger.error("===================================================================\n")

              val tag2: String = o.getString("tag2")
              val line_code_2_stop: String = o.getString("line_code_2_stop")
              val start_stop_tm_2: String = o.getString("start_stop_tm_2")
              val end_stop_tm_2: String = o.getString("end_stop_tm_2")
              val last_done_time: String = o.getString("last_done_time")
              val line_code_2_keep: String = o.getString("line_code_2_keep")
              val start_tm2: String = o.getString("start_tm2")
              val end_tm2: String = o.getString("end_tm2")

              (line_code, tag2, line_code_2_stop, start_stop_tm_2, end_stop_tm_2, last_done_time, line_code_2_keep, start_tm2, end_tm2)
          })
          .toDF("line_code1", "tag2", "line_code_2_stop", "start_stop_tm_2",
              "end_stop_tm_2", "last_done_time1", "line_code_2_keep", "start_tm2", "end_tm2")
          .cache()

        GetDFCountAndSampleData(logger, cancelDF, "取消线路最终数据")

        cancelDF
    }

    // 保留线路最终数据
    def getKeepLine(spark: SparkSession, optRDD2: RDD[JSONObject], planArrBC: Broadcast[Array[Row]], hisArrBC: Broadcast[Array[Row]], inc_day: String, yesterday: String): DataFrame = {
        import spark.implicits._

        val keepDF: DataFrame = optRDD2
          .map(o => {
              val planArr: Array[JSONObject] = planArrBC.value.map(row2Json)

              val line_code: String = o.getString("line_code")
              val planning_main_id_list: String = o.getString("planning_main_id_list")

              var pointFlag: Int = 0 //pointFlag = 0 表示不存在串点
              val ids: Array[Long] = planning_main_id_list.split(",").map(_.toLong)
              logger.error(s"line_code:$line_code,ids:$planning_main_id_list")

              // 判断 某条线路是否有串点 pointFlag = 0 表示不存在串点
              pointFlag = dealSerialPoint2(o, logger, ids, planArr, inc_day)
              logger.error("*******************************************************************")
              if (pointFlag == 0) {
                  logger.error(s"line_code:$line_code,所有的 id 都不存在串点,进入【同向线路】是否有串点环节！")
                  val planning_main_id_list2: String = o.getString("planning_main_id_list2")

                  var pointFlag2: Int = 0 //pointFlag = 0 表示不存在串点
                  if (!isEmptyOrNull(planning_main_id_list2)) {
                      val ids2: Array[Long] = planning_main_id_list2.split(",").map(_.toLong)
                      logger.error(s"line_code:$line_code,ids2:$planning_main_id_list2")

                      pointFlag2 = dealSerialPoint2(o, logger, ids2, planArr, inc_day)
                      logger.error("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
                  }


                  if (pointFlag2 == 0) {
                      logger.error(s"line_code:$line_code,所有的 id 都不存在【同向线路】串点,进入【班次是否停用】环节！")

                      val hisArr: Array[JSONObject] = hisArrBC.value.map(row2Json)
                      val flag3: Int = bacthDisabl(hisArr, o, yesterday)

                      if (flag3 == 1) {
                          logger.error(s"line_code:$line_code,【建议取消班次】已经停用,进入【是否被其他线路经停】环节！")

                          val src_zone_code_s1_e: String = o.getString("src_zone_code_s1_e")
                          val planArr2: Array[JSONObject] = planArr.filter(o => {
                              val pass_codes: String = o.getString("pass_codes")
                              val oper_type: String = o.getString("oper_type")
                              if (!isEmptyOrNull(pass_codes) && pass_codes.split(",").contains(src_zone_code_s1_e) && oper_type != "3") true else false
                          })

                          val ids: Array[String] = planArr2.map(_.getString("planning_main_id")).distinct

                          if (ids.nonEmpty) {
                              val (line_code_keep, start_tm, end_tm) = bacthDisabl(planArr2, o, ids)
                              o.put("line_code_1_keep", line_code_keep)
                              o.put("start_tm1", start_tm)
                              o.put("end_tm1", end_tm)

                              if (!isEmptyOrNull(line_code_keep)) o.put("tag1", 5)

                          } else {
                              val b :Boolean = isMove(planArr, o)
                              if (b) o.put("tag1", 7) else o.put("tag1", 10)
                          }


                      } else o.put("tag1", "8或9")
                  }

              }

              logger.error("===================================================================\n")


              val tag1: String = o.getString("tag1")
              val line_code_1_stop: String = o.getString("line_code_1_stop")
              val start_stop_tm_1: String = o.getString("start_stop_tm_1")
              val end_stop_tm_1: String = o.getString("end_stop_tm_1")
              val last_done_time: String = o.getString("last_done_time")
              val line_code_1_keep: String = o.getString("line_code_1_keep")
              val start_tm1: String = o.getString("start_tm1")
              val end_tm1: String = o.getString("end_tm1")

              (line_code, tag1, line_code_1_stop, start_stop_tm_1, end_stop_tm_1, last_done_time, line_code_1_keep, start_tm1, end_tm1)
          })
          .toDF("line_code2", "tag1", "line_code_1_stop", "start_stop_tm_1",
              "end_stop_tm_1", "last_done_time2", "line_code_1_keep", "start_tm1", "end_tm1")
          .cache()

        GetDFCountAndSampleData(logger, keepDF, "保留线路最终数据")

        keepDF
    }

    // 取消线路、保留线路 关联回原始数据的最终数据
    def getcancelAndKeepResultLine(spark: SparkSession, optDF: DataFrame, cancelDF: DataFrame, keepDF: DataFrame): Unit = {
        import spark.implicits._

        val optResultDF: DataFrame = optDF
          .join(cancelDF, optDF("line_code_s2_e") === cancelDF("line_code1"), "left")
          .join(keepDF, optDF("line_code_s1_e") === keepDF("line_code2"), "left")
          .filter("line_code1 is not null or line_code2 is not null")
          .withColumn("tag", concat_ws(",", $"tag1", $"tag2"))
          .withColumn("incday",$"inc_day")
          .drop("line_code_s1_e1","line_code_s2_e2","line_code1","line_code2","inc_day")
          .withColumnRenamed("incday","inc_day")
          .coalesce(1)
          .cache()

        GetDFCountAndSampleData(logger, optResultDF, "取消+保留线路最终的线路数据")
        df2HiveByOverwrite(logger, optResultDF, "dm_gis.stop_line_deliver_optimize_nochange_cancel_keep_data2")
    }


}
