package entry

case class TaskRate(
                     task_area_code: String,
                     task_id: String,
                     vehicle_serial: String,
                     src_longitude: String,
                     src_latitude: String,
                     dest_longitude: String,
                     dest_latitude: String,
                     actual_depart_tm: String,
                     actual_arrive_tm: String,
                     plan_depart_tm: String,
                     plan_arrive_tm: String,
                     `type`: String,
                     time_threshold: String,
                     dis_threshold: String,
                     vir_dis: String,
                     real_dis: String,
                     track_rate: String,
                     inc_day: String
                   )

case class LineNavi(
                     task_id: String,
                     navi_id: String,
                     sdk_version: String,
                     req_id: String,
                     report_time: String,
                     navi_strategy: String,
                     is_return_sta_line: String,
                     is_navi_at_start: String,
                     is_navi_by_sta_line: String,
                     dest_dept_code: String,
                     route_time: String,
                     drive_time: String,
                     is_yaw_by_driver: String,
                     inc_day: String
                   )

case class TrackQuality(
                         ak: String,
                         un: String,
                         is_track_lose: String,
                         track_lose_time: Long,
                         is_re_upload:String,
                         tracks_cn:Int,
                         delay1min_tracks_cn:Int,
                         delay5min_tracks_cn:Int,
                         delay30min_tracks_cn:Int,
                         delay6h_tracks_cn:Int,
                         delay6hup_tracks_cn:Int,
                         drift_tracks_cn:Int,
                         tracks_start_time:String,
                         tracks_end_time:String,
                         upload_fre:Double,
                         inc_day: String
                   )