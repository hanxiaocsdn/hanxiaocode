package test

import java.sql.{Connection, PreparedStatement}

object CreateTableForMysql {

    def main(args: Array[String]): Unit = {

        // mysql的参数
//        val driver = "com.mysql.jdbc.Driver"
        val driver = "com.mysql.cj.jdbc.Driver"
        val url = "jdbc:mysql://naviqueryindex-m.db.sfcloud.local:3306/navi_index?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
        val userName = "navi_index"
        val passWd = "hs9x+nh8u"

        val sql:String="drop table gis_eta_pns_std_return_index"

        val sql1:String=
            """
              |create table gis_eta_pns_std_return_index(
              |  id varchar(255) not null primary key,
              |  start_dist varchar(255),
              |  task_area_code varchar(255),
              |  pull_navi_type int,
              |  distance varchar(255),
              |  stdrequest int,
              |  stdreturn int,
              |  top3_stdclick int,
              |  top3_click int,
              |  top3_strclick int,
              |  type9 int,
              |  type8 int,
              |  type2 int,
              |  type10 int,
              |  type5 int,
              |  type7 int,
              |  type4 int,
              |  type1 int,
              |  type6 int,
              |  type11 int,
              |  type12 int,
              |  type13 int,
              |  std_return varchar(10),
              |  stdclick varchar(10),
              |  click varchar(10),
              |  stdexit varchar(10),
              |  not_return9 varchar(10),
              |  not_return8 varchar(10),
              |  not_return2 varchar(10),
              |  not_return10 varchar(10),
              |  not_return5 varchar(10),
              |  not_return7 varchar(10),
              |  not_return4 varchar(10),
              |  not_return1 varchar(10),
              |  not_return6 varchar(10),
              |  not_return11 varchar(10),
              |  not_return12 varchar(10),
              |  not_return13 varchar(10),
              |  inc_day varchar(10)
              |) comment = '标准线路返回率指标明细表'
              |""".stripMargin

        Class.forName(driver)
        val connection: Connection = java.sql.DriverManager.getConnection(url, userName, passWd)
        val statement: PreparedStatement = connection.prepareStatement(sql)
        statement.execute()

        val statement1: PreparedStatement = connection.prepareStatement(sql1)
        statement1.execute()
    }
}
