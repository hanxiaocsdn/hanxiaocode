package test

import com.alibaba.fastjson._
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.mutable.ArrayBuffer
import scala.language.postfixOps


object akLimit {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")
    val track_url: String = config.getString("track_url")
    val ct_url: String = config.getString("ct_url")
    val qm_url3: String = config.getString("qm_url3")

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)


    def main(args: Array[String]): Unit = {


        //  创建spark
        //                val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        //  创建spark
        val spark: SparkSession = SparkSession
          .builder()
          .master("local[*]")
          .appName("MyTest")
          .getOrCreate()

        //  导入隐式转换


        val df: DataFrame = spark.createDataFrame(Seq(
            ("ming", 22, 15552211521L, false),
            ("hong", 19, 15552211521L, true),
            ("ming", 18, 13287994007L, false),
            ("ming", 19, 13287994007L, false),
            ("hong", 36, 13287994007L, true),
            ("hong", 19, 13287994007L, false),
            ("", 19, 13287994007L, false),
            (null, 19, 13287994007L, true),
            ("zhi", 10, 15552211523L, true)
        ))
          .toDF("name", "age", "phone", "is_rich")



        val rdd: RDD[String] = df
          .rdd
          .repartition(3)
          .mapPartitions(p => {

              val limitMin = 12
              var cnt = 0
              val obj: Iterator[String] = p.map(_ => {
                  var startTime: Long = System.currentTimeMillis()
                  if (cnt == limitMin) {
                      val endTime: Long = System.currentTimeMillis() - startTime
                      if (endTime <= 60 * 1000) {
                          logger.error(s"每分钟访问量超过限制$limitMin,休眠${60 * 1000 - endTime} ms中")
                          Thread.sleep(60 * 1000 - endTime)
                      }
                      startTime = System.currentTimeMillis()
                      cnt = 0
                  }

                  cnt += 1
                  getinter(cnt)
              })
              obj
          })

        rdd.count()







//        val limitMin = 12
//        var cnt = 0
//        for(i<- 1 to 30 ){
//            var startTime: Long = System.currentTimeMillis()
//            if ( cnt == limitMin  ) {
//                val endTime: Long = System.currentTimeMillis() - startTime
//                if( endTime <= 60 * 1000 ){
//                    logger.error( s"每分钟访问量超过限制$limitMin,休眠${60*1000 - endTime } ms中" )
//                    Thread.sleep(60*1000 - endTime )
//                }
//                startTime = System.currentTimeMillis()
//                cnt = 0
//            }
//
//            val o: JSONObject = getinter(cnt)
//
//            cnt += 1
//        }


















        logger.error("运行结束！")

    }


    def getPersonInfo: UserDefinedFunction = udf((name: String, sex: String, age: Int) => {
        val personArr = new ArrayBuffer[person]()
        personArr.append(person(name, sex, age + 1))
        personArr.append(person(name, sex, age + 2))
        personArr.append(person(name, sex, age + 3))

        logger.error(personArr.mkString(";"))
        personArr
    })

    def getPersonInfo3: UserDefinedFunction = udf((name: String, sex: String, age: Int) => {
        val personArr = new ArrayBuffer[(String, String, Int)]()
        personArr.append((name, sex, age + 1))
        personArr.append((name, sex, age + 2))
        personArr.append((name, sex, age + 3))

        logger.error(personArr.mkString(";"))
        personArr
    })


    case class person(name: String, sex: String, age: Int)


    def getinter(i:Int): String ={
        val o = new JSONObject()
        o.put(i+"",i)
        logger.error(s"第${i}次调接口")

        o.toJSONString
    }


    def getinter2(i:Int): (Int, Int) ={

        logger.error(s"第${i}次调接口")

        (i,i*10)
    }


}
