package test


import org.apache.spark.sql._
import org.apache.spark.sql.functions.lit
import org.slf4j.{Logger, LoggerFactory}
import utils.CommonTools.{df2HiveByOverwrite, getNowTime}
import utils.SparkConfigUtil


object AddCSVToHive {

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)

    def main(args: Array[String]): Unit = {


        // 接收外部传递进来的变量
        //        val UNIT_CSV_FILE_PATH: String = args(0)


        // 创建spark
        val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        //  创建spark
        //        val spark: SparkSession = SparkSession
        //          .builder()
        //          .master("local[*]")
        //          .appName("MyTest")
        //          .getOrCreate()


        // 获取csv文件数据
        val csvDS: Dataset[String] = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("sep", ",")
          .load("/user/01413698/upload/data/owner_contact.csv")
          //          .load("G:\\吨吨加油\\【粤运】业户联系方式(1).csv")
          .withColumn("inc_day", lit(getNowTime))
          .toJSON

        val csvDF: DataFrame = spark
          .read
          .json(csvDS)
          .select("owner_id", "owner_name", "linkman", "linkman_phone", "scope_business", "scope_details", "manger_name", "inc_day")






        // 写入hive表中
        //                df2HiveByAppend(logger,csvDF,"dm_gis.mms_car_route_aggre_data_issue_info")
        df2HiveByOverwrite(logger, csvDF, "dm_gis.yue_owner_link_info")


        // 程序结束 关闭spark
        spark.stop()

    }


}
