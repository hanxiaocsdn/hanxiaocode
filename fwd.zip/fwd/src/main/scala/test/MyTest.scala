package test


import com.alibaba.fastjson._
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.mutable.ArrayBuffer
import scala.language.postfixOps


object MyTest {

    // 初始化配置文件
    val config: Config = ConfigFactory.load()
    // 获取配置文件信息
    val qm_url: String = config.getString("qm_url")
    val track_url: String = config.getString("track_url")
    val ct_url: String = config.getString("ct_url")
    val qm_url3: String = config.getString("qm_url3")

    // 初始化
    val className: String = this.getClass.getSimpleName.stripSuffix("$")
    val logger: Logger = LoggerFactory.getLogger(className)


    def main(args: Array[String]): Unit = {

        // 接收外部传递进来的变量
        //        val UNIT_CSV_FILE_PATH: String = args(0)


        //  创建spark
        //                                val spark: SparkSession = SparkConfigUtil.initSparkConfig(className)

        //  创建spark
        val spark: SparkSession = SparkSession
          .builder()
          .master("local[*]")
          .appName("MyTest")
          .getOrCreate()

        //  导入隐式转换
        import spark.implicits._


        val df: DataFrame = spark.createDataFrame(Seq(
            ("ming", 22, 15552211521L, false),
            ("hong", 19, 15552211521L, true),
            ("ming", 18, 13287994007L, false),
            ("ming", 19, 13287994007L, false),
            ("hong", 36, 13287994007L, true),
            ("hong", 19, 13287994007L, false),
            ("", 19, 13287994007L, false),
            (null, 19, 13287994007L, true),
            ("zhi", 10, 15552211523L, true)
        ))
          .toDF("name", "age", "phone", "is_rich")

        val df2: DataFrame = spark.createDataFrame(Seq(
            ("ming", "男", 22),
            ("hong2", "女", 19),
            ("hong3", "女", 18)
        ))
          .toDF("name", "sex", "age")













        // 左表 和 右表 共同有的
        //                                df.join(df2, df("name")===df2("name"), "leftsemi").show()

        // 左表 独有的
        //                        df.join(df2, df("name")===df2("name"), "leftanti").show()
        //                        df.join(df2, Seq("age"), "leftanti").show()
        //                        df.join(df, $"age1" === $"age1", "leftanti").show()
        //
        //
        val df3: DataFrame = df2
          .withColumn("sex", lit("女"))
          .withColumn("person", explode(getPersonInfo22('name, 'sex, 'age)))
          .withColumn("name2", $"person._1")
          .withColumn("sex2", $"person._2")
          .withColumn("age2", $"person._3")
          .drop("person")
          .withColumn("inc_day", lit("20220927"))
        df3.show(false)


        logger.error("运行结束！")

    }


    def getPersonInfo: UserDefinedFunction = udf((name: String, sex: String, age: Int) => {
        val personArr = new ArrayBuffer[person]()
        personArr.append(person(name, sex, age + 1))
        personArr.append(person(name, sex, age + 2))
        personArr.append(person(name, sex, age + 3))

        logger.error(personArr.mkString(";"))
        personArr
    })

    def getPersonInfo2: UserDefinedFunction = udf((name: String, sex: String, age: Int) => {
        logger.error("11111111")
        (name, sex, age + 3)
    })

    def PersonInfo2: UserDefinedFunction = udf((age: Int) => {
        logger.error("11111111")
        age + 3
    })

    def getPersonInfo22: UserDefinedFunction = udf((name: String, sex: String, age: Int) => {
        logger.error("11111111")
        val arr = new Array[(String, String, Int)](1)
        arr(0) = (name, sex, age + 3)
        arr
    })

    def getPersonInfo222: UserDefinedFunction = udf((name: String, sex: String, age: Int) => {
        logger.error("11111111")
        age + 3
    })

    def getPersonInfo3: UserDefinedFunction = udf((name: String, sex: String, age: Int) => {
        val personArr = new ArrayBuffer[(String, String, Int)]()
        personArr.append((name, sex, age + 1))
        personArr.append((name, sex, age + 2))
        personArr.append((name, sex, age + 3))

        logger.error(personArr.mkString(";"))
        personArr
    })


    case class person(name: String, sex: String, age: Int)


    def getinter(i: Int): JSONObject = {
        val o = new JSONObject()
        o.put(i + "", i)
        logger.error(s"第${i}次调接口")

        o
    }


}
