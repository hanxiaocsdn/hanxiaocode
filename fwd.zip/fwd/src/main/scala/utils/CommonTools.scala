package utils

import com.alibaba.fastjson.JSONObject
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.xml.{NodeSeq, XML}

object CommonTools {
  val className: String = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)

  // 判断 某个字符串是否为空或者null
  def isEmptyOrNull(str: String): Boolean = {
    var flag: Boolean = false
    if (str == null) flag = true
    else if (str.isEmpty) flag = true
    flag
  }

  ///给定一个包含XML的字符串，解析字符串获取version
  def getVersion(xmlstring: String): String = {
    var nodes: NodeSeq = XML.loadString(xmlstring) \\ "data"
    nodes = nodes.head
    val version: String = nodes.toString()
      .replaceAll("/", "")
      .split("<buildTime>")(1)
    version
  }

  // 将df的每一行数据转为json
  def row2Json(r: Row): JSONObject = {
    val rowMap_tmp: Map[String, String] = r.getValuesMap(r.schema.fieldNames)
    val rowMap: Map[String, String] = rowMap_tmp.map(v => {
      if (v._2 == null) (v._1, "") else v
    })

    val obj: JSONObject = new JSONObject()
    for (m <- rowMap) obj.put(m._1, m._2)
    obj
  }

  // 输出df的条数和样例数据
  def GetDFCountAndSampleData(logger: Logger, df: DataFrame, desc: String) {
    val cnt: Long = df.count()
    logger.error(s"$desc 数据总量：$cnt 条")
    logger.error(s"$desc 样例数据：")
    df.take(1).foreach(r => logger.error(r.mkString("|")))
  }

  // 输出df的条数和样例数据
  def GetDFCountAndSampleData(logger: Logger, df: DataFrame, desc: String, n: Int) {
    val cnt: Long = df.count()
    logger.error(s"$desc 数据总量：$cnt 条")
    logger.error(s"$desc 样例数据：")
    df.take(n).foreach(r => logger.error(r.mkString("|")))
  }

  // 输出ds的条数和样例数据
  def GetDSCountAndSampleData(logger: Logger, ds: Dataset[_], desc: String) {
    val cnt: Long = ds.count()
    logger.error(s"$desc 数据总量：$cnt 条")
    logger.error(s"$desc 样例数据：")
    ds.take(1).foreach(r => logger.error(r.toString))
  }

  // 输出ds的条数和样例数据
  def GetDSCountAndSampleData(logger: Logger, ds: Dataset[_], desc: String, n: Int) {
    val cnt: Long = ds.count()
    logger.error(s"$desc 数据总量：$cnt 条")
    logger.error(s"$desc 样例数据：")
    ds.take(n).foreach(r => logger.error(r.toString))
  }

  // 输出rdd的条数和样例数据
  def GetRDDCountAndSampleData(logger: Logger, rdd: RDD[JSONObject], desc: String, n: Int) {
    val cnt: Long = rdd.count()
    logger.error(s"$desc 数据总量：$cnt 条")
    logger.error(s"$desc 样例数据：")
    rdd.take(n).foreach(o => logger.error(o.toJSONString))
  }

  // 输出rdd的条数和样例数据
  def GetRDDCountAndSampleData(logger: Logger, rdd: RDD[JSONObject], desc: String) {
    val cnt: Long = rdd.count()
    logger.error(s"$desc 数据总量：$cnt 条")
    logger.error(s"$desc 样例数据：")
    rdd.take(1).foreach(o => logger.error(o.toJSONString))
  }

  // 输出rdd的条数和样例数据
  def GetRDDCountAndSampleData2(logger: Logger, rdd: RDD[(String, JSONObject)], desc: String) {
    val cnt: Long = rdd.count()
    logger.error(s"$desc 数据总量：$cnt 条")
    logger.error(s"$desc 样例数据：")
    rdd.map(_._2).take(1).foreach(o => logger.error(o.toJSONString))
  }

  // 输出rdd的条数和样例数据
  def GetRDDCountAndSampleData3(logger: Logger, rdd: RDD[String], desc: String) {
    val cnt: Long = rdd.count()
    logger.error(s"$desc 数据总量：$cnt 条")
    logger.error(s"$desc 样例数据：")
    rdd.take(1).foreach(logger.error)
  }


  // 把df数据写入到hive
  def df2HiveByOverwrite(logger: Logger, df: DataFrame, table: String): Unit = {
    logger.error(s"开始写入到 Hive：$table")
    df
      .write
      .mode(SaveMode.Overwrite)
      .insertInto(table)
    logger.error(s"写入 $table 成功！")
  }

  // 把ds数据写入到hive
  def ds2HiveByOverwrite(logger: Logger, ds: Dataset[_], table: String): Unit = {
    logger.error(s"开始写入到 Hive：$table")
    ds
      .write
      .mode(SaveMode.Overwrite)
      .insertInto(table)
    logger.error(s"写入 $table 成功！")
  }

  // 把df数据写入到hive
  def df2HiveByAppend(logger: Logger, df: DataFrame, table: String): Unit = {
    logger.error(s"开始写入到 Hive：$table")
    df
      .write
      .mode(SaveMode.Append)
      .insertInto(table)
    logger.error(s"写入 $table 成功！")
  }

  // 把ds数据写入到hive
  def ds2HiveByAppend(logger: Logger, ds: Dataset[_], table: String): Unit = {
    logger.error(s"开始写入到 Hive：$table")
    ds
      .write
      .mode(SaveMode.Append)
      .insertInto(table)
    logger.error(s"写入 $table 成功！")
  }

  // 把df数据写入到hive
  def testDF2Hive(logger: Logger, df: DataFrame, table: String): Unit = {
    logger.error(s"开始写入到Hive：$table")
    df
      .write
      .mode(SaveMode.Overwrite)
      .partitionBy("inc_day")
      .saveAsTable(table)
    logger.error(s"写入 $table 成功！")
  }

  // 把ds数据写入到hive
  def testDS2Hive(logger: Logger, ds: Dataset[_], table: String): Unit = {
    logger.error(s"开始写入到Hive：$table")
    ds
      .write
      .mode(SaveMode.Overwrite)
      .partitionBy("inc_day")
      .saveAsTable(table)
    logger.error(s"写入 $table 成功！")
  }

  // 获得当前时间
  def getNowTime: String = {

    //实例化一个Date对象并且获取时间戳（毫秒级）

    val time: Long = new Date().getTime

    //设置时间格式

    val format = new SimpleDateFormat("yyyyMMdd")

    //将时间格式套用在获取的时间戳上

    format.format(time)

  }

  // 获得当前时间
  def getNowTime2: String = {

    //实例化一个Date对象并且获取时间戳（毫秒级）

    val time: Long = new Date().getTime

    //设置时间格式

    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

    //将时间格式套用在获取的时间戳上

    format.format(time)

  }

  // 获得当前时间
  def getNowTime3: String = {

    //实例化一个Date对象并且获取时间戳（毫秒级）

    val time: Long = new Date().getTime

    //设置时间格式

    val format = new SimpleDateFormat("yyyy-MM-dd")

    //将时间格式套用在获取的时间戳上

    format.format(time)

  }

  // 把日期类型的字符串转时间戳(毫秒级别)
  def getTimestamp(s: String, fmt: String): Long = {
    var t = 0l
    try {
      val format = new SimpleDateFormat(fmt)
      t = format.parse(s).getTime
    } catch {
      case e: Exception => logger.error("字段异常" + e.getMessage)
    }
    t
  }

  // 把日期类型的字符串转时间戳(毫秒级别)
  def getTimestamp: UserDefinedFunction = udf((s: String) => {
    var t: Long = 0l
    val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    try {
      t = format.parse(s).getTime
    } catch {
      case e: Exception => logger.error(e.getMessage)
    }
    t
  })


  // 把时间戳(毫秒级别) 转换为日期类型的字符串
  def getDateStr(l: Long, fmt: String): String = {
    var s = ""
    try {
      val format = new SimpleDateFormat(fmt)
      s = format.format(new Date(l))
    } catch {
      case e: Exception => logger.error(e.getMessage)
    }
    s
  }

  // 单位是分钟
  def getTimeDiff: UserDefinedFunction = udf((start_tm: String, end_tm: String) => {
    val l1: Long = getTimestamp(start_tm, "yyyy-MM-dd HH:mm:ss")
    val l2: Long = getTimestamp(end_tm, "yyyy-MM-dd HH:mm:ss")
    (l1 - l2) / (1000 * 60)
  })

  // 返回天数
  def getTimeDiffDay: UserDefinedFunction = udf((start_tm: String, end_tm: String) => {
    val l1: Long = getTimestamp(start_tm, "yyyy-MM-dd")
    val l2: Long = getTimestamp(end_tm, "yyyy-MM-dd")
    (l1 - l2) / (1000 * 60 * 60 * 24)
  })

  // 返回天数
  def getTimeDiffDay(start_tm: String, end_tm: String): Long = {
    val l1: Long = getTimestamp(start_tm, "yyyy-MM-dd")
    val l2: Long = getTimestamp(end_tm, "yyyy-MM-dd")
    (l1 - l2) / (1000 * 60 * 60 * 24)
  }

  /**
   * 获取两个日期之间的日期
   *
   * @param start 开始日期
   * @param end   结束日期
   * @return 日期集合
   */
  def getBetweenDates(start: String, end: String): List[String] = {
    val startData: Date = new SimpleDateFormat("yyyyMMdd").parse(start); //定义起始日期
    val endData: Date = new SimpleDateFormat("yyyyMMdd").parse(end); //定义结束日期

    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
    val buffer = new ListBuffer[String]
    buffer += dateFormat.format(startData.getTime)
    val tempStart: Calendar = Calendar.getInstance()

    tempStart.setTime(startData)
    tempStart.add(Calendar.DAY_OF_YEAR, 1)

    val tempEnd: Calendar = Calendar.getInstance()
    tempEnd.setTime(endData)
    while (tempStart.before(tempEnd)) {
      buffer += dateFormat.format(tempStart.getTime)
      tempStart.add(Calendar.DAY_OF_YEAR, 1)
    }
    buffer += dateFormat.format(endData.getTime)
    buffer.toList
  }

  def getBetweenDates2(start: String, end: String): List[String] = {
    val startData: Date = new SimpleDateFormat("yyyyMMdd").parse(start); //定义起始日期
    val endData: Date = new SimpleDateFormat("yyyyMMdd").parse(end); //定义结束日期

    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val buffer = new ListBuffer[String]
    buffer += dateFormat.format(startData.getTime)
    val tempStart: Calendar = Calendar.getInstance()

    tempStart.setTime(startData)
    tempStart.add(Calendar.DAY_OF_YEAR, 1)

    val tempEnd: Calendar = Calendar.getInstance()
    tempEnd.setTime(endData)
    while (tempStart.before(tempEnd)) {
      buffer += dateFormat.format(tempStart.getTime)
      tempStart.add(Calendar.DAY_OF_YEAR, 1)
    }
    buffer += dateFormat.format(endData.getTime)
    buffer.toList
  }

  def getWeekOfYear(date: String): Int = {
    val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
    val date1: Date = sdf.parse(date)
    val calendar: Calendar = Calendar.getInstance()
    //下面的Calendar.MONDAY也可以用数字表示:SUNDAY:1,MONDYA:2,TUESDAY:3,WEDNESDAY:4,THURSDAY:5,FRIDAY:6,SATURDAY:7
    calendar.setFirstDayOfWeek(Calendar.MONDAY)
    calendar.setTime(date1)
    val week: Int = calendar.get(Calendar.WEEK_OF_YEAR)
    week
  }

  def getdayOfWeek(date: String): Int = {
    val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
    val date1: Date = sdf.parse(date)
    val calendar: Calendar = Calendar.getInstance()
    //下面的Calendar.MONDAY也可以用数字表示:SUNDAY:1,MONDYA:2,TUESDAY:3,WEDNESDAY:4,THURSDAY:5,FRIDAY:6,SATURDAY:7
    calendar.setFirstDayOfWeek(Calendar.DAY_OF_WEEK)
    calendar.setTime(date1)
    val day: Int = calendar.get(Calendar.DAY_OF_WEEK) - 1
    if (day == 0) 7 else day
  }

  // 返回2个数的百分比 i:分子  j:分母 ,保留2位小数
  def getRate(i: Long, j: Long): String = {
    val i2: Double = i.toDouble

    var rate: String = ""
    if (j != 0) rate = (i2 * 100 / j).formatted("%.2f") + "%"
    rate
  }

  def getRate(i: Int, j: Int): String = {
    val i2: Double = i.toDouble

    var rate: String = ""
    if (j != 0) rate = (i2 * 100 / j).formatted("%.2f") + "%"
    rate
  }

  // 计算2个数相除的百分百,保留2位小数
  def getRate2: UserDefinedFunction = udf((i: Int, j: Int) => {
    val i2: Double = i.toDouble

    var rate: String = ""
    if (j != 0) rate = (i2 * 100 / j).formatted("%.2f") + "%"
    rate
  })

  // 计算2个数相除的百分百,保留2位小数
  def getRate3: UserDefinedFunction = udf((i: Long, j: Long) => {
    val i2: Double = i.toDouble

    var rate: String = ""
    if (j != 0) rate = (i2 * 100 / j).formatted("%.2f") + "%"
    rate
  })


  // 获取 DataFrame
  def getDataFrame(logger: Logger, spark: SparkSession, sql: String, des: String = "原始数据"): DataFrame = {
    logger.error(sql)

    val df: DataFrame = spark
      .sql(sql)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetDFCountAndSampleData(logger, df, des)

    df
  }


  // 获取 RDD[JSONObject]
  def getJsonRDD(logger: Logger, spark: SparkSession, sql: String, n: Int = 1, des: String = "原始数据"): RDD[JSONObject] = {
    logger.error(sql)

    val rdd: RDD[JSONObject] = spark
      .sql(sql)
      .rdd
      .map(row2Json)
      .persist(StorageLevel.MEMORY_AND_DISK)

    GetRDDCountAndSampleData(logger, rdd, des, n)
    rdd
  }

  def runInterfaceWithAkLimit(logger: Logger, spark: SparkSession, dataRdd: RDD[JSONObject], fun: (String, JSONObject) => JSONObject, parallelism: Int, ak: String, akMinuLimit: Int): RDD[JSONObject] = {
    val cores: Integer = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.cores", "0"))
    val excutors: Integer = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.instances", "0"))
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)

    //为了精确控制并发，task数量和并行度需要小于excutors数量，否则并行度和ak单位分钟限制无法精确控制
    var maxParallelism: Int = parallelism
    if (parallelism > excutors) maxParallelism = excutors

    logger.error("最大分区数：" + maxParallelism)
    val curPartition: Int = dataRdd.getNumPartitions
    var runRdd: RDD[JSONObject] = null
    if (curPartition != maxParallelism) {
      runRdd = dataRdd.repartition(maxParallelism)
      logger.error("重分区：" + maxParallelism)
    } else runRdd = dataRdd

    var maxMinueOfPartition: Int = akMinuLimit / maxParallelism
    if (parallelism > maxParallelism) maxMinueOfPartition = akMinuLimit / maxParallelism

    logger.error(s"单分区ak最大分钟限制：$maxMinueOfPartition 次")
    val retRdd: RDD[JSONObject] = runRdd.mapPartitions(partitions => {
      val partitionLimitMinu: Int = maxMinueOfPartition
      var lastMin: Int = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      //实际单为并行跑数
      partitions.map(obj => {
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount.toString)
        }
        val second: Int = Calendar.getInstance().get(Calendar.SECOND)
        val cur: Int = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin) {
          timeInt = timeInt + 1
          if (timeInt >= partitionLimitMinu) {
            logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount)
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          timeInt = 1
          lastMin = cur
        }
        fun(ak, obj)
      })
    })

    retRdd
  }

  // 根据经纬度，计算2点之间的距离 返回值的单位：m
  def getDistance(longitude1: Double, latitude1: Double, longitude2: Double, latitude2: Double): Double = {
    val R = 6371.00

    val lat1: Double = Math.toRadians(latitude1)
    val lat2: Double = Math.toRadians(latitude2)
    // 经度
    val lng1: Double = Math.toRadians(longitude1)
    val lng2: Double = Math.toRadians(longitude2)
    // 纬度之差
    val a: Double = lat1 - lat2
    // 经度之差
    val b: Double = lng1 - lng2
    // 计算两点距离的公式
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(b / 2), 2)))
    // 弧长乘地球半径, 返回单位: 千米
    s = s * R * 1000
    s.formatted("%.2f").toDouble
  }

  // 根据经纬度，计算2点之间的距离 返回值的单位：m
  def getDistance: UserDefinedFunction = udf((longitude1: Double, latitude1: Double, longitude2: Double, latitude2: Double) => {
    val R = 6371.00

    val lat1: Double = Math.toRadians(latitude1)
    val lat2: Double = Math.toRadians(latitude2)
    // 经度
    val lng1: Double = Math.toRadians(longitude1)
    val lng2: Double = Math.toRadians(longitude2)
    // 纬度之差
    val a: Double = lat1 - lat2
    // 经度之差
    val b: Double = lng1 - lng2
    // 计算两点距离的公式
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(b / 2), 2)))
    // 弧长乘地球半径, 返回单位: 千米
    s = s * R * 1000
    s.formatted("%.2f").toDouble
  })

  // 将map转化为string，剔除值为null的数据
  def map2String(parMap: mutable.HashMap[String, Any]): String = {
    for (elem <- parMap)
      if (elem._2 == null) parMap.remove(elem._1)
    val parStr: String = parMap.mkString("&").replaceAll(" -> ", "=")
    parStr
  }

  def getFirstDayofMonthBeforeOrAfter(num: Int): UserDefinedFunction = udf((inc_day: String) => {
    val tmp_1: String = inc_day.substring(0, 6) + "01"
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp_1)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    dateFormat.format(cal.getTime)
  })

  def getFirstDayofMonthBeforeOrAfter(inc_day: String, num: Int): String = {
    val tmp_1: String = inc_day.substring(0, 6) + "01"
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp_1)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    dateFormat.format(cal.getTime)
  }

  def getLastDayofMonthBeforeOrAfter(inc_day: String, num: Int): String = {
    val tmp_1: String = inc_day.substring(0, 6) + "01"
    val tmp_2: String = getdaysBeforeOrAfter(tmp_1, -1)
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp_2)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num + 1)
    cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE))
    dateFormat.format(cal.getTime)
  }

  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

}
