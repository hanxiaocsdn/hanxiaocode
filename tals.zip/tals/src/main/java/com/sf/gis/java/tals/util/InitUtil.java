package com.sf.gis.java.tals.util;

import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.tals.constant.ConfConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

/**
 * 初始化工具
 * @author 01370539 created on Jul.21 2021
 */
public class InitUtil {
    private static final Logger logger = LoggerFactory.getLogger(InitUtil.class);

    public static void initConf() {
        logger.error("start init conf...");
        ConfConstant.CFG_HBASE = ConfigUtil.loadPropertiesConfiguration("hbase.properties");
        ConfConstant.CFG_PARALLELISM = ConfigUtil.loadPropertiesConfiguration("parallelism.properties");
    }
}
