package com.sf.gis.java.tals.pojo;

import javax.persistence.Column;

/**
 * 电话基础信息
 * @author 01370539 created on Jul.21 2021
 */
public class TalsTelBase {

    @Column(name = "tel")
    private String tel;
    @Column(name = "tel_md5")
    private String telMd5;
    @Column(name = "tel_id")
    private String telId;
    @Column(name = "name")
    private String name;
    @Column(name = "location")
    private String location;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "type")
    private String type;
    @Column(name = "is_abnormal")
    private String isAbnormal;
    @Column(name = "abnormal_tag")
    private String abnormalTag;

}
