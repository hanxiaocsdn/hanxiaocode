package com.sf.gis.java.tals.udf;

import com.sf.gis.java.tals.util.MD5Util;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * @author 01416344
 * @Date  20220715
 * 描述： MD5编码加密解密
 */
public class Md5EncodeDecode extends UDF {


	/**
	 * 加密解密算法 执行一次加密，两次解密
	 */
	public static String evaluate(String inStr) {
		String res = "";
		if(null!=inStr && inStr.length()>0){
			res = MD5Util.convertMD5(inStr);
		}
		return  res;
	}

}
