package com.sf.gis.java.tals.util;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public final class EncryptUtils {


    private EncryptUtils() {

    }

    public static String sha256Encrypt(String content) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(content.getBytes("utf-8"));
            return Base64.getEncoder().encodeToString(md.digest());
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static String encrypt(int encryptType, String key, String content) {
        String result = null;
        switch (encryptType) {
            case 1: // AES128
                result = aes128Entrypt(key, content);
                break;
            case 2: // 3DES
                result = des3Entrypt(key, content);
                break;
            case 3:
                result = rc4Entrypt(key, content);
                break;
            case 4:
                result = desEntrypt(key, content);
                break;
        }
        return result;
    }

    public static String decrypt(int decryptType, String key, String content) {
        String result = null;
        switch (decryptType) {
            case 1:
                result = aes128Detrypt(key, content);
                break;
            case 2:
                result = des3Detrypt(key, content);
                break;
            case 3:
                result = rc4Detrypt(key, content);
                break;
            case 4:
                result = desDetrypt(key, content);
                break;
        }
        return result;
    }

    private static String aes128Entrypt(String key, String content) {
        return keyGeneratorES(key, content, "AES", 128, true);
    }

    private static String aes128Detrypt(String key, String content) {
        return keyGeneratorES(key, content, "AES", 128, false);
    }


    private static String des3Entrypt(String key, String content) {
        return keyGeneratorES(key, content, "DESede", 0, true);
    }

    private static String des3Detrypt(String key, String content) {
        return keyGeneratorES(key, content, "DESede", 0, false);
    }

    private static String desEntrypt(String key, String content) {
        return keyGeneratorES(key, content, "DES", 0, true);
    }

    private static String desDetrypt(String key, String content) {
        return keyGeneratorES(key, content, "DES", 0, false);
    }

    private static String rc4Entrypt(String key, String content) {
        return keyGeneratorES(key, content, "RC4", 0, true);
    }

    private static String rc4Detrypt(String key, String content) {
        return keyGeneratorES(key, content, "RC4", 0, false);
    }

    private static class BaseKey {
        String algorithm;
        String key;
        boolean isEncode;

        public BaseKey(String algorithm, String key, boolean isEncode) {
            super();
            this.algorithm = algorithm;
            this.key = key;
            this.isEncode = isEncode;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((algorithm == null) ? 0 : algorithm.hashCode());
            result = prime * result + (isEncode ? 1231 : 1237);
            result = prime * result + ((key == null) ? 0 : key.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            BaseKey other = (BaseKey) obj;
            if (algorithm == null) {
                if (other.algorithm != null)
                    return false;
            } else if (!algorithm.equals(other.algorithm))
                return false;
            if (isEncode != other.isEncode)
                return false;
            if (key == null) {
                if (other.key != null)
                    return false;
            } else if (!key.equals(other.key))
                return false;
            return true;
        }

    }

    private static Map<BaseKey, Cipher> cipherMap = new HashMap<>();

    private static String keyGeneratorES(String key, String content, String algorithm, int keysize, boolean isEncode) {
        try {
            Cipher cipher = cipherMap.computeIfAbsent(new BaseKey(algorithm, key, isEncode), k -> {
                try {
                    KeyGenerator kg = KeyGenerator.getInstance(algorithm);
                    byte[] keyBytes = key.getBytes("utf-8");
                    SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
                    random.setSeed(keyBytes);
                    if (keysize == 0) {
                        kg.init(random);
                    } else {
                        kg.init(keysize, random);
                    }
                    SecretKey sk = kg.generateKey();
                    SecretKeySpec sks = new SecretKeySpec(sk.getEncoded(), algorithm);
                    Cipher res = Cipher.getInstance(algorithm);
                    if (isEncode) {
                        res.init(Cipher.ENCRYPT_MODE, sks);
                    } else {
                        res.init(Cipher.DECRYPT_MODE, sks);
                    }
                    return res;
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
            if (isEncode) {
                return Base64.getEncoder().encodeToString(cipher.doFinal(content.getBytes("utf-8")));
            } else {
                return new String(cipher.doFinal(Base64.getDecoder().decode(content)));
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static void rsaEncryptFile(String sourceFilePath, String encryptedFilePath, String privateKeyFilePath) {
        try (ObjectInputStream oisKey = new ObjectInputStream(new FileInputStream(privateKeyFilePath));
             FileInputStream fis = new FileInputStream(sourceFilePath);
             FileOutputStream fos = new FileOutputStream(encryptedFilePath)) {
            Key key = (Key) oisKey.readObject();
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] b = new byte[117];
            while (fis.read(b) != -1) {
                fos.write(cipher.doFinal(b));
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static void rsaDecryptFile(String encrytedFilePath, String decryptedFilePath, String publicKeyFilePath) {
        try (ObjectInputStream oisKey = new ObjectInputStream(new FileInputStream(publicKeyFilePath));
             FileInputStream fis = new FileInputStream(encrytedFilePath);
             FileOutputStream fos = new FileOutputStream(decryptedFilePath)) {
            Key key = (Key) oisKey.readObject();
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] b = new byte[128];
            while (fis.read(b) != -1) {
                fos.write(cipher.doFinal(b));
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static void makeKeyFile(String pubkeyfile, String pvtkeyfile) throws Exception {
        // KeyPairGenerator类用于生成公钥和私钥对，基于RSA算法生成对象
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
        // 初始化密钥对生成器，密钥大小为1024位
        keyPairGen.initialize(1024);
        // 生成一个密钥对，保存在keyPair中
        KeyPair keyPair = keyPairGen.generateKeyPair();
        // 得到私钥
        RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
        // 得到公钥
        RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
        // 生成私钥
        try (ObjectOutputStream pvt = new ObjectOutputStream(new FileOutputStream(pvtkeyfile));
             ObjectOutputStream pub = new ObjectOutputStream(new FileOutputStream(pubkeyfile))) {
            pvt.writeObject(privateKey);
            pub.writeObject(publicKey);
        }

    }

    public static void main(String[] args) {
        // aes128加密
//        String en = decrypt(1, "gC7I4vJ2QvfpiWgF", "IJk5/fLCV1/914fP34GWUeNoRj08akI4UGJwBtWV24u4iA2/npvoNQTkbNZHJqb6ZNeYByHuhMCufQ2snWOQFQ==");
//        String en = encrypt(1, "26td+o2y6LqNeX77","张三");
//        System.out.println(en);

        String en = encrypt(1, "hellopasswd","hello");
        System.out.println(en);
        System.out.println(decrypt(1,"hellopasswd", en));

    }

}
