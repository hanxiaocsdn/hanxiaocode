package com.sf.gis.java.tals.constant;

import java.util.Properties;

/**
 * 常量类：通过config文件初始化
 * @author: 01370539 Created On: May.07 2021
 */
public class ConfConstant {

    public static Properties CFG_HBASE = null;    // hbase相关配置信息
    public static Properties CFG_PARALLELISM = null;    // 并行度相关配置
}
