package com.sf.gis.java.tals.udf;

import com.sf.gis.java.tals.util.EncryptUtils;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * @author 01416344(zhangxiaoqiong)
 * @Date  20230308
 * 描述： 对加密字符串进行解密（AES128 自定义秘钥）
 */
public class StrDecrypt extends UDF {


	/**
	 * 对加密字符串进行解密
	 */
	public static String evaluate(String inStr, String key) {
		String res = "";
		if(null!=inStr && inStr.length()>0){
			res = EncryptUtils.decrypt(1, key, inStr);
		}
		return  res;
	}

}
