package com.sf.gis.java.tals.app;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.tals.constant.ConfConstant;
import com.sf.gis.java.tals.constant.TalsConstant;
import com.sf.gis.java.tals.controller.TalsInitController;
import com.sf.gis.java.tals.util.InitUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 电话地址库初始化流程
 * @author 01370539 created on Jul.19 2021
 */
public class TalsInitApp {
    private static final Logger logger = LoggerFactory.getLogger(TalsInitApp.class);

//    public static void main(String[] args) {
//        String iterativeMode;  // 迭代模式，init：初始化模式；incr：增量模式
//        String startDate;
//        String endDate;
//        if (args.length >= 3) {
//            iterativeMode = args[0];
//            startDate = args[1];
//            endDate = args[2];
//        } else {
//            iterativeMode = TalsConstant.ITERATIVE_MODE_INCR;
//            startDate = DateUtil.getCurrentDateBefore(FixedConstant.DATE_FORMATE_INCDAY);
//            endDate = startDate;
//        }
//        if (!startDate.matches("20\\d{6}") || !endDate.matches("20\\d{6}")) {
//            logger.error("date format must be yyyyMMdd");
//            System.exit(0);
//        }
//
//        InitUtil.initConf();
//
//        new TalsInitController().process(iterativeMode, startDate, endDate);
//    }
}
