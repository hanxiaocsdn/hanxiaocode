package com.sf.gis.java.tals.util;

/**
 * Created by 01416344 on 2022/11/08.
 * 数理统计类工具类
 */
public class StatUtils {

    /**
     * 标准差
     * @param samples Doube数组
     * @return
     */
    public static Double STDEVP(Double[] samples) {
        if (1 > samples.length) {
            return null;
        }
        double dSum = 0.0; // 样本值之和
        double dAverage = 0.0; // 样本值的平均值

        for (int i = 0; i < samples.length; ++i) {
            dSum += samples[i];
        }
        dAverage = dSum / samples.length;

        dSum = 0.0;
        for (int i = 0; i < samples.length; ++i) {
            dSum += (samples[i] - dAverage) * (samples[i] - dAverage);
        }
        double dStdDev = Math.sqrt(dSum / samples.length);
        return dStdDev;
    }

    /**
     * 均值
     * @param samples Doube数组
     * @return
     */
    public static Double AVERAGE(Double[] samples) {
        if (1 > samples.length) {
            return null;
        }
        double dSum = 0.0; // 样本值之和
        Double dAverage = null; // 样本值的平均值

        for (int i = 0; i < samples.length; ++i) {
            dSum += samples[i];
        }
        dAverage = dSum / samples.length;
        return dAverage;
    }

    public static void main(String[] args) {
        //输入：1345.0,1301.0,1368.0,1322.0,1310.0,1370.0,1318.0,1350.0,1303.0,1299.0
        //STDEVP输出：26.05456
        //AVERAGE输出：1328.6
        Double[] testSamps = new Double[]{1345.0,1301.0,1368.0,1322.0,1310.0,1370.0,1318.0,1350.0,1303.0,1299.0};
        Double stdevp = STDEVP(testSamps);
        System.out.println(stdevp);
        Double avg = AVERAGE(testSamps);
        System.out.println(avg);

    }


}
