package com.sf.gis.java.tals.constant;

/**
 * 电话地址库常量
 * @author: 01370539 Created On: May.07 2021
 */
public class TalsConstant {
    public static final int TALS_INIT_DATA_COUNT = 14;  // 电话地址库初始化数据取数收件数据取数范围跨度

    public static final String ITERATIVE_MODE_INIT = "INIT"; // 迭代模式为初始化
    public static final String ITERATIVE_MODE_INCR = "INCR"; // 迭代模式为增量
}
