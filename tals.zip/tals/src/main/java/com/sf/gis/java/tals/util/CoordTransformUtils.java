package com.sf.gis.java.tals.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 01416344 on 2023/11/08.
 * 经纬坐标转换工具类
 */
public class CoordTransformUtils {

    public final static double x_pi = 3.14159265358979324 * 3000.0 / 180.0;

    private static final double PI = 3.14159265358979324;
    private static final double A = 6378245.0;
    private static final double EE = 0.00669342162296594323;

    /**
     * 高德坐标转百度坐标
     *
     * @param gd_lon 经度
     * @param gd_lat 纬度
     * @return
     */
    public static Map<String, String> gd2bd(double gd_lon, double gd_lat) {
        Map<String, String> data = new HashMap<>();
        double x = gd_lon, y = gd_lat;
        double z = Math.sqrt(x * x + y * y) + 0.00002 * Math.sin(y * x_pi);
        double theta = Math.atan2(y, x) + 0.000003 * Math.cos(x * x_pi);
        double bd_lon = z * Math.cos(theta) + 0.0065;
        double bd_lat = z * Math.sin(theta) + 0.006;
        data.put("lon", String.format("%.6f", bd_lon));
        data.put("lat", String.format("%.6f", bd_lat));
        return data;
    }


    /**
     * 百度坐标转换高德坐标
     *
     * @param bd_lon 经度
     * @param bd_lat 纬度
     * @return
     */
    public static Map<String, String> bd2gd(double bd_lon, double bd_lat) {
        double x = bd_lon - 0.0065, y = bd_lat - 0.006;
        double z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * x_pi);
        double theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * x_pi);
        double gd_lon = z * Math.cos(theta);
        double gd_lat = z * Math.sin(theta);
        Map<String, String> data = new HashMap<>();
        data.put("lon", String.format("%.6f", gd_lon));
        data.put("lat", String.format("%.6f", gd_lat));
        return data;
    }


    /**
     * 经纬度 GPS转高德
     *
     * @param wgLon GPS经度
     * @param wgLat GPS维度
     * @return 转化后的经纬度坐标
     */


    // 将 WGS-84 坐标转换为 GCJ-02（高德坐标）
    public static Map<String, String> wgs84ToGcj02(double wgLon, double wgLat) {
        Map<String, String> data = new HashMap<>();
        if (outOfChina(wgLat, wgLon)) {
            data.put("lon", String.format("%.6f", 0.0));
            data.put("lat", String.format("%.6f", 0.0));
            return data;
        }

        double dLat = transformLat(wgLon - 105.0, wgLat - 35.0);
        double dLon = transformLon(wgLon - 105.0, wgLat - 35.0);

        double radLat = wgLat / 180.0 * PI;
        double magic = Math.sin(radLat);
        magic = 1 - EE * magic * magic;
        double sqrtMagic = Math.sqrt(magic);

        dLat = (dLat * 180.0) / ((A * (1 - EE)) / (magic * sqrtMagic) * PI);
        dLon = (dLon * 180.0) / (A / sqrtMagic * Math.cos(radLat) * PI);

        double mgLat = wgLat + dLat;
        double mgLon = wgLon + dLon;

        data.put("lon", String.format("%.6f", mgLon));
        data.put("lat", String.format("%.6f", mgLat));
        return data;
    }

    // 判断坐标是否在中国境内
    private static boolean outOfChina(double lat, double lon) {
        return lon < 72.004 || lon > 137.8347 || (lat < 0.8293 || lat > 55.8271 || false);
    }

    private static double transformLat(double x, double y) {
        double ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * Math.sqrt(Math.abs(x));
        ret += (20.0 * Math.sin(6.0 * x * PI) + 20.0 * Math.sin(2.0 * x * PI)) * 2.0 / 3.0;
        ret += (20.0 * Math.sin(y * PI) + 40.0 * Math.sin(y / 3.0 * PI)) * 2.0 / 3.0;
        ret += (160.0 * Math.sin(y / 12.0 * PI) + 320 * Math.sin(y * PI / 30.0)) * 2.0 / 3.0;
        return ret;
    }

    private static double transformLon(double x, double y) {
        double ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * Math.sqrt(Math.abs(x));
        ret += (20.0 * Math.sin(6.0 * x * PI) + 20.0 * Math.sin(2.0 * x * PI)) * 2.0 / 3.0;
        ret += (20.0 * Math.sin(x * PI) + 40.0 * Math.sin(x / 3.0 * PI)) * 2.0 / 3.0;
        ret += (150.0 * Math.sin(x / 12.0 * PI) + 300.0 * Math.sin(x / 30.0 * PI)) * 2.0 / 3.0;
        return ret;
    }




    public static void main(String[] args) {
        Map<String, String> doubleMap = bd2gd(116.481499, 39.990475);
        System.out.printf("输入坐标："+doubleMap.toString()+"\n");
        System.out.printf("高德api接口返回结果："+"116.4748955248,39.984717169345"+"\n");
        System.out.printf("bd2gd工具类返回结果："+doubleMap.get("lon")+","+doubleMap.get("lat")+"\n");

        Map<String, String> doubleMap1 = wgs84ToGcj02(116.481499, 39.990475);
        System.out.printf("高德api接口返回结果："+"116.487585177952,39.991754014757"+"\n");
        System.out.printf("wgs84Togd工具类返回结果："+doubleMap1.get("lon")+","+doubleMap1.get("lat")+"\n");

    }

}
