package com.sf.gis.java.tals.util;

import com.sf.gis.java.base.util.HttpConnection;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import java.nio.charset.Charset;

public class MyHttpConnection {

    private static Logger logger = Logger.getLogger(MyHttpConnection.class);
    private static PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    private static CloseableHttpClient httpClient = null;
    private static boolean isInitConnection = false;

    private static void initConnectionManager() {
        synchronized (HttpConnection.class){
            //noinspection SingleStatementInBlock
            if(!isInitConnection){
                try {
                    connManager.setMaxTotal(500); // 设置整个连接池最大连接数 根据自己的场景决定
                    // 是路由的默认最大连接（该值默认为2），限制数量实际使用DefaultMaxPerRoute并非MaxTotal。设置过小无法支持大并发(ConnectionPoolTimeoutException: Timeout waiting for connection from pool)，路由是对maxTotal的细分。
                    connManager.setDefaultMaxPerRoute(500);// （目前只有一个路由，因此让他等于最大值）
                    SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setSoTimeout(30000).setTcpNoDelay(true).build();
                    connManager.setDefaultSocketConfig(socketConfig);

                    RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(30000).setConnectTimeout(30000).setSocketTimeout(30000).build();
                    httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setConnectionManager(connManager).build();
                } catch (Exception e) {
                    logger.error("initConnectionManager error. ", e);
                }
            }
        }
    }

    public static String httpPost(int tryCount, String url, String json, String ak) {
        int count = tryCount;
        while (count-- > 0) {
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("Content-type", "application/json; charset=utf-8");
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("ak", ak);
            httpPost.setEntity(new StringEntity(json, Charset.forName("UTF-8")));
            try (CloseableHttpClient httpClient = HttpClients.custom().build();
                 CloseableHttpResponse response = httpClient.execute(httpPost);) {

                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    // LogUtil.e(result);
                    return result;
                }
            } catch (Exception e) {
                logger.error(e);
                try {
                    if (count == 0) {
                        logger.error(url + "," + e.getMessage());
                    } else if (count == 1) {
                        Thread.sleep(500);
                    } else if (count == 2) {
                        Thread.sleep(250);
                    } else if (count == 3) {
                        Thread.sleep(125);
                    }
                } catch (InterruptedException e1) {
                }
                continue;
            } finally {
                httpPost.releaseConnection();
            }
        }
        return null;
    }

}
