package com.sf.gis.java.tals.pojo;

import javax.persistence.Column;
import java.io.Serializable;

/**
 * 电话库初始化数据映射类
 * @author 01370539 created on Jul.20 2021
 */
public class TalsAddrInit implements Serializable {

    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "county")
    private String county;
    @Column(name = "tel")
    private String tel;
    @Column(name = "tel_normalized")
    private String telNormalized;
    @Column(name = "tel_md5")
    private String telMd5;
    @Column(name = "tel_location")
    private String telLocation;
    @Column(name = "tel_id")
    private String telId;
    @Column(name = "name")
    private String name;
    @Column(name = "addr")
    private String addr;
    @Column(name = "company")
    private String company;
    @Column(name = "action")
    private String action;
    @Column(name = "action_time")
    private String actionTime;
    @Column(name = "waybill_no")
    private String waybillNo;
    @Column(name = "inc_day")
    private String incDay;
    @Column(name = "action_date")
    private String actionDate;

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getTelNormalized() {
        return telNormalized;
    }

    public void setTelNormalized(String telNormalized) {
        this.telNormalized = telNormalized;
    }

    public String getTelMd5() {
        return telMd5;
    }

    public void setTelMd5(String telMd5) {
        this.telMd5 = telMd5;
    }

    public String getTelLocation() {
        return telLocation;
    }

    public void setTelLocation(String telLocation) {
        this.telLocation = telLocation;
    }

    public String getTelId() {
        return telId;
    }

    public void setTelId(String telId) {
        this.telId = telId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getActionTime() {
        return actionTime;
    }

    public void setActionTime(String actionTime) {
        this.actionTime = actionTime;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public String getActionDate() {
        return actionDate;
    }

    public void setActionDate(String actionDate) {
        this.actionDate = actionDate;
    }

    @Override
    public String toString() {
        return "TalsAddrInit{" +
                "province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", county='" + county + '\'' +
                ", tel='" + tel + '\'' +
                ", telNormalized='" + telNormalized + '\'' +
                ", telMd5='" + telMd5 + '\'' +
                ", telLocation='" + telLocation + '\'' +
                ", telId='" + telId + '\'' +
                ", name='" + name + '\'' +
                ", addr='" + addr + '\'' +
                ", company='" + company + '\'' +
                ", action='" + action + '\'' +
                ", actionTime='" + actionTime + '\'' +
                ", waybillNo='" + waybillNo + '\'' +
                ", incDay='" + incDay + '\'' +
                ", actionDate='" + actionDate + '\'' +
                '}';
    }
}
