package com.sf.gis.java.tals.service;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.HbaseUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.tals.constant.ConfConstant;
import com.sf.gis.java.tals.constant.TalsConstant;
import com.sf.gis.java.tals.pojo.TalsAddrInit;
import com.sf.gis.java.tals.pojo.TalsInitData;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Table;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * 电话地址库初始化流程
 * @author 01370539 created on Jul.20 2021
 */
public class TalsInitService {
    private static final Logger logger = LoggerFactory.getLogger(TalsInitService.class);

    /**
     * 加载初始化数据（初始化模式下的初始化数据）
     * @param sparkInfo SparkInfo
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return 运单相关信息数据
     */
//    public JavaRDD<TalsAddrInit> loadInitData(SparkInfo sparkInfo, String startDate, String endDate) {
//        String sql = SqlUtil.getSqlStr("tals_init_init.sql", startDate, endDate, startDate, endDate);
//        return dataTransfer(DataUtil.loadData(sparkInfo, sql, TalsInitData.class));
//    }
//
//    /**
//     * 加载初始化数据（增量模式下的初始化数据）
//     * @param sparkInfo SparkInfo
//     * @param date 数据所属日期
//     * @return 运单相关信息数据
//     */
//    public JavaRDD<TalsAddrInit> loadIncrData(SparkInfo sparkInfo, String date) {
//        String preDate = DateUtil.getDayBefore(date, FixedConstant.DATE_FORMATE_INCDAY, TalsConstant.TALS_INIT_DATA_COUNT);
//        String sql = SqlUtil.getSqlStr("tals_init_incr.sql", date, preDate, date, date);
//        return dataTransfer(DataUtil.loadData(sparkInfo, sql, TalsInitData.class));
//    }
//
//    public JavaRDD<String> processTel(SparkInfo sparkInfo, JavaRDD<TalsAddrInit> rddTai) {
//        JavaPairRDD<String, Iterable<TalsAddrInit>> rddTel = rddTai.mapToPair(temp -> new Tuple2<>(temp.getCityCode() + "_" + temp.getTel(), temp)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("tel count: {}", rddTel.count());
//
//        Broadcast<Properties> propsBroadcast = sparkInfo.getContext().broadcast(ConfConstant.CFG_HBASE);
//        logger.error("tblName: {}", ConfConstant.CFG_HBASE.getProperty("hbase.tbl.gis.tals.tel.base"));
//        logger.error("family: {}", ConfConstant.CFG_HBASE.getProperty("hbase.gis.family"));
//        logger.error("column: {}", ConfConstant.CFG_HBASE.getProperty("hbase.gis.column"));
//        logger.error("batchSize: {}", ConfConstant.CFG_HBASE.getProperty("batchSize"));
//
//        rddTel.repartition(SysConstant.PARTITION_COUNT).mapPartitions(pt -> {
//            List<TalsAddrInit> result = new ArrayList<>();
//            Properties prop = propsBroadcast.getValue();
//            if (prop == null) {
//                logger.error("读取广播变量失败");
//                return result.iterator();
//            }
//            HbaseUtil.setProperties(prop);
//            String tableName = prop.getProperty("hbase.gis.tel.base.table");
//            String family = prop.getProperty("hbase.gis.family");
//            String column = prop.getProperty("hbase.gis.column");
//            int batchSize = Integer.valueOf(prop.getProperty("batchSize"));
//            Connection conn = HbaseUtil.getConnection();
//            Table table = HbaseUtil.getTable(conn, tableName);
//            while (pt.hasNext()) {
//                Tuple2<String, Iterable<TalsAddrInit>> tp = pt.next();
//
//            }
//            return null;
//        });
//
//
//        return rddTai.mapToPair(temp -> new Tuple2<>(temp.getCityCode() + "_" + temp.getTel(), 1)).reduceByKey((tp1, tp2) -> tp1).map(tp -> tp._1);
//    }
//
//    public JavaRDD<TalsAddrInit> queryTelInfoFromHbase(SparkInfo sparkInfo, JavaRDD<TalsAddrInit> rddTai) {
//        Broadcast<Properties> propsBroadcast = sparkInfo.getContext().broadcast(ConfConstant.CFG_HBASE);
//
//        logger.error("tblName: {}", ConfConstant.CFG_HBASE.getProperty("hbase.tbl.gis.tals.tel.base"));
//        logger.error("family: {}", ConfConstant.CFG_HBASE.getProperty("hbase.gis.family"));
//        logger.error("column: {}", ConfConstant.CFG_HBASE.getProperty("hbase.gis.column"));
//        logger.error("batchSize: {}", ConfConstant.CFG_HBASE.getProperty("batchSize"));
//
//        return rddTai.repartition(Integer.parseInt(ConfConstant.CFG_PARALLELISM.getProperty("hbase"))).mapPartitions(pt -> {
//            List<TalsAddrInit> result = new ArrayList<>();
//            Properties prop = propsBroadcast.getValue();
//            if (prop == null) {
//                logger.error("读取广播变量失败");
//                return result.iterator();
//            }
//            HbaseUtil.setProperties(prop);
//            String tableName = prop.getProperty("hbase.gis.tel.base.table");
//            String family = prop.getProperty("hbase.gis.family");
//            String column = prop.getProperty("hbase.gis.column");
//            int batchSize = Integer.valueOf(prop.getProperty("batchSize"));
//            Connection conn = HbaseUtil.getConnection();
//            Table table = HbaseUtil.getTable(conn, tableName);
//            List<TalsAddrInit> tempList = new ArrayList<>();
//            List<Get> getList = new ArrayList<>();
//
//            while (pt.hasNext()) {
//                Tuple2<String, > o = pt.next();
//                tempList.add(o);
//                String rowkey = HbaseUtils.getKey500Str(FixedConstant.TELS_BASE_INFO_PREFIX + "_" + o.getTel());
//                Get get = HbaseUtils.getGet(rowkey, family, column);
//                getList.add(get);
//                if (getList.size() == batchSize) {
//                    result.addAll(mergeTelInfo(tempList, getList, table, family, column));
//                    tempList.clear();
//                    getList.clear();
//                }
//
//            }
//            if (!getList.isEmpty()) {
//                result.addAll(mergeTelInfo(tempList, getList, table, family, column));
//                tempList.clear();
//                getList.clear();
//            }
//            if (table != null) {
//                table.close();
//            }
//            return result.iterator();
//        }).repartition(VariableConstant.partitions);
//    }
//
//    private static JavaRDD<TalsAddrInit> dataTransfer(JavaRDD<TalsInitData> rddTid) {
//        return rddTid.flatMap(temp -> {
//            List<TalsAddrInit> resultList = new ArrayList<>();
//            if (StringUtils.isNotEmpty(temp.getMobile())) {
//                resultList.add(transfer(temp, "mobile"));
//            }
//            if (StringUtils.isNotEmpty(temp.getPhone()) && !temp.getPhone().equals(temp.getMobile())) {
//                resultList.add(transfer(temp, "phone"));
//            }
//            return resultList.iterator();
//        });
//    }
//
//    private static TalsAddrInit transfer(TalsInitData tid, String telSrc) {
//        TalsAddrInit tai = new TalsAddrInit();
//        tai.setProvince(tid.getProvince());
//        tai.setCity(tid.getCity());
//        tai.setCityCode(tid.getCityCode());
//        tai.setCounty(tid.getCounty());
//        tai.setTel("mobile".equals(telSrc) ? tid.getMobile() : tid.getPhone());
//        tai.setTelId(DigestUtils.md5Hex("tel" + (StringUtils.isNotEmpty(tid.getMobile()) ? tid.getMobile() : tid.getPhone())));
//        tai.setName(tid.getName());
//        tai.setAddr(tid.getAddr());
//        tai.setCompany(tid.getCompany());
//        tai.setAction(tid.getAction());
//        tai.setActionTime(tid.getActionTime());
//        tai.setWaybillNo(tid.getWaybillNo());
//        tai.setIncDay(tid.getIncDay());
//        tai.setActionDate(tid.getActionDate());
//        return tai;
//    }
}
