package com.sf.gis.java.tals.udf;

import com.sf.gis.java.tals.util.MD5Util;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * @author 01416344
 * @Date  20220715
 * 描述： 将字符串进行MD5加密处理（输出全小写）
 */
public class Md5Encode extends UDF {


	/**
	 * md5加密
	 */
	public static String evaluate(String inStr) {
		String res = "";
		if(null!=inStr && inStr.length()>0){
			res = MD5Util.md5(inStr).toLowerCase();
		}
		return  res;
	}

}
