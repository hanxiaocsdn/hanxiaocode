package com.sf.gis.java.tals.controller;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.tals.pojo.TalsInitData;
import com.sf.gis.java.tals.service.TalsInitService;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 电话地址库初始化流程
 * @author 01370539 created on Jul.19 2021
 */
public class TalsInitController {
    private static final Logger logger = LoggerFactory.getLogger(TalsInitController.class);

    private static SparkInfo sparkInfo;
    private static final TalsInitService talsInitService = new TalsInitService();

    /**
     * 初始化流程进行中
     * @param iterativeMode 迭代模式，init：初始化模式；incr：增量模式
     * @param startDate 开始日期
     * @param endDate 结束日期
     */
//    public void process(String iterativeMode, String startDate, String endDate) {
//        logger.error("start tals init. iterativeMode - {}, startDate - {}, endDate - {}", iterativeMode, startDate, endDate);
//
//        sparkInfo = SparkUtil.getSpark(TalsInitController.class.getName());
//        logger.error("end tals init. ");
//    }
//
//    public void init(String startDate, String endDate) {
//        logger.error("start init mode, startDate - {}, endDate: {}", startDate, endDate);
//        JavaRDD<TalsInitData> rddTid = talsInitService.loadInitData(sparkInfo, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("current partitions: {}, rddTid count: {}", rddTid.getNumPartitions(), rddTid.count());
//
//        logger.error("end init mode, startDate - {}, endDate: {}", startDate, endDate);
//    }
//
//    public void incr(String date) {
//        logger.error("start increment date: {}", date);
//        JavaRDD<TalsInitData> rddTid = talsInitService.loadIncrData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("current partitions: {}, rddTid count: {}", rddTid.getNumPartitions(), rddTid.count());
//
//        logger.error("end increment date: {}", date);
//    }
}
