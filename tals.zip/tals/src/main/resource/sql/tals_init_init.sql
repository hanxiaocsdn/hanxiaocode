-- 电话库初始化流程数据来源（初始化模式下）
select province, city_code, county, mobile, phone, name, addr, company, action, action_time, action_date, waybill_no, inc_day from
(
select consignor_mobile mobile, consignor_phone phone, regexp_replace(consignor_cont_name, '\\\\|,|\"|\n|\r|\t|\\s|，','') as name, regexp_replace(consignor_addr, '\\\\|,|\"|\n|\r|\t|\\s|，', '') addr, src_province province, src_dist_code city_code, src_county county, consignor_comp_name company, '寄件' action, consigned_tm action_time, regexp_replace(split(consigned_tm, ' ')[0],'-','') as action_date, waybill_no, inc_day from dm_gis.tt_waybill_info where inc_day between '%s' and '%s'
UNION ALL
select consignee_mobile mobile, consignee_phone phone, regexp_replace(consignee_cont_name, '\\\\|,|\"|\n|\r|\t|\\s|，','') as name, regexp_replace(consignee_addr, '\\\\|,|\"|\n|\r|\t|\\s|，', '') addr, dest_province province, dest_dist_code city_code, dest_county county, consignee_comp_name company, '收件' action, signin_tm action_time, regexp_replace(split(signin_tm, ' ')[0],'-','') as action_date, waybill_no, inc_day from dm_gis.tt_waybill_info where inc_day between '%s' and '%s' and signer_name not like '%取消%'
) temp