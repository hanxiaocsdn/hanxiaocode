package com.sf.gis.scala.tals.app

import com.sf.gis.java.tals.util.StatUtils
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}

/**
 * Created by 01416344 on 2022/08/15.
 * 冰鉴二期
 * 描述：根据手机号和给定的日期，计算相关指标
 *
 */
object BingjianSampleConsigneeApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql = args.apply(0)
    val out_table1 = args.apply(1)
    val out_table2 = args.apply(2)

    val sampDf = spark.sql(int_sql)
    sampDf.show()
    sampDf.createGlobalTempView("order_consignee")

    /**
     * 自定义函数：isCompany
     */
    spark.udf.register("isCompany", (w1:String,w2:String ) => {
      var res = false
      val paternStr = "公司|集团|科技|有限|无限|责任"
      if ( (w1!=null && w1.nonEmpty && paternStr.r.findAllIn(w1).nonEmpty) || (w2!=null && w2.nonEmpty && paternStr.r.findAllIn(w2).nonEmpty) ) res = true
      res
    })
    /**
     * 自定义函数：isTMall
     */
    spark.udf.register("isTMall", (w1:String,w2:String ) => {
      var res = false
      val paternStr = "天猫"
      if ( (w1!=null && w1.nonEmpty && paternStr.r.findAllIn(w1).nonEmpty) || (w2!=null && w2.nonEmpty && paternStr.r.findAllIn(w2).nonEmpty) ) res = true
      res
    })
    /**
     * 自定义函数：isJD
     */
    spark.udf.register("isJD", (w1:String,w2:String ) => {
      var res = false
      val paternStr = "京东"
      if ( (w1!=null && w1.nonEmpty && paternStr.r.findAllIn(w1).nonEmpty) || (w2!=null && w2.nonEmpty && paternStr.r.findAllIn(w2).nonEmpty) ) res = true
      res
    })
    /**
     * 自定义函数：havePos
     */
    spark.udf.register("havePos", (w:String) => {
      var res = false
      val paternStr = "po(.*)机"
      if (w!=null && w.nonEmpty && paternStr.r.findAllIn(w.toLowerCase()).nonEmpty) res = true
      res
    })

    val rDf = spark.sql(
                    """
                      |select tel,apply_time,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-7),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and apply_time>=consigned_tm then 1 else 0 end ) as   consigned_cnt_7d,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-30),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and apply_time>=consigned_tm then 1 else 0 end ) as   consigned_cnt_30d,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and apply_time>=consigned_tm then 1 else 0 end ) as   consigned_cnt_90d,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and apply_time>=consigned_tm then 1 else 0 end ) as   consigned_cnt_180d,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-365),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and apply_time>=consigned_tm then 1 else 0 end ) as   consigned_cnt_365d,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-365),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and apply_time>=consigned_tm
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      |then 1 else 0 end ) as   consigned_cnt_365d_noSpecial,
                      |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-11),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-10),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d12m,
                      |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-10),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-9),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d11m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-9),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-8),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d10m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-8),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-7),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d9m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-7),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-6),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d8m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-6),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-5),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d7m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-5),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-4),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d6m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-4),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-3),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d5m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-3),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-2),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d4m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-2),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-1),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d3m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-1),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(apply_time,'yyyy-MM')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_d2m,
                      |  sum(case when unix_timestamp(apply_time,'yyyy-MM')=unix_timestamp(consigned_tm,'yyyy-MM')
                      | then 1 else 0 end ) as   consigned_cnt_d1m,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-11),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-10),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d12m_ts,
                      |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-10),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-9),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d11m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-9),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-8),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d10m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-8),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-7),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d9m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-7),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-6),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d8m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-6),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-5),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d7m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-5),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-4),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d6m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-4),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-3),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d5m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-3),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-2),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d4m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-2),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-1),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d3m_ts,
                      | sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp(apply_time,'yyyy-MM'),'yyyy-MM-dd HH:mm:ss'),-1),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(apply_time,'yyyy-MM')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d2m_ts,
                      |  sum(case when unix_timestamp(apply_time,'yyyy-MM')=unix_timestamp(consigned_tm,'yyyy-MM')
                      |and not (unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |)
                      | then 1 else 0 end ) as   consigned_cnt_d1m_ts,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and apply_time>=consigned_tm then 1 else 0 end ) as   consigned_cnt_one90d,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as   consigned_cnt_two90d,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-270),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |  then 1 else 0 end ) as   consigned_cnt_three90d,
                      |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-270),'yyyy-MM-dd')>unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |  then 1 else 0 end ) as   consigned_cnt_four90d,
                      |datediff(apply_time,max(consigned_tm)) as recent_days,
                      |sum(case when substr(signin_tm,12,2)>='06' and substr(signin_tm,12,2)<'12' then 1 else  0 end) as signin_tm_zs_cnt,
                      |sum(case when substr(signin_tm,12,2)>='12' and substr(signin_tm,12,2)<'18' then 1 else  0 end) as signin_tm_zw_cnt,
                      |sum(case when (substr(signin_tm,12,2)>='18' and substr(signin_tm,12,2)<'24') or (substr(signin_tm,12,2)>='00' and substr(signin_tm,12,2)<'06') then 1 else  0 end) as signin_tm_ws_cnt,
                      |sum(case when unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-1,'-06-30'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as consigned_cnt_618,
                      |sum(case when unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-11-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as consigned_cnt_1111,
                      |sum(case when unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | or unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-01'),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') and unix_timestamp(concat(cast(substr(apply_time,0,4) as int)-0,'-12-20'),'yyyy-MM-dd')>=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      | then 1 else 0 end ) as consigned_cnt_1212,
                      |sum(case when isCompany(consignor_cont_name,consignor_comp_name) then 0 else 1 end ) as consigned_cnt_person,
                      |sum(case when isCompany(consignor_cont_name,consignor_comp_name) then 1 else 0 end ) as consigned_cnt_company,
                      |sum(case when isTMall(consignor_cont_name,consignor_comp_name) then 1 else 0 end ) as consigned_cnt_tmall,
                      |sum(case when isJD(consignor_cont_name,consignor_comp_name) then 1 else 0 end ) as consigned_cnt_jd,
                      |sum(case when havePos(concat_ws(',', cons_name)) then 1 else 0 end ) as consigned_cnt_pos
                      |
                      |
                      |from global_temp.order_consignee
                      |
                      |where
                      |consigned_tm is not null and consigned_tm<>''
                      |and signin_tm is not null and signin_tm<>''
                      |and
                      |unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-365),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
                      |and apply_time>=consigned_tm
                      |
                      |group by tel,apply_time
                      |
                      |
                      |""".stripMargin)

    rDf.show()
    rDf.createGlobalTempView("stat_consignee")

    /**
     * 自定义函数： calculateStab
     */
    spark.udf.register("calculateStab", (x1:Int,x2:Int,x3:Int,x4:Int,x5:Int,x6:Int,x7:Int,x8:Int,x9:Int,x10:Int,x11:Int,x12:Int) => {
      var resOup:java.lang.Double = null
      if (null!=x1 && null!=x2 && null!=x3 && null!=x4 && null!=x5 && null!=x6 && null!=x7 && null!=x8 && null!=x9 && null!=x10 && null!=x11 && null!=x12 ) {
        val inputParam = Array[java.lang.Double](x1.toDouble, x2.toDouble, x3.toDouble, x4.toDouble, x5.toDouble, x6.toDouble, x7.toDouble, x8.toDouble, x9.toDouble, x10.toDouble, x11.toDouble, x12.toDouble)
        val stdevp = StatUtils.STDEVP(inputParam)
        val average = StatUtils.AVERAGE(inputParam)
        if (null != stdevp && null != average && average != 0) {
          resOup = stdevp / average
        }
      }
      resOup
    })

    // 近一年稳定性 recent_1y_stab
    val calDf = spark.sql(
      """
        |select
        |tel,apply_time,
        |calculateStab(consigned_cnt_d12m_ts,consigned_cnt_d11m_ts,consigned_cnt_d10m_ts,consigned_cnt_d9m_ts,consigned_cnt_d8m_ts,consigned_cnt_d7m_ts,consigned_cnt_d6m_ts,consigned_cnt_d5m_ts,consigned_cnt_d4m_ts,consigned_cnt_d3m_ts,consigned_cnt_d2m_ts,consigned_cnt_d1m_ts) as recent_1y_stab
        |
        |from global_temp.stat_consignee
        |""".stripMargin)
    calDf.show()
    calDf.createGlobalTempView("consignee_stab")



    /**
     * 自定义函数：haveConsignor
     */
    spark.udf.register("haveConsignor", (x1:Int,x2:Int,x3:Int,x4:Int,x5:Int,x6:Int,x7:Int,x8:Int,x9:Int,x10:Int,x11:Int,x12:Int) => {
      var resOup = 0
      if(x1>0) resOup = resOup + 1
      if(x2>0) resOup = resOup + 1
      if(x3>0) resOup = resOup + 1
      if(x4>0) resOup = resOup + 1
      if(x5>0) resOup = resOup + 1
      if(x6>0) resOup = resOup + 1
      if(x7>0) resOup = resOup + 1
      if(x8>0) resOup = resOup + 1
      if(x9>0) resOup = resOup + 1
      if(x10>0) resOup = resOup + 1
      if(x11>0) resOup = resOup + 1
      if(x12>0) resOup = resOup + 1
      resOup
    })

    // 月寄件最大，有寄件月份的个数
    val statDf1 = spark.sql(
      """
        |
        |
        |select
        |tel,apply_time,
        |sort_array(array(consigned_cnt_d12m,consigned_cnt_d11m,consigned_cnt_d10m,consigned_cnt_d9m,consigned_cnt_d8m,consigned_cnt_d7m,consigned_cnt_d6m,consigned_cnt_d5m,consigned_cnt_d4m,consigned_cnt_d3m,consigned_cnt_d2m,consigned_cnt_d1m))[11] as max_dm,
        |haveConsignor(consigned_cnt_d12m,consigned_cnt_d11m,consigned_cnt_d10m,consigned_cnt_d9m,consigned_cnt_d8m,consigned_cnt_d7m,consigned_cnt_d6m,consigned_cnt_d5m,consigned_cnt_d4m,consigned_cnt_d3m,consigned_cnt_d2m,consigned_cnt_d1m) as cnt_dm
        |
        |from global_temp.stat_consignee
        |
        |where consigned_cnt_365d>0
        |
        |""".stripMargin)

    statDf1.show()
    statDf1.createGlobalTempView("consignee_max_month")

    // 做left join
    val consigneeDf = spark.sql(
      """
        |
        |select
        |
        |t0.tel,t0.apply_time,
        |consigned_cnt_7d,consigned_cnt_30d,consigned_cnt_90d,consigned_cnt_180d,consigned_cnt_365d,consigned_cnt_365d_nospecial,consigned_cnt_d12m,consigned_cnt_d11m,consigned_cnt_d10m,
        |consigned_cnt_d9m,consigned_cnt_d8m,consigned_cnt_d7m,consigned_cnt_d6m,consigned_cnt_d5m,consigned_cnt_d4m,consigned_cnt_d3m,consigned_cnt_d2m,consigned_cnt_d1m,consigned_cnt_d12m_ts,consigned_cnt_d11m_ts,
        |consigned_cnt_d10m_ts,consigned_cnt_d9m_ts,consigned_cnt_d8m_ts,consigned_cnt_d7m_ts,consigned_cnt_d6m_ts,consigned_cnt_d5m_ts,consigned_cnt_d4m_ts,consigned_cnt_d3m_ts,consigned_cnt_d2m_ts,consigned_cnt_d1m_ts,
        |recent_1y_stab,
        |consigned_cnt_one90d,consigned_cnt_two90d,consigned_cnt_three90d,consigned_cnt_four90d,recent_days,signin_tm_zs_cnt,signin_tm_zw_cnt,signin_tm_ws_cnt,consigned_cnt_618,consigned_cnt_1111,consigned_cnt_1212,
        |consigned_cnt_person,consigned_cnt_company,consigned_cnt_tmall,consigned_cnt_jd,consigned_cnt_pos,
        |max_dm,cnt_dm
        |
        |from global_temp.stat_consignee as t0
        |left join global_temp.consignee_stab as t1
        |on t0.tel=t1.tel and t0.apply_time=t1.apply_time
        |left join global_temp.consignee_max_month  as t2
        |on t0.tel=t2.tel and t0.apply_time=t2.apply_time
        |
        |
        |""".stripMargin)

    consigneeDf.show()
    consigneeDf.repartition(10).write.mode(SaveMode.Overwrite).saveAsTable(out_table1)


    // 不同城市和城市等级
    val cityDf = spark.sql(
      """
        |select
        |tel,apply_time,dest_dist_code,count(1) as citycode_consignee_cnt
        |from global_temp.order_consignee
        |where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_time,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-365),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
        |and dest_dist_code is not null and dest_dist_code<>''
        |group by tel,apply_time,dest_dist_code
        |
        |""".stripMargin)

    cityDf.show()
    cityDf.repartition(10).write.mode(SaveMode.Overwrite).saveAsTable(out_table2)



    spark.stop()


  }





}
