package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.tals.method.MySfNetInteface
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD


/**
 * 经纬坐标查询AOI
 * 需求方：敖少良（01425243）
 * @author 张小琼 （01416344）
 * Created on 2023-03-17
 * 任务信息： 668258 行政村收派件_v2.0 | 926185 行政村收派件_new(基于dwd_waybill_info_dtl_di)
 *
 */

object VillageLatLngAoiApp {



  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val sparkInfo = SparkUtil.getSpark4GisBd(appName)
    val sparkSession = sparkInfo.getSession

    val int_sql = args.apply(0)
    val out_table = args.apply(1)
    val pall_num = args.apply(2).toInt

    // 读取输入数据
    println(int_sql)
    val inputDf = sparkSession.sql(int_sql)
    inputDf.show(10)

    // 调接口需求输入的rdd
    val inputRdd = inputDf.rdd.map(x => {
      val resJson = new JSONObject()
      resJson.put("aoi_code",x.getAs[String]("aoi_code"))
      resJson.put("lgt",x.getAs[String]("zx"))
      resJson.put("lat",x.getAs[String]("zy"))
      resJson.put("inc_day",x.getAs[String]("inc_day"))
      resJson.put("dist_code",x.getAs[String]("dist_code"))
      resJson
    })

    // 接口监控启动
    val invokeCnt = inputRdd.count()
    logger.error(s"调用服务，总行数：${invokeCnt}")
    val invokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01416344", "669219/929822", "village_classcode_waybill_xg_res(byApi)/是否进乡镇_小哥轨迹_跑接口", "经纬坐标查询AOI", MySfNetInteface.URL_LGTLATSEARCHAOI, "", invokeCnt, 40)


    // 分钟数限制跑接口
    val outRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession, inputRdd, MySfNetInteface.lgtlatSearchAOI , 40, "", pall_num)
    val resRdd = outRDD.map( x => {
      var resTuple = Tuple6[String, String, String, String, String, String]("","","","","","")
      var matchRes = ""

      val aoi_code = x.getString("aoi_code")
      val lgt = x.getString("lgt")
      val lat = x.getString("lat")
      val inc_day = x.getString("inc_day")
      val dist_code = x.getString("dist_code")

      val resJson = x.getJSONObject("lgtlatSearchAOI")
      if (null!=resJson && resJson.getInteger("code")==200) {
        val dataArray = resJson.getJSONArray("data")
        if (null != dataArray && dataArray.size() > 0) {
          import scala.util.control.Breaks._
          breakable {
            for (i <- 0 to dataArray.size() - 1) {
              val dataJson = dataArray.getJSONObject(i)
              if (null != dataJson && aoi_code.equals(dataJson.getString("aoiCode"))) {
                  matchRes = "1"
                  break
              }
            }
          }
        }
      }
      resTuple = Tuple6[String, String, String, String, String, String](
        aoi_code,
        lgt,
        lat,
        matchRes,
        inc_day,
        dist_code
      )
      resTuple

  })

    // 接口监控结束
    logger.error(s"调用服务完成，调用服务ID：${invokeId}")
    BdpTaskRecordUtil.endNetworkInterface("01416344", invokeId)


    // rdd转DF，输出到表中
    import sparkSession.implicits._
    val resDf = resRdd.toDF("aoi_code","lgt","lat","matchres","inc_day","dist_code").repartition(20)
    resDf.createTempView("village_latlngaoi")

    logger.error(s"写入分区表： ${out_table} ")
    val outputDf = sparkSession.sql(
      s"""
         |
         |insert overwrite table  ${out_table} partition(inc_day)
         |select
         |aoi_code,lgt,lat,max(matchres) as matchres,dist_code,inc_day
         |from village_latlngaoi
         |group by aoi_code,lgt,lat,dist_code,inc_day
         |
         |""".stripMargin)
    outputDf.repartition(10).show()

    sparkSession.stop()

    logger.error("任务结束。")

  }






}
