package com.sf.gis.scala.tals.app

import com.github.davidmoten.geo.GeoHash
import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.java.tals.util.CoordTransformUtils
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

import scala.collection.JavaConverters.asScalaBufferConverter

/**
 * 经纬坐标转换（百度转高德）
 * 需求方：敖少良（01425243）
 * @author 张小琼 （01416344）
 * Created on 2023-10-19
 * 任务信息： 668258  行政村收派件_v2.0
 *
 */

object VillageLonLatTransformApp {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    conf.set("hive.exec.dynamic.partition","true")
    conf.set("hive.exec.dynamic.partition.mode","nonstrict")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql = args.apply(0)
    val out_table = args.apply(1)
    val inc_day = args.apply(2)

    // 读取输入的经纬坐标数据
    val intDf = spark.sql(int_sql)
    intDf.createTempView("village_tb_01")
    intDf.show()

    // 注册函数
    registerFun(spark)

    // 坐标转换并输出到表
    logger.error(s"写入hive ${out_table}中...")

    val resDF = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table} partition(inc_day='${inc_day}')
         |select bd_lon,bd_lat,coordTransform(bd_lon,bd_lat) as gd_lon_lat from village_tb_01
         |
         |""".stripMargin)
    resDF.repartition(8).show()


    logger.error("spark任务结束")
    spark.stop()
  }


  /**
   * 自定义注册函数
   *
   */
  def registerFun(spark: SparkSession): Unit = {

    /**
     * 自定义函数：CoordTransform
     */
    spark.udf.register("coordTransform", (x: String, y: String) => {
      var res = ""
      if (null != x && x.length > 1 && null != y && y.length > 1) {
        val key = CoordTransformUtils.bd2gd(x.toDouble, y.toDouble)
        if (null != key) {
          res = key.get("lon") + "," + key.get("lat")
        }
      }
      res
    })

  }
}
