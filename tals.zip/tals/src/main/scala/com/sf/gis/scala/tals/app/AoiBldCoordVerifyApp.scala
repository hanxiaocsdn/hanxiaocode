package com.sf.gis.scala.tals.app

import com.github.davidmoten.geo.GeoHash
import com.sf.gis.java.base.util.GeometryUtil
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

import scala.collection.JavaConverters.asScalaBufferConverter

/**
 * create by 01416344(张小琼) on 2022/11/16
 * 小区楼栋坐标验证
 * 描述：对楼栋经纬坐标，通过运单经纬坐标验证
 */
object AoiBldCoordVerifyApp {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    conf.set("hive.exec.dynamic.partition","true")
    conf.set("hive.exec.dynamic.partition.mode","nonstrict")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql0 = args.apply(0)
    val int_sql1 = args.apply(1)
    val out_table1 = args.apply(2)
    val city_adcode = args.apply(3)
    val dis_param = args.apply(4).toDouble
    val min_freq = args.apply(5).toInt

    // 读取楼栋坐标数据
    val intDf0 = spark.sql(int_sql0)
    intDf0.createGlobalTempView("bld_tb00")
    intDf0.show()


    // 读取楼栋运单数据
    val intDf1 = spark.sql(int_sql1)
    intDf1.createGlobalTempView("bld_tb01")
    intDf1.show()


    // aoi_guid,bld_id 关联（bld_id不能为空）
    val tmpDF = spark.sql(
      """
        |select
        |t0.city_adcode,t0.aoi_guid,t0.aoi_name,t0.bld_id,t0.bld_name,t0.bld_no,t0.x_coord,t0.y_coord,
        |t1.xy_sp_set,t1.period
        |from
        |(select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,city_adcode
        |from global_temp.bld_tb00
        |where bld_id is not null and  bld_id<>'' and bld_id!='NULL') as t0
        |left join
        |global_temp.bld_tb01 as t1
        |on t0.city_adcode=t1.city_adcode and t0.aoi_guid=t1.aoi_id and t0.bld_id=t1.bld_id
        |
        |""".stripMargin)
    tmpDF.show()
    tmpDF.createGlobalTempView("bld_tb02")

    // 通过对aoi_guid,bld_no来关联
    val tmpDF1a = spark.sql(
      """
        |
        |select
        |t0.city_adcode,t0.aoi_guid,t0.aoi_name,t0.bld_id,t0.bld_name,t0.bld_no,t0.x_coord,t0.y_coord,
        |t1.xy_sp_set,t1.period
        |from
        |(select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,city_adcode
        |from global_temp.bld_tb00
        |where bld_no is not null and  bld_no<>'' and bld_no!='NULL' ) as t0
        |left join
        |global_temp.bld_tb01 as t1
        |on t0.city_adcode=t1.city_adcode and t0.aoi_guid=t1.aoi_id and t0.bld_no=t1.bld_no
        |
        |
        |""".stripMargin)
    tmpDF1a.show()
    tmpDF1a.createGlobalTempView("bld_tb02a")

    val tmpDF1b = spark.sql(
      """
        |
        |select
        |city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
        |xy_sp_set,period
        |from (
        |select
        |city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
        |xy_sp_set,period
        |from global_temp.bld_tb02
        |union all
        |select
        |city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
        |xy_sp_set,period
        |from global_temp.bld_tb02a
        |) as t
        |group by city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
        |xy_sp_set,period
        |
        |
        |""".stripMargin)
    tmpDF1b.show()
    tmpDF1b.createGlobalTempView("bld_tb02b")


    val tmpDF1 = spark.sql(
      """
        |select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
        |split(item,",")[0] as lng,split(item,",")[1] as lat,period  from (select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
        |xy_sp_set,period from global_temp.bld_tb02b where xy_sp_set is not null )  as t0
        |LATERAL VIEW explode(t0.xy_sp_set) adTable AS item
        |
        |""".stripMargin)
    tmpDF1.show()
    tmpDF1.createGlobalTempView("bld_tb03")

    /**
     * 自定义函数：runKey
     */
    spark.udf.register("runKey", (x:String,y:String,param:Int) => {
      var res = ""
      if (null!=x && x.length>1 && null!=y && y.length>1) {
        val key = GeoHash.encodeHash(y.toDouble, x.toDouble, param)
        if (null != key) {
          res = key
        }
      }
      res
    })

    /**
     * 自定义函数：getKeyNBS
     */
    spark.udf.register("getKeyNBS", (x:String,y:String,param:Int) => {
      var res = ""
      if (null!=x && x.length>1 && null!=y && y.length>1) {
        val key = GeoHash.encodeHash(y.toDouble, x.toDouble, param)
        if (null != key) {
          res = GeoHash.neighbours(key).toString
        }
      }
      res
    })

    /**
     * 自定义函数：判断是否在范围内
     */
    spark.udf.register("isContainKey", (x:String,y:String,param:Int,bldKey:String,eventKey:String,eventlng:String,eventlat:String,disParam:Double) => {
      var res = ""
      if (null!=bldKey && !"".equals(bldKey) && null!=eventKey && !"".equals(eventKey) && bldKey.equals(eventKey)){
        res = "y"
      }else {
        if (null!=bldKey && !"".equals(bldKey) && null!=eventKey && !"".equals(eventKey)) {
          if (null != x && x.length > 1 && null != y && y.length > 1) {
            val key = GeoHash.encodeHash(y.toDouble, x.toDouble, param)
            if (null != key) {
              val nbsList = GeoHash.neighbours(key).asScala.toList
              if (null != nbsList) {
                for (nbs <- nbsList) {
                  if ("".equals(res) && null != nbs && nbs.equals(eventKey)) {
                    res = "y"
                  }
                }
              }
            }
          }
        }
      }
      if ("".equals(res) && null!=x && x.length>1 && null!=y && y.length>1 && null!=eventlng && eventlng.length>1 && null!=eventlat && eventlat.length>1) {
        val distance = GeometryUtil.getDistance(GeometryUtil.createPointByWKT("POINT (" + x + " " + y + ")"),GeometryUtil.createPointByWKT("POINT (" + eventlng + " " + eventlat + ")")).toString
        if (null != distance && distance.toDouble<=disParam) {
          res = "y"
        }
      }
      res
    })



    val tmpDF2 = spark.sql(
      s"""
         |
         |select
         |x_coord,y_coord,
         |lng,lat,
         |isContainKey(x_coord,y_coord,8,runKey(x_coord,y_coord,8),runKey(lng,lat,8),lng,lat,${dis_param}) as rs_type
         |from
         |(select x_coord,y_coord,lng,lat
         |from
         |global_temp.bld_tb03
         |group by x_coord,y_coord,lng,lat
         |) as t
         |
         |""".stripMargin)

    tmpDF2.show()
    tmpDF2.createGlobalTempView("bld_tb04")

    // 统计楼栋关联运单坐标数量
    val tmpDF3 = spark.sql(
      """
        |select
        |city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
        |count(1) as freq
        |from (
        |select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,t0.x_coord,t0.y_coord,
        |rs_type
        |from global_temp.bld_tb03 as t0
        |left join
        |global_temp.bld_tb04 as t1
        |on t0.x_coord=t1.x_coord and t0.y_coord=t1.y_coord and t0.lng=t1.lng and t0.lat=t1.lat
        |) as t
        |group by city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord
        |
        |
        |""".stripMargin)
    tmpDF3.show()
    tmpDF3.createGlobalTempView("bld_tb05")

    // 统计楼栋满足rs_type='y'的个数
    val tmpDF3a = spark.sql(
      """
        |select
        |city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
        |rs_type,count(1) as verify_freq
        |from (
        |select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,t0.x_coord,t0.y_coord,
        |rs_type
        |from global_temp.bld_tb03 as t0
        |left join
        |global_temp.bld_tb04 as t1
        |on t0.x_coord=t1.x_coord and t0.y_coord=t1.y_coord and t0.lng=t1.lng and t0.lat=t1.lat
        |) as t
        |where rs_type='y'
        |group by city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,rs_type
        |
        |
        |""".stripMargin)
    tmpDF3a.show()
    tmpDF3a.createGlobalTempView("bld_tb05a")

    // 拼接两份数据
    val tmpDF4 = spark.sql(
      s"""
        |select
        |t0.city_adcode,t0.aoi_guid,t0.aoi_name,t0.bld_id,t0.bld_name,t0.bld_no,t0.x_coord,t0.y_coord,
        |t1.rs_type,t0.freq,t1.verify_freq
        |from global_temp.bld_tb05 as t0
        |left join
        |(select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,rs_type,verify_freq
        |from global_temp.bld_tb05a where verify_freq>=${min_freq} ) as t1
        |on t0.city_adcode=t1.city_adcode and t0.aoi_guid=t1.aoi_guid
        |and t0.aoi_name=t1.aoi_name and t0.bld_id=t1.bld_id and t0.bld_name=t1.bld_name and t0.bld_no=t1.bld_no and t0.x_coord=t1.x_coord and t0.y_coord=t1.y_coord
        |
        |""".stripMargin)
    tmpDF4.show()
    tmpDF4.createGlobalTempView("bld_tb06")

    logger.error(s"写入hive ${out_table1}中...")

    val resDF = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table1} partition(city_adcode='${city_adcode}')
         |select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,rs_type,freq,verify_freq from global_temp.bld_tb06
         |
         |""".stripMargin)
    resDF.repartition(8).show()

    logger.error(s"写入分区${city_adcode}成功")



//    // 对aoi_guid,bld_id关联未能验证通过的楼栋，再通过对aoi_guid,bld_no来关联验证
//    val tmpDF5 = spark.sql(
//      """
//        |
//        |select
//        |t0.aoi_guid,t0.aoi_name,t0.bld_id,t0.bld_name,t0.bld_no,t0.x_coord,t0.y_coord,t0.city_adcode
//        |from
//        |(select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,city_adcode
//        |from global_temp.bld_tb00
//        |where bld_no is not null and  bld_no<>'' and bld_no!='NULL') as t0
//        |left join (
//        |select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,city_adcode,rs_type from global_temp.bld_tb06 where rs_type='y'
//        |) as t1
//        |on t0.aoi_guid=t1.aoi_guid and t0.aoi_name=t1.aoi_name and t0.bld_id=t1.bld_id and t0.bld_name=t1.bld_name and t0.bld_no=t1.bld_no and t0.x_coord=t1.x_coord and t0.y_coord=t1.y_coord
//        |where t1.aoi_guid is null and t1.aoi_name is null
//        |
//        |
//        |""".stripMargin)
//    tmpDF5.show()
//    tmpDF5.createGlobalTempView("bld_tb07")
//
//    val tmpDF6 = spark.sql(
//      """
//        |select
//        |t0.city_adcode,t0.aoi_guid,t0.aoi_name,t0.bld_id,t0.bld_name,t0.bld_no,t0.x_coord,t0.y_coord,
//        |t1.xy_sp_set,t1.period
//        |from
//        |(select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,city_adcode
//        |from global_temp.bld_tb07 ) as t0
//        |left join
//        |global_temp.bld_tb01 as t1
//        |on t0.city_adcode=t1.city_adcode and t0.aoi_guid=t1.aoi_id and t0.bld_no=t1.bld_no
//        |
//        |""".stripMargin)
//    tmpDF6.show()
//    tmpDF6.createGlobalTempView("bld_tb08")
//
//    val tmpDF7 = spark.sql(
//      """
//        |select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
//        |split(item,",")[0] as lng,split(item,",")[1] as lat,period  from (select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
//        |xy_sp_set,period from global_temp.bld_tb08 where xy_sp_set is not null )  as t0
//        |LATERAL VIEW explode(t0.xy_sp_set) adTable AS item
//        |
//        |""".stripMargin)
//    tmpDF7.show()
//    tmpDF7.createGlobalTempView("bld_tb09")
//
//    val tmpDF8 = spark.sql(
//      s"""
//         |
//         |select
//         |x_coord,y_coord,
//         |lng,lat,
//         |isContainKey(x_coord,y_coord,8,runKey(x_coord,y_coord,8),runKey(lng,lat,8),lng,lat,${dis_param}) as rs_type
//         |from
//         |(select x_coord,y_coord,lng,lat
//         |from
//         |global_temp.bld_tb09
//         |group by x_coord,y_coord,lng,lat
//         |) as t
//         |
//         |""".stripMargin)
//
//    tmpDF8.show()
//    tmpDF8.createGlobalTempView("bld_tb010")
//
//    val tmpDF9 = spark.sql(
//      """
//        |
//        |select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,t0.x_coord,t0.y_coord,
//        |rs_type
//        |from global_temp.bld_tb09 as t0
//        |left join
//        |global_temp.bld_tb010 as t1
//        |on t0.x_coord=t1.x_coord and t0.y_coord=t1.y_coord and t0.lng=t1.lng and t0.lat=t1.lat
//        |
//        |""".stripMargin)
//    tmpDF9.show()
//    tmpDF9.createGlobalTempView("bld_tb011")
//
//    val tmpDF9a = spark.sql(
//      """
//        |
//        |select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
//        |rs_type,count(1) as freq
//        |from global_temp.bld_tb011
//        |group by city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,
//        |rs_type
//        |
//        |""".stripMargin)
//    tmpDF9a.show()
//    tmpDF9a.createGlobalTempView("bld_tb011a")
//
//
//    val tmpDF10 = spark.sql(
//      """
//        |
//        |select
//        |city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,rs_type
//        |from (
//        |select city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,rs_type,
//        |row_number() over(partition by city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord
//        |order by  case when rs_type is null or rs_type='' then 'zzz' else rs_type end asc) as rn
//        |from global_temp.bld_tb011a
//        |) as t where t.rn=1
//        |
//        |""".stripMargin)
//    tmpDF10.show()
//    tmpDF10.createGlobalTempView("bld_tb012")

//    val tmpDF11 = spark.sql(
//      """
//        |select
//        |city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,rs_type
//        |from
//        |(
//        |select
//        |city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,rs_type,
//        |row_number() over(partition by city_adcode,aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord
//        |order by  case when rs_type is null or rs_type='' then 'zzz' else rs_type end asc) as rn
//        |from
//        |(
//        |select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,city_adcode,rs_type from global_temp.bld_tb06
//        |union all
//        |select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,city_adcode,rs_type from global_temp.bld_tb012
//        |) as t ) as t0 where t0.rn=1
//        |
//        |
//        |""".stripMargin)
//    tmpDF11.show()
//    tmpDF11.createGlobalTempView("bld_tb013")



//    logger.error(s"写入hive ${out_table1}中...")
//
//    val resDF = spark.sql(
//      s"""
//         |
//         |insert overwrite table ${out_table1} partition(city_adcode='${city_adcode}')
//         |select aoi_guid,aoi_name,bld_id,bld_name,bld_no,x_coord,y_coord,rs_type from global_temp.bld_tb013
//         |
//         |""".stripMargin)
//    resDF.repartition(8).show()
//
//    logger.error(s"写入分区${city_adcode}成功")


    logger.error("spark任务结束")
    spark.stop()
  }
}
