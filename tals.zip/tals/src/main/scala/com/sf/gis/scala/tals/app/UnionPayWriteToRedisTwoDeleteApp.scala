package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{HttpConnection, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util

/**
 * Created by 01416344 on 2022/01/04.
 * 银联电话地址数据删除时间超半年数据
 */

object UnionPayWriteToRedisTwoDeleteApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  //测试
//  val URL = "http://gis-int.intsit.sfdc.com.cn:1080/unionpay/api/del"
//  val AK = "50e1947c655747f18b7649e7001bd026"
  //生产
  val URL = "http://gis-int.int.sfdc.com.cn:1080/unionpay/api/del"
  val AK = "e7e0666ab27443f9a88a63b97993195b"


  def main(args: Array[String]): Unit = {

    /**
     * json:
      *{
        *"ak":"8bb09e5e110845f39a000391668e3e80",
        *"addr":"深圳市软件产业基地5E",
        *"phone":"7d9f41baaf5936cfc57d7b0e0fc85bdf",
        *"time":1638180550
      *}
     */

    val  halfTime = args(0)
    val  parNum = args(1).toInt  //并行度

    val sparkInfo = SparkUtil.getSpark(appName)
    val spark = sparkInfo.getSession

    var tmpSql =
      s"""
        |insert overwrite table dm_gis.tel_addr_unionpay_tmp2
        |select tel_md5 from dm_gis.tel_addr_unionpay_tmp1 where action_date>'$halfTime' group by tel_md5
        |""".stripMargin

    println(tmpSql)

    val DF = spark.sql(tmpSql).repartition(10).persist(StorageLevel.MEMORY_AND_DISK)
    DF.show(10,false)

    val querySql =
      s"""
         |select a.tel_md5,citycode,addr,action,action_time from
         |(
         |select tel_md5,citycode,addr,action,action_time from dm_gis.tel_addr_unionpay_tmp1 where action_date='$halfTime'
         |) as a
         |left join  dm_gis.tel_addr_unionpay_tmp2 as b
         |on a.tel_md5=b.tel_md5
         |where b.tel_md5 is null
         |""".stripMargin
    println(querySql)

    val sourDf = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK)


//    val parNum = 1  //并行度
//    val sparkConf = new SparkConf().setMaster("local[1]").setAppName(appName)
//    val spark = SparkSession.builder().config(sparkConf).getOrCreate()
//
//    val df = spark.read.format("csv")
//      .option("delimiter", "|")
//      .load("./tals/data/unionPayDel.txt")
//      .toDF("x0","tel_md5","citycode","addr","action","action_time","x1")
//
//    import spark.implicits._
//    val sourDf = df.select("tel_md5","citycode","addr","action","action_time")
//      .map( item => Tuple5(item(0).toString.trim,item(1).toString.trim,item(2).toString.trim,item(3).toString.trim,item(4).toString.trim) )
//      .toDF("tel_md5","citycode","addr","action","action_time")



    val colList = sourDf.columns
    val keyMap = new util.HashMap[String, String]
    for(column <- colList){
        column match {
          case "tel_md5" => keyMap.put(column, "phone")
          case "citycode" => keyMap.put(column, "citycode")
          case "addr" => keyMap.put(column, "addr")
          case "action" => keyMap.put(column, "action")
          case "action_time" => keyMap.put(column, "actionTime")
        }
    }

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("ak", AK)
      for (columns <- colList) {
        if (!"action_time".equals(columns)){
          jsonObj.put(keyMap.get(columns), obj.getAs[String](columns))
        }else{
          val actionTimeStr = obj.getAs[String](columns)
          if (!actionTimeStr.isEmpty) {
            val simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            jsonObj.put(keyMap.get(columns), simpleDateFormat.parse(actionTimeStr).getTime / 1000)
          }else{
            jsonObj.put(keyMap.get(columns), 0)
          }
        }
      }
//      jsonObj.toJSONString
      HttpConnection.httpPost(3, URL, jsonObj.toJSONString)
    })

    logger.error(s"数据量:${sourRdd.count()}")

    spark.stop()


  }

}
