package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{HttpConnection, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util

/**
 * Created by 01416344 on 2022/02/11.
 * 武汉KV库天汇总数据写入redis
 */

object WuHanKvWriteToRedisAppTest {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  //测试
  val URL = "http://gis-int.intsit.sfdc.com.cn:1080/unionpay/api/addDeliFrequency"
  val AK = "0376a9aa84724dd2a995f858dd963346"



  def main(args: Array[String]): Unit = {

    /**
     * json:
        {
        "ak":"申请AK",
        "roomId":"47F5046C369811EBA3130F2334609108",
        "type":"l_fj",
        "period":"20220117",
        "cityCode":"028",
        "freq":"12"
        }
     */


    val parNum = 1  //并行度
    val sparkConf = new SparkConf().setMaster("local[1]").setAppName(appName)
    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    val df = spark.read.format("csv")
      .option("delimiter", "|")
      .load("./tals/data/wuhanKvDay.txt")
      .toDF("x0","room_id","count","adcode","src","city_code","period","x1")

    import spark.implicits._
    val sourDf = df.select("room_id","count","src","city_code","period")
      .map( item => Tuple5(item(0).toString.trim,item(1).toString.trim,item(2).toString.trim,item(3).toString.trim,item(4).toString.trim) )
      .toDF("room_id","count","src","city_code","period")

    val colList = sourDf.columns
    val keyMap = new util.HashMap[String, String]
    for(column <- colList){
        column match {
          case "room_id" => keyMap.put(column, "roomId")
          case "src" => keyMap.put(column, "type")
          case "period" => keyMap.put(column, "period")
          case "city_code" => keyMap.put(column, "cityCode")
          case "count" => keyMap.put(column, "freq")
        }
    }

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("ak", AK)
      for (columns <- colList) {
        jsonObj.put(keyMap.get(columns), obj.getAs[String](columns))
      }
      println(jsonObj.toJSONString)
      jsonObj.toJSONString
      HttpConnection.httpPost(3, URL, jsonObj.toJSONString)
    })

    logger.error(s"数据量:${sourRdd.count()}")

    spark.stop()


  }

}
