package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil}
import com.sf.gis.java.tals.util.CoordTransformUtils
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.tals.method.MySfNetInteface
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


/**
 * 仓管家坐标转换并跑接口判断是否上门
 * 需求方：敖少良（01425243）
 * @author 张小琼 （01416344）
 * Created on 2023-12-26
 * 任务信息： FLOW ID：926185 行政村收派件_new(基于dwd_waybill_info_dtl_di)  TASK ID：954578 仓管家2_坐标转换与跑接口
 *
 */

object VillageLatLngCgjRadius500App {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc", "true")
    conf.set("hive.exec.dynamic.partition", "true")
    conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    val sparkSession = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    sparkSession.sparkContext.setLogLevel("ERROR")

    val int_sql = args.apply(0)
    val out_table = args.apply(1)
    val pall_num = args.apply(2).toInt
    val inc_day = args.apply(3)

    // 读取输入数据
    println(int_sql)
    val inputDf = sparkSession.sql(int_sql)
    inputDf.createTempView("village_cgj_01")
    inputDf.show(10)

    // 注册函数
    registerFun(sparkSession)

    // 坐标转换
    val transDf = sparkSession.sql(
      """
        |select waybill_no,class_code,vilcode,src_dist_code,coordTransform(cgj_longitude,cgj_latitude) as gd_lon_lat  from village_cgj_01
        |
        |""".stripMargin
    )
    transDf.createTempView("village_cgj_02")
    val trans1Df = sparkSession.sql(
      """
        |select waybill_no,class_code,vilcode,src_dist_code,split(gd_lon_lat,',')[0] as cgj_longitude,split(gd_lon_lat,',')[1] as cgj_latitude from village_cgj_02
        |
        |""".stripMargin
    )
    trans1Df.createTempView("village_cgj_03")
    val trans2Df = sparkSession.sql(
      """
        |select vilcode,cgj_longitude,cgj_latitude from village_cgj_03
        |where
        |class_code in ('220','210') and vilcode is not null and vilcode<>'' and cgj_longitude is not null and cgj_longitude<>'' and cgj_latitude is not null and cgj_latitude<>''
        |group by vilcode,cgj_longitude,cgj_latitude
        |
        |""".stripMargin
    )


    // 调接口需求输入的rdd
    val inputRdd = trans2Df.rdd.map(x => {
      val resJson = new JSONObject()
      resJson.put("vilcode", x.getAs[String]("vilcode"))
      resJson.put("zx", x.getAs[String]("cgj_longitude"))
      resJson.put("zy", x.getAs[String]("cgj_latitude"))
      resJson
    })

    // 接口监控启动
    val invokeCnt = inputRdd.count()
    logger.error(s"调用服务，总行数：${invokeCnt}")
    val invokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01416344", "954578", "仓管家2_坐标转换与跑接口", "经纬坐标查询行政村", MySfNetInteface.URL_LATLNG_VILLAGE_RADIUS, "", invokeCnt, 20)


    // 分钟数限制跑接口
    val outRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession, inputRdd, MySfNetInteface.latLngVillageRadius500, 20, "", pall_num)
    val resRdd = outRDD.map(x => {
      var resTuple = Tuple4[String, String, String, String]("", "", "",  "")
      var matchRes = ""

      val vilcode = x.getString("vilcode")
      val lon = x.getString("zx")
      val lat = x.getString("zy")

      val resJson = x.getJSONObject("latLngVillageRadius500")
      if (null != resJson && resJson.getBoolean("success") == true) {
        val dataArray = resJson.getJSONArray("data")
        if (null != dataArray && dataArray.size() > 0) {
          import scala.util.control.Breaks._
          breakable {
            for (i <- 0 to dataArray.size() - 1) {
              val dataJson = dataArray.getJSONObject(i)
              if (null != dataJson && vilcode.equals(dataJson.getString("areaCode"))) {
                matchRes = "1"
                break
              }
            }
          }
        }
      }
      resTuple = Tuple4[String, String, String, String](
        vilcode,
        lon,
        lat,
        matchRes
      )
      resTuple
    })

    // 接口监控结束
    logger.error(s"调用服务完成，调用服务ID：${invokeId}")
    BdpTaskRecordUtil.endNetworkInterface("01416344", invokeId)

    // rdd转DF，输出到表中
    import sparkSession.implicits._
    val resDf = resRdd.toDF("vilcode", "cgj_longitude", "cgj_latitude", "cgj_match")
    resDf.createTempView("village_cgj_radius")

    logger.error(s"写入分区表： ${out_table} ")
    val outputDf = sparkSession.sql(
      s"""
         |insert overwrite table ${out_table} partition(inc_day='${inc_day}')
         |select waybill_no,class_code,t0.vilcode,src_dist_code,t0.cgj_longitude,t0.cgj_latitude,cgj_match
         |from (select waybill_no,class_code,vilcode,src_dist_code,cgj_longitude,cgj_latitude from  village_cgj_03 ) as t0
         |left join (select vilcode,cgj_longitude,cgj_latitude,cgj_match from village_cgj_radius) as t1
         |on t0.vilcode=t1.vilcode and t0.cgj_longitude=t1.cgj_longitude and t0.cgj_latitude=t1.cgj_latitude
         |
         |""".stripMargin)
    outputDf.repartition(10).show()


    sparkSession.stop()

    logger.error("任务结束。")

  }





  /**
   * 自定义注册函数
   * 描述：GPS坐标转高德坐标
   */
  def registerFun(spark: SparkSession): Unit = {

    /**
     * 自定义函数：CoordTransform
     */
    spark.udf.register("coordTransform", (x: String, y: String) => {
      var res = ""
      if (null != x && !"".equals(x.trim) && null != y && !"".equals(y.trim)) {
        val key = CoordTransformUtils.wgs84ToGcj02(x.toDouble, y.toDouble)
        if (null != key) {
          res = key.get("lon") + "," + key.get("lat")
        }
      }
      res
    })

  }

}
