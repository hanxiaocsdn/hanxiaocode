package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.tals.method.MySfNetInteface
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD


/**
 * 经纬坐标查询行政村
 * 需求方：敖少良（01425243）
 * @author 张小琼 （01416344）
 * Created on 2023-04-28
 * 任务信息： 668258 行政村收派件_v2.0 | 926185 行政村收派件_new(基于dwd_waybill_info_dtl_di)
 *
 */

object VillageLatLngVillageRadiusApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val sparkInfo = SparkUtil.getSpark4GisBd(appName)
    val sparkSession = sparkInfo.getSession

    val int_sql = args.apply(0)
    val out_table = args.apply(1)
    val pall_num = args.apply(2).toInt

    // 读取输入数据
    println(int_sql)
    val inputDf = sparkSession.sql(int_sql)
    inputDf.show(10)

   // 调接口需求输入的rdd
    val inputRdd = inputDf.rdd.map(x => {
      val resJson = new JSONObject()
      resJson.put("vilcode",x.getAs[String]("vilcode"))
      resJson.put("operate_longitude",x.getAs[String]("operate_longitude"))
      resJson.put("operate_latitude",x.getAs[String]("operate_latitude"))
      resJson.put("dist_code",x.getAs[String]("dist_code"))
      resJson.put("inc_day",x.getAs[String]("inc_day"))
      resJson
    })

    // 接口监控启动
    val invokeCnt = inputRdd.count()
    logger.error(s"调用服务，总行数：${invokeCnt}")
    val invokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01416344", "735516/735517", "village_dest_owncode_isnotnull_api_res(byApi)", "经纬坐标查询行政村", MySfNetInteface.URL_LATLNG_VILLAGE_RADIUS, "", invokeCnt, 20)


    // 分钟数限制跑接口
    val outRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession, inputRdd, MySfNetInteface.latLngVillageRadius , 20, "", pall_num)
    val resRdd = outRDD.map( x => {
      var resTuple = Tuple6[String,String,String,String,String,String]("","","","","","")
      var matchRes = ""

      val vilcode = x.getString("vilcode")
      val operate_longitude = x.getString("operate_longitude")
      val operate_latitude = x.getString("operate_latitude")
      val dist_code = x.getString("dist_code")
      val inc_day = x.getString("inc_day")

      val resJson = x.getJSONObject("latLngVillageRadius")
      if (null!=resJson && resJson.getBoolean("success")==true) {
        val dataArray = resJson.getJSONArray("data")
        if (null != dataArray && dataArray.size() > 0) {
          import scala.util.control.Breaks._
          breakable {
            for (i <- 0 to dataArray.size() - 1) {
              val dataJson = dataArray.getJSONObject(i)
              if (null != dataJson && vilcode.equals(dataJson.getString("areaCode"))) {
                matchRes = "1"
                break
              }
            }
          }
        }
      }
      resTuple = Tuple6[String, String, String, String, String, String](
        vilcode,
        operate_longitude,
        operate_latitude,
        matchRes,
        dist_code,
        inc_day
      )
      resTuple
    })

    // 接口监控结束
    logger.error(s"调用服务完成，调用服务ID：${invokeId}")
    BdpTaskRecordUtil.endNetworkInterface("01416344", invokeId)

    // rdd转DF，输出到表中
    import sparkSession.implicits._
    val resDf = resRdd.toDF("vilcode","operate_longitude","operate_latitude","match_res","dist_code","inc_day")
    resDf.createTempView("village_latlngvillageradius")

    logger.error(s"写入分区表： ${out_table} ")
    val outputDf = sparkSession.sql(
      s"""
         |insert overwrite table  ${out_table} partition(inc_day)
         |select
         |vilcode,operate_longitude,operate_latitude,match_res,dist_code,inc_day
         |from village_latlngvillageradius
         |
         |""".stripMargin)
    outputDf.repartition(10).show()

    sparkSession.stop()

    logger.error("任务结束。")

  }

}
