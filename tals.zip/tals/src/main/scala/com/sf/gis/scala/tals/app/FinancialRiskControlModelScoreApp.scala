package com.sf.gis.scala.tals.app

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
 * Created by 01416344 on 2022/12/16.
 * 金融风控评分接口数据
 * 描述：计算模型得分
 *
 */
object FinancialRiskControlModelScoreApp {
//
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//  val logger: Logger = Logger.getLogger(appName)
//
//  def main(args: Array[String]): Unit = {
//
//    val conf = new SparkConf()
//    conf.setAppName(appName)
//    conf.set("spark.sql.adaptive.enabled", "true")
//    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
//    conf.set("spark.sql.adaptive.join.enabled", "true")
//    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
//    conf.set("spark.sql.hive.convertMetastoreOrc","true")
//    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
//    spark.sparkContext.setLogLevel("ERROR")
//
//
//    val int_sql1 = args.apply(0)
//    val out_table1 = args.apply(1)
//    val id = args.apply(2)
//    val inc_day = args.apply(3) //格式 yyyyMMdd
//
//    logger.error(s"int_sql1: ${int_sql1}")
//    logger.error(s"inc_day: ${inc_day}")
//
//    val inputDf = spark.sql(int_sql1)
//    inputDf.show(10)
//
//
//    spark.sql("set spark.sql.legacy.allowUntypedScalaUDF=true")
//    val dframe1 = inputDf.withColumnRenamed("tel_md5","tel_md5")
//      .withColumnRenamed("consigned_cnt_7d","jj_最近7天")
//      .withColumnRenamed("consigned_cnt_30d", "jj_最近1个月")
//      .withColumnRenamed("consigned_cnt_90d", "jj_最近3个月")
//      .withColumnRenamed("consigned_cnt_180d", "jj_最近半年")
//      .withColumnRenamed("consigned_cnt_365d", "jj_最近一年")
//      .withColumnRenamed("consigned_cnt_365d_nospecial", "jj_最近1年（剔除特殊时间）")
//      .withColumnRenamed("consigned_cnt_d12m", "jj_第12月")
//      .withColumnRenamed("consigned_cnt_d11m", "jj_第11月")
//      .withColumnRenamed("consigned_cnt_d10m", "jj_第10月")
//      .withColumnRenamed("consigned_cnt_d9m", "jj_第9月")
//      .withColumnRenamed("consigned_cnt_d8m", "jj_第8月")
//      .withColumnRenamed("consigned_cnt_d7m", "jj_第7月")
//      .withColumnRenamed("consigned_cnt_d6m", "jj_第6月")
//      .withColumnRenamed("consigned_cnt_d5m", "jj_第5月")
//      .withColumnRenamed("consigned_cnt_d4m", "jj_第4月")
//      .withColumnRenamed("consigned_cnt_d3m", "jj_第3月")
//      .withColumnRenamed("consigned_cnt_d2m", "jj_第2月")
//      .withColumnRenamed("consigned_cnt_d1m", "jj_第1月")
//      .withColumnRenamed("consigned_cnt_one90d", "jj_第一90")
//      .withColumnRenamed("consigned_cnt_two90d", "jj_第二90")
//      .withColumnRenamed("d1d2_growth", "jj_第一第二增长率")
//      .withColumnRenamed("consigned_cnt_three90d", "jj_第三90")
//      .withColumnRenamed("d2d3_growth", "jj_第二第三增长率")
//      .withColumnRenamed("consigned_cnt_four90d", "jj_第四90")
//      .withColumnRenamed("d3d4_growth", "jj_第三第四增长率")
//      .withColumnRenamed("recent_days", "jj_最近一次天数")
//      .withColumnRenamed("consignor_tm_zs_cnt", "jj_早")
//      .withColumnRenamed("consignor_tm_zw_cnt", "jj_中")
//      .withColumnRenamed("consignor_tm_ws_cnt", "jj_晚")
//      .withColumnRenamed("consigned_cnt_618", "jj_618")
//      .withColumnRenamed("consigned_cnt_1111", "jj_1111")
//      .withColumnRenamed("consigned_cnt_1212", "jj_1212")
//      .withColumnRenamed("consigned_cnt_person", "jj_个人")
//      .withColumnRenamed("consigned_cnt_company", "jj_企业")
//      .withColumnRenamed("consigned_cnt_tmall", "jj_天猫")
//      .withColumnRenamed("consigned_cnt_jd", "jj_京东")
//      .withColumnRenamed("consigned_cnt_pos", "jj_pos机")
//      .withColumnRenamed("max_dm", "jj_最大月份")
//      .withColumnRenamed("cnt_dm", "jj_有月份的个数")
//      .withColumnRenamed("city_cnt", "jj_城市数")
//      .withColumnRenamed("city_level", "jj_城市等级")
//      .withColumnRenamed("consignee_cnt_7d", "sj_最近7天")
//      .withColumnRenamed("consignee_cnt_30d", "sj_最近1个月")
//      .withColumnRenamed("consignee_cnt_90d", "sj_最近3个月")
//      .withColumnRenamed("consignee_cnt_180d", "sj_最近半年")
//      .withColumnRenamed("consignee_cnt_365d", "sj_最近1年")
//      .withColumnRenamed("consignee_cnt_365d_nospecial", "sj_最近1年（剔除特殊时间）")
//      .withColumnRenamed("consignee_cnt_d12m", "sj_第12月")
//      .withColumnRenamed("consignee_cnt_d11m", "sj_第11月")
//      .withColumnRenamed("consignee_cnt_d10m", "sj_第10月")
//      .withColumnRenamed("consignee_cnt_d9m", "sj_第9月")
//      .withColumnRenamed("consignee_cnt_d8m", "sj_第8月")
//      .withColumnRenamed("consignee_cnt_d7m", "sj_第7月")
//      .withColumnRenamed("consignee_cnt_d6m", "sj_第6月")
//      .withColumnRenamed("consignee_cnt_d5m", "sj_第5月")
//      .withColumnRenamed("consignee_cnt_d4m", "sj_第4月")
//      .withColumnRenamed("consignee_cnt_d3m", "sj_第3月")
//      .withColumnRenamed("consignee_cnt_d2m", "sj_第2月")
//      .withColumnRenamed("consignee_cnt_d1m", "sj_第1月")
//      .withColumnRenamed("consignee_cnt_d12m_ts", "sj_第12月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d11m_ts", "sj_第11月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d10m_ts", "sj_第10月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d9m_ts", "sj_第9月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d8m_ts", "sj_第8月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d7m_ts", "sj_第7月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d6m_ts", "sj_第6月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d5m_ts", "sj_第5月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d4m_ts", "sj_第4月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d3m_ts", "sj_第3月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d2m_ts", "sj_第2月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d1m_ts", "sj_第1月(剔除特殊时间)")
//      .withColumnRenamed("recent_1y_stab", "sj_近1年的收快递稳定性(剔除特殊时间)")
//      .withColumnRenamed("signin_tm_zs_cnt", "sj_早")
//      .withColumnRenamed("signin_tm_zw_cnt", "sj_中")
//      .withColumnRenamed("signin_tm_ws_cnt", "sj_晚")
//      .withColumnRenamed("consignee_cnt_618", "sj_618")
//      .withColumnRenamed("consignee_cnt_1111", "sj_1111")
//      .withColumnRenamed("consignee_cnt_1212", "sj_1212")
//      .withColumnRenamed("consignee_cnt_tmall", "sj_天猫")
//      .withColumnRenamed("consignee_cnt_jd", "sj_京东")
//      .withColumnRenamed("consignee_cnt_pos", "sj_pos机")
//      .withColumnRenamed("consignee_max_dm", "sj_最大月份")
//      .withColumnRenamed("consignee_cnt_dm", "sj_有收件的月个数")
//      .withColumnRenamed("consignee_city_cnt", "sj_城市数")
//
//    // 加载模型
//    var model = loadModel("all_xgb_model_B_1011.xml")
//    // 模型预测
//    var resDs:DataFrame = model.transform(dframe1).withColumnRenamed("probability(1)", "m1s")
//
//    model = loadModel("model_1102.xml")
//    resDs = model.transform(resDs).withColumnRenamed("probability(1)", "m2s")
//
//    model = loadModel("model_1103.xml")
//    resDs = model.transform(resDs).withColumnRenamed("probability(1)", "m3s")
//
//    model = loadModel("model1.xml")
//    resDs = model.transform(resDs).withColumnRenamed("probability(1)", "m4s")
//
//    model = loadModel("model2.xml")
//    resDs = model.transform(resDs).withColumnRenamed("probability(1)", "m5s")
//
//    model = loadModel("model3.xml")
//    resDs = model.transform(resDs).withColumnRenamed("probability(1)", "m6s")
//
//    val resDF = resDs.select("tel_md5","m1s","m2s","m3s","m4s","m5s","m6s")
//    resDF.createTempView("frc_modelscore_res")
//
//    logger.error(s"写入hive  ${out_table1}  中...")
//    val resOutDF = spark.sql(
//      s"""
//         |
//         |insert overwrite table ${out_table1} partition(inc_day='${inc_day}',id='${id}')
//         |select
//         |tel_md5,m1s,m2s,m3s,m4s,m5s,m6s
//         |from frc_modelscore_res
//         |
//         |""".stripMargin)
//    resOutDF.repartition(20).show()
//    logger.error(s"写入分区 inc_day='${inc_day}',id='${id}' 成功")
//
//    logger.error("任务结束")
//    spark.stop()
//
//
//  }
//
//  /**
//   * 加载pmml模型(已转换为xml格式)
//   * @param fileName
//   * @return
//   */
//  def loadModel(fileName:String): Transformer ={
//    // Load the PMML
//    val pmmlIs = FinancialRiskControlModelScoreApp.getClass.getClassLoader.getResourceAsStream(fileName)
//    // Create the evaluator
//    val evaluator = new LoadingModelEvaluatorBuilder()
//      .load(pmmlIs)
//      .build()
//    // Create the transformer
//    var pmmlTransformer = new TransformerBuilder(evaluator)
//      .withTargetCols
//      .withOutputCols
//      .exploded(true)
//      .build()
//    pmmlTransformer
//  }
//
}
