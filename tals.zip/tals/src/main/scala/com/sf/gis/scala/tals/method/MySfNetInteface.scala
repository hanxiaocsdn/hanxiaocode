package com.sf.gis.scala.tals.method

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.constant.InfConstant
import com.sf.gis.java.base.util.{HttpConnection, HttpInvokeUtil}
import com.sf.gis.java.tals.util.MyHttpConnection
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger

import java.net.URLEncoder
import java.util
import java.util.{Calendar, Date}

/**
 * Created by 01416344 on 2022/7/25.
 */
object MySfNetInteface {


  // 测试  seg服务地址分词接口
//  val AK_SEG = "373efa25370241b1a58d8c4eefa50b90"
//  val URL_SEG = "http://gis-int.intsit.sfdc.com.cn:1080/seg/api/split?ak=%s&address=%s&citycode=%s&orderno=123456&level=4&showcode=1"

  // 生产  seg服务地址分词接口
  val AK_SEG = "75c79782e0da46e79866bdb790eb04a1"
  val URL_SEG = "http://gis-int.int.sfdc.com.cn:1080/seg/api/split?ak=%s&address=%s&citycode=%s&orderno=123456&level=4&showcode=1"

  // 测试  调用geo服务地理编码接口
//  val AK_GEO = "373efa25370241b1a58d8c4eefa50b90"
//  val URL_GEO = "http://gis-int.intsit.sfdc.com.cn:1080/geo/api?ak=%s&address=%s&city=%s&cc=1"

  // 生产  调用geo服务地理编码接口
    val AK_GEO = "75c79782e0da46e79866bdb790eb04a1"
    val URL_GEO = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?ak=%s&address=%s&city=%s&cc=1"

  // 测试  地址分词微服务接口
//    val AK_SPLIT = "373efa25370241b1a58d8c4eefa50b90"
//    val URL_SPLIT = "http://gis-int.intsit.sfdc.com.cn:1080/split/api?ak=%s&address=%s&citycode=%s"

  // 生产  地址分词微服务接口
  val AK_SPLIT = "75c79782e0da46e79866bdb790eb04a1"
  val URL_SPLIT = "http://gis-int.int.sfdc.com.cn:1080/split/api?ak=%s&address=%s&citycode=%s"

//  // 测试  经纬度解析行政区划接口
//      val AK_LGTLAT_ADCODE = "373efa25370241b1a58d8c4eefa50b90"
//      val URL_LGTLAT_ADCODE = "http://gis-int.intsit.sfdc.com.cn:1080/adcode/api/querybatchadcode?opt=GetBatchAdcode&cc=1&xy=%s&ak=%s"

  // 生产  经纬度解析行政区划接口
  val AK_LGTLAT_ADCODE = "75c79782e0da46e79866bdb790eb04a1"
  val URL_LGTLAT_ADCODE = "http://gis-int.int.sfdc.com.cn:1080/adcode/api/querybatchadcode?opt=GetBatchAdcode&cc=1&xy=%s&ak=%s"


//  // 测试  计算aoi_list中心点到网点标记点的距离
//      val AK_AOIS2ZC = "373efa25370241b1a58d8c4eefa50b90"
//      val URL_AOIS2ZC = "http://gis-int.intsit.sfdc.com.cn:1080/dept/routeplan/aois2zc"

  // 生产  计算aoi_list中心点到网点标记点的距离
  val AK_AOIS2ZC = "75c79782e0da46e79866bdb790eb04a1"
  val URL_AOIS2ZC = "http://gis-apis.int.sfcloud.local:1080/dept/routeplan/aois2zc"


  // 测试  坐标查询aoi
//  val URL_LGTLATSEARCHAOI = "http://sds-core-datarun.sit.sf-express.com/datarun/aoi/getCircleAoiBase?x=%s&y=%s&radius=200"

  //生产 坐标查询aoi
  val URL_LGTLATSEARCHAOI = "http://sds-core-datarun.int.sfcloud.local/datarun/aoi/getCircleAoiBase?x=%s&y=%s&radius=200"

//    // 测试  地址查aoi
//        val AK_ADDR2AOI = "373efa25370241b1a58d8c4eefa50b90"
//        val URL_ADDR2AOI = "http://gis-int.intsit.sfdc.com.cn:1080/chkquery/tc/teamCode"

  // 生产  地址查aoi
  val AK_ADDR2AOI = "75c79782e0da46e79866bdb790eb04a1"
//  val URL_ADDR2AOI = "http://gis-int.int.sfdc.com.cn:1080/chkquery/tc/teamCode"
  val URL_ADDR2AOI = "http://gis-int2.int.sfdc.com.cn:1080/chkquery/tc/teamCode"

//  // 测试  地址查行政村
//  val AK_ADDR2VILLAGE = "8bb09e5e110845f39a000391668e3e80"
//  val URL_ADDR2VILLAGE = "http://gis-gw.intsit.sfdc.com.cn:9080/village/api"

  // 生产  地址查行政村
  val AK_ADDR2VILLAGE = "5686a2aca02e42c9807158558446a455"
//  val AK_ADDR2VILLAGE = "7ae7a15377f34c74b3885d017f74a7a9"  // 灰度ak
  val URL_ADDR2VILLAGE = "http://gis-gw.int.sfdc.com.cn:9080/village/api"

  // 测试  AT服务地址接口(AT派)
//    val AK_AT = "6d4ad76b030e4bd6a99b0a760c3b1d91"
//    val URL_AT = "http://gis-int.intsit.sfdc.com.cn:1080/atdispatch/api/normal/city?ak=%s&province=%s&cityName=%s&district=%s&address=%s"

  // 生产  AT服务地址接口(AT派)
  val AK_AT = "0376a9aa84724dd2a995f858dd963346"
  val URL_AT = "http://gis-int.int.sfdc.com.cn:1080/atdispatch/api/normal/city?ak=%s&province=%s&cityName=%s&district=%s&address=%s"


  // 测试  seg服务地址分词接口(AT派)
//    val AK_AT_SEG = "373efa25370241b1a58d8c4eefa50b90"
//    val URL_AT_SEG = "http://gis-int.intsit.sfdc.com.cn:1080/seg/api/split?ak=%s&address=%s&province=%s&city=%s&county=%s&orderno=123456&level=4&showcode=1"

  // 生产  seg服务地址分词接口(AT派)
//  val AK_AT_SEG = "75c79782e0da46e79866bdb790eb04a1"
  val AK_AT_SEG = "0376a9aa84724dd2a995f858dd963346"
  val URL_AT_SEG = "http://gis-int.int.sfdc.com.cn:1080/seg/api/split?ak=%s&address=%s&province=%s&city=%s&county=%s&orderno=123456&level=4&showcode=1"

  // 测试  seg规范化词接口(AT派)
//      val AK_AT_SEG_NORMAL = "373efa25370241b1a58d8c4eefa50b90"
//      val URL_AT_SEG_NORMAL = "http://gis-int.intsit.sfdc.com.cn:1080/seg/norm/api?ak=%s&address=%s"

  // 生产  seg规范化接口(AT派)
  val AK_AT_SEG_NORMAL = "0376a9aa84724dd2a995f858dd963346"
  val URL_AT_SEG_NORMAL = "http://gis-int.int.sfdc.com.cn:1080/seg/norm/api?ak=%s&address=%s"

  // 测试 经纬坐标查询行政村
//  val URL_LATLNG_VILLAGE = "http://sds-core-datarun.sit.sf-express.com/datarun/aoiVillage/getVillageByCoor?x=%s&y=%s"

  // 生产 经纬坐标查询行政村 （获取单个adcode）
  val URL_LATLNG_VILLAGE = "http://sds-core-datarun.int.sfcloud.local/datarun/aoiVillage/getVillageByCoor?x=%s&y=%s"

  // 生产 经纬坐标查询行政村  （获取adcode list）
  val URL_LATLNG_VILLAGE_RADIUS_500 = "http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=%s&y=%s&radius=500"


  // 测试 经纬度查询行政村 getVillageByCoorRadius
//  val URL_LATLNG_VILLAGE_RADIUS = "http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=%s&y=%s&radius=1000"
  // 生产 经纬度查询行政村 getVillageByCoorRadius
  val URL_LATLNG_VILLAGE_RADIUS = "http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=%s&y=%s&radius=1000"


  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

//  /**
//   * 调用seg服务地址分词接口
//   * @param ak   ak值
//   * @param obj  传入的json对象
//   *
//   */
//  def segSplit(ak:String,obj:JSONObject): JSONObject = {
//
//    try {
//      val address = JSONUtil.getJsonValSingle(obj,"address")
//      val citycode = JSONUtil.getJsonValSingle(obj,"citycode")
//      val county = JSONUtil.getJsonValSingle(obj,"county")
//      val countyAddr = county + address
//      if(StringUtils.isBlank(countyAddr) || StringUtils.isBlank(citycode) ){
//        return obj
//      }
//      val finalUrl = URL_SEG.format(ak,countyAddr,citycode)
//
//      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
//      if (ret != null ) {
//        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
//          val second = Calendar.getInstance().get(Calendar.SECOND)
//          Thread.sleep((60-second)*1000)
//          return segSplit(ak,obj)
//        }
//        obj.put("segSplit",ret)
//      }
//    } catch {
//      case e: Exception => logger.error(e)
//        val tmp = new JSONObject()
//        tmp.put("myException",e.getMessage)
//        obj.put("segSplit",tmp)
//    }
//    obj
//  }


//  /**
//   * 调用geo服务地理编码接口
//   * @param ak   ak值
//   * @param obj  传入的json对象
//   *
//   */
//  def geoServer(ak:String,obj:JSONObject): JSONObject = {
//
//    try {
//      val address = JSONUtil.getJsonValSingle(obj,"address")
//      val citycode = JSONUtil.getJsonValSingle(obj,"citycode")
//      val county = JSONUtil.getJsonValSingle(obj,"county")
//      val countyAddr = county + address
//      if(StringUtils.isBlank(countyAddr) || StringUtils.isBlank(citycode) ){
//        return obj
//      }
//      val finalUrl = URL_GEO.format(ak,countyAddr,citycode)
//
//      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
//      if (ret != null ) {
//        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
//          val second = Calendar.getInstance().get(Calendar.SECOND)
//          Thread.sleep((60-second)*1000)
//          return geoServer(ak,obj)
//        }
//        obj.put("geoServer",ret)
//      }
//    } catch {
//      case e: Exception => logger.error(e)
//        val tmp = new JSONObject()
//        tmp.put("myException",e.getMessage)
//        obj.put("geoServer",tmp)
//    }
//    obj
//  }


//  /**
//   * 调用分词微服务接口
//   * @param ak   ak值
//   * @param obj  传入的json对象
//   *
//   */
//  def addrSplit(ak:String,obj:JSONObject): JSONObject = {
//
//    try {
//      val address = JSONUtil.getJsonValSingle(obj,"address")
//      val citycode = JSONUtil.getJsonValSingle(obj,"citycode")
//      val county = JSONUtil.getJsonValSingle(obj,"county")
//      val countyAddr = county + address
//      if(StringUtils.isBlank(countyAddr) || StringUtils.isBlank(citycode) ){
//        return obj
//      }
//      val finalUrl = URL_SPLIT.format(ak,countyAddr,citycode)
//
//      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
//      if (ret != null ) {
//        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
//          val second = Calendar.getInstance().get(Calendar.SECOND)
//          Thread.sleep((60-second)*1000)
//          return addrSplit(ak,obj)
//        }
//        obj.put("addrSplit",ret)
//      }
//    } catch {
//      case e: Exception => logger.error(e)
//        val tmp = new JSONObject()
//        tmp.put("myException",e.getMessage)
//        obj.put("addrSplit",tmp)
//    }
//    obj
//  }


  /**
   * 调用经纬度查询行政区划接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def lgtLatAdcode(ak:String,obj:JSONObject): JSONObject = {

    try {
      val lgt = JSONUtil.getJsonValSingle(obj,"lgt")
      val lat = JSONUtil.getJsonValSingle(obj,"lat")
      val xy = lgt + "," + lat
      if(lgt==null || lgt.isEmpty  || lat==null || lat.isEmpty){
        return obj
      }
      val finalUrl = URL_LGTLAT_ADCODE.format(xy,ak)

      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return lgtLatAdcode(ak,obj)
        }
        obj.put("lgtLatAdcode",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("lgtLatAdcode",tmp)
    }
    obj
  }


  /**
   * 计算aoi_list中心点到网点标记点的距离
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def aois2zcDistance(ak:String,obj:JSONObject): JSONObject = {

    try {
      val aoi = JSONUtil.getJsonValSingle(obj,"aoi")
      val zc = JSONUtil.getJsonValSingle(obj,"zc")

      if(aoi==null || aoi.isEmpty  || zc==null || zc.isEmpty){
        return obj
      }
      val finalUrl = URL_AOIS2ZC

      val jsonObject = new JSONObject
      jsonObject.put("ak", AK_AOIS2ZC)
      jsonObject.put("zc", zc)
      var aoiList: util.List[Any] = new util.ArrayList[Any]()
      aoiList.add(aoi)
      jsonObject.put("aoi_list", JSON.toJSON(aoiList))
      val postJson = jsonObject.toJSONString
      val retStr = HttpInvokeUtil.sendPost(finalUrl, postJson,3)
      val ret: JSONObject = JSON.parseObject(retStr)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return aois2zcDistance(ak,obj)
        }
        obj.put("aois2zcDistance",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("aois2zcDistance",tmp)
    }
    obj
  }


  /**
   * 坐标查询AOI(支持radius扩大范围查询)
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def lgtlatSearchAOI(ak:String,obj:JSONObject): JSONObject = {

    try {
      val lgt = JSONUtil.getJsonValSingle(obj,"lgt")
      val lat = JSONUtil.getJsonValSingle(obj,"lat")

      if(lgt==null || lgt.isEmpty  || lat==null || lat.isEmpty){
        return obj
      }
      val finalUrl = URL_LGTLATSEARCHAOI.format(lgt,lat)

      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getBoolean("success")!=true ){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return lgtlatSearchAOI(ak,obj)
        }
        obj.put("lgtlatSearchAOI",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("lgtlatSearchAOI",tmp)
    }
    obj
  }



  /**
   * 单元区域查询(地址、城市编码)   根据地址查询aoi
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def addrSearchAOI(ak:String,obj:JSONObject): JSONObject = {

    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val cityCode = JSONUtil.getJsonValSingle(obj,"cityCode")
      val addressType = JSONUtil.getJsonValSingle(obj,"addressType")
      val mobile = JSONUtil.getJsonValSingle(obj,"mobile")
      val phone = JSONUtil.getJsonValSingle(obj,"phone")

      if(address==null || address.isEmpty  || cityCode==null || cityCode.isEmpty || addressType==null || addressType.isEmpty ){
        return obj
      }
      val finalUrl = URL_ADDR2AOI

      val jsonObject = new JSONObject
      jsonObject.put("ak", AK_ADDR2AOI)
      jsonObject.put("address", URLEncoder.encode(address,"utf-8"))
      jsonObject.put("cityCode", cityCode)
      jsonObject.put("addressType", addressType)
      jsonObject.put("sysCode", "M")
      jsonObject.put("type", 1)
      jsonObject.put("mobile", mobile)
      jsonObject.put("phone", phone)

      val postJson = jsonObject.toJSONString
      val retStr = HttpConnection.httpPost(3, finalUrl, postJson)
      val ret: JSONObject = JSON.parseObject(retStr)
      if (ret != null ) {
        if(!"1".equals(ret.getString("retCode")) ){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return addrSearchAOI(ak,obj)
        }
        obj.put("addrSearchAOI",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("addrSearchAOI",tmp)
    }
    obj
  }


  /**
   * 通过地址解析出行政村
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def addr2Village(ak:String,obj:JSONObject): JSONObject = {

    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val cityCode = JSONUtil.getJsonValSingle(obj,"citycode")

      if(address==null || address.isEmpty  || cityCode==null || cityCode.isEmpty ){
        return obj
      }
      val finalUrl = URL_ADDR2VILLAGE

      val jsonObject = new JSONObject
      jsonObject.put("sysCode","BIGDATA")
      jsonObject.put("address", URLEncoder.encode(address,"utf-8"))
      jsonObject.put("cityCode", cityCode)

      val postJson = jsonObject.toJSONString
      val retStr = MyHttpConnection.httpPost(3, finalUrl, postJson, AK_ADDR2VILLAGE)
      val ret: JSONObject = JSON.parseObject(retStr)
      if (ret != null ) {
        if( ret.get("status")==1 ){
          val resultJson: JSONObject = ret.getJSONObject("result")
          if (null!=resultJson && resultJson.get("err")==1012) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep((60 - second) * 1000)
            return addr2Village(ak, obj)
          }
        }
        obj.put("addr2Village",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("addr2Village",tmp)
    }
    obj
  }

  /**
   * 调用AT接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def atNormal(ak:String,obj:JSONObject): JSONObject = {

    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val province = JSONUtil.getJsonValSingle(obj,"province")
      val city = JSONUtil.getJsonValSingle(obj,"city")
      val county = JSONUtil.getJsonValSingle(obj,"county")
      if( StringUtils.isBlank(address) ){
        return obj
      }
      val finalUrl = URL_AT.format(ak,province,city,county,URLEncoder.encode(address,"utf-8"))

      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atNormal(ak,obj)
        }
        obj.put("atNormal",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atNormal",tmp)
    }
    obj
  }

  /**
   * 调用seg服务地址分词接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def atSeg(ak:String,obj:JSONObject): JSONObject = {

    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val province = JSONUtil.getJsonValSingle(obj,"province")
      val city = JSONUtil.getJsonValSingle(obj,"city")
      val county = JSONUtil.getJsonValSingle(obj,"county")
      if( StringUtils.isBlank(address) ){
        return obj
      }
      val finalUrl = URL_AT_SEG.format(ak,URLEncoder.encode(address,"utf-8"),province,city,county)

      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atSeg(ak,obj)
        }
        obj.put("atSeg",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atSeg",tmp)
    }
    obj
  }

  /**
   * 调用seg规范化接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def atSegNormal(ak:String,obj:JSONObject): JSONObject = {

    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val province = JSONUtil.getJsonValSingle(obj,"province")
      val city = JSONUtil.getJsonValSingle(obj,"city")
      val county = JSONUtil.getJsonValSingle(obj,"county")
      if( StringUtils.isBlank(address) ){
        return obj
      }
      val addressPlus = province+city+county+address
      val finalUrl = URL_AT_SEG_NORMAL.format(ak,URLEncoder.encode(addressPlus,"utf-8"))

      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atSegNormal(ak,obj)
        }
        obj.put("atSegNormal",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atSegNormal",tmp)
    }
    obj
  }


  /**
   * 经纬坐标查询行政村接口
   * @param obj  传入的json对象
   *
   */
  def latLngVillage(ak:String,obj:JSONObject): JSONObject = {

    try {
      val zx = JSONUtil.getJsonValSingle(obj,"zx")
      val zy = JSONUtil.getJsonValSingle(obj,"zy")
      if( StringUtils.isBlank(zx) | StringUtils.isBlank(zy)){
        return obj
      }
      val finalUrl = URL_LATLNG_VILLAGE.format(zx,zy)

      val retStr = HttpInvokeUtil.sendGet(finalUrl,3)
      val ret: JSONObject = JSON.parseObject(retStr)
      if (ret != null ) {
        if(ret.getBooleanValue("success")!=true ){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return latLngVillage("",obj)
        }
        obj.put("latLngVillage",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("latLngVillage",tmp)
    }
    obj
  }

  /**
   * 经纬坐标查询行政村接口(Radius)
   * @param obj  传入的json对象
   *
   */
  def latLngVillageRadius(ak:String,obj:JSONObject): JSONObject = {

    try {
      val zx = JSONUtil.getJsonValSingle(obj,"operate_longitude")
      val zy = JSONUtil.getJsonValSingle(obj,"operate_latitude")
      if( StringUtils.isBlank(zx) | StringUtils.isBlank(zy)){
        return obj
      }
      val finalUrl = URL_LATLNG_VILLAGE_RADIUS.format(zx,zy)

      val retStr = HttpInvokeUtil.sendGet(finalUrl,3)
      val ret: JSONObject = JSON.parseObject(retStr)
      if (ret != null ) {
        if(ret.getBooleanValue("success")!=true ){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return latLngVillageRadius("",obj)
        }
        obj.put("latLngVillageRadius",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("latLngVillageRadius",tmp)
    }
    obj
  }

  /**
   * 经纬坐标查询行政村接口(Radius) 获取adcode list
   * @param obj  传入的json对象
   *
   */
  def latLngVillageRadius500(ak:String,obj:JSONObject): JSONObject = {

    try {
      val zx = JSONUtil.getJsonValSingle(obj,"zx")
      val zy = JSONUtil.getJsonValSingle(obj,"zy")
      if( StringUtils.isBlank(zx) | StringUtils.isBlank(zy)){
        return obj
      }
      val finalUrl = URL_LATLNG_VILLAGE_RADIUS_500.format(zx,zy)

      val retStr = HttpInvokeUtil.sendGet(finalUrl,3)
      val ret: JSONObject = JSON.parseObject(retStr)
      if (ret != null ) {
        if(ret.getBooleanValue("success")!=true ){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return latLngVillageRadius500("",obj)
        }
        obj.put("latLngVillageRadius500",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("latLngVillageRadius500",tmp)
    }
    obj
  }


  def main(args: Array[String]): Unit = {

//    val dd = new JSONObject()
//    dd.put("zx","111.188273")
//    dd.put("zy","33.761547")
////    dd.put("zy","s")
//
//    val x = latLngVillageRadius500("",dd)
//    println("x:"+x)
//
//    val resJson = x.getJSONObject("latLngVillageRadius500")
//    if ( null != resJson ){
//      println("api res : "+resJson)
//      if ( resJson.getBooleanValue("success")==true ) {
//        println(resJson.get("data").toString)
//      }
//    }

//    val dd = new JSONObject()
//    dd.put("address","软件产业基地")
//    dd.put("province","广东省")
//    dd.put("city","深圳市")
//    dd.put("county","南山区")
//
//    val gg = atSegNormal(AK_AT_SEG_NORMAL, dd)
//    println(gg)
//    val resJson = gg.getJSONObject("atSegNormal")
//    if (null!=resJson && resJson.get("status")==0) {
//      val resultJson: JSONObject = resJson.getJSONObject("result")
//      val dataJson = resultJson.getJSONObject("data")
//      println(dataJson)
//    }

//    var gg = atNormal(AK_AT, dd)
//    println(gg)
//
//    var resJson = gg.getJSONObject("atNormal")
//    if (null!=resJson && resJson.get("status")==0) {
//      val resultJson: JSONObject = resJson.getJSONObject("result")
//      println(resultJson)
//    }
//
//    gg = atSeg(AK_AT_SEG, dd)
//    println(gg)
//    resJson = gg.getJSONObject("atSeg")
//    if (null!=resJson && resJson.get("status")==0) {
//      val resultJson: JSONObject = resJson.getJSONObject("result")
//      val dataJson = resultJson.getJSONObject("data")
//      println(dataJson)
//    }


//    val dd = new JSONObject()
////    dd.put("address","河南省郑州市新郑市中兴路华夏国际商务中心办公楼")
//    dd.put("address",URLEncoder.encode("河南省郑州市新郑市中兴路华夏国际商务中心办公楼","utf-8"))
//    dd.put("citycode","371")
//
//    val gg = addr2Village(AK_ADDR2VILLAGE, dd)
//    println(gg)
//
//    val resJson = gg.getJSONObject("addr2Village")
//    if (null!=resJson && resJson.get("status")==0) {
//      val resultJson: JSONObject = resJson.getJSONObject("result")
//      val dataJson = resultJson.getJSONObject("data")
//      println(dataJson)
//    }


//    val dd = new JSONObject()
////    dd.put("address","广东省深圳市宝安区海雅缤纷城君誉-C单元建安一路99号顺丰标快1")
//    dd.put("address",URLEncoder.encode("广东省深圳市宝安区海雅缤纷城君誉-C单元建安一路99号顺丰标快1","utf-8"))
//    dd.put("cityCode","755")
//    dd.put("addressType","2")
//
//    val gg = addrSearchAOI(AK_ADDR2AOI, dd)
//    println(gg)
//
//    val resJson = gg.getJSONObject("addrSearchAOI")
//    if (null!=resJson && "1".equals(resJson.get("retCode"))) {
//      println(resJson.getString("aoiCode"))
//    }


//        val lgtlat = new JSONObject()
//        lgtlat.put("lgt","114.15432726553519")
//        lgtlat.put("lat","22.636956440746005")
//        val gg = lgtlatSearchAOI("", lgtlat)
//        println(gg)
//
//    val resJson = gg.getJSONObject("lgtlatSearchAOI")
//        if (null!=resJson && resJson.get("code")==200) {
//          val dataArray = resJson.getJSONArray("data")
//          if (null != dataArray && dataArray.size() > 0) {
//            val dataJson = dataArray.getJSONObject(0)
//            println(dataJson)
//          }
//        }


//    val dd = new JSONObject()
//    dd.put("address","广东省深圳市宝安区海雅缤纷城君誉-C单元建安一路99号顺丰标快1")
//    dd.put("citycode","755")
//    dd.put("county","宝安区")
////    val ff = segSplit(AK_SEG,dd)
////    val ff = geoServer(AK_GEO,dd)
//    val ff = addrSplit(AK_SPLIT,dd)
//    println(ff.toJSONString)

//    val lgtlat = new JSONObject()
//    lgtlat.put("lgt","121.84171")
//    lgtlat.put("lat","29.90548")
//    val gg = lgtLatAdcode(AK_LGTLAT_ADCODE, lgtlat)
//    println(gg)
//
//    val resJson = gg.getJSONObject("lgtLatAdcode")
//    if (null!=resJson && resJson.get("status")==0){
//      val resultJson: JSONObject = resJson.getJSONObject("result")
//      val dataArray = resultJson.getJSONArray("data")
//      if(null!=dataArray && dataArray.size()>0) {
//        val dataJson = dataArray.getJSONObject(0)
//        val resTuple = Tuple9[String, String, String, String, String, String, String, String, String](
//          "dld_code",
//          "lgt",
//          "lat",
//          if (null != dataJson.getString("province")) dataJson.getString("province") else "",
//          if (null != dataJson.getString("city")) dataJson.getString("city") else "",
//          if (null != dataJson.getString("county")) dataJson.getString("county") else "",
//          if (null != dataJson.getString("town")) dataJson.getString("town") else "",
//          if (null != dataJson.getString("adcode")) dataJson.getString("adcode") else "",
//          if (null != dataJson.getString("citycode")) dataJson.getString("citycode") else ""
//        )
//        println(resTuple)
//      }
//    }

//    val aoi2zc = new JSONObject()
//    aoi2zc.put("aoi","032F2C771D764BAA90386265732CBACE")
//    aoi2zc.put("zc","512AA")
//    val aoi2zcR = aois2zcDistance(AK_AOIS2ZC, aoi2zc)
//    println(aoi2zcR)

//        val resJson = aoi2zcR.getJSONObject("aois2zcDistance")
//        if (null!=resJson && resJson.get("status")==0) {
//          val resultJson: JSONObject = resJson.getJSONObject("result")
//          val dataJson = resultJson.getJSONObject("data")
//          println(dataJson)
//          val carJson = dataJson.getJSONObject("car")
//          val horseJson = dataJson.getJSONObject("horse")
//          val  resTuple = Tuple4[String, String, String, String](
//            "lgt",
//            "lat",
//            if (null != carJson.getString("dist")) carJson.getString("dist") else "",
//            if (null != horseJson.getString("dist")) horseJson.getString("dist") else ""
//          )
//          println(resTuple)
//        }
  }
}
