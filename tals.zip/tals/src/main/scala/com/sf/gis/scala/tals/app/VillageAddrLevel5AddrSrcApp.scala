package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.tals.method.MySfNetInteface
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD


/**
 * 运单地址解析，行政村5级地址
 * 需求方：敖少良（01425243）
 * @author 张小琼 （01416344）
 * Created on 2023-02-23
 * 任务信息： 668258 行政村收派件_v2.0 | 926185 行政村收派件_new(基于dwd_waybill_info_dtl_di)
 *
 */

object VillageAddrLevel5AddrSrcApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val sparkInfo = SparkUtil.getSpark4GisBd(appName)
    val sparkSession = sparkInfo.getSession

    val int_sql = args.apply(0)
    val out_table = args.apply(1)
    val pall_num = args.apply(2).toInt

    // 读取输入数据
    val waybillSql = int_sql
    println(waybillSql)
    val waybillDf = sparkSession.sql(waybillSql)
    waybillDf.show(10)
    waybillDf.createTempView("village_addr_input")

    // 跑接口输入数据进行去重优化
    val inputDf = sparkSession.sql("select '' as waybill_no,'' as inc_day,yd_citycode,yd_addr   from village_addr_input group by yd_citycode,yd_addr")


   // 调接口需求输入的rdd
    val inputRdd = inputDf.rdd.map(x => {
      val resJson = new JSONObject()
      resJson.put("waybill_no",x.getAs[String]("waybill_no"))
      resJson.put("inc_day",x.getAs[String]("inc_day"))
      resJson.put("citycode",x.getAs[String]("yd_citycode"))
      resJson.put("address",x.getAs[String]("yd_addr"))
      resJson
    })

    // 接口监控启动
    val invokeCnt  = inputRdd.count()
    logger.error(s"调用服务，总行数：${invokeCnt}")
    val invokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01416344", "670832/929228", "village_src_addr_decode(byApi)", "跑5级地址(收件)", MySfNetInteface.URL_ADDR2VILLAGE, MySfNetInteface.AK_ADDR2VILLAGE, invokeCnt, 20)

    // 分钟数限制跑接口
    val outRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession, inputRdd, MySfNetInteface.addr2Village , 20, MySfNetInteface.AK_ADDR2VILLAGE, pall_num)
    val resRdd = outRDD.map( x => {
      var resTuple = Tuple20[String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String]("","","","","","","","","","","","","","","","","","","","")

      val waybill_no = x.getString("waybill_no")
      val inc_day = x.getString("inc_day")
      val yd_citycode = x.getString("citycode")
      val yd_addr = x.getString("address")

      val resJson = x.getJSONObject("addr2Village")
      if (null!=resJson && resJson.get("status")==0){
        val resultJson: JSONObject = resJson.getJSONObject("result")
        val dataJson = resultJson.getJSONObject("data")
        resTuple = Tuple20[String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String](
          waybill_no,
          inc_day,
          yd_citycode,
          yd_addr,
          if (null!=dataJson.getString("province")) dataJson.getString("province") else "",
          if (null!=dataJson.getString("city")) dataJson.getString("city") else "",
          if (null!=dataJson.getString("county")) dataJson.getString("county") else "",
          if (null!=dataJson.getString("town")) dataJson.getString("town") else "",
          if (null!=dataJson.getString("src")) dataJson.getString("src") else "",
          if (null!=dataJson.getString("x")) dataJson.getString("x") else "",
          if (null!=dataJson.getString("y")) dataJson.getString("y") else "",
          if (null!=dataJson.getString("vilName")) dataJson.getString("vilName") else "",
          if (null!=dataJson.getString("vilSpaceCode")) dataJson.getString("vilSpaceCode") else "",
          if (null!=dataJson.getString("classCode")) dataJson.getString("classCode") else "",
          if (null!=dataJson.getString("aoiId")) dataJson.getString("aoiId") else "",
          if (null!=dataJson.getString("aoiCode")) dataJson.getString("aoiCode") else "",
          if (null!=dataJson.getString("deptCode")) dataJson.getString("deptCode") else "",
          if (null!=dataJson.getString("vilCode")) dataJson.getString("vilCode") else "",
          if (null!=dataJson.getString("townAdCode")) dataJson.getString("townAdCode") else "",
          if (null!=dataJson.getString("distance")) dataJson.getString("distance") else ""
        )
      }else{
        resTuple = Tuple20[String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String,String](
          waybill_no,
          inc_day,
          yd_citycode,
          yd_addr,
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          ""
        )
      }
      resTuple
    })

    // 接口监控结束
    logger.error(s"调用服务完成，调用服务ID：${invokeId}")
    BdpTaskRecordUtil.endNetworkInterface("01416344", invokeId)

    // rdd转DF，输出到表中
    import sparkSession.implicits._
    val resDf = resRdd.toDF("waybill_no","inc_day","yd_citycode","yd_addr","province","city","county","town","src","x","y","vil_name","vil_space_code","class_code","aoi_id","aoi_code","dept_code","vil_code","town_adcode","distance")
    resDf.createTempView("village_level5_addr")

    logger.error(s"写入分区表： ${out_table} ")
    val outputDf = sparkSession.sql(
      s"""
         |
         |insert into  ${out_table} partition(inc_day)
         |select
         |waybill_no,t0.yd_addr as consignor_addr,province,city,county,town,vil_name as vilname,vil_code as vilcode,town_adcode,class_code,distance,t0.yd_citycode as src_dist_code,
         |inc_day
         |from (select waybill_no,inc_day,yd_citycode,yd_addr from village_addr_input ) as t0
         |left join
         |(select yd_citycode,yd_addr,province,city,county,town,vil_name,vil_code,town_adcode,class_code,distance from village_level5_addr ) as t1
         |on
         |t0.yd_citycode=t1.yd_citycode and t0.yd_addr=t1.yd_addr
         |
         |""".stripMargin)
    outputDf.repartition(10).show()

    sparkSession.stop()

    logger.error("任务结束。")

  }

}
