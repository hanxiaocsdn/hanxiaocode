package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.tals.method.MySfNetInteface
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.util


/**
 * 经纬坐标查询行政村(同城件判断是否上门)
 * 需求方：敖少良（01425243）
 * @author 张小琼 （01416344）
 * Created on 2023-10-20
 * 任务信息： 668258  行政村收派件_v2.0
 *
 */

object VillageLatLngDriverTrackRadius500App {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {



    val sparkInfo = SparkUtil.getSpark4GisBd(appName)
    val sparkSession = sparkInfo.getSession

    val int_sql = args.apply(0)
    val out_table = args.apply(1)
    val pall_num = args.apply(2).toInt
    val inc_day = args.apply(3)

    // 读取输入数据
    println(int_sql)
    val inputDf = sparkSession.sql(int_sql)
    inputDf.show(10)

    // 调接口需求输入的rdd
    val inputRdd = inputDf.rdd.map(x => {
      val resJson = new JSONObject()
      resJson.put("vilcode", x.getAs[String]("vilcode"))
      resJson.put("driver_track", x.getAs[String]("driver_track"))
      resJson.put("zx", x.getAs[String]("zx"))
      resJson.put("zy", x.getAs[String]("zy"))
      resJson
    })

    // 接口监控启动
    val invokeCnt = inputRdd.count()
    val invokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01416344", "929584", "同城经纬跑接口", "经纬坐标查询行政村", MySfNetInteface.URL_LATLNG_VILLAGE_RADIUS, "", invokeCnt, 20)


    // 分钟数限制跑接口
    val outRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession, inputRdd, MySfNetInteface.latLngVillageRadius500, 20, "", pall_num)
    val resRdd = outRDD.map(x => {
      var resTuple = Tuple5[String, String, String,  String, String]("", "", "",  "", "")
      var matchRes = ""

      val vilcode = x.getString("vilcode")
      val driver_track = x.getString("driver_track")
      val lon = x.getString("zx")
      val lat = x.getString("zy")

      val resJson = x.getJSONObject("latLngVillageRadius500")
      if (null != resJson && resJson.getBoolean("success") == true) {
        val dataArray = resJson.getJSONArray("data")
        if (null != dataArray && dataArray.size() > 0) {
          import scala.util.control.Breaks._
          breakable {
            for (i <- 0 to dataArray.size() - 1) {
              val dataJson = dataArray.getJSONObject(i)
              if (null != dataJson && vilcode.equals(dataJson.getString("areaCode"))) {
                matchRes = "1"
                break
              }
            }
          }
        }
      }
      resTuple = Tuple5[String, String, String, String, String](
        vilcode,
        driver_track,
        lon,
        lat,
        matchRes
      )
      resTuple
    })

    // 接口监控结束
    logger.error(s"调用服务完成，调用服务ID：${invokeId}")
    BdpTaskRecordUtil.endNetworkInterface("01416344", invokeId)

    // rdd转DF，输出到表中
    import sparkSession.implicits._
    val resDf = resRdd.toDF("vilcode", "driver_track", "lon", "lat", "tc_res")
    resDf.createTempView("village_latlngvillageradius")

    logger.error(s"写入分区表： ${out_table} ")
    val outputDf = sparkSession.sql(
      s"""
         |insert overwrite table ${out_table} partition(inc_day='${inc_day}')
         |select
         |vilcode,driver_track,max(tc_res) as tc_res
         |from village_latlngvillageradius
         |group by vilcode,driver_track
         |
         |""".stripMargin)
    outputDf.repartition(10).show()


    sparkSession.stop()

    logger.error("任务结束。")

  }

}
