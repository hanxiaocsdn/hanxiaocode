package com.sf.gis.scala.tals.app

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.tals.app.WuHanKvWriteToRedisAppTest.appName
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01416344 on 2022/02/17.
 * 样例企业匹配
 */

object CompanySampleMatchAppTest {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)


  def main(args: Array[String]): Unit = {


    val parNum = 1  //并行度
    val sparkConf = new SparkConf().setMaster("local[4]").setAppName(appName)
    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    val df = spark.read.format("csv")
      .option("delimiter", "|")
      .load("./tals/data/citysample.txt")
      .toDF("x0","company_name","credit_code","zt","dy","hy","hz","fdy","fhz","fhy","fzt","city_code_dy","city_code_fdy","x1")

    import spark.implicits._
    val sampleDf = df.select("company_name","credit_code","zt","dy","hy","hz","fdy","fhz","fhy","fzt","city_code_dy","city_code_fdy")
      .map( item => Tuple12(item(0).toString.trim,item(1).toString.trim,item(2).toString.trim,item(3).toString.trim,item(4).toString.trim,item(5).toString.trim
      ,item(6).toString.trim,item(7).toString.trim,item(8).toString.trim,item(9).toString.trim,item(10).toString.trim,item(11).toString.trim) )
      .toDF("company_name","credit_code","zt","dy","hy","hz","fdy","fhz","fhy","fzt","city_code_dy","city_code_fdy" )
    val sampleLst = sampleDf.collect().toList
    println(sampleLst.length)
    val broadcastVar = spark.sparkContext.broadcast(sampleLst)

    val df1 = spark.read.format("csv")
      .option("delimiter", "|")
      .load("./tals/data/cityConsignorCont.txt")
      .toDF("x0","consignor_name","city_code","x1")

    val waybillDf = df1.select("consignor_name","city_code")
      .map( item => Tuple2(item(0).toString.trim,item(1).toString.trim) )
      .toDF("consignor_name","city_code" )


//    val tuplesRdd = waybillDf.rdd.repartition(parNum).flatMap(obj => {
//      val consignor_name = obj.getAs[String]("consignor_name")
//      val city_code = obj.getAs[String]("city_code")
//
//      val tuples = new ArrayBuffer[Tuple4[String, String, String, String]]()
//      broadcastVar.value.foreach(row => {
//        val company_name = row.getAs[String]("company_name")
//        val credit_code = row.getAs[String]("credit_code")
//        val zt = row.getAs[String]("zt")
//        val dy = row.getAs[String]("dy")
//        val hy = row.getAs[String]("hy")
//        val hz = row.getAs[String]("hz")
//        val fdy = row.getAs[String]("fdy")
//        val fhz = row.getAs[String]("fhz")
//        val fhy = row.getAs[String]("fhy")
//        val fzt = row.getAs[String]("fzt")
//        val city_code_dy = row.getAs[String]("city_code_dy")
//        val city_code_fdy = row.getAs[String]("city_code_fdy")
//
//        // zt、fzt、hy、fhy
//        var ztHave = getAStringContainB(consignor_name, zt)
//        var fztHave = getAStringContainB(consignor_name, fzt)
//        var hyHave = getAStringContainB(consignor_name, hy)
//        var fhyHave = getAStringContainB(consignor_name, fhy)
//        // dy、fdy
//        var dyHave = getAStringContainB(consignor_name, dy)
//        var fdyHave = getAStringContainB(consignor_name, fdy)
//        // hz、fhz
//        var hzHave = getAStringContainB(consignor_name, hz)
//        var fhzHave = getAStringContainB(consignor_name, fhz)
//
//
//        if (ztHave && fztHave && hyHave && fhyHave && dyHave && fdyHave && hzHave && fhzHave) {
//          tuples += new Tuple4[String, String, String, String](consignor_name, city_code, company_name, credit_code)
//        } else {
//          if (ztHave && fztHave && hyHave && fhyHave && (!dy.isEmpty && dyHave || !fdy.isEmpty && fdyHave || !city_code_dy.isEmpty && city_code_dy == credit_code || !city_code_fdy.isEmpty && city_code_fdy == credit_code)) {
//            tuples += new Tuple4[String, String, String, String](consignor_name, city_code, company_name, credit_code)
//          }
//        }
//
//      }
//      )
//      tuples
//    })
//
//
//    val rDf = tuplesRdd.toDF("consignor_name","city_code","company_name","credit_code")
//
//    rDf.show()


    val cartesianRdd = waybillDf.rdd.repartition(4).cartesian(spark.sparkContext.makeRDD(sampleLst))

//    cartesianRdd.foreach(println)

    val resRdd = cartesianRdd.map( o => {
      val startTime = System.currentTimeMillis()

      val waybillRow = o._1
      val row = o._2

      val consignor_name = waybillRow.getAs[String]("consignor_name")
      val city_code = waybillRow.getAs[String]("city_code")

      var tupleRes = Tuple4[String, String, String, String]("","","","")
      val company_name = row.getAs[String]("company_name")
      val credit_code = row.getAs[String]("credit_code")
      val zt = row.getAs[String]("zt")
      val dy = row.getAs[String]("dy")
      val hy = row.getAs[String]("hy")
      val hz = row.getAs[String]("hz")
      val fdy = row.getAs[String]("fdy")
      val fhz = row.getAs[String]("fhz")
      val fhy = row.getAs[String]("fhy")
      val fzt = row.getAs[String]("fzt")
      val city_code_dy = row.getAs[String]("city_code_dy")
      val city_code_fdy = row.getAs[String]("city_code_fdy")

      // zt、fzt、hy、fhy
      var ztHave = getAStringContainB(consignor_name, zt)
      var fztHave = getAStringContainB(consignor_name, fzt)
      var hyHave = getAStringContainB(consignor_name, hy)
      var fhyHave = getAStringContainB(consignor_name, fhy)
      // dy、fdy
      var dyHave = getAStringContainB(consignor_name, dy)
      var fdyHave = getAStringContainB(consignor_name, fdy)
      // hz、fhz
      var hzHave = getAStringContainB(consignor_name, hz)
      var fhzHave = getAStringContainB(consignor_name, fhz)

      if (ztHave && fztHave && hyHave && fhyHave && dyHave && fdyHave && hzHave && fhzHave) {
        tupleRes = new Tuple4[String, String, String, String](consignor_name, city_code, company_name, credit_code)
      } else {
        if (ztHave && fztHave && hyHave && fhyHave &&
          (null!=dy && !dy.isEmpty && dyHave || null!=fdy &&  !fdy.isEmpty && fdyHave
            || null!=city_code_dy && !city_code_dy.isEmpty && city_code_dy == credit_code
            || null!=city_code_fdy && !city_code_fdy.isEmpty && city_code_fdy == credit_code)) {
          tupleRes = new Tuple4[String, String, String, String](consignor_name, city_code, company_name, credit_code)
        }
      }

      val endTime = System.currentTimeMillis()

//      println("耗时："+(endTime-startTime))

      tupleRes

    }).filter( x => null!=x._1 && !x._1.isEmpty)

    val resDf = resRdd.toDF("consignor_name","city_code","company_name","credit_code")
    resDf.show(100)

    spark.stop()


  }

  /**
   *
   * @param a
   * @param b
   */
  def getAStringContainB(a: String,b: String): Boolean ={
    var isContain = true
    if (null!=b && !b.isEmpty){
      if(null!=a && !a.isEmpty){
        if(a.contains(b)){
          isContain = true
        }else{
          isContain = false
        }
      }
    }
    isContain
  }

}
