package com.sf.gis.scala.tals.app

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * create by 01416344(张小琼) on 2022/05/11
 * spark sql模板
 * 描述：用于在bdp平台跑自定义的sql。shell脚本内以spark-submit方式提交。
 */
object SqlRun {

  val logger: Logger = Logger.getLogger(SqlRun.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)

  /**
   *
   * @param args
   * tableName: 表名（需要带上库名，只有在tag为true时写入表）
   * tag: 读取的数据是否写入表标识
   * sql: 自定义的sql语句，多条用“;”分割
   * getDataPartition：getDataDf时的分区数
   * saveDataPartition：数据入表时的分区数
   * showNumRows：打印时显示的数据行数
   */
  def main(args: Array[String]): Unit = {

    val tableName = args.apply(0)
    val tag = args.apply(1)
    val sql = args.apply(2)
    val getDataPartition = args.apply(3).toInt
    val saveDataPartition = args.apply(4).toInt
    val showNumRows = args.apply(5).toInt

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.crossJoin.enabled", "true")


    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    if(sql!=null && !"".equals(sql) && !sql.isEmpty){
      val sqlArray = sql.split(";")
      for(i <- 0 until (sqlArray.length-1)){
        start(spark,sqlArray(i),tableName,tag,getDataPartition,saveDataPartition,showNumRows)
      }
    }


  }


  def start(spark:SparkSession, sql:String, tableName:String, tag:String, getDataPartition:Int, saveDataPartition:Int, showNumRows:Int) = {

    logger.error("开始计算" )
    val DF = getDataDf(spark,sql,getDataPartition,showNumRows)

    if(tag.equals("true") && tableName.nonEmpty){
      logger.error("数据入表")
      DF.repartition(saveDataPartition).write.mode(SaveMode.Overwrite).saveAsTable(tableName)
      logger.error(s"更新完毕:${tableName}")
    }

    logger.error("统计完毕")
  }


  def getDataDf(spark:SparkSession, sql:String, sqlPartition:Int, showNumRows:Int) = {
    logger.error(sql)
    val DF = spark.sql(sql).repartition(sqlPartition).persist(StorageLevel.MEMORY_AND_DISK)
    DF.show(showNumRows,false)
    DF
  }


}
