package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.tals.method.MySfNetInteface
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD


/**
 * 经纬坐标查询行政村
 * 需求方：敖少良（01425243）
 * @author 张小琼 （01416344）
 * Created on 2023-03-25
 * 任务信息： 668258  行政村收派件_v2.0
 *
 */

object VillageLatLngVillageApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val sparkInfo = SparkUtil.getSpark4GisBd(appName)
    val sparkSession = sparkInfo.getSession

    val int_sql = args.apply(0)
    val out_table = args.apply(1)
    val pall_num = args.apply(2).toInt

    // 读取输入数据
    println(int_sql)
    val inputDf = sparkSession.sql(int_sql)
    inputDf.show(10)

   // 调接口需求输入的rdd
    val inputRdd = inputDf.rdd.map(x => {
      val resJson = new JSONObject()
      resJson.put("zx",x.getAs[String]("zx"))
      resJson.put("zy",x.getAs[String]("zy"))
      resJson.put("inc_day",x.getAs[String]("inc_day"))
      resJson.put("dist_code",x.getAs[String]("dist_code"))
      resJson
    })

    // 分钟数限制跑接口
    val outRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession, inputRdd, MySfNetInteface.latLngVillage , 20, "", pall_num)
    val resRdd = outRDD.map( x => {
      var resTuple = Tuple7[String,String,String,String,String,String,String]("","","","","","","")

      val zx = x.getString("zx")
      val zy = x.getString("zy")
      val inc_day = x.getString("inc_day")
      val dist_code = x.getString("dist_code")

      val resJson = x.getJSONObject("latLngVillage")
      if (null!=resJson && resJson.getBoolean("success")==true){
        val dataJson = resJson.getJSONObject("data")
        if (null!=dataJson) {
          resTuple = Tuple7[String, String, String, String, String,String, String](
            zx,
            zy,
            if (null != dataJson.getString("objCode")) dataJson.getString("objCode") else "",
            if (null != dataJson.getString("name")) dataJson.getString("name") else "",
            if (null != dataJson.getString("guid")) dataJson.getString("guid") else "",
            inc_day,
            dist_code
          )
        }else{
          resTuple = Tuple7[String,String,String,String,String,String, String](
            zx,
            zy,
            "",
            "",
            "",
            inc_day,
            dist_code
          )
        }
      }else{
        resTuple = Tuple7[String,String,String,String,String,String, String](
          zx,
          zy,
          "",
          "",
          "",
          inc_day,
          dist_code
        )
      }
      resTuple
    })

    // rdd转DF，输出到表中
    import sparkSession.implicits._
    val resDf = resRdd.toDF("zx","zy","vil_code","vil_name","guid","inc_day","dist_code")
    resDf.createTempView("village_latlngvillage")

    logger.error(s"写入分区表： ${out_table} ")
    val outputDf = sparkSession.sql(
      s"""
         |insert overwrite table  ${out_table} partition(inc_day)
         |select
         |zx,zy,vil_code,vil_name,guid,dist_code,inc_day
         |from village_latlngvillage
         |
         |""".stripMargin)
    outputDf.repartition(10).show()

    sparkSession.stop()

    logger.error("任务结束。")

  }

}
