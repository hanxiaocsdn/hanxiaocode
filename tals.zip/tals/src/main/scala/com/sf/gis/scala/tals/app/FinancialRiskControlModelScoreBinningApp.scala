package com.sf.gis.scala.tals.app

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession


/**
 * Created by 01416344 on 2022/12/29.
 * 金融风控评分接口数据
 * 描述：计算模型得分(特征分箱)
 *
 */
object FinancialRiskControlModelScoreBinningApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    val int_sql1 = args.apply(0)
    val out_table1 = args.apply(1)
    val id = args.apply(2)
    val inc_day = args.apply(3) //格式 yyyyMMdd
    val repart_n = args.apply(4).toInt

    logger.error(s"int_sql1: ${int_sql1}")
    logger.error(s"inc_day: ${inc_day}")

    val inputDf = spark.sql(int_sql1)
    inputDf.show(10)


//    spark.sql("set spark.sql.legacy.allowUntypedScalaUDF=true")
//    val dframe1 = inputDf.withColumnRenamed("tel_md5","tel_md5")
//      .withColumnRenamed("consigned_cnt_7d","jj_最近7天")
//      .withColumnRenamed("consigned_cnt_30d", "jj_最近1个月")
//      .withColumnRenamed("consigned_cnt_90d", "jj_最近3个月")
//      .withColumnRenamed("consigned_cnt_180d", "jj_最近半年")
//      .withColumnRenamed("consigned_cnt_365d", "jj_最近一年")
//      .withColumnRenamed("consigned_cnt_365d_nospecial", "jj_最近1年（剔除特殊时间）")
//      .withColumnRenamed("consigned_cnt_d12m", "jj_第12月")
//      .withColumnRenamed("consigned_cnt_d11m", "jj_第11月")
//      .withColumnRenamed("consigned_cnt_d10m", "jj_第10月")
//      .withColumnRenamed("consigned_cnt_d9m", "jj_第9月")
//      .withColumnRenamed("consigned_cnt_d8m", "jj_第8月")
//      .withColumnRenamed("consigned_cnt_d7m", "jj_第7月")
//      .withColumnRenamed("consigned_cnt_d6m", "jj_第6月")
//      .withColumnRenamed("consigned_cnt_d5m", "jj_第5月")
//      .withColumnRenamed("consigned_cnt_d4m", "jj_第4月")
//      .withColumnRenamed("consigned_cnt_d3m", "jj_第3月")
//      .withColumnRenamed("consigned_cnt_d2m", "jj_第2月")
//      .withColumnRenamed("consigned_cnt_d1m", "jj_第1月")
//      .withColumnRenamed("consigned_cnt_one90d", "jj_第一90")
//      .withColumnRenamed("consigned_cnt_two90d", "jj_第二90")
//      .withColumnRenamed("d1d2_growth", "jj_第一第二增长率")
//      .withColumnRenamed("consigned_cnt_three90d", "jj_第三90")
//      .withColumnRenamed("d2d3_growth", "jj_第二第三增长率")
//      .withColumnRenamed("consigned_cnt_four90d", "jj_第四90")
//      .withColumnRenamed("d3d4_growth", "jj_第三第四增长率")
//      .withColumnRenamed("recent_days", "jj_最近一次天数")
//      .withColumnRenamed("consignor_tm_zs_cnt", "jj_早")
//      .withColumnRenamed("consignor_tm_zw_cnt", "jj_中")
//      .withColumnRenamed("consignor_tm_ws_cnt", "jj_晚")
//      .withColumnRenamed("consigned_cnt_618", "jj_618")
//      .withColumnRenamed("consigned_cnt_1111", "jj_1111")
//      .withColumnRenamed("consigned_cnt_1212", "jj_1212")
//      .withColumnRenamed("consigned_cnt_person", "jj_个人")
//      .withColumnRenamed("consigned_cnt_company", "jj_企业")
//      .withColumnRenamed("consigned_cnt_tmall", "jj_天猫")
//      .withColumnRenamed("consigned_cnt_jd", "jj_京东")
//      .withColumnRenamed("consigned_cnt_pos", "jj_pos机")
//      .withColumnRenamed("max_dm", "jj_最大月份")
//      .withColumnRenamed("cnt_dm", "jj_有月份的个数")
//      .withColumnRenamed("city_cnt", "jj_城市数")
//      .withColumnRenamed("city_level", "jj_城市等级")
//      .withColumnRenamed("consignee_cnt_7d", "sj_最近7天")
//      .withColumnRenamed("consignee_cnt_30d", "sj_最近1个月")
//      .withColumnRenamed("consignee_cnt_90d", "sj_最近3个月")
//      .withColumnRenamed("consignee_cnt_180d", "sj_最近半年")
//      .withColumnRenamed("consignee_cnt_365d", "sj_最近1年")
//      .withColumnRenamed("consignee_cnt_365d_nospecial", "sj_最近1年（剔除特殊时间）")
//      .withColumnRenamed("consignee_cnt_d12m", "sj_第12月")
//      .withColumnRenamed("consignee_cnt_d11m", "sj_第11月")
//      .withColumnRenamed("consignee_cnt_d10m", "sj_第10月")
//      .withColumnRenamed("consignee_cnt_d9m", "sj_第9月")
//      .withColumnRenamed("consignee_cnt_d8m", "sj_第8月")
//      .withColumnRenamed("consignee_cnt_d7m", "sj_第7月")
//      .withColumnRenamed("consignee_cnt_d6m", "sj_第6月")
//      .withColumnRenamed("consignee_cnt_d5m", "sj_第5月")
//      .withColumnRenamed("consignee_cnt_d4m", "sj_第4月")
//      .withColumnRenamed("consignee_cnt_d3m", "sj_第3月")
//      .withColumnRenamed("consignee_cnt_d2m", "sj_第2月")
//      .withColumnRenamed("consignee_cnt_d1m", "sj_第1月")
//      .withColumnRenamed("consignee_cnt_d12m_ts", "sj_第12月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d11m_ts", "sj_第11月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d10m_ts", "sj_第10月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d9m_ts", "sj_第9月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d8m_ts", "sj_第8月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d7m_ts", "sj_第7月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d6m_ts", "sj_第6月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d5m_ts", "sj_第5月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d4m_ts", "sj_第4月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d3m_ts", "sj_第3月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d2m_ts", "sj_第2月(剔除特殊时间)")
//      .withColumnRenamed("consignee_cnt_d1m_ts", "sj_第1月(剔除特殊时间)")
//      .withColumnRenamed("recent_1y_stab", "sj_近1年的收快递稳定性(剔除特殊时间)")
//      .withColumnRenamed("signin_tm_zs_cnt", "sj_早")
//      .withColumnRenamed("signin_tm_zw_cnt", "sj_中")
//      .withColumnRenamed("signin_tm_ws_cnt", "sj_晚")
//      .withColumnRenamed("consignee_cnt_618", "sj_618")
//      .withColumnRenamed("consignee_cnt_1111", "sj_1111")
//      .withColumnRenamed("consignee_cnt_1212", "sj_1212")
//      .withColumnRenamed("consignee_cnt_tmall", "sj_天猫")
//      .withColumnRenamed("consignee_cnt_jd", "sj_京东")
//      .withColumnRenamed("consignee_cnt_pos", "sj_pos机")
//      .withColumnRenamed("consignee_max_dm", "sj_最大月份")
//      .withColumnRenamed("consignee_cnt_dm", "sj_有收件的月个数")
//      .withColumnRenamed("consignee_city_cnt", "sj_城市数")


    // 注册函数
    registerFun(spark)


    inputDf.repartition(repart_n).createTempView("frc_features_input")


    val dframe = spark.sql(
      """
        |
        |
        |select
        |tel_md5,
        |case when consigned_cnt_90d is not null then splitV1(consigned_cnt_90d) else 'X' end as v1,
        |case when consigned_cnt_180d is not null then splitV2(consigned_cnt_180d) else 'X' end  as v2,
        |case when consigned_cnt_365d is not null then splitV3(consigned_cnt_365d) else 'X' end  as v3,
        |case when consigned_cnt_365d_nospecial is not null then splitV4(consigned_cnt_365d_nospecial) else 'X' end  as v4,
        |case when cnt_dm is not null then splitV5(cnt_dm) else 'X' end  as v5,
        |case when recent_days is not null then splitV6(recent_days) else 'X' end  as v6,
        |case when consignee_cnt_30d is not null then splitV7(consignee_cnt_30d) else 'X' end  as v7,
        |case when consignee_cnt_90d is not null then splitV8(consignee_cnt_90d) else 'X' end  as v8,
        |case when consignee_cnt_180d is not null then splitV9(consignee_cnt_180d) else 'X' end  as v9,
        |case when consignee_cnt_365d is not null then splitV10(consignee_cnt_365d) else 'X' end  as v10,
        |case when consignee_cnt_365d_nospecial is not null then splitV11(consignee_cnt_365d_nospecial) else 'X' end  as v11,
        |case when recent_1y_stab is not null then splitV12(recent_1y_stab) else 'X' end  as v12,
        |case when signin_tm_zs_cnt is not null then splitV13(signin_tm_zs_cnt) else 'X' end  as v13,
        |case when signin_tm_zw_cnt is not null then splitV14(signin_tm_zw_cnt) else 'X' end  as v14,
        |case when signin_tm_ws_cnt is not null then splitV15(signin_tm_ws_cnt) else 'X' end  as v15,
        |case when consignee_cnt_618 is not null then splitV16(consignee_cnt_618) else 'X' end  as v16,
        |case when consignee_cnt_tmall is not null then splitV17(consignee_cnt_tmall) else 'X' end  as v17,
        |case when consignee_max_dm is not null then splitV18(consignee_max_dm) else 'X' end  as v18,
        |case when consignee_cnt_dm is not null then splitV19(consignee_cnt_dm) else 'X' end  as v19,
        |case when consignee_cnt_d2m is not null then splitV20(consignee_cnt_d2m) else 'X' end  as v20
        |
        |from frc_features_input
        |
        |
        |""".stripMargin)

    dframe.createTempView("frc_features_v20")

    logger.error(s"写入hive  ${out_table1}  中...")
    val resDf = spark.sql(
      s"""
        |insert overwrite table ${out_table1} partition(inc_day='${inc_day}',id='${id}')
        |select
        |tel_md5,
        |concat(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20) as m7s
        |
        |from frc_features_v20
        |
        |""".stripMargin)

    resDf.repartition(20).show()
    logger.error(s"写入分区 inc_day='${inc_day}',id='${id}' 成功")



    logger.error("任务结束")
    spark.stop()


  }


  /**
   * 自定义注册函数
   *
   */
  def registerFun(spark: SparkSession): Unit ={
    /**
     * 自定义函数：splitV1
     */
    spark.udf.register("splitV1", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0.0) ){
          res = "0"
        }else if( (0.0<w) && (w<=1.0) ){
          res = "1"
        }else if( (1.0<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=3) ){
          res = "3"
        }else if( (3<w) && (w<=4) ){
          res = "4"
        }else if( (4<w) && (w<=6) ){
          res = "5"
        }else if( (6<w) && (w<=9) ){
          res = "6"
        }else if( (9<w) && (w<=15) ){
          res = "7"
        }else if( (15<w) && (w<=30) ){
          res = "8"
        }else if( (30<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV2
     */
    spark.udf.register("splitV2", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0.0) ){
          res = "0"
        }else if( (0.0<w) && (w<=1.0) ){
          res = "1"
        }else if( (1.0<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=4) ){
          res = "3"
        }else if( (4<w) && (w<=6) ){
          res = "4"
        }else if( (6<w) && (w<=10) ){
          res = "5"
        }else if( (10<w) && (w<=14) ){
          res = "6"
        }else if( (14<w) && (w<=20) ){
          res = "7"
        }else if( (20<w) && (w<=50) ){
          res = "8"
        }else if( (50<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV3
     */
    spark.udf.register("splitV3", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=1.0) ){
          res = "0"
        }else if( (1.0<w) && (w<=2.0) ){
          res = "1"
        }else if( (2.0<w) && (w<=4) ){
          res = "2"
        }else if( (4<w) && (w<=5) ){
          res = "3"
        }else if( (5<w) && (w<=8) ){
          res = "4"
        }else if( (8<w) && (w<=12) ){
          res = "5"
        }else if( (12<w) && (w<=20) ){
          res = "6"
        }else if( (20<w) && (w<=41) ){
          res = "7"
        }else if( (41<w) && (w<=100) ){
          res = "8"
        }else if( (100<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV4
     */
    spark.udf.register("splitV4", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0) ){
          res = "0"
        }else if( (0<w) && (w<=1) ){
          res = "1"
        }else if( (1<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=4) ){
          res = "3"
        }else if( (4<w) && (w<=6) ){
          res = "4"
        }else if( (6<w) && (w<=9) ){
          res = "5"
        }else if( (9<w) && (w<=12) ){
          res = "6"
        }else if( (12<w) && (w<=22) ){
          res = "7"
        }else if( (22<w) && (w<=50) ){
          res = "8"
        }else if( (50<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV5
     */
    spark.udf.register("splitV5", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=1) ){
          res = "0"
        }else if( (1<w) && (w<=2) ){
          res = "1"
        }else if( (2<w) && (w<=3) ){
          res = "2"
        }else if( (3<w) && (w<=5) ){
          res = "3"
        }else if( (5<w) && (w<=6) ){
          res = "4"
        }else if( (6<w) && (w<=8) ){
          res = "5"
        }else if( (8<w) && (w<=9) ){
          res = "6"
        }else if( (9<w) && (w<=10) ){
          res = "7"
        }else if( (10<w) && (w<=11) ){
          res = "8"
        }else if( (11<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV6
     */
    spark.udf.register("splitV6", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=7) ){
          res = "0"
        }else if( (7<w) && (w<=14) ){
          res = "1"
        }else if( (14<w) && (w<=21) ){
          res = "2"
        }else if( (21<w) && (w<=30) ){
          res = "3"
        }else if( (30<w) && (w<=60) ){
          res = "4"
        }else if( (60<w) && (w<=90) ){
          res = "5"
        }else if( (90<w) && (w<=120) ){
          res = "6"
        }else if( (120<w) && (w<=200) ){
          res = "7"
        }else if( (200<w) && (w<=300) ){
          res = "8"
        }else if( (300<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV7
     */
    spark.udf.register("splitV7", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0) ){
          res = "0"
        }else if( (0<w) && (w<=1) ){
          res = "1"
        }else if( (1<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=3) ){
          res = "3"
        }else if( (3<w) && (w<=4) ){
          res = "4"
        }else if( (4<w) && (w<=5) ){
          res = "5"
        }else if( (5<w) && (w<=6) ){
          res = "6"
        }else if( (6<w) && (w<=9 ) ){
          res = "7"
        }else if( (9<w) && (w<=15) ){
          res = "8"
        }else if( (15<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV8
     */
    spark.udf.register("splitV8", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0) ){
          res = "0"
        }else if( (0<w) && (w<=1) ){
          res = "1"
        }else if( (1<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=3) ){
          res = "3"
        }else if( (3<w) && (w<=5) ){
          res = "4"
        }else if( (5<w) && (w<=6) ){
          res = "5"
        }else if( (6<w) && (w<=8) ){
          res = "6"
        }else if( (8<w) && (w<=13 ) ){
          res = "7"
        }else if( (13<w) && (w<=30) ){
          res = "8"
        }else if( (30<w)  ){
          res = "9"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV9
     */
    spark.udf.register("splitV9", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0) ){
          res = "0"
        }else if( (0<w) && (w<=1) ){
          res = "1"
        }else if( (1<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=3) ){
          res = "3"
        }else if( (3<w) && (w<=5) ){
          res = "4"
        }else if( (5<w) && (w<=8) ){
          res = "5"
        }else if( (8<w) && (w<=12) ){
          res = "6"
        }else if( (12<w) && (w<=21 ) ){
          res = "7"
        }else if( (21<w) && (w<=38) ){
          res = "8"
        }else if( (38<w)  ){
          res = "9"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV10
     */
    spark.udf.register("splitV10", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=2) ){
          res = "0"
        }else if( (2<w) && (w<=3) ){
          res = "1"
        }else if( (3<w) && (w<=5) ){
          res = "2"
        }else if( (5<w) && (w<=7) ){
          res = "3"
        }else if( (7<w) && (w<=11) ){
          res = "4"
        }else if( (11<w) && (w<=15) ){
          res = "5"
        }else if( (15<w) && (w<=23) ){
          res = "6"
        }else if( (23<w) && (w<=43 ) ){
          res = "7"
        }else if( (43<w) && (w<=71) ){
          res = "8"
        }else if( (71<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV11
     */
    spark.udf.register("splitV11", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=1) ){
          res = "0"
        }else if( (1<w) && (w<=3) ){
          res = "1"
        }else if( (3<w) && (w<=5) ){
          res = "2"
        }else if( (5<w) && (w<=8) ){
          res = "3"
        }else if( (8<w) && (w<=11) ){
          res = "4"
        }else if( (11<w) && (w<=19) ){
          res = "5"
        }else if( (19<w) && (w<=27) ){
          res = "6"
        }else if( (27<w) && (w<=41 ) ){
          res = "7"
        }else if( (41<w) && (w<=84) ){
          res = "8"
        }else if( (84<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV12
     */
    spark.udf.register("splitV12", (w:Double) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0.7) ){
          res = "0"
        }else if( (0.7<w) && (w<=0.913) ){
          res = "1"
        }else if( (0.913<w) && (w<=1.095) ){
          res = "2"
        }else if( (1.095<w) && (w<=1.247) ){
          res = "3"
        }else if( (1.247<w) && (w<=1.399) ){
          res = "4"
        }else if( (1.399<w) && (w<=1.528) ){
          res = "5"
        }else if( (1.528<w) && (w<=1.704) ){
          res = "6"
        }else if( (1.704<w) && (w<=2.221 ) ){
          res = "7"
        }else if( (2.221<w) && (w<=3.316) ){
          res = "8"
        }else if( ( 3.316<w )  ){
          res = "9"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV13
     */
    spark.udf.register("splitV13", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=1) ){
          res = "0"
        }else if( (1<w) && (w<=2) ){
          res = "1"
        }else if( (2<w) && (w<=3) ){
          res = "2"
        }else if( (3<w) && (w<=4) ){
          res = "3"
        }else if( (4<w) && (w<=8) ){
          res = "4"
        }else if( (8<w) && (w<=12) ){
          res = "5"
        }else if( (12<w) && (w<=20) ){
          res = "6"
        }else if( (20<w) && (w<=24 ) ){
          res = "7"
        }else if( (24<w) && (w<=49) ){
          res = "8"
        }else if( (49<w)  ){
          res = "9"
        }
      }
      res
    })

    /**
     * 自定义函数：splitV14
     */
    spark.udf.register("splitV14", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=1) ){
          res = "0"
        }else if( (1<w) && (w<=2) ){
          res = "1"
        }else if( (2<w) && (w<=3) ){
          res = "2"
        }else if( (3<w) && (w<=4) ){
          res = "3"
        }else if( (4<w) && (w<=6) ){
          res = "4"
        }else if( (6<w) && (w<=9) ){
          res = "5"
        }else if( (9<w) && (w<=12) ){
          res = "6"
        }else if( (12<w) && (w<=18 ) ){
          res = "7"
        }else if( (18<w) && (w<=35) ){
          res = "8"
        }else if( (35<w)  ){
          res = "9"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV15
     */
    spark.udf.register("splitV15", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0) ){
          res = "0"
        }else if( (0<w) && (w<=1) ){
          res = "1"
        }else if( (1<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=3) ){
          res = "3"
        }else if( (3<w) && (w<=4) ){
          res = "4"
        }else if( (4<w) && (w<=6) ){
          res = "5"
        }else if( (6<w) && (w<=8) ){
          res = "6"
        }else if( (8<w) && (w<=12 ) ){
          res = "7"
        }else if( (12<w) && (w<=18) ){
          res = "8"
        }else if( (18<w)  ){
          res = "9"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV16
     */
    spark.udf.register("splitV16", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0) ){
          res = "0"
        }else if( (0<w) && (w<=1) ){
          res = "1"
        }else if( (1<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=3) ){
          res = "3"
        }else if( (3<w) && (w<=4) ){
          res = "4"
        }else if( (4<w) && (w<=5) ){
          res = "5"
        }else if( (5<w) && (w<=6) ){
          res = "6"
        }else if( (6<w) && (w<=7 ) ){
          res = "7"
        }else if( (7<w) && (w<=13) ){
          res = "8"
        }else if( (13<w)  ){
          res = "9"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV17
     */
    spark.udf.register("splitV17", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0) ){
          res = "0"
        }else if( (0<w) && (w<=1) ){
          res = "1"
        }else if( (1<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=5) ){
          res = "3"
        }else if( (5<w)  ){
          res = "4"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV18
     */
    spark.udf.register("splitV18", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=1) ){
          res = "0"
        }else if( (1<w) && (w<=2) ){
          res = "1"
        }else if( (2<w) && (w<=3) ){
          res = "2"
        }else if( (3<w) && (w<=4) ){
          res = "3"
        }else if( (4<w) && (w<=5) ){
          res = "4"
        }else if( (5<w) && (w<=6) ){
          res = "5"
        }else if( (6<w) && (w<=8) ){
          res = "6"
        }else if( (8<w) && (w<=10 ) ){
          res = "7"
        }else if( (10<w) && (w<=14) ){
          res = "8"
        }else if( (14<w)  ){
          res = "9"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV19
     */
    spark.udf.register("splitV19", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=1) ){
          res = "0"
        }else if( (1<w) && (w<=2) ){
          res = "1"
        }else if( (2<w) && (w<=3) ){
          res = "2"
        }else if( (3<w) && (w<=4) ){
          res = "3"
        }else if( (4<w) && (w<=5) ){
          res = "4"
        }else if( (5<w) && (w<=7) ){
          res = "5"
        }else if( (7<w) && (w<=9) ){
          res = "6"
        }else if( (9<w) && (w<=10 ) ){
          res = "7"
        }else if( (10<w) && (w<=11) ){
          res = "8"
        }else if( (11<w)  ){
          res = "9"
        }
      }
      res
    })
    /**
     * 自定义函数：splitV20
     */
    spark.udf.register("splitV20", (w:Int) => {
      var res :String = "X"
      if( null!=w ){
        if( (-1.0<w) && (w<=0) ){
          res = "0"
        }else if( (0<w) && (w<=1) ){
          res = "1"
        }else if( (1<w) && (w<=2) ){
          res = "2"
        }else if( (2<w) && (w<=3) ){
          res = "3"
        }else if( (3<w) && (w<=4) ){
          res = "4"
        }else if( (4<w) && (w<=5) ){
          res = "5"
        }else if( (5<w) && (w<=6) ){
          res = "6"
        }else if( (6<w) && (w<=9 ) ){
          res = "7"
        }else if( (9<w) && (w<=15) ){
          res = "8"
        }else if( (15<w)  ){
          res = "9"
        }
      }
      res
    })
  }


}
