package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{HttpConnection, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util

/**
 * Created by 01416344 on 2021/12/16.
 * 银联电话地址数据按天新增
 */

object UnionPayWriteToRedisTwoAddApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  //测试
//  val URL = "http://gis-int.intsit.sfdc.com.cn:1080/unionpay/api/add"
//  val AK = "50e1947c655747f18b7649e7001bd026"
  //生产
  val URL = "http://gis-int.int.sfdc.com.cn:1080/unionpay/api/add"
  val AK = "e7e0666ab27443f9a88a63b97993195b"


  def main(args: Array[String]): Unit = {

    /**
     * json:
      *{
        *"ak":"8bb09e5e110845f39a000391668e3e80",
        *"addr":"深圳市软件产业基地5E",
        *"phone":"7d9f41baaf5936cfc57d7b0e0fc85bdf",
        *"time":1638180550
      *}
     */

    val  startTime = args(0)
    val  endTime = args(1)
    val  parNum = args(2).toInt  //并行度


    val sparkInfo = SparkUtil.getSpark(appName)
    val spark = sparkInfo.getSession

    val querySql =
      s"""
         |select
         |tel_md5,citycode,addr,action,action_time
         |from dm_gis.tel_addr_unionpay_tmp1 where action_date>='$startTime' and action_date<'$endTime'  order by action_time asc
         |""".stripMargin
    println(querySql)

    val sourDf = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK)


//    val sparkConf = new SparkConf().setMaster("local[1]").setAppName(appName)
//    val spark = SparkSession.builder().config(sparkConf).getOrCreate()
//
//    val df = spark.read.format("csv")
//      .option("delimiter", "|")
//      .load("./tals/data/unionPay.txt")
//      .toDF("x0","tel_md5","citycode","addr","action","action_time","x1")
//
//    import spark.implicits._
//    val sourDf = df.select("tel_md5","citycode","addr","action","action_time")
//      .map( item => Tuple5(item(0).toString.trim,item(1).toString.trim,item(2).toString.trim,item(3).toString.trim,item(4).toString.trim) )
//      .toDF("tel_md5","citycode","addr","action","action_time")




    val colList = sourDf.columns
    val keyMap = new util.HashMap[String, String]
    for(column <- colList){
        column match {
          case "tel_md5" => keyMap.put(column, "phone")
          case "citycode" => keyMap.put(column, "citycode")
          case "addr" => keyMap.put(column, "addr")
          case "action" => keyMap.put(column, "action")
          case "action_time" => keyMap.put(column, "actionTime")
        }
    }

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("ak", AK)
      for (columns <- colList) {
        if (!"action_time".equals(columns)) jsonObj.put(keyMap.get(columns), obj.getAs[String](columns)) else{
          val actionTimeStr = obj.getAs[String](columns)
          if (!actionTimeStr.isEmpty) {
            val simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            jsonObj.put(keyMap.get(columns), simpleDateFormat.parse(actionTimeStr).getTime / 1000)
          }else jsonObj.put(keyMap.get(columns), 0)
        }
      }
//      jsonObj.toJSONString
      HttpConnection.httpPost(3, URL, jsonObj.toJSONString)
    })

    logger.error(s"数据量:${sourRdd.count()}")

    spark.stop()


  }

}
