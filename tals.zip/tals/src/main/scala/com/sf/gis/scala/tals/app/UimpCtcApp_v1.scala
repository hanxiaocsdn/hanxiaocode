package com.sf.gis.scala.tals.app


import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.json.JSONArray
import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.util.JSONUtil

import scala.collection.JavaConversions.asScalaIterator
/**
 * Created by 01421359 on 2022/11/12.
 * 统一报表平台 CTC合同报表
 * 描述：供应商名称改成改取“outerSupplierName”的值
        供应商编码改取“outerSupplierCode”的值
        【税率(带%)】取值逻辑变更为：
        根据contractCode匹配，取 taxPoint的值、或者【票据税率 voucherTax】的值
        【付款条件】取值逻辑变更为：
        根据contractCode匹配，取paymentCondition的值、或者【paymentTerms】的值
 *
 */

object UimpCtcApp_v1 {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    //    // 测试
    //      val sparkConf = new SparkConf().setMaster("local[3]").setAppName(appName)
    //        .set("spark.executor.cores","1")
    //        .set("spark.executor.instances","1")
    //        .set("spark.driver.cores","1")
    //      val spark = SparkSession.builder().config(sparkConf).getOrCreate()
    //
    //      val intDf = spark.read.format("csv")
    //        .option("delimiter", "\001")
    //        .option("header","true")
    //        .load("./tals/data/ctc.csv")
    //        .toDF()
    //
    //    intDf.show()

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc", "true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql0 = args.apply(0)
    val out_table1 = args.apply(1)
    val inc_day = args.apply(2)

    val partition_1 = 20
    val partition_2 = 1

    val intDf = spark.sql(int_sql0)
    intDf.show(5)

    import spark.implicits._
    val rdd1: RDD[(String, String, String, String, String, String, String, String, String, String,
      String, String, String, String, String, String, String, String, String, String)] = intDf.repartition(partition_1).rdd.map(o => {
      val jSONObject = JSONUtil.parseJSONObject(o.getString(0))
      if (null != jSONObject) {

        val contractVO = jSONObject.getJSONObject("contractVO")
        val contractCode = contractVO.getString("contractCode") // 合同编号
        val contractStatus = contractVO.getString("contractStatus") //合同状态
        val enableDate = contractVO.getString("enableDate") // 合同开始日期
        val disableDate = contractVO.getString("disableDate") // 合同结束日期
        val contractName = contractVO.getString("contractName") // 合同内容
        val createrCode = contractVO.getString("createrCode") // 经办人工号
        val createrName = contractVO.getString("createrName") // 经办人
        val createOrganization = contractVO.getString("createOrganization") // 采购组织
        val createOrganizationName = contractVO.getString("createOrganizationName") // 采购组织


        val supplierList = jSONObject.getJSONArray("supplierList")
        val supplierListJava = supplierList.iterator().toList
        var supplierCode = "" //签约主体
        val supplierName = contractVO.getString("outerSupplierName") //供应商名称
        val supplierCode_gys = contractVO.getString("outerSupplierCode") // 供应商编码
        var taxPoint = "" // 税率
        var paymentCondition = "" // 付款条件

        val dynamicValueMap = jSONObject.getJSONObject("dynamicValueMap")

        if (null != supplierListJava) {
          supplierListJava.map(m => {
            val jSONObject1 = JSONUtil.parseJSONObject(m.toString)
            if ("innerSupplier".equals(jSONObject1.getString("supplierType"))) {
              supplierCode = jSONObject1.getString("supplierCode")

              val financeList = jSONObject1.getJSONArray("financeList")
              if (null != financeList) {
                val financeListJava = financeList.iterator().toList
                if (null != financeListJava) {
                  financeListJava.map(m1 => {
                    val jSONObject1 = JSONUtil.parseJSONObject(m1.toString)
                    taxPoint = jSONObject1.getString("taxPoint")
                    paymentCondition = jSONObject1.getString("paymentCondition")

                  })
                }
              }

            }
            //            if ("outerSupplier".equals(jSONObject1.getString("supplierType"))) {
            //              supplierName = jSONObject1.getString("supplierName")
            //              supplierCode_gys = jSONObject1.getString("supplierCode")
            //            }


          })

        }
        if (StringUtils.isEmpty(taxPoint)) {
          taxPoint = dynamicValueMap.getString("voucherTax")
        }
        if (StringUtils.isEmpty(paymentCondition)) {
          paymentCondition = dynamicValueMap.getString("paymentTerms")
        }
        val contractType = dynamicValueMap.getString("contractType") //合同类别
        val htssBU = dynamicValueMap.getString("htssBU") //BU
        val htssdq = dynamicValueMap.getString("htssdq") //大区
        val htlx = dynamicValueMap.getString("htlx") //是否框架合同
        val htgsxmdm = dynamicValueMap.getString("htgsxmdm") //销售项目
        var amount = dynamicValueMap.getString("amount") //合同金额
        if (null == amount) {
          val contAmount = dynamicValueMap.getJSONObject("contAmount") //合同金额
          if (null != contAmount) {
            amount = contAmount.getString("money")
          }
        }


        (contractCode, contractStatus, enableDate, disableDate, contractName, createrCode, createrName, createOrganization, createOrganizationName,
          supplierCode, supplierName, supplierCode_gys, taxPoint, paymentCondition,
          contractType, htssBU, htssdq, htlx, htgsxmdm, amount)
      }
      else {
        (o.getString(0), "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
      }
    })

    val outDf = rdd1.toDF("contract_code", "contract_status", "enable_date", "disable_date", "contract_name",
      "creater_code", "creater_name", "create_organization", "create_organization_name", "supplier_code", "supplier_name",
      "supplier_code_gys", "tax_point", "payment_condition", "contract_type", "htss_bu", "htss_dq", "htlx", "htgsxmdm", "amount")
    outDf.show()
    outDf.createTempView("dwd_issp_ctc")
    //    outDf.repartition(partition_2).write.format("com.databricks.spark.csv").option("header", "true").save("./tals/output/ctc_out")
    val outDf1 = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table1} partition(inc_day=${inc_day})
         |select
         |contract_code,contract_status,enable_date,disable_date,contract_name,
         |creater_code,creater_name,create_organization,create_organization_name,supplier_code,supplier_name,
         |supplier_code_gys,tax_point,payment_condition,contract_type,htss_bu,htss_dq,htlx,htgsxmdm,amount
         |from dwd_issp_ctc
         |
         |""".stripMargin)
    outDf1.repartition(partition_2).show()

    logger.error("spark任务结束")
    spark.stop()

  }

}
