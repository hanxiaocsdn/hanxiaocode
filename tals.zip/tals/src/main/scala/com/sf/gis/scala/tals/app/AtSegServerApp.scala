package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.tals.method.MySfNetInteface
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
 * AT派-跑seg接口
 * 需求方：李莹（01425237）
 * @author 张小琼 （01416344）
 * Created on 2023-02-08
 * 任务信息： 临时跑数用，未发布任务
 *
 */

object AtSegServerApp {


  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val parNum = 200  //并行度
    val sparkInfo = SparkUtil.getSpark(appName)
    val sparkSession = sparkInfo.getSession

    val int_sql = args.apply(0)
    val out_table = args.apply(1)
    val inc_day = args.apply(2)
    val dest_dist_code = args.apply(3)
    val pall_num = args.apply(4).toInt

    val waybillSql = int_sql
    println(waybillSql)
    val waybillDf = sparkSession.sql(waybillSql)
    waybillDf.show(10)


    val inputRdd = waybillDf.rdd.repartition(parNum).map(x => {
      val resJson = new JSONObject()
      resJson.put("province",x.getAs[String]("province"))
      resJson.put("city",x.getAs[String]("city"))
      resJson.put("county",x.getAs[String]("county"))
      resJson.put("address",x.getAs[String]("address"))
      resJson
    })

    val outRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession, inputRdd, MySfNetInteface.atSeg , 20, MySfNetInteface.AK_AT_SEG, pall_num)
    val resRdd = outRDD.map( x => {
      var resTuple = Tuple8[String,String,String,String,String,String,String,String]("","","","","","","","")

      val province = x.getString("province")
      val city = x.getString("city")
      val county = x.getString("county")
      val address = x.getString("address")

      val resJson = x.getJSONObject("atSeg")
      if (null!=resJson && resJson.get("status")==0){
        val resultJson: JSONObject = resJson.getJSONObject("result")
        val dataJson = resultJson.getJSONObject("data")
        resTuple = Tuple8[String,String,String,String,String,String,String,String](
          province,
          city,
          county,
          address,
          if (null!=dataJson.getString("provinceCode")) dataJson.getString("provinceCode") else "",
          if (null!=dataJson.getString("countyCode")) dataJson.getString("countyCode") else "",
          if (null!=dataJson.getString("citycode")) dataJson.getString("citycode") else "",
          if (null!=dataJson.getString("adcode")) dataJson.getString("adcode") else ""
        )
      }else{
        resTuple = Tuple8[String,String,String,String,String,String,String,String](
          province,
          city,
          county,
          address,
          "",
          "",
          "",
          ""
        )
      }
      resTuple
    })

    import sparkSession.implicits._
    val resSrcDf = resRdd.toDF("province","city","county","address","province_code","county_code","city_code","adcode")
    resSrcDf.createTempView("at_seg_server_out")

    logger.error(s"写入hive  ${out_table}  中...")
    val resOutDF = sparkSession.sql(
      s"""
         |
         |insert overwrite table ${out_table} partition(inc_day='${inc_day}',dest_dist_code='${dest_dist_code}')
         |select
         |province,city,county,address,province_code,county_code,city_code,adcode
         |from at_seg_server_out
         |
         |""".stripMargin)
    resOutDF.repartition(20).show()
    logger.error(s"写入分区 inc_day='${inc_day}',dest_dist_code='${dest_dist_code}' 成功")

    sparkSession.stop()
    logger.error("任务结束。")

  }

}
