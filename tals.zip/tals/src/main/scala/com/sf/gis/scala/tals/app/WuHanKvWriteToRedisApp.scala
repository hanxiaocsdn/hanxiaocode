package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{HttpConnection, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util

/**
 * Created by 01416344 on 2022/02/11.
 * 武汉KV库天汇总数据写入redis
 */

object WuHanKvWriteToRedisApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  //生产
  val URL = "http://gis-int.int.sfdc.com.cn:1080/unionpay/api/addDeliFrequency"
  var AK = "1c5e0f56ef7b462098a89454fb1b05e3"


  def main(args: Array[String]): Unit = {

    /**
     * json:
        {
        "ak":"申请AK",
        "roomId":"47F5046C369811EBA3130F2334609108",
        "type":"l_fj",
        "period":"20220117",
        "cityCode":"028",
        "freq":"12"
        }
     */

    val  startTime = args(0)
    val  endTime = args(1)
    val  parNum = args(2).toInt  //并行度
    val  startPeriod = args(3)
    val  endPeriod = args(4)
    AK = args(5)


    val sparkInfo = SparkUtil.getSpark(appName)
    val spark = sparkInfo.getSession

    val querySql =
      s"""
         |select
         |room_id,count,src,city_code,period
         |from dm_gis.tel_wuhan_kafka_kv where inc_day>='$startTime' and inc_day<'$endTime' and period>='$startPeriod' and period<'$endPeriod'
         |""".stripMargin
    println(querySql)

    val sourDf = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK)

    val colList = sourDf.columns
    val keyMap = new util.HashMap[String, String]
    for(column <- colList){
        column match {
          case "room_id" => keyMap.put(column, "roomId")
          case "src" => keyMap.put(column, "type")
          case "period" => keyMap.put(column, "period")
          case "city_code" => keyMap.put(column, "cityCode")
          case "count" => keyMap.put(column, "freq")
        }
    }

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("ak", AK)
      for (columns <- colList) {
        jsonObj.put(keyMap.get(columns), obj.getAs[String](columns))
      }
//      jsonObj.toJSONString
      HttpConnection.httpPost(3, URL, jsonObj.toJSONString)
    })

    logger.error(s"数据量:${sourRdd.count()}")

    spark.stop()


  }

}
