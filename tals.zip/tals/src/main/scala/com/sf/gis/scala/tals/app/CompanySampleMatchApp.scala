package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{HttpConnection, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SaveMode}
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util
import scala.collection.JavaConversions.asScalaBuffer
import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01416344 on 2022/02/17.
 * 样例企业匹配
 */

object CompanySampleMatchApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)




  def main(args: Array[String]): Unit = {

    val  halfTime = args(0)
    val  parNum = args(1).toInt  //并行度
    val  tableName = args(2)
    val  tableName1  = args(3)

    val sparkInfo = SparkUtil.getSpark(appName)
    val spark = sparkInfo.getSession


    val sampleSql =
      s"""
         |select company_name,credit_code,zt,dy,hy,hz,fdy,fhz,fhy,fzt,city_code_dy,city_code_fdy from dm_gis.city_sample_fenci_citycode_sample
         |""".stripMargin
    println(sampleSql)
    val sampleDf = spark.sql(sampleSql).persist(StorageLevel.MEMORY_AND_DISK)
    sampleDf.show(10)
    val sampleLst = sampleDf.collect().toList
    println(sampleLst.length)

    val waybillSql =
      s"""
         |select consignor_name,city_code
         |from $tableName where inc_day='$halfTime'
         |""".stripMargin
    println(waybillSql)
    val waybillDf = spark.sql(waybillSql).persist(StorageLevel.MEMORY_AND_DISK)
    waybillDf.show(10)


    val cartesianRdd = waybillDf.rdd.repartition(parNum).cartesian(spark.sparkContext.makeRDD(sampleLst))

    val resRdd = cartesianRdd.map( o => {
      val waybillRow = o._1
      val row = o._2

      val consignor_name = waybillRow.getAs[String]("consignor_name")
      val city_code = waybillRow.getAs[String]("city_code")

      var tupleRes = Tuple5[String, String, String, String, String]("","","","","")
      val company_name = row.getAs[String]("company_name")
      val credit_code = row.getAs[String]("credit_code")
      val zt = row.getAs[String]("zt")
      val dy = row.getAs[String]("dy")
      val hy = row.getAs[String]("hy")
      val hz = row.getAs[String]("hz")
      val fdy = row.getAs[String]("fdy")
      val fhz = row.getAs[String]("fhz")
      val fhy = row.getAs[String]("fhy")
      val fzt = row.getAs[String]("fzt")
      val city_code_dy = row.getAs[String]("city_code_dy")
      val city_code_fdy = row.getAs[String]("city_code_fdy")

      // zt、fzt、hy、fhy
      var ztHave = getAStringContainB(consignor_name, zt)
      var fztHave = getAStringContainB(consignor_name, fzt)
      var hyHave = getAStringContainB(consignor_name, hy)
      var fhyHave = getAStringContainB(consignor_name, fhy)
      // dy、fdy
      var dyHave = getAStringContainB(consignor_name, dy)
      var fdyHave = getAStringContainB(consignor_name, fdy)
      // hz、fhz
      var hzHave = getAStringContainB(consignor_name, hz)
      var fhzHave = getAStringContainB(consignor_name, fhz)

      if (ztHave && fztHave && hyHave && fhyHave && dyHave && fdyHave && hzHave && fhzHave) {
        tupleRes = new Tuple5[String, String, String, String, String](consignor_name, city_code, company_name, credit_code, halfTime)
      } else {
        if (ztHave && fztHave && hyHave && fhyHave &&
          (null!=dy && !dy.isEmpty && dyHave || null!=fdy &&  !fdy.isEmpty && fdyHave
            || null!=city_code_dy && !city_code_dy.isEmpty && city_code_dy == credit_code
            || null!=city_code_fdy && !city_code_fdy.isEmpty && city_code_fdy == credit_code)) {
          tupleRes = new Tuple5[String, String, String, String, String](consignor_name, city_code, company_name, credit_code, halfTime)
        }
      }

      tupleRes

    }).filter( x => null!=x._1 && !x._1.isEmpty)

//    println(resRdd.count())


    import spark.implicits._
    val rDf = resRdd.repartition(1).toDF("consignor_name","city_code","company_name","credit_code","inc_day")

//    rDf.repartition(1).createOrReplaceTempView("tmptable")

//    val insertSql =
//      s"""
//         |insert into $tableName1 partition(inc_day='$halfTime') select consignor_name,city_code,company_name,credit_code from tmptable
//         |""".stripMargin
//    spark.sql(insertSql)

    rDf.repartition(1).write.mode("append").format("Hive").saveAsTable(tableName1)
//    rDf.show(2000)

    spark.stop()

    logger.error("任务结束。")

  }

  /**
   *
   * @param a
   * @param b
   */
  def getAStringContainB(a: String,b: String): Boolean ={
    var isContain = true
    if (null!=b && !b.isEmpty){
      if(null!=a && !a.isEmpty){
        if(a.contains(b)){
          isContain = true
        }else{
          isContain = false
        }
      }
    }
    isContain
  }

}
