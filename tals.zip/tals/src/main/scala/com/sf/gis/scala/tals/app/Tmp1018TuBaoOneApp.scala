package com.sf.gis.scala.tals.app

import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.java.base.util.GeometryUtil.createPoint
import com.vividsolutions.jts.geom.{Point, Polygon}
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}

import java.util
import java.util.{ArrayList, List}
import scala.collection.JavaConverters.asJavaIterableConverter

/**
 * create by 01416344(张小琼) on 2022/10/19
 * 小区楼栋数据验证跑凸点多边形及判断
 * 描述：楼栋事件经纬坐标数组跑凸点，判断楼栋是否在多边形内
 */
object Tmp1018TuBaoOneApp {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql = args.apply(0)
    val out_table1 = args.apply(1)

    val intDf = spark.sql(int_sql)


//    val parNum = 2  //并行度
//    val sparkConf = new SparkConf().setMaster("local[3]").setAppName(appName)
//      .set("spark.executor.cores","1")
//      .set("spark.executor.instances","1")
//      .set("spark.driver.cores","1")
//    val spark = SparkSession.builder().config(sparkConf).getOrCreate()
//
//    val intDf = spark.read.format("csv")
//      .option("delimiter", ",")
//      .load("./tals/data/tmp_1018_kyhy_event.csv")
//      .toDF()

    intDf.show()

    import spark.implicits._
    val rdd1:RDD[(String,String)] = intDf.repartition(100).rdd.map(o => {
      val k = o.getString(0) + "_" + o.getString(1) + "_" + o.getString(2)
      val v = o.getString(3) + "_" + o.getString(4)
      (k, v)
    })
    val rdd2 = rdd1.groupByKey().map(gpd => {
      val k = gpd._1
      import collection.JavaConverters._
      val k1 = new util.ArrayList(k.split("_").toList.asJava)
      val bld = k1.get(0)
      val x = k1.get(1)
      val y = k1.get(2)
      val v = gpd._2.toList
      if (v.size>=3) {
        val points = new util.ArrayList[Point]
        v.foreach( w => {
//          import collection.JavaConverters._
          val vv : util.ArrayList[String] = new java.util.ArrayList(w.split("_").toList.asJava)
          points.add(createPoint(vv.get(0), vv.get(1)))
        } )

        val points1: util.List[Point] = GeometryUtil.convexHull(points)
        val wktStr: String = GeometryUtil.getPolygonStrByPoints(points1)
        val wktPolygon: Polygon = GeometryUtil.createPolygonByWKT(wktStr)
        val isContain: String = wktPolygon.contains(GeometryUtil.createPointByWKT("POINT (" + x + " " + y + ")")).toString
        var isContain1 = isContain
        var isContain2 = isContain
        if ("false".equals(isContain)) {
          val distance = GeometryUtil.getDistance(GeometryUtil.createPointByWKT("POINT (" + x + " " + y + ")"), wktPolygon)
          if (distance <= 10) {
            isContain1 = "true"
          }
          if (distance <= 20) {
            isContain2 = "true"
          }
        }
        (bld,x,y,wktStr,isContain,isContain1,isContain2)
      }else{
        (bld,x,y,"","散点数少于3","","")
      }
    })

    val rDf = rdd2.toDF(colNames = "bld","x","y","ploygon","is_contain_0","is_contain_10","is_contain_20")

    rDf.show()

    rDf.repartition(5).write.mode(SaveMode.Overwrite).saveAsTable(out_table1)
//    rdd2.foreach(println)

    logger.error("spark任务结束")
    spark.stop()
  }
}
