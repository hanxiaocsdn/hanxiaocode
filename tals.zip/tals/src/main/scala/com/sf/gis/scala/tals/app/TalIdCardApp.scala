package com.sf.gis.scala.tals.app

import com.sf.gis.java.base.util.SparkUtil
import org.apache.log4j.Logger
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.HttpConnection
import com.sf.gis.java.tals.util.{EncryptUtils, MD5Util}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{Row, SparkSession}

import java.util


/**
 * Created by 01416344 on 2022/07/15.
 * 通过身份证号获取电话
 * 描述：明文身份证号，参数加密，调用接口，获取加密电话，再解密
 */
object TalIdCardApp {

//  //测试
//  val URL = "http://gis-int.intsit.sfdc.com.cn:1080/unionpay/api/queryCardIds"
//  val AK = "8bb09e5e110845f39a000391668e3e80"
//  val key = "gC7I4vJ2QvfpiWgF"
  // 生产
  val URL = "http://gis-int.int.sfdc.com.cn:1080/unionpay/api/queryCardIds"
  val AK = "e7e0666ab27443f9a88a63b97993195b"
  val key = "26td+o2y6LqNeX77"


  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

//    //测试
//    val parNum = 2  //并行度
//    val sparkConf = new SparkConf().setMaster("local[2]").setAppName(appName)
//    val spark = SparkSession.builder().config(sparkConf).getOrCreate()
//
//    val df = spark.read.format("csv")
//      .option("delimiter", ",")
//      .load("./tals/data/tmp0715idcard.txt")
//      .toDF("n_name","id_card").limit(2)

    //生产
    val parNum = 10  //并行度
    val sparkInfo = SparkUtil.getSpark(appName)
    val spark = sparkInfo.getSession

    val sampleSql =
      s"""
         |select n_name,id_card from dm_gis.tmp_0715_idcard
         |""".stripMargin
    println(sampleSql)
    val df = spark.sql(sampleSql)

    df.show()

    val flatRdd  = df.rdd.repartition(parNum).flatMap( obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("ak", AK)
      val id_card = obj.getAs[String]("id_card")
//      println(id_card)
//      var cardId = "Xy7nH34q+iLPCIx0oilHnuJL6aB4QzqbsW/mjzp9Zxs="
      var cardId = ""
      if (null!=id_card && id_card.length>0) {
        cardId = EncryptUtils.encrypt(1, key, id_card)
      }
      jsonObj.put("cardId", cardId)

      // 调身份证号获取电话接口
      val res = HttpConnection.httpPost(3, URL, jsonObj.toJSONString)
//      println(res)
      val resJson : JSONObject =  JSON.parseObject(res)
      var tupleRes = Tuple2[String, String]("","")
      val tmpList = new util.ArrayList[Tuple2[String, String]]()
      val status = resJson.get("status").toString
      if ("0".equals(status)) {
        val result = resJson.get("result").toString
        if (!result.isEmpty) {
          val nObject = JSON.parseObject(result)
          if (!nObject.isEmpty) {
            val phoneListStr = nObject.get("phoneList").toString
            val lst = phoneListStr.split("\",\"")
            for (item <- lst) {
              val tmpStr = item.replace("[\"", "").replace("\"]", "")
              var tphone = ""
              if (null != tmpStr && !"[]".equals(tmpStr)) {
                tphone = EncryptUtils.decrypt(1, key, tmpStr)
              }
              tupleRes = Tuple2[String, String](id_card, tphone)
              tmpList.add(tupleRes)
            }
          }else{
            tupleRes = Tuple2[String, String](id_card, "")
            tmpList.add(tupleRes)
          }
        }
      }
      val phoneList  =  tmpList.toArray
      phoneList
    })


    import spark.implicits._
    val rDf = flatRdd.map(x => {
            val tuplStr  = x.toString
            val strings = tuplStr.split(",").toList
            val tmpList2 = new util.ArrayList[String]()
            for (tmpsp <- strings){
              tmpList2.add(tmpsp.replace("(","").replace(")",""))
            }
      Tuple3[String, String, String](tmpList2.get(0),tmpList2.get(1),if (!tmpList2.get(1).isEmpty) MD5Util.md5(tmpList2.get(1)).toLowerCase else "")
    }).repartition(1).toDF("id_card","phone","phone_md5")

    rDf.show()

    rDf.repartition(1).write.mode("append").format("Hive").saveAsTable("dm_gis.tmp_0715_idcard_res_md5")

    spark.stop()

    logger.error("任务结束。")
  }
}
