package com.sf.gis.scala.tals.app

import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.java.base.util.GeometryUtil.createPoint
import com.vividsolutions.jts.geom.{Point, Polygon}
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}

import java.util

/**
 * create by 01416344(张小琼) on 2022/11/08
 * 描述：输入小区数据有楼栋但没有经纬坐标，推荐坐标
 */
object Tmp1108TuBaoApp {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    // 测试
//    val sparkConf = new SparkConf().setMaster("local[3]").setAppName(appName)
//      .set("spark.executor.cores","1")
//      .set("spark.executor.instances","1")
//      .set("spark.driver.cores","1")
//    val spark = SparkSession.builder().config(sparkConf).getOrCreate()
//
//    val intDf = spark.read.format("csv")
//      .option("delimiter", "\001")
//      .option("header","true")
//      .load("./tals/data/tmp_1108_step5_coord.csv")
//      .toDF()

    // 生产
    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql = args.apply(0)
    val out_table1 = args.apply(1)

    val intDf = spark.sql(int_sql)
    intDf.show()

    val partition_1 = 100
    val partition_2 = 5

    import spark.implicits._
    val rdd1:RDD[(String,String)] = intDf.repartition(partition_1).rdd.map(o => {

      val aoi_guid = if (null!=o.getString(0)) o.getString(0) else ""
      val aoi_name = if (null!=o.getString(1)) o.getString(1) else ""
      val name_chn = if (null!=o.getString(2)) o.getString(2) else ""
      val x_coord = if (null!=o.getString(3)) o.getString(3) else ""
      val y_coord = if (null!=o.getString(4)) o.getString(4) else ""
      val x = if (null!=o.getString(5)) o.getString(5) else ""
      val y = if (null!=o.getString(6)) o.getString(6) else ""
      val k = aoi_guid + "_" + aoi_name + "_" + name_chn + "_" + x_coord + "_" + y_coord
      val v = x + "_" + y
      (k, v)
    })

    val rdd2 = rdd1.groupByKey().map(gpd => {
      val k = gpd._1
      import collection.JavaConverters._
      val k1 = new util.ArrayList(k.split("_",-1).toList.asJava)
      val aoi_guid = k1.get(0)
      val aoi_name = k1.get(1)
      val name_chn = k1.get(2)
      val x_coord = k1.get(3)
      val y_coord = k1.get(4)
      val v = gpd._2.toList
      if (v.size>=3) {
        val points = new util.ArrayList[Point]
        v.foreach( w => {
          val vv : util.ArrayList[String] = new java.util.ArrayList(w.split("_",-1).toList.asJava)
          points.add(createPoint(vv.get(0), vv.get(1)))
        } )
        // 散点计算凸包
        val tubaoPoints: util.List[Point] = GeometryUtil.convexHull(points)
        val wktStr: String = GeometryUtil.getPolygonStrByPoints(tubaoPoints)
        val wktPolygon: Polygon = GeometryUtil.createPolygonByWKT(wktStr)
        // 多边行找中心点
        val centroid: Point = wktPolygon.getCentroid
        val pred_x = centroid.getX.toString
        val pred_y = centroid.getY.toString

        (aoi_guid,aoi_name,name_chn,x_coord,y_coord,wktStr,pred_x,pred_y)
      }else{
        (aoi_guid,aoi_name,name_chn,x_coord,y_coord,"散点数少于3","","")
      }
    })


    val rDf = rdd2.toDF(colNames = "aoi_guid","aoi_name","name_chn","x_coord","y_coord","wkt_str","pred_x","pred_y")
    rDf.show()

    rDf.repartition(partition_2).write.mode(SaveMode.Overwrite).saveAsTable(out_table1)


    logger.error("spark任务结束")
    spark.stop()
  }
}
