package com.sf.gis.scala.tals.app

import com.sf.gis.java.base.util.SparkUtil
import org.apache.commons.codec.digest.DigestUtils
import org.apache.log4j.Logger


/**
 * Created by 01416344 on 2022/05/10.
 * ZLZP地址匹配样本电话md5加密
 * 描述：对原明文电话（dm_gis.zlzp_addr_sample_tmp中phone字段）进行md5加密，输出到dm_gis.zlzp_phone_md5
 */
object ZlzpSampleMatchApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    val sparkInfo = SparkUtil.getSpark(appName)
    val spark = sparkInfo.getSession

    val sampleSql =
      s"""
         |select phone from dm_gis.zlzp_addr_sample_tmp where length(phone)>1  group by phone
         |""".stripMargin
    println(sampleSql)
    val sampleDf = spark.sql(sampleSql)
    sampleDf.show(10)


    val resRdd = sampleDf.rdd.map(o => {
      val phone = o.getAs[String]("phone")

      var tupleRes = Tuple2[String, String]("","")
      val phoneMd5 = DigestUtils.md5Hex(phone)
      tupleRes = Tuple2[String, String](phone, phoneMd5)

      tupleRes

    })

    import spark.implicits._
    val rDf = resRdd.repartition(1).toDF("phone","phone_md5")

    rDf.repartition(1).write.mode("append").format("Hive").saveAsTable("dm_gis.zlzp_phone_md5")

    spark.stop()

    logger.error("任务结束。")
  }
}
