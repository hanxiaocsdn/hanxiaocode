package com.sf.gis.scala.tals.app

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}


/**
 * Created by 01416344 on 2022/12/02.
 * 金融风控评分接口数据
 * 描述：计算寄件特征中间数据
 *
 */
object FinancialRiskControlDayApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql = args.apply(0)
    val out_table1 = args.apply(1)
    val out_table2 = args.apply(2)
    val out_table3 = args.apply(3)
    val out_table4 = args.apply(4)
    val inc_day = args.apply(5)


    val sampDf = spark.sql(int_sql)
    sampDf.show(10)
    sampDf.createGlobalTempView("frc_waybill")

    /**
     * 自定义函数：isCompany
     */
    spark.udf.register("isCompany", (w1:String,w2:String ) => {
      var res = false
      val paternStr = "公司|集团|科技|有限|无限|责任"
      if ( (w1!=null && w1.nonEmpty && paternStr.r.findAllIn(w1).nonEmpty) || (w2!=null && w2.nonEmpty && paternStr.r.findAllIn(w2).nonEmpty) ) res = true
      res
    })
    /**
     * 自定义函数：isTMall
     */
    spark.udf.register("isTMall", (w1:String,w2:String ) => {
      var res = false
      val paternStr = "天猫"
      if ( (w1!=null && w1.nonEmpty && paternStr.r.findAllIn(w1).nonEmpty) || (w2!=null && w2.nonEmpty && paternStr.r.findAllIn(w2).nonEmpty) ) res = true
      res
    })
    /**
     * 自定义函数：isJD
     */
    spark.udf.register("isJD", (w1:String,w2:String ) => {
      var res = false
      val paternStr = "京东"
      if ( (w1!=null && w1.nonEmpty && paternStr.r.findAllIn(w1).nonEmpty) || (w2!=null && w2.nonEmpty && paternStr.r.findAllIn(w2).nonEmpty) ) res = true
      res
    })
    /**
     * 自定义函数：havePos
     */
    spark.udf.register("havePos", (w:String) => {
      var res = false
      val paternStr = "po(.*)机"
      if (w!=null && w.nonEmpty && paternStr.r.findAllIn(w.toLowerCase()).nonEmpty) res = true
      res
    })



    // 寄件中间数据（件量相关）
    val jjDf = spark.sql(
                    """
                      |select
                      |consignor_mobile,
                      |count(1) as consignor_cnt,
                      |sum(case when substr(consigned_tm,12,2)>='06' and substr(consigned_tm,12,2)<'12' then 1 else  0 end) as consignor_tm_zs_cnt,
                      |sum(case when substr(consigned_tm,12,2)>='12' and substr(consigned_tm,12,2)<'18' then 1 else  0 end) as consignor_tm_zw_cnt,
                      |sum(case when (substr(consigned_tm,12,2)>='18' and substr(consigned_tm,12,2)<'24') or (substr(consigned_tm,12,2)>='00' and substr(consigned_tm,12,2)<'06') then 1 else  0 end) as consignor_tm_ws_cnt,
                      |sum(case when month(consigned_tm)=6 and day(consigned_tm)>=1 and day(consigned_tm)<=30 then 1 else 0 end ) as consigned_cnt_618,
                      |sum(case when month(consigned_tm)=11 and day(consigned_tm)>=1 and day(consigned_tm)<=20 then 1 else 0 end) as consigned_cnt_1111,
                      |sum(case when month(consigned_tm)=12 and day(consigned_tm)>=1 and day(consigned_tm)<=20 then 1 else 0 end ) as consigned_cnt_1212,
                      |sum(case when isCompany(consignor_cont_name,consignor_comp_name) then 0 else 1 end ) as consigned_cnt_person,
                      |sum(case when isCompany(consignor_cont_name,consignor_comp_name) then 1 else 0 end ) as consigned_cnt_company,
                      |sum(case when isTMall(consignor_cont_name,consignor_comp_name) then 1 else 0 end ) as consigned_cnt_tmall,
                      |sum(case when isJD(consignor_cont_name,consignor_comp_name) then 1 else 0 end ) as consigned_cnt_jd,
                      |sum(case when havePos(concat_ws(',', cons_name)) then 1 else 0 end ) as consigned_cnt_pos
                      |
                      |from global_temp.frc_waybill
                      |where consignor_mobile<>''
                      |
                      |group by consignor_mobile
                      |
                      |
                      |""".stripMargin)
    jjDf.createGlobalTempView("frc_consignor_cnt")

    logger.error(s"写入hive ${out_table1}中...")
    val jjResDF = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table1} partition(inc_day='${inc_day}')
         |select
         |consignor_mobile,
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as consignor_date,
         |consignor_cnt,consignor_tm_zs_cnt,consignor_tm_zw_cnt,consignor_tm_ws_cnt,
         |consigned_cnt_618,consigned_cnt_1111,consigned_cnt_1212,consigned_cnt_person,consigned_cnt_company,
         |consigned_cnt_tmall,consigned_cnt_jd,consigned_cnt_pos
         |from global_temp.frc_consignor_cnt
         |
         |""".stripMargin)
    jjResDF.repartition(8).show()
    logger.error(s"写入分区${inc_day}成功")


    // 城市(寄件)
    val jjCityDf = spark.sql(
      """
        |select
        |consignor_mobile,src_dist_code,
        |count(1) as citycode_consignor_cnt
        |from global_temp.frc_waybill
        |where consignor_mobile<>'' and src_dist_code<>''
        |group by consignor_mobile,src_dist_code
        |
        |""".stripMargin)
    jjCityDf.createGlobalTempView("frc_consignor_city")

    logger.error(s"写入hive ${out_table2}中...")
    val jjCityResDF = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table2} partition(inc_day='${inc_day}')
         |select
         |consignor_mobile,src_dist_code,citycode_consignor_cnt
         |from global_temp.frc_consignor_city
         |
         |""".stripMargin)
    jjCityResDF.repartition(8).show()
    logger.error(s"写入分区${inc_day}成功")


    // 收件中间数据（件量相关）
    val sjDf = spark.sql(
      """
        |select
        |consignee_mobile,
        |count(1) as consignor_cnt,
        |sum(case when substr(signin_tm,12,2)>='06' and substr(signin_tm,12,2)<'12' then 1 else  0 end) as signin_tm_zs_cnt,
        |sum(case when substr(signin_tm,12,2)>='12' and substr(signin_tm,12,2)<'18' then 1 else  0 end) as signin_tm_zw_cnt,
        |sum(case when (substr(signin_tm,12,2)>='18' and substr(signin_tm,12,2)<'24') or (substr(signin_tm,12,2)>='00' and substr(signin_tm,12,2)<'06') then 1 else  0 end) as signin_tm_ws_cnt,
        |sum(case when month(consigned_tm)=6 and day(consigned_tm)>=1 and day(consigned_tm)<=30 then 1 else 0 end ) as consigned_cnt_618,
        |sum(case when month(consigned_tm)=11 and day(consigned_tm)>=1 and day(consigned_tm)<=20 then 1 else 0 end) as consigned_cnt_1111,
        |sum(case when month(consigned_tm)=12 and day(consigned_tm)>=1 and day(consigned_tm)<=20 then 1 else 0 end ) as consigned_cnt_1212,
        |sum(case when isTMall(consignor_cont_name,consignor_comp_name) then 1 else 0 end ) as consigned_cnt_tmall,
        |sum(case when isJD(consignor_cont_name,consignor_comp_name) then 1 else 0 end ) as consigned_cnt_jd,
        |sum(case when havePos(concat_ws(',', cons_name)) then 1 else 0 end ) as consigned_cnt_pos
        |
        |from global_temp.frc_waybill
        |where consignee_mobile<>''  and  signin_tm<>''
        |
        |group by consignee_mobile
        |
        |
        |""".stripMargin)
    sjDf.createGlobalTempView("frc_consignee_cnt")

    logger.error(s"写入hive ${out_table3}中...")
    val sjResDF = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table3} partition(inc_day='${inc_day}')
         |select
         |consignee_mobile,
         |from_unixtime(unix_timestamp('${inc_day}','yyyyMMdd'),'yyyy-MM-dd') as consignor_date,
         |consignor_cnt,signin_tm_zs_cnt,signin_tm_zw_cnt,signin_tm_ws_cnt,
         |consigned_cnt_618,consigned_cnt_1111,consigned_cnt_1212,
         |consigned_cnt_tmall,consigned_cnt_jd,consigned_cnt_pos
         |
         |from global_temp.frc_consignee_cnt
         |
         |""".stripMargin)
    sjResDF.repartition(8).show()
    logger.error(s"写入分区${inc_day}成功")


    // 城市(收件)
    val sjCityDf = spark.sql(
      """
        |select
        |consignee_mobile,dest_dist_code,count(1) as citycode_consignee_cnt
        |from global_temp.frc_waybill
        |where consignee_mobile<>''  and  signin_tm<>'' and dest_dist_code<>''
        |group by consignee_mobile,dest_dist_code
        |
        |""".stripMargin)
    sjCityDf.createGlobalTempView("frc_consignee_city")

    logger.error(s"写入hive ${out_table4}中...")
    val sjCityResDF = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table4} partition(inc_day='${inc_day}')
         |select
         |consignee_mobile,dest_dist_code,citycode_consignee_cnt
         |from global_temp.frc_consignee_city
         |
         |""".stripMargin)
    sjCityResDF.repartition(8).show()
    logger.error(s"写入分区${inc_day}成功")



    spark.stop()


  }

}
