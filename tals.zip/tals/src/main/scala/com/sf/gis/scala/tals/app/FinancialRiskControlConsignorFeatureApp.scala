package com.sf.gis.scala.tals.app

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * Created by 01416344 on 2022/12/02.
 * 金融风控评分接口数据
 * 描述：计算特征(寄件)
 *
 */
object FinancialRiskControlConsignorFeatureApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql1 = args.apply(0)
    val int_sql2 = args.apply(1)
    val int_sql3 = args.apply(2)
    val out_table1 = args.apply(3)
    val out_table2 = args.apply(4)
    val out_table3 = args.apply(5)
    val inc_day = args.apply(6) //格式 yyyyMMdd
    val apply_date = inc_day.substring(0,4).concat("-").concat(inc_day.substring(4,6)).concat("-").concat(inc_day.substring(6,8)) //格式 yyyy-MM-dd
    val id = args.apply(7)

    logger.error(s"inc_day: ${inc_day}")
    logger.error(s"apply_date: ${apply_date}")

    logger.error(s"int_sql1: ${int_sql1}")
    val sampDf = spark.sql(int_sql1)
    sampDf.show(10)
    sampDf.createGlobalTempView("frc_consignor_day")

    val rDfi = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table1} partition(id='${id}')
         |select
         |consignor_mobile,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-7),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_7d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-30),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_30d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-90),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_90d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-180),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_180d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-365),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_365d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-365),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         |then consignor_cnt else 0 end ) as   consigned_cnt_365d_noSpecial,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-11),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-10),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d12m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-10),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-9),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d11m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-9),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-8),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d10m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-8),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-7),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d9m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-7),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-6),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d8m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-6),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-5),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d7m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-5),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-4),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d6m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-4),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-3),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d5m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-3),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-2),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d4m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-2),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-1),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d3m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-1),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp('${apply_date}','yyyy-MM')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d2m,
         |sum(case when unix_timestamp('${apply_date}','yyyy-MM')=unix_timestamp(consignor_date,'yyyy-MM')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d1m,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_one90d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_two90d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-270),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |  then consignor_cnt else 0 end ) as   consigned_cnt_three90d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-270),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |  then consignor_cnt else 0 end ) as   consigned_cnt_four90d,
         |datediff('${apply_date}', max(consignor_date)) as recent_days,
         |sum(consignor_tm_zs_cnt) as consignor_tm_zs_cnt,
         |sum(consignor_tm_zw_cnt) as consignor_tm_zw_cnt,
         |sum(consignor_tm_ws_cnt) as consignor_tm_ws_cnt,
         |sum(consigned_cnt_618) as consigned_cnt_618,
         |sum(case when substr('${apply_date}',0,4)=substr(consignor_date,0,4) then consigned_cnt_1111 else 0 end ) as consigned_cnt_1111,
         |sum(case when substr('${apply_date}',0,4)=substr(consignor_date,0,4) then consigned_cnt_1212 else 0 end ) as consigned_cnt_1212,
         |sum(consigned_cnt_person) as consigned_cnt_person,
         |sum(consigned_cnt_company) as consigned_cnt_company,
         |sum(consigned_cnt_tmall) as consigned_cnt_tmall,
         |sum(consigned_cnt_jd) as consigned_cnt_jd,
         |sum(consigned_cnt_pos) as consigned_cnt_pos
         |
         |from global_temp.frc_consignor_day
         |
         |group by consignor_mobile
         |
         |
         |""".stripMargin)
    rDfi.repartition(20).show()
    logger.error(s"写入hive表: ${out_table1}")

    val rDf: DataFrame = spark.sql(
      s"""
         |select
         |consignor_mobile,
         |consigned_cnt_7d,
         |consigned_cnt_30d,
         |consigned_cnt_90d,
         |consigned_cnt_180d,
         |consigned_cnt_365d,
         |consigned_cnt_365d_noSpecial,
         |consigned_cnt_d12m,
         |consigned_cnt_d11m,
         |consigned_cnt_d10m,
         |consigned_cnt_d9m,
         |consigned_cnt_d8m,
         |consigned_cnt_d7m,
         |consigned_cnt_d6m,
         |consigned_cnt_d5m,
         |consigned_cnt_d4m,
         |consigned_cnt_d3m,
         |consigned_cnt_d2m,
         |consigned_cnt_d1m,
         |consigned_cnt_one90d,
         |consigned_cnt_two90d,
         |consigned_cnt_three90d,
         |consigned_cnt_four90d,
         |recent_days,
         |consignor_tm_zs_cnt,
         |consignor_tm_zw_cnt,
         |consignor_tm_ws_cnt,
         |consigned_cnt_618,
         |consigned_cnt_1111,
         |consigned_cnt_1212,
         |consigned_cnt_person,
         |consigned_cnt_company,
         |consigned_cnt_tmall,
         |consigned_cnt_jd,
         |consigned_cnt_pos
         |
         |from ${out_table1}
         |where id='${id}'
         |
         |""".stripMargin)
    rDf.show(10)
    rDf.createGlobalTempView("frc_consignor_cnt_stat")


    /**
     * 自定义函数： 增值率  calculateGrowth
     */
    spark.udf.register("calculateGrowth", (x1:Int,x2:Int) => {
      var resOup:java.lang.Double = null
      if (null!=x1 && null!=x2 && x2!=0){
        resOup = (x1-x2).toDouble/x2
      }
      resOup
    })

    /**
     * 自定义函数：计算有寄件的月份数  haveConsignor
     */
    spark.udf.register("haveConsignor", (x1:Int,x2:Int,x3:Int,x4:Int,x5:Int,x6:Int,x7:Int,x8:Int,x9:Int,x10:Int,x11:Int,x12:Int) => {
      var resOup = 0
      if(x1>0) resOup = resOup + 1
      if(x2>0) resOup = resOup + 1
      if(x3>0) resOup = resOup + 1
      if(x4>0) resOup = resOup + 1
      if(x5>0) resOup = resOup + 1
      if(x6>0) resOup = resOup + 1
      if(x7>0) resOup = resOup + 1
      if(x8>0) resOup = resOup + 1
      if(x9>0) resOup = resOup + 1
      if(x10>0) resOup = resOup + 1
      if(x11>0) resOup = resOup + 1
      if(x12>0) resOup = resOup + 1
      resOup
    })

    // 增值率  月最大件数  有寄件的月份数
    logger.error(s"增值率  月最大件数  有寄件的月份数")
    val calDf = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table2} partition(id='${id}')
         |select
         |
         |consignor_mobile,
         |calculateGrowth(consigned_cnt_one90d,consigned_cnt_two90d) as d1d2_growth,
         |calculateGrowth(consigned_cnt_two90d,consigned_cnt_three90d) as d2d3_growth,
         |calculateGrowth(consigned_cnt_three90d,consigned_cnt_four90d) as d3d4_growth,
         |greatest(consigned_cnt_d12m,consigned_cnt_d11m,consigned_cnt_d10m,consigned_cnt_d9m,consigned_cnt_d8m,consigned_cnt_d7m,consigned_cnt_d6m,consigned_cnt_d5m,consigned_cnt_d4m,consigned_cnt_d3m,consigned_cnt_d2m,consigned_cnt_d1m) as max_dm,
         |haveConsignor(consigned_cnt_d12m,consigned_cnt_d11m,consigned_cnt_d10m,consigned_cnt_d9m,consigned_cnt_d8m,consigned_cnt_d7m,consigned_cnt_d6m,consigned_cnt_d5m,consigned_cnt_d4m,consigned_cnt_d3m,consigned_cnt_d2m,consigned_cnt_d1m) as cnt_dm
         |
         |from global_temp.frc_consignor_cnt_stat
         |
         |""".stripMargin)
    calDf.repartition(20).show()
    logger.error(s"写入hive表: ${out_table2}")

    // 城市个数  城市等级
    logger.error(s"城市个数  城市等级")
    logger.error(s"int_sql2: ${int_sql2}")
    val cityDf = spark.sql(int_sql2)
    cityDf.show(10)
    cityDf.createGlobalTempView("frc_consignor_city_stat")
    logger.error(s"int_sql3: ${int_sql3}")
    val cityLevelDf = spark.sql(int_sql3)
    cityLevelDf.show(10)
    cityLevelDf.createGlobalTempView("frc_consignor_city_level")
    val city01DF = spark.sql(
      s"""
         |
         |select
         |consignor_mobile,src_dist_code,sum(citycode_consignor_cnt) as citycode_consignor_cnt
         |from global_temp.frc_consignor_city_stat
         |group by consignor_mobile,src_dist_code
         |
         |""".stripMargin)
    city01DF.createGlobalTempView("frc_consignor_city_stat_01")
    val city02DF = spark.sql(
      s"""
         |
         |select
         |consignor_mobile,count(1) as city_cnt
         |from global_temp.frc_consignor_city_stat_01
         |group by consignor_mobile
         |
         |""".stripMargin)
    city02DF.createGlobalTempView("frc_consignor_city_stat_02")
    val city03DF = spark.sql(
      s"""
         |
         |select
         |t0.consignor_mobile,t0.src_dist_code,
         |t1.city_level
         |from (
         |select
         |consignor_mobile,src_dist_code
         |from ( select
         |consignor_mobile,src_dist_code,row_number() over(partition by consignor_mobile order by citycode_consignor_cnt desc) as rn
         |from global_temp.frc_consignor_city_stat_01 ) as t
         |where t.rn=1
         |) as t0
         |left join global_temp.frc_consignor_city_level as t1
         |on t0.src_dist_code=t1.citycode
         |
         |""".stripMargin)
    city03DF.createGlobalTempView("frc_consignor_city_stat_03")
    val city04DF = spark.sql(
      s"""
         |
         |insert overwrite table ${out_table3} partition(id='${id}')
         |select
         |t0.consignor_mobile,t0.city_cnt,
         |t1.city_level
         |from global_temp.frc_consignor_city_stat_02 as t0
         |left join global_temp.frc_consignor_city_stat_03 as t1
         |on t0.consignor_mobile=t1.consignor_mobile
         |
         |""".stripMargin)
    city04DF.repartition(20).show()
    logger.error(s"写入hive表: ${out_table3}")


    logger.error("任务结束")
    spark.stop()


  }

}
