package com.sf.gis.scala.tals.app

import com.github.davidmoten.geo.GeoHash
import com.sf.gis.java.base.util.GeometryUtil
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}

import scala.collection.JavaConverters.asScalaBufferConverter

/**
 * create by 01416344(张小琼) on 2022/10/26
 * 小区楼栋数据验证跑切片key
 * 描述：楼栋经纬坐标，事件经纬坐标跑key
 */
object Tmp1102RunKeyApp {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql = args.apply(0)
    val out_table1 = args.apply(1)

    /**
     * 自定义函数：runKey
     */
    spark.udf.register("runKey", (x:String,y:String,param:Int) => {
      var res = ""
      if (null!=x && x.length>1 && null!=y && y.length>1) {
        val key = GeoHash.encodeHash(y.toDouble, x.toDouble, param)
        if (null != key) {
          res = key
        }
      }
      res
    })

    /**
     * 自定义函数：getKeyNBS
     */
    spark.udf.register("getKeyNBS", (x:String,y:String,param:Int) => {
      var res = ""
      if (null!=x && x.length>1 && null!=y && y.length>1) {
        val key = GeoHash.encodeHash(y.toDouble, x.toDouble, param)
        if (null != key) {
          res = GeoHash.neighbours(key).toString
        }
      }
      res
    })

    /**
     * 自定义函数：isContainKey
     */
    spark.udf.register("isContainKey", (x:String,y:String,param:Int,bldKey:String,eventKey:String) => {
      var res = ""
      if (null!=bldKey && !"".equals(bldKey) && null!=eventKey && !"".equals(eventKey) && bldKey.equals(eventKey)){
        res = "key"
      }else {
        if (null!=bldKey && !"".equals(bldKey) && null!=eventKey && !"".equals(eventKey)) {
          if (null != x && x.length > 1 && null != y && y.length > 1) {
            val key = GeoHash.encodeHash(y.toDouble, x.toDouble, param)
            if (null != key) {
              val nbsList = GeoHash.neighbours(key).asScala.toList
              if (null != nbsList) {
                for (nbs <- nbsList) {
                  if ("".equals(res) && null != nbs && nbs.equals(eventKey)) {
                    res = "nbs"
                  }
                }
              }
            }
          }
        }
      }
      res
    })

    /**
     * 自定义函数：getDistance
     */
    spark.udf.register("getDistance", (x:String,y:String,eventlng:String,eventlat:String) => {
      var res = ""
      if (null!=x && x.length>1 && null!=y && y.length>1 && null!=eventlng && eventlng.length>1 && null!=eventlat && eventlat.length>1) {
        val distance = GeometryUtil.getDistance(GeometryUtil.createPointByWKT("POINT (" + x + " " + y + ")"),GeometryUtil.createPointByWKT("POINT (" + eventlng + " " + eventlat + ")")).toString
        if (null != distance) {
          res = distance
        }
      }
      res
    })

    val intDf = spark.sql(int_sql)
    intDf.createGlobalTempView("tmp_tbl")

    val rDf = spark.sql(
      """
        |select
        |aoi_guid,aoi_name,name_chn,x_coord,y_coord,waybill_no,inc_day,action,bld,eventlng,eventlat,
        |getDistance(x_coord,y_coord,eventlng,eventlat) as bld_event_dis,
        |runKey(x_coord,y_coord,8) as bld_key,
        |runKey(eventlng,eventlat,8)  as event_key,
        |getKeyNBS(x_coord,y_coord,8) as bld_key_nbs
        |from
        |global_temp.tmp_tbl
        |""".stripMargin)

    rDf.show()
    rDf.createGlobalTempView("tmp_tbl1")

    val rDf1 = spark.sql(
      """
        |select
        |aoi_guid,aoi_name,name_chn,x_coord,y_coord,bld_key,event_key,count(1) as bld_event_cnt
        |from
        |global_temp.tmp_tbl1
        |where
        | event_key<>''
        |group by
        |aoi_guid,aoi_name,name_chn,x_coord,y_coord,bld_key,event_key
        |""".stripMargin)
    rDf1.show()
    rDf1.createGlobalTempView("tmp_tbl2")

    val rDf2 = spark.sql(
      """
        |select
        |t0.aoi_guid,t0.aoi_name,t0.name_chn,t0.x_coord,t0.y_coord,t0.waybill_no,t0.inc_day,t0.action,t0.bld,t0.eventlng,t0.eventlat,t0.bld_event_dis,t0.bld_key,t0.event_key,t0.bld_key_nbs,
        |t1.bld_event_cnt
        |from
        |(select aoi_guid,aoi_name,name_chn,x_coord,y_coord,waybill_no,inc_day,action,bld,eventlng,eventlat,bld_event_dis,bld_key,event_key,bld_key_nbs
        |from global_temp.tmp_tbl1 ) as t0
        |left join
        |( select aoi_guid,aoi_name,name_chn,x_coord,y_coord,bld_key,event_key,bld_event_cnt
        |from global_temp.tmp_tbl2 ) as t1
        |on t0.aoi_guid=t1.aoi_guid and t0.aoi_name=t1.aoi_name and t0.x_coord=t1.x_coord and t0.y_coord=t1.y_coord and t0.bld_key=t1.bld_key and t0.event_key=t1.event_key
        |""".stripMargin)
    rDf2.show()
    rDf2.createGlobalTempView("tmp_tbl3")

    val rDf3 = spark.sql(
      """
        |select
        |aoi_guid,aoi_name,name_chn,x_coord,y_coord,waybill_no,inc_day,action,bld,eventlng,eventlat,bld_event_dis,bld_key,event_key,bld_key_nbs,
        |bld_event_cnt,
        |isContainKey(x_coord,y_coord,8,bld_key,event_key) as rs_type
        |from global_temp.tmp_tbl3
        |""".stripMargin)
    rDf3.show()

    rDf3.repartition(6).write.mode(SaveMode.Overwrite).saveAsTable(out_table1)

    logger.error("spark任务结束")
    spark.stop()
  }
}
