package com.sf.gis.scala.tals.app

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SaveMode, SparkSession}

/**
 * create by 01416344(张小琼) on 2022/10/18
 * 小区楼栋数据验证跑楼栋提取
 * 描述：从地址分词中提取楼栋
 */
object Tmp1018SplitApp {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql = args.apply(0)
    val out_table1 = args.apply(1)

    spark.udf.register("getBuilding", (w1:String) => {
      var res = ""
      import collection.JavaConverters._
      val levelLst: java.util.ArrayList[String]  = new java.util.ArrayList(w1.split("""\;""").toList.asJava)
      if(null!=levelLst && levelLst.size() > 1 && levelLst.get(1).toInt>=13 ) {
        val w2 = levelLst.get(0)
        val tmpLst: Array[String] = w2.split("""\|""")
        tmpLst.foreach(x => {
          import collection.JavaConverters._
          val xLst = new java.util.ArrayList(x.split("""\^""").toList.asJava)
          if (null != xLst && xLst.size() > 1 && "214".equals(xLst.get(1))) {
            if("".equals(res)){
              res = xLst.get(0)
            }
          }
        })
      }
      res
    })

    val intDf = spark.sql(int_sql)
    intDf.createGlobalTempView("tmp_tbl")

    val rDf = spark.sql(
      """
        |select waybill_no, province, city, citycode, addr,aoi, split, getBuilding(split) as building, action_date, action, inc_day
        |from global_temp.tmp_tbl
        |""".stripMargin)

    rDf.show()
    rDf.repartition(5).write.mode(SaveMode.Overwrite).saveAsTable(out_table1)

    logger.error("spark任务结束")
    spark.stop()
  }
}
