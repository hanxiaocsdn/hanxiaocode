package com.sf.gis.scala.tals.app

import com.sf.gis.java.tals.util.StatUtils
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}


/**
 * Created by 01416344 on 2022/12/02.
 * 金融风控评分接口数据
 * 描述：计算特征(收件)
 *
 */
object FinancialRiskControlConsigneeFeatureApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
    conf.setAppName(appName)
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
    conf.set("spark.sql.adaptive.join.enabled", "true")
    conf.set("spark.sql.autoBroadcastJoinThreshold", "20971520")
    conf.set("spark.sql.hive.convertMetastoreOrc","true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val int_sql1 = args.apply(0)
    val int_sql2 = args.apply(1)
    val out_table1 = args.apply(2)
    val out_table2 = args.apply(3)
    val out_table3 = args.apply(4)
    val inc_day = args.apply(5) //格式 yyyyMMdd
    val apply_date = inc_day.substring(0,4).concat("-").concat(inc_day.substring(4,6)).concat("-").concat(inc_day.substring(6,8)) //格式 yyyy-MM-dd
    val id = args.apply(6)

    logger.error(s"inc_day: ${inc_day}")
    logger.error(s"apply_date: ${apply_date}")

    logger.error(s"int_sql1: ${int_sql1}")
    val sampDf = spark.sql(int_sql1)
    sampDf.show(10)
    sampDf.createGlobalTempView("frc_consignor_day")


    val rDfi = spark.sql(
      s"""
         |insert overwrite table ${out_table1} partition(id='${id}')
         |select
         |consignee_mobile,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-7),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_7d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-30),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_30d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-90),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_90d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-180),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_180d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-365),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd') then consignor_cnt else 0 end ) as   consigned_cnt_365d,
         |sum(case when unix_timestamp(date_add(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM-dd'),'yyyy-MM-dd'),-365),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         |then consignor_cnt else 0 end ) as   consigned_cnt_365d_noSpecial,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-11),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-10),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d12m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-10),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-9),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d11m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-9),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-8),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d10m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-8),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-7),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d9m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-7),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-6),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d8m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-6),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-5),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d7m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-5),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-4),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d6m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-4),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-3),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d5m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-3),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-2),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d4m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-2),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-1),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d3m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-1),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp('${apply_date}','yyyy-MM')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d2m,
         |sum(case when unix_timestamp('${apply_date}','yyyy-MM')=unix_timestamp(consignor_date,'yyyy-MM')
         | then consignor_cnt else 0 end ) as   consigned_cnt_d1m,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-11),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-10),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d12m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-10),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-9),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d11m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-9),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-8),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d10m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-8),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-7),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d9m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-7),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-6),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d8m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-6),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-5),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d7m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-5),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-4),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d6m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-4),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-3),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d5m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-3),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-2),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d4m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-2),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-1),'yyyy-MM-dd')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d3m_ts,
         |sum(case when unix_timestamp(add_months(from_unixtime(unix_timestamp('${apply_date}','yyyy-MM'),'yyyy-MM-dd'),-1),'yyyy-MM-dd')<=unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and unix_timestamp('${apply_date}','yyyy-MM')>unix_timestamp(consignor_date,'yyyy-MM-dd')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d2m_ts,
         |sum(case when unix_timestamp('${apply_date}','yyyy-MM')=unix_timestamp(consignor_date,'yyyy-MM')
         |and not ( ( month(consignor_date)=6 and day(consignor_date)>=1 and day(consignor_date)<=30 ) or (month(consignor_date)=11 and day(consignor_date)>=1 and day(consignor_date)<=20 ) or ( month(consignor_date)=12 and day(consignor_date)>=1 and day(consignor_date)<=20 ) )
         | then consignor_cnt else 0 end ) as   consigned_cnt_d1m_ts,
         |sum(signin_tm_zs_cnt) as signin_tm_zs_cnt,
         |sum(signin_tm_zw_cnt) as signin_tm_zw_cnt,
         |sum(signin_tm_ws_cnt) as signin_tm_ws_cnt,
         |sum(consigned_cnt_618) as consigned_cnt_618,
         |sum(case when substr('${apply_date}',0,4)=substr(consignor_date,0,4) then consigned_cnt_1111 else 0 end ) as consigned_cnt_1111,
         |sum(case when substr('${apply_date}',0,4)=substr(consignor_date,0,4) then consigned_cnt_1212 else 0 end ) as consigned_cnt_1212,
         |sum(consigned_cnt_tmall) as consigned_cnt_tmall,
         |sum(consigned_cnt_jd) as consigned_cnt_jd,
         |sum(consigned_cnt_pos) as consigned_cnt_pos
         |
         |from global_temp.frc_consignor_day
         |
         |group by consignee_mobile
         |
         |
         |""".stripMargin)
    rDfi.repartition(20).show()
    logger.error(s"写入hive表: ${out_table1}")

    val rDf: DataFrame = spark.sql(
      s"""
         |select
         |consignee_mobile,
         |consigned_cnt_7d,
         |consigned_cnt_30d,
         |consigned_cnt_90d,
         |consigned_cnt_180d,
         |consigned_cnt_365d,
         |consigned_cnt_365d_noSpecial,
         |consigned_cnt_d12m,
         |consigned_cnt_d11m,
         |consigned_cnt_d10m,
         |consigned_cnt_d9m,
         |consigned_cnt_d8m,
         |consigned_cnt_d7m,
         |consigned_cnt_d6m,
         |consigned_cnt_d5m,
         |consigned_cnt_d4m,
         |consigned_cnt_d3m,
         |consigned_cnt_d2m,
         |consigned_cnt_d1m,
         |consigned_cnt_d12m_ts,
         |consigned_cnt_d11m_ts,
         |consigned_cnt_d10m_ts,
         |consigned_cnt_d9m_ts,
         |consigned_cnt_d8m_ts,
         |consigned_cnt_d7m_ts,
         |consigned_cnt_d6m_ts,
         |consigned_cnt_d5m_ts,
         |consigned_cnt_d4m_ts,
         |consigned_cnt_d3m_ts,
         |consigned_cnt_d2m_ts,
         |consigned_cnt_d1m_ts,
         |signin_tm_zs_cnt,
         |signin_tm_zw_cnt,
         |signin_tm_ws_cnt,
         |consigned_cnt_618,
         |consigned_cnt_1111,
         |consigned_cnt_1212,
         |consigned_cnt_tmall,
         |consigned_cnt_jd,
         |consigned_cnt_pos
         |
         |from ${out_table1}
         |where id='${id}'
         |
         |""".stripMargin)
    rDf.show(10)
    rDf.createGlobalTempView("frc_consignee_cnt_stat")


    /**
     * 自定义函数：计算稳定性 calculateStab
     */
    spark.udf.register("calculateStab", (x1:Int,x2:Int,x3:Int,x4:Int,x5:Int,x6:Int,x7:Int,x8:Int,x9:Int,x10:Int,x11:Int,x12:Int) => {
      var resOup:java.lang.Double = null
      if (null!=x1 && null!=x2 && null!=x3 && null!=x4 && null!=x5 && null!=x6 && null!=x7 && null!=x8 && null!=x9 && null!=x10 && null!=x11 && null!=x12 ) {
        val inputParam = Array[java.lang.Double](x1.toDouble, x2.toDouble, x3.toDouble, x4.toDouble, x5.toDouble, x6.toDouble, x7.toDouble, x8.toDouble, x9.toDouble, x10.toDouble, x11.toDouble, x12.toDouble)
        val stdevp = StatUtils.STDEVP(inputParam)
        val average = StatUtils.AVERAGE(inputParam)
        if (null != stdevp && null != average && average != 0) {
          resOup = stdevp / average
        }
      }
      resOup
    })

    /**
     * 自定义函数：计算有寄件的月份数  haveConsignor
     */
    spark.udf.register("haveConsignor", (x1:Int,x2:Int,x3:Int,x4:Int,x5:Int,x6:Int,x7:Int,x8:Int,x9:Int,x10:Int,x11:Int,x12:Int) => {
      var resOup = 0
      if(x1>0) resOup = resOup + 1
      if(x2>0) resOup = resOup + 1
      if(x3>0) resOup = resOup + 1
      if(x4>0) resOup = resOup + 1
      if(x5>0) resOup = resOup + 1
      if(x6>0) resOup = resOup + 1
      if(x7>0) resOup = resOup + 1
      if(x8>0) resOup = resOup + 1
      if(x9>0) resOup = resOup + 1
      if(x10>0) resOup = resOup + 1
      if(x11>0) resOup = resOup + 1
      if(x12>0) resOup = resOup + 1
      resOup
    })

    // 近一年稳定性 recent_1y_stab 月最大件数  有寄件的月份数
    logger.error(s"近一年稳定性 月最大件数  有寄件的月份数")
    val calDf = spark.sql(
      s"""
         |insert overwrite table ${out_table2} partition(id='${id}')
         |select
         |
         |consignee_mobile,
         |calculateStab(consigned_cnt_d12m_ts,consigned_cnt_d11m_ts,consigned_cnt_d10m_ts,consigned_cnt_d9m_ts,consigned_cnt_d8m_ts,consigned_cnt_d7m_ts,consigned_cnt_d6m_ts,consigned_cnt_d5m_ts,consigned_cnt_d4m_ts,consigned_cnt_d3m_ts,consigned_cnt_d2m_ts,consigned_cnt_d1m_ts) as recent_1y_stab,
         |greatest(consigned_cnt_d12m,consigned_cnt_d11m,consigned_cnt_d10m,consigned_cnt_d9m,consigned_cnt_d8m,consigned_cnt_d7m,consigned_cnt_d6m,consigned_cnt_d5m,consigned_cnt_d4m,consigned_cnt_d3m,consigned_cnt_d2m,consigned_cnt_d1m) as max_dm,
         |haveConsignor(consigned_cnt_d12m,consigned_cnt_d11m,consigned_cnt_d10m,consigned_cnt_d9m,consigned_cnt_d8m,consigned_cnt_d7m,consigned_cnt_d6m,consigned_cnt_d5m,consigned_cnt_d4m,consigned_cnt_d3m,consigned_cnt_d2m,consigned_cnt_d1m) as cnt_dm
         |
         |from global_temp.frc_consignee_cnt_stat
         |
         |""".stripMargin)
    calDf.repartition(20).show()
    logger.error(s"写入hive表: ${out_table2}")


    // 城市个数
    logger.error(s"城市个数  ")
    logger.error(s"int_sql2: ${int_sql2}")
    val cityDf = spark.sql(int_sql2)
    cityDf.show(10)
    cityDf.createGlobalTempView("frc_consignee_city_stat")
    val city01DF = spark.sql(
      s"""
         |
         |select
         |consignee_mobile,dest_dist_code,sum(citycode_consignee_cnt) as citycode_consignee_cnt
         |from global_temp.frc_consignee_city_stat
         |group by consignee_mobile,dest_dist_code
         |
         |""".stripMargin)
    city01DF.createGlobalTempView("frc_consignee_city_stat_01")
    val city02DF = spark.sql(
      s"""
         |insert overwrite table ${out_table3} partition(id='${id}')
         |select
         |consignee_mobile,count(1) as city_cnt
         |from global_temp.frc_consignee_city_stat_01
         |group by consignee_mobile
         |
         |""".stripMargin)
    city02DF.repartition(20).show()
    logger.error(s"写入hive表: ${out_table3}")

    logger.error(s"任务结束")
    spark.stop()


  }

}
