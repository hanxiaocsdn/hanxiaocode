package com.sf.gis.scala.tals.app

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{HttpConnection, SparkUtil}
import org.apache.hadoop.io.serializer.Serializer
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util
import scala.collection.mutable

/**
 * Created by 01416344 on 2022/12/06.
 * 企业地址数据
 */

object CompanyWriteApp {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
//  //测试
//  val URL = "http://gis-int.intsit.sfdc.com.cn:1080/unionpay/api/addCompany"
//  val AK = "8bb09e5e110845f39a000391668e3e80"
  //生产
  val URL = "http://gis-int.int.sfdc.com.cn:1080/unionpay/api/addCompany"
  val AK = "e7e0666ab27443f9a88a63b97993195b"


  def main(args: Array[String]): Unit = {

    /**
     * json:
       {
        "ak":"8bb09e5e110845f39a000391668e3e80",
        "creditCode":"11130902760338418F11",
        "name":"沧州市新华区南大街街道办事处",
        "regStatusNew":"正常",
        "companyOrgTypeNew":"其他经济组织",
        "regLocation":"河北省沧州市新华区交通大街交东路3号",
        "regNormAddr":"河北省沧州市新华区南大街街道交通大街交东路3号",
        "operateAddress":"[{\"address_append\":\"DE##EwAVTvu5kl0AY4t%2FLA6%2Fda1%2B%2BrdPbjScbfYXoQDQEPPmnAjM034uwpTsEXTZN3bZhir6zgfZv9eOyAGKtLrE%2FNR1HIVPFETY2u01rG8EOn5%2BHo8NsQp7ZKHfAbOpvthrbNSthw%3D%3D\",\"confidence\":5,\"sender_cnt\":0,\"sender_first_date\":null,\"sender_latest_date\":null,\"receiver_cnt\":1,\"receiver_first_date\":\"2020-08-20\",\"receiver_latest_date\":\"2020-08-20\"}]"
        }
     */

    val startCode = args(0)
    val endCode = args(1)
    val parNum = args(2).toInt

    val sparkInfo = SparkUtil.getSpark(appName)
    val spark = sparkInfo.getSession

    val querySql =
      s"""
         |select
         |credit_code,name,reg_status_new,company_org_type_new,reg_location,reg_norm_addr,operate_address
         |from dm_gis.company_operate_address_by_city
         |where city_code>='$startCode' and city_code<'$endCode' and credit_code is not null and length(credit_code)>0
         |""".stripMargin
    println(querySql)

    val sourDf = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK)
    sourDf.printSchema()


//    val sparkConf = new SparkConf().setMaster("local[1]").setAppName(appName)
//    val spark = SparkSession.builder().config(sparkConf).getOrCreate()
//
//    val df = spark.read
//      .option("delimiter", "\001")
//      .option("header", "true")
//      .option("quote", "'")
//      .option("nullValue", "\\N")
//      .option("inferSchema", "true")
//      .csv("./tals/data/companyAddr.txt")
//
//    val sourDf = df.select("credit_code","name","reg_status_new","company_org_type_new",
//      "reg_location","reg_norm_addr","operate_address")


    val colList = sourDf.columns
    val keyMap = new util.HashMap[String, String]
    for(column <- colList){
      keyMap.put(column , underlineToHump(column))
    }

    val sourRddTmp = sourDf.rdd.repartition(parNum)
//    sourRddTmp.collect().foreach(println)
    val sourRdd = sourRddTmp.map( obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("ak", AK)
      for (column <- colList) {
        if (!"operate_address".equals(column)) {
          jsonObj.put(keyMap.get(column), obj.getAs[String](column))
        }else{
          //测试
//          if ("null".equals(obj.getAs[String](column))){
//            jsonObj.put(keyMap.get(column), "")
//          }else{
//            jsonObj.put(keyMap.get(column), obj.getAs[String](column))
//          }
          /**
           * array<struct<
           * address_append:string,confidence:int,
           * sender_cnt:int,sender_first_date:string,sender_latest_date:string,
           * receiver_cnt:int,receiver_first_date:string,receiver_latest_date:string
           * >>
           */
          val operateAddress = obj.getAs[mutable.WrappedArray[Row]](column)
          if(operateAddress!=null && operateAddress.length>0){
            val itemList: util.ArrayList[JSONObject] = new util.ArrayList[JSONObject]()
            operateAddress.foreach(item => {
              val newJson = new JSONObject()
              newJson.put("address_append", item.getAs[String]("address_append"))
              newJson.put("confidence", item.getAs[Int]("confidence"))
              newJson.put("sender_cnt", item.getAs[Int]("sender_cnt"))
              newJson.put("sender_first_date", item.getAs[String]("sender_first_date"))
              newJson.put("sender_latest_date", item.getAs[String]("sender_latest_date"))
              newJson.put("receiver_cnt", item.getAs[Int]("receiver_cnt"))
              newJson.put("receiver_first_date", item.getAs[String]("receiver_first_date"))
              newJson.put("receiver_latest_date", item.getAs[String]("receiver_latest_date"))
              itemList.add(newJson)
            })
            jsonObj.put(keyMap.get(column), JSON.toJSONString(itemList, SerializerFeature.DisableCircularReferenceDetect))
          }else{
            jsonObj.put(keyMap.get(column), "")
          }

        }
      }

//      println(jsonObj.toJSONString)
//      jsonObj.toJSONString
      HttpConnection.httpPost(3, URL, jsonObj.toJSONString)
    })
//    sourRdd.collect().foreach(println)

    logger.error(s"数据量:${sourRdd.count()}")

    spark.stop()


  }


  /**
   * 下滑线字段转驼峰
   * @param str
   * @return
   */
  def underlineToHump(str : String) : String = {
    var spStr : Array[String] = str.split("_")
    //循环这个数组
    var result = ""
    var index = 0
    for(i <- 0 to str.length - 1) {
      if(str.charAt(i) == '_') {
        index = 1 + i
      } else {
        if(i == index && i != 0) {
          result += str.charAt(i).toUpper
        } else {
          result += str.charAt(i)
        }
      }
    }
    result
  }


}
