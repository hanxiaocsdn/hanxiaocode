-- 1、数据准备
-- 1）导入test_sample.csv
drop table if exists dm_gis_oms.tmp_rhjk_sample_1108;
create table dm_gis_oms.tmp_rhjk_sample_1108(
idx string,
phone_md5 string,
apply_time string  comment '格式yyyy-MM-dd'
) 
comment '融慧金科测试三' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
tblproperties('skip.header.line.count'='1');

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/sample_all_1108.csv' OVERWRITE INTO TABLE dm_gis_oms.tmp_rhjk_sample_1108;



-- 2）md5电话关联出加密电话和原始电话
drop table if exists dm_gis_oms.tmp_rhjk_sample_tel_1108;
create table dm_gis_oms.tmp_rhjk_sample_tel_1108 as 
select 
t0.idx,t0.phone_md5,t0.apply_time,
t1.tel,t1.tel_decode,t1.name 
from dm_gis_oms.tmp_rhjk_sample_1108 as t0 
left join dm_gis_oms.ods_tals_tel_base as t1 
on t0.phone_md5=t1.tel_md5
;

drop table if exists dm_gis_oms.tmp_rhjk_sample_tel_new_1108;
create table dm_gis_oms.tmp_rhjk_sample_tel_new_1108 as 
select phone_md5,apply_time,tel,tel_decode,name 
from dm_gis_oms.tmp_rhjk_sample_tel_1108 
where tel is not null 
group by phone_md5,apply_time,tel,tel_decode,name 
;


-- 3） 补dm_gis_oms.ods_sy_order_info_di




-- 4) 建表（取20200101往前推一年到20220101的分区，通过电话关联运单）
drop table if exists dm_gis_oms.tmp_rhjk_order_consignor_di_1108;
create table dm_gis_oms.tmp_rhjk_order_consignor_di_1108(
tel string,
apply_time string,
consignor_mobile string,
consignor_cont_name string,
consignee_mobile string,
consignee_cont_name string,
consigned_tm string,
src_dist_code string,
signin_tm string,
dest_dist_code string,
consignor_comp_name string,
consignee_comp_name string,
waybill_no string,
cons_name array<string> 
)
comment '冰鉴二期运单寄件'
PARTITIONED BY (
inc_day string COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy');



-- 收件运单
drop table if exists dm_gis_oms.tmp_rhjk_order_consignee_di_1108;
create table dm_gis_oms.tmp_rhjk_order_consignee_di_1108(
tel string,
apply_time string,
consignor_mobile string,
consignor_cont_name string,
consignee_mobile string,
consignee_cont_name string,
consigned_tm string,
src_dist_code string,
signin_tm string,
dest_dist_code string,
consignor_comp_name string,
consignee_comp_name string,
waybill_no string,
cons_name array<string> 
)
comment '冰鉴二期运单收件'
PARTITIONED BY (
inc_day string COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 5) 跑寄件、收件运单
sqltest=" 
        insert overwrite table dm_gis_oms.tmp_rhjk_order_consignor_di_1108 partition(inc_day='$firstDay')
select 
t0.tel,t0.apply_time,
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name 
from dm_gis_oms.tmp_rhjk_sample_tel_new_1108 as t0 
left join 
(
select 
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name 
from dm_gis_oms.ods_sy_order_info_di 
where inc_day='$firstDay'
) as t1 
on t0.tel=t1.consignor_mobile 
where 
consigned_tm is not null and consigned_tm<>'' 
and t0.apply_time>=substr(consigned_tm,1,10)
;
"


sqltest=" 
insert overwrite table dm_gis_oms.tmp_rhjk_order_consignee_di_1108 partition(inc_day='$firstDay')
select 
t0.tel,t0.apply_time,
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name 
from dm_gis_oms.tmp_rhjk_sample_tel_new_1108 as t0 
left join 
(
select 
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name 
from dm_gis_oms.ods_sy_order_info_di 
where inc_day='$firstDay'
) as t1 
on t0.tel=t1.consignee_mobile 
where 
signin_tm is not null and signin_tm<>'' 
and t0.apply_time>=substr(signin_tm,1,10)
;
"


---------------------寄件-------------------------
-- spark 跑出三个表   BingjianSampleConsignorApp
int_sql="select * from dm_gis_oms.tmp_rhjk_order_consignor_di_1108"

out_table1="dm_gis_oms.tmp_rhjk_consignor_stat_1108"
out_table2="dm_gis_oms.tmp_rhjk_consignor_city_1108"



---------------------收件-------------------------
-- spark 跑出三个表   BingjianSampleConsigneeApp
int_sql="select * from dm_gis_oms.tmp_rhjk_order_consignee_di_1108"

out_table1="dm_gis_oms.tmp_rhjk_consignee_stat_1108"
out_table2="dm_gis_oms.tmp_rhjk_consignee_city_1108"


---------------------寄件-------------------------
-- 城市个数
drop table if exists dm_gis_oms.tmp_rhjk_consignor_city_cnt_1108;
create table dm_gis_oms.tmp_rhjk_consignor_city_cnt_1108 as 
select 
tel,apply_time,count(1) as city_cnt 
from dm_gis_oms.tmp_rhjk_consignor_city_1108 
group by tel,apply_time
;


-- 城市等级
drop table if exists dm_gis_oms.tmp_rhjk_city_level_2_1108;
create table dm_gis_oms.tmp_rhjk_city_level_2_1108 as 
select 
tel,apply_time,src_dist_code,
t1.city_level 
from (
select 
tel,apply_time,src_dist_code
from ( select 
tel,apply_time,src_dist_code,row_number() over(partition by tel,apply_time order by citycode_consignor_cnt desc) as rn 
from dm_gis_oms.tmp_rhjk_consignor_city_1108 ) as t 
where t.rn=1 
) as t0 
left join (select citycode,min(city_level) as city_level from dm_gis_oms.tmp_bingjian_city_level_1 group by citycode) as t1 
on t0.src_dist_code=t1.citycode 
;



---------------------收件-------------------------

-- 城市个数
drop table if exists dm_gis_oms.tmp_rhjk_consignee_city_cnt_1108;
create table dm_gis_oms.tmp_rhjk_consignee_city_cnt_1108 as 
select 
tel,apply_time,count(1) as city_cnt 
from dm_gis_oms.tmp_rhjk_consignee_city_1108 
group by tel,apply_time
;


----------------left join 得到特征结果-----------------------
drop table if exists dm_gis_oms.tmp_rhjk_res_1108 ;
create table dm_gis_oms.tmp_rhjk_res_1108 as 
select 
t0.idx,t0.phone_md5,t0.apply_time,
t1.consigned_cnt_7d,
t1.consigned_cnt_30d,
t1.consigned_cnt_90d,
t1.consigned_cnt_180d,
t1.consigned_cnt_365d,
t1.consigned_cnt_365d_nospecial,
t1.consigned_cnt_d12m,
t1.consigned_cnt_d11m,
t1.consigned_cnt_d10m,
t1.consigned_cnt_d9m,
t1.consigned_cnt_d8m,
t1.consigned_cnt_d7m,
t1.consigned_cnt_d6m,
t1.consigned_cnt_d5m,
t1.consigned_cnt_d4m,
t1.consigned_cnt_d3m,
t1.consigned_cnt_d2m,
t1.consigned_cnt_d1m,
t1.consigned_cnt_one90d,
t1.consigned_cnt_two90d,
t1.d1d2_growth,
t1.consigned_cnt_three90d,
t1.d2d3_growth,
t1.consigned_cnt_four90d,
t1.d3d4_growth,
t1.recent_days,
t1.consignor_tm_zs_cnt,
t1.consignor_tm_zw_cnt,
t1.consignor_tm_ws_cnt,
t1.consigned_cnt_618,
t1.consigned_cnt_1111,
t1.consigned_cnt_1212,
t1.consigned_cnt_person,
t1.consigned_cnt_company,
t1.consigned_cnt_tmall,
t1.consigned_cnt_jd,
t1.consigned_cnt_pos,
t1.max_dm,
t1.cnt_dm,
t3.city_cnt,
t4.city_level,
t5.consigned_cnt_7d as consignee_cnt_7d,
t5.consigned_cnt_30d as consignee_cnt_30d,
t5.consigned_cnt_90d as consignee_cnt_90d,
t5.consigned_cnt_180d as consignee_cnt_180d,
t5.consigned_cnt_365d as consignee_cnt_365d,
t5.consigned_cnt_365d_nospecial as consignee_cnt_365d_nospecial,
t5.consigned_cnt_d12m as consignee_cnt_d12m,
t5.consigned_cnt_d11m as consignee_cnt_d11m,
t5.consigned_cnt_d10m as consignee_cnt_d10m,
t5.consigned_cnt_d9m as consignee_cnt_d9m,
t5.consigned_cnt_d8m as consignee_cnt_d8m,
t5.consigned_cnt_d7m as consignee_cnt_d7m,
t5.consigned_cnt_d6m as consignee_cnt_d6m,
t5.consigned_cnt_d5m as consignee_cnt_d5m,
t5.consigned_cnt_d4m as consignee_cnt_d4m,
t5.consigned_cnt_d3m as consignee_cnt_d3m,
t5.consigned_cnt_d2m as consignee_cnt_d2m,
t5.consigned_cnt_d1m as consignee_cnt_d1m,
t5.consigned_cnt_d12m_ts as consignee_cnt_d12m_ts,
t5.consigned_cnt_d11m_ts as consignee_cnt_d11m_ts,
t5.consigned_cnt_d10m_ts as consignee_cnt_d10m_ts,
t5.consigned_cnt_d9m_ts as consignee_cnt_d9m_ts,
t5.consigned_cnt_d8m_ts as consignee_cnt_d8m_ts,
t5.consigned_cnt_d7m_ts as consignee_cnt_d7m_ts,
t5.consigned_cnt_d6m_ts as consignee_cnt_d6m_ts,
t5.consigned_cnt_d5m_ts as consignee_cnt_d5m_ts,
t5.consigned_cnt_d4m_ts as consignee_cnt_d4m_ts,
t5.consigned_cnt_d3m_ts as consignee_cnt_d3m_ts,
t5.consigned_cnt_d2m_ts as consignee_cnt_d2m_ts,
t5.consigned_cnt_d1m_ts as consignee_cnt_d1m_ts,
t5.recent_1y_stab,
t5.signin_tm_zs_cnt,
t5.signin_tm_zw_cnt,
t5.signin_tm_ws_cnt,
t5.consigned_cnt_618 as consignee_cnt_618,
t5.consigned_cnt_1111 as consignee_cnt_1111,
t5.consigned_cnt_1212 as consignee_cnt_1212,
t5.consigned_cnt_tmall as consignee_cnt_tmall,
t5.consigned_cnt_jd as consignee_cnt_jd,
t5.consigned_cnt_pos as consignee_cnt_pos,
t5.max_dm as consignee_max_dm,
t5.cnt_dm as consignee_cnt_dm,
t7.city_cnt as consignee_city_cnt
from dm_gis_oms.tmp_rhjk_sample_tel_1108 as t0 
left join  dm_gis_oms.tmp_rhjk_consignor_stat_1108 as t1 
on t0.tel=t1.tel and t0.apply_time=t1.apply_time 
left join dm_gis_oms.tmp_rhjk_consignor_city_cnt_1108 as t3 
on t0.tel=t3.tel and t0.apply_time=t3.apply_time 
left join dm_gis_oms.tmp_rhjk_city_level_2_1108 as t4 
on t0.tel=t4.tel and t0.apply_time=t4.apply_time 
left join dm_gis_oms.tmp_rhjk_consignee_stat_1108 as t5 
on t0.tel=t5.tel and t0.apply_time=t5.apply_time 
left join dm_gis_oms.tmp_rhjk_consignee_city_cnt_1108 as t7 
on t0.tel=t7.tel and t0.apply_time=t7.apply_time 
;


-- 其它样例跑数，暂时修改表名
alter table dm_gis_oms.tmp_rhjk_res_1108 rename to dm_gis_oms.tmp_rhjk_res_1108_bak01;
alter table  dm_gis_oms.tmp_rhjk_order_consignor_di_1108  rename to  dm_gis_oms.tmp_rhjk_order_consignor_di_1108_bak01;
alter table  dm_gis_oms.tmp_rhjk_order_consignee_di_1108  rename to  dm_gis_oms.tmp_rhjk_order_consignee_di_1108_bak01;


-- 评估存储量

CREATE TABLE dm_gis_oms.tmp_rhjk_res_1108_parquat(                                                                                                                                                                  
   `idx` string,                                                                                                                                                                                                     
   `phone_md5` string,                                                                                                                                                                                               
   `apply_time` string,                                                                                                                                                                                              
   `consigned_cnt_7d` bigint,                                                                                                                                                                                        
   `consigned_cnt_30d` bigint,                                                                                                                                                                                       
   `consigned_cnt_90d` bigint,                                                                                                                                                                                       
   `consigned_cnt_180d` bigint,                                                                                                                                                                                      
   `consigned_cnt_365d` bigint,                                                                                                                                                                                      
   `consigned_cnt_365d_nospecial` bigint,                                                                                                                                                                            
   `consigned_cnt_d12m` bigint,                                                                                                                                                                                      
   `consigned_cnt_d11m` bigint,                                                                                                                                                                                      
   `consigned_cnt_d10m` bigint,                                                                                                                                                                                      
   `consigned_cnt_d9m` bigint,                                                                                                                                                                                       
   `consigned_cnt_d8m` bigint,                                                                                                                                                                                       
   `consigned_cnt_d7m` bigint,                                                                                                                                                                                       
   `consigned_cnt_d6m` bigint,                                                                                                                                                                                       
   `consigned_cnt_d5m` bigint,                                                                                                                                                                                       
   `consigned_cnt_d4m` bigint,                                                                                                                                                                                       
   `consigned_cnt_d3m` bigint,                                                                                                                                                                                       
   `consigned_cnt_d2m` bigint,                                                                                                                                                                                       
   `consigned_cnt_d1m` bigint,                                                                                                                                                                                       
   `consigned_cnt_one90d` bigint,                                                                                                                                                                                    
   `consigned_cnt_two90d` bigint,                                                                                                                                                                                    
   `d1d2_growth` double,                                                                                                                                                                                             
   `consigned_cnt_three90d` bigint,                                                                                                                                                                                  
   `d2d3_growth` double,                                                                                                                                                                                             
   `consigned_cnt_four90d` bigint,                                                                                                                                                                                   
   `d3d4_growth` double,                                                                                                                                                                                             
   `recent_days` int,                                                                                                                                                                                                
   `consignor_tm_zs_cnt` bigint,                                                                                                                                                                                     
   `consignor_tm_zw_cnt` bigint,                                                                                                                                                                                     
   `consignor_tm_ws_cnt` bigint,                                                                                                                                                                                     
   `consigned_cnt_618` bigint,                                                                                                                                                                                       
   `consigned_cnt_1111` bigint,                                                                                                                                                                                      
   `consigned_cnt_1212` bigint,                                                                                                                                                                                      
   `consigned_cnt_person` bigint,                                                                                                                                                                                    
   `consigned_cnt_company` bigint,                                                                                                                                                                                   
   `consigned_cnt_tmall` bigint,                                                                                                                                                                                     
   `consigned_cnt_jd` bigint,                                                                                                                                                                                        
   `consigned_cnt_pos` bigint,                                                                                                                                                                                       
   `max_dm` bigint,                                                                                                                                                                                                  
   `cnt_dm` int,                                                                                                                                                                                                     
   `city_cnt` bigint,                                                                                                                                                                                                
   `city_level` string,                                                                                                                                                                                              
   `consignee_cnt_7d` bigint,                                                                                                                                                                                        
   `consignee_cnt_30d` bigint,                                                                                                                                                                                       
   `consignee_cnt_90d` bigint,                                                                                                                                                                                       
   `consignee_cnt_180d` bigint,                                                                                                                                                                                      
   `consignee_cnt_365d` bigint,                                                                                                                                                                                      
   `consignee_cnt_365d_nospecial` bigint,                                                                                                                                                                            
   `consignee_cnt_d12m` bigint,                                                                                                                                                                                      
   `consignee_cnt_d11m` bigint,                                                                                                                                                                                      
   `consignee_cnt_d10m` bigint,                                                                                                                                                                                      
   `consignee_cnt_d9m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d8m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d7m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d6m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d5m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d4m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d3m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d2m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d1m` bigint,                                                                                                                                                                                       
   `consignee_cnt_d12m_ts` bigint,                                                                                                                                                                                   
   `consignee_cnt_d11m_ts` bigint,                                                                                                                                                                                   
   `consignee_cnt_d10m_ts` bigint,                                                                                                                                                                                   
   `consignee_cnt_d9m_ts` bigint,                                                                                                                                                                                    
   `consignee_cnt_d8m_ts` bigint,                                                                                                                                                                                    
   `consignee_cnt_d7m_ts` bigint,                                                                                                                                                                                    
   `consignee_cnt_d6m_ts` bigint,                                                                                                                                                                                    
   `consignee_cnt_d5m_ts` bigint,                                                                                                                                                                                    
   `consignee_cnt_d4m_ts` bigint,                                                                                                                                                                                    
   `consignee_cnt_d3m_ts` bigint,                                                                                                                                                                                    
   `consignee_cnt_d2m_ts` bigint,                                                                                                                                                                                    
   `consignee_cnt_d1m_ts` bigint,                                                                                                                                                                                    
   `recent_1y_stab` double,                                                                                                                                                                                          
   `signin_tm_zs_cnt` bigint,                                                                                                                                                                                        
   `signin_tm_zw_cnt` bigint,                                                                                                                                                                                        
   `signin_tm_ws_cnt` bigint,                                                                                                                                                                                        
   `consignee_cnt_618` bigint,                                                                                                                                                                                       
   `consignee_cnt_1111` bigint,                                                                                                                                                                                      
   `consignee_cnt_1212` bigint,                                                                                                                                                                                      
   `consignee_cnt_tmall` bigint,                                                                                                                                                                                     
   `consignee_cnt_jd` bigint,                                                                                                                                                                                        
   `consignee_cnt_pos` bigint,                                                                                                                                                                                       
   `consignee_max_dm` bigint,                                                                                                                                                                                        
   `consignee_cnt_dm` int,                                                                                                                                                                                           
   `consignee_city_cnt` bigint)   
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

insert overwrite table  dm_gis_oms.tmp_rhjk_res_1108_parquat 
select * from dm_gis_oms.tmp_rhjk_res_1108_bak01;



-- 近一年收件手机量
select count(1) from (select consignee_mobile from dm_gis_oms.dwm_sy_consignee_consignor_mi where inc_day>=202109 group by consignee_mobile) as a;
-- 840933474

set tez.queue.name=gis;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;
select count(1) as cnt 
from (
select mobile 
from (
select consignor_mobile as mobile from dm_gis_oms.dwm_sy_consignee_consignor_mi where inc_day>=202109 group by consignor_mobile
union all 
select consignee_mobile as mobile from dm_gis_oms.dwm_sy_consignee_consignor_mi where inc_day>=202109 group by consignee_mobile
) as a 
group by mobile
) as b
;
-- 890332632