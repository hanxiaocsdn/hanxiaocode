-- 
-- 寄件运单： dm_gis_oms.tmp_bryc_order_consignor_all_1217 
-- 收件运单： dm_gis_oms.tmp_bryc_order_consignee_all_1217 
-- `tel` string,
-- `apply_date` string,
-- `consignor_mobile` string,
-- `consignor_cont_name` string,
-- `consignee_mobile` string,
-- `consignee_cont_name` string,
-- `consigned_tm` string,
-- `src_dist_code` string,
-- `signin_tm` string,
-- `dest_dist_code` string,
-- `consignor_comp_name` string,
-- `consignee_comp_name` string,
-- `waybill_no` string,
-- `cons_name` array<string>,
-- `freight_payment_type_code` string,
-- `freight_settlement_type_code` string,
-- `all_fee_rmb` string,
-- `service_prod_code` string,
-- `has_service_prod_flag` string,
-- `customs_batchs` string,
-- `consignor_addr` string,
-- `consignee_addr` string,

---- 关联手机号
-- 
-- 近12月\6月\3月\1月\15天	汇总  寄件 个数	求和
-- 
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_total_res;
create table dm_gis_oms.tmp_bryc_jj_glsj_total_res as 
select 
tel,apply_date,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_mobile else null end )  as jj_consignee_mobile_cnt_360d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_mobile else null end )  as jj_consignee_mobile_cnt_180d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_mobile else null end )  as jj_consignee_mobile_cnt_90d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-30),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_mobile else null end )  as jj_consignee_mobile_cnt_30d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-15),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_mobile else null end )  as jj_consignee_mobile_cnt_15d 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
group by tel,apply_date 
;

-- 近12月\6月\3月\1月\15天	汇总  收件 个数	求和
-- 
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_total_res;
create table dm_gis_oms.tmp_bryc_sj_glsj_total_res as 
select 
tel,apply_date,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_mobile else null end )  as sj_consignor_mobile_cnt_360d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_mobile else null end )  as sj_consignor_mobile_cnt_180d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_mobile else null end )  as sj_consignor_mobile_cnt_90d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-30),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_mobile else null end )  as sj_consignor_mobile_cnt_30d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-15),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_mobile else null end )  as sj_consignor_mobile_cnt_15d 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
group by tel,apply_date 
;


-- 近12月\6月	寄件快递第一大地址	寄件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_jj_addr_top1_360d;
create table dm_gis_oms.tmp_bryc_jj_addr_top1_360d as 
select 
tel,apply_date,consignor_addr 
from (
select 
tel,apply_date,consignor_addr,
row_number() over(partition by tel,apply_date order by jj_cnt desc) as rn 
from (
select 
tel,apply_date,consignor_addr,count(1) as jj_cnt 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,consignor_addr 
) as t 
) as t0 where t0.rn=1
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_360d as 
select 
tel,apply_date,consignor_addr,
count(distinct consignee_mobile) as jj_top1addr_consignee_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,t0.consignee_mobile 
from 
(
select 
tel,apply_date,consignor_addr,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_top1_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignor_addr 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_jj_addr_top1_180d;
create table dm_gis_oms.tmp_bryc_jj_addr_top1_180d as 
select 
tel,apply_date,consignor_addr 
from (
select 
tel,apply_date,consignor_addr,
row_number() over(partition by tel,apply_date order by jj_cnt desc) as rn 
from (
select 
tel,apply_date,consignor_addr,count(1) as jj_cnt 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,consignor_addr 
) as t 
) as t0 where t0.rn=1
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_180d as 
select 
tel,apply_date,consignor_addr,
count(distinct consignee_mobile) as jj_top1addr_consignee_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,t0.consignee_mobile 
from 
(
select 
tel,apply_date,consignor_addr,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_top1_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignor_addr 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_res 
select t0.tel,t0.apply_date,jj_top1addr_consignee_mobile_cnt_360d,jj_top1addr_consignee_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;


-- 近12月\6月	收件快递第一大地址	收件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_sj_addr_top1_360d;
create table dm_gis_oms.tmp_bryc_sj_addr_top1_360d as 
select 
tel,apply_date,consignee_addr 
from (
select 
tel,apply_date,consignee_addr,
row_number() over(partition by tel,apply_date order by sj_cnt desc) as rn 
from (
select 
tel,apply_date,consignee_addr,count(1) as sj_cnt 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,consignee_addr 
) as t 
) as t0 where t0.rn=1
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_360d as 
select 
tel,apply_date,consignee_addr,
count(distinct consignor_mobile) as sj_top1addr_consignor_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,t0.consignor_mobile 
from 
(
select 
tel,apply_date,consignee_addr,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_top1_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignee_addr 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_sj_addr_top1_180d;
create table dm_gis_oms.tmp_bryc_sj_addr_top1_180d as 
select 
tel,apply_date,consignee_addr 
from (
select 
tel,apply_date,consignee_addr,
row_number() over(partition by tel,apply_date order by sj_cnt desc) as rn 
from (
select 
tel,apply_date,consignee_addr,count(1) as sj_cnt 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,consignee_addr 
) as t 
) as t0 where t0.rn=1
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_180d as 
select 
tel,apply_date,consignee_addr,
count(distinct consignor_mobile) as sj_top1addr_consignor_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,t0.consignor_mobile 
from 
(
select 
tel,apply_date,consignee_addr,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_top1_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignee_addr 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_res as 
select t0.tel,t0.apply_date,sj_top1addr_consignor_mobile_cnt_360d,sj_top1addr_consignor_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;


---------
-- 近12月\6月	寄件快递第二大地址	寄件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_jj_addr_top2_360d;
create table dm_gis_oms.tmp_bryc_jj_addr_top2_360d as 
select 
tel,apply_date,consignor_addr 
from (
select 
tel,apply_date,consignor_addr,
row_number() over(partition by tel,apply_date order by jj_cnt desc) as rn 
from (
select 
tel,apply_date,consignor_addr,count(1) as jj_cnt 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,consignor_addr 
) as t 
) as t0 where t0.rn=2
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_360d as 
select 
tel,apply_date,consignor_addr,
count(distinct consignee_mobile) as jj_top2addr_consignee_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,t0.consignee_mobile 
from 
(
select 
tel,apply_date,consignor_addr,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_top2_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignor_addr 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_jj_addr_top2_180d;
create table dm_gis_oms.tmp_bryc_jj_addr_top2_180d as 
select 
tel,apply_date,consignor_addr 
from (
select 
tel,apply_date,consignor_addr,
row_number() over(partition by tel,apply_date order by jj_cnt desc) as rn 
from (
select 
tel,apply_date,consignor_addr,count(1) as jj_cnt 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,consignor_addr 
) as t 
) as t0 where t0.rn=2
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_180d as 
select 
tel,apply_date,consignor_addr,
count(distinct consignee_mobile) as jj_top2addr_consignee_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,t0.consignee_mobile 
from 
(
select 
tel,apply_date,consignor_addr,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_top2_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignor_addr 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_res 
select t0.tel,t0.apply_date,jj_top2addr_consignee_mobile_cnt_360d,jj_top2addr_consignee_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;


-- 近12月\6月	收件快递第二大地址	收件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_sj_addr_top2_360d;
create table dm_gis_oms.tmp_bryc_sj_addr_top2_360d as 
select 
tel,apply_date,consignee_addr 
from (
select 
tel,apply_date,consignee_addr,
row_number() over(partition by tel,apply_date order by sj_cnt desc) as rn 
from (
select 
tel,apply_date,consignee_addr,count(1) as sj_cnt 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,consignee_addr 
) as t 
) as t0 where t0.rn=2
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_360d as 
select 
tel,apply_date,consignee_addr,
count(distinct consignor_mobile) as sj_top2addr_consignor_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,t0.consignor_mobile 
from 
(
select 
tel,apply_date,consignee_addr,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_top2_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignee_addr 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_sj_addr_top2_180d;
create table dm_gis_oms.tmp_bryc_sj_addr_top2_180d as 
select 
tel,apply_date,consignee_addr 
from (
select 
tel,apply_date,consignee_addr,
row_number() over(partition by tel,apply_date order by sj_cnt desc) as rn 
from (
select 
tel,apply_date,consignee_addr,count(1) as sj_cnt 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,consignee_addr 
) as t 
) as t0 where t0.rn=2
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_180d as 
select 
tel,apply_date,consignee_addr,
count(distinct consignor_mobile) as sj_top2addr_consignor_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,t0.consignor_mobile 
from 
(
select 
tel,apply_date,consignee_addr,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_top2_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignee_addr 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_res 
select t0.tel,t0.apply_date,sj_top2addr_consignor_mobile_cnt_360d,sj_top2addr_consignor_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;


--------
-- 近12月\6月	寄件快递第大城市	寄件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_jj_city_top1_360d;
create table dm_gis_oms.tmp_bryc_jj_city_top1_360d as 
select 
tel,apply_date,src_dist_code 
from (
select 
tel,apply_date,src_dist_code,
row_number() over(partition by tel,apply_date order by jj_cnt desc) as rn 
from (
select 
tel,apply_date,src_dist_code,count(1) as jj_cnt 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,src_dist_code 
) as t 
) as t0 where t0.rn=1
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_360d as 
select 
tel,apply_date,src_dist_code,
count(distinct consignee_mobile) as jj_top1city_consignee_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.src_dist_code,t0.consignee_mobile 
from 
(
select 
tel,apply_date,src_dist_code,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_city_top1_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.src_dist_code=t1.src_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date,src_dist_code 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_jj_city_top1_180d;
create table dm_gis_oms.tmp_bryc_jj_city_top1_180d as 
select 
tel,apply_date,src_dist_code 
from (
select 
tel,apply_date,src_dist_code,
row_number() over(partition by tel,apply_date order by jj_cnt desc) as rn 
from (
select 
tel,apply_date,src_dist_code,count(1) as jj_cnt 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,src_dist_code 
) as t 
) as t0 where t0.rn=1
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_180d as 
select 
tel,apply_date,src_dist_code,
count(distinct consignee_mobile) as jj_top1city_consignee_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.src_dist_code,t0.consignee_mobile 
from 
(
select 
tel,apply_date,src_dist_code,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_city_top1_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.src_dist_code=t1.src_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date,src_dist_code 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_res 
select t0.tel,t0.apply_date,jj_top1city_consignee_mobile_cnt_360d,jj_top1city_consignee_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;


-- 近12月\6月	收件快递第大城市	收件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_sj_city_top1_360d;
create table dm_gis_oms.tmp_bryc_sj_city_top1_360d as 
select 
tel,apply_date,dest_dist_code 
from (
select 
tel,apply_date,dest_dist_code,
row_number() over(partition by tel,apply_date order by sj_cnt desc) as rn 
from (
select 
tel,apply_date,dest_dist_code,count(1) as sj_cnt 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,dest_dist_code 
) as t 
) as t0 where t0.rn=1
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_360d as 
select 
tel,apply_date,dest_dist_code,
count(distinct consignor_mobile) as sj_top1city_consignor_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.dest_dist_code,t0.consignor_mobile 
from 
(
select 
tel,apply_date,dest_dist_code,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_city_top1_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.dest_dist_code=t1.dest_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date,dest_dist_code 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_sj_city_top1_180d;
create table dm_gis_oms.tmp_bryc_sj_city_top1_180d as 
select 
tel,apply_date,dest_dist_code 
from (
select 
tel,apply_date,dest_dist_code,
row_number() over(partition by tel,apply_date order by sj_cnt desc) as rn 
from (
select 
tel,apply_date,dest_dist_code,count(1) as sj_cnt 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
group by tel,apply_date,dest_dist_code 
) as t 
) as t0 where t0.rn=1
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_180d as 
select 
tel,apply_date,dest_dist_code,
count(distinct consignor_mobile) as sj_top1city_consignor_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.dest_dist_code,t0.consignor_mobile 
from 
(
select 
tel,apply_date,dest_dist_code,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_city_top1_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.dest_dist_code=t1.dest_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date,dest_dist_code 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_res 
select t0.tel,t0.apply_date,sj_top1city_consignor_mobile_cnt_360d,sj_top1city_consignor_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;


--------
-- 近12月\6月	寄件快递最近一次地址	寄件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_jj_addr_last_360d;
create table dm_gis_oms.tmp_bryc_jj_addr_last_360d as 
select 
tel,apply_date,consignor_addr 
from (
select 
tel,apply_date,consignor_addr,
row_number() over(partition by tel,apply_date order by consigned_tm desc) as rn 
from (
select 
tel,apply_date,consignor_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t 
) as t0 where t0.rn=1
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_360d as 
select 
tel,apply_date,consignor_addr,
count(distinct consignee_mobile) as jj_lastaddr_consignee_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,t0.consignee_mobile 
from 
(
select 
tel,apply_date,consignor_addr,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_last_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignor_addr 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_jj_addr_last_180d;
create table dm_gis_oms.tmp_bryc_jj_addr_last_180d as 
select 
tel,apply_date,consignor_addr 
from (
select 
tel,apply_date,consignor_addr,
row_number() over(partition by tel,apply_date order by consigned_tm desc) as rn 
from (
select 
tel,apply_date,consignor_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 

) as t 
) as t0 where t0.rn=1
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_180d as 
select 
tel,apply_date,consignor_addr,
count(distinct consignee_mobile) as jj_lastaddr_consignee_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,t0.consignee_mobile 
from 
(
select 
tel,apply_date,consignor_addr,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_last_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignor_addr 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_res 
select t0.tel,t0.apply_date,jj_lastaddr_consignee_mobile_cnt_360d,jj_lastaddr_consignee_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;


-- 近12月\6月	收件快递最近一次地址	收件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_sj_addr_last_360d;
create table dm_gis_oms.tmp_bryc_sj_addr_last_360d as 
select 
tel,apply_date,consignee_addr 
from (
select 
tel,apply_date,consignee_addr,
row_number() over(partition by tel,apply_date order by consigned_tm desc) as rn 
from (
select 
tel,apply_date,consignee_addr,consigned_tm 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 

) as t 
) as t0 where t0.rn=1
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_360d as 
select 
tel,apply_date,consignee_addr,
count(distinct consignor_mobile) as sj_lastaddr_consignor_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,t0.consignor_mobile 
from 
(
select 
tel,apply_date,consignee_addr,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_last_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignee_addr 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_sj_addr_last_180d;
create table dm_gis_oms.tmp_bryc_sj_addr_last_180d as 
select 
tel,apply_date,consignee_addr 
from (
select 
tel,apply_date,consignee_addr,
row_number() over(partition by tel,apply_date order by consigned_tm desc) as rn 
from (
select 
tel,apply_date,consignee_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 

) as t 
) as t0 where t0.rn=1
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_180d as 
select 
tel,apply_date,consignee_addr,
count(distinct consignor_mobile) as sj_lastaddr_consignor_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,t0.consignor_mobile 
from 
(
select 
tel,apply_date,consignee_addr,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_last_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date,consignee_addr 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_res as 
select t0.tel,t0.apply_date,sj_lastaddr_consignor_mobile_cnt_360d,sj_lastaddr_consignor_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;



--------
-- 近12月\6月	寄件快递最近一次城市	寄件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_jj_city_last_360d;
create table dm_gis_oms.tmp_bryc_jj_city_last_360d as 
select 
tel,apply_date,src_dist_code 
from (
select 
tel,apply_date,src_dist_code,
row_number() over(partition by tel,apply_date order by consigned_tm desc) as rn 
from (
select 
tel,apply_date,src_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 

) as t 
) as t0 where t0.rn=1
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_360d as 
select 
tel,apply_date,src_dist_code,
count(distinct consignee_mobile) as jj_lastcity_consignee_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.src_dist_code,t0.consignee_mobile 
from 
(
select 
tel,apply_date,src_dist_code,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_city_last_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.src_dist_code=t1.src_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date,src_dist_code 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_jj_city_last_180d;
create table dm_gis_oms.tmp_bryc_jj_city_last_180d as 
select 
tel,apply_date,src_dist_code 
from (
select 
tel,apply_date,src_dist_code,
row_number() over(partition by tel,apply_date order by consigned_tm desc) as rn 
from (
select 
tel,apply_date,src_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 

) as t 
) as t0 where t0.rn=1
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_180d as 
select 
tel,apply_date,src_dist_code,
count(distinct consignee_mobile) as jj_lastcity_consignee_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.src_dist_code,t0.consignee_mobile 
from 
(
select 
tel,apply_date,src_dist_code,consignee_mobile 
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_city_last_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.src_dist_code=t1.src_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date,src_dist_code 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_res 
select t0.tel,t0.apply_date,jj_lastcity_consignee_mobile_cnt_360d,jj_lastcity_consignee_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;


-- 近12月\6月	收件快递最近一次城市	收件 个数	求和 
-- 
--step1
drop table if exists dm_gis_oms.tmp_bryc_sj_city_last_360d;
create table dm_gis_oms.tmp_bryc_sj_city_last_360d as 
select 
tel,apply_date,dest_dist_code 
from (
select 
tel,apply_date,dest_dist_code,
row_number() over(partition by tel,apply_date order by consigned_tm desc) as rn 
from (
select 
tel,apply_date,dest_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 

) as t 
) as t0 where t0.rn=1
;

--step2
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_360d as 
select 
tel,apply_date,dest_dist_code,
count(distinct consignor_mobile) as sj_lastcity_consignor_mobile_cnt_360d
from (
select 
t0.tel,t0.apply_date,t0.dest_dist_code,t0.consignor_mobile 
from 
(
select 
tel,apply_date,dest_dist_code,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_city_last_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.dest_dist_code=t1.dest_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date,dest_dist_code 
;

--step3
drop table if exists dm_gis_oms.tmp_bryc_sj_city_last_180d;
create table dm_gis_oms.tmp_bryc_sj_city_last_180d as 
select 
tel,apply_date,dest_dist_code 
from (
select 
tel,apply_date,dest_dist_code,
row_number() over(partition by tel,apply_date order by consigned_tm  desc) as rn 
from (
select 
tel,apply_date,dest_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 

) as t 
) as t0 where t0.rn=1
;

--step4
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_180d as 
select 
tel,apply_date,dest_dist_code,
count(distinct consignor_mobile) as sj_lastcity_consignor_mobile_cnt_180d
from (
select 
t0.tel,t0.apply_date,t0.dest_dist_code,t0.consignor_mobile 
from 
(
select 
tel,apply_date,dest_dist_code,consignor_mobile 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_city_last_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.dest_dist_code=t1.dest_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date,dest_dist_code 
;

--step5
drop table if exists dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_res;
create table dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_res 
select t0.tel,t0.apply_date,sj_lastcity_consignor_mobile_cnt_360d,sj_lastcity_consignor_mobile_cnt_180d 
from dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_360d as t0 
left join dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_180d as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date
;



---- 关联地址
--
-- 近12月\6月\3月\1月\15天	汇总	寄件	地址个数|城市	求和
--
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_city_total_res;
create table dm_gis_oms.tmp_bryc_jj_gldz_city_total_res as 
select 
tel,apply_date,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_addr else null end )  as jj_consignor_addr_cnt_360d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_addr else null end )  as jj_consignor_addr_cnt_180d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_addr else null end )  as jj_consignor_addr_cnt_90d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-30),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_addr else null end )  as jj_consignor_addr_cnt_30d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-15),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignor_addr else null end )  as jj_consignor_addr_cnt_15d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then src_dist_code else null end )  as jj_consignor_city_cnt_360d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then src_dist_code else null end )  as jj_consignor_city_cnt_180d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then src_dist_code else null end )  as jj_consignor_city_cnt_90d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-30),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then src_dist_code else null end )  as jj_consignor_city_cnt_30d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-15),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then src_dist_code else null end )  as jj_consignor_city_cnt_15d 

from dm_gis_oms.tmp_bryc_order_consignor_all_1217 
group by tel,apply_date 
;

-- 近12月\6月\3月\1月\15天	汇总	收件	地址个数|城市	求和
--
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_city_total_res;
create table dm_gis_oms.tmp_bryc_sj_gldz_city_total_res as 
select 
tel,apply_date,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_addr else null end )  as sj_consignee_addr_cnt_360d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_addr else null end )  as sj_consignee_addr_cnt_180d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_addr else null end )  as sj_consignee_addr_cnt_90d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-30),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_addr else null end )  as sj_consignee_addr_cnt_30d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-15),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then consignee_addr else null end )  as sj_consignee_addr_cnt_15d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then dest_dist_code else null end )  as sj_consignee_city_cnt_360d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then dest_dist_code else null end )  as sj_consignee_city_cnt_180d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-90),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then dest_dist_code else null end )  as sj_consignee_city_cnt_90d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-30),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then dest_dist_code else null end )  as sj_consignee_city_cnt_30d,
count(distinct case when unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-15),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
then dest_dist_code else null end )  as sj_consignee_city_cnt_15d 

from dm_gis_oms.tmp_bryc_order_consignee_all_1217 
group by tel,apply_date 
;

-- 
-- 近12月\6月	快递量第一大地址	寄件	月份数	   求和
-- 近12月\6月	快递量第一大地址	寄件	间隔天数	最大\最小\平均\求和
-- 近12月\6月	快递量第一大地址	寄件	距今天数	求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_top1addr_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_gldz_top1addr_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_top1addr_month_cnt_360d,
max(diffdays) as jj_gldz_top1addr_max_diffdays_360d,
min(diffdays) as jj_gldz_top1addr_min_diffdays_360d,
avg(diffdays) as jj_gldz_top1addr_avg_diffdays_360d,
sum(diffdays) as jj_gldz_top1addr_sum_diffdays_360d, 
min(lastdays) as jj_gldz_top1addr_lastdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignor_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_top1_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 180d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_top1addr_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_gldz_top1addr_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_top1addr_month_cnt_180d,
max(diffdays) as jj_gldz_top1addr_max_diffdays_180d,
min(diffdays) as jj_gldz_top1addr_min_diffdays_180d,
avg(diffdays) as jj_gldz_top1addr_avg_diffdays_180d,
sum(diffdays) as jj_gldz_top1addr_sum_diffdays_180d, 
min(lastdays) as jj_gldz_top1addr_lastdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignor_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_top1_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 
-- 近12月\6月	快递量第一大地址	收件	月份数	   求和
-- 近12月\6月	快递量第一大地址	收件	间隔天数	最大\最小\平均\求和
-- 近12月\6月	快递量第一大地址	收件	距今天数	求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_top1addr_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_gldz_top1addr_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_top1addr_month_cnt_360d,
max(diffdays) as sj_gldz_top1addr_max_diffdays_360d,
min(diffdays) as sj_gldz_top1addr_min_diffdays_360d,
avg(diffdays) as sj_gldz_top1addr_avg_diffdays_360d,
sum(diffdays) as sj_gldz_top1addr_sum_diffdays_360d, 
min(lastdays) as sj_gldz_top1addr_lastdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignee_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_top1_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;
-- 180d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_top1addr_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_gldz_top1addr_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_top1addr_month_cnt_180d,
max(diffdays) as sj_gldz_top1addr_max_diffdays_180d,
min(diffdays) as sj_gldz_top1addr_min_diffdays_180d,
avg(diffdays) as sj_gldz_top1addr_avg_diffdays_180d,
sum(diffdays) as sj_gldz_top1addr_sum_diffdays_180d, 
min(lastdays) as sj_gldz_top1addr_lastdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignee_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_top1_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;


-- 
-- 近12月\6月	快递量第二大地址	寄件	月份数	   求和
-- 近12月\6月	快递量第二大地址	寄件	间隔天数	最大\最小\平均\求和
-- 近12月\6月	快递量第二大地址	寄件	距今天数	求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_top2addr_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_gldz_top2addr_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_top2addr_month_cnt_360d,
max(diffdays) as jj_gldz_top2addr_max_diffdays_360d,
min(diffdays) as jj_gldz_top2addr_min_diffdays_360d,
avg(diffdays) as jj_gldz_top2addr_avg_diffdays_360d,
sum(diffdays) as jj_gldz_top2addr_sum_diffdays_360d, 
min(lastdays) as jj_gldz_top2addr_lastdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignor_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_top2_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 180d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_top2addr_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_gldz_top2addr_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_top2addr_month_cnt_180d,
max(diffdays) as jj_gldz_top2addr_max_diffdays_180d,
min(diffdays) as jj_gldz_top2addr_min_diffdays_180d,
avg(diffdays) as jj_gldz_top2addr_avg_diffdays_180d,
sum(diffdays) as jj_gldz_top2addr_sum_diffdays_180d, 
min(lastdays) as jj_gldz_top2addr_lastdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignor_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_top2_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;


-- 
-- 近12月\6月	快递量第二大地址	收件	月份数	   求和
-- 近12月\6月	快递量第二大地址	收件	间隔天数	最大\最小\平均\求和
-- 近12月\6月	快递量第二大地址	收件	距今天数	求和
--
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_top2addr_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_gldz_top2addr_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_top2addr_month_cnt_360d,
max(diffdays) as sj_gldz_top2addr_max_diffdays_360d,
min(diffdays) as sj_gldz_top2addr_min_diffdays_360d,
avg(diffdays) as sj_gldz_top2addr_avg_diffdays_360d,
sum(diffdays) as sj_gldz_top2addr_sum_diffdays_360d, 
min(lastdays) as sj_gldz_top2addr_lastdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignee_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_top2_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;
-- 180d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_top2addr_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_gldz_top2addr_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_top2addr_month_cnt_180d,
max(diffdays) as sj_gldz_top2addr_max_diffdays_180d,
min(diffdays) as sj_gldz_top2addr_min_diffdays_180d,
avg(diffdays) as sj_gldz_top2addr_avg_diffdays_180d,
sum(diffdays) as sj_gldz_top2addr_sum_diffdays_180d, 
min(lastdays) as sj_gldz_top2addr_lastdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignee_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_top2_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 
-- 近12月\6月	快递量最大城市	寄件	月份数	   求和
-- 近12月\6月	快递量最大城市	寄件	间隔天数	最大\最小\平均\求和
-- 近12月\6月	快递量最大城市	寄件	距今天数	求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_top1city_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_gldz_top1city_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_top1city_month_cnt_360d,
max(diffdays) as jj_gldz_top1city_max_diffdays_360d,
min(diffdays) as jj_gldz_top1city_min_diffdays_360d,
avg(diffdays) as jj_gldz_top1city_avg_diffdays_360d,
sum(diffdays) as jj_gldz_top1city_sum_diffdays_360d, 
min(lastdays) as jj_gldz_top1city_lastdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.src_dist_code,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,src_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_city_top1_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.src_dist_code=t1.src_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 180d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_top1city_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_gldz_top1city_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_top1city_month_cnt_180d,
max(diffdays) as jj_gldz_top1city_max_diffdays_180d,
min(diffdays) as jj_gldz_top1city_min_diffdays_180d,
avg(diffdays) as jj_gldz_top1city_avg_diffdays_180d,
sum(diffdays) as jj_gldz_top1city_sum_diffdays_180d, 
min(lastdays) as jj_gldz_top1city_lastdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.src_dist_code,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,src_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_city_top1_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.src_dist_code=t1.src_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 
-- 近12月\6月	快递量最大城市	收件	月份数	   求和
-- 近12月\6月	快递量最大城市	收件	间隔天数	最大\最小\平均\求和
-- 近12月\6月	快递量最大城市	收件	距今天数	求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_top1city_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_gldz_top1city_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_top1city_month_cnt_360d,
max(diffdays) as sj_gldz_top1city_max_diffdays_360d,
min(diffdays) as sj_gldz_top1city_min_diffdays_360d,
avg(diffdays) as sj_gldz_top1city_avg_diffdays_360d,
sum(diffdays) as sj_gldz_top1city_sum_diffdays_360d, 
min(lastdays) as sj_gldz_top1city_lastdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.dest_dist_code,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,dest_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_city_top1_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.dest_dist_code=t1.dest_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;
-- 180d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_top1city_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_gldz_top1city_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_top1city_month_cnt_180d,
max(diffdays) as sj_gldz_top1city_max_diffdays_180d,
min(diffdays) as sj_gldz_top1city_min_diffdays_180d,
avg(diffdays) as sj_gldz_top1city_avg_diffdays_180d,
sum(diffdays) as sj_gldz_top1city_sum_diffdays_180d, 
min(lastdays) as sj_gldz_top1city_lastdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.dest_dist_code,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,dest_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_city_top1_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.dest_dist_code=t1.dest_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;



-- 
-- 近12月\6月	快递最近地址	寄件	月份数	   求和
-- 近12月\6月	快递最近地址	寄件	间隔天数	最大\最小\平均\求和
-- 近12月\6月	快递最近地址	寄件	距今天数	求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_lastaddr_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_gldz_lastaddr_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_lastaddr_month_cnt_360d,
max(diffdays) as jj_gldz_lastaddr_max_diffdays_360d,
min(diffdays) as jj_gldz_lastaddr_min_diffdays_360d,
avg(diffdays) as jj_gldz_lastaddr_avg_diffdays_360d,
sum(diffdays) as jj_gldz_lastaddr_sum_diffdays_360d, 
min(lastdays) as jj_gldz_lastaddr_lastdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignor_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_last_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 180d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_lastaddr_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_gldz_lastaddr_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_lastaddr_month_cnt_180d,
max(diffdays) as jj_gldz_lastaddr_max_diffdays_180d,
min(diffdays) as jj_gldz_lastaddr_min_diffdays_180d,
avg(diffdays) as jj_gldz_lastaddr_avg_diffdays_180d,
sum(diffdays) as jj_gldz_lastaddr_sum_diffdays_180d, 
min(lastdays) as jj_gldz_lastaddr_lastdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.consignor_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignor_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_addr_last_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignor_addr=t1.consignor_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 
-- 近12月\6月	快递最近地址	收件	月份数	   求和
-- 近12月\6月	快递最近地址	收件	间隔天数	最大\最小\平均\求和
-- 近12月\6月	快递最近地址	收件	距今天数	求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_lastaddr_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_gldz_lastaddr_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_lastaddr_month_cnt_360d,
max(diffdays) as sj_gldz_lastaddr_max_diffdays_360d,
min(diffdays) as sj_gldz_lastaddr_min_diffdays_360d,
avg(diffdays) as sj_gldz_lastaddr_avg_diffdays_360d,
sum(diffdays) as sj_gldz_lastaddr_sum_diffdays_360d, 
min(lastdays) as sj_gldz_lastaddr_lastdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignee_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_last_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;
-- 180d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_lastaddr_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_gldz_lastaddr_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_lastaddr_month_cnt_180d,
max(diffdays) as sj_gldz_lastaddr_max_diffdays_180d,
min(diffdays) as sj_gldz_lastaddr_min_diffdays_180d,
avg(diffdays) as sj_gldz_lastaddr_avg_diffdays_180d,
sum(diffdays) as sj_gldz_lastaddr_sum_diffdays_180d, 
min(lastdays) as sj_gldz_lastaddr_lastdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.consignee_addr,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays,
datediff(t0.apply_date, t0.consigned_tm) lastdays    
from 
(
select 
tel,apply_date,consignee_addr,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_addr_last_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.consignee_addr=t1.consignee_addr 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;


-- 
-- 近12月\6月	快递最近城市	寄件	月份数	   求和
-- 近12月\6月	快递最近城市	寄件	间隔天数	最大\最小\平均\求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_lastcity_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_jj_gldz_lastcity_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_lastcity_month_cnt_360d,
max(diffdays) as jj_gldz_lastcity_max_diffdays_360d,
min(diffdays) as jj_gldz_lastcity_min_diffdays_360d,
avg(diffdays) as jj_gldz_lastcity_avg_diffdays_360d,
sum(diffdays) as jj_gldz_lastcity_sum_diffdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.src_dist_code,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays 
from 
(
select 
tel,apply_date,src_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_city_last_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.src_dist_code=t1.src_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 180d
drop table if exists dm_gis_oms.tmp_bryc_jj_gldz_lastcity_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_jj_gldz_lastcity_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as jj_gldz_lastcity_month_cnt_180d,
max(diffdays) as jj_gldz_lastcity_max_diffdays_180d,
min(diffdays) as jj_gldz_lastcity_min_diffdays_180d,
avg(diffdays) as jj_gldz_lastcity_avg_diffdays_180d,
sum(diffdays) as jj_gldz_lastcity_sum_diffdays_180d 
from (
select 
t0.tel,t0.apply_date,t0.src_dist_code,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays 
from 
(
select 
tel,apply_date,src_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignor_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_jj_city_last_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.src_dist_code=t1.src_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;

-- 
-- 近12月\6月	快递最近城市	收件	月份数	   求和
-- 近12月\6月	快递最近城市	收件	间隔天数	最大\最小\平均\求和
-- 360d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_lastcity_month_cnt_360d;
create table dm_gis_oms.tmp_bryc_sj_gldz_lastcity_month_cnt_360d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_lastcity_month_cnt_360d,
max(diffdays) as sj_gldz_lastcity_max_diffdays_360d,
min(diffdays) as sj_gldz_lastcity_min_diffdays_360d,
avg(diffdays) as sj_gldz_lastcity_avg_diffdays_360d,
sum(diffdays) as sj_gldz_lastcity_sum_diffdays_360d 
from (
select 
t0.tel,t0.apply_date,t0.dest_dist_code,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays 
from 
(
select 
tel,apply_date,dest_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-360),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_city_last_360d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.dest_dist_code=t1.dest_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;
-- 180d
drop table if exists dm_gis_oms.tmp_bryc_sj_gldz_lastcity_month_cnt_180d;
create table dm_gis_oms.tmp_bryc_sj_gldz_lastcity_month_cnt_180d as 
select 
tel,apply_date,
count(distinct m) as sj_gldz_lastcity_month_cnt_180d,
max(diffdays) as sj_gldz_lastcity_max_diffdays_180d,
min(diffdays) as sj_gldz_lastcity_min_diffdays_180d,
avg(diffdays) as sj_gldz_lastcity_avg_diffdays_180d,
sum(diffdays) as sj_gldz_lastcity_sum_diffdays_180d  
from (
select 
t0.tel,t0.apply_date,t0.dest_dist_code,
ceil(datediff(t0.apply_date, t0.consigned_tm) / 30) m,
datediff(t0.consigned_tm, lag(t0.consigned_tm, 1) over(partition by t0.tel,t0.apply_date order by t0.consigned_tm ) ) diffdays 
from 
(
select 
tel,apply_date,dest_dist_code,consigned_tm  
from dm_gis_oms.tmp_bryc_order_consignee_all_1217  
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-180),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss') 
) as t0 
left join dm_gis_oms.tmp_bryc_sj_city_last_180d  as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date and t0.dest_dist_code=t1.dest_dist_code 
where t1.tel is not null 
) as tt 
group by tel,apply_date  
;


-- 
-- 特征汇合 
drop table if exists dm_gis_oms.tmp_bryc_glsj_gldz_res;
create table dm_gis_oms.tmp_bryc_glsj_gldz_res as 
select t0.tel_md5,t0.apply_date,t0.tel,		
jj_consignee_mobile_cnt_360d,		
jj_consignee_mobile_cnt_180d,		
jj_consignee_mobile_cnt_90d,		
jj_consignee_mobile_cnt_30d,		
jj_consignee_mobile_cnt_15d,	
sj_consignor_mobile_cnt_360d,		
sj_consignor_mobile_cnt_180d,		
sj_consignor_mobile_cnt_90d,		
sj_consignor_mobile_cnt_30d,		
sj_consignor_mobile_cnt_15d,
jj_top1addr_consignee_mobile_cnt_360d,		
jj_top1addr_consignee_mobile_cnt_180d, 
sj_top1addr_consignor_mobile_cnt_360d,		
sj_top1addr_consignor_mobile_cnt_180d,
jj_top2addr_consignee_mobile_cnt_360d,		
jj_top2addr_consignee_mobile_cnt_180d,
sj_top2addr_consignor_mobile_cnt_360d,		
sj_top2addr_consignor_mobile_cnt_180d,
jj_top1city_consignee_mobile_cnt_360d,		
jj_top1city_consignee_mobile_cnt_180d,
sj_top1city_consignor_mobile_cnt_360d,		
sj_top1city_consignor_mobile_cnt_180d,
jj_lastaddr_consignee_mobile_cnt_360d,		
jj_lastaddr_consignee_mobile_cnt_180d,
sj_lastaddr_consignor_mobile_cnt_360d,		
sj_lastaddr_consignor_mobile_cnt_180d,
jj_lastcity_consignee_mobile_cnt_360d,		
jj_lastcity_consignee_mobile_cnt_180d,
sj_lastcity_consignor_mobile_cnt_360d,		
sj_lastcity_consignor_mobile_cnt_180d,
jj_consignor_addr_cnt_360d,		
jj_consignor_addr_cnt_180d,		
jj_consignor_addr_cnt_90d,		
jj_consignor_addr_cnt_30d,		
jj_consignor_addr_cnt_15d,		
jj_consignor_city_cnt_360d,		
jj_consignor_city_cnt_180d,		
jj_consignor_city_cnt_90d,		
jj_consignor_city_cnt_30d,		
jj_consignor_city_cnt_15d,
sj_consignee_addr_cnt_360d,		
sj_consignee_addr_cnt_180d,		
sj_consignee_addr_cnt_90d,		
sj_consignee_addr_cnt_30d,		
sj_consignee_addr_cnt_15d,		
sj_consignee_city_cnt_360d,		
sj_consignee_city_cnt_180d,		
sj_consignee_city_cnt_90d,		
sj_consignee_city_cnt_30d,		
sj_consignee_city_cnt_15d,
jj_gldz_top1addr_month_cnt_360d,		
jj_gldz_top1addr_max_diffdays_360d,		
jj_gldz_top1addr_min_diffdays_360d,		
jj_gldz_top1addr_avg_diffdays_360d,		
jj_gldz_top1addr_sum_diffdays_360d,		
jj_gldz_top1addr_lastdays_360d, 
jj_gldz_top1addr_month_cnt_180d,		
jj_gldz_top1addr_max_diffdays_180d,		
jj_gldz_top1addr_min_diffdays_180d,		
jj_gldz_top1addr_avg_diffdays_180d,		
jj_gldz_top1addr_sum_diffdays_180d,		
jj_gldz_top1addr_lastdays_180d,
sj_gldz_top1addr_month_cnt_180d,		
sj_gldz_top1addr_max_diffdays_180d,		
sj_gldz_top1addr_min_diffdays_180d,		
sj_gldz_top1addr_avg_diffdays_180d,		
sj_gldz_top1addr_sum_diffdays_180d,		
sj_gldz_top1addr_lastdays_180d,

sj_gldz_top1addr_month_cnt_360d,
sj_gldz_top1addr_max_diffdays_360d,
sj_gldz_top1addr_min_diffdays_360d,
sj_gldz_top1addr_avg_diffdays_360d,
sj_gldz_top1addr_sum_diffdays_360d, 
sj_gldz_top1addr_lastdays_360d, 

jj_gldz_top2addr_month_cnt_360d,		
jj_gldz_top2addr_max_diffdays_360d,		
jj_gldz_top2addr_min_diffdays_360d,		
jj_gldz_top2addr_avg_diffdays_360d,		
jj_gldz_top2addr_sum_diffdays_360d,		
jj_gldz_top2addr_lastdays_360d,
sj_gldz_top2addr_month_cnt_360d,		
sj_gldz_top2addr_max_diffdays_360d,		
sj_gldz_top2addr_min_diffdays_360d,		
sj_gldz_top2addr_avg_diffdays_360d,		
sj_gldz_top2addr_sum_diffdays_360d,		
sj_gldz_top2addr_lastdays_360d,
jj_gldz_top2addr_month_cnt_180d,		
jj_gldz_top2addr_max_diffdays_180d,		
jj_gldz_top2addr_min_diffdays_180d,		
jj_gldz_top2addr_avg_diffdays_180d,		
jj_gldz_top2addr_sum_diffdays_180d,		
jj_gldz_top2addr_lastdays_180d,
sj_gldz_top2addr_month_cnt_180d,		
sj_gldz_top2addr_max_diffdays_180d,		
sj_gldz_top2addr_min_diffdays_180d,		
sj_gldz_top2addr_avg_diffdays_180d,		
sj_gldz_top2addr_sum_diffdays_180d,		
sj_gldz_top2addr_lastdays_180d,
jj_gldz_top1city_month_cnt_360d,		
jj_gldz_top1city_max_diffdays_360d,		
jj_gldz_top1city_min_diffdays_360d,		
jj_gldz_top1city_avg_diffdays_360d,		
jj_gldz_top1city_sum_diffdays_360d,		
jj_gldz_top1city_lastdays_360d,
sj_gldz_top1city_month_cnt_360d,		
sj_gldz_top1city_max_diffdays_360d,		
sj_gldz_top1city_min_diffdays_360d,		
sj_gldz_top1city_avg_diffdays_360d,		
sj_gldz_top1city_sum_diffdays_360d,		
sj_gldz_top1city_lastdays_360d,
jj_gldz_top1city_month_cnt_180d,		
jj_gldz_top1city_max_diffdays_180d,		
jj_gldz_top1city_min_diffdays_180d,		
jj_gldz_top1city_avg_diffdays_180d,		
jj_gldz_top1city_sum_diffdays_180d,		
jj_gldz_top1city_lastdays_180d,
sj_gldz_top1city_month_cnt_180d,		
sj_gldz_top1city_max_diffdays_180d,		
sj_gldz_top1city_min_diffdays_180d,		
sj_gldz_top1city_avg_diffdays_180d,		
sj_gldz_top1city_sum_diffdays_180d,		
sj_gldz_top1city_lastdays_180d,

jj_gldz_lastaddr_month_cnt_360d,
jj_gldz_lastaddr_max_diffdays_360d,
jj_gldz_lastaddr_min_diffdays_360d,
jj_gldz_lastaddr_avg_diffdays_360d,
jj_gldz_lastaddr_sum_diffdays_360d, 
jj_gldz_lastaddr_lastdays_360d,
jj_gldz_lastaddr_month_cnt_180d,
jj_gldz_lastaddr_max_diffdays_180d,
jj_gldz_lastaddr_min_diffdays_180d,
jj_gldz_lastaddr_avg_diffdays_180d,
jj_gldz_lastaddr_sum_diffdays_180d, 
jj_gldz_lastaddr_lastdays_180d,
sj_gldz_lastaddr_month_cnt_360d,
sj_gldz_lastaddr_max_diffdays_360d,
sj_gldz_lastaddr_min_diffdays_360d,
sj_gldz_lastaddr_avg_diffdays_360d,
sj_gldz_lastaddr_sum_diffdays_360d, 
sj_gldz_lastaddr_lastdays_360d,
sj_gldz_lastaddr_month_cnt_180d,
sj_gldz_lastaddr_max_diffdays_180d,
sj_gldz_lastaddr_min_diffdays_180d,
sj_gldz_lastaddr_avg_diffdays_180d,
sj_gldz_lastaddr_sum_diffdays_180d, 
sj_gldz_lastaddr_lastdays_180d,

jj_gldz_lastcity_month_cnt_360d,		
jj_gldz_lastcity_max_diffdays_360d,		
jj_gldz_lastcity_min_diffdays_360d,		
jj_gldz_lastcity_avg_diffdays_360d,		
jj_gldz_lastcity_sum_diffdays_360d,
sj_gldz_lastcity_month_cnt_360d,		
sj_gldz_lastcity_max_diffdays_360d,		
sj_gldz_lastcity_min_diffdays_360d,		
sj_gldz_lastcity_avg_diffdays_360d,		
sj_gldz_lastcity_sum_diffdays_360d,
jj_gldz_lastcity_month_cnt_180d,		
jj_gldz_lastcity_max_diffdays_180d,		
jj_gldz_lastcity_min_diffdays_180d,		
jj_gldz_lastcity_avg_diffdays_180d,		
jj_gldz_lastcity_sum_diffdays_180d,
sj_gldz_lastcity_month_cnt_180d,		
sj_gldz_lastcity_max_diffdays_180d,		
sj_gldz_lastcity_min_diffdays_180d,		
sj_gldz_lastcity_avg_diffdays_180d,		
sj_gldz_lastcity_sum_diffdays_180d 
from (select tel_md5,apply_date,tel from dm_gis_oms.tmp_bryc_sample_tel_1217) as t0
left join dm_gis_oms.tmp_bryc_jj_glsj_total_res as t1 
on t0.tel=t1.tel and t0.apply_date=t1.apply_date 
left join dm_gis_oms.tmp_bryc_sj_glsj_total_res as t2 
on t0.tel=t2.tel and t0.apply_date=t2.apply_date 
left join dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_res as t3 
on t0.tel=t3.tel and t0.apply_date=t3.apply_date 
left join dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_res as t4 
on t0.tel=t4.tel and t0.apply_date=t4.apply_date 
left join dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_res as t5 
on t0.tel=t5.tel and t0.apply_date=t5.apply_date 
left join dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_res as t6 
on t0.tel=t6.tel and t0.apply_date=t6.apply_date 
left join dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_res as t7 
on t0.tel=t7.tel and t0.apply_date=t7.apply_date 
left join dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_res as t8 
on t0.tel=t8.tel and t0.apply_date=t8.apply_date 
left join dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_res as t9 
on t0.tel=t9.tel and t0.apply_date=t9.apply_date 
left join dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_res as t10 
on t0.tel=t10.tel and t0.apply_date=t10.apply_date 
left join dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_res as t11 
on t0.tel=t11.tel and t0.apply_date=t11.apply_date 
left join dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_res as t12 
on t0.tel=t12.tel and t0.apply_date=t12.apply_date 

left join dm_gis_oms.tmp_bryc_jj_gldz_city_total_res as t13 
on t0.tel=t13.tel and t0.apply_date=t13.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_city_total_res as t14 
on t0.tel=t14.tel and t0.apply_date=t14.apply_date 
left join dm_gis_oms.tmp_bryc_jj_gldz_top1addr_month_cnt_360d as t15 
on t0.tel=t15.tel and t0.apply_date=t15.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_top1addr_month_cnt_360d as t16 
on t0.tel=t16.tel and t0.apply_date=t16.apply_date 
left join dm_gis_oms.tmp_bryc_jj_gldz_top1addr_month_cnt_180d as t17 
on t0.tel=t17.tel and t0.apply_date=t17.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_top1addr_month_cnt_180d as t18 
on t0.tel=t18.tel and t0.apply_date=t18.apply_date 
left join dm_gis_oms.tmp_bryc_jj_gldz_top2addr_month_cnt_360d as t19 
on t0.tel=t19.tel and t0.apply_date=t19.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_top2addr_month_cnt_360d as t20 
on t0.tel=t20.tel and t0.apply_date=t20.apply_date 

left join dm_gis_oms.tmp_bryc_jj_gldz_top2addr_month_cnt_180d as t21 
on t0.tel=t21.tel and t0.apply_date=t21.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_top2addr_month_cnt_180d as t22 
on t0.tel=t22.tel and t0.apply_date=t22.apply_date 
left join dm_gis_oms.tmp_bryc_jj_gldz_top1city_month_cnt_360d as t23 
on t0.tel=t23.tel and t0.apply_date=t23.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_top1city_month_cnt_360d as t24 
on t0.tel=t24.tel and t0.apply_date=t24.apply_date 
left join dm_gis_oms.tmp_bryc_jj_gldz_top1city_month_cnt_180d as t25 
on t0.tel=t25.tel and t0.apply_date=t25.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_top1city_month_cnt_180d as t26 
on t0.tel=t26.tel and t0.apply_date=t26.apply_date 
left join dm_gis_oms.tmp_bryc_jj_gldz_lastaddr_month_cnt_360d as t27 
on t0.tel=t27.tel and t0.apply_date=t27.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_lastaddr_month_cnt_360d as t28 
on t0.tel=t28.tel and t0.apply_date=t28.apply_date 
left join dm_gis_oms.tmp_bryc_jj_gldz_lastaddr_month_cnt_180d as t29 
on t0.tel=t29.tel and t0.apply_date=t29.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_lastaddr_month_cnt_180d as t30 
on t0.tel=t30.tel and t0.apply_date=t30.apply_date 

left join dm_gis_oms.tmp_bryc_jj_gldz_lastcity_month_cnt_360d as t31 
on t0.tel=t31.tel and t0.apply_date=t31.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_lastcity_month_cnt_360d as t32 
on t0.tel=t32.tel and t0.apply_date=t32.apply_date 
left join dm_gis_oms.tmp_bryc_jj_gldz_lastcity_month_cnt_180d as t33 
on t0.tel=t33.tel and t0.apply_date=t33.apply_date 
left join dm_gis_oms.tmp_bryc_sj_gldz_lastcity_month_cnt_180d as t34 
on t0.tel=t34.tel and t0.apply_date=t34.apply_date 
;



desc dm_gis_oms.tmp_bryc_jj_glsj_total_res
desc dm_gis_oms.tmp_bryc_sj_glsj_total_res
desc dm_gis_oms.tmp_bryc_jj_glsj_top1addr_consignee_mobile_cnt_res
desc dm_gis_oms.tmp_bryc_sj_glsj_top1addr_consignor_mobile_cnt_res 
desc dm_gis_oms.tmp_bryc_jj_glsj_top2addr_consignee_mobile_cnt_res 
desc dm_gis_oms.tmp_bryc_sj_glsj_top2addr_consignor_mobile_cnt_res 
desc dm_gis_oms.tmp_bryc_jj_glsj_top1city_consignee_mobile_cnt_res 
desc dm_gis_oms.tmp_bryc_sj_glsj_top1city_consignor_mobile_cnt_res 
desc dm_gis_oms.tmp_bryc_jj_glsj_lastaddr_consignee_mobile_cnt_res 
desc dm_gis_oms.tmp_bryc_sj_glsj_lastaddr_consignor_mobile_cnt_res 
desc dm_gis_oms.tmp_bryc_jj_glsj_lastcity_consignee_mobile_cnt_res 
desc dm_gis_oms.tmp_bryc_sj_glsj_lastcity_consignor_mobile_cnt_res 

desc dm_gis_oms.tmp_bryc_jj_gldz_city_total_res 
desc dm_gis_oms.tmp_bryc_sj_gldz_city_total_res 
desc dm_gis_oms.tmp_bryc_jj_gldz_top1addr_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_sj_gldz_top1addr_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_jj_gldz_top1addr_month_cnt_180d 
desc dm_gis_oms.tmp_bryc_sj_gldz_top1addr_month_cnt_180d 
desc dm_gis_oms.tmp_bryc_jj_gldz_top2addr_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_sj_gldz_top2addr_month_cnt_360d 

desc dm_gis_oms.tmp_bryc_jj_gldz_top2addr_month_cnt_180d 
desc dm_gis_oms.tmp_bryc_sj_gldz_top2addr_month_cnt_180d 
desc dm_gis_oms.tmp_bryc_jj_gldz_top1city_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_sj_gldz_top1city_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_jj_gldz_top1city_month_cnt_180d 
desc dm_gis_oms.tmp_bryc_sj_gldz_top1city_month_cnt_180d 
desc dm_gis_oms.tmp_bryc_jj_gldz_lastaddr_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_sj_gldz_lastaddr_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_jj_gldz_lastaddr_month_cnt_180d 
desc dm_gis_oms.tmp_bryc_sj_gldz_lastaddr_month_cnt_180d 

desc dm_gis_oms.tmp_bryc_jj_gldz_lastcity_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_sj_gldz_lastcity_month_cnt_360d 
desc dm_gis_oms.tmp_bryc_jj_gldz_lastcity_month_cnt_180d 
desc dm_gis_oms.tmp_bryc_sj_gldz_lastcity_month_cnt_180d 