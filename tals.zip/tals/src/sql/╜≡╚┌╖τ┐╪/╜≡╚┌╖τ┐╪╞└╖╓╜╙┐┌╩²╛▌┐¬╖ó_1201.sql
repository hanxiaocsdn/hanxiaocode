-----------------------------------------------------
---- 金融风控评分接口数据开发
---- Created by 01416344(zhangxiaoqiong) on 2022/12/1
-----------------------------------------------------
-----------------------------------------------------
-- 件量中间表（寄件）
create table dm_gis_oms.dwd_frc_consignor_mid(
consignor_mobile string,
consignor_date string,
consignor_cnt string,
consignor_tm_zs_cnt string,
consignor_tm_zw_cnt string,
consignor_tm_ws_cnt string,
consigned_cnt_618  string,
consigned_cnt_1111 string,
consigned_cnt_1212 string,
consigned_cnt_person string,
consigned_cnt_company string,
consigned_cnt_tmall string,
consigned_cnt_jd string,
consigned_cnt_pos string
)
COMMENT "金融风控评分件量中间表（寄件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 城市件量中间表（寄件）
create table dm_gis_oms.dwd_frc_consignor_city_mid(
consignor_mobile string,
src_dist_code string,
citycode_consignor_cnt string
)
COMMENT "金融风控评分城市件量中间表（寄件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 件量中间表（收件）
create table dm_gis_oms.dwd_frc_consignee_mid(
consignee_mobile string,
consignor_date string,
consignor_cnt string,
signin_tm_zs_cnt string,
signin_tm_zw_cnt string,
signin_tm_ws_cnt string,
consigned_cnt_618  string,
consigned_cnt_1111 string,
consigned_cnt_1212 string,
consigned_cnt_tmall string,
consigned_cnt_jd string,
consigned_cnt_pos string
)
COMMENT "金融风控评分件量中间表（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 城市件量中间表（收件）
create table dm_gis_oms.dwd_frc_consignee_city_mid(
consignee_mobile string,
dest_dist_code string,
citycode_consignee_cnt string
)
COMMENT "金融风控评分城市件量中间表（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 每天计算一份结果(寄件)
int_sql="select 
waybill_no,inc_day,
consignor_mobile,consignor_cont_name,
consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
cons_name 
from dm_gis_oms.ods_sy_order_info_di 
where inc_day='$firstDay' and consigned_tm is not null and consigned_tm<>'' "

out_table1='dm_gis_oms.dwd_frc_consignor_mid'
out_table2='dm_gis_oms.dwd_frc_consignor_city_mid'
out_table3='dm_gis_oms.dwd_frc_consignee_mid'
out_table4='dm_gis_oms.dwd_frc_consignee_city_mid'
inc_day='$firstDay'
mainClass="com.sf.gis.scala.tals.app.FinancialRiskControlDayApp"


-- 城市等级映射表(数据准备)
create table dm_gis_oms.dws_frc_citylevel as 
select citycode,min(city_level) as city_level from dm_gis_oms.tmp_bingjian_city_level_1 group by citycode
;

---------------------------------
---------------------------------
------ 计算特征
-- 按id分区特征中间表（寄件）
drop table if exists dm_gis_oms.dws_frc_consignor_feature_tmp1;
create table dm_gis_oms.dws_frc_consignor_feature_tmp1(
consignor_mobile string,
consigned_cnt_7d int,
consigned_cnt_30d int,
consigned_cnt_90d int,
consigned_cnt_180d int,
consigned_cnt_365d int,
consigned_cnt_365d_noSpecial int,
consigned_cnt_d12m int,
consigned_cnt_d11m int,
consigned_cnt_d10m int,
consigned_cnt_d9m int,
consigned_cnt_d8m int,
consigned_cnt_d7m int,
consigned_cnt_d6m int,
consigned_cnt_d5m int,
consigned_cnt_d4m int,
consigned_cnt_d3m int,
consigned_cnt_d2m int,
consigned_cnt_d1m int,
consigned_cnt_one90d int,
consigned_cnt_two90d int,
consigned_cnt_three90d int,
consigned_cnt_four90d int,
recent_days int,
consignor_tm_zs_cnt int,
consignor_tm_zw_cnt int,
consignor_tm_ws_cnt int,
consigned_cnt_618 int,
consigned_cnt_1111 int,
consigned_cnt_1212 int,
consigned_cnt_person int,
consigned_cnt_company int,
consigned_cnt_tmall int,
consigned_cnt_jd int,
consigned_cnt_pos int
) 
COMMENT "金融风控评分件量hash取模特征中间表1（寄件）" 
PARTITIONED BY (id STRING COMMENT "hash取模分区")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


drop table if exists dm_gis_oms.dws_frc_consignor_feature_tmp2;
create table dm_gis_oms.dws_frc_consignor_feature_tmp2(
consignor_mobile string,
d1d2_growth	double,	
d2d3_growth	double,	
d3d4_growth	double,
max_dm int,
cnt_dm int
) 
COMMENT "金融风控评分件量hash取模特征中间表2（寄件）" 
PARTITIONED BY (id STRING COMMENT "hash取模分区")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table dm_gis_oms.dws_frc_consignor_feature_tmp3;
create table dm_gis_oms.dws_frc_consignor_feature_tmp3(
consignor_mobile string,
city_cnt	int,	
city_level	int
) 
COMMENT "金融风控评分件量hash取模特征中间表3（寄件）" 
PARTITIONED BY (id STRING COMMENT "hash取模分区")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 计算特征(寄件)
firstDay='20220930'
Param3=`date -d "-12 month $firstDay" +%Y%m%d`
hash_mod=10
last_id=`expr $hash_mod - 1`
for id in `seq 0 ${last_id}`;do 
    int_sql1="select 
    consignor_mobile,
    consignor_date,
    consignor_cnt,consignor_tm_zs_cnt,consignor_tm_zw_cnt,consignor_tm_ws_cnt,
    consigned_cnt_618,consigned_cnt_1111,consigned_cnt_1212,consigned_cnt_person,consigned_cnt_company,
    consigned_cnt_tmall,consigned_cnt_jd,consigned_cnt_pos
    from dm_gis_oms.dwd_frc_consignor_mid 
    where inc_day>='$Param3' and inc_day<'$firstDay'  
    and abs(hash(consignor_mobile)%${hash_mod})=${id}  "
    int_sql2="select consignor_mobile,src_dist_code,citycode_consignor_cnt from dm_gis_oms.dwd_frc_consignor_city_mid where inc_day>='$Param3' and inc_day<'$firstDay'  
    and abs(hash(consignor_mobile)%${hash_mod})=${id}  "
    int_sql3="select citycode,city_level from dm_gis_oms.dws_frc_citylevel"
    out_table1='dm_gis_oms.dws_frc_consignor_feature_tmp1'
    out_table2='dm_gis_oms.dws_frc_consignor_feature_tmp2'
    out_table3='dm_gis_oms.dws_frc_consignor_feature_tmp3'
    inc_day=$firstDay
    mainClass="com.sf.gis.scala.tals.app.FinancialRiskControlConsignorFeatureApp"

    spark-submit \
    --master yarn \
    --queue gis \
    --driver-memory 6g \
    --num-executors 15 \
    --executor-memory 30g \
    --executor-cores 20 \
    --conf spark.sql.shuffle.partitions=300 \
    --conf spark.default.parallelism=300 \
    --class $mainClass $mainJar "$int_sql1" "$int_sql2" "$int_sql3" "$out_table1"  "$out_table2" "$out_table3" "$inc_day" "${id}"

done


-- 按id分区特征中间表（收件）
drop table if exists dm_gis_oms.dws_frc_consignee_feature_tmp1;
create table dm_gis_oms.dws_frc_consignee_feature_tmp1(
consignee_mobile string,
consigned_cnt_7d int,
consigned_cnt_30d int,
consigned_cnt_90d int,
consigned_cnt_180d int,
consigned_cnt_365d int,
consigned_cnt_365d_noSpecial int,
consigned_cnt_d12m int,
consigned_cnt_d11m int,
consigned_cnt_d10m int,
consigned_cnt_d9m int,
consigned_cnt_d8m int,
consigned_cnt_d7m int,
consigned_cnt_d6m int,
consigned_cnt_d5m int,
consigned_cnt_d4m int,
consigned_cnt_d3m int,
consigned_cnt_d2m int,
consigned_cnt_d1m int,
consigned_cnt_d12m_ts int,
consigned_cnt_d11m_ts int,
consigned_cnt_d10m_ts int,
consigned_cnt_d9m_ts int,
consigned_cnt_d8m_ts int,
consigned_cnt_d7m_ts int,
consigned_cnt_d6m_ts int,
consigned_cnt_d5m_ts int,
consigned_cnt_d4m_ts int,
consigned_cnt_d3m_ts int,
consigned_cnt_d2m_ts int,
consigned_cnt_d1m_ts int,
signin_tm_zs_cnt int,
signin_tm_zw_cnt int,
signin_tm_ws_cnt int,
consigned_cnt_618 int,
consigned_cnt_1111 int,
consigned_cnt_1212 int,
consigned_cnt_tmall int,
consigned_cnt_jd int,
consigned_cnt_pos int
) 
COMMENT "金融风控评分件量hash取模特征中间表1（收件）" 
PARTITIONED BY (id STRING COMMENT "hash取模分区")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table if exists dm_gis_oms.dws_frc_consignee_feature_tmp2;
create table dm_gis_oms.dws_frc_consignee_feature_tmp2(
consignee_mobile string,
recent_1y_stab double,
max_dm int,
cnt_dm int
) 
COMMENT "金融风控评分件量hash取模特征中间表2（收件）" 
PARTITIONED BY (id STRING COMMENT "hash取模分区")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table dm_gis_oms.dws_frc_consignee_feature_tmp3;
create table dm_gis_oms.dws_frc_consignee_feature_tmp3(
consignee_mobile string,
city_cnt int
) 
COMMENT "金融风控评分件量hash取模特征中间表3（收件）" 
PARTITIONED BY (id STRING COMMENT "hash取模分区")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



-- 计算特征shell（收件）
firstDay='20220930'
Param3=`date -d "-12 month $firstDay" +%Y%m%d`

hash_mod=10
last_id=`expr $hash_mod - 1`
for id in `seq 0 ${last_id}`;do 
    int_sql1="select 
    consignee_mobile,
    consignor_date,
    consignor_cnt,signin_tm_zs_cnt,signin_tm_zw_cnt,signin_tm_ws_cnt,
    consigned_cnt_618,consigned_cnt_1111,consigned_cnt_1212,
    consigned_cnt_tmall,consigned_cnt_jd,consigned_cnt_pos
    from dm_gis_oms.dwd_frc_consignee_mid 
    where inc_day>='$Param3' and inc_day<'$firstDay' 
    and abs(hash(consignee_mobile)%${hash_mod})=${id}  "
    int_sql2="select consignee_mobile,dest_dist_code,citycode_consignee_cnt 
    from dm_gis_oms.dwd_frc_consignee_city_mid where inc_day>='$Param3' and inc_day<'$firstDay'
    and abs(hash(consignee_mobile)%${hash_mod})=${id}    "
    out_table1='dm_gis_oms.dws_frc_consignee_feature_tmp1'
    out_table2='dm_gis_oms.dws_frc_consignee_feature_tmp2'
    out_table3='dm_gis_oms.dws_frc_consignee_feature_tmp3'
    inc_day=$firstDay
    mainClass="com.sf.gis.scala.tals.app.FinancialRiskControlConsigneeFeatureApp"

    spark-submit \
    --master yarn \
    --queue gis \
    --driver-memory 6g \
    --num-executors 15 \
    --executor-memory 30g \
    --executor-cores 20 \
    --conf spark.sql.shuffle.partitions=300 \
    --conf spark.default.parallelism=300 \
    --class $mainClass $mainJar "$int_sql1" "$int_sql2" "$out_table1"  "$out_table2" "$out_table3" "$inc_day" "${id}"

done




---- 特征汇合(总)
create table dm_gis_oms.dws_frc_feature(
tel_md5 string,
consigned_cnt_7d int,
consigned_cnt_30d int,
consigned_cnt_90d int,
consigned_cnt_180d int,
consigned_cnt_365d int,
consigned_cnt_365d_noSpecial int,
consigned_cnt_d12m int,
consigned_cnt_d11m int,
consigned_cnt_d10m int,
consigned_cnt_d9m int,
consigned_cnt_d8m int,
consigned_cnt_d7m int,
consigned_cnt_d6m int,
consigned_cnt_d5m int,
consigned_cnt_d4m int,
consigned_cnt_d3m int,
consigned_cnt_d2m int,
consigned_cnt_d1m int,
consigned_cnt_one90d int,
consigned_cnt_two90d int,
d1d2_growth double,
consigned_cnt_three90d int,
d2d3_growth double,
consigned_cnt_four90d int,
d3d4_growth double,
recent_days int,
consignor_tm_zs_cnt int,
consignor_tm_zw_cnt int,
consignor_tm_ws_cnt int,
consigned_cnt_618 int,
consigned_cnt_1111 int,
consigned_cnt_1212 int,
consigned_cnt_person int,
consigned_cnt_company int,
consigned_cnt_tmall int,
consigned_cnt_jd int,
consigned_cnt_pos int,
max_dm int,
cnt_dm int,
city_cnt int,
city_level int,
consignee_cnt_7d int,
consignee_cnt_30d int,
consignee_cnt_90d int,
consignee_cnt_180d int,
consignee_cnt_365d int,
consignee_cnt_365d_nospecial int,
consignee_cnt_d12m int,
consignee_cnt_d11m int,
consignee_cnt_d10m int,
consignee_cnt_d9m int,
consignee_cnt_d8m int,
consignee_cnt_d7m int,
consignee_cnt_d6m int,
consignee_cnt_d5m int,
consignee_cnt_d4m int,
consignee_cnt_d3m int,
consignee_cnt_d2m int,
consignee_cnt_d1m int,
consignee_cnt_d12m_ts int,
consignee_cnt_d11m_ts int,
consignee_cnt_d10m_ts int,
consignee_cnt_d9m_ts int,
consignee_cnt_d8m_ts int,
consignee_cnt_d7m_ts int,
consignee_cnt_d6m_ts int,
consignee_cnt_d5m_ts int,
consignee_cnt_d4m_ts int,
consignee_cnt_d3m_ts int,
consignee_cnt_d2m_ts int,
consignee_cnt_d1m_ts int,
recent_1y_stab double,
signin_tm_zs_cnt int,
signin_tm_zw_cnt int,
signin_tm_ws_cnt int,
consignee_cnt_618 int,
consignee_cnt_1111 int,
consignee_cnt_1212 int,
consignee_cnt_tmall int,
consignee_cnt_jd int,
consignee_cnt_pos int,
consignee_max_dm int,
consignee_cnt_dm int,
consignee_city_cnt int
) 
COMMENT '金融风控特征' 
PARTITIONED BY (inc_day STRING COMMENT '日期分区',id STRING COMMENT 'hash取模分区')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 1、获取到电话md5

hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

drop table if exists  dm_gis_oms.dws_frc_base_feature_tmp ;
create table dm_gis_oms.dws_frc_base_feature_tmp stored as parquet as 
select 
t0.tel,t0.tel_md5,t1.id  
from (select tel,tel_md5 from dm_gis_oms.ods_tals_tel_base where tel is not null and tel<>'' and tel_md5 is not null and tel_md5<>'' group by tel,tel_md5 ) as t0 
left join ( select mobile,id from 
(select consignor_mobile as mobile,id from dm_gis_oms.dws_frc_consignor_feature_tmp2  
union all 
select consignee_mobile as mobile,id from dm_gis_oms.dws_frc_consignee_feature_tmp2 ) as t group by mobile,id  ) as t1 
on t0.tel=t1.mobile
where t1.mobile is not null  
;
"

-- 2、特征合并
hash_mod=10
last_id=`expr $hash_mod - 1`
for id in `seq 0 ${last_id}`;do 

    hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;


insert overwrite table dm_gis_oms.dws_frc_feature partition(inc_day='$firstDay',id='$id') 
select 
t0.tel_md5,
t1.consigned_cnt_7d,
t1.consigned_cnt_30d,
t1.consigned_cnt_90d,
t1.consigned_cnt_180d,
t1.consigned_cnt_365d,
t1.consigned_cnt_365d_nospecial,
t1.consigned_cnt_d12m,
t1.consigned_cnt_d11m,
t1.consigned_cnt_d10m,
t1.consigned_cnt_d9m,
t1.consigned_cnt_d8m,
t1.consigned_cnt_d7m,
t1.consigned_cnt_d6m,
t1.consigned_cnt_d5m,
t1.consigned_cnt_d4m,
t1.consigned_cnt_d3m,
t1.consigned_cnt_d2m,
t1.consigned_cnt_d1m,
t1.consigned_cnt_one90d,
t1.consigned_cnt_two90d,
t2.d1d2_growth,
t1.consigned_cnt_three90d,
t2.d2d3_growth,
t1.consigned_cnt_four90d,
t2.d3d4_growth,
t1.recent_days,
t1.consignor_tm_zs_cnt,
t1.consignor_tm_zw_cnt,
t1.consignor_tm_ws_cnt,
t1.consigned_cnt_618,
t1.consigned_cnt_1111,
t1.consigned_cnt_1212,
t1.consigned_cnt_person,
t1.consigned_cnt_company,
t1.consigned_cnt_tmall,
t1.consigned_cnt_jd,
t1.consigned_cnt_pos,
t2.max_dm,
t2.cnt_dm,
t3.city_cnt,
t3.city_level,
t5.consigned_cnt_7d as consignee_cnt_7d,
t5.consigned_cnt_30d as consignee_cnt_30d,
t5.consigned_cnt_90d as consignee_cnt_90d,
t5.consigned_cnt_180d as consignee_cnt_180d,
t5.consigned_cnt_365d as consignee_cnt_365d,
t5.consigned_cnt_365d_nospecial as consignee_cnt_365d_nospecial,
t5.consigned_cnt_d12m as consignee_cnt_d12m,
t5.consigned_cnt_d11m as consignee_cnt_d11m,
t5.consigned_cnt_d10m as consignee_cnt_d10m,
t5.consigned_cnt_d9m as consignee_cnt_d9m,
t5.consigned_cnt_d8m as consignee_cnt_d8m,
t5.consigned_cnt_d7m as consignee_cnt_d7m,
t5.consigned_cnt_d6m as consignee_cnt_d6m,
t5.consigned_cnt_d5m as consignee_cnt_d5m,
t5.consigned_cnt_d4m as consignee_cnt_d4m,
t5.consigned_cnt_d3m as consignee_cnt_d3m,
t5.consigned_cnt_d2m as consignee_cnt_d2m,
t5.consigned_cnt_d1m as consignee_cnt_d1m,
t5.consigned_cnt_d12m_ts as consignee_cnt_d12m_ts,
t5.consigned_cnt_d11m_ts as consignee_cnt_d11m_ts,
t5.consigned_cnt_d10m_ts as consignee_cnt_d10m_ts,
t5.consigned_cnt_d9m_ts as consignee_cnt_d9m_ts,
t5.consigned_cnt_d8m_ts as consignee_cnt_d8m_ts,
t5.consigned_cnt_d7m_ts as consignee_cnt_d7m_ts,
t5.consigned_cnt_d6m_ts as consignee_cnt_d6m_ts,
t5.consigned_cnt_d5m_ts as consignee_cnt_d5m_ts,
t5.consigned_cnt_d4m_ts as consignee_cnt_d4m_ts,
t5.consigned_cnt_d3m_ts as consignee_cnt_d3m_ts,
t5.consigned_cnt_d2m_ts as consignee_cnt_d2m_ts,
t5.consigned_cnt_d1m_ts as consignee_cnt_d1m_ts,
t6.recent_1y_stab,
t5.signin_tm_zs_cnt,
t5.signin_tm_zw_cnt,
t5.signin_tm_ws_cnt,
t5.consigned_cnt_618 as consignee_cnt_618,
t5.consigned_cnt_1111 as consignee_cnt_1111,
t5.consigned_cnt_1212 as consignee_cnt_1212,
t5.consigned_cnt_tmall as consignee_cnt_tmall,
t5.consigned_cnt_jd as consignee_cnt_jd,
t5.consigned_cnt_pos as consignee_cnt_pos,
t6.max_dm as consignee_max_dm,
t6.cnt_dm as consignee_cnt_dm,
t7.city_cnt as consignee_city_cnt 
from (select tel,tel_md5 from dm_gis_oms.dws_frc_base_feature_tmp where id='${id}'  ) as t0 
left join (select * from dm_gis_oms.dws_frc_consignor_feature_tmp1 where id='$id' ) as t1 
on t0.tel=t1.consignor_mobile 
left join (select * from dm_gis_oms.dws_frc_consignor_feature_tmp2 where id='$id' ) as t2 
on t0.tel=t2.consignor_mobile 
left join (select * from dm_gis_oms.dws_frc_consignor_feature_tmp3 where id='$id' ) as t3 
on t0.tel=t3.consignor_mobile 
left join (select * from dm_gis_oms.dws_frc_consignee_feature_tmp1 where id='$id' ) as t5 
on t0.tel=t5.consignee_mobile 
left join (select * from dm_gis_oms.dws_frc_consignee_feature_tmp2 where id='$id' ) as t6 
on t0.tel=t6.consignee_mobile 
left join (select * from dm_gis_oms.dws_frc_consignee_feature_tmp3 where id='$id' ) as t7 
on t0.tel=t7.consignee_mobile 
;
"

done 

--验证数据
58943,823cf4834865afc17b56a7af725c3471,2022-09-30,1,2,11,12,18,16,1,1,2,1,0,1,0,0,1,3,6,2,11,1,10.0,2,-0.5,4,-0.5,1,7,8,3,1,0,0,18,0,0,0,0,6,9,1,2,0,3,6,8,19,17,0,0,1,2,7,1,0,1,1,1,2,3,0,0,0,2,7,1,0,1,0,1,2,3,1.3656690313228117,15,4,0,1,0,0,0,0,0,7,9,1
51927,2fe70adab51914b1e284f30e6924e4f8,2022-09-30,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,1,1,2,2,2,2,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,2.2360679774997902,2,0,0,0,0,0,0,0,0,1,2,1
87850,151b3b97e9c0f958a1e8879b0f860f89,2022-09-30,0,2,11,20,29,19,2,0,5,1,1,0,2,2,5,8,1,2,11,9,0.2222222222222222,1,8.0,8,-0.875,15,16,12,1,5,0,0,9,20,0,0,0,8,10,1,2,1,5,37,77,193,133,16,24,30,9,15,19,9,14,17,21,11,5,16,5,6,9,15,19,9,14,0,21,11,5,0.558739070687227,133,48,12,17,0,0,4,6,0,30,12,1

tel_md5,consigned_cnt_7d,consigned_cnt_30d,consigned_cnt_90d,consigned_cnt_180d,consigned_cnt_365d,consigned_cnt_365d_nospecial,consigned_cnt_d12m,consigned_cnt_d11m,consigned_cnt_d10m,consigned_cnt_d9m,consigned_cnt_d8m,consigned_cnt_d7m,consigned_cnt_d6m,consigned_cnt_d5m,consigned_cnt_d4m,consigned_cnt_d3m,consigned_cnt_d2m,consigned_cnt_d1m,consigned_cnt_one90d,consigned_cnt_two90d,d1d2_growth,consigned_cnt_three90d,d2d3_growth,consigned_cnt_four90d,d3d4_growth,recent_days,consignor_tm_zs_cnt,consignor_tm_zw_cnt,consignor_tm_ws_cnt,consigned_cnt_618,consigned_cnt_1111,consigned_cnt_1212,consigned_cnt_person,consigned_cnt_company,consigned_cnt_tmall,consigned_cnt_jd,consigned_cnt_pos,max_dm,cnt_dm,city_cnt,city_level,consignee_cnt_7d,consignee_cnt_30d,consignee_cnt_90d,consignee_cnt_180d,consignee_cnt_365d,consignee_cnt_365d_nospecial,consignee_cnt_d12m,consignee_cnt_d11m,consignee_cnt_d10m,consignee_cnt_d9m,consignee_cnt_d8m,consignee_cnt_d7m,consignee_cnt_d6m,consignee_cnt_d5m,consignee_cnt_d4m,consignee_cnt_d3m,consignee_cnt_d2m,consignee_cnt_d1m,consignee_cnt_d12m_ts,consignee_cnt_d11m_ts,consignee_cnt_d10m_ts,consignee_cnt_d9m_ts,consignee_cnt_d8m_ts,consignee_cnt_d7m_ts,consignee_cnt_d6m_ts,consignee_cnt_d5m_ts,consignee_cnt_d4m_ts,consignee_cnt_d3m_ts,consignee_cnt_d2m_ts,consignee_cnt_d1m_ts,recent_1y_stab,signin_tm_zs_cnt,signin_tm_zw_cnt,signin_tm_ws_cnt,consignee_cnt_618,consignee_cnt_1111,consignee_cnt_1212,consignee_cnt_tmall,consignee_cnt_jd,consignee_cnt_pos,consignee_max_dm,consignee_cnt_dm,consignee_city_cnt,inc_day
151b3b97e9c0f958a1e8879b0f860f89,0,2,11,20,29,19,2,0,5,1,1,0,2,2,5,8,1,2,11,9,0.2222222222222222,1,8.0,8,-0.875,15,16,12,1,5,0,5,9,20,0,0,0,8,10,1,2,1,5,37,77,193,131,16,24,30,9,15,19,9,14,17,21,11,5,16,4,5,9,15,19,9,14,0,21,11,5,0.5821230003186612,133,48,12,17,20,25,4,6,0,30,12,1,20220930
2fe70adab51914b1e284f30e6924e4f8,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,1,1,2,2,2,2,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,2.2360679774997902,2,0,0,0,0,0,0,0,0,1,2,1,20220930
823cf4834865afc17b56a7af725c3471,1,2,11,12,18,15,1,1,2,1,0,1,0,0,1,3,6,2,11,1,10.0,2,-0.5,4,-0.5,1,7,8,3,1,1,1,18,0,0,0,0,6,9,1,2,0,3,6,8,19,17,0,0,1,2,7,1,0,1,1,1,2,3,0,0,0,2,7,1,0,1,0,1,2,3,1.3656690313228117,15,4,0,1,0,1,0,0,0,7,9,1,20220930


select * from dm_gis_oms.dws_frc_feature 
where tel_md5 in ('823cf4834865afc17b56a7af725c3471',
'2fe70adab51914b1e284f30e6924e4f8','151b3b97e9c0f958a1e8879b0f860f89') limit 10




-- ---- 模型得分表（同步到hbase  gis:frc_model_score） 
-- drop table if exists dm_gis_oms.dws_frc_model_score;
-- create table dm_gis_oms.dws_frc_model_score(
-- rk string comment 'rowkey(含电话md5)',
-- m1s string comment '模型1得分',
-- m2s string comment '模型2得分',
-- m3s string comment '模型3得分' 
-- )
-- COMMENT '金融风控模型得分表' 
-- PARTITIONED BY (inc_day STRING COMMENT '分区日期')
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;

-- insert into dm_gis_oms.dws_frc_model_score partition(inc_day='20221208') 
-- values ('659bd23e9e71a93ea1fab02a1f4865bd','0.12','0.116252013','0.107236454')
-- ,('8c6e664fb2b2f6fbe4903a4cfc5362a5','0.1','0.09682694','0.079740573')
-- ,('20a8bbd5a0363396266c6d161e57e257','0.05','0.045679027','0.041891329')
-- ,('eb97ea6e8457e0a2046ed548734ad7c5','0.11','0.105494506','0.10144466')
-- ;


-- -- hbase测试数据
-- rowKey	info:rk	info:m1s	info:m2s	info:m3s
-- 20a8bbd5a0363396266c6d161e57e257	20a8bbd5a0363396266c6d161e57e257	0.05	0.045679027	0.041891329
-- 659bd23e9e71a93ea1fab02a1f4865bd	659bd23e9e71a93ea1fab02a1f4865bd	0.12	0.116252013	0.107236454
-- 8c6e664fb2b2f6fbe4903a4cfc5362a5	8c6e664fb2b2f6fbe4903a4cfc5362a5	0.1	0.09682694	0.079740573
-- eb97ea6e8457e0a2046ed548734ad7c5	eb97ea6e8457e0a2046ed548734ad7c5	0.11	0.105494506



-------增加冰鉴的模型-----
-- 模型得分中间表（按模型名分区）
create table dm_gis_oms.dws_frc_model_score_mid(
tel_md5 string,
m1s string,
m2s string,
m3s string,
m4s string,
m5s string,
m6s string 
)
COMMENT '金融风控模型得分中间表' 
PARTITIONED BY (inc_day STRING COMMENT '日期',id STRING COMMENT 'hash取模分区')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 跑数shell 
mainJar="frc_model_score.jar"

firstDay='20220930'

hash_mod=10
last_id=`expr $hash_mod - 1`
for id in `seq 0 ${last_id}`;do 

    int_sql1="select * from dm_gis_oms.dws_frc_feature where inc_day='$firstDay' and id='$id' and (consigned_cnt_7d is not null or consignee_cnt_7d is not null)"
    out_table1='dm_gis_oms.dws_frc_model_score_mid'
    inc_day=$firstDay
    repart_n=1000
    mainClass="org.jpmml.evaluator.spark.FinancialRiskControlModelScoreApp" 

    spark-submit \
    --master yarn \
    --queue gis \
    --driver-memory 6g \
    --num-executors 20 \
    --executor-memory 7g \
    --executor-cores 20 \
    --conf spark.sql.shuffle.partitions=500 \
    --conf spark.default.parallelism=1000 \
    --class $mainClass $mainJar "$int_sql1" "$out_table1" "${id}" "$inc_day" "$repart_n"

done

---- 模型得分中间表（特征分箱）（按模型名分区）
create table dm_gis_oms.dws_frc_model_score_mid1(
tel_md5 string,
m7s string 
)
COMMENT '金融风控模型得分中间表(特征分箱)' 
PARTITIONED BY (inc_day STRING COMMENT '日期',id STRING COMMENT 'hash取模分区')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 跑数shell
mainJar="frc_model_score.jar"

firstDay='20220930'

hash_mod=10
last_id=`expr $hash_mod - 1`
for id in `seq 0 ${last_id}`;do 

    int_sql1="select * from dm_gis_oms.dws_frc_feature where inc_day='$firstDay' and id='$id' and (consigned_cnt_7d is not null or consignee_cnt_7d is not null)"
    out_table1='dm_gis_oms.dws_frc_model_score_mid1'
    inc_day=$firstDay
    repart_n=1000
    mainClass="org.jpmml.evaluator.spark.FinancialRiskControlModelScoreBinningApp" 

    spark-submit \
    --master yarn \
    --queue gis \
    --driver-memory 6g \
    --num-executors 20 \
    --executor-memory 7g \
    --executor-cores 20 \
    --conf spark.sql.shuffle.partitions=500 \
    --conf spark.default.parallelism=1000 \
    --class $mainClass $mainJar "$int_sql1" "$out_table1" "${id}" "$inc_day" "$repart_n"

done



---- 模型得分表（同步到hbase  gis:frc_model_score） 
drop table if exists dm_gis_oms.dws_frc_model_score;
create table dm_gis_oms.dws_frc_model_score(
rk string comment 'rowkey(含电话md5)',
m1s string comment '模型1得分',
m2s string comment '模型2得分',
m3s string comment '模型3得分',
m4s string comment '模型4得分',
m5s string comment '模型5得分',
m6s string comment '模型6得分', 
m7s string comment '模型7得分(冰鉴20个特征分箱压缩)'
)
COMMENT '金融风控模型得分表' 
PARTITIONED BY (inc_day STRING COMMENT '分区日期',id STRING COMMENT 'hash取模分区')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
hash_mod=10
last_id=`expr $hash_mod - 1`
for id in `seq 0 ${last_id}`;do 

    hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;


insert overwrite table dm_gis_oms.dws_frc_model_score partition(inc_day='$firstDay',id='$id')
select concat(lpad(abs(hash(t0.tel_md5)%300),3,0),'_',t0.tel_md5) as rk,m1s,m2s,m3s,m4s,m5s,m6s,m7s from 
(select tel_md5,m1s,m2s,m3s,m4s,m5s,m6s from dm_gis_oms.dws_frc_model_score_mid where inc_day='$firstDay' and  id='$id' ) as t0 
left join 
(select tel_md5,m7s from dm_gis_oms.dws_frc_model_score_mid1 where inc_day='$firstDay' and  id='$id' ) as t1 
on t0.tel_md5=t1.tel_md5 
;

drop table if exists dm_gis_oms.dws_frc_model_score_isnull;
create table dm_gis_oms.dws_frc_model_score_isnull as 
select rk 
from (select rk from dm_gis_oms.dws_frc_model_score where inc_day<'$firstDay' and id='$id' ) as t0 
left join (select concat(lpad(abs(hash(tel_md5)%300),3,0),'_',tel_md5) as tel_md5 from dm_gis_oms.dws_frc_model_score_mid1 where inc_day='$firstDay' and  id='$id'  ) as t1 
on t0.rk=t1.tel_md5 
where t1.tel_md5 is null
;

insert into dm_gis_oms.dws_frc_model_score partition(inc_day='$firstDay',id='$id') 
select rk,'' as m1s,'' as m2s,'' as m3s,'' as m4s,'' as m5s,'' as m6s,'' as m7s from dm_gis_oms.dws_frc_model_score_isnull
;

"

done


-- 删除过去的分区
firstDay=$p_first
yDay=`date -d "-365 day $firstDay" +%Y%m%d`

hive -e "alter table dm_gis_oms.dws_frc_model_score drop partition (inc_day<'$firstDay');
alter table dm_gis_oms.dws_frc_model_score_mid drop partition (inc_day<'$firstDay');
alter table dm_gis_oms.dws_frc_model_score_mid1 drop partition (inc_day<'$firstDay');
alter table dm_gis_oms.dws_frc_consignee_feature_tmp1 drop partition (id<'90');
alter table dm_gis_oms.dws_frc_consignee_feature_tmp2 drop partition (id<'90');
alter table dm_gis_oms.dws_frc_consignee_feature_tmp3 drop partition (id<'90');
alter table dm_gis_oms.dws_frc_consignor_feature_tmp1 drop partition (id<'90');
alter table dm_gis_oms.dws_frc_consignor_feature_tmp2 drop partition (id<'90');
alter table dm_gis_oms.dws_frc_consignor_feature_tmp3 drop partition (id<'90');
alter table dm_gis_oms.dwd_frc_consignor_mid drop partition (inc_day<'$yDay');
alter table dm_gis_oms.dwd_frc_consignee_mid drop partition (inc_day<'$yDay');
alter table dm_gis_oms.dwd_frc_consignor_city_mid drop partition (inc_day<'$yDay');
alter table dm_gis_oms.dwd_frc_consignee_city_mid drop partition (inc_day<'$yDay');
drop table if exists  dm_gis_oms.dws_frc_base_feature_tmp ;"

-- 同步到hbase
-- 命名空间：gis  表名：frc_model_score   预分区数：300    hbase赋权：账户名 82986df49a-1124 	密码 f4d4849b	所属应用 GIS_LSS_TLOC_定位服务系统_轨迹定位系統	
-- ETL脚本模式（分两个）
select rk,m1s,m2s,m3s,m4s,m5s,m6s,m7s from dm_gis_oms.dws_frc_model_score where id<'5'
select rk,m1s,m2s,m3s,m4s,m5s,m6s,m7s from dm_gis_oms.dws_frc_model_score where id>='5'


-- ALTER TABLE dm_gis_oms.dws_frc_model_score rename TO dm_gis_oms.dws_frc_model_score_tmp


-- create table dm_gis_oms.dws_frc_model_score_isnull as 
-- select t0.rk 
-- from (select rk from dm_gis_oms.dws_frc_model_score_tmp  ) as t0 
-- left join (select tel_md5 from dm_gis_oms.dws_frc_model_score_mid where inc_day='$firstDay'  ) as t1 
-- on t0.rk=t1.tel_md5 
-- where t1.tel_md5 is null
-- ;


