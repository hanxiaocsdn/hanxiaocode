-- 百融云创第三次数据开发
-- 描述：新增特征2千多个


-- 样例数据导入hive
create table dm_gis_oms.tmp_bryc_sample_1217(
tel_md5 string,
apply_date string
)
comment '百融云创测试三' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/bryc_sample_1217.csv' OVERWRITE INTO TABLE dm_gis_oms.tmp_bryc_sample_1217;


-- md5电话关联出加密电话和原始电话
drop table if exists dm_gis_oms.tmp_bryc_sample_tel_1217;
create table dm_gis_oms.tmp_bryc_sample_tel_1217 as 
select 
t1.tel_md5,t1.apply_date,
t0.tel,t0.tel_decode,t0.name 
from dm_gis_oms.ods_tals_tel_base as t0  
left join  dm_gis_oms.tmp_bryc_sample_1217 as t1 
on t0.tel_md5=t1.tel_md5
where t1.tel_md5 is not null 
group by t1.tel_md5,t1.apply_date,
t0.tel,t0.tel_decode,t0.name
;

-- 备份关联表
create table dm_gis_oms.tmp_bryc_sample_tel_bak (
tel_md5 string,
apply_date string,
tel string,
tel_decode string,
name string   
) 
comment '备份md5电话关联出加密电话和原始电话关联表'
PARTITIONED BY (
run_day string COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


insert into dm_gis_oms.tmp_bryc_sample_tel_bak partition(run_day='') 
select tel_md5,apply_date,tel,tel_decode,name from dm_gis_oms.tmp_bryc_sample_tel_1217
;



---- 建关联运单数据表（取max(apply_date)往前一年作为开始分区，通过电话关联运单）
-- consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
-- consigned_tm,src_dist_code,
-- signin_tm,dest_dist_code,
-- consignor_comp_name,consignee_comp_name,
-- waybill_no,cons_name 
-- freight_payment_type_code 寄付/到付,freight_settlement_type_code 现结/月结,
-- all_fee_rmb 运费,
-- service_prod_code 增值服务代码,has_service_prod_flag 有无增值服务,
-- customs_batchs 报关批次
-- consignor_addr 寄件地址
-- consignee_addr 收件地址

-- 寄件运单
drop table if exists dm_gis_oms.tmp_bryc_order_consignor_di_1217;
create table dm_gis_oms.tmp_bryc_order_consignor_di_1217(
tel string,
apply_date string,
consignor_mobile string,
consignor_cont_name string,
consignee_mobile string,
consignee_cont_name string,
consigned_tm string,
src_dist_code string,
signin_tm string,
dest_dist_code string,
consignor_comp_name string,
consignee_comp_name string,
waybill_no string,
cons_name array<string>,
freight_payment_type_code string comment '寄付/到付',
freight_settlement_type_code  string comment '现结/月结',
all_fee_rmb  string comment '运费',
service_prod_code  string comment '增值服务代码',
has_service_prod_flag  string comment '有无增值服务',
customs_batchs  string comment '报关批次',
consignor_addr  string comment '寄件地址',
consignee_addr  string comment '收件地址' 
)
comment '运单寄件'
PARTITIONED BY (
inc_day string COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 收件运单
drop table if exists dm_gis_oms.tmp_bryc_order_consignee_di_1217;
create table dm_gis_oms.tmp_bryc_order_consignee_di_1217(
tel string,
apply_date string,
consignor_mobile string,
consignor_cont_name string,
consignee_mobile string,
consignee_cont_name string,
consigned_tm string,
src_dist_code string,
signin_tm string,
dest_dist_code string,
consignor_comp_name string,
consignee_comp_name string,
waybill_no string,
cons_name array<string>,
freight_payment_type_code string comment '寄付/到付',
freight_settlement_type_code  string comment '现结/月结',
all_fee_rmb  string comment '运费',
service_prod_code  string comment '增值服务代码',
has_service_prod_flag  string comment '有无增值服务',
customs_batchs  string comment '报关批次',
consignor_addr  string comment '寄件地址',
consignee_addr  string comment '收件地址' 
)
comment '运单收件'
PARTITIONED BY (
inc_day string COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy');



---- 关联运单跑数  (dm_gis_oms.ods_sy_order_info_di没有customs_batchs报关批次; dm_gis.tt_waybill_info只保留了近3年的数据)
-- 寄件运单
sqltest=" 
insert overwrite table dm_gis_oms.tmp_bryc_order_consignor_di_1217 partition(inc_day='$firstDay')
select 
t0.tel,t0.apply_date,
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
customs_batchs,
consignor_addr,
consignee_addr  
from (
select 
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
'' as customs_batchs,
consignor_addr,
consignee_addr  
from dm_gis_oms.ods_sy_order_info_di  
where inc_day='$firstDay'
) as t1 
left join dm_gis_oms.tmp_bryc_sample_tel_1217 as t0 
on t0.tel=t1.consignor_mobile 
where 
consigned_tm is not null and consigned_tm<>'' 
and t0.apply_date>substr(consigned_tm,1,10)
;
"

sqltest=" 
insert overwrite table dm_gis_oms.tmp_bryc_order_consignor_di_1217 partition(inc_day='$firstDay')
select 
t0.tel,t0.apply_date,
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
customs_batchs,
consignor_addr,
consignee_addr  
from (
select 
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
customs_batchs,
consignor_addr,
consignee_addr  
from dm_gis.tt_waybill_info   
where inc_day='$firstDay'
) as t1 
left join dm_gis_oms.tmp_bryc_sample_tel_1217 as t0 
on t0.tel=t1.consignor_mobile 
where 
consigned_tm is not null and consigned_tm<>'' 
and t0.apply_date>substr(consigned_tm,1,10)
;
"


-- 收件运单
sqltest=" 
insert overwrite table dm_gis_oms.tmp_bryc_order_consignee_di_1217 partition(inc_day='$firstDay')
select 
t0.tel,t0.apply_date,
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
customs_batchs,
consignor_addr,
consignee_addr  
from (
select 
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
'' as customs_batchs,
consignor_addr,
consignee_addr  
from dm_gis_oms.ods_sy_order_info_di   
where inc_day='$firstDay'
) as t1 
left join dm_gis_oms.tmp_bryc_sample_tel_1217 as t0 
on t0.tel=t1.consignee_mobile 
where 
signin_tm is not null and signin_tm<>'' 
and t0.apply_date>substr(signin_tm,1,10)
;
"

sqltest=" 
insert overwrite table dm_gis_oms.tmp_bryc_order_consignee_di_1217 partition(inc_day='$firstDay')
select 
t0.tel,t0.apply_date,
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
customs_batchs,
consignor_addr,
consignee_addr  
from (
select 
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,
signin_tm,dest_dist_code,
consignor_comp_name,consignee_comp_name,
waybill_no,cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
customs_batchs,
consignor_addr,
consignee_addr  
from dm_gis.tt_waybill_info    
where inc_day='$firstDay'
) as t1 
left join dm_gis_oms.tmp_bryc_sample_tel_1217 as t0 
on t0.tel=t1.consignee_mobile 
where 
signin_tm is not null and signin_tm<>'' 
and t0.apply_date>substr(signin_tm,1,10)
;
"


-- 增值服务代码
create table dm_gis_oms.frc_rhjk_zcfw as select * from dim.dim_fee_serv_info_df where inc_day='20221212' and type_flg=2 and is_valid=1 limit 100;


-- 运单数据合成
drop table if exists dm_gis_oms.tmp_bryc_order_consignor_all_1217;
create table dm_gis_oms.tmp_bryc_order_consignor_all_1217 as 
select 
* 
from 
dm_gis_oms.tmp_bryc_order_consignor_di_1217
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-365),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
and apply_date>=consigned_tm 
;

drop table if exists dm_gis_oms.tmp_bryc_order_consignee_all_1217;
create table dm_gis_oms.tmp_bryc_order_consignee_all_1217 as 
select 
* 
from 
dm_gis_oms.tmp_bryc_order_consignee_di_1217
where unix_timestamp(date_add(from_unixtime(unix_timestamp(apply_date,'yyyy-MM-dd'),'yyyy-MM-dd HH:mm:ss'),-365),'yyyy-MM-dd')<=unix_timestamp(consigned_tm,'yyyy-MM-dd HH:mm:ss')
and apply_date>=consigned_tm 
;

-- 运单数据备份
-- 寄件运单
create table dm_gis_oms.tmp_bryc_order_consignor_all_bak(
tel string,
apply_date string,
consignor_mobile string,
consignor_cont_name string,
consignee_mobile string,
consignee_cont_name string,
consigned_tm string,
src_dist_code string,
signin_tm string,
dest_dist_code string,
consignor_comp_name string,
consignee_comp_name string,
waybill_no string,
cons_name array<string>,
freight_payment_type_code string comment '寄付/到付',
freight_settlement_type_code  string comment '现结/月结',
all_fee_rmb  string comment '运费',
service_prod_code  string comment '增值服务代码',
has_service_prod_flag  string comment '有无增值服务',
customs_batchs  string comment '报关批次',
consignor_addr  string comment '寄件地址',
consignee_addr  string comment '收件地址',
inc_day string  
)
comment '运单寄件'
PARTITIONED BY (
run_day string COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 收件运单
create table dm_gis_oms.tmp_bryc_order_consignee_all_bak(
tel string,
apply_date string,
consignor_mobile string,
consignor_cont_name string,
consignee_mobile string,
consignee_cont_name string,
consigned_tm string,
src_dist_code string,
signin_tm string,
dest_dist_code string,
consignor_comp_name string,
consignee_comp_name string,
waybill_no string,
cons_name array<string>,
freight_payment_type_code string comment '寄付/到付',
freight_settlement_type_code  string comment '现结/月结',
all_fee_rmb  string comment '运费',
service_prod_code  string comment '增值服务代码',
has_service_prod_flag  string comment '有无增值服务',
customs_batchs  string comment '报关批次',
consignor_addr  string comment '寄件地址',
consignee_addr  string comment '收件地址',
inc_day string  
)
comment '运单收件'
PARTITIONED BY (
run_day string COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


insert into dm_gis_oms.tmp_bryc_order_consignor_all_bak partition(run_day='')
select 
tel,
apply_date,
consignor_mobile,
consignor_cont_name,
consignee_mobile,
consignee_cont_name,
consigned_tm,
src_dist_code,
signin_tm,
dest_dist_code,
consignor_comp_name,
consignee_comp_name,
waybill_no,
cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
customs_batchs,
consignor_addr,
consignee_addr,
inc_day   
from dm_gis_oms.tmp_bryc_order_consignor_all_1217
;

insert into dm_gis_oms.tmp_bryc_order_consignee_all_bak partition(run_day='')
select 
tel,
apply_date,
consignor_mobile,
consignor_cont_name,
consignee_mobile,
consignee_cont_name,
consigned_tm,
src_dist_code,
signin_tm,
dest_dist_code,
consignor_comp_name,
consignee_comp_name,
waybill_no,
cons_name,
freight_payment_type_code,
freight_settlement_type_code,
all_fee_rmb,
service_prod_code,
has_service_prod_flag,
customs_batchs,
consignor_addr,
consignee_addr,
inc_day 
from dm_gis_oms.tmp_bryc_order_consignee_all_1217
;



-- 特征开发（多人开发，在其他文件）


-- 特征数据导出（新创建txtfile表，通过ftp导出来）
--

hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;
set mapreduce.output.fileoutputformat.compress=false;

create table dm_gis_oms.tmp_bryc_consignor_feature_0130 stored as textfile as
select * from dm_gis.dws_bryc_consignor_feature ;

create table dm_gis_oms.tmp_bryc_consignee_feature_0130 stored as textfile as
select * from dm_gis.dws_bryc_consignee_feature ;
"

rm -f ./000000_0
hdfs dfs -get hdfs://sfbd/hive/warehouse/ft/DM/dm_gis_oms/tmp_bryc_consignor_feature_0130/000000_0 ./
curl ftp://gis:L1iwM21xYF@10.116.49.190/01416344/000000_0_jj -T 000000_0

rm -f ./000000_0
hdfs dfs -get hdfs://sfbd/hive/warehouse/ft/DM/dm_gis_oms/tmp_bryc_consignee_feature_0130/000000_0 ./
curl ftp://gis:L1iwM21xYF@10.116.49.190/01416344/000000_0_sj -T 000000_0