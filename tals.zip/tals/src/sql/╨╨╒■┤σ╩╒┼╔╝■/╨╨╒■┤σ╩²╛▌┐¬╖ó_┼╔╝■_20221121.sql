-- 行政村收派件1.7版本 --

---- 数据准备 ----
-- 派件收件共用的

-- 小哥轨迹
drop table if exists dm_gis.tmp_village_henan_esg_gis_1006;
create table  dm_gis.tmp_village_henan_esg_gis_1006  as 
select un,inc_day,tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20221006'
;

-- 网点站点数据 dim.dim_department_hist  (20230306修改 dim.dim_dept_info_df)
drop table if exists dm_gis.tmp_village_henan_department_1006;
create table dm_gis.tmp_village_henan_department_1006  as 
select dept_code,area_name,dept_name,longitude,latitude 
from (
select dept_code,area_name,dept_name,longitude,latitude,row_number() over(partition by dept_code order by inc_day desc)  as rn 
from (select area_name,dept_code,dept_name,longitude,latitude,inc_day  
from dim.dim_dept_info_df where inc_day='20221006' ) as a 
) as b where b.rn=1
;


-- 订单类型 dwd.dwd_pd_order_timely_repond_dtl_di
drop table if exists dm_gis.tmp_village_henan_order_type_1006;
create table dm_gis.tmp_village_henan_order_type_1006 as 
select waybill_no,inc_day,order_type_desc  from dwd.dwd_pd_order_timely_repond_dtl_di where inc_day='20221006' and waybill_no<>'' 
;


-- 网点类型
drop table if exists dm_gis.tmp_village_henan_business_model_1006;
create table  dm_gis.tmp_village_henan_business_model_1006 as 
select prov_name,dist_name,prefecture_name,town_street_name,business_model 
from dm_nrps.app_tm_dept_opera_coverage_detail 
where inc_day=regexp_replace(date_sub(from_unixtime(unix_timestamp('202210','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),1),'-','') 
and town_street_name<>''
;

-- 行政村多边形
-- st_asewkt,x,y,ogc_fid,guid,area_code,name,class_code,name_p,adcode_p,name_c,adcode_c,name_d,adcode_d,name_t,adcode_t
-- st_asewkt改成wkt
-- wkt,x,y,ogc_fid,guid,area_code,name,class_code,name_p,adcode_p,name_c,adcode_c,name_d,adcode_d,name_t,adcode_t
create table dm_gis_oms.tmp_henan_zhoukou_village220(
wkt string,
x string,
y string,
ogc_fid string,
guid string,
area_code string,
name string,
class_code string,
name_p string,
adcode_p string,
name_c string,
adcode_c string,
name_d string,
adcode_d string,
name_t string,
adcode_t string 
) 
comment '行政村多边形' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES
("separatorChar"=",")
STORED AS TEXTFILE
tblproperties("skip.header.line.count"="1");

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/village_henan_1130.csv' OVERWRITE INTO TABLE dm_gis_oms.tmp_henan_zhoukou_village220;

-- dm_gis.tmp_henan_df_sywlfg_0908


-- 派件运单
-- dm_gis.tt_waybill_hook  派件
-- waybill_id,waybill_no,inc_day,dest_city_code,signin_tm,dest_hq_code,dest_area_code,dest_zone_code,deliver_emp_code,real_product_code,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,dest_county,consignee_addr,dest_dist_code,consignee_mobile,consignee_phone,consignee_comp_name,consignee_cont_name,cons_name
drop table if exists dm_gis.tmp_henan_tt_waybill_hook_1006;
create table dm_gis.tmp_henan_tt_waybill_hook_1006  as 
select waybill_id,waybill_no,inc_day,dest_city_code,signin_tm,dest_hq_code,dest_area_code,dest_zone_code,deliver_emp_code,real_product_code,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,dest_county,consignee_addr,dest_dist_code,consignee_mobile,consignee_phone,consignee_comp_name,consignee_cont_name,cons_name  
from dm_gis.tt_waybill_hook where inc_day='20221006' and  dest_area_code='371Y'
;
--  dest_zone_code in ('394DLD172','394DLD114','394DLD089','394DLD129','394DLD125','394DLD149','394DLD080','394DLD171','394DLD090','394DLD095','394DLD121','394DLD073','394DLD103','394DLD069','394DLD075','394DLD079','394DLD152','394DLD074','394DLD137','394DLD161')
--  ;
 

-- 地址解析行政村     VillageAddrHenanVillageApp   waybill_no,yd_county,yd_addr,citycode,inc_day
-- shell
int_sql="select waybill_no,dest_county as yd_county,consignee_addr as yd_addr,dest_dist_code as city_code,inc_day  from  dm_gis.tmp_henan_tt_waybill_hook_1006 "
out_table="dm_gis.tmp_henan_dest_addr_village220_1006"
mainClass="com.sf.gis.scala.tals.app.VillageAddrHenanVillageApp"

spark-submit \
--master yarn \
--queue gis \
--driver-memory 4g \
--num-executors 5 \
--executor-memory 3g \
--executor-cores 6 \
--conf spark.sql.shuffle.partitions=300 \
--class $mainClass $mainJar '$int_sql' '$out_table'

--curl  -v  -XPOST -H 'Content-Type:application/json' -H 'ak:8bb09e5e110845f39a000391668e3e80'  http://gis-gw.intsit.sfdc.com.cn:9080/village/api -d  ' {'address' : '河南省周口市沈丘县冯营乡冯营村委会','cityCode':'394'} '
--curl  -v  -XPOST -H 'Content-Type:application/json' -H 'ak:5686a2aca02e42c9807158558446a455'  http://gis-gw.int.sfdc.com.cn:9080/village/api -d  ' {'address' : '河南省周口市沈丘县冯营乡冯营村委会','cityCode':'394'} '




-- 行政村 res
drop table if exists dm_gis.tmp_henan_dest_villres_1006;
create table dm_gis.tmp_henan_dest_villres_1006 as 
select t0.waybill_id,t0.waybill_no,t0.inc_day,t0.dest_city_code,t0.signin_tm,t0.dest_hq_code,t0.dest_area_code,t0.dest_zone_code,t0.deliver_emp_code,t0.real_product_code,t0.aoi_id,t0.aoi_code,t0.aoi_name,t0.aoi_type_name,t0.dest_county,t0.consignee_addr,t0.dest_dist_code, 
province,city,county,town,vil_name,guid,vil_code,town_adcode,class_code    
from dm_gis.tmp_henan_tt_waybill_hook_1006 as t0 
left join 
(select waybill_no,inc_day,province,city,county,town,vil_name,vil_space_code as guid,vil_code,town_adcode,class_code from dm_gis.tmp_henan_dest_addr_village220_1006  where waybill_no<>'' 
group by waybill_no,inc_day,province,city,county,town,vil_name,vil_space_code,vil_code,town_adcode,class_code 
) as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day 
;


-- 是否进村派件
-- 小哥收派件轨迹匹配当前的行政村
-- （1.7开始按ods_yjy.yjy_mailno_kb这个表加，后面取消了）
-- -- ods_yjy.yjy_mailno_kb 的 order_state=‘已出库’
-- drop table if exists dm_gis.tmp_henan_dest_villres_a_1006;
-- create table dm_gis.tmp_henan_dest_villres_a_1006 as 
-- select t0.waybill_no,t0.inc_day,signin_tm,deliver_emp_code,guid,class_code 
-- from  (select waybill_no,inc_day,signin_tm,deliver_emp_code,guid,class_code from dm_gis.tmp_henan_dest_villres_1006 where class_code='220') as t0 
-- left join 
-- (select mailno,inc_day from ods_yjy.yjy_mailno_kb where inc_day='20221006' and order_state='已出库') as t1 
-- on t0.waybill_no=t1.mailno and t0.inc_day=t1.inc_day
-- where t1.mailno is not null 
-- ;

-- -- 不命中的网下走
-- drop table if exists dm_gis.tmp_henan_dest_villres_b_1006;
-- create table dm_gis.tmp_henan_dest_villres_b_1006 as 
-- select t0.waybill_no,t0.inc_day,signin_tm,deliver_emp_code,guid,class_code from  dm_gis.tmp_henan_dest_villres_1006 as t0 
-- left join (select waybill_no,inc_day from  dm_gis.tmp_henan_dest_villres_a_1006) as t1 
-- on t0.waybill_no=t1.waybill_no 
-- where t1.waybill_no is not null
-- ;

-- -- 小哥轨迹
-- drop table if exists dm_gis.tmp_village_henan_esg_gis_1006;
-- create table  dm_gis.tmp_village_henan_esg_gis_1006  as 
-- select un,inc_day,tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20221006'
-- ;

----  小哥收派件轨迹匹配当前的行政村（满足class_code='220'的）
----  时间范围
drop table if exists dm_gis.tmp_village_henan_dest_sfjc_1006;
create table dm_gis.tmp_village_henan_dest_sfjc_1006  as 
select 
waybill_no,inc_day,signin_tm,deliver_emp_code,guid,
tm,zx,zy 
from (
select 
t0.waybill_no,t0.inc_day,signin_tm,t0.deliver_emp_code,guid,
tm,zx,zy 
from (
select un,inc_day,cast(tm as int) as tm,zx,zy 
from dm_gis.tmp_village_henan_esg_gis_1006 
where  un is not null and un<>'' 
and zx is not null and zx<>'' 
and zy is not null and zy<>'') as t1 
left join (
select waybill_no,inc_day,unix_timestamp(signin_tm) as signin_tm,deliver_emp_code,guid 
from dm_gis.tmp_henan_dest_villres_1006   
where class_code='220' and deliver_emp_code<>'' and guid<>'' and signin_tm<>''  ) as t0  
on  t0.deliver_emp_code=t1.un and t0.inc_day=t1.inc_day
where  t0.deliver_emp_code is not null 
) as t 
where  signin_tm-60*5<=tm and signin_tm+60*30>=tm
;


---- 挂上多边形wkt
drop table if exists dm_gis.tmp_village_henan_dest_sfjc_1006a;
create table dm_gis.tmp_village_henan_dest_sfjc_1006a  as 
select 
t0.waybill_no,t0.inc_day,t0.signin_tm,t0.deliver_emp_code,t0.guid,
t0.tm,t0.zx,t0.zy, 
ta.wkt
from  dm_gis.tmp_village_henan_dest_sfjc_1006  as t0 
left join ( select guid,wkt from dm_gis_oms.tmp_henan_zhoukou_village220 where wkt!='wkt' ) as ta 
on t0.guid=ta.guid 
;


---- 作为spark的待处理数据 spark类  VillageHenanXiaoGeGuiJi1006App  （ isin_village大于0表示小哥有上门 ）
--   
int_sql="select waybill_no,inc_day,signin_tm,deliver_emp_code,tm,zx,zy,guid,wkt from dm_gis.tmp_village_henan_dest_sfjc_1006a where wkt is not null"
out_table="dm_gis.tmp_village_henan_dest_sfjc_1006a_isinvillage"    
mainClass="com.sf.gis.scala.tals.app.VillageHenanXiaoGeGuiJi1006App"



-- 是否进乡镇上门
---- 行政村类型为220或判断的进村派件为是的
drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_no1_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_no1_1006 as 
select waybill_no,inc_day from (
select waybill_no,inc_day from dm_gis.tmp_henan_dest_villres_1006 where class_code='220' 
union all 
select waybill_no,inc_day from dm_gis.tmp_village_henan_dest_sfjc_1006a_isinvillage where isin_village>0 
) as t 
group by waybill_no,inc_day
;

drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_tmp_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_tmp_1006 as 
select t0.waybill_no,t0.inc_day,signin_tm,deliver_emp_code,guid,aoi_id,aoi_code 
from (select waybill_no,inc_day,signin_tm,deliver_emp_code,guid,aoi_id,aoi_code from dm_gis.tmp_henan_dest_villres_1006  where deliver_emp_code<>'' and signin_tm<>'' ) as t0 
left join dm_gis.tmp_village_henan_dest_sfjxz_no1_1006 as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day
where t1.waybill_no is null
;

drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_tmp1_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_tmp1_1006  as 
select 
waybill_no,inc_day,signin_tm,deliver_emp_code,guid,aoi_id,aoi_code,
tm,zx,zy 
from (
select t0.waybill_no,t0.inc_day,signin_tm,t0.deliver_emp_code,guid,aoi_id,aoi_code, 
tm,zx,zy 
from (
select un,inc_day,cast(tm as int) as tm,zx,zy 
from dm_gis.tmp_village_henan_esg_gis_1006 
where  un is not null and un<>'' 
and zx is not null and zx<>'' 
and zy is not null and zy<>'') as t1 
left join 
(
select waybill_no,inc_day,unix_timestamp(signin_tm) as signin_tm,deliver_emp_code,guid,aoi_id,aoi_code  
from dm_gis.tmp_village_henan_dest_sfjxz_tmp_1006   
where deliver_emp_code<>'' and signin_tm<>''  ) as t0
on  t0.deliver_emp_code=t1.un and t0.inc_day=t1.inc_day 
where t0.deliver_emp_code is not null 
) as t 
where  signin_tm-60*5<=tm and signin_tm+60*30>=tm
;

-- -- 处理经纬坐标以减少计算量  
-- drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006;
-- create table dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006 as   
-- select 
-- waybill_no,inc_day,aoi_id,aoi_code,round(zx,4) as zx,round(zy,4) as zy 
-- from  dm_gis.tmp_village_henan_dest_sfjxz_tmp1_1006  
-- group by  waybill_no,inc_day,aoi_id,aoi_code,zx,zy 
-- ;

-- 处理经纬坐标以减少计算量  20221219修改  取最近的一个
drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006 as  
select waybill_no,inc_day,aoi_id,aoi_code,zx,zy 
from (
select 
waybill_no,inc_day,aoi_id,aoi_code,zx,zy,
row_number() over(partition by waybill_no,inc_day order by diff_tm asc) as rn 
from ( 
select 
waybill_no,inc_day,aoi_id,aoi_code,zx,zy,abs(signin_tm-tm) as diff_tm   
from  dm_gis.tmp_village_henan_dest_sfjxz_tmp1_1006  
) as t  ) as t0 where t0.rn=1 
;



-- 是否进乡镇上门 作为spark的待处理数据 spark类  VillageHenanXiaoGeGuiJi200mDest1006App （ match_res大于1表示小哥有上门 ）
-- 
int_sql="select aoi_code,zx,zy from dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006 where aoi_code<>'' group by aoi_code,zx,zy"
out_table="dm_gis.tmp_village_henan_dest_sfjxz_1006a_isintown"    
mainClass="com.sf.gis.scala.tals.app.VillageHenanXiaoGeGuiJi200mDest1006App"



-- 还原判断是否进乡镇
drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_no2_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_no2_1006 as 
select waybill_no,inc_day,sum(match_res) as sum_match_res 
from (select waybill_no,inc_day,t1.match_res  
from dm_gis.tmp_village_henan_dest_sfjxz_1006a_isintown as t1 
left join dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006 as t0 
on t0.aoi_code=t1.aoi_code and  t0.zx=t1.lgt and t0.zy=t1.lat 
) as t 
group by waybill_no,inc_day 
;

drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_res_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_res_1006 as 
select t0.waybill_no,t0.inc_day,
case when  t1.waybill_no is not null or t2.sum_match_res=0 then '否' 
when t2.sum_match_res>0 then '是' 
else '未知' end as isin_town 
from dm_gis.tmp_henan_dest_villres_1006 as t0 
left join dm_gis.tmp_village_henan_dest_sfjxz_no1_1006 as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day 
left join dm_gis.tmp_village_henan_dest_sfjxz_no2_1006 as t2 
on t0.waybill_no=t2.waybill_no and t0.inc_day=t2.inc_day 
;


-- -- 网点站点数据 dim.dim_department_hist
-- drop table if exists dm_gis.tmp_village_henan_department_1006;
-- create table dm_gis.tmp_village_henan_department_1006  as 
-- select dept_code,area_name,dept_name,longitude,latitude 
-- from (
-- select dept_code,area_name,dept_name,longitude,latitude,row_number() over(partition by dept_code order by inc_day desc)  as rn 
-- from (select area_name,dept_code,dept_name,longitude,latitude,inc_day  
-- from dim.dim_department_hist where inc_day='20221006' ) as a 
-- ) as b where b.rn=1
-- ;


-- -- 订单类型 dwd.dwd_pd_order_timely_repond_dtl_di
-- drop table if exists dm_gis.tmp_village_henan_order_type_1006;
-- create table dm_gis.tmp_village_henan_order_type_1006 as 
-- select waybill_no,inc_day,order_type_desc  from dwd.dwd_pd_order_timely_repond_dtl_di where inc_day='20221006' and waybill_no<>'' 
-- ;



------- 派件数据大整合 ------
drop table if exists dm_gis.tmp_village_henan_dest_matchall_res_1006_1;
create table dm_gis.tmp_village_henan_dest_matchall_res_1006_1 as 
select 
t0.waybill_id,t0.waybill_no,t0.inc_day,t0.dest_city_code,t0.signin_tm,t0.dest_hq_code,t0.dest_area_code,t0.dest_zone_code,t0.deliver_emp_code,t0.real_product_code,t0.aoi_id,t0.aoi_code,t0.aoi_name,t0.aoi_type_name,t0.dest_county,t0.consignee_addr,t0.dest_dist_code,   
t01.province,t01.city,t01.county,t01.town,t01.vil_name,t01.guid,t01.vil_code,t01.town_adcode,t01.class_code,
t1.area_name,t1.dept_name,
t2.order_type_desc,
t4.aoi_area_code,
t6.isin_village,
t7.isin_town 
from dm_gis.tmp_henan_tt_waybill_hook_1006 as t0 
left join dm_gis.tmp_henan_dest_villres_1006 as t01 
on t0.waybill_no=t01.waybill_no and t0.inc_day=t01.inc_day 
left join  dm_gis.tmp_village_henan_department_1006 as t1 
on t0.dest_zone_code=t1.dept_code 
left join dm_gis.tmp_village_henan_order_type_1006 as t2 
on t0.waybill_no=t2.waybill_no and t0.inc_day=t2.inc_day 
left join dm_tc_waybillinfo.aoi_area_aoi as t4 
on t0.aoi_code=t4.aoi_id 
left join (select waybill_no,inc_day,isin_village from dm_gis.tmp_village_henan_dest_sfjc_1006a_isinvillage where isin_village>0 ) as t6 
on t0.waybill_no=t6.waybill_no and t0.inc_day=t6.inc_day 
left join dm_gis.tmp_village_henan_dest_sfjxz_res_1006 as t7 
on t0.waybill_no=t7.waybill_no and t0.inc_day=t7.inc_day 
;

drop table if exists dm_gis.tmp_village_henan_dest_matchall_res_1006_2;
create table dm_gis.tmp_village_henan_dest_matchall_res_1006_2 as 
select 
waybill_id,waybill_no,inc_day,dest_city_code,signin_tm,dest_hq_code,dest_area_code,
dest_zone_code,area_name,dept_name,order_type_desc,
deliver_emp_code,real_product_code,
aoi_id,aoi_code,aoi_name,aoi_type_name,aoi_area_code,dest_county,consignee_addr,dest_dist_code,
province,city,county,town,vil_name,guid,vil_code,town_adcode,class_code,
case when class_code='220' or isin_village>0 then '否' else '是' end as  is_xz,
case when isin_village>0  then '是' else '否' end as is_jcpj,
isin_town as is_jxzpj 
from dm_gis.tmp_village_henan_dest_matchall_res_1006_1
;



---- 计算距离 ----
drop table if exists dm_gis.tmp_village_henan_dest_aoi_dld_1006;
create table  dm_gis.tmp_village_henan_dest_aoi_dld_1006 as 
select waybill_no,inc_day,aoi_id,aoi_code,dest_zone_code as dld_code  from dm_gis.tmp_village_henan_dest_matchall_res_1006_2 
where class_code='220' and aoi_id<>'' and dest_zone_code<>''
;


-- aoi_id + 站点编码，调用接口计算距离   VillageAoi2ZcDistanceHenan1006App
int_sql="select aoi_id,dld_code from dm_gis.tmp_village_henan_dest_aoi_dld_1006 group by aoi_id,dld_code "
out_table="dm_gis.tmp_village_henan_dest_aois2zcdistance_1006"
mainClass="com.sf.gis.scala.tals.app.VillageAoi2ZcDistanceHenan1006App"


-- 取最远的
drop table if exists dm_gis.tmp_village_henan_dest_aoi_dld_res_1006;
create table dm_gis.tmp_village_henan_dest_aoi_dld_res_1006 as 
select 
waybill_no,inc_day,dld_code,car_dist,horse_dist 
from ( 
select waybill_no,inc_day,dld_code,car_dist,horse_dist,row_number() over(partition by waybill_no,inc_day order by horse_dist desc)  as rn 
from (
select 
t0.waybill_no,t0.inc_day,t0.aoi_id,t0.aoi_code,
t1.dld_code,t1.car_dist,t1.horse_dist 
from dm_gis.tmp_village_henan_dest_aoi_dld_1006 as t0 
left join (select aoi_id,dld_code,car_dist,horse_dist from dm_gis.tmp_village_henan_dest_aois2zcdistance_1006 where aoi_id is not null and aoi_id<>'') as t1 
on t0.aoi_id=t1.aoi_id and t0.dld_code=t1.dld_code 
) as a 
) as b where b.rn=1
;

-- -- 网点类型
-- drop table if exists dm_gis.tmp_village_henan_business_model_1006;
-- create table  dm_gis.tmp_village_henan_business_model_1006 as 
-- select prov_name,dist_name,prefecture_name,town_street_name,business_model 
-- from dm_nrps.app_tm_dept_opera_coverage_detail 
-- where inc_day=regexp_replace(date_sub(from_unixtime(unix_timestamp('202210','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),1),'-','') 
-- and town_street_name<>''
-- ;


-- 派件明细表（后面增加距离字段）
-- 建表
drop table if exists dm_gis.tmp_village_henan_dest_matchall_res_1006;
create table dm_gis.tmp_village_henan_dest_matchall_res_1006(
waybill_no string,
signin_tm string,
dest_hq_code string,
dest_area_code string,
dest_zone_code string,
area_name string,
dept_name string,
order_type_desc string,
deliver_emp_code string,
real_product_code string,
is_yj string,
aoi_id string,
aoi_code string,
aoi_name string,
aoi_type_name string,
aoi_area_code string,
dest_county string,
dest_dist_code string,
province string,
city string,
county string,
town string,
vil_name string,
guid string,
vil_code string,
town_adcode string,
class_code string,
is_jcpj string,
is_jxzpj string,
yd_type string,
fg_type string, 
car_dist string,
business_model string
)
COMMENT "派件行政村" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.tmp_village_henan_dest_matchall_res_1006 partition(inc_day='20221006') 
select 
t0.waybill_no,signin_tm,dest_hq_code,dest_area_code,
dest_zone_code,area_name,dept_name,order_type_desc,
deliver_emp_code,real_product_code,
t10.is_yj,
t0.aoi_id,t0.aoi_code,aoi_name,aoi_type_name,aoi_area_code,dest_county,dest_dist_code,
t0.province,t0.city,t0.county,t0.town,vil_name,guid,vil_code,town_adcode,class_code,
is_jcpj,is_jxzpj,yd_type,
t9.fg_type, 
t1.car_dist,
t11.business_model  
from 
(select 
waybill_id,waybill_no,inc_day,dest_dist_code,signin_tm,dest_hq_code,dest_area_code,
dest_zone_code,area_name,dept_name,order_type_desc,
deliver_emp_code,real_product_code,
aoi_id,aoi_code,aoi_name,aoi_type_name,aoi_area_code,dest_county,consignee_addr,dest_dist_code,
province,city,county,town,vil_name,guid,vil_code,town_adcode,class_code,
is_xz,is_jcpj,is_jxzpj,
case when (class_code='220') or (is_jcpj='是')  then '行政村' 
when (class_code!='220') and (is_jcpj!='是') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code!='220') and (is_jcpj!='是') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type 
from dm_gis.tmp_village_henan_dest_matchall_res_1006_2 
) as t0 
left join dm_gis.tmp_village_henan_dest_aoi_dld_res_1006 as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day 
left join dm_gis.tmp_henan_df_sywlfg_0908 as t9 
on t0.province=t9.province and t0.city=t9.city and t0.county=t9.county and t0.town=t9.town 
left join (select waybill_no,inc_day,consignee_comp_name,consignee_cont_name,cons_name,case when freight_monthly_acct_code<>'' then '是' else '否' end as is_yj  from dm_gis.tmp_henan_tt_waybill_hook_1006 ) as t10 
on t0.waybill_no=t10.waybill_no and t0.inc_day=t10.inc_day 
left join  dm_gis.tmp_village_henan_business_model_1006 as t11 
on t0.province=t11.prov_name and t0.city=t11.dist_name and t0.county=t11.prefecture_name and t0.town=t11.town_street_name 
group by 
t0.waybill_no,signin_tm,dest_hq_code,dest_area_code,
dest_zone_code,area_name,dept_name,order_type_desc,
deliver_emp_code,real_product_code,
t10.is_yj,
t0.aoi_id,t0.aoi_code,aoi_name,aoi_type_name,aoi_area_code,dest_county,dest_dist_code,
t0.province,t0.city,t0.county,t0.town,vil_name,guid,vil_code,town_adcode,class_code,
is_jcpj,is_jxzpj,yd_type,
t9.fg_type, 
t1.car_dist,
t11.business_model   
;


alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column waybill_no waybill_no string comment '运单号';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column signin_tm signin_tm string comment '收件时间';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column dest_hq_code dest_hq_code string comment '大区代码';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column dest_area_code dest_area_code string comment '地区代码';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column dest_zone_code dest_zone_code string comment '网点代码';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column area_name area_name string comment '地区名称';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column dept_name dept_name string comment '网点名称';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column order_type_desc order_type_desc string comment '订单类型';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column deliver_emp_code deliver_emp_code string comment '派件员';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column real_product_code real_product_code string comment '产品名称';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column is_yj is_yj string comment '是否月结';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column aoi_id aoi_id string comment 'AOI ID';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column aoi_code aoi_code string comment 'AOI编码';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column aoi_name aoi_name string comment 'AOI名称';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column aoi_type_name aoi_type_name string comment 'AOI类型名称';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column aoi_area_code aoi_area_code string comment 'AOI区域';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column dest_county dest_county string comment '区/县/镇';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column dest_dist_code dest_dist_code string comment '城市代码';
province string,
city string,
county string,
town string,
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column  vil_name vil_name string comment '行政村';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column  guid  guid string comment '行政村唯一标识';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column vil_code vil_code string comment '村code';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column town_adcode town_adcode string  comment '镇code';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column class_code class_code string  comment '类型';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column is_jcpj is_jcpj string  comment '是否进村派件';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column is_jxzpj is_jxzpj string  comment '是否进乡镇派件';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column yd_type yd_type string  comment '运单类型';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column fg_type fg_type string  comment '速运网络覆盖'; 
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column car_dist car_dist string  comment '地址到网点距离';
alter table dm_gis.tmp_village_henan_dest_matchall_res_1006 change column business_model business_model string  comment '网点类型';


-- 网点、镇、村统计件量
drop table if exists dm_gis.tmp_village_henan_zone_stat;
create table dm_gis.tmp_village_henan_zone_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "网点统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table if exists dm_gis.tmp_village_henan_town_stat;
create table dm_gis.tmp_village_henan_town_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
town string comment '乡镇名称',
town_adcode string comment '乡镇code',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "乡镇统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 20230202需求增加class_code,yd_type字段
drop table if exists dm_gis.tmp_village_henan_vil_stat;
create table dm_gis.tmp_village_henan_vil_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
town string comment '乡镇名称',
town_adcode string comment '乡镇code',
vil_name string comment '村名称',
vil_code string comment '村code',
class_code string comment 'class_code',
yd_type string comment 'yd_type',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "村统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

ALTER TABLE dm_gis.tmp_village_henan_vil_stat RENAME TO dm_gis.tmp_village_henan_vil_stat_0206;


-- 
drop table if exists dm_gis.tmp_village_henan_vil_stat_dest;
create table dm_gis.tmp_village_henan_vil_stat_dest as 
select 
dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,class_code,
yd_type,  
count(1) as dest_cnt 
from 
(select 
dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,
yd_type  
from dm_gis.tmp_village_henan_dest_matchall_res_1006 
where inc_day='20230115' and dest_area_code<>'' and city<>'' and dest_zone_code<>''  )as t 
group by dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,class_code,
yd_type 
;

drop table if exists dm_gis.tmp_village_henan_vil_stat_src;
create table dm_gis.tmp_village_henan_vil_stat_src as 
select 
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,
yd_type,
count(1) as src_cnt 
from 
(select 
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,
yd_type  
from dm_gis.tmp_village_henan_src_matchall_res_1006 
where inc_day='20230115' and src_area_code<>'' and city<>'' and source_zone_code<>'' )as t 
group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,
yd_type  
;

insert overwrite table dm_gis.tmp_village_henan_vil_stat partition(inc_day='20221006')
select 
if(t0.area_code is not null,t0.area_code,t1.area_code) as area_code,
if(t0.dist_code is not null,t0.dist_code,t1.dist_code) as dist_code,
if(t0.city is not null,t0.city,t1.city) as city,
if(t0.zone_code is not null,t0.zone_code,t1.zone_code) as zone_code,
if(t0.town is not null,t0.town,t1.town) as town,
if(t0.town_adcode is not null,t0.town_adcode,t1.town_adcode) as town_adcode,
if(t0.vil_name is not null,t0.vil_name,t1.vil_name) as vil_name,
if(t0.vil_code is not null,t0.vil_code,t1.vil_code) as vil_code,
if(t0.class_code is not null,t0.class_code,t1.class_code) as class_code,
if(t0.yd_type is not null,t0.yd_type,t1.yd_type) as yd_type,
if(t0.dest_cnt is not null,t0.dest_cnt,0 ) as dest_cnt,
if(t1.src_cnt is not null,t1.src_cnt,0 ) as src_cnt 
from 
(
select dest_area_code as area_code,dest_dist_code as dist_code,city,dest_zone_code as zone_code,town,town_adcode,vil_name,vil_code,class_code,yd_type,dest_cnt 
from dm_gis.tmp_village_henan_vil_stat_dest ) as t0
full outer join 
(
select src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,class_code,yd_type,src_cnt 
from dm_gis.tmp_village_henan_vil_stat_src 
) as t1  
on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code 
and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code 
;

insert overwrite table dm_gis.tmp_village_henan_town_stat partition(inc_day='20221006') 
select 
area_code,dist_code,city,zone_code,town,town_adcode,
sum(dest_cnt)  as dest_cnt,
sum(src_cnt)  as src_cnt 
from dm_gis.tmp_village_henan_vil_stat 
where inc_day='20221006' 
group by 
area_code,dist_code,city,zone_code,town,town_adcode
;

insert overwrite table dm_gis.tmp_village_henan_zone_stat partition(inc_day='20221006') 
select 
area_code,dist_code,city,zone_code,
sum(dest_cnt)  as dest_cnt,
sum(src_cnt)  as src_cnt 
from dm_gis.tmp_village_henan_vil_stat 
where inc_day='20221006' 
group by 
area_code,dist_code,city,zone_code
;


