-- 建表
CREATE TABLE `dm_gis.village_log_flink`(
`log` string
)
COMMENT '行政村接口日志' 
PARTITIONED BY (
`inc_day` string)
ROW FORMAT SERDE
'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe'
WITH SERDEPROPERTIES (
'field.delim'='\t',
'line.delim'='\n',
'serialization.format'='\t')
STORED AS INPUTFORMAT
'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT
'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
;


-- 实时任务  GIS_RSS_SEG_VILLAGE_TO_HIVE

-- 将实时同步的数据加载到分区
-- hive -e "alter table dm_gis.village_log_flink add partition (inc_day='$pt') location 'hdfs://sfbd/user/hive/warehouse/dm_gis.db/village_log_flink/$pt'"

-- 数据解析 ()
drop table if exists dm_gis.village_log_flink_tmp ;
create table dm_gis.village_log_flink_tmp as 
select get_json_object(get_json_object(log,'$.message'),'$.param') as param,get_json_object(get_json_object(log,'$.message'),'$.data')  as data from dm_gis.village_log_flink where inc_day='20230110' and 
get_json_object(get_json_object(log,'$.message'),'$.data') is not null 
;

-- 
create table dm_gis.village_log_flink_res(
p_address string comment '地址',
p_city_code string comment '城市代码',
p_waybill_no string comment '运单号',
p_sys_code string comment '系统编码',
p_aoiid string comment 'aoiid',
p_at_aoi_src	string comment 'aoi来源',
p_aoi_code	string comment 'aoiCode',	
p_dept_code	string comment '网点'	,
p_group_id	string comment '大组id'	,
p_split_result	string	comment '分词结果',	
p_standardization	string	comment '标准化',	
p_geo_x	string	comment 'Geo返回的经度'	,
p_geo_y	string	comment 'Geo返回的纬度'	,
r_province	string	comment '省',
r_city	string	comment '市',
r_county	string	comment '区县',
r_town	string	comment '街道、镇',
r_src	string	comment '数据来源',
r_x	string	comment '经度',
r_y	string	comment '纬度',
r_vilname	string	comment '行政村名称',
r_vil_space_code	string	comment '行政村空间匹配编码',
r_class_code	string	comment '城乡分类代码',
r_aoiid	string	comment 'aoiId',
r_vilcode	string	comment '行政村adcode',
r_town_adcode	string	comment '镇adcode',
r_geo_x	string	comment 'Geo返回的经度',
r_geo_y	string	comment 'Geo返回的纬度',
r_group_id	string	comment '大组id',
r_split_result	string	comment '分词结果',
r_standardization	string	comment '标准化',
r_at_aoi_src	string	comment 'AOI来源',
r_town_x	string	comment '乡镇经度',
r_town_y	string	comment '乡镇纬度',
r_distance	string	comment '距离',
r_aoi_code	string	comment 'aoiCode',
r_dept_code	string	comment '网点',
r_filter	string	comment '',
r_level	string	comment '',
r_msg string	comment 'status为1时的msg',
r_status string	comment ''
) 
COMMENT '乡村达日志'
PARTITIONED BY (`inc_day` string COMMENT '分区月份') 
stored as parquet 
tblproperties ('parquet.compression'='snappy')
;

-- 跑数
insert overwrite table dm_gis.village_log_flink_res partition(inc_day='')
select 
get_json_object(param,'$.address') as p_address,
get_json_object(param,'$.cityCode') as p_city_code,
get_json_object(param,'$.waybillNo') as p_waybill_no,
get_json_object(param,'$.sysCode') as p_sys_code,
get_json_object(param,'$.aoiid') as p_aoiid,
get_json_object(param,'$.atAoiSrc') as p_at_aoi_src,
get_json_object(param,'$.aoiCode') as p_aoi_code,
get_json_object(param,'$.deptCode') as p_dept_code,
get_json_object(param,'$.groupId') as p_group_id,
get_json_object(param,'$.splitResult') as p_split_result,
get_json_object(param,'$.standardization') as p_standardization,
get_json_object(param,'$.geoX') as p_geo_x,
get_json_object(param,'$.geoY') as p_geo_y,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.province'),null) as r_province,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.city'),null) as r_city,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.county'),null) as r_county,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.town'),null) as r_town,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.src'),null) as r_src,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.x'),null) as r_x,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.y'),null) as r_y,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.vilName'),null) as r_vilname,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.vilSpaceCode'),null) as r_vil_space_code,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.classCode'),null) as r_class_code,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.aoiId'),null) as r_aoiid,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.vilcode'),null) as r_vilcode,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.townAdcode'),null) as r_town_adcode,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.geoX'),null) as r_geo_x,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.geoY'),null) as r_geo_y,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.groupId'),null) as r_group_id,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.splitResult'),null) as r_split_result,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.standardization'),null) as r_standardization,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.atAoisrc'),null) as r_at_aoi_src,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.townX'),null) as r_town_x,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.townY'),null) as r_town_y,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.distance'),null) as r_distance,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.aoiCode'),null) as r_aoi_code,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.deptCode'),null) as r_dept_code,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.filter'),null) as r_filter,
if (get_json_object(data,'$.status')=0,get_json_object(get_json_object(get_json_object(data,'$.result'),'$.data'),'$.level'),null) as r_level,
if (get_json_object(data,'$.status')=1,get_json_object(get_json_object(data,'$.result'),'$.msg'),null) as r_msg,
get_json_object(data,'$.status') as r_status 
from dm_gis.village_log_flink_tmp  
;