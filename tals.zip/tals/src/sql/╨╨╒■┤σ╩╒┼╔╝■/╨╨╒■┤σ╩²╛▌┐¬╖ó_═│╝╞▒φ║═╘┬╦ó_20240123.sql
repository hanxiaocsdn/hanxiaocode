--
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- @author 张小琼 （01416344）
-- Created on 2023-12-06
-- 任务信息： ID:926185  行政村收派件_new(基于dwd_waybill_info_dtl_di)
--

-----------------------------------------------------------------------------------------------------------------------------------
-- 统计表开发
-----------------------------------------------------------------------------------------------------------------------------------

-- --------------------------------------
-- 前提：派件和收件明细表都有了
-- 网点、镇、村统计件量

create table dm_gis.village_kdsm_zone_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "网点统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


create table dm_gis.village_kdsm_town_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
town string comment '乡镇名称',
town_adcode string comment '乡镇code',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "乡镇统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


create table dm_gis.village_kdsm_vil_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
town string comment '乡镇名称',
town_adcode string comment '乡镇code',
vil_name string comment '村名称',
vil_code string comment '村code',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "村统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- -- 
-- drop table if exists dm_gis.tmp_village_kdsm_vil_stat_dest;
-- create table dm_gis.tmp_village_kdsm_vil_stat_dest as 
-- select 
-- dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,
-- count(1) as dest_cnt 
-- from 
-- (select 
-- dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,waybill_no  
-- from dm_gis.village_dest_kdsm_res 
-- where inc_day='$firstDay' and dest_area_code<>'' and city<>'' and dest_zone_code<>''  )as t 
-- group by dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code 
-- ;

-- drop table if exists dm_gis.tmp_village_kdsm_vil_stat_src;
-- create table dm_gis.tmp_village_kdsm_vil_stat_src as 
-- select 
-- src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,
-- count(1) as src_cnt 
-- from 
-- (select 
-- src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no  
-- from dm_gis.village_src_kdsm_res 
-- where inc_day='$firstDay' and src_area_code<>'' and city<>'' and source_zone_code<>'' )as t 
-- group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code 
-- ;

-- insert overwrite dm_gis.village_kdsm_vil_stat partition(inc_day='$firstDay')
-- select 
-- if(t0.area_code is not null,t0.area_code,t1.area_code) as area_code,
-- if(t0.dist_code is not null,t0.dist_code,t1.dist_code) as dist_code,
-- if(t0.city is not null,t0.city,t1.city) as city,
-- if(t0.zone_code is not null,t0.zone_code,t1.zone_code) as zone_code,
-- if(t0.town is not null,t0.town,t1.town) as town,
-- if(t0.town_adcode is not null,t0.town_adcode,t1.town_adcode) as town_adcode,
-- if(t0.vil_name is not null,t0.vil_name,t1.vil_name) as vil_name,
-- if(t0.vil_code is not null,t0.vil_code,t1.vil_code) as vil_code,
-- if(t0.dest_cnt is not null,t0.dest_cnt,0 ) as dest_cnt,
-- if(t1.src_cnt is not null,t1.src_cnt,0 ) as src_cnt 
-- from 
-- (
-- select dest_area_code as area_code,dest_dist_code as dist_code,city,dest_zone_code as zone_code,town,town_adcode,vil_name,vil_code,dest_cnt 
-- from dm_gis.tmp_village_kdsm_vil_stat_dest ) as t0
-- full outer join 
-- (
-- select src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,src_cnt 
-- from dm_gis.tmp_village_kdsm_vil_stat_src 
-- ) as t1  
-- on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code 
-- and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code 
-- ;

--  20230331 
-- dm_gis.village_kdsm_vil_stat新增四个字段含义：
-- 城乡分类代码：class_code
-- 是否妥投驿站：is_ttyz
-- 进村派件量：dest_jcpj_cnt
-- 进村收件量：src_jcpj_cnt
-- 
alter table dm_gis.village_kdsm_vil_stat add columns (class_code string COMMENT '城乡分类代码');
alter table dm_gis.village_kdsm_vil_stat add columns (is_ttyz string COMMENT '是否妥投驿站');
alter table dm_gis.village_kdsm_vil_stat add columns (dest_jcpj_cnt string COMMENT '进村派件量');
alter table dm_gis.village_kdsm_vil_stat add columns (src_jcpj_cnt string COMMENT '进村收件量');

ALTER TABLE dm_gis.village_kdsm_vil_stat CHANGE COLUMN src_jcpj_cnt src_jcpj_cnt STRING COMMENT '进村收件量';

-- 20230418
-- dm_gis.village_kdsm_vil_stat 新增两个字段
-- 折前收入：all_fee_rmb
-- 折后收入：tt_fee_zh_all_fee
alter table dm_gis.village_kdsm_vil_stat add columns (all_fee_rmb string COMMENT '折前收入');
alter table dm_gis.village_kdsm_vil_stat add columns (tt_fee_zh_all_fee string COMMENT '折后收入');


drop table if exists dm_gis.tmp_village_kdsm_vil_stat_dest;
create table dm_gis.tmp_village_kdsm_vil_stat_dest stored as parquet as
select
dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz,
count(1) as dest_cnt,sum(is_jcpj) as dest_jcpj_cnt
from
(select
dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,if(own_code is not null,'是','否') is_ttyz,is_jcpj
from dm_gis.village_dest_kdsm_res
where inc_day='$firstDay' and dest_area_code<>'' and city<>'' and dest_zone_code<>'' )as t
group by dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz
;

drop table if exists dm_gis.tmp_village_kdsm_vil_stat_src;
create table dm_gis.tmp_village_kdsm_vil_stat_src stored as parquet as
select
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz,
count(1) as src_cnt,sum(is_jcpj) as src_jcpj_cnt,sum(all_fee_rmb) as all_fee_rmb,sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from
(select
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,if(own_code is not null,'是','否') is_ttyz,is_jcpj,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.village_src_kdsm_res
where inc_day='$firstDay' and src_area_code<>'' and city<>'' and source_zone_code<>'' ) as t
group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz
;

insert overwrite dm_gis.village_kdsm_vil_stat partition(inc_day='$firstDay')
select
if(t0.area_code is not null,t0.area_code,t1.area_code) as area_code,
if(t0.dist_code is not null,t0.dist_code,t1.dist_code) as dist_code,
if(t0.city is not null,t0.city,t1.city) as city,
if(t0.zone_code is not null,t0.zone_code,t1.zone_code) as zone_code,
if(t0.town is not null,t0.town,t1.town) as town,
if(t0.town_adcode is not null,t0.town_adcode,t1.town_adcode) as town_adcode,
if(t0.vil_name is not null,t0.vil_name,t1.vil_name) as vil_name,
if(t0.vil_code is not null,t0.vil_code,t1.vil_code) as vil_code,
if(t0.dest_cnt is not null,t0.dest_cnt,0 ) as dest_cnt,
if(t1.src_cnt is not null,t1.src_cnt,0 ) as src_cnt,

if(t0.class_code is not null,t0.class_code,t1.class_code) as class_code,
if(t0.is_ttyz is not null,t0.is_ttyz,t1.is_ttyz) as is_ttyz,
if(t0.dest_jcpj_cnt is not null,t0.dest_jcpj_cnt,0 ) as dest_jcpj_cnt,
if(t1.src_jcpj_cnt is not null,t1.src_jcpj_cnt,0 ) as src_jcpj_cnt,

if(t1.all_fee_rmb is not null,t1.all_fee_rmb,0 ) as all_fee_rmb,
if(t1.tt_fee_zh_all_fee is not null,t1.tt_fee_zh_all_fee,0 ) as tt_fee_zh_all_fee  

from
(
select dest_area_code as area_code,dest_dist_code as dist_code,city,dest_zone_code as zone_code,town,town_adcode,vil_name,vil_code,dest_cnt,class_code,is_ttyz,dest_jcpj_cnt
from dm_gis.tmp_village_kdsm_vil_stat_dest ) as t0
full outer join
(
select src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,src_cnt,class_code,is_ttyz,src_jcpj_cnt,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.tmp_village_kdsm_vil_stat_src
) as t1
on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code
and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code and t0.class_code=t1.class_code and t0.is_ttyz=t1.is_ttyz
;



insert overwrite dm_gis.village_kdsm_town_stat partition(inc_day='$firstDay') 
select 
area_code,dist_code,city,zone_code,town,town_adcode,
sum(dest_cnt)  as dest_cnt,
sum(src_cnt)  as src_cnt 
from dm_gis.village_kdsm_vil_stat 
where inc_day='$firstDay' 
group by 
area_code,dist_code,city,zone_code,town,town_adcode
;

insert overwrite dm_gis.village_kdsm_zone_stat partition(inc_day='$firstDay') 
select 
area_code,dist_code,city,zone_code,
sum(dest_cnt)  as dest_cnt,
sum(src_cnt)  as src_cnt 
from dm_gis.village_kdsm_vil_stat 
where inc_day='$firstDay' 
group by 
area_code,dist_code,city,zone_code
;


drop table if exists dm_gis.tmp_village_kdsm_vil_stat_dest;
drop table if exists dm_gis.tmp_village_kdsm_vil_stat_src;

-- ------------------------------------------
-- 统计表 （20230302 增加网点类型）
-- 建表
create table dm_gis.village_kdsm_stat (
hq_code string comment '大区代码',
area_code string comment '地区代码',
area_name string comment '地区名称',
dist_code string comment '城市编码',
wd_type string comment '网点类型',
pj_all_cnt int comment '派件总量',
pj_xz_cnt int comment '派件乡镇件量',
pj_xz_sm_cnt int comment '派件乡镇上门件量',
pj_xz_sm_ratio double comment '派件乡镇上门率',
pj_xzc_cnt int comment '派件行政村件量',
pj_xzc_jc_cnt int comment '派件行政村进村件量',
pj_xzc_jc_ratio double comment '派件行政村进村率',
pj_yjc_10_cnt int comment '派件大于10km应进村件量',
pj_yjc_10_30_cnt int comment '派件10-30km应进村件量',
pj_jc_10_30_cnt int comment '派件10-30km进村件量',
pj_yjc_30_50_cnt int comment '派件30-50km应进村件量',
pj_jc_30_50_cnt int comment '派件30-50km进村件量',
pj_yjc_50_cnt int comment '派件大于50km应进村件量',
pj_jc_50_cnt int comment '派件大于50km进村件量',
pj_no_cnt int comment '派件未识别件量',
pj_no_ratio double comment '派件未识别率',
sj_all_cnt  int comment '收件总量',
sj_xz_cnt int comment '收件乡镇件量',
sj_xz_sm_cnt int comment '收件乡镇上门件量',
sj_xz_sm_ratio double comment '收件乡镇上门率',
sj_xzc_cnt int comment '收件行政村件量',
sj_xzc_jc_cnt int comment '收件行政村进村件量',
sj_xzc_jc_ratio double comment '收件行政村进村率',
sj_no_cnt  int comment '收件未识别件量',
sj_no_ratio   double comment '收件未识别率' 
)
COMMENT '行政村收派件统计表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

--派件
drop table if exists dm_gis.tmp_village_kdsm_dest_res_stat_1;
create table dm_gis.tmp_village_kdsm_dest_res_stat_1 stored as parquet as 
select 
dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type,
count(1) as pj_all_cnt,
sum(case when yd_type='乡镇' then 1 else 0 end ) as pj_xz_cnt,
sum(case when yd_type='乡镇' and is_jxzpj='是' then 1 else 0 end ) as pj_xz_sm_cnt,
sum(case when yd_type='行政村' then 1 else 0 end ) as pj_xzc_cnt,
sum(case when yd_type='行政村' and is_jcpj='是' then 1 else 0 end ) as pj_xzc_jc_cnt,
count(distinct case when distance>=10000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_10_cnt,
count(distinct case when distance>=10000 and distance<30000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_10_30_cnt,
count(distinct case when distance>=10000 and distance<30000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_10_30_cnt,
count(distinct case when distance>=30000 and distance<50000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_30_50_cnt,
count(distinct case when distance>=30000 and distance<50000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_30_50_cnt,
count(distinct case when distance>=50000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_50_cnt,
count(distinct case when distance>=50000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_50_cnt,
sum(case when yd_type is null or yd_type='' then 1 else 0 end ) as pj_no_cnt
from (
select 
dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type,
yd_type,is_jxzpj,cast(distance as int) as distance,is_jcpj,aoi_code  
from dm_gis.village_dest_kdsm_res 
where inc_day='$firstDay' and dest_hq_code<>'' and dest_area_code<>'' and dest_dist_code<>'' 
) as t 
group by dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type 
;

--收件
drop table if exists dm_gis.tmp_village_kdsm_src_res_stat_1;
create table dm_gis.tmp_village_kdsm_src_res_stat_1 stored as parquet as 
select 
src_hq_code,src_area_code,area_name,src_dist_code,wd_type,
count(1) as sj_all_cnt,
sum(case when yd_type='乡镇' then 1 else 0 end ) as sj_xz_cnt,
sum(case when yd_type='乡镇' and is_jxzpj='是' then 1 else 0 end ) as sj_xz_sm_cnt,
sum(case when yd_type='行政村' then 1 else 0 end ) as sj_xzc_cnt,
sum(case when yd_type='行政村' and is_jcpj='是' then 1 else 0 end ) as sj_xzc_jc_cnt,
sum(case when yd_type is null or yd_type='' then 1 else 0 end ) as sj_no_cnt
from (
select 
src_hq_code,src_area_code,area_name,src_dist_code,wd_type,
yd_type,is_jxzpj,is_jcpj,aoi_code  
from dm_gis.village_src_kdsm_res 
where inc_day='$firstDay' and src_hq_code<>'' and src_area_code<>'' and src_dist_code<>'' 
) as t 
group by src_hq_code,src_area_code,area_name,src_dist_code,wd_type  
;


---- 汇聚得筛选表
drop table if exists dm_gis.tmp_village_kdsm_stat_dist_code;
create table dm_gis.tmp_village_kdsm_stat_dist_code stored as parquet as 
select 
hq_code,area_code,area_name,dist_code,wd_type 
from (
select dest_hq_code as hq_code,dest_area_code as area_code,area_name,dest_dist_code as dist_code,wd_type 
from dm_gis.tmp_village_kdsm_dest_res_stat_1 
union all 
select src_hq_code as hq_code,src_area_code as area_code,area_name,src_dist_code as dist_code,wd_type  
from dm_gis.tmp_village_kdsm_src_res_stat_1 
) as t 
group by hq_code,area_code,area_name,dist_code,wd_type   
;

insert overwrite table dm_gis.village_kdsm_stat partition(inc_day='$firstDay')
select 
t0.hq_code,t0.area_code,t0.area_name,t0.dist_code,t0.wd_type,
t1.pj_all_cnt,
t1.pj_xz_cnt,
t1.pj_xz_sm_cnt,
t1.pj_xz_sm_ratio,
t1.pj_xzc_cnt,
t1.pj_xzc_jc_cnt,
t1.pj_xzc_jc_ratio,
t1.pj_yjc_10_cnt,
t1.pj_yjc_10_30_cnt,
t1.pj_jc_10_30_cnt,
t1.pj_yjc_30_50_cnt,
t1.pj_jc_30_50_cnt,
t1.pj_yjc_50_cnt,
t1.pj_jc_50_cnt,
t1.pj_no_cnt,
t1.pj_no_ratio,
t2.sj_all_cnt,
t2.sj_xz_cnt,
t2.sj_xz_sm_cnt,
t2.sj_xz_sm_ratio,
t2.sj_xzc_cnt,
t2.sj_xzc_jc_cnt,
t2.sj_xzc_jc_ratio,
t2.sj_no_cnt,
t2.sj_no_ratio   
from dm_gis.tmp_village_kdsm_stat_dist_code as t0 
left join (
select dest_hq_code as hq_code,dest_area_code as area_code,area_name,dest_dist_code as dist_code,wd_type,
pj_all_cnt,
pj_xz_cnt,
pj_xz_sm_cnt,
pj_xz_sm_cnt/pj_xz_cnt as pj_xz_sm_ratio,
pj_xzc_cnt,
pj_xzc_jc_cnt,
pj_xzc_jc_cnt/pj_xzc_cnt as pj_xzc_jc_ratio,
pj_yjc_10_cnt,
pj_yjc_10_30_cnt,
pj_jc_10_30_cnt,
pj_yjc_30_50_cnt,
pj_jc_30_50_cnt,
pj_yjc_50_cnt,
pj_jc_50_cnt,
pj_no_cnt,
pj_no_cnt/pj_all_cnt as pj_no_ratio 
from dm_gis.tmp_village_kdsm_dest_res_stat_1 ) as t1 
on t0.hq_code=t1.hq_code and t0.area_code=t1.area_code and t0.area_name=t1.area_name and t0.dist_code=t1.dist_code and t0.wd_type=t1.wd_type   
left join (
select src_hq_code as hq_code,src_area_code as area_code,area_name,src_dist_code as dist_code,wd_type, 
sj_all_cnt,sj_xz_cnt,sj_xz_sm_cnt,
sj_xz_sm_cnt/sj_xz_cnt as sj_xz_sm_ratio,
sj_xzc_cnt,sj_xzc_jc_cnt,
sj_xzc_jc_cnt/sj_xzc_cnt as sj_xzc_jc_ratio,
sj_no_cnt,
sj_no_cnt/sj_all_cnt as sj_no_ratio   
from dm_gis.tmp_village_kdsm_src_res_stat_1 
) as t2 
on t0.hq_code=t2.hq_code and t0.area_code=t2.area_code and t0.area_name=t2.area_name and t0.dist_code=t2.dist_code and t0.wd_type=t2.wd_type  
;

drop table if exists dm_gis.tmp_village_kdsm_stat_dist_code;
drop table if exists dm_gis.tmp_village_kdsm_src_res_stat_1;
drop table if exists dm_gis.tmp_village_kdsm_dest_res_stat_1;
-- 200230509  v2.6 修改 1.接口http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=1000；把radius入参改为1000




-- 2023.12.27 新增 收派件统计数据
create table dm_gis.village_kdsm_stat_cnt_fee_di(
province	string comment '省',
city	string comment '市名称',
county	string comment '区',
town	string comment '乡镇名称',
town_adcode	string comment '乡镇code',
vil_name	string comment '村名称',
vil_code	string comment '村code',
class_code	string comment 'Class code',
distance	string comment '村-镇距离',
zone_code	string comment '网点代码',
dept_type_code	string comment '网点类型代码',
dept_type_name	string comment '网点类型名称',
wd_type	string comment '网点合作方式',
area_code	string comment '地区代码',
dist_code	string comment '城市代码',
is_yj	string comment '是否月结',
pj_cnt	string comment '派件数量',
jcpj_cnt	string comment '进村派件量',
sj_cnt	string comment '收件数量',
jcsj_cnt	string comment '进村收件量',
all_fee_rmb	string comment '折前收入',
tt_fee_zh_all_fee	string comment '折后收入',
jxzpj_cnt	string comment '乡镇上门派件量',
jxzsj_cnt	string comment '乡镇上门收件量'
)
COMMENT '行政村收派件统计表(件量、收入)'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 2024.01.23 增加字段
alter table dm_gis.village_kdsm_stat_cnt_fee_di add columns(city_label  string comment '城区标签') cascade;
alter table dm_gis.village_kdsm_stat_cnt_fee_di add columns(town_country_types   string comment '城乡区域类型') cascade;



-- 行政村收派件统计表(件量、收入)
-- 派件
drop table if exists dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1;
create table dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1 stored as parquet as 
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,dest_zone_code,wd_type,dest_area_code,dest_dist_code,is_yj,
count(1) as pj_cnt,sum(is_jcpj) as jcpj_cnt,sum(is_jxzpj) as jxzpj_cnt 
from (select 
if(province<>'',province,'') as province,if(city<>'',city,'') as city,if(county<>'',county,'') as county,if(town<>'',town,'') as town,if(town_adcode<>'',town_adcode,'') as town_adcode,
if(vil_name<>'',vil_name,'') as vil_name,if(vil_code<>'',vil_code,'') as vil_code,if(class_code<>'',class_code,'') as class_code,
if(distance<>'',ROUND(CAST(distance AS DOUBLE),1),'') as distance,if(dest_zone_code<>'',dest_zone_code,'') as dest_zone_code,if(wd_type<>'',wd_type,'') as wd_type,
if(dest_area_code<>'',dest_area_code,'') as dest_area_code,if(dest_dist_code<>'',dest_dist_code,'') as dest_dist_code,if(is_yj<>'',is_yj,'') as is_yj,
if(is_jcpj<>'',is_jcpj,'') as is_jcpj,if(is_jxzpj<>'',is_jxzpj,'') as is_jxzpj 
from dm_gis.village_dest_kdsm_res 
where inc_day='$firstDay' 
) as t 
group by province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,dest_zone_code,wd_type,dest_area_code,dest_dist_code,is_yj 
;

-- 收件
drop table if exists dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1;
create table dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1 stored as parquet as 
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj,
count(1) as sj_cnt,sum(is_jcpj) as jcsj_cnt,sum(is_jxzpj) as jxzsj_cnt,sum(all_fee_rmb) as all_fee_rmb,sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from (select 
if(province<>'',province,'') as province,if(city<>'',city,'') as city,if(county<>'',county,'') as county,if(town<>'',town,'') as town,if(town_adcode<>'',town_adcode,'') as town_adcode,
if(vil_name<>'',vil_name,'') as vil_name,if(vil_code<>'',vil_code,'') as vil_code,if(class_code<>'',class_code,'') as class_code,
if(distance<>'',ROUND(CAST(distance AS DOUBLE),1),'') as distance,if(source_zone_code<>'',source_zone_code,'') as source_zone_code,if(wd_type<>'',wd_type,'') as wd_type,
if(src_area_code<>'',src_area_code,'') as src_area_code,if(src_dist_code<>'',src_dist_code,'') as src_dist_code,if(is_yj<>'',is_yj,'') as is_yj,
if(is_jcpj<>'',is_jcpj,'') as is_jcpj,if(is_jxzpj<>'',is_jxzpj,'') as is_jxzpj,if(all_fee_rmb<>'',all_fee_rmb,'') as all_fee_rmb,if(tt_fee_zh_all_fee<>'',tt_fee_zh_all_fee,'') as tt_fee_zh_all_fee  
from dm_gis.village_src_kdsm_res 
where inc_day='$firstDay' 
) as t 
group by province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj  
;


-- -- 汇聚得筛选表
drop table if exists dm_gis.tmp_village_kdsm_stat_cnt_fee_key;
create table dm_gis.tmp_village_kdsm_stat_cnt_fee_key stored as parquet as 
select 
province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,zone_code,wd_type,area_code,dist_code,is_yj
from (
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,dest_zone_code as zone_code,wd_type,dest_area_code as area_code,dest_dist_code as dist_code,is_yj 
from dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1 
union all 
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code as zone_code,wd_type,src_area_code as area_code,src_dist_code as dist_code,is_yj  
from dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1 
) as t 
group by province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,zone_code,wd_type,area_code,dist_code,is_yj  
;


insert overwrite table dm_gis.village_kdsm_stat_cnt_fee_di partition(inc_day='$firstDay')
select 
t0.province,t0.city,t0.county,t0.town,t0.town_adcode,t0.vil_name,t0.vil_code,t0.class_code,t0.distance,
t0.zone_code,t1.dept_type_code,t1.dept_type_name,
t0.wd_type,t0.area_code,t0.dist_code,t0.is_yj,
pj_cnt,jcpj_cnt,sj_cnt,jcsj_cnt,all_fee_rmb,tt_fee_zh_all_fee,jxzpj_cnt,jxzsj_cnt,
t15.remark as city_label,
case when (SUBSTR(t0.county, -1)='区' and t0.class_code in ('111','112') ) or t15.remark='市中心'  then '市区' 
     when (SUBSTR(t0.county, -1)!='区' and t0.class_code in ('111','112') ) or t15.remark='县中心'  then '县区'  
     when t0.class_code in  ('121','122','123')  then '镇区'  
     when t0.class_code in  ('210','220')  then '乡村'
else '' end  as town_country_types   
from dm_gis.tmp_village_kdsm_stat_cnt_fee_key as t0 
left join (select dept_code,dept_type_code,dept_type_name from dim.dim_dept_info_df where inc_day='$firstDay' and dept_code<>'' group by dept_code,dept_type_code,dept_type_name 
) as t1 
on t0.zone_code=t1.dept_code 
left join (select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,dest_zone_code,wd_type,dest_area_code,dest_dist_code,is_yj,
pj_cnt,jcpj_cnt,jxzpj_cnt 
from dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1 ) as t2 
on t0.province=t2.province and t0.city=t2.city and t0.county=t2.county and t0.town=t2.town and t0.town_adcode=t2.town_adcode 
and t0.vil_name=t2.vil_name and t0.vil_code=t2.vil_code and t0.class_code=t2.class_code and t0.distance=t2.distance 
and t0.zone_code=t2.dest_zone_code and t0.wd_type=t2.wd_type and t0.area_code=t2.dest_area_code and t0.dist_code=t2.dest_dist_code and t0.is_yj=t2.is_yj 
left join (select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj,
sj_cnt,jcsj_cnt,jxzsj_cnt,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1 ) as t3 
on t0.province=t3.province and t0.city=t3.city and t0.county=t3.county and t0.town=t3.town and t0.town_adcode=t3.town_adcode 
and t0.vil_name=t3.vil_name and t0.vil_code=t3.vil_code and t0.class_code=t3.class_code and t0.distance=t3.distance 
and t0.zone_code=t3.source_zone_code and t0.wd_type=t3.wd_type and t0.area_code=t3.src_area_code and t0.dist_code=t3.src_dist_code and t0.is_yj=t3.is_yj 
left join ( select area_code,remark from dm_gis.dim_village_city_af )  as t15
on t0.vil_code=t15.area_code 
;


drop table if exists dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1;
drop table if exists dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1;
drop table if exists dm_gis.tmp_village_kdsm_stat_cnt_fee_key;





------------------------------------------------------------------------------------------------------------
-- ID：712787  行政村收派件_v2.0_月刷新
------------------------------------------------------------------------------------------------------------
-- dm_gis.village_src_kdsm_res
insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,wd_type,src_dist_code,t1.tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,
subsidy_type,subsidy,
src_type_code,order_no,aoi_id,aoi_src,aoi_type,aoi_area_type,is_cgj,cgj_longitude,cgj_latitude,
consign_xy_aoiid,
csg_location_mark,
bar_sn,
is_same_aoi,
cabinet_code,
position_name,
city_label,
town_country_types,
consign_aoi_area,
is_addr_aoi      
 
from (
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,
pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,yd_type,wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,
subsidy_type,subsidy,
src_type_code,order_no,aoi_id,aoi_src,aoi_type,aoi_area_type,is_cgj,cgj_longitude,cgj_latitude,
consign_xy_aoiid,
csg_location_mark,
bar_sn,
is_same_aoi,
cabinet_code,
position_name,
city_label,
town_country_types,
consign_aoi_area,
is_addr_aoi           

from dm_gis.village_src_kdsm_res where inc_day='$firstDay' ) as t0 
left join (select waybill_no,tt_fee_zh_all_fee from dm_gis.tt_order_hook where inc_day='$firstDay' group by waybill_no,tt_fee_zh_all_fee) as t1 
on t0.waybill_no=t1.waybill_no
;

-- dm_gis.village_kdsm_vil_stat
insert overwrite table  dm_gis.village_kdsm_vil_stat partition(inc_day='$firstDay')
select t0.area_code,t0.dist_code,t0.city,t0.zone_code,t0.town,t0.town_adcode,t0.vil_name,t0.vil_code,t0.dest_cnt,t0.src_cnt,t0.class_code,t0.is_ttyz,t0.dest_jcpj_cnt,t0.src_jcpj_cnt,
t1.all_fee_rmb,t1.tt_fee_zh_all_fee 
from (select area_code,dist_code,city,zone_code,town,town_adcode,vil_name,vil_code,dest_cnt,src_cnt,class_code,is_ttyz,dest_jcpj_cnt,src_jcpj_cnt,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.village_kdsm_vil_stat where inc_day='$firstDay' ) as t0 
left join (
select
src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz,
sum(all_fee_rmb) as all_fee_rmb,sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from
(select
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,if(own_code is not null,'是','否') is_ttyz,is_jcpj,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.village_src_kdsm_res
where inc_day='$firstDay' and src_area_code<>'' and city<>'' and source_zone_code<>'' ) as t
group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz
) as t1 
on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code
and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code and t0.class_code=t1.class_code and t0.is_ttyz=t1.is_ttyz
;


-- dm_gis.village_kdsm_stat_cnt_fee_di
insert overwrite table dm_gis.village_kdsm_stat_cnt_fee_di partition(inc_day='$firstDay')
select 
t0.province,t0.city,t0.county,t0.town,t0.town_adcode,t0.vil_name,t0.vil_code,t0.class_code,t0.distance,
t0.zone_code,t0.dept_type_code,t0.dept_type_name,
t0.wd_type,t0.area_code,t0.dist_code,t0.is_yj,
pj_cnt,jcpj_cnt,sj_cnt,jcsj_cnt,all_fee_rmb,t1.tt_fee_zh_all_fee,jxzpj_cnt,jxzsj_cnt,city_label,town_country_types  
from (select  
province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,
zone_code,dept_type_code,dept_type_name,
wd_type,area_code,dist_code,is_yj,
pj_cnt,jcpj_cnt,sj_cnt,jcsj_cnt,all_fee_rmb,tt_fee_zh_all_fee,jxzpj_cnt,jxzsj_cnt,city_label,town_country_types 
from dm_gis.village_kdsm_stat_cnt_fee_di where inc_day='$firstDay' ) as t0 
left join (
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj,
sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from (select 
if(province<>'',province,'') as province,if(city<>'',city,'') as city,if(county<>'',county,'') as county,if(town<>'',town,'') as town,if(town_adcode<>'',town_adcode,'') as town_adcode,
if(vil_name<>'',vil_name,'') as vil_name,if(vil_code<>'',vil_code,'') as vil_code,if(class_code<>'',class_code,'') as class_code,
if(distance<>'',ROUND(CAST(distance AS DOUBLE),1),'') as distance,if(source_zone_code<>'',source_zone_code,'') as source_zone_code,if(wd_type<>'',wd_type,'') as wd_type,
if(src_area_code<>'',src_area_code,'') as src_area_code,if(src_dist_code<>'',src_dist_code,'') as src_dist_code,if(is_yj<>'',is_yj,'') as is_yj,
if(is_jcpj<>'',is_jcpj,'') as is_jcpj,if(is_jxzpj<>'',is_jxzpj,'') as is_jxzpj,if(all_fee_rmb<>'',all_fee_rmb,'') as all_fee_rmb,if(tt_fee_zh_all_fee<>'',tt_fee_zh_all_fee,'') as tt_fee_zh_all_fee  
from dm_gis.village_src_kdsm_res 
where inc_day='$firstDay' 
) as t 
group by province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj  
) as t1 
on t0.province=t1.province and t0.city=t1.city and t0.county=t1.county and t0.town=t1.town and t0.town_adcode=t1.town_adcode 
and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code and t0.class_code=t1.class_code and t0.distance=t1.distance 
and t0.zone_code=t1.source_zone_code and t0.wd_type=t1.wd_type and t0.area_code=t1.src_area_code and t0.dist_code=t1.src_dist_code and t0.is_yj=t1.is_yj 
;






------------------------------------------------------------------------------------------------------------
-- 集派回刷近30天
------------------------------------------------------------------------------------------------------------
-- 20231020 集派回刷近30天数据（增加进村派件为是的量）

-- insert overwrite table dm_gis.village_dest_kdsm_res partition(inc_day='')
-- select 
-- dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
-- meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
-- is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
-- province,city,county,town,town_adcode,vil_name,vil_code,class_code,
-- own_code,is_jcpj,is_jxzpj,
-- case when (class_code in ('220','210')) or (is_jcpj='1')  then '行政村' 
-- when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
-- when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
--  else '' end as  yd_type ,
-- distance,
-- wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
-- is_jp,is_tcj,lonlat_tag,
-- subsidy_type,subsidy 
-- from (select 
-- dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,t0.waybill_no,deliver_emp_code,real_product_code,meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
-- is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,
-- if(class_code in ('220','210') and t1.sending_tm is not null, '1' ,is_jcpj) as is_jcpj,
-- if(class_code in ('220','210') and t1.sending_tm is not null, '0' ,is_jxzpj) as is_jxzpj,
-- yd_type,distance,wd_type,dest_dist_code,
-- operate_longitude,operate_latitude,signin_tm,add_fee,is_jp,is_tcj,lonlat_tag,subsidy_type,subsidy 
-- from (select 
-- dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
-- is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,yd_type,distance,wd_type,dest_dist_code,
-- operate_longitude,operate_latitude,signin_tm,add_fee,is_jp,is_tcj,lonlat_tag,subsidy_type,subsidy,inc_day 
-- from 
-- dm_gis.village_dest_kdsm_res where inc_day='' ) as t0 
-- left join (select waybill_no,sending_tm from dm_gis.tmp_village_dest_waybill_no_cnt_res group by waybill_no,sending_tm) as t1 
-- on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.sending_tm 
-- ) as t 
-- ;



------------------------------------------------------------------------------------------------------------
-- 补贴标签 
------------------------------------------------------------------------------------------------------------
-- 2023.11.21  新增字段  补贴标签(subsidy_type)  补贴更新(subsidy)
-- dm_ifs.ifs_fct_township_gather_pick_deliver_dtl_mi	subsidy_type	
-- 1.利用运单号关联该表的inc_day相同且pd_flag=2时的waybill_no，命中则获取subsidy_type，否则为空；更新时间，上游表更新后刷新
-- 2.利用运单号关联该表的inc_day相同且pd_flag=2时的waybill_no，命中则获取subsidy，否则为空；更新时间，上游表更新后刷新 
insert overwrite table dm_gis.village_dest_kdsm_res partition(inc_day='$firstDay') 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,t0.waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag,
t1.subsidy_type,t1.subsidy,
dest_type_code,aoi_id,aoi_src,aoi_type,aoi_area_type,driver_track 

from (select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag,
dest_type_code,aoi_id,aoi_src,aoi_type,aoi_area_type,driver_track 

from dm_gis.village_dest_kdsm_res  where inc_day='$firstDay' ) as t0 
left join (select waybill_no,subsidy_type,subsidy from dm_ifs.dm_ifs_fct_township_gather_pick_deliver_dtl_di where inc_day='$firstDay' and pd_flag='2' and subsidy_type<>'集收' group by waybill_no,subsidy_type,subsidy) as t1 
on t0.waybill_no=t1.waybill_no
;
