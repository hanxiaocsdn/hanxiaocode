---- 统计表
--派件
drop table if exists dm_gis.tmp_village_henan_dest_res_stat_1;
create table dm_gis.tmp_village_henan_dest_res_stat_1 as 
select 
dest_hq_code,dest_area_code,area_name,dest_dist_code,
count(1) as pj_all_cnt,
sum(case when yd_type='乡镇' then 1 else 0 end ) as pj_xz_cnt,
sum(case when yd_type='乡镇' and is_jxzpj='是' then 1 else 0 end ) as pj_xz_sm_cnt,
sum(case when yd_type='行政村' then 1 else 0 end ) as pj_xzc_cnt,
sum(case when yd_type='行政村' and is_jcpj='是' then 1 else 0 end ) as pj_xzc_jc_cnt,
count(distinct case when car_dist>=10000 and yd_type='行政村' then aoi_id else null end ) as pj_yjc_10_cnt,
count(distinct case when car_dist>=10000 and car_dist<30000 and yd_type='行政村' then aoi_id else null end ) as pj_yjc_10_30_cnt,
count(distinct case when car_dist>=10000 and car_dist<30000 and yd_type='行政村' and is_jcpj='是' then aoi_id else null end ) as pj_jc_10_30_cnt,
count(distinct case when car_dist>=30000 and car_dist<50000 and yd_type='行政村' then aoi_id else null end ) as pj_yjc_30_50_cnt,
count(distinct case when car_dist>=30000 and car_dist<50000 and yd_type='行政村' and is_jcpj='是' then aoi_id else null end ) as pj_jc_30_50_cnt,
count(distinct case when car_dist>=50000 and yd_type='行政村' then aoi_id else null end ) as pj_yjc_50_cnt,
count(distinct case when car_dist>=50000 and yd_type='行政村' and is_jcpj='是' then aoi_id else null end ) as pj_jc_50_cnt,
sum(case when yd_type is null or yd_type='' then 1 else 0 end ) as pj_no_cnt
from (
select 
dest_hq_code,dest_area_code,area_name,dest_dist_code,
yd_type,is_jxzpj,cast(car_dist as int) as car_dist,is_jcpj,aoi_id 
from dm_gis.tmp_village_henan_dest_matchall_res_1006
where inc_day='20230102' and dest_hq_code<>'' and dest_area_code<>'' and dest_dist_code<>'' 
) as t 
group by dest_hq_code,dest_area_code,area_name,dest_dist_code
;

--收件
drop table if exists dm_gis.tmp_village_henan_src_res_stat_1;
create table dm_gis.tmp_village_henan_src_res_stat_1 as 
select 
src_hq_code,src_area_code,area_name,src_dist_code,
count(1) as sj_all_cnt,
sum(case when yd_type='乡镇' then 1 else 0 end ) as sj_xz_cnt,
sum(case when yd_type='乡镇' and is_jxzpj='是' then 1 else 0 end ) as sj_xz_sm_cnt,
sum(case when yd_type='行政村' then 1 else 0 end ) as sj_xzc_cnt,
sum(case when yd_type='行政村' and is_jcpj='是' then 1 else 0 end ) as sj_xzc_jc_cnt,
sum(case when yd_type is null or yd_type='' then 1 else 0 end ) as sj_no_cnt
from (
select 
src_hq_code,src_area_code,area_name,src_dist_code,
yd_type,is_jxzpj,is_jcpj,aoi_id 
from dm_gis.tmp_village_henan_src_matchall_res_1006
where inc_day='20230102' and src_hq_code<>'' and src_area_code<>'' and src_dist_code<>'' 
) as t 
group by src_hq_code,src_area_code,area_name,src_dist_code 
;


---- 汇聚得筛选表
drop table if exists dm_gis.tmp_village_henan_stat_dist_code;
create table dm_gis.tmp_village_henan_stat_dist_code as 
select 
hq_code,area_code,area_name,dist_code 
from (
select dest_hq_code as hq_code,dest_area_code as area_code,area_name,dest_dist_code as dist_code 
from dm_gis.tmp_village_henan_dest_res_stat_1 
union all 
select src_hq_code as hq_code,src_area_code as area_code,area_name,src_dist_code as dist_code 
from dm_gis.tmp_village_henan_src_res_stat_1 
) as t 
group by hq_code,area_code,area_name,dist_code 
;

-- 建表
create table dm_gis.tmp_village_henan_stat (
hq_code string comment '大区代码',
area_code string comment '地区代码',
area_name string comment '地区名称',
dist_code string comment '城市编码',
pj_all_cnt int comment '派件总量',
pj_xz_cnt int comment '派件乡镇件量',
pj_xz_sm_cnt int comment '派件乡镇上门件量',
pj_xz_sm_ratio double comment '派件乡镇上门率',
pj_xzc_cnt int comment '派件行政村件量',
pj_xzc_jc_cnt int comment '派件行政村进村件量',
pj_xzc_jc_ratio double comment '派件行政村进村率',
pj_yjc_10_cnt int comment '派件大于10km应进村件量',
pj_yjc_10_30_cnt int comment '派件10-30km应进村件量',
pj_jc_10_30_cnt int comment '派件10-30km进村件量',
pj_yjc_30_50_cnt int comment '派件30-50km应进村件量',
pj_jc_30_50_cnt int comment '派件30-50km进村件量',
pj_yjc_50_cnt int comment '派件大于50km应进村件量',
pj_jc_50_cnt int comment '派件大于50km进村件量',
pj_no_cnt int comment '派件未识别件量',
pj_no_ratio double comment '派件未识别率',
sj_all_cnt  int comment '收件总量',
sj_xz_cnt int comment '收件乡镇件量',
sj_xz_sm_cnt int comment '收件乡镇上门件量',
sj_xz_sm_ratio double comment '收件乡镇上门率',
sj_xzc_cnt int comment '收件行政村件量',
sj_xzc_jc_cnt int comment '收件行政村进村件量',
sj_xzc_jc_ratio double comment '收件行政村进村率',
sj_no_cnt  int comment '收件未识别件量',
sj_no_ratio   double comment '收件未识别率' 
)
COMMENT '行政村收派件统计表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 跑数
insert overwrite table dm_gis.tmp_village_henan_stat partition(inc_day='')
select 
t0.hq_code,t0.area_code,t0.area_name,t0.dist_code,
t1.pj_all_cnt,
t1.pj_xz_cnt,
t1.pj_xz_sm_cnt,
t1.pj_xz_sm_ratio,
t1.pj_xzc_cnt,
t1.pj_xzc_jc_cnt,
t1.pj_xzc_jc_ratio,
t1.pj_yjc_10_cnt,
t1.pj_yjc_10_30_cnt,
t1.pj_jc_10_30_cnt,
t1.pj_yjc_30_50_cnt,
t1.pj_jc_30_50_cnt,
t1.pj_yjc_50_cnt,
t1.pj_jc_50_cnt,
t1.pj_no_cnt,
t1.pj_no_ratio,
t2.sj_all_cnt,
t2.sj_xz_cnt,
t2.sj_xz_sm_cnt,
t2.sj_xz_sm_ratio,
t2.sj_xzc_cnt,
t2.sj_xzc_jc_cnt,
t2.sj_xzc_jc_ratio,
t2.sj_no_cnt,
t2.sj_no_ratio   
from dm_gis.tmp_village_henan_stat_dist_code as t0 
left join (
select dest_hq_code as hq_code,dest_area_code as area_code,area_name,dest_dist_code as dist_code,
pj_all_cnt,
pj_xz_cnt,
pj_xz_sm_cnt,
pj_xz_sm_cnt/pj_xz_cnt as pj_xz_sm_ratio,
pj_xzc_cnt,
pj_xzc_jc_cnt,
pj_xzc_jc_cnt/pj_xzc_cnt as pj_xzc_jc_ratio,
pj_yjc_10_cnt,
pj_yjc_10_30_cnt,
pj_jc_10_30_cnt,
pj_yjc_30_50_cnt,
pj_jc_30_50_cnt,
pj_yjc_50_cnt,
pj_jc_50_cnt,
pj_no_cnt,
pj_no_cnt/pj_all_cnt as pj_no_ratio 
from dm_gis.tmp_village_henan_dest_res_stat_1 ) as t1 
on t0.hq_code=t1.hq_code and t0.area_code=t1.area_code and t0.area_name=t1.area_name and t0.dist_code=t1.dist_code  
left join (
select src_hq_code as hq_code,src_area_code as area_code,area_name,src_dist_code as dist_code, 
sj_all_cnt,sj_xz_cnt,sj_xz_sm_cnt,
sj_xz_sm_cnt/sj_xz_cnt as sj_xz_sm_ratio,
sj_xzc_cnt,sj_xzc_jc_cnt,
sj_xzc_jc_cnt/sj_xzc_cnt as sj_xzc_jc_ratio,
sj_no_cnt,
sj_no_cnt/sj_all_cnt as sj_no_ratio   
from dm_gis.tmp_village_henan_src_res_stat_1 
) as t2 
on t0.hq_code=t2.hq_code and t0.area_code=t2.area_code and t0.area_name=t2.area_name and t0.dist_code=t2.dist_code  
;