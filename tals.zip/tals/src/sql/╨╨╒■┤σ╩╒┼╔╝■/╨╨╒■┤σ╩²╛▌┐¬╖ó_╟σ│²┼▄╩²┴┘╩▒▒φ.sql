-- 删除临时表
drop table if exists dm_gis.tmp_village_dest_addr_decode_log;
drop table if exists dm_gis.tmp_village_cms_aoi_village; 
drop table if exists dm_gis.tmp_village_gisaoisrc_dest; 
drop table if exists dm_gis.tmp_village_guid_dest;
drop table if exists dm_gis.tmp_village_emap_district_village;
drop table if exists dm_gis.tmp_village_village_log_flink_res;
drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode;
drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set;
drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode;
drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set;
drop table if exists dm_gis.tmp_tt_waybill_addition_dest;

drop table if exists dm_gis.tmp_village_req_orderno_src;
drop table if exists dm_gis.tmp_village_gisaoisrc_src;
drop table if exists dm_gis.tmp_village_src_addr_decode_log;

drop table if exists dm_gis.tmp_village_kdsm_vil_stat_dest;
drop table if exists dm_gis.tmp_village_kdsm_vil_stat_src;
drop table if exists dm_gis.tmp_village_kdsm_dest_res_stat_1;
drop table if exists dm_gis.tmp_village_kdsm_src_res_stat_1;
drop table if exists dm_gis.tmp_village_kdsm_stat_dist_code;


