-- 
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- 需求： id: 1585280  【偏远乡村派件上门】快递进村收派件数据统计_V2.1 
-- @author 张小琼 （01416344）
-- Created on 2023-02-15
-- 任务信息： 668258	行政村收派件_20230222
-- 

-- 1、数据准备

-- 1.1 运单
-- 源：dm_gis.tt_waybill_hook  派件
-- dm_gis.village_tt_waybill_hook
create table dm_gis.village_tt_waybill_hook(
waybill_no string comment '运单号',
signin_tm string comment '收件时间',
dest_hq_code string comment '目的地经营本部（大区）',
dest_area_code string comment '目的地区部（地区代码）',
dest_zone_code string comment '目的地网点代码（网点代码）',
deliver_emp_code string comment '派件员',
real_product_code string comment '产品代码',
meterage_weight_qty string comment '计费重量',
pay_cust_type string comment '付费客户类型',
service_prod_code string comment '增值服务代码',
all_fee_rmb string comment '总收入',
freight_monthly_acct_code string comment '月结账号',
aoi_id string comment 'aoi id',
aoi_code string comment 'aoi编码',
aoi_name string comment 'aoi名称',
aoi_type_name string comment 'aoi类型名称',
dest_county string comment '目的地区/县/镇',
consignee_addr  string comment '收件地址',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "行政村运单（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 剔除掉ackbill_type_code=9的运单
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;

insert overwrite table  dm_gis.village_tt_waybill_hook partition(inc_day) 
select waybill_no,signin_tm,dest_hq_code,dest_area_code,dest_zone_code,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
dest_county,consignee_addr,
dest_dist_code,inc_day 
from dm_gis.tt_waybill_hook where inc_day='$firstDay' and (ackbill_type_code is null or ackbill_type_code<>'9')
;

-- 1.2 小哥轨迹 dm_gis.esg_gis_loc_trajectory
-- drop table if exists dm_gis.tmp_village_henan_esg_gis_1006;
-- create table  dm_gis.tmp_village_henan_esg_gis_1006  as 
-- select un,inc_day,tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay'
-- ;

-- 1.3 网点站点数据 dim.dim_department_hist (新表 dim.dim_dept_info_df）
-- drop table if exists dm_gis.tmp_village_henan_department_1006;
-- create table dm_gis.tmp_village_henan_department_1006  as 
-- select dept_code,area_name,dept_name,longitude,latitude 
-- from (
-- select dept_code,area_name,dept_name,longitude,latitude,row_number() over(partition by dept_code order by inc_day desc)  as rn 
-- from (select area_name,dept_code,dept_name,longitude,latitude,inc_day  
-- from dim.dim_department_hist where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') ) as a 
-- ) as b where b.rn=1
-- ;

-- 1.4 aoi和aoi区域对应关系表 dm_tc_waybillinfo.aoi_area_aoi 
-- select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi 


-- 1.5 行政村查询接口日志数据 dm_gis.village_log_flink_res
-- 地址和city code与表dm_gis.village_log_flink_res（inc_day的最近7天）的 p_address和p_city_code进行匹配,都命中则获取 ，否则通过行政村查询接口查询，获取对应数据
-- 
drop table if exists dm_gis.tmp_village_village_log_flink_res;
create table dm_gis.tmp_village_village_log_flink_res stored as parquet as 
select p_address,p_city_code,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance
from (
select p_address,p_city_code,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,
row_number() over( partition by p_address,p_city_code order by r_distance desc ) as rn  
from dm_gis.village_log_flink_res where inc_day>=date_format(date_add(current_date(),-7),'yyyyMMdd') and inc_day<date_format(current_date(),'yyyyMMdd') and r_status='0' 
) as t where t.rn=1 
;

-- 1.6 网点类型 dim.dim_dept_info_df
-- 利用网点代码与表dim.dim_dept_info_df，where dept_type_code='DB05-DLD'的dept_code做匹配，命中则填入‘代理’，不命中则填入‘自营’
-- select dept_code from dim.dim_dept_info_df where inc_day='' and dept_type_code='DB05-DLD' 

-- 1.7 ods_yjy.yjy_mailno_kb
-- 利用运单号和日期与表ods_yjy.yjy_mailno_kb（order_state=‘已出库’）中的 mailno和inc_day匹配，命中则返回own_code，否则为空

-- select mailno,own_code from ods_yjy.yjy_mailno_kb where inc_day='$firstDay' and order_state='已出库' ;



-- 1、利用aoi id到表dm_gis.cms_aoi_village（最新inc_day）中获取village_guid
-- 2、利用village_guid匹配表dm_gis.emap_district_village（最新inc_day）中的 guid，命中则返回 name_p、 name_c、 name_d、 name_t、 adcode_t、 name、 area_code、 class_code、 distant，否则跳到第三步
-- 3、利用地址和city code与表dm_gis.village_log_flink_res（inc_day的最近7天）的 p_address和p_city_code进行匹配,都命中则获取 r_province、 r_city、 r_county、 r_town、 r_vilname、 r_vilcode、 r_town_adcode和 r_class_code，否则通过行政村查询接口查询，获取对应数据

-- 1.8 表dm_gis.cms_aoi_village，表dm_gis.emap_district_village  
-- 取最新分区数据
table1='dm_gis.cms_aoi_village'
v_partition=`hive -e  "show partitions $table1" | grep "inc_day=*" | sort | tail -n 1`
last_partition=${v_partition:10:8}
echo ${last_partition}

hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

drop table if exists dm_gis.tmp_village_cms_aoi_village;
create table dm_gis.tmp_village_cms_aoi_village  stored as parquet as 
select city_code,aoi_id,village_guid from dm_gis.cms_aoi_village where inc_day='${last_partition}' and aoi_id is not null and aoi_id<>'' and village_guid is not null and village_guid<>''  group by city_code,aoi_id,village_guid;
"

-- 
table1='dm_gis.emap_district_village'
v_partition=`hive -e  "show partitions $table1" | grep "inc_day=*" | sort | tail -n 1`
last_partition=${v_partition:10:8}
echo ${last_partition}

hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

drop table if exists dm_gis.tmp_village_emap_district_village;
create table dm_gis.tmp_village_emap_district_village stored as parquet as 
select guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant from dm_gis.emap_district_village where inc_day='${last_partition}' group by guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant;
"

-- 1.9 是否集派
-- ods_dcs.tt_edcs_hive_commission_detail_old（以该表最新数据，回刷主表的最近30天内数据）
-- 4.筛选inc_day=主表的inc_day的scene_type= ’3’  and audit_type=2获取subtract_type、billing_version_no、sending_tm、takeover_tm和waybill_no
-- 5.判断sending_tm=takeover_tm，则若waybill_no有多条数据则选择subtract_type不等于’冲’且billing_version_no最大的sending_tm和waybill_no再往下走，否则直接往下走
-- 利用sending_tm作为分区匹配主表的inc_day（限制最近30天内），且waybill_no匹配主表的waybill_no，命中则返回1，否则返回0
-- 计算waybill_no有多个的
drop table if exists dm_gis.tmp_village_dest_waybill_no_cnt_more ;
create table dm_gis.tmp_village_dest_waybill_no_cnt_more stored as parquet as 
select waybill_no,cnt 
from (
select waybill_no,count(1) as cnt 
from ods_dcs.tt_edcs_hive_commission_detail_old 
where inc_day='$firstDay' 
and scene_type='3' and audit_type='2' 
group by waybill_no
) as t where cnt>1
;

drop table if exists dm_gis.tmp_village_dest_waybill_no_cnt_1 ;
create table dm_gis.tmp_village_dest_waybill_no_cnt_1 stored as parquet as 
select t0.waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from (
select waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from ods_dcs.tt_edcs_hive_commission_detail_old 
where inc_day='$firstDay' 
and scene_type='3' and audit_type='2' 
and unix_timestamp(sending_tm,'yyyy-MM-dd HH:mm:ss')>unix_timestamp(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-30),'yyyy-MM-dd')
) as t0 
left join dm_gis.tmp_village_dest_waybill_no_cnt_more as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null
;

drop table if exists dm_gis.tmp_village_dest_waybill_no_cnt_2 ;
create table dm_gis.tmp_village_dest_waybill_no_cnt_2 stored as parquet as 
select t0.waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from (
select waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from ods_dcs.tt_edcs_hive_commission_detail_old 
where inc_day='$firstDay' 
and scene_type='3' and audit_type='2'
and subtract_type<>'2'
) as t0 
left join dm_gis.tmp_village_dest_waybill_no_cnt_more as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

drop table if exists dm_gis.tmp_village_dest_waybill_no_cnt_3 ;
create table dm_gis.tmp_village_dest_waybill_no_cnt_3 stored as parquet as 
select 
waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from (
select waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type,
row_number() over(partition by waybill_no order by billing_version_no desc ) as rn 
from dm_gis.tmp_village_dest_waybill_no_cnt_2 
) as t 
where t.rn=1 
and unix_timestamp(sending_tm,'yyyy-MM-dd HH:mm:ss')>unix_timestamp(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-30),'yyyy-MM-dd')
;


drop table if exists dm_gis.tmp_village_dest_waybill_no_cnt_res ;
create table dm_gis.tmp_village_dest_waybill_no_cnt_res stored as parquet as 
select waybill_no,replace(substr(sending_tm,1,10),'-','') as sending_tm  from dm_gis.tmp_village_dest_waybill_no_cnt_1
union all 
select waybill_no,replace(substr(sending_tm,1,10),'-','') as sending_tm  from dm_gis.tmp_village_dest_waybill_no_cnt_3
;



-- 1.10 同城
-- dm_gis.sf_order_rider_track
-- 利用inc_day和waybill_no匹配dm_gis.sf_order_rider_track的inc_day和waybill_no，命中则返回1，否则返回0



-- 2 获取5级地址
create table dm_gis.village_dest_addr_decode(
waybill_no string comment '运单号',
consignee_addr string comment '收件地址',
province string comment '',
city string comment '',
county string comment '',
town string comment '',
vilname string comment '村级名称',
vilcode string comment '村级编码',
town_adcode string comment '乡镇编码',
class_code string comment '城乡分类代码',
distance string comment '到网点距离',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "5级地址（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 2.1.1 通过aoi id获取 (v2.8 修改)
-- 1、利用运单号匹配表dm_gis.gis_rds_omsto中的req_waybillno，命中则获取gisaoisrc  
-- 20230721 改动
-- 1、利用运单号和aoi code匹配表dm_gis.gis_rds_omsto（inc_day=‘派件inc_day最近7天内’）中的req_waybillno和gisaoicode，
-- 2、利用aoi id（只用gisaoisrc=norm和chkn下的AOI）到表dm_gis.cms_aoi_village（最新inc_day）中获取village_guid 
drop table if exists dm_gis.tmp_village_gisaoisrc_dest;
create table dm_gis.tmp_village_gisaoisrc_dest stored as parquet  as 
select t0.waybill_no,t0.inc_day,t0.dest_dist_code,t0.consignee_addr,t0.aoi_id    
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr,aoi_id,aoi_code  from dm_gis.village_tt_waybill_hook where inc_day='$firstDay' and aoi_id is not null and aoi_id<>'' and aoi_code is not null and aoi_code<>'' ) as t0 
left join ( select req_waybillno,gisaoicode from dm_gis.gis_rds_omsto where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay' and req_waybillno is not null and req_waybillno<>'' and (gisaoisrc='norm' or gisaoisrc='chkn') group by req_waybillno,gisaoicode ) as t1 
on t0.waybill_no=t1.req_waybillno and t0.aoi_code=t1.gisaoicode
where t1.req_waybillno is not null 
;

drop table if exists dm_gis.tmp_village_guid_dest;
create table dm_gis.tmp_village_guid_dest  stored as parquet  as 
select t0.waybill_no,t0.inc_day,t0.dest_dist_code,t0.consignee_addr,t0.aoi_id,t1.village_guid   
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr,aoi_id  from dm_gis.tmp_village_gisaoisrc_dest where  aoi_id is not null and aoi_id<>'' ) as t0 
left join  (select city_code,aoi_id,village_guid from dm_gis.tmp_village_cms_aoi_village where village_guid is not null and village_guid<>'')  as t1 
on t0.dest_dist_code=t1.city_code and t0.aoi_id=t1.aoi_id 
;

insert overwrite table  dm_gis.village_dest_addr_decode partition(inc_day) 
select waybill_no,consignee_addr,name_p as province,name_c as city,name_d as county,name_t as town,name as vilname,area_code as vilcode,adcode_t as town_adcode,class_code,distant,dest_dist_code,inc_day   
from dm_gis.tmp_village_guid_dest as t0 
left join ( select guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant from dm_gis.tmp_village_emap_district_village ) as t1 
on t0.village_guid=t1.guid
where t1.guid is not null 
;

-- 2.1.2 从历史解析日志中获取 
drop table if exists dm_gis.tmp_village_dest_addr_decode_log;
create table dm_gis.tmp_village_dest_addr_decode_log stored as parquet as 
select t0.waybill_no,t0.inc_day,t0.dest_dist_code,t0.consignee_addr  
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr from dm_gis.village_tt_waybill_hook where inc_day='$firstDay'  ) as t0 
left join ( select waybill_no from dm_gis.village_dest_addr_decode where inc_day='$firstDay'  group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
;

insert into  dm_gis.village_dest_addr_decode partition(inc_day) 
select t1.waybill_no,t1.consignee_addr,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,
t1.dest_dist_code,t1.inc_day   
from dm_gis.tmp_village_village_log_flink_res as t0 
left join ( select waybill_no,inc_day,dest_dist_code,consignee_addr from dm_gis.tmp_village_dest_addr_decode_log  ) as t1 
on t0.p_city_code=t1.dest_dist_code and t0.p_address=t1.consignee_addr  
where t1.waybill_no is not null 
;



-- 2.1.3 调接口获取
-- http://gis-gw.intsit.sfdc.com.cn:9080/village/

-- 
mainClass="com.sf.gis.scala.tals.app.VillageAddrLevel5AddrDestApp"
int_sql="
select t0.waybill_no,t0.inc_day,t0.dest_dist_code as yd_citycode,t0.consignee_addr as yd_addr  
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr from dm_gis.village_tt_waybill_hook where inc_day='$firstDay' ) as t0 
left join ( select waybill_no from dm_gis.village_dest_addr_decode where inc_day='$firstDay'  group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
"
out_table="dm_gis.village_dest_addr_decode"
pall_num=20000



-- 2.1.4 运单5级地址去重
insert overwrite table  dm_gis.village_dest_addr_decode partition(inc_day) 
select waybill_no,consignee_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,dest_dist_code,inc_day
from (select waybill_no,consignee_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,inc_day,dest_dist_code,
row_number() over(partition by waybill_no,dest_dist_code,inc_day order by vilcode desc) as rn from dm_gis.village_dest_addr_decode where inc_day='$firstDay' 
) as t where t.rn=1 
;


-- 2.2 是否进村派件
-- 当城乡分类代码不为220时，填入否；当城乡分类代码=220时，判断驿站编码，是否为空.
-- 1.不为空,则利用驿站编码和村adcode与表 （inc_day选最新）ods_yjy.station_info_d 的own_code和village_code匹配，都命中则为是，否则为否
-- 2.为空,否则用小哥经纬度到杨俊提个的坐标查询行政村服务获取村adcode与前面获取的村adcode进行匹配，命中则为是，否则为否

-- 20230427 v2.4 改
-- 当城乡分类代码不为220、210时，填入否；当城乡分类代码=220、210时，判断驿站编码，是否为空：
-- 1.不为空：
--   1）驿站收派件经纬度不为空：利用驿站收件经纬度跑接口http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=200获取行政村list，若行政村list中存在areaCode与村code匹配则为是，否则为否
--   2）驿站收派件经纬度为空：则利用驿站编码和村adcode与表 （inc_day选最新）ods_yjy.station_info_d 的own_code和village_code匹配，都命中则为是，否则为否
-- 2.为空：否则用小哥轨迹到杨俊提个的坐标查询行政村服务获取村adcode与前面获取的村adcode进行匹配，命中则为是，否则为否

-- 20230506 v2.5 改 去掉 2）驿站收派件经纬度为空：则利用驿站编码和村adcode与表 （inc_day选最新）ods_yjy.station_info_d 的own_code和village_code匹配，都命中则为是，否则为否

-- 20230523 v2.8 改 
-- 当城乡分类代码不为220、210时，填入否；当城乡分类代码=220、210时，判断驿站编码，是否为空：
-- 1.不为空：利用驿站收件经纬度跑接口http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=1000获取行政村list，若行政村list中存在areaCode与村code匹配则为是，否则为否
-- 2.为空：否则用小哥轨迹到http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=500获取村adcode list，与前面获取的村adcode进行匹配，存在命中则为是，否则为否

-- 20230817 v3.2 改
-- 当城乡分类代码不为220、210时，填入否；当城乡分类代码=220、210时，判断驿站编码，是否为空：
-- 1.不为空：利用驿站收件经纬度跑接口http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=1000获取行政村list，若行政村list中存在areaCode与村code匹配则为是，否则为否
-- 2.为空：用揽收时间的前后5分钟的最靠近收件时间的5个（不足5个则全取）小哥轨迹到http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=500获取村adcode list，与前面获取的村adcode进行匹配，存在命中则为是，否则为否

-- 20231020 v3.4 改
-- 当城乡分类代码不为220、210时，填入否；当城乡分类代码=220、210时，判断是否集派，是则为1（是否集收回刷更新变为1，则该项也纠正为1），否则往下走
-- 0.判断是否同城件，若为同城件则用waybill_no获取表dm_gis.sf_order_rider_track中的driver_track数据，并解析出时间戳和经纬度，
-- 用于跑接口http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=500获取行政村list若行政村list中存在areaCode与村code匹配则为是，否则为否；
-- 不为同城件则，判断驿站编码是否为空：


-- 2.2.1 驿站编码 不为空 (使用时用class_code='220'筛选)
drop table if exists dm_gis.village_dest_owncode_isnotnull;
create table dm_gis.village_dest_owncode_isnotnull(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码',
dest_dist_code STRING COMMENT "分区城市代码",
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
lonlat_tag string COMMENT '出入库标签'
)
COMMENT "驿站编码不为空（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- insert overwrite table dm_gis.village_dest_owncode_isnotnull partition(inc_day) 
-- select 
-- waybill_no,class_code,vilcode,own_code,dest_dist_code,inc_day 
-- from (select mailno,own_code from ods_yjy.yjy_mailno_kb where inc_day='$firstDay' and type='派件') as t0 
-- left join (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_addr_decode where inc_day='$firstDay' ) as t1 
-- on t0.mailno=t1.waybill_no 
-- where t1.waybill_no is not null
-- ;

alter table dm_gis.village_dest_owncode_isnotnull add columns (operate_longitude string COMMENT '驿站经度') cascade;
alter table dm_gis.village_dest_owncode_isnotnull add columns (operate_latitude string COMMENT '驿站纬度') cascade;

-- 2023.10.20 出入库标签
alter table dm_gis.village_dest_owncode_isnotnull add columns (lonlat_tag string COMMENT '出入库标签') cascade;

-- 
insert overwrite table dm_gis.village_dest_owncode_isnotnull partition(inc_day) 
select 
waybill_no,class_code,vilcode,own_code,dest_dist_code,operate_longitude,operate_latitude,lonlat_tag,inc_day 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_addr_decode where inc_day='$firstDay' ) as t0  
left join
(select mailno,own_code,
if(pj_operate_longitude<>'' and pj_operate_longitude<>'nan',pj_operate_longitude,operate_longitude) as operate_longitude,
if(pj_operate_latitude<>'' and pj_operate_latitude<>'nan',pj_operate_latitude,operate_latitude) as operate_latitude,
case when (pj_operate_longitude<>'' and pj_operate_longitude<>'nan') then '1' 
when (operate_longitude<>'' and operate_longitude<>'nan') then '2' 
else '' end as lonlat_tag 
from dm_yjy.yjy_mailno_kb where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay' and type='派件') as t1 
on t0.waybill_no=t1.mailno 
where t1.mailno is not null
;


-- 坐标系转换（百度转高德）
drop table if exists dm_gis.village_dest_lonlat_transform;
create table dm_gis.village_dest_lonlat_transform(
bd_lon string comment '百度经度',
bd_lat string comment '百度纬度',
gd_lon_lat string comment '高德经纬坐标'
)
COMMENT "坐标系转换（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLonLatTransformApp"
int_sql="select operate_longitude as bd_lon,operate_latitude as bd_lat from dm_gis.village_dest_owncode_isnotnull where inc_day='$firstDay' and operate_longitude<>'' and operate_longitude<>'nan' group by operate_longitude,operate_latitude"
out_table="dm_gis.village_dest_lonlat_transform" 


insert overwrite table dm_gis.village_dest_owncode_isnotnull partition(inc_day='$firstDay') 
select waybill_no,class_code,vilcode,own_code,dest_dist_code,gd_lon as operate_longitude,gd_lat as operate_latitude,lonlat_tag   
from (select 
waybill_no,class_code,vilcode,own_code,dest_dist_code,operate_longitude,operate_latitude,lonlat_tag,inc_day 
from dm_gis.village_dest_owncode_isnotnull where inc_day='$firstDay' ) as t0 
left join (select bd_lon,bd_lat,split(gd_lon_lat,',')[0] as gd_lon,split(gd_lon_lat,',')[1] as gd_lat from dm_gis.village_dest_lonlat_transform where inc_day='$firstDay') as t1 
on t0.operate_longitude=t1.bd_lon and t0.operate_latitude=t1.bd_lat 
;


-- 集派和同城识别进村 (同城件，需要先用同城件的经纬坐标跑接口判断是否进村)
-- 当城乡分类代码不为220、210时，填入否；当城乡分类代码=220、210时，判断是否集派，是则为1（是否集收回刷更新变为1，则该项也纠正为1），否则往下走
-- 0.判断是否同城件

-- 集派 判断为是的
drop table if exists dm_gis.village_dest_jp_res;
create table dm_gis.village_dest_jp_res(
waybill_no string comment '运单号',
class_code string comment '类型',
vilcode string comment '村编码'
)
COMMENT "集派判断上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_jp_res partition(inc_day='$firstDay')
select 
t0.waybill_no,class_code,vilcode 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_addr_decode where inc_day='$firstDay' and class_code in ('220','210')  ) as t0  
left join (select waybill_no,sending_tm from dm_gis.tmp_village_dest_waybill_no_cnt_res ) as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.sending_tm 
where t1.waybill_no is not null 
;

-- 集派 判断为否的(关联同城件的经纬坐标)
drop table if exists dm_gis.village_dest_driver_track;
create table dm_gis.village_dest_driver_track(
waybill_no string comment '运单号',
driver_track string comment '轨迹坐标',
class_code string comment '类型',
vilcode string comment '村编码'
)
COMMENT "集派判断上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_driver_track partition(inc_day='$firstDay')
select t3.waybill_no,driver_track,class_code,vilcode  
from (select 
t0.waybill_no,class_code,vilcode,inc_day 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_addr_decode where inc_day='$firstDay' and class_code in ('220','210')  ) as t0  
left join (select waybill_no,sending_tm from dm_gis.tmp_village_dest_waybill_no_cnt_res) as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.sending_tm 
where t1.waybill_no is null 
) as t3 
left join (
select waybill_no,driver_track from dm_gis.sf_order_rider_track where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay'
) as t4 
on t3.waybill_no=t4.waybill_no
;
 


-- 同城件经纬坐标判断为是的（调接口）
drop table if exists dm_gis.village_dest_driver_track_res;
create table dm_gis.village_dest_driver_track_res(
waybill_no string comment '运单号',
driver_track string comment '轨迹坐标',
class_code string comment '类型',
vilcode string comment '村编码',
tc_res  string comment '判断结果'
)
COMMENT "集派判断上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
; 


drop table if exists dm_gis.village_dest_driver_track_api;
create table dm_gis.village_dest_driver_track_api(
vilcode string comment '村编码',
driver_track string comment '轨迹坐标',
tc_res  string comment '判断结果'
)
COMMENT "同城件经纬坐标判断进村上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
; 



mainClass="com.sf.gis.scala.tals.app.VillageLatLngDriverTrackRadius500App"
int_sql="select 
vilcode,driver_track,get_json_object(lonlat_json,'$.x') as zx , get_json_object(lonlat_json,'$.y') as zy
from (select vilcode,driver_track from dm_gis.village_dest_driver_track where inc_day='$firstDay' and vilcode is not null and vilcode<>'' and driver_track<>'' group by vilcode,driver_track) as t
lateral view explode(split(regexp_replace(regexp_replace(driver_track, '\\}\\, \\{','\\}\\;\\{'),'\\[|\\]',''),'\\;')) dt as lonlat_json 
"
out_table="dm_gis.village_dest_driver_track_api" 
pall_num=10000
inc_day='$firstDay'



insert overwrite table dm_gis.village_dest_driver_track_res partition(inc_day='$firstDay')
select waybill_no,t0.driver_track,class_code,t0.vilcode,tc_res from dm_gis.village_dest_driver_track as t0 
left join (select vilcode,driver_track,tc_res from dm_gis.village_dest_driver_track_api where inc_day='$firstDay') as t1 
on t0.vilcode=t1.vilcode and t0.driver_track=t1.driver_track
;





-- 20230427 v2.4 改
-- 20231020 集派、同城件 判断为是的先过滤
-- 1）驿站收派件经纬度不为空：利用驿站收件经纬度跑接口  
create table dm_gis.village_dest_owncode_isnotnull_api_res(
vilcode string comment '村编码',
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
match_res string COMMENT '是否',
dest_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "驿站编码不为空（派件）接口判断结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadiusApp"
int_sql="select vilcode,operate_longitude,operate_latitude,dest_dist_code as dist_code,inc_day from (
select 
t0.waybill_no,vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day 
from (
select waybill_no,vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnotnull 
where inc_day='$firstDay' and class_code in ('220','210') and vilcode is not null and vilcode<>'' and operate_longitude is not null and operate_longitude<>'' and operate_latitude is not null and operate_latitude<>''
) as t0 
left join (select waybill_no from dm_gis.village_dest_jp_res where inc_day='$firstDay' 
union all 
select waybill_no from dm_gis.village_dest_driver_track_res where inc_day='$firstDay' and  tc_res='1' ) as t1 
on t0.waybill_no=t1.waybill_no 
where  t1.waybill_no is null 
) as t
group by vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day "
out_table="dm_gis.village_dest_owncode_isnotnull_api_res" 
pall_num=10000



-- 2）驿站收派件经纬度为空：则利用驿站编码和村adcode与表 （inc_day选最新）ods_yjy.station_info_d 的own_code和village_code匹配
-- 2.2.1.1 own_code和village_code匹配是否命中
drop table if exists dm_gis.village_dest_owncode_isnotnull_res;
create table dm_gis.village_dest_owncode_isnotnull_res(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码',
own_code_check  string comment '',
village_code  string comment '',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码不为空（派件）结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnotnull_res partition(inc_day) 
select waybill_no,class_code,vilcode,t0.own_code,t1.own_code as own_code_1,village_code,dest_dist_code,inc_day
from (select waybill_no,class_code,vilcode,own_code,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnotnull where inc_day='$firstDay'  and class_code in ('220','210') and (operate_longitude is null or trim(operate_longitude)='' or operate_latitude is null or trim(operate_latitude)='') ) as t0 
left join ( select own_code,village_code from ods_yjy.station_info_d where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') and village_code<>'' group by own_code,village_code ) as t1 
on trim(t0.own_code)=trim(t1.own_code) and trim(t0.vilcode)=trim(t1.village_code)  
;


-- 2.2.2 驿站编码 为空
-- 20230817 v3.2 改   用揽收时间的前后5分钟的最靠近收件时间的3个（不足3个则全取）小哥轨迹
drop table if exists dm_gis.village_dest_owncode_isnull;
create table dm_gis.village_dest_owncode_isnull(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_owncode_isnull partition(inc_day) 
select t0.waybill_no,class_code,vilcode,dest_dist_code,inc_day
from ( select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_addr_decode where inc_day='$firstDay' and class_code in ('220','210') ) as t0 
left join (select waybill_no from dm_gis.village_dest_owncode_isnotnull where inc_day='$firstDay' and class_code in ('220','210') group by waybill_no) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
;


-- 2.2.2.1 运单关联获取signin_tm,deliver_emp_code
drop table if exists dm_gis.village_dest_owncode_isnull_waybill;
create table dm_gis.village_dest_owncode_isnull_waybill(
waybill_no string comment '运单号',
signin_tm string comment '收件时间',
deliver_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取signin_tm,deliver_emp_code（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill partition(inc_day) 
select 
t0.waybill_no,t0.signin_tm,t0.deliver_emp_code,
t1.class_code,t1.vilcode,t1.dest_dist_code,
t1.inc_day 
from ( select waybill_no,signin_tm,deliver_emp_code,dest_dist_code,inc_day from dm_gis.village_tt_waybill_hook where inc_day='$firstDay' ) as t0 
left join (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull where inc_day='$firstDay' ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 2.2.2.2 运单关联小哥轨迹 
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_tmp;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_tmp(
waybill_no string comment '运单号',
deliver_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
zx string comment '经度',
zy string comment '纬度',
signin_tm string comment '收件时间',
tm string comment '小哥轨迹时间',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联小哥轨迹（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_tmp partition(inc_day) 
select 
waybill_no,deliver_emp_code,class_code,vilcode,zx,zy,signin_tm,tm,t1.dest_dist_code,t1.inc_day 
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(signin_tm) as signin_tm,deliver_emp_code,class_code,vilcode,dest_dist_code,inc_day
from dm_gis.village_dest_owncode_isnull_waybill where inc_day='$firstDay'  and signin_tm<>'' ) as t1 
on t0.un=t1.deliver_emp_code
where signin_tm-60*5<=tm and signin_tm+60*5>=tm
;

-- 2.2.2.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg;
create table dm_gis.village_dest_owncode_isnull_waybill_xg(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期的轨迹点（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg partition(inc_day) 
select waybill_no,zx,zy,dest_dist_code,inc_day
from (
select waybill_no,inc_day,dest_dist_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,inc_day,dest_dist_code,zx,zy,abs(signin_tm-tm) as diff_tm from dm_gis.village_dest_owncode_isnull_waybill_xg_tmp where inc_day='$firstDay'  ) as t  
) as t0 where t0.rn=1 
;


-- -- 2.2.2.4 调坐标查询行政村接口 
-- drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_res;
-- create table dm_gis.village_dest_owncode_isnull_waybill_xg_res (
-- zx string comment '',
-- zy string comment '',
-- vil_code string comment '',
-- vil_name string comment '',
-- guid string comment '',
-- dest_dist_code STRING COMMENT "分区城市代码" 
-- )
-- COMMENT "跑经纬坐标查询行政村（派件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;

-- -- 
-- mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageDestApp"
-- int_sql="select zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg where inc_day='$firstDay'  group by zx,zy,inc_day,dest_dist_code"
-- out_table="dm_gis.village_dest_owncode_isnull_waybill_xg_res" 
-- pall_num=10000

-- 2.2.2.4 调坐标查询行政村接口 (派件收件一起跑)
drop table if exists dm_gis.village_owncode_isnull_waybill_xg;
create table dm_gis.village_owncode_isnull_waybill_xg(
zx string comment '经度',
zy string comment '纬度',
dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期的轨迹点" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- v2.8 更改  先调接口获取adcode list
-- drop table if exists dm_gis.village_owncode_isnull_waybill_xg_res;
-- create table dm_gis.village_owncode_isnull_waybill_xg_res (
-- zx string comment '',
-- zy string comment '',
-- vil_code string comment '',
-- vil_name string comment '',
-- guid string comment '',
-- dist_code STRING COMMENT "分区城市代码" 
-- )
-- COMMENT "跑经纬坐标查询行政村" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;

drop table if exists dm_gis.village_owncode_isnull_waybill_xg_json;
create table dm_gis.village_owncode_isnull_waybill_xg_json (
zx string comment '',
zy string comment '',
json_str string comment '接口返回的的json数据',
dist_code STRING COMMENT "分区城市代码",
api_res string comment '接口返回结果'  
)
COMMENT "跑经纬坐标查询行政村" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
insert overwrite table dm_gis.village_owncode_isnull_waybill_xg partition(inc_day) 
select zx,zy,dist_code,inc_day
from (
select zx,zy,dest_dist_code as dist_code,inc_day
from (
select zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg where inc_day='$firstDay' ) as a
union all 
select zx,zy,src_dist_code as dist_code,inc_day 
from (
select zx,zy,src_dist_code,inc_day from dm_gis.village_src_owncode_isnull_waybill_xg where inc_day='$firstDay'  ) as b
) as c 
group by zx,zy,dist_code,inc_day 
;

-- -- 
-- mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageApp"
-- int_sql="select zx,zy,dist_code,inc_day from dm_gis.village_owncode_isnull_waybill_xg where inc_day='$firstDay' "
-- out_table="dm_gis.village_owncode_isnull_waybill_xg_res" 
-- pall_num=10000

-- v2.8 更改
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadius500App"
int_sql="select zx,zy,dist_code,inc_day from dm_gis.village_owncode_isnull_waybill_xg where inc_day='$firstDay' "
out_table="dm_gis.village_owncode_isnull_waybill_xg_json" 
pall_num=10000




-- 2.2.2.4  驿站编码 为空 res 
-- drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_hy;
-- create table dm_gis.village_dest_owncode_isnull_waybill_xg_hy (
-- waybill_no string comment '',
-- zx string comment '',
-- zy string comment '',
-- vil_code string comment '',
-- vil_name string comment '',
-- guid string comment '',
-- dest_dist_code STRING COMMENT "分区城市代码"  
-- )
-- COMMENT "驿站编码为空小哥还原（派件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;

-- insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_hy partition(inc_day)  
-- select waybill_no,t0.zx,t0.zy,vil_code,vil_name,guid,dest_dist_code,inc_day from (select waybill_no,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg where inc_day='$firstDay'  ) as t0 
-- left join ( select zx,zy,vil_code,vil_name,guid from dm_gis.village_owncode_isnull_waybill_xg_res where inc_day='$firstDay'  ) as t1 
-- on t0.zx=t1.zx and t0.zy=t1.zy 
-- ;

drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_hy;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_hy (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "驿站编码为空小哥还原（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode stored as parquet  as 
select  zx,zy,get_json_object(ss.col,'$.objCode') as obj_code
from (select zx,zy,
split(regexp_replace(regexp_extract(json_str,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis.village_owncode_isnull_waybill_xg_json where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
;

drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set stored as parquet  as 
select 
zx,zy,collect_set(obj_code) as obj_code_set 
from dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode where obj_code is not null and obj_code<>'' group by zx,zy 
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_hy partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,dest_dist_code,inc_day 
from (select waybill_no,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;


-- 
-- drop table if exists dm_gis.village_dest_owncode_isnull_res;
-- create table dm_gis.village_dest_owncode_isnull_res (
-- waybill_no string comment '',
-- class_code string comment '',
-- vilcode string comment '',
-- zx string comment '',
-- zy string comment '',
-- vil_code string comment '',
-- vil_name string comment '',
-- guid string comment '',
-- dest_dist_code STRING COMMENT "分区城市代码"  
-- )
-- COMMENT "驿站编码为空res（派件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;


-- insert overwrite table dm_gis.village_dest_owncode_isnull_res partition(inc_day)  
-- select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,vil_name,guid,dest_dist_code,inc_day 
-- from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull where inc_day='$firstDay'  ) as t0 
-- left join (select waybill_no,zx,zy,vil_code,vil_name,guid from dm_gis.village_dest_owncode_isnull_waybill_xg_hy where inc_day='$firstDay'   ) as t1 
-- on t0.waybill_no=t1.waybill_no
-- ;

drop table if exists dm_gis.village_dest_owncode_isnull_res;
create table dm_gis.village_dest_owncode_isnull_res (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
adcode_isin string comment 'adcode是否在adcode list中',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "驿站编码为空res（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 判断 adcode是不是在array中，例如： if(array_contains(obj_code_set,'620723106206'),1,0)
insert overwrite table dm_gis.village_dest_owncode_isnull_res partition(inc_day)  
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,dest_dist_code,inc_day 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull where inc_day='$firstDay' ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_dest_owncode_isnull_waybill_xg_hy where inc_day='$firstDay' ) as t1 
on t0.waybill_no=t1.waybill_no
;

------------------------------------------------------------------------------
-- 20230817 v3.2 改  
------------------------------------------------------------------------------
-- 对上面用了最近1个小哥轨迹未判断出进村的部分，再用揽收时间的前后5分钟的最靠近收件时间的3个（不足3个则全取）小哥轨迹
-- top3 小哥轨迹 （派件） 去掉已经识别成功的部分
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_top3;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_top3(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期top3的轨迹点（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_top3 partition(inc_day) 
select waybill_no,zx,zy,dest_dist_code,inc_day
from (
select waybill_no,inc_day,dest_dist_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select t0.waybill_no,inc_day,dest_dist_code,zx,zy,abs(signin_tm-tm) as diff_tm 
from (select waybill_no,inc_day,dest_dist_code,zx,zy,signin_tm,tm from dm_gis.village_dest_owncode_isnull_waybill_xg_tmp where inc_day='$firstDay' ) as t0 
left join (select waybill_no from dm_gis.village_dest_owncode_isnull_res where inc_day='$firstDay' and adcode_isin='1'  ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
 ) as t  
) as t0 where t0.rn<=3 
;

-- top3 小哥轨迹 （收件） 去掉已经识别成功的部分
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_top3;
create table dm_gis.village_src_owncode_isnull_waybill_xg_top3(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度',
src_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期top3的轨迹点（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_top3 partition(inc_day) 
select waybill_no,zx,zy,src_dist_code,inc_day  
from (
select waybill_no,src_dist_code,inc_day ,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select t0.waybill_no,src_dist_code,inc_day ,zx,zy,abs(consigned_tm-tm) as diff_tm 
from (select waybill_no,inc_day,src_dist_code,zx,zy,consigned_tm,tm from dm_gis.village_src_owncode_isnull_waybill_xg_tmp where inc_day='$firstDay' ) as t0 
left join (select waybill_no from dm_gis.village_src_owncode_isnull_res where inc_day='$firstDay' and adcode_isin='1'  ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
) as t  
) as t0 where t0.rn<=3 
;


-- 需要再跑的小哥轨迹（派件收件一起）  top3去掉top1的部分
drop table if exists dm_gis.village_owncode_isnull_waybill_xg_top3;
create table dm_gis.village_owncode_isnull_waybill_xg_top3(
zx string comment '经度',
zy string comment '纬度',
dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期的top3轨迹点" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table if exists dm_gis.village_owncode_isnull_waybill_xg_top3_json;
create table dm_gis.village_owncode_isnull_waybill_xg_top3_json (
zx string comment '',
zy string comment '',
json_str string comment '接口返回的的json数据',
dist_code STRING COMMENT "分区城市代码",
api_res string comment '接口返回结果'
)
COMMENT "跑经纬坐标查询行政村(top3)" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_owncode_isnull_waybill_xg_top3 partition(inc_day) 
select t0.zx,t0.zy,t0.dist_code,t0.inc_day from (
select zx,zy,dist_code,inc_day
from (
select zx,zy,dest_dist_code as dist_code,inc_day
from (
select zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay' ) as a
union all 
select zx,zy,src_dist_code as dist_code,inc_day 
from (
select zx,zy,src_dist_code,inc_day from dm_gis.village_src_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay'  ) as b
) as c 
group by zx,zy,dist_code,inc_day 
) as t0 
left join (select zx,zy,dist_code,inc_day from dm_gis.village_owncode_isnull_waybill_xg where inc_day='$firstDay' ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy and t0.dist_code=t1.dist_code 
where t1.inc_day is null 
;


-- 跑 小哥轨迹获取村编码list 接口 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadius500App"
int_sql="select zx,zy,dist_code,inc_day from dm_gis.village_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay' "
out_table="dm_gis.village_owncode_isnull_waybill_xg_top3_json" 
pall_num=20000


-- 小哥轨迹 运单 村编码list  还原 （派件）
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "驿站编码为空小哥还原（派件）(top3)" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 小哥轨迹 运单 村编码list  还原 （收件）
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy;
create table dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空小哥还原（收件）(top3)" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

--  解析adcode list （派件收件一起） (shell脚本需要把\\换成\\\\)
drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode stored as parquet as 
select  zx,zy,get_json_object(ss.col,'$.objCode') as obj_code
from (select zx,zy,
split(regexp_replace(regexp_extract(json_str,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis.village_owncode_isnull_waybill_xg_top3_json where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
;

drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set stored as parquet as 
select 
zx,zy,collect_set(obj_code) as obj_code_set 
from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode where obj_code is not null and obj_code<>'' group by zx,zy 
;

-- 还原 （派件）
insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,dest_dist_code,inc_day 
from (select waybill_no,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;

-- 还原 （收件）
insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,src_dist_code,inc_day  
from (select waybill_no,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set  ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;


-- top3结果整合top1结果 （派件）
insert overwrite table dm_gis.village_dest_owncode_isnull_res partition(inc_day)  
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day,row_number() over(partition by waybill_no order by adcode_isin desc) as rn 
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_res where inc_day='$firstDay' and adcode_isin='1' 
union all 
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,dest_dist_code,inc_day 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_res where inc_day='$firstDay' and (adcode_isin is null or adcode_isin<>'1') ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy where inc_day='$firstDay' ) as t1 
on t0.waybill_no=t1.waybill_no 
) as t 
) as tt where tt.rn=1
;

-- top3结果整合top1结果 （收件）
insert overwrite table dm_gis.village_src_owncode_isnull_res partition(inc_day) 
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day 
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day,row_number() over(partition by waybill_no order by adcode_isin desc) as rn 
from (    
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day from dm_gis.village_src_owncode_isnull_res where inc_day='$firstDay' and adcode_isin='1' 
union all 
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,src_dist_code,inc_day   
from (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_res where inc_day='$firstDay' and (adcode_isin is null or adcode_isin<>'1') ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy where inc_day='$firstDay'   ) as t1 
on t0.waybill_no=t1.waybill_no 
) as t 
) as tt where tt.rn=1
;


------------------------------------------------------------------------------------
------------------------------------------------------------------------------------


-- 3 是否进乡镇上门
-- 城乡代码为220或是否进村上门为‘是’标记为‘否’；对其他的，用小哥轨迹坐标调坐标查询aoi接口（参数外延200m距离）,判断是否为乡镇上门，是：接口返回aoicode中有运单aoicode，否：接口返回aoicode中无运单aoicode

-- 3.1 运单关联获取 signin_tm,deliver_emp_code,aoi_id,aoi_code
drop table if exists dm_gis.village_dest_classcode_waybill;
create table dm_gis.village_dest_classcode_waybill (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
signin_tm string comment '',
deliver_emp_code string comment '',
aoi_id string comment '',
aoi_code string comment '',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_dest_classcode_waybill partition(inc_day)  
select t1.waybill_no,t1.class_code,t1.vilcode,t0.signin_tm,t0.deliver_emp_code,aoi_id,aoi_code,t1.dest_dist_code,t1.inc_day  
from ( select waybill_no,signin_tm,deliver_emp_code,aoi_id,aoi_code,dest_dist_code,inc_day from dm_gis.village_tt_waybill_hook where inc_day='$firstDay'   ) as t0 
left join (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_addr_decode where inc_day='$firstDay'  and (class_code is null or class_code not in ('220','210','110','111') ) ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 3.2 运单关联小哥轨迹  
drop table if exists dm_gis.village_dest_classcode_waybill_xg_tmp;
create table dm_gis.village_dest_classcode_waybill_xg_tmp (
waybill_no string comment '',
aoi_id string comment '',
aoi_code string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
signin_tm string comment '',
tm string comment '',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_classcode_waybill_xg_tmp partition(inc_day)  
select 
waybill_no,aoi_id,aoi_code,class_code,vilcode,zx,zy,signin_tm,tm,t1.dest_dist_code,t1.inc_day 
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(signin_tm) as signin_tm,deliver_emp_code,aoi_id,aoi_code,class_code,vilcode,dest_dist_code,inc_day
from dm_gis.village_dest_classcode_waybill where inc_day='$firstDay' and deliver_emp_code<>'' and signin_tm<>'' ) as t1 
on t0.un=t1.deliver_emp_code
where signin_tm-60*5<=tm and signin_tm+60*5>=tm
;

-- 3.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_dest_classcode_waybill_xg;
create table dm_gis.village_dest_classcode_waybill_xg (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_dest_classcode_waybill_xg partition(inc_day)  
select waybill_no,aoi_code,zx,zy,dest_dist_code,inc_day
from (
select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,abs(signin_tm-tm) as diff_tm from dm_gis.village_dest_classcode_waybill_xg_tmp where inc_day='$firstDay' ) as t  
) as t0 where t0.rn=1 
;

-- -- 3.4 调坐标查询aoi接口
-- drop table if exists dm_gis.village_dest_classcode_waybill_xg_res;
-- create table dm_gis.village_dest_classcode_waybill_xg_res (
-- aoi_code string comment '',
-- lgt string comment '',
-- lat string comment '',
-- matchres string comment '',
-- dest_dist_code STRING COMMENT "分区城市代码" 
-- )
-- COMMENT "跑经纬坐标查询aoi（派件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;


-- mainClass="com.sf.gis.scala.tals.app.VillageLatLngAoiDestApp"
-- int_sql="select aoi_code,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_classcode_waybill_xg where inc_day='$firstDay' and aoi_code<>'' group by aoi_code,zx,zy,inc_day,dest_dist_code"
-- out_table="dm_gis.village_dest_classcode_waybill_xg_res" 
-- pall_num=100000


-- 3.4 将派件与收件进行合并后再跑接口
drop table if exists dm_gis.village_classcode_waybill_xg;
create table dm_gis.village_classcode_waybill_xg (
aoi_code string comment '',
zx string comment '',
zy string comment '',
dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "运单关联获取" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table if exists dm_gis.village_classcode_waybill_xg_res;
create table dm_gis.village_classcode_waybill_xg_res (
aoi_code string comment '',
lgt string comment '',
lat string comment '',
matchres string comment '',
dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "跑经纬坐标查询aoi" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
insert overwrite table dm_gis.village_classcode_waybill_xg partition(inc_day) 
select aoi_code,zx,zy,dist_code,inc_day
from (
select aoi_code,zx,zy,dest_dist_code as dist_code,inc_day
from (
select aoi_code,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_classcode_waybill_xg where inc_day='$firstDay' and aoi_code<>'' ) as a
union all 
select aoi_code,zx,zy,src_dist_code as dist_code,inc_day 
from (
select aoi_code,zx,zy,src_dist_code,inc_day from dm_gis.village_src_classcode_waybill_xg where inc_day='$firstDay' and aoi_code<>''  ) as b
) as c 
group by aoi_code,zx,zy,dist_code,inc_day 
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngAoiApp"
int_sql="select aoi_code,zx,zy,dist_code,inc_day from dm_gis.village_classcode_waybill_xg where inc_day='$firstDay' "
out_table="dm_gis.village_classcode_waybill_xg_res" 
pall_num=100000


-- 3.5 能关联小哥轨迹的运单查询aoi后判断是否上门的结果
drop table if exists dm_gis.village_dest_classcode_waybill_xg_aoi_res;
create table dm_gis.village_dest_classcode_waybill_xg_aoi_res (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
matchres string comment '',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "跑经纬坐标查询aoi（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_classcode_waybill_xg_aoi_res partition(inc_day)  
select waybill_no,t0.aoi_code,zx,zy,matchres,dest_dist_code,inc_day from (select waybill_no,aoi_code,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_classcode_waybill_xg where inc_day='$firstDay' ) as t0 
left join (select aoi_code,lgt,lat,matchres from dm_gis.village_classcode_waybill_xg_res where inc_day='$firstDay' ) as t1 
on t0.aoi_code=t1.aoi_code and t0.zx=t1.lgt and t0.zy=t1.lat 
;
 




-- 4 快递上门结果表 (派件)
drop table if exists dm_gis.village_dest_kdsm_res;
create table dm_gis.village_dest_kdsm_res (
dest_hq_code	string comment '大区代码',
dest_area_code	string comment '地区代码',
area_name	string comment '地区名称',
dest_zone_code	string comment '网点代码',
dept_name	string comment '网点名称',
waybill_no	string comment '单号',
deliver_emp_code	string comment '派件人工号',
real_product_code	string comment '产品名称',
meterage_weight_qty	string comment '计费重量',
pay_cust_type	string comment '付费客户类型',
service_prod_code	string comment '增值服务代码',
all_fee_rmb	string comment '总收入（rmb）',
freight_monthly_acct_code	string comment '月结账号',
is_yj	string comment '是否月结',
aoi_code	string comment 'AOI编码',
aoi_name	string comment 'AOI名称',
aoi_type_name	string comment 'aoi类型名称',
aoi_area_code	string comment 'AOI区域',
province	string comment '省',
city	string comment '市/市辖区',
county	string comment '区/县',
town	string comment '镇/乡',
town_adcode	string comment '镇adcode',
vil_name	string comment '行政村/社区',
vil_code	string comment '村adcode',
class_code	string comment '城乡分类代码',
own_code	string comment '驿站编码',
is_jcpj	string comment '是否进村派件',
is_jxzpj	string comment '是否为乡镇上门派件',
yd_type	string comment '运单类型',
distance	string comment '收件地址到派件网点的距离',
wd_type	string comment '网点类型',
dest_dist_code STRING COMMENT "分区城市代码",
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
signin_tm string comment'派送时间',
add_fee string comment'乡村达收入',
is_jp string comment'是否集派',
is_tcj string COMMENT '是否同城件',
lonlat_tag string comment'出入库标签'
)
COMMENT "行政村快递上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
alter table dm_gis.village_dest_kdsm_res add columns (operate_longitude string COMMENT '驿站经度');
alter table dm_gis.village_dest_kdsm_res add columns (operate_latitude string COMMENT '驿站纬度');
-- v2.9 新增 signin_tm
alter table dm_gis.village_dest_kdsm_res add columns(signin_tm string comment'派送时间') ; 
-- 20230721 v3.1 增加 乡村达收入 
alter table dm_gis.village_dest_kdsm_res add columns(add_fee string comment'乡村达收入') ; 
-- 20231020 v3.4 增加 是否集派 是否同城件 出入库标签
alter table dm_gis.village_dest_kdsm_res add columns(is_jp string comment'是否集派') cascade;
alter table dm_gis.village_dest_kdsm_res add columns(is_tcj string comment'是否同城件') cascade;
alter table dm_gis.village_dest_kdsm_res add columns(lonlat_tag string comment'出入库标签') cascade;
-- 2023.11.21  补贴标签(subsidy_type)  补贴更新(subsidy)
alter table dm_gis.village_dest_kdsm_res add columns(subsidy_type string comment'补贴标签') cascade;
alter table dm_gis.village_dest_kdsm_res add columns(subsidy string comment'补贴更新') cascade;




-- 20230721 v3.1 取乡村达收入数据
drop table if exists dm_gis.tmp_tt_waybill_addition_dest;
create table dm_gis.tmp_tt_waybill_addition_dest stored as parquet  as 
select waybill_no,add_fee 
from (
select waybill_no,get_json_object(addition_values,'$.additionalFee') as add_fee from ods_shiva_oms_sws.tt_waybill_addition 
where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-15),'-','') and inc_day<='$firstDay'  
 and addition_key='RURAL_EXPRESS' 
 and get_json_object(addition_values,'$.additionalFee') is not null  
 and get_json_object(addition_values,'$.additionalFee')  > 0 
 ) as t group by waybill_no,add_fee 
 ;

-- 
insert overwrite table  dm_gis.village_dest_kdsm_res partition(inc_day) 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vilname,vilcode,class_code,
own_code,is_jcpj,is_jxzpj,
case when (class_code in ('220','210')) or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type ,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,
if(is_yj='1',null,add_fee) as add_fee,
is_jp,is_tcj,lonlat_tag,
'' as subsidy_type,'' as subsidy,
inc_day
from (
select 
dest_hq_code,dest_area_code,t5.area_name,dest_zone_code,t5.dept_name,t0.waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
case when freight_monthly_acct_code<>'' then '1' else '0' end as is_yj,
t0.aoi_code,t0.aoi_name,aoi_type_name,t6.aoi_area_code,
t1.province,t1.city,t1.county,t1.town,t1.town_adcode,t1.vilname,t1.vilcode,t1.class_code,
t7.own_code,
-- v2.5 修改 case when t8.match_res='1' or t2.own_code_check is not null or (t3.vil_code is not null and t3.vilcode=t3.vil_code) then '1' else '0' end as is_jcpj,
-- v2.8 修改 case when t8.match_res='1' or (t3.vil_code is not null and t3.vilcode=t3.vil_code) then '1' else '0' end as is_jcpj,
case when t12.waybill_no is not null or t13.waybill_no is not null or t8.match_res='1' or adcode_isin='1' then '1' else '0' end as is_jcpj,
case when t4.matchres='1'  then '1' else '0' end as is_jxzpj,
distance,
case when t5.dept_type_code='DB05-DLD' then '代理' else '自营' end as wd_type,
t7.operate_longitude,t7.operate_latitude,
signin_tm,
t9.add_fee,
if(t10.sending_tm is not null,'1','0') as is_jp,
if(t11.waybill_no is not null,'1','0') as is_tcj,
t7.lonlat_tag,
t0.inc_day,t0.dest_dist_code 
from (
select waybill_no,signin_tm,dest_hq_code,dest_area_code,dest_zone_code,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
dest_county,consignee_addr,
dest_dist_code,inc_day from dm_gis.village_tt_waybill_hook where inc_day='$firstDay'   ) as t0 
left join ( select waybill_no,consignee_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,dest_dist_code,inc_day 
from dm_gis.village_dest_addr_decode where inc_day='$firstDay'  ) as t1 
on t0.waybill_no=t1.waybill_no 
left join (select waybill_no,class_code,vilcode,own_code,own_code_check,village_code,dest_dist_code,inc_day
from dm_gis.village_dest_owncode_isnotnull_res where inc_day='$firstDay'  ) as t2 
on t0.waybill_no=t2.waybill_no 
left join (select waybill_no,class_code,vilcode,inc_day,dest_dist_code,zx,zy,adcode_isin  
from dm_gis.village_dest_owncode_isnull_res where inc_day='$firstDay'    ) as t3 
on t0.waybill_no=t3.waybill_no 
left join (select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,matchres from dm_gis.village_dest_classcode_waybill_xg_aoi_res where inc_day='$firstDay'  ) as t4 
on t0.waybill_no=t4.waybill_no 
left join (select dept_code,area_name,dept_name,dept_type_code from (select dept_code,area_name,dept_name,dept_type_code,row_number() over(partition by dept_code order by inc_day desc)  as rn 
from  dim.dim_dept_info_df where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') ) as b where b.rn=1 ) as t5 
on t0.dest_zone_code=t5.dept_code 
left join dm_tc_waybillinfo.aoi_area_aoi as t6 
on t0.aoi_code=t6.aoi_id 
left join (select waybill_no,own_code,dest_dist_code,vilcode,operate_longitude,operate_latitude,lonlat_tag from dm_gis.village_dest_owncode_isnotnull where inc_day='$firstDay'  ) as t7 
on t0.waybill_no=t7.waybill_no 
left join (select dest_dist_code,vilcode,operate_longitude,operate_latitude,match_res from dm_gis.village_dest_owncode_isnotnull_api_res where inc_day='$firstDay' ) as t8 
on t7.dest_dist_code=t8.dest_dist_code and t7.vilcode=t8.vilcode and t7.operate_longitude=t8.operate_longitude and t7.operate_latitude=t8.operate_latitude 
left join dm_gis.tmp_tt_waybill_addition_dest as t9 
on t0.waybill_no=t9.waybill_no 
left join (select waybill_no,sending_tm from dm_gis.tmp_village_dest_waybill_no_cnt_res ) as t10 
on t0.waybill_no=t10.waybill_no and t0.inc_day=t10.sending_tm 
left join (
select waybill_no from dm_gis.sf_order_rider_track where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay'
) as t11 
on t0.waybill_no=t11.waybill_no 
left join (select waybill_no from dm_gis.village_dest_jp_res where inc_day='$firstDay') as t12 
on t0.waybill_no=t12.waybill_no 
left join (select waybill_no from dm_gis.village_dest_driver_track_res where inc_day='$firstDay' and  tc_res='1') as t13 
on t0.waybill_no=t13.waybill_no 
) as t 
;


drop table if exists dm_gis.tmp_tt_waybill_addition_dest;






-----------------------------------------------------------------------------------------------------------------------------------
-- 统计表开发
-----------------------------------------------------------------------------------------------------------------------------------

-- --------------------------------------
-- 前提：派件和收件明细表都有了
-- 网点、镇、村统计件量

create table dm_gis.village_kdsm_zone_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "网点统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


create table dm_gis.village_kdsm_town_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
town string comment '乡镇名称',
town_adcode string comment '乡镇code',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "乡镇统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


create table dm_gis.village_kdsm_vil_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
town string comment '乡镇名称',
town_adcode string comment '乡镇code',
vil_name string comment '村名称',
vil_code string comment '村code',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "村统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- -- 
-- drop table if exists dm_gis.tmp_village_kdsm_vil_stat_dest;
-- create table dm_gis.tmp_village_kdsm_vil_stat_dest as 
-- select 
-- dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,
-- count(1) as dest_cnt 
-- from 
-- (select 
-- dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,waybill_no  
-- from dm_gis.village_dest_kdsm_res 
-- where inc_day='$firstDay' and dest_area_code<>'' and city<>'' and dest_zone_code<>''  )as t 
-- group by dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code 
-- ;

-- drop table if exists dm_gis.tmp_village_kdsm_vil_stat_src;
-- create table dm_gis.tmp_village_kdsm_vil_stat_src as 
-- select 
-- src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,
-- count(1) as src_cnt 
-- from 
-- (select 
-- src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no  
-- from dm_gis.village_src_kdsm_res 
-- where inc_day='$firstDay' and src_area_code<>'' and city<>'' and source_zone_code<>'' )as t 
-- group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code 
-- ;

-- insert overwrite dm_gis.village_kdsm_vil_stat partition(inc_day='$firstDay')
-- select 
-- if(t0.area_code is not null,t0.area_code,t1.area_code) as area_code,
-- if(t0.dist_code is not null,t0.dist_code,t1.dist_code) as dist_code,
-- if(t0.city is not null,t0.city,t1.city) as city,
-- if(t0.zone_code is not null,t0.zone_code,t1.zone_code) as zone_code,
-- if(t0.town is not null,t0.town,t1.town) as town,
-- if(t0.town_adcode is not null,t0.town_adcode,t1.town_adcode) as town_adcode,
-- if(t0.vil_name is not null,t0.vil_name,t1.vil_name) as vil_name,
-- if(t0.vil_code is not null,t0.vil_code,t1.vil_code) as vil_code,
-- if(t0.dest_cnt is not null,t0.dest_cnt,0 ) as dest_cnt,
-- if(t1.src_cnt is not null,t1.src_cnt,0 ) as src_cnt 
-- from 
-- (
-- select dest_area_code as area_code,dest_dist_code as dist_code,city,dest_zone_code as zone_code,town,town_adcode,vil_name,vil_code,dest_cnt 
-- from dm_gis.tmp_village_kdsm_vil_stat_dest ) as t0
-- full outer join 
-- (
-- select src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,src_cnt 
-- from dm_gis.tmp_village_kdsm_vil_stat_src 
-- ) as t1  
-- on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code 
-- and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code 
-- ;

--  20230331 
-- dm_gis.village_kdsm_vil_stat新增四个字段含义：
-- 城乡分类代码：class_code
-- 是否妥投驿站：is_ttyz
-- 进村派件量：dest_jcpj_cnt
-- 进村收件量：src_jcpj_cnt
-- 
alter table dm_gis.village_kdsm_vil_stat add columns (class_code string COMMENT '城乡分类代码');
alter table dm_gis.village_kdsm_vil_stat add columns (is_ttyz string COMMENT '是否妥投驿站');
alter table dm_gis.village_kdsm_vil_stat add columns (dest_jcpj_cnt string COMMENT '进村派件量');
alter table dm_gis.village_kdsm_vil_stat add columns (src_jcpj_cnt string COMMENT '进村收件量');

ALTER TABLE dm_gis.village_kdsm_vil_stat CHANGE COLUMN src_jcpj_cnt src_jcpj_cnt STRING COMMENT '进村收件量';

-- 20230418
-- dm_gis.village_kdsm_vil_stat 新增两个字段
-- 折前收入：all_fee_rmb
-- 折后收入：tt_fee_zh_all_fee
alter table dm_gis.village_kdsm_vil_stat add columns (all_fee_rmb string COMMENT '折前收入');
alter table dm_gis.village_kdsm_vil_stat add columns (tt_fee_zh_all_fee string COMMENT '折后收入');


drop table if exists dm_gis.tmp_village_kdsm_vil_stat_dest;
create table dm_gis.tmp_village_kdsm_vil_stat_dest stored as parquet as
select
dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz,
count(1) as dest_cnt,sum(is_jcpj) as dest_jcpj_cnt
from
(select
dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,if(own_code is not null,'是','否') is_ttyz,is_jcpj
from dm_gis.village_dest_kdsm_res
where inc_day='$firstDay' and dest_area_code<>'' and city<>'' and dest_zone_code<>'' )as t
group by dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz
;

drop table if exists dm_gis.tmp_village_kdsm_vil_stat_src;
create table dm_gis.tmp_village_kdsm_vil_stat_src stored as parquet as
select
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz,
count(1) as src_cnt,sum(is_jcpj) as src_jcpj_cnt,sum(all_fee_rmb) as all_fee_rmb,sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from
(select
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,if(own_code is not null,'是','否') is_ttyz,is_jcpj,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.village_src_kdsm_res
where inc_day='$firstDay' and src_area_code<>'' and city<>'' and source_zone_code<>'' ) as t
group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz
;

insert overwrite dm_gis.village_kdsm_vil_stat partition(inc_day='$firstDay')
select
if(t0.area_code is not null,t0.area_code,t1.area_code) as area_code,
if(t0.dist_code is not null,t0.dist_code,t1.dist_code) as dist_code,
if(t0.city is not null,t0.city,t1.city) as city,
if(t0.zone_code is not null,t0.zone_code,t1.zone_code) as zone_code,
if(t0.town is not null,t0.town,t1.town) as town,
if(t0.town_adcode is not null,t0.town_adcode,t1.town_adcode) as town_adcode,
if(t0.vil_name is not null,t0.vil_name,t1.vil_name) as vil_name,
if(t0.vil_code is not null,t0.vil_code,t1.vil_code) as vil_code,
if(t0.dest_cnt is not null,t0.dest_cnt,0 ) as dest_cnt,
if(t1.src_cnt is not null,t1.src_cnt,0 ) as src_cnt,

if(t0.class_code is not null,t0.class_code,t1.class_code) as class_code,
if(t0.is_ttyz is not null,t0.is_ttyz,t1.is_ttyz) as is_ttyz,
if(t0.dest_jcpj_cnt is not null,t0.dest_jcpj_cnt,0 ) as dest_jcpj_cnt,
if(t1.src_jcpj_cnt is not null,t1.src_jcpj_cnt,0 ) as src_jcpj_cnt,

if(t1.all_fee_rmb is not null,t1.all_fee_rmb,0 ) as all_fee_rmb,
if(t1.tt_fee_zh_all_fee is not null,t1.tt_fee_zh_all_fee,0 ) as tt_fee_zh_all_fee  

from
(
select dest_area_code as area_code,dest_dist_code as dist_code,city,dest_zone_code as zone_code,town,town_adcode,vil_name,vil_code,dest_cnt,class_code,is_ttyz,dest_jcpj_cnt
from dm_gis.tmp_village_kdsm_vil_stat_dest ) as t0
full outer join
(
select src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,src_cnt,class_code,is_ttyz,src_jcpj_cnt,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.tmp_village_kdsm_vil_stat_src
) as t1
on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code
and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code and t0.class_code=t1.class_code and t0.is_ttyz=t1.is_ttyz
;



insert overwrite dm_gis.village_kdsm_town_stat partition(inc_day='$firstDay') 
select 
area_code,dist_code,city,zone_code,town,town_adcode,
sum(dest_cnt)  as dest_cnt,
sum(src_cnt)  as src_cnt 
from dm_gis.village_kdsm_vil_stat 
where inc_day='$firstDay' 
group by 
area_code,dist_code,city,zone_code,town,town_adcode
;

insert overwrite dm_gis.village_kdsm_zone_stat partition(inc_day='$firstDay') 
select 
area_code,dist_code,city,zone_code,
sum(dest_cnt)  as dest_cnt,
sum(src_cnt)  as src_cnt 
from dm_gis.village_kdsm_vil_stat 
where inc_day='$firstDay' 
group by 
area_code,dist_code,city,zone_code
;


drop table if exists dm_gis.tmp_village_kdsm_vil_stat_dest;
drop table if exists dm_gis.tmp_village_kdsm_vil_stat_src;

-- ------------------------------------------
-- 统计表 （20230302 增加网点类型）
-- 建表
create table dm_gis.village_kdsm_stat (
hq_code string comment '大区代码',
area_code string comment '地区代码',
area_name string comment '地区名称',
dist_code string comment '城市编码',
wd_type string comment '网点类型',
pj_all_cnt int comment '派件总量',
pj_xz_cnt int comment '派件乡镇件量',
pj_xz_sm_cnt int comment '派件乡镇上门件量',
pj_xz_sm_ratio double comment '派件乡镇上门率',
pj_xzc_cnt int comment '派件行政村件量',
pj_xzc_jc_cnt int comment '派件行政村进村件量',
pj_xzc_jc_ratio double comment '派件行政村进村率',
pj_yjc_10_cnt int comment '派件大于10km应进村件量',
pj_yjc_10_30_cnt int comment '派件10-30km应进村件量',
pj_jc_10_30_cnt int comment '派件10-30km进村件量',
pj_yjc_30_50_cnt int comment '派件30-50km应进村件量',
pj_jc_30_50_cnt int comment '派件30-50km进村件量',
pj_yjc_50_cnt int comment '派件大于50km应进村件量',
pj_jc_50_cnt int comment '派件大于50km进村件量',
pj_no_cnt int comment '派件未识别件量',
pj_no_ratio double comment '派件未识别率',
sj_all_cnt  int comment '收件总量',
sj_xz_cnt int comment '收件乡镇件量',
sj_xz_sm_cnt int comment '收件乡镇上门件量',
sj_xz_sm_ratio double comment '收件乡镇上门率',
sj_xzc_cnt int comment '收件行政村件量',
sj_xzc_jc_cnt int comment '收件行政村进村件量',
sj_xzc_jc_ratio double comment '收件行政村进村率',
sj_no_cnt  int comment '收件未识别件量',
sj_no_ratio   double comment '收件未识别率' 
)
COMMENT '行政村收派件统计表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

--派件
drop table if exists dm_gis.tmp_village_kdsm_dest_res_stat_1;
create table dm_gis.tmp_village_kdsm_dest_res_stat_1 stored as parquet as 
select 
dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type,
count(1) as pj_all_cnt,
sum(case when yd_type='乡镇' then 1 else 0 end ) as pj_xz_cnt,
sum(case when yd_type='乡镇' and is_jxzpj='是' then 1 else 0 end ) as pj_xz_sm_cnt,
sum(case when yd_type='行政村' then 1 else 0 end ) as pj_xzc_cnt,
sum(case when yd_type='行政村' and is_jcpj='是' then 1 else 0 end ) as pj_xzc_jc_cnt,
count(distinct case when distance>=10000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_10_cnt,
count(distinct case when distance>=10000 and distance<30000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_10_30_cnt,
count(distinct case when distance>=10000 and distance<30000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_10_30_cnt,
count(distinct case when distance>=30000 and distance<50000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_30_50_cnt,
count(distinct case when distance>=30000 and distance<50000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_30_50_cnt,
count(distinct case when distance>=50000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_50_cnt,
count(distinct case when distance>=50000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_50_cnt,
sum(case when yd_type is null or yd_type='' then 1 else 0 end ) as pj_no_cnt
from (
select 
dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type,
yd_type,is_jxzpj,cast(distance as int) as distance,is_jcpj,aoi_code  
from dm_gis.village_dest_kdsm_res 
where inc_day='$firstDay' and dest_hq_code<>'' and dest_area_code<>'' and dest_dist_code<>'' 
) as t 
group by dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type 
;

--收件
drop table if exists dm_gis.tmp_village_kdsm_src_res_stat_1;
create table dm_gis.tmp_village_kdsm_src_res_stat_1 stored as parquet as 
select 
src_hq_code,src_area_code,area_name,src_dist_code,wd_type,
count(1) as sj_all_cnt,
sum(case when yd_type='乡镇' then 1 else 0 end ) as sj_xz_cnt,
sum(case when yd_type='乡镇' and is_jxzpj='是' then 1 else 0 end ) as sj_xz_sm_cnt,
sum(case when yd_type='行政村' then 1 else 0 end ) as sj_xzc_cnt,
sum(case when yd_type='行政村' and is_jcpj='是' then 1 else 0 end ) as sj_xzc_jc_cnt,
sum(case when yd_type is null or yd_type='' then 1 else 0 end ) as sj_no_cnt
from (
select 
src_hq_code,src_area_code,area_name,src_dist_code,wd_type,
yd_type,is_jxzpj,is_jcpj,aoi_code  
from dm_gis.village_src_kdsm_res 
where inc_day='$firstDay' and src_hq_code<>'' and src_area_code<>'' and src_dist_code<>'' 
) as t 
group by src_hq_code,src_area_code,area_name,src_dist_code,wd_type  
;


---- 汇聚得筛选表
drop table if exists dm_gis.tmp_village_kdsm_stat_dist_code;
create table dm_gis.tmp_village_kdsm_stat_dist_code stored as parquet as 
select 
hq_code,area_code,area_name,dist_code,wd_type 
from (
select dest_hq_code as hq_code,dest_area_code as area_code,area_name,dest_dist_code as dist_code,wd_type 
from dm_gis.tmp_village_kdsm_dest_res_stat_1 
union all 
select src_hq_code as hq_code,src_area_code as area_code,area_name,src_dist_code as dist_code,wd_type  
from dm_gis.tmp_village_kdsm_src_res_stat_1 
) as t 
group by hq_code,area_code,area_name,dist_code,wd_type   
;

insert overwrite table dm_gis.village_kdsm_stat partition(inc_day='$firstDay')
select 
t0.hq_code,t0.area_code,t0.area_name,t0.dist_code,t0.wd_type,
t1.pj_all_cnt,
t1.pj_xz_cnt,
t1.pj_xz_sm_cnt,
t1.pj_xz_sm_ratio,
t1.pj_xzc_cnt,
t1.pj_xzc_jc_cnt,
t1.pj_xzc_jc_ratio,
t1.pj_yjc_10_cnt,
t1.pj_yjc_10_30_cnt,
t1.pj_jc_10_30_cnt,
t1.pj_yjc_30_50_cnt,
t1.pj_jc_30_50_cnt,
t1.pj_yjc_50_cnt,
t1.pj_jc_50_cnt,
t1.pj_no_cnt,
t1.pj_no_ratio,
t2.sj_all_cnt,
t2.sj_xz_cnt,
t2.sj_xz_sm_cnt,
t2.sj_xz_sm_ratio,
t2.sj_xzc_cnt,
t2.sj_xzc_jc_cnt,
t2.sj_xzc_jc_ratio,
t2.sj_no_cnt,
t2.sj_no_ratio   
from dm_gis.tmp_village_kdsm_stat_dist_code as t0 
left join (
select dest_hq_code as hq_code,dest_area_code as area_code,area_name,dest_dist_code as dist_code,wd_type,
pj_all_cnt,
pj_xz_cnt,
pj_xz_sm_cnt,
pj_xz_sm_cnt/pj_xz_cnt as pj_xz_sm_ratio,
pj_xzc_cnt,
pj_xzc_jc_cnt,
pj_xzc_jc_cnt/pj_xzc_cnt as pj_xzc_jc_ratio,
pj_yjc_10_cnt,
pj_yjc_10_30_cnt,
pj_jc_10_30_cnt,
pj_yjc_30_50_cnt,
pj_jc_30_50_cnt,
pj_yjc_50_cnt,
pj_jc_50_cnt,
pj_no_cnt,
pj_no_cnt/pj_all_cnt as pj_no_ratio 
from dm_gis.tmp_village_kdsm_dest_res_stat_1 ) as t1 
on t0.hq_code=t1.hq_code and t0.area_code=t1.area_code and t0.area_name=t1.area_name and t0.dist_code=t1.dist_code and t0.wd_type=t1.wd_type   
left join (
select src_hq_code as hq_code,src_area_code as area_code,area_name,src_dist_code as dist_code,wd_type, 
sj_all_cnt,sj_xz_cnt,sj_xz_sm_cnt,
sj_xz_sm_cnt/sj_xz_cnt as sj_xz_sm_ratio,
sj_xzc_cnt,sj_xzc_jc_cnt,
sj_xzc_jc_cnt/sj_xzc_cnt as sj_xzc_jc_ratio,
sj_no_cnt,
sj_no_cnt/sj_all_cnt as sj_no_ratio   
from dm_gis.tmp_village_kdsm_src_res_stat_1 
) as t2 
on t0.hq_code=t2.hq_code and t0.area_code=t2.area_code and t0.area_name=t2.area_name and t0.dist_code=t2.dist_code and t0.wd_type=t2.wd_type  
;

drop table if exists dm_gis.tmp_village_kdsm_stat_dist_code;
drop table if exists dm_gis.tmp_village_kdsm_src_res_stat_1;
drop table if exists dm_gis.tmp_village_kdsm_dest_res_stat_1;
-- 200230509  v2.6 修改 1.接口http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=1000；把radius入参改为1000




-- 2023.12.27 新增 收派件统计数据
create table dm_gis.village_kdsm_stat_cnt_fee_di(
province	string comment '省',
city	string comment '市名称',
county	string comment '区',
town	string comment '乡镇名称',
town_adcode	string comment '乡镇code',
vil_name	string comment '村名称',
vil_code	string comment '村code',
class_code	string comment 'Class code',
distance	string comment '村-镇距离',
zone_code	string comment '网点代码',
dept_type_code	string comment '网点类型代码',
dept_type_name	string comment '网点类型名称',
wd_type	string comment '网点合作方式',
area_code	string comment '地区代码',
dist_code	string comment '城市代码',
is_yj	string comment '是否月结',
pj_cnt	string comment '派件数量',
jcpj_cnt	string comment '进村派件量',
sj_cnt	string comment '收件数量',
jcsj_cnt	string comment '进村收件量',
all_fee_rmb	string comment '折前收入',
tt_fee_zh_all_fee	string comment '折后收入',
jxzpj_cnt	string comment '乡镇上门派件量',
jxzsj_cnt	string comment '乡镇上门收件量'
)
COMMENT '行政村收派件统计表(件量、收入)'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 行政村收派件统计表(件量、收入)
-- 派件
drop table if exists dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1;
create table dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1 stored as parquet as 
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,dest_zone_code,wd_type,dest_area_code,dest_dist_code,is_yj,
count(1) as pj_cnt,sum(is_jcpj) as jcpj_cnt,sum(is_jxzpj) as jxzpj_cnt 
from (select 
if(province<>'',province,'') as province,if(city<>'',city,'') as city,if(county<>'',county,'') as county,if(town<>'',town,'') as town,if(town_adcode<>'',town_adcode,'') as town_adcode,
if(vil_name<>'',vil_name,'') as vil_name,if(vil_code<>'',vil_code,'') as vil_code,if(class_code<>'',class_code,'') as class_code,
if(distance<>'',ROUND(CAST(distance AS DOUBLE),1),'') as distance,if(dest_zone_code<>'',dest_zone_code,'') as dest_zone_code,if(wd_type<>'',wd_type,'') as wd_type,
if(dest_area_code<>'',dest_area_code,'') as dest_area_code,if(dest_dist_code<>'',dest_dist_code,'') as dest_dist_code,if(is_yj<>'',is_yj,'') as is_yj,
if(is_jcpj<>'',is_jcpj,'') as is_jcpj,if(is_jxzpj<>'',is_jxzpj,'') as is_jxzpj 
from dm_gis.village_dest_kdsm_res 
where inc_day='$firstDay' 
) as t 
group by province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,dest_zone_code,wd_type,dest_area_code,dest_dist_code,is_yj 
;

-- 收件
drop table if exists dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1;
create table dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1 stored as parquet as 
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj,
count(1) as sj_cnt,sum(is_jcpj) as jcsj_cnt,sum(is_jxzpj) as jxzsj_cnt,sum(all_fee_rmb) as all_fee_rmb,sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from (select 
if(province<>'',province,'') as province,if(city<>'',city,'') as city,if(county<>'',county,'') as county,if(town<>'',town,'') as town,if(town_adcode<>'',town_adcode,'') as town_adcode,
if(vil_name<>'',vil_name,'') as vil_name,if(vil_code<>'',vil_code,'') as vil_code,if(class_code<>'',class_code,'') as class_code,
if(distance<>'',ROUND(CAST(distance AS DOUBLE),1),'') as distance,if(source_zone_code<>'',source_zone_code,'') as source_zone_code,if(wd_type<>'',wd_type,'') as wd_type,
if(src_area_code<>'',src_area_code,'') as src_area_code,if(src_dist_code<>'',src_dist_code,'') as src_dist_code,if(is_yj<>'',is_yj,'') as is_yj,
if(is_jcpj<>'',is_jcpj,'') as is_jcpj,if(is_jxzpj<>'',is_jxzpj,'') as is_jxzpj,if(all_fee_rmb<>'',all_fee_rmb,'') as all_fee_rmb,if(tt_fee_zh_all_fee<>'',tt_fee_zh_all_fee,'') as tt_fee_zh_all_fee  
from dm_gis.village_src_kdsm_res 
where inc_day='$firstDay' 
) as t 
group by province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj  
;


-- -- 汇聚得筛选表
drop table if exists dm_gis.tmp_village_kdsm_stat_cnt_fee_key;
create table dm_gis.tmp_village_kdsm_stat_cnt_fee_key stored as parquet as 
select 
province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,zone_code,wd_type,area_code,dist_code,is_yj
from (
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,dest_zone_code as zone_code,wd_type,dest_area_code as area_code,dest_dist_code as dist_code,is_yj 
from dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1 
union all 
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code as zone_code,wd_type,src_area_code as area_code,src_dist_code as dist_code,is_yj  
from dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1 
) as t 
group by province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,zone_code,wd_type,area_code,dist_code,is_yj  
;


insert overwrite table dm_gis.village_kdsm_stat_cnt_fee_di partition(inc_day='$firstDay')
select 
t0.province,t0.city,t0.county,t0.town,t0.town_adcode,t0.vil_name,t0.vil_code,t0.class_code,t0.distance,
t0.zone_code,t1.dept_type_code,t1.dept_type_name,
t0.wd_type,t0.area_code,t0.dist_code,t0.is_yj,
pj_cnt,jcpj_cnt,sj_cnt,jcsj_cnt,all_fee_rmb,tt_fee_zh_all_fee,jxzpj_cnt,jxzsj_cnt 
from dm_gis.tmp_village_kdsm_stat_cnt_fee_key as t0 
left join (select dept_code,dept_type_code,dept_type_name from dim.dim_dept_info_df where inc_day='$firstDay' and dept_code<>'' group by dept_code,dept_type_code,dept_type_name 
) as t1 
on t0.zone_code=t1.dept_code 
left join (select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,dest_zone_code,wd_type,dest_area_code,dest_dist_code,is_yj,
pj_cnt,jcpj_cnt,jxzpj_cnt 
from dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1 ) as t2 
on t0.province=t2.province and t0.city=t2.city and t0.county=t2.county and t0.town=t2.town and t0.town_adcode=t2.town_adcode 
and t0.vil_name=t2.vil_name and t0.vil_code=t2.vil_code and t0.class_code=t2.class_code and t0.distance=t2.distance 
and t0.zone_code=t2.dest_zone_code and t0.wd_type=t2.wd_type and t0.area_code=t2.dest_area_code and t0.dist_code=t2.dest_dist_code and t0.is_yj=t2.is_yj 
left join (select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj,
sj_cnt,jcsj_cnt,jxzsj_cnt,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1 ) as t3 
on t0.province=t3.province and t0.city=t3.city and t0.county=t3.county and t0.town=t3.town and t0.town_adcode=t3.town_adcode 
and t0.vil_name=t3.vil_name and t0.vil_code=t3.vil_code and t0.class_code=t3.class_code and t0.distance=t3.distance 
and t0.zone_code=t3.source_zone_code and t0.wd_type=t3.wd_type and t0.area_code=t3.src_area_code and t0.dist_code=t3.src_dist_code and t0.is_yj=t3.is_yj 
;


drop table if exists dm_gis.tmp_village_kdsm_dest_stat_cnt_fee_1;
drop table if exists dm_gis.tmp_village_kdsm_src_stat_cnt_fee_1;
drop table if exists dm_gis.tmp_village_kdsm_stat_cnt_fee_key;





------------------------------------------------------------------------------------------------------------
-- ID：712787  行政村收派件_v2.0_月刷新
------------------------------------------------------------------------------------------------------------
-- dm_gis.village_src_kdsm_res
insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,wd_type,src_dist_code,t1.tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,
subsidy_type,subsidy      
from (
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,
pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,yd_type,wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,
subsidy_type,subsidy      
from dm_gis.village_src_kdsm_res where inc_day='$firstDay' ) as t0 
left join (select waybill_no,tt_fee_zh_all_fee from dm_gis.tt_order_hook where inc_day='$firstDay' group by waybill_no,tt_fee_zh_all_fee) as t1 
on t0.waybill_no=t1.waybill_no
;

-- dm_gis.village_kdsm_vil_stat
insert overwrite table  dm_gis.village_kdsm_vil_stat partition(inc_day='$firstDay')
select t0.area_code,t0.dist_code,t0.city,t0.zone_code,t0.town,t0.town_adcode,t0.vil_name,t0.vil_code,t0.dest_cnt,t0.src_cnt,t0.class_code,t0.is_ttyz,t0.dest_jcpj_cnt,t0.src_jcpj_cnt,
t1.all_fee_rmb,t1.tt_fee_zh_all_fee 
from (select area_code,dist_code,city,zone_code,town,town_adcode,vil_name,vil_code,dest_cnt,src_cnt,class_code,is_ttyz,dest_jcpj_cnt,src_jcpj_cnt,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.village_kdsm_vil_stat where inc_day='$firstDay' ) as t0 
left join (
select
src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz,
sum(all_fee_rmb) as all_fee_rmb,sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from
(select
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,if(own_code is not null,'是','否') is_ttyz,is_jcpj,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.village_src_kdsm_res
where inc_day='$firstDay' and src_area_code<>'' and city<>'' and source_zone_code<>'' ) as t
group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz
) as t1 
on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code
and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code and t0.class_code=t1.class_code and t0.is_ttyz=t1.is_ttyz
;


-- dm_gis.village_kdsm_stat_cnt_fee_di
insert overwrite table dm_gis.village_kdsm_stat_cnt_fee_di partition(inc_day='$firstDay')
select 
t0.province,t0.city,t0.county,t0.town,t0.town_adcode,t0.vil_name,t0.vil_code,t0.class_code,t0.distance,
t0.zone_code,t0.dept_type_code,t0.dept_type_name,
t0.wd_type,t0.area_code,t0.dist_code,t0.is_yj,
pj_cnt,jcpj_cnt,sj_cnt,jcsj_cnt,all_fee_rmb,t1.tt_fee_zh_all_fee,jxzpj_cnt,jxzsj_cnt 
from (select  
province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,
zone_code,dept_type_code,dept_type_name,
wd_type,area_code,dist_code,is_yj,
pj_cnt,jcpj_cnt,sj_cnt,jcsj_cnt,all_fee_rmb,tt_fee_zh_all_fee,jxzpj_cnt,jxzsj_cnt 
from dm_gis.village_kdsm_stat_cnt_fee_di where inc_day='$firstDay' ) as t0 
left join (
select province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj,
sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from (select 
if(province<>'',province,'') as province,if(city<>'',city,'') as city,if(county<>'',county,'') as county,if(town<>'',town,'') as town,if(town_adcode<>'',town_adcode,'') as town_adcode,
if(vil_name<>'',vil_name,'') as vil_name,if(vil_code<>'',vil_code,'') as vil_code,if(class_code<>'',class_code,'') as class_code,
if(distance<>'',ROUND(CAST(distance AS DOUBLE),1),'') as distance,if(source_zone_code<>'',source_zone_code,'') as source_zone_code,if(wd_type<>'',wd_type,'') as wd_type,
if(src_area_code<>'',src_area_code,'') as src_area_code,if(src_dist_code<>'',src_dist_code,'') as src_dist_code,if(is_yj<>'',is_yj,'') as is_yj,
if(is_jcpj<>'',is_jcpj,'') as is_jcpj,if(is_jxzpj<>'',is_jxzpj,'') as is_jxzpj,if(all_fee_rmb<>'',all_fee_rmb,'') as all_fee_rmb,if(tt_fee_zh_all_fee<>'',tt_fee_zh_all_fee,'') as tt_fee_zh_all_fee  
from dm_gis.village_src_kdsm_res 
where inc_day='$firstDay' 
) as t 
group by province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,source_zone_code,wd_type,src_area_code,src_dist_code,is_yj  
) as t1 
on t0.province=t1.province and t0.city=t1.city and t0.county=t1.county and t0.town=t1.town and t0.town_adcode=t1.town_adcode 
and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code and t0.class_code=t1.class_code and t0.distance=t1.distance 
and t0.zone_code=t1.source_zone_code and t0.wd_type=t1.wd_type and t0.area_code=t1.src_area_code and t0.dist_code=t1.src_dist_code and t0.is_yj=t1.is_yj 
;






------------------------------------------------------------------------------------------------------------
-- 集派回刷近30天
------------------------------------------------------------------------------------------------------------
-- 20231020 集派回刷近30天数据（增加进村派件为是的量）

insert overwrite table dm_gis.village_dest_kdsm_res partition(inc_day='')
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
case when (class_code in ('220','210')) or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type ,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag,
subsidy_type,subsidy 
from (select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,t0.waybill_no,deliver_emp_code,real_product_code,meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,
if(class_code in ('220','210') and t1.sending_tm is not null, '1' ,is_jcpj) as is_jcpj,
if(class_code in ('220','210') and t1.sending_tm is not null, '0' ,is_jxzpj) as is_jxzpj,
yd_type,distance,wd_type,dest_dist_code,
operate_longitude,operate_latitude,signin_tm,add_fee,is_jp,is_tcj,lonlat_tag,subsidy_type,subsidy 
from (select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,yd_type,distance,wd_type,dest_dist_code,
operate_longitude,operate_latitude,signin_tm,add_fee,is_jp,is_tcj,lonlat_tag,subsidy_type,subsidy,inc_day 
from 
dm_gis.village_dest_kdsm_res where inc_day='' ) as t0 
left join (select waybill_no,sending_tm from dm_gis.tmp_village_dest_waybill_no_cnt_res group by waybill_no,sending_tm) as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.sending_tm 
) as t 
;



------------------------------------------------------------------------------------------------------------
-- 补贴标签 
------------------------------------------------------------------------------------------------------------
-- 2023.11.21  新增字段  补贴标签(subsidy_type)  补贴更新(subsidy)
-- dm_ifs.ifs_fct_township_gather_pick_deliver_dtl_mi	subsidy_type	
-- 1.利用运单号关联该表的inc_day相同且pd_flag=2时的waybill_no，命中则获取subsidy_type，否则为空；更新时间，上游表更新后刷新
-- 2.利用运单号关联该表的inc_day相同且pd_flag=2时的waybill_no，命中则获取subsidy，否则为空；更新时间，上游表更新后刷新 
insert overwrite table dm_gis.village_dest_kdsm_res partition(inc_day='$firstDay') 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,t0.waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag,
subsidy_type,subsidy 
from (select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag 
from dm_gis.village_dest_kdsm_res  where inc_day='$firstDay' ) as t0 
left join (select waybill_no,subsidy_type,subsidy from dm_ifs.dm_ifs_fct_township_gather_pick_deliver_dtl_di where inc_day='$firstDay' and pd_flag='2' and subsidy_type<>'集收' group by waybill_no,subsidy_type,subsidy) as t1 
on t0.waybill_no=t1.waybill_no
;
