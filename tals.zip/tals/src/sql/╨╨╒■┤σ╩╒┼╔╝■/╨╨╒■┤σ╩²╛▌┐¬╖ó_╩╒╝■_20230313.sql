-- 
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- 需求： id: 1585280  【偏远乡村派件上门】快递进村收派件数据统计_V2.1 
-- @author 张小琼 （01416344）
-- Created on 2023-02-15
-- 任务信息： 668258	行政村收派件_20230222
-- 

-- 1、数据准备

-- 1.1 运单
-- 源：dm_gis.tt_order_hook  收件
-- dm_gis.village_tt_order_hook (v2.2 新增tt_fee_zh_all_fee)
drop table if exists dm_gis.village_tt_order_hook;
create table dm_gis.village_tt_order_hook(
waybill_no string comment '运单号',
consigned_tm string comment '寄件时间',
src_hq_code string comment '目的地经营本部（大区）',
src_area_code string comment '目的地区部（地区代码）',
source_zone_code string comment '目的地网点代码（网点代码）',
consignee_emp_code string comment '收件员',
real_product_code string comment '产品代码',
meterage_weight_qty string comment '计费重量',
pay_cust_type string comment '付费客户类型',
service_prod_code string comment '增值服务代码',
all_fee_rmb string comment '总收入',
freight_monthly_acct_code string comment '月结账号',
aoi_id string comment 'aoi id',
aoi_code string comment 'aoi编码',
aoi_name string comment 'aoi名称',
aoi_type_name string comment 'aoi类型名称',
src_county string comment '目的地区/县/镇',
consignor_addr  string comment '寄件地址',
src_dist_code STRING COMMENT '分区城市代码',
tt_fee_zh_all_fee string comment '折后收入' 
)
COMMENT "行政村运单（寄件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- v2.2 新增tt_fee_zh_all_fee
alter table dm_gis.village_tt_order_hook add columns(tt_fee_zh_all_fee string comment'折后收入') ; 

-- v2.9 利用运单号关联ods_kafka_fvp.fvp_core_fact_route_op中inc_day相同且opcode=54的waybillno，命中则获取baruploadtm填入表中
-- select waybillno,from_unixtime(cast(cast(baruploadtm as bigint)/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as barupload_tm 
-- from ods_kafka_fvp.fvp_core_fact_route_op 
-- where inc_day='$firstDay' and opcode='54'

set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;

insert overwrite table  dm_gis.village_tt_order_hook partition(inc_day) 
select 
waybill_no,
if(barupload_tm is not null,barupload_tm,consigned_tm) as consigned_tm,
src_hq_code,src_area_code,source_zone_code,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
src_county,consignor_addr,src_dist_code,tt_fee_zh_all_fee,
inc_day 
from (select waybill_no,consigned_tm,src_hq_code,src_area_code,source_zone_code,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
src_county,consignor_addr,src_dist_code,tt_fee_zh_all_fee,
inc_day  
from dm_gis.tt_order_hook where inc_day='$firstDay' 
) as t0 
left join (select waybillno,from_unixtime(cast(cast(baruploadtm as bigint)/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as barupload_tm 
from ods_kafka_fvp.fvp_core_fact_route_op 
where inc_day='$firstDay' and opcode='54' group by waybillno,baruploadtm ) as t1 
on t0.waybill_no=t1.waybillno 
;


-- 1.9 是否集收	
-- ods_dcs.tt_edcs_hive_commission_detail_old（以该表最新数据，回刷主表的最近30天内数据）		
-- 1.筛选inc_day=主表的inc_day的scene_type= 1 and audit_type=1获取subtract_type、billing_version_no、sending_tm、takeover_tm和waybill_no，
-- 若waybill_no有多个，则取subtract_type不等于’2’且billing_version_no最大的
-- 3.利用takeover_tm作为分区匹配主表的inc_day（限制最近30天内），且waybill_no匹配主表的waybill_no，命中则返回1，否则返回0

-- 计算waybill_no有多个的
drop table if exists dm_gis.tmp_village_src_waybill_no_cnt_more ;
create table dm_gis.tmp_village_src_waybill_no_cnt_more stored as parquet as 
select waybill_no,cnt 
from (
select waybill_no,count(1) as cnt 
from ods_dcs.tt_edcs_hive_commission_detail_old 
where inc_day='$firstDay' 
and scene_type='1' and audit_type='1' 
group by waybill_no
) as t where cnt>1
;

drop table if exists dm_gis.tmp_village_src_waybill_no_cnt_1 ;
create table dm_gis.tmp_village_src_waybill_no_cnt_1 stored as parquet as 
select t0.waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from (
select waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from ods_dcs.tt_edcs_hive_commission_detail_old 
where inc_day='$firstDay' 
and scene_type='1' and audit_type='1' 
and unix_timestamp(takeover_tm,'yyyy-MM-dd HH:mm:ss')>unix_timestamp(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-30),'yyyy-MM-dd')
) as t0 
left join dm_gis.tmp_village_src_waybill_no_cnt_more as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null
;

drop table if exists dm_gis.tmp_village_src_waybill_no_cnt_2 ;
create table dm_gis.tmp_village_src_waybill_no_cnt_2 stored as parquet as 
select t0.waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from (
select waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from ods_dcs.tt_edcs_hive_commission_detail_old 
where inc_day='$firstDay' 
and scene_type='1' and audit_type='1' 
and subtract_type<>'2'
) as t0 
left join dm_gis.tmp_village_src_waybill_no_cnt_more as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

drop table if exists dm_gis.tmp_village_src_waybill_no_cnt_3 ;
create table dm_gis.tmp_village_src_waybill_no_cnt_3 stored as parquet as 
select 
waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type 
from (
select waybill_no,subtract_type,billing_version_no,sending_tm,takeover_tm,scene_type,audit_type,
row_number() over(partition by waybill_no order by billing_version_no desc ) as rn 
from dm_gis.tmp_village_src_waybill_no_cnt_2 
) as t 
where t.rn=1 
and unix_timestamp(takeover_tm,'yyyy-MM-dd HH:mm:ss')>unix_timestamp(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-30),'yyyy-MM-dd')
;


drop table if exists dm_gis.tmp_village_src_waybill_no_cnt_res ;
create table dm_gis.tmp_village_src_waybill_no_cnt_res stored as parquet as 
select waybill_no,replace(substr(takeover_tm,1,10),'-','') as takeover_tm  from dm_gis.tmp_village_src_waybill_no_cnt_1
union all 
select waybill_no,replace(substr(takeover_tm,1,10),'-','') as takeover_tm  from dm_gis.tmp_village_src_waybill_no_cnt_3
;




-- 2 获取5级地址
drop table if exists dm_gis.village_src_addr_decode;
create table dm_gis.village_src_addr_decode(
waybill_no string comment '运单号',
consignor_addr string comment '寄件地址',
province string comment '',
city string comment '',
county string comment '',
town string comment '',
vilname string comment '村级名称',
vilcode string comment '村级编码',
town_adcode string comment '乡镇编码',
class_code string comment '城乡分类代码',
distance string comment '到网点距离',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "5级地址（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 2.1.1 通过aoi id获取 (v2.8 修改)
-- 1、利用运单号匹配表dm_gis.gis_rds_omsto中的req_waybillno，命中则获取gisaoisrc
-- 2、利用aoi id（只用gisaoisrc=norm和chrk下的AOI）到表dm_gis.cms_aoi_village（最新inc_day）中获取village_guid 
-- drop table if exists dm_gis.tmp_village_gisaoisrc_src;
-- create table dm_gis.tmp_village_gisaoisrc_src stored as parquet as 
-- select t0.waybill_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr,t0.aoi_id    
-- from ( select waybill_no,src_dist_code,inc_day,consignor_addr,aoi_id  from dm_gis.village_tt_order_hook where inc_day='$firstDay' and aoi_id is not null and aoi_id<>'' ) as t0 
-- left join ( select req_waybillno from dm_gis.gis_rds_omsto where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-3),'-','') and inc_day<='$firstDay' and req_waybillno is not null and req_waybillno<>'' and (gisaoisrc='norm' or gisaoisrc='chrk') group by req_waybillno ) as t1 
-- on t0.waybill_no=t1.req_waybillno 
-- where t1.req_waybillno is not null 
-- ;

-- drop table if exists dm_gis.tmp_village_guid_src;
-- create table dm_gis.tmp_village_guid_src stored as parquet as 
-- select t0.waybill_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr,t0.aoi_id,t1.village_guid   
-- from ( select waybill_no,src_dist_code,inc_day ,consignor_addr,aoi_id  from dm_gis.tmp_village_gisaoisrc_src where  aoi_id is not null and aoi_id<>'' ) as t0 
-- left join (select city_code,aoi_id,village_guid from dm_gis.tmp_village_cms_aoi_village where village_guid is not null and village_guid<>'')  as t1 
-- on t0.src_dist_code=t1.city_code and t0.aoi_id=t1.aoi_id 
-- ;

-- insert overwrite table  dm_gis.village_src_addr_decode partition(inc_day) 
-- select waybill_no,consignor_addr,name_p as province,name_c as city,name_d as county,name_t as town,name as vilname,area_code as vilcode,adcode_t as town_adcode,class_code,distant,src_dist_code,inc_day   
-- from dm_gis.tmp_village_guid_src as t0 
-- left join ( select guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant from dm_gis.tmp_village_emap_district_village ) as t1 
-- on t0.village_guid=t1.guid
-- where t1.guid is not null 
-- ;

--  20230721 v3.1 修改
-- 1、利用运单号匹配表dm_gis.gis_rds_omsto（inc_day=‘派件inc_day最近7天内’）中的req_waybillno，命中则获取req_orderno
-- 2、利用req_orderno匹配dm_gis.gis_rds_omsfrom中的orderno，命中则获取aoisrc
-- 2、利用aoi id（只用aoisrc=dispatch-norm和dispatch-chkn下的AOI）到表dm_gis.cms_aoi_village（最新inc_day）中获取village_guid
drop table if exists dm_gis.tmp_village_req_orderno_src;
create table dm_gis.tmp_village_req_orderno_src stored as parquet as 
select t0.waybill_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr,t0.aoi_id,t1.req_orderno     
from ( select waybill_no,src_dist_code,inc_day,consignor_addr,aoi_id  from dm_gis.village_tt_order_hook where inc_day='$firstDay' and aoi_id is not null and aoi_id<>'' ) as t0 
left join ( select req_waybillno,req_orderno from dm_gis.gis_rds_omsto where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-3),'-','') and inc_day<='$firstDay' and req_waybillno is not null and req_waybillno<>''  group by req_waybillno,req_orderno ) as t1 
on t0.waybill_no=t1.req_waybillno 
where t1.req_waybillno is not null 
;

drop table if exists dm_gis.tmp_village_gisaoisrc_src;
create table dm_gis.tmp_village_gisaoisrc_src stored as parquet as 
select t0.waybill_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr,t0.aoi_id  
from ( select waybill_no,src_dist_code,inc_day,consignor_addr,aoi_id,req_orderno  from dm_gis.tmp_village_req_orderno_src where  req_orderno is not null and req_orderno<>'' ) as t0 
left join (select orderno from dm_gis.gis_rds_omsfrom where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-3),'-','') and inc_day<='$firstDay' 
and (aoisrc='dispatch-norm' or aoisrc='dispatch-chkn') group by orderno )  as t1 
on t0.req_orderno=t1.orderno 
where t1.orderno is not null 
;

drop table if exists dm_gis.tmp_village_guid_src;
create table dm_gis.tmp_village_guid_src stored as parquet as 
select t0.waybill_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr,t0.aoi_id,t1.village_guid   
from ( select waybill_no,src_dist_code,inc_day ,consignor_addr,aoi_id  from dm_gis.tmp_village_gisaoisrc_src where  aoi_id is not null and aoi_id<>'' ) as t0 
left join (select city_code,aoi_id,village_guid from dm_gis.tmp_village_cms_aoi_village where village_guid is not null and village_guid<>'')  as t1 
on t0.src_dist_code=t1.city_code and t0.aoi_id=t1.aoi_id 
;

insert overwrite table  dm_gis.village_src_addr_decode partition(inc_day) 
select waybill_no,consignor_addr,name_p as province,name_c as city,name_d as county,name_t as town,name as vilname,area_code as vilcode,adcode_t as town_adcode,class_code,distant,src_dist_code,inc_day   
from dm_gis.tmp_village_guid_src as t0 
left join ( select guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant from dm_gis.tmp_village_emap_district_village ) as t1 
on t0.village_guid=t1.guid
where t1.guid is not null 
;

-- 2.1.2 从历史解析日志中获取 
drop table if exists dm_gis.tmp_village_src_addr_decode_log;
create table dm_gis.tmp_village_src_addr_decode_log stored as parquet as 
select t0.waybill_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr  
from ( select waybill_no,src_dist_code,inc_day ,consignor_addr from dm_gis.village_tt_order_hook where inc_day='$firstDay'  ) as t0 
left join ( select waybill_no from dm_gis.village_src_addr_decode where inc_day='$firstDay'  group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
;


insert into  dm_gis.village_src_addr_decode partition(inc_day) 
select t1.waybill_no,t1.consignor_addr,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,t1.src_dist_code,
t1.inc_day  
from dm_gis.tmp_village_village_log_flink_res as t0 
left join ( select waybill_no,src_dist_code,inc_day,consignor_addr from dm_gis.tmp_village_src_addr_decode_log  ) as t1 
on t0.p_city_code=t1.src_dist_code and t0.p_address=t1.consignor_addr  
where t1.waybill_no is not null 
;

-- 2.1.2 调接口获取
-- http://gis-gw.intsit.sfdc.com.cn:9080/village/


-- 
mainClass="com.sf.gis.scala.tals.app.VillageAddrLevel5AddrSrcApp"
int_sql="
select t0.waybill_no,t0.inc_day,t0.src_dist_code as yd_citycode,t0.consignor_addr as yd_addr  
from ( select waybill_no,src_dist_code,inc_day ,consignor_addr from dm_gis.village_tt_order_hook where inc_day='$firstDay'  ) as t0 
left join ( select waybill_no from dm_gis.village_src_addr_decode where inc_day='$firstDay'  group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
"
out_table="dm_gis.village_src_addr_decode"
pall_num=20000

-- 2.1.3 运单5级地址去重
insert overwrite table  dm_gis.village_src_addr_decode partition(inc_day) 
select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,src_dist_code,inc_day  
from (select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,src_dist_code,inc_day ,
row_number() over(partition by waybill_no,src_dist_code,inc_day  order by vilcode desc) as rn from dm_gis.village_src_addr_decode where inc_day='$firstDay' 
) as t where t.rn=1 
;



-- 2.2 是否进村派件
-- 当城乡分类代码不为220时，填入否；当城乡分类代码=220时，判断驿站编码，是否为空.
-- 1.不为空,则利用驿站编码和村adcode与表 （inc_day选最新）ods_yjy.station_info_d 的own_code和village_code匹配，都命中则为是，否则为否
-- 2.为空,否则用小哥经纬度到杨俊提个的坐标查询行政村服务获取村adcode与前面获取的村adcode进行匹配，命中则为是，否则为否


-- 2.2.1 驿站编码 不为空 
drop table if exists dm_gis.village_src_owncode_isnotnull;
create table dm_gis.village_src_owncode_isnotnull(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "驿站编码不为空（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- insert overwrite table dm_gis.village_src_owncode_isnotnull partition(inc_day) 
-- select 
-- waybill_no,class_code,vilcode,own_code,src_dist_code,inc_day   
-- from (select mailno,own_code from ods_yjy.yjy_mailno_kb where inc_day='$firstDay' and type='收件') as t0 
-- left join (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_addr_decode where inc_day='$firstDay'  ) as t1 
-- on t0.mailno=t1.waybill_no 
-- where t1.waybill_no is not null
-- ;

alter table dm_gis.village_src_owncode_isnotnull add columns (operate_longitude string COMMENT '驿站经度') cascade;
alter table dm_gis.village_src_owncode_isnotnull add columns (operate_latitude string COMMENT '驿站纬度') cascade;

-- 2023.10.20
alter table dm_gis.village_src_owncode_isnotnull add columns (lonlat_tag string COMMENT '出入库标签') cascade;

insert overwrite table dm_gis.village_src_owncode_isnotnull partition(inc_day) 
select 
waybill_no,class_code,vilcode,own_code,src_dist_code,operate_longitude,operate_latitude,lonlat_tag,inc_day 
from (select waybill_no,class_code,vilcode,src_dist_code,inc_day from dm_gis.village_src_addr_decode where inc_day='$firstDay' ) as t0 
left join (select mailno,own_code,
if(pj_operate_longitude<>'' and pj_operate_longitude<>'nan',pj_operate_longitude,operate_longitude) as operate_longitude,
if(pj_operate_latitude<>'' and pj_operate_latitude<>'nan',pj_operate_latitude,operate_latitude) as operate_latitude,
case when (pj_operate_longitude<>'' and pj_operate_longitude<>'nan') then '1' 
when (operate_longitude<>'' and operate_longitude<>'nan') then '2' 
else '' end as lonlat_tag   
from dm_yjy.yjy_mailno_kb where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay' and type='收件') as t1 
on t0.waybill_no=t1.mailno 
where t1.mailno is not null
;

-- 坐标系转换（百度转高德）
drop table if exists dm_gis.village_src_lonlat_transform;
create table dm_gis.village_src_lonlat_transform(
bd_lon string comment '百度经度',
bd_lat string comment '百度纬度',
gd_lon_lat string comment '高德经纬坐标'
)
COMMENT "坐标系转换（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLonLatTransformApp"
int_sql="select operate_longitude as bd_lon,operate_latitude as bd_lat from dm_gis.village_src_owncode_isnotnull where inc_day='$firstDay' and operate_longitude<>'' and operate_longitude<>'nan' group by operate_longitude,operate_latitude"
out_table="dm_gis.village_src_lonlat_transform" 


insert overwrite table dm_gis.village_src_owncode_isnotnull partition(inc_day='$firstDay') 
select waybill_no,class_code,vilcode,own_code,src_dist_code,gd_lon as operate_longitude,gd_lat as operate_latitude,lonlat_tag   
from (select 
waybill_no,class_code,vilcode,own_code,src_dist_code,operate_longitude,operate_latitude,lonlat_tag,inc_day 
from dm_gis.village_src_owncode_isnotnull where inc_day='$firstDay' ) as t0 
left join (select bd_lon,bd_lat,split(gd_lon_lat,',')[0] as gd_lon,split(gd_lon_lat,',')[1] as gd_lat from dm_gis.village_src_lonlat_transform where inc_day='$firstDay') as t1 
on t0.operate_longitude=t1.bd_lon and t0.operate_latitude=t1.bd_lat 
;


-- 集收 判断为是的
drop table if exists dm_gis.village_src_js_res;
create table dm_gis.village_src_js_res(
waybill_no string comment '运单号',
class_code string comment '类型',
vilcode string comment '村编码'
)
COMMENT "集收判断上门（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_js_res partition(inc_day='$firstDay')
select 
t0.waybill_no,class_code,vilcode 
from (select waybill_no,class_code,vilcode,src_dist_code,inc_day from dm_gis.village_src_addr_decode where inc_day='$firstDay' and class_code in ('220','210')  ) as t0  
left join (select waybill_no,takeover_tm from dm_gis.tmp_village_src_waybill_no_cnt_res ) as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.takeover_tm 
where t1.waybill_no is not null 
;


-- 20230427 v2.4 改
-- 1）驿站收派件经纬度不为空：利用驿站收件经纬度跑接口
create table dm_gis.village_src_owncode_isnotnull_api_res(
vilcode string comment '村编码',
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
match_res string COMMENT '是否',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "驿站编码不为空（收件）接口判断结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



-- 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadiusApp"
int_sql="select vilcode,operate_longitude,operate_latitude,src_dist_code as dist_code,inc_day from (
select 
t0.waybill_no,vilcode,operate_longitude,operate_latitude,src_dist_code,inc_day 
from (
select waybill_no,vilcode,operate_longitude,operate_latitude,src_dist_code,inc_day from dm_gis.village_src_owncode_isnotnull 
where inc_day='$firstDay' and class_code in ('220','210') and vilcode is not null and vilcode<>'' and operate_longitude is not null and operate_longitude<>'' and operate_latitude is not null and operate_latitude<>''
) as t0 
left join (select waybill_no from dm_gis.village_src_js_res where inc_day='$firstDay' 
 ) as t1 
on t0.waybill_no=t1.waybill_no 
where  t1.waybill_no is null 
) as t 
group by vilcode,operate_longitude,operate_latitude,src_dist_code,inc_day "
out_table="dm_gis.village_src_owncode_isnotnull_api_res" 
pall_num=10000


-- 2.2.1.1 own_code和village_code匹配是否命中
drop table if exists dm_gis.village_src_owncode_isnotnull_res;
create table dm_gis.village_src_owncode_isnotnull_res(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码',
own_code_check  string comment '',
village_code  string comment '',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "驿站编码不为空（收件）结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnotnull_res partition(inc_day) 
select waybill_no,class_code,vilcode,t0.own_code,t1.own_code as own_code_1,village_code,src_dist_code,inc_day  
from (select waybill_no,class_code,vilcode,own_code,src_dist_code,inc_day   from dm_gis.village_src_owncode_isnotnull where inc_day='$firstDay'  and class_code in ('220','210') and (operate_longitude is null or trim(operate_longitude)='' or operate_latitude is null or trim(operate_latitude)='') ) as t0 
left join ( select own_code,village_code from ods_yjy.station_info_d where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') and village_code<>'' group by own_code,village_code ) as t1 
on trim(t0.own_code)=trim(t1.own_code) and trim(t0.vilcode)=trim(t1.village_code)  
;


-- 2.2.2 驿站编码 为空
drop table if exists dm_gis.village_src_owncode_isnull;
create table dm_gis.village_src_owncode_isnull(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_owncode_isnull partition(inc_day) 
select t0.waybill_no,class_code,vilcode,src_dist_code,inc_day  
from ( select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_addr_decode where inc_day='$firstDay'  and class_code in ('220','210') ) as t0 
left join (select waybill_no from dm_gis.village_src_owncode_isnotnull where inc_day='$firstDay'  and class_code in ('220','210') group by waybill_no) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
;


-- 2.2.2.1 运单关联获取consigned_tm,consignee_emp_code
drop table if exists dm_gis.village_src_owncode_isnull_waybill;
create table dm_gis.village_src_owncode_isnull_waybill(
waybill_no string comment '运单号',
consigned_tm string comment '收件时间',
consignee_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取consigned_tm,consignee_emp_code（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill partition(inc_day) 
select 
t0.waybill_no,t0.consigned_tm,t0.consignee_emp_code,
t1.class_code,t1.vilcode,t1.src_dist_code,
t1.inc_day 
from ( select waybill_no,consigned_tm,consignee_emp_code,src_dist_code,inc_day   from dm_gis.village_tt_order_hook where inc_day='$firstDay'  ) as t0 
left join (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull where inc_day='$firstDay'  ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 2.2.2.2 运单关联小哥轨迹 
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_tmp;
create table dm_gis.village_src_owncode_isnull_waybill_xg_tmp(
waybill_no string comment '运单号',
consignee_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
zx string comment '经度',
zy string comment '纬度',
consigned_tm string comment '收件时间',
tm string comment '小哥轨迹时间',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联小哥轨迹（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_tmp partition(inc_day) 
select 
waybill_no,consignee_emp_code,class_code,vilcode,zx,zy,consigned_tm,tm,t1.src_dist_code,t1.inc_day  
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,class_code,vilcode,src_dist_code,inc_day  
from dm_gis.village_src_owncode_isnull_waybill where inc_day='$firstDay'  and consigned_tm<>'' ) as t1 
on t0.un=t1.consignee_emp_code
where consigned_tm-60*5<=tm and consigned_tm+60*5>=tm
;

-- 2.2.2.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg;
create table dm_gis.village_src_owncode_isnull_waybill_xg(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "取最靠近收件日期的轨迹点（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg partition(inc_day) 
select waybill_no,zx,zy,src_dist_code,inc_day  
from (
select waybill_no,src_dist_code,inc_day ,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,src_dist_code,inc_day ,zx,zy,abs(consigned_tm-tm) as diff_tm from dm_gis.village_src_owncode_isnull_waybill_xg_tmp where inc_day='$firstDay'  ) as t  
) as t0 where t0.rn=1 
;

-- -- 2.2.2.4 调坐标查询行政村接口 
-- drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_res;
-- create table dm_gis.village_src_owncode_isnull_waybill_xg_res (
-- zx string comment '',
-- zy string comment '',
-- vil_code string comment '',
-- vil_name string comment '',
-- guid string comment '',
-- src_dist_code STRING COMMENT "分区城市代码" 
-- )
-- COMMENT "跑经纬坐标查询行政村（收件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;

-- mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageSrcApp"
-- int_sql="select zx,zy,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_waybill_xg where inc_day='$firstDay'  group by zx,zy,src_dist_code,inc_day "
-- out_table="dm_gis.village_src_owncode_isnull_waybill_xg_res" 
-- pall_num=10000


-- 2.2.2.4  驿站编码 为空 res 
-- drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_hy;
-- create table dm_gis.village_src_owncode_isnull_waybill_xg_hy (
-- waybill_no string comment '',
-- zx string comment '',
-- zy string comment '',
-- vil_code string comment '',
-- vil_name string comment '',
-- guid string comment '',
-- src_dist_code STRING COMMENT "分区城市代码" 
-- )
-- COMMENT "驿站编码为空小哥还原（收件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;

-- insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_hy partition(inc_day)  
-- select waybill_no,t0.zx,t0.zy,vil_code,vil_name,guid,src_dist_code,inc_day  from (select waybill_no,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_waybill_xg where inc_day='$firstDay'  ) as t0 
-- left join ( select zx,zy,vil_code,vil_name,guid from dm_gis.village_owncode_isnull_waybill_xg_res where inc_day='$firstDay'  ) as t1 
-- on t0.zx=t1.zx and t0.zy=t1.zy 
-- ;

-- v2.8
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_hy;
create table dm_gis.village_src_owncode_isnull_waybill_xg_hy (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空小哥还原（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_hy partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,src_dist_code,inc_day  
from (select waybill_no,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_waybill_xg where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set  ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;


-- -- 
-- drop table if exists dm_gis.village_src_owncode_isnull_res;
-- create table dm_gis.village_src_owncode_isnull_res (
-- waybill_no string comment '',
-- class_code string comment '',
-- vilcode string comment '',
-- zx string comment '',
-- zy string comment '',
-- vil_code string comment '',
-- vil_name string comment '',
-- guid string comment '',
-- src_dist_code STRING COMMENT "分区城市代码" 
-- )
-- COMMENT "驿站编码为空res（收件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;


-- insert overwrite table dm_gis.village_src_owncode_isnull_res partition(inc_day)  
-- select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,vil_name,guid,src_dist_code,inc_day   
-- from (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull where inc_day='$firstDay'  ) as t0 
-- left join (select waybill_no,zx,zy,vil_code,vil_name,guid from dm_gis.village_src_owncode_isnull_waybill_xg_hy where inc_day='$firstDay'   ) as t1 
-- on t0.waybill_no=t1.waybill_no
-- ;

-- 
drop table if exists dm_gis.village_src_owncode_isnull_res;
create table dm_gis.village_src_owncode_isnull_res (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
adcode_isin string comment 'adcode是否在adcode list中',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空res（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_res partition(inc_day)  
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,src_dist_code,inc_day   
from (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull where inc_day='$firstDay'  ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_src_owncode_isnull_waybill_xg_hy where inc_day='$firstDay'   ) as t1 
on t0.waybill_no=t1.waybill_no
;


-- 3 是否进乡镇上门
-- 城乡代码为220或是否进村上门为‘是’标记为‘否’；对其他的，用小哥轨迹坐标调坐标查询aoi接口（参数外延200m距离）,判断是否为乡镇上门，是：接口返回aoicode中有运单aoicode，否：接口返回aoicode中无运单aoicode

-- 3.1 运单关联获取 consigned_tm,consignee_emp_code,aoi_id,aoi_code
drop table if exists dm_gis.village_src_classcode_waybill;
create table dm_gis.village_src_classcode_waybill (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
consigned_tm string comment '',
consignee_emp_code string comment '',
aoi_id string comment '',
aoi_code string comment '',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_src_classcode_waybill partition(inc_day)  
select t1.waybill_no,t1.class_code,t1.vilcode,t0.consigned_tm,t0.consignee_emp_code,aoi_id,aoi_code,t1.src_dist_code,t1.inc_day   
from ( select waybill_no,consigned_tm,consignee_emp_code,aoi_id,aoi_code,src_dist_code,inc_day   from dm_gis.village_tt_order_hook where inc_day='$firstDay'   ) as t0 
left join (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_addr_decode where inc_day='$firstDay'  and (class_code is null or class_code not in ('220','210','110','111')  ) ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 3.2 运单关联小哥轨迹  
drop table if exists dm_gis.village_src_classcode_waybill_xg_tmp;
create table dm_gis.village_src_classcode_waybill_xg_tmp (
waybill_no string comment '',
aoi_id string comment '',
aoi_code string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
consigned_tm string comment '',
tm string comment '',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_classcode_waybill_xg_tmp partition(inc_day)  
select 
waybill_no,aoi_id,aoi_code,class_code,vilcode,zx,zy,consigned_tm,tm,src_dist_code,t1.inc_day  
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,aoi_id,aoi_code,class_code,vilcode,src_dist_code,inc_day  
from dm_gis.village_src_classcode_waybill where inc_day='$firstDay'  and consignee_emp_code<>'' and consigned_tm<>'' ) as t1 
on t0.un=t1.consignee_emp_code
where consigned_tm-60*5<=tm and consigned_tm+60*5>=tm
;

-- 3.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_src_classcode_waybill_xg;
create table dm_gis.village_src_classcode_waybill_xg (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_src_classcode_waybill_xg partition(inc_day)  
select waybill_no,aoi_code,zx,zy,src_dist_code,inc_day  
from (
select waybill_no,src_dist_code,inc_day ,aoi_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,src_dist_code,inc_day ,aoi_code,zx,zy,abs(consigned_tm-tm) as diff_tm from dm_gis.village_src_classcode_waybill_xg_tmp where inc_day='$firstDay'    ) as t  
) as t0 where t0.rn=1 
;

-- -- 3.4 调坐标查询aoi接口
-- drop table if exists dm_gis.village_src_classcode_waybill_xg_res;
-- create table dm_gis.village_src_classcode_waybill_xg_res (
-- aoi_code string comment '',
-- lgt string comment '',
-- lat string comment '',
-- matchres string comment '',
-- src_dist_code STRING COMMENT "分区城市代码"
-- )
-- COMMENT "跑经纬坐标查询aoi（收件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;


-- mainClass="com.sf.gis.scala.tals.app.VillageLatLngAoiSrcApp"
-- int_sql="select aoi_code,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_classcode_waybill_xg where inc_day='$firstDay'    and aoi_code<>'' group by aoi_code,zx,zy,src_dist_code,inc_day "
-- out_table="dm_gis.village_src_classcode_waybill_xg_res" 
-- pall_num=100000


-- 3.5 能关联小哥轨迹的运单查询aoi后判断是否上门的结果
drop table if exists dm_gis.village_src_classcode_waybill_xg_aoi_res;
create table dm_gis.village_src_classcode_waybill_xg_aoi_res (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
matchres string comment '',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "跑经纬坐标查询aoi（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_classcode_waybill_xg_aoi_res partition(inc_day)  
select waybill_no,t0.aoi_code,zx,zy,matchres,src_dist_code,inc_day  from (select waybill_no,aoi_code,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_classcode_waybill_xg where inc_day='$firstDay'   ) as t0 
left join (select aoi_code,lgt,lat,matchres from dm_gis.village_classcode_waybill_xg_res where inc_day='$firstDay'   ) as t1 
on t0.aoi_code=t1.aoi_code and t0.zx=t1.lgt and t0.zy=t1.lat 
;
 




-- 4 快递上门结果表 （收件）（v2.2 新增 tt_fee_zh_all_fee distance）
drop table if exists dm_gis.village_src_kdsm_res;
create table dm_gis.village_src_kdsm_res (
src_hq_code	string comment '大区代码',
src_area_code	string comment '地区代码',
area_name	string comment '地区名称',
source_zone_code	string comment '网点代码',
dept_name	string comment '网点名称',
waybill_no	string comment '单号',
consignee_emp_code	string comment '派件人工号',
real_product_code	string comment '产品名称',
meterage_weight_qty	string comment '计费重量',
pay_cust_type	string comment '付费客户类型',
service_prod_code	string comment '增值服务代码',
all_fee_rmb	string comment '总收入（rmb）',
freight_monthly_acct_code	string comment '月结账号',
is_yj	string comment '是否月结',
aoi_code	string comment 'AOI编码',
aoi_name	string comment 'AOI名称',
aoi_type_name	string comment 'aoi类型名称',
aoi_area_code	string comment 'AOI区域',
province	string comment '省',
city	string comment '市/市辖区',
county	string comment '区/县',
town	string comment '镇/乡',
town_adcode	string comment '镇adcode',
vil_name	string comment '行政村/社区',
vil_code	string comment '村adcode',
class_code	string comment '城乡分类代码',
own_code	string comment '驿站编码',
is_jcpj	string comment '是否进村派件',
is_jxzpj	string comment '是否为乡镇上门派件',
yd_type	string comment '运单类型',
wd_type	string comment '网点类型',
src_dist_code STRING COMMENT "分区城市代码",
tt_fee_zh_all_fee string comment '折后收入',
distance	string comment '寄件地址到收件网点的距离',
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
consigned_tm string comment'揽收时间',
is_js string comment'是否集收',
lonlat_tag string comment'出入库标签'
)
COMMENT "行政村快递上门（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- v2.2 新增 tt_fee_zh_all_fee和distance
alter table dm_gis.village_src_kdsm_res add columns(tt_fee_zh_all_fee string comment'折后收入') ; 
alter table dm_gis.village_src_kdsm_res add columns(distance string comment'寄件地址到收件网点的距离') ; 
--  新增  operate_longitude和operate_latitude
alter table dm_gis.village_src_kdsm_res add columns(operate_longitude string COMMENT '驿站经度');
alter table dm_gis.village_src_kdsm_res add columns(operate_latitude string COMMENT '驿站纬度');
-- v2.9 新增 consigned_tm
alter table dm_gis.village_src_kdsm_res add columns(consigned_tm string comment'揽收时间') ; 
-- 20231020 v3.4 增加 是否集派 是否同城件 出入库标签
alter table dm_gis.village_src_kdsm_res add columns(is_js string comment'是否集收') cascade;
alter table dm_gis.village_src_kdsm_res add columns(lonlat_tag string comment'出入库标签') cascade;
-- 2023.11.21   补贴标签(subsidy_type)  补贴更新(subsidy)
alter table dm_gis.village_src_kdsm_res add columns(subsidy_type string comment'补贴标签') cascade;
alter table dm_gis.village_src_kdsm_res add columns(subsidy string comment'补贴更新') cascade;




insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day) 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vilname,vilcode,class_code,
own_code,is_jcpj,is_jxzpj,
case when (class_code in ('220','210')) or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type ,
wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,
'' as subsidy_type,'' as subsidy,
inc_day
from (
select 
src_hq_code,src_area_code,t5.area_name,source_zone_code,t5.dept_name,t0.waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,tt_fee_zh_all_fee,freight_monthly_acct_code,
case when freight_monthly_acct_code<>'' then '1' else '0' end as is_yj,
t0.aoi_code,t0.aoi_name,aoi_type_name,t6.aoi_area_code,
t1.province,t1.city,t1.county,t1.town,t1.town_adcode,t1.vilname,t1.vilcode,t1.class_code,
t7.own_code,
case when t12.waybill_no is not null or t8.match_res='1' or adcode_isin='1' then '1' else '0' end as is_jcpj,
case when t4.matchres='1'  then '1' else '0' end as is_jxzpj,
distance,
case when t5.dept_type_code='DB05-DLD' then '代理' else '自营' end as wd_type,
t7.operate_longitude,t7.operate_latitude,
consigned_tm,
if(t10.takeover_tm is not null,'1','0') as is_js,
t7.lonlat_tag,
t0.inc_day,t0.src_dist_code
from (
select waybill_no,consigned_tm,src_hq_code,src_area_code,source_zone_code,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,tt_fee_zh_all_fee,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
src_county,consignor_addr,
inc_day,src_dist_code  from dm_gis.village_tt_order_hook where inc_day='$firstDay'   ) as t0 
left join ( select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,src_dist_code,inc_day   
from dm_gis.village_src_addr_decode where inc_day='$firstDay'  ) as t1 
on t0.waybill_no=t1.waybill_no 
left join (select waybill_no,class_code,vilcode,own_code,own_code_check,village_code,src_dist_code,inc_day  
from dm_gis.village_src_owncode_isnotnull_res where inc_day='$firstDay'  ) as t2 
on t0.waybill_no=t2.waybill_no 
left join (select waybill_no,class_code,vilcode,src_dist_code,inc_day ,zx,zy,adcode_isin  
from dm_gis.village_src_owncode_isnull_res where inc_day='$firstDay'    ) as t3 
on t0.waybill_no=t3.waybill_no 
left join (select waybill_no,src_dist_code,inc_day ,aoi_code,zx,zy,matchres from dm_gis.village_src_classcode_waybill_xg_aoi_res where inc_day='$firstDay'  ) as t4 
on t0.waybill_no=t4.waybill_no 
left join (select dept_code,area_name,dept_name,dept_type_code from (select dept_code,area_name,dept_name,dept_type_code,row_number() over(partition by dept_code order by inc_day desc)  as rn 
from  dim.dim_dept_info_df where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') ) as b where b.rn=1 ) as t5 
on t0.source_zone_code=t5.dept_code 
left join dm_tc_waybillinfo.aoi_area_aoi as t6 
on t0.aoi_code=t6.aoi_id 
left join (select waybill_no,own_code,src_dist_code,vilcode,operate_longitude,operate_latitude,lonlat_tag from dm_gis.village_src_owncode_isnotnull where inc_day='$firstDay'  ) as t7 
on t0.waybill_no=t7.waybill_no 
left join (select src_dist_code,vilcode,operate_longitude,operate_latitude,match_res from dm_gis.village_src_owncode_isnotnull_api_res where inc_day='$firstDay' ) as t8 
on t7.src_dist_code=t8.src_dist_code and t7.vilcode=t8.vilcode and t7.operate_longitude=t8.operate_longitude and t7.operate_latitude=t8.operate_latitude 
left join (select waybill_no,takeover_tm from dm_gis.tmp_village_src_waybill_no_cnt_res ) as t10 
on t0.waybill_no=t10.waybill_no and t0.inc_day=t10.takeover_tm 
left join (select waybill_no from dm_gis.village_src_js_res where inc_day='$firstDay') as t12 
on t0.waybill_no=t12.waybill_no 
) as t 
;





-- 20230418 
-- v2.2 刷新之前的数据 (每月*号刷上个月的数据)
-- insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day='$firstDay') 
-- select 
-- src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,
-- meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
-- province,city,county,town,town_adcode,vil_name,vil_code,class_code,
-- own_code,is_jcpj,is_jxzpj,
-- yd_type,wd_type,src_dist_code,t1.tt_fee_zh_all_fee,t2.distance,operate_longitude,operate_latitude,consigned_tm  
-- from (
-- select 
-- src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,
-- pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
-- province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,yd_type,wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm   
-- from dm_gis.village_src_kdsm_res where inc_day='$firstDay' ) as t0 
-- left join (select waybill_no,tt_fee_zh_all_fee from dm_gis.tt_order_hook where inc_day='$firstDay' group by waybill_no,tt_fee_zh_all_fee) as t1 
-- on t0.waybill_no=t1.waybill_no
-- left join ( select waybill_no,distance from dm_gis.village_src_addr_decode where inc_day='$firstDay' group by waybill_no,distance ) as t2 
-- on t0.waybill_no=t2.waybill_no 
-- ;

insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,wd_type,src_dist_code,t1.tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,
subsidy_type,subsidy 
from (
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,
pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,yd_type,wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,
subsidy_type,subsidy 
from dm_gis.village_src_kdsm_res where inc_day='$firstDay' ) as t0 
left join (select waybill_no,tt_fee_zh_all_fee from dm_gis.tt_order_hook where inc_day='$firstDay' group by waybill_no,tt_fee_zh_all_fee) as t1 
on t0.waybill_no=t1.waybill_no
;


-- 20230418 统计v1.2
-- dm_gis.village_kdsm_vil_stat 刷新之前的数据 (每月*号刷上个月的数据)
insert overwrite dm_gis.village_kdsm_vil_stat partition(inc_day='$firstDay')
select t0.area_code,t0.dist_code,t0.city,t0.zone_code,t0.town,t0.town_adcode,t0.vil_name,t0.vil_code,t0.dest_cnt,t0.src_cnt,t0.class_code,t0.is_ttyz,t0.dest_jcpj_cnt,t0.src_jcpj_cnt,
t1.all_fee_rmb,t1.tt_fee_zh_all_fee 
from (select area_code,dist_code,city,zone_code,town,town_adcode,vil_name,vil_code,dest_cnt,src_cnt,class_code,is_ttyz,dest_jcpj_cnt,src_jcpj_cnt,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.village_kdsm_vil_stat where inc_day='$firstDay' ) as t0 
left join (
select
src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz,
sum(all_fee_rmb) as all_fee_rmb,sum(tt_fee_zh_all_fee) as tt_fee_zh_all_fee 
from
(select
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no,class_code,if(own_code is not null,'是','否') is_ttyz,is_jcpj,all_fee_rmb,tt_fee_zh_all_fee 
from dm_gis.village_src_kdsm_res
where inc_day='$firstDay' and src_area_code<>'' and city<>'' and source_zone_code<>'' ) as t
group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,class_code,is_ttyz
) as t1 
on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code
and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code and t0.class_code=t1.class_code and t0.is_ttyz=t1.is_ttyz
;



------------------------------------------------------
------------------------------------------------------
-- 20231020 集收回刷近30天数据（增加进村收件为是的量）
-- insert overwrite table dm_gis.village_src_kdsm_res partition(inc_day='')
-- select 
-- src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
-- is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,
-- if(class_code in ('220','210') and t1.takeover_tm is not null, '1' ,is_jcpj) as is_jcpj,
-- if(class_code in ('220','210') and t1.takeover_tm is not null, '0' ,is_jxzpj) as is_jxzpj,
-- yd_type,wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,is_js,lonlat_tag 
-- from (
-- select 
-- src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
-- is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,
-- is_jcpj,
-- is_jxzpj,
-- yd_type,wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,is_js,lonlat_tag,inc_day 
-- from 
-- dm_gis.village_src_kdsm_res where inc_day='' ) as t0 
-- left join (select waybill_no,takeover_tm from dm_gis.tmp_village_src_waybill_no_cnt_res group by waybill_no,takeover_tm) as t1 
-- on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.takeover_tm 
-- ;


------------------------------------------------------
------------------------------------------------------
-- 2023.11.21  新增字段  补贴标签(subsidy_type)  补贴更新(subsidy)
-- dm_ifs.ifs_fct_township_gather_pick_deliver_dtl_mi	subsidy_type	
-- 1.利用运单号关联该表的inc_day相同且pd_flag=2时的waybill_no，命中则获取subsidy_type，否则为空；更新时间，上游表更新后刷新
-- 2.利用运单号关联该表的inc_day相同且pd_flag=2时的waybill_no，命中则获取subsidy，否则为空；更新时间，上游表更新后刷新 
insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day='$firstDay') 
select src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,
is_jcpj,
is_jxzpj,
yd_type,
wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,
subsidy_type,subsidy 
from ( select src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,
is_jcpj,
is_jxzpj,
yd_type,
wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag 
from dm_gis.village_src_kdsm_res where inc_day='' ) as t0 
left join (select waybill_no,subsidy_type,subsidy from dm_ifs.dm_ifs_fct_township_gather_pick_deliver_dtl_di where inc_day='$firstDay' and pd_flag='1' group by waybill_no,subsidy_type,subsidy) as t1 
on t0.waybill_no=t1.waybill_no
;
