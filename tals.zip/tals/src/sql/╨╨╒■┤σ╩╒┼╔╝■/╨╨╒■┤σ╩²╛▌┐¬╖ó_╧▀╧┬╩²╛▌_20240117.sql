-- 
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- @author 张小琼 （01416344）
-- Created on 2023-12-06
-- 任务信息： ID:926185  行政村收派件_new(基于dwd_waybill_info_dtl_di)
-- 

------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 城区面行政村（线下数据导入）
drop table if exists dm_gis.ods_csv_village_city_af;
create table dm_gis.ods_csv_village_city_af(
id string comment 'id', 
adcode string comment '', 
adcode_c string comment '', 
name_c string comment '',
name_chn string comment '',
remark string comment '',
guid string comment '',
area_code string comment ''
)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
tblproperties('skip.header.line.count'='1');

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/城区面行政村20240117112544.csv' OVERWRITE INTO TABLE dm_gis.ods_csv_village_city_af;

