-- 
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- 需求： id: 1585280  【偏远乡村派件上门】快递进村收派件数据统计_V2.0 
-- @author 张小琼 （01416344）
-- Created on 2023-02-15
-- 任务信息： 668258	行政村收派件_20230222
-- 

-- 1、数据准备

-- 1.1 运单
-- 源：dm_gis.tt_order_hook  收件
-- dm_gis.village_tt_order_hook
create table dm_gis.village_tt_order_hook(
waybill_no string comment '运单号',
consigned_tm string comment '寄件时间',
src_hq_code string comment '目的地经营本部（大区）',
src_area_code string comment '目的地区部（地区代码）',
source_zone_code string comment '目的地网点代码（网点代码）',
consignee_emp_code string comment '收件员',
real_product_code string comment '产品代码',
meterage_weight_qty string comment '计费重量',
pay_cust_type string comment '付费客户类型',
service_prod_code string comment '增值服务代码',
all_fee_rmb string comment '总收入',
freight_monthly_acct_code string comment '月结账号',
aoi_id string comment 'aoi id',
aoi_code string comment 'aoi编码',
aoi_name string comment 'aoi名称',
aoi_type_name string comment 'aoi类型名称',
src_county string comment '目的地区/县/镇',
consignor_addr  string comment '寄件地址' 
)
COMMENT "行政村运单（寄件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;

insert overwrite table  dm_gis.village_tt_order_hook partition(inc_day,src_dist_code) 
select waybill_no,consigned_tm,src_hq_code,src_area_code,source_zone_code,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
src_county,consignor_addr,
inc_day,src_dist_code  
from dm_gis.tt_order_hook where inc_day='20230219' and  src_dist_code in ('371') limit 1000
;


-- 2 获取5级地址
create table dm_gis.village_src_addr_decode(
waybill_no string comment '运单号',
consignor_addr string comment '寄件地址',
province string comment '',
city string comment '',
county string comment '',
town string comment '',
vilname string comment '村级名称',
vilcode string comment '村级编码',
town_adcode string comment '乡镇编码',
class_code string comment '城乡分类代码',
distance string comment '到网点距离'
)
COMMENT "5级地址（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 2.1.1 从历史解析日志中获取 
insert overwrite table  dm_gis.village_src_addr_decode partition(inc_day,src_dist_code) 
select t1.waybill_no,t1.consignor_addr,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,
t1.inc_day,t1.src_dist_code  
from dm_gis.tmp_village_village_log_flink_res as t0 
left join ( select waybill_no,inc_day,src_dist_code,consignor_addr from dm_gis.village_tt_order_hook where inc_day='20230219' and src_dist_code in ('371')  ) as t1 
on t0.p_city_code=t1.src_dist_code and t0.p_address=t1.consignor_addr  
where t1.waybill_no is not null 
;

-- 2.1.2 调接口获取
-- http://gis-gw.intsit.sfdc.com.cn:9080/village/


-- 
mainClass="com.sf.gis.scala.tals.app.VillageAddrLevel5AddrSrcApp"
int_sql="
select t0.waybill_no,t0.inc_day,t0.src_dist_code as yd_citycode,t0.consignor_addr as yd_addr  
from ( select waybill_no,inc_day,src_dist_code,consignor_addr from dm_gis.village_tt_order_hook where inc_day='20230219' and src_dist_code in ('371') ) as t0 
left join ( select waybill_no from dm_gis.village_src_addr_decode where inc_day='20230219' and src_dist_code in ('371') group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
"
out_table="dm_gis.village_src_addr_decode"
pall_num=20000

-- 2.1.3 运单5级地址去重
insert overwrite table  dm_gis.village_src_addr_decode partition(inc_day,src_dist_code) 
select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,inc_day,src_dist_code 
from (select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,inc_day,src_dist_code,
row_number() over(partition by waybill_no,inc_day,src_dist_code order by vilcode desc) as rn from dm_gis.village_src_addr_decode where inc_day='20230219' and src_dist_code in ('371')
) as t where t.rn=1 
;



-- 2.2 是否进村派件
-- 当城乡分类代码不为220时，填入否；当城乡分类代码=220时，判断驿站编码，是否为空.
-- 1.不为空,则利用驿站编码和村adcode与表 （inc_day选最新）ods_yjy.station_info_d 的own_code和village_code匹配，都命中则为是，否则为否
-- 2.为空,否则用小哥经纬度到杨俊提个的坐标查询行政村服务获取村adcode与前面获取的村adcode进行匹配，命中则为是，否则为否


-- 2.2.1 驿站编码 不为空 
drop table if exists dm_gis.village_src_owncode_isnotnull;
create table dm_gis.village_src_owncode_isnotnull(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码'
)
COMMENT "驿站编码不为空（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnotnull partition(inc_day,src_dist_code) 
select 
waybill_no,class_code,vilcode,own_code,inc_day,src_dist_code  
from (select mailno,own_code from ods_yjy.yjy_mailno_kb where inc_day='20230219' and type='收件') as t0 
left join (select waybill_no,class_code,vilcode,inc_day,src_dist_code from dm_gis.village_src_addr_decode where inc_day='20230219' and src_dist_code in ('371') ) as t1 
on t0.mailno=t1.waybill_no 
where t1.waybill_no is not null
;

-- 2.2.1.1 own_code和village_code匹配是否命中
drop table if exists dm_gis.village_src_owncode_isnotnull_res;
create table dm_gis.village_src_owncode_isnotnull_res(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码',
own_code_check  string comment '',
village_code  string comment ''
)
COMMENT "驿站编码不为空（收件）结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnotnull_res partition(inc_day,src_dist_code) 
select waybill_no,class_code,vilcode,t0.own_code,t1.own_code,village_code,inc_day,src_dist_code 
from (select waybill_no,class_code,vilcode,own_code,inc_day,src_dist_code  from dm_gis.village_src_owncode_isnotnull where inc_day='20230219' and src_dist_code in ('371') and class_code='220' ) as t0 
left join ( select own_code,village_code from ods_yjy.station_info_d where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') and village_code<>'' group by own_code,village_code ) as t1 
on t0.own_code=t1.own_code and t0.vilcode=t1.village_code 
;


-- 2.2.2 驿站编码 为空
drop table if exists dm_gis.village_src_owncode_isnull;
create table dm_gis.village_src_owncode_isnull(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码' 
)
COMMENT "驿站编码为空（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_owncode_isnull partition(inc_day,src_dist_code) 
select t0.waybill_no,class_code,vilcode,inc_day,src_dist_code 
from ( select waybill_no,class_code,vilcode,inc_day,src_dist_code from dm_gis.village_src_addr_decode where inc_day='20230219' and src_dist_code in ('371') and class_code='220' ) as t0 
left join (select waybill_no from dm_gis.village_src_owncode_isnotnull where inc_day='20230219' and src_dist_code in ('371') and class_code='220' group by waybill_no) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
;


-- 2.2.2.1 运单关联获取consigned_tm,consignee_emp_code
drop table if exists dm_gis.village_src_owncode_isnull_waybill;
create table dm_gis.village_src_owncode_isnull_waybill(
waybill_no string comment '运单号',
consigned_tm string comment '收件时间',
consignee_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码' 
)
COMMENT "运单关联获取consigned_tm,consignee_emp_code（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill partition(inc_day,src_dist_code) 
select 
t0.waybill_no,t0.consigned_tm,t0.consignee_emp_code,
t1.class_code,t1.vilcode,
t1.inc_day,t1.src_dist_code 
from ( select waybill_no,consigned_tm,consignee_emp_code,inc_day,src_dist_code  from dm_gis.village_tt_order_hook where inc_day='20230219' and src_dist_code in ('371') ) as t0 
left join (select waybill_no,class_code,vilcode,inc_day,src_dist_code from dm_gis.village_src_owncode_isnull where inc_day='20230219' and src_dist_code in ('371') ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 2.2.2.2 运单关联小哥轨迹 
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_tmp;
create table dm_gis.village_src_owncode_isnull_waybill_xg_tmp(
waybill_no string comment '运单号',
consignee_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
zx string comment '经度',
zy string comment '纬度',
consigned_tm string comment '收件时间',
tm string comment '小哥轨迹时间' 
)
COMMENT "运单关联小哥轨迹（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_tmp partition(inc_day,src_dist_code) 
select 
waybill_no,consignee_emp_code,class_code,vilcode,zx,zy,consigned_tm,tm,t1.inc_day,src_dist_code  
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20230219' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,class_code,vilcode,inc_day,src_dist_code 
from dm_gis.village_src_owncode_isnull_waybill where inc_day='20230219' and src_dist_code in ('371') and consigned_tm<>'' ) as t1 
on t0.un=t1.consignee_emp_code
where consigned_tm-60*5<=tm and consigned_tm+60*5>=tm
;

-- 2.2.2.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg;
create table dm_gis.village_src_owncode_isnull_waybill_xg(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度' 
)
COMMENT "取最靠近收件日期的轨迹点（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg partition(inc_day,src_dist_code) 
select waybill_no,zx,zy,inc_day,src_dist_code 
from (
select waybill_no,inc_day,src_dist_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,inc_day,src_dist_code,zx,zy,abs(consigned_tm-tm) as diff_tm from dm_gis.village_src_owncode_isnull_waybill_xg_tmp where inc_day='20230219' and src_dist_code in ('371') ) as t  
) as t0 where t0.rn=1 
;

-- 2.2.2.4 调坐标查询行政村接口 
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_res;
create table dm_gis.village_src_owncode_isnull_waybill_xg_res (
zx string comment '',
zy string comment '',
vil_code string comment '',
vil_name string comment '',
guid string comment '' 
)
COMMENT "跑经纬坐标查询行政村（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageSrcApp"
int_sql="select zx,zy,inc_day,src_dist_code from dm_gis.village_src_owncode_isnull_waybill_xg where inc_day='20230219' and src_dist_code in ('371') group by zx,zy,inc_day,src_dist_code"
out_table="dm_gis.village_src_owncode_isnull_waybill_xg_res" 
pall_num=10000


-- 2.2.2.4  驿站编码 为空 res 
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_hy;
create table dm_gis.village_src_owncode_isnull_waybill_xg_hy (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code string comment '',
vil_name string comment '',
guid string comment '' 
)
COMMENT "驿站编码为空小哥还原（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_hy partition(inc_day,src_dist_code)  
select waybill_no,t0.zx,t0.zy,vil_code,vil_name,guid,inc_day,src_dist_code from (select waybill_no,zx,zy,inc_day,src_dist_code from dm_gis.village_src_owncode_isnull_waybill_xg where inc_day='20230219' and src_dist_code in ('371') ) as t0 
left join ( select zx,zy,vil_code,vil_name,guid from dm_gis.village_src_owncode_isnull_waybill_xg_res where inc_day='20230219' and src_dist_code in ('371') ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;

-- 
drop table if exists dm_gis.village_src_owncode_isnull_res;
create table dm_gis.village_src_owncode_isnull_res (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
vil_code string comment '',
vil_name string comment '',
guid string comment '' 
)
COMMENT "驿站编码为空res（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_res partition(inc_day,src_dist_code)  
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,vil_name,guid,inc_day,src_dist_code  
from (select waybill_no,class_code,vilcode,inc_day,src_dist_code from dm_gis.village_src_owncode_isnull where inc_day='20230219' and src_dist_code in ('371') ) as t0 
left join (select waybill_no,zx,zy,vil_code,vil_name,guid from dm_gis.village_src_owncode_isnull_waybill_xg_hy where inc_day='20230219' and src_dist_code in ('371')  ) as t1 
on t0.waybill_no=t1.waybill_no
;


-- 3 是否进乡镇上门
-- 城乡代码为220或是否进村上门为‘是’标记为‘否’；对其他的，用小哥轨迹坐标调坐标查询aoi接口（参数外延200m距离）,判断是否为乡镇上门，是：接口返回aoicode中有运单aoicode，否：接口返回aoicode中无运单aoicode

-- 3.1 运单关联获取 consigned_tm,consignee_emp_code,aoi_id,aoi_code
drop table if exists dm_gis.village_src_classcode_waybill;
create table dm_gis.village_src_classcode_waybill (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
consigned_tm string comment '',
consignee_emp_code string comment '',
aoi_id string comment '',
aoi_code string comment ''
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_src_classcode_waybill partition(inc_day,src_dist_code)  
select t1.waybill_no,t1.class_code,t1.vilcode,t0.consigned_tm,t0.consignee_emp_code,aoi_id,aoi_code,t1.inc_day,t1.src_dist_code  
from ( select waybill_no,consigned_tm,consignee_emp_code,aoi_id,aoi_code,inc_day,src_dist_code  from dm_gis.village_tt_order_hook where inc_day='20230219' and src_dist_code in ('371')  ) as t0 
left join (select waybill_no,class_code,vilcode,inc_day,src_dist_code from dm_gis.village_src_addr_decode where inc_day='20230219' and src_dist_code in ('371') and (class_code is null or class_code<>'220' ) ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 3.2 运单关联小哥轨迹  
drop table if exists dm_gis.village_src_classcode_waybill_xg_tmp;
create table dm_gis.village_src_classcode_waybill_xg_tmp (
waybill_no string comment '',
aoi_id string comment '',
aoi_code string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
consigned_tm string comment '',
tm string comment '' 
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_classcode_waybill_xg_tmp partition(inc_day,src_dist_code)  
select 
waybill_no,aoi_id,aoi_code,class_code,vilcode,zx,zy,consigned_tm,tm,t1.inc_day,src_dist_code  
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20230219' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,aoi_id,aoi_code,class_code,vilcode,inc_day,src_dist_code 
from dm_gis.village_src_classcode_waybill where inc_day='20230219' and src_dist_code in ('371') and consignee_emp_code<>'' and consigned_tm<>'' ) as t1 
on t0.un=t1.consignee_emp_code
where consigned_tm-60*5<=tm and consigned_tm+60*5>=tm
;

-- 3.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_src_classcode_waybill_xg;
create table dm_gis.village_src_classcode_waybill_xg (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '' 
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_src_classcode_waybill_xg partition(inc_day,src_dist_code)  
select waybill_no,aoi_code,zx,zy,inc_day,src_dist_code 
from (
select waybill_no,inc_day,src_dist_code,aoi_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,inc_day,src_dist_code,aoi_code,zx,zy,abs(consigned_tm-tm) as diff_tm from dm_gis.village_src_classcode_waybill_xg_tmp where inc_day='20230219'  and src_dist_code in ('371')  ) as t  
) as t0 where t0.rn=1 
;

-- 3.4 调坐标查询aoi接口
drop table if exists dm_gis.village_src_classcode_waybill_xg_res;
create table dm_gis.village_src_classcode_waybill_xg_res (
aoi_code string comment '',
lgt string comment '',
lat string comment '',
matchres string comment ''
)
COMMENT "跑经纬坐标查询aoi（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


mainClass="com.sf.gis.scala.tals.app.VillageLatLngAoiSrcApp"
int_sql="select aoi_code,zx,zy,inc_day,src_dist_code from dm_gis.village_src_classcode_waybill_xg where inc_day='20230219'  and src_dist_code in ('371')  and aoi_code<>'' group by aoi_code,zx,zy,inc_day,src_dist_code"
out_table="dm_gis.village_src_classcode_waybill_xg_res" 
pall_num=100000


-- 3.5 能关联小哥轨迹的运单查询aoi后判断是否上门的结果
drop table if exists dm_gis.village_src_classcode_waybill_xg_aoi_res;
create table dm_gis.village_src_classcode_waybill_xg_aoi_res (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
matchres string comment ''
)
COMMENT "跑经纬坐标查询aoi（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_classcode_waybill_xg_aoi_res partition(inc_day,src_dist_code)  
select waybill_no,t0.aoi_code,zx,zy,matchres,inc_day,src_dist_code from (select waybill_no,aoi_code,zx,zy,inc_day,src_dist_code from dm_gis.village_src_classcode_waybill_xg where inc_day='20230219'  and src_dist_code in ('371') ) as t0 
left join (select aoi_code,lgt,lat,matchres from dm_gis.village_src_classcode_waybill_xg_res where inc_day='20230219'  and src_dist_code in ('371') ) as t1 
on t0.aoi_code=t1.aoi_code and t0.zx=t1.lgt and t0.zy=t1.lat 
;
 




-- 4 快递上门结果表 （收件）
create table dm_gis.village_src_kdsm_res (
src_hq_code	string comment '大区代码',
src_area_code	string comment '地区代码',
area_name	string comment '地区名称',
source_zone_code	string comment '网点代码',
dept_name	string comment '网点名称',
waybill_no	string comment '单号',
consignee_emp_code	string comment '派件人工号',
real_product_code	string comment '产品名称',
meterage_weight_qty	string comment '计费重量',
pay_cust_type	string comment '付费客户类型',
service_prod_code	string comment '增值服务代码',
all_fee_rmb	string comment '总收入（rmb）',
freight_monthly_acct_code	string comment '月结账号',
is_yj	string comment '是否月结',
aoi_code	string comment 'AOI编码',
aoi_name	string comment 'AOI名称',
aoi_type_name	string comment 'aoi类型名称',
aoi_area_code	string comment 'AOI区域',
province	string comment '省',
city	string comment '市/市辖区',
county	string comment '区/县',
town	string comment '镇/乡',
town_adcode	string comment '镇adcode',
vil_name	string comment '行政村/社区',
vil_code	string comment '村adcode',
class_code	string comment '城乡分类代码',
own_code	string comment '驿站编码',
is_jcpj	string comment '是否进村派件',
is_jxzpj	string comment '是否为乡镇上门派件',
yd_type	string comment '运单类型',
wd_type	string comment '网点类型' 	
)
COMMENT "行政村快递上门（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",src_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;




insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day,src_dist_code) 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vilname,vilcode,class_code,
own_code,is_jcpj,is_jxzpj,
case when (class_code='220') or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type ,
wd_type,
inc_day,src_dist_code
from (
select 
src_hq_code,src_area_code,t5.area_name,source_zone_code,t5.dept_name,t0.waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
case when freight_monthly_acct_code<>'' then '1' else '0' end as is_yj,
t0.aoi_code,t0.aoi_name,aoi_type_name,t6.aoi_area_code,
t1.province,t1.city,t1.county,t1.town,t1.town_adcode,t1.vilname,t1.vilcode,t1.class_code,
t7.own_code,
case when t2.own_code_check is not null or (t3.vil_code is not null and t3.vilcode=t3.vil_code) then '1' else '0' end as is_jcpj,
case when t4.matchres='1'  then '1' else '0' end as is_jxzpj,
case when t5.dept_type_code='DB05-DLD' then '代理' else '自营' end as wd_type,
t0.inc_day,t0.src_dist_code
from (
select waybill_no,consigned_tm,src_hq_code,src_area_code,source_zone_code,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
src_county,consignor_addr,
inc_day,src_dist_code  from dm_gis.village_tt_order_hook where inc_day='20230219' and src_dist_code in ('371')  ) as t0 
left join ( select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,inc_day,src_dist_code  
from dm_gis.village_src_addr_decode where inc_day='20230219' and src_dist_code in ('371') ) as t1 
on t0.waybill_no=t1.waybill_no 
left join (select waybill_no,class_code,vilcode,own_code,own_code_check,village_code,inc_day,src_dist_code 
from dm_gis.village_src_owncode_isnotnull_res where inc_day='20230219' and src_dist_code in ('371') ) as t2 
on t0.waybill_no=t2.waybill_no 
left join (select waybill_no,class_code,vilcode,inc_day,src_dist_code,zx,zy,vil_code,vil_name,guid 
from dm_gis.village_src_owncode_isnull_res where inc_day='20230219' and src_dist_code in ('371')   ) as t3 
on t0.waybill_no=t3.waybill_no 
left join (select waybill_no,inc_day,src_dist_code,aoi_code,zx,zy,matchres from dm_gis.village_src_classcode_waybill_xg_aoi_res where inc_day='20230219' and src_dist_code in ('371') ) as t4 
on t0.waybill_no=t4.waybill_no 
left join (select dept_code,area_name,dept_name,dept_type_code from (select dept_code,area_name,dept_name,dept_type_code,row_number() over(partition by dept_code order by inc_day desc)  as rn 
from  dim.dim_dept_info_df where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') ) as b where b.rn=1 ) as t5 
on t0.source_zone_code=t5.dept_code 
left join dm_tc_waybillinfo.aoi_area_aoi as t6 
on t0.aoi_code=t6.aoi_id 
left join (select waybill_no,own_code from dm_gis.village_src_owncode_isnotnull where inc_day='20230219' and src_dist_code in ('371') ) as t7 
on t0.waybill_no=t7.waybill_no 
) as t 
;




