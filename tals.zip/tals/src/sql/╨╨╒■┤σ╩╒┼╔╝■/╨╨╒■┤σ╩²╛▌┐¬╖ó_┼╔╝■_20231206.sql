-- 
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- 需求：  
-- @author 张小琼 （01416344）
-- Created on 2023-12-06
-- 任务信息： 
-- 

------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 运单（派件） 
create table dm_gis.village_dest_waybill_info_di(
dest_hq_code string comment '目的地经营本部（大区）',
dest_area_code string comment '目的地区部（地区代码）',
dest_zone_code string comment '目的地网点代码（网点代码）',
dest_type_code string comment '网点类型代码',
waybill_no string comment '运单号',
consignee_addr  string comment '收件地址',
deliver_emp_code string comment '派件员',
product_code string comment '产品代码',
meterage_weight_qty_kg string comment '计费重量',
service_prod_code string comment '增值服务代码',
all_fee_rmb string comment '总收入',
freight_monthly_acct_code string comment '月结账号',
aoi_code string comment 'aoi编码',
aoi_id string comment 'aoi id',
aoi_name string comment 'aoi名称',
aoi_type string comment 'AOI类型',
signin_tm string comment '收件时间',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "行政村运单（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



-- 
insert overwrite table  dm_gis.village_dest_waybill_info_di partition(inc_day='$firstDay') 
select 
dest_hq_code,dest_area_code,dest_zone_code,dest_type_code,
waybill_no,consignee_addr,deliver_emp_code,product_code,meterage_weight_qty_kg,
service_prod_code,all_fee_rmb,freight_monthly_acct_code,
aoi_code,aoi_id,aoi_name,aoi_type,signin_tm,
dest_dist_code 
from (select 
inc_day,
dest_hq_code,dest_area_code,dest_zone_code,dest_type_code,
waybill_no,consignee_addr,deliver_emp_code,product_code,meterage_weight_qty_kg,
service_prod_code,all_fee_rmb,freight_monthly_acct_code,
aoi_code,aoi_id,aoi_name,aoi_type,signin_tm,
dest_dist_code,
row_number() over(partition by waybill_no order by inc_day desc) as rn 
from (select 
inc_day,
dest_hq_code,dest_area_code,dest_zone_code,dest_type_code,
waybill_no,
consignee_addr_decrypt as consignee_addr,
deliver_emp_code,
product_code,
meterage_weight_qty_kg,
service_prod_code,
all_fee_rmb,
freight_monthly_acct_code,
if(addressee_aoi_dept_code_fix is not null and trim(addressee_aoi_dept_code_fix)<>'',addressee_aoi_dept_code_fix,addressee_aoi_dept_code) as aoi_code,
if(addressee_aoi_id_fix is not null and trim(addressee_aoi_id_fix)<>'',addressee_aoi_id_fix,addressee_aoi_id) as aoi_id,
addressee_aoi_name as aoi_name,
addresseeaoitype as aoi_type,
signin_tm,
dest_dist_code 
from dm_gis.dwd_waybill_info_dtl_di 
where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-15),'-','')  and inc_day<='$firstDay' 
and ackbill_type_code not in ('9','2') 
and signin_tm<>'' 
and replace(substr(signin_tm,1,10),'-','')='$firstDay'
) as t 
) as tt where tt.rn=1
;




------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 数据准备
-- 1.1
-- 地区名称	dim.dim_dept_info_df，inc_day选最新一天	area_name	利用网点代码dest_zone_code匹配该表dept_code获取area_name
-- 网点名称	dim.dim_dept_info_df，inc_day选最新一天	dept_name	利用网点代码dest_zone_code匹配该表dept_code获取dept_name
-- select dept_code,area_name,dept_name,dept_type_code 
-- from (select dept_code,area_name,dept_name,dept_type_code,row_number() over(partition by dept_code order by inc_day desc)  as rn 
-- from  dim.dim_dept_info_df where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') ) as b where b.rn=1

-- 1.2
-- Aoisrc	dm_gis.gis_rds_omsto	finalaoidetailsrc	利用运单号匹配表dm_gis.gis_rds_omsto（inc_day=T-1至T-8）中的req_waybillno，命中则获取finalaoidetailsrc
-- select req_waybillno,finalaoidetailsrc from dm_gis.gis_rds_omsto  
-- where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay'

-- 1.3
-- AOI区域	dm_tc_waybillinfo.aoi_area_aoi	aoi_area_code	
-- 利用AOI编码匹配该表的aoi_id获取aoi_area_code
-- AOI区域类型名称	dm_tc_waybillinfo.aoi_area_aoi	aoi_area_type	
-- 利用AOI编码匹配该表的aoi_id获取aoi_area_type

-- left join dm_tc_waybillinfo.aoi_area_aoi as t6 
-- on t0.aoi_code=t6.aoi_id 

-- -- 1.4


-- 1.5
-- 是否同城件  同城件经纬度
-- select 
-- waybill_no,driver_track,get_json_object(lonlat_json,'$.x') as zx , get_json_object(lonlat_json,'$.y') as zy
-- from (select waybill_no,driver_track from dm_gis.sf_order_rider_track 
-- where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay' 
-- and driver_track<>'' group by vilcode,driver_track) as t
-- lateral view explode(split(regexp_replace(regexp_replace(driver_track, '\\}\\, \\{','\\}\\;\\{'),'\\[|\\]',''),'\\;')) dt as lonlat_json 
-- ;


------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 2.1  5级地址解析  
-- 省
-- 市/市辖区
-- 区/县
-- 镇/乡
-- 镇code
-- 村code
-- 行政村/社区  (后面判断)
-- 城乡分类代码 

create table dm_gis.village_dest_level5_addr_decode_di(
waybill_no string comment '运单号',
consignee_addr string comment '收件地址',
province string comment '',
city string comment '',
county string comment '',
town string comment '',
vilname string comment '村级名称',
vilcode string comment '村级编码',
town_adcode string comment '乡镇编码',
class_code string comment '城乡分类代码',
distance string comment '到网点距离',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "5级地址（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



-- 1、利用aoi id（只用finalaoidetailsrc=norm和chkn下的AOI）到表dm_gis.cms_aoi_village（最新inc_day）中获取village_guid
-- 2、利用village_guid匹配表dm_gis.emap_district_village（最新inc_day）中的 guid，命中则返回 name_p、 name_c、 name_d、 name_t、 adcode_t、 name、 area_code、 class_code、 distant，否则跳到3
-- 3、利用地址和city code与表dm_gis.village_log_flink_res（inc_day的最近7天）的 p_address和p_city_code进行匹配,都命中则获取 r_province、 r_city、 r_county、 r_town、 r_vilname、 r_vilcode、 r_town_adcode和 r_class_code，否则通过行政村查询接口查询，获取对应数据

-- 2.1.1 通过aoi id获取 
-- 表dm_gis.cms_aoi_village，表dm_gis.emap_district_village  
-- 取最新分区数据
table1='dm_gis.cms_aoi_village'
v_partition=`hive -e  "show partitions $table1" | grep "inc_day=*" | sort | tail -n 1`
last_partition=${v_partition:10:8}
echo ${last_partition}

hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

drop table if exists dm_gis.tmp_village_cms_aoi_village_mid;
create table dm_gis.tmp_village_cms_aoi_village_mid  stored as parquet as 
select city_code,aoi_id,village_guid from dm_gis.cms_aoi_village where inc_day='${last_partition}' and aoi_id is not null and aoi_id<>'' and village_guid is not null and village_guid<>''  group by city_code,aoi_id,village_guid;
"

-- 
table1='dm_gis.emap_district_village'
v_partition=`hive -e  "show partitions $table1" | grep "inc_day=*" | sort | tail -n 1`
last_partition=${v_partition:10:8}
echo ${last_partition}

hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

drop table if exists dm_gis.tmp_village_emap_district_village_mid;
create table dm_gis.tmp_village_emap_district_village_mid stored as parquet as 
select guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant from dm_gis.emap_district_village where inc_day='${last_partition}' group by guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant;
"


-- 获取aoi_id  获取满足finalaoidetailsrc=norm和chkn下的运单aoi_id
drop table if exists dm_gis.tmp_village_dest_aoisrc_mid;
create table dm_gis.tmp_village_dest_aoisrc_mid stored as parquet  as 
select t0.waybill_no,t0.inc_day,t0.dest_dist_code,t0.consignee_addr,t0.aoi_id    
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr,aoi_id 
from dm_gis.village_dest_waybill_info_di 
where inc_day='$firstDay' and aoi_id is not null and aoi_id<>'' ) as t0 
left join ( select req_waybillno 
from dm_gis.gis_rds_omsto 
where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay' 
and req_waybillno is not null and req_waybillno<>'' 
and (finalaoidetailsrc='norm' or finalaoidetailsrc='chkn') group by req_waybillno ) as t1 
on t0.waybill_no=t1.req_waybillno 
where t1.req_waybillno is not null 
;

-- 获取village_guid
drop table if exists dm_gis.tmp_village_dest_guid_mid;
create table dm_gis.tmp_village_dest_guid_mid  stored as parquet  as 
select t0.waybill_no,t0.inc_day,t0.dest_dist_code,t0.consignee_addr,t0.aoi_id,t1.village_guid   
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr,aoi_id  from dm_gis.tmp_village_dest_aoisrc_mid where  aoi_id is not null and aoi_id<>'' ) as t0 
left join  (select city_code,aoi_id,village_guid from dm_gis.tmp_village_cms_aoi_village_mid where village_guid is not null and village_guid<>'')  as t1 
on t0.dest_dist_code=t1.city_code and t0.aoi_id=t1.aoi_id 
;

insert overwrite table  dm_gis.village_dest_level5_addr_decode_di partition(inc_day) 
select waybill_no,consignee_addr,name_p as province,name_c as city,name_d as county,name_t as town,name as vilname,area_code as vilcode,adcode_t as town_adcode,class_code,distant,dest_dist_code,inc_day   
from dm_gis.tmp_village_dest_guid_mid as t0 
left join ( select guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant from dm_gis.tmp_village_emap_district_village_mid ) as t1 
on t0.village_guid=t1.guid
where t1.guid is not null 
;



-- 2.1.2 从历史解析日志中获取 

-- 行政村查询接口日志数据 dm_gis.village_log_flink_res （最近7天）
hive -e "
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis.tmp_village_village_log_flink_res_mid;
create table dm_gis.tmp_village_village_log_flink_res_mid stored as parquet as 
select p_address,p_city_code,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance
from (
select p_address,p_city_code,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,
row_number() over( partition by p_address,p_city_code order by r_distance desc ) as rn  
from dm_gis.village_log_flink_res where inc_day>=date_format(date_add(current_date(),-7),'yyyyMMdd') and inc_day<date_format(current_date(),'yyyyMMdd') and r_status='0' 
) as t where t.rn=1 
;
"


drop table if exists dm_gis.tmp_village_dest_addr_decode_log_mid;
create table dm_gis.tmp_village_dest_addr_decode_log_mid stored as parquet as 
select t0.waybill_no,t0.inc_day,t0.dest_dist_code,t0.consignee_addr  
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr from dm_gis.village_dest_waybill_info_di  where inc_day='$firstDay'  ) as t0 
left join ( select waybill_no from dm_gis.village_dest_level5_addr_decode_di where inc_day='$firstDay'  group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
;

insert into  dm_gis.village_dest_level5_addr_decode_di partition(inc_day) 
select t1.waybill_no,t1.consignee_addr,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,
t1.dest_dist_code,t1.inc_day   
from dm_gis.tmp_village_village_log_flink_res_mid as t0 
left join ( select waybill_no,inc_day,dest_dist_code,consignee_addr from dm_gis.tmp_village_dest_addr_decode_log_mid  ) as t1 
on t0.p_city_code=t1.dest_dist_code and t0.p_address=t1.consignee_addr  
where t1.waybill_no is not null 
;


-- 需要等收件跑完再删除
drop table if exists dm_gis.tmp_village_dest_aoisrc_mid;
drop table if exists dm_gis.tmp_village_emap_district_village_mid;
drop table if exists dm_gis.tmp_village_cms_aoi_village_mid;
drop table if exists dm_gis.tmp_village_dest_addr_decode_log_mid;
drop table if exists dm_gis.tmp_village_village_log_flink_res_mid;



-- 2.1.3 调接口获取
-- http://gis-gw.intsit.sfdc.com.cn:9080/village/

-- 
mainClass="com.sf.gis.scala.tals.app.VillageAddrLevel5AddrDestApp"
int_sql="
select t0.waybill_no,t0.inc_day,t0.dest_dist_code as yd_citycode,t0.consignee_addr as yd_addr  
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr from dm_gis.village_dest_waybill_info_di where inc_day='$firstDay' ) as t0 
left join ( select waybill_no from dm_gis.village_dest_level5_addr_decode_di where inc_day='$firstDay'  group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
"
out_table="dm_gis.village_dest_level5_addr_decode_di"
pall_num=20000



-- 2.1.4 运单5级地址去重
insert overwrite table  dm_gis.village_dest_level5_addr_decode_di partition(inc_day) 
select waybill_no,consignee_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,dest_dist_code,inc_day
from (select waybill_no,consignee_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,inc_day,dest_dist_code,
row_number() over(partition by waybill_no,dest_dist_code,inc_day order by vilcode desc) as rn from dm_gis.village_dest_level5_addr_decode_di where inc_day='$firstDay' 
) as t where t.rn=1 
;



------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 2.2 是否进村 
-- 2.2.1 驿站编码 不为空
drop table if exists dm_gis.village_dest_owncode_isnotnull_mid;
create table dm_gis.village_dest_owncode_isnotnull_mid(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码',
dest_dist_code STRING COMMENT "分区城市代码",
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
lonlat_tag string COMMENT '出入库标签'
)
COMMENT "驿站编码不为空（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
insert overwrite table dm_gis.village_dest_owncode_isnotnull_mid partition(inc_day) 
select 
waybill_no,class_code,vilcode,own_code,dest_dist_code,operate_longitude,operate_latitude,lonlat_tag,inc_day 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_level5_addr_decode_di where inc_day='$firstDay' ) as t0  
left join
(select mailno,own_code,
if(pj_operate_longitude<>'' and pj_operate_longitude<>'nan',pj_operate_longitude,operate_longitude) as operate_longitude,
if(pj_operate_latitude<>'' and pj_operate_latitude<>'nan',pj_operate_latitude,operate_latitude) as operate_latitude,
case when (pj_operate_longitude<>'' and pj_operate_longitude<>'nan') then '1' 
when (operate_longitude<>'' and operate_longitude<>'nan') then '2' 
else '' end as lonlat_tag 
from dm_yjy.yjy_mailno_kb where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay' and type='派件') as t1 
on t0.waybill_no=t1.mailno 
where t1.mailno is not null
;


-- 坐标系转换（百度转高德）
drop table if exists dm_gis.village_dest_lonlat_transform_mid;
create table dm_gis.village_dest_lonlat_transform_mid(
bd_lon string comment '百度经度',
bd_lat string comment '百度纬度',
gd_lon_lat string comment '高德经纬坐标'
)
COMMENT "坐标系转换（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLonLatTransformApp"
int_sql="select operate_longitude as bd_lon,operate_latitude as bd_lat from dm_gis.village_dest_owncode_isnotnull_mid where inc_day='$firstDay' and operate_longitude<>'' and operate_longitude<>'nan' group by operate_longitude,operate_latitude"
out_table="dm_gis.village_dest_lonlat_transform_mid" 


insert overwrite table dm_gis.village_dest_owncode_isnotnull_mid partition(inc_day='$firstDay') 
select waybill_no,class_code,vilcode,own_code,dest_dist_code,gd_lon as operate_longitude,gd_lat as operate_latitude,lonlat_tag   
from (select 
waybill_no,class_code,vilcode,own_code,dest_dist_code,operate_longitude,operate_latitude,lonlat_tag,inc_day 
from dm_gis.village_dest_owncode_isnotnull_mid where inc_day='$firstDay' ) as t0 
left join (select bd_lon,bd_lat,split(gd_lon_lat,',')[0] as gd_lon,split(gd_lon_lat,',')[1] as gd_lat from dm_gis.village_dest_lonlat_transform_mid where inc_day='$firstDay') as t1 
on t0.operate_longitude=t1.bd_lon and t0.operate_latitude=t1.bd_lat 
;



-- 1、当城乡分类代码不为220、210时，填入否；当城乡分类代码=220、210时，往下走
-- 2、判断是否同城件
-- （1）若为同城件则用waybill_no获取表dm_gis.sf_order_rider_track中的driver_track数据，并解析出时间戳和经纬度，用于跑接口http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=500获取行政村list若行政村list中存在areaCode与村code匹配则为是，否则为否；
-- （2）不为同城件则往下走，
-- 3、判断驿站编码是否为空：
-- （1）不为空：利用驿站收件经纬度跑接口
-- http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=1000获取行政村list，若行政村list中存在areaCode与村code匹配则为是，否则为否
-- （2）为空：用揽收时间的前后5分钟的最靠近收件时间的3个（不足3个则全取）小哥轨迹到http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getVillageByCoorRadius?x=114.182345&y=22.633745&radius=500获取村adcode list，与前面获取的村adcode进行匹配，存在命中则为是，否则为否

-- 2.2.1.0
-- 通过同城件判断
drop table if exists dm_gis.village_dest_driver_track_mid;
create table dm_gis.village_dest_driver_track_mid(
waybill_no string comment '运单号',
driver_track string comment '轨迹坐标',
class_code string comment '类型',
vilcode string comment '村编码'
)
COMMENT "集派判断上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_driver_track_mid partition(inc_day='$firstDay')
select t0.waybill_no,driver_track,class_code,vilcode  
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_level5_addr_decode_di where inc_day='$firstDay' and class_code in ('220','210')  ) as t0  
left join (
select waybill_no,driver_track from dm_gis.sf_order_rider_track where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay'
) as t1 
on t0.waybill_no=t1.waybill_no
;
 


-- 同城件经纬坐标判断为是的（调接口）
drop table if exists dm_gis.village_dest_driver_track_res_mid;
create table dm_gis.village_dest_driver_track_res_mid(
waybill_no string comment '运单号',
driver_track string comment '轨迹坐标',
class_code string comment '类型',
vilcode string comment '村编码',
tc_res  string comment '判断结果'
)
COMMENT "集派判断上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
; 


drop table if exists dm_gis.village_dest_driver_track_api_mid;
create table dm_gis.village_dest_driver_track_api_mid(
vilcode string comment '村编码',
driver_track string comment '轨迹坐标',
tc_res  string comment '判断结果'
)
COMMENT "同城件经纬坐标判断进村上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
; 



mainClass="com.sf.gis.scala.tals.app.VillageLatLngDriverTrackRadius500App"
int_sql="select 
vilcode,driver_track,get_json_object(lonlat_json,'$.x') as zx , get_json_object(lonlat_json,'$.y') as zy
from (select vilcode,driver_track from dm_gis.village_dest_driver_track_mid where inc_day='$firstDay' and vilcode is not null and vilcode<>'' and driver_track<>'' group by vilcode,driver_track) as t
lateral view explode(split(regexp_replace(regexp_replace(driver_track, '\\\\}\\\\, \\\\{','\\\\}\\\\;\\\\{'),'\\\\[|\\\\]',''),'\\\\;')) dt as lonlat_json 
"
out_table="dm_gis.village_dest_driver_track_api_mid" 
pall_num=20000
inc_day='$firstDay'



insert overwrite table dm_gis.village_dest_driver_track_res_mid partition(inc_day='$firstDay')
select waybill_no,t0.driver_track,class_code,t0.vilcode,tc_res from dm_gis.village_dest_driver_track_mid as t0 
left join (select vilcode,driver_track,tc_res from dm_gis.village_dest_driver_track_api_mid where inc_day='$firstDay') as t1 
on t0.vilcode=t1.vilcode and t0.driver_track=t1.driver_track
;



-- 2.2.2.1 驿站编码 不为空
-- 1）利用驿站收件经纬度跑接口  (先过滤同城件判断为是的)
create table dm_gis.village_dest_owncode_isnotnull_api_res_mid(
vilcode string comment '村编码',
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
match_res string COMMENT '是否',
dest_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "驿站编码不为空（派件）接口判断结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadiusApp"
int_sql="select vilcode,operate_longitude,operate_latitude,dest_dist_code as dist_code,inc_day from (
select 
t0.waybill_no,vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day 
from (
select waybill_no,vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnotnull_mid 
where inc_day='$firstDay' and class_code in ('220','210') and vilcode is not null and vilcode<>'' and operate_longitude is not null and operate_longitude<>'' and operate_latitude is not null and operate_latitude<>''
) as t0 
left join (
select waybill_no from dm_gis.village_dest_driver_track_res_mid where inc_day='$firstDay' and  tc_res='1' ) as t1 
on t0.waybill_no=t1.waybill_no 
where  t1.waybill_no is null 
) as t
group by vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day "
out_table="dm_gis.village_dest_owncode_isnotnull_api_res_mid" 
pall_num=10000



-- 2.2.2.2 驿站编码 为空
-- 用揽收时间的前后5分钟的最靠近收件时间的3个（不足3个则全取）小哥轨迹
drop table if exists dm_gis.village_dest_owncode_isnull_mid;
create table dm_gis.village_dest_owncode_isnull_mid(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_owncode_isnull_mid partition(inc_day) 
select t0.waybill_no,class_code,vilcode,dest_dist_code,inc_day
from ( select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_level5_addr_decode_di where inc_day='$firstDay' and class_code in ('220','210') ) as t0 
left join (select waybill_no from dm_gis.village_dest_owncode_isnotnull_mid where inc_day='$firstDay' and class_code in ('220','210') group by waybill_no) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
;


-- 2.2.2.2.1 运单关联获取signin_tm,deliver_emp_code
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_mid;
create table dm_gis.village_dest_owncode_isnull_waybill_mid(
waybill_no string comment '运单号',
signin_tm string comment '收件时间',
deliver_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取signin_tm,deliver_emp_code（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_mid partition(inc_day) 
select 
t0.waybill_no,t0.signin_tm,t0.deliver_emp_code,
t1.class_code,t1.vilcode,t1.dest_dist_code,
t1.inc_day 
from ( select waybill_no,signin_tm,deliver_emp_code,dest_dist_code,inc_day from dm_gis.village_dest_waybill_info_di where inc_day='$firstDay' ) as t0 
left join (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_mid where inc_day='$firstDay' ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 2.2.2.2.2 运单关联小哥轨迹 
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_gj_mid;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_gj_mid(
waybill_no string comment '运单号',
deliver_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
zx string comment '经度',
zy string comment '纬度',
signin_tm string comment '收件时间',
tm string comment '小哥轨迹时间',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联小哥轨迹（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_gj_mid partition(inc_day) 
select 
waybill_no,deliver_emp_code,class_code,vilcode,zx,zy,signin_tm,tm,t1.dest_dist_code,t1.inc_day 
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(signin_tm) as signin_tm,deliver_emp_code,class_code,vilcode,dest_dist_code,inc_day
from dm_gis.village_dest_owncode_isnull_waybill_mid where inc_day='$firstDay'  and signin_tm<>'' ) as t1 
on t0.un=t1.deliver_emp_code
where signin_tm-60*5<=tm and signin_tm+60*5>=tm
;

-- 2.2.2.2.3 取最靠近收件日期的轨迹点 (top1的)
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_mid;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_mid(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期的轨迹点（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_mid partition(inc_day) 
select waybill_no,zx,zy,dest_dist_code,inc_day
from (
select waybill_no,inc_day,dest_dist_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,inc_day,dest_dist_code,zx,zy,abs(signin_tm-tm) as diff_tm from dm_gis.village_dest_owncode_isnull_waybill_xg_gj_mid where inc_day='$firstDay'  ) as t  
) as t0 where t0.rn=1 
;



-- 2.2.2.2.4 调坐标查询行政村接口 (派件收件一起跑)
drop table if exists dm_gis.village_owncode_isnull_waybill_xg_mid;
create table dm_gis.village_owncode_isnull_waybill_xg_mid(
zx string comment '经度',
zy string comment '纬度',
dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期的轨迹点" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 先调接口获取adcode list
drop table if exists dm_gis.village_owncode_isnull_waybill_xg_json_mid;
create table dm_gis.village_owncode_isnull_waybill_xg_json_mid (
zx string comment '',
zy string comment '',
json_str string comment '接口返回的的json数据',
dist_code STRING COMMENT "分区城市代码",
api_res string comment '接口返回结果'
)
COMMENT "跑经纬坐标查询行政村" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
insert overwrite table dm_gis.village_owncode_isnull_waybill_xg_mid partition(inc_day) 
select zx,zy,dist_code,inc_day
from (
select zx,zy,dest_dist_code as dist_code,inc_day
from (
select zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg_mid where inc_day='$firstDay' ) as a
union all 
select zx,zy,src_dist_code as dist_code,inc_day 
from (
select zx,zy,src_dist_code,inc_day from dm_gis.village_src_owncode_isnull_waybill_xg_mid where inc_day='$firstDay'  ) as b
) as c 
group by zx,zy,dist_code,inc_day 
;


-- 跑接口 （小哥轨迹 top1）
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadius500App"
int_sql="select zx,zy,dist_code,inc_day from dm_gis.village_owncode_isnull_waybill_xg_mid where inc_day='$firstDay' "
out_table="dm_gis.village_owncode_isnull_waybill_xg_json_mid" 
pall_num=10000




-- 驿站编码 为空 res 
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_hy_mid;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_hy_mid (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "驿站编码为空小哥还原（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_mid;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_mid stored as parquet  as 
select  zx,zy,get_json_object(ss.col,'$.objCode') as obj_code
from (select zx,zy,
split(regexp_replace(regexp_extract(json_str,'^\\\\[(.+)\\\\]$',1),'\\\\}\\\\,\\\\{', '\\\\}\\\\|\\\\|\\\\{'),'\\\\|\\\\|') as dstr
from dm_gis.village_owncode_isnull_waybill_xg_json_mid where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
;

drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set_mid;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set_mid stored as parquet  as 
select 
zx,zy,collect_set(obj_code) as obj_code_set 
from dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_mid where obj_code is not null and obj_code<>'' group by zx,zy 
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_hy_mid partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,dest_dist_code,inc_day 
from (select waybill_no,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg_mid where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set_mid ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;



drop table if exists dm_gis.village_dest_owncode_isnull_res_mid;
create table dm_gis.village_dest_owncode_isnull_res_mid (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
adcode_isin string comment 'adcode是否在adcode list中',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "驿站编码为空res（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 判断 adcode是不是在array中，例如： if(array_contains(obj_code_set,'620723106206'),1,0)
insert overwrite table dm_gis.village_dest_owncode_isnull_res_mid partition(inc_day)  
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,dest_dist_code,inc_day 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_mid where inc_day='$firstDay' ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_dest_owncode_isnull_waybill_xg_hy_mid where inc_day='$firstDay' ) as t1 
on t0.waybill_no=t1.waybill_no
;


-- 对上面用了最近1个小哥轨迹未判断出进村的部分，再用揽收时间的前后5分钟的最靠近收件时间的3个（不足3个则全取）小哥轨迹
-- top3 小哥轨迹 （派件） 去掉已经识别成功的部分
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_top3_mid;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_top3_mid(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期top3的轨迹点（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_top3_mid partition(inc_day) 
select waybill_no,zx,zy,dest_dist_code,inc_day
from (
select waybill_no,inc_day,dest_dist_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select t0.waybill_no,inc_day,dest_dist_code,zx,zy,abs(signin_tm-tm) as diff_tm 
from (select waybill_no,inc_day,dest_dist_code,zx,zy,signin_tm,tm from dm_gis.village_dest_owncode_isnull_waybill_xg_gj_mid where inc_day='$firstDay' ) as t0 
left join (select waybill_no from dm_gis.village_dest_owncode_isnull_res_mid where inc_day='$firstDay' and adcode_isin='1'  ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
 ) as t  
) as t0 where t0.rn<=3 
;

-- top3 小哥轨迹 （收件） 去掉已经识别成功的部分
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_top3_mid;
create table dm_gis.village_src_owncode_isnull_waybill_xg_top3_mid(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度',
src_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期top3的轨迹点（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_top3_mid partition(inc_day) 
select waybill_no,zx,zy,src_dist_code,inc_day  
from (
select waybill_no,src_dist_code,inc_day ,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select t0.waybill_no,src_dist_code,inc_day ,zx,zy,abs(consigned_tm-tm) as diff_tm 
from (select waybill_no,inc_day,src_dist_code,zx,zy,consigned_tm,tm from dm_gis.village_src_owncode_isnull_waybill_xg_gj_mid where inc_day='$firstDay' ) as t0 
left join (select waybill_no from dm_gis.village_src_owncode_isnull_res_mid where inc_day='$firstDay' and adcode_isin='1'  ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
) as t  
) as t0 where t0.rn<=3 
;


-- 需要再跑的小哥轨迹（派件收件一起）  top3去掉top1的部分
drop table if exists dm_gis.village_owncode_isnull_waybill_xg_top3_mid;
create table dm_gis.village_owncode_isnull_waybill_xg_top3_mid(
zx string comment '经度',
zy string comment '纬度',
dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "取最靠近收件日期的top3轨迹点" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table if exists dm_gis.village_owncode_isnull_waybill_xg_top3_json_mid;
create table dm_gis.village_owncode_isnull_waybill_xg_top3_json_mid (
zx string comment '',
zy string comment '',
json_str string comment '接口返回的的json数据',
dist_code STRING COMMENT "分区城市代码",
api_res string comment '接口返回结果'
)
COMMENT "跑经纬坐标查询行政村(top3)" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_owncode_isnull_waybill_xg_top3_mid partition(inc_day) 
select t0.zx,t0.zy,t0.dist_code,t0.inc_day from (
select zx,zy,dist_code,inc_day
from (
select zx,zy,dest_dist_code as dist_code,inc_day
from (
select zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg_top3_mid where inc_day='$firstDay' ) as a
union all 
select zx,zy,src_dist_code as dist_code,inc_day 
from (
select zx,zy,src_dist_code,inc_day from dm_gis.village_src_owncode_isnull_waybill_xg_top3_mid where inc_day='$firstDay'  ) as b
) as c 
group by zx,zy,dist_code,inc_day 
) as t0 
left join (select zx,zy,dist_code,inc_day from dm_gis.village_owncode_isnull_waybill_xg_mid where inc_day='$firstDay' ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy and t0.dist_code=t1.dist_code 
where t1.inc_day is null 
;


-- 跑 小哥轨迹获取村编码list 接口 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadius500App"
int_sql="select zx,zy,dist_code,inc_day from dm_gis.village_owncode_isnull_waybill_xg_top3_mid where inc_day='$firstDay' "
out_table="dm_gis.village_owncode_isnull_waybill_xg_top3_json_mid" 
pall_num=20000


-- 小哥轨迹 运单 村编码list  还原 （派件）
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy_mid;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy_mid (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "驿站编码为空小哥还原（派件）(top3)" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 小哥轨迹 运单 村编码list  还原 （收件）
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy_mid;
create table dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy_mid (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空小哥还原（收件）(top3)" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

--  解析adcode list （派件收件一起） (shell脚本需要把\\换成\\\\)
drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_mid;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_mid stored as parquet as 
select  zx,zy,get_json_object(ss.col,'$.objCode') as obj_code
from (select zx,zy,
split(regexp_replace(regexp_extract(json_str,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis.village_owncode_isnull_waybill_xg_top3_json_mid where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
;

drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set_mid;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set_mid stored as parquet as 
select 
zx,zy,collect_set(obj_code) as obj_code_set 
from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode where obj_code is not null and obj_code<>'' group by zx,zy 
;

-- 还原 （派件）
insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy_mid partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,dest_dist_code,inc_day 
from (select waybill_no,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg_top3_mid where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set_mid ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;

-- 还原 （收件）
insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy_mid partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,src_dist_code,inc_day  
from (select waybill_no,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_waybill_xg_top3_mid where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set_mid  ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;


-- top3结果整合top1结果 （派件）
insert overwrite table dm_gis.village_dest_owncode_isnull_res_mid partition(inc_day)  
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day,row_number() over(partition by waybill_no order by adcode_isin desc) as rn 
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_res_mid where inc_day='$firstDay' and adcode_isin='1' 
union all 
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,dest_dist_code,inc_day 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_res_mid where inc_day='$firstDay' and (adcode_isin is null or adcode_isin<>'1') ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy_mid where inc_day='$firstDay' ) as t1 
on t0.waybill_no=t1.waybill_no 
) as t 
) as tt where tt.rn=1
;

-- top3结果整合top1结果 （收件）
insert overwrite table dm_gis.village_src_owncode_isnull_res_mid partition(inc_day) 
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day 
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day,row_number() over(partition by waybill_no order by adcode_isin desc) as rn 
from (    
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day from dm_gis.village_src_owncode_isnull_res_mid where inc_day='$firstDay' and adcode_isin='1' 
union all 
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,src_dist_code,inc_day   
from (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_res_mid where inc_day='$firstDay' and (adcode_isin is null or adcode_isin<>'1') ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy_mid where inc_day='$firstDay'   ) as t1 
on t0.waybill_no=t1.waybill_no 
) as t 
) as tt where tt.rn=1
;


------------------------------------------------------------------------------------
------------------------------------------------------------------------------------

-- 3 是否进乡镇上门
-- 城乡代码为220或是否进村上门为‘是’标记为‘否’；对其他的，用小哥轨迹坐标调坐标查询aoi接口（参数外延200m距离）,判断是否为乡镇上门，是：接口返回aoicode中有运单aoicode，否：接口返回aoicode中无运单aoicode

-- 3.1 运单关联获取 signin_tm,deliver_emp_code,aoi_id,aoi_code
drop table if exists dm_gis.village_dest_classcode_waybill_mid;
create table dm_gis.village_dest_classcode_waybill_mid (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
signin_tm string comment '',
deliver_emp_code string comment '',
aoi_id string comment '',
aoi_code string comment '',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_classcode_waybill_mid partition(inc_day)  
select t1.waybill_no,t1.class_code,t1.vilcode,t0.signin_tm,t0.deliver_emp_code,aoi_id,aoi_code,t1.dest_dist_code,t1.inc_day  
from ( select waybill_no,signin_tm,deliver_emp_code,aoi_id,aoi_code,dest_dist_code,inc_day from dm_gis.village_dest_waybill_info_di where inc_day='$firstDay'   ) as t0 
left join (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_level5_addr_decode_di where inc_day='$firstDay'  and (class_code is null or class_code not in ('220','210','110','111') ) ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 3.2 运单关联小哥轨迹  
drop table if exists dm_gis.village_dest_classcode_waybill_xg_gj_mid;
create table dm_gis.village_dest_classcode_waybill_xg_gj_mid (
waybill_no string comment '',
aoi_id string comment '',
aoi_code string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
signin_tm string comment '',
tm string comment '',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_classcode_waybill_xg_gj_mid partition(inc_day)  
select 
waybill_no,aoi_id,aoi_code,class_code,vilcode,zx,zy,signin_tm,tm,t1.dest_dist_code,t1.inc_day 
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(signin_tm) as signin_tm,deliver_emp_code,aoi_id,aoi_code,class_code,vilcode,dest_dist_code,inc_day
from dm_gis.village_dest_classcode_waybill_mid where inc_day='$firstDay' and deliver_emp_code<>'' and signin_tm<>'' ) as t1 
on t0.un=t1.deliver_emp_code
where signin_tm-60*5<=tm and signin_tm+60*5>=tm
;

-- 3.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_dest_classcode_waybill_xg_mid;
create table dm_gis.village_dest_classcode_waybill_xg_mid (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_classcode_waybill_xg_mid partition(inc_day)  
select waybill_no,aoi_code,zx,zy,dest_dist_code,inc_day
from (
select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,abs(signin_tm-tm) as diff_tm from dm_gis.village_dest_classcode_waybill_xg_gj_mid where inc_day='$firstDay' ) as t  
) as t0 where t0.rn=1 
;


-- 3.4 将派件与收件进行合并后再跑接口
drop table if exists dm_gis.village_classcode_waybill_xg_mid;
create table dm_gis.village_classcode_waybill_xg_mid (
aoi_code string comment '',
zx string comment '',
zy string comment '',
dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "运单关联获取" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table if exists dm_gis.village_classcode_waybill_xg_res_mid;
create table dm_gis.village_classcode_waybill_xg_res_mid (
aoi_code string comment '',
lgt string comment '',
lat string comment '',
matchres string comment '',
dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "跑经纬坐标查询aoi" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
insert overwrite table dm_gis.village_classcode_waybill_xg_mid partition(inc_day) 
select aoi_code,zx,zy,dist_code,inc_day
from (
select aoi_code,zx,zy,dest_dist_code as dist_code,inc_day
from (
select aoi_code,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_classcode_waybill_xg_mid where inc_day='$firstDay' and aoi_code<>'' ) as a
union all 
select aoi_code,zx,zy,src_dist_code as dist_code,inc_day 
from (
select aoi_code,zx,zy,src_dist_code,inc_day from dm_gis.village_src_classcode_waybill_xg_mid where inc_day='$firstDay' and aoi_code<>''  ) as b
) as c 
group by aoi_code,zx,zy,dist_code,inc_day 
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngAoiApp"
int_sql="select aoi_code,zx,zy,dist_code,inc_day from dm_gis.village_classcode_waybill_xg_mid where inc_day='$firstDay' "
out_table="dm_gis.village_classcode_waybill_xg_res_mid" 
pall_num=100000


-- 3.5 能关联小哥轨迹的运单查询aoi后判断是否上门的结果
drop table if exists dm_gis.village_dest_classcode_waybill_xg_aoi_res_mid;
create table dm_gis.village_dest_classcode_waybill_xg_aoi_res_mid (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
matchres string comment '',
dest_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "跑经纬坐标查询aoi（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_classcode_waybill_xg_aoi_res_mid partition(inc_day)  
select waybill_no,t0.aoi_code,zx,zy,matchres,dest_dist_code,inc_day 
from (select waybill_no,aoi_code,zx,zy,dest_dist_code,inc_day 
from dm_gis.village_dest_classcode_waybill_xg_mid where inc_day='$firstDay' ) as t0 
left join (select aoi_code,lgt,lat,matchres from dm_gis.village_classcode_waybill_xg_res_mid where inc_day='$firstDay' ) as t1 
on t0.aoi_code=t1.aoi_code and t0.zx=t1.lgt and t0.zy=t1.lat 
;
 



------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 4 快递上门结果表 (派件) 
drop table if exists dm_gis.village_dest_kdsm_res_di;
create table dm_gis.village_dest_kdsm_res_di (
dest_hq_code	string	comment '大区代码',
dest_area_code	string	comment '地区代码',
area_name	string	comment '地区名称',
dest_zone_code	string	comment '网点代码',
dept_name	string	comment '网点名称',
waybill_no	string	comment '单号',
deliver_emp_code	string	comment '派件人工号',
real_product_code	string	comment '产品名称',
meterage_weight_qty	string	comment '计费重量',
pay_cust_type	string	comment '付费客户类型',
service_prod_code	string	comment '增值服务代码',
all_fee_rmb	string	comment '总收入（rmb）',
freight_monthly_acct_code	string	comment '月结账号',
is_yj	string	comment '是否月结',
aoi_code	string	comment 'AOI编码',
aoi_name	string	comment 'AOI名称',
aoi_type_name	string	comment 'aoi类型名称',
aoi_area_code	string	comment 'AOI区域',
province	string	comment '省',
city	string	comment '市/市辖区',
county	string	comment '区/县',
town	string	comment '镇/乡',
town_adcode	string	comment '镇adcode',
vil_name	string	comment '行政村/社区',
vil_code	string	comment '村adcode',
class_code	string	comment '城乡分类代码',
own_code	string	comment '驿站编码',
is_jcpj	string	comment '是否进村派件',
is_jxzpj	string	comment '是否为乡镇上门派件',
yd_type	string	comment '运单类型',
distance	string	comment '收件地址到派件网点的距离',
wd_type	string	comment '网点类型',
dest_dist_code	string	comment '分区城市代码',
operate_longitude	string	comment '驿站经度',
operate_latitude	string	comment '驿站纬度',
signin_tm	string	comment '派送时间',
add_fee	string	comment '乡村达收入',
is_jp	string	comment '是否集派',
is_tcj	string	comment '是否同城件',
lonlat_tag	string	comment '出入库标签',
subsidy_type	string	comment '补贴标签',
subsidy	string	comment '补贴更新',
dest_type_code	string	comment '网点类型代码',
aoi_id	string	comment 'AOI id',
aoi_src	string	comment 'AOI src',
aoi_type	string	comment 'AOI类型代码',
aoi_area_type	string	comment 'AOI区域类型名称',
driver_track	string	comment '同城件经纬度' 
)
COMMENT '行政村快递上门（派件）'
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;




-- 取乡村达收入数据
drop table if exists dm_gis.tmp_tt_waybill_addition_dest;
create table dm_gis.tmp_tt_waybill_addition_dest stored as parquet  as 
select waybill_no,add_fee 
from (
select waybill_no,get_json_object(addition_values,'$.additionalFee') as add_fee from ods_shiva_oms_sws.tt_waybill_addition 
where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-15),'-','') and inc_day<='$firstDay'  
 and addition_key='RURAL_EXPRESS' 
 and get_json_object(addition_values,'$.additionalFee') is not null  
 and get_json_object(addition_values,'$.additionalFee')  > 0 
 ) as t group by waybill_no,add_fee 
 ;


-- 驿站编码不为空，结果
drop table if exists dm_gis.tmp_village_dest_owncode_isnotnull_res;
create table dm_gis.tmp_village_dest_owncode_isnotnull_res stored as parquet  as 
select 
t0.waybill_no,t0.own_code,t0.dest_dist_code,t0.vilcode,t0.operate_longitude,t0.operate_latitude,t0.lonlat_tag,match_res 
from (select waybill_no,own_code,dest_dist_code,vilcode,operate_longitude,operate_latitude,lonlat_tag from dm_gis.village_dest_owncode_isnotnull_mid where inc_day='$firstDay'  ) as t0
left join (select dest_dist_code,vilcode,operate_longitude,operate_latitude,match_res from dm_gis.village_dest_owncode_isnotnull_api_res_mid where inc_day='$firstDay' ) as t1 
on t0.dest_dist_code=t1.dest_dist_code and t0.vilcode=t1.vilcode and t0.operate_longitude=t1.operate_longitude and t0.operate_latitude=t1.operate_latitude 
;


-- AOI src  (取最新)
drop table if exists dm_gis.tmp_village_dest_aoisrc_res;
create table dm_gis.tmp_village_dest_aoisrc_res stored as parquet  as 
select req_waybillno,finalaoidetailsrc 
from (select req_waybillno,finalaoidetailsrc,row_number() over(partition by req_waybillno order by inc_day desc,finalaoidetailsrc desc) rn  from dm_gis.gis_rds_omsto  
where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay' and req_waybillno is not null and req_waybillno<>'' and finalaoidetailsrc<>''
) as t where t.rn=1
;




-- 派件结果表数据写入
insert overwrite table  dm_gis.village_dest_kdsm_res_di partition(inc_day='$firstDay') 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,meterage_weight_qty,
'' as pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,'' as aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,
case when (class_code in ('220','210')) or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type ,
distance,wd_type,dest_dist_code,
operate_longitude,operate_latitude,signin_tm,
if(is_yj='1',null,add_fee) as add_fee,
'' as is_jp,
is_tcj,lonlat_tag,
'' as subsidy_type,'' as subsidy,
dest_type_code,aoi_id,aoi_src,aoi_type,aoi_area_type,driver_track 

from (select 
dest_hq_code,dest_area_code,t6.area_name,t0.dest_dist_code,dest_zone_code,t6.dept_name,dest_type_code,t0.waybill_no,deliver_emp_code,product_code as real_product_code,
meterage_weight_qty_kg as meterage_weight_qty,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
case when freight_monthly_acct_code<>'' then '1' else '0' end as is_yj,
t0.aoi_code,t0.aoi_id,t9.finalaoidetailsrc as aoi_src,t0.aoi_name,aoi_type,t7.aoi_area_code,t7.aoi_area_type,
if(t8.waybill_no is not null,'1','0') as is_tcj,t8.driver_track,
t1.province,t1.city,t1.county,t1.town,t1.town_adcode,t1.vilname as vil_name,t1.vilcode as vil_code,t1.class_code,
t3.own_code,t3.operate_longitude,t3.operate_latitude,t3.lonlat_tag,
case when t2.waybill_no is not null or t3.match_res='1' or t4.adcode_isin='1' then '1' else '0' end as is_jcpj,
case when t5.matchres='1'  then '1' else '0' end as is_jxzpj,
case when dest_type_code='DB05-DLD' then '代理' else '自营' end as wd_type,
distance,
signin_tm,
t10.add_fee 
from (select 
dest_hq_code,dest_area_code,dest_zone_code,dest_type_code,
waybill_no,consignee_addr,deliver_emp_code,product_code,meterage_weight_qty_kg,
service_prod_code,all_fee_rmb,freight_monthly_acct_code,
aoi_code,aoi_id,aoi_name,aoi_type,signin_tm,
dest_dist_code 
from dm_gis.village_dest_waybill_info_di where inc_day='$firstDay'   ) as t0 
-- 5级地址
left join ( select waybill_no,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,dest_dist_code,inc_day 
from dm_gis.village_dest_level5_addr_decode_di where inc_day='$firstDay'  ) as t1 
on t0.waybill_no=t1.waybill_no 
-- 是否进村
left join (select waybill_no from dm_gis.village_dest_driver_track_res_mid where inc_day='$firstDay' and  tc_res='1') as t2 
on t0.waybill_no=t2.waybill_no 
left join (select waybill_no,own_code,dest_dist_code,vilcode,operate_longitude,operate_latitude,lonlat_tag,match_res from dm_gis.tmp_village_dest_owncode_isnotnull_res ) as t3 
on t0.waybill_no=t3.waybill_no 
left join (select waybill_no,class_code,vilcode,inc_day,dest_dist_code,zx,zy,adcode_isin  from dm_gis.village_dest_owncode_isnull_res_mid where inc_day='$firstDay'  ) as t4 
on t0.waybill_no=t4.waybill_no 
-- 是否进乡镇
left join (select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,matchres from dm_gis.village_dest_classcode_waybill_xg_aoi_res_mid where inc_day='$firstDay'  ) as t5 
on t0.waybill_no=t5.waybill_no 
-- 地区名称 网点名称
left join (select dept_code,area_name,dept_name from (select dept_code,area_name,dept_name,dept_type_code,row_number() over(partition by dept_code order by inc_day desc)  as rn 
from  dim.dim_dept_info_df where inc_day=date_format(date_add(current_date(),-1),'yyyyMMdd') ) as b where b.rn=1 ) as t6 
on t0.dest_zone_code=t6.dept_code 
-- AOI区域	AOI区域类型名称	
left join (select aoi_id,aoi_area_code,aoi_area_type from dm_tc_waybillinfo.aoi_area_aoi ) as t7 
on t0.aoi_code=t7.aoi_id 
-- 同城件 同城经纬
left join (
select waybill_no,driver_track from dm_gis.sf_order_rider_track where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay'
) as t8 
on t0.waybill_no=t8.waybill_no  
-- AOI src
left join ( select req_waybillno,finalaoidetailsrc from dm_gis.tmp_village_dest_aoisrc_res ) as t9
on t0.waybill_no=t9.req_waybillno 
-- 乡村达收入
left join (select waybill_no,add_fee from dm_gis.tmp_tt_waybill_addition_dest ) as t10 
on t0.waybill_no=t10.waybill_no 
) as t
;