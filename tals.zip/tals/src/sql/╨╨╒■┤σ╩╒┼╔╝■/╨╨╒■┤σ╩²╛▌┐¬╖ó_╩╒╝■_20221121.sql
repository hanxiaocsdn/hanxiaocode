-- 行政村收派件1.7版本 --

-- 收件运单
drop table if exists dm_gis.tmp_henan_tt_order_hook_1006;
create table dm_gis.tmp_henan_tt_order_hook_1006 as 
select waybill_no,inc_day,consigned_tm,src_hq_code,src_area_code,source_zone_code,consignee_emp_code,real_product_code,freight_monthly_acct_code,
aoi_id,aoi_code,aoi_name,aoi_type_name,src_county,consignor_addr,src_dist_code 
from dm_gis.tt_order_hook where inc_day='20221006' and src_area_code='371Y'
;
-- and source_zone_code in ('394DLD172','394DLD114','394DLD089','394DLD129','394DLD125','394DLD149','394DLD080','394DLD171','394DLD090','394DLD095','394DLD121','394DLD073','394DLD103','394DLD069','394DLD075','394DLD079','394DLD152','394DLD074','394DLD137','394DLD161')
--  ;

 -- 地址解析行政村     VillageAddrHenanVillageApp
int_sql="select waybill_no,src_county as yd_county,consignor_addr as yd_addr,src_dist_code as city_code,inc_day  from  dm_gis.tmp_henan_tt_order_hook_1006 "
out_table="dm_gis.tmp_henan_src_addr_village220_1006"
mainClass="com.sf.gis.scala.tals.app.VillageAddrHenanVillageApp"

-- 行政村 res
drop table if exists dm_gis.tmp_henan_src_villres_1006;
create table dm_gis.tmp_henan_src_villres_1006 as 
select t0.waybill_no,t0.inc_day,consigned_tm,src_hq_code,src_area_code,source_zone_code,consignee_emp_code,real_product_code,freight_monthly_acct_code,
aoi_id,aoi_code,aoi_name,aoi_type_name,src_county,consignor_addr,src_dist_code, 
province,city,county,town,vil_name,guid,vil_code,town_adcode,class_code    
from dm_gis.tmp_henan_tt_order_hook_1006 as t0 
left join 
(select waybill_no,inc_day,province,city,county,town,vil_name,vil_space_code as guid,vil_code,town_adcode,class_code from dm_gis.tmp_henan_src_addr_village220_1006  where waybill_no<>'' 
group by waybill_no,inc_day,province,city,county,town,vil_name,vil_space_code,vil_code,town_adcode,class_code 
) as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day 
;

-- -- 小哥轨迹
-- drop table if exists dm_gis.tmp_village_henan_esg_gis_1006;
-- create table  dm_gis.tmp_village_henan_esg_gis_1006  as 
-- select un,inc_day,tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20221006'
-- ;

----  小哥收派件轨迹匹配当前的行政村
----  时间范围
drop table if exists dm_gis.tmp_village_henan_src_sfjc_1006;
create table dm_gis.tmp_village_henan_src_sfjc_1006  as 
select 
waybill_no,inc_day,consigned_tm,consignee_emp_code,guid,
tm,zx,zy 
from (
select 
t0.waybill_no,t0.inc_day,consigned_tm,consignee_emp_code,guid,
tm,zx,zy 
from (
select un,inc_day,cast(tm as int) as tm,zx,zy 
from dm_gis.tmp_village_henan_esg_gis_1006 
where  un is not null and un<>'' 
and zx is not null and zx<>'' 
and zy is not null and zy<>'') as t1 
left join (
select waybill_no,inc_day,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,guid 
from dm_gis.tmp_henan_src_villres_1006   
where class_code='220' and consignee_emp_code<>'' and guid<>'' and consigned_tm<>''  ) as t0  
on  t0.consignee_emp_code=t1.un and t0.inc_day=t1.inc_day
where  t0.consignee_emp_code is not null 
) as t 
where  consigned_tm-60*60*2<=tm and consigned_tm+60*5>=tm
;

---- 挂上多边形wkt
drop table if exists dm_gis.tmp_village_henan_src_sfjc_1006a;
create table dm_gis.tmp_village_henan_src_sfjc_1006a  as 
select 
t0.waybill_no,t0.inc_day,consigned_tm,consignee_emp_code,t0.guid,
t0.tm,t0.zx,t0.zy, 
ta.wkt
from  dm_gis.tmp_village_henan_src_sfjc_1006  as t0 
left join ( select guid,wkt from dm_gis_oms.tmp_henan_zhoukou_village220 where wkt!='wkt' ) as ta 
on t0.guid=ta.guid 
;


---- 作为spark的待处理数据 spark类  VillageHenanXiaoGeGuiJi1006App  （ isin_village大于0表示小哥有上门 ）
--   
int_sql="select waybill_no,inc_day,zx,zy,guid,wkt from dm_gis.tmp_village_henan_src_sfjc_1006a where wkt is not null"
out_table="dm_gis.tmp_village_henan_src_sfjc_1006a_isinvillage"    
mainClass="com.sf.gis.scala.tals.app.VillageHenanXiaoGeGuiJi1006App"

-- 是否进乡镇上门
---- 行政村类型为220或判断的进村收件为是的
drop table if exists dm_gis.tmp_village_henan_src_sfjxz_no1_1006;
create table dm_gis.tmp_village_henan_src_sfjxz_no1_1006 as 
select waybill_no,inc_day from (
select waybill_no,inc_day from dm_gis.tmp_henan_src_villres_1006 where class_code='220' 
union all 
select waybill_no,inc_day from dm_gis.tmp_village_henan_src_sfjc_1006a_isinvillage where isin_village>0 
) as t 
group by waybill_no,inc_day
;

drop table if exists dm_gis.tmp_village_henan_src_sfjxz_tmp_1006;
create table dm_gis.tmp_village_henan_src_sfjxz_tmp_1006 as 
select t0.waybill_no,t0.inc_day,consigned_tm,consignee_emp_code,guid,aoi_id,aoi_code 
from (select waybill_no,inc_day,consigned_tm,consignee_emp_code,guid,aoi_id,aoi_code from dm_gis.tmp_henan_src_villres_1006  where consignee_emp_code<>'' and consigned_tm<>'' ) as t0 
left join dm_gis.tmp_village_henan_src_sfjxz_no1_1006 as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day
where t1.waybill_no is null
;

drop table if exists dm_gis.tmp_village_henan_src_sfjxz_tmp1_1006;
create table dm_gis.tmp_village_henan_src_sfjxz_tmp1_1006  as 
select 
waybill_no,inc_day,consigned_tm,consignee_emp_code,guid,aoi_id,aoi_code,
tm,zx,zy 
from (
select t0.waybill_no,t0.inc_day,consigned_tm,t0.consignee_emp_code,guid,aoi_id,aoi_code, 
tm,zx,zy 
from (
select un,inc_day,cast(tm as int) as tm,zx,zy 
from dm_gis.tmp_village_henan_esg_gis_1006 
where  un is not null and un<>'' 
and zx is not null and zx<>'' 
and zy is not null and zy<>'') as t1 
left join 
(
select waybill_no,inc_day,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,guid,aoi_id,aoi_code  
from dm_gis.tmp_village_henan_src_sfjxz_tmp_1006   
where consignee_emp_code<>'' and consigned_tm<>''  ) as t0
on  t0.consignee_emp_code=t1.un and t0.inc_day=t1.inc_day 
where t0.consignee_emp_code is not null 
) as t 
where  consigned_tm-60*60*2<=tm and consigned_tm+60*5>=tm
;

-- -- 处理经纬坐标以减少计算量  
-- drop table if exists dm_gis.tmp_village_henan_src_sfjxz_tmp2_1006;
-- create table dm_gis.tmp_village_henan_src_sfjxz_tmp2_1006 as   
-- select 
-- waybill_no,inc_day,aoi_id,aoi_code,round(zx,4) as zx,round(zy,4) as zy 
-- from  dm_gis.tmp_village_henan_src_sfjxz_tmp1_1006  
-- group by  waybill_no,inc_day,aoi_id,aoi_code,zx,zy 
-- ;

-- 处理经纬坐标以减少计算量  20221219修改  取最近的一个
drop table if exists dm_gis.tmp_village_henan_src_sfjxz_tmp2_1006;
create table dm_gis.tmp_village_henan_src_sfjxz_tmp2_1006 as  
select waybill_no,inc_day,aoi_id,aoi_code,zx,zy 
from (
select 
waybill_no,inc_day,aoi_id,aoi_code,zx,zy,
row_number() over(partition by waybill_no,inc_day order by diff_tm asc) as rn 
from ( 
select 
waybill_no,inc_day,aoi_id,aoi_code,zx,zy,abs(consigned_tm-tm) as diff_tm   
from  dm_gis.tmp_village_henan_src_sfjxz_tmp1_1006  
) as t  ) as t0 where t0.rn=1 
;

-- 是否进乡镇上门 作为spark的待处理数据 spark类  VillageHenanXiaoGeGuiJi200mDest1006App （ match_res大于1表示小哥有上门 ）
-- 
int_sql="select aoi_code,zx,zy from dm_gis.tmp_village_henan_src_sfjxz_tmp2_1006 where aoi_code<>'' group by aoi_code,zx,zy"
out_table="dm_gis.tmp_village_henan_src_sfjxz_1006a_isintown"    
mainClass="com.sf.gis.scala.tals.app.VillageHenanXiaoGeGuiJi200mDest1006App"


-- 还原判断是否进乡镇
drop table if exists dm_gis.tmp_village_henan_src_sfjxz_no2_1006;
create table dm_gis.tmp_village_henan_src_sfjxz_no2_1006 as 
select waybill_no,inc_day,sum(match_res) as sum_match_res 
from (select waybill_no,inc_day,t1.match_res  
from dm_gis.tmp_village_henan_src_sfjxz_1006a_isintown as t1 
left join dm_gis.tmp_village_henan_src_sfjxz_tmp2_1006 as t0 
on t0.aoi_code=t1.aoi_code and  t0.zx=t1.lgt and t0.zy=t1.lat 
) as t 
group by waybill_no,inc_day 
;

drop table if exists dm_gis.tmp_village_henan_src_sfjxz_res_1006;
create table dm_gis.tmp_village_henan_src_sfjxz_res_1006 as 
select t0.waybill_no,t0.inc_day,
case when  t1.waybill_no is not null or t2.sum_match_res=0 then '否' 
when t2.sum_match_res>0 then '是' 
else '未知' end as isin_town 
from dm_gis.tmp_henan_src_villres_1006 as t0 
left join dm_gis.tmp_village_henan_src_sfjxz_no1_1006 as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day 
left join dm_gis.tmp_village_henan_src_sfjxz_no2_1006 as t2 
on t0.waybill_no=t2.waybill_no and t0.inc_day=t2.inc_day 
;


-- -- 网点站点数据 dim.dim_department_hist
-- drop table if exists dm_gis.tmp_village_henan_department_1006;
-- create table dm_gis.tmp_village_henan_department_1006  as 
-- select dept_code,area_name,dept_name,longitude,latitude 
-- from (
-- select dept_code,area_name,dept_name,longitude,latitude,row_number() over(partition by dept_code order by inc_day desc)  as rn 
-- from (select area_name,dept_code,dept_name,longitude,latitude,inc_day  
-- from dim.dim_department_hist where inc_day='20221006' ) as a 
-- ) as b where b.rn=1
-- ;


-- -- 订单类型 dwd.dwd_pd_order_timely_repond_dtl_di
-- drop table if exists dm_gis.tmp_village_henan_order_type_1006;
-- create table dm_gis.tmp_village_henan_order_type_1006 as 
-- select waybill_no,inc_day,order_type_desc  from dwd.dwd_pd_order_timely_repond_dtl_di where inc_day='20221006' and waybill_no<>'' 
-- ;



------- 收件数据大整合 ------
drop table if exists dm_gis.tmp_village_henan_src_matchall_res_1006_1;
create table dm_gis.tmp_village_henan_src_matchall_res_1006_1 as 
select 
t0.waybill_no,t0.inc_day,t0.consigned_tm,t0.src_hq_code,t0.src_area_code,t0.source_zone_code,t0.consignee_emp_code,t0.real_product_code,t0.freight_monthly_acct_code,
t0.aoi_id,t0.aoi_code,t0.aoi_name,t0.aoi_type_name,t0.src_county,t0.consignor_addr,t0.src_dist_code,   
t01.province,t01.city,t01.county,t01.town,t01.vil_name,t01.guid,t01.vil_code,t01.town_adcode,t01.class_code,
t1.area_name,t1.dept_name,
t4.aoi_area_code,
t6.isin_village,
t7.isin_town 
from dm_gis.tmp_henan_tt_order_hook_1006 as t0 
left join  dm_gis.tmp_henan_src_villres_1006 as t01 
on t0.waybill_no=t01.waybill_no and t0.inc_day=t01.inc_day 
left join  dm_gis.tmp_village_henan_department_1006 as t1 
on t0.source_zone_code=t1.dept_code 
left join dm_tc_waybillinfo.aoi_area_aoi as t4 
on t0.aoi_code=t4.aoi_id 
left join (select waybill_no,inc_day,isin_village from dm_gis.tmp_village_henan_src_sfjc_1006a_isinvillage where isin_village>0 ) as t6 
on t0.waybill_no=t6.waybill_no and t0.inc_day=t6.inc_day 
left join dm_gis.tmp_village_henan_src_sfjxz_res_1006 as t7 
on t0.waybill_no=t7.waybill_no and t0.inc_day=t7.inc_day 
;

drop table if exists dm_gis.tmp_village_henan_src_matchall_res_1006_2;
create table dm_gis.tmp_village_henan_src_matchall_res_1006_2 as 
select 
waybill_no,inc_day,consigned_tm,src_hq_code,src_area_code,
source_zone_code,area_name,dept_name,
consignee_emp_code,real_product_code,
freight_monthly_acct_code,
aoi_id,aoi_code,aoi_name,aoi_type_name,aoi_area_code,src_county,consignor_addr,src_dist_code,
province,city,county,town,vil_name,guid,vil_code,town_adcode,class_code,
case when class_code='220' or isin_village>0 then '否' else '是' end as  is_xz,
case when isin_village>0  then '是' else '否' end as is_jcpj,
isin_town as is_jxzpj 
from dm_gis.tmp_village_henan_src_matchall_res_1006_1
;


---- 收件明细表  ---- 
-- 建表
drop table if exists dm_gis.tmp_village_henan_src_matchall_res_1006;
create table dm_gis.tmp_village_henan_src_matchall_res_1006(
waybill_no string,
consigned_tm string,
src_hq_code string,
src_area_code string,
source_zone_code string,
area_name string,
dept_name string,
consignee_emp_code string,
real_product_code string,
is_yj string,
aoi_id string,
aoi_code string,
aoi_name string,
aoi_type_name string,
aoi_area_code string,
src_county string,
src_dist_code string,
province string,
city string,
county string,
town string,
vil_name string,
guid string,
vil_code string,
town_adcode string,
class_code string,
is_jcpj string,
is_jxzpj string,
yd_type string,
fg_type string, 
business_model string
)
COMMENT "收件行政村" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 写入到明细表
insert overwrite table dm_gis.tmp_village_henan_src_matchall_res_1006 partition(inc_day='20221006') 
select 
t0.waybill_no,consigned_tm,src_hq_code,src_area_code,
source_zone_code,area_name,dept_name,
consignee_emp_code,real_product_code,
is_yj,
aoi_id,aoi_code,aoi_name,aoi_type_name,aoi_area_code,src_county,src_dist_code,
t0.province,t0.city,t0.county,t0.town,vil_name,guid,vil_code,town_adcode,class_code,
is_jcpj,is_jxzpj,
yd_type,
t9.fg_type, 
t11.business_model  
from 
(select 
waybill_no,inc_day,consigned_tm,src_hq_code,src_area_code,
source_zone_code,area_name,dept_name,
consignee_emp_code,real_product_code,
case when freight_monthly_acct_code<>'' then '是' else '否' end as is_yj,
aoi_id,aoi_code,aoi_name,aoi_type_name,aoi_area_code,src_county,consignor_addr,src_dist_code,
province,city,county,town,vil_name,guid,vil_code,town_adcode,class_code,
is_xz,is_jcpj,is_jxzpj,
case when (class_code='220') or (is_jcpj='是')  then '行政村' 
when (class_code!='220') and (is_jcpj!='是') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code!='220') and (is_jcpj!='是') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type 
from dm_gis.tmp_village_henan_src_matchall_res_1006_2 
) as t0 
left join dm_gis.tmp_henan_df_sywlfg_0908 as t9 
on t0.province=t9.province and t0.city=t9.city and t0.county=t9.county and t0.town=t9.town 
left join  dm_gis.tmp_village_henan_business_model_1006 as t11 
on t0.province=t11.prov_name and t0.city=t11.dist_name and t0.county=t11.prefecture_name and t0.town=t11.town_street_name 
group by 
t0.waybill_no,consigned_tm,src_hq_code,src_area_code,
source_zone_code,area_name,dept_name,
consignee_emp_code,real_product_code,
is_yj,
aoi_id,aoi_code,aoi_name,aoi_type_name,aoi_area_code,src_county,src_dist_code,
t0.province,t0.city,t0.county,t0.town,vil_name,guid,vil_code,town_adcode,class_code,
is_jcpj,is_jxzpj,
yd_type,
t9.fg_type, 
t11.business_model  
;


alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column waybill_no waybill_no string comment '运单号';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column consigned_tm consigned_tm string comment '寄件时间';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column src_hq_code src_hq_code string comment '大区代码';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column src_area_code src_area_code string comment '地区代码';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column source_zone_code source_zone_code string comment '网点代码';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column area_name area_name string comment '地区名称';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column dept_name dept_name string comment '网点名称';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column consignee_emp_code consignee_emp_code string comment '派件员';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column real_product_code real_product_code string comment '产品名称';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column is_yj is_yj string comment '是否月结';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column aoi_id aoi_id string comment 'AOI ID';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column aoi_code aoi_code string comment 'AOI编码';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column aoi_name aoi_name string comment 'AOI名称';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column aoi_type_name aoi_type_name string comment 'AOI类型名称';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column aoi_area_code aoi_area_code string comment 'AOI区域';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column src_county src_county string comment '区/县/镇';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column src_dist_code src_dist_code string comment '城市代码';
province string,
city string,
county string,
town string,
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column  vil_name vil_name string comment '行政村';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column  guid  guid string comment '行政村唯一标识';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column vil_code vil_code string comment '村code';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column town_adcode town_adcode string  comment '镇code';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column class_code class_code string  comment '类型';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column is_jcpj is_jcpj string  comment '是否进村派件';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column is_jxzpj is_jxzpj string  comment '是否进乡镇派件';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column yd_type yd_type string  comment '运单类型';
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column fg_type fg_type string  comment '速运网络覆盖'; 
alter table dm_gis.tmp_village_henan_src_matchall_res_1006 change column business_model business_model string  comment '网点类型';


-- 2022-12-17 找是否进乡镇判断问题
select * from dm_gis.tmp_village_henan_src_matchall_res_1006 where waybill_no='SF1127108094431' limit 10

select * from dm_gis.tmp_village_henan_src_sfjxz_tmp2_1006 where waybill_no='SF1127108094431' limit 10 

select * from dm_gis.tmp_village_henan_src_sfjxz_tmp1_1006 where waybill_no='SF1127108094431' limit 10

select * from dm_gis.tmp_village_henan_src_sfjxz_tmp_1006 where waybill_no='SF1127108094431' limit 10 

select un,inc_day,format_datetime(from_unixtime(cast(tm as int)),'yyyy-MM-dd HH:mm:ss') as tm,zx,zy  
from dm_gis.tmp_village_henan_esg_gis_1006  where  un='982238'  and  cast(tm as int)>=1671001356 and cast(tm as int)<=1671001416 limit 1000


drop table if exists dm_gis.tmp_village_henan_src_sfjxz_tmp1_1006;
create table dm_gis.tmp_village_henan_src_sfjxz_tmp1_1006  as 
select 
waybill_no,inc_day,consigned_tm,consignee_emp_code,guid,aoi_id,aoi_code,
tm,zx,zy 
from (
select t0.waybill_no,t0.inc_day,consigned_tm,t0.consignee_emp_code,guid,aoi_id,aoi_code, 
tm,zx,zy 
from (
select un,inc_day,cast(tm as int) as tm,zx,zy 
from dm_gis.tmp_village_henan_esg_gis_1006 
where  un is not null and un<>'' and un='982238'
and zx is not null and zx<>'' 
and zy is not null and zy<>'') as t1 
left join 
(
select waybill_no,inc_day,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,guid,aoi_id,aoi_code  
from dm_gis.tmp_village_henan_src_sfjxz_tmp_1006   
where consignee_emp_code<>'' and guid<>'' and consigned_tm<>'' and  waybill_no='SF1127108094431' ) as t0
on  t0.consignee_emp_code=t1.un and t0.inc_day=t1.inc_day 
where t0.consignee_emp_code is not null 
) as t 
where  consigned_tm-30<=tm and consigned_tm+30>=tm
;