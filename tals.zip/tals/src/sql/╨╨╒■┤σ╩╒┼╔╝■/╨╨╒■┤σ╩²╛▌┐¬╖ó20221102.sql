--
需求描述：在数据核验过程中，发现数据并不符合业务方预期，主要原因为村的定义与地区的理解存在偏差，因此修正了村的定义以后，并对跑数逻辑作出一下修改，并再次进行数据核验.
1、周期：10月8日至10月13日期间
2、频次：每天一次
3、每天输出时间：13:30之前
4、筛选条件：选取的20个代理点( dest_zone_code in ('394DLD172','394DLD114','394DLD089','394DLD129','394DLD125','394DLD149','394DLD080','394DLD171','394DLD090','394DLD095','394DLD121','394DLD073','394DLD103','394DLD069','394DLD075','394DLD079','394DLD152','394DLD074','394DLD137','394DLD161')和inc_day=前天（如今日是20220920，则inc_day='20220918'）

新增改动：
1、之前的行政村表更改成表《周口市行政村220》；
2、获取五级地址的逻辑改成用行政村查询接口获取；
3、增加城乡分类代码字段，并通过五级地址的逻辑进行；
4、三处”行政村字段不为空“的判断条件，全部更换为”城乡分类代码为220“；
--

-- 数据准备
-- 1、运单
-- dm_gis.tt_waybill_hook  派件
-- waybill_id,waybill_no,inc_day,signin_tm,dest_hq_code,dest_area_code,dest_zone_code,deliver_emp_code,real_product_code,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,dest_county,consignee_addr,dest_dist_code,consignee_mobile,consignee_phone,consignee_comp_name,consignee_cont_name,cons_name
drop table if exists dm_gis.tmp_henan_tt_waybill_hook_1006;
create table dm_gis.tmp_henan_tt_waybill_hook_1006  as 
select waybill_id,waybill_no,inc_day,signin_tm,dest_hq_code,dest_area_code,dest_zone_code,deliver_emp_code,real_product_code,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,dest_county,consignee_addr,dest_dist_code,consignee_mobile,consignee_phone,consignee_comp_name,consignee_cont_name,cons_name  
from dm_gis.tt_waybill_hook where inc_day='20221006' and  
 dest_zone_code in ('394DLD172','394DLD114','394DLD089','394DLD129','394DLD125','394DLD149','394DLD080','394DLD171','394DLD090','394DLD095','394DLD121','394DLD073','394DLD103','394DLD069','394DLD075','394DLD079','394DLD152','394DLD074','394DLD137','394DLD161')
 ;
 
 
-- 2、《周口市行政村220》
-- wkt,x,y,ogc_fid,guid,area_code,name,class_code,name_p,adcode_p,name_c,adcode_c,name_d,adcode_d,name_t,adcode_t
create table dm_gis_oms.tmp_henan_zhoukou_village220(
wkt string,
x string,
y string,
ogc_fid string,
guid string,
area_code string,
name string,
class_code string,
name_p string,
adcode_p string,
name_c string,
adcode_c string,
name_d string,
adcode_d string,
name_t string,
adcode_t string 
) 
comment '周口市行政村220' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES
('separatorChar'=',')
STORED AS TEXTFILE
tblproperties('skip.header.line.count'='1');

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/周口市行政村220.csv' OVERWRITE INTO TABLE dm_gis_oms.tmp_henan_zhoukou_village220;



-- 地址解析行政村     VillageAddrHenanVillageApp   waybill_no,yd_county,yd_addr,citycode,inc_day
-- int_sql
select waybill_no,dest_county as yd_county,consignee_addr as yd_addr,inc_day  from  dm_gis.tmp_henan_tt_waybill_hook_1006

-- shell
int_sql='
select waybill_no,dest_county as yd_county,consignee_addr as yd_addr,inc_day  from  dm_gis.tmp_henan_tt_waybill_hook_1006
'
out_table='dm_gis.tmp_henan_dest_addr_village220_1006'

spark-submit \
--master yarn \
--queue gis \
--driver-memory 4g \
--num-executors 5 \
--executor-memory 3g \
--executor-cores 6 \
--conf spark.sql.shuffle.partitions=300 \
--class $mainClass $mainJar '$int_sql' '$out_table'

-- out_table    
dm_gis.tmp_henan_dest_addr_village220_1006


--curl  -v  -XPOST -H 'Content-Type:application/json' -H 'ak:8bb09e5e110845f39a000391668e3e80'  http://gis-gw.intsit.sfdc.com.cn:9080/village/api -d  ' {'address' : '河南省周口市沈丘县冯营乡冯营村委会','cityCode':'394'} '
--curl  -v  -XPOST -H 'Content-Type:application/json' -H 'ak:5686a2aca02e42c9807158558446a455'  http://gis-gw.int.sfdc.com.cn:9080/village/api -d  ' {'address' : '河南省周口市沈丘县冯营乡冯营村委会','cityCode':'394'} '


-- 派件 事件发生经纬坐标 
drop table if exists dm_gis.tmp_village_henan_dest_event_1006;
create table dm_gis.tmp_village_henan_dest_event_1006  as 
select waybillno,eventlng,eventlat,inc_day  from  ods_inc_sgs_core.inc_sgs_task_flow_new  
where inc_day='20221006'  and  eventtype='31124' and city_code='394' 
group by waybillno,eventlng,eventlat,inc_day 
;



-- 行政村 res
drop table dm_gis.tmp_henan_dest_villres_1006;
create table dm_gis.tmp_henan_dest_villres_1006 as 
select t0.waybill_id,t0.waybill_no,t0.inc_day,t0.signin_tm,t0.dest_hq_code,t0.dest_area_code,t0.dest_zone_code,t0.deliver_emp_code,t0.real_product_code,t0.aoi_id,t0.aoi_code,t0.aoi_name,t0.aoi_type_name,t0.dest_county,t0.consignee_addr,t0.dest_dist_code, 
province,city,county,town,vil_name,guid,class_code    
from dm_gis.tmp_henan_tt_waybill_hook_1006 as t0 
left join (select waybill_no,inc_day,province,city,county,town,vil_name,vil_space_code as guid,class_code from dm_gis.tmp_henan_dest_addr_village220_1006  where waybill_no<>'') as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day 
;


-- 是否进村派件
---- 站点编码,运单号,收派员编码  （主要是通过这一批运单号来标记进村派件）
--drop table if exists dm_gis_oms.tmp_henan_waybill_zd_1006;
--create table dm_gis_oms.tmp_henan_waybill_zd_1006(
--zd_code string,
--waybill_no string,
--spy_code string
--) 
--comment '运单站点' 
--row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES
--('separatorChar'=',')
--STORED AS TEXTFILE
--tblproperties('skip.header.line.count'='1');
--
---- load_data
--LOAD DATA  INPATH '/user/01416344/upload/waybill_zd_0922.csv' OVERWRITE INTO TABLE dm_gis_oms.tmp_henan_waybill_zd_1006;


----  行政村类型不为220的（事件经纬坐标匹配行政村）
----   spark类 VillageHenanEvent1006App
-- int_sql
select 
t0.waybill_no,t0.inc_day,
eventlng,eventlat 
from (select waybill_no,inc_day from dm_gis.tmp_henan_dest_villres_1006  where class_code!='220'  ) as t0  
left join  dm_gis.tmp_village_henan_dest_event_1006 as t1 
on  t0.waybill_no=t1.waybillno and t0.inc_day=t1.inc_day
where 
t1.waybillno is not null
and eventlng is not null and eventlng<>'' 
and eventlat is not null and eventlat<>'' 


-- 结果 （事件经纬坐标匹配行政村）
-- out_table
dm_gis.tmp_village_henan_dest_envent_match_1006    （ 所有表示匹配到行政村，判断为上门 ）

-- village_sql
select wkt,guid from dm_gis_oms.tmp_henan_zhoukou_village220 where wkt!='wkt'


-- 小哥轨迹
drop table if exists dm_gis.tmp_village_henan_esg_gis_1006;
create table  dm_gis.tmp_village_henan_esg_gis_1006  as 
select un,inc_day,tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20221006'
;

----  行政村类型为220的 （小哥收派件轨迹匹配当前的行政村）
----  时间范围
drop table if exists dm_gis.tmp_village_henan_dest_sfjc_1006;
create table dm_gis.tmp_village_henan_dest_sfjc_1006  as 
select 
waybill_no,inc_day,signin_tm,deliver_emp_code,guid,
tm,zx,zy 
from (
select 
t0.waybill_no,t0.inc_day,unix_timestamp(t0.signin_tm) as signin_tm,t0.deliver_emp_code,guid,
cast(tm as int) as tm,zx,zy 
from (select waybill_no,inc_day,signin_tm,deliver_emp_code,guid from dm_gis.tmp_henan_dest_villres_1006  where deliver_emp_code<>'' and class_code='220' and signin_tm<>''   ) as t0  
left join  dm_gis.tmp_village_henan_esg_gis_1006 as t1 
on  t0.deliver_emp_code=t1.un and t0.inc_day=t1.inc_day
where  t1.un is not null 
and zx is not null and zx<>'' 
and zy is not null and zy<>'' 
) as t 
where  signin_tm-60*5<=tm and signin_tm+60*30>=tm
;

---- 挂上多边形wkt
drop table if exists dm_gis.tmp_village_henan_dest_sfjc_1006a;
create table dm_gis.tmp_village_henan_dest_sfjc_1006a  as 
select 
t0.waybill_no,t0.inc_day,t0.signin_tm,t0.deliver_emp_code,t0.guid,
t0.tm,t0.zx,t0.zy, 
ta.wkt
from  dm_gis.tmp_village_henan_dest_sfjc_1006  as t0 
left join ( select guid,wkt from dm_gis_oms.tmp_henan_zhoukou_village220 where wkt!='wkt' ) as ta 
on t0.guid=ta.guid 
;


---- 作为spark的待处理数据 spark类  VillageHenanXiaoGeGuiJi1006App
--   
select 
waybill_no,inc_day,signin_tm,deliver_emp_code,
tm,zx,zy, 
guid,wkt 
from dm_gis.tmp_village_henan_dest_sfjc_1006a 


-- 结果
dm_gis.tmp_village_henan_dest_sfjc_1006a_isinvillage    （ isin_village大于0表示小哥有上门 ）



-- 是否进乡镇上门
---- 行政村类型为220或判断的进村派件为是的
drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_no1_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_no1_1006 as 
select waybill_no,inc_day from dm_gis.tmp_henan_dest_villres_1006 where class_code='220' 
union all 
select waybill_no,inc_day from dm_gis.tmp_village_henan_dest_envent_match_1006 
;

drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_tmp_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_tmp_1006 as 
select t0.waybill_no,t0.inc_day,signin_tm,deliver_emp_code,guid,aoi_id,aoi_code 
from (select waybill_no,inc_day,signin_tm,deliver_emp_code,guid,aoi_id,aoi_code from dm_gis.tmp_henan_dest_villres_1006  where deliver_emp_code<>'' and signin_tm<>'' ) as t0 
left join dm_gis.tmp_village_henan_dest_sfjxz_no1_1006 as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day
where t1.waybill_no is null
;

drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_tmp1_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_tmp1_1006  as 
select 
waybill_no,inc_day,signin_tm,deliver_emp_code,guid,aoi_id,aoi_code,
tm,zx,zy 
from (
select 
t0.waybill_no,t0.inc_day,unix_timestamp(t0.signin_tm) as signin_tm,t0.deliver_emp_code,guid,aoi_id,aoi_code,
cast(tm as int) as tm,zx,zy 
from dm_gis.tmp_village_henan_dest_sfjxz_tmp_1006 as t0  
left join  dm_gis.tmp_village_henan_esg_gis_1006 as t1 
on  t0.deliver_emp_code=t1.un and t0.inc_day=t1.inc_day
where  t1.un is not null 
and zx is not null and zx<>'' 
and zy is not null and zy<>'' 
) as t 
where  signin_tm-60*5<=tm and signin_tm+60*30>=tm
;

-- 处理经纬坐标以减少计算量  
drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006 as   
select 
waybill_no,inc_day,aoi_id,aoi_code,round(zx,4) as zx,round(zy,4) as zy 
from  dm_gis.tmp_village_henan_dest_sfjxz_tmp1_1006  
group by  waybill_no,inc_day,aoi_id,aoi_code,zx,zy 
;

-- 是否进乡镇上门 作为spark的待处理数据 spark类  VillageHenanXiaoGeGuiJi200mDest1006App
-- input

select
aoi_code,zx,zy
from dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006
where aoi_code<>''
group by aoi_code,zx,zy



-- 结果
dm_gis.tmp_village_henan_dest_sfjxz_1006a_isintown  （ match_res大于1表示小哥有上门 ）



-- 还原判断是否进乡镇
--派件
drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_no2_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_no2_1006 as 
select waybill_no,inc_day,sum(match_res) as sum_match_res 
from (select waybill_no,inc_day,t1.match_res  
from dm_gis.tmp_village_henan_dest_sfjxz_tmp2_1006 as t0 
left join dm_gis.tmp_village_henan_dest_sfjxz_1006a_isintown as t1 
on t0.aoi_code=t1.aoi_code and  t0.zx=t1.lgt and t0.zy=t1.lat 
where t0.aoi_code<>''
) as t 
group by waybill_no,inc_day 
;

drop table if exists dm_gis.tmp_village_henan_dest_sfjxz_res_1006;
create table dm_gis.tmp_village_henan_dest_sfjxz_res_1006 as 
select t0.waybill_no,t0.inc_day,
case when  t1.waybill_no is not null or t2.sum_match_res=0 then '否' 
when t2.sum_match_res>0 then '是' 
else '未知' end as isin_town 
from dm_gis.tmp_henan_dest_villres_1006 as t0 
left join dm_gis.tmp_village_henan_dest_sfjxz_no1_1006 as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day 
left join dm_gis.tmp_village_henan_dest_sfjxz_no2_1006 as t2 
on t0.waybill_no=t2.waybill_no and t0.inc_day=t2.inc_day 
;


-- 网点站点数据 dim.dim_department_hist
drop table if exists dm_gis.tmp_village_henan_department_1006;
create table dm_gis.tmp_village_henan_department_1006  as 
select dept_code,area_name,dept_name,longitude,latitude 
from (
select dept_code,area_name,dept_name,longitude,latitude,row_number() over(partition by dept_code order by inc_day desc)  as rn 
from (select area_name,dept_code,dept_name,longitude,latitude,inc_day  
from dim.dim_department_hist where inc_day='20221006' ) as a 
) as b where b.rn=1
;


-- 订单类型 dwd.dwd_pd_order_timely_repond_dtl_di
drop table if exists dm_gis.tmp_village_henan_order_type_1006;
create table dm_gis.tmp_village_henan_order_type_1006 as 
select waybill_no,inc_day,order_type_desc  from dwd.dwd_pd_order_timely_repond_dtl_di where inc_day='20221006' and waybill_no<>''
;


-------- 2022-11-02 修改 --------
-- 增加10月5号到10月8号的运单站点清单
drop table if exists dm_gis_oms.tmp_henan_waybill_zd_1006;
create table dm_gis_oms.tmp_henan_waybill_zd_1006(
waybill_no string,
zd_code string
) 
comment '' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
tblproperties('skip.header.line.count'='1');

LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/zhandiandata_05_08.csv' OVERWRITE INTO TABLE dm_gis_oms.tmp_henan_waybill_zd_1006;


---- 
------- 派件数据大整合 ------
drop table if exists dm_gis.tmp_village_henan_dest_matchall_res_1006_1;
create table dm_gis.tmp_village_henan_dest_matchall_res_1006_1 as 
select 
t0.waybill_id,t0.waybill_no,t0.inc_day,t0.signin_tm,t0.dest_hq_code,t0.dest_area_code,t0.dest_zone_code,t0.deliver_emp_code,t0.real_product_code,t0.aoi_id,t0.aoi_code,t0.aoi_name,t0.aoi_type_name,t0.dest_county,t0.consignee_addr,t0.dest_dist_code,   
t0.province,t0.city,t0.county,t0.town,t0.vil_name,t0.guid,t0.class_code,
t1.area_name,t1.dept_name,
t2.order_type_desc,
t4.aoi_area_code,
t5.match_res,
t6.isin_village,
t7.isin_town,
t8.eventlng,t8.eventlat,
t9.zd_code  
from dm_gis.tmp_henan_dest_villres_1006 as t0 
left join  dm_gis.tmp_village_henan_department_1006 as t1 
on t0.dest_zone_code=t1.dept_code 
left join dm_gis.tmp_village_henan_order_type_1006 as t2 
on t0.waybill_no=t2.waybill_no and t0.inc_day=t2.inc_day 
left join dm_tc_waybillinfo.aoi_area_aoi as t4 
on t0.aoi_code=t4.aoi_id 
left join dm_gis.tmp_village_henan_dest_envent_match_1006 as t5 
on t0.waybill_no=t5.waybill_no and t0.inc_day=t5.inc_day 
left join dm_gis.tmp_village_henan_dest_sfjc_1006a_isinvillage as t6 
on t0.waybill_no=t6.waybill_no and t0.inc_day=t6.inc_day 
left join dm_gis.tmp_village_henan_dest_sfjxz_res_1006 as t7 
on t0.waybill_no=t7.waybill_no and t0.inc_day=t7.inc_day 
left join dm_gis.tmp_village_henan_dest_event_1006 as t8 
on t0.waybill_no=t8.waybillno and t0.inc_day=t8.inc_day 
left join dm_gis_oms.tmp_henan_waybill_zd_1006 as t9 
on t0.waybill_no=t9.waybill_no
;

drop table dm_gis.tmp_village_henan_dest_matchall_res_1006_2;
create table dm_gis.tmp_village_henan_dest_matchall_res_1006_2 as 
select 
waybill_id,waybill_no,inc_day,signin_tm,dest_hq_code,dest_area_code,
dest_zone_code,area_name,dept_name,order_type_desc,
deliver_emp_code,real_product_code,
eventlng,eventlat,
aoi_id,aoi_code,aoi_name,aoi_type_name,aoi_area_code,dest_county,consignee_addr,dest_dist_code,
province,city,county,town,vil_name,guid,class_code,
case when class_code='220' or zd_code is not null then '否' else '是' end as  is_xz,
case when match_res is not null or isin_village>0 or zd_code is not null then '是' when match_res is null or isin_village=0 then '否' else '未知' end as is_jcpj,
isin_town as is_jxzpj 
from dm_gis.tmp_village_henan_dest_matchall_res_1006_1
;



-- 派件新增或修改
--3）乡镇字段匹配运单，运单增加代理编码字段
drop table if exists dm_gis.tmp_village_henan_dest_aoi_dld_1006;
create table  dm_gis.tmp_village_henan_dest_aoi_dld_1006 as 
select 
t0.waybill_no,t0.inc_day,t0.aoi_id,t0.aoi_code,t1.dld_code 
from (select waybill_no,inc_day,aoi_id,aoi_code,province,city,county,town  from dm_gis.tmp_village_henan_dest_matchall_res_1006_2 where is_jcpj='是') as t0 
left join (select dld_code,province,city,county,town from dm_gis.tmp_henan_df_dld_0908 where  dld_code<>'' and town<>'' group by dld_code,province,city,county,town ) as t1 
on t0.province=t1.province and t0.city=t1.city and t0.county=t1.county and t0.town=t1.town 
;


--4）aoi_id + 代理编码，调用接口计算距离   VillageAoi2ZcDistanceHenan1006App
select aoi_id,dld_code
from dm_gis.tmp_village_henan_dest_aoi_dld_1006
where dld_code is not null and dld_code<>'' 
group by aoi_id,dld_code 


-- 结果
dm_gis.tmp_village_henan_dest_aois2zcdistance_1006


-- 取最远的
drop table if exists dm_gis.tmp_village_henan_dest_aoi_dld_res_1006;
create table dm_gis.tmp_village_henan_dest_aoi_dld_res_1006 as 
select 
waybill_no,inc_day,dld_code,car_dist,horse_dist 
from (select 
waybill_no,inc_day,dld_code,car_dist,horse_dist,row_number() over(partition by waybill_no,inc_day order by horse_dist desc)  as rn 
from (
select 
t0.waybill_no,t0.inc_day,t0.aoi_id,t0.aoi_code,
t1.dld_code,t1.car_dist,t1.horse_dist 
from dm_gis.tmp_village_henan_dest_aoi_dld_1006 as t0 
left join dm_gis.tmp_village_henan_dest_aois2zcdistance_1006 as t1 
on t0.aoi_id=t1.aoi_id and t0.dld_code=t1.dld_code 
) as a ) as b where b.rn=1
;


-- 距离字段加到派件明细表
drop table if exists dm_gis.tmp_village_henan_dest_matchall_res_1006;
create table dm_gis.tmp_village_henan_dest_matchall_res_1006 as 
select 
waybill_id,t0.waybill_no,t0.inc_day,signin_tm,dest_hq_code,dest_area_code,
dest_zone_code,area_name,dept_name,order_type_desc,
deliver_emp_code,real_product_code,
t10.consignee_comp_name,t10.consignee_cont_name,t10.cons_name,t10.is_yj,
eventlng,eventlat,
t0.aoi_id,t0.aoi_code,aoi_name,aoi_type_name,aoi_area_code,dest_county,consignee_addr,dest_dist_code,
t0.province,t0.city,t0.county,t0.town,vil_name,guid,class_code,
is_jcpj,is_jxzpj,yd_type,
t9.fg_type, 
t1.dld_code,t1.car_dist,t1.horse_dist 
from 
(select 
waybill_id,waybill_no,inc_day,signin_tm,dest_hq_code,dest_area_code,
dest_zone_code,area_name,dept_name,order_type_desc,
deliver_emp_code,real_product_code,
eventlng,eventlat,
aoi_id,aoi_code,aoi_name,aoi_type_name,aoi_area_code,dest_county,consignee_addr,dest_dist_code,
province,city,county,town,vil_name,guid,class_code,
is_xz,is_jcpj,is_jxzpj,
case when (class_code='220') or (is_jcpj='是')  then '行政村' 
when (class_code!='220') and (is_jcpj!='是') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code!='220') and (is_jcpj!='是') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type 
from dm_gis.tmp_village_henan_dest_matchall_res_1006_2 
) as t0 
left join dm_gis.tmp_village_henan_dest_aoi_dld_res_1006 as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day 
left join dm_gis.tmp_henan_df_sywlfg_0908 as t9 
on t0.province=t9.province and t0.city=t9.city and t0.county=t9.county and t0.town=t9.town 
left join (select waybill_no,inc_day,consignee_comp_name,consignee_cont_name,cons_name,case when freight_monthly_acct_code<>'' then '是' else '否' end as is_yj  from dm_gis.tmp_henan_tt_waybill_hook_1006 ) as t10 
on t0.waybill_no=t10.waybill_no and t0.inc_day=t10.inc_day 
group by 
waybill_id,t0.waybill_no,t0.inc_day,signin_tm,dest_hq_code,dest_area_code,
dest_zone_code,area_name,dept_name,order_type_desc,
deliver_emp_code,real_product_code,
t10.consignee_comp_name,t10.consignee_cont_name,t10.cons_name,t10.is_yj,
eventlng,eventlat,
t0.aoi_id,t0.aoi_code,aoi_name,aoi_type_name,aoi_area_code,dest_county,consignee_addr,dest_dist_code,
t0.province,t0.city,t0.county,t0.town,vil_name,guid,class_code,
is_jcpj,is_jxzpj,yd_type,
t9.fg_type, 
t1.dld_code,t1.car_dist,t1.horse_dist 
;