-- 
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- 需求：GIS-RSS-SEG：【偏远乡村派件上门】  
-- @author 张小琼 （01416344）
-- Created on 2023-12-06
-- 任务信息： ID:926185  行政村收派件_new(基于dwd_waybill_info_dtl_di)
-- 

------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 运单（收件） 
create table dm_gis.village_src_waybill_info_di(
src_hq_code string comment '大区代码',
src_area_code string comment '地区代码',
src_dist_code STRING COMMENT '城市代码',
consignor_addr  string comment '寄件地址',
source_zone_code string comment '网点代码',
src_type_code string comment '网点类型',
waybill_no string comment '运单号',
order_no string comment '订单号',
consignee_emp_code string comment '收件员工号',
product_code string comment '产品代码',
meterage_weight_qty_kg string comment '计费重量',
service_prod_code string comment '增值服务代码',
all_fee_rmb string comment '总收入',
freight_monthly_acct_code string comment '月结账号',
aoi_code string comment 'aoi编码',
aoi_id string comment 'aoi id',
aoi_name string comment 'aoi名称',
aoi_type string comment 'AOI类型',
consigned_tm string comment '寄件时间'  
)
COMMENT "行政村运单（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 寄件时间 揽收时间
-- 1、利用运单号关联ods_kafka_fvp.fvp_core_fact_route_op中inc_day相同且opcode=54的waybillno，命中则获取baruploadtm填入表中
-- 2、对于剩余揽收时间为空的数据，运单号关联ods_kafka_fvp.fvp_core_fact_route_op中inc_day相同且opcode=50的waybillno，命中则获取baruploadtm填入表中

-- 
insert overwrite table  dm_gis.village_src_waybill_info_di partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,src_dist_code,consignor_addr,source_zone_code,src_type_code,
waybill_no,order_no,consignee_emp_code,product_code,meterage_weight_qty_kg,service_prod_code,
all_fee_rmb,freight_monthly_acct_code,aoi_code,aoi_id,aoi_name,aoi_type,consigned_tm
from (select 
src_hq_code,src_area_code,src_dist_code,consignor_addr,source_zone_code,src_type_code,
waybill_no,order_no,consignee_emp_code,product_code,meterage_weight_qty_kg,service_prod_code,
all_fee_rmb,freight_monthly_acct_code,aoi_code,aoi_id,aoi_name,aoi_type,consigned_tm,
row_number() over(partition by waybill_no order by consigned_tm desc) as rn 
from (select 
src_hq_code,src_area_code,src_dist_code,consignor_addr,source_zone_code,src_type_code,
waybill_no,order_no,consignee_emp_code,product_code,meterage_weight_qty_kg,service_prod_code,
all_fee_rmb,freight_monthly_acct_code,aoi_code,aoi_id,aoi_name,aoi_type,
if(barupload_tm is not null,barupload_tm,consigned_tm) as consigned_tm 
from (select 
src_hq_code,
src_area_code,
src_dist_code,
consignor_addr_decrypt as consignor_addr,
source_zone_code,
src_type_code,
waybill_no,
order_no,
consignee_emp_code,
product_code,
meterage_weight_qty_kg,
service_prod_code,
all_fee_rmb,
freight_monthly_acct_code,
if(consignor_aoi_dept_code_fix is not null and trim(consignor_aoi_dept_code_fix)<>'',consignor_aoi_dept_code_fix,consignor_aoi_dept_code) as aoi_code,
if(consignor_aoi_id_fix is not null and trim(consignor_aoi_id_fix)<>'',consignor_aoi_id_fix,consignor_aoi_id) as aoi_id,
consignor_aoi_dept_name as aoi_name,
consignor_aoi_type as aoi_type,
consigned_tm 
from dm_gis.dwd_waybill_info_dtl_di 
where inc_day='$firstDay' ) as t0 
left join (select waybillno,max(from_unixtime(cast(cast(baruploadtm as bigint)/1000 as bigint),'yyyy-MM-dd HH:mm:ss')) as barupload_tm 
from ods_kafka_fvp.fvp_core_fact_route_op 
where inc_day='$firstDay' and opcode='54' group by waybillno ) as t1 
on t0.waybill_no=t1.waybillno 
) as t 
) as tt where tt.rn=1
;




------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 2 获取5级地址
drop table if exists dm_gis.village_src_level5_addr_decode_di;
create table dm_gis.village_src_level5_addr_decode_di(
waybill_no string comment '运单号',
consignor_addr string comment '寄件地址',
province string comment '',
city string comment '',
county string comment '',
town string comment '',
vilname string comment '村级名称',
vilcode string comment '村级编码',
town_adcode string comment '乡镇编码',
class_code string comment '城乡分类代码',
distance string comment '到网点距离',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "5级地址（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 2.1.1 通过aoi id获取   
-- 表dm_gis.cms_aoi_village，表dm_gis.emap_district_village  (派件代码中)
-- 获取aoi_id  (利用aoi id（只用aoisrc=dispatch-norm和dispatch-chkn下的AOI）到表dm_gis.cms_aoi_village（最新inc_day）中获取village_guid )
drop table if exists dm_gis.tmp_village_src_aoisrc_mid;
create table dm_gis.tmp_village_src_aoisrc_mid stored as parquet as 
select t0.waybill_no,t0.order_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr,t0.aoi_id      
from ( select waybill_no,order_no,src_dist_code,inc_day,consignor_addr,aoi_id  from dm_gis.village_src_waybill_info_di where inc_day='$firstDay' and aoi_id is not null and aoi_id<>'' ) as t0 
left join ( select orderno from dm_gis.gis_rds_omsfrom
where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-9),'-','') and inc_day<='$firstDay' 
and orderno is not null and orderno<>'' and aoisrc<>'' 
and (aoisrc='dispatch-norm' or aoisrc='dispatch-chkn') group by orderno ) as t1 
on t0.order_no=t1.orderno 
where t1.orderno is not null 
;

-- 获取village_guid
drop table if exists dm_gis.tmp_village_src_guid_mid;
create table dm_gis.tmp_village_src_guid_mid stored as parquet as 
select t0.waybill_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr,t0.aoi_id,t1.village_guid   
from ( select waybill_no,src_dist_code,inc_day ,consignor_addr,aoi_id  from dm_gis.tmp_village_src_aoisrc_mid where  aoi_id is not null and aoi_id<>'' ) as t0 
left join (select city_code,aoi_id,village_guid from dm_gis.tmp_village_cms_aoi_village_mid where village_guid is not null and village_guid<>'')  as t1 
on t0.src_dist_code=t1.city_code and t0.aoi_id=t1.aoi_id 
;

insert overwrite table  dm_gis.village_src_level5_addr_decode_di partition(inc_day) 
select waybill_no,consignor_addr,name_p as province,name_c as city,name_d as county,name_t as town,name as vilname,area_code as vilcode,adcode_t as town_adcode,class_code,distant,src_dist_code,inc_day   
from dm_gis.tmp_village_src_guid_mid as t0 
left join ( select guid,name_p,name_c,name_d,name_t,adcode_t,name,area_code,class_code,distant from dm_gis.tmp_village_emap_district_village_mid ) as t1 
on t0.village_guid=t1.guid
where t1.guid is not null 
;

-- 2.1.2 从历史解析日志中获取   （派件代码中 dm_gis.tmp_village_village_log_flink_res_mid）
drop table if exists dm_gis.tmp_village_src_addr_decode_log_mid;
create table dm_gis.tmp_village_src_addr_decode_log_mid stored as parquet as 
select t0.waybill_no,t0.inc_day,t0.src_dist_code,t0.consignor_addr  
from ( select waybill_no,src_dist_code,inc_day,consignor_addr from dm_gis.village_src_waybill_info_di where inc_day='$firstDay'  ) as t0 
left join ( select waybill_no from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay'  group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
;


insert into  dm_gis.village_src_level5_addr_decode_di partition(inc_day) 
select t1.waybill_no,t1.consignor_addr,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,t1.src_dist_code,
t1.inc_day  
from dm_gis.tmp_village_village_log_flink_res_mid as t0 
left join ( select waybill_no,src_dist_code,inc_day,consignor_addr from dm_gis.tmp_village_src_addr_decode_log_mid  ) as t1 
on t0.p_city_code=t1.src_dist_code and t0.p_address=t1.consignor_addr  
where t1.waybill_no is not null 
;

-- 
drop table if exists dm_gis.tmp_village_src_guid_mid;
drop table if exists dm_gis.tmp_village_src_addr_decode_log_mid;

-- 2.1.2 调接口获取
-- http://gis-gw.intsit.sfdc.com.cn:9080/village/


-- 
mainClass="com.sf.gis.scala.tals.app.VillageAddrLevel5AddrSrcApp"
int_sql="
select t0.waybill_no,t0.inc_day,t0.src_dist_code as yd_citycode,t0.consignor_addr as yd_addr  
from ( select waybill_no,src_dist_code,inc_day,consignor_addr from dm_gis.village_src_waybill_info_di where inc_day='$firstDay'  ) as t0 
left join ( select waybill_no from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay'  group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
"
out_table="dm_gis.village_src_level5_addr_decode_di"
pall_num=20000



-- 2.1.3 运单5级地址去重
insert overwrite table  dm_gis.village_src_level5_addr_decode_di partition(inc_day) 
select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,src_dist_code,inc_day  
from (select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,src_dist_code,inc_day ,
row_number() over(partition by waybill_no,src_dist_code,inc_day  order by vilcode desc) as rn from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay' 
) as t where t.rn=1 
;



------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 2.2 是否进村

-- 1、当城乡分类代码不为220、210时，填入否；当城乡分类代码=220、210时往下走
-- 2、判断丰巢AOi是否与收件AOi一致是否=’是’，若为是则填入1，否则往下走

-- select t0.waybill_no,class_code,is_same_aoi
-- from ( select waybill_no,class_code from dm_gis.village_src_level5_addr_decode_di where inc_day'$firstDay' and class_code in ('220','210') ) as t0 
-- left join (select waybill_no,is_same_aoi from dwd_o.dwd_pd_pickup_cabinet_di where inc_day='$firstDay' and is_same_aoi='是' ) as t13
-- on t0.waybill_no=t13.waybill_no 
-- ;

-- 上面这个进村判断逻辑在后面加



-- 2.2.0 仓管家标签 仓管家收件经纬度  
-- inc_day利用主表inc_day和运单号匹配该表的inc_day和waybill_no （筛选条件：event = 'IntellSort_AddBag_002' and properties['task_type'] = '3'或event = 'IntellSort_AddBag_002' and properties['task_type'] = '4'或event = 'Handover_Loading_002' and properties['task_type'] = '15'或inc_day = '20231203' and event = 'Handover_Loading_002' and properties['task_type'] = '14'），若匹配成功则为1，否则为0
-- inc_day利用主表inc_day和运单号匹配该表的inc_day和waybill_no （筛选条件：event = 'IntellSort_AddBag_002' and properties['task_type'] = '3'或event = 'IntellSort_AddBag_002' and properties['task_type'] = '4'或event = 'Handover_Loading_002' and properties['task_type'] = '15'或inc_day = '20231203' and event = 'Handover_Loading_002' and properties['task_type'] = '14'），命中则获取经纬度（ properties['longitude'] as longitude , properties['latitude'] as latitude ，若有多个，随意取一个不为空的），否则为空 
-- create table dm_gis.village_src_cgj_mid(
-- waybill_no string comment '运单号',
-- class_code string comment '城乡分类代码',
-- vilcode string comment '村编码',
-- src_dist_code STRING COMMENT "分区城市代码",
-- cgj_longitude string COMMENT '仓管家经度',
-- cgj_latitude string COMMENT '仓管家纬度' 
-- )
-- COMMENT "仓管家标签 仓管家收件经纬度（收件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期")
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;


-- drop table if exists dm_gis.tmp_village_src_cgj;
-- create table dm_gis.tmp_village_src_cgj stored as parquet  as 
-- select 
-- waybill_no,longitude,latitude 
-- from (select waybill_no,properties['longitude'] as longitude,properties['latitude'] as latitude,
-- row_number() over(partition by waybill_no order by properties['longitude'] desc) as rn 
-- from dm_sfxg.platform_inc_ubas_leafnet 
-- where inc_day='$firstDay' 
-- and ( (event='IntellSort_AddBag_002' and (properties['task_type']='3' or  properties['task_type']='4') ) or (event='Handover_Loading_002' and (properties['task_type']='15' or  properties['task_type']='14') ) )
-- ) as t where t.rn=1
-- ;

-- insert overwrite table dm_gis.village_src_cgj_mid partition(inc_day='$firstDay') 
-- select 
-- t0.waybill_no,class_code,vilcode,src_dist_code,longitude as cgj_longitude,latitude as cgj_latitude 
-- from (select waybill_no,class_code,vilcode,src_dist_code,inc_day from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay' ) as t0 
-- left join (select waybill_no,longitude,latitude from dm_gis.tmp_village_src_cgj ) as t1 
-- on t0.waybill_no=t1.waybill_no
-- where t1.waybill_no is not null 
-- ;

-- drop table if exists dm_gis.tmp_village_src_cgj;

-- -- 2.2.0 坐标转换并跑接口判断是否上门 
-- create table dm_gis.village_src_cgj_res_mid(
-- waybill_no string comment '运单号',
-- class_code string comment '城乡分类代码',
-- vilcode string comment '村编码',
-- src_dist_code STRING COMMENT "分区城市代码",
-- cgj_longitude string COMMENT '仓管家经度',
-- cgj_latitude string COMMENT '仓管家纬度',
-- cgj_match string COMMENT '仓管家判断是否上门'
-- )
-- COMMENT "仓管家判断是否上门（收件）" 
-- PARTITIONED BY (inc_day STRING COMMENT "分区日期")
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;

-- -- 坐标转换、跑接口 （相关sql）
-- -- select waybill_no,class_code,vilcode,src_dist_code,cgj_longitude,cgj_latitude  from dm_gis.village_src_cgj_mid where inc_day='' 
-- -- select waybill_no,class_code,vilcode,src_dist_code,coordTransform(cgj_longitude,cgj_latitude) as gd_lon_lat  from village_cgj_01 
-- -- select waybill_no,class_code,vilcode,src_dist_code,split(gd_lon_lat,',')[0] as cgj_longitude,split(gd_lon_lat,',')[1] as cgj_latitude from village_cgj_02 
-- -- select vilcode,cgj_longitude,cgj_latitude from village_cgj_03
-- -- where
-- -- class_code in ('220','210') and vilcode is not null and vilcode<>'' and cgj_longitude is not null and cgj_longitude<>'' and cgj_latitude is not null and cgj_latitude<>''
-- -- group by vilcode,cgj_longitude,cgj_latitude


-- -- 跑接口输出
-- mainClass="com.sf.gis.scala.tals.app.VillageLatLngCgjRadius500App"
-- int_sql="select waybill_no,class_code,vilcode,src_dist_code,cgj_longitude,cgj_latitude  from dm_gis.village_src_cgj_mid where inc_day='$firstDay' "
-- out_table="dm_gis.village_src_cgj_res_mid" 
-- pall_num=10000


------------------------------
-- 2024.01.10 修改
-- 仓管家标签 仓管家收件经纬度  ods_kafka_fvp.fvp_core_fact_route_op(fvp巴枪路由数据表_opcode分区)
-- 利用运单号与inc_day与网点代码匹配该表的waybillno和inc_day和zonecode，命中则为1，不命中则为0
-- 利用运单号与inc_day与网点代码匹配该表的waybillno和inc_day和zonecode，命中则区分
-- （1）若存在opcode='209'，则取opcode='209'时的exts ['ext27']，若有多个取exts ['ext27']不为空，且barscantm为最早的，
-- （2）若若不存在opcode='209'，则取opcode='30'时的exts ['ext38']，若有多个取exts ['ext38']不为空，且barscantm为最早的
-- 不命中则为空(该坐标系为84坐标系，需转换为高德坐标系再落表)
create table dm_gis.village_src_cgj_new_mid(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
src_dist_code STRING COMMENT "分区城市代码",
cgj_longitude string COMMENT '仓管家经度',
cgj_latitude string COMMENT '仓管家纬度' 
)
COMMENT "仓管家标签 仓管家收件经纬度（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


drop table if exists dm_gis.tmp_village_src_cgj_new;
create table dm_gis.tmp_village_src_cgj_new stored as parquet  as 
select 
waybillno,zonecode,opcode,barscantm,split(cgj_lgtlat, ',')[0] as longitude,split(cgj_lgtlat, ',')[1] as latitude 
from ( 
select waybillno,zonecode,opcode,barscantm,
case when opcode='209' then exts['ext27'] 
     when opcode='30' then exts['ext38'] 
else '' end as cgj_lgtlat 
FROM ods_kafka_fvp.fvp_core_fact_route_op 
where inc_day='$firstDay' and (opcode='209' or opcode='30') and barSn='O2O-DDS-ISS' 
) as t 
;

drop table if exists dm_gis.tmp_village_src_class_code;
create table dm_gis.tmp_village_src_class_code stored as parquet  as 
select t0.waybill_no,source_zone_code,class_code,vilcode,src_dist_code,inc_day 
from ( select waybill_no,class_code,vilcode,src_dist_code,inc_day from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay' ) as t0 
left join ( select waybill_no,source_zone_code from dm_gis.village_src_waybill_info_di where inc_day='$firstDay' ) as t1 
on t0.waybill_no=t1.waybill_no
;


drop table if exists dm_gis.tmp_village_src_cgj_209_new;
create table dm_gis.tmp_village_src_cgj_209_new stored as parquet  as 
select 
t0.waybill_no,class_code,vilcode,src_dist_code,longitude as cgj_longitude,latitude as cgj_latitude 
from ( select waybill_no,source_zone_code,class_code,vilcode,src_dist_code,inc_day from dm_gis.tmp_village_src_class_code ) as t0 
left join (
select waybillno,zonecode,opcode,barscantm,longitude,latitude 
from ( select waybillno,zonecode,opcode,barscantm,longitude,latitude,
row_number() over(partition by waybillno order by barscantm asc) as rn 
from dm_gis.tmp_village_src_cgj_new where opcode='209' and longitude is not null and longitude<>'' and longitude<>'null'
) as t where t.rn=1 
) as t1 
on t0.waybill_no=t1.waybillno and t0.source_zone_code=t1.zonecode
where t1.waybillno is not null 
;


drop table if exists dm_gis.tmp_village_src_cgj_30_new;
create table dm_gis.tmp_village_src_cgj_30_new stored as parquet  as 
select 
t00.waybill_no,class_code,vilcode,src_dist_code,longitude as cgj_longitude,latitude as cgj_latitude 
from (select t0.waybill_no,source_zone_code,class_code,vilcode,src_dist_code,inc_day 
from ( select waybill_no,source_zone_code,class_code,vilcode,src_dist_code,inc_day from dm_gis.tmp_village_src_class_code ) as t0 
          left join ( select waybill_no from dm_gis.tmp_village_src_cgj_209_new ) as t1 
          on t0.waybill_no=t1.waybill_no 
          where t1.waybill_no is null  ) as t00 
left join (
select waybillno,zonecode,opcode,barscantm,longitude,latitude 
from (select waybillno,zonecode,opcode,barscantm,longitude,latitude,
row_number() over(partition by waybillno order by barscantm asc) as rn 
from dm_gis.tmp_village_src_cgj_new where opcode='30' and longitude is not null and longitude<>''  and longitude<>'null'
) as t where t.rn=1 
) as t01  
on t00.waybill_no=t01.waybillno and t00.source_zone_code=t01.zonecode
where t01.waybillno is not null 
;

insert overwrite table dm_gis.village_src_cgj_new_mid partition(inc_day='$firstDay') 
select 
waybill_no,class_code,vilcode,src_dist_code,cgj_longitude,cgj_latitude 
from dm_gis.tmp_village_src_cgj_209_new 
union all 
select 
waybill_no,class_code,vilcode,src_dist_code,cgj_longitude,cgj_latitude 
from dm_gis.tmp_village_src_cgj_30_new 
;


drop table if exists dm_gis.tmp_village_src_cgj_new;
drop table if exists dm_gis.tmp_village_src_class_code;
drop table if exists dm_gis.tmp_village_src_cgj_209_new;
drop table if exists dm_gis.tmp_village_src_cgj_30_new;



-- 2.2.0 坐标转换并跑接口判断是否上门 
create table dm_gis.village_src_cgj_res_new_mid(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
src_dist_code STRING COMMENT "分区城市代码",
cgj_longitude string COMMENT '仓管家经度',
cgj_latitude string COMMENT '仓管家纬度',
cgj_match string COMMENT '仓管家判断是否上门'
)
COMMENT "仓管家判断是否上门（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 坐标转换、跑接口 （相关sql）
-- select waybill_no,class_code,vilcode,src_dist_code,cgj_longitude,cgj_latitude  from dm_gis.village_src_cgj_new_mid where inc_day='' 
-- select waybill_no,class_code,vilcode,src_dist_code,coordTransform(cgj_longitude,cgj_latitude) as gd_lon_lat  from village_cgj_01 
-- select waybill_no,class_code,vilcode,src_dist_code,split(gd_lon_lat,',')[0] as cgj_longitude,split(gd_lon_lat,',')[1] as cgj_latitude from village_cgj_02 
-- select vilcode,cgj_longitude,cgj_latitude from village_cgj_03
-- where
-- class_code in ('220','210') and vilcode is not null and vilcode<>'' and cgj_longitude is not null and cgj_longitude<>'' and cgj_latitude is not null and cgj_latitude<>''
-- group by vilcode,cgj_longitude,cgj_latitude


-- 跑接口输出
mainClass="com.sf.gis.scala.tals.app.VillageLatLngCgjRadius500App"
int_sql="select waybill_no,class_code,vilcode,src_dist_code,cgj_longitude,cgj_latitude  from dm_gis.village_src_cgj_new_mid where inc_day='$firstDay' "
out_table="dm_gis.village_src_cgj_res_new_mid" 
pall_num=10000







-- 2.2.1 驿站编码 不为空 
drop table if exists dm_gis.village_src_owncode_isnotnull_mid;
create table dm_gis.village_src_owncode_isnotnull_mid(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码',
src_dist_code STRING COMMENT "分区城市代码",
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
lonlat_tag string COMMENT '出入库标签' 
)
COMMENT "驿站编码不为空（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnotnull_mid partition(inc_day) 
select 
waybill_no,class_code,vilcode,own_code,src_dist_code,operate_longitude,operate_latitude,lonlat_tag,inc_day 
from (select waybill_no,class_code,vilcode,src_dist_code,inc_day from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay' ) as t0 
left join (select mailno,own_code,
if(pj_operate_longitude<>'' and pj_operate_longitude<>'nan',pj_operate_longitude,operate_longitude) as operate_longitude,
if(pj_operate_latitude<>'' and pj_operate_latitude<>'nan',pj_operate_latitude,operate_latitude) as operate_latitude,
case when (pj_operate_longitude<>'' and pj_operate_longitude<>'nan') then '1' 
when (operate_longitude<>'' and operate_longitude<>'nan') then '2' 
else '' end as lonlat_tag   
from dm_yjy.yjy_mailno_kb where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-7),'-','') and inc_day<='$firstDay' and type='收件') as t1 
on t0.waybill_no=t1.mailno 
where t1.mailno is not null
;

-- 坐标系转换（百度转高德）
drop table if exists dm_gis.village_src_lonlat_transform_mid;
create table dm_gis.village_src_lonlat_transform_mid(
bd_lon string comment '百度经度',
bd_lat string comment '百度纬度',
gd_lon_lat string comment '高德经纬坐标'
)
COMMENT "坐标系转换（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLonLatTransformApp"
int_sql="select operate_longitude as bd_lon,operate_latitude as bd_lat from dm_gis.village_src_owncode_isnotnull_mid where inc_day='$firstDay' and operate_longitude<>'' and operate_longitude<>'nan' group by operate_longitude,operate_latitude"
out_table="dm_gis.village_src_lonlat_transform_mid" 


insert overwrite table dm_gis.village_src_owncode_isnotnull_mid partition(inc_day='$firstDay') 
select waybill_no,class_code,vilcode,own_code,src_dist_code,gd_lon as operate_longitude,gd_lat as operate_latitude,lonlat_tag   
from (select 
waybill_no,class_code,vilcode,own_code,src_dist_code,operate_longitude,operate_latitude,lonlat_tag,inc_day 
from dm_gis.village_src_owncode_isnotnull_mid where inc_day='$firstDay' ) as t0 
left join (select bd_lon,bd_lat,split(gd_lon_lat,',')[0] as gd_lon,split(gd_lon_lat,',')[1] as gd_lat from dm_gis.village_src_lonlat_transform_mid where inc_day='$firstDay') as t1 
on t0.operate_longitude=t1.bd_lon and t0.operate_latitude=t1.bd_lat 
;

-- 2.2.1 驿站编码 不为空 
-- 利用驿站收件经纬度跑接口
create table dm_gis.village_src_owncode_isnotnull_api_res_mid(
vilcode string comment '村编码',
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
match_res string COMMENT '是否',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "驿站编码不为空（收件）接口判断结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



-- 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadiusApp"
int_sql="select vilcode,operate_longitude,operate_latitude,src_dist_code as dist_code,inc_day from ( 
select waybill_no,vilcode,operate_longitude,operate_latitude,src_dist_code,inc_day from dm_gis.village_src_owncode_isnotnull_mid 
where inc_day='$firstDay' and class_code in ('220','210') and vilcode is not null and vilcode<>'' and operate_longitude is not null and operate_longitude<>'' and operate_latitude is not null and operate_latitude<>'' 
) as t group by vilcode,operate_longitude,operate_latitude,src_dist_code,inc_day "
out_table="dm_gis.village_src_owncode_isnotnull_api_res_mid" 
pall_num=10000



-- 2.2.2 驿站编码 为空
drop table if exists dm_gis.village_src_owncode_isnull_mid;
create table dm_gis.village_src_owncode_isnull_mid(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_owncode_isnull_mid partition(inc_day) 
select t0.waybill_no,class_code,vilcode,src_dist_code,inc_day  
from ( select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay'  and class_code in ('220','210') ) as t0 
left join (select waybill_no from dm_gis.village_src_owncode_isnotnull_mid where inc_day='$firstDay'  and class_code in ('220','210') group by waybill_no) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
;


-- 2.2.2.1 运单关联获取consigned_tm,consignee_emp_code
drop table if exists dm_gis.village_src_owncode_isnull_waybill_mid;
create table dm_gis.village_src_owncode_isnull_waybill_mid(
waybill_no string comment '运单号',
consigned_tm string comment '收件时间',
consignee_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取consigned_tm,consignee_emp_code（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill_mid partition(inc_day) 
select 
t0.waybill_no,t0.consigned_tm,t0.consignee_emp_code,
t1.class_code,t1.vilcode,t1.src_dist_code,
t1.inc_day 
from ( select waybill_no,consigned_tm,consignee_emp_code,src_dist_code,inc_day   from dm_gis.village_src_waybill_info_di where inc_day='$firstDay'  ) as t0 
left join (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_mid where inc_day='$firstDay'  ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 2.2.2.2 运单关联小哥轨迹 
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_gj_mid;
create table dm_gis.village_src_owncode_isnull_waybill_xg_gj_mid(
waybill_no string comment '运单号',
consignee_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
zx string comment '经度',
zy string comment '纬度',
consigned_tm string comment '收件时间',
tm string comment '小哥轨迹时间',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联小哥轨迹（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_gj_mid partition(inc_day) 
select 
waybill_no,consignee_emp_code,class_code,vilcode,zx,zy,consigned_tm,tm,t1.src_dist_code,t1.inc_day  
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,class_code,vilcode,src_dist_code,inc_day  
from dm_gis.village_src_owncode_isnull_waybill_mid where inc_day='$firstDay'  and consigned_tm<>'' ) as t1 
on t0.un=t1.consignee_emp_code
where consigned_tm-60*5<=tm and consigned_tm+60*5>=tm
;

-- 2.2.2.3 取最靠近收件日期的轨迹点 (top1的)
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_mid;
create table dm_gis.village_src_owncode_isnull_waybill_xg_mid(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "取最靠近收件日期的轨迹点（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_mid partition(inc_day) 
select waybill_no,zx,zy,src_dist_code,inc_day  
from (
select waybill_no,src_dist_code,inc_day ,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,src_dist_code,inc_day ,zx,zy,abs(consigned_tm-tm) as diff_tm from dm_gis.village_src_owncode_isnull_waybill_xg_gj_mid where inc_day='$firstDay'  ) as t  
) as t0 where t0.rn=1 
;

-- 2.2.2.4 调坐标查询行政村接口 （跟派件一起）
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_hy_mid;
create table dm_gis.village_src_owncode_isnull_waybill_xg_hy_mid (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空小哥还原（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_hy_mid partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,src_dist_code,inc_day  
from (select waybill_no,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_waybill_xg_mid where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_json_decode_set_mid  ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;


-- 
drop table if exists dm_gis.village_src_owncode_isnull_res_mid;
create table dm_gis.village_src_owncode_isnull_res_mid (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
adcode_isin string comment 'adcode是否在adcode list中',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空res（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_owncode_isnull_res_mid partition(inc_day)  
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,src_dist_code,inc_day   
from (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_mid where inc_day='$firstDay'  ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_src_owncode_isnull_waybill_xg_hy_mid where inc_day='$firstDay'   ) as t1 
on t0.waybill_no=t1.waybill_no
;



------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 3 是否进乡镇上门
-- 城乡代码为220或是否进村上门为‘是’标记为‘否’；对其他的，用小哥轨迹坐标调坐标查询aoi接口（参数外延200m距离）,判断是否为乡镇上门，是：接口返回aoicode中有运单aoicode，否：接口返回aoicode中无运单aoicode

-- 3.1 运单关联获取 consigned_tm,consignee_emp_code,aoi_id,aoi_code
drop table if exists dm_gis.village_src_classcode_waybill_mid;
create table dm_gis.village_src_classcode_waybill_mid (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
consigned_tm string comment '',
consignee_emp_code string comment '',
aoi_id string comment '',
aoi_code string comment '',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_src_classcode_waybill_mid partition(inc_day)  
select t1.waybill_no,t1.class_code,t1.vilcode,t0.consigned_tm,t0.consignee_emp_code,aoi_id,aoi_code,t1.src_dist_code,t1.inc_day   
from ( select waybill_no,consigned_tm,consignee_emp_code,aoi_id,aoi_code,src_dist_code,inc_day   from dm_gis.village_src_waybill_info_di where inc_day='$firstDay'   ) as t0 
left join (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay'  and (class_code is null or class_code not in ('220','210','110','111')  ) ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 2024.01.10 新增修改
-- 揽收坐标所在AOI
insert overwrite table dm_gis.village_src_classcode_waybill_mid partition(inc_day)   
select 
t0.waybill_no,class_code,vilcode,consigned_tm,consignee_emp_code,aoi_id,aoi_code,src_dist_code,inc_day
from (select waybill_no,class_code,vilcode,consigned_tm,consignee_emp_code,aoi_id,aoi_code,src_dist_code,inc_day 
from dm_gis.village_src_classcode_waybill_mid where inc_day='$firstDay' ) as t0
left join ( select waybill_no,consign_xy_aoiid from dm_gis.t_gdl_waybill_state_info where inc_day='$firstDay' and consign_xy_aoiid is not null and consign_xy_aoiid<>'' ) as t1
on t0.waybill_no=t1.waybill_no and t0.aoi_id=t1.consign_xy_aoiid
where t1.waybill_no is null
;




-- 3.2 运单关联小哥轨迹  
drop table if exists dm_gis.village_src_classcode_waybill_xg_gj_mid;
create table dm_gis.village_src_classcode_waybill_xg_gj_mid (
waybill_no string comment '',
aoi_id string comment '',
aoi_code string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
consigned_tm string comment '',
tm string comment '',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_classcode_waybill_xg_gj_mid partition(inc_day)  
select 
waybill_no,aoi_id,aoi_code,class_code,vilcode,zx,zy,consigned_tm,tm,src_dist_code,t1.inc_day  
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='$firstDay' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(consigned_tm) as consigned_tm,consignee_emp_code,aoi_id,aoi_code,class_code,vilcode,src_dist_code,inc_day  
from dm_gis.village_src_classcode_waybill_mid where inc_day='$firstDay'  and consignee_emp_code<>'' and consigned_tm<>'' ) as t1 
on t0.un=t1.consignee_emp_code
where consigned_tm-60*5<=tm and consigned_tm+60*5>=tm
;

-- 3.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_src_classcode_waybill_xg_mid;
create table dm_gis.village_src_classcode_waybill_xg_mid (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "运单关联获取（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_src_classcode_waybill_xg_mid partition(inc_day)  
select waybill_no,aoi_code,zx,zy,src_dist_code,inc_day  
from (
select waybill_no,src_dist_code,inc_day ,aoi_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,src_dist_code,inc_day ,aoi_code,zx,zy,abs(consigned_tm-tm) as diff_tm from dm_gis.village_src_classcode_waybill_xg_gj_mid where inc_day='$firstDay'    ) as t  
) as t0 where t0.rn=1 
;


-- 3.5 能关联小哥轨迹的运单查询aoi后判断是否上门的结果
drop table if exists dm_gis.village_src_classcode_waybill_xg_aoi_res_mid;
create table dm_gis.village_src_classcode_waybill_xg_aoi_res_mid (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
matchres string comment '',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "跑经纬坐标查询aoi（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_src_classcode_waybill_xg_aoi_res_mid partition(inc_day)  
select waybill_no,t0.aoi_code,zx,zy,matchres,src_dist_code,inc_day  from (select waybill_no,aoi_code,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_classcode_waybill_xg_mid where inc_day='$firstDay'   ) as t0 
left join (select aoi_code,lgt,lat,matchres,dist_code from dm_gis.village_classcode_waybill_xg_res_mid where inc_day='$firstDay'   ) as t1 
on t0.aoi_code=t1.aoi_code and t0.zx=t1.lgt and t0.zy=t1.lat and t0.src_dist_code=t1.dist_code 
;
 

------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 4 快递上门结果表 （收件）
drop table if exists dm_gis.village_src_kdsm_res_di;
create table dm_gis.village_src_kdsm_res_di (
src_hq_code	string	comment '大区代码',
src_area_code	string	comment '地区代码',
area_name	string	comment '地区名称',
source_zone_code	string	comment '网点代码',
dept_name	string	comment '网点名称',
waybill_no	string	comment '单号',
consignee_emp_code	string	comment '派件人工号',
real_product_code	string	comment '产品名称',
meterage_weight_qty	string	comment '计费重量',
pay_cust_type	string	comment '付费客户类型',
service_prod_code	string	comment '增值服务代码',
all_fee_rmb	string	comment '总收入（rmb）',
freight_monthly_acct_code	string	comment '月结账号',
is_yj	string	comment '是否月结',
aoi_code	string	comment 'AOI编码',
aoi_name	string	comment 'AOI名称',
aoi_type_name	string	comment 'aoi类型名称',
aoi_area_code	string	comment 'AOI区域',
province	string	comment '省',
city	string	comment '市/市辖区',
county	string	comment '区/县',
town	string	comment '镇/乡',
town_adcode	string	comment '镇adcode',
vil_name	string	comment '行政村/社区',
vil_code	string	comment '村adcode',
class_code	string	comment '城乡分类代码',
own_code	string	comment '驿站编码',
is_jcpj	string	comment '是否进村派件',
is_jxzpj	string	comment '是否为乡镇上门派件',
yd_type	string	comment '运单类型',
wd_type	string	comment '网点类型',
src_dist_code	string	comment '分区城市代码',
tt_fee_zh_all_fee	string	comment '折后收入',
distance	string	comment '寄件地址到收件网点的距离',
operate_longitude	string	comment '驿站经度',
operate_latitude	string	comment '驿站纬度',
consigned_tm	string	comment '揽收时间',
is_js	string	comment '是否集收',
lonlat_tag	string	comment '出入库标签',
subsidy_type	string	comment '补贴标签',
subsidy	string	comment '补贴更新',
src_type_code	string	comment '网点类型代码',
order_no	string	comment '订单号',
aoi_id	string	comment 'AOI id',
aoi_src	string	comment 'AOI src',
aoi_type	string	comment 'AOI类型代码',
aoi_area_type	string	comment 'AOI区域类型名称',
is_cgj	string	comment '仓管家标签',
cgj_longitude	string	comment '仓管家收件经度',
cgj_latitude	string	comment '仓管家收件纬度',
-- 2024.01.09  增加字段
consign_xy_aoiid string	comment '揽收坐标所在AOI',
csg_location_mark string	comment '揽收位置标签',
bar_sn string	comment '设备号',
is_same_aoi string	comment '丰巢AOi是否与收件AOi一致',
cabinet_code string	comment '丰巢柜编码',
position_name string	comment '收件岗位',
city_label string	comment '城区标签',
town_country_types string	comment '城乡区域类型' 
)
COMMENT '行政村快递上门（收件）'
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 2024.01.09  增加字段
-- 
-- 揽收坐标所在AOI   consign_xy_aoiid
-- 揽收位置标签   csg_location_mark
-- 设备号   bar_sn
-- 丰巢AOi是否与收件AOi一致  is_same_aoi
-- 丰巢柜编码  cabinet_code
-- 收件岗位  position_name
-- 城区标签  city_label
-- 城乡区域类型   town_country_types

alter table dm_gis.village_src_kdsm_res_di add columns(consign_xy_aoiid  string comment '揽收坐标所在AOI') cascade;
alter table dm_gis.village_src_kdsm_res_di add columns(csg_location_mark  string comment '揽收位置标签') cascade;
alter table dm_gis.village_src_kdsm_res_di add columns(bar_sn  string comment '设备号') cascade;
alter table dm_gis.village_src_kdsm_res_di add columns(is_same_aoi  string comment '丰巢AOi是否与收件AOi一致') cascade;
alter table dm_gis.village_src_kdsm_res_di add columns(cabinet_code  string comment '丰巢柜编码') cascade;
alter table dm_gis.village_src_kdsm_res_di add columns(position_name  string comment '收件岗位') cascade;
alter table dm_gis.village_src_kdsm_res_di add columns(city_label  string comment '城区标签') cascade;
alter table dm_gis.village_src_kdsm_res_di add columns(town_country_types  string comment '城乡区域类型') cascade;

-- 2024.01.24  增加字段
-- 揽收位置AOI区域			
-- 揽收位置是否在地址所在AOI区域
alter table dm_gis.village_src_kdsm_res_di add columns(consign_aoi_area  string comment '揽收位置AOI区域') cascade;
alter table dm_gis.village_src_kdsm_res_di add columns(is_addr_aoi  string comment '揽收位置是否在地址所在AOI区域') cascade;



-- 驿站编码不为空，结果
drop table if exists dm_gis.tmp_village_src_owncode_isnotnull_res;
create table dm_gis.tmp_village_src_owncode_isnotnull_res stored as parquet  as 
select 
t0.waybill_no,t0.own_code,t0.src_dist_code,t0.vilcode,t0.operate_longitude,t0.operate_latitude,t0.lonlat_tag,t1.match_res 
from (select waybill_no,own_code,src_dist_code,vilcode,operate_longitude,operate_latitude,lonlat_tag from dm_gis.village_src_owncode_isnotnull_mid where inc_day='$firstDay'  ) as t0 
left join (select src_dist_code,vilcode,operate_longitude,operate_latitude,match_res from dm_gis.village_src_owncode_isnotnull_api_res_mid where inc_day='$firstDay' ) as t1 
on t0.src_dist_code=t1.src_dist_code and t0.vilcode=t1.vilcode and t0.operate_longitude=t1.operate_longitude and t0.operate_latitude=t1.operate_latitude 
;



-- AOI src 
drop table if exists dm_gis.tmp_village_src_aoisrc_res;
create table dm_gis.tmp_village_src_aoisrc_res stored as parquet  as 
select orderno,aoisrc 
from (select orderno,aoisrc,row_number() over(partition by orderno order by inc_day desc,aoisrc desc) as rn 
from dm_gis.gis_rds_omsfrom where inc_day>=replace(date_add(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-9),'-','') and inc_day<='$firstDay' and orderno is not null and orderno<>'' and aoisrc<>'' 
) as t where t.rn=1
;




-- 收件结果表数据写入
-- insert overwrite table  dm_gis.village_src_kdsm_res_di partition(inc_day='$firstDay') 
insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,
'' as pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,'' as aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,
case when (class_code in ('220','210')) or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type,
wd_type,src_dist_code,
'' as tt_fee_zh_all_fee,
distance,operate_longitude,operate_latitude,consigned_tm,'' as is_js,lonlat_tag,
'' as subsidy_type,'' as subsidy,
src_type_code,order_no,aoi_id,aoi_src,aoi_type,aoi_area_type,is_cgj,cgj_longitude,cgj_latitude,
-- 2024.01.09
'' as consign_xy_aoiid,
'' as csg_location_mark,
'' as bar_sn,
'' as is_same_aoi,
'' as cabinet_code,
'' as position_name,
'' as city_label,
'' as town_country_types,
-- 2024.01.24 
'' as consign_aoi_area,
'' as is_addr_aoi 

from (select 
src_hq_code,src_area_code,t6.area_name,t0.src_dist_code,source_zone_code,t6.dept_name,src_type_code,t0.waybill_no,t0.order_no,consignee_emp_code,product_code as real_product_code,
meterage_weight_qty_kg as meterage_weight_qty,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
case when freight_monthly_acct_code<>'' then '1' else '0' end as is_yj,
t0.aoi_code,t0.aoi_id,t9.aoisrc as aoi_src,aoi_name,aoi_type,t7.aoi_area_code,t7.aoi_area_type,
if(t10.waybill_no is not null,'1','0') as is_cgj,
t10a.cgj_longitude,
t10a.cgj_latitude,
t1.province,t1.city,t1.county,t1.town,t1.town_adcode,t1.vilname as vil_name,t1.vilcode as vil_code,t1.class_code,
t3.own_code,t3.operate_longitude,t3.operate_latitude,t3.lonlat_tag,
case when t10a.cgj_match='1' or t3.match_res='1' or t4.adcode_isin='1' or (t1.class_code in ('220','210') and t13.is_same_aoi='是') then '1' else '0' end as is_jcpj,
case when ((t1.class_code is null or t1.class_code not in ('220','210','110','111')) and  t5a.waybill_no is not null ) or t5.matchres='1'  then '1' else '0' end as is_jxzpj,
case when src_type_code='DB05-DLD' then '代理' else '自营' end as wd_type,
distance,
consigned_tm 

from (select 
src_hq_code,src_area_code,src_dist_code,consignor_addr,source_zone_code,src_type_code,
waybill_no,order_no,consignee_emp_code,product_code,meterage_weight_qty_kg,service_prod_code,
all_fee_rmb,freight_monthly_acct_code,aoi_code,aoi_id,aoi_name,aoi_type,
consigned_tm 
from dm_gis.village_src_waybill_info_di where inc_day='$firstDay'   ) as t0 
-- 5级地址
left join ( select waybill_no,consignor_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,src_dist_code,inc_day   
from dm_gis.village_src_level5_addr_decode_di where inc_day='$firstDay'  ) as t1 
on t0.waybill_no=t1.waybill_no 
-- 是否进村
left join (select waybill_no,own_code,src_dist_code,vilcode,operate_longitude,operate_latitude,lonlat_tag,match_res from dm_gis.tmp_village_src_owncode_isnotnull_res ) as t3 
on t0.waybill_no=t3.waybill_no 
left join (select waybill_no,class_code,vilcode,src_dist_code,inc_day,zx,zy,adcode_isin  from dm_gis.village_src_owncode_isnull_res_mid where inc_day='$firstDay'  ) as t4 
on t0.waybill_no=t4.waybill_no 
-- 2024.01.09 
-- 2、判断丰巢AOi是否与派件AOi一致是否=’是’，若为’是’则填入1，否则往下走
left join (select waybill_no,is_same_aoi,cabinet_code from dwd_o.dwd_pd_pickup_cabinet_di where inc_day='$firstDay' ) as t13
on t0.waybill_no=t13.waybill_no 

-- 是否进乡镇
left join (select waybill_no,src_dist_code,inc_day,aoi_code,zx,zy,matchres from dm_gis.village_src_classcode_waybill_xg_aoi_res_mid where inc_day='$firstDay'  ) as t5 
on t0.waybill_no=t5.waybill_no 
-- 2024.01.10 新增修改
left join ( select waybill_no,consign_xy_aoiid from dm_gis.t_gdl_waybill_state_info where inc_day='$firstDay' and consign_xy_aoiid is not null and consign_xy_aoiid<>'' ) as t5a
on t0.waybill_no=t5a.waybill_no and t0.aoi_id=t5a.consign_xy_aoiid

-- 地区名称 网点名称
left join (select dept_code,area_name,dept_name,dept_type_code from (select dept_code,area_name,dept_name,dept_type_code,row_number() over(partition by dept_code order by inc_day desc)  as rn 
from  dim.dim_dept_info_df where inc_day=date_format(date_add(current_date(),-1),'yyyyMMdd') ) as b where b.rn=1 ) as t6 
on t0.source_zone_code=t6.dept_code 
-- AOI区域	AOI区域类型名称	
left join (select aoi_id,aoi_area_code,aoi_area_type from dm_tc_waybillinfo.aoi_area_aoi ) as t7 
on t0.aoi_code=t7.aoi_id 
-- AOI src   利用order_no匹配表dm_gis.gis_rds_omsfrom（该表inc_day=主表inc_day）中的orderno，命中则获取aoisrc
left join ( select orderno,aoisrc from dm_gis.tmp_village_src_aoisrc_res ) as t9
on t0.order_no=t9.orderno 

-- 2024.01.09 
-- 仓管家标签 仓管家收件经纬度 
left join (select waybillno as waybill_no  FROM ods_kafka_fvp.fvp_core_fact_route_op where inc_day='$firstDay' and (opcode='209' or opcode='30') and barSn='O2O-DDS-ISS' group by waybillno) as t10 
on t0.waybill_no=t10.waybill_no 
left join (select waybill_no,cgj_longitude,cgj_latitude,cgj_match from dm_gis.village_src_cgj_res_new_mid where inc_day='$firstDay') as t10a
on t0.waybill_no=t10a.waybill_no 

) as t 
;





--------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------

-- ------ 2024.01.09 
-- 设备号 (第一优先级)
-- 1.利用运单号匹配该表opcode='54'下的waybillno，获取barSn
-- 2.剩余未匹配上的运单号，匹配opcode=’50’下的waybillno，获取barSn
-- 若有多个，取baruploadtm与揽收时间最近的操作
drop table if exists dm_gis.tmp_village_src_bar_sn_54_res;
create table dm_gis.tmp_village_src_bar_sn_54_res stored as parquet  as 
select waybill_no,barSn,abs_tm  
from (select waybill_no,barSn,abs_tm,row_number() over(partition by waybill_no order by abs_tm asc ) as rn 
from (select 
t0.waybill_no,barSn,abs(consigned_tm-baruploadtm) as abs_tm
from (select waybill_no,1000*unix_timestamp(consigned_tm) as consigned_tm from dm_gis.village_src_waybill_info_di where inc_day='$firstDay'  ) as t0 
left join (SELECT waybillno,opcode,barSn,cast(baruploadtm as bigint) as baruploadtm FROM ods_kafka_fvp.fvp_core_fact_route_op where inc_day='$firstDay'  and opcode='54' ) as t1 
on t0.waybill_no=t1.waybillno 
where barSn is not null
) as t 
) as tt where tt.rn=1
;

drop table if exists dm_gis.tmp_village_src_bar_sn_50_res;
create table dm_gis.tmp_village_src_bar_sn_50_res stored as parquet  as 
select waybill_no,barSn,abs_tm  
from (select waybill_no,barSn,abs_tm,row_number() over(partition by waybill_no order by abs_tm asc ) as rn 
from (select t00.waybill_no,barSn,abs(consigned_tm-baruploadtm) as abs_tm
from (select t0.waybill_no,consigned_tm 
      from (select waybill_no,1000*unix_timestamp(consigned_tm) as consigned_tm from dm_gis.village_src_waybill_info_di where inc_day='$firstDay'  ) as t0 
      left join (SELECT waybill_no FROM dm_gis.tmp_village_src_bar_sn_54_res ) as t1 
     on t0.waybill_no=t1.waybill_no 
     where t1.waybill_no is null 
) as t00 
left join (SELECT waybillno,opcode,barSn,cast(baruploadtm as bigint) as baruploadtm FROM ods_kafka_fvp.fvp_core_fact_route_op where inc_day='$firstDay'  and opcode='50' ) as t01 
on t00.waybill_no=t01.waybillno 
where barSn is not null
) as t 
) as tt where tt.rn=1
;

drop table if exists dm_gis.tmp_village_src_bar_sn_res;
create table dm_gis.tmp_village_src_bar_sn_res stored as parquet  as 
select waybill_no,barSn from dm_gis.tmp_village_src_bar_sn_54_res 
union all 
select waybill_no,barSn from dm_gis.tmp_village_src_bar_sn_50_res 
;

-- 2024.01.10 新增
-- 揽收坐标所在AOI:	   dm_gis.t_gdl_waybill_state_info(运单状态表，信息来源于丰源表,第一个任务只刷新坐标，第二个任务刷新aoi，任务id:678177, 919285)
-- consign_xy_aoiid	利用运单号和inc_day匹配该表的waybill_no和inc_day命中则获取consign_xy_aoiid，否则为空 
-- select waybill_no,consign_xy_aoiid from dm_gis.t_gdl_waybill_state_info where inc_day='$firstDay'
-- 揽收位置标签:
-- 1.驿站编码是否为空，若为’是’则跳到步骤2，若为‘否’则往下走
-- （1）当出入库标签=1标记为’驿站出库’，
-- （2）当出入库标签=2，则为’驿站入库’
-- （3）当出入库标签为空时，则‘驿小店经纬度缺失’
-- 2.剔除揽收坐标所在AOI为空数据（标记为空），判断揽收坐标所在AOI是否等于Aoi_id,若为是则标记为’丰源定位与AOI一致’，若为否则标记为’丰源定位与AOI不一致’
drop table if exists dm_gis.tmp_village_src_csg_location_mark_res;
create table dm_gis.tmp_village_src_csg_location_mark_res stored as parquet  as 
select waybill_no,
case when lonlat_tag='1' then '驿站出库' 
     when lonlat_tag='2' then '驿站入库' 
else '驿小店经纬度缺失' end as csg_location_mark 
from dm_gis.village_src_owncode_isnotnull_mid where inc_day='$firstDay'  
union all 
select 
t3.waybill_no,
case when aoi_id is not null and aoi_id<>'' and aoi_id=consign_xy_aoiid then '丰源定位与AOI一致'
     when aoi_id is not null and aoi_id<>'' and aoi_id<>consign_xy_aoiid then '丰源定位与AOI不一致'
else '' end as csg_location_mark
from (select t0.waybill_no,aoi_id 
from ( select waybill_no,aoi_id from dm_gis.village_src_waybill_info_di where inc_day='$firstDay' ) as t0 
left join ( select waybill_no from dm_gis.village_src_owncode_isnotnull_mid where inc_day='$firstDay' group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
) as t3 
left join (select waybill_no,consign_xy_aoiid from dm_gis.t_gdl_waybill_state_info where inc_day='$firstDay' and consign_xy_aoiid is not null and consign_xy_aoiid<>'') as t4 
on t3.waybill_no=t4.waybill_no
;





-- 2024.01.09
insert overwrite table  dm_gis.village_src_kdsm_res_di partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,
pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,
yd_type,
wd_type,src_dist_code,
tt_fee_zh_all_fee,
distance,operate_longitude,operate_latitude,consigned_tm,is_js,lonlat_tag,
subsidy_type,subsidy,
src_type_code,order_no,aoi_id,aoi_src,aoi_type,aoi_area_type,is_cgj,cgj_longitude,cgj_latitude,
-- 2024.01.09
t16.consign_xy_aoiid as consign_xy_aoiid,
t17.csg_location_mark as csg_location_mark,
t12.barSn as bar_sn,
t13.is_same_aoi as is_same_aoi,
t13.cabinet_code as cabinet_code,
t14.position_name as position_name,
t15.remark as city_label,
case when (SUBSTR(county, -1)='区' and class_code in ('111','112') ) or t15.remark='市中心'  then '市区' 
     when (SUBSTR(county, -1)!='区' and class_code in ('111','112') ) or t15.remark='县中心'  then '县区'  
     when class_code in  ('121','122','123')  then '镇区'  
     when class_code in  ('210','220')  then '乡村'
else '' end  as town_country_types,


from (select * from dm_gis.village_src_kdsm_res_di where inc_day='$firstDay' ) as t0 
-- 2024.01.10 新增
-- 揽收坐标所在AOI
left join (select waybill_no,consign_xy_aoiid from dm_gis.t_gdl_waybill_state_info where inc_day='$firstDay') as t16 
on t0.waybill_no=t16.waybill_no 
-- 揽收位置标签 
left join (select waybill_no,csg_location_mark from dm_gis.tmp_village_src_csg_location_mark_res ) as t17 
on t0.waybill_no=t17.waybill_no 

-- 设备号 (第一优先级)
left join (select waybill_no,barSn from dm_gis.tmp_village_src_bar_sn_res )  as t12 
on t0.waybill_no=t12.waybill_no 
-- 丰巢AOi是否与收件AOi一致  (第一优先级)
-- 丰巢柜编码  (第一优先级)
left join (select waybill_no,is_same_aoi,cabinet_code from dwd_o.dwd_pd_pickup_cabinet_di where inc_day='$firstDay' ) as t13
on t0.waybill_no=t13.waybill_no 
-- 收件岗位  (第一优先级)
left join (select org_emp_code,position_name from dim.dim_emp_info_df where inc_day='$firstDay' ) as t14 
on t0.consignee_emp_code=t14.org_emp_code 

-- -- 2024.01.10 
-- -- 城区标签 城乡区域类型   dm_gis.ods_csv_village_city_af (来自线下数据源) 利用vilcode匹配该表的areaCode，若匹配成功获取remark字段，否则为空
left join ( select area_code,remark 
          from (select 
          area_code,remark,row_number() over(partition by area_code order by remark_label asc) as rn 
          from (select area_code,remark,
          case when remark='市中心' then '1' 
          when remark='县中心' then '2' 
          when remark='镇中心' then '3' 
          when remark='新城' then '4'  
          else '' end as remark_label   from dm_gis.ods_csv_village_city_af where remark is not null and remark<>'' 
          ) as t 
          ) as tt where tt.rn=1 )  as t15
on t0.vil_code=t15.area_code 
;



-- -- 2024.01.24 
-- 揽收位置AOI区域	dm_gis.cms_aoi_sch/dm_tc_waybillinfo.aoi_area_aoi		
-- 揽收位置是否在地址所在AOI区域		判断揽收位置AOi区域=AOI区域？
drop table if exists dm_gis.tmp_village_src_aoi_area_res;
create table dm_gis.tmp_village_src_aoi_area_res stored as parquet  as 
select t0.aoi_id,t0.aoi_code,t1.aoi_area_code 
from (select aoi_id,aoi_code from dm_gis.cms_aoi_sch ) as t0 
left join ( select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi  ) as t1 
on t0.aoi_code=t1.aoi_id
;

-- 2024.01.24 
insert overwrite table  dm_gis.village_src_kdsm_res_di partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,
pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,t0.aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,
yd_type,
wd_type,src_dist_code,
tt_fee_zh_all_fee,
distance,operate_longitude,operate_latitude,consigned_tm,is_js,lonlat_tag,
subsidy_type,subsidy,
src_type_code,order_no,t0.aoi_id,aoi_src,aoi_type,aoi_area_type,is_cgj,cgj_longitude,cgj_latitude,
consign_xy_aoiid,
csg_location_mark,
bar_sn,
is_same_aoi,
cabinet_code,
position_name,
city_label,
town_country_types,
t1.aoi_area_code as consign_aoi_area,
case when ((t0.aoi_area_code is not null and t0.aoi_area_code<>'') or (t1.aoi_area_code is not null and t1.aoi_area_code<>'')) 
          and t0.aoi_area_code=t1.aoi_area_code then '1' 
     when ((t0.aoi_area_code is not null and t0.aoi_area_code<>'') or (t1.aoi_area_code is not null and t1.aoi_area_code<>'')) 
          and t0.aoi_area_code!=t1.aoi_area_code then '0' 
else '' end as is_addr_aoi 

from (select * from dm_gis.village_src_kdsm_res_di where inc_day='$firstDay' ) as t0 
-- -- 2024.01.24 
-- 揽收位置AOI区域	dm_gis.cms_aoi_sch/dm_tc_waybillinfo.aoi_area_aoi		
-- 揽收位置是否在地址所在AOI区域		判断揽收位置AOi区域=AOI区域？
left join (select aoi_id,aoi_area_code from dm_gis.tmp_village_src_aoi_area_res) as t1 
on t0.consign_xy_aoiid=t1.aoi_id 
;








---------------------------------------------------------------------------------------
-- 2024.01.09 2024.01.10 变动内容
---------------------------------------------------------------------------------------
-- 2024.01.10 新增
-- 揽收坐标所在AOI:	   dm_gis.t_gdl_waybill_state_info(运单状态表，信息来源于丰源表,第一个任务只刷新坐标，第二个任务刷新aoi，任务id:678177, 919285)
-- consign_xy_aoiid	利用运单号和inc_day匹配该表的waybill_no和inc_day命中则获取consign_xy_aoiid，否则为空 
select waybill_no,consign_xy_aoiid from dm_gis.t_gdl_waybill_state_info where inc_day='$firstDay'

-- 揽收位置标签:
-- 1.驿站编码是否为空，若为’是’则跳到步骤2，若为‘否’则往下走
-- （1）当出入库标签=1标记为’驿站出库’，
-- （2）当出入库标签=2，则为’驿站入库’
-- （3）当出入库标签为空时，则‘驿小店经纬度缺失’
-- 2.剔除揽收坐标所在AOI为空数据（标记为空），判断揽收坐标所在AOI是否等于Aoi_id,若为是则标记为’丰源定位与AOI一致’，若为否则标记为’丰源定位与AOI不一致’

drop table if exists dm_gis.tmp_village_src_csg_location_mark_res;
create table dm_gis.tmp_village_src_csg_location_mark_res stored as parquet  as 
select waybill_no,
case when lonlat_tag='1' then '驿站出库' 
     when lonlat_tag='2' then '驿站入库' 
else '驿小店经纬度缺失' end as csg_location_mark 
from dm_gis.village_src_owncode_isnotnull_mid where inc_day='$firstDay'  
union all 
select 
t3.waybill_no,
case when aoi_id is not null and aoi_id<>'' and aoi_id=consign_xy_aoiid then '丰源定位与AOI一致'
     when aoi_id is not null and aoi_id<>'' and aoi_id<>consign_xy_aoiid then '丰源定位与AOI不一致'
else '' end as csg_location_mark
from (select t0.waybill_no,aoi_id 
from ( select waybill_no,aoi_id from dm_gis.village_src_waybill_info_di where inc_day='$firstDay' ) as t0 
left join ( select waybill_no from dm_gis.village_src_owncode_isnotnull_mid where inc_day='$firstDay' group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
) as t3 
left join (select waybill_no,consign_xy_aoiid from dm_gis.t_gdl_waybill_state_info where inc_day='$firstDay' and consign_xy_aoiid is not null and consign_xy_aoiid<>'') as t4 
on t3.waybill_no=t4.waybill_no
;


-----------------------------
-- 2024.01.10 新增
-- 设备号 (第一优先级)
-- 1.利用运单号匹配该表opcode=’54’下的waybillno，获取barSn
-- 2.剩余未匹配上的运单号，匹配opcode=’50’下的waybillno，获取barSn
-- 若有多个，取baruploadtm与揽收时间最近的操作
SELECT waybillno,opcode,barSn FROM ods_kafka_fvp.fvp_core_fact_route_op where inc_day='$firstDay'  and opcode in ('54','50')


-- 丰巢AOi是否与收件AOi一致  (第一优先级)
-- dwd_o.dwd_pd_pickup_cabinet_di		利用运单号与inc_day匹配该表的waybill_no获取is_same_aoi
-- 丰巢柜编码  (第一优先级)
-- dwd_o.dwd_pd_pickup_cabinet_di		利用运单号与inc_day匹配该表的waybill_no获取cabinet_code
select waybill_no,is_same_aoi,cabinet_code from dwd_o.dwd_pd_pickup_cabinet_di where inc_day='$firstDay'


-- 收件岗位  (第一优先级)
-- dim.dim_emp_info_df（取T-1）		利用小哥工号，匹配该表的org_emp_code，获取position_name
select org_emp_code,position_name from dim.dim_emp_info_df where inc_day='20240110'


-- 2024.01.10 新增  
-- 城区标签    dm_gis.ods_csv_village_city_af (来自线下数据源) 利用vilcode匹配该表的areaCode，若匹配成功获取remark字段，否则为空
-- 有多个，就按照优先取市中心>县中心>镇中心>新城 
select area_code,remark,
case when remark='市中心' then '1' 
    when remark='县中心' then '2' 
    when remark='镇中心' then '3' 
    when remark='新城' then '4'  
else '' end as remark_label   from dm_gis.ods_csv_village_city_af 

-- 城乡区域类型
-- 1.市区：[county为’区’结尾且class_code in (‘111’,’112’)]或[城区标签为“市中心”]标记为“市区” 
-- 2.县城：[county不为’区’结尾且class_code in (‘111’,’112’)]或[城区标签为“县中心”]标记为“县区” 
-- 3.镇区：剩下部分class_code in (‘121’,’122’,’123’) 
-- 4.乡村：剩下的class_code in (‘210’,’220’)
case when (SUBSTR(county, -1)='区' and class_code in ('111','112') ) or city_label='市中心'  then '市区' 
     when (SUBSTR(county, -1)!='区' and class_code in ('111','112') ) or city_label='县中心'  then '县区'  
     when class_code in  ('121','122','123')  then '镇区'  
     when class_code in  ('210','220')  then '乡村'
else '' end  as town_country_types




-----------------------------
-- 2024.01.10 修改
-- 是否进村收件
-- 2、判断丰巢AOi是否与收件AOi一致是否=’是’，若为’是’则填入1，否则往下走

-- 是否为乡镇上门收件
-- aoi_id与揽收坐标所在AOI 判断



---------------------------------------------------------------------------------------
-- 2024.01.24 变动内容
---------------------------------------------------------------------------------------
-- 揽收位置AOI区域	dm_gis.cms_aoi_sch/dm_tc_waybillinfo.aoi_area_aoi		
-- 1.利用揽收坐标所在AOI关联表dm_gis.cms_aoi_sch的aoi_id获取aoi_code
-- 2.利用aoi_code关联dm_tc_waybillinfo.aoi_area_aoi的aoi_id获取aoi_area_code
-- 揽收位置是否在地址所在AOI区域		判断揽收位置AOi区域=AOI区域？
-- 若为是则填是；
-- 若为否则填否；
-- 若两者为空则为无法判断。
drop table if exists dm_gis.tmp_village_src_aoi_area_res;
create table dm_gis.tmp_village_src_aoi_area_res stored as parquet  as 
select t0.aoi_id,t0.aoi_code,t1.aoi_area_code 
from (select aoi_id,aoi_code from dm_gis.cms_aoi_sch ) as t0 
left join ( select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi  ) as t1 
on t0.aoi_code=t1.aoi_id
;
