
-- 1）驿站收派件经纬度不为空：利用驿站收件经纬度跑接口  
create table dm_gis.village_dest_owncode_isnotnull_api_res_1123(
vilcode string comment '村编码',
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
match_res string COMMENT '是否',
dest_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "驿站编码不为空（派件）接口判断结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadiusApp"
int_sql="select vilcode,operate_longitude,operate_latitude,dest_dist_code as dist_code,inc_day from (
select 
t0.waybill_no,vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day 
from (
select waybill_no,vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnotnull 
where inc_day='$firstDay' and class_code in ('220','210') and vilcode is not null and vilcode<>'' and operate_longitude is not null and operate_longitude<>'' and operate_latitude is not null and operate_latitude<>''
) as t0 
left join (select waybill_no from dm_gis.village_dest_jp_res where inc_day='$firstDay' 
union all 
select waybill_no from dm_gis.village_dest_driver_track_res where inc_day='$firstDay' and  tc_res='1' ) as t1 
on t0.waybill_no=t1.waybill_no 
where  t1.waybill_no is null 
) as t
group by vilcode,operate_longitude,operate_latitude,dest_dist_code,inc_day "
out_table="dm_gis.village_dest_owncode_isnotnull_api_res_1123" 
pall_num=20000


-- 1）驿站收派件经纬度不为空：利用驿站收件经纬度跑接口
create table dm_gis.village_src_owncode_isnotnull_api_res_1123(
vilcode string comment '村编码',
operate_longitude string COMMENT '驿站经度',
operate_latitude string COMMENT '驿站纬度',
match_res string COMMENT '是否',
src_dist_code STRING COMMENT "分区城市代码"
)
COMMENT "驿站编码不为空（收件）接口判断结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



-- 
mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadiusApp"
int_sql="select vilcode,operate_longitude,operate_latitude,src_dist_code as dist_code,inc_day from (
select 
t0.waybill_no,vilcode,operate_longitude,operate_latitude,src_dist_code,inc_day 
from (
select waybill_no,vilcode,operate_longitude,operate_latitude,src_dist_code,inc_day from dm_gis.village_src_owncode_isnotnull 
where inc_day='$firstDay' and class_code in ('220','210') and vilcode is not null and vilcode<>'' and operate_longitude is not null and operate_longitude<>'' and operate_latitude is not null and operate_latitude<>''
) as t0 
left join (select waybill_no from dm_gis.village_src_js_res where inc_day='$firstDay' 
 ) as t1 
on t0.waybill_no=t1.waybill_no 
where  t1.waybill_no is null 
) as t 
group by vilcode,operate_longitude,operate_latitude,src_dist_code,inc_day "
out_table="dm_gis.village_src_owncode_isnotnull_api_res_1123" 
pall_num=20000





-- 建用于存跑接口判断是否进村上门的结果表（将补跑的结果存起来）
drop table if exists dm_gis.village_dest_owncode_isnull_res_1123;
create table dm_gis.village_dest_owncode_isnull_res_1123 (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
adcode_isin string comment 'adcode是否在adcode list中',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "驿站编码为空res（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table if exists dm_gis.village_src_owncode_isnull_res_1123;
create table dm_gis.village_src_owncode_isnull_res_1123 (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
adcode_isin string comment 'adcode是否在adcode list中',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空res（收件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;




-- top3 小哥轨迹 （派件） 去掉已经识别成功的部分
insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_top3 partition(inc_day) 
select waybill_no,zx,zy,dest_dist_code,inc_day
from (
select waybill_no,inc_day,dest_dist_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select t0.waybill_no,inc_day,dest_dist_code,zx,zy,abs(signin_tm-tm) as diff_tm 
from (select waybill_no,inc_day,dest_dist_code,zx,zy,signin_tm,tm from dm_gis.village_dest_owncode_isnull_waybill_xg_tmp where inc_day='$firstDay' ) as t0 
left join (select waybill_no from dm_gis.village_dest_owncode_isnull_res where inc_day='$firstDay' and adcode_isin='1'  ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
 ) as t  
) as t0 where t0.rn<=3 
;

-- top3 小哥轨迹 （收件） 去掉已经识别成功的部分
insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_top3 partition(inc_day) 
select waybill_no,zx,zy,src_dist_code,inc_day  
from (
select waybill_no,src_dist_code,inc_day ,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select t0.waybill_no,src_dist_code,inc_day ,zx,zy,abs(consigned_tm-tm) as diff_tm 
from (select waybill_no,inc_day,src_dist_code,zx,zy,consigned_tm,tm from dm_gis.village_src_owncode_isnull_waybill_xg_tmp where inc_day='$firstDay' ) as t0 
left join (select waybill_no from dm_gis.village_src_owncode_isnull_res where inc_day='$firstDay' and adcode_isin='1'  ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
) as t  
) as t0 where t0.rn<=3 
;

-- 需要再跑的小哥轨迹（派件收件一起）  注：top3不去掉top1的部分
insert overwrite table dm_gis.village_owncode_isnull_waybill_xg_top3 partition(inc_day) 
select t0.zx,t0.zy,t0.dist_code,t0.inc_day from (
select zx,zy,dist_code,inc_day
from (
select zx,zy,dest_dist_code as dist_code,inc_day
from (
select zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay' ) as a
union all 
select zx,zy,src_dist_code as dist_code,inc_day 
from (
select zx,zy,src_dist_code,inc_day from dm_gis.village_src_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay'  ) as b
) as c 
group by zx,zy,dist_code,inc_day 
) as t0 
;



mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageRadius500App"
int_sql="select zx,zy,dist_code,inc_day from dm_gis.village_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay'"
out_table="dm_gis.village_owncode_isnull_waybill_xg_top3_json" 
pall_num=15000



-- 小哥轨迹 运单 村编码list  还原 （派件）
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
dest_dist_code STRING COMMENT "分区城市代码"  
)
COMMENT "驿站编码为空小哥还原（派件）(top3)" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 小哥轨迹 运单 村编码list  还原 （收件）
drop table if exists dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy;
create table dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code array<string> comment 'adcode list',
src_dist_code STRING COMMENT "分区城市代码" 
)
COMMENT "驿站编码为空小哥还原（收件）(top3)" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

--  解析adcode list （派件收件一起） (shell脚本需要把\\换成\\\\)
drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode stored as parquet as 
select  zx,zy,get_json_object(ss.col,'$.objCode') as obj_code
from (select zx,zy,
split(regexp_replace(regexp_extract(json_str,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis.village_owncode_isnull_waybill_xg_top3_json where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
;

drop table if exists dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set;
create table dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set stored as parquet as 
select 
zx,zy,collect_set(obj_code) as obj_code_set 
from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode where obj_code is not null and obj_code<>'' group by zx,zy 
;

-- 还原 （派件）
insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,dest_dist_code,inc_day 
from (select waybill_no,zx,zy,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;

-- 还原 （收件）
insert overwrite table dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy partition(inc_day)  
select waybill_no,t0.zx,t0.zy,vil_code,src_dist_code,inc_day  
from (select waybill_no,zx,zy,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_waybill_xg_top3 where inc_day='$firstDay'  ) as t0 
left join ( select zx,zy,obj_code_set as vil_code from dm_gis.tmp_village_owncode_isnull_waybill_xg_top3_json_decode_set  ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;




-- top3结果整合top1结果 （派件）
insert overwrite table dm_gis.village_dest_owncode_isnull_res_1123 partition(inc_day)  
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day,row_number() over(partition by waybill_no order by adcode_isin desc) as rn 
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_res where inc_day='$firstDay' and adcode_isin='1' 
union all 
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,dest_dist_code,inc_day 
from (select waybill_no,class_code,vilcode,dest_dist_code,inc_day from dm_gis.village_dest_owncode_isnull_res where inc_day='$firstDay' and (adcode_isin is null or adcode_isin<>'1') ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_dest_owncode_isnull_waybill_xg_top3_hy where inc_day='$firstDay' ) as t1 
on t0.waybill_no=t1.waybill_no 
) as t 
) as tt where tt.rn=1
;

-- top3结果整合top1结果 （收件）
insert overwrite table dm_gis.village_src_owncode_isnull_res_1123 partition(inc_day) 
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day 
from (
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day,row_number() over(partition by waybill_no order by adcode_isin desc) as rn 
from (    
select waybill_no,class_code,vilcode,zx,zy,vil_code,adcode_isin,src_dist_code,inc_day from dm_gis.village_src_owncode_isnull_res where inc_day='$firstDay' and adcode_isin='1' 
union all 
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,if(array_contains(vil_code,t0.vilcode),1,0) as adcode_isin,src_dist_code,inc_day   
from (select waybill_no,class_code,vilcode,src_dist_code,inc_day  from dm_gis.village_src_owncode_isnull_res where inc_day='$firstDay' and (adcode_isin is null or adcode_isin<>'1') ) as t0 
left join (select waybill_no,zx,zy,vil_code from dm_gis.village_src_owncode_isnull_waybill_xg_top3_hy where inc_day='$firstDay'   ) as t1 
on t0.waybill_no=t1.waybill_no 
) as t 
) as tt where tt.rn=1
;




-- 结果表
CREATE TABLE `dm_gis.village_dest_kdsm_res_1123`(
`dest_hq_code` string COMMENT '大区代码',
`dest_area_code` string COMMENT '地区代码',
`area_name` string COMMENT '地区名称',
`dest_zone_code` string COMMENT '网点代码',
`dept_name` string COMMENT '网点名称',
`waybill_no` string COMMENT '单号',
`deliver_emp_code` string COMMENT '派件人工号',
`real_product_code` string COMMENT '产品名称',
`meterage_weight_qty` string COMMENT '计费重量',
`pay_cust_type` string COMMENT '付费客户类型',
`service_prod_code` string COMMENT '增值服务代码',
`all_fee_rmb` string COMMENT '总收入（rmb）',
`freight_monthly_acct_code` string COMMENT '月结账号',
`is_yj` string COMMENT '是否月结',
`aoi_code` string COMMENT 'AOI编码',
`aoi_name` string COMMENT 'AOI名称',
`aoi_type_name` string COMMENT 'aoi类型名称',
`aoi_area_code` string COMMENT 'AOI区域',
`province` string COMMENT '省',
`city` string COMMENT '市/市辖区',
`county` string COMMENT '区/县',
`town` string COMMENT '镇/乡',
`town_adcode` string COMMENT '镇adcode',
`vil_name` string COMMENT '行政村/社区',
`vil_code` string COMMENT '村adcode',
`class_code` string COMMENT '城乡分类代码',
`own_code` string COMMENT '驿站编码',
`is_jcpj` string COMMENT '是否进村派件',
`is_jxzpj` string COMMENT '是否为乡镇上门派件',
`yd_type` string COMMENT '运单类型',
`distance` string COMMENT '收件地址到派件网点的距离',
`wd_type` string COMMENT '网点类型',
`dest_dist_code` string COMMENT '分区城市代码',
`operate_longitude` string COMMENT '驿站经度',
`operate_latitude` string COMMENT '驿站纬度',
`signin_tm` string COMMENT '派送时间',
`add_fee` string COMMENT '乡村达收入',
`is_jp` string COMMENT '是否集派',
`is_tcj` string COMMENT '是否同城件',
`lonlat_tag` string COMMENT '出入库标签')
COMMENT '行政村快递上门（派件）'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
ROW FORMAT SERDE
'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
;

-- 2023.11.21  补贴标签(subsidy_type)  补贴更新(subsidy)
alter table dm_gis.village_dest_kdsm_res_1123 add columns(subsidy_type string comment'补贴标签') cascade;
alter table dm_gis.village_dest_kdsm_res_1123 add columns(subsidy string comment'补贴更新') cascade;


CREATE TABLE `dm_gis.village_src_kdsm_res_1123`(
`src_hq_code` string COMMENT '大区代码',
`src_area_code` string COMMENT '地区代码',
`area_name` string COMMENT '地区名称',
`source_zone_code` string COMMENT '网点代码',
`dept_name` string COMMENT '网点名称',
`waybill_no` string COMMENT '单号',
`consignee_emp_code` string COMMENT '派件人工号',
`real_product_code` string COMMENT '产品名称',
`meterage_weight_qty` string COMMENT '计费重量',
`pay_cust_type` string COMMENT '付费客户类型',
`service_prod_code` string COMMENT '增值服务代码',
`all_fee_rmb` string COMMENT '总收入（rmb）',
`freight_monthly_acct_code` string COMMENT '月结账号',
`is_yj` string COMMENT '是否月结',
`aoi_code` string COMMENT 'AOI编码',
`aoi_name` string COMMENT 'AOI名称',
`aoi_type_name` string COMMENT 'aoi类型名称',
`aoi_area_code` string COMMENT 'AOI区域',
`province` string COMMENT '省',
`city` string COMMENT '市/市辖区',
`county` string COMMENT '区/县',
`town` string COMMENT '镇/乡',
`town_adcode` string COMMENT '镇adcode',
`vil_name` string COMMENT '行政村/社区',
`vil_code` string COMMENT '村adcode',
`class_code` string COMMENT '城乡分类代码',
`own_code` string COMMENT '驿站编码',
`is_jcpj` string COMMENT '是否进村派件',
`is_jxzpj` string COMMENT '是否为乡镇上门派件',
`yd_type` string COMMENT '运单类型',
`wd_type` string COMMENT '网点类型',
`src_dist_code` string COMMENT '分区城市代码',
`tt_fee_zh_all_fee` string COMMENT '折后收入',
`distance` string COMMENT '寄件地址到收件网点的距离',
`operate_longitude` string COMMENT '驿站经度',
`operate_latitude` string COMMENT '驿站纬度',
`consigned_tm` string COMMENT '揽收时间',
`is_js` string COMMENT '是否集收',
`lonlat_tag` string COMMENT '出入库标签')
COMMENT '行政村快递上门（收件）'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
ROW FORMAT SERDE
'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
;

-- 2023.11.21   补贴标签(subsidy_type)  补贴更新(subsidy)
alter table dm_gis.village_src_kdsm_res_1123 add columns(subsidy_type string comment'补贴标签') cascade;
alter table dm_gis.village_src_kdsm_res_1123 add columns(subsidy string comment'补贴更新') cascade;



insert overwrite table dm_gis.village_dest_kdsm_res_1123 partition(inc_day='$firstDay') 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
case when (class_code in ('220','210')) or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type ,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag,subsidy_type,subsidy  
from (select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,t0.waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,t0.class_code,
t0.own_code,
case when is_jcpj='1' or t3.adcode_isin='1' or t8.match_res='1' then '1' else '0' end as is_jcpj,
is_jxzpj,
distance,
wd_type,t0.dest_dist_code,t0.operate_longitude,t0.operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,t0.lonlat_tag,subsidy_type,subsidy,
t0.inc_day 
from (select dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,
is_jcpj,
is_jxzpj,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag,subsidy_type,subsidy,
inc_day  from dm_gis.village_dest_kdsm_res 
where inc_day='$firstDay' ) as t0
left join (select waybill_no,class_code,vilcode,inc_day,dest_dist_code,zx,zy,adcode_isin  
from dm_gis.village_dest_owncode_isnull_res_1123 where inc_day='$firstDay'   ) as t3 
on t0.waybill_no=t3.waybill_no 
left join (select waybill_no,own_code,dest_dist_code,vilcode,operate_longitude,operate_latitude,lonlat_tag from dm_gis.village_dest_owncode_isnotnull where inc_day='$firstDay'  ) as t7 
on t0.waybill_no=t7.waybill_no 
left join (select dest_dist_code,vilcode,operate_longitude,operate_latitude,match_res from dm_gis.village_dest_owncode_isnotnull_api_res_1123 where inc_day='$firstDay' ) as t8 
on t7.dest_dist_code=t8.dest_dist_code and t7.vilcode=t8.vilcode and t7.operate_longitude=t8.operate_longitude and t7.operate_latitude=t8.operate_latitude 

) as t 
;


insert overwrite table dm_gis.village_dest_kdsm_res partition(inc_day='$firstDay') 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag,subsidy_type,subsidy 
from dm_gis.village_dest_kdsm_res_1123 
where inc_day='$firstDay'
;


-- 
insert overwrite table  dm_gis.village_src_kdsm_res_1123 partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,
is_jcpj,
is_jxzpj,
case when (class_code in ('220','210')) or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220' or class_code!='210') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type ,
wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,subsidy_type,subsidy  
from (select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,t0.class_code,
t0.own_code,
case when is_jcpj='1' or t3.adcode_isin='1' or t8.match_res='1' then '1' else '0' end as is_jcpj,
is_jxzpj,
wd_type,t0.src_dist_code,tt_fee_zh_all_fee,distance,t0.operate_longitude,t0.operate_latitude,consigned_tm,
is_js,t0.lonlat_tag,subsidy_type,subsidy,
t0.inc_day
from (select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,subsidy_type,subsidy,
inc_day
from dm_gis.village_src_kdsm_res 
where inc_day='$firstDay' ) as t0 
left join (select waybill_no,class_code,vilcode,src_dist_code,inc_day ,zx,zy,adcode_isin  
from dm_gis.village_src_owncode_isnull_res_1123 where inc_day='$firstDay'   ) as t3 
on t0.waybill_no=t3.waybill_no 
left join (select waybill_no,own_code,src_dist_code,vilcode,operate_longitude,operate_latitude,lonlat_tag from dm_gis.village_src_owncode_isnotnull where inc_day='$firstDay'  ) as t7 
on t0.waybill_no=t7.waybill_no 
left join (select src_dist_code,vilcode,operate_longitude,operate_latitude,match_res from dm_gis.village_src_owncode_isnotnull_api_res_1123 where inc_day='$firstDay' ) as t8 
on t7.src_dist_code=t8.src_dist_code and t7.vilcode=t8.vilcode and t7.operate_longitude=t8.operate_longitude and t7.operate_latitude=t8.operate_latitude 

) as t
;


insert overwrite table  dm_gis.village_src_kdsm_res partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,waybill_no,consignee_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,
is_jcpj,
is_jxzpj,
yd_type,
wd_type,src_dist_code,tt_fee_zh_all_fee,distance,operate_longitude,operate_latitude,consigned_tm,
is_js,lonlat_tag,subsidy_type,subsidy  
from dm_gis.village_src_kdsm_res_1123 
where inc_day='$firstDay'
;


























--  
-- dm_gis.village_dest_kdsm_res
CREATE TABLE `dm_gis.tmp_village_dest_kdsm_res_1127`(
`dest_hq_code` string COMMENT '大区代码',
`dest_area_code` string COMMENT '地区代码',
`area_name` string COMMENT '地区名称',
`dest_zone_code` string COMMENT '网点代码',
`dept_name` string COMMENT '网点名称',
`waybill_no` string COMMENT '单号',
`deliver_emp_code` string COMMENT '派件人工号',
`real_product_code` string COMMENT '产品名称',
`meterage_weight_qty` string COMMENT '计费重量',
`pay_cust_type` string COMMENT '付费客户类型',
`service_prod_code` string COMMENT '增值服务代码',
`all_fee_rmb` string COMMENT '总收入（rmb）',
`freight_monthly_acct_code` string COMMENT '月结账号',
`is_yj` string COMMENT '是否月结',
`aoi_code` string COMMENT 'AOI编码',
`aoi_name` string COMMENT 'AOI名称',
`aoi_type_name` string COMMENT 'aoi类型名称',
`aoi_area_code` string COMMENT 'AOI区域',
`province` string COMMENT '省',
`city` string COMMENT '市/市辖区',
`county` string COMMENT '区/县',
`town` string COMMENT '镇/乡',
`town_adcode` string COMMENT '镇adcode',
`vil_name` string COMMENT '行政村/社区',
`vil_code` string COMMENT '村adcode',
`class_code` string COMMENT '城乡分类代码',
`own_code` string COMMENT '驿站编码',
`is_jcpj` string COMMENT '是否进村派件',
`is_jxzpj` string COMMENT '是否为乡镇上门派件',
`yd_type` string COMMENT '运单类型',
`distance` string COMMENT '收件地址到派件网点的距离',
`wd_type` string COMMENT '网点类型',
`dest_dist_code` string COMMENT '分区城市代码',
`operate_longitude` string COMMENT '驿站经度',
`operate_latitude` string COMMENT '驿站纬度',
`signin_tm` string COMMENT '派送时间',
`add_fee` string COMMENT '乡村达收入',
`is_jp` string COMMENT '是否集派',
`is_tcj` string COMMENT '是否同城件',
`lonlat_tag` string COMMENT '出入库标签')
COMMENT '行政村快递上门（派件）'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
ROW FORMAT SERDE
'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
STORED AS INPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat'
OUTPUTFORMAT
'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
;


insert overwrite table dm_gis.tmp_village_dest_kdsm_res_1127 partition(inc_day='$firstDay') 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,
own_code,is_jcpj,is_jxzpj,
yd_type,
distance,
wd_type,dest_dist_code,operate_longitude,operate_latitude,signin_tm,add_fee,
is_jp,is_tcj,lonlat_tag 
from dm_gis.village_dest_kdsm_res  
where inc_day='$firstDay' 
and add_fee > 0 
and (is_jcpj = '1' or is_jxzpj = '1');
;