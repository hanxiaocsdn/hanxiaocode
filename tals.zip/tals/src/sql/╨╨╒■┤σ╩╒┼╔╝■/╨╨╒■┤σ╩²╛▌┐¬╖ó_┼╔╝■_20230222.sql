-- 
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- 需求： id: 1585280  【偏远乡村派件上门】快递进村收派件数据统计_V2.0 
-- @author 张小琼 （01416344）
-- Created on 2023-02-15
-- 任务信息： 668258	行政村收派件_20230222
-- 

-- 1、数据准备

-- 1.1 运单
-- 源：dm_gis.tt_waybill_hook  派件
-- dm_gis.village_tt_waybill_hook
create table dm_gis.village_tt_waybill_hook(
waybill_no string comment '运单号',
signin_tm string comment '收件时间',
dest_hq_code string comment '目的地经营本部（大区）',
dest_area_code string comment '目的地区部（地区代码）',
dest_zone_code string comment '目的地网点代码（网点代码）',
deliver_emp_code string comment '派件员',
real_product_code string comment '产品代码',
meterage_weight_qty string comment '计费重量',
pay_cust_type string comment '付费客户类型',
service_prod_code string comment '增值服务代码',
all_fee_rmb string comment '总收入',
freight_monthly_acct_code string comment '月结账号',
aoi_id string comment 'aoi id',
aoi_code string comment 'aoi编码',
aoi_name string comment 'aoi名称',
aoi_type_name string comment 'aoi类型名称',
dest_county string comment '目的地区/县/镇',
consignee_addr  string comment '收件地址' 
)
COMMENT "行政村运单（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;

insert overwrite table  dm_gis.village_tt_waybill_hook partition(inc_day,dest_dist_code) 
select waybill_no,signin_tm,dest_hq_code,dest_area_code,dest_zone_code,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
dest_county,consignee_addr,
inc_day,dest_dist_code  
from dm_gis.tt_waybill_hook where inc_day='20230219' and  dest_dist_code in ('371') limit 1000
;

-- 1.2 小哥轨迹 dm_gis.esg_gis_loc_trajectory
-- drop table if exists dm_gis.tmp_village_henan_esg_gis_1006;
-- create table  dm_gis.tmp_village_henan_esg_gis_1006  as 
-- select un,inc_day,tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20230219'
-- ;

-- 1.3 网点站点数据 dim.dim_department_hist (新表 dim.dim_dept_info_df）
-- drop table if exists dm_gis.tmp_village_henan_department_1006;
-- create table dm_gis.tmp_village_henan_department_1006  as 
-- select dept_code,area_name,dept_name,longitude,latitude 
-- from (
-- select dept_code,area_name,dept_name,longitude,latitude,row_number() over(partition by dept_code order by inc_day desc)  as rn 
-- from (select area_name,dept_code,dept_name,longitude,latitude,inc_day  
-- from dim.dim_department_hist where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') ) as a 
-- ) as b where b.rn=1
-- ;

-- 1.4 aoi和aoi区域对应关系表 dm_tc_waybillinfo.aoi_area_aoi 
-- select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi 


-- 1.5 行政村查询接口日志数据 dm_gis.village_log_flink_res
-- 地址和city code与表dm_gis.village_log_flink_res（inc_day的最近7天）的 p_address和p_city_code进行匹配,都命中则获取 ，否则通过行政村查询接口查询，获取对应数据
-- 
drop table if exists dm_gis.tmp_village_village_log_flink_res;
create table dm_gis.tmp_village_village_log_flink_res  as 
select p_address,p_city_code,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance
from (
select p_address,p_city_code,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,
row_number() over( partition by p_address,p_city_code order by r_distance desc ) as rn  
from dm_gis.village_log_flink_res where inc_day>=date_format(date_add(current_date(),-7),'yyyyMMdd') and inc_day<date_format(current_date(),'yyyyMMdd') and r_status='0' 
) as t where t.rn=1 
;

-- 1.6 网点类型 dim.dim_dept_info_df
-- 利用网点代码与表dim.dim_dept_info_df，where dept_type_code='DB05-DLD'的dept_code做匹配，命中则填入‘代理’，不命中则填入‘自营’
-- select dept_code from dim.dim_dept_info_df where inc_day='' and dept_type_code='DB05-DLD' 

-- 1.7 ods_yjy.yjy_mailno_kb
-- 利用运单号和日期与表ods_yjy.yjy_mailno_kb（order_state=‘已出库’）中的 mailno和inc_day匹配，命中则返回own_code，否则为空

-- select mailno,own_code from ods_yjy.yjy_mailno_kb where inc_day='20230219' and order_state='已出库' ;



-- 2 获取5级地址
create table dm_gis.village_dest_addr_decode(
waybill_no string comment '运单号',
consignee_addr string comment '收件地址',
province string comment '',
city string comment '',
county string comment '',
town string comment '',
vilname string comment '村级名称',
vilcode string comment '村级编码',
town_adcode string comment '乡镇编码',
class_code string comment '城乡分类代码',
distance string comment '到网点距离'
)
COMMENT "5级地址（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 2.1.1 从历史解析日志中获取 
insert overwrite table  dm_gis.village_dest_addr_decode partition(inc_day,dest_dist_code) 
select t1.waybill_no,t1.consignee_addr,r_province,r_city,r_county,r_town,r_vilname,r_vilcode,r_town_adcode,r_class_code,r_distance,
t1.inc_day,t1.dest_dist_code  
from dm_gis.tmp_village_village_log_flink_res as t0 
left join ( select waybill_no,inc_day,dest_dist_code,consignee_addr from dm_gis.village_tt_waybill_hook where inc_day='20230219' and dest_dist_code in ('371')  ) as t1 
on t0.p_city_code=t1.dest_dist_code and t0.p_address=t1.consignee_addr  
where t1.waybill_no is not null 
;

-- 2.1.2 调接口获取
-- http://gis-gw.intsit.sfdc.com.cn:9080/village/


-- 
mainClass="com.sf.gis.scala.tals.app.VillageAddrLevel5AddrDestApp"
int_sql="
select t0.waybill_no,t0.inc_day,t0.dest_dist_code as yd_citycode,t0.consignee_addr as yd_addr  
from ( select waybill_no,inc_day,dest_dist_code,consignee_addr from dm_gis.village_tt_waybill_hook where inc_day='20230219' and dest_dist_code in ('371') ) as t0 
left join ( select waybill_no from dm_gis.village_dest_addr_decode where inc_day='20230219' and dest_dist_code in ('371') group by waybill_no ) as t1 
on t0.waybill_no=t1.waybill_no 
where t1.waybill_no is null
"
out_table="dm_gis.village_dest_addr_decode"
pall_num=20000

-- 2.1.3 运单5级地址去重
insert overwrite table  dm_gis.village_dest_addr_decode partition(inc_day,dest_dist_code) 
select waybill_no,consignee_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,inc_day,dest_dist_code 
from (select waybill_no,consignee_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,inc_day,dest_dist_code,
row_number() over(partition by waybill_no,inc_day,dest_dist_code order by vilcode desc) as rn from dm_gis.village_dest_addr_decode where inc_day='20230219' and dest_dist_code in ('371')
) as t where t.rn=1 
;


-- 2.2 是否进村派件
-- 当城乡分类代码不为220时，填入否；当城乡分类代码=220时，判断驿站编码，是否为空.
-- 1.不为空,则利用驿站编码和村adcode与表 （inc_day选最新）ods_yjy.station_info_d 的own_code和village_code匹配，都命中则为是，否则为否
-- 2.为空,否则用小哥经纬度到杨俊提个的坐标查询行政村服务获取村adcode与前面获取的村adcode进行匹配，命中则为是，否则为否


-- 2.2.1 驿站编码 不为空 (使用时用class_code='220'筛选)
drop table if exists dm_gis.village_dest_owncode_isnotnull;
create table dm_gis.village_dest_owncode_isnotnull(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码'
)
COMMENT "驿站编码不为空（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnotnull partition(inc_day,dest_dist_code) 
select 
waybill_no,class_code,vilcode,own_code,inc_day,dest_dist_code  
from (select mailno,own_code from ods_yjy.yjy_mailno_kb where inc_day='20230219' and type='派件') as t0 
left join (select waybill_no,class_code,vilcode,inc_day,dest_dist_code from dm_gis.village_dest_addr_decode where inc_day='20230219' and dest_dist_code in ('371') ) as t1 
on t0.mailno=t1.waybill_no 
where t1.waybill_no is not null
;

-- 2.2.1.1 own_code和village_code匹配是否命中
drop table if exists dm_gis.village_dest_owncode_isnotnull_res;
create table dm_gis.village_dest_owncode_isnotnull_res(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
own_code string comment '驿站编码',
own_code_check  string comment '',
village_code  string comment ''
)
COMMENT "驿站编码不为空（派件）结果" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnotnull_res partition(inc_day,dest_dist_code) 
select waybill_no,class_code,vilcode,t0.own_code,t1.own_code,village_code,inc_day,dest_dist_code 
from (select waybill_no,class_code,vilcode,own_code,inc_day,dest_dist_code  from dm_gis.village_dest_owncode_isnotnull where inc_day='20230219' and dest_dist_code in ('371') and class_code='220' ) as t0 
left join ( select own_code,village_code from ods_yjy.station_info_d where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') and village_code<>'' group by own_code,village_code ) as t1 
on t0.own_code=t1.own_code and t0.vilcode=t1.village_code 
;


-- 2.2.2 驿站编码 为空
drop table if exists dm_gis.village_dest_owncode_isnull;
create table dm_gis.village_dest_owncode_isnull(
waybill_no string comment '运单号',
class_code string comment '城乡分类代码',
vilcode string comment '村编码' 
)
COMMENT "驿站编码为空（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_owncode_isnull partition(inc_day,dest_dist_code) 
select t0.waybill_no,class_code,vilcode,inc_day,dest_dist_code 
from ( select waybill_no,class_code,vilcode,inc_day,dest_dist_code from dm_gis.village_dest_addr_decode where inc_day='20230219' and dest_dist_code in ('371') and class_code='220' ) as t0 
left join (select waybill_no from dm_gis.village_dest_owncode_isnotnull where inc_day='20230219' and dest_dist_code in ('371') and class_code='220' group by waybill_no) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is null 
;


-- 2.2.2.1 运单关联获取signin_tm,deliver_emp_code
drop table if exists dm_gis.village_dest_owncode_isnull_waybill;
create table dm_gis.village_dest_owncode_isnull_waybill(
waybill_no string comment '运单号',
signin_tm string comment '收件时间',
deliver_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码' 
)
COMMENT "运单关联获取signin_tm,deliver_emp_code（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill partition(inc_day,dest_dist_code) 
select 
t0.waybill_no,t0.signin_tm,t0.deliver_emp_code,
t1.class_code,t1.vilcode,
t1.inc_day,t1.dest_dist_code 
from ( select waybill_no,signin_tm,deliver_emp_code,inc_day,dest_dist_code  from dm_gis.village_tt_waybill_hook where inc_day='20230219' and dest_dist_code in ('371') ) as t0 
left join (select waybill_no,class_code,vilcode,inc_day,dest_dist_code from dm_gis.village_dest_owncode_isnull where inc_day='20230219' and dest_dist_code in ('371') ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 2.2.2.2 运单关联小哥轨迹 
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_tmp;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_tmp(
waybill_no string comment '运单号',
deliver_emp_code string comment '小哥编码',
class_code string comment '城乡分类代码',
vilcode string comment '村编码',
zx string comment '经度',
zy string comment '纬度',
signin_tm string comment '收件时间',
tm string comment '小哥轨迹时间' 
)
COMMENT "运单关联小哥轨迹（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_tmp partition(inc_day,dest_dist_code) 
select 
waybill_no,deliver_emp_code,class_code,vilcode,zx,zy,signin_tm,tm,t1.inc_day,dest_dist_code  
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20230219' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(signin_tm) as signin_tm,deliver_emp_code,class_code,vilcode,inc_day,dest_dist_code 
from dm_gis.village_dest_owncode_isnull_waybill where inc_day='20230219' and dest_dist_code in ('371') and signin_tm<>'' ) as t1 
on t0.un=t1.deliver_emp_code
where signin_tm-60*5<=tm and signin_tm+60*5>=tm
;

-- 2.2.2.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg;
create table dm_gis.village_dest_owncode_isnull_waybill_xg(
waybill_no string comment '运单号',
zx string comment '经度',
zy string comment '纬度' 
)
COMMENT "取最靠近收件日期的轨迹点（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg partition(inc_day,dest_dist_code) 
select waybill_no,zx,zy,inc_day,dest_dist_code 
from (
select waybill_no,inc_day,dest_dist_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,inc_day,dest_dist_code,zx,zy,abs(signin_tm-tm) as diff_tm from dm_gis.village_dest_owncode_isnull_waybill_xg_tmp where inc_day='20230219' and dest_dist_code in ('371') ) as t  
) as t0 where t0.rn=1 
;

-- 2.2.2.4 调坐标查询行政村接口 
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_res;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_res (
zx string comment '',
zy string comment '',
vil_code string comment '',
vil_name string comment '',
guid string comment '' 
)
COMMENT "跑经纬坐标查询行政村（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

mainClass="com.sf.gis.scala.tals.app.VillageLatLngVillageApp"
int_sql="select zx,zy,inc_day,dest_dist_code from dm_gis.village_dest_owncode_isnull_waybill_xg where inc_day='20230219' and dest_dist_code in ('371') group by zx,zy,inc_day,dest_dist_code"
out_table="dm_gis.village_dest_owncode_isnull_waybill_xg_res" 
pall_num=10000


-- 2.2.2.4  驿站编码 为空 res 
drop table if exists dm_gis.village_dest_owncode_isnull_waybill_xg_hy;
create table dm_gis.village_dest_owncode_isnull_waybill_xg_hy (
waybill_no string comment '',
zx string comment '',
zy string comment '',
vil_code string comment '',
vil_name string comment '',
guid string comment '' 
)
COMMENT "驿站编码为空小哥还原（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.village_dest_owncode_isnull_waybill_xg_hy partition(inc_day,dest_dist_code)  
select waybill_no,t0.zx,t0.zy,vil_code,vil_name,guid,inc_day,dest_dist_code from (select waybill_no,zx,zy,inc_day,dest_dist_code from dm_gis.village_dest_owncode_isnull_waybill_xg where inc_day='20230219' and dest_dist_code in ('371') ) as t0 
left join ( select zx,zy,vil_code,vil_name,guid from dm_gis.village_dest_owncode_isnull_waybill_xg_res where inc_day='20230219' and dest_dist_code in ('371') ) as t1 
on t0.zx=t1.zx and t0.zy=t1.zy 
;

-- 
drop table if exists dm_gis.village_dest_owncode_isnull_res;
create table dm_gis.village_dest_owncode_isnull_res (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
vil_code string comment '',
vil_name string comment '',
guid string comment '' 
)
COMMENT "驿站编码为空res（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_owncode_isnull_res partition(inc_day,dest_dist_code)  
select t0.waybill_no,t0.class_code,t0.vilcode,zx,zy,vil_code,vil_name,guid,inc_day,dest_dist_code  
from (select waybill_no,class_code,vilcode,inc_day,dest_dist_code from dm_gis.village_dest_owncode_isnull where inc_day='20230219' and dest_dist_code in ('371') ) as t0 
left join (select waybill_no,zx,zy,vil_code,vil_name,guid from dm_gis.village_dest_owncode_isnull_waybill_xg_hy where inc_day='20230219' and dest_dist_code in ('371')  ) as t1 
on t0.waybill_no=t1.waybill_no
;


-- 3 是否进乡镇上门
-- 城乡代码为220或是否进村上门为‘是’标记为‘否’；对其他的，用小哥轨迹坐标调坐标查询aoi接口（参数外延200m距离）,判断是否为乡镇上门，是：接口返回aoicode中有运单aoicode，否：接口返回aoicode中无运单aoicode

-- 3.1 运单关联获取 signin_tm,deliver_emp_code,aoi_id,aoi_code
drop table if exists dm_gis.village_dest_classcode_waybill;
create table dm_gis.village_dest_classcode_waybill (
waybill_no string comment '',
class_code string comment '',
vilcode string comment '',
signin_tm string comment '',
deliver_emp_code string comment '',
aoi_id string comment '',
aoi_code string comment ''
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_dest_classcode_waybill partition(inc_day,dest_dist_code)  
select t1.waybill_no,t1.class_code,t1.vilcode,t0.signin_tm,t0.deliver_emp_code,aoi_id,aoi_code,t1.inc_day,t1.dest_dist_code  
from ( select waybill_no,signin_tm,deliver_emp_code,aoi_id,aoi_code,inc_day,dest_dist_code  from dm_gis.village_tt_waybill_hook where inc_day='20230219' and dest_dist_code in ('371')  ) as t0 
left join (select waybill_no,class_code,vilcode,inc_day,dest_dist_code from dm_gis.village_dest_addr_decode where inc_day='20230219' and dest_dist_code in ('371') and (class_code is null or class_code<>'220' ) ) as t1 
on t0.waybill_no=t1.waybill_no
where t1.waybill_no is not null 
;

-- 3.2 运单关联小哥轨迹  
drop table if exists dm_gis.village_dest_classcode_waybill_xg_tmp;
create table dm_gis.village_dest_classcode_waybill_xg_tmp (
waybill_no string comment '',
aoi_id string comment '',
aoi_code string comment '',
class_code string comment '',
vilcode string comment '',
zx string comment '',
zy string comment '',
signin_tm string comment '',
tm string comment '' 
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_classcode_waybill_xg_tmp partition(inc_day,dest_dist_code)  
select 
waybill_no,aoi_id,aoi_code,class_code,vilcode,zx,zy,signin_tm,tm,t1.inc_day,dest_dist_code  
from ( select un,inc_day,cast(tm as int) as tm,zx,zy from dm_gis.esg_gis_loc_trajectory where inc_day='20230219' and un<>'' and tm<>'' and zx<>'' and zy<>'' ) as t0 
left join ( select waybill_no,unix_timestamp(signin_tm) as signin_tm,deliver_emp_code,aoi_id,aoi_code,class_code,vilcode,inc_day,dest_dist_code 
from dm_gis.village_dest_classcode_waybill where inc_day='20230219' and dest_dist_code in ('371') and deliver_emp_code<>'' and signin_tm<>'' ) as t1 
on t0.un=t1.deliver_emp_code
where signin_tm-60*5<=tm and signin_tm+60*5>=tm
;

-- 3.3 取最靠近收件日期的轨迹点 
drop table if exists dm_gis.village_dest_classcode_waybill_xg;
create table dm_gis.village_dest_classcode_waybill_xg (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '' 
)
COMMENT "运单关联获取（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.village_dest_classcode_waybill_xg partition(inc_day,dest_dist_code)  
select waybill_no,aoi_code,zx,zy,inc_day,dest_dist_code 
from (
select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,row_number() over( partition by waybill_no order by diff_tm asc ) as rn 
from ( select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,abs(signin_tm-tm) as diff_tm from dm_gis.village_dest_classcode_waybill_xg_tmp where inc_day='20230219'  and dest_dist_code in ('371')  ) as t  
) as t0 where t0.rn=1 
;

-- 3.4 调坐标查询aoi接口
drop table if exists dm_gis.village_dest_classcode_waybill_xg_res;
create table dm_gis.village_dest_classcode_waybill_xg_res (
aoi_code string comment '',
lgt string comment '',
lat string comment '',
matchres string comment ''
)
COMMENT "跑经纬坐标查询aoi（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


mainClass="com.sf.gis.scala.tals.app.VillageLatLngAoiApp"
int_sql="select aoi_code,zx,zy,inc_day,dest_dist_code from dm_gis.village_dest_classcode_waybill_xg where inc_day='20230219'  and dest_dist_code in ('371')  and aoi_code<>'' group by aoi_code,zx,zy,inc_day,dest_dist_code"
out_table="dm_gis.village_dest_classcode_waybill_xg_res" 
pall_num=100000


-- 3.5 能关联小哥轨迹的运单查询aoi后判断是否上门的结果
drop table if exists dm_gis.village_dest_classcode_waybill_xg_aoi_res;
create table dm_gis.village_dest_classcode_waybill_xg_aoi_res (
waybill_no string comment '',
aoi_code string comment '',
zx string comment '',
zy string comment '',
matchres string comment ''
)
COMMENT "跑经纬坐标查询aoi（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码") 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis.village_dest_classcode_waybill_xg_aoi_res partition(inc_day,dest_dist_code)  
select waybill_no,t0.aoi_code,zx,zy,matchres,inc_day,dest_dist_code from (select waybill_no,aoi_code,zx,zy,inc_day,dest_dist_code from dm_gis.village_dest_classcode_waybill_xg where inc_day='20230219'  and dest_dist_code in ('371') ) as t0 
left join (select aoi_code,lgt,lat,matchres from dm_gis.village_dest_classcode_waybill_xg_res where inc_day='20230219'  and dest_dist_code in ('371') ) as t1 
on t0.aoi_code=t1.aoi_code and t0.zx=t1.lgt and t0.zy=t1.lat 
;
 




-- 4 快递上门结果表 (派件)
create table dm_gis.village_dest_kdsm_res (
dest_hq_code	string comment '大区代码',
dest_area_code	string comment '地区代码',
area_name	string comment '地区名称',
dest_zone_code	string comment '网点代码',
dept_name	string comment '网点名称',
waybill_no	string comment '单号',
deliver_emp_code	string comment '派件人工号',
real_product_code	string comment '产品名称',
meterage_weight_qty	string comment '计费重量',
pay_cust_type	string comment '付费客户类型',
service_prod_code	string comment '增值服务代码',
all_fee_rmb	string comment '总收入（rmb）',
freight_monthly_acct_code	string comment '月结账号',
is_yj	string comment '是否月结',
aoi_code	string comment 'AOI编码',
aoi_name	string comment 'AOI名称',
aoi_type_name	string comment 'aoi类型名称',
aoi_area_code	string comment 'AOI区域',
province	string comment '省',
city	string comment '市/市辖区',
county	string comment '区/县',
town	string comment '镇/乡',
town_adcode	string comment '镇adcode',
vil_name	string comment '行政村/社区',
vil_code	string comment '村adcode',
class_code	string comment '城乡分类代码',
own_code	string comment '驿站编码',
is_jcpj	string comment '是否进村派件',
is_jxzpj	string comment '是否为乡镇上门派件',
yd_type	string comment '运单类型',
distance	string comment '收件地址到派件网点的距离',
wd_type	string comment '网点类型' 	
)
COMMENT "行政村快递上门（派件）" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code STRING COMMENT "分区城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;




insert overwrite table  dm_gis.village_dest_kdsm_res partition(inc_day,dest_dist_code) 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vilname,vilcode,class_code,
own_code,is_jcpj,is_jxzpj,
case when (class_code='220') or (is_jcpj='1')  then '行政村' 
when (class_code is null or class_code!='220') and (is_jcpj!='1') and  town regexp '乡|镇|牧场|农场' then '乡镇' 
when (class_code is null or class_code!='220') and (is_jcpj!='1') and  town regexp '街道|区' then '城区' 
 else '' end as  yd_type ,
distance,
wd_type,
inc_day,dest_dist_code
from (
select 
dest_hq_code,dest_area_code,t5.area_name,dest_zone_code,t5.dept_name,t0.waybill_no,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,
case when freight_monthly_acct_code<>'' then '1' else '0' end as is_yj,
t0.aoi_code,t0.aoi_name,aoi_type_name,t6.aoi_area_code,
t1.province,t1.city,t1.county,t1.town,t1.town_adcode,t1.vilname,t1.vilcode,t1.class_code,
t7.own_code,
case when t2.own_code_check is not null or (t3.vil_code is not null and t3.vilcode=t3.vil_code) then '1' else '0' end as is_jcpj,
case when t4.matchres='1'  then '1' else '0' end as is_jxzpj,
distance,
case when t5.dept_type_code='DB05-DLD' then '代理' else '自营' end as wd_type,
t0.inc_day,t0.dest_dist_code
from (
select waybill_no,signin_tm,dest_hq_code,dest_area_code,dest_zone_code,deliver_emp_code,real_product_code,
meterage_weight_qty,pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,aoi_id,aoi_code,aoi_name,aoi_type_name,
dest_county,consignee_addr,
inc_day,dest_dist_code  from dm_gis.village_tt_waybill_hook where inc_day='20230219' and dest_dist_code in ('371')  ) as t0 
left join ( select waybill_no,consignee_addr,province,city,county,town,vilname,vilcode,town_adcode,class_code,distance,inc_day,dest_dist_code  
from dm_gis.village_dest_addr_decode where inc_day='20230219' and dest_dist_code in ('371') ) as t1 
on t0.waybill_no=t1.waybill_no 
left join (select waybill_no,class_code,vilcode,own_code,own_code_check,village_code,inc_day,dest_dist_code 
from dm_gis.village_dest_owncode_isnotnull_res where inc_day='20230219' and dest_dist_code in ('371') ) as t2 
on t0.waybill_no=t2.waybill_no 
left join (select waybill_no,class_code,vilcode,inc_day,dest_dist_code,zx,zy,vil_code,vil_name,guid 
from dm_gis.village_dest_owncode_isnull_res where inc_day='20230219' and dest_dist_code in ('371')   ) as t3 
on t0.waybill_no=t3.waybill_no 
left join (select waybill_no,inc_day,dest_dist_code,aoi_code,zx,zy,matchres from dm_gis.village_dest_classcode_waybill_xg_aoi_res where inc_day='20230219' and dest_dist_code in ('371') ) as t4 
on t0.waybill_no=t4.waybill_no 
left join (select dept_code,area_name,dept_name,dept_type_code from (select dept_code,area_name,dept_name,dept_type_code,row_number() over(partition by dept_code order by inc_day desc)  as rn 
from  dim.dim_dept_info_df where inc_day=date_format(date_add(current_date(),-2),'yyyyMMdd') ) as b where b.rn=1 ) as t5 
on t0.dest_zone_code=t5.dept_code 
left join dm_tc_waybillinfo.aoi_area_aoi as t6 
on t0.aoi_code=t6.aoi_id 
left join (select waybill_no,own_code from dm_gis.village_dest_owncode_isnotnull where inc_day='20230219' and dest_dist_code in ('371') ) as t7 
on t0.waybill_no=t7.waybill_no 
) as t 
;





-- --------------------------------------
-- 前提：派件和收件明细表都有了
-- 网点、镇、村统计件量

create table dm_gis.village_kdsm_zone_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "网点统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


create table dm_gis.village_kdsm_town_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
town string comment '乡镇名称',
town_adcode string comment '乡镇code',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "乡镇统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


create table dm_gis.village_kdsm_vil_stat(
area_code string comment '地区代码',
dist_code string comment '城市代码',
city string comment '城市名称',
zone_code string comment '网点代码',
town string comment '乡镇名称',
town_adcode string comment '乡镇code',
vil_name string comment '村名称',
vil_code string comment '村code',
dest_cnt string comment '派件数量',
src_cnt  string comment '收件数量' 
)
COMMENT "村统计" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
drop table if exists dm_gis.tmp_village_kdsm_vil_stat_dest;
create table dm_gis.tmp_village_kdsm_vil_stat_dest as 
select 
dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,
count(1) as dest_cnt 
from 
(select 
dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code,waybill_no  
from dm_gis.village_dest_kdsm_res 
where inc_day='20230219' and dest_area_code<>'' and city<>'' and dest_zone_code<>''  )as t 
group by dest_area_code,dest_dist_code,city,dest_zone_code,town,town_adcode,vil_name,vil_code 
;

drop table if exists dm_gis.tmp_village_kdsm_vil_stat_src;
create table dm_gis.tmp_village_kdsm_vil_stat_src as 
select 
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,
count(1) as src_cnt 
from 
(select 
src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code,waybill_no  
from dm_gis.village_src_kdsm_res 
where inc_day='20230219' and src_area_code<>'' and city<>'' and source_zone_code<>'' )as t 
group by src_area_code,src_dist_code,city,source_zone_code,town,town_adcode,vil_name,vil_code 
;

insert overwrite dm_gis.village_kdsm_vil_stat partition(inc_day='20230219')
select 
if(t0.area_code is not null,t0.area_code,t1.area_code) as area_code,
if(t0.dist_code is not null,t0.dist_code,t1.dist_code) as dist_code,
if(t0.city is not null,t0.city,t1.city) as city,
if(t0.zone_code is not null,t0.zone_code,t1.zone_code) as zone_code,
if(t0.town is not null,t0.town,t1.town) as town,
if(t0.town_adcode is not null,t0.town_adcode,t1.town_adcode) as town_adcode,
if(t0.vil_name is not null,t0.vil_name,t1.vil_name) as vil_name,
if(t0.vil_code is not null,t0.vil_code,t1.vil_code) as vil_code,
if(t0.dest_cnt is not null,t0.dest_cnt,0 ) as dest_cnt,
if(t1.src_cnt is not null,t1.src_cnt,0 ) as src_cnt 
from 
(
select dest_area_code as area_code,dest_dist_code as dist_code,city,dest_zone_code as zone_code,town,town_adcode,vil_name,vil_code,dest_cnt 
from dm_gis.tmp_village_kdsm_vil_stat_dest ) as t0
full outer join 
(
select src_area_code as area_code,src_dist_code as dist_code,city,source_zone_code as zone_code,town,town_adcode,vil_name,vil_code,src_cnt 
from dm_gis.tmp_village_kdsm_vil_stat_src 
) as t1  
on t0.area_code=t1.area_code and t0.dist_code=t1.dist_code and t0.city=t1.city and t0.zone_code=t1.zone_code 
and t0.town=t1.town and t0.town_adcode=t1.town_adcode and t0.vil_name=t1.vil_name and t0.vil_code=t1.vil_code 
;

insert overwrite dm_gis.village_kdsm_town_stat partition(inc_day='20230219') 
select 
area_code,dist_code,city,zone_code,town,town_adcode,
sum(dest_cnt)  as dest_cnt,
sum(src_cnt)  as src_cnt 
from dm_gis.village_kdsm_vil_stat 
where inc_day='20230219' 
group by 
area_code,dist_code,city,zone_code,town,town_adcode
;

insert overwrite dm_gis.village_kdsm_zone_stat partition(inc_day='20230219') 
select 
area_code,dist_code,city,zone_code,
sum(dest_cnt)  as dest_cnt,
sum(src_cnt)  as src_cnt 
from dm_gis.village_kdsm_vil_stat 
where inc_day='20230219' 
group by 
area_code,dist_code,city,zone_code
;


-- ------------------------------------------
-- 统计表 （20230302 增加网点类型）
-- 建表
create table dm_gis.village_kdsm_stat (
hq_code string comment '大区代码',
area_code string comment '地区代码',
area_name string comment '地区名称',
dist_code string comment '城市编码',
wd_type string comment '网点类型',
pj_all_cnt int comment '派件总量',
pj_xz_cnt int comment '派件乡镇件量',
pj_xz_sm_cnt int comment '派件乡镇上门件量',
pj_xz_sm_ratio double comment '派件乡镇上门率',
pj_xzc_cnt int comment '派件行政村件量',
pj_xzc_jc_cnt int comment '派件行政村进村件量',
pj_xzc_jc_ratio double comment '派件行政村进村率',
pj_yjc_10_cnt int comment '派件大于10km应进村件量',
pj_yjc_10_30_cnt int comment '派件10-30km应进村件量',
pj_jc_10_30_cnt int comment '派件10-30km进村件量',
pj_yjc_30_50_cnt int comment '派件30-50km应进村件量',
pj_jc_30_50_cnt int comment '派件30-50km进村件量',
pj_yjc_50_cnt int comment '派件大于50km应进村件量',
pj_jc_50_cnt int comment '派件大于50km进村件量',
pj_no_cnt int comment '派件未识别件量',
pj_no_ratio double comment '派件未识别率',
sj_all_cnt  int comment '收件总量',
sj_xz_cnt int comment '收件乡镇件量',
sj_xz_sm_cnt int comment '收件乡镇上门件量',
sj_xz_sm_ratio double comment '收件乡镇上门率',
sj_xzc_cnt int comment '收件行政村件量',
sj_xzc_jc_cnt int comment '收件行政村进村件量',
sj_xzc_jc_ratio double comment '收件行政村进村率',
sj_no_cnt  int comment '收件未识别件量',
sj_no_ratio   double comment '收件未识别率' 
)
COMMENT '行政村收派件统计表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

--派件
drop table if exists dm_gis.tmp_village_kdsm_dest_res_stat_1;
create table dm_gis.tmp_village_kdsm_dest_res_stat_1 as 
select 
dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type,
count(1) as pj_all_cnt,
sum(case when yd_type='乡镇' then 1 else 0 end ) as pj_xz_cnt,
sum(case when yd_type='乡镇' and is_jxzpj='是' then 1 else 0 end ) as pj_xz_sm_cnt,
sum(case when yd_type='行政村' then 1 else 0 end ) as pj_xzc_cnt,
sum(case when yd_type='行政村' and is_jcpj='是' then 1 else 0 end ) as pj_xzc_jc_cnt,
count(distinct case when distance>=10000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_10_cnt,
count(distinct case when distance>=10000 and distance<30000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_10_30_cnt,
count(distinct case when distance>=10000 and distance<30000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_10_30_cnt,
count(distinct case when distance>=30000 and distance<50000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_30_50_cnt,
count(distinct case when distance>=30000 and distance<50000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_30_50_cnt,
count(distinct case when distance>=50000 and yd_type='行政村' then aoi_code else null end ) as pj_yjc_50_cnt,
count(distinct case when distance>=50000 and yd_type='行政村' and is_jcpj='是' then aoi_code else null end ) as pj_jc_50_cnt,
sum(case when yd_type is null or yd_type='' then 1 else 0 end ) as pj_no_cnt
from (
select 
dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type,
yd_type,is_jxzpj,cast(distance as int) as distance,is_jcpj,aoi_code  
from dm_gis.village_dest_kdsm_res 
where inc_day='20230219' and dest_hq_code<>'' and dest_area_code<>'' and dest_dist_code<>'' 
) as t 
group by dest_hq_code,dest_area_code,area_name,dest_dist_code,wd_type 
;

--收件
drop table if exists dm_gis.tmp_village_kdsm_src_res_stat_1;
create table dm_gis.tmp_village_kdsm_src_res_stat_1 as 
select 
src_hq_code,src_area_code,area_name,src_dist_code,wd_type,
count(1) as sj_all_cnt,
sum(case when yd_type='乡镇' then 1 else 0 end ) as sj_xz_cnt,
sum(case when yd_type='乡镇' and is_jxzpj='是' then 1 else 0 end ) as sj_xz_sm_cnt,
sum(case when yd_type='行政村' then 1 else 0 end ) as sj_xzc_cnt,
sum(case when yd_type='行政村' and is_jcpj='是' then 1 else 0 end ) as sj_xzc_jc_cnt,
sum(case when yd_type is null or yd_type='' then 1 else 0 end ) as sj_no_cnt
from (
select 
src_hq_code,src_area_code,area_name,src_dist_code,wd_type,
yd_type,is_jxzpj,is_jcpj,aoi_code  
from dm_gis.village_src_kdsm_res 
where inc_day='20230219' and src_hq_code<>'' and src_area_code<>'' and src_dist_code<>'' 
) as t 
group by src_hq_code,src_area_code,area_name,src_dist_code,wd_type  
;


---- 汇聚得筛选表
drop table if exists dm_gis.tmp_village_kdsm_stat_dist_code;
create table dm_gis.tmp_village_kdsm_stat_dist_code as 
select 
hq_code,area_code,area_name,dist_code,wd_type 
from (
select dest_hq_code as hq_code,dest_area_code as area_code,area_name,dest_dist_code as dist_code,wd_type 
from dm_gis.tmp_village_kdsm_dest_res_stat_1 
union all 
select src_hq_code as hq_code,src_area_code as area_code,area_name,src_dist_code as dist_code,wd_type  
from dm_gis.tmp_village_kdsm_src_res_stat_1 
) as t 
group by hq_code,area_code,area_name,dist_code,wd_type   
;

insert overwrite table dm_gis.village_kdsm_stat partition(inc_day='20230219')
select 
t0.hq_code,t0.area_code,t0.area_name,t0.dist_code,t0.wd_type,
t1.pj_all_cnt,
t1.pj_xz_cnt,
t1.pj_xz_sm_cnt,
t1.pj_xz_sm_ratio,
t1.pj_xzc_cnt,
t1.pj_xzc_jc_cnt,
t1.pj_xzc_jc_ratio,
t1.pj_yjc_10_cnt,
t1.pj_yjc_10_30_cnt,
t1.pj_jc_10_30_cnt,
t1.pj_yjc_30_50_cnt,
t1.pj_jc_30_50_cnt,
t1.pj_yjc_50_cnt,
t1.pj_jc_50_cnt,
t1.pj_no_cnt,
t1.pj_no_ratio,
t2.sj_all_cnt,
t2.sj_xz_cnt,
t2.sj_xz_sm_cnt,
t2.sj_xz_sm_ratio,
t2.sj_xzc_cnt,
t2.sj_xzc_jc_cnt,
t2.sj_xzc_jc_ratio,
t2.sj_no_cnt,
t2.sj_no_ratio   
from dm_gis.tmp_village_kdsm_stat_dist_code as t0 
left join (
select dest_hq_code as hq_code,dest_area_code as area_code,area_name,dest_dist_code as dist_code,wd_type,
pj_all_cnt,
pj_xz_cnt,
pj_xz_sm_cnt,
pj_xz_sm_cnt/pj_xz_cnt as pj_xz_sm_ratio,
pj_xzc_cnt,
pj_xzc_jc_cnt,
pj_xzc_jc_cnt/pj_xzc_cnt as pj_xzc_jc_ratio,
pj_yjc_10_cnt,
pj_yjc_10_30_cnt,
pj_jc_10_30_cnt,
pj_yjc_30_50_cnt,
pj_jc_30_50_cnt,
pj_yjc_50_cnt,
pj_jc_50_cnt,
pj_no_cnt,
pj_no_cnt/pj_all_cnt as pj_no_ratio 
from dm_gis.tmp_village_kdsm_dest_res_stat_1 ) as t1 
on t0.hq_code=t1.hq_code and t0.area_code=t1.area_code and t0.area_name=t1.area_name and t0.dist_code=t1.dist_code and t0.wd_type=t1.wd_type   
left join (
select src_hq_code as hq_code,src_area_code as area_code,area_name,src_dist_code as dist_code,wd_type, 
sj_all_cnt,sj_xz_cnt,sj_xz_sm_cnt,
sj_xz_sm_cnt/sj_xz_cnt as sj_xz_sm_ratio,
sj_xzc_cnt,sj_xzc_jc_cnt,
sj_xzc_jc_cnt/sj_xzc_cnt as sj_xzc_jc_ratio,
sj_no_cnt,
sj_no_cnt/sj_all_cnt as sj_no_ratio   
from dm_gis.tmp_village_kdsm_src_res_stat_1 
) as t2 
on t0.hq_code=t2.hq_code and t0.area_code=t2.area_code and t0.area_name=t2.area_name and t0.dist_code=t2.dist_code and t0.wd_type=t2.wd_type  
;