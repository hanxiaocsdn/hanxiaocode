--
-- 快递进村收派件
-- 需求方：敖少良(01425243)
-- @author 张小琼 （01416344）
-- Created on 2023-12-06
-- 任务信息： ID:926185  行政村收派件_new(基于dwd_waybill_info_dtl_di)
--


-- 城区标签维表
create table dm_gis.dim_village_city_af stored as parquet as 
select area_code,remark 
from (select 
area_code,remark,row_number() over(partition by area_code order by remark_label asc) as rn 
from (select area_code,remark,
case when remark='市中心' then '1' 
when remark='县中心' then '2' 
when remark='镇中心' then '3' 
when remark='新城' then '4'  
else '' end as remark_label   from dm_gis.ods_csv_village_city_af where remark is not null and remark<>'' 
) as t 
) as tt where tt.rn=1 
;


-- 派件
insert overwrite table  dm_gis.village_dest_kdsm_res_di partition(inc_day='$firstDay') 
select 
dest_hq_code,dest_area_code,area_name,dest_zone_code,dept_name,t0.waybill_no,deliver_emp_code,real_product_code,meterage_weight_qty,
pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,
yd_type ,
distance,wd_type,dest_dist_code,
operate_longitude,operate_latitude,signin_tm,
add_fee,
is_jp,
is_tcj,lonlat_tag,
subsidy_type,subsidy,
dest_type_code,aoi_id,aoi_src,aoi_type,aoi_area_type,driver_track,
fysz_res,
yxdsz_res,
delivery_xy_aoiid,
dlv_location_mark,
opcode,
bar_sn,
is_same_aoi,
cabinet_code,
position_name,
t15.remark as city_label,
case when (SUBSTR(county, -1)='区' and class_code in ('111','112') ) or t15.remark='市中心'  then '市区' 
     when (SUBSTR(county, -1)!='区' and class_code in ('111','112') ) or t15.remark='县中心'  then '县区'  
     when class_code in  ('121','122','123')  then '镇区'  
     when class_code in  ('210','220')  then '乡村'
else '' end  as town_country_types 
from (select * from dm_gis.village_dest_kdsm_res_di where inc_day='$firstDay' ) as t0 
left join ( select area_code,remark from dm_gis.dim_village_city_af )  as t15
on t0.vil_code=t15.area_code 
;


-- 收件
insert overwrite table  dm_gis.village_src_kdsm_res_di partition(inc_day='$firstDay') 
select 
src_hq_code,src_area_code,area_name,source_zone_code,dept_name,t0.waybill_no,consignee_emp_code,real_product_code,meterage_weight_qty,
pay_cust_type,service_prod_code,all_fee_rmb,freight_monthly_acct_code,is_yj,aoi_code,aoi_name,aoi_type_name,aoi_area_code,
province,city,county,town,town_adcode,vil_name,vil_code,class_code,own_code,is_jcpj,is_jxzpj,
yd_type,
wd_type,src_dist_code,
tt_fee_zh_all_fee,
distance,operate_longitude,operate_latitude,consigned_tm,is_js,lonlat_tag,
subsidy_type,subsidy,
src_type_code,order_no,aoi_id,aoi_src,aoi_type,aoi_area_type,is_cgj,cgj_longitude,cgj_latitude,
consign_xy_aoiid,
csg_location_mark,
bar_sn,
is_same_aoi,
cabinet_code,
position_name,
t15.remark as city_label,
case when (SUBSTR(county, -1)='区' and class_code in ('111','112') ) or t15.remark='市中心'  then '市区' 
     when (SUBSTR(county, -1)!='区' and class_code in ('111','112') ) or t15.remark='县中心'  then '县区'  
     when class_code in  ('121','122','123')  then '镇区'  
     when class_code in  ('210','220')  then '乡村'
else '' end  as town_country_types

from (select * from dm_gis.village_src_kdsm_res_di where inc_day='$firstDay' ) as t0 
left join ( select area_code,remark from dm_gis.dim_village_city_af )  as t15
on t0.vil_code=t15.area_code 
;


-- 统计表 dm_gis.village_kdsm_stat_cnt_fee_di 
insert overwrite table dm_gis.village_kdsm_stat_cnt_fee_di partition(inc_day='$firstDay') 
SELECT province,city,county,town,town_adcode,vil_name,vil_code,class_code,distance,zone_code,dept_type_code,dept_type_name,wd_type,
t0.area_code,dist_code,is_yj,pj_cnt,jcpj_cnt,sj_cnt,jcsj_cnt,all_fee_rmb,tt_fee_zh_all_fee,jxzpj_cnt,jxzsj_cnt,
t15.remark as city_label,
case when (SUBSTR(county, -1)='区' and class_code in ('111','112') ) or t15.remark='市中心'  then '市区' 
     when (SUBSTR(county, -1)!='区' and class_code in ('111','112') ) or t15.remark='县中心'  then '县区'  
     when class_code in  ('121','122','123')  then '镇区'  
     when class_code in  ('210','220')  then '乡村'
else '' end  as town_country_types  
FROM ( select * from dm_gis.village_kdsm_stat_cnt_fee_di where inc_day='$firstDay' ) as t0 
left join ( select area_code,remark from dm_gis.dim_village_city_af )  as t15
on t0.vil_code=t15.area_code 
;