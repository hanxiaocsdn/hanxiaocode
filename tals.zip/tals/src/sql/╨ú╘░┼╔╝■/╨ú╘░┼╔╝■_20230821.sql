-- 
-- 
-- /**
--  * 【校园派件】校园派件数据统计
--  * 需求方：黄皓(01377527)
--  * 需求： ID 1963860  GIS-ASS-ADDS：【校园派件】校园派件数据统计_V1.5
--  * @author 张小琼 （01416344）
--  * Created on 2023-08-21
--  * 任务信息：ID：791980  校园派件数据统计flow
--  *
--  */
-- 

-- 名称 KAFKA_SOURCE
-- 节点类型  KAFKA_SOURCE
-- Kafka地址
-- 集群  gis_ass_eds_lcx9xjel01
-- MOM URL
-- http://tkafka-w64h4xza-GIS-ASS-EDS.kafka.sfcloud.local:1080/mom-mon/monitor/requestService.pub
-- 主题 GIS_ASS_ADDS_CAMPUS
-- 主题校验码 2jzYLiet
-- 消费组  GIS_ASS_ADDS_CAMPUS
-- 消费组校验码  Q1WQOc4Q
-- 处理类  com.sf.bdp.connector.kafka.BdpFlinkKafkaConsumer08
-- 输出类型  java.lang.String


-- hive 任务

-- $[time(yyyyMMdd,-1d)]
insert overwrite table dm_gis.gis_eta_navi_campus_dispatch_v2 partition(inc_day='$[time(yyyyMMdd,-1d)]')
select 
get_json_object(get_json_object(get_json_object(log, '$.message'),'$.param'),'$.waybillNo') as waybillno,
get_json_object(get_json_object(get_json_object(log, '$.message'),'$.param'),'$.aoiId') as aoi_id,
get_json_object(get_json_object(get_json_object(log, '$.message'),'$.param'),'$.disAddr') as disaddr,
get_json_object(get_json_object(get_json_object(log, '$.message'),'$.param'),'$.disPhone') as disphone,
get_json_object(get_json_object(get_json_object(log, '$.message'),'$.param'),'$.addressee') as addressee,
get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log, '$.message'),'$.data'),'$.result'),'$.data'),'$.campusMark') as campusmark,
get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log, '$.message'),'$.data'),'$.result'),'$.data'),'$.stationMark') as stationmark,
get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log, '$.message'),'$.data'),'$.result'),'$.data'),'$.stuComeMark') as stucomemark,
get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log, '$.message'),'$.data'),'$.result'),'$.data'),'$.stuMark') as stumark,	
get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log, '$.message'),'$.data'),'$.result'),'$.data'),'$.source') as source,
log,
get_json_object(get_json_object(log, '$.message'),'$.type') as type,
get_json_object(get_json_object(get_json_object(log, '$.message'),'$.param'),'$.destCityCode') as destcitycode 

from dm_gis.gis_eta_navi_campus_dispatch_log 
where inc_day='$[time(yyyyMMdd,-1d)]' 
and get_json_object(get_json_object(log, '$.message'),'$.type')='req_e' 
and get_json_object(get_json_object(log, '$.message'),'$.ak') like '6f2702464%'



-- shell 任务
pt1=$day30
pt2=$day180

hive -e "
alter table dm_gis.gis_eta_navi_campus_dispatch_log drop partition (inc_day<'$pt1');
alter table dm_gis.gis_eta_navi_campus_dispatch_v2 drop partition (inc_day<'$pt2');
"