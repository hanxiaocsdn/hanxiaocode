-- 需求：
-- 1、先从dm_gis.tt_waybill_hook运单宽表取全国历史七天的数据，取数字段：consignee_addr，dest_province，dest_city_code（拼音换成中文+市，如ZhengZhou，则需转换郑州市,从dm_gis.dim_city_info_df关联），dest_county，dest_dist_code。
-- 2、将第一步取出的数据（consignee_addr（地址），dest_province（省），转换成中文的dest_city_code（市），dest_county（区）跑AT规范化接口，
-- 接口地址：http://gis-int.int.sfdc.com.cn:1080/atdispatch/api/normal/city。
-- 入参：province（省，非必填），cityName（市，非必填），district（区，非必填），address（地址，必填），ak（必填）。出参：adCode，cityCode。
-- http://gis-int.intsit.sfdc.com.cn:1080/atdispatch/api/normal/city?ak=&province=&cityName=&district=&address=
-- 3、将第一步取出的数据（consignee_addr（地址），dest_province（省），转换成中文的dest_city_code（市），dest_county（区）跑SEG接口，接口文档见附件。出出参只需要adcode，citycode。
-- 4、将第一步的dest_dist_code和第二步以及第三步的citycode进行比较。


-- 数据开发
-- step1:  
create table dm_gis.tmp_at_order_0130_0205(
waybill_no string,
consignee_addr string,
dest_province string,
dest_city_code string,
dest_county string,
dest_dist_code string
)
COMMENT "AT派" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.tmp_at_order_0130_0205 partition(inc_day='20230205')
select waybill_no,consignee_addr,dest_province,city_name,dest_county,dest_dist_code from (
select waybill_no,consignee_addr,dest_province,dest_city_code,dest_county,dest_dist_code 
from dm_gis.tt_waybill_hook where inc_day='20230205'  ) as t0 
left join ( select dist_code,city_name  from dm_gis.dim_city_info_df where inc_day='20230205' ) as t1 
on t0.dest_dist_code=t1.dist_code 
;

-- step2:
-- 跑AT接口
http://gis-int.int.sfdc.com.cn:1080/atdispatch/api/normal/city?ak=3eb300d2e06947f7945cd02530a32fd2&province=广东省&cityName=深圳市&district=南山区&address=软件基地
curl 'http://gis-int.int.sfdc.com.cn:1080/atdispatch/api/normal/city?ak=0376a9aa84724dd2a995f858dd963346&province=广东省&cityName=深圳市&district=南山区&address=软件基地'
-- 跑seg接口

curl 'http://gis-int.int.sfdc.com.cn:1080/seg/api/split?ak=0376a9aa84724dd2a995f858dd963346&address=软件基地&province=广东省&city=深圳市&county=南山区&orderno=123456&level=4&showcode=1'

-- SEG：
-- 晚上9.00---早上4.00，早上5.00----早上6.00，每分钟调用量5W；
-- 早上6.00---晚上9.00，每分钟调用量2W；
-- AT：（今晚不能跑，从周四早上6.00开始跑）
-- 晚上9.00----早上6.00，每分钟调用量10W；
-- 早上6.00----晚上9.00，每分钟调用量3W

-- 
drop table if exists dm_gis.tmp_at_order_100city_0130_0205;
create table dm_gis.tmp_at_order_100city_0130_0205(
province string,
city string,
county string,
address string,
dest_dist_code string  
)
COMMENT "AT派" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

insert overwrite table dm_gis.tmp_at_order_100city_0130_0205 partition(inc_day='$firstDay')
select province,city,county,address,dest_dist_code from 
(select dest_province as province,dest_city_code as city,dest_county as county,consignee_addr as address,dest_dist_code 
from dm_gis.tmp_at_order_0130_0205 where inc_day='$firstDay' and dest_dist_code in ('891', '971', '951', '471', '931', '991', '351', '898', '791', '851', '431', '451', '771', '871', '531', '311', '591', '551', '024', '7311', '371', '025', '027', '022', '029', '028', '571', '755', '010', '020', '021', '750', '457', '468', '543', '737', '593', '350', '722', '352', '539', '354', '355', '452', '566', '943', '795', '436', '633', '812', '919', '745', '510', '830', '476', '906', '668', '663', '990', '744', '572', '376', '479', '858', '937', '417', '772', '913', '555', '817', '421', '834', '546', '429', '483', '580', '570', '392', '349', '835', '718', '724', '557', '771', '799', '564', '358', '412', '532', '977', '813', '715', '995', '818', '086', '827', '535', '776', '470', '769')  ) as t 
group by province,city,county,address,dest_dist_code
;


-- 按城市跑数
drop table if exists dm_gis.tmp_at_order_atserver_out;
create table dm_gis.tmp_at_order_atserver_out(
province string,
city string,
county string,
address string,
norm_addr string,
dispatch string,
city_code string,
adcode string 
)
COMMENT "AT派atserver接口输出" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

drop table if exists dm_gis.tmp_at_order_atsegserver_out;
create table dm_gis.tmp_at_order_atsegserver_out(
province string,
city string,
county string,
address string,
province_code string,
county_code string,
city_code string,
adcode string 
)
COMMENT "AT派atsegserver接口输出" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027' '022' '029' '028' '571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990' '744' '572' '376' '479' '858' '937' '417' '772' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
for var in ${citys[@]};
    do
        firstDay='20230130'
        endDay='20230206'
        echo $firstDay $endDay 
        
        while (( $firstDay < $endDay ))
            do
                echo $firstDay
                Param0=`date -d "+0 month $firstDay" +%Y%m`
                Param1=$firstDay
                Param2=`date -d "+1 month $firstDay" +%Y%m%d`
                echo $Param0 $Param1 $Param2

                echo $var
                mainClass="com.sf.gis.scala.tals.app.AtServerApp"
                int_sql="select province,city,county,address from dm_gis.tmp_at_order_100city_0130_0205 where inc_day='$firstDay' and dest_dist_code='$var' "
                out_table="dm_gis.tmp_at_order_atserver_out" 
                inc_day=$firstDay
                dest_dist_code="$var"
                pall_num=30000

                spark-submit \
                --master yarn \
                --queue gis_public \
                --driver-memory 4g \
                --num-executors 10 \
                --executor-memory 4g \
                --executor-cores 10 \
                --conf spark.sql.shuffle.partitions=300 \
                --conf spark.defalut.parallelism=300 \
                --class $mainClass $mainJar "$int_sql" "$out_table" "$inc_day" "$dest_dist_code" "$pall_num"

                firstDay=`date -d "+1 day $firstDay" +%Y%m%d`

            done
    done




-- step3
create table dm_gis.tmp_at_order_res_0130_0205(
waybill_no string,
consignee_addr string,
dest_province string,
dest_city_code string,
dest_county string,
dest_dist_code string,
at_city_code string,
at_adcode string,
seg_city_code string,
seg_adcode string 
)
COMMENT "AT派" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis.tmp_at_order_res_0130_0205 partition(inc_day='$firstDay') 
select
waybill_no,dest_province,dest_city_code,dest_county,consignee_addr,dest_dist_code,
t1.city_code as at_city_code,t1.adcode as at_adcode,
t2.city_code as seg_city_code,t2.adcode  as seg_adcode 
 from 
( select waybill_no,dest_province,dest_city_code,dest_county,consignee_addr,dest_dist_code from dm_gis.tmp_at_order_0130_0205 where inc_day='$firstDay' ) as t0 
left join (select province,city,county,address,city_code,adcode from dm_gis.tmp_at_order_atserver_out where inc_day='$firstDay' ) as t1 
on t0.dest_province=t1.province and t0.dest_city_code=t1.city and  t0.dest_county=t1.county and t0.consignee_addr=t1.address 
left join (select province,city,county,address,city_code,adcode from dm_gis.tmp_at_order_atsegserver_out where inc_day='$firstDay' ) as t2 
on t0.dest_province=t2.province and t0.dest_city_code=t2.city and  t0.dest_county=t2.county and t0.consignee_addr=t2.address 
;



-- 
-- 100city
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027' '022' '029' '028' '571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990' '744' '572' '376' '479' '858' '937' '417' '772' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
-- 20230210 at
-- 待跑
citys=('022' '029' '028' '571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
-- 已跑
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027' '022' '029' '028')
citys=('566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990' '744' '572' '376' '479' '858' '937' '417' '772') 

-- 20230210 seg
-- 待跑
citys=('371' '025' '027' '022' '029' '028' '571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '744' '572' '376' '479' '858' '937' '417' '772' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
--已跑
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027')
citys=('566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990' ) 




-- 运单地址数据按城市去重
drop table if exists dm_gis.tmp_at_order_100city_addr_0130_0205;
create table dm_gis.tmp_at_order_100city_addr_0130_0205(
province string,
city string,
county string,
address string 
)
COMMENT "AT派" 
PARTITIONED BY (dest_dist_code STRING COMMENT "城市代码")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



citys=('371' '025' '027' '022' '029' '028' '571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '744' '572' '376' '479' '858' '937' '417' '772' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
for var in ${citys[@]};
    do
    hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

insert overwrite table dm_gis.tmp_at_order_100city_addr_0130_0205 partition(dest_dist_code='$var')
select province,city,county,address from 
(select dest_province as province,dest_city_code as city,dest_county as county,consignee_addr as address 
from dm_gis.tmp_at_order_0130_0205 where dest_dist_code='$var' ) as t 
group by province,city,county,address 
"
    done


-- 跑数
-- at 

citys=('571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
for var in ${citys[@]};
    do
        echo $var

        mainClass="com.sf.gis.scala.tals.app.AtServerApp"
int_sql="select province,city,county,address from dm_gis.tmp_at_order_100city_addr_0130_0205 where dest_dist_code='$var' "
out_table="dm_gis.tmp_at_order_atserver_out" 
inc_day='0130_0205'
dest_dist_code="$var"
pall_num=30000

spark-submit \
--master yarn \
--queue gis_public \
--driver-memory 4g \
--num-executors 10 \
--executor-memory 4g \
--executor-cores 10 \
--conf spark.sql.shuffle.partitions=300 \
--conf spark.defalut.parallelism=300 \
--class $mainClass $mainJar "$int_sql" "$out_table" "$inc_day" "$dest_dist_code" "$pall_num"


    done



-- seg 
citys=('022' '029' '028' '571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '744' '572' '376' '479' '858' '937' '417' '772' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
for var in ${citys[@]};
    do
        echo $var

        mainClass="com.sf.gis.scala.tals.app.AtSegServerApp"
int_sql="select province,city,county,address from dm_gis.tmp_at_order_100city_addr_0130_0205 where dest_dist_code='$var' "
out_table="dm_gis.tmp_at_order_atsegserver_out" 
inc_day='0130_0205'
dest_dist_code="$var"
pall_num=20000

spark-submit \
--master yarn \
--queue gis_public \
--driver-memory 4g \
--num-executors 10 \
--executor-memory 4g \
--executor-cores 10 \
--conf spark.sql.shuffle.partitions=300 \
--conf spark.defalut.parallelism=300 \
--class $mainClass $mainJar "$int_sql" "$out_table" "$inc_day" "$dest_dist_code" "$pall_num"


    done


-- 9点开跑 
-- AT
citys=('750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
-- seg
citys=('750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412')



-- 20230212 （将按天跑的换成整合去重的）
-- 100city
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027' '022' '029' '028' '571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990' '744' '572' '376' '479' '858' '937' '417' '772' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 

-- AT 
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027' '022' '029' '028')
citys=('566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990') 
for var in ${citys[@]};
    do
        echo $var
hive -e "
insert overwrite table dm_gis.tmp_at_order_atserver_out partition(inc_day='0130_0205',dest_dist_code='$var')  
select province,city,county,address,norm_addr,dispatch,city_code,adcode from dm_gis.tmp_at_order_atserver_out where inc_day>='20230130' and inc_day<='20230205' and dest_dist_code='$var' 
group by province,city,county,address,norm_addr,dispatch,city_code,adcode
"
    done

-- Seg
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027')
citys=('566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990' ) 

for var in ${citys[@]};
    do
        echo $var
hive -e "
insert overwrite table dm_gis.tmp_at_order_atsegserver_out partition(inc_day='0130_0205',dest_dist_code='$var') 
select province,city,county,address,province_code,county_code,city_code,adcode from dm_gis.tmp_at_order_atsegserver_out where inc_day>='20230130' and inc_day<='20230205' and dest_dist_code='$var' 
group by province,city,county,address,province_code,county_code,city_code,adcode
"
    done



-- 还原运单
create table dm_gis.tmp_at_order_result_0130_0205(
waybill_no string,
consignee_addr string,
dest_province string,
dest_city_code string,
dest_county string,
at_city_code string,
at_adcode string,
seg_city_code string,
seg_adcode string  
)
COMMENT "AT派citycode对比" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

--
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027' '022' '029' '028' '571' '755' '010' '020' '021' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990' '744' '572' '376' '479' '858' '937' '417' '772' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 
for var in ${citys[@]};
    do
        firstDay='20230130'
        endDay='20230206'
        echo $firstDay $endDay 
        
        while (( $firstDay < $endDay ))
            do
                echo $firstDay
                echo $var 
                hive -e "
insert overwrite table dm_gis.tmp_at_order_result_0130_0205 partition(inc_day='$firstDay',dest_dist_code='$var')
select waybill_no,consignee_addr,dest_province,dest_city_code,dest_county,
at_city_code,at_adcode,
seg_city_code,seg_adcode 
from (
select waybill_no,consignee_addr,dest_province,dest_city_code,dest_county,dest_dist_code 
from dm_gis.tmp_at_order_0130_0205 where inc_day='$firstDay' and dest_dist_code='$var'  ) as t0 
left join 
( select province,city,county,address,city_code as at_city_code,adcode as at_adcode   
from dm_gis.tmp_at_order_atserver_out where inc_day='0130_0205' and dest_dist_code='$var' ) as t1 
on t0.dest_province=t1.province and t0.dest_city_code=t1.city and t0.dest_county=t1.county and t0.consignee_addr=t1.address 
left join 
(select province,city,county,address,city_code as seg_city_code,adcode as seg_adcode   
from dm_gis.tmp_at_order_atsegserver_out where inc_day='0130_0205' and dest_dist_code='$var' ) as t2 
on t0.dest_province=t2.province and t0.dest_city_code=t2.city and t0.dest_county=t2.county and t0.consignee_addr=t2.address
;
"

                firstDay=`date -d "+1 day $firstDay" +%Y%m%d`

            done
    done



-- 补其他城市 取两天('20230130','20230131')
    hive -e "
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

insert overwrite table dm_gis.tmp_at_order_100city_addr_0130_0205 partition(dest_dist_code='other')
select province,city,county,address from 
(select dest_province as province,dest_city_code as city,dest_county as county,consignee_addr as address 
from dm_gis.tmp_at_order_0130_0205 where inc_day in ('20230130','20230131') and dest_dist_code not in ('891','971','951','471','931','991','351','898','791','851','431','451','771','871','531','311','591','551','024','7311','371','025','027','022','029','028','571','755','010','020','021','750','457','468','543','737','593','350','722','352','539','354','355','452','566','943','795','436','633','812','919','745','510','830','476','906','668','663','990','744','572','376','479','858','937','417','772','913','555','817','421','834','546','429','483','580','570','392','349','835','718','724','557','771','799','564','358','412','532','977','813','715','995','818','086','827','535','776','470','769') ) as t 
group by province,city,county,address 
"

-- 拆分
hash_mod=10
last_id=`expr $hash_mod - 1`
for id in `seq 0 ${last_id}`;do 

  hive -e "
  insert overwrite table dm_gis.tmp_at_order_result_0130_0205 partition(dest_dist_code='other${id}') 
  select province,city,county,address from dm_gis.tmp_at_order_100city_addr_0130_0205 where dest_dist_code='other' 
and abs(hash(concat(if(province==null,'',province),if(city==null,'',city),if(county==null,'',county),if(address==null,'',address)))%${hash_mod})=${id}  "

done




-- 还原已跑
citys=('891' '971' '951' '471' '931' '991' '351' '898' '791' '851' '431' '451' '771' '871' '531' '311' '591' '551' '024' '7311' '371' '025' '027') 
citys=('566' '943' '795' '436' '633' '812' '919' '745' '510' '830' '476' '906' '668' '663' '990' '750' '457' '468' '543' '737' '593' '350' '722' '352' '539' '354' '355' '452' '913' '555' '817' '421' '834' '546' '429' '483' '580' '570' '392' '349' '835' '718' '724' '557' '771' '799' '564' '358' '412' '532' '977' '813' '715' '995' '818' '086' '827' '535' '776' '470' '769') 

-- 20230213 待跑
citys=('022' '029' '028' '571' '755' '010' '020' '021' '744' '572' '376' '479' '858' '937' '417' '772')



-- 计算占比
select dest_dist_code,count(1) as cnt,
sum(if(dest_dist_code!=at_city_code , 1 , 0 ) ) as at_sum,
sum(if(dest_dist_code!=seg_city_code , 1 , 0 ) ) as seg_sum
from dm_gis.tmp_at_order_result_0130_0205 group by dest_dist_code


-- 20230215  增加跑seg规范化接口
-- 'http://gis-int.intsit.sfdc.com.cn:1080/seg/norm/api?ak=8bb09e5e110845f39a000391668e3e80&address=广东省深圳市南山区软件产业基地'

create table dm_gis.tmp_at_order_atsegnormalserver_out(
province string,
city string,
county string,
address string,
detail_addr string,
adcode string,
norm_address string,
address_suffix string 
)
COMMENT "AT派atsegnormalserver接口输出" 
PARTITIONED BY (inc_day STRING COMMENT "分区日期",dest_dist_code string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;




-- 

citys=('024' '431' '451' '010' '311' '022' '351' '471' '021' '025' '571' '551' '591' '791' '531' '371' '027' '7311' '020' '771' '898' '028' '851' '871' '891' '029' '931' '971' '951' '991' '755' '769' '354')
for var in ${citys[@]};
    do
        echo $var

        mainClass="com.sf.gis.scala.tals.app.AtSegServer2App"
int_sql="select province,city,county,address from 
(select dest_province as province,dest_city_code as city,dest_county as county,consignee_addr as address 
from dm_gis.tmp_at_order_0130_0205 where inc_day='20230130' and dest_dist_code='$var' ) as t 
group by province,city,county,address  "
out_table="dm_gis.tmp_at_order_atsegnormalserver_out" 
inc_day='20230130'
dest_dist_code="$var"
pall_num=20000

spark-submit \
--master yarn \
--queue gis_public \
--driver-memory 4g \
--num-executors 6 \
--executor-memory 2g \
--executor-cores 8 \
--conf spark.sql.shuffle.partitions=300 \
--conf spark.defalut.parallelism=300 \
--class $mainClass $mainJar "$int_sql" "$out_table" "$inc_day" "$dest_dist_code" "$pall_num"


    done

-- adcode关联出citycode
create table dm_gis.tmp_at_order_atsegnormalserver_out_decode as 
select province,city,county,address,dest_dist_code,tmptbl.tmpcode 
from (select province,city,county,address,dest_dist_code,adcode from dm_gis.tmp_at_order_atsegnormalserver_out where inc_day='20230130' 
) as t 
lateral view explode(split(adcode,'#')) tmptbl  as tmpcode
;

create table dm_gis.tmp_at_order_atsegnormalserver_out_decode_res as 
select 
province,t0.city,county,address,dest_dist_code,t1.city as city_code
from (
select province,city,county,address,dest_dist_code,adcode4 from (
select province,city,county,address,dest_dist_code,substring(tmpcode,0,4) as adcode4 from dm_gis.tmp_at_order_atsegnormalserver_out_decode 
) as ta 
group by province,city,county,address,dest_dist_code,adcode4 
) as t0
left join
(
select city,adcode4 from (
select city,substring(city_code,0,4) as adcode4  from dm_gis.gis_district where inc_day='20230130' 
) as tb
group by city,adcode4
) as t1
on t0.adcode4=t1.adcode4
;

drop table if exists dm_gis.tmp_at_order_segnormal_res_0130;
create table dm_gis.tmp_at_order_segnormal_res_0130(
waybill_no string,
consignee_addr string,
dest_province string,
dest_city_code string,
dest_county string,
dest_dist_code string,
at_city_code string,
segnormal_city_code string

)
COMMENT "AT派citycode对比" 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.tmp_at_order_segnormal_res_0130 
select waybill_no,consignee_addr,dest_province,dest_city_code,dest_county,t0.dest_dist_code,
at_city_code,
segnormal_city_code  
from (
select waybill_no,consignee_addr,dest_province,dest_city_code,dest_county,dest_dist_code 
from dm_gis.tmp_at_order_0130_0205 where inc_day='20230130' and dest_dist_code in ('024','431','451','010','311','022','351','471','021','025','571','551','591','791','531','371','027','7311','020','771','898','028','851','871','891','029','931','971','951','991','755','769','354')
 ) as t0 
left join 
( select province,city,county,address,dest_dist_code,city_code as at_city_code   
from dm_gis.tmp_at_order_atserver_out where inc_day='0130_0205' and dest_dist_code in ('024','431','451','010','311','022','351','471','021','025','571','551','591','791','531','371','027','7311','020','771','898','028','851','871','891','029','931','971','951','991','755','769','354')
 ) as t1 
on t0.dest_dist_code=t1.dest_dist_code and t0.dest_province=t1.province and t0.dest_city_code=t1.city and t0.dest_county=t1.county and t0.consignee_addr=t1.address 
left join 
(select province,city,county,address,dest_dist_code,city_code as segnormal_city_code  
from dm_gis.tmp_at_order_atsegnormalserver_out_decode_res   ) as t2 
on t0.dest_dist_code=t1.dest_dist_code and t0.dest_province=t2.province and t0.dest_city_code=t2.city and t0.dest_county=t2.county and t0.consignee_addr=t2.address
;


-- 计算占比
select dest_dist_code,count(1) as cnt,
sum(if(at_city_code is null or dest_dist_code!=at_city_code , 1 , 0 ) ) as at_sum,
sum(if(segnormal_city_code is null or dest_dist_code!=segnormal_city_code , 1 , 0 ) ) as segnormal_sum
from dm_gis.tmp_at_order_segnormal_res_0130 
group by dest_dist_code


-- 
-- adcode关联出citycode 
drop table if exists dm_gis.tmp_at_order_atsegnormalserver_out_decode_1;
create table dm_gis.tmp_at_order_atsegnormalserver_out_decode_1 as 
select province,city,county,address,dest_dist_code,tmpcode 
from (select province,city,county,address,dest_dist_code,split(adcode,'#')[0] as tmpcode from dm_gis.tmp_at_order_atsegnormalserver_out where inc_day='20230130' 
) as t 
where dest_dist_code is not null and tmpcode is not null and tmpcode<>''
;

create table dm_gis.tmp_at_order_gis_district as 
select city,adcode4 from (
select city,substring(city_code,0,4) as adcode4  from dm_gis.gis_district where inc_day='20230130' 
) as tb
group by city,adcode4
;

drop table if exists dm_gis.tmp_at_order_atsegnormalserver_out_decode_res_1;
create table dm_gis.tmp_at_order_atsegnormalserver_out_decode_res_1 as 
select 
province,t0.city,county,address,dest_dist_code,t1.city as city_code
from (
select province,city,county,address,dest_dist_code,adcode4 from (
select province,city,county,address,dest_dist_code,substring(tmpcode,0,4) as adcode4 from dm_gis.tmp_at_order_atsegnormalserver_out_decode_1 
) as ta 
group by province,city,county,address,dest_dist_code,adcode4 
) as t0
left join dm_gis.tmp_at_order_gis_district as t1
on t0.adcode4=t1.adcode4
;


create table dm_gis.tmp_at_order_segnormal_res_0130_1(
waybill_no string,
consignee_addr string,
dest_province string,
dest_city_code string,
dest_county string,
dest_dist_code string,
at_city_code string,
segnormal_city_code string

)
COMMENT "AT派citycode对比" 
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



insert overwrite table dm_gis.tmp_at_order_segnormal_res_0130_1 
select waybill_no,consignee_addr,dest_province,dest_city_code,dest_county,t0.dest_dist_code,
at_city_code,
segnormal_city_code  
from (
select waybill_no,consignee_addr,dest_province,dest_city_code,dest_county,dest_dist_code 
from dm_gis.tmp_at_order_0130_0205 where inc_day='20230130' and dest_dist_code in ('024','431','451','010','311','022','351','471','021','025','571','551','591','791','531','371','027','7311','020','771','898','028','851','871','891','029','931','971','951','991','755','769','354')
 ) as t0 
left join 
( select province,city,county,address,dest_dist_code,city_code as at_city_code   
from dm_gis.tmp_at_order_atserver_out where inc_day='0130_0205' and dest_dist_code in ('024','431','451','010','311','022','351','471','021','025','571','551','591','791','531','371','027','7311','020','771','898','028','851','871','891','029','931','971','951','991','755','769','354')
 ) as t1 
on t0.dest_dist_code=t1.dest_dist_code and t0.dest_province=t1.province and t0.dest_city_code=t1.city and t0.dest_county=t1.county and t0.consignee_addr=t1.address 
left join 
(select province,city,county,address,dest_dist_code,city_code as segnormal_city_code  
from dm_gis.tmp_at_order_atsegnormalserver_out_decode_res_1   ) as t2 
on t0.dest_dist_code=t1.dest_dist_code and t0.dest_province=t2.province and t0.dest_city_code=t2.city and t0.dest_county=t2.county and t0.consignee_addr=t2.address
;