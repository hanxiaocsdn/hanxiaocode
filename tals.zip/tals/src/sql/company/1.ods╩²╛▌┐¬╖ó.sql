--------------------- 企业 ----------------------------
-- 源：dm_isic_ris_core_tycdata.company (取最近一个分区的数据)
-- dm_gis_oms.ods_company_info

CREATE TABLE `dm_gis_oms.ods_company_info`(
`id` string,
`base` string COMMENT '归属省份的首字母小写',
`name` string COMMENT '公司名称',
`legal_person_id` string COMMENT '法人ID',
`legal_person_name` string COMMENT '法人姓名',
`legal_person_type` string COMMENT '法人类型，1 人 2 公司',
`reg_number` string COMMENT '注册号',
`company_type` string COMMENT '公司类型代码',
`company_org_type` string COMMENT '公司类型',
`reg_location` string COMMENT '注册地址',
`estiblish_time` string COMMENT '成立日期',
`from_time` string COMMENT '营业期限开始日期',
`to_time` string COMMENT '营业期限终止日期',
`business_scope` string COMMENT '经营范围',
`reg_institute` string COMMENT '登记机关',
`approved_time` string COMMENT '核准日期',
`reg_status` string COMMENT '企业状态',
`reg_capital` string COMMENT '注册资金',
`actual_capital` string COMMENT '实收注册资金',
`org_number` string COMMENT '组织机构代码',
`org_approved_institute` string,
`flag` string COMMENT '1表示parse过，0表示没parse，3表示parse出错',
`parent_id` string COMMENT '上级机构ID',
`updatetime` string,
`list_code` string COMMENT '上市代码',
`ownership_stake` string COMMENT '母公司控股比例',
`source_flag` string COMMENT '数据来源标志',
`name_suffix` string COMMENT '根据名称parse出的公司后缀类型',
`property1` string COMMENT '统一社会信用代码',
`property2` string COMMENT '新公司名id',
`property3` string COMMENT '英文名',
`property4` string COMMENT '纳税人识别号',
`property5` string COMMENT '通过工商app抓取时间',
`crawledtime` string COMMENT '解析完成时间',
`inc_updatetime` string COMMENT '增量数据更新时间')
COMMENT '公司表'
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- 写入数据
-- 只要最近1个分区的数据
set mapreduce.job.queuename=gis;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.support.quoted.identifiers=none;

insert overwrite table dm_gis_oms.ods_company_info
select `(inc_day)?+.+` from dm_isic_ris_core_tycdata.company where inc_day=20220620
;



-- 源：dim.dim_customer_info_df （取最近一个分区）
---- dm_gis_oms.ods_customer_info_df 客户信息（月结账号）
CREATE EXTERNAL TABLE `dm_gis_oms.ods_customer_info_df`(
`customer_code` string COMMENT '客户卡号',
`billing_status` string COMMENT '月结状态',
`valid_date` string COMMENT '协议生效时间',
`invalid_date` string COMMENT '协议到期时间',
`cancel_date` string COMMENT '协议注销时间',
`break_reason` string COMMENT '协议注销原因',
`break_reason_detail` string COMMENT '具体注销原因描述',
`shroff_emp_code` string COMMENT '收账员工号',
`group_bill_mode` string COMMENT '结算方式',
`send_email` string COMMENT '账单发送email地址',
`full_name` string COMMENT '客户全称',
`short_name` string COMMENT '客户简称',
`current_department` string COMMENT '网络代码',
`division_code` string COMMENT '分部代码',
`area_code` string COMMENT '地区代码',
`hq_code` string COMMENT '经营本部代码',
`customer_type` string COMMENT '客户类型',
`enterprise_property_name` string COMMENT '客户性质',
`corp_indi_cred_type` string COMMENT '个人客户证件类型',
`corp_indi_cred_num` string COMMENT '个人客户证件号码',
`credit_code` string COMMENT '统一社会信用代码',
`tax_code` string COMMENT '税务登记号',
`organise_code` string COMMENT '组织机构代码',
`corp_number` string COMMENT '公司注册号',
`corp_license_start_tm` string COMMENT '营业执照开始日期',
`corp_license_end_tm` string COMMENT '营业执照结束日期',
`business_account_type_name` string COMMENT '业务账号类型',
`first_effect_time` string COMMENT '首次合作生效时间',
`corp_product` string COMMENT '主要托寄物',
`major_sell_way` string COMMENT '主要销售对象',
`corp_business_type` string COMMENT '主要销售渠道',
`rang_name` string COMMENT '市场类型',
`invoice_flag` string COMMENT '是否需要发票',
`one_level_industry` string COMMENT '一级行业',
`two_level_industry` string COMMENT '二级行业',
`three_level_industry` string COMMENT '三级行业',
`inner_publicaccount_catrgory` string COMMENT '公司内部免费件账号类别',
`is_virtual_account` string COMMENT '是否虚拟账号',
`sf_one_level_industry_name` string COMMENT 'SF一级行业名称',
`sf_two_level_industry_name` string COMMENT 'SF二级行业名称',
`parent_customer_code` string COMMENT '集团总公司编码',
`is_related_account` string COMMENT '是否关联公司账号',
`layer_name` string COMMENT '客户分层',
`mgr_emp_code` string COMMENT '客户经理工号',
`mgr_emp_name` string COMMENT '客户经理姓名',
`mgr_emp_email` string COMMENT '客户经理邮箱',
`mgr_emp_mobile` string COMMENT '客户经理手机',
`sales_manage_channel` string COMMENT '客户归属组织',
`elect_customer_type` string COMMENT '电商客户类型',
`customer_files_id` string COMMENT '销帮客户档案ID',
`customer_id` string COMMENT '主档案ID（客户ID）',
`customer_class` string COMMENT '客户分级',
`group_id` string COMMENT '集团ID',
`industry_project_code` string COMMENT '行业项目代码',
`is_pro_cust_service` string COMMENT '是否提供项目客服服务',
`no_return_receive` string COMMENT '免录回单（非物流普运）',
`is_change_address` string COMMENT '更改收货地区免责客户',
`config_items_service_area` string COMMENT '配置项目客服地区',
`credit_level` string COMMENT '信用等级',
`credit_limit` double COMMENT '信用额度',
`credit_pay_term` string COMMENT '信用账期',
`tid_value_upper_limit` double COMMENT '特安声明价值上限',
`decission_maker_name` string COMMENT '快递决策人',
`decission_maker_tel` string COMMENT '快递决策人电话',
`decission_maker_mobile_phone` string COMMENT '快递决策人手机',
`bill_code` string COMMENT '结算卡号',
`contract_no` string COMMENT '合同编号',
`period_type` string COMMENT '账期类型',
`is_standard` string COMMENT '是否标准合同',
`contract_state` string COMMENT '合同状态',
`contract_type` string COMMENT '月结协议名称',
`latest_date` string COMMENT '最新合作生效时间',
`sf_sealname` string COMMENT '乙方一印章名称',
`protocol_type_zj` string COMMENT '是否已签转寄件协议',
`protocol_type_ds` string COMMENT '是否代收货款',
`is_sfth` string COMMENT '是否顺丰特惠',
`sfth_pri_method` string COMMENT '顺丰特惠计价方式',
`sfth_valid_date` string COMMENT '顺丰特惠生效时间',
`sfth_invalid_date` string COMMENT '顺丰特惠失效时间',
`protocol_type_mp` string COMMENT '是否免赔协议',
`sales_area_code` string COMMENT '销售地区',
`sales_hq_code` string COMMENT '销售大区',
`customer_profile_status_code` string COMMENT '客户业绩状态代码',
`customer_profile_status_name` string COMMENT '客户业绩状态名称',
`people_follow` string COMMENT '销售工号（跟进人）',
`follow_role` string COMMENT '跟进人角色',
`frozen_flag` string COMMENT '冻结标识（冻结、解冻、默认状态）',
`ly_deduction_rate` string COMMENT '冷运免赔率',
`deduction_type` string COMMENT '免赔类型',
`is_sfwxj` string COMMENT '是否顺丰微小件',
`sfwxj_valid_date` string COMMENT '顺丰微小件生效时间',
`sfwxj_invalid_date` string COMMENT '顺丰微小件失效时间',
`is_sfgp` string COMMENT '是否顺丰干配',
`sfgp_valid_date` string COMMENT '顺丰干配生效时间',
`sfgp_invalid_date` string COMMENT '顺丰干配失效时间',
`sfgp_cancel_date` string COMMENT '顺丰干配注销时间',
`is_sfly` string COMMENT '是否冷运标快',
`sfly_valid_date` string COMMENT '冷运标快生效时间',
`sfly_invalid_date` string COMMENT '冷运标快失效时间',
`sy_area_code` string COMMENT '所属速运业务区',
`sy_area_name` string COMMENT '所属速运地区名称',
`area_name` string COMMENT '地区名称',
`division_name` string COMMENT '分部名称',
`ts_industry_name` string COMMENT 'TS行业',
`sales_area_name` string COMMENT '销售地区名称',
`sales_hq_name` string COMMENT '销售大区名称',
`main_archv_first_cprtn_valid_tm` string COMMENT '主档案ID首次合作生效时间',
`main_archv_cancel_tm` string COMMENT '主档案完全注销时间',
`main_archv_billing_status` string COMMENT '主档案ID生效注销状态',
`is_keep` string COMMENT '是否参与当月保有',
`new_old_cust` string COMMENT '新老客户',
`is_month_active` string COMMENT '是否月应活跃')
COMMENT '客户信息（月结账号）'
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
set mapreduce.job.queuename=gis;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;

insert overwrite table dm_gis_oms.ods_customer_info_df
select `(inc_day)?+.+` from dim.dim_customer_info_df  where inc_day=20220710 ;


-- 公司地址基础表（by算法组）
-- dm_gis_edt.dw_dm_company_base_address


----公司经营异常建表语句
-- 源：dm_isic_ris_core_tycdata.company_abnormal_info （取最近一个分区）
-- dm_gis_oms.ods_company_abnormal_info
CREATE EXTERNAL TABLE `dm_gis_oms.ods_company_abnormal_info`
( `id` string,
`company_id` string COMMENT '公司id',
`put_reason` string COMMENT '列入异常名录原因',
`put_date` string COMMENT '列入异常名录日期',
`put_department` string COMMENT '决定列入异常名录部门(作出决定机关)',
`remove_reason` string COMMENT '移除异常名录原因',
`remove_date` string COMMENT '移除异常名录日期',
`remove_department` string COMMENT '决定移除异常名利部门',
`createtime` string, `deleted` string COMMENT '0：未删除 1：删除',
`inc_updatetime` string COMMENT '增量数据更新时间')
COMMENT '公司经营异常'
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'
;

--
insert overwrite table dm_gis_oms.ods_company_abnormal_info
select `(inc_day)?+.+` from dm_isic_ris_core_tycdata.company_abnormal_info where inc_day=$incDay
;

----公司变更信息
-- 源：dm_isic_ris_core_tycdata.company_change_info （取最近一个分区）
-- dm_gis_oms.ods_company_change_info
CREATE EXTERNAL TABLE `dm_gis_oms.ods_company_change_info`
( `id` string,
`company_id` string COMMENT '公司id',
`change_item` string COMMENT '变更事项',
`content_before` string COMMENT '变更前内容',
`content_after` string COMMENT '变更后内容',
`change_time` string COMMENT '变更日期',
`createtime` string,
`inc_updatetime` string COMMENT '增量数据更新时间')
COMMENT '公司变更信息'
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'
;


--
insert overwrite table dm_gis_oms.ods_company_change_info
select `(inc_day)?+.+` from dm_isic_ris_core_tycdata.company_change_info  where inc_day=$incDay ;

-- 天眼查_行政处罚
-- 源：dm_isic_ris_core_tycdata.company_punishment_info （取最近一个分区）
-- dm_gis_oms.ods_company_punishment_info
CREATE TABLE `dm_gis_oms.ods_company_punishment_info`(
 `id` string,
 `company_id` string COMMENT '公司id',
 `base` string COMMENT '省份',
 `punish_number` string COMMENT '行政处罚决定书文号',
 `name` string COMMENT '名称',
 `reg_number` string COMMENT '注册号',
 `legal_person_name` string COMMENT '法定代表人（负责人）姓名',
 `type` string COMMENT '违法行为类型',
 `content` string COMMENT '行政处罚内容',
 `department_name` string COMMENT '作出行政处罚决定机关名称',
 `decision_date` string COMMENT '作出行政处罚决定日期',
 `publish_date` string COMMENT '公示日期',
 `description` string COMMENT '描述',
 `create_time` string COMMENT '创建时间',
 `deleted` string COMMENT '0：未删除 1：删除',
 `punish_desc_case_id` string,
 `punish_desc_des_id` string,
 `punish_desc_file_path` string,
 `punish_desc_oss_file_path` string,
 `punish_desc_from_node` string,
 `punish_desc_last_modified_time` string,
 `punish_desc_remark` string,
 `inc_updatetime` string COMMENT '增量数据更新时间')
COMMENT '行政处罚'
 ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
 STORED AS INPUTFORMAT
  'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
 OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'
 ;


--导入数据
  INSERT OVERWRITE TABLE dm_gis_oms.ods_company_punishment_info
      SELECT `(inc_day)?+.+` FROM dm_isic_ris_core_tycdata.company_punishment_info WHERE inc_day = '20220717';

-- 天眼查_动产抵押
-- 源：dm_isic_ris_core_tycdata.company_mortgage_info （取最近一个分区）
-- dm_gis_oms.ods_company_mortgage_info
CREATE TABLE `dm_gis_oms.ods_company_mortgage_info`(
 `id` string,
 `company_id` string COMMENT '公司id',
 `base` string COMMENT '省份',
 `reg_num` string COMMENT '登记编号',
 `reg_date` string COMMENT '登记日期',
 `publish_date` string COMMENT '公示日期',
 `status` string COMMENT '状态',
 `reg_department` string COMMENT '登记机关',
 `type` string COMMENT '被担保债权种类',
 `amount` string COMMENT '被担保债权数额',
 `term` string COMMENT '债务人履行债务的期限',
 `scope` string COMMENT '担保范围',
 `remark` string COMMENT '备注',
 `overview_type` string COMMENT '概况种类',
 `overview_amount` string COMMENT '概况数额',
 `overview_scope` string COMMENT '概况担保的范围',
 `overview_term` string COMMENT '概况债务人履行债务的期限',
 `overview_remark` string COMMENT '概况备注',
 `cancel_date` string COMMENT '注销日期',
 `cancel_reason` string COMMENT '注销原因',
 `create_time` string COMMENT '创建时间',
 `deleted` string COMMENT '0：未删除 1：删除',
 `inc_updatetime` string COMMENT '增量数据更新时间')
COMMENT '动产抵押'
ROW FORMAT SERDE
'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
STORED AS INPUTFORMAT
'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
OUTPUTFORMAT
'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'
;


--导入数据
  INSERT OVERWRITE TABLE dm_gis_oms.ods_company_mortgage_info
      SELECT `(inc_day)?+.+` FROM dm_isic_ris_core_tycdata.company_mortgage_info WHERE inc_day = '20220717';



-- 天眼查_严重违法
-- 源：dm_isic_ris_core_tycdata.company_illegal_info （取最近一个分区）
-- dm_gis_oms.company_illegal_info
CREATE EXTERNAL TABLE `dm_gis_oms.company_illegal_info`
( `id` string,
`company_id` string COMMENT '公司id',
`put_reason` string COMMENT '列入原因',
`put_date` string COMMENT '列入日期',
`put_department` string COMMENT '决定列入部门(作出决定机关)',
`remove_reason` string COMMENT '移除原因',
`remove_date` string COMMENT '移除日期',
`remove_department` string COMMENT '决定移除部门',
`type` string COMMENT '类别',
`fact` string COMMENT '违法事实',
`deleted` string COMMENT '0：未删除 1：删除',
`inc_updatetime` string COMMENT '增量数据更新时间')
COMMENT '严重违法'
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'
;

--
  INSERT OVERWRITE TABLE dm_gis_oms.company_illegal_info
      SELECT `(inc_day)?+.+` FROM dm_isic_ris_core_tycdata.company_illegal_info WHERE inc_day = '20220717';


-- 天眼查_行政许可
-- 源：dm_isic_ris_core_tycdata.company_license
-- dm_gis_oms.ods_company_license
CREATE TABLE IF NOT EXISTS `dm_gis_oms.ods_company_license`(
 `id` string,
 `companyid` string COMMENT '公司id',
 `licencename` string COMMENT '许可证名称',
 `licencenumber` string COMMENT '许可证号',
 `scope` string COMMENT '范围',
 `fromdate` string COMMENT '起始日期',
 `todate` string COMMENT '到期日期',
 `issuedate` string COMMENT '发证日期',
 `type` string COMMENT '类型',
 `department` string COMMENT '发证机关',
 `state` string COMMENT '证书状态',
 `grade` string COMMENT '等级',
 `createtime` string COMMENT '创建时间',
 `inc_updatetime` string COMMENT '增量数据更新时间')
COMMENT '行政许可'
ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
STORED AS INPUTFORMAT
  'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat';


--
set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.support.quoted.identifiers=none;

INSERT OVERWRITE TABLE dm_gis_oms.ods_company_license
select
id,
companyid,
licencename,
licencenumber,
scope,
fromdate,
todate,
issuedate,
type,
department,
state,
grade,
createtime,
inc_updatetime
from
(
select t.*, row_number() over(partition by id,companyid order by inc_day desc) as rn from dm_isic_ris_core_tycdata.company_license as t
) as t1
where t1.rn=1
;