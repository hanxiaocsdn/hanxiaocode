---------------------企业----------------------------
-- 月结账号寄件量及费用统计
-- 累计寄件次数
---- dm_gis_oms.dwm_freight_total_consignor_rmb_mi 月结账号累计寄件及费用(每月)
create table dm_gis_oms.dwm_freight_total_consignor_rmb_mi(
freight_monthly_acct_code string comment '月结账号',
consigned_cnt int comment '寄件数',
total_jf_rmb double comment '寄件费用'
)
comment '月结账号累计寄件'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

insert overwrite table dm_gis_oms.dwm_freight_total_consignor_rmb_mi partition(inc_day='202204')
select freight_monthly_acct_code,
sum(1) as consigned_cnt,
sum(all_fee_rmb) as total_jf_rmb
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and length(freight_monthly_acct_code)>4
and ((freight_payment_type_code='1'  and freight_settlement_type_code='2') or (freight_payment_type_code='3'  and freight_settlement_type_code='2'  and freight_payment_change_type_code='1'))
group by freight_monthly_acct_code
;


drop table if exists dm_gis_oms.dwm_freight_total_consignor_rmb_y_tmp;

create table dm_gis_oms.dwm_freight_total_consignor_rmb_y_tmp as
select freight_monthly_acct_code,
sum(consigned_cnt) as consigned_cnt,
sum(total_jf_rmb) as total_jf_rmb
from dm_gis_oms.dwm_freight_total_consignor_rmb_mi
where inc_day>='202101' and inc_day<'202201'
group by freight_monthly_acct_code
;


-- 计算年度统计量
create table dm_gis_oms.dws_freight_all_stat_year
(
stat_year string,
percentile_jj array<double>,
avg_jj int,
min_jj int,
max_jj int,
percentile_rmb array<double>,
avg_rmb int,
min_rmb int,
max_rmb int
)
comment '所有月结账户统计量'
;

insert into dm_gis_oms.dws_freight_all_stat_year
select t0.stat_year,percentile_jj,avg_jj,min_jj,max_jj,
percentile_rmb,avg_rmb,min_rmb,max_rbm
from(
select '2021' as stat_year,percentile(consigned_cnt,array(0.25,0.5,0.75)) as percentile_jj,avg(consigned_cnt) as avg_jj,min(consigned_cnt) as min_jj,max(consigned_cnt) as max_jj
from dm_gis_oms.dwm_freight_total_consignor_rmb_y_tmp where consigned_cnt is not null and consigned_cnt>0 ) as t0
left join (
select '2021' as stat_year,percentile(cast(total_jf_rmb as bigint),array(0.25,0.5,0.75)) as percentile_rmb,avg(total_jf_rmb) as avg_rmb,min(total_jf_rmb) as min_rmb,max(total_jf_rmb) as max_rbm
from dm_gis_oms.dwm_freight_total_consignor_rmb_y_tmp where  total_jf_rmb is not null and total_jf_rmb>0 ) as t1
on t0.stat_year=t1.stat_year
;


-- 常用寄件地址（top3）
create table dm_gis_oms.dwm_freight_consignor_addr_mi(
freight_monthly_acct_code string comment '月结账号',
consignor_addr int comment '寄件地址',
consignor_addr_cnt int comment '寄件地址寄件次数'
)
comment '月结账号寄件地址寄件量'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');



insert overwrite table dm_gis_oms.dwm_freight_total_consignor_rmb_mi partition(inc_day='202204')
select freight_monthly_acct_code,
consignor_addr,
count(1) as consignor_addr_cnt
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and length(freight_monthly_acct_code)>4
and ((freight_payment_type_code='1'  and freight_settlement_type_code='2') or (freight_payment_type_code='3'  and freight_settlement_type_code='2'  and freight_payment_change_type_code='1'))
and consignor_addr is not null and consignor_addr<>''
group by freight_monthly_acct_code,consignor_addr
;


-- 常寄托寄物（top3）
create table dm_gis_oms.dwm_freight_consignor_cons_mi(
freight_monthly_acct_code string,
cons string,
cons_cnt  int
)
comment '寄托寄物'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
insert overwrite table dm_gis_oms.dwm_freight_consignor_cons_mi partition(inc_day='202204')
select freight_monthly_acct_code,cons,count(1) as cons_cnt
from (
select  freight_monthly_acct_code,cons
from (
select  freight_monthly_acct_code,cons_name
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and length(freight_monthly_acct_code)>4
and ((freight_payment_type_code='1'  and freight_settlement_type_code='2') or (freight_payment_type_code='3'  and freight_settlement_type_code='2'  and freight_payment_change_type_code='1'))
and size(cons_name)>0 ) as a
LATERAL VIEW explode(cons_name) spc as cons
) as b group by freight_monthly_acct_code,cons
;

-- dm_gis_oms.dwm_freight_consignor_cons_tmp 寄托寄物top3临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_freight_consignor_cons_tmp1;
create table dm_gis_oms.dwm_freight_consignor_cons_tmp1 as
select freight_monthly_acct_code,cons,sum(cons_cnt) as cons_cnt from dm_gis_oms.dwm_freight_consignor_cons_mi
where inc_day<='202204'
group by freight_monthly_acct_code,cons
;

drop table if exists dm_gis_oms.dwm_freight_consignor_cons_tmp;
create table dm_gis_oms.dwm_freight_consignor_cons_tmp as
select freight_monthly_acct_code,cons,cons_cnt from (
select freight_monthly_acct_code,cons,cons_cnt,row_number() over(partition by freight_monthly_acct_code order by cons_cnt desc) as rn
 from dm_gis_oms.dwm_freight_consignor_cons_tmp1
) as a1 where a1.rn<=3
;


-- 月结客户寄件手机寄件票数
create table dm_gis_oms.dwm_freight_consignor_mobile_mi(
freight_monthly_acct_code string,
consignor_mobile string,
consignor_mobile_cnt  int
)
comment '月结客户寄件手机寄件票数'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
insert overwrite table dm_gis_oms.dwm_freight_consignor_mobile_mi partition(inc_day='202204')
select freight_monthly_acct_code,consignor_mobile,count(1) as consignor_mobile_cnt
from (
select  freight_monthly_acct_code,consignor_mobile
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and length(freight_monthly_acct_code)>4
and ((freight_payment_type_code='1'  and freight_settlement_type_code='2') or (freight_payment_type_code='3'  and freight_settlement_type_code='2' and freight_payment_change_type_code='1'))
) as b group by freight_monthly_acct_code,consignor_mobile
;