--  源表名：dm_gis_oms.ods_company_info
--  目标表名：dm_gis_oms.dwd_company_info
--  1)企业名称规范化：遵循企业名称命名规范、统一中文括号
--  2)企业统一信用编码：增加母公司统一社会信用代码
--  3)企业状态标准化：在营、注销、吊销、其他
--  4)重复数据：企业统一信用编码+企业名称为唯一项
--  5)地区标准化：省、市、区/县
--  6)注册资金标准化：统一单位
--  7)去掉无意义字段

set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

--name,status清洗（从ods_company_info表生成）
drop table if exists dm_gis_oms.dwd_company_info_basic_mid;
create table dm_gis_oms.dwd_company_info_basic_mid as
select 
    id,name, regexp_replace(regexp_replace(name,'(\\(.*\\))',''),'([^\\u4E00-\\u9FA5\（\） a-zA-Z.,]+)','') name_new,
    regexp_replace(reg_status,'[^\u4e00-\u9fa5]','') reg_status,
    case
    when reg_status regexp('吊销') then '吊销' 
    when reg_status regexp('注销') then '注销'
    when reg_status regexp('存续|在营|在业|在册|正常|开业') then '在营'
    else '其它'
    end as reg_status_new,
    property1,parent_id,substr(updatetime,1,10) updatetime
from dm_gis_oms.ods_company_info where id not regexp('[^0-9]') and id != ''
;

--提取母公司统一信用编码parent_property1(此表只包含有母公司的公司数据)(在上面basic表的基础上生成)
drop table if exists dm_gis_oms.dwd_company_info_parentcode_mid;
create table dm_gis_oms.dwd_company_info_parentcode_mid as
select t1.id,t1.parent_id,t2.property1 parent_property1 from
(select * from
dm_gis_oms.dwd_company_info_basic_mid
where parent_id not regexp('[^0-9]') and parent_id != '') t1
left join
(select * from
dm_gis_oms.dwd_company_info_basic_mid
where length(property1)=18) t2
on t1.parent_id=t2.id
;

----统一reg_capital单位（从ods_company_info表生成）
drop table if exists dm_gis_oms.dwd_company_info_capital_mid;
create table dm_gis_oms.dwd_company_info_capital_mid as
select id,base,reg_capital,capital_1,capital_2,
case
when capital_1 not regexp('[0-9]') or cast(capital_1 as float)<3 then ''
when capital_2 regexp('万') and capital_2 not regexp('[英|美|日|港|欧]') then concat(cast(capital_1 as float),'万元')
when capital_2 regexp('万') then concat(cast(capital_1 as float),capital_2)
else concat(if(cast(capital_1 as float)<10000,cast(capital_1 as float),cast(capital_1 as float)/10000),'万元')
end as capital_new
from 
(
select id,base,regexp_replace(reg_capital,'[^\\u4E00-\\u9FA5.0-9]','') reg_capital,
regexp_replace(reg_capital,'[^0-9.]','') capital_1,
regexp_replace(reg_capital,'[^\\u4E00-\\u9FA5]','') capital_2
from dm_gis_oms.ods_company_info where id not regexp('[^0-9]') and id != ''
) t1
;

--从统一信用编码property1提取地址（从ods_company_info表和dm_gis_oms.dim_administrative_division表生成）
drop table if exists dm_gis_oms.dwd_company_info_add_from_code_mid;
create table dm_gis_oms.dwd_company_info_add_from_code_mid as
select t1.*,province_from_code,city_from_code,district_from_code from
    (
    select id,property1,substr(property1,3,2) pcode,substr(property1,3,4) ccode,substr(property1,3,6) dcode
    from dm_gis_oms.ods_company_info where id not regexp('[^0-9]') and id != '' and length(property1)=18
    ) t1
    left join
    (
    select xzqh_name province_from_code,pj_code from dm_gis_oms.dim_administrative_division where tag = '1'
    )tp on t1.pcode=tp.pj_code
    left join
    (
    select xzqh_name city_from_code,sj_code from dm_gis_oms.dim_administrative_division where tag = '2'
    )tc on t1.ccode=tc.sj_code 
    left join
    (
    select xzqh_name district_from_code,qxj_code from dm_gis_oms.dim_administrative_division where tag = '3'
    )td on t1.dcode=td.qxj_code 
;
	
--base提取省份，reg_institute提取市、区，reg_location提取市(从ods_company_info表生成)
drop table if exists dm_gis_oms.dwd_company_info_add_from_other_mid;
create table dm_gis_oms.dwd_company_info_add_from_other_mid as
select t1.id id,base,t2.reg_institute,t3.reg_location1,t1.province_from_base,t2.city_from_ins,t2.district_from_ins,t3.city_from_location
from
    (select id,base,
    case base
    when 'gd' then '广东省' when 'js' then '江苏省' when 'sd' then '山东省' when 'zj' then '浙江省' when 'hen' then '河南省'
    when 'sc' then '四川省' when 'hub' then '湖北省' when 'heb' then '河北省' when 'hun' then '湖南省' when 'fj' then '福建省'
    when 'ln' then '辽宁省' when 'ah' then '安徽省' when 'yn' then '云南省' when 'snx' then '陕西省'
    when 'jx' then '江西省' when 'gx' then '广西壮族自治区' when 'gz' then '贵州省' when 'sx' then '山西省'
    when 'hlj' then '黑龙江省' when 'sh' then '上海市' when 'cq' then '重庆市' when 'bj' then '北京市'
    when 'jl' then '吉林省' when 'nmg' then '内蒙古自治区' when 'xj' then '新疆维吾尔自治区' when 'gs' then '甘肃省'
    when 'hk' then '香港特别行政区' when 'tj' then '天津市' when 'han' then '海南省' when 'nx' then '宁夏回族自治区'
    when 'tw' then '台湾省' when 'qh' then '青海省' when 'xz' then '西藏自治区' when 'tmp' then 'tmp'
    else ''
    end as province_from_base
    from dm_gis_oms.ods_company_info where id not regexp('[^0-9]') and id != '') t1
    left join
    (select id,reg_institute,
    regexp_extract(regexp_replace(regexp_replace(regexp_replace(reg_institute,'[^\u4e00-\u9fa5]',''),'.*自治区|.*省',''),'市场',''),'(.+?市)',1) city_from_ins,
    regexp_extract(regexp_replace(regexp_replace(regexp_replace(regexp_replace(reg_institute,'[^\u4e00-\u9fa5]',''),'.*自治区|.*省',''),'市场',''),'.+?市',''),'(.+(区|县|旗))',1) district_from_ins
    from dm_gis_oms.ods_company_info) t2
    on t1.id=t2.id
    left join
    (
    select id,reg_location1,if(length(city)>2 and length(city)<6,city,'') city_from_location
    from
        (select id,reg_location,regexp_replace(reg_location,'[^\u4e00-\u9fa5]','') reg_location1,
        regexp_extract(regexp_replace(regexp_replace(reg_location,'[^\u4e00-\u9fa5]',''),'.*自治区|.*省|.*自治州|.*地区|(市场)|(门市)|(菜市)|(夜市)','') ,'(.+?市)',1) city
        from dm_gis_oms.ods_company_info) t1
    ) t3
    on t1.id=t3.id
;
	
--将从institute，location中提取的市区信息和行政区划维表的地名匹配，新字段d_from_ins,c_from_ins,c_from_loc
--（从dwd_company_info_add_from_other_mid表和dm_gis_oms.dim_administrative_division表生成）
--drop table if exists dm_gis_oms.dwd_company_info_add_from_other_new_mid;
--create table dm_gis_oms.dwd_company_info_add_from_other_new_mid as
--select t1.*,td.xzqh_name d_from_ins,tc1.xzqh_name c_from_ins,tc2.xzqh_name c_from_loc from
--dm_gis_oms.dwd_company_info_add_from_other_mid t1
--left join
--(
--select xzqh_name from dm_gis_oms.dim_administrative_division
--where tag = '3' group by xzqh_name
--)td
--on t1.district_from_ins = td.xzqh_name
--left join
--(
--select xzqh_name from dm_gis_oms.dim_administrative_division
--where tag = '2' group by xzqh_name
--)tc1
--on t1.city_from_ins = tc1.xzqh_name
--left join
--(
--select xzqh_name from dm_gis_oms.dim_administrative_division
--where tag = '2' group by xzqh_name
--)tc2
--on t1.city_from_location = tc2.xzqh_name
--;

--
drop table if exists dm_gis_oms.dwd_company_info_add_from_other_mid1;
create table  dm_gis_oms.dwd_company_info_add_from_other_mid1  as
select id,district_from_ins,xzqh_name
from (
select
id,base,reg_institute,reg_location1,province_from_base,city_from_ins,district_from_ins,city_from_location
from dm_gis_oms.dwd_company_info_add_from_other_mid where district_from_ins<>'' and id<>'') as t1
left join (
select xzqh_name from dm_gis_oms.dim_administrative_division
where tag = '3' group by xzqh_name
)td
on t1.district_from_ins = td.xzqh_name
;

drop table if exists dm_gis_oms.dwd_company_info_add_from_other_mid2;
create table  dm_gis_oms.dwd_company_info_add_from_other_mid2  as
select id,city_from_ins,xzqh_name
from (
select
id,base,reg_institute,reg_location1,province_from_base,city_from_ins,district_from_ins,city_from_location
from dm_gis_oms.dwd_company_info_add_from_other_mid where city_from_ins<>''  and id<>'' ) as t1
left join (
select xzqh_name from dm_gis_oms.dim_administrative_division
where tag = '2' group by xzqh_name
)tc1
on t1.city_from_ins = tc1.xzqh_name
;

drop table if exists dm_gis_oms.dwd_company_info_add_from_other_mid3;
create table  dm_gis_oms.dwd_company_info_add_from_other_mid3  as
select id,city_from_location,xzqh_name
from (
select
id,base,reg_institute,reg_location1,province_from_base,city_from_ins,district_from_ins,city_from_location
from dm_gis_oms.dwd_company_info_add_from_other_mid where city_from_location<>''  and id<>'' ) as t1
left join (
select xzqh_name from dm_gis_oms.dim_administrative_division
where tag = '2' group by xzqh_name
)tc2
on t1.city_from_location = tc2.xzqh_name
;

drop table if exists dm_gis_oms.dwd_company_info_add_from_other_new_mid;
create table dm_gis_oms.dwd_company_info_add_from_other_new_mid as
select t0.id,base,reg_institute,reg_location1,province_from_base,t0.city_from_ins,t0.district_from_ins,t0.city_from_location,
t1.xzqh_name d_from_ins,t2.xzqh_name c_from_ins,t3.xzqh_name c_from_loc
from dm_gis_oms.dwd_company_info_add_from_other_mid t0
left join dm_gis_oms.dwd_company_info_add_from_other_mid1 as t1
on t0.id=t1.id
left join dm_gis_oms.dwd_company_info_add_from_other_mid2 as t2
on t0.id=t2.id
left join dm_gis_oms.dwd_company_info_add_from_other_mid3 as t3
on t0.id=t3.id
;

--整合地址信息(dm_gis_oms.dwd_company_info_add_from_other_new_mid和dm_gis_oms.dwd_company_info_add_from_code_mid表)
drop table if exists dm_gis_oms.dwd_company_info_add_mid;
create table dm_gis_oms.dwd_company_info_add_mid as
select id,base,property1,reg_institute,reg_location1,
if((province_from_base = province_from_code) or province_from_code is null,province_from_base,null) as province,
case
when c_from_ins is not null then c_from_ins
when c_from_loc is not null then c_from_loc
else city_from_code end as city,
case
when d_from_ins is not null then d_from_ins
else district_from_code end as district
from
(select * from
    (select id,property1,province_from_code,city_from_code,district_from_code from
    dm_gis_oms.dwd_company_info_add_from_code_mid) code
    left join
    (select id,base,reg_institute,reg_location1,province_from_base,c_from_ins,c_from_loc,d_from_ins from
    dm_gis_oms.dwd_company_info_add_from_other_new_mid) other
    on code.id=other.id) address_all
;

--整合上面提取的所有字段
drop table if exists dm_gis_oms.dwd_company_info_mid;
create table dm_gis_oms.dwd_company_info_mid as
select t_name.id,t_name.name_new name,t_name.reg_status_new reg_status,t_name.property1,t_capital.capital_new reg_capital,
t_add.base,t_add.reg_institute,t_add.reg_location1 reg_location,t_add.province,t_add.city,t_add.district,
t_name.parent_id,t_parent.parent_property1,t_name.updatetime
from
dm_gis_oms.dwd_company_info_basic_mid t_name
left join
dm_gis_oms.dwd_company_info_capital_mid t_capital
on t_name.id=t_capital.id
left join
dm_gis_oms.dwd_company_info_add_mid t_add
on t_name.id=t_add.id
left join
dm_gis_oms.dwd_company_info_parentcode_mid t_parent
on t_name.id=t_parent.id
;

--整合ods_company_info其他字段
drop table if exists dm_gis_oms.dwd_company_info_all_mid;
create table dm_gis_oms.dwd_company_info_all_mid as
select t1.*,t2.legal_person_id,t2.legal_person_name,t2.legal_person_type,t2.reg_number,
t2.company_org_type,t2.estiblish_time,t2.from_time,t2.to_time,t2.business_scope,t2.approved_time,
t2.actual_capital,t2.org_number,t2.org_approved_institute,
t2.property2,t2.property3,t2.property4,t2.property5
from
dm_gis_oms.dwd_company_info_mid t1
left join
dm_gis_oms.ods_company_info t2
on t1.id=t2.id
;

----建表
--CREATE TABLE `dm_gis_oms.dwd_company_info`(
--`id` string,
--`base` string COMMENT '归属省份的首字母小写',
--`name` string COMMENT '公司名称',
--`legal_person_id` string COMMENT '法人ID',
--`legal_person_name` string COMMENT '法人姓名',
--`legal_person_type` string COMMENT '法人类型，1 人 2 公司',
--`reg_number` string COMMENT '注册号',
--`company_org_type` string COMMENT '公司类型',
--`reg_location` string COMMENT '注册地址',
--`reg_institute` string COMMENT '登记机关',
--`province` string COMMENT '归属省份',
--`city` string COMMENT '归属城市',
--`district` string COMMENT '归属区县',
--`establish_time` string COMMENT '成立日期',
--`from_time` string COMMENT '营业期限开始日期',
--`to_time` string COMMENT '营业期限终止日期',
--`business_scope` string COMMENT '经营范围',
--`approved_time` string COMMENT '核准日期',
--`reg_status` string COMMENT '企业状态',
--`reg_capital` string COMMENT '注册资金',
--`actual_capital` string COMMENT '实收注册资金',
--`org_number` string COMMENT '组织机构代码',
--`org_approved_institute` string,
--`parent_id` string COMMENT '上级机构ID',
--`parent_property1` string COMMENT '上级机构统一社会信用代码',
--`updatetime` string,
--`property1` string COMMENT '统一社会信用代码',
--`property2` string COMMENT '新公司名id',
--`property3` string COMMENT '英文名',
--`property4` string COMMENT '纳税人识别号'
--)
--COMMENT '企业工商表'
--STORED AS ORC
--TBLPROPERTIES ('orc.compression'='SNAPPY')
--;

--数据去重，删除无效数据
set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.support.quoted.identifiers=none;

--drop table if exists dm_gis_oms.dwd_company_info;
insert overwrite table dm_gis_oms.dwd_company_info
select
id,base,name,legal_person_id,legal_person_name,legal_person_type,reg_number,company_org_type,reg_location,reg_institute,
province,city,district,estiblish_time,from_time,to_time,business_scope,approved_time,reg_status,reg_capital,actual_capital,
org_number,org_approved_institute,parent_id,parent_property1,updatetime,property1,property2,property3,property4
from
    (select *,row_number() over(partition by name,property1 order by updatetime desc) rn
    from dm_gis_oms.dwd_company_info_all_mid
    where length(name)>4 or (length(name)=4 and length(property1)=18) and province!='tmp') t1
where rn=1
;

