------------企业标签_dim数据开发----------
-- 1.行政区划维表
-- dm_gis_oms.dim_administrative_division


drop table if exists dm_gis_oms.tmp_xzqh_pcct_0908;
create table dm_gis_oms.tmp_xzqh_pcct_0908  as
select xzqh_code,
substr(xzqh_code,0,2) as c1,
substr(xzqh_code,0,4) as c2,
substr(xzqh_code,0,6) as c3,
substr(xzqh_code,0,9) as c4,
xzqh_name,citycode
from dm_gis_oms.xzqh_pcct
;

drop table if exists dm_gis_oms.tmp_xzqh_pcct_0908_01;
create table dm_gis_oms.tmp_xzqh_pcct_0908_01 as
select xzqh_code,c1,c2,c3,c4,xzqh_name,citycode,
case when cast(xzqh_code as bigint)=cast(c1 as bigint)*10000000000 then '1'
when cast(xzqh_code as bigint)!=cast(c1 as bigint)*10000000000 and cast(xzqh_code as bigint)=cast(c2 as bigint)*100000000 then '2'
when cast(xzqh_code as bigint)!=cast(c1 as bigint)*10000000000 and cast(xzqh_code as bigint)!=cast(c2 as bigint)*100000000  and cast(xzqh_code as bigint)==cast(c3 as bigint)*1000000 then '3'
when cast(xzqh_code as bigint)!=cast(c1 as bigint)*10000000000 and cast(xzqh_code as bigint)!=cast(c2 as bigint)*100000000  and cast(xzqh_code as bigint)!=cast(c3 as bigint)*1000000 and cast(xzqh_code as bigint)==cast(c4 as bigint)*1000 then '4'
else '' end as tag
from dm_gis_oms.tmp_xzqh_pcct_0908
;

--
create table dm_gis_oms.dim_administrative_division(
xzqh_code string comment '行政区划代码（12位）',
pj_code string comment '省级代码',
sj_code string comment '市级代码',
qxj_code string comment '区县级代码',
xzj_code string comment '乡镇级代码',
xzqh_name string comment '行政区划名称',
city_code string comment '乡镇级代码',
tag string comment '标记（1：省  2：市  3：区县  4：乡镇）'
)
comment '行政区划维表'
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');


insert overwrite table dm_gis_oms.dim_administrative_division
select xzqh_code,c1,c2,c3,c4,xzqh_name,citycode,tag
from dm_gis_oms.tmp_xzqh_pcct_0908_01 where tag<>''
;


drop table if exists dm_gis_oms.tmp_xzqh_pcct_0908;
drop table if exists dm_gis_oms.tmp_xzqh_pcct_0908_01;