------------小区楼栋坐标验收--------------
-- create by 01416344(张小琼) on 2022-11-02
------------------------------------------
-- aoi_guid,aoi_name,name_chn,x_coord,y_coord,sfadcode
drop table if exists dm_gis.tmp_1102_kunshanaoi_bld;
create table dm_gis.tmp_1102_kunshanaoi_bld(
aoi_guid string,
aoi_name string,
name_chn string,
x_coord string,
y_coord string,
sfadcode string
) 
comment '' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
tblproperties('skip.header.line.count'='1');

LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/input_bld_1102.csv' OVERWRITE INTO TABLE dm_gis.tmp_1102_kunshanaoi_bld;


-- 1、小区收派件运单 
-- 1.1 通过aoi关联
drop table if exists dm_gis.tmp_1102_step1_1;
create table dm_gis.tmp_1102_step1_1 as 
select province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
t1.aoi_guid  
from (
select province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day  
from dm_gis.tals_address_detail_cityin_final 
where action_date>='20211001' and action_date<='20220930'  and region='subei' and city='徐州市' and aoi<>'' 
) as t0 
left join ( select aoi_guid from dm_gis.tmp_1102_kunshanaoi_bld where aoi_guid<>'aoi_guid' and aoi_guid<>'' group by aoi_guid ) as t1 
on t0.aoi=t1.aoi_guid 
where t1.aoi_guid is not null
;

-- 1.2 通过aoi_name与地址模糊匹配
--select * from a left join b on 1=1 where locate(a.col,b.col)>0
drop table if exists dm_gis.tmp_1102_step1_2;
create table dm_gis.tmp_1102_step1_2 as 
select province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
t1.aoi_name  
from (
select province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day  
from dm_gis.tals_address_detail_cityin_final 
where action_date>='20211001' and action_date<='20220930'  and region='subei' and city='徐州市' and addr<>'' 
) as t0 
left join ( select aoi_name from dm_gis.tmp_1102_kunshanaoi_bld where aoi_name<>'aoi_name' and aoi_name<>'' group by aoi_name ) as t1 
on 1=1 
where locate(t1.aoi_name,t0.addr)>0 
; 

-- 1.3 提取运单号合并去重
drop table if exists dm_gis.tmp_1102_step1_3;
create table dm_gis.tmp_1102_step1_3 as 
select waybill_no,inc_day,action,aoi,split 
from (
select waybill_no,inc_day,action,aoi,split from dm_gis.tmp_1102_step1_1 
union all 
select waybill_no,inc_day,action,aoi,split from dm_gis.tmp_1102_step1_2
) as t 
group by waybill_no,inc_day,action,aoi,split
;

-- 1.4 从地址分词中提取aoi name和bld(楼栋)
int_sql="select waybill_no,inc_day,action,aoi,split from dm_gis.tmp_1102_step1_3 where split<>''"
out_table1="dm_gis.tmp_1102_step1_4"
mainClass="com.sf.gis.scala.tals.app.Tmp1031SplitApp"
--dm_gis.tmp_1102_step1_4
--select waybill_no,inc_day,action,split,getAoiName(split) as aoi_name,getBuilding(split) as building from global_temp.tmp_tbl


-- 2、收派件运单匹配事件经纬坐标
drop table if exists dm_gis.tmp_1102_step2_sj;
create table dm_gis.tmp_1102_step2_sj 
(
waybill_no string,
inc_day string,
eventlng string,
eventlat string,
eventaccuracy string
)
COMMENT '收件匹配'
PARTITIONED BY (
`inc_month` string COMMENT '分区月份')
;

drop table if exists dm_gis.tmp_1102_step2_pj;
create table dm_gis.tmp_1102_step2_pj 
(
waybill_no string,
inc_day string,
eventlng string,
eventlat string,
eventaccuracy string
)
COMMENT '派件匹配'
PARTITIONED BY (
`inc_month` string COMMENT '分区月份')
;

insert overwrite table dm_gis.tmp_1102_step2_sj  partition (inc_month='202209')
select t0.waybill_no,t0.inc_day,
t1.eventlng,t1.eventlat,t1.eventaccuracy 
from (select eventlng,eventlat,eventaccuracy,waybillno,inc_day from ods_inc_sgs_core.inc_sgs_task_flow_new 
where inc_day>='20220901' and inc_day<'20221001' and eventtype='31201') t1
left join (select waybill_no,inc_day,action from dm_gis.tmp_1102_step1_3 
where inc_day>='20220901' and inc_day<'20221001' and action='寄件' ) as t0
ON t1.waybillno = t0.waybill_no and t1.inc_day = t0.inc_day 
where t0.waybill_no is not null
;

insert overwrite table dm_gis.tmp_1102_step2_pj  partition (inc_month='202209')
select t0.waybill_no,t0.inc_day,
t1.eventlng,t1.eventlat,t1.eventaccuracy 
from (select eventlng,eventlat,eventaccuracy,waybillno,inc_day from ods_inc_sgs_core.inc_sgs_task_flow_new 
where inc_day>='20220901' and inc_day<'20221001' and eventtype='31124') t1 
left join (select waybill_no,inc_day,action from dm_gis.tmp_1102_step1_3 
where inc_day>='20220901' and inc_day<'20221001' and action='收件' ) as t0
ON t1.waybillno = t0.waybill_no and t1.inc_day = t0.inc_day
where t0.waybill_no is not null
;


-- 2.2 事件经纬数据汇总
drop table if exists dm_gis.tmp_1102_step2_all;
create table dm_gis.tmp_1102_step2_all as 
select waybill_no,inc_day,eventlng,eventlat,action 
from (
select waybill_no,inc_day,eventlng,eventlat,'寄件' as action from dm_gis.tmp_1102_step2_sj group by eventlng,eventlat,waybill_no,inc_day 
union all 
select waybill_no,inc_day,eventlng,eventlat,'收件' as action from dm_gis.tmp_1102_step2_pj group by eventlng,eventlat,waybill_no,inc_day 
) as t
;



-- 3、层层关联，生成待计算数据
-- 3.1 对输入数据，楼栋做标准化处理
drop table if exists dm_gis.tmp_1102_step3_1;
create table dm_gis.tmp_1102_step3_1 as 
select aoi_guid,aoi_name,name_chn,upper(regexp_replace(name_chn,'号楼|栋|号|座','幢')) as bld,x_coord,y_coord 
from dm_gis.tmp_1102_kunshanaoi_bld where aoi_name<>'aoi_name' 
;

-- 3.2 通过aoi关联出的运单，关联上运单分词楼栋字段
drop table if exists dm_gis.tmp_1102_step3_2;
create table dm_gis.tmp_1102_step3_2 as 
select province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,t0.action,action_time,t0.waybill_no,t0.inc_day,
t1.aoi_name,t1.bld 
from dm_gis.tmp_1102_step1_1 as t0
left join ( select waybill_no,inc_day,action,aoi_name,if(building regexp('[\u4e00-\u9fa5]') ,upper(regexp_replace(building,'号楼|栋|号|座','幢')),upper(concat(building,'幢'))) as bld 
from dm_gis.tmp_1102_step1_4 ) as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day and t0.action=t1.action
;


-- 3.2.1 通过aoi关联出的运单，匹配楼栋
drop table if exists dm_gis.tmp_1102_step3_2_1;
create table dm_gis.tmp_1102_step3_2_1 as 
select 
t0.aoi_guid,t0.aoi_name,t0.name_chn,t0.x_coord,t0.y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
t1.aoi_name as split_aoiname,t1.bld  
from dm_gis.tmp_1102_step3_1 as t0 
left join dm_gis.tmp_1102_step3_2  as t1 
on t0.aoi_guid=t1.aoi and t0.aoi_name=t1.aoi_name and t0.bld=t1.bld 
;

-- 3.2.2 通过aoi关联出的运单，关联上事件经纬坐标
drop table if exists dm_gis.tmp_1102_step3_2_2;
create table dm_gis.tmp_1102_step3_2_2 as 
select t0.aoi_guid,t0.aoi_name,t0.name_chn,t0.x_coord,t0.y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,t0.action,action_time,t0.waybill_no,t0.inc_day,
t0.split_aoiname,t0.bld,
eventlng,eventlat  
from dm_gis.tmp_1102_step3_2_1 as t0 
left join dm_gis.tmp_1102_step2_all as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day and t0.action=t1.action
group by t0.aoi_guid,t0.aoi_name,t0.name_chn,t0.x_coord,t0.y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,t0.action,action_time,t0.waybill_no,t0.inc_day,
t0.split_aoiname,t0.bld,
eventlng,eventlat 
;


-- 3.3 通过aoi_name关联出的运单，关联上运单分词楼栋字段
drop table if exists dm_gis.tmp_1102_step3_3;
create table dm_gis.tmp_1102_step3_3 as 
select province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,t0.action,action_time,t0.waybill_no,t0.inc_day,
t1.aoi_name,t1.bld 
from dm_gis.tmp_1102_step1_2 as t0
left join ( select waybill_no,inc_day,action,aoi_name,if(building regexp('[\u4e00-\u9fa5]') ,upper(regexp_replace(building,'号楼|栋|号|座','幢')),upper(concat(building,'幢'))) as bld 
from dm_gis.tmp_1102_step1_4 ) as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day and t0.action=t1.action
;

-- 3.3.1 通过aoi_name关联出的运单，匹配楼栋
drop table if exists dm_gis.tmp_1102_step3_3_1;
create table dm_gis.tmp_1102_step3_3_1 as 
select 
t0.aoi_guid,t0.aoi_name,t0.name_chn,t0.x_coord,t0.y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
t1.aoi_name as split_aoiname,t1.bld  
from dm_gis.tmp_1102_step3_1 as t0 
left join 
(select province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
aoi_name,bld from dm_gis.tmp_1102_step3_3 where aoi_name<>'' or keyword_rds<>'' or keyword_geo<>'' 
)as t1 
on  1=1 
where t0.aoi_name<>'' and (t0.aoi_name=t1.aoi_name or t0.aoi_name=t1.keyword_rds or t0.aoi_name=t1.keyword_rds) and t0.name_chn=t1.bld 
;

-- 3.3.2 通过aoi_name关联出的运单，关联上事件经纬坐标
drop table if exists dm_gis.tmp_1102_step3_3_2;
create table dm_gis.tmp_1102_step3_3_2 as 
select t0.aoi_guid,t0.aoi_name,t0.name_chn,t0.x_coord,t0.y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,t0.action,action_time,t0.waybill_no,t0.inc_day,
t0.split_aoiname,t0.bld,
eventlng,eventlat  
from dm_gis.tmp_1102_step3_3_1 as t0 
left join dm_gis.tmp_1102_step2_all as t1 
on t0.waybill_no=t1.waybill_no and t0.inc_day=t1.inc_day and t0.action=t1.action
group by t0.aoi_guid,t0.aoi_name,t0.name_chn,t0.x_coord,t0.y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,t0.action,action_time,t0.waybill_no,t0.inc_day,
t0.split_aoiname,t0.bld,
eventlng,eventlat 
;


-- 3.4 合并aoi,aoi_name的结果
drop table if exists dm_gis.tmp_1102_step3_4;
create table dm_gis.tmp_1102_step3_4 as 
select aoi_guid,aoi_name,name_chn,x_coord,y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
split_aoiname,bld,
eventlng,eventlat
from 
(
select aoi_guid,aoi_name,name_chn,x_coord,y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
split_aoiname,bld,
eventlng,eventlat  from dm_gis.tmp_1102_step3_2_2 
union all 
select aoi_guid,aoi_name,name_chn,x_coord,y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
split_aoiname,bld,
eventlng,eventlat  from dm_gis.tmp_1102_step3_3_2
) as t
group by aoi_guid,aoi_name,name_chn,x_coord,y_coord, 
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
split_aoiname,bld,
eventlng,eventlat
;


-- 4、计算
-- Tmp1026RunKeyApp
int_sql="select waybill_no,province,city,citycode,addr,aoi,split,action_time as action_date,action,inc_day,bld,x_coord as x,y_coord as y,eventlng,eventlat  
from dm_gis.tmp_1102_step3_4 where  bld<>'' and eventlng<>'' and eventlat<>'' and eventlng!=0 and eventlat!=0 "
out_table1="dm_gis.tmp_1102_step4_1"
mainClass="com.sf.gis.scala.tals.app.Tmp1026RunKeyApp"


-- 
drop table if exists dm_gis.tmp_1102_step4_2;
create table dm_gis.tmp_1102_step4_2 as 
select 
t1.aoi_guid,t1.aoi_name,t1.name_chn,t1.x_coord,t1.y_coord,
t1.province,t1.city,t1.citycode,t1.aoi,t1.addr,t1.split,t1.keyword_rds,t1.keyword_geo,t1.action,t1.action_time,t1.waybill_no,t1.inc_day,
t1.split_aoiname,t1.bld,
t1.eventlng,t1.eventlat,
t2.bld_event_distance,t2.bld_key,t2.event_key,t2.bld_event_cnt,t2.bld_key_nbs,t2.rs_type   
from dm_gis.tmp_1102_step3_4 as t1 
left join dm_gis.tmp_1102_step4_1 as t2 
on t1.waybill_no=t2.waybill_no and t1.inc_day=t2.inc_day and t1.action=t2.action and t1.x_coord=t2.x and t1.y_coord=t2.y 
;



-- 统计 小区楼栋的运单数量 
drop table if exists dm_gis.tmp_1102_step4_2_1;
create table dm_gis.tmp_1102_step4_2_1 as 
select aoi_guid,name_chn,count(1) as bld_yd_cnt
from (
select aoi_guid,name_chn,waybill_no,inc_day 
from dm_gis.tmp_1102_step4_2 
where waybill_no is not null and waybill_no<>'' 
group by aoi_guid,name_chn,waybill_no,inc_day
) as t0 
group by aoi_guid,name_chn
;

-- 统计 小区楼栋的事件非空数量 
drop table if exists dm_gis.tmp_1102_step4_2_2;
create table dm_gis.tmp_1102_step4_2_2 as 
select aoi_guid,name_chn,count(1) as bld_eventyd_cnt
from (
select aoi_guid,name_chn,waybill_no,inc_day,eventlng,eventlat  
from dm_gis.tmp_1102_step4_2 
where waybill_no is not null and waybill_no<>'' 
and eventlng is not null and eventlng<>'' 
and eventlat is not null and eventlat<>'' 
group by aoi_guid,name_chn,waybill_no,inc_day,eventlng,eventlat  
) as t0 
group by aoi_guid,name_chn
;

-- 结果
drop table if exists dm_gis.tmp_1102_step4_3;
create table dm_gis.tmp_1102_step4_3 as 
select 
t0.aoi_guid,t0.aoi_name,t0.name_chn,x_coord,y_coord,
province,city,citycode,aoi,addr,split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
split_aoiname,bld,
eventlng,eventlat,
bld_event_distance,bld_key,event_key,bld_event_cnt,bld_key_nbs,rs_type, 
t1.bld_yd_cnt,
t2.bld_eventyd_cnt 
from dm_gis.tmp_1102_step4_2 as t0 
left join  dm_gis.tmp_1102_step4_2_1 as t1 
on t0.aoi_guid=t1.aoi_guid and t0.name_chn=t1.name_chn
left join  dm_gis.tmp_1102_step4_2_2 as t2  
on t0.aoi_guid=t2.aoi_guid and t0.name_chn=t2.name_chn
;


-- IDE 导出csv
select 
aoi_guid,aoi_name,name_chn,x_coord,y_coord,
base64(cast(split as binary)) as split,keyword_rds,keyword_geo,action,action_time,waybill_no,inc_day,
split_aoiname,bld,
eventlng,eventlat,
bld_event_distance,bld_key,event_key,bld_event_cnt,
bld_key_nbs,rs_type,
bld_yd_cnt,
bld_eventyd_cnt 
from dm_gis.tmp_1102_step4_3 limit 3000000

