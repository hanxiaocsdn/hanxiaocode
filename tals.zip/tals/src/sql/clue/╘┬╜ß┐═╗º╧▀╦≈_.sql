-- 三城市寄件运单（近一年）
create table dm_gis_oms.tmp_clue_730_sy_order_info_di (
consignor_mobile string,
consignor_cont_name string,
consignee_mobile string,
consignee_cont_name string,
consigned_tm string,
src_dist_code string,
src_province string,
consignor_addr string,
signin_tm string,
dest_dist_code string,
dest_province string,
consignee_addr string,
freight_monthly_acct_code string,
freight_settlement_type_code string,
consignor_comp_name string,
waybill_no string,
transport_type_code string,
limit_type_code string,
all_fee_rmb double,
freight_payment_type_code string,
is_value_insured int,
service_prod_code array<string>,
self_send_flag string,
self_pickup_flag string,
cons_name array<string>
)
COMMENT ''
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
set mapreduce.job.queuename=gis;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;

insert overwrite table dm_gis_oms.tmp_clue_730_sy_order_info_di partition(inc_day)
select
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,src_province,consignor_addr,
signin_tm,dest_dist_code,dest_province,consignee_addr,
freight_monthly_acct_code,freight_settlement_type_code,consignor_comp_name,
waybill_no,transport_type_code,
limit_type_code,all_fee_rmb,freight_payment_type_code,
is_value_insured,service_prod_code,self_send_flag,self_pickup_flag,cons_name
,inc_day
from
dm_gis.tt_waybill_info
where inc_day='$[time(yyyyMMdd,-2d)]'
and src_dist_code in ('021','028','551')
;


--  挂有月结卡号的寄件电话
create table dm_gis_oms.tmp_clue_730_have_freight as
select consignor_mobile
from (
select consignor_mobile from  dm_gis_oms.tmp_clue_730_sy_order_info_di
where  length(freight_monthly_acct_code)>4 or freight_settlement_type_code='2'
) as t group by consignor_mobile;


-- 未挂有月结卡号的寄件电话
create table dm_gis_oms.tmp_clue_730_nohave_freight as
select consignor_mobile
from (
select consignor_mobile from  dm_gis_oms.tmp_clue_730_sy_order_info_di
where  freight_settlement_type_code!='2'
) as t group by consignor_mobile;


--
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top200_nohave_freight as
select t0.*,t1.consignor_mobile as nohave_freight from dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top200 as t0
left join dm_gis_oms.tmp_clue_730_nohave_freight as t1
on t0.consignor_mobile=t1.consignor_mobile
;


-- 寄件手机常挂公司名称
create table dm_gis_oms.tmp_clue_730_mobile_comp_name as
select consignor_mobile,consignor_comp_name,count(1) as comp_name_cnt
from (
select consignor_mobile,consignor_comp_name from  dm_gis_oms.tmp_clue_730_sy_order_info_di
where  length(consignor_comp_name)>=2
) as t group by consignor_mobile,consignor_comp_name
;

-- top1
create table dm_gis_oms.tmp_clue_730_mobile_comp_name_top1 as
select consignor_mobile,consignor_comp_name,comp_name_cnt from (
select consignor_mobile,consignor_comp_name,comp_name_cnt,row_number() over(partition by consignor_mobile order by comp_name_cnt desc) as rn
from dm_gis_oms.tmp_clue_730_mobile_comp_name ) as t where t.rn<=1
;


--
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top200_comp_name as
select t0.*,consignor_comp_name,comp_name_cnt from dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top200 as t0
left join dm_gis_oms.tmp_clue_730_mobile_comp_name_top1 as t1
on t0.consignor_mobile=t1.consignor_mobile
;



-- 武汉竞对
-- ads.ads_all_waybill_510100
--
由于我方关注地址数据。会将这一行10个字段拆分成两行，分为收地址数据、寄地址数据2行。
  变动：
  1. 调整：唯一标记运单号首部增加01_,02_，标记收派。
  2. 新增： adcode 计算
  收：
  01_xxxxx,20220110,110000,北京市,北京市,朝阳区,xxxx地址
  寄：
  02_xxxxx,20220110,110000,北京市,北京市,朝阳区,xxxx地址

 简而言之：从甲方那里拿到运单50亿条（原始数据），我们按收、派拆分1条为2条，最终100亿条。
 原始数据是：50亿，10个字段，时间、运单号、收省市区、收地址；派省市区，派地址。
 我们的数据：100亿，7字段。时间，运单号，收派类别，省市区，地址。


drop table if exists tmp.ads_all_waybill_510100_02_addr;
create table tmp.ads_all_waybill_510100_02_addr as
select
id,
from_unixtime(cast(substr(yd_timestamp,0,10) as int)) as yd_time,
norm_address,
normalized,
match_addr,
citycode,
district,
standard
from ads.ads_all_waybill_510100
where substr(id,0,2)='02'
;


create table tmp.ads_all_waybill_510100_tmp_normalized as
select
normalized,
count(1) as cnt
from tmp.ads_all_waybill_510100_02_addr
where
length(normalized)>4
group by normalized
;


drop table tmp.ads_all_waybill_510100_tmp_matchaddr;
create table tmp.ads_all_waybill_510100_tmp_matchaddr as
select
match_addr,
count(1) as cnt
from ( select translate(match_addr,"@|\|","") as match_addr from tmp.ads_all_waybill_510100_02_addr where length(match_addr)>4 ) as t
group by match_addr
;

select max(yd_time),min(yd_time) from tmp.ads_all_waybill_510100_02_addr limit 10 ;
--KEY       VALUE
--max	2022-02-26 02:01:05
--min	2022-02-26 00:01:54


-- 导出竟对数据
select  match_addr,cnt  from  tmp.ads_all_waybill_510100_tmp_matchaddr  where cnt>=100;


-- 导入竟对数据
create table dm_gis_oms.tmp_clue_sichuan_jd_addr(
match_addr string ,
cnt int
)
comment '四川竟对地址统计'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES
("separatorChar"="\001")
STORED AS TEXTFILE
tblproperties("skip.header.line.count"="1")
;

LOAD DATA  INPATH '/user/01416344/upload/ads_all_waybill_510100_tmp_matchaddr.csv' OVERWRITE INTO TABLE dm_gis_oms.tmp_clue_sichuan_jd_addr;


-- 用一年的电话城市top1地址碰撞
drop table if exists dm_gis_oms.dwm_sy_consignor_jjcs_addr_chengdu_match_addr;
create table dm_gis_oms.dwm_sy_consignor_jjcs_addr_chengdu_match_addr  as
select consignor_mobile,consignor_city,addr_1y,addr_cnt_1y,
cnt
from ( select consignor_mobile,consignor_city,addr_1y,addr_cnt_1y from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_1y
where consignor_city='028' and addr_cnt_1y>=50 ) as t0
left join dm_gis_oms.tmp_clue_sichuan_jd_addr as t1
on t0.addr_1y=t1.match_addr
where t1.match_addr is not null
;


