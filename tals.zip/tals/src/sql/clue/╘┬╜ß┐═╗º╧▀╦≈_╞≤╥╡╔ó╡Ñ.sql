--------------------------
-- 月结客户潜客线索_企业
-- 描述：基于近一年运单数据，计算满足项涉及的标签，再通过标签筛选候选线索，过滤项过滤掉不需要的线索，最后输出线索清单。
--      满足项：寄件区域（上海、成都、安徽合肥三个区）
--

-- 市场主体 （'上海区','成都区','合肥区'）  dm_gis_oms.ods_company_info
create table dm_gis_oms.tmp_clue_730_company_info as
select * from dm_gis_oms.ods_company_info where reg_institute regexp '上海|成都|合肥'
;

-- 经营地址 dm_gis_edt.dw_dm_company_base_address（公司地址基础表）  dm_gis.company_operate_address_by_city
create table dm_gis_oms.tmp_clue_730_tl_address as
select * from dm_gis_edt.dw_dm_company_base_address
where inc_day=20220701
and city_code in (select citycode from dm_gis.city_name_map where region in ('上海区') or city in ('成都市','合肥市'))
;

-- 经营地址 取最新一个分区
create table dm_gis_oms.tmp_clue_730_tl_address_top1 as
select credit_code,name,reg_status_new,company_org_type_new,reg_location,reg_norm_addr,
soa.address_append ,soa.sender_latest_date ,soa.receiver_latest_date , soa.address_append as decrypt_address
from (
select credit_code,name,reg_status_new,company_org_type_new,reg_location,reg_norm_addr,operate_address
from
( select credit_code,name,reg_status_new,company_org_type_new,reg_location,reg_norm_addr,operate_address,row_number() over(partition by credit_code order by inc_day desc) as rn
   from  dm_gis_oms.tmp_clue_730_tl_address ) as t0  where t0.rn=1
) t LATERAL VIEW explode(t.operate_address) v as soa
;


-- 运单地址（标准化）对应寄件手机号  近一年 dm_gis.tals_address_detail_cityin_final
create table dm_gis_oms.tmp_clue_730_addr_std_tals as
select waybill_no,addr,concat(addr_std,addr_std_suffix) as addr_std,tel,region,action_date from dm_gis.tals_address_detail_cityin_final
where action_date>=20210701
and region in ('shanghai','anhui','sichuan')
and action='寄件'
and citycode in (select citycode from dm_gis.city_name_map where region in ('上海区') or city in ('成都市','合肥市'))
;



-- 原始运单 dm_gis_oms.dwd_sy_order_info_di
create table dm_gis_oms.tmp_clue_730_sy_order_info as
select *
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20210701' and inc_day<'20220701'
and src_dist_code in (select citycode from dm_gis.city_name_map where region in ('上海区') or city in ('成都市','合肥市'))
;


-- 线索公海 ods_sasp.sasp_clue_sea
select company_name,company_address,contacts,contacts_mobile from ods_sasp.sasp_clue_sea


-- 潜客 市场主体
create table dm_gis_oms.tmp_clue_730_company_no_customer as
select t0.id,t0.base,t0.name,t0.reg_location,t0.business_scope,t0.reg_status,t0.reg_institute,t0.property1,t0.inc_updatetime,t0.credit_code,t0.full_name
from (
select t0.*,t1.credit_code,t1.full_name from dm_gis_oms.tmp_clue_730_company_info as t0
left join (select credit_code,full_name from dm_gis_oms.ods_customer_info_df where length(credit_code)>4) as t1
on t0.property1=t1.credit_code
 union all
select t0.*,t1.credit_code,t1.full_name from dm_gis_oms.tmp_clue_730_company_info as t0
left join (select credit_code,full_name from dm_gis_oms.ods_customer_info_df where length(full_name)>2) as t1
on t0.name=t1.full_name
) as t0
group by t0.id,t0.base,t0.name,t0.reg_location,t0.business_scope,t0.reg_status,t0.reg_institute,t0.property1,t0.inc_updatetime,t0.credit_code,t0.full_name
;



---------------------
-- 通过地址挂接
---------------------
-- 市场主体 (（过滤 去掉 已在月结表中）)关联经营地址

add jar hdfs://sfbdp1//tmp/udf/01397450/97839/1000/encrypt-1.0.0.jar;
add file hdfs://sfbdp1//tmp/udf/sfencode/01416344/sfdencrpt.ini;
create temporary function new_address_encrypt_pro as 'com.sf.udf.encrypt.AddressEncryptPro';

drop table dm_gis_oms.tmp_clue_730_company_no_customer_operate_address;
create table dm_gis_oms.tmp_clue_730_company_no_customer_operate_address as
select t0.id,t0.base,t0.name,t0.reg_location,t0.business_scope,t0.reg_status,t0.reg_institute,t0.property1,t0.inc_updatetime,t0.credit_code,t0.full_name,
t1.reg_status_new,t1.company_org_type_new,t1.reg_norm_addr,new_address_encrypt_pro(t1.reg_norm_addr) as reg_norm_addr_md,
t1.address_append,new_address_encrypt_pro(t1.address_append) as address_append_md,t1.sender_latest_date,t1.receiver_latest_date
from
(select * from dm_gis_oms.tmp_clue_730_company_no_customer where credit_code is null and full_name is null ) as t0
left join dm_gis_oms.tmp_clue_730_tl_address_top1 as t1
on t0.property1=t1.credit_code
;

-- 过滤 去掉企业名称在线索公海表中 再去重
--
create table dm_gis_oms.tmp_clue_730_company_no_customer_operate_address_quchong as
select  t0.id,t0.base,t0.name,t0.reg_location,t0.business_scope,t0.reg_status,t0.reg_institute,t0.property1,t0.inc_updatetime,t0.credit_code,t0.full_name,
        t0.reg_status_new,t0.company_org_type_new,t0.reg_norm_addr,t0.reg_norm_addr_md,
        t0.address_append,t0.address_append_md,t0.sender_latest_date,t0.receiver_latest_date
from dm_gis_oms.tmp_clue_730_company_no_customer_operate_address as t0
left join (select company_name,company_address,contacts,contacts_mobile from ods_sasp.sasp_clue_sea group by company_name,company_address,contacts,contacts_mobile) as t1
on t0.name=t1.company_name
where t1.company_name is null
group by t0.id,t0.base,t0.name,t0.reg_location,t0.business_scope,t0.reg_status,t0.reg_institute,t0.property1,t0.inc_updatetime,t0.credit_code,t0.full_name,
                 t0.reg_status_new,t0.company_org_type_new,t0.reg_norm_addr,t0.reg_norm_addr_md,
                 t0.address_append,t0.address_append_md,t0.sender_latest_date,t0.receiver_latest_date
             ;

-- 经营地址与运单寄件地址挂接
create table dm_gis_oms.tmp_clue_730_address_append_md_order as
select
 address_append_md,t1.*
from (select address_append_md from dm_gis_oms.tmp_clue_730_company_no_customer_operate_address_quchong where address_append_md is not null group by address_append_md) as t0
left join (
select
consignor_mobile,
consignor_cont_name,
consignee_mobile,
consignee_cont_name,
consigned_tm,
src_dist_code,
src_province,
consignor_addr,
signin_tm,
dest_dist_code,
dest_province,
consignee_addr,
freight_monthly_acct_code,
freight_settlement_type_code,
consignor_comp_name,
waybill_no,
transport_type_code,
limit_type_code,
all_fee_rmb,
freight_payment_type_code,
is_value_insured,
service_prod_code,
self_send_flag,
self_pickup_flag,
cons_name
from dm_gis_oms.tmp_clue_730_sy_order_info
) as t1
on t0.address_append_md=t1.consignor_addr
;

--
create table dm_gis_oms.tmp_clue_730_company_order as
select t0.*,t1.name,t1.reg_location,t1.business_scope,t1.reg_status,t1.reg_institute,t1.property1,
t1.reg_status_new,t1.company_org_type_new,t1.address_append
from (select * from dm_gis_oms.tmp_clue_730_address_append_md_order where consignor_mobile is not null ) as t0
left join dm_gis_oms.tmp_clue_730_company_no_customer_operate_address_quchong as t1
on t0.address_append_md=t1.address_append_md
;


----------------------------------------
-- 基于企业计算标签
----------------------------------------
-- 寄件散单票数  dm_gis_oms.tmp_clue_730_consignor_jjsd_1y (近一年)
-- 寄件散单频次  dm_gis_oms.tmp_clue_730_consignor_jjsdts_1y (近一年)
-- 常寄托寄物  dm_gis_oms.tmp_clue_730_consignor_cons_1y (近一年) dm_gis_oms.tmp_clue_730_consignor_cons_1y_top1
-- 常寄件手机 dm_gis_oms.tmp_clue_730_consignor_cons_1y_top1
-- 地址
create table dm_gis_oms.tmp_clue_730_consignor_jjsd_1y as
select property1,
sum(case when freight_settlement_type_code!='2' then 1 else 0 end) as consigned_sd_cnt
from dm_gis_oms.tmp_clue_730_company_order
where consigned_tm>='20210701' and consigned_tm<'20220701'
and length(property1)>4
group by property1
;

create table dm_gis_oms.tmp_clue_730_consignor_jjsdts_1y as
select  property1,count(distinct consigned_tm_day) as consignor_day_cnt
from (
select property1,consigned_tm_day
from (
select property1,substr(consigned_tm,1,10) as consigned_tm_day
from dm_gis_oms.tmp_clue_730_company_order
where consigned_tm>='20210701' and consigned_tm<'20220701'
and freight_settlement_type_code!='2'
and length(property1)>4
and length(consigned_tm)>0  ) as t
group by property1,consigned_tm_day ) as t1
group by property1
;


create table dm_gis_oms.tmp_clue_730_consignor_cons_1y as
select property1,cons,count(1) as cons_cnt
from (
select  property1,cons
from (
select  property1,cons_name
from dm_gis_oms.tmp_clue_730_company_order
where consigned_tm>='20210701' and consigned_tm<'20220701'
and freight_settlement_type_code!='2'
and length(property1)>4
and size(cons_name)>0 ) as a
LATERAL VIEW explode(cons_name) spc as cons
) as b group by property1,cons
;

create table dm_gis_oms.tmp_clue_730_consignor_cons_1y_top3 as
select  property1,cons,cons_cnt
from (
select property1,cons,cons_cnt,row_number() over(partition by property1 order by cons_cnt desc) as rn
from dm_gis_oms.tmp_clue_730_consignor_cons_1y ) as t
where t.rn<=3
;

create table dm_gis_oms.tmp_clue_730_consignor_cons_1y_top1 as
select  property1,cons,cons_cnt
from (
select property1,cons,cons_cnt,row_number() over(partition by property1 order by cons_cnt desc) as rn
from dm_gis_oms.tmp_clue_730_consignor_cons_1y ) as t
where t.rn=1
;

create table dm_gis_oms.tmp_clue_730_consignor_jjsj_1y as
select property1,consignor_mobile,
sum(case when freight_settlement_type_code!='2' then 1 else 0 end) as consignor_mobile_cnt
from dm_gis_oms.tmp_clue_730_company_order
where consigned_tm>='20210701' and consigned_tm<'20220701'
and length(property1)>4
group by property1,consignor_mobile
;

create table dm_gis_oms.tmp_clue_730_consignor_jjsj_1y_top1 as
select property1,consignor_mobile,consignor_mobile_cnt
from (
select property1,consignor_mobile,consignor_mobile_cnt,row_number() over(partition by property1 order by consignor_mobile_cnt desc) as rn
from dm_gis_oms.tmp_clue_730_consignor_jjsj_1y ) as t
where t.rn=1
;

create table dm_gis_oms.tmp_clue_730_consignor_addr_1y as
select property1,consignor_mobile,
sum(case when freight_settlement_type_code!='2' then 1 else 0 end) as consignor_mobile_cnt
from dm_gis_oms.tmp_clue_730_company_order
where consigned_tm>='20210701' and consigned_tm<'20220701'
and length(property1)>4
group by property1,consignor_mobile
;

-- 地址
dm_gis_oms.tmp_clue_730_address_append_md_order

--
--
--
create table dm_gis_oms.tmp_clue_730_company_no_customer_res as
select
t0.property1,name,reg_status_new,reg_institute,city_code,t1.consigned_sd_cnt,t2.consignor_day_cnt,t3.consignor_mobile,t3.consignor_mobile_cnt,t4.cons,t4.cons_cnt
from
(
select property1,name,reg_status_new,reg_institute
from dm_gis_oms.tmp_clue_730_company_no_customer_operate_address_quchong  group by property1,name,reg_status_new,reg_institute
) as t0
left join (select city_code,credit_code from dm_gis_oms.tmp_clue_730_tl_address where length(credit_code)>4 group by city_code,credit_code) as t00
on t0.property1=t00.credit_code
left join dm_gis_oms.tmp_clue_730_consignor_jjsd_1y as t1
on t0.property1=t1.property1
left join dm_gis_oms.tmp_clue_730_consignor_jjsdts_1y as t2
on t0.property1=t2.property1
left join dm_gis_oms.tmp_clue_730_consignor_jjsj_1y_top1 as t3
on t0.property1=t3.property1
left join dm_gis_oms.tmp_clue_730_consignor_cons_1y_top1 as t4
on t0.property1=t4.property1
where t1.property1 is not null
;



drop table if exists dm_gis_oms.tmp_clue_730_company_no_customer_res_top200;
create table dm_gis_oms.tmp_clue_730_company_no_customer_res_top200 as
select property1,name,reg_status_new,city_code,consigned_sd_cnt,consignor_day_cnt,
consignor_mobile,consignor_mobile_cnt,cons,cons_cnt
from (
select property1,name,reg_status_new,city_code,consigned_sd_cnt,consignor_day_cnt,
       consignor_mobile,consignor_mobile_cnt,cons,cons_cnt,
row_number() over(partition by city_code order by consigned_sd_cnt desc,consignor_day_cnt desc) as rn
from
(
select * from dm_gis_oms.tmp_clue_730_company_no_customer_res
where consigned_sd_cnt is not null
and consignor_day_cnt is not null
) as a ) as b where b.rn<=200
;






------------------------------------------------------------------------------------------------------------------------


-- 统计月结客户分布  （客户类型，客户性质）
create table dm_gis_oms.tmp_customer_type as
select customer_type,count(1) from dm_gis_oms.ods_customer_info_df group by  customer_type
;

create table dm_gis_oms.tmp_enterprise_property_name as
select enterprise_property_name,count(1) from dm_gis_oms.ods_customer_info_df group by  enterprise_property_name
;

-- '上海区','成都区','安徽区'  月结
create table dm_gis_oms.tmp_sales_area_name as
select * from dm_gis_oms.ods_customer_info_df where sales_area_name in ('上海区','成都区','安徽区')
;


-- '上海区','成都区','安徽区'  市场主体
create table dm_gis_oms.tmp_3_company_info as
select * from dm_gis_oms.ods_company_info where reg_institute regexp '上海|成都|安徽'
;


-- 潜客 市场主体 地址 挂接运单

-- dm_gis.tals_address_detail_cityin_final   region=shanghai  chengdu anhui sichuan
create table dm_gis_oms.tmp_3_addr_tals as
select waybill_no,addr,tel from dm_gis.tals_address_detail_cityin_final where action_date>=20210701 and region in ('shanghai','anhui','sichuan') and action='寄件'
;

create table dm_gis_oms.tmp_3_addr_std_tals as
select waybill_no,concat(addr_std,addr_std_suffix) as addr_std,tel from dm_gis.tals_address_detail_cityin_final where action_date>=20210701 and region in ('shanghai','anhui','sichuan') and action='寄件'
;


-- dm_gis_oms.tmp_3_company_info 注册地址挂接
create table dm_gis_oms.tmp_3_company_info_addr_tals as
select t0.id,t0.base,t0.name,t0.reg_location,t0.business_scope,t0.reg_institute,t0.property1,
 t1.waybill_no,t1.tel from dm_gis_oms.tmp_3_company_info as t0
left join dm_gis_oms.tmp_3_addr_tals as t1
on t0.reg_location=t1.addr
where t1.waybill_no is not null
;


-- 潜客 市场主体 去掉 已在月结表中
create table dm_gis_oms.tmp_3_company_info_addr_tals_no_customer as
select t0.id,t0.base,t0.name,t0.reg_location,t0.business_scope,t0.reg_institute,t0.property1,
        t0.waybill_no,t0.tel,t0.credit_code,t0.full_name
from (
select t0.*,t1.credit_code,t1.full_name from dm_gis_oms.tmp_3_company_info_addr_tals as t0
left join (select credit_code,full_name from dm_gis_oms.tmp_sales_area_name where length(credit_code)>4) as t1
on t0.property1=t1.credit_code
union all
select t0.*,t1.credit_code,t1.full_name from dm_gis_oms.tmp_3_company_info_addr_tals as t0
left join (select credit_code,full_name from dm_gis_oms.tmp_sales_area_name where length(full_name)>2) as t1
on t0.name=t1.full_name
) as t0 group by t0.id,t0.base,t0.name,t0.reg_location,t0.business_scope,t0.reg_institute,t0.property1,
                         t0.waybill_no,t0.tel,t0.credit_code,t0.full_name
;


create table dm_gis_oms.tmp_3_company_info_addr_tals_no_customer_1 as
select * from dm_gis_oms.tmp_3_company_info_addr_tals_no_customer where length(credit_code)>4 or length(full_name)>0
;

create table dm_gis_oms.tmp_3_company_info_addr_tals_no_customer_0 as
select * from dm_gis_oms.tmp_3_company_info_addr_tals_no_customer where length(credit_code)<=4 and length(full_name)<1
;