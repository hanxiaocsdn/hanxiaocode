--------------------------
-- 月结客户潜客线索_个人散单
-- 描述：基于近一年运单数据，计算满足项涉及的标签，再通过标签筛选候选线索，过滤项过滤掉不需要的线索，最后输出线索清单。
--      满足项：寄件区域（上海、成都、安徽合肥三个区）、寄件量大、寄件频次高
--      过滤项：挂了月结卡号的个人、已存在线索公海
-- 取数：
-- 寄件散单票数  dm_gis_oms.dwm_sy_total_consignor_mi   dm_gis_oms.dwm_sy_total_consignor_jjsdps_tmp (近一年) dm_gis_oms.dwm_sy_total_consignor_jjsdps_halfy_tmp (近半年)
-- 寄件散单频次  dm_gis_oms.dwm_sy_consignor_jjsdts_mi  dm_gis_oms.dwm_sy_consignor_jjsdts_tmp（近一年） dm_gis_oms.dwm_sy_consignor_jjsdts_halfy_tmp（近半年）
-- 常寄托寄物  dm_gis_oms.dwm_sy_consignor_cons_mi  dm_gis_oms.dwm_sy_consignor_cons_1y_tmp (近一年) dm_gis_oms.dwm_sy_consignor_cons_1y_top3 dm_gis_oms.dwm_sy_consignor_cons_1y_top1
-- 电话姓名  dm_gis_oms.ods_tals_tel_base
-- 寄件地址  dm_gis_oms.dwm_sy_consignor_addr_mi  dm_gis_oms.dwm_sy_consignor_addr_1y_tmp (近一年)  dm_gis_oms.dwm_sy_consignor_addr_1y_top3 dm_gis_oms.dwm_sy_consignor_addr_1y_top1
--
--



create table dm_gis_oms.dwm_sy_total_consignor_jjsdps_tmp as
select consignor_mobile,
sum(consigned_sd_cnt) as consigned_sd_cnt
from dm_gis_oms.dwm_sy_total_consignor_mi
where inc_day>='202107' and inc_day<='202206'
group by consignor_mobile
;

create table dm_gis_oms.dwm_sy_total_consignor_jjsdps_halfy_tmp as
select consignor_mobile,
sum(consigned_sd_cnt) as consigned_sd_cnt
from dm_gis_oms.dwm_sy_total_consignor_mi
where inc_day>='202201' and inc_day<='202206'
group by consignor_mobile
;

create table dm_gis_oms.dwm_sy_total_consignor_jjsdps_1m_tmp as
select consignor_mobile,consigned_sd_cnt
from dm_gis_oms.dwm_sy_total_consignor_mi
where inc_day='202206'
;

dwm_sy_consignor_jjsdts_tmp （直取）

create table dm_gis_oms.dwm_sy_consignor_jjsdts_halfy_tmp as
select consignor_mobile,sum(consignor_day_cnt) as consignor_day_cnt
from dm_gis_oms.dwm_sy_consignor_jjsdts_mi
where inc_day>='202201' and inc_day<='202206'
group by consignor_mobile
;

create table dm_gis_oms.dwm_sy_consignor_jjsdts_1m_tmp as
select consignor_mobile,consignor_day_cnt
from dm_gis_oms.dwm_sy_consignor_jjsdts_mi
where inc_day='202206'
;


create table dm_gis_oms.dwm_sy_consignor_cons_1y_tmp as
select consignor_mobile,cons,sum(cons_cnt) as cons_cnt from dm_gis_oms.dwm_sy_consignor_cons_mi
where inc_day>='202107' and inc_day<='202206'
group by consignor_mobile,cons
;

create table dm_gis_oms.dwm_sy_consignor_cons_1y_top3 as
select  consignor_mobile,cons,cons_cnt
from (
select consignor_mobile,cons,cons_cnt,row_number() over(partition by consignor_mobile order by cons_cnt desc) as rn
from dm_gis_oms.dwm_sy_consignor_cons_1y_tmp ) as t
where t.rn<=3
;

create table dm_gis_oms.dwm_sy_consignor_cons_1y_top1 as
select  consignor_mobile,cons,cons_cnt
from (
select consignor_mobile,cons,cons_cnt,row_number() over(partition by consignor_mobile order by cons_cnt desc) as rn
from dm_gis_oms.dwm_sy_consignor_cons_1y_tmp ) as t
where t.rn<=1
;


create table dm_gis_oms.dwm_sy_consignor_addr_1y_tmp as
select consignor_mobile,consignor_addr,sum(consignor_addr_cnt) as consignor_addr_cnt from dm_gis_oms.dwm_sy_consignor_addr_mi
where inc_day>='202107' and inc_day<='202206'
group by consignor_mobile,consignor_addr
;


create table dm_gis_oms.dwm_sy_consignor_addr_1y_top3 as
select  consignor_mobile,consignor_addr,consignor_addr_cnt
from (
select consignor_mobile,consignor_addr,consignor_addr_cnt,row_number() over(partition by consignor_mobile order by consignor_addr_cnt desc) as rn
from dm_gis_oms.dwm_sy_consignor_addr_1y_tmp ) as t
where t.rn<=3
;

create table dm_gis_oms.dwm_sy_consignor_addr_1y_top1 as
select  consignor_mobile,consignor_addr,consignor_addr_cnt
from (
select consignor_mobile,consignor_addr,consignor_addr_cnt,row_number() over(partition by consignor_mobile order by consignor_addr_cnt desc) as rn
from dm_gis_oms.dwm_sy_consignor_addr_1y_tmp ) as t
where t.rn<=1
;


--
-- 寄件城市  dm_gis_oms.dwm_sy_consignor_jjcs_mi  dm_gis_oms.dwm_sy_consignor_jjcs_recent_1y_tmp (近一年)
-- 上海、成都、安徽合肥三个区   select * from dm_gis.city_name_map where region in ('上海区') or city in ('成都市','合肥市')
--
create table dm_gis_oms.dwm_sy_consignor_jjcs_recent_1y_tmp as
select consignor_mobile,consignor_city,sum(consignor_city_cnt) as consignor_city_cnt from dm_gis_oms.dwm_sy_consignor_jjcs_mi
where inc_day>='202107' and inc_day<='202206'
group by consignor_mobile,consignor_city
;


--
-- 有月结卡号的寄件手机号  dm_gis_oms.dwm_freight_consignor_mobile_mi  dm_gis_oms.dwm_freight_consignor_mobile_recent_1y_tmp （近一年）
--
create table dm_gis_oms.dwm_freight_consignor_mobile_recent_1y_tmp as
select freight_monthly_acct_code,consignor_mobile,sum(consignor_mobile_cnt) as consignor_mobile_cnt
from dm_gis_oms.dwm_freight_consignor_mobile_mi
where inc_day>='202107' and inc_day<='202206'
group by freight_monthly_acct_code,consignor_mobile
;


-- 线索公海 ods_sasp.sasp_clue_sea
select company_name,company_address,contacts,contacts_mobile from ods_sasp.sasp_clue_sea;

---
-- 在三个区，未月结卡的
--
create table dm_gis_oms.dwm_sy_consignor_jjcs_recent_1y_mobile_tmp  as
select t0.consignor_mobile,consignor_city,consignor_city_cnt from
(
select  consignor_mobile,consignor_city,consignor_city_cnt  from dm_gis_oms.dwm_sy_consignor_jjcs_recent_1y_tmp
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区') or city in ('成都市','合肥市'))
) as t0
left join
(select  consignor_mobile  from dm_gis_oms.dwm_freight_consignor_mobile_recent_1y_tmp ) as t1
on t0.consignor_mobile=t1.consignor_mobile
where t1.consignor_mobile is null
;

--
-- 不在线索公海
--
create table dm_gis_oms.dwm_sy_consignor_jjcs_recent_1y_mobile_tmp1  as
select * from dm_gis_oms.dwm_sy_consignor_jjcs_recent_1y_mobile_tmp as t0
left join (select company_name,company_address,contacts,contacts_mobile from ods_sasp.sasp_clue_sea) as t1
on t0.consignor_mobile=t1.contacts_mobile
where t1.contacts_mobile is null
;


--
-- 线索池
--
drop table if exists dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_tmp;
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_tmp as
select t0.consignor_mobile,consignor_city,consignor_city_cnt,
t1.consigned_sd_cnt,t2.consignor_day_cnt,
t11.consigned_sd_cnt as consigned_sd_halfy_cnt,t21.consignor_day_cnt as consignor_day_halfy_cnt,
t12.consigned_sd_cnt as consigned_sd_1m_cnt,t22.consignor_day_cnt as consignor_day_1m_cnt,
t3.consignor_addr,t3.consignor_addr_cnt,t4.cons,t4.cons_cnt
 from  dm_gis_oms.dwm_sy_consignor_jjcs_recent_1y_mobile_tmp1 as t0
left join dm_gis_oms.dwm_sy_total_consignor_jjsdps_tmp as t1
on t0.consignor_mobile=t1.consignor_mobile
left join dm_gis_oms.dwm_sy_total_consignor_jjsdps_halfy_tmp as t11
on t0.consignor_mobile=t11.consignor_mobile
left join dm_gis_oms.dwm_sy_total_consignor_jjsdps_1m_tmp as t12
on t0.consignor_mobile=t12.consignor_mobile
left join dm_gis_oms.dwm_sy_consignor_jjsdts_tmp as t2
on t0.consignor_mobile=t2.consignor_mobile
left join dm_gis_oms.dwm_sy_consignor_jjsdts_halfy_tmp as t21
on t0.consignor_mobile=t21.consignor_mobile
left join dm_gis_oms.dwm_sy_consignor_jjsdts_1m_tmp as t22
on t0.consignor_mobile=t22.consignor_mobile
left join dm_gis_oms.dwm_sy_consignor_addr_1y_top1 as t3
on t0.consignor_mobile=t3.consignor_mobile
left join dm_gis_oms.dwm_sy_consignor_cons_1y_top1 as t4
on t0.consignor_mobile=t4.consignor_mobile
;


------ 每个城市取top300
add jar hdfs://sfbdp1/tmp/udf/01397450/97887/1000/decrypt-1.0.0.jar;
add file hdfs://sfbdp1//tmp/udf/sfencode/01416344/sfdencrpt.ini;
create temporary function new_decrypt as 'com.sf.udf.decrypt.Decrypt';


drop table if exists dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top300;
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top300 as
select consignor_mobile,consignor_city,consignor_city_cnt,consigned_sd_cnt,consignor_day_cnt,
consigned_sd_halfy_cnt,consignor_day_halfy_cnt,
consigned_sd_1m_cnt,consignor_day_1m_cnt,
new_decrypt(consignor_addr) as consignor_addr,consignor_addr_cnt,cons,cons_cnt
from (
select consignor_mobile,consignor_city,consigned_sd_cnt,consignor_day_cnt,consignor_city_cnt,
consigned_sd_halfy_cnt,consignor_day_halfy_cnt,
consigned_sd_1m_cnt,consignor_day_1m_cnt,
consignor_addr,consignor_addr_cnt,cons,cons_cnt,
row_number() over(partition by consignor_city order by consignor_city_cnt desc,consigned_sd_1m_cnt desc,consignor_day_1m_cnt desc) as rn
from
(
select consignor_mobile,consignor_city,consignor_city_cnt,consigned_sd_cnt,consignor_day_cnt,
    consigned_sd_halfy_cnt,consignor_day_halfy_cnt,
    consigned_sd_1m_cnt,consignor_day_1m_cnt,
    consignor_addr,consignor_addr_cnt,cons,cons_cnt
from dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_tmp
where consignor_city_cnt>=100
and consigned_sd_cnt is not null and consigned_sd_cnt>=100
and consignor_day_cnt is not null and consignor_day_cnt>=100
and consigned_sd_halfy_cnt is not null and consigned_sd_halfy_cnt>=50
and consignor_day_halfy_cnt is not null and consignor_day_halfy_cnt>=50
and consigned_sd_1m_cnt is not null and consigned_sd_1m_cnt>=8
and consignor_day_1m_cnt is not null and consignor_day_1m_cnt>=8
) as a ) as b where b.rn<=300
;

-- 挂上consignor_comp_name  和 电话姓名
drop table if exists dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top300_comp_name;
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top300_comp_name as
select t0.*,
consignor_comp_name,comp_name_cnt,
tel_decode,name
from dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top300 as t0
left join dm_gis_oms.tmp_clue_730_mobile_comp_name_top1 as t1
on t0.consignor_mobile=t1.consignor_mobile
left join dm_gis_oms.ods_tals_tel_base as t2
on t0.consignor_mobile=t2.tel
;

--



-- 加密导出
add jar hdfs://sfbdp1/tmp/udf/01397450/97887/1000/decrypt-1.0.0.jar;
add file hdfs://sfbdp1//tmp/udf/sfencode/01416344/sfdencrpt.ini;
create temporary function new_decrypt as 'com.sf.udf.decrypt.Decrypt';
add jar hdfs://sfbdp1//tmp/udf/01416344/112902/1001/tals-udf.jar;
create temporary function convertMD5 as 'com.sf.gis.java.tals.udf.Md5EncodeDecode';

select
consignor_mobile,consignor_city,consignor_city_cnt,consigned_sd_cnt,consignor_day_cnt,
consigned_sd_halfy_cnt,consignor_day_halfy_cnt,
consigned_sd_1m_cnt,consignor_day_1m_cnt,
convertMD5(consignor_addr) as consignor_addr,consignor_addr_cnt,cons,cons_cnt,
consignor_comp_name,comp_name_cnt,
case when tel_decode is not null then convertMD5(tel_decode) else convertMD5(new_decrypt(consignor_mobile)) end as tel_decode,name
 from dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top300_comp_name
 where consignor_mobile<>""
;


------------------------------------------------2022-08-08------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
-- 到付： 帅龙 ，仁济馨达健康药房，成都第五人民医院
-- 费用不达标： 游炜，林文扬，彭珊，张学鹏，金亮兵
-- 储值卡： 小何，李昌健
-- 微友寄： 王宏，吴悠勤，古与美学，兰晶华，高一格，杜松
-- 金手指： 张学鹏，王敬刘

create table dm_gis_oms.dwm_sy_consignor_clue_rmb_tmp_0810 as
select * from dm_gis_oms.dwm_sy_consignor_jjcs_rmb_tmp_nm
where consignor_mobile in
(select consignor_mobile from dm_gis_oms.dwm_sy_consignor_clue_recent_1y_mobile_top300_comp_name
where consignor_comp_name in ("帅龙" ,"仁济馨达健康药房","成都第五人民医院","游炜","林文扬","彭珊","张学鹏","金亮兵","小何","李昌健",
"王宏","吴悠勤","古与美学","兰晶华","高一格","杜松","张学鹏","王敬刘"
)
)


-- 最近n个月散单寄件票数： dm_gis_oms.dwm_sy_total_consignor_tmp_nm
-- 最近n个月散单寄件频次： dm_gis_oms.dwm_sy_consignor_jjsdts_tmp_nm
-- 最近n个月寄件手机各城市散单寄件量： dm_gis_oms.dwm_sy_consignor_jjcs_sd_tmp_nm
-- 最近n个月寄件手机各城市散单寄件频次： dm_gis_oms.dwm_sy_consignor_jjcssdts_tmp_nm
-- 最近n个月寄件手机各城市top1地址及寄件量(散单)： dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_nm   dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_1y dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_6m
-- 最近n个月寄件手机各城市top1托寄物及数量(散单)： dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_nm   dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_1y dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_6m
-- 最近n个月寄件手机各城市top1企业及数量(散单)：  dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_nm   dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_1y dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_6m
-- 最近n个月寄件手机各城市寄付现结费用、票数： dm_gis_oms.dwm_sy_consignor_jjcs_rmb_tmp_nm

-- 线索公海: ods_sasp.sasp_clue_sea
-- 储值卡用户数据：dm_fin_sfpay.sfpay_ncard_user_info
-- 微友寄用户数据：dwd.dwd_act_wfriend_mpp_user_info_df
-- 金手指用户数据：dm_sfai.jsz_jf_detail
-- 内部员工的表: dm_gis_edt.bs_inner_mobile

drop table if exists dm_gis_oms.dwm_sy_consignor_clue_0810;
create table  dm_gis_oms.dwm_sy_consignor_clue_0810 as
select
t0.consignor_mobile,t0.consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
addr_1y,addr_cnt_1y,addr_6m,addr_cnt_6m,addr_3m,addr_cnt_3m,addr_1m,addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y
from
(select consignor_mobile,consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_sd_tmp_nm
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t0
left join
(select consignor_mobile,src_dist_code,consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcssdts_tmp_nm
where src_dist_code in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t1
on  t0.consignor_mobile=t1.consignor_mobile and t0.consignor_city=t1.src_dist_code
left join
(select consignor_mobile,consignor_city,addr_1y,addr_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_1y
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t21
on  t0.consignor_mobile=t21.consignor_mobile and t0.consignor_city=t21.consignor_city
left join
(select consignor_mobile,consignor_city,addr_6m,addr_cnt_6m
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_6m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t22
on  t0.consignor_mobile=t22.consignor_mobile and t0.consignor_city=t22.consignor_city
left join
(select consignor_mobile,consignor_city,addr_3m,addr_cnt_3m
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_3m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t23
on  t0.consignor_mobile=t23.consignor_mobile and t0.consignor_city=t23.consignor_city
left join
(select consignor_mobile,consignor_city,addr_1m,addr_cnt_1m
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_1m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t24
on  t0.consignor_mobile=t24.consignor_mobile and t0.consignor_city=t24.consignor_city
left join
(select consignor_mobile,consignor_city,cons_1y,cons_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_1y
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t31
on  t0.consignor_mobile=t31.consignor_mobile and t0.consignor_city=t31.consignor_city
left join
(select consignor_mobile,consignor_city,cons_6m,cons_cnt_6m
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_6m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t32
on  t0.consignor_mobile=t32.consignor_mobile and t0.consignor_city=t32.consignor_city
left join
(select consignor_mobile,consignor_city,cons_3m,cons_cnt_3m
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_3m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t33
on  t0.consignor_mobile=t33.consignor_mobile and t0.consignor_city=t33.consignor_city
left join
(select consignor_mobile,consignor_city,cons_1m,cons_cnt_1m
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_1m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t34
on  t0.consignor_mobile=t34.consignor_mobile and t0.consignor_city=t34.consignor_city
left join
(select consignor_mobile,consignor_city,comp_name_1y,comp_name_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_1y
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t41
on  t0.consignor_mobile=t41.consignor_mobile and t0.consignor_city=t41.consignor_city
left join
(select consignor_mobile,consignor_city,comp_name_6m,comp_name_cnt_6m
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_6m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t42
on  t0.consignor_mobile=t42.consignor_mobile and t0.consignor_city=t42.consignor_city
left join
(select consignor_mobile,consignor_city,comp_name_3m,comp_name_cnt_3m
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_3m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t43
on  t0.consignor_mobile=t43.consignor_mobile and t0.consignor_city=t43.consignor_city
left join
(select consignor_mobile,consignor_city,comp_name_1m,comp_name_cnt_1m
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_1m
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t44
on  t0.consignor_mobile=t44.consignor_mobile and t0.consignor_city=t44.consignor_city
left join
(select consignor_mobile,consignor_city,consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_rmb_tmp_nm
where consignor_city in (select citycode from dm_gis.city_name_map where region in ('上海区','北京区') or city in ('成都市','自贡市','攀枝花市','泸州市','合肥市','芜湖市','阜阳市','蚌埠市','苏州市','南京市','无锡市','南通市','沈阳市','大连市','鞍山市','抚顺市','武汉市','宜昌市','随州市','孝感市'))
) as t5
on  t0.consignor_mobile=t5.consignor_mobile and t0.consignor_city=t5.consignor_city
;

-- 有月结卡号的寄件手机号  dm_gis_oms.dwm_freight_consignor_mobile_mi  dm_gis_oms.dwm_freight_consignor_mobile_recent_1y_tmp （近一年）
--
drop table if exists dm_gis_oms.dwm_freight_consignor_mobile_recent_1y_tmp;
create table dm_gis_oms.dwm_freight_consignor_mobile_recent_1y_tmp as
select freight_monthly_acct_code,consignor_mobile,sum(consignor_mobile_cnt) as consignor_mobile_cnt
from dm_gis_oms.dwm_freight_consignor_mobile_mi
where inc_day>='202101' and inc_day<='202209'
group by freight_monthly_acct_code,consignor_mobile
;


-- 线索公海: ods_sasp.sasp_clue_sea                        inc_day='所有分区' company_name,company_address,contacts,contacts_mobile
-- 储值卡用户数据：dm_fin_sfpay.sfpay_ncard_user_info       card_status='ACTIVE'  mobile_no_kj
-- 微友寄用户数据：dwd.dwd_act_wfriend_mpp_user_info_df     inc_day='当前分区' status='1'  mobile
-- 金手指用户数据：dm_sfai.jsz_jf_detail                    inc_day='近一个月' status='USED'   cust_mobile
-- 月结客户信息维表：dm_gis_oms.ods_customer_info_df        decission_maker_mobile_phone       customer_code,billing_status,valid_date,invalid_date,full_name,short_name,decission_maker_mobile_phone,area_name,new_old_cust
-- 内部员工的表: dm_gis_edt.bs_inner_mobile

drop table if exists dm_gis_oms.dwm_freight_consignor_mobile_filter_tmp;
create table dm_gis_oms.dwm_freight_consignor_mobile_filter_tmp as
select contacts_mobile as mobile from ods_sasp.sasp_clue_sea
union all
select mobile from (select mobile_no_kj as mobile from dm_fin_sfpay.sfpay_ncard_user_info where card_status='ACTIVE' group by mobile_no_kj) as t1
union all
select mobile from (select mobile  from dwd.dwd_act_wfriend_mpp_user_info_df where inc_day='20221001' and status='1' group by mobile) as t2
union all
select mobile from (select cust_mobile as mobile from dm_sfai.jsz_jf_detail where inc_day>='20220901'  and  status='USED' group by cust_mobile) as t3
union all
select mobile from (select  decission_maker_mobile_phone as mobile from  dm_gis_oms.ods_customer_info_df group by decission_maker_mobile_phone) as t4
union all
select mobile from dm_gis_edt.bs_inner_mobile as t5
;



---- 候选集1（过滤项）
drop table dm_gis_oms.dwm_freight_consignor_mobile_candidate_tmp1 ;
create table dm_gis_oms.dwm_freight_consignor_mobile_candidate_tmp1 as
select
t0.consignor_mobile,t0.consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
addr_1y,addr_cnt_1y,addr_6m,addr_cnt_6m,addr_3m,addr_cnt_3m,addr_1m,addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y
from dm_gis_oms.dwm_sy_consignor_clue_0810 as t0
left join
(select consignor_mobile as mobile from dm_gis_oms.dwm_freight_consignor_mobile_recent_1y_tmp
union all
select mobile from dm_gis_oms.dwm_freight_consignor_mobile_filter_tmp group by mobile
) as t1
on t0.consignor_mobile=t1.mobile
where t1.mobile is null
;


---- 候选集2 (成都竟对数据)
drop table dm_gis_oms.dwm_freight_consignor_mobile_candidate_tmp2 ;
create table dm_gis_oms.dwm_freight_consignor_mobile_candidate_tmp2 as
select
t0.consignor_mobile,t0.consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
addr_1y,addr_cnt_1y,addr_6m,addr_cnt_6m,addr_3m,addr_cnt_3m,addr_1m,addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y,
t1.cnt
from dm_gis_oms.dwm_freight_consignor_mobile_candidate_tmp1 as t0
left join  (select consignor_mobile,consignor_city,cnt from dm_gis_oms.dwm_sy_consignor_jjcs_addr_chengdu_match_addr) as t1
on t0.consignor_mobile=t1.consignor_mobile and t0.consignor_city=t1.consignor_city
;



---- 取top300 (未用成都竟对)
drop table if exists dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300 ;
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300 as
select
consignor_mobile,consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
addr_1y,addr_cnt_1y,addr_6m,addr_cnt_6m,addr_3m,addr_cnt_3m,addr_1m,addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y
from (
select
consignor_mobile,consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
addr_1y,addr_cnt_1y,addr_6m,addr_cnt_6m,addr_3m,addr_cnt_3m,addr_1m,addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y,
row_number() over(partition by consignor_city order by consignor_day_cnt_1m desc) as rn
from dm_gis_oms.dwm_freight_consignor_mobile_candidate_tmp1
where consignor_city_cnt_1m>=5 and consignor_day_cnt_1m>=5 and consignor_rmb_1m>=500
) as t where t.rn<=400
;


---- 取top300 (用上成都竟对)
drop table if exists dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300_jd ;
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300_jd as
select
consignor_mobile,consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
addr_1y,addr_cnt_1y,addr_6m,addr_cnt_6m,addr_3m,addr_cnt_3m,addr_1m,addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y,
cnt
from (
select
consignor_mobile,consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
addr_1y,addr_cnt_1y,addr_6m,addr_cnt_6m,addr_3m,addr_cnt_3m,addr_1m,addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y,cnt,
row_number() over(partition by consignor_city order by cnt desc) as rn
from dm_gis_oms.dwm_freight_consignor_mobile_candidate_tmp2
where consignor_city_cnt_1m>=5 and consignor_day_cnt_1m>=5 and consignor_rmb_1m>=500
and  consignor_city='028'
) as t where t.rn<=400
;



---- 导出候选线索
--先挂上电话和姓名,在用base64加密
add jar hdfs://sfbdp1/tmp/udf/01397450/97887/1000/decrypt-1.0.0.jar;
add file hdfs://sfbdp1//tmp/udf/sfencode/01416344/sfdencrpt.ini;
create temporary function new_decrypt as 'com.sf.udf.decrypt.Decrypt';

drop table if exists dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300_res;
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300_res as
select
consignor_mobile,
base64(cast(new_decrypt(consignor_mobile) as binary)) as consignor_mobile_jm,
consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
base64(cast(addr_1y as binary)) as addr_1y,
addr_cnt_1y,
base64(cast(addr_6m as binary)) as addr_6m,
addr_cnt_6m,
base64(cast(addr_3m as binary)) as addr_3m,
addr_cnt_3m,
base64(cast(addr_1m as binary)) as addr_1m,
addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y,
base64(cast(t2.tel_decode as binary)) as tel_decode,t2.name
from dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300 as t0
left join dm_gis_oms.ods_tals_tel_base as t2
on t0.consignor_mobile=t2.tel
;



drop table if exists dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300_jd_res;
create table dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300_jd_res as
select
consignor_mobile,
base64(cast(new_decrypt(consignor_mobile) as binary)) as consignor_mobile_jm,
consignor_city,consignor_city_cnt_1m,consignor_city_cnt_3m,consignor_city_cnt_6m,consignor_city_cnt_1y,
consignor_day_cnt_1m,consignor_day_cnt_3m,consignor_day_cnt_6m,consignor_day_cnt_1y,
base64(cast(addr_1y as binary)) as addr_1y,
addr_cnt_1y,
base64(cast(addr_6m as binary)) as addr_6m,
addr_cnt_6m,
base64(cast(addr_3m as binary)) as addr_3m,
addr_cnt_3m,
base64(cast(addr_1m as binary)) as addr_1m,
addr_cnt_1m,
cons_1y,cons_cnt_1y,cons_6m,cons_cnt_6m,cons_3m,cons_cnt_3m,cons_1m,cons_cnt_1m,
comp_name_1y,comp_name_cnt_1y,comp_name_6m,comp_name_cnt_6m,comp_name_3m,comp_name_cnt_3m,comp_name_1m,comp_name_cnt_1m,
consignor_rmb_1m,consignor_rmb_3m,consignor_rmb_6m,consignor_rmb_1y,consignor_cnt_1m,consignor_cnt_3m,consignor_cnt_6m,consignor_cnt_1y,cnt,
base64(cast(t2.tel_decode as binary)) as tel_decode,t2.name
from dm_gis_oms.dwm_sy_consignor_clue_recent_1m_tmp_top300_jd as t0
left join dm_gis_oms.ods_tals_tel_base as t2
on t0.consignor_mobile=t2.tel
;






------------------------------------------------------------------------
------------------------------------------------------------------------
-- 线索公海已分配、已处理的线索，线下是否有签月结未反馈确认

select * from ods_sasp.sasp_clue_sea where inc_day>='20220802' and clue_source='1364' and handle_status in ('1964','1965')

-- DEEQAVTspFOuW30XtoC32ZiXFs7mw%3D  阮永
-- select * from dim.dim_customer_info_df where inc_day='20220822' and decission_maker_mobile_phone='DEEQAVTspFOuW30XtoC32ZiXFs7mw%3D' limit 10

drop table if exists dm_gis_oms.tmp_clue_0823_sucess;
drop table if exists dm_gis_oms.tmp_clue_0823_mobile_sucess;
create table dm_gis_oms.tmp_clue_0823_mobile_sucess as
select company_name,city_code,company_address,contacts,contacts_mobile,clue_source,handle_status,inc_day,
customer_code,billing_status,valid_date,invalid_date,full_name,short_name,decission_maker_mobile_phone,area_name,new_old_cust
from (
select
company_name,city_code,company_address,contacts,contacts_mobile,clue_source,handle_status,inc_day
from (
select company_name,city_code,company_address,contacts,contacts_mobile,clue_source,handle_status,inc_day,
row_number() over(partition by contacts_mobile order by inc_day)  as rn
from ods_sasp.sasp_clue_sea where inc_day>='20220802' and clue_source='1364' and handle_status in ('1964','1965')
) as t where t.rn=1
) as t0
left join
(select customer_code,billing_status,valid_date,invalid_date,full_name,short_name,decission_maker_mobile_phone,area_name,new_old_cust
 from dim.dim_customer_info_df
where inc_day='20220823' and  valid_date>='2022-08-02') as t1
on t0.contacts_mobile=t1.decission_maker_mobile_phone
;

drop table if exists dm_gis_oms.tmp_clue_0823_name_sucess;
create table dm_gis_oms.tmp_clue_0823_name_sucess as
select company_name,city_code,company_address,contacts,contacts_mobile,clue_source,handle_status,inc_day,
customer_code,billing_status,valid_date,invalid_date,full_name,short_name,decission_maker_mobile_phone,area_name,new_old_cust
from (
select
company_name,city_code,company_address,contacts,contacts_mobile,clue_source,handle_status,inc_day
from (
select company_name,city_code,company_address,contacts,contacts_mobile,clue_source,handle_status,inc_day,
row_number() over(partition by contacts_mobile order by inc_day)  as rn
from ods_sasp.sasp_clue_sea where inc_day>='20220802' and clue_source='1364' and handle_status in ('1964','1965')
) as t where t.rn=1
) as t0
left join
(select customer_code,billing_status,valid_date,invalid_date,full_name,short_name,decission_maker_mobile_phone,area_name,new_old_cust
 from dim.dim_customer_info_df
where inc_day='20220823' and  valid_date>='2022-08-02' ) as t1
on t0.company_name=t1.full_name
;