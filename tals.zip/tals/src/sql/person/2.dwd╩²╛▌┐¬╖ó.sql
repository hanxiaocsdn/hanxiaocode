-- dw开发
-- consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
-- consigned_tm,src_dist_code,src_province,consignor_addr,
-- signin_tm,dest_dist_code,dest_province,consignee_addr,
-- freight_monthly_acct_code,freight_settlement_type_code,consignor_comp_name,
-- waybill_no,transport_type_code,
-- limit_type_code,all_fee_rmb,freight_payment_type_code,
-- freight_payment_change_type_code,comb_payment_type_code,
-- is_value_insured,service_prod_code,self_send_flag,self_pickup_flag,cons_name

-- 创建dm_gis_oms.dwd_sy_order_info_di
create table dm_gis_oms.dwd_sy_order_info_di (
consignor_mobile string,
consignor_cont_name string,
consignee_mobile string,
consignee_cont_name string,
consigned_tm string,
src_dist_code string,
src_province string,
consignor_addr string,
signin_tm string,
dest_dist_code string,
dest_province string,
consignee_addr string,
freight_monthly_acct_code string,
freight_settlement_type_code string,
consignor_comp_name string,
waybill_no string,
transport_type_code string,
limit_type_code string,
all_fee_rmb double,
freight_payment_type_code string,
freight_payment_change_type_code string,
comb_payment_type_code string,
is_value_insured int,
service_prod_code array<string>, 
self_send_flag string,
self_pickup_flag string,
cons_name array<string>
)
COMMENT '新运单宽表明细'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 写数据
set mapreduce.job.queuename=gis;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;

insert overwrite table dm_gis_oms.dwd_sy_order_info_di partition(inc_day)
select 
consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name,
consigned_tm,src_dist_code,src_province,consignor_addr,
signin_tm,dest_dist_code,dest_province,consignee_addr,
freight_monthly_acct_code,freight_settlement_type_code,consignor_comp_name,
waybill_no,transport_type_code,
limit_type_code,all_fee_rmb,freight_payment_type_code,
freight_payment_change_type_code,comb_payment_type_code,
is_value_insured,service_prod_code,self_send_flag,self_pickup_flag,cons_name
,inc_day 
from 
dm_gis_oms.ods_sy_order_info_di 
where waybill_no is not null and length(waybill_no)>4  
and consigned_tm is not null and consigned_tm<>'' 
and signin_tm is not null and signin_tm<>'' 
and inc_day='$[time(yyyyMMdd,-2d)]'
;




