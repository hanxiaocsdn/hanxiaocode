-- 
-- 所有寄件人和收件人统计量
所有寄件人的寄件量的最小值
所有寄件人的寄件量的1/4分位数
所有寄件人的寄件量的中位数
所有寄件人的寄件量的3/4分位数
所有寄件人的寄件量的平均值
所有寄件人的寄件量的最大值
所有寄件人的散单寄件量的最小值
所有寄件人的散单寄件量的1/4分位数
所有寄件人的散单寄件量的中位数
所有寄件人的散单寄件量的3/4分位数
所有寄件人的散单寄件量的平均值
所有寄件人的散单寄件量的最大值
所有收件人的收件量的最小值
所有收件人的收件量的1/4分位数
所有收件人的收件量的中位数
所有收件人的收件量的3/4分位数
所有收件人的收件量的平均值
所有收件人的收件量的最大值
所有收件人的散单收件量的最小值
所有收件人的散单收件量的1/4分位数
所有收件人的散单收件量的中位数
所有收件人的散单收件量的3/4分位数
所有收件人的散单收件量的平均值
所有收件人的散单收件量的最大值

drop table if exists dm_gis_oms.dws_all_consignor_jj_tmp;
create table dm_gis_oms.dws_all_consignor_jj_tmp as 
select percentile(consigned_cnt,array(0.25,0.5,0.75)) as percentile_jj,avg(consigned_cnt) as avg_jj,min(consigned_cnt) as min_jj,max(consigned_cnt) as max_jj from (
select tel,consigned_cnt from dm_gis_oms.dws_sy_order_bw1 where consigned_cnt is not null and consigned_cnt>0
) as tmp  
;

create table dm_gis_oms.dws_all_consignor_jj_tmp1 as 
select *  from dm_gis_oms.dws_sy_order_bw1 where consigned_cnt is not null and consigned_cnt>1000000;


drop table if exists dm_gis_oms.dws_all_consignor_sd_tmp;
create table dm_gis_oms.dws_all_consignor_sd_tmp as 
select percentile(consigned_sd_cnt,array(0.25,0.5,0.75)) as percentile_sd,avg(consigned_sd_cnt) as avg_sd,min(consigned_sd_cnt) as min_sd,max(consigned_sd_cnt) as max_sd from (
select tel,consigned_sd_cnt from dm_gis_oms.dws_sy_order_bw1 where consigned_sd_cnt is not null and consigned_sd_cnt>0
) as tmp  
;

drop table if exists dm_gis_oms.dws_all_consignee_jj_tmp;
create table dm_gis_oms.dws_all_consignee_jj_tmp as 
select percentile(consignee_cnt,array(0.25,0.5,0.75)) as percentile_jj,avg(consignee_cnt) as avg_jj,min(consignee_cnt) as min_jj,max(consignee_cnt) as max_jj from (
select tel,consignee_cnt from dm_gis_oms.dws_sy_order_bw1 where consignee_cnt is not null and consignee_cnt>0
) as tmp  
;

drop table if exists dm_gis_oms.dws_all_consignee_sd_tmp;
create table dm_gis_oms.dws_all_consignee_sd_tmp as 
select percentile(consignee_sd_cnt,array(0.25,0.5,0.75)) as percentile_sd,avg(consignee_sd_cnt) as avg_sd,min(consignee_sd_cnt) as min_sd,max(consignee_sd_cnt) as max_sd from (
select tel,consignee_sd_cnt from dm_gis_oms.dws_sy_order_bw1 where consignee_sd_cnt is not null and consignee_sd_cnt>0
) as tmp  
;


---- 增加年度汇总
drop table if exists dm_gis_oms.dws_all_stat_year;
create table dm_gis_oms.dws_all_stat_year
(
stat_year string,
percentile_jj array<double>,
avg_jj int,
min_jj int,
max_jj int,
percentile_sd array<double>,
avg_sd int,
min_sd int,
max_sd int,
percentile_sj array<double>,
avg_sj int,
min_sj int,
max_sj int,
percentile_sjsd array<double>,
avg_sjsd int,
min_sjsd int,
max_sjsd int,
percentile_rmb array<double>,
avg_rmb int,
min_rmb int,
max_rmb int
)
comment '所有寄件人和收件人统计量'
;

-- 累计寄件数量（年_临时）
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_total_consignor_y_tmp;
create table dm_gis_oms.dwm_sy_total_consignor_y_tmp as
select consignor_mobile,
sum(consigned_cnt) as consigned_cnt,
sum(consigned_jf_cnt) as consigned_jf_cnt,
sum(consigned_df_cnt) as consigned_df_cnt,
sum(consigned_dsff_cnt) as consigned_dsff_cnt,
sum(consigned_sd_cnt) as consigned_sd_cnt,
sum(self_send_cnt) as self_send_cnt,
sum(self_pickup_cnt) as self_pickup_cnt
from dm_gis_oms.dwm_sy_total_consignor_mi
where inc_day>=202101 and inc_day<202201
group by consignor_mobile
;

-- 累计收件数量（年_临时）
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_total_consignee_y_tmp;
create table dm_gis_oms.dwm_sy_total_consignee_y_tmp as
select consignee_mobile,
sum(consignee_cnt) as consignee_cnt,
sum(consignee_sd_cnt) as consignee_sd_cnt
from dm_gis_oms.dwm_sy_total_consignee_mi
where inc_day>=202101 and inc_day<202201
group by consignee_mobile
;

-- 费用（年_临时）
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_total_consignor_tm_rmb_y_tmp;
create table dm_gis_oms.dwm_sy_total_consignor_tm_rmb_y_tmp as
select consignor_mobile,
sum(total_rmb) as total_rmb,
sum(total_jf_rmb) as total_jf_rmb,
sum(total_df_rmb) as total_df_rmb,
sum(total_sff_rmb) as total_sff_rmb
from dm_gis_oms.dwm_sy_total_consignor_tm_rmb_mi
where inc_day>=202101 and inc_day<202201
group by consignor_mobile
;

--

insert into dm_gis_oms.dws_all_stat_year 
select t0.stat_year,percentile_jj,avg_jj,min_jj,max_jj,percentile_sd,avg_sd,min_sd,max_sd,percentile_sj,avg_sj,min_sj,max_sj,percentile_sjsd,avg_sjsd,min_sjsd,max_sjsd,
percentile_rmb,avg_rmb,min_rmb,max_rbm
from(
select '2021' as stat_year,percentile(consigned_cnt,array(0.25,0.5,0.75)) as percentile_jj,avg(consigned_cnt) as avg_jj,min(consigned_cnt) as min_jj,max(consigned_cnt) as max_jj
from dm_gis_oms.dwm_sy_total_consignor_y_tmp where consigned_cnt is not null and consigned_cnt>0 ) as t0
left join (
select '2021' as stat_year,percentile(consigned_sd_cnt,array(0.25,0.5,0.75)) as percentile_sd,avg(consigned_sd_cnt) as avg_sd,min(consigned_sd_cnt) as min_sd,max(consigned_sd_cnt) as max_sd
from dm_gis_oms.dwm_sy_total_consignor_y_tmp where  consigned_sd_cnt is not null and consigned_sd_cnt>0 ) as t1
on t0.stat_year=t1.stat_year
left join (
select '2021' as stat_year,percentile(consignee_cnt,array(0.25,0.5,0.75)) as percentile_sj,avg(consignee_cnt) as avg_sj,min(consignee_cnt) as min_sj,max(consignee_cnt) as max_sj
from dm_gis_oms.dwm_sy_total_consignee_y_tmp where  consignee_cnt is not null and consignee_cnt>0 ) as t2
on t0.stat_year=t2.stat_year 
left join (
select '2021' as stat_year,percentile(consignee_sd_cnt,array(0.25,0.5,0.75)) as percentile_sjsd,avg(consignee_sd_cnt) as avg_sjsd,min(consignee_sd_cnt) as min_sjsd,max(consignee_sd_cnt) as max_sjsd
from dm_gis_oms.dwm_sy_total_consignee_y_tmp where  consignee_sd_cnt is not null and consignee_sd_cnt>0 ) as t3
on t0.stat_year=t3.stat_year
left join (
select '2021' as stat_year,percentile(cast(total_rmb as bigint),array(0.25,0.5,0.75)) as percentile_rmb,avg(total_rmb) as avg_rmb,min(total_rmb) as min_rmb,max(total_rmb) as max_rbm
from dm_gis_oms.dwm_sy_total_consignor_tm_rmb_y_tmp where  total_rmb is not null and total_rmb>0 ) as t4
on t0.stat_year=t4.stat_year
;



create table dm_gis_oms.dws_all_consignor_jjsd_tmp1 as 
select *  from dm_gis_oms.dws_sy_order_bw1 where consigned_sd_cnt is not null and consigned_sd_cnt>100000;



