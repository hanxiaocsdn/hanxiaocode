-- dwm层
-- 1.tel,name
-- dm_gis_oms.ods_tals_tel_base
电话
姓名



-- 2. consignor_mobile,consignor_cont_name,consignee_mobile,consignee_cont_name
寄件常用名Top3
收件常用名Top3

-- dm_gis_oms.dwm_sy_consignor_name_mi寄件人姓名寄件次数(每月)
create table dm_gis_oms.dwm_sy_consignor_name_mi(
consignor_mobile string comment '寄件手机',
consignor_cont_name string comment '寄件人姓名',
consignor_name_cnt int comment '寄件人姓名次数'
)
comment '寄件人姓名次数'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

insert overwrite table dm_gis_oms.dwm_sy_consignor_name_mi partition(inc_day='202204') 
select  consignor_mobile,consignor_cont_name,count(1) as consignor_name_cnt  
from  dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4 
group by consignor_mobile,consignor_cont_name
;

--shell脚本
#!/bin/sh

firstDay='20200101'
endDay='20220501'
echo $firstDay $endDay 

while (( $firstDay < $endDay ))
      do
        echo $firstDay
        Param0=`date -d "+0 month $firstDay" +%Y%m`
        Param1=$firstDay
        Param2=`date -d "+1 month $firstDay" +%Y%m%d`
        echo $Param0 $Param1 $Param2

       hive -e 'set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
insert overwrite table dm_gis_oms.dwm_sy_consignor_name_mi partition(inc_day='$Param0') 
select  consignor_mobile,consignor_cont_name,count(1) as consignor_name_cnt  
from  dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='$Param1' and inc_day<'$Param2' 
and length(consignor_mobile)>4 
group by consignor_mobile,consignor_cont_name
;' 

        firstDay=`date -d "+1 month $firstDay" +%Y%m%d`

    done


-- dm_gis_oms.dwm_sy_consignor_name_tmp 寄件手机寄件人寄件次数top3临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignor_name_tmp;
create table dm_gis_oms.dwm_sy_consignor_name_tmp as 
select consignor_mobile,consignor_cont_name,consignor_name_cnt from (
select consignor_mobile,consignor_cont_name,consignor_name_cnt,row_number() over(partition by consignor_mobile order by consignor_name_cnt desc) as rn 
 from (
select consignor_mobile,consignor_cont_name,sum(consignor_name_cnt) as consignor_name_cnt from dm_gis_oms.dwm_sy_consignor_name_mi 
where inc_day<='202204'
group by consignor_mobile,consignor_cont_name
) as a 
) as a1 where a1.rn<=3
;


-- dm_gis_oms.dwm_sy_consignee_name_mi 收件人姓名收件次数(每月)
create table dm_gis_oms.dwm_sy_consignee_name_mi(
consignee_mobile string comment '收件手机',
consignee_cont_name string comment '收件人姓名',
consignee_name_cnt int comment '收件人姓名次数'
)
comment '收件人姓名次数'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

insert overwrite table dm_gis_oms.dwm_sy_consignee_name_mi partition(inc_day='202204') 
select  consignee_mobile,consignee_cont_name,count(1) as consignee_name_cnt  
from  dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignee_mobile)>4 
group by consignee_mobile,consignee_cont_name
;

-- dm_gis_oms.dwm_sy_consignee_name_tmp 收件手机收件人收件次数top3临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignee_name_tmp;
create table dm_gis_oms.dwm_sy_consignee_name_tmp as 
select consignee_mobile,consignee_cont_name,consignee_name_cnt from (
select consignee_mobile,consignee_cont_name,consignee_name_cnt,row_number() over(partition by consignee_mobile order by consignee_name_cnt desc) as rn 
 from (
select consignee_mobile,consignee_cont_name,sum(consignee_name_cnt) as consignee_name_cnt from dm_gis_oms.dwm_sy_consignee_name_mi 
where inc_day<='202204'
group by consignee_mobile,consignee_cont_name
) as a 
) as a1 where a1.rn<=3
;






-- 3. 
性别
年龄
年龄段
出生年月
婚姻状况
最高教育程度
籍贯







-- 4. consigned_tm,src_dist_code,src_city_code,src_province,consignor_addr,
--  signin_tm,dest_dist_code,dest_city_code,dest_province,consignee_addr,
-- freight_monthly_acct_code, freight_settlement_type_code,consignor_comp_name
家乡
用户足迹
常住城市
常住城市所在省市
常住城市最后一次收寄的日期
居住地址
工作地址
公司
所在行业


---- 常住临时表
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;
drop table if exists dm_gis_oms.dwm_tel_czcs_tmp;
create table dm_gis_oms.dwm_tel_czcs_tmp  as 
select 
t1.tel  tel1,t1.city city1,t1.citycode citycode1,t1.province province1,t1.addr addr1,t1.addr_type addr_type1,t1.date_sign date_sign1,
t2.tel tel2,t2.city city2,t2.citycode citycode2,t2.province province2,t2.addr addr2,t2.addr_type addr_type2,t2.date_sign date_sign2 
from (
select tel,city,citycode,province,addr,addr_type,date_sign 
from (
select  tel,city,citycode,province,addr,addr_type,date_sign,row_number() over(partition by tel order by date_sign desc) as rn 
from dm_gis.tals_city_permanent_final 
where date_confirm<20220501 
and (substr(addr_type,1,4)='1203' or addr_type in ('120203','190108','190400','190401') )
) as a where a.rn=1
) as t1 
full outer join (
select tel,city,citycode,province,addr,addr_type,date_sign 
from (
select  tel,city,citycode,province,addr,addr_type,date_sign,row_number() over(partition by tel order by date_sign desc) as rn 
from dm_gis.tals_city_permanent_final 
where date_confirm<20220501 
and (substr(addr_type,1,4)!='1203' and addr_type not in ('120203','190108','190400','190401') )
) as b where b.rn=1
) as t2 
on t1.tel=t2.tel
;


create table dm_gis_oms.dwm_tel_czcs_tmp1 as 
select 
case when date_sign1 is not null and date_sign2 is not null and date_sign1>date_sign2 then tel1 
     when date_sign1 is not null then tel1 else tel2 end as tel,
case when date_sign1 is not null and date_sign2 is not null and date_sign1>date_sign2 then city1 
     when date_sign1 is not null then city1 else city2 end as city,
case when date_sign1 is not null and date_sign2 is not null and date_sign1>date_sign2 then citycode1 
     when date_sign1 is not null then citycode1 else citycode2 end as citycode,
case when date_sign1 is not null and date_sign2 is not null and date_sign1>date_sign2 then province1 
     when date_sign1 is not null then province1 else province2 end as province,
case when date_sign1 is not null and date_sign2 is not null and date_sign1>date_sign2 then date_sign1 
     when date_sign1 is not null then date_sign1 else date_sign2 end as date_sign,
addr1 as czdz,
addr2 as gsdz
from dm_gis_oms.dwm_tel_czcs_tmp;

---- 公司
---- dm_gis_oms.dwm_sy_company_halfyear_mi 寄件手机公司(近半年)
create table dm_gis_oms.dwm_sy_company_halfyear_mi(
consignor_mobile string comment '寄件手机',
consignor_comp_name string comment '寄件公司',
freight_monthly_acct_code string comment '运费月结账号',
consigned_tm string comment '收件人姓名'
)
comment '寄件手机公司'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');


insert overwrite table dm_gis_oms.dwm_sy_company_halfyear_mi partition(inc_day='030')  
select consignor_mobile,consignor_comp_name,freight_monthly_acct_code,consigned_tm  
from (
select consignor_mobile,consignor_comp_name,freight_monthly_acct_code,consigned_tm,row_number() over(partition by consignor_mobile order by consigned_tm desc) as rn 
from (
select consignor_mobile,consignor_comp_name,freight_monthly_acct_code,consigned_tm   
from  dm_gis_oms.dwd_sy_order_info_di  
where inc_day>=from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('20220501','yyyyMMdd')), 30),'yyyy-MM-dd'),'yyyyMMdd') 
and inc_day<from_unixtime(unix_timestamp(date_sub(from_unixtime(unix_timestamp('20220501','yyyyMMdd')), 0),'yyyy-MM-dd'),'yyyyMMdd') 
and length(consignor_mobile)>4 
and length(consignor_comp_name)>1 
and freight_settlement_type_code=2
) as tmp 
) as a where a.rn=1
;

---- dm_gis_oms.dwm_sy_company_halfyear_tmp 寄件手机公司(近半年)临时表
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

drop table if exists dm_gis_oms.dwm_sy_company_halfyear_tmp;
create table dm_gis_oms.dwm_sy_company_halfyear_tmp as 
select consignor_mobile,consignor_comp_name,freight_monthly_acct_code 
from (
select consignor_mobile,consignor_comp_name,freight_monthly_acct_code,row_number() over(partition by consignor_mobile order by consigned_tm  desc) as rn 
from   dm_gis_oms.dwm_sy_company_halfyear_mi  
) as a where a.rn=1
;

-- 5. waybill_no,transport_type_code,freight_monthly_acct_code,freight_settlement_type_code,src_city_code
--   waybill_no,freight_settlement_type_code
近1个月寄件量
近3个月寄件量
近6个月寄件量
近1年寄件量
近1个月收件量
近3个月收件量
近6个月收件量
近1年收件量
近6个月寄收比
近1年寄收比
近3个月周末寄件量
近3个月周末寄件量占比
近6个月周末寄件量
近6个月周末寄件量占比
近1年周末寄件量
近1年周末寄件量占比
近1个月空运寄件量
近1个月陆运寄件量
近3个月空运寄件量
近3个月陆运寄件量
近6个月空运寄件量
近6个月陆运寄件量
近1年空运寄件量
近1年陆运寄件量
近1个月空运寄件量占比
近1个月陆运寄件量占比
近1个月散单寄件量
近3个月散单寄件量
近6个月散单寄件量
近1年散单寄件量
近1个月散单收件量
近3个月散单收件量
近6个月散单收件量
近1年散单收件量
近6个月散单寄收比
近1年散单寄收比
近3个月周末散单寄件量
近3个月周末散单寄件量占比
近6个月周末散单寄件量
近6个月周末散单寄件量占比
近1年周末散单寄件量
近1年周末散单寄件量占比
近1个月空运散单寄件量
近1个月陆运散单寄件量
近3个月空运散单寄件量
近3个月陆运散单寄件量
近6个月空运散单寄件量
近6个月陆运散单寄件量
近1年空运散单寄件量
近1年陆运散单寄件量
近1个月空运散单寄件量占比
近1个月陆运散单寄件量占比
近6个月最近一次使用的月结卡号
近6个月最近一次使用月结卡号的时间
近6个月寄件保价的运单量
近1年寄件保价的运单量


-- dm_gis_oms.dwm_user_send_year5  李宇成开发
-- 寄件
select consignor_mobile,
sum(case when datediff('2022-04-01 00:00:00',consigned_tm)<=30 then 1 else 0 end) as consignor_cnt_30,
sum(case when datediff('2022-04-01 00:00:00',consigned_tm)<=90 then 1 else 0 end) as consignor_cnt_90,
sum(case when datediff('2022-04-01 00:00:00',consigned_tm)<=180 then 1 else 0 end) as consignor_cnt_180,
sum(case when datediff('2022-04-01 00:00:00',consigned_tm)<=365 then 1 else 0 end) as consignor_cnt_365,

from  dm_gis_oms.dwd_sy_order_info_di 
where inc_day>='' 
group by consignor_mobile


-- 收件
select consignor_mobile,
sum(case when datediff('2022-04-01 00:00:00',consigned_tm)<=30 then 1 else 0 end) as consignor_cnt_30,
sum(case when datediff('2022-04-01 00:00:00',consigned_tm)<=90 then 1 else 0 end) as consignor_cnt_90,
sum(case when datediff('2022-04-01 00:00:00',consigned_tm)<=180 then 1 else 0 end) as consignor_cnt_180,
sum(case when datediff('2022-04-01 00:00:00',consigned_tm)<=365 then 1 else 0 end) as consignor_cnt_365,
from  dm_gis_oms.dwd_sy_order_info_di 
where inc_day>='' 
group by consignor_mobile





-- 6.consignor_mobile,consigned_tm,src_dist_code,
最近一次寄件日期
最近一次寄件城市
最近一次寄件距今天数
最近一次寄件距今天数分层
首次寄件日期
首次寄件距今天数



-- dm_gis_oms.dwm_sy_last_consignor_mi 寄件手机最近寄件(每月)
create table dm_gis_oms.dwm_sy_last_consignor_mi(
consignor_mobile string comment '寄件手机',
last_consigned_tm string comment '最近一次寄件日期',
last_consigned_city string comment '最近一次寄件城市'
)
comment '寄件手机最近寄件'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

---- 
---- 跑一个月大约耗时15分钟
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

insert overwrite table dm_gis_oms.dwm_sy_last_consignor_mi partition(inc_day='202204') 
select consignor_mobile,consigned_tm as last_consigned_tm,src_dist_code as last_consigned_city 
from (
select consignor_mobile,consigned_tm,src_dist_code,
row_number() over(partition by consignor_mobile order by consigned_tm desc) as rn  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4
) as a where a.rn=1
;
---- 


-- dm_gis_oms.dwm_sy_last_consignor_tmp 寄件手机最近寄件临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_last_consignor_tmp;
create table dm_gis_oms.dwm_sy_last_consignor_tmp as 
select consignor_mobile,last_consigned_tm,last_consigned_city  
from (
select consignor_mobile,last_consigned_tm,last_consigned_city,
row_number() over(partition by consignor_mobile order by last_consigned_tm desc) as rn  
from dm_gis_oms.dwm_sy_last_consignor_mi   
where inc_day<='202204' 
) as a where a.rn=1
;

---- dm_gis_oms.dwm_sy_first_consignor_mi寄件手机首次寄件(每月)
create table dm_gis_oms.dwm_sy_first_consignor_mi(
consignor_mobile string comment '寄件手机',
first_consigned_tm string comment '首次寄件日期'
)
comment '寄件手机首次寄件'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

---- shell  hive -e  'set hive.execution.engine=tez; '
---- 跑一个月耗时7分钟
insert overwrite table dm_gis_oms.dwm_sy_first_consignor_mi partition(inc_day='202204') 
select consignor_mobile,min(consigned_tm) as first_consigned_tm 
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4 
group by consignor_mobile
;
----

-- dm_gis_oms.dwm_sy_first_consignor_tmp 寄件手机首次寄件临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_first_consignor_tmp;
create table dm_gis_oms.dwm_sy_first_consignor_tmp as 
select consignor_mobile,min(first_consigned_tm) as first_consigned_tm 
from dm_gis_oms.dwm_sy_first_consignor_mi   
where inc_day<='202204' 
group by consignor_mobile
;



-- 7.freight_payment_type_code、freight_settlement_type_code
累计寄件次数
累计寄件寄付票数
累计寄件到付票数
累计寄件第三方付票数
累计散单寄件次数
累计散单寄件占比
累计收件次数
累计散单收件次数
累计散单收件占比

网点自寄票数
网点自寄比例
网点自取票数
网点自取比例

总收寄件量

---- dm_gis_oms.dwm_sy_total_consignor_mi 寄件手机累计寄件(每月)
create table dm_gis_oms.dwm_sy_total_consignor_mi(
consignor_mobile string comment '寄件手机',
consigned_cnt int comment '寄件数',
consigned_jf_cnt int comment '寄付票数',
consigned_df_cnt int comment '到付票数',
consigned_dsff_cnt int comment '第三方付票数',
consigned_sd_cnt int comment '散单寄件数',
self_send_cnt int comment '自寄票数',
self_pickup_cnt int comment '自取票数'
)
comment '寄件手机累计寄件'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY'); 


----
---- 耗时16分钟
set tez.queue.name=gis_public;
set hive.tez.exec.print.summary=true;
set hive.execution.engine=tez;

insert overwrite table dm_gis_oms.dwm_sy_total_consignor_mi partition(inc_day='202204')
select consignor_mobile,
sum(1) as consigned_cnt,
sum(case when freight_payment_type_code='1' then 1 else 0 end) as consigned_jf_cnt,
sum(case when freight_payment_type_code='2' then 1 else 0 end) as consigned_df_cnt,
sum(case when freight_payment_type_code='3' then 1 else 0 end) as consigned_dsff_cnt,
sum(case when freight_settlement_type_code!='2' then 1 else 0 end) as consigned_sd_cnt,
sum(case when self_send_flag=1 then 1 else 0 end) as self_send_cnt,
sum(case when self_pickup_flag=1 then 1 else 0 end) as self_pickup_cnt 
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4
group by consignor_mobile
;

-- dm_gis_oms.dwm_sy_total_consignor_tmp 寄件手机累计寄件临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_total_consignor_tmp;
create table dm_gis_oms.dwm_sy_total_consignor_tmp as 
select consignor_mobile,
sum(consigned_cnt) as consigned_cnt,
sum(consigned_jf_cnt) as consigned_jf_cnt,
sum(consigned_df_cnt) as consigned_df_cnt,
sum(consigned_dsff_cnt) as consigned_dsff_cnt,
sum(consigned_sd_cnt) as consigned_sd_cnt,
sum(self_send_cnt) as self_send_cnt,
sum(self_pickup_cnt) as self_pickup_cnt
from dm_gis_oms.dwm_sy_total_consignor_mi  
where inc_day<='202204' 
group by consignor_mobile
;

---- dm_gis_oms.dwm_sy_total_consignee_mi 收件手机累计收件(每月)
create table dm_gis_oms.dwm_sy_total_consignee_mi(
consignee_mobile string comment '收件手机',
consignee_cnt int comment '收件数',
consignee_sd_cnt int comment '散单收件数'
)
comment '寄件手机累计寄件'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY'); 

insert overwrite table dm_gis_oms.dwm_sy_total_consignee_mi partition(inc_day='202204')
select consignee_mobile,
sum(1) as consignee_cnt,
sum(case when freight_settlement_type_code!='2' then 1 else 0 end) as consignee_sd_cnt
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignee_mobile)>4
group by consignee_mobile
;

-- dm_gis_oms.dwm_sy_total_consignee_tmp 收件手机累计收件临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_total_consignee_tmp;
create table dm_gis_oms.dwm_sy_total_consignee_tmp as 
select consignee_mobile,
sum(consignee_cnt) as consignee_cnt,
sum(consignee_sd_cnt) as consignee_sd_cnt
from dm_gis_oms.dwm_sy_total_consignee_mi  
where inc_day<='202204' 
group by consignee_mobile
;






-- 7. （需要分别有寄件人和收件人的统计量）
所有寄件人的寄件量的最小值
所有寄件人的寄件量的1/4分位数
所有寄件人的寄件量的中位数
所有寄件人的寄件量的3/4分位数
所有寄件人的寄件量的平均值
所有寄件人的寄件量的最大值
所有寄件人的散单寄件量的最小值
所有寄件人的散单寄件量的1/4分位数
所有寄件人的散单寄件量的中位数
所有寄件人的散单寄件量的3/4分位数
所有寄件人的散单寄件量的平均值
所有寄件人的散单寄件量的最大值
所有收件人的收件量的最小值
所有收件人的收件量的1/4分位数
所有收件人的收件量的中位数
所有收件人的收件量的3/4分位数
所有收件人的收件量的平均值
所有收件人的收件量的最大值
所有收件人的散单收件量的最小值
所有收件人的散单收件量的1/4分位数
所有收件人的散单收件量的中位数
所有收件人的散单收件量的3/4分位数
所有收件人的散单收件量的平均值
所有收件人的散单收件量的最大值


----未开发



-- 8. limit_type_code,all_fee_rmb,freight_payment_type_code
常用寄件时间段
寄件时效类型Top3
早上寄件量
下午寄件量
晚上寄件量
寄件总费用
寄件平均费用
寄件寄付费用总计
寄件到付费用总计
寄件第三方付费用总计
寄件城市流向列表
常用寄件城市流向Top3
寄件联系人(收件方)列表
常用寄件联系人(收件方)Top3
收件联系人(寄件方)列表
收用寄件联系人(寄件方)Top3

-- dm_gis_oms.dwm_sy_total_consignor_tm_rmb_mi 寄件手机寄件时间寄件费用(每月)
create table dm_gis_oms.dwm_sy_total_consignor_tm_rmb_mi(
consignor_mobile string,
consignor_tm_0008_cnt int,
consignor_tm_0811_cnt int,
consignor_tm_1113_cnt int,
consignor_tm_1318_cnt int,
consignor_tm_1824_cnt int,
consignor_tm_zs_cnt int,
consignor_tm_zw_cnt int,
consignor_tm_ws_cnt int,
total_rmb double,
total_jf_rmb double,
total_df_rmb double,
total_sff_rmb double 
)
comment '寄件手机寄件时间寄件费用'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');



---- shell hive -e 'set hive.execution.engine=tez; 
---- 耗时7分钟


insert overwrite table dm_gis_oms.dwm_sy_total_consignor_tm_rmb_mi partition(inc_day='202204') 
select consignor_mobile,
sum(case when consigned_hour>='00' and consigned_hour<'08' then 1 else  0 end) as consignor_tm_0008_cnt,
sum(case when consigned_hour>='08' and consigned_hour<'11' then 1 else  0 end) as consignor_tm_0811_cnt,
sum(case when consigned_hour>='11' and consigned_hour<'13' then 1 else  0 end) as consignor_tm_1113_cnt,
sum(case when consigned_hour>='13' and consigned_hour<'18' then 1 else  0 end) as consignor_tm_1318_cnt,
sum(case when consigned_hour>='18' and consigned_hour<'24' then 1 else  0 end) as consignor_tm_1824_cnt,
sum(case when consigned_hour>='07' and consigned_hour<'13' then 1 else  0 end) as consignor_tm_zs_cnt,
sum(case when consigned_hour>='13' and consigned_hour<'18' then 1 else  0 end) as consignor_tm_zw_cnt,
sum(case when consigned_hour>='18' and consigned_hour<'24' then 1 else  0 end) as consignor_tm_ws_cnt,
sum(all_fee_rmb) as total_rmb,
sum(case when freight_payment_type_code='1' then all_fee_rmb else 0 end) as total_jf_rmb,
sum(case when freight_payment_type_code='2' then all_fee_rmb else 0 end) as total_df_rmb,
sum(case when freight_payment_type_code='3' then all_fee_rmb else 0 end) as total_sff_rmb 
 from 
(select consignor_mobile,substr(consigned_tm,12,2) as consigned_hour,limit_type_code,all_fee_rmb,freight_payment_type_code  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4 
) as a 
group by consignor_mobile
;

--  dm_gis_oms.dwm_sy_total_consignor_tm_rmb_tmp 寄件手机寄件时间寄件费用临时
---- -sort_array(array(-consignor_tm_0008_cnt,-consignor_tm_0811_cnt,-consignor_tm_1113_cnt,-consignor_tm_1318_cnt,-consignor_tm_1824_cnt))[0] as  max_tm_cnt
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_total_consignor_tm_rmb_tmp;
create table dm_gis_oms.dwm_sy_total_consignor_tm_rmb_tmp as 
select consignor_mobile,
case 
when -sort_array(array(-consignor_tm_0008_cnt,-consignor_tm_0811_cnt,-consignor_tm_1113_cnt,-consignor_tm_1318_cnt,-consignor_tm_1824_cnt))[0]=consignor_tm_0008_cnt then '00-08' 
when -sort_array(array(-consignor_tm_0008_cnt,-consignor_tm_0811_cnt,-consignor_tm_1113_cnt,-consignor_tm_1318_cnt,-consignor_tm_1824_cnt))[0]=consignor_tm_0811_cnt then '08-11' 
when -sort_array(array(-consignor_tm_0008_cnt,-consignor_tm_0811_cnt,-consignor_tm_1113_cnt,-consignor_tm_1318_cnt,-consignor_tm_1824_cnt))[0]=consignor_tm_1113_cnt then '11-13' 
when -sort_array(array(-consignor_tm_0008_cnt,-consignor_tm_0811_cnt,-consignor_tm_1113_cnt,-consignor_tm_1318_cnt,-consignor_tm_1824_cnt))[0]=consignor_tm_1318_cnt then '13-18' 
else '13-18' end as consignor_tm_cntmax,
consignor_tm_zs_cnt,
consignor_tm_zw_cnt,
consignor_tm_ws_cnt,
total_rmb,
total_jf_rmb,
total_df_rmb,
total_sff_rmb 
from (
select consignor_mobile,
sum(consignor_tm_0008_cnt) as consignor_tm_0008_cnt,
sum(consignor_tm_0811_cnt) as consignor_tm_0811_cnt,
sum(consignor_tm_1113_cnt) as consignor_tm_1113_cnt,
sum(consignor_tm_1318_cnt) as consignor_tm_1318_cnt,
sum(consignor_tm_1824_cnt) as consignor_tm_1824_cnt,
sum(consignor_tm_zs_cnt) as consignor_tm_zs_cnt,
sum(consignor_tm_zw_cnt) as consignor_tm_zw_cnt,
sum(consignor_tm_ws_cnt) as consignor_tm_ws_cnt,
sum(total_rmb) as total_rmb,
sum(total_jf_rmb) as total_jf_rmb,
sum(total_df_rmb) as total_df_rmb,
sum(total_sff_rmb) as total_sff_rmb 
from dm_gis_oms.dwm_sy_total_consignor_tm_rmb_mi  
where inc_day<='202204' 
group by consignor_mobile
) as tmp 
;

---- dm_gis_oms.dwm_sy_consignor_limit_type_mi 寄件时效类型(每月)
---- 
create table dm_gis_oms.dwm_sy_consignor_limit_type_mi(
consignor_mobile string,
limit_type_code string,
limit_type_cnt  int 
)
comment '寄件时效类型'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

---- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_limit_type_mi partition(inc_day='202204') 
select consignor_mobile,limit_type_code,count(1) as  limit_type_cnt 
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4 and length(limit_type_code)>0 
group by consignor_mobile,limit_type_code
;

-- dm_gis_oms.dwm_sy_consignor_limit_type_tmp 寄件时效类型top3临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_consignor_limit_type_tmp;
create table dm_gis_oms.dwm_sy_consignor_limit_type_tmp as 
select consignor_mobile,limit_type_code,limit_type_cnt from (
select consignor_mobile,limit_type_code,limit_type_cnt,row_number() over(partition by consignor_mobile order by limit_type_cnt desc) as rn 
 from (
select consignor_mobile,limit_type_code,sum(limit_type_cnt) as limit_type_cnt from dm_gis_oms.dwm_sy_consignor_limit_type_mi 
where inc_day<='202204'
group by consignor_mobile,limit_type_code 
) as a 
) as a1 where a1.rn<=3
;





-- dm_gis_oms.dwm_sy_consignor_directed_trace_mi 寄件手机寄件城市流向(每月)
create table dm_gis_oms.dwm_sy_consignor_directed_trace_mi(
consignor_mobile string,
src_dist_code string,
dest_dist_code string,
consignor_city_cnt  int 
)
comment '寄件手机寄件城市流向'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');


---- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_directed_trace_mi partition(inc_day='202204') 
select consignor_mobile,src_dist_code,dest_dist_code,count(1) as  consignor_city_cnt 
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4 
and length(src_dist_code)>1 and length(dest_dist_code)>1 
group by consignor_mobile,src_dist_code,dest_dist_code
;

-- dm_gis_oms.dwm_sy_consignor_directed_trace_tmp 寄件手机寄件城市流向top3临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_consignor_directed_trace_tmp;
create table dm_gis_oms.dwm_sy_consignor_directed_trace_tmp as 
select consignor_mobile,src_dist_code,dest_dist_code,consignor_city_cnt from (
select consignor_mobile,src_dist_code,dest_dist_code,consignor_city_cnt,row_number() over(partition by consignor_mobile order by consignor_city_cnt desc) as rn 
 from (
select consignor_mobile,src_dist_code,dest_dist_code,sum(consignor_city_cnt) as consignor_city_cnt from dm_gis_oms.dwm_sy_consignor_directed_trace_mi 
where inc_day<='202204'
group by consignor_mobile,src_dist_code,dest_dist_code
) as a 
) as a1 where a1.rn<=3
;



-- dm_gis_oms.dwm_sy_consignor_consignee_mi 寄件手机寄件联系人(每月)
create table dm_gis_oms.dwm_sy_consignor_consignee_mi(
consignor_mobile string,
consignee_mobile string,
contact_cnt  int 
)
comment '寄件手机寄件联系人'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

---- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_consignee_mi partition(inc_day='202204') 
select consignor_mobile,consignee_mobile,count(1) as  contact_cnt 
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4 and length(consignee_mobile)>4 
group by consignor_mobile,consignee_mobile
;

-- dm_gis_oms.dwm_sy_consignor_consignee_tmp 寄件手机寄件联系人top3临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_consignor_consignee_tmp;
create table dm_gis_oms.dwm_sy_consignor_consignee_tmp as 
select consignor_mobile,consignee_mobile,contact_cnt from (
select consignor_mobile,consignee_mobile,contact_cnt,row_number() over(partition by consignor_mobile order by contact_cnt desc) as rn 
 from (
select consignor_mobile,consignee_mobile,sum(contact_cnt) as contact_cnt from dm_gis_oms.dwm_sy_consignor_consignee_mi 
where inc_day<='202204'
group by consignor_mobile,consignee_mobile
) as a 
) as a1 where a1.rn<=3
;

-- dm_gis_oms.dwm_sy_consignee_consignor_mi 收件手机联系人(每月)
create table dm_gis_oms.dwm_sy_consignee_consignor_mi(
consignee_mobile string,
consignor_mobile string,
contact_cnt  int 
)
comment '寄件手机寄件联系人'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

---- 
insert overwrite table dm_gis_oms.dwm_sy_consignee_consignor_mi partition(inc_day='202204') 
select consignee_mobile,consignor_mobile,count(1) as  contact_cnt 
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4 and length(consignee_mobile)>4 
group by consignor_mobile,consignee_mobile
;

-- dm_gis_oms.dwm_sy_consignor_consignee_tmp 收件手机联系人top3临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_consignee_consignor_tmp;
create table dm_gis_oms.dwm_sy_consignee_consignor_tmp as 
select consignee_mobile,consignor_mobile,contact_cnt from (
select consignee_mobile,consignor_mobile,contact_cnt,row_number() over(partition by consignee_mobile order by contact_cnt desc) as rn 
 from (
select consignee_mobile,consignor_mobile,sum(contact_cnt) as contact_cnt from dm_gis_oms.dwm_sy_consignee_consignor_mi 
where inc_day<='202204'
group by consignee_mobile,consignor_mobile
) as a 
) as a1 where a1.rn<=3
;


-- 9. 
散单互寄列表
散单互寄频次最高的号码
散单互寄频次最高的姓名
散单互寄频次最高对应件量
散单互寄频次最高对应票均运费

-- dm_gis_oms.dwm_sy_consignor_sd_mi 寄件收件散单(每月)
create table dm_gis_oms.dwm_sy_consignor_sd_mi(
consignor_mobile string,
consignee_mobile string,
consignor_cnt  int,
total_sff_rmb  double 
)
comment '寄件手机寄件联系人'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

---- 跑了
insert overwrite table dm_gis_oms.dwm_sy_consignor_sd_mi partition(inc_day='202204') 
select consignor_mobile,consignee_mobile,count(1) as consignor_cnt,sum(all_fee_rmb) as total_sff_rmb 
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4 and length(consignee_mobile)>4 
and freight_settlement_type_code!='2' 
group by consignor_mobile,consignee_mobile
;

-- dm_gis_oms.dwm_sy_consignor_sd_tmp 寄件收件散单互寄临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_consignor_sd_tmp;
create table dm_gis_oms.dwm_sy_consignor_sd_tmp as 
select consignor_mobile,consignee_mobile,sum(consignor_cnt) as consignor_cnt,sum(total_sff_rmb) as total_sff_rmb 
from dm_gis_oms.dwm_sy_consignor_sd_mi 
where inc_day<='202204'
group by consignor_mobile,consignee_mobile
;


---- 散单互寄临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_sd_each_tmp;
create table dm_gis_oms.dwm_sy_sd_each_tmp as 
select 
consignor_mobile,consignee_mobile,consignor_cnt,avg_sff_rmb 
from (
select consignor_mobile,consignee_mobile,consignor_cnt,avg_sff_rmb,row_number() over(partition by consignor_mobile order by consignor_cnt desc) as rn
from 
(
select t1.consignor_mobile,t1.consignee_mobile,t1.consignor_cnt+t2.consignor_cnt as consignor_cnt,(t1.total_sff_rmb+t2.total_sff_rmb)/(t1.consignor_cnt+t2.consignor_cnt) as avg_sff_rmb from  
(
select consignor_mobile,consignee_mobile,consignor_cnt,total_sff_rmb 
from dm_gis_oms.dwm_sy_consignor_sd_tmp 
) as t1 
inner join 
(
select consignor_mobile,consignee_mobile,consignor_cnt,total_sff_rmb 
from dm_gis_oms.dwm_sy_consignor_sd_tmp 
) as t2 
on t1.consignor_mobile=t2.consignee_mobile and t2.consignor_mobile=t1.consignee_mobile
) as t3
) as t4 where t4.rn=1 
;


-- 10. is_value_insured,service_prod_code,self_send_flag,self_pickup_flag,cons_name
常用寄件增值服务Top3
常用收件增值服务Top3
寄件地址列表(地址聚合去重)
收件地址列表(地址聚合去重)
常用寄件目的地Top3
常用寄件地址Top3
常用收件地址Top3
常寄托寄物
常收托寄物
收寄偏好用户分层


-- 寄件增值服务(service_prod_code array<string>类型)
-- dm_gis_oms.dwm_sy_consignor_service_mi 寄件增值服务(每月)
create table dm_gis_oms.dwm_sy_consignor_service_mi(
consignor_mobile string,
prod_code string,
prod_code_cnt  int
)
comment '寄件增值服务'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_service_mi partition(inc_day='202204') 
select consignor_mobile,prod_code,count(1) as prod_code_cnt 
from (
select  consignor_mobile,prod_code 
from (
select  consignor_mobile,service_prod_code  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4  
and size(service_prod_code)>0 ) as a 
LATERAL VIEW explode(service_prod_code) spc as prod_code 
) as b group by consignor_mobile,prod_code 
;

-- dm_gis_oms.dwm_sy_consignor_service_tmp 寄件增值top3临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_consignor_service_tmp;
create table dm_gis_oms.dwm_sy_consignor_service_tmp as 
select consignor_mobile,prod_code,prod_code_cnt from (
select consignor_mobile,prod_code,prod_code_cnt,row_number() over(partition by consignor_mobile,prod_code order by prod_code_cnt desc) as rn 
 from (
select consignor_mobile,prod_code,sum(prod_code_cnt) as prod_code_cnt from dm_gis_oms.dwm_sy_consignor_service_mi  
where inc_day<='202204'
group by consignor_mobile,prod_code 
) as a 
) as a1 where a1.rn<=3
;

-- 收件增值服务(service_prod_code array<string>类型)
-- dm_gis_oms.dwm_sy_consignee_service_mi 收件增值服务(每月)
create table dm_gis_oms.dwm_sy_consignee_service_mi(
consignee_mobile string,
prod_code string,
prod_code_cnt  int
)
comment '收件增值服务'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignee_service_mi partition(inc_day='202204') 
select consignee_mobile,prod_code,count(1) as prod_code_cnt 
from (
select  consignee_mobile,prod_code 
from (
select  consignee_mobile,service_prod_code  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignee_mobile)>4  
and size(service_prod_code)>0 ) as a 
LATERAL VIEW explode(service_prod_code) spc as prod_code 
) as b group by consignee_mobile,prod_code 
;

-- dm_gis_oms.dwm_sy_consignee_service_tmp 收件增值top3临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_consignee_service_tmp;
create table dm_gis_oms.dwm_sy_consignee_service_tmp as 
select consignee_mobile,prod_code,prod_code_cnt from (
select consignee_mobile,prod_code,prod_code_cnt,row_number() over(partition by consignee_mobile,prod_code order by prod_code_cnt desc) as rn 
 from (
select consignee_mobile,prod_code,sum(prod_code_cnt) as prod_code_cnt from dm_gis_oms.dwm_sy_consignee_service_mi  
where inc_day<='202204'
group by consignee_mobile,prod_code 
) as a 
) as a1 where a1.rn<=3
;



-- 寄件目的地Top3
-- dm_gis_oms.dwm_sy_consignor_mdd_mi 寄件目的地(每月)
create table dm_gis_oms.dwm_sy_consignor_mdd_mi(
consignor_mobile string,
consignee_addr string,
consignee_addr_cnt  int
)
comment '寄件目的地'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_mdd_mi partition(inc_day='202204') 
select consignor_mobile,consignee_addr,count(1) as consignee_addr_cnt
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4  
and length(consignee_addr)>4 
group by consignor_mobile,consignee_addr 
;



-- dm_gis_oms.dwm_sy_consignor_mdd_tmp 寄件目的地top3临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignor_mdd_tmp1;
create table dm_gis_oms.dwm_sy_consignor_mdd_tmp1 as 
select consignor_mobile,consignee_addr,sum(consignee_addr_cnt) as consignee_addr_cnt from dm_gis_oms.dwm_sy_consignor_mdd_mi  
where inc_day<='202104'  
group by consignor_mobile,consignee_addr 
;

drop table if exists dm_gis_oms.dwm_sy_consignor_mdd_tmp;
create table dm_gis_oms.dwm_sy_consignor_mdd_tmp as 
select consignor_mobile,consignee_addr,consignee_addr_cnt from (
select consignor_mobile,consignee_addr,consignee_addr_cnt,row_number() over(partition by consignor_mobile order by consignee_addr_cnt desc) as rn 
 from dm_gis_oms.dwm_sy_consignor_mdd_tmp1 
) as a1 where a1.rn<=3
;

-- 寄件地址Top3
-- dm_gis_oms.dwm_sy_consignor_addr_mi 寄件地址(每月)
create table dm_gis_oms.dwm_sy_consignor_addr_mi(
consignor_mobile string,
consignor_addr string,
consignor_addr_cnt  int
)
comment '寄件地址'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_addr_mi partition(inc_day='202204') 
select consignor_mobile,consignor_addr,count(1) as consignor_addr_cnt
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4  
and length(consignor_addr)>4 
group by consignor_mobile,consignor_addr 
;

-- dm_gis_oms.dwm_sy_consignor_addr_tmp 寄件地址top3临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignor_addr_tmp1;
create table dm_gis_oms.dwm_sy_consignor_addr_tmp1 as 
select consignor_mobile,consignor_addr,sum(consignor_addr_cnt) as consignor_addr_cnt from dm_gis_oms.dwm_sy_consignor_addr_mi  
where inc_day<='202204'
group by consignor_mobile,consignor_addr 
;

drop table if exists dm_gis_oms.dwm_sy_consignor_addr_tmp;
create table dm_gis_oms.dwm_sy_consignor_addr_tmp as 
select consignor_mobile,consignor_addr,consignor_addr_cnt from (
select consignor_mobile,consignor_addr,consignor_addr_cnt,row_number() over(partition by consignor_mobile order by consignor_addr_cnt desc) as rn 
 from dm_gis_oms.dwm_sy_consignor_addr_tmp1 
) as a1 where a1.rn<=3
;

-- 收件地址Top3
-- dm_gis_oms.dwm_sy_consignee_addr_mi 收件地址(每月)
create table dm_gis_oms.dwm_sy_consignee_addr_mi(
consignee_mobile string,
consignee_addr string,
consignee_addr_cnt  int
)
comment '收件地址'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignee_addr_mi partition(inc_day='202204') 
select consignee_mobile,consignee_addr,count(1) as consignee_addr_cnt
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignee_mobile)>4  
and length(consignee_addr)>4 
group by consignee_mobile,consignee_addr 
;

-- dm_gis_oms.dwm_sy_consignee_addr_tmp 收件地址top3临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignee_addr_tmp1;
create table dm_gis_oms.dwm_sy_consignee_addr_tmp1 as 
select consignee_mobile,consignee_addr,sum(consignee_addr_cnt) as consignee_addr_cnt from dm_gis_oms.dwm_sy_consignee_addr_mi  
where inc_day<='202204'
group by consignee_mobile,consignee_addr 
;

drop table if exists dm_gis_oms.dwm_sy_consignee_addr_tmp;
create table dm_gis_oms.dwm_sy_consignee_addr_tmp as 
select consignee_mobile,consignee_addr,consignee_addr_cnt from (
select consignee_mobile,consignee_addr,consignee_addr_cnt,row_number() over(partition by consignee_mobile order by consignee_addr_cnt desc) as rn 
 from dm_gis_oms.dwm_sy_consignee_addr_tmp1  
) as a1 where a1.rn<=3
;



-- 常寄托寄物
-- dm_gis_oms.dwm_sy_consignor_cons_mi 寄托寄物(每月)
create table dm_gis_oms.dwm_sy_consignor_cons_mi(
consignor_mobile string,
cons string,
cons_cnt  int
)
comment '寄托寄物'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_cons_mi partition(inc_day='202204') 
select consignor_mobile,cons,count(1) as cons_cnt 
from (
select  consignor_mobile,cons 
from (
select  consignor_mobile,cons_name   
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4  
and size(cons_name)>0 ) as a 
LATERAL VIEW explode(cons_name) spc as cons 
) as b group by consignor_mobile,cons 
;

-- dm_gis_oms.dwm_sy_consignor_cons_tmp 寄托寄物top3临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignor_cons_tmp1;
create table dm_gis_oms.dwm_sy_consignor_cons_tmp1 as 
select consignor_mobile,cons,sum(cons_cnt) as cons_cnt from dm_gis_oms.dwm_sy_consignor_cons_mi  
where inc_day<='202204'
group by consignor_mobile,cons 
;

drop table if exists dm_gis_oms.dwm_sy_consignor_cons_tmp;
create table dm_gis_oms.dwm_sy_consignor_cons_tmp as 
select consignor_mobile,cons,cons_cnt from (
select consignor_mobile,cons,cons_cnt,row_number() over(partition by consignor_mobile order by cons_cnt desc) as rn 
 from dm_gis_oms.dwm_sy_consignor_cons_tmp1 
) as a1 where a1.rn<=3
;

-- 常收托寄物
-- dm_gis_oms.dwm_sy_consignee_cons_mi 收托寄物(每月)
create table dm_gis_oms.dwm_sy_consignee_cons_mi(
consignee_mobile string,
cons string,
cons_cnt  int
)
comment '收托寄物'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignee_cons_mi partition(inc_day='202204') 
select consignee_mobile,cons,count(1) as cons_cnt 
from (
select  consignee_mobile,cons 
from (
select  consignee_mobile,cons_name   
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignee_mobile)>4  
and size(cons_name)>0 ) as a 
LATERAL VIEW explode(cons_name) spc as cons 
) as b group by consignee_mobile,cons 
;

-- dm_gis_oms.dwm_sy_consignee_cons_tmp 收托寄top3物临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignee_cons_tmp1;
create table dm_gis_oms.dwm_sy_consignee_cons_tmp1 as 
select consignee_mobile,cons,sum(cons_cnt) as cons_cnt from dm_gis_oms.dwm_sy_consignee_cons_mi  
where inc_day<='202204'
group by consignee_mobile,cons 
;

drop table if exists dm_gis_oms.dwm_sy_consignee_cons_tmp;
create table dm_gis_oms.dwm_sy_consignee_cons_tmp as 
select consignee_mobile,cons,cons_cnt from (
select consignee_mobile,cons,cons_cnt,row_number() over(partition by consignee_mobile order by cons_cnt desc) as rn 
 from dm_gis_oms.dwm_sy_consignee_cons_tmp1 
) as a1 where a1.rn<=3
;


-- 2022-06-13 新增
寄件目的城市数量
在不同城市的寄件量
在不同城市的收件量
常用收件来源城市
最近一次收件日期
最近一次收件城市
寄件联系人(收件方)列表
收件联系人(寄件方)列表
寄件频次
收件频次

--------------------------------------------
-- dm_gis_oms.dwm_sy_consignor_mdcs_mi 寄件目的城市(每月)
create table dm_gis_oms.dwm_sy_consignor_mdcs_mi(
consignor_mobile string,
consignee_city string,
consignee_city_cnt  int 
)
comment '寄件目的城市'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_mdcs_mi partition(inc_day='202204') 
select consignor_mobile,dest_dist_code,count(1) as consignee_city_cnt  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4  
and length(dest_dist_code)>0   
group by consignor_mobile,dest_dist_code 
;


-- dm_gis_oms.dwm_sy_consignor_mdcs_tmp 寄件目的城市临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignor_mdcs_tmp1;
create table dm_gis_oms.dwm_sy_consignor_mdcs_tmp1 as 
select consignor_mobile,consignee_city,sum(consignee_city_cnt) as consignee_city_cnt from dm_gis_oms.dwm_sy_consignor_mdcs_mi  
where inc_day<='202104'  
group by consignor_mobile,consignee_city 
;

-- 目的城市数量
drop table if exists dm_gis_oms.dwm_sy_consignor_mdcs_tmp;
create table dm_gis_oms.dwm_sy_consignor_mdcs_tmp as 
select consignor_mobile,count(distinct consignee_city) as mdcs_cnt 
from dm_gis_oms.dwm_sy_consignor_mdcs_tmp1 
group by consignor_mobile
;

--------------------------------------------
-- dm_gis_oms.dwm_sy_consignor_jjcs_mi 寄件城市(每月)
create table dm_gis_oms.dwm_sy_consignor_jjcs_mi(
consignor_mobile string,
consignor_city string,
consignor_city_cnt  int 
)
comment '寄件城市'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_jjcs_mi partition(inc_day='202204') 
select consignor_mobile,src_dist_code,count(1) as consignor_city_cnt  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignor_mobile)>4  
and length(src_dist_code)>0   
group by consignor_mobile,src_dist_code 
;


-- dm_gis_oms.dwm_sy_consignor_jjcs_tmp 寄件城市临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignor_jjcs_tmp1;
create table dm_gis_oms.dwm_sy_consignor_jjcs_tmp1 as 
select consignor_mobile,consignor_city,sum(consignor_city_cnt) as consignor_city_cnt from dm_gis_oms.dwm_sy_consignor_jjcs_mi  
where inc_day<='202104'  
group by consignor_mobile,consignor_city 
;

-- 寄件城市寄件数量
drop table if exists dm_gis_oms.dwm_sy_consignor_jjcs_tmp;
create table dm_gis_oms.dwm_sy_consignor_jjcs_tmp as 
select consignor_mobile,consignor_city,count(1) as consignor_city_cnt  
from dm_gis_oms.dwm_sy_consignor_jjcs_tmp1 
group by consignor_mobile,consignor_city 
;

--------------------------------------------
-- dm_gis_oms.dwm_sy_consignee_sjcs_mi 收件城市(每月)
create table dm_gis_oms.dwm_sy_consignee_sjcs_mi(
consignee_mobile string,
consignee_city string,
consignee_city_cnt  int 
)
comment '收件城市'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignee_sjcs_mi partition(inc_day='202204') 
select consignee_mobile,dest_dist_code,count(1) as consignee_city_cnt  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignee_mobile)>4  
and length(dest_dist_code)>0   
group by consignee_mobile,dest_dist_code 
;


-- dm_gis_oms.dwm_sy_consignee_sjcs_tmp 收件城市临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignee_sjcs_tmp1;
create table dm_gis_oms.dwm_sy_consignee_sjcs_tmp1 as 
select consignee_mobile,consignee_city,sum(consignee_city_cnt) as consignee_city_cnt from dm_gis_oms.dwm_sy_consignee_sjcs_mi  
where inc_day<='202104'  
group by consignee_mobile,consignee_city 
;

-- 寄件城市寄件数量
drop table if exists dm_gis_oms.dwm_sy_consignee_sjcs_tmp;
create table dm_gis_oms.dwm_sy_consignee_sjcs_tmp as 
select consignee_mobile,consignee_city,count(1) as consignee_city_cnt  
from dm_gis_oms.dwm_sy_consignee_sjcs_tmp1 
group by consignee_mobile,consignee_city 
;


--------------------------------------------
-- dm_gis_oms.dwm_sy_consignee_sjlycs_mi 收件来源城市(每月)
create table dm_gis_oms.dwm_sy_consignee_sjlycs_mi(
consignee_mobile string,
consignor_city string,
consignor_city_cnt  int 
)
comment '收件来源城市'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignee_sjlycs_mi partition(inc_day='202204') 
select consignee_mobile,src_dist_code,count(1) as consignor_city_cnt  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignee_mobile)>4  
and length(src_dist_code)>0   
group by consignee_mobile,src_dist_code 
;


-- dm_gis_oms.dwm_sy_consignee_sjlycs_tmp 收件来源城市临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignee_sjlycs_tmp1;
create table dm_gis_oms.dwm_sy_consignee_sjlycs_tmp1 as 
select consignee_mobile,consignor_city,sum(consignor_city_cnt) as consignor_city_cnt from dm_gis_oms.dwm_sy_consignee_sjlycs_mi  
where inc_day<='202104'  
group by consignee_mobile,consignor_city 
;

-- 收件来源城市运单数量
drop table if exists dm_gis_oms.dwm_sy_consignee_sjlycs_tmp;
create table dm_gis_oms.dwm_sy_consignee_sjlycs_tmp as 
select consignee_mobile,consignor_city,consignor_city_cnt from (
select consignee_mobile,consignor_city,consignor_city_cnt,row_number() over(partition by consignee_mobile order by consignor_city_cnt desc) as rn 
 from dm_gis_oms.dwm_sy_consignee_sjlycs_tmp1 
) as a1 where a1.rn<=3
;


--------------------------------------------
-- dm_gis_oms.dwm_sy_last_consignee_mi  收件手机最近收件(每月)
create table dm_gis_oms.dwm_sy_last_consignee_mi(
consignee_mobile string comment '收件手机',
last_consignee_tm string comment '最近一次收件日期',
last_consignee_city string comment '最近一次收件城市'
)
comment '收件手机最近收件'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

---- 
insert overwrite table dm_gis_oms.dwm_sy_last_consignee_mi partition(inc_day='202204') 
select consignee_mobile,signin_tm as last_consignee_tm,dest_dist_code as last_consignee_city  
from (
select consignee_mobile,signin_tm,dest_dist_code,
row_number() over(partition by consignee_mobile order by signin_tm desc) as rn  
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and length(consignee_mobile)>4
) as a where a.rn=1
;
---- 


-- dm_gis_oms.dwm_sy_last_consignee_tmp 收件手机最近收件临时表
set mapreduce.job.queuename=gis_public;
drop table if exists dm_gis_oms.dwm_sy_last_consignee_tmp;
create table dm_gis_oms.dwm_sy_last_consignee_tmp as 
select consignee_mobile,last_consignee_tm,last_consignee_city  
from (
select consignee_mobile,last_consignee_tm,last_consignee_city,
row_number() over(partition by consignee_mobile order by last_consignee_tm desc) as rn  
from dm_gis_oms.dwm_sy_last_consignee_mi   
where inc_day<='202204' 
) as a where a.rn=1
;


------------------------------------------------
-- 近一年个人寄件/收件（散单）天数[寄件/收件频次]
-- 
-- dm_gis_oms.dwm_sy_consignor_jjsdts_mi 寄件（散单）天数(每月)
create table dm_gis_oms.dwm_sy_consignor_jjsdts_mi(
consignor_mobile string,
consignor_day_cnt  int 
)
comment '收件（散单）天数'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignor_jjsdts_mi partition(inc_day='202204') 
select  consignor_mobile,count(distinct consigned_tm_day) as consignor_day_cnt
from (
select consignor_mobile,consigned_tm_day
from (
select consignor_mobile,substr(consigned_tm,1,10) as consigned_tm_day
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and freight_settlement_type_code!='2'
and length(consignor_mobile)>4
and length(consigned_tm)>0  ) as t
group by consignor_mobile,consigned_tm_day ) as t1
group by consignor_mobile
;


-- dm_gis_oms.dwm_sy_consignor_jjsdts_tmp 寄件（散单）天数临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignor_jjsdts_tmp;
create table dm_gis_oms.dwm_sy_consignor_jjsdts_tmp as 
select consignor_mobile,sum(consignor_day_cnt) as consignor_day_cnt from dm_gis_oms.dwm_sy_consignor_jjsdts_mi  
where inc_day<='202104'  
group by consignor_mobile 
;

----
-- dm_gis_oms.dwm_sy_consignee_sjsdts_mi 收件（散单）天数(每月)
create table dm_gis_oms.dwm_sy_consignee_sjsdts_mi(
consignee_mobile string,
consignee_day_cnt  int 
)
comment '收件（散单）天数'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 
insert overwrite table dm_gis_oms.dwm_sy_consignee_sjsdts_mi partition(inc_day='202204') 
select  consignee_mobile,count(distinct signin_tm_day) as consignee_day_cnt 
from (
select consignee_mobile,substr(signin_tm,1,10) as signin_tm_day   
from dm_gis_oms.dwd_sy_order_info_di  
where inc_day>='20220401' and inc_day<'20220501' 
and freight_settlement_type_code!='2' 
and length(consignee_mobile)>4  
and length(signin_tm)>0  ) as t 
group by consignee_mobile,signin_tm_day  
;


-- dm_gis_oms.dwm_sy_consignee_sjsdts_tmp 收件（散单）天数临时表
set mapreduce.job.queuename=gis_public;

drop table if exists dm_gis_oms.dwm_sy_consignee_sjsdts_tmp;
create table dm_gis_oms.dwm_sy_consignee_sjsdts_tmp as 
select consignee_mobile,sum(consignee_day_cnt) as consignee_day_cnt from dm_gis_oms.dwm_sy_consignee_sjsdts_mi  
where inc_day<='202104'  
group by consignee_mobile 
;



-- 2022-08-02 新增
最近一次寄件增加字段信息 【增加寄件地址、收件地址、收件人、收件人电话、托寄物】
最近一次收件增加字段信息 【增加寄件地址、收件地址、收件人、收件人电话、托寄物】
最近n个月散单寄件量   【从 dm_gis_oms.dwm_sy_total_consignor_mi 提取】
最近n个月散单寄件频次  【从 dm_gis_oms.dwm_sy_consignor_jjsdts_mi 提取】
最近n个月寄件手机各城市散单寄件量
最近n个月寄件手机各城市散单寄件频次
最近n个月寄件手机各城市top1地址及寄件量(散单)
最近n个月寄件手机各城市top1托寄物及数量(散单)
最近n个月寄件手机各城市top1企业及数量(散单)


-- 最近n个月散单寄件量
create table dm_gis_oms.dwm_sy_total_consignor_tmp_nm as
select
consignor_mobile,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then consigned_sd_cnt else 0 end) as consigned_sd_cnt_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then consigned_sd_cnt else 0 end) as consigned_sd_cnt_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then consigned_sd_cnt else 0 end) as consigned_sd_cnt_6m,
sum(consigned_sd_cnt) as consigned_sd_cnt_1y
from dm_gis_oms.dwm_sy_total_consignor_mi
where inc_day>='202108'
group by consignor_mobile
;


-- 最近n个月散单寄件频次
create table dm_gis_oms.dwm_sy_consignor_jjsdts_tmp_nm as
select
consignor_mobile,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then consignor_day_cnt else 0 end) as consignor_day_cnt_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then consignor_day_cnt else 0 end) as consignor_day_cnt_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then consignor_day_cnt else 0 end) as consignor_day_cnt_6m,
sum(consignor_day_cnt) as consignor_day_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjsdts_mi
where inc_day>='202108'
group by consignor_mobile
;


-- 最近n个月寄件手机各城市散单寄件量
create table dm_gis_oms.dwm_sy_consignor_jjcs_sd_mi(
consignor_mobile string,
consignor_city string,
consignor_city_cnt  int
)
comment '寄件城市'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
insert overwrite table dm_gis_oms.dwm_sy_consignor_jjcs_sd_mi partition(inc_day='202204')
select consignor_mobile,src_dist_code,count(1) as consignor_city_cnt
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and freight_settlement_type_code!='2'
and length(consignor_mobile)>4
and length(src_dist_code)>0
group by consignor_mobile,src_dist_code
;

-- 近n寄件城市散单
create table dm_gis_oms.dwm_sy_consignor_jjcs_sd_tmp_nm as
select
consignor_mobile,consignor_city,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then consignor_city_cnt else 0 end) as consignor_city_cnt_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then consignor_city_cnt else 0 end) as consignor_city_cnt_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then consignor_city_cnt else 0 end) as consignor_city_cnt_6m,
sum(consignor_city_cnt) as consignor_city_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_sd_mi
where inc_day>='202108'
group by consignor_mobile,consignor_city
;


-- 最近n个月寄件手机各城市散单寄件频次
create table dm_gis_oms.dwm_sy_consignor_jjcssdts_mi(
consignor_mobile string,
src_dist_code string,
consignor_day_cnt  int
)
comment '寄件城市（散单）天数'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
insert overwrite table dm_gis_oms.dwm_sy_consignor_jjcssdts_mi partition(inc_day='202204')
select  consignor_mobile,src_dist_code,count(distinct consigned_tm_day) as consignor_day_cnt
from (
select consignor_mobile,src_dist_code,consigned_tm_day
from (
select consignor_mobile,src_dist_code,substr(consigned_tm,1,10) as consigned_tm_day
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and freight_settlement_type_code!='2'
and length(consignor_mobile)>4
and length(consigned_tm)>0
and length(src_dist_code)>0   ) as t
group by consignor_mobile,src_dist_code,consigned_tm_day ) as t1
group by consignor_mobile,src_dist_code
;


-- 近n个月寄件城市散单寄件频次
create table dm_gis_oms.dwm_sy_consignor_jjcssdts_tmp_nm as
select
consignor_mobile,src_dist_code,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then consignor_day_cnt else 0 end) as consignor_day_cnt_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then consignor_day_cnt else 0 end) as consignor_day_cnt_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then consignor_day_cnt else 0 end) as consignor_day_cnt_6m,
sum(consignor_day_cnt) as consignor_day_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcssdts_mi
where inc_day>='202108'
group by consignor_mobile,src_dist_code
;




-- 最近n个月寄件手机各城市top1地址及寄件量(散单)
create table dm_gis_oms.dwm_sy_consignor_jjcs_addr_mi(
consignor_mobile string,
consignor_city string,
consignor_addr string,
consignor_addr_cnt  int
)
comment '寄件城市top1地址'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
insert overwrite table dm_gis_oms.dwm_sy_consignor_jjcs_addr_mi partition(inc_day='202204')
select consignor_mobile,src_dist_code,consignor_addr,count(1) as consignor_addr_cnt
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and freight_settlement_type_code!='2'
and length(consignor_mobile)>4
and length(src_dist_code)>0
and length(consignor_addr)>0
group by consignor_mobile,src_dist_code,consignor_addr
;

-- 近n统计
create table dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_nm as
select
consignor_mobile,consignor_city,consignor_addr,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then consignor_addr_cnt else 0 end) as addr_cnt_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then consignor_addr_cnt else 0 end) as addr_cnt_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then consignor_addr_cnt else 0 end) as addr_cnt_6m,
sum(consignor_addr_cnt) as addr_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_mi
where inc_day>='202108'
group by consignor_mobile,consignor_city,consignor_addr
;


-- 计算top1
create table dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_1y as
select
consignor_mobile,consignor_city,consignor_addr as addr_1y,addr_cnt_1y
from (select
consignor_mobile,consignor_city,consignor_addr,addr_cnt_1y,
row_number() over(partition by consignor_mobile,consignor_city order by addr_cnt_1y desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_nm
) as t
where t.rn<=1
;

create table dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_6m as
select
consignor_mobile,consignor_city,consignor_addr as addr_6m,addr_cnt_6m
from (select
consignor_mobile,consignor_city,consignor_addr,addr_cnt_6m,
row_number() over(partition by consignor_mobile,consignor_city order by addr_cnt_6m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_nm
where addr_cnt_6m>0
) as t
where t.rn<=1
;

create table dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_3m as
select
consignor_mobile,consignor_city,consignor_addr as addr_3m,addr_cnt_3m
from (select
consignor_mobile,consignor_city,consignor_addr,addr_cnt_3m,
row_number() over(partition by consignor_mobile,consignor_city order by addr_cnt_3m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_nm
where addr_cnt_3m>0
) as t
where t.rn<=1
;

create table dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_top1_1m as
select
consignor_mobile,consignor_city,consignor_addr as addr_1m,addr_cnt_1m
from (select
consignor_mobile,consignor_city,consignor_addr,addr_cnt_1m,
row_number() over(partition by consignor_mobile,consignor_city order by addr_cnt_1m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_addr_tmp_nm
where addr_cnt_1m>0
) as t
where t.rn<=1
;


-- 最近n个月寄件手机各城市top1托寄物及数量(散单)
create table dm_gis_oms.dwm_sy_consignor_jjcs_cons_mi(
consignor_mobile string,
consignor_city string,
cons string comment "托寄物",
cons_cnt  int comment "托寄物对应票数"
)
comment '寄件城市top1托寄物'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
insert overwrite table dm_gis_oms.dwm_sy_consignor_jjcs_cons_mi partition(inc_day='202204')
select consignor_mobile,src_dist_code,cons,count(1) as cons_cnt
from (
select  consignor_mobile,src_dist_code,cons
from (
select  consignor_mobile,src_dist_code,cons_name
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and freight_settlement_type_code!='2'
and length(consignor_mobile)>4
and length(src_dist_code)>0
and size(cons_name)>0 ) as a
LATERAL VIEW explode(cons_name) spc as cons
) as b group by consignor_mobile,src_dist_code,cons
;


-- 近n统计
create table dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_nm as
select
consignor_mobile,consignor_city,cons,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then cons_cnt else 0 end) as cons_cnt_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then cons_cnt else 0 end) as cons_cnt_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then cons_cnt else 0 end) as cons_cnt_6m,
sum(cons_cnt) as cons_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_mi
where inc_day>='202108'
group by consignor_mobile,consignor_city,cons
;

-- 计算top1
create table dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_1y as
select
consignor_mobile,consignor_city,cons as cons_1y,cons_cnt_1y
from (select
consignor_mobile,consignor_city,cons,cons_cnt_1y,
row_number() over(partition by consignor_mobile,consignor_city order by cons_cnt_1y desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_nm
) as t
where t.rn<=1
;

create table dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_6m as
select
consignor_mobile,consignor_city,cons as cons_6m,cons_cnt_6m
from (select
consignor_mobile,consignor_city,cons,cons_cnt_6m,
row_number() over(partition by consignor_mobile,consignor_city order by cons_cnt_6m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_nm
where cons_cnt_6m>0
) as t
where t.rn<=1
;


create table dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_3m as
select
consignor_mobile,consignor_city,cons as cons_3m,cons_cnt_3m
from (select
consignor_mobile,consignor_city,cons,cons_cnt_3m,
row_number() over(partition by consignor_mobile,consignor_city order by cons_cnt_3m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_nm
where cons_cnt_3m>0
) as t
where t.rn<=1
;

create table dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_top1_1m as
select
consignor_mobile,consignor_city,cons as cons_1m,cons_cnt_1m
from (select
consignor_mobile,consignor_city,cons,cons_cnt_1m,
row_number() over(partition by consignor_mobile,consignor_city order by cons_cnt_1m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_cons_tmp_nm
where cons_cnt_1m>0
) as t
where t.rn<=1
;







-- 最近n个月寄件手机各城市top1企业及数量(散单)
create table dm_gis_oms.dwm_sy_consignor_jjcs_comp_mi(
consignor_mobile string,
consignor_city string,
consignor_comp_name string comment "寄件企业",
comp_name_cnt  int comment "寄件企业对应票数"
)
comment '寄件城市top1企业'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
insert overwrite table dm_gis_oms.dwm_sy_consignor_jjcs_comp_mi partition(inc_day='202204')
select consignor_mobile,src_dist_code,consignor_comp_name,count(1) as comp_name_cnt
from dm_gis_oms.dwd_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and freight_settlement_type_code!='2'
and length(consignor_mobile)>4
and length(src_dist_code)>0
and length(consignor_comp_name)>0
group by consignor_mobile,src_dist_code,consignor_comp_name
;

-- 近n统计
create table dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_nm as
select
consignor_mobile,consignor_city,consignor_comp_name,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then comp_name_cnt else 0 end) as comp_name_cnt_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then comp_name_cnt else 0 end) as comp_name_cnt_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then comp_name_cnt else 0 end) as comp_name_cnt_6m,
sum(comp_name_cnt) as comp_name_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_mi
where inc_day>='202108'
group by consignor_mobile,consignor_city,consignor_comp_name
;

-- 计算top1
create table dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_1y as
select
consignor_mobile,consignor_city,consignor_comp_name as comp_name_1y,comp_name_cnt_1y
from (select
consignor_mobile,consignor_city,consignor_comp_name,comp_name_cnt_1y,
row_number() over(partition by consignor_mobile,consignor_city order by comp_name_cnt_1y desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_nm
) as t
where t.rn<=1
;

create table dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_6m as
select
consignor_mobile,consignor_city,consignor_comp_name as comp_name_6m,comp_name_cnt_6m
from (select
consignor_mobile,consignor_city,consignor_comp_name,comp_name_cnt_6m,
row_number() over(partition by consignor_mobile,consignor_city order by comp_name_cnt_6m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_nm
where comp_name_cnt_6m>0
) as t
where t.rn<=1
;


create table dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_3m as
select
consignor_mobile,consignor_city,consignor_comp_name as comp_name_3m,comp_name_cnt_3m
from (select
consignor_mobile,consignor_city,consignor_comp_name,comp_name_cnt_3m,
row_number() over(partition by consignor_mobile,consignor_city order by comp_name_cnt_6m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_nm
where comp_name_cnt_3m>0
) as t
where t.rn<=1
;

create table dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_top1_1m as
select
consignor_mobile,consignor_city,consignor_comp_name as comp_name_1m,comp_name_cnt_1m
from (select
consignor_mobile,consignor_city,consignor_comp_name,comp_name_cnt_1m,
row_number() over(partition by consignor_mobile,consignor_city order by comp_name_cnt_1m desc) as rn
from dm_gis_oms.dwm_sy_consignor_jjcs_comp_tmp_nm
where comp_name_cnt_1m>0
) as t
where t.rn<=1
;



-- 最近n个月寄件手机各城市寄付现结费用
-- 最近n个月寄件手机各城市寄付现结票数
create table dm_gis_oms.dwm_sy_consignor_jjcs_rmb_mi(
consignor_mobile string,
consignor_city string,
consignor_rmb  double comment "费用",
consignor_cnt  int comment "票数"
)
comment '各城市寄付现结'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY');

--
insert overwrite table dm_gis_oms.dwm_sy_consignor_jjcs_rmb_mi partition(inc_day='202204')
select consignor_mobile,src_dist_code,sum(all_fee_rmb) as consignor_rmb,count(1) as consignor_cnt
from dm_gis_oms.ods_sy_order_info_di
where inc_day>='20220401' and inc_day<'20220501'
and freight_payment_type_code='1' and freight_settlement_type_code='1'
and length(consignor_mobile)>4
and length(src_dist_code)>0
group by consignor_mobile,src_dist_code
;


--
create table dm_gis_oms.dwm_sy_consignor_jjcs_rmb_tmp_nm as
select
consignor_mobile,consignor_city,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then consignor_rmb else 0 end) as consignor_rmb_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then consignor_rmb else 0 end) as consignor_rmb_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then consignor_rmb else 0 end) as consignor_rmb_6m,
sum(consignor_rmb) as consignor_rmb_1y,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+11),'yyyy-MM-dd'),'yyyyMM')  then consignor_cnt else 0 end) as consignor_cnt_1m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+9),'yyyy-MM-dd'),'yyyyMM')  then consignor_cnt else 0 end) as consignor_cnt_3m,
sum(case when inc_day>=from_unixtime(unix_timestamp(add_months(from_unixtime(unix_timestamp('202108','yyyyMM'),'yyyy-MM-dd HH:mm:ss'),+6),'yyyy-MM-dd'),'yyyyMM')  then consignor_cnt else 0 end) as consignor_cnt_6m,
sum(consignor_cnt) as consignor_cnt_1y
from dm_gis_oms.dwm_sy_consignor_jjcs_rmb_mi
where inc_day>='202108'
group by consignor_mobile,consignor_city
;