-- ods层
-- 1. dm_gis_oms.ods_sy_order_info_di 
-- 来源 dwd.dwd_waybill_info_dtl_di 
CREATE  TABLE `dm_gis_oms.ods_sy_order_info_di`(
`waybill_id` string COMMENT '运单ID',
`waybill_no` string COMMENT '运单号',
`express_flow_code` string COMMENT '快件流向:原寄地区域或者国家到目的地区域或者国家',
`source_zone_code` string COMMENT '原寄地网点代码',
`dest_zone_code` string COMMENT '目的地网点代码未派送前是目的地城市代码 如755',
`addressee_dept_code` string COMMENT '目的地网点代码',
`consignor_team_code` string COMMENT '寄件单元区域',
`addressee_team_code` string COMMENT '目的地单元区域',
`addresseeaoicode` string COMMENT '收件方（派件）AOI区域编码',
`addresseeaoitype` string COMMENT '收件方（派件）AOI类型',
`src_dist_code` string COMMENT '原寄地区域代码',
`src_city_code` string COMMENT '源寄地城市代码',
`src_county` string COMMENT '源寄地区/县/镇',
`src_division_code` string COMMENT '源寄地分部',
`src_area_code` string COMMENT '源寄地区部',
`src_type_code` string COMMENT '源寄地网点类型',
`dest_dist_code` string COMMENT '目的地区域代码',
`dest_city_code` string COMMENT '目的地城市代码',
`dest_county` string COMMENT '目的地区/县/镇',
`dest_division_code` string COMMENT '目的地分部',
`dest_area_code` string COMMENT '目的地区部',
`dest_type_code` string COMMENT '目的地网点类型',
`src_lgt` string COMMENT '源寄地网点经度',
`src_lat` string COMMENT '源寄地网点纬度',
`dest_lgt` string COMMENT '目的地网点经度',
`dest_lat` string COMMENT '目的地网点纬度',
`meterage_weight_qty` double COMMENT '计费总重量',
`real_weight_qty` double COMMENT '实际重量',
`quantity` double COMMENT '包裹总件数',
`consigned_tm` string COMMENT '寄件时间',
`signin_tm` string COMMENT '签收时间',
`cargo_type_code` string COMMENT '快件内容(维表：dim.dim_pub_cargo_type_info_df)',
`limit_type_code` string COMMENT '时效类型(维表：dim.dim_tml_type_info_df)',
`distance_type_code` string COMMENT '区域类型(维表：dim.dim_pub_distance_type_info_df)',
`transport_type_code` string COMMENT '运输方式(TR1：陆运件,TR2:航空件)',
`express_type_code` string COMMENT '业务类型(维表：dim.dim_prod_express_type_info_df)',
`volume` double COMMENT '总体积',
`bill_long` double COMMENT '总长',
`bill_width` double COMMENT '总宽',
`bill_high` double COMMENT '总高',
`unit_weight` string COMMENT '重量计量单位',
`cons_value` double COMMENT '声明价值',
`cons_value_currency_code` string COMMENT '声明价值币种',
`product_code` string COMMENT ' 产品代码 （维表：dim.dim_product_info）',
`waybill_type` string COMMENT '1为纸质运单0为电子单',
`waybill_remark` string COMMENT '备注',
`order_no` string COMMENT '顺丰订单号',
`contacts_id` string COMMENT '收寄联系人ID',
`consignor_comp_name` string COMMENT '寄件公司',
`consignor_addr` string COMMENT '寄件地址',
`consignor_phone` string COMMENT '寄件电话',
`consignor_cont_name` string COMMENT '寄件联系人',
`consignor_mobile` string COMMENT '寄件手机',
`consignee_comp_name` string COMMENT '收件公司',
`consignee_addr` string COMMENT '收件地址',
`consignee_phone` string COMMENT '收件电话',
`consignee_cont_name` string COMMENT '收件联系人',
`consignee_mobile` string COMMENT '收件手机',
`consignor_addr_native` string COMMENT '寄方客户编码',
`consignee_addr_native` string COMMENT '收方客户编码',
`freight_monthly_acct_code` string COMMENT '运费月结账号',
`freight_payment_type_code` string COMMENT '运费付款方式:1.寄付2.到付3.第三方付',
`freight_settlement_type_code` string COMMENT '运费结算类型:1.现结2.月结',
`freight_payment_change_type_code` string COMMENT '运费付款方式变更',
`comb_payment_type_code` string COMMENT '组合付款方式:寄付/到付/三方付结合月结/现结',
`cod_monthly_acct_code` string COMMENT '代收货款月结账号',
`all_fee` double COMMENT '总费用(除代收货款外)',
`all_fee_rmb` double COMMENT '总费用折人民币(除代收货款外)',
`freight` double COMMENT '运费',
`freight_rmb` double COMMENT '运费折人民币',
`cod_fee` double COMMENT '代收货款金额',
`cod_fee_rmb` double COMMENT '代收货款折人民币金额',
`consignor_tax_no` string COMMENT '寄件人税号',
`unified_code` string COMMENT '统一编码（收件人税号）',
`service_prod_code` array<string> COMMENT '增值服务代码',
`is_value_insured` int COMMENT '是否保价1是0否',
`cons_name` array<string> COMMENT '托寄物名称',
`package_no` array<string> COMMENT '包裹运单号',
`source_waybill_no` string COMMENT '原单号',
`box_type_code` string COMMENT '箱类型',
`temperature_range` string COMMENT '温控范围',
`labelling_pattern` array<string> COMMENT '标记类型',
`inner_parcel_flag` string COMMENT '是否内部件',
`self_send_flag` string COMMENT '是否自寄件',
`self_pickup_flag` string COMMENT '是否自取件',
`has_service_prod_flag` string COMMENT '有增值服务标志',
`is_interior` string COMMENT '是否对内',
`transfer_parcel_flag` string COMMENT '是否转寄件',
`b2c_flag` string COMMENT '是否B2C',
`free_parcel_flag` string COMMENT '是否免费件',
`frangible_parcel_flag` string COMMENT '是否易碎件',
`c_client` string COMMENT 'c类客户0:否1:是',
`cod_bill_flag` string COMMENT '是否上门收款',
`src_province` string COMMENT '源寄地省份',
`dest_province` string COMMENT '目的地省份',
`meterage_weight_qty_kg` double COMMENT '计费总重量（kg）',
`real_weight_qty_kg` double COMMENT '实际总重量（kg）',
`declared_value` double COMMENT '声明价值（保价）',
`declared_value_currency_code` string COMMENT '声明价值（保价）币种',
`cons_fee` double COMMENT '保价费',
`cons_fee_currency_code` string COMMENT '保价费币种',
`consign_tag` string COMMENT 'C1:易燃\;C21高价，且能线上剥离，c-box集装\;C22:高价，不能线上剥离集装\;C30:原始三级目录SOP标签标识为C3但大数据易碎标识label_fragile为非易碎的，仅监控，不剥离不集装\;C31:易碎，且线上剥离，c-box集装\;C32:易碎，暂不具备剥离集装条件\;C33:易碎，卸货口剥离，不集装\;C39:易碎，卸货口剥离，小蓝箱集装\;C40:冷冻，不冷藏\;C41:冷冻，应入冷库\;C50:保鲜，不冷藏\;C51:保鲜，应入冷库\;C6:正常\;C7:其他。',
`consignor_phone_dw` string COMMENT '寄件电话(数仓清洗后)',
`consignor_mobile_dw` string COMMENT '寄件手机(数仓清洗后)',
`consignee_phone_dw` string COMMENT '收件电话(数仓清洗后)',
`consignee_mobile_dw` string COMMENT '收件手机(数仓清洗后)',
`addressee_aoi_id` string COMMENT '收件方（派件）aoiid',
`limit_tag` string COMMENT 'T1:即日\;T4:特快\;T6:标快\;SP6:标快+\;T801:特快+\;T36:陆运填仓\;T40:航空填仓',
`addressee_building_id` string COMMENT '收件方（派件）楼栋ID',
`addressee_aoi_dept_code` string COMMENT ' 收件方（派件）aoi编码 （维表：dim.dim_aoi_info_df）',
`consignor_aoi_dept_code` string COMMENT ' 寄方aoi编码 （维表：dim.dim_aoi_info_df）',
`consignor_aoi_id` string COMMENT '寄方aoiid',
`receipt_model_tag` string COMMENT ' 收件模式标签 （P1=仓收,P2=集收,P3=散收）',
`sorting_model_tag` string COMMENT ' 分拣模式标签 （S1=扁平件,S2=小件,S3=包裹,S4=重货）',
`delivery_model_tag` string COMMENT ' 派件模式标签 （D1=一级中转场直派,D2=二级中转场直派,D3=网点派送,D4=派件到柜）',
`route_code` string COMMENT '路由代码',
`sort_code` string COMMENT '分拣代码',
`is_5000_fw` int COMMENT '当天丰网只做了5000的运单（1：是，0：否）',
`fee_ind_rmd` double COMMENT '个性化计费费用(rmb)',
`dw_data_insert_time` string COMMENT '数据插入时间')
COMMENT '新运单宽表'
PARTITIONED BY (`inc_day` string)
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');



-- 写入历史数据
-- hive脚本
set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set mapreduce.input.fileinputformat.split.maxsize=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.rack=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.node=268435456;
set mapred.max.split.size=268435456;
set mapred.min.split.size.per.node=268435456;
set mapred.min.split.size.per.rack=268435456;
--设置jvm重用
set mapred.job.reuse.jvm.num.tasks=10;

insert overwrite table dm_gis_oms.ods_sy_order_info_di partition(inc_day)
select
waybill_id
,t0.waybill_no as waybill_no
,express_flow_code
,source_zone_code
,dest_zone_code
,addressee_dept_code
,consignor_team_code
,addressee_team_code
,addresseeaoicode
,addresseeaoitype
,src_dist_code
,src_city_code
,src_county
,src_division_code
,src_area_code
,src_type_code
,dest_dist_code
,dest_city_code
,dest_county
,dest_division_code
,dest_area_code
,dest_type_code
,src_lgt
,src_lat
,dest_lgt
,dest_lat
,meterage_weight_qty
,real_weight_qty
,quantity
,consigned_tm
,signin_tm
,cargo_type_code
,limit_type_code
,distance_type_code
,transport_type_code
,express_type_code
,volume
,bill_long
,bill_width
,bill_high
,unit_weight
,cons_value
,cons_value_currency_code
,product_code
,waybill_type
,waybill_remark
,order_no
,contacts_id
,consignor_comp_name
,t1.consignor_addr as consignor_addr
,consignor_phone
,consignor_cont_name
,consignor_mobile
,consignee_comp_name
,t2.consignee_addr as consignee_addr
,consignee_phone
,consignee_cont_name
,consignee_mobile
,consignor_addr_native
,consignee_addr_native
,freight_monthly_acct_code
,freight_payment_type_code
,freight_settlement_type_code
,freight_payment_change_type_code
,comb_payment_type_code
,cod_monthly_acct_code
,all_fee
,all_fee_rmb
,freight
,freight_rmb
,cod_fee
,cod_fee_rmb
,consignor_tax_no
,unified_code
,service_prod_code
,is_value_insured
,cons_name
,package_no
,source_waybill_no
,box_type_code
,temperature_range
,labelling_pattern
,inner_parcel_flag
,self_send_flag
,self_pickup_flag
,has_service_prod_flag
,is_interior
,transfer_parcel_flag
,b2c_flag
,free_parcel_flag
,frangible_parcel_flag
,c_client
,cod_bill_flag
,src_province
,dest_province
,meterage_weight_qty_kg
,real_weight_qty_kg
,declared_value
,declared_value_currency_code
,cons_fee
,cons_fee_currency_code
,consign_tag
,consignor_phone_dw
,consignor_mobile_dw
,consignee_phone_dw
,consignee_mobile_dw
,addressee_aoi_id
,limit_tag
,addressee_building_id
,addressee_aoi_dept_code
,consignor_aoi_dept_code
,consignor_aoi_id
,receipt_model_tag
,sorting_model_tag
,delivery_model_tag
,route_code
,sort_code
,is_5000_fw
,fee_ind_rmd
,dw_data_insert_time
,inc_day
from
(
select
waybill_id
,waybill_no
,express_flow_code
,source_zone_code
,dest_zone_code
,addressee_dept_code
,consignor_team_code
,addressee_team_code
,addresseeaoicode
,addresseeaoitype
,src_dist_code
,src_city_code
,src_county
,src_division_code
,src_area_code
,src_type_code
,dest_dist_code
,dest_city_code
,dest_county
,dest_division_code
,dest_area_code
,dest_type_code
,src_lgt
,src_lat
,dest_lgt
,dest_lat
,meterage_weight_qty
,real_weight_qty
,quantity
,consigned_tm
,signin_tm
,cargo_type_code
,limit_type_code
,distance_type_code
,transport_type_code
,express_type_code
,volume
,bill_long
,bill_width
,bill_high
,unit_weight
,cons_value
,cons_value_currency_code
,product_code
,waybill_type
,waybill_remark
,order_no
,contacts_id
,consignor_comp_name
,consignor_addr
,consignor_phone
,consignor_cont_name
,consignor_mobile
,consignee_comp_name
,consignee_addr
,consignee_phone
,consignee_cont_name
,consignee_mobile
,consignor_addr_native
,consignee_addr_native
,freight_monthly_acct_code
,freight_payment_type_code
,freight_settlement_type_code
,freight_payment_change_type_code
,comb_payment_type_code
,cod_monthly_acct_code
,all_fee
,all_fee_rmb
,freight
,freight_rmb
,cod_fee
,cod_fee_rmb
,consignor_tax_no
,unified_code
,service_prod_code
,is_value_insured
,cons_name
,package_no
,source_waybill_no
,box_type_code
,temperature_range
,labelling_pattern
,inner_parcel_flag
,self_send_flag
,self_pickup_flag
,has_service_prod_flag
,is_interior
,transfer_parcel_flag
,b2c_flag
,free_parcel_flag
,frangible_parcel_flag
,c_client
,cod_bill_flag
,src_province
,dest_province
,meterage_weight_qty_kg
,real_weight_qty_kg
,declared_value
,declared_value_currency_code
,cons_fee
,cons_fee_currency_code
,consign_tag
,consignor_phone_dw
,consignor_mobile_dw
,consignee_phone_dw
,consignee_mobile_dw
,addressee_aoi_id
,limit_tag
,addressee_building_id
,addressee_aoi_dept_code
,consignor_aoi_dept_code
,consignor_aoi_id
,receipt_model_tag
,sorting_model_tag
,delivery_model_tag
,route_code
,sort_code
,is_5000_fw
,fee_ind_rmd
,dw_data_insert_time
,inc_day 
from dwd.dwd_waybill_info_dtl_di where inc_day='20220721'
) as t0
left join (select waybill_no,consignor_addr from dm_addr.consignor_addr where inc_day='20220721' ) as t1
on md5(t0.waybill_no)=t1.waybill_no
left join (select waybill_no,consignee_addr from dm_addr.consignee_addr where inc_day='20220721' ) as t2
on md5(t0.waybill_no)=t2.waybill_no
;



select
inc_day,max(dw_data_insert_time)
from dwd.dwd_waybill_info_dtl_di where inc_day>=20220401
group by inc_day


-- dm_gis_oms.ods_tals_tel_base （电话基础表）
-- 来源 hbase  tals_tel_base

CREATE EXTERNAL TABLE `dm_gis_oms.tals_tel_base`(
`rowkey` string COMMENT '',
`info` string COMMENT ''
)
COMMENT '电话基础表'
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');


CREATE EXTERNAL TABLE `dm_gis_oms.ods_tals_tel_base`(
`tel` string COMMENT '加密电话(规范化后的加密电话)',
`tel_decode` string COMMENT '解密电话(明文)',
`tel_md5` string COMMENT '解密电话的MD5值(明文电话的MD5值，小写)',
`name` string COMMENT '姓名',
`is_name_abnormal` string COMMENT '姓名是否异常（true：异常；false：非异常）',
`location` string COMMENT '归属地（规范化后的城市名）',
`citycode` string COMMENT '城市编码',
`type` string COMMENT '电话运营商类型（电信；移动；连通）',
`is_sr_in_spring_day` string COMMENT '是否在春节有过收寄行为',
`is_abnormal` string COMMENT '是否异常（根据异常电话规则判断,true：异常；false：非异常；）',
`abnormal_tag` string COMMENT '异常判断方式（异常规则中的异常标记）',
`is_fraud` string COMMENT '是否欺诈电话',
`is_sell` string COMMENT '是否推销电话'
)
COMMENT '电话基础表'
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');

-- 写数据
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;

add jar hdfs://sfbdp1//tmp/udf/01416344/112905/1000/tals-udf.jar;
create temporary function convert_md5 as 'com.sf.gis.java.tals.udf.Md5EncodeDecode';

insert overwrite table dm_gis_oms.ods_tals_tel_base 
select 
get_json_object(convert_md5(info),'$.tel') as tel,
get_json_object(convert_md5(info),'$.telDecode') as tel_decode,
get_json_object(convert_md5(info),'$.telMd5') as tel_md5,
get_json_object(convert_md5(info),'$.name') as name,
get_json_object(convert_md5(info),'$.isNameAbnormal') as is_name_abnormal,
get_json_object(convert_md5(info),'$.location') as location,
get_json_object(convert_md5(info),'$.citycode') as citycode,
get_json_object(convert_md5(info),'$.type') as type,
get_json_object(convert_md5(info),'$.isSRInSpringDay') as is_sr_in_spring_day,
get_json_object(convert_md5(info),'$.isAbnormal') as is_abnormal,
get_json_object(convert_md5(info),'$.abnormalTag') as abnormal_tag,
get_json_object(convert_md5(info),'$.isFraud') as is_fraud,
get_json_object(convert_md5(info),'$.isSell') as is_sell 
from dm_gis_oms.tals_tel_base


-- 新运动宽表分析
create table dm_gis_oms.ods_sy_order_info_di_01_tmp1 as 
select dtime,count(1) as cnt   from 
(select substring(dw_data_insert_time,0,10) as dtime from  dm_gis_oms.ods_sy_order_info_di_01 where inc_day='2022031801') as a group by dtime order by dtime;

create table dm_gis_oms.ods_sy_order_info_di_01_tmp2 as 
select dtime,count(1) as cnt   from 
(select substring(dw_data_insert_time,0,10) as dtime from  dm_gis_oms.ods_sy_order_info_di_01 where inc_day='2022031802') as a group by dtime order by dtime;

--
create table dm_gis_oms.ods_sy_order_info_di_01_tmp3 as 
select a.* from (select * from  dm_gis_oms.ods_sy_order_info_di_01 where inc_day='2022031801') as a 
left join
(select waybill_id from  dm_gis_oms.ods_sy_order_info_di_01 where inc_day='2022031802' and dw_data_insert_time>='2022-04-19' ) as b 
on a.waybill_id=b.waybill_id
where b.waybill_id is not null 
;

create table dm_gis_oms.ods_sy_order_info_di_01_tmp4 as 
select * from  dm_gis_oms.ods_sy_order_info_di_01_tmp3 
union all 
select * from  dm_gis_oms.ods_sy_order_info_di_01 where inc_day='2022031802' and dw_data_insert_time>='2022-04-19'
;


--
create table dm_gis_oms.ods_sy_order_info_di_01_tmp5 as 
select * from  dm_gis_oms.ods_sy_order_info_di  where inc_day='20220304' and dw_data_insert_time>='2022-04-20'

insert into  dm_gis_oms.ods_sy_order_info_di_01_tmp5
select * from  dm_gis_oms.ods_sy_order_info_di  where inc_day='20220201' and dw_data_insert_time>='2022-04-20'


--  dm_gis_oms.ods_ly_order_info_di（冷运运单宽表）
-- 来源 dwd_ly.dwd_ly_pub_waybill_dtl_di
CREATE TABLE `dm_gis_oms.ods_ly_order_info_di`(
`waybill_id` string COMMENT '运单ID',
`waybill_no` string COMMENT '运单号',
`source_zone_code` string COMMENT '原寄地网点代码',
`addressee_dept_code` string COMMENT '目的地网点代码',
`consignor_team_code` string COMMENT '寄件单元区域',
`addressee_team_code` string COMMENT '目的地单元区域',
`addresseeaoicode` string COMMENT '收件方（派件）AOI区域编码',
`addresseeaoitype` string COMMENT '收件方（派件）AOI类型',
`src_dist_code` string COMMENT '原寄地区域代码',
`src_county` string COMMENT '源寄地区/县/镇',
`src_division_code` string COMMENT '源寄地分部',
`src_area_code` string COMMENT '源寄地区部',
`src_type_code` string COMMENT '源寄地网点类型',
`dest_dist_code` string COMMENT '目的地区域代码',
`dest_city_code` string COMMENT '目的地城市代码',
`dest_county` string COMMENT '目的地区/县/镇',
`dest_division_code` string COMMENT '目的地分部',
`dest_area_code` string COMMENT '目的地区部',
`dest_type_code` string COMMENT '目的地网点类型',
`src_lgt` string COMMENT '源寄地网点经度',
`src_lat` string COMMENT '源寄地网点纬度',
`dest_lgt` string COMMENT '目的地网点经度',
`dest_lat` string COMMENT '目的地网点纬度',
`meterage_weight_qty` double COMMENT '计费总重量',
`real_weight_qty` double COMMENT '实际重量',
`consigned_tm` string COMMENT '寄件时间',
`signin_tm` string COMMENT '签收时间',
`cargo_type_code` string COMMENT '快件内容',
`limit_type_code` string COMMENT '时效类型',
`distance_type_code` string COMMENT '区域类型',
`transport_type_code` string COMMENT '运输方式',
`express_type_code` string COMMENT '业务类型',
`volume` double COMMENT '总体积',
`bill_long` double COMMENT '总长',
`bill_width` double COMMENT '总宽',
`bill_high` double COMMENT '总高',
`product_code` string COMMENT '产品代码',
`waybill_remark` string COMMENT '备注',
`order_no` string COMMENT '顺丰订单号',
`contacts_id` string COMMENT '收寄联系人ID',
`consignor_comp_name` string COMMENT '寄件公司',
`consignor_addr` string COMMENT '寄件地址',
`consignor_phone` string COMMENT '寄件电话',
`consignor_cont_name` string COMMENT '寄件联系人',
`consignor_mobile` string COMMENT '寄件手机',
`consignee_comp_name` string COMMENT '收件公司',
`consignee_addr` string COMMENT '收件地址',
`consignee_phone` string COMMENT '收件电话',
`consignee_cont_name` string COMMENT '收件联系人',
`consignee_mobile` string COMMENT '收件手机',
`consignor_addr_native` string COMMENT '寄方客户编码',
`consignee_addr_native` string COMMENT '收方客户编码',
`freight_monthly_acct_code` string COMMENT '运费月结账号',
`comb_payment_type_code` string COMMENT '组合付款方式:寄付/到付/三方付结合月结/现结',
`cod_monthly_acct_code` string COMMENT '代收货款月结账号',
`all_fee_rmb` double COMMENT '总费用折人民币(除代收货款外)',
`freight_rmb` double COMMENT '运费折人民币',
`cod_fee_rmb` double COMMENT '代收货款折人民币金额',
`service_prod_code` string COMMENT '增值服务代码',
`is_value_insured` int COMMENT '是否保价1是0否',
`cons_name` string COMMENT '托寄物名称',
`source_waybill_no` string COMMENT '原单号',
`temperature_range` string COMMENT '温控范围',
`self_send_flag` string COMMENT '是否自寄件',
`self_pickup_flag` string COMMENT '是否自取件',
`has_service_prod_flag` string COMMENT '有增值服务标志',
`b2c_flag` string COMMENT '是否B2C',
`src_province` string COMMENT '源寄地省份',
`dest_province` string COMMENT '目的地省份',
`meterage_weight_qty_kg` double COMMENT '计费总重量（kg）',
`real_weight_qty_kg` double COMMENT '实际总重量（kg）',
`declared_value` double COMMENT '声明价值（保价）',
`cons_fee` double COMMENT '保价费',
`consign_tag` string COMMENT '托寄物标签',
`limit_tag` string COMMENT '时效标签',
`addressee_aoi_dept_code` string COMMENT '收件方（派件）aoi编码',
`consignor_aoi_dept_code` string COMMENT '寄方aoi编码',
`receipt_model_tag` string COMMENT '收件模式标签',
`sorting_model_tag` string COMMENT '分拣模式标签',
`delivery_model_tag` string COMMENT '派件模式标签',
`route_code` string COMMENT '路由代码',
`sort_code` string COMMENT '分拣代码',
`pickup_fee` double COMMENT '提货服务费',
`delivery_fee` double COMMENT '配送服务费',
`special_house_fee` double COMMENT '特殊入仓费',
`unload_fee` double COMMENT '装卸服务费',
`keeping_fee` double COMMENT '货物保管费',
`self_delivery_fee` double COMMENT '自取件费用',
`self_pickup_fee` double COMMENT '自寄件费用',
`return_fee` double COMMENT '签单返还费用',
`other_fee` double COMMENT '其他费用',
`animal_fee` double COMMENT '动检证费用',
`quantity` bigint COMMENT '运单总件数',
`waybill_status` string COMMENT '运单状态',
`cancel_reason` string COMMENT '取消原因',
`pay_status` string COMMENT '支付状态:待支付Pending支付中Processing支付成功Completed支付失败Voided',
`pay_time` string COMMENT '支付成功时间',
`special_flag` string COMMENT '特殊标识(值:2916)',
`product_alias_code` string COMMENT '冷运产品别名',
`sender_dept_code` string COMMENT '寄件大网网点',
`receiver_dept_code` string COMMENT '派件大网网点',
`red_meterage_weight_flag` string COMMENT '红冲计费重量标识(Y红冲过\;N未红冲过)',
`product_name` string COMMENT '产品名称',
`src_city_code` string COMMENT '原寄地城市',
`warehouse_flag` string COMMENT '仓内/仓外标识')
COMMENT '冷运运单宽表'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');


-- 写数据
set mapreduce.job.queuename=gis;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;

insert overwrite table dm_gis_oms.ods_ly_order_info_di partition(inc_day) 
select 
waybill_id
,waybill_no
,source_zone_code
,addressee_dept_code
,consignor_team_code
,addressee_team_code
,addresseeaoicode
,addresseeaoitype
,src_dist_code
,src_county
,src_division_code
,src_area_code
,src_type_code
,dest_dist_code
,dest_city_code
,dest_county
,dest_division_code
,dest_area_code
,dest_type_code
,src_lgt
,src_lat
,dest_lgt
,dest_lat
,meterage_weight_qty
,real_weight_qty
,consigned_tm
,signin_tm
,cargo_type_code
,limit_type_code
,distance_type_code
,transport_type_code
,express_type_code
,volume
,bill_long
,bill_width
,bill_high
,product_code
,waybill_remark
,order_no
,contacts_id
,consignor_comp_name
,consignor_addr
,consignor_phone
,consignor_cont_name
,consignor_mobile
,consignee_comp_name
,consignee_addr
,consignee_phone
,consignee_cont_name
,consignee_mobile
,consignor_addr_native
,consignee_addr_native
,freight_monthly_acct_code
,comb_payment_type_code
,cod_monthly_acct_code
,all_fee_rmb
,freight_rmb
,cod_fee_rmb
,service_prod_code
,is_value_insured
,cons_name
,source_waybill_no
,temperature_range
,self_send_flag
,self_pickup_flag
,has_service_prod_flag
,b2c_flag
,src_province
,dest_province
,meterage_weight_qty_kg
,real_weight_qty_kg
,declared_value
,cons_fee
,consign_tag
,limit_tag
,addressee_aoi_dept_code
,consignor_aoi_dept_code
,receipt_model_tag
,sorting_model_tag
,delivery_model_tag
,route_code
,sort_code
,pickup_fee
,delivery_fee
,special_house_fee
,unload_fee
,keeping_fee
,self_delivery_fee
,self_pickup_fee
,return_fee
,other_fee
,animal_fee
,quantity
,waybill_status
,cancel_reason
,pay_status
,pay_time
,special_flag
,product_alias_code
,sender_dept_code
,receiver_dept_code
,red_meterage_weight_flag
,product_name
,src_city_code
,warehouse_flag
,inc_day  
from dwd_ly.dwd_ly_pub_waybill_dtl_di where inc_day>=20220401 and inc_day<20220403


