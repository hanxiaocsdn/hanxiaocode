-- dws 速运大宽表

-- 全量数据累计相关的标签
set mapreduce.job.queuename=gis_public;

create table dm_gis_oms.dws_sy_order_bw1 as 
select t0.tel,t0.name,
t1.consignor_name_top3,
t2.consignee_name_top3,
t3.city,t3.citycode,t3.province,t3.date_sign,t3.czdz,t3.gsdz,
t4.consignor_comp_name,t4.freight_monthly_acct_code,
t5.last_consigned_tm,t5.last_consigned_city,
t6.first_consigned_tm,
t7.consigned_cnt,t7.consigned_jf_cnt,t7.consigned_df_cnt,t7.consigned_dsff_cnt,t7.consigned_sd_cnt,t7.self_send_cnt,t7.self_pickup_cnt,
t8.consignee_cnt,t8.consignee_sd_cnt,
t9.consignor_tm_cntmax,t9.consignor_tm_zs_cnt,t9.consignor_tm_zw_cnt,t9.consignor_tm_ws_cnt,t9.total_rmb,t9.total_jf_rmb,t9.total_df_rmb,t9.total_sff_rmb,
t10.limit_type_code_top3,
t11.directed_trace_top3,
t12.consignee_mobile_top3,
t13.consignor_mobile_top3,
t14.consignee_mobile,t14.consignor_cnt,t14.avg_sff_rmb,
t15.consignor_prod_code_top3,
t16.consignee_prod_code_top3,
t17.mdd_top3,
t18.consignor_addr_top3,
t19.consignee_addr_top3,
t20.consignor_cons_top3,
t21.consignee_cons_top3  
from dm_gis_oms.ods_tals_tel_base as t0
left join (select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignor_cont_name, ':', ''),cast(consignor_name_cnt as string))) as consignor_name_top3 
from dm_gis_oms.dwm_sy_consignor_name_tmp group by consignor_mobile ) as t1 
on t0.tel=t1.consignor_mobile 
left join (select consignee_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignee_cont_name, ':', ''),cast(consignee_name_cnt as string))) as consignee_name_top3 
from dm_gis_oms.dwm_sy_consignee_name_tmp group by consignee_mobile) as t2 
on t0.tel=t2.consignee_mobile 
left join (select tel,city,citycode,province,date_sign,czdz,gsdz from dm_gis_oms.dwm_tel_czcs_tmp1) as t3
on t0.tel=t3.tel 
left join (select consignor_mobile,consignor_comp_name,freight_monthly_acct_code from dm_gis_oms.dwm_sy_company_halfyear_tmp) as t4 
on t0.tel=t4.consignor_mobile 
left join (select consignor_mobile,last_consigned_tm,last_consigned_city  from dm_gis_oms.dwm_sy_last_consignor_tmp) as t5 
on t0.tel=t5.consignor_mobile 
left join (select consignor_mobile,first_consigned_tm  from dm_gis_oms.dwm_sy_first_consignor_tmp) as t6 
on t0.tel=t6.consignor_mobile 
left join (select consignor_mobile,consigned_cnt,consigned_jf_cnt,consigned_df_cnt,consigned_dsff_cnt,consigned_sd_cnt,self_send_cnt,self_pickup_cnt 
from dm_gis_oms.dwm_sy_total_consignor_tmp) as t7
on t0.tel=t7.consignor_mobile 
left join (select consignee_mobile,consignee_cnt,consignee_sd_cnt from dm_gis_oms.dwm_sy_total_consignee_tmp) as t8 
on t0.tel=t8.consignee_mobile 
left join (select consignor_mobile,consignor_tm_cntmax,consignor_tm_zs_cnt,consignor_tm_zw_cnt,consignor_tm_ws_cnt,total_rmb,total_jf_rmb,total_df_rmb,total_sff_rmb 
from dm_gis_oms.dwm_sy_total_consignor_tm_rmb_tmp) as t9
on t0.tel=t9.consignor_mobile 
left join (select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(limit_type_code, ':', ''),cast(limit_type_cnt as string))) as limit_type_code_top3 
from dm_gis_oms.dwm_sy_consignor_limit_type_tmp  group by consignor_mobile ) as t10 
on t0.tel=t10.consignor_mobile 
left join (select consignor_mobile,collect_list(concat_ws(':',concat_ws('->',src_dist_code,dest_dist_code),cast(consignor_city_cnt as string))) as directed_trace_top3  
from dm_gis_oms.dwm_sy_consignor_directed_trace_tmp group by consignor_mobile) as t11 
on t0.tel=t11.consignor_mobile 
left join (select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignee_mobile, ':', ''),cast(contact_cnt as string))) as consignee_mobile_top3  
from dm_gis_oms.dwm_sy_consignor_consignee_tmp group by consignor_mobile) as t12 
on t0.tel=t12.consignor_mobile 
left join (select consignee_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignor_mobile, ':', ''),cast(contact_cnt as string))) as consignor_mobile_top3  
from dm_gis_oms.dwm_sy_consignee_consignor_tmp group by consignee_mobile) as t13 
on t0.tel=t13.consignee_mobile 
left join (select consignor_mobile,consignee_mobile,consignor_cnt,avg_sff_rmb 
from dm_gis_oms.dwm_sy_sd_each_tmp ) as t14 
on t0.tel=t14.consignor_mobile 
left join (select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(prod_code, ':', ''),cast(prod_code_cnt as string))) as consignor_prod_code_top3  
from dm_gis_oms.dwm_sy_consignor_service_tmp group by consignor_mobile) as t15 
on t0.tel=t15.consignor_mobile 
left join (select consignee_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(prod_code, ':', ''),cast(prod_code_cnt as string))) as consignee_prod_code_top3  
from dm_gis_oms.dwm_sy_consignee_service_tmp group by consignee_mobile) as t16
on t0.tel=t16.consignee_mobile 
left join (select consignor_mobile,collect_list(concat_ws(':',consignee_addr,cast(consignee_addr_cnt as string))) as mdd_top3  
from dm_gis_oms.dwm_sy_consignor_mdd_tmp group by consignor_mobile) as t17 
on t0.tel=t17.consignor_mobile 
left join (select consignor_mobile,collect_list(concat_ws(':',consignor_addr,cast(consignor_addr_cnt as string))) as  consignor_addr_top3 
from dm_gis_oms.dwm_sy_consignor_addr_tmp group by consignor_mobile) as t18 
on t0.tel=t18.consignor_mobile 
left join (select consignee_mobile,collect_list(concat_ws(':',consignee_addr,cast(consignee_addr_cnt as string))) as  consignee_addr_top3  
from dm_gis_oms.dwm_sy_consignee_addr_tmp group by consignee_mobile) as t19 
on t0.tel=t19.consignee_mobile 
left join (select consignor_mobile, collect_list(concat_ws(':',REGEXP_REPLACE(cons, ':', ''),cast(cons_cnt as string))) as consignor_cons_top3  
from dm_gis_oms.dwm_sy_consignor_cons_tmp group by consignor_mobile) as t20 
on t0.tel=t20.consignor_mobile 
left join (select consignee_mobile, collect_list(concat_ws(':',REGEXP_REPLACE(cons, ':', ''),cast(cons_cnt as string))) as consignee_cons_top3   
from dm_gis_oms.dwm_sy_consignee_cons_tmp group by consignee_mobile) as t21 
on t0.tel=t21.consignee_mobile 
;  





-- 大宽表 dm_gis_oms.dwm_sy_order_bw （全量累计与近一年内）
-- 
create table dm_gis_oms.dwm_sy_order_bw (
tel string COMMENT '手机',
name string COMMENT '姓名',
consignor_name_top3 array<string> COMMENT '寄件常用名Top3',
consignee_name_top3 array<string> COMMENT '收件常用名Top3',
city string COMMENT '常住城市',
citycode string COMMENT '常住城市编码',
province  string COMMENT '常住城市所在省',
date_sign  string COMMENT '常住城市最后一次收寄日期',
czdz string COMMENT '居住地址',
gsdz string COMMENT '工作地址',
consignor_comp_name string COMMENT '公司',
freight_monthly_acct_code string COMMENT '公司对应月结账号',
last_consigned_tm string COMMENT '最近一次寄件日期',
last_consigned_city string COMMENT '最近一次寄件城市',
first_consigned_tm string COMMENT '首次寄件日期',
consigned_cnt int COMMENT '累计寄件次数',
consigned_jf_cnt int COMMENT '累计寄件寄付票数',
consigned_df_cnt int COMMENT '累计寄件到付票数',
consigned_dsff_cnt int COMMENT '累计寄件第三方付票数',
consigned_sd_cnt int COMMENT '累计散单寄件次数',
self_send_cnt int COMMENT '网点自寄票数',
self_pickup_cnt int COMMENT '网点自取票数',
consignee_cnt int COMMENT '累计收件次数',
consignee_sd_cnt int COMMENT '累计散单收件次数',
consignor_tm_cntmax string COMMENT '常用寄件时间段',
consignor_tm_zs_cnt int COMMENT '早上寄件量',
consignor_tm_zw_cnt int COMMENT '中午寄件量',
consignor_tm_ws_cnt int COMMENT '晚上寄件量',
total_rmb double COMMENT '寄件总费用',
total_jf_rmb double COMMENT '寄件寄付费用总计',
total_df_rmb double COMMENT '寄件到付费用总计',
total_sff_rmb double COMMENT '寄件第三方付费用总计',
limit_type_code_top3 array<string> COMMENT '寄件时效类型top3',
directed_trace_top3 array<string> COMMENT '常用寄件城市流向Top3',
consignee_mobile_top3 array<string> COMMENT '常用寄件联系人(收件方)Top3',
consignor_mobile_top3 array<string> COMMENT '常用寄件联系人(寄件方)Top3',
consignee_mobile  string COMMENT '散单互寄频次最高的号码',
consignor_cnt  int COMMENT '散单互寄频次最高对应件量',
avg_sff_rmb double COMMENT '散单互寄频次最高对应票均运费',
consignor_prod_code_top3  array<string> COMMENT '常用寄件增值服务Top3',
consignee_prod_code_top3 array<string> COMMENT '常用收件增值服务Top3',
mdd_top3 array<string> COMMENT '常用寄件目的地Top3',
consignor_addr_top3 array<string> COMMENT '常用寄件地址Top3',
consignee_addr_top3 array<string> COMMENT '常用收件地址Top3',
consignor_cons_top3 array<string> COMMENT '常寄托寄物',
consignee_cons_top3  array<string> COMMENT '常收托寄物',
consignor_cnt_30 int COMMENT '近1个月寄件量',
consignor_cnt_90 int COMMENT '近3个月寄件量',
consignor_cnt_180 int COMMENT '近6个月寄件量',
consignor_cnt_365 int COMMENT '近1年寄件量',
consignor_cnt_30_weekend int COMMENT '近1个月周末寄件量',
consignor_cnt_90_weekend int COMMENT '近3个月周末寄件量',
consignor_cnt_180_weekend int COMMENT '近6个月周末寄件量',
consignor_cnt_365_weekend int COMMENT '近1年周末寄件量',
consignor_30_weekend_ratio double COMMENT '近1个月周末寄件量占比',
consignor_90_weekend_ratio double COMMENT '近3个月周末寄件量占比',
consignor_180_weekend_ratio double COMMENT '近6个月周末寄件量占比',
consignor_365_weekend_ratio double COMMENT '近1年周末寄件量占比',
consignor_air_30 int COMMENT '近1个月空运寄件量',
consignor_land_30 int COMMENT '近1个月陆运寄件量',
consignor_air_90 int COMMENT '近3个月空运寄件量',
consignor_land_90 int COMMENT '近3个月陆运寄件量',
consignor_air_180 int COMMENT '近6个月空运寄件量',
consignor_land_180 int COMMENT '近6个月陆运寄件量',
consignor_air_365 int COMMENT '近1年空运寄件量',
consignor_land_365 int COMMENT '近1年陆运寄件量',
consignor_30_air_ratio double COMMENT '近1个月空运寄件量占比',
consignor_30_land_ratio double COMMENT '近1个月陆运寄件量占比',
consignor_cashdown_30 int COMMENT '近1个月散单寄件量',
consignor_cashdown_90 int COMMENT '近3个月散单寄件量',
consignor_cashdown_180 int COMMENT '近6个月散单寄件量',
consignor_cashdown_365 int COMMENT '近1年散单寄件量',
consignor_cashdown_weekend_30 int COMMENT '近1个月周末散单寄件量',
consignor_cashdown_weekend_90 int COMMENT '近3个月周末散单寄件量',
consignor_cashdown_weekend_180 int COMMENT '近6个月周末散单寄件量',
consignor_cashdown_weekend_365 int COMMENT '近1年周末散单寄件量',
consignor_cashdown_ratio_30 double COMMENT '近1个月周末散单寄件量占比',
consignor_cashdown_ratio_90 double COMMENT '近3个月周末散单寄件量占比',
consignor_cashdown_ratio_180 double COMMENT '近6个月周末散单寄件量占比',
consignor_cashdown_ratio_365 double COMMENT '近1年周末散单寄件量占比',
consignor_cashdown_air_30 int COMMENT '近1个月空运散单寄件量',
consignor_cashdown_land_30 int COMMENT '近1个月陆运散单寄件量',
consignor_cashdown_air_90 int COMMENT '近3个月空运散单寄件量',
consignor_cashdown_land_90 int COMMENT '近3个月陆运散单寄件量',
consignor_cashdown_air_180 int COMMENT '近6个月空运散单寄件量',
consignor_cashdown_land_180 int COMMENT '近6个月陆运散单寄件量',
consignor_cashdown_air_365 int COMMENT '近1年空运散单寄件量',
consignor_cashdown_land_365 int COMMENT '近1年陆运散单寄件量',
consignor_cashdown_air_ratio_30 double COMMENT '近1个月空运散单寄件量占比',
consignor_cashdown_land_ratio_30 double COMMENT '近1个月陆运散单寄件量占比',
consignor_last_monthly_acct_tm_180 string COMMENT '近6个月最近一次使用月结卡号的时间（寄件）',
consignor_last_monthly_acct_180 string COMMENT '近6个月最近一次使用的月结卡号（寄件）',
consignee_cnt_30 int COMMENT '近1个月收件量',
consignee_cnt_90 int COMMENT '近3个月收件量',
consignee_cnt_180 int COMMENT '近6个月收件量',
consignee_cnt_365 int COMMENT '近1年收件量',
consignee_cashdown_30 int COMMENT '近1个月散单寄件量',
consignee_cashdown_90 int COMMENT '近3个月散单寄件量',
consignee_cashdown_180 int COMMENT '近6个月散单寄件量',
consignee_cashdown_365 int COMMENT '近1年散单寄件量',
consignee_last_monthly_acct_tm_180 string COMMENT '近6个月最近一次使用月结卡号的时间（收件）',
consignee_last_monthly_acct_180 string COMMENT '近6个月最近一次使用的月结卡号（收件）',
consignor_insured_180 string COMMENT '近6个月寄件保价的运单量',
consignor_insured_365  string COMMENT '近1年寄件保价的运单量',
consignee_consignor_180_ratio double COMMENT '近6个月寄收比',
consignee_consignor_365_ratio double COMMENT '近1年寄收比',
last_consigned_tm_days int COMMENT '最近一次寄件距今天数',
first_consigned_tm_days int COMMENT '首次寄件距今天数',
consigned_sd_ratio double COMMENT '累计散单寄件占比',
consignee_sd_ratio double COMMENT '累计散单收件占比',
total_consignor_consigned_cnt int COMMENT '总收寄件量',
avg_rmb double COMMENT '寄件平均费用',
self_send_ratio double COMMENT '网点自寄比例',
self_pickup_ratio double COMMENT '网点自取比例'
)
comment '大宽表'
PARTITIONED BY (
`inc_day` string COMMENT '分区日期')
STORED AS ORC 
TBLPROPERTIES ('orc.compression'='SNAPPY');


-- 
insert overwrite table dm_gis_oms.dwm_sy_order_bw partition(inc_day='20220501') 
select 
t1.tel,
t1.name,
consignor_name_top3,
consignee_name_top3,
city,
citycode,
province,
date_sign,
czdz,
gsdz,
consignor_comp_name,
freight_monthly_acct_code,
last_consigned_tm,
last_consigned_city,
first_consigned_tm,
consigned_cnt,
consigned_jf_cnt,
consigned_df_cnt,
consigned_dsff_cnt,
consigned_sd_cnt,
self_send_cnt,
self_pickup_cnt,
consignee_cnt,
consignee_sd_cnt,
consignor_tm_cntmax ,
consignor_tm_zs_cnt ,
consignor_tm_zw_cnt,
consignor_tm_ws_cnt,
total_rmb,
total_jf_rmb,
total_df_rmb,
total_sff_rmb,
limit_type_code_top3,
directed_trace_top3,
consignee_mobile_top3,
consignor_mobile_top3,
t0.consignee_mobile,
consignor_cnt,
avg_sff_rmb ,
consignor_prod_code_top3 ,
consignee_prod_code_top3 ,
mdd_top3 ,
consignor_addr_top3 ,
consignee_addr_top3 ,
consignor_cons_top3 ,
consignee_cons_top3 ,
consignor_cnt_30,
consignor_cnt_90 ,
consignor_cnt_180 ,
consignor_cnt_365 ,
consignor_cnt_30_weekend ,
consignor_cnt_90_weekend ,
consignor_cnt_180_weekend,
consignor_cnt_365_weekend ,
consignor_30_weekend_ratio ,
consignor_90_weekend_ratio ,
consignor_180_weekend_ratio ,
consignor_365_weekend_ratio ,
consignor_air_30 ,
consignor_land_30,
consignor_air_90 ,
consignor_land_90 ,
consignor_air_180 ,
consignor_land_180 ,
consignor_air_365 ,
consignor_land_365 ,
consignor_30_air_ratio ,
consignor_30_land_ratio ,
consignor_cashdown_30 ,
consignor_cashdown_90 ,
consignor_cashdown_180 ,
consignor_cashdown_365 ,
consignor_cashdown_weekend_30 ,
consignor_cashdown_weekend_90 ,
consignor_cashdown_weekend_180 ,
consignor_cashdown_weekend_365,
consignor_cashdown_ratio_30,
consignor_cashdown_ratio_90 ,
consignor_cashdown_ratio_180,
consignor_cashdown_ratio_365 ,
consignor_cashdown_air_30 ,
consignor_cashdown_land_30,
consignor_cashdown_air_90 ,
consignor_cashdown_land_90 ,
consignor_cashdown_air_180 ,
consignor_cashdown_land_180,
consignor_cashdown_air_365,
consignor_cashdown_land_365 ,
consignor_cashdown_air_ratio_30 ,
consignor_cashdown_land_ratio_30,
t1.last_monthly_acct_tm_180 as consignor_last_monthly_acct_tm_180,
t1.last_monthly_acct_180 as consignor_last_monthly_acct_180,
consignee_cnt_30,
consignee_cnt_90 ,
consignee_cnt_180,
consignee_cnt_365,
consignee_cashdown_30 ,
consignee_cashdown_90 ,
consignee_cashdown_180,
consignee_cashdown_365,
t2.last_monthly_acct_tm_180  as consignee_last_monthly_acct_tm_180,
t2.last_monthly_acct_180 as consignee_last_monthly_acct_180,
consignor_insured_180,
consignor_insured_365,
cast(consignor_cnt_180/consignee_cnt_180 as decimal(20,4)) as consignee_consignor_180_ratio,
cast(consignor_cnt_365/consignee_cnt_365 as decimal(20,4)) as consignee_consignor_365_ratio ,
datediff(last_consigned_tm,'2022-05-01 00:00:00') as last_consigned_tm_days,
datediff(first_consigned_tm,'2022-05-01 00:00:00') as first_consigned_tm_days ,
cast(consigned_sd_cnt/consigned_cnt as decimal(20,4)) as consigned_sd_ratio,
cast(consignee_sd_cnt/consignee_cnt as decimal(20,4)) as consignee_sd_ratio ,
consigned_cnt+consignee_cnt as total_consignor_consigned_cnt ,
cast(total_rmb/consigned_cnt as decimal(20,4)) as avg_rmb ,
cast(self_send_cnt/consigned_cnt as decimal(20,4)) as self_send_ratio ,
cast(self_pickup_cnt/consigned_cnt as decimal(20,4)) as self_pickup_ratio 
from dm_gis_oms.dws_sy_order_bw1 as t0 
left join  dm_gis_oms.dwm_consignor_send_May  as t1 
on t0.tel=t1.consignor_mobile 
left join  dm_gis_oms.dwm_consignor_receive_May  as t2 
on t0.tel=t2.consignee_mobile 
;

