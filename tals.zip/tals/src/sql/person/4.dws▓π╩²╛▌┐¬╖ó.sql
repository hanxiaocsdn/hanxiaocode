-- dws层
-- 电话、姓名
电话
姓名
select tel,name 
from dm_gis_oms.ods_tals_tel_base

--
寄件常用名Top3
收件常用名Top3

select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignor_cont_name, ':', ''),cast(consignor_name_cnt as string)))
from dm_gis_oms.dwm_sy_consignor_name_tmp group by consignor_mobile
;

select consignee_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignee_cont_name, ':', ''),cast(consignee_name_cnt as string)))
from dm_gis_oms.dwm_sy_consignee_name_tmp group by consignee_mobile
;


--
性别
年龄
年龄段
出生年月
婚姻状况
最高教育程度
籍贯


--
家乡
用户足迹
常住城市
常住城市所在省市
常住城市最后一次收寄的日期
居住地址
工作地址
公司
所在行业

select tel,city,citycode,province,date_sign,czdz,gsdz from dm_gis_oms.dwm_tel_czcs_tmp1
;

select consignor_mobile,consignor_comp_name,freight_monthly_acct_code from dm_gis_oms.dwm_sy_company_halfyear_tmp
;


-- 近一年内情况
近1个月寄件量
近3个月寄件量
近6个月寄件量
近1年寄件量
近1个月收件量
近3个月收件量
近6个月收件量
近1年收件量
近6个月寄收比
近1年寄收比
近3个月周末寄件量
近3个月周末寄件量占比
近6个月周末寄件量
近6个月周末寄件量占比
近1年周末寄件量
近1年周末寄件量占比
近1个月空运寄件量
近1个月陆运寄件量
近3个月空运寄件量
近3个月陆运寄件量
近6个月空运寄件量
近6个月陆运寄件量
近1年空运寄件量
近1年陆运寄件量
近1个月空运寄件量占比
近1个月陆运寄件量占比
近1个月散单寄件量
近3个月散单寄件量
近6个月散单寄件量
近1年散单寄件量
近1个月散单收件量
近3个月散单收件量
近6个月散单收件量
近1年散单收件量
近6个月散单寄收比
近1年散单寄收比
近3个月周末散单寄件量
近3个月周末散单寄件量占比
近6个月周末散单寄件量
近6个月周末散单寄件量占比
近1年周末散单寄件量
近1年周末散单寄件量占比
近1个月空运散单寄件量
近1个月陆运散单寄件量
近3个月空运散单寄件量
近3个月陆运散单寄件量
近6个月空运散单寄件量
近6个月陆运散单寄件量
近1年空运散单寄件量
近1年陆运散单寄件量
近1个月空运散单寄件量占比
近1个月陆运散单寄件量占比
近6个月最近一次使用的月结卡号
近6个月最近一次使用月结卡号的时间
近6个月寄件保价的运单量
近1年寄件保价的运单量


----dm_gis_oms.dwm_consignor_send_May
`consignor_mobile` string COMMENT '寄件手机',
`consignor_cnt_30` int COMMENT '近1个月寄件量',
`consignor_cnt_90` int COMMENT '近3个月寄件量',
`consignor_cnt_180` int COMMENT '近6个月寄件量',
`consignor_cnt_365` int COMMENT '近1年寄件量',
`consignor_cnt_30_weekend` int COMMENT '近1个月周末寄件量',
`consignor_cnt_90_weekend` int COMMENT '近3个月周末寄件量',
`consignor_cnt_180_weekend` int COMMENT '近6个月周末寄件量',
`consignor_cnt_365_weekend` int COMMENT '近1年周末寄件量',
`consignor_30_weekend_ratio` double COMMENT '近1个月周末寄件量占比',
`consignor_90_weekend_ratio` double COMMENT '近3个月周末寄件量占比',
`consignor_180_weekend_ratio` double COMMENT '近6个月周末寄件量占比',
`consignor_365_weekend_ratio` double COMMENT '近1年周末寄件量占比',
`consignor_air_30` int COMMENT '近1个月空运寄件量',
`consignor_land_30` int COMMENT '近1个月陆运寄件量',
`consignor_air_90` int COMMENT '近3个月空运寄件量',
`consignor_land_90` int COMMENT '近3个月陆运寄件量',
`consignor_air_180` int COMMENT '近6个月空运寄件量',
`consignor_land_180` int COMMENT '近6个月陆运寄件量',
`consignor_air_365` int COMMENT '近1年空运寄件量',
`consignor_land_365` int COMMENT '近1年陆运寄件量',
`consignor_30_air_ratio` double COMMENT '近1个月空运寄件量占比',
`consignor_30_land_ratio` double COMMENT '近1个月陆运寄件量占比',
`consignor_cashdown_30` int COMMENT '近1个月散单寄件量',
`consignor_cashdown_90` int COMMENT '近3个月散单寄件量',
`consignor_cashdown_180` int COMMENT '近6个月散单寄件量',
`consignor_cashdown_365` int COMMENT '近1年散单寄件量',
`consignor_cashdown_weekend_30` int COMMENT '近1个月周末散单寄件量',
`consignor_cashdown_weekend_90` int COMMENT '近3个月周末散单寄件量',
`consignor_cashdown_weekend_180` int COMMENT '近6个月周末散单寄件量',
`consignor_cashdown_weekend_365` int COMMENT '近1年周末散单寄件量',
`consignor_cashdown_ratio_30` double COMMENT '近1个月周末散单寄件量占比',
`consignor_cashdown_ratio_90` double COMMENT '近3个月周末散单寄件量占比',
`consignor_cashdown_ratio_180` double COMMENT '近6个月周末散单寄件量占比',
`consignor_cashdown_ratio_365` double COMMENT '近1年周末散单寄件量占比',
`consignor_cashdown_air_30` int COMMENT '近1个月空运散单寄件量',
`consignor_cashdown_land_30` int COMMENT '近1个月陆运散单寄件量',
`consignor_cashdown_air_90` int COMMENT '近3个月空运散单寄件量',
`consignor_cashdown_land_90` int COMMENT '近3个月陆运散单寄件量',
`consignor_cashdown_air_180` int COMMENT '近6个月空运散单寄件量',
`consignor_cashdown_land_180` int COMMENT '近6个月陆运散单寄件量',
`consignor_cashdown_air_365` int COMMENT '近1年空运散单寄件量',
`consignor_cashdown_land_365` int COMMENT '近1年陆运散单寄件量',
`consignor_cashdown_air_ratio_30` double COMMENT '近1个月空运散单寄件量占比',
`consignor_cashdown_land_ratio_30` double COMMENT '近1个月陆运散单寄件量占比',
`last_monthly_acct_tm_180` string COMMENT '近6个月最近一次使用月结卡号的时间（寄件）',
`last_monthly_acct_180` string COMMENT '近6个月最近一次使用的月结卡号（寄件）',
`consignor_insured_180` string COMMENT '近6个月寄件保价的运单量',
`consignor_insured_365` string COMMENT '近1年寄件保价的运单量'


---- dm_gis_oms.dwm_consignor_receive_May
`consignee_mobile` string COMMENT '收件手机',
`consignee_cnt_30` int COMMENT '近1个月收件量',
`consignee_cnt_90` int COMMENT '近3个月收件量',
`consignee_cnt_180` int COMMENT '近6个月收件量',
`consignee_cnt_365` int COMMENT '近1年收件量',
`consignee_cashdown_30` int COMMENT '近1个月散单寄件量',
`consignee_cashdown_90` int COMMENT '近3个月散单寄件量',
`consignee_cashdown_180` int COMMENT '近6个月散单寄件量',
`consignee_cashdown_365` int COMMENT '近1年散单寄件量',
`last_monthly_acct_tm_180` string COMMENT '近6个月最近一次使用月结卡号的时间（收件）',
`last_monthly_acct_180` string COMMENT '近6个月最近一次使用的月结卡号（收件）')



--
最近一次寄件日期
最近一次寄件城市
最近一次寄件距今天数
最近一次寄件距今天数分层
首次寄件日期
首次寄件距今天数

select consignor_mobile,last_consigned_tm,last_consigned_city  from dm_gis_oms.dwm_sy_last_consignor_tmp 

select consignor_mobile,first_consigned_tm  from dm_gis_oms.dwm_sy_first_consignor_tmp

--
累计寄件次数
累计寄件寄付票数
累计寄件到付票数
累计寄件第三方付票数
累计散单寄件次数
累计散单寄件占比
累计收件次数
累计散单收件次数
累计散单收件占比

网点自寄票数
网点自寄比例
网点自取票数
网点自取比例

总收寄件量

select consignor_mobile,consigned_cnt,consigned_jf_cnt,consigned_df_cnt,consigned_dsff_cnt,consigned_sd_cnt,self_send_cnt,self_pickup_cnt 
from dm_gis_oms.dwm_sy_total_consignor_tmp
;

select consignee_mobile,consignee_cnt,consignee_sd_cnt from dm_gis_oms.dwm_sy_total_consignee_tmp
;

--
常用寄件时间段
寄件时效类型Top3
早上寄件量
下午寄件量
晚上寄件量
寄件总费用
寄件平均费用
寄件寄付费用总计
寄件到付费用总计
寄件第三方付费用总计
寄件城市流向列表
常用寄件城市流向Top3
寄件联系人(收件方)列表
常用寄件联系人(收件方)Top3
收件联系人(寄件方)列表
收用寄件联系人(寄件方)Top3

select consignor_mobile,consignor_tm_cntmax,consignor_tm_zs_cnt,consignor_tm_zw_cnt,consignor_tm_ws_cnt,total_rmb,total_jf_rmb,total_df_rmb,total_sff_rmb 
from dm_gis_oms.dwm_sy_total_consignor_tm_rmb_tmp
;  


select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(limit_type_code, ':', ''),cast(limit_type_cnt as string)))
from dm_gis_oms.dwm_sy_consignor_limit_type_tmp  group by consignor_mobile 
;

select consignor_mobile,collect_list(concat_ws(':',concat_ws('->',src_dist_code,dest_dist_code),cast(consignor_city_cnt as string))) 
from dm_gis_oms.dwm_sy_consignor_directed_trace_tmp group by consignor_mobile
;

select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignee_mobile, ':', ''),cast(contact_cnt as string))) 
from dm_gis_oms.dwm_sy_consignor_consignee_tmp group by consignor_mobile
;

select consignee_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignor_mobile, ':', ''),cast(contact_cnt as string))) 
from dm_gis_oms.dwm_sy_consignee_consignor_tmp group by consignee_mobile
;


--  
散单互寄列表
散单互寄频次最高的号码
散单互寄频次最高的姓名
散单互寄频次最高对应件量
散单互寄频次最高对应票均运费

select consignor_mobile,consignee_mobile,consignor_cnt,avg_sff_rmb
from dm_gis_oms.dwm_sy_sd_each_tmp  


-- 
常用寄件增值服务Top3
常用收件增值服务Top3
寄件地址列表(地址聚合去重)
收件地址列表(地址聚合去重)
常用寄件目的地Top3
常用寄件地址Top3
常用收件地址Top3
常寄托寄物
常收托寄物
收寄偏好用户分层

select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(prod_code, ':', ''),cast(prod_code_cnt as string))) 
from dm_gis_oms.dwm_sy_consignor_service_tmp group by consignor_mobile
;

select consignee_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(prod_code, ':', ''),cast(prod_code_cnt as string))) 
from dm_gis_oms.dwm_sy_consignee_service_tmp group by consignee_mobile
;

select consignor_mobile,collect_list(concat_ws(':',REGEXP_REPLACE(consignee_addr, ':', ''),cast(consignee_addr_cnt as string))) 
from dm_gis_oms.dwm_sy_consignor_mdd_tmp group by consignor_mobile
;

select consignor_mobile,,collect_list(concat_ws(':',REGEXP_REPLACE(consignor_addr, ':', ''),cast(consignor_addr_cnt as string))) 
from dm_gis_oms.dwm_sy_consignor_addr_tmp group by consignor_mobile
;

select consignee_mobile,,collect_list(concat_ws(':',REGEXP_REPLACE(consignee_addr, ':', ''),cast(consignee_addr_cnt as string))) 
from dm_gis_oms.dwm_sy_consignee_addr_tmp group by consignee_mobile
;

select consignor_mobile, collect_list(concat_ws(':',REGEXP_REPLACE(cons, ':', ''),cast(cons_cnt as string))) 
from dm_gis_oms.dwm_sy_consignor_cons_tmp group by consignor_mobile
;

select consignee_mobile, collect_list(concat_ws(':',REGEXP_REPLACE(cons, ':', ''),cast(cons_cnt as string))) 
from dm_gis_oms.dwm_sy_consignee_cons_tmp group by consignee_mobile
;