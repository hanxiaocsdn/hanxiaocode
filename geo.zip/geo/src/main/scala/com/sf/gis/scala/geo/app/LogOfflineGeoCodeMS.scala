package com.sf.scala.geo.app

import java.sql.Connection
import java.text.SimpleDateFormat
import java.util.Date

import com.alibaba.fastjson.JSON
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, DbUtil, HttpClientUtil}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * 郭振未
 *
 * geo日志解析, 此报表目前已屏蔽,需要后面看看谁需要在释放，但是数据暂时不动 20231115 01374443
 * 已迁移至新集群
 * 韩笑
 */
object LogOfflineGeoCodeMS {
  @transient lazy val logger: Logger = Logger.getLogger(LogOfflineGeoCodeMS.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //hive 表
  var freqTable = "dm_gis.bee_logs_gis_geo_collect_ak_addr_freq"
  ///mysql 表
  val timeOutTableName = "TIMEOUT_STAT"
  val geoReqTableName = "GEO_REQ"
  val geoReqDetailTableName = "GEO_REQ_DETAIL"
  val akTableName = "AK"
  val geoRespTableName = "GEO_RESP"
  val geoRespAkTableName = "GEO_RESP_AK"
  val geoRespCityTableName = "GEO_RESP_CITY"

  case class LogGeo(ymdhm: String, ak: String, aktype: String, city: String, cityiden: String, addrtype: String, src: String, precision: String, status: Int, statusiden: String, err: String, msg: String, tm: Long, addressReq: String, addressRsp: String, remote_ip: String, showserver: String, match_level: String, result_type: String, xcoord: String, ycoord: String, regcode: String, adname: String, adcode: String, cc: String, city_code_req: String, src_rsp: String)

  case class LogAK(aktype: String, ak: String, req: Int, rspmax: Int, rspavg: Int, rspmin: Int, t99max: Int, t99avg: Int, t99min: Int, tmltg200: Int, tmltg500: Int, tmltg1000: Int, tmltg2000: Int, tmltg3000: Int, tmov3000: Int)

  case class LogAkType(aktype: String, ak: String, cnt: Long, cityign: Long, cityidy: Long, cityidn: Long, addrerr: Long, addrnor: Long, addrnet: Long)

  case class LogAddrAk(addrtype: String, ak: String, aktype: String, status: Int, detail: String, cityiden: String)

  case class LogAddrDetail(addrtype: String, ak: String, aktype: String, status: Int, detail: String, cnt: Int)

  case class LogAddrType(addrtype: String, cnt: Int)

  case class LogCity(addrtype: String, city: String, cnt: Int, yy: Int, sf: Int, sw: Int, gf: Int, bd: Int, gd: Int, tc: Int, gu: Int, w_bd: Int, w_gd: Int, w_tc: Int, gj: Int, wt: Int, dj: Int, err: Int)

  case class LogFreq(ak: String, aktype: String, city: String, cityiden: String, addrtype: String, src: String, precision: String, status: String, statusiden: String, err: String, msg: String, tm: String, address_req: String, address_rsp: String, remote_ip: String, showserver: String, match_level: String, result_type: String, xcoord: String, ycoord: String, regcode: String, adname: String, adcode: String)

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    var akFlag = false
    if(args.length>1){
      akFlag=args(1).toBoolean
    }
    if(!akFlag){
      start(incDay, "EXTN")
    }else{
      startAK(incDay,"EXTN")
    }

  }

  def queryAkStateBc(sparkSession: SparkSession, rptType: String) = {
    try {
      val akresult = HttpClientUtil.getJsonByGet(s"http://akjetty-gis-ass-oms.dcn.k8s.sf-express.com/pub/getAkInfoByService?serviceCode=${if (rptType == "BD") "GIS-RSS-GEO-BDP" else "GEO"}", 3)
      val aklist = akresult.getJSONObject("result").getJSONArray("list")
      val akstate = (0 to aklist.size() - 1).map(i => {
        val akobj = aklist.getJSONObject(i)
        val now = new Date().getTime
        val flag = akobj.getIntValue("state") == 1 && akobj.getLongValue("startTime") <= now && now <= akobj.getLongValue("endTime")
        (akobj.getString("akValue"), flag)
      }).toMap
      sparkSession.sparkContext.broadcast(akstate)
    } catch {
      case e: Exception => {
        null: Broadcast[Map[String, Boolean]]
      }
    }
  }

  def queryGeoLog(sparkSession: SparkSession, incDay: String,
                  bAkStateBc: Broadcast[Map[String, Boolean]]) = {
    //      var hdfsPath = s"hdfs://stream/user/mario/warehouse/ods_kafka_gis/bee_logs_gis_geo_collect/$dayid"
    val sql = s"select log from dm_gis.bee_logs_gis_geo_collect where inc_day='$incDay' " +
      s" and log like '%url_e%' and log not like '%geo/split%' and log not like '%rpmp/api%' "
    logger.error(sql)
    var logParsed = sparkSession.sql(sql).rdd.repartition(3200)
      .map(d => {
        parseLogGeo(d.getString(0), bAkStateBc.value)
      })
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(s"【$incDay 日志总数量：】" + logParsed.count())
    logParsed
  }

  def showErrSample(logParsed: RDD[(LogGeo, String)]) = {
    val logErr = logParsed.filter(_._2 != null).map(_._2)
    val errcnt = logErr.count()
    if (errcnt > 0) {
      val showSize = 10
      logger.error(s"【日志解析失败数量：】" + errcnt + "，其中前" + showSize)
      logger.error("-------------------------------------------------------------------------------")
      logErr.filter(d =>
        !d.contains("unclosed jsonArray") &&
          !d.contains("unclosed string :") &&
          !d.contains("String index out of range: -1") &&
          !d.contains("expect ':' at") &&
          !d.contains("syntax error") &&
          !d.contains("unterminated json string") &&
          !d.contains("unclosed.str") &&
          !d.contains("error parse")).take(showSize).foreach(obj => {
        logger.error(obj)
      })
      logger.error("-------------------------------------------------------------------------------")
    }
  }

  def startAK(incDay: String, rptType: String) = {
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_geo?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"
    val uid = "gis_oms_geo"
    val pwd = "gis_oms_geo@123@"
    val connection = DbUtil.getConnection(driver, url, uid, pwd)
    DbUtil.execute(connection
      , s"delete from $akTableName where AK='_' or ak='undefined'")
    logger.error("delete from ak1")
    DbUtil.execute(connection, s"delete from $akTableName where length(AK)>32")
    logger.error("delete from ak2")
    DbUtil.execute(connection,
      s"""insert into `$akTableName`(`ID`,`AK`,`PROJECT`)
         |select md5(concat(ak,'GEO')),ak,'GEO' from
         |(select distinct AK as ak from $geoReqTableName
         |union all select distinct AK as ak from $geoReqDetailTableName
         |union all select distinct AK as ak from $geoRespTableName
         |union all select distinct AK as ak from $geoRespAkTableName)a
         |ON DUPLICATE KEY UPDATE AK=a.ak,project='GEO'
                         """.stripMargin)
    logger.error("delete from invalid ak")
    val delAkSql4 = s"delete from `$akTableName` where length(AK)<4"
    logger.error(delAkSql4)
    DbUtil.execute(connection, delAkSql4)
    val delAkSql32 = s"DELETE FROM `$akTableName` WHERE LENGTH(AK)>32"
    DbUtil.execute(connection, delAkSql32)
    connection.close()
    logger.error("ak操作完毕")
  }

  def start(incDay: String, rptType: String): Unit = {

    val sparkSession = Spark.getSparkSession(appName)
    logger.error(s"【$rptType】即将开始地理编码微服务日志指标离线统计：" + incDay)
    val bAkStateBc = queryAkStateBc(sparkSession, rptType)

    val logParsed = queryGeoLog(sparkSession, incDay, bAkStateBc)
    showErrSample(logParsed)

    var logEnd = logParsed.map(_._1).filter(d => d != null && d.ymdhm.indexOf(incDay) == 0).persist(StorageLevel.MEMORY_AND_DISK_SER) ////.repartition(Util.defaultPartitionSize*2)
    val logcnt = logEnd.count()
    logParsed.unpersist()
    logger.error(s"【$incDay】最终返回数：" + logcnt + "，分区数：" + logEnd.getNumPartitions + "，耗时：")
    Spark.clearPersistWithoutId(sparkSession, logEnd.id)

    //计算mapa地址缺失频次统计
    mapaAddrMissFreq(sparkSession, incDay, logEnd)
    Spark.clearPersistWithoutId(sparkSession, logEnd.id)

    processMySqlKpi(sparkSession, logEnd, incDay, logcnt, rptType, bAkStateBc)
    Spark.clearPersistWithoutId(sparkSession, logEnd.id)
    val todayDayid = DateUtil.getDate(0)
    val week = DateUtil.getWeek(todayDayid) //今天的星期
    if ("6".equals(week)) {
      ///生产实际已经屏蔽掉很长时间了，估计暂时没人使用
      processFreq(sparkSession, logEnd, incDay)
    }
    logEnd.unpersist()

  }

  def saveFreq(spark: SparkSession, freqRdd: RDD[LogGeo], dayid: String, tag: String) = {
    import spark.implicits._
    if (!freqRdd.isEmpty()) {
      val tmpViewName = "tmp" + System.currentTimeMillis()
      freqRdd.map(d => {
        LogFreq(d.ak, d.aktype, d.city, d.cityiden, d.addrtype, d.src,
          d.precision, d.status.toString, d.statusiden, d.err, d.msg,
          d.tm.toString, d.addressReq, d.addressRsp, d.remote_ip,
          d.showserver, d.match_level, d.result_type, d.xcoord,
          d.ycoord, d.regcode, d.adname, d.adcode)
      }).toDF().createOrReplaceTempView(tmpViewName)
      val sql = s"insert overwrite table ${freqTable} partition(inc_day='$dayid',tag='$tag') " +
        s" select * from $tmpViewName"
      logger.error(sql)
      spark.sql(sql)
    }
  }

  def parseLogGeo(d: String, b_akstate: Map[String, Boolean]) = {

    val aklistMissPatch = "0228bf6c478c4f60bfad74588ef9559e,1405423f241c4971b292df1c3228d1f1,3847482cb9844067b0e41767e1acf01f,4a881b947aa54c6a944a900351c1afa6,504ce6892fd14f1da1973d34ccaf020d,56a8a571223940a28a272cb8a5480bc2,6eeefc8dcc7c42869bd4f84a746f428d,8bb09e5e110845f39a000391668e3e80,932c3c4cf4c54afd9b240b70980481ac,9bf4fc8ebdcd4a1eaa51b46484a4f645,9dc8e8ddcbd947698263c21a4061bd29,c2efaba7d5504cc9936541e9890108ae,e2c8d6311bc7459195f7a5cc4fc4a68c,e6553bd0ce51b08f1aa8cc6cc42de767,e9106d80834e483189c3439938bac5d2,f5fa161fec22487787f48a2d0d29c25c,f85e6a69f9554101be41346752ab2cdf,123bd6f3a60547aca7dfb1ca817d2654,6e491612e0a54fa2a4f1940dfb2a3319,a244e29144b9467ab9f6584a6912913e,e6b53e609c2440c8b20b14552bab4e09,0228bf6c478c4f60bfad74588ef9559e,f5fa161fec22487787f48a2d0d29c25c,e6b53e609c2440c8b20b14552bab4e09,e2c8d6311bc7459195f7a5cc4fc4a68c,6eeefc8dcc7c42869bd4f84a746f428d,4a881b947aa54c6a944a900351c1afa6,3847482cb9844067b0e41767e1acf01f,123bd6f3a60547aca7dfb1ca817d2654,a4fbd3a08ecc4f9e41bc9b06421ef3b5,504ce6892fd14f1da1973d34ccaf020d,1405423f241c4971b292df1c3228d1f1,9bf4fc8ebdcd4a1eaa51b46484a4f645,a244e29144b9467ab9f6584a6912913e,9dc8e8ddcbd947698263c21a4061bd29,6e491612e0a54fa2a4f1940dfb2a3319,af5938935293445084a6b7ba8cd23a4c,e6553bd0ce51b08f1aa8cc6cc42de767,d0a3085716f44228a3e08ef519b194bb,94c9162319557b6e9102f0aeb4b3bf5d".split(",").distinct //小哥行为，补缺失，地址可达
    //val jsonStart = "#{\""
    val jsonStart = s""""message":""""

    if (d.indexOf(jsonStart) != -1) {
      //val str = d.substring(d.indexOf(jsonStart)+1)
      val str = JSON.parseObject(d).getString("message")
      val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
      val sdf2: SimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm")
      try {
        val json = JSON.parseObject(JSON.parse(str).toString)
        val ymdhm = sdf2.format(sdf.parse(json.getString("dateTime")).getTime)
        //ak,aktype,city,cityiden,addrtype,src,precision,status,err,msg

        val datatype = json.getString("type")
        val sn = json.getString("sn")
        val urlObj = json.getJSONObject("url")
        var ak = fixnull(urlObj.getString("ak"))
        val url = urlObj.getString("url")
        if (ak == "未知")
          ak = fixnull(getPara(url, "ak="))
        if (ak.indexOf("?") != -1)
          ak = ak.substring(0, ak.indexOf("?"))
        if (ak.length != 32)
          ak == "未知"

        if (ak != "未知" && ak != "-" && ak != "ALL" && ak != "all" && (ak.length != 32 || ak.indexOf("\r") != -1 || ak.indexOf("\n") != -1 || ak.indexOf("ISystem") != -1)) ak = "未知"

        val address_req = if (urlObj.getString("address") != null) fixAddress(fixnull(urlObj.getString("address"))) else fixAddress(try {
          java.net.URLDecoder.decode(getPara(url, "address="), "utf8")
        } catch {
          case e: Exception => "解析错误：" + getPara(url, "address=")
        })

        //val address_req= Util.fixAddress(try{java.net.URLDecoder.decode(addr,"utf8")} catch{case e:Exception=>"解析错误："+addr})
        //val aktype = if(aklistMissPatch.contains(ak)) "补缺失ak" else if(aklistNormal.contains(ak)) "普通ak" else "非法ak"
        val aktype = if (aklistMissPatch.contains(ak)) "补缺失ak" else if (b_akstate == null) "未知" else if (b_akstate.getOrElse(ak, false)) "普通ak" else "非法ak"
        val tm = if (json.getString("time") == null) 0l else json.getIntValue("time").toLong
        val data = json.getJSONObject("data")
        val status = data.getIntValue("status")
        var resultObj = data.getJSONObject("result")
        if (resultObj == null) resultObj = JSON.parseObject("{}")

        val address_rsp = fixAddress(fixnull(resultObj.getString("src_address")))
        val precision = fixnull(resultObj.getString("precision"))
        val src = if (status == 1) "返回错误码" else if (resultObj.getString("src") == "empty") "未返回" else if (precision != "2") "返回低精" else fixnull(resultObj.getString("src"))
        val src_rsp = fixnull(resultObj.getString("src"))
        val cc = fixnull(resultObj.getString("cc"))
        val statusiden = if (status == 1) "返回错误码" else if (resultObj.getString("src") == "empty") "未返回" else if (status == 0) "返回正常" else "其他:" + status

        val tp = fixnull(resultObj.getString("type"))
        val adcode = fixnull(resultObj.getString("adcode"))
        val adname = resultObj.getJSONArray("adname")

        val city = if (src == "未返回") "未返回" else if (status != 0) "返回错误码" else if (adname == null || adname.size() < 2) "未知" else fixnull(adname.getString(1))
        val prov = if (adname == null || adname.size() < 1) "未知" else fixnull(adname.getString(0))
        //todo cityiden
        val err = if (status == 1) resultObj.getString("err") else "无"
        val cityiden = if (city == "未返回") "不可识别" else if (status != 0 && err == "1005") "城市冲突" else "可识别"
        //todo addrtype
        val addrtype = if (status == 1 && err == "-107" || city == "未返回") "错误地址" else if (src == "wd") "网点地址" else "普通地址"

        val msg = if (status == 1) resultObj.getString("msg") else "无"

        //增加扩展属性
        val remote_ip = fixnull(urlObj.getString("remoteIp"))
        val showserver = fixnull(urlObj.getString("showserver"))
        val match_level = fixnull(resultObj.getString("match_level"))
        val result_type = fixnull(resultObj.getString("type"))
        val xcoord = fixnull(resultObj.getString("xcoord"))
        val ycoord = fixnull(resultObj.getString("ycoord"))
        val regcode = fixnull(resultObj.getString("regcode"))
        val adnames = if (resultObj.getJSONArray("adname") == null) fixnull(null) else fixnull(resultObj.getJSONArray("adname").toArray().mkString(","))

        val city_code_req = if (urlObj != null) fixnull(urlObj.getString("city")) else "未知"

        (new LogGeo(ymdhm, ak, aktype, city, cityiden, addrtype, src, precision, status, statusiden, err, msg, tm, address_req, address_rsp, remote_ip, showserver, match_level, result_type, xcoord, ycoord, regcode, adnames, adcode, cc, city_code_req, src_rsp), null)
      } catch {
        case e: Exception => {
          //System.err.println(str)
          //System.err.println(e.getMessage)
          //System.err.println(e.getCause)
          //e.printStackTrace()
          (null, d + "\n" + e.getMessage + "\n" + e.getCause)
        }
      }
    }
    else {
      (null, d)
    }
  }

  def fixAddress(str: String) = {
    if (str == null) null else {
      str.replaceAll(s"""[\\\\,\t\r\n'\" (null)(NULL)]""", "")
    }
  }

  def getPara(src: String, pre: String, sub: String = null, extSub: String = "") = {
    if (src.contains(pre)) {
      if (sub == null) {
        val finalSub = ",&" + extSub
        var ak = src.substring(src.indexOf(pre) + pre.length)
        //        ak = if(ak.contains(",")) ak.substring(0,ak.indexOf(",")) else ak
        //        ak = if(ak.contains("&")) ak.substring(0,ak.indexOf("&")) else ak
        finalSub.toCharArray.foreach(c => {
          ak = if (ak.contains(c.toString)) ak.substring(0, ak.indexOf(c.toString)) else ak
        })
        ak
      } else {
        var ak = src.substring(src.indexOf(pre) + pre.length)
        ak = if (ak.contains(sub)) ak.substring(0, ak.indexOf(sub)) else ak
        ak
      }
    } else {
      ""
    }
  }

  def mapaAddrMissFreq(sparkSession: SparkSession, dayid: String, logEnd: RDD[LogGeo]) = {
    val aklist = s"""d7b4f4c307f0482e81c805913bde3138,14e9ee810854c40f5ae9414f2a62c8cc,9549fc4188fe072d6f1c6c589c1331cd,6bc1cce77927449e803cffb1d84b97ff,bba16126b28f4d54b922cd45ea739efb,bfda9d6f849e4cbe92e6d8ba41dd1b8d,cfd8c287490d432f84eecfd8e95608ad,20ac2e1414a04405abbfcef551c679c8,00b826ea8629489eb61e14183c4dd723,8035b0cad5ef4b9e8e8363defcf455c9,fe044a34e92c42f5a2996275ff0074d7,289eb7959c8c4909af668dea415b21b4,2af744941b2941d9bb1d82c34a3e1707,20b9fd80ca35362c39ad755f69167873,a985576e4d0748ea902316059d1e93cf,0be023281e6549769a38b2b678b1e38d,c17256f349d7fc46d0e2772df2fdb34f,44d847d9626923049082788be3998d40,8f4a7f792206c6c5c4330ad22315bd99,101e3dd6d394069f32eadc424c3b8c33,918facc212c515ef03b5eab323ef5365,11c9e2e48b6d4abea89fe706c11ea2b6,5e3e7424227d7bf3d0e45be107709f9b,1761b108c1da441d956b5d2ef1221ef5,ff80abd5ec0b427c91087baa9417c09f,2115b841e6b84cf0a34ad2558d4c933e,49b3b2dc19af365802fe6db21b73af60,e88e3db501e144ccab2d7588f7d178ab,9cfdf8e458e640248ff23f301b7dea8c,7f97bed330767c772d496b2f95c7d2e7,ce625a40ce7b9c5a8c5b9dc7de397143""".split(",")

    import sparkSession.implicits._

    val df = logEnd.filter(d => {
      aklist.contains(d.ak) && ((d.status == 0 && d.precision == "0") || (d.status == 1 && d.addressReq != null && d.addressReq != ""))
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    df.createOrReplaceTempView("mapa_miss")

    val missLogCnt = sparkSession.sql("select count(1) from mapa_miss").take(1)(0).getLong(0)
    logger.error(s"【$dayid - 地理编码对外日志 MAPA地址缺失记录数】$missLogCnt")

    val mapa_miss_freq_sql = s"""select city_code_req,addressReq,count(1) as freq from mapa_miss group by city_code_req,addressReq"""


    val mapa_miss_desc_sql = s"""select * from (select row_number() over(partition by city_code_req,addressReq order by ymdhm desc) rn,t.* from mapa_miss t) q where rn=1"""

    val joinSql =
      s"""select a.city_code_req,a.addressReq,a.freq,b.status,b.src_rsp,b.match_level,b.result_type,b.precision,b.xcoord,b.ycoord,b.adcode,b.regcode,b.adname,b.cc,b.err,substr(b.msg,1,100) from
         |(${mapa_miss_freq_sql})a
         | left join
         | (${mapa_miss_desc_sql}) b
         | on a.city_code_req=b.city_code_req and a.addressReq=b.addressReq""".stripMargin

    val sql = s"""insert overwrite table dm_gis.bee_logs_gis_geo_collect_mapa_addr_miss_freq partition(inc_day='$dayid') $joinSql"""
    logger.error(sql)
    sparkSession.sql(sql)

    val missCnt = sparkSession.sql(s"select count(1) from dm_gis.bee_logs_gis_geo_collect_mapa_addr_miss_freq where inc_day=$dayid").take(1)(0).getLong(0)
    logger.error(s"【$dayid - 地理编码对外日志 MAPA地址缺失记录聚合去重完毕，记录数】$missCnt")
    df.unpersist()
  }

  def processFreq(spark: SparkSession, logEnd: RDD[LogGeo], dayid: String) = {
    //开始计算各类ak、地址每日频次
    //无法识别出城市，错误地址，网点地址，返回自有源的数据，返回百度高德腾讯源的数据，返回低精数据，返回错误码数据
    val selfSrc = "yy,sf,sw,gf".split(",")
    val exitSrc = "bd,gd,tc,gu".split(",")

    logger.error("【开始计算地址频次】")
    saveFreq(spark, logEnd.filter(_.cityiden != "可识别"), dayid, "city_err") //无法识别城市
    saveFreq(spark, logEnd.filter(_.addrtype == "错误地址"), dayid, "addr_err") //"错误地址"
    saveFreq(spark, logEnd.filter(_.addrtype == "网点地址"), dayid, "addr_wd") //"网点地址"
    saveFreq(spark, logEnd.filter(d => selfSrc.contains(d.src)), dayid, "src_self") //"返回自有源"
    saveFreq(spark, logEnd.filter(d => exitSrc.contains(d.src)), dayid, "src_ext") //"返回外部源"
    saveFreq(spark, logEnd.filter(_.src == "返回低精"), dayid, "ret_dj") //"返回低精"
    saveFreq(spark, logEnd.filter(_.src == "返回错误码"), dayid, "ret_err") //"返回错误码"
    logger.error("结束计算地址频次")
    logger.error("【processFreq】")
  }


  def parsemm(l: ((String, String), Iterable[LogGeo])) = {
    val aktype = l._1._1
    val ak = l._1._2
    val r = l._2.toIndexedSeq
    val tm = r.map(_.tm).filter(_ > 0)
    val t99 = tm.sortBy(d => d)
    val req = r.size
    val rspmax = if (tm.size > 0) tm.max.toInt else 0
    val rspmin = if (tm.size > 0) tm.min.toInt else 0
    val rspavg = if (tm.size > 0) Math.ceil(tm.sum.toDouble / tm.size.toDouble).toInt else 0
    val t99max = if (t99.size > 0) t99(Math.floor(t99.size * 0.99).toInt) else 0
    val t99min = if (t99.size > 0) t99.min else 0
    val t99avg = if (t99.size > 0) Math.ceil(t99.sum.toDouble / t99.size.toDouble).toInt else 0
    val tmltg200 = if (tm.size > 0) tm.filter(_ <= 200).size else 0
    val tmltg500 = if (tm.size > 0) tm.filter(d => d > 200 && d <= 500).size else 0
    val tmltg1000 = if (tm.size > 0) tm.filter(d => d > 500 && d <= 1000).size else 0
    val tmltg2000 = if (tm.size > 0) tm.filter(d => d > 1000 && d <= 2000).size else 0
    val tmltg3000 = if (tm.size > 0) tm.filter(d => d > 2000 && d <= 3000).size else 0
    val tmov3000 = if (tm.size > 0) tm.filter(d => d > 3000).size else 0
    LogAK(aktype, ak, req, rspmax, rspavg, rspmin, t99max.toInt, t99avg, t99min.toInt, tmltg200, tmltg500, tmltg1000, tmltg2000, tmltg3000, tmov3000)
  }

  def process(d: ((String, String), Iterable[LogGeo]),
              rpttype: String, dayid: String) = {
    val ymdhm = d._1._1
    val ak = if (d._1._2 == "未知") "-" else d._1._2
    val r = d._2.toIndexedSeq.map(_.tm).filter(_ > 0).sortBy(d => d)
    val cnt = r.size
    val avgrsp = if (r.size > 0) Math.ceil(r.sum / r.size).toInt else 0
    val t99rsp = if (r.size > 0) r(Math.floor(r.size * 0.99).toInt) else 0
    Array(MD5Util.getMD5(ymdhm + rpttype + ak), rpttype, ymdhm, ak,
      cnt.toString, avgrsp.toString, t99rsp.toString, dayid)
  }

  def parsetm(d: (String, Iterable[LogGeo])) = {
    val ak = d._1
    val row = d._2
    (ak, row.map(_.tm).filter(_ > 0))
  }

  //增加对中间结果中图商源（gd/bd/tc/gu）的调用量汇总统计
  def processGeoRespUpdateMysql(spark: SparkSession, dayid: String, rpttype: String,
                                connection: Connection) = {
    val tb = "bee_logs_gis_geo_collect"
    val dlr = "$"
    var sql =
      s"""select
         |  get_json_object(
         |    substr(t.log, locate('#{"', t.log)+1),
         |    '${dlr}.url.ak'
         |  ) as ak,
         |  substr(get_json_object(
         |    substr(t.log, locate('#{"', t.log)+1),
         |    '${dlr}.type'
         |  ),1,2) as tp,
         |  1 as cnt
         |from
         |  dm_gis.${tb} t
         |where
         |  t.inc_day = ${dayid} and t.log not REGEXP '(url_s)|(url_e)'
          """.stripMargin
    var tsdf = spark.sql(sql).groupBy("ak").pivot("tp").sum("cnt").where("ak is not null").persist(StorageLevel.MEMORY_AND_DISK_SER)
    //tsdf.show(Integer.MAX_VALUE)

    "bd,gd,tc,gu".split(",").foreach(d => {
      if (!tsdf.columns.contains(d))
        tsdf = tsdf.selectExpr("*", s"0 as $d")
    })

    tsdf.selectExpr("ak", "bd", "gd", "tc", "gu").na.fill(0l).rdd.map(d => {
      val ak = d.getString(0)
      val bd = d.get(1).toString.toLong
      val gd = d.get(2).toString.toLong
      val tc = d.get(3).toString.toLong
      val gu = d.get(4).toString.toLong
      val sql = s"update $geoRespTableName set REQ_BD=$bd,REQ_GD=$gd,REQ_TC=$tc,REQ_GG=$gu where STAT_DATE='$dayid' AND ak='$ak' and SVC_TYPE='$rpttype'"
      sql
    }).collect().foreach(d => {
      DbUtil.execute(connection, d, null)
    })
    tsdf.unpersist()
  }

  def processTimeOutMysql(connection: Connection, middle: RDD[((String, String), Iterable[LogAK])],
                          incDay: String, rptType: String) = {
    val timeOver = middle.map(d => {
      var aktype = d._1._1
      if ("普通ak".equals(aktype)) {
        aktype = "GNRL"
      } else if ("补缺失ak".equals(aktype)) {
        aktype = "RPLN"
      } else if ("非法ak".equals(aktype)) {
        aktype = "ILLGL"
      }
      val ak = if (d._1._2 == "未知") "-" else d._1._2
      val row = d._2
      val req = row.map(_.req).sum
      val tmltg200 = row.map(_.tmltg200).sum
      val tmltg500 = row.map(_.tmltg500).sum
      val tmltg1000 = row.map(_.tmltg1000).sum
      val tmltg2000 = row.map(_.tmltg2000).sum
      val tmltg3000 = row.map(_.tmltg3000).sum
      val tmov3000 = row.map(_.tmov3000).sum
      val id = MD5Util.getMD5(incDay + rptType + "GEO" + aktype + ak)
      Array(id, rptType, incDay, "GEO", aktype, ak, req.toString, tmltg200.toString, tmltg500.toString, tmltg1000.toString, tmltg2000.toString,
        tmltg3000.toString, tmov3000.toString)
    }).filter(obj => {
      val akTypeList = Array("ALL", "GNRL", "RPLN", "ILLGL")
      akTypeList.contains(obj(4))
    }).collect()
    logger.error("TIMEOUT_STAT数量:" + timeOver.size)
    timeOver.take(2).foreach(obj => {
      logger.error(obj.mkString(","))
    })

    val deleteTimeOutGeoSql = s"delete from $timeOutTableName where SVC_TYPE='$rptType' and STAT_DATE='$incDay' AND SERVICE='GEO'"
    logger.error("删除超时geo已有数据:" + deleteTimeOutGeoSql)
    DbUtil.execute(connection, deleteTimeOutGeoSql)
    val insertTimeOutGeoSql = s"insert into  $timeOutTableName (ID,SVC_TYPE,STAT_DATE,SERVICE,AK_TYPE,AK,REQ,TIMEOUT_200,TIMEOUT_500," +
      s"TIMEOUT_1000,TIMEOUT_2000,TIMEOUT_3000,TIMEOUT_INFINITE) values(?,?,?,?,?,?,?,?,?,?,?,?,?) "
    logger.error("写入超时geo数据:" + insertTimeOutGeoSql)
    DbUtil.executeBatchSql(connection, insertTimeOutGeoSql, timeOver)
  }

  def processGeoReqMysql(connection: Connection, middle: RDD[((String, String), Iterable[LogAK])],
                         incDay: String, rptType: String) = {
    var geoReq = middle.filter(d => d._1._1 == "ALL").map(d => { //filter(d=>{d._1._1!="ALL" && d._1._2!="ALL" || d._1._1=="ALL" && d._1._2=="ALL"})
      val ak = if (d._1._2 == "未知") "-" else d._1._2
      val l = d._2.toIndexedSeq
      val avg = l.map(_.rspavg).filter(_ > 0)
      val t99 = l.map(_.t99avg).filter(_ > 0)
      val req = l.map(_.req).filter(_ > 0)

      val reqmax = if (req.size > 0) req.max else 0
      val reqmin = if (req.size > 0) req.min else 0
      val reqavg = if (req.size > 0) Math.ceil(req.sum / req.size).toInt else 0
      val rspmax = if (l.size > 0) l.map(_.rspmax).max else 0
      val rspmin = if (l.size > 0) l.map(_.rspmin).min else 0
      val rspavg = if (avg.size > 0) Math.ceil(avg.sum / avg.size).toInt else 0
      val t99max = if (l.size > 0) l.map(_.t99max).max else 0
      val t99min = if (l.size > 0) l.map(_.t99min).min else 0
      val t99avg = if (t99.size > 0) Math.ceil(t99.sum / t99.size).toInt else 0
      Array(MD5Util.getMD5(incDay + rptType + ak), rptType, incDay, ak, reqmax.toString, reqavg.toString,
        reqmin.toString, rspmax.toString, rspavg.toString, rspmin.toString, t99max.toString,
        t99avg.toString, t99min.toString)
    }).filter(obj => {
      val akArrray = Array("未知", "-", "ALL", "all")
      val ak = obj(3)
      if (!akArrray.contains(ak) &&
        (ak.length != 32 || ak.contains("\\r") ||
          ak.contains("\\n") || ak.contains("ISystem"))) {
        false
      } else if ("_".equals(ak) || "undefined".equals(ak) || ak.contains("%")) {
        false
      } else {
        true
      }
    }).collect()

    logger.error("GEO_REQ数量:" + geoReq.size)
    middle.unpersist()

    val deleteGeoReqSql = s"delete from $geoReqTableName where STAT_DATE='$incDay' and SVC_TYPE='$rptType'  "
    logger.error("删除geo req已有数据:" + deleteGeoReqSql)
    DbUtil.execute(connection, deleteGeoReqSql)
    val insertGeoReqSql = s"insert into $geoReqTableName (ID,SVC_TYPE,STAT_DATE,AK,REQ_MAX,REQ_AVG,REQ_MIN,RESP_TIME_MAX," +
      s"RESP_TIME_AVG,RESP_TIME_MIN,RESP_TIME_99MAX,RESP_TIME_99AVG," +
      s"RESP_TIME_99MIN) values(?,?,?,?,?,?,?,?,?,?,?,?,?) "
    logger.error("写入geo请求数据:" + insertGeoReqSql)
    DbUtil.executeBatchSql(connection, insertGeoReqSql, geoReq)
  }

  def processGeoReqUpdateMysql(connection: Connection, logmm: RDD[(String, Iterable[LogGeo])], incDay: String,
                               rptType: String) = {
    //    val tableName = "GEO_REQ"
    //优化上面倾斜问题
    val georeq = logmm.map(d => {
      val u = d._2.map(r => ((r.ak, r.tm), 1))
      val v = d._2.map(r => (("ALL", r.tm), 1))
      u.toList.union(v.toList)
    }).flatMap(d => d).reduceByKey(_ + _).groupBy(d => d._1._1).map(d => {
      val ak = d._1
      val cnt = d._2.map(_._2).sum //tm 总频次
      val avg = if (cnt > 0) Math.floor(d._2.map(t => {
        t._1._2 * t._2
      }).sum.toDouble / cnt.toDouble).toInt else 0
      val tm99maxidx = Math.floor(cnt * 0.99)
      var tm99max = 0l
      var tmc = 0
      d._2.map(t => (t._1._2, t._2)).toIndexedSeq.sortBy(t => t._1).foreach(t => {
        tmc += t._2
        if (tm99max == 0 && tmc >= tm99maxidx)
          tm99max = t._1
      })
      val id = MD5Util.getMD5(incDay + rptType + ak)
      s"update $geoReqTableName set RESP_TIME_AVG = $avg,RESP_TIME_99MAX = $tm99max where ID='$id'"
    }).collect().foreach(d => DbUtil.execute(connection, d))

    val sql = s"""INSERT IGNORE INTO `${akTableName}`(`ID`,`AK`,`PROJECT`) select distinct md5(concat(`AK`,'GEO')),`AK`,'GEO' from $geoReqTableName where $geoReqTableName.STAT_DATE='$incDay'"""
    logger.error(sql)
    logger.error("connection:" + connection)
    DbUtil.execute(connection, sql)
    DbUtil.execute(connection, s"""delete from ${akTableName} WHERE AK not in('未知','-','ALL','all') and (LENGTH(AK)<>32 or AK LIKE '%\r%' or AK LIKE '%\n%' or AK LIKE '%ISystem%')""")
  }

  def processGeoReqDetailMysql(connection: Connection, logRdd: RDD[LogGeo], incDay: String, rptType: String) = {

    val u = logRdd.groupBy(d => (d.ymdhm, d.ak)).repartition(200).map(d => process(d, rptType, incDay))
    val v = logRdd.groupBy(d => (d.ymdhm, "ALL")).repartition(200).map(d => process(d, rptType, incDay))

    val geoReqDetail = u.union(v).filter(obj => {
      val akArrray = Array("未知", "-", "ALL", "all")
      val ak = obj(3)
      if (!akArrray.contains(ak) &&
        (ak.length != 32 || ak.contains("\\r") ||
          ak.contains("\\n") || ak.contains("ISystem"))) {
        false
      } else if ("_".equals(ak) || "undefined".equals(ak) || ak.contains("%")) {
        false
      } else {
        true
      }
    }).collect()
    logger.error("GEO_REQ_DETAIL数量:" + geoReqDetail.size)

    val geoReqDetailSql = s"delete from $geoReqDetailTableName where STAT_DATE='$incDay' and SVC_TYPE='$rptType'  "
    logger.error("删除geoReqDetail已有数据:" + geoReqDetailSql)
    DbUtil.execute(connection, geoReqDetailSql)
    val insertGeoReqDetailSql = s"insert into  $geoReqDetailTableName (ID,SVC_TYPE,STAT_DATETIME,AK,GEO_REQ_COUNT," +
      s"GEO_RESP_TIME,GEO_RESP_TIME_99,STAT_DATE) values(?,?,?,?,?,?,?,?) "
    logger.error("写入geo req明细数据:" + insertGeoReqDetailSql)
    DbUtil.executeBatchSql(connection, insertGeoReqDetailSql, geoReqDetail)
  }

  def processGeoRespMysql(connection: Connection,
                          logmm: RDD[(String, Iterable[LogGeo])],
                          incDay: String, rptType: String,
                          logCnt: Long) = {

    val geoResp = logmm.map(d => {
      val ymdhm = d._1
      d._2.groupBy(d => (d.aktype, d.ak)).map(l => {
        val aktype = l._1._1
        val ak = l._1._2
        if (aktype == "非法ak") {
          val cnt = l._2.filter(d => d.ak == ak).toIndexedSeq.size
          LogAkType(aktype, ak, cnt, 0, 0, 0, 0, 0, 0)
        } else {
          val r = l._2.filter(d => d.aktype != "非法ak").toIndexedSeq
          val cnt = r.size
          val cityign = r.filter(_.cityiden == "城市冲突").size
          val cityidy = r.filter(_.cityiden == "可识别").size
          val cityidn = r.filter(_.cityiden == "不可识别").size
          val c = r.filter(_.cityiden == "可识别")
          val addrerr = c.filter(_.addrtype == "错误地址").size
          val addrnor = c.filter(_.addrtype == "普通地址").size
          val addrnet = c.filter(_.addrtype == "网点地址").size
          LogAkType(aktype, ak, cnt, cityign, cityidy, cityidn, addrerr, addrnor, addrnet)
        }
      })
    }).flatMap(d => d).groupBy(d => (d.aktype, d.ak)).repartition(200).map(d => {
      var aktype = d._1._1
      if (aktype == "普通ak")
        aktype = "GNRL"
      else if (aktype == "补缺失ak")
        aktype = "RPLN"
      else if (aktype == "非法ak")
        aktype = "ILLGL"
      val ak = if (d._1._2 == "未知") "-" else d._1._2
      val r = d._2.toIndexedSeq
      val cnt = r.map(_.cnt).sum
      val cityign = r.map(_.cityign).sum
      val cityidy = r.map(_.cityidy).sum
      val cityidn = r.map(_.cityidn).sum
      val addrerr = r.map(_.addrerr).sum
      val addrnor = r.map(_.addrnor).sum
      val addrnet = r.map(_.addrnet).sum
      Array(MD5Util.getMD5(incDay + rptType + ak), rptType, incDay, aktype, ak,
        logCnt.toString, cnt.toString, "0", "0", "0", "0",
        cityign.toString, cityidy.toString, cityidn.toString, addrerr.toString,
        addrnor.toString, addrnet.toString)
    }).filter(obj => {
      val akArrray = Array("未知", "-", "ALL", "all")
      val ak = obj(4)
      if (!akArrray.contains(ak) &&
        (ak.length != 32 || ak.contains("\\r") ||
          ak.contains("\\n") || ak.contains("ISystem"))) {
        false
      } else if ("_".equals(ak) || "undefined".equals(ak) || ak.contains("%")) {
        false
      } else {
        true
      }
    }).collect()
    logger.error("GEO_RESP数量:" + geoResp.size)

    val geoRespSql = s"delete from $geoRespTableName where STAT_DATE='$incDay' and SVC_TYPE='$rptType'  "
    logger.error("删除geo resp已有数据:" + geoRespSql)
    DbUtil.execute(connection, geoRespSql)
    val insertGeoRespSql = s"insert into  $geoRespTableName (ID,SVC_TYPE,STAT_DATE," +
      s"AK_TYPE,AK,REQ_TOTAL,REQ_COUNT,REQ_GD,REQ_BD,REQ_TC,REQ_GG," +
      s"CITY_CONFLICT,CITY_REC,CITY_UNREC,ADDR_ERR,ADDR_ORDN,ADDR_ZNO) " +
      s"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
    logger.error("写入geo明细数据:" + insertGeoRespSql)
    DbUtil.executeBatchSql(connection, insertGeoRespSql, geoResp)

  }

  def processGeoRespAkMysql(spark: SparkSession, connection: Connection, logmm: RDD[(String, Iterable[LogGeo])], incDay: String,
                            rptType: String) = {
    import spark.implicits._

    val logdetail = logmm.map(d => {
      val ymdhm = d._1
      d._2.map(d => {
        val detail = if (d.status == 1) d.err else if (d.src == "返回低精") "dj" else if (d.src == "未返回") "-" else d.src
        LogAddrAk(d.addrtype, d.ak, d.aktype, d.status, detail, d.cityiden)
      }).groupBy(d => (d.addrtype, d.ak, d.aktype, d.status, d.detail)).map(l => {
        var addrtype = l._1._1
        val ak = l._1._2
        val aktype = l._1._3
        val status = l._1._4
        val detail = l._1._5
        val r = l._2.filter(d => d.aktype != "非法ak" && d.cityiden == "可识别").toIndexedSeq
        val cnt = r.size
        ((addrtype, ak, aktype, status, detail), cnt)
      })
    }).flatMap(d => d).reduceByKey(_ + _).map(d => {
      val k = d._1
      val ak = if (k._2 == "未知") "-" else k._2
      val aktype = if (k._3 == "未知") "-" else k._3
      LogAddrDetail(k._1, ak, aktype, k._4, k._5, d._2)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logdetail.toDF().createOrReplaceTempView("addrtypedetail")

    logmm.map(d => {
      val ymdhm = d._1
      d._2.groupBy(d => d.addrtype).map(d => {
        (d._1, d._2.size)
      })
    }).flatMap(d => d).reduceByKey(_ + _).map(d => {
      LogAddrType(d._1, d._2)
    }).toDF().createOrReplaceTempView("addrtype")

    val cityidycnt = logdetail.map(_.cnt).sum.toInt

    val sql =
      s"""select md5(concat('$incDay','$rptType',a.addrtype,a.ak,a.status,a.detail)),'$rptType','$incDay',case when a.addrtype='普通地址' then 'ORDN' when a.addrtype='网点地址' then 'ZNO' when a.addrtype='错误地址' then 'ERRAD' else a.addrtype end AS addrtype,case when a.aktype='普通ak' then 'GNRL' when a.aktype='非法ak' then 'ILLGL' when a.aktype='补缺失ak' then 'RPLN' else a.aktype end as aktype,a.ak,case when a.status='未知' then '-' else a.status end,a.detail,$cityidycnt,b.cnt,a.cnt from addrtypedetail a left join addrtype b on a.addrtype = b.addrtype""".stripMargin
    logger.error(sql)
    val geoRespAk = spark.sql(sql).map(obj => {
      var aktype = obj.getString(4)
      if ("普通ak".equals(aktype)) {
        aktype = "GNRL"
      } else if ("补缺失ak".equals(aktype)) {
        aktype = "RPLN"
      } else if ("非法ak".equals(aktype)) {
        aktype = "ILLGL"
      }
      var addrType = obj.getString(3)
      if ("ERRADDR".equals(addrType)) {
        addrType = "ERRAD"
      }
      Array(obj.getString(0), obj.getString(1), obj.getString(2), addrType,
        aktype, obj.getString(5), obj.getString(6), obj.getString(7),
        obj.getInt(8).toString, obj.getInt(9).toString, obj.getInt(10).toString)
    }).filter(obj => {
      val akArrray = Array("未知", "-", "ALL", "all")
      val ak = obj(5)
      if (ak == null || "_".equals(ak) || "".equals(ak)) {
        false
      } else if (!akArrray.contains(ak) && (ak.length != 32 || ak.contains("\\r") || ak.contains("\\n") || ak.contains("ISystem"))) {
        false
      } else if ("_".equals(ak) || "undefined".equals(ak) || ak.contains("%")) {
        false
      } else {
        true
      }
    }).filter(obj => {
      val akTypeList = Array("GNRL", "RPLN", "ILLGL")
      akTypeList.contains(obj(4))
    }).collect()
    logdetail.unpersist()
    logger.error("GEO_RESP_AK数量:" + geoRespAk.size)

    val geoRespAkSql = s"delete from $geoRespAkTableName where STAT_DATE='$incDay' and SVC_TYPE='$rptType'  "
    logger.error("删除geo resp ak 已有数据:" + geoRespAkSql)
    DbUtil.execute(connection, geoRespAkSql)
    val insertGeoRespAkSql = s"insert into  $geoRespAkTableName (ID,SVC_TYPE,STAT_DATE," +
      s"ADDR_TYPE,AK_TYPE,AK,RESP_STATUS,STATUS_DETAIL,REQ_TOTAL,REQ_AT,REQ_COUNT) " +
      s"values(?,?,?,?,?,?,?,?,?,?,?) "
    logger.error("写入geo resp ak数据:" + insertGeoRespAkSql)
    DbUtil.executeBatchSql(connection, insertGeoRespAkSql, geoRespAk)
  }

  def processGeoRespCityMysql(spark: SparkSession, connection: Connection, logmm: RDD[(String, Iterable[LogGeo])],
                              incDay: String, rptType: String) = {
    import spark.implicits._
    spark.read.csv("/dolphinscheduler/gisbdp/resources/dic_region.csv").toDF("region", "province", "city_name", "city_code", "adcode").createOrReplaceTempView("dic_region")

    val logcity = logmm.map(d => {
      val ymdhm = d._1
      d._2.groupBy(d => (d.addrtype, if (d.city == null || d.city == "未知" || d.city == "未返回" || d.city == "返回错误码" || """[a-zA-Z]+""".r.findAllIn(d.city).toIndexedSeq.size > 0) "-" else d.city)).map(d => {
        var addrtype = d._1._1
        var city = d._1._2
        val r = d._2.filter(d => d.aktype == "普通ak" && d.cityiden == "可识别").toIndexedSeq
        val cnt = r.size
        val bd = r.filter(_.src == "bd").size
        val gd = r.filter(_.src == "gd").size
        val gf = r.filter(_.src == "gf").size
        val gu = r.filter(_.src == "gu").size
        val sf = r.filter(_.src == "sf").size
        val sw = r.filter(_.src == "sw").size
        val tc = r.filter(_.src == "tc").size
        val yy = r.filter(_.src == "yy").size
        val w_bd = r.filter(_.src == "w-bd").size
        val w_gd = r.filter(_.src == "w-gd").size
        val w_tc = r.filter(_.src == "w-tc").size
        val gj = r.filter(_.precision == "2").size
        val wt = r.filter(_.src.indexOf("w-") == 0).size
        val dj = r.filter(_.src == "返回低精").size
        val err = r.filter(_.src == "返回错误码").size
        val invalidArray = Array("", "_", "未知", "未返回", "返回错误码")

        if (invalidArray.contains(city)) {
          city = "-"
        }
        if ("普通地址".equals(addrtype)) {
          addrtype = "ORDN"
        } else if ("网点地址".equals(addrtype)) {
          addrtype = "ZNO"
        } else if ("错误地址".equals(addrtype)) {
          addrtype = "ERRAD"
        } else if ("ERRADDR".equals(addrtype)) {
          addrtype = "ERRAD"
        }
        LogCity(addrtype, city, cnt, yy, sf, sw, gf, bd, gd, tc, gu, w_bd, w_gd, w_tc, gj, wt, dj, err)
      })
    }).flatMap(d => d).groupBy(d => (d.addrtype, d.city)).repartition(200).map(d => {
      val addrtype = d._1._1
      val city = d._1._2
      val r = d._2.toIndexedSeq
      val cnt = r.map(_.cnt).sum
      val bd = r.map(_.bd).sum
      val gd = r.map(_.gd).sum
      val gf = r.map(_.gf).sum
      val gu = r.map(_.gu).sum
      val sf = r.map(_.sf).sum
      val sw = r.map(_.sw).sum
      val tc = r.map(_.tc).sum
      val yy = r.map(_.yy).sum
      val w_bd = r.map(_.w_bd).sum
      val w_gd = r.map(_.w_gd).sum
      val w_tc = r.map(_.w_tc).sum
      val gj = r.map(_.gj).sum
      val wt = r.map(_.wt).sum
      val dj = r.map(_.dj).sum
      val err = r.map(_.err).sum
      LogCity(addrtype, city, cnt, yy, sf, sw, gf, bd, gd, tc, gu, w_bd, w_gd, w_tc, gj, wt, dj, err)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logcity.toDF().createOrReplaceTempView("addrcity")

    spark.sql("select * from addrcity").show(100)

    val logcitycnt = logcity.map(_.cnt).sum.toInt
    val geoRespCitySql = s"""select md5(concat('$incDay','$rptType',a.addrtype,nvl(a.city,'-'),nvl(b.city_code,'-'))),'$rptType','$incDay',a.addrtype,nvl(b.province,'-'),nvl(b.region,'-'),nvl(b.city_name,'-'),nvl(city_code,'-'),$logcitycnt,a.cnt,a.gj,a.wt,a.dj,a.err from addrcity a left join dic_region b on a.city=b.city_name"""
    val geoRespCity = spark.sql(geoRespCitySql).map(obj => {
      var addrType = obj.getString(3)
      var province = obj.getString(4)
      var region = obj.getString(5)
      var city = obj.getString(6)
      var cityCode = obj.getString(7)
      val invalidArray = Array("", "_", "未知", "未返回", "返回错误码")

      if (invalidArray.contains(region)) {
        region = "-"
      }
      if (invalidArray.contains(province)) {
        province = "-"
      }

      if (invalidArray.contains(cityCode)) {
        cityCode = "-"
      }

      Array(obj.getString(0), obj.getString(1), obj.getString(2), addrType,
        province, region, city, cityCode,
        obj.getInt(8).toString, obj.getInt(9).toString, obj.getInt(10).toString, obj.getInt(11).toString,
        obj.getInt(12).toString, obj.getInt(13).toString)
    }).filter(obj => {
      val city = obj(6)
      val pattern = "[A-Za-z0-9]+".r
      val findResult = pattern findFirstIn city
      if (findResult.nonEmpty) {
        false
      } else {
        true
      }
    }).collect()
    logger.error("GEO_RESP_CITY数量:" + geoRespCity.size)
    geoRespCity.filter(obj => {
      obj(0).equals("2ec41ca3f6c20315638c8b237152165f")
    }).foreach(obj => {
      logger.error("2ec41ca3f6c20315638c8b237152165f:" + obj.mkString(","))
    })
    logcity.unpersist()

    val geoRespCityDelSql = s"delete from $geoRespCityTableName where STAT_DATE='$incDay' and SVC_TYPE='$rptType'  "
    logger.error("删除geo resp City 已有数据:" + geoRespCityDelSql)
    DbUtil.execute(connection, geoRespCityDelSql)
    val insertGeoRespCitySql = s"insert into  $geoRespCityTableName (ID,SVC_TYPE," +
      s"STAT_DATE,ADDR_TYPE,PROVINCE,REGION,CITY,CITY_CODE,REQ_TOTAL,REQ_AT," +
      s"RESP_GJ,RESP_WT,RESP_DJ,RESP_ERR) " +
      s"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
    logger.error("写入geo resp City数据:" + insertGeoRespCitySql)
    DbUtil.executeBatchSql(connection, insertGeoRespCitySql, geoRespCity)
    logger.error("写入geo resp City数据完毕")
  }

  def processMySqlKpi(spark: SparkSession, logSrc: RDD[LogGeo], incDay: String,
                      logCnt: Long, rptType: String, bAkStateBc: Broadcast[Map[String, Boolean]]): Unit = {
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_geo?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"
    val uid = "gis_oms_geo"
    val pwd = "gis_oms_geo@123@"
    val connection = DbUtil.getConnection(driver, url, uid, pwd)
    processGeoReqDetailMysql(connection, logSrc, incDay, rptType)

    val logmm = logSrc.groupBy(d => d.ymdhm).repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)
    if (logmm.count() == 0) {
      logger.error(s"【processMySqlKpi】$incDay 无日志，计算略")
      return
    }
    Spark.clearPersistWithoutId(spark, logmm.id)

    val middle = logmm.map(d => {
      val ymdhm = d._1
      val t = d._2.groupBy(d => (d.aktype, d.ak)).map(l => parsemm(l))
      val u = d._2.groupBy(d => (d.aktype, "ALL")).map(l => parsemm(l))
      val v = d._2.groupBy(d => ("ALL", d.ak)).map(l => parsemm(l))
      val w = d._2.groupBy(d => ("ALL", "ALL")).map(l => parsemm(l))
      t.toList.union(u.toList).union(v.toList).union(w.toList)
    }).flatMap(d => d).groupBy(d => (d.aktype, d.ak)).repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)
    processTimeOutMysql(connection, middle, incDay, rptType)
    processGeoReqMysql(connection, middle, incDay, rptType)
    processGeoReqUpdateMysql(connection, logmm, incDay, rptType)
    processGeoRespMysql(connection, logmm, incDay, rptType, logCnt)
    processGeoRespUpdateMysql(spark, incDay, rptType, connection)
    processGeoRespAkMysql(spark, connection, logmm, incDay, rptType)
    processGeoRespCityMysql(spark, connection, logmm, incDay, rptType)

    //以下直接放在driver上跑就行了
    //    DbUtil.execute(connection, s"delete from $akTableName where AK='_' or ak='undefined'")
    //    logger.error("delete from ak1" )
    //    DbUtil.execute(connection, s"delete from $akTableName where length(AK)>32")
    //    logger.error("delete from ak2" )
    //    DbUtil.execute(connection,
    //      s"""insert into `$akTableName`(`ID`,`AK`,`PROJECT`)
    //        |select md5(concat(ak,'GEO')),ak,'GEO' from
    //        |(select distinct AK as ak from $geoReqTableName
    //        |union all select distinct AK as ak from $geoReqDetailTableName
    //        |union all select distinct AK as ak from $geoRespTableName
    //        |union all select distinct AK as ak from $geoRespAkTableName)a
    //        |ON DUPLICATE KEY UPDATE AK=a.ak,project='GEO'
    //                     """.stripMargin)
    //    logger.error("delete from invalid ak")
    //    val delAkSql4 = s"delete from `$akTableName` where length(AK)<4"
    //    logger.error(delAkSql4)
    //    DbUtil.execute(connection, delAkSql4)
    //    val delAkSql32 = s"DELETE FROM `$akTableName` WHERE LENGTH(AK)>32"
    //    DbUtil.execute(connection, delAkSql32)
    connection.close()
    logmm.unpersist()
    logger.error("【processMySqlKpi】计算完毕")
  }


  def fixnull(ak: String) = {
    if (ak == null || ak.trim == "" || ak.trim.toLowerCase() == "null") "未知" else ak
  }
}
