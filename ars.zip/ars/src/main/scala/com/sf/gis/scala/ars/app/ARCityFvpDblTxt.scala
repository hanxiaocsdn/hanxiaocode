package com.sf.gis.scala.ars.app

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpClientUtil, HttpUtils}
import org.apache.log4j.Logger
import org.apache.spark.storage.StorageLevel;

/** *
 * 郭振未
 * * 地址可达服务压测代码,每天跑下灰度，然后有任务会每天去看看，目前改为月度，用于查看准确率
 * * 迁移新集群   146
 * * 韩笑，刘思远，段嫦慧
 */

object ARCityFvpDblTxt {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val incDay = "20210219"
    val runCnt = args(0).toInt
    start(incDay, runCnt)
  }

  def start(incDay: String, runCnt: Int): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    val queryOrginSql = s"select waybill_no,d_deliverycode,dist_code,consignee_addr from dm_gis.ars_server_pressure_test_table where inc_day='${incDay}'"
    logger.error(queryOrginSql)
    val rdd = sparkSession.sql(queryOrginSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    rdd.createOrReplaceTempView("bsp_order_src")
    val cnt = rdd.count()
    logger.error(s"【$incDay】工单总量：" + cnt)

    if (cnt == 0) {
      logger.error("无数据")
      System.exit(-1)
    } else {
      //MergeSmallFiles.parquetHiveTable("dm_gis","bsp_order_src")
      //输入：bsp_order_src表的所有字段，使用consignee_addr字段进行服务调用，结果保留bsp_order_src表中的所有字段，以及服务调用结果。另存一个新表
      /*
      * 	数据源：bsp订单地址和80目的地城市代码对比数据作为输入
    筛单服务url：http://gis-int.int.sfdc.com.cn:1080/ar/api&province=&city=&district=&address=四平市梨树县四棵树乡&extention=0&opt=tip0&ak=af5938935293445084a6b7ba8cd23a4c
    保留数据：source为'src-conflict', 'src_samecd', 'src_poiad', 'src_notsamecd_has_ad', 'has_ad', 'src_dumped','src_repeat_dumped', 'src_has_pc', 'has_T', 'src_norm', 'src_samead'的数据 或
  resultinfo.code=-10 or  resultinfo.code=-11 and not (source=src-tip and citycode is not null)
  建表保存
  保留字段：原始数据4个字段（工单号，bsp城市代码、80城市代码，地址），source、resultinfo.code、citycode、地址是否详细
      * */
      //执行上述汇总统计,初始化数据
      val tableNameAR = "bsp_order_src_ar"

      var limit = cnt //Math.floor(cnt/5).toInt
      if (runCnt != -1) {
        limit = runCnt
      }
      logger.error("limit:" + limit)
      val resultrdd = sparkSession.sql(s"select waybill_no,d_deliverycode,dist_code,consignee_addr from bsp_order_src  limit $limit")
        .rdd.repartition(30).map(d => {
        val waybill_no = d.getString(0)
        val d_deliverycode = d.getString(1)
        val dist_code = d.getString(2)
        val consignee_addr = d.getString(3)
        val date = new Date
        val hour = date.getHours
        if(hour>=7 && hour <22 ){
          logger.error("超出时间了")
          System.exit(-1)
        }
        //todo fix tip to 1
        val url = s"http://gis-int.int.sfdc.com.cn:1080/ar/api?province=&city=&district=&address=${URLEncoder.encode(consignee_addr, "utf8").replaceAll("\\+","%20")}&extention=0&opt=tip1&ak=af5938935293445084a6b7ba8cd23a4c" //af5938935293445084a6b7ba8cd23a4c //87e4924a24564525a0dbab3c86c04103
        val result = HttpClientUtil.getJsonByGetWithError(url, 3)
        if (result != null) {
          try {
            val json = result
            val source = json.getString("src")
            val code = json.getJSONObject("extention").getJSONObject("resultinfo").getIntValue("code")
            val citycode = json.getString("city_code")
            val detail_addr = json.getString("detail_addr")
            (Array(waybill_no, d_deliverycode, dist_code, consignee_addr, source, code.toString, citycode, detail_addr), null)
          } catch {
            case e: Exception => {
              logger.error(s"【REQ】：$url")
              logger.error(s"【RSP】：$result")
              (null, s"【REQ】：$url\n【RSP】：$result\n${e.getMessage}\n${e.getCause}\n【IP】:${HttpUtils.getAllIpAddress.toArray.mkString(",")}")
            }
          }
        } else {
          logger.error(s"【REQ】：$url")
          logger.error(s"【RSP】：$result")
          (null, s"【REQ】：$url\n【RSP】：$result\n【IP】:${HttpUtils.getAllIpAddress.toArray.mkString(",")}")
        }
      }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

      val resultrdd_count = resultrdd.count
      logger.error("==================================================================================")
      logger.error(s"纯文本调用数据源总量：${resultrdd_count}，其中服务调用失败数：${resultrdd.filter(_._2 != null).count}")
      resultrdd.filter(_._2 != null).map(_._2).take(100).foreach(logger.error)
      logger.error("==================================================================================")
      import sparkSession.implicits._
      resultrdd.filter(_._1 != null).keys.map(row => {
        val waybill_no = row(0)
        val d_deliverycode = row(1)
        val dist_code = row(2)
        val consignee_addr = row(3)
        val source = row(4)
        val code = row(5)
        val citycode = row(6)
        val detail_addr = row(7)
        (waybill_no, d_deliverycode, dist_code, consignee_addr, source, code, citycode, detail_addr)
      }).toDF("waybill_no,d_deliverycode,dist_code,consignee_addr,source,code,citycode,detail_addr".split(","): _*).createOrReplaceTempView(tableNameAR)
      val insertRetSql = s"insert overwrite table dm_gis.${tableNameAR} partition(inc_day='${incDay}') " +
        s" select * from ${tableNameAR} "
      logger.error(insertRetSql)
      sparkSession.sql(insertRetSql)
      val sourceList = "src-conflict,src_samecd,src_poiad,src_notsamecd_has_ad,has_ad,src_dumped,src_repeat_dumped,src_has_pc,has_T,src_norm,src_samead,src_samecd_has_ad,src_hk_conflict,src_only_PorC,src_ML,src_ML_redis,src_ML_model".toLowerCase.split(",").mkString("'", "','", "'")
      sparkSession.sql(s"select * from $tableNameAR where  (lower(source) in ($sourceList) or code='-10' or (code like '-11%' and not (source='src-tip' and citycode is not null and citycode<>'')))").createOrReplaceTempView("city_neq")

      //双重城市代码一致量
      val city_eq_cnt = sparkSession.sql(s"select count(1) from city_neq where  dist_code=citycode and citycode is not null and citycode<>''").collect()(0).getLong(0)
      //双重城市代码不一致量
      val city_neq_cnt = sparkSession.sql(s"select count(1) from city_neq where  dist_code<>citycode and dist_code is not null and dist_code<>'' and citycode is not null and citycode<>''").collect()(0).getLong(0)
      //双重筛单城市为空数量
      val city_null_cnt = sparkSession.sql(s"select count(1) from city_neq where  (citycode is null or citycode='')").collect()(0).getLong(0)
      //全部纯文本城市代码一致量
      val txt_city_eq_cnt = sparkSession.sql(s"select count(1) from $tableNameAR where   dist_code=citycode and citycode is not null and citycode<>''").collect()(0).getLong(0)
      //全部纯文本城市代码不一致量
      val txt_city_neq_cnt = sparkSession.sql(s"select count(1) from $tableNameAR where   dist_code<>citycode and dist_code is not null and dist_code<>'' and citycode is not null and citycode<>''").collect()(0).getLong(0)
      //全部纯文本城市代码为空量
      val txt_city_null_cnt = sparkSession.sql(s"select count(1) from $tableNameAR where   (citycode is null or citycode='')").collect()(0).getLong(0)
      //总输入数据量
      val input_cnt = resultrdd_count //Util.spark.sql(s"select count(1) from bsp_order_src where inc_day='$dayid'").collect()(0).getLong(0)
      //双重城市总量
      val city_dbl_cnt = city_eq_cnt + city_neq_cnt + city_null_cnt
      //双重城市识别准确率
      val city_dbl_ar = Math.round(city_eq_cnt.toDouble / (city_eq_cnt + city_neq_cnt).toDouble * 10000.0) / 100.0
      //双重城市识别率
      val city_dbl_ir = Math.round((city_eq_cnt + city_neq_cnt).toDouble / city_dbl_cnt.toDouble * 10000.0) / 100.0
      //双重城市占比
      val city_dbl_p = Math.round(city_dbl_cnt.toDouble / input_cnt.toDouble * 10000.0) / 100.0

      //new add
      //全部纯文本城市代码识别率
      val txt_city_ir = Math.round((txt_city_eq_cnt + txt_city_neq_cnt).toDouble / input_cnt.toDouble * 10000.0) / 100.0
      //全部纯文本城市代码准确率
      val txt_city_ar = Math.round(txt_city_eq_cnt.toDouble / (txt_city_eq_cnt + txt_city_neq_cnt).toDouble * 10000.0) / 100.0
      //双重城市文本规则一致量
      val srccol = s"""'src-conflict', 'src_samecd', 'src_poiad', 'src_notsamecd_has_ad', 'has_ad','src_dumped','src_repeat_dumped', 'src_has_pc', 'has_T', 'src_norm', 'src_samead','src_samecd_has_ad','src_hk_conflict', 'src_only_PorC'""".toLowerCase
      val city_txt_eq_cnt = sparkSession.sql(s"select count(1) from city_neq where  dist_code=citycode and citycode is not null and citycode<>'' and lower(source) in($srccol)").collect()(0).getLong(0)
      //双重城市文本规则不一致量
      val city_txt_neq_cnt = sparkSession.sql(s"select count(1) from city_neq where  dist_code<>citycode and dist_code is not null and dist_code<>'' and citycode is not null and citycode<>'' and lower(source) in($srccol)").collect()(0).getLong(0)
      //双重城市文本规则识别率
      val city_txt_ir = Math.round((city_txt_eq_cnt + city_txt_neq_cnt).toDouble / city_dbl_cnt.toDouble * 10000.0) / 100.0
      //双重城市文本规则准确率
      val city_txt_ar = Math.round(city_txt_eq_cnt.toDouble / (city_txt_eq_cnt + city_txt_neq_cnt).toDouble * 10000.0) / 100.0
      //双重城市机器学习一致量
      val srccolml = s"""'src_ML_redis','src_ML_model'""".toLowerCase
      val city_txtml_eq_cnt = sparkSession.sql(s"select count(1) from city_neq where  dist_code=citycode and citycode is not null and citycode<>'' and lower(source) in($srccolml)").collect()(0).getLong(0)
      //双重城市机器学习不一致量
      val city_txtml_neq_cnt = sparkSession.sql(s"select count(1) from city_neq where dist_code<>citycode and dist_code is not null and dist_code<>'' and citycode is not null and citycode<>'' and lower(source) in($srccolml)").collect()(0).getLong(0)
      //双重城市机器学习识别率
      val city_txtml_ir = Math.round((city_txtml_eq_cnt + city_txtml_neq_cnt).toDouble / city_dbl_cnt.toDouble * 10000.0) / 100.0
      //双重城市机器学习准确率
      val city_txtml_ar = Math.round(city_txtml_eq_cnt.toDouble / (city_txtml_eq_cnt + city_txtml_neq_cnt).toDouble * 10000.0) / 100.0
      //非双重城市代码识别率
      val txt_city_eq_ir = Math.round((txt_city_eq_cnt + txt_city_neq_cnt - city_eq_cnt - city_neq_cnt).toDouble / input_cnt.toDouble * 10000.0) / 100.0
      //非双重城市代码准确率
      val txt_city_eq_ar = Math.round((txt_city_eq_cnt - city_eq_cnt).toDouble / (txt_city_eq_cnt + txt_city_neq_cnt - city_eq_cnt - city_neq_cnt).toDouble * 10000.0) / 100.0


      logger.error("===========================================================================")
      logger.error(
        s"""
           |【双重城市筛单统计结果】
           |【双重城市代码一致量】  $city_eq_cnt
           |【双重城市代码不一致量】  $city_neq_cnt
           |【双重筛单城市为空数量】  $city_null_cnt
           |【总输入数据量】  $input_cnt
           |【双重城市总量】  $city_dbl_cnt
           |【双重城市识别准确率】  $city_dbl_ar%
           |【双重城市识别率】  $city_dbl_ir%
           |【双重城市占比】  $city_dbl_p%
           |【全部纯文本城市代码一致量】  $txt_city_eq_cnt
           |【全部纯文本城市代码不一致量】  $txt_city_neq_cnt
           |【全部纯文本城市代码为空量】  $txt_city_null_cnt
           |【全部纯文本城市代码识别率】  $txt_city_ir%
           |【全部纯文本城市代码准确率】  $txt_city_ar%
           |【双重城市文本规则一致量】  $city_txt_eq_cnt
           |【双重城市文本规则不一致量】  $city_txt_neq_cnt
           |【双重城市文本规则识别率】  $city_txt_ir%
           |【双重城市文本规则准确率】  $city_txt_ar%
           |【双重城市机器学习一致量】  $city_txtml_eq_cnt
           |【双重城市机器学习不一致量】  $city_txtml_neq_cnt
           |【双重城市机器学习识别率】  $city_txtml_ir%
           |【双重城市机器学习准确率】  $city_txtml_ar%
           |【非双重城市代码识别率】  $txt_city_eq_ir%
           |【非双重城市代码准确率】  $txt_city_eq_ar%
           |""".stripMargin)
      logger.error("===========================================================================")
      val day = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime())
      sparkSession.sql(s"insert overwrite table dm_gis.bsp_order_src_ar_stat partition(inc_day='${day}') values($city_eq_cnt,$city_neq_cnt,$city_null_cnt,$input_cnt,$city_dbl_cnt,$city_dbl_ar,$city_dbl_ir,$city_dbl_p,$txt_city_eq_cnt,$txt_city_neq_cnt,$txt_city_null_cnt,$txt_city_ir,$txt_city_ar,$city_txt_eq_cnt,$city_txt_neq_cnt,$city_txt_ir,$city_txt_ar,$city_txtml_eq_cnt,$city_txtml_neq_cnt,$city_txtml_ir,$city_txtml_ar,$txt_city_eq_ir,$txt_city_eq_ar,$incDay,$day)")

      logger.error("双重城市筛单统计完毕")
      logger.error(s"【$incDay】统计完毕")

    }
  }


}
