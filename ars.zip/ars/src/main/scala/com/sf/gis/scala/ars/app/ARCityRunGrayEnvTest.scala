package com.sf.gis.scala.ars.app

import java.net.URLEncoder

import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel;

/**
 * @ProductManager:01425247 段嫦慧
 * @Author: 01374443
 * @CreateTime: 2023-09-16
 * @TaskId:995
 * @TaskName: 地址可达-灰度测试
 * @Description: ,按城市输出
 * @最新修改记录(线上的包如果比这个旧，请重新打包更新)：20230916
 */

object ARCityRunGrayEnvTest {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class ArsRet(
                     address: String,
                     city_code: String,
                     province: String,
                     city: String,
                     county: String,
                     town: String,
                     r_city_code: String,
                     r_province: String,
                     r_city: String,
                     r_county: String,
                     r_town: String,
                     r_village: String,
                     r_detailinfo: String,
                     r_result: Int,
                     result_src: String,
                     req_time: String,
                     resp: String
                   )

  def main(args: Array[String]): Unit = {
    var runCnt = -1
    var citycodeCfgPath = args(0)
    if (args.length >= 2) {
      runCnt = args(1).toInt
    }

    start(citycodeCfgPath, runCnt)
  }

  def queryOriginData(sparkSession: SparkSession) = {
    val originViewName = "bsp_order_src"
    val queryOrginSql = s"select address,dest_dist_code,dest_zone_code,waybill_no,province,city,county,town from dm_gis.ars_server_pressure_test_table_new"
    logger.error(queryOrginSql)
    val rdd = sparkSession.sql(queryOrginSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    rdd.createOrReplaceTempView(originViewName)
    val cnt = rdd.count()
    logger.error(s"工单总量：" + cnt)

    (originViewName, cnt)
  }

  def runNetData(sparkSession: SparkSession, originViewName: String, cnt: Long, runCnt: Int) = {
    var limit = cnt //Math.floor(cnt/5).toInt
    if (runCnt != -1) {
      limit = runCnt
    }
    logger.error("limit:" + limit)
    val resultrdd = sparkSession.sql(s"select address,dest_dist_code,dest_zone_code,waybill_no,province,city,county,town from bsp_order_src  limit $limit")
      .rdd.repartition(30).map(d => {
      val consignee_addr = d.getString(0)
      val dest_dist_code = d.getString(1)
      val dest_zone_code = d.getString(2)
      val waybill_no = d.getString(3)
      val province = d.getString(4)
      val city = d.getString(5)
      val county = d.getString(6)
      val town = d.getString(7)

      //todo fix tip to 1
      val url = s"http://gis-int.int.sfdc.com.cn:1080/ar/api?province=&city=&district=&address=${URLEncoder.encode(consignee_addr, "utf8")}&extention=0&opt=tip1&ak=af5938935293445084a6b7ba8cd23a4c" //af5938935293445084a6b7ba8cd23a4c //87e4924a24564525a0dbab3c86c04103
      val result = HttpClientUtil.getJsonByGetWithError(url, 3)
      if (result != null) {
        try {
          val json = result
          val r_citycode = json.getString("city_code")
          val district = json.getJSONObject("district")
          val r_province = JSONUtil.getJsonValSingle(district, "province", "")
          val r_town = JSONUtil.getJsonValSingle(district, "town", "")
          val r_city = JSONUtil.getJsonValSingle(district, "city", "")
          val r_county = JSONUtil.getJsonValSingle(district, "county", "")
          val r_detailinfo = JSONUtil.getJsonValSingle(district, "detailinfo", "")
          val r_village = JSONUtil.getJsonValSingle(district, "village", "")
          val r_result = json.getInteger("result")
          val result_src = json.getString("src")
          ArsRet(consignee_addr, dest_dist_code, province, city, county, town, r_citycode,
            r_province, r_city, r_county, r_town, r_village, r_detailinfo, r_result, result_src, DateUtil.getCurrentDate("yyyyMMdd HH:mm:ss"), result.toJSONString)
        } catch {
          case e: Exception => {
            logger.error(s"【REQ】：${url.split("ak=")(0)}")
            logger.error(s"【RSP】：$result")
            ArsRet(consignee_addr, dest_dist_code, province, city, county, town, "",
              "", "", "", "", "", "", -100, "", DateUtil.getCurrentDate("yyyyMMdd HH:mm:ss"), result.toJSONString)
          }
        }
      } else {
        logger.error(s"【REQ】：${url.split("ak=")(0)}")
        logger.error(s"【RSP】：$result")
        ArsRet(consignee_addr, dest_dist_code, province, city, county, town, "",
          "", "", "", "", "", "", -1000, "", DateUtil.getCurrentDate("yyyyMMdd HH:mm:ss"), null)
      }
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    val resultrdd_count = resultrdd.count
    logger.error("==================================================================================")
    logger.error(s"纯文本调用数据源总量：${resultrdd_count}，其中服务调用失败数：${resultrdd.filter(obj => (obj.r_result == -100 || obj.r_result == -1000)).count}")
    resultrdd.filter(obj => (obj.r_result == -100 || obj.r_result == -1000)).take(100).foreach(logger.error)
    logger.error("==================================================================================")
    resultrdd
  }

  def saveData(sparkSession: SparkSession, runDataRdd: RDD[ArsRet], today: String) = {
    import sparkSession.implicits._
    //执行上述汇总统计,初始化数据
    val tableNameAR = "ars_pre_address_result"
    runDataRdd.toDF().createOrReplaceTempView(tableNameAR)
    val insertRetSql = s"insert overwrite table dm_gis.${tableNameAR} partition(inc_day='${today}') " +
      s" select * from ${tableNameAR} "
    logger.error(insertRetSql)
    sparkSession.sql(insertRetSql)
    tableNameAR
  }

  def staResultData(sparkSession: SparkSession, view: String, today: String): Unit = {
    var sql = s" select sum(address_count)address_count ,sum(result_1) result_1,sum(result_2)result_2," +
      s"sum(result_3)result_3,min(req_time) min_req_time,max(req_time) max_req_time from (" +
      s"select 1 address_count ,if(r_result=1,1,0) result_1,if(r_result=2,1,0) result_2," +
      s" if(r_result=3,1,0) result_3,if(r_result!=3 and r_result!=2 and r_result!=1,1,0) result_other,req_time" +
      s" from $view ) a "
    val tmpViewName = "tmp" + System.currentTimeMillis()
    val totalDataRdd = sparkSession.sql(sql).repartition(1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("总量大小：" + totalDataRdd.count())
    totalDataRdd.createOrReplaceTempView(tmpViewName)
    val tableName = "dm_gis.ars_pre_result"
    sql = s"insert overwrite table $tableName partition(inc_day='$today') select address_count," +
      s" result_1,result_1/address_count, result_2,result_2/address_count,result_3,result_3/address_count," +
      s" min_req_time,max_req_time from $tmpViewName"
    logger.error(sql)
    sparkSession.sql(sql)
    totalDataRdd.unpersist()
  }

  def queryCompareCityCode(sparkSession: SparkSession, citycodeCfgPath: String) = {
    //城市编码,省,市,区,乡/镇/街道
    val dataframe: DataFrame = sparkSession.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      .csv(citycodeCfgPath)
      .toDF("province_code", "province", "city_code", "adcode", "city", "county_code", "county").persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("装载城市总数量:" + dataframe.count())
    logger.error("构造结果默认值")
    val cityCodeList = dataframe.rdd.map(obj => {
      (obj.getString(2),1)
    }).distinct().collectAsMap()
    cityCodeList.take(10).mkString(",")
    dataframe.unpersist()
    sparkSession.sparkContext.broadcast(cityCodeList)
  }

  def staCitycodeData(sparkSession: SparkSession, runDataRdd: RDD[ArsRet], today: String,
                      cityCodeList: Broadcast[collection.Map[String,Int]]) = {
    import sparkSession.implicits._
    val tmpViewName = "tmp_"+System.currentTimeMillis()
    runDataRdd.map(obj=>{
      val city_code = obj.city_code
      var city_code_matched = 0
      if(city_code.equals(obj.r_city_code)){
        city_code_matched =1
      }
      var city_code_unmatched = 0
      if(!city_code.isEmpty && !city_code.equals(obj.r_city_code)){
        city_code_unmatched =1
      }
      var city_code_empty = 0
      if(obj.r_city_code.isEmpty){
        city_code_empty = 1
      }
      var city_code_error = 0
      if(!city_code.isEmpty && !city_code.equals(obj.r_city_code) && !cityCodeList.value.contains(obj.r_city_code)){
        city_code_error = 1
      }
      (obj.city_code,(1,city_code_matched,city_code_unmatched,city_code_empty,city_code_error,obj.req_time,obj.req_time))
    }).reduceByKey((obj1,obj2)=>{
      var maxTime=obj2._7
      if(obj1._7.compareTo(obj2._7)>0){
        maxTime = obj1._7
      }
      var minTime=obj1._6
      if(obj1._6.compareTo(obj2._6)>0){
        maxTime = obj2._6
      }
      (obj1._1+obj2._1,obj1._2+obj2._2,obj1._3+obj2._3,obj1._4+obj2._4,obj1._5+obj2._5,minTime,maxTime)
    }).map(obj=>{
      (obj._1,obj._2._1,obj._2._2,obj._2._3,obj._2._4,obj._2._5,obj._2._6,obj._2._7)
    }).toDF("city_code","city_code_number","city_code_matched","city_code_unmatched",
      "city_code_empty","city_code_error","min_req_time","max_req_time")
      .createOrReplaceTempView(tmpViewName)
    val tableName = "dm_gis.ars_pre_city_code_data_result"
    val sql = s"insert overwrite table $tableName partition(inc_day='$today') select city_code,city_code_number," +
      s"city_code_matched,city_code_matched/city_code_number city_code_matched_rate, " +
      s"city_code_unmatched,city_code_unmatched/city_code_number city_code_unmatched_rate, " +
      s"city_code_empty,city_code_empty/city_code_number city_code_empty_rate," +
      s"city_code_error,city_code_error/city_code_number city_code_error_rate,min_req_time,max_req_time" +
      s" from $tmpViewName "
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def staProvinceData(sparkSession: SparkSession, view: String, today: String): Unit = {
    var sql = s"select sum(province_number) province_number,sum(city_number) city_number," +
      s"sum(county_number)county_number,sum(town_number) town_number," +
      s"sum(province_unmatched)province_unmatched,sum(city_unmatched)city_unmatched," +
      s"sum(county_unmatched)county_unmatched,sum(town_unmatched)town_unmatched," +
      s"min(req_time)min_req_time,max(req_time)max_req_time from ( " +
      s"select 1 province_number ,1 city_number,1 county_number,1 town_number," +
      s" if(province<>r_province,1,0)province_unmatched,if(city<>r_city,1,0)city_unmatched," +
      s" if(county<>r_county,1,0)county_unmatched,if(town<>r_town,1,0)town_unmatched,req_time " +
      s" from $view) a "
    logger.error(sql)
    val tmpViewName = "tmp" + System.currentTimeMillis()
    val totalDataRdd = sparkSession.sql(sql).repartition(1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("总量大小：" + totalDataRdd.count())
    totalDataRdd.createOrReplaceTempView(tmpViewName)
    val tableName = "dm_gis.ars_pre_data_result"
    sql = s"insert overwrite table $tableName partition(inc_day='$today') select " +
      s"province_number, province_unmatched,province_unmatched/province_number province_unmatched_rate, " +
      s"city_number, city_unmatched,city_unmatched/city_number city_unmatched_rate, " +
      s"county_number, county_unmatched,county_unmatched/county_number county_unmatched_rate, " +
      s"town_number, town_unmatched,town_unmatched/town_number town_unmatched_rate, " +
      s"min_req_time,max_req_time" +
      s" from $tmpViewName "
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def start(citycodeCfgPath: String, runCnt: Int): Unit = {
    val today = DateUtil.getCurrentDate("yyyyMMdd")
    val sparkSession = Spark.getSparkSession(appName)
    logger.error("获取城市配置文件")
    val cityCodeListBc = queryCompareCityCode(sparkSession, citycodeCfgPath)
    logger.error("获取原始数据")
    val (originViewName, cnt) = queryOriginData(sparkSession)
    logger.error("跑ars灰度")
    val runDataRdd = runNetData(sparkSession, originViewName, cnt, runCnt)
    logger.error("结果存表")
    val tmpView = saveData(sparkSession, runDataRdd, today)

    logger.error("统计报表并存表")
    logger.error("统计地址可达情况")
    staResultData(sparkSession, tmpView, today)
    logger.error("统计可达灰度城市代码指标数据表")
    staCitycodeData(sparkSession, runDataRdd, today, cityCodeListBc)
    logger.error("统计可达灰度-省-市-区匹配指标数据表")
    staProvinceData(sparkSession, tmpView, today)
    logger.error("运行完毕")
  }
}
