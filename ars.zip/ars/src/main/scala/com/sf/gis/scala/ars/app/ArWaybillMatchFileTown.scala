package com.sf.gis.scala.ars.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel;

/**
 * @ProductManager:01425247 段嫦慧
 * @Author: 01374443
 * @CreateTime: 2023-09-12
 * @TaskId:815634
 * @TaskName: 地址可达-运单地址匹配指定乡镇地址量
 * @Description: 筛单多出街道数据统计命中运单地址情况-一次性任务
 * @最新修改记录(线上的包如果比这个旧，请重新打包更新)：20230915
 */
object ArWaybillMatchFileTown {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class TownSta(province: String,
                     city: String,
                     cityCode: String,
                     county: String,
                     town: String,
                     addr: String,
                     totalCnt: Int,
                     consigneeMatchCnt: Int,
                     consignorMatchCnt: Int
                    )

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val days = args(1).toInt
    val townCfgPath = args(2)
    logger.error(townCfgPath)
    start(incDay, days,townCfgPath)
  }
//  create table tmp_dm_gis.ar_town_match_01374443_20230912_detail(
//    detail string
//  )
//  PARTITIONED BY (
//    `inc_day` string)
//  ROW FORMAT SERDE
//  'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
//  WITH SERDEPROPERTIES (
//    'field.delim'='\t',
//  'line.delim'='\n',
//  'serialization.format'='\t')
//  STORED AS ORC TBLPROPERTIES('orc.compression'='SNAPPY')



  def parseTownFile(sparkSession: SparkSession,townCfgPath:String) = {
    //城市编码,省,市,区,乡/镇/街道
    val dataframe: DataFrame = sparkSession.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
//      .option("inferSchema", "true")
      .csv(townCfgPath)
//      .csv("hdfs://sfbdp1/user/01374443/upload/ar/ar_town_01425247.csv")
      .toDF("citycode", "province", "city", "county", "town").persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("装载城镇总数量:" + dataframe.count())
    logger.error("构造结果默认值")
    val defaultData = dataframe.rdd.map(obj=>{
      ((obj.getString(0),obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4)),(0, "pai", 0, "shou"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("构造结果默认值数量:"+defaultData)
    logger.error("构造广播")
    val cityTownData = dataframe.rdd.map(obj => {
//      var cityCode = obj.getInt(0)+"";
//      if(cityCode.length<3){
//        cityCode="0"+cityCode
//      }
      (obj.getString(0), (obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4)))
    }).distinct().groupByKey().map(obj => {
      (obj._1, obj._2.toArray)
    }).collectAsMap()
    dataframe.unpersist()
    cityTownData.take(1).foreach(obj=>{
      obj._2.take(5).foreach(obj=>{
        logger.error(obj.toString())
      })
    })
    val cityCodeList = cityTownData.keySet
    (cityCodeList, sparkSession.sparkContext.broadcast(cityTownData),defaultData)
  }



  def queryWaybillData(sparkSession: SparkSession, singleDay: String) = {
    val sql = s"select  src_dist_code,nvl(consignor_addr_decrypt,'') consignor_addr,dest_dist_code,nvl(consignee_addr_decrypt,'') consignee_addr from dm_gis.dwd_waybill_info_dtl_di " +
      s" where inc_day='${singleDay}' "
    logger.error(sql)
    val (dataRdd, columns) = SparkRead.readHiveAsJson(sparkSession, sql)
    dataRdd
  }

  def matchWaybill(sparkSession: SparkSession, waybillData: RDD[JSONObject],
                   cityTownDataBc: Broadcast[collection.Map[String, Array[(String, String, String, String)]]],
                   singleDay: String, defaultData:RDD[((String,String,String,String,String),(Int,String,Int,String))]) = {
    val totalMatchRdd = waybillData.map(obj => {
      val src_dist_code = obj.getString("src_dist_code")
      val consignor_addr = obj.getString("consignor_addr")
      val dest_dist_code = obj.getString("dest_dist_code")
      val consignee_addr = obj.getString("consignee_addr")
      val cityTownData = cityTownDataBc.value
      if (cityTownData.contains(src_dist_code)) {
        val cityTownItem = cityTownData.apply(src_dist_code)
        for (i <- cityTownItem.indices) {
          val tmpItem = cityTownItem(i)
          if (consignor_addr.contains(tmpItem._4)) {
            obj.put("consignor_citycode", src_dist_code)
            obj.put("consignor_province", tmpItem._1)
            obj.put("consignor_city", tmpItem._2)
            obj.put("consignor_county", tmpItem._3)
            obj.put("consignor_town", tmpItem._4)
          }
        }
      }
      if (cityTownData.contains(dest_dist_code)) {
        val cityTownItem = cityTownData.apply(dest_dist_code)
        for (i <- cityTownItem.indices) {
          val tmpItem = cityTownItem(i)
          if (consignee_addr.contains(tmpItem._4)) {
            obj.put("consignee_citycode", dest_dist_code)
            obj.put("consignee_province", tmpItem._1)
            obj.put("consignee_city", tmpItem._2)
            obj.put("consignee_county", tmpItem._3)
            obj.put("consignee_town", tmpItem._4)
          }
        }
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val totalCount = totalMatchRdd.count();
    totalMatchRdd.take(1).foreach(obj=>{
      logger.error(obj.toString())
    })
    logger.error("总数量:"+totalCount)
    val consignee_data = totalMatchRdd.filter(obj => obj.containsKey("consignee_town")).map(obj => {
      val key = Array(obj.getString("consignee_citycode"), obj.getString("consignee_province"),
        obj.getString("consignee_city"), obj.getString("consignee_county"),
        obj.getString("consignee_town")
      ).mkString("_")
      ((obj.getString("consignee_citycode"), obj.getString("consignee_province"),
        obj.getString("consignee_city"), obj.getString("consignee_county"),
        obj.getString("consignee_town")
      ), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("匹配派件的量:" + consignee_data.count())
    SparkWrite.save2HiveStaticSingleColumnNew(sparkSession, consignee_data.values, "tmp_dm_gis.ar_town_match_01374443_20230912_detail", Array(("inc_day", singleDay), ("data_type", "pai")), 1
    )
    val consignor_data = totalMatchRdd.filter(obj => obj.containsKey("consignor_town")).map(obj => {
      val key = Array(obj.getString("consignor_citycode"),
        obj.getString("consignor_province"),
        obj.getString("consignor_city"), obj.getString("consignor_county"),
        obj.getString("consignor_town")
      ).mkString("_")
      ((obj.getString("consignor_citycode"),
        obj.getString("consignor_province"),
        obj.getString("consignor_city"), obj.getString("consignor_county"),
        obj.getString("consignor_town")
      ), obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("匹配上收件的量:" + consignor_data.count())
    totalMatchRdd.unpersist()
    SparkWrite.save2HiveStaticSingleColumnNew(sparkSession, consignor_data.values, "tmp_dm_gis.ar_town_match_01374443_20230912_detail", Array(("inc_day", singleDay), ("data_type", "shou")), 1
    )
    logger.error("聚合派件数据")
    val consigneeGroup = consignee_data.map(obj => (obj._1, 1)).reduceByKey((obj1, obj2) => {
      obj1 + obj2
    }).map(obj => {
      (obj._1, (obj._2, "pai", 0, "shou"))
    })
    val consignorGroup = consignor_data.map(obj => (obj._1, 1)).reduceByKey((obj1, obj2) => {
      obj1 + obj2
    }).map(obj => {
      (obj._1, (0, "pai", obj._2, "shou"))
    })
    //补齐所有的城镇，避免没有匹配到不出现


    import sparkSession.implicits._
    var tmpView = "tmp_" + System.currentTimeMillis()
    val totalGroup = consigneeGroup.union(consignorGroup).union(defaultData).reduceByKey((obj1, obj2) => {
      (obj2._1 + obj1._1, obj1._2, obj1._3 + obj2._3, obj1._4)
    }).map(obj => {
      (obj._1._1, obj._1._2, obj._1._3, obj._1._4, obj._1._5, obj._2._1, obj._2._3, totalCount)
    }).repartition(1).toDF("citycode", "province", "city", "county", "town", "pai_cnt", "shou_cnt", "total_cnt")
      .createOrReplaceTempView(tmpView)
    val sql = s"insert overwrite table tmp_dm_gis.ar_town_match_01374443_20230912 partition(inc_day='$singleDay') " +
      s"select * from $tmpView"
    logger.error(sql)
    sparkSession.sql(sql)
    consignee_data.unpersist()
    consignor_data.unpersist()
  }

  def startStaSingleDay(sparkSession: SparkSession, singleDay: String,
                        cityTownData: Broadcast[collection.Map[String, Array[(String, String, String, String)]]],
                          defaultData:RDD[((String,String,String,String,String),(Int,String,Int,String))]) = {
    logger.error("获取运单宽表数据")
    val waybillData = queryWaybillData(sparkSession, singleDay)
    logger.error("匹配数据")
    matchWaybill(sparkSession, waybillData, cityTownData, singleDay,defaultData)

  }

  def start(incDay: String, days: Int,townCfgPath:String): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    val (cityCodeList, cityTownData,defaultData) = parseTownFile(sparkSession,townCfgPath)
    for (i <- 0 until days) {
      val singleDay = DateUtil.getDateStr(incDay, 0 - i)
      logger.error("开始处理singleDay")
      startStaSingleDay(sparkSession, singleDay, cityTownData,defaultData)
      sparkSession.catalog.clearCache()
    }
    logger.error("处理完毕")
  }
}
