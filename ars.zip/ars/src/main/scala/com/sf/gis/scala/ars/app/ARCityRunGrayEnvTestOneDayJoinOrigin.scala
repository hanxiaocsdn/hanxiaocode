package com.sf.gis.scala.ars.app

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkNetNew}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession;

/**
 * @ProductManager:01425247 段嫦慧
 * @Author: 01374443
 * @CreateTime: 2023-09-16
 * @TaskId:1023
 * @TaskName: 地址可达-灰度测试
 * @Description: 回挂数据
 * @最新修改记录(线上的包如果比这个旧，请重新打包更新)：20230916,
 */

object ARCityRunGrayEnvTestOneDayJoinOrigin {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val pidStart = args(1).toInt
    val pidEnd = args(2).toInt
    start(incDay, pidStart, pidEnd)
  }


  def runNetworkInteface(sparkSession: SparkSession, originData: RDD[JSONObject], thread: Int, akLimit: Int,
                         isExitInDay: Boolean) = {
    val parmMap = new util.HashMap[String, String]()
    if (isExitInDay) {
      parmMap.put("exitHour", "1")
      parmMap.put("exitHourMin", "8")
      parmMap.put("exitHourMax", "20")
    }
    val inputDataRdd = SparkNetNew.queryAddrReachGray(sparkSession, originData, "af5938935293445084a6b7ba8cd23a4c",
      thread, akLimit, "province", "city", "district", "address", false, 5000, parmMap)
    inputDataRdd
  }

  def joinOriginData(sparkSession: SparkSession, incDay: String, pid: String): Unit = {
    val sql = s" insert overwrite table dm_gis.bee_logs_gis_ar_parse_and_run_test_rslt " +
      s" partition(inc_day='${incDay}',pid='${pid}') " +
      s" select a.sn,a.province,a.city,a.district,a.address,a.pre_city_code,a.pre_province,a.pre_city,a.pre_county,a.pre_town,a.pre_village,a.pre_detailinfo,a.pre_source,a.pre_src," +
      s" r_city_code,b.r_province,b.r_city,b.r_county,b.r_town,b.r_village,b.r_detailinfo,b.r_src,b.myexception,a.pre_result,b.r_result,a.ak,a.order_no," +
      s" r_bxy_province,r_bxy_city,r_bxy_county,r_bxy_town,r_bxy_village,r_bxy_detailinfo," +
      s" pre_detail_addr,pre_detail_level,pre_detail_addr_special,pre_detail_type,pre_town_only,pre_splite_result_iad, " +
      s" r_detail_addr,r_detail_level,r_detail_addr_special,r_detail_type,r_town_only,r_splite_result_iad " +
      s" from " +
      s" (select * from dm_gis.bee_logs_gis_ar_parse where inc_day='${incDay}' and pid='${pid}') a " +
      s" left join " +
      s" (select * from dm_gis.ar_gray_test_address_no_repeat_run_network_ret where inc_day='${incDay}') b " +
      s" on a.province=b.province and a.city=b.city and a.district=b.district " +
      s" and a.address=b.address "
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def start(incDay: String, pidStart: Int, pidEnd: Int): Unit = {

    val sparkSession = Spark.getSparkSession(appName)

    for (i <- pidStart to pidEnd) {
      logger.error("关联原始数据：" + incDay + ",pid:" + i)
      joinOriginData(sparkSession, incDay, i.toString)
      sparkSession.catalog.clearCache()
    }
    logger.error("关联入库结束")
  }
}
