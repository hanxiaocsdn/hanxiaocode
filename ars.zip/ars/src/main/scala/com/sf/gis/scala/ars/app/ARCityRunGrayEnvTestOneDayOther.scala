package com.sf.gis.scala.ars.app

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.spark.{Spark, SparkNetNew, SparkRead, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession};

/**
 * @ProductManager:01425247 段嫦慧
 * @Author: 01374443
 * @CreateTime: 2023-09-16
 * @TaskId:1060
 * @TaskName: 地址可达-灰度测试
 * @Description: ,按城市输出,前置任务id:1016
 * @最新修改记录(线上的包如果比这个旧，请重新打包更新)：20230916,用于处理杂七杂八的数据源
 */

object ARCityRunGrayEnvTestOneDayOther {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val envFlagDefault = "prod"
  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val count = args(1).toInt
    val thread = args(2).toInt
    val akLimit = args(3).toInt
    //白天是否不跑
    val isExitInDay = args(4).toBoolean
    val envFlag =  args(5)
    val originTableName=args(6)
    val retTableName=args(7)
    start(incDay, count,thread,akLimit,isExitInDay,envFlag,originTableName,retTableName)
  }

  def queryOriginData(sparkSession: SparkSession, incDay: String, originTableName: String,count:Int) = {
    var sql = s"select province,city,district,address from  ${originTableName} where inc_day='${incDay}' "
    if(count != -1){
      sql = sql +s" limit ${count} "
    }
    logger.error(sql)
    val (dataRdd, columns) = SparkRead.readHiveAsJson(sparkSession, sql)
    dataRdd.take(2).foreach(obj=>{
      logger.error(obj.toJSONString)
    })
    dataRdd
  }

  def runNetworkIntefaceGray(sparkSession: SparkSession, originData: RDD[JSONObject],thread:Int,akLimit:Int,
                         isExitInDay:Boolean) = {
    val parmMap = new util.HashMap[String,String]()
    logger.error("isExitInDay:"+isExitInDay)
    if(isExitInDay){
      parmMap.put("exitHour","1")
      parmMap.put("exitHourMin","7")
      parmMap.put("exitHourMax","20")
    }
    val inputDataRdd = SparkNetNew.queryAddrReachGray(sparkSession, originData, "af5938935293445084a6b7ba8cd23a4c",
      thread, akLimit, "province", "city", "district", "address", true,5000,parmMap)
    inputDataRdd.take(2).foreach(obj=>{
      logger.error(obj.toJSONString)
    })
    inputDataRdd
  }
  def runNetworkIntefaceProd(sparkSession: SparkSession, originData: RDD[JSONObject],thread:Int,akLimit:Int,
                             isExitInDay:Boolean) = {
    val parmMap = new util.HashMap[String,String]()
    logger.error("isExitInDay:"+isExitInDay)
    if(isExitInDay){
      parmMap.put("exitHour","1")
      parmMap.put("exitHourMin","7")
      parmMap.put("exitHourMax","20")
    }
    val inputDataRdd = SparkNetNew.queryAddrReachGray(sparkSession, originData, "58b2111039c7486a866293436ea1ef20",
      thread, akLimit, "province", "city", "district", "address", true,5000,parmMap)
    inputDataRdd.take(2).foreach(obj=>{
      logger.error(obj.toJSONString)
    })
    inputDataRdd
  }
  def runNetworkIntefaceTest(sparkSession: SparkSession, originData: RDD[JSONObject],thread:Int,akLimit:Int,
                         isExitInDay:Boolean) = {
    val parmMap = new util.HashMap[String,String]()
    logger.error("isExitInDay:"+isExitInDay)
    if(isExitInDay){
      parmMap.put("exitHour","1")
      parmMap.put("exitHourMin","7")
      parmMap.put("exitHourMax","20")
    }
    val inputDataRdd = SparkNetNew.queryAddrReachTest(sparkSession, originData, "762b849f5a1d41228a1b4432d4e38ccd",
      thread, akLimit, "province", "city", "district", "address", false,5000,parmMap)
    inputDataRdd.take(2).foreach(obj=>{
      logger.error(obj.toJSONString)
    })
    inputDataRdd
  }

  def runNetworkInteface(sparkSession: SparkSession, originData: RDD[JSONObject], thread: Int, akLimit: Int, isExitInDay: Boolean, envFlag: String) = {
    if("gray".equals(envFlag)){
      val id = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01374443","1017","ar全天数据灰度测试跑接口","",CommonUrl.addReachUrlGray,"af5938935293445084a6b7ba8cd23a4c",originData.count(),35)
      val retRdd = runNetworkIntefaceGray(sparkSession, originData,thread,akLimit,isExitInDay)
      BdpTaskRecordUtil.endNetworkInterface("01374443",id)
      retRdd
    }else if("prod".equals(envFlag)) {
      val id = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01374443","1017","ar全天数据生产跑接口","",CommonUrl.addReachUrlGray,"58b2111039c7486a866293436ea1ef20",originData.count(),35)
      val retRdd = runNetworkIntefaceProd(sparkSession, originData,thread,akLimit,isExitInDay)
      BdpTaskRecordUtil.endNetworkInterface("01374443",id)
      retRdd
    }
      else
    {
      runNetworkIntefaceTest(sparkSession, originData,thread,akLimit,isExitInDay)
    }
  }

  def start(incDay: String, count:Int, thread:Int, akLimit:Int,
            isExitInDay:Boolean, envFlag:String,originTableName:String,retTableName:String): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    logger.error("获取原始数据：" + incDay + ",originTableName:" + originTableName+",retTableName:"+retTableName+",thread:"+thread+",akLimit:"+akLimit+",isExitInDay:"+isExitInDay)
    val originData = queryOriginData(sparkSession, incDay, originTableName,count)
    logger.error("开始跑接口")
    val retRdd = runNetworkInteface(sparkSession, originData,thread,akLimit,isExitInDay,envFlag)
    logger.error("开始存储数据")
    val saveKeyName = Array("province", "city", "district", "address", "r_province", "r_city", "r_county", "r_town", "r_village", "r_detailinfo", "r_result", "r_src","myException","r_city_code",
      "r_bxy_province","r_bxy_city","r_bxy_county","r_bxy_town","r_bxy_village","r_bxy_detailinfo","r_detail_addr","r_detail_level","r_detail_addr_special","r_detail_type","r_town_only",
      "r_splite_result_iad","addrReachGray")
    SparkWrite.save2HiveStaticNew(sparkSession, retRdd, saveKeyName, retTableName,
      Array(("inc_day", incDay),("pid","0")), retRdd.getNumPartitions,SaveMode.Overwrite,false)
  }
}
