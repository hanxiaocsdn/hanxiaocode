package com.sf.gis.scala.ars.app

import com.sf.gis.scala.base.spark.{Spark, SparkRead}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer;

/**
 * @ProductManager:01425247 段嫦慧
 * @Author: 01374443
 * @CreateTime: 2023-09-16
 * @TaskId:1059
 * @TaskName: 地址可达-灰度测试
 * @Description: 准备测试数据
 * @最新修改记录(线上的包如果比这个旧，请重新打包更新)：20231123, 用于装载其他乱七八糟的数据源
 */
/**
 * 高频地址来源
 * create table show create table tmp_dm_gis.tmp_addr_01374443_high_freq as
 * select addr from dm_gis.dwd_dkh_addr_src_stat_mi  where ttl_cnt > 300  or ttl_freight>1000 group by addr
 *
 */
object ARCityRunGrayEnvTestOneDayOtherOriginData {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val bspRun = args(1).toBoolean
    val encryAddrRun = args(2).toBoolean
    val highFreqAddr = args(3).toBoolean
    val bspFilePath = args(4)
    val highFreqFilePath = args(5)
    val reRunGrayTest = args(6).toBoolean
    start(incDay, bspRun, encryAddrRun, highFreqAddr, bspFilePath, highFreqFilePath, reRunGrayTest)
  }


  def parseLog(sparkSession: SparkSession, incDay: String): Unit = {
    val sql = s"insert overwrite  table dm_gis.bee_logs_gis_ar_parse partition(inc_day,pid) " +
      "select  " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.sn'),'')sn, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.ak'),'') ak, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.province'), '') province," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.city'),'')city," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.district'),'') district, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.address'),'')  address," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.city_code'),'') pre_city_code," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.province'),'')pre_province," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.city'),'')pre_city," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.county'),'')pre_county," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.town'),'')pre_town," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.village'),'')pre_village, " +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.detailinfo'),'')pre_detailinfo, " +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.source'),'') pre_source," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.src'),'') pre_src," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.result'),'') pre_result, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.order_no'),'') order_no, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_addr'),'') pre_detail_addr," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_level'),'') pre_detail_level," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_addr_special'),'') pre_detail_addr_special," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_type'),'') pre_detail_type," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.town_only'),'') pre_town_only," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.splite_result_iad'),'') pre_splite_result_iad," +
      " inc_day,   cast(rand()*8 as int ) as pid  from dm_gis.bee_logs_gis_ar_collect " +
      s"  where inc_day='${incDay}' " +
      " and  get_json_object(get_json_object(log,'$.message'),'$.type')='url_e'  " +
      " and get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'), '$.ak')<>'af5938935293445084a6b7ba8cd23a4c'"
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def groupData(sparkSession: SparkSession, incDay: String): Unit = {
    val sql = s"insert overwrite  table dm_gis.ar_gray_test_address_no_repeat partition(inc_day,pid) " +
      s" select province,city,district,address,inc_day,cast(rand()*8 as int ) as pid from dm_gis.bee_logs_gis_ar_parse where inc_day='${incDay}'" +
      s" group by province,city,district,address,inc_day"
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def parseBspLog(sparkSession: SparkSession, bspFilePath: String, incDay: String) = {
    //城市编码,省,市,区,乡/镇/街道
    val dataframe = sparkSession.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      //      .option("inferSchema", "true")
      .csv(bspFilePath)
      //      .csv("hdfs://sfbdp1/user/01374443/upload/ar/ar_town_01425247.csv")
      .toDF("name", "address", "result", "citycode", "province", "city", "county", "town")
      .rdd.map(obj => {
      (convertEmpty(obj.getString(1)))
    }).distinct().persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("装载bsp总数量:" + dataframe.count())
    val tmpName = "tmp_" + System.currentTimeMillis()
    import sparkSession.implicits._
    dataframe.toDF("addr").createOrReplaceTempView(tmpName)
    val sql = s"insert overwrite table dm_gis.origin_ar_basp_data partition(inc_day='${incDay}') " +
      s" select '' province,'' city,'' district, a.* from ${tmpName} a "
    logger.error(sql)
    sparkSession.sql(sql)
    logger.error("存储完毕")
  }

  def parseHighFreqAddr(sparkSession: SparkSession, incDay: String) = {
    val sql = s"insert overwrite table dm_gis.origin_ar_highfreq_data partition(inc_day='${incDay}') " +
      s" select '' province,'' city,'' district, addr from dm_gis.dm_vip_addr_high_freq_mf a "
    logger.error(sql)
    sparkSession.sql(sql)
    logger.error("存储完毕")
  }

  def parseHighFreqAddrBak(sparkSession: SparkSession, highFreqFilePath: String, incDay: String) = {
    //城市编码,省,市,区,乡/镇/街道
    val dataframe = sparkSession.read
      .format("csv")
      .option("sep", "\\t")
      //      .option("header", "true")
      //      .option("inferSchema", "true")
      .csv(highFreqFilePath)
      //      .csv("hdfs://sfbdp1/user/01374443/upload/ar/ar_town_01425247.csv")
      .toDF("addr")
      .rdd.map(obj => {
      (convertEmpty(obj.getString(0)))
    }).distinct().repartition(10).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("装载高频总数量:" + dataframe.count())
    val tmpName = "tmp_" + System.currentTimeMillis()
    import sparkSession.implicits._
    dataframe.toDF("addr").createOrReplaceTempView(tmpName)
    val sql = s"insert overwrite table dm_gis.origin_ar_highfreq_data partition(inc_day='${incDay}') " +
      s" select '' province,'' city,'' district, a.* from ${tmpName} a "
    logger.error(sql)
    sparkSession.sql(sql)
    logger.error("存储完毕")
  }

  def parseEncryptAddr(sparkSession: SparkSession, incDay: String) = {
    //切换address=DE匹配
    var sql = "select get_json_object(get_json_object(log,'$.message'),'$.url.url') " +
      s"  from dm_gis.bee_logs_gis_ar_collect where inc_day='${incDay}' " +
      "and log like '%DE%' and log like '%url_s%'"
    logger.error(sql)
    val data = sparkSession.sql(sql).rdd
      .map(obj => {
        obj.getString(0)
      }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("包含DE的数量：" + data.count())
    //    data.take(2).foreach(obj=>{
    //      logger.error("***"+obj)
    //    })
    val convertRdd = data.map(obj => {
      parse(obj)
    }).distinct().filter(obj => obj != null)

    import sparkSession.implicits._
    val tmpView = "tmp_" + System.currentTimeMillis()
    convertRdd.repartition(10).toDF("address").createOrReplaceTempView(tmpView)
    sql = s" insert overwrite table dm_gis.origin_ar_encrypt_data partition(inc_day='${incDay}') " +
      s" select '' province,'' city,'' district, a.* from ${tmpView} a"
    logger.error(sql)
    sparkSession.sql(sql)
    logger.error("存储完毕")
  }

  def parseRerunGrayTestdata(sparkSession: SparkSession, incDay: String) = {
    var sql = s"select province,city,district,address " +
      s" from  dm_gis.bee_logs_gis_ar_parse_and_run_test_rslt where inc_day='${incDay}' and (pre_result='3' or r_result='3') and (pre_result<>r_result or pre_result is null or r_result is null ) "
    logger.error(sql)
    val (dataRdd, columns) = SparkRead.readHiveAsJson(sparkSession, sql)
    dataRdd.take(2).foreach(obj => {
      logger.error(obj.toJSONString)
    })
    import sparkSession.implicits._
    val tmpView = "tmp_" + System.currentTimeMillis()
    val convertRdd = dataRdd.map(obj => {
      (obj.getString("province"),
        obj.getString("city"), obj.getString("district"),
        obj.getString("address")
      )
    }).distinct().repartition(10).toDF("province", "city", "district", "address").createOrReplaceTempView(tmpView)

    sql = s" insert overwrite table dm_gis.origin_ar_rerun_gray_test_data partition(inc_day='${incDay}') " +
      s" select * from ${tmpView} "
    logger.error(sql)
    sparkSession.sql(sql)
    logger.error("存储完毕")
  }

  def start(incDay: String, bspRun: Boolean, encryAddrRun: Boolean, highFreqAddr: Boolean,
            bspFilePath: String, highFreqFilePath: String, reRunGrayTest: Boolean): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    if (bspRun) {
      logger.error("获取bsp数据")
      parseBspLog(sparkSession, bspFilePath, incDay)
    }
    if (highFreqAddr) {
      logger.error("获取高频数据")
      parseHighFreqAddr(sparkSession, incDay)
    }
    logger.error("按照省市区地址排重，写表")
    if (encryAddrRun) {
      logger.error("获取加密地址")
      parseEncryptAddr(sparkSession, incDay)
    }
    logger.error("重跑灰度测试疑问数据，写表")
    if (reRunGrayTest) {
      logger.error("灰度测试疑问数据")
      parseRerunGrayTestdata(sparkSession, incDay)
    }
    logger.error("处理完成")
  }

  def convertEmpty(str: String): String = {
    if (str == null) {
      return ""
    }
    return str
  }

  /**
   * 解析url
   *
   * @param
   * @return
   */
  def parse(urlStr: String): String = {

    if (urlStr == null) {
      return null;
    }
    val url = urlStr.trim();
    if (url.equals("")) {
      return null;
    }
    val urlParts = url.split("\\?");

    val baseUrl = urlParts(0);
    val sb = new ArrayBuffer[String]()
    //有参数
    val params = urlParts(1).split("&");
    for (param <- params) {
      val keyValue = param.split("=");
      if (!keyValue(0).equals("ak")) {
        sb.append(param)
      }
    }
    if (sb.length == 0) {
      return null
    }
    return "http://gis-int.int.sfdc.com.cn:1080/ar/api" + "?" + sb.mkString("&") + "&ak=";
  }

}
