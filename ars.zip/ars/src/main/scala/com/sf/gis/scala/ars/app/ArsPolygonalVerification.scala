package com.sf.gis.scala.ars.app


import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.SparkUtils.getDfToJson
import com.sf.gis.scala.base.spark.SparkWrite.writeToHiveNoPart
import com.vividsolutions.jts.io.WKTReader
import org.apache.spark.sql.functions.{col, concat, desc, lit, round, row_number, sum, trim, when}
import Jtstool.getArea
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel

/**
 *需求名称：多边形面数据校验
 *需求描述：由于历史行政区划数据更新存在不准确或遗漏的一些错误数据。为了解决这一问题，为了确保行政区划数据的准确性和完整性，需要对行政区划数据进行校验。
 *需求方：01436983 王艳
 *开发: 周勇(01390943)
 *任务创建时间：20240124
 *任务id：998349
 **/

object ArsPolygonalVerification {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")

    val spark = SparkSession
      .builder()
      .appName(className)
      //.config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .enableHiveSupport()
      .getOrCreate()

    import spark.implicits._

    update_wkt(spark)

    logger.error(">>>任务执行完毕")
    spark.close()
  }


  //定义数据清洗，计算各层级面积
  def update_wkt(spark:SparkSession): Unit ={
    import spark.implicits._

    //市级数据清洗
    val citydata=spark.sql("select * from dm_gis.dm_csv_ars_city_af where wkt !='wkt'")

    // logger.error("citydata分区数："+citydata.rdd.partitions.length)

    val citydata2= getDfToJson(spark, citydata,20)
      .map(
        obj=>{
          val wkt=obj.getString("wkt")
          val adcode=obj.getString("adcode")
          val name=obj.getString("name")
          val adcode_p=obj.getString("adcode_p")
          val name_p=obj.getString("name_p")
          val citycode=obj.getString("citycode")
          val name_en=obj.getString("name_en")
          val name_cht=obj.getString("name_cht")
          val name_p_en=obj.getString("name_p_en")
          val name_p_cht=obj.getString("name_p_cht")

          val wkt_tmp=wkt.replace("MULTIPOLYGON(((","")
            .replace(")))","")
          //最外面的循环
          val z= wkt_tmp.replace(")),((", "),(").split("\\),\\(")
          val s=z.size
          val ar2=new ArrayBuffer[String]()
          val area_cal=new ArrayBuffer[Double]()
          if(s>0){
            for(i<-0 to s-1){
              // println(z(i))

              //最里面的坐标循环
              val z_i=z(i).split(",")
              val s_z_i=z_i.size
              val ar1=new ArrayBuffer[String]()
              if(s_z_i>0){
                for(j<-0 to s_z_i-1){
                  try{
                    val xcoord=z_i(j).split(" ")(0)
                    val ycoord=z_i(j).split(" ")(1)
                    val xy=(xcoord.toDouble/3600).formatted("%.6f").concat(" ").concat((ycoord.toDouble/3600).formatted("%.6f"))
                    ar1.append(xy)
                  }
                  catch{
                    case e: Exception => logger.error("e1:"+e)
                  }
                }

              }
              val ar1_string=ar1.mkString(",")
              ar2.append(ar1_string)

            }

          }

          var wkt_new=""
          if(wkt.contains(")),((")){wkt_new="MULTIPOLYGON(((".concat(ar2.mkString(")),((")).concat(")))")}
          else {wkt_new="MULTIPOLYGON(((".concat(ar2.mkString("),(")).concat(")))")}

          val reader = new WKTReader
          val wkt_new_rd= reader.read(wkt_new)
          val area_new=(getArea(wkt_new_rd)/1000000).formatted("%.4f").toString
          city_tb(wkt,adcode,name,adcode_p,name_p,citycode,name_en,name_cht,name_p_en,name_p_cht,wkt_new,area_new)
        }
      ).toDF()
      .withColumn("joinkey_city",concat($"adcode_p",lit("_"),$"name_p",lit("_"),$"adcode",lit("_"),$"name"))
      .coalesce(5)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //logger.error("citydata2分区数1："+citydata2.rdd.partitions.length)

    //选择所需列
    val city_cols = spark.sql("""select * from dm_gis.dm_csv_ars_city2_af limit 0""").schema.map(_.name).map(col)
    writeToHiveNoPart(spark, citydata2.select(city_cols: _*), "dm_gis.dm_csv_ars_city2_af")

    //区级数据清洗
    val countydata=spark.sql("select * from dm_gis.dm_csv_ars_county_af  where wkt !='wkt' and level_xzqh='COUNTY' ")
      .withColumn("rank",row_number()over(Window.partitionBy('adcode).orderBy(desc("priority"))))
      .filter($"rank"===1)

    val countydata2= getDfToJson(spark, countydata,150)
      .map(
        obj=>{
          val wkt=obj.getString("wkt")
          val adcode=obj.getString("adcode")
          val name_chn=obj.getString("name_chn")
          val name_eng=obj.getString("name_eng")
          val citycode=obj.getString("citycode")
          val station=obj.getString("station")
          val population=obj.getString("population")
          val postcode=obj.getString("postcode")
          val area=obj.getString("area")
          val adcode_p=obj.getString("adcode_p")
          val name_p=obj.getString("name_p")
          val adcode_c=obj.getString("adcode_c")
          val name_c=obj.getString("name_c")
          val adcode_d=obj.getString("adcode_d")
          val name_d=obj.getString("name_d")
          val level_xzqh=obj.getString("level_xzqh")
          val descr=obj.getString("descr")
          val changedesc=obj.getString("changedesc")
          val name_als=obj.getString("name_als")
          val adcode_als=obj.getString("adcode_als")
          val update_t=obj.getString("update_t")
          val sourcetime=obj.getString("sourcetime")
          val productor=obj.getString("productor")
          val upd_date=obj.getString("upd_date")
          val brief=obj.getString("brief")
          val name_r=obj.getString("name_r")
          val typea=obj.getString("type")
          val priority=obj.getString("priority")
          val centerx=obj.getString("centerx")
          val centery=obj.getString("centery")
          val sys_id=obj.getString("sys_id")
          val flag=obj.getString("flag")
          val name_en=obj.getString("name_en")
          val name_cht=obj.getString("name_cht")
          val name_p_en=obj.getString("name_p_en")
          val name_p_cht=obj.getString("name_p_cht")
          val name_c_en=obj.getString("name_c_en")
          val name_c_cht=obj.getString("name_c_cht")
          val name_d_en=obj.getString("name_d_en")
          val name_d_cht=obj.getString("name_d_cht")

          val wkt_tmp=wkt.replace("MULTIPOLYGON(((","")
            .replace(")))","")
          //最外面的循环
          // val z=wkt_tmp.split("\\)\\)\\,\\(\\(")
          val z= wkt_tmp.replace(")),((", "),(").split("\\),\\(")
          val s=z.size
          val ar2=new ArrayBuffer[String]()
          val area_cal=new ArrayBuffer[Double]()
          if(s>0){
            for(i<-0 to s-1){
              //println(z(i))

              //最里面的坐标循环
              val z_i=z(i).split(",")
              val s_z_i=z_i.size
              val ar1=new ArrayBuffer[String]()
              if(s_z_i>0){
                for(j<-0 to s_z_i-1){
                  try{
                    val xcoord=z_i(j).split(" ")(0)
                    val ycoord=z_i(j).split(" ")(1)
                    //println(xcoord)
                    //println(ycoord)
                    val xy=(xcoord.toDouble/3600).formatted("%.6f").concat(" ").concat((ycoord.toDouble/3600).formatted("%.6f"))
                    //println(xy)
                    ar1.append(xy)
                  }
                  catch{
                    case e: Exception => logger.error("e4:"+e)
                  }
                }

                //取第一个点形成闭环
                try{
                  val xcoord=z_i(0).split(" ")(0)
                  val ycoord=z_i(0).split(" ")(1)
                  val xy=(xcoord.toDouble/3600).formatted("%.6f").concat(" ").concat((ycoord.toDouble/3600).formatted("%.6f"))
                  ar1.append(xy)
                }
                catch{
                  case e: Exception => logger.error("e5:"+e)
                }

              }
              val ar1_string=ar1.mkString(",")
              ar2.append(ar1_string)

            }

          }
          var wkt_new=""
          if(wkt.contains(")),((")){wkt_new="MULTIPOLYGON(((".concat(ar2.mkString(")),((")).concat(")))")}
          else {wkt_new="MULTIPOLYGON(((".concat(ar2.mkString("),(")).concat(")))")}

          val reader = new WKTReader
          val wkt_new_rd= reader.read(wkt_new)
          val area_new=(getArea(wkt_new_rd)/1000000).formatted("%.4f").toString
          county_tb(wkt,adcode,name_chn,name_eng,citycode,station,population,postcode,area,adcode_p,name_p,adcode_c,
            name_c,adcode_d,name_d,level_xzqh,descr,changedesc,name_als,adcode_als,update_t,sourcetime,
            productor,upd_date,brief,name_r,typea,priority,centerx,centery,sys_id,flag,name_en,name_cht,
            name_p_en,name_p_cht,name_c_en,name_c_cht,name_d_en,name_d_cht,wkt_new,area_new)
        }
      ).toDF()
      .withColumn("type",$"typea")
      .withColumn("joinkey_city",concat($"adcode_p",lit("_"),$"name_p",lit("_"),$"adcode_c",lit("_"),$"name_c"))
      .withColumn("joinkey_county",concat($"adcode_p",lit("_"),$"name_p",lit("_"),$"adcode_c",lit("_"),$"name_c",lit("_"),$"adcode",lit("_"),$"name_chn"))
      .coalesce(5)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //选择所需列
    val county_cols = spark.sql("""select * from dm_gis.dm_csv_ars_county2_af limit 0""").schema.map(_.name).map(col)
    writeToHiveNoPart(spark, countydata2.select(county_cols: _*), "dm_gis.dm_csv_ars_county2_af")

    //街道级数据清洗
    val towndata=spark.sql("select * from dm_gis.dm_csv_ars_alltown_af where wkt !='wkt'")


    val towndata2= getDfToJson(spark, towndata,150)
      .map(
        obj=>{
          val wkt=obj.getString("wkt")
          val area_code=obj.getString("area_code")
          val citycode=obj.getString("citycode")
          val name=obj.getString("name")
          val adcode_p=obj.getString("adcode_p")
          val name_p=obj.getString("name_p")
          val adcode_c=obj.getString("adcode_c")
          val name_c=obj.getString("name_c")
          val adcode_d=obj.getString("adcode_d")
          val name_d=obj.getString("name_d")
          val flag=obj.getString("flag")
          val name_en=obj.getString("name_en")
          val name_cht=obj.getString("name_cht")
          val name_p_en=obj.getString("name_p_en")
          val name_p_cht=obj.getString("name_p_cht")
          val name_c_en=obj.getString("name_c_en")
          val name_c_cht=obj.getString("name_c_cht")
          val name_d_en=obj.getString("name_d_en")
          val name_d_cht=obj.getString("name_d_cht")

          val wkt_tmp=wkt.replace("MULTIPOLYGON(((","")
            .replace(")))","")
          //最外面的循环
          //val z=wkt_tmp.split("\\)\\)\\,\\(\\(")
          val z= wkt_tmp.replace(")),((", "),(").split("\\),\\(")
          val s=z.size
          val ar2=new ArrayBuffer[String]()
          val area_cal=new ArrayBuffer[Double]()
          if(s>0){
            for(i<-0 to s-1){
              //println(z(i))

              //最里面的坐标循环
              val z_i=z(i).split(",")
              val s_z_i=z_i.size
              val ar1=new ArrayBuffer[String]()
              if(s_z_i>0){
                for(j<-0 to s_z_i-1){
                  try{
                    val xcoord=z_i(j).split(" ")(0)
                    val ycoord=z_i(j).split(" ")(1)
                    //println(xcoord)
                    //println(ycoord)
                    val xy=(xcoord.toDouble/3600).formatted("%.6f").concat(" ").concat((ycoord.toDouble/3600).formatted("%.6f"))
                    //println(xy)
                    ar1.append(xy)
                  }
                  catch{
                    case e: Exception => logger.error("e7:"+e)
                  }
                }

                //取第一个点形成闭环
                try{
                  val xcoord=z_i(0).split(" ")(0)
                  val ycoord=z_i(0).split(" ")(1)
                  val xy=(xcoord.toDouble/3600).formatted("%.6f").concat(" ").concat((ycoord.toDouble/3600).formatted("%.6f"))
                  ar1.append(xy)
                }
                catch{
                  case e: Exception => logger.error("e8:"+e)
                }
              }
              val ar1_string=ar1.mkString(",")
              ar2.append(ar1_string)

            }

          }
          var wkt_new=""
          if(wkt.contains(")),((")){wkt_new="MULTIPOLYGON(((".concat(ar2.mkString(")),((")).concat(")))")}
          else {wkt_new="MULTIPOLYGON(((".concat(ar2.mkString("),(")).concat(")))")}

          val reader = new WKTReader
          val wkt_new_rd= reader.read(wkt_new)
          val area_new=(getArea(wkt_new_rd)/1000000).formatted("%.4f").toString
          alltown_tb(wkt,area_code,citycode,name,adcode_p,name_p,adcode_c,name_c,adcode_d,name_d,flag,name_en,name_cht,name_p_en,
            name_p_cht,name_c_en,name_c_cht,name_d_en,name_d_cht,wkt_new,area_new)
        }
      ).toDF()
      .withColumn("joinkey_county",concat($"adcode_p",lit("_"),$"name_p",lit("_"),$"adcode_c",lit("_"),$"name_c",lit("_"),$"adcode_d",lit("_"),$"name_d"))
      .coalesce(5)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //选择所需列
    val town_cols = spark.sql("""select * from dm_gis.dm_csv_ars_alltown2_af limit 0""").schema.map(_.name).map(col)
    writeToHiveNoPart(spark, towndata2.select(town_cols: _*), "dm_gis.dm_csv_ars_alltown2_af")

    //街道汇总区县面积
    val towndata2_total=towndata2.withColumn("area_new",when($"area_new".isNull || trim($"area_new")==="" || $"area_new".like("%P%"),0.0).otherwise($"area_new"))
      .groupBy("joinkey_county")
      .agg(sum($"area_new") as "area_new_town")

    //区县汇总市面积
    val countydata2_total=countydata2.withColumn("area_new",when($"area_new".isNull || trim($"area_new")==="" || $"area_new".like("%P%"),0.0).otherwise($"area_new"))
      .groupBy("joinkey_city")
      .agg(sum($"area_new") as "area_new_county")

    val citydata2_res=citydata2.join(countydata2_total,Seq("joinkey_city"),"left")
      .withColumn("cityname",$"name")
      .withColumn("citycode",$"adcode")
      .withColumn("cityarea",when($"area_new".isNull || trim($"area_new")==="",0.0).otherwise($"area_new"))
      .withColumn("all_county_area",when($"area_new_county".isNull || trim($"area_new_county")==="",0.0).otherwise($"area_new_county"))
      .withColumn("city_county_area",$"cityarea"-$"all_county_area")
      .withColumn("city_county_ratio",round($"all_county_area"/$"cityarea",6))
      .coalesce(5)

    //logger.error("citydata2分区数2："+citydata2.rdd.partitions.length)
    //logger.error("citydata2_res分区数："+citydata2_res.rdd.partitions.length)

    //选择所需列
    val citydata2_res_cols = spark.sql("""select * from dm_gis.dm_ars_polyarea1_af limit 0""").schema.map(_.name).map(col)
    writeToHiveNoPart(spark, citydata2_res.select(citydata2_res_cols: _*), "dm_gis.dm_ars_polyarea1_af")

    val countydata2_res=countydata2.join(towndata2_total,Seq("joinkey_county"),"left")
      .withColumn("cityname",$"name_c")
      .withColumn("citycode",$"adcode_c")
      .withColumn("countyname",$"name_chn")
      .withColumn("countycode",$"adcode")
      .withColumn("countyarea",when($"area_new".isNull || trim($"area_new")==="",0.0).otherwise($"area_new"))
      .withColumn("all_town_area",when($"area_new_town".isNull || trim($"area_new_town")==="",0.0).otherwise($"area_new_town"))
      .withColumn("county_town_area",$"countyarea"-$"all_town_area")
      .withColumn("county_town_ratio",round($"all_town_area"/$"countyarea",6))
      .coalesce(5)

    //选择所需列
    val countydata2_res_cols = spark.sql("""select * from dm_gis.dm_ars_polyarea2_af limit 0""").schema.map(_.name).map(col)
    writeToHiveNoPart(spark, countydata2_res.select(countydata2_res_cols: _*), "dm_gis.dm_ars_polyarea2_af")

    //选择大于51%的覆盖率为归属
    val citydata_cover=citydata2
      .withColumn("cityname",$"name")
      .withColumn("citycode",$"adcode")
      .withColumn("citywkt",$"wkt_new")
      .withColumn("area_new_city",$"area_new")
      .withColumn("flag",lit("1"))
      .select("cityname","citycode","citywkt","area_new_city","flag")


    val countydata_cover=countydata2
      .withColumn("cityname",$"name_c")
      .withColumn("citycode",$"adcode_c")
      .withColumn("countyname",$"name_chn")
      .withColumn("countycode",$"adcode")
      .withColumn("countywkt",$"wkt_new")
      .withColumn("area_new_county",$"area_new")
      .withColumn("flag",lit("1"))
      .select("cityname","citycode","countyname","countycode","countywkt","area_new_county","flag")


    val towndata_cover=towndata2
      .withColumn("cityname",$"name_c")
      .withColumn("citycode",$"adcode_c")
      .withColumn("countyname",$"name_d")
      .withColumn("countycode",$"adcode_d")
      .withColumn("townname",$"name")
      .withColumn("towncode",$"area_code")
      .withColumn("townwkt",$"wkt_new")
      .withColumn("area_new_town",$"area_new")
      .withColumn("flag",lit("1"))
      .select("cityname","citycode","countyname","countycode","townname","towncode","townwkt","area_new_town","flag")

    //val citydata_cover2=citydata_cover.join(countydata_cover,Seq("cityname","citycode"),"left")
    val citydata_cover2=citydata_cover.join(countydata_cover,Seq("flag"),"left")

    val citydata_cover3= getDfToJson(spark, citydata_cover2,500)
      .map(obj=>{
        val cityname=obj.getString("cityname")
        val citycode=obj.getString("citycode")
        val countyname=obj.getString("countyname")
        val countycode=obj.getString("countycode")
        val citywkt=obj.getString("citywkt")
        val countywkt=obj.getString("countywkt")
        val area_new_city=obj.getString("area_new_city")
        val area_new_county=obj.getString("area_new_county")
        val area_cal=new ArrayBuffer[Double]()
        val citywkt2=citywkt.split(";")
        val countywkt2=countywkt.split(";")
        val s1=citywkt2.length
        val s2=countywkt2.length

        var area_new=0.0

        //判断是否相交，计算重叠面积
        try {
          val reader = new WKTReader
          val peo1a = reader.read(citywkt)
          val peo2a = reader.read(countywkt)
          val isxj = peo1a.intersects(peo2a)
          if (isxj) {
            val peoa = peo1a.intersection(peo2a)
            area_new =getArea(peoa)/1000000
          }
        }
        catch{
          case e: Exception => logger.error("e10:"+e)
        }

        //        val area_new=area_cal.sum/1000000
        val citycoverrate=(area_new/area_new_county.toDouble).formatted("%.4f").toString

        (cityname,citycode,countyname,countycode,area_new_city,area_new_county,area_new.formatted("%.4f"),citycoverrate)
      }).toDF ("cityname","citycode","countyname","countycode","area_new_city","area_new_county","area_new","citycoverrate")
      .filter($"citycoverrate".cast("double")>0.51)
    //.coalesce(5)

    logger.error("开始计算citydata_cover3_cols：")
    //选择所需列
    val citydata_cover3_cols = spark.sql("""select * from dm_gis.dm_ars_polyarea4_af limit 0""").schema.map(_.name).map(col)
    writeToHiveNoPart(spark, citydata_cover3.select(citydata_cover3_cols: _*), "dm_gis.dm_ars_polyarea4_af")

    logger.error("citydata_cover3分区数："+citydata_cover3.rdd.partitions.length)
    // logger.error("citydata_cover3数据量："+citydata_cover3.count())

    //val countydata_cover2=countydata_cover.join(towndata_cover,Seq("cityname","citycode","countyname","countycode"),"left")

    logger.error("开始计算countydata_cover2：")
    val countydata_cover2=towndata_cover.repartition(1000).join(countydata_cover,Seq("flag"),"left")

    logger.error("countydata_cover2分区数："+countydata_cover2.rdd.partitions.length)

    logger.error("开始计算countydata_cover3：")
    val countydata_cover3= getDfToJson2(spark, countydata_cover2)
      .map(obj=>{
        val cityname=obj.getString("cityname")
        val citycode=obj.getString("citycode")
        val countyname=obj.getString("countyname")
        val countycode=obj.getString("countycode")
        val townname=obj.getString("townname")
        val towncode=obj.getString("towncode")
        val countywkt=obj.getString("countywkt")
        val townwkt=obj.getString("townwkt")
        val area_new_county=obj.getString("area_new_county")
        val area_new_town=obj.getString("area_new_town")
        val area_cal=new ArrayBuffer[Double]()
        val townwkt2=townwkt.split(";")
        val countywkt2=countywkt.split(";")
        val s1=townwkt2.length
        val s2=countywkt2.length

        var area_new=0.0
        //判断是否相交，计算重叠面积
        try {
          val reader = new WKTReader
          val peo1a = reader.read(townwkt)
          val peo2a = reader.read(countywkt)
          val isxj = peo1a.intersects(peo2a)
          if (isxj) {
            val peoa = peo1a.intersection(peo2a)
            area_new =getArea(peoa)/1000000
          }
        }
        catch{
          case e: Exception => logger.error("e10:"+e)
        }

        val countycoverrate=(area_new/area_new_town.toDouble).formatted("%.4f").toString
        (cityname,citycode,countyname,countycode,townname,towncode,countycoverrate)
      }).toDF ("cityname","citycode","countyname","countycode","townname","towncode","countycoverrate")
      .filter($"countycoverrate".cast("double")>0.51)

    //logger.error("countydata_cover3数据量："+countydata_cover3.count())
    logger.error("开始计算citydata_cover4：")
    val citydata_cover4=citydata_cover3.join(countydata_cover3,Seq("cityname","citycode","countyname","countycode"),"left")
      .withColumn("cityname_all",$"cityname")
      .withColumn("citycode_all",$"citycode")
      .withColumn("countyname_all",$"countyname")
      .withColumn("countycode_all",$"countycode")
      .withColumn("townname_all",$"townname")
      .withColumn("towncode_all",$"towncode")
      .select(
        "cityname_all","citycode_all","countyname_all","countycode_all","townname_all","towncode_all",
        "citycoverrate","countycoverrate")
      .withColumn("flag1",lit("1"))

    logger.error("开始计算xzqh_pcct：")
    val xzqh_pcct=spark.sql("select * from dm_gis.dm_csv_ars_polyarea3_af where p_code !='省编码'")
      .withColumn("cityname_all",$"city_name")
      .withColumn("citycode_all",$"city_code")
      .withColumn("countyname_all",$"county_name")
      .withColumn("countycode_all",$"county_code")
      .withColumn("townname_all",$"town_name")
      .withColumn("towncode_all",$"town_code")
      .withColumn("citycoverrate",lit(""))
      .withColumn("countycoverrate",lit(""))
      .select("cityname_all","citycode_all","countyname_all","countycode_all","townname_all","towncode_all","citycoverrate","countycoverrate")
      .withColumn("flag2",lit("2"))

    //logger.error("xzqh_pcct数据量："+xzqh_pcct.count())
    logger.error("开始计算all_data：")
    val all_data=citydata_cover4.drop("flag1").union(xzqh_pcct.drop("flag2"))
      .join(citydata_cover4.drop("citycoverrate","countycoverrate"),Seq("cityname_all","citycode_all","countyname_all","countycode_all","townname_all","towncode_all"),"left")
      .join(xzqh_pcct.drop("citycoverrate","countycoverrate"),Seq("cityname_all","citycode_all","countyname_all","countycode_all","townname_all","towncode_all"),"left")
      .withColumn("new_cityname", when($"flag1"==="1" ,$"cityname_all").otherwise(""))
      .withColumn("new_citycode",when($"flag1"==="1" ,$"citycode_all").otherwise(""))
      .withColumn("new_countyname",when($"flag1"==="1" ,$"countyname_all").otherwise(""))
      .withColumn("new_countycode",when($"flag1"==="1" ,$"countycode_all").otherwise(""))
      .withColumn("new_townname",when($"flag1"==="1" ,$"townname_all").otherwise(""))
      .withColumn("new_towncode",when($"flag1"==="1" ,$"towncode_all").otherwise(""))
      .withColumn("cityname", when($"flag2"==="2" ,$"cityname_all").otherwise(""))
      .withColumn("citycode",when($"flag2"==="2" ,$"citycode_all").otherwise(""))
      .withColumn("countyname",when($"flag2"==="2" ,$"countyname_all").otherwise(""))
      .withColumn("countycode",when($"flag2"==="2" ,$"countycode_all").otherwise(""))
      .withColumn("townname",when($"flag2"==="2" ,$"townname_all").otherwise(""))
      .withColumn("towncode",when($"flag2"==="2" ,$"towncode_all").otherwise(""))
      .withColumn("contrast",when($"flag1"==="1" && $"flag2"==="2","1").otherwise("0"))

    //.coalesce(5)
    logger.error("开始计算all_data_cols：")
    //选择所需列
    val all_data_cols = spark.sql("""select * from dm_gis.dm_ars_polyarea3_af limit 0""").schema.map(_.name).map(col)
    writeToHiveNoPart(spark, all_data.select(all_data_cols: _*), "dm_gis.dm_ars_polyarea3_af")

  }

  //无分区转换rdd
  def getDfToJson2( spark:SparkSession,sourDf:DataFrame) ={
    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    })

    sourRdd
  }




  case class city_tb(
                      wkt:String,
                      adcode:String,
                      name:String,
                      adcode_p:String,
                      name_p:String,
                      citycode:String,
                      name_en:String,
                      name_cht:String,
                      name_p_en:String,
                      name_p_cht:String,
                      wkt_new:String,
                      area_new:String
                    )

  case class county_tb(
                        wkt	:String,
                        adcode	:String,
                        name_chn	:String,
                        name_eng	:String,
                        citycode	:String,
                        station	:String,
                        population	:String,
                        postcode	:String,
                        area	:String,
                        adcode_p	:String,
                        name_p	:String,
                        adcode_c	:String,
                        name_c	:String,
                        adcode_d	:String,
                        name_d	:String,
                        level_xzqh	:String,
                        descr	:String,
                        changedesc	:String,
                        name_als	:String,
                        adcode_als	:String,
                        update_t	:String,
                        sourcetime	:String,
                        productor	:String,
                        upd_date	:String,
                        brief	:String,
                        name_r	:String,
                        typea	:String,
                        priority	:String,
                        centerx	:String,
                        centery	:String,
                        sys_id	:String,
                        flag	:String,
                        name_en	:String,
                        name_cht	:String,
                        name_p_en	:String,
                        name_p_cht	:String,
                        name_c_en	:String,
                        name_c_cht	:String,
                        name_d_en	:String,
                        name_d_cht	:String,
                        wkt_new	:String,
                        area_new :String

                      )

  case class alltown_tb(
                         wkt	:String,
                         area_code	:String,
                         citycode	:String,
                         name	:String,
                         adcode_p	:String,
                         name_p	:String,
                         adcode_c	:String,
                         name_c	:String,
                         adcode_d	:String,
                         name_d	:String,
                         flag	:String,
                         name_en	:String,
                         name_cht	:String,
                         name_p_en	:String,
                         name_p_cht	:String,
                         name_c_en	:String,
                         name_c_cht	:String,
                         name_d_en	:String,
                         name_d_cht	:String,
                         wkt_new	:String,
                         area_new	:String
                       )
}
