package com.sf.gis.scala.ars.app;


import com.vividsolutions.jts.geom.*;

public class Jtstool {
    public static void main(String[] args) {
//        System.out.println("sss");
//        System.out.println(getCoordinate(108.48552703857419 ,31.439684859491592)[0]);
//        System.out.println(getCoordinate(108.48552703857419 ,31.439684859491592)[1]);
    }

    public static double getArea(Geometry geometry) {
        double radius = 6371008.8D;
        double area = 0.0D;
        if (geometry instanceof Polygon) {
            Polygon polygon = (Polygon)geometry;
            LineString lineString = polygon.getExteriorRing();
            area += Math.abs(getAreaInternal(lineString.getCoordinates(), radius));

            for(int i = 0; i < polygon.getNumInteriorRing(); ++i) {
                lineString = polygon.getInteriorRingN(i);
                area -= Math.abs(getAreaInternal(lineString.getCoordinates(), radius));
            }
        } else {
            int i;
            int len;
            Geometry geom;
            if (geometry instanceof MultiPolygon) {
                MultiPolygon polygon = (MultiPolygon)geometry;
                len = polygon.getNumGeometries();
                geom = null;

                for(i = 0; i < len; ++i) {
                    geom = polygon.getGeometryN(i);
                    area += getArea(geom);
                }
            } else if (geometry instanceof GeometryCollection) {
                GeometryCollection geometryCollection = (GeometryCollection)geometry;
                len = geometryCollection.getNumGeometries();
                geom = null;

                for(i = 0; i < len; ++i) {
                    geom = geometryCollection.getGeometryN(i);
                    area += getArea(geom);
                }
            }
        }

        return area;
    }

    public static double getAreaInternal(Coordinate[] coordinates, Double radius) {
        double area = 0.0D;
        int len = coordinates.length;
        double x1 = coordinates[len - 1].x;
        double y1 = coordinates[len - 1].y;
        Coordinate[] var9 = coordinates;
        int var10 = coordinates.length;

        for(int var11 = 0; var11 < var10; ++var11) {
            Coordinate coordinate = var9[var11];
            double x2 = coordinate.x;
            double y2 = coordinate.y;
            area += Math.toRadians(x2 - x1) * (2.0D + Math.sin(Math.toRadians(y1)) + Math.sin(Math.toRadians(y2)));
            x1 = x2;
            y1 = y2;
        }

        return area * radius * radius / 2.0D;
    }

}
