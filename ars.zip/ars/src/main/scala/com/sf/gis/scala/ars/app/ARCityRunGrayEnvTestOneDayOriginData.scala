package com.sf.gis.scala.ars.app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession;

/**
 * @ProductManager:01425247 段嫦慧
 * @Author: 01374443
 * @CreateTime: 2023-09-16
 * @TaskId:1024
 * @TaskName: 地址可达-灰度测试
 * @Description: 准备测试数据
 * @最新修改记录(线上的包如果比这个旧，请重新打包更新)：20230916,
 */

object ARCityRunGrayEnvTestOneDayOriginData {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    //    val origincity = "Hong Kong"
    //    val city = URLEncoder.encode(origincity, "utf-8")
    //    val originaddre = "5 Tai Hang Rd 34G, Block 1, Illumination Terrace"
    //    val address = URLEncoder.encode(originaddre, "utf-8")
    //    val url =String.format("http://gis-int.int.sfdc.com.cn:1080/ar/api?province=%s&city=%s&district=%s&address=%s&extention=0&opt=&ak=%s","",origincity,"",originaddre,"af5938935293445084a6b7ba8cd23a4c")
    //    val url_new = String.format("http://gis-int.int.sfdc.com.cn:1080/ar/api?province=%s&city=%s&district=%s&address=%s&extention=0&opt=&ak=%s","",city,"",address,"af5938935293445084a6b7ba8cd23a4c")
    //    println(HttpUtils.urlConnectionGetJson(url_new, 10000))
    //    println("")
    //    val city1 = URLEncoder.encode(origincity, "utf-8").replaceAll("\\+","%20")
    //    val address1 = URLEncoder.encode(originaddre, "utf-8").replaceAll("\\+","%20")
    //    val url_new1 = String.format("http://gis-int.int.sfdc.com.cn:1080/ar/api?province=%s&city=%s&district=%s&address=%s&extention=0&opt=&ak=%s","",city1,"",address1,"af5938935293445084a6b7ba8cd23a4c")
    //    println(url_new1)
    //    println("")
    //    println(HttpUtils.urlConnectionGetJson(url_new1, 10000))
    //    println(HttpUtils.urlConnectionGetJson(url, 10000))
    //
    //
    //    return
    var stepFlag=1
    if(args.length>1){
      stepFlag = args(1).toInt
    }
    start(incDay,stepFlag)
  }


  def parseLog(sparkSession: SparkSession, incDay: String): Unit = {
    val sql = s"insert overwrite  table dm_gis.bee_logs_gis_ar_parse partition(inc_day,pid) " +
      "select  " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.sn'),'')sn, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.ak'),'') ak, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.province'), '') province," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.city'),'')city," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.district'),'') district, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.address'),'')  address," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.city_code'),'') pre_city_code," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.province'),'')pre_province," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.city'),'')pre_city," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.county'),'')pre_county," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.town'),'')pre_town," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.village'),'')pre_village, " +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.district.detailinfo'),'')pre_detailinfo, " +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.source'),'') pre_source," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.src'),'') pre_src," +
      " nvl(get_json_object(get_json_object(log,'$.message'), '$.data.result.result'),'') pre_result, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.url.order_no'),'') order_no, " +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_addr'),'') pre_detail_addr," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_level'),'') pre_detail_level," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_addr_special'),'') pre_detail_addr_special," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_type'),'') pre_detail_type," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.town_only'),'') pre_town_only," +
      " nvl(get_json_object(get_json_object(log,'$.message'),'$.data.result.splite_result_iad'),'') pre_splite_result_iad," +
      " inc_day,   cast(rand()*8 as int ) as pid  from dm_gis.bee_logs_gis_ar_collect " +
      s"  where inc_day='${incDay}' " +
      " and  get_json_object(get_json_object(log,'$.message'),'$.type')='url_e'  " +
      " and get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'), '$.ak')<>'af5938935293445084a6b7ba8cd23a4c'"
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def groupData(sparkSession: SparkSession, incDay: String): Unit = {
    val sql = s"insert overwrite  table dm_gis.ar_gray_test_address_no_repeat partition(inc_day,pid) " +
      s" select province,city,district,address,inc_day,cast(rand()*8 as int ) as pid from dm_gis.bee_logs_gis_ar_parse where inc_day='${incDay}'" +
      s" group by province,city,district,address,inc_day"
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def start(incDay: String,stepFlag:Int): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    if(stepFlag==1){
      logger.error("提取日志数据入解析表")
      parseLog(sparkSession, incDay)
    }
    logger.error("按照省市区地址排重，写表")
    groupData(sparkSession, incDay)
    logger.error("处理完成")
  }
}
