package com.sf.gis.scala.ars.app

import java.sql.Connection
import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSON
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DbUtil
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/** *
 * 郭振未
 * 地址可达日志解析
 * 迁移新集群
 * 韩笑
 */
object LogOfflineAddressReachableMS {
  @transient lazy val logger: Logger = Logger.getLogger(LogOfflineAddressReachableMS.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val respStatTableName = "RESP_STAT"
  val reqStatTableName = "REQ_STAT"
  val reqStatDetailTableName = "REQ_STAT_DETAIL"
  val akTableName = "AK"

  case class LogResp(ak: String, tp: String, stat_type: String, stat_detail: String, req_cnt: Int, req_reachable: Int, req_unreachable: Int, req_addrdetail: Int, req_addrundetail: Int, req_other: Int, citycover: Int, cityuncover_addrdetail: Int, cityuncover_addrundetail: Int, addr_detail: Int, addr_undetail: Int)

  case class LogAr(ymdhm: String, datatype: String, sn: String, ak: String, src: String, tp: String, tm: Int, status: Int, result: String, prov: String, city: String, err: String, msg: String, cityret: String, detail: String, detail_type: String)

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    logger.error("incDay:" + incDay)
    start(incDay)
    logger.error("end")
  }

  def processRespStat(d: ((String, String, String, String), Iterable[LogAr]), status: Int, stype: String) = {
    val key = d._1
    val row = d._2
    val ymdhm = key._1
    val ak = key._2.replaceAll("未知", "-")
    val tp = key._3.replaceAll("未知", "-")
    val stat_type = if (status == 0) {
      if (stype == "src") "0-SRC" else if (stype == "detail") "0-ADDRTYPE" else "-"
    } else {
      "1"
    }
    val stat_detail = key._4.replaceAll("未知", "-")
    val req_cnt = row.size
    val req_reachable = row.filter(_.result == "1").size
    val req_unreachable = row.filter(_.result == "2").size
    val req_addrdetail = row.filter(d => d.result == "3" && d.detail == "0" && d.detail_type.toUpperCase != "GEO_MATCH_NOK" && d.detail_type.toUpperCase != "GEO_MATCH_ZERO").size
    val req_addrundetail = row.filter(d => d.result == "3" && d.detail != "0").size
    val req_other = req_cnt - req_reachable - req_unreachable - req_addrdetail - req_addrundetail
    val citycover = row.filter(_.cityret == "city有返回").size
    val cityuncover_addrdetail = row.filter(d => d.cityret == "city无返回" && d.detail == "0" && d.detail_type.toUpperCase != "GEO_MATCH_NOK" && d.detail_type.toUpperCase != "GEO_MATCH_ZERO").size
    val cityuncover_addrundetail = row.filter(d => d.cityret == "city无返回" && d.detail != "0" && d.detail_type.toUpperCase != "GEO_MATCH_NOK" && d.detail_type.toUpperCase != "GEO_MATCH_ZERO").size
    val addr_detail = row.filter(d => d.detail == "0" && d.detail_type.toUpperCase != "GEO_MATCH_NOK" && d.detail_type.toUpperCase != "GEO_MATCH_ZERO").size
    val addr_undetail = row.filter(_.detail != "0").size

    LogResp(ak, tp, stat_type, stat_detail, req_cnt, req_reachable, req_unreachable, req_addrdetail, req_addrundetail, req_other, citycover, cityuncover_addrdetail, cityuncover_addrundetail, addr_detail, addr_undetail)
  }

  def processRespSum(d: ((String, String, String, String), Iterable[LogResp]), dayid: String, total: Long) = {
    val key = d._1
    val row = d._2
    var ak = key._1
    if ("_".equals(ak)) {
      ak = "-"
    }

    var tp = key._2
    if ("_".equals(tp)) {
      tp = "-"
    }
    val stat_type = key._3
    val stat_detail = key._4
    val req_cnt = row.map(_.req_cnt).sum
    val req_reachable = row.map(_.req_reachable).sum
    val req_unreachable = row.map(_.req_unreachable).sum
    val req_addrdetail = row.map(_.req_addrdetail).sum
    val req_addrundetail = row.map(_.req_addrundetail).sum
    val req_other = row.map(_.req_other).sum
    val citycover = row.map(_.citycover).sum
    val cityuncover_addrdetail = row.map(_.cityuncover_addrdetail).sum
    val cityuncover_addrundetail = row.map(_.cityuncover_addrundetail).sum
    val addr_detail = row.map(_.addr_detail).sum
    val addr_undetail = row.map(_.addr_undetail).sum

    val id = MD5Util.getMD5(dayid + ak + tp + stat_type + stat_detail)
    val now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime())
    Array(id, dayid, ak, tp, stat_type, stat_detail, total.toString,
      req_cnt.toString, req_reachable.toString, req_unreachable.toString, req_addrdetail.toString,
      req_addrundetail.toString, req_other.toString, citycover.toString, cityuncover_addrdetail.toString,
      cityuncover_addrundetail.toString, addr_detail.toString, addr_undetail.toString)
  }

  def fixnull(ak: String) = {
    if (ak == null || ak.trim == "" || ak.trim.toLowerCase() == "null") "未知" else ak
  }

  def getPara(src: String, pre: String, sub: String = null, extSub: String = "") = {
    if (src.contains(pre)) {
      if (sub == null) {
        val finalSub = ",&" + extSub
        var ak = src.substring(src.indexOf(pre) + pre.length)
        //        ak = if(ak.contains(",")) ak.substring(0,ak.indexOf(",")) else ak
        //        ak = if(ak.contains("&")) ak.substring(0,ak.indexOf("&")) else ak
        finalSub.toCharArray.foreach(c => {
          ak = if (ak.contains(c.toString)) ak.substring(0, ak.indexOf(c.toString)) else ak
        })
        ak
      } else {
        var ak = src.substring(src.indexOf(pre) + pre.length)
        ak = if (ak.contains(sub)) ak.substring(0, ak.indexOf(sub)) else ak
        ak
      }
    } else {
      ""
    }
  }

  def fixAddress(str: String) = {
    if (str == null) null else {
      str.replaceAll(s"""[\\\\,\t\r\n'\" (null)(NULL)]""", "")
    }
  }

  def parseLogAr(d: String, b_city_prov: Broadcast[Map[String, String]]) = {
    val jsonStart = s""""message":""""
    if (d.indexOf(jsonStart) != -1) {
      //val str = d.substring(d.indexOf("#{\"")+1)
      val str = JSON.parseObject(d).getString("message")

      val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
      val sdf2: SimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm")
      try {

        val json = JSON.parseObject(JSON.parse(str).toString)
        val ymdhm = sdf2.format(sdf.parse(json.getString("dateTime")).getTime)
        val datatype = json.getString("type")
        val sn = json.getString("sn")
        val urlobj = json.getJSONObject("url")
        val tp = fixnull(urlobj.getString("datatype"))
        var ak = if (datatype != "url_e") {
          fixnull(urlobj.getString("ak"))
        } else {
          val t = urlobj.getString("url")
          if (t.indexOf("ak=") == -1) {
            fixnull(null)
          } else
            fixnull(getPara(t, "ak=", null, "?%"))
        }
        ak = fixAddress(ak)
        val tm = json.getIntValue("time")
        val data = json.getJSONObject("data")
        val missData = data.toJSONString == "{}"
        var status = 0
        var src = fixnull(null)
        var result = fixnull(null)
        var city = fixnull(null)
        var cityret = fixnull(null)
        var prov = fixnull(null)
        var err = fixnull(null)
        var msg = fixnull(null)
        var detail = fixnull(null)
        var detail_type = fixnull(null)

        if (!missData) {
          status = data.getIntValue("status")
          val resultobj = data.getJSONObject("result")
          if (resultobj.getString("ak") != null) ak = resultobj.getString("ak")
          src = fixnull(data.getString("src"))
          result = fixnull(if (status == 0) resultobj.getString("result") else "-1")
          city = fixnull(if (status == 0) resultobj.getString("city_code") else "未知")
          cityret = if (city == "未知") "city无返回" else "city有返回"
          prov = fixnull(if (city != null) b_city_prov.value.getOrElse(city, city) else "未知")
          err = if (status == 1) resultobj.getString("err") else "无"
          msg = if (status == 1) resultobj.getString("msg") else "无"
          detail = fixnull(resultobj.getString("detail_addr"))
          detail_type = fixnull(resultobj.getString("detail_type"))
        }
        LogAr(ymdhm, datatype, sn, ak, src, tp, tm, status, result, prov, city, err, msg, cityret, detail, detail_type)
      } catch {
        case e: Exception => {
          System.err.println(str)
          System.err.println(e.getMessage)
          e.printStackTrace()
          null
        }
      }
    }
    else {
      null
    }
  }

  def queryCityProv(sparkSession: SparkSession) = {
    val city_prov = sparkSession.sparkContext.textFile("/dolphinscheduler/gisbdp/resources/city_prov.csv").filter(d => d != null && d.trim.length > 1).map(d => {
      val t = d.split(",")
      (t(0), t(1))
    }).collect().toMap
    sparkSession.sparkContext.broadcast(city_prov)
  }

  def queryLogEnd(sparkSession: SparkSession, incDay: String, cityProvBc: Broadcast[Map[String, String]]) = {
    val queryArLogSql = s" select log from dm_gis.bee_logs_gis_ar_collect where inc_day='${incDay}' " +
      s" and log is not null and log like '%url_e%' "
    val logEnd = sparkSession.sql(queryArLogSql).rdd.repartition(3200)
      .map(obj => {
        parseLogAr(obj.getString(0), cityProvBc)
      }).filter(d => d != null && d.ymdhm.indexOf(incDay) == 0).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val endcnt = logEnd.count()
    logger.error("endCnt:" + endcnt)
    (logEnd, endcnt)
  }

  def initConnection() = {
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_ars?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull"
    val uid = "gis_oms_ars"
    val pwd = "gis_oms_ars@123@"
    val connection = DbUtil.getConnection(driver, url, uid, pwd)
    connection
  }

  def parseLogRespStat(connection: Connection, logEnd: RDD[LogAr], incDay: String,
                       endcnt: Int) = {
    val a = logEnd.filter(_.status == 0).groupBy(d => (d.ymdhm, d.ak, d.tp, d.src))
      .map(d => processRespStat(d, 0, "src"))
      .groupBy(d => (d.ak, d.tp, d.stat_type, d.stat_detail))
      .map(d => processRespSum(d, incDay, endcnt))
    val b = logEnd.filter(_.status == 0).groupBy(d => (d.ymdhm, d.ak, d.tp, d.detail_type))
      .map(d => processRespStat(d, 0, "detail"))
      .groupBy(d => (d.ak, d.tp, d.stat_type, d.stat_detail))
      .map(d => processRespSum(d, incDay, endcnt))
    val c = logEnd.filter(_.status == 1).groupBy(d => (d.ymdhm, d.ak, d.tp, d.err))
      .map(d => processRespStat(d, 1, "err"))
      .groupBy(d => (d.ak, d.tp, d.stat_type, d.stat_detail))
      .map(d => processRespSum(d, incDay, endcnt))
    val respStatData = a.union(b).union(c).filter(obj => {
      obj(3).length <= 3 && obj(5).length <= 40
    }).collect()
    logger.error("RESP_STAT数量：" + respStatData.length)

    val deleteRespStatSql = s"delete from $respStatTableName where STAT_DATE='$incDay'"
    logger.error(deleteRespStatSql)
    DbUtil.execute(connection, deleteRespStatSql)

    val insertRespStatSql = s"insert into $respStatTableName (ID,STAT_DATE,AK,BUSINESS_TYPE,STAT_TYPE," +
      s"STAT_DETAIL,REQ_TOTAL,REQ_COUNT,REQ_REACHABLE,REQ_UNREACHABLE,REQ_ADDRDETAIL,REQ_ADDRNOTDETAIL," +
      s"REQ_OTHER,CITY_COVERAGE,CITY_ADDRDETAIL,CITY_ADDRNOTDETAIL,ADDR_DETAIL,ADDR_NOTDETAIL) " +
      s"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
    logger.error("写入resp stat数据:" + insertRespStatSql)
    DbUtil.executeBatchSql(connection, insertRespStatSql, respStatData)
  }

  def parseLogReqStat(connection: Connection, logEnd: RDD[LogAr], incDay: String) = {
    //REQ_STAT
    val reqStatRdd = logEnd.groupBy(d => (d.ymdhm, d.ak)).map(d => {
      val ak = d._1._2.replaceAll("未知", "-")
      val req = d._2.toIndexedSeq
      val tm = req.map(_.tm).filter(_ > 0).sortBy(d => d)
      val rsp = if (tm.size == 0) 0 else Math.floor(tm.sum.toDouble / tm.size.toDouble).toInt
      val p99 = if (tm.size == 0) 0 else tm(Math.floor(tm.size * 0.99).toInt)
      val p95 = if (tm.size == 0) 0 else tm(Math.floor(tm.size * 0.95).toInt)
      val tm50 = if (tm.size == 0) 0 else tm.filter(d => d > 50 && d <= 200).size
      val tm200 = if (tm.size == 0) 0 else tm.filter(d => d > 200 && d <= 500).size
      val tm500 = if (tm.size == 0) 0 else tm.filter(d => d > 500).size
      (ak, (req.size, rsp, p99, p95, tm50, tm200, tm500))
    }).groupByKey().map(d => {
      val ak = d._1
      val r = d._2.toIndexedSeq
      val t = r.map(_._1)
      val rsp = r.map(_._2)
      val ptm99 = r.map(_._3)
      val ptm95 = r.map(_._4)
      val tm50 = r.map(_._5).max
      val tm200 = r.map(_._6).max
      val tm500 = r.map(_._7).max
      val reqmax = t.max
      val reqavg = if (t.size == 0) 0 else Math.floor(t.sum.toDouble / t.size.toDouble).toInt
      val reqmin = t.min

      val rspmax = rsp.max
      val rspavg = if (rsp.size == 0) 0 else Math.floor(rsp.sum.toDouble / rsp.size.toDouble).toInt
      val rspmin = rsp.min

      val p99max = ptm99.max
      val p99avg = if (ptm99.size == 0) 0 else Math.floor(ptm99.sum.toDouble / ptm99.size.toDouble).toInt
      val p99min = ptm99.min

      val p95max = ptm95.max
      val p95avg = if (ptm95.size == 0) 0 else Math.floor(ptm95.sum.toDouble / ptm95.size.toDouble).toInt
      val p95min = ptm95.min

      Array(MD5Util.getMD5(incDay + ak), incDay, ak, reqmax.toString,
        reqavg.toString, reqmin.toString, rspmax.toString, rspavg.toString, rspmin.toString, p99max.toString,
        p99avg.toString, p99min.toString, p95max.toString, p95avg.toString, p95min.toString, tm50.toString,
        tm200.toString, tm500.toString)
    }).union(logEnd.groupBy(d => d.ymdhm).map(d => {
      val ak = "all"
      val req = d._2.toIndexedSeq
      val tm = req.map(_.tm).filter(_ > 0).sortBy(d => d)
      val rsp = if (tm.size == 0) 0 else Math.floor(tm.sum.toDouble / tm.size.toDouble).toInt
      val p99 = if (tm.size == 0) 0 else tm(Math.floor(tm.size * 0.99).toInt)
      val p95 = if (tm.size == 0) 0 else tm(Math.floor(tm.size * 0.95).toInt)
      val tm50 = if (tm.size == 0) 0 else tm.filter(d => d > 50 && d <= 200).size
      val tm200 = if (tm.size == 0) 0 else tm.filter(d => d > 200 && d <= 500).size
      val tm500 = if (tm.size == 0) 0 else tm.filter(d => d > 500).size
      (ak, (req.size, rsp, p99, p95, tm50, tm200, tm500))
    }).groupByKey().map(d => {
      val ak = d._1
      val r = d._2.toIndexedSeq
      val t = r.map(_._1)
      val rsp = r.map(_._2)
      val ptm99 = r.map(_._3)
      val ptm95 = r.map(_._4)
      val tm50 = r.map(_._5).max
      val tm200 = r.map(_._6).max
      val tm500 = r.map(_._7).max

      val reqmax = t.max
      val reqavg = if (t.size == 0) 0 else Math.floor(t.sum.toDouble / t.size.toDouble).toInt
      val reqmin = t.min

      val rspmax = rsp.max
      val rspavg = if (rsp.size == 0) 0 else Math.floor(rsp.sum.toDouble / rsp.size.toDouble).toInt
      val rspmin = rsp.min

      val p99max = ptm99.max
      val p99avg = if (ptm99.size == 0) 0 else Math.floor(ptm99.sum.toDouble / ptm99.size.toDouble).toInt
      val p99min = ptm99.min

      val p95max = ptm95.max
      val p95avg = if (ptm95.size == 0) 0 else Math.floor(ptm95.sum.toDouble / ptm95.size.toDouble).toInt
      val p95min = ptm95.min

      val now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime())
      Array(MD5Util.getMD5(incDay + ak), incDay, ak, reqmax.toString, reqavg.toString, reqmin.toString,
        rspmax.toString, rspavg.toString, rspmin.toString, p99max.toString, p99avg.toString, p99min.toString,
        p95max.toString, p95avg.toString, p95min.toString, tm50.toString, tm200.toString, tm500.toString)
    })).collect()
    logger.error("req stat 数量:" + reqStatRdd.length)
    val deleteReqStatSql = s"delete from $reqStatTableName where STAT_DATE='$incDay'"
    logger.error(deleteReqStatSql)
    DbUtil.execute(connection, deleteReqStatSql)

    val insertReqStatSql = s"insert into $reqStatTableName (ID,STAT_DATE,AK,REQ_MAX,REQ_AVG,REQ_MIN," +
      s"RESP_TIME_MAX,RESP_TIME_AVG,RESP_TIME_MIN,RESP_TIME_99MAX,RESP_TIME_99AVG,RESP_TIME_99MIN," +
      s"RESP_TIME_95MAX,RESP_TIME_95AVG,RESP_TIME_95MIN,RESP_OT_50,RESP_OT_200,RESP_OT_500) " +
      s"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
    logger.error("写入req stat数据:" + insertReqStatSql)
    DbUtil.executeBatchSql(connection, insertReqStatSql, reqStatRdd)

  }

  def parseLogReqStatDetail(connection: Connection, logEnd: RDD[LogAr], incDay: String) = {
    //REQ_STAT_DETAIL
    val reqStatDetail = logEnd.groupBy(d => (d.ymdhm, d.ak)).map(d => {
      val ymdhm = d._1._1
      val ak = d._1._2.replaceAll("未知", "-")
      val req = d._2.toIndexedSeq
      val tm = req.map(_.tm).filter(_ > 0).sortBy(d => d)
      val rsp = if (tm.size == 0) 0 else Math.floor(tm.sum.toDouble / tm.size.toDouble).toInt
      val p99 = if (tm.size == 0) 0 else tm(Math.floor(tm.size * 0.99).toInt)
      val p95 = if (tm.size == 0) 0 else tm(Math.floor(tm.size * 0.95).toInt)
      val tm50 = if (tm.size == 0) 0 else tm.filter(d => d > 50 && d <= 200).size
      val tm200 = if (tm.size == 0) 0 else tm.filter(d => d > 200 && d <= 500).size
      val tm500 = if (tm.size == 0) 0 else tm.filter(d => d > 500).size
      Array(MD5Util.getMD5(ymdhm + ak), ymdhm, ak, req.size.toString, rsp.toString, p99.toString, p95.toString,
        tm50.toString, tm200.toString, tm500.toString, incDay)
    }).union(logEnd.groupBy(d => (d.ymdhm)).map(d => {
      val ymdhm = d._1
      val ak = "ALL"
      val req = d._2.toIndexedSeq
      val tm = req.map(_.tm).filter(_ > 0).sortBy(d => d)
      val rsp = if (tm.size == 0) 0 else Math.floor(tm.sum.toDouble / tm.size.toDouble).toInt
      val p99 = if (tm.size == 0) 0 else tm(Math.floor(tm.size * 0.99).toInt)
      val p95 = if (tm.size == 0) 0 else tm(Math.floor(tm.size * 0.95).toInt)
      val tm50 = if (tm.size == 0) 0 else tm.filter(d => d > 50 && d <= 200).size
      val tm200 = if (tm.size == 0) 0 else tm.filter(d => d > 200 && d <= 500).size
      val tm500 = if (tm.size == 0) 0 else tm.filter(d => d > 500).size
      Array(MD5Util.getMD5(ymdhm + ak), ymdhm, ak, req.size.toString, rsp.toString, p99.toString, p95.toString,
        tm50.toString, tm200.toString, tm500.toString, incDay)
    })).collect()
    logger.error("req stat detail 数量:" + reqStatDetail.length)
    val deleteReqStatDetailSql = s"delete from $reqStatDetailTableName where STAT_DATE='$incDay'"
    logger.error(deleteReqStatDetailSql)
    DbUtil.execute(connection, deleteReqStatDetailSql)


    val insertReqStatDetailSql = s"insert into $reqStatDetailTableName (ID,STAT_DATETIME,AK,REQ_COUNT," +
      s"RESP_TIME,RESP_TIME_99,RESP_TIME_95,RESP_OT_50,RESP_OT_200,RESP_OT_500,STAT_DATE) " +
      s"values(?,?,?,?,?,?,?,?,?,?,?) "
    logger.error("写入req stat detail数据:" + insertReqStatDetailSql)
    DbUtil.executeBatchSql(connection, insertReqStatDetailSql, reqStatDetail)
  }

  def insertIntoAk(connection: Connection, incDay: String): Unit = {
    val akSql = s"""insert into `$akTableName`(ID,AK,PROJECT) select md5(concat(a.ak,a.project)),a.ak,a.project from (SELECT distinct case when ak='未知' then '-' else ak end as ak,'ARS' as project FROM $reqStatTableName where STAT_DATE=$incDay) a ON DUPLICATE KEY UPDATE ak=a.ak,project=a.project""".stripMargin
    DbUtil.execute(connection, akSql)
    DbUtil.execute(connection, s"delete from `$akTableName` where length(AK)<4")
    DbUtil.execute(connection, s"DELETE FROM `$akTableName` WHERE LENGTH(AK)>32")
  }

  def start(incDay: String): Unit = {

    System.err.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    System.err.println("即将开始地址可达微服务日志指标离线统计：" + incDay)
    System.err.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    System.err.println("============================================================")
    System.err.println("当前目录：" + System.getProperty("user.dir"))
    System.err.println("============================================================")

    val sparkSession = Spark.getSparkSession(appName)

    val cityProvBc = queryCityProv(sparkSession)
    val (logEnd, endcnt) = queryLogEnd(sparkSession, incDay, cityProvBc)
    val connection = initConnection()
    parseLogRespStat(connection, logEnd, incDay, endcnt.toInt)

    parseLogReqStat(connection, logEnd, incDay)
    parseLogReqStatDetail(connection, logEnd, incDay)
    logEnd.unpersist()
    insertIntoAk(connection, incDay)
  }
}


