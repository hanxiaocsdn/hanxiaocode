package com.sf.gis.scala.ars.app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger;

/**
 * @ProductManager:01425247 段嫦慧
 * @Author: 01374443
 * @CreateTime: 2023-09-12
 * @TaskId:
 * @TaskName: 地址可达-运单地址匹配指定乡镇地址量
 * @Description: 筛单多出街道数据统计命中运单地址情况-一次性任务
 * @最新修改记录(线上的包如果比这个旧，请重新打包更新)：20230915
 */
object TmpWaybillProduct {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {

    val startDay = args(0)
    val endDay = args(1)
    start(startDay, endDay)
  }


  def start(startDay: String, endDay: String): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    //    val cnt = 366
    //    for (i <- 0 until cnt) {
    //      val curDay = DateUtil.getDay(startDay, i, "")
    //      logger.error("curDay:" + curDay)
    val sql = s" insert overwrite table tmp_dm_gis.tmp_01374443_waybill_product partition(inc_day)" +
      s" select cnt, a.product_code, nvl(b.prod_owner_code,'')prod_owner_code,a.inc_day from  (select nvl(product_code,'') product_code,count(1) cnt,inc_day from dwd.dwd_waybill_info_dtl_di " +
      s" where inc_day between '${startDay}' and '${endDay}' group by inc_day,nvl(product_code,'')) a" +
      s" left join (select distinct nvl(prod_code,'') prod_code,prod_owner_code,inc_day from dim.dim_prod_info_df where inc_day between '${startDay}' and '${endDay}') b " +
      s" on a.inc_day=b.inc_day and a.product_code = b.prod_code "
    logger.error(sql)
    sparkSession.sql(sql)
    //      if (curDay.toInt > endDay.toInt) {
    //        logger.error("结束~")
    //        return;
    //      }
    //    }


    logger.error("处理完毕")
  }
}
