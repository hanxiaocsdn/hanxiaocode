package com.sf.gis.scala.ars.app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel;

/**
 * @ProductManager:01425247 段嫦慧
 * @Author: 01374443
 * @CreateTime: 2023-09-16
 * @TaskId: 1061
 * @TaskName: 地址可达-灰度测试
 * @Description: ,按城市输出,前置任务id:1060
 * @最新修改记录(线上的包如果比这个旧，请重新打包更新)：20231123, 用于处理其他数据源
 */

object ARCityRunGrayEnvTestOneDayStaOther {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val arsCfgPath = args(1)
    val grayTableName =args(2)
    val prodTableName = args(3)
    val rateRetTableName = args(4)
    val matchRetTableName = args(5)
    val joinRetTableName = args(6)
    start(incDay, arsCfgPath,grayTableName,prodTableName,rateRetTableName,matchRetTableName,joinRetTableName)
  }

  def groupTotalData(sparkSession: SparkSession, incDay: String,rateRetTableName:String,joinRetTableName:String) = {
    val sql = s" insert overwrite table ${rateRetTableName} partition(inc_day='${incDay}') " +
      s"select address_count,pre_result_1,pre_result_1/address_count pre_result_1_rate," +
      s"result_1,result_1/address_count result_1_rate," +
      s"pre_result_2,pre_result_2/address_count pre_result_2_rate," +
      s"result_2,result_2/address_count result_2_rate," +
      s"pre_result_3,pre_result_3/address_count pre_result_3_rate," +
      s"result_3,result_3/address_count result_3 " +
      s" from ( select sum(address_count) address_count," +
      s"sum(pre_result_1)pre_result_1," +
      s"sum(result_1)result_1," +
      s"sum(pre_result_2)pre_result_2," +
      s"sum(result_2)result_2," +
      s"sum(pre_result_3)pre_result_3," +
      s"sum(result_3)result_3 from(" +
      s" select 1 address_count, " +
      s"if(pre_result='1',1,0) pre_result_1,if(r_result='1',1,0) result_1," +
      s"if(pre_result='2',1,0) pre_result_2,if(r_result='2',1,0) result_2," +
      s"if(pre_result='3',1,0) pre_result_3,if(r_result='3',1,0) result_3 " +
      s" from ${joinRetTableName} where inc_day='${incDay}' ) a)b "
    logger.error(sql)
    sparkSession.sql(sql)
  }


  def queryCfgData(sparkSession: SparkSession, arsCfgPath: String) = {
    //城市编码,省,市,区,乡/镇/街道
    val dataframe = sparkSession.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      //      .option("inferSchema", "true")
      .csv(arsCfgPath)
      //      .csv("hdfs://sfbdp1/user/01374443/upload/ar/ar_town_01425247.csv")
      .toDF("city_code", "province", "city", "district", "town", "village", "tag", "pre_tag", "version")
      .rdd.map(obj => {
      (convertEmpty(obj.getString(0)),
        convertEmpty(obj.getString(1)),
        convertEmpty(obj.getString(2)),
        convertEmpty(obj.getString(3)),
        convertEmpty(obj.getString(4)),
        convertEmpty(obj.getString(5)),
        convertEmpty(obj.getString(6)),
        convertEmpty(obj.getString(7)),
        convertEmpty(obj.getString(8)))
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("装载城镇总数量:" + dataframe.count())
    dataframe.take(1).foreach(obj => {
      logger.error(obj.toString())
    })
    logger.error("构造结果默认值")
    val defaultData = dataframe.map(obj => {
      ((obj._1, obj._2, obj._3, obj._4, obj._5, obj._6), ((0, 0, 0, 0, 0, 0, 0, 0), (obj._7, obj._8, obj._9)))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("构造结果默认值数量:" + defaultData.count())

    logger.error("构造广播")
    val arsCfgMap = dataframe.map(obj => {
      ((obj._1, obj._2, obj._3, obj._4, obj._5, obj._6), (obj._7, obj._8, obj._9))
    }).collectAsMap()

    (sparkSession.sparkContext.broadcast(arsCfgMap), defaultData)
  }

  def convertEmpty(str: String): String = {
    if (str == null) {
      return ""
    }
    return str
  }

  def groupDimData(sparkSession: SparkSession, incDay: String,
                   joinRetTableName:String) = {
    val preSql = s" select pre_city_code,pre_province,pre_city,pre_county,pre_town,pre_village," +
      s" sum(address_count) address_count,sum(pre_result_1)pre_result_1," +
      s" sum(pre_result_2)pre_result_2,sum(pre_result_3)pre_result_3 from " +
      s" (select nvl(pre_city_code,'')pre_city_code,nvl(pre_province,'')pre_province,nvl(pre_city,'')pre_city," +
      s" nvl(pre_county,'')pre_county,nvl(pre_town,'')pre_town,nvl(pre_village,'')pre_village, 1 address_count, " +
      s" if(pre_result='1',1,0) pre_result_1," +
      s" if(pre_result='2',1,0) pre_result_2," +
      s" if(pre_result='3',1,0) pre_result_3 " +
      s" from ${joinRetTableName} where inc_day='${incDay}' ) a " +
      s" group by pre_city_code,pre_province,pre_city,pre_county,pre_town,pre_village"
    logger.error(preSql)
    val preDataRdd = sparkSession.sql(preSql).rdd.map(obj => {
      ((obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4), obj.getString(5)),
        (obj.getLong(6).toInt, obj.getLong(7).toInt, obj.getLong(8).toInt, obj.getLong(9).toInt, 0, 0, 0, 0))
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("preData数量:" + preDataRdd.count())
    preDataRdd.take(1).foreach(obj => {
      logger.error(obj.toString)
    })
    val rSql = s" select r_city_code,r_province,r_city,r_county,r_town,r_village," +
      s" sum(address_count) address_count,sum(r_result_1)r_result_1," +
      s" sum(r_result_2)r_result_2,sum(r_result_3)r_result_3 from " +
      s" (select nvl(r_city_code,'')r_city_code,nvl(r_province,'')r_province,nvl(r_city,'')r_city," +
      s" nvl(r_county,'')r_county,nvl(r_town,'')r_town,nvl(r_village,'')r_village, 1 address_count, " +
      s" if(r_result='1',1,0) r_result_1," +
      s" if(r_result='2',1,0) r_result_2," +
      s" if(r_result='3',1,0) r_result_3" +
      s" from dm_gis.bee_logs_gis_ar_parse_and_run_test_rslt where inc_day='${incDay}' ) a " +
      s" group by r_city_code,r_province,r_city,r_county,r_town,r_village"
    logger.error(rSql)
    val rDataRdd = sparkSession.sql(rSql).rdd.map(obj => {
      ((obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4), obj.getString(5)),
        (0, 0, 0, 0, obj.getLong(6).toInt, obj.getLong(7).toInt, obj.getLong(8).toInt, obj.getLong(9).toInt))
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("preData数量:" + rDataRdd.count())
    rDataRdd.take(1).foreach(obj => {
      logger.error(obj.toString)
    })
    val villageMergeDataRdd = rDataRdd.union(preDataRdd).reduceByKey((obj1, obj2) => {
      (obj1._1 + obj2._1, obj1._2 + obj2._2, obj1._3 + obj2._3, obj1._4 + obj2._4,
        obj1._5 + obj2._5, obj1._6 + obj2._6, obj1._7 + obj2._7, obj1._8 + obj2._8)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("village合并数据量:" + villageMergeDataRdd.count())
    val townMergeDataRdd = villageMergeDataRdd.map(obj => {
      ((obj._1._1, obj._1._2, obj._1._3, obj._1._4, obj._1._5, ""), obj._2)
    }).reduceByKey((obj1, obj2) => {
      (obj1._1 + obj2._1, obj1._2 + obj2._2, obj1._3 + obj2._3, obj1._4 + obj2._4,
        obj1._5 + obj2._5, obj1._6 + obj2._6, obj1._7 + obj2._7, obj1._8 + obj2._8)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("town合并数据量:" + townMergeDataRdd.count())

    val countyMergeDataRdd = townMergeDataRdd.map(obj => {
      ((obj._1._1, obj._1._2, obj._1._3, obj._1._4, "", ""), obj._2)
    }).reduceByKey((obj1, obj2) => {
      (obj1._1 + obj2._1, obj1._2 + obj2._2, obj1._3 + obj2._3, obj1._4 + obj2._4,
        obj1._5 + obj2._5, obj1._6 + obj2._6, obj1._7 + obj2._7, obj1._8 + obj2._8)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("county合并数据量:" + countyMergeDataRdd.count())
    val cityMergeDataRdd = countyMergeDataRdd.map(obj => {
      ((obj._1._1, obj._1._2, obj._1._3, "", "", ""), obj._2)
    }).reduceByKey((obj1, obj2) => {
      (obj1._1 + obj2._1, obj1._2 + obj2._2, obj1._3 + obj2._3, obj1._4 + obj2._4,
        obj1._5 + obj2._5, obj1._6 + obj2._6, obj1._7 + obj2._7, obj1._8 + obj2._8)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("city合并数据量:" + cityMergeDataRdd.count())
    val provinceMergeDataRdd = cityMergeDataRdd.map(obj => {
      (("", obj._1._2, "", "", "", ""), obj._2)
    }).reduceByKey((obj1, obj2) => {
      (obj1._1 + obj2._1, obj1._2 + obj2._2, obj1._3 + obj2._3, obj1._4 + obj2._4,
        obj1._5 + obj2._5, obj1._6 + obj2._6, obj1._7 + obj2._7, obj1._8 + obj2._8)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("province合并数据量:" + provinceMergeDataRdd.count())
    val totalDataRdd = villageMergeDataRdd.filter(obj => {
      !obj._1._6.isEmpty()
    }).union(
      townMergeDataRdd.filter(obj => {
        !obj._1._5.isEmpty()
      }
      )).union(
      countyMergeDataRdd.filter(obj => {
        !obj._1._4.isEmpty()
      }
      )).union(
      cityMergeDataRdd.filter(obj => {
        !obj._1._4.isEmpty()
      }
      )).union(
      provinceMergeDataRdd.filter(obj => {
        !obj._1._3.isEmpty()
      }
      )).map(obj => {
      //打个标签
      (obj._1, (obj._2, ("", "", "")))
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("总数据量:" + totalDataRdd.count())
    Spark.clearPersistWithoutId(sparkSession, totalDataRdd.id)
    totalDataRdd
  }

  def mergeAndSave(sparkSession: SparkSession,
                   groupData: RDD[((String, String, String, String, String, String), ((Int, Int, Int, Int, Int, Int, Int, Int), (String, String, String)))],
                   defaultData: RDD[((String, String, String, String, String, String), ((Int, Int, Int, Int, Int, Int, Int, Int), (String, String, String)))],
                   incDay: String,matchRetTableName:String) = {
    import sparkSession.implicits._
    val tmpViewName = "tmpView"+System.currentTimeMillis()
    val retData = groupData.union(defaultData).reduceByKey((obj1, obj2) => {
      ((obj1._1._1 + obj2._1._1, obj1._1._2 + obj2._1._2, obj1._1._3 + obj2._1._3, obj1._1._4 + obj2._1._4,
        obj1._1._5 + obj2._1._5, obj1._1._6 + obj2._1._6, obj1._1._7 + obj2._1._7, obj1._1._8 + obj2._1._8),
        (obj1._2._1 + obj2._2._1, obj1._2._2 + obj2._2._2, obj1._2._3 + obj2._2._3))
    }).map(obj => {
      (obj._1._1, obj._1._2, obj._1._3, obj._1._4, obj._1._5, obj._1._6,
        obj._2._2._1, obj._2._2._2, obj._2._2._3,
        obj._2._1._1, obj._2._1._2, obj._2._1._3, obj._2._1._4, obj._2._1._5, obj._2._1._6, obj._2._1._7, obj._2._1._8
      )
    }).repartition(1).toDF("city_code", "province", "city", "district", "town", "village", "tag", "pre_tag", "version",
      "pre_total", "pre_result_1", "pre_result_2", "pre_result_3",
      "r_total", "r_result_1", "r_result_2", "r_result_3"
    ).createOrReplaceTempView(tmpViewName)
    val sql = s"insert overwrite table ${matchRetTableName} partition(inc_day='${incDay}') " +
      s" select * from ${tmpViewName}"
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def joinGrayAndProd(sparkSession: SparkSession, grayTableName: String, prodTableName: String, incDay: String, joinRetTableName: String) = {
    val sql = s" insert overwrite table ${joinRetTableName} " +
      s" partition(inc_day='${incDay}') " +
      s" select '' sn,a.province,a.city,a.district,a.address,a.pre_city_code,a.pre_province,a.pre_city,a.pre_county,a.pre_town,a.pre_village,a.pre_detailinfo,a.pre_source,a.pre_src," +
      s" b.r_city_code,b.r_province,b.r_city,b.r_county,b.r_town,b.r_village,b.r_detailinfo,b.r_src,b.myexception,a.pre_result,b.r_result, '' ak,'' order_no," +
      s" b.r_bxy_province,b.r_bxy_city,b.r_bxy_county,b.r_bxy_town,b.r_bxy_village,b.r_bxy_detailinfo," +
      s" a.pre_detail_addr,a.pre_detail_level,a.pre_detail_addr_special,a.pre_detail_type," +
      s" a.pre_town_only,a.pre_splite_result_iad, " +
      s" b.r_detail_addr,b.r_detail_level,b.r_detail_addr_special,b.r_detail_type,b.r_town_only," +
      s" b.r_splite_result_iad " +
      s" from " +
      s" (select province,city,district,address,r_city_code pre_city_code," +
      s" r_province pre_province,r_city pre_city,r_county pre_county,r_town pre_town," +
      s" r_village pre_village,r_detailinfo pre_detailinfo,'' pre_source,r_src pre_src," +
      s" r_detail_addr pre_detail_addr,r_detail_level pre_detail_level,r_detail_addr_special pre_detail_addr_special," +
      s" r_detail_type pre_detail_type,r_town_only pre_town_only,r_splite_result_iad pre_splite_result_iad,r_result pre_result " +
      s" from ${prodTableName} where inc_day='${incDay}') a " +
      s" left join " +
      s" (select * from ${grayTableName} where inc_day='${incDay}') b " +
      s" on a.province=b.province and a.city=b.city and a.district=b.district " +
      s" and a.address=b.address "
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def start(incDay: String, arsCfgPath: String
            , grayTableName: String, prodTableName: String, rateRetTableName: String,
            matchRetTableName: String, joinRetTableName:String): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    logger.error("统计日期：" + incDay)
    logger.error("开始join生产和灰度数据")
    joinGrayAndProd(sparkSession,grayTableName,prodTableName,incDay,joinRetTableName)
    logger.error("按地址聚合指标")
    groupTotalData(sparkSession, incDay,rateRetTableName,joinRetTableName)
    logger.error("按照省市区维度去聚合数据")
    val groupData = groupDimData(sparkSession, incDay,joinRetTableName)
    logger.error("根据配置文件去命中数据")
    val (arsCfgMapBc, defaultData) = queryCfgData(sparkSession, arsCfgPath)
    logger.error("合并默认数据，存表")
    mergeAndSave(sparkSession, groupData, defaultData, incDay,matchRetTableName)
    logger.error("完成")
  }
}
