# -*- coding: utf-8 -*-
import sel_def
import os

if __name__ == '__main__':
    sel_def.remove_file('output/cms_new_output.xlsx')  # 删除文件
    sel_def.remove_file('output/cms_change_output.xlsx')  # 删除文件
    sel_def.remove_file('output/cms_delete_output.xlsx')  # 删除文件
    sel_def.remove_file('output/gis_new_output.xlsx')  # 删除文件
    sel_def.remove_file('output/gis_change_output.xlsx')  # 删除文件
    sel_def.remove_file('output/gis_delete_output.xlsx')  # 删除文件
    sel_def.remove_file('output/region_all_output.xlsx')  # 删除文件
    sel_def.remove_file('output/region_all_output0.xlsx')  # 删除文件
    sel_def.remove_file('output/region_all_output200000.xlsx')  # 删除文件
    sel_def.remove_file('output/region_all_output400000.xlsx')  # 删除文件
    sel_def.remove_file('output/region_all_output600000.xlsx')  # 删除文件

    sel_def.output_xlsx('cms_new_output', 'sheet1')
    sel_def.output_xlsx('cms_change_output', 'sheet1')
    sel_def.output_xlsx('cms_delete_output', 'sheet1')
    sel_def.output_xlsx('gis_new_output', 'sheet1')
    sel_def.output_xlsx('gis_change_output', 'sheet1')
    sel_def.output_xlsx('gis_delete_output', 'sheet1')
    sel_def.output_xlsx2('region_all_output', 'sheet1',0,200000)
    sel_def.output_xlsx2('region_all_output', 'sheet1',200000,200000)
    sel_def.output_xlsx2('region_all_output', 'sheet1', 400000, 200000)
    sel_def.output_xlsx2('region_all_output', 'sheet1', 600000, 200000)





