# -*- coding: utf-8 -*-
import sel_def
import pandas as pd
from sqlalchemy import create_engine, VARCHAR, TEXT
import time

#mysqlinfo='mysql://root:zy123456@127.0.0.1:3306/mywork?charset=utf8'
print('start：' + time.strftime("%Y-%m-%d %H:%M:%S"))
#创建数据库连接
engine=create_engine('mysql+pymysql://root:zy123456@127.0.0.1:3306/mywork?charset=utf8mb4')

#上传全量表
region_all=pd.read_excel("others/Q4全量行政区划数据新版20231228.xlsx",sheet_name="Sheet1",dtype=str)
region_all.to_sql(name='region_all_input',schema='mywork',con=engine,index=False,if_exists='append')

print('time1：' + time.strftime("%Y-%m-%d %H:%M:%S"))
#mysql导入的城市代码可能有问题，需要手动执行sql修改
# SET SQL_SAFE_UPDATES = 0;
# update mywork.region_all_input
# set `城市代码`=lpad(`城市代码`,3,'0')
sql="""
update mywork.region_all_input
set `城市代码`=case when length(`城市代码`)<=3 then lpad(`城市代码`,3,'0') else `城市代码` end
"""
sel_def.Sql_Data(sql)

print('time2：' + time.strftime("%Y-%m-%d %H:%M:%S"))
#上传其他表encoding='utf8',
cms_change_input=pd.read_csv("cms/变更_fill.csv",engine='python',dtype='object')
cms_change_input.to_sql(name='cms_change_input',con=engine,if_exists='append',index=False)

cms_new_input=pd.read_csv("cms/新增_fill.csv",engine='python',dtype='object')
cms_new_input.to_sql(name='cms_new_input',con=engine,if_exists='append',index=False)

cms_delete_input=pd.read_csv("cms/撤销_fill.csv",encoding='utf8',engine='python',dtype='object')
cms_delete_input.to_sql(name='cms_delete_input',con=engine,if_exists='append',index=False)

gis_change_input=pd.read_csv("gis/变更_fill.csv",encoding='utf8',engine='python',dtype='object')
gis_change_input.to_sql(name='gis_change_input',con=engine,if_exists='append',index=False)

gis_new_input=pd.read_csv("gis/新增_fill.csv",encoding='utf8',engine='python',dtype='object')
gis_new_input.to_sql(name='gis_new_input',con=engine,if_exists='append',index=False)

gis_delete_input=pd.read_csv("gis/撤销_fill.csv",encoding='utf8',engine='python',dtype='object')
gis_delete_input.to_sql(name='gis_delete_input',con=engine,if_exists='append',index=False)

city_reflect_input=pd.read_csv("others/city_reflect.csv",engine='python',dtype='object')
city_reflect_input.to_sql(name='city_reflect_input',con=engine,if_exists='append',index=False)

county_reflect_input=pd.read_csv("others/county_reflect.csv",engine='python',dtype='object')
county_reflect_input.to_sql(name='county_reflect_input',con=engine,if_exists='append',index=False)

town_reflect_input=pd.read_csv("others/town_reflect.csv",engine='python',dtype='object')
town_reflect_input.to_sql(name='town_reflect_input',con=engine,if_exists='append',index=False)


sql2="""
update mywork.cms_new_input
set `城市代码`=case when length(`城市代码`)<=3 then lpad(`城市代码`,3,'0') else `城市代码` end
"""
sel_def.Sql_Data(sql2)

sql3="""
update mywork.gis_new_input
set `城市代码`=case when length(`城市代码`)<=3 then lpad(`城市代码`,3,'0') else `城市代码` end
"""
sel_def.Sql_Data(sql3)

sql4="""
update mywork.cms_delete_input
set `城市代码`=case when length(`城市代码`)<=3 then lpad(`城市代码`,3,'0') else `城市代码` end
"""
sel_def.Sql_Data(sql4)

sql5="""
update mywork.gis_delete_input
set `城市代码`=case when length(`城市代码`)<=3 then lpad(`城市代码`,3,'0') else `城市代码` end
"""
sel_def.Sql_Data(sql5)

sql6="""
update mywork.cms_change_input
set `变更前城市代码`=case when length(`变更前城市代码`)<=3 then lpad(`变更前城市代码`,3,'0') else `变更前城市代码` end,
`变更后城市代码`=case when length(`变更后城市代码`)<=3 then lpad(`变更后城市代码`,3,'0') else `变更后城市代码` end
"""
sel_def.Sql_Data(sql6)

sql7="""
update mywork.gis_change_input
set `变更前城市代码`=case when length(`变更前城市代码`)<=3 then lpad(`变更前城市代码`,3,'0') else `变更前城市代码` end,
`变更后城市代码`=case when length(`变更后城市代码`)<=3 then lpad(`变更后城市代码`,3,'0') else `变更后城市代码` end
"""
sel_def.Sql_Data(sql7)

#先清空结果表
sql8=f"""
truncate table cms_new_output;
"""
sel_def.Sql_Data(sql8)

sql8=f"""
truncate table cms_change_output;
"""
sel_def.Sql_Data(sql8)

sql8=f"""
truncate table cms_delete_output;
"""
sel_def.Sql_Data(sql8)

sql8=f"""
truncate table gis_new_output;
"""
sel_def.Sql_Data(sql8)

sql8=f"""
truncate table gis_change_output;
"""
sel_def.Sql_Data(sql8)

sql8=f"""
truncate table gis_delete_output;
"""
sel_def.Sql_Data(sql8)

sql8=f"""
truncate table region_all_output;
"""
sel_def.Sql_Data(sql8)

#将全量表数据写入到新的表，用于更新
sql9="""
insert into mywork.region_all_output
(`省编码`,`省`,`城市代码`,`市编码`,`市`,`区县编码`,`区县`,`乡/镇/街道编码`,`乡/镇/街道`,`村编码`,`村名称`,
`省英文名称`,`省繁体名称`,`市英文名称`,`市繁体名称`,`区县英文名称`,`区县繁体名称`,
`乡/镇/街道英文名称`,`乡/镇/街道繁体名称`,`版本号`,`生效日期`,`标记`)
select `省编码`,`省`,`城市代码`,`市编码`,`市`,`区县编码`,`区县`,`乡/镇/街道编码`,`乡/镇/街道`,`村编码`,`村名称`,
`省英文名称`,`省繁体名称`,`市英文名称`,`市繁体名称`,`区县英文名称`,`区县繁体名称`,
`乡/镇/街道英文名称`,`乡/镇/街道繁体名称`,`版本号`,`生效日期`,'' as `标记` from mywork.region_all_input
"""
sel_def.Sql_Data(sql9)

print('end：' + time.strftime("%Y-%m-%d %H:%M:%S"))