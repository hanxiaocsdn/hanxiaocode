# -*- coding: utf-8 -*-
import pandas as pd
import pymysql
from openpyxl import Workbook
import time
import os
from pymysql.converters import escape_string

#定义查询mysql数据库函数
def Select_Data(sql):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = sql
    cur.execute(sql)
    result = cur.fetchall()
    connect.commit()
    cur.close()
    connect.close()
    return  result

#定义查询mysql数据库函数
def Sql_Data(sql):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    cur.execute('SET SQL_SAFE_UPDATES = 0;')
    cur.execute(sql)
    connect.commit()
    cur.close()
    connect.close()


#定义数据写入：
def Insert_new(res_data,inserttb):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"insert into {inserttb} \
                value(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    cur.execute(sql,res_data)
    connect.commit()
    cur.close()
    connect.close()

#定义数据写入：
def Insert_change(res_data,inserttb):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"insert into {inserttb} \
                value(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\
                    %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\
                    %s,%s,%s,%s,%s,%s)"
    cur.execute(sql,res_data)
    connect.commit()
    cur.close()
    connect.close()

#定义数据写入：
def Insert_delete(res_data,inserttb):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"insert into {inserttb} \
                value(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\
                    %s,%s,%s,%s,%s,%s,%s,%s,%s)"
    cur.execute(sql,res_data)
    connect.commit()
    cur.close()
    connect.close()

#定义数据写入：
def Insert_all_input(res_data):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = "insert into region_all_output \
                value(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    cur.execute(sql,res_data)
    connect.commit()
    cur.close()
    connect.close()

#定义数据更新：
def update_all_input_city(province_code1,province_name1,province_eng1,province_ft1,
city_dm1,city_code1,city_name1,city_eng1,city_ft1,
county_code1,county_name1,county_eng1,county_ft1,
street_code1,street_name1,street_eng1,street_ft1,
village_code1,village_name1,village_eng1,village_ft1,
province_code2,province_name2,province_eng2,province_ft2,
city_dm2,city_code2,city_name2,city_eng2,city_ft2,
county_code2,county_name2,county_eng2,county_ft2,
street_code2,street_name2,street_eng2,street_ft2,
village_code2,village_name2,village_eng2,village_ft2,flag):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f""" update  region_all_output \
            set `省编码`="{province_code2}",`省`="{province_name2}",`省英文名称`="{province_eng2}",`省繁体名称`="{province_ft2}", \
            `城市代码`="{city_dm2}",`市编码`="{city_code2}",`市`="{city_name2}",`市英文名称`="{city_eng2}",`市繁体名称`="{city_ft2}" \
            where  `省编码`="{province_code1}" and `省`="{province_name1}" and `省英文名称`="{province_eng1}" and `省繁体名称`="{province_ft1}" \
             and `城市代码`="{city_dm1}" and `市编码`="{city_code1}" and `市`="{city_name1}" and `市英文名称`="{city_eng1}" and `市繁体名称`="{city_ft1}" and `标记`="{flag}"
            """
    cur.execute('SET SQL_SAFE_UPDATES = 0')
    cur.execute(sql)
    connect.commit()
    cur.close()
    connect.close()

#定义数据更新：
def update_all_input_county(province_code1,province_name1,province_eng1,province_ft1,
city_dm1,city_code1,city_name1,city_eng1,city_ft1,
county_code1,county_name1,county_eng1,county_ft1,
street_code1,street_name1,street_eng1,street_ft1,
village_code1,village_name1,village_eng1,village_ft1,
province_code2,province_name2,province_eng2,province_ft2,
city_dm2,city_code2,city_name2,city_eng2,city_ft2,
county_code2,county_name2,county_eng2,county_ft2,
street_code2,street_name2,street_eng2,street_ft2,
village_code2,village_name2,village_eng2,village_ft2,flag):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"""update  region_all_output \
                set `省编码`="{province_code2}",`省`="{province_name2}",`省英文名称`="{province_eng2}",`省繁体名称`="{province_ft2}", \
                `城市代码`="{city_dm2}",`市编码`="{city_code2}",`市`="{city_name2}",`市英文名称`="{city_eng2}",`市繁体名称`="{city_ft2}", \
                 `区县编码`="{county_code2}",`区县`="{county_name2}",`区县英文名称`="{county_eng2}",`区县繁体名称`="{county_ft2}" \
                where  `省编码`="{province_code1}" and `省`="{province_name1}" and `省英文名称`="{province_eng1}" and `省繁体名称`="{province_ft1}" \
                 and `城市代码`="{city_dm1}" and `市编码`="{city_code1}" and `市`="{city_name1}" and `市英文名称`="{city_eng1}" and `市繁体名称`="{city_ft1}"  \
                 and `区县编码`="{county_code1}" and `区县`="{county_name1}" and `区县英文名称`="{county_eng1}" and `区县繁体名称`="{county_ft1}"  and `标记`="{flag}"
    			 """
    cur.execute('SET SQL_SAFE_UPDATES = 0')
    cur.execute(sql)
    connect.commit()
    cur.close()
    connect.close()


# 定义数据更新：
def update_all_input_street( province_code1, province_name1, province_eng1, province_ft1,
                            city_dm1, city_code1, city_name1, city_eng1, city_ft1,
                            county_code1, county_name1, county_eng1, county_ft1,
                            street_code1, street_name1, street_eng1, street_ft1,
                            village_code1, village_name1, village_eng1, village_ft1,
                            province_code2, province_name2, province_eng2, province_ft2,
                            city_dm2, city_code2, city_name2, city_eng2, city_ft2,
                            county_code2, county_name2, county_eng2, county_ft2,
                            street_code2, street_name2, street_eng2, street_ft2,
                            village_code2, village_name2, village_eng2, village_ft2,flag):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"""update  region_all_output \
                set `省编码`="{province_code2}",`省`="{province_name2}",`省英文名称`="{province_eng2}",`省繁体名称`="{province_ft2}", \
                `城市代码`="{city_dm2}",`市编码`="{city_code2}",`市`="{city_name2}",`市英文名称`="{city_eng2}",`市繁体名称`="{city_ft2}", \
                 `区县编码`="{county_code2}",`区县`="{county_name2}",`区县英文名称`="{county_eng2}",`区县繁体名称`="{county_ft2}", \
    			 `乡/镇/街道编码`="{street_code2}",`乡/镇/街道`="{street_name2}",`乡/镇/街道英文名称`="{street_eng2}",`乡/镇/街道繁体名称`="{street_ft2}" \
                where  `省编码`="{province_code1}" and `省`="{province_name1}" and `省英文名称`="{province_eng1}" and `省繁体名称`="{province_ft1}" \
                 and `城市代码`="{city_dm1}" and `市编码`="{city_code1}" and `市`="{city_name1}" and `市英文名称`="{city_eng1}" and `市繁体名称`="{city_ft1}"  \
                 and `区县编码`="{county_code1}" and `区县`="{county_name1}" and `区县英文名称`="{county_eng1}" and `区县繁体名称`="{county_ft1}" \
    			 and `乡/镇/街道编码`="{street_code1}" and `乡/镇/街道` = "{street_name1}" and `乡/镇/街道英文名称` = "{street_eng1}" and `乡/镇/街道繁体名称` = "{street_ft1}"
    			  and `标记`="{flag}"
           """
    cur.execute('SET SQL_SAFE_UPDATES = 0')
    cur.execute(sql)
    connect.commit()
    cur.close()
    connect.close()


# 定义数据更新：
def update_all_input_village( province_code1, province_name1, province_eng1, province_ft1,
                             city_dm1, city_code1, city_name1, city_eng1, city_ft1,
                             county_code1, county_name1, county_eng1, county_ft1,
                             street_code1, street_name1, street_eng1, street_ft1,
                             village_code1, village_name1, village_eng1, village_ft1,
                             province_code2, province_name2, province_eng2, province_ft2,
                             city_dm2, city_code2, city_name2, city_eng2, city_ft2,
                             county_code2, county_name2, county_eng2, county_ft2,
                             street_code2, street_name2, street_eng2, street_ft2,
                             village_code2, village_name2, village_eng2, village_ft2,flag):
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"""update  region_all_output \
                set `省编码`="{province_code2}",`省`="{province_name2}",`省英文名称`="{province_eng2}",`省繁体名称`="{province_ft2}", \
                `城市代码`="{city_dm2}",`市编码`="{city_code2}",`市`="{city_name2}",`市英文名称`="{city_eng2}",`市繁体名称`="{city_ft2}", \
                 `区县编码`="{county_code2}",`区县`="{county_name2}",`区县英文名称`="{county_eng2}",`区县繁体名称`="{county_ft2}", \
    			 `乡/镇/街道编码`="{street_code2}",`乡/镇/街道`="{street_name2}",`乡/镇/街道英文名称`="{street_eng2}",`乡/镇/街道繁体名称`="{street_ft2}", \
                 `村编码`="{village_code2}",`村名称`="{village_name2}"			 \
                where  `省编码`="{province_code1}" and `省`="{province_name1}" and `省英文名称`="{province_eng1}" and `省繁体名称`="{province_ft1}" \
                 and `城市代码`="{city_dm1}" and `市编码`="{city_code1}" and `市`="{city_name1}" and `市英文名称`="{city_eng1}" and `市繁体名称`="{city_ft1}"  \
                 and `区县编码`="{county_code1}" and `区县`="{county_name1}" and `区县英文名称`="{county_eng1}" and `区县繁体名称`="{county_ft1}" \
    			 and `乡/镇/街道编码`="{street_code1}" and `乡/镇/街道`="{street_name1}" and `乡/镇/街道英文名称`="{street_eng1}" and `乡/镇/街道繁体名称`="{street_ft1}" \
    			 and `村编码`="{village_code1}" and `村名称`="{village_name1}"  and `标记`="{flag}"
    			 """
    cur.execute('SET SQL_SAFE_UPDATES = 0')
    cur.execute(sql)
    connect.commit()
    cur.close()
    connect.close()

#定义导出
def output_xlsx(tbname,sheetname):
    print(f"保存数据到 {tbname}.xlsx:"+time.strftime("%Y-%m-%d %H:%M:%S"))
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"select * from {tbname}"
    cur.execute(sql)

    results = cur.fetchall()

    # 写入Excel文件
    wb = Workbook()
    ws = wb.active
    ws.title = sheetname

    # 写入表头
    column_names = [i[0] for i in cur.description]
    ws.append(column_names)

    # 逐行写入数据
    for row in results:
        ws.append(row)

    # 保存文件
    wb.save(filename=f"output/{tbname}.xlsx")

    connect.commit()
    cur.close()
    connect.close()
    print('保存成功>>>'+time.strftime("%Y-%m-%d %H:%M:%S"))

#定义导出
def output_xlsx2(tbname,sheetname,fromlimit,limitnum):
    print(f"保存数据到 {tbname}.xlsx:"+time.strftime("%Y-%m-%d %H:%M:%S"))
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"select * from {tbname} limit {fromlimit},{limitnum}"
    cur.execute(sql)

    results = cur.fetchall()

    # 写入Excel文件
    wb = Workbook()
    ws = wb.active
    ws.title = sheetname

    # 写入表头
    column_names = [i[0] for i in cur.description]
    ws.append(column_names)

    # 逐行写入数据
    for row in results:
        ws.append(row)

    # 保存文件
    wb.save(filename=f"output/{tbname}"+f"{fromlimit}.xlsx")

    connect.commit()
    cur.close()
    connect.close()
    print('保存成功>>>'+time.strftime("%Y-%m-%d %H:%M:%S"))
#定义导出
def output_xlsx3(tbname,sheetname,colsname):
    print(f"保存数据到 {tbname}.xlsx:"+time.strftime("%Y-%m-%d %H:%M:%S"))
    connect = pymysql.connect(user='root', passwd='zy123456', host='127.0.0.1', db='mywork', charset='utf8')
    cur = connect.cursor()
    sql = f"select * from {tbname}"
    cur.execute(sql)

    results = cur.fetchall()

    results2=list(results)

    results3=pd.DataFrame(results2,columns=colsname)

    results3.to_excel(f"output/{tbname}.xlsx",sheetname)

    connect.commit()
    cur.close()
    connect.close()
    print('保存成功>>>'+time.strftime("%Y-%m-%d %H:%M:%S"))

#删除旧文件
def remove_file(file_name):
    if os.path.exists(file_name):
        os.remove(file_name)
        print('文件删除成功')
    else:
        print('文件不存在')

#处理空字符
def deal_escape_string(x):
    if x is None:
        return  x
    else:
        return escape_string(x)