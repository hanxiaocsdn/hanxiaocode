# -*- coding: utf-8 -*-
import sel_def
import pandas as pd
import time
from pymysql.converters import escape_string

# null deal
def nd(x):
    if x is None:
        return 'is null'
    else:
        return '="'+x+'"'

#更新全量表的标准区和非标准区
#更新全量表的标准区和非标准区
def update_std():
    #更新街道级
    sql1 = f"""
        select * from mywork.town_reflect_input
        """
    result = sel_def.Select_Data(sql1)

    for i in result:
        # 获取对应字段值
        adcode = i[0]
        name_chn = i[1]
        update_sql=f"""
          update mywork.region_all_output set
          `标记`='功能区'
          where `乡/镇/街道编码` %s and `乡/镇/街道` %s
           """%(nd(adcode),nd(name_chn))
        sel_def.Sql_Data(update_sql)

    #更新区级
    sql2 = f"""
        select * from mywork.county_reflect_input
        """
    result2 = sel_def.Select_Data(sql2)

    for i in result2:
        # 获取对应字段值
        adcode = i[0]
        name_chn = i[1]
        update_sql=f"""
          update mywork.region_all_output set
          `标记`='功能区'
          where `区县编码` %s and `区县` %s
           """%(nd(adcode),nd(name_chn))
        sel_def.Sql_Data(update_sql)

    #更新市级
    sql3 = f"""
        select * from mywork.city_reflect_input
        """
    result3 = sel_def.Select_Data(sql3)

    for i in result3:
        # 获取对应字段值
        adcode = i[0]
        name_chn = i[1]
        update_sql=f"""
          update mywork.region_all_output set
          `标记`='功能区'
          where `市编码` %s and `市` %s
           """%(nd(adcode),nd(name_chn))
        sel_def.Sql_Data(update_sql)

    #更新其他数据为非功能区
    update_sql4 = f"""
      update mywork.region_all_output set
      `标记`='非功能区'
      where `标记`='' or `标记` is null
       """
    sel_def.Sql_Data(update_sql4)


#新增:市
def new_city(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='市级别新增'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code = i[1]
        province_name = i[2]
        province_eng = i[3]
        province_ft = i[4]

        city_dm = i[5]
        city_code = i[6]
        city_name = i[7]
        city_eng = i[8]
        city_ft = i[9]

        county_code = i[10]
        county_name = i[11]
        county_eng = i[12]
        county_ft = i[13]

        street_code = i[14]
        street_name = i[15]
        street_eng = i[16]
        street_ft = i[17]

        village_code = i[18]
        village_name = i[19]
        village_eng = i[20]
        village_ft = i[21]
        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
         """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft))
        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)


        # print(i)
        if result_i_len == 0:
            i = i + ("新增行政区划上层级不存在",flag,)
            # 写入表
            sel_def.Insert_new(i,inserttb)
        else:
            sql_j = f"""
            select * from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s and `标记`  %s
             """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),nd(flag))
            result_j = sel_def.Select_Data(sql_j)
            result_j_len = len(result_j)
            if result_j_len > 0:
                i = i + ("新增行政区划数据已经存在",flag,)
                # 写入表
                sel_def.Insert_new(i,inserttb)
            else:
                xvalue = (i[1], i[2], i[5], i[6], i[7], i[10], i[11], i[14], i[15], i[18], i[19], i[3],
                          i[4], i[8], i[9], i[12], i[13], i[16], i[17], '', '',flag)
                # 写入表
                sel_def.Insert_all_input(xvalue)
                i = i + ("已新增到全量表",flag,)
                # 写入表
                sel_def.Insert_new(i,inserttb)

#新增:区
def new_county(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='县级别新增'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code = i[1]
        province_name = i[2]
        province_eng = i[3]
        province_ft = i[4]

        city_dm = i[5]
        city_code = i[6]
        city_name = i[7]
        city_eng = i[8]
        city_ft = i[9]

        county_code = i[10]
        county_name = i[11]
        county_eng = i[12]
        county_ft = i[13]

        street_code = i[14]
        street_name = i[15]
        street_eng = i[16]
        street_ft = i[17]

        village_code = i[18]
        village_name = i[19]
        village_eng = i[20]
        village_ft = i[21]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
        and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
        """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft))

        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        # print(i)
        if result_i_len == 0:
            i = i + ("新增行政区划上层级不存在",flag,)
            # 写入表
            sel_def.Insert_new(i,inserttb)
        else:
            sql_j = f"""
            select * from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s  and `标记`  %s
            """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(flag))
            result_j = sel_def.Select_Data(sql_j)
            result_j_len = len(result_j)
            if result_j_len > 0:
                i = i + ("新增行政区划数据已经存在",flag,)
                # 写入表
                sel_def.Insert_new(i,inserttb)
            else:
                # 判断上级有没有数据，从市级开始判断,如果上级有一条数据而且它的下级是空的，就删掉
                sql_ixj = f"""
                delete from region_all_output
                where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
                and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s  and `标记`  %s and  (`区县编码` is  null or `区县编码` ='')
                """ % (
                nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
                nd(city_name), nd(city_eng), nd(city_ft), nd(flag))
                sel_def.Sql_Data(sql_ixj)

                xvalue = (i[1], i[2], i[5], i[6], i[7], i[10], i[11], i[14], i[15], i[18], i[19], i[3],
                          i[4], i[8], i[9], i[12], i[13], i[16], i[17], '', '',flag)
                # 写入表
                sel_def.Insert_all_input(xvalue)
                i = i + ("已新增到全量表",flag,)
                # 写入表
                sel_def.Insert_new(i,inserttb)


#新增:乡镇
def new_street(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='乡镇级别新增'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code = i[1]
        province_name = i[2]
        province_eng = i[3]
        province_ft = i[4]

        city_dm = i[5]
        city_code = i[6]
        city_name = i[7]
        city_eng = i[8]
        city_ft = i[9]

        county_code = i[10]
        county_name = i[11]
        county_eng = i[12]
        county_ft = i[13]

        street_code = i[14]
        street_name = i[15]
        street_eng = i[16]
        street_ft = i[17]

        village_code = i[18]
        village_name = i[19]
        village_eng = i[20]
        village_ft = i[21]
        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
        and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
        and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
        """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft))
        #print(province_code, province_name, province_eng, province_ft, city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)
        #print(i)
        if result_i_len == 0:
            i = i + ("新增行政区划上层级不存在",flag,)
            # 写入表
            sel_def.Insert_new(i,inserttb)
        else:
            sql_j = f"""
            select * from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s  and `标记`  %s
             """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft),nd(flag))

            result_j = sel_def.Select_Data(sql_j)
            result_j_len = len(result_j)
            if result_j_len > 0:
                i = i + ("新增行政区划数据已经存在",flag,)
                # 写入表
                sel_def.Insert_new(i,inserttb)
            else:
                # 判断上级有没有数据，从市级开始判断,如果上级有一条数据而且它的下级是空的，就删掉
                sql_ixj = f"""
                delete from region_all_output
                where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
                and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
                and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                and `标记`  %s and  (`乡/镇/街道编码` is  null or `乡/镇/街道编码` ='')
                """ % (
                nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
                nd(city_name), nd(city_eng), nd(city_ft),nd(county_code),nd(county_name),nd(county_eng),nd(county_ft), nd(flag))
                sel_def.Sql_Data(sql_ixj)

                xvalue = (i[1], i[2], i[5], i[6], i[7], i[10], i[11], i[14], i[15], i[18], i[19], i[3],
                          i[4], i[8], i[9], i[12], i[13], i[16], i[17], '', '',flag)
                # 写入表
                sel_def.Insert_all_input(xvalue)
                i = i + ("已新增到全量表",flag,)
                # 写入表
                sel_def.Insert_new(i,inserttb)

#新增:村
def new_village(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='村级别新增'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code = i[1]
        province_name = i[2]
        province_eng = i[3]
        province_ft = i[4]

        city_dm = i[5]
        city_code = i[6]
        city_name = i[7]
        city_eng = i[8]
        city_ft = i[9]

        county_code = i[10]
        county_name = i[11]
        county_eng = i[12]
        county_ft = i[13]

        street_code = i[14]
        street_name = i[15]
        street_eng = i[16]
        street_ft = i[17]

        village_code = i[18]
        village_name = i[19]
        village_eng = i[20]
        village_ft = i[21]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
        and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
        and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
        and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
        """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft))
        #print(province_code, province_name, province_eng, province_ft, city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)
        #print(i)
        if result_i_len == 0:
            i = i + ("新增行政区划上层级不存在",flag,)
            # 写入表
            sel_def.Insert_new(i,inserttb)
        else:
            sql_j = f"""
            select * from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s  and `标记`  %s
            and  `村编码`  %s and   `村名称` %s
            """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft),
			nd(village_code),nd(village_name),nd(flag))
            result_j = sel_def.Select_Data(sql_j)
            result_j_len = len(result_j)
            if result_j_len > 0:
                i = i + ("新增行政区划数据已经存在",flag,)
                # 写入表
                sel_def.Insert_new(i,inserttb)
            else:
                # 判断上级有没有数据，从市级开始判断,如果上级有一条数据而且它的下级是空的，就删掉
                sql_ixj = f"""
                delete from region_all_output
                where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
                and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
                and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                and `标记`  %s and  (`村编码` is  null or `村编码` ='')
                """ % (
                nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
                nd(city_name), nd(city_eng), nd(city_ft),nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),
                nd(street_code),nd(street_name),nd(street_eng),nd(street_ft), nd(flag))
                sel_def.Sql_Data(sql_ixj)

                xvalue = (i[1], i[2], i[5], i[6], i[7], i[10], i[11], i[14], i[15], i[18], i[19], i[3],
                          i[4], i[8], i[9], i[12], i[13], i[16], i[17], '', '',flag)
                # 写入表
                sel_def.Insert_all_input(xvalue)
                i = i + ("已新增到全量表",flag,)
                # 写入表
                sel_def.Insert_new(i,inserttb)

#变更：市
def change_city(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='市级别变更' and `二级调整` !='范围'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code1 = i[2]
        province_name1 = i[3]
        province_eng1 =  i[4]
        province_ft1 = i[5]
        city_dm1 = i[6]
        city_code1 = i[7]
        city_name1 = i[8]
        city_eng1 =  i[9]
        city_ft1 = i[10]
        county_code1 = i[11]
        county_name1 = i[12]
        county_eng1 =  i[13]
        county_ft1 = i[14]
        street_code1 = i[15]
        street_name1 = i[16]
        street_eng1 =  i[17]
        street_ft1 = i[18]
        village_code1 = i[19]
        village_name1 = i[20]
        village_eng1 =  i[21]
        village_ft1 = i[22]
        province_code2 = i[23]
        province_name2 = i[24]
        province_eng2 =  i[25]
        province_ft2 = i[26]
        city_dm2 = i[27]
        city_code2 = i[28]
        city_name2 = i[29]
        city_eng2 =  i[30]
        city_ft2 = i[31]
        county_code2 = i[32]
        county_name2 = i[33]
        county_eng2 =  i[34]
        county_ft2 = i[35]
        street_code2 = i[36]
        street_name2 = i[37]
        street_eng2 =  i[38]
        street_ft2 = i[39]
        village_code2 = i[40]
        village_name2 = i[41]
        village_eng2 =  i[42]
        village_ft2 = i[43]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
        and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s and `标记`  %s
        """%(nd(province_code1),nd(province_name1),nd(province_eng1),nd(province_ft1),nd(city_dm1),nd(city_code1),nd(city_name1),nd(city_eng1),nd(city_ft1),nd(flag))

        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        #判断下级有没有数据
        sql_ixj = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
        and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s  and `标记`  %s and  `区县编码` is not null and `区县编码` !=''
        """%(nd(province_code1),nd(province_name1),nd(province_eng1),nd(province_ft1),nd(city_dm1),nd(city_code1),nd(city_name1),nd(city_eng1),nd(city_ft1),nd(flag))

        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_ixj = sel_def.Select_Data(sql_ixj)
        result_ixj_len = len(result_ixj)

        # print(i)
        if result_i_len == 0:
            i = i + ("变更行政区划数据不存在",flag,)
            # 写入表
            sel_def.Insert_change(i,inserttb)
        else :
            #如果下级没数据，则新增一条
            if result_ixj_len>0:
                flag_tmp='CMS变更新增-市' if tbname.find("cms") != -1 else 'GIS变更新增-市'
                xvalue = (province_code1, province_name1, city_dm1, city_code1, city_name1, county_code1, county_name1, street_code1, street_name1, village_code1, village_name1,
                          province_eng1,province_ft1, city_eng1, city_ft1,county_eng1, county_ft1, street_eng1, street_ft1, '', '',flag_tmp)
                # 写入表
                print('变更新增:' , xvalue)
                sel_def.Insert_all_input(xvalue)

            sql_j = f"""
            select * from region_all_output
            where `省编码` %s  and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
            """%(nd(province_code2),nd(province_name2),nd(province_eng2),nd(province_ft2))
            result_j = sel_def.Select_Data(sql_j)
            result_j_len = len(result_j)
            if result_j_len == 0:
                i = i + ("变更后行政区划上层级不存在",flag,)
                # 写入表
                sel_def.Insert_change(i,inserttb)
            else:
                # 写入表
                sel_def.update_all_input_city(province_code1,province_name1,province_eng1,province_ft1,
                            city_dm1,city_code1,city_name1,city_eng1,city_ft1,
                            county_code1,county_name1,county_eng1,county_ft1,
                            street_code1,street_name1,street_eng1,street_ft1,
                            village_code1,village_name1,village_eng1,village_ft1,
                            province_code2,province_name2,province_eng2,province_ft2,
                            city_dm2,city_code2,city_name2,city_eng2,city_ft2,
                            county_code2,county_name2,county_eng2,county_ft2,
                            street_code2,street_name2,street_eng2,street_ft2,
                            village_code2,village_name2,village_eng2,village_ft2,flag_tmp)
                i = i + ("已变更到全量表",flag,)
                # 写入表
                sel_def.Insert_change(i,inserttb)

#变更:区
def change_county(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='县级别变更' and `三级调整` !='范围'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code1 = i[2]
        province_name1 = i[3]
        province_eng1 = i[4]
        province_ft1 = i[5]
        city_dm1 = i[6]
        city_code1 = i[7]
        city_name1 = i[8]
        city_eng1 = i[9]
        city_ft1 = i[10]
        county_code1 = i[11]
        county_name1 = i[12]
        county_eng1 = i[13]
        county_ft1 = i[14]
        street_code1 = i[15]
        street_name1 = i[16]
        street_eng1 = i[17]
        street_ft1 = i[18]
        village_code1 = i[19]
        village_name1 = i[20]
        village_eng1 = i[21]
        village_ft1 = i[22]
        province_code2 = i[23]
        province_name2 = i[24]
        province_eng2 = i[25]
        province_ft2 = i[26]
        city_dm2 = i[27]
        city_code2 = i[28]
        city_name2 = i[29]
        city_eng2 = i[30]
        city_ft2 = i[31]
        county_code2 = i[32]
        county_name2 = i[33]
        county_eng2 = i[34]
        county_ft2 = i[35]
        street_code2 = i[36]
        street_name2 = i[37]
        street_eng2 = i[38]
        street_ft2 = i[39]
        village_code2 = i[40]
        village_name2 = i[41]
        village_eng2 = i[42]
        village_ft2 = i[43]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
        and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
        and  `区县编码` %s  and  `区县` %s  and  `区县英文名称` %s  and  `区县繁体名称` %s and `标记`  %s
                   """%(nd(province_code1),nd(province_name1),nd(province_eng1),nd(province_ft1),nd(city_dm1),nd(city_code1),nd(city_name1),nd(city_eng1),nd(city_ft1),
			nd(county_code1),nd(county_name1),nd(county_eng1),nd(county_ft1),nd(flag))
        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        #判断下级有没有数据
        sql_ixj = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
        and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
        and  `区县编码` %s  and  `区县` %s  and  `区县英文名称` %s  and  `区县繁体名称` %s and `标记`  %s
        and  `乡/镇/街道编码`  is not null and `乡/镇/街道编码` !=''
        """%(nd(province_code1),nd(province_name1),nd(province_eng1),nd(province_ft1),nd(city_dm1),nd(city_code1),nd(city_name1),nd(city_eng1),nd(city_ft1),
			nd(county_code1),nd(county_name1),nd(county_eng1),nd(county_ft1),nd(flag))

        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_ixj = sel_def.Select_Data(sql_ixj)
        result_ixj_len = len(result_ixj)

        # print(i)
        if result_i_len == 0:
            i = i + ("变更行政区划数据不存在",flag,)
            # 写入表
            sel_def.Insert_change(i,inserttb)
        else:
            #如果下级没数据，则新增一条
            if result_ixj_len>0:
                flag_tmp='CMS变更新增-区' if tbname.find("cms") != -1 else 'GIS变更新增-区'
                xvalue = (province_code1, province_name1, city_dm1, city_code1, city_name1, county_code1, county_name1, street_code1, street_name1, village_code1, village_name1,
                          province_eng1,province_ft1, city_eng1, city_ft1,county_eng1, county_ft1, street_eng1, street_ft1, '', '',flag_tmp)
                # 写入表
                print('变更新增:' , xvalue)
                sel_def.Insert_all_input(xvalue)

            sql_j = f"""
            select * from region_all_output
            where `省编码` %s  and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
            and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
            """%(nd(province_code2),nd(province_name2),nd(province_eng2),nd(province_ft2),nd(city_dm2),nd(city_code2),nd(city_name2),nd(city_eng2),nd(city_ft2))

            result_j = sel_def.Select_Data(sql_j)
            result_j_len = len(result_j)
            if result_j_len == 0:
                i = i + ("变更后行政区划上层级不存在",flag,)
                # 写入表
                sel_def.Insert_change(i,inserttb)
            else:
                # 写入表
                sel_def.update_all_input_county(province_code1,province_name1,province_eng1,province_ft1,
                            city_dm1,city_code1,city_name1,city_eng1,city_ft1,
                            county_code1,county_name1,county_eng1,county_ft1,
                            street_code1,street_name1,street_eng1,street_ft1,
                            village_code1,village_name1,village_eng1,village_ft1,
                            province_code2,province_name2,province_eng2,province_ft2,
                            city_dm2,city_code2,city_name2,city_eng2,city_ft2,
                            county_code2,county_name2,county_eng2,county_ft2,
                            street_code2,street_name2,street_eng2,street_ft2,
                            village_code2,village_name2,village_eng2,village_ft2,flag_tmp)
                i = i + ("已变更到全量表",flag,)
                # 写入表
                sel_def.Insert_change(i,inserttb)

#变更：乡
def change_street(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='乡镇级别变更' and `四级调整` !='范围'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code1 = i[2]
        province_name1 = i[3]
        province_eng1 = i[4]
        province_ft1 = i[5]
        city_dm1 = i[6]
        city_code1 = i[7]
        city_name1 = i[8]
        city_eng1 = i[9]
        city_ft1 = i[10]
        county_code1 = i[11]
        county_name1 = i[12]
        county_eng1 = i[13]
        county_ft1 = i[14]
        street_code1 = i[15]
        street_name1 = i[16]
        street_eng1 = i[17]
        street_ft1 = i[18]
        village_code1 = i[19]
        village_name1 = i[20]
        village_eng1 = i[21]
        village_ft1 = i[22]
        province_code2 = i[23]
        province_name2 = i[24]
        province_eng2 = i[25]
        province_ft2 = i[26]
        city_dm2 = i[27]
        city_code2 = i[28]
        city_name2 = i[29]
        city_eng2 = i[30]
        city_ft2 = i[31]
        county_code2 = i[32]
        county_name2 = i[33]
        county_eng2 = i[34]
        county_ft2 = i[35]
        street_code2 = i[36]
        street_name2 = i[37]
        street_eng2 = i[38]
        street_ft2 = i[39]
        village_code2 = i[40]
        village_name2 = i[41]
        village_eng2 = i[42]
        village_ft2 = i[43]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
        and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
        and  `区县编码` %s  and  `区县` %s  and  `区县英文名称` %s  and  `区县繁体名称` %s
        and  `乡/镇/街道编码` %s  and  `乡/镇/街道` %s  and  `乡/镇/街道英文名称` %s  and  `乡/镇/街道繁体名称` %s  and `标记`  %s
        """%(nd(province_code1),nd(province_name1),nd(province_eng1),nd(province_ft1),nd(city_dm1),nd(city_code1),nd(city_name1),nd(city_eng1),nd(city_ft1),
			nd(county_code1),nd(county_name1),nd(county_eng1),nd(county_ft1),nd(street_code1),nd(street_name1),nd(street_eng1),nd(street_ft1),nd(flag))
        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        # 判断下级有没有数据
        sql_ixj = f"""
                select * from region_all_output
                where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
                and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
                and  `区县编码` %s  and  `区县` %s  and  `区县英文名称` %s  and  `区县繁体名称` %s
                and  `乡/镇/街道编码` %s  and  `乡/镇/街道` %s  and  `乡/镇/街道英文名称` %s  and  `乡/镇/街道繁体名称` %s  and `标记`  %s
                and  `村编码`  is not null and `村编码` !=''
        """%(nd(province_code1),nd(province_name1),nd(province_eng1),nd(province_ft1),nd(city_dm1),nd(city_code1),nd(city_name1),nd(city_eng1),nd(city_ft1),
			nd(county_code1),nd(county_name1),nd(county_eng1),nd(county_ft1),nd(street_code1),nd(street_name1),nd(street_eng1),nd(street_ft1),nd(flag))

        result_ixj = sel_def.Select_Data(sql_ixj)
        result_ixj_len = len(result_ixj)

        print(i)
        if result_i_len == 0:
            i = i + ("变更行政区划数据不存在",flag,)
            # 写入表
            sel_def.Insert_change(i,inserttb)
        else:

            #如果下级没数据，则新增一条
            if result_ixj_len>0:
                flag_tmp='CMS变更新增-街道' if tbname.find("cms") != -1 else 'GIS变更新增-街道'
                xvalue = (province_code1, province_name1, city_dm1, city_code1, city_name1, county_code1, county_name1, street_code1, street_name1, village_code1, village_name1,
                          province_eng1,province_ft1, city_eng1, city_ft1,county_eng1, county_ft1, street_eng1, street_ft1, '', '',flag_tmp)
                # 写入表
                print('变更新增:',xvalue)
                sel_def.Insert_all_input(xvalue)

            sql_j = f"""
            select * from region_all_output
            where `省编码` %s  and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
            and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
            and  `区县编码` %s  and  `区县` %s  and  `区县英文名称` %s  and  `区县繁体名称` %s
            """%(nd(province_code2),nd(province_name2),nd(province_eng2),nd(province_ft2),nd(city_dm2),nd(city_code2),nd(city_name2),nd(city_eng2),nd(city_ft2),
			nd(county_code2),nd(county_name2),nd(county_eng2),nd(county_ft2))
            result_j = sel_def.Select_Data(sql_j)
            result_j_len = len(result_j)
            if result_j_len == 0:
                i = i + ("变更后行政区划上层级不存在",flag,)
                # 写入表
                sel_def.Insert_change(i,inserttb)
            else:
                # 写入表
                sel_def.update_all_input_street(province_code1,province_name1,province_eng1,province_ft1,
                            city_dm1,city_code1,city_name1,city_eng1,city_ft1,
                            county_code1,county_name1,county_eng1,county_ft1,
                            street_code1,street_name1,street_eng1,street_ft1,
                            village_code1,village_name1,village_eng1,village_ft1,
                            province_code2,province_name2,province_eng2,province_ft2,
                            city_dm2,city_code2,city_name2,city_eng2,city_ft2,
                            county_code2,county_name2,county_eng2,county_ft2,
                            street_code2,street_name2,street_eng2,street_ft2,
                            village_code2,village_name2,village_eng2,village_ft2,flag_tmp)
                i = i + ("已变更到全量表",flag,)
                # 写入表
                sel_def.Insert_change(i,inserttb)
#变更：村
def change_village(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='村级别变更' and `五级调整` !='范围'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code1 = i[2]
        province_name1 = i[3]
        province_eng1 = i[4]
        province_ft1 = i[5]
        city_dm1 = i[6]
        city_code1 = i[7]
        city_name1 = i[8]
        city_eng1 = i[9]
        city_ft1 = i[10]
        county_code1 = i[11]
        county_name1 = i[12]
        county_eng1 = i[13]
        county_ft1 = i[14]
        street_code1 = i[15]
        street_name1 = i[16]
        street_eng1 = i[17]
        street_ft1 = i[18]
        village_code1 = i[19]
        village_name1 = i[20]
        village_eng1 = i[21]
        village_ft1 = i[22]
        province_code2 = i[23]
        province_name2 = i[24]
        province_eng2 = i[25]
        province_ft2 = i[26]
        city_dm2 = i[27]
        city_code2 = i[28]
        city_name2 = i[29]
        city_eng2 = i[30]
        city_ft2 = i[31]
        county_code2 = i[32]
        county_name2 = i[33]
        county_eng2 = i[34]
        county_ft2 = i[35]
        street_code2 = i[36]
        street_name2 = i[37]
        street_eng2 = i[38]
        street_ft2 = i[39]
        village_code2 = i[40]
        village_name2 = i[41]
        village_eng2 = i[42]
        village_ft2 = i[43]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
        and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
        and  `区县编码` %s  and  `区县` %s  and  `区县英文名称` %s  and  `区县繁体名称` %s
        and  `乡/镇/街道编码` %s  and  `乡/镇/街道` %s  and  `乡/镇/街道英文名称` %s  and  `乡/镇/街道繁体名称` %s
        and  `村编码` %s  and  `村名称` %s   and `标记`  %s
        """%(nd(province_code1),nd(province_name1),nd(province_eng1),nd(province_ft1),nd(city_dm1),nd(city_code1),nd(city_name1),nd(city_eng1),nd(city_ft1),
			nd(county_code1),nd(county_name1),nd(county_eng1),nd(county_ft1),nd(street_code1),nd(street_name1),nd(street_eng1),nd(street_ft1),
			nd(village_code1),nd(village_name1),nd(flag))
        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        # print(i)
        if result_i_len == 0:
            i = i + ("变更行政区划数据不存在",flag,)
            # 写入表
            sel_def.Insert_change(i,inserttb)
        else:
            sql_j = f"""
            select * from region_all_output
            where `省编码` %s  and  `省` %s  and  `省英文名称` %s  and  `省繁体名称` %s
            and  `城市代码` %s  and  `市编码` %s  and  `市` %s  and  `市英文名称` %s  and  `市繁体名称` %s
            and  `区县编码` %s  and  `区县` %s  and  `区县英文名称` %s  and  `区县繁体名称` %s
            and  `乡/镇/街道编码` %s  and  `乡/镇/街道` %s  and  `乡/镇/街道英文名称` %s  and  `乡/镇/街道繁体名称` %s
            """%(nd(province_code2),nd(province_name2),nd(province_eng2),nd(province_ft2),nd(city_dm2),nd(city_code2),nd(city_name2),nd(city_eng2),nd(city_ft2),
			nd(county_code2),nd(county_name2),nd(county_eng2),nd(county_ft2),nd(street_code2),nd(street_name2),nd(street_eng2),nd(street_ft2))
            result_j = sel_def.Select_Data(sql_j)
            result_j_len = len(result_j)
            if result_j_len == 0:
                i = i + ("变更后行政区划上层级不存在",flag,)
                # 写入表
                sel_def.Insert_change(i,inserttb)
            else:
                # 写入表
                sel_def.update_all_input_village(province_code1,province_name1,province_eng1,province_ft1,
                            city_dm1,city_code1,city_name1,city_eng1,city_ft1,
                            county_code1,county_name1,county_eng1,county_ft1,
                            street_code1,street_name1,street_eng1,street_ft1,
                            village_code1,village_name1,village_eng1,village_ft1,
                            province_code2,province_name2,province_eng2,province_ft2,
                            city_dm2,city_code2,city_name2,city_eng2,city_ft2,
                            county_code2,county_name2,county_eng2,county_ft2,
                            street_code2,street_name2,street_eng2,street_ft2,
                            village_code2,village_name2,village_eng2,village_ft2,flag)
                i = i + ("已变更到全量表",flag,)
                # 写入表
                sel_def.Insert_change(i,inserttb)

#变更后将多与数据删除和改变标识
def change_update():
    sql=f"select * from region_all_output where `标记` like '%变更新增%' "

    result = sel_def.Select_Data(sql)
    for i in result:
        province_code=i[0]
        province_name = i[1]
        city_dm = i[2]
        city_code = i[3]
        city_name = i[4]
        county_code = i[5]
        county_name = i[6]
        street_code = i[7]
        street_name = i[8]
        village_code = i[9]
        village_name = i[10]
        province_eng = i[11]
        province_ft = i[12]
        city_eng = i[13]
        city_ft = i[14]
        county_eng = i[15]
        county_ft = i[16]
        street_eng = i[17]
        street_ft = i[18]
        version = i[19]
        dates = i[20]
        flag = i[21]

        print(version,"aaa1",nd(version),"aaa2",dates,"aaa3",nd(dates),"aaa4",flag)
        #市级别数据处理
        if flag.find("市") != -1:
            # 去数据库里查有没有符合要求的数据
            sql_i = f"""
            select * from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` is not null and `区县编码` !=''
            """ % (
            nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm),
            nd(city_code),nd(city_name), nd(city_eng), nd(city_ft))

            print(sql_i)

            result_i = sel_def.Select_Data(sql_i)
            result_i_len = len(result_i)
            if result_i_len>0:
                sql_j = f"""
                            delete from region_all_output
                            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                            and  `村编码`  %s and   `村名称` %s  and  `版本号`  %s and  `生效日期` %s  and `标记`  %s
                            """ % (
                nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
                nd(city_name), nd(city_eng), nd(city_ft),nd(county_code), nd(county_name), nd(county_eng), nd(county_ft), nd(street_code), nd(street_name),
                nd(street_eng), nd(street_ft),nd(village_code), nd(village_name),nd(version),nd(dates), nd(flag))
                sel_def.Sql_Data(sql_j)
            else:
                ql_j = f"""
                            update region_all_output set `标记`=case when `标记` like '%%CMS%%' then '功能区' else '非功能区' end
                               where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                            and  `村编码`  %s and   `村名称` %s  and  `版本号`  %s and  `生效日期` %s  and `标记`  %s
                            """ % (
                nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
                nd(city_name), nd(city_eng), nd(city_ft),nd(county_code), nd(county_name), nd(county_eng), nd(county_ft), nd(street_code), nd(street_name),
                nd(street_eng), nd(street_ft),nd(village_code), nd(village_name),nd(version),nd(dates), nd(flag))
                sel_def.Sql_Data(ql_j)

        # 区级别数据处理
        elif flag.find("区") != -1:
            # 去数据库里查有没有符合要求的数据
            sql_i = f"""
            select * from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
            and  `乡/镇/街道编码` is not null and `乡/镇/街道编码` !=''
                    """ % (
            nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm),
            nd(city_code),nd(city_name), nd(city_eng), nd(city_ft), nd(county_code), nd(county_name), nd(county_eng),nd(county_ft))
            result_i = sel_def.Select_Data(sql_i)

            print(sql_i)

            result_i_len = len(result_i)
            if result_i_len > 0:
                sql_j = f"""
                            delete from region_all_output
                            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                            and  `村编码`  %s and   `村名称` %s  and  `版本号`  %s and  `生效日期` %s  and `标记`  %s
                            """ % (
                    nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm),
                    nd(city_code),nd(city_name), nd(city_eng), nd(city_ft), nd(county_code), nd(county_name), nd(county_eng),
                    nd(county_ft), nd(street_code), nd(street_name),
                    nd(street_eng), nd(street_ft), nd(village_code), nd(village_name), nd(version), nd(dates),nd(flag))
                sel_def.Sql_Data(sql_j)
            else:
                ql_j = f"""
                            update region_all_output set `标记`=case when `标记` like '%%CMS%%' then '功能区' else '非功能区' end
                               where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                            and  `村编码`  %s and   `村名称` %s  and  `版本号`  %s and  `生效日期` %s  and `标记`  %s
                            """ % (nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm),
                    nd(city_code),nd(city_name), nd(city_eng), nd(city_ft), nd(county_code), nd(county_name), nd(county_eng),
                    nd(county_ft), nd(street_code), nd(street_name),nd(street_eng), nd(street_ft), nd(village_code), nd(village_name), nd(version), nd(dates),nd(flag))
                sel_def.Sql_Data(ql_j)

                # 区级别数据处理
        elif flag.find("街道") != -1:
            # 去数据库里查有没有符合要求的数据
            sql_i = f"""
                   select * from region_all_output
                   where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                   and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                   and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and `区县繁体名称` %s
                   and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                   and  `村编码` is not null and `村编码` !=''
                           """ % (
                nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm),
                nd(city_code), nd(city_name), nd(city_eng), nd(city_ft), nd(county_code), nd(county_name),
                nd(county_eng), nd(county_ft), nd(street_code), nd(street_name),nd(street_eng), nd(street_ft))

            print(sql_i)
            print((nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm),
                nd(city_code), nd(city_name), nd(city_eng), nd(city_ft), nd(county_code), nd(county_name),
                nd(county_eng),nd(county_ft), nd(street_code), nd(street_name), nd(street_eng), nd(street_ft), nd(village_code),
                nd(village_name), nd(version), nd(dates)))

            result_i = sel_def.Select_Data(sql_i)
            result_i_len = len(result_i)
            if result_i_len > 0:
                sql_j = f"""
                       delete from region_all_output
                       where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                       and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                       and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                       and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                       and  `村编码`  %s and   `村名称` %s  and  `版本号`  %s and  `生效日期` %s  and `标记`  %s
                       """ % (nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm),
                    nd(city_code), nd(city_name), nd(city_eng), nd(city_ft), nd(county_code), nd(county_name),
                    nd(county_eng),nd(county_ft), nd(street_code), nd(street_name),nd(street_eng), nd(street_ft),
                    nd(village_code), nd(village_name), nd(version), nd(dates), nd(flag))
                sel_def.Sql_Data(sql_j)
            else:
                ql_j = f"""
                           update region_all_output set `标记`=case when `标记` like '%%CMS%%' then '功能区' else '非功能区' end
                              where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                           and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                           and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                           and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                           and  `村编码`  %s and   `村名称` %s  and  `版本号`  %s and  `生效日期` %s
                           """ % (nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm),
                nd(city_code), nd(city_name), nd(city_eng), nd(city_ft), nd(county_code), nd(county_name),
                nd(county_eng),nd(county_ft), nd(street_code), nd(street_name), nd(street_eng), nd(street_ft), nd(village_code),
                nd(village_name), nd(version), nd(dates))

                print(ql_j)

                sel_def.Sql_Data(ql_j)
        else:
            print("无需处理变更新增")



#撤销：村
def delete_village(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='村级别撤销'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code = i[1]
        province_name = i[2]
        province_eng = i[3]
        province_ft = i[4]
        city_dm = i[5]
        city_code = i[6]
        city_name = i[7]
        city_eng = i[8]
        city_ft = i[9]
        county_code = i[10]
        county_name = i[11]
        county_eng = i[12]
        county_ft = i[13]
        street_code = i[14]
        street_name = i[15]
        street_eng = i[16]
        street_ft = i[17]
        village_code = i[18]
        village_name = i[19]
        village_eng = i[20]
        village_ft = i[21]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
        and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
        and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
        and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
        and  `村编码` %s and  `村名称` %s  and `标记`  %s
         """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft),
			nd(village_code),nd(village_name),nd(flag))
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        # 去数据库里查对应上级的数据，用于判断是直接删除还是保留一条
        sql_j = f"""
                select * from region_all_output
                where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                and `标记`  %s
                 """ % (
        nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
        nd(city_name), nd(city_eng), nd(city_ft),
        nd(county_code), nd(county_name), nd(county_eng), nd(county_ft), nd(street_code), nd(street_name),
        nd(street_eng), nd(street_ft), nd(flag))
        result_j = sel_def.Select_Data(sql_j)
        result_j_len = len(result_j)

        # print(i)
        if result_i_len == 0:
            i = i + ("撤销的行政区划数据不存在",flag,)
            # 写入表
            sel_def.Insert_delete(i,inserttb)
        elif result_j_len>1:
            sql_j = f"""
            delete from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
            and  `村编码`  %s and   `村名称` %s  and `标记`  %s
            """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft),
			nd(village_code),nd(village_name),nd(flag))
            sel_def.Sql_Data(sql_j)
            i = i + ("已在全量表撤销",flag,)
            # 写入表
            sel_def.Insert_delete(i, inserttb)
        else:
            sql_k=f"""
            update region_all_output
            set `村编码` =NULL , `村名称` =NULL
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
            and  `村编码`  %s and  `村名称` %s  and `标记`  %s
            """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft),
			nd(village_code),nd(village_name),nd(flag))
            sel_def.Sql_Data(sql_k)
            i = i + ("已在全量表置空对应层级字段",flag,)
            # 写入表
            sel_def.Insert_delete(i, inserttb)


#撤销：乡镇
def delete_street(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='乡镇级别撤销'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code = i[1]
        province_name = i[2]
        province_eng = i[3]
        province_ft = i[4]
        city_dm = i[5]
        city_code = i[6]
        city_name = i[7]
        city_eng = i[8]
        city_ft = i[9]
        county_code = i[10]
        county_name = i[11]
        county_eng = i[12]
        county_ft = i[13]
        street_code = i[14]
        street_name = i[15]
        street_eng = i[16]
        street_ft = i[17]
        village_code = i[18]
        village_name = i[19]
        village_eng = i[20]
        village_ft = i[21]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
        and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
        and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
        and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s  and `标记`  %s
        """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft),nd(flag))
        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        #判断下级有没有数据
        sql_ixj =f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
        and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
        and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
        and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s  and  `村编码` is not null and `村编码` !=''
        """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft))

        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_ixj = sel_def.Select_Data(sql_ixj)
        result_ixj_len = len(result_ixj)

        # 去数据库里查对应上级的数据，用于判断是直接删除还是保留一条
        sql_j = f"""
                select * from region_all_output
                where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                and `标记`  %s
                 """ % (
        nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
        nd(city_name), nd(city_eng), nd(city_ft),
        nd(county_code), nd(county_name), nd(county_eng), nd(county_ft),nd(flag))
        result_j = sel_def.Select_Data(sql_j)
        result_j_len = len(result_j)

        if result_i_len == 0:
            i = i + ("撤销的行政区划数据不存在",flag,)
            # 写入表
            sel_def.Insert_delete(i,inserttb)
            print(i)
        elif result_ixj_len > 1:
            i = i + ("撤销的行政区划数据存在下级",flag,)
            # 写入表
            sel_def.Insert_delete(i,inserttb)
            print(i)
        elif result_j_len > 1:
            sql_j = f"""
            delete from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
            and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s  and `标记`  %s
            """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(street_code),nd(street_name),nd(street_eng),nd(street_ft),nd(flag))
            sel_def.Sql_Data(sql_j)
            i = i + ("已在全量表撤销",flag,)
            # 写入表
            sel_def.Insert_delete(i, inserttb)
        else:
            sql_k = f"""
                    update region_all_output
                    set `乡/镇/街道编码` =NULL , `乡/镇/街道` =NULL , `乡/镇/街道英文名称` =NULL , `乡/镇/街道繁体名称` =NULL
                    where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                    and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                    and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                    and  `乡/镇/街道编码` %s and  `乡/镇/街道` %s and  `乡/镇/街道英文名称` %s and  `乡/镇/街道繁体名称` %s
                    and `标记`  %s
                    """ % (
            nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
            nd(city_name), nd(city_eng), nd(city_ft),
            nd(county_code), nd(county_name), nd(county_eng), nd(county_ft), nd(street_code), nd(street_name),
            nd(street_eng), nd(street_ft),nd(flag))
            sel_def.Sql_Data(sql_k)
            i = i + ("已在全量表置空对应层级字段", flag,)
            # 写入表
            sel_def.Insert_delete(i, inserttb)


#撤销：区
def delete_county(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='县级别撤销'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code = i[1]
        province_name = i[2]
        province_eng = i[3]
        province_ft = i[4]
        city_dm = i[5]
        city_code = i[6]
        city_name = i[7]
        city_eng = i[8]
        city_ft = i[9]
        county_code = i[10]
        county_name = i[11]
        county_eng = i[12]
        county_ft = i[13]
        street_code = i[14]
        street_name = i[15]
        street_eng = i[16]
        street_ft = i[17]
        village_code = i[18]
        village_name = i[19]
        village_eng = i[20]
        village_ft = i[21]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
        and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
        and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s  and `标记`  %s
        """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(flag))
        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        # 判断下级有没有数据
        sql_ixj = f"""
                select * from region_all_output
                where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                and `乡/镇/街道编码` is not null and `乡/镇/街道编码` !=''
                """ % (
        nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
        nd(city_name), nd(city_eng), nd(city_ft),
        nd(county_code), nd(county_name), nd(county_eng), nd(county_ft))

        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_ixj = sel_def.Select_Data(sql_ixj)
        result_ixj_len = len(result_ixj)

        # 去数据库里查对应上级的数据，用于判断是直接删除还是保留一条
        sql_j = f"""
                select * from region_all_output
                where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                and `标记`  %s
                 """ % (
        nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
        nd(city_name), nd(city_eng), nd(city_ft), nd(flag))
        result_j = sel_def.Select_Data(sql_j)
        result_j_len = len(result_j)

        if result_i_len == 0:
            i = i + ("撤销的行政区划数据不存在",flag,)
            # 写入表
            sel_def.Insert_delete(i,inserttb)
        elif result_ixj_len > 1:
            i = i + ("撤销的行政区划数据存在下级",flag,)
            # 写入表
            sel_def.Insert_delete(i,inserttb)
            print(i)
        elif result_j_len > 1:
            sql_j = f"""
            delete from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
            and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s  and `标记`  %s
            """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),
			nd(county_code),nd(county_name),nd(county_eng),nd(county_ft),nd(flag))
            sel_def.Sql_Data(sql_j)
            i = i + ("已在全量表撤销",flag,)
            # 写入表
            sel_def.Insert_delete(i, inserttb)
        else:
            sql_k = f"""
                    update region_all_output
                    set `区县编码` =NULL , `区县` =NULL , `区县英文名称` =NULL , `区县繁体名称` =NULL
                    where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                    and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                    and  `区县编码` %s and  `区县` %s and  `区县英文名称`  %s and   `区县繁体名称` %s
                    and `标记`  %s
                    """ % (
            nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
            nd(city_name), nd(city_eng), nd(city_ft),
            nd(county_code), nd(county_name), nd(county_eng), nd(county_ft), nd(flag))
            sel_def.Sql_Data(sql_k)
            i = i + ("已在全量表置空对应层级字段", flag,)
            # 写入表
            sel_def.Insert_delete(i, inserttb)

#撤销：市
def delete_city(tbname,inserttb,flag):
    sql = f"""
    select * from {tbname}
    where `修改类型`='市级别撤销'
    """

    result = sel_def.Select_Data(sql)

    for i in result:
        # 获取对应字段值
        province_code = i[1]
        province_name = i[2]
        province_eng = i[3]
        province_ft = i[4]
        city_dm = i[5]
        city_code = i[6]
        city_name = i[7]
        city_eng = i[8]
        city_ft = i[9]
        county_code = i[10]
        county_name = i[11]
        county_eng = i[12]
        county_ft = i[13]
        street_code = i[14]
        street_name = i[15]
        street_eng = i[16]
        street_ft = i[17]
        village_code = i[18]
        village_name = i[19]
        village_eng = i[20]
        village_ft = i[21]

        # 去数据库里查有没有符合要求的数据
        sql_i = f"""
        select * from region_all_output
        where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
        and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s and `标记`  %s
         """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),nd(flag))
        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_i = sel_def.Select_Data(sql_i)
        result_i_len = len(result_i)

        # 判断下级有没有数据
        sql_ixj = f"""
                select * from region_all_output
                where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                and `区县编码` is not null and `区县编码` !=''
                """ % (
        nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
        nd(city_name), nd(city_eng), nd(city_ft))

        # print(province_code,province_name,province_eng,province_ft,city_code)
        result_ixj = sel_def.Select_Data(sql_ixj)
        result_ixj_len = len(result_ixj)

        # 去数据库里查对应上级的数据，用于判断是直接删除还是保留一条
        sql_j = f"""
                select * from region_all_output
                where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                and `标记`  %s
                 """ % (
        nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(flag))
        result_j = sel_def.Select_Data(sql_j)
        result_j_len = len(result_j)

        if result_i_len == 0:
            i = i + ("撤销的行政区划数据不存在",flag,)
            # 写入表
            sel_def.Insert_delete(i,inserttb)
        elif result_ixj_len > 1:
            i = i + ("撤销的行政区划数据存在下级",flag,)
            # 写入表
            sel_def.Insert_delete(i,inserttb)
            print(i)
        elif result_j_len > 1:
            sql_j = f"""
            delete from region_all_output
            where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
            and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s and `标记`  %s
            """%(nd(province_code),nd(province_name),nd(province_eng),nd(province_ft),nd(city_dm),nd(city_code),nd(city_name),nd(city_eng),nd(city_ft),nd(flag))

            sel_def.Sql_Data(sql_j)
            i = i + ("已在全量表撤销",flag,)
            # 写入表
            sel_def.Insert_delete(i, inserttb)
        else:
            sql_k = f"""
                    update region_all_output
                    set `城市代码` =NULL , `市编码` =NULL , `市` =NULL , `市英文名称` =NULL , `市繁体名称` =NULL
                    where `省编码` %s and  `省` %s and  `省英文名称` %s and  `省繁体名称` %s
                    and  `城市代码` %s and  `市编码` %s and  `市` %s and  `市英文名称` %s and  `市繁体名称` %s
                    and `标记`  %s
                    """ % (
            nd(province_code), nd(province_name), nd(province_eng), nd(province_ft), nd(city_dm), nd(city_code),
            nd(city_name), nd(city_eng), nd(city_ft),nd(flag))
            sel_def.Sql_Data(sql_k)
            i = i + ("已在全量表置空对应层级字段", flag,)
            # 写入表
            sel_def.Insert_delete(i, inserttb)

if __name__ == '__main__':

    #更新全量表的功能区和非功能区
    update_std()
    tbname = 'cms_new_input'
    inserttb='cms_new_output'
    print('新增cms_city：'+time.strftime("%Y-%m-%d %H:%M:%S"))
    new_city(tbname,inserttb,'功能区')
    print('新增cms_county：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    new_county(tbname,inserttb,'功能区')
    print('新增cms_street：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    new_street(tbname,inserttb,'功能区')
    print('新增cms_village：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    new_village(tbname,inserttb,'功能区')

    tbname = 'cms_change_input'
    inserttb='cms_change_output'
    print('变更cms_city：'+time.strftime("%Y-%m-%d %H:%M:%S"))
    change_city(tbname,inserttb,'功能区')
    print('变更cms_county：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    change_county(tbname,inserttb,'功能区')
    print('变更cms_street：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    change_street(tbname,inserttb,'功能区')
    print('变更cms_village：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    change_village(tbname,inserttb,'功能区')

    #处理变更后的新增数据
    change_update()

    tbname = 'cms_delete_input'
    inserttb='cms_delete_output'
    print('撤销cms_village：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    delete_village(tbname,inserttb,'功能区')
    print('撤销cms_street：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    delete_street(tbname,inserttb,'功能区')
    print('撤销cms_county：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    delete_county(tbname,inserttb,'功能区')
    print('撤销cms_city：'+time.strftime("%Y-%m-%d %H:%M:%S"))
    delete_city(tbname,inserttb,'功能区')

    tbname = 'gis_new_input'
    inserttb = 'gis_new_output'
    print('新增gis_city：'+time.strftime("%Y-%m-%d %H:%M:%S"))
    new_city(tbname,inserttb,'非功能区')
    print('新增gis_county：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    new_county(tbname,inserttb,'非功能区')
    print('新增gis_street：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    new_street(tbname,inserttb,'非功能区')
    print('新增gis_village：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    new_village(tbname,inserttb,'非功能区')

    tbname = 'gis_change_input'
    inserttb='gis_change_output'
    print('变更gis_city：'+time.strftime("%Y-%m-%d %H:%M:%S"))
    change_city(tbname,inserttb,'非功能区')
    print('变更gis_county：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    change_county(tbname,inserttb,'非功能区')
    print('变更gis_street：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    change_street(tbname,inserttb,'非功能区')
    print('变更gis_village：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    change_village(tbname,inserttb,'非功能区')

    #处理变更后的新增数据
    change_update()

    tbname = 'gis_delete_input'
    inserttb='gis_delete_output'
    print('撤销gis_village：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    delete_village(tbname,inserttb,'非功能区')
    print('撤销gis_street：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    delete_street(tbname,inserttb,'非功能区')
    print('撤销gis_county：' + time.strftime("%Y-%m-%d %H:%M:%S"))
    delete_county(tbname,inserttb,'非功能区')
    print('撤销gis_city：'+time.strftime("%Y-%m-%d %H:%M:%S"))
    delete_city(tbname,inserttb,'非功能区')

    print('任务执行完成：'+time.strftime("%Y-%m-%d %H:%M:%S"))


