package com.sf.gis.java.rls.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class GdData implements Serializable {

    @Column(name = "un")
    private String un;
    @Column(name = "tp")
    private String tp;
    @Column(name = "zx")
    private String zx;
    @Column(name = "zy")
    private String zy;
    @Column(name = "ac")
    private String ac;
    @Column(name = "sp")
    private String sp;
    @Column(name = "tm")
    private String tm;
    @Column(name = "cr")
    private String cr;
    @Column(name = "ak")
    private String ak;
    @Column(name = "sl")
    private String sl;
    @Column(name = "dx")
    private String dx;
    @Column(name = "dy")
    private String dy;
    @Column(name = "state")
    private String state;
    @Column(name = "pc")
    private String pc;
    @Column(name = "ad")
    private String ad;
    @Column(name = "be")
    private String be;
    @Column(name = "sc")
    private String sc;

    public String getUn() {
        return un;
    }

    public void setUn(String un) {
        this.un = un;
    }

    public String getTp() {
        return tp;
    }

    public void setTp(String tp) {
        this.tp = tp;
    }

    public String getZx() {
        return zx;
    }

    public void setZx(String zx) {
        this.zx = zx;
    }

    public String getZy() {
        return zy;
    }

    public void setZy(String zy) {
        this.zy = zy;
    }

    public String getAc() {
        return ac;
    }

    public void setAc(String ac) {
        this.ac = ac;
    }

    public String getSp() {
        return sp;
    }

    public void setSp(String sp) {
        this.sp = sp;
    }

    public String getTm() {
        return tm;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }

    public String getCr() {
        return cr;
    }

    public void setCr(String cr) {
        this.cr = cr;
    }

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getSl() {
        return sl;
    }

    public void setSl(String sl) {
        this.sl = sl;
    }

    public String getDx() {
        return dx;
    }

    public void setDx(String dx) {
        this.dx = dx;
    }

    public String getDy() {
        return dy;
    }

    public void setDy(String dy) {
        this.dy = dy;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPc() {
        return pc;
    }

    public void setPc(String pc) {
        this.pc = pc;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getBe() {
        return be;
    }

    public void setBe(String be) {
        this.be = be;
    }

    public String getSc() {
        return sc;
    }

    public void setSc(String sc) {
        this.sc = sc;
    }

    @Override
    public String toString() {
        return "GdData{" +
                "un='" + un + '\'' +
                ", tp='" + tp + '\'' +
                ", zx='" + zx + '\'' +
                ", zy='" + zy + '\'' +
                ", ac='" + ac + '\'' +
                ", sp='" + sp + '\'' +
                ", tm='" + tm + '\'' +
                ", cr='" + cr + '\'' +
                ", ak='" + ak + '\'' +
                ", sl='" + sl + '\'' +
                ", dx='" + dx + '\'' +
                ", dy='" + dy + '\'' +
                ", state='" + state + '\'' +
                ", pc='" + pc + '\'' +
                ", ad='" + ad + '\'' +
                ", be='" + be + '\'' +
                ", sc='" + sc + '\'' +
                '}';
    }
}
