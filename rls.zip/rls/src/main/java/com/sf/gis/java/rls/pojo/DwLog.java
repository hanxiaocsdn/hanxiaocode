package com.sf.gis.java.rls.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DwLog implements Serializable {

    @Column(name = "waybill_No")
    private String waybillNo;
    @Column(name = "dest_province")
    private String destProvince;
    @Column(name = "dest_city")
    private String destCity;
    @Column(name = "dest_city_Code")
    private String destCityCode;
    @Column(name = "dest_county")
    private String destCounty;
    @Column(name = "dest_addr")
    private String destAddr;
    @Column(name = "dest_company")
    private String destCompany;
    @Column(name = "dest_telphone")
    private String destTelphone;
    @Column(name = "dest_contacts_name")
    private String destContactsName;
    @Column(name = "source_province")
    private String sourceProvince;
    @Column(name = "source_city")
    private String sourceCity;
    @Column(name = "source_city_code")
    private String sourceCityCode;
    @Column(name = "source_county")
    private String sourceCounty;
    @Column(name = "source_dept_code")
    private String sourceDeptCode;
    @Column(name = "source_addr")
    private String sourceAddr;
    @Column(name = "source_company")
    private String sourceCompany;
    @Column(name = "source_telphone")
    private String sourceTelphone;
    @Column(name = "source_contacts_name")
    private String sourceContactsName;
    @Column(name = "cargo_type_code")
    private String cargoTypeCode;
    @Column(name = "limit_type_code")
    private String limitTypeCode;
    @Column(name = "express_type_code")
    private String expressTypeCode;
    @Column(name = "weight")
    private String weight;
    @Column(name = "service_code_list")
    private String serviceCodeList;
    @Column(name = "customer_account")
    private String customerAccount;
    @Column(name = "gdesc")
    private String gdesc;
    @Column(name = "pay_type")
    private String payType;
    @Column(name = "dest_port_code")
    private String destPortCode;
    @Column(name = "dest_post_code")
    private String destPostCode;
    @Column(name = "dest_country")
    private String destCountry;
    @Column(name = "goods_value_total")
    private String goodsValueTotal;
    @Column(name = "currency_symbol")
    private String currencySymbol;
    @Column(name = "cus_batch")
    private String cusBatch;
    @Column(name = "export_declaration_method")
    private String exportDeclarationMethod;
    @Column(name = "import_declaration_method")
    private String importDeclarationMethod;
    @Column(name = "src_species_type")
    private String srcSpeciesType;
    @Column(name = "des_species_type")
    private String desSpeciesType;
    @Column(name = "goods_number")
    private String goodsNumber;
    @Column(name = "source_team_code_rev")
    private String sourceTeamCodeRev;
    @Column(name = "dest_dept_code_rev")
    private String destDeptCodeRev;
    @Column(name = "dest_team_code_rev")
    private String destTeamCodeRev;
    @Column(name = "quantity")
    private String quantity;
    @Column(name = "rev_type")
    private String revType;
    @Column(name = "channel_code")
    private String channelCode;
    @Column(name = "src_order_no")
    private String srcOrderNo;
    @Column(name = "oms_order_no")
    private String omsOrderNo;
    @Column(name = "sys_order_type")
    private String sysOrderType;
    @Column(name = "oms_order_type")
    private String omsOrderType;
    @Column(name = "extent")
    private String extent;
    @Column(name = "width")
    private String width;
    @Column(name = "height")
    private String height;
    @Column(name = "client_code")
    private String clientCode;
    @Column(name = "customer_type")
    private String customerType;
    @Column(name = "add_service_list")
    private String addServiceList;
    @Column(name = "oneself_pickup_flag")
    private String oneselfPickupFlag;
    @Column(name = "mcode")
    private String mcode;
    @Column(name = "nc_flag")
    private String ncFlag;
    @Column(name = "nc_pack")
    private String ncPack;
    @Column(name = "air_banned_tag")
    private String airBannedTag;
    @Column(name = "a_flag")
    private String aFlag;
    @Column(name = "create_time")
    private String createTime;
    @Column(name = "system")
    private String system;
    @Column(name = "trace_id")
    private String traceId;
    @Column(name = "source_transfer_code")
    private String sourceTransferCode;
    @Column(name = "source_team_code")
    private String sourceTeamCode;
    @Column(name = "dest_dept_code")
    private String destDeptCode;
    @Column(name = "dest_gis_dept_code")
    private String destGisDeptCode;
    @Column(name = "dest_dept_code_mapping")
    private String destDeptCodeMapping;
    @Column(name = "dest_team_code")
    private String destTeamCode;
    @Column(name = "dest_raw_team_code")
    private String destRawTeamCode;
    @Column(name = "dest_raw_team_code1")
    private String destRawTeamCode1;
    @Column(name = "dest_team_code_mapping")
    private String destTeamCodeMapping;
    @Column(name = "dest_transfer_code")
    private String destTransferCode;
    @Column(name = "dest_route_label")
    private String destRouteLabel;
    @Column(name = "pro_name")
    private String proName;
    @Column(name = "coding_mapping")
    private String codingMapping;
    @Column(name = "coding_mapping_out")
    private String codingMappingOut;
    @Column(name = "xb_flag")
    private String xbFlag;
    @Column(name = "send_area_code")
    private String sendAreaCode;
    @Column(name = "destination_station_code")
    private String destinationStationCode;
    @Column(name = "sx_label_dest_code")
    private String sxLabelDestCode;
    @Column(name = "sx_dest_transfer_code")
    private String sxDestTransferCode;
    @Column(name = "sx_company")
    private String sxCompany;
    @Column(name = "print_flag")
    private String printFlag;
    @Column(name = "two_dimension_code")
    private String twoDimensionCode;
    @Column(name = "pro_code")
    private String proCode;
    @Column(name = "print_icon")
    private String printIcon;
    @Column(name = "ab_flag")
    private String abFlag;
    @Column(name = "new_ab_flag")
    private String newAbFlag;
    @Column(name = "err_msg")
    private String errMsg;
    @Column(name = "check_code")
    private String checkCode;
    @Column(name = "pro_icon")
    private String proIcon;
    @Column(name = "file_icon")
    private String fileIcon;
    @Column(name = "fba_icon")
    private String fbaIcon;
    @Column(name = "icsm_icon")
    private String icsmIcon;
    @Column(name = "consign_tag")
    private String consignTag;
    @Column(name = "limit_tag")
    private String limitTag;
    @Column(name = "receipt_model_tag")
    private String receiptModelTag;
    @Column(name = "sorting_model_tag")
    private String sortingModelTag;
    @Column(name = "container_model_tag")
    private String containerModelTag;
    @Column(name = "delivery_model_tag")
    private String deliveryModelTag;
    @Column(name = "new_icon")
    private String newIcon;
    @Column(name = "hqr_level")
    private String hqrLevel;
    @Column(name = "dest_addr_key_word")
    private String destAddrKeyWord;
    @Column(name = "air_transport_icon")
    private String airTransportIcon;
    @Column(name = "cp_dest_transfer_code")
    private String cpDestTransferCode;
    @Column(name = "cp_source_transfer_code")
    private String cpSourceTransferCode;
    @Column(name = "aoi_channel")
    private String aoiChannel;
    @Column(name = "print_name_kc")
    private String printNameKc;
    @Column(name = "rong_type")
    private String rongType;
    @Column(name = "waybill_icon_list")
    private String waybillIconList;
    @Column(name = "consign_info")
    private String consignInfo;
    @Column(name = "inc_day")
    private String incDay;

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getDestProvince() {
        return destProvince;
    }

    public void setDestProvince(String destProvince) {
        this.destProvince = destProvince;
    }

    public String getDestCity() {
        return destCity;
    }

    public void setDestCity(String destCity) {
        this.destCity = destCity;
    }

    public String getDestCityCode() {
        return destCityCode;
    }

    public void setDestCityCode(String destCityCode) {
        this.destCityCode = destCityCode;
    }

    public String getDestCounty() {
        return destCounty;
    }

    public void setDestCounty(String destCounty) {
        this.destCounty = destCounty;
    }

    public String getDestAddr() {
        return destAddr;
    }

    public void setDestAddr(String destAddr) {
        this.destAddr = destAddr;
    }

    public String getDestCompany() {
        return destCompany;
    }

    public void setDestCompany(String destCompany) {
        this.destCompany = destCompany;
    }

    public String getDestTelphone() {
        return destTelphone;
    }

    public void setDestTelphone(String destTelphone) {
        this.destTelphone = destTelphone;
    }

    public String getDestContactsName() {
        return destContactsName;
    }

    public void setDestContactsName(String destContactsName) {
        this.destContactsName = destContactsName;
    }

    public String getSourceProvince() {
        return sourceProvince;
    }

    public void setSourceProvince(String sourceProvince) {
        this.sourceProvince = sourceProvince;
    }

    public String getSourceCity() {
        return sourceCity;
    }

    public void setSourceCity(String sourceCity) {
        this.sourceCity = sourceCity;
    }

    public String getSourceCityCode() {
        return sourceCityCode;
    }

    public void setSourceCityCode(String sourceCityCode) {
        this.sourceCityCode = sourceCityCode;
    }

    public String getSourceCounty() {
        return sourceCounty;
    }

    public void setSourceCounty(String sourceCounty) {
        this.sourceCounty = sourceCounty;
    }

    public String getSourceDeptCode() {
        return sourceDeptCode;
    }

    public void setSourceDeptCode(String sourceDeptCode) {
        this.sourceDeptCode = sourceDeptCode;
    }

    public String getSourceAddr() {
        return sourceAddr;
    }

    public void setSourceAddr(String sourceAddr) {
        this.sourceAddr = sourceAddr;
    }

    public String getSourceCompany() {
        return sourceCompany;
    }

    public void setSourceCompany(String sourceCompany) {
        this.sourceCompany = sourceCompany;
    }

    public String getSourceTelphone() {
        return sourceTelphone;
    }

    public void setSourceTelphone(String sourceTelphone) {
        this.sourceTelphone = sourceTelphone;
    }

    public String getSourceContactsName() {
        return sourceContactsName;
    }

    public void setSourceContactsName(String sourceContactsName) {
        this.sourceContactsName = sourceContactsName;
    }

    public String getCargoTypeCode() {
        return cargoTypeCode;
    }

    public void setCargoTypeCode(String cargoTypeCode) {
        this.cargoTypeCode = cargoTypeCode;
    }

    public String getLimitTypeCode() {
        return limitTypeCode;
    }

    public void setLimitTypeCode(String limitTypeCode) {
        this.limitTypeCode = limitTypeCode;
    }

    public String getExpressTypeCode() {
        return expressTypeCode;
    }

    public void setExpressTypeCode(String expressTypeCode) {
        this.expressTypeCode = expressTypeCode;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getServiceCodeList() {
        return serviceCodeList;
    }

    public void setServiceCodeList(String serviceCodeList) {
        this.serviceCodeList = serviceCodeList;
    }

    public String getCustomerAccount() {
        return customerAccount;
    }

    public void setCustomerAccount(String customerAccount) {
        this.customerAccount = customerAccount;
    }

    public String getGdesc() {
        return gdesc;
    }

    public void setGdesc(String gdesc) {
        this.gdesc = gdesc;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getDestPortCode() {
        return destPortCode;
    }

    public void setDestPortCode(String destPortCode) {
        this.destPortCode = destPortCode;
    }

    public String getDestPostCode() {
        return destPostCode;
    }

    public void setDestPostCode(String destPostCode) {
        this.destPostCode = destPostCode;
    }

    public String getDestCountry() {
        return destCountry;
    }

    public void setDestCountry(String destCountry) {
        this.destCountry = destCountry;
    }

    public String getGoodsValueTotal() {
        return goodsValueTotal;
    }

    public void setGoodsValueTotal(String goodsValueTotal) {
        this.goodsValueTotal = goodsValueTotal;
    }

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    public String getCusBatch() {
        return cusBatch;
    }

    public void setCusBatch(String cusBatch) {
        this.cusBatch = cusBatch;
    }

    public String getExportDeclarationMethod() {
        return exportDeclarationMethod;
    }

    public void setExportDeclarationMethod(String exportDeclarationMethod) {
        this.exportDeclarationMethod = exportDeclarationMethod;
    }

    public String getImportDeclarationMethod() {
        return importDeclarationMethod;
    }

    public void setImportDeclarationMethod(String importDeclarationMethod) {
        this.importDeclarationMethod = importDeclarationMethod;
    }

    public String getSrcSpeciesType() {
        return srcSpeciesType;
    }

    public void setSrcSpeciesType(String srcSpeciesType) {
        this.srcSpeciesType = srcSpeciesType;
    }

    public String getDesSpeciesType() {
        return desSpeciesType;
    }

    public void setDesSpeciesType(String desSpeciesType) {
        this.desSpeciesType = desSpeciesType;
    }

    public String getGoodsNumber() {
        return goodsNumber;
    }

    public void setGoodsNumber(String goodsNumber) {
        this.goodsNumber = goodsNumber;
    }

    public String getSourceTeamCodeRev() {
        return sourceTeamCodeRev;
    }

    public void setSourceTeamCodeRev(String sourceTeamCodeRev) {
        this.sourceTeamCodeRev = sourceTeamCodeRev;
    }

    public String getDestDeptCodeRev() {
        return destDeptCodeRev;
    }

    public void setDestDeptCodeRev(String destDeptCodeRev) {
        this.destDeptCodeRev = destDeptCodeRev;
    }

    public String getDestTeamCodeRev() {
        return destTeamCodeRev;
    }

    public void setDestTeamCodeRev(String destTeamCodeRev) {
        this.destTeamCodeRev = destTeamCodeRev;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getRevType() {
        return revType;
    }

    public void setRevType(String revType) {
        this.revType = revType;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getSrcOrderNo() {
        return srcOrderNo;
    }

    public void setSrcOrderNo(String srcOrderNo) {
        this.srcOrderNo = srcOrderNo;
    }

    public String getOmsOrderNo() {
        return omsOrderNo;
    }

    public void setOmsOrderNo(String omsOrderNo) {
        this.omsOrderNo = omsOrderNo;
    }

    public String getSysOrderType() {
        return sysOrderType;
    }

    public void setSysOrderType(String sysOrderType) {
        this.sysOrderType = sysOrderType;
    }

    public String getOmsOrderType() {
        return omsOrderType;
    }

    public void setOmsOrderType(String omsOrderType) {
        this.omsOrderType = omsOrderType;
    }

    public String getExtent() {
        return extent;
    }

    public void setExtent(String extent) {
        this.extent = extent;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getClientCode() {
        return clientCode;
    }

    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getAddServiceList() {
        return addServiceList;
    }

    public void setAddServiceList(String addServiceList) {
        this.addServiceList = addServiceList;
    }

    public String getOneselfPickupFlag() {
        return oneselfPickupFlag;
    }

    public void setOneselfPickupFlag(String oneselfPickupFlag) {
        this.oneselfPickupFlag = oneselfPickupFlag;
    }

    public String getMcode() {
        return mcode;
    }

    public void setMcode(String mcode) {
        this.mcode = mcode;
    }

    public String getNcFlag() {
        return ncFlag;
    }

    public void setNcFlag(String ncFlag) {
        this.ncFlag = ncFlag;
    }

    public String getNcPack() {
        return ncPack;
    }

    public void setNcPack(String ncPack) {
        this.ncPack = ncPack;
    }

    public String getAirBannedTag() {
        return airBannedTag;
    }

    public void setAirBannedTag(String airBannedTag) {
        this.airBannedTag = airBannedTag;
    }

    public String getaFlag() {
        return aFlag;
    }

    public void setaFlag(String aFlag) {
        this.aFlag = aFlag;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getSourceTransferCode() {
        return sourceTransferCode;
    }

    public void setSourceTransferCode(String sourceTransferCode) {
        this.sourceTransferCode = sourceTransferCode;
    }

    public String getSourceTeamCode() {
        return sourceTeamCode;
    }

    public void setSourceTeamCode(String sourceTeamCode) {
        this.sourceTeamCode = sourceTeamCode;
    }

    public String getDestDeptCode() {
        return destDeptCode;
    }

    public void setDestDeptCode(String destDeptCode) {
        this.destDeptCode = destDeptCode;
    }

    public String getDestGisDeptCode() {
        return destGisDeptCode;
    }

    public void setDestGisDeptCode(String destGisDeptCode) {
        this.destGisDeptCode = destGisDeptCode;
    }

    public String getDestDeptCodeMapping() {
        return destDeptCodeMapping;
    }

    public void setDestDeptCodeMapping(String destDeptCodeMapping) {
        this.destDeptCodeMapping = destDeptCodeMapping;
    }

    public String getDestTeamCode() {
        return destTeamCode;
    }

    public void setDestTeamCode(String destTeamCode) {
        this.destTeamCode = destTeamCode;
    }

    public String getDestRawTeamCode() {
        return destRawTeamCode;
    }

    public void setDestRawTeamCode(String destRawTeamCode) {
        this.destRawTeamCode = destRawTeamCode;
    }

    public String getDestRawTeamCode1() {
        return destRawTeamCode1;
    }

    public void setDestRawTeamCode1(String destRawTeamCode1) {
        this.destRawTeamCode1 = destRawTeamCode1;
    }

    public String getDestTeamCodeMapping() {
        return destTeamCodeMapping;
    }

    public void setDestTeamCodeMapping(String destTeamCodeMapping) {
        this.destTeamCodeMapping = destTeamCodeMapping;
    }

    public String getDestTransferCode() {
        return destTransferCode;
    }

    public void setDestTransferCode(String destTransferCode) {
        this.destTransferCode = destTransferCode;
    }

    public String getDestRouteLabel() {
        return destRouteLabel;
    }

    public void setDestRouteLabel(String destRouteLabel) {
        this.destRouteLabel = destRouteLabel;
    }

    public String getProName() {
        return proName;
    }

    public void setProName(String proName) {
        this.proName = proName;
    }

    public String getCodingMapping() {
        return codingMapping;
    }

    public void setCodingMapping(String codingMapping) {
        this.codingMapping = codingMapping;
    }

    public String getCodingMappingOut() {
        return codingMappingOut;
    }

    public void setCodingMappingOut(String codingMappingOut) {
        this.codingMappingOut = codingMappingOut;
    }

    public String getXbFlag() {
        return xbFlag;
    }

    public void setXbFlag(String xbFlag) {
        this.xbFlag = xbFlag;
    }

    public String getSendAreaCode() {
        return sendAreaCode;
    }

    public void setSendAreaCode(String sendAreaCode) {
        this.sendAreaCode = sendAreaCode;
    }

    public String getDestinationStationCode() {
        return destinationStationCode;
    }

    public void setDestinationStationCode(String destinationStationCode) {
        this.destinationStationCode = destinationStationCode;
    }

    public String getSxLabelDestCode() {
        return sxLabelDestCode;
    }

    public void setSxLabelDestCode(String sxLabelDestCode) {
        this.sxLabelDestCode = sxLabelDestCode;
    }

    public String getSxDestTransferCode() {
        return sxDestTransferCode;
    }

    public void setSxDestTransferCode(String sxDestTransferCode) {
        this.sxDestTransferCode = sxDestTransferCode;
    }

    public String getSxCompany() {
        return sxCompany;
    }

    public void setSxCompany(String sxCompany) {
        this.sxCompany = sxCompany;
    }

    public String getPrintFlag() {
        return printFlag;
    }

    public void setPrintFlag(String printFlag) {
        this.printFlag = printFlag;
    }

    public String getTwoDimensionCode() {
        return twoDimensionCode;
    }

    public void setTwoDimensionCode(String twoDimensionCode) {
        this.twoDimensionCode = twoDimensionCode;
    }

    public String getProCode() {
        return proCode;
    }

    public void setProCode(String proCode) {
        this.proCode = proCode;
    }

    public String getPrintIcon() {
        return printIcon;
    }

    public void setPrintIcon(String printIcon) {
        this.printIcon = printIcon;
    }

    public String getAbFlag() {
        return abFlag;
    }

    public void setAbFlag(String abFlag) {
        this.abFlag = abFlag;
    }

    public String getNewAbFlag() {
        return newAbFlag;
    }

    public void setNewAbFlag(String newAbFlag) {
        this.newAbFlag = newAbFlag;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    public String getProIcon() {
        return proIcon;
    }

    public void setProIcon(String proIcon) {
        this.proIcon = proIcon;
    }

    public String getFileIcon() {
        return fileIcon;
    }

    public void setFileIcon(String fileIcon) {
        this.fileIcon = fileIcon;
    }

    public String getFbaIcon() {
        return fbaIcon;
    }

    public void setFbaIcon(String fbaIcon) {
        this.fbaIcon = fbaIcon;
    }

    public String getIcsmIcon() {
        return icsmIcon;
    }

    public void setIcsmIcon(String icsmIcon) {
        this.icsmIcon = icsmIcon;
    }

    public String getConsignTag() {
        return consignTag;
    }

    public void setConsignTag(String consignTag) {
        this.consignTag = consignTag;
    }

    public String getLimitTag() {
        return limitTag;
    }

    public void setLimitTag(String limitTag) {
        this.limitTag = limitTag;
    }

    public String getReceiptModelTag() {
        return receiptModelTag;
    }

    public void setReceiptModelTag(String receiptModelTag) {
        this.receiptModelTag = receiptModelTag;
    }

    public String getSortingModelTag() {
        return sortingModelTag;
    }

    public void setSortingModelTag(String sortingModelTag) {
        this.sortingModelTag = sortingModelTag;
    }

    public String getContainerModelTag() {
        return containerModelTag;
    }

    public void setContainerModelTag(String containerModelTag) {
        this.containerModelTag = containerModelTag;
    }

    public String getDeliveryModelTag() {
        return deliveryModelTag;
    }

    public void setDeliveryModelTag(String deliveryModelTag) {
        this.deliveryModelTag = deliveryModelTag;
    }

    public String getNewIcon() {
        return newIcon;
    }

    public void setNewIcon(String newIcon) {
        this.newIcon = newIcon;
    }

    public String getHqrLevel() {
        return hqrLevel;
    }

    public void setHqrLevel(String hqrLevel) {
        this.hqrLevel = hqrLevel;
    }

    public String getDestAddrKeyWord() {
        return destAddrKeyWord;
    }

    public void setDestAddrKeyWord(String destAddrKeyWord) {
        this.destAddrKeyWord = destAddrKeyWord;
    }

    public String getAirTransportIcon() {
        return airTransportIcon;
    }

    public void setAirTransportIcon(String airTransportIcon) {
        this.airTransportIcon = airTransportIcon;
    }

    public String getCpDestTransferCode() {
        return cpDestTransferCode;
    }

    public void setCpDestTransferCode(String cpDestTransferCode) {
        this.cpDestTransferCode = cpDestTransferCode;
    }

    public String getCpSourceTransferCode() {
        return cpSourceTransferCode;
    }

    public void setCpSourceTransferCode(String cpSourceTransferCode) {
        this.cpSourceTransferCode = cpSourceTransferCode;
    }

    public String getAoiChannel() {
        return aoiChannel;
    }

    public void setAoiChannel(String aoiChannel) {
        this.aoiChannel = aoiChannel;
    }

    public String getPrintNameKc() {
        return printNameKc;
    }

    public void setPrintNameKc(String printNameKc) {
        this.printNameKc = printNameKc;
    }

    public String getRongType() {
        return rongType;
    }

    public void setRongType(String rongType) {
        this.rongType = rongType;
    }

    public String getWaybillIconList() {
        return waybillIconList;
    }

    public void setWaybillIconList(String waybillIconList) {
        this.waybillIconList = waybillIconList;
    }

    public String getConsignInfo() {
        return consignInfo;
    }

    public void setConsignInfo(String consignInfo) {
        this.consignInfo = consignInfo;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "DwLog{" +
                "waybillNo='" + waybillNo + '\'' +
                ", destProvince='" + destProvince + '\'' +
                ", destCity='" + destCity + '\'' +
                ", destCityCode='" + destCityCode + '\'' +
                ", destCounty='" + destCounty + '\'' +
                ", destAddr='" + destAddr + '\'' +
                ", destCompany='" + destCompany + '\'' +
                ", destTelphone='" + destTelphone + '\'' +
                ", destContactsName='" + destContactsName + '\'' +
                ", sourceProvince='" + sourceProvince + '\'' +
                ", sourceCity='" + sourceCity + '\'' +
                ", sourceCityCode='" + sourceCityCode + '\'' +
                ", sourceCounty='" + sourceCounty + '\'' +
                ", sourceDeptCode='" + sourceDeptCode + '\'' +
                ", sourceAddr='" + sourceAddr + '\'' +
                ", sourceCompany='" + sourceCompany + '\'' +
                ", sourceTelphone='" + sourceTelphone + '\'' +
                ", sourceContactsName='" + sourceContactsName + '\'' +
                ", cargoTypeCode='" + cargoTypeCode + '\'' +
                ", limitTypeCode='" + limitTypeCode + '\'' +
                ", expressTypeCode='" + expressTypeCode + '\'' +
                ", weight='" + weight + '\'' +
                ", serviceCodeList='" + serviceCodeList + '\'' +
                ", customerAccount='" + customerAccount + '\'' +
                ", gdesc='" + gdesc + '\'' +
                ", payType='" + payType + '\'' +
                ", destPortCode='" + destPortCode + '\'' +
                ", destPostCode='" + destPostCode + '\'' +
                ", destCountry='" + destCountry + '\'' +
                ", goodsValueTotal='" + goodsValueTotal + '\'' +
                ", currencySymbol='" + currencySymbol + '\'' +
                ", cusBatch='" + cusBatch + '\'' +
                ", exportDeclarationMethod='" + exportDeclarationMethod + '\'' +
                ", importDeclarationMethod='" + importDeclarationMethod + '\'' +
                ", srcSpeciesType='" + srcSpeciesType + '\'' +
                ", desSpeciesType='" + desSpeciesType + '\'' +
                ", goodsNumber='" + goodsNumber + '\'' +
                ", sourceTeamCodeRev='" + sourceTeamCodeRev + '\'' +
                ", destDeptCodeRev='" + destDeptCodeRev + '\'' +
                ", destTeamCodeRev='" + destTeamCodeRev + '\'' +
                ", quantity='" + quantity + '\'' +
                ", revType='" + revType + '\'' +
                ", channelCode='" + channelCode + '\'' +
                ", srcOrderNo='" + srcOrderNo + '\'' +
                ", omsOrderNo='" + omsOrderNo + '\'' +
                ", sysOrderType='" + sysOrderType + '\'' +
                ", omsOrderType='" + omsOrderType + '\'' +
                ", extent='" + extent + '\'' +
                ", width='" + width + '\'' +
                ", height='" + height + '\'' +
                ", clientCode='" + clientCode + '\'' +
                ", customerType='" + customerType + '\'' +
                ", addServiceList='" + addServiceList + '\'' +
                ", oneselfPickupFlag='" + oneselfPickupFlag + '\'' +
                ", mcode='" + mcode + '\'' +
                ", ncFlag='" + ncFlag + '\'' +
                ", ncPack='" + ncPack + '\'' +
                ", airBannedTag='" + airBannedTag + '\'' +
                ", aFlag='" + aFlag + '\'' +
                ", createTime='" + createTime + '\'' +
                ", system='" + system + '\'' +
                ", traceId='" + traceId + '\'' +
                ", sourceTransferCode='" + sourceTransferCode + '\'' +
                ", sourceTeamCode='" + sourceTeamCode + '\'' +
                ", destDeptCode='" + destDeptCode + '\'' +
                ", destGisDeptCode='" + destGisDeptCode + '\'' +
                ", destDeptCodeMapping='" + destDeptCodeMapping + '\'' +
                ", destTeamCode='" + destTeamCode + '\'' +
                ", destRawTeamCode='" + destRawTeamCode + '\'' +
                ", destRawTeamCode1='" + destRawTeamCode1 + '\'' +
                ", destTeamCodeMapping='" + destTeamCodeMapping + '\'' +
                ", destTransferCode='" + destTransferCode + '\'' +
                ", destRouteLabel='" + destRouteLabel + '\'' +
                ", proName='" + proName + '\'' +
                ", codingMapping='" + codingMapping + '\'' +
                ", codingMappingOut='" + codingMappingOut + '\'' +
                ", xbFlag='" + xbFlag + '\'' +
                ", sendAreaCode='" + sendAreaCode + '\'' +
                ", destinationStationCode='" + destinationStationCode + '\'' +
                ", sxLabelDestCode='" + sxLabelDestCode + '\'' +
                ", sxDestTransferCode='" + sxDestTransferCode + '\'' +
                ", sxCompany='" + sxCompany + '\'' +
                ", printFlag='" + printFlag + '\'' +
                ", twoDimensionCode='" + twoDimensionCode + '\'' +
                ", proCode='" + proCode + '\'' +
                ", printIcon='" + printIcon + '\'' +
                ", abFlag='" + abFlag + '\'' +
                ", newAbFlag='" + newAbFlag + '\'' +
                ", errMsg='" + errMsg + '\'' +
                ", checkCode='" + checkCode + '\'' +
                ", proIcon='" + proIcon + '\'' +
                ", fileIcon='" + fileIcon + '\'' +
                ", fbaIcon='" + fbaIcon + '\'' +
                ", icsmIcon='" + icsmIcon + '\'' +
                ", consignTag='" + consignTag + '\'' +
                ", limitTag='" + limitTag + '\'' +
                ", receiptModelTag='" + receiptModelTag + '\'' +
                ", sortingModelTag='" + sortingModelTag + '\'' +
                ", containerModelTag='" + containerModelTag + '\'' +
                ", deliveryModelTag='" + deliveryModelTag + '\'' +
                ", newIcon='" + newIcon + '\'' +
                ", hqrLevel='" + hqrLevel + '\'' +
                ", destAddrKeyWord='" + destAddrKeyWord + '\'' +
                ", airTransportIcon='" + airTransportIcon + '\'' +
                ", cpDestTransferCode='" + cpDestTransferCode + '\'' +
                ", cpSourceTransferCode='" + cpSourceTransferCode + '\'' +
                ", aoiChannel='" + aoiChannel + '\'' +
                ", printNameKc='" + printNameKc + '\'' +
                ", rongType='" + rongType + '\'' +
                ", waybillIconList='" + waybillIconList + '\'' +
                ", consignInfo='" + consignInfo + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
