package com.sf.gis.java.rls.controller;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.rls.pojo.DwLog;
import com.sf.gis.java.rls.service.DwLogAnalysisService;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Row;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 日志解析控制器
 * 任务ID：365193
 * @author 01370539 Created On: Aug.27 2021
 */
public class DwLogAnalysisController {
	private static final Logger logger = LoggerFactory.getLogger(DwLogAnalysisController.class);

	private  final DwLogAnalysisService dwLogAnalysisService = new DwLogAnalysisService();

	public void process(String startDate, String endDate) {
		logger.error("process start. statDate - {}", startDate);

		// 初始化spark
		SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());

		JavaRDD<Row> rddRow = dwLogAnalysisService.loadOrigLog(sparkInfo, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
		rddRow.take(1).forEach(row -> logger.error("log -> {}", row.getString(0)));

		JavaRDD<DwLog> rddDwLog = dwLogAnalysisService.analysis(rddRow, startDate).filter(temp -> {
			String createTime = DateUtil.formatDate(DateUtil.getDateFromStr(temp.getCreateTime()), "yyyyMMdd");
			return startDate.equals(createTime);
		}).persist(StorageLevel.MEMORY_AND_DISK_SER());

        DataUtil.saveOverwrite(sparkInfo, "dm_gis.rls_log_dw", DwLog.class, rddDwLog, "inc_day");
		rddRow.unpersist();

		logger.error("process: end ");
	}
}
