package com.sf.gis.java.rls.controller;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.rls.constant.RlsConstant;
import com.sf.gis.java.rls.pojo.FwLog;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import static ru.yandex.clickhouse.domain.ClickHouseDataType.Array;

public class NlsLocationWifiHbaseToHiveController implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(NlsLocationWifiHbaseToHiveController.class);

    public void process(String fileName) {
        // 初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext jsc = sparkInfo.getContext();
        SparkSession ss = sparkInfo.getSession();

        // 加载配置信息
        Properties confInfo = ConfigUtil.loadPropertiesConfiguration(fileName);
        logger.error("confInfo:{}", confInfo.toString());
        Broadcast<Properties> confInfoBc = jsc.broadcast(confInfo);
        List<Integer> list = new ArrayList<>();
        for (int i=1;i<=400;i++){
            list.add(i);
        }
        JavaRDD<Integer> rdd = jsc.parallelize(list,400);
        rdd.mapPartitions(part -> {
            List<Integer> tag = new ArrayList<>();
            Properties prop = confInfoBc.value();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.wifi.table");
            String family = prop.getProperty("hbase.gis.family");
            //String column = prop.getProperty("hbase.gis.column");
            //int batchSize = Integer.parseInt(prop.getProperty("batchSize"));
            int count = 0;
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            try {
                Scan scan = new Scan();
                ResultScanner resultScan = table.getScanner(scan);
                Iterator<Result> iter = resultScan.iterator();
                List<Result> list1 = new ArrayList<>();
                while(iter.hasNext()){
                    list1.add(iter.next());
                }
            } catch (Exception e) {
                logger.error("error .", e);
            } finally {
                if (table != null) {
                    table.close();
                }
                if (table != null) {
                    table.close();
                }
            }
            tag.add(count);
            return tag.iterator();
        });
        //logger.error("delete data " + cnt);
        ss.stop();
    }

}
