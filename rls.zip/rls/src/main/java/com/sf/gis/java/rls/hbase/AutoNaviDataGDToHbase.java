package com.sf.gis.java.rls.hbase;

import com.sf.gis.java.rls.controller.AutoNaviDataGDToHbaseController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AutoNaviDataGDToHbase {
    public static Logger logger = LoggerFactory.getLogger(AutoNaviDataGDToHbase.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{}, endDate:{}", startDate, endDate);
        new AutoNaviDataGDToHbaseController().process("gdhive2hbase.properties", startDate, endDate);
        logger.error("process end");
    }
}
