package com.sf.gis.java.rls.app;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.rls.controller.DwLogAnalysisController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 日志解析应用
 * @author 01370539 Created On: May.07 2021
 */
public class DwLogAnalysisApp {
	private static final Logger logger = LoggerFactory.getLogger(DwLogAnalysisApp.class);

	public static void main(String[] args) {
		String startDate;
		String endDate;
		if (args != null && args.length >= 2) {
			startDate = args[0];
			endDate = args[1];
		} else {
			String curDate = DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY);
			startDate = DateUtil.getDayBefore(curDate, FixedConstant.DATE_FORMATE_INCDAY, 1);
			endDate = curDate;
		}

		if (!startDate.matches("20\\d{6}") || !endDate.matches("20\\d{6}")) {
			logger.error("date format must be yyyyMMdd, startDate - {}, endDate - {}", startDate, endDate);
			System.exit(0);
		}

		new DwLogAnalysisController().process(startDate, endDate);
	}
}
