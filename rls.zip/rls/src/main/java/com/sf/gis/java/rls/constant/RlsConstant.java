package com.sf.gis.java.rls.constant;

/**
 * 常量类
 * @author 01370539 Created On: May.07 2021
 */
public class RlsConstant {
	public static final String FILTER_WAYBILL = "273651966947"; // 统计时要过滤的运单号

	public static final String ZC_TYPE_210 = "210";
	public static final String ZC_TYPE_201 = "201";

	public static final String SITE_FW = "0";

	public static final String FW_LOG_PREFIX ="fwb";

	public static final String GD_LOG_PREFIX ="gdb";
}
