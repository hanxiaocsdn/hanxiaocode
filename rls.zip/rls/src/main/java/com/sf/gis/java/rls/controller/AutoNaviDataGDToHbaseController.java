package com.sf.gis.java.rls.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.rls.constant.RlsConstant;
import com.sf.gis.java.rls.pojo.FwLog;
import com.sf.gis.java.rls.pojo.GdData;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

public class AutoNaviDataGDToHbaseController implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(AutoNaviDataGDToHbaseController.class);

    public void process(String fileName, String startDate, String endDate) {
        // 初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext jsc = sparkInfo.getContext();
        SparkSession ss = sparkInfo.getSession();

        // 加载配置信息
        Properties confInfo = ConfigUtil.loadPropertiesConfiguration(fileName);
        logger.error("confInfo:{}", confInfo.toString());
        Broadcast<Properties> confInfoBc = jsc.broadcast(confInfo);

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        for (String date : dates) {
            logger.error("date:{}", date);

            JavaRDD<GdData> gdDataRdd = loadData(ss, jsc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("gdDataRdd cnt:{}", gdDataRdd.count());
            gdDataRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<GdData> fixgdDataRdd = gdDataRdd.map(o -> {
                for (Field f : o.getClass().getDeclaredFields()) {
                    f.setAccessible(true);
                    if (StringUtils.equals(f.getType().toString(),"class java.lang.String") && f.get(o) == null) { //若字段为空，给该属性赋为空字符串
                        f.set(o, "");
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("fixgdDataRdd cnt:{}", fixgdDataRdd.count());
            fixgdDataRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            gdDataRdd.unpersist();

            int cnt = fixgdDataRdd.mapPartitions(part -> {
                List<Integer> tag = new ArrayList<>();
                Properties prop = confInfoBc.value();
                HbaseUtil.setProperties(prop);
                String tableName = prop.getProperty("hbase.gis.tloc.human.history.table");
                int batchSize = Integer.parseInt(prop.getProperty("batchSize"));
                int count = 0;
                Connection conn = HbaseUtil.getConnection();
                Table table = HbaseUtil.getTable(conn, tableName);
                try {
                    List<Delete> deleteList = new ArrayList<>();
                    while (part.hasNext()) {
                        GdData o = part.next();
                        count++;
                        //用户工号
                        String un = o.getUn();
                        //时间戳
                        String tm = o.getTm();
                        //传入时间戳，得到类似格式：20160223,推送过来的数据只到秒级,需要*1000，做到毫秒
                        long tmTemp = Long.parseLong(tm)*1000;
                        String trunc = DateUtil.truncTime(tmTemp+"");
                        String ak = o.getAk();
                        //100个预分区
//                        String md5Key = un + "_" + trunc + "_" +ak + "_" +tm  ;
//                        String rowKey = HbaseUtil.getKeyStr(RlsConstant.GD_LOG_PREFIX + "_" + md5Key, 100);
                        String md5Key = un + "_" + trunc + "_" +ak ;
                        String rowKey = SaltUtil.generateSaltNew(md5Key, 100) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;
                        Delete delete = new Delete(Bytes.toBytes(rowKey));
                        deleteList.add(delete);
                        if (deleteList.size() >= batchSize) {
                            HbaseUtil.delete(table, deleteList);
                            deleteList.clear();
                        }
                    }
                    if (!deleteList.isEmpty()) {
                        HbaseUtil.delete(table, deleteList);
                    }
                } catch (Exception e) {
                    logger.error("error .", e);
                } finally {
                    if (table != null) {
                        table.close();
                    }
                }
                tag.add(count);
                return tag.iterator();
            }).reduce((a, b) -> a + b);
            logger.error("delete data " + cnt);

            int size = fixgdDataRdd.mapPartitions(iter -> {
                List<Integer> tag = new ArrayList<>();
                Properties prop = confInfoBc.value();
                HbaseUtil.setProperties(prop);
                String tableName = prop.getProperty("hbase.gis.tloc.human.history.table");
                String family = prop.getProperty("hbase.gis.family");
                String columns = prop.getProperty("hbase.gis.column");
                int batchSize = Integer.parseInt(prop.getProperty("batchSize"));
                logger.error("begin put to hbase ");
                int count = 0;
                Connection conn = HbaseUtil.getConnection();
                Table table = HbaseUtil.getTable(conn, tableName);
                try {
                    List<Put> putList = new ArrayList<>();
                    while (iter.hasNext()) {
                        GdData o = iter.next();
                        count++;
                        //用户工号
                        String un = o.getUn();
                        String tp = o.getTp();
                        String zx = o.getZx();
                        String zy = o.getZy();
                        String ac = o.getAc();
                        String sp = o.getSp();
                        //时间戳
                        String tm = o.getTm();
                        String cr = o.getCr();
                        String ak = o.getAk();

                        String sl = o.getSl();
                        String dx = o.getDx();
                        String dy = o.getDy();
                        String state = o.getState();
                        String pc = o.getPc();
                        String ad = o.getAd();
                        String be = o.getBe();
                        String sc = o.getSc();
                        //传入时间戳，得到类似格式：20160223,推送过来的数据只到秒级,需要*1000，做到毫秒
                        long tmTemp = Long.parseLong(tm)*1000;
                        String trunc = DateUtil.truncTime(tmTemp+"");

                        //100个预分区
//                        String md5Key = un + "_" + trunc + "_" +ak + "_" +tm  ;
//                        String rowKey = HbaseUtil.getKeyStr(RlsConstant.GD_LOG_PREFIX + "_" + md5Key, 100);
                        String md5Key = un + "_" + trunc + "_" +ak ;
                        String rowKey = SaltUtil.generateSaltNew(md5Key, 100) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;
                        HashMap<String, String> valueMap = new HashMap<>();
                        valueMap.put("un", un);
                        valueMap.put("tp", tp);
                        valueMap.put("zx", zx);
                        valueMap.put("zy", zy);
                        valueMap.put("ac", ac);
                        valueMap.put("sp", sp);
                        valueMap.put("tm", tm);
                        valueMap.put("cr", cr);
                        valueMap.put("ak", ak);
                        valueMap.put("sl", sl);
                        valueMap.put("dx", dx);
                        valueMap.put("dy", dy);
                        valueMap.put("state", state);
                        valueMap.put("pc", pc);
                        valueMap.put("ad", ad);
                        valueMap.put("be", be);
                        valueMap.put("sc", sc);
                        Put put = new Put(Bytes.toBytes(rowKey));
                        for(String column : columns.split(":")) {
                            String value = valueMap.get(column);
                            try {
                                put.addColumn(Bytes.toBytes(family), Bytes.toBytes(column), Bytes.toBytes(value));
                            } catch (Exception e){
                                throw  new RuntimeException("rowkey:"+rowKey+",column:"+column+",value:"+value);
                            }
                        }
                        putList.add(put);
                        if (putList.size() >= batchSize) {
                            HbaseUtil.save(table, putList);
                            putList.clear();
                        }
                    }
                    if (!putList.isEmpty()) {
                        HbaseUtil.save(table, putList);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (table != null) {
                        table.close();
                    }
                }
                tag.add(count);
                return tag.iterator();
            }).reduce((a, b) -> a + b);
            logger.error("insert data " + size);

            /*JavaRDD<JSONObject> res = fixgdDataRdd.map(o -> {
                Properties prop = confInfoBc.value();
                HbaseUtil.setProperties(prop);
                String tableName = prop.getProperty("hbase.gis.tloc.human.history.table");
                String family = prop.getProperty("hbase.gis.family");
                String columns = prop.getProperty("hbase.gis.column");
                Connection conn = HbaseUtil.getConnection();
                Table table = HbaseUtil.getTable(conn, tableName);
                JSONObject json = new JSONObject();
                try {
                    //时间戳
                    String tm = o.getTm();
                    //用户工号
                    String un = o.getUn();
                    //传入时间戳，得到类似格式：20160223,推送过来的数据只到秒级,需要*1000，做到毫秒
                    long tmTemp = Long.parseLong(tm)*1000;
                    String trunc = DateUtil.truncTime(tmTemp+"");
                    String ak = o.getAk();
                    //100个预分区
//                    String md5Key = un + "_" + trunc + "_" +ak + "_" +tm  ;
//                    String rowKey = HbaseUtil.getKeyStr(RlsConstant.GD_LOG_PREFIX + "_" + md5Key, 100);
                    String md5Key = un + "_" + trunc + "_" +ak ;
                    String rowKey = SaltUtil.generateSaltNew(md5Key, 100) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;
                    Result result = HbaseUtil.getByKey(table,rowKey);
                    json.put("rowKey",rowKey);
                    for(String column_name : columns.split(":")) {
                        try {
                            String column_value = Bytes.toString(result.getValue(family.getBytes(),column_name.getBytes()));
                            json.put(column_name,column_value);
                        } catch (Exception e){
                            throw  new RuntimeException("rowkey:"+rowKey+",column:"+column_name);
                        }
                    }
                } catch (Exception e) {
                    logger.error("error .", e);
                } finally {
                    if (table != null) {
                        table.close();
                    }
                }
                return json;
            });
            logger.error("res cnt:{}", res.count());
            res.take(3000).forEach(o -> logger.error(JSON.toJSONString(o)));*/

            fixgdDataRdd.unpersist();
        }
        ss.stop();
    }

    public JavaRDD<GdData> loadData(SparkSession ss, JavaSparkContext jsc, String date) {
        String sql = String.format("SELECT un,tp,zx,zy,cast(ac as int) as ac,cast(sp as float) as sp,tm,cr,ak,0 as sl,-1 as dx,-1 as dy,-1 as state,0 as pc,'0' as ad,'0' as be,'0' as sc FROM dm_gis.auto_navi_data_gd_res where inc_day = '%s'" +
                "and (un is not null and un <> '')" +
                "and (tm is not null and tm <> '')", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(ss, jsc, sql, GdData.class);
    }

}
