package com.sf.gis.java.rls.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.rls.pojo.DwLog;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 日志解析服务
 * @author 01370539 Created On: May.07 2021
 */
public class DwLogAnalysisService {
	private static final Logger logger = LoggerFactory.getLogger(DwLogAnalysisService.class);

    /**
     * 加载原始日志
     * @param sparkInfo spark相关信息
     * @param startDate 加载某一周期内的数据，周期开始时间
     * @param endDate 加载某一周期内的数据，周期结束时间
     * @return 原始日志
     */
	public JavaRDD<Row> loadOrigLog(SparkInfo sparkInfo, String startDate, String endDate) {
//		String sql = "select log from dm_gis.rls_log_kafka_dw where inc_day between '" + startDate + "' and '" + endDate + "'";
		String sql = String.format("select log from dm_gis.rls_log_kafka_dw where inc_day between '%s' and '%s' and DATE_FORMAT(get_json_object(log,'$.createTime'), 'yyyyMMdd') = '%s'",startDate,endDate, startDate);
        return DataUtil.loadData(sparkInfo.getSession(), sql);
	}

    /**
     * 解析日志
     * @param rddRow 日志数据
     * @param statDate 只解析改解析的日志，此日志的过滤时间
     * @return 解析完成的日志数据
     */
	public JavaRDD<DwLog> analysis(JavaRDD<Row> rddRow, String statDate) {
		logger.error("analysis log, analysis count: {}", rddRow.count());

		return rddRow.map(row -> {
			DwLog dwLog = new DwLog();
			if (StringUtils.isNotEmpty(row.getString(0))) {
				JSONObject json = JSONObject.parseObject(row.getString(0));
				dwLog.setIncDay(statDate);
                dwLog.setCreateTime(json.getString("createTime"));
				JSONObject messageJson = json.getJSONObject("message");
				if (messageJson != null) {
					JSONArray reqJsonArr = messageJson.getJSONArray("request");
					if (reqJsonArr != null && reqJsonArr.size() > 0) {
                        JSONObject reqJson = reqJsonArr.getJSONObject(0);
                        if (reqJson != null) {
                            dwLog.setWaybillNo(reqJson.getString("waybillNo"));
                            dwLog.setDestProvince(reqJson.getString("destProvince"));
                            dwLog.setDestCity(reqJson.getString("destCity"));
                            dwLog.setDestCityCode(reqJson.getString("destCityCode"));
                            dwLog.setDestCounty(reqJson.getString("destCounty"));
                            dwLog.setDestAddr(reqJson.getString("destAddr"));
                            dwLog.setDestCompany(reqJson.getString("destCompany"));
                            dwLog.setDestTelphone(reqJson.getString("destTelphone"));
                            dwLog.setDestContactsName(reqJson.getString("destContactsName"));
                            dwLog.setSourceProvince(reqJson.getString("sourceProvince"));
                            dwLog.setSourceCity(reqJson.getString("sourceCity"));
                            dwLog.setSourceCityCode(reqJson.getString("sourceCityCode"));
                            dwLog.setSourceCounty(reqJson.getString("sourceCounty"));
                            dwLog.setSourceDeptCode(reqJson.getString("sourceDeptCode"));
                            dwLog.setSourceAddr(reqJson.getString("sourceAddr"));
                            dwLog.setSourceCompany(reqJson.getString("sourceCompany"));
                            dwLog.setSourceTelphone(reqJson.getString("sourceTelphone"));
                            dwLog.setSourceContactsName(reqJson.getString("sourceContactsName"));
                            dwLog.setCargoTypeCode(reqJson.getString("cargoTypeCode"));
                            dwLog.setLimitTypeCode(reqJson.getString("limitTypeCode"));
                            dwLog.setExpressTypeCode(reqJson.getString("expressTypeCode"));
                            dwLog.setWeight(reqJson.getString("weight"));
                            dwLog.setServiceCodeList(reqJson.getString("serviceCodeList"));
                            dwLog.setCustomerAccount(reqJson.getString("customerAccount"));
                            dwLog.setGdesc(reqJson.getString("gdesc"));
                            dwLog.setPayType(reqJson.getString("payType"));

                            dwLog.setSrcSpeciesType(reqJson.getString("srcSpeciesType"));
                            dwLog.setDesSpeciesType(reqJson.getString("desSpeciesType"));
                            dwLog.setGoodsNumber(reqJson.getString("goodsNumber"));
                            dwLog.setSourceTeamCodeRev(reqJson.getString("sourceTeamCodeRev"));
                            dwLog.setDestDeptCodeRev(reqJson.getString("destDeptCodeRev"));
                            dwLog.setDestTeamCodeRev(reqJson.getString("destTeamCodeRev"));
                            dwLog.setQuantity(reqJson.getString("quantity"));
                            dwLog.setRevType(reqJson.getString("revType"));
                            dwLog.setChannelCode(reqJson.getString("channelCode"));
                            dwLog.setSrcOrderNo(reqJson.getString("srcOrderNo"));
                            dwLog.setOmsOrderNo(reqJson.getString("omsOrderNo"));
                            dwLog.setSysOrderType(reqJson.getString("sysOrderType"));
                            dwLog.setOmsOrderType(reqJson.getString("omsOrderType"));
                            dwLog.setExtent(reqJson.getString("extent"));
                            dwLog.setWidth(reqJson.getString("width"));
                            dwLog.setHeight(reqJson.getString("height"));
                            dwLog.setClientCode(reqJson.getString("clientCode"));
                            dwLog.setCustomerType(reqJson.getString("customerType"));
                            dwLog.setAddServiceList(reqJson.getString("addServiceList"));
                            dwLog.setOneselfPickupFlag(reqJson.getString("oneselfPickupFlag"));
                            dwLog.setMcode(reqJson.getString("mcode"));
                            dwLog.setNcFlag(reqJson.getString("ncFlag"));
                            dwLog.setNcPack(reqJson.getString("ncPack"));
                            dwLog.setAirBannedTag(reqJson.getString("airBannedTag"));
                            dwLog.setaFlag(reqJson.getString("aFlag"));
                        }
					}
					JSONArray respJsonArr = messageJson.getJSONArray("response");
					if (respJsonArr != null && respJsonArr.size() > 0) {
                        JSONObject respJson = respJsonArr.getJSONObject(0);
                        if (respJson != null) {
                            JSONObject routeLabelDataJson = respJson.getJSONObject("routeLabelData");
                            if (routeLabelDataJson != null) {
                                dwLog.setDestPortCode(routeLabelDataJson.getString("destPortCode"));
                                dwLog.setDestPostCode(routeLabelDataJson.getString("destPostCode"));
                                dwLog.setDestCountry(routeLabelDataJson.getString("destCountry"));
                                dwLog.setGoodsValueTotal(routeLabelDataJson.getString("goodsValueTotal"));
                                dwLog.setCurrencySymbol(routeLabelDataJson.getString("currencySymbol"));
                                dwLog.setCusBatch(routeLabelDataJson.getString("cusBatch"));
                                dwLog.setExportDeclarationMethod(routeLabelDataJson.getString("exportDeclarationMethod"));
                                dwLog.setImportDeclarationMethod(routeLabelDataJson.getString("importDeclarationMethod"));
//                                dwLog.setSrcSpeciesType(routeLabelDataJson.getString("srcSpeciesType"));
//                                dwLog.setDesSpeciesType(routeLabelDataJson.getString("desSpeciesType"));
//                                dwLog.setGoodsNumber(routeLabelDataJson.getString("goodsNumber"));
//                                dwLog.setSourceTeamCodeRev(routeLabelDataJson.getString("sourceTeamCodeRev"));
//                                dwLog.setDestDeptCodeRev(routeLabelDataJson.getString("destDeptCodeRev"));
//                                dwLog.setDestTeamCodeRev(routeLabelDataJson.getString("destTeamCodeRev"));
//                                dwLog.setQuantity(routeLabelDataJson.getString("quantity"));
//                                dwLog.setRevType(routeLabelDataJson.getString("revType"));
//                                dwLog.setChannelCode(routeLabelDataJson.getString("channelCode"));
//                                dwLog.setSrcOrderNo(routeLabelDataJson.getString("srcOrderNo"));
//                                dwLog.setOmsOrderNo(routeLabelDataJson.getString("omsOrderNo"));
//                                dwLog.setSysOrderType(routeLabelDataJson.getString("sysOrderType"));
//                                dwLog.setOmsOrderType(routeLabelDataJson.getString("omsOrderType"));
//                                dwLog.setExtent(routeLabelDataJson.getString("extent"));
//                                dwLog.setWidth(routeLabelDataJson.getString("width"));
//                                dwLog.setHeight(routeLabelDataJson.getString("height"));
//                                dwLog.setClientCode(routeLabelDataJson.getString("clientCode"));
//                                dwLog.setCustomerType(routeLabelDataJson.getString("customerType"));
//                                dwLog.setAddServiceList(routeLabelDataJson.getString("addServiceList"));
//                                dwLog.setOneselfPickupFlag(routeLabelDataJson.getString("oneselfPickupFlag"));
//                                dwLog.setMcode(routeLabelDataJson.getString("mcode"));
//                                dwLog.setNcFlag(routeLabelDataJson.getString("ncFlag"));
//                                dwLog.setNcPack(routeLabelDataJson.getString("ncPack"));
//                                dwLog.setAirBannedTag(routeLabelDataJson.getString("airBannedTag"));
//                                dwLog.setaFlag(routeLabelDataJson.getString("aFlag"));
                                dwLog.setSourceTransferCode(routeLabelDataJson.getString("sourceTransferCode"));
                                dwLog.setSourceTeamCode(routeLabelDataJson.getString("sourceTeamCode"));
                                dwLog.setDestDeptCode(routeLabelDataJson.getString("destDeptCode"));
                                dwLog.setDestGisDeptCode(routeLabelDataJson.getString("destGisDeptCode"));
                                dwLog.setDestDeptCodeMapping(routeLabelDataJson.getString("destDeptCodeMapping"));
                                dwLog.setDestTeamCode(routeLabelDataJson.getString("destTeamCode"));
                                dwLog.setDestRawTeamCode(routeLabelDataJson.getString("destRawTeamCode"));
                                dwLog.setDestRawTeamCode1(routeLabelDataJson.getString("destRawTeamCode1"));
                                dwLog.setDestTeamCodeMapping(routeLabelDataJson.getString("destTeamCodeMapping"));
                                dwLog.setDestTransferCode(routeLabelDataJson.getString("destTransferCode"));
                                dwLog.setDestRouteLabel(routeLabelDataJson.getString("destRouteLabel"));
                                dwLog.setProName(routeLabelDataJson.getString("proName"));
                                dwLog.setCodingMapping(routeLabelDataJson.getString("codingMapping"));
                                dwLog.setCodingMappingOut(routeLabelDataJson.getString("codingMappingOut"));
                                dwLog.setXbFlag(routeLabelDataJson.getString("xbFlag"));
                                dwLog.setSendAreaCode(routeLabelDataJson.getString("sendAreaCode"));
                                dwLog.setDestinationStationCode(routeLabelDataJson.getString("destinationStationCode"));
                                dwLog.setSxLabelDestCode(routeLabelDataJson.getString("sxLabelDestCode"));
                                dwLog.setSxDestTransferCode(routeLabelDataJson.getString("sxDestTransferCode"));
                                dwLog.setSxCompany(routeLabelDataJson.getString("sxCompany"));
                                dwLog.setPrintFlag(routeLabelDataJson.getString("printFlag"));
                                dwLog.setTwoDimensionCode(routeLabelDataJson.getString("twoDimensionCode"));
                                dwLog.setProCode(routeLabelDataJson.getString("proCode"));
                                dwLog.setPrintIcon(routeLabelDataJson.getString("printIcon"));
                                dwLog.setAbFlag(routeLabelDataJson.getString("abFlag"));
                                dwLog.setNewAbFlag(routeLabelDataJson.getString("newAbFlag"));
                                dwLog.setErrMsg(routeLabelDataJson.getString("errMsg"));
                                dwLog.setCheckCode(routeLabelDataJson.getString("checkCode"));
                                dwLog.setProIcon(routeLabelDataJson.getString("proIcon"));
                                dwLog.setFileIcon(routeLabelDataJson.getString("fileIcon"));
                                dwLog.setFbaIcon(routeLabelDataJson.getString("fbaIcon"));
                                dwLog.setIcsmIcon(routeLabelDataJson.getString("icsmIcon"));
                                dwLog.setConsignTag(routeLabelDataJson.getString("consignTag"));
                                dwLog.setLimitTag(routeLabelDataJson.getString("limitTag"));
                                dwLog.setReceiptModelTag(routeLabelDataJson.getString("receiptModelTag"));
                                dwLog.setSortingModelTag(routeLabelDataJson.getString("sortingModelTag"));
                                dwLog.setContainerModelTag(routeLabelDataJson.getString("containerModelTag"));
                                dwLog.setDeliveryModelTag(routeLabelDataJson.getString("deliveryModelTag"));
                                dwLog.setNewIcon(routeLabelDataJson.getString("newIcon"));
                                dwLog.setHqrLevel(routeLabelDataJson.getString("hqrLevel"));
                                dwLog.setDestAddrKeyWord(routeLabelDataJson.getString("destAddrKeyWord"));
                                dwLog.setAirTransportIcon(routeLabelDataJson.getString("airTransportIcon"));
                                dwLog.setCpDestTransferCode(routeLabelDataJson.getString("cpDestTransferCode"));
                                dwLog.setCpSourceTransferCode(routeLabelDataJson.getString("cpSourceTransferCode"));
                                dwLog.setAoiChannel(routeLabelDataJson.getString("aoiChannel"));
                                dwLog.setPrintNameKc(routeLabelDataJson.getString("printNameKc"));
                                dwLog.setRongType(routeLabelDataJson.getString("rongType"));
                                dwLog.setWaybillIconList(routeLabelDataJson.getString("waybillIconList"));
                                dwLog.setConsignInfo(routeLabelDataJson.getString("consignInfo"));
                            }
                        }
                    }
					dwLog.setSystem(messageJson.getString("system"));
					dwLog.setTraceId(messageJson.getString("traceId"));
				}
			}
			return dwLog;
		});
	}
}
