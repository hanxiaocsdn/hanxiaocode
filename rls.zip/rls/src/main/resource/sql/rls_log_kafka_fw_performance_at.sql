select
  t1.elapsedtime elapsedtime,
  t1.code code,
  t1.cachetag cachetag
from
  (
    select
      at_elapsedtime elapsedtime,
      get_json_object(re_fns_at, '$.status') code,
      get_json_object(re_fns_at, '$.cacheTag') cachetag,
      (
        case
          when tag = 'CAINIAO' then tag
          else 'OTHER'
        end
      ) tag
    from
      dm_gis.rls_log_fw
    where
      inc_day = '%s'
      and re_fns_at is not null
      and re_fns_at <> ''
  ) t1
where
  t1.tag = '%s'