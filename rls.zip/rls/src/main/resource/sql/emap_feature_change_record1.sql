select
  a.old_codes old_codes,
  a.type type
from
  (
    select
      old_codes,
      type,
      row_number() over(
        partition by old_codes
        order by
          update_date desc
      ) as row_cnt
    from
      dm_gis.emap_feature_change_record
    where
      layer_id = '46'
      and status = '6'
      and type in ('2', '3')
      and inc_day between '%s'
      and '%s'
  ) a
where
  a.row_cnt = 1