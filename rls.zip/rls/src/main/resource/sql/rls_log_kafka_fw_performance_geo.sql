select
  t2.elapsedTime elapsedtime,
  row_number() over(
    order by
      cast(t2.elapsedTime as int) asc
  ) rank
from
  (
    select
      *
    from
      (
        select
          get_json_object(re_fns_geo, '$.elapsedTime') elapsedTime,
          (
            case
              when get_json_object(re_fns_geo, '$.tag') = 'CAINIAO' then get_json_object(re_fns_geo, '$.tag')
              else 'OTHER'
            end
          ) tag
        from
          dm_gis.rls_log_fw
        where
          inc_day = '%s'
          and re_fns_geo is not null
          and re_fns_geo <> ''
      ) t1
    where
      t1.tag = '%s'
  ) t2