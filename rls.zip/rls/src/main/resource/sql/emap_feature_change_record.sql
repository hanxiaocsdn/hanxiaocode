select
  t2.old_codes old_codes,
  t2.type type,
  t2.status status,
  t2.update_date update_date
from
  (
    select
      t1.*,
      row_number() over(
        partition by t1.old_codes
        order by
          t1.update_date desc
      ) rn1
    from
      (
        select
          old_codes,
          type,
          status,
          update_date
        from
          dm_gis.emap_feature_change_record
        where
          inc_day = '%s'
          and old_codes != ''
          and layer_id in ('46', '47', '48')
        union
        select
          new_codes as old_codes,
          type,
          status,
          update_date
        from
          dm_gis.emap_feature_change_record
        where
          inc_day = '%s'
          and old_codes = ''
          and new_codes != ''
          and layer_id in ('46', '47', '48')
      ) t1
  ) t2
where
  t2.rn1 = 1