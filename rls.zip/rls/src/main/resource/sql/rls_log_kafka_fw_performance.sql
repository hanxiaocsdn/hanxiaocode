select
  t2.createTime createtime,
  t2.elapsedTime elapsedtime,
  t2.code code,
  row_number() over(
    order by cast(t2.elapsedTime as int) asc
  ) rank
from
  (
    select
      *
    from
      (
        select
          get_json_object(log, '$.createTime') createTime,
          get_json_object(get_json_object(log, '$.message'),'$.elapsedTime') elapsedTime,
          get_json_object(get_json_object(get_json_object(log, '$.message'), '$.response'),'$.result.code') code,
          (
            case
              when get_json_object(get_json_object(log, '$.message'), '$.tag') = 'CAINIAO' then get_json_object(get_json_object(log, '$.message'), '$.tag')
              else 'OTHER'
            end
          ) tag
        from
          dm_gis.rls_log_kafka_fw
        where
          inc_day = '%s'
          and log is not null
          and log <> ''
          and get_json_object(get_json_object(log, '$.message'),'$.logKeyWords') = 'FnsRouteLabel'
      ) t1
    where
      t1.tag = '%s'
  ) t2