select
a.waybill_no waybill_no,
a.citycode citycode,
a.city city,
a.region region,
a.create_time create_time,
a.dest_province dest_province,
a.dest_city dest_city,
a.dest_county dest_county,
a.dest_addr dest_addr,
a.dest_aoiid dest_aoiid,
a.dest_dept_code dest_dept_code,
a.fns_first_dept_code fns_first_dept_code,
a.fns_delivery_code fns_delivery_code,
a.inc_day inc_day,
a.fns_src fns_src,
a.fns_fir_status fns_fir_status,
a.at_src at_src,
a.at_citycode at_citycode,
a.at_groupid at_groupid,
a.at_dept at_dept,
a.at_team at_team,
a.aoi_src aoi_src,
a.geo_x geo_x,
a.geo_y geo_y,
a.geo_filter geo_filter,
a.geo_level geo_level,
a.geo_source geo_source,
a.cnt cnt,
a.same_cnt same_cnt,
a.disp_site_code disp_site_code,
a.first_acc first_acc,
b.x_80 x_80,
b.y_80 y_80
 from
(
    select
        waybill_no,
        citycode,
        city,
        region,
        create_time,
        dest_province,
        dest_city,
        dest_county,
        regexp_replace(dest_addr, '[\r\n\0, \s, \.,\,,\t,\0022]+', '') as dest_addr,
        dest_aoiid,
        dest_dept_code,
        fns_first_dept_code,
        fns_delivery_code,
        inc_day,
        fns_src,
        fns_fir_status,
        regexp_replace(get_json_object(get_json_object(re_fns_at,'$.result'), '$.src'),'[\r\n\t]+', '') at_src,
        regexp_replace(get_json_object(get_json_object(get_json_object(re_fns_at,'$.result'), '$.other'),'$.city'),'[\r\n\t]+', '') at_citycode,
        regexp_replace(get_json_object(get_json_object(get_json_object(re_fns_at,'$.result'), '$.other'),'$.groupid'),'[\r\n\t]+', '') at_groupid,
        regexp_replace(get_json_object(get_json_object(get_json_object(re_fns_at,'$.result'), '$.other'),'$.dept'),'[\r\n\t]+', '') at_dept,
        regexp_replace(get_json_object(get_json_object(get_json_object(re_fns_at,'$.result'), '$.other'),'$.team'),'[\r\n\t]+', '') at_team,
        regexp_replace(get_json_object(get_json_object(get_json_object(re_fns_at,'$.result'), '$.tcs[0]'),'$.atAoiSrc'),'[\r\n\t]+', '') aoi_src,
        regexp_replace(get_json_object(get_json_object(re_fns_geo,'$.response'), '$.x'),'[\r\n\t]+', '') geo_x,
        regexp_replace(get_json_object(get_json_object(re_fns_geo,'$.response'), '$.y'),'[\r\n\t]+', '') geo_y,
        regexp_replace(get_json_object(get_json_object(re_fns_geo,'$.response'), '$.filter'),'[\r\n\t]+', '') geo_filter,
        regexp_replace(get_json_object(get_json_object(re_fns_geo,'$.response'), '$.level'),'[\r\n\t]+', '') geo_level,
        regexp_replace(get_json_object(get_json_object(re_fns_geo,'$.response'), '$.source'),'[\r\n\t]+', '') geo_source,
        cnt,
        same_cnt,
        disp_site_code,
        first_acc
    from dm_gis.rls_log_fw_first_acc where first_acc in ('wr_0', 'wr_1') and inc_day = '%s'
) a
left join
(
    select * from
    (
        select
            waybillno,
            eventlng as x_80,
            eventlat as y_80,
            org_code,
            inc_day,
            eventtype,
            city_code,
            operatime_new,
            row_number() over(partition by waybillno order by operatime_new ) as rn
        from ods_inc_sgs_core.inc_sgs_task_flow_new
        where inc_day between '%s' and '%s'
            and eventtype ='31124'
    ) bb
    where rn=1
) b
on a.waybill_no=b.waybillno