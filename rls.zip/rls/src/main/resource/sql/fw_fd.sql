select
  tc_type,
  ky_unit,
  count(aoi) aoi_count
from
  (
    select
      id,
      ky_unit,
      relate_aoi,
      aoi,
      tc_type
    from
      dm_gis.emap_efsms_kyunit_relate_aoi_incday a lateral view explode(split(a.relate_aoi, '\\|')) r as aoi
    where
      inc_day = '%s'
      and tc_type in('fns_first','fns_snd','fns_delivery')
  ) a
group by
  tc_type,
  ky_unit