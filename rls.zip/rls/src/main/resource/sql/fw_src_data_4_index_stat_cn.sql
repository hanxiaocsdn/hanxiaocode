select
  rls.region region,
  rls.citycode citycode,
  rls.city city,
  rls.waybill_no waybill_no,
  rls.fns_transfer_code fns_transfer_code,
  rls.fns_first_dept_code fns_first_dept_code,
  rls.fns_sec_dept_code fns_sec_dept_code,
  rls.fns_delivery_code fns_delivery_code,
  rls.fns_src fns_src,
  rls.dest_raw_team_code dest_raw_team_code,
  rls.dest_aoiid dest_aoiid,
  rls.code rls_code,
  rls.source_addr_decrypt source_addr_decrypt,
  rls.source_city_code source_city_code,
  rls.dest_addr_decrypt dest_addr_decrypt,
  rls.dest_city_code dest_city_code_rls,
  rls.cargo_type_code cargo_type_code,
  rls.express_type_code express_type_code,
  rls.limit_type_code limit_type_code,
  rls.fns_dlv_status fns_dlv_status,
  rls.fns_fir_status fns_fir_status,
  rls.fns_snd_status fns_snd_status,
  rls.create_time create_time,
  rls.dest_province dest_province,
  rls.dest_city dest_city,
  rls.dest_county dest_county,
  rls.dest_addr dest_addr,
  rls.dest_dept_code dest_dept_code,
  rls.re_fns_geo re_fns_geo,
  rls.re_fns_at re_fns_at,
  rls.inc_day inc_day,
  gto.code gto_code,
  gto.dest_transfer_code dest_transfer_code,
  gto.dest_city_code dest_city_code_gto,
  gto.have_returned_goods have_returned_goods,
  gao.transorder_id transorder_id,
  gao.transorder_code transorder_code,
  gao.disp_site_id disp_site_id,
  gao.disp_site_code disp_site_code,
  gao.dispatcher_id dispatcher_id,
  gao.dispatcher_name dispatcher_name,
  gao.sign_date sign_date,
  gtof.code gtof_code,
  dsid.type dsid_type,
  dsid.is_sf_site is_sf_site,
  dsid.id dsid_id,
  dsid.parent_site_code parent_site_code
from
  (
    select
      region,
      citycode,
      city,
      waybill_no,
      fns_transfer_code,
      fns_first_dept_code,
      fns_sec_dept_code,
      fns_delivery_code,
      fns_src,
      dest_raw_team_code,
      dest_aoiid,
      code,
      source_addr_decrypt,
      source_city_code,
      dest_addr_decrypt,
      dest_city_code,
      cargo_type_code,
      express_type_code,
      limit_type_code,
      fns_dlv_status,
      fns_fir_status,
      fns_snd_status,
      create_time,
      dest_province,
      dest_city,
      dest_county,
      dest_addr,
      dest_dept_code,
      re_fns_geo,
      re_fns_at,
      inc_day
    from
      (
        select
          region,
          citycode,
          city,
          waybill_no,
          fns_transfer_code,
          fns_first_dept_code,
          fns_sec_dept_code,
          fns_delivery_code,
          fns_src,
          dest_raw_team_code,
          dest_aoiid,
          code,
          source_addr_decrypt,
          source_city_code,
          dest_addr_decrypt,
          dest_city_code,
          cargo_type_code,
          express_type_code,
          limit_type_code,
          fns_dlv_status,
          fns_fir_status,
          fns_snd_status,
          create_time,
          dest_province,
          dest_city,
          dest_county,
          dest_addr,
          dest_dept_code,
          re_fns_geo,
          re_fns_at,
          inc_day,
          ROW_NUMBER() OVER(
            PARTITION BY waybill_no
            ORDER BY
              create_time desc
          ) AS rn
        from
          dm_gis.rls_log_fw
        where
          inc_day = '%s'
          and waybill_no != '%s'
          and create_time <= '%s'
          and tag = 'CAINIAO'
      ) tmpRls
    where
      tmpRls.rn = 1
  ) rls
  left join (
    select
      code,
      dest_transfer_code,
      dest_city_code,
      have_returned_goods
    from
      (
        select
          code,
          dest_transfer_code,
          dest_city_code,
          have_returned_goods,
          ROW_NUMBER() OVER(
            PARTITION BY code
            ORDER BY
              inc_day desc
          ) AS rn
        from
          ods_x5_prod.gt_trans_order
        where
          inc_day between '%s'
          and '%s'
      ) tempGto
    where
      tempGto.rn = 1
  ) gto on rls.waybill_no = gto.code
  left join (
    select
      transorder_id,
      transorder_code,
      disp_site_id,
      disp_site_code,
      dispatcher_id,
      dispatcher_name,
      sign_date
    from
      (
        select
          transorder_id,
          transorder_code,
          disp_site_id,
          disp_site_code,
          dispatcher_id,
          dispatcher_name,
          sign_date,
          ROW_NUMBER() OVER(
            PARTITION BY transorder_code
            ORDER BY
              inc_day desc
          ) AS rn
        from
          dm_gis.gt_scan_all
        where
          inc_day between '%s'
          and '%s'
      ) tempGao
    where
      tempGao.rn = 1
  ) gao on rls.waybill_no = gao.transorder_code
  left join (
    select
      code
    from
      (
        select
          code,
          ROW_NUMBER() OVER(
            PARTITION BY code
            ORDER BY
              inc_day desc
          ) AS rn
        from
          ods_x5_prod.gt_trans_order_forward
        where
          inc_day between '%s'
          and '%s'
      ) tempGtof
    where
      tempGtof.rn = 1
  ) gtof on rls.waybill_no = gtof.code
  left join (
    select
      id,
      type,
      is_sf_site,
      parent_site_code
    from
      (
        select
          id,
          type,
          is_sf_site,
          parent_site_code,
          ROW_NUMBER() OVER(
            PARTITION BY id
            ORDER BY
              inc_day desc
          ) AS rn
        from
          dm_fw.dim_site_info_df
        where
          inc_day between '%s'
          and '%s'
      ) tempDsid
    where
      tempDsid.rn = 1
  ) dsid on gao.disp_site_id = dsid.id