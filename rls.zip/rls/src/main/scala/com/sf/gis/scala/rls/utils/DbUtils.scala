package com.sf.gis.scala.rls.utils

import java.sql.{Connection, DriverManager, PreparedStatement, SQLException}

import com.alibaba.druid.pool.DruidDataSource
import org.apache.log4j.Logger

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01375125 on 2018/8/22.
 */
object DbUtils {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getName)

  val javaUtil = new JavaUtil(6)

  private val Driver = javaUtil.get("oms.mysql.driver")
  private val URL = javaUtil.get("oms.mysql.url")
  private val USERNAME = javaUtil.get("oms.mysql.uid")
  private val PASSWORD = javaUtil.get("oms.mysql.pwd")

  def getMysqlConn(url: String, driver: String, username: String, password: String): Connection = {
    var conn: Connection = null
    try {
      Class.forName(driver)
      conn = DriverManager.getConnection(url, username, password)
    } catch {
      case e: Exception => logger.error(">>>连接数据库异常：" + url + ",exception=" + e)
    }
    conn
  }

  /**
   * 传入配置类，获取连接
   *
   * @param javaUtil
   * @return
   */
  def getConn(javaUtil: JavaUtil): Connection = {
    val Driver = javaUtil.get("oms.mysql.driver")
    val URL = javaUtil.get("oms.mysql.url")
    val USERNAME = javaUtil.get("oms.mysql.uid")
    val PASSWORD = javaUtil.get("oms.mysql.pwd")
    DbUtils.getMysqlConn(URL, Driver, USERNAME, PASSWORD)
  }


  /**
   * 获取数据库连接
   *
   * @return
   */
  def getConn: Connection = {
    var conn: Connection = null
    var dataSource: DruidDataSource = null
    try {
      dataSource = new DruidDataSource()
      dataSource.setDriverClassName(Driver)
      dataSource.setUrl(URL)
      dataSource.setUsername(USERNAME)
      dataSource.setPassword(PASSWORD)
      dataSource.setMaxActive(20)
      dataSource.setMaxWait(3000)
      dataSource.setRemoveAbandoned(false)
      conn = dataSource.getConnection
    } catch {
      case e: Exception => println(">>>mysql数据库连接异常：" + e)
    }
    conn
  }


  /**
   * 获取数据库连接
   *
   * @return
   */
  def getConnection(javaUtil: JavaUtil): Connection = {
    var conn: Connection = null
    var dataSource: DruidDataSource = null
    try {
      dataSource = new DruidDataSource()
      val DRIVER = javaUtil.get("oms.mysql.driver")
      val URL = javaUtil.get("oms.mysql.url")
      val USERNAME = javaUtil.get("oms.mysql.uid")
      val PASSWORD = javaUtil.get("oms.mysql.pwd")
      dataSource.setDriverClassName(DRIVER)
      dataSource.setUrl(URL)
      dataSource.setUsername(USERNAME)
      dataSource.setPassword(PASSWORD)
      dataSource.setMaxActive(20)
      dataSource.setMaxWait(1000)
      dataSource.setRemoveAbandoned(false)
      conn = dataSource.getConnection
    } catch {
      case e: Exception => println(">>>mysql数据库连接异常：" + e)
    }
    conn
  }

  /**
   * 批量把数据插入到mysql数据库
   *
   * @param sql
   * @param paramList
   */
  def executeBatchSql(conn: Connection, sql: String, paramList: ArrayBuffer[Array[String]]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(false)
      for (params: Array[String] <- paramList) {
        if (params != null) {
          for (i <- 0 until params.length) ps.setString(i + 1, params(i).toString)
          ps.addBatch()
        }

      }
      ps.executeBatch()
      conn.commit()
      ps.close()
      //      conn.close()
    } catch {
      case e: Exception => logger.error(String.format(e + ">>>数据批量操作异常: %s", sql))
    }
  }

  /**
   * 批量把数据插入到mysql数据库
   *
   * @param sql
   * @param paramList
   */
  def batchExecute(conn: Connection, sql: String, paramList: ArrayBuffer[Array[Any]]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(false)
      for (params: Array[Any] <- paramList) {
        if (params != null) {
          for (i <- 0 until params.length) ps.setString(i + 1, params(i).toString)
          ps.addBatch()
        }

      }
      ps.executeBatch()
      conn.commit()
      ps.close()
      //      conn.close()
    } catch {
      case e: Exception => logger.error(String.format(e + ">>>数据批量操作异常: %s", sql))
    }
  }


  /**
   * 把数据插入到mysql数据库
   *
   * @param sql
   * @param params
   */
  def executeSql(conn: Connection, sql: String, params: Array[String], tag: String): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      if (params != null) {
        for (i <- 0 until params.length) ps.setString(i + 1, params(i))
      }
      ps.executeUpdate()
      ps.close()
    } catch {
      case e: Exception => println(">>>数据库操作异常," + e + ":" + sql)
    }
  }

  /**
   * 把数据插入到mysql数据库
   *
   * @param sql
   * @param params
   */
  def execute(conn: Connection, sql: String, params: Array[Any]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      if (params != null) {
        for (i <- 0 until params.length) ps.setString(i + 1, params(i).toString)
      }
      ps.executeUpdate()
      ps.close()
    } catch {
      case e: Exception => println(">>>数据库操作异常," + e + ",sql:" + sql + ",param:" + params.mkString(","))
    }
  }


  /**
   * 插入一个数组的数据
   *
   * @param conn
   * @param sql
   * @param params
   */
  def executeSql(conn: Connection, sql: String, params: Array[String]): Unit = {
    executeSql(conn: Connection, sql: String, params: Array[String], null)
  }

  def executeSql(conn: Connection, sql: String): Unit = {
    executeSql(conn: Connection, sql: String, null, null)
  }

  /**
   * 执行查询语句
   *
   * @param conn
   * @param sql
   */
  def querySql(conn: Connection, sql: String): Unit = {
    //    val list = new ArrayBuffer[]()
    try {
      val ps = conn.prepareStatement(sql)
      val rs = ps.executeQuery()
      /*while(rs.next()){
        val row = Array
      }*/

      ps.close()
    } catch {
      //      case e: Exception => logger.error(String.format(e + ">>>数据操作异常: %s", ele))
      case e: Exception => println("数据库操作异常：" + e + ">>>")
    }
  }


  /**
   * 查询语句
   *
   * @param conn
   * @param sql
   * @param params
   * @param columns
   * @return
   */
  def selectColumns(conn: Connection, sql: String, params: Array[String], columns: Array[String]): ArrayBuffer[Array[String]] = {
    var ps: PreparedStatement = null
    var rows: ArrayBuffer[Array[String]] = new ArrayBuffer[Array[String]]
    try {
      ps = conn.prepareStatement(sql)
      if (params != null) {
        for (i <- 0 until params.length) ps.setString(i + 1, params(i))
      }
      val rs = ps.executeQuery()
      while (rs.next()) {
        val row: Array[String] = new Array[String](columns.length)
        for (i <- 0 until row.length) {
          val field = rs.getObject(columns(i))
          if (field != null) {
            row(i) = field.toString
          } else {
            row(i) = ""
          }
        }
        rows += row
      }

    } catch {
      case e: SQLException => println(">>>查询数据异常：" + e)

    }
    rows
  }

  /**
   * 查询语句
   *
   * @param conn
   * @param sql
   * @param columns
   * @return
   */
  def selectColumns(conn: Connection, sql: String, columns: Array[String]): ArrayBuffer[Array[String]] = {
    selectColumns(conn, sql, null, columns)
  }

  def selectColumn(conn: Connection, sql: String, params: Array[String], columns: Array[String]): ArrayBuffer[String] = {
    var ps: PreparedStatement = null
    var rows: ArrayBuffer[String] = new ArrayBuffer[String]
    try {
      ps = conn.prepareStatement(sql)
      if (params != null) {
        for (i <- 0 until params.length) ps.setString(i + 1, params(i))
      }
      val rs = ps.executeQuery()
      while (rs.next()) {
        val field = rs.getObject(1)
        if (field != null) {
          rows += field.toString
        } else {
          rows += ""
        }
      }
    } catch {
      case e: SQLException => println(">>>查询数据异常：" + e)
    }
    rows
  }

  def selectColumn(conn: Connection, sql: String, columns: Array[String]): ArrayBuffer[String] = {
    selectColumn(conn, sql, null, columns)
  }


  def testPU(): Unit = {
    val conn = DbUtils.getConn
    //OMS收件分钟表
    val REQ_CHK_PU_DETAIL = "REQ_CHK_PU_DETAIL"
    val ak = "all"
    val dimension = "TOTAL"
    val date = "20181024"
    val columns = Array("req_max", "req_avg", "req_min", "resp_time_max", "resp_time_avg", "resp_time_min", "resp_time_99max", "resp_time_99avg", "resp_time_99min")
    val selectSqlDay = String.format(s"select MAX(req_count) req_max,AVG(req_count) req_avg ,MIN(req_count) req_min  , MAX(resp_time) resp_time_max,AVG(resp_time) resp_time_avg,MIN(resp_time) resp_time_min  ,MAX(resp_time_99) resp_time_99max,AVG(resp_time_99) resp_time_99avg ,MIN(resp_time_99) resp_time_99min from $REQ_CHK_PU_DETAIL where  ak = '%s' and stat_dmns = '%s' AND stat_date= '%s' ", ak, dimension, date)
    println("selectSqlDay:" + selectSqlDay)
    val dayIndexss: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, selectSqlDay, null, columns)
    val dayIndexs = dayIndexss(0)
    println("按天指标：" + dayIndexs.mkString(","))


  }


}