package com.sf.gis.scala.rls.app

import java.sql.DriverManager
import java.text.SimpleDateFormat
import java.util
import java.util.{Calendar, Date}

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, StringUtils}
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Durations, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer


/**
 * rls实时性能指标统计
 * 任务id:225201
 */
object RlsRealtimePerforMain {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  //  val javaUtil = new JavaUtil(6) //6表示rds服务
  case class RlsSta(
                     id: String,
                     stat_day: String,
                     stat_hour: Int,
                     stat_end_minu: Int,
                     totalNum: Int,
                     retCode: Int,
                     retBy: Int,
                     deptCode: Int,
                     teamCode: Int,
                     addrType: Int,
                     waybillNo: Int,
                     aoiId: Int,
                     aoiCode: Int,
                     aoiAreaCode: Int,
                     aoiUnit: Int,
                     addressKeyword: Int,
                     aoiTypeCode: Int,
                     innerMark: Int,
                     originDept: Int,
                     appliedAoiCode: Int,
                     appliedAoiId: Int,
                     appliedAoiInfo: Int,
                     aoiAreaGroup: Int,
                     deptGroup: Int
                   )

  def main(args: Array[String]): Unit = {

    if (args.length == 0) {
      //不传参数，实时,当日
      var today = DateUtil.getDate(0, "-")
      start(today: String)
    } else {
      //传入参数，离线，某天日期，如"2019-08-13"
      val date = args(0)
      dealOfflineTask(date)
    }
  }

  /**
   * 执行入口
   */
  def start(date: String): Unit = {
    val sc = new SparkContext(getConf(appName))
    sc.setLogLevel("ERROR")
    val ssc = new StreamingContext(sc, Durations.seconds(5 * 60))
    ssc.sparkContext.setLogLevel("ERROR")
    val format = FastDateFormat.getInstance("yyyy-MM-dd")
    val today = format.format(Calendar.getInstance().getTime)

    var hdfsPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/chk_query_log_flink/%s"
    hdfsPath = String.format(hdfsPath, date.replaceAll("-", ""))
    println("-----------------------------------开始数据处理-----------------------------------------------")
    logger.error(">>>统计日期：" + date + ",>>>日志路径：" + hdfsPath + ",>>>appName=" + appName)
    val lines = ssc.textFileStream(hdfsPath)
    val lineRdd: DStream[String] = ssc.textFileStream(hdfsPath).repartition(100)
    lines.foreachRDD(lineRdd => {
      logger.error(">>>统计日期：" + today + ",>>>日志路径：" + hdfsPath + ",>>>appName=" + appName)
      logger.error(">>>新增日志量：" + lineRdd.count())
    })
    val windowLog: DStream[String] = lines.window(Durations.seconds(10 * 60), Durations.seconds(5 * 60))
    logger.error(">>>处理新获取的日志")
    dealWindowLog(windowLog, date, hdfsPath)
    ssc.start()
    val checkIntervalMillis = 20000
    var stopFlag = false
    while (!stopFlag) {
      val isStopped = ssc.awaitTerminationOrTimeout(checkIntervalMillis)
      if (isStopped) {
        logger.error("WARNING!!! The spark streaming context is stopped. Exiting application ......")
        stopFlag = true
      }
      val curDay = format.format(Calendar.getInstance().getTime)
      if (!curDay.equals(today)) {
        logger.error("跨天了，强行停止~~~")
        ssc.stop(stopSparkContext = true, stopGracefully = false)
      }
      //      val curTime = DateUtils.longToTime(new Date().getTime,"yyyyMMddHHmm")
      //      if(curTime.startsWith("20200225181")){
      //        streamingContext.stop(stopSparkContext = true,stopGracefully = false)
      //        logger.error("stop~~~")
      //      }else{
      //        logger.error("no stop~~~"+curTime)
      //      }
    }
    logger.error(">>>The end!")
  }

  /**
   * 解析离线日期数据
   */
  def dealOfflineTask(date: String): Unit = {
    //    val today="2019-08-13"
    var hdfsPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/chk_query_log_flink/%s"
    hdfsPath = String.format(hdfsPath, date.replaceAll("-", ""))
    val spark = Spark.getSparkSession(appName)
    val logRdd = spark.sparkContext.textFile(hdfsPath)
    //    dealLogTask(logRdd: RDD[String], date: String)
  }

  def parserController(data: JSONObject, date: Date, day: String) = {

    RlsSta("" + day + date.getHours + date.getMinutes,
      "" + day, date.getHours, date.getMinutes,
      1,
      checkEmpty(data, "retCode"),
      checkEmpty(data, "retBy"),
      checkEmpty(data, "deptCode"),
      checkEmpty(data, "teamCode"),
      checkEmpty(data, "addrType"),
      checkEmpty(data, "waybillNo"),
      checkEmpty(data, "aoiId"),
      checkEmpty(data, "aoiCode"),
      checkEmpty(data, "aoiAreaCode"),
      checkEmpty(data, "aoiUnit"),
      checkEmpty(data, "addressKeyword"),
      checkEmpty(data, "aoiTypeCode"),
      checkEmpty(data, "innerMark"),
      checkEmpty(data, "originDept"),
      checkEmpty(data, "appliedAoiCode"),
      checkEmpty(data, "appliedAoiId"),
      checkEmpty(data, "appliedAoiInfo"),
      checkEmpty(data, "aoiAreaGroup"),
      checkEmpty(data, "deptGroup")
    )
  }

  def checkEmpty(json: JSONObject, key: String) = {
    val str = json.getString(key)
    if (str == null || str.trim.isEmpty) {
      1
    } else {
      0
    }
  }

  def querySingleRetInf(obj: JSONObject, date: Date): java.util.ArrayList[RlsSta] = {
    val retList = new util.ArrayList[RlsSta]()
    val day = DateUtil.longToTime(date.getTime, "yyyyMMdd")
    try {
      val data = obj.getJSONObject("message").getJSONObject("data")
      retList.add(parserController(data, date, day))
    } catch {
      case e: Exception =>
        retList.add(RlsSta("" + day + date.getHours + date.getMinutes,
          "" + day, date.getHours, date.getMinutes, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1, 1, 1, 1, 1))

    }
    retList
  }

  def queryBatchRetInf(obj: JSONObject, date: Date) = {
    val retList = new util.ArrayList[RlsSta]()
    val day = DateUtil.longToTime(date.getTime, "yyyyMMdd")
    try {
      val data = obj.getJSONObject("message").getJSONArray("responses")
      for (i <- 0 until data.size()) {
        try {
          val item = data.getJSONObject(i)
          retList.add(parserController(item, date, day))
        } catch {
          case e: Exception => retList.add(RlsSta("" + day + date.getHours + date.getMinutes,
            "" + day, date.getHours, date.getMinutes, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1))
        }

      }
    } catch {
      case e: Exception =>
    }
    retList
  }

  def staResponseEmptyInfo(logRdd: RDD[String], date: Date) = {
    val argsRdd: RDD[(String, JSONObject)] = logRdd.filter(obj => {
      obj.contains("teamCodeCotrollerArgs")
    }).filter(obj => {
      val json = JSON.parseObject(obj)
      val request = json.getJSONObject("message").getJSONObject("request")
      val address: String = request.getString("address")
      val addressChar: List[Char] = address.toList.distinct
      addressChar.size == 1 && addressChar.head.toString == "*"
    }).map(obj => {
      val json = JSON.parseObject(obj)
      val requestId = json.getJSONObject("message").getString("requestId")
      json.put("requestId", requestId)
      (requestId, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("地址全部为*的数据量:"+argsRdd.count())
    val retRdd: RDD[(String, JSONObject)] = logRdd.filter(obj => {
      obj.contains("teamCodeCotrollerRet") || obj.contains("teamCodeBatchCotrollerRet")
    }).map(obj => {
      val json = JSON.parseObject(obj)
      val requestId = json.getJSONObject("message").getString("requestId")
      json.put("requestId", requestId)
      (requestId, json)
    })
    val joinArgsRdd: RDD[JSONObject] = retRdd.leftOuterJoin(argsRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.put("argsRequestId", rightObj.getString("requestId"))
      }
      leftObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    argsRdd.unpersist()
    val filterRetRdd: RDD[JSONObject] = joinArgsRdd.filter(obj => {
      obj.getString("argsRequestId") == null
    })
    val addressStarCnt: Long = joinArgsRdd.filter(obj => {
      obj.getString("argsRequestId") != null
    }).count()
    val staRetRdd: RDD[RlsSta] = filterRetRdd.flatMap(obj => {
      val objStr: String = obj.toJSONString
      if (objStr.contains("teamCodeCotrollerRet")) {
        querySingleRetInf(obj, date).iterator()
      } else if (objStr.contains("teamCodeBatchCotrollerRet")) {
        queryBatchRetInf(obj, date).iterator()
      } else {
        val retList = new util.ArrayList[RlsSta]()
        retList.iterator()
      }
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("过滤带*的地址后数据量:"+staRetRdd.count())
    if (staRetRdd.count() != 0) {
      val staRet = staRetRdd.reduce((obj1, obj2) => {
        RlsSta(obj1.id, obj1.stat_day, obj1.stat_hour, obj1.stat_end_minu,
          obj1.totalNum + obj2.totalNum,
          obj1.retCode + obj2.retCode,
          obj1.retBy + obj2.retBy,
          obj1.deptCode + obj2.deptCode,
          obj1.teamCode + obj2.teamCode,
          obj1.addrType + obj2.addrType,
          obj1.waybillNo + obj2.waybillNo,
          obj1.aoiId + obj2.aoiId,
          obj1.aoiCode + obj2.aoiCode,
          obj1.aoiAreaCode + obj2.aoiAreaCode,
          obj1.aoiUnit + obj2.aoiUnit,
          obj1.addressKeyword + obj2.addressKeyword,
          obj1.aoiTypeCode + obj2.aoiTypeCode,
          obj1.innerMark + obj2.innerMark,
          obj1.originDept + obj2.originDept,
          obj1.appliedAoiCode + obj2.appliedAoiCode,
          obj1.appliedAoiId + obj2.appliedAoiId,
          obj1.appliedAoiInfo + obj2.appliedAoiInfo,
          obj1.aoiAreaGroup + obj2.aoiAreaGroup,
          obj1.deptGroup + obj2.deptGroup
        )
      })
      val inserRet = insertIntoMysql(staRet,addressStarCnt)
      println("inserRet:" + inserRet)
    }
    staRetRdd.unpersist()
    joinArgsRdd.unpersist()
  }

  def insertIntoMysql(rlsSta: RlsSta,addressStarCnt:Long) = {
    val url: String = "jdbc:mysql://gismonitor-m.db.sfcloud.local:3306/gismonitor?useSSL=false&useUnicode=true&characterEncoding=utf-8"
    val username: String = "gismonitor"
    val password: String = "Gismonitor$3421"
//    println("com.mysql.cj.jdbc.Driver")
    Class.forName("com.mysql.cj.jdbc.Driver");
    val conn = DriverManager.getConnection(url, username, password)
    val sql = s"insert ignore into  `chk_query_field_stat`(`id`,`stat_day`,`stat_hour`,`stat_end_minu`,`total_num`, `retCode`,`retBy`,`deptCode`,`teamCode`,`addrType`,`waybillNo`,`aoiId`,`aoiCode`,`aoiAreaCode`,`aoiUnit`,`addressKeyword`,`aoiTypeCode`,`innerMark`,`originDept`,`appliedAoiCode`,`appliedAoiId`,`appliedAoiInfo`,`aoiAreaGroup`,`deptGroup`" +
      s",`addressStarCnt`) " +
      s"values(${
        rlsSta.id
      },${
        rlsSta.stat_day
      },${
        rlsSta.stat_hour
      },${
        rlsSta.stat_end_minu
      },${
        rlsSta.totalNum
      },${
        rlsSta.retCode
      },${
        rlsSta.retBy
      },${
        rlsSta.deptCode
      },${
        rlsSta.teamCode
      },${
        rlsSta.addrType
      },${
        rlsSta.waybillNo
      },${
        rlsSta.aoiId
      },${
        rlsSta.aoiCode
      },${
        rlsSta.aoiAreaCode
      },${
        rlsSta.aoiUnit
      },${
        rlsSta.addressKeyword
      },${
        rlsSta.aoiTypeCode
      },${
        rlsSta.innerMark
      },${
        rlsSta.originDept
      },${
        rlsSta.appliedAoiCode
      },${
        rlsSta.appliedAoiId
      },${
        rlsSta.appliedAoiInfo
      },${
        rlsSta.aoiAreaGroup
      },${
        rlsSta.deptGroup
      },$addressStarCnt" +
      s")"
    val ps = conn.prepareStatement(sql)
    val ret = ps.executeUpdate()
    conn.close()
    ret
  }

  /**
   * 处理窗口获取的日志
   *
   * @param windowLog
   */
  def dealWindowLog(windowLog: DStream[String], today: String, hdfsPath: String): Unit = {
    windowLog.foreachRDD(logRdd => {
      logger.error("---------------------------------本次流数据处理start--------------------------------------")
      logger.error(">>>统计日期：" + today + ",>>>日志路径：" + hdfsPath + ",>>>appName=" + appName)
//      try {
        //        dealLogTask(logRdd: RDD[String], today: String)
        val date = new Date()

        staResponseEmptyInfo(logRdd, date)

//      } catch {
//
//        case e: Exception => logger.error(">>>本次流处理异常：" + e)
//      }
      logger.error("---------------------------------本次流数据处理end-----------------------------------------")
    })
  }

  //  def dealLogTask(logRdd: RDD[String], today: String): Unit = {
  //    logger.error(">>>拉取窗口日志量：" + logRdd.count() + ",解析日志...")
  //    val (singleLog, batchLog) = parseLog(logRdd, today)
  //    logger.error(">>>统计指标")
  //    val (singleIndexMinRdd, batchIndexMinRdd) = statIndex(singleLog, batchLog)
  //    logger.error(">>>单个请求指标入库量：" + singleIndexMinRdd.count() + ",指标入库中...")
  //    updateSingleIndex(singleIndexMinRdd)
  //    logger.error(">>>批量请求指标入库量：" + batchIndexMinRdd.count() + ",指标入库中...")
  //    updateBatchIndex(batchIndexMinRdd)
  //    logger.error(">>>指标入库结束.")
  //
  //    singleIndexMinRdd.unpersist()
  //    batchIndexMinRdd.unpersist()
  //    singleLog.unpersist()
  //    batchLog.unpersist()
  //  }

//  /**
//   * 解析日志
//   *
//   * @param logRdd
//   */
//  def parseLog(logRdd: RDD[String], date: String): (RDD[JSONObject], RDD[JSONObject]) = {
//    var validLog: RDD[String] = getValidRdd(logRdd, date).repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error(">>>有效的日志量：" + validLog.count() + "，日志解析中...")
//    //单条请求的日志
//    val singleReqLog = validLog.filter(
//      line => {
//        line.contains("teamCodeCotrollerArgs")
//      }
//    ).map(line => {
//      val json = new JSONObject()
//      var reqId = ""
//      //      val reqId = StringUtil.pickGroup1Str(line, "--start-- (.*?)=>teamCodeCotrollerArgs:")
//      try {
//        val originJson = JSON.parseObject(line)
//        val message = originJson.getJSONObject("message")
//        val reqTime = message.getString("dataTime")
//        reqId = message.getString("requestId")
//        var ak = "-"
//        var addressType = "-"
//        var dimension = "-"
//        val body = message.getJSONObject("request")
//        if (body != null) {
//          if (body.getString("addressType") != null) addressType = body.getString("addressType")
//          if (body.getString("ak") != null) ak = body.getString("ak")
//        }
//        if (addressType.equals("1")) {
//          dimension = "PU" //收件
//        }
//        if (addressType.equals("2")) {
//          dimension = "DLV" //派件
//        }
//
//        json.put("reqTime", reqTime)
//        json.put("ak", ak)
//        json.put("dimension", dimension)
//      } catch {
//        case e: Exception => logger.error(">>>解析异常：" + e)
//      }
//      (reqId, json)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error(">>>singleReqLog数量：" + singleReqLog.count())
//
//    //单条返回的日志
//    val singleRetLog = validLog.filter(
//      line => {
//        line.contains("teamCodeCotrollerRet")
//      }
//    ).map(line => {
//      val originJson = JSON.parseObject(line)
//      val message = originJson.getJSONObject("message")
//      val retTime = message.getString("dataTime")
//      val reqId = message.getString("requestId")
//      val json = new JSONObject()
//      json.put("retTime", retTime)
//      (reqId, json)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error(">>>singleRetLog数量：" + singleRetLog.count())
//
//    val singleLog = singleReqLog.union(singleRetLog).reduceByKey((o1, o2) => {
//      o1.fluentPutAll(o2)
//      o1
//    }).map(_._2).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error(">>>合并单个请求和返回后的日志量：" + singleLog.count())
//
//
//    val batchLog = validLog.filter(line => {
//      line.contains("teamCodeBatchCotrollerArg") || line.contains("teamCodeBatchCotrollerRet")
//    }).map(line => {
//      var result: (String, JSONObject) = null
//      try {
//        if (line.contains("teamCodeBatchCotrollerArg")) result = parseBatchReq(line)
//        else if (line.contains("teamCodeBatchCotrollerRet")) result = parseBatchRet(line)
//      } catch {
//        case e: Exception => logger.error(">>>解析批量行日志异常" + e)
//      }
//      result
//    }).filter(_ != null).reduceByKey((o1, o2) => {
//      o1.fluentPutAll(o2)
//      o1
//    }).map(_._2).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error(">>>解析后批量返回的日志量：" + batchLog.count())
//
//    validLog.unpersist()
//    singleReqLog.unpersist()
//    singleRetLog.unpersist()
//
//    (singleLog, batchLog)
//  }

//  /**
//   * 统计实时指标
//   *
//   * @param singleLog
//   * @param batchLog
//   * @return
//   */
//  def statIndex(singleLog: RDD[JSONObject], batchLog: RDD[JSONObject]): (RDD[JSONObject], RDD[JSONObject]) = {
//    logger.error(">>>统计单个请求分钟的指标...")
//    val singleRdd = singleLog.filter(json => {
//      val reqTime = json.getString("reqTime")
//      reqTime != null
//    }).map(json => {
//      var reqTime = json.getString("reqTime")
//      var ak = json.getString("ak")
//      if (ak == null) println("json1:" + json)
//      var dimension = "-"
//      if (json.getString("dimension") != null) dimension = json.getString("dimension")
//      val retTime = json.getString("retTime")
//      var time = 0
//      if (retTime != null) {
//        time = (timeToLong(retTime) - timeToLong(reqTime)).toInt
//      }
//      reqTime = reqTime.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "").substring(0, 12)
//      if (ak == null) println("json2:" + json)
//      ((reqTime, ak, dimension), time)
//    })
//    //    statRdd.foreach(o=>{println("行指标："+o)})
//
//    //ak为ALL时候的指标
//    val singleRddAkAll = singleRdd.map(obj => {
//      ((obj._1._1, "ALL", obj._1._3), obj._2)
//    })
//
//    //维度为TOTAL时候的指标
//    val statRddDimAll = singleRdd.map(obj => {
//      val reqTime = obj._1._1
//      val ak = obj._1._2
//      val dimension = "TOTAL"
//      val time = obj._2
//      ((reqTime, ak, dimension), time)
//    })
//
//    //ak为ALL 维度为TOTAL时候的指标
//    val statRddAll = singleRdd.map(obj => {
//      val reqTime = obj._1._1
//      val ak = "ALL"
//      val dimension = "TOTAL"
//      val time = obj._2
//      ((reqTime, ak, dimension), time)
//    })
//
//    val statLogMinAll = singleRdd.union(singleRddAkAll).union(statRddDimAll).union(statRddAll)
//    val singleIndexMinRdd = getMinRddIndex(statLogMinAll).repartition(1).persist() //统计单条每分钟的指标
//
//    logger.error(">>>统计批量请求分钟的指标...")
//    val batchRdd = batchLog.filter(json => {
//      val reqTime = json.getString("reqTime")
//      reqTime != null
//    }).map(json => {
//      var reqTime = json.getString("reqTime")
//      var ak = json.getString("ak")
//      //			if(ak==null)println("json1:"+json)
//      var dimension = "-"
//      if (json.getString("dimension") != null) dimension = json.getString("dimension")
//      val retTime = json.getString("retTime")
//      var time = 0
//      if (retTime != null) {
//        time = (timeToLong(retTime) - timeToLong(reqTime)).toInt
//      }
//      reqTime = reqTime.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "").substring(0, 12)
//      if (ak == null) ak = "-"
//      ((reqTime, ak, dimension), time)
//    })
//
//    val batchRddAkAll = batchRdd.map(obj => {
//      val reqTime = obj._1._1
//      val ak = "ALL"
//      val dimension = obj._1._3
//      val time = obj._2
//      ((reqTime, ak, dimension), time)
//    })
//    //统计批量ak维度以及ak为ALL时候的分钟指标
//    val batchIndexMinRdd = getMinRddIndex(batchRdd.union(batchRddAkAll)).repartition(1).persist()
//    (singleIndexMinRdd, batchIndexMinRdd)
//  }
//
//  /**
//   * 批量的分钟指标
//   *
//   * @param statRdd
//   * @return
//   */
//  def getMinRddIndex(statRdd: RDD[((String, String, String), Int)]): RDD[JSONObject] = {
//    val indexRddMin = statRdd.groupByKey().map(record => {
//      val reqTime = record._1._1
//      val ak = record._1._2
//      val dimension = record._1._3
//      val date = reqTime.substring(0, 8)
//      val groupRdd: Iterable[Int] = record._2
//      val reqCount = groupRdd.size
//      var respTimeList = new ArrayBuffer[Int]()
//      for (respTime <- groupRdd) {
//        if (respTime != 0) respTimeList += respTime
//      }
//      respTimeList = respTimeList.sorted //升序排列
//      val size = respTimeList.size
//      var avgRespTime, maxRespTime, minRespTime, p99RespTime = 0
//      if (size > 0) {
//        avgRespTime = Math.round(respTimeList.sum / size)
//        maxRespTime = respTimeList(respTimeList.length - 1)
//        minRespTime = respTimeList(0)
//        val p99Index = Math.round(respTimeList.size * 0.99).toInt
//        p99RespTime = respTimeList(p99Index - 1)
//      }
//      val json = new JSONObject()
//      json.put("reqTime", reqTime)
//      json.put("ak", ak)
//      json.put("dimension", dimension)
//      json.put("date", date)
//      json.put("reqCount", reqCount)
//      json.put("maxRespTime", maxRespTime)
//      json.put("avgRespTime", avgRespTime)
//      json.put("minRespTime", minRespTime)
//      json.put("p99RespTime", p99RespTime)
//      json
//    })
//
//    indexRddMin
//  }

  //  /**
  //   * 更新单条请求的指标
  //   *
  //   * @param indexMinRdd
  //   */
  //  def updateSingleIndex(indexMinRdd: RDD[JSONObject]): Unit = {
  //
  //    val REQ_QRY_SNGL_DETAIL = "REQ_QRY_SNGL_DETAIL"
  //    val REQ_QRY_SNGL = "REQ_QRY_SNGL"
  //    val AK = "AK"
  //    logger.error(">>>打印单个请求分钟指标")
  //    println("id,stat_datetime,ak,stat_dmns,req_count,resp_time,resp_time_99,stat_date")
  //    indexMinRdd.take(1).foreach(println)
  //    indexMinRdd.foreachPartition(partitionRdd => {
  //      var conn: Connection = null
  //      try {
  //        conn = DbUtils.getConn(javaUtil)
  //        partitionRdd.foreach(json => {
  //          var ak = json.getString("ak")
  //          if (ak == null) ak = "-"
  //          val reqTime = json.getString("reqTime")
  //          val date = json.getString("date")
  //          val dimension = json.getString("dimension")
  //          val reqCount = json.getInteger("reqCount")
  //          val avgRespTime = json.getInteger("avgRespTime")
  //          val p99RespTime = json.getInteger("p99RespTime")
  //          val id = MD5Util.getMD5(reqTime + ak + dimension)
  //          //更新ak表
  //          if (!ak.equals("ALL") && !ak.equals("-")) {
  //            val project = "RDS"
  //            val akId = MD5Util.getMD5(ak + project)
  //            val akSelectSql = String.format("select ak from AK where id = '%s'", akId)
  //            val akInsertSql = String.format(s"insert into $AK (id,ak,project) values('%s','%s','%s')", akId, ak, project)
  //            val akList = DbUtils.selectColumn(conn, akSelectSql, Array("ak"))
  //            if (!akList.contains(ak)) {
  //              DbUtils.executeSql(conn, akInsertSql)
  //            }
  //          }
  //
  //          val selectSql = String.format(s"SELECT REQ_COUNT FROM $REQ_QRY_SNGL_DETAIL where id='%s' ", id)
  //          val insertSql = String.format(s"insert into $REQ_QRY_SNGL_DETAIL (ID,STAT_DATETIME,AK,STAT_DMNS,REQ_COUNT,RESP_TIME,RESP_TIME_99,STAT_DATE) values('%s','%s','%s','%s',%s,'%s',%s,'%s')", id, reqTime, ak, dimension, reqCount.toString, avgRespTime.toString, p99RespTime.toString, date)
  //          val updateSql = String.format(s"update $REQ_QRY_SNGL_DETAIL set req_count=%s,RESP_TIME=%s,RESP_TIME_99=%s where id = '%s' ", reqCount.toString, avgRespTime.toString, p99RespTime.toString, id)
  //          val stmt = conn.createStatement()
  //          val resultSet = stmt.executeQuery(selectSql)
  //          if (resultSet.first()) {
  //            //调用first判断是否有返回值,移动了光标,因此不需要next(),即可取值,否则查询时先执行while(resultSet.next()).
  //            val count = resultSet.getInt(1)
  //            if (count < reqCount) {
  //              //新增的指标数据更好
  //              stmt.executeUpdate(updateSql)
  //            }
  //          } else {
  //            //没有查询到数据，直接执行插入
  //            stmt.executeUpdate(insertSql)
  //          }
  //          val arr = Array(id, reqTime, ak, dimension, reqCount, avgRespTime, p99RespTime, date)
  //          //			println("分钟数据:"+arr.mkString(","))
  //
  //          val idDate = MD5Util.getMD5(date + ak + dimension)
  //          val columns = Array("req_max", "req_avg", "req_min", "resp_time_max", "resp_time_avg", "resp_time_min", "resp_time_99max", "resp_time_99avg", "resp_time_99min")
  //          val selectSqlDay = String.format(s"select MAX(req_count) req_max,AVG(req_count) req_avg ,MIN(req_count) req_min  , MAX(resp_time) resp_time_max,AVG(resp_time) resp_time_avg,MIN(resp_time) resp_time_min  ,MAX(resp_time_99) resp_time_99max,AVG(resp_time_99) resp_time_99avg ,MIN(resp_time_99) resp_time_99min from $REQ_QRY_SNGL_DETAIL where  ak = '%s' and stat_dmns = '%s' AND stat_date= '%s' ", ak, dimension, date)
  //          val dayIndexss: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, selectSqlDay, null, columns)
  //          val dayIndexs = dayIndexss(0)
  //          //			println("按天指标："+dayIndexs.mkString(","))
  //          val insertSqlDay = String.format(s"insert into  $REQ_QRY_SNGL(id,stat_date,stat_dmns,ak,req_max,req_avg,req_min,resp_time_max,resp_time_avg,resp_time_min,resp_time_99max,resp_time_99avg,resp_time_99min) values(?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update stat_date=?,stat_dmns=?,ak=?,req_max=?,req_avg=?,req_min=?,resp_time_max=?,resp_time_avg=?,resp_time_min=?,resp_time_99max=?,resp_time_99avg=?,resp_time_99min=? ")
  //          val paramArray = Array(idDate, date, dimension, ak, dayIndexs(0), dayIndexs(1), dayIndexs(2), dayIndexs(3), dayIndexs(4), dayIndexs(5), dayIndexs(6), dayIndexs(7), dayIndexs(8), date, dimension, ak, dayIndexs(0), dayIndexs(1), dayIndexs(2), dayIndexs(3), dayIndexs(4), dayIndexs(5), dayIndexs(6), dayIndexs(7), dayIndexs(8))
  //          DbUtils.executeSql(conn, insertSqlDay, paramArray)
  //        })
  //      } catch {
  //        case e: Exception => logger.error(">>>分钟指标入库异常：" + e)
  //      } finally {
  //        conn.close()
  //      }
  //    })
  //  }


  //  def updateBatchIndex(indexMinRdd: RDD[JSONObject]): Unit = {
  //    val REQ_QRY_BTCH_DETAIL = "REQ_QRY_BTCH_DETAIL"
  //    val REQ_QRY_BTCH = "REQ_QRY_BTCH"
  //    val AK = "AK"
  //    logger.error(">>>打印批量分钟指标")
  //    println("id,stat_datetime,ak,req_count,resp_time,resp_time_99,stat_date")
  //    indexMinRdd.take(1).foreach(println)
  //
  //
  //    indexMinRdd.foreachPartition(rdd => {
  //      var conn: Connection = null
  //      try {
  //        conn = DbUtils.getConn(javaUtil)
  //        rdd.foreach(json => {
  //
  //          var ak = json.getString("ak")
  //          if (ak == null) ak = "-"
  //          val reqTime = json.getString("reqTime")
  //          val date = json.getString("date")
  //          val reqCount = json.getInteger("reqCount")
  //          val avgRespTime = json.getInteger("avgRespTime")
  //          val p99RespTime = json.getInteger("p99RespTime")
  //          val id = MD5Util.getMD5(reqTime + ak)
  //          //更新ak表
  //          if (!ak.equals("ALL") && !ak.equals("-")) {
  //            val project = "RDS"
  //            val akId = MD5Util.getMD5(ak + project)
  //            val akSelectSql = String.format(s"select ak from $AK where id = '%s'", akId)
  //            val akInsertSql = String.format(s"insert into $AK (id,ak,project) values('%s','%s','%s')", akId, ak, project)
  //            val akList = DbUtils.selectColumn(conn, akSelectSql, Array("ak"))
  //            if (!akList.contains(ak)) {
  //              logger.error(">>>新增了ak:" + ak)
  //              DbUtils.executeSql(conn, akInsertSql)
  //            }
  //          }
  //
  //          val selectSql = String.format("select req_count from %s where id='%s' ", REQ_QRY_BTCH_DETAIL, id)
  //          val insertSql = String.format("insert into %s (id,stat_datetime,ak,req_count,resp_time,resp_time_99,stat_date) values('%s','%s','%s','%s','%s',%s,'%s')", REQ_QRY_BTCH_DETAIL, id, reqTime, ak, reqCount.toString, avgRespTime.toString, p99RespTime.toString, date)
  //          val updateSql = String.format("update %s set req_count=%s,resp_time=%s,resp_time_99=%s where id = '%s' ", REQ_QRY_BTCH_DETAIL, reqCount.toString, avgRespTime.toString, p99RespTime.toString, id)
  //          val stmt = conn.createStatement()
  //          val resultSet = stmt.executeQuery(selectSql)
  //          if (resultSet.first()) {
  //            //调用first判断是否有返回值,移动了光标,因此不需要next(),即可取值,否则查询时先执行while(resultSet.next()).
  //            val count = resultSet.getInt(1)
  //            if (count < reqCount) {
  //              //新增的指标数据更好
  //              stmt.executeUpdate(updateSql)
  //            }
  //          } else {
  //            //没有查询到数据，直接执行插入
  //            stmt.executeUpdate(insertSql)
  //          }
  //
  //          val arr = Array(id, reqTime, ak, reqCount, avgRespTime, p99RespTime, date)
  //          //			println("分钟指标："+arr.mkString(","))
  //          val idDate = MD5Util.getMD5(date + ak)
  //          val columns = Array("req_max", "req_avg", "req_min", "resp_time_max", "resp_time_avg", "resp_time_min", "resp_time_99max", "resp_time_99avg", "resp_time_99min")
  //          val selectSqlDay = String.format(s"select MAX(req_count) req_max,AVG(req_count) req_avg ,MIN(req_count) req_min  , MAX(resp_time) resp_time_max,AVG(resp_time) resp_time_avg,MIN(resp_time) resp_time_min  ,MAX(resp_time_99) resp_time_99max,AVG(resp_time_99) resp_time_99avg ,MIN(resp_time_99) resp_time_99min from $REQ_QRY_BTCH_DETAIL where  ak = '%s' and  stat_date= '%s' ", ak, date)
  //          val dayIndexss: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, selectSqlDay, null, columns)
  //          val dayIndexs = dayIndexss(0)
  //          //			println("按天指标："+dayIndexs.mkString(","))
  //          val insertSqlDay = String.format(s"insert into  $REQ_QRY_BTCH(id,stat_date,ak,req_max,req_avg,req_min,resp_time_max,resp_time_avg,resp_time_min,resp_time_99max,resp_time_99avg,resp_time_99min) values(?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update stat_date=?,ak=?,req_max=?,req_avg=?,req_min=?,resp_time_max=?,resp_time_avg=?,resp_time_min=?,resp_time_99max=?,resp_time_99avg=?,resp_time_99min=? ")
  //          val paramArray = Array(idDate, date, ak, dayIndexs(0), dayIndexs(1), dayIndexs(2), dayIndexs(3), dayIndexs(4), dayIndexs(5), dayIndexs(6), dayIndexs(7), dayIndexs(8), date, ak, dayIndexs(0), dayIndexs(1), dayIndexs(2), dayIndexs(3), dayIndexs(4), dayIndexs(5), dayIndexs(6), dayIndexs(7), dayIndexs(8))
  //          DbUtils.executeSql(conn, insertSqlDay, paramArray)
  //        })
  //      } catch {
  //        case e: Exception => logger.error(">>>更新批量指标异常：" + e)
  //      } finally {
  //        conn.close()
  //      }
  //    })
  //
  //
  //  }


//  /**
//   * 批量请求的日志性能指标
//   *
//   * @param line
//   * @return
//   */
//  def parseBatchReq(line: String): (String, JSONObject) = {
//    val originJson = JSON.parseObject(line)
//    val message = originJson.getJSONObject("message")
//    val reqTime = message.getString("dataTime")
//    val reqId = message.getString("requestId")
//
//    var ak = "-"
//    val bodys = message.getJSONArray("requests")
//    val firstBody = JSON.parseObject(bodys.get(0).toString)
//    if (firstBody != null && firstBody.getString("ak") != null) ak = firstBody.getString("ak")
//    val json = new JSONObject()
//    json.put("reqTime", reqTime)
//    json.put("ak", ak)
//    json.put("first_body", firstBody)
//    (reqId, json)
//  }
//
//  /**
//   * 批量返回的日志性能指标
//   *
//   * @param line
//   * @return
//   */
//  def parseBatchRet(line: String): (String, JSONObject) = {
//    val originJson = JSON.parseObject(line)
//    val message = originJson.getJSONObject("message")
//    val reqTime = message.getString("dataTime")
//    val reqId = message.getString("requestId")
//    val json = new JSONObject()
//    json.put("retTime", reqTime)
//    (reqId, json)
//  }
//
//
//  def getTime(line: String): String = {
//    val datetime = StringUtils.pickGroup1Str(line, "\\[(\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s\\d{3})\\]")
//    datetime
//  }
//
//  /**
//   * 时间字符串转换成毫秒值
//   * 样例：2018-10-24 09:54:47 236 ==> 1540346087236
//   *
//   * @param time
//   * @return
//   */
//  def timeToLong(time: String): Long = {
//    val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS")
//    val longTime = sdf.parse(time).getTime
//    longTime
//  }
//
//  /**
//   * 获取有效的日志
//   *
//   * @param logRdd
//   * @return
//   */
//  def getValidRdd(logRdd: RDD[String], date: String): RDD[String] = {
//    val validRdd: RDD[String] = logRdd.filter(line => {
//      val isDate = line.contains(date) && line.contains("_tc")
//      val a = line.indexOf("teamCodeCotrollerArgs") > -1 //单个请求
//      val b = line.indexOf("teamCodeCotrollerRet") > -1 //单个返回
//      val c = line.indexOf("teamCodeBatchCotrollerArg") > -1 //批量请求
//      val d = line.indexOf("teamCodeBatchCotrollerRet") > -1 //批量返回
//      isDate && (a || b || c || d)
//    })
//    validRdd
//  }
//
//  /**
//   * 判断teamToResult是否是oms的数据
//   *
//   * @param line
//   * @return
//   */
//  def isOmsTeamToResult(line: String): Boolean = {
//    val reqId = StringUtils.pickGroup1Str(line, "--start-- (.*?)=>teamToResult:")
//    val isOms = reqId.indexOf("_OMS_") > -1 //oms的数据
//    isOms
//  }
//
//  /**
//   * 获得有效的日志
//   *
//   * @param logRdd
//   * @param incDay
//   * @return
//   */
//  def getValidLog(logRdd: RDD[String], incDay: String): RDD[JSONObject] = {
//    val validRdd: RDD[JSONObject] = logRdd.filter(line => {
//      line.contains("log#{\"dateTime\":\"" + incDay)
//    }).map(line => {
//      var json: JSONObject = null
//      try {
//        json = JSON.parseObject(line.substring(line.indexOf("{")))
//      } catch {
//        case e: Exception => {
//          logger.error(">>>日志格式不正确：" + e + "," + line)
//        }
//      }
//      json
//
//    }).filter(_ != null)
//    validRdd
//  }

  def getConf(appName: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
      .set("spark.port.maxRetries", "100")
      .set("spark.driver.maxResultSize", "12g")
      .set("spark.rpc.io.backLog", "10000")
      .set("spark.cleaner.referenceTracking.blocking", "false")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.driver.allowMultipleContexts", "true")
      .set("spark.sql.tungsten.enabled", "false")
      .set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
      .set("quota.consumer.default", (10485760 * 2).toString)
      .set("cache.max.bytes.buffering", (20485760 * 2).toString)
    conf
  }

  //  /**
  //   * 获取rds的mysql连接
  //   *
  //   * @return
  //   */
  //  def getRdsConn: Connection = {
  //    val Driver = javaUtil.get("oms.mysql.driver")
  //    val URL = javaUtil.get("oms.mysql.url")
  //    val USERNAME = javaUtil.get("oms.mysql.uid")
  //    val PASSWORD = javaUtil.get("oms.mysql.pwd")
  //    DbUtils.getMysqlConn(URL, Driver, USERNAME, PASSWORD)
  //  }

}
