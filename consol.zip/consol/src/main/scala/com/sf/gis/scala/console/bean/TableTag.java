package com.sf.gis.scala.console.bean;

public enum TableTag {
    sizeLess20M,//分区总大小小于20M
    partitionDiffWithHive,//分区和hive对不上
    sucDone,//已处理
}
