package com.sf.gis.scala.console.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * hdfs目录信息
 */
public class HdfsInfo implements Serializable {
    //hdfs前缀，到库级别
    private String hdfsPath;
    //hdfsHome
    private String hdfsHome;

    //数据库名称
    private String databaseName;
    //表名，外部表可能不是表名
    private String tableName;
    //分区名
    private List<KeyValue> partitionList = new ArrayList<>();
    ;
    //文件平均大小
    private long avgSize;
    //文件最大值
    private long maxSize;
    //文件最小值
    private long minSize;
    //可疑标签
    private Set<String> tagList = new HashSet<>();
    //库还是表
    private boolean isTable;
    //是否外部表
    private boolean isExternal;
    //是否分区表
    private boolean isPartitionType;

    //文件数
    private long size;
    //总大小
    private int fileCnt;
    //相关hive表
    private List<String> relateTables = new ArrayList<>();
    //是否存在hive表
    private boolean isExistTable = false;
    //是否存在hive分区, 目前无法在spark内部获取到分区是否存在，先默认为存在
    private boolean isHivePartitionExist = true;
    //存储格式
    private String tableFormat;
    //压缩格式
    private String compressType;

    public HdfsInfo() {

    }

    public HdfsInfo(String path, String modificationtime, String accesstime, long size, int filecount, String[] hdfsDbPathArray,
                    String hdfsPre) {
        for (String hdfsDbPathPre : hdfsDbPathArray) {
            if (!path.startsWith(hdfsDbPathPre)) {
                continue;
            }
            this.size = size;
            this.avgSize = size / filecount;
            this.fileCnt = filecount;
            this.hdfsPath = path;
            String[] splitPrePath = hdfsDbPathPre.split("/");
            this.databaseName = splitPrePath[splitPrePath.length - 1].replaceAll("\\.db", "");
            hdfsHome = hdfsPre + hdfsDbPathPre;
            String[] splitPath = path.replaceFirst(hdfsDbPathPre, "").split("/");
            if (splitPath.length == 0) {
                //库级别结束
                this.isTable = false;
                break;
            }
            this.isTable = true;
            tableName = splitPath[1];
            hdfsHome = hdfsHome + "/" + tableName;
            if (splitPath.length == 2) {
                //表级别，或者无分区表
                break;
            }

            isPartitionType = true;
            for (int i = 2; i < splitPath.length; i++) {
                //遍历分区
                String partition = splitPath[i];
                KeyValue partitionInfo = new KeyValue();
                if (partition.contains("=")) {
                    String[] nameData = partition.split("=");
                    partitionInfo.setKey(nameData[0]);
                    partitionInfo.setValue(nameData[1]);
                    isExternal = false;
                } else {
                    partitionInfo.setValue(partition);
                    isExternal = true;
                }
                partitionList.add(partitionInfo);
            }

            break;
        }
    }

    public String getTableFormat() {
        return tableFormat;
    }

    public void setTableFormat(String tableFormat) {
        this.tableFormat = tableFormat;
    }

    public String getCompressType() {
        return compressType;
    }

    public void setCompressType(String compressType) {
        this.compressType = compressType;
    }

    public String getHdfsHome() {
        return hdfsHome;
    }

    public void setHdfsHome(String hdfsHome) {
        this.hdfsHome = hdfsHome;
    }

    public List<String> getRelateTables() {
        return relateTables;
    }

    public void setRelateTables(List<String> relateTables) {
        this.relateTables = relateTables;
    }

    public boolean isExistTable() {
        return isExistTable;
    }

    public void setExistTable(boolean existTable) {
        isExistTable = existTable;
    }

    public boolean isHivePartitionExist() {
        return isHivePartitionExist;
    }

    public void setHivePartitionExist(boolean hivePartitionExist) {
        isHivePartitionExist = hivePartitionExist;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public int getFileCnt() {
        return fileCnt;
    }

    public void setFileCnt(int fileCnt) {
        this.fileCnt = fileCnt;
    }

    public List<KeyValue> getPartitionList() {
        return partitionList;
    }

    public void setPartitionList(List<KeyValue> partitionList) {
        this.partitionList = partitionList;
    }

    public boolean isTable() {
        return isTable;
    }

    public void setTable(boolean table) {
        isTable = table;
    }

    public boolean isExternal() {
        return isExternal;
    }

    public void setExternal(boolean external) {
        isExternal = external;
    }

    public boolean isPartitionType() {
        return isPartitionType;
    }

    public void setPartitionType(boolean partitionType) {
        isPartitionType = partitionType;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getHdfsPath() {
        return hdfsPath;
    }

    public void setHdfsPath(String hdfsPath) {
        this.hdfsPath = hdfsPath;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public long getAvgSize() {
        return avgSize;
    }

    public void setAvgSize(long avgSize) {
        this.avgSize = avgSize;
    }

    public long getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(long maxSize) {
        this.maxSize = maxSize;
    }

    public long getMinSize() {
        return minSize;
    }

    public void setMinSize(long minSize) {
        this.minSize = minSize;
    }

    public Set<String> getTagList() {
        return tagList;
    }

    public void setTagList(Set<String> tagList) {
        this.tagList = tagList;
    }

    public static class KeyValue {
        private String key;
        private String value;

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }
}
