package com.sf.gis.scala.console.app

import java.net.URLEncoder
import java.sql.DriverManager
import java.util.Date

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, MD5Util, StrUtils}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil}
import com.sf.gis.scala.console.app.common.FsManager
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-09-12 20:00
 * @TaskId:826031
 * @TaskName:seg-vip-地址定时测试
 * @Description: seg bsp服务跑大客户地址，结果存入运维监控mysql，防止大客户的地址问题
 */
object SegRunVip {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //ar的ip
  //  val url = "http://seg-shin.int.sfcloud.local:1080/seg/api/split?address=%s&ak=e6d2bea8c2e64c5b8b37718eb8ce81cf"
  val url = "http://gis-apis.int.sfcloud.local:1080/segbsp/api/split?address=%s&ak=e6d2bea8c2e64c5b8b37718eb8ce81cf"


  def loadVipAddress(sparkSession: SparkSession, addressPath: String, sourceFromDb: Boolean, isTest: Boolean) = {
    if (sourceFromDb) {
      loadVipAddressFromFileDb(sparkSession, isTest)
    } else {
      loadVipAddressFromFile(sparkSession, addressPath)
    }
  }

  def loadVipAddressFromFileDb(sparkSession: SparkSession, isTest: Boolean) = {

    var url: String = "jdbc:mysql://gismonitor-m.db.sfcloud.local:3306/gismonitor?useSSL=false&useUnicode=true&characterEncoding=utf-8"
    var username: String = "gismonitor"
    var password: String = "Gismonitor$3421"
    println("com.mysql.cj.jdbc.Driver")
    Class.forName("com.mysql.cj.jdbc.Driver");
    if (isTest) {
      url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useSSL=false&useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
      username = "gis_oms_rds"
      password = "gis_oms_rds@123@"
    }
    logger.error("url:" + url)
    var dataList = Array[JSONObject]()
    //      new java.util.ArrayList[JSONObject]()
    val conn = DriverManager.getConnection(url, username, password)
    val stmt = conn.createStatement
    val rs1 = stmt.executeQuery(s"select id,address,norm_citycode from seg_vip_addres_console")
    while (rs1.next()) {
      val json = new JSONObject()
      json.put("id", convertEmpty(rs1.getString(1)))
      json.put("address", convertEmpty(rs1.getString(2)))
      json.put("norm_citycode", convertEmpty(rs1.getString(3)))

      dataList = json +: dataList
    }
    conn.close()
    logger.error("装载seg vip地址总数量:" + dataList.size)
    dataList.take(10).foreach(obj => {
      logger.error(obj.toString())
    })
    dataList
  }

  def loadVipAddressFromFile(sparkSession: SparkSession, addressPath: String) = {
    val dataList = sparkSession.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      //不要开启自动探测，不然可能会转int，long
      //      .option("inferSchema", "true")
      .csv(addressPath)
      .toDF("address", "norm_citycode").rdd
      .map(obj => {
        val json = new JSONObject()
        json.put("address", convertEmpty(obj.getString(0)))
        json.put("norm_citycode", convertEmpty(obj.getString(1)))
        val addrsssMd5 = MD5Util.getMD5(json.getString("address"))
        json.put("id", addrsssMd5)
        json
      }
      ).collect()
    logger.error("装载seg vip地址总数量:" + dataList.size)
    dataList.take(10).foreach(obj => {
      logger.error(obj.toJSONString())
    })
    dataList
  }

  def convertEmpty(str: String): String = {
    if (str == null) {
      return ""
    }
    return str
  }


  def runInteface(dataList: Array[JSONObject], isTest: Boolean) = {
    var count = 0;
    val runRet = dataList.map(obj => {
      val address = URLEncoder.encode(obj.getString("address"), "utf-8")
      val tmpUrl = String.format(url, address);
      count = count + 1
      if (count % 500 == 0) {
        logger.error("已跑条数:" + count)
      }
      //      if(!"test".equals(isTest) ||  count<=11){
      var cnt = 0
      var retJson: JSONObject = null;
      while (cnt < 3) {
        try {
          retJson = HttpUtils.urlConnectionGetJson(tmpUrl, 3 * 1000)
          cnt = 3
        } catch {
          case e: Exception => {
            logger.error(e)
            Thread.sleep(3000)
            cnt = cnt + 1
            if (cnt >= 3) {
              throw e
            }
          }
        }

      }
      if (retJson != null) {
        if (count == 1) {
          logger.error(retJson.toString())
        }
        val citycode = JSONUtil.getJsonVal(retJson, "result.data.citycode", "")
        if (!citycode.equals(obj.getString("norm_citycode"))) {
          logger.error("数据不相等：" + citycode + "," + obj.getString("norm_citycode") + "----" + retJson)
        }
        (obj, citycode)
      } else {
        logger.error("返回为空：" + obj)
        (obj, null)
      }
      //      }else{
      //        (obj, "")
      //      }

    }).filter(obj => obj._2 != null)
    logger.error("运行后不为null的结果数：" + runRet.size)
    val emptyCnt = runRet.filter(obj => !StrUtils.isBlank(obj._2)).length;
    logger.error("运行后不为空的结果数：" + emptyCnt)
    runRet.take(2).foreach(obj => {
      logger.error(obj._1.toJSONString + "," + obj._2)
    })
    runRet
  }

  def main(args: Array[String]): Unit = {
    ///user/01374443/upload/ar
    val addressPath = args(0)
    //是否测试模式，会传到测试库
    var isTest = false
    if ("test".equals(args(1))) {
      isTest = true
    }
    //是否初始化，初始化，将以跑出的数据为准，更新全部数据
    var isInit = false
    if ("init".equals(args(2))) {
      //目前无用
      isInit = true
    }
    //标杆数据来源是否是数据库，或者文件
    var sourceFromDb = true
    if ("file".equals(args(3))) {
      sourceFromDb = false
    }
    val sparkSession = Spark.getSparkSession(appName, null, true, 1)
    logger.error("装载数据：" + addressPath)
    var dataList = loadVipAddress(sparkSession, addressPath, sourceFromDb, isTest)
    logger.error("开始跑接口")
    val invokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01374443", "826031", "seg-vip-地址定时测试", "大客户测试seg服务", url, "e6d2bea8c2e64c5b8b37718eb8ce81cf", dataList.length, 1)
    val runInterfaceRet = runInteface(dataList, isTest)
    BdpTaskRecordUtil.endNetworkInterface("01374443", invokeId)
    logger.error("打印不相等的数据,用于核实和修改")
    print_errordata(isTest, runInterfaceRet)
    logger.error("写表")
    insertIntoDisMysql(runInterfaceRet, isTest, isInit)
    val maxEmpty = 0
    if (runInterfaceRet.size < (dataList.size - maxEmpty)) {
      logger.error(s"*************为空数据超过${maxEmpty}条，请注意*************")
      System.exit(-1)
    }
    logger.error("完成")
  }

  def sendFsMsg(printRet: Array[(JSONObject, String)]): Unit = {
    try {
      //丰声告警相关信息
      val fsManager = new FsManager("segbsp")
      val token = fsManager.queryToken
      System.out.println("token:" + token)
      val time = (new Date).getTime
      printRet.foreach(obj => {
        val content = convertWarninggContent(obj._1, obj._2)
        fsManager.send(content.toJSONString, token, time, null)
      })

    } catch {
      case e: Exception => logger.error(e)
    }
  }

  def convertWarninggContent(data: JSONObject, r_citycode: String): JSONArray = {
    data.put("r_citycode", r_citycode)

    val keys = Array("id", "地址", "原城市", "现城市")
    val mapKeys = Array("id", "address", "norm_citycode", "r_citycode")
    val retArray = new JSONArray();
    for (i <- 0 until keys.length) {
      val tmpJobj = new JSONObject();
      tmpJobj.put("key", keys(i))
      tmpJobj.put("value", data.getString(mapKeys(i)) + " ")
      retArray.add(tmpJobj)
    }
    return retArray
  }

  def print_errordata(isTest: Boolean, runRet: Array[(JSONObject, String)]): Unit = {
    var printRet = runRet.filter(obj => {
      !obj._1.getString("norm_citycode").equals(obj._2)
    })
    if (!isTest) {
    } else {
      printRet = printRet.take(10)
    }
    println("address,norm_citycode,citycode")
    printRet.foreach(obj => {
      println(obj._1.getString("address") + "," + obj._1.getString("norm_citycode") + "," + obj._2)
    })
    if (printRet.length > 0) {
      logger.error("发告警")
      sendFsMsg(printRet)
    } else {
      logger.error("无需告警")
    }
  }

  def insertIntoDisMysql(runRet: Array[(JSONObject, String)], isTest: Boolean, isCleanTable: Boolean) = {
    var url: String = "jdbc:mysql://gismonitor-m.db.sfcloud.local:3306/gismonitor?useSSL=false&useUnicode=true&characterEncoding=utf-8"
    var username: String = "gismonitor"
    var password: String = "Gismonitor$3421"
    println("com.mysql.cj.jdbc.Driver")
    Class.forName("com.mysql.cj.jdbc.Driver");
    if (isTest) {
      url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useSSL=false&useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
      username = "gis_oms_rds"
      password = "gis_oms_rds@123@"
    }
    logger.error("url:" + url)
    val conn = DriverManager.getConnection(url, username, password)
    //    if(isCleanTable){
    //      logger.error("清除表")
    //      val ps = conn.prepareStatement(s" truncate table seg_vip_addres_console ")
    //      ps.executeUpdate()
    //    }
    val modifyTime = DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss");
    var count = 0
    runRet.foreach(obj => {
      count = count + 1
      if (count % 500 == 0) {
        logger.error("count:" + count)
      }
      val sql = s"insert into  `seg_vip_addres_console`(`id`,`address`,`norm_citycode`,`citycode`,`MODIFY_TIME`) " +
        s"values('${obj._1.getString("id")}','${obj._1.getString("address").replace("'", "’")}'," +
        s"'${obj._1.getString("norm_citycode")}','${obj._2}','${modifyTime}')" +
        s" ON DUPLICATE KEY update citycode='${obj._2}',MODIFY_TIME='${modifyTime}' "
      //      try{
      val ps = conn.prepareStatement(sql)
      ps.executeUpdate()
      //      }catch {
      //        case e:Exception=> logger.error(obj._2)
      //      }

    })
    val stmt = conn.createStatement
    val rs = stmt.executeQuery("select count(1) from seg_vip_addres_console")
    while (rs.next()) {
      logger.error("表里面总数" + rs.getLong(1));
    }
    val rs1 = stmt.executeQuery("select * from seg_vip_addres_console limit 1")
    while (rs1.next()) {
      logger.error("id:" + rs1.getString(1));
      logger.error("address:" + rs1.getString(2));
      logger.error("norm_citycode:" + rs1.getString(3));
      logger.error("citycode:" + rs1.getString(4));
    }
    conn.close()
  }
}