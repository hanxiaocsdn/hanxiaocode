package com.sf.gis.scala.console.app

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-03-10 15:49
 * @TaskId:
 * @TaskName:
 * @Description: 获取库表信息
 */
object PullDbTables {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    //表明检测的时间
    val databaseName = args(0)
    start(databaseName)
  }
  def start(databaseName: String): Unit ={
    val sparkSession = Spark.getSparkSession(appName)
    parseDatabases(sparkSession,databaseName)
  }
  def parseDatabases(sparkSession: SparkSession, databaseName:String) = {

      logger.error("当前数据库：" + databaseName)
      sparkSession.sql(s"use $databaseName")
      val tableList = sparkSession.sql("show tables").rdd.map(obj => {
        obj.getString(1)
      }).collect()
      logger.error("总数据表数量：" + tableList.size + ",样例:" + tableList(0))
      val arrayList = new util.ArrayList[JSONObject]()
      for (name <- tableList) {
        try {
          val tableInfo = sparkSession.sql(s"show create table $name").rdd.flatMap(obj => {
            obj.getString(0).split("\n").iterator
          }).collect()
          logger.error("size:"+tableInfo.size)
          tableInfo.foreach(obj => {
            logger.error("信息-----"+obj + "-----结束")
          })
          val ret = new JSONObject()
          ret.put("name", name)
          val showCreateArrayBuffer = new ArrayBuffer[String]()
          var over = false;
          for (info <- tableInfo; if !over) {
            logger.error("*******"+info + "-----********end")
            if (info.startsWith("COMMENT '")) {
              ret.put("comment", info.replaceAll("COMMENT '", "").replaceAll("'", ""))
            }
            if (info.startsWith("WITH") || info.startsWith("ROW")
              || info.startsWith("STORED") || info.startsWith("LOCATION")
              || info.startsWith("TBLPROPERTIES")
              || info.startsWith("USING")
            ) {
              over = true
            } else {
              var tmp  = info.replaceAll("[\\r\\n\\t]", "")

              showCreateArrayBuffer.append(tmp)
            }
          }
          ret.put("info", showCreateArrayBuffer.mkString(" "))
          arrayList.add(ret)
        }catch{
            case e:Exception=> logger.error(e)
          }
      }
    import sparkSession.implicits._
      sparkSession.sparkContext.parallelize(arrayList.toArray).map(obj=>{
        val tmp = obj.asInstanceOf[JSONObject]
        (tmp.getString("name"),tmp.getString("comment"),tmp.getString("info"))
      }).toDF("name","comment","info").repartition(1)
        .createOrReplaceTempView("tmpView")
    val sql=s"insert overwrite table dm_gis.dim_db_table_info partition(db_name='$databaseName') " +
      s"select * from tmpView"
    logger.error(sql)
    sparkSession.sql(sql)
  }
}
