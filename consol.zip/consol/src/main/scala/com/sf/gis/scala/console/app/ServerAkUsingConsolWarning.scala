package com.sf.gis.scala.console.app

import java.util.Date

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import com.sf.gis.scala.console.app.ServerAkUsingConsolTotalSta.rejectAkSql
import com.sf.gis.scala.console.app.common.FsManager
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2024-01-02 14:34
 * @TaskId:957807
 * @TaskName:服务ak监控
 * @Description:
 */
object ServerAkUsingConsolWarning {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)

  def queryAccumulateDataCnt(sparkSession: SparkSession, incDay: String, lastDay: String, lastWeekDay: String, dataType: String, startHour: String, endHour: String) = {
    //获取三天的小时段累计数据量
    var sql = s"select sum(cnt),inc_day from ${ServerAkUsingConsol.retTableName} where inc_day in " +
      s"('${incDay}','${lastDay}','${lastWeekDay}' ) and data_type='${dataType}' and hour <= '${endHour}' "
    val akSql = rejectAkSql(dataType)
    sql = sql + akSql + "  group by inc_day  "

    logger.error(sql)
    val dataMap = sparkSession.sql(sql).rdd.map(obj => {
      (obj.getString(1), obj.getLong(0))
    }).collectAsMap()

    //提取三天的数据量
    val todayCnt = dataMap.apply(incDay)
    val lastdayCnt = dataMap.apply(lastDay)
    val lastWeekCnt = dataMap.apply(lastWeekDay)
    logger.error(todayCnt, lastdayCnt, lastWeekCnt)
    (todayCnt, lastdayCnt, lastWeekCnt)
  }

  def queryHourDataCnt(sparkSession: SparkSession, sparkSession1: SparkSession, incDay: String, lastDay: String, lastWeekDay: String, dataType: String, startHour: String, endHour: String) = {
    //获取三天的小时段累计数据量
    var sql = s"select sum(cnt),inc_day,hour from ${ServerAkUsingConsol.retTableName} where inc_day in " +
      s"('${incDay}','${lastDay}','${lastWeekDay}' ) and data_type='${dataType}' and hour between '${startHour}' and '${endHour}' "
    val akSql = rejectAkSql(dataType)
    sql = sql + akSql + "  group by inc_day,hour "
    logger.error(sql)
    val dataMap = sparkSession.sql(sql).rdd.map(obj => {
      (obj.getString(1) + "_" + obj.getString(2), obj.getLong(0))
    }).collectAsMap()
    //提取三天的数据量
    val todayStartHourCnt = dataMap.apply(incDay + "_" + startHour)
    val lastDayStartHourCnt = dataMap.apply(lastDay + "_" + startHour)
    val lastWeekStartHourCnt = dataMap.apply(lastWeekDay + "_" + startHour)
    val todayEndHourCnt = dataMap.apply(incDay + "_" + endHour)
    val lastDayEndHourCnt = dataMap.apply(lastDay + "_" + endHour)
    val lastWeekEndHourCnt = dataMap.apply(lastWeekDay + "_" + endHour)
    logger.error(todayStartHourCnt, lastDayStartHourCnt, lastWeekStartHourCnt,
      todayEndHourCnt, lastDayEndHourCnt, lastWeekEndHourCnt)

    (todayStartHourCnt, lastDayStartHourCnt, lastWeekStartHourCnt,
      todayEndHourCnt, lastDayEndHourCnt, lastWeekEndHourCnt
    )
  }

  def checkWarningRule(todayCnt: Long, lastdayCnt: Long, lastWeekCnt: Long,
                       lastDayMax: Int, lastWeekMax: Int) = {
    //比较昨日
    var sendMsg = true;
    val compareToday = ((todayCnt - lastdayCnt) * 1.0 / lastdayCnt * 100);
    if (Math.abs(compareToday) >= lastDayMax) {
    } else {
      sendMsg = false
    }
    val compareWeekDay = (todayCnt - lastWeekCnt) * 1.0 / lastWeekCnt * 100;
    if (Math.abs(compareWeekDay) >= lastWeekMax) {
    } else {
      sendMsg = false
    }
    sendMsg
  }

  def checkNeedWarning(todayCnt: Long, lastdayCnt: Long, lastWeekCnt: Long,
                       todayStartHourCnt: Long, lastDayStartHourCnt: Long, lastWeekStartHourCnt: Long,
                       todayEndHourCnt: Long, lastDayEndHourCnt: Long, lastWeekEndHourCnt: Long,
                       lastDayMax: Int, lastWeekMax: Int,
                       lastDayHourMax: Int, lastWeekHourMax: Int) = {
    logger.error("比较累计量预警值")
    val accumulateSendMsg = checkWarningRule(todayCnt, lastdayCnt, lastWeekCnt,
      lastDayMax, lastWeekMax)
    logger.error("累计量是否预警：" + accumulateSendMsg)

    logger.error("比较起始时间预警值")
    val startHourSendMsg = checkWarningRule(todayStartHourCnt, lastDayStartHourCnt, lastWeekStartHourCnt,
      lastDayHourMax, lastWeekHourMax)
    logger.error("起始小时量是否预警：" + startHourSendMsg)

    logger.error("比较截止时间预警值")
    val endHourSendMsg = checkWarningRule(todayEndHourCnt, lastDayEndHourCnt, lastWeekEndHourCnt,
      lastDayHourMax, lastWeekHourMax)
    logger.error("截止小时量是否预警：" + endHourSendMsg)

    (accumulateSendMsg, startHourSendMsg, endHourSendMsg)
  }

  def createMessageDetail(msgArray:ArrayBuffer[String],todayCnt: Long, lastdayCnt: Long, lastWeekCnt: Long, lastDayMax: Int, lastWeekMax: Int,
                          dayWeek: String, lastDayWeek: String,
                          incDay:String,endHour:String) ={
    val first = ServerAkUsingConsolTotalSta.converDayToChinese(incDay)+"("+dayWeek+")"+" "+endHour+":59 "
    val second = "累计调用量为："+todayCnt
    msgArray.append(first)
    msgArray.append(second)

    val compareToday = ((todayCnt - lastdayCnt) * 1.0 / lastdayCnt * 100);
    val todayCompareDesc = createDesc(compareToday)
    if (Math.abs(compareToday) > lastDayMax) {
      msgArray.append("1、相较于昨日" + todayCompareDesc + Math.abs(todayCnt - lastdayCnt) + "，波动范围超过" + lastDayMax + "%，烦请关注 ！！！")
    } else {
      msgArray.append("2、相较于昨日" + todayCompareDesc + Math.abs(todayCnt - lastdayCnt) + "，波动范围为" + Math.abs(compareToday).formatted("%.1f") + "%.")
    }
    val compareWeekDay = (todayCnt - lastWeekCnt) * 1.0 / lastWeekCnt * 100;
    val weekCompareDesc = createDesc(compareWeekDay)
    if (Math.abs(compareWeekDay) > lastWeekMax) {
      msgArray.append("1、相较于上" + dayWeek + weekCompareDesc + Math.abs(todayCnt - lastWeekCnt) + "，波动范围超过" + lastWeekMax + "%,烦请关注 ！！！")
    } else {
      msgArray.append("2、相较于上" + dayWeek + weekCompareDesc + Math.abs(todayCnt - lastWeekCnt) + "，波动范围为" + Math.abs(compareWeekDay).formatted("%.1f") + "%.")
    }
  }

  def createMessageDetailHour(msgArray:ArrayBuffer[String],todayStartHourCnt: Long, lastDayStartHourCnt: Long,
                              lastWeekStartHourCnt: Long,
                              lastDayHourMax: Int, lastWeekHourMax: Int,
                              dayWeek: String, lastDayWeek: String,hour:String,
                              incDay:String) = {
    msgArray.append(" ")
    msgArray.append(" ")
//    val first = ServerAkUsingConsolTotalSta.converDayToChinese(incDay)+"("+dayWeek+")"+" "+hour+":00-"+hour+":59"
    val second = "分时段("+hour+":00-"+hour+":59"+")调用量为："+todayStartHourCnt
//    msgArray.append(first)
    msgArray.append(second)

    val compareTodayCnt = todayStartHourCnt - lastDayStartHourCnt
    val compareToday = (compareTodayCnt * 1.0 / lastDayStartHourCnt * 100);
    val todayCompareDesc = createDesc(compareToday)
    if (Math.abs(compareToday) > lastDayHourMax) {
      msgArray.append("1、相较于昨日" + todayCompareDesc + Math.abs(compareTodayCnt) + "，波动范围超过" + lastDayHourMax + "%，烦请关注 ！！！")
    } else {
      msgArray.append("1、相较于昨日" + todayCompareDesc + Math.abs(compareTodayCnt) + "，波动范围为" + Math.abs(compareToday).formatted("%.1f") + "%.")
    }
    val compareWeebkDayCnt = todayStartHourCnt - lastWeekStartHourCnt
    val compareWeekDay = compareWeebkDayCnt * 1.0 / lastWeekStartHourCnt * 100;
    val weekCompareDesc = createDesc(compareWeekDay)
    if (Math.abs(compareWeekDay) > lastWeekHourMax) {
      msgArray.append("2、相较于上" + dayWeek + weekCompareDesc + Math.abs(compareWeebkDayCnt) + "，波动范围超过" + lastWeekHourMax + "%,烦请关注 ！！！")
    } else {
      msgArray.append("2、相较于上" + dayWeek + weekCompareDesc + Math.abs(compareWeebkDayCnt) + "，波动范围为" + Math.abs(compareWeekDay).formatted("%.1f") + "%.")
    }
    msgArray
  }

  def createMessage(accumulateSendMsg: Boolean, startHourSendMsg: Boolean, endHourSendMsg: Boolean,
                    todayCnt: Long, lastdayCnt: Long, lastWeekCnt: Long,
                    todayStartHourCnt: Long, lastDayStartHourCnt: Long, lastWeekStartHourCnt: Long,
                    todayEndHourCnt: Long, lastDayEndHourCnt: Long, lastWeekEndHourCnt: Long,
                    lastDayMax: Int, lastWeekMax: Int,
                    lastDayHourMax: Int, lastWeekHourMax: Int,
                    incDay:String, lastDay:String, lastWeekDay:String, dataType:String,
                    startHour:String, endHour:String
                   ) = {
    val dayWeek = DateUtil.getWeekOfDateChinese(incDay)
    val lastDayWeek = DateUtil.getWeekOfDateChinese(lastDay)
    val messageArray = new ArrayBuffer[String]()

    createMessageDetail(messageArray,todayCnt, lastdayCnt, lastWeekCnt,
      lastDayMax, lastWeekMax,dayWeek,lastDayWeek,incDay,endHour)
    if (startHourSendMsg) {
        createMessageDetailHour(messageArray,todayStartHourCnt, lastDayStartHourCnt,
        lastWeekStartHourCnt,
        lastDayHourMax, lastWeekHourMax,dayWeek,lastDayWeek,startHour,incDay)
    }
    if (endHourSendMsg) {
        createMessageDetailHour(messageArray,todayEndHourCnt, lastDayEndHourCnt,
        lastWeekEndHourCnt,
        lastDayHourMax, lastWeekHourMax,dayWeek,lastDayWeek,endHour,incDay)
    }
    messageArray
  }

  def startSta(sparkSession: SparkSession, incDay: String, startHour: String,
               endHour: String, dataType: String,
               lastDayMax: Int, lastWeekMax: Int,
               lastDayHourMax: Int, lastWeekHourMax: Int): Unit = {
    //获取昨天和7天前数据
    val lastDay = DateUtil.getDay(incDay, -1, "")
    val lastWeekDay = DateUtil.getDay(incDay, -7, "")
    //获取对应 星期描述
    val dayWeek = DateUtil.getWeekOfDateChinese(incDay)
    val lastDayWeek = DateUtil.getWeekOfDateChinese(lastDay)
    logger.error("计算累计量")
    val (todayCnt, lastdayCnt, lastWeekCnt) = queryAccumulateDataCnt(sparkSession, incDay, lastDay, lastWeekDay, dataType, startHour, endHour)
    logger.error("获取小时量")
    val (todayStartHourCnt, lastDayStartHourCnt, lastWeekStartHourCnt,
    todayEndHourCnt, lastDayEndHourCnt, lastWeekEndHourCnt
      ) = queryHourDataCnt(sparkSession, sparkSession, incDay, lastDay, lastWeekDay, dataType, startHour, endHour)
    logger.error("开始检测是否需要告警")
    val (accumulateSendMsg, startHourSendMsg, endHourSendMsg) = checkNeedWarning(todayCnt, lastdayCnt, lastWeekCnt, todayStartHourCnt, lastDayStartHourCnt, lastWeekStartHourCnt,
      todayEndHourCnt, lastDayEndHourCnt, lastWeekEndHourCnt, lastDayMax, lastWeekMax, lastDayHourMax, lastWeekHourMax)

    if ((accumulateSendMsg || startHourSendMsg || endHourSendMsg)
      && endHour.toInt >= 9 && endHour.toInt < 22) {
      val msgArray = createMessage(accumulateSendMsg, startHourSendMsg, endHourSendMsg, todayCnt, lastdayCnt, lastWeekCnt, todayStartHourCnt, lastDayStartHourCnt, lastWeekStartHourCnt,
        todayEndHourCnt, lastDayEndHourCnt, lastWeekEndHourCnt, lastDayMax, lastWeekMax, lastDayHourMax, lastWeekHourMax,
        incDay, lastDay, lastWeekDay, dataType, startHour, endHour
      )
      //构造消息体
      val retArray = new JSONArray();


      for (i <- 0 until msgArray.length) {
        val tmpJobj = new JSONObject();
        tmpJobj.put("key", " ")
        tmpJobj.put("value", msgArray(i) + " ")
        retArray.add(tmpJobj)
      }
      logger.error("retArray:"+retArray.toJSONString)
      sendFsMsg(retArray.toJSONString, convertFsFlag(dataType))
    } else {
      logger.error("无需告警")
    }
  }


  def createDesc(compareData: Double) = {
    var descStr = "增加"
    if (compareData < 0) {
      descStr = "减少"
    }
    descStr
  }

  def convertFsFlag(dataType: String) = {
    dataType + "_ak_fluctuate"
  }

  def sendFsMsg(content: String, fsFlag: String): Unit = {
    try {
      //丰声告警相关信息
      val fsManager = new FsManager(fsFlag)
      val token = fsManager.queryToken
      System.out.println("token:" + token)
      val time = (new Date).getTime
      fsManager.send(content, token, time, null)
    } catch {
      case e: Exception => logger.error(e)
    }
  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0).replaceAll("-", "")
    val startHour = args(1)
    val endHour = args(2)
    val dataType = args(3)
    var lastDayMax = 10
    if (args.length > 4) {
      lastDayMax = args(4).toInt
    }
    var lastWeekMax = 10
    if (args.length > 5) {
      lastWeekMax = args(5).toInt
    }

    var lastDayHourMax = 50
    if (args.length > 6) {
      lastDayHourMax = args(6).toInt
    }

    var lastWeekHourMax = 50
    if (args.length > 7) {
      lastWeekHourMax = args(7).toInt
    }

    logger.error(incDay, startHour, endHour, dataType)
    val sparkSession = Spark.getSparkSession(appName)
    startSta(sparkSession, incDay, startHour, endHour, dataType, lastDayMax, lastWeekMax, lastDayHourMax, lastWeekHourMax)
  }
}
