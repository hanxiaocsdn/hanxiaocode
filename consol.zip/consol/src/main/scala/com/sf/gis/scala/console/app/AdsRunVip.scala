package com.sf.gis.scala.console.app

import java.net.URLEncoder
import java.sql.DriverManager
import java.util.Date

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil}
import com.sf.gis.scala.console.app.common.FsManager
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-09-12 20:00
 * @TaskId:912234
 * @TaskName:地址详细-vip-地址定时测试
 * @Description: ads服务跑大客户地址，结果存入运维监控mysql，防止大客户的地址问题
 */
object AdsRunVip {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //ar的ip
  val url = "http://gis-int.int.sfdc.com.cn:1080/iad/api?ak=e6d2bea8c2e64c5b8b37718eb8ce81cf&address=%s&opt=detail&showserver=true"


  def loadVipAddress(sparkSession: SparkSession, addressPath: String, sourceFromDb: Boolean, isTest: Boolean) = {
//    if (sourceFromDb) {
      loadVipAddressFromFileDb(sparkSession, isTest)
//    } else {
//      System.exit(0)
//      loadVipAddressFromFile(sparkSession, addressPath)
//    }
  }

  def loadVipAddressFromFileDb(sparkSession: SparkSession, isTest: Boolean) = {

    var url: String = "jdbc:mysql://gismonitor-m.db.sfcloud.local:3306/gismonitor?useSSL=false&useUnicode=true&characterEncoding=utf-8"
    var username: String = "gismonitor"
    var password: String = "Gismonitor$3421"
    println("com.mysql.cj.jdbc.Driver")
    Class.forName("com.mysql.cj.jdbc.Driver");
    if (isTest) {
      url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useSSL=false&useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
      username = "gis_oms_rds"
      password = "gis_oms_rds@123@"
    }
    logger.error("url:" + url)
    var dataList = Array[(String, String, String)]()
    //      new java.util.ArrayList[JSONObject]()
    val conn = DriverManager.getConnection(url, username, password)
    val stmt = conn.createStatement
    val rs1 = stmt.executeQuery(s"select id,address,normresult from ads_vip_address_console")
    while (rs1.next()) {
      dataList = (convertEmpty(rs1.getString(1)),
        convertEmpty(rs1.getString(2)),
        convertEmpty(rs1.getString(3))) +: dataList
    }
    conn.close()
    logger.error("装载ads vip地址总数量:" + dataList.size)
    dataList.take(10).foreach(obj => {
      logger.error(obj.toString())
    })
    dataList
  }



  def convertEmpty(str: String): String = {
    if (str == null) {
      return ""
    }
    return str
  }


  def runInteface(dataList: Array[(String, String, String)], isTest: Boolean) = {

    var count = 0;
    val runRet = dataList.map(obj => {
      val tmpUrl = String.format(url, URLEncoder.encode(obj._2, "utf-8").replaceAll("\\+","%20"))
      count = count + 1
      if (count % 500 == 0) {
        logger.error("已跑条数:" + count)
      }
      var cnt = 0
      var retJson: JSONObject = null;
      while (cnt < 3) {
        try {
          retJson = HttpUtils.urlConnectionGetJson(tmpUrl, 2 * 1000)
          cnt = 3
        } catch {
          case e: Exception => {
            logger.error(e)
            Thread.sleep(3000)
            cnt = cnt + 1
            if (cnt >= 3) {
              throw e
            }
          }
        }
      }
      if (retJson != null) {
        if (count == 1) {
          logger.error(retJson.toString())
        }
        val result = JSONUtil.getJsonVal(retJson,"result.data.multi","")
        if (result.isEmpty) {
          logger.error("返回为空：" + obj._2 + "----" + retJson)
        } else if (!result.equals(obj._3)) {
          logger.error("数据不相等：" + obj._2 + "," + obj._3 + "----" + retJson)
        }
        (obj._1, obj._2, obj._3, result)
      } else {
        logger.error("返回为空：" + obj._2)
        (obj._1, obj._2, obj._3, null)
      }
    }).filter(obj => obj._4 != null).map(obj => (obj._1, obj._2, obj._3, obj._4))
    logger.error("运行后不为空的结果数：" + runRet.size)
    runRet.take(2).foreach(obj => {
      logger.error(obj)
    })
    runRet
  }

  def main(args: Array[String]): Unit = {
    ///user/01374443/upload/ar
    val addressPath = args(0)
    //是否测试模式，会传到测试库
    var isTest = false
    if ("test".equals(args(1))) {
      isTest = true
    }
    //是否初始化，初始化，将以跑出的数据为准，更新全部数据
    var isInit = false
    if ("init".equals(args(2))) {
      ///Ars目前无用不做批量修改
      isInit = true
    }
    //标杆数据来源是否是数据库，或者文件
    var sourceFromDb = true
    if ("file".equals(args(3))) {
      sourceFromDb = false
    }
    val sparkSession = Spark.getSparkSession(appName, null, true, 1)
    logger.error("装载数据：" + addressPath)
    var dataList = loadVipAddress(sparkSession, addressPath, sourceFromDb, isTest)
    logger.error("开始跑接口")
    val invokeId=BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01374443","817316","地址详细-vip-地址定时测试","大客户测试ads服务",url,"e6d2bea8c2e64c5b8b37718eb8ce81cf",dataList.length,1)
    val runInterfaceRet = runInteface(dataList, isTest)
    BdpTaskRecordUtil.endNetworkInterface("01374443",invokeId)
    logger.error("写表")
    insertIntoDisMysql(runInterfaceRet, isTest)

    logger.error("发告警")
    sendFsMsg(runInterfaceRet)

    val maxEmpty = 0
    if (runInterfaceRet.size < (dataList.size - maxEmpty)) {
      logger.error(s"*************为空数据超过${maxEmpty}条，请注意*************")
      System.exit(-1)
    }
    logger.error("完成")
  }

  def sendFsMsg(runInterfaceRet: Array[(String, String, String, String)]) = {
    try {
      //丰声告警相关信息
      val fsManager = new FsManager("ads")
      val token = fsManager.queryToken
      System.out.println("token:" + token)
      val time = (new Date).getTime
      runInterfaceRet.filter(obj => {
        if (!obj._3.equals(obj._4)) {
          true
        }else{
          false
        }
      }).foreach(obj=>{
        val content = convertWarninggContent(obj._1,obj._2,obj._3,obj._4)
        fsManager.send(content.toJSONString, token, time,null)
      })
    } catch {
      case e: Exception => logger.error(e)
    }
  }
  def convertWarninggContent(id:String,address:String,result:String,r_result:String ): JSONArray = {
    val item = new JSONObject()
    item.put("id", id)
    item.put("address", address)
    item.put("result", result+"")
    item.put("r_result", r_result+"")

    val keys = Array("id", "地址", "原result", "现result")
    val mapKeys = Array("id", "address", "result", "r_result")
    val retArray = new JSONArray();
    for (i <- 0 until keys.length) {
      val tmpJobj = new JSONObject();
      tmpJobj.put("key", keys(i))
      tmpJobj.put("value", item.getString(mapKeys(i))+" ")
      retArray.add(tmpJobj)
    }
    return retArray
  }

  def insertIntoDisMysql(runRet: Array[(String, String, String, String)], isTest: Boolean) = {
    var url: String = "jdbc:mysql://gismonitor-m.db.sfcloud.local:3306/gismonitor?useSSL=false&useUnicode=true&characterEncoding=utf-8"
    var username: String = "gismonitor"
    var password: String = "Gismonitor$3421"
    println("com.mysql.cj.jdbc.Driver")
    Class.forName("com.mysql.cj.jdbc.Driver");
    if (isTest) {
      url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useSSL=false&useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
      username = "gis_oms_rds"
      password = "gis_oms_rds@123@"
      //      Class.forName("com.mysql.jdbc.Driver")
    }
    logger.error("url:" + url)
    //    else{
    //      Class.forName("com.mysql.cj.jdbc.Driver")
    //    }

    val conn = DriverManager.getConnection(url, username, password)
    val modifyTime = DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss");
    var count = 0
    runRet.foreach(obj => {
      count = count + 1
      if (count % 500 == 0) {
        logger.error("count:" + count)
      }
      val sql = s"insert into  `ads_vip_address_console`(`id`,`address`,`normresult`,`result`,`MODIFY_TIME`) " +
        s"values('${obj._1}','${obj._2.replace("'", "’")}','${obj._3}','${obj._4}','${modifyTime}')" +
        s"  ON DUPLICATE KEY update result='${obj._4}',MODIFY_TIME='${modifyTime}' "
      //      try{
      val ps = conn.prepareStatement(sql)
      ps.executeUpdate()
      //      }catch {
      //        case e:Exception=> logger.error(obj._2)
      //      }

    })
    val stmt = conn.createStatement
    val rs = stmt.executeQuery("select count(1) from ads_vip_address_console")
    while (rs.next()) {
      logger.error("表里面总数" + rs.getLong(1));
    }
    val rs1 = stmt.executeQuery("select * from ads_vip_address_console limit 1")
    while (rs1.next()) {
      logger.error(rs1.getString(1));
      logger.error(rs1.getString(2));
      logger.error(rs1.getString(3));
      logger.error(rs1.getString(4));
    }
    conn.close()
  }
}