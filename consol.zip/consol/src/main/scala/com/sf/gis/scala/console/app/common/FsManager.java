
package com.sf.gis.scala.console.app.common;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.base.util.FileUtil;
import com.sf.gis.scala.base.util.StringUtils;
import com.sf.gis.scala.console.app.AtpaiRunVip;
import com.sf.gis.scala.console.utils.FsUtils;
import org.jboss.netty.util.internal.StringUtil;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:
 * @TaskName:
 * @Description:发丰声工具类
 */
public class FsManager {
    private Properties prop;
    private String tokenUrl;
    private String sendUrl;
    private String clientId;
    private String clientSecret;
    private String templateCode;
    private String grantType="client_credentials";
    private JSONArray receviersList;
    private JSONArray groupIdArray;
    private String title;
    private String jumpPcUrl;
    public  FsManager(){

    }
    public FsManager(String type) {
        prop = FileUtil.getFilePropertieRes("conf/fs_msg_cfg.properties");
        tokenUrl = prop.getProperty("fs.token.url");
        sendUrl = prop.getProperty("fs.send.url");
        clientId = prop.getProperty("fs.client.id");
        clientSecret = prop.getProperty("fs.client.secret");
        //默认的模板，如果有其他模板，则使用传入的模板code
        templateCode= prop.getProperty("fs.template.code");
        receviersList = JSON.parseArray(getProperty(type+".notice.account"));
        System.out.println("receviersList:"+receviersList.toJSONString());
        groupIdArray = JSON.parseArray(getProperty(type+".notice.group"));
        System.out.println("receviersList:"+groupIdArray.toJSONString());
        title = getProperty(type+".notice.title");
        jumpPcUrl = getProperty(type+".notice.jump.url.pc");
    }
    public String getProperty(String key) {
        return prop.getProperty(key);
    }

    /**
     * msg send
     *
     * @param receviersList the receiver list
     * @param title         the title
     * @param content       the content
     * @param showType      the showType
     * @return the send result
     */
    public Map<String, Object> send(String content,
                                    String token, long sendTime,String intputTemplateCode) {
        //默认的模板，如果有其他模板，则使用传入的模板code
        String templateCode = StringUtils.isBlank(intputTemplateCode)?this.templateCode:intputTemplateCode;
        JSONObject parm = new JSONObject();
        parm.put("sendTime", sendTime);
        parm.put("templateCode", templateCode);
        if ("1102".equals(templateCode)) {
            JSONObject body = new JSONObject();
            body.put("toNums", receviersList);
            if (groupIdArray != null && !groupIdArray.isEmpty()) {
                body.put("toGroupIds", groupIdArray);
            }
            body.put("range", "APPOINT");
            body.put("message", title + ":" + content);
            parm.put("body", body);
        } else if ("1203".equals(templateCode)) {
            JSONObject body = new JSONObject();
            body.put("toNums", receviersList);
            if (groupIdArray != null && !groupIdArray.isEmpty()) {
                body.put("toGroupIds", groupIdArray);
            }
            body.put("range", "APPOINT");
            body.put("title", title);


            //正文展示栏， content为key value数组，表示一条数据
            JSONObject contentBody = new JSONObject();
            contentBody.put("list", JSON.parseArray(content));
            body.put("content", contentBody);

            //跳转栏
            JSONObject jumpParms = createJumpParms(jumpPcUrl);
            if (jumpParms != null) {
                body.put("jumpParams", jumpParms);
            }

            //push content 通知栏
            JSONObject pushContent = new JSONObject();
            pushContent.put("title", title);
            pushContent.put("body", title);
            body.put("pushContent", pushContent);

            parm.put("body", body);
        }
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("Authorization", "Bearer " + token);
        System.out.println(parm.toJSONString());
        System.out.println("sendUrl:"+sendUrl);
        return FsUtils.sendMsg(sendUrl, parm, headerMap);
    }

    public JSONObject createJumpParms(String jumpPcUrl) {
        JSONObject jumpParms = new JSONObject();
        if (!StringUtils.isBlank(jumpPcUrl)) {
            JSONObject pc = new JSONObject();
            pc.put("businessKey", "microservice");
            pc.put("action", "openNormalUrl");
            JSONObject data = new JSONObject();
            data.put("extraUrl", jumpPcUrl);
            pc.put("data", data);
            jumpParms.put("pc", pc);
        }
        if (jumpParms.isEmpty()) {
            return null;
        }
        return jumpParms;
    }

    /**
     * 获取token
     */
    public String queryToken() {
        Map<String, String> parm = new HashMap<>();
        parm.put("client_id", clientId);
        parm.put("client_secret", clientSecret);
        parm.put("grant_type", grantType);
        return FsUtils.queryToken(tokenUrl, parm);
    }



    public static void main(String[] args) {
        //atpai
        FsManager fsManager = new FsManager("atpai");
        String token = fsManager.queryToken();
        System.out.println("token:"+token);

        JSONArray receviersList = new JSONArray();
        receviersList.add(fsManager.getProperty("atpai.notice.account"));
        JSONArray groupArray = new JSONArray();
        groupArray.add(fsManager.getProperty("atpai.notice.group"));
        String title="atpai大客户地址告警";
        JSONObject tmpJson = new JSONObject();
        tmpJson.put("citycode","755");
        tmpJson.put("address","我是地址");
        tmpJson.put("company","我是公司");
        tmpJson.put("contact","我是联系人");
        tmpJson.put("tel","我是电话");
        tmpJson.put("mobile","我是手机");
        tmpJson.put("dept","我是原网点");
//        tmpJson.put("r_dept","我是新网点");
        tmpJson.put("aoi","我是原aoi");
//        tmpJson.put("r_aoi","我是新aoi");
        tmpJson.put("gid","我是原gid");
        tmpJson.put("r_gid","我是新gid");
        tmpJson.put("src","我是原src");
        tmpJson.put("r_src","我是新src");
        JSONArray content = AtpaiRunVip.convertWarninggContent(tmpJson,"我是新网点","我是新aoi");
        String jumperPcUrl = fsManager.getProperty("atpai.notice.jump.url.pc");
        fsManager.send(content.toJSONString(),token,(new Date()).getTime(),null);
    }
}
