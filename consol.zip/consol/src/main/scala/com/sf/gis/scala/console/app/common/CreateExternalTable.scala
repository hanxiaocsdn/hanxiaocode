package com.sf.gis.scala.console.app.common

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger

/**
 * @ProductManager:01374443
 * @Author: 01374443
 * @CreateTime: 2023-10-08
 * @TaskId:临时任务
 * @TaskName:临时任务
 * @Description:用于spark代码创建外部创建外部表，链接无权限集群
 */
object CreateExternalTable {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val sql = args(0)
    logger.error("args(0):" + args(0))
    val sparkSession = Spark.getSparkSession(className)
    logger.error(sql)
    sparkSession.sql(sql)

  }
}
