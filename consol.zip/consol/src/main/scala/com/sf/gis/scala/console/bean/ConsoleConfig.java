package com.sf.gis.scala.console.bean;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.base.util.FileUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class ConsoleConfig {
    //小文件阈值 单位Byte
    public final long smallFileMaxSize;

    //集群和库的路径映射关系
    public final Map<String,String[]> clusterMap;
    //集群和hdfs前缀影射关系
    public final Map<String,String> clusterPreMap;
    //库列表
    public final String[] databaseArray;
    //配置信息
    public final Properties prop;
    public ConsoleConfig(String configFile) {
        this.prop = FileUtil.getFilePropertieRes(configFile);
        this.smallFileMaxSize = Long.valueOf(prop.getProperty("small_file_avg_size"));
        this.databaseArray = prop.getProperty("database").split(";");
        JSONObject clusterConfigJson = JSON.parseObject(prop.getProperty("hdfs_cluster_map"));
        this.clusterMap = new HashMap<>();
        for(String key:clusterConfigJson.keySet()){
            String[] hdfsPath = clusterConfigJson.getString(key).split(";");
            clusterMap.put(key,hdfsPath);
        }
        clusterPreMap = JSON.parseObject(prop.getProperty("hdfs_cluster_hdfs"),HashMap.class);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("clusterMap:");
        for(Object key : prop.keySet()){
            sb.append(key.toString()+"->"+prop.getProperty(key.toString())).append(";");
        }
        sb.deleteCharAt(sb.length()-1);
        return sb.toString();
    }
}
