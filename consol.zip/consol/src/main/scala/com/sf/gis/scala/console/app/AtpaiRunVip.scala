package com.sf.gis.scala.console.app

import java.net.URLEncoder
import java.sql.DriverManager
import java.util.Date

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, MD5Util}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.gis.scala.console.app.common.FsManager
import org.apache.log4j.Logger
import org.apache.spark.sql.{SaveMode, SparkSession}

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-09-12 20:00
 * @TaskId:825154
 * @TaskName:atpai-vip-地址定时测试
 * @Description: atpai服务跑大客户地址，结果存入运维监控mysql，防止大客户的地址问题
 */
object AtpaiRunVip {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //ar的ip
  val url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=e6d2bea8c2e64c5b8b37718eb8ce81cf&opt=zh&city=%s&address=%s&tel=%s&mobile=%s&company=%s&contact=%s&showserver=true"


  def loadVipAddress(sparkSession: SparkSession, addressPath: String, sourceFromDb: Boolean, isTest: Boolean) = {
    if (sourceFromDb) {
      loadVipAddressFromFileDb(sparkSession, isTest)
    } else {
      loadVipAddressFromFile(sparkSession, addressPath)
    }
  }

  def loadVipAddressFromFileDb(sparkSession: SparkSession, isTest: Boolean) = {

    var url: String = "jdbc:mysql://gismonitor-m.db.sfcloud.local:3306/gismonitor?useSSL=false&useUnicode=true&characterEncoding=utf-8"
    var username: String = "gismonitor"
    var password: String = "Gismonitor$3421"
    println("com.mysql.cj.jdbc.Driver")
    Class.forName("com.mysql.cj.jdbc.Driver");
    if (isTest) {
      url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useSSL=false&useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
      username = "gis_oms_rds"
      password = "gis_oms_rds@123@"
    }
    logger.error("url:" + url)
    var dataList = Array[JSONObject]()
    //      new java.util.ArrayList[JSONObject]()
    val conn = DriverManager.getConnection(url, username, password)
    val stmt = conn.createStatement
    val rs1 = stmt.executeQuery(s"select id,address,citycode,tel,mobile,company,contact,normdept,normaoiid,normsrc,normgid from atpai_vip_addres_console")
    while (rs1.next()) {
      val json = new JSONObject()
      json.put("id", convertEmpty(rs1.getString(1)))
      json.put("address", convertEmpty(rs1.getString(2)))
      json.put("citycode", convertEmpty(rs1.getString(3)))
      json.put("tel", convertEmpty(rs1.getString(4)))
      json.put("mobile", convertEmpty(rs1.getString(5)))
      json.put("company", convertEmpty(rs1.getString(6)))
      json.put("contact", convertEmpty(rs1.getString(7)))
      json.put("dept", convertEmpty(rs1.getString(8)))
      json.put("aoiid", convertEmpty(rs1.getString(9)))
      json.put("src", convertEmpty(rs1.getString(10)))
      json.put("gid", convertEmpty(rs1.getString(11)))
      dataList = json +: dataList
    }
    conn.close()
    logger.error("装载atpai vip地址总数量:" + dataList.size)
    dataList.take(10).foreach(obj => {
      logger.error(obj.toJSONString())
    })
    dataList
  }

  def loadVipAddressFromFile(sparkSession: SparkSession, addressPath: String) = {
    val dataList = sparkSession.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      //不要开启自动探测，不然可能会转int，long
      //      .option("inferSchema", "true")
      .csv(addressPath)
      //citycode,address,tel,mobile,company,contact,src,dept,aoiid
      //      .csv("hdfs://sfbdp1/user/01374443/upload/ar/ar_town_01425247.csv")
      .toDF("citycode", "address", "tel", "mobile", "company",
        "contact", "src", "dept", "aoiid", "gid").rdd
      .map(obj => {
        val json = new JSONObject()
        json.put("citycode", convertEmpty(obj.getString(0)))
        json.put("address", convertEmpty(obj.getString(1)))
        json.put("tel", convertEmpty(obj.getString(2)))
        json.put("mobile", convertEmpty(obj.getString(3)))
        json.put("company", convertEmpty(obj.getString(4)))
        json.put("contact", convertEmpty(obj.getString(5)))
        json.put("src", convertEmpty(obj.getString(6)))
        json.put("dept", convertEmpty(obj.getString(7)))
        json.put("aoiid", convertEmpty(obj.getString(8)))
        json.put("gid", convertEmpty(obj.getString(9)))
        val addrsssMd5 = MD5Util.getMD5(json.getString("address").replace("'", "’") + "_" + json.getString("citycode") +
          "_" + json.getString("tel") + "_" + json.getString("mobile") + "_" + json.getString("company")
          + "_" + json.getString("contact"))
        json.put("id", addrsssMd5)
        json
      }
      ).collect()
    logger.error("装载atpai vip地址总数量:" + dataList.size)
    dataList.take(10).foreach(obj => {
      logger.error(obj.toJSONString())
    })
    dataList
  }

  def convertEmpty(str: String): String = {
    if (str == null) {
      return ""
    }
    return str
  }

  def updateLatestData(sparkSession: SparkSession, runRet: Array[(JSONObject, String, String)],
                       addressPath: String, isInit: Boolean, isTest: Boolean) = {
    var savePath = addressPath
    if (isTest) {
      savePath = addressPath + "_test"
    }
    val convertRet = runRet.map(obj => {
      var needUpdate = false
      if (isInit) {
        obj._1.put("dept", obj._2)
        obj._1.put("aoiid", obj._3)
        obj._1.put("src", obj._1.getString("r_src"))
        obj._1.put("gid", obj._1.getString("r_gid"))
        needUpdate = true
      }
      if (!obj._1.getString("dept").equals(obj._2) && !obj._1.getString("aoiid").isEmpty && obj._1.getString("aoiid").equals(obj._3)) {
        needUpdate = true
        obj._1.put("dept_old", obj._1.getString("dept"))
        obj._1.put("src_old", obj._1.getString("src"))
        obj._1.put("gid_old", obj._1.getString("gid"))
        obj._1.put("dept", obj._2)
        obj._1.put("src", obj._1.getString("r_src"))
        obj._1.put("gid", obj._1.getString("r_gid"))
      }

      if(obj._1.getString("dept").equals(obj._2) && !obj._1.getString("aoiid").equals(obj._3) ){
        obj._1.put("aoiid",obj._3)
      }

      obj._1.put("needUpdate", needUpdate)
      obj
    })
    val updateRet = convertRet.filter(obj => obj._1.getBooleanValue("needUpdate"))
    if (updateRet.size != 0) {
      if (!isInit) {
        logger.error("打印网点变更aoi没变更的数据")
        println("citycode", "address", "dept_old", "dept_new", "aoiid", "company")
        updateRet.foreach(obj => {
          println(obj._1.getString("citycode"), obj._1.getString("address"), obj._1.getString("dept_old"),
            obj._1.getString("dept"), obj._1.getString("aoiid"), obj._1.getString("company")
          )
        })
      }

      logger.error("开始刷新hdfs原始文件,mysql的数据到后面统一更新")
      import sparkSession.implicits._
      sparkSession.sparkContext.parallelize(convertRet).map(obj => {
        (obj._1.getString("citycode"), obj._1.getString("address"), obj._1.getString("tel"),
          obj._1.getString("mobile"), obj._1.getString("company"), obj._1.getString("contact"),
          obj._1.getString("src"), obj._1.getString("dept"), obj._1.getString("aoiid"),
          obj._1.getString("gid")
        )
      }).coalesce(1).toDF("citycode", "address", "tel", "mobile", "company",
        "contact", "src", "dept", "aoiid", "gid").write.mode(SaveMode.Overwrite).option("header", "true").csv(savePath)
    } else {
      logger.error("没有网点变更但aoi没变更的数据")
    }
    convertRet
  }

  def runInteface(dataList: Array[JSONObject], isTest: Boolean) = {
    var count = 0;
    val runRet = dataList.map(obj => {
      var tmpCompany = ""
      if (!obj.getString("company").isEmpty) {
        tmpCompany = URLEncoder.encode(obj.getString("company"), "utf-8")
      }
      val tmpUrl = String.format(url, obj.getString("citycode"),
        URLEncoder.encode(obj.getString("address"), "utf-8"),
        obj.getString("tel"), obj.getString("mobile"),
        tmpCompany,
        obj.getString("contact")
      )

      count = count + 1
      if (count % 500 == 0) {
        logger.error("已跑条数:" + count)
      }
      //      if (!isTest || count <= 11) {
      var cnt = 0
      var retJson: JSONObject = null;
      while (cnt < 3) {
        try {
          retJson = HttpUtils.urlConnectionGetJson(tmpUrl, 3 * 1000)
          cnt = 3
        } catch {
          case e: Exception => {
            logger.error(e)
            Thread.sleep(3000)
            cnt = cnt + 1
            if (cnt >= 3) {
              throw e
            }
          }
        }
      }
      if (retJson != null) {
        if (count == 1) {
          logger.error(retJson.toString())
        }
        val tcs = JSONUtil.getJsonArrayMultiOfFirstObject(retJson, "result.tcs")
        val dept = JSONUtil.getJsonValSingle(tcs, "dept")
        val aoiid = JSONUtil.getJsonValSingle(tcs, "aoiid")
        val src = JSONUtil.getJsonValSingle(tcs, "src")
        val gid = JSONUtil.getJsonValSingle(tcs, "groupid")
        obj.put("r_dept", dept)
        obj.put("r_aoiid", aoiid)
        obj.put("r_src", src)
        obj.put("r_gid", gid)
        //          if(StringUtils.isBlank(dept)){
        //            logger.error("返回为空："+obj.toJSONString+"----"+retJson)
        //          }
        if(!obj.getString("dept").equals(dept)){
          logger.error("数据不相等："+obj.toJSONString+"----"+retJson)
        }
        (obj, dept, aoiid)
      } else {
        logger.error("返回为空：" + obj)
        (obj, null, null)
      }
      //      } else {
      //        (obj, "", "")
      //      }
    })
    runRet
  }

  def main(args: Array[String]): Unit = {
    ///user/01374443/upload/ar
    val addressPath = args(0)
    //是否测试模式，会传到测试库
    var isTest = false
    if ("test".equals(args(1))) {
      isTest = true
    }
    //是否初始化，初始化，将以跑出的数据为准，更新全部数据
    var isInit = false
    if ("init".equals(args(2))) {
      isInit = true
    }
    //标杆数据来源是否是数据库，或者文件
    var sourceFromDb = true
    if ("file".equals(args(3))) {
      sourceFromDb = false
    }
    val sparkSession = Spark.getSparkSession(appName, null, true, 1)
    logger.error("装载数据：" + addressPath)
    var dataList = loadVipAddress(sparkSession, addressPath, sourceFromDb, isTest)
    logger.error("开始跑接口")
    val invokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01374443", "825154", "atpai服务-vip-地址定时测试", "大客户测试atpai服务", url, "e6d2bea8c2e64c5b8b37718eb8ce81cf", dataList.length, 1)
    val runInterfaceRet = runInteface(dataList, isTest)
    BdpTaskRecordUtil.endNetworkInterface("01374443", invokeId)
    logger.error("满足条件时，更新标杆数据")
    val fillRunRet = updateLatestData(sparkSession, runInterfaceRet, addressPath, isInit, isTest)

    val runNotNull = fillRunRet.filter(obj => obj._2 != null)
    logger.error("运行后不为null的结果数：" + runNotNull.size)

    val emptyCnt = runNotNull.filter(obj => !StringUtils.isBlank(obj._2)).length;
    logger.error("运行后不为空的结果数：" + emptyCnt)

    runNotNull.take(2).foreach(obj => {
      logger.error(obj._1.toJSONString + "," + obj._2)
    })

    logger.error("打印不相等的数据,用于核实和修改")
    print_errordata(isTest, runNotNull)
    logger.error("写表")
    insertIntoDisMysql(runNotNull, isTest, isInit)
    val maxEmpty = 0
    if (runNotNull.size < (dataList.size - maxEmpty)) {
      logger.error(s"*************为空数据超过${maxEmpty}条，请注意*************")
      System.exit(-1)
    }
    logger.error("完成")
  }

  def sendFsMsg(fsManager: FsManager, token: String, data: JSONObject, r_dept: String,
                r_aoi: String,
                time: Long) = {
    try {
      val content = AtpaiRunVip.convertWarninggContent(data, r_dept, r_aoi)
      fsManager.send(content.toJSONString, token, time, null)
    } catch {
      case e: Exception => logger.error(e)
    }
  }

  def print_errordata(isTest: Boolean, runRet: Array[(JSONObject, String, String)]): Unit = {
    logger.error("打印dept不相等数据")
    var printRet = runRet.filter(obj => {
      !obj._1.getString("dept").equals(obj._2)
    })
    if (!isTest) {
    } else {
      printRet = printRet.take(10)
    }
    if (printRet.length > 0) {
      logger.error("发送告警")
      //丰声告警相关信息
      val fsManager = new FsManager("atpai")
      val token = fsManager.queryToken
      System.out.println("token:" + token)
      val time = (new Date).getTime
      println("citycode,dept_new,dept_old,aoiid_new,aoiid_old,address,company,src_new,src_od,gid_new,gid_old")
      printRet.foreach(obj => {
        println(obj._1.getString("citycode") + "," +
          obj._2 + "," + obj._1.getString("dept") + "," +
          obj._3 + "," + obj._1.getString("aoiid") + "," +
          obj._1.getString("address") + "," +
          obj._1.getString("company") + "," +
          obj._1.getString("r_src") + "," +
          obj._1.getString("src") + "," +
          obj._1.getString("r_gid") + "," +
          obj._1.getString("gid")
        )
        //发送告警
        sendFsMsg(fsManager, token, obj._1, obj._2, obj._3, time)
      })
    } else {
      logger.error("无需告警")
    }
  }

  def convertWarninggContent(item: JSONObject, r_zc: String, r_aoi: String): JSONArray = {
    item.put("r_dept", r_zc)
    item.put("r_aoi", r_aoi)
    val keys = Array("id", "城市", "地址", "公司", "联系人", "电话", "手机", "原zc", "现zc", "原aoi", "现aoi", "原gid", "现gid", "原src", "现src")
    val mapKeys = Array("id", "citycode", "address", "company", "contact", "tel", "mobile", "dept", "r_dept", "aoi", "r_aoi", "gid", "r_gid", "src", "r_src")
    val retArray = new JSONArray();
    for (i <- 0 until keys.length) {
      val tmpJobj = new JSONObject();
      tmpJobj.put("key", keys(i))
      tmpJobj.put("value", item.getString(mapKeys(i)) + " ")
      retArray.add(tmpJobj)
    }
    return retArray
  }

  def insertIntoDisMysql(runRet: Array[(JSONObject, String, String)], isTest: Boolean, isInit: Boolean) = {
    var url: String = "jdbc:mysql://gismonitor-m.db.sfcloud.local:3306/gismonitor?useSSL=false&useUnicode=true&characterEncoding=utf-8"
    var username: String = "gismonitor"
    var password: String = "Gismonitor$3421"
    println("com.mysql.cj.jdbc.Driver")
    Class.forName("com.mysql.cj.jdbc.Driver");
    if (isTest) {
      url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useSSL=false&useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
      username = "gis_oms_rds"
      password = "gis_oms_rds@123@"
    }
    logger.error("url:" + url)
    val conn = DriverManager.getConnection(url, username, password)
    if (isInit) {
      logger.error("清除表")
      val ps = conn.prepareStatement(s" truncate table atpai_vip_addres_console ")
      ps.executeUpdate()
    }

    var count = 0
    val modifyTime = DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss");
    runRet.foreach(obj => {
      count = count + 1
      if (count % 500 == 0) {
        logger.error("count:" + count)
      }
      var sql = s"insert into  `atpai_vip_addres_console`(`id`,`address`,`citycode`,`tel`,`mobile`,`company`,`contact`," +
        s"`normdept`,`dept`,`normaoiid`,`aoiid`,`modify_time`,`normsrc`,`normgid`) " +
        s"values('${obj._1.getString("id")}','${obj._1.getString("address").replace("'", "’")}'," +
        s"'${obj._1.getString("citycode")}','${obj._1.getString("tel")}'," +
        s"'${obj._1.getString("mobile")}','${obj._1.getString("company")}'," +
        s"'${obj._1.getString("contact")}','${obj._1.getString("dept")}'," +
        s"'${obj._2}','${obj._1.getString("aoiid")}', '${obj._3}','${modifyTime}'," +
        s" '${obj._1.getString("src")}','${obj._1.getString("gid")}'" +
        s")" +
        s" ON DUPLICATE KEY update dept='${obj._2}'," +
        s"aoiid='${obj._3}',modify_time='${modifyTime}', normaoiid='${obj._1.getString("aoiid")}'   " +
        s" "
      if (obj._1.getBooleanValue("needUpdate")) {
        sql = sql + s",normdept='${obj._1.getString("dept")}'"
      }

      //      try{
      val ps = conn.prepareStatement(sql)
      ps.executeUpdate()
      //      }catch {
      //        case e:Exception=> logger.error(obj._2)
      //      }

    })
    val stmt = conn.createStatement
    val rs = stmt.executeQuery("select count(1) from atpai_vip_addres_console")
    while (rs.next()) {
      logger.error("表里面总数" + rs.getLong(1));
    }
    val rs1 = stmt.executeQuery("select * from atpai_vip_addres_console limit 1")
    while (rs1.next()) {
      logger.error("id:" + rs1.getString(1));
      logger.error("address:" + rs1.getString(2));
      logger.error("citycide:" + rs1.getString(3));
      logger.error("normdept:" + rs1.getString(8));
      logger.error("dept:" + rs1.getString(9));
      logger.error("modify_time:" + rs1.getString(10));
    }
    conn.close()
  }
}