package com.sf.gis.scala.console.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * table目录信息
 */
public class TableInfo implements Serializable {
    //列信息
    private List<ColumnInfo> columnList = new ArrayList<>();
    //是否外部表
    private boolean isExternal;
    //是否内部表
    private String tableName;
    //库名
    private String databaseName;
    //存储格式
    private String tableFormat;
    //压缩格式
    private String compressType;
    //hdfs路径
    private String hdfsHome;
    //分区名称
    private List<String> partitionNameList = new ArrayList<>();

    public TableInfo(String[] tableCreateInfoList, String databaseName) {
        boolean isPartitionsStart = false;
        boolean isTblproperties = false;
        this.databaseName = databaseName;
        for (int i = 0; i < tableCreateInfoList.length; i++) {
            String line = tableCreateInfoList[i];
            while(true){
                if (line.contains("  ")){
                    line = line.replaceAll("  "," ");
                }else{
                    break;
                }
            }
//            System.out.println(line);
            if (line.startsWith("CREATE TABLE ") || line.startsWith("CREATE EXTERNAL TABLE")) {
                judgeExternal(line);
                parseTableColumn(line);
                continue;
            }
            if (line.startsWith("PARTITIONED BY")) {
                parsePartitions(line);
                continue;
            }

            if (line.startsWith("LOCATION 'hdfs://")) {
                this.hdfsHome = line.replaceAll("'", "").replaceAll("LOCATION ", "");
                continue;
            }
            if (line.startsWith("ROW FORMAT SERDE '")) {
                parseTableFormat(line);
                continue;
            }
            if (line.startsWith("TBLPROPERTIES")) {
                isTblproperties = true;
                continue;
            }
            if (isTblproperties && line.contains("\\.compression")) {
                String[] compressType = line.split("=");
                if (compressType.length == 2 && compressType[0].endsWith("\\.compression'")) {
                    this.compressType = compressType[1].replaceAll("'", "");
                }
            }
        }
    }

    private void parseTableFormat(String line) {
        if (line.contains("org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe")) {
            this.tableFormat = "parquet";
        } else if (line.contains("org.apache.hadoop.hive.ql.io.orc.OrcSerde")) {
            this.tableFormat = "orc";
        } else {
            this.tableFormat = "txt";
        }
    }

    private void parsePartitions(String line) {
        String[] partitionInfo = line.split("`");
        for (int i = 0; i < partitionInfo.length; i++) {
            if (i % 2 == 1) {
                partitionNameList.add(partitionInfo[i]);
            }
        }
    }

    private void parseTableColumn(String line) {
        this.tableName = line.split("`")[1];
        String[] tableNameInfo = line.replaceAll("` \\(`","`\\(`").split("`\\(`")[1].split(", `");
        for (String column : tableNameInfo) {
            String[] columnsInfos = column.replaceAll("`", "").split(" ");
            ColumnInfo columnInfo = new ColumnInfo(columnsInfos[0], columnsInfos[1].replaceAll("\\)", ""));
            columnList.add(columnInfo);
        }
    }

    private void judgeExternal(String line) {
        if (line.startsWith("CREATE EXTERNAL TABLE")) {
            this.isExternal = true;
        } else {
            this.isExternal = false;
        }
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public List<ColumnInfo> getColumnList() {
        return columnList;
    }

    public void setColumnList(List<ColumnInfo> columnList) {
        this.columnList = columnList;
    }

    public boolean isExternal() {
        return isExternal;
    }

    public void setExternal(boolean external) {
        isExternal = external;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getTableFormat() {
        return tableFormat;
    }

    public void setTableFormat(String tableFormat) {
        this.tableFormat = tableFormat;
    }

    public String getCompressType() {
        return compressType;
    }

    public void setCompressType(String compressType) {
        this.compressType = compressType;
    }

    public String getHdfsHome() {
        return hdfsHome;
    }

    public void setHdfsHome(String hdfsHome) {
        this.hdfsHome = hdfsHome;
    }

    public List<String> getPartitionNameList() {
        return partitionNameList;
    }

    public void setPartitionNameList(List<String> partitionNameList) {
        this.partitionNameList = partitionNameList;
    }

    /**
     * 列信息
     */
    public static class ColumnInfo {
        private String name;
        private String type;

        public ColumnInfo(String name, String type) {
            this.name = name;
            this.type = type;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }

    public static void main(String[] args) {
        String line = "CREATE TABLE `dm_gis.gis_oms_small_file_info`(";
        String[] tableNameInfo = line.split("`")[1].split("\\.");
        System.out.println(tableNameInfo[0]);
    }
}

