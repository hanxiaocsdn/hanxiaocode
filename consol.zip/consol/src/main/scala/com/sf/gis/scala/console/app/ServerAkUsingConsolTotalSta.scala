package com.sf.gis.scala.console.app

import java.util.Date

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import com.sf.gis.scala.console.app.common.FsManager
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2024-01-02 14:34
 * @TaskId:	958257
 * @TaskName:服务ak监控-通知每日量
 * @Description:
 */
object ServerAkUsingConsolTotalSta {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)

  def rejectAkSql(dataType:String): String ={
    if("ars".equals(dataType)){
      val aks = Array("f2aeb3da621b45789168e599201f6623", "d1ff62d983654b3cbcd1e4432eff89d1",
        "8bb09e5e110845f39a000391668e3e80", "87106f6380af4df0845a693eee58843c",
        "af5938935293445084a6b7ba8cd23a4c", "58d89a9c079d4eff85918822de309c61",
        "281d0c93711f4db1a1c0255e25424cd8")
      return s" and  ak not in ('${aks.mkString("','")}') "
    }else if("seg".equals(dataType) || "segcx".equals(dataType)){
      val aks = Array("8bb09e5e110845f39a000391668e3e80","b4baa4d569bc416ab0f66dc2017c108c",
        "77c82ab7a7054f10af86b4422df2f1b2","1d1610331c0b47a8ab1e3dde081ca258","bf23cf0476a14f6b89c88e69e23dcbe7",
        "c7821c9dbe714de1a696aa024f3fd20e","ffc9595f015e4d2a96b565fc2dc1157a","0376a9aa84724dd2a995f858dd963346","3a7263f9423b47fc9a8d1defbfed10d9")
      return s" and ak not in ('${aks.mkString("','")}') "
    } else if("chkquery".equals(dataType)){
      val aks = Array("8bb09e5e110845f39a000391668e3e80","0376a9aa84724dd2a995f858dd963346","77c82ab7a7054f10af86b4422df2f1b2","a7588e5166e84b5f9f20c5f0397e9d0a")
      return s" and ak not in ('${aks.mkString("','")}') "
    }
    else {
      return " "
    }
  }


  def staDataTypeData(sparkSession: SparkSession, incDay: String, lastDay: String, dayWeekAgo: String,
                      dayWeek: String, lastDayWeek: String, dataType: String) = {
    var sql = s"select sum(cnt),inc_day from ${ServerAkUsingConsol.retTableName} where inc_day in " +
      s"('${incDay}','${lastDay}','${dayWeekAgo}' ) and data_type='${dataType}' "
    val akSql = rejectAkSql(dataType)
     sql = sql + akSql + "  group by inc_day  "
    logger.error(sql)
    val dataMap = sparkSession.sql(sql).rdd.map(obj => {
      (obj.getString(1), obj.getLong(0))
    }).collectAsMap()
    val todayCnt = dataMap.apply(incDay)
    val lastdayCnt = dataMap.apply(lastDay)
    val lastWeekCnt = dataMap.apply(dayWeekAgo)
    logger.error(todayCnt+","+lastdayCnt+","+lastWeekCnt)


    val (todayInfo, toDayCnt) = (converDayToChinese(incDay) + "(" + dayWeek + ")", todayCnt + " (" + (((todayCnt - lastWeekCnt) * 1.0 / lastWeekCnt *100).formatted("%.1f")) + "%)")
    val (lastdayInfo, lastDayCnt) = (converDayToChinese(lastDay) + "(" + lastDayWeek + ")", lastdayCnt + "")
    val (lastweekdayInfo, lastWeekDayCnt) = (converDayToChinese(dayWeekAgo) + "(" + dayWeek + ")", lastWeekCnt + "")

    //构造消息体
    val dataArray = Array((todayInfo, toDayCnt), (lastdayInfo, lastDayCnt), (lastweekdayInfo, lastWeekDayCnt))
    val retArray = new JSONArray();
    for (i <- 0 until dataArray.length) {
      val tmpJobj = new JSONObject();
      tmpJobj.put("key"," " )
      tmpJobj.put("value",dataArray(i)._1+": "+ dataArray(i)._2 + " ")
      retArray.add(tmpJobj)
    }
    sendFsMsg(retArray.toJSONString, convertFsFlag(dataType))
  }
  def converDayToChinese(date:String): String ={
      val year = date.substring(0,4)
    val month = date.substring(4,6)
    val day =date.substring(6,8)
    return year+"年"+month+"月"+day+"日"
  }
  def start(incDay: String, lastDay: String, dayWeekAgo: String, dataTypeArray: Array[String]): Unit = {
    val dayWeek = DateUtil.getWeekOfDateChinese(incDay)
    val lastDayWeek = DateUtil.getWeekOfDateChinese(lastDay)
    val sparkSession = Spark.getSparkSession(appName)
    for (dataType <- dataTypeArray) {
      staDataTypeData(sparkSession, incDay, lastDay, dayWeekAgo, dayWeek, lastDayWeek, dataType)
    }
  }

  def convertFsFlag(dataType: String) = {
    dataType + "_ak"
  }

  def sendFsMsg(content: String, fsFlag: String): Unit = {
    try {
      //丰声告警相关信息
      val fsManager = new FsManager(fsFlag)
      val token = fsManager.queryToken
      System.out.println("token:" + token)
      val time = (new Date).getTime
      fsManager.send(content, token, time, null)
    } catch {
      case e: Exception => logger.error(e)
    }
  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val lastDay = args(1)
    val dayWeekAgo = args(2)
    val dataType = args(3)
    logger.error(incDay, lastDay, dayWeekAgo, dataType)
    val dataTypeArray = dataType.split(",")
    start(incDay, lastDay, dayWeekAgo, dataTypeArray)
  }
}
