package com.sf.gis.scala.console.app

import java.util.Date

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.constants.ServerType
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import com.sf.gis.scala.console.app.common.FsManager
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2024-01-02 14:34
 * @TaskId:958523,958484
 * @TaskName:服务调用-chk-shou监控,服务调用-chk-pai监控
 * @Description: chk收和chk派服务和业务量之间比较，调用告警
 */

object ChkServerCompareBusiness {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)


  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dataType = args(1)
    val maxCnt = args(2).toLong
    println("incday:" + incDay)
    println("dataType:" + dataType)
    println("maxCnt:" + maxCnt)
    start(incDay, dataType, maxCnt)
  }

  def queryOriginDataSql(incDay: String, dataType: String): String = {
    if (dataType.equals(ServerType.chkshou.name())) {
      val sql =
        s"""
           |select count(1) from
           |(select src_order_no from dwd.dwd_pub_order_dtl_di where inc_day='${incDay}' group by src_order_no) wb
           |left join
           |(select sysorderno from dm_gis.gis_rds_omsfrom where inc_day='${incDay}' group by sysorderno) log on wb.src_order_no = log.sysorderno
           |where log.sysorderno is null
           |""".stripMargin
      logger.error(sql)
      return sql
    } else if (dataType.equals(ServerType.chkpai.name())) {
      val sql =
        s"""
           |select count(1) from
           |(select  waybill_no from dwd.dwd_waybill_info_dtl_di where inc_day = '${incDay}' group by waybill_no) wb
           |left join
           |(select req_waybillno from dm_gis.gis_rds_omsto where inc_day = '${incDay}' group by req_waybillno) log
           | on wb.waybill_no = log.req_waybillno
           |where log.req_waybillno is null
           |""".stripMargin
      logger.error(sql)
      return sql
    }
    return null
  }


  def queryOriginData(sparkSession: SparkSession, incDay: String, dataType: String) = {
    val sql = queryOriginDataSql(incDay, dataType)
    var cnt = sparkSession.sql(sql).rdd.map(obj => {
      val cnt = obj.getLong(0)
      cnt
    }).collect()(0)
    logger.error("差异量：" + cnt)
    cnt
  }


  def start(incDay: String, dataType: String, maxCnt: Long): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    logger.error("获取原始数据")
    val cnt = queryOriginData(sparkSession, incDay, dataType)
    logger.error("比较差异结果，发送告警")

    if (cnt > maxCnt*10000) {
      val arrayBuffer = new ArrayBuffer[String]()
      arrayBuffer.append(DateUtil.converDayToChinese(incDay) + "（" + DateUtil.getWeekOfDateChinese(incDay) + "）" )

      arrayBuffer.append("未调用量为："+cnt+"，超过:"+maxCnt+"万，烦请关注！！！")
      //构造消息体
      val retArray = new JSONArray();
      for (i <- 0 until arrayBuffer.length) {
        val tmpJobj = new JSONObject();
        tmpJobj.put("key", " ")
        tmpJobj.put("value", arrayBuffer(i)+" ")
        retArray.add(tmpJobj)
      }
      sendFsMsg(retArray.toJSONString, convertFsFlag(dataType))
    }
    logger.error("结束")
  }

  def convertFsFlag(dataType: String) = {
    dataType + "_compare_business"
  }

  def sendFsMsg(content: String, fsFlag: String): Unit = {
    try {
      //丰声告警相关信息
      val fsManager = new FsManager(fsFlag)
      val token = fsManager.queryToken
      System.out.println("token:" + token)
      val time = (new Date).getTime
      fsManager.send(content, token, time, null)
    } catch {
      case e: Exception => logger.error(e)
    }
  }
}
