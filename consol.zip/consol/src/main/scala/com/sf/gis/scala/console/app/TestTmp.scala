package com.sf.gis.scala.console.app


import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger


object TestTmp {

  @transient lazy val logger: Logger = Logger.getLogger(TestTmp.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    val sql =
      s"""
         |
         |insert into  dm_gis.ars_server_pressure_test_table partition(inc_day='20210219')
         |select
         |  distinct m.waybill_no as waybill_no,
         |  m.d_deliverycode as d_deliverycode,
         |  n.dist_code as dist_code,
         |  m.consignee_addr as consignee_addr
         |from
         |  (
         |    select
         |       regexp_replace(
         |      regexp_replace(
         |       concat(
         |          nvl(a.d_province, ''),
         |          nvl(a.d_cityname, ''),
         |          nvl(a.d_address, '')
         |        ),
         |        "[,\r\n\t\' ]",
         |        ''
         |      ),'"' ,'') as consignee_addr,
         |      a.d_deliverycode as d_deliverycode,
         |      regexp_replace(a.mailno, ',', ' ') as waybill_no
         |    from
         |      ods_bsp.tl_bsp_order a
         |      join ods_bsp.tt_orders_confirm_status b on a.inc_day between '20210120'
         |      and '20210311'
         |      and a.create_tm like '%2021-02-19%'
         |      and a.mailno is not null
         |      and a.d_deliverycode regexp '[0-9]+'
         |      and b.inc_day between '20210120'
         |      and '20210311'
         |      and b.deal_status <> 2
         |      and a.id = b.log_id
         |  ) m
         |  inner join (
         |    select
         |      d.mainwaybillno as mainwaybillno,
         |      e.dist_code as dist_code
         |    from
         |      (
         |        select
         |          c.mainwaybillno,
         |          c.zonecode
         |        from
         |          (
         |            select
         |              a.mainwaybillno,
         |              a.zonecode,
         |              b.mainwaybillno as b_mainwaybillno
         |            from
         |              (
         |                select
         |                  mainwaybillno,
         |                  zonecode
         |                from
         |                  (
         |                    select
         |                      t.mainwaybillno,
         |                      t.zonecode,
         |                      row_number() over (
         |                        partition by t.mainwaybillno
         |                        order by
         |                          t.barscantmstd
         |                      ) as rowno
         |                    from
         |                      ods_kafka_fvp.fvp_core_fact_route_op t
         |                    WHERE
         |                      t.inc_day between 20210219
         |                      and 20210306
         |                      and t.opcode = '80'
         |                  ) u
         |                where
         |                  u.rowno = 1
         |              ) a
         |              left outer join (
         |                select
         |                  distinct x.mainwaybillno
         |                from
         |                  ods_kafka_fvp.fvp_core_fact_route_op x
         |                where
         |                  inc_day between 20210219
         |                  and 20210306
         |                  and (
         |                    (
         |                      x.opcode = '33'
         |                      and x.staywhycode in ('55', '67', '14', '9')
         |                    )
         |                    or (
         |                      x.opcode = '70'
         |                      and x.staywhycode in ('55', '67', '14', '9')
         |                    )
         |                    or (
         |                      x.opcode = '77'
         |                      and x.staywhycode in ('14', '55', '103')
         |                    )
         |                    or x.opcode = '99'
         |                    or x.opcode = '626'
         |                    or x.opcode = '627'
         |                  )
         |              ) b on a.mainwaybillno = b.mainwaybillno
         |          ) c
         |        where
         |          c.b_mainwaybillno is null
         |      ) d
         |      left outer join (
         |        select
         |          *
         |        from(
         |            select
         |              dept_name,
         |              dept_code,
         |              nvl(division_code, dept_code) division_code,
         |              nvl(division_name, dept_name) division_name,
         |              area_name,
         |              area_code,
         |              hq_code,
         |              hq_name,
         |              dist_code,
         |              city_code,
         |              province_code,
         |              row_number() over(
         |                partition by dept_code
         |                order by
         |                  create_tm desc
         |              ) rn
         |            from
         |              gdl.zipper_dim_department
         |            where
         |              dw_end_date >= '20210219'
         |              and dw_start_date <= '20210219'
         |              and delete_flg = '0'
         |              and dist_code regexp '[0-9]+'
         |          ) tt
         |        where
         |          tt.rn = 1
         |      ) e on d.zonecode = e.dept_code
         |  ) n on m.waybill_no = n.mainwaybillno
         |
         |""".stripMargin

    logger.error("sql")
    val sparkSession = Spark.getSparkSession(appName)
    sparkSession.sql(sql)
    sparkSession.sql("select count(*) from dm_gis.ars_server_pressure_test_table where " +
      "inc_day='20210219' ").show(100)
  }


}
