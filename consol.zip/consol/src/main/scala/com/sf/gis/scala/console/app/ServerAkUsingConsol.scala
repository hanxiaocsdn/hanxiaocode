package com.sf.gis.scala.console.app

import com.sf.gis.scala.base.constants.ServerType
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2024-01-02 14:34
 * @TaskId:957807
 * @TaskName:服务ak监控
 * @Description:
 */

object ServerAkUsingConsol {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass.getSimpleName)
  //
  val retTableName = "dm_gis.dm_server_ak_console_di"

  case class ServerConsolAkInfo(
                                 ak: String,
                                 day: String,
                                 hour: String,
                                 cnt: Long,
                                 dataType:String
                               )

  def main(args: Array[String]): Unit = {
    for (arg <- args) {
      println(arg)
    }
    //    val akUsingConsol = new ServerAkUsingConsol()
    val incdaySep = args(0)
    val startHour = args(1)
    startHour.toInt
    val endHour = args(2)
    endHour.toInt
    val startMinu = args(3)
    val endMinu = args(4)
    val inday = incdaySep.replace("-", "")
    val inputDataType = args(5)
    val originTableName = args(6)
    val dataType = ServerType.matchServerType(inputDataType)
    println("incday:" + incdaySep)
    println("start time:" + startHour + ":" + startMinu)
    println("end time:" + endHour + ":" + endMinu)
    start(incdaySep, startHour, startMinu, endHour, endMinu, inday, dataType,originTableName)
  }

  def queryOriginDataSql(spark:SparkSession,incdaySep: String, startHour: String, startMinu: String, endHour: String,
                         endMinu: String, incday: String, dataType: ServerType,originTableName:String): String = {
    val startTime = incdaySep + " " + startHour + ":" + startMinu + ":" + "00" + ".000"
    val endTime = incdaySep + " " + endHour + ":" + endMinu + ":" + "59" + ".999"
    if (dataType.equals(ServerType.chkshou)) {
      val sql = "select count(1) cnt,'' ak, substr(get_json_object(log,'$.createTime'),0,13)," +
        s"'${ServerType.chkshou.name()}' dataType " +
        s" from ${originTableName} where inc_day = '${incday}' " +
        "and log like '%\"dataType\":\"req\"%' and log like '%\"type\":\"rds\"%' and get_json_object(log,'$.createTime') between  " +
        s" '${startTime}' and '${endTime}' " +
        " group by substr(get_json_object(log,'$.createTime'),0,13) "
      logger.error(sql)
      return sql
    } else if (dataType.equals(ServerType.chkpai)) {
      val sql = "select count(1) cnt,'' ak, substr(get_json_object(log,'$.createTime'),0,13)," +
        s" '${ServerType.chkpai.name()}' dataType " +
        s" from ${originTableName} where inc_day = '${incday}' " +
        "and log like '%receive oms waybill message%' and get_json_object(log,'$.createTime') between  " +
        s" '${startTime}' and '${endTime}'  " +
        " group by substr(get_json_object(log,'$.createTime'),0,13) "
      logger.error(sql)
      return sql
    } else if (dataType.equals(ServerType.chkquery)) {
      spark.sql("CREATE TEMPORARY FUNCTION " +
        " parseServerAkUDTF as 'com.sf.gis.scala.base.util.ParseServerAkUDTF' ")
      val sql = s"select count(1) cnt , ak, timeHour,'${ServerType.chkquery.name()}' dataType from (" +
        s" select parseServerAkUDTF(log,'${ServerType.chkquery.name()}') from ${originTableName} " +
        s" where inc_day = '${incday}' and (log like '%teamCodeCotrollerArgs%'  or log like '%teamCodeBatchCotrollerArg%' ) " +
        " and get_json_object(log,'$.createTime') between  " +
        s" '${startTime}' and '${endTime}' " +
        ") a group by ak,timeHour"
      logger.error(sql)
      return sql
    }else if(dataType.equals(ServerType.ars)){
      val sql = "select count(1) cnt,get_json_object(get_json_object(log, '$.message'), '$.url.ak') ak, " +
        "substr(get_json_object(get_json_object(log, '$.message'), '$.dateTime'),0,13)," +
        s" '${ServerType.ars.name()}' dataType " +
        s" from ${originTableName} where inc_day = '${incday}' " +
        "and get_json_object(get_json_object(log, '$.message'), '$.type') = 'url_s' and get_json_object(get_json_object(log, '$.message'), '$.dateTime') between  " +
        s" '${startTime}' and '${endTime}'  " +
        " group by get_json_object(get_json_object(log, '$.message'), '$.url.ak'),substr(get_json_object(get_json_object(log, '$.message'), '$.dateTime'),0,13) "
      logger.error(sql)
      return sql
    }else if(dataType.equals(ServerType.seg)){
      val sql = "select count(1) cnt,ak,timeHour,dataType from (" +
        "select get_json_object(get_json_object(logs, '$.message'), '$.url.ak') ak, substr(get_json_object(get_json_object(logs, '$.message'), '$.dateTime'),0,13) timeHour," +
        " if(get_json_object(get_json_object(get_json_object(logs, '$.message'), '$.url'), '$.url') like '%/seg/%',  " +
        s" '${ServerType.seg.name}', " +
        " if(get_json_object(get_json_object(get_json_object(logs, '$.message'), '$.url'), '$.url') " +
        s" like '%/segcx/%','${ServerType.segcx.name()}','')) dataType " +
        s" from ${originTableName} where inc_day = '${incday}' " +
        " and get_json_object(get_json_object(logs, '$.message'), '$.type') = 'url_s' and get_json_object(get_json_object(logs, '$.message'), '$.dateTime') between  " +
        s" '${startTime}' and '${endTime}' " +
        " and get_json_object(get_json_object(get_json_object(logs, '$.message'), '$.url'), '$.url') like '%/seg%' ) a " +
        " group by ak, timeHour,dataType "
      logger.error(sql)
      return sql
    }
//    else if(dataType.equals(ServerType.segcx)){
//      val sql = "select count(1) cnt,get_json_object(get_json_object(log, '$.message'), '$.url.ak') ak, substr(get_json_object(get_json_object(log, '$.message'), '$.dateTime'),0,13) " +
//        s" from ${originTableName} where inc_day = '${incday}' " +
//        "and   get_json_object(get_json_object(log, '$.message'), '$.type') = 'url_s' and get_json_object(get_json_object(log, '$.message'), '$.dateTime') between  " +
//        s" '${startTime}' and '${endTime}' " +
//        " and get_json_object(get_json_object(get_json_object(logs, '$.message'), '$.url'), '$.url') like '%/segcx/%' " +
//        " group by get_json_object(get_json_object(log, '$.message'), '$.url.ak'),substr(get_json_object(get_json_object(log, '$.message'), '$.dateTime'),0,13) "
//      logger.error(sql)
//      return sql
//    }
    else if(dataType.equals(ServerType.geo)){
      val sql = "select count(1) cnt,get_json_object(get_json_object(log, '$.message'), '$.url.ak') ak," +
        " substr(get_json_object(get_json_object(log, '$.message'), '$.dateTime'),0,13)," +
        s" '${ServerType.geo.name()}' dataType " +
        s" from ${originTableName} where inc_day = '${incday}' " +
        "and get_json_object(get_json_object(log, '$.message'), '$.type') = 'url_s' and get_json_object(get_json_object(log, '$.message'), '$.dateTime') between  " +
        s" '${startTime}' and '${endTime}'  " +
        " group by get_json_object(get_json_object(log, '$.message'), '$.url.ak'),substr(get_json_object(get_json_object(log, '$.message'), '$.dateTime'),0,13) "
      logger.error(sql)
      return sql
    }
    return null
  }

  def parserAk(data: String): String = {
    return "";
  }


  def queryOriginData(sparkSession: SparkSession, incdaySep: String, startHour: String,
                      startMinu: String, endHour: String, endMinu: String,
                      incday: String, dataType: ServerType,
                      sql: String) = {
    var currentDataRdd = sparkSession.sql(sql).rdd.map(obj => {
      var ak = obj.getString(1)
      val times = obj.getString(2).split(" ")
      val day = times(0)
      val useHourStr = times(1)
      val dataType = obj.getString(3)
      ServerConsolAkInfo(ak,day, useHourStr,obj.getLong(0),dataType)
    }).filter(obj=> !StringUtils.isBlank(obj.dataType)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("当前时间段的数据数量：" + currentDataRdd.count())
    currentDataRdd.take(3).foreach(obj=>{
      logger.error(obj.ak,obj.day,obj.hour,obj.cnt,obj.dataType)
    })
    currentDataRdd
  }

  def queryDayData(sparkSession: SparkSession, incday: String, dataType: ServerType) = {
    val sql = s"select ak,cnt,hour,data_type from ${retTableName} where inc_day='${incday}' and data_type like '%${dataType.name}%' "
    logger.error(sql)
    val dataRdd = sparkSession.sql(sql).rdd.map(obj => {
      ServerConsolAkInfo(obj.getString(0), incday, obj.getString(2), obj.getLong(1),obj.getString(3))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("今天已有数据：" + dataRdd.count())
    dataRdd
  }

  def saveData(sparkSession: SparkSession, currentDataRdd: RDD[ServerConsolAkInfo], incday: String,
               dataType: ServerType): Unit = {
    logger.error("获取当天全量数据")
    val dayDataRdd = queryDayData(sparkSession, incday, dataType)
    import sparkSession.implicits._
    val tmpView = "tmp_" + System.currentTimeMillis()
    currentDataRdd.union(dayDataRdd).repartition(1).toDF().createOrReplaceTempView(tmpView)
    val sql = s"insert overwrite table ${retTableName} partition(inc_day,data_type)  " +
      s" select ak,cnt,hour,'${incday}' as inc_day ,dataType as data_type from ${tmpView} "
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def start(incdaySep: String, startHour: String, startMinu: String, endHour: String, endMinu: String, incday: String,
            dataType: ServerType,originTableName:String): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    logger.error("获取原始数据sql")
    val sql = queryOriginDataSql(sparkSession,incdaySep, startHour, startMinu,
      endHour, endMinu, incday, dataType,originTableName)
    logger.error("获取原始数据")
    val currentDataRdd = queryOriginData(sparkSession, incdaySep, startHour, startMinu,
      endHour, endMinu, incday, dataType, sql)
    logger.error("存储全量明细数据")
    saveData(sparkSession, currentDataRdd, incday, dataType)
    logger.error("结束")
  }
}
