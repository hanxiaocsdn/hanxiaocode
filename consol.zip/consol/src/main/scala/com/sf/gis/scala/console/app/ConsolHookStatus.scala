package com.sf.gis.scala.console.app

import java.util

import com.alibaba.fastjson.serializer.SerializeFilter
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.console.bean.{ConsoleConfig, HdfsInfo, TableInfo, TableTag}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * 针对挂接任务是否已启动
 * 根据数据量大小,申请不同的资源分级做处理
 */

object ConsolHookStatus {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  val smalFileTable = "dm_gis.gis_oms_small_file_info"


  def parseDatabases(sparkSession: SparkSession, databases: Array[String],
                     tableWhiteList: Array[String],
                     judgeRule: JSONObject, infoRule: JSONObject) = {
    for (database <- databases) {
      logger.error("当前数据库：" + database)
      sparkSession.sql(s"use $database")
      val tableList = sparkSession.sql("show tables").rdd.map(obj => {
        obj.getString(0)
      }).collect()
      logger.error("总数据表数量：" + tableList.size + ",样例:" + tableList.take(1))
      var i = 1
      for (name <- tableList; if i == 1) {
        val tableInfo = sparkSession.sql(s"show create table $name").rdd.map(obj => {
          obj.getString(0)
        }).collect()
        tableInfo.foreach(obj => {
          logger.error(obj)
        })
        val ret = new JSONObject()
        ret.put("name", name)
        ret.put("db", database)
        for (info <- tableInfo) {
          val judgeRuleArray = judgeRule.keySet().toArray.asInstanceOf[Array[String]]
          for (key <- judgeRuleArray) {
            if (info.matches(judgeRule.getString(key))) {
              ret.put(key, "1")
            }
          }
          val infoRuleArray = infoRule.keySet().toArray.asInstanceOf[Array[String]]
          for (key <- infoRuleArray) {
            if (info.matches(infoRule.getString(key))) {
              val pattern = s"""${infoRule.getString(key)}""".r
              val ruleRet = pattern.findFirstIn(info).get
              ret.put(key, ruleRet)
            }
          }
        }
        i = 2
        logger.error("" + ret)
      }
    }
  }

  def checkDate(hdfsInfo: HdfsInfo, startDate: String, endDate: String): Boolean = {
    if (!hdfsInfo.isTable) {
      return false
    }
    if (!hdfsInfo.isPartitionType) {
      return true
    }
    for (i <- 0 until hdfsInfo.getPartitionList.size()) {
      val keyValue = hdfsInfo.getPartitionList.get(i)
      val date = keyValue.getValue.replaceAll("[-_ ]", "")
      if (date <= endDate && date >= startDate) {
        return true
      }
    }
    return false
  }

  def querySuspiciousData(sparkSession: SparkSession, incDay: String,
                          cluster: String, hdfsPathArray: Array[String],
                          startDate: String, endDate: String,
                          smallFileMaxSize: Long,
                          hdfsInfoMapBc: Broadcast[util.HashMap[String, util.ArrayList[TableInfo]]],
                          hdfsPre: String, internalTableNameMapBc: Broadcast[util.HashMap[String, TableInfo]]) = {

    var sql = s"select path,modificationtime,accesstime,size,filecount from dm_bdpfsimage.$cluster " +
      s"where ds='$incDay' and modificationtime between '$startDate' and '$endDate' "
    ///添加hdfs限制
    var hdfsFilterBuffer = new ArrayBuffer[String]()
    hdfsFilterBuffer.append(" and (path like '")
    hdfsFilterBuffer.append(hdfsPathArray.mkString("%' or path like '"))
    hdfsFilterBuffer.append("%') ")
    sql = sql + hdfsFilterBuffer.mkString("")
    //添加平均值判断
    sql = sql + s" and (size/filecount < $smallFileMaxSize ) "
    logger.error("取数sql：" + sql)
    val smallFileDataRdd = sparkSession.sql(sql).rdd.repartition(200).map(obj => {
      val hdfsInfo = new HdfsInfo(obj.getString(0), obj.getString(1), obj.getString(2),
        obj.getLong(3), obj.getInt(4), hdfsPathArray, hdfsPre)
      hdfsInfo
    }).filter(hdfsInfo => hdfsInfo.isTable).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("数量：" + smallFileDataRdd.count())
    smallFileDataRdd.take(10).foreach(obj => {
      logger.error(JSON.toJSONString(obj, new Array[SerializeFilter](0)))
    })
    //      .filter(obj=>{
    //     checkDate(obj,startDate,endDate)
    //    })
    val groupRdd = smallFileDataRdd.map(hdfsInfo => ((hdfsInfo.getDatabaseName, hdfsInfo.getTableName), hdfsInfo))
      .groupByKey()
      .flatMap(obj => {
        val dataArray = obj._2.toArray.sortBy(_.getPartitionList.size())
        //获取最后一个层级分区的长度
        val maxPartitionSize = dataArray.last.getPartitionList.size();
        val tableInfoList = new java.util.ArrayList[JSONObject]
        for (hdfsInfo <- dataArray) {
          if (hdfsInfo.getPartitionList.size() == maxPartitionSize) {
            //保留最后一个层级分区信息
            if (hdfsInfo.getSize <= smallFileMaxSize && hdfsInfo.getFileCnt == 1) {
              //分区里面的总数量太小
              hdfsInfo.getTagList.add(TableTag.sizeLess20M.name())
            }
            checkResultByHdfsInfoDetail(hdfsInfo, hdfsInfoMapBc.value, internalTableNameMapBc.value)
            val tmpStr = JSON.toJSONString(hdfsInfo, new Array[SerializeFilter](0))
            tableInfoList.add(JSON.parseObject(tmpStr))
          }
        }
        tableInfoList.iterator()
      }).persist(StorageLevel.MEMORY_AND_DISK_SER_2);
    logger.error("存在小文件的分区数：" + groupRdd.count())
    groupRdd
  }

  def queryHdfsTableInfo(sparkSession: SparkSession, databaseArray: Array[String]) = {
    val externalTableHdfsMap = new util.HashMap[String, java.util.ArrayList[TableInfo]]()
    val internalTableNameMap = new util.HashMap[String, TableInfo]()
    for (database <- databaseArray) {
      sparkSession.sql(s"use ${database}")
      val tableList = sparkSession.sql("show tables").rdd.map(obj => {
        obj.getString(1)
      }).collect()
      logger.error("库表的数量：" + tableList.size + ",示例:" + tableList.take(3).mkString(","))

      logger.error("开始获取表信息")
      for (tableName <- tableList) {
        val tableCreateInfoList = sparkSession.sql(s"show create table ${tableName}").rdd.map(obj => {
          obj.getString(0).toString
        }).collect()
        val tableInfo = new TableInfo(tableCreateInfoList(0).split("\\n"), database)
        if (tableInfo.getHdfsHome != null && tableInfo.isExternal) {
          if (externalTableHdfsMap.containsKey(tableInfo.getHdfsHome)) {
            externalTableHdfsMap.get(tableInfo.getHdfsHome).add(tableInfo)
          } else {
            val tableInfoList = new util.ArrayList[TableInfo]()
            tableInfoList.add(tableInfo)
            externalTableHdfsMap.put(tableInfo.getHdfsHome, tableInfoList)
          }
        } else if (!tableInfo.isExternal) {
          internalTableNameMap.put(tableInfo.getDatabaseName + "." + tableInfo.getTableName, tableInfo)
        }
      }
    }
    logger.error("外部表带hdfs的表级映射关系:" + externalTableHdfsMap.size())
    logger.error("内部表的表级映射关系:" + internalTableNameMap.size())
    (sparkSession.sparkContext.broadcast(internalTableNameMap), sparkSession.sparkContext.broadcast(externalTableHdfsMap))
  }

  def checkResultByHdfsInfoDetail(hdfsInfo: HdfsInfo,
                                  hdfsInfoMap: util.HashMap[String, util.ArrayList[TableInfo]],
                                  internalTableNameMap: util.HashMap[String, TableInfo]): Unit = {
    if (!hdfsInfoMap.containsKey(hdfsInfo.getHdfsHome)
      && !internalTableNameMap.containsKey(hdfsInfo.getDatabaseName + "." + hdfsInfo.getTableName)) {
      return;
    }
    if (hdfsInfoMap.containsKey(hdfsInfo.getHdfsHome)) {
      val tableInfoList = hdfsInfoMap.get(hdfsInfo.getHdfsHome)
      var maxColumns = 0;
      hdfsInfo.setExistTable(true)

      for (tableinfo <- tableInfoList) {
        hdfsInfo.getRelateTables.add(tableinfo.getDatabaseName + "." + tableinfo.getTableName)
        if (tableinfo.getColumnList.size() > maxColumns) {
          maxColumns = tableinfo.getColumnList.size()
          hdfsInfo.setTableName(tableinfo.getTableName)
          hdfsInfo.setDatabaseName(tableinfo.getDatabaseName)
          hdfsInfo.setTableFormat(tableinfo.getTableFormat)
          hdfsInfo.setCompressType(tableinfo.getCompressType)
          hdfsInfo.setExternal(tableinfo.isExternal)
          val tablePartitionNameList = tableinfo.getPartitionNameList
          val hdfsPartitionList = hdfsInfo.getPartitionList
          if (tablePartitionNameList.size() == hdfsPartitionList.size()) {
            for (i <- 0 until tablePartitionNameList.size()) {
              hdfsPartitionList.get(i).setKey(tablePartitionNameList.get(i))
            }
          } else {
            hdfsInfo.getTagList.add(TableTag.partitionDiffWithHive.name())
          }
        }
      }
    } else {
      val tableinfo = internalTableNameMap.get(hdfsInfo.getDatabaseName + "." + hdfsInfo.getTableName)
      hdfsInfo.setExternal(tableinfo.isExternal)
      hdfsInfo.getRelateTables.add(tableinfo.getDatabaseName + "." + tableinfo.getTableName)
      hdfsInfo.setExistTable(true)
      hdfsInfo.setTableFormat(tableinfo.getTableFormat)
      hdfsInfo.setCompressType(tableinfo.getCompressType)
      val tablePartitionNameList = tableinfo.getPartitionNameList
      val hdfsPartitionList = hdfsInfo.getPartitionList
      if (tablePartitionNameList.size() == hdfsPartitionList.size()) {
        for (i <- 0 until tablePartitionNameList.size()) {
          hdfsPartitionList.get(i).setKey(tablePartitionNameList.get(i))
        }
      } else {
        hdfsInfo.getTagList.add(TableTag.partitionDiffWithHive.name())
      }
    }
  }
  def start(incDay: String, startDate: String, endDate: String): Unit = {
    logger.error("拉取配置")
    val consoleConfig = new ConsoleConfig("conf/table_consol.properties")
    //    logger.error("开始遍历数据库")
    //    val confMap=Map("hive.metastore.uris"->"thrift://10.116.100.12:9075,thrift://10.116.100.5:9075,thrift://10.116.100.6:9075,thrift://10.116.100.8:9075,thrift://10.116.101.6:9075,thrift://10.116.100.12:9076,thrift://10.116.100.5:9076,thrift://10.116.100.6:9076,thrift://10.116.100.8:9076,thrift://10.116.101.6:9076,thrift://10.116.100.12:9077,thrift://10.116.100.5:9077,thrift://10.116.100.6:9077,thrift://10.116.100.8:9077,thrift://10.116.101.6:9077")
    val sparkSession = Spark.getSparkSession(className)
    logger.error("开始遍历数据库，获取表信息")
    val (internalTableNameMapBc, hdfsInfoMapBc) = queryHdfsTableInfo(sparkSession, consoleConfig.databaseArray)
    logger.error("开始读取sfbd表数据表数据")
    val clusterArray = consoleConfig.clusterMap
    for (cluster <- clusterArray) {
      logger.error("集群名称：" + cluster)
      val hdfsPathArray = consoleConfig.clusterMap.get(cluster._1)
      val smallFileDataRdd = querySuspiciousData(sparkSession, incDay, cluster._1, hdfsPathArray,
        startDate, endDate, consoleConfig.smallFileMaxSize, hdfsInfoMapBc, consoleConfig.clusterPreMap.get(cluster._1),
        internalTableNameMapBc)
      Spark.clearPersistWithoutId(sparkSession, smallFileDataRdd.id)

      logger.error("存储到小文件结果表:" + smalFileTable)
      val hdfsInfoArray = Array("hdfsPath", "databaseName", "tableName", "avgSize", "tagList", "table", "external", "partitionType", "size", "fileCnt", "relateTables", "existTable", "hivePartitionExist", "hdfsHome", "tableFormat", "compressType", "partitionList")
      SparkWrite.save2HiveStatic(sparkSession, smallFileDataRdd.repartition(1), hdfsInfoArray, smalFileTable, Array(("inc_day", incDay), ("cluster_name", cluster._1)), 1)
    }


    //    sparkSession.sql("set hive.metastore.uris").collect().foreach(obj=> logger.error(obj.getString(1)))
    //    val showSql = "show databases"
    //    logger.error("查询databases")
    //    sparkSession.sql(showSql).show(100)
    //    logger.error("查询databases完毕")
    //
    //    val sql = "use dm_gis"
    //    logger.error("切换dm_gis")
    //    sparkSession.sql(sql).show(100)
    //    logger.error("切换dm_gis完毕")
    //    val ret = parseDatabases(sparkSession,databases,tableWhiteList,judgeRule,infoRule)
  }

  def main(args: Array[String]): Unit = {
    //表明检测的时间
    val incDay = args(0)
    val startDate = args(1)
    val endDate = args(2)
    start(incDay, startDate, endDate)
  }
}


