package com.sf.gis.scala.console.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.base.util.HttpUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:
 * @TaskName:
 * @Description:丰声工具类
 */
public class FsUtils {
    public static final Logger logger = LoggerFactory.getLogger(FsUtils.class);

    public static String queryToken(String url, Map<String, String> parm) {
        String content = null;
        try {
            content = HttpUtils.postForm(url, parm, "utf-8");
            JSONObject jsonObject = JSON.parseObject(content);
            return jsonObject.getString("access_token");
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("获取丰声token异常：" + e.getMessage() + ",content:" + content);
        }
        return null;
    }

    public static Map<String, Object> sendMsg(String sendUrl, JSONObject parm, Map<String, String> headerMap) {
        Map<String, Object> retMap = new HashMap<>();
        String content = HttpUtils.postJson(sendUrl, parm, headerMap);
        try {
            JSONObject jsonObject = JSON.parseObject(content);
            if (jsonObject.getInteger("code") == 200) {
                retMap.put("status", true);
            } else {
                logger.error("response:"+jsonObject);
                retMap.put("message", "Send fs failed，content:" + content+",response:"+jsonObject);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("发送丰声失败：" + e.getMessage() + ",content:" + content);
            retMap.put("message", "Send fs failed，" + e.getMessage() + ",content:" + content);
        }
        return retMap;
    }
}
