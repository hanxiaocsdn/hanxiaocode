package com.sf.gis.scala.console.bean;

import java.io.Serializable;
/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:
 * @TaskName:
 * @Description:告警类
 */
public class WarnningInfo implements Serializable {
    //表名
    private String tableName;
    //当前小文件数
    private long curAverageSize ;
    //建议分区数
    private int advertisePartition;
    //分区时间
    private String partition;
    public WarnningInfo(String tableName,String partition, long curAverageSize,int advertisePartition){
        this.tableName = tableName;
        this.partition = partition;
        this.curAverageSize = curAverageSize;
        this.advertisePartition = advertisePartition;
    }
    public String getPartition() {
        return partition;
    }

    public void setPartition(String partition) {
        this.partition = partition;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public long getCurAverageSize() {
        return curAverageSize;
    }

    public void setCurAverageSize(long curAverageSize) {
        this.curAverageSize = curAverageSize;
    }

    public int getAdvertisePartition() {
        return advertisePartition;
    }

    public void setAdvertisePartition(int advertisePartition) {
        this.advertisePartition = advertisePartition;
    }

    @Override
    public String toString() {
        return "表名：\""+tableName+",分区：\""+partition+"\",当前平均大小:"+
                curAverageSize+"B,建议重分区数:"+advertisePartition;
    }
}
