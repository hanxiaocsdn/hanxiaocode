package com.sf.gis.scala.console.app.common

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
/**
 * @ProductManager:01374443
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:478956
 * @TaskName:添加外部表分区
 * @Description:用于spark代码添加分区，部分hdfs是sfbdp1，hive无权限访问
 */
object AddSinglePartition {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val hdfsArray = args(0).split(";")
    logger.error("args(0):" + args(0))
    val sparkSession = Spark.getSparkSession(className)
    for (i <- 0 until hdfsArray.length) {
      val itemArray = hdfsArray(i).split(",")
      val tableName = itemArray(0)
      val partitionName = itemArray(1)
      val partitionValue = itemArray(2)
      val hdfsPath = itemArray(3)
      val sql = s"alter table $tableName add if not exists partition($partitionName='${partitionValue}') " +
        s"location '${hdfsPath}' "
      logger.error(sql)
      sparkSession.sql(sql)
    }
  }
}
