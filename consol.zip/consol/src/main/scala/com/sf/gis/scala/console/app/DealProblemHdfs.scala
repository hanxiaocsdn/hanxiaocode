package com.sf.gis.scala.console.app

import java.net.URI
import java.util.Date

import com.alibaba.fastjson.{JSON, JSONArray}
import com.sf.gis.java.base.dto.DBInfo
import com.sf.gis.scala.base.spark.{Spark, SparkRead}
import com.sf.gis.scala.console.app.common.FsManager
import com.sf.gis.scala.console.bean.HdfsInfo.KeyValue
import com.sf.gis.scala.console.bean.{ConsoleConfig, HdfsInfo, TableTag, WarnningInfo}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer


/**
 * @ProductManager:01374443
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:441004
 * @TaskName:获取有问题的hdfs信息并且处理它
 * @Description:针对表进行检测
 * * 根据数据量大小,申请不同的资源分级做处理
 */
object DealProblemHdfs {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  val inputTableName = QueryProblematicalHdfsInfo.smalFileTable
  val smalFileDealRetTable = "dm_gis.gis_oms_small_file_deal_ret"

  val checkEmptyPartitionTable = Array("dm_gis.tel_addr_unionpay_tmp1", "dm_gis.tel_library_report_craft_res_day", "dm_gis.tel_tc_waybill_rule_inc", "dm_gis.gis_rss_eta_accident_warn", "dm_gis.road_toll_monitor_appeal_detail", "dm_gis.road_toll_plan_monitor_cover_detail", "dm_gis.aoi_info_bmms_day", "dm_gis.dm_express_delivery_exceed_ten_minutes_di", "dm_gis.order_region_detail", "dm_gis.aoi_resource_hierarchical_data_summary", "dm_gis.sx_empty_group", "dm_gis.elevator_addr_spyinfo", "dm_gis.dm_lbs_tjy_result_dtl_di", "dm_gis.order_region_aggregation", "dm_gis.elespy_group", "dm_gis.tel_tc_waybill_rule_inc_curs2", "dm_gis.gis_ass_adds_log_stat_orderno_ak", "dm_gis.fty_company_info_incre_update", "dm_gis.push_judgment_check", "dm_gis.analyze_bike_over_speed", "dm_gis.aoi_id_code_city_diff", "dm_gis.gis_pai_addr_freq_stat", "dm_gis.rds_fns_to", "dm_gis.pm_residence_profile_by_consign", "dm_gis.pm_addr_ld_feature", "dm_gis.pm_merge_phone_addr_profile", "dm_gis.xiaoge_path_distance", "dm_gis.gis_crawl_import_hbase_cell", "dm_gis.gis_rds_omsfrom_splitresult", "dm_gis.diff_log_flink", "dm_gis.tmp_xiaoge_zaigang", "dm_gis.sx_null_group", "dm_gis.dw_company_profile_by_bill_month", "dm_gis.gis_lss_core_cell_nr", "dm_gis.huishou_process_test", "dm_gis.charging_pile_waterbills", "dm_gis.dw_waybill_address_append", "dm_gis.high_freq_unreg_consname", "dm_gis.dw_comp_prof_addr_freq_by_city_top10_monthly", "dm_gis.dw_comp_prof_addr_freq_by_city_top10")
  val warningList = new java.util.HashMap[String, java.util.ArrayList[WarnningInfo]]()
  val consoleConfig = new ConsoleConfig("conf/table_consol.properties")

  def queryProblemHdfs(sparkSession: SparkSession, incDay: String, maxSize: Long, minSize: Long,
                       dataBases: Array[String]) = {
    var sql = s"select databasename,tablename,filecnt,size,partitionlist,isexternal,hdfspath,hdfshome from ${inputTableName} " +
      s" where inc_day='${incDay}' and isexisttable='true' and filecnt<>'1' and cast( size as bigint)>= ${minSize} " +
      s" and cast( size as bigint)< ${maxSize} " +
      s" and taglist ='[]' and istable='true' and ispartitiontype='true' "
    if (!dataBases.isEmpty) sql = sql + s" and databasename in ('${dataBases.mkString("','")}') "

    logger.error(sql)
    val dataList = sparkSession.sql(sql).rdd.map(obj => {
      val hdfsInfo = new HdfsInfo()
      hdfsInfo.setDatabaseName(obj.getString(0))
      hdfsInfo.setTableName(obj.getString(1))
      hdfsInfo.setPartitionList(JSON.parseArray(obj.getString(4), classOf[KeyValue]))
      hdfsInfo.setSize(obj.getString(3).toLong)
      hdfsInfo.setExternal(obj.getString(5).toBoolean)
      hdfsInfo.setFileCnt(obj.getString(2).toInt)
      var hdfsPath = obj.getString(6)
      val hdfsHome = obj.getString(7)
      if (hdfsHome.startsWith("hdfs://sfbdp1")) hdfsPath = "hdfs://sfbdp1" + hdfsPath else if (hdfsHome.startsWith("hdfs://sfbd")) hdfsPath = "hdfs://sfbd" + hdfsPath
      hdfsInfo.setHdfsPath(hdfsPath)
      hdfsInfo.setAvgSize(hdfsInfo.getSize / hdfsInfo.getFileCnt)
      hdfsInfo
    }).collect().sortBy(-_.getFileCnt)
    logger.error("等待清理的分区数量：" + dataList.length)
    dataList
  }

  def queryOneData(sparkSession: SparkSession, hdfsInfo: HdfsInfo) = {
    val partitionList = hdfsInfo.getPartitionList
    val sb = new ArrayBuffer[String]()
    for (i <- 0 until partitionList.size()) {
      val partition = partitionList.get(i)
      sb.append(partition.getKey + "='" + partition.getValue + "'")
    }

    val sql = s"select * from ${hdfsInfo.getDatabaseName}.${hdfsInfo.getTableName} where ${sb.mkString(" and ")}"
    //    logger.error(sql)
    val dataFrame = sparkSession.sql(sql)
    val columns = dataFrame.columns

    columns
  }

  def countHdfsFileCnt(obj: HdfsInfo): Int = {
    val f = FileSystem.get(URI.create(obj.getHdfsPath), new Configuration)
    val status = f.listStatus(new Path(obj.getHdfsPath))
    if (status.size == 2) status.foreach(tmpObj => {
      if (tmpObj.getPath.toString.endsWith("_SUCCESS")) {
        //          obj.setFileCnt(obj.getFileCnt-1)
        return 1
        //          if(obj.getSize/obj.getFileCnt>20971520){
        //            logger.error("success文件，剔除计算,path:"+tmpObj.getPath+",len:"+tmpObj.getLen+",剔除后平均值:"+ obj.getSize/obj.getFileCnt)
        //
        //          }
      }
    })
    status.size
  }

  def countPartition(sparkSession: SparkSession, hdfsInfo: HdfsInfo) = {
    val partitionList = hdfsInfo.getPartitionList
    val sb = new ArrayBuffer[String]()
    for (i <- 0 until partitionList.size()) {
      val partition = partitionList.get(i)
      sb.append(partition.getKey + "='" + partition.getValue + "'")
    }

    val sql = s"select count(*) from ${hdfsInfo.getDatabaseName}.${hdfsInfo.getTableName} where ${sb.mkString(" and ")}"
    //    logger.error(sql)
    val cnt = sparkSession.sql(sql).collect().take(1).map(obj => obj.getLong(0))
    cnt
  }

  def addToWaringList(userTableMap: collection.Map[String, String],
                      obj: HdfsInfo, numPartition: Int,
                      partitionContionSql: ArrayBuffer[String]) = {
    val tableName = obj.getDatabaseName + "." + obj.getTableName
    if (userTableMap.contains(tableName)) {
      logger.error("找到表所有者")
      if (obj.getAvgSize <= consoleConfig.prop.getProperty("warning_avg_size").toLong) {
        //先设置为10M
        val warnningInfo = new WarnningInfo(tableName, partitionContionSql.mkString(","), obj.getAvgSize, numPartition)
        val user = userTableMap(tableName)
        if (warningList.containsKey(user)) warningList.get(user).add(warnningInfo) else {
          val list = new java.util.ArrayList[WarnningInfo]()
          list.add(warnningInfo)
          warningList.put(user, list)
        }
      }
    }
  }

  def compressTable(obj: HdfsInfo, sparkSession: SparkSession, fileCntWrong: ArrayBuffer[String],
                    hdfsBlack: ArrayBuffer[String], emptyArray: ArrayBuffer[String],
                    userTableMap: collection.Map[String, String]): Unit = {
    if (obj.getSize == 0) {
      logger.error("大小为空，单独处理:" + obj.getHdfsPath + ";" + obj.getDatabaseName + "." + obj.getTableName)
      return
    }
    val (columnsArray) = queryOneData(sparkSession, obj)
    //    if (cnt == 0) {
    //      logger.error("hive分区数据为空")
    //      obj.getTagList.add(TableTag.partitionDiffWithHive.name())
    //      return;
    //    }
    val partitions = obj.getPartitionList
    val partitionNameSql = new ArrayBuffer[String]()
    val partitionContionSql = new ArrayBuffer[String]()
    for (i <- 0 until partitions.size) {
      val partition = partitions.get(i)
      if (!columnsArray(columnsArray.length - partitions.size + i).equals(partition.getKey)) {
        obj.getTagList.add(TableTag.partitionDiffWithHive.name())
        logger.error("分区名称和字段名没对上")
        return
      }
      partitionNameSql.append(partition.getKey)
      partitionContionSql.append(partition.getKey + "='" + partition.getValue + "'")
    }

    logger.error("检测hdfs是否更新过，比对数量")
    val fileCnt = countHdfsFileCnt(obj)
    if (fileCnt != obj.getFileCnt) {
      logger.error("数量没对上,当前数量：" + fileCnt + ",统计数量：" + obj.getFileCnt + ",hdfs:" + obj.getHdfsPath)
      fileCntWrong.append(obj.getHdfsPath)
      return
    }
    logger.error("hdfs:" + obj.getHdfsPath)
    logger.error("检测黑名单，部分hdfs是无用的野路子,是没有关联表的")
    if (obj.getHdfsPath.startsWith("hdfs://sfbd/hive/warehouse/ft/DM/dm_gis_edt/dw_adl_phone_profile_month_new/")
      || obj.getHdfsPath.startsWith("hdfs://sfbd/user/hive/warehouse/dm_gis_edt.db/dw_adl_phone_profile_month/")
      || obj.getHdfsPath.startsWith("hdfs://sfbd/user/hive/warehouse/dm_gis.db/dw_company_profile_by_bill_city/")) {
      hdfsBlack.append(obj.getHdfsPath)
      logger.error("hdfs黑名单")
      return
    }
    if (checkEmptyPartitionTable.contains(obj.getDatabaseName + "." + obj.getTableName)
      && obj.getSize < 1048576
      && countPartition(sparkSession, obj) == 0) {
      logger.error("数量为空，单独处理:" + obj.getHdfsPath + ";" + obj.getDatabaseName + "." + obj.getTableName)
      return
    }

    sparkSession.sql("set hive.exec.dynamic.partition.mode=nonstrict")
    sparkSession.sql("set hive.exec.compress.output=true")
    sparkSession.sql("set mapred.compress.map.output=true")
    sparkSession.sql("set mapred.output.compress=true")
    sparkSession.sql("set hive.exec.max.dynamic.partitions.pernode=10000")
    sparkSession.sql("set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec")
    sparkSession.sql("set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec")
    sparkSession.sql("set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec")
    sparkSession.sql("set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat")
    sparkSession.sql("set mapreduce.input.fileinputformat.split.maxsize=134217728")
    sparkSession.sql("set mapreduce.input.fileinputformat.split.minsize.per.rack=134217728")
    sparkSession.sql("set mapreduce.input.fileinputformat.split.minsize.per.node=134217728")
    sparkSession.sql("set hive.merge.mapredfiles=true")
    sparkSession.sql("set hive.merge.smallfiles.avgsize=134217728")
    sparkSession.sql("set spark.sql.adaptive.shuffle.targetPostShuffleInputSize=134217728")
    sparkSession.sql("set spark.sql.adaptive.enabled=true")
    sparkSession.sql("set hive.merge.sparkfiles=true")
    sparkSession.sql("set hive.merge.mapfiles=true")
    sparkSession.sql("set hive.merge.size.per.task=134217728")
    //    val sql = s"insert overwrite table ${obj.getDatabaseName}.${obj.getTableName} partition(${partitionNameSql.mkString(",")}) " +
    //      s" select * from ${obj.getDatabaseName}.${obj.getTableName} where ${partitionContionSql.mkString(" and ")} "
    val sql = s" select * from ${obj.getDatabaseName}.${obj.getTableName} where ${partitionContionSql.mkString(" and ")} "
    logger.error(sql)
    var tableRate = 1
    //特殊表，压缩率太高
    val rateArray=Array("gis_onsite_service_doing_info")
    if(rateArray.contains(obj.getTableName)){
      tableRate = 5
    }
    val numPartition = (obj.getSize / 1024 / 1024 / 128 + 1).toInt*tableRate
    logger.error("推荐分区数：" + numPartition)
    addToWaringList(userTableMap, obj, numPartition, partitionContionSql)

    val tmpView = obj.getTableName + System.currentTimeMillis()
    val data = sparkSession.sql(sql).repartition(numPartition).createTempView(tmpView)
    val insertSql = s"insert overwrite table ${obj.getDatabaseName}.${obj.getTableName} partition(${partitionNameSql.mkString(",")}) " +
      s" select * from ${tmpView} "
    logger.error("文件数：" + obj.getFileCnt + "," + insertSql)
    sparkSession.sql(insertSql).count()
    sparkSession.catalog.clearCache()
    obj.getTagList.add(TableTag.sucDone.name())
    logger.error("单表处理完毕")
  }

  def queryUserTableMap(sparkSession: SparkSession) = {

    val dbInfo = new DBInfo("com.mysql.jdbc.Driver", "jdbc:mysql://10.119.72.209:3306/use_for_bdp_01374443?useUnicode=true&amp;characterEncoding=utf-8", "use_for_bdp_01374443",
      "use_for_bdp_01374443@123@")
    val (dataRdd, columns) = SparkRead.readMysqlAsJson(sparkSession, dbInfo, "select `user`,tableName,dbName from bdp_table_user ")
    val dataMap = dataRdd.map(obj => {
      (obj.getString("dbName") + "." + obj.getString("tableName"), obj.getString("user"))
    }).collectAsMap()
    logger.error("表名所有者映射关系:" + dataMap.mkString(","))
    dataMap
  }

//  def sendWaringMsg(): Unit = {
//    val fsManager = new FsManager()
//    val prop = consoleConfig.prop
//    val token = fsManager.queryToken(prop.getProperty("fs.token.url"), prop.getProperty("fs.client.id"),
//      prop.getProperty("fs.client.secret"), "client_credentials"
//    )
//    for (user <- warningList.keySet()) {
//      val warningData = warningList.get(user)
//      val receiver = new JSONArray()
//      receiver.add(user)
//      fsManager.send(receiver, "丰数平台,您负责的表存在严重小文件(20M以下)问题，请在代码中写入表前做重分区(spark)或者增加合并小文件的配置(hive)-有疑问可联系01374443",
//        warningData.mkString(";"), prop.getProperty("fs.send.url"), token,
//        prop.getProperty("fs.template.code"), new Date().getTime(),null)
//      logger.error("user:" + user + ",需要修改的表分区：" + warningData.mkString(";"))
//    }
//  }

  def start(incDay: String, maxSize: Long, minSize: Long, dataBases: Array[String]): Unit = {

    val sparkSession = Spark.getSparkSession(className)
    logger.error("获取209数据库记录的表和所有者映射表")
    val userTableMap = queryUserTableMap(sparkSession)
    //    val testList = new util.ArrayList[WarnningInfo]
    //    val warnningInfo = new WarnningInfo("dm_gis.tmp","inc_day='dd'",12,1)
    //    testList.add(warnningInfo)
    //    warningList.put("01374443",testList)
    //    return sendWaringMsg()

    logger.error("获取符合总大小的hdfs")
    val dataList = queryProblemHdfs(sparkSession, incDay, maxSize, minSize, dataBases)
    logger.error("开始遍历符合总大小的hdfs")

    //    val service = Executors.newFixedThreadPool(6)
    //    val list = new java.util.ArrayList[Callable[Void]]()
    val failedArray = new ArrayBuffer[String]()
    val fileCntWrong = new ArrayBuffer[String]()
    val hdfsBlack = new ArrayBuffer[String]()
    val emptyArray = new ArrayBuffer[String]()

    var cnt = 0
    dataList.map(obj => {
      //      list.add(new Callable[Void] {
      //        override def call(): Void = {
      //          logger.error("tableName:" + obj.getDatabaseName + "," + obj.getTableName)
      try compressTable(obj, sparkSession, fileCntWrong, hdfsBlack, emptyArray, userTableMap) catch {
        case e: Exception => {
          logger.error("出异常了哟：" + obj.getHdfsPath + "," + e)
          failedArray.append(obj.getTableName)
        }
      }
      cnt = cnt + 1
      logger.error("已处理：" + cnt + ",总数:" + dataList.size)
      //          null
      //        }
      //      })
    })
    logger.error("失败的表：" + failedArray.mkString(","))
    logger.error("文件数量没对上的表：" + fileCntWrong.mkString(";"))
    logger.error("野路子黑名单中hdfs：" + hdfsBlack.mkString(";"))
    logger.error("空分区：" + emptyArray.mkString(";"))
    //    service.invokeAll(list)
    //    service.shutdown()

    //    val retRdd = sparkSession.sparkContext.parallelize(dataList).map(obj => {
    //      val tmpStr = JSON.toJSONString(obj,new SerializeConfig(true))
    //      JSON.parseObject(tmpStr)
    //    })
    //    val hdfsInfoArray = Array("hdfsPath", "databaseName", "tableName", "avgSize", "tagList", "table", "external", "partitionType", "size", "fileCnt", "relateTables", "existTable", "hivePartitionExist", "hdfsHome", "tableFormat", "compressType", "partitionList")
    //    SparkWrite.save2HiveStatic(sparkSession, retRdd.repartition(1), hdfsInfoArray, smalFileDealRetTable, Array(("inc_day", incDay)), 1)
    logger.error("丰声发送告警信息")
    //数据治理那边已经发了，这里就不发了
//    sendWaringMsg()
  }

  def main(args: Array[String]): Unit = {
    //    val hdfs="hdfs://sfbd/user/hive/warehouse/dm_gis_edt.db/dw_adl_phone_profile_month_new/date_period=202106/contact_id_mod=13"
    //    val f = FileSystem.get(URI.create(hdfs), new Configuration)
    //    logger.error(f.listStatus(new Path(hdfs)).size)
    //    return

    //表明检测的时间
    val incDay = args(0)
    val maxSize = args(1).toLong
    val minSize = args(2).toLong
    var dataBases = Array[String]()
    if (args.length > 3) dataBases = args(3).split(",")
    start(incDay, maxSize, minSize, dataBases)
  }
}


