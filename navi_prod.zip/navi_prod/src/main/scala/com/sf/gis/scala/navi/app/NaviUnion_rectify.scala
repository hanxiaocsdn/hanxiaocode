package com.sf.gis.scala.navi.app

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: (已下线，合并到表6 task_id:262325) 264942
 * @description: gis_navi_rectify_result 表7
 * @demander: 80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/2/2 11:00
 */
object NaviUnion_rectify {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val df = new DecimalFormat("0.0000")
  var isEnd = false
  var repartition = 500
  var trackquery_url1 = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrate"
  var trackquery_url2 = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/query"
  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val rectify_url2 = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val compare_track_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"
  val retTable = "dm_gis.gis_navi_rectify_result";

  //  val retTable = "tmp_dm_gis.tmp_gis_navi_rectify_result_01374443";
  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)

    //传入参数，单天任务
    unionLog(spark, args(0))

    logger.error(">>>处理完毕---------------")
  }


  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def unionLog(spark: SparkSession, date: String): Unit = {
    val inputRdd = getNaviUnion_rectifyRdd(spark, date)
    logger.error("开始处理" + date)
    parseSaveLog(spark, inputRdd, date)
  }

  def getNaviUnion_rectifyRdd(spark: SparkSession, date: String) = {

    val startDate = DateUtil.getDateStr(date, -1)
    val endDate = date

    logger.error(">>>获取" + date + "号的Navi关联rectify")
    val sql =
      s"""
         |select a.navi_id,a.navi_starttime,a.starttime_type,a.navi_endtime,a.vehicle,a.vehicle_type,a.weight,a.mload,a.length,a.axle_number,a.navi_type,b.req_time,a.inc_day,a.inc_day as inc_date from
         |(select task_id,navi_id,navi_starttime,starttime_type,navi_endtime,vehicle,vehicle_type,weight,mload,length,axle_number,navi_type,inc_day from dm_gis.gis_navi_finish_monitor where inc_day between '$startDate' and '$endDate' and status in ('1','2','3','10','13','14') and navi_starttime is not null and navi_starttime<>'' and navi_endtime is not null and navi_endtime<>'' group by task_id,navi_id,navi_starttime,starttime_type,navi_endtime,vehicle,vehicle_type,weight,mload,length,axle_number,navi_type,inc_day) a
         |left join (select task_id,navi_id,req_time from dm_gis.gis_navi_top3_parse where inc_day between '$startDate' and '$endDate' and req_time is not null and req_time<>'' group by task_id,navi_id,req_time) b on a.task_id=b.task_id and a.navi_id=b.navi_id
       """.stripMargin
    logger.error(sql)
    val (resultRdd, columns) = SparkRead.readHiveAsJson(spark, sql)

    val computeRdd = resultRdd.map(json => {
      //获取历史轨迹
      var tracks1_origin: JSONArray = null
      var req_time = ""
      var navi_endtime = ""
      val req_timel = json.getLong("req_time")
      if (req_timel != null) {
        req_time = longToTime(req_timel)
      }
      val navi_endtimel = json.getLong("navi_endtime")
      if (navi_endtimel != null) {
        navi_endtime = longToTime(navi_endtimel + 300000)
      }

      if (!StringUtils.isEmpty(req_time) && !StringUtils.isEmpty(navi_endtime)) {
        var flag = false
        val httpObject1 = accessTrackUrl1(json, req_time, navi_endtime)
        if (httpObject1 != null) {
          val result = httpObject1.getJSONObject("result")
          if (result != null) {
            val data = result.getJSONObject("data")
            if (data != null) {
              val track = data.getJSONArray("track")
              if (track != null && track.size() > 0) {
                flag = true
                tracks1_origin = data.getJSONArray("track")
              }
            }
          }
        }
        if (!flag) {
          val httpObject2 = accessTrackUrl2(json, req_time, navi_endtime)
          if (httpObject2 != null) {
            val result = httpObject2.getJSONObject("result")
            if (result != null) {
              val data = result.getJSONObject("data")
              if (data != null) {
                tracks1_origin = data.getJSONArray("track")
              }
            }
          }
        }
      }

      var tracks1: JSONArray = new JSONArray()
      val tracks1_new = new JSONArray()
      if (tracks1_origin != null && tracks1_origin.size() > 0) {
        for (i <- 0.until(tracks1_origin.size())) {
          val tempJson = tracks1_origin.getJSONObject(i)
          val newJson1 = new JSONObject()
          val newJson2 = new JSONObject()
          if (tempJson != null) {
            val tp = tempJson.getInteger("tp")
            val x = tempJson.getDouble("zx")
            val y = tempJson.getDouble("zy")
            val ac = tempJson.getInteger("ac")
            val sp = tempJson.getDouble("sp")
            val be = tempJson.getDouble("be")
            val tm = tempJson.getInteger("tm")

            if (tp != null) newJson1.put("type", tp)
            if (x != null) newJson1.put("x", x)
            if (y != null) newJson1.put("y", y)
            if (ac != null) newJson1.put("accuracy", ac)
            if (sp != null) newJson1.put("speed", sp)
            if (be != null) newJson1.put("azimuth", be)
            if (tm != null) newJson1.put("time", tm)

            if (x != null) newJson2.put("x", x)
            if (y != null) newJson2.put("y", y)
            if (tm != null) newJson2.put("tm", tm)
          }

          newJson1.put("index", i)
          tracks1.add(newJson1)
          tracks1_new.add(newJson2)
        }
      }

      var tracks2_new = new ArrayBuffer[JSONObject]()
      val stayList = new JSONArray()
      var offTimeRatio = ""
      var len = ""
      var ret = ""

      var result: JSONObject = null
      if ("gdwl".equalsIgnoreCase(json.getString("navi_type"))) {
        result = accessRectifyUrl(json, tracks1)
      }
      else {
        result = accessRectifyUrl2(json, tracks1)
      }
      if (result != null) {
        val status = result.getInteger("status")
        val resultObject = result.getJSONObject("result")
        if (resultObject != null) {
          val tracks2 = resultObject.getJSONArray("tracks")
          val stay_points = resultObject.getJSONArray("stay_points")
          offTimeRatio = resultObject.getString("offTimeRatio")
          len = resultObject.getString("len")
          ret = resultObject.getString("ret")
          if (tracks2 != null && tracks2.size() > 0) {
            for (i <- 0.until(tracks2.size())) {
              val track = tracks2.getJSONObject(i)
              if (track != null) {
                val newJson = new JSONObject()
                val x = track.getString("x")
                val y = track.getString("y")
                val tm = track.getString("time")
                val sum_dist = track.getString("sum_dist")
                val swid = track.getString("SWID")

                newJson.put("x", x)
                newJson.put("y", y)
                newJson.put("tm", tm)
                newJson.put("sum_dist", sum_dist)
                newJson.put("swid", swid)
                tracks2_new += newJson
              }
            }
          }
          if (stay_points != null && tracks2 != null) {
            if (stay_points.size() > 0) {
              for (i <- 0.until(stay_points.size())) {
                val stay_point = stay_points.getJSONObject(i)
                if (stay_point != null) {
                  val start_index = stay_point.getInteger("start_index")
                  val end_index = stay_point.getInteger("end_index")
                  val pois = stay_point.getJSONArray("pois")

                  val duration = stay_point.getString("duration")
                  var stayStartTime = ""
                  var stayStartLongitude = ""
                  var stayStartLatitude = ""
                  var stayEndTime = ""
                  var stayEndLongitude = ""
                  var stayEndLatitude = ""
                  var stayType = ""

                  if (start_index != null && start_index < tracks2.size()) {
                    val track = tracks2.getJSONObject(start_index)
                    if (track != null) {
                      stayStartTime = track.getString("time")
                      stayStartLongitude = track.getString("x")
                      stayStartLatitude = track.getString("y")
                    }
                  }

                  if (end_index != null && end_index < tracks2.size()) {
                    val track = tracks2.getJSONObject(end_index)
                    if (track != null) {
                      stayEndTime = track.getString("time")
                      stayEndLongitude = track.getString("x")
                      stayEndLatitude = track.getString("y")
                    }
                  }

                  if (pois != null && pois.size() > 0) {
                    val all_poi_types = new ArrayBuffer[String]()
                    breakable(
                      for (j <- 0.until(pois.size())) {
                        val poi = pois.getJSONObject(j)
                        if (poi != null) {
                          val _type = poi.getString("type")
                          if ("1".equalsIgnoreCase(_type) || "5".equalsIgnoreCase(_type)) {
                            stayType = "3"
                            break
                          }
                          if (!StringUtils.isEmpty(_type)) all_poi_types += _type
                        }
                      }
                    )
                    if (StringUtils.isEmpty(stayType)) {
                      val all_types = all_poi_types.toSet
                      if (all_types.contains("3")) stayType = "1"
                      else if (all_types.contains("2")) stayType = "2"
                      else stayType = "4"
                    }
                  }

                  val newJson = new JSONObject()
                  newJson.put("duration", duration)
                  newJson.put("stayStartTime", stayStartTime)
                  newJson.put("stayStartLongitude", stayStartLongitude)
                  newJson.put("stayStartLatitude", stayStartLatitude)
                  newJson.put("stayEndTime", stayEndTime)
                  newJson.put("stayEndLongitude", stayEndLongitude)
                  newJson.put("stayEndLatitude", stayEndLatitude)
                  newJson.put("stayType", stayType)

                  stayList.add(newJson)

                }
              }
            }
          }
        }
        //          }
      }

      if (tracks1_new.size() > 0) json.put("tracks1", tracks1_new)
      if (tracks2_new.nonEmpty) {
        val tracks2_new2 = new JSONArray()
        val temp = tracks2_new.sortBy(j => j.getLong("tm"))
        temp.toList.foreach(j => {
          tracks2_new2.add(j)
        })
        json.put("tracks2", tracks2_new2)
      }
      json.put("offtime_ratio", offTimeRatio)
      if (stayList.size() > 0) json.put("stay_list", stayList)
      json.put("len", len)
      json.put("ret", ret)

      json
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error(">>>计算后日志量：" + computeRdd.count())
    resultRdd.unpersist()
    computeRdd
  }

  /**
   * 解析日志主流程
   */
  def parseSaveLog(spark: SparkSession, etaComputeRdd: RDD[JSONObject], date: String): Unit = {
    if (etaComputeRdd != null) {
      val keys = Array("navi_id", "vehicle", "vehicle_type", "weight", "mload", "length", "axle_number", "navi_starttime", "navi_endtime", "tracks1", "tracks2", "offtime_ratio", "stay_list", "len", "ret", "starttime_type")
      SparkWrite.save2HiveStaticRandom(spark, etaComputeRdd, keys, retTable, Array(("inc_day", date)), 200)
      etaComputeRdd.unpersist()
    }
  }

  /**
   * 访问比较轨迹接口
   *
   * @param json
   * @param tracks
   * @return
   */
  def accessRectifyUrl(json: JSONObject, tracks: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("vehicle", vehicle_type)
    param.put("retflag", 7)
    param.put("addpoint", 1)
    param.put("poiinfo", 1)
    param.put("tracks", tracks)

    val vehicleInfo = new JSONObject()
    val mload = json.getString("mload")
    if (!StringUtils.isEmpty(mload)) vehicleInfo.put("load", mload)
    val axle_number = json.getString("axle_number")
    if (!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis", axle_number)
    val weight = json.getDouble("weight")
    if (weight != null) vehicleInfo.put("weight", weight)
    val length = json.getDouble("length")
    if (length != null) vehicleInfo.put("length", length)

    param.put("vehicleInfo", vehicleInfo)
    param.put("roadinfo", 1)
    param.put("mat_ratio", 1)

    val process = new JSONObject()
    process.put("stay_time", 180)
    process.put("poi_range", 500)

    param.put("process", process)

    println("参数：" + param.toString)
    http_result = HttpClientUtil.getJsonByPostJson(rectify_url, param.toString)
    //println("返回："+http_result.toString)
    //    Thread.sleep(600)
    //      println("轨迹对比结果："+http_result)
    //    } catch {
    //      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
    //    }
    http_result
  }

  def accessTrackUrl1(json: JSONObject, req_time: String, navi_endtime: String): JSONObject = {
    var http_result: JSONObject = null
    val param = new JSONObject()
    param.put("un", json.getString("vehicle"))
    if (req_time != null) param.put("beginDateTime", req_time.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    if (navi_endtime != null) param.put("endDateTime", navi_endtime.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    param.put("type", 0)
    param.put("rectify", false)
    param.put("ak", "e640de2b47394b19862ee134d817bbc7")
    param.put("hasRate", true)
    //    println("-------------json-------" + json)
    http_result = HttpClientUtil.getJsonByPostJson(trackquery_url1, param.toString)
    //    Thread.sleep(3000)
    http_result
  }

  def accessTrackUrl2(json: JSONObject, req_time: String, navi_endtime: String): JSONObject = {
    var http_result: JSONObject = null
    val param = new JSONObject()
    param.put("un", json.getString("vehicle"))
    if (req_time != null) param.put("beginDateTime", req_time.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    if (navi_endtime != null) param.put("endDateTime", navi_endtime.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""))
    param.put("type", 400)
    param.put("rectify", false)
    param.put("ak", "e640de2b47394b19862ee134d817bbc7")
    param.put("hasRate", true)
    //    println("-------------json-------" + json)
    http_result = HttpClientUtil.getJsonByPostJson(trackquery_url2, param.toString)
    //    Thread.sleep(3000)
    http_result
  }


  def accessRectifyUrl2(json: JSONObject, tracks: JSONArray): JSONObject = {
    var http_result: JSONObject = null
    //    try {
    var vehicle_type = 6
    if (json.getInteger("vehicle_type") != null) vehicle_type = json.getInteger("vehicle_type")
    val param = new JSONObject()
    param.put("ak", "d9c28a860af34836973480542dc11d83")
    param.put("vehicle", vehicle_type)
    param.put("retflag", 7)
    param.put("addpoint", 1)
    param.put("poiinfo", 1)
    param.put("tracks", tracks)

    val vehicleInfo = new JSONObject()
    val mload = json.getString("mload")
    if (!StringUtils.isEmpty(mload)) vehicleInfo.put("load", mload)
    val axle_number = json.getString("axle_number")
    if (!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis", axle_number)
    val weight = json.getDouble("weight")
    if (weight != null) vehicleInfo.put("weight", weight)
    val length = json.getDouble("length")
    if (length != null) vehicleInfo.put("length", length)

    param.put("vehicleInfo", vehicleInfo)
    param.put("roadinfo", 1)
    param.put("mat_ratio", 1)

    val process = new JSONObject()
    process.put("stay_time", 180)
    process.put("poi_range", 500)

    param.put("process", process)

    println("参数：" + param.toString)
    http_result = HttpClientUtil.getJsonByPostJson(rectify_url2, param.toString)
    //println("返回："+http_result.toString)
    //    Thread.sleep(600)
    //      println("轨迹对比结果："+http_result)
    //    } catch {
    //      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
    //    }
    http_result
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss"): String = {
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }
}
