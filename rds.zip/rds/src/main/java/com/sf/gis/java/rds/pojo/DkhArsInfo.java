package com.sf.gis.java.rds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DkhArsInfo implements Serializable {
    @Column(name = "address")
    private String address;
    @Column(name = "src")
    private String src;
    @Column(name = "province")
    private String province;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "city")
    private String city;
    @Column(name = "county")
    private String county;
    @Column(name = "town")
    private String town;
    @Column(name = "village")
    private String village;
    @Column(name = "detail_info")
    private String detailInfo;
    @Column(name = "key")
    private String key;
    @Column(name = "inc_day")
    private String incDay;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getDetailInfo() {
        return detailInfo;
    }

    public void setDetailInfo(String detailInfo) {
        this.detailInfo = detailInfo;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "DkhArsInfo{" +
                "address='" + address + '\'' +
                ", src='" + src + '\'' +
                ", province='" + province + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", town='" + town + '\'' +
                ", village='" + village + '\'' +
                ", detailInfo='" + detailInfo + '\'' +
                ", key='" + key + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
