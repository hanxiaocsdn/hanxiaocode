package com.sf.gis.java.rds.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.rds.pojo.AoiChanged;
import com.sf.gis.java.rds.pojo.AoiChangedWb;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Row;

import java.util.List;

/**
 * aoi变更运单分析
 * 任务名称：819307
 * @author 01370539 YY
 * created on Oct.23
 */
public class AoiChangedWbService {

    public JavaRDD<AoiChangedWb> loadWbPuAddr(SparkInfo si, String wbStartDate, String wbEndDate, String city, String aoiIncDay) {
        String sql = "select wb.waybill_no, wb.province, wb.city_code, wb.city_name, wb.county, wb.comp_name, wb.phone, wb.cont_name, wb.mobile, wb.addr, wb.fm_acct_code, wb.zc, wb.aoi_id, " +
                "wb.aoi_code, wb.aoi_zc, aoi.aoi_id new_aoi_id, wb.inc_day from (select waybill_no, src_province province, src_dist_code city_code, src_city_code city_name, src_county county, " +
                "consignor_comp_name comp_name, consignor_phone phone, consignor_cont_name cont_name, consignor_mobile mobile, consignor_addr addr, freight_monthly_acct_code fm_acct_code, source_zone_code zc, " +
                "aoi_id, aoi_code, aoi_zc, inc_day from dm_gis.tt_order_hook where inc_day between '" + wbStartDate + "' and '" + wbEndDate + "' and src_dist_code = '" + city + "' and consignor_addr is not null and consignor_addr != '') wb " +
                "left join (select aoi_id from dm_gis.dwb_aoi_change_info_df where inc_day = '" + aoiIncDay + "' and is_changed = 'N') aoi on wb.aoi_id = aoi.aoi_id ";
        return DataUtil.loadData(si, sql, AoiChangedWb.class);
    }

    public JavaRDD<AoiChangedWb> loadWbPuChanged(SparkInfo si, String incDay) {
        String sql = "select wb.waybill_no, wb.province, wb.city_code, wb.city_name, wb.county, wb.comp_name, wb.phone, wb.cont_name, wb.mobile, wb.addr, wb.fm_acct_code, " +
                "wb.zc, wb.aoi_id, wb.aoi_code, wb.aoi_zc, aoi.new_zc, aoi.new_zc_src, aoi.new_aoi_id, aoi.new_aoi_code, aoi.new_aoi_src from " +
                "(select * from dm_gis.dwb_wb_aoi_changed_pu_mi where inc_day = '" + incDay + "') wb left join " +
                "(select * from (select *, ROW_NUMBER() OVER(PARTITION BY province, city_code, county, addr, comp_name, phone, cont_name, mobile, fm_acct_code ORDER BY new_aoi_id desc) AS rn " +
                "from dm_gis.dwb_wb_aoi_changed_pu_atsh_cache where inc_day = '" + incDay + "') tmpRn where tmpRn.rn = 1) aoi on wb.province = aoi.province and wb.city_code = aoi.city_code " +
                "and wb.county = aoi.county and wb.addr = aoi.addr and wb.comp_name = aoi.comp_name and wb.phone = aoi.phone and wb.cont_name = aoi.cont_name and wb.mobile = aoi.mobile and wb.fm_acct_code = aoi.fm_acct_code";
        return DataUtil.loadData(si, sql, AoiChangedWb.class);
    }

    public List<String> loadAtShouPartitions(SparkInfo si, String incDay) {
        String sql = "select distinct(inc_day) from dm_gis.dwb_wb_aoi_changed_pu_atsh_mi where inc_day like '" + incDay + "%'";
        List<String> partitions = DataUtil.loadData(si.getSession(), sql).map(o -> {
            return o.getString(0);
        }).collect();
        return partitions;
    }

    public JavaRDD<AoiChangedWb> loadAtshou(SparkInfo si, String incDay) {
        String sql = "select * from dm_gis.dwb_wb_aoi_changed_pu_atsh_mi where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, AoiChangedWb.class);
    }

    public JavaRDD<AoiChangedWb> loadKsCache(SparkInfo si, String incDay) {
        String sql = "select * from dm_gis.dwb_wb_aoi_changed_pu_ks_cache where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, AoiChangedWb.class);
    }

    public List<String> loadKsPartitions(SparkInfo si, String incDay) {
        String sql = "select distinct(inc_day) from dm_gis.dwb_wb_aoi_changed_pu_ks_mi where inc_day like '" + incDay + "%'";
        List<String> partitions = DataUtil.loadData(si.getSession(), sql).map(o -> {
            return o.getString(0);
        }).collect();
        return partitions;
    }

    public List<String> loadKsCachePartitions(SparkInfo si, String incDay) {
        String sql = "select distinct(inc_day) from dm_gis.dwb_wb_aoi_changed_pu_ks_cache where inc_day like '" + incDay + "%'";
        List<String> partitions = DataUtil.loadData(si.getSession(), sql).map(o -> {
            return o.getString(0);
        }).collect();
        return partitions;
    }

    public JavaRDD<AoiChanged> loadChangedAoi(SparkInfo si, String startDate, String endDate) {
        String incDay = DateUtil.formatDate(startDate, "yyyy-MM-dd", "yyyyMMdd");
        String sql = "select t.aoi_id from (" +
                "select aoi_id from dm_gis.cms_aoi_change where inc_day >= '" + incDay + "' and oper_type ='I' and date_format(update_date, 'yyyy-MM-dd') <= '" + endDate + "' and date_format(update_date, 'yyyy-MM-dd') >= '" + startDate + "' " +
                "union " +
                "select aoi_id from dm_gis.cms_aoi_change where inc_day >= '" + incDay + "' and oper_type ='D' and date_format(update_date, 'yyyy-MM-dd') <= '" + endDate + "' and date_format(update_date, 'yyyy-MM-dd') >= '" + startDate + "' " +
                "union " +
                "select aoi_id from dm_gis.cms_aoi_change where inc_day >= '" + incDay + "' and oper_type ='U' and get_json_object(data,'$.oldAoi.wkt') != get_json_object(data,'$.newAoi.wkt') and date_format(update_date, 'yyyy-MM-dd') <= '" + endDate + "' and date_format(update_date, 'yyyy-MM-dd') >= '" + startDate + "') t";
        return DataUtil.loadData(si, sql, AoiChanged.class);
    }

    public JavaRDD<AoiChanged> loadAoi(SparkInfo si) {
        String incDay = DateUtil.getDayBefore(DateUtil.getCurrentDate(), "yyyyMMdd", 1);
        String sql = "select distinct(aoi_id) aoi_id from dm_gis.cms_aoi where inc_day = '" + incDay + "' and del_flag = 0";
        return DataUtil.loadData(si, sql, AoiChanged.class);
    }
}
