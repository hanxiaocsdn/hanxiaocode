package com.sf.gis.java.rds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DkhRdsInfo implements Serializable {
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "detail_addr")
    private String detailAddr;
    @Column(name = "addr")
    private String addr;
    @Column(name = "aoi_80xy")
    private String aoi80xy;
    @Column(name = "phone")
    private String phone;
    @Column(name = "comp_name")
    private String compName;
    @Column(name = "ttl_cnt")
    private String ttlCnt;
    @Column(name = "ttl_freight")
    private String ttlFreight;
    @Column(name = "cnt")
    private String cnt;
    @Column(name = "freight")
    private String freight;
    @Column(name = "zc")
    private String zc;
    @Column(name = "zc_src")
    private String zcSrc;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_code")
    private String aoiCode;
    @Column(name = "aoi_src")
    private String aoiSrc;
    @Column(name = "aoi_unit")
    private String aoiUnit;
    @Column(name = "group_id")
    private String groupId;
    @Column(name = "inc_day")
    private String incDay;

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getDetailAddr() {
        return detailAddr;
    }

    public void setDetailAddr(String detailAddr) {
        this.detailAddr = detailAddr;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getAoi80xy() {
        return aoi80xy;
    }

    public void setAoi80xy(String aoi80xy) {
        this.aoi80xy = aoi80xy;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getTtlCnt() {
        return ttlCnt;
    }

    public void setTtlCnt(String ttlCnt) {
        this.ttlCnt = ttlCnt;
    }

    public String getTtlFreight() {
        return ttlFreight;
    }

    public void setTtlFreight(String ttlFreight) {
        this.ttlFreight = ttlFreight;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public String getFreight() {
        return freight;
    }

    public void setFreight(String freight) {
        this.freight = freight;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getZcSrc() {
        return zcSrc;
    }

    public void setZcSrc(String zcSrc) {
        this.zcSrc = zcSrc;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiSrc() {
        return aoiSrc;
    }

    public void setAoiSrc(String aoiSrc) {
        this.aoiSrc = aoiSrc;
    }

    public String getAoiUnit() {
        return aoiUnit;
    }

    public void setAoiUnit(String aoiUnit) {
        this.aoiUnit = aoiUnit;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "AddrAzInfo{" +
                "cityCode='" + cityCode + '\'' +
                ", detailAddr='" + detailAddr + '\'' +
                ", addr='" + addr + '\'' +
                ", aoi80xy='" + aoi80xy + '\'' +
                ", phone='" + phone + '\'' +
                ", compName='" + compName + '\'' +
                ", ttlCnt='" + ttlCnt + '\'' +
                ", ttlFreight='" + ttlFreight + '\'' +
                ", cnt='" + cnt + '\'' +
                ", freight='" + freight + '\'' +
                ", zc='" + zc + '\'' +
                ", zcSrc='" + zcSrc + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiCode='" + aoiCode + '\'' +
                ", aoiSrc='" + aoiSrc + '\'' +
                ", aoiUnit='" + aoiUnit + '\'' +
                ", groupId='" + groupId + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
