package com.sf.gis.java.rds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AddrPojo implements Serializable {
    @Column(name = "addr")
    private String addr;
    @Column(name = "addr_type")
    private String addrType;
    @Column(name = "cnt")
    private String cnt;
    @Column(name = "freight_rmb")
    private String freightRmb;
    @Column(name = "is_hit_bsp")
    private String isHitBsp;
    @Column(name = "inc_day")
    private String incDay;

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getAddrType() {
        return addrType;
    }

    public void setAddrType(String addrType) {
        this.addrType = addrType;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public String getFreightRmb() {
        return freightRmb;
    }

    public void setFreightRmb(String freightRmb) {
        this.freightRmb = freightRmb;
    }

    public String getIsHitBsp() {
        return isHitBsp;
    }

    public void setIsHitBsp(String isHitBsp) {
        this.isHitBsp = isHitBsp;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "AddrPojo{" +
                "addr='" + addr + '\'' +
                ", addrType='" + addrType + '\'' +
                ", cnt='" + cnt + '\'' +
                ", freightRmb='" + freightRmb + '\'' +
                ", isHitBsp='" + isHitBsp + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
