package com.sf.gis.java.rds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DkhInfo implements Serializable {
    @Column(name = "province")
    private String province;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "city_name")
    private String cityName;
    @Column(name = "county")
    private String county;
    @Column(name = "addr")
    private String addr;
    @Column(name = "fm_acct_code")
    private String fmAcctCode;   // 月结账号
    @Column(name = "fp_type_code")
    private String fpTypeCode;    // 付款方式
    @Column(name = "fs_type_code")
    private String fsTypeCode;   // 运费结算类型
    @Column(name = "fp_change_type_code")
    private String fpChangeTypeCode;   // 付款方式是否改变
    @Column(name = "cnt")
    private String cnt;
    @Column(name = "freight")
    private String freight;
    @Column(name = "is_bsp")
    private String isBsp;
    @Column(name = "is_wb_pu")
    private String isWbPu;
    @Column(name = "is_wb_dlv")
    private String isWbDlv;
    @Column(name = "is_log")
    private String is_log;
    @Column(name = "is_ars_use")
    private String isArsUse;
    @Column(name = "is_seg_use")
    private String isSegUse;
    @Column(name = "is_rds_use")
    private String isRdsUse;
    @Column(name = "is_diff_use")
    private String isDiffUse;
    @Column(name = "is_ads_use")
    private String isAdsUse;
    @Column(name = "inc_day")
    private String incDay;

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getFmAcctCode() {
        return fmAcctCode;
    }

    public void setFmAcctCode(String fmAcctCode) {
        this.fmAcctCode = fmAcctCode;
    }

    public String getFpTypeCode() {
        return fpTypeCode;
    }

    public void setFpTypeCode(String fpTypeCode) {
        this.fpTypeCode = fpTypeCode;
    }

    public String getFsTypeCode() {
        return fsTypeCode;
    }

    public void setFsTypeCode(String fsTypeCode) {
        this.fsTypeCode = fsTypeCode;
    }

    public String getFpChangeTypeCode() {
        return fpChangeTypeCode;
    }

    public void setFpChangeTypeCode(String fpChangeTypeCode) {
        this.fpChangeTypeCode = fpChangeTypeCode;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public String getFreight() {
        return freight;
    }

    public void setFreight(String freight) {
        this.freight = freight;
    }

    public String getIsBsp() {
        return isBsp;
    }

    public void setIsBsp(String isBsp) {
        this.isBsp = isBsp;
    }

    public String getIsWbPu() {
        return isWbPu;
    }

    public void setIsWbPu(String isWbPu) {
        this.isWbPu = isWbPu;
    }

    public String getIsWbDlv() {
        return isWbDlv;
    }

    public void setIsWbDlv(String isWbDlv) {
        this.isWbDlv = isWbDlv;
    }

    public String getIs_log() {
        return is_log;
    }

    public void setIs_log(String is_log) {
        this.is_log = is_log;
    }

    public String getIsArsUse() {
        return isArsUse;
    }

    public void setIsArsUse(String isArsUse) {
        this.isArsUse = isArsUse;
    }

    public String getIsSegUse() {
        return isSegUse;
    }

    public void setIsSegUse(String isSegUse) {
        this.isSegUse = isSegUse;
    }

    public String getIsRdsUse() {
        return isRdsUse;
    }

    public void setIsRdsUse(String isRdsUse) {
        this.isRdsUse = isRdsUse;
    }

    public String getIsDiffUse() {
        return isDiffUse;
    }

    public void setIsDiffUse(String isDiffUse) {
        this.isDiffUse = isDiffUse;
    }

    public String getIsAdsUse() {
        return isAdsUse;
    }

    public void setIsAdsUse(String isAdsUse) {
        this.isAdsUse = isAdsUse;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "DkhInfo{" +
                "province='" + province + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", cityName='" + cityName + '\'' +
                ", county='" + county + '\'' +
                ", addr='" + addr + '\'' +
                ", fmAcctCode='" + fmAcctCode + '\'' +
                ", fpTypeCode='" + fpTypeCode + '\'' +
                ", fsTypeCode='" + fsTypeCode + '\'' +
                ", fpChangeTypeCode='" + fpChangeTypeCode + '\'' +
                ", cnt='" + cnt + '\'' +
                ", freight='" + freight + '\'' +
                ", isBsp='" + isBsp + '\'' +
                ", isWbPu='" + isWbPu + '\'' +
                ", isWbDlv='" + isWbDlv + '\'' +
                ", is_log='" + is_log + '\'' +
                ", isArsUse='" + isArsUse + '\'' +
                ", isSegUse='" + isSegUse + '\'' +
                ", isRdsUse='" + isRdsUse + '\'' +
                ", isDiffUse='" + isDiffUse + '\'' +
                ", isAdsUse='" + isAdsUse + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
