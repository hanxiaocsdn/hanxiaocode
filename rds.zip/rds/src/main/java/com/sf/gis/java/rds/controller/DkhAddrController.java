package com.sf.gis.java.rds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.api.AddrApi;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.AddrInfo;
import com.sf.gis.java.base.dto.ArApiIn;
import com.sf.gis.java.base.dto.AtdispatchApiIn;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.rds.common.DkhConstant;
import com.sf.gis.java.rds.pojo.*;
import com.sf.gis.java.rds.service.DkhAddrService;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 大客户地址数据挖掘
 * @author 01370539 YY
 * Created on Oct.25
 */
public class DkhAddrController {
    private static final Logger logger = LoggerFactory.getLogger(DkhAddrController.class);

    private static final DkhAddrService daSvc = new DkhAddrService();

    /**
     * 单纯按照统计地址的月度累计频次和累计运费金额，属于基础统计
     * 任务ID：915501
     * 任务名称：大客户地址库基础统计-月度统计
     * 使用人：金姣（用于地址可达项目），郭本婕（路由分单大客户地址库使用了其和BSP的碰撞结果）
     */
    public void statAddrByMonth(int backCnt) {
        logger.error("start statWbByMonth: backCnt - {}", backCnt);
        SparkInfo si = SparkUtil.getSpark(DkhAddrController.class.getName());

        JavaPairRDD<String, Integer> bspRdd = daSvc.loadBspData(si).mapToPair(o -> new Tuple2<>(o.getAddress(), 1)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("bsp data count: {}", bspRdd.count());
        bspRdd.take(3).forEach(o -> logger.error("bspRdd -> {}", o._1));

        String curMonth = DateUtil.getCurrentDate("yyyyMM");
        for (int i = backCnt; i > 0; i--) {
            String calMonth = DateUtil.getMonthBefore(curMonth, "yyyyMM", i);
            logger.error("start cal mont: {}", calMonth);

            JavaRDD<AddrPojo> rddDlv = daSvc.statDlvByMonth(si, calMonth).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("派件地址数量：{}", rddDlv.count());
            rddDlv.take(3).forEach(o -> logger.error("rddDlv -> {}", o.toString()));

            JavaRDD<AddrPojo> rddDlvBsp = hitBsp(rddDlv, bspRdd);
            rddDlv.unpersist();

            JavaRDD<AddrPojo> rddPu = daSvc.statPuByMonth(si, calMonth).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("收件地址数量：{}", rddPu.count());
            rddPu.take(3).forEach(o -> logger.error("rddPu -> {}", o.toString()));

            JavaRDD<AddrPojo> rddPuBsp = hitBsp(rddPu, bspRdd);
            rddPu.unpersist();

            DataUtil.saveOverwrite(si, "dm_gis.dwd_dkh_addr_stat_mi", AddrPojo.class, rddDlvBsp.union(rddPuBsp), "inc_day");
            rddDlvBsp.unpersist();
            rddPuBsp.unpersist();
        }
        logger.error("end statWbByMonth: backCnt - {}", backCnt);
    }

    /**
     * 任务ID：913508
     * 任务名称：地址可达大客户地址库结果生成
     * 使用人：金姣
     */
    public void initArsDkh(int threadCnt) {
        logger.error("start initArsDkh: threadCnt - {}", threadCnt);
        SparkInfo si = SparkUtil.getSpark(DkhAddrController.class.getName());

        JavaRDD<DkhArsInfo> rddBsp = daSvc.loadBspData(si).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("bsp data count: {}", rddBsp.count());
        rddBsp.take(3).forEach(o -> logger.error("bspRdd -> {}", o.toString()));

        String month = DateUtil.getCurrentDate("yyyyMM");
        String startMonth = DateUtil.getMonthBefore(month, "yyyyMM", 12);
        String endMonth = DateUtil.getMonthBefore(month, "yyyyMM", 1);
        String dkhIncDay = DateUtil.getMonthBefore(month, "yyyyMM", 2);

        JavaRDD<DkhArsInfo> rddStat = daSvc.getInitAddr4Ars(si, startMonth, endMonth).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("统计到的地址数量：{}", rddStat.count());
        rddStat.take(3).forEach(o -> logger.error("rddStat - {}", o.toString()));

        JavaRDD<DkhArsInfo> rddBoth = rddStat.union(rddBsp).mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> {
            if (o1.getSrc().startsWith("stat")) {
                o1.setSrc(o1.getSrc().replace("stat", "both"));
                return o1;
            } else {
                o2.setSrc(o2.getSrc().replace("stat", "both"));
                return o2;
            }
        }).map(o -> o._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        long invokeCnt = rddBoth.count();
        logger.error("BSP和挖掘到的地址总量：{}", invokeCnt);
        logger.error("{} 量：{}", DkhConstant.ARS_DKH_ADDR_TYPE_BSP, rddBoth.filter(o -> DkhConstant.ARS_DKH_ADDR_TYPE_BSP.equals(o.getSrc())).count());
        logger.error("{} 量：{}", DkhConstant.ARS_DKH_ADDR_TYPE_STAT_FREIGHT, rddBoth.filter(o -> DkhConstant.ARS_DKH_ADDR_TYPE_STAT_FREIGHT.equals(o.getSrc())).count());
        logger.error("{} 量：{}", DkhConstant.ARS_DKH_ADDR_TYPE_STAT_NUM, rddBoth.filter(o -> DkhConstant.ARS_DKH_ADDR_TYPE_STAT_NUM.equals(o.getSrc())).count());
        logger.error("{} 量：{}", DkhConstant.ARS_DKH_ADDR_TYPE_STAT_BOTH, rddBoth.filter(o -> DkhConstant.ARS_DKH_ADDR_TYPE_STAT_BOTH.equals(o.getSrc())).count());
        logger.error("{} 量：{}", DkhConstant.ARS_DKH_ADDR_TYPE_BOTH_FREIGHT, rddBoth.filter(o -> DkhConstant.ARS_DKH_ADDR_TYPE_BOTH_FREIGHT.equals(o.getSrc())).count());
        logger.error("{} 量：{}", DkhConstant.ARS_DKH_ADDR_TYPE_BOTH_NUM, rddBoth.filter(o -> DkhConstant.ARS_DKH_ADDR_TYPE_BOTH_NUM.equals(o.getSrc())).count());
        logger.error("{} 量：{}", DkhConstant.ARS_DKH_ADDR_TYPE_BOTH_BOTH, rddBoth.filter(o -> DkhConstant.ARS_DKH_ADDR_TYPE_BOTH_BOTH.equals(o.getSrc())).count());
        rddBsp.unpersist();
        rddStat.unpersist();

        JavaRDD<DkhArsInfo> rddDkh = daSvc.getArsDkh(si, dkhIncDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("{} 地址库地址数量为：{}", dkhIncDay, rddDkh.count());
        rddDkh.take(3).forEach(o -> logger.error("rdsDkh - {}", o.toString()));

        JavaRDD<DkhArsInfo> rddHookLast = rddBoth.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).leftOuterJoin(rddDkh.mapToPair(o -> new Tuple2<>(o.getAddress(),o))).map(o -> {
            DkhArsInfo dai;
            if (o._2._2.isPresent()) {
                dai = o._2._2.get();
            } else {
                dai = o._2._1;
            }
            dai.setSrc(o._2._1.getSrc());
            dai.setIncDay(endMonth);
            return dai;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("挂接初始化地址库结果后地址数量为：{}", rddHookLast.count());
        rddHookLast.take(3).forEach(o -> logger.error("rddHookLast - {}", o.toString()));
        rddBoth.unpersist();
        rddDkh.unpersist();

        JavaRDD<DkhArsInfo> rddExistRs = rddHookLast.filter(o -> StringUtils.isNotEmpty(o.getProvince())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("地址库已初始化的数量为：{}", rddExistRs.count());
        rddExistRs.take(3).forEach(o -> logger.error("rddExistRs - {}", o.toString()));

        JavaRDD<DkhArsInfo> rddNoneRs = rddHookLast.filter(o -> StringUtils.isEmpty(o.getProvince())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("地址库库未初始化的数量为：{}", rddNoneRs.count());
        rddNoneRs.take(3).forEach(o -> logger.error("rddNoneRs - {}", o.toString()));
        rddHookLast.unpersist();

        String ak = "281d0c93711f4db1a1c0255e25424cd8";
        String httpArInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(),"01370539", "915593", "地址可达大客户地址库结果生成", "大客户地址库", HttpConstant.HTTP_URL_AR_API, ak, invokeCnt, threadCnt);

        JavaRDD<DkhArsInfo> rddNoneRsGet = rddNoneRs.repartition(threadCnt).map(o -> {
            ArApiIn aaiParam = new ArApiIn();
            aaiParam.setAk(ak);
            aaiParam.setExtention("1");
            aaiParam.setAddress(URLEncoder.encode(StrUtils.processInvalidCharacter(o.getAddress()), FixedConstant.CHARSET_UTF));
            AddrInfo arRs = AddrApi.arApi(aaiParam);
            o.setProvince(arRs.getProvince());
            o.setCityCode(arRs.getCityCode());
            o.setCity(arRs.getCity());
            o.setCounty(arRs.getCounty());
            o.setTown(arRs.getTown());
            o.setVillage(arRs.getVillage());
            o.setDetailInfo(arRs.getDetailInfo());
            o.setKey(AddrUtil.processKey(arRs.getKeyword(), arRs.getVillage()));
            return  o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("未初始化的跑完地址可达后的地址量：{}", rddNoneRsGet.count());
        rddNoneRsGet.take(3).forEach(o -> logger.error("rddNoneRsGet - {}", o.toString()));
        rddNoneRs.unpersist();
        BdpTaskRecordUtil.endNetworkInterface("01370539", httpArInvokeId);

        JavaRDD<DkhArsInfo> rddFinal = rddExistRs.union(rddNoneRsGet).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("地址库最终的地址量为：{}", rddFinal.count());

        DataUtil.saveOverwrite(si, "dm_gis.dwd_dkh_ars_mf", DkhArsInfo.class, rddFinal, "inc_day");
        logger.error("end initArsDkh");
    }

    private static JavaRDD<AddrPojo> hitBsp(JavaRDD<AddrPojo> srcRdd, JavaPairRDD<String, Integer> bspRdd) {
        JavaRDD<AddrPojo> rddSrcRs = srcRdd.mapToPair(o -> new Tuple2<>(o.getAddr(), o)).leftOuterJoin(bspRdd).map(o -> {
            o._2._1.setIsHitBsp(o._2._2.isPresent() ? "Y" : "N");
            return o._2._1;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("和BSP地址匹配后输入地址数量：{}", srcRdd.count());
        logger.error("和BSP地址相同的输入地址数量：{}", rddSrcRs.filter(o -> "Y".equals(o.getIsHitBsp())).count());
        return rddSrcRs;
    }

    /**
     * 按照“省+市+区+地址”的维度按月累计频次和运费金额
     * 任务ID：917634
     * @param backCnt 回溯时间数量
     */
    public void statWbByMonth(int backCnt) {
        logger.error("start initDkhAddr: backCnt - {}", backCnt);
        SparkInfo si = SparkUtil.getSpark(DkhAddrController.class.getName());

        // 开始进行数据回溯
        String curMonth = DateUtil.getCurrentDate("yyyyMM");
        for (int i = backCnt; i > 0; i--) {
            String calMonth = DateUtil.getMonthBefore(curMonth, "yyyyMM", i);
            logger.error("start cal mont: {} -----------------------------------", calMonth);

            // 2023年11月之后运单宽表切换，故之前从旧的运单宽表取数据，之后从新的运单宽表取数据
            JavaRDD<DkhInfo> rddWbPu;
            JavaRDD<DkhInfo> rddWbDlv;
            if (Integer.parseInt(calMonth) >= 20231100) {
                rddWbPu = daSvc.loadPuAddrFromNewWbByMonth(si, calMonth).persist(StorageLevel.MEMORY_AND_DISK_SER());
                rddWbDlv = daSvc.loadDlvAddrFromNewWbByMonth(si, calMonth).persist(StorageLevel.MEMORY_AND_DISK_SER());
            } else {
                rddWbPu = daSvc.loadPuAddrFromOldWbByMonth(si, calMonth).persist(StorageLevel.MEMORY_AND_DISK_SER());
                rddWbDlv = daSvc.loadDlvAddrFromOldWbByMonth(si, calMonth).persist(StorageLevel.MEMORY_AND_DISK_SER());
            }
            logger.error("{}来自运单宽表的收件数量为：{}, 派件数量为：{}", calMonth, rddWbPu.count(), rddWbDlv.count());
            rddWbPu.take(3).forEach(o -> logger.error("rddWbPu -> {}",o.toString()));
            rddWbDlv.take(3).forEach(o -> logger.error("rddWbDlv -> {}",o.toString()));

            // 开始进行收件地址金额、件量、月结账号统计
            JavaRDD<DkhInfo> rddPuStat = processWb(rddWbPu, calMonth);
            rddWbPu.unpersist();
            logger.error("收件数据入库");
            DataUtil.saveOverwrite(si, "dm_gis.dwd_dkh_addr_wb_pu_mi", DkhInfo.class, rddPuStat, "inc_day");
            rddPuStat.unpersist();

            // 开始进行派件地址金额、件量、月结账号统计
            JavaRDD<DkhInfo> rddDlvStat = processWb(rddWbDlv, calMonth);
            rddWbDlv.unpersist();
            logger.error("派件数据入库");
            DataUtil.saveOverwrite(si, "dm_gis.dwd_dkh_addr_wb_dlv_mi", DkhInfo.class, rddDlvStat, "inc_day");
            rddPuStat.unpersist();

            si.getSession().catalog().clearCache();
        }
    }

    /**
     * 按照省+城市编码+区+地址 进行金额、件量、月结账号统计，并返回结果
     * @param rddWb 全量运单
     * @param calMonth 统计月份
     * @return 统计好的结果
     */
    private static JavaRDD<DkhInfo> processWb(JavaRDD<DkhInfo> rddWb, String calMonth) {
          JavaRDD<DkhInfo> rddWbStat = rddWb.mapToPair(o -> new Tuple2<>(o.getProvince() + "_" + o.getCityCode() + "_" + o.getCounty() + "_" + o.getAddr(), o)).groupByKey().map(o -> {
            List<DkhInfo> diList = wbStat(o._2);
            DkhInfo tmpDi = diList.get(0);
            DkhInfo di = new DkhInfo();   // 重新装载是为了剔除掉原始有的一些不必要的冗余值
            di.setProvince(tmpDi.getProvince());
            di.setCityCode(tmpDi.getCityCode());
            di.setCityName(tmpDi.getCityName());
            di.setCounty(tmpDi.getCounty());
            di.setAddr(tmpDi.getAddr());
            di.setCnt(tmpDi.getCnt());
            di.setFreight(tmpDi.getFreight());
            di.setIsWbDlv(tmpDi.getIsWbDlv());
            di.setIsWbPu(tmpDi.getIsWbPu());
            di.setFmAcctCode(tmpDi.getFmAcctCode());
            di.setIncDay(calMonth);
            return di;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("按省+市+区+地址维度统计后地址数量：{}", rddWbStat.count());
        rddWbStat.take(3).forEach(o -> logger.error("rddWbStat: {}", o.toString()));
        rddWb.unpersist();
        return rddWbStat;
    }

    /**
     * 进行金额、件量、月结账号统计
     * @param rddWbIter 纳入统计的数据
     * @return 统计结果
     */
    private static List<DkhInfo> wbStat(Iterable<DkhInfo> rddWbIter) {
        List<DkhInfo> diList = Lists.newArrayList(rddWbIter);
        double freight = 0;
        String freightOwner;
        String fmAcctCode = "";

        Map<String, Integer> facMap = new HashMap<>();
        for (DkhInfo di : diList) {
            freightOwner = freightOwner(di);
            if (StringUtils.isNotEmpty(di.getFreight()) && ((DkhConstant.FREIGHT_OWNER_PU.equals(freightOwner) && "Y".equals(di.getIsWbPu())) || (DkhConstant.FREIGHT_OWNER_DLV.equals(freightOwner) && "Y".equals(di.getIsWbDlv())))) {
                freight += Double.parseDouble(di.getFreight());
                facMap.put(di.getFmAcctCode(), 1);
            }
        }
        for (String key : facMap.keySet()) {
            if (StringUtils.isEmpty(fmAcctCode)) {
                fmAcctCode += key;
            } else {
                fmAcctCode += "|" + key;
            }
        }
        for (DkhInfo di : diList) {
            di.setCnt(diList.size()+"");
            di.setFreight(freight+"");
            di.setFmAcctCode(fmAcctCode);
        }
        return diList;
    }


    private static String freightOwner(DkhInfo dkhInfo) {
        if (("1".equals(dkhInfo.getFpTypeCode()) && "1".equals(dkhInfo.getFsTypeCode()) && ("0".equals(dkhInfo.getFpChangeTypeCode()) || "1".equals(dkhInfo.getFpChangeTypeCode()) || "-1".equals(dkhInfo.getFpChangeTypeCode())))
                || ("1".equals(dkhInfo.getFpTypeCode()) && "2".equals(dkhInfo.getFsTypeCode()) && ("0".equals(dkhInfo.getFpChangeTypeCode()) || "1".equals(dkhInfo.getFpChangeTypeCode()) || "-1".equals(dkhInfo.getFpChangeTypeCode())))
                || ("1".equals(dkhInfo.getFpTypeCode()) && "-1".equals(dkhInfo.getFsTypeCode()) && "-1".equals(dkhInfo.getFpChangeTypeCode()))
                || ("2".equals(dkhInfo.getFpTypeCode()) && "1".equals(dkhInfo.getFsTypeCode()) && "1".equals(dkhInfo.getFpChangeTypeCode()))
                || ("3".equals(dkhInfo.getFpTypeCode()) && "1".equals(dkhInfo.getFsTypeCode()) && "1".equals(dkhInfo.getFpChangeTypeCode()))
                || ("3".equals(dkhInfo.getFpTypeCode()) && "2".equals(dkhInfo.getFsTypeCode()) && ("1".equals(dkhInfo.getFpChangeTypeCode()) || "-1".equals(dkhInfo.getFpChangeTypeCode())))) {
            return DkhConstant.FREIGHT_OWNER_PU;
        } else if (("2".equals(dkhInfo.getFpTypeCode()) && "1".equals(dkhInfo.getFsTypeCode()) && ("0".equals(dkhInfo.getFpChangeTypeCode()) || "2".equals(dkhInfo.getFpChangeTypeCode()) || "-1".equals(dkhInfo.getFpChangeTypeCode())))
                || ("2".equals(dkhInfo.getFpTypeCode()) && "2".equals(dkhInfo.getFsTypeCode()) && ("0".equals(dkhInfo.getFpChangeTypeCode()) || "-1".equals(dkhInfo.getFpChangeTypeCode())))
                || ("2".equals(dkhInfo.getFpTypeCode()) && "-1".equals(dkhInfo.getFsTypeCode()) && "-1".equals(dkhInfo.getFpChangeTypeCode()))
                || ("3".equals(dkhInfo.getFpTypeCode()) && "1".equals(dkhInfo.getFsTypeCode()) && "2".equals(dkhInfo.getFpChangeTypeCode()))
                || ("3".equals(dkhInfo.getFpTypeCode()) && "2".equals(dkhInfo.getFsTypeCode()) && "2".equals(dkhInfo.getFpChangeTypeCode()))) {
            return DkhConstant.FREIGHT_OWNER_DLV;
        } else {
            return DkhConstant.FREIGHT_OWNER_OTHER;
        }
    }

    /**
     * 任务ID：884187
     * 任务名称：大客户地址获取AOI
     * @param threadCnt 线程数
     *
     */
    public void initRdsDkh(int threadCnt) {
        logger.error("start getAddrAoi: threadCnt - {}", threadCnt);
        SparkInfo si = SparkUtil.getSpark(DkhAddrController.class.getName());

        String month = DateUtil.getCurrentDate("yyyyMM");
        String startMonth = DateUtil.getMonthBefore(month, "yyyyMM", 12);
        String endMonth = DateUtil.getMonthBefore(month, "yyyyMM", 1);
        String dkhIncDay = DateUtil.getMonthBefore(month, "yyyyMM", 2);

        JavaRDD<DkhRdsInfo> rddStat = daSvc.getInitAddr4Rds(si, startMonth, endMonth).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("大客户地址数量：{}", rddStat.count());
        rddStat.take(3).forEach(o -> logger.error("dkhWb -> {}", o.toString()));

        JavaRDD<DkhRdsInfo> rddDkhRd = rddStat.mapToPair(o -> new Tuple2<>(o.getAddr(), o)).reduceByKey((o1, o2) -> StringUtils.isNotEmpty(o1.getAoiSrc()) ? o1 : o2).map(o -> o._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("排重后大客户地址数量：{}", rddDkhRd.count());
        rddDkhRd.take(3).forEach(o -> logger.error("rddDkhRd -> {}", o.toString()));
        rddStat.unpersist();

        JavaRDD<DkhRdsInfo> rddDkh = daSvc.getRdsDkh(si, dkhIncDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("{} 地址库地址数量为：{}", dkhIncDay, rddDkh.count());
        rddDkh.take(3).forEach(o -> logger.error("rdsDkh - {}", o.toString()));

        JavaRDD<DkhRdsInfo> rddHookLast = rddDkhRd.mapToPair(o -> new Tuple2<>(o.getAddr(), o)).leftOuterJoin(rddDkh.mapToPair(o -> new Tuple2<>(o.getAddr(),o))).map(o -> {
            DkhRdsInfo dai;
            if (o._2._2.isPresent()) {
                dai = o._2._2.get();
            } else {
                dai = o._2._1;
            }
            dai.setIncDay(endMonth);
            return dai;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("挂接初始化地址库结果后地址数量为：{}", rddHookLast.count());
        rddHookLast.take(3).forEach(o -> logger.error("rddHookLast - {}", o.toString()));
        rddDkhRd.unpersist();
        rddDkh.unpersist();

        JavaRDD<DkhRdsInfo> rddExistRs = rddHookLast.filter(o -> StringUtils.isNotEmpty(o.getCityCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("地址库已初始化的数量为：{}", rddExistRs.count());
        rddExistRs.take(3).forEach(o -> logger.error("rddExistRs - {}", o.toString()));

        JavaRDD<DkhRdsInfo> rddNoneRs = rddHookLast.filter(o -> StringUtils.isEmpty(o.getCityCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        long invokeCnt = rddNoneRs.count();
        logger.error("地址库库未初始化的数量为：{}", invokeCnt);
        rddNoneRs.take(3).forEach(o -> logger.error("rddNoneRs - {}", o.toString()));
        rddHookLast.unpersist();

        String ak = "87106f6380af4df0845a693eee58843c"; // 郭本婕
        String httpAtInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(),"01370539", "884187", "大客户地址获取AOI", "大客户地址库", HttpConstant.HTTP_URL_ATDISPATCH_API, ak, invokeCnt, threadCnt);
        String httpArInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(),"01370539", "884187", "大客户地址获取AOI", "大客户地址库", HttpConstant.HTTP_URL_AR_API, ak, invokeCnt, threadCnt);
        JavaRDD<DkhRdsInfo> rddNoneRsGet = rddNoneRs.repartition(threadCnt).map(o -> {
            DkhRdsInfo rs = new DkhRdsInfo();
            ArApiIn aaiParam = new ArApiIn();
            aaiParam.setAk(ak);
            aaiParam.setAddress(URLEncoder.encode(StrUtils.processInvalidCharacter(o.getAddr()), FixedConstant.CHARSET_UTF));
            AddrInfo arRs = AddrApi.arApi(aaiParam);
            rs.setCityCode(arRs.getCityCode());
            rs.setDetailAddr(arRs.getDetailAddr());
            rs.setAddr(o.getAddr());
            rs.setAoi80xy(o.getAoiId());
            rs.setPhone(o.getPhone());
            rs.setCompName(o.getCompName());
            rs.setTtlCnt(o.getTtlCnt());
            rs.setTtlFreight(o.getTtlFreight());
            rs.setCnt(o.getCnt());
            rs.setFreight(o.getFreight());
            if (StringUtils.isNotEmpty(arRs.getCityCode())) {
                AtdispatchApiIn param = new AtdispatchApiIn();
                param.setAk(ak);
                param.setOpt("zh");
                param.setCity(arRs.getCityCode());
                param.setAddress(URLEncoder.encode(StrUtils.processInvalidCharacter(o.getAddr()), FixedConstant.CHARSET_UTF));
                param.setCompany(StrUtils.processInvalidCharacter(o.getCompName()));
                param.setTel(o.getPhone());
                AddrInfo addrInfo = AddrApi.atdispatchApi(param);
                rs.setZc(addrInfo.getZc());
                rs.setZcSrc(addrInfo.getZcSrc());
                rs.setAoiId(addrInfo.getAoiId());
                rs.setAoiCode(addrInfo.getAoiCode());
                rs.setAoiSrc(addrInfo.getAoiSrc());
                rs.setAoiUnit(addrInfo.getAoiUnit());
                if ("chkn".equals(rs.getAoiSrc())) {
                    rs.setGroupId(addrInfo.getChknId());
                } else if ("norm".equals(rs.getAoiSrc())) {
                    rs.setGroupId(addrInfo.getGroupId());
                }
            }
            rs.setIncDay(endMonth);
            return rs;
        }).repartition(SysConstant.PARTITION_COUNT).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("地址库库未初始化的数据获取到aoi信息后地址数量：{}", rddNoneRsGet.count());
        rddNoneRsGet.take(3).forEach(o -> logger.error("rddRs: {}", o.toString()));
        rddNoneRs.unpersist();

        BdpTaskRecordUtil.endNetworkInterface("01370539", httpAtInvokeId);
        BdpTaskRecordUtil.endNetworkInterface("01370539", httpArInvokeId);

        JavaRDD<DkhRdsInfo> rddFinal = rddExistRs.union(rddNoneRsGet).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("地址库最终的地址量为：{}", rddFinal.count());
        rddExistRs.unpersist();
        rddNoneRsGet.unpersist();

        DataUtil.saveOverwrite(si, "dm_gis.dwd_dkh_rds_mf", DkhRdsInfo.class, rddFinal, "inc_day");
        rddFinal.unpersist();

        logger.error("end getAddrAoi");
    }
}
