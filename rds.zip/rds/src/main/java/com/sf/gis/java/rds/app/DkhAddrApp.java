package com.sf.gis.java.rds.app;

import com.sf.gis.java.rds.common.DkhConstant;
import com.sf.gis.java.rds.controller.DkhAddrController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 大客户地址数据挖掘
 * @author 01370539 YY
 * Created on Oct.25
 */
public class DkhAddrApp {
    private static final Logger logger = LoggerFactory.getLogger(DkhAddrApp.class);

    public static void main(String[] args) {
        logger.error("Start DkhAddrApp.args: {}", args);

        String taskType;
        int backCnt = 1;
        if (args.length > 0) {
            taskType = args[0];
            if (DkhConstant.TASK_TYPE_BASIC_STAT_ADDR.equals(taskType)) {
                if (args.length > 1) {
                    backCnt = Integer.parseInt(args[1]);
                }
                new DkhAddrController().statAddrByMonth(backCnt);
            } else if (DkhConstant.TASK_TYPE_BASIC_STAT_ADDR_WB.equals(taskType)) {
                if (args.length > 1) {
                    backCnt = Integer.parseInt(args[1]);
                }
                new DkhAddrController().statWbByMonth(backCnt);
            } else if (DkhConstant.TASK_TYPE_INIT_DKH_ARS.equals(taskType)) {
                int threadCnt = Integer.parseInt(args[1]);
                new DkhAddrController().initArsDkh(threadCnt);
            } else if (DkhConstant.TASK_TYPE_INIT_DKH_RDS.equals(taskType)) {
                int threadCnt = Integer.parseInt(args[1]);
                new DkhAddrController().initRdsDkh(threadCnt);
            } else {
                logger.error("不存在的任务类型： {}", taskType);
            }
        }

        logger.error("end DkhAddrApp.");
    }
}
