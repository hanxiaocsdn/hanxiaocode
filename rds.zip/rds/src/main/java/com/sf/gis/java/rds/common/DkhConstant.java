package com.sf.gis.java.rds.common;

public class DkhConstant {
    public static final String ARS_DKH_ADDR_TYPE_STAT_FREIGHT = "stat_frei";
    public static final String ARS_DKH_ADDR_TYPE_STAT_NUM = "stat_num";
    public static final String ARS_DKH_ADDR_TYPE_STAT_BOTH = "stat_both";
    public static final String ARS_DKH_ADDR_TYPE_BSP = "bsp";
    public static final String ARS_DKH_ADDR_TYPE_BOTH_FREIGHT = "both_frei";
    public static final String ARS_DKH_ADDR_TYPE_BOTH_NUM = "both_num";
    public static final String ARS_DKH_ADDR_TYPE_BOTH_BOTH = "both_both";

    public static final String TASK_TYPE_BASIC_STAT_ADDR = "BASIC_STAT_ADDR";
    public static final String TASK_TYPE_BASIC_STAT_ADDR_WB = "BASIC_STAT_ADDR_WB";
    public static final String TASK_TYPE_BASIC_STAT_ADDR_LOG = "BASIC_STAT_ADDR_LOG";
    public static final String TASK_TYPE_INIT_DKH_RDS = "INIT_DKH_RDS";
    public static final String TASK_TYPE_INIT_DKH_ARS = "INIT_DKH_ARS";

    /*********************** 费用归属 ***********************/
    public static final String FREIGHT_OWNER_PU = "pu";   // 费用归属寄方
    public static final String FREIGHT_OWNER_DLV = "dlv";   // 费用归属收方
    public static final String FREIGHT_OWNER_OTHER = "other";   // 费用不归属任一方
}
