package com.sf.gis.java.rds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiChangedWb implements Serializable {
    @Column(name = "waybill_no")
    private String waybillNo;
    @Column(name = "province")
    private String province;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "city_name")
    private String cityName;
    @Column(name = "county")
    private String county;
    @Column(name = "addr")
    private String addr;
    @Column(name = "comp_name")
    private String compName;
    @Column(name = "phone")
    private String phone;
    @Column(name = "cont_name")
    private String contName;
    @Column(name = "mobile")
    private String mobile;
    @Column(name = "fm_acct_code")
    private String fmAcctCode;
    @Column(name = "zc")
    private String zc;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_code")
    private String aoiCode;
    @Column(name = "aoi_zc")
    private String aoiZc;
    @Column(name = "new_zc")
    private String newZc;
    @Column(name = "new_zc_src")
    private String newZcSrc;
    @Column(name = "new_aoi_id")
    private String newAoiId;
    @Column(name = "new_aoi_code")
    private String newAoiCode;
    @Column(name = "new_aoi_src")
    private String newAoiSrc;
    @Column(name = "inc_day")
    private String incDay;
    private String cnt;
    private long aoiCnt;

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getContName() {
        return contName;
    }

    public void setContName(String contName) {
        this.contName = contName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getFmAcctCode() {
        return fmAcctCode;
    }

    public void setFmAcctCode(String fmAcctCode) {
        this.fmAcctCode = fmAcctCode;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiZc() {
        return aoiZc;
    }

    public void setAoiZc(String aoiZc) {
        this.aoiZc = aoiZc;
    }

    public String getNewZc() {
        return newZc;
    }

    public void setNewZc(String newZc) {
        this.newZc = newZc;
    }

    public String getNewZcSrc() {
        return newZcSrc;
    }

    public void setNewZcSrc(String newZcSrc) {
        this.newZcSrc = newZcSrc;
    }

    public String getNewAoiId() {
        return newAoiId;
    }

    public void setNewAoiId(String newAoiId) {
        this.newAoiId = newAoiId;
    }

    public String getNewAoiCode() {
        return newAoiCode;
    }

    public void setNewAoiCode(String newAoiCode) {
        this.newAoiCode = newAoiCode;
    }

    public String getNewAoiSrc() {
        return newAoiSrc;
    }

    public void setNewAoiSrc(String newAoiSrc) {
        this.newAoiSrc = newAoiSrc;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public long getAoiCnt() {
        return aoiCnt;
    }

    public void setAoiCnt(long aoiCnt) {
        this.aoiCnt = aoiCnt;
    }

    @Override
    public String toString() {
        return "AoiChangedWb{" +
                "waybillNo='" + waybillNo + '\'' +
                ", province='" + province + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", cityName='" + cityName + '\'' +
                ", county='" + county + '\'' +
                ", addr='" + addr + '\'' +
                ", compName='" + compName + '\'' +
                ", phone='" + phone + '\'' +
                ", contName='" + contName + '\'' +
                ", mobile='" + mobile + '\'' +
                ", fmAcctCode='" + fmAcctCode + '\'' +
                ", zc='" + zc + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiCode='" + aoiCode + '\'' +
                ", aoiZc='" + aoiZc + '\'' +
                ", newZc='" + newZc + '\'' +
                ", newZcSrc='" + newZcSrc + '\'' +
                ", newAoiId='" + newAoiId + '\'' +
                ", newAoiCode='" + newAoiCode + '\'' +
                ", newAoiSrc='" + newAoiSrc + '\'' +
                ", incDay='" + incDay + '\'' +
                ", cnt='" + cnt + '\'' +
                ", aoiCnt='" + aoiCnt + '\'' +
                '}';
    }
}
