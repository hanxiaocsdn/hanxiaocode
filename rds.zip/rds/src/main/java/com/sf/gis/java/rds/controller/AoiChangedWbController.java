package com.sf.gis.java.rds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.api.AddrApi;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.*;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.rds.common.AoiConstant;
import com.sf.gis.java.rds.pojo.AoiChanged;
import com.sf.gis.java.rds.pojo.AoiChangedWb;
import com.sf.gis.java.rds.service.AoiChangedWbService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * aoi件量预测模型-AOI变更运单分析
 * @author 01370539 YY
 * created on Oct.23
 */
public class AoiChangedWbController {
    private static final Logger log = LoggerFactory.getLogger(AoiChangedWbController.class);

    private final AoiChangedWbService aoiChangedWbSvc = new AoiChangedWbService();

    /**
     * 任务ID：819307
     * 任务名称：aoi变更运单分析
     * @param isInitAoi 是否初始化AOI
     * @param cityCodes 需要跑的城市
     * @param aoiStartDate 变更aoi获取的开始日期
     * @param aoiEndDate 变更aoi获取的截止日期
     */
    public void loadAoiChangedWb(String isInitAoi, String cityCodes, String aoiStartDate, String aoiEndDate, String wbStartDate, String wbEndDate) {
        log.error("start statAoiChangedWb: isInitAoi - {}, aoiStartDate - {}, aoiEndDate - {}, wbStartDate - {}, wbEndDate - {}, cityCodes - {}", isInitAoi, aoiStartDate, aoiEndDate, cityCodes, wbStartDate, wbEndDate);
        SparkInfo si = SparkUtil.getSpark(AoiChangedWbController.class.getName());
        String aoiIncDay = DateUtil.formatDate(aoiStartDate, "yyyy-MM-dd", "yyyyMMdd") + "_" + DateUtil.formatDate(aoiEndDate, "yyyy-MM-dd", "yyyyMMdd");

        if ("Y".equals(isInitAoi)) {
            JavaRDD<AoiChanged> rddAoiChanged = aoiChangedWbSvc.loadChangedAoi(si, aoiStartDate, aoiEndDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("{} - {} aoi变更的量：{}", aoiStartDate, aoiEndDate, rddAoiChanged.count());
            JavaRDD<AoiChanged> rddAoiAll = aoiChangedWbSvc.loadAoi(si).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("aoi总量：{}", rddAoiAll.count());

            JavaRDD<AoiChanged> rddAoiFlag = rddAoiAll.mapToPair(o -> new Tuple2<>(o.getAoiId(), 1)).leftOuterJoin(rddAoiChanged.mapToPair(o -> new Tuple2<>(o.getAoiId(), 1))).map(o -> {
                AoiChanged ac = new AoiChanged();
                ac.setAoiId(o._1);
                if (o._2._2.isPresent()) {
                    ac.setIsChanged("Y");
                } else {
                    ac.setIsChanged("N");
                }
                ac.setIncDay(aoiIncDay);
                return ac;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("未改变的AOI的量：{}", rddAoiFlag.filter(o -> "N".equals(o.getIsChanged())).count());

            DataUtil.saveOverwrite(si, "dm_gis.dwb_aoi_change_info_df", AoiChanged.class, rddAoiFlag, "inc_day");
            rddAoiChanged.unpersist();
            rddAoiAll.unpersist();
            rddAoiFlag.unpersist();
        }

        String[] cityArr = cityCodes.split(",");

        for (String city : cityArr) {
            String wbIncDay = aoiIncDay + "_" + city + "_" + wbStartDate + "_" + wbEndDate;

            JavaRDD<AoiChangedWb> rddAddrAoi = aoiChangedWbSvc.loadWbPuAddr(si, wbStartDate, wbEndDate, city, aoiIncDay).map(o -> {
                o.setIncDay(wbIncDay);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("{} 收件地址数据的量：{}", city, rddAddrAoi.count());
            rddAddrAoi.take(3).forEach(o -> log.error("rddAddrAoi -> {}", o.toString()));

            JavaRDD<AoiChangedWb> rddAddrAoiAreaChanged = rddAddrAoi.filter(o -> StringUtils.isEmpty(o.getNewAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("{} 收件数据AOI范围变更的量：{}", city, rddAddrAoiAreaChanged.count());

            JavaRDD<AoiChangedWb> rddAddrAoiAreaNotChanged = rddAddrAoi.filter(o -> StringUtils.isNotEmpty(o.getNewAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("{} 收件数据AOI范围未变更的量：{}", city, rddAddrAoiAreaNotChanged.count());
            rddAddrAoi.unpersist();

            JavaPairRDD<String, AoiChangedWb> rddAddrAoiAreaNotChangedTp = rddAddrAoiAreaNotChanged.mapToPair(o -> new Tuple2<>(getKey2MultiAoi(o), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("{} 收件数据AOI范围未变更的地址进行分组准备后的数量：{}", city, rddAddrAoiAreaNotChangedTp.count());
            rddAddrAoiAreaNotChanged.unpersist();


            JavaPairRDD<String, Integer> rddAddrUnsameAoiCnt = rddAddrAoiAreaNotChangedTp.mapToPair(o -> new Tuple2<>(o._2.getAoiId() + "_" + o._1, o._1)).reduceByKey((a,b) -> a).mapToPair(o -> new Tuple2<>(o._2, o._1)).groupByKey().mapToPair(o -> {
                Map<String, Integer> aoiMap = new HashMap<>();
                String[] keyArr;
                List<String> KeyList = Lists.newArrayList(o._2);
                for (String key : KeyList) {
                    keyArr = key.split("_");
                    if (StringUtils.isNotEmpty(keyArr[0]) && keyArr[0].length() == 32) {
                        aoiMap.put(keyArr[0], 1);
                    }
                }
                return new Tuple2(o._1, aoiMap.size());
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("{} 完成每个地址不同aoi的数量计算. 共计算 {} 组", city, rddAddrUnsameAoiCnt.count());

            Map<String, Integer> multiAoiMap = rddAddrUnsameAoiCnt.filter(o -> o._2 > 1).collectAsMap();
            Map<String, Integer> bcMap = new HashMap<>();
            bcMap.putAll(multiAoiMap);
            log.error("multiAoiMap 的地址数量为： {}", multiAoiMap.size());
            Broadcast<Map<String, Integer>> topBc = si.getContext().broadcast(bcMap);

            JavaRDD<AoiChangedWb> rddAddrMultiAoi = rddAddrAoiAreaNotChangedTp.map(o -> {
                Map<String, Integer> topBcValue = topBc.value();
                Integer aoiCnt = topBcValue.get(o._1);
                o._2.setAoiCnt(aoiCnt == null ? 0 : aoiCnt);
                return o._2;
            }).filter(o -> o.getAoiCnt() > 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("rddAddrMultiAoi 的地址数量为： {}", rddAddrMultiAoi.count());

            JavaRDD<AoiChangedWb> rddAddrAoiChangedAll = rddAddrAoiAreaChanged.union(rddAddrMultiAoi).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("{} 收件数据AOI变更的总量：{}", city, rddAddrAoiChangedAll.count());
            rddAddrAoiChangedAll.take(3).forEach(o -> log.error("rddAddrAoiChangedAll -> {}", o.toString()));
            rddAddrMultiAoi.unpersist();
            rddAddrAoiAreaChanged.unpersist();

            log.error("白名单数量为：{}", AoiConstant.whiteMap.size());

            JavaRDD<AoiChangedWb> rddPuw = rddAddrAoiChangedAll.filter(o -> AoiConstant.whiteMap.get(o.getAoiId()) == null).persist(StorageLevel.MEMORY_AND_DISK_SER());
            log.error("{} 收件数据需要重跑AOI的数据剔除白名单后的量：{}", city, rddPuw.count());
            rddPuw.take(3).forEach(o -> log.error("rddPuw -> {}", o.toString()));
            rddAddrAoiChangedAll.unpersist();

            DataUtil.saveOverwrite(si, "dm_gis.dwb_wb_aoi_changed_pu_mi", AoiChangedWb.class, rddPuw, "inc_day");
            rddPuw.unpersist();
            si.getSession().catalog().clearCache();
        }

    }

    /**
     * 任务ID：819508
     * 任务名称： AOI变更收件地址跑AT收服务
     * @param aoiStartDate 变更aoi获取的开始日期
     * @param aoiEndDate 变更aoi获取的截止日期
     * @param cityCodes 要跑数的城市编码
     * @param threadCount 服务调用并发数
     * @param invokeStartTm 可以调用服务的开始时间
     * @param invokeEndTm 可以调用服务的结束时间
     */
    public void loadPuNewAoiByAtShou(String aoiStartDate, String aoiEndDate, String cityCodes, int threadCount, long invokeStartTm, long invokeEndTm) {
        log.error("start loadPuNewAoiByAtShou: aoiStartDate - {}, aoiEndDate - {}, cityCodes - {}, threadCount - {}, invokeStartTm - {}, invokeEndTm - {}", aoiStartDate, aoiEndDate, cityCodes, threadCount, invokeStartTm, invokeEndTm);
        SparkInfo si = SparkUtil.getSpark(AoiChangedWbController.class.getName());
        String aoiIncDay = DateUtil.formatDate(aoiStartDate, "yyyy-MM-dd", "yyyyMMdd") + "_" + DateUtil.formatDate(aoiEndDate, "yyyy-MM-dd", "yyyyMMdd");
        List<String> partitionList = aoiChangedWbSvc.loadAtShouPartitions(si, aoiIncDay);
        log.error("时间内 {} 的分区数量为：{}", aoiIncDay, partitionList.size());
        String[] cityArr = cityCodes.split(",");
        for (String cityCode : cityArr) {
            String finalIncDay = aoiIncDay + "_" + cityCode;
            if (partitionList.contains(finalIncDay)) {
                log.error("城市：{} 已完成！", cityCode);
                continue;
            }
            if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                log.error("开始处理城市：{} ----------------------------", cityCode);
                JavaRDD<AoiChangedWb> rddAddr = aoiChangedWbSvc.loadWbPuChanged(si, finalIncDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("城市 {} 的收件地址量为： {}", cityCode, rddAddr.count());
                rddAddr.take(3).forEach(o -> log.error("rddAddr -> {}", o.toString()));

                JavaRDD<AoiChangedWb> rddExistAoi = rddAddr.filter(o -> StringUtils.isNotEmpty(o.getNewAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("城市 {} 的收件地址已跑Aoi的量为： {}", cityCode, rddExistAoi.count());

                JavaRDD<AoiChangedWb> rddNoneAoi = rddAddr.filter(o -> StringUtils.isEmpty(o.getNewAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("城市 {} 的收件地址未跑Aoi的量为： {}", cityCode, rddNoneAoi.count());

                rddAddr.unpersist();

                JavaPairRDD<String, Iterable<String>> rddNoneAoiGrp = rddNoneAoi.mapToPair(o -> new Tuple2<>(getKey2Atsh(o), o.getAoiZc())).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
                long invokeAtShouCnt = rddNoneAoiGrp.count();
                log.error("城市 {} 需要调用AT收件服务的地址量为: {}", cityCode, invokeAtShouCnt);

                String ak = "0376a9aa84724dd2a995f858dd963346";
                String httpAtShouInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(), "01370539", "819508", "AOI变更收件地址跑AT收服务", "件量预测前置数据处理", HttpConstant.HTTP_URL_ATCONSIGNEE_TEAM_BYADDR, ak, invokeAtShouCnt, threadCount);

                JavaPairRDD<String, AoiChangedWb> rddAoi = rddNoneAoiGrp.repartition(threadCount).mapToPair(o -> {
                    List<String> wbs = Lists.newArrayList(o._2);
                    AtconsigneeTeamByaddrIn param = new AtconsigneeTeamByaddrIn();
                    AddrInfo aoi = null;
                    AoiChangedWb acw = getAcw(o._1);
                    if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                        param.setAk(ak);
                        param.setOpt("zh");
                        param.setCallDispatch("1");
                        param.setIsNotUnderCall("1");
                        param.setNeedAoiArea("1");
                        param.setProvince(acw.getProvince());
                        param.setCity(acw.getCityCode());
                        param.setDistrict(acw.getCounty());
                        param.setAddress(URLEncoder.encode(StrUtils.processInvalidCharacter(acw.getAddr()), FixedConstant.CHARSET_UTF));
                        param.setTel(acw.getPhone());
                        param.setMobile(acw.getMobile());
                        param.setCompany(StrUtils.processInvalidCharacter(acw.getCompName()));
                        param.setContacts(StrUtils.processInvalidCharacter(acw.getContName()));
                        param.setCustomerAccount(acw.getFmAcctCode());
                        aoi = AddrApi.atconsigneeTeamByaddr(param);
                        if (StringUtils.isEmpty(aoi.getAoiId())) {
                            Map<String, Long> cityMap = getCityCntMap(wbs);
                            while (StringUtils.isEmpty(aoi.getAoiId()) && cityMap.size() > 0) {
                                param.setCity(getMaxCntCity(cityMap));
                                if (!param.getCity().equals(acw.getCityCode())) {
                                    aoi = AddrApi.atconsigneeTeamByaddr(param);
                                }
                                cityMap.remove(param.getCity());
                            }
                        }
                    }
                    if (aoi != null) {
                        acw.setNewZc(aoi.getZc());
                        acw.setNewZcSrc(aoi.getZcSrc());
                        acw.setNewAoiId(aoi.getAoiId());
                        acw.setNewAoiCode(aoi.getAoiCode());
                        acw.setNewAoiSrc(aoi.getAoiSrc());
                    }
                    acw.setIncDay(finalIncDay);
                    return new Tuple2<>(o._1, acw);
                }).repartition(SysConstant.PARTITION_COUNT).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("调用AT收后的运单数据量：{} ------------", rddAoi.count());
                rddAoi.take(3).forEach(o -> log.error("调用AT收后的运单详细信息：{}", o._2.toString()));
                rddNoneAoiGrp.unpersist();
                log.error("调用服务完成，调用服务ID：{}", httpAtShouInvokeId);
                BdpTaskRecordUtil.endNetworkInterface("01370539", httpAtShouInvokeId);

                if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                    JavaRDD<AoiChangedWb> rddAoiGet = mergeAtshResult(si, rddNoneAoi, rddAoi, finalIncDay);

                    JavaRDD<AoiChangedWb> rddFinal = rddAoiGet.union(rddExistAoi).map(o -> {
                        o.setIncDay(finalIncDay);
                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                    log.error("城市 {} 已跑AOI的数据量：{} ------------", cityCode, rddFinal.count());
                    rddAoiGet.unpersist();
                    rddExistAoi.unpersist();

                    DataUtil.saveOverwrite(si, "dm_gis.dwb_wb_aoi_changed_pu_atsh_mi", AoiChangedWb.class, rddFinal, "inc_day");

                } else {

                    JavaPairRDD<String, AoiChangedWb> rddExistAoiGrp = rddExistAoi.mapToPair(o -> new Tuple2<>(getKey2Atsh(o), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
                    log.error("原始缓存库的数量 - {}", rddExistAoiGrp.count());
                    rddExistAoi.unpersist();

                    JavaRDD<AoiChangedWb> rddFinal = rddExistAoiGrp.union(rddAoi).reduceByKey((o1, o2) -> o1).map(o -> {
                        o._2.setIncDay(finalIncDay);
                        return o._2;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                    log.error("入缓存库的数量 - {}", rddFinal.count());
                    rddFinal.take(3).forEach(o -> log.error("入缓存库的详细信息: {}", o.toString()));
                    rddExistAoiGrp.unpersist();
                    rddAoi.unpersist();

                    DataUtil.saveOverwrite(si, "dm_gis.dwb_wb_aoi_changed_pu_atsh_cache", AoiChangedWb.class, rddFinal, "inc_day");

                    log.error("当前已跑但未完成的城市为： {}， 当前时间已经不在跑数时间内，程序即将结束！！！", cityCode);
                    break;
                }
            } else {
                log.error("未执行的城市为：{}， 当前时间不在跑数时间内，程序即将结束！！！", cityCode);
                break;
            }
            si.getSession().catalog().clearCache();
        }
        log.error("end loadPuNewAoiByAtShou: aoiStartDate - {}, aoiEndDate - {}, cityCodes - {}, threadCount - {}", aoiStartDate, aoiEndDate, cityCodes, threadCount);
    }

    private static JavaRDD<AoiChangedWb> mergeAtshResult(SparkInfo si, JavaRDD<AoiChangedWb> rddNoneAoi, JavaPairRDD<String, AoiChangedWb> rddAoi, String finalIncDay) {
        log.error("------------------------------------ 待合并结果的数量为：{}， 结果数量为：{}， 分区为：{}，开始进行数据合并 ------------------------------------", rddNoneAoi.count(), rddAoi.count(), finalIncDay);
        List<Tuple2<Integer, String>> topKeyList = rddNoneAoi.mapToPair(o -> new Tuple2<>(getKey2Atsh(o), 1)).reduceByKey(Integer::sum).mapToPair(o -> new Tuple2<>(o._2, o._1)).sortByKey(false).take(rddNoneAoi.getNumPartitions()*4);
        Map<String, Integer> topKeyMap = new HashMap<>();
        for (int i = 0, size = topKeyList.size(); i < size; i++) {
            if (i < 20) {
                log.error("数量排名前20的key为：{}，其值为：{}", topKeyList.get(i)._1, topKeyList.get(i)._2);
            }
            topKeyMap.put(topKeyList.get(i)._2, topKeyList.get(i)._1);
        }
        log.error("topKeyList.size - {}, topKeyMap.size - {}", topKeyList.size(), topKeyMap.size());


        Map<String, AoiChangedWb> aoiTopMap = rddAoi.filter(o -> topKeyMap.get(o._1) != null).collectAsMap();
        Map<String, AoiChangedWb> bcMap = new HashMap<>();
        bcMap.putAll(aoiTopMap);
        log.error("aoiTopMap 数量为： {}", aoiTopMap.size());
        Broadcast<Map<String, AoiChangedWb>> topBc = si.getContext().broadcast(bcMap);

        JavaPairRDD<String, AoiChangedWb> rddNoneAoiGrp = rddNoneAoi.mapToPair(o -> new Tuple2<>(getKey2Atsh(o), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("rddNoneAoiGrp 数量为： {}", rddNoneAoiGrp.count());
        rddNoneAoi.unpersist();

        JavaPairRDD<String, AoiChangedWb> rddNoneAoiGrpTop = rddNoneAoiGrp.filter(o -> topKeyMap.get(o._1) != null).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("rddNoneAoiGrpTop 数量为： {}", rddNoneAoiGrpTop.count());
        JavaPairRDD<String, AoiChangedWb> rddNoneAoiGrpUnTop = rddNoneAoiGrp.filter(o -> topKeyMap.get(o._1) == null).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("rddNoneAoiGrpUnTop 数量为： {}", rddNoneAoiGrpUnTop.count());
        rddNoneAoiGrp.unpersist();

        JavaRDD<AoiChangedWb> rddUnTopAoi = rddNoneAoiGrpUnTop.leftOuterJoin(rddAoi).map(o -> {
            AoiChangedWb acw = o._2._1;
            if (o._2._2.isPresent()) {
                AoiChangedWb aoi = o._2._2.get();
                if (aoi != null) {
                    acw.setNewZc(aoi.getNewZc());
                    acw.setNewZcSrc(aoi.getNewZcSrc());
                    acw.setNewAoiId(aoi.getNewAoiId());
                    acw.setNewAoiCode(aoi.getNewAoiCode());
                    acw.setNewAoiSrc(aoi.getNewAoiSrc());
                }
            }
            acw.setIncDay(finalIncDay);
            return acw;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("rddUnTopAoi - 地址关联AOI结果后的数据量：{} ------------", rddUnTopAoi.count());
        rddUnTopAoi.take(3).forEach(o -> log.error("rddUnTopAoi - 地址关联AOI结果后的详细信息：{}", o.toString()));
        rddAoi.unpersist();
        rddNoneAoiGrpUnTop.unpersist();

        JavaRDD<AoiChangedWb> rddTopAoi = rddNoneAoiGrpTop.map(o -> {
            Map<String, AoiChangedWb> topBcValue = topBc.value();
            AoiChangedWb acw = o._2;
            AoiChangedWb aoi = topBcValue.get(o._1);
            acw.setNewZc(aoi.getNewZc());
            acw.setNewZcSrc(aoi.getNewZcSrc());
            acw.setNewAoiId(aoi.getNewAoiId());
            acw.setNewAoiCode(aoi.getNewAoiCode());
            acw.setNewAoiSrc(aoi.getNewAoiSrc());
            acw.setIncDay(finalIncDay);
            return acw;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("rddTopAoi - 地址关联AOI结果后的数据量：{} ------------", rddTopAoi.count());
        rddTopAoi.take(3).forEach(o -> log.error("rddTopAoi - 地址关联AOI结果后的详细信息：{}", o.toString()));
        rddNoneAoiGrpTop.unpersist();

        JavaRDD<AoiChangedWb> rddTotal = rddUnTopAoi.union(rddTopAoi).persist(StorageLevel.MEMORY_AND_DISK_SER());
        log.error("地址关联AOI结果后的总数据量：{} ------------", rddTotal.count());
        rddUnTopAoi.unpersist();
        rddTopAoi.unpersist();

        return rddTotal;
    }

    /**
     * 任务ID：819471
     * 任务名称： AOI变更地址跑KS服务
     * @param aoiStartDate 变更aoi获取的开始日期
     * @param aoiEndDate 变更aoi获取的截止日期
     * @param cityCodes 要跑数的城市编码
     * @param threadCount 服务调用并发数
     * @param invokeStartTm 可以调用服务的开始时间
     * @param invokeEndTm 可以调用服务的结束时间
     */
    public void loadPuNewAoiByKs(String aoiStartDate, String aoiEndDate, String cityCodes, int threadCount, long invokeStartTm, long invokeEndTm) {
        log.error("start loadPuNewAoiByKs: aoiStartDate - {}, aoiEndDate - {}, cityCodes - {}, threadCount - {}, invokeStartTm - {}, invokeEndTm - {}", aoiStartDate, aoiEndDate, cityCodes, threadCount, invokeStartTm, invokeEndTm);
        SparkInfo si = SparkUtil.getSpark(AoiChangedWbController.class.getName());
        String aoiIncDay = DateUtil.formatDate(aoiStartDate, "yyyy-MM-dd", "yyyyMMdd") + "_" + DateUtil.formatDate(aoiEndDate, "yyyy-MM-dd", "yyyyMMdd");

        List<String> ksPList = aoiChangedWbSvc.loadKsPartitions(si, aoiIncDay);
        log.error("时间内 {} ks的分区数量为：{}", aoiIncDay, ksPList.size());

        List<String> ksCachePList = aoiChangedWbSvc.loadKsCachePartitions(si, aoiIncDay);
        log.error("时间内 {} ks缓存的分区数量为：{}", aoiIncDay, ksCachePList.size());

        String[] cityArr = cityCodes.split(",");
        JavaRDD<AoiChangedWb> rddAtShou;
        for (String cityCode : cityArr) {
            String finalIncDay = aoiIncDay + "_" + cityCode;
            if (ksPList.contains(finalIncDay)) {
                log.error("城市：{} 已完成！", cityCode);
                continue;
            }
            if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                log.error("开始处理城市：{} ----------------------------", cityCode);
                if (ksCachePList.contains(finalIncDay)) {
                    rddAtShou = aoiChangedWbSvc.loadKsCache(si, finalIncDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                } else {
                    rddAtShou = aoiChangedWbSvc.loadAtshou(si, finalIncDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                }
                long rddAtShouCnt = rddAtShou.count();
                log.error("城市 {} 从结果表获取的收件单量为： {}", cityCode, rddAtShouCnt);

                JavaRDD<AoiChangedWb> rddExistAoi = rddAtShou.filter(o -> StringUtils.isNotEmpty(o.getNewAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("城市 {} 从结果表获取的收件AOI不为空的单量为： {}", cityCode, rddExistAoi.count());

                JavaRDD<AoiChangedWb> rddNoneAoi = rddAtShou.filter(o -> StringUtils.isEmpty(o.getNewAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("城市 {} 从结果表获取的收件AOI为空的单量为： {}", cityCode, rddNoneAoi.count());
                rddAtShou.unpersist();

                JavaPairRDD<String, Iterable<AoiChangedWb>> rddNoneAoiGrp = rddNoneAoi.mapToPair(o -> new Tuple2<>(getKey2Ks(o), o)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
                long invokeCnt = rddNoneAoiGrp.count();
                log.error("城市 {} 需要调用KS服务的地址量为: {}", cityCode, invokeCnt);
                rddNoneAoi.unpersist();

                String httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(), "01370539", "819471", "AOI变更地址跑KS服务", "件量预测前置数据处理", HttpConstant.HTTP_URL_RDSKS_API_GETTEAM, "54b2887682324f79ae04cfd2815853ae", invokeCnt, threadCount);
                JavaRDD<AoiChangedWb> rddGetAoi = rddNoneAoiGrp.repartition(threadCount).mapPartitions(o -> {
                    List<AoiChangedWb> rsList = new ArrayList<>();
                    long i = 0;
                    while (o.hasNext()) {
                        i++;
                        Tuple2<String, Iterable<AoiChangedWb>> tpAcw = o.next();
                        List<AoiChangedWb> wbs = Lists.newArrayList(tpAcw._2);
                        if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                            AoiChangedWb tmp = wbs.get(0);
                            RdsksApiGetTeamIn param = new RdsksApiGetTeamIn();
                            param.setAk("54b2887682324f79ae04cfd2815853ae");
                            param.setProvince(tmp.getProvince());
                            param.setCity(tmp.getCityCode());
                            param.setDistrict(tmp.getCounty());
                            param.setDept(tmp.getNewZc());
                            param.setAddress(URLEncoder.encode(StrUtils.processInvalidCharacter(tmp.getAddr()), FixedConstant.CHARSET_UTF));
                            param.setTel(tmp.getPhone());
                            param.setMobile(tmp.getMobile());
                            param.setCompany(StrUtils.processInvalidCharacter(tmp.getCompName()));
                            AddrInfo aoi = AddrApi.rdsksApiGetTeam(param, 0);
                            for (AoiChangedWb wb : wbs) {
                                wb.setNewZc(aoi.getZc());
                                wb.setNewZcSrc(aoi.getZcSrc());
                                wb.setNewAoiId(aoi.getAoiId());
                                wb.setNewAoiCode(aoi.getAoiCode());
                                wb.setNewAoiSrc(aoi.getAoiSrc());
                                rsList.add(wb);
                            }
                        }
                        if (i % 1000 == 0) {
                            log.error("当前分区已经处理的数量为：{}", i);
                        }
                    }
                    log.error("当前分区已经处理完成，处理的数量为：{}", i);
                    return rsList.iterator();
                }).repartition(SysConstant.PARTITION_COUNT).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("调用KS后的运单数据量：{} ------------", rddGetAoi.count());
                rddGetAoi.take(3).forEach(o -> log.error("调用KS后的运单详细信息：{}", o.toString()));
                rddNoneAoiGrp.unpersist();
                log.error("调用服务完成，调用服务ID：{}", httpInvokeId);
                BdpTaskRecordUtil.endNetworkInterface("01370539", httpInvokeId);

                JavaRDD<AoiChangedWb> rddFinal = rddGetAoi.union(rddExistAoi).persist(StorageLevel.MEMORY_AND_DISK_SER());
                log.error("待入库的运单数据量：{} ------------", rddFinal.count());
                rddFinal.take(3).forEach(o -> log.error("待入库的运单详细信息：{}", o.toString()));
                rddGetAoi.unpersist();

                if (HttpInvokeUtil.isCanInvoke(invokeStartTm, invokeEndTm)) {
                    DataUtil.saveOverwrite(si, "dm_gis.dwb_wb_aoi_changed_pu_ks_mi", AoiChangedWb.class, rddFinal, "inc_day");
                } else {
                    DataUtil.saveOverwrite(si, "dm_gis.dwb_wb_aoi_changed_pu_ks_cache", AoiChangedWb.class, rddFinal, "inc_day");
                    log.error("当前完成的城市为： {}， 当前时间已经不在跑数时间内，程序即将结束！！！", cityCode);
                    break;
                }
            } else {
                log.error("未执行的城市为：{}， 当前时间不在跑数时间内，程序即将结束！！！", cityCode);
                break;
            }
            si.getSession().catalog().clearCache();
        }
        log.error("end loadPuNewAoiByKs: aoiStartDate - {}, aoiEndDate - {}, cityCodes - {}, threadCount - {}", aoiStartDate, aoiEndDate, cityCodes, threadCount);
    }

    private static String getKey2MultiAoi(AoiChangedWb o) {
        return (StringUtils.isNotEmpty(o.getProvince()) ? o.getProvince() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getCityCode()) ? o.getCityCode() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getCounty()) ? o.getCounty() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getAddr()) ? o.getAddr() : "1") + "_";
    }

    private static String getKey2Atsh(AoiChangedWb o) {
        return (StringUtils.isNotEmpty(o.getProvince()) ? o.getProvince() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getCityCode()) ? o.getCityCode() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getCounty()) ? o.getCounty() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getAddr()) ? o.getAddr() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getPhone()) ? o.getPhone() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getMobile()) ? o.getMobile() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getCompName()) ? o.getCompName() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getContName()) ? o.getContName() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getFmAcctCode()) ? o.getFmAcctCode() : "1") + "_";
    }

    private static String getKey2Ks(AoiChangedWb o) {
        return (StringUtils.isNotEmpty(o.getProvince()) ? o.getProvince() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getCityCode()) ? o.getCityCode() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getCounty()) ? o.getCounty() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getNewZc()) ? o.getNewZc() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getAddr()) ? o.getAddr() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getPhone()) ? o.getPhone() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getMobile()) ? o.getMobile() : "1") + "_" +
                (StringUtils.isNotEmpty(o.getCompName()) ? o.getCompName() : "1") + "_";
    }

    private static AoiChangedWb getAcw(String key) {
        AoiChangedWb acw = new AoiChangedWb();
        try {
            String[] keyArr = key.split("_");
            acw.setProvince(chkKey(keyArr[0]));
            acw.setCityCode(chkKey(keyArr[1]));
            acw.setCounty(chkKey(keyArr[2]));
            acw.setAddr(chkKey(keyArr[3]));
            acw.setPhone(chkKey(keyArr[4]));
            acw.setMobile(chkKey(keyArr[5]));
            acw.setCompName(chkKey(keyArr[6]));
            acw.setContName(chkKey(keyArr[7]));
            acw.setFmAcctCode(chkKey(keyArr[8]));
        } catch (Exception e) {
            log.error("getAcw execute error. key - {}, e - {}", key, e.getStackTrace());
        }
        return acw;
    }

    private static String chkKey(String key) {
        String rs = "";
        if (!"1".equals(key)) {
            rs = key;
        }
        return rs;
    }

    private static Map<String, Long> getCityCntMap(List<String> zcList) {
        Map<String, Long> cityMap = new HashMap<>();
        String city;
        for (String zc : zcList) {
            if (StringUtils.isNotEmpty(zc)) {
                city = getCityByZc(zc);
                if (StringUtils.isNotEmpty(city)) {
                    if (cityMap.get(city) != null) {
                        cityMap.put(city, cityMap.get(city) + 1);
                    } else {
                        cityMap.put(city, 1L);
                    }
                }
            }
        }
        return cityMap;
    }

    private static String getMaxCntCity(Map<String, Long> cityMap) {
        String maxCity = null;
        long maxCityCnt = -1;
        for(String city : cityMap.keySet()) {
            if (maxCity == null) {
                maxCity = city;
                maxCityCnt = cityMap.get(city);
            } else {
                if (cityMap.get(city) > maxCityCnt) {
                    maxCity = city;
                }
            }
        }
        return maxCity;
    }

    private static String getCityByZc(String zc) {
        String city = null;
        if (StringUtils.isNotEmpty(zc)) {
            String regex = "\\d+";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(zc);
            if (m.find() && zc.startsWith(m.group(0))) {
                city = m.group(0);
            }
        }
        return city;
    }
}
