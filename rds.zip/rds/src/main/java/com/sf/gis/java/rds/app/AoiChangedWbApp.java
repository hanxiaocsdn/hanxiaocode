package com.sf.gis.java.rds.app;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.rds.common.AoiConstant;
import com.sf.gis.java.rds.controller.AoiChangedWbController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * aoi件量预测模型-AOI变更运单分析
 * @author 01370539 YY
 * created on Oct.23
 */
public class AoiChangedWbApp {
    private static final Logger log = LoggerFactory.getLogger(AoiChangedWbApp.class);


    public static void main(String[] args) {
        log.error(">>>>>>>> start <<<<<<<<");
        String nodeType;
        String aoiStartDate;
        String aoiEndDate;
        String isInitAoi;
        String cityCodes;
        if (args.length >= 5) {
            nodeType = args[0];
            aoiStartDate = args[1];
            aoiEndDate = args[2];
            if (AoiConstant.WB_CNT_MD_NODE_AOI_CHANGED_WB.equals(nodeType)) {
                isInitAoi = args[3];
                cityCodes = args[4];
                String wbStartDate = args[5];
                String wbEndDate = args[6];
                new AoiChangedWbController().loadAoiChangedWb(isInitAoi, cityCodes, aoiStartDate, aoiEndDate, wbStartDate, wbEndDate);
            } else if (AoiConstant.WB_CNT_MD_NODE_WB_NEW_AOI_ATSH.equals(nodeType)) {
                cityCodes = args[3];
                int threadCount = Integer.parseInt(args[4]);
                long invokeStartTm = Long.parseLong(args[5]);
                long invokeEndTm = Long.parseLong(args[6]);
                new AoiChangedWbController().loadPuNewAoiByAtShou(aoiStartDate, aoiEndDate, cityCodes, threadCount, invokeStartTm, invokeEndTm);
            } else if (AoiConstant.WB_CNT_MD_NODE_WB_NEW_AOI_KS.equals(nodeType)) {
                cityCodes = args[3];
                int threadCount = Integer.parseInt(args[4]);
                long invokeStartTm = Long.parseLong(args[5]);
                long invokeEndTm = Long.parseLong(args[6]);
                new AoiChangedWbController().loadPuNewAoiByKs(aoiStartDate, aoiEndDate, cityCodes, threadCount, invokeStartTm, invokeEndTm);
            }
        }
        log.error(">>>>>>>> end <<<<<<<<");
    }
}
