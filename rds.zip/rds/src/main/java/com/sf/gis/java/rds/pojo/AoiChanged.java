package com.sf.gis.java.rds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiChanged implements Serializable {
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "is_changed")
    private String isChanged;
    @Column(name = "inc_day")
    private String incDay;

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getIsChanged() {
        return isChanged;
    }

    public void setIsChanged(String isChanged) {
        this.isChanged = isChanged;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "AoiChanged{" +
                "aoiId='" + aoiId + '\'' +
                ", isChanged='" + isChanged + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
