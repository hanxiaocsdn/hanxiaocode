package com.sf.gis.java.rds.common;

import java.util.HashMap;
import java.util.Map;

public class AoiConstant {

    public static final String WB_CNT_MD_NODE_AOI_CHANGED_WB = "1";  // 获取aoi变更的运单
    public static final String WB_CNT_MD_NODE_WB_NEW_AOI_ATSH = "2";  // 运单通过AT收获取新的aoi
    public static final String WB_CNT_MD_NODE_WB_NEW_AOI_KS = "3";  // 运单通过KS获取新的aoi

    public static final Map<String, Integer> whiteMap = new HashMap<>();
    private static final String[] whiteArr = new String[]{"B8C948C3E4EB433DB2A6DEDF7ED7D5BF","68D84AAF83013182E0530EF4520AB906"};

    static {
        for (int i = 0; i < whiteArr.length; i++) {
            whiteMap.put(whiteArr[i], i);
        }
    }

}
