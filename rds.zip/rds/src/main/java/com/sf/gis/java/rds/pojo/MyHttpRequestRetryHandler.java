package com.sf.gis.java.rds.pojo;

import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpRequest;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.protocol.HttpContext;

import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

public class MyHttpRequestRetryHandler implements HttpRequestRetryHandler {
    private int executionCount;
    private long retryInterval;

    MyHttpRequestRetryHandler(Builder builder) {
        this.executionCount = builder.executionCount;
        this.retryInterval = builder.retryInterval;
    }


    @Override
    public boolean retryRequest(IOException exception, int executionCount, HttpContext httpContext) {
        System.out.println("retryRequest:"+executionCount);

        if (executionCount >= this.executionCount)
            return false;

        if (exception instanceof ConnectTimeoutException
                || exception instanceof NoHttpResponseException
                || exception instanceof SocketTimeoutException
                || !(exception instanceof UnknownHostException)
                || !(exception instanceof InterruptedIOException)
                || !(exception instanceof SSLException)
                || !(exception instanceof SSLHandshakeException)
        )
            return true;
        else
            System.out.println("未记录的请求异常：" + exception.getClass());


        HttpClientContext clientContext = HttpClientContext.adapt(httpContext);
        HttpRequest request = clientContext.getRequest();
        boolean idempotent = ! ( request instanceof HttpEntityEnclosingRequest );
        if (idempotent)
            // 如果请求被认为是幂等的，那么就重试。即重复执行不影响程序其他效果的
            return true;

        return false;
    }

    public static final class Builder {
        public int executionCount;
        public long retryInterval;

        public Builder() {
            executionCount = 3;
            retryInterval = 1000;
        }

        public Builder executionCount(int executionCount) {
            this.executionCount = executionCount;
            return this;
        }

        public Builder retryInterval(long retryInterval) {
            this.retryInterval = retryInterval;
            return this;
        }

        public MyHttpRequestRetryHandler build() {
            return new MyHttpRequestRetryHandler(this);
        }
    }
}
