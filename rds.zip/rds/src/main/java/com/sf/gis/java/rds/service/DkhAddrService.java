package com.sf.gis.java.rds.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.rds.pojo.*;
import org.apache.spark.api.java.JavaRDD;

/**
 * 大客户地址数据挖掘
 * @author 01370539 YY
 * Created on Oct.25
 */
public class DkhAddrService {

    public JavaRDD<DkhArsInfo> loadBspData(SparkInfo si) {
        String sql = "select distinct(address) address, 'bsp' src from dm_gis.ods_bsp_dkh_addr ";
        return DataUtil.loadData(si, sql, DkhArsInfo.class);
    }

    public JavaRDD<AddrPojo> statDlvByMonth(SparkInfo si, String month) {
        String sql = "select consignee_addr addr, 'dlv' addr_type, count(1) cnt, sum(freight_rmb) freight_rmb, '" + month + "' inc_day from dm_gis.dwd_waybill_info_dtl_di where inc_day like '" + month + "%' group by consignee_addr";
        return DataUtil.loadData(si, sql, AddrPojo.class);
    }

    public JavaRDD<AddrPojo> statPuByMonth(SparkInfo si, String month) {
        String sql = "select consignor_addr addr, 'pu' addr_type, count(1) cnt, sum(freight_rmb) freight_rmb, '" + month + "' inc_day from dm_gis.dwd_waybill_info_dtl_di where inc_day like '" + month + "%' group by consignor_addr";
        return DataUtil.loadData(si, sql, AddrPojo.class);
    }

    public JavaRDD<DkhRdsInfo> getInitAddr4Rds(SparkInfo si, String startMonth, String endMonth) {
        String sql = "select addr, phone, comp_name, aoi_id, aoi_src, ttl_cnt, ttl_freight, cnt, freight from (select addr, phone, comp_name, aoi_id, aoi_src, ttl_cnt, ttl_freight, cnt, freight, ROW_NUMBER() OVER(PARTITION BY addr ORDER BY cnt desc) AS rn from dm_gis.dwd_dkh_addr_src_stat_mi where inc_day between '" + startMonth + "' and '" + endMonth + "' and (ttl_cnt >= 1000 or ttl_freight >= 10000) and addr is not null and addr != '') t where t.rn = 1 " +
                "union select distinct addr, '' phone, '' comp_name, '' aoi_id, '' aoi_src, '' ttl_cnt, '' ttl_freight, '' cnt, '' freight from dm_gis.dwd_dkh_addr_stat_mi where inc_day between '" + startMonth + "' and '" + endMonth + "' and is_hit_bsp = 'Y'";
        return DataUtil.loadData(si, sql, DkhRdsInfo.class);
    }

    public JavaRDD<DkhRdsInfo> getRdsDkh(SparkInfo si, String incDay) {
        String sql = "select * from dm_gis.dwd_dkh_rds_mf where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, DkhRdsInfo.class);
    }

    public JavaRDD<DkhInfo> loadPuAddrFromNewWbByMonth(SparkInfo si, String month) {
        String sql = "select src_province province, src_dist_code city_code, src_city_name city_name, src_county county, consignor_addr_decrypt addr, freight_monthly_acct_code fm_acct_code, freight_payment_type_code fp_type_code, freight_settlement_type_code fs_type_code, freight_payment_change_type_code fp_change_type_code, freight_rmb freight, 'Y' is_wb_pu, inc_day from dm_gis.dwd_waybill_info_dtl_di where inc_day like '" + month + "%'";
        return DataUtil.loadData(si, sql, DkhInfo.class);
    }

    public JavaRDD<DkhInfo> loadPuAddrFromOldWbByMonth(SparkInfo si, String month) {
        String sql = "select src_province province, src_dist_code city_code, src_city_code city_name, src_county county, consignor_addr addr, freight_monthly_acct_code fm_acct_code, freight_payment_type_code fp_type_code, freight_settlement_type_code fs_type_code, freight_payment_change_type_code fp_change_type_code, freight_rmb freight, 'Y' is_wb_pu, inc_day from dm_gis.dwd_waybill_info_old_dtl_di where inc_day like '" + month + "%'";
        return DataUtil.loadData(si, sql, DkhInfo.class);
    }

    public JavaRDD<DkhInfo> loadDlvAddrFromNewWbByMonth(SparkInfo si, String month) {
        String sql = "select dest_province province, dest_dist_code city_code, dest_city_name city_name, dest_county county, consignee_addr_decrypt addr, freight_monthly_acct_code fm_acct_code, freight_payment_type_code fp_type_code, freight_settlement_type_code fs_type_code, freight_payment_change_type_code fp_change_type_code, freight_rmb freight, 'Y' is_wb_dlv, inc_day from dm_gis.dwd_waybill_info_dtl_di where inc_day like '" + month + "%'";
        return DataUtil.loadData(si, sql, DkhInfo.class);
    }

    public JavaRDD<DkhInfo> loadDlvAddrFromOldWbByMonth(SparkInfo si, String month) {
        String sql = "select dest_province province, dest_dist_code city_code, dest_city_code city_name, dest_county county, consignee_addr addr, freight_monthly_acct_code fm_acct_code, freight_payment_type_code fp_type_code, freight_settlement_type_code fs_type_code, freight_payment_change_type_code fp_change_type_code, freight_rmb freight, 'Y' is_wb_dlv, inc_day from dm_gis.dwd_waybill_info_old_dtl_di where inc_day like '" + month + "%'";
        return DataUtil.loadData(si, sql, DkhInfo.class);
    }
    
    public JavaRDD<DkhArsInfo> getInitAddr4Ars(SparkInfo si, String startMonth, String endMonth) {
        String sql = "select tt.addr address, IF(size(tt.src_set) >= 2, 'stat_both', tt.src_set[0]) as src from " +
                "(select t.addr, collect_set(IF(t.cnt >= 100, IF(t.freight_rmb >= 10000, 'stat_both', 'stat_num'), 'stat_frei')) as src_set from " +
                "(select addr, sum(cnt) cnt, sum(freight_rmb) freight_rmb, inc_day  from dm_gis.dwd_dkh_addr_stat_mi where inc_day >= '" + startMonth + "' and inc_day <= '" + endMonth + "' and addr != '' and addr is not null group by inc_day, addr) t " +
                "where t.cnt >= 100 or t.freight_rmb >= 10000 group by t.addr) tt";
        return DataUtil.loadData(si, sql, DkhArsInfo.class);
    }

    public JavaRDD<DkhArsInfo> getArsDkh(SparkInfo si, String incDay) {
        String sql = "select * from dm_gis.dwd_dkh_ars_mf where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, DkhArsInfo.class);
    }
}
