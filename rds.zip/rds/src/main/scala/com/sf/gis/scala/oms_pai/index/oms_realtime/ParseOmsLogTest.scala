package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.net.{URLDecoder, URLEncoder}
import java.text.DecimalFormat

import com.alibaba.fastjson.JSONObject

import scala.util.matching.Regex

object ParseOmsLogTest {

  def getKeyByStr(waybillNo: String): String = {
    var salt = (waybillNo.hashCode() % 30).toString.replace("-", "")
    val df = new DecimalFormat("00")
    if (salt.length == 1) {
      //个位数前面需要补0
      salt = df.format(Integer.parseInt(salt))
    }
    val key = salt + "_" + waybillNo
    key
  }
  def main(args: Array[String]): Unit = {
    print(URLEncoder.encode("广东省深圳市龙华区东环二路企生活人工智能华盛园2楼-ZY","utf-8"))
    val dd111 = "ddd?dd"
    println(dd111.split("\\?")(1))
    val json = new JSONObject()
    json.put("x",124.44)
    json.put("y",1245)
    val tmp = new JSONObject()
    tmp.put("tmp",json)
    println(tmp.getString("tmp"))
    val dd = "%E5%B1%B1%E4%B8%9C%E7%9C%81%E8%81%8A%E5%9F%8E%E5%B8%82%E4%B8%B4%E6%B8%85%E5%B8%82%E5%88%98%E5%9E%93%E5%AD%90%E9%95%87%E6%94%BF%E5%BA%9C888%E5%8F%B7"
    println(URLDecoder.decode(dd,"utf-8"))


    val splitresult = "广东省^11,深圳市^12,罗湖区^13,罗湖^03,水贝茂名大厦^113,10楼^216,左边^118;16"
    val address = splitresult.toUpperCase()
    val strings = address.split("\\|")
    var last613 = ""
    var last14 = ""
    var last13 = ""
    var key_tag = ""
    var key_word = ""
    var key_level = ""
    for (i <- Range(0, strings.length).reverse) {
      val pattern613 = new Regex(".*\\^613")
      if (pattern613.findFirstIn(strings(i)) != None) {
        if ("".equals(last613)) {
          last613 = strings(i).split("\\^")(0)
        }
      }
      val pattern14 = new Regex(".*\\^[1-5]14")
      if (pattern14.findFirstIn(strings(i)) != None)
        if ("".equals(last14)) {
          var str2 = strings(i)
          last14 = str2.split("\\^")(0)
        }

      val pattern13 = new Regex(".*\\^[1-5]13")
      if (pattern13.findFirstIn(strings(i)) != None) {
        if ("".equals(last13))
          last13 = strings(i).split("\\^")(0)
      }

    }
    println(last13)
  }
}
