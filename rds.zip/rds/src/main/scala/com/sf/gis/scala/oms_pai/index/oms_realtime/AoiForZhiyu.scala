package com.sf.gis.scala.oms_pai.index.oms_realtime

import com.alibaba.fastjson.{JSON, JSONObject}
import com.csvreader.CsvReader
import com.sf.gis.scala.base.spark.SparkWrite
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.oms_pai.start.JavaUtil
import com.sf.gis.scala.utils.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01374443 on 2019/3/5.
 * 任务id:225137
 * 任务名称：派件日志aoi-智域
 * 业务：蓝媛青
 * 开发：张想远
 */
object AoiForZhiyu {
  @transient lazy val logger: Logger = Logger.getLogger(AoiForZhiyu.getClass)
  // 生成的两种类型, 包含在json对象中
  val fields = Array("waybillNo", "orderNo", "addresseeCityCode", "receiverProvince", "receiverCity", "receiverArea", "receiverAddr", "addresseeAddr", "addresseeCompName", "addresseeMobile", "addresseePhone", "addresseeContacts", "reqTime", "addresseeDeptCode", "addresseeTeamCode", "addresseeAoiCode", "aoiParentCode")
  val omsToArray = Array("waybillNo", "req_body", "reqTime", "addresseeDeptCode", "addresseeTeamCode", "gisAoiCode", "ksAoiCode", "finalAoiCode", "inc_day")
  val reqBodyKey = Array("orderNo", "destCityCode", "receiverProvince", "receiverCity", "receiverArea", "receiverAddr", "addresseeAddr", "addresseeCompName", "addresseeMobile", "addresseePhone", "addresseeContacts")

  val javaUtil = new JavaUtil(6) //6表示路由分单 1表示测试
  var incDay: String = Util.dateDelta(-1, "")
  val appName = "AoiForZhiyu"


  def main(args: Array[String]): Unit = {
    if (args.length > 0) {
      incDay = args(0)
    }
    logger.error("incDay:" + incDay)
    start()
  }

  def start(): Unit = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    //高峰期
//    conf.set("spark.executor.instances", "30")
//    conf.set("spark.executor.cores", "4")
//    conf.set("spark.executor.memory", "10g")

    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    fetchAoi(spark)
  }

  def getCmsDept: Map[String, String] = {
    val cityCodes = "010,511,514,519,660,663,754,852,768,411,415,769,757,758,766,591,593,598,599,930,931,932,933,934,935,936,937,938,939,941,943,970,971,972,973,974,975,976,977,979,701,791,792,793,798,790,794,795,796,797,799,770,771,772,773,774,775,776,777,778,779,020,751,763,052,053,851,854,855,856,857,858,859,898,8981,451,452,453,454,455,456,457,458,459,464,467,468,469,470,027,710,711,712,713,714,715,716,717,718,719,722,724,728,752,753,762,431,432,433,434,435,436,437,438,439,482,530,531,534,537,538,634,635,313,314,315,316,317,335,310,311,312,318,319,570,578,579,532,535,631,533,536,539,543,546,632,633,025,513,515,471,472,473,474,475,476,477,478,479,483,574,580,951,952,953,954,955,594,595,592,596,597,349,350,351,352,353,354,355,356,357,358,359,029,911,912,913,914,915,916,917,919,021,755,024,412,414,416,417,418,419,421,427,429,028,812,813,816,817,818,825,826,827,830,831,832,833,834,835,836,837,838,839,891,892,893,894,895,896,516,517,518,527,512,576,022,551,552,554,557,558,561,564,550,553,555,556,559,562,563,566,577,510,523,730,7311,7312,7313,734,735,736,737,738,739,743,744,745,746,901,902,903,906,908,909,990,991,992,993,994,995,996,997,998,999,370,371,372,373,378,391,392,393,374,375,376,377,379,394,395,396,398,662,668,750,756,759,760,086,088,691,692,870,871,872,873,874,875,876,877,878,879,883,887,571,572,573,575,023"
    val cityCodeArray = cityCodes.split(",")
    var retMap: Map[String, String] = Map()
    val url = "http://gis-cms-bg.sf-express.com/cms/api/zno/getZnoBySzDepart?cityCode=%s"
    for (cityCode <- cityCodeArray) {
      val urlStr = String.format(url, cityCode)
      logger.error(urlStr)
      try {
        val ret = HttpClientUtil.getJsonByGet(urlStr)
        val data = ret.getJSONArray("data")
        for (i <- 0 until data.size()) {
          val item = data.getJSONObject(i)
          retMap += (item.getString("znoCode") -> item.getString("departCode"))
        }

      } catch {
        case e: Exception => logger.error(e)
      }
    }
    logger.error("cmsDeptMap size:" + retMap.size)
    retMap
  }

  def fillParentData(sc: SparkContext, aoiRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val virtualDept = getVirtualDeptList
    val cmsDeptMap = getCmsDept
    logger.error("cmsDeptCount:" + cmsDeptMap.size)
    val virtualDeptBc = sc.broadcast(virtualDept)
    val cmsDeptMapBc = sc.broadcast(cmsDeptMap)
    aoiRdd.map(obj => {
      val addresseeDeptCode = JSONUtil.getJsonVal(obj, "addresseeDeptCode", "")
      var addresseeAoiCode = JSONUtil.getJsonVal(obj, "addresseeAoiCode", "")
      if (addresseeAoiCode.isEmpty && virtualDeptBc.value.contains(addresseeDeptCode)) {
        addresseeAoiCode = addresseeDeptCode + "999999"
        obj.put("addresseeAoiCode", addresseeAoiCode)
      }
      var aoiParentCode = ""
      if (addresseeAoiCode.length > 6) {
        val aoiDept = addresseeAoiCode.substring(0, addresseeAoiCode.length - 6)
        if (cmsDeptMapBc.value.contains(aoiDept)) {
          aoiParentCode = cmsDeptMapBc.value.apply(aoiDept)
        }
      }
      obj.put("aoiParentCode", aoiParentCode)
      obj
    })
  }

  /**
   * 处理缺失数据
   *
   * @param spark : spark session
   */
  def fetchAoi(spark: SparkSession): Unit = {
    logger.error(">>>get aoi data")
    val aoiRdd = getAoiData(spark, incDay)
    logger.error(">>>fill aoi parent data ")
    val aoiParentRdd = fillParentData(spark.sparkContext, aoiRdd).persist(StorageLevel.DISK_ONLY_2)
    logger.error(s">>>aoi num ${aoiParentRdd.count()}")
    logger.error(">>>save aoi data start")
    saveAoiData(spark, aoiParentRdd, incDay)
  }

  def getVirtualDeptList: ArrayBuffer[String] = {
    val list = new ArrayBuffer[String]
    val xiaogePath = System.getProperty("user.dir") + "/virtual_dept.csv"
    val csvReader = new CsvReader(xiaogePath)
    if (csvReader.readRecord()) println("headers:" + csvReader.getValues.mkString(","))
    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val deptcode = row(0)
      if (deptcode != null && !deptcode.isEmpty) {
        list += deptcode
      }
    }
    logger.error("虚拟网点数量:" + list.size)
    list
  }

  /**
   * 查询缺失数据
   *
   * @param spark  : spark session
   * @param incDay : 日期
   * @return
   */
  def getAoiData(spark: SparkSession, incDay: String): RDD[JSONObject] = {
    val hiveTableName = "dm_gis.gis_rds_omsto"
    val sql =
      s"""select * from(
         |select req_waybillno,req_body,req_time,finalzc,finaltc,gisAoiCode,ksAoiCode,finalAoiCode,inc_day,row_number() over(partition BY req_waybillno
         | order by req_time desc ) as rank from $hiveTableName where inc_day = '$incDay'and req_waybillno<> ''
         | )a where a.rank=1 """.stripMargin
    logger.error(">>>aoi sql :" + sql)
    val rdd = spark.sql(sql).rdd.map(row => {
      val obj = new JSONObject()
      for (i <- omsToArray.indices) {
        obj.put(omsToArray(i), row.getString(i))
      }
      val addresseeTeamCode = obj.getString("addresseeTeamCode")
      if (addresseeTeamCode != null && addresseeTeamCode.equals("null")) {
        obj.put("addresseeTeamCode", "")
      }
      val reqBody = obj.getString("req_body")
      if (reqBody != null && !reqBody.isEmpty) {
        try {
          val reqBodyJson = JSON.parseObject(reqBody)
          for (i <- reqBodyKey.indices) {
            if (reqBodyKey(i).equals("destCityCode")) {
              obj.put("addresseeCityCode", JSONUtil.getJsonVal(reqBodyJson, reqBodyKey(i), ""))
            } else {
              obj.put(reqBodyKey(i), JSONUtil.getJsonVal(reqBodyJson, reqBodyKey(i), ""))
            }
          }
        } catch {
          case e: Exception => logger.error(e)
        }
      }
      if (obj.getString("finalAoiCode") != null && !obj.getString("finalAoiCode").isEmpty) {
        obj.put("addresseeAoiCode", obj.getString("finalAoiCode"))
      } else if (obj.getString("gisAoiCode") != null && !obj.getString("gisAoiCode").isEmpty) {
        obj.put("addresseeAoiCode", obj.getString("gisAoiCode"))
      } else if (obj.getString("ksAoiCode") != null && !obj.getString("ksAoiCode").isEmpty) {
        obj.put("addresseeAoiCode", obj.getString("ksAoiCode"))
      } else {
        obj.put("addresseeAoiCode", "")
      }
      obj
    })
    rdd
  }

  def saveAoiData(spark: SparkSession, aoiRdd: RDD[JSONObject], incDay: String): Unit = {
    aoiRdd.take(3).foreach(obj => logger.error(obj))
    val rows = aoiRdd.map(obj => {
      val ret = new JSONObject()
      for (name <- fields) {
        var tmp = obj.getString(name)
        if (tmp == null) {
          tmp = ""
        }
        ret.put(name, tmp.replaceAll("[',\",\\r,\\n,\\t,\\\\]", ""))
      }
      ret
    })

    val tableName = "dm_gis.rds_omsto_aoi"
    SparkWrite.save2HiveStaticRandom(spark, rows, fields, tableName, Array(("inc_day", incDay)), 10)
  }
}
