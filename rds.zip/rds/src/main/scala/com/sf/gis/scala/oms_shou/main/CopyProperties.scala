package com.sf.gis.scala.oms_shou.main

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializerFeature
import com.sf.gis.scala.oms_shou.constant.VariableConstant
import com.sf.gis.scala.oms_shou.pojo.OrderData
import com.sf.gis.scala.oms_shou.pojo.arss.{ArssReBody, ArssReqBody}
import com.sf.gis.scala.oms_shou.pojo.errCall.ErrCallBody
import com.sf.gis.scala.oms_shou.pojo.rds.{OmsReBody, OmsReqBody, RdsArssReqBody, Tcs}
import org.slf4j.{Logger, LoggerFactory}

/**
 * Created by 01368078 on 2019/1/11.
 */
object CopyProperties {
  @transient lazy val logger: Logger = LoggerFactory.getLogger(CopyProperties.getClass)

  def main(args: Array[String]): Unit = {
    val xx: Tcs = null
    println(JSON.toJSONString(xx, SerializerFeature.PrettyFormat))

  }

  /**
   * 合并同步请求到订单信息
   *
   * @param orderData   : 订单数据
   * @param syncReqBody : 同步请求体
   */
  def syncReq2OrderData(orderData: OrderData, syncReqBody: OmsReqBody): Unit = {
    if (syncReqBody == null)
      return
    orderData.setSyncReqFlag(true)
    orderData.setSyncReqDateTime(syncReqBody.getDataTime)
    orderData.setSyncReqId(syncReqBody.getRequestId)
    //    orderData.setSyncNodeId(syncReqBody.getNodeId)
    orderData.setReqTime(syncReqBody.getDataTime)
    orderData.setReqDate(syncReqBody.getDataTime.split(" ")(0).replaceAll("-", ""))
  }

  /**
   * 合并异步请求到订单信息
   *
   * @param orderData    : 订单数据
   * @param asyncReqBody : 异步请求体
   */
  def asyncReq2OrderData(orderData: OrderData, asyncReqBody: OmsReqBody): Unit = {
    if (asyncReqBody == null)
      return
    orderData.setAsyncReqFlag(true)
    orderData.setAsyncReqDateTime(asyncReqBody.getDataTime)
    orderData.setAsyncReqId(asyncReqBody.getRequestId)
    //    orderData.setAsyncNodeId(asyncReqBody.getNodeId)
    if (orderData.getReqTime == null || "".equals(orderData.getReqTime)) {
      orderData.setReqTime(asyncReqBody.getDataTime)
      orderData.setReqDate(asyncReqBody.getDataTime.split(" ")(0).replaceAll("-", ""))
    }
  }

  /**
   * 合并同步返回到订单信息
   *
   * @param orderData  : 订单数据
   * @param syncReBody : 同步响应体
   */
  def syncRe2OrderData(orderData: OrderData, syncReBody: OmsReBody): Unit = {
    if (syncReBody == null)
      return
    orderData.setSyncReFlag(true)
    orderData.setSyncReDateTime(syncReBody.getDataTime)
    orderData.setSyncReStatus(syncReBody.getStatus)
    if (orderData.getReqTime == null || "".equals(orderData.getReqTime)) {
      orderData.setReqTime(syncReBody.getDataTime)
      orderData.setReqDate(syncReBody.getDataTime.split(" ")(0).replaceAll("-", ""))
    }
    if (
//      !(VariableConstant.SUCCESS_STATUS.equals(syncReBody.getStatus) || VariableConstant.UNMATCH_STATUS.equals(syncReBody.getStatus) ) ||
      syncReBody.getRet == null) //返回数据为空或者识别不了
      return

    val omsSyncRet = syncReBody.getRet
    orderData.setSyncSrc(omsSyncRet.getSrc)
    orderData.setSyncGroupId(omsSyncRet.getGroupid)
    orderData.setMatchSrc(omsSyncRet.getSrc)
    orderData.setMatchGroupId(omsSyncRet.getGroupid)

    val atSrvRet = omsSyncRet.getAtSrvRet
    if (atSrvRet == null) //at返回为空
      return
    val tcs = atSrvRet.getTcs
    if (tcs == null)
      return
    orderData.setSyncTeamCode(tcs.getTeam)
    orderData.setSyncDeptCode(tcs.getDept)
    orderData.setSyncAoiCode(tcs.getAoicode)
    orderData.setSyncAoiId(tcs.getAoiid)
    orderData.setSyncTcs(tcs)
    orderData.setMatchTeamCode(tcs.getTeam)
    orderData.setMatchDeptCode(tcs.getDept)

    val other = tcs.getOther
    if (other == null)
      return
    orderData.setSyncChkDeptSrc(other.getChkdeptsrc)
    orderData.setSyncChkTcSrc(other.getChktcsrc)
    orderData.setSyncTc2GeoSrc(other.getGeosrc)
    orderData.setSyncTc2Gid(other.getTc2gid)
    orderData.setMatchChkDeptSrc(other.getChkdeptsrc)
    orderData.setMatchChkTcSrc(other.getChktcsrc)
    orderData.setMatchTc2GeoSrc(other.getGeosrc)
    orderData.setMatchTc2Gid(other.getTc2gid)

  }

  /**
   * 和异步返回到订单信息
   *
   * @param orderData   : 订单数据
   * @param asyncReBody : 异步响应体
   */
  def asyncRe2OrderData(orderData: OrderData, asyncReBody: OmsReBody): Unit = {
    if (asyncReBody == null)
      return
    orderData.setAsyncReFlag(true)
    orderData.setAsyncReDateTime(asyncReBody.getDataTime)
    orderData.setAsyncReStatus(asyncReBody.getStatus)
    if (orderData.getReqTime == null || "".equals(orderData.getReqTime)) {
      orderData.setReqTime(asyncReBody.getDataTime)
      orderData.setReqDate(asyncReBody.getDataTime.split(" ")(0).replaceAll("-", ""))
    }
    if (!VariableConstant.SUCCESS_STATUS.equals(asyncReBody.getStatus) || asyncReBody.getRet == null) //返回数据为空或者识别不了
      return

    val omsAsyncRet = asyncReBody.getRet
    orderData.setAsyncSrc(omsAsyncRet.getSrc)
    orderData.setAsyncGroupId(omsAsyncRet.getGroupid)
    orderData.setMatchSrc(omsAsyncRet.getSrc)
    orderData.setMatchGroupId(omsAsyncRet.getGroupid)

    val atSrvRet = omsAsyncRet.getAtSrvRet
    if (atSrvRet == null) //at返回为空
      return
    val tcs = atSrvRet.getTcs
    if (tcs == null)
      return
    orderData.setAsyncTeamCode(tcs.getTeam)
    orderData.setAsyncDeptCode(tcs.getDept)
    orderData.setAsyncAoiCode(tcs.getAoicode)
    orderData.setAsyncTcs(tcs)
    orderData.setMatchTeamCode(tcs.getTeam)
    orderData.setMatchDeptCode(tcs.getDept)
    orderData.setAsyncAoiId(tcs.getAoiid)
    val other = tcs.getOther
    if (other == null)
      return
    orderData.setAsyncChkDeptSrc(other.getChkdeptsrc)
    orderData.setAsyncChkTcSrc(other.getChktcsrc)
    orderData.setAsyncTc2GeoSrc(other.getGeosrc)
    orderData.setAsyncTc2Gid(other.getTc2gid)
    orderData.setMatchChkDeptSrc(other.getChkdeptsrc)
    orderData.setMatchChkTcSrc(other.getChktcsrc)
    orderData.setMatchTc2GeoSrc(other.getGeosrc)
    orderData.setMatchTc2Gid(other.getTc2gid)

  }

  /**
   * 合并oms请求订单信息
   *
   * @param orderData  : 订单数据
   * @param omsReqData : oms请求数据
   */
  def omsReqData2OrderData(orderData: OrderData, omsReqData: OmsReqBody): Unit = {
    if (omsReqData == null) //oms请求数据为空
      return

    //    orderData.setAk(omsReqArgs.getAk)
    //    orderData.setUrl(omsReqArgs.getUrl)
    //    orderData.setRemoteIp(omsReqArgs.getRemoteIp)
    orderData.setSysCode(omsReqData.getSysCode)
    //    orderData.setSno(omsReqArgs.getSno)

    val omsOrderInfo = omsReqData.getOrderInfo
    if (omsOrderInfo == null)
      return
    orderData.setOrderType(omsOrderInfo.getOrderType)
    orderData.setSysSource(omsOrderInfo.getSysSource)
    orderData.setLimitTypeCode(omsOrderInfo.getLimitTypeCode)
    orderData.setPayType(omsOrderInfo.getPayType)
    orderData.setPickupType(omsOrderInfo.getPickupType)
    orderData.setBookingType(omsOrderInfo.getBookingType)
    orderData.setCargoTypeCode(omsOrderInfo.getCargoTypeCode)
    orderData.setExpressTypeCode(omsOrderInfo.getExpressTypeCode)
    orderData.setWeight(omsOrderInfo.getWeight)
    orderData.setClientCode(omsOrderInfo.getClientCode)
    orderData.setOrderNo(omsOrderInfo.getOrderNo)
    orderData.setIsNotUnderCall(omsOrderInfo.getIsNotUnderCall);
    val omsOrderFromToList = omsOrderInfo.getOrderFromToList
    if (omsOrderFromToList == null || omsOrderFromToList.getOrderFrom == null)
      return
    val orderFrom = omsOrderFromToList.getOrderFrom
    orderData.setCountryCode(orderFrom.getCountryCode)
    orderData.setCountryCode(orderFrom.getCountryCode)
    orderData.setProvince(orderFrom.getProvince)
    orderData.setCity(orderFrom.getCity)
    orderData.setCityCode(orderFrom.getCityCode)
    orderData.setCounty(orderFrom.getCounty)
    orderData.setAddress(orderFrom.getAddress)
    orderData.setCustomerAccount(orderFrom.getCustomerAccount)
    orderData.setCustomerId(orderFrom.getCustomerId)
    orderData.setContactsName(orderFrom.getContactsName)
    orderData.setCompany(orderFrom.getCompany)
    orderData.setPhone(orderFrom.getPhone)
    orderData.setMobile(orderFrom.getMobile)
    orderData.setWaybillNo(orderFrom.getWaybillNo)
  }

  /**
   * 合并rds请求arss到订单信息
   *
   * @param orderData      : 订单数据
   * @param rdsArssReqBody : 审补请求数据
   */
  def rdsArssReq2OrderData(orderData: OrderData, rdsArssReqBody: RdsArssReqBody): Unit = {
    if (rdsArssReqBody == null)
      return
    orderData.setRdsArssReqFlag(true)
    orderData.setRdsArssReqDateTime(rdsArssReqBody.getDataTime)
    if (orderData.getReqTime == null || "".equals(orderData.getReqTime)) {
      orderData.setReqTime(rdsArssReqBody.getDataTime)
      orderData.setReqDate(rdsArssReqBody.getDataTime.split(" ")(0).replaceAll("-", ""))
    }

    if (rdsArssReqBody.getProducerArssInfo == null)
      return
    val producerArssInfo = rdsArssReqBody.getProducerArssInfo
    orderData.setSysOrderNo(producerArssInfo.getSysOrderNo)
    orderData.setOrderNo(producerArssInfo.getOrderNo)
    orderData.setCountryCode(producerArssInfo.getCountryCode)
    orderData.setProvince(producerArssInfo.getProvince)
    orderData.setCity(producerArssInfo.getCity)
    orderData.setCityCode(producerArssInfo.getCityCode)
    orderData.setCounty(producerArssInfo.getCounty)
    orderData.setAddress(producerArssInfo.getAddress)
    orderData.setCompany(producerArssInfo.getCompany)
    orderData.setPhone(producerArssInfo.getPhone)
    orderData.setMobile(producerArssInfo.getMobile)
    orderData.setWaybillNo(producerArssInfo.getWaybillNo)
    orderData.setAsyncReqId(producerArssInfo.getRequestId)
  }

  /**
   * 合并arss接收请求到订单信息
   *
   * @param orderData   : 订单数据
   * @param arssReqBody : 审补请求数据
   */
  def arssReq2OrderData(orderData: OrderData, arssReqBody: ArssReqBody): Unit = {
    if (arssReqBody == null)
      return
    orderData.setArssReqFlag(true)
    orderData.setArssReqNodeId(arssReqBody.getNodeId)
    orderData.setArssReqDataTime(arssReqBody.getDateTime)
    if (orderData.getReqTime == null || "".equals(orderData.getReqTime)) {
      orderData.setReqTime(arssReqBody.getDateTime)
      orderData.setReqDate(arssReqBody.getDateTime.split(" ")(0).replaceAll("-", ""))
    }
    val arssReqData = arssReqBody.getData
    if (arssReqData == null)
      return
    orderData.setSysOrderNo(arssReqData.getSysOrderNo)
    orderData.setOrderNo(arssReqData.getOrderNo)
    orderData.setCityCode(arssReqData.getCityCode)
    orderData.setAddress(arssReqData.getAddress)
    orderData.setProvince(arssReqData.getProvince)
    orderData.setCity(arssReqData.getCity)
  }

  /**
   * 合并arss返回到订单信息
   *
   * @param orderData  : 订单数据
   * @param arssReBody : 审补响应数据
   */
  def arssRe2OrderData(orderData: OrderData, arssReBody: ArssReBody): Unit = {
    if (arssReBody == null)
      return
    orderData.setArssReFlag(true)
    orderData.setArssReNodeId(arssReBody.getNodeId)
    orderData.setArssReDataTime(arssReBody.getDateTime)
    if (orderData.getReqTime == null || "".equals(orderData.getReqTime)) {
      orderData.setReqTime(arssReBody.getDateTime)
      orderData.setReqDate(arssReBody.getDateTime.split(" ")(0).replaceAll("-", ""))
    }
    val arssReData = arssReBody.getData
    if (arssReData == null)
      return

    orderData.setArssEmpCode(arssReData.getEmpCode)
    orderData.setSysOrderNo(arssReData.getSysOrderNo)
    orderData.setOrderNo(arssReData.getOrderNo)
    val orderFrom = arssReData.getOrderFrom
    if (orderFrom == null)
      return
    orderData.setArssDeptCode(orderFrom.getDeptCode)
    orderData.setArssTeamCode(orderFrom.getTeamCode)
    orderData.setArssAoiCode(orderFrom.getEntityAoiCode)
    orderData.setArssAoiId(orderFrom.getEntityAoiId)
    orderData.setCityCode(orderFrom.getCityCode)
    orderData.setAddress(orderFrom.getAddress)
    orderData.setProvince(orderFrom.getProvince)
    orderData.setCity(orderFrom.getCity)
  }

  /**
   * 合并错call到订单信息
   *
   * @param orderData   : 订单数据
   * @param errCallBody : 错call响应数据
   */
  def errCall2OrderData(orderData: OrderData, errCallBody: ErrCallBody): Unit = {
    if (errCallBody == null)
      return
    orderData.setErrCallFlag(true)
    orderData.setSysOrderNo(errCallBody.getOrderid)
    orderData.setErrCallAddrabb(errCallBody.getAddrabb)
    orderData.setErrCallAddrDept(errCallBody.getAddrDept)
    orderData.setErrCallAddrGroupid(errCallBody.getAddrGroupid)
    orderData.setErrCallAddrSrc(errCallBody.getAddrSrc)
    orderData.setErrCallAddrTeamCode(errCallBody.getAddrTeamCode)
    orderData.setErrCallCity(errCallBody.getCity)
    orderData.setErrCallCounty(errCallBody.getCounty)
    orderData.setErrCallEmpid(errCallBody.getEmpid)
    orderData.setErrCallEmptel(errCallBody.getEmptel)
    orderData.setErrCallProvince(errCallBody.getProvince)
    orderData.setErrCallResno(errCallBody.getResno)
    orderData.setErrCallTeamid(errCallBody.getTeamid)
    orderData.setErrCallDept(errCallBody.getDept)
    orderData.setErrCallDate(errCallBody.getErrCallDate)
    orderData.setErrCallTime(errCallBody.getCreateTime)
    orderData.setErrCallTcSouce(errCallBody.getTcSouce)
    orderData.setErrCallOperName(errCallBody.getOperName)
    if (orderData.getReqTime == null || "".equals(orderData.getReqTime)) {
      orderData.setReqTime(errCallBody.getCreateTime)
      orderData.setReqDate(errCallBody.getErrCallDate)
    }
  }
}
