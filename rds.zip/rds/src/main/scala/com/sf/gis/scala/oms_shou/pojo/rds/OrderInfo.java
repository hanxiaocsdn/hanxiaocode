package com.sf.gis.scala.oms_shou.pojo.rds;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/8.
 */
public class OrderInfo implements Serializable {
    private String orderType;
    private String sysSource;
    private String limitTypeCode;
    private String payType;
    private String pickupType;
    private String bookingType;
    private String sysOrderNo;
    private String orderNo;
    private String weight;
    private String cargoTypeCode;
    private String clientCode;
    private String expressTypeCode;
    private OrderFromToList orderFromToList;
    private String isNotUnderCall;
    public String getOrderType() {
        return orderType;
    }

    public String getIsNotUnderCall() {
        return isNotUnderCall;
    }

    public void setIsNotUnderCall(String isNotUnderCall) {
        this.isNotUnderCall = isNotUnderCall;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getSysSource() {
        return sysSource;
    }

    public void setSysSource(String sysSource) {
        this.sysSource = sysSource;
    }

    public String getLimitTypeCode() {
        return limitTypeCode;
    }

    public void setLimitTypeCode(String limitTypeCode) {
        this.limitTypeCode = limitTypeCode;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getBookingType() {
        return bookingType;
    }

    public void setBookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public String getSysOrderNo() {
        return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getCargoTypeCode() {
        return cargoTypeCode;
    }

    public void setCargoTypeCode(String cargoTypeCode) {
        this.cargoTypeCode = cargoTypeCode;
    }

    public String getClientCode() {
        return clientCode;
    }

    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    public String getExpressTypeCode() {
        return expressTypeCode;
    }

    public void setExpressTypeCode(String expressTypeCode) {
        this.expressTypeCode = expressTypeCode;
    }

    public OrderFromToList getOrderFromToList() {
        return orderFromToList;
    }

    public void setOrderFromToList(OrderFromToList orderFromToList) {
        this.orderFromToList = orderFromToList;
    }

    public String getPickupType() {
        return pickupType;
    }

    public void setPickupType(String pickupType) {
        this.pickupType = pickupType;
    }
}
