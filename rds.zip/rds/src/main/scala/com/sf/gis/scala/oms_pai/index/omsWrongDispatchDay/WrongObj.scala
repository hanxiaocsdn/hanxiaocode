package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

/**
  * Created by 01375125 on 2018/11/23.
  *
  */
object WrongObj {


  /**
    *
    * @param data_type
    * @param stat_date           统计日期（yyyyMMdd）
    * @param province            省份
    * @param region              大区
    * @param city                城市
    * @param city_code           城市编码
    * @param status              '返回状态（UNRESP：无返回；RESP：有返回但值为空或不可识别；REC：有返回可识别）',
    * @param status_detail       'STATUS为UNRESP和RESP时默认“-”；为REC时为其响应值的来源，包括：NORM、CHKE、CHKN、TC2、AUTO、PHONE、ROAD.',
    * @param fd                  当前维度下GIS的错分量
    * @param fd_unsame_sss       当前维度下GIS与SSS不一致中GIS的错分量
    * @param fd_final            当前维度下最终错分中GIS的错分量
    * @param fd_final_same_sss   当前维度下最终错分中与GIS与SSS一致的GIS的错分量
    * @param fd_final_unsame_sss 当前维度下最终错分中与GIS与SSS不一致的GIS的错分量
    * @param fd_final_sss_isnull 当前维度下最终错分中SSS为空的量下GIS的错分量
    * @param fd_final_arss_gis   当前维度下最终错分中审补为GIS的错分量
    */
  case class GisObj(
                     data_type: String,
                     stat_date: String,
                     province: String,
                     region: String,
                     city: String,
                     city_code: String,
                     status: String,
                     status_detail: String,
                     fd: Int,
                     fd_unsame_sss: Int,
                     fd_final: Int,
                     fd_final_same_sss: Int,
                     fd_final_unsame_sss: Int,
                     fd_final_sss_isnull: Int,
                     fd_final_arss_gis: Int
                   )


  /**
    *
    * @param data_type
    * @param stat_date             统计日期（yyyyMMdd）
    * @param province              省份
    * @param region                大区
    * @param city                  城市
    * @param city_code             城市编码
    * @param fd_gis_sss            当前维度GIS_SSS错分量
    * @param fd_gis                当前维度GIS错分量
    * @param fd_sss                当前维度SSS错分量
    * @param fd_arss               当前维度审补错分量
    * @param fd_gis_sss_uss        当前维度GIS和SSS网点不一致数据里SSS的错分量
    * @param fd_gis_sss_usg        当前维度GIS和SSS网点不一致数据里GIS的错分量
    * @param fd_gis_sss_usb        当前维度GIS和SSS网点不一致数据里GIS和SSS同时错分的错分量
    * @param fd_final              当前维度最终错分量
    * @param fd_final_gis          当前维度最终错分里GIS的错分量
    * @param fd_final_arss         当前维度最终错分里ARSS的错分量
    * @param fd_final_sss          当前维度最终错分里SSS的错分量
    * @param fd_final_sss_gisnull  当前维度最终错分里SSS错分中GIS为空的错分量
    * @param fd_final_sss_arss     当前维度最终错分里SSS错分中进ARSS的错分量
    * @param fd_final_sss_arss07   当前维度最终错分里SSS错分中ARSS结果为0-7的错分量
    * @param fd_final_sss_arssnull 当前维度最终错分里SSS错分中ARSS结果为null的错分量
    */
  case class FinalObj(
                       data_type: String,
                       stat_date: String,
                       province: String,
                       region: String,
                       city_code: String,
                       city: String,
                       fd_gis_sss: Int,
                       fd_gis: Int,
                       fd_sss: Int,
                       fd_arss: Int,
                       fd_gis_sss_uss: Int,
                       fd_gis_sss_usg: Int,
                       fd_gis_sss_usb: Int,
                       fd_final: Int,
                       fd_final_gis: Int,
                       fd_final_arss: Int,
                       fd_final_sss: Int,
                       fd_final_sss_gisnull: Int,
                       fd_final_sss_arss: Int,
                       fd_final_sss_arss07: Int,
                       fd_final_sss_arssnull: Int,
                       fd_ks: Int
                     )


  /**
    *
    * @param data_type
    * @param stat_date
    * @param province
    * @param region
    * @param city_code
    * @param city
    * @param zonecode
    * @param req
    * @param gisRec
    * @param gisRecDiff
    * @param sssRec
    * @param sssRecDiff
    * @param gisSssRec
    * @param arssRec
    * @param finalRec
    * @param finalRecDiff
    * @param gisNoWrong
    * @param gisNoWrongDiff
    * @param sssNoWrong
    * @param sssNoWrongDiff
    * @param gisSssNoWrong
    * @param arssNoWrong
    * @param finalNoWrong
    * @param finalNoWrongDiff
    */
  case class RecObj(
                     data_type: String,
                     stat_date: String,
                     province: String,
                     region: String,
                     city_code: String,
                     city: String,
                     zonecode: String,
                     req: Int,
                     gisRec: Int,
                     gisRecDiff: Int,
                     sssRec: Int,
                     sssRecDiff: Int,
                     gisSssRec: Int,
                     arssRec: Int,
                     finalRec: Int,
                     finalRecDiff: Int,
                     gisNoWrong: Int,
                     gisNoWrongDiff: Int,
                     sssNoWrong: Int,
                     sssNoWrongDiff: Int,
                     gisSssNoWrong: Int,
                     arssNoWrong: Int,
                     finalNoWrong: Int,
                     finalNoWrongDiff: Int,
                     gisRecNorm:Int,
                     gisNoWrongNorm:Int,
                     ksRec: Int
                   )


  /**
    *
    * @param stat_date
    * @param province
    * @param region
    * @param city_code
    * @param city
    * @param gisValidRec
    * @param sssValidRec
    * @param gisSssValidRec
    * @param arssValidRec
    * @param finalValidRec
    * @param gisValidRecDiff
    * @param sssValidRecDiff
    * @param finalValidRecDiff
    */
  case class RecValidObj(
                          stat_date: String,
                          province: String,
                          region: String,
                          city_code: String,
                          city: String,
                          gisValidRec: Int,
                          sssValidRec: Int,
                          gisSssValidRec: Int,
                          arssValidRec: Int,
                          finalValidRec: Int,
                          gisValidRecDiff: Int,
                          sssValidRecDiff: Int,
                          finalValidRecDiff: Int,
                          gisValidRecNorm:Int,
                          ksValidRec: Int
                        )

  /**
    *
    * @param data_type
    * @param stat_date
    * @param province
    * @param region
    * @param city_code
    * @param city
    * @param req
    * @param gisValidRec
    * @param sssValidRec
    * @param gisSssValidRec
    * @param arssValidRec
    * @param finalValidRec
    * @param gusRecDiff
    */
  case class ZcRecValidObj(
                            data_type: String,
                            stat_date: String,
                            province: String,
                            region: String,
                            city_code: String,
                            city: String,
                            zonecode: String,
                            req: Int,
                            gisValidRec: Int,
                            sssValidRec: Int,
                            gisSssValidRec: Int,
                            arssValidRec: Int,
                            finalValidRec: Int,
                            gusRecDiff: Int,
                            gisValidRecNorm:Int,
                            ksValidRec: Int
                          )

  /**
    * 按网点错分指标
    *
    * @param data_type
    * @param stat_date
    * @param province
    * @param region
    * @param city_code
    * @param city
    * @param zonecode
    * @param zc             网点错分量
    * @param zc_norm        来自NORM的网点的错分量
    * @param zc_chkn        来自CHKN的网点的错分量
    * @param zc_chke        来自CHKE的网点的错分量
    * @param zc_phone       来自PHONE的网点的错分量
    * @param zc_road        来自ROAD的网点的错分量
    * @param zc_tc2         来自TC2的网点的错分量
    * @param zc_auto        来自AUTO的网点的错分量
    * @param zc_normhp      来自NORMHP的网点的错分量
    * @param zc_normcompany 来自NORMCOMPANY的网点的错分量
    * @param zc_sss         SSS网点的错分量
    * @param zc_gissss      GIS_SSS网点的错分量
    * @param zc_arss        网点审补量
    * @param zc_final       最终网点的错分量
    * @param zc_gus         GIS和SSS不一致中GIS的错分量
    * @param zc_gus_sss     GIS和SSS不一致中SSS的错分量
    * @param zc_gus_both    GIS和SSS不一致中GIS和SSS都错分的量
    */
  case class ZcWdObj(
                      data_type: String,
                      stat_date: String,
                      province: String,
                      region: String,
                      city_code: String,
                      city: String,
                      zonecode: String,
                      zc: Int,
                      zc_norm: Int,
                      zc_chkn: Int,
                      zc_chke: Int,
                      zc_phone: Int,
                      zc_road: Int,
                      zc_tc2: Int,
                      zc_auto: Int,
                      zc_normhp: Int,
                      zc_normcompany: Int,
                      zc_sss: Int,
                      zc_gissss: Int,
                      zc_arss: Int,
                      zc_final: Int,
                      zc_gus: Int,
                      zc_gus_sss: Int,
                      zc_gus_both: Int,
                      zc_chkn_aos: Int,
                      zc_chkn_aosnewgid1: Int,
                      zc_chkn_optsup: Int,
                      zc_chkn_arss: Int,
                      zc_chkn_cms: Int,
                      zc_chkn_truth: Int,
                      zc_chkn_truthqs: Int,
                      zc_chkn_aostcdj: Int,
                      zc_chkn_aostcgj: Int,
                      zc_chkn_script: Int,
                      zc_chkn_sss: Int,
                      zc_chkn_awsm: Int,
                      zc_chkn_other: Int,
                      zc_ks: Int
                    )

  /**
    * 错分指标统计
    *
    * @param data_type 剔除前后
    * @param stat_date 日期
    * @param region    大区
    * @param city      城市名称
    * @param zonecode  网点
    * @param ak        ak
    * @param gisObj    gis错分信息
    * @param finalObj  最终错分信息
    * @param zcWdObj   带网点的错分信息
    */
  case class WrongIndexObj(
                            data_type: String,
                            stat_date: String,
                            region: String,
                            city: String,
                            zonecode: String,
                            ak: String,
                            gisObj: GisObjNew,
                            finalObj: FinalObj,
                            zcWdObj: ZcWdObj)

  /**
    * 有效识别量信息
    *
    * @param data_type         剔除前后
    * @param stat_date         日期
    * @param region            大区
    * @param city              城市
    * @param zonecode          网点
    * @param ak                ak
    * @param req               总请求量
    * @param gisValidRec       gis有效识别
    * @param sssValidRec       sss有效识别
    * @param gisSssValidRec    gis_sss有效识别
    * @param arssValidRec      审补有效识别
    * @param finalValidRec     最终有效识别
    * @param gusRecDiff        GIS和SSS不一致的有效识别量
    * @param sssValidRecDiff   当前维度GIS和SSS有效不一致量SSS的量（剔除重货等无效识别）
    * @param finalValidRecDiff 当前维度GIS和SSS有效不一致量（剔除重货等无效识别）
    */
  case class RecValidNewObj(data_type: String,
                            stat_date: String,
                            region: String,
                            city: String,
                            city_code: String,
                            zonecode: String,
                            ak: String,
                            req: Int,
                            gisValidRec: Int,
                            sssValidRec: Int,
                            gisSssValidRec: Int,
                            arssValidRec: Int,
                            finalValidRec: Int,
                            gusRecDiff: Int,
                            sssValidRecDiff: Int,
                            finalValidRecDiff: Int,
                            gisValidRecNorm:Int,
                            ksValidRec: Int
                           )

  /**
    *
    * @param data_type
    * @param stat_date
    * @param region
    * @param city
    * @param zonecode
    * @param req
    * @param gisRec
    * @param gisRecDiff
    * @param sssRec
    * @param sssRecDiff
    * @param gisSssRec
    * @param arssRec
    * @param finalRec
    * @param finalRecDiff
    * @param gisNoWrong
    * @param gisNoWrongDiff
    * @param sssNoWrong
    * @param sssNoWrongDiff
    * @param gisSssNoWrong
    * @param arssNoWrong
    * @param finalNoWrong
    * @param finalNoWrongDiff
    */
  case class RecObjNew(
                        data_type: String,
                        stat_date: String,
                        region: String,
                        city: String,
                        city_code: String,
                        zonecode: String,
                        ak: String,
                        req: Int,
                        gisRec: Int,
                        gisRecDiff: Int,
                        sssRec: Int,
                        sssRecDiff: Int,
                        gisSssRec: Int,
                        arssRec: Int,
                        finalRec: Int,
                        finalRecDiff: Int,
                        gisNoWrong: Int,
                        gisNoWrongDiff: Int,
                        sssNoWrong: Int,
                        sssNoWrongDiff: Int,
                        gisSssNoWrong: Int,
                        arssNoWrong: Int,
                        finalNoWrong: Int,
                        finalNoWrongDiff: Int,
                        gisRecNorm:Int,
                        gisNoWrongNorm:Int,
                        ksRec: Int
                      )

  /**
    * gis错分详细统计
    *
    * @param gisObjNorm
    * @param gisObjChkn
    * @param gisObjChke
    * @param gisObjPhone
    * @param gisObjAuto
    * @param gisObjRoad
    * @param gisObjTc2
    */
  case class GisObjNew(
                        fd_final_same_sss: Int,
                        fd_final_unsame_sss: Int,
                        fd_final_sss_isnull: Int,
                        fd_final_arss_gis: Int,
                        gisObjNorm: GisObj,
                        gisObjChkn: GisObj,
                        gisObjChke: GisObj,
                        gisObjPhone: GisObj,
                        gisObjAuto: GisObj,
                        gisObjRoad: GisObj,
                        gisObjTc2: GisObj,
                        gisObjNormHp: GisObj,
                        gisObjNormCompany: GisObj,
                        gisObjOther: GisObj
                      )

  case class AoiWdObj(
                      stat_date: String,
                      region: String,
                      city_code: String,
                      city: String,
                      zone_code:String,
                      req: Int,
                      aoi:Int,
                      aoi_wrong: Int,
                      aoi_ks: Int,
                      aoi_ks_wrong:Int,
                      aoi_arss:Int,
                      aoi_arss_wrong:Int,
                      aoi_gis: Int,
                      aoi_gis_wrong: Int,
                      aoi_gis_wrong_norm: Int,
                      aoi_gis_wrong_chkn: Int,
                      aoi_gis_wrong_chke: Int,
                      aoi_gis_wrong_phone: Int,
                      aoi_gis_wrong_road: Int,
                      aoi_gis_wrong_tc2: Int,
                      aoi_gis_wrong_auto: Int,
                      aoi_gis_wrong_normhp: Int,
                      aoi_gis_wrong_normcompany: Int,
                      aoi_gis_wrong_other: Int
                    )
  case class AoiProObj(
                       stat_date: String,
                       region: String,
                       city_code: String,
                       city: String,
                       zone_code:String,
                       aoi:Int,
                       aoi_wrong: Int
                     )
}
