package com.sf.gis.scala.utils;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChinestToDigit {
    private static HashMap<String, String> digitMap = new HashMap<String, String>();

    static {
        digitMap.put("0", "零");
        digitMap.put("1", "一");
        digitMap.put("2", "二");
        digitMap.put("3", "三");
        digitMap.put("4", "四");
        digitMap.put("5", "五");
        digitMap.put("6", "六");
        digitMap.put("7", "七");
        digitMap.put("8", "八");
        digitMap.put("9", "九");
    }

    private static Map<String, Integer> chineseMap = new HashMap<String, Integer>();

    static {
        chineseMap.put("零", 0);
        chineseMap.put("一", 1);
        chineseMap.put("二", 2);
        chineseMap.put("三", 3);
        chineseMap.put("四", 4);
        chineseMap.put("五", 5);
        chineseMap.put("六", 6);
        chineseMap.put("七", 7);
        chineseMap.put("八", 8);
        chineseMap.put("九", 9);
    }
    private static Map<String, Integer> unitMap = new HashMap<String, Integer>();

    static {
        unitMap.put("十", 10);
        unitMap.put("百", 100);
        unitMap.put("千", 1000);
    }

    public static String cheseToDigit(String srcStr) {
        int value = 0;
        List<String> strList = Arrays.asList(srcStr.split(""));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < strList.size(); i++) {
            String word = strList.get(i);
            if (chineseMap.containsKey(word)) {
                if (i == strList.size() - 1) {
                    value = value + chineseMap.get(word);
                    sb.append(value);
                    break;
                } else if (!unitMap.containsKey(strList.get(i + 1))
                        && !chineseMap.containsKey(strList.get(i + 1))) {

                    value = value + chineseMap.get(word);
                    sb.append(value);
                    value = 0;
                } else if (unitMap.containsKey(strList.get(i + 1))) {
                    value = value + chineseMap.get(word) * unitMap.get(strList.get(i + 1));
                } else if (chineseMap.containsKey(strList.get(i + 1))) {
                    if ("零".equals(word) && value != 0) {
                        continue;
                    } else {
                        value = value + chineseMap.get(word);
                        sb.append(value);
                        value = 0;
                    }
                }
            } else if (unitMap.containsKey(word)) {
                if (value != 0) {
                    if (i == strList.size() - 1 || !chineseMap.containsKey(strList.get(i + 1))) {
                        sb.append(value);
                        value = 0;
                    }
                } else if ("十".equals(word)) {
                    if (i == strList.size() - 1) {
                        sb.append(word);
                    } else if (!chineseMap.containsKey(strList.get(i + 1))) {
                        sb.append("10");
                    } else {
                        value = 10;
                    }
                } else {
                    sb.append(word);
                }
            } else {
                sb.append(word);
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        String[] dd = "dad|dasd".split("\\|");
        System.out.println(dd);
        String[] strs = new String[]{"后鞍新一二堤一行"};
        for (String xx : strs) {
            System.out.println(ChinestToDigit.cheseToDigit(xx));
        }
    }
}
