package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

import java.security.MessageDigest
import java.sql.Connection
import java.text.SimpleDateFormat
import java.util
import java.util.Date

import com.alibaba.druid.pool.DruidDataSource
import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay.WdIndexStat.MergeType.MergeType
import com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay.WrongObj.{AoiWdObj, FinalObj, GisObj, GisObjNew, RecValidNewObj, RecValidObj, WrongIndexObj, ZcRecValidObj, ZcWdObj}
import com.sf.gis.scala.oms_pai.index.oms_realtime.Obj.{DlvFdPart1, DlvFdPart2, OmsDlvFdPart1, OmsDlvFdPart2}
import com.sf.gis.scala.oms_pai.start.ComUtil
import com.sf.gis.scala.utils.DbUtils
import org.apache.log4j.Logger
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer


/**
 * Created by 01375125 on 2018/11/22.
 * 错分指标统计
 */
object WdIndexStat {
  val appName: String = this.getClass.getName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val invalidRegion = Array[String]("", "香港区", "澳门区", "台湾区")

  /** *
   * 定义维度类型
   */
  object MergeType extends Enumeration {
    type MergeType = Value //声明枚举对外暴露的变量类型
    val date = Value("date")
    val zc = Value("zc")
    val region = Value("region")
    val city = Value("city")
    val ak = Value("ak")
  }

  /**
   * 统计错分行指标
   *
   * @param standardRdd
   */
  def statRowIndex(standardRdd: RDD[JSONObject]): (RDD[(GisObj, FinalObj, ZcWdObj, GisObjNew)]) = {
    logger.error(">>>统计每行指标...")
    val rowIndexRdd: RDD[(GisObj, FinalObj, ZcWdObj, GisObjNew)] = standardRdd.flatMap(obj => {
      //统计每行指标
      statRowIndex(obj).iterator()
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    rowIndexRdd
  }

  /**
   * 统计错分指标
   *
   * @param rowIndexRdd
   */
  def statIndex(rowIndexRdd: RDD[(GisObj, FinalObj, ZcWdObj, GisObjNew)]): (RDD[GisObj], RDD[FinalObj], RDD[ZcWdObj]) = {
    //    logger.error(">>>统计gis的指标...")
    //    val gisIndexRdd = rowIndexRdd.filter(obj => Constant.PRE.equals(obj._1.data_type)).map(tp => {
    //      val obj = tp._1
    //      val key = Array(obj.stat_date, obj.city, obj.city_code, obj.status, obj.status_detail).mkString("_")
    //      (key, obj)
    //    }).reduceByKey((o1, o2) => {
    //      mergeGisIndex(o1, o2)
    //    }).values.sortBy(_.stat_date).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    //    gisIndexRdd.take(2).foreach(o=>println(o))
    //
    //
    //    logger.error(">>>统计final的指标...")
    //    val finalIndexRdd = rowIndexRdd.filter(obj => Constant.PRE.equals(obj._2.data_type)).map(tp => {
    //      val obj = tp._2
    //      val key = Array(obj.stat_date, obj.city_code, obj.city).mkString("_")
    //      (key, obj)
    //    }).reduceByKey((o1, o2) => {
    //      mergeFinlaIndex(o1, o2)
    //    }).values.sortBy(_.stat_date).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(">>>按统计网点错分指标")
    val zcWdIdxRdd = rowIndexRdd.map(tp => {
      val obj = tp._3
      val key = Array(obj.data_type, obj.stat_date, obj.city_code, obj.city, obj.zonecode).mkString("_")
      (key, obj)
    }).reduceByKey((o1, o2) => {
      mergeZcWdIndex(o1, o2)
    }).values.sortBy(_.stat_date).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    logger.error("gis idx num:" + gisIndexRdd.count())
    //    logger.error("final idx num:" + finalIndexRdd.count())
    logger.error("zc wd idx num:" + zcWdIdxRdd.count())
    rowIndexRdd.unpersist()
    //    finalIndexRdd.take(2).foreach(o=>println(o))
    (null, null, zcWdIdxRdd)
  }

  /**
   * 按维度合并错分数据
   *
   * @param mergeType
   * @param rowIndexRdd
   * @return
   */
  def statIndexMerge(mergeType: MergeType, rowIndexRdd: RDD[(GisObj, FinalObj, ZcWdObj, GisObjNew)]): RDD[WrongIndexObj] = {
    var rowIndexRddMerge: RDD[(String, WrongIndexObj)] = null

    if (mergeType.equals(MergeType.date)) {
      rowIndexRddMerge = rowIndexRdd.filter(obj => (obj._3.region != null
        && !invalidRegion.contains(obj._3.region))).map(tp => {
        val zcObj = tp._3
        val key = Array(zcObj.data_type, zcObj.stat_date, "ALL", "ALL", "ALL", "ALL").mkString("_")
        val wrongObj = WrongIndexObj(zcObj.data_type, zcObj.stat_date, "ALL", "ALL", "ALL", "ALL",
          tp._4, tp._2, tp._3)
        (key, wrongObj)
      })
    } else if (mergeType.equals(MergeType.region)) {
      rowIndexRddMerge = rowIndexRdd.map(tp => {
        val zcObj = tp._3
        val key = Array(zcObj.data_type, zcObj.stat_date, zcObj.region, "ALL", "ALL", "ALL").mkString("_")
        val wrongObj = WrongIndexObj(zcObj.data_type, zcObj.stat_date, zcObj.region, "ALL", "ALL", "ALL",
          tp._4, tp._2, tp._3)
        (key, wrongObj)
      })
    } else if (mergeType.equals(MergeType.city)) {
      rowIndexRddMerge = rowIndexRdd.map(tp => {
        val zcObj = tp._3
        val key = Array(zcObj.data_type, zcObj.stat_date, zcObj.region, zcObj.city, "ALL", "ALL").mkString("_")
        val wrongObj = WrongIndexObj(zcObj.data_type, zcObj.stat_date, zcObj.region, zcObj.city, "ALL", "ALL",
          tp._4, tp._2, tp._3)
        (key, wrongObj)
      })
    } else if (mergeType.equals(MergeType.zc)) {
      rowIndexRddMerge = rowIndexRdd.map(tp => {
        val zcObj = tp._3
        val key = Array(zcObj.data_type, zcObj.stat_date, zcObj.region, zcObj.city, zcObj.zonecode, "ALL").mkString("_")
        val wrongObj = WrongIndexObj(zcObj.data_type, zcObj.stat_date, zcObj.region, zcObj.city, zcObj.zonecode,
          "ALL", tp._4, tp._2, tp._3)
        (key, wrongObj)
      })
    } else {
      return null
    }
    rowIndexRddMerge.reduceByKey((o1, o2) => {
      val zcWdObj = mergeZcWdIndex(o1.zcWdObj, o2.zcWdObj)
      val gisObj = mergeGisIndexNew(o1.gisObj, o2.gisObj)
      val finalObj = mergeFinlaIndex(o1.finalObj, o2.finalObj)
      WrongIndexObj(o1.data_type, o1.stat_date, o1.region, o1.city, o1.zonecode, o1.ak, gisObj, finalObj, zcWdObj)
    }).values.sortBy(_.stat_date).persist(StorageLevel.MEMORY_AND_DISK_SER)
  }

  /**
   * 统计错分指标(新)
   *
   * @param rowIndexRdd
   */
  def statIndexNew(rowIndexRdd: RDD[(GisObj, FinalObj, ZcWdObj, GisObjNew)]): (RDD[WrongIndexObj], RDD[WrongIndexObj], RDD[WrongIndexObj], RDD[WrongIndexObj]) = {
    logger.error(">>>按日期统计错分指标...")
    //    ****可优化，和有效识别量一样优化***
    val dateIndexRdd = statIndexMerge(MergeType.date, rowIndexRdd)
    logger.error(">>>按日期统计错分指标:" + dateIndexRdd.count())
    logger.error(">>>按大区统计错分指标...")
    val regionIndexRdd = statIndexMerge(MergeType.region, rowIndexRdd)
    logger.error(">>>按大区统计错分指标:" + regionIndexRdd.count())
    logger.error(">>>按城市名统计错分指标...")
    val cityIndexRdd = statIndexMerge(MergeType.city, rowIndexRdd)
    logger.error(">>>按城市名统计错分指标:" + cityIndexRdd.count())
    logger.error(">>>按网点统计错分指标...")
    val zcIndexRdd = statIndexMerge(MergeType.zc, rowIndexRdd)
    logger.error(">>>按网点统计错分指标:" + zcIndexRdd.count())
    (dateIndexRdd, regionIndexRdd, cityIndexRdd, zcIndexRdd)
  }

  /**
   * 按行统计gis和final的指标
   *
   * @param json
   * @return
   */
  def statRowIndex(json: JSONObject): util.ArrayList[(GisObj, FinalObj, ZcWdObj, GisObjNew)] = {
    val list = new util.ArrayList[(GisObj, FinalObj, ZcWdObj, GisObjNew)]()
    list.add(statRowIndex(json, oper_flag = false))
    list.add(statRowIndex(json, oper_flag = true))
    list
  }

  /**
   * 生成gis错分记录
   *
   * @param data_type
   * @param stat_date
   * @param province
   * @param region
   * @param city
   * @param city_code
   * @param status
   * @param status_detail
   * @param fd
   * @param fd_unsame_sss
   * @param fd_final_gis
   * @param fd_final_same_sss
   * @param fd_final_unsame_sss
   * @param fd_final_sss_isnull
   * @param fd_final_arss_gis
   * @return
   */
  def createGisObjNew(data_type: String, stat_date: String, province: String, region: String,
                      city: String, city_code: String, status: String, status_detail: String,
                      fd: Int, fd_unsame_sss: Int, fd_final_gis: Int, fd_final_same_sss: Int,
                      fd_final_unsame_sss: Int, fd_final_sss_isnull: Int, fd_final_arss_gis: Int): GisObjNew = {
    var gisObjNorm: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjChkn: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjChke: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjPhone: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjAuto: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjRoad: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjTc2: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjNormHp: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjNormCompany: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    var gisObjOther: GisObj = GisObj(null, null, null, null, null, null, null, null, 0, 0, 0, 0, 0, 0, 0)
    status_detail match {
      case "NORM" => gisObjNorm = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case "CHKN" => gisObjChkn = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case "CHKE" => gisObjChke = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case "PHONE" => gisObjPhone = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case "ROAD" => gisObjRoad = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case "TC2" => gisObjTc2 = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case "AUTO" => gisObjAuto = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case "NORMHP" => gisObjNormHp = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case "NORMCOMPANY" => gisObjNormCompany = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
      case _ => gisObjOther = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
    }
    GisObjNew(fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis,
      gisObjNorm, gisObjChkn, gisObjChke, gisObjPhone, gisObjAuto, gisObjRoad, gisObjTc2, gisObjNormHp, gisObjNormCompany, gisObjOther)
  }

  def statRowIndex(json: JSONObject, oper_flag: Boolean): (GisObj, FinalObj, ZcWdObj, GisObjNew) = {
    var fd_gis_sss, fd_gis, fd_sss, fd_arss, fd_ks, fd_gis_sss_uss, fd_gis_sss_usg, fd_gis_sss_usb, fd_final, fd_final_gis, fd_final_arss, fd_final_sss, fd_final_sss_gisnull, fd_final_sss_arss, fd_final_sss_arss07, fd_final_sss_arssnull = 0
    var fd, fd_unsame_sss, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis = 0
    var fd_norm, fd_chkn, fd_chke, fd_phone, fd_road, fd_tc2, fd_auto, fd_normhp, fd_normcompany = 0
    val province = json.getString("province")
    val region = json.getString("region")
    val city_code = json.getString("city_code")
    val city = json.getString("city")
    var status = "UNRESP" //默认gis无返回
    var status_detail = "-"
    val oms_body = json.getJSONObject("oms_body")
    val stat_date = oms_body.getString("req_date")
    val oper_status = oms_body.getString("oper_status")
    val tag = json.getString("tag")
    if (tag.equals("wrong")) fd_final = 1
    val data_type = if (oper_flag) Constant.AFT else Constant.PRE

    val gis_dept = oms_body.getString("gis_dept")
    //noinspection ScalaUnusedSymbol
    val gis_dept_map = oms_body.getString("gis_dept_map")
    val sss_dept = oms_body.getString("sss_dept")
    //noinspection ScalaUnusedSymbol
    val sss_dept_map = oms_body.getString("sss_dept_map")
    //noinspection ScalaUnusedSymbol
    val gis_sss_dept = oms_body.getString("gis_sss_dept")
    //noinspection ScalaUnusedSymbol
    val gis_sss_dept_map = oms_body.getString("gis_sss_dept_map")
    //noinspection ScalaUnusedSymbol
    val arss_dept = oms_body.getString("arss_dept")
    //noinspection ScalaUnusedSymbol
    val arss_dept_map = oms_body.getString("arss_dept_map")
    var final_dept_map = oms_body.getString("final_dept_map")
    if (final_dept_map == null || "".equals(final_dept_map)) final_dept_map = "-"

    val isGisDeptMatch = oms_body.getBoolean("isGisDeptMatch")
    val isSssDeptMatch = oms_body.getBoolean("isSssDeptMatch")
    //noinspection ScalaUnusedSymbol
    val isArssDeptMatch = oms_body.getBoolean("isArssDeptMatch")
    //noinspection ScalaUnusedSymbol
    val isGisSssDeptMatch = oms_body.getBoolean("isGisSssDeptMatch")
    //noinspection ScalaUnusedSymbol
    val isFinalDeptMatch = oms_body.getBoolean("isFinalDeptMatch")
    val final_dept_src = oms_body.getString("final_dept_src")
    val chkDeptSrc = oms_body.getString("chkDeptSrc")
    val precision = oms_body.getString("precision")

    val isGisSssDiff = oms_body.getString("isGisSssDiff")
    val gis_sss_status = oms_body.getString("gis_sss_status")
    val gis_status = oms_body.getString("gis_status")
    val sss_status = oms_body.getString("sss_status")
    val arss_status = oms_body.getString("arss_status")
    val final_status = oms_body.getString("final_status")
    val ks_status = oms_body.getString("ks_status")

    val gis_time = oms_body.getString("gis_time")
    val src = oms_body.getString("lib_src")
    //noinspection ScalaUnusedSymbol
    val sys_src = oms_body.getString("sys_src")
    if (gis_time != null) {
      status = "RESP" //gis有返回
      if (isGisDeptMatch) {
        status = "REC" //有返回且可识别
        if (src != null) status_detail = src.toUpperCase
      }
    }

    val zc_chkn_detail = scala.collection.mutable.Map("aos" -> 0, "aos_new_gid1" -> 0, "opt_sup" -> 0, "arss" -> 0, "cms" -> 0, "truth" -> 0, "truth_qs" -> 0,
      "aos_tc_init_gid_dj" -> 0, "aos_tc_init_gid_gj" -> 0, "script" -> 0, "sss" -> 0, "awsm" -> 0, "other" -> 0)
    //计算错分整体指标
    if (!oper_flag || !"1".equals(oper_status)) { //非补码排除件
      if (gis_sss_status.equals("5")) fd_gis_sss = 1 //gis_sss错分总量
      if (gis_status.equals("5")) {
        fd_gis = 1 //gis错分总量(zc)
        fd = 1 //当前维度下GIS的错分量(gis)
        status_detail match {
          case "NORM" => fd_norm = 1
          case "CHKN" => fd_chkn = 1
          case "CHKE" => fd_chke = 1
          case "PHONE" => fd_phone = 1
          case "ROAD" => fd_road = 1
          case "TC2" => fd_tc2 = 1
          case "AUTO" => fd_auto = 1
          case "NORMHP" => fd_normhp = 1
          case "NORMCOMPANY" => fd_normcompany = 1
          case _ =>
        }
        if (status_detail.equals("CHKN")) {
          chkDeptSrc match {
            case "aos" | "aos_new_gid1" | "arss" | "cms" | "truth"
                 | "truth_qs" | "script" | "sss" | "awsm" =>
              zc_chkn_detail.update(chkDeptSrc, 1)
            case "opt_sup" | "opt" =>
              zc_chkn_detail.update("opt_sup", 1)
            case "aos_tc_init_gid_update" | "aos_tc_init_gid" =>
              if (precision.equals("2")) {
                zc_chkn_detail.update("aos_tc_init_gid_dj", 1)
              } else if (precision.equals("1") || precision.equals("0")) {
                zc_chkn_detail.update("aos_tc_init_gid_gj", 1)
              } else {
                zc_chkn_detail.update("other", 1)
              }
            case _ =>
              zc_chkn_detail.update("other", 1)
          }
        }

      }

      if (sss_status.equals("5")) fd_sss = 1 //sss错分总量
      if (arss_status.equals("5")) fd_arss = 1 //审补错分总量
      if (ks_status.equals("5")) fd_ks = 1 //ks错分总量

      //系统网点不一致时或者映射网点不一致时
      if (isGisSssDiff.equals("diff")) {
        if (sss_status.equals("5")) fd_gis_sss_uss = 1 //系统网点不一致时，sss错分总量
        if (gis_status.equals("5")) {
          fd_gis_sss_usg = 1 //系统网点不一致时 gis错分总量(zc)
          fd_unsame_sss = 1 //当前维度下GIS与SSS不一致中GIS的错分量(gis)
        }
        if (gis_status.equals("5") && sss_status.equals("5")) fd_gis_sss_usb = 1 //系统网点不一致时，gis—sss同时错分总量
      }

      //最终错分指标
      if (final_status.equals("5")) {
        //        fd_final = 1 //最终错分总量
        if (final_dept_src != null) {
          if (final_dept_src.equals("gis")) {
            fd_final_gis = 1 //当前维度最终错分里GIS的错分量
            if (isGisSssDiff.equals("diff")) fd_final_unsame_sss = 1 //当前维度下最终错分中与GIS与SSS不一致的GIS的错分量
            if (isGisSssDiff.equals("same")) fd_final_same_sss = 1 //当前维度下最终错分中与GIS与SSS一致的GIS的错分量
            if (!isSssDeptMatch) fd_final_sss_isnull = 1 //当前维度下最终错分中SSS为空的量下GIS的错分量
          } else if (final_dept_src.equals("sss")) {
            fd_final_sss = 1 //当前维度最终错分里SSS的错分量
            if (arss_dept == null || arss_dept.equals("")) fd_final_sss_arssnull = 1 //当前维度下SSS错分量中ARSS结果为null错分量
            if (arss_dept != null && arss_dept.matches("^[0-7]")) fd_final_sss_arss07 = 1 //当前维度下SSS错分量中ARSS结果为0-9的错分量
            if (gis_dept == null || gis_dept.equals("")) fd_final_sss_gisnull = 1 //当前维度最终错分里SSS错分中GIS为空的错分量
            if (arss_dept != null && arss_dept.equals(sss_dept)) fd_final_sss_arss = 1 //当前维度最终错分里SSS错分中审补为SSS的错分量
          } else if (final_dept_src.equals("arss")) {
            fd_final_arss = 1 //当前维度最终错分里ARSS的错分量
          }
        }
      }
    }

    val gisObj = GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
    val gisObjNew = createGisObjNew(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final_gis, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
    val finalObj = FinalObj(data_type, stat_date, province, region, city_code, city, fd_gis_sss, fd_gis, fd_sss, fd_arss, fd_gis_sss_uss, fd_gis_sss_usg, fd_gis_sss_usb, fd_final, fd_final_gis, fd_final_arss, fd_final_sss, fd_final_sss_gisnull, fd_final_sss_arss, fd_final_sss_arss07, fd_final_sss_arssnull, fd_ks)
    val zcWdObj = ZcWdObj(data_type, stat_date, province, region, city_code, city, final_dept_map, fd_gis, fd_norm, fd_chkn, fd_chke, fd_phone, fd_road, fd_tc2, fd_auto, fd_normhp, fd_normcompany, fd_sss, fd_gis_sss, fd_arss, fd_final, fd_gis_sss_usg, fd_gis_sss_uss, fd_gis_sss_usb,
      zc_chkn_detail("aos"), zc_chkn_detail("aos_new_gid1"),
      zc_chkn_detail("opt_sup"), zc_chkn_detail("arss"), zc_chkn_detail("cms"), zc_chkn_detail("truth"),
      zc_chkn_detail("truth_qs"), zc_chkn_detail("aos_tc_init_gid_dj"), zc_chkn_detail("aos_tc_init_gid_gj"),
      zc_chkn_detail("script"), zc_chkn_detail("sss"), zc_chkn_detail("awsm"), zc_chkn_detail("other"), fd_ks)
    (gisObj, finalObj, zcWdObj, gisObjNew)
  }

  /**
   * 获取错误分类数据
   *
   * @param standardRdd
   * @return
   */
  def getWdDetailData(standardRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val detailRdd = standardRdd.map(json => {
      val oms_body = json.getJSONObject("oms_body")
      var type1 = "-"
      //错误类型 final/gis/sss/gis_sss/arss
      var type2 = "-"
      var _type = "-"

      val src = oms_body.getString("lib_src")
      val isGisSssDiff = oms_body.getString("isGisSssDiff")
      val gis_sss_status = oms_body.getString("gis_sss_status")
      val gis_status = oms_body.getString("gis_status")
      val sss_status = oms_body.getString("sss_status")
      val arss_status = oms_body.getString("arss_status")
      val final_status = oms_body.getString("final_status")

      val gis_dept = oms_body.getString("gis_dept")
      val sss_dept = oms_body.getString("sss_dept")
      val arss_dept = oms_body.getString("arss_dept")

      //noinspection ScalaUnusedSymbol
      val isGisDeptMatch = oms_body.getBoolean("isGisDeptMatch")
      val isSssDeptMatch = oms_body.getBoolean("isSssDeptMatch")
      //noinspection ScalaUnusedSymbol
      val isArssDeptMatch = oms_body.getBoolean("isArssDeptMatch")
      val final_dept_src = oms_body.getString("final_dept_src")
      //noinspection ScalaUnusedSymbol
      val sys_src = oms_body.getString("sys_src")

      if (!final_status.equals("5")) {
        //最终网点没有错误（gis/sss/gis_sss/arss有一个错误）
        type1 = "right"
        val arr = new ArrayBuffer[String]()
        val arrDetail = new ArrayBuffer[String]()
        if (gis_status.equals("5")) {
          arr += "gis"
          arrDetail += ("gis_" + src)
        }
        if (sss_status.equals("5")) {
          arr += "sss"
          arrDetail += "sss"
        }
        if (gis_sss_status.equals("5")) {
          arr += "gis_sss"
          arrDetail += "gis_sss"
        }
        if (arss_status.equals("5")) {
          arr += "arss"
          arrDetail += "arss"
        }
        if (arr.nonEmpty) type2 = arr.mkString("|")
        if (arrDetail.nonEmpty) _type = arrDetail.mkString("|")
      } else {
        //最终指标错误
        if (final_dept_src != null) {
          if (final_dept_src.equals("sss")) {
            type1 = "sss"
            if (arss_dept == null || arss_dept.equals("")) type2 = "sss_arssNone"
            if (arss_dept != null && arss_dept.matches("^[0-9]+")) type2 = "sss_arss0-9"
            if (gis_dept == null || gis_dept.equals("")) type2 = "sss_gisNone"
            if (arss_dept != null && sss_dept.equals(arss_dept)) type2 = "sss_arssSame"
            //            if(isSssDeptMatch && isArssDeptMatch && sss_dept.equals(arss_dept))type2="sss_arssSame"
          } else if (final_dept_src.equals("gis")) {
            type1 = "gis"
            if (isGisSssDiff.equals("diff")) type2 = "gis_sssDiff"
            if (isGisSssDiff.equals("same")) type2 = "gis_sssSame"
            if (!isSssDeptMatch) type2 = "gis_sssNone"
            if (!"-".equals(type2)) _type = type2 + "_" + src
            //            if(isGisDeptMatch && isArssDeptMatch && arss_dept.equals(gis_dept))type2="gis_arssSame"
          } else if (final_dept_src.equals("arss")) {
            type1 = "arss" //当前维度最终错分里ARSS的错分量
            type2 = "arss" //当前维度最终错分里ARSS的错分量
            //            if(sys_src.equals("gis_sss")){
            //              if(isSssDeptMatch && isArssDeptMatch && sss_dept.equals(arss_dept))type2="sss_arssSame"//当前维度最终错分里SSS错分中审补为SSS的错分量
            //            }else if(sys_src.equals("gis")){
            //              if(isGisDeptMatch && isArssDeptMatch && arss_dept.equals(gis_dept))type2="gis_arssSame"//当前维度下最终错分中审补为GIS的错分量
            //            }else{
            //              type1="arss"//当前维度最终错分里ARSS的错分量
            //            }
          }
        }
      }
      oms_body.put("type1", type1)
      oms_body.put("type2", type2)
      oms_body.put("type", _type)
      val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS")
      val handle_time = sdf.format(new Date)
      val handle_date = handle_time.split(" ")(0).replaceAll("-", "")
      json.put("handle_time", handle_time)
      json.put("handle_date", handle_date)
      json
    })
    detailRdd
  }

  /**
   * 合并gis指标
   *
   * @param o1
   * @param o2
   * @return
   */
  def mergeGisIndex(o1: GisObj, o2: GisObj): GisObj = {
    val data_type = o1.data_type
    val stat_date = o1.stat_date
    val province = o1.province
    val region = o1.region
    val city = o1.city
    val city_code = o1.city_code
    val status = o1.status
    val status_detail = o1.status_detail
    val fd = o1.fd + o2.fd
    val fd_unsame_sss = o1.fd_unsame_sss + o2.fd_unsame_sss
    val fd_final = o1.fd_final + o2.fd_final
    val fd_final_same_sss = o1.fd_final_same_sss + o2.fd_final_same_sss
    val fd_final_unsame_sss = o1.fd_final_unsame_sss + o2.fd_final_unsame_sss
    val fd_final_sss_isnull = o1.fd_final_sss_isnull + o2.fd_final_sss_isnull
    val fd_final_arss_gis = o1.fd_final_arss_gis + o2.fd_final_arss_gis

    GisObj(data_type, stat_date, province, region, city, city_code, status, status_detail, fd, fd_unsame_sss, fd_final, fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis)
  }

  /**
   * 合并gis指标
   *
   * @param o1
   * @param o2
   * @return
   */
  def mergeGisIndexNew(o1: GisObjNew, o2: GisObjNew): GisObjNew = {
    val gisObjNorm: GisObj = mergeGisIndex(o1.gisObjNorm, o2.gisObjNorm)
    val gisObjChkn: GisObj = mergeGisIndex(o1.gisObjChkn, o2.gisObjChkn)
    val gisObjChke: GisObj = mergeGisIndex(o1.gisObjChke, o2.gisObjChke)
    val gisObjPhone: GisObj = mergeGisIndex(o1.gisObjPhone, o2.gisObjPhone)
    val gisObjAuto: GisObj = mergeGisIndex(o1.gisObjAuto, o2.gisObjAuto)
    val gisObjRoad: GisObj = mergeGisIndex(o1.gisObjRoad, o2.gisObjRoad)
    val gisObjTc2: GisObj = mergeGisIndex(o1.gisObjTc2, o2.gisObjTc2)
    val gisObjNormHp: GisObj = mergeGisIndex(o1.gisObjNormHp, o2.gisObjNormHp)
    val gisObjNormCompany: GisObj = mergeGisIndex(o1.gisObjNormCompany, o2.gisObjNormCompany)
    val gisObjOther: GisObj = mergeGisIndex(o1.gisObjOther, o2.gisObjOther)
    val fd_final_same_sss = o1.fd_final_same_sss + o2.fd_final_same_sss
    val fd_final_unsame_sss = o1.fd_final_unsame_sss + o2.fd_final_unsame_sss
    val fd_final_sss_isnull = o1.fd_final_sss_isnull + o2.fd_final_sss_isnull
    val fd_final_arss_gis = o1.fd_final_arss_gis + o2.fd_final_arss_gis
    GisObjNew(fd_final_same_sss, fd_final_unsame_sss, fd_final_sss_isnull, fd_final_arss_gis,
      gisObjNorm, gisObjChkn, gisObjChke, gisObjPhone, gisObjAuto, gisObjRoad, gisObjTc2, gisObjNormHp, gisObjNormCompany, gisObjOther)
  }


  /**
   * 合并final指标
   *
   * @param o1
   * @param o2
   * @return
   */
  def mergeFinlaIndex(o1: FinalObj, o2: FinalObj): FinalObj = {
    val data_type = o1.data_type
    val stat_date = o1.stat_date
    val province = o1.province
    val region = o1.region
    val city_code = o1.city_code
    val city = o1.city

    val fd_gis_sss = o1.fd_gis_sss + o2.fd_gis_sss
    val fd_gis = o1.fd_gis + o2.fd_gis
    val fd_sss = o1.fd_sss + o2.fd_sss
    val fd_arss = o1.fd_arss + o2.fd_arss
    val fd_gis_sss_uss = o1.fd_gis_sss_uss + o2.fd_gis_sss_uss
    val fd_gis_sss_usg = o1.fd_gis_sss_usg + o2.fd_gis_sss_usg
    val fd_gis_sss_usb = o1.fd_gis_sss_usb + o2.fd_gis_sss_usb
    val fd_final = o1.fd_final + o2.fd_final
    val fd_final_gis = o1.fd_final_gis + o2.fd_final_gis
    val fd_final_arss = o1.fd_final_arss + o2.fd_final_arss
    val fd_final_sss = o1.fd_final_sss + o2.fd_final_sss
    val fd_final_sss_gisnull = o1.fd_final_sss_gisnull + o2.fd_final_sss_gisnull
    val fd_final_sss_arss = o1.fd_final_sss_arss + o2.fd_final_sss_arss
    val fd_final_sss_arss07 = o1.fd_final_sss_arss07 + o2.fd_final_sss_arss07
    val fd_final_sss_arssnull = o1.fd_final_sss_arssnull + o2.fd_final_sss_arssnull
    val fd_ks = o1.fd_ks + o2.fd_ks
    FinalObj(data_type, stat_date, province, region, city_code, city, fd_gis_sss, fd_gis, fd_sss, fd_arss, fd_gis_sss_uss, fd_gis_sss_usg, fd_gis_sss_usb, fd_final, fd_final_gis, fd_final_arss, fd_final_sss, fd_final_sss_gisnull, fd_final_sss_arss, fd_final_sss_arss07, fd_final_sss_arssnull, fd_ks)
  }

  /**
   * 合并安网点错分指标
   *
   * @param o1
   * @param o2
   * @return
   */
  def mergeZcWdIndex(o1: ZcWdObj, o2: ZcWdObj): ZcWdObj = {
    val data_type = o1.data_type
    val stat_date = o1.stat_date
    val province = o1.province
    val region = o1.region
    val city_code = o1.city_code
    val city = o1.city
    val zonecode = o1.zonecode

    val zc = o1.zc + o2.zc
    val zc_norm = o1.zc_norm + o2.zc_norm
    val zc_chkn = o1.zc_chkn + o2.zc_chkn
    val zc_chke = o1.zc_chke + o2.zc_chke
    val zc_phone = o1.zc_phone + o2.zc_phone
    val zc_road = o1.zc_road + o2.zc_road
    val zc_tc2 = o1.zc_tc2 + o2.zc_tc2
    val zc_auto = o1.zc_auto + o2.zc_auto
    val zc_normhp = o1.zc_normhp + o2.zc_normhp
    val zc_normcompany = o1.zc_normcompany + o2.zc_normcompany
    val zc_sss = o1.zc_sss + o2.zc_sss
    val zc_gissss = o1.zc_gissss + o2.zc_gissss
    val zc_arss = o1.zc_arss + o2.zc_arss
    val zc_final = o1.zc_final + o2.zc_final
    val zc_gus = o1.zc_gus + o2.zc_gus
    val zc_gus_sss = o1.zc_gus_sss + o2.zc_gus_sss
    val zc_gus_both = o1.zc_gus_both + o2.zc_gus_both
    val zc_chkn_aos = o1.zc_chkn_aos + o2.zc_chkn_aos
    val zc_chkn_aosnewgid1 = o1.zc_chkn_aosnewgid1 + o2.zc_chkn_aosnewgid1
    val zc_chkn_optsup = o1.zc_chkn_optsup + o2.zc_chkn_optsup
    val zc_chkn_arss = o1.zc_chkn_arss + o2.zc_chkn_arss
    val zc_chkn_cms = o1.zc_chkn_cms + o2.zc_chkn_cms
    val zc_chkn_truth = o1.zc_chkn_truth + o2.zc_chkn_truth
    val zc_chkn_truthqs = o1.zc_chkn_truthqs + o2.zc_chkn_truthqs
    val zc_chkn_aostcdj = o1.zc_chkn_aostcdj + o2.zc_chkn_aostcdj
    val zc_chkn_aostcgj = o1.zc_chkn_aostcgj + o2.zc_chkn_aostcgj
    val zc_chkn_script = o1.zc_chkn_script + o2.zc_chkn_script
    val zc_chkn_sss = o1.zc_chkn_sss + o2.zc_chkn_sss
    val zc_chkn_awsm = o1.zc_chkn_awsm + o2.zc_chkn_awsm
    val zc_chkn_other = o1.zc_chkn_other + o2.zc_chkn_other
    val zc_ks = o1.zc_ks + o2.zc_ks
    ZcWdObj(data_type, stat_date, province, region, city_code, city, zonecode, zc, zc_norm, zc_chkn, zc_chke, zc_phone, zc_road,
      zc_tc2, zc_auto, zc_normhp, zc_normcompany, zc_sss, zc_gissss, zc_arss, zc_final, zc_gus, zc_gus_sss, zc_gus_both,
      zc_chkn_aos, zc_chkn_aosnewgid1, zc_chkn_optsup, zc_chkn_arss, zc_chkn_cms, zc_chkn_truth, zc_chkn_truthqs, zc_chkn_aostcdj,
      zc_chkn_aostcgj, zc_chkn_script, zc_chkn_sss, zc_chkn_awsm, zc_chkn_other, zc_ks
    )
  }


  /**
   * 标准化省市区数据
   *
   * @return
   */
  def getStandardLogRdd(inputRdd: RDD[JSONObject], sc: SparkContext, comUtil: ComUtil): RDD[JSONObject] = {
    val conn = getRdsConn(comUtil)
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("province", "region", "city", "citycode")
    val regionSelectSql = s"select province,region,city,citycode from $regoinCityTable"
    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    logger.error("data size :" + regions.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val citycode = arr(3).toString
      if (cityMap.contains(citycode)) {
        val cityCodeList = cityMap.apply(citycode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (citycode -> cityCodeList)
      }
    }
    val cityMapBc = sc.broadcast(cityMap)
    //    cityMap.take(3).foreach(o=>println(o))

    //    inputRdd.take(5).foreach(o=>println(o))
    val standardLog = inputRdd.map(json => {
      //      val json = new JSONObject()
      val oms_body = json.getJSONObject("oms_body")
      var city_code = oms_body.getString("city_code")
      if (city_code == null) city_code = "-"
      json.put("region", "")
      json.put("province", "")
      json.put("city", "")
      json.put("city_code", city_code)
      val addresseeAddr = oms_body.getString("req_addresss")
      var flag = false
      val map = cityMapBc.value
      if (map.contains(city_code)) {
        flag = true
        val cityList: ArrayBuffer[Array[String]] = map.apply(city_code)
        if (cityList.length == 1) {
          //如果只有一个list，一一对应的，直接返回
          json.put("province", cityList(0)(0))
          json.put("region", cityList(0)(1))
          json.put("city", cityList(0)(2))
        } else if (cityList.length > 1) {
          //一个城市代码对应多个城市
          json.put("province", cityList(0)(0))
          json.put("region", cityList(0)(1))
          for (cityObj <- cityList) {
            val city = cityObj(2)
            val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
            if (addresseeAddr.contains(city) || addresseeAddr.contains(city1)) {
              json.put("city", cityObj(2))
            } else {
              if (json.getString("city") == null) {
                json.put("city", "-")
              }

            }
          }

        }
      }
      //      logger.error("region :"+json.getString("region"))
      (flag, json)
    }).filter(_._1 == true).values

    standardLog
  }

  def getStandardLogRddOmsBody(inputRdd: RDD[JSONObject],
                               sc: SparkContext,
                               comUtil: ComUtil): RDD[JSONObject] = {
    val conn = getRdsConn(comUtil)
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("province", "region", "city", "citycode")
    val regionSelectSql = s"select province,region,city,citycode from $regoinCityTable"
    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    logger.error("data size :" + regions.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val citycode = arr(3).toString
      if (cityMap.contains(citycode)) {
        val cityCodeList = cityMap.apply(citycode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (citycode -> cityCodeList)
      }
    }
    cityMap = sc.broadcast(cityMap).value
    //    cityMap.take(3).foreach(o=>println(o))

    //    inputRdd.take(5).foreach(o=>println(o))
    val standardLog = inputRdd.map(json => {
      //      val json = new JSONObject()
      val oms_body = json.getJSONObject("oms_body")
      var city_code = oms_body.getString("city_code")
      if (city_code == null) city_code = "-"
      oms_body.put("db_region", "")
      oms_body.put("db_province", "")
      oms_body.put("db_city", "")
      oms_body.put("city_code", city_code)
      val addresseeAddr = oms_body.getString("req_addresss")
      var flag = false
      if (cityMap.contains(city_code)) {
        flag = true
        val cityList: ArrayBuffer[Array[String]] = cityMap.apply(city_code)
        if (cityList.length == 1) {
          //如果只有一个list，一一对应的，直接返回
          oms_body.put("db_province", cityList(0)(0))
          oms_body.put("db_region", cityList(0)(1))
          oms_body.put("db_city", cityList(0)(2))
        } else if (cityList.length > 1) {
          //一个城市代码对应多个城市
          oms_body.put("db_province", cityList(0)(0))
          oms_body.put("db_region", cityList(0)(1))
          for (cityObj <- cityList) {
            val city = cityObj(2)
            val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
            if (addresseeAddr.contains(city) || addresseeAddr.contains(city1)) {
              oms_body.put("db_city", cityObj(2))
            } else {
              if (oms_body.getString("db_city") == null) {
                oms_body.put("db_city", "-")
              }

            }
          }

        }
      }
      //      logger.error("region :"+json.getString("region"))
      (flag, json)
    }).filter(_._1 == true).values

    standardLog
  }

  /**
   * 获取cms库数据库连接
   *
   * @return
   */
  def getRdsConn(comUtil: ComUtil): Connection = {
    var conn: Connection = null

    var dataSource: DruidDataSource = null
    try {
      dataSource = new DruidDataSource()
      dataSource.setDriverClassName(comUtil.getValue("rds_mysql_driver"))
      dataSource.setUrl(comUtil.getValue("rds_mysql_url"))
      dataSource.setUsername(comUtil.getValue("rds_mysql_uid"))
      dataSource.setPassword(comUtil.getValue("rds_mysql_pwd"))
      dataSource.setMaxActive(20)
      dataSource.setMaxWait(3000)
      dataSource.setRemoveAbandoned(false)
      conn = dataSource.getConnection
    } catch {
      case e: Exception => println(">>>mysql数据库连接异常：" + e)
    }
    conn
  }


  /**
   * 指标入库
   *
   * @param wrongIndexRdd
   */
  def saveIndexToHive(spark: SparkSession, zcRecValidRdd: RDD[(String, ZcRecValidObj)], wrongIndexRdd: (RDD[GisObj], RDD[FinalObj], RDD[ZcWdObj]), incDay: String): Unit = {
    import spark.implicits._
    val part1Df = zcRecValidRdd.map(obj => {
      val o = obj._2
      val id = MD5Util.getMD5(Array(o.data_type, o.stat_date, o.city_code, o.city, o.zonecode).mkString("_"))
      OmsDlvFdPart1(id, o.data_type, o.stat_date, o.province, o.region,
        o.city_code, o.city, o.zonecode, o.req, o.gisValidRec, o.sssValidRec,
        o.gisSssValidRec, o.arssValidRec, o.finalValidRec, o.gusRecDiff)
    }).toDF().persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error("旧的错分数量第一部分:" + part1Df.count())
    part1Df.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.oms_dlv_fd_part1")
    part1Df.unpersist()
    val part2Df = wrongIndexRdd._3.map(obj => {
      val o = obj
      val id = MD5Util.getMD5(Array(o.data_type, o.stat_date, o.city_code, o.city, o.zonecode).mkString("_"))
      OmsDlvFdPart2(id, o.data_type, o.stat_date, o.province, o.region, o.city_code, o.city, o.zonecode,
        o.zc, o.zc_norm, o.zc_chkn, o.zc_chke, o.zc_phone, o.zc_road, o.zc_tc2, o.zc_auto, o.zc_normhp, o.zc_normcompany,
        o.zc_sss, o.zc_gissss, o.zc_arss, o.zc_final, o.zc_gus, o.zc_gus_sss, o.zc_gus_both,
        o.zc_chkn_aos, o.zc_chkn_aosnewgid1, o.zc_chkn_optsup, o.zc_chkn_arss, o.zc_chkn_cms, o.zc_chkn_truth, o.zc_chkn_truthqs,
        o.zc_chkn_aostcdj, o.zc_chkn_aostcgj, o.zc_chkn_script, o.zc_chkn_sss, o.zc_chkn_awsm, o.zc_chkn_other)
    }).toDF().persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error("旧的错分数量第二部分:" + part2Df.count())
    part2Df.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.oms_dlv_fd_part2")
    part2Df.unpersist()
    logger.error(">>>旧指标入hive库结束!")
  }

  /**
   * 指标入库(新)
   *
   * @param omsValidRecRdd
   * @param wrongIndexRdd
   * @param dateArray
   */
  def saveIndexNewToHive(spark: SparkSession, omsValidRecRdd: (RDD[RecValidNewObj], RDD[RecValidNewObj], RDD[RecValidNewObj], RDD[RecValidNewObj]),
                         wrongIndexRdd: (RDD[WrongIndexObj], RDD[WrongIndexObj], RDD[WrongIndexObj], RDD[WrongIndexObj]),
                         dateArray: Array[String]): Unit = {

    for (incDay <- dateArray) {
      logger.error(">>>日期：" + incDay)
      val (validDfAll, wrongDfAll) = convertIndexByType(spark, "ALL", omsValidRecRdd._1.filter(obj => obj.stat_date.equals(incDay)), wrongIndexRdd._1.filter(obj => obj.stat_date.equals(incDay)))
      val (validDfRegion, wrongDfRegion) = convertIndexByType(spark, "REGION", omsValidRecRdd._2.filter(obj => obj.stat_date.equals(incDay)), wrongIndexRdd._2.filter(obj => obj.stat_date.equals(incDay)))
      val (validDfCity, wrongDfCity) = convertIndexByType(spark, "CITY", omsValidRecRdd._3.filter(obj => obj.stat_date.equals(incDay)), wrongIndexRdd._3.filter(obj => obj.stat_date.equals(incDay)))
      val (validDfZc, wrongDfZc) = convertIndexByType(spark, "ZC", omsValidRecRdd._4.filter(obj => obj.stat_date.equals(incDay)), wrongIndexRdd._4.filter(obj => obj.stat_date.equals(incDay)))
      val totalValidDf = validDfAll.union(validDfRegion).union(validDfCity).union(validDfZc).persist(StorageLevel.MEMORY_ONLY_SER_2)
      logger.error("total valid 数量:" + totalValidDf.count())
      totalValidDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.dlv_fd_part1")
      totalValidDf.unpersist()
      val totalWdDf = wrongDfAll.union(wrongDfRegion).union(wrongDfCity).union(wrongDfZc).persist(StorageLevel.MEMORY_ONLY_SER_2)
      logger.error("total wd 数量:" + totalWdDf.count())
      totalWdDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.dlv_fd_part2")
      totalWdDf.unpersist()
    }
  }

  def convertIndexByType(spark: SparkSession,
                         statType: String,
                         validRecRdd: RDD[RecValidNewObj],
                         wrongIndexRdd: RDD[WrongIndexObj]) = {
    import spark.implicits._
    logger.error(">>>statType:" + statType)
    val validDf = validRecRdd.map(o => {
      var statContent = "ALL"
      if (statType.equals("ZC")) {
        statContent = o.zonecode
      } else if (statType.equals("REGION")) {
        statContent = o.region
      } else if (statType.equals("CITY")) {
        statContent = o.city
      }
      //计算md5值
      val id = MD5Util.getMD5(Array(o.data_type, o.stat_date, o.region, o.city, o.zonecode, o.ak).mkString("_"))
      DlvFdPart1(id, o.data_type, statType, statContent, o.stat_date, o.region, o.city, o.city_code, o.zonecode, o.ak,
        o.req, o.finalValidRec, o.gisSssValidRec, o.sssValidRec, o.gisValidRec, o.arssValidRec, o.finalValidRecDiff, o.gisValidRecNorm, o.ksValidRec)
    }).toDF()
    logger.error(">>>更新错分数据")
    // 更新错分数据
    val wrongDf = wrongIndexRdd.map(o => {
      var statContent = "ALL"
      if (statType.equals("ZC")) {
        statContent = o.zonecode
      } else if (statType.equals("REGION")) {
        statContent = o.region
      } else if (statType.equals("CITY")) {
        statContent = o.city
      }
      //计算md5值
      val id = MD5Util.getMD5(Array(o.data_type, o.stat_date, o.region, o.city, o.zonecode, o.ak).mkString("_"))
      DlvFdPart2(id, o.data_type, statType, statContent, o.stat_date, o.region, o.city, o.zcWdObj.city_code, o.zonecode,
        o.ak, o.zcWdObj.zc_final, o.zcWdObj.zc_gissss, o.zcWdObj.zc_sss, o.zcWdObj.zc, o.zcWdObj.zc_norm,
        o.zcWdObj.zc_chkn, o.zcWdObj.zc_chkn_aos,
        o.zcWdObj.zc_chkn_aosnewgid1, o.zcWdObj.zc_chkn_optsup, o.zcWdObj.zc_chkn_arss, o.zcWdObj.zc_chkn_cms,
        o.zcWdObj.zc_chkn_truth, o.zcWdObj.zc_chkn_truthqs,
        o.zcWdObj.zc_chkn_aostcdj, o.zcWdObj.zc_chkn_aostcgj, o.zcWdObj.zc_chkn_script, o.zcWdObj.zc_chkn_sss,
        o.zcWdObj.zc_chkn_awsm, o.zcWdObj.zc_chkn_other,
        o.zcWdObj.zc_chke, o.zcWdObj.zc_phone, o.zcWdObj.zc_road, o.zcWdObj.zc_tc2, o.zcWdObj.zc_auto, o.zcWdObj.zc_normhp,
        o.zcWdObj.zc_normcompany, o.zcWdObj.zc_arss, o.zcWdObj.zc_gus_sss, o.zcWdObj.zc_gus, o.zcWdObj.zc_gus_both,
        o.finalObj.fd_final_sss_gisnull, o.finalObj.fd_final_sss_arssnull, o.finalObj.fd_final_sss_arss, o.finalObj.fd_final_sss_arss07,
        o.gisObj.fd_final_sss_isnull, o.gisObj.gisObjNorm.fd_final_sss_isnull, o.gisObj.gisObjChkn.fd_final_sss_isnull,
        o.gisObj.gisObjChke.fd_final_sss_isnull, o.gisObj.gisObjPhone.fd_final_sss_isnull, o.gisObj.gisObjAuto.fd_final_sss_isnull,
        o.gisObj.gisObjRoad.fd_final_sss_isnull, o.gisObj.gisObjTc2.fd_final_sss_isnull,
        o.gisObj.fd_final_same_sss, o.gisObj.gisObjNorm.fd_final_same_sss, o.gisObj.gisObjChkn.fd_final_same_sss,
        o.gisObj.gisObjChke.fd_final_same_sss, o.gisObj.gisObjPhone.fd_final_same_sss, o.gisObj.gisObjAuto.fd_final_same_sss,
        o.gisObj.gisObjRoad.fd_final_same_sss, o.gisObj.gisObjTc2.fd_final_same_sss,
        o.gisObj.fd_final_unsame_sss, o.gisObj.gisObjNorm.fd_final_unsame_sss, o.gisObj.gisObjChkn.fd_final_unsame_sss,
        o.gisObj.gisObjChke.fd_final_unsame_sss, o.gisObj.gisObjPhone.fd_final_unsame_sss, o.gisObj.gisObjAuto.fd_final_unsame_sss,
        o.gisObj.gisObjRoad.fd_final_unsame_sss, o.gisObj.gisObjTc2.fd_final_unsame_sss,
        o.gisObj.fd_final_arss_gis, o.gisObj.gisObjNorm.fd_final_arss_gis, o.gisObj.gisObjChkn.fd_final_arss_gis,
        o.gisObj.gisObjChke.fd_final_arss_gis, o.gisObj.gisObjPhone.fd_final_arss_gis, o.gisObj.gisObjAuto.fd_final_arss_gis,
        o.gisObj.gisObjRoad.fd_final_arss_gis, o.gisObj.gisObjTc2.fd_final_arss_gis, o.zcWdObj.zc_ks
      )
    }).toDF()
    (validDf, wrongDf)
  }

  def saveIndex(validRecRdd: RDD[(String, RecValidObj)], zcRecValidRdd: RDD[(String, ZcRecValidObj)], wrongIndexRdd: (RDD[GisObj], RDD[FinalObj], RDD[ZcWdObj]), comUtil: ComUtil, incDay: String): Unit = {
    //    val gisIndexRdd = wrongIndexRdd._1
    //    val finalIndexRdd = wrongIndexRdd._2
    val zcWdRdd = wrongIndexRdd._3
    //    val OMS_DLV_ZC = "OMS_DLV_ZC"
    //    val OMS_DLV_ZC_GIS = "OMS_DLV_ZC_GIS"
    val OMS_DLV_FD = "OMS_DLV_FD"
    //    val OMS_DLV_ZC_GIS = "RESP_DLV_ZNO_GIS"
    //    val OMS_DLV_ZC = "RESP_DLV_ZNO"
    val conn = getRdsConn(comUtil)
    val md5Instance = MD5Util.getMD5Instance

    //    logger.error(">>>Gis错分指标入库量：" + gisIndexRdd.count() + ",指标入库中...")
    //    gisIndexRdd.take(2).foreach(o => println(o))
    //    val gisInsertSql =
    //      s"""
    //         |insert into $OMS_DLV_ZC_GIS (id,stat_date,province,region,city,city_code,status,status_detail,fd,fd_unsame_sss,fd_final,fd_final_same_sss,fd_final_unsame_sss,fd_final_sss_isnull,fd_final_arss_gis)
    //         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update
    //         |fd=?,fd_unsame_sss=?,fd_final=?,fd_final_same_sss=?,fd_final_unsame_sss=?,fd_final_sss_isnull=?,fd_final_arss_gis=?
    //       """.stripMargin
    //    var gisParams: Array[Any] = null
    //    var gislList = new ArrayBuffer[Array[Any]]
    //    try {
    //      gisIndexRdd.collect().foreach(o => {
    //        val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.city_code, o.city, o.status, o.status_detail).mkString("_"))
    //        gisParams = Array(id, o.stat_date, o.province, o.region, o.city, o.city_code, o.status, o.status_detail, o.fd, o.fd_unsame_sss, o.fd_final, o.fd_final_same_sss, o.fd_final_unsame_sss, o.fd_final_sss_isnull, o.fd_final_arss_gis, o.fd, o.fd_unsame_sss, o.fd_final, o.fd_final_same_sss, o.fd_final_unsame_sss, o.fd_final_sss_isnull, o.fd_final_arss_gis)
    //        gislList += gisParams
    //        //        println("gisParams:"+gisParams.mkString(","))
    //        DbUtils.execute(conn, gisInsertSql, gisParams)
    //      })
    //      //      DbUtils.batchExecute(conn, gisInsertSql, gislList)
    //      logger.error(">>>Gis指标入库结束!")
    //    } catch {
    //      case e: Exception => logger.error(">>>GIS错分指标入库异常：" + e)
    //    }


    //    logger.error(">>>Final错分指标入库量：" + finalIndexRdd.count() + ",指标入库中...")
    //    finalIndexRdd.take(2).foreach(o => println(o))
    //    val finalInsertSql =
    //      s"""
    //         |insert into $OMS_DLV_ZC (id,stat_date,province,region,city_code,city,fd_gis_sss,fd_gis,fd_sss,fd_arss,fd_gis_sss_uss,fd_gis_sss_usg,fd_gis_sss_usb,fd_final,fd_final_gis,fd_final_arss,fd_final_sss,fd_final_sss_gisnull,fd_final_sss_arss,fd_final_sss_arss07,fd_final_sss_arssnull)
    //         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update
    //         |fd_gis_sss=?,fd_gis=?,fd_sss=?,fd_arss=?,fd_gis_sss_uss=?,fd_gis_sss_usg=?,fd_gis_sss_usb=?,fd_final=?,fd_final_gis=?,fd_final_arss=?,fd_final_sss=?,fd_final_sss_gisnull=?,fd_final_sss_arss=?,fd_final_sss_arss07=?,fd_final_sss_arssnull=?
    //       """.stripMargin
    //    var finalParams: Array[Any] = null
    //    try {
    //      finalIndexRdd.collect().foreach(o => {
    //        val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.city_code, o.city).mkString("_"))
    //        finalParams = Array(id, o.stat_date, o.province, o.region, o.city_code, o.city, o.fd_gis_sss, o.fd_gis, o.fd_sss, o.fd_arss, o.fd_gis_sss_uss, o.fd_gis_sss_usg, o.fd_gis_sss_usb, o.fd_final, o.fd_final_gis, o.fd_final_arss, o.fd_final_sss, o.fd_final_sss_gisnull, o.fd_final_sss_arss, o.fd_final_sss_arss07, o.fd_final_sss_arssnull, o.fd_gis_sss, o.fd_gis, o.fd_sss, o.fd_arss, o.fd_gis_sss_uss, o.fd_gis_sss_usg, o.fd_gis_sss_usb, o.fd_final, o.fd_final_gis, o.fd_final_arss, o.fd_final_sss, o.fd_final_sss_gisnull, o.fd_final_sss_arss, o.fd_final_sss_arss07, o.fd_final_sss_arssnull)
    //        DbUtils.execute(conn, finalInsertSql, finalParams)
    //      })
    //      logger.error(">>>Final指标入库结束!")
    //    } catch {
    //      case e: Exception => logger.error(">>>Final错分指标入库异常：" + e)
    //    }
    //    logger.error(">>>Final有效错分识别入库量：" + validRecRdd.count() + ",指标入库中...")
    //    validRecRdd.take(2).foreach(o => println(o))
    //    val finalValidInsertSql =
    //      s"""
    //         |insert into $OMS_DLV_ZC (id,stat_date,province,region,city_code,city,rcg_vld,rcg_gis_vld,rcg_sss_vld,rcg_gis_sss_vld,rcg_arss_vld,gis_sss_unsame_vld,gis_sss_unsame_vld_gis,gis_sss_unsame_vld_sss)
    //         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update
    //         |rcg_vld=?,rcg_gis_vld=?,rcg_sss_vld=?,rcg_gis_sss_vld=?,rcg_arss_vld=?,gis_sss_unsame_vld=?,gis_sss_unsame_vld_gis=?,gis_sss_unsame_vld_sss=?
    //       """.stripMargin
    //    var finalValidParams: Array[Any] = null
    //    try {
    //      validRecRdd.values.collect().foreach(o => {
    //        val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.city_code, o.city).mkString("_"))
    //        finalValidParams = Array(id, o.stat_date, o.province, o.region, o.city_code, o.city, o.finalValidRec, o.gisValidRec, o.sssValidRec, o.gisSssValidRec, o.arssValidRec, o.finalValidRecDiff, o.gisValidRecDiff, o.sssValidRecDiff, o.finalValidRec, o.gisValidRec, o.sssValidRec, o.gisSssValidRec, o.arssValidRec, o.finalValidRecDiff, o.gisValidRecDiff, o.sssValidRecDiff)
    //        DbUtils.execute(conn, finalValidInsertSql, finalValidParams)
    //      })
    //      logger.error(">>>Final有效识别指标入库结束!")
    //    } catch {
    //      case e: Exception => logger.error(">>>Final有效错分指标入库异常：" + e)
    //    }


    logger.error(">>>网点有效识别入库量：" + zcRecValidRdd.count() + ",指标入库中...")
    zcRecValidRdd.take(2).foreach(o => println(o))
    val zcValidInsertSql =
      s"""
         |insert into $OMS_DLV_FD (id,data_type,stat_date,province,region,city_code,city,zonecode,req,rcg_zc_vld,rcg_zc_sss_vld,rcg_zc_gissss_vld,rcg_zc_arss_vld,rcg_zc_final_vld,rcg_zc_gus_vld)
         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update
         |req=?,rcg_zc_vld=?,rcg_zc_sss_vld=?,rcg_zc_gissss_vld=?,rcg_zc_arss_vld=?,rcg_zc_final_vld=?,rcg_zc_gus_vld=?
       """.stripMargin
    var zcValidParams: Array[Any] = null
    try {
      val delFdSql = String.format(s"delete from $OMS_DLV_FD where stat_date='%s'", incDay)
      logger.error(">>>保存之前，删除fd一天的数据:" + delFdSql)
      DbUtils.executeSql(conn, delFdSql)

      zcRecValidRdd.values.collect().foreach(o => {
        val id = MD5Util.getMD5(md5Instance, Array(o.data_type, o.stat_date, o.city_code, o.city, o.zonecode).mkString("_"))
        zcValidParams = Array(id, o.data_type, o.stat_date, o.province, o.region, o.city_code, o.city, o.zonecode, o.req, o.gisValidRec, o.sssValidRec, o.gisSssValidRec, o.arssValidRec, o.finalValidRec, o.gusRecDiff, o.req, o.gisValidRec, o.sssValidRec, o.gisSssValidRec, o.arssValidRec, o.finalValidRec, o.gusRecDiff)
        DbUtils.execute(conn, zcValidInsertSql, zcValidParams)
      })
      logger.error(">>>网点有效识别指标入库结束!")
    } catch {
      case e: Exception => logger.error(">>>网点有效识别指标入库异常：" + e)
    }

    logger.error(">>>网点错分入库量：" + zcWdRdd.count() + ",指标入库中...")
    zcWdRdd.take(2).foreach(o => println(o))
    val zcWdInsertSql =
      s"""
         | insert into $OMS_DLV_FD (id,data_type,stat_date,province,region,city_code,city,zonecode,zc,zc_norm,zc_chkn,zc_chke,
         | zc_phone,zc_road,zc_tc2,zc_auto,zc_normhp,zc_normcompany,zc_sss,zc_gissss,zc_arss,zc_final,zc_gus,zc_gus_sss,zc_gus_both,
         | zc_chkn_aos,zc_chkn_aosnewgid1,zc_chkn_optsup,zc_chkn_arss,zc_chkn_cms,zc_chkn_truth,zc_chkn_truthqs,zc_chkn_aostcdj,zc_chkn_aostcgj,
         | zc_chkn_script,zc_chkn_sss,zc_chkn_awsm,zc_chkn_other)
         | values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update
         | zc=?,zc_norm=?,zc_chkn=?,zc_chke=?,zc_phone=?,zc_road=?,zc_tc2=?,zc_auto=?,zc_normhp=?,zc_normcompany=?,zc_sss=?,
         | zc_gissss=?,zc_arss=?,zc_final=?,zc_gus=?,zc_gus_sss=?,zc_gus_both=?,
         | zc_chkn_aos=?,zc_chkn_aosnewgid1=?,zc_chkn_optsup=?,zc_chkn_arss=?,zc_chkn_cms=?,zc_chkn_truth=?,
         | zc_chkn_truthqs=?,zc_chkn_aostcdj=?,zc_chkn_aostcgj=?,zc_chkn_script=?,zc_chkn_sss=?,zc_chkn_awsm=?,
         | zc_chkn_other=?
       """.stripMargin
    var zcWdParams: Array[Any] = null
    try {
      zcWdRdd.collect().foreach(o => {
        val id = MD5Util.getMD5(md5Instance, Array(o.data_type, o.stat_date, o.city_code, o.city, o.zonecode).mkString("_"))
        zcWdParams = Array(id, o.data_type, o.stat_date, o.province, o.region, o.city_code, o.city, o.zonecode,
          o.zc, o.zc_norm, o.zc_chkn, o.zc_chke, o.zc_phone, o.zc_road, o.zc_tc2, o.zc_auto, o.zc_normhp, o.zc_normcompany,
          o.zc_sss, o.zc_gissss, o.zc_arss, o.zc_final, o.zc_gus, o.zc_gus_sss, o.zc_gus_both,
          o.zc_chkn_aos, o.zc_chkn_aosnewgid1, o.zc_chkn_optsup, o.zc_chkn_arss, o.zc_chkn_cms, o.zc_chkn_truth, o.zc_chkn_truthqs,
          o.zc_chkn_aostcdj, o.zc_chkn_aostcgj, o.zc_chkn_script, o.zc_chkn_sss, o.zc_chkn_awsm, o.zc_chkn_other,
          o.zc, o.zc_norm, o.zc_chkn, o.zc_chke, o.zc_phone, o.zc_road, o.zc_tc2, o.zc_auto, o.zc_normhp, o.zc_normcompany,
          o.zc_sss, o.zc_gissss, o.zc_arss, o.zc_final, o.zc_gus, o.zc_gus_sss, o.zc_gus_both,
          o.zc_chkn_aos, o.zc_chkn_aosnewgid1, o.zc_chkn_optsup, o.zc_chkn_arss, o.zc_chkn_cms, o.zc_chkn_truth, o.zc_chkn_truthqs,
          o.zc_chkn_aostcdj, o.zc_chkn_aostcgj, o.zc_chkn_script, o.zc_chkn_sss, o.zc_chkn_awsm, o.zc_chkn_other)
        DbUtils.execute(conn, zcWdInsertSql, zcWdParams)
      })
      logger.error(">>>网点错分指标入库结束!")
    } catch {
      case e: Exception => logger.error(">>>网点错分指标入库异常：" + e)
    }
    logger.error(">>>指标入库结束!")
  }

  def saveIndexSingleDate(zcRecValidRdd: RDD[(String, ZcRecValidObj)],
                          wrongIndexRdd: (RDD[GisObj], RDD[FinalObj], RDD[ZcWdObj]),
                          comUtil: ComUtil, incDay: String): Unit = {

    val zcWdRdd = wrongIndexRdd._3.filter(obj => obj.stat_date.equals(incDay))
    val OMS_DLV_FD = "OMS_DLV_FD"
    val conn = getRdsConn(comUtil)
    val md5Instance = MD5Util.getMD5Instance

    logger.error(">>>网点有效识别入库量：" + zcRecValidRdd.count() + ",指标入库中...")
    zcRecValidRdd.take(2).foreach(o => println(o))
    val zcValidInsertSql =
      s"""
         |insert into $OMS_DLV_FD (id,data_type,stat_date,province,region,city_code,city,zonecode,req,rcg_zc_vld,rcg_zc_sss_vld,rcg_zc_gissss_vld,rcg_zc_arss_vld,rcg_zc_final_vld,rcg_zc_gus_vld)
         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update
         |req=?,rcg_zc_vld=?,rcg_zc_sss_vld=?,rcg_zc_gissss_vld=?,rcg_zc_arss_vld=?,rcg_zc_final_vld=?,rcg_zc_gus_vld=?
       """.stripMargin
    var zcValidParams: Array[Any] = null
    try {
      val delFdSql = String.format(s"delete from $OMS_DLV_FD where stat_date='%s'", incDay)
      logger.error(">>>保存之前，删除fd一天的数据:" + delFdSql)
      DbUtils.executeSql(conn, delFdSql)

      zcRecValidRdd.values.filter(obj => obj.stat_date.equals(incDay)).collect().foreach(o => {
        val id = MD5Util.getMD5(md5Instance, Array(o.data_type, o.stat_date, o.city_code, o.city, o.zonecode).mkString("_"))
        zcValidParams = Array(id, o.data_type, o.stat_date, o.province, o.region, o.city_code, o.city, o.zonecode, o.req, o.gisValidRec, o.sssValidRec, o.gisSssValidRec, o.arssValidRec, o.finalValidRec, o.gusRecDiff, o.req, o.gisValidRec, o.sssValidRec, o.gisSssValidRec, o.arssValidRec, o.finalValidRec, o.gusRecDiff)
        DbUtils.execute(conn, zcValidInsertSql, zcValidParams)
      })
      logger.error(">>>网点有效识别指标入库结束!")
    } catch {
      case e: Exception => logger.error(">>>网点有效识别指标入库异常：" + e)
    }

    logger.error(">>>网点错分入库量：" + zcWdRdd.count() + ",指标入库中...")
    zcWdRdd.take(2).foreach(o => println(o))
    val zcWdInsertSql =
      s"""
         | insert into $OMS_DLV_FD (id,data_type,stat_date,province,region,city_code,city,zonecode,zc,zc_norm,zc_chkn,zc_chke,
         | zc_phone,zc_road,zc_tc2,zc_auto,zc_normhp,zc_normcompany,zc_sss,zc_gissss,zc_arss,zc_final,zc_gus,zc_gus_sss,zc_gus_both,
         | zc_chkn_aos,zc_chkn_aosnewgid1,zc_chkn_optsup,zc_chkn_arss,zc_chkn_cms,zc_chkn_truth,zc_chkn_truthqs,zc_chkn_aostcdj,zc_chkn_aostcgj,
         | zc_chkn_script,zc_chkn_sss,zc_chkn_awsm,zc_chkn_other)
         | values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update
         | zc=?,zc_norm=?,zc_chkn=?,zc_chke=?,zc_phone=?,zc_road=?,zc_tc2=?,zc_auto=?,zc_normhp=?,zc_normcompany=?,zc_sss=?,
         | zc_gissss=?,zc_arss=?,zc_final=?,zc_gus=?,zc_gus_sss=?,zc_gus_both=?,
         | zc_chkn_aos=?,zc_chkn_aosnewgid1=?,zc_chkn_optsup=?,zc_chkn_arss=?,zc_chkn_cms=?,zc_chkn_truth=?,
         | zc_chkn_truthqs=?,zc_chkn_aostcdj=?,zc_chkn_aostcgj=?,zc_chkn_script=?,zc_chkn_sss=?,zc_chkn_awsm=?,
         | zc_chkn_other=?
       """.stripMargin
    var zcWdParams: Array[Any] = null
    try {
      zcWdRdd.collect().foreach(o => {
        val id = MD5Util.getMD5(md5Instance, Array(o.data_type, o.stat_date, o.city_code, o.city, o.zonecode).mkString("_"))
        zcWdParams = Array(id, o.data_type, o.stat_date, o.province, o.region, o.city_code, o.city, o.zonecode,
          o.zc, o.zc_norm, o.zc_chkn, o.zc_chke, o.zc_phone, o.zc_road, o.zc_tc2, o.zc_auto, o.zc_normhp, o.zc_normcompany,
          o.zc_sss, o.zc_gissss, o.zc_arss, o.zc_final, o.zc_gus, o.zc_gus_sss, o.zc_gus_both,
          o.zc_chkn_aos, o.zc_chkn_aosnewgid1, o.zc_chkn_optsup, o.zc_chkn_arss, o.zc_chkn_cms, o.zc_chkn_truth, o.zc_chkn_truthqs,
          o.zc_chkn_aostcdj, o.zc_chkn_aostcgj, o.zc_chkn_script, o.zc_chkn_sss, o.zc_chkn_awsm, o.zc_chkn_other,
          o.zc, o.zc_norm, o.zc_chkn, o.zc_chke, o.zc_phone, o.zc_road, o.zc_tc2, o.zc_auto, o.zc_normhp, o.zc_normcompany,
          o.zc_sss, o.zc_gissss, o.zc_arss, o.zc_final, o.zc_gus, o.zc_gus_sss, o.zc_gus_both,
          o.zc_chkn_aos, o.zc_chkn_aosnewgid1, o.zc_chkn_optsup, o.zc_chkn_arss, o.zc_chkn_cms, o.zc_chkn_truth, o.zc_chkn_truthqs,
          o.zc_chkn_aostcdj, o.zc_chkn_aostcgj, o.zc_chkn_script, o.zc_chkn_sss, o.zc_chkn_awsm, o.zc_chkn_other)
        DbUtils.execute(conn, zcWdInsertSql, zcWdParams)
      })
      logger.error(">>>网点错分指标入库结束!")
    } catch {
      case e: Exception => logger.error(">>>网点错分指标入库异常：" + e)
    }
    logger.error(">>>指标入库结束!")
  }

  /**
   * 指标入库(新)
   *
   * @param omsValidRecRdd
   * @param wrongIndexRdd
   * @param comUtil
   * @param dateArray
   */
  def saveIndexNew(omsValidRecRdd: (RDD[RecValidNewObj], RDD[RecValidNewObj], RDD[RecValidNewObj], RDD[RecValidNewObj]),
                   wrongIndexRdd: (RDD[WrongIndexObj], RDD[WrongIndexObj], RDD[WrongIndexObj], RDD[WrongIndexObj]),
                   comUtil: ComUtil, dateArray: Array[String]): Unit = {

    val DLV_FD = "DLV_FD"
    logger.error(">>>错分指标表名：" + DLV_FD)
    val conn = getRdsConn(comUtil)
    val md5Instance = MD5Util.getMD5Instance
    val statTypeArray = Array("ALL", "REGION", "CITY", "ZC")
    // 插入有效识别数据
    val insertValidRecSql =
      s"""insert into $DLV_FD (ID,DATA_TYPE,STAT_TYPE,STAT_TYPE_CONTENT,STAT_DATE,REGION,CITY,CITY_CODE,ZONECODE,
         |AK,REQ,ZC_RCG_VLD,ZC_RCG_VLD_GISSSS,ZC_RCG_VLD_SSS,ZC_RCG_VLD_GIS,ZC_RCG_VLD_ARSS,ZC_RCG_VLD_GUS,ZC_RCG_VLD_GIS_NORM)
         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""".stripMargin
    logger.error(">>>insertValidRecSql:" + insertValidRecSql)
    val updateSqlBuilder = new StringBuilder
    updateSqlBuilder.append(" update " + DLV_FD + " set ")
    val updateColumns = Array("ZC", "ZC_GISSSS", "ZC_SSS", "ZC_GIS", "ZC_NORM", "ZC_CHKN", "ZC_CHKN_AOS",
      "ZC_CHKN_AOSNEWGID1", "ZC_CHKN_OPTSUP", "ZC_CHKN_ARSS", "ZC_CHKN_CMS", "ZC_CHKN_TRUTH", "ZC_CHKN_TRUTHQS",
      "ZC_CHKN_AOSTCDJ", "ZC_CHKN_AOSTCGJ", "ZC_CHKN_SCRIPT", "ZC_CHKN_SSS", "ZC_CHKN_AWSM", "ZC_CHKN_OTHER",
      "ZC_CHKE", "ZC_PHONE", "ZC_ROAD", "ZC_TC2", "ZC_AUTO", "ZC_NORMHP", "ZC_NORMCOMPANY",
      "ZC_ARSS", "ZC_GUS_SSS", "ZC_GUS_GIS", "ZC_GUS_BOTH", "ZC_SSS_GISISNULL", "ZC_SSS_CHKNISNULL",
      "ZC_SSS_CHKNISSSS", "ZC_SSS_CHKNIS07", "ZC_GIS_SSSISNULL", "ZC_GIS_SSSISNULL_NORM", "ZC_GIS_SSSISNULL_CHKN",
      "ZC_GIS_SSSISNULL_CHKE", "ZC_GIS_SSSISNULL_PHONE", "ZC_GIS_SSSISNULL_AUTO", "ZC_GIS_SSSISNULL_ROAD",
      "ZC_GIS_SSSISNULL_TC2", "ZC_GIS_SAMESSS", "ZC_GIS_SAMESSS_NORM", "ZC_GIS_SAMESSS_CHKN",
      "ZC_GIS_SAMESSS_CHKE", "ZC_GIS_SAMESSS_PHONE", "ZC_GIS_SAMESSS_AUTO", "ZC_GIS_SAMESSS_ROAD",
      "ZC_GIS_SAMESSS_TC2", "ZC_GIS_UNSAMESSS", "ZC_GIS_UNSAMESSS_NORM", "ZC_GIS_UNSAMESSS_CHKN",
      "ZC_GIS_UNSAMESSS_CHKE", "ZC_GIS_UNSAMESSS_PHONE", "ZC_GIS_UNSAMESSS_AUTO", "ZC_GIS_UNSAMESSS_ROAD",
      "ZC_GIS_UNSAMESSS_TC2", "ZC_GIS_CHKNISGIS", "ZC_GIS_CHKNISGIS_NORM", "ZC_GIS_CHKNISGIS_CHKN",
      "ZC_GIS_CHKNISGIS_CHKE", "ZC_GIS_CHKNISGIS_PHONE", "ZC_GIS_CHKNISGIS_AUTO", "ZC_GIS_CHKNISGIS_ROAD",
      "ZC_GIS_CHKNISGIS_TC2")
    for (i <- updateColumns.indices) {
      updateSqlBuilder.append(" " + updateColumns.apply(i) + "=?,")
    }
    updateSqlBuilder.deleteCharAt(updateSqlBuilder.length - 1)
    updateSqlBuilder.append(" where ID=? ")
    val updateWrongSql = updateSqlBuilder.toString()
    logger.error(">>>updateWrongSql:" + updateWrongSql)

    for (incDay <- dateArray) {
      if (dateArray.indexOf(incDay) == 0) {
        logger.error(">>>日期：" + incDay)
        logger.error(">>>删除当天指标数据")
        val delSql = "delete from " + DLV_FD + " where stat_date='" + incDay + "'"
        DbUtils.executeSql(conn, delSql)
        saveIndexByType(conn, md5Instance, insertValidRecSql, updateWrongSql, "ALL", omsValidRecRdd._1.filter(obj => obj.stat_date.equals(incDay)), wrongIndexRdd._1.filter(obj => obj.stat_date.equals(incDay)))
        saveIndexByType(conn, md5Instance, insertValidRecSql, updateWrongSql, "REGION", omsValidRecRdd._2.filter(obj => obj.stat_date.equals(incDay)), wrongIndexRdd._2.filter(obj => obj.stat_date.equals(incDay)))
        saveIndexByType(conn, md5Instance, insertValidRecSql, updateWrongSql, "CITY", omsValidRecRdd._3.filter(obj => obj.stat_date.equals(incDay)), wrongIndexRdd._3.filter(obj => obj.stat_date.equals(incDay)))
        saveIndexByType(conn, md5Instance, insertValidRecSql, updateWrongSql, "ZC", omsValidRecRdd._4.filter(obj => obj.stat_date.equals(incDay)), wrongIndexRdd._4.filter(obj => obj.stat_date.equals(incDay)))

      }
    }
  }

  /**
   * 按聚合类型保存指标
   */
  def saveIndexByType(conn: Connection, md5Instance: MessageDigest, insertValidRecSql: String,
                      updateWrongSql: String, statType: String,
                      validRecRdd: RDD[RecValidNewObj],
                      wrongIndexRdd: RDD[WrongIndexObj]): Unit = {
    logger.error(">>>statType:" + statType)
    logger.error(">>>插入有效识别数据")
    var count = 0
    validRecRdd.collect().foreach(o => {
      count = count + 1
      if (count % 1000 == 0) {
        logger.error(">>>count:" + count)
      }
      var statContent = "ALL"
      if (statType.equals("ZC")) {
        statContent = o.zonecode
      } else if (statType.equals("REGION")) {
        statContent = o.region
      } else if (statType.equals("CITY")) {
        statContent = o.city
      }
      //计算md5值
      val id = MD5Util.getMD5(md5Instance, Array(o.data_type, o.stat_date, o.region, o.city, o.zonecode, o.ak).mkString("_"))
      val fdParams = Array(id, o.data_type, statType, statContent, o.stat_date, o.region, o.city, o.city_code, o.zonecode, o.ak,
        o.req, o.finalValidRec, o.gisSssValidRec, o.sssValidRec, o.gisValidRec, o.arssValidRec, o.finalValidRecDiff, o.gisValidRecNorm)
      DbUtils.execute(conn, insertValidRecSql, fdParams)
    })
    logger.error(">>>更新错分数据")
    // 更新错分数据
    wrongIndexRdd.collect().foreach(o => {
      var statContent = "ALL"
      if (statType.equals("ZC")) {
        statContent = o.zonecode
      } else if (statType.equals("REGION")) {
        statContent = o.region
      } else if (statType.equals("CITY")) {
        statContent = o.city
      }
      //计算md5值
      val id = MD5Util.getMD5(md5Instance, Array(o.data_type, o.stat_date, o.region, o.city, o.zonecode, o.ak).mkString("_"))
      val fdParams = Array(o.zcWdObj.zc_final, o.zcWdObj.zc_gissss, o.zcWdObj.zc_sss, o.zcWdObj.zc, o.zcWdObj.zc_norm,
        o.zcWdObj.zc_chkn, o.zcWdObj.zc_chkn_aos,
        o.zcWdObj.zc_chkn_aosnewgid1, o.zcWdObj.zc_chkn_optsup, o.zcWdObj.zc_chkn_arss, o.zcWdObj.zc_chkn_cms,
        o.zcWdObj.zc_chkn_truth, o.zcWdObj.zc_chkn_truthqs,
        o.zcWdObj.zc_chkn_aostcdj, o.zcWdObj.zc_chkn_aostcgj, o.zcWdObj.zc_chkn_script, o.zcWdObj.zc_chkn_sss,
        o.zcWdObj.zc_chkn_awsm, o.zcWdObj.zc_chkn_other,
        o.zcWdObj.zc_chke, o.zcWdObj.zc_phone, o.zcWdObj.zc_road, o.zcWdObj.zc_tc2, o.zcWdObj.zc_auto, o.zcWdObj.zc_normhp,
        o.zcWdObj.zc_normcompany, o.zcWdObj.zc_arss, o.zcWdObj.zc_gus_sss, o.zcWdObj.zc_gus, o.zcWdObj.zc_gus_both,
        o.finalObj.fd_final_sss_gisnull, o.finalObj.fd_final_sss_arssnull, o.finalObj.fd_final_sss_arss, o.finalObj.fd_final_sss_arss07,
        o.gisObj.fd_final_sss_isnull, o.gisObj.gisObjNorm.fd_final_sss_isnull, o.gisObj.gisObjChkn.fd_final_sss_isnull,
        o.gisObj.gisObjChke.fd_final_sss_isnull, o.gisObj.gisObjPhone.fd_final_sss_isnull, o.gisObj.gisObjAuto.fd_final_sss_isnull,
        o.gisObj.gisObjRoad.fd_final_sss_isnull, o.gisObj.gisObjTc2.fd_final_sss_isnull,
        o.gisObj.fd_final_same_sss, o.gisObj.gisObjNorm.fd_final_same_sss, o.gisObj.gisObjChkn.fd_final_same_sss,
        o.gisObj.gisObjChke.fd_final_same_sss, o.gisObj.gisObjPhone.fd_final_same_sss, o.gisObj.gisObjAuto.fd_final_same_sss,
        o.gisObj.gisObjRoad.fd_final_same_sss, o.gisObj.gisObjTc2.fd_final_same_sss,
        o.gisObj.fd_final_unsame_sss, o.gisObj.gisObjNorm.fd_final_unsame_sss, o.gisObj.gisObjChkn.fd_final_unsame_sss,
        o.gisObj.gisObjChke.fd_final_unsame_sss, o.gisObj.gisObjPhone.fd_final_unsame_sss, o.gisObj.gisObjAuto.fd_final_unsame_sss,
        o.gisObj.gisObjRoad.fd_final_unsame_sss, o.gisObj.gisObjTc2.fd_final_unsame_sss,
        o.gisObj.fd_final_arss_gis, o.gisObj.gisObjNorm.fd_final_arss_gis, o.gisObj.gisObjChkn.fd_final_arss_gis,
        o.gisObj.gisObjChke.fd_final_arss_gis, o.gisObj.gisObjPhone.fd_final_arss_gis, o.gisObj.gisObjAuto.fd_final_arss_gis,
        o.gisObj.gisObjRoad.fd_final_arss_gis, o.gisObj.gisObjTc2.fd_final_arss_gis,
        id
      )
      DbUtils.execute(conn, updateWrongSql, fdParams)
    })
  }

  def saveAoiWdIndex(aoiWdIndexRdd: RDD[(String, AoiWdObj)],
                     comUtil: ComUtil, dateArray: Array[String],
                     tableName: String = "DLV_AOI_FD"): Unit = {

    val DLV_AOI_FD = tableName
    logger.error(">>>AOI错分指标表名：" + DLV_AOI_FD)
    val conn = getRdsConn(comUtil)
    val md5Instance = MD5Util.getMD5Instance
    // 插入有效识别数据
    val insertValidRecSql =
      s"""insert into $DLV_AOI_FD (ID,STAT_DATE,REGION,CITY_CODE,CITY,
         |REQ,AOI,AOI_WRONG,AOI_KS,AOI_WRONG_KS,AOI_ARSS,AOI_WRONG_ARSS,
         |AOI_GIS,AOI_WRONG_GIS,AOI_WRONG_GIS_NORM,AOI_WRONG_GIS_CHKN,
         |AOI_WRONG_GIS_CHKE,AOI_WRONG_GIS_PHONE,AOI_WRONG_GIS_ROAD,
         |AOI_WRONG_GIS_TC2,AOI_WRONG_GIS_AUTO,AOI_WRONG_GIS_NORMHP,
         |AOI_WRONG_GIS_NORMCOMPANY,AOI_WRONG_GIS_OTHER)
         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""".stripMargin
    logger.error(">>>insertValidRecSql:" + insertValidRecSql)
    for (incDay <- dateArray) {
      logger.error(">>>日期：" + incDay)
      logger.error(">>>删除当天指标数据")
      val delSql = "delete from " + DLV_AOI_FD + " where STAT_DATE='" + incDay + "'"
      DbUtils.executeSql(conn, delSql)
      val tmpRdd = aoiWdIndexRdd.filter(obj => obj._2.stat_date.equals(incDay)).values
      tmpRdd.collect().foreach(o => {
        //计算md5值
        val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.region, o.city_code, o.city).mkString("_"))
        val fdParams = Array(id, o.stat_date, o.region, o.city_code, o.city,
          o.req, o.aoi, o.aoi_wrong, o.aoi_ks, o.aoi_ks_wrong, o.aoi_arss, o.aoi_arss_wrong,
          o.aoi_gis, o.aoi_gis_wrong, o.aoi_gis_wrong_norm, o.aoi_gis_wrong_chkn,
          o.aoi_gis_wrong_chke, o.aoi_gis_wrong_phone, o.aoi_gis_wrong_road,
          o.aoi_gis_wrong_tc2, o.aoi_gis_wrong_auto, o.aoi_gis_wrong_normhp,
          o.aoi_gis_wrong_normcompany, o.aoi_gis_wrong_other
        )
        DbUtils.execute(conn, insertValidRecSql, fdParams)
      }
      )
    }
  }

  def saveAoiRealWdIndex(aoiWdIndexRdd: RDD[(String, AoiWdObj)],
                         comUtil: ComUtil, dateArray: Array[String]): Unit = {

    val DLV_AOI_REAL_FD = "DLV_AOI_REAL_FD"
    logger.error(">>>AOI真实错分指标表名：" + DLV_AOI_REAL_FD)
    val conn = getRdsConn(comUtil)
    val md5Instance = MD5Util.getMD5Instance
    // 插入有效识别数据
    val insertValidRecSql =
      s"""insert into $DLV_AOI_REAL_FD (ID,STAT_DATE,REGION,CITY_CODE,CITY,
         |REQ,AOI,AOI_WRONG,AOI_KS,AOI_WRONG_KS,AOI_ARSS,AOI_WRONG_ARSS,
         |AOI_GIS,AOI_WRONG_GIS,AOI_WRONG_GIS_NORM,AOI_WRONG_GIS_CHKN,
         |AOI_WRONG_GIS_CHKE,AOI_WRONG_GIS_PHONE,AOI_WRONG_GIS_ROAD,
         |AOI_WRONG_GIS_TC2,AOI_WRONG_GIS_AUTO,AOI_WRONG_GIS_NORMHP,
         |AOI_WRONG_GIS_NORMCOMPANY,AOI_WRONG_GIS_OTHER)
         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""".stripMargin
    logger.error(">>>insertValidRecSql:" + insertValidRecSql)
    for (incDay <- dateArray) {
      logger.error(">>>日期：" + incDay)
      val tmpRdd = aoiWdIndexRdd.filter(obj => obj._2.stat_date.equals(incDay)).values
      if (tmpRdd.count() != 0) {
        logger.error(">>>删除当天指标数据")
        val delSql = "delete from " + DLV_AOI_REAL_FD + " where STAT_DATE='" + incDay + "'"
        DbUtils.executeSql(conn, delSql)
        tmpRdd.collect().foreach(o => {
          //计算md5值
          val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.region, o.city_code, o.city).mkString("_"))
          val fdParams = Array(id, o.stat_date, o.region, o.city_code, o.city,
            o.req, o.aoi, o.aoi_wrong, o.aoi_ks, o.aoi_ks_wrong, o.aoi_arss, o.aoi_arss_wrong,
            o.aoi_gis, o.aoi_gis_wrong, o.aoi_gis_wrong_norm, o.aoi_gis_wrong_chkn,
            o.aoi_gis_wrong_chke, o.aoi_gis_wrong_phone, o.aoi_gis_wrong_road,
            o.aoi_gis_wrong_tc2, o.aoi_gis_wrong_auto, o.aoi_gis_wrong_normhp,
            o.aoi_gis_wrong_normcompany, o.aoi_gis_wrong_other
          )
          DbUtils.execute(conn, insertValidRecSql, fdParams)
        }
        )
      }
    }
  }

  def saveAoiRealWdIndexZc(aoiWdIndexRdd: RDD[(String, AoiWdObj)],
                           comUtil: ComUtil, dateArray: Array[String]): Unit = {

    val DLV_AOI_REAL_FD_ZC = "DLV_AOI_REAL_FD_ZC"
    logger.error(">>>AOI真实错分网点维度指标表名：" + DLV_AOI_REAL_FD_ZC)
    val conn = getRdsConn(comUtil)
    val md5Instance = MD5Util.getMD5Instance
    // 插入有效识别数据
    val insertValidRecSql =
      s"""insert into $DLV_AOI_REAL_FD_ZC (ID,STAT_DATE,REGION,CITY_CODE,CITY,ZONE_CODE,
         |REQ,AOI,AOI_WRONG,AOI_KS,AOI_WRONG_KS,AOI_ARSS,AOI_WRONG_ARSS,
         |AOI_GIS,AOI_WRONG_GIS,AOI_WRONG_GIS_NORM,AOI_WRONG_GIS_CHKN,
         |AOI_WRONG_GIS_CHKE,AOI_WRONG_GIS_PHONE,AOI_WRONG_GIS_ROAD,
         |AOI_WRONG_GIS_TC2,AOI_WRONG_GIS_AUTO,AOI_WRONG_GIS_NORMHP,
         |AOI_WRONG_GIS_NORMCOMPANY,AOI_WRONG_GIS_OTHER)
         |values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""".stripMargin
    logger.error(">>>insertValidRecSql:" + insertValidRecSql)
    for (incDay <- dateArray) {
      logger.error(">>>日期：" + incDay)
      val tmpRdd = aoiWdIndexRdd.filter(obj => obj._2.stat_date.equals(incDay)).values
      if (tmpRdd.count() != 0) {
        logger.error(">>>删除当天指标数据")
        val delSql = "delete from " + DLV_AOI_REAL_FD_ZC + " where STAT_DATE='" + incDay + "'"
        DbUtils.executeSql(conn, delSql)
        tmpRdd.collect().foreach(o => {
          //计算md5值
          val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.region, o.city_code, o.city, o.zone_code).mkString("_"))
          val fdParams = Array(id, o.stat_date, o.region, o.city_code, o.city, o.zone_code,
            o.req, o.aoi, o.aoi_wrong, o.aoi_ks, o.aoi_ks_wrong, o.aoi_arss, o.aoi_arss_wrong,
            o.aoi_gis, o.aoi_gis_wrong, o.aoi_gis_wrong_norm, o.aoi_gis_wrong_chkn,
            o.aoi_gis_wrong_chke, o.aoi_gis_wrong_phone, o.aoi_gis_wrong_road,
            o.aoi_gis_wrong_tc2, o.aoi_gis_wrong_auto, o.aoi_gis_wrong_normhp,
            o.aoi_gis_wrong_normcompany, o.aoi_gis_wrong_other
          )
          DbUtils.execute(conn, insertValidRecSql, fdParams)
        }
        )
      }
    }
  }
}
