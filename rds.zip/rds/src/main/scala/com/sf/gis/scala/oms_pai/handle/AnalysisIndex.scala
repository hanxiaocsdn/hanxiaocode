package com.sf.gis.scala.oms_pai.handle

import java.text.SimpleDateFormat

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.oms_pai.obj.Case._
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01375125 on 2018/9/27.
 */
object AnalysisIndex {
  @transient lazy val logger = Logger.getLogger(this.getClass.getSimpleName.replace("$", ""))

  /**
   * 统计指标
   */
  def stat(reqRdd: RDD[JSONObject], reRdd: RDD[JSONObject]): (RDD[ReqDataMin], RDD[ReqDataDayFinal], RDD[ReDataDayFinal]) = {

    //统计请求指标
    val reqIndexRdd = statReqIndexRdd(reqRdd)
    logger.error(">>>统计返回指标(天)")
    val reRddByDate = statReIndexRdd(reRdd: RDD[JSONObject])
    reRddByDate.take(2).foreach(o => {
      println(o)
    })
    reqRdd.unpersist()
    reRdd.unpersist()
    (reqIndexRdd._1, reqIndexRdd._2, reRddByDate)
  }


  /**
   * 统计请求指标
   *
   * @param reqRdd
   */
  def statReqIndexRdd(reqRdd: RDD[JSONObject]): (RDD[ReqDataMin], RDD[ReqDataDayFinal]) = {

    //获取有效数据集
    val validReqRdd = getValidReqRdd(reqRdd)
    //    validReqRdd.collect().foreach(o=>{println(o)})

    //每分钟统计指标
    val reqStatIndexMin = statReqIndexByMin(validReqRdd)
    val reqStatIndexMinAk = reqStatIndexMin._1 //datetime ak维度
    val reqStatIndexMinAkAll = reqStatIndexMin._2 //datetime维度（ak为ALL）
    //    reqStatIndexMin.collect().foreach(o=>{println(o)})

    //按天统计指标
    val reqStatIndexDay = statReqIndexByDay(reqStatIndexMinAk)
    //    reqDataDetail.collect().foreach(o=>{println(o)})
    (reqStatIndexMinAkAll, reqStatIndexDay)
  }

  /**
   * 统计返回指标
   *
   * @param reRdd
   */
  def statReIndexRdd(reRdd: RDD[JSONObject]): RDD[ReDataDayFinal] = {
    //统计每行返回数据
    val reDataByRow: RDD[ReDataDay] = reRdd.map(obj => {
      //统计每行的指标
      statReIndexByRow(obj)
    })
    //统计一整天的数据,sum
    var countMap: Map[String, Int] = Map()
    val reDataDaySum = reDataByRow.filter(_ != null).map(o => {
      val key = o.date
      (key, o)
    }).reduceByKey((o1, o2) => {
      val req_cnt = o1.req_cnt + o2.req_cnt
      val trans_cnt = o1.trans_cnt + o2.trans_cnt
      new ReDataDay(o1.date, o1.ak, o1.resp_status, o1.status_detail, req_cnt, trans_cnt)
    }).collect().foreach(t => {
      val key = t._1
      val o = t._2
      val req_cnt = o.req_cnt
      val trans_cnt = o.trans_cnt
      //      countMap +=(key -> o)
      countMap += ("req_cnt_sum" -> req_cnt)
      countMap += ("trans_cnt_sum" -> trans_cnt)
    })

    //统计维度date ak resp_status status_detail
    val reDataByRowAk = reDataByRow.map(o => {
      val key = Array(o.date, o.ak, o.resp_status, o.status_detail).mkString("_")
      (key, o)
    })

    //统计维度date resp_status status_detail(ak="ALL")
    val reDataByRowAkAll = reDataByRow.map(obj => {
      val tmpObj = obj.copy(ak = "ALL")
      val key = Array(tmpObj.date, tmpObj.ak, tmpObj.resp_status, tmpObj.status_detail).mkString("_")
      (key, tmpObj)
    })

    val reDataDayAk = mergeReIndex(reDataByRowAk, countMap)
    val reDataDayAkAll = mergeReIndex(reDataByRowAkAll, countMap)

    reDataDayAk.union(reDataDayAkAll)
  }

  def mergeReIndex(reIndexRdd: RDD[(String, ReDataDay)], countMap: Map[String, Int]): RDD[ReDataDayFinal] = {
    //统计一整天的数据
    val reDataDay: RDD[ReDataDayFinal] = reIndexRdd.reduceByKey((o1, o2) => {
      val req_cnt = o1.req_cnt + o2.req_cnt
      val trans_cnt = o1.trans_cnt + o2.trans_cnt
      new ReDataDay(o1.date, o1.ak, o1.resp_status, o1.status_detail, req_cnt, trans_cnt)
    }).map(obj => {
      val key = obj._1
      val o = obj._2
      val req_cnt_sum = countMap.apply("req_cnt_sum")
      val trans_cnt_sum = countMap.apply("trans_cnt_sum")
      new ReDataDayFinal(o.date, o.ak, o.resp_status, o.status_detail, req_cnt_sum, o.req_cnt, trans_cnt_sum, o.trans_cnt)
    })
    reDataDay
  }

  /**
   * 按行统计返回量
   *
   * @param obj
   * @return
   */
  def statReIndexByRow(obj: JSONObject): ReDataDay = {
    var reDataDay: ReDataDay = null
    try {
      val re_cnt = 1
      var trans_cnt = 0
      var ak = "-"
      var resp_status = "-"
      var status_detail = "-"
      val return_body = obj.getJSONObject("return_body")
      val url_body = return_body.getJSONObject("url")
      if (url_body != null && url_body.getString("ak") != null) ak = url_body.getString("ak")
      val datetime = return_body.getString("dateTime")
      val date = datetime.split(" ")(0)
      val data_body = return_body.getJSONObject("data")
      if (data_body != null) {
        resp_status = data_body.getString("status")
        //当响应状态为0时，存储的是响应来源
        if (resp_status != null && resp_status.equals("0")) {
          val result_doby = data_body.getJSONObject("result")
          if (result_doby != null) {
            val src = result_doby.getString("src")
            if (src != null) {
              if (src.equals("bd") || src.equals("gd") || src.equals("sf")) trans_cnt = 1
              status_detail = src
            }
          }
        }
      }
      reDataDay = new ReDataDay(date, ak, resp_status, status_detail, re_cnt, trans_cnt)
    } catch {
      case e: Exception => logger.error(">>>统计行返回量指标异常：" + e)
    }
    reDataDay
  }

  /**
   * 统计每分钟请求的指标
   *
   * @param validReqRdd
   * @return
   */
  def statReqIndexByMin(validReqRdd: RDD[JSONObject]): (RDD[ReqDataMin], RDD[ReqDataMin]) = {
    val reqRowIndexRdd = validReqRdd.map(obj => {
      //统计每行的指标
      statReqIndexByRow(obj)
    }).filter(_ != null)
    //维度 ak datatime
    val reqRowAkIndexRdd = reqRowIndexRdd.map(o => {
      val key = Array(o.ak, o.datetime).mkString("_")
      (key, o)
    })

    //构建ak为all的行指标rdd ,维度datetime
    val reqRowAkAllIndexRdd = reqRowIndexRdd.map(o => {
      val ak = "ALL"
      val key = Array(ak, o.datetime).mkString("_")
      val reqData = new ReqDataRow(o.date, o.datetime, ak, o.req_cnt, o.respTimeList)
      (key, reqData)
    })

    val reqMinAkIndexRdd = mergeReqRowIndex(reqRowAkIndexRdd) //维度ak datetime
    val reqMinAkAllIndexRdd = mergeReqRowIndex(reqRowAkAllIndexRdd) //维度datetime

    (reqMinAkIndexRdd, reqMinAkIndexRdd.union(reqMinAkAllIndexRdd))
  }

  /**
   * 根据每行指标，计算分钟的指标
   *
   * @param rowIndexRdd
   * @return
   */
  def mergeReqRowIndex(rowIndexRdd: RDD[(String, ReqDataRow)]): RDD[ReqDataMin] = {
    val rowIndexReRdd = rowIndexRdd.reduceByKey((o1, o2) => {
      val req_cnt = o1.req_cnt + o2.req_cnt
      //把每个响应时间数组相加
      val respTimeList = (o1.respTimeList ++= o2.respTimeList)
      new ReqDataRow(o1.date, o1.datetime, o1.ak, req_cnt, respTimeList)
    }).map(obj => {
      val o = obj._2
      var respTimeList = o.respTimeList
      //平均响应时间
      var respTimeSum = 0
      for (time <- respTimeList) {
        respTimeSum += time
        //响应时间为0的移除掉
        if (time == 0) respTimeList -= time
      }
      respTimeList = respTimeList.sorted //升序排列
      var avgRespTime, p99RespTime, minRespTime, maxRespTime = 0
      val size = respTimeList.length
      if (size > 0) {
        avgRespTime = Math.round(respTimeSum / respTimeList.length)
        val p99Index = Math.round(respTimeList.length * 0.99).toInt
        p99RespTime = respTimeList(p99Index - 1) //99%响应时间
        minRespTime = respTimeList(0) //最小响应时间
        maxRespTime = respTimeList(respTimeList.length - 1) //最大响应时间
      }
      new ReqDataMin(o.date, o.datetime, o.ak, o.req_cnt, avgRespTime, maxRespTime, minRespTime, p99RespTime)
    })
    rowIndexReRdd
  }


  /**
   * 统计每天的指标
   *
   * @param reqStatIndexMin
   * @return
   */
  def statReqIndexByDay(reqStatIndexMin: RDD[ReqDataMin]): RDD[ReqDataDayFinal] = {

    val reqIndexMin = reqStatIndexMin.map(o => {
      val reqCntList = new ArrayBuffer[Int]()
      reqCntList += o.req_cnt
      val avgRespTimeList = new ArrayBuffer[Int]()
      avgRespTimeList += o.avgRespTime
      val maxRespTimeList = new ArrayBuffer[Int]()
      maxRespTimeList += o.maxRespTime
      val minRespTimeList = new ArrayBuffer[Int]()
      minRespTimeList += o.minRespTime
      val p99RespTimeList = new ArrayBuffer[Int]()
      p99RespTimeList += o.p99RespTime
      //按天统计每分钟的指标
      val reqDataDay = new ReqDataDay(o.date, o.ak, o.req_cnt, reqCntList, avgRespTimeList, maxRespTimeList, minRespTimeList, p99RespTimeList)
      reqDataDay
    })
    //维度 date ak
    val reqIndexAkMin = reqIndexMin.map(o => {
      val key = Array(o.date, o.ak).mkString("_")
      (key, o)
    })

    //维度 date
    val reqIndexAkAllMin = reqIndexMin.map(o => {
      val ak = "ALL"
      val key = Array(o.date, ak).mkString("_")
      (key, new ReqDataDay(o.date, ak, o.req_cnt_sum, o.reqCntList, o.avgRespTimeList, o.maxRespTimeList, o.minRespTimeList, o.p99RespTimeList))
    })

    val reqDataAkDetail = getReqIndexByDay(reqIndexAkMin)
    val reqDataAkAllDetail = getReqIndexByDay(reqIndexAkAllMin)

    reqDataAkDetail.union(reqDataAkAllDetail)
  }


  def getReqIndexByDay(reqIndexRdd: RDD[(String, ReqDataDay)]): RDD[ReqDataDayFinal] = {
    val reqDataDetail: RDD[ReqDataDayFinal] = reqIndexRdd.reduceByKey((o1, o2) => {
      //合并到每天
      mergeByDay(o1, o2)
    }).map(t => {
      val o = t._2
      val date = o.date
      val ak = o.ak
      val req_cnt_sum = o.req_cnt_sum
      val reqCntList = o.reqCntList.sorted
      val avgRespTimeList = o.avgRespTimeList.sorted
      val maxRespTimeList = o.maxRespTimeList.sorted
      val minRespTimeList = o.minRespTimeList.sorted
      val p99RespTimeList = o.p99RespTimeList.sorted

      val req_cnt_max = reqCntList(reqCntList.length - 1) //当天每分钟最大请求量
      val req_cnt_min = reqCntList(0) //当天每分钟最小请求量
      val req_cnt_avg = Math.round(reqCntList.sum / reqCntList.length) //当天每分钟平均请求量
      val maxRespTime = maxRespTimeList(maxRespTimeList.length - 1) //当天每分钟最大响应时间
      val minRespTime = minRespTimeList(0) //当天每分钟最小响应时间
      val avgRespTime = Math.round(avgRespTimeList.sum / avgRespTimeList.length) //当天每分钟平均响应时间
      val p99RespTimeMax = p99RespTimeList(p99RespTimeList.length - 1) //当天每分钟99%最大响应时间
      val p99RespTimeMin = p99RespTimeList(0) //当天每分钟99%最小响应时间
      val p99RespTimeAvg = Math.round(p99RespTimeList.sum / p99RespTimeList.length) //当天每分钟99%平均响应时间
      //按天统计每分钟指标-最终结果
      new ReqDataDayFinal(date, ak, req_cnt_sum, req_cnt_max, req_cnt_min, req_cnt_avg, maxRespTime, minRespTime, avgRespTime, p99RespTimeMax, p99RespTimeMin, p99RespTimeAvg)
    })

    reqDataDetail
  }

  /**
   * 获取有效的请求数据集
   *
   * @param reqRdd
   * @return
   */
  def getValidReqRdd(reqRdd: RDD[JSONObject]): RDD[JSONObject] = {

    val validReqRdd = reqRdd.filter(obj => {
      val start_body = obj.getJSONObject("start_body")
      start_body != null
    })
    logger.error(">>>有start_body（即为有效的统计数据）的请求数据总量：" + validReqRdd.count())

    val validReqRddBoth = reqRdd.filter(obj => {
      val start_body = obj.getJSONObject("start_body")
      val centre_body = obj.getJSONObject("centre_body")
      start_body != null && centre_body != null
    })
    logger.error(">>>有start_body和centre_body的量:" + validReqRddBoth.count())

    val yesStartNoCentreRdd = reqRdd.filter(obj => {
      val start_body = obj.getJSONObject("start_body")
      val centre_body = obj.getJSONObject("centre_body")
      start_body != null && centre_body == null
    })
    logger.error(">>>有start_body，无centre_body的量:" + yesStartNoCentreRdd.count())

    val noStartYesCentreRdd = reqRdd.filter(obj => {
      val start_body = obj.getJSONObject("start_body")
      val centre_body = obj.getJSONObject("centre_body")
      start_body == null && centre_body != null
    })
    logger.error(">>>无start_body，有centre_body的量:" + noStartYesCentreRdd.count())
    //    validReqRdd
    validReqRddBoth
  }


  def mergeByDay(o1: ReqDataDay, o2: ReqDataDay): ReqDataDay = {
    val date = o1.date
    val ak = o1.ak
    val req_cnt_sum = o1.req_cnt_sum + o2.req_cnt_sum
    val reqCntList = (o1.reqCntList ++= o2.reqCntList).sorted
    val avgRespTimeList = (o1.avgRespTimeList ++= o2.avgRespTimeList).sorted
    val maxRespTimeList = (o1.maxRespTimeList ++= o2.maxRespTimeList).sorted
    val minRespTimeList = (o1.minRespTimeList ++= o2.minRespTimeList).sorted
    val p99RespTimeList = (o1.p99RespTimeList ++= o2.p99RespTimeList).sorted
    new ReqDataDay(date, ak, req_cnt_sum, reqCntList, avgRespTimeList, maxRespTimeList, minRespTimeList, p99RespTimeList)
  }


  /**
   * 统计请求明细数据指标
   *
   * @param obj
   * @return
   */
  def statReqIndexByRow(obj: JSONObject): ReqDataRow = {
    var result: ReqDataRow = null
    try {
      var req_cnt = 0
      var spendTime: Int = 0
      val start_body = obj.getJSONObject("start_body")
      if (start_body != null) req_cnt = 1
      val url_body = start_body.getJSONObject("url")
      var ak = "-"
      if (url_body.getString("ak") != null) ak = url_body.getString("ak")
      val req_time = start_body.getString("dateTime")
      val date = req_time.split(" ")(0).replaceAll("-", "")
      val datetime = getyyyyMMddHHmm(req_time)

      val centre_body = obj.getJSONObject("centre_body")
      if (centre_body != null) {
        val centre_time = centre_body.getString("dateTime ")
        if (req_time != null && centre_time != null) {
          spendTime = getSpendTime(req_time, centre_time).toInt
        }
        if (centre_body.getString("time") != null) spendTime = centre_body.getString("time").toInt
      }

      val respTimeList = new ArrayBuffer[Int]()
      respTimeList += spendTime
      result = ReqDataRow(date, datetime, ak, req_cnt, respTimeList)
    } catch {
      case e: Exception => logger.info(">>>统计请求明细指标异常：" + e)
    }
    result
  }

  def getyyyyMMddHHmm(time: String): String = {
    time.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "").substring(0, 12)
  }

  def getSpendTime(startTime: String, endTime: String, format: String = "yyyy-MM-dd HH:mm:ss.SSS"): Long = {
    var spendTime = 0L
    val startLongTime = datetimeToLong(startTime, format)
    val endLongTime = datetimeToLong(endTime, format)
    spendTime = endLongTime - startLongTime
    spendTime
  }

  def datetimeToLong(time: String, format: String): Long = {
    var result = 0L
    try {
      if (time != null) {
        val sdf: SimpleDateFormat = new SimpleDateFormat(format)
        val longTime = sdf.parse(time).getTime
        result = longTime
      }
    } catch {
      case e: Exception => logger.error(">>>转换异常：" + e)
    }
    result
  }

}
