package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.net.URLEncoder
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, MD5Util, ShellExcutor}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_pai.start.JavaUtil
import com.sf.gis.scala.utils.{DbUtils, HttpConnection}
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks


/**
 * Created by 01374443 on 2019/3/5.
 * 任务id:225138
 * 任务名称：rds派件指标系统-AOI缺失指标
 * 开发：张想远
 * 业务：郭本婕
 */
object AoiUnMatchData {
  @transient lazy val logger: Logger = Logger.getLogger(AoiUnMatchData.getClass)
  //  val vv= "551GF"
  //  println(vv.matches(String.format("%s[a-zA-Z]+\\d*", "551")))

  // 生成的两种类型, 包含在json对象中
  val addNameArr = Array("unMatchType", "keyWord")
  val nameArr: Array[String] = Array[String]("type", "req_time", "req_addresseephone", "req_addresseemobile", "req_addresseeaddr",
    "req_destcitycode", "req_waybillno", "re_addresseedeptcode", "re_addresseeteamcode", "gis_to_sys_time",
    "gis_to_sys_teamtoretby", "gis_to_sys_gisteamcodeto", "gis_to_sys_src", "gis_to_sys_gisdeptcodeto",
    "gis_to_sys_groupid", "gis_to_sys_depttoretby", "gis_to_sys_sssdeptcodeto", "finalzc", "finaltc",
    "service", "finalzcby", "finaltcby", "atpai_time", "notc", "city", "adcode", "standardization",
    "splitresult", "splittype", "groupids", "matchids", "filters", "adcodes", "keywords", "keys",
    "req_comp_name", "req_province", "req_city", "req_area", "re_body")
  val otherNameArr = Array("finalAoiCode")

  val getKeyUrlPat = "http://10.119.72.207:8089/getkeyByNormSplit?split_terms=%s"
  //  val getKeyUrlPat = "http://10.202.43.228:3000/getkeyByNormSplit?split_terms=%s"
  val getSelectWaybillUrlPat = "http://gis-int.int.sfdc.com.cn:1080/ar/api?address=%s&extention=0&datatype=r01&opt=&ak=e6553bd0ce51b08f1aa8cc6cc42de767"
  //  val getSelectWaybillUrlPat = "http://gis-int.intsit.sfdc.com.cn:1080/ar/api?address=%s&extention=0&datatype=r01&opt=&ak=1ba8611acb0a45519641045cf0408520"

  val javaUtil = new JavaUtil(6) //6表示路由分单 1表示测试

  var cityMap: Map[String, ArrayBuffer[Array[String]]] = getCityMap
  //  val taskCode = -1
  //  val incDay: String = Util.dateDelta(taskCode, "")
  val appName = "AoiUnMatchData"

  case class UnMatchAoi(id: String, stat_date: String, province: String, region: String, city: String,
                        city_code: String, req: Int, addr_0_1: Int, addr_ll_3: Int,
                        addr_nsb: Int, addr_en: Int, other_city: Int, key: Int, filter_10_32_66: Int, id_single: Int,
                        id_single_nozc: Int, id_single_zc: Int,
                        id_multi: Int, id_multi_nozc: Int, id_multi_zc: Int, poi: Int, split_9: Int, split_6: Int,
                        auto_distinguish: Int, split_development_zone: Int, other: Int, out_service: Int, split_9_11: Int,
                        split_5: Int, split_3: Int, split_2: Int)

  def main(args: Array[String]): Unit = {
    start(args(0))
  }

  def start(incDay: String): Unit = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    //    conf.set("spark.executor.instances","30")
    //    conf.set("spark.executor.cores","4")
    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    unMatchDispatch(spark, incDay)
  }

  def saveUnMatchIdxToHive(spark: SparkSession, unMatchIdxRdd: RDD[Obj.nonAoiAddrObj],
                           incDay: String) = {
    import spark.implicits._
    val tmpView = "aoi_empty_data"
    unMatchIdxRdd.map(o => {
      //计算md5值
      val id = MD5Util.getMD5(MD5Util.getMD5Instance, Array(o.stat_date, o.city, o.city_code).mkString("_"))
      UnMatchAoi(id, o.stat_date, o.province, o.region, o.city, o.city_code, o.req, o.addr_0_1, o.addr_ll_3,
        o.addr_nsb, o.addr_en, o.other_city, o.key, o.filter_10_32_66, o.id_single, o.id_single_nozc, o.id_single_zc,
        o.id_multi, o.id_multi_nozc, o.id_multi_zc, o.poi, o.split_9, o.split_6,
        o.auto_distinguish, o.split_development_zone, o.other, o.out_service, o.split_9_11,
        o.split_5, o.split_3, o.split_2)
    }).toDF().createOrReplaceTempView(tmpView)
    val tableName = "dm_gis.dm_req_aoi_empty_data_di"
    val sql = s"insert overwrite table $tableName partition(inc_day='$incDay') " +
      s" select * from $tmpView "
    logger.error(sql)
    spark.sql(sql)
  }

  /**
   * 处理缺失数据
   *
   * @param spark : spark session
   */
  def unMatchDispatch(spark: SparkSession, incDay: String): Unit = {
    logger.error(">>>get unmatch data")
    val unMatchRdd = getUnMatchData(spark, incDay: String).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val dataCnt = unMatchRdd.count()
    logger.error(s">>>unmatch num ${
      dataCnt
    }")
    val keyId = BdpTaskRecordUtil.startRunNetworkInterface(spark,"0137443","225138","rds派件指标系统-AOI缺失指标",
      "",getKeyUrlPat,"",dataCnt,15)
    val arId = BdpTaskRecordUtil.startRunNetworkInterface(spark,"0137443","225138","rds派件指标系统-AOI缺失指标",
      "",getSelectWaybillUrlPat,"e6553bd0ce51b08f1aa8cc6cc42de767",dataCnt,15)
    logger.error(">>>mark unmatch type")
    val unMatchTypeRdd = markUnMatchType(spark, unMatchRdd, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(s">>>unmatch type num : ${
      unMatchTypeRdd.count()
    }")
    unMatchRdd.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01374443",keyId)
    BdpTaskRecordUtil.endNetworkInterface("01374443",arId)
    logger.error(">>>save unmatch data start")
    saveUnMatchData(spark, unMatchTypeRdd, incDay)
    logger.error(">>>save unmatch data end")
    val unMatchStatRdd = unMatchTypeRdd.filter(obj => {
      //公司名为baison的为测试单
      !"baison".equals(obj.getString("req_comp_name"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(s">>>统计使用的缺失量 : ${
      unMatchStatRdd.count()
    }")
    unMatchTypeRdd.unpersist()
    logger.error(">>>stat idx")
    val unMatchIdxRdd = statUnMatchIdx(unMatchStatRdd, incDay)
    logger.error(s">>>idx num : ${
      unMatchIdxRdd.count()
    }")
    logger.error(">>>save idx start")
    saveUnMatchIdx(unMatchIdxRdd, incDay)
    saveUnMatchIdxToHive(spark, unMatchIdxRdd, incDay)
    logger.error(">>>save idx end")
    unMatchStatRdd.unpersist()
  }

  def saveUnMatchIdx(rdd: RDD[Obj.nonAoiAddrObj], incDay: String): Unit = {
    val conn = DbUtils.getConnection(javaUtil)
    val md5Instance = MD5Util.getMD5Instance
    val OMS_DLV_NONAOIADDR = "OMS_DLV_NONAOIADDR"
    try {
      val delNonAoiSql = String.format(s"delete from $OMS_DLV_NONAOIADDR where stat_date='%s'", incDay)
      logger.error(">>>保存之前，删除non aoi addr一天的数据:" + delNonAoiSql)
      DbUtils.executeSql(conn, delNonAoiSql)

      val nonAoiInsertSql = s"insert into $OMS_DLV_NONAOIADDR (`id`, `stat_date`, `province`, `region`, `city`, `city_code`, `req`," +
        s"`addr_0_1`, `addr_ll3`, `addr_nsb`, `addr_en`, `other_city`, `key`, `filter_10_32_66`, `id_single`, `id_single_nozc`, `id_single_zc`," +
        s" `id_multi`,`id_multi_nozc`,`id_multi_zc`, `poi`," +
        s"`split_9`, `split_6`,`auto`,`split_other`,`other`,`out_service`,`split_9_11`,`split_5`,`split_3`,`split_2`) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," +
        s" ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
      var nonAoiParams: Array[Any] = null
      rdd.collect().foreach(o => {
        //计算md5值
        val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.city, o.city_code).mkString("_"))
        nonAoiParams = Array(id, o.stat_date, o.province, o.region, o.city, o.city_code, o.req, o.addr_0_1, o.addr_ll_3,
          o.addr_nsb, o.addr_en, o.other_city, o.key, o.filter_10_32_66, o.id_single, o.id_single_nozc, o.id_single_zc,
          o.id_multi, o.id_multi_nozc, o.id_multi_zc, o.poi, o.split_9, o.split_6,
          o.auto_distinguish, o.split_development_zone, o.other, o.out_service, o.split_9_11,
          o.split_5, o.split_3, o.split_2)
        //        println("nonZcParams:"+nonZcParams.mkString(","))
        DbUtils.execute(conn, nonAoiInsertSql, nonAoiParams)
      })
      logger.error(">>>non aoi指标入库结束！")
    } catch {
      case e: Exception => logger.error(">>>non aoi指标入库失败！" + e)
    }
  }

  def statUnMatchIdx(unMatchTypeRdd: RDD[JSONObject], incDay: String): RDD[Obj.nonAoiAddrObj] = {
    val unMatchIdxRdd = unMatchTypeRdd.map(obj => {
      var req, addr_0_1, addr_ll_3, addr_nsb, addr_en, other_city, key, filter_10_32_66, id_single, id_multi, poi, split_9, split_6 = 0
      var auto_distinguish, split_development_zone, other = 0
      var id_single_zc, id_single_nozc, id_multi_zc, id_multi_nozc = 0
      var out_service = 0
      var split_9_11, split_5, split_3, split_2 = 0
      val unMatchType = obj.getString("unMatchType")

      req = 1
      if (Constant.ADDRESS_0_1.equals(unMatchType)) {
        addr_0_1 = 1
      } else if (Constant.SHORT_TEXT.equals(unMatchType)) {
        addr_ll_3 = 1
      } else if (Constant.ADDRESS_NUM_SYMB_BLANK.equals(unMatchType)) {
        addr_nsb = 1
      } else if (Constant.ADDRESS_ENG.equals(unMatchType)) {
        addr_en = 1
      } else if (Constant.ADDRESS_OTHER_CITY.equals(unMatchType)) {
        other_city = 1
      } else if (Constant.KEY_WORD_EXISTS.equals(unMatchType)) {
        key = 1
      } else if (Constant.NO_MATCH.equals(unMatchType)) {
        filter_10_32_66 = 1
      } else if (Constant.MAKR_SINGLE_GROUP_NOZC.equals(unMatchType)) {
        id_single = 1
        id_single_nozc = 1
      } else if (Constant.MAKR_SINGLE_GROUP_ZC.equals(unMatchType)) {
        id_single = 1
        id_single_zc = 1
      } else if (Constant.MAKR_MULTI_GROUP_NOZC.equals(unMatchType)) {
        id_multi = 1
        id_multi_nozc = 1
      } else if (Constant.MAKR_MULTI_GROUP_ZC.equals(unMatchType)) {
        id_multi = 1
        id_multi_zc = 1
      } else if (Constant.MARK_13.equals(unMatchType)) {
        poi = 1
      } else if (Constant.MARK_9.equals(unMatchType)) {
        split_9 = 1
      } else if (Constant.MARK_6.equals(unMatchType)) {
        split_6 = 1
      } else if (Constant.DEPT.equals(unMatchType)) {
        auto_distinguish = 1
      } else if (Constant.MARK_4.equals(unMatchType)) {
        split_development_zone = 1
      } else if (Constant.MARK_OUT_SERVICE.equals(unMatchType)) {
        out_service = 1
      } else if (Constant.MARK_9_11.equals(unMatchType)) {
        split_9_11 = 1
      } else if (Constant.MARK_5.equals(unMatchType)) {
        split_5 = 1
      } else if (Constant.MARK_3.equals(unMatchType)) {
        split_3 = 1
      } else if (Constant.MARK_2.equals(unMatchType)) {
        split_2 = 1
      }
      else {
        other = 1
      }
      val statDate = incDay
      val cityCode = obj.getString("req_destcitycode")
      val cityTp = getCity(obj.getString("req_addresseeaddr"), cityCode)
      val province = cityTp._1
      val region = cityTp._2
      val city = cityTp._3
      (Array(statDate, city, cityCode).mkString("_"), Obj.nonAoiAddrObj(statDate,
        province, region, city, cityCode, req, addr_0_1, addr_ll_3, addr_nsb, addr_en,
        other_city, key, filter_10_32_66, id_single, id_single_nozc, id_single_zc,
        id_multi, id_multi_nozc, id_multi_zc, poi, split_9, split_6,
        auto_distinguish, split_development_zone, other, out_service, split_9_11, split_5,
        split_3, split_2))
    }).reduceByKey((obj1, obj2) => {
      val statDate = obj1.stat_date
      val province = obj1.province
      val region = obj1.region
      val city = obj1.city
      val cityCode = obj1.city_code
      val req = obj1.req + obj2.req
      val addr_0_1 = obj1.addr_0_1 + obj2.addr_0_1
      val addr_ll_3 = obj1.addr_ll_3 + obj2.addr_ll_3
      val addr_nsb = obj1.addr_nsb + obj2.addr_nsb
      val addr_en = obj1.addr_en + obj2.addr_en
      val other_city = obj1.other_city + obj2.other_city
      val key = obj1.key + obj2.key
      val filter_10_32_66 = obj1.filter_10_32_66 + obj2.filter_10_32_66
      val id_single = obj1.id_single + obj2.id_single
      val id_single_nozc = obj1.id_single_nozc + obj2.id_single_nozc
      val id_single_zc = obj1.id_single_zc + obj2.id_single_zc
      val id_multi = obj1.id_multi + obj2.id_multi
      val id_multi_nozc = obj1.id_multi_nozc + obj2.id_multi_nozc
      val id_multi_zc = obj1.id_multi_zc + obj2.id_multi_zc
      val poi = obj1.poi + obj2.poi
      val split_9 = obj1.split_9 + obj2.split_9
      val split_6 = obj1.split_6 + obj2.split_6
      val auto_distinguish = obj1.auto_distinguish + obj2.auto_distinguish
      val split_development_zone = obj1.split_development_zone + obj2.split_development_zone
      val other = obj1.other + obj2.other
      val out_service = obj1.out_service + obj2.out_service
      val split_9_11 = obj1.split_9_11 + obj2.split_9_11
      val split_5 = obj1.split_5 + obj2.split_5
      val split_3 = obj1.split_3 + obj2.split_3
      val split_2 = obj1.split_2 + obj2.split_2

      Obj.nonAoiAddrObj(statDate, province, region, city, cityCode, req, addr_0_1, addr_ll_3,
        addr_nsb, addr_en, other_city, key, filter_10_32_66, id_single, id_single_nozc, id_single_zc,
        id_multi, id_multi_nozc, id_multi_zc, poi, split_9, split_6,
        auto_distinguish, split_development_zone, other, out_service, split_9_11,
        split_5, split_3, split_2)
    }).values
    unMatchIdxRdd
  }

  /**
   * 转数字
   *
   * @param str
   * @return
   */
  def convertToDigit(str: String): Integer = {
    if (str == null || str.isEmpty) {
      return null
    }
    try {
      return Integer.valueOf(str)
    } catch {
      case _: Exception => logger.error(str)
    }
    null
  }

  /**
   * 查询缺失数据
   *
   * @param spark  : spark session
   * @param incDay : 日期
   * @return
   */
  def getUnMatchData(spark: SparkSession, incDay: String): RDD[JSONObject] = {
    val dataBaseName = "dm_gis"
    val hiveTableName = "gis_rds_omsto"
    logger.error(">>>dataBaseName：" + dataBaseName + ",hiveTableName:" + hiveTableName)
    spark.sql(s"""use $dataBaseName""") //hive中的dm_gis库
    val sql =
      s"""select * from(
         |select type, req_time, req_addresseephone, req_addresseemobile, req_addresseeaddr,
         | req_destcitycode, req_waybillno, re_addresseedeptcode, re_addresseeteamcode,
         | gis_to_sys_time, gis_to_sys_teamtoretby, gis_to_sys_gisteamcodeto, gis_to_sys_src,
         | gis_to_sys_gisdeptcodeto, gis_to_sys_groupid, gis_to_sys_depttoretby, gis_to_sys_sssdeptcodeto,
         | finalzc, finaltc, service, finalzcby, finaltcby, atpai_time, notc, city, adcode, standardization,
         | splitresult, splittype, groupids, matchids, filters, adcodes, keywords, keys, req_comp_name,
         | req_province, req_city, req_area,re_body,finalAoiCode,inc_day,row_number() over(partition BY req_waybillno
         | order by req_time desc ) as rank,gisAoiCode,ksAoiCode from $hiveTableName where inc_day = '$incDay'
         | and gisAoiCode = '' and ksAoiCode='' and (finalaoiby<>'gis' or finalaoicode='')
         | )a where a.rank=1  """.stripMargin
    logger.error(">>>unmatch sql :" + sql)
    val rdd = spark.sql(sql).rdd.map(row => {
      val obj = new JSONObject()
      for (i <- nameArr.indices)
        obj.put(nameArr(i), row.getString(i))
      for (i <- otherNameArr.indices)
        obj.put(otherNameArr(i), row.getString(i + nameArr.length))
      obj
    })
    rdd
  }

  /**
   * 分流缺失数据
   *
   * @param rdd : 数据rdd
   * @return
   */
  def markUnMatchType(spark: SparkSession, rdd: RDD[JSONObject], date: String): RDD[JSONObject] = {
    val city2CityCodeMap = City2AdcodeMap.getCity2CityCodeMap
    val invalidDept = OmsIndexStat.fetchInvalidDept(spark, date, -1)
    val broadcastInvalidDept = spark.sparkContext.broadcast(invalidDept).value

    val unMatchRdd = rdd.repartition(15).map(obj => {
      val typeTp = markUnMatchType(obj, city2CityCodeMap)
      obj.put("unMatchType", typeTp._1)
      obj.put("keyWord", typeTp._2)
      val finalZc = obj.getString("finalzc")

      obj.put("isRejectDept", broadcastInvalidDept.contains(finalZc).toString)
      obj
    })
    unMatchRdd
  }

  def markByOutService(address: String): String = {
    val calendar = Calendar.getInstance()
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    if (hour >= 7 && hour < 21) {
      return null
    }
    val getKeyUrl = String.format(getSelectWaybillUrlPat, URLEncoder.encode(address, "UTF-8"))
    val re = HttpConnection.sendGet(getKeyUrl)
    val content = re.get("content")
    var result: Int = 0
    if (content != null && !"".equals(content)) {
      try {
        val jsonObj = JSON.parseObject(content)
        result = jsonObj.getInteger("result")
      } catch {
        case e: Exception => logger.error(e)
      }
    }
    if (result == 2)
      Constant.MARK_OUT_SERVICE
    else
      null
  }

  def markUnMatchType(obj: JSONObject, city2CityCodeMap: util.HashMap[String, String]): (String, String) = {
    val filterSet = obj.getString("filters").split(Constant.SEP).toSet.-("")
    val groupIdSet = obj.getString("groupids").split(Constant.SEP).toSet.-("")
    val address = obj.getString("req_addresseeaddr")
    val cityCode = obj.getString("req_destcitycode")
    val splitResult = obj.getString("splitresult")
    val gisDeptcodeto = obj.getString("gis_to_sys_gisdeptcodeto")
    val gisSrc = obj.getString("gis_to_sys_src")
    var keyWord: String = null
    var _type: String = null

    _type = markByAddress(address, cityCode, gisSrc)
    if (_type != null)
      return (_type, keyWord)

    _type = markByCity(splitResult, cityCode, city2CityCodeMap)
    if (_type != null)
      return (_type, keyWord)

    //    _type = markByOutService(address)
    //    if(_type != null)
    //      return (_type, keyWord)

    _type = markByFilter(filterSet, groupIdSet, gisDeptcodeto)
    if (_type != null)
      return (_type, keyWord)

    val typeTp = markByKeyWord(splitResult)
    _type = typeTp._1
    keyWord = typeTp._2
    if (_type != null)
      return (_type, keyWord)

    _type = markBySplitType(address, splitResult)
    if (_type != null)
      return (_type, keyWord)

    (Constant.MARK_OTHER, keyWord)
  }

  /**
   * 根据filter判断缺失类型
   *
   * @param filterSet  : 过滤set
   * @param groupIdSet : 大组et
   * @return
   */
  def markByFilter(filterSet: Set[String], groupIdSet: Set[String], gisDeptcodeto: String): String = {
    if (groupIdSet.nonEmpty && (filterSet.contains("10") || filterSet.contains("32") || filterSet.contains("66"))) {
      return Constant.NO_MATCH //未识别
    } else if (filterSet.contains("1") || filterSet.contains("2") || filterSet.contains("8")) {
      if (groupIdSet.size == 1)
        if (gisDeptcodeto == null || gisDeptcodeto.isEmpty) {
          return Constant.MAKR_SINGLE_GROUP_NOZC
        } else {
          return Constant.MAKR_SINGLE_GROUP_ZC; //单groupid
        }
      else if (groupIdSet.size > 1)
        if (gisDeptcodeto == null || gisDeptcodeto.isEmpty) {
          return Constant.MAKR_MULTI_GROUP_NOZC
        } else {
          return Constant.MAKR_MULTI_GROUP_ZC //多groupid
        }
    }
    null
  }

  /**
   * 根据地址判断未缺失类型
   *
   * @param address  : 地址
   * @param cityCode : 城市代码
   * @return
   */
  def markByAddress(address: String, cityCode: String, gisSrc: String): String = {
    if (Set("0", "1").contains(address)) { //0或1
      return Constant.ADDRESS_0_1
      //    } else if (address.matches(String.format("%s[a-zA-Z]+\\d*", cityCode))) { //网点
    } else if (gisSrc != null && gisSrc.equals("auto")) {
      return Constant.DEPT
    } else if (address.matches("^((?![\\u4e00-\\u9fa5]).)*[a-zA-Z]((?![\\u4e00-\\u9fa5]).)*$")) { //英文地址
      return Constant.ADDRESS_ENG
    } else if ("".equals(address) || address.matches("^[^\\u4e00-\\u9fa5]*$")) { //数字或空格或符号
      return Constant.ADDRESS_NUM_SYMB_BLANK
    }
    null
  }

  /**
   * 判断是否其他城市地址
   *
   * @param splitResult : 分词结果
   * @param cityCode    : 城市代码
   * @return
   */
  def markByCity(splitResult: String, cityCode: String, city2CityCodeMap: util.HashMap[String, String]): String = {
    var city: String = null
    val splitTmps = splitResult.split(";")
    try {
      if (!"".equals(splitResult) && splitTmps.nonEmpty) {
        val loop = new Breaks
        loop.breakable(
          for (term <- splitTmps(0).split("\\|")) {
            val keyLevel = term.split("\\^")
            val key = keyLevel(0)
            val level = keyLevel(1).substring(1)
            if ("2".equals(level)) { //获取分词中的城市
              city = key
              loop.break()
            }
          }
        )
      }
    } catch {
      case e: Exception => logger.error(splitResult, e)
    }
    val cityCode2 = city2CityCodeMap.get(city)
    if (cityCode2 != null && !cityCode2.equals(cityCode)) //地址中的城市和城市代码不一致
      return Constant.ADDRESS_OTHER_CITY
    null
  }


  /**
   * 根据主题判断缺失类型
   *
   * @param splitResult : 分词结果
   * @return
   */
  def markByKeyWord(splitResult: String): (String, String) = {
    val splitTmps = splitResult.replaceAll("\\|", ",").split(";")
    if (splitTmps.length != 2)
      return (null, "")
    val getKeyUrl = String.format(getKeyUrlPat, URLEncoder.encode(splitTmps(0), "UTF-8"))
    val re = HttpConnection.sendGet(getKeyUrl)
    val keyContent = re.get("content")
    var keyWord: String = null
    if (keyContent != null && !"".equals(keyContent)) {
      try {
        val jsonObj = JSON.parseObject(keyContent)
        keyWord = jsonObj.getString("key_word")
      } catch {
        case e: Exception => logger.error(e)
      }
    }
    if (keyWord != null && !"".equals(keyWord))
      (Constant.KEY_WORD_EXISTS, keyWord)
    else
      (null, keyWord)
  }

  def markBySplitType(address: String, splitResult: String): String = {
    if (address.length <= 3) {
      return Constant.SHORT_TEXT
    }
    try {
      val set = new util.HashSet[String]()
      val keyLevelSet_13 = new util.HashSet[String]()
      val splitTmps = splitResult.split(";")
      if (!"".equals(splitResult) && splitTmps.nonEmpty) {
        for (term <- splitTmps(0).split("\\|")) {
          val keyLevel = term.split("\\^")
          //noinspection ScalaUnusedSymbol
          val key = keyLevel(0)
          val level = keyLevel(1).substring(1)
          set.add(level)
          if ("13".equals(level))
            keyLevelSet_13.add(keyLevel(1))
        }
      }
      if (set.contains("13") && !(keyLevelSet_13.size() == 1
        && keyLevelSet_13.contains("613")))
        return Constant.MARK_13
      else if (set.contains("9") && set.contains("11"))
        return Constant.MARK_9_11
      else if (set.contains("9"))
        return Constant.MARK_9
      else if (set.contains("6"))
        return Constant.MARK_6
      else if (set.contains("5"))
        return Constant.MARK_5
      else if (set.contains("4"))
        return Constant.MARK_4
      else if (set.contains("3"))
        return Constant.MARK_3
      else if (set.contains("2"))
        return Constant.MARK_2
    } catch {
      case _: Exception => logger.error(splitResult)
    }

    null
  }

  def getCityMap: Map[String, ArrayBuffer[Array[String]]] = {
    logger.error(">>>javaUtil：" + javaUtil.getFlag)
    val conn = DbUtils.getConnection(javaUtil)
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("province", "region", "city", "citycode")
    val regionSelectSql = s"select province,region,city,citycode from $regoinCityTable"
    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val citycode = arr(3).toString
      if (cityMap.contains(citycode)) {
        val cityCodeList = cityMap.apply(citycode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (citycode -> cityCodeList)
      }
    }
    cityMap
  }

  def getCity(address: String, cityCode: String): (String, String, String) = {
    var flag = false
    var _province = "-"
    var _region = "-"
    var _city = "-"
    if (cityMap.contains(cityCode)) {
      flag = true
      val cityList: ArrayBuffer[Array[String]] = cityMap.apply(cityCode)
      _province = cityList(0)(0)
      _region = cityList(0)(1)
      if (cityList.length == 1) {
        //如果只有一个list，一一对应的，直接返回
        _city = cityList(0)(2)
      } else if (cityList.length > 1) {
        //一个城市代码对应多个城市
        for (cityObj <- cityList) {
          val city = cityObj(2)
          val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
          if (address.contains(city) || address.contains(city1)) {
            _city = city
          }
        }
      }
    }
    (_province, _region, _city)
  }

  /**
   * 保存数据到hive
   *
   * @param spark
   * @param unMatchTypeRdd
   * @param incDay
   */
  def saveUnMatchData(spark: SparkSession, unMatchTypeRdd: RDD[JSONObject], incDay: String): Unit = {
    val rows = unMatchTypeRdd.map(obj => {
      val rowBuilder = new StringBuilder
      for (name <- nameArr) {
        var tmp = obj.getString(name)
        if (tmp == null) {
          tmp = ""
        }
        rowBuilder.append(tmp.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")).append("\t")
      }
      for (i <- addNameArr.indices) {
        rowBuilder.append(JSONUtil.getJsonVal(obj, addNameArr(i), "").replaceAll("[\\r\\n\\t,\\\\]", "")).append("\t")
      }
      for (i <- otherNameArr.indices) {
        //        if (i != otherNameArr.length - 1)
        rowBuilder.append(JSONUtil.getJsonVal(obj, otherNameArr(i), "").replaceAll("[\\r\\n\\t,\\\\]", "")).append("\t")
        //        else rowBuilder.append(JSONUtil.getJsonVal(obj, otherNameArr(i), "").replaceAll("[',\",\\r,\\n,\\t,\\\\]", ""))
      }
      rowBuilder.append(JSONUtil.getJsonVal(obj, "isRejectDept", ""))
      rowBuilder.toString()
    }).repartition(1)
    spark.sql("use dm_gis")
    val table = "gis_rds_omsto_gis_unmatch_aoi"
    val dropSql = String.format("alter table %s drop if exists partition(inc_day = '%s')", table, incDay)
    spark.sql(dropSql)
    ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R /user/hive/warehouse/dm_gis.db/%s/inc_day=%s", table, incDay))
    rows.saveAsTextFile(String.format("/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", table, incDay))
    val addSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
    spark.sql(addSql)
  }

  def getUnmatchTypeName(unMatchType: String): String = {
    if (Constant.ADDRESS_0_1.equals(unMatchType)) {
      "为0或1"
    } else if (Constant.SHORT_TEXT.equals(unMatchType)) {
      "长度小于3"
    } else if (Constant.ADDRESS_NUM_SYMB_BLANK.equals(unMatchType)) {
      "为数字、符号或空格"
    } else if (Constant.ADDRESS_ENG.equals(unMatchType)) {
      "为纯英文的数量"
    } else if (Constant.ADDRESS_OTHER_CITY.equals(unMatchType)) {
      "非本市"
    } else if (Constant.KEY_WORD_EXISTS.equals(unMatchType)) {
      "有主体"
    } else if (Constant.NO_MATCH.equals(unMatchType)) {
      "Filter为10、32或66"
    } else if (Constant.MAKR_SINGLE_GROUP_NOZC.equals(unMatchType)) {
      "Groupid为单个，无网点"
    } else if (Constant.MAKR_SINGLE_GROUP_ZC.equals(unMatchType)) {
      "Groupid为单个，有网点"
    } else if (Constant.MAKR_MULTI_GROUP_NOZC.equals(unMatchType)) {
      "Groupid为多个，无网点"
    } else if (Constant.MAKR_MULTI_GROUP_ZC.equals(unMatchType)) {
      "Groupid为多个，有网点"
    } else if (Constant.MARK_13.equals(unMatchType)) {
      "有POI"
    } else if (Constant.MARK_9.equals(unMatchType)) {
      "切词包含路、巷、街、道"
    } else if (Constant.MARK_6.equals(unMatchType)) {
      "切词包含村、社区"
    } else if (Constant.DEPT.equals(unMatchType)) {
      "AUTO"
    } else if (Constant.MARK_4.equals(unMatchType)) {
      "切词包含开发区"
    } else if (Constant.MARK_OUT_SERVICE.equals(unMatchType)) {
      "超顺丰服务范围"
    } else if (Constant.MARK_9_11.equals(unMatchType)) {
      "切词包路、门牌号"
    }
    else {
      "其他"
    }
  }
}
