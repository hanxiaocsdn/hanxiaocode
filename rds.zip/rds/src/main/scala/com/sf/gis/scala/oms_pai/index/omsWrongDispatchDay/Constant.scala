package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

/**
  * Created by 01368078 on 2019/3/5.
  */
object Constant {
  val PRE = "PRE"
  val AFT = "AFT"
}
