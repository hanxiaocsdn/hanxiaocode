package com.sf.gis.scala.utils

import java.util.regex.Pattern

/**
  * Created by 01368078 on 2018/2/7.
  */
object StringUtil {
  def nonEmpty(str:String):Boolean={
    str!=null && !str.isEmpty
  }
  def pickGroup1Str(str: String, regex: String): String = {
    val pattern = Pattern.compile(regex)
    val matcher = pattern.matcher(str)
    if (matcher.find) matcher.group(1)
    else ""
  }

  def isNotBlank(str : String) : Boolean = {
    !isBlank(str)
  }

  def isBlank(str : String) : Boolean = {
    if(str == null || "".equals(str.trim))
      true
    else
      false
  }
  def fixnull(ak:String,defaultVal:String = "")={
    if(ak==null||ak.trim==""||ak.trim.toLowerCase()=="null") defaultVal else ak
  }
}
