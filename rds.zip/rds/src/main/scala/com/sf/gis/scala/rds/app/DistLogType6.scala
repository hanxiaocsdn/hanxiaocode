package com.sf.gis.scala.rds.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager:01408947
 * @Author: 01407499
 * @CreateTime: 2023-03-20 16:10
 * @TaskId:499868
 * @TaskName:
 * @Description: gis_rds_pns日志解析
 */

object DistLogType6 {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey=Array("createTm","extendedField","msg","operateCode","operateEmpCode","operateTm","operateType","operateZoneCode","packageNo")
    def main(args: Array[String]): Unit = {
        val start_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("开始解析日志")
        val resultRdd = ParseLog(sparkSession, start_day)
        logger.error("开始存储日志数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.gis_rds_pns_dist_log_type6",Array(("inc_day", start_day)), 25)

    }
    def ParseLog(spark:SparkSession,start_day:String)={
        var sql=
            s"""
              |
              |select get_json_object(data, '$$.sendSispKakfa') from dm_gis.gis_rds_pns_dist_log_result t
              | where inc_day='$start_day' and get_json_object(data, '$$.operateType')='6'
              |""".stripMargin
        val dataDf = spark.sql(sql)
        val logRdd=dataDf.na.fill("").rdd.repartition(2000).map(row=>{
            var json:JSONObject = null
            try {
                val line = row.getString(0)
                json = JSON.parseObject(line)
            } catch {
                case e:Exception =>logger.error(">>>日志转json失败："+e)
            }
            json
        }).filter(_!=null).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("日志数量----》"+logRdd.count())
        logRdd
    }

}
