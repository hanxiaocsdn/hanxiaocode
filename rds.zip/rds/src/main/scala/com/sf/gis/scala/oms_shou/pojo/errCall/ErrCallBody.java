package com.sf.gis.scala.oms_shou.pojo.errCall;

import java.io.Serializable;


@SuppressWarnings("unused")
public class ErrCallBody implements Serializable {
    private String orderid;
    private String province;
    private String city;
    private String resno;
    private String addrabb;
    private String county;
    private String teamid;
    private String dept;
    private String addrSrc;
    private String addrGroupid;
    private String addrDept;
    private String addrTeamCode;
    private String empid;
    private String emptel;
    private String createTime;
    private String errCallDate;
    private String tcSouce;
    private String operName;


    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getResno() {
        return resno;
    }

    public void setResno(String resno) {
        this.resno = resno;
    }

    public String getAddrabb() {
        return addrabb;
    }

    public void setAddrabb(String addrabb) {
        this.addrabb = addrabb;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTeamid() {
        return teamid;
    }

    public void setTeamid(String teamid) {
        this.teamid = teamid;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmptel() {
        return emptel;
    }

    public void setEmptel(String emptel) {
        this.emptel = emptel;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getErrCallDate() {
        return errCallDate;
    }

    public void setErrCallDate(String errCallDate) {
        this.errCallDate = errCallDate;
    }

    public String getAddrSrc() {
        return addrSrc;
    }

    public void setAddrSrc(String addrSrc) {
        this.addrSrc = addrSrc;
    }

    public String getAddrGroupid() {
        return addrGroupid;
    }

    public void setAddrGroupid(String addrGroupid) {
        this.addrGroupid = addrGroupid;
    }

    public String getAddrDept() {
        return addrDept;
    }

    public void setAddrDept(String addrDept) {
        this.addrDept = addrDept;
    }

    public String getAddrTeamCode() {
        return addrTeamCode;
    }

    public void setAddrTeamCode(String addrTeamCode) {
        this.addrTeamCode = addrTeamCode;
    }

    public String getTcSouce() {
        return tcSouce;
    }

    public void setTcSouce(String tcSouce) {
        this.tcSouce = tcSouce;
    }

    public String getOperName() {
        return operName;
    }

    public void setOperName(String operName) {
        this.operName = operName;
    }
}
