//package com.sf.gis.scala.utils;
//
//
//import com.sf.gis.scala.oms_pai.start.JavaUtil;
//import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.hbase.HBaseConfiguration;
//import org.apache.hadoop.hbase.TableName;
//import org.apache.hadoop.hbase.client.Connection;
//import org.apache.hadoop.hbase.client.ConnectionFactory;
//import org.apache.hadoop.hbase.client.Table;
//import org.apache.log4j.Logger;
//
///**
// * Created by 01375125 on 2018/10/17.
// * hbase工具类
// */
//@SuppressWarnings("unused")
//public class JavaHbaseUtil {
//    private Logger logger = Logger.getLogger(this.getClass().getName());
//
//    private String hbaseParent = JavaUtil.getString("zookeeper.znode.parent");
//    private String hbaseQuorum = JavaUtil.getString("hbase.zookeeper.quorum");
//    private String hbaseClientPort = JavaUtil.getString("hbase.zookeeper.property.clientPort");
//    private String tableName = JavaUtil.getString("hbase.gis.oms.table");
//
//
//    /**
//     * 获取hbase配置
//     * @return Configuration:
//     */
//    private Configuration getHbaseConf(){
//        Configuration hbaseConf =null;
//        try{
//            //获取hbase的conf
//            hbaseConf = HBaseConfiguration.create();
//            //设置写入的表
//            hbaseConf.set("zookeeper.znode.parent", hbaseParent);
//            hbaseConf.set("hbase.zookeeper.quorum", hbaseQuorum);
//            hbaseConf.set("hbase.zookeeper.property.clientPort", hbaseClientPort);
//        }catch(Exception e){
//            logger.error(">>>连接hbase失败："+e);
//        }
//        return hbaseConf;
//    }
//
//    /**
//     * 获取hbase配置
//     * @return Table:
//     */
//    public Table getTable(String tableName){
//        Table table =null;
//        try{
//            //获取hbase的conf
//            Configuration hbaseConf = getHbaseConf();
//            Connection conn = ConnectionFactory.createConnection(hbaseConf);
//            table = conn.getTable(TableName.valueOf(tableName));
//        }catch(Exception e){
//            logger.error(">>>获取Table对象失败："+e);
//        }
//        return table;
//    }
//
//
//}
