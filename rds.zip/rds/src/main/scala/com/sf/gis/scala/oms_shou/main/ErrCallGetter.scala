package com.sf.gis.scala.oms_shou.main

import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.com.sf.gis.scala.oms_shou.constant.FixedConstant
import com.sf.gis.scala.base.util.HttpConnection
import com.sf.gis.scala.utils.{ConfigurationUtil, DateUtil}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}
import com.sf.gis.scala.oms_shou.constant.VariableConstant

import scala.collection.JavaConverters
import scala.collection.JavaConversions._

/**
  * Created by 01368078 on 2019/1/7.
  */
class ErrCallGetter {
  @transient val logger: Logger = LoggerFactory.getLogger(classOf[ErrCallGetter])
  //错call数据需要的字段
  val jsonKey :List[String] = List("orderid", "province", "city", "resno", "addrabb", "county", "teamid",
    "dept", "addrSrc","addrGroupid", "addrDept", "addrTeamCode", "empid", "emptel", "tcSouce", "operName","createTime")

  //错call数据新接口的字段映射
  val jsonKeyMap:Map[String, String] = Map("orderid"->"waybillNo", "addrabb"->"address", "teamid"->"schCode",
  "dept"->"znoCode","addrDept"->"checkDeptCode","addrTeamCode"->"checkSchCode",
  "empid"->"checkBy","tcSouce"->"source", "createTime"->"dataTime","resno"->"cityCode")

  def getErrCallData(sc : SparkContext, incDay : String) : RDD[(String, JSONObject)] = {
    var errCallList : java.util.List[JSONObject] = new util.ArrayList[JSONObject]()
    val url = String.format(ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("errcall.url"), incDay + "000000", incDay + "235959")
    logger.error(s""">>>errCall url : $url""")
    val errCallStr = HttpConnection.doGet(url, FixedConstant.CHARSET)
    var errCallRdd : RDD[(String, JSONObject)] = null
    try{
      val errCallReObj = JSON.parseObject(errCallStr)
//      errCallList = JSON.parseArray(errCallStr, classOf[JSONObject])
      errCallList = if("1".equals(errCallReObj.getString("code"))) errCallReObj.getJSONArray("data").toJavaList(classOf[JSONObject]) else new util.ArrayList[JSONObject]()
      logger.error(s">>>>$incDay: " + errCallList.size())
      errCallRdd = sc.parallelize(JavaConverters.asScalaIteratorConverter(errCallList.iterator).asScala.toSeq).map(obj => {
        val sysOrderNo = obj.getString(VariableConstant.ERR_CALL_SYS_ORDERNO_KEY)
        val createTime = obj.getLong(VariableConstant.ERRCALL_TIME_KEY)
        val errCallDate = DateUtil.formatTimeStamp2Str(createTime, FixedConstant.DATE_FORMAT2)
        obj.put("errCallDate", errCallDate)
        obj.put(VariableConstant.ERRCALL_TIME_KEY, DateUtil.formatTimeStamp2Str(createTime, FixedConstant.DATE_TIME_FORMAT))
        (sysOrderNo, obj)
      }).reduceByKey((obj1, obj2) => {
        try{
          val createTime1 = obj1.getString(VariableConstant.ERRCALL_TIME_KEY)
          val createTime2 = obj2.getString(VariableConstant.ERRCALL_TIME_KEY)
          if(createTime1 > createTime2)
            obj1
          else
            obj2
        }catch {
          case e : Exception => e.printStackTrace()
            null
        }
      }).filter(_ != null).map(obj => {
        val newObj = new JSONObject()
        newObj.put(VariableConstant.ERR_CALL_BODY_KEY, obj._2)
        (obj._1, newObj)
      })
    }catch {
      case e : Exception => logger.error(">>>get errCall error", e)
    }
    errCallRdd
  }

  /**
    * 错call对象转成rdd
    * @param sc: sc
    * @param errCallList: 错call列表
    * @return
    */
  private def errcall_convert_to_rdd(sc : SparkContext, errCallList : java.util.List[JSONObject]): RDD[(String, JSONObject)]  ={
      var errCallRdd : RDD[(String, JSONObject)] = null
    try{
      errCallRdd = sc.parallelize(JavaConverters.asScalaIteratorConverter(errCallList.iterator).asScala.toSeq).map(obj => {
        val sysOrderNo = obj.getString(VariableConstant.ERR_CALL_SYS_ORDERNO_KEY)
        val createTime = obj.getLong(VariableConstant.ERRCALL_TIME_KEY)
        val errCallDate = DateUtil.formatTimeStamp2Str(createTime, FixedConstant.DATE_FORMAT2)
        obj.put("errCallDate", errCallDate)
        obj.put(VariableConstant.ERRCALL_TIME_KEY, DateUtil.formatTimeStamp2Str(createTime, FixedConstant.DATE_TIME_FORMAT))
        (sysOrderNo, obj)
      }).reduceByKey((obj1, obj2) => {
        try{
          val createTime1 = obj1.getString(VariableConstant.ERRCALL_TIME_KEY)
          val createTime2 = obj2.getString(VariableConstant.ERRCALL_TIME_KEY)
          if(createTime1 > createTime2)
            obj1
          else
            obj2
        }catch {
          case e : Exception => e.printStackTrace()
            null
        }
      }).filter(_ != null).map(obj => {
        val newObj = new JSONObject()
        newObj.put(VariableConstant.ERR_CALL_BODY_KEY, obj._2)
        (obj._1, newObj)
      })
    }catch {
      case e : Exception => logger.error(">>>get errCall error", e)
    }
    errCallRdd
  }
  /**
    * 调用接口获取错call数据   新接口
    * @param sc: sc
    * @param incDay: 日期
    * @return
    */
  def getErrCallDataNew(sc : SparkContext, incDay : String) : RDD[(String, JSONObject)] = {
    val errCallList : java.util.List[JSONObject] = new util.ArrayList[JSONObject]()
    val url = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("errcall.url_new")
    val city_codes_str = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("errcall.citycodes_old")
    val city_codes_array = city_codes_str.split(",")
    logger.error(s""">>>errCall url : $url""")
    for(city_code <- city_codes_array){
      var pageNo = 1
      val pageSize = 5000
      var loop = true
      while(loop){
        val realUrl = String.format(url, city_code, incDay + "000000", incDay + "235959", ""+pageNo, ""+pageSize)
        val errCallStr = HttpConnection.doGet(realUrl, FixedConstant.CHARSET)
        val errCallReObj = JSON.parseObject(errCallStr)
        val resCode =  errCallReObj.getInteger("code")
        if(resCode == 200){
          val tmpResult = errCallReObj.getJSONObject("data").getJSONArray("result").toJavaList(classOf[JSONObject])
          for(resItem <- tmpResult){
            val jObj = new JSONObject()
            for(key <- jsonKey){
              if(key.equals("createTime")){
                val createTime = DateUtil.formatStr2TimeStamp(resItem.getString(jsonKeyMap(key)),FixedConstant.DATE_TIME_FORMAT_Y_S)
                jObj.put(key, createTime)
              }else if(resItem.containsKey(key)){
                var value = resItem.getString(key)
                if(value == null){
                  value = ""
                }
                jObj.put(key, value)
              }else if(jsonKeyMap.contains(key) && resItem.containsKey(jsonKeyMap(key))){
                var value = resItem.getString(jsonKeyMap(key))
                if(value == null){
                  value = ""
                }
                jObj.put(key, value)
              }else{
                jObj.put(key, "")
              }
            }
            errCallList.append(jObj)
          }
          if(tmpResult.size() < pageSize){
            loop = false
          }else{
            pageNo = pageNo + 1
          }
        }
      }
    }
    errcall_convert_to_rdd(sc, errCallList)
  }
  /**
    * 调用接口获取错call数据   新接口
    * @param sc: sc
    * @param incDay: 日期
    * @return
    */
  def getErrCallDataNewShidian(sc : SparkContext, incDay : String) : RDD[(String, JSONObject)] = {
    val errCallList : java.util.List[JSONObject] = new util.ArrayList[JSONObject]()
    val url = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("errcall.url_new_shidian")
    val city_codes_str = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("errcall.citycodes")
    val city_codes_array = city_codes_str.split(",")
    logger.error(s""">>>errCall url : $url""")
    for(city_code <- city_codes_array){
      var pageNo = 1
      val pageSize = 50000
      var loop = true
      while(loop){
        val realUrl = String.format(url, city_code, incDay + "000000", incDay + "235959", ""+pageNo, ""+pageSize)
        if(pageNo > 1){
          logger.error(realUrl)
        }
        val errCallStr = HttpConnection.doGet(realUrl, FixedConstant.CHARSET)
        val errCallReObj = JSON.parseObject(errCallStr)
        val resCode =  errCallReObj.getInteger("code")
        if(resCode == 200){
          val tmpResult = errCallReObj.getJSONObject("data").getJSONArray("result").toJavaList(classOf[JSONObject])
          for(resItem <- tmpResult){
            val jObj = new JSONObject()
            for(key <- jsonKey){
              if(key.equals("createTime")){
                val createTime = DateUtil.formatStr2TimeStamp(resItem.getString(jsonKeyMap(key)),FixedConstant.DATE_TIME_FORMAT_Y_S)
                jObj.put(key, createTime)
              }else if(resItem.containsKey(key)){
                var value = resItem.getString(key)
                if(value == null){
                  value = ""
                }
                jObj.put(key, value)
              }else if(jsonKeyMap.contains(key) && resItem.containsKey(jsonKeyMap(key))){
                var value = resItem.getString(jsonKeyMap(key))
                if(value == null){
                  value = ""
                }
                jObj.put(key, value)
              }else{
                jObj.put(key, "")
              }
            }
            errCallList.append(jObj)
          }
          if(tmpResult.size() < pageSize){
            loop = false
          }else{
            pageNo = pageNo + 1
          }
        }else{
          loop = false
          logger.error(realUrl)
          logger.error(""+errCallStr)
        }
      }
    }
    errcall_convert_to_rdd(sc, errCallList)
  }
}

object ErrCallGetter{
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("gis.sf").setMaster("local[1]")
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default",(10485760 * 2).toString)// default is 10485760
    conf.set("quota.consumer.default",(10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering",(10485760 * 2).toString)
    val sc = new SparkContext(conf)
    val incDayList = new util.ArrayList[String]()
    incDayList.add("20190823")
//    incDayList.add("20190824")
    var errCallRdd : RDD[(String, JSONObject)] = null
    for(incDay <- incDayList){
      val errCallRddTemp : RDD[(String, JSONObject)] = new ErrCallGetter().getErrCallDataNew(sc, incDay).persist(StorageLevel.DISK_ONLY)
      if(errCallRddTemp.count() > 0 ){
        if(errCallRdd == null)
          errCallRdd = errCallRddTemp
        else
          errCallRdd = errCallRdd.union(errCallRddTemp)
      }
    }
    errCallRdd.foreach(obj => {
      println(obj)
    })
  }
}
