package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.io.{BufferedReader, FileInputStream, InputStreamReader}
import java.util

import com.sf.gis.java.base.util.FileUtil
import org.apache.log4j.Logger

/**
  * Created by 01368078 on 2019/3/6.
  */
object City2AdcodeMap {
  val logger: Logger = Logger.getLogger(City2AdcodeMap.getClass)

  def getCity2CityCodeMap : util.HashMap[String, String] = {

//    logger.error("city_adcode path :" + path)
    val br = new BufferedReader(new InputStreamReader(classOf[FileUtil].getClassLoader.getResourceAsStream("conf/oms_pai/city_adcode.csv"), "utf-8"))
    br.readLine()
    var line = br.readLine()
    val map = new util.HashMap[String, String]()
    while(line != null){
      val strs = line.split(",")
      if(strs.length == 6){
        map.put(strs(2), strs(3))
        map.put(strs(5), strs(3))
      }
      line = br.readLine()
    }
    map
  }

  def cityCode2AdcodeMap() : util.HashMap[String, String] = {
    val path = System.getProperty("user.dir") + "/city_adcode.csv"
    logger.error("city_adcode path :" + path)
    val br = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"))
    br.readLine()
    var line = br.readLine()
    val map = new util.HashMap[String, String]()
    while(line != null){
      val strs = line.split(",")
      if(strs.length == 6){
        map.put(strs(3), strs(1))
      }
      line = br.readLine()
    }
    map
  }
}
