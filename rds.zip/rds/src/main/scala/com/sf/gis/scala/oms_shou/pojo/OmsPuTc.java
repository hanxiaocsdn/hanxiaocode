package com.sf.gis.scala.oms_shou.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/6.
 */
@Entity
public class OmsPuTc implements Serializable {
    @Column(name = "ID")
    private String id;
    @Column(name = "UNDER_CALL")
    private String underCall;
    @Column(name = "DATA_TYPE")
    private String dataType;
    @Column(name = "STAT_DATE")
    private String statDate;    //数据日期
    @Column(name = "PROVINCE")
    private String province;    //省
    @Column(name = "REGION")
    private String region;  //大区
    @Column(name = "CITY_CODE")
    private String cityCode;    //城市代码
    @Column(name = "CITY")
    private String city;    //城市
    @Column(name = "ZONDCODE")
    private String zoneCode;    //网点

    @Column(name = "ORDER")
    private int order; //下单量
    @Column(name = "RCG_TC")
    private int rcgTc; //GIS自动识别量（=RCG_NORM+RCG_SCH+RCG_TC2+RCG_CHKE+RCG_CHKN）
    @Column(name = "RCG_NORM")
    private int rcgNorm;   //GIS自动识别量中来自NORM的识别量
    @Column(name = "RCG_DPNORM")
    private int rcgDispatchNorm;   //GIS自动识别量中来自DISPATCH_NORM的识别量
    @Column(name = "RCG_SCH")
    private int rcgSch;   //GIS自动识别量中来自SCH的识别量
    @Column(name = "RCG_TC2")
    private int rcgTc2; //GIS自动识别量中来自TC2的识别量
    @Column(name = "RCG_DPTC2")
    private int rcgDispatchTc2;   //GIS自动识别量中来自DISPATCH_TC2的识别量
    @Column(name = "RCG_CHKE")
    private int rcgChke; //GIS自动识别量中来自CHKE的识别量
    @Column(name = "RCG_DPCHKE")
    private int rcgDispatchChke;   //GIS自动识别量中来自DISPATCH_CHKE的识别量
    @Column(name = "RCG_CHKN")
    private int rcgChkn;  //GIS自动识别量中来自CHKN的识别量
    @Column(name = "RCG_PHONE")
    private int rcgPhone;  //GIS自动识别量中来自Phone的识别量
    @Column(name = "RCG_DPCHKN")
    private int rcgDispatchChkn;   //GIS自动识别量中来自DISPATCH_CHKN的识别量
    @Column(name = "RCG_DPROAD")
    private int rcgDispatchRoad;   //GIS自动识别量中来自DISPATCH_ROAD的识别量
    @Column(name = "RCG_DPPHONE")
    private int rcgDispatchPhone;   //GIS自动识别量中来自DISPATCH_PHONE的识别量
    @Column(name = "RCG_CHKN_HISSCH")
    private int rcgChknHisSch;  //GIS自动识别量中CHKN识别中来自HIS_SCH的量
    @Column(name = "RCG_CHKN_CGCS")
    private int rcgChknCgcs;    //GIS自动识别量中CHKN识别中来自CGCS的量
    @Column(name = "RCG_CHKN_CGCSKDD")
    private int rcgChknCgcsKdd; //GIS自动识别量中CHKN识别中来自CGCS_KDD的量
    @Column(name = "RCG_CHKN_OMSKAFKA")
    private int rcgChknOmsKafka;    //GIS自动识别量中CHKN识别中来自OMS_KAFKA的量
    @Column(name = "RCG_CHKN_CMS")
    private int rcgChknCms;    //GIS自动识别量中CHKN识别中来自CMS的量
    @Column(name = "RCG_CHKN_OTHER")
    private int rcgChknOther;   //GIS自动识别量中CHKN识别中来自其它源的量
    @Column(name = "RCG_ARSS")
    private int rcgArss; //人工审补识别量
    @Column(name = "KS_REQ")
    private int chkKsReq; //ckn发往ks请求量
    @Column(name = "KS_RESP")
    private int chkKsRe; //ks返回量
    @Column(name = "KS_RCG_AOI")
    private int chkKsAoi; //ks的aoi的识别量
    @Column(name = "KS_RESP_TC")
    private int chkKsTc; //ks的tc识别量

    @Column(name = "RCG_KS")
    private int chkKsGisTc; //GIS自动识别量ks的tc识别量

    @Column(name = "FC_TC")
    private int fcTc; //GIS自动识别错call量（=FC_NORM+FC_SCH+FC_TC2+FC_CHKE+FC_CHKN）
    @Column(name = "FC_NORM")
    private int fcNorm; //GIS自动识别量中来自NORM的错call量
    @Column(name = "FC_DPNORM")
    private int fcDispatchNorm; //GIS自动识别量中来自DISPATCH_NORM的错call量
    @Column(name = "FC_SCH")
    private int fcSch; //GIS自动识别量中来自SCH的错call量
    @Column(name = "FC_TC2")
    private int fcTc2; //GIS自动识别量中来自TC2的错call量
    @Column(name = "FC_DPTC2")
    private int fcDispatchTc2; //GIS自动识别量中来自DISPATCH_TC2的错call量
    @Column(name = "FC_CHKE")
    private int fcChke; //GIS自动识别量中来自CHKE的错call量
    @Column(name = "FC_DPCHKE")
    private int fcDispatchChke; //GIS自动识别量中来自DISPATCH_CHKE的错call量
    @Column(name = "FC_CHKN")
    private int fcChkn; //GIS自动识别量中来自CHKN的错call量
    @Column(name = "FC_PHONE")
    private int fcPhone; //GIS自动识别量中来自phone的错call量
    @Column(name = "FC_DPCHKN")
    private int fcDispatchChkn; //GIS自动识别量中来自DISPATCH_CHKN的错call量

    @Column(name = "FC_DPROAD")
    private int fcDispatchRoad; //GIS自动识别量中来自DISPATCH_ROAD的错call量
    @Column(name = "FC_DPPHONE")
    private int fcDispatchPhone; //GIS自动识别量中来自DISPATCH_PHONE的错call量

    @Column(name = "FC_CHKN_HISSCH")
    private int fcChknHisSch; //GIS自动识别量中CHKN错call中来自HIS_SCH的量
    @Column(name = "FC_CHKN_CGCS")
    private int fcChknCgcs; //GIS自动识别量中CHKN错call中来自CGCS的量
    @Column(name = "FC_CHKN_CGCSKDD")
    private int fcChknCgcsKdd; //GIS自动识别量中CHKN错call中来自CGCS_KDD的量
    @Column(name = "FC_CHKN_OMSKAFKA")
    private int fcChknOmsKafka; //GIS自动识别量中CHKN错call中来自OMS_KAFKA的量
    @Column(name = "FC_CHKN_CMS")
    private int fcChknCms; //GIS自动识别量中CHKN错call中来自CMS的量
    @Column(name = "FC_CHKN_OTHER")
    private int fcChknOther; //GIS自动识别量中CHKN错call中来自其它源的量
    @Column(name = "FC_ARSS")
    private int fcArss; //人工审补错call量
    @Column(name = "FC_TOTAL")
    private int fcTotal; //总错call量--不管有没有请求   数据库表字段 和 FC_PUSH的值互换，所以fcTotal值目前存的是有请求的
    @Column(name = "FC_PUSH")
    private int fcPush; //每天推送的错call量 --关联的日志必须要包含请求
    @Column(name = "OVERTIME")
    private int overtime;
    @Column(name = "SYSSOURCE")
    private String sysSource;

    public String getSysSource() {
        return sysSource;
    }

    public void setSysSource(String sysSource) {
        this.sysSource = sysSource;
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }

    public String getUnderCall() {
        return underCall;
    }

    public void setUnderCall(String underCall) {
        this.underCall = underCall;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public int getChkKsGisTc() {
        return chkKsGisTc;
    }

    public void setChkKsGisTc(int chkKsGisTc) {
        this.chkKsGisTc = chkKsGisTc;
    }

    public int getChkKsReq() {
        return chkKsReq;
    }

    public void setChkKsReq(int chkKsReq) {
        this.chkKsReq = chkKsReq;
    }

    public int getChkKsRe() {
        return chkKsRe;
    }

    public void setChkKsRe(int chkKsRe) {
        this.chkKsRe = chkKsRe;
    }

    public int getChkKsAoi() {
        return chkKsAoi;
    }

    public void setChkKsAoi(int chkKsAoi) {
        this.chkKsAoi = chkKsAoi;
    }

    public int getChkKsTc() {
        return chkKsTc;
    }

    public void setChkKsTc(int chkKsTc) {
        this.chkKsTc = chkKsTc;
    }

    public int getFcPhone() {
        return fcPhone;
    }

    public void setFcPhone(int fcPhone) {
        this.fcPhone = fcPhone;
    }

    public int getRcgPhone() {
        return rcgPhone;
    }

    public void setRcgPhone(int rcgPhone) {
        this.rcgPhone = rcgPhone;
    }

    public int getRcgDispatchRoad() {
        return rcgDispatchRoad;
    }

    public void setRcgDispatchRoad(int rcgDispatchRoad) {
        this.rcgDispatchRoad = rcgDispatchRoad;
    }

    public int getRcgDispatchPhone() {
        return rcgDispatchPhone;
    }

    public void setRcgDispatchPhone(int rcgDispatchPhone) {
        this.rcgDispatchPhone = rcgDispatchPhone;
    }

    public int getFcDispatchRoad() {
        return fcDispatchRoad;
    }

    public void setFcDispatchRoad(int fcDispatchRoad) {
        this.fcDispatchRoad = fcDispatchRoad;
    }

    public int getFcDispatchPhone() {
        return fcDispatchPhone;
    }

    public void setFcDispatchPhone(int fcDispatchPhone) {
        this.fcDispatchPhone = fcDispatchPhone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getRcgTc() {
        return rcgTc;
    }

    public void setRcgTc(int rcgTc) {
        this.rcgTc = rcgTc;
    }

    public int getRcgNorm() {
        return rcgNorm;
    }

    public void setRcgNorm(int rcgNorm) {
        this.rcgNorm = rcgNorm;
    }

    public int getRcgSch() {
        return rcgSch;
    }

    public void setRcgSch(int rcgSch) {
        this.rcgSch = rcgSch;
    }

    public int getRcgTc2() {
        return rcgTc2;
    }

    public void setRcgTc2(int rcgTc2) {
        this.rcgTc2 = rcgTc2;
    }

    public int getRcgChke() {
        return rcgChke;
    }

    public void setRcgChke(int rcgChke) {
        this.rcgChke = rcgChke;
    }

    public int getRcgChkn() {
        return rcgChkn;
    }

    public void setRcgChkn(int rcgChkn) {
        this.rcgChkn = rcgChkn;
    }

    public int getRcgChknHisSch() {
        return rcgChknHisSch;
    }

    public void setRcgChknHisSch(int rcgChknHisSch) {
        this.rcgChknHisSch = rcgChknHisSch;
    }

    public int getRcgChknCgcs() {
        return rcgChknCgcs;
    }

    public void setRcgChknCgcs(int rcgChknCgcs) {
        this.rcgChknCgcs = rcgChknCgcs;
    }

    public int getRcgChknOmsKafka() {
        return rcgChknOmsKafka;
    }

    public void setRcgChknOmsKafka(int rcgChknOmsKafka) {
        this.rcgChknOmsKafka = rcgChknOmsKafka;
    }

    public int getRcgChknCms() {
        return rcgChknCms;
    }

    public void setRcgChknCms(int rcgChknCms) {
        this.rcgChknCms = rcgChknCms;
    }

    public int getRcgChknOther() {
        return rcgChknOther;
    }

    public void setRcgChknOther(int rcgChknOther) {
        this.rcgChknOther = rcgChknOther;
    }

    public int getRcgArss() {
        return rcgArss;
    }

    public void setRcgArss(int rcgArss) {
        this.rcgArss = rcgArss;
    }

    public int getFcTc() {
        return fcTc;
    }

    public void setFcTc(int fcTc) {
        this.fcTc = fcTc;
    }

    public int getFcNorm() {
        return fcNorm;
    }

    public void setFcNorm(int fcNorm) {
        this.fcNorm = fcNorm;
    }

    public int getFcSch() {
        return fcSch;
    }

    public void setFcSch(int fcSch) {
        this.fcSch = fcSch;
    }

    public int getFcTc2() {
        return fcTc2;
    }

    public void setFcTc2(int fcTc2) {
        this.fcTc2 = fcTc2;
    }

    public int getFcChke() {
        return fcChke;
    }

    public void setFcChke(int fcChke) {
        this.fcChke = fcChke;
    }

    public int getFcChkn() {
        return fcChkn;
    }

    public void setFcChkn(int fcChkn) {
        this.fcChkn = fcChkn;
    }

    public int getFcChknHisSch() {
        return fcChknHisSch;
    }

    public void setFcChknHisSch(int fcChknHisSch) {
        this.fcChknHisSch = fcChknHisSch;
    }

    public int getFcChknCgcs() {
        return fcChknCgcs;
    }

    public void setFcChknCgcs(int fcChknCgcs) {
        this.fcChknCgcs = fcChknCgcs;
    }

    public int getFcChknOmsKafka() {
        return fcChknOmsKafka;
    }

    public void setFcChknOmsKafka(int fcChknOmsKafka) {
        this.fcChknOmsKafka = fcChknOmsKafka;
    }

    public int getFcChknCms() {
        return fcChknCms;
    }

    public void setFcChknCms(int fcChknCms) {
        this.fcChknCms = fcChknCms;
    }

    public int getFcChknOther() {
        return fcChknOther;
    }

    public void setFcChknOther(int fcChknOther) {
        this.fcChknOther = fcChknOther;
    }

    public int getFcArss() {
        return fcArss;
    }

    public void setFcArss(int fcArss) {
        this.fcArss = fcArss;
    }

    public int getFcTotal() {
        return fcTotal;
    }

    public void setFcTotal(int fcTotal) {
        this.fcTotal = fcTotal;
    }

    public int getFcPush() {
        return fcPush;
    }

    public void setFcPush(int fcPush) {
        this.fcPush = fcPush;
    }

    public int getOvertime() {
        return overtime;
    }

    public void setOvertime(int overtime) {
        this.overtime = overtime;
    }

    public int getFcDispatchNorm() {
        return fcDispatchNorm;
    }

    public void setFcDispatchNorm(int fcDispatchNorm) {
        this.fcDispatchNorm = fcDispatchNorm;
    }

    public int getFcDispatchTc2() {
        return fcDispatchTc2;
    }

    public void setFcDispatchTc2(int fcDispatchTc2) {
        this.fcDispatchTc2 = fcDispatchTc2;
    }

    public int getFcDispatchChke() {
        return fcDispatchChke;
    }

    public void setFcDispatchChke(int fcDispatchChke) {
        this.fcDispatchChke = fcDispatchChke;
    }

    public int getFcDispatchChkn() {
        return fcDispatchChkn;
    }

    public void setFcDispatchChkn(int fcDispatchChkn) {
        this.fcDispatchChkn = fcDispatchChkn;
    }

    public int getRcgDispatchNorm() {
        return rcgDispatchNorm;
    }

    public void setRcgDispatchNorm(int rcgDispatchNorm) {
        this.rcgDispatchNorm = rcgDispatchNorm;
    }

    public int getRcgDispatchTc2() {
        return rcgDispatchTc2;
    }

    public void setRcgDispatchTc2(int rcgDispatchTc2) {
        this.rcgDispatchTc2 = rcgDispatchTc2;
    }

    public int getRcgDispatchChke() {
        return rcgDispatchChke;
    }

    public void setRcgDispatchChke(int rcgDispatchChke) {
        this.rcgDispatchChke = rcgDispatchChke;
    }

    public int getRcgDispatchChkn() {
        return rcgDispatchChkn;
    }

    public void setRcgDispatchChkn(int rcgDispatchChkn) {
        this.rcgDispatchChkn = rcgDispatchChkn;
    }

    public int getRcgChknCgcsKdd() {
        return rcgChknCgcsKdd;
    }

    public void setRcgChknCgcsKdd(int rcgChknCgcsKdd) {
        this.rcgChknCgcsKdd = rcgChknCgcsKdd;
    }

    public int getFcChknCgcsKdd() {
        return fcChknCgcsKdd;
    }

    public void setFcChknCgcsKdd(int fcChknCgcsKdd) {
        this.fcChknCgcsKdd = fcChknCgcsKdd;
    }

    public void merge(OmsPuTc obj) {
        this.order += obj.getOrder();
        this.rcgTc += obj.getRcgTc();
        this.rcgNorm += obj.getRcgNorm();
        this.rcgSch += obj.getRcgSch();
        this.rcgTc2 += obj.getRcgTc2();
        this.rcgChke += obj.getRcgChke();
        this.rcgChkn += obj.getRcgChkn();
        this.rcgPhone += obj.getRcgPhone();
        this.rcgChknHisSch += obj.getRcgChknHisSch();
        this.rcgChknCgcs += obj.getRcgChknCgcs();
        this.rcgChknOmsKafka += obj.getRcgChknOmsKafka();
        this.rcgChknCms += obj.getRcgChknCms();
        this.rcgChknOther += obj.getRcgChknOther();
        this.rcgArss += obj.getRcgArss();
        this.chkKsReq += obj.getChkKsReq();
        this.chkKsRe += obj.getChkKsRe();
        this.chkKsAoi += obj.getChkKsAoi();
        this.chkKsTc += obj.getChkKsTc();
        this.chkKsGisTc += obj.getChkKsGisTc();
        this.fcTc += obj.getFcTc();
        this.fcNorm += obj.getFcNorm();
        this.fcSch += obj.getFcSch();
        this.fcTc2 += obj.getFcTc2();
        this.fcChke += obj.getFcChke();
        this.fcChkn += obj.getFcChkn();
        this.fcPhone += obj.getFcPhone();
        this.fcChknHisSch += obj.getFcChknHisSch();
        this.fcChknCgcs += obj.getFcChknCgcs();
        this.fcChknOmsKafka += obj.getFcChknOmsKafka();
        this.fcChknCms += obj.getFcChknCms();
        this.fcChknOther += obj.getFcChknOther();
        this.fcArss += obj.getFcArss();
        this.fcTotal += obj.getFcTotal();
        this.fcPush += obj.getFcPush();
        this.overtime += obj.getOvertime();
        this.rcgDispatchNorm += obj.getRcgDispatchNorm();
        this.rcgDispatchTc2 += obj.getRcgDispatchTc2();
        this.rcgDispatchChke += obj.getRcgDispatchChke();
        this.rcgDispatchChkn += obj.getRcgDispatchChkn();
        this.rcgDispatchRoad += obj.getRcgDispatchRoad();
        this.rcgDispatchPhone += obj.getRcgDispatchPhone();
        this.rcgChknCgcsKdd += obj.getRcgChknCgcsKdd();
        this.fcDispatchNorm += obj.getFcDispatchNorm();
        this.fcDispatchTc2 += obj.getFcDispatchTc2();
        this.fcDispatchChke += obj.getFcDispatchChke();
        this.fcDispatchChkn += obj.getFcDispatchChkn();
        this.fcDispatchRoad += obj.getFcDispatchRoad();
        this.fcDispatchPhone += obj.getFcDispatchPhone();
        this.fcChknCgcsKdd += obj.getFcChknCgcsKdd();
    }

    /**
     * 初始化
     * @param obj
     */
    public void init(OmsPuTc obj) {
        this.underCall = obj.getUnderCall();
        this.dataType = obj.getDataType();
        this.statDate = obj.getStatDate();
        this.province = obj.getProvince();
        this.region = obj.getRegion();
        this.cityCode = obj.getCityCode();
        this.city = obj.getCity();
        this.zoneCode = obj.getZoneCode();
        this.order = obj.getOrder();
        this.rcgTc = obj.getRcgTc();
        this.rcgNorm = obj.getRcgNorm();
        this.rcgSch = obj.getRcgSch();
        this.rcgTc2 = obj.getRcgTc2();
        this.rcgChke = obj.getRcgChke();
        this.rcgChkn = obj.getRcgChkn();
        this.rcgPhone = obj.getRcgPhone();
        this.rcgChknHisSch = obj.getRcgChknHisSch();
        this.rcgChknCgcs = obj.getRcgChknCgcs();
        this.rcgChknOmsKafka = obj.getRcgChknOmsKafka();
        this.rcgChknCms = obj.getRcgChknCms();
        this.rcgChknOther = obj.getRcgChknOther();
        this.rcgArss = obj.getRcgArss();
        this.chkKsReq = obj.getChkKsReq();
        this.chkKsRe = obj.getChkKsRe();
        this.chkKsAoi = obj.getChkKsAoi();
        this.chkKsTc = obj.getChkKsTc();
        this.chkKsGisTc = obj.getChkKsGisTc();
        this.fcTc = obj.getFcTc();
        this.fcNorm = obj.getFcNorm();
        this.fcSch = obj.getFcSch();
        this.fcTc2 = obj.getFcTc2();
        this.fcChke = obj.getFcChke();
        this.fcChkn = obj.getFcChkn();
        this.fcPhone = obj.getFcPhone();
        this.fcChknHisSch = obj.getFcChknHisSch();
        this.fcChknCgcs = obj.getFcChknCgcs();
        this.fcChknOmsKafka = obj.getFcChknOmsKafka();
        this.fcChknCms = obj.getFcChknCms();
        this.fcChknOther = obj.getFcChknOther();
        this.fcArss = obj.getFcArss();
        this.fcTotal = obj.getFcTotal();
        this.fcPush = obj.getFcPush();
        this.overtime = obj.getOvertime();
        this.rcgDispatchNorm = obj.getRcgDispatchNorm();
        this.rcgDispatchTc2 = obj.getRcgDispatchTc2();
        this.rcgDispatchChke = obj.getRcgDispatchChke();
        this.rcgDispatchChkn = obj.getRcgDispatchChkn();
        this.rcgDispatchRoad = obj.getRcgDispatchRoad();
        this.rcgDispatchPhone = obj.getRcgDispatchPhone();
        this.rcgChknCgcsKdd = obj.getRcgChknCgcsKdd();
        this.fcDispatchNorm = obj.getFcDispatchNorm();
        this.fcDispatchTc2 = obj.getFcDispatchTc2();
        this.fcDispatchChke = obj.getFcDispatchChke();
        this.fcDispatchChkn = obj.getFcDispatchChkn();
        this.fcDispatchRoad = obj.getFcDispatchRoad();
        this.fcDispatchPhone = obj.getFcDispatchPhone();
        this.fcChknCgcsKdd = obj.getFcChknCgcsKdd();
        this.sysSource = obj.getSysSource();
    }

    /**
     * 更新错柯gis指标
     * @param value
     */
    public void updateFcGis(int value) {
        fcTc = value;
        fcNorm = value;
        fcSch = value;
        fcTc2 = value;
        fcChke = value;
        fcChkn = value;
        fcPhone = value;
        fcDispatchNorm = value;
        fcDispatchChkn = value;
        fcDispatchChke = value;
        fcDispatchTc2 = value;
        fcDispatchRoad = value;
        fcDispatchPhone = value;
        fcChknHisSch = value;
        fcChknCgcs = value;
        fcChknOmsKafka = value;
        fcChknCms = value;
        fcChknCgcsKdd = value;
        fcChknOther = value;
    }

    /**
     * 重置所有指标
     * @param value
     */
    public void resetAllSta(int value) {
        this.order = value;
        this.rcgTc = value;
        this.rcgNorm = value;
        this.rcgSch = value;
        this.rcgTc2 = value;
        this.rcgChke = value;
        this.rcgChkn = value;
        this.rcgPhone = value;
        this.rcgChknHisSch = value;
        this.rcgChknCgcs = value;
        this.rcgChknOmsKafka = value;
        this.rcgChknCms = value;
        this.rcgChknOther = value;
        this.rcgArss = value;
        this.chkKsReq = value;
        this.chkKsRe = value;
        this.chkKsAoi = value;
        this.chkKsTc = value;
        this.chkKsGisTc = value;
        this.fcTc = value;
        this.fcNorm = value;
        this.fcSch = value;
        this.fcTc2 = value;
        this.fcChke = value;
        this.fcChkn = value;
        this.fcPhone = value;
        this.fcChknHisSch = value;
        this.fcChknCgcs = value;
        this.fcChknOmsKafka = value;
        this.fcChknCms = value;
        this.fcChknOther = value;
        this.fcArss = value;
        this.fcTotal = value;
        this.fcPush = value;
        this.overtime = value;
        this.rcgDispatchNorm = value;
        this.rcgDispatchTc2 = value;
        this.rcgDispatchChke = value;
        this.rcgDispatchChkn = value;
        this.rcgDispatchRoad = value;
        this.rcgDispatchPhone = value;
        this.rcgChknCgcsKdd = value;
        this.fcDispatchNorm = value;
        this.fcDispatchTc2 = value;
        this.fcDispatchChke = value;
        this.fcDispatchChkn = value;
        this.fcDispatchRoad = value;
        this.fcDispatchPhone = value;
        this.fcChknCgcsKdd = value;
    }
}
