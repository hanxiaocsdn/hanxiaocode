package com.sf.gis.scala.oms_shou.pojo.rds;

import java.io.Serializable;

/**
 * at层返回other数据
 * Created by 01368078 on 2019/3/26.
 */
public class Other implements Serializable {
    private String geozc;
    private String schzc;
    private String tc2gid;
    private String schtc;
    private String geosrc;
    private String geotc;
    private String gid;
    private String chkdeptsrc;
    private String precision;
    private String chktcsrc;
    private String dsrc;

    public String getGeozc() {
        return geozc;
    }

    public void setGeozc(String geozc) {
        this.geozc = geozc;
    }

    public String getSchzc() {
        return schzc;
    }

    public void setSchzc(String schzc) {
        this.schzc = schzc;
    }

    public String getTc2gid() {
        return tc2gid;
    }

    public void setTc2gid(String tc2gid) {
        this.tc2gid = tc2gid;
    }

    public String getSchtc() {
        return schtc;
    }

    public void setSchtc(String schtc) {
        this.schtc = schtc;
    }

    public String getGeosrc() {
        return geosrc;
    }

    public void setGeosrc(String geosrc) {
        this.geosrc = geosrc;
    }

    public String getGeotc() {
        return geotc;
    }

    public void setGeotc(String geotc) {
        this.geotc = geotc;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public String getChkdeptsrc() {
        return chkdeptsrc;
    }

    public void setChkdeptsrc(String chkdeptsrc) {
        this.chkdeptsrc = chkdeptsrc;
    }

    public String getPrecision() {
        return precision;
    }

    public void setPrecision(String precision) {
        this.precision = precision;
    }

    public String getChktcsrc() {
        return chktcsrc;
    }

    public void setChktcsrc(String chktcsrc) {
        this.chktcsrc = chktcsrc;
    }

    public String getDsrc() {
        return dsrc;
    }

    public void setDsrc(String dsrc) {
        this.dsrc = dsrc;
    }
}
