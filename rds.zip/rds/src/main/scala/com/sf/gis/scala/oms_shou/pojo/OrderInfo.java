package com.sf.gis.scala.oms_shou.pojo;

import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.oms_shou.pojo.arss.ArssReBody;
import com.sf.gis.scala.oms_shou.pojo.arss.ArssReqBody;
import com.sf.gis.scala.oms_shou.pojo.errCall.ErrCallBody;
import com.sf.gis.scala.oms_shou.pojo.rds.*;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/8.
 */
public class OrderInfo implements Serializable {
    private String sysOrderNo;
    private OmsReqBody syncReqBody;
    private OmsReBody syncReBody;
    private OmsReqBody asyncReqBody;
    private OmsReBody asyncReBody;
    private RdsArssReqBody rdsArssReqBody;
    private ArssReqBody arssReqBody;
    private ArssReBody arssReBody;
    private ErrCallBody errCallBody;
    private JSONObject chkKsReqBody;
    private JSONObject chkKsReBody;
    private JSONObject chkOmsRebody;
    private JSONObject pickupBody;
    private JSONObject requestBuildingBody;
    private JSONObject responseBuildingBody;
    private JSONObject atShouBody;
    private String dataTime;
    private String reqId;
    private int tag;

    public JSONObject getAtShouBody() {
        return atShouBody;
    }

    public void setAtShouBody(JSONObject atShouBody) {
        this.atShouBody = atShouBody;
    }

    public int getTag() {
        return tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public String getDataTime() {
        return dataTime;
    }

    public void setDataTime(String dataTime) {
        this.dataTime = dataTime;
    }

    public JSONObject getRequestBuildingBody() {
        return requestBuildingBody;
    }

    public void setRequestBuildingBody(JSONObject requestBuildingBody) {
        this.requestBuildingBody = requestBuildingBody;
    }

    public JSONObject getResponseBuildingBody() {
        return responseBuildingBody;
    }

    public void setResponseBuildingBody(JSONObject responseBuildingBody) {
        this.responseBuildingBody = responseBuildingBody;
    }

    public JSONObject getPickupBody() {
        return pickupBody;
    }

    public void setPickupBody(JSONObject pickupBody) {
        this.pickupBody = pickupBody;
    }

    public JSONObject getChkOmsRebody() {
        return chkOmsRebody;
    }

    public void setChkOmsRebody(JSONObject chkOmsRebody) {
        this.chkOmsRebody = chkOmsRebody;
    }

    public JSONObject getChkKsReqBody() {
        return chkKsReqBody;
    }

    public void setChkKsReqBody(JSONObject chkKsReqBody) {
        this.chkKsReqBody = chkKsReqBody;
    }

    public JSONObject getChkKsReBody() {
        return chkKsReBody;
    }

    public void setChkKsReBody(JSONObject chkKsReBody) {
        this.chkKsReBody = chkKsReBody;
    }

    public String getSysOrderNo() {
        return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public OmsReqBody getSyncReqBody() {
        return syncReqBody;
    }

    public void setSyncReqBody(OmsReqBody syncReqBody) {
        this.syncReqBody = syncReqBody;
    }

    public OmsReBody getSyncReBody() {
        return syncReBody;
    }

    public void setSyncReBody(OmsReBody syncReBody) {
        this.syncReBody = syncReBody;
    }

    public OmsReqBody getAsyncReqBody() {
        return asyncReqBody;
    }

    public void setAsyncReqBody(OmsReqBody asyncReqBody) {
        this.asyncReqBody = asyncReqBody;
    }

    public OmsReBody getAsyncReBody() {
        return asyncReBody;
    }

    public void setAsyncReBody(OmsReBody asyncReBody) {
        this.asyncReBody = asyncReBody;
    }

    public RdsArssReqBody getRdsArssReqBody() {
        return rdsArssReqBody;
    }

    public void setRdsArssReqBody(RdsArssReqBody rdsArssReqBody) {
        this.rdsArssReqBody = rdsArssReqBody;
    }

    public ArssReqBody getArssReqBody() {
        return arssReqBody;
    }

    public void setArssReqBody(ArssReqBody arssReqBody) {
        this.arssReqBody = arssReqBody;
    }

    public ArssReBody getArssReBody() {
        return arssReBody;
    }

    public void setArssReBody(ArssReBody arssReBody) {
        this.arssReBody = arssReBody;
    }

    public ErrCallBody getErrCallBody() {
        return errCallBody;
    }

    public void setErrCallBody(ErrCallBody errCallBody) {
        this.errCallBody = errCallBody;
    }
}
