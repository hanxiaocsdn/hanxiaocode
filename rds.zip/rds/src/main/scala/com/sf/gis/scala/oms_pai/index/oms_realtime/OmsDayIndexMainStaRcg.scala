package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.security.MessageDigest
import java.sql.Connection
import java.util

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.csvreader.CsvReader
import com.sf.gis.java.base.util.{DateUtil, MD5Util}
import com.sf.gis.scala.base.spark.{Spark, SparkRead}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_pai.index.oms_realtime.Obj._
import com.sf.gis.scala.oms_pai.index.oms_realtime.OmsIndexStat.MergeType
import com.sf.gis.scala.oms_pai.index.oms_realtime.OmsIndexStat.MergeType.MergeType
import com.sf.gis.scala.utils.{DbUtils, Util}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.Map
import scala.collection.mutable.ArrayBuffer

/**
 * 任务id:628807,628791,628797(rds派件指标系统-即日-指标统计,rds派件指标系统-隔日-指标统计,rds派件指标系统-三日-指标统计)
 * 业务方：01434056（唐巧亭）
 * 研发：013995851（匡仁衡）
 * 时间：2023年9月15日10:54:07
 */
object OmsDayIndexMainStaRcg {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  //若有需要，只需去ParseOmsLog放开
  /**
   * main方法
   *
   * @param args : 参数
   */
  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val taskCode = args(1).toInt
    start(incDay, taskCode)
  }


  /**
   * 开始任务
   */
  def start(incDay: String, taskCode: Int): Unit = {
    val spark = Spark.getSparkSession(appName)
    handleTask(spark, incDay, taskCode)
  }

  def fetchOriginLog(spark: SparkSession, incDay: String) = {
    val sql = s"select req_waybillno,province, city, req_body, req_time, gis_to_sys_body,atpai_body, arss_dept_req_body, arss_dept_re_body," +
      s"awsm_tc_req_body, awsm_tc_re_body,geo_body, re_body_item,  ks_req_body,ks_re_body, aoi_dept_req_body," +
      s"aoi_dept_re_body, bid_re_body, groupIds,notc, chkDeptSrc,precision, gisAoiSrc,gisAoiCode,splitResult,filters,arss_dept_re_array,arss_dept_req_array from(" +
      s"select req_waybillno,req_province province, req_destcitycode city, req_body, req_time, gis_to_sys_body,at_pai_body atpai_body, arss_dept_req_body, arss_dept_re_body," +
      s"awsm_tc_req_body, awsm_tc_re_body,geo_body, re_body_latest re_body_item,  ks_req_body,ks_re_body, aoi_dept_req_body," +
      s"aoi_dept_re_body, bid_re_body,groupids groupIds,notc,chkdeptsrc chkDeptSrc,precision,gisaoisrc gisAoiSrc,gisaoicode gisAoiCode," +
      s"splitresult splitResult,filters,arss_dept_re_array,arss_dept_req_array,row_number() over(partition by req_waybillno order by req_time desc ) rank from dm_gis.gis_rds_omsto " +
      s"where inc_day='$incDay' and req_waybillno is not null and req_waybillno<>''" +
      " and (get_json_object(req_body,'$.addresseeCompName') is null or get_json_object(req_body,'$.addresseeCompName')<>'baison') )a where rank = 1"
    logger.error(sql)
    val (dataRdd, columns) = SparkRead.readHiveAsJson(spark, sql, 3200)
    dataRdd
  }

  /**
   * 处理任务
   */
  def handleTask(spark: SparkSession,
                 incDay: String, taskCode: Int): Unit = {
    logger.error("--------start-------处理oms派件日志，日期：" + incDay)
    var logRdd = fetchOriginLog(spark, incDay)

    logger.error(">>>统计指标...")
    val (rowIndexRdd, emptyAoiRdd) = statTotalIndex(logRdd, spark, incDay, taskCode)
    logger.error(">>>统计各维度派件指标...")
    val indexRddMergeAoi = statIndexMergeAoi(rowIndexRdd, emptyAoiRdd)
    saveIndexMergeAoiToHive(spark, incDay, indexRddMergeAoi)
    Spark.clearPersistWithoutId(spark, rowIndexRdd.id)
    val indexRddMerge = statIndexMerge(rowIndexRdd, emptyAoiRdd)
    rowIndexRdd.unpersist()
    saveIndexMergeToHive(spark, incDay, indexRddMerge)
    //    logger.error(">>>指标入库...")

    //    saveIndexMerge(indexRddMerge, incDay, taskCode, javaUtil, spark)
    //    saveIndexMergeAoi(indexRddMergeAoi, incDay, taskCode, javaUtil, spark)
//    logger.error("保存指标到hive")


  }

  def statIndexMergeAoi(rowIndexRdd: RDD[(String, DlvRcgObj, DlvAoiObj)], emptyAoiRdd: RDD[(String, Int)]): (RDD[(String, DlvAoiObj)]) = {
    var aoiRdd = rowIndexRdd.map(obj => {
      (obj._1, obj._3)
    })
    //    rowIndexRdd.filter(obj=>obj._5.endsWith("_551")&&obj._4.aoi_invalid_dept==1).map(obj=>obj._5).collect().foreach(obj=>
    //      logger.error(obj)
    //    )
    if (emptyAoiRdd != null) {
      aoiRdd = aoiRdd.leftOuterJoin(emptyAoiRdd).map(obj => {
        val rowIndex = obj._2._1
        val aoiEmptyOption = obj._2._2
        if (aoiEmptyOption.nonEmpty) {
          (obj._1, rowIndex.copy(aoi_invalid_address = 1))
        } else {
          (obj._1, rowIndex.copy(aoi_invalid_address = 0))
        }
      })
    }
    val aoiRddFinal = aoiRdd.flatMap(obj => {
      val dlvAoiobj = obj._2
      val list = new util.ArrayList[DlvAoiObj]()
      list.add(dlvAoiobj.copy(rejection_type = "PRE"))
      if (dlvAoiobj.aoi_invalid_dept == 0) {
        list.add(dlvAoiobj.copy(rejection_type = "REJECT_DEPT"))
        if (dlvAoiobj.aoi_invalid_address == 0) {
          list.add(dlvAoiobj.copy(rejection_type = "REJECT_DEPT_ADDR"))
        }
      }
      list.iterator()
    })
    logger.error(">>>指标按网点聚合")
    val dlvAoiRddZc = mergeDlvAoiByType(MergeType.zc, aoiRddFinal).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>指标按网点聚合:" + dlvAoiRddZc.count())
    logger.error(">>>指标按城市聚合")
    val dlvAoiRddCity = mergeDlvAoiIndexByType(MergeType.city, dlvAoiRddZc).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>指标按城市聚合:" + dlvAoiRddCity.count())
    logger.error(">>>指标按区聚合")
    val dlvAoiRddRegion = mergeDlvAoiIndexByType(MergeType.region, dlvAoiRddCity).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>指标按区聚合:" + dlvAoiRddRegion.count())
    logger.error(">>>指标按时间聚合")
    val dlvAoiRddDate = mergeDlvAoiIndexByType(MergeType.date, dlvAoiRddRegion).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>指标按时间聚合:" + dlvAoiRddDate.count())
    dlvAoiRddDate.union(dlvAoiRddRegion)
      .union(dlvAoiRddCity).union(dlvAoiRddZc)
  }

  def mergeDlvAoiIndexByType(mergeType: MergeType, dlvAoiRdd: RDD[(String, DlvAoiObj)]): RDD[(String, DlvAoiObj)] = {
    val invalidRegion = Array[String]("", "香港区", "澳门区", "台湾区")
    var convertRdd: RDD[((String, String), DlvAoiObj)] = null
    if (mergeType.equals(MergeType.date)) {
      // 日期
      convertRdd = dlvAoiRdd.map(_._2).filter(obj => (obj.region != null
        && !invalidRegion.contains(obj.region))).map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date).mkString("_")
        val tmp = obj.copy(region = "ALL", city = "ALL", zonecode = "ALL", city_code = "ALL")
        ((key, "ALL"), tmp)
      })
    } else if (mergeType.equals(MergeType.region)) {
      //大区
      convertRdd = dlvAoiRdd.map(_._2).map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date, obj.region).mkString("_")
        val tmp = obj.copy(city = "ALL", zonecode = "ALL", city_code = "ALL")
        ((key, "REGION"), tmp)
      })
    } else if (mergeType.equals(MergeType.city)) {
      //城市
      convertRdd = dlvAoiRdd.map(_._2).map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date, obj.region, obj.city).mkString("_")
        val tmp = obj.copy(zonecode = "ALL")
        ((key, "CITY"), tmp)
      })
    } else if (mergeType.equals(MergeType.zc)) {
      //网点
      convertRdd = dlvAoiRdd.map(_._2).map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date, obj.region, obj.city, obj.zonecode).mkString("_")
        ((key, "ZC"), obj)
      })
    } else {
      return null
    }
    convertRdd.reduceByKey((o1, o2) => {
      mergeDlvAoiIndex(o1, o2)
    }).map(obj => (obj._1._2, obj._2))
  }

  def mergeDlvAoiIndex(o1: DlvAoiObj, o2: DlvAoiObj): DlvAoiObj = {
    val reject_type = o1.rejection_type
    val stat_date = o1.stat_date
    val province = o1.province
    val region = o1.region
    val city = o1.city
    //    if(!checkValidCityData(city) && checkValidCityData(o2.city)){
    //      city = o2.city
    //    }
    val city_code = o1.city_code
    val zonecode = o1.zonecode
    val req = o1.req + o2.req
    val aoi = o1.aoi + o2.aoi
    val aoi_req = o1.aoi_req + o2.aoi_req
    val aoi_re = o1.aoi_re + o2.aoi_re
    val aoi_suc = o1.aoi_suc + o2.aoi_suc
    val aoi_dept_error = o1.aoi_dept_error + o2.aoi_dept_error
    val aoi_address_unknown = o1.aoi_address_unknown + o2.aoi_address_unknown
    val gis_aoi = o1.gis_aoi + o2.gis_aoi
    val ks_aoi = o1.ks_aoi + o2.ks_aoi
    val sys_aoi = o1.sys_aoi + o2.sys_aoi
    val rcg_gis_aoi_norm = o1.rcg_gis_aoi_norm + o2.rcg_gis_aoi_norm
    val rcg_gis_aoi_chkn = o1.rcg_gis_aoi_chkn + o2.rcg_gis_aoi_chkn
    val rcg_gis_aoi_chke = o1.rcg_gis_aoi_chke + o2.rcg_gis_aoi_chke
    val rcg_gis_aoi_phone = o1.rcg_gis_aoi_phone + o2.rcg_gis_aoi_phone
    val rcg_gis_aoi_road = o1.rcg_gis_aoi_road + o2.rcg_gis_aoi_road
    val rcg_gis_aoi_tc2 = o1.rcg_gis_aoi_tc2 + o2.rcg_gis_aoi_tc2
    val rcg_gis_aoi_auto = o1.rcg_gis_aoi_auto + o2.rcg_gis_aoi_auto
    val rcg_gis_aoi_normhp = o1.rcg_gis_aoi_normhp + o2.rcg_gis_aoi_normhp
    val rcg_gis_aoi_normcompany = o1.rcg_gis_aoi_normcompany + o2.rcg_gis_aoi_normcompany
    val rcg_gis_aoi_other = o1.rcg_gis_aoi_other + o2.rcg_gis_aoi_other
    val address_building = o1.addressee_building + o2.addressee_building
    val bidCollectCnt = o1.bidCollectCnt + o2.bidCollectCnt
    val bidCollectRejectCnt = o1.bidCollectRejectCnt + o2.bidCollectRejectCnt
    val bidCfCnt = o1.bidCfCnt + o2.bidCfCnt
    val bidSysCnt = o1.bidSysCnt + o2.bidSysCnt
    val bidSysBaseCnt = o1.bidSysBaseCnt + o2.bidSysBaseCnt
    val bidSysOk = o1.bidSysOk + o2.bidSysOk
    val bidAoiidDiff = o1.bidAoiidDiff + o2.bidAoiidDiff
    val bidCfNorm = o1.bidCfNorm + o2.bidCfNorm
    val bidCfNormMultiGid = o1.bidCfNormMultiGid + o2.bidCfNormMultiGid
    val bidCfComapny = o1.bidCfComapny + o2.bidCfComapny
    val bidCfPhone = o1.bidCfPhone + o2.bidCfPhone
    val bidCfDsPoi = o1.bidCfDsPoi + o2.bidCfDsPoi
    val bidCfMinPoi = o1.bidCfMinPoi + o2.bidCfMinPoi
    val bidCfAoiMapping1 = o1.bidCfAoiMapping1 + o2.bidCfAoiMapping1
    val bidCfAoiMapping2 = o1.bidCfAoiMapping2 + o2.bidCfAoiMapping2
    val bidCfAoiSimilar = o1.bidCfAoiSimilar + o2.bidCfAoiSimilar
    val bidCfOther = o1.bidCfOther + o2.bidCfOther
    val ks_only_aoi = o1.ks_only_aoi + o2.ks_only_aoi
    DlvAoiObj(reject_type, stat_date, province, region, city, city_code, zonecode, req, aoi, aoi_req, aoi_re, aoi_suc, aoi_dept_error, aoi_address_unknown,
      gis_aoi, ks_aoi, sys_aoi, rcg_gis_aoi_norm, rcg_gis_aoi_chkn, rcg_gis_aoi_chke, rcg_gis_aoi_phone, rcg_gis_aoi_road, rcg_gis_aoi_tc2, rcg_gis_aoi_auto, rcg_gis_aoi_normhp,
      rcg_gis_aoi_normcompany, rcg_gis_aoi_other, 0, 0, address_building, bidCollectCnt, bidCollectRejectCnt, bidCfCnt, bidSysCnt, bidSysBaseCnt, bidSysOk, bidAoiidDiff,
      bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping1, bidCfAoiMapping2, bidCfAoiSimilar, bidCfOther,
      ks_only_aoi
    )
  }

  def mergeDlvAoiByType(mergeType: MergeType, aoiRdd: RDD[DlvAoiObj]): RDD[(String, DlvAoiObj)] = {
    if (mergeType.equals(MergeType.zc)) {
      //网点
      aoiRdd.map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date, obj.region, obj.city, obj.zonecode).mkString("_")
        ((key, "ZC"), obj)
      }).reduceByKey((o1, o2) => {
        mergeDlvAoiIndex(o1, o2)
      }).map(obj => (obj._1._2, obj._2))
    } else {
      null
    }
  }

  def statIndexMerge(rowIndexRdd: RDD[(String, DlvRcgObj, DlvAoiObj)], emptyAoiRdd: RDD[(String, Int)]): (RDD[DlvRcgObj], RDD[DlvRcgObj], RDD[DlvRcgObj], RDD[DlvRcgObj]) = {
    var aoiRdd = rowIndexRdd.map(obj => {
      (obj._1, obj._2)
    })

    if (emptyAoiRdd != null) {
      aoiRdd = aoiRdd.leftOuterJoin(emptyAoiRdd).map(obj => {
        val rowIndex = obj._2._1
        val aoiEmptyOption = obj._2._2
        if (aoiEmptyOption.nonEmpty) {
          (obj._1, rowIndex.copy(aoi_invalid_address = 1))
        } else {
          (obj._1, rowIndex.copy(aoi_invalid_address = 0))
        }
      })
    }
    val aoiRddFinal = aoiRdd.flatMap(obj => {
      val dlvRcgObj = obj._2
      val list = new util.ArrayList[DlvRcgObj]()
      list.add(dlvRcgObj.copy(rejection_type = "PRE"))
      if (dlvRcgObj.aoi_invalid_dept == 0) {
        list.add(dlvRcgObj.copy(rejection_type = "REJECT_DEPT"))
        if (dlvRcgObj.aoi_invalid_address == 0) {
          list.add(dlvRcgObj.copy(rejection_type = "REJECT_DEPT_ADDR"))
        }
      }
      list.iterator()
    })

    logger.error(">>>指标按网点聚合")
    val dlvRcgRddZc = mergeDlvRcgByType(MergeType.zc, aoiRddFinal).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>指标按网点聚合:" + dlvRcgRddZc.count())
    logger.error(">>>指标按城市聚合")
    val dlvRcgRddCity = mergeDlvRcgIndexByType(MergeType.city, dlvRcgRddZc).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>指标按城市聚合:" + dlvRcgRddCity.count())
    logger.error(">>>指标按区聚合")
    val dlvRcgRddRegion = mergeDlvRcgIndexByType(MergeType.region, dlvRcgRddCity).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>指标按区聚合:" + dlvRcgRddRegion.count())
    logger.error(">>>指标按时间聚合")
    val dlvRcgRddDate = mergeDlvRcgIndexByType(MergeType.date, dlvRcgRddRegion).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>指标按时间聚合:" + dlvRcgRddDate.count())
    (dlvRcgRddDate, dlvRcgRddRegion, dlvRcgRddCity, dlvRcgRddZc)
  }

  def mergeDlvRcgByType(mergeType: MergeType, dlvRcgRdd: RDD[DlvRcgObj]): RDD[DlvRcgObj] = {
    val invalidRegion = Array[String]("", "香港区", "澳门区", "台湾区")
    if (mergeType.equals(MergeType.date)) {
      // 日期
      dlvRcgRdd.filter(obj => (obj.region != null
        && !invalidRegion.contains(obj.region))).map(obj => {
        (obj.stat_date, obj)
      }).reduceByKey((o1, o2) => {
        val mergeObj = mergeDlvRcgIndex(o1, o2)
        mergeObj.copy(region = "ALL", city = "ALL", zonecode = "ALL", city_code = "ALL")
      }).map(_._2)
    } else if (mergeType.equals(MergeType.region)) {
      //大区
      dlvRcgRdd.map(obj => {
        val key = Array(obj.stat_date, obj.region).mkString("_")
        (key, obj)
      }).reduceByKey((o1, o2) => {
        val mergeObj = mergeDlvRcgIndex(o1, o2)
        mergeObj.copy(city = "ALL", zonecode = "ALL", city_code = "ALL")
      }).map(_._2)
    } else if (mergeType.equals(MergeType.city)) {
      //城市
      dlvRcgRdd.map(obj => {
        val key = Array(obj.stat_date, obj.region, obj.city).mkString("_")
        (key, obj)
      }).reduceByKey((o1, o2) => {
        val mergeObj = mergeDlvRcgIndex(o1, o2)
        mergeObj.copy(zonecode = "ALL")
      }).map(_._2)
    } else if (mergeType.equals(MergeType.zc)) {
      //网点
      dlvRcgRdd.map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date, obj.region, obj.city, obj.zonecode).mkString("_")
        (key, obj)
      }).reduceByKey((o1, o2) => {
        mergeDlvRcgIndex(o1, o2)
      }).map(_._2)
    } else {
      null
    }
  }

  def mergeDlvRcgIndexByType(mergeType: MergeType, dlvRcgRdd: RDD[DlvRcgObj]): RDD[DlvRcgObj] = {
    val invalidRegion = Array[String]("", "香港区", "澳门区", "台湾区")
    var convertRdd: RDD[(String, DlvRcgObj)] = null
    if (mergeType.equals(MergeType.date)) {
      // 日期
      convertRdd = dlvRcgRdd.filter(obj => (obj.region != null
        && !invalidRegion.contains(obj.region))).map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date).mkString("_")
        val tmp = obj.copy(region = "ALL", city = "ALL", zonecode = "ALL", city_code = "ALL")
        (key, tmp)
      })
    } else if (mergeType.equals(MergeType.region)) {
      //大区
      convertRdd = dlvRcgRdd.map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date, obj.region).mkString("_")
        val tmp = obj.copy(city = "ALL", zonecode = "ALL", city_code = "ALL")
        (key, tmp)
      })
    } else if (mergeType.equals(MergeType.city)) {
      //城市
      convertRdd = dlvRcgRdd.map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date, obj.region, obj.city).mkString("_")
        val tmp = obj.copy(zonecode = "ALL")
        (key, tmp)
      })
    } else if (mergeType.equals(MergeType.zc)) {
      //网点
      convertRdd = dlvRcgRdd.map(obj => {
        val key = Array(obj.rejection_type, obj.stat_date, obj.region, obj.city, obj.zonecode).mkString("_")
        (key, obj)
      })
    } else {
      return null
    }
    convertRdd.reduceByKey((o1, o2) => {
      mergeDlvRcgIndex(o1, o2)
    }).map(_._2).sortBy(_.stat_date)
  }

  def mergeDlvRcgIndex(o1: DlvRcgObj, o2: DlvRcgObj): DlvRcgObj = {
    val stat_date = o1.stat_date
    val province = o1.province
    val region = o1.region
    val city = o1.city
    //    if(!checkValidCityData(city) && checkValidCityData(o2.city)){
    //      city = o2.city
    //    }
    val city_code = o1.city_code
    val zonecode = o1.zonecode
    val rejection_type = o1.rejection_type

    val req = o1.req + o2.req
    val gid = o1.gid + o2.gid
    val zc = o1.zc + o2.zc
    val zc_norm = o1.zc_norm + o2.zc_norm
    val zc_chkn = o1.zc_chkn + o2.zc_chkn
    val zc_chke = o1.zc_chke + o2.zc_chke
    val zc_phone = o1.zc_phone + o2.zc_phone
    val zc_road = o1.zc_road + o2.zc_road
    val zc_tc2 = o1.zc_tc2 + o2.zc_tc2
    val zc_auto = o1.zc_auto + o2.zc_auto
    val zc_normhp = o1.zc_normhp + o2.zc_normhp
    val zc_normcompany = o1.zc_normcompany + o2.zc_normcompany
    val tc = o1.tc + o2.tc
    val tc_norm = o1.tc_norm + o2.tc_norm
    val tc_chkn = o1.tc_chkn + o2.tc_chkn
    val tc_chke = o1.tc_chke + o2.tc_chke
    val tc_phone = o1.tc_phone + o2.tc_phone
    val tc_road = o1.tc_road + o2.tc_road
    val tc_tc2 = o1.tc_tc2 + o2.tc_tc2
    val tc_auto = o1.tc_auto + o2.tc_auto
    val tc_normhp = o1.tc_normhp + o2.tc_normhp
    val tc_normcompany = o1.tc_normcompany + o2.tc_normcompany
    val tc_sss = o1.tc_sss + o2.tc_sss
    val zc_gis_sss = o1.zc_gis_sss + o2.zc_gis_sss
    val zc_final = o1.zc_final + o2.zc_final
    val zc_sss = o1.zc_sss + o2.zc_sss
    val zc_arss = o1.zc_arss + o2.zc_arss
    val zc_arss_req = o1.zc_arss_req + o2.zc_arss_req
    val zc_arss_resp = o1.zc_arss_resp + o2.zc_arss_resp
    val tc_awsm = o1.tc_awsm + o2.tc_awsm
    val tc_awsm_req = o1.tc_awsm_req + o2.tc_awsm_req
    val tc_awsm_resp = o1.tc_awsm_resp + o2.tc_awsm_resp
    val notc = o1.notc + o2.notc
    val rcg_gis_zc_chkn_aos = o1.rcg_gis_zc_chkn_aos + o2.rcg_gis_zc_chkn_aos
    val rcg_gis_zc_chkn_aos_new_gid1 = o1.rcg_gis_zc_chkn_aos_new_gid1 + o2.rcg_gis_zc_chkn_aos_new_gid1
    val rcg_gis_zc_chkn_opt_sup = o1.rcg_gis_zc_chkn_opt_sup + o2.rcg_gis_zc_chkn_opt_sup
    val rcg_gis_zc_chkn_arss = o1.rcg_gis_zc_chkn_arss + o2.rcg_gis_zc_chkn_arss
    val rcg_gis_zc_chkn_cms = o1.rcg_gis_zc_chkn_cms + o2.rcg_gis_zc_chkn_cms
    val rcg_gis_zc_chkn_truth = o1.rcg_gis_zc_chkn_truth + o2.rcg_gis_zc_chkn_truth
    val rcg_gis_zc_chkn_truth_qs = o1.rcg_gis_zc_chkn_truth_qs + o2.rcg_gis_zc_chkn_truth_qs
    val rcg_gis_zc_chkn_aos_tc_init_gid_dj = o1.rcg_gis_zc_chkn_aos_tc_init_gid_dj + o2.rcg_gis_zc_chkn_aos_tc_init_gid_dj
    val rcg_gis_zc_chkn_aos_tc_init_gid_gj = o1.rcg_gis_zc_chkn_aos_tc_init_gid_gj + o2.rcg_gis_zc_chkn_aos_tc_init_gid_gj
    val rcg_gis_zc_chkn_script = o1.rcg_gis_zc_chkn_script + o2.rcg_gis_zc_chkn_script
    val rcg_gis_zc_chkn_sss = o1.rcg_gis_zc_chkn_sss + o2.rcg_gis_zc_chkn_sss
    val rcg_gis_zc_chkn_awsm = o1.rcg_gis_zc_chkn_awsm + o2.rcg_gis_zc_chkn_awsm
    val rcg_gis_zc_chkn_other = o1.rcg_gis_zc_chkn_other + o2.rcg_gis_zc_chkn_other
    val address_unknown = o1.address_unknown + o2.address_unknown
    val add_xy_cnt = o1.add_xy_cnt + o2.add_xy_cnt
    val add_xy_dept_match = o1.add_xy_dept_match + o2.add_xy_dept_match
    val add_xy_tc_match = o1.add_xy_tc_match + o2.add_xy_tc_match
    val aoi = o1.aoi + o2.aoi
    val aoi_req = o1.aoi_req + o2.aoi_req
    val aoi_re = o1.aoi_re + o2.aoi_re
    val aoi_suc = o1.aoi_suc + o2.aoi_suc
    val aoi_dept_error = o1.aoi_dept_error + o2.aoi_dept_error
    val aoi_address_unknown = o1.aoi_address_unknown + o2.aoi_address_unknown
    val ksReqCnt = o1.ksReqCnt + o2.ksReqCnt
    val ksResCnt = o1.ksResCnt + o2.ksResCnt
    val ksTcCnt = o1.ksTcCnt + o2.ksTcCnt
    val ksAoiCnt = o1.ksAoiCnt + o2.ksAoiCnt
    val ks_zc = o1.ks_zc + o2.ks_zc
    val auto_zc = o1.auto_zc + o2.auto_zc
    val ks_tc = o1.ks_tc + o2.ks_tc
    val total_tc = o1.total_tc + o2.total_tc
    val gis_aoi = o1.gis_aoi + o2.gis_aoi
    val ks_aoi = o1.ks_aoi + o2.ks_aoi
    val sys_aoi = o1.sys_aoi + o2.sys_aoi
    val rcg_gis_aoi_norm = o1.rcg_gis_aoi_norm + o2.rcg_gis_aoi_norm
    val rcg_gis_aoi_chkn = o1.rcg_gis_aoi_chkn + o2.rcg_gis_aoi_chkn
    val rcg_gis_aoi_chke = o1.rcg_gis_aoi_chke + o2.rcg_gis_aoi_chke
    val rcg_gis_aoi_phone = o1.rcg_gis_aoi_phone + o2.rcg_gis_aoi_phone
    val rcg_gis_aoi_road = o1.rcg_gis_aoi_road + o2.rcg_gis_aoi_road
    val rcg_gis_aoi_tc2 = o1.rcg_gis_aoi_tc2 + o2.rcg_gis_aoi_tc2
    val rcg_gis_aoi_auto = o1.rcg_gis_aoi_auto + o2.rcg_gis_aoi_auto
    val rcg_gis_aoi_normhp = o1.rcg_gis_aoi_normhp + o2.rcg_gis_aoi_normhp
    val rcg_gis_aoi_normcompany = o1.rcg_gis_aoi_normcompany + o2.rcg_gis_aoi_normcompany
    val rcg_gis_aoi_other = o1.rcg_gis_aoi_other + o2.rcg_gis_aoi_other
    val addresseeKeyWordFlag = o1.addresseeKeyWordFlag + o2.addresseeKeyWordFlag
    val aoiAreaCnt = o1.aoiAreaCnt + o2.aoiAreaCnt
    val transitCodeCnt = o1.transitCodeCnt + o2.transitCodeCnt
    val aoiTypeCnt = o1.aoiTypeCnt + o2.aoiTypeCnt
    val aoiChannelCnt = o1.aoiChannelCnt + o2.aoiChannelCnt

    val sysZc = o1.sys_zc + o2.sys_zc
    val ksOnlyAoi = o1.ks_only_aoi + o2.ks_only_aoi

    DlvRcgObj(rejection_type, stat_date, province, region, city, city_code, zonecode, req, gid, zc, zc_norm, zc_chkn, zc_chke, zc_phone,
      zc_road, zc_tc2, zc_auto, zc_normhp, zc_normcompany, tc, tc_norm, tc_chkn, tc_chke, tc_phone, tc_road, tc_tc2, tc_auto,
      tc_normhp, tc_normcompany, tc_sss, zc_gis_sss, zc_final, zc_sss, zc_arss, zc_arss_req, zc_arss_resp,
      tc_awsm, tc_awsm_req, tc_awsm_resp, notc, rcg_gis_zc_chkn_aos, rcg_gis_zc_chkn_aos_new_gid1, rcg_gis_zc_chkn_opt_sup,
      rcg_gis_zc_chkn_arss, rcg_gis_zc_chkn_cms, rcg_gis_zc_chkn_truth, rcg_gis_zc_chkn_truth_qs, rcg_gis_zc_chkn_aos_tc_init_gid_dj,
      rcg_gis_zc_chkn_aos_tc_init_gid_gj, rcg_gis_zc_chkn_script, rcg_gis_zc_chkn_sss, rcg_gis_zc_chkn_awsm, rcg_gis_zc_chkn_other,
      address_unknown, add_xy_cnt, add_xy_dept_match, add_xy_tc_match, aoi, aoi_req, aoi_re, aoi_suc, aoi_dept_error, aoi_address_unknown,
      ksReqCnt, ksResCnt, ksTcCnt, ksAoiCnt, ks_zc, auto_zc, ks_tc, total_tc, gis_aoi, ks_aoi, sys_aoi, addresseeKeyWordFlag,
      rcg_gis_aoi_norm, rcg_gis_aoi_chkn, rcg_gis_aoi_chke, rcg_gis_aoi_phone, rcg_gis_aoi_road, rcg_gis_aoi_tc2, rcg_gis_aoi_auto, rcg_gis_aoi_normhp,
      rcg_gis_aoi_normcompany, rcg_gis_aoi_other, aoiAreaCnt, transitCodeCnt, aoiTypeCnt, aoiChannelCnt, 0, 0, sysZc, ksOnlyAoi
    )
  }


  def updateBidInfo(obj: (JSONObject, DlvRcgObj, DlvAoiObj)) = {
    val bodyIndex = obj._1.getString("bodyIndex")
    val bidReBody = obj._1.getJSONObject("bidReBody")
    val bidReBodyBase = obj._1.getJSONObject("bidReBodyBase")
    val bidAoiState = JSONUtil.getJsonVal(obj._1, "bidAoiState", "")
    val addresseeAoiId = JSONUtil.getJsonVal(obj._1, "finalAoiId", "")
    //楼栋识别率
    var bidCollectCnt = 0
    var bidCollectRejectCnt = 0
    var bidCfCnt = 0
    var bidSysCnt = 0
    //基础
    var bidSysBaseCnt = 0
    var bidSysOk = 0
    var bidAoiidDiff = 0
    if (obj._3.aoi == 1 && !bidAoiState.isEmpty) {
      bidCollectCnt = 1
      if (!bidAoiState.equals("1")) {
        bidCollectRejectCnt = 1
        val buildingId = JSONUtil.getJsonVal(bidReBody, "result.buildingId", "")
        if (!buildingId.isEmpty) {
          bidCfCnt = 1
          val bidAoiidBase = JSONUtil.getJsonVal(bidReBodyBase, "result.aoiId", "")
          if (addresseeAoiId.equals(bidAoiidBase)) {
            bidSysBaseCnt = 1
          } else {
            bidAoiidDiff = 1
          }
          val bidAoiid = JSONUtil.getJsonVal(bidReBody, "result.aoiId", "")
          if (addresseeAoiId.equals(bidAoiid)) {
            bidSysCnt = 1
            val tmpLable = JSONUtil.getJsonVal(bidReBody, "result.label", "")
            if ("2".equals(tmpLable)) {
              bidSysOk = 1
            }
            ///***
            val tmpSource = JSONUtil.getJsonVal(bidReBody, "result.source", "")
            if ("DS_POI".equals(tmpSource)) {
              //底商来源的虚拟楼栋
              bidSysOk = 1
            }
            val geoPrecision = JSONUtil.getJsonVal(bidReBody, "result.geoPrecision", "")
            if (geoPrecision.isEmpty) {
              //底商来源的虚拟楼栋
              bidSysOk = 1
            }
            try {
              if (!geoPrecision.isEmpty && geoPrecision.toFloat > 94) {
                bidSysOk = 1
              }
            } catch {
              case e: Exception => logger.error("geoPrecision error:" + geoPrecision)
            }
          }
        }

      }
    }
    val bidSource = JSONUtil.getJsonVal(bidReBody, "result.source", "")
    val (bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping1, bidCfAoiMapping2, bidCfAoiSimilar, bidCfOther) = matchBidSource(bidSource, bidCfCnt, bodyIndex)
    val aoiObj = obj._3.copy(
      bidCollectCnt = bidCollectCnt,
      bidCollectRejectCnt = bidCollectRejectCnt,
      bidCfCnt = bidCfCnt, bidSysCnt = bidSysCnt,
      bidSysBaseCnt = bidSysBaseCnt, bidSysOk = bidSysOk,
      bidAoiidDiff = bidAoiidDiff, bidCfNorm = bidCfNorm,
      bidCfNormMultiGid = bidCfNormMultiGid, bidCfComapny = bidCfComapny,
      bidCfPhone = bidCfPhone, bidCfDsPoi = bidCfDsPoi,
      bidCfMinPoi = bidCfMinPoi, bidCfAoiMapping1 = bidCfAoiMapping1,
      bidCfAoiMapping2 = bidCfAoiMapping2, bidCfAoiSimilar = bidCfAoiSimilar,
      bidCfOther = bidCfOther
    )
    (JSONUtil.getJsonVal(obj._1, "waybillNo", ""),
      obj._2, aoiObj)
  }

  /**
   * 统计指标, 总数据
   *
   * @param rdd : 统计指标rdd
   */
  def statTotalIndex(rdd: RDD[JSONObject], spark: SparkSession,
                     incDay: String, taskCode: Int) = {
    val citycodeRegionMapBc = queryCityRegionMap(spark, incDay)
    logger.error(">>>统计指标")
    val invalidDeptSet = fetchInvalidDept(spark, incDay, taskCode)
    val deptCodeMap = fetDeptType(spark, incDay)
    val deptCodeMapBc: Broadcast[Map[String, String]] = spark.sparkContext.broadcast(deptCodeMap)
    //根据运单号排重
    val resultLog = rdd.map(obj => {
      //剔除垃圾字段
      val citycodeRegionMap = citycodeRegionMapBc.value
      val citycode = JSONUtil.getJsonVal(obj, "req_body.destCityCode", "")
      if (citycodeRegionMap.contains(citycode)) {
        obj.put("region", citycodeRegionMap(citycode)(0)(1))
        obj.put("city", citycodeRegionMap(citycode)(0)(2))
      }
      val (jObject, rcgObj, aoiObj, rcgObjDetail) = statRowIndex(obj, invalidDeptSet, incDay, deptCodeMapBc)
      (jObject, rcgObj, aoiObj, rcgObjDetail)
    }).filter(obj => obj._1 != null).persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error(">>>统计后解析数据量：" + resultLog.count())
    rdd.unpersist()
    val city2CityCodeMap = City2AdcodeMap.getCity2CityCodeMap
    var aoiEmptyRdd: RDD[(String, Int)] = null
    if (taskCode != 0) {
      aoiEmptyRdd = resultLog.filter(obj => {
        val gisAoiCode = JSONUtil.getJsonVal(obj._1, "gisAoiCode", "")
        val ksAoiCode = JSONUtil.getJsonVal(obj._1, "ksAoiCode", "")
        gisAoiCode.isEmpty && ksAoiCode.isEmpty
      }).repartition(60).map(obj => {
        (JSONUtil.getJsonVal(obj._1, "waybillNo", ""),
          OmsIndexStat.checkInvalidAddressNew(obj._1, city2CityCodeMap))
      }).filter(obj => obj._2 == 1).persist(StorageLevel.MEMORY_ONLY_SER_2)
      logger.error("aoi为空的数量：" + aoiEmptyRdd.count())
    }

    val detailRdd = resultLog.map(obj => obj._4).persist(StorageLevel.MEMORY_ONLY_SER_2)
    val targetRdd = resultLog.map(obj => (obj._1, obj._2, obj._3)).persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error("detailRdd:" + detailRdd.count())
    logger.error("targetRdd:" + targetRdd.count())
    resultLog.unpersist()
    detailRdd.unpersist()

    //save detail
    //    import spark.implicits._
    //    detailRdd.toDF().withColumn("inc_day", lit(incDay)).repartition(800).write.mode(SaveMode.Overwrite).insertInto("dm_gis.dlv_rcg_detail")
    //    detailRdd.unpersist()


    logger.error("获取楼栋范围aoiid数据")
    val joinBidRdd = joinBid(targetRdd, spark)
    logger.error("获取楼栋范围aoiid结束")
    val rowIndexRdd: RDD[(String, DlvRcgObj, DlvAoiObj)] = joinBidRdd.map(obj => {
      updateBidInfo(obj)
    }).persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error("指标转换完毕:" + rowIndexRdd.count())
    rowIndexRdd.take(1).foreach(o => println(o))
    //    joinBidRdd.unpersist()
    targetRdd.unpersist()
    (rowIndexRdd, aoiEmptyRdd)
  }

  def queryCityRegionMap(spark: SparkSession, date: String): Broadcast[Map[String, ArrayBuffer[Array[String]]]] = {
    val beforeDate = DateUtil.getDaysBefore(date, 1)
    //    val sql = "select area,region,city,citycode,province from dm_gis.city_name_map group by area,region,city,citycode,province "
    val sql = String.format("select region_name area,area_name region,dist_name city,dist_code citycode,prov_name province from dm_gis.dim_city_info_df where inc_day = '%s' group by area_name,region_name,dist_name,dist_code,prov_name", beforeDate)
    logger.error("拉取城市映射:" + sql)
    val dataList = spark.sql(sql).collect()
    logger.error("整体数据量:" + dataList.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    dataList.foreach(obj => {
      val item = Array(obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4))
      val cityCode = obj.getString(3)
      if (cityMap.contains(cityCode)) {
        val cityCodeList = cityMap.apply(cityCode)
        cityCodeList += item
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += item
        cityMap += (cityCode -> cityCodeList)
      }
    })
    spark.sparkContext.broadcast(cityMap)
  }

  def joinBid(resultLog: RDD[(JSONObject, DlvRcgObj, DlvAoiObj)],
              spark: SparkSession) = {
    val bidAoiInfoRdd = OmsIndexStat.fetchBidInfo(spark)
    logger.error("转化为hash值")
    val bidAoiBc = OmsIndexStat.convertBidAoi(spark, bidAoiInfoRdd)
    bidAoiInfoRdd.unpersist()
    val resultLogFinal = resultLog.map(obj => {
      val aoiId = JSONUtil.getJsonVal(obj._1, "finalAoiId", "")
      val hashValue = (aoiId.hashCode % 5000).toString
      val bidMap = bidAoiBc.value
      if (!aoiId.isEmpty && bidMap.contains(hashValue)) {
        val aoiidInfo = bidMap.get(hashValue).get
        if (aoiidInfo.contains(aoiId)) {
          obj._1.put("bidAoiState", aoiidInfo.get(aoiId).toString)
        }
      }
      obj
    })
    //    logger.error("打印一条bidAoistate不为空的")
    //    resultLogFinal.filter(obj=> obj._1.getString("bidAoiState")!=null).take(1).foreach(obj=>{
    //      logger.error(obj._1.toJSONString)
    //    })
    resultLogFinal
  }

  def remainObject(obj: JSONObject, addresseeAoiId: String,
                   bodyIndex: String, bidReBody: JSONObject,
                   bidReBodyBase: JSONObject) = {
    val ret = new JSONObject()
    ret.put("waybillNo", JSONUtil.getJsonVal(obj, "req_body.waybillNo", ""))
    ret.put("cityCode", JSONUtil.getJsonVal(obj, "req_body.destCityCode", ""))
    val address = (JSONUtil.getJsonVal(obj, "req_body.receiverProvince", "") +
      JSONUtil.getJsonVal(obj, "req_body.receiverCity", "") +
      JSONUtil.getJsonVal(obj, "req_body.receiverArea", "") +
      JSONUtil.getJsonVal(obj, "req_body.receiverAddr", "")).replaceAll("[\\r\\n\\t]", "")

    ret.put("address", address)
    ret.put("gisSrc", JSONUtil.getJsonVal(obj, "gis_to_sys_body.src", ""))
    ret.put("gisAoiCode", JSONUtil.getJsonVal(obj, "gisAoiCode", ""))

    ret.put("groupIds", obj.getString("groupIds"))
    ret.put("filters", obj.getString("filters"))
    ret.put("splitResult", obj.getString("splitResult"))

    val ksAoiCode = JSONUtil.getJsonVal(obj, "ks_re_body.result.aoiCode", "")
    ret.put("ksAoiCode", ksAoiCode)
    ret.put("finalAoiId", addresseeAoiId)
    ret.put("bodyIndex", bodyIndex)
    ret.put("bidReBody", bidReBody)
    ret.put("bidReBodyBase", bidReBodyBase)
    ret
  }

  def statRowIndex(obj: JSONObject,
                   invalidDeptSet: util.HashSet[String],
                   incDay: String,
                   deptCodeMapBc: Broadcast[Map[String, String]]):
  (JSONObject, DlvRcgObj, DlvAoiObj, DlvRcgDetail) = {
    var re: (JSONObject, DlvRcgObj, DlvAoiObj, DlvRcgDetail) = null
    try {
      val req, resp = 1
      var same_final, unsame_final, same_sss, unsame_sss, sss_isnull = 0
      //gis的指标
      var rcg, rcg_gis, rcg_sss, rcg_gis_sss, rcg_arss, arss_req, arss_resp, aoi_re, gis_final_unsame, gis_final_same, gis_sss_unsame, gis_sss_unsame_gis, gis_sss_unsame_sss, gis_sss_same, sss_final_unsame, sss_final_same, sss_arss_unsame, sss_arss_same = 0
      //地址不详相关的数据
      var address_unknown, add_xy_cnt, add_xy_dept_match, add_xy_tc_match = 0
      val province = obj.getString("province")
      val region = obj.getString("region")
      val city = obj.getString("city")
      //===oms请求的数据===
      val req_body = obj.getJSONObject("req_body")
      //noinspection ScalaUnusedSymbol
      val city_code = req_body.getString("destCityCode")

      val gis_to_sys_body = obj.getJSONObject("gis_to_sys_body") //===接口返回的数据===
      var sysSrc: String = null
      var status = "UNRESP" //默认gis无返回
      var status_detail = "-"
      var gisDeptCodeTo = "-"
      var sssDeptCodeTo = "-"
      var gisTeamCodeTo = "-"
      var isGisDeptMatch = false
      var isSssDeptMatch = false
      var isGisTcMatch = false
      var isSssTcMatch = false

      val atpai_body = obj.getJSONObject("atpai_body")
      var notcFlag = "0"
      var chkDeptSrc = ""
      var precision = ""
      var groupIds: Array[String] = null
      var tcs: JSONArray = null
      var aoiSrc = ""
      if (atpai_body != null) {
        notcFlag = obj.getString("notc")
        groupIds = obj.getString("groupIds").split(Constant.SEP)
        chkDeptSrc = obj.getString("chkDeptSrc")
        precision = obj.getString("precision")
        tcs = atpai_body.getJSONArray("tcs")
        aoiSrc = obj.getString("gisAoiSrc")
      }
      // gis aoi
      var gis_aoi = 0
      if (tcs != null && tcs.size() != 0) {
        val tcsObj = tcs.getJSONObject(0)
        val aoicode = tcsObj.getString("aoicode")
        if (aoicode != null && !aoicode.isEmpty) {
          gis_aoi = 1
        }
      }
      var rcg_gis_aoi_norm, rcg_gis_aoi_chkn, rcg_gis_aoi_chke, rcg_gis_aoi_phone, rcg_gis_aoi_road, rcg_gis_aoi_tc2, rcg_gis_aoi_auto, rcg_gis_aoi_normhp, rcg_gis_aoi_normcompany, rcg_gis_aoi_other = 0
      var gis_to_sys_zc_exist = false
      var gis_tc_exist = true
      var gis_team_exist = false
      var gisZC: String = null
      var sssZC: String = null
      if (gis_to_sys_body != null) {
        status = "RESP"
        //gis有返回，为null或不可识别
        gisZC = gis_to_sys_body.getString("gisDeptCodeTo")
        sssZC = gis_to_sys_body.getString("sssDeptCodeTo")
        if ((gisZC != null && !gisZC.isEmpty) || (sssZC != null && !sssZC.isEmpty)) {
          gis_to_sys_zc_exist = true
        }
        val gisTC = gis_to_sys_body.getString("gisTeamCodeTo")
        val sssTC = gis_to_sys_body.getString("sssTeamCodeTo")
        if (gisZC != null && !gisZC.isEmpty && (gisTC == null || gisTC.isEmpty)) {
          gis_tc_exist = false
        }
        if (gisTC != null && !gisTC.isEmpty) {
          gis_team_exist = true
        }
        sysSrc = gis_to_sys_body.getString("deptToRetBy")
        if (sssZC == null || sssZC.equals("")) sss_isnull = 1 //sss为空的量
        isGisDeptMatch = (gisZC != null) && gisZC.matches("^[0-9]+[a-zA-Z]+[0-9]*$")
        if (gisZC != null) {
          rcg_gis = 1 //GIS识别量
          if (gis_to_sys_body.getString("src") != null) status_detail = gis_to_sys_body.getString("src").toUpperCase
        }
        if (isGisDeptMatch) {
          gisDeptCodeTo = gisZC
          status = "REC" //gis有返回且可识别
          //          rcg_gis = 1 //GIS识别量
          //          if (gis_to_sys_body.getString("src") != null) status_detail = gis_to_sys_body.getString("src").toUpperCase
        }
        isSssDeptMatch = (sssZC != null) && sssZC.matches("^[0-9]+[A-Z]+[0-9]*$")
        if (sssZC != null) rcg_sss = 1
        if (isSssDeptMatch) {
          sssDeptCodeTo = sssZC
          //          rcg_sss = 1 //SSS识别量
        }
        //        if (isGisDeptMatch || isSssDeptMatch) rcg_gis_sss = 1 //GIS_SSS识别量
        if (gisZC != null || sssZC != null) rcg_gis_sss = 1 //GIS_SSS识别量
        isGisTcMatch = (gisTC != null) && gisTC.matches("^[0-9]+[A-Z]+[0-9]+$") && !gisTC.endsWith("999")
        isSssTcMatch = (sssTC != null) && sssTC.matches("^[0-9]+[A-Z]+[0-9]+$") && !sssTC.endsWith("999")
        if (isGisTcMatch) gisTeamCodeTo = gisTC
      }

      if (isGisDeptMatch && isSssDeptMatch) {
        if (gisDeptCodeTo.equals(sssDeptCodeTo)) {
          same_sss = 1 //gis与sss结果一致
        } else {
          unsame_sss = 1 //gis与sss结果不一致
        }
      }
      var aoi_req = 0
      val arss_dept_req_array = obj.getJSONArray("arss_dept_req_array") //===网点进审补的数据===
      val taskType = ArrayBuffer[String]()
      if (arss_dept_req_array != null && arss_dept_req_array.size() > 0) {
        for (i <- 0 until arss_dept_req_array.size()) {
          val item = arss_dept_req_array.getJSONObject(i)
          taskType.append(item.getString("taskType"))
        }

        if (taskType.nonEmpty && (taskType.contains("2") || taskType.contains("9"))) {
          arss_req = 1 // 网点进审补量
        }

        if (taskType.nonEmpty && (taskType.contains("2") || taskType.contains("9") || taskType.contains("19"))) {
          aoi_req = 1
        }

      }


      //取出arss_dept_re_array 中 arss_dept_re_time最大值对应的empCode
      var empCode = ""
      var arss_dept_re_time = ""
      var aoiid = ""
      var identRs = ""
      val arss_dept_re_array = obj.getJSONArray("arss_dept_re_array")
      if (arss_dept_re_array != null && arss_dept_re_array.size() != 0) {
        for (i <- 0 until arss_dept_re_array.size()) {
          val item = arss_dept_re_array.getJSONObject(i)
          val temp_arss_dept_re_time = item.getString("arss_dept_re_time")
          val temp_empCode = item.getString("empCode")
          val temp_aoiid = item.getString("aoiId")
          val temp_identRs = item.getString("identRs")
          if (arss_dept_re_time == "") {
            arss_dept_re_time = temp_arss_dept_re_time
            empCode = temp_empCode
            aoiid = temp_aoiid
            identRs = temp_identRs
          } else if (temp_arss_dept_re_time > arss_dept_re_time) {
            arss_dept_re_time = temp_arss_dept_re_time
            empCode = temp_empCode
            aoiid = temp_aoiid
            identRs = temp_identRs
          }
        }
      }

      if (taskType.nonEmpty && (taskType.contains("2") || taskType.contains("9")) && StringUtils.isNotEmpty(identRs)) {
        rcg_arss = 1
      }

      val arss_dept_re_body = obj.getJSONObject("arss_dept_re_body") //===网点审补返回的数据===
      var isSssArssDeptSuc: Boolean = false //审补网点是否有效
      var sssArssDept: String = null

      if (arss_req == 1 && StringUtils.isNotEmpty(empCode)) {
        arss_resp = 1 // 网点审补返回量
      }

      if (taskType.nonEmpty && (taskType.contains("2") || taskType.contains("9") || taskType.contains("19")) && StringUtils.isNotEmpty(empCode)) {
        aoi_re = 1
      }


      if (arss_dept_re_body != null) {
        //        arss_resp = 1 // 网点审补返回量
        //        arss_req = 1
        sssArssDept = arss_dept_re_body.getString("identRs")
        if (sssArssDept != null) {
          //          rcg_arss = 1
          isSssArssDeptSuc = sssArssDept.matches("^[0-9]+[A-Z]+[0-9]*$")
        }
        //        if (isSssArssDeptSuc) rcg_arss = 1 // 网点成功审补量
        val cancelReasonCode = arss_dept_re_body.getString("cancelReasonCode")
        if (cancelReasonCode != null && !cancelReasonCode.equals("") && cancelReasonCode.equals("1")) address_unknown = 1 //85 发给用户地址不详的票数
      }

      //计算最终网点
      if (gisZC != null || sssZC != null || (taskType.nonEmpty && (taskType.contains("2") || taskType.contains("9")) && StringUtils.isNotEmpty(identRs))) rcg = 1 //最终网点识别量
      //      if (isGisDeptMatch || isSssDeptMatch || isSssArssDeptSuc) rcg = 1 //最终网点识别量

      var awsm_req, awsm_resp, rcg_awsm = 0
      val awsm_dept_req_body = obj.getJSONObject("awsm_tc_req_body") //===单元区域进审补的数据===
      if (awsm_dept_req_body != null) awsm_req = 1 // 单元区域进审补量

      val awsm_tc_re_body = obj.getJSONObject("awsm_tc_re_body") //===AWSM审补结果====
      var awsm_arss_tc: String = null
      var awsmArssDept: String = null
      var isAwsmArssTcSuc: Boolean = false //awsm单元区域审补是否有效
      var isAwsmArssDeptSuc: Boolean = false //awsm网点审补是否有效
      if (awsm_tc_re_body != null) {
        awsm_resp = 1
        awsm_req = 1
        awsm_arss_tc = awsm_tc_re_body.getString("teamCode")
        awsmArssDept = awsm_tc_re_body.getString("deptCode")
        if (awsm_arss_tc != null) isAwsmArssTcSuc = awsm_arss_tc.matches("^[0-9]+[A-Z]+[0-9]+$") && !awsm_arss_tc.endsWith("999")
        if (awsmArssDept != null) isAwsmArssDeptSuc = awsmArssDept.matches("^[0-9]+[A-Z]+[0-9]*$")
        if (isAwsmArssTcSuc) rcg_awsm = 1 // 网点成功审补量

        val dataType = awsm_tc_re_body.getString("dataType")
        if (dataType != null && !dataType.equals("") && dataType.equals("6")) {
          add_xy_cnt = 1 //86 awsm返回的数据，用户补了经纬度的
        }
      }
      val geo_body = obj.getJSONObject("geo_body") //===地址不详 地理编码返回的数据
      var isGeoDeptCodeMatch: Boolean = false
      var isGeoTeamCodeMatch: Boolean = false

      if (geo_body != null) {
        val addresseeDeptCode = geo_body.getString("addresseeDeptCode")
        val addresseeTeamCode = geo_body.getString("addresseeTeamCode")
        if (addresseeDeptCode != null) isGeoDeptCodeMatch = addresseeDeptCode.matches("^[0-9]+[A-Z]+$")
        if (isGeoDeptCodeMatch) {
          add_xy_dept_match = 1 //87 返回geo的数据中，网点可以识别
          //          gis_sss_dept_match_add =1 //89 gis_sss网点识别量+geo返回网点可识别的
        }
        if (addresseeTeamCode != null) isGeoTeamCodeMatch = addresseeTeamCode.matches("^[0-9]+[A-Z]+[0-9]+$")
        if (isGeoTeamCodeMatch) {
          add_xy_tc_match = 1 //88 返回的geo数据中 单元区域可识别的
          //          gis_tc_match_add = 1 //90 gis单元区域识别量+geo返回的tc可识别的量
        }

      }
      //      val finalTp = getFinalZc(isSssArssDeptSuc, sssArssDept, sysSrc, isGisDeptMatch, gisDeptCodeTo, isSssDeptMatch, sssDeptCodeTo)
      //      val finalZc = finalTp._1
      //      val finalZcBy = finalTp._2
      //      val re_body_array = obj.getJSONArray("re_body")
      //      val re_body_item = OmsDayIndexMain.getLatestBody(re_body_array, "datetime")

      val re_body_item = obj.getJSONObject("re_body_item")
      var finalZc = JSONUtil.getJsonVal(re_body_item, "addresseeDeptCode", "")
      if (StringUtils.isNotEmpty(finalZc)) {
        finalZc = finalZc.replaceAll("\t", "")
      }
      val finalZcBy = JSONUtil.getJsonVal(re_body_item, "src", "")
      val addresseeAoiChannel = JSONUtil.getJsonVal(re_body_item, "addresseeAoiChannel", "")
      var aoiChannelCnt = 0
      if (!addresseeAoiChannel.isEmpty) {
        aoiChannelCnt = 1
      }
      //中转场代码识别指标
      val addresseeTransitCode = JSONUtil.getJsonVal(re_body_item, "addresseeTransitCode", "")
      var transitCodeCnt = 0
      if (!addresseeTransitCode.isEmpty) {
        transitCodeCnt = 1
      }
      //AOI类型识别指标
      val addresseeAoiType = JSONUtil.getJsonVal(re_body_item, "addresseeAoiType", "")
      var aoiTypeCnt = 0
      if (!addresseeAoiType.isEmpty) {
        aoiTypeCnt = 1
      }

      val addresseeAoiArea = JSONUtil.getJsonVal(re_body_item, "addresseeAoiArea", "")
      var aoiAreaCnt = 0
      if (!addresseeAoiArea.isEmpty) {
        aoiAreaCnt = 1
      }
      //最终网点有效
      val isFinalZcMatch = !finalZc.equals("-")


      //最终单元区域计算,计算顺序 awsm gis
      //
      //      if (isAwsmArssTcSuc) {
      //        finalTc = awsm_arss_tc
      //      } else if (isGisTcMatch) {
      //        finalTc = gisTeamCodeTo
      //      }
      //noinspection ScalaUnusedSymbol
      //最终单元区域有效
      //      val isFinalTcMatch = !finalTc.equals("")

      if (isGisDeptMatch && isFinalZcMatch) {
        if (gisDeptCodeTo.equals(finalZc)) {
          same_final = 1 //gis和最终网点一致
          gis_final_same = 1

        } else {
          unsame_final = 1 ////gis和最终网点不一致
          gis_final_unsame = 1
        }
      }
      if (isGisDeptMatch && isSssDeptMatch) {
        if (gisDeptCodeTo.equals(sssDeptCodeTo)) {
          gis_sss_same = 1 //gis和sss网点一致
        } else {
          gis_sss_unsame = 1 //gis和sss网点不一致
          if (finalZcBy.equals("gis")) gis_sss_unsame_gis = 1 //GIS和SSS不一致时来源于GIS的量'
          if (finalZcBy.equals("sss")) gis_sss_unsame_sss = 1 //GIS和SSS不一致时来源于SSS的量'
        }
      }

      if (isSssDeptMatch && isFinalZcMatch) {
        if (sssDeptCodeTo.equals(finalZc)) {
          sss_final_same = 1 //sss和最终网点一致
        } else {
          sss_final_unsame = 1 //sss和最终网点不一致
        }
      }

      if (isSssDeptMatch && isSssArssDeptSuc) {
        if (sssDeptCodeTo.equals(sssArssDept)) {
          sss_arss_same = 1 //SSS和审补不一致量'
        } else {
          sss_arss_unsame = 1 //SSS和审补一致量
        }
      }


      var rcg_gis_zc_norm, rcg_gis_zc_chkn, rcg_gis_zc_chke, rcg_gis_zc_phone, rcg_gis_zc_road, rcg_gis_zc_tc2, rcg_gis_zc_auto, rcg_gis_zc_normhp, rcg_gis_zc_normcompany = 0
      val rcg_gis_zc_chkn_detail = scala.collection.mutable.Map("aos" -> 0, "aos_new_gid1" -> 0, "opt_sup" -> 0, "arss" -> 0, "cms" -> 0, "truth" -> 0, "truth_qs" -> 0,
        "aos_tc_init_gid_dj" -> 0, "aos_tc_init_gid_gj" -> 0, "script" -> 0, "sss" -> 0, "awsm" -> 0, "other" -> 0)
      var gid, rcg_gis_tc, rcg_gis_tc_norm, rcg_gis_tc_chkn, rcg_gis_tc_chke, rcg_gis_tc_phone, rcg_gis_tc_road, rcg_gis_tc_tc2, rcg_gis_tc_auto, rcg_gis_tc_normhp, rcg_gis_tc_normcompany, notc = 0
      var rcg_sss_tc = 0
      if (rcg_gis == 1) {
        status_detail match {
          case "NORM" => rcg_gis_zc_norm = 1
          case "CHKN" => rcg_gis_zc_chkn = 1
          case "CHKE" => rcg_gis_zc_chke = 1
          //          case "PHONE" => rcg_gis_zc_phone = 1
          case "ROAD" => rcg_gis_zc_road = 1
          case "TC2" => rcg_gis_zc_tc2 = 1
          case "AUTO" => rcg_gis_zc_auto = 1
          //          case "NORMHP" => rcg_gis_zc_normhp = 1
          case "NORMCOMPANY" => rcg_gis_zc_normcompany = 1
          case _ =>
        }

        if (StringUtils.isNotEmpty(status_detail) && status_detail.contains("PHONE")) {
          rcg_gis_zc_phone = 1
        }

        if (StringUtils.isNotEmpty(status_detail) && status_detail.contains("NORMHP")) {
          rcg_gis_zc_normhp = 1
        }
      }

      if (isGisDeptMatch && status_detail.equals("CHKN")) {
        chkDeptSrc match {
          case "aos" | "aos_new_gid1" | "arss" | "cms" | "truth"
               | "truth_qs" | "script" | "sss" | "awsm" =>
            rcg_gis_zc_chkn_detail.update(chkDeptSrc, 1)
          case "opt_sup" | "opt" =>
            rcg_gis_zc_chkn_detail.update("opt_sup", 1)
          case "aos_tc_init_gid_update" | "aos_tc_init_gid" =>
            if (precision.equals("2")) {
              rcg_gis_zc_chkn_detail.update("aos_tc_init_gid_dj", 1)
            } else if (precision.equals("1") || precision.equals("0")) {
              rcg_gis_zc_chkn_detail.update("aos_tc_init_gid_gj", 1)
            } else {
              rcg_gis_zc_chkn_detail.update("other", 1)
            }
          case _ =>
            rcg_gis_zc_chkn_detail.update("other", 1)
        }
      }
      if (isGisTcMatch) {
        rcg_gis_tc = 1
        status_detail match {
          case "NORM" => rcg_gis_tc_norm = 1
          case "CHKN" => rcg_gis_tc_chkn = 1
          case "CHKE" => rcg_gis_tc_chke = 1
          case "PHONE" => rcg_gis_tc_phone = 1
          case "ROAD" => rcg_gis_tc_road = 1
          case "TC2" => rcg_gis_tc_tc2 = 1
          case "AUTO" => rcg_gis_tc_auto = 1
          case "NORMHP" => rcg_gis_tc_normhp = 1
          case "NORMCOMPANY" => rcg_gis_tc_normcompany = 1
          case _ =>
        }
      } else {
        if ("1".equals(notcFlag))
          notc = 1
      }
      if (groupIds != null && groupIds.length > 0) {
        for (i <- 0 until groupIds.length) {
          val groupId = groupIds(i)
          if (groupId != null && !"".equals(groupId)) {
            gid = 1
          }
        }
      }
      //aoi数据信息
      //      val re_body_array = obj.getJSONArray("re_body") //
      var aoi_ok = 0
      var ks_zc = 0
      var ks_tc = 0
      var ks_aoi = 0

      var addresseeKeyWordFlag = 0
      var addresseeBuildingIdFlag = 0
      val addresseeBuildingId = JSONUtil.getJsonVal(re_body_item, "addresseeBuildingId", "")
      if (!addresseeBuildingId.isEmpty) {
        addresseeBuildingIdFlag = 1
      }
      val addresseeAoiCode = JSONUtil.getJsonVal(re_body_item, "addresseeAoiCode", "")
      val addresseeAoiId = JSONUtil.getJsonVal(re_body_item, "addresseeAoiId", "")
      if (!addresseeAoiCode.isEmpty) {
        aoi_ok = 1
      }
      var finalTc: String = JSONUtil.getJsonVal(re_body_item, "addresseeTeamCode", "")
      //香港特殊化操作
      val hkAOiOk = specialHk(city_code, addresseeAoiId, addresseeAoiArea, finalTc)
      if (hkAOiOk) {
        aoi_ok = 1
      }
      val src = JSONUtil.getJsonVal(re_body_item, "src", "")
      if (gis_aoi == 0 && "gis".equals(src) && !addresseeAoiCode.isEmpty) {
        gis_aoi = 1
        rcg_gis_aoi_other = 1
      }

      var type_code = ""
      if (StringUtils.isNotEmpty(finalZc)) {
        type_code = deptCodeMapBc.value.getOrDefault(finalZc, "")
      }
      val hkAoiOkNew = specialHk_new(city_code, addresseeAoiId, addresseeAoiArea, finalTc)
      if (("852".equals(city_code) && "gis,sss,gis_sss".split(",").contains(src) && StringUtils.isNotEmpty(type_code)) || hkAoiOkNew) {
        gis_aoi = 1
      }

      if (gis_aoi == 1) {
        var gis_aoi_src = aoiSrc
        if (gis_aoi_src == null) {
          gis_aoi_src = ""
        }
        gis_aoi_src = gis_aoi_src.toUpperCase
        gis_aoi_src match {
          case "NORM" => rcg_gis_aoi_norm = 1
          case "CHKN" => rcg_gis_aoi_chkn = 1
          case "CHKE" => rcg_gis_aoi_chke = 1
          //          case "PHONE" => rcg_gis_aoi_phone = 1
          case "ROAD" => rcg_gis_aoi_road = 1
          case "TC2" => rcg_gis_aoi_tc2 = 1
          case "AUTO" => rcg_gis_aoi_auto = 1
          //          case "NORMHP" => rcg_gis_aoi_normhp = 1
          case "NORMCOMPANY" => rcg_gis_aoi_normcompany = 1
          case _ => rcg_gis_aoi_other = 1
        }

        if (StringUtils.isNotEmpty(gis_aoi_src) && gis_aoi_src.contains("PHONE")) {
          rcg_gis_aoi_phone = 1
        }

        if (StringUtils.isNotEmpty(gis_aoi_src) && gis_aoi_src.contains("NORMHP")) {
          rcg_gis_aoi_normhp = 1
        }
      }

      if (gis_aoi == 0 && "ks".equals(src) && !addresseeAoiCode.isEmpty) {
        ks_aoi = 1
      }
      val addresseeDeptCode = JSONUtil.getJsonVal(re_body_item, "addresseeDeptCode", "")

      var dept = ""
      try {
        dept = obj.getJSONObject("ks_re_body").getJSONObject("result").getString("dept")
      } catch {
        case e: Exception => logger.error("get dept error")
      }
      if ((!gis_to_sys_zc_exist && "ks".equals(src) && !addresseeDeptCode.isEmpty) || (StringUtils.isNotEmpty(dept))) {
        ks_zc = 1
      }
      val addresseeTeamCode = JSONUtil.getJsonVal(re_body_item, "addresseeTeamCode", "")
      if ((!gis_to_sys_zc_exist || !gis_tc_exist) && "ks".equals(src) && !addresseeTeamCode.isEmpty) {
        ks_tc = 1
      }
      val addresseeKeyWord = JSONUtil.getJsonVal(re_body_item, "addresseeKeyWord", "")
      if (!addresseeKeyWord.isEmpty) {
        addresseeKeyWordFlag = 1
      }

      //楼栋识别率
      var bidCollectCnt = 0
      var bidCollectRejectCnt = 0
      var bidCfCnt = 0
      var bidSysCnt = 0
      //基础
      var bidSysBaseCnt = 0
      var bidSysOk = 0
      var bidAoiidDiff = 0

      // bid业务等关联bid数据后,重新计算,此处先占个坑
      val (body_index, bid_re_body, bid_re_body_base) = queryBidReBody(obj, addresseeAoiId)
      val bidAoiState = JSONUtil.getJsonVal(obj, "bidAoiState", "")
      if (aoi_ok == 1 && !bidAoiState.isEmpty) {
        bidCollectCnt = 1
        if (!bidAoiState.equals("1")) {
          bidCollectRejectCnt = 1
          val buildingId = JSONUtil.getJsonVal(bid_re_body, "result.buildingId", "")
          if (!buildingId.isEmpty) {
            bidCfCnt = 1
            val bidAoiidBase = JSONUtil.getJsonVal(bid_re_body_base, "result.aoiId", "")
            if (addresseeAoiId.equals(bidAoiidBase)) {
              bidSysBaseCnt = 1
            } else {
              bidAoiidDiff = 1
            }
            val bidAoiid = JSONUtil.getJsonVal(bid_re_body, "result.aoiId", "")
            if (addresseeAoiId.equals(bidAoiid)) {
              bidSysCnt = 1
              val tmpLable = JSONUtil.getJsonVal(bid_re_body, "result.label", "")
              if ("2".equals(tmpLable)) {
                bidSysOk = 1
              }
              ///***
              val tmpSource = JSONUtil.getJsonVal(bid_re_body, "result.source", "")
              if ("DS_POI".equals(tmpSource)) {
                //底商来源的虚拟楼栋
                bidSysOk = 1
              }
              val geoPrecision = JSONUtil.getJsonVal(bid_re_body, "result.geoPrecision", "")
              if (geoPrecision.isEmpty) {
                //底商来源的虚拟楼栋
                bidSysOk = 1
              }
              try {
                if (!geoPrecision.isEmpty && geoPrecision.toFloat > 94) {
                  bidSysOk = 1
                }
              } catch {
                case e: Exception => logger.error("geoPrecision error:" + geoPrecision)
              }
            }
            //            else {
            //              bidAoiidDiff = 1
            //            }
          }

        }
      }
      val bidSource = JSONUtil.getJsonVal(bid_re_body, "result.source", "")
      val (bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping1, bidCfAoiMapping2, bidCfAoiSimilar, bidCfOther) = matchBidSource(bidSource, bidCfCnt, body_index)


      //解析ks审补数据
      val ksReBody = obj.getJSONObject("ks_req_body")
      //ks请求量
      var ksReqCnt = 0
      if (ksReBody != null) {
        ksReqCnt = 1
      }
      val ksResBody = obj.getJSONObject("ks_re_body")
      //ks响应量
      var ksResCnt, ksTcCnt = 0
      if (ksResBody != null) {
        ksReqCnt = 1
        ksResCnt = 1
        val ksResult = ksResBody.getJSONObject("result")
        if (ksResult != null) {
          val ksTc = ksResult.getString("tc")
          if (ksTc != null && !ksTc.isEmpty) {
            ksTcCnt = 1
          }
          val ksAoiCode = ksResult.getString("aoiCode")
          if (ksAoiCode != null && !ksAoiCode.isEmpty) {
            ks_aoi = 1
          }
        }

      }

      // 自动识别量：gis， sss, ks
      var auto_zc = 0
      //新增  ZC_系统识别量
      var sys_zc = 0
      var total_tc = 0
      var sys_aoi = 0
      if (ks_zc == 1 || gis_to_sys_zc_exist) {
        auto_zc = 1
        sys_zc = 1
      }
      // 最终识别量增加ks统计
      if (ks_zc == 1) {
        rcg = 1
      }
      if (ks_tc == 1 || gis_team_exist) {
        total_tc = 1
      }
      if (gis_aoi == 1 || ks_aoi == 1) {
        sys_aoi = 1
        aoi_ok = 1
      }
      //gis_aoi不存在时,ks识别到的量
      var ks_only_aoi = 0
      //dlv_rcg 中新增 ks_only_aoi
      if (sys_aoi == 1 && gis_aoi == 0) {
        ks_only_aoi = 1
      }
      val aoi_dept_req_body = obj.getJSONArray("aoi_dept_req_body")

      if (aoi_dept_req_body != null && aoi_dept_req_body.size() != 0) {
        //aoi请求，取一条
        aoi_req = 1
      }

      val aoi_dept_re_body = obj.getJSONArray("aoi_dept_re_body")
      var aoi_suc, aoi_dept_error, aoi_address_unknown = 0


      if (aoi_dept_re_body != null && aoi_dept_re_body.size() != 0) {
        //aoi响应 取最后时间的那条
        aoi_re = 1
        aoi_req = 1
        var aoi_data_type = ""
        var aoi_time = ""
        for (i <- 0 until aoi_dept_re_body.size()) {
          val aoi_dept_re_item = aoi_dept_re_body.getJSONObject(i)
          val tmp_aoi_time = aoi_dept_re_item.getString("aoi_dept_re_time")
          val tmp_aoi_data_type = aoi_dept_re_item.getString("dataType")
          if (aoi_time == "") {
            aoi_time = tmp_aoi_time
            aoi_data_type = tmp_aoi_data_type
          } else if (tmp_aoi_time > aoi_time) {
            aoi_time = tmp_aoi_time
            aoi_data_type = tmp_aoi_data_type
          }
        }
        if (aoi_data_type.equals("1")) {
          aoi_suc = 1
          aoi_ok = 1
        } else if (aoi_data_type.equals("5")) {
          aoi_dept_error = 1
        } else if (aoi_data_type.equals("8")) {
          aoi_address_unknown = 1
        }
      }

      if (taskType.nonEmpty && (taskType.contains("2") || taskType.contains("9") || taskType.contains("19")) && StringUtils.isNotEmpty(aoiid)) {
        aoi_suc = 1
        aoi_ok = 1
      }


      rcg_sss_tc = if (isSssTcMatch) 1 else 0
      val invalidDept = checkInvalidDept(finalZc, invalidDeptSet)

      val rcgObj = Obj.DlvRcgObj("", incDay, province, region, city, city_code, finalZc, req, gid, rcg_gis,
        rcg_gis_zc_norm, rcg_gis_zc_chkn, rcg_gis_zc_chke, rcg_gis_zc_phone, rcg_gis_zc_road, rcg_gis_zc_tc2,
        rcg_gis_zc_auto, rcg_gis_zc_normhp, rcg_gis_zc_normcompany, rcg_gis_tc, rcg_gis_tc_norm, rcg_gis_tc_chkn,
        rcg_gis_tc_chke, rcg_gis_tc_phone, rcg_gis_tc_road, rcg_gis_tc_tc2, rcg_gis_tc_auto, rcg_gis_tc_normhp,
        rcg_gis_tc_normcompany, rcg_sss_tc, rcg_gis_sss, rcg, rcg_sss, rcg_arss, arss_req, arss_resp,
        rcg_awsm, awsm_req, awsm_resp, notc, rcg_gis_zc_chkn_detail("aos"), rcg_gis_zc_chkn_detail("aos_new_gid1"),
        rcg_gis_zc_chkn_detail("opt_sup"), rcg_gis_zc_chkn_detail("arss"), rcg_gis_zc_chkn_detail("cms"), rcg_gis_zc_chkn_detail("truth"),
        rcg_gis_zc_chkn_detail("truth_qs"), rcg_gis_zc_chkn_detail("aos_tc_init_gid_dj"), rcg_gis_zc_chkn_detail("aos_tc_init_gid_gj"),
        rcg_gis_zc_chkn_detail("script"), rcg_gis_zc_chkn_detail("sss"), rcg_gis_zc_chkn_detail("awsm"), rcg_gis_zc_chkn_detail("other"),
        address_unknown, add_xy_cnt, add_xy_dept_match, add_xy_tc_match, aoi_ok, aoi_req, aoi_re, aoi_suc, aoi_dept_error, aoi_address_unknown,
        ksReqCnt, ksResCnt, ksTcCnt, ks_aoi, ks_zc, auto_zc, ks_tc, total_tc, gis_aoi, ks_aoi, sys_aoi, addresseeKeyWordFlag,
        rcg_gis_aoi_norm, rcg_gis_aoi_chkn, rcg_gis_aoi_chke, rcg_gis_aoi_phone, rcg_gis_aoi_road, rcg_gis_aoi_tc2, rcg_gis_aoi_auto, rcg_gis_aoi_normhp,
        rcg_gis_aoi_normcompany, rcg_gis_aoi_other, aoiAreaCnt, transitCodeCnt, aoiTypeCnt, aoiChannelCnt, 0, invalidDept, sys_zc, ks_only_aoi
      )

      val req_waybillno = obj.getString("req_waybillno")
      val req_time = obj.getString("req_time")

      val rcgObjDetail = DlvRcgDetail(req_waybillno, req_time, "", incDay, province, region, city, city_code, finalZc, req, gid, rcg_gis, rcg_gis_zc_norm,
        rcg_gis_zc_chkn, rcg_gis_zc_chke, rcg_gis_zc_phone, rcg_gis_zc_road, rcg_gis_zc_tc2, rcg_gis_zc_auto, rcg_gis_zc_normhp, rcg_gis_zc_normcompany, rcg_gis_tc, rcg_gis_tc_norm, rcg_gis_tc_chkn,
        rcg_gis_tc_chke, rcg_gis_tc_phone, rcg_gis_tc_road, rcg_gis_tc_tc2, rcg_gis_tc_auto, rcg_gis_tc_normhp,
        rcg_gis_tc_normcompany, rcg_sss_tc, rcg_gis_sss, rcg, rcg_sss,
        rcg_arss, arss_req, arss_resp, rcg_awsm, awsm_req, awsm_resp, notc, rcg_gis_zc_chkn_detail("aos"), rcg_gis_zc_chkn_detail("aos_new_gid1"),
        rcg_gis_zc_chkn_detail("opt_sup"), rcg_gis_zc_chkn_detail("arss"), rcg_gis_zc_chkn_detail("cms"), rcg_gis_zc_chkn_detail("truth"),
        rcg_gis_zc_chkn_detail("truth_qs"), rcg_gis_zc_chkn_detail("aos_tc_init_gid_dj"), rcg_gis_zc_chkn_detail("aos_tc_init_gid_gj"),
        rcg_gis_zc_chkn_detail("script"), rcg_gis_zc_chkn_detail("sss"), rcg_gis_zc_chkn_detail("awsm"), rcg_gis_zc_chkn_detail("other"),
        address_unknown, add_xy_cnt, add_xy_dept_match, add_xy_tc_match, aoi_ok, aoi_req, aoi_re, aoi_suc, aoi_dept_error, aoi_address_unknown,
        ksReqCnt, ksResCnt, ks_aoi, ksTcCnt, ks_zc, auto_zc, ks_tc, total_tc,
        gis_aoi, ks_aoi, sys_aoi, addresseeKeyWordFlag, rcg_gis_aoi_norm, rcg_gis_aoi_chkn, rcg_gis_aoi_chke, rcg_gis_aoi_phone,
        rcg_gis_aoi_road, rcg_gis_aoi_tc2, rcg_gis_aoi_auto, rcg_gis_aoi_normhp, rcg_gis_aoi_normcompany, rcg_gis_aoi_other, aoiAreaCnt,
        transitCodeCnt, aoiTypeCnt, aoiChannelCnt, sys_zc, ks_only_aoi, ks_aoi
      )


      val aoiObj = Obj.DlvAoiObj("", incDay, province, region, city, city_code, finalZc, req, aoi_ok, aoi_req, aoi_re, aoi_suc, aoi_dept_error, aoi_address_unknown,
        gis_aoi, ks_aoi, sys_aoi, rcg_gis_aoi_norm, rcg_gis_aoi_chkn, rcg_gis_aoi_chke, rcg_gis_aoi_phone, rcg_gis_aoi_road, rcg_gis_aoi_tc2, rcg_gis_aoi_auto, rcg_gis_aoi_normhp,
        rcg_gis_aoi_normcompany, rcg_gis_aoi_other, 0, invalidDept, addresseeBuildingIdFlag, bidCollectCnt, bidCollectRejectCnt, bidCfCnt, bidSysCnt, bidSysBaseCnt, bidSysOk, bidAoiidDiff,
        bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping1, bidCfAoiMapping2, bidCfAoiSimilar, bidCfOther, ks_only_aoi
      )
      val jOject = remainObject(obj, addresseeAoiId, body_index,
        bid_re_body, bid_re_body_base)
      re = (jOject, rcgObj, aoiObj, rcgObjDetail)
    } catch {
      case e: Exception => logger.error(">>>解析行指标错误:" + e + ",json:" + obj)
    }
    re
  }

  def checkInvalidDept(finalZc: String, invalidDeptSet: util.HashSet[String]): Int = {
    if (finalZc != null && !finalZc.isEmpty
      && invalidDeptSet.contains(finalZc)) {
      return 1
    }
    0
  }

  def matchBidSource(bidSource: String, bidCfCnt: Int, body_index: String): (Int, Int, Int, Int, Int, Int, Int, Int, Int, Int) = {
    var bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping1, bidCfAoiMapping2, bidCfAoiSimilar, bidCfOther = 0
    if (bidCfCnt == 1) {
      bidSource match {
        case "NORM" => bidCfNorm = 1
        case "NORM_MULTI_GID" => bidCfNormMultiGid = 1
        case "COMPANY" => bidCfComapny = 1
        case "PHONE" => bidCfPhone = 1
        case "DS_POI" => bidCfDsPoi = 1
        case "MIN_POI" => bidCfMinPoi = 1
        case "AOI_MAPPING" => {
          if ("1".equals(body_index)) {
            bidCfAoiMapping1 = 1
          } else {
            bidCfAoiMapping2 = 1
          }
        }
        case "SIMILAR" => bidCfAoiSimilar = 1
        case _ => bidCfOther = 1
      }
    }
    (bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping1, bidCfAoiMapping2, bidCfAoiSimilar, bidCfOther)
  }

  def specialHk(cityCode: String, addresseeAoiId: String, addresseeAoiArea: String, finalTc: String): Boolean = {
    if ("852".equals(cityCode) && addresseeAoiId.isEmpty && !finalTc.isEmpty && addresseeAoiArea.length >= 3) {
      val str = addresseeAoiArea.takeRight(3)
      if (str.startsWith("5") || str.startsWith("6")) {
        return true
      }
    }
    false
  }

  def specialHk_new(cityCode: String, addresseeAoiId: String, addresseeAoiArea: String, finalTc: String): Boolean = {
    if ("852".equals(cityCode) && addresseeAoiId.isEmpty && !finalTc.isEmpty && addresseeAoiArea.length >= 3) {
      val str = addresseeAoiArea.takeRight(3)
      if (str.startsWith("5") || str.startsWith("6") || str.startsWith("7") || str.startsWith("8") || str.startsWith("9")) {
        return true
      }
    }
    false
  }

  /**
   * 筛选最终bid, 取第一个bid和最后一个bid，如果第一个aoidid于addressaoiid不相等且最后一个bid的aoiid和addressAoiid相同则取最后一个
   * 第一个bid_body作为基础非兜底策略的返回，需要单独使用
   * 返回的第一个标号，代表整个返回源，是第一个还是兜底返回的
   *
   * @param obj
   * @param addresseeAoiId
   * @return
   */
  def queryBidReBody(obj: JSONObject, addresseeAoiId: String): (String, JSONObject, JSONObject) = {
    val bid_re_array = obj.getJSONArray("bid_re_body")
    if (bid_re_array == null || bid_re_array.size() == 0) {
      return (null, null, null)
    } else if (bid_re_array.size() == 1) {
      return ("1", bid_re_array.getJSONObject(0), bid_re_array.getJSONObject(0))
    } else {
      var bid_re_body_first = bid_re_array.getJSONObject(0)
      var bid_re_body_last = bid_re_array.getJSONObject(bid_re_array.size() - 1)
      val bidAoiidFirst = JSONUtil.getJsonVal(bid_re_body_first, "result.aoiId", "")
      if (!bidAoiidFirst.isEmpty && bidAoiidFirst.equals(addresseeAoiId)) {
        return ("1", bid_re_body_first, bid_re_body_first)
      }
      val bidAoiidLast = JSONUtil.getJsonVal(bid_re_body_last, "result.aoiId", "")
      if (!bidAoiidLast.isEmpty && bidAoiidLast.equals(addresseeAoiId)) {
        return ("2", bid_re_body_last, bid_re_body_first)
      }
      ("1", bid_re_body_first, bid_re_body_first)
    }

  }

  def fetchInvalidDept(spark: SparkSession, incDay: String, taskCode: Int): util.HashSet[String] = {
    var date = incDay
    if (taskCode == 0) {
      date = Util.dateDelta(-1, "")
    }
    val deptTable = "gdl.zipper_dim_department"
    val deptSql = s"select dept_code from $deptTable where dw_start_date<='$date' and dw_end_date>= '$date' " +
      s" and (dept_type_code in ('DB05-XMDB','FB04-WXJ','FB05-CCPSCK','DB05-JPZ','FB04-KYFB','ZZC04-ERJ','ZZC05-KYJS','QB03-KYGS') " +
      s" or (dept_type_code='DB05-SFZ' and (dept_name like '%临时网点%'" +
      " )))"
    val deptList = spark.sql(deptSql).rdd.map(obj => obj.getString(0)).collect()
    val deptSet = new util.HashSet[String]()
    for (dept <- deptList) {
      if (dept != null && !dept.isEmpty) {
        deptSet.add(dept)
      }
    }
    logger.error("识别率流程中剔除网点数量:" + deptSet.size())
    val csvFileDept = getAoiDeptOutList
    logger.error("文件带的特殊网点数量：" + csvFileDept.size)
    deptSet.addAll(csvFileDept)
    deptSet
  }

  def fetDeptType(spark: SparkSession, incDay: String) = {
    val deptSql = s"select dept_code,dept_type_code from dim.dim_dept_info_df where inc_day = '$incDay' and dept_type_code = 'DB05-SFZ' and dept_code <>'' and dept_code is not null"
    val map = spark.sql(deptSql).rdd.map(obj => (obj.getString(0), obj.getString(1))).collectAsMap()
    logger.error("map size:" + map.size)
    map
  }


  /**
   * 把配置资源中的数据加载到内存中来
   *
   * @return
   */
  def getAoiDeptOutList: ArrayBuffer[String] = {
    val list = new ArrayBuffer[String]
    val xiaogePath = System.getProperty("user.dir") + "/aoi_deptcode_out.csv"
    val csvReader = new CsvReader(xiaogePath)
    if (csvReader.readRecord()) println("headers:" + csvReader.getValues.mkString(","))
    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val deptcode = row(0)
      list += deptcode
    }
    list
  }

  /**
   * 保存统计指标
   *
   * @param indexRdd : 指标rdd
   */
  def saveIndexMergeToHive(spark: SparkSession, incDay: String, indexRdd: (RDD[DlvRcgObj], RDD[DlvRcgObj], RDD[DlvRcgObj], RDD[DlvRcgObj])): Unit = {
    import spark.implicits._
    val allRdd = convertIndexMergeByType("ALL", indexRdd._1)
    val regionRdd = convertIndexMergeByType("REGION", indexRdd._2)
    val cityRdd = convertIndexMergeByType("CITY", indexRdd._3)
    val zcRdd = convertIndexMergeByType("ZC", indexRdd._4)
    val totalDf = allRdd.union(regionRdd).union(cityRdd).union(zcRdd).toDF().persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error("总数量:" + totalDf.count())
    totalDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.dlv_rcg")
    logger.error(">>>rcg按维度指标入hive库结束！")
  }

  def convertIndexMergeByType(statType: String, rcgRdd: RDD[DlvRcgObj]) = {
    logger.error(">>>statType:" + statType)
    var count = 0
    rcgRdd.map(o => {
      var statContent = "ALL"
      if (statType.equals("ZC")) {
        statContent = o.zonecode
      } else if (statType.equals("REGION")) {
        statContent = o.region
      } else if (statType.equals("CITY")) {
        statContent = o.city
      }
      //计算md5值
      val id = MD5Util.getMD5(Array(o.rejection_type, o.stat_date, o.region, o.city, o.zonecode, "ALL").mkString("_"))
      val rcgParams = DlvRcg(id, o.rejection_type, statType, statContent, o.stat_date, o.region, o.city, o.city_code, "ALL", o.zonecode, o.req, o.gid, o.zc, o.zc_norm,
        o.zc_chkn, o.zc_chke, o.zc_phone, o.zc_road, o.zc_tc2, o.zc_auto, o.zc_normhp, o.zc_normcompany, o.tc, o.tc_norm, o.tc_chkn,
        o.tc_chke, o.tc_phone, o.tc_road, o.tc_tc2, o.tc_auto, o.tc_normhp, o.tc_normcompany, o.tc_sss, o.zc_gis_sss, o.zc_final, o.zc_sss,
        o.zc_arss, o.zc_arss_req, o.zc_arss_resp, o.tc_awsm, o.tc_awsm_req, o.tc_awsm_resp, o.notc, o.rcg_gis_zc_chkn_aos, o.rcg_gis_zc_chkn_aos_new_gid1,
        o.rcg_gis_zc_chkn_opt_sup, o.rcg_gis_zc_chkn_arss, o.rcg_gis_zc_chkn_cms, o.rcg_gis_zc_chkn_truth, o.rcg_gis_zc_chkn_truth_qs,
        o.rcg_gis_zc_chkn_aos_tc_init_gid_dj, o.rcg_gis_zc_chkn_aos_tc_init_gid_gj, o.rcg_gis_zc_chkn_script,
        o.rcg_gis_zc_chkn_sss, o.rcg_gis_zc_chkn_awsm, o.rcg_gis_zc_chkn_other, o.address_unknown, o.add_xy_cnt, o.add_xy_dept_match,
        o.add_xy_tc_match, o.aoi, o.aoi_req, o.aoi_re, o.aoi_suc, o.aoi_dept_error, o.aoi_address_unknown,
        o.ksReqCnt, o.ksResCnt, o.ksAoiCnt, o.ksTcCnt, o.ks_zc, o.auto_zc, o.ks_tc, o.total_tc,
        o.gis_aoi, o.ks_aoi, o.sys_aoi, o.addresseeKeyWordFlag, o.rcg_gis_aoi_norm, o.rcg_gis_aoi_chkn, o.rcg_gis_aoi_chke, o.rcg_gis_aoi_phone,
        o.rcg_gis_aoi_road, o.rcg_gis_aoi_tc2, o.rcg_gis_aoi_auto, o.rcg_gis_aoi_normhp, o.rcg_gis_aoi_normcompany, o.rcg_gis_aoi_other, o.aoiAreaCnt,
        o.transitCodeCnt, o.aoiTypeCnt, o.aoiChannelCnt, o.sys_zc, o.ks_only_aoi, o.ks_aoi
      )
      rcgParams
    })
  }

  def saveIndexMergeAoiToHive(spark: SparkSession, incDay: String, indexRdd: RDD[(String, DlvAoiObj)]): Unit = {
    import spark.implicits._
    val retDf = indexRdd.map(obj => {
      val statType = obj._1
      val o = obj._2
      var statContent = "ALL"
      if (statType.equals("ZC")) {
        statContent = o.zonecode
      } else if (statType.equals("REGION")) {
        statContent = o.region
      } else if (statType.equals("CITY")) {
        statContent = o.city
      }
      //计算md5值
      val id = MD5Util.getMD5(Array(o.rejection_type, o.stat_date, o.region, o.city, o.zonecode, "ALL").mkString("_"))
      val aoiParams = DlvAoiRcg(id, o.rejection_type, statType, statContent, o.stat_date, o.region, o.city, o.city_code, "ALL", o.zonecode, o.req,
        o.aoi, o.aoi_req, o.aoi_re, o.aoi_suc, o.aoi_dept_error, o.aoi_address_unknown,
        o.gis_aoi, o.ks_aoi, o.sys_aoi, o.rcg_gis_aoi_norm, o.rcg_gis_aoi_chkn, o.rcg_gis_aoi_chke, o.rcg_gis_aoi_phone,
        o.rcg_gis_aoi_road, o.rcg_gis_aoi_tc2, o.rcg_gis_aoi_auto, o.rcg_gis_aoi_normhp, o.rcg_gis_aoi_normcompany, o.rcg_gis_aoi_other, o.addressee_building,
        o.bidCollectCnt, o.bidCollectRejectCnt, o.bidCfCnt, o.bidSysCnt, o.bidSysOk, o.bidAoiidDiff,
        o.bidCfNorm, o.bidCfNormMultiGid, o.bidCfComapny, o.bidCfPhone, o.bidCfDsPoi, o.bidCfMinPoi, o.bidCfAoiMapping1, o.bidCfOther, o.bidSysBaseCnt, o.bidCfAoiMapping2, o.bidCfAoiSimilar,
        o.ks_only_aoi)
      aoiParams
    }).toDF()
    retDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.app_dlv_aoi_rcg")
    logger.error(">>>rcg aoi按维度指标入hive库结束！")
  }


  def findFinalAoiSrcDetail(src: String, gisAoiSrc: String, ksSrc: String, addresseeAoiCode: String) = {
    if (src.isEmpty || addresseeAoiCode.isEmpty) {
      ""
    } else if ("ks".equals(src)) {
      ksSrc
    } else if ("gis".equals(src)) {
      gisAoiSrc
    } else {
      "chke_cur"
    }
  }

  def saveIndexMergeByType(conn: Connection, md5Instance: MessageDigest, rcgInsertSql: String, statType: String, rcgRdd: RDD[DlvRcgObj]): Unit = {
    logger.error(">>>statType:" + statType)
    var count = 0
    rcgRdd.collect().foreach(o => {
      count = count + 1
      if (count % 1000 == 0) {
        logger.error(">>>count:" + count)
      }
      var statContent = "ALL"
      if (statType.equals("ZC")) {
        statContent = o.zonecode
      } else if (statType.equals("REGION")) {
        statContent = o.region
      } else if (statType.equals("CITY")) {
        statContent = o.city
      }

      //计算md5值
      val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.region, o.city, o.zonecode, "ALL").mkString("_"))
      val rcgParams = Array(id, statType, statContent, o.stat_date, o.region, o.city, o.city_code, "ALL", o.zonecode, o.req, o.gid, o.zc, o.zc_norm,
        o.zc_chkn, o.zc_chke, o.zc_phone, o.zc_road, o.zc_tc2, o.zc_auto, o.zc_normhp, o.zc_normcompany, o.tc, o.tc_norm, o.tc_chkn,
        o.tc_chke, o.tc_phone, o.tc_road, o.tc_tc2, o.tc_auto, o.tc_normhp, o.tc_normcompany, o.tc_sss, o.zc_gis_sss, o.zc_final, o.zc_sss,
        o.zc_arss, o.zc_arss_req, o.zc_arss_resp, o.tc_awsm, o.tc_awsm_req, o.tc_awsm_resp, o.notc, o.rcg_gis_zc_chkn_aos, o.rcg_gis_zc_chkn_aos_new_gid1,
        o.rcg_gis_zc_chkn_opt_sup, o.rcg_gis_zc_chkn_arss, o.rcg_gis_zc_chkn_cms, o.rcg_gis_zc_chkn_truth, o.rcg_gis_zc_chkn_truth_qs,
        o.rcg_gis_zc_chkn_aos_tc_init_gid_dj, o.rcg_gis_zc_chkn_aos_tc_init_gid_gj, o.rcg_gis_zc_chkn_script,
        o.rcg_gis_zc_chkn_sss, o.rcg_gis_zc_chkn_awsm, o.rcg_gis_zc_chkn_other, o.address_unknown, o.add_xy_cnt, o.add_xy_dept_match,
        o.add_xy_tc_match, o.aoi, o.aoi_req, o.aoi_re, o.aoi_suc, o.aoi_dept_error, o.aoi_address_unknown,
        o.ksReqCnt, o.ksResCnt, o.ksAoiCnt, o.ksTcCnt, o.ks_zc, o.auto_zc, o.ks_tc, o.total_tc,
        o.gis_aoi, o.ks_aoi, o.sys_aoi, o.addresseeKeyWordFlag, o.rcg_gis_aoi_norm, o.rcg_gis_aoi_chkn, o.rcg_gis_aoi_chke, o.rcg_gis_aoi_phone,
        o.rcg_gis_aoi_road, o.rcg_gis_aoi_tc2, o.rcg_gis_aoi_auto, o.rcg_gis_aoi_normhp, o.rcg_gis_aoi_normcompany, o.rcg_gis_aoi_other, o.aoiAreaCnt,
        o.transitCodeCnt, o.aoiTypeCnt, o.aoiChannelCnt
      )
      DbUtils.execute(conn, rcgInsertSql, rcgParams)
    })
  }

}
