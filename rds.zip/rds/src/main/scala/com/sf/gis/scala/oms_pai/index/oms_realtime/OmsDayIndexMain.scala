package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.text.DecimalFormat
import java.util

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_pai.start.JavaUtil
import com.sf.gis.scala.utils.Util
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.util.Random

/**
 * @ProductManager:01369702
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:225056，225129，225128
 * @TaskName:rds派件指标系统
 * @Description:rds派件日志解析
 */
object OmsDayIndexMain {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val javaUtil = new JavaUtil(6)
  val version = 1.1
  println(version)
  val testSingleWaybill = false
  val onlySaveHiveFlag = "onlySaveHive"
  val useCollectTableFlag = "collect"

  /**
   * main方法
   *
   * @param args : 参数
   */
  def main(args: Array[String]): Unit = {
    //    val tmp="SF1980355736193"
    //    println(getKeyByStr(tmp))
    //    test()
    //    var taskCode: Int = 0 //0表示实时程序，-1表示隔日程序
    logger.error("testSingleWaybill:" + testSingleWaybill)
    var incDaySep = "";
    var inclueDays = 0 //单次跑多少天的日志. 目前在过滤中只获取时间为当天的数据，不获取跨天的数据做匹配
    //存储标志
    var saveFlag = ""
    if (args.length >= 2) {
      incDaySep = args(0)
      inclueDays = args(1).toInt
    }
    //是否保存hbase数据
    if (args.length > 2) {
      saveFlag = args(2)
    }
    var tableFlag = useCollectTableFlag
    if (args.length > 3) {
      tableFlag = args(3)
    }
    start(incDaySep, inclueDays, saveFlag, tableFlag)
    logger.error("日志解析完毕")
  }

  def test(): Unit = {

  }

  /**
   * 开始任务
   */
  def start(incDaySep: String, inclueDays: Int, saveFlag: String, tableFlag: String): Unit = {
    val spark = SparkSession.builder().config(getConf(appName+Random.nextInt(1000))).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    //    val date: String = Util.dateDelta(taskCode, "-")
    singleTask(spark, incDaySep, inclueDays, saveFlag, tableFlag)
    //    spark.stop()
  }

  /**
   * 单个任务
   *
   * @param spark : spark session
   * @param date  : 日期
   */
  def singleTask(spark: SparkSession, date: String, inclueDays: Int, saveFlag: String, tableFlag: String): Unit = {
    //取两天数据防止跨天结果返回(人工审补)和跨天打日志
    handleTask(spark, date, inclueDays, saveFlag, tableFlag)
  }

  def queryOverOneDayDataFlag() = {
    Array("=>link to gid:", "kafka topic GIS_ASS_RDS_CHK_DISPATCH_TO_ARSS,message:",
      "kafka topic GIS_ASS_RDS_CHKDEST_TO_ARSS,message:", "=>receive waybill dept chk message :",
      "=>kafka topic GIS_ASS_RDS_AOI_TO_AWSM,message:", "=>chkAoiMsg:",
      "=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message:",
      "AddressUnkowCheck:"
      //req用来平衡rebody的数据，减少无请求的今天的rebody
      //      ,"=>receive oms waybill message :"
    ).mkString("|")
  }

  def fetchOriginLog(spark: SparkSession, dateSep: String, incDay: String, inclueDays: Int,
                     tableFlag: String): RDD[String] = {
    val beginDay = incDay
    val endDay = Util.getDay(incDay, inclueDays, "")
    val incDayBc = spark.sparkContext.broadcast(incDay)
    val dateSepBc = spark.sparkContext.broadcast(dateSep)
    var originTable = "dm_gis.chk_pai_log_flink_collect"
    if (incDay.equals(Util.dateDelta(0, "")) || !useCollectTableFlag.equals(tableFlag)) {
      originTable = "dm_gis.chk_pai_log_flink"
    }
    val overOneDayDataFlag = queryOverOneDayDataFlag()
    var sql = s"select log,inc_day from $originTable where " +
      s" inc_day between '$beginDay' and '$endDay' " +
      s" and (inc_day='${incDay}' or (log like '%$dateSep%') or log regexp '$overOneDayDataFlag') "
    if (testSingleWaybill) {
      sql = sql + " and (log like '%SF1451019857254%' or log like '%SF1623679020066%' or log like '%SF1687855569807%' or log like '%SF1834903019882%') "
    }
    logger.error(sql)
    val origin = spark.sql(sql).rdd.filter(obj => {
      val line = obj.getString(0)
      val incDay = obj.getString(1)
      if (incDayBc.value.equals(incDay)) {
        ParseOmsLog.isValidLine(line) && line.contains(dateSepBc.value)
      } else {
        (ParseOmsLog.isValidLine(line) && line.contains(dateSepBc.value)) || ParseOmsLog.isShenbuLine(line)
      }
    }).map(obj => {
      obj.getString(0)
    })
    origin
  }

  def fetchOriginLogBak(spark: SparkSession, dateSep: String, incDay: String, inclueDays: Int): RDD[String] = {
    val beginDay = incDay
    val endDay = Util.getDay(incDay, inclueDays, "")
    val incDayBc = spark.sparkContext.broadcast(incDay)
    val dateSepBc = spark.sparkContext.broadcast(dateSep)
    var originTable = "dm_gis.chk_pai_log_flink_collect"
    if (incDay.equals(Util.dateDelta(0, ""))) {
      originTable = "dm_gis.chk_pai_log_flink"
    }
    var sql = s"select log,inc_day from $originTable where " +
      s" inc_day between '$beginDay' and '$endDay' "

    //    sql = s"select log,inc_day from $originTable where " +
    //      s" inc_day between '$beginDay' and '$endDay' and log not like '%=>kafka topic GIS_ASS_RDS_CHK_DISPATCH_EXT_EVENT,message:%' " +
    //      s" union select log,inc_day from dm_gis.tmp_chk_pai where inc_day between '$beginDay' and '$endDay' and log not like '%=>kafka topic GIS_ASS_RDS_CHK_DISPATCH_EXT_EVENT,message:%' "+
    //      s" union select log,inc_day from dm_gis.tmp_chk_pai_2 where inc_day between '$beginDay' and '$endDay' and log not like '%=>kafka topic GIS_ASS_RDS_CHK_DISPATCH_EXT_EVENT,message:%' "
    logger.error(sql)
    val origin = spark.sql(sql).rdd.filter(obj => {
      val line = obj.getString(0)
      val incDay = obj.getString(1)
      if (incDayBc.value.equals(incDay)) {
        ParseOmsLog.isValidLine(line) && line.contains(dateSepBc.value)
      } else {
        (ParseOmsLog.isValidLine(line) && line.contains(dateSepBc.value)) || ParseOmsLog.isShenbuLine(line)
      }
    }).map(obj => {
      obj.getString(0)
    })
    //      .map(obj => {
    //      (obj.getString(0), null)
    //    })
    //      .reduceByKey((obj1, _) => {
    //      obj1
    //    }).keys
    //    val tmp = origin.filter(obj=> obj.contains("SF1060576647821"))
    //    tmp.collect().foreach(obj=>{
    //      logger.error(obj)
    //    })
    //    origin.collect().foreach(obj=>{
    //      logger.error(obj)
    //    })
    origin
  }

  /**
   * 处理任务
   */
  def handleTask(spark: SparkSession, date: String,
                 inclueDays: Int, saveFlag: String,
                 tableFlag: String): Unit = {
    logger.error("--------start-------处理oms派件日志，日期：" + date)

    val incDay = date.replaceAll("-", "")
    var logRdd: RDD[String] = fetchOriginLog(spark, date, incDay, inclueDays, tableFlag)
    logRdd = logRdd.persist(StorageLevel.DISK_ONLY)
    logger.error(">>>需要解析当天的记录行数：" + logRdd.count())
    logger.error(">>>解析日志数据...")
    val (statLog, noMatchDataRdd) = ParseOmsLog.parseOmsLog(spark, logRdd, date, javaUtil)
    //TODO
    if (testSingleWaybill) {
      System.exit(0)
    }
    logger.error("将要写入hbase的数据写入hive，方便后面改版")
    val (lastestDataRdd, otherDataRdd) = saveHbaseDataToHive(spark, incDay, statLog, saveFlag)
    //隔日的时候数据入hive库库
    logger.error(">>>解析数据入hive库-----------")
    storeOmsLogToHive(spark, lastestDataRdd, incDay, "gis_rds_omsto")
    storeOmsLogToHive(spark, otherDataRdd, incDay, "gis_rds_omsto_other")
    Spark.clearAllPersist(spark)
  }

  def saveHbaseDataToHive(spark: SparkSession, incDay: String, omsRdd: RDD[JSONObject],
                          saveFlag: String) = {
    //转换rdd，设置put[key,value]得到最终的要存入的结果集
    val inputRdd = omsRdd.map(json => {
      var wayBillNo: String = null
      val req_body = json.getJSONObject("req_body")
      if (req_body != null && req_body.getString("waybillNo") != null) {
        wayBillNo = req_body.getString("waybillNo")
      }
      (wayBillNo, json)
    }).filter(_._1 != null).groupByKey().map(obj => {
      val wayBillNo = obj._1
      val groupJson = obj._2.toArray.sortBy(_.getString("req_time"))
      val jsonArray = new JSONArray()
      var index = groupJson.size - 1
      for (i <- groupJson.indices) {
        //倒序存储
        val json = groupJson(index - i)
        jsonArray.add(json)
      }
      //      val jsonObject = new JSONObject()
      //      jsonObject.put("data", jsonArray.toJSONString)
      //      jsonObject.put("hashKey", getKeyByStr(wayBillNo))
      //      jsonObject
      (wayBillNo, jsonArray)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("按运单聚合数量：" + inputRdd.count())
    Spark.clearPersistWithoutId(spark, inputRdd.id)
    if (onlySaveHiveFlag.equals(saveFlag)) {
      logger.error("只存储hive")
    } else {
      val saveKey = Array("data", "hashKey")
      SparkWrite.save2HiveStaticRandom(spark, inputRdd.map(obj => {
        val jsonObject = new JSONObject()
        jsonObject.put("data", obj._2.toJSONString)
        jsonObject.put("hashKey", getKeyByStr(obj._1))
        jsonObject
      }), saveKey,
        "dm_gis.gis_rds_omsto_hbase",
        Array(("inc_day", incDay)), 800)
      logger.error(">>>" + incDay + "号oms解析hbase数据入hive结束。")
    }
    logger.error("将最后一次的请求数据和其他数据分开存储")
    val lastestDataRdd = inputRdd.map(obj => {
      obj._2.getJSONObject(0)
    })
    val otherDataRdd: RDD[JSONObject] = inputRdd.flatMap(obj => {
      obj._2.remove(0)
      val tmpArray = new util.ArrayList[JSONObject]()
      for (i <- 0 until obj._2.size()) {
        tmpArray.add(obj._2.getJSONObject(i))
      }
      tmpArray.iterator()
    })
    (lastestDataRdd, otherDataRdd)
  }


  def findFinalAoiSrcDetail(src: String, gisAoiSrc: String, ksSrc: String, addresseeAoiCode: String) = {
    if (src.isEmpty || addresseeAoiCode.isEmpty) {
      ""
    } else if ("ks".equals(src)) {
      ksSrc
    } else if ("gis".equals(src)) {
      gisAoiSrc
    } else {
      "chke_cur"
    }
  }

  /**
   * oms解析日志入库
   *
   * @param spark  : spark session
   * @param incDay : 日期
   */
  def storeOmsLogToHive(spark: SparkSession, omstoLog: RDD[JSONObject], incDay: String,
                        hiveTableName: String): Unit = {

    val rows: RDD[Row] = omstoLog.map(obj => {
      val re_body_array = obj.getJSONArray("re_body")
      val re_body_item = getLatestBody(re_body_array, "datetime")
      var re_body_item_str = ""
      if (re_body_item != null) re_body_item_str = re_body_item.toJSONString.replaceAll("[\\r\\n\\t]", "")

      val nameList = Array[String]("nodeId", "type", "reqId", "req_time", "req_body.inputEmpCode", "req_body.orderNo",
        "req_body.addreisseePhone", "req_body.addresseeMobile", "req_body.addresseeAddr", "req_body.addresseeContacts",
        "req_body.sourceCityCode", "req_body.destCityCode", "req_body.waybillNo", "req_body.consignorAddr", "re_time",
        "re_body.addresseeCityCode", "re_body.orderNo", "re_body.consignorCityCode", "re_body.addresseeAddr",
        "re_body.addresseeDeptCode", "re_body.addresseeTeamCode", "re_body.addresseeTransitCode", "re_body.waybillNo",
        "gis_to_sys_time", "gis_to_sys_body.teamToRetBy", "gis_to_sys_body.gisTeamCodeTo", "gis_to_sys_body.src",
        "gis_to_sys_body.gisDeptCodeTo", "atpai_body.groupId", "gis_to_sys_body.deptToRetBy", "gis_to_sys_body.sssDeptCodeTo",
        "arss_dept_req_time", "arss_dept_req_body.inputEmpCode", "arss_dept_req_body.taskType", "arss_dept_req_body.address",
        "arss_dept_req_body.gid", "arss_dept_req_body.orderNo", "arss_dept_req_body.phone", "arss_dept_req_body.cityCode",
        "arss_dept_req_body.errorType", "arss_dept_req_body.mobile", "arss_dept_req_body.contactsName", "arss_dept_req_body.waybillNo",
        "arss_dept_re_time", "arss_dept_re_body.identRs", "arss_dept_re_body.dealTm", "arss_dept_re_body.dealFlg",
        "arss_dept_re_body.opType", "arss_dept_re_body.opTm", "arss_dept_re_body.result", "arss_dept_re_body.dealIp",
        "arss_dept_re_body.cancelReasonCode", "arss_dept_re_body.insertTm", "arss_dept_re_body.id", "arss_dept_re_body.dealCount",
        "arss_dept_re_body.taskId", "arss_dept_re_body.waybillNo", "awsm_tc_req_time", "awsm_tc_req_body.sysCode",
        "awsm_tc_req_body.address", "awsm_tc_req_body.gid", "awsm_tc_req_body.orderNo", "awsm_tc_req_body.phone",
        "awsm_tc_req_body.mobile", "awsm_tc_req_body.locationCode", "awsm_tc_req_body.contacts", "awsm_tc_req_body.deptCode",
        "awsm_tc_req_body.waybillNo", "awsm_tc_re_time", "awsm_tc_re_body.gid", "awsm_tc_re_body.address", "awsm_tc_re_body.dataType",
        "awsm_tc_re_body.teamCode", "awsm_tc_re_body.locationCode", "awsm_tc_re_body.retCode", "awsm_tc_re_body.deptCode",
        "awsm_tc_re_body.waybillNo")
      val valueList = new Array[String](nameList.length)
      for (i <- nameList.indices) {
        if (nameList(i).startsWith("re_body.")) {
          valueList(i) = JSONUtil.getJsonVal(re_body_item, nameList(i).replace("re_body.", ""), "").toString.replaceAll("[\\r\\n\\t]", "")
        } else if (i == 8) {
          //地址新逻辑，为空时，使用原始地址做拼接
//          var tmpAddress = JSONUtil.getJsonVal(obj, "req_body.addresseeAddr", "")
//          if (!tmpAddress.isEmpty) {
//            valueList(i) = tmpAddress.replaceAll("[\\r\\n\\t]", "")
//          } else {
            valueList(i) = (JSONUtil.getJsonVal(obj, "req_body.receiverProvince", "")
              + JSONUtil.getJsonVal(obj, "req_body.receiverCity", "")
              + JSONUtil.getJsonVal(obj, "req_body.receiverArea", "")
              + JSONUtil.getJsonVal(obj, "req_body.receiverAddr", "")).replaceAll("[\\r\\n\\t]", "")
//          }
        }
        else {
          valueList(i) = JSONUtil.getJsonVal(obj, nameList(i), "").toString.replaceAll("[\\r\\n\\t]", "")
        }
      }
      var finalAoiCode = JSONUtil.getJsonVal(re_body_item, "addresseeAoiCode", "").replaceAll("[\\r\\n\\t]", "")
      val finalAoiCodeNew = JSONUtil.getJsonVal(re_body_item, "entityAoiCode", "").replaceAll("[\\r\\n\\t]", "")
      if (!finalAoiCodeNew.isEmpty) {
        finalAoiCode = finalAoiCodeNew
      }
      var finalAoiId = JSONUtil.getJsonVal(re_body_item, "addresseeAoiId", "").replaceAll("[\\r\\n\\t]", "")
      val finalAoiIdNew = JSONUtil.getJsonVal(re_body_item, "entityAoiId", "").replaceAll("[\\r\\n\\t]", "")
      if (!finalAoiIdNew.isEmpty) {
        finalAoiId = finalAoiIdNew
      }

      val finalZc = JSONUtil.getJsonVal(re_body_item, "addresseeDeptCode", "").replaceAll("[\\r\\n\\t]", "")
      val finalTc = JSONUtil.getJsonVal(re_body_item, "addresseeTeamCode", "").replaceAll("[\\r\\n\\t]", "")
      val finalSrc = JSONUtil.getJsonVal(re_body_item, "src", "").replaceAll("[\\r\\n\\t]", "")
      val finalZcBy = finalSrc
      val finalTcBy = finalSrc
      val service = "micro" //微服务

      val req_body = JSONUtil.getJsonObj(obj, "req_body", "").replaceAll("[\\r\\n\\t]", "")
      val re_body = JSONUtil.getJsonArray(obj, "re_body", "").replaceAll("[\\r\\n\\t]", "")
      val gis_to_sys_body = JSONUtil.getJsonObj(obj, "gis_to_sys_body", "").replaceAll("[\\r\\n\\t]", "")
      val arss_dept_req_body = JSONUtil.getJsonObj(obj, "arss_dept_req_body", "").replaceAll("[\\r\\n\\t]", "")
      val arss_dept_re_body = JSONUtil.getJsonObj(obj, "arss_dept_re_body", "").replaceAll("[\\r\\n\\t]", "")
      val arss_dept_req_array = JSONUtil.getJsonArray(obj, "arss_dept_req_array", "").replaceAll("[\\r\\n\\t]", "")
      val arss_dept_re_array = JSONUtil.getJsonArray(obj, "arss_dept_re_array", "").replaceAll("[\\r\\n\\t]", "")

      val awsm_tc_req_body = JSONUtil.getJsonObj(obj, "awsm_tc_req_body", "").replaceAll("[\\r\\n\\t]", "")
      val awsm_tc_re_body = JSONUtil.getJsonObj(obj, "awsm_tc_re_body", "").replaceAll("[\\r\\n\\t]", "")
      val geo_body = JSONUtil.getJsonObj(obj, "geo_body", "").replaceAll("[\\r\\n\\t]", "")
      val geo_time = JSONUtil.getJsonObj(obj, "geo_time", "").replaceAll("[\\r\\n\\t]", "")
      val async_data = JSONUtil.getJsonArray(obj, "async_data", "").replaceAll("[\\r\\n\\t]", "")
      val sss_dept_req_body = JSONUtil.getJsonObj(obj, "sss_dept_req_body", "").replaceAll("[\\r\\n\\t]", "")
      val sss_dept_re_body = JSONUtil.getJsonObj(obj, "sss_dept_re_body", "").replaceAll("[\\r\\n\\t]", "")
      val no_req_data = JSONUtil.getJsonArray(obj, "no_req_data", "").replaceAll("[\\r\\n\\t]", "")
      val no_gid_data = JSONUtil.getJsonArray(obj, "no_gid_data", "").replaceAll("[\\r\\n\\t]", "")
      val aoi_dept_req_body = JSONUtil.getJsonArray(obj, "aoi_dept_req_body", "").replaceAll("[\\r\\n\\t]", "")
      val aoi_dep_req_latest = getLatestBody(obj.getJSONArray("aoi_dept_req_body"), "aoi_dept_req_time")
      var aoi_dep_req_latest_str = ""
      if (aoi_dep_req_latest != null) aoi_dep_req_latest_str = aoi_dep_req_latest.toJSONString.replaceAll("[\\r\\n\\t]", "")
      val aoi_dept_re_body = JSONUtil.getJsonArray(obj, "aoi_dept_re_body", "").replaceAll("[\\r\\n\\t]", "")
      val aoi_dep_re_latest = getLatestBody(obj.getJSONArray("aoi_dept_re_body"), "aoi_dept_re_time")
      var aoi_dep_re_latest_str = ""
      if (aoi_dep_re_latest != null) aoi_dep_re_latest_str = aoi_dep_re_latest.toJSONString.replaceAll("[\\r\\n\\t]", "")

      val ks_req_body = JSONUtil.getJsonObj(obj, "ks_req_body", "").replaceAll("[\\r\\n\\t]", "")
      val ks_re_body = JSONUtil.getJsonObj(obj, "ks_re_body", "").replaceAll("[\\r\\n\\t]", "")
      val chk_ext_req_body = JSONUtil.getJsonObj(obj, "chk_ext_req_body", "").replaceAll("[\\r\\n\\t]", "")
      //楼栋
      val bid_req_body = JSONUtil.getJsonArray(obj, "bid_req_body", "").replaceAll("[\\r\\n\\t]", "")
      val bid_re_array = JSONUtil.getJsonArray(obj, "bid_re_body", "").replaceAll("[\\r\\n\\t]", "")
      //      val bid_re_body=JSONUtil.getJsonObj(obj, "bid_re_body", "").replaceAll("[\\r\\n\\t]", "")
      val (body_index, bid_re_body_json, bid_re_body_base) = OmsIndexStat.queryBidReBody(obj, finalAoiId)
      var bid_re_body = ""
      if (bid_re_body_json != null) {
        bid_re_body = bid_re_body_json.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }

      //未识别数据
      val unkownCheckBody = JSONUtil.getJsonObj(obj, "address_unkow_check_body", "").replaceAll("[\\r\\n\\t]", "")

      val atPaiTime = JSONUtil.getJsonValSingle(obj, "atpai_time", "")
      var notc = ""
      var chkDeptSrc = ""
      var precision = ""
      var city = ""
      var adcode = ""
      var standardization = ""
      var splitResult = ""
      var splitType = ""
      var groupIds = ""
      var filters = ""
      var adcodes = ""
      var keys = ""
      var keyWords = ""
      var matchIds = ""
      var other_matchid = ""
      val atPaiBodySave = new JSONObject()
      var idListStr = ""
      if (obj.containsKey("atpai_body")) {
        val atpaiBody = obj.getJSONObject("atpai_body")
        try {
          val idList = atpaiBody.getJSONObject("idList")
          if (idList != null) {
            idListStr = idList.toJSONString
          }
          val rpcInfo = atpaiBody.getJSONObject("rpcInfo")
          if (rpcInfo != null) {
            atPaiBodySave.put("rpcInfo", rpcInfo)
          }
          val tcs = atpaiBody.getJSONArray("tcs")
          if (tcs != null) {
            atPaiBodySave.put("tcs", tcs)
          }
          obj.put("atPaiBodySave", atPaiBodySave)
          chkDeptSrc = atpaiBody.getString("chkDeptSrc")
          precision = atpaiBody.getString("precision")
          notc = atpaiBody.getString("notc")
          city = atpaiBody.getString("city")
          adcode = atpaiBody.getString("adcode")
          standardization = atpaiBody.getString("standardization")
          splitResult = atpaiBody.getString("splitResult")
          splitType = atpaiBody.getString("splitType")
          groupIds = atpaiBody.getJSONArray("groupIds").mkString("$")
          filters = atpaiBody.getJSONArray("filters").mkString("$")
          adcodes = atpaiBody.getJSONArray("adcodes").mkString("$")
          keys = atpaiBody.getJSONArray("keys").mkString("$")
          keyWords = atpaiBody.getJSONArray("keyWords").mkString("$")
          matchIds = atpaiBody.getJSONArray("matchIds").mkString("$")
          other_matchid = atpaiBody.getJSONArray("other_matchid").mkString("$")
        } catch {
          //          case e: Exception => logger.error("get atpai error", e)
          case e: Exception =>
        }
      }

      val reqCompName = JSONUtil.getJsonVal(obj, "req_body.addresseeCompName", "").replaceAll("[\\r\\n\\t]", "")
      val reqProvince = JSONUtil.getJsonVal(obj, "req_body.receiverProvince", "").replaceAll("[\\r\\n\\t]", "")
      val reqCity = JSONUtil.getJsonVal(obj, "req_body.receiverCity", "").replaceAll("[\\r\\n\\t]", "")
      val reqArea = JSONUtil.getJsonVal(obj, "req_body.receiverArea", "").replaceAll("[\\r\\n\\t]", "")
      val gisAoiSrc = JSONUtil.getJsonVal(obj, "atpai_body.aoiSrc", "").replaceAll("[\\r\\n\\t]", "")
      var gisAoiCode = JSONUtil.getJsonVal(obj, "atpai_body.aoiCode", "").replaceAll("[\\r\\n\\t]", "")
      val addresseeAoiCode = JSONUtil.getJsonVal(re_body_item, "addresseeAoiCode", "").replaceAll("[\\r\\n\\t]", "")
      //      if ((gisAoiCode == null || gisAoiCode.isEmpty) && "gis".equals(gisAoiSrc) && addresseeAoiCode != null && !addresseeAoiCode.isEmpty) {
      //        gisAoiCode = addresseeAoiCode
      //      }
      var ksAoiCode = JSONUtil.getJsonVal(obj, "ks_re_body.result.aoiCode", "").replaceAll("[\\r\\n\\t]", "")
      val ksSrc = JSONUtil.getJsonVal(obj, "ks_re_body.result.aoiTag", "").replaceAll("[\\r\\n\\t]", "")
      val src = JSONUtil.getJsonVal(re_body_item, "src", "").replaceAll("[\\r\\n\\t]", "")

      if ((gisAoiCode == null || gisAoiCode.isEmpty) && "ks".equals(src) && addresseeAoiCode != null && !addresseeAoiCode.isEmpty) {
        ksAoiCode = addresseeAoiCode
      }
      val finalAoiBy = src
      var finalAoiDetailSrc = findFinalAoiSrcDetail(src, gisAoiSrc, ksSrc, addresseeAoiCode)
      //新增字段值
      val addValues = Array[String](finalZc, finalTc, service, finalZcBy, finalTcBy, req_body, re_body, gis_to_sys_body,
        arss_dept_req_body, arss_dept_re_body, awsm_tc_req_body, awsm_tc_re_body, geo_body, geo_time, atPaiTime, notc,
        city, adcode, standardization, splitResult, splitType, groupIds, matchIds, filters, adcodes, keyWords, keys,
        reqCompName, reqProvince, reqCity, reqArea, chkDeptSrc, precision, async_data, no_req_data, no_gid_data,
        sss_dept_req_body, sss_dept_re_body, aoi_dept_req_body, aoi_dept_re_body, other_matchid, ks_req_body, ks_re_body,
        chk_ext_req_body, JSONUtil.getJsonObj(obj, "atPaiBodySave", ""), gisAoiCode, gisAoiSrc, ksAoiCode, finalAoiCode,
        arss_dept_req_array, arss_dept_re_array, re_body_item_str, aoi_dep_req_latest_str, aoi_dep_re_latest_str,
        idListStr, finalAoiBy, bid_req_body, bid_re_body, unkownCheckBody, bid_re_array, finalAoiId, finalAoiDetailSrc)

      var row: Row = null
      try {
        row = RowFactory.create(valueList(0), valueList(1), valueList(2), valueList(3), valueList(4), valueList(5), valueList(6),
          valueList(7), valueList(8), valueList(9), valueList(10), valueList(11), valueList(12), valueList(13), valueList(14),
          valueList(15), valueList(16), valueList(17), valueList(18), valueList(19), valueList(20), valueList(21), valueList(22),
          valueList(23), valueList(24), valueList(25), valueList(26), valueList(27), valueList(28), valueList(29), valueList(30),
          valueList(31), valueList(32), valueList(33), valueList(34), valueList(35), valueList(36), valueList(37), valueList(38),
          valueList(39), valueList(40), valueList(41), valueList(42), valueList(43), valueList(44), valueList(45), valueList(46),
          valueList(47), valueList(48), valueList(49), valueList(50), valueList(51), valueList(52), valueList(53), valueList(54),
          valueList(55), valueList(56), valueList(57), valueList(58), valueList(59), valueList(60), valueList(61), valueList(62),
          valueList(63), valueList(64), valueList(65), valueList(66), valueList(67), valueList(68), valueList(69), valueList(70),
          valueList(71), valueList(72), valueList(73), valueList(74), valueList(75), valueList(76),
          addValues(0), addValues(1), addValues(2), addValues(3), addValues(4), addValues(5), addValues(6), addValues(7), addValues(8),
          addValues(9), addValues(10), addValues(11), addValues(12), addValues(13), addValues(14), addValues(15), addValues(16),
          addValues(17), addValues(18), addValues(19), addValues(20), addValues(21), addValues(22), addValues(23), addValues(24),
          addValues(25), addValues(26), addValues(27), addValues(28), addValues(29), addValues(30), addValues(31), addValues(32),
          addValues(33), addValues(34), addValues(35), addValues(36), addValues(37), addValues(38), addValues(39), addValues(40),
          addValues(41), addValues(42), addValues(43), addValues(44), addValues(45), addValues(46), addValues(47), addValues(48),
          addValues(49), addValues(50), addValues(51), addValues(52), addValues(53), addValues(54), addValues(55), addValues(56), addValues(57),
          addValues(58), addValues(59), addValues(60), addValues(61))
      } catch {
        //        case e: Exception => logger.error(obj, e)
        case e: Exception =>
      }
      row
    }).filter(_ != null).map(obj => {
      (Random.nextInt(800), obj)
    }).repartition(800).values

    val structs = Array("nodeId", "type", "reqId", "req_time", "req_inputEmpCode", "req_orderNo", "req_addresseePhone",
      "req_addresseeMobile", "req_addresseeAddr", "req_addresseeContacts", "req_sourceCityCode", "req_destCityCode",
      "req_waybillNo", "req_consignorAddr", "re_time", "re_addresseeCityCode", "re_orderNo", "re_consignorCityCode",
      "re_addresseeAddr", "re_addresseeDeptCode", "re_addresseeTeamCode", "re_addresseeTransitCode", "re_waybillNo",
      "gis_to_sys_time", "gis_to_sys_teamToRetBy", "gis_to_sys_gisTeamCodeTo", "gis_to_sys_src", "gis_to_sys_gisDeptCodeTo",
      "gis_to_sys_groupid", "gis_to_sys_deptToRetBy", "gis_to_sys_sssDeptCodeTo", "arss_dept_req_time", "arss_dept_req_inputEmpCode",
      "arss_dept_req_taskType", "arss_dept_req_address", "arss_dept_req_gid", "arss_dept_req_orderNo", "arss_dept_req_phone",
      "arss_dept_req_cityCode", "arss_dept_req_errorType", "arss_dept_req_mobile", "arss_dept_req_contactsName", "arss_dept_req_waybillNo",
      "arss_dept_re_time", "arss_dept_re_identRs", "arss_dept_re_dealTm", "arss_dept_re_dealFlg", "arss_dept_re_opType", "arss_dept_re_opTm",
      "arss_dept_re_result", "arss_dept_re_dealIp", "arss_dept_re_cancelReasonCode", "arss_dept_re_insertTm", "arss_dept_re_id",
      "arss_dept_re_dealCount", "arss_dept_re_taskId", "arss_dept_re_waybillNo", "awsm_tc_req_time", "awsm_tc_req_sysCode",
      "awsm_tc_req_address", "awsm_tc_req_gid", "awsm_tc_req_orderNo", "awsm_tc_req_phone", "awsm_tc_req_mobile",
      "awsm_tc_req_locationCode", "awsm_tc_req_contacts", "awsm_tc_req_deptCode", "awsm_tc_req_waybillNo", "awsm_tc_re_time",
      "awsm_tc_re_gid", "awsm_tc_re_address", "awsm_tc_re_dataType", "awsm_tc_re_teamCode", "awsm_tc_re_locationCode", "awsm_tc_re_retCode",
      "awsm_tc_re_deptCode", "awsm_tc_re_waybillNo", "finalZc", "finalTc", "service", "finalZcBy", "finalTcBy", "req_body", "re_body",
      "gis_to_sys_body", "arss_dept_req_body", "arss_dept_re_body", "awsm_tc_req_body", "awsm_tc_re_body", "geo_body", "geo_time",
      "atpai_time", "notc", "city", "adcode", "standardization", "splitResult", "splitType", "groupIds", "matchIds", "filters", "adcodes",
      "keyWords", "keys", "reqCompName", "reqProvince", "reqCity", "reqArea", "chkDeptSrc", "precision", "async_data", "no_req_data", "no_gid_data",
      "sss_dept_req_body", "sss_dept_re_body", "aoi_dept_req_body", "aoi_dept_re_body", "other_matchid", "ks_req_body", "ks_re_body",
      "chk_ext_req_body", "at_pai_body", "gisAoiCode", "gisAoiSrc", "ksAoiCode", "finalAoiCode",
      "arss_dept_req_array", "arss_dept_re_array", "re_body_latest", "aoi_dept_req_body_latest", "aoi_dept_re_body_latest",
      "idList", "finalaoiby", "bid_req_body", "bid_re_body", "unkown_check_body", "bid_re_array", "finalAoiId", "finalAoiDetailSrc")

    import java.util
    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))

    val structType = DataTypes.createStructType(structFileds)
    val df: DataFrame = spark.createDataFrame(rows, structType)
    val dataBaseName = "dm_gis"

    val tempView = String.format("%s_temp_view", hiveTableName)
    df.createOrReplaceTempView(tempView)
    val insertSql = s"insert overwrite table ${dataBaseName}.${hiveTableName} partition(inc_day = '${incDay}') select * from ${tempView}"
    logger.error(">>>插入数据：" + insertSql)
    spark.sql(insertSql)
    logger.error(">>>" + incDay + "号oms解析数据入hive库结束!")
  }

  def getLatestBody(jArray: JSONArray, dateTimeKey: String): JSONObject = {
    if (jArray == null || jArray.size() == 0) {
      return null
    }
    var re_body_item: JSONObject = null
    for (i <- 0 until jArray.size()) {
      val tmp_re_body = jArray.getJSONObject(i)
      if (re_body_item == null) {
        re_body_item = tmp_re_body
      } else {
        if (re_body_item.getString(dateTimeKey) < tmp_re_body.getString(dateTimeKey)) {
          re_body_item = tmp_re_body
        }
      }
    }
    re_body_item
  }

  /**
   * 根据运单号计算key
   *
   * @param waybillNo : 运单号
   * @return
   */
  def getKeyByStr(waybillNo: String): String = {
    var salt = (waybillNo.hashCode() % 30).toString.replace("-", "")
    val df = new DecimalFormat("00")
    if (salt.length == 1) {
      //个位数前面需要补0
      salt = df.format(Integer.parseInt(salt))
    }
    val key = salt + "_" + waybillNo
    key
  }

  /**
   * @param appName : spark任务名
   * @return
   */
  def getConf(appName: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
      .set("spark.port.maxRetries", "100")
      .set("spark.driver.maxResultSize", "12g")
      .set("spark.rpc.io.backLog", "10000")
      .set("spark.cleaner.referenceTracking.blocking", "false")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.driver.allowMultipleContexts", "true")
      .set("spark.sql.tungsten.enabled", "false")
      .set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
      .set("quota.consumer.default", (10485760 * 2).toString)
      .set("cache.max.bytes.buffering", (20485760 * 2).toString)
      .set("spark.sql.broadcastTimeout", "36000")
      .set("spark.network.timeout", "30000")
      .set("spark.executor.heartbeatInterval", "30000")
      .set("hive.exec.dynamic.partition", "true")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.result.partition.ratio", "1")
    //    if(taskCode == 0){
    //      println("excutors:40")
    //      conf.set("spark.executor.instances","40")
    //    }else{
    //      println("excutors:50")
    //高峰期配置 begin
    //    conf.set("spark.executor.instances", "60")
    //    conf.set("spark.executor.instances","40")
    //    conf.set("spark.executor.memory", "30g")
    //    conf.set("spark.yarn.executor.memoryOverhead", "10g")
    //高峰期配置 end
    //    }
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
    conf.set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")

    conf
  }

}
