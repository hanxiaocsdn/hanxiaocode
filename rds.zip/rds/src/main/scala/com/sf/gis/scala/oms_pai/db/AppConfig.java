package com.sf.gis.scala.oms_pai.db;

import com.alibaba.fastjson.JSONObject;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

/**
 * Created by 01368078 on 2018/2/6.
 */
public class AppConfig implements Serializable {
    public static final int REALTIME_TYPE = 1;
    public static final int OFFLINE_TYPE = 2;

    private String hdfs;
    private String dbGis;
    private String tableGis;
    private String tableGis2;
    private String tableGisTempview;
    private String tableGisTempview2;
    private String tableGisRls;
    private String tableGisOmsto;
    private String dbFvp;
    private String tableFvp;
    private String dbPickUpPlan;
    private String tablePickUpPlan;
    private String tableEmpInfo;
    private String table_scan;
    private Set<String> citycodes;

    private Set<String> onCitycodes;
    private String gisByAddr;  //gis单元区域请求地址

    private static AppConfig config = null;

    private AppConfig() {
        initConfig();
    }

    public static AppConfig getInstance() {
        if (config == null) {
            synchronized (AppConfig.class) {
                if (config == null)
                    config = new AppConfig();
            }
        }
        return config;
    }

    private void initConfig() {
        setHdfs(getString("hdfs"));
        setDbGis(getString("db_gis"));
        setTableGis(getString("table_gis"));
        setTableGisTempview(getString("table_gis_tempview"));
        setTableGisRls(getString("table_gis_rls"));
        setTableGisOmsto(getString("table_gis_omsto"));
        setDbFvp(getString("db_fvp"));
        setTableFvp(getString("table_fvp"));
        setCitycodes(JSONObject.parseObject(getString("citycodes"), HashSet.class));
        setOnCitycodes(JSONObject.parseObject(getString("oncitycodes"), HashSet.class));
        setGisByAddr(getString("gisbyaddr"));
        setDbPickUpPlan(getString("db_pickupplan"));
        setTablePickUpPlan(getString("table_pickupplan"));
        setTableEmpInfo(getString("table_empinfo"));
        setTable_scan(getString("table_scan"));
        setTableGis2(getString("table_gis2"));
        setTableGisTempview2(getString("table_gis_tempview2"));
    }

    public String getTableEmpInfo() {
        return tableEmpInfo;
    }

    public void setTableEmpInfo(String tableEmpInfo) {
        this.tableEmpInfo = tableEmpInfo;
    }

    public String getDbPickUpPlan() {
        return dbPickUpPlan;
    }

    public void setDbPickUpPlan(String dbPickUpPlan) {
        this.dbPickUpPlan = dbPickUpPlan;
    }

    public String getTableGisTempview() {
        return tableGisTempview;
    }

    public void setTableGisTempview(String tableGisTempview) {
        this.tableGisTempview = tableGisTempview;
    }

    public String getTableGisRls() {
        return tableGisRls;
    }

    public void setTableGisRls(String tableGisRls) {
        this.tableGisRls = tableGisRls;
    }

    public String getGisByAddr() {
        return gisByAddr;
    }

    public void setGisByAddr(String gisByAddr) {
        this.gisByAddr = gisByAddr;
    }

    public String getHdfs() {
        return hdfs;
    }

    public void setHdfs(String hdfs) {
        this.hdfs = hdfs;
    }

    public String getDbGis() {
        return dbGis;
    }

    public void setDbGis(String dbGis) {
        this.dbGis = dbGis;
    }

    public String getTableGis() {
        return tableGis;
    }

    public void setTableGis(String tableGis) {
        this.tableGis = tableGis;
    }

    public String getDbFvp() {
        return dbFvp;
    }

    public void setDbFvp(String dbFvp) {
        this.dbFvp = dbFvp;
    }

    public String getTableFvp() {
        return tableFvp;
    }

    public void setTableFvp(String tableFvp) {
        this.tableFvp = tableFvp;
    }

    public Set<String> getCitycodes() {
        return citycodes;
    }

    public void setCitycodes(Set<String> citycodes) {
        this.citycodes = citycodes;
    }

    public Set<String> getOnCitycodes() {
        return onCitycodes;
    }

    public void setOnCitycodes(Set<String> onCitycodes) {
        this.onCitycodes = onCitycodes;
    }

    public String getTablePickUpPlan() {
        return tablePickUpPlan;
    }

    public void setTablePickUpPlan(String tablePickUpPlan) {
        this.tablePickUpPlan = tablePickUpPlan;
    }

    public String getTable_scan() {
        return table_scan;
    }

    public String getTableGis2() {
        return tableGis2;
    }

    public void setTableGis2(String tableGis2) {
        this.tableGis2 = tableGis2;
    }

    public String getTableGisTempview2() {
        return tableGisTempview2;
    }

    public void setTableGisTempview2(String tableGisTempview2) {
        this.tableGisTempview2 = tableGisTempview2;
    }

    public void setTable_scan(String table_scan) {
        this.table_scan = table_scan;
    }

    public String getTableGisOmsto() {
        return tableGisOmsto;
    }

    public void setTableGisOmsto(String tableGisOmsto) {
        this.tableGisOmsto = tableGisOmsto;
    }

    public Set<String> getDeptcodes(){
        Set<String> set = new HashSet<String>();
        set.add("755ADAL");
        set.add("755KNL");
        set.add("755AENL");
        return set;
    }

    public static String getString(String key) {
        String value = null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {
//            in = this.getClass().getClassLoader().getResourceAsStream("config.properties");
            in = AppConfig.class.getClassLoader().getResourceAsStream("conf/oms_pai/config.properties");
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }

    public static HashMap<String, String> citycode2Adcode(){
        HashMap<String, String> map = new HashMap<String, String>();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
            in = AppConfig.class.getClassLoader().getResourceAsStream("city_code.csv");
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            br = new BufferedReader(isr);
            String line = null;
            while((line = br.readLine()) != null){
                String[] strs = line.split(",");
                String adcode = strs[1];
                String cityCode = strs[3];
                map.put(cityCode, adcode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)
                    br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return map;
    }

    public static HashMap<String, String> getZno2DeptList(){
        HashMap<String, String> map = new HashMap<String, String>();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
            in = AppConfig.class.getClassLoader().getResourceAsStream("zno2Dept.properties");
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            br = new BufferedReader(isr);
            String line = null;
            while((line = br.readLine()) != null){
                String[] strs = line.split(",");
                String znocode = strs[0];
                String deptcode = strs[2];
                map.put(znocode, deptcode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)
                    br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return map;
    }

    public static void main(String[] args) {
//        AppConfig config = AppConfig.getInstance();
//        System.out.println(config.getOnCitycodes());
        System.out.println(new AppConfig().getTableEmpInfo());

    }
}
