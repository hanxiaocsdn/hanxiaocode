package com.sf.gis.scala.oms_shou.pojo.rds;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/8.
 */
public class OrderFromToList implements Serializable {
    private Order orderTo;
    private Order orderFrom;

    public Order getOrderTo() {
        return orderTo;
    }

    public void setOrderTo(Order orderTo) {
        this.orderTo = orderTo;
    }

    public Order getOrderFrom() {
        return orderFrom;
    }

    public void setOrderFrom(Order orderFrom) {
        this.orderFrom = orderFrom;
    }
}
