package com.sf.gis.scala.rds.util;

import java.io.Serializable;
import java.security.MessageDigest;

public class MD5Util implements Serializable {

    public static MessageDigest getMD5Instance(){
        MessageDigest md5Instance =null;
        try {
            md5Instance = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return md5Instance;
    }

    /**
     * 生成md5值
     * @param MD5Instance MD5实例
     * @param message  传入的字符串
     * @return String
     */
    public static String getMD5(MessageDigest MD5Instance, String message){
        String md5Str = null;
        try{
            byte[] inputBytes = message.getBytes();
            byte[] buff = MD5Instance.digest(inputBytes);
            md5Str = bytesToHex(buff);
        }catch(Exception e){
            e.printStackTrace();
        }
        return md5Str;
    }

    /**
     * 生成md5值
     * @param message:
     * @return String:
     */
    public static String getMD5(String message){
        String md5Str = null;
        try{
            MessageDigest md =  getMD5Instance();
            byte[] inputBytes = message.getBytes();
            byte[] buff = md.digest(inputBytes);
            md5Str = bytesToHex(buff);

        }catch(Exception e){
            e.printStackTrace();
        }


        return md5Str;
    }


    /**
     * 二进制信息转换成十六进制
     * @param bytes:
     * @return String:
     */
    private static String bytesToHex(byte[] bytes){
        StringBuilder md5Str = new StringBuilder();
        int digital;
        for (byte aByte : bytes) {
            digital = aByte;
            if (digital < 0) {
                digital += 256;
            }
            if (digital < 16) {
                md5Str.append("0");
            }
            md5Str.append(Integer.toHexString(digital));
        }

        return md5Str.toString().toUpperCase();
    }


    public static void main(String[] args) {
        String str = "我不是潘金莲";
        String md5 = getMD5(str);
        System.out.println("md5:"+md5);

    }
}