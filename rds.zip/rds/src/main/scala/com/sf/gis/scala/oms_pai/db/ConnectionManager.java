package com.sf.gis.scala.oms_pai.db;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.log4j.Logger;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Created by 01368078 on 2018/2/27.
 */
public class ConnectionManager {
    private static ConnectionManager instance;
    private static ComboPooledDataSource dataSource;
    static Logger logger = Logger.getLogger(ConnectionManager.class);

    private ConnectionManager() throws PropertyVetoException {
        dataSource = new ComboPooledDataSource();

        dataSource.setDriverClass(AppConfig.getString("driver"));
        dataSource.setJdbcUrl(AppConfig.getString("url"));
        dataSource.setUser(AppConfig.getString("username"));
        dataSource.setPassword(AppConfig.getString("password"));
        dataSource.setInitialPoolSize(Integer.parseInt(AppConfig.getString("initialPoolSize")));
        dataSource.setMinPoolSize(Integer.parseInt(AppConfig.getString("minPoolSize")));
        dataSource.setMaxPoolSize(Integer.parseInt(AppConfig.getString("maxPoolSize")));
        dataSource.setMaxStatements(Integer.parseInt(AppConfig.getString("maxStatement")));
        dataSource.setMaxIdleTime(Integer.parseInt(AppConfig.getString("maxIdleTime")));
    }

    public static ConnectionManager getInstance(){
        if(instance == null){
            synchronized (AppConfig.class){
                if(instance == null)
                    try {
                        instance = new ConnectionManager();
                    } catch (PropertyVetoException e) {
                        logger.error("创建数据库连接池异常", e);
                    }
            }
        }
        return instance;
    }

    public synchronized Connection getConn(){
        Connection conn = null;
        try {
            conn = dataSource.getConnection();
        } catch (SQLException e) {
            logger.error(String.format("获取数据库连接异常:driver-%s,db-%s,user-%s,passwd-%s", AppConfig.getString("driver"),
                    AppConfig.getString("url"), AppConfig.getString("username"), AppConfig.getString("password")), e);
        }
        return conn;
    }
}
