package com.sf.gis.scala.oms_pai.handle

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel

/**
 * Created by 01375125 on 2018/9/27.
 */
object ParseLog {
  val appName = this.getClass.getSimpleName.replace("$", "")
  @transient lazy val logger = Logger.getLogger(appName)

  /**
   * 解析日志
   *
   * @param rgeoLogRdd
   * @param inc_day
   * @return
   */
  def parseLog(rgeoLogRdd: RDD[String], inc_day: String): (RDD[JSONObject], RDD[JSONObject]) = {
    //得到每个解析的jsong格式数据
    val filterRdd = rgeoLogRdd.filter(_ != null).filter(line => {
      //        line.contains("system.log#") &&
      line.contains(inc_day) && line.contains("RGEO")
    }).map(line => {
      var result: JSONObject = null
      try {
        //          val bodyRow = Util.pickGroup1Str(line, "log#(.*)$")
        val tmp = JSON.parseObject(line)
        result = JSON.parseObject(tmp.getString("message"))
      } catch {
        case e: Exception => logger.error(">>>转json异常：" + e)
      }
      result
    }).filter(_ != null)
    logger.error(">>>过滤后的数据量：" + filterRdd.count())
    filterRdd.take(1).foreach(println)

    val validRdd = filterRdd.map(json => {
      getLineJsonObject(json)
    }).filter(_ != null).repartition(800).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("有效解析的数据量:" + validRdd.count())

    val startRdd = validRdd.filter(obj => {
      val key = obj.getString("key")
      key.equals("start")
    })
    val centreRdd = validRdd.filter(obj => {
      val key = obj.getString("key")
      key.equals("centre")
    })

    val otherRdd = validRdd.filter(obj => {
      val key = obj.getString("key")
      key.equals("other")
    })

    val returnRdd = validRdd.filter(obj => {
      val key = obj.getString("key")
      key != null && key.equals("return")
    }).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    returnRdd.persist()

    //返回的数量
    val reCount = returnRdd.count()
    logger.error(">>>有效数据中,start数量：" + startRdd.count() + ",centre数量：" + centreRdd.count() + ",return数量：" + reCount + ",other的数量：" + otherRdd.count())
    //    otherRdd.collect().foreach(o=>{logger.error("other数据:"+o)})

    //请求数据
    val reqRdd: RDD[JSONObject] = validRdd.filter(obj => {
      val key = obj.getString("key")
      key.equals("start") || key.equals("centre")
    }).map(obj => {
      val sn = obj.getString("sn")
      obj.remove("key")
      (sn, obj)
    }).reduceByKey((o1, o2) => {
      o1.fluentPutAll(o2)
      o1
    }).map(_._2).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    reqRdd.persist()
    logger.error(">>>关联后请求数据量：" + reqRdd.count())
    reqRdd.take(1).foreach(o => {
      println("req:" + o)
    })

    logger.error(">>>关联后返回数据量：" + reCount)
    returnRdd.take(1).foreach(o => {
      println("re:" + o)
    })

    validRdd.unpersist()
    (reqRdd: RDD[JSONObject], returnRdd: RDD[JSONObject])
  }

  /**
   * 对每一行数据进行解析,请求和返回分开
   *
   */
  def getLineJsonObject(body: JSONObject): JSONObject = {
    var result: JSONObject = null
    try {
      var sn: String = null
      var key: String = null
      if (body != null) {
        val appName = body.getString("appName")
        if (appName != null && appName.equals("RGEO")) {
          sn = body.getString("sn")
          var body_name: String = null
          val _type = body.getString("type")
          if (_type.equals("url_s")) {
            key = "start"
            body_name = "start_body"
          } else if (_type.equals("url_e")) {
            key = "return"
            body_name = "return_body"
          } else if (_type.equals("zh") || _type.equals("bd") || _type.equals("gd") || _type.equals("sf")) {
            key = "centre"
            body_name = "centre_body"
          } else {
            key = "other"
            body_name = "other_body"
          }
          result = new JSONObject()
          result.put("sn", sn)
          result.put("key", key)
          result.put(body_name, body)
        }
      }

    } catch {
      case e: Exception => logger.error(">>>数据解析异常," + e)
    }
    result
  }


}
