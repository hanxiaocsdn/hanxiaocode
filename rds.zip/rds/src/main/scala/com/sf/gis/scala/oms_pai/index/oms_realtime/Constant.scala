package com.sf.gis.scala.oms_pai.index.oms_realtime

/**
  * Created by 01368078 on 2019/3/5.
  */
object Constant {
  val NO_MATCH = "1"
  val SINGLE_GROUP = "2"
  val MULTI_GROUP = "3"
  val ADDRESS_OTHER_CITY = "4"
  val ADDRESS_0_1 = "5"
  val DEPT = "6"
  val ADDRESS_ENG = "7"
  val ADDRESS_NUM_SYMB_BLANK = "8"
  val KEY_WORD_EXISTS = "9"
  val SHORT_TEXT = "10"
  val MARK_13 = "11"
  val MARK_9 = "12"
  val MARK_6 = "13"
  val MARK_4 = "14"
  val MARK_OTHER = "15"
  val MARK_OUT_SERVICE = "16"
  val MARK_9_11 = "17"
  val MAKR_SINGLE_GROUP_NOZC = "18"
  val MAKR_SINGLE_GROUP_ZC = "19"
  val MAKR_MULTI_GROUP_NOZC = "20"
  val MAKR_MULTI_GROUP_ZC = "21"
  val MARK_5 = "22"
  val MARK_3 = "23"
  val MARK_2 = "24"
  val SEP = "\\$"
}
