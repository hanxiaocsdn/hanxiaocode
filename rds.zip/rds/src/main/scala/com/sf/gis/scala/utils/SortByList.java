package com.sf.gis.scala.utils;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.List;
import java.util.stream.Stream;

/**
 * Created by 01375125 on 2018/11/19.
 */
public class SortByList {



    /**
     * 将传入的list根据时间排序，并且取前5个数据
     * @param list
     * @return
     */
    public static List<JSONObject> sortByReqTime(List<JSONObject> list,int num ){
        list.sort((o1,o2) -> o2.getString("req_time").compareTo(o1.getString("req_time")));
        int size = list.size();
        if(list.size() > num){
            size=num;
        }
        return list.subList(0, size);
    }





    /**
     * 将传入的list根据时间排序，并且取前5个数据
     * @param list
     * @return
     */
    public static JSONArray sortByReqTime30Day(List<JSONObject> list ,int num){
        list.sort((o1,o2) -> o2.getString("req_time").compareTo(o1.getString("req_time")));
        int size = list.size();
        if(size > num){
            size = num ;
        }
        JSONArray jsonArr = new JSONArray();
        for (int i = 0; i < size; i++) {
            jsonArr.add(list.get(i));
        }
        return jsonArr;
    }

    public static void main(String[] args) {
        Integer[] sixNums = {1, 2, 3, 4, 5, 6};
        Integer[] evens =Stream.of(sixNums).filter(n -> n%2 == 0).toArray(Integer[]::new);

    }





}
