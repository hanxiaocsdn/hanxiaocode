package com.sf.gis.scala.oms_shou.main

import java.text.DecimalFormat
import java.util
import java.util.Properties

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.com.sf.gis.scala.oms_shou.constant.FixedConstant
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_shou.constant.{AppType, VariableConstant}
import com.sf.gis.scala.oms_shou.pojo.rds.OmsReqBody
import com.sf.gis.scala.oms_shou.pojo.{AdminArea, ErrCallData, OrderData, OrderInfo}
import com.sf.gis.scala.utils.{ConfigurationUtil, DateUtil, StringUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * 任务id:225056，225129，225128
 * * @TaskName:rds收件指标系统
 * 业务方：01394694（郭本婕）
 * 研发：01399581（匡仁衡）
 */
object ChkShouLogParser {

  @transient lazy val logger: Logger = LoggerFactory.getLogger(ChkShouLogParser.getClass)
  val props: Properties = ConfigurationUtil.loadProperties(VariableConstant.CONF, FixedConstant.CHARSET)
  val appName: String = props.getProperty("app.name")

  //揽收表
  val tt_pickup_task_ex = "ods_inc_sgs_core.tt_pickup_task_ex"
  val tt_pickup_task = "ods_inc_sgs_core.tt_pickup_task"
  val chk_shou_pick_up_info_mid_table = "dm_gis.chk_shou_pick_up_info_mid"
  //写入hbase表
  val hbaseTableName = "dm_gis.rds_omsfrom_tohbase_new"
  //写入错call表
  val errCallHiveTable = "dm_gis.dm_rds_err_call_di"
  //日志hive表
  val omsFromTable = "dm_gis.gis_rds_omsfrom"
  val omsFromTableOther = "dm_gis.gis_rds_omsfrom_other"

  //默认运行模式 只存储hive
  val defaultRunFlag = "onlySaveHive"
  //默认的揽收模式：从yuanbiao获取
  val defaultPickupMode = "origin"

  var isTest = false


  def main(args: Array[String]): Unit = {
    //标识是否是当日，当日不需要揽收
    var appDays = args(0).toInt
    //日志日期 需要分隔符分隔
    var dateSep = args(1)
    //存储标志，主要用于hbase表和指标的统计控制
    var runFlag = args(2)
    //揽收表获取， 存在几种模式，t-1的不做强制要求关联，防止报错
    var pickUpTableMode = args(3)
    start(dateSep, appDays, runFlag, pickUpTableMode)
  }

  def start(dateSep: String, appDays: Int,
            runFlag: String, pickUpTableMode: String): Unit = {
    logger.info(s">>>dateSep : $dateSep")
    val spark = Spark.getSparkSession(appName)
    run(spark, dateSep, appDays, runFlag, pickUpTableMode)
  }


  def getDateList(appType: Int, date: String, dateFormat: String, days: Int): util.ArrayList[String] = {
    val dateList = new util.ArrayList[String]()
    dateList.add(date)
    if (appType != AppType.REALTIME_TYPE) {
      for (i <- 1 to days) {
        dateList.add(0, DateUtil.dateBefore(dateFormat, -i, date))
      }
    }
    dateList
  }

  def orderByDataTime(spark: SparkSession, orderRdd: RDD[JSONObject]) = {
    logger.error("按照订单号聚合，保留时间最完的数据请求id做聚合运算")
    val latestReqDataRdd = orderRdd.map(obj => {
      (obj.getString("sysOrderNo"), (obj.getString("reqId"), obj.getString("dataTime")));
    }).reduceByKey((obj1, obj2) => {
      if (obj1._2 > obj2._2) {
        obj1
      } else {
        obj2
      }
    }).map(obj => {
      (obj._1 + "##" + obj._2._1, 0)
    })
    logger.error("按照系统订单号回挂数据")
    orderRdd.map(obj => {
      (obj.getString("sysOrderNo") + "##" + obj.getString("reqId"), obj)
    }).leftOuterJoin(latestReqDataRdd).map(obj => {
      val leftBody = obj._2._1
      val rightOpt = obj._2._2
      if (rightOpt.nonEmpty) {
        //给最晚的那条打上标签
        leftBody.put("tag", 1)
      }
      leftBody
    })
  }

  def run(spark: SparkSession,
          dateSep: String,
          appDays: Int,
          runFlag: String, pickUpTableMode: String): Unit = {
    val incDay: String = dateSep.replaceAll("-", "")

    logger.error(">>>获取错柯数据")
    val errcallDayList = getDateList(appDays, incDay, FixedConstant.DATE_FORMAT2, 2)
    var errCallRdd = getErrCallData(spark.sparkContext, errcallDayList)
    if (errCallRdd == null) {
      return
    }
    errCallRdd = errCallRdd.repartition(500).persist(StorageLevel.DISK_ONLY_2)
    logger.error(">>>错柯量 : {}", errCallRdd.count())
    Spark.clearPersistWithoutId(spark, errCallRdd.id)

    logger.error("获取原始数据")
    val logs = readDataNew(spark, incDay, appDays, dateSep)
      .persist(StorageLevel.DISK_ONLY_2) //加载日志
    logger.error(">>>日志量: {}", logs.count())


    logger.error(">>>开始解析日志.")
    val validLogRdd = parseLog(logs)
    logger.error(">>>开始聚合日志.")
    val orderRdd = reduceByOrder(spark, validLogRdd, errCallRdd,
      appDays, incDay, pickUpTableMode) //请求rdd
    Spark.clearPersistWithoutId(spark, orderRdd.id)

    logger.error(">>>开始存储")
    if (!"onlySaveHive".equals(runFlag)) {
      logger.error("存储所有数据到hbase")
      saveHbaseDataToHive(spark, orderRdd, incDay, true)
    } else {
      logger.error("存储下call数据到hbase")
      saveHbaseDataToHive(spark, orderRdd, incDay, false)
    }

    Spark.clearPersistWithoutId(spark, orderRdd.id)
    logger.error("开始处理hive存储日志")
    logger.error("系统订单聚合，提取请求id，进行排序，获取最晚请求进行打标签")
    val orderByRdd = orderByDataTime(spark, orderRdd).persist(StorageLevel.DISK_ONLY_2)
    logger.error("排序的量：" + orderByRdd.count())
    Spark.clearPersistWithoutId(spark, orderByRdd.id)
    logger.error("转化日志格式")
    val singleDateRdd = orderByRdd.map(obj => {
      converData(obj)
    })
    logger.error("开始存储")
    saveLogSingle(spark, singleDateRdd, incDay, runFlag)

    if (!"onlySaveHive".equals(runFlag)) {
      logger.error(">>>开始统计指标")
      val latestRdd = singleDateRdd.filter(obj => obj.getTag == 1).persist(StorageLevel.DISK_ONLY_2)
      logger.error("最后的请求单数：" + latestRdd.count())
      Spark.clearPersistWithoutId(spark, latestRdd.id)
      statLog(spark, latestRdd, incDay)
    }

    logger.error("the end~")
  }

  def statLog(spark: SparkSession, orderRdd: RDD[OrderData], incDay: String): Unit = {
    val statistics = new LogStatistics
    val adminAreaMap: util.Map[String, util.List[AdminArea]] = new AdminAreaLoader().loadAdminArea()
    logger.error(">>>stat pu buz")
    statistics.statPuBuz(orderRdd, incDay, adminAreaMap, spark)
    logger.error(">>>stat pu tc")
    logger.error("获取楼栋范围aoiid数据")
    val joinBidRdd = joinBid(orderRdd, spark)
    statistics.statPuTc(joinBidRdd, incDay, adminAreaMap, spark, null, null)
  }

  def convertBidAoi(spark: SparkSession, bidAoiInfoRdd: RDD[(String, Int)]) = {
    val bidAoiInfoMap = bidAoiInfoRdd.map(obj => {
      ((obj._1.hashCode % 5000).toString, (obj._1, obj._2))
    }).groupByKey().map(obj => {
      val map = new util.HashMap[String, Int]()
      val iter = obj._2.iterator
      while (iter.hasNext) {
        val tmp = iter.next()
        map.put(tmp._1, tmp._2)
      }
      (obj._1, map)
    }).collectAsMap()
    logger.error("bidAoi hash后数量:" + bidAoiInfoMap.size)
    //    logger.error("keys:"+bidAoiInfoMap.keySet.mkString(","))
    spark.sparkContext.broadcast(bidAoiInfoMap)
  }

  def joinBid(resultLog: RDD[OrderData], spark: SparkSession): RDD[OrderData] = {
    val bidAoiInfoRdd = fetchBidInfo(spark)
    logger.error("转化为hash值")
    val bidAoiBc = convertBidAoi(spark, bidAoiInfoRdd)
    bidAoiInfoRdd.unpersist()
    val resultLogFinal = resultLog.map(obj => {
      val aoiId = obj.getAoiId
      if (aoiId != null && !aoiId.isEmpty) {
        val hashValue = (aoiId.hashCode % 5000).toString
        val bidMap = bidAoiBc.value
        if (!aoiId.isEmpty && bidMap.contains(hashValue)) {
          val aoiidInfo = bidMap.get(hashValue).get
          if (aoiidInfo.contains(aoiId)) {
            obj.setBidAoiState(aoiidInfo.get(aoiId).toString)
          }
        }
      }
      obj
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("关联楼栋aoiid数据完毕:" + resultLogFinal.count())
    resultLog.unpersist()
    resultLogFinal
  }

  def joinBidNew(resultLog: RDD[OrderData], spark: SparkSession): RDD[OrderData] = {
    val bidAoiInfoRdd = fetchBidInfo(spark)
    val resultLogNoFinalAoi = resultLog.filter(obj => obj.getAoiId == null || obj.getAoiId.isEmpty).persist(StorageLevel.DISK_ONLY_2)
    logger.error("无aoi数据：" + resultLogNoFinalAoi.count())
    val resultLogFinalAoi = resultLog.filter(obj => obj.getAoiId != null && !obj.getAoiId.isEmpty).persist(StorageLevel.DISK_ONLY_2)
    logger.error("有aoi数据：" + resultLogFinalAoi.count())
    resultLog.unpersist()
    val resultLogFinal = leftOuterJoinOfLeftLeanElem(resultLogFinalAoi.map(obj => {
      (MD5Util.getMD5(obj.getAoiId), obj)
    }), bidAoiInfoRdd, 10, 50).map(obj => {
      val left = obj._2._1.asInstanceOf[OrderData]
      val rightOp = obj._2._2
      if (rightOp.nonEmpty) {
        val right = rightOp.get
        left.setBidAoiState(right + "")
      }
      left
    }).union(resultLogNoFinalAoi).persist(StorageLevel.DISK_ONLY_2)
    logger.error("关联楼栋aoiid数据完毕:" + resultLogFinal.count())
    resultLogFinalAoi.unpersist()
    resultLogNoFinalAoi.unpersist()
    bidAoiInfoRdd.unpersist()
    resultLogFinal
  }

  /**
   * 左关联，左表存在少部分key倾斜，采用单独处理部分key的方式
   *
   * @param left    左表
   * @param right   右表
   * @param hashNum 散列系数，扩容倍数
   * @param topLean 需要单独处理的倾斜数据量
   */
  def leftOuterJoinOfLeftLeanElem(left: RDD[(String, Object)], right: RDD[(String, Int)], hashNum: Int, topLean: Int = 10): RDD[(String, (Object, Option[Int]))] = {
    val keyCounts = left.map(obj => (obj._1, 1)).reduceByKey(_ + _).sortBy(-_._2).take(topLean)
    val keys = keyCounts.map(obj => obj._1)
    val counts = keyCounts.map(obj => obj._2).sum
    logger.error("单独处理的keys:" + keyCounts.mkString(","))
    logger.error("单独处理的总数量:" + counts)
    //拆分数据为独立处理的key和非独立处理的key
    val leftHashKeyData = left.filter(obj => keys.contains(obj._1))
    val leftOtherData = left.filter(obj => !keys.contains(obj._1))
    val rightHashKeyData = right.filter(obj => keys.contains(obj._1))
    val rightOtherData = right.filter(obj => !keys.contains(obj._1))
    //先关联其他key数据
    val otherJoin = leftOtherData.leftOuterJoin(rightOtherData)
    //扩展单独处理的数据
    val leftHashKeyDataExpand = leftHashKeyData.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      (("00" + hashPrefix, obj._1), obj._2)
    })
    val rightHashKeyDataExpand = rightHashKeyData.flatMap(obj => {
      val dataArray = new ArrayBuffer[((String, String), Int)]()
      for (i <- 0 until hashNum) {
        dataArray.append((("00" + i, obj._1), obj._2))
      }
      dataArray.iterator
    })
    //关联数据
    val hashKeyJoin = leftHashKeyDataExpand.leftOuterJoin(rightHashKeyDataExpand).map(obj => (obj._1._2, obj._2))
    hashKeyJoin.union(otherJoin)
  }

  def fetchBidInfo(spark: SparkSession): RDD[(String, Int)] = {
    val sql = " with a as (select distinct aoi_id from dm_gis.t_dm_tmp_aoi_sp_cnt_dist_v1_aoi_list )," +
      " b as (select distinct aoi_id from dm_gis.bid_aoi_reject where data_type='publish') " +
      " select a.aoi_id,if(b.aoi_id is null,0,1) reject from a left join b on a.aoi_id=b.aoi_id "
    logger.error(sql)
    val bidAoiInfoRdd = spark.sql(sql).rdd.map(obj => {
      (obj.getString(0), obj.getInt(1))
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("楼栋的aoi数量:" + bidAoiInfoRdd.count())
    logger.error("楼栋的剔除aoi数量" + bidAoiInfoRdd.filter(obj => obj._2 == 1).count())
    bidAoiInfoRdd
  }

  def fetchAoiidReject(spark: SparkSession): Broadcast[Array[String]] = {
    val sql = "select aoi_id from dm_gis.bid_aoi_reject where data_type='publish' and aoi_id is not null and aoi_id<> ''  group by aoi_id"
    logger.error(sql)
    val dataArray = spark.sql(sql).rdd.map(obj => {
      obj.getString(0)
    }).collect()
    spark.sparkContext.broadcast(dataArray)
  }

  def fetchAoiidSet(spark: SparkSession): Broadcast[Array[String]] = {
    val sql = "select aoi_id from dm_gis.t_dm_tmp_aoi_sp_cnt_dist_v1_aoi_list where aoi_id is not null and aoi_id<> '' group by aoi_id"
    logger.error(sql)
    val dataArray = spark.sql(sql).rdd.map(obj => {
      obj.getString(0)
    }).collect()
    spark.sparkContext.broadcast(dataArray)
  }

  def converData(obj: JSONObject) = {
    val orderInfo = JSON.toJavaObject(obj, classOf[OrderInfo])
    //      (JSON.parseObject(JSON.toJSONString(orderInfo, SerializerFeature.PrettyFormat)), pickValuableInfo(orderInfo))
    val orderData = pickValuableInfo(orderInfo)
    orderData.setSyncReqBody(obj.getJSONObject("syncReqBody"))
    orderData.setAsyncReqBody(obj.getJSONObject("asyncReqBody"))
    orderData.setSyncReBody(obj.getJSONObject("syncReBody"))
    orderData.setAsyncReBody(obj.getJSONObject("asyncReBody"))
    orderData.setArssReBody(obj.getJSONObject("arssReBody"))
    orderData.setTag(orderInfo.getTag)
    val rdsArssReqBody = obj.getJSONObject("rdsArssReqBody")
    val arssReqBody = obj.getJSONObject("arssReqBody")
    if (arssReqBody != null) {
      //此处优先使用这个，但是实际貌似为空，疑似作废
      orderData.setArssReqBody(arssReqBody)
    } else {
      orderData.setArssReqBody(rdsArssReqBody)
    }
    orderData
  }

  def readDataNew(spark: SparkSession,
                  incDay: String,
                  appDays: Int,
                  dateSep: String
                 ): RDD[String] = {
    val tmpDateList: util.ArrayList[String] = getDateList(appDays, dateSep, FixedConstant.DATE_FORMAT, 1)
    logger.error("tmpDateList:" + tmpDateList.mkString(","))
    val incDayList: util.ArrayList[String] = getDateList(appDays, incDay, FixedConstant.DATE_FORMAT2, 1)
    logger.error("incDayList:" + incDayList.mkString(","))
    val beginDay = incDayList(incDayList.length - 1)
    val endDay = incDayList(0)
    //    val endDay="20210609"
    val today = DateUtil.dateBefore(FixedConstant.DATE_FORMAT2, 0)
    var logTableName = "dm_gis.chk_shou_log_flink_collect"
    if (today.equals(beginDay) && today.equals(endDay)) {
      logTableName = "dm_gis.chk_shou_log_flink"
    }
    var sql = s"select log from $logTableName where " +
      s" inc_day between '$beginDay' and '$endDay' "
    //    sql = sql+" and log like '%CX2759568827916294%' "
    logger.error(sql)
    val logs = spark.sql(sql).rdd.map(row => {
      row.getString(0)
    }).filter(line => {
      //      (line.contains(VariableConstant.LOG_MARKER) || checkChkKsData(line)) && checkDate(line, dateList)
      line.contains("dataType") && checkDate(line, tmpDateList)
    })
    //      .map(obj => {
    //      (obj, null)
    //    }).reduceByKey((obj1, _) => {
    //      obj1
    //    })
    //      .keys
    logs
  }

  def checkDate(line: String, dateList: util.ArrayList[String]): Boolean = {
    for (date <- dateList) {
      if (line.contains(date))
        return true
    }
    false
  }

  def parseLog(logs: RDD[String]): RDD[(String, JSONObject)] = {
    val parser = new LogParser()
    val logRdd = parser.parse(logs)
    logRdd
  }

  def getErrCallData(sc: SparkContext, incDayList: util.ArrayList[String]): RDD[(String, JSONObject)] = {
    var errCallRdd: RDD[(String, JSONObject)] = null
    val errCallGetter = new ErrCallGetter()
    for (day <- incDayList) {
      val errCallRddTmp: RDD[(String, JSONObject)] = errCallGetter.getErrCallDataNewShidian(sc, day).persist(StorageLevel.DISK_ONLY_2)
      logger.error("错柯数量:" + errCallRddTmp.count())
      if (errCallRddTmp.count() > 0) {
        if (errCallRdd == null)
          errCallRdd = errCallRddTmp
        else
          errCallRdd = errCallRdd.union(errCallRddTmp)
      }
    }
    if (errCallRdd == null) {
      errCallRdd = sc.makeRDD(List())
    }
    errCallRdd
  }


  def joinPickUpInfo(spark: SparkSession, omsFromSysOrderNoRdd: RDD[(String, JSONObject)],
                     incDay: String, pickUpTableMode: String,
                     appDays: Int) = {
    logger.error("获取揽收信息,key为系统订单号和订单号组成")
    val pickUpRdd = selectAllPickUpInfo(spark, incDay, appDays, pickUpTableMode)

    logger.error("系统订单号关联揽收")
    val stepRdd1 = joinPickUpRdd(spark, omsFromSysOrderNoRdd, pickUpRdd).persist(StorageLevel.DISK_ONLY_2)
    logger.error("系统订单号关联揽收后数量：" + stepRdd1.count())
    omsFromSysOrderNoRdd.unpersist()

    logger.error("订单号关联揽收")
    val noExistData = stepRdd1.filter(obj => !obj._2.containsKey("pickupBody") && obj._2.getString(VariableConstant.ORDERNO_KEY) != null).map(obj => {
      (obj._2.getString(VariableConstant.ORDERNO_KEY), obj._2)
    })
    val existData = stepRdd1.filter(obj => obj._2.containsKey("pickupBody") || obj._2.getString(VariableConstant.ORDERNO_KEY) == null)

    val stepRdd2 = joinPickUpRdd(spark, noExistData, pickUpRdd)
    val joinDataRdd = existData.union(stepRdd2).repartition(3200).persist(StorageLevel.DISK_ONLY_2)
    logger.error("全部关联揽收后数量：" + joinDataRdd.count())
    pickUpRdd.unpersist()
    stepRdd1.unpersist()
    joinDataRdd
  }

  def reduceByOrder(spark: SparkSession, rdd: RDD[(String, JSONObject)],
                    errCallRdd: RDD[(String, JSONObject)],
                    appDays: Int, incDay: String,
                    pickUpTableMode: String
                   ): RDD[JSONObject] = {
    val omsFromSysOrderNoRdd = rdd.reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).filter(obj => {
      val reqDate = JSONUtil.getJsonValSingle(obj._2, "dataTime", "")
      //目前只有包含异步或者同步请求时，才会有dataTime，所以dataTime能当做同步异步的标志，并且用来判断是否是当天请求
      reqDate.replaceAll("-", "").contains(incDay)
      //      val (reqDate, asyncReqFlag, syncReqFlag) = findReqDate(obj._2)
      //      ((asyncReqFlag || syncReqFlag) && incDay.equals(reqDate))
    }).map(tp => (tp._2.getString("sysOrderNo"), tp._2)).persist(StorageLevel.DISK_ONLY_2)
    logger.error("按请求id聚合数量:" + omsFromSysOrderNoRdd.count())
    rdd.unpersist()
    var mergePickUpRdd = omsFromSysOrderNoRdd
    if (appDays != AppType.REALTIME_TYPE) {
      //关联揽收
      mergePickUpRdd = joinPickUpInfo(spark, omsFromSysOrderNoRdd, incDay, pickUpTableMode, appDays)
    } else {
      logger.error("当天数据，不关联揽收")
    }

    val errCall = spark.sparkContext.broadcast(errCallRdd.collect())
    val newRdd = mergePickUpRdd.filter(tp => StringUtils.isNotEmpty(tp._2.getString("sysOrderNo"))).map(tp => {
      val obj = tp._2
      val sysOrderNo = obj.getString("sysOrderNo")
      val errCallList = errCall.value.filter(o => sysOrderNo.equals(o._1)).map(o => o._2)
      if (errCallList.length > 0) {
        for (elem <- errCallList) {
          obj.fluentPutAll(elem)
        }
      }
      obj
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error(">>>请求维度数量 : {}", newRdd.count())
    mergePickUpRdd.unpersist()
    errCallRdd.unpersist()
    newRdd
  }


  def joinPickUpRdd(spark: SparkSession, rdd: RDD[(String, JSONObject)], pickUpRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    // 每个分区前4 还未上线 ，上线需要考虑driver内存是否要添加 rdd.getNumPartitions*4
    // logger.error("系统订单号/订单号每个分区前4")
    logger.error("系统订单号/订单号前10统计")
    val tuples1 = rdd.map(tp => (tp._1, 1)).reduceByKey((o1, o2) => o1 + o2).sortBy(_._2, ascending = false).take(200)
    tuples1.take(200).foreach(tp => logger.error(tp.toString()))
    val maxSysOrderNoTuple = tuples1.map(obj => obj._1)
    //    logger.error("maxSysOrderNoTuple:" + maxSysOrderNoTuple)

    val eqMaxsysOrderNoRdd = rdd.filter(tp => maxSysOrderNoTuple.contains(tp._1))
    //      .persist(StorageLevel.DISK_ONLY_2)
    val noEqMaxsysOrderNoRdd = rdd.filter(tp => !maxSysOrderNoTuple.contains(tp._1))
    //      .persist(StorageLevel.DISK_ONLY_2)
    //    logger.error("eqMaxsysOrderNoRdd cnt:" + eqMaxsysOrderNoRdd.count())
    //    logger.error("noEqMaxsysOrderNoRdd cnt:" + noEqMaxsysOrderNoRdd.count())
    //    rdd.unpersist()

    val pickUpEqNoMap = pickUpRdd.filter(tp => maxSysOrderNoTuple.contains(tp._1)).collectAsMap()
    //      .persist(StorageLevel.DISK_ONLY_2)
    //    val cnt = pickUpEqNoRdd.count()
    //    logger.error("pickUpEqNoRdd cnt:" + cnt)

    //    var joinPickRdd1 = eqMaxsysOrderNoRdd
    //    if (cnt > 0) {
    //      val pickUpMaxSysOrderNo = pickUpEqNoRdd.map(tp => tp._2).collect()(0)
    val pickUpMaxSysOrderNoBc = spark.sparkContext.broadcast(pickUpEqNoMap)
    var joinPickRdd1 = eqMaxsysOrderNoRdd.map(tp => {
      val leftObj = tp._2
      val pickUpEqNoMap = pickUpMaxSysOrderNoBc.value
      if (pickUpEqNoMap.contains(tp._1)) {
        val rightObj = pickUpEqNoMap.apply(tp._1)
        val pickUpObj = rightObj.getJSONObject("pickup")
        if (pickUpObj != null) {
          //            val pickUpObj = pickUpArray.getJSONObject(0)
          val pickUpObjRet = new JSONObject()
          pickUpObjRet.put("pick_up_tc", pickUpObj.getString("tc"))
          pickUpObjRet.put("resource_id", pickUpObj.getString("resource_id"))
          pickUpObjRet.put("current_state", pickUpObj.getString("current_state"))
          leftObj.put("pickupBody", pickUpObjRet)
        }
      }
      (leftObj.getString("reqId"), leftObj)
    })
    //      .persist(StorageLevel.DISK_ONLY_2)
    //      logger.error("joinPickRdd1 cnt:" + joinPickRdd1.count())
    //      eqMaxsysOrderNoRdd.unpersist()
    //    } else {
    //      joinPickRdd1 = eqMaxsysOrderNoRdd.map(tp => {
    //        val leftObj = tp._2
    //        (leftObj.getString("reqId"), leftObj)
    //      }).persist(StorageLevel.DISK_ONLY_2)
    //      logger.error("joinPickRdd1 cnt:" + joinPickRdd1.count())
    //      eqMaxsysOrderNoRdd.unpersist()
    //    }

    val joinPickRdd2 = noEqMaxsysOrderNoRdd.leftOuterJoin(pickUpRdd).map(obj => {
      val leftObj = obj._2._1
      val rightObj = obj._2._2
      if (rightObj.nonEmpty) {
        val pickUpObj = rightObj.get.getJSONObject("pickup")
        if (pickUpObj != null) {
          //          val pickUpObj = pickUpArray.getJSONObject(0)
          val pickUpObjRet = new JSONObject()
          pickUpObjRet.put("pick_up_tc", pickUpObj.getString("tc"))
          pickUpObjRet.put("resource_id", pickUpObj.getString("resource_id"))
          pickUpObjRet.put("current_state", pickUpObj.getString("current_state"))
          leftObj.put("pickupBody", pickUpObjRet)
        }
      }
      (leftObj.getString("reqId"), leftObj)
    })
    //      .persist(StorageLevel.DISK_ONLY_2)
    //    logger.error("joinPickRdd2 cnt:" + joinPickRdd2.count())
    //    noEqMaxsysOrderNoRdd.unpersist()

    val unionRdd = joinPickRdd1.union(joinPickRdd2)
    //      .persist(StorageLevel.DISK_ONLY_2)
    //    logger.error("unionRdd cnt:" + unionRdd.count())
    //    joinPickRdd1.unpersist()
    //    joinPickRdd2.unpersist()
    unionRdd

  }

  /**
   * 提取需要的字段
   *
   * @param orderInfo : 数据体
   * @return
   */
  def pickValuableInfo(orderInfo: OrderInfo): OrderData = {
    val orderData = new OrderData
    val arssReqBody = orderInfo.getArssReqBody
    val arssReBody = orderInfo.getArssReBody
    val syncReqBody = orderInfo.getSyncReqBody
    val syncReBody = orderInfo.getSyncReBody
    val asyncReqBody = orderInfo.getAsyncReqBody
    val asyncReBody = orderInfo.getAsyncReBody
    val rdsArssReqBody = orderInfo.getRdsArssReqBody
    val errCallBody = orderInfo.getErrCallBody
    orderData.setSysOrderNo(orderInfo.getSysOrderNo)

    orderData.setDataTime(orderInfo.getDataTime)
    orderData.setReqId(orderInfo.getReqId)

    orderData.setChkKsReBody(orderInfo.getChkKsReBody)
    orderData.setChkKsReqBody(orderInfo.getChkKsReqBody)
    orderData.setChkOmsRebody(orderInfo.getChkOmsRebody)
    orderData.setPickupBody(orderInfo.getPickupBody)
    orderData.setRequestBuildingBody(orderInfo.getRequestBuildingBody)
    orderData.setResponseBuildingBody(orderInfo.getResponseBuildingBody)
    orderData.setAtShouBody(orderInfo.getAtShouBody)
    var omsReqData: OmsReqBody = null

    CopyProperties.syncReq2OrderData(orderData, syncReqBody)
    if (syncReqBody != null) {
      omsReqData = syncReqBody
    }

    CopyProperties.syncRe2OrderData(orderData, syncReBody)

    CopyProperties.asyncReq2OrderData(orderData, asyncReqBody)
    if (asyncReqBody != null) {
      omsReqData = asyncReqBody
    }

    CopyProperties.asyncRe2OrderData(orderData, asyncReBody)

    //    CopyProperties.omsReqData2OrderData(orderData, omsReqData)

    CopyProperties.rdsArssReq2OrderData(orderData, rdsArssReqBody)

    CopyProperties.arssReq2OrderData(orderData, arssReqBody)

    CopyProperties.arssRe2OrderData(orderData, arssReBody)
    CopyProperties.omsReqData2OrderData(orderData, omsReqData)
    CopyProperties.errCall2OrderData(orderData, errCallBody)

    if (arssReBody != null) {
      orderData.setStatus(VariableConstant.UNMATCH_STATUS)
      orderData.setSrc(VariableConstant.SRC_CHKE_CUR)
      orderData.setDeptCode(orderData.getArssDeptCode)
      orderData.setTeamCode(orderData.getArssTeamCode)
      orderData.setAoiCode(orderData.getArssAoiCode)
      orderData.setAoiId(orderData.getArssAoiId)
    } else if (asyncReBody != null) {
      orderData.setStatus(orderData.getAsyncReStatus)
      orderData.setSrc(orderData.getAsyncSrc)
      orderData.setGroupId(orderData.getAsyncGroupId)
      orderData.setDeptCode(orderData.getAsyncDeptCode)
      orderData.setTeamCode(orderData.getAsyncTeamCode)
      orderData.setAoiCode(orderData.getAsyncAoiCode)
      orderData.setAoiId(orderData.getAsyncAoiId)
    } else {
      orderData.setStatus(orderData.getSyncReStatus)
      orderData.setSrc(orderData.getSyncSrc)
      orderData.setGroupId(orderData.getSyncGroupId)
      orderData.setDeptCode(orderData.getSyncDeptCode)
      orderData.setTeamCode(orderData.getSyncTeamCode)
      orderData.setAoiCode(orderData.getSyncAoiCode)
      orderData.setAoiId(orderData.getSyncAoiId)
    }
    orderData
  }

  def saveErrCallDataToHive(spark: SparkSession, incDay: String, errCallData: RDD[ErrCallData]) = {

    import spark.implicits._
    val tmpViewName = "tmp_" + System.currentTimeMillis()
    errCallData.map(obj => {
      ErrCall(obj.getId, obj.getReqDate, obj.getReqTime, obj.getFrequency, obj.getSysOrderNo,
        obj.getProvince, obj.getCity, obj.getCounty, obj.getCityCode, obj.getAddress,
        obj.getMatchSrc, obj.getSrcDetail, obj.getMatchDept, obj.getMatchTeam, obj.getMatchGroupId,
        obj.getErrCallDept, obj.getErrCallTeam, obj.getErrCallAddrAbb, obj.getChkDept, obj.getChkTeam,
        obj.getChkEmpId, obj.getChkModifyUser, obj.getMiningDept, obj.getMiningTeam, obj.getErrCallDate,
        obj.getCompany, obj.getPhone, obj.getMobile, obj.getAoiId, obj.getCurrent_state,
        obj.getPick_up_tc, obj.getResource_id, obj.getIs_wrong_report)
    }).repartition(5).toDF().createOrReplaceTempView(tmpViewName)
    val sql = s" insert overwrite table ${errCallHiveTable} partition(inc_day='${incDay}') select * from ${tmpViewName}"
    logger.error(sql)
    spark.sql(sql)
  }

  def saveLogSingle(spark: SparkSession, orderDataRdd: RDD[OrderData],
                    incDay: String, runFlag: String): Unit = {
    val conservator = new LogConservator
    logger.error("保存日期:" + incDay)
    if (!"onlySaveHive".equals(runFlag)) {
      logger.error(">>>save errCall data")
      val errCallData = getErrCallData(orderDataRdd.filter(obj => {
        obj.getTag == 1 && obj.isErrCallFlag
      }))
      //存储错call数据到hive表
      saveErrCallDataToHive(spark, incDay, errCallData)
    }

    logger.error(">>>save log to hive.")
    //    val rdd = orderDataRdd.filter(tp => {
    //      tp.isSyncReqFlag || tp.isAsyncReqFlag
    //    }).persist(StorageLevel.DISK_ONLY_2)
    //    logger.error("rdd cnt:{}", rdd.count())
    val latestRdd = orderDataRdd.filter(obj => obj.getTag == 1)
    if(isTest){
      saveLogToHive(spark, latestRdd, incDay, "tmp_dm_gis.tmp_gis_rds_omsfrom_01374443")
      return
    }
    saveLogToHive(spark, latestRdd, incDay, omsFromTable)
    val otherRdd = orderDataRdd.filter(obj => obj.getTag != 1)
    saveLogToHive(spark, otherRdd, incDay, omsFromTableOther)
    logger.error(">>>over")
  }

  def findPoiInfo(obj: OrderData): (String, String, String) = {
    //审补
    val aoiInfo = JSONUtil.getJsonVal(obj.getArssReBody, "data.orderFrom.aoiInfo", "");
    var poiCode = ""
    var poiId = ""
    if ("1".equals(aoiInfo)) {
      poiCode = JSONUtil.getJsonVal(obj.getArssReBody, "data.orderFrom.aoiCode", "");
      poiId = JSONUtil.getJsonVal(obj.getArssReBody, "data.orderFrom.aoiId", "");
    }
    if (!poiCode.isEmpty) {
      return (poiId, poiCode, "arss")
    }
    //异步
    //默认此字段为poi字段，asyncPoiId有id则有code
    var asyncPoiCode = JSONUtil.getJsonVal(obj.getAsyncReBody, "ret.entityAoiCode", "")
    val asyncPoiId = JSONUtil.getJsonVal(obj.getAsyncReBody, "ret.poiId", "")
    if (!asyncPoiId.isEmpty) {
      return (asyncPoiId, asyncPoiCode, "async")
    }
    //同步
    //默认此字段为poi字段，如果和aoi相同，则是aoi
    var syncPoiCode = JSONUtil.getJsonVal(obj.getSyncReBody, "ret.entityAoiCode", "")
    val syncPoiId = JSONUtil.getJsonVal(obj.getSyncReBody, "ret.poiId", "")
    if (!syncPoiId.isEmpty) {
      //如果相等，则说明都是aoi
      return (syncPoiId, syncPoiCode, "sync")
    }
    return ("", "", "")
  }

  def queryAtShouAoiInfo(atShouBody: JSONObject) = {
    val tcs = JSONUtil.getJsonArrayMultiOfFirstObject(atShouBody, "result.tcs")

    val aoiid = JSONUtil.getJsonValSingle(tcs, "aoiid", "")
    val aoiSrc = JSONUtil.getJsonValSingle(tcs, "atAoiSrc", "")
    val deptSrc = JSONUtil.getJsonValSingle(tcs, "atDeptSrc", "")
    (aoiid, aoiSrc, deptSrc)
  }

  def saveLogToHive(spark: SparkSession, orderRdd: RDD[OrderData],
                    incDay: String, table: String): Unit = {
    val count = 1000
    val rows = orderRdd.map(obj => {
      var syncTcs = ""
      var asyncTcs = ""
      if (obj.getSyncTcs != null) syncTcs = JSON.toJSONString(obj.getSyncTcs, SerializerFeature.PrettyFormat)
      if (obj.getAsyncTcs != null) asyncTcs = JSON.toJSONString(obj.getAsyncTcs, SerializerFeature.PrettyFormat)
      val chkOmsAoi = JSONUtil.getJsonVal(obj.getChkOmsRebody, "orderFrom.aoiCode", "")
      var syncReqBody = ""
      if (obj.getSyncReqBody != null) {
        syncReqBody = obj.getSyncReqBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var syncReBody = ""
      if (obj.getSyncReBody != null) {
        syncReBody = obj.getSyncReBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var asyncReqBody = ""
      if (obj.getAsyncReqBody != null) {
        asyncReqBody = obj.getAsyncReqBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var asyncReBody = ""
      if (obj.getAsyncReBody != null) {
        asyncReBody = obj.getAsyncReBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }

      var arssReqBody = ""
      if (obj.getArssReqBody != null) {
        arssReqBody = obj.getArssReqBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var arssReBody = ""
      if (obj.getArssReBody != null) {
        arssReBody = obj.getArssReBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }

      //运单号
      var waybillNo = JSONUtil.getJsonVal(obj.getSyncReqBody, "orderInfo.orderFromToList.orderTo.waybillNo", "")
      if (waybillNo.isEmpty) {
        waybillNo = JSONUtil.getJsonVal(obj.getAsyncReqBody, "orderInfo.orderFromToList.orderTo.waybillNo", "")
      }
      var requestBuildingBody = ""
      if (obj.getRequestBuildingBody != null) {
        requestBuildingBody = obj.getRequestBuildingBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var responseBuildingBody = ""
      if (obj.getResponseBuildingBody != null) {
        responseBuildingBody = obj.getResponseBuildingBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }

      val deptCode = obj.getDeptCode()
      val ksDeptCode = JSONUtil.getJsonVal(obj.getChkKsReBody, "result.dept", "")
      if (StringUtil.isBlank(deptCode) && !StringUtil.isBlank(ksDeptCode)) {
        obj.setDeptCode(ksDeptCode)
        val ksSrc = JSONUtil.getJsonVal(obj.getChkKsReBody, "result.zcTag", "")
        obj.setSrc(ksSrc)
      }
      val ksAoiId = JSONUtil.getJsonVal(obj.getChkKsReBody, "result.aoi", "")
      val ksAoiSrc = JSONUtil.getJsonVal(obj.getChkKsReBody, "result.aoiTag", "")
      //新增at收body
      var atShouBody = ""
      if (obj.getAtShouBody != null) {
        atShouBody = obj.getAtShouBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      val (atShouAoiId, atShouAoiSrc, atShouDeptSrc) = queryAtShouAoiInfo(obj.getAtShouBody)
      //新增poi字段
      val (poiId, poiCode, poiSrc) = findPoiInfo(obj)
      var aoiSrc = ""
      if (!StringUtil.isBlank(obj.getArssAoiCode)) {
        aoiSrc = "chke_cur"
        if (!StringUtil.isBlank(atShouAoiId)) {
          aoiSrc = atShouAoiSrc
          obj.setSrc(atShouDeptSrc)
        }
      } else if (!StringUtil.isBlank(ksAoiId)) {
        aoiSrc = ksAoiSrc
      } else if (!StringUtil.isBlank(obj.getAsyncAoiCode)) {
        aoiSrc = obj.getAsyncTcs.getAtAoiSrc
      } else if (!StringUtil.isBlank(obj.getSyncAoiCode)) {
        aoiSrc = obj.getSyncTcs.getAtAoiSrc
      }
      val finalAoiid = obj.getAoiId
      val arr = Array[String](obj.isSyncReqFlag.toString, obj.isSyncReFlag.toString, obj.isAsyncReqFlag.toString,
        obj.isAsyncReFlag.toString, obj.isRdsArssReqFlag.toString, obj.isArssReqFlag.toString, obj.isArssReFlag.toString,
        obj.isErrCallFlag.toString, obj.getSyncReqDateTime, obj.getSyncReDateTime, obj.getSyncReStatus,
        obj.getSyncReqId, obj.getSyncNodeId, obj.getAsyncReqDateTime, obj.getAsyncReDateTime, obj.getAsyncReStatus, obj.getAsyncReqId,
        obj.getAsyncNodeId, obj.getRdsArssReqDateTime, obj.getArssReqDataTime, obj.getArssReqNodeId, obj.getArssReDataTime, obj.getArssReNodeId,
        obj.getAk, obj.getUrl, obj.getRemoteIp, obj.getSno, obj.getSysCode, obj.getOrderType, obj.getSysSource, obj.getLimitTypeCode,
        obj.getPayType, obj.getBookingType, obj.getCargoTypeCode, obj.getExpressTypeCode, obj.getWeight, obj.getClientCode,
        obj.getOrderNo, obj.getSysOrderNo, obj.getCountryCode, obj.getProvince, obj.getCity, obj.getCityCode, obj.getCounty,
        obj.getAddress, obj.getCustomerAccount, obj.getCustomerId, obj.getContactsName, obj.getCompany, obj.getPhone, obj.getMobile,
        waybillNo, obj.getSyncSrc, obj.getSyncGroupId, obj.getSyncDeptCode, obj.getSyncTeamCode, obj.getAsyncSrc,
        obj.getAsyncGroupId, obj.getAsyncDeptCode, obj.getAsyncTeamCode, obj.getArssDeptCode, obj.getArssTeamCode, obj.getArssEmpCode,
        obj.getStatus, obj.getSrc, obj.getGroupId, obj.getDeptCode, obj.getTeamCode, obj.getErrCallProvince, obj.getErrCallCity,
        obj.getErrCallResno, obj.getErrCallAddrabb, obj.getErrCallCounty, obj.getErrCallTeamid, obj.getErrCallAddrSrc, obj.getErrCallAddrGroupid,
        obj.getErrCallAddrDept, obj.getErrCallAddrTeamCode, obj.getErrCallEmpid, obj.getErrCallEmptel, obj.getMatchSrc, obj.getMatchGroupId,
        obj.getMatchTeamCode, obj.getMatchDeptCode, obj.getSyncChkDeptSrc, obj.getSyncChkTcSrc, obj.getAsyncChkDeptSrc, obj.getAsyncChkTcSrc,
        obj.getMatchChkDeptSrc, obj.getMatchChkTcSrc, obj.getErrCallDept, obj.getSyncTc2GeoSrc, obj.getSyncTc2Gid,
        obj.getAsyncTc2GeoSrc, obj.getAsyncTc2Gid, obj.getMatchTc2GeoSrc, obj.getMatchTc2Gid,
        JSONUtil.convertJsonToStr(obj.getChkKsReqBody),
        JSONUtil.convertJsonToStr(obj.getChkKsReBody), JSONUtil.convertJsonToStr(obj.getChkOmsRebody)
        , JSONUtil.convertJsonToStr(obj.getPickupBody), obj.getIsNotUnderCall,
        obj.getSyncAoiCode, obj.getAsyncAoiCode, obj.getArssAoiCode, obj.getAoiCode, obj.getPickupType,
        syncTcs, asyncTcs, chkOmsAoi, syncReqBody, syncReBody,
        asyncReqBody, asyncReBody, requestBuildingBody, responseBuildingBody, aoiSrc, arssReqBody, arssReBody,
        finalAoiid, poiId, poiCode, poiSrc, atShouBody
      )

      for (i <- arr.indices) {
        arr(i) = if (arr(i) != null) arr(i).replaceAll("[\\r\\n\\t]", "") else ""
      }

      var row: Row = null
      try {
        row = RowFactory.create(arr(0), arr(1), arr(2), arr(3), arr(4), arr(5), arr(6), arr(7), arr(8), arr(9), arr(10),
          arr(11), arr(12), arr(13), arr(14), arr(15), arr(16), arr(17), arr(18), arr(19), arr(20), arr(21), arr(22),
          arr(23), arr(24), arr(25), arr(26), arr(27), arr(28), arr(29), arr(30), arr(31), arr(32), arr(33), arr(34),
          arr(35), arr(36), arr(37), arr(38), arr(39), arr(40), arr(41), arr(42), arr(43), arr(44), arr(45), arr(46),
          arr(47), arr(48), arr(49), arr(50), arr(51), arr(52), arr(53), arr(54), arr(55), arr(56), arr(57), arr(58),
          arr(59), arr(60), arr(61), arr(62), arr(63), arr(64), arr(65), arr(66), arr(67), arr(68), arr(69), arr(70),
          arr(71), arr(72), arr(73), arr(74), arr(75), arr(76), arr(77), arr(78), arr(79), arr(80), arr(81), arr(82),
          arr(83), arr(84), arr(85), arr(86), arr(87), arr(88), arr(89), arr(90), arr(91), arr(92), arr(93), arr(94),
          arr(95), arr(96), arr(97), arr(98), arr(99), arr(100), arr(101), arr(102), arr(103), arr(104), arr(105), arr(106),
          arr(107), arr(108), arr(109), arr(110), arr(111), arr(112), arr(113), arr(114), arr(115), arr(116), arr(117), arr(118),
          arr(119),
          arr(120), arr(121), arr(122), arr(123))
      } catch {
        case e: Exception => logger.error("transfer " + JSON.toJSONString(obj, SerializerFeature.PrettyFormat) + " error", e)
      }
      row
    }).filter(_ != null).map(obj => {
      (Random.nextInt(count), obj)
    }).repartition(count).values
    val structFields = new util.ArrayList[StructField]()
    structFields.add(DataTypes.createStructField("syncReqFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReqFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("rdsArssReqFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReqFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReqDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReStatus", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReqId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncNodeId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReqDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReStatus", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReqId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncNodeId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("rdsArssReqDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReqDataTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReqNodeId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReDataTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReNodeId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("ak", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("url", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("remoteIp", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sno", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sysCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("orderType", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sysSource", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("limitTypeCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("payType", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bookingType", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("cargoTypeCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("expressTypeCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("weight", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("clientCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("orderNo", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sysOrderNo", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("countryCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("province", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("city", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("cityCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("county", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("address", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("customerAccount", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("customerId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("contactsName", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("company", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("phone", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("mobile", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("waybillNo", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncGroupId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncDeptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncGroupId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncDeptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssDeptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssEmpCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("status", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("src", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("groupId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("deptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("teamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallProvince", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallCity", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallResno", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrabb", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallCounty", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallTeamid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrGroupid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrDept", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallEmpid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallEmptel", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchGroupId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchDeptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncChkDeptSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncChkTcSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncChkDeptSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncChkTcSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchChkDeptSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchChkTcSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallDept", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncTc2GeoSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncTc2Gid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncTc2GeoSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncTc2Gid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchTc2GeoSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchTc2Gid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("chkKsReqBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("chkKsReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("chkOmsReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("pickUpBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("isNotUnderCall", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncAoiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncAoiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssAoiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("finalAoiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("pickupType", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncTcs", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncTcs", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("chkOmsAoi", DataTypes.StringType, true))

    structFields.add(DataTypes.createStructField("syncReqBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReqBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bid_req_body", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bid_re_body", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("aoisrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReqBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("finalAoiId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("poiId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("poiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("poiSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("atShouBody", DataTypes.StringType, true))
    val structTypes = DataTypes.createStructType(structFields)
    val props = ConfigurationUtil.loadProperties(VariableConstant.CONF, FixedConstant.CHARSET)
    //    spark.sql(String.format("use %s", props.getProperty("hive.db.gis")))
    val df = spark.createDataFrame(rows, structTypes)
    //    val table = props.getProperty("hive.table.gis_rds_omsfrom")
    val tempView = "%s_temp_view".format(System.currentTimeMillis())
    df.createOrReplaceTempView(tempView)
    val sql = s"insert overwrite table ${table} partition(inc_day = '${incDay}') select * from ${tempView}"

    logger.error(sql)
    spark.sql(sql)
  }

  def saveHbaseDataToHive(spark: SparkSession, orderDataRdd: RDD[JSONObject],
                          incDay: String, saveNotUnderCall: Boolean): Unit = {
    logger.error("合并reqid数据,适配hbase")

    import spark.implicits._
    //转换rdd，设置put[key,value]得到最终的要存入的结果集
    val mergeRdd = orderDataRdd.map(o => (o.getString("sysOrderNo"), o)).reduceByKey((o1, o2) => {
      val time1 = o1.getString("dataTime")
      val time2 = o2.getString("dataTime")
      //用时间大的覆盖小的
      if (time1 > time2) {
        o2.fluentPutAll(o1)
        o2
      } else {
        o1.fluentPutAll(o2)
        o1
      }
    }).values.persist(StorageLevel.DISK_ONLY_2)
    logger.error("按照系统订单号合并的数量:" + mergeRdd.count())
    val inputRdd = mergeRdd.map(json => {
      val orderInfo = JSON.toJavaObject(json, classOf[OrderInfo])
      val orderData = pickValuableInfo(orderInfo)
      json.put("errcallflag", orderData.isErrCallFlag)
      json.put("syncreqdatetime", orderData.getSyncReqDateTime)
      json.put("citycode", orderData.getCityCode)
      json.put("address", orderData.getAddress)
      json.put("phone", orderData.getPhone)
      json.put("mobile", orderData.getMobile)
      json.put("arssdeptcode", orderData.getArssDeptCode)
      json.put("arssteamcode", orderData.getArssTeamCode)
      json.put("arssempcode", orderData.getArssEmpCode)
      json.put("errcalladdrabb", orderData.getErrCallAddrabb)
      json.put("errcallteamid", orderData.getErrCallTeamid)
      json.put("errcallempid", orderData.getErrCallEmpid)
      json.put("matchsrc", orderData.getMatchSrc)
      json.put("matchgrouid", orderData.getMatchGroupId)
      json.put("matchdeptcode", orderData.getMatchDeptCode)
      json.put("matchteamcode", orderData.getMatchTeamCode)
      json.put("pickUpBody", orderData.getPickupBody)
      json.put("isNotUnderCall", orderData.getIsNotUnderCall)
      val orderNo: String = json.getString(VariableConstant.SYS_ORDERNO_KEY)

      if ((orderData.isSyncReqFlag || orderData.isAsyncReqFlag) && incDay.equals(orderData.getReqDate) && !StringUtil.isBlank(orderNo)) {
        val key = getKeyByStr(orderNo)
        (orderNo, key, orderData.getIsNotUnderCall, json.toJSONString.replaceAll("[\\r\\n\\t]", ""))
      } else {
        (null, null, null, null)
      }
    }).filter(obj => {
      obj._1 != null
    })
    var tmpViewName = "tmp_undercall" + System.currentTimeMillis()
    //下call
    val isNotUnderCallRdd = inputRdd.filter(obj => !"1".equals(obj._3))
      .map(obj => {
        (Random.nextInt(500), (obj._2, obj._4))
      }).repartition(500).values.toDF("rowKey", "data").createOrReplaceTempView(tmpViewName)
    var sql = s"insert overwrite table ${hbaseTableName} partition(inc_day='${incDay}',isnotundercall='0') select * from $tmpViewName "
    logger.error(sql)
    spark.sql(sql)
    logger.error("下call写入hbase分区完毕")
    if (saveNotUnderCall) {
      //非下call
      tmpViewName = "tmp_not_undercall" + System.currentTimeMillis()
      val isUnderCallRdd = inputRdd.filter(obj => "1".equals(obj._3))
        .map(obj => {
          (Random.nextInt(500), (obj._2, obj._4))
        }).repartition(500).values.toDF("rowKey", "data").createOrReplaceTempView(tmpViewName)
      sql = s"insert overwrite table ${hbaseTableName} partition(inc_day='${incDay}',isnotundercall='1') select * from $tmpViewName "
      logger.error(sql)
      spark.sql(sql)
      logger.error("非下call写入hbase分区完毕")

    }
    mergeRdd.unpersist()
  }


  /**
   * 根据运单号计算key
   *
   * @param waybillNo : 运单号
   * @return
   */
  def getKeyByStr(waybillNo: String): String = {
    var salt = (waybillNo.hashCode() % 30).toString.replace("-", "")
    val df = new DecimalFormat("00")
    if (salt.length == 1) {
      //个位数前面需要补0
      salt = df.format(Integer.parseInt(salt))
    }
    val key = salt + "_" + waybillNo
    key
  }


  def getErrCallData(errCallData: RDD[OrderData]): RDD[ErrCallData] = {
    val errCallRdd1 = errCallData.map(obj => {
      val errCallData = new ErrCallData
      val reqDate = obj.getReqDate
      val reqTime = obj.getReqTime
      var cityCode = obj.getCityCode
      if (cityCode == null || "".equals(cityCode)) {
        cityCode = obj.getErrCallTeamid.replaceAll("(\\d*).*", "$1")
      }
      val sysOrderNo = obj.getSysOrderNo.replaceAll("'", "")
      val province = obj.getProvince.replaceAll("'", "")
      val city = obj.getCity.replaceAll("'", "")
      val county = obj.getCounty.replaceAll("'", "")
      val address = obj.getAddress.replaceAll("'", "").replaceAll("['\\\\]*", "")
      val matchSrc = obj.getSrc.replaceAll("'", "")
      val srcDetail = obj.getMatchChkDeptSrc.replaceAll("'", "")
      val matchDept = obj.getDeptCode.replaceAll("'", "")
      val matchTeam = obj.getTeamCode.replaceAll("'", "")
      val matchGroupId = obj.getGroupId.replaceAll("'", "")
      val errCallDept = obj.getErrCallDept.replaceAll("'", "")
      val errCallTeam = obj.getErrCallTeamid.replaceAll("'", "")
      val errCallAddrabb = obj.getErrCallAddrabb.replaceAll("'", "")
      val errCallAddrDept = obj.getErrCallAddrDept.replaceAll("'", "")
      val errCallAddrTeamCode = obj.getErrCallAddrTeamCode.replaceAll("'", "")
      val errCallTcSouce = obj.getErrCallTcSouce.replaceAll("'", "")
      val chkEmpId = obj.getErrCallOperName.replaceAll("'", "")
      val chkModifyUser = ""
      var chkDept = ""
      var chkTeam = ""
      var miningDept = ""
      var miningTeam = ""
      if ("work".equals(errCallTcSouce) || "CGCS_KDD".equals(errCallTcSouce)) {
        miningDept = errCallAddrDept
        miningTeam = errCallAddrTeamCode
      } else if ("cgcs".equals(errCallTcSouce) || "CK".equals(errCallTcSouce)) {
        chkDept = errCallAddrDept
        chkTeam = errCallAddrTeamCode
      }
      val errCallDate = obj.getErrCallDate
      val id = reqDate + "_" + sysOrderNo
      errCallData.setId(id)
      errCallData.setReqDate(reqDate)
      errCallData.setReqTime(reqTime)
      errCallData.setSysOrderNo(sysOrderNo)
      errCallData.setProvince(province)
      errCallData.setCity(city)
      errCallData.setCounty(county)
      errCallData.setCityCode(cityCode)
      errCallData.setAddress(address)
      errCallData.setMatchSrc(matchSrc)
      errCallData.setSrcDetail(srcDetail)
      errCallData.setMatchDept(matchDept)
      errCallData.setMatchTeam(matchTeam)
      errCallData.setMatchGroupId(matchGroupId)
      errCallData.setErrCallDept(errCallDept)
      errCallData.setErrCallTeam(errCallTeam)
      errCallData.setErrCallAddrAbb(errCallAddrabb.replaceAll("['\\\\]*", "").replaceAll("[\\\\r\\\\n]*", ""))
      errCallData.setChkDept(chkDept)
      errCallData.setChkTeam(chkTeam)
      errCallData.setChkEmpId(chkEmpId)
      errCallData.setChkModifyUser(chkModifyUser)
      errCallData.setMiningDept(miningDept)
      errCallData.setMiningTeam(miningTeam)
      errCallData.setErrCallDate(errCallDate)
      errCallData.setCompany(obj.getCompany.replaceAll("['\\\\]*", "").replaceAll("[\\\\r\\\\n]*", ""))
      errCallData.setPhone(obj.getPhone.replaceAll("'", ""))
      errCallData.setMobile(obj.getMobile.replaceAll("'", ""))
      errCallData.setAoiId(obj.getAoiId)
      val pickupBody = obj.getPickupBody
      if (pickupBody != null) {
        val pick_up_tc = pickupBody.getString("pick_up_tc")
        val resource_id = pickupBody.getString("resource_id")
        val current_state = pickupBody.getString("current_state")
        errCallData.setPick_up_tc(pick_up_tc)
        errCallData.setResource_id(resource_id)
        errCallData.setCurrent_state(current_state)
        if (errCallData.getMatchTeam != null && !errCallData.getMatchTeam.isEmpty
          && pick_up_tc != null && !pick_up_tc.isEmpty) {
          if (pick_up_tc.equals(errCallData.getMatchTeam)) {
            errCallData.setIs_wrong_report("1")
          } else {
            errCallData.setIs_wrong_report("0")
          }
        }
      }
      (reqDate + "_" + address, errCallData)
    })

    val freqRdd = errCallRdd1.map(obj => {
      val id = obj._1
      val address = obj._2.getAddress
      if (address != null && !"".equals(address))
        (id, 1)
      else
        (id, 0)
    }).filter(_ != null).reduceByKey(_ + _)

    val errCallRdd = errCallRdd1.leftOuterJoin(freqRdd).map(tp => {
      val errCallObj = tp._2._1
      val freqObj = tp._2._2
      if (freqObj.nonEmpty)
        errCallObj.setFrequency(freqObj.get)
      errCallObj
    })
    errCallRdd

  }

  def selectAllPickUpInfoOrigin(sparkSession: SparkSession, inc_day: String, appDays: Int) = {

    var pickUpRowRdd: RDD[Row] = null
    var pick_up_join_days = 3
    if (appDays == 1) {
      pick_up_join_days = 1
    }
    for (i <- 0 until pick_up_join_days) {
      val endDate = DateUtil.dateBefore("yyyyMMdd", 0 - i, inc_day)
      val tmpRdd = selectPickUpInfoOrigin(sparkSession, endDate)
      if (pickUpRowRdd == null) {
        pickUpRowRdd = tmpRdd
      } else {
        pickUpRowRdd = pickUpRowRdd.union(tmpRdd)
      }
    }
    val pickUpRdd = pickUpRowRdd
      //      .repartition(3200)
      .map(obj => {
        //        val pickUpArray = new JSONArray()
        val rsltTmp = new JSONObject()
        rsltTmp.put("sysorderno", obj.getString(0))
        rsltTmp.put("tc", obj.getString(1))
        rsltTmp.put("resource_id", obj.getString(2))
        rsltTmp.put("current_state", obj.getString(3))
        //        pickUpArray.add(rsltTmp)
        val key = rsltTmp.getString("sysorderno")
        val rslt = new JSONObject()
        rslt.put("pickup", rsltTmp)
        (key, rslt)
      }).reduceByKey((obj1, obj2) => {
      //      val pickup1 = obj1.getJSONArray("pickup")
      //      val pickup2 = obj2.getJSONArray("pickup")
      //      for (i <- 0 until pickup2.size()) {
      //        pickup1.add(pickup2.get(i))
      //      }
      obj1
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("揽收排重后数量:" + pickUpRdd.count())
    //    pickUpRdd.unpersist()
    pickUpRdd
  }

  def selectAllPickUpInfoMid(sparkSession: SparkSession, incDay: String, appDays: Int) = {
    val endDate = DateUtil.dateBefore("yyyyMMdd", 0 - appDays, incDay)
    val sql = s"select order_no,pickup_tc,resource_id,current_state from " +
      s"(select order_no,pickup_tc,resource_id,current_state, " +
      s"row_number() over(partition by order_no order by task_modify_time,ex_modify_time desc ) as rank from " +
      s"${chk_shou_pick_up_info_mid_table} where inc_day between '${incDay}' and '${endDate}') a where rank=1 "
    logger.error(sql)
    var pickUpRdd = sparkSession.sql(sql).rdd.map(obj => {
      val rsltTmp = new JSONObject()
      rsltTmp.put("sysorderno", obj.getString(0))
      rsltTmp.put("tc", obj.getString(1))
      rsltTmp.put("resource_id", obj.getString(2))
      rsltTmp.put("current_state", obj.getString(3))
      //        pickUpArray.add(rsltTmp)
      val key = rsltTmp.getString("sysorderno")
      val rslt = new JSONObject()
      rslt.put("pickup", rsltTmp)
      (key, rslt)
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("揽收排重后数量:" + pickUpRdd.count())
    //    pickUpRdd.unpersist()
    pickUpRdd
  }

  /**
   * 获取揽收数据
   *
   * @param sparkSession : sparksession
   * @param inc_day      : 日期
   * @return
   */
  def selectAllPickUpInfo(sparkSession: SparkSession, inc_day: String, appDays: Int, pickUpTableMode: String) = {
    if (defaultPickupMode.equals(pickUpTableMode)) {
      selectAllPickUpInfoOrigin(sparkSession, inc_day, appDays)
    } else {
      selectAllPickUpInfoMid(sparkSession, inc_day, appDays)
    }
  }

  def selectPickUpInfoOrigin(sc: SparkSession, inc_day: String): RDD[Row] = {
    logger.error("日期：" + inc_day)
    val pickup_sql = "select t.order_no," +
      "ex.pickup_tc,t.resource_id," +
      " t.current_state from" +
      " (select inc_day,order_no,task_id,resource_id,current_state from " + tt_pickup_task + " " +
      " where inc_day = '" + inc_day + "' and order_no is not null and order_no <> '' ) t" +
      " left join (select pid,get_json_object(content,'$.receiveOrder.orderUnitareaCode') as pickup_tc from " + tt_pickup_task_ex + " where inc_day = '" + inc_day +
      "' and ex_key='RO_INFO' ) ex on t.task_id = ex.pid "
    logger.error(pickup_sql)
    val pickUpRdd = sc.sql(pickup_sql).rdd
    pickUpRdd
  }

  case class ErrCall(
                      id: String,
                      reqDate: String,
                      reqTime: String,
                      frequency: Int,
                      sysOrderNo: String,
                      province: String,
                      city: String,
                      county: String,
                      cityCode: String,
                      address: String,
                      matchSrc: String,
                      srcDetail: String,
                      matchDept: String,
                      matchTeam: String,
                      matchGroupId: String,
                      errCallDept: String,
                      errCallTeam: String,
                      errCallAddrAbb: String,
                      chkDept: String,
                      chkTeam: String,
                      chkEmpId: String,
                      chkModifyUser: String,
                      miningDept: String,
                      miningTeam: String,
                      errCallDate: String,
                      company: String,
                      phone: String,
                      mobile: String,
                      aoiId: String,
                      current_state: String,
                      pick_up_tc: String,
                      resource_id: String,
                      is_wrong_report: String
                    )

}
