package com.sf.gis.scala.oms_shou.pojo.rds;


public class AtSrvRet {
    private String src;
    private Tcs tcs;
    private int count;

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public Tcs getTcs() {
        return tcs;
    }

    public void setTcs(Tcs tcs) {
        this.tcs = tcs;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
