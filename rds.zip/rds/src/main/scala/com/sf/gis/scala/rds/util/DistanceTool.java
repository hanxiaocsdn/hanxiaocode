package com.sf.gis.scala.rds.util;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LinearRing;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.io.ParseException;
import com.vividsolutions.jts.io.WKTReader;

import java.io.IOException;

public class DistanceTool {
    static double EARTH_RADIUS = 6378137.0;    //单位M

    static private double getRad(double d) {
        return d * Math.PI / 180.0;
    }

    //算法1:求两点之间的距离(比较粗略，但是GD/BD地图采用此算法)
    static public double getGreatCircleDistance(double lng1, double lat1, double lng2, double lat2) {

        try {
            double radLat1 = getRad(lat1);
            double radLat2 = getRad(lat2);

            double dy = radLat1 - radLat2;  //a
            double dx = getRad(lng1) - getRad(lng2);    //b

            double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(dy / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(dx / 2), 2)));
            s = s * EARTH_RADIUS;
            s = Math.round(s * 10000) / 10000.0;

            return s;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    static private double getLongt(double longt1, double lat1, double distance) {
        return (180 * distance) / (Math.PI * EARTH_RADIUS * Math.cos(lat1 * Math.PI / 180));
    }


    static private double getLat(double longt1, double lat1, double distance) {
        return distance / 111000;
    }

    static public Polygon createRingPolygon(GeometryFactory geometryFactory, double x, double y, double radius) {
        double lgtDis = getLongt(x, y, radius);
        double latDis = getLat(x, y, radius);
        System.out.println(lgtDis + "," + latDis);
        Coordinate c0 = new Coordinate(x - lgtDis, y - latDis);
        Coordinate c1 = new Coordinate(x - lgtDis, y);
        Coordinate c2 = new Coordinate(x - lgtDis, y + latDis);
        Coordinate c3 = new Coordinate(x, y + latDis);
        Coordinate c4 = new Coordinate(x + lgtDis, y + latDis);
        Coordinate c5 = new Coordinate(x + lgtDis, y);
        Coordinate c6 = new Coordinate(x + lgtDis, y - latDis);
        Coordinate c7 = new Coordinate(x, y - latDis);
        Coordinate[] cArray = new Coordinate[]{c0, c1, c2, c3, c4, c5, c6, c7, c0};

        LinearRing line = geometryFactory.createLinearRing(cArray);
        Polygon polygon = geometryFactory.createPolygon(line, null);
        return polygon;
    }

    /**
     * 生成个最大矩形框
     */
    public static String createMaxRec(GeometryFactory geometryFactory, String polygonStr, Double lng, Double lat) throws ParseException {
        WKTReader wKTReader = new WKTReader(geometryFactory);
        Polygon polygon = (Polygon) wKTReader.read(polygonStr);
        Coordinate[] points = polygon.getCoordinates();
        double minX = lng, maxX = lng, minY = lat, maxY = lat;
        for (Coordinate point : points) {
            minX = point.x > minX ? minX : point.x;
            minY = point.y > minY ? minY : point.y;
            maxX = point.x > maxX ? point.x : maxX;
            maxY = point.y > maxY ? point.y : maxY;
        }
        double extendXmin = getLongt(minX, minY, 500);
        double extendYmin = getLat(minX, minY, 500);
        double extendXmax = getLongt(maxX, maxY, 500);
        double extendYmax = getLat(maxX, maxY, 500);
        Coordinate c0 = new Coordinate(minX-extendXmin, minY-extendYmin);
        Coordinate c1 = new Coordinate(minX-extendXmin, maxY+extendYmax);
        Coordinate c2 = new Coordinate(maxX+extendXmax, maxY+extendYmax);
        Coordinate c3 = new Coordinate(maxX+extendXmax, minY-extendYmin);
        Coordinate[] cArray = new Coordinate[]{c0, c1, c2, c3, c0};
        LinearRing line = geometryFactory.createLinearRing(cArray);
        Polygon rec = geometryFactory.createPolygon(line, null);
        return rec.toString();
    }


    public static void main(String[] args) throws IOException {
        String dd = "POLYGON((108.60942806296075 34.29348242068207,108.60998596243587 34.291532370661386,108.6099001317474 34.28841219648605,108.61007179312433 34.28699389719516,108.6182257085296 34.27564664113292,108.62277473501884 34.26600026908923,108.62534965567313 34.2613894798493,108.62968410544111 34.26266633909911,108.63620723776532 34.26461705885782,108.64114899514387 34.266135719776585,108.65009422401064 34.26951267294103,108.6582762132362 34.27306202271997,108.66375927853468 34.27652174660636,108.66775040554887 34.27989058806554,108.67122654843217 34.284074855770925,108.67208485531687 34.2920869720177,108.66682594964452 34.292967178540366,108.66308695027769 34.29354775643142,108.66209478726184 34.30131251556736,108.66171365926202 34.30370697385116,108.66113165208864 34.30651891636546,108.66100961157842 34.307102723962586,108.66092243978547 34.30730212600699,108.65370761042847 34.306152447736736,108.65341515888966 34.30614267605985,108.65334771828591 34.306226662834334,108.6529001747588 34.30754292752404,108.65209018430653 34.31029939868323,108.65057741842203 34.31556325347081,108.650212637996 34.31776085948603,108.64965473852091 34.321092604023804,108.64908201662672 34.32528874385038,108.64925367800366 34.32536184214976,108.64930732218397 34.32544158567647,108.64920003382338 34.32593112066584,108.6486411118306 34.32911637608544,108.64785229406284 34.33278810677224,108.64669919250368 34.33903012983755,108.64654355295605 34.33972871809533,108.64853544602822 34.34042613419692,108.65604563126986 34.34277308643193,108.65501566300814 34.3484778032027,108.64986582169954 34.3488321206345,108.64664717088168 34.35035566852835,108.64470704430283 34.35007127541196,108.6348679039211 34.347209010408676,108.62661822670641 34.34022083859948,108.61980950671455 34.33406750875184,108.61450495814005 34.330865931596435,108.61117901896156 34.32638274550894,108.60991149135675 34.32408029833462,108.60870953157114 34.322604257131175,108.60550160958933 34.32159413270793,108.60444042663326 34.32053412290003,108.60432104980478 34.319752212910714,108.6044712535096 34.31874205416035,108.60543684875498 34.31591531725988,108.60662416500264 34.31299077959903,108.60685305511477 34.30975834945413,108.60693530124838 34.30923333381591,108.60745333756346 34.30490409970086,108.60786103333375 34.30208575971447,108.60841893280892 34.29912551462154,108.6091036140572 34.29575642040486,108.60942806296075 34.29348242068207))";

        System.out.println(dd.replaceAll("^(0+)", ""));

    }
}
