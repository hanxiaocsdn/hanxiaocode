package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

import java.io._
import java.sql.Connection
import java.util

import com.alibaba.druid.pool.DruidDataSource
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.csvreader.CsvReader
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpConnection, MD5Util}
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.oms_pai.db.{ManagerFactory, RdsManager, WdManager}
import com.sf.gis.scala.oms_pai.index.idxCompare.WdIdxCompare
import com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay.CustConf.getCustDept
import com.sf.gis.scala.oms_pai.start.ComUtil
import com.sf.gis.scala.utils.{DbUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks

/**
 * Created by 01375125 on 2018/11/13.
 * oms派件错分隔日统计，重构
 * t-4、t-6已迁移至新集群
 * 任务id:103,225194,已改版新的业务需求，此逻辑下线，先注释待删除 01374443-20240115
 */
object WrongDispatchDayMain {
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//  val logger: Logger = Logger.getLogger(appName)
//  val comUtil = new ComUtil(7)
//  //  val wd_db_property = "wd_detail.properties"
//  //  val rds_db_property = "rds_db.properties"
//  val gis_dept_name = "gis_dept"
//  val gis_dept_map_name = "gis_dept_map"
//  val gis_status_name = "gis_status"
//  val sss_dept_name = "sss_dept"
//  val sss_dept_map_name = "sss_dept_map"
//  val sss_status_name = "sss_status"
//  val gis_sss_dept_name = "gis_sss_dept"
//  val gis_sss_dept_map_name = "gis_sss_dept_map"
//  val gis_sss_status_name = "gis_sss_status"
//  val arss_dept_name = "arss_dept"
//  val arss_dept_map_name = "arss_dept_map"
//  val arss_status_name = "arss_status"
//  val final_dept_name = "final_dept"
//  val final_dept_map_name = "final_dept_map"
//  val final_status_name = "final_status"
//  val dlv_dept_name = "dlv_dept"
//  val dlv_dept_map_name = "dlv_dept_map"
//  //status - 表示网点无效 0 表示有限但是没有妥投 1 表示妥投并且非重货 2 表示妥投且为重货 3 表示妥投非重货且网点不一致 4表示找不到小哥网点延续错分或者和小哥网点不一致 5表示找不到把枪延续前面的错分或者和把枪网点不一致
//
//  def main(args: Array[String]): Unit = {
//    start(args)
//  }
//
//  def testCms(): Unit = {
//    val znoDeptMap = getZnoDeptMap
//    logger.error(">>>获取zno_depart的数据量：" + znoDeptMap.size)
//    znoDeptMap.foreach(o => println(o))
//
//    val cmsMap: Map[String, String] = getCmsData
//    logger.error(">>>获取cms表的数据量：" + cmsMap.size)
//    cmsMap.foreach(o => println(o))
//  }
//
//  def singleRunStaIndex(dateArray: Array[String], spark: SparkSession, sc: SparkContext, flag: String): Unit = {
//    val startDate = dateArray.apply(0)
//    val incDay = dateArray.apply(dateArray.length - 1)
//    val wrongRddData = queryWrongData(spark, startDate)
//
//    logger.error(">>>统计错分指标-------------------------")
//    logger.error(">>>统计错分行指标-------------------------")
//    val rowIndexRdd = WdIndexStat.statRowIndex(wrongRddData)
//    logger.error(">>>统计错分维度指标-------------------------")
//    val wrongIndexRdd = WdIndexStat.statIndex(rowIndexRdd)
//    logger.error(">>>统计错分维度指标(新)-------------------------")
//    val wrongIndexRddNew = WdIndexStat.statIndexNew(rowIndexRdd)
//    Spark.clearPersistWithoutId(spark, wrongRddData.id)
//    logger.error(">>>获取oms的有效识别量指标...")
//    val sameRddData = querySameData(spark, startDate)
//    val rdd = sameRddData.union(wrongRddData).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>获取oms的有效识别量指标" + incDay + "统计指标数量:"
//      + rdd.filter(obj => obj.getJSONObject("oms_body").getString("req_date").equals(incDay)).count())
//    sameRddData.unpersist()
//    wrongRddData.unpersist()
//
//    logger.error(">>>累计调用频次和错分频次 End------")
//    Spark.clearPersistWithoutId(spark, rdd.id)
//    logger.error(">>>获取oms的有效识别量行统计指标...")
//    val omsRecRdd = StatRecIndex.getOmsRowRecRdd(rdd)
//    logger.error(">>>获取oms的有效识别量行" + incDay + "统计指标数量:"
//      + omsRecRdd.filter(obj => obj.data_type.equals(Constant.PRE) && obj.stat_date.equals(incDay)).count())
//    rdd.unpersist()
//    logger.error(">>>获取oms的有效识别量聚合指标...")
//    val omsValidRecRdd = StatRecIndex.getOmsValidRecRdd(omsRecRdd)
//    logger.error(">>>获取oms的有效识别量聚合指标(新)...")
//    val omsValidRecRddNew = StatRecIndex.getOmsValidRecRddNew(omsRecRdd)
//    omsRecRdd.unpersist()
//    logger.error(">>>错分指标入库...")
//    WdIndexStat.saveIndexSingleDate(omsValidRecRdd._2, wrongIndexRdd, comUtil, startDate)
//    WdIndexStat.saveIndexNew(omsValidRecRddNew, wrongIndexRddNew, comUtil, dateArray)
//    logger.error(">>>错分指标统计结束End--------")
//    omsValidRecRdd._1.unpersist()
//    omsValidRecRdd._2.unpersist()
//    logger.error("开始存储指标到hive")
//    WdIndexStat.saveIndexToHive(spark, omsValidRecRdd._2, wrongIndexRdd, startDate)
//    WdIndexStat.saveIndexNewToHive(spark, omsValidRecRddNew, wrongIndexRddNew, dateArray.take(1))
//
//    logger.error("------------------------------------------")
//    logger.error(">>>指标对比-----------")
//    val comp = new WdIdxCompare()
//    comp.comapre(Util.getDay(incDay, -6, ""))
//  }
//
//  /**
//   * 开始程序
//   */
//  def start(args: Array[String]): Unit = {
//    val conf = getSparkConf(appName)
////    val sc = new SparkContext(conf)
//
//    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
//    val sc = spark.sparkContext
//    sc.setLogLevel("ERROR")
//    logger.error(">>>统计oms派件错分指标-------生产--------start------ComUtil.flag:" + comUtil.getFlag + "-----appName==" + appName + "----------")
//    //    var daysAgo = 1
//    //    if (args.length == 1) {
//    //      daysAgo = args(0).toInt
//    //    }
//    //    val incDay = Util.dateDelta(-daysAgo, "")
//    val incDay = args(0)
//    var flag = ""
//    if (args.length > 1) {
//      flag = args(1)
//      logger.error("flag:" + flag)
//    }
//    var saveSingleWdMysql = false
//    if (args.length > 2 && args(2).equals("saveSingleWdMysql")) {
//      saveSingleWdMysql = true
//      logger.error("saveSingleWdMysql:" + saveSingleWdMysql)
//    }
//    var freq = true
//    if(args.length>3 && args(3).equals("noFreq")){
//      freq = false;
//    }
//    val dateArray = Array(Util.getDay(incDay, -6, ""), Util.getDay(incDay, -5, ""), Util.getDay(incDay, -4, ""), Util.getDay(incDay, -3, ""), Util.getDay(incDay, -2, ""), Util.getDay(incDay, -1, ""), Util.getDay(incDay, 0, ""))
//    //    getWeightMapDept(spark,incDay,null)
//    if (flag.equals("singleRunStaIndex")) {
//      singleRunStaIndex(dateArray, spark, sc, flag)
//    } else if (flag.equals("singleRunDay")) {
//      handleTask(dateArray, spark, sc, flag, saveSingleWdMysql,freq)
//    } else {
//      handleTask(dateArray, spark, sc, flag, saveSingleWdMysql,freq)
//    }
//  }
//
//  def saveWrongDataToHive(spark: SparkSession,
//                          wrongRddData: RDD[JSONObject],
//                          sameRddData: RDD[JSONObject],
//                          barCacheData: RDD[(String, String, String, String)],
//                          incDay: String) = {
//    val saveKey = Array("data")
//    SparkWrite.save2HiveStatic(spark, wrongRddData.map(obj => {
//      val jsonObject = new JSONObject()
//      jsonObject.put("data", obj)
//      jsonObject
//    }), saveKey,
//      "dm_gis.zc_wd_wrong",
//      Array(("inc_day", incDay)), wrongRddData.getNumPartitions)
//    wrongRddData.unpersist()
//
//    //    OmsDayIndexMain.clearPersistWithoutId(spark,sameRddData.id)
//    SparkWrite.save2HiveStatic(spark, sameRddData.map(obj => {
//      val jsonObject = new JSONObject()
//      jsonObject.put("data", obj)
//      jsonObject
//    }), saveKey,
//      "dm_gis.zc_wd_same",
//      Array(("inc_day", incDay)), sameRddData.getNumPartitions)
//    logger.error(">>>" + incDay + "入库错分数据到临时表完毕")
//    sameRddData.unpersist()
//    logger.error(">>>" + incDay + "入库坐标缓存数据")
//    val barCacheDataRdd = barCacheData.map(obj => {
//      val jsonObject = new JSONObject()
//      jsonObject.put("x", obj._1)
//      jsonObject.put("y", obj._2)
//      jsonObject.put("zc", obj._3)
//      jsonObject.put("req_date", obj._4)
//      ((obj._1, obj._2), jsonObject)
//    }).reduceByKey((obj1, obj2) => {
//      obj1
//    }).values
//    SparkWrite.save2HiveStatic(spark, barCacheDataRdd, Array("x", "y", "zc", "req_date"),
//      "dm_gis.zc_wd_bar_xy_cache",
//      Array(("inc_day", incDay)), 10)
//    logger.error(">>>" + incDay + "入库坐标缓存数据完毕")
//
//  }
//
//  def querySameData(spark: SparkSession, startDate: String) = {
//    val sql2 = s"select data from dm_gis.zc_wd_same where inc_day='$startDate' "
//    logger.error(sql2)
//    val sameData = spark.sql(sql2).rdd.map(obj => {
//      JSON.parseObject(obj.getString(0))
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("相同数据量:" + sameData.count())
//    sameData
//  }
//
//  def queryWrongData(spark: SparkSession, startDate: String) = {
//    val sql1 = s"select data from dm_gis.zc_wd_wrong where inc_day='$startDate' "
//    logger.error(sql1)
//    val wronData = spark.sql(sql1).rdd.map(obj => {
//      JSON.parseObject(obj.getString(0))
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("错误数据量:" + wronData.count())
//    wronData
//  }
//
//  def handleWrongDataSingle(standardRdd: RDD[JSONObject],
//                            spark: SparkSession,
//                            dateList: Array[String], saveSingleWdMysql: Boolean): Unit = {
//    try {
//      val detailDataRdd = WdIndexStat.getWdDetailData(standardRdd)
//      //      detailDataRdd.take(3).foreach(o => println(o))
//      for (statDate <- dateList) {
//        val dateRdd = detailDataRdd.filter(json => {
//          val req_date = json.getJSONObject("oms_body").getString("req_date")
//          req_date.equals(statDate)
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//        val count = dateRdd.count()
//        logger.error(">>>" + statDate + "号错分详细数据量：" + count + ",数据入hive库中----------------------------------")
//        if (count != 0) {
//          saveWrongRddToHive(dateRdd, spark, statDate)
//          logger.error(">>>" + statDate + "号错分详细数据量数据入mysql库中----------------------------------")
//          saveWrongRddToMysql(dateRdd, statDate)
//          if (saveSingleWdMysql) {
//            logger.error(">>>" + statDate + "号错分详细数据量数据入错分补码原始表库中----------------------------------")
//            saveWrongRddToMysql2(dateRdd, statDate)
//            doSaveWrongAddressToMysql(dateRdd, statDate)
//          }
//        }
//
//        dateRdd.unpersist()
//      }
//    } catch {
//      case e: Exception => logger.error(">>>错分明细数据处理异常：" + e)
//    }
//
//  }
//
//  /**
//   * 处理任务
//   *
//   * @param dateArray
//   * @param spark
//   * @param sc
//   */
//  def handleTask(dateArray: Array[String],
//                 spark: SparkSession, sc: SparkContext,
//                 flag: String, saveSingleWdMysql: Boolean,freq:Boolean=true): Unit = {
//    val startDate = dateArray.apply(0)
//    val incDay = dateArray.apply(dateArray.length - 1)
//    val logEndDay = dateArray.apply(dateArray.length - 3)
//    logger.error("-------统计" + startDate + "--" + incDay
//      + "之间，" + dateArray.length + "天的的错分指标--------")
//
//    val znoDeptMap = getZnoDeptMap
//    logger.error(">>>获取zno_depart的数据量：" + znoDeptMap.size)
//    val cmsMap: Map[String, String] = getCmsData
//    logger.error(">>>获取cms表的数据量：" + cmsMap.size)
//
//    val zno2DeptMap = sc.broadcast(cmsMap ++ znoDeptMap).value
//    logger.error(">>>合并后的网点映射数据量：" + zno2DeptMap.size)
//    logger.error(zno2DeptMap)
//    logger.error(">>>过滤错分数据...")
//    val (wrongRddData1, sameRddData1, barCacheData) = filterWrongData(startDate, incDay, spark, sc, zno2DeptMap, logEndDay, flag)
//    logger.error("写入临时数据库")
//    saveWrongDataToHive(spark, wrongRddData1, sameRddData1, barCacheData, startDate)
//    spark.catalog.clearCache()
//    val wrongRddData = queryWrongData(spark, startDate)
//    logger.error(">>>错分数据明细处理...")
//    handleWrongDataSingle(wrongRddData, spark: SparkSession,
//      dateArray.take(1), saveSingleWdMysql)
//
//    logger.error(">>>统计错分指标-------------------------")
//    logger.error(">>>统计错分行指标-------------------------")
//    val rowIndexRdd = WdIndexStat.statRowIndex(wrongRddData)
//    logger.error(">>>统计错分维度指标-------------------------")
//    val wrongIndexRdd = WdIndexStat.statIndex(rowIndexRdd)
//    logger.error(">>>统计错分维度指标(新)-------------------------")
//    val wrongIndexRddNew = WdIndexStat.statIndexNew(rowIndexRdd)
//    Spark.clearPersistWithoutId(spark, wrongRddData.id)
//    logger.error(">>>获取oms的有效识别量指标...")
//    val sameRddData = querySameData(spark, startDate)
//    val rdd = sameRddData.union(wrongRddData).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>获取oms的有效识别量指标" + incDay + "统计指标数量:"
//      + rdd.filter(obj => obj.getJSONObject("oms_body").getString("req_date").equals(incDay)).count())
//    sameRddData.unpersist()
//    wrongRddData.unpersist()
//    if(freq){
//      logger.error(">>>累计调用频次和错分频次 start------")
//      MatchFreq.freqData(spark, rdd, dateArray)
//      logger.error(">>>累计调用频次和错分频次 End------")
//    }
//    Spark.clearPersistWithoutId(spark, rdd.id)
//    logger.error(">>>获取oms的有效识别量行统计指标...")
//    val omsRecRdd = StatRecIndex.getOmsRowRecRdd(rdd)
//    logger.error(">>>获取oms的有效识别量行" + incDay + "统计指标数量:"
//      + omsRecRdd.filter(obj => obj.data_type.equals(Constant.PRE) && obj.stat_date.equals(incDay)).count())
//    rdd.unpersist()
//    logger.error(">>>获取oms的有效识别量聚合指标...")
//    val omsValidRecRdd = StatRecIndex.getOmsValidRecRdd(omsRecRdd)
//    logger.error(">>>获取oms的有效识别量聚合指标(新)...")
//    val omsValidRecRddNew = StatRecIndex.getOmsValidRecRddNew(omsRecRdd)
//    omsRecRdd.unpersist()
//    logger.error(">>>错分指标入库...")
//    WdIndexStat.saveIndex(omsValidRecRdd._1, omsValidRecRdd._2, wrongIndexRdd, comUtil, startDate)
//    WdIndexStat.saveIndexNew(omsValidRecRddNew, wrongIndexRddNew, comUtil, dateArray)
//    logger.error(">>>错分指标统计结束End--------")
//    omsValidRecRdd._1.unpersist()
//    omsValidRecRdd._2.unpersist()
//    logger.error("开始存储指标到hive")
//    WdIndexStat.saveIndexToHive(spark, omsValidRecRdd._2, wrongIndexRdd, startDate)
//    WdIndexStat.saveIndexNewToHive(spark, omsValidRecRddNew, wrongIndexRddNew, dateArray.take(1))
//    logger.error("删除临时表分区")
//    spark.sql(s"alter table dm_gis.zc_wd_wrong drop if exists partition(inc_day='$startDate') ")
//    spark.sql(s"alter table dm_gis.zc_wd_same drop if exists partition(inc_day='$startDate') ")
//    logger.error("------------------------------------------")
//    logger.error(">>>指标对比-----------")
//    val comp = new WdIdxCompare()
//    comp.comapre(Util.getDay(incDay, -6, ""))
//    //    comp.comapre(Util.getDay(incDay, -5, ""))
//    //    comp.comapre(Util.getDay(incDay, -4, ""))
//    //    comp.comapre(Util.getDay(incDay, -3, ""))
//
//
//  }
//
//  def getJpzDeptList(spark: SparkSession): Array[String] = {
//    val sql = s"select zno_code from dm_gis.st_department where type_code='DB05-JPZ'"
//    logger.error(sql)
//    val data = spark.sql(sql).rdd.map(obj => {
//      obj.getString(0)
//    }).collect()
//    data
//  }
//
//  /**
//   * 临时过滤妥投规则
//   *
//   * @param zno_code
//   * @return
//   */
//  def reject_dlv_map(zno_code: String): Boolean = {
//    zno_code.matches("^[0-9]+(FW|ZPW|ZPVA)+(.*)")
//  }
//
//  def queryBarXyZcCache(spark: SparkSession, startDate: String, logEndDay: String) = {
//    val yestoday = Util.getDay(startDate, -1, "")
//    val sql = s"select x,y,zc from dm_gis.zc_wd_bar_xy_cache where " +
//      s"inc_day between '${yestoday}' and '${startDate}' and req_date between '${startDate}' and '${logEndDay}' "
//    logger.error(sql)
//    val xyZcMap = spark.sql(sql).rdd.map(obj => {
//      val xy = obj.getString(0) + "_" + obj.getString(1)
//      ((xy.hashCode % 1000).toString, (xy, obj.getString(2)))
//    }).groupByKey().map(obj => {
//      val iter = obj._2.iterator
//      val tmpMap = new util.HashMap[String, String]()
//      while (iter.hasNext) {
//        val tmp = iter.next()
//        tmpMap.put(tmp._1, tmp._2)
//      }
//      (obj._1, tmpMap)
//    }).collectAsMap()
//    logger.error("缓存坐标hash后数量:" + xyZcMap.size)
//    spark.sparkContext.broadcast(xyZcMap)
//  }
//
//  def queryXyZc(barXyZcCache: collection.Map[String, util.HashMap[String, String]],
//                json: JSONObject,
//                zno2DeptMap: Map[String, String]): (String, JSONObject) = {
//    val bar_body = json.getJSONObject("bar_body")
//    val x = JSONUtil.getJsonValSingle(bar_body, "bar_scan_lng")
//    val y = JSONUtil.getJsonValSingle(bar_body, "bar_scan_lat")
//    val xy = x + "_" + y
//    val hashStr = (xy.hashCode % 1000).toString
//    var bar_dept: String = null
//    var bar_dept_map: String = null
//    if (barXyZcCache.contains(hashStr)) {
//      val tmpMap = barXyZcCache.get(hashStr).get
//      if (tmpMap.containsKey(xy)) {
//        bar_dept = tmpMap.get(xy)
//        if (zno2DeptMap.contains(bar_dept)) {
//          bar_dept_map = zno2DeptMap.apply(bar_dept)
//          bar_body.put("bar_dept_map", bar_dept_map)
//        }
//        bar_body.put("bar_dept", bar_dept)
//        return (bar_dept_map, json)
//      }
//    }
//    val result = getBarDeptPost(json, zno2DeptMap)
//    result
//  }
//
//  def checkWrong(oms_body: JSONObject, dlv_body: JSONObject) = {
//    var dlv_dept: String = null
//    var dlv_dept_map: String = null
//    //妥投网点是否为蜂巢
//    var is_fc = false
//    if (dlv_body != null) {
//      dlv_dept = dlv_body.getString(dlv_dept_name)
//      dlv_dept_map = dlv_body.getString(dlv_dept_map_name)
//      //妥投网点是否为蜂巢
//      val extendattach5 = dlv_body.getString("extendattach5")
//      if (extendattach5 != null && extendattach5.startsWith("FC")) {
//        is_fc = true
//      }
//    }
//    //noinspection ScalaUnusedSymbol
//    val isGisDeptMatch = oms_body.getBoolean("isGisDeptMatch")
//    //noinspection ScalaUnusedSymbol
//    val isSssDeptMatch = oms_body.getBoolean("isSssDeptMatch")
//    //noinspection ScalaUnusedSymbol
//    val isGisSssDeptMatch = oms_body.getBoolean("isGisSssDeptMatch")
//    val isArssDeptMatch = oms_body.getBoolean("isArssDeptMatch")
//    //noinspection ScalaUnusedSymbol
//    val isFinalDeptMatch = oms_body.getBoolean("isFinalDeptMatch")
//    val gis_dept = oms_body.getString(gis_dept_name)
//    val gis_dept_map = oms_body.getString(gis_dept_map_name)
//    val sss_dept = oms_body.getString(sss_dept_name)
//    val sss_dept_map = oms_body.getString(sss_dept_map_name)
//    val gis_sss_dept = oms_body.getString(gis_sss_dept_name)
//    val gis_sss_dept_map = oms_body.getString(gis_sss_dept_map_name)
//    val arss_dept = oms_body.getString(arss_dept_name)
//    val arss_dept_map = oms_body.getString(arss_dept_map_name)
//    val final_dept = oms_body.getString(final_dept_name)
//    val final_dept_map = oms_body.getString(final_dept_map_name)
//
//    val gis_status = oms_body.getString(gis_status_name)
//    val sss_status = oms_body.getString(sss_status_name)
//    val gis_sss_status = oms_body.getString(gis_sss_status_name)
//    val arss_status = oms_body.getString(arss_status_name)
//    val final_status = oms_body.getString(final_status_name)
//    if (!is_fc) {
//      if (gis_status.equals("1")) {
//        if ((gis_dept_map == null || (!gis_dept_map.equals(dlv_dept_map) && !gis_dept_map.equals(dlv_dept)))
//          && !gis_dept.equals(dlv_dept_map) && !gis_dept.equals(dlv_dept)) oms_body.put(gis_status_name, "3")
//      }
//      if (sss_status.equals("1")) {
//        if ((sss_dept_map == null || (!sss_dept_map.equals(dlv_dept_map) && !sss_dept_map.equals(dlv_dept)))
//          && !sss_dept.equals(dlv_dept_map) && !sss_dept.equals(dlv_dept)) oms_body.put(sss_status_name, "3")
//      }
//      if (gis_sss_status.equals("1")) {
//        if ((gis_sss_dept_map == null || (!gis_sss_dept_map.equals(dlv_dept_map) && !gis_sss_dept_map.equals(dlv_dept)))
//          && !gis_sss_dept.equals(dlv_dept_map) && !gis_sss_dept.equals(dlv_dept)) oms_body.put(gis_sss_status_name, "3")
//      }
//      if (arss_status.equals("1")) {
//        if (isArssDeptMatch && (arss_dept_map == null || (!arss_dept_map.equals(dlv_dept_map) && !arss_dept_map.equals(dlv_dept)))
//          && !arss_dept.equals(dlv_dept_map) && !arss_dept.equals(dlv_dept)) oms_body.put(arss_status_name, "3")
//      }
//      if (final_status.equals("1")) {
//        if ((final_dept_map == null || (!final_dept_map.equals(dlv_dept_map) && !final_dept_map.equals(dlv_dept)))
//          && !final_dept.equals(dlv_dept_map) && !final_dept.equals(dlv_dept)) oms_body.put(final_status_name, "3")
//      }
//    }
//
//    val isGisDeptWrong = oms_body.getString(gis_status_name).equals("3")
//    val isSssDeptWrong = oms_body.getString(sss_status_name).equals("3")
//    val isGisSssDeptWrong = oms_body.getString(gis_sss_status_name).equals("3")
//    val isArssDeptWrong = oms_body.getString(arss_status_name).equals("3")
//    val isFinalDeptWrong = oms_body.getString(final_status_name).equals("3")
//    isGisDeptWrong || isSssDeptWrong || isGisSssDeptWrong || isArssDeptWrong || isFinalDeptWrong //有错分
//  }
//
//  /**
//   * 过滤错分的数据
//   *
//   * @param startDate
//   * @param endDate
//   * @param spark
//   * @return
//   */
//  def filterWrongData(startDate: String, endDate: String,
//                      spark: SparkSession, sc: SparkContext,
//                      zno2DeptMap: Map[String, String],
//                      logEndDay: String, runFlag: String) = {
//
//    val xiaogeNoOutList = getXiaogeOutList
//    val finalDeptOutList = getFinalDeptOutList
//    logger.error(">>>获得免除小哥工号数据量:" + xiaogeNoOutList.size)
//    logger.error(">>>获得免除网点数据量:" + finalDeptOutList.size)
//
//    val accountOutList = getAccountOutListByDb
//    val accountOutListBrod = sc.broadcast(accountOutList)
//    logger.error(">>>获取月结账号：" + accountOutListBrod.value.size)
//    logger.error(accountOutListBrod.value)
//    logger.error("获取集配站")
//    val jpzDeptList = getJpzDeptList(spark)
//    val jpzDeptListBrod = sc.broadcast(jpzDeptList)
//    logger.error("集配站列表：" + jpzDeptListBrod.value)
//
//    val xiaogeNoOutListBrod = sc.broadcast(xiaogeNoOutList)
//    val finalDeptOutListBrod = sc.broadcast(finalDeptOutList)
//
//    //    val znoDeptMap = getZnoDeptMap()
//    //    logger.error(">>>获取zno_depart的数据量："+znoDeptMap.size)
//    //
//    //    val cmsMap:Map[String,String] = getCmsData()
//    //    logger.error(">>>获取cms表的数据量："+cmsMap.size)
//
//    logger.error(">>>获取oms派件5天的日志数据...")
//    val omsRdd = getOmsLogRdd(startDate, logEndDay, spark, sc, zno2DeptMap, runFlag)
//    //    logger.error(">>>获取oms派件" + endDate + "的数据量：" + omsRdd.filter(obj => obj._2.getJSONObject("oms_body").getString("req_date").equals(endDate)).count())
//    //    omsRdd.take(4).foreach(o => println(o))
//
//    logger.error(">>>获取有效路由妥投的数据...")
//    val dlvRdd = getDlvRdd(startDate, endDate, spark).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>获取有效路由妥投数据量：" + dlvRdd.count())
//    //    dlvRdd.take(4).foreach(o => println(o))
//
//    logger.error(">>>左关联妥投数据...")
//    val dlvResultRdd = omsRdd.leftOuterJoin(dlvRdd).map(obj => {
//      var dlv_dept_map: String = null
//      val omsJson = obj._2._1
//      val dlvObj = obj._2._2
//      val oms_body = omsJson.getJSONObject("oms_body")
//      val waybillno = oms_body.getString("waybillno")
//      val isGisDeptMatch = oms_body.getBoolean("isGisDeptMatch")
//      val isSssDeptMatch = oms_body.getBoolean("isSssDeptMatch")
//      val isGisSssDeptMatch = oms_body.getBoolean("isGisSssDeptMatch")
//      val isArssDeptMatch = oms_body.getBoolean("isArssDeptMatch")
//      val isFinalDeptMatch = oms_body.getBoolean("isFinalDeptMatch")
//      oms_body.put(gis_status_name, "-")
//      oms_body.put(sss_status_name, "-")
//      oms_body.put(gis_sss_status_name, "-")
//      oms_body.put(arss_status_name, "-")
//      oms_body.put(final_status_name, "-")
//      if (isGisDeptMatch) oms_body.put(gis_status_name, "0")
//      if (isSssDeptMatch) oms_body.put(sss_status_name, "0")
//      if (isGisSssDeptMatch) oms_body.put(gis_sss_status_name, "0")
//      if (isArssDeptMatch) oms_body.put(arss_status_name, "0")
//      if (isFinalDeptMatch) oms_body.put(final_status_name, "0")
//      if (dlvObj.nonEmpty) {
//        val dlvJson = dlvObj.get
//        val dlv_body = dlvJson.getJSONObject("dlv_body")
//        val dlv_dept = dlv_body.getString(dlv_dept_name)
//        val courier_code = dlv_body.getString("courier_code")
//        if (!xiaogeNoOutListBrod.value.contains(courier_code)) {
//          //不在免除小哥工号表里面
//          if (dlv_dept != null && !reject_dlv_map(dlv_dept) && dlv_dept.matches("^[0-9]+[a-zA-Z]+[0-9]*$") && zno2DeptMap.contains(dlv_dept)) {
//            dlv_dept_map = zno2DeptMap.apply(dlv_dept)
//            if (!finalDeptOutListBrod.value.contains(dlv_dept_map)) {
//              dlv_body.put(dlv_dept_map_name, dlv_dept_map)
//              if (isGisDeptMatch) oms_body.put(gis_status_name, "1")
//              if (isSssDeptMatch) oms_body.put(sss_status_name, "1")
//              if (isGisSssDeptMatch) oms_body.put(gis_sss_status_name, "1")
//              if (isArssDeptMatch) oms_body.put(arss_status_name, "1")
//              if (isFinalDeptMatch) oms_body.put(final_status_name, "1")
//              omsJson.fluentPutAll(dlvJson)
//            }
//          }
//        }
//      }
//      (waybillno, omsJson)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>关联后妥投的数据量：" + dlvResultRdd.count())
//    //    dlvResultRdd.take(4).foreach(o => println(o))
//    omsRdd.unpersist()
//    dlvRdd.unpersist()
//
//    logger.error(">>>获取重量映射网点数据...")
//    val weightDeptMap = getWeightMapDept(spark, startDate, zno2DeptMap)
//    logger.error(">>>重量映射数据量：" + weightDeptMap.size)
//    val weightDeptMapBrod = sc.broadcast(weightDeptMap)
//    //    weightDeptMap.take(1).foreach(o=>println(o))
//
//    logger.error(">>>获取运单宽表重量数据")
//    //    (252257034917,{"wide_body":{"waybill_no":"252257034917","wide_day":"20181221","meterage_weight_qty":"26.0","dest_dist_code":"871"}})
//    val wideRdd = getWideRdd(startDate, endDate, spark, dlvResultRdd).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>运单宽表的数据量：" + wideRdd.count())
//    wideRdd.take(4).foreach(o => println(o))
//
//    logger.error(">>>关联重货映射...")
//    val wideResultRdd = dlvResultRdd.leftOuterJoin(wideRdd).map(obj => {
//      val omsJson = obj._2._1
//      val wideObj = obj._2._2
//      val oms_body = omsJson.getJSONObject("oms_body")
//      val dlv_body = omsJson.getJSONObject("dlv_body")
//      if (dlv_body != null) {
//        if (wideObj.nonEmpty) {
//          //能关联到运单宽表的数据
//          val wideJson = wideObj.get
//          val wide_body = wideJson.getJSONObject("wide_body")
//          //运单宽表对应的重量
//          var meterage_weight_qty = 0.0
//          try {
//            meterage_weight_qty = wide_body.getString("meterage_weight_qty").toDouble
//          } catch {
//            case e: Exception => logger.error(">>>重量转换异常：" + e)
//          }
//          //增加月结账号过滤
//          var account = ""
//          var dest_dist_code = ""
//          var source_zone_code = ""
//          try {
//            account = wide_body.getString("freight_monthly_acct_code")
//            dest_dist_code = wide_body.getString("dest_dist_code")
//            source_zone_code = wide_body.getString("source_zone_code")
//          } catch {
//            case e: Exception => logger.error(">>>月结账号转换异常：" + e)
//          }
//          if (accountOutListBrod.value.contains(dest_dist_code + "," + account + "," + source_zone_code + "," + dlv_body.getString(dlv_dept_name))) {
//            //月账户，删除妥投映射
//            omsJson.remove("dlv_body")
//            val gis_status = oms_body.getString(gis_status_name)
//            if (gis_status.equals("1")) {
//              oms_body.put(gis_status_name, "0")
//            }
//            val sss_status = oms_body.getString(sss_status_name)
//            if (sss_status.equals("1")) {
//              oms_body.put(sss_status_name, "0")
//            }
//            val gis_sss_status = oms_body.getString(gis_sss_status_name)
//            if (gis_sss_status.equals("1")) {
//              oms_body.put(gis_sss_status_name, "0")
//            }
//            val arss_status = oms_body.getString(arss_status_name)
//            if (arss_status.equals("1")) {
//              oms_body.put(arss_status_name, "0")
//            }
//            val final_status = oms_body.getString(final_status_name)
//            if (final_status.equals("1")) {
//              oms_body.put(final_status_name, "0")
//            }
//          } else {
//            //            val gis_status = oms_body.getString(gis_status_name)
//            //            if (gis_status.equals("1")) {
//            //              var gis_dept = oms_body.getString(gis_dept_map_name)
//            //              if (gis_dept == null) gis_dept = oms_body.getString(gis_dept_name)
//            //              val gis_dept_behind = getWeightDept(gis_dept, meterage_weight_qty, weightDeptMapBrod.value)
//            //              if (gis_dept_behind != null) oms_body.put(gis_dept_map_name, gis_dept_behind) //重货映射后网点
//            //            }
//            //            val sss_status = oms_body.getString(sss_status_name)
//            //            if (sss_status.equals("1")) {
//            //              var sss_dept = oms_body.getString(sss_dept_map_name)
//            //              if (sss_dept == null) sss_dept = oms_body.getString(sss_dept_name)
//            //              val sss_dept_behind = getWeightDept(sss_dept, meterage_weight_qty, weightDeptMapBrod.value)
//            //              if (sss_dept_behind != null) oms_body.put(sss_dept_map_name, sss_dept_behind) //重货映射后网点
//            //            }
//            //            val gis_sss_status = oms_body.getString(gis_sss_status_name)
//            //            if (gis_sss_status.equals("1")) {
//            //              var gis_sss_dept = oms_body.getString(gis_sss_dept_map_name)
//            //              if (gis_sss_dept == null) gis_sss_dept = oms_body.getString(gis_sss_dept_name)
//            //              val gis_sss_dept_behind = getWeightDept(gis_sss_dept, meterage_weight_qty, weightDeptMapBrod.value)
//            //              if (gis_sss_dept_behind != null) oms_body.put(gis_sss_dept_map_name, gis_sss_dept_behind) //重货映射后网点
//            //            }
//            //            val arss_status = oms_body.getString(arss_status_name)
//            //            if (arss_status.equals("1")) {
//            //              var arss_dept = oms_body.getString(arss_dept_map_name)
//            //              if (arss_dept == null) arss_dept = oms_body.getString(arss_dept_name)
//            //              val arss_dept_behind = getWeightDept(arss_dept, meterage_weight_qty, weightDeptMapBrod.value)
//            //              if (arss_dept_behind != null) oms_body.put(arss_dept_map_name, arss_dept_behind) //重货映射后网点
//            //            }
//            //            val final_status = oms_body.getString(final_status_name)
//            //            if (final_status.equals("1")) {
//            //              var final_dept = oms_body.getString(final_dept_map_name)
//            //              if (final_dept == null) final_dept = oms_body.getString(final_dept_name)
//            //              val final_dept_behind = getWeightDept(final_dept, meterage_weight_qty, weightDeptMapBrod.value)
//            //              if (final_dept_behind != null) oms_body.put(final_dept_map_name, final_dept_behind) //重货映射后网点
//            //            }
//            var dlv_dept = dlv_body.getString(dlv_dept_map_name)
//            if (dlv_dept == null) dlv_dept = dlv_body.getString(dlv_dept_name)
//            if (jpzDeptListBrod.value.contains(dlv_dept)) {
//              val dlv_dept_behind = getWeightDept(dlv_dept, meterage_weight_qty, weightDeptMapBrod.value)
//              if (dlv_dept_behind != null) dlv_body.put(dlv_dept_map_name, dlv_dept_behind) //重货映射后网点
//            }
//            omsJson.fluentPutAll(wideJson)
//          }
//        }
//      }
//      omsJson
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>：关联重货后的数据量" + wideResultRdd.count())
//    //    wideResultRdd.take(4).foreach(o => println("关联映射：" + o))
//    dlvResultRdd.unpersist()
//    wideRdd.unpersist()
//
//    logger.error(">>>计算妥投和待比较网点是否一致...")
//    val dlvDiffRdd2 = wideResultRdd.map(json => {
//      val oms_body = json.getJSONObject("oms_body")
//      var flag = false
//      val dlv_body = json.getJSONObject("dlv_body")
//      flag = checkWrong(oms_body, dlv_body)
//      (flag, json)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("数量:" + dlvDiffRdd2.count())
//    wideResultRdd.unpersist()
//
//    val dlvSameRdd = dlvDiffRdd2.filter(_._1 == false).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2) //一致或无妥投或重货
//    logger.error(">>>妥投和待比较网点有一致或无妥投的数据量：" + dlvSameRdd.count())
//    //    dlvSameRdd.take(4).foreach(o => println(o))
//    val dlvDiffRdd = dlvDiffRdd2.filter(_._1 == true).values.map(json => {
//      val dlv_body = json.getJSONObject("dlv_body")
//      val dlv_date = dlv_body.getString("dlv_date")
//      var courier_code = dlv_body.getString("courier_code")
//      try {
//        courier_code = java.lang.Long.parseLong(courier_code).toString
//      } catch {
//        case e: Exception => logger.error(">>>妥投员工号转换异常:" + e + ",json:" + json)
//      }
//      val key = dlv_date + "_" + courier_code
//      (key, json)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>妥投和待比较网点有不一致的数据量：" + dlvDiffRdd.count())
//    //    dlvDiffRdd.take(4).foreach(o => println(o))
//    dlvDiffRdd2.unpersist()
//
//    logger.error(">>>获取员工的工号及其所属网点")
//    val empRdd = getEmpRdd(startDate, endDate, spark).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>获取员工的工号及其所属网点的数量：" + empRdd.count())
//    //    empRdd.take(4).foreach(o => println(o))
//
//    val empWrongRdd2 = dlvDiffRdd.leftOuterJoin(empRdd).map(obj => {
//      var flag = ""
//      //默认找不到小哥网点
//      val omsJson = obj._2._1
//      val empObj = obj._2._2
//      if (empObj.nonEmpty) {
//        //可以找到小哥网点
//        val empJson = empObj.get
//        val emp_body = empJson.getJSONObject("emp_body")
//        val oms_body = omsJson.getJSONObject("oms_body")
//        val emp_dept = emp_body.getString("emp_dept")
//        //        val final_dept_map =omsJson.getJSONObject("oms_body").getString(final_dept_map_name)
//        var emp_dept_map: String = null
//        if (emp_dept != null && zno2DeptMap.contains(emp_dept)) emp_dept_map = zno2DeptMap.apply(emp_dept)
//        if (omsJson.containsKey("wide_body") && jpzDeptListBrod.value.contains(emp_dept)) {
//          val wide_body = omsJson.getJSONObject("wide_body")
//          var meterage_weight_qty = 0.0
//          try {
//            meterage_weight_qty = wide_body.getString("meterage_weight_qty").toDouble
//          } catch {
//            case e: Exception => logger.error(">>>重量转换异常：" + e)
//          }
//          val emp_dept_behind = getWeightDept(if (emp_dept_map != null) emp_dept_map else emp_dept, meterage_weight_qty, weightDeptMapBrod.value)
//          if (emp_dept_behind != null) emp_dept_map = emp_dept_behind //重货映射后网点
//          emp_body.put("emp_dept_map", emp_dept_map)
//        }
//
//        if (emp_dept_map != null || emp_dept != null) {
//          val gis_status = oms_body.getString(gis_status_name)
//          if (gis_status.equals("3")) {
//            //gis网点错分
//            val gis_dept = oms_body.getString(gis_dept_name)
//            val gis_dept_map = oms_body.getString(gis_dept_map_name)
//            if ((gis_dept_map == null || (!gis_dept_map.equals(emp_dept_map) && !gis_dept_map.equals(emp_dept)))
//              && !gis_dept.equals(emp_dept_map) && !gis_dept.equals(emp_dept)) oms_body.put(gis_status_name, "4")
//          }
//
//          val sss_status = oms_body.getString(sss_status_name)
//          if (sss_status.equals("3")) {
//            val sss_dept = oms_body.getString(sss_dept_name)
//            val sss_dept_map = oms_body.getString(sss_dept_map_name)
//            if ((sss_dept_map == null || (!sss_dept_map.equals(emp_dept_map) && !sss_dept_map.equals(emp_dept)))
//              && !sss_dept.equals(emp_dept_map) && !sss_dept.equals(emp_dept)) oms_body.put(sss_status_name, "4")
//          }
//
//          val gis_sss_status = oms_body.getString(gis_sss_status_name)
//          if (gis_sss_status.equals("3")) {
//            val gis_sss_dept = oms_body.getString(gis_sss_dept_name)
//            val gis_sss_dept_map = oms_body.getString(gis_sss_dept_map_name)
//            if ((gis_sss_dept_map == null || (!gis_sss_dept_map.equals(emp_dept_map) && !gis_sss_dept_map.equals(emp_dept)))
//              && !gis_sss_dept.equals(emp_dept_map) && !gis_sss_dept.equals(emp_dept)) oms_body.put(gis_sss_status_name, "4")
//          }
//
//          val arss_status = oms_body.getString(arss_status_name)
//          if (arss_status.equals("3")) {
//            val arss_dept = oms_body.getString(arss_dept_name)
//            val arss_dept_map = oms_body.getString(arss_dept_map_name)
//            if ((arss_dept_map == null || (!arss_dept_map.equals(emp_dept_map) && !arss_dept_map.equals(emp_dept)))
//              && !arss_dept.equals(emp_dept_map) && !arss_dept.equals(emp_dept)) oms_body.put(arss_status_name, "4")
//          }
//
//          val final_status = oms_body.getString(final_status_name)
//          if (final_status.equals("3")) {
//            val final_dept = oms_body.getString(final_dept_name)
//            val final_dept_map = oms_body.getString(final_dept_map_name)
//            if ((final_dept_map == null || (!final_dept_map.equals(emp_dept_map) && !final_dept_map.equals(emp_dept)))
//              && !final_dept.equals(emp_dept_map) && !final_dept.equals(emp_dept)) oms_body.put(final_status_name, "4")
//          }
//          val isGisDeptWrong = oms_body.getString(gis_status_name).equals("4")
//          val isSssDeptWrong = oms_body.getString(sss_status_name).equals("4")
//          val isGisSssDeptWrong = oms_body.getString(gis_sss_status_name).equals("4")
//          val isArssDeptWrong = oms_body.getString(arss_status_name).equals("4")
//          val isFinalDeptWrong = oms_body.getString(final_status_name).equals("4")
//          if (isGisDeptWrong || isSssDeptWrong || isGisSssDeptWrong || isArssDeptWrong || isFinalDeptWrong) flag = "0" //有网点错分
//        } else {
//          //小哥归属网点存在，但是在CMS表中找不到
//        }
//        omsJson.fluentPutAll(empJson)
//      } else {
//        //flag = "0"//找不到小哥归属网点，也要算错分,延续前面的错分
//        val oms_body = omsJson.getJSONObject("oms_body")
//        if (oms_body.getString(gis_status_name).equals("3")) oms_body.put(gis_status_name, "4")
//        if (oms_body.getString(sss_status_name).equals("3")) oms_body.put(sss_status_name, "4")
//        if (oms_body.getString(gis_sss_status_name).equals("3")) oms_body.put(gis_sss_status_name, "4")
//        if (oms_body.getString(arss_status_name).equals("3")) oms_body.put(arss_status_name, "4")
//        if (oms_body.getString(final_status_name).equals("3")) oms_body.put(final_status_name, "4")
//
//        val isGisDeptWrong = oms_body.getString(gis_status_name).equals("4")
//        val isSssDeptWrong = oms_body.getString(sss_status_name).equals("4")
//        val isGisSssDeptWrong = oms_body.getString(gis_sss_status_name).equals("4")
//        val isArssDeptWrong = oms_body.getString(arss_status_name).equals("4")
//        val isFinalDeptWrong = oms_body.getString(final_status_name).equals("4")
//        if (isGisDeptWrong || isSssDeptWrong || isGisSssDeptWrong || isArssDeptWrong || isFinalDeptWrong) flag = "0" //有网点错分
//      }
//      (flag, omsJson)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("数量:" + empWrongRdd2.count())
//    dlvDiffRdd.unpersist()
//    empRdd.unpersist()
//
//    val empSameRdd = empWrongRdd2.filter(obj => {
//      !"0".equals(obj._1)
//    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2) //一致或无妥投或重货
//    logger.error(">>>小哥网点存在且无网点错分：" + empSameRdd.count())
//    //    empSameRdd.take(4).foreach(o => println(o))
//
//    val empWrongRdd = empWrongRdd2.filter(obj => {
//      "0".equals(obj._1)
//    }).values.map(json => {
//      val waybillno = json.getJSONObject("oms_body").getString("waybillno")
//      (waybillno, json)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val xyRunCnt = empWrongRdd.count()
//    logger.error(">>>小哥网点存在且有网点错分以及小哥网点不存在延续前面错分的数据量：" + xyRunCnt)
//    //    empWrongRdd.take(4).foreach(o => println(o))
//    empWrongRdd2.unpersist()
//
//    logger.error(">>>通过把枪定为数据表获取经纬度数据...")
//    val barRdd = getBarRdd(startDate, endDate, spark).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>获取把枪定位数据表的数据量：" + barRdd.count())
//    barRdd.take(4).foreach(o => println(o))
//
//    logger.error("获取巴枪坐标网点缓存")
//    val barXyZcBc = queryBarXyZcCache(spark, startDate, logEndDay)
//    val bar_url = comUtil.getValue("bar_url")
//    val bar_url_ak = comUtil.getValue("bar_url_ak")
//    val barXyId = BdpTaskRecordUtil.startRunNetworkInterface(spark,"01374443","103","派件地址频次累计计算","网点错分",bar_url,bar_url_ak,xyRunCnt,50)
//    val barWrongRdd2 = empWrongRdd.leftOuterJoin(barRdd)
//      .repartition(50)
//      .map(obj => {
//        var flag = ""
//        val empJson = obj._2._1
//        val barObj = obj._2._2
//        val oms_body = empJson.getJSONObject("oms_body")
//        if (barObj.nonEmpty) {
//          val barJsonBefore = barObj.get
//          //增加缓存步骤
//          val result = queryXyZc(barXyZcBc.value, barJsonBefore, zno2DeptMap)
//          var bar_dept_map = result._1
//          val barJson = result._2
//          val bar_dept = barJson.getJSONObject("bar_body").getString("bar_dept")
//          empJson.fluentPutAll(barJson)
//          try {
//            if (bar_dept_map != null || bar_dept != null) {
//              //把枪网点存在且映射网点存在
//              if (empJson.containsKey("wide_body")) { //重货网点映射
//                val wide_body = empJson.getJSONObject("wide_body")
//                var meterage_weight_qty = 0.0
//                try {
//                  meterage_weight_qty = wide_body.getString("meterage_weight_qty").toDouble
//                } catch {
//                  case e: Exception => logger.error(">>>重量转换异常：" + e)
//                }
//                if (jpzDeptListBrod.value.contains(bar_dept_map)) {
//                  val bar_dept_behind = getWeightDept(bar_dept_map, meterage_weight_qty, weightDeptMapBrod.value)
//                  if (bar_dept_behind != null) {
//                    bar_dept_map = bar_dept_behind //重货映射后网点
//                    barJson.put("bar_dept_map", bar_dept_map)
//                  }
//                }
//              }
//              val gis_status = oms_body.getString(gis_status_name)
//              if (gis_status.equals("4")) {
//                //前面判定的gis错分了
//                val gis_dept = oms_body.getString(gis_dept_name)
//                val gis_dept_map = oms_body.getString(gis_dept_map_name)
//                if ((gis_dept_map == null || (!gis_dept_map.equals(bar_dept_map) && !gis_dept_map.equals(bar_dept)))
//                  && !gis_dept.equals(bar_dept_map) && !gis_dept.equals(bar_dept)) oms_body.put(gis_status_name, "5")
//              }
//
//              val sss_status = oms_body.getString(sss_status_name)
//              if (sss_status.equals("4")) {
//                val sss_dept = oms_body.getString(sss_dept_name)
//                val sss_dept_map = oms_body.getString(sss_dept_map_name)
//                if ((sss_dept_map == null || (!sss_dept_map.equals(bar_dept_map) && !sss_dept_map.equals(bar_dept)))
//                  && !sss_dept.equals(bar_dept_map) && !sss_dept.equals(bar_dept)) oms_body.put(sss_status_name, "5")
//              }
//
//              val gis_sss_status = oms_body.getString(gis_sss_status_name)
//              if (gis_sss_status.equals("4")) {
//                val gis_sss_dept = oms_body.getString(gis_sss_dept_name)
//                val gis_sss_dept_map = oms_body.getString(gis_sss_dept_map_name)
//                if ((gis_sss_dept_map == null || (!gis_sss_dept_map.equals(bar_dept_map) && !gis_sss_dept_map.equals(bar_dept)))
//                  && !gis_sss_dept.equals(bar_dept_map) && !gis_sss_dept.equals(bar_dept)) oms_body.put(gis_sss_status_name, "5")
//              }
//
//              val arss_status = oms_body.getString(arss_status_name)
//              if (arss_status.equals("4")) {
//                val arss_dept = oms_body.getString(arss_dept_name)
//                val arss_dept_map = oms_body.getString(arss_dept_map_name)
//                if ((arss_dept_map == null || (!arss_dept_map.equals(bar_dept_map) && !arss_dept_map.equals(bar_dept)))
//                  && !arss_dept.equals(bar_dept_map) && !arss_dept.equals(bar_dept)) oms_body.put(arss_status_name, "5")
//              }
//
//              val final_status = oms_body.getString(final_status_name)
//              if (final_status.equals("4")) {
//                val final_dept = oms_body.getString(final_dept_name)
//                val final_dept_map = oms_body.getString(final_dept_map_name)
//                if ((final_dept_map == null || (!final_dept_map.equals(bar_dept_map) && !final_dept_map.equals(bar_dept)))
//                  && !final_dept.equals(bar_dept_map) && !final_dept.equals(bar_dept)) oms_body.put(final_status_name, "5")
//              }
//
//              val isGisDeptWrong = oms_body.getString(gis_status_name).equals("5")
//              val isSssDeptWrong = oms_body.getString(sss_status_name).equals("5")
//              val isGisSssDeptWrong = oms_body.getString(gis_sss_status_name).equals("5")
//              val isArssDeptWrong = oms_body.getString(arss_status_name).equals("5")
//              val isFinalDeptWrong = oms_body.getString(final_status_name).equals("5")
//              if (isGisDeptWrong || isSssDeptWrong || isGisSssDeptWrong || isArssDeptWrong || isFinalDeptWrong) flag = "0" //有网点错分
//            } else {
//              //关联上了把枪数据但是找不到把枪网点,延续前面的错分
//              if (oms_body.getString(gis_status_name).equals("4")) oms_body.put(gis_status_name, "5")
//              if (oms_body.getString(sss_status_name).equals("4")) oms_body.put(sss_status_name, "5")
//              if (oms_body.getString(gis_sss_status_name).equals("4")) oms_body.put(gis_sss_status_name, "5")
//              if (oms_body.getString(arss_status_name).equals("4")) oms_body.put(arss_status_name, "5")
//              if (oms_body.getString(final_status_name).equals("4")) oms_body.put(final_status_name, "5")
//
//              val isGisDeptWrong = oms_body.getString(gis_status_name).equals("5")
//              val isSssDeptWrong = oms_body.getString(sss_status_name).equals("5")
//              val isGisSssDeptWrong = oms_body.getString(gis_sss_status_name).equals("5")
//              val isArssDeptWrong = oms_body.getString(arss_status_name).equals("5")
//              val isFinalDeptWrong = oms_body.getString(final_status_name).equals("5")
//              if (isGisDeptWrong || isSssDeptWrong || isGisSssDeptWrong || isArssDeptWrong || isFinalDeptWrong) flag = "0" //有网点错分
//            }
//          } catch {
//            case e: Exception => logger.error(">>>处理把枪网点错分异常：" + e + "," + empJson)
//          }
//        } else {
//          //关联不上把枪数据，延续前面的错分
//          if (oms_body.getString(gis_status_name).equals("4")) oms_body.put(gis_status_name, "5")
//          if (oms_body.getString(sss_status_name).equals("4")) oms_body.put(sss_status_name, "5")
//          if (oms_body.getString(gis_sss_status_name).equals("4")) oms_body.put(gis_sss_status_name, "5")
//          if (oms_body.getString(arss_status_name).equals("4")) oms_body.put(arss_status_name, "5")
//          if (oms_body.getString(final_status_name).equals("4")) oms_body.put(final_status_name, "5")
//
//          val isGisDeptWrong = oms_body.getString(gis_status_name).equals("5")
//          val isSssDeptWrong = oms_body.getString(sss_status_name).equals("5")
//          val isGisSssDeptWrong = oms_body.getString(gis_sss_status_name).equals("5")
//          val isArssDeptWrong = oms_body.getString(arss_status_name).equals("5")
//          val isFinalDeptWrong = oms_body.getString(final_status_name).equals("5")
//          if (isGisDeptWrong || isSssDeptWrong || isGisSssDeptWrong || isArssDeptWrong || isFinalDeptWrong) flag = "0" //有网点错分
//        }
//        (flag, empJson)
//      }).repartition(2000).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("数量:" + barWrongRdd2.count())
//    BdpTaskRecordUtil.endNetworkInterface("01374443",barXyId)
//    empWrongRdd.unpersist()
//    barRdd.unpersist()
//    logger.error("准备缓存坐标数据:")
//    val barCacheData = barWrongRdd2.filter(obj => !JSONUtil.getJsonVal(obj._2, "bar_body.bar_dept", "").isEmpty).map(obj => {
//      (JSONUtil.getJsonVal(obj._2, "bar_body.bar_scan_lng", ""),
//        JSONUtil.getJsonVal(obj._2, "bar_body.bar_scan_lat", ""),
//        JSONUtil.getJsonVal(obj._2, "bar_body.bar_dept", ""),
//        JSONUtil.getJsonVal(obj._2, "oms_body.req_date", "")
//      )
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("巴枪缓存坐标结果:" + barCacheData.count())
//    val barCacheUseData = barWrongRdd2.filter(obj => {
//      val bar_body = obj._2.getJSONObject("bar_body")
//      if (bar_body != null && !bar_body.containsKey("http_data") && bar_body.containsKey("bar_dept")) {
//        true
//      } else {
//        false
//      }
//    })
//    logger.error("巴枪使用缓存坐标结果数量:" + barCacheUseData.count())
//    val barSameRdd = barWrongRdd2.filter(obj => {
//      !"0".equals(obj._1)
//    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>把枪网点无错分数据量：" + barSameRdd.count())
//
//    val barWrongRdd = barWrongRdd2.filter(_._1 == "0").values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>把枪网点错分数据量：" + barWrongRdd.count())
//    barWrongRdd2.unpersist()
//
//    val custConfMap = CustConf.getCustConf(zno2DeptMap)
//    logger.error(">>>大客户数据量：" + custConfMap.size)
//    val custConfMapBrod = sc.broadcast(custConfMap)
//    val custWrongRdd2 = barWrongRdd.map(json => {
//      val oms_body = json.getJSONObject("oms_body")
//      val gis_dept_map = oms_body.getString(gis_dept_map_name)
//      val gis_dept = if (gis_dept_map != null) gis_dept_map else oms_body.getString(gis_dept_name)
//      val sss_dept_map = oms_body.getString(sss_dept_map_name)
//      val sss_dept = if (sss_dept_map != null) sss_dept_map else oms_body.getString(sss_dept_name)
//      val gis_sss_dept_map = oms_body.getString(gis_sss_dept_map_name)
//      val gis_sss_dept = if (gis_sss_dept_map != null) gis_sss_dept_map else oms_body.getString(gis_sss_dept_name)
//      val arss_dept_map = oms_body.getString(arss_dept_map_name)
//      val arss_dept = if (arss_dept_map != null) arss_dept_map else oms_body.getString(arss_dept_name)
//      val final_dept_map = oms_body.getString(final_dept_map_name)
//      val final_dept = if (final_dept_map != null) final_dept_map else oms_body.getString(final_dept_name)
//      val city_code = oms_body.getString("city_code")
//      val waybillno = oms_body.getString("waybillno")
//      val address = oms_body.getString("req_addresss")
//      val deptSet = Array[String](gis_dept, sss_dept, gis_sss_dept, arss_dept, final_dept).toSet
//      val custDept = getCustDept(custConfMapBrod.value, deptSet, city_code, waybillno, address)
//      if (custDept != null) {
//        oms_body.put("cust_dept", custDept)
//        // 判断大客户是否错分
//        if (custDept.equals(gis_dept)) oms_body.put(gis_status_name, "1")
//        if (custDept.equals(sss_dept)) oms_body.put(sss_status_name, "1")
//        if (custDept.equals(gis_sss_dept)) oms_body.put(gis_sss_status_name, "1")
//        if (custDept.equals(arss_dept)) oms_body.put(arss_status_name, "1")
//        if (custDept.equals(final_dept)) oms_body.put(final_status_name, "1")
//      }
//      val isGisDeptWrong = oms_body.getString(gis_status_name).equals("5")
//      val isSssDeptWrong = oms_body.getString(sss_status_name).equals("5")
//      val isGisSssDeptWrong = oms_body.getString(gis_sss_status_name).equals("5")
//      val isArssDeptWrong = oms_body.getString(arss_status_name).equals("5")
//      val isFinalDeptWrong = oms_body.getString(final_status_name).equals("5")
//      var flag = "1"
//      if (isGisDeptWrong || isSssDeptWrong || isGisSssDeptWrong || isArssDeptWrong || isFinalDeptWrong) flag = "0" //有网点错分
//      (flag, json)
//    })
//
//    val custSameRdd = custWrongRdd2.filter(obj => {
//      !"0".equals(obj._1)
//    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>大客户无错分数据量：" + custSameRdd.count())
//    val custWrongRdd = custWrongRdd2.filter(_._1 == "0").values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>大客户网点错分数据量：" + custWrongRdd.count())
//    barWrongRdd.unpersist()
//
//    val wdpOperMap = WdpOperDataGetter.getWdpOperData(startDate, zno2DeptMap)
//    logger.error(">>>补码数据量：" + wdpOperMap.size)
//    val wdpOperMapBrod = sc.broadcast(wdpOperMap)
//
//    val wrongRdd = custWrongRdd.map(json => {
//      val oms_body = json.getJSONObject("oms_body")
//      val final_status = oms_body.getString(final_status_name)
//      val gis_dept_map = oms_body.getString(gis_dept_map_name)
//      val gis_dept = if (gis_dept_map != null) gis_dept_map else oms_body.getString(gis_dept_name)
//      val sss_dept_map = oms_body.getString(sss_dept_map_name)
//      val sss_dept = if (sss_dept_map != null) sss_dept_map else oms_body.getString(sss_dept_name)
//      val arss_dept_map = oms_body.getString(arss_dept_map_name)
//      val arss_dept = if (arss_dept_map != null) arss_dept_map else oms_body.getString(arss_dept_name)
//      val waybillno = oms_body.getString("waybillno")
//      val oper_dept = if (wdpOperMapBrod.value.contains(waybillno)) wdpOperMapBrod.value.apply(waybillno) else ""
//      oms_body.put("oper_dept", oper_dept)
//      if ("5".equals(final_status) && gis_dept.equals(sss_dept) && gis_dept.equals(oper_dept)
//        && (arss_dept == null || "".equals(arss_dept) || gis_dept.equals(arss_dept))) {
//        oms_body.put("oper_status", "1")
//      }
//      json
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>把枪网点有错分数据量（即错分数据总量）：" + wrongRdd.count())
//    //    wrongRdd.take(4).foreach(o => println(o))
//    custWrongRdd.unpersist()
//    val gisNonWrongRdd = wrongRdd.filter(json => {
//      "1".equals(json.getJSONObject("oms_body").getString("oper_status"))
//    })
//    logger.error(">>>补码后gis无错分数据量：" + gisNonWrongRdd.count())
//
//
//    val sameRdd = dlvSameRdd.union(empSameRdd).union(barSameRdd).union(custSameRdd).map(obj => {
//      val saveKey = Array("province", "region", "city_code", "city", "oms_body", "dlv_body")
//      //只保留后面使用的字段
//      val keyArray = obj.keySet().toArray()
//      for (key <- keyArray) {
//        if (!saveKey.contains(key.toString)) {
//          obj.remove(key)
//        }
//      }
//      obj
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>无错分数据量（即总无分数据总量）：" + sameRdd.count())
//
//    //    sameRdd.take(4).foreach(o => println(o))
//    dlvSameRdd.unpersist()
//    empSameRdd.unpersist()
//    barSameRdd.unpersist()
//    custSameRdd.unpersist()
//    (wrongRdd, sameRdd, barCacheData)
//  }
//
//  def getWeightDept(beforeDept: String, weight: Double, weightDeptMap: Map[String, JSONArray]): String = {
//    var behindDept: String = null
//    if (weightDeptMap.contains(beforeDept)) {
//      val weightDeptArr = weightDeptMap.apply(beforeDept)
//      val loop = new Breaks
//      loop.breakable(
//        for (i <- 0 until weightDeptArr.size()) {
//          val weightArrObj = weightDeptArr.getJSONObject(i)
//          val dept_code_behind = weightArrObj.getString("dept_code_behind")
//          var min_weight = 0.0
//          try {
//            min_weight = weightArrObj.getString("min_weight").toDouble
//          } catch {
//            case e: Exception => logger.error(">>>mix_weight转换异常：" + e)
//          }
//          var max_weight = 0.0
//          try {
//            max_weight = weightArrObj.getString("max_weight").toDouble
//          } catch {
//            case e: Exception => logger.error(">>>max_weight转换异常：" + e)
//          }
//          if (weight >= min_weight && weight < max_weight) {
//            behindDept = dept_code_behind
//            loop.break()
//          }
//        }
//      )
//    }
//    behindDept
//  }
//
//  /**
//   * 解析的错分明细数据入hive库
//   *
//   * @param standardRdd
//   * @param spark
//   * @param dateList
//   */
//  def handleWrongData(standardRdd: RDD[JSONObject],
//                      spark: SparkSession,
//                      dateList: Array[String]): Unit = {
//    try {
//      val detailDataRdd = WdIndexStat.getWdDetailData(standardRdd)
//      //      detailDataRdd.take(3).foreach(o => println(o))
//      for (statDate <- dateList) {
//        val dateRdd = detailDataRdd.filter(json => {
//          val req_date = json.getJSONObject("oms_body").getString("req_date")
//          req_date.equals(statDate)
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//        val count = dateRdd.count()
//        logger.error(">>>" + statDate + "号错分详细数据量：" + count + ",数据入hive库中----------------------------------")
//        if (count != 0) {
//          saveWrongRddToHive(dateRdd, spark, statDate)
//          logger.error(">>>" + statDate + "号错分详细数据量数据入mysql库中----------------------------------")
//          saveWrongRddToMysql(dateRdd, statDate)
//          if (statDate.equals(Util.getDay(dateList.apply(dateList.length - 1), -5, ""))) {
//            logger.error(">>>" + statDate + "号错分详细数据量数据入错分补码原始表库中----------------------------------")
//            saveWrongRddToMysql2(dateRdd, statDate)
//            doSaveWrongAddressToMysql(dateRdd, statDate)
//          }
//        }
//
//        dateRdd.unpersist()
//      }
//    } catch {
//      case e: Exception => logger.error(">>>错分明细数据处理异常：" + e)
//    }
//
//  }
//
//  /**
//   * 保存错分明细到mysql
//   * 保存前先删除之前改天数据
//   *
//   * @param detailDataRdd
//   * @param incDay
//   */
//  def saveWrongRddToMysql(detailDataRdd: RDD[JSONObject], incDay: String): Unit = {
//    //删除一天的数据
//    val conn2 = ManagerFactory.createManager(classOf[WdManager]).getConn
//    val stmt2 = conn2.createStatement()
//    val table = "wrong_dispatch_data_origin_multi_day"
//    val delGisSql = String.format(s"delete from $table where data_time='%s'", incDay)
//    logger.error(">>>保存之前，删除历史数据:" + delGisSql)
//    stmt2.executeUpdate(delGisSql)
//    conn2.close()
//    logger.error(">>>删除成功")
//    doSaveWrongRddToMysql(detailDataRdd, incDay, table)
//  }
//
//  /**
//   * 保存错分明细到mysql
//   *
//   * @param detailDataRdd
//   * @param incDay
//   */
//  def saveWrongRddToMysql2(detailDataRdd: RDD[JSONObject], incDay: String): Unit = {
//    val table = "wrong_dispatch_data_origin_by_day"
//    doSaveWrongRddToMysql(detailDataRdd, incDay, table)
//  }
//
//  def doSaveWrongRddToMysql(detailDataRdd: RDD[JSONObject], incDay: String, table: String): Unit = {
//    detailDataRdd.repartition(20).foreachPartition(p => {
//      val conn = ManagerFactory.createManager(classOf[WdManager]).getConn
//      val stmt = conn.createStatement()
//      while (p.hasNext) {
//        val obj = p.next()
//        val is_done = '0'
//        val frequency = '1'
//        val address = JSONUtil.getJsonVal(obj, "oms_body.req_addresss", "").replaceAll("['\"]", "")
//        val unique_md5 = MD5Util.getMD5(address).toLowerCase
//        val sssdeptcodeto = JSONUtil.getJsonVal(obj, "oms_body.sss_dept", "").replaceAll("['\"]", "")
//        val gisdeptcodeto = JSONUtil.getJsonVal(obj, "oms_body.gis_dept", "").replaceAll("['\"]", "")
//        val gisteamcodeto = JSONUtil.getJsonVal(obj, "oms_body.gis_tc", "").replaceAll("['\"]", "")
//        val data_time = incDay
//        val final_dept = JSONUtil.getJsonVal(obj, "dlv_body.dlv_dept_map", "").replaceAll("['\"]", "")
//        val origin_src = JSONUtil.getJsonVal(obj, "oms_body.lib_src", "").replaceAll("['\"]", "")
//        val city_code = JSONUtil.getJsonVal(obj, "oms_body.city_code", "").replaceAll("['\"]", "")
//        val waybillNo = JSONUtil.getJsonVal(obj, "oms_body.waybillno", "").replaceAll("['\"]", "")
//        val req_addresseemobile = JSONUtil.getJsonVal(obj, "oms_body.req_addresseemobile", "").replaceAll("['\"]", "")
//        val req_addresseephone = JSONUtil.getJsonVal(obj, "oms_body.req_addresseephone", "").replaceAll("['\"]", "")
//        val deptType = JSONUtil.getJsonVal(obj, "oms_body.type1", "").replaceAll("['\"]", "")
//        val sbdeptcode = JSONUtil.getJsonVal(obj, "oms_body.arss_dept", "").replaceAll("['\"]", "")
//        val service_final_dept = JSONUtil.getJsonVal(obj, "oms_body.gis_sss_dept", "").replaceAll("['\"]", "")
//        val dept_req_address = JSONUtil.getJsonVal(obj, "oms_body.arss_req_address", "").replaceAll("['\"]", "")
//        val zonecode = JSONUtil.getJsonVal(obj, "dlv_body.dlv_dept", "").replaceAll("['\"]", "")
//        val gis_to_sys_depttoretby = JSONUtil.getJsonVal(obj, "oms_body.sys_src", "").replaceAll("['\"]", "")
//        val courierCode = JSONUtil.getJsonVal(obj, "dlv_body.courier_code", "").replaceAll("['\"]", "")
//        val courierDeptCode = JSONUtil.getJsonVal(obj, "emp_body.emp_dept", "").replaceAll("['\"]", "")
//        val planDeptCode = ""
//        val mapDept = JSONUtil.getJsonVal(obj, "bar_body.bar_dept", "").replaceAll("['\"]", "")
//        var x = JSONUtil.getJsonVal(obj, "bar_body.bar_scan_lng", "").replaceAll("['\"]", "")
//        var y = JSONUtil.getJsonVal(obj, "bar_body.bar_scan_lat", "").replaceAll("['\"]", "")
//        if ("".equals(x) || "0".equals(x) || "0.0".equals(x)) {
//          x = null
//          y = null
//        }
//
//        val type2 = JSONUtil.getJsonVal(obj, "oms_body.type2", "").replaceAll("['\"]", "")
//        val city = JSONUtil.getJsonVal(obj, "oms_body.city", "").replaceAll("['\"]", "")
//        val splitresult = JSONUtil.getJsonVal(obj, "oms_body.splitresult", "").replaceAll("['\"]", "")
//        val splittype = JSONUtil.getJsonVal(obj, "oms_body.splittype", "").replaceAll("['\"]", "")
//        val groupid = JSONUtil.getJsonVal(obj, "oms_body.gis_to_sys_groupid", "").replaceAll("['\"]", "")
//        val filter = JSONUtil.getJsonVal(obj, "oms_body.filters", "").replaceAll("['\"]", "")
//        val adcode = JSONUtil.getJsonVal(obj, "oms_body.adcode", "").replaceAll("['\"]", "")
//        val geocd_keywords = JSONUtil.getJsonVal(obj, "oms_body.keywords", "").replaceAll("['\"]", "")
//        val geocd_groupids = JSONUtil.getJsonVal(obj, "oms_body.groupids", "").replaceAll("['\"]", "")
//        val geocd_matchids = JSONUtil.getJsonVal(obj, "oms_body.matchids", "").replaceAll("['\"]", "")
//        val geocd_adcodes = JSONUtil.getJsonVal(obj, "oms_body.adcodes", "").replaceAll("['\"]", "")
//        val oper_dept = JSONUtil.getJsonVal(obj, "oms_body.oper_dept", "").replaceAll("['\"]", "")
//        val oper_status = JSONUtil.getJsonVal(obj, "oms_body.oper_status", "").replaceAll("['\"]", "")
//        val cust_dept = JSONUtil.getJsonVal(obj, "oms_body.cust_dept", "").replaceAll("['\"]", "")
//        val typeDetail = JSONUtil.getJsonVal(obj, "oms_body.type", "").replaceAll("['\"]", "")
//        val gis_status = if ("5".equals(JSONUtil.getJsonVal(obj, "oms_body.gis_status", "").replaceAll("['\"]", ""))) "0" else "1"
//        val sss_status = if ("5".equals(JSONUtil.getJsonVal(obj, "oms_body.sss_status", "").replaceAll("['\"]", ""))) "0" else "1"
//        val gis_sss_status = if ("5".equals(JSONUtil.getJsonVal(obj, "oms_body.gis_sss_status", "").replaceAll("['\"]", ""))) "0" else "1"
//        val arss_status = if ("5".equals(JSONUtil.getJsonVal(obj, "oms_body.arss_status", "").replaceAll("['\"]", ""))) "0" else "1"
//        val final_status = if ("5".equals(JSONUtil.getJsonVal(obj, "oms_body.final_status", "").replaceAll("['\"]", ""))) "0" else "1"
//        //月结账户
//        val accountantcode = JSONUtil.getJsonVal(obj, "wide_body.freight_monthly_acct_code", "").replaceAll("['\"]", "")
//        val source_zone_code = JSONUtil.getJsonVal(obj, "wide_body.source_zone_code", "").replaceAll("['\"]", "")
//        val dest_dist_code = JSONUtil.getJsonVal(obj, "wide_body.dest_dist_code", "").replaceAll("['\"]", "")
//        val req_comp_name = JSONUtil.getJsonVal(obj, "oms_body.req_comp_name", "").replaceAll("['\"]", "")
//        val req_city = JSONUtil.getJsonVal(obj, "oms_body.req_city", "").replaceAll("['\"]", "")
//        val req_area = JSONUtil.getJsonVal(obj, "oms_body.req_area", "").replaceAll("['\"]", "")
//        val req_province = JSONUtil.getJsonVal(obj, "oms_body.req_province", "").replaceAll("['\"]", "")
//        val id = data_time + "_" + waybillNo + "_" + city_code
//        val sql =
//          s"""insert ignore into $table(id, is_done, frequency, unique_md5, address, sssdeptcodeto, gisdeptcodeto,
//             | gisteamcodeto, data_time, final_dept, origin_src, city_code, waybillNo, req_addresseemobile,
//             | req_addresseephone, deptType, sbdeptcode, service_final_dept, dept_req_address, zonecode,
//             | gis_to_sys_depttoretby, courierCode, courierDeptCode, planDeptCode, mapDept, x, y, type2,
//             | city, splitresult, splittype, groupid, filter, adcode, geocd_keywords, geocd_groupids,
//             | geocd_matchids, geocd_adcodes, oper_dept, oper_status, cust_dept, gis_status, sss_status,
//             | gis_sss_status, arss_status, final_status, re_identrs, type,accountantcode,source_zone_code,dest_dist_code,
//             | req_comp_name,req_city,req_area,req_province)
//             | values ('$id', '$is_done', '$frequency', '$unique_md5', '$address',
//             | '$sssdeptcodeto', '$gisdeptcodeto', '$gisteamcodeto', '$data_time', '$final_dept', '$origin_src',
//             | '$city_code', '$waybillNo', '$req_addresseemobile', '$req_addresseephone', '$deptType', '$sbdeptcode',
//             | '$service_final_dept', '$dept_req_address', '$zonecode', '$gis_to_sys_depttoretby', '$courierCode',
//             | '$courierDeptCode', '$planDeptCode', '$mapDept', $x, $y, '$type2', '$city', '$splitresult',
//             | '$splittype', '$groupid', '$filter', '$adcode', '$geocd_keywords', '$geocd_groupids',
//             | '$geocd_matchids', '$geocd_adcodes', '$oper_dept', '$oper_status', '$cust_dept',
//             | '$gis_status', '$sss_status', '$gis_sss_status', '$arss_status', '$final_status',
//             | '$sbdeptcode', '$typeDetail', '$accountantcode','$source_zone_code','$dest_dist_code','$req_comp_name',
//             | '$req_city','$req_area','$req_province')""".stripMargin
//        try {
//          stmt.execute(sql)
//        } catch {
//          case e: Exception =>
//            logger.error(sql, e)
//        }
//      }
//      conn.close()
//    })
//  }
//
//  def doSaveWrongAddressToMysql(detailDataRdd: RDD[JSONObject], incDay: String): Unit = {
//    val table = "sss_gis_diff_address_order"
//    detailDataRdd.repartition(20).foreachPartition(p => {
//      val conn = ManagerFactory.createManager(classOf[WdManager]).getConn
//      val stmt = conn.createStatement()
//      while (p.hasNext) {
//        val obj = p.next()
//        val address = JSONUtil.getJsonVal(obj, "oms_body.req_addresss", "").replaceAll("['\"]", "")
//        val addressMd5 = MD5Util.getMD5(address).toLowerCase
//        val city_code = JSONUtil.getJsonVal(obj, "oms_body.city_code", "").replaceAll("['\"]", "")
//        val waybillNo = JSONUtil.getJsonVal(obj, "oms_body.waybillno", "").replaceAll("['\"]", "")
//        val jobject = new JSONObject()
//        jobject.put("address", address)
//        jobject.put("waybillNo", waybillNo)
//        val uniqueMd5 = MD5Util.getMD5(jobject.toJSONString).toLowerCase
//        val origin_src = ""
//        val data_time = incDay.replaceAll("(\\d{4})(\\d{2})(\\d{2})", "$1-$2-$3")
//        val id = incDay + "_" + waybillNo + "_" + city_code
//        val sql =
//          s"""insert ignore into $table(id, unique_md5, address_src_md5, address, origin_src,
//             | data_time, waybillNo, city_code)
//             | values ('$id', '$uniqueMd5', '$addressMd5', '$address', '$origin_src',
//             | '$data_time', '$waybillNo', '$city_code')""".stripMargin
//        try {
//          stmt.execute(sql)
//        } catch {
//          case e: Exception =>
//            logger.error(sql, e)
//        }
//      }
//      conn.close()
//    })
//  }
//
//  def saveWrongRddToHive(detailDataRdd: RDD[JSONObject], spark: SparkSession, incDay: String): Unit = {
//    spark.sql("use dm_gis")
//    val WRONG_TABLE = "rds_wd_detail"
//
//    //1 构造DataFrame的元数据 StructField
//    import java.util
//    val structFileds = new util.ArrayList[StructField]()
//    val structs = Array("waybillno", "province", "region", "city_code", "city", "req_time", "req_addresss",
//      "final_dept", "final_dept_map", "final_dept_src", "gis_dept", "gis_dept_map", "sss_dept", "sss_dept_map",
//      "sys_src", "lib_src", "gis_tc", "arss_dept", "arss_dept_map", "arss_req_address", "dlv_dept", "dlv_dept_map",
//      "courier_code", "courier_dept", "courier_dept_map", "x", "y", "bar_dept", "bar_dept_map", "handle_date",
//      "handle_time", "type1", "type2", "json", "groupid", "req_addresseemobile", "req_addresseephone",
//      "geocd_city", "adcode", "splitresult", "splittype", "geocd_groupids",
//      "geocd_filters", "geocd_keywords", "geocd_matchids", "geocd_adcodes", "oper_dept", "oper_status", "cust_dept", "type")
//    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
//    //2 构建StructType用于DataFrame的元数据描述
//    val structType = DataTypes.createStructType(structFileds)
//    //3 构建Row格式数据集RDD[Row]
//    val rowRdd = detailDataRdd.map(obj => {
//      var row: Row = null
//      try {
//        val names = Array("oms_body.waybillno", "province", "region", "city_code", "city", "oms_body.req_time",
//          "oms_body.req_addresss", "oms_body.final_dept", "oms_body.final_dept_map", "oms_body.final_dept_src",
//          "oms_body.gis_dept", "oms_body.gis_dept_map", "oms_body.sss_dept", "oms_body.sss_dept_map",
//          "oms_body.sys_src", "oms_body.lib_src", "oms_body.gis_tc", "oms_body.arss_dept", "oms_body.arss_dept_map",
//          "oms_body.arss_req_address", "dlv_body.dlv_dept", "dlv_body.dlv_dept_map", "dlv_body.courier_code",
//          "emp_body.emp_dept", "emp_body.emp_dept_map", "bar_body.bar_scan_lng", "bar_body.bar_scan_lat",
//          "bar_body.bar_dept", "bar_body.bar_dept_map", "handle_date", "handle_time", "oms_body.type1",
//          "oms_body.type2", "oms_body.gis_to_sys_groupid", "oms_body.req_addresseemobile",
//          "oms_body.req_addresseephone", "oms_body.city", "oms_body.adcode", "oms_body.splitresult",
//          "oms_body.splittype", "oms_body.groupids", "oms_body.filters", "oms_body.keywords", "oms_body.matchids",
//          "oms_body.adcodes", "oms_body.oper_dept", "oms_body.oper_status", "oms_body.cust_dept", "oms_body.type")
//        val values = new Array[String](names.length)
//        for (i <- names.indices) values(i) = JSONUtil.getJsonVal(obj, names(i), "")
//        //        values(names.length) = obj.toString
//        row = RowFactory.create(values(0), values(1), values(2), values(3), values(4), values(5), values(6), values(7),
//          values(8), values(9), values(10), values(11), values(12), values(13), values(14), values(15), values(16), values(17),
//          values(18), values(19), values(20), values(21), values(22), values(23), values(24), values(25), values(26),
//          values(27), values(28), values(29), values(30), values(31), values(32), obj.toString, values(33), values(34),
//          values(35), values(36), values(37), values(38), values(39), values(40), values(41), values(42), values(43),
//          values(44), values(45), values(46), values(47), values(48))
//      } catch {
//        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
//      }
//      row
//    }).filter(_ != null).repartition(1)
//    // 4 构建DataFrame
//    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
//    //5 基于Datarame创建临时表
//    val tempView = String.format("%s_temp_view", WRONG_TABLE)
//    df.createOrReplaceTempView(tempView)
////    //6 分区、表等操作
////    val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", WRONG_TABLE, incDay)
////    logger.error(">>>删除分区：" + deleteSql)
////    spark.sql(deleteSql)
////    val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", WRONG_TABLE, incDay)
////    logger.error(">>>新建分区：" + createPartitionSql)
////    spark.sql(createPartitionSql)
//    //7 把临时表的数据刷进hive表中
//    spark.sql(String.format("insert overwrite table %s partition(inc_day = '%s') select * from %s", WRONG_TABLE, incDay, tempView))
//    logger.error(">>>数据入hive库结束!")
//  }
//
//
//  def saveWrongRddToHive1(detailDataRdd: RDD[JSONObject], spark: SparkSession, incDay: String): Unit = {
//    spark.sql("use dm_gis")
//    val WRONG_TABLE = "oms_wd_detail"
//
//    //1 构造DataFrame的元数据 StructField
//    import java.util
//    val structFileds = new util.ArrayList[StructField]()
//    val structs = Array("waybillno", "province", "region", "city_code", "city", "req_time", "req_addresss", "gis_dept", "sss_dept", "sys_src", "lib_src", "gis_tc", "arss_dept", "arss_req_address", "dlv_dept", "dlv_dept_map", "courier_code", "courier_dept", "courier_dept_map", "x", "y", "bar_dept", "bar_dept_map", "handle_date", "handle_time", "type1", "type2", "json")
//    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
//    //2 构建StructType用于DataFrame的元数据描述
//    val structType = DataTypes.createStructType(structFileds)
//    //3 构建Row格式数据集RDD[Row]
//    val rowRdd = detailDataRdd.map(obj => {
//      var row: Row = null
//      try {
//        val names = Array("oms_body.waybillno", "province", "region", "city_code", "city", "oms_body.req_time", "oms_body.req_addresss", "oms_body.gis_dept", "oms_body.sss_dept", "oms_body.sys_src", "oms_body.lib_src", "oms_body.gis_tc", "oms_body.arss_dept", "oms_body.arss_req_address", "dlv_body.dlv_dept", "dlv_body.dlv_dept_map", "dlv_body.courier_code", "emp_body.emp_dept", "emp_body.emp_dept_map", "bar_body.bar_scan_lng", "bar_body.bar_scan_lat", "bar_body.bar_dept", "bar_body.bar_dept_map", "handle_date", "handle_time", "oms_body.type1", "oms_body.type2")
//        val values = new Array[String](names.length + 1)
//        for (i <- names.indices) values(i) = JSONUtil.getJsonVal(obj, names(i), "")
//        values(names.length) = obj.toString
//        row = RowFactory.create(values(0), values(1), values(2), values(3), values(4), values(5), values(6), values(7), values(8), values(9), values(10), values(11), values(12), values(13), values(14), values(15), values(16), values(17), values(18), values(19), values(20), values(21), values(22), values(23), values(24), values(25), values(26), obj.toString)
//      } catch {
//        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
//      }
//      row
//    }).filter(_ != null)
//    // 4 构建DataFrame
//    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
//    //5 基于Datarame创建临时表
//    val tempView = String.format("%s_temp_view", WRONG_TABLE)
//    df.createOrReplaceTempView(tempView)
//    //6 分区、表等操作
//    val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", WRONG_TABLE, incDay)
//    logger.error(">>>删除分区：" + deleteSql)
//    spark.sql(deleteSql)
//    val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", WRONG_TABLE, incDay)
//    logger.error(">>>新建分区：" + createPartitionSql)
//    spark.sql(createPartitionSql)
//    //7 把临时表的数据刷进hive表中
//    spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", WRONG_TABLE, incDay, tempView))
//    logger.error(">>>数据入hive库结束!")
//  }
//
//  /**
//   * 获取运单宽表重量大于20的数据量
//   *
//   * @param startDate
//   * @param endDate
//   * @param spark
//   * @return
//   */
//  def getWideRdd(startDate: String, endDate: String, spark: SparkSession,
//                 dlvResultRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
//    logger.error("将妥投表需要关联的数据抽取出来，减少数据量")
//    import spark.implicits._
//    val waybillInfoRdd = dlvResultRdd.filter(obj => {
//      val oms_body = obj._2.getJSONObject("oms_body")
//      val dlv_body = obj._2.getJSONObject("dlv_body")
//      checkWrong(oms_body, dlv_body)
//    }).map(obj => {
//      (obj._1)
//    }).toDF("waybillno")
//    val tmpView = "tmpWaybillInfo"
//    waybillInfoRdd.createOrReplaceTempView(tmpView)
//    //    val wideRdd
//    val selectWideSql =
//      s"""
//         |select waybill_no,meterage_weight_qty,dest_dist_code,freight_monthly_acct_code,source_zone_code
//         |from (
//         |select waybill_no,meterage_weight_qty,dest_dist_code,freight_monthly_acct_code,source_zone_code
//         |from dm_gis.tt_waybill_info where inc_day between '$startDate' and '$endDate' and meterage_weight_qty is not null)
//         |a join ${tmpView} b on a.waybill_no=b.waybillno
//       """.stripMargin
//    ///数据量太大了，跑最终决定那天的数据，其他天的明天在跑
//    //    val selectWideSql =
//    //      s"""
//    //         |select inc_day,waybill_no,meterage_weight_qty,dest_dist_code,freight_monthly_acct_code,source_zone_code
//    //         |from dm_gis.tt_waybill_info where inc_day between '$startDate' and '$startDate' and meterage_weight_qty is not null
//    //         |group by inc_day,waybill_no,meterage_weight_qty,dest_dist_code,freight_monthly_acct_code,source_zone_code
//    //       """.stripMargin
//
//
//    //    val selectWideSql = "select * from tmp_dm_gis.rds_wide_1111"
//    println("selectWideSql:" + selectWideSql)
//
//    val wideDf = spark.sql(selectWideSql).rdd.repartition(2000)
//    val wideRdd = wideDf.map(row => {
//      //      val inc_day = row.getString(0)
//      val waybill_no = row.getString(0)
//      val meterage_weight_qty = row.getDouble(1).toString
//      val dest_dist_code = row.getString(2)
//      val freight_monthly_acct_code = row.getString(3)
//      val source_zone_code = row.getString(4)
//      val json = new JSONObject()
//      //      json.put("wide_day", inc_day)
//      //      json.put("waybill_no", waybill_no)
//      json.put("meterage_weight_qty", meterage_weight_qty)
//      json.put("dest_dist_code", dest_dist_code)
//      json.put("freight_monthly_acct_code", freight_monthly_acct_code)
//      json.put("source_zone_code", source_zone_code)
//      val result = new JSONObject()
//      result.put("wide_body", json)
//      (waybill_no, result)
//    })
//    wideRdd
//  }
//
//  /**
//   * 获取运单宽表rdd
//   *
//   * @param spark
//   * @param date
//   * @return
//   */
//  def getWeightMapDept(spark: SparkSession, date: String, zno2DeptMap: Map[String, String]): Map[String, JSONArray] = {
//    //    val wideRdd
//    val selectWeightMapSql =
//      """
//        |select
//        |  inc_day,
//        |  min_weight,
//        |  max_weight,
//        |  dept_code_before,
//        |  dept_code_behind,
//        |  push_time
//        |from
//        |  (
//        |    select
//        |      inc_day,
//        |      min_weight,
//        |      max_weight,
//        |      dept_code_before,
//        |      dept_code_behind,
//        |      push_time,
//        |      row_number() over(
//        |        partition by min_weight,
//        |        max_weight,
//        |        dept_code_before,
//        |        dept_code_behind
//        |        order by
//        |          push_time desc
//        |      ) rank
//        |    from
//        |      (
//        |        select
//        |          inc_day,
//        |          get_json_object(log, '$.minWeight') min_weight,
//        |          get_json_object(log, '$.maxWeight') max_weight,
//        |          get_json_object(log, '$.deptCodeBefore') dept_code_before,
//        |          get_json_object(log, '$.deptCodeBehind') dept_code_behind,
//        |          get_json_object(log, '$.pushTime') push_time
//        |        from
//        |          dm_gis.sss_2020_weight_config
//        |        where
//        |""".stripMargin +
//        s"inc_day = '$date' " +
//        """
//          |          and get_json_object(log, '$.isDele') = 0
//          |      ) b
//          |  ) a
//          |where
//          |  rank = 1
//          |""".stripMargin
//    println("selectWeightMapSql:" + selectWeightMapSql)
//    var map: Map[String, JSONArray] = Map()
//    val headers = Array("inc_day", "min_weight", "max_weight", "dept_code_before", "dept_code_behind", "push_time")
//    val inputRdd = spark.sql(selectWeightMapSql).rdd.map(row => {
//      val json: JSONObject = new JSONObject()
//      for (i <- headers.indices) json.put(headers(i), row(i))
//      val dept_code_behind = json.getString("dept_code_behind")
//      if (zno2DeptMap.contains(dept_code_behind)) json.put("dept_code_behind", zno2DeptMap.get(dept_code_behind))
//      json
//    })
//    //    logger.error(">>>读取" + date + "号重量映射数据量：" + inputRdd.count())
//    //    inputRdd.take(1).foreach(o => println(o))
//
//    val weightRdd = inputRdd.filter(json => {
//      val dept_code_before = json.getString("dept_code_before")
//      val dept_code_behind = json.getString("dept_code_behind")
//      dept_code_before != null && dept_code_behind != null && !dept_code_before.equals(dept_code_behind)
//    })
//    //    logger.error(">>>有效映射的数据量：" + weightRdd.count())
//
//    val groupRdd = weightRdd.flatMap(json => {
//      val list = new util.ArrayList[(String, JSONObject)]()
//      val dept_code_behind = json.getString("dept_code_behind").split(",")(0)
//      val min_weight = json.getString("min_weight").toDouble
//      val max_weight = json.getString("max_weight").toDouble
//      val deptCodeBefores = json.getString("dept_code_before").split(",")
//      for (dept_code_before <- deptCodeBefores) {
//        if (!dept_code_before.equals("")) {
//          val obj = new JSONObject()
//          obj.put("dept_code_behind", dept_code_behind)
//          obj.put("min_weight", min_weight)
//          obj.put("max_weight", max_weight)
//          list.add((dept_code_before, obj))
//        }
//      }
//      list.iterator()
//    }).groupByKey.map(obj => {
//      val dept_code_before = obj._1
//      val groupObj: Iterable[JSONObject] = obj._2
//      val validKeySet = new util.HashSet[String]() //记录出现过的映射关系，用于排重
//      val jsonArray = new JSONArray()
//      for (json <- groupObj) {
//        val dept_code_behind = json.getString("dept_code_behind")
//        val min_weight = json.getString("min_weight")
//        val max_weight = json.getString("max_weight")
//        val key = dept_code_behind + "_" + min_weight + "_" + max_weight
//        if (!validKeySet.contains(key)) {
//          jsonArray.add(json)
//          validKeySet.add(key)
//        }
//      }
//      (dept_code_before, jsonArray)
//    })
//    //    logger.error(">>>分组后的数据量："+groupRdd.count())
//    //    groupRdd.take(3).foreach(o=>println(o))
//    groupRdd.collect().foreach(o => {
//      val dept_code_before = o._1
//      val jsonArray = o._2
//      map += (dept_code_before -> jsonArray)
//    })
//    logger.error("按照网点聚合后数量:" + map.size)
//    map
//  }
//
//
//  /**
//   * 获取小哥网点的数据
//   *
//   * @param startDate
//   * @param endDate
//   * @param spark
//   * @return
//   */
//  def getEmpRdd(startDate: String, endDate: String, spark: SparkSession): RDD[(String, JSONObject)] = {
//
//    var empRdd: RDD[(String, JSONObject)] = null
//    try {
//      val selectEmpSql =
//        s"""
//           |select inc_day ,emp_code ,dept_code from gdl.tt_emp_info where inc_day between '$startDate' and '$endDate'
//         """.stripMargin
//      println("selectEmpSql:" + selectEmpSql)
//      val empDf = spark.sql(selectEmpSql).rdd
//      empRdd = empDf.map(row => {
//        val inc_day = row.getString(0)
//        var emp_code = row.getString(1)
//        val emp_dept = row.getString(2)
//        val json = new JSONObject()
//        json.put("emp_day", inc_day)
//        json.put("emp_code", emp_code)
//        json.put("emp_dept", emp_dept)
//        //注意：员工表中的员工号都有补0，因此要转换一下
//        try {
//          emp_code = Integer.parseInt(emp_code).toString
//        } catch {
//          case e: Exception => logger.error(">>>转换员工工号异常：" + e + ",json:" + json)
//        }
//        val key = inc_day + "_" + emp_code
//        val result = new JSONObject()
//        result.put("emp_body", json)
//        (key, result)
//      })
//    } catch {
//      case e: Exception => logger.error(">>>获取小哥工号rdd失败" + e)
//    }
//
//    empRdd
//  }
//
//
//  /**
//   * 获取把枪运单和经纬度的数据
//   *
//   * @param startDate
//   * @param endDate
//   * @param spark
//   * @return
//   */
//  def getBarRdd(startDate: String, endDate: String, spark: SparkSession): RDD[(String, JSONObject)] = {
//    val emptyList = new util.ArrayList[(String, JSONObject)]
//    val retRdd = spark.sparkContext.parallelize(emptyList)
//    //    return retRdd
//    val selectBarSql =
//      s"""
//         |select inc_day,waybill_no,delivery_lgt,delivery_lat from
//         |(select inc_day,waybill_no,delivery_lgt,delivery_lat,
//         |row_number() over (partition by waybill_no order by signin_tm desc) as rank  from dm_gis.tt_waybill_info
//         |where inc_day between '$startDate' and '$endDate' and delivery_lgt is not null and delivery_lgt<>'' and delivery_lgt <> '0.0'
//         |and delivery_lat is not null and delivery_lat<>'' and delivery_lat <> '0.0')b where b.rank=1
//       """.stripMargin
//    //    val selectBarSql ="select * from tmp_dm_gis.rds_bar_1111"
//    println("selectBarSql:" + selectBarSql)
//    val barDf = spark.sql(selectBarSql).rdd
//    val barRdd = barDf.map(row => {
//      try {
//        val bar_day = row.getString(0)
//        val bar_waybillno = row.getString(1)
//        val bar_scan_lng = row.getString(2).toDouble
//        val bar_scan_lat = row.getString(3).toDouble
//        val json = new JSONObject()
//        json.put("bar_day", bar_day)
//        json.put("bar_waybillno", bar_waybillno)
//        json.put("bar_scan_lng", bar_scan_lng)
//        json.put("bar_scan_lat", bar_scan_lat)
//        val result = new JSONObject()
//        result.put("bar_body", json)
//        (bar_waybillno, result)
//      } catch {
//        case e: Exception => logger.error(e)
//          (null, null)
//      }
//    }).filter(obj => obj._1 != null)
//    barRdd
//  }
//
//
//  /**
//   * 获取cms库数据库连接
//   *
//   * @return
//   */
//  def getCmsConn: Connection = {
//    var conn: Connection = null
//    var dataSource: DruidDataSource = null
//    try {
//      dataSource = new DruidDataSource()
//      dataSource.setDriverClassName(comUtil.getValue("cms.mysql.driver"))
//      dataSource.setUrl(comUtil.getValue("cms.mysql.url"))
//      dataSource.setUsername(comUtil.getValue("cms.mysql.uid"))
//      dataSource.setPassword(comUtil.getValue("cms.mysql.pwd"))
//      dataSource.setMaxActive(20)
//      dataSource.setMaxWait(3000)
//      dataSource.setRemoveAbandoned(false)
//      conn = dataSource.getConnection
//    } catch {
//      case e: Exception => println(">>>mysql数据库连接异常：" + e)
//    }
//    conn
//  }
//
//  /**
//   *
//   * @return
//   */
//  def getCmsData: Map[String, String] = {
//    val conn = getCmsConn
//    logger.error(">>>755深圳的用st_zno_depart这个表，其他城市用st_sss_zno_depart这个表")
//    //    val cms_sql =
//    //      s"""
//    //         |SELECT DISTINCT
//    //         |	zno_code,depart_code,type_code
//    //         |FROM
//    //         |	st_sss_zno_depart
//    //         |WHERE
//    //         |	 type_code IN ('FB04-YWX','DB05-DB','DB05-DLD',	'DB05-SFZ','FB04-XMFB','DB05-XMDB')
//    //       """.stripMargin
//    //    logger.error(">>>cms_sql:"+cms_sql)
//    //    val cmsLists: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn,cms_sql,Array("zno_code","depart_code","type_code"))
//
//    val cms755_sql =
//      s"""
//         |SELECT DISTINCT
//         |	zno_code,depart_code,type_code
//         |FROM
//         |	st_zno_depart
//         |WHERE
//         |	 city_code = '755' and type_code IN ('FB04-YWX','DB05-DB','DB05-DLD', 'DB05-SFZ','FB04-XMFB','DB05-XMDB','DB05-YYZ','ZZC05-SJ','FB04-YWX','DB05-DB','DB05-DLD',	'DB05-SFZ','FB04-XMFB','DB05-XMDB')
//       """.stripMargin
//    logger.error(">>>cms755_sql:" + cms755_sql)
//    val cmsOther_sql =
//      s"""
//         |SELECT DISTINCT
//         |	zno_code,depart_code,type_code
//         |FROM
//         |	st_sss_zno_depart
//         |WHERE
//         |	 city_code != '755' and type_code IN ('FB04-YWX','DB05-DB','DB05-DLD', 'DB05-SFZ','FB04-XMFB','DB05-XMDB','DB05-YYZ','ZZC05-SJ','FB04-YWX','DB05-DB','DB05-DLD',	'DB05-SFZ','FB04-XMFB','DB05-XMDB')
//       """.stripMargin
//    logger.error(">>>cmsOther_sql:" + cmsOther_sql)
//
//    val cmsLists755: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, cms755_sql, Array("zno_code", "depart_code", "type_code"))
//    val cmsListsOther: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, cmsOther_sql, Array("zno_code", "depart_code", "type_code"))
//    val cmsLists = cmsLists755 ++= cmsListsOther
//
//    logger.error(">>>sch_sql:" + "select sch_code from st_sch where zno_code ='%s' AND (`status`=1 or `status`=3)")
//
//    //    cmsList.foreach(o=>{print(o.mkString(","))})
//    var cmsMap = Map[String, String]()
//    cmsLists.foreach(row => {
//      try {
//        if (row != null) {
//          val zno_code = row(0)
//          val depart_code = row(1)
//          val type_code = row(2)
//          if (zno_code != null && depart_code != null && type_code != null) {
//            //            if (type_code.equals("FB04-XMFB") || type_code.equals("DB05-XMDB")) {
//            //            if (!type_code.equals("DB05-SFZ")) {
//            //              //该网点的单元区域是否为空,去掉这两种类型单元区域为空的数据
//            //              val selectTcSql = String.format("select sch_code from st_sch where zno_code ='%s' AND (`status`=1 or `status`=3)", zno_code)
//            //              val resultSet = conn.createStatement().executeQuery(selectTcSql)
//            //              //调用first判断是否有返回值,移动了光标,因此不需要next(),即可取值,否则查询时先执行while(resultSet.next()).
//            //              if (resultSet.first()) {
//            //                //说明该网点下面有单元区域，可以用该网点和站点映射
//            //                cmsMap += (zno_code -> depart_code)
//            //              }
//            //            } else {
//            cmsMap += (zno_code -> depart_code)
//            //            }
//          }
//        }
//      } catch {
//        case e: Exception => logger.error(">>>去除没有单元区域的网点和站点的映射异常：" + e)
//      }
//    })
//    cmsMap
//  }
//
//  //
//  //  /**
//  //    *
//  //    * @return
//  //    */
//  //  def getCmsData1: Map[String, String] = {
//  //    val conn = getCmsConn
//  //    val cms_sql =
//  //      s"""
//  //         |SELECT DISTINCT
//  //         |	zno_code,depart_code,type_code
//  //         |FROM
//  //         |	st_zno_depart
//  //         |WHERE
//  //         |	 type_code IN ('FB04-YWX','DB05-DB','DB05-DLD',	'DB05-SFZ','FB04-XMFB','DB05-XMDB')
//  //       """.stripMargin
//  //
//  //    logger.error(">>>cms_sql:" + cms_sql)
//  //    logger.error(">>>sch_sql:" + "select sch_code from st_sch where zno_code ='%s' AND `status`=1")
//  //    val cmsLists: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, cms_sql, Array("zno_code", "depart_code", "type_code"))
//  //    //    cmsList.foreach(o=>{print(o.mkString(","))})
//  //    var cmsMap = Map[String, String]()
//  //    cmsLists.foreach(row => {
//  //      try {
//  //        if (row != null) {
//  //          val zno_code = row(0)
//  //          val depart_code = row(1)
//  //          val type_code = row(2)
//  //          if (zno_code != null && depart_code != null && type_code != null) {
//  //            if (type_code.equals("FB04-XMFB") || type_code.equals("DB05-XMDB")) {
//  //              //该网点的单元区域是否为空,去掉这两种类型单元区域为空的数据
//  //              val selectTcSql = String.format("select sch_code from st_sch where zno_code ='%s' AND `status`=1", zno_code)
//  //              val resultSet = conn.createStatement().executeQuery(selectTcSql)
//  //              //调用first判断是否有返回值,移动了光标,因此不需要next(),即可取值,否则查询时先执行while(resultSet.next()).
//  //              if (resultSet.first()) {
//  //                cmsLists -= row
//  //              }
//  //            } else {
//  //              cmsMap += (zno_code -> depart_code)
//  //            }
//  //
//  //          }
//  //        }
//  //      } catch {
//  //        case e: Exception => logger.error(">>>去除没有单元区域的网点和站点的映射异常：" + e)
//  //      }
//  //    })
//  //
//  //    cmsMap
//  //  }
//
//
//  /**
//   * 把配置资源中的数据加载到内存中来
//   *
//   * @return
//   */
//  def getXiaogeOutList11: ArrayBuffer[String] = {
//    val list = new ArrayBuffer[String]
//    val path = System.getProperty("user.dir") + "/xiaogeno_out.csv"
//    val buff = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"))
//    var line: String = null
//    var flag = true
//    println("小哥剔除:")
//    while (flag) {
//      line = buff.readLine()
//      if (line == null) {
//        flag = false
//      } else {
//        val arr = line.split(",")
//        if (arr.nonEmpty) {
//          var xiaogeNo = arr(0)
//          try {
//            xiaogeNo = Integer.parseInt(xiaogeNo).toString
//          } catch {
//            case e: Exception => logger.error(">>>转换员工工号异常：" + e + ",xiaogeNo:" + xiaogeNo)
//          }
//
//          list += xiaogeNo
//          print(xiaogeNo + ",")
//        }
//      }
//
//    }
//    buff.close()
//    println("")
//    list
//  }
//
//  /**
//   * 通过数据库获取月结账号
//   *
//   * @return
//   */
//  def getAccountOutListByDb: ArrayBuffer[String] = {
//    val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
//    val accountOut_sql =
//      s"""
//         |SELECT concat(CITY_CODE,'\\,', ACCOUNT_CODE,'\\,', PU_ZC,'\\,',DLV_ZC) account_info
//         |FROM
//         |	ACCU_CONFIG
//       """.stripMargin
//    logger.error(">>>cmsOther_sql:" + accountOut_sql)
//
//    val accountOut: ArrayBuffer[String] = DbUtils.selectColumn(conn, accountOut_sql, Array("account_info"))
//    accountOut
//  }
//
//  /**
//   * 把配置资源中的数据加载到内存中来
//   *
//   * @return
//   */
//  def getAccountOutList: ArrayBuffer[String] = {
//    val list = new ArrayBuffer[String]
//    val xiaogePath = System.getProperty("user.dir") + "/account_out.csv"
//    val csvReader = new CsvReader(xiaogePath)
//    if (csvReader.readRecord()) println("headers:" + csvReader.getValues.mkString(","))
//    while (csvReader.readRecord()) {
//      val row = csvReader.getValues
//      val citycode = row(0)
//      val accountantcode = row(1)
//      val source_zone_code = row(2)
//      val deptcode = row(3)
//      try {
//        //xiaogeNo = java.lang.Long.parseLong(xiaogeNo).toString
//        val accountInfp = citycode + "," + accountantcode + "," + source_zone_code + "," + deptcode
//        list += accountInfp
//      } catch {
//        case e: Exception => println(">>>员工号转换异常：" + e + "," + accountantcode)
//      }
//    }
//    list
//  }
//
//  /**
//   * 把配置资源中的数据加载到内存中来
//   *
//   * @return
//   */
//  def getXiaogeOutList: ArrayBuffer[String] = {
//    val list = new ArrayBuffer[String]
//    val xiaogePath = System.getProperty("user.dir") + "/xiaogeno_out.csv"
//    val csvReader = new CsvReader(xiaogePath)
//    if (csvReader.readRecord()) println("headers:" + csvReader.getValues.mkString(","))
//    while (csvReader.readRecord()) {
//      val row = csvReader.getValues
//      var xiaogeNo = row(0)
//      try {
//        //xiaogeNo = java.lang.Long.parseLong(xiaogeNo).toString
//        list += xiaogeNo
//      } catch {
//        case e: Exception => println(">>>员工号转换异常：" + e + "," + xiaogeNo)
//      }
//    }
//    list
//  }
//
//  /**
//   * 把配置资源中的数据加载到内存中来
//   *
//   * @return
//   */
//  def getFinalDeptOutList: ArrayBuffer[String] = {
//    val list = new ArrayBuffer[String]
//    val xiaogePath = System.getProperty("user.dir") + "/final_dept_out.csv"
//    val csvReader = new CsvReader(xiaogePath)
//    if (csvReader.readRecord()) println("headers:" + csvReader.getValues.mkString(","))
//    println("特殊网点剔除:")
//    while (csvReader.readRecord()) {
//      val row = csvReader.getValues
//      var xiaogeNo = row(0)
//      try {
//        //xiaogeNo = java.lang.Long.parseLong(xiaogeNo).toString
//        list += xiaogeNo
//        print(xiaogeNo + ",")
//      } catch {
//        case e: Exception => println(">>>员工号转换异常：" + e + "," + xiaogeNo)
//      }
//    }
//    println("")
//    list
//  }
//
//
//  /**
//   * 获取oms派件的数据
//   *
//   * @param startDate
//   * @param endDate
//   * @param spark
//   * @param zno2DeptMap
//   * @return
//   */
//  def getOmsLogRdd(startDate: String, endDate: String, spark: SparkSession, sc: SparkContext,
//                   zno2DeptMap: Map[String, String], runFlag: String): RDD[(String, JSONObject)] = {
//    //公司名为baison的为测试单
//    var selectOmsSql =
//      s"""
//         |select * from
//         |	(select inc_day,req_waybillno,req_destcitycode,req_time,req_addresseeaddr,gis_to_sys_time,gis_to_sys_src,
//         |   gis_to_sys_gisdeptcodeto,gis_to_sys_sssdeptcodeto,gis_to_sys_depttoretby,gis_to_sys_gisteamcodeto,
//         |   arss_dept_re_identrs,arss_dept_req_address,gis_to_sys_groupid,standardization,req_addresseemobile,
//         |   req_addresseephone,city,adcode,splitresult,splittype,groupids,filters,keywords,matchids,adcodes,inc_day,
//         |   chkDeptSrc,precision,req_comp_name,req_province,req_city,req_area,
//         |   row_number() over(partition BY req_waybillno order by req_time desc ) as rank
//         |   from dm_gis.gis_rds_omsto
//         | where inc_day between '$startDate' and '$endDate'  and req_waybillno <> '' and req_comp_name <> 'baison' )a where a.rank=1
//      """.stripMargin
//    if (runFlag.equals("singleRunDay")) {
//      selectOmsSql = selectOmsSql + s" and inc_day='${startDate}' "
//    }
//
//    println("selectOmsSql:" + selectOmsSql)
//    val omsRdd = spark.sql(selectOmsSql)
//      .repartition(2000)
//      .rdd
//      .map(row => {
//        val oms_body = new JSONObject()
//        val nameArr = Array("req_date", "waybillno", "city_code", "req_time", "req_addresss", "gis_time", "lib_src",
//          "gis_dept", "sss_dept", "sys_src", "gis_tc", "arss_dept", "arss_req_address",
//          "gis_to_sys_groupid", "standardization", "req_addresseemobile", "req_addresseephone", "city", "adcode", "splitresult",
//          "splittype", "groupids", "filters", "keywords", "matchids", "adcodes", "inc_day", "chkDeptSrc", "precision",
//          "req_comp_name", "req_province", "req_city", "req_area")
//        for (i <- nameArr.indices) oms_body.put(nameArr(i), row.getString(i))
//        oms_body
//      }).map(oms_body => {
//      val gis_dept = oms_body.getString(gis_dept_name)
//      val sss_dept = oms_body.getString(sss_dept_name)
//      val arss_dept = oms_body.getString(arss_dept_name)
//      val sys_src = oms_body.getString("sys_src")
//      val waybillno = oms_body.getString("waybillno")
//
//      //计算最终网点
//      val isGisDeptMatch = gis_dept != null && gis_dept.matches("^[0-9]+[a-zA-Z]+[0-9]*$")
//      val isSssDeptMatch = sss_dept != null && sss_dept.matches("^[0-9]+[a-zA-Z]+[0-9]*$")
//      val isArssDeptMatch = arss_dept != null && arss_dept.matches("^[0-9]+[a-zA-Z]+[0-9]*$")
//
//      oms_body.put("isGisDeptMatch", isGisDeptMatch)
//      oms_body.put("isSssDeptMatch", isSssDeptMatch)
//      oms_body.put("isArssDeptMatch", isArssDeptMatch)
//      var gis_sss_dept: String = null
//      var final_dept: String = null
//      var final_dept_map: String = null
//      var final_dept_src: String = null
//      var gis_dept_map: String = null
//      var sss_dept_map: String = null
//      var arss_dept_map: String = null
//      var gis_sss_dept_map: String = null
//      if (isArssDeptMatch) {
//        final_dept = arss_dept
//        final_dept_src = "arss" //最终网点来源于审补
//      } //审补有效用审补
//      if (sys_src != null) {
//        //计算gis_sss网点
//        if (sys_src.equals("gis_sss") && isSssDeptMatch) {
//          gis_sss_dept = sss_dept
//        }
//        if (sys_src.equals("gis") && isGisDeptMatch) {
//          gis_sss_dept = gis_dept
//        }
//        //计算最终网点
//        if (!isArssDeptMatch) {
//          //审补无效的时候看gis和sss系统
//          if (sys_src.equals("gis_sss") && isSssDeptMatch) {
//            final_dept = sss_dept
//            final_dept_src = "sss" //最终网点来源于sss
//          }
//          if (sys_src.equals("gis") && isGisDeptMatch) {
//            final_dept = gis_dept
//            final_dept_src = "gis" //最终网点来源于gis
//          }
//        }
//      }
//
//      val isGisSssDeptMatch = gis_sss_dept != null && gis_sss_dept.matches("^[0-9]+[a-zA-Z]+[0-9]*$")
//      val isFinalDeptMatch = final_dept != null && final_dept.matches("^[0-9]+[a-zA-Z]+[0-9]*$")
//      oms_body.put("isGisSssDeptMatch", isGisSssDeptMatch)
//      oms_body.put("isFinalDeptMatch", isFinalDeptMatch)
//
//      if (isGisDeptMatch && zno2DeptMap.contains(gis_dept)) {
//        gis_dept_map = zno2DeptMap.apply(gis_dept)
//      }
//
//      if (isSssDeptMatch && zno2DeptMap.contains(sss_dept)) {
//        sss_dept_map = zno2DeptMap.apply(sss_dept)
//      }
//
//      if (isGisSssDeptMatch && zno2DeptMap.contains(gis_sss_dept)) {
//        gis_sss_dept_map = zno2DeptMap.apply(gis_sss_dept)
//      }
//
//      if (isArssDeptMatch && zno2DeptMap.contains(arss_dept)) {
//        arss_dept_map = zno2DeptMap.apply(arss_dept)
//      }
//
//      if (isFinalDeptMatch && zno2DeptMap.contains(final_dept)) {
//        final_dept_map = zno2DeptMap.apply(final_dept)
//      }
//
//      //比较gis网点和sss网点是否一致（先使用映射，映射不存在使用网点本身）
//      var isGisSssDiff = ""
//      if (gis_dept_map != null && sss_dept_map != null) {
//        //映射网点都存在
//        if (gis_dept_map.equals(sss_dept_map)) {
//          isGisSssDiff = "same" //gis sss网点都存在且相同
//        } else {
//          isGisSssDiff = "diff" //gis sss网点都存在且不同
//        }
//      } else {
//        //有映射网点不存在
//        if (isGisDeptMatch && isSssDeptMatch) {
//          if (!gis_dept.equals(sss_dept)) isGisSssDiff = "diff" //gis sss网点都存在且不同
//          if (gis_dept.equals(sss_dept)) isGisSssDiff = "same" //gis sss网点都存在且相同
//        }
//      }
//      oms_body.put("isGisSssDiff", isGisSssDiff)
//
//      oms_body.put(gis_dept_map_name, gis_dept_map)
//      oms_body.put(sss_dept_map_name, sss_dept_map)
//      oms_body.put(gis_sss_dept_name, gis_sss_dept)
//      oms_body.put(gis_sss_dept_map_name, gis_sss_dept_map)
//      oms_body.put(arss_dept_map_name, arss_dept_map)
//      oms_body.put(final_dept_name, final_dept)
//      oms_body.put(final_dept_map_name, final_dept_map)
//      oms_body.put("final_dept_src", final_dept_src)
//
//      val result = new JSONObject()
//      result.put("oms_body", oms_body)
//      (waybillno, result)
//    }).filter(_._1 != null).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>运单数量:" + endDate + "-" + omsRdd.filter(obj => obj.getJSONObject("oms_body").getString("req_date").equals(endDate)).count())
//    //    omsRdd.take(5).foreach(o=>println(o))
//    logger.error(">>>标准化大区和城市代码...")
//    val standardLogRdd = WdIndexStat.getStandardLogRdd(omsRdd, sc, comUtil).map(obj => {
//      val waybillno = obj.getJSONObject("oms_body").getString("waybillno")
//      val cityCode = obj.getJSONObject("oms_body").getString("city_code")
//      (String.format("%s_%s", waybillno, cityCode), obj)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("标准化后数量:" + standardLogRdd.count())
//    omsRdd.unpersist()
//    Spark.clearPersistWithoutId(spark, standardLogRdd.id)
//    standardLogRdd
//  }
//
//  /**
//   * 计算最终指标
//   *
//   * @param gis_dept
//   * @param sss_dept
//   * @param arss_dept
//   * @return
//   */
//  def getFinalDept(gis_dept: String, sss_dept: String, arss_dept: String, city_code: String): String = {
//    var finalDept: String = null
//    var isGisDeptMatch = false
//    var isSssDeptMatch = false
//    var isArssDeptMatch = false
//    if (gis_dept != null && gis_dept.matches("^[0-9]+[a-zA-Z]+")) isGisDeptMatch = true //gis网点有效
//    if (sss_dept != null && sss_dept.matches("^[0-9]+[a-zA-Z]+")) isSssDeptMatch = true //sss网点有效
//    if (arss_dept != null && arss_dept.matches("^[0-9]+[a-zA-Z]+")) isArssDeptMatch = true //arss网点有效
//    if (isGisDeptMatch && !isSssDeptMatch) finalDept = gis_dept //gis有效，sss无效，final_dept取gis的
//    if (!isGisDeptMatch && isSssDeptMatch) finalDept = sss_dept //gis无效，sss有效，final_dept取sss的
//    if (!isGisDeptMatch && !isSssDeptMatch && isArssDeptMatch) finalDept = arss_dept //gis和sss都无效，看审补(审补有效取审补，审补无效已忽略)
//    if (isGisDeptMatch && isSssDeptMatch) {
//      //gis有效，sss有效
//      val isGisSssDeptSame = gis_dept.equals(sss_dept)
//      if (isGisSssDeptSame) {
//        //gis sss网点一致，优先取sss（755有限gis）
//        if (!city_code.equals("755")) {
//          finalDept = sss_dept
//        } else {
//          finalDept = gis_dept
//        }
//      } else {
//        //gis sss网点不一致，看审补
//        if (isArssDeptMatch) {
//          //审补有效取审补
//          finalDept = arss_dept
//        } else {
//          //审补无效，有限取sss（755取gis）
//          if (!city_code.equals("755")) {
//            finalDept = sss_dept
//          } else {
//            finalDept = gis_dept
//          }
//        }
//      }
//    }
//    finalDept
//  }
//
//  /**
//   * 获取妥投去掉转寄的数据
//   *
//   * @param startDate
//   * @param endDate
//   * @param spark
//   * @return
//   */
//  def getDlvRdd(startDate: String, endDate: String, spark: SparkSession): RDD[(String, JSONObject)] = {
//    val selectDlvSql =
//      s"""
//         |select * from
//         |	(select inc_day,mainwaybillno,zonecode,couriercode,extendattach5,
//         |	row_number() over (partition by mainwaybillno order by barscantm desc) as rank from ods_kafka_fvp.fvp_core_fact_route_op
//         |	where inc_day between '$startDate' and '$endDate' and opcode='80' and mainwaybillno <> '') b
//         |where b.rank=1
//         |and not exists
//         |			(select 1
//         |			from ods_kafka_fvp.fvp_core_fact_route_op c
//         |			where inc_day between '$startDate' and '$endDate'
//         |            and (opcode = '99'
//         |                or (opcode = '33'  and staywhycode in ('14', '55', '9', '67'))
//         |                or (opcode = '70' and staywhycode in ('14', '55', '9', '67'))
//         |                or (opcode = '77' and staywhycode in ('14', '55', '103'))
//         |                or opcode = '648')
//         |			and b.mainwaybillno=c.mainwaybillno)
//       """.stripMargin
//    println("selectDlvSql:" + selectDlvSql)
//    val dlvRdd = spark.sql(selectDlvSql)
//      .rdd
//      .repartition(2000)
//      .map(row => {
//        val dlv_body = new JSONObject()
//        val waybillno = row.getString(1)
//        val dlv_dept = row.getString(2)
//        val citycode = dlv_dept.replaceAll("(\\d*).*", "$1")
//        dlv_body.put("dlv_date", row.getString(0))
//        dlv_body.put("waybillno", waybillno)
//        dlv_body.put("dlv_dept", dlv_dept)
//        dlv_body.put("courier_code", row.getString(3))
//        dlv_body.put("extendattach5", row.getString(4))
//        val result = new JSONObject()
//        result.put("dlv_body", dlv_body)
//        (String.format("%s_%s", waybillno, citycode), result)
//      })
//    dlvRdd
//  }
//
//
//  /**
//   * 把枪通过经纬度访问网点的http接口
//   *
//   * @param json
//   * @param zno2DeptMap
//   * @return
//   */
//  def getBarDept(json: JSONObject, zno2DeptMap: Map[String, String]): (String, JSONObject) = {
//    var bar_dept: String = null
//    var bar_dept_map: String = null
//    try {
//      val bar_body = json.getJSONObject("bar_body")
//      //      val bar_scan_lng = bar_body.getString("bar_scan_lng")
//      val x = bar_body.getString("bar_scan_lng")
//      val y = bar_body.getString("bar_scan_lat")
//      val bar_url = comUtil.getValue("bar_url")
//      val url = String.format(bar_url, x, y)
//      val httpData = HttpClientUtil.getJsonByGet(url)
//      val status = httpData.getString("status")
//      if (status != null && status.equals("0")) {
//        val data = httpData.getJSONObject("result").getJSONArray("data")
//        if (data.size() == 1) {
//          val firstData = data.getJSONObject(0)
//          bar_dept = firstData.getString("zno_code")
//          if (bar_dept != null && zno2DeptMap.contains(bar_dept)) {
//            bar_dept_map = zno2DeptMap.apply(bar_dept)
//            bar_body.put("bar_dept", bar_dept)
//            bar_body.put("bar_dept_map", bar_dept_map)
//            bar_body.put("http_data", httpData)
//          }
//        }
//      }
//    } catch {
//      case e: Exception => logger.error(">>>获取把枪网点异常:" + e + "," + json)
//    }
//    (bar_dept_map, json)
//  }
//
//  def getBarDeptPost(json: JSONObject, zno2DeptMap: Map[String, String]): (String, JSONObject) = {
//    var bar_dept: String = null
//    var bar_dept_map: String = null
//    try {
//      val bar_body = json.getJSONObject("bar_body")
//      //      val bar_scan_lng = bar_body.getString("bar_scan_lng")
//      val x = bar_body.getString("bar_scan_lng")
//      val y = bar_body.getString("bar_scan_lat")
//      val bar_url = comUtil.getValue("bar_url")
//      val bar_url_ak = comUtil.getValue("bar_url_ak")
//      //      val url = String.format(bar_url, x, y)
//      val parm = new JSONObject()
//      parm.put("ak", bar_url_ak)
//      val xyArray = new JSONArray()
//      val xyObj = new JSONObject()
//      xyObj.put("lng", x)
//      xyObj.put("lat", y)
//      xyArray.add(xyObj)
//      parm.put("coords", xyArray)
//      val httpData = HttpConnection.sendPost(bar_url, parm.toJSONString)
//      logger.error("httpData;" + httpData)
//      if (httpData != null && httpData.containsKey("content") && httpData.get("content") != null) {
//        val content = httpData.get("content").toString
//        val json = JSON.parseObject(content)
//        val status = json.getInteger("status")
//
//        if (status != null && status == 0) {
//          val result = json.getJSONObject("result")
//          if (result != null) {
//            val data = result.getJSONObject("data")
//            val aois = data.getJSONArray("aois")
//            if (aois != null && aois.size() != 0) {
//              val aoiData = aois.getJSONObject(0)
//              bar_dept = aoiData.getString("zc")
//              if (bar_dept != null) {
//                if (zno2DeptMap.contains(bar_dept)) {
//                  bar_dept_map = zno2DeptMap.apply(bar_dept)
//                  bar_body.put("bar_dept_map", bar_dept_map)
//                }
//                bar_body.put("bar_dept", bar_dept)
//                bar_body.put("http_data", httpData)
//              }
//            }
//          }
//        }
//      }
//    } catch {
//      case e: Exception => logger.error(">>>获取把枪网点异常:" + e + "," + json)
//    }
//    (bar_dept_map, json)
//  }
//
//  /**
//   * 读取配置文件中的晚点站点映射数据
//   *
//   * @return
//   */
//  def getZnoDeptMap: Map[String, String] = {
//    var znoDeptMap = Map[String, String]()
//    val path = System.getProperty("user.dir") + "/zno_depart.csv"
//    val buff = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"))
//    var line: String = null
//    var flag = true
//    println("映射配置表:")
//    while (flag) {
//      line = buff.readLine()
//      if (line == null) {
//        flag = false
//      } else {
//        val arr = line.split(",")
//        if (arr.nonEmpty) {
//          val zno_code = arr(0)
//          val depart_code = arr(1)
//          znoDeptMap += (zno_code -> depart_code)
//          print(zno_code + "->" + depart_code + ",")
//          //          list += xiaogeNo
//        }
//      }
//
//    }
//    buff.close()
//    println("--结束")
//    znoDeptMap
//  }
//
//
//  /**
//   * 配置spark的conf
//   *
//   * @param appName
//   * @return
//   */
//  def getSparkConf(appName: String): SparkConf = {
//    val conf = new SparkConf().setAppName(appName)
//    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
//    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
//    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
//    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
//    conf.set("quota.consumer.default", (10485760 * 2).toString)
//    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
//    conf.set("spark.yarn.executor.memoryOverhead", "4096")
//    conf.set("spark.scheduler.maxRegisteredResourcesWaitingTime", "180000")
//    conf.set("hive.exec.dynamic.partition", "true")
//    conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
//    //    conf.set("spark.executor.instances","20")
//    //    conf.set("spark.executor.memory","20g")bar
//    conf.set("spark.sql.result.partition.ratio", "1")
//    //    conf.set("spark.executor.instances", "45")
//    //    conf.set("spark.executor.memory", "40g")
//    //    conf.set("spark.yarn.executor.memoryOverhead","10g")
//    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
//
//    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
//
//    //    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
//    //    conf.set("spark.kryo.registrationRequired", "true")
//    //    conf.registerKryoClasses(Array(
//    //      classOf[JSONObject],
//    //      classOf[FinalObj],
//    //      classOf[GisObj],
//    //      classOf[RecValidObj],
//    //      classOf[ZcRecValidObj],
//    //      classOf[ZcWdObj]
//    //    ))
//    conf
//  }


}
