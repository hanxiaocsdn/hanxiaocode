package com.sf.gis.scala.oms_pai

import java.io._
import java.text.SimpleDateFormat
import java.util
import java.util.Date

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import com.sf.gis.scala.utils.HttpClientUtil
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel

object SendReturnProMain {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val fileSepartor: String = System.getProperty("file.separator")
  val downloadUrl = "http://gis-int.int.sfdc.com.cn:1080/redirect/geometry"
  val updateUrl = "http://gis-int.int.sfdc.com.cn:1080/redirect/geometry/put?ak=93a3da65f39e41fe9c754c625911b7cc&geometryCode=%s&geometryType=%s&specialLevel=%s&x=%s&y=%s"
  val deleteUrl = "http://gis-int.int.sfdc.com.cn:1080/redirect/geometry/del?geometryCode=%s&specialLevel=%s&ak=93a3da65f39e41fe9c754c625911b7cc"

  def main(args: Array[String]): Unit = {
    start(args)
    //    test()
  }

  def start(args: Array[String]): Unit = {
    //    val spark = SparkUtil.getSparkSession(appName)
    val spark = getSparkSession(appName)
    spark.sparkContext.setLogLevel("ERROR")
    if (args.length == 0) {
      //未传参，代码内部获取日期参数，默认昨天
      val date = DateUtil.getYesterday
      handleTask(spark, date)
    } else if (args.length == 1) {
      //传入参数，单天任务
      val date = args(0)
      handleTask(spark, date)
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      val startDate = args(0)
      val endDate = args(1)
      batchTask(spark, startDate, endDate)
    }
    spark.stop()
  }


  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>批量处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      handleTask(spark, date)
    }
  }

  def handleTask(spark: SparkSession, date: String): Unit = {
    logger.error(">>>处理" + date + "号的任务------------------appName=" + appName + "------------------")
    val hievRdd = getHiveData(spark: SparkSession, date: String)
    logger.error(">>>查询到大数据平台的数据量：" + hievRdd.count())
    hievRdd.take(1).foreach(println)

    logger.error(">>>调用查询接口下载转寄退回数据")
    val downloadRdd = getDownloadRdd(spark)

    logger.error(">>>外关联，以hive中数据为基准作对比，执行新增、更新、删除操作...")
    val resultRdd = hievRdd.fullOuterJoin(downloadRdd).map(obj => {
      val hiveObj = obj._2._1
      val queryObj = obj._2._2
      var httpResult: JSONObject = null
      var resultJson: JSONObject = null
      try {
        if (hiveObj.nonEmpty) {
          //hive中数据不为空
          val hiveJson = hiveObj.get
          resultJson = hiveJson
          resultJson.put("source", "hive")
          val hiveX = hiveJson.getString("x")
          val hiveY = hiveJson.getString("y")
          val hiveGeometryType = hiveJson.getString("geometry_type")
          val geometry_code = hiveJson.getString("geometry_code")
          val special_level = hiveJson.getString("special_level")
          if (queryObj.nonEmpty) {
            //查询接口数据不为空，做数据比对，以hive数据为基准，不同的就更新
            val queryJson = queryObj.get
            val queryX = queryJson.getString("x")
            val queryY = queryJson.getString("y")
            val queryGeometryType = queryJson.getString("geometry_type")
            if (queryX != hiveX || queryY != queryY || queryGeometryType != hiveGeometryType) {
              //两个值比对，有一列不同就需要调用接口,把hive的数据更新进来
              val eachUpdateUrlPer = updateUrl.format(geometry_code, hiveGeometryType, special_level, hiveX, hiveY)
              httpResult = HttpClientUtil.getJsonByGet(eachUpdateUrlPer)
              resultJson.put("opt", "update")
            } else {
              resultJson.put("opt", "same")
            }
          } else {
            //查询接口数据为空,调新增接口
            val eachUpdateUrlPer = updateUrl.format(geometry_code, hiveGeometryType, special_level, hiveX, hiveY)
            httpResult = HttpClientUtil.getJsonByGet(eachUpdateUrlPer)
            resultJson.put("opt", "insert")
          }
        } else {
          //hive中数据为空
          if (queryObj.nonEmpty) {
            //查询接口有数据，调删除接口
            val queryJson = queryObj.get
            resultJson = queryJson
            queryJson.put("source", "interface")
            val geometryCode = queryJson.getString("geometry_code")
            val specialLevel = queryJson.getString("special_level")
            val eachDeleteUrl = deleteUrl.format(geometryCode, specialLevel)
            httpResult = HttpClientUtil.getJsonByGet(eachDeleteUrl)
            resultJson.put("opt", "delete")
          }
        }
        if (resultJson != null) {
          if (httpResult != null) {
            val status = httpResult.getInteger("status")
            resultJson.put("status", status)
            val result = httpResult.getJSONObject("result")
            if (result != null) {
              val editMsg = result.getString("msg")
              resultJson.put("message", editMsg)
            }
            resultJson.put("httpResult", httpResult)
          }
        }
      } catch {
        case e: Exception => logger.error(">>>异常：" + hiveObj, e); resultJson.put("message", e.getMessage)
      }
      resultJson
    }).filter(_ != null).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>full join后的数据量：" + resultRdd.count())
    resultRdd.take(1).foreach(println)
    logger.error(">>>保存处理后的数据明细")
    saveDataToHive(spark, resultRdd, date)
    logger.error(">>>处理结束!")
  }

  /**
   * 存储操作后的明细数据
   *
   * @param inputRdd
   * @param date
   */
  def saveDataToHive(spark: SparkSession, inputRdd: RDD[JSONObject], date: String): Unit = {
    try {
      val db = "dm_gis"
      spark.sql(s"use $db")
      val table = "send_return_result"
      logger.error(">>>table=" + db + "." + table)
      val structFileds = new util.ArrayList[StructField]()
      val fileds = Array("geometry_code", "geometry_type", "special_level", "x", "y", "date", "opt", "source", "status", "message")
      for (filed <- fileds) structFileds.add(DataTypes.createStructField(filed, DataTypes.StringType, true))
      val structType = DataTypes.createStructType(structFileds)
      val rowRdd = inputRdd.map(obj => {
        var row: Row = null
        try {
          val names = Array("geometry_code", "geometry_type", "special_level", "x", "y", "date", "opt", "source", "status", "message")
          val values = new Array[String](names.length)
          for (i <- names.indices) values(i) = JSONUtil.getJsonVal(obj, names(i), "")
          row = RowFactory.create(values(0), values(1), values(2), values(3), values(4), values(5), values(6), values(7), values(8), values(9))
        } catch {
          case e: Exception => logger.error(">>>构造row异常：" + e)
        }
        row
      })
      // 4 构建DataFrame
      val df: DataFrame = spark.createDataFrame(rowRdd, structType)
      //5 基于Datarame创建临时表
      val tempView = String.format("%s_temp_view", table)
      df.createOrReplaceTempView(tempView)
      val partitionSql = String.format(s"partition(inc_day='%s')", date)
      //6 分区、表等操作
      val deletePartitionSql = String.format(s"alter table %s drop if  exists $partitionSql", table)
      logger.error(">>>删除处理日期分区：" + deletePartitionSql)
      spark.sql(deletePartitionSql)

      val createPartitionSql = String.format(s"alter table %s add if not exists $partitionSql", table)
      logger.error(">>>新建分区：" + createPartitionSql)
      spark.sql(createPartitionSql)
      //7 把临时表的数据刷进hive表中
      spark.sql(String.format(s"insert into  %s $partitionSql select * from %s", table, tempView))
      logger.error(">>>明细数据入hive库结束!")
    } catch {
      case e: Exception => logger.error(">>>明细数据入hive异常：" + e)
    }

  }


  /**
   * 下载并处理低精审补数据
   *
   * @param spark
   * @return
   */
  def getDownloadRdd(spark: SparkSession): RDD[(String, JSONObject)] = {
    val date = DateUtil.getToday
    val currPath = System.getProperty("user.dir")
    val tempFilePath = currPath + "/sendReturnData_" + getTime + ".csv"
    logger.error("下载文件，保存临时文件路径tempFilePath:" + tempFilePath)
    var headers = downloadData(date: String, tempFilePath: String)

    logger.error(">>>处理下载到本地的csv文件，转换成rdd格式...")
    val rdd = handleFile(headers, tempFilePath, spark, date)
    logger.error(">>>删除掉本地csv文件")
    deleteLocalFile(tempFilePath)
    rdd
  }

  /**
   * 删除本地文件
   *
   * @param filePath
   */
  def deleteLocalFile(filePath: String): Unit = {
    val file = new File(filePath)
    if (file.isFile && file.exists()) file.delete()
  }

  /**
   * 获取当前系统到秒的时间
   *
   * @return
   */
  def getTime: String = {
    val longtTime = System.currentTimeMillis()
    val dfTime = new SimpleDateFormat("yyyyMMdd_HHmmssSSS")
    val time = dfTime.format(new Date(longtTime))
    time
  }

  /**
   * 下载审补的数据
   *
   * @param incDay
   * @param tempFilePath
   */
  def downloadData(incDay: String, tempFilePath: String): Array[String] = {
    val file = new File(tempFilePath)
    if (!file.exists()) file.createNewFile()
    val bw = new BufferedWriter(new FileWriter(file))
    var headers: Array[String] = null
    val url = String.format(downloadUrl)
    val is = HttpClientUtil.getStreamByGet(url)
    val buf = new BufferedReader(new InputStreamReader(is, "utf-8"))
    var flag = true
    var line: String = null
    val headLine = buf.readLine()
    headers = headLine.split(",")
    println("headers:" + headers.mkString(","))
    while (flag) {
      line = buf.readLine()
      if (line != null) {
        bw.write(line + "\r\n")
      } else {
        flag = false
      }
    }
    headers
  }

  /**
   * 处理下载的低精审补数据
   *
   * @param headers
   * @param tempFilePath
   * @param spark
   * @param date
   * @return
   */
  def handleFile(headers: Array[String], tempFilePath: String, spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    spark.sql(String.format(s"alter table dm_gis.send_return_data drop if exists partition (inc_day = '%s')", date))
    spark.sql(String.format(s"alter table dm_gis.send_return_data add if not exists partition (inc_day = '%s')", date))
    val hdfsTablePath = "hdfs://sfbdp1/user/hive/warehouse/dm_gis.db/send_return_data/inc_day=" + date
    val command = "hdfs dfs -put " + tempFilePath + " " + hdfsTablePath
    logger.error(">>>command:" + command)
    val process = Runtime.getRuntime.exec(command)
    val result = process.waitFor()
    if (result != 0) logger.error(">>>执行shell命令失败，result=" + result)
    val inputRdd = spark.sparkContext.textFile(hdfsTablePath)
    println("headers:" + headers.mkString(","))
    val outputRdd = inputRdd.repartition(20).map(line => {
      var json: JSONObject = null
      try {
        json = new JSONObject()
        val row = line.split(",")
        for (i <- 0 until row.length) json.put(headers(i), row(i))
        json.put("date", date)
        json.put("geometry_code", json.getString("geometryCode"))
        json.put("special_level", json.getString("specialLevel"))
        json.put("geometry_type", json.getString("geometryType"))
      } catch {
        case e: Exception => logger.error(">>>处理数据异常：" + e + ",异常数据:" + line)
      }
      val key = Array(json.getString("geometry_code"), json.getString("special_level")).mkString("_")
      (key, json)
    }).filter(obj => {
      val json = obj._2
      val geometryType = json.getString("geometry_type")
      val specialLevel = json.getString("special_level")
      obj._1 != null && geometryType == "1" && List("4", "5", "8").contains(specialLevel)
    }).reduceByKey((o1, o2) => o1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>下载一天的数据量为：" + outputRdd.count())
    outputRdd.take(1).foreach(println)
    outputRdd
  }

  /**
   * 获取大数据平台的转寄退回数据
   *
   * @param spark
   * @param date
   * @return
   */
  def getHiveData(spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    val sql =
      s"""
         |select geometry_code,geometry_type,special_level,x,y,inc_day date
         |from ods_sfmap.vw_map_spatial_all
         |where inc_day=$date and geometry_type = '1' and special_level in ('4','5', '8')
       """.stripMargin
    var json: JSONObject = null
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val rdd = df.rdd.map(row => {
      json = new JSONObject()
      for (i <- fields.indices) json.put(fields(i).name, row.getString(i) + "")
      val key = Array(json.getString("geometry_code"), json.getString("special_level")).mkString("_")
      (key, json)
    }).reduceByKey((o1, o2) => o1).repartition(40).persist(StorageLevel.MEMORY_AND_DISK_SER)
    rdd
  }

  /**
   * 获取spark程序入口
   *
   * @param appName
   * @return
   */
  def getSparkSession(appName: String): SparkSession = {
    val spark = SparkSession.builder().config(getSparkConf(appName, "60000")).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("error")
    spark
  }

  /**
   * 配置spark的conf
   *
   * @param appName
   * @return
   */
  def getSparkConf(appName: String, timeOut: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", timeOut)
    conf
  }

}
