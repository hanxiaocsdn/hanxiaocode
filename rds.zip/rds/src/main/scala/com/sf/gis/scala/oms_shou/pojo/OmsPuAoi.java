package com.sf.gis.scala.oms_shou.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/6.
 */
@Entity
public class OmsPuAoi implements Serializable {
    @Column(name = "ID")
    private String id;
    @Column(name = "UNDER_CALL")
    private String underCall;
    @Column(name = "STAT_DATE")
    private String statDate;    //数据日期
    @Column(name = "PROVINCE")
    private String province;    //省
    @Column(name = "REGION")
    private String region;  //大区
    @Column(name = "CITY_CODE")
    private String cityCode;    //城市代码
    @Column(name = "CITY")
    private String city;    //城市
    @Column(name = "ZONE_CODE")
    private String zoneCode;    //网点
    @Column(name = "ORDER")
    private int order; //下单量
    @Column(name = "AOI")
    private int aoi;
    @Column(name = "AOI_AUTO")
    private int aoiAuto;
    @Column(name = "AOI_GIS")
    private int aoiGis;
    @Column(name = "AOI_GIS_NORM")
    private int aoiNorm;   //GIS自动识别量中来自NORM的识别量
    @Column(name = "AOI_GIS_DPNORM")
    private int aoiDispatchNorm;   //GIS自动识别量中来自DISPATCH_NORM的识别量
    @Column(name = "AOI_GIS_SCH")
    private int aoiSch;   //GIS自动识别量中来自SCH的识别量
    @Column(name = "AOI_GIS_TC2")
    private int aoiTc2; //GIS自动识别量中来自TC2的识别量
    @Column(name = "AOI_GIS_DPTC2")
    private int aoiDispatchTc2;   //GIS自动识别量中来自DISPATCH_TC2的识别量
    @Column(name = "AOI_GIS_CHKE")
    private int aoiChke; //GIS自动识别量中来自CHKE的识别量
    @Column(name = "AOI_GIS_DPCHKE")
    private int aoiDispatchChke;   //GIS自动识别量中来自DISPATCH_CHKE的识别量
    @Column(name = "AOI_GIS_CHKN")
    private int aoiChkn;  //GIS自动识别量中来自CHKN的识别量
    @Column(name = "AOI_GIS_PHONE")
    private int aoiPhone;  //GIS自动识别量中来自Phone的识别量
    @Column(name = "AOI_GIS_DPCHKN")
    private int aoiDispatchChkn;   //GIS自动识别量中来自DISPATCH_CHKN的识别量
    @Column(name = "AOI_GIS_DPROAD")
    private int aoiDispatchRoad;   //GIS自动识别量中来自DISPATCH_ROAD的识别量
    @Column(name = "AOI_GIS_DPPHONE")
    private int aoiDispatchPhone;   //GIS自动识别量中来自DISPATCH_PHONE的识别量
    @Column(name = "AOI_GIS_OTHER")
    private int aoiOther;
    @Column(name = "AOI_KS")
    private int aoiKs;
    @Column(name = "AOI_MONTH_ACC")
    private int aoiMonthAcc;
    @Column(name = "AOI_ARSS_RE")
    private int aoiArssRe; //人工审补识别量
    @Column(name = "AOI_ARSS_REQ")
    private int aoiArssReq; //人工审补识别量
    @Column(name = "FC_AOI")
    private int aoiFc;
    @Column(name = "FC_AOI_GIS")
    private int aoiGisFc;
    @Column(name = "FC_AOI_NORM")
    private int aoiNormFc;   //GIS自动识别量中来自NORM的识别量
    @Column(name = "FC_AOI_DPNORM")
    private int aoiDispatchNormFc;   //GIS自动识别量中来自DISPATCH_NORM的识别量
    @Column(name = "FC_AOI_SCH")
    private int aoiSchFc;   //GIS自动识别量中来自SCH的识别量
    @Column(name = "FC_AOI_TC2")
    private int aoiTc2Fc; //GIS自动识别量中来自TC2的识别量
    @Column(name = "FC_AOI_DPTC2")
    private int aoiDispatchTc2Fc;   //GIS自动识别量中来自DISPATCH_TC2的识别量
    @Column(name = "FC_AOI_CHKE")
    private int aoiChkeFc; //GIS自动识别量中来自CHKE的识别量
    @Column(name = "FC_AOI_DPCHKE")
    private int aoiDispatchChkeFc;   //GIS自动识别量中来自DISPATCH_CHKE的识别量
    @Column(name = "FC_AOI_CHKN")
    private int aoiChknFc;  //GIS自动识别量中来自CHKN的识别量
    @Column(name = "FC_AOI_PHONE")
    private int aoiPhoneFc;  //GIS自动识别量中来自Phone的识别量
    @Column(name = "FC_AOI_DPCHKN")
    private int aoiDispatchChknFc;   //GIS自动识别量中来自DISPATCH_CHKN的识别量
    @Column(name = "FC_AOI_DPROAD")
    private int aoiDispatchRoadFc;   //GIS自动识别量中来自DISPATCH_ROAD的识别量
    @Column(name = "FC_AOI_DPPHONE")
    private int aoiDispatchPhoneFc;   //GIS自动识别量中来自DISPATCH_PHONE的识别量
    @Column(name = "FC_AOI_OTHER")
    private int aoiOtherFc;
    @Column(name = "FC_AOI_MONTH_ACC")
    private int aoiMonthAccFc;
    @Column(name = "FC_AOI_KS")
    private int aoiKsFc;
    @Column(name = "FC_AOI_ARSS")
    private int aoiArssFc; //人工审补识别量
    @Column(name = "SYSSOURCE")
    private String sysSource;
    private int addressBuilding;//楼栋
    private int bidCollectCnt;
    private int bidCollectRejectCnt;
    private int bidCfCnt;
    private int bidSysCnt;
    private int bidSysOk;
    private int bidAoiidDiff;
    private int bidCfNorm;
    private int bidCfNormMultiGid;
    private int bidCfComapny;
    private int bidCfPhone;
    private int bidCfDsPoi;
    private int bidCfMinPoi;
    private int bidCfAoiMapping;
    private int bidCfOther;

    public void updateBidSta(int bidCollectCnt,int bidCollectRejectCnt,int bidCfCnt,int bidSysCnt,int bidSysOk,int bidAoiidDiff,
                      int bidCfNorm,int bidCfNormMultiGid,int bidCfComapny,int bidCfPhone,int bidCfDsPoi,int bidCfMinPoi,
                      int bidCfAoiMapping,int bidCfOther){
        this.bidCollectCnt=bidCollectCnt;
        this.bidCollectRejectCnt=bidCollectRejectCnt;
        this.bidCfCnt=bidCfCnt;
        this.bidSysCnt=bidSysCnt;
        this.bidSysOk=bidSysOk;
        this.bidAoiidDiff=bidAoiidDiff;
        this.bidCfNorm=bidCfNorm;
        this.bidCfNormMultiGid=bidCfNormMultiGid;
        this.bidCfComapny=bidCfComapny;
        this.bidCfPhone=bidCfPhone;
        this.bidCfDsPoi=bidCfDsPoi;
        this.bidCfMinPoi=bidCfMinPoi;
        this.bidCfAoiMapping=bidCfAoiMapping;
        this.bidCfOther=bidCfOther;
    }

    public String getSysSource() {
        return sysSource;
    }

    public void setSysSource(String sysSource) {
        this.sysSource = sysSource;
    }

    public int getBidCollectCnt() {
        return bidCollectCnt;
    }

    public void setBidCollectCnt(int bidCollectCnt) {
        this.bidCollectCnt = bidCollectCnt;
    }

    public int getBidCollectRejectCnt() {
        return bidCollectRejectCnt;
    }

    public void setBidCollectRejectCnt(int bidCollectRejectCnt) {
        this.bidCollectRejectCnt = bidCollectRejectCnt;
    }

    public int getBidCfCnt() {
        return bidCfCnt;
    }

    public void setBidCfCnt(int bidCfCnt) {
        this.bidCfCnt = bidCfCnt;
    }

    public int getBidSysCnt() {
        return bidSysCnt;
    }

    public void setBidSysCnt(int bidSysCnt) {
        this.bidSysCnt = bidSysCnt;
    }

    public int getBidSysOk() {
        return bidSysOk;
    }

    public void setBidSysOk(int bidSysOk) {
        this.bidSysOk = bidSysOk;
    }

    public int getBidAoiidDiff() {
        return bidAoiidDiff;
    }

    public void setBidAoiidDiff(int bidAoiidDiff) {
        this.bidAoiidDiff = bidAoiidDiff;
    }

    public int getBidCfNorm() {
        return bidCfNorm;
    }

    public void setBidCfNorm(int bidCfNorm) {
        this.bidCfNorm = bidCfNorm;
    }

    public int getBidCfNormMultiGid() {
        return bidCfNormMultiGid;
    }

    public void setBidCfNormMultiGid(int bidCfNormMultiGid) {
        this.bidCfNormMultiGid = bidCfNormMultiGid;
    }

    public int getBidCfComapny() {
        return bidCfComapny;
    }

    public void setBidCfComapny(int bidCfComapny) {
        this.bidCfComapny = bidCfComapny;
    }

    public int getBidCfPhone() {
        return bidCfPhone;
    }

    public void setBidCfPhone(int bidCfPhone) {
        this.bidCfPhone = bidCfPhone;
    }

    public int getBidCfDsPoi() {
        return bidCfDsPoi;
    }

    public void setBidCfDsPoi(int bidCfDsPoi) {
        this.bidCfDsPoi = bidCfDsPoi;
    }

    public int getBidCfMinPoi() {
        return bidCfMinPoi;
    }

    public void setBidCfMinPoi(int bidCfMinPoi) {
        this.bidCfMinPoi = bidCfMinPoi;
    }

    public int getBidCfAoiMapping() {
        return bidCfAoiMapping;
    }

    public void setBidCfAoiMapping(int bidCfAoiMapping) {
        this.bidCfAoiMapping = bidCfAoiMapping;
    }

    public int getBidCfOther() {
        return bidCfOther;
    }

    public void setBidCfOther(int bidCfOther) {
        this.bidCfOther = bidCfOther;
    }

    public int getAddressBuilding() {
        return addressBuilding;
    }

    public void setAddressBuilding(int addressBuilding) {
        this.addressBuilding = addressBuilding;
    }

    public int getAoiAuto() {
        return aoiAuto;
    }

    public void setAoiAuto(int aoiAuto) {
        this.aoiAuto = aoiAuto;
    }

    public int getAoiGis() {
        return aoiGis;
    }

    public void setAoiGis(int aoiGis) {
        this.aoiGis = aoiGis;
    }

    public int getAoi() {
        return aoi;
    }

    public void setAoi(int aoi) {
        this.aoi = aoi;
    }

    public int getAoiArssRe() {
        return aoiArssRe;
    }

    public void setAoiArssRe(int aoiArssRe) {
        this.aoiArssRe = aoiArssRe;
    }

    public int getAoiArssReq() {
        return aoiArssReq;
    }

    public void setAoiArssReq(int aoiArssReq) {
        this.aoiArssReq = aoiArssReq;
    }

    public int getAoiOther() {
        return aoiOther;
    }

    public void setAoiOther(int aoiOther) {
        this.aoiOther = aoiOther;
    }

    public int getAoiKs() {
        return aoiKs;
    }

    public void setAoiKs(int aoiKs) {
        this.aoiKs = aoiKs;
    }

    public int getAoiNorm() {
        return aoiNorm;
    }

    public void setAoiNorm(int aoiNorm) {
        this.aoiNorm = aoiNorm;
    }

    public int getAoiDispatchNorm() {
        return aoiDispatchNorm;
    }

    public void setAoiDispatchNorm(int aoiDispatchNorm) {
        this.aoiDispatchNorm = aoiDispatchNorm;
    }

    public int getAoiSch() {
        return aoiSch;
    }

    public void setAoiSch(int aoiSch) {
        this.aoiSch = aoiSch;
    }

    public int getAoiTc2() {
        return aoiTc2;
    }

    public void setAoiTc2(int aoiTc2) {
        this.aoiTc2 = aoiTc2;
    }

    public int getAoiDispatchTc2() {
        return aoiDispatchTc2;
    }

    public void setAoiDispatchTc2(int aoiDispatchTc2) {
        this.aoiDispatchTc2 = aoiDispatchTc2;
    }

    public int getAoiChke() {
        return aoiChke;
    }

    public void setAoiChke(int aoiChke) {
        this.aoiChke = aoiChke;
    }

    public int getAoiDispatchChke() {
        return aoiDispatchChke;
    }

    public void setAoiDispatchChke(int aoiDispatchChke) {
        this.aoiDispatchChke = aoiDispatchChke;
    }

    public int getAoiChkn() {
        return aoiChkn;
    }

    public void setAoiChkn(int aoiChkn) {
        this.aoiChkn = aoiChkn;
    }

    public int getAoiPhone() {
        return aoiPhone;
    }

    public void setAoiPhone(int aoiPhone) {
        this.aoiPhone = aoiPhone;
    }

    public int getAoiDispatchChkn() {
        return aoiDispatchChkn;
    }

    public void setAoiDispatchChkn(int aoiDispatchChkn) {
        this.aoiDispatchChkn = aoiDispatchChkn;
    }

    public int getAoiDispatchRoad() {
        return aoiDispatchRoad;
    }

    public void setAoiDispatchRoad(int aoiDispatchRoad) {
        this.aoiDispatchRoad = aoiDispatchRoad;
    }

    public int getAoiDispatchPhone() {
        return aoiDispatchPhone;
    }

    public void setAoiDispatchPhone(int aoiDispatchPhone) {
        this.aoiDispatchPhone = aoiDispatchPhone;
    }

    public String getUnderCall() {
        return underCall;
    }

    public void setUnderCall(String underCall) {
        this.underCall = underCall;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getAoiFc() {
        return aoiFc;
    }

    public void setAoiFc(int aoiFc) {
        this.aoiFc = aoiFc;
    }

    public int getAoiGisFc() {
        return aoiGisFc;
    }

    public void setAoiGisFc(int aoiGisFc) {
        this.aoiGisFc = aoiGisFc;
    }

    public int getAoiNormFc() {
        return aoiNormFc;
    }

    public void setAoiNormFc(int aoiNormFc) {
        this.aoiNormFc = aoiNormFc;
    }

    public int getAoiDispatchNormFc() {
        return aoiDispatchNormFc;
    }

    public void setAoiDispatchNormFc(int aoiDispatchNormFc) {
        this.aoiDispatchNormFc = aoiDispatchNormFc;
    }

    public int getAoiSchFc() {
        return aoiSchFc;
    }

    public void setAoiSchFc(int aoiSchFc) {
        this.aoiSchFc = aoiSchFc;
    }

    public int getAoiTc2Fc() {
        return aoiTc2Fc;
    }

    public void setAoiTc2Fc(int aoiTc2Fc) {
        this.aoiTc2Fc = aoiTc2Fc;
    }

    public int getAoiDispatchTc2Fc() {
        return aoiDispatchTc2Fc;
    }

    public void setAoiDispatchTc2Fc(int aoiDispatchTc2Fc) {
        this.aoiDispatchTc2Fc = aoiDispatchTc2Fc;
    }

    public int getAoiChkeFc() {
        return aoiChkeFc;
    }

    public void setAoiChkeFc(int aoiChkeFc) {
        this.aoiChkeFc = aoiChkeFc;
    }

    public int getAoiDispatchChkeFc() {
        return aoiDispatchChkeFc;
    }

    public void setAoiDispatchChkeFc(int aoiDispatchChkeFc) {
        this.aoiDispatchChkeFc = aoiDispatchChkeFc;
    }

    public int getAoiChknFc() {
        return aoiChknFc;
    }

    public void setAoiChknFc(int aoiChknFc) {
        this.aoiChknFc = aoiChknFc;
    }

    public int getAoiPhoneFc() {
        return aoiPhoneFc;
    }

    public void setAoiPhoneFc(int aoiPhoneFc) {
        this.aoiPhoneFc = aoiPhoneFc;
    }

    public int getAoiDispatchChknFc() {
        return aoiDispatchChknFc;
    }

    public void setAoiDispatchChknFc(int aoiDispatchChknFc) {
        this.aoiDispatchChknFc = aoiDispatchChknFc;
    }

    public int getAoiDispatchRoadFc() {
        return aoiDispatchRoadFc;
    }

    public void setAoiDispatchRoadFc(int aoiDispatchRoadFc) {
        this.aoiDispatchRoadFc = aoiDispatchRoadFc;
    }

    public int getAoiDispatchPhoneFc() {
        return aoiDispatchPhoneFc;
    }

    public void setAoiDispatchPhoneFc(int aoiDispatchPhoneFc) {
        this.aoiDispatchPhoneFc = aoiDispatchPhoneFc;
    }

    public int getAoiOtherFc() {
        return aoiOtherFc;
    }

    public void setAoiOtherFc(int aoiOtherFc) {
        this.aoiOtherFc = aoiOtherFc;
    }

    public int getAoiKsFc() {
        return aoiKsFc;
    }

    public void setAoiKsFc(int aoiKsFc) {
        this.aoiKsFc = aoiKsFc;
    }

    public int getAoiArssFc() {
        return aoiArssFc;
    }

    public void setAoiArssFc(int aoiArssFc) {
        this.aoiArssFc = aoiArssFc;
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }

    public int getAoiMonthAccFc() {
        return aoiMonthAccFc;
    }

    public void setAoiMonthAccFc(int aoiMonthAccFc) {
        this.aoiMonthAccFc = aoiMonthAccFc;
    }

    public int getAoiMonthAcc() {
        return aoiMonthAcc;
    }

    public void setAoiMonthAcc(int aoiMonthAcc) {
        this.aoiMonthAcc = aoiMonthAcc;
    }

    public void merge(OmsPuAoi obj) {
        this.order += obj.getOrder();
        //aoi
        this.aoi += obj.getAoi();
        this.aoiAuto += obj.getAoiAuto();
        this.aoiGis += obj.getAoiGis();
        this.aoiNorm += obj.getAoiNorm();
        this.aoiDispatchNorm += obj.getAoiDispatchNorm();
        this.aoiSch += obj.getAoiSch();
        this.aoiTc2 += obj.getAoiTc2();
        this.aoiDispatchTc2 += obj.getAoiDispatchTc2();
        this.aoiChke += obj.getAoiChke();
        this.aoiDispatchChke += obj.getAoiDispatchChke();
        this.aoiChkn += obj.getAoiChkn();
        this.aoiPhone += obj.getAoiPhone();
        this.aoiDispatchChkn += obj.getAoiDispatchChkn();
        this.aoiDispatchRoad += obj.getAoiDispatchRoad();
        this.aoiDispatchPhone += obj.getAoiDispatchPhone();
        this.aoiMonthAcc += obj.getAoiMonthAcc();
        this.aoiOther += obj.getAoiOther();
        this.aoiKs += obj.getAoiKs();
        this.aoiArssRe += obj.getAoiArssRe();
        this.aoiArssReq += obj.getAoiArssReq();

        this.aoiFc += obj.getAoiFc();
        this.aoiGisFc += obj.getAoiGisFc();
        this.aoiKsFc += obj.getAoiKsFc();
        this.aoiArssFc += obj.getAoiArssFc();

        this.aoiNormFc += obj.getAoiNormFc();
        this.aoiChkeFc += obj.getAoiChkeFc();
        this.aoiChknFc += obj.getAoiChknFc();
        this.aoiOtherFc += obj.getAoiOtherFc();
        this.aoiPhoneFc += obj.getAoiPhoneFc();
        this.aoiSchFc += obj.getAoiSchFc();
        this.aoiTc2Fc +=obj.getAoiTc2Fc();
        this.aoiDispatchChkeFc += obj.getAoiDispatchChkeFc();
        this.aoiDispatchChknFc += obj.getAoiDispatchChknFc();
        this.aoiDispatchNormFc += obj.getAoiDispatchNormFc();
        this.aoiDispatchPhoneFc += obj.getAoiDispatchPhoneFc();
        this.aoiDispatchRoadFc += obj.getAoiDispatchRoadFc();
        this.aoiDispatchTc2Fc += obj.getAoiDispatchTc2Fc();
        this.aoiMonthAccFc += obj.getAoiMonthAccFc();

        this.addressBuilding += obj.getAddressBuilding();

        this.bidCollectCnt += obj.getBidCollectCnt();
        this.bidCollectRejectCnt += obj.getBidCollectRejectCnt();
        this.bidCfCnt += obj.getBidCfCnt();
        this.bidSysCnt += obj.getBidSysCnt();
        this.bidSysOk += obj.getBidSysOk();
        this.bidAoiidDiff += obj.getBidAoiidDiff();
        this.bidCfNorm += obj.getBidCfNorm();
        this.bidCfNormMultiGid += obj.getBidCfNormMultiGid();
        this.bidCfComapny += obj.getBidCfComapny();
        this.bidCfPhone += obj.getBidCfPhone();
        this.bidCfDsPoi += obj.getBidCfDsPoi();
        this.bidCfMinPoi += obj.getBidCfMinPoi();
        this.bidCfAoiMapping += obj.getBidCfAoiMapping();
        this.bidCfOther += obj.getBidCfOther();

    }
}
