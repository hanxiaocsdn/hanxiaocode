package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.io.{BufferedReader, InputStreamReader}
import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.FileUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_pai.index.oms_realtime.AoiUnMatchData._
import com.sf.gis.scala.utils.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01375125 on 2018/6/6.
 * 统计指标
 */
object OmsIndexStat extends Serializable {

  val logger: Logger = Logger.getLogger(this.getClass.getSimpleName.replace("$", ""))

  case class CityObj(province: String, region: String, city: String, citycode: String)

  /** *
   * 定义维度类型
   */
  object MergeType extends Enumeration {
    type MergeType = Value //声明枚举对外暴露的变量类型
    val date = Value("date")
    val zc = Value("zc")
    val region = Value("region")
    val city = Value("city")
    val ak = Value("ak")
  }

  def main(args: Array[String]): Unit = {


  }

  def fetchBidInfo(spark: SparkSession): RDD[(String, Int)] = {
    val sql = " with a as (select distinct aoi_id from dm_gis.t_dm_tmp_aoi_sp_cnt_dist_v1_aoi_list )," +
      " b as (select distinct aoi_id from dm_gis.bid_aoi_reject where data_type='publish') " +
      " select a.aoi_id,if(b.aoi_id is null,0,1) reject from a left join b on a.aoi_id=b.aoi_id "
    logger.error(sql)
    val bidAoiInfoRdd = spark.sql(sql).rdd.map(obj => {
      (obj.getString(0), obj.getInt(1))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("楼栋的aoi数量:" + bidAoiInfoRdd.count())
    logger.error("楼栋的剔除aoi数量" + bidAoiInfoRdd.filter(obj => obj._2 == 1).count())
    bidAoiInfoRdd
  }

  def convertBidAoi(spark: SparkSession, bidAoiInfoRdd: RDD[(String, Int)]) = {
    val bidAoiInfoMap = bidAoiInfoRdd.map(obj => {
      ((obj._1.hashCode % 5000).toString, (obj._1, obj._2))
    }).groupByKey().map(obj => {
      val map = new util.HashMap[String, Int]()
      val iter = obj._2.iterator
      while (iter.hasNext) {
        val tmp = iter.next()
        map.put(tmp._1, tmp._2)
      }
      (obj._1, map)
    }).collectAsMap()
    logger.error("bidAoi hash后数量:" + bidAoiInfoMap.size)
    val key = bidAoiInfoMap.keySet.take(1).last
    logger.error(key + ":" + bidAoiInfoMap.get(key).get.toString)

    //    logger.error("keys:"+bidAoiInfoMap.keySet.mkString(","))
    spark.sparkContext.broadcast(bidAoiInfoMap)
  }

  def fetchInvalidDept(spark: SparkSession, incDay: String, taskCode: Int): util.HashSet[String] = {
    var date = incDay
    if (taskCode == 0) {
      date = Util.dateDelta(-1, "")
    }
    val deptTable = "gdl.zipper_dim_department"
    val deptSql = s"select dept_code from $deptTable where dw_start_date<='$date' and dw_end_date>= '$date' " +
      s" and (dept_type_code in ('DB05-XMDB','FB04-WXJ','FB05-CCPSCK','DB05-JPZ','FB04-KYFB','ZZC04-ERJ','ZZC05-KYJS','QB03-KYGS') " +
      s" or (dept_type_code='DB05-SFZ' and (dept_name like '%临时网点%'" +
      " )))"
    val deptList = spark.sql(deptSql).rdd.map(obj => obj.getString(0)).collect()
    val deptSet = new util.HashSet[String]()
    for (dept <- deptList) {
      if (dept != null && !dept.isEmpty) {
        deptSet.add(dept)
      }
    }
    logger.error("识别率流程中剔除网点数量:" + deptSet.size())
    val csvFileDept = getAoiDeptOutList
    logger.error("文件带的特殊网点数量：" + csvFileDept.size)
    deptSet.addAll(csvFileDept)
    deptSet
  }

  /**
   * 把配置资源中的数据加载到内存中来
   *
   * @return
   */
  def getAoiDeptOutList: ArrayBuffer[String] = {
    val list = new ArrayBuffer[String]
    val br = new BufferedReader(new InputStreamReader(classOf[FileUtil].getClassLoader.getResourceAsStream("conf/oms_pai/aoi_deptcode_out.csv")))
    br.readLine()
    var line = br.readLine()
    while (line != null) {
      val strs = line.split(",")
      list += strs(0)
      line = br.readLine()
    }
    logger.error("剔除网点数量：" + list.size)
    if (list.size > 0) {
      logger.error("deptecode:" + list.apply(0))
    }
    list
  }


  def checkInvalidAddressNew(obj: JSONObject, city2CityCodeMap: util.HashMap[String, String]): Int = {
    val cityCode = JSONUtil.getJsonVal(obj, "cityCode", "")
    val address = JSONUtil.getJsonVal(obj, "address", "")
    val gisSrc = JSONUtil.getJsonVal(obj, "gisSrc", "")

    var splitResult = JSONUtil.getJsonVal(obj, "splitResult", "")
    var groupIds = JSONUtil.getJsonVal(obj, "groupIds", "")
    var filters = JSONUtil.getJsonVal(obj, "filters", "")

    val filterSet = filters.split(Constant.SEP).toSet.-("")
    val groupIdSet = groupIds.split(Constant.SEP).toSet.-("")
    var _type = markByAddress(address, cityCode, gisSrc)
    if (_type != null)
      return 1
    _type = markByCity(splitResult, cityCode, city2CityCodeMap)
    if (_type != null)
      return 1
    _type = markByFilter(filterSet, groupIdSet, "")
    if (_type != null)
      return 1
    val typeTp = markByKeyWord(splitResult)
    _type = typeTp._1
    if (_type != null)
      return 0
    _type = markBySplitType(address, splitResult)
    if (_type != null && (_type.equals(Constant.MARK_9)
      || _type.equals(Constant.MARK_4) || _type.equals(Constant.MARK_5)
      || _type.equals(Constant.MARK_3) || _type.equals(Constant.MARK_2))) {
      return 1
    }
    0
  }

  /**
   * 筛选最终bid, 取第一个bid和最后一个bid，如果第一个aoidid于addressaoiid不相等且最后一个bid的aoiid和addressAoiid相同则取最后一个
   * 第一个bid_body作为基础非兜底策略的返回，需要单独使用
   * 返回的第一个标号，代表整个返回源，是第一个还是兜底返回的
   *
   * @param obj
   * @param addresseeAoiId
   * @return
   */
  def queryBidReBody(obj: JSONObject, addresseeAoiId: String): (String, JSONObject, JSONObject) = {
    val bid_re_array = obj.getJSONArray("bid_re_body")
    if (bid_re_array == null || bid_re_array.size() == 0) {
      return (null, null, null)
    } else if (bid_re_array.size() == 1) {
      return ("1", bid_re_array.getJSONObject(0), bid_re_array.getJSONObject(0))
    } else {
      var bid_re_body_first = bid_re_array.getJSONObject(0)
      var bid_re_body_last = bid_re_array.getJSONObject(bid_re_array.size() - 1)
      val bidAoiidFirst = JSONUtil.getJsonVal(bid_re_body_first, "result.aoiId", "")
      if (!bidAoiidFirst.isEmpty && bidAoiidFirst.equals(addresseeAoiId)) {
        return ("1", bid_re_body_first, bid_re_body_first)
      }
      val bidAoiidLast = JSONUtil.getJsonVal(bid_re_body_last, "result.aoiId", "")
      if (!bidAoiidLast.isEmpty && bidAoiidLast.equals(addresseeAoiId)) {
        return ("2", bid_re_body_last, bid_re_body_first)
      }
      ("1", bid_re_body_first, bid_re_body_first)
    }

  }
}
