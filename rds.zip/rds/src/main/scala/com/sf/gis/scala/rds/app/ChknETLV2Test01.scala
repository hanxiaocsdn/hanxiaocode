package com.sf.gis.scala.rds.app

import java.net.URLEncoder
import java.util
import java.util.Date
import java.util.regex.Pattern

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.dto.DBInfo
import com.sf.gis.scala.base.spark.{Spark, SparkRead}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.utils.{Counter, StringUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks._

/**
 * 新派件审补下线逻辑
 * 需求方：郭本婕（01394694）
 *
 * @author 韩笑（01417629）
 *         Created on Dec.16 2022
 *         任务信息：138（新派件审补下线逻辑，	每天18时15分执行、2021年1月1日--）
 */
object ChknETLV2Test01 {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  //  case class Detail(address: String, cityCode: String, deliverytype: String, zno_code: String, dept: String, znocode: String,
  //                    depart_code: String, aoiid: String, aoi_id: String, group_id: String, group_group: String, standardization: String,
  //                    keyword: String, hasloc: Boolean, hastxt: Boolean, isbehind: Boolean, tag: Int, tag1: Int, tag2: Int, splitinfo: String,
  //                    action: Int, result: Int, one_group: String, norm_rsp: String, hp_rsp: String, extend_attach8: String, aoiunit_norm: String, aoiunit_hp: String, aoiunit_redis: String, flag: String, aoi_check_tag: String, update_resp: String, adcode_shenbu: String, adcode_biaozhun: String)
  case class Detail(address: String, citycode: String, deliverytype: String, zno_code: String, dept: String, dept_equal1: Boolean, aoiid_norm: String,
                    aoiid_chkn: String, aoi_chkn_null: Boolean, aoi_equal1: Boolean, group_id: String, group_group: String, standard: String,
                    keyword: String, hasloc: Boolean, hasdist: Boolean, hastxt: Boolean, has14: Boolean, isbehind: Boolean, tag: Int, tcs_src: String, recog_hp: String, dept_hp: String, dept_equal2: Boolean, aoiid_hp: String, aoi_equal2: Boolean, aoiunit_equal2: Boolean, tag1: Int, tag2: Int, splitinfo: String, splitinfo_chkn: String,
                    action: Int, result: Int, one_group: String, norm_rsp: String, hp_rsp: String, aoiunit_chkn: String, aoiunit_chkn_null: Boolean, aoiunit_equal1: Boolean, group_prod: String, dept_prod: String, dept_equal3: Boolean, aoiid_prod: String, aoi_equal3: Boolean, aoiunit_norm: String, aoiunit_hp: String, aoiunit_prod: String
                    , aoiunit_equal3: String, aoiunit_redis: String, flag: String, aoi_check_tag: String, update_resp: String, adcode_shenbu: String, adcode_biaozhun: String, adcode_chkn_is45678: String, adcode_equal: Boolean, date_time: String, message: String, drop_time: String, action_flag: String, filter: String, level: String, chknid: String,aoiunit_norm_null : Boolean,aoiunit_fix : String)

  val sep = "\u0001"
  val driver = "com.mysql.jdbc.Driver"
  //val url = "jdbc:mysql://wchka-m.dbdr.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull"
  val url = "jdbc:mysql://wchka-s1.db.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull"
  val uid = "wchka_aoi"
  val pwd = "giscmsaoi123"

  def getCitiesByDay(day: String) = {

    val cityplan =
      s"""
         |2:027,022,512
         |3:028,029,769
         |4:023,757,571
         |5:010
         |6:021
         |7:020
         |8:755
         |9:576,532,531,431,8981
         |10:591,516,551,771,311,754
         |11:760,377,579,052,539,558
         |12:536,663,515,376,315,791,451
         |13:519,573,394,310,411,775,797,758,759
         |14:316,396,592,317,351,379,991,523,575,537
         |15:710,730,716,750,931,793,530,792,514,370,763
         |16:535,739,857,373,756,319,668,913,855,912,854,768
         |17:534,471,391,596,856,713,736,712,772,572,533,660,728
         |18:753,7313,518,374,746,517,511,635,734,593,556,476,313,372
         |19:816,314,762,773,745,719,774,412,735,472,795,858,717,718,550,375
         |20:817,594,527,359,751,831,543,378,352,916,538,355,715,796,432,859,917
         |21:354,053,553,738,766,477,599,564,357,874,737,597,470,994,475,662,318,557,951
         |22:873,794,358,818,393,417,632,870,7312,631,872,714,911,454,743,724,455,563,915,452,830,937
         |23:459,578,438,350,722,479,546,935,633,776,832,421,778,429,335,554,474,395,838,555,833,826,433,938,777,552,934,598,416
         |24:453,798,435,744,570,971,876,813,996,478,825,839,398,418,834,877,932,997,356,827,436,999,914,434,875,878,998,415,933,427,419,691,482,580,939
         |25:779,799,692,349,943,879,414,883,456,566
         |26:559,439,467,562,993,906,953,936,353,561,930,088,902,901,891,468,701,392,458,711,770,835,812,437,469,919,972,473,903,954,955,790,909,952,979,457,990,894,941,992,483,837,464,836,995,977,086,887,908,893,896,970,974,892,895,976,973,975
         |27:595,871,7311,513,312
         |28:574,752,898,025,510
         |29:577,371,024,851
         |""".stripMargin

    val citys = cityplan.split("\n").filter(_.startsWith(day + ":"))(0).split(":")(1).replaceAll("\r", "").replaceAll("\n", "")
    citys
  }

  def main(args: Array[String]): Unit = {
    //获取日期，按照天来分批处理城市
    val dayid = args(0) //20221208
    if (dayid.endsWith("30") || dayid.endsWith("31") || dayid.endsWith("01")) {
      logger.error("01|30|31号不搞事情~~,1号不知道为什么")
      System.exit(0)
    }
    val day = dayid.substring(6, 8).toInt.toString
    var citys = ""
    if (args.length > 1) {
      citys = args(1)
    } else {
      citys = getCitiesByDay(day) //citys=027,022,512
    }
    logger.error(s"$dayid 待处理城市：$citys")
    val sparkSession = Spark.getSparkSession(appName)
    citys.split(",").foreach(cityCode => {
      if (cityCode != "") {
        start(sparkSession, dayid, cityCode) //dayid=20221208,cityCode=027
        sparkSession.catalog.clearCache()
      }
    })
  }


  def start(sparkSession: SparkSession, dayid: String, cityCode: String) = {
    //构造 CMS地址变更城市名到数据库表映射
    //val token = "五环到六环之间,地铁20号口,内环到三环里,内环到二环里,地铁19号口,地铁18号口,地铁13号口,地铁12号口,地铁17号口,地铁11号口,地铁16号口,地铁15号口,内环到四环里,地铁10号口,地铁21号口,地铁14号口,二环到三环,地铁5号口,地铁6号口,的十字路口,地铁4号口,地铁9号口,地铁8号口,地铁7号口,往西走到底,地铁1号口,往南走到底,五环到六环,内环到四环,往东走到底,一环到二环,内环到三环,往城头方向,往北走顺路,地铁3号口,四环到五环,地铁2号口,的交叉路口,内环到二环,三环到四环,自西向东,西四门市,东南方向,西三门市,东南门市,马路对面,西南门市,东一门市,西南方向,二环以内,西二门市,二环以外,交叉路口,下电梯口,西北门市,南二门市,进去即是,西北方向,六环以内,进入网站,右转到底,六环以外,五环以外,五环以内,楼下门市,向东直行,三叉路口,向北直行,马路对门,的入口处,往西到底,下楼梯口,的十字路,往南到底,下扶梯口,北二门市,北四门市,北三门市,往东到底,自南向北,自东向西,自北向南,西转盘处,往北到底,东北门市,北转盘处,的出口处,的交叉口,转弯角处,四环以外,四环以内,小转盘路,小转盘处,向南直行,东门路口,东北方向,三岔路口,十字路口,的交汇处,的交界处,三环以外,向西直行,三环以内,西北角,西北侧,那条路,五环外,靠左手,靠右手,左手边,靠西面,靠西边,靠南面,左侧街,靠南边,靠东面,最外面,最里面,靠东边,靠北边,转弯角,进站口,交口处,转盘旁,转盘路,转盘街,转角处,交界口,交界处,中间的,交接的,交接处,交会处,正西面,正西方,正西侧,正南面,正南方,正南侧,交汇处,正畸科,正对着,正对面,正对门,正对过,正对个,交差口,正东面,正东方,正东侧,正大门,正北面,正北方,正北侧,这条路,交叉口,站牌旁,站牌处,交叉处,过马路,拐弯处,附属楼,负一层,二环外,右手边,东院区,东一门,东入口,右侧街,东南门,东南角,东南侧,东大院,东大门,东侧厅,东北隅,东北门,东北角,东北侧,地下室,北三门,北入口,延长线,延伸线,延伸段,新转盘,斜对面,斜对过,北二门,五车间,往里走,停靠站,四环外,四车间,北大门,的入口,的路口,的交口,的交汇,的出口,单行道,大门外,大门前,大门口,出站口,出入口,出口处,便道上,三环外,入门处,入口处,西转盘,西院区,米左右,六环外,靠北面,南三门,西南隅,西南首,南入口,西南角,西南侧,南二门,南大院,南大门,那条巷,以北,街口,边头,边上,背面,背后,北走,外围,接近,往北,脚下,北头,北厅,北梯,北塔,往里,那排,往南,往西,往右,往左,西边,西侧,西端,左数,左首,左手,左面,左段,左侧,左边,对门,西行,西户,转入,转角,左转,中间,直入,之间,正门,正对,这里,西邻,西临,院内,右转,右数,右首,右手,右面,右段,右侧,右边,西门,西面,西墙,以西,以外,以内,以南,以东,西首,一侧,沿线,斜对,西数,巷内,巷口,向左,向右,向下,向西,向上,向南,向里,向东,向北,相邻,下面,下滑,下行,下段,西厅,西头,交口,西塔,南口,交界,米处,门外,门前,交会,南数,交汇,南走,前边,路西,路尾,交叉,后走,后有,后厅,后面,后门,后楼,后栋,后边,河边,过去,过桥,路南,过了,过道,路东,拐弯,拐角,隔壁,前行,路边,附近,路北,前楼,前面,内侧,西梯,对面,街边,对过,能到,东数,东头,东厅,上面,前往,旁边,两侧,前约,东面,前走,东门,东临,东邻,东口,东户,东行,里边,南行,南首,东侧,东边,南墙,桥北,南端,靠西,桥东,南面,掉头,店内,南门,桥南,北数,北首,桥西,靠南,靠近,北墙,北面,北门,北临,北邻,北口,北户,北行,南侧,北端,南边,靠东,北侧,北边,挨着,入口,西口,南临,靠北,上行,顺着,外侧,外面,南邻,到底,往东,进入,其他,村北,进去,紧邻,出去,街上,出口,朝北,侧面,侧门,侧边,靠,旁,侧".split(",")
    //val token = "交差口,交界,分岔,交叉,路口,对面,旁,隔壁,近,附近,靠近,挨着,接近,临近,相临,相邻,邻近,尽头,到底,之间,桥东,桥西,桥北,桥南,走一会,掉头,拐弯,拐角,转弯,城尾,城头,村头,村尾,中间,最里面,直行,直走,往东,往西,往北,往南,向东,向西,向北,向南,往前,往后,后面,前面,东侧,西侧,南侧,北侧,侧边,外侧,外围,周边,前走,前行,后走,后行".split(",")
    //val token = "交差口,交界,分岔,交叉,路口,对面,旁,旁边,隔壁,近,附近,靠近,挨着,接近,临近,相临,相邻,邻近,尽头,到底,之间,桥东,桥西,桥北,桥南,走一会,掉头,拐弯,拐角,转弯,城尾,城头,村头,村尾,中间,最里面,直行,直走,往东,往西,往北,往南,向东,向西,向北,向南,往前,往后,后面,前面,东侧,西侧,南侧,北侧,西北侧,东北侧,东南侧,西南侧,东边,西边,南边,北边,西北边,东北边,东南边,西南边,侧边,外侧,外围,周边,前走,前行,后走,后行,路北,路南,路西,路东".split(",")
    //val token = "交差口,交界,分岔,交叉,路口,对面,旁,隔壁,近,附近,靠近,挨着,接近,临近,相临,相邻,邻近,尽头,到底,之间,桥东,桥西,桥北,桥南,走一会,掉头,拐弯,拐角,转弯,城尾,城头,村头,村尾,中间,最里面,直行,直走,往东,往西,往北,往南,向东,向西,向北,向南,往前,往后,后面,前面,东侧,西侧,南侧,北侧,西北侧,东北侧,东南侧,西南侧,东边,西边,南边,北边,西北边,东北边,东南边,西南边,侧边,外侧,外围,周边,前走,前行,后走,后行,路北,路南,路西,路东,右侧,左侧,前方,后方,侧门,旁边,旁侧,东口,西口,南口,北口".split(",")
    val token = "交差口,交界,分岔,交叉,路口,对面,旁,隔壁,近,附近,靠近,挨着,接近,临近,相临,相邻,邻近,尽头,到底,之间,桥东,桥西,桥北,桥南,走一会,掉头,拐弯,拐角,转弯,城尾,城头,村头,村尾,中间,最里面,直行,直走,往东,往西,往北,往南,向东,向西,向北,向南,往前,往后,后面,前面,东侧,西侧,南侧,北侧,西北侧,东北侧,东南侧,西南侧,东边,西边,南边,北边,西北边,东北边,东南边,西南边,侧边,外侧,外围,周边,前走,前行,后走,后行,路北,路南,路西,路东,右侧,左侧,前方,后方,侧门,旁边,旁侧,东口,西口,南口,北口,对过,左拐,右拐,前拐,后拐,拐左,拐右".split(",")
    val citydef =
      s"""010=1
         |020=2
         |021=3
         |755=4
         |022,023,024,025,027,028,029,052,053,086,088,310,311,312,313,314,315,316,317,318=5
         |319,335,349,350,351,352,353,354,355,356,357,358,359,370,371,372,373,374,375,376=6
         |377,378,379,391,392,393,394,395,396,398,411,412,414,415,416,417,418,419,421,427=7
         |429,431,432,433,434,435,436,437,438,439,451,452,453,454,455,456,457,458,459,464=8
         |467,468,469,470,471,472,473,474,475,476,477,478,479,482,483,510,511,512,513,514=9
         |515,516,517,518,519,523,527,530,531,532,533,534,535,536,537,538,539,543,546,550=10
         |551,552,553,554,555,556,557,558,559,561,562,563,564,566,570,571,572,573,574,575=11
         |576,577,578,579,580,591,592,593,594,595,596,597,598,599,631,632,633,634,635,660=12
         |662,663,668,691,692,701,710,711,712,713,714,715,716,717,718,719,722,724,728,730=13
         |7311,7312,7313,734,735,736,737,738,739,743,744,745,746,750,751,752,753,754,756,757=14
         |758,759,760,762,763,766,768,769,770,771,772,773,774,775,776,777,778,779,790,791=15
         |792,793,794,795,796,797,798,799,812,813,816,817,818,825,826,827,830,831,832,833=16
         |834,835,836,837,838,839,851,852,853,854,855,856,857,858,859,870,871,872,873,874=17
         |875,876,877,878,879,883,886,887,891,892,893,894,895,896,897,898,8981,8982,8983,901=18
         |902,903,906,908,909,911,912,913,914,915,916,917,919,930,931,932,933,934,935,936=19
         |937,938,939,941,943,951,952,953,954,955,970,971,972,973,974,975,976,977,979,990,991,992,993,994,995,996,997,998,999=20""".stripMargin
        .split("\n").filter(_.length > 0).map(d => {

        val t = d.split("=")
        if (t.size > 1) {
          val v = t(1)
          t(0).split(",").map(cityCode => {
            (cityCode, v)
          })
        } else {
          logger.error("parse error:" + d)
          null
        }
      }).filter(_ != null).flatMap(d => d).toMap
    logger.error("----------------------------------------------------------------------------------------------")

    val cityPartition = citydef.getOrElse(cityCode, "0") //cityPartition=5
    val debugZcCnd = "" // "and (zno_code='021FD')" // and zno_code ='512QC'" //todo remove this //  " and zno_code ='512QC'" //
    val sql = s"""select zno_code,count(1) cnt from wchka.cms_address_$cityPartition where city_code='$cityCode' and `type`=2 and delivery_type in (0,2) and del_flag=0 and zno_code like '$cityCode%' $debugZcCnd group by zno_code"""
    val dbInfo = new DBInfo(driver, url, uid, pwd)
    val zcList = SparkRead.readMysqlAsRow(sparkSession, dbInfo, sql)._1.collect().map(row => {
      val zc = row.getString(0)
      val cnt = row.getLong(1).toInt
      (zc, cnt)
    }).filter(_._1.startsWith(cityCode)).sortBy(_._1)

    val total = zcList.map(_._2).sum
    logger.error("城市：" + cityCode + "，待处理记录数：" + total)

    zcList.foreach(d => println(d.productIterator.mkString("=")))

    val threadCnt = 5

    process(sparkSession, zcList, cityCode, cityPartition, dayid, token)

    logger.error("城市：" + cityCode + "，网点数：" + zcList.size + "，处理完毕")


    val processed = sparkSession.sql(s"select * from dm_gis.chkn_etl_v2 where inc_day='$dayid' and city_code='$cityCode'").persist(StorageLevel.MEMORY_AND_DISK_SER)
    val p1 = zcList.map(_._2).sum.toLong
    val t1 = "审补库总量"
    val r1 = ""

    val p2 = processed.where("depart_code<>'' and depart_code is not null").count()
    val t2 = "匹上标准库数据"
    val r2 = rate(p2, p1)

    val p3 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null").count()
    val t3 = "审补网点和标准网点相等数据"
    val r3 = rate(p3, p1)

    val p4 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null and aoiid<>'' and aoiid is not null and aoiid=aoi_id").count()
    val t4 = "审补网点和标准网点相等&审补有AOI&审补AOI=标准AOI"
    val r4 = rate(p4, p1)

    val p5 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null and (aoiid='' or aoiid is null) and (aoi_id='' or aoi_id is null)").count()
    val t5 = "审补网点和标准网点相等&审补无AOI&标准无AOI"
    val r5 = rate(p5, p1)

    val p6 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null and (aoiid='' or aoiid is null) and aoi_id<>'' and aoi_id is not null and one_group='true'").count()
    val t6 = "审补网点和标准网点相等&审补无AOI&标准有AOI&大组唯一"
    val r6 = rate(p6, p1)

    val p7 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null and (aoiid='' or aoiid is null) and aoi_id<>'' and aoi_id is not null and one_group='false'").count()
    val t7 = "审补网点和标准网点相等&审补无AOI&标准有AOI&大组不唯一"
    val r7 = rate(p7, p1)

    val p8 = processed.where("tag=0 and tag1=0").count()
    val t8 = "拟下线数据中被normhp匹上"
    val r8 = rate(p8, p1)

    val p9 = processed.where("tag=0 and tag1=1").count()
    val t9 = "拟下线数据中未被normhp匹上"
    val r9 = rate(p9, p1)

    val p10 = processed.where("tag=0").count()
    val t10 = "拟下线数据"
    val r10 = rate(p10, p1)

    val p11a = processed.where("tag=0 and flag='0'").count()
    val t11a = "拟下线数据_AOI单元ID校验后"
    val r11a = rate(p11a, p1)

    val p11 = processed.where("tag=0 and flag='0' and tag2=0 and action=0").count()
    val t11 = "审补最终下线结果数"
    val r11 = rate(p11, p1)

    val p12 = processed.where("tag=0 and flag='0' and tag2=0 and action=1").count()
    val t12 = "redis不符"
    val r12 = rate(p12, p1)

    val p13 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='false'").count()
    val t13 = "审补下线结果中无方位词"
    val r13 = rate(p13, p1)

    val p14 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='true' and hastxt='false'").count()
    val t14 = "审补下线结果中有方位词且无文本"
    val r14 = rate(p14, p1)

    val p15 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='true' and hastxt='true'").count()
    val t15 = "审补下线结果中有方位词且有文本"
    val r15 = rate(p15, p1)

    val p16 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='true' and hastxt='true' and isbehind='true'").count()
    val t16 = "审补下线结果中有方位词且有文本且文本在方位词之后"
    val r16 = rate(p16, p1)

    val p17 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='true' and hastxt='true' and isbehind='false'").count()
    val t17 = "审补下线结果中有方位词且有文本且文本不在方位词之后"
    val r17 = rate(p17, p1)

    val p18 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and result=0").count()
    val t18 = "审补下线成功"
    val r18 = rate(p18, p1)

    val result = List(
      (1, t1, p1, r1),
      (2, t2, p2, r2),
      (3, t3, p3, r3),
      (4, t4, p4, r4),
      (5, t5, p5, r5),
      (6, t6, p6, r6),
      (7, t7, p7, r7),
      (8, t8, p8, r8),
      (9, t9, p9, r9),
      (10, t10, p10, r10),
      (11, t11a, p11a, r11a),
      (12, t11, p11, r11),
      (13, t12, p12, r12),
      (14, t13, p13, r13),
      (15, t14, p14, r14),
      (16, t15, p15, r15),
      (17, t16, p16, r16),
      (18, t17, p17, r17),
      (19, t18, p18, r18)
    )
    import sparkSession.implicits._
    sparkSession.sparkContext
      .makeRDD(result)
      .toDF("序号", "标题", "数量", "占比")
      .sort("序号")
      .show(false)

    //        1	审补库总量	总数
    //        2	匹上标准库数据	depart_code不为空
    //        3	审补网点和标准网点相等数据	znocode=depart_code
    //        4	审补网点和标准网点相等&审补有AOI&审补AOI=标准AOI	znocode=depart_code & aoiid不为空 & aoiid=aoi_id
    //        5	审补网点和标准网点相等&审补无AOI&标准无AOI	znocode=depart_code & aoiid为空 & aoi_id为空
    //        6	审补网点和标准网点相等&审补无AOI&标准有AOI&大组唯一	znocode=depart_code & aoiid为空 & aoi_id不为空 & one_group=true
    //        7	审补网点和标准网点相等&审补无AOI&标准有AOI&大组不唯一	znocode=depart_code & aoiid为空 & aoi_id不为空 & one_group=false
    //        8	拟下线数据中被normhp匹上	tag=0 & tag1=0
    //        9	拟下线数据中未被normhp匹上	tag=0 & tag1=1
    //        10	拟下线数据	tag=0
    //        11	审补最终下线结果数	tag=0 & tag2=0 & action=0
    //        12	redis不符	tag=0 & tag2=0 & action=1
    //        13	审补下线结果中无方位词	tag=0 & tag2=0 & action=0 & hasloc=false
    //        14	审补下线结果中有方位词且无文本	tag=0 & tag2=0 & action=0 & hasloc=true & hastxt=false
    //        15	审补下线结果中有方位词且有文本	tag=0 & tag2=0 & action=0 & hasloc=true & hastxt=true
    //        16	审补下线结果中有方位词且有文本且文本在方位词之后	tag=0 & tag2=0 & action=0 & hasloc=true & hastxt=true & isbehind=true
    //        17	审补下线结果中有方位词且有文本且文本不在方位词之后	tag=0 & tag2=0 & action=0 & hasloc=true & hastxt=true & isbehind=false
    //        18	审补下线成功	tag=0 & tag2=0 & action=0 & result=0


  }

  def rate(a: Long, b: Long) = {
    (Math.round(a.toDouble / b.toDouble * 10000) / 100.0).toString + "%"
  }

  def getSSSZnoCode(zcMap: java.util.HashMap[String, String], zno_code: String) = {
    if (zcMap.containsKey(zno_code)) {
      zcMap.get(zno_code)
    } else {
      zno_code
    }
  }

  def queryZcMap(cityCode: String) = {
    val url = s"""http://gis-cms-bg.sf-express.com/cms/api/zno/getZnoBySssZnoDepart?cityCode=$cityCode"""
    val zcMap = new java.util.HashMap[String, String]()
    val sb = new ArrayBuffer[String]()
    val json = HttpClientUtil.getJsonByGet(url, 5)
    if (json.getIntValue("code") == 200 && json.getBooleanValue("success") == true) {
      val data = json.getJSONArray("data")
      for (i <- 0 until data.size()) {
        val item = data.getJSONObject(i)
        zcMap.put(item.getString("znoCode"), item.getString("departCode"))
        sb.append(item.getString("znoCode") + "=>" + item.getString("departCode"))
      }
    } else {
      throw new Exception("获取网点映射失败")
    }
    logger.error("映射表:" + sb.mkString(","))
    zcMap
  }

  def process(sparkSession: SparkSession, zcList: Array[(String, Int)], cityCode: String,
              cityPartition: String,
              dayid: String, token: Array[String]) = {
    logger.error("获取zc网点映射数据")
    //val zcMap = queryZcMap(cityCode)
    //val zcMapBc = sparkSession.sparkContext.broadcast(zcMap)
    val zcin = zcList.map(_._1).mkString("'", "','", "'")
    logger.error("zcList:" + zcin)
    """
      |sch_code 删掉；zno_code 映射为 （cms 接口待定取名 znocode）
      |""".stripMargin
    // TODO: hide this
    val debugZcCnd = "" //"and zno_code='021FD'"
    val debugAddressCnd = "" // and address='江苏省苏州市昆山市开发区庆丰路路富花园西村18栋车库'"
    val src = sparkSession.read.format("jdbc")
      .option("driver", driver)
      .option("url", url)
      .option("dbtable", s"wchka.cms_address_$cityPartition")
      .option("user", uid)
      .option("password", pwd)
      .load()
      .where(s"city_code='$cityCode' and `type`=2 and del_flag=0 $debugZcCnd $debugAddressCnd")
      //.where(s"city_code='$cityCode' and (zno_code in ($zcin) or receipt_zno_code in ($zcin)) and `type`=2 and del_flag=0 $debugZcCnd $debugAddressCnd")
      //.where(s"city_code='$cityCode' and zno_code in($zcin) and `type`=2 and delivery_type in (0,2) and del_flag=0 $debugZcCnd $debugAddressCnd")
      .select("address", "zno_code", "aoi_id", "delivery_type", "keyword", "extend_attach8", "adcode", "address_md5","receipt_zno_code")
      .repartition(100 * 12).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //.createOrReplaceTempView(s"addr_${dayid}_$jobIdx")
    logger.error(s"【$cityCode】记录数${src.count}")

    //src.show(20, false)

    logger.error(s"【$cityCode】审补网点编码映射完毕")
    //address去重
    src.createOrReplaceTempView("tmp")
    val sql_1 =
      s"""
         |select
         |	 address
         |	,zno_code
         |	,aoi_id
         |	,delivery_type
         |	,keyword
         |	,extend_attach8
         |	,adcode
         |	,case when rn <> 1 then '0' else '1' end as action_flag
         | ,address_md5 as chknid
         |from
         |(
         |	select
         |		*
         |		,row_number() over(partition by address,zno_code,aoi_id,delivery_type,keyword,extend_attach8,adcode,address_md5 order by address,zno_code,aoi_id,delivery_type,keyword,extend_attach8,adcode,address_md5) as rn
         |	from
         | (
         |   select
         |      address
         |      ,case when zno_code is null or zno_code = '' then receipt_zno_code else zno_code end as zno_code
         |      ,aoi_id
         |      ,delivery_type
         |      ,keyword
         |      ,extend_attach8
         |      ,adcode
         |      ,address_md5
         |   from tmp
         | ) tt1
         |) as t1
         |""".stripMargin
    //val rdd1 = Util.getRowToJsonNew(sparkSession,sql_tmp)
    val rdd1 = sparkSession.sql(sql_1)
    rdd1.show(2)
    logger.error(s"rdd1共：${rdd1.count()}")


    //跑派件容灾
    val speedLimit = 50000 / sparkSession.sparkContext.getConf.get("spark.executor.instances", "20").toInt
    val b_speedLimit = sparkSession.sparkContext.broadcast(speedLimit)

    val detail1 = rdd1.rdd.repartition(1200).filter(obj => {
      "1".equals(StringUtil.fixnull(obj.getString(7)))
    }).mapPartitions(p => {
      //限制了每分钟访问量:6000, 每秒访问量100,【100cpu】每cpu每秒访问量1
      Counter.speedLimit = b_speedLimit.value

      def sleep(t0: Long): Unit = {
        Counter.count(t0)
      }

      p.map(f = d => {
        //val tmpZcMap = zcMapBc.value
        val t0 = new Date().getTime
        val addr = StringUtil.fixnull(d.getString(0))
        val zno_code = StringUtil.fixnull(d.getString(1)).toUpperCase()
        //val znocode = zno_code // dept
        /*if (tmpZcMap.containsKey(znocode)) {
          znocode = tmpZcMap.get(znocode)
        }*/
        //val aoi = StringUtil.fixnull(d.getString(2)).toUpperCase()
        val aoiid_chkn = StringUtil.fixnull(d.getString(2)).toUpperCase()
        val dt = d.getInt(3).toString
        //val dt = StringUtil.fixnull(d.getString(3))
        val keyword = StringUtil.fixnull(d.getString(4))
        //val extend_attach8 = StringUtil.fixnull(d.getString(5))
        val aoiunit_chkn = StringUtil.fixnull(d.getString(5))
        val adcode_shenbu = StringUtil.fixnull(d.getString(6))
        val action_flag = StringUtil.fixnull(d.getString(7))
        val chknid = StringUtil.fixnull(d.getString(8))
        var aoiunit_norm = ""
        var aoiunit_hp = ""
        var aoiunit_redis = ""
        var flag = ""
        var rsp = null: JSONObject
        var groupid = ""
        var aoiid_norm = ""
        //var teams = "".split(",")
        var depts = "".split(",")
        var standard = ""
        var dept = ""
        //var depart_code = ""
        //var team = ""
        var aoi_chkn_null = true
        if (aoiid_chkn.nonEmpty) {
          aoi_chkn_null = false
        }

        var tag = -1
        var tag1 = -1
        var tag2 = -1
        var action = -1
        var action_result = -1
        var message = ""
        var aoiCheckTag = ""
        //var tag_dingwei = ""

        var standardization = ""
        var adcode_biaozhun = ""
        var splitinfo = ""
        var one_group = "false"

        var dept_equal1 = false
        var aoiid_norm_no_empty = "0"
        var aoi_equal1 = false
        var adcode_chkn_is45678 = "0"
        var adcode_equal = true

        var group_prod = ""
        var dept_prod = ""
        var aoiid_prod = ""
        var aoiUnit_prod = ""
        var aoiunit_equal3 = "0"
        var dept_equal3 = false
        var aoi_equal3 = false

        var tcs_src = ""
        //var depart_code_hp = ""
        var dept_hp = ""
        var aoiid_hp = ""

        var splitinfo_chkn = ""

        var aoiunit_equal1 = false

        var filter = ""
        var level = ""

        var aoiunit_norm_null = true

        var aoiunit_fix = ""

        //ak before:0c3cd2c65820417d970b514122f16a1c  //6000 / min
        // ak new:e6a874c441cc41eda1b443d420f6632d    //10000 /min
        // 0c3cd2c65820417d970b514122f16a1c //100000 /min
        val url = s"""http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=${URLEncoder.encode(addr, "utf8")}&city=$cityCode&ak=0c3cd2c65820417d970b514122f16a1c&opt=normdetail"""
        //{"status":0,"result":{"src":"normdetail","count":1,"tcs":[{"src":"norm","flag":2,"dept":"512FP","team":"512FP017","groupid":"E1D3C6802D5011E8B7CF6C92BF74D4C8","notc":"0","aoicode":"512FP000136","aoiid":"62556EAEAE531B9DE0530EF4520A0CFC"}],"other":{"normresp":{"success":true,"errorCode":0,"result":{"status":0,"count":1,"geocoder":[{"floor":"0","adcode":320506,"filter":2,"group":"E1D3C6802D5011E8B7CF6C92BF74D4C8","name":"江苏省苏州市吴中区钟南街|208号","x":120.759,"y":31.314,"standardization":"江苏省苏州市吴中区苏州新加坡国际学校钟南街208号","score":1,"level":"GL_STREETNO","mainid":"162758","poi_typecode":"0","id":"408F2F302D5011E887E86C92BF74D4C8","sflag":0,"key":"1|2"}],"source":"suzhou","splitResult":"jiangsuprovincesuzhoucitywuzhong208zhongnanstreet^218,钟南街^19,208号^211;11","splitType":0,"addrSplitInfo":[{"match":"0","prop":"2","level":18,"name":"jiangsuprovincesuzhoucitywuzhong208zhongnanstreet"},{"match":"1","prop":"1","level":9,"name":"钟南街"},{"match":"1","prop":"2","level":11,"name":"208号"}],"guid":"D9ADECA9-418A-4EF8-8FD2-69E6FC576D50"}},"cacheresp":{"success":true,"errorCode":0,"result":[{"city":"512","groupid":"E1D3C6802D5011E8B7CF6C92BF74D4C8","floor":0,"result":[{"tc":"512FP017","dept":"512FP","notc":"0","aoiId":"62556EAEAE531B9DE0530EF4520A0CFC","aoiCode":"512FP000136","aoiTC":[{"dept":"512FP","tc":"512FP017"}]}],"query":{"adcode":320506,"floor":0,"filter":2,"city":"512"}}]},"normfilters":[{"src":"norm","flag":2,"dept":"512FP","team":"512FP017","groupid":"E1D3C6802D5011E8B7CF6C92BF74D4C8","aoicode":"512FP000136","aoiid":"62556EAEAE531B9DE0530EF4520A0CFC"}],"arg":{"createTime":1568877410168,"ak":"0c3cd2c65820417d970b514122f16a1c","remoteIp":"10.116.101.181","url":"http://nginx_wa/atdispatch/api?address=%22Jiangsu+ProvinceSuzhou+CityWuZhong208+Zhong+Nan+Street++%E9%92%9F%E5%8D%97%E8%A1%97208%22&city=512&ak=0c3cd2c65820417d970b514122f16a1c&opt=normdetail","city":"512","opt":"normdetail","address":"JiangsuProvinceSuzhouCityWuZhong208ZhongNanStreet钟南街208","adcode":"320500","originalAddress":"\"Jiangsu ProvinceSuzhou CityWuZhong208 Zhong Nan Street  钟南街208\""},"city":"512","adcode":"320500","filters":[2],"groupid":"E1D3C6802D5011E8B7CF6C92BF74D4C8"}}}
        try {
          rsp = HttpClientUtil.getJsonByGet(url, 5)
          if (rsp != null && rsp != "") {
            val json = rsp
            if (json.getIntValue("status") == 0) {

              val result = json.getJSONObject("result")
              val tcs = result.getJSONArray("tcs")
              if (tcs.size() > 0) {
                val tc = tcs.getJSONObject(0)
                groupid = StringUtil.fixnull(tc.getString("groupid"))
                aoiid_norm = StringUtil.fixnull(tc.getString("aoiid"))
                aoiunit_norm = StringUtil.fixnull(tc.getString("aoiUnit"))
                if (aoiunit_norm.nonEmpty) {
                  aoiunit_norm_null = false
                }

                """
                  |team 是TC模块，删掉不用
                  |""".stripMargin
                """
                  |dept 映射上级网点 名为：depart_code
                  |""".stripMargin
                depts = tcs.toArray.map(tc => {
                  try {
                    val tcbefore = tc.asInstanceOf[JSONObject].getString("dept").toUpperCase()
                    //val tcafter = getSSSZnoCode(zcMapBc.value, tcbefore)
                    tcbefore
                  } catch {
                    case e: Exception => {
                      null
                    }
                  }
                }).filter(_ != null).distinct
                try {
                  //group_group 拼接来源
                  standard = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").toArray()
                    .filter(d => {
                      d.asInstanceOf[JSONObject].getString("group") == groupid
                    })(0).asInstanceOf[JSONObject].getString("standardization")
                  standard = StringUtil.fixnull(standard)
                } catch {
                  case e: Exception => {
                    //e.printStackTrace(System.err)
                    //logger.error("【解析standardization失败】" + rst)
                  }
                }

                //team = if (teams.size > 0) Util.fixnull(teams(0)).toUpperCase() else ""
                dept = if (depts.size > 0) StringUtil.fixnull(depts(0)).toUpperCase() else ""
                //depart_code = if (dept != "") getSSSZnoCode(zcMapBc.value, dept) else ""
                //depart_code = dept


                //地址是否包含方位词
                val locationToken = token.map(t => {
                  if (addr.contains(t)) {
                    val addr_arr = addr.split(t)
                    if (addr_arr.length == 1) {
                      t+","+addr.indexOf(t)
                    } else if (addr_arr.length >= 2 && !((addr_arr(0).contains("(") || addr_arr(0).contains("（")) && (addr_arr(1).contains(")") || addr_arr(1).contains("）")))) {
                      t+","+addr.indexOf(t)
                    } else {
                      null
                    }
                  } else {
                    null
                  }
                }).filter(_ != null)

                var last_token = ""
                if (locationToken.size > 0) {
                  val max = locationToken.map(o => {
                    (o.split(",")(1).toInt, o.split(",")(0))
                  }).sorted.max
                  last_token = max._2
                }

                // """方位词 都保留"""
                //address是否包含距离量词，且模糊方位不在括号内
                //hasdist(落表)
                //获取距离量词+索引
                val distance_token_list = pattern_match(addr)
                val iter = distance_token_list.iterator()
                var cnt = 0
                while (iter.hasNext) {
                  val it = iter.next().toString
                  val t = it.split("###")(0)
                  if (addr.contains(t)) {
                    val addr_arr = addr.split(t)
                    if (addr_arr.length == 1) {
                      cnt += 1
                    } else if (addr_arr.length >= 2 && !((addr_arr(0).contains("(") || addr_arr(0).contains("（")) && (addr_arr(1).contains(")") || addr_arr(1).contains("）")))) {
                      cnt += 1
                    }
                  }
                }

                val hasdist = (distance_token_list.size() > 0) && (cnt > 0)

                //获取最后一个距离量词
                var dis_token = ""
                if (distance_token_list.size > 0) {
                  val max = distance_token_list.toString.replaceAll(" ", "").replaceAll("\\[|\\]", "").split(",").map(o => {
                    (o.split("###")(1).toInt, o.split("###")(0))
                  }).sorted.max
                  dis_token = max._2
                }


                //最后一个模糊方位词或者距离量词后是否
                //有文本hastext（落表）
                var last_distance_token = ""
                if (last_token.nonEmpty && dis_token.nonEmpty) {
                  val i1 = addr.indexOf(last_token)
                  val i2 = addr.indexOf(dis_token)
                  last_distance_token = if (i1 > i2) last_token else dis_token
                } else if (last_token.nonEmpty && dis_token.isEmpty) {
                  last_distance_token = last_token
                } else if (last_token.isEmpty && dis_token.nonEmpty) {
                  last_distance_token = dis_token
                } else {
                  last_distance_token = ""
                }
                var hastxt = false
                /*locationToken.foreach(d => {
                  if (addr.endsWith(d))
                    hastxt = false
                })*/
                if (!addr.endsWith(last_distance_token)) {
                  hastxt = true
                }

                var kxy = "".split(",").map(d => false).filter(d => d)
                var groupCnt = 0
                var group_group = ""
                //获取地址切词结果，比对方位词位置

                var level_gt_14 = false
                try {
                  val rst = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result")
                  val geocoder = rst.getJSONArray("geocoder").toArray().map(d => {
                    val t = d.asInstanceOf[JSONObject]
                    if (standardization == "") {
                      standardization = StringUtil.fixnull(t.getString("standardization"))
                    }
                    if (adcode_biaozhun == "") {
                      adcode_biaozhun = StringUtil.fixnull(t.getString("adcode"))
                    }
                    StringUtil.fixnull(t.getString("group"))
                  }).filter(_ != "")

                  groupCnt = geocoder.distinct.size
                  one_group = (groupCnt == 1).toString
                  group_group = geocoder.distinct.mkString("$")

                  splitinfo_chkn = StringUtil.fixnull(rst.getString("splitResult"))

                  val addrSplitInfo = rst.getJSONArray("addrSplitInfo").toArray().map(d => {
                    val t = d.asInstanceOf[JSONObject]
                    val name = t.getString("name")
                    val level = t.getIntValue("level")
                    val matchid = t.getIntValue("match")
                    val prop = t.getIntValue("prop")
                    (name, level, matchid, prop)
                  })
                  splitinfo = addrSplitInfo.sortBy(_._2).map(d => {
                    d._1 + "^" + d._2 + "^" + d._4 + "^" + d._3
                  }).mkString("|")

                  val arr = rst.getJSONArray("geocoder")
                  if (arr.size > 0) {
                    val json = arr.getJSONObject(0)
                    filter = JSONUtil.getJsonVal(json, "filter", "")
                    level = JSONUtil.getJsonVal(json, "level", "")
                  }

                  val splitInfoMatched = addrSplitInfo.filter(_._3 == 1) //匹配上了matchkye

                  level_gt_14 = addrSplitInfo.filter(obj => {
                    val strings = addr.split(last_distance_token)
                    var behand_txt = ""
                    if (strings.length > 1) {
                      behand_txt = strings(1)
                    }
                    behand_txt.nonEmpty && behand_txt.equals(obj._1) && obj._2 >= 14 && obj._2 <= 17
                  }).size == addrSplitInfo.size
                  //matchkey 在方位词之后？
                  /*kxy = splitInfoMatched.map(d => {
                    var behand = true
                    val l0 = addr.lastIndexOf(d._1) + d._1.length
                    locationToken.foreach(d => {
                      val l1 = addr.lastIndexOf(d) + d.length
                      if (l0 <= l1) {
                        behand = false
                      }
                    })
                    Array()
                    behand
                  }).filter(d => d).distinct*/
                  kxy = splitInfoMatched.map(d => {
                    var behand = true
                    val l0 = addr.lastIndexOf(d._1) + d._1.length
                    val l1 = addr.lastIndexOf(last_distance_token) + last_distance_token.length
                    if (last_distance_token.nonEmpty && l0 <= l1) {
                      behand = false
                    }
                    behand
                  }).filter(d => d).distinct
                } catch {
                  case e: Exception => {
                    logger.error("group_group 信息解析失败：" + e.getMessage + "\t" + e.getCause)
                    logger.error(rsp)
                  }
                }
                //
                //znocode=010PD,zno_code=010Z072,depart_code=010PD
                //znocode.nonEmpty && zno_code.equalsIgnoreCase(depart_code)
                if (zno_code.nonEmpty && zno_code == dept) {
                  dept_equal1 = true
                  if (aoiid_chkn.nonEmpty) {
                    if (aoiid_chkn.equals(aoiid_norm)) {
                      aoi_equal1 = true
                      val arr = Array("4", "5", "6", "7", "8")
                      if (arr.contains(adcode_shenbu) && !adcode_shenbu.equals(adcode_biaozhun)) {
                        adcode_chkn_is45678 = "1"
                        adcode_equal = false
                        //tag_dingwei = "here_1"
                        //tag = 0
                        //groupid = adcode_shenbu
                        aoiCheckTag = "updateAddrAoiCheck"
                      }

                      if (hasdist) {
                        if (hastxt) {
                          if (kxy.size > 0) {
                            tag = 0
                            //tag_dingwei = "here_2"
                          } else {
                            if (level_gt_14) {
                              tag = 0
                            } else {
                              tag = 1
                            }
                            //tag_dingwei = "here_3"
                          }
                        } else {
                          tag = 1
                          //tag_dingwei = "here_4"
                        }
                      } else {
                        if (locationToken.size > 0) {
                          if (hastxt) {
                            if (kxy.size > 0) {
                              tag = 0
                              //tag_dingwei = "here_2"
                            } else {
                              if (level_gt_14) {
                                tag = 0
                              } else {
                                tag = 1
                              }
                              //tag_dingwei = "here_3"
                            }
                          } else {
                            tag = 1
                            //tag_dingwei = "here_4"
                          }
                        } else {
                          tag = 0
                          //tag_dingwei = "here_5"
                        }
                      }
                    } else {
                      tag = 1
                      //tag_dingwei = "here_6"
                    }
                  } else if (aoiid_norm.nonEmpty) {
                    aoiid_norm_no_empty = "1"
                    if (groupCnt == 1) {
                      tag = 0
                      //tag_dingwei = "here_7"
                    } else {
                      tag = 1
                      //tag_dingwei = "here_8"
                    }
                  } else {
                    tag = 0
                    //tag_dingwei = "here_9"
                  }

                } else {
                  tag = 1
                  //tag_dingwei = "here_10"
                }

                //增加aoi单元区域验证
                if (tag == 0) {
                  if (aoiunit_chkn.isEmpty) {
                    flag = "0"
                  } else if (aoiunit_norm.isEmpty) {
                    //调取接口将审补AOI单元ID aoiunit_chkn赋值给标准地址aoiunit_norm（aoiunit_fix 修改是否成功 落表）
                    //city_code: String, zno_code: String, groupid: String, aoiId_norm: String, aoiunit_chkn: String
                    /*val resultObject = updateNormAddrTcZc(cityCode, zno_code, groupid, aoiid_norm,aoiunit_chkn)
                    if (resultObject != null) {
                      val success = JSONUtil.getJsonVal(resultObject, "success", "")
                      val message1 = JSONUtil.getJsonVal(resultObject, "message", "")
                      if (success == "true" || success == "True") {
                        aoiunit_fix = "success"
                        flag = "0"
                      } else {
                        aoiunit_fix = message1
                        flag = "1"
                      }
                    } else {
                      aoiunit_fix = "null"

                    }*/
                    flag = "1"
                  } else if (aoiunit_chkn.equals(aoiunit_norm)) {
                    flag = "0"
                    aoiunit_equal1 = true
                  } else {
                    flag = "1"
                  }
                }


                var updateAddrAoiCheckResp = ""
                /*if(aoiCheckTag == "updateAddrAoiCheck"){
                  var groupid1 = "[" + groupid + "]"
                  if(!StringUtils.isEmpty(groupid1)){
                    val addresses = JSON.parseArray(groupid1)
                    if(addresses!=null && addresses.size() > 0){
                      val json = updateAddrAoiCheck(cityCode,addresses,adcode_biaozhun)
                      updateAddrAoiCheckResp = json.toJSONString
                    }
                  }
                }*/

                var hprsp = null: JSONObject
                var recog_hp = "-1"
                var dept_equal2 = false
                var aoi_equal2 = false
                var aoiunit_equal2 = false
                var aoiunit_chkn_null = true
                if (!aoiunit_chkn.isEmpty) {
                  aoiunit_chkn_null = false
                }
                //normhp 验证
                if (tag == 0 && flag == "0") {
                  val url = s"""http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=${URLEncoder.encode(addr, "utf8")}&city=$cityCode&ak=0c3cd2c65820417d970b514122f16a1c&opt=normhpdetail"""

                  s"""
                     |{
                     |	"status": 0,
                     |	"result": {
                     |		"src": "hpdetail",
                     |		"count": 1,
                     |		"tcs": [{
                     |			"src": "normhp",
                     |			"flag": 1,
                     |			"dept": "711E",
                     |			"groupid": "DA6787E8A52711E8B3130894EF519FCA",
                     |			"aoicode": "711E000313",
                     |			"aoiid": "944409A5D7B9400EB04DA565985B40B2"
                     |		}],
                     |		"other": {
                     |			"normresp": {
                     |				"success": true,
                     |				"errorCode": 0,
                     |				"result": {
                     |					"status": 0,
                     |					"count": 3,
                     |					"geocoder": [{
                     |						"floor": "0",
                     |						"adcode": 420704,
                     |						"filter": 2,
                     |						"group": "DA9A9B4CA52711E8B3130894EF519FCA",
                     |						"name": "湖北省鄂州市鄂城区市政府",
                     |						"x": 114.920887,
                     |						"y": 30.398043,
                     |						"standardization": "湖北省鄂州市鄂城区滨湖西路市政府",
                     |						"score": 1,
                     |						"level": "GL_POI",
                     |						"mainid": "298496",
                     |						"poi_typecode": "130100",
                     |						"id": "A98935FEA52711E891F70894EF519FCA",
                     |						"sflag": 0,
                     |						"key": "4"
                     |					}, {
                     |						"floor": "0",
                     |						"adcode": 420704,
                     |						"filter": 2,
                     |						"group": "58DE8EE4A5F211E8B6350894EF519FCA",
                     |						"name": "湖北省鄂州市鄂城区市政府",
                     |						"x": 114.891887,
                     |						"y": 30.389043,
                     |						"standardization": "湖北省鄂州市鄂城区凤凰街道滨湖北路特1号市政府办公大楼",
                     |						"score": 1,
                     |						"level": "GL_POI",
                     |						"mainid": "344018",
                     |						"poi_typecode": "130100",
                     |						"id": "3DF38F1CA5F211E899D80894EF519FCA",
                     |						"sflag": 0,
                     |						"key": "4"
                     |					}, {
                     |						"floor": "0",
                     |						"adcode": 420704,
                     |						"filter": 2,
                     |						"group": "DA6787E8A52711E8B3130894EF519FCA",
                     |						"name": "湖北省鄂州市鄂城区市政府",
                     |						"x": 114.894887,
                     |						"y": 30.393043,
                     |						"standardization": "湖北省鄂州市鄂城区凤凰街道滨湖北路市政府",
                     |						"score": 1,
                     |						"level": "GL_POI",
                     |						"mainid": "363920",
                     |						"poi_typecode": "130100",
                     |						"id": "A989212CA52711E891F70894EF519FCA",
                     |						"sflag": 0,
                     |						"key": "4"
                     |					}],
                     |					"source": "ezhou",
                     |					"splitResult": "湖北省^11,鄂州市^12,鄂城区^13,滨海阔天空总店^213,市政府^313,对面^118,湖北路^29,22号^211;13",
                     |					"splitType": 0,
                     |					"addrSplitInfo": [{
                     |						"match": "1",
                     |						"prop": "1",
                     |						"level": 1,
                     |						"name": "湖北省"
                     |					}, {
                     |						"match": "1",
                     |						"prop": "1",
                     |						"level": 2,
                     |						"name": "鄂州市"
                     |					}, {
                     |						"match": "1",
                     |						"prop": "1",
                     |						"level": 3,
                     |						"name": "鄂城区"
                     |					}, {
                     |						"match": "0",
                     |						"prop": "2",
                     |						"level": 13,
                     |						"name": "滨海阔天空总店"
                     |					}, {
                     |						"match": "1",
                     |						"prop": "3",
                     |						"level": 13,
                     |						"name": "市政府"
                     |					}, {
                     |						"match": "0",
                     |						"prop": "1",
                     |						"level": 18,
                     |						"name": "对面"
                     |					}, {
                     |						"match": "1",
                     |						"prop": "2",
                     |						"level": 9,
                     |						"name": "湖北路"
                     |					}, {
                     |						"match": "0",
                     |						"prop": "2",
                     |						"level": 11,
                     |						"name": "22号"
                     |					}],
                     |					"guid": "108FAF2A-7F55-465B-A8F7-83C9917D32C0"
                     |				}
                     |			},
                     |			"arg": {
                     |				"createTime": 1606802826308,
                     |				"ak": "0c3cd2c65820417d970b514122f16a1c",
                     |				"remoteIp": "10.220.21.77",
                     |				"url": "http://nginxwa/atdispatch/api?address=%E6%B9%96%E5%8C%97%E7%9C%81%E9%84%82%E5%B7%9E%E5%B8%82%E9%84%82%E5%9F%8E%E5%8C%BA%E6%BB%A8%E6%B5%B7%E9%98%94%E5%A4%A9%E7%A9%BA%E6%80%BB%E5%BA%97%E5%B8%82%E6%94%BF%E5%BA%9C%E5%AF%B9%E9%9D%A2%E6%B9%96%E5%8C%97%E8%B7%AF22%E5%8F%B7&city=711&ak=0c3cd2c65820417d970b514122f16a1c&opt=hpdetail",
                     |				"city": "711",
                     |				"opt": "hpdetail",
                     |				"q": "0",
                     |				"address": "湖北省鄂州市鄂城区滨海阔天空总店市政府对面湖北路22号",
                     |				"adcode": "420700",
                     |				"originalAddress": "湖北省鄂州市鄂城区滨海阔天空总店市政府对面湖北路22号",
                     |				"fullAddress": "湖北省鄂州市鄂城区滨海阔天空总店市政府对面湖北路22号"
                     |			},
                     |			"hpcacheresp": {
                     |				"success": true,
                     |				"errorCode": 0,
                     |				"result": [{
                     |					"citycode": "711",
                     |					"groupid": "DA9A9B4CA52711E8B3130894EF519FCA",
                     |					"result": [{
                     |						"hp": "市政府对面安置楼",
                     |						"dept": "711E",
                     |						"aoiId": "7C0E429C3B4349FB88708B1F29DD06EA",
                     |						"aoiCode": "711E000220"
                     |					}]
                     |				}, {
                     |					"citycode": "711",
                     |					"groupid": "58DE8EE4A5F211E8B6350894EF519FCA",
                     |					"result": null
                     |				}, {
                     |					"citycode": "711",
                     |					"groupid": "DA6787E8A52711E8B3130894EF519FCA",
                     |					"result": [{
                     |						"hp": "市政府对面",
                     |						"dept": "711E",
                     |						"aoiId": "944409A5D7B9400EB04DA565985B40B2",
                     |						"aoiCode": "711E000313"
                     |					}]
                     |				}]
                     |			},
                     |			"city": "711",
                     |			"adcode": "420700",
                     |			"groupid": "DA6787E8A52711E8B3130894EF519FCA"
                     |		}
                     |	}
                     |}
                     |""".stripMargin

                  hprsp = HttpClientUtil.getJsonByGet(url, 5)
                  val json = hprsp
                  val result = json.getJSONObject("result")
                  val tcs = result.getJSONArray("tcs")


                  if (tcs.size() > 0) {
                    val tc = tcs.getJSONObject(0)
                    tcs_src = StringUtil.fixnull(tc.getString("src"))
                    dept_hp = StringUtil.fixnull(tc.getString("dept"))
                    //depart_code_hp = getSSSZnoCode(zcMapBc.value, depart_code_hp)
                    aoiid_hp = StringUtil.fixnull(tc.getString("aoiid"))
                    aoiunit_hp = StringUtil.fixnull(tc.getString("aoiUnit"))
                  }

                  if (tcs_src == "normhp") {
                    recog_hp = "1"
                    tag1 = 0
                    if (aoiid_chkn != "") {
                      if (zno_code == dept_hp) {
                        dept_equal2 = true
                      }
                      if (aoiid_chkn == aoiid_hp) {
                        aoi_equal2 = true
                      }
                      if (zno_code == dept_hp && aoiid_chkn == aoiid_hp) {
                        //tag2 = 0
                        if (!aoiunit_chkn.isEmpty) {
                          if (aoiunit_chkn.equals(aoiunit_hp)) {
                            aoiunit_equal2 = true
                            tag2 = 0
                          } else {
                            tag2 = 1
                          }
                        } else {
                          tag2 = 0
                        }
                      } else {
                        tag2 = 1
                      }
                    } else {
                      tag2 = if (zno_code != "" && zno_code == dept_hp) 0 else 1
                    }
                  } else {
                    recog_hp = "0"
                    tag1 = 1
                    tag2 = 0
                  }
                }

                //redis验证，下线
                if (tag2 == 0) {
                  if (tag1 == 0) {
                    //下线 进行下线并将下线结果赋给Result，action=0
                    action = 0

                    //val json = addressOffline(cityCode, addr, dt, aoiid_norm)
                    val json = new JSONObject()
                    action_result = JSONUtil.getJsonVal(json, "ret", "1").toInt
                    message = JSONUtil.getJsonVal(json, "rst", "")
                    //action_result = addressOffline(cityCode, addr, dt, aoiid_norm)
                  } else {
                    val p = URLEncoder.encode(s"""{"query":[{"city":"$cityCode","groupid":"$groupid"}]}""", "utf8")
                    //var redisUrl = s"""http://gis-int.int.sfdc.com.cn:1080/atalter/team/bygroup?ak=3eb300d2e06947f7945cd02530a32fd2&p=$p"""
                    //var redisUrl = s"""http://gis-int.int.sfdc.com.cn:1080/atalter/team/bygroup?ak=3eb300d2e06947f7945cd02530a32fd2&p=$p"""
                    var rsp = null: JSONObject
                    s"""
                       |{
                       |  "status": 0,
                       |  "result": [
                       |    {
                       |      "city": "711",
                       |      "groupid": "46672EF67A5811EAACD440EEDD0EF9F6",
                       |      "tcresult": {
                       |        "status": 0,
                       |        "result": [
                       |          {
                       |            "dept": "711D",
                       |            "tc": "711D010",
                       |            "notc": "0",
                       |            "aoiId": "0F240F4873F24049A021DE84ED407AD0",
                       |            "aoiCode": "711D000029",
                       |            "aoiSrc": "S100",
                       |            "aoiTC": [
                       |              {
                       |                "dept": "711D",
                       |                "tc": "711D010"
                       |              }
                       |            ]
                       |          }
                       |        ]
                       |      }
                       |    }
                       |  ]
                       |}
                       |""".stripMargin
                    try {
                      //rsp = atdispatch(addr,cityCode,"norm")
                      //rsp = HttpClientUtil.getJsonByGet(redisUrl, 5)
                      /*if (rsp == null) {
                        val pd = s"""{"query":[{"city":"$cityCode","groupid":"$groupid"}]}"""
                        redisUrl = "http://gis-int.int.sfdc.com.cn:1080/atalter/team/bygroup?ak=3eb300d2e06947f7945cd02530a32fd2"
                        rsp = HttpClientUtil.tryPost(redisUrl, pd, 5)
                      }*/

                      var tcs = new JSONArray()
                      rsp = atdispatch(addr.replaceAll("#", ""), cityCode, "norm")
                      if (rsp != null) {
                        val resultObject_norm2 = rsp.getJSONObject("result")
                        if (resultObject_norm2 != null) {
                          tcs = resultObject_norm2.getJSONArray("tcs")
                          if (tcs != null && tcs.size() > 0) {
                            val tcs0 = tcs.getJSONObject(0)
                            if (tcs0 != null) {
                              group_prod = tcs0.getString("groupid")
                              dept_prod = tcs0.getString("dept")
                              aoiid_prod = tcs0.getString("aoiid")
                              aoiUnit_prod = tcs0.getString("aoiUnit")
                            }
                          }
                        }
                      }
                      /*val json = rsp
                      val results = json.getJSONArray("result").getJSONObject(0).getJSONObject("tcresult").getJSONArray("result")
                      val result = results.getJSONObject(0)
                      val redisAoiid = StringUtil.fixnull(result.getString("aoiId"))
                      var redisDept = StringUtil.fixnull(result.getString("dept"))
                      if (tmpZcMap.containsKey(redisDept)) {
                        redisDept = tmpZcMap.get(redisDept)
                      } else {
                        redisDept = ""
                      }*/
                      if (dept != "" && dept == dept_prod) {
                        dept_equal3 = true
                      }
                      if (aoiid_norm == aoiid_prod) {
                        aoi_equal3 = true
                      }
                      if (dept != "" && dept == dept_prod && aoiid_norm == aoiid_prod) {
                        val aoiUnitArr = tcs.toArray().map(d => {
                          val t = d.asInstanceOf[JSONObject]
                          if (t.containsKey("aoiUnit"))
                            StringUtil.fixnull(t.getString("aoiUnit"))
                          else ""
                        }).filter(_ != "")

                        if (aoiunit_norm.isEmpty) {
                          //下线
                          action = 0
                          //action_result = addressOffline(cityCode, addr, dt, aoiid_norm)
                          //val json = addressOffline(cityCode, addr, dt, aoiid_norm)
                          val json = new JSONObject()
                          action_result = JSONUtil.getJsonVal(json, "ret", "1").toInt
                          message = JSONUtil.getJsonVal(json, "rst", "")
                        } else if (aoiUnitArr.size == 1) {
                          aoiunit_redis = aoiUnitArr(0)
                          if (aoiunit_redis == aoiunit_norm) {
                            aoiunit_equal3 = "1"
                            //下线
                            action = 0
                            //action_result = addressOffline(cityCode, addr, dt, aoiid_norm)
                            //val json = addressOffline(cityCode, addr, dt, aoiid_norm)
                            val json = new JSONObject()
                            action_result = JSONUtil.getJsonVal(json, "ret", "1").toInt
                            message = JSONUtil.getJsonVal(json, "rst", "")
                          } else {
                            action = 1
                          }
                        } else if (aoiUnitArr.contains(aoiunit_norm)) {
                          aoiunit_equal3 = "2"
                          aoiunit_redis = aoiunit_norm
                          //下线
                          action = 0
                          //action_result = addressOffline(cityCode, addr, dt, aoiid_norm)
                          //val json = addressOffline(cityCode, addr, dt, aoiid_norm)
                          val json = new JSONObject()
                          action_result = JSONUtil.getJsonVal(json, "ret", "1").toInt
                          message = JSONUtil.getJsonVal(json, "rst", "")
                        } else {
                          action = 1
                        }
                      } else {
                        action = 1
                      }

                    } catch {
                      case e: Exception => {
                        //logger.error(s"【REQ】$redisUrl")
                        logger.error(s"【RSP】$rsp")
                      }
                    }
                  }
                }
                var tmpResp = ""
                if (rsp != null) {
                  tmpResp = rsp.toJSONString
                }
                var tmpHprsp = ""
                if (hprsp != null) {
                  tmpHprsp = hprsp.toJSONString
                }
                val detail = Detail(addr, cityCode, dt, zno_code, dept, dept_equal1,
                  aoiid_norm, aoiid_chkn, aoi_chkn_null, aoi_equal1, groupid, group_group, standard,
                  keyword, locationToken.size > 0, hasdist, hastxt, level_gt_14, kxy.size > 0, tag, tcs_src, recog_hp, dept_hp, dept_equal2, aoiid_hp, aoi_equal2, aoiunit_equal2, tag1, tag2
                  , splitinfo, splitinfo_chkn, action, action_result, one_group, tmpResp, tmpHprsp, aoiunit_chkn, aoiunit_chkn_null, aoiunit_equal1, group_prod, dept_prod, dept_equal3
                  , aoiid_prod, aoi_equal3, aoiunit_norm, aoiunit_hp, aoiUnit_prod, aoiunit_equal3, "", flag
                  , aoiCheckTag, updateAddrAoiCheckResp, adcode_shenbu, adcode_biaozhun, adcode_chkn_is45678, adcode_equal, dayid, message, dayid, action_flag, filter, level, chknid,aoiunit_norm_null,aoiunit_fix)

                //Detail(addr, cityCode, znocode, dt, depart_code, group_group, standardization, keyword,hasloc=locationToken.size>0,hastxt,isbehind = kxy.size>0, tag,tag1,tag2, splitinfo, action,action_result,aoi,aoiid,one_group,rsp,hprsp)

                sleep(t0)
                detail
              } else {
                sleep(t0)
                null
              }
            } else {
              logger.error("【REQ】" + url)
              logger.error("【RSP】" + rsp)
              if (rsp != null && rsp.toJSONString.contains("访问限制")) {
                Counter.sleep += 1
                Counter.overSpeed = true
              }
              sleep(t0)
              null
            }
          } else {
            logger.error("【REQ】" + url)
            logger.error("【RSP】" + rsp)
            sleep(t0)
            null
          }
        } catch {
          case e: Exception => {
            logger.error("【REQ】" + url)
            logger.error("【RSP】" + rsp)
            sleep(t0)
            null
          }
        }
      })
    }).filter(_ != null).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(s"detail1共：${detail1.count()}")

    val detail2 = rdd1.rdd.repartition(1200).filter(obj => {
      !"1".equals(StringUtil.fixnull(obj.getString(7)))
    }).mapPartitions(p => {
      //限制了每分钟访问量:6000, 每秒访问量100,【100cpu】每cpu每秒访问量1
      Counter.speedLimit = b_speedLimit.value

      def sleep(t0: Long): Unit = {
        Counter.count(t0)
      }

      p.map(f = d => {
        val t0 = new Date().getTime
        val addr = StringUtil.fixnull(d.getString(0))
        val zno_code = StringUtil.fixnull(d.getString(1)).toUpperCase()
        val aoiid_chkn = StringUtil.fixnull(d.getString(2)).toUpperCase()
        //val dt = StringUtil.fixnull(d.getString(3))
        val dt = d.getInt(3).toString
        val keyword = StringUtil.fixnull(d.getString(4))
        val aoiunit_chkn = StringUtil.fixnull(d.getString(5))
        val adcode_shenbu = StringUtil.fixnull(d.getString(6))
        val action_flag = StringUtil.fixnull(d.getString(7))
        val chknid = StringUtil.fixnull(d.getString(8))
        var aoiunit_norm = ""
        var aoiunit_hp = ""
        var aoiunit_redis = ""
        var flag = ""
        var groupid = ""
        var aoiid_norm = ""
        var standard = ""
        var dept = ""


        var tag = -1
        var tag1 = -1
        var tag2 = -1
        var action = -1
        var action_result = -1
        var aoiCheckTag = ""


        var adcode_biaozhun = ""
        var splitinfo = ""
        var one_group = "false"

        var message = ""


        try {
          action = 0
          //action_result = addressOffline(cityCode, addr, dt, aoiid_norm)
          //val json = addressOffline(cityCode, addr, dt, aoiid_norm)
          val json = new JSONObject()
          action_result = JSONUtil.getJsonVal(json, "ret", "1").toInt
          message = JSONUtil.getJsonVal(json, "rst", "")

          val detail = Detail(addr, cityCode, dt, zno_code, dept, false,
            aoiid_norm, aoiid_chkn, false, false, groupid, "", standard,
            keyword, false, false, false, false, false, tag, "", "", "", false, "", false, false, tag1, tag2
            , splitinfo, "", action, action_result, one_group, "", "", aoiunit_chkn, false, false, "", "", false
            , "", false, aoiunit_norm, aoiunit_hp, "", "", "", flag
            , aoiCheckTag, "", adcode_shenbu, adcode_biaozhun, "", false, dayid, message, dayid, action_flag, "", "", chknid,true,"")
          detail
        } catch {
          case e: Exception => {
            sleep(t0)
            null
          }
        }
      })
    }).filter(_ != null).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(s"detail2共：${detail2.count()}")

    val detail = detail1.union(detail2).repartition(10).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(s"detail日志信息打印:")
    detail.take(2).foreach(println(_))

    val cnt = detail.count()
    logger.error(s"【$cityCode】容灾跑数结果记录数:" + cnt)

    detail1.unpersist()
    detail2.unpersist()

    val tag0 = detail.filter(_.tag == 0).count()
    logger.error(s"【$cityCode】tag=0 记录数:$tag0，占比：${tag0.toDouble / cnt.toDouble * 100}")

    val tag1 = detail.filter(_.tag == 1).count()
    logger.error(s"【$cityCode 】tag=1 记录数:$tag1，占比：${tag1.toDouble / cnt.toDouble * 100}")

    val aoi_check_tag_cnt = detail.filter(_.aoi_check_tag == "updateAddrAoiCheck").count()
    logger.error(s"【$cityCode 】aoi_check_tag=updateAddrAoiCheck 记录数:$aoi_check_tag_cnt")
    import sparkSession.implicits._
    val tmpViewName = "tmp" + cityCode + System.currentTimeMillis()
    detail.toDF().createOrReplaceTempView(tmpViewName)
    //val sql = s"insert overwrite table dm_gis.chkn_etl_v2 partition(inc_day='${dayid}',city_code='${cityCode}') " +
    //val sql = s"insert overwrite table dm_gis.chkn_etl_v3 partition(inc_day='${dayid}',city_code='${cityCode}') " +
    val sql = s"insert overwrite table dm_gis.chkn_etl_v3_test_20230410 partition(inc_day='${dayid}',city_code='${cityCode}',batch_no='5') " +
      s" select * from ${tmpViewName}  "
    logger.error(sql)
    sparkSession.sql(sql)
    detail.unpersist()
    src.unpersist()
  }

  /*def pattern_match(str: String) = {
    val pattern = Pattern.compile("(([0-9]{0,5})|([一二两三四五六七八九十百千]{0,5})|(几{0,1})|(多{0,1}))((米)|(千米)|(公里))")
    var res = false
    val matcher = pattern.matcher(str)
    val list = new util.ArrayList[String]()
    while (matcher.find()) {
      list.add(matcher.group())
    }
    if (list.size() >= 1) {
      res = true
    }
    res
  }*/
  def pattern_match(str: String) = {
    val pattern = Pattern.compile("(([0-9]{0,5})|([一二两三四五六七八九十百千]{0,5})|(几{0,1})|(多{0,1}))((米)|(千米)|(公里))")
    var res = false
    val matcher = pattern.matcher(str)
    val list = new util.ArrayList[String]()
    while (matcher.find()) {
      list.add(matcher.group() + "###" + str.indexOf(matcher.group()))
    }
    list
  }


  def addressOffline(cityCode: String, address: String, tp: String, aoi: String): JSONObject = {
    val res = new JSONObject()
    s"""
       |{"operSource":"sb_delete","operUserName":"01386736",
       |"addressDel":[{"address":"湖北省鄂州市鄂城区凤凰街道永利花园9栋","cityCode":"711","type":2}],
       |"ak":"7577390e76cc40b6ad6542640edd9d84",
       |"nomarAddr":0}
       |{"code":200,"subCode":"","success":true,"message":""}
       |""".stripMargin

    val url = s"http://gis-cms-bg.sf-express.com/cms/api/address/batchDelRgsbAddr"
    val json = JSON.parseObject("{}")
    json.put("ak", "7577390e76cc40b6ad6542640edd9d84")
    json.put("operSource", "sb_delete")
    json.put("operUserName", "01386736")

    val addrs = JSON.parseArray("[]")
    val ad = JSON.parseObject("{}")
    ad.put("cityCode", cityCode)
    ad.put("address", address)
    ad.put("type", tp.toInt)
    //添加不需要再次规范化的标识，否则可能会造成二次规范化，导致地址不可查找
    ad.put("nomarAddr", 0)
    addrs.add(ad)
    json.put("addressDel", addrs)

    val postdata = json.toString()
    var rst = null: JSONObject
    var ret = -1
    try {
      // TODO: free this
      rst = HttpClientUtil.tryPost(url, postdata, 10)
      ret = if (rst.getBoolean("success")) 0 else 1 //0 成功，1失败
    } catch {
      case e: Exception => {
        logger.error(s"【REQ】$url\t${json.toJSONString}")
        logger.error(s"【RSP】$rst")
        ret = 1
      }
    }
    res.put("rst", rst.toJSONString)
    res.put("ret", ret)
    res
  }

  def updateNormAddrTcZc(city_code: String, zno_code: String, groupid: String, aoiid_norm: String, aoiunit_chkn: String): JSONObject = {
    var jsonObject: JSONObject = null
    val url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/updateNormAddrTcZc"
    val json = new JSONObject()
    json.put("ak", "3eb300d2e06947f7945cd02530a32fd2")
    json.put("operSource", "NORM")
    json.put("operUserName", "01427169")
    val addressUpdate = new JSONObject()
    addressUpdate.put("cityCode", city_code)
    addressUpdate.put("addressId", groupid)
    addressUpdate.put("znoCode", zno_code)
    addressUpdate.put("aoiId", aoiid_norm)
    addressUpdate.put("unitId", aoiunit_chkn)
    json.put("addressUpdate", addressUpdate)

    breakable(
      for (i <- 0.until(5)) {
        try {
          jsonObject = com.sf.gis.scala.utils.HttpClientUtil.getJsonByPostJson(url, json.toJSONString)
          Thread.sleep(100)
          if (jsonObject != null) {
            val code = jsonObject.getString("success")
            if ("true".equalsIgnoreCase(code)) break
            else Thread.sleep(100)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => //logger.error(">>>访问updateNormAddrTcZc：url" + i + "=" + url + ", json=" + json + ", result=" + jsonObject)
        }
      }
    )
    jsonObject
  }

  def atdispatch(address: String, city: String, opt: String): JSONObject = {
    var jsonObject: JSONObject = null
    val url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=6bc8b69cc19b4882b9e40b554fd8fd93&opt=%s&address=%s&city=%s"
      .format(opt, address, city)
    breakable(
      for (i <- 0.until(5)) {
        try {
          jsonObject = HttpClientUtil.getJsonByGet(url)
          logger.error(">>>访问atdispatch：url=" + url + ", json=" + jsonObject)
          Thread.sleep(350)
          if (jsonObject != null) {
            val status = jsonObject.getString("status")
            if ("0".equalsIgnoreCase(status)) break
            else Thread.sleep(350)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => logger.error(">>>访问atdispatch异常：" + e + ",第" + i + "次, url=" + url + ", json=" + jsonObject)
        }
      }
    )
    jsonObject
  }

  def updateAddrAoiCheck(cityCode: String, addresses: JSONArray, aoiCheckTag: String): JSONObject = {
    var jsonObject: JSONObject = null
    //val url = "http://gisasscmsbgintface-gis-ass-cms.dcn2.k8s.sfcloud.local:1080/cms/api/address/updateAddrAoiCheck"
    //val url = "http://gis-cms-bg.sit.sf-express.com/cms/api/address/updateAddrAoiCheck"
    val url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/updateAddrAoiCheck"
    val json = new JSONObject()
    json.put("cityCode", cityCode)
    json.put("aoiCheckTag", aoiCheckTag)
    json.put("addressIds", addresses)
    breakable(
      for (i <- 0.until(5)) {
        try {
          jsonObject = com.sf.gis.scala.utils.HttpClientUtil.getJsonByPostJson(url, json.toJSONString)
          //          logger.error(">>>访问updateAddrAoiCheck：url" + i + "=" + url + ", json="+json + ", result="+jsonObject)
          Thread.sleep(100)
          if (jsonObject != null) {
            val code = jsonObject.getString("code")
            if ("200".equalsIgnoreCase(code)) break
            else Thread.sleep(100)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => logger.error(">>>访问updateAddrAoiCheck：url" + i + "=" + url + ", json=" + json + ", result=" + jsonObject)
        }
      }
    )
    jsonObject
  }
}

