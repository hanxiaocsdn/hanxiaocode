package com.sf.gis.scala.oms_shou.pojo.arss;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/8.
 */
public class ArssReData  implements Serializable {
    private String sysOrderNo;
    private String result;
    private String orderNo;
    private String empCode;
    private OrderFrom orderFrom;

    public String getSysOrderNo() {
        return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public OrderFrom getOrderFrom() {
        return orderFrom;
    }

    public void setOrderFrom(OrderFrom orderFrom) {
        this.orderFrom = orderFrom;
    }
}
