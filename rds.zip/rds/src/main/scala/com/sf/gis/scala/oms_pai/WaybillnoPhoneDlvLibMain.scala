/*
package com.sf.gis.scala.oms_pai

import java.io.BufferedReader
import java.sql.Connection
import java.text.{DecimalFormat, SimpleDateFormat}
import java.util
import java.util.Date

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.DateUtil
import com.sf.gis.scala.oms_pai.start.JavaUtil
import com.sf.gis.scala.utils.{DbUtils, SortByList}
//import org.apache.hadoop.hbase.client._
//import org.apache.hadoop.hbase.util.Bytes
//import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01375125 on 2018/10/24.
 * 任务id:225333
 * 业务：01412980 潘宜鹏
 * 描述：给arss提供运单的回单网点，揽收网点，用于评估审补作业结果
 *
 */
object WaybillnoPhoneDlvLibMain {

  val appName: String = this.getClass.getName.replaceAll("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val javaUtil = new JavaUtil(3)
  //剔除妥投网点
  //  val reject_dept_array=Array("024CL")
  val reject_dept_array = Array("024CL", "852CCD", "852Q", "595ZPXA")
  //ZPXA
  /**
   * main方法
   *
   * @param args
   */
  def main(args: Array[String]): Unit = {
    //    println(getKeyStr("SF1122425568531"))
    //    var date = DateUtil.dateDelta(-5, "")
    //    val date = Util.dateDelta(-10,"")
    //    val date = "20190904"
    //    println(date)
    //    if (args.length >= 1) {
    val date = args(0)
    val pickUpDate = args(1)
    //    }
    //    println(date)
    //    println(getKeyStr("293345406048"))
    start(date, pickUpDate)

  }

  /**
   * 开始任务
   */
  def start(date: String, pickUpDate: String): Unit = {
    var spark: SparkSession = null

    //处理5天前的错分妥投工单数据yyyyMMdd

    //      incDay = "20181123"
    spark = Spark.getSparkSession(appName)
    //    logger.error(">>>处理"+incDay+"号妥投网点的工单------------start----------")
    val conn = DbUtils.getConnection(javaUtil)
    val cmsMap: Map[String, String] = getCmsData(conn)
    logger.error(">>>获取cms表的数据量：" + cmsMap.size)
    val xgOutList: ArrayBuffer[String] = getXiaogeOutList()
    logger.error(">>>获得免除小哥工号数据量:" + xgOutList.size)

    //跑单天的数据
    startOneStask(date, spark, cmsMap, xgOutList, pickUpDate)

    //跑多天的数据
    //    startBatchStask(spark,cmsMap:Map[String,String],xgOutList:ArrayBuffer[String])
    if (spark != null) spark.stop()
  }

  def queryFvpPickUpData(spark: SparkSession, incDay: String) = {
    val sql = s"select mainwaybillno,zonecode from ( select mainwaybillno,zonecode, row_number() over( partition by mainwaybillno order by barscantm desc ) as rank from ods_kafka_fvp.fvp_core_fact_route_op " +
      s" where inc_day = '$incDay' and opcode='5000' and mainwaybillno <> '' ) b where b.rank = 1 "
    logger.error(sql)
    //    val sql = s"select mainwaybillno,zonecode, from ods_kafka_fvp.fvp_core_fact_route " +
    //      s" where  inc_day ='$incDay' and opcode='5000'  and mainwaybillno <> ''  "
    //    logger.error(sql)
    val dataRdd = spark.sql(sql).rdd.map(obj => (obj.getString(0), obj.getString(1))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("opcode=5000的数据量:" + dataRdd.count())
    dataRdd.take(2).foreach(obj => {
      logger.error(obj._1 + "," + obj._2)
    })
    dataRdd
  }

  def handlePickUpData(incDay: String, spark: SparkSession) = {
    logger.error("获取opcode为5000的数据")
    val fvpPickUpDataRdd = queryFvpPickUpData(spark, incDay)
    logger.error("写入hbase")
    //    storeWaybillPickUpInfoToHbase(fvpPickUpDataRdd)
    storeWaybillPickUpInfoToHiveForHbase(spark, fvpPickUpDataRdd, incDay)
  }

  /**
   * 跑单天的数据
   *
   * @param incDay
   * spark    */
  def startOneStask(incDay: String, spark: SparkSession, cmsMap: Map[String, String],
                    xgOutList: ArrayBuffer[String],
                    pickUpDate: String): Unit = {
    //新增揽收网点数据
    handlePickUpData(pickUpDate, spark)

    handleTask(incDay, spark: SparkSession, cmsMap: Map[String, String], xgOutList: ArrayBuffer[String])
  }

  //  /**
  //   *
  //   * 跑单天的数据
  //   * spark    */
  //  def startBatchStask(spark: SparkSession, cmsMap: Map[String, String], xgOutList: ArrayBuffer[String]): Unit = {
  //    //    val dayArray = Util.getBetweenDatesStr("20190401","02190415","")
  //    val dayArray = Util.getTwoDatesStr("20190412", "20190418", "")
  //    println("-------------处理的日期：" + dayArray.mkString(","))
  //    for (incDay <- dayArray) {
  //      handleTask(incDay, spark: SparkSession, cmsMap: Map[String, String], xgOutList: ArrayBuffer[String])
  //    }
  //  }


  def getTtWayRdd(incDay: String, spark: SparkSession): RDD[(String, JSONObject)] = {
    val selectTtSql =
      s"""
         |select inc_day,dest_dist_code,waybill_no,'',consignee_mobile,consignee_addr_decrypt consignee_addr,'','',''
         |from dm_gis.dwd_waybill_info_dtl_di where inc_day ='$incDay'
         |""".stripMargin
    println("selectDlvSql:" + selectTtSql)
    val omsRdd = spark.sql(selectTtSql).rdd.map(row => {
      val json = new JSONObject()
      json.put("req_date", row.getString(0))
      json.put("req_destcitycode", row.getString(1))
      val waybillno = row.getString(2)
      json.put("waybillno", waybillno)
      json.put("req_time", row.getString(3))
      json.put("req_addresseemobile", row.getString(4))
      json.put("req_addresseeaddr", row.getString(5))
      json.put("gis_to_sys_gisdeptcodeto", row.getString(6))
      json.put("gis_to_sys_sssdeptcodeto", row.getString(7))
      json.put("gis_to_sys_time", row.getString(8))
      json.put("type", "tt")
      (waybillno, json)
    })

    omsRdd
  }

  /**
   * 临时过滤妥投规则
   *
   * @param zno_code
   * @return
   */
  def reject_dlv_map(zno_code: String): Boolean = {
    zno_code.matches("^[0-9]+(FW|ZPW|ZPVA)+(.*)")
  }

  /**
   * 处理全部任务
   *
   * @param incDay
   * @param spark
   */
  def handleTask(incDay: String, spark: SparkSession, cmsMap: Map[String, String], xgOutList: ArrayBuffer[String]): Unit = {
    logger.error(">>>-----------------------开始处理" + incDay + "号妥投工单任务-----------------------------------")

    val omsLogRdd: RDD[(String, JSONObject)] = getOmsRdd(incDay, spark)
    //    logger.error(">>>获取"+incDay+" 号派件表中根据运单排重后的数据量:"+omsLogRdd.count())
    val ttWayRdd: RDD[(String, JSONObject)] = getTtWayRdd(incDay, spark)
    //    logger.error(">>>获取"+incDay+" 号运单宽表数据量:"+ttWayRdd.count())
    val omsRdd = omsLogRdd.union(ttWayRdd).reduceByKey((obj1, obj2) => {
      if ("gis".equals(obj1.getString("type"))) {
        obj1
      } else if ("gis".equals(obj2.getString("type"))) {
        obj2
      } else {
        obj1
      }
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>获取" + incDay + " 号数据表总数据量:" + omsRdd.count())

    logger.error(">>>获取妥投的数据")
    val dlvRdd: RDD[(String, JSONObject)] = getDlvRdd(incDay, spark).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>获取妥投的数据量:" + dlvRdd.count())
    dlvRdd.take(1).foreach(o => println(o))

    logger.error(">>>派件运单与妥投运单关联,然后映射网点")
    val resultRdd = omsRdd.leftOuterJoin(dlvRdd).map(obj => {
      val omsObj = obj._2._1
      val routeObj = obj._2._2
      if (routeObj.nonEmpty) {
        //能关联上妥投数据,并且妥投小哥不能在免除小哥工号表里面
        val routeJson = routeObj.get
        val couriercode = routeJson.getString("couriercode")
        if (couriercode != null && !couriercode.equals("null") && !xgOutList.contains(couriercode)) {
          val zno_code = routeJson.getString("zno_code")
          if (zno_code != null && !reject_dept_array.contains(zno_code) && cmsMap.contains(zno_code) && !reject_dlv_map(zno_code)) {
            val depart_code = cmsMap.apply(zno_code)
            routeJson.put("depart_code", depart_code)
          }
          omsObj.fluentPutAll(routeJson)
        }
      }
      omsObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>得到关联后的妥投工单数据量：" + resultRdd.count())
    resultRdd.take(1).foreach(o => println(o))
    dlvRdd.unpersist()
    omsRdd.unpersist()
    logger.error(">>>处理关联妥投后的数据...")
    handleDlvResultRdd(resultRdd: RDD[JSONObject], spark, incDay)

    logger.error(">>>妥投数据入库结束，释放缓存")

    logger.error("The end!")
  }

  /**
   * 处理得到的妥投后的数据
   *
   * @param resultRdd
   * @param spark
   * @param incDay
   */
  def handleDlvResultRdd(resultRdd: RDD[JSONObject], spark: SparkSession, incDay: String): Unit = {

    logger.error(">>>根据当天的妥投数据得到一个运单妥投的rdd，直接入hbase库")
    //    storeWaybillnoRddToHbase(resultRdd: RDD[JSONObject])
    storeWaybillnoRddToHiveForHbase(spark, resultRdd: RDD[JSONObject], incDay)
    logger.error(">>>妥投数据根据电话排重...")
    val phoneRdd = getPhoneRdd(resultRdd: RDD[JSONObject])

    logger.error(">>>把排重后电话库数据存到hive入库中...")
    storeDlvRddToHive(phoneRdd: RDD[JSONObject], spark, incDay)
    resultRdd.unpersist()
    logger.error(">>>查询妥投工单电话库15天的数据")
    val hisPhoneRdd = getHisHivePhoneRdd(spark, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //
    logger.error(">>>15天的电话库数据入hbase库数据量：" + hisPhoneRdd.count() + ",数据入hbase中...")
    //    storeHisPhoneHbase(hisPhoneRdd)
    storeHisPhoneToHiveForHbase(spark, hisPhoneRdd, incDay)
    hisPhoneRdd.unpersist()
  }

  //  /**
  //   *
  //   * @param phone30Rdd
  //   */
  //  def storeHisPhoneHbase(phone30Rdd: RDD[(String, JSONArray)]): Unit = {
  //    //    try {
  //    phone30Rdd.repartition(40).foreachPartition(rdd => {
  //      //获取table并设置参数
  //      val table = getTable(javaUtil.get("phone_table"))
  //      val putList = new util.ArrayList[Put]()
  //      rdd.foreach(obj => {
  //        val phone = obj._1
  //        val key = getKeyStr(phone)
  //        val jsonArray = obj._2
  //        val put = new Put(Bytes.toBytes(key))
  //        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("phone_value"), Bytes.toBytes(jsonArray.toString))
  //        putList.add(put)
  //        if (putList.size() >= 500) {
  //          try {
  //            table.put(putList)
  //          } catch {
  //            case e: Exception => logger.error(e)
  //          }
  //          putList.clear()
  //        }
  //      })
  //      if (putList.size() > 0) {
  //        try {
  //          table.put(putList)
  //        } catch {
  //          case e: Exception => logger.error(e)
  //        }
  //        putList.clear()
  //      }
  //      table.close()
  //      //        Thread.sleep(500)
  //    })
  //    //    } catch {
  //    //      case e: Exception => logger.error(">>>电话库数据入库异常：" + e)
  //    //    }
  //    logger.error(">>>解析数据入hbase库结束。")
  //    phone30Rdd.unpersist()
  //  }
  /**
   *
   * @param phone30Rdd
   */
  def storeHisPhoneToHiveForHbase(spark: SparkSession, phone30Rdd: RDD[(String, JSONArray)], incDay: String): Unit = {
    //    try {
    val retRdd = phone30Rdd.map(obj => {
      val phone = obj._1
      val key = getKeyStr(phone)
      val jsonArray = obj._2
      val ret = new JSONObject()
      ret.put("rowkey", key);
      ret.put("info_phone_value", jsonArray.toJSONString)
      ret
    })
    var columns = Array("rowkey", "info_phone_value")
    SparkWrite.save2HiveStaticRandom(spark, retRdd, columns, "dm_gis.dwd_gis_oms_phone_dlv_mid",
      Array(("inc_day", incDay)), 3200
    )
    logger.error(">>>解析数据入hive库结束（后续导入hbase）")
    phone30Rdd.unpersist()
  }

  /**
   * 把妥投当天的数据根据电话去重
   *
   * @param resultRdd
   * @return
   */
  def getPhoneRdd(resultRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val phoneRdd = resultRdd.map(json => {
      var key: String = null
      val phone = json.getString("req_addresseemobile")
      val req_time = json.getString("req_time")
      if (phone != null && phone.length > 6 && req_time != null) {
        key = phone
      }
      (key, json)
    }).filter(_._1 != null).groupByKey().flatMap(obj => {
      val iter: Iterable[JSONObject] = obj._2
      val list = new util.ArrayList[JSONObject]()
      for (json <- iter) list.add(json)
      val subList = SortByList.sortByReqTime(list, 5)
      subList.iterator()
    })
    phoneRdd
  }


  /**
   * 获取运单排重后派件表的数据
   *
   * @param incDay
   * @param spark
   * @return
   */
  def getOmsRdd(incDay: String, spark: SparkSession): RDD[(String, JSONObject)] = {
    val selectDlvSql =
      s"""
         |select inc_day,req_destcitycode,req_waybillno,req_time,req_addresseemobile,req_addresseeaddr,gis_to_sys_gisdeptcodeto,gis_to_sys_sssdeptcodeto,gis_to_sys_time
         |from
         |	(select inc_day,req_destcitycode,req_waybillno,req_time,req_addresseemobile,req_addresseeaddr,gis_to_sys_gisdeptcodeto,gis_to_sys_sssdeptcodeto,gis_to_sys_time,
         | row_number() over(partition BY req_waybillno order by req_time desc ) as rank from dm_gis.gis_rds_omsto
         | where inc_day ='$incDay'  and req_waybillno <> '')a where a.rank=1
       """.stripMargin

    //    val selectDlvSql =
    //    s"""
    //       |select inc_day,req_destcitycode,req_waybillno,req_time,req_addresseemobile,req_addresseeaddr,gis_to_sys_gisdeptcodeto,gis_to_sys_sssdeptcodeto,gis_to_sys_time
    //       |from dm_gis.gis_rds_omsto where inc_day ='$incDay'
    //       |""".stripMargin
    println("selectDlvSql:" + selectDlvSql)
    val omsRdd = spark.sql(selectDlvSql).rdd.map(row => {
      val json = new JSONObject()
      json.put("req_date", row.getString(0))
      json.put("req_destcitycode", row.getString(1))
      val waybillno = row.getString(2)
      json.put("waybillno", waybillno)
      json.put("req_time", row.getString(3))
      json.put("req_addresseemobile", row.getString(4))
      json.put("req_addresseeaddr", row.getString(5))
      json.put("gis_to_sys_gisdeptcodeto", row.getString(6))
      json.put("gis_to_sys_sssdeptcodeto", row.getString(7))
      json.put("gis_to_sys_time", row.getString(8))
      json.put("type", "gis")
      (waybillno, json)
    })

    omsRdd
  }


  /**
   * 获取妥投去掉转寄的数据
   *
   * @param incDay
   * @param spark
   * @return
   */
  def getDlvRdd(incDay: String, spark: SparkSession): RDD[(String, JSONObject)] = {
    val startDay = DateUtil.getDay(incDay, 0, "")
    val endDay = DateUtil.getDay(incDay, 4, "")
//    val fiveDayListStr = Array(DateUtil.getDay(incDay, 0, ""), DateUtil.getDay(incDay, 1, ""), DateUtil.getDay(incDay, 2, ""), DateUtil.getDay(incDay, 3, ""), DateUtil.getDay(incDay, 4, "")).mkString("'", "','", "'")
    val selectDlvSql =
      s"""
         |select * from
         |	(select inc_day,mainwaybillno,zonecode,couriercode,
         |	row_number() over (partition by mainwaybillno order by barscantm desc) as rank from ods_kafka_fvp.fvp_core_fact_route_op
         |	where inc_day between  '${startDay}' and '${endDay}' and opcode='80' and mainwaybillno <> '') b
         |where b.rank=1
        """.stripMargin
    val rejectSql =
      s"""
        |select mainwaybillno waybillno
        |      from ods_kafka_fvp.fvp_core_fact_route_op c
        |      where inc_day between  '${startDay}' and '${endDay}' and (opcode = '99'
        |      or (opcode = '33'  and staywhycode in ('14', '55', '9', '67'))
        |       or (opcode = '70' and staywhycode in ('14', '55', '9', '67'))
        |       or (opcode = '77' and staywhycode in ('14', '55', '103'))
        |       or opcode = '648')   group by mainwaybillno
        |""".stripMargin

    val joinSql =
      s"""
        | select inc_day,mainwaybillno,zonecode,couriercode from
        | (${selectDlvSql})t1 left join (${rejectSql}) t2 on t1.mainwaybillno = t2.waybillno
        | where t2.waybillno is null
        |""".stripMargin
    println("joinSql:" + joinSql)
    val dlvRdd = spark.sql(joinSql).rdd.map(row => {
      val dlv_body = new JSONObject()
      dlv_body.put("dlv_day", row.getString(0))
      val mainwaybillno = row.getString(1)
      dlv_body.put("waybillno", mainwaybillno)
      dlv_body.put("zno_code", row.getString(2))
      var couriercode = row.getString(3)
//      try {
//        //        couriercode = Integer.parseInt(couriercode).toString
//        //        import java.collec
//        //        couriercode = Long.valueo
//      } catch {
//        case e: Exception => logger.error(">>>转换员工工号异常：" + e + ",xiaogeNo:" + couriercode)
//      }
      dlv_body.put("couriercode", couriercode)
      (mainwaybillno, dlv_body)
    })
    dlvRdd
  }


  /*

    /**
      * 获得cms的数据
      * @param conn
      * @return
      */
    def getCmsData(conn:Connection): Map[String,String] ={
      val cms_sql =
        s"""
           |SELECT DISTINCT
           |	zno_code,
           |	depart_code,
           |	type_code
           |FROM
           |	st_sss_zno_depart
           |WHERE
           |	 type_code IN ('FB04-YWX','DB05-DB','DB05-DLD',	'DB05-SFZ','FB04-XMFB','DB05-XMDB')
         """.stripMargin

      logger.error(">>>cms_sql:"+cms_sql)
      val cmsList: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn,cms_sql,Array("zno_code","depart_code","type_code"))


      logger.error(">>>去除没有单元区域的网点和站点的映射...")
      var cmsMap = Map[String,String]()
      cmsList.foreach(row => {
        try {
          if (row != null) {
            val zno_code = row(0)
            val depart_code = row(1)
            val type_code = row(2)
            if (zno_code != null && depart_code != null && type_code != null) {
  //            if (type_code.equals("FB04-XMFB") || type_code.equals("DB05-XMDB")) {
                if (!type_code.equals("DB05-SFZ")) {//新逻辑1.18号邮件
                //该网点的单元区域是否为空
                val selectTcSql = String.format("select sch_code from st_sch where zno_code ='%s' AND `status` in(1,3)", zno_code)
                val resultSet = conn.createStatement().executeQuery(selectTcSql)
                //调用first判断是否有返回值,移动了光标,因此不需要next(),即可取值,否则查询时先执行while(resultSet.next()).
                if (resultSet.first()) {
                  cmsList -= row
                }
              } else {
                cmsMap += (zno_code -> depart_code)
              }

            }
          }
        } catch {
          case e:Exception =>logger.error(">>>去除没有单元区域的网点和站点的映射异常："+e)
        }

      })

      logger.error(">>>过滤后的cms表的数据个数:"+cmsList.length)
      cmsMap
    }
  */

  /**
   *
   * @return
   */
  def getCmsData(conn: Connection): Map[String, String] = {
    logger.error(">>>755深圳的用st_zno_depart这个表，其他城市用st_sss_zno_depart这个表")
    val cms755_sql =
      s"""
         |SELECT DISTINCT
         |	zno_code,depart_code,type_code
         |FROM
         |	st_zno_depart
         |WHERE
         |	 city_code = '755' and type_code IN ('FB04-YWX','DB05-DB','DB05-DLD', 'DB05-SFZ','FB04-XMFB','DB05-XMDB','DB05-YYZ','ZZC05-SJ','FB04-YWX','DB05-DB','DB05-DLD',	'DB05-SFZ','FB04-XMFB','DB05-XMDB')
       """.stripMargin
    logger.error(">>>cms755_sql:" + cms755_sql)
    val cmsOther_sql =
      s"""
         |SELECT DISTINCT
         |	zno_code,depart_code,type_code
         |FROM
         |	st_sss_zno_depart
         |WHERE
         |	 city_code != '755' and type_code IN ('FB04-YWX','DB05-DB','DB05-DLD', 'DB05-SFZ','FB04-XMFB','DB05-XMDB','DB05-YYZ','ZZC05-SJ','FB04-YWX','DB05-DB','DB05-DLD', 'DB05-SFZ','FB04-XMFB','DB05-XMDB')
       """.stripMargin
    logger.error(">>>cmsOther_sql:" + cmsOther_sql)

    val cmsLists755: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, cms755_sql, Array("zno_code", "depart_code", "type_code"))
    val cmsListsOther: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, cmsOther_sql, Array("zno_code", "depart_code", "type_code"))
    val cmsLists = cmsLists755 ++= cmsListsOther

    logger.error(">>>sch_sql:" + "select sch_code from st_sch where zno_code ='%s' AND `status` in(1,3)")

    //    cmsList.foreach(o=>{print(o.mkString(","))})
    var cmsMap = Map[String, String]()
    cmsLists.foreach(row => {
      try {
        if (row != null) {
          val zno_code = row(0)
          val depart_code = row(1)
          val type_code = row(2)
          if (zno_code != null && depart_code != null && type_code != null) {
            //            if (type_code.equals("FB04-XMFB") || type_code.equals("DB05-XMDB")) {
            //            if (!type_code.equals("DB05-SFZ")) {//新逻辑
            //            //该网点的单元区域是否为空,去掉这两种类型单元区域为空的数据
            //            val selectTcSql = String.format("select sch_code from st_sch where zno_code ='%s' AND `status` in(1,3)", zno_code)
            //              val resultSet = conn.createStatement().executeQuery(selectTcSql)
            //              //调用first判断是否有返回值,移动了光标,因此不需要next(),即可取值,否则查询时先执行while(resultSet.next()).
            //              if (resultSet.first()) {
            //                //说明该网点下面有单元区域，可以用该网点和站点映射
            //                cmsMap += (zno_code -> depart_code)
            //              }
            //            }else{
            cmsMap += (zno_code -> depart_code)
            //            }
          }
        }
      } catch {
        case e: Exception => logger.error(">>>去除没有单元区域的网点和站点的映射异常：" + e)
      }
    })
    cmsMap
  }


  /**
   * 把配置资源中的数据加载到内存中来
   *
   * @return
   */
  def getXiaogeOutList(): ArrayBuffer[String] = {
    val list = new ArrayBuffer[String]
    val buff: BufferedReader = javaUtil.readFile("conf/oms_pai/xiaogeno_out.csv")
    var line: String = null
    var flag = true
    while (flag) {
      line = buff.readLine()
      if (line == null) {
        flag = false
      } else {
        val arr = line.split(",")
        if (arr.length > 0) {
          var xiaogeNo = arr(0)
          try {
            xiaogeNo = Integer.parseInt(xiaogeNo).toString
          } catch {
            case e: Exception => logger.error(">>>转换员工工号异常：" + e + ",xiaogeNo:" + xiaogeNo)
          }

          list += xiaogeNo
        }
      }

    }
    buff.close()
    list
  }


  /**
   * 查询30天的电话库数据
   *
   * @param spark
   * @param incDay
   * @return
   */
  def getHisHivePhoneRdd(spark: SparkSession, incDay: String): RDD[(String, JSONArray)] = {
    val before30Day = DateUtil.getDay(incDay, -15, "")
    val select30PhoneSql =
      s"""
         |select
         |  record
         |from
         |  dm_gis.dlv_waybillno_phone_lib
         |where
         |  inc_day between  '$before30Day' and '$incDay'
       """.stripMargin
    println("select30PhoneSql:" + select30PhoneSql)

    val phone30Rdd = spark.sql(select30PhoneSql).rdd.map(row => {
      val record = row.getString(0)
      var json: JSONObject = null
      try {
        json = JSON.parseObject(record)
      } catch {
        case e: Exception => logger.error(">>>转换失败" + e)
      }
      json
    }).filter(_ != null).map(json => {
      var key: String = null
      val phone = json.getString("req_addresseemobile")
      val req_time = json.getString("req_time")
      if (phone != null && phone.length > 6 && req_time != null) {
        key = phone
      }
      (key, json)
    }).filter(_._1 != null).groupByKey().map(obj => {
      val iter: Iterable[JSONObject] = obj._2
      val list = new util.ArrayList[JSONObject]()
      for (json <- iter) list.add(json)
      val subList = SortByList.sortByReqTime30Day(list, 10)
      (obj._1, subList)
    })
    phone30Rdd
  }

  //  /**
  //   * 运单数据入hbase库
  //   *
  //   * @param dlvResultRdd
  //   */
  //  def storeWaybillnoRddToHbase(dlvResultRdd: RDD[JSONObject]): Unit = {
  //    try {
  //      val waybillnoRdd = dlvResultRdd.map(json => {
  //        val waybillno = json.getString("waybillno")
  //        (waybillno, json)
  //      }).filter(obj => {
  //        val waybillno = obj._1
  //        waybillno.matches("^[0-9]+") || waybillno.matches("^[a-zA-Z]+[0-9]+")
  //      }).groupByKey().map(obj => {
  //        val groupJson = obj._2
  //        val jsonArray = new JSONArray()
  //        for (json <- groupJson) {
  //          jsonArray.add(json)
  //        }
  //        (obj._1, jsonArray)
  //      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
  //
  //      logger.error(">>>运单入hbase库数据量:" + waybillnoRdd.count() + ",数据入库中")
  //      waybillnoRdd.repartition(40).foreachPartition(rdd => {
  //        //获取table并设置参数
  //        val table = getTable(javaUtil.get("waybillno_table"))
  //        val putList = new util.ArrayList[Put]()
  //        rdd.foreach(obj => {
  //          val waybillno = obj._1
  //          val key = getKeyStr(waybillno)
  //          val jsonArray = obj._2
  //          val put = new Put(Bytes.toBytes(key))
  //          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wrong_value"), Bytes.toBytes(jsonArray.toString))
  //          putList.add(put)
  //          if (putList.size() >= 500) {
  //            try {
  //              table.put(putList)
  //            } catch {
  //              case e: Exception => logger.error(e)
  //            }
  //            putList.clear()
  //          }
  //        })
  //        if (putList.size() > 0) {
  //          try {
  //            table.put(putList)
  //          } catch {
  //            case e: Exception => logger.error(e)
  //          }
  //          putList.clear()
  //        }
  //        table.close()
  //        //        Thread.sleep(500)
  //      })
  //
  //      logger.error(">>>运单入hbase库数据结束-------------")
  //      waybillnoRdd.unpersist()
  //    } catch {
  //      case e: Exception => logger.error(">>>运单数据入库异常：" + e)
  //    }
  //
  //  }
  /**
   * 运单数据入hbase库
   *
   * @param dlvResultRdd
   */
  def storeWaybillnoRddToHiveForHbase(spark: SparkSession, dlvResultRdd: RDD[JSONObject],
                                      incDay: String): Unit = {
    val waybillnoRdd = dlvResultRdd.map(json => {
      val waybillno = json.getString("waybillno")
      (waybillno, json)
    }).filter(obj => {
      val waybillno = obj._1
      waybillno.matches("^[0-9]+") || waybillno.matches("^[a-zA-Z]+[0-9]+")
    }).groupByKey().map(obj => {
      val groupJson = obj._2
      val jsonArray = new JSONArray()
      for (json <- groupJson) {
        jsonArray.add(json)
      }
      (obj._1, jsonArray)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>运单入hbase库数据量:" + waybillnoRdd.count() + ",数据入库中")
    val retRdd = waybillnoRdd.map(obj => {
      val waybillno = obj._1
      val key = getKeyStr(waybillno)
      val jsonArray = obj._2
      val ret = new JSONObject()
      ret.put("rowkey", key)
      ret.put("info_wrong_value", jsonArray.toJSONString)
      ret
    })
    var columns = Array("rowkey", "info_wrong_value")
    SparkWrite.save2HiveStaticRandom(spark, retRdd, columns, "dm_gis.dwd_gis_rds_oms_wrong_dipatch_mid",
      Array(("inc_day", incDay), ("data_type", "data")), 200
    )
    logger.error(">>>运单入hive库数据结束(后续导入到hbase)-------------")
    waybillnoRdd.unpersist()
  }

  /**
   * 运单数据入hbase库
   *
   * @param dlvResultRdd
   */
  def storeWaybillPickUpInfoToHiveForHbase(spark: SparkSession, dlvResultRdd: RDD[(String, String)],
                                           incDay: String): Unit = {
    val waybillnoRdd = dlvResultRdd.filter(obj => {
      val waybillno = obj._1
      waybillno.matches("^[0-9]+") || waybillno.matches("^[a-zA-Z]+[0-9]+")
    })
    val retRdd = waybillnoRdd.map(obj => {
      val waybillno = obj._1
      val key = getKeyStr(waybillno)
      val ret = new JSONObject()
      ret.put("rowkey", key);
      ret.put("info_consignee_depart_code", obj._2)
      ret
    })
    var columns = Array("rowkey", "info_consignee_depart_code")
    SparkWrite.save2HiveStaticRandom(spark, retRdd, columns, "dm_gis.dwd_gis_rds_oms_wrong_dipatch_mid",
      Array(("inc_day", incDay), ("data_type", "zc")), 20
    )
    logger.error(">>>解析数据入hive库结束（后续导入hbase）")
    waybillnoRdd.unpersist()
  }

  //  /**
  //   * 运单数据入hbase库
  //   *
  //   * @param dlvResultRdd
  //   */
  //  def storeWaybillPickUpInfoToHbase(dlvResultRdd: RDD[(String, String)]): Unit = {
  //    try {
  //      val waybillnoRdd = dlvResultRdd.filter(obj => {
  //        val waybillno = obj._1
  //        waybillno.matches("^[0-9]+") || waybillno.matches("^[a-zA-Z]+[0-9]+")
  //      })
  //      //      logger.error(">>>运单入hbase库数据量:" + waybillnoRdd.count() + ",数据入库中")
  //      waybillnoRdd.repartition(40).foreachPartition(rdd => {
  //        //获取table并设置参数
  //        val table = getTable(javaUtil.get("waybillno_table"))
  //        val putList = new util.ArrayList[Put]()
  //        rdd.foreach(obj => {
  //          val waybillno = obj._1
  //          val key = getKeyStr(waybillno)
  //          val put = new Put(Bytes.toBytes(key))
  //          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("consignee_depart_code"), Bytes.toBytes(obj._2))
  //          putList.add(put)
  //          if (putList.size() >= 500) {
  //            try {
  //              table.put(putList)
  //            } catch {
  //              case e: Exception => logger.error(e)
  //            }
  //            putList.clear()
  //          }
  //        })
  //        if (putList.size() > 0) {
  //          try {
  //            table.put(putList)
  //          } catch {
  //            case e: Exception => logger.error(e)
  //          }
  //          putList.clear()
  //        }
  //        table.close()
  //        //        Thread.sleep(500)
  //      })
  //
  //      logger.error(">>>运单入hbase库数据结束-------------")
  //      waybillnoRdd.unpersist()
  //    } catch {
  //      case e: Exception => logger.error(">>>运单数据入库异常：" + e)
  //    }
  //
  //  }
  //  def getTable(tableName: String): Table = {
  //    val hbaseConf = HBaseConfiguration.create()
  //    //设置写入的表
  //    hbaseConf.set("zookeeper.znode.parent", javaUtil.get("zookeeper.znode.parent"))
  //    hbaseConf.set("hbase.zookeeper.quorum", javaUtil.get("hbase.zookeeper.quorum"))
  //    hbaseConf.set("hbase.zookeeper.property.clientPort", javaUtil.get("hbase.zookeeper.property.clientPort"))
  //    val connection = ConnectionFactory.createConnection(hbaseConf)
  //    val table = connection.getTable(TableName.valueOf(tableName))
  //    //    table.setAutoFlush(false, false)
  //    //    table.setWriteBufferSize(512)
  //    table
  //  }

  /**
   * 将妥投的数据存在hive中
   *
   * @param resultRdd
   * @param spark
   * @param incDay
   */
  def storeDlvRddToHive(resultRdd: RDD[JSONObject], spark: SparkSession, incDay: String)(): Unit = {
    import org.apache.spark.sql.Row
//    try {
      spark.sql("use dm_gis")
      val dlv_waybillno_phone_lib = "dlv_waybillno_phone_lib"

      //1 构造DataFrame的元数据list StructField
      val structs = Array("record")
      val structFields = new ArrayBuffer[StructField]()
      for (struct <- structs) structFields.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
      //2 构建StructType用于DataFrame的元数据描述
      val structType = DataTypes.createStructType(structFields.toArray)
      //3 构建Row格式数据集RDD[Row]
      val rowRdd: RDD[Row] = resultRdd.map(obj => {
        var row: Row = null
        try {
          row = RowFactory.create(obj.toString)
        } catch {
          case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
        }
        row
      }).filter(_ != null).repartition(200)
      //4 构建DataFrame
      val df = spark.createDataFrame(rowRdd, structType)
      //5 基于Datarame创建临时表
      val tempView = dlv_waybillno_phone_lib + "_temp_view"
      df.createOrReplaceTempView(tempView)
      //6 分区、表等操作
      val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", dlv_waybillno_phone_lib, incDay)
      logger.error(">>>删除分区：" + deleteSql)
      spark.sql(deleteSql)
      val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", dlv_waybillno_phone_lib, incDay)
      logger.error(">>>新建分区：" + createPartitionSql)
      spark.sql(createPartitionSql)

      //7 把临时表的数据刷进hive表中
      val insertSql = String.format("insert into %s partition(inc_day = '%s') select * from %s", dlv_waybillno_phone_lib, incDay, tempView)
      println("insertSql:" + insertSql)
      spark.sql(insertSql)

      logger.error(">>>入hive结束。")
//    } catch {
//      case e: Exception => logger.error(">>>数据存hive异常：" + e)
//    }

  }


  /**
   * 计算rowkey
   *
   * @param key
   * @return
   */
  def getKeyStr(key: String): String = {
    //计算两位数的盐值
    var salt = (key.hashCode() % 30).toString.replace("-", "") //替换掉负号
    val df = new DecimalFormat("00")
    if (salt.length == 1) {
      //个位数前面需要补0
      salt = df.format(Integer.parseInt(salt))
    }
    salt + "_" + key
  }

  /**
   * 获取当前系统到秒的时间
   *
   * @return
   */
  def getTime(): String = {
    val longtTime = System.currentTimeMillis()
    val dfTime = new SimpleDateFormat("yyyyMMdd HH:mm:ss:SSS")
    val time = dfTime.format(new Date(longtTime))
    time
  }
}
*/
