package com.sf.gis.scala.oms_shou.main

import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_shou.constant.VariableConstant
import com.sf.gis.scala.utils.StringUtil
import org.apache.spark.rdd.RDD
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConversions._
import scala.util.control.Breaks

/**
 * Created by 01368078 on 2019/1/4.
 */
class LogParser extends Serializable {
  @transient val logger: Logger = LoggerFactory.getLogger(classOf[LogParser])

  var bodyKeyMap: util.HashMap[String, String] = new util.HashMap[String, String]()
  bodyKeyMap.put("rds_true_req", VariableConstant.SYNC_REQ_BODY_KEY)
  bodyKeyMap.put("rds_true_re", VariableConstant.SYNC_RE_BODY_KEY)
  bodyKeyMap.put("rds_false_req", VariableConstant.ASYNC_REQ_BODY_KEY)
  bodyKeyMap.put("rds_false_re", VariableConstant.ASYNC_RE_BODY_KEY)
  bodyKeyMap.put("rds_false_arss_req", VariableConstant.RDS_ARSS_REQ_BODY_KEY)
  //  bodyKeyMap.put("arss__arss_req", VariableConstant.ARSS_REQ_BODY_KEY)
  bodyKeyMap.put("arss__arss_re", VariableConstant.ARSS_RE_BODY_KEY)
  bodyKeyMap.put("rds_false_ks_resp", VariableConstant.KS_RE_BODY_KEY)
  bodyKeyMap.put("rds_false_ks_req", VariableConstant.KS_REQ_BODY_KEY)

  bodyKeyMap.put("building_true_re", VariableConstant.BUILDING_BODY_KEY)
  bodyKeyMap.put("building_false_re", VariableConstant.BUILDING_BODY_KEY)

  var sysOrderNoKeyMap: util.HashMap[String, String] = new util.HashMap[String, String]()
  sysOrderNoKeyMap.put("rds_true_req", VariableConstant.SYNC_REQ_SYS_ORDERNO_KEY)
  sysOrderNoKeyMap.put("rds_true_re", VariableConstant.SYNC_REQ_SYS_ORDERNO_KEY)
  sysOrderNoKeyMap.put("rds_false_req", VariableConstant.ASYNC_REQ_SYS_ORDERNO_KEY)
  sysOrderNoKeyMap.put("rds_false_re", VariableConstant.ASYNC_RE_SYS_ORDERNO_KEY)
  sysOrderNoKeyMap.put("rds_false_arss_req", VariableConstant.RDS_ARSS_REQ_SYS_ORDERNO_KEY)

  sysOrderNoKeyMap.put("rds_false_ks_req", VariableConstant.RDS_ARSS_REQ_SYS_ORDERNO_KEY)

  def parse(logs: RDD[String]): RDD[(String, JSONObject)] = {
    val logRdd = logs
      //      .filter(line => {
      ////      //      (line.contains(VariableConstant.LOG_MARKER) || checkChkKsData(line)) && checkDate(line, dateList)
      ////      line.contains("dataType") && checkDate(line, dateList)
      ////    })
      .map(line => {
        var tp: (String, JSONObject) = null
        try {
          tp = parse(line)
        } catch {
          case e: Exception =>
            e.printStackTrace()
            //          logger.error("parse line error")
            (null, null)
        }
        tp
      }).filter(obj => obj != null && !StringUtil.isBlank(obj._1) && obj._2 != null)
    logRdd
  }

  /**
   * 是否是需解析的报文
   *
   * @param line : 数据体
   * @return
   */
  def checkChkKsData(line: String): Boolean = {
    //chk和ks之间的报文
    line.contains(VariableConstant.CHK_TO_KS_REQ_MARKER) || line.contains(VariableConstant.KS_TO_CHK_RE_MARKER) || line.contains(VariableConstant.CHK_TO_OMS_MARKER)
  }

  def checkDate(line: String, dateList: util.ArrayList[String]): Boolean = {
    for (date <- dateList) {
      if (line.contains(date))
        return true
    }
    false
  }

  def parse(line: String): (String, JSONObject) = {
    try {
      line2Tuple(line)
    } catch {
      case e: Exception => logger.error(line, e)
        (null, null)
    }
  }

  /**
   * ks回复chkn
   *
   * @param line : 数据体
   * @return
   */
  def ksToChkReParser(line: String, dataTime: String): (String, JSONObject) = {
    val obj = JSONUtil.parseStr2Json(line)
    val rslt = new JSONObject()
    val result = obj.getJSONObject("result")
    var sysOrderNo: String = null
    var requestId:String = null

    if (result != null) {
      val attachment = JSONUtil.parseStr2Json(JSONUtil.getJsonVal(result, "attachment", ""))
      sysOrderNo = JSONUtil.getJsonVal(attachment, "producerOmsInfo.sysOrderNo", null)
      requestId = JSONUtil.getJsonVal(attachment, "producerArssInfo.requestId", null)
      rslt.put("reqId", requestId)
      result.remove("attachment")
      result.put("requestId", requestId)
      obj.put("result", result)
    }
    //    val attachment = JSONUtil.parseStr2Json(JSONUtil.getJsonVal(obj, "result.attachment", ""))
    //    val sysOrderNo = JSONUtil.getJsonVal(attachment, "producerArssInfo.sysOrderNo", null)
    rslt.put("chkKsReBody", obj)
    //    rslt.put("dataTime", dataTime)
    rslt.put("sysOrderNo", sysOrderNo)
    (requestId, rslt)
  }

  /**
   * chk发往ks的请求
   *
   * @param line : 数据体
   * @return
   */
  def chkToKsReqParser(line: String, dataTime: String): (String, JSONObject) = {
    val obj = JSONUtil.parseStr2Json(line)
    val rslt = new JSONObject()
    val requestId = obj.getString("requestId")
    //    val sysOrderNo = JSONUtil.getJsonVal(obj, "producerArssInfo.sysOrderNo", null)
    val sysOrderNo = JSONUtil.getJsonVal(obj, "prodOmsInfo.sysOrderNo", null)
    obj.remove("orderInfo")
    obj.remove("producerArssInfo")
    rslt.put("chkKsReqBody", obj)
    //    rslt.put("dataTime", dataTime)
    rslt.put("reqId", requestId)
    rslt.put("sysOrderNo", sysOrderNo)
    (requestId, rslt)
  }

  def buildIngParser(message: JSONObject, dataTime: String): (String, JSONObject) = {
    val rslt = new JSONObject()
    rslt.put("requestBuildingBody", JSON.parseObject(message.getString("requestBuilding")))
    rslt.put("responseBuildingBody", JSON.parseObject(message.getString("responseBuilding")))
    //    rslt.put("sysOrderNo",message.getString("sysOrderNo"))
    val sysOrderNo = JSONUtil.getJsonVal(message, "sysOrderNo", null)
    val requestId = JSONUtil.getJsonVal(message, "requestId", null)
    rslt.put("reqId", requestId)
    //    rslt.put("dataTime", dataTime)
    rslt.put("sysOrderNo", sysOrderNo)
    (requestId, rslt)
  }

  def atShouBodyParser(message: JSONObject): (String, JSONObject) = {
    val rslt = new JSONObject()
    val res = message.getJSONObject("res")
    rslt.put("atShouBody",res)
    val reqId = JSONUtil.getJsonValSingle(message, "requestId", null)
    rslt.put("reqId",reqId)
    (reqId,rslt)
  }

  def line2Tuple(line: String): (String, JSONObject) = {
    val totalObj = JSONUtil.parseStr2Json(line)
    if (totalObj == null) {
      (null, null)
    } else if ("arss_re".equals(totalObj.getString("dataType"))
      && "arss".equals(totalObj.getString("type"))) {
      val _type = JSONUtil.getJsonVal(totalObj, "type", "")
      val syn = ""
      val dataType = JSONUtil.getJsonVal(totalObj, "dataType", "")
      val keyStr = String.format("%s_%s_%s", _type, syn, dataType)
      val bodyKey = bodyKeyMap.get(keyStr)
      val reqId = JSONUtil.getJsonVal(totalObj, "reqId", null)
      val dataTime = JSONUtil.getJsonVal(totalObj, "dateTime", "")
      val sysOrderNo: String = JSONUtil.getJsonVal(totalObj, "data.sysOrderNo", null)
      val rslt = new JSONObject()
      rslt.put("arssReBody", totalObj)
      rslt.put("reqId", reqId)
      rslt.put("sysOrderNo", sysOrderNo)
      //      rslt.put("dataTime", dataTime)
      (reqId, rslt)
    }else {
      val message = totalObj.getJSONObject("message")
      //            val reqId = JSONUtil.getJsonVal(message, "requestId", "")
      val dataTime = JSONUtil.getJsonVal(totalObj, "createTime", "")
      val _type = JSONUtil.getJsonVal(message, "type", "")
      val syn = JSONUtil.getJsonVal(message, "syn", "")
      val dataType = JSONUtil.getJsonVal(message, "dataType", "")
      if (StringUtil.isBlank(dataType)) {
        return (null, null)
      }

      if("AT".equals(dataType)){
        //at收body
        return atShouBodyParser(message)
      }

      val keyStr = String.format("%s_%s_%s", _type, syn, dataType)

      val bodyKey = bodyKeyMap.get(keyStr)
      if (VariableConstant.KS_RE_BODY_KEY.equals(bodyKey)) {
        return ksToChkReParser(JSONUtil.getJsonVal(message, "ksStr", ""), dataTime)
      }
      if (VariableConstant.KS_REQ_BODY_KEY.equals(bodyKey)) {
        return chkToKsReqParser(message.toJSONString, dataTime)
      }
      if (VariableConstant.BUILDING_BODY_KEY.equals(bodyKey)) {
        return buildIngParser(message, dataTime)
      }
      if ("rds_false_re".equals(keyStr) && ("10".equals(message.getString("status"))
        || "9".equals(message.getString("status")))
        && message.getJSONObject("prodOmsInfo") != null) {
        val prodOmsInfo = message.getJSONObject("prodOmsInfo")
        val reqId = JSONUtil.getJsonVal(message, "requestId", "")
        val sysOrderNo: String = prodOmsInfo.getString("sysOrderNo")
        val rslt = new JSONObject()
        rslt.put("chkOmsRebody", prodOmsInfo)
        rslt.put("reqId", reqId)
        //        rslt.put("dataTime", dataTime)
        rslt.put("sysOrderNo", sysOrderNo)
        return (reqId, rslt)
      }
      val sysOrderNoKey = sysOrderNoKeyMap.get(keyStr)
      if (VariableConstant.SYNC_REQ_BODY_KEY.equals(bodyKey) || VariableConstant.ASYNC_REQ_BODY_KEY.equals(bodyKey)) //获取第一条请求
        fetchBody(message, VariableConstant.ORDERINFO_LIST_KEY)

      if (VariableConstant.SYNC_RE_BODY_KEY.equals(bodyKey) || VariableConstant.ASYNC_RE_BODY_KEY.equals(bodyKey)) {
        fetchBody(message, VariableConstant.TCS_KEY)
        str2Json(message, VariableConstant.CHKRESULT_KEY)
      }
      if(bodyKey == null){
        return (null,null)
      }
      val reqId = JSONUtil.getJsonVal(message, "requestId", "")
      val newObj = new JSONObject()
      newObj.put("reqId", reqId)
      //dataTime将作为是否有同步异步请求的标识，其他报文不要解析此字段出来放到外层，防止聚合影响时间值
      newObj.put("dataTime", dataTime)
      newObj.put(bodyKey, message)
      if (sysOrderNoKey != null) { //有系统订单号
        var sysNo = JSONUtil.getJsonVal(message, sysOrderNoKey, null)
        //        if ("".equals(sysNo)) //订单号为空，以reqId作为订单号，防止reduceByKey归为一类
        //          sysNo = reqId
        newObj.put(VariableConstant.SYS_ORDERNO_KEY, sysNo)
        val orderKey = sysOrderNoKey.replace("sysOrderNo", "orderNo")
        val orderNo = JSONUtil.getItem(message, orderKey, null)
        newObj.put(VariableConstant.ORDERNO_KEY, orderNo)
      }

      (reqId, newObj)
    }
  }

  def fetchBody(obj: JSONObject, keys: String): Unit = {
    val keyArr = keys.split("\\.")
    val objMap = new util.HashMap[String, JSONObject]()
    var tempObj = obj
    val loop = new Breaks
    loop.breakable(
      for (i <- 0 until keyArr.length) {
        if (tempObj == null || !tempObj.containsKey(keyArr(i)))
          loop.break()
        if (i < keyArr.length - 1) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        } else {
          tempObj = tempObj.getJSONArray(keyArr(i)).getJSONObject(0)
        }
        objMap.put(keyArr(i), tempObj)
      }
    )
    loop.breakable(
      for (i <- (0 until keyArr.length - 1).reverse) {
        if (!objMap.containsKey(keyArr(i)))
          loop.break()
        objMap.get(keyArr(i)).put(keyArr(i + 1), objMap.get(keyArr(i + 1)))
      }
    )
    if (objMap.containsKey(keyArr(0)))
      obj.put(keyArr(0), objMap.get(keyArr(0)))
  }

  def str2Json(obj: JSONObject, keys: String): Unit = {
    val keyArr = keys.split("\\.")
    val objMap = new util.HashMap[String, JSONObject]()
    var tempObj = obj
    val loop = new Breaks
    loop.breakable(
      for (i <- 0 until keyArr.length) {
        if (tempObj == null || !tempObj.containsKey(keyArr(i)))
          loop.break()
        if (i < keyArr.length - 1)
          tempObj = tempObj.getJSONObject(keyArr(i))
        else
          tempObj = JSON.parseObject(tempObj.getString(keyArr(i)))
        objMap.put(keyArr(i), tempObj)
      }
    )
    loop.breakable(
      for (i <- (0 until keyArr.length - 1).reverse) {
        if (!objMap.containsKey(keyArr(i)))
          loop.break()
        objMap.get(keyArr(i)).put(keyArr(i + 1), objMap.get(keyArr(i + 1)))
      }
    )
    if (objMap.containsKey(keyArr(0)))
      obj.put(keyArr(0), objMap.get(keyArr(0)))
  }
}

object LogParser {
  def main(args: Array[String]): Unit = {
    val lp = new LogParser
    val str = "{\"appname\":\"chk-consignee\",\"createTime\":\"2023-05-04 13:26:58.372\",\"ip\":\"10.244.19.150\",\"level\":\"HDFS\",\"message\":{\"dataTime\":\"2023-05-04 13:26:58 372\",\"dataType\":\"re\",\"orderInfo\":{\"bookingDateTime\":\"\",\"bookingType\":\"1\",\"cargoTypeCode\":\"T6\",\"clientCode\":\"4312800259\",\"expressTypeCode\":\"B1\",\"isNotUnderCall\":\"1\",\"limitTypeCode\":\"T6\",\"omsSendTime\":1683178018344,\"orderFromToList\":[{\"orderFrom\":{\"address\":\"远达大街858号2819室\",\"city\":\"长春市\",\"cityCode\":\"431\",\"company\":\"长春泰阳*\",\"contactsName\":\"长春泰阳*\",\"county\":\"北湖科技开发区\",\"customerAccount\":\"4312941035\",\"customerId\":\"AAABh+U6Vh+8KB0q/ZxIn6vBdo4d7IXr\",\"mobile\":\"DEEQAVTloQLd2y0cPenmCF1gXjY0w%3D\",\"phone\":\"DEEQAVTloQLd2y0cPenmCF1gXjY0w%3D\",\"province\":\"吉林省\"},\"orderTo\":{\"address\":\"DE##EwA9Thet4b4sAhugE6gGWOacpkp600FDWXHTERZQXVQyxzXn0%2BEQpt5ue1KWY8qb1cCiQ0LnTxIFsYGZOnMY9wsqgvI%3D\",\"city\":\"天津市\",\"cityCode\":\"022\",\"contactsName\":\"王华林\",\"county\":\"滨海新区\",\"customerId\":\"AAABh+U6Vh9JABiNTFxD1Kb/cfgrGtY+\",\"mobile\":\"DEEQAVTq%2F1i4G0oXziUF1HuwJN%2BOM%3D\",\"phone\":\"DEEQAVTq%2F1i4G0oXziUF1HuwJN%2BOM%3D\",\"province\":\"天津市\",\"waybillNo\":\"SF1612211884011\"}}],\"orderNo\":\"01701050413265832203235995\",\"orderType\":\"2\",\"payType\":\"1\",\"serviceCodeList\":[\"IN01\"],\"sysOrderNo\":\"1007299971\",\"sysSource\":\"BSP\",\"weight\":\"1.0\"},\"requestId\":\"0042652023050413265835237484_OMS_01701050413265832203235995_1007299971\",\"ret\":{\"addrSplit\":\"\",\"aoiArea\":\"\",\"aoiCode\":\"\",\"aoiId\":\"\",\"aoiUnit\":\"\",\"atSrvRet\":\"{\\\"isNotUnderCall\\\":\\\"1\\\",\\\"src\\\":\\\"zh\\\",\\\"tcs\\\":[{\\\"atAoiSrc\\\":\\\"\\\",\\\"other\\\":{\\\"tc2y\\\":\\\"\\\",\\\"geozc\\\":\\\"\\\",\\\"tc2x\\\":\\\"\\\",\\\"tc2SchTc\\\":\\\"\\\",\\\"tc2Flag\\\":\\\"\\\",\\\"tc2MatchLevel\\\":\\\"\\\",\\\"tc2Count\\\":\\\"\\\",\\\"tc2Score\\\":\\\"\\\",\\\"tc2GeoSrc\\\":\\\"\\\",\\\"tc2AoiId\\\":\\\"\\\",\\\"tc2GroupId\\\":\\\"\\\",\\\"tc2AoiCode\\\":\\\"\\\",\\\"geotc\\\":\\\"\\\",\\\"tc2AoiArea\\\":\\\"\\\",\\\"tc2Src\\\":\\\"\\\",\\\"tc2SchZc\\\":\\\"\\\"},\\\"flag\\\":1,\\\"notc\\\":\\\"0\\\",\\\"src\\\":\\\"dispatch-normhp\\\",\\\"aoiArea\\\":\\\"\\\",\\\"groupid\\\":\\\"738F3C00004511ED96F340EEDD0EF9F6\\\",\\\"addrSplit\\\":\\\"\\\",\\\"aoiUnit\\\":\\\"\\\",\\\"dept\\\":\\\"431BEE\\\",\\\"team\\\":\\\"\\\",\\\"atTeamSrc\\\":\\\"\\\",\\\"aoicode\\\":\\\"\\\",\\\"stdAddrSplit\\\":\\\"\\\",\\\"atDeptSrc\\\":\\\"dispatch-normhp\\\",\\\"aoiid\\\":\\\"\\\"}],\\\"count\\\":1,\\\"atDisResult\\\":\\\"{\\\\\\\"status\\\\\\\":0,\\\\\\\"result\\\\\\\":{\\\\\\\"src\\\\\\\":\\\\\\\"zh\\\\\\\",\\\\\\\"count\\\\\\\":1,\\\\\\\"tcs\\\\\\\":[{\\\\\\\"src\\\\\\\":\\\\\\\"normhp\\\\\\\",\\\\\\\"flag\\\\\\\":1,\\\\\\\"dept\\\\\\\":\\\\\\\"431BEE\\\\\\\",\\\\\\\"groupid\\\\\\\":\\\\\\\"738F3C00004511ED96F340EEDD0EF9F6\\\\\\\",\\\\\\\"notc\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"atDeptSrc\\\\\\\":\\\\\\\"normhp\\\\\\\",\\\\\\\"keyWord\\\\\\\":\\\\\\\"远达大街858号\\\\\\\",\\\\\\\"haschk\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"other\\\\\\\":{}}],\\\\\\\"other\\\\\\\":{\\\\\\\"normresp\\\\\\\":{\\\\\\\"success\\\\\\\":true,\\\\\\\"errorCode\\\\\\\":0,\\\\\\\"result\\\\\\\":{\\\\\\\"status\\\\\\\":0,\\\\\\\"count\\\\\\\":3,\\\\\\\"geocoder\\\\\\\":[{\\\\\\\"floor\\\\\\\":\\\\\\\"28\\\\\\\",\\\\\\\"adcode\\\\\\\":220105,\\\\\\\"filter\\\\\\\":2,\\\\\\\"group\\\\\\\":\\\\\\\"738F3C00004511ED96F340EEDD0EF9F6\\\\\\\",\\\\\\\"name\\\\\\\":\\\\\\\"吉林省长春市二道区远达大街|858号@28层\\\\\\\",\\\\\\\"x\\\\\\\":125.377628,\\\\\\\"y\\\\\\\":43.9072189,\\\\\\\"standardization\\\\\\\":\\\\\\\"吉林省长春市二道区远达大街858号\\\\\\\",\\\\\\\"score\\\\\\\":1,\\\\\\\"level\\\\\\\":\\\\\\\"GL_STREETNO\\\\\\\",\\\\\\\"mainid\\\\\\\":\\\\\\\"310967\\\\\\\",\\\\\\\"poi_typecode\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"id\\\\\\\":\\\\\\\"71AD5D2C004511EDA97340EEDD0EF9F6\\\\\\\",\\\\\\\"sflag\\\\\\\":0,\\\\\\\"key\\\\\\\":\\\\\\\"3|4\\\\\\\"},{\\\\\\\"floor\\\\\\\":\\\\\\\"28\\\\\\\",\\\\\\\"adcode\\\\\\\":220103,\\\\\\\"filter\\\\\\\":2,\\\\\\\"group\\\\\\\":\\\\\\\"6AD85A96627F11ED8D7240EEDD0EF9F6\\\\\\\",\\\\\\\"name\\\\\\\":\\\\\\\"吉林省长春市宽城区远达大街|858号\\\\\\\",\\\\\\\"x\\\\\\\":125.409965,\\\\\\\"y\\\\\\\":43.9678978,\\\\\\\"standardization\\\\\\\":\\\\\\\"吉林省长春市宽城区远达大街858号\\\\\\\",\\\\\\\"score\\\\\\\":1,\\\\\\\"level\\\\\\\":\\\\\\\"GL_STREETNO\\\\\\\",\\\\\\\"mainid\\\\\\\":\\\\\\\"3283047\\\\\\\",\\\\\\\"poi_typecode\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"id\\\\\\\":\\\\\\\"6A9567AE627F11ED892640EEDD0EF9F6\\\\\\\",\\\\\\\"sflag\\\\\\\":0,\\\\\\\"key\\\\\\\":\\\\\\\"3|4\\\\\\\"},{\\\\\\\"floor\\\\\\\":\\\\\\\"28\\\\\\\",\\\\\\\"adcode\\\\\\\":220103,\\\\\\\"filter\\\\\\\":2,\\\\\\\"group\\\\\\\":\\\\\\\"03EAD5F6C4B911ED909B40EEDD0EF9F6\\\\\\\",\\\\\\\"name\\\\\\\":\\\\\\\"吉林省长春市宽城区北远达大街|858号\\\\\\\",\\\\\\\"x\\\\\\\":125.386968,\\\\\\\"y\\\\\\\":43.971545,\\\\\\\"standardization\\\\\\\":\\\\\\\"吉林省长春市宽城区北远达大街858号\\\\\\\",\\\\\\\"score\\\\\\\":1,\\\\\\\"level\\\\\\\":\\\\\\\"GL_STREETNO\\\\\\\",\\\\\\\"mainid\\\\\\\":\\\\\\\"313104\\\\\\\",\\\\\\\"poi_typecode\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"id\\\\\\\":\\\\\\\"03AC1DA2C4B911ED882240EEDD0EF9F6\\\\\\\",\\\\\\\"sflag\\\\\\\":0,\\\\\\\"key\\\\\\\":\\\\\\\"3|4\\\\\\\"}],\\\\\\\"source\\\\\\\":\\\\\\\"jilinqu\\\\\\\",\\\\\\\"splitResult\\\\\\\":\\\\\\\"吉林省^11,长春市^12,北湖科技开发区^14,远达大街^19,858号^211,2819室^217;17\\\\\\\",\\\\\\\"splitType\\\\\\\":0,\\\\\\\"addrSplitInfo\\\\\\\":[{\\\\\\\"match\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"prop\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"level\\\\\\\":1,\\\\\\\"name\\\\\\\":\\\\\\\"吉林省\\\\\\\"},{\\\\\\\"match\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"prop\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"level\\\\\\\":2,\\\\\\\"name\\\\\\\":\\\\\\\"长春市\\\\\\\"},{\\\\\\\"match\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"prop\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"level\\\\\\\":4,\\\\\\\"name\\\\\\\":\\\\\\\"北湖科技开发区\\\\\\\"},{\\\\\\\"match\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"prop\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"level\\\\\\\":9,\\\\\\\"name\\\\\\\":\\\\\\\"远达大街\\\\\\\"},{\\\\\\\"match\\\\\\\":\\\\\\\"1\\\\\\\",\\\\\\\"prop\\\\\\\":\\\\\\\"2\\\\\\\",\\\\\\\"level\\\\\\\":11,\\\\\\\"name\\\\\\\":\\\\\\\"858号\\\\\\\"},{\\\\\\\"match\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"prop\\\\\\\":\\\\\\\"2\\\\\\\",\\\\\\\"level\\\\\\\":17,\\\\\\\"name\\\\\\\":\\\\\\\"2819室\\\\\\\"}],\\\\\\\"guid\\\\\\\":\\\\\\\"8C81879C-8E17-4401-9AC8-FD01916FE596\\\\\\\"}},\\\\\\\"city\\\\\\\":\\\\\\\"431\\\\\\\",\\\\\\\"adcode\\\\\\\":\\\\\\\"220100\\\\\\\",\\\\\\\"filters\\\\\\\":[2],\\\\\\\"groupid\\\\\\\":\\\\\\\"738F3C00004511ED96F340EEDD0EF9F6\\\\\\\"},\\\\\\\"id_list\\\\\\\":{\\\\\\\"normId\\\\\\\":\\\\\\\"738F3C00004511ED96F340EEDD0EF9F6\\\\\\\",\\\\\\\"hpId\\\\\\\":\\\\\\\"738F3C00004511ED96F340EEDD0EF9F6|2819室\\\\\\\",\\\\\\\"roadId\\\\\\\":{\\\\\\\"matchId\\\\\\\":null,\\\\\\\"exceptId\\\\\\\":null,\\\\\\\"tcMatchId\\\\\\\":null,\\\\\\\"tcExceptId\\\\\\\":null,\\\\\\\"aoiMatchId\\\\\\\":null,\\\\\\\"aoiExceptId\\\\\\\":null}}}}\\\"}\",\"cityCode\":\"431\",\"cityLev\":0,\"groupid\":\"738F3C00004511ED96F340EEDD0EF9F6\",\"message\":\"getTeamfromgis/nullnull\",\"noTc\":\"0\",\"notArss\":false,\"retType\":\"onlyDept\",\"src\":\"dispatch-normhp\",\"stdAddrSplit\":\"\",\"team\":{\"customerId\":\"AAABh+U6Vh+8KB0q/ZxIn6vBdo4d7IXr\",\"deptCode\":\"431BEE\"},\"teamRetBy\":\"gis\"},\"status\":\"2\",\"syn\":\"true\",\"sysCode\":\"SHIVA-OMS\",\"type\":\"rds\"},\"syn\":false}"
    val dd = lp.parse(str)
    //    val (key,json) = lp.line2Tuple(str)
    //    println(key)
    //    val orderInfo = JSON.toJavaObject(json, classOf[OrderInfo])
    //    val orderData = new Main().pickValuableInfo(orderInfo)
    //    val orderData = JSON.parseObject(str, classOf[OrderData])
    //    new LogStatistics().getPuTcDetail(orderData,null)
    //    println(JSON.toJSONString(new Main().pickValuableInfo(orderInfo), SerializerFeature.PrettyFormat))
  }
}
