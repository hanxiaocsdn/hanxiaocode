//package com.sf.gis.scala.utils;
//
////import com.sf.presto.jdbc.internal.okhttp3.Connection;
//
//
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Properties;
//
//public class test {
//
//    public static Connection getConnection(Map<String,String> dataSource) throws SQLException {
//        Properties jdbcPros=new Properties();
//        String jdbcUrl=dataSource.get("jdbcUrl"),username=dataSource.get("username"),password=dataSource.get("password");
//        jdbcPros.put("user",username);
//        jdbcPros.put("password",password);
//        String cluster=dataSource.get("cluster");
//        if(cluster!=null){
//            jdbcPros.put("ext.cluster",cluster);
//        }
//
//        return DriverManager.getConnection(jdbcUrl,jdbcPros);
//    }
//
//    public static void main(String[] args) {
//        HashMap<String, String> dataSource = new HashMap<String, String>();
//        dataSource.put("jdbcUrl","jdbc:presto://10.202.106.166:8081/hive");
//        dataSource.put("password","sf123456");
//        dataSource.put("username","app_presto_default");
//        dataSource.put("cluster","testsun");
//        Statement statement=null;
//        Connection connection=null;
//        try {
//            connection = getConnection(dataSource);
//            statement = connection.createStatement();
//
////            PreparedStatement pst = connection.prepareStatement("insert into default.01389405_test_20200101_dest_zone_code_010abd(waybill_no)values('你好')");
////            pst.setString(0,"你好");
////            pst.executeUpdate();
//            int i = statement.executeUpdate("insert into default.01389405_test_20200101_dest_zone_code_010abd values('gg') ");
//
////            int i = statement.executeUpdate("insert into default.01389405_test_20200101_dest_zone_code_010abd select call_count from default.t_ccsr_forecast_model_result_timely limit 100 ");
////            int i = statement.executeUpdate("drop table default.01389405_test_20200101_dest_zone_code_010abd select call_count ");
//            System.out.println(i);
//
////            int i = statement.executeUpdate("create table default.t_test_20220218(" +
////                    "user_id                   string COMMENT '国家格式-座机号、手机号'," +
////                    "name            int COMMENT '近一年寄件量'" +
////
////                    ")" +
////                    "");
////            System.out.println(i);
//
//
////            ResultSet resultSet = statement.executeQuery("select * from default.t_ccsr_forecast_model_result_timely limit 100");
//////            System.out.println(resultSet.toString());
////            while(resultSet.next()){
////
////                System.out.println(resultSet.getString("vc_name"));
////                System.out.println(resultSet.getString("call_date"));
////
////            }
//        } catch (SQLException throwables) {
//            throwables.printStackTrace();
//        }finally {
//            try {
//                statement.close();
//                connection.close();
//
//            }catch (Exception e){
//
//            }
//
//
//        }
//
//
//    }
//}
//
//
