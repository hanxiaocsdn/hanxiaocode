package com.sf.gis.scala.oms_pai.index.oms_realtime;


public class OmsDlvRcg {
    private String province;
    private String region;
    private String city;
    private String city_code;
    private String zonecode;
    private int req;

    public OmsDlvRcg(String province, String region, String city, String city_code, String zonecode, int req) {
        this.province = province;
        this.region = region;
        this.city = city;
        this.city_code = city_code;
        this.zonecode = zonecode;
        this.req = req;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public int getReq() {
        return req;
    }

    public void setReq(int req) {
        this.req = req;
    }
}
