package com.sf.gis.scala.utils;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStreamReader;
import java.util.Properties;


public class ConfigurationUtil {

    private  static Logger logger = LoggerFactory.getLogger(ConfigurationUtil.class);

    @SuppressWarnings("SameParameterValue")
    public static Properties loadProperties(String fileName, String charset) {
        Properties props = new Properties();
        try {
            InputStreamReader in = new InputStreamReader(ConfigurationUtil.class.getClassLoader().getResourceAsStream(fileName), charset);
            props.load(in);
            in.close();
        }catch (Exception e){
            logger.error("load properties file error! file name : " +  fileName, e);
        }
        return props;
    }
    public static Properties loadProperties(String fileName) {
        return loadProperties(fileName, "UTF-8");
    }



}
