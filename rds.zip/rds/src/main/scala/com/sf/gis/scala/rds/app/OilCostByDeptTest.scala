package com.sf.gis.scala.rds.app

import java.util
import java.util.stream.Collectors

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.csvreader.CsvReader
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import com.sf.gis.scala.rds.util.{DistanceTool, HttpClientUtils, Util}
import com.vividsolutions.jts.geom.{Coordinate, GeometryFactory, Point, Polygon}
import com.vividsolutions.jts.io.WKTReader
import org.apache.log4j.Logger
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.geotools.geometry.jts.JTSFactoryFinder

import scala.collection.JavaConversions._


/**
 * Modified by 01394386 on 2020/06.
 * 1.更换排班表
 * 2.修改同个员工出现多条轨迹的逻辑为 取相同时间段里程最大的轨迹
 * 3.修改纠偏前轨迹,按ak,工号,设备id,app_v分组后进行纠偏
 * 4.获取轨迹正则:(\{"ret":0,"tracks":\[\{)|("sum_dist":(.*?),)|("reliable":(.*?),)|("matchOrder":(.*?),)|("index":(.*?),)|("milltime":(.*?),)|("time":(.*?),)|("status":(.*?),)|("type":(.*?),)|("tm":(.*?),)|("x":)|("y":)|(\[)|(\{)|(\])|(\})|(,\n)|("speed":.*\}?)
 **/
//noinspection DuplicatedCode


//统计 车辆用户网点到单元区域轨迹往返趟数, 网点到单元区域轨迹理论里程（从cms获取），以及单元区域内轨迹里程计算
object OilCostByDeptTest {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val calPartition = 200
  val savePartition = 20
  //允许的最大距离范围
  val maxAllowDistance = 1500
  //根据坐标去获取aoi

  //调用路径规划接口获取车行距离L
  val xyGetDistUrl = "http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?cc=1&opt=sf1&x1=%s&y1=%s&x2=%s&y2=%s&strategy=0&type=0&ak=1f6a303e618e4b0498550a9310eb0b38"


  def main(args: Array[String]): Unit = {
    start(args(0), args(1))
  }

  def fetchEmpNo(spark: SparkSession, incDay: String): (util.HashSet[String], RDD[(String, JSONObject)]) = {
    val sparkSql =
      s"""
         |select
         |  a.city_code,
         |  a.un,
         |  a.zc,
         |  a.position_name,
         |  a.persk_txt,
         |  a.parent_dept_code,
         |  b.son_dept_code
         |from
         |  (
         |    select
         |      ifnull(tmp1.city_code, tmp2.city_code) city_code,
         |      tmp1.un un,
         |      ifnull(tmp1.zc, tmp2.dept_code) zc,
         |      tmp2.position_name position_name,
         |      tmp2.persk_txt persk_txt,
         |      tmp3.parent_dept_code parent_dept_code
         |    from
         |      (
         |        select
         |          distinct regexp_replace(substring(a.dept_code, 0, 4), '[a-zA-Z]*', '') as city_code,
         |          regexp_replace(b.emp_code, '^(0+)', '') as un,
         |          a.dept_code as zc
         |        from
         |          (
         |            select
         |              regexp_replace(emp_code, '^(0+)', '') as emp_code
         |            from
         |              dm_vms.tm_vms_vehicle_subsicy
         |            where
         |              inc_day = '$incDay'
         |              and emp_code <> ''
         |          ) b
         |          left join (
         |            select
         |              regexp_replace(loginid, '^(0+)', '') as buid,
         |              dept_code
         |            from
         |              dm_tc_waybillinfo.schedule_width_data
         |            where
         |              inc_day = '$incDay'
         |          ) a on a.buid = b.emp_code
         |        --where
         |          --regexp_replace(b.emp_code, '^(0+)', '') = '503991'
         |      ) tmp1
         |      left join(
         |        select
         |          regexp_replace(emp_code, '^(0+)', '') emp_code,
         |          position_name,
         |          persk_txt,
         |          dept_code,
         |          regexp_replace(substring(dept_code, 0, 4), '[a-zA-Z]*', '') as city_code
         |        from
         |          gdl.tt_emp_info
         |        where
         |          inc_day = '$incDay'
         |          and emp_code <> ''
         |      ) tmp2 on tmp1.un = tmp2.emp_code
         |      left JOIN (
         |        select
         |          dept_code,
         |          parent_dept_code
         |        from
         |          gdl.zipper_dim_department
         |        where
         |          dw_start_date <= '$incDay'
         |          and dw_end_date >= '$incDay'
         |          and dept_type_name = '营业站'
         |      ) tmp3 ON ifnull(tmp1.zc, tmp2.dept_code) = tmp3.dept_code
         |  ) a
         |  left join (
         |    select
         |      tmp.parent_dept_code as dept_code,
         |      concat_ws(',', collect_set(tmp.dept_code)) as son_dept_code
         |    from
         |      (
         |        select
         |          dept_code,
         |          dept_type_name,
         |          parent_dept_code
         |        from
         |          gdl.zipper_dim_department
         |        where
         |          dw_start_date <= '$incDay'
         |          and dw_end_date >= '$incDay'
         |          and dept_type_name = '营业站'
         |      ) tmp
         |    group by
         |      tmp.parent_dept_code
         |  ) b on a.parent_dept_code = b.dept_code
         |  where a.un = '40913016'
         |""".stripMargin

    //where tmp1.un in ('40283668','40995757','890733','40699796')
    logger.error("获取员工号hhhh:" + sparkSql)
    val empNoDF = spark.sql(sparkSql)
    empNoDF.show(5)
    val rdd = empNoDF.rdd.repartition(calPartition).map(obj => {
      val ret = new JSONObject()
      val deptCode = if (StringUtils.nonEmpty(obj.getString(2))) obj.getString(2) else ""

      try {
        ret.put("empCode", obj.getString(1))
        ret.put("deptParentCode", obj.getString(5))
        ret.put("cityCode", obj.getString(0))
        ret.put("deptCode", deptCode)
        ret.put("job", obj.getString(3))
        ret.put("prop", obj.getString(4))
        ret.put("sonDeptCode", obj.getString(6))
      } catch {
        case e: Exception =>
          val errorMsg = "method=>fetchEmpNo,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("fetchEmpNo") && !elem.toString.contains("apply")).mkString(";")

          ret.put("fetchEmpNoMsg", errorMsg)
      }

      (ret.getString("empCode"), ret)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("工号数量:" + rdd.count())
    val empCodeList = rdd.keys.collect()
    val empCodeSet = new util.HashSet[String]()
    for (empCode <- empCodeList) {
      empCodeSet.add(empCode)
    }
    logger.error("员工数量:" + empCodeSet.size())
    (empCodeSet, rdd)
  }

  def fetchEmpInfo(spark: SparkSession, incDay: String): RDD[(String, JSONObject)] = {
    val empInfoTable = "gdl.tt_emp_info"
    val sparkSql =
      s"""select tmp1.emp_code,tmp1.position_name,
         |  tmp1.persk_txt,tmp1.dept_code,
         |  regexp_replace(substring(tmp1.dept_code,0,4),'[a-zA-Z]*','') as city_code,
         |  tmp2.parent_dept_code
         |from $empInfoTable tmp1
         |left JOIN
         |(
         |select dept_code,parent_dept_code
         |from gdl.zipper_dim_department
         |where
         | dw_start_date <= '$incDay'
         | and dw_end_date >= '$incDay'
         | and dept_name like '%营业站'
         |) tmp2
         |ON tmp1.dept_code = tmp2.dept_code
         |where tmp1.inc_day='$incDay' and tmp1.emp_code <>''
       """.stripMargin

    logger.error(sparkSql)
    val empNoDF1 = spark.sql(sparkSql)
    empNoDF1.show(5)
    val rdd = empNoDF1.rdd.map(obj => {
      val empNo = obj.getString(0).replaceAll("^(0+)", "")
      val ret = new JSONObject()
      ret.put("job", obj.getString(1))
      ret.put("prop", obj.getString(2))
      ret.put("empDeptCode", obj.getString(3))
      ret.put("empCityCode", obj.getString(4))
      ret.put("empDeptParentCode", obj.getString(5))
      (empNo, ret)
    }).reduceByKey((obj1, _) => {
      obj1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("员工信息数量:" + rdd.count())
    rdd

  }

  def doEmpTotal(empNoRdd: RDD[(String, JSONObject)], empInfoRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val empTotalRdd = empNoRdd.leftOuterJoin(empInfoRdd).map(obj => {
      val leftBody = obj._2._1
      val rightOption = obj._2._2
      if (rightOption.nonEmpty) {
        leftBody.fluentPutAll(rightOption.get)
      }

      var deptCode = leftBody.getString("deptCode")
      val empDeptCode = leftBody.getString("empDeptCode")
      if ((deptCode == null || deptCode.isEmpty)
        && empDeptCode != null && !empDeptCode.isEmpty) {
        leftBody.put("deptCode", empDeptCode)
        deptCode = empDeptCode
      }

      val deptParentCode = leftBody.getString("deptParentCode")
      val empDeptParentCode = leftBody.getString("empDeptParentCode")
      if ((deptParentCode == null || deptParentCode.isEmpty)
        && empDeptParentCode != null && !empDeptParentCode.isEmpty) {
        leftBody.put("deptParentCode", empDeptParentCode)
      }

      val cityCode = leftBody.getString("cityCode")
      val empCityCode = leftBody.getString("empCityCode")
      if ((cityCode == null || cityCode.isEmpty)
        && empCityCode != null && !empCityCode.isEmpty) {
        leftBody.put("cityCode", empCityCode)
      }
      (deptCode, leftBody)
    }).persist(StorageLevel.DISK_ONLY)
    empTotalRdd.take(5).foreach(println)
    logger.error("员工信息总数:" + empTotalRdd.count())
    empNoRdd.unpersist()
    empInfoRdd.unpersist()
    logger.error("关联上的个数:" + empTotalRdd.filter(obj => {
      obj._2.containsKey("job")
    }).count())
    empTotalRdd

  }

  def fetchFvpTimeRdd(spark: SparkSession, incDay: String, sepDate: String): RDD[(String, JSONObject)] = {
    val nextDay = Util.getDay(incDay, 1, "")
    logger.error("incDay:" + incDay + ",nextDay:" + nextDay)
    val incDayLong = getDayLongTime(incDay, "")
    val nextDayLong = getDayLongTime(nextDay, "")
    logger.error("incDay:" + incDayLong + ",nextDay:" + nextDayLong)
    val fvpTimeTable = "ods_kafka_fvp.fvp_core_fact_route_op"
    val sparkSql = s"select couriercode, max(barscantm),min(barscantm) from $fvpTimeTable where inc_day='$incDay' " +
      s" and cast(barscantm as bigint) between $incDayLong and $nextDayLong " +
      s" group by couriercode "
    logger.error(sparkSql)
    val fvpRdd = spark.sql(sparkSql).rdd.map(obj => {
      val ret = new JSONObject()
      val empCode = obj.getString(0).replaceAll("^(0+)", "")
      ret.put("fvpTmMax", obj.getString(1).toLong / 1000)
      ret.put("fvpTmMin", obj.getString(2).toLong / 1000)
      (empCode, ret)
    }).reduceByKey((obj1, obj2) => {
      obj1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("路由表获取时间信息数量：" + fvpRdd.count())
    fvpRdd
  }

  def doJoinFvpTime(empTotalRdd: RDD[(String, JSONObject)],
                    fvpTimeRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val joinFvpTime = empTotalRdd.leftOuterJoin(fvpTimeRdd).map(obj => {
      val leftBody = obj._2._1
      val rightOption = obj._2._2
      if (rightOption.nonEmpty) {
        leftBody.fluentPutAll(rightOption.get)
      }
      (obj._1, leftBody)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("关联路由表时间：" + joinFvpTime.count())
    empTotalRdd.unpersist()
    fvpTimeRdd.unpersist()
    joinFvpTime
  }

  def fetchEmpXy(spark: SparkSession, date: String, empCodeSet: util.HashSet[String]): RDD[(String, JSONObject)] = {
    val sql =
    /* s"""
        |select emp_code,rectifyTrack
        |from dm_gis.vehicle_tracks_rectify where inc_day='$date' and ak=1
        |and regexp_replace(emp_code,'^(0+)','') in ('${empCodeSet.stream().collect(Collectors.joining("','"))}')
      """.stripMargin*/
      s"""
         |select un,rsp,err
         |from dm_gis.path_fix where inc_day='$date'
         | and tp='bike' and regexp_replace(un,'^(0+)','')
         | in ('${empCodeSet.stream().collect(Collectors.joining("','"))}')
       """.stripMargin

    //    logger.error(sql)
    val trackRdd = spark.sql(sql).rdd.map(obj => {
      val ret = new JSONObject()
      val un = obj.getString(0)
      val empCode = obj.getString(0).replaceAll("^(0+)", "")
      val rspStr = obj.getString(1)
      val err = obj.getString(2)
      val result =
        try {
          if (rspStr != null && rspStr != "null" && !rspStr.isEmpty && err != "疑似纠偏异常") {
            val rsp = JSON.parseObject(rspStr)
            val tracks = rsp.getJSONArray("tracks")
            //val tracks = JSON.parseArray(rspStr)
            ret.put("tracksSizeAft", "" + tracks.size())
            val xyArray = new JSONArray()
            if (tracks.size() > 1) {
              ret.put("totalMaxTm", tracks.getJSONObject(tracks.size() - 1).getLong("tm"))
              ret.put("totalMinTm", tracks.getJSONObject(0).getLong("tm"))
            }
            for (i <- 0 until tracks.size()) {
              val item = tracks.getJSONObject(i)
              item.remove("status")
              xyArray.add(item)
            }
            ret.put("xy", xyArray)
            ret.put("trajectory_source","hive")
            (empCode, ret)
          } else {
            //调用轨迹纠偏接口获得小哥轨迹纠偏结果
            val (str,json) = getPathFix(un,date)
            logger.error("#######################################(str,json): " + (str,json))
            Thread.sleep(600000)
            if(json == null && rspStr != null && rspStr != "null" && !rspStr.isEmpty){
              val rsp = JSON.parseObject(rspStr)
              val tracks = rsp.getJSONArray("tracks")
              //val tracks = JSON.parseArray(rspStr)
              ret.put("tracksSizeAft", "" + tracks.size())
              val xyArray = new JSONArray()
              if (tracks.size() > 1) {
                ret.put("totalMaxTm", tracks.getJSONObject(tracks.size() - 1).getLong("tm"))
                ret.put("totalMinTm", tracks.getJSONObject(0).getLong("tm"))
              }
              for (i <- 0 until tracks.size()) {
                val item = tracks.getJSONObject(i)
                item.remove("status")
                xyArray.add(item)
              }
              ret.put("xy", xyArray)
              ret.put("trajectory_source","hive")
              (empCode, ret)
            }else{
              (str,json)
            }
          }
        } catch {
          case e: Exception =>

            val errorMsg = "method=>fetchEmpXy,message=>" + e.fillInStackTrace() + ",stack =>" +
              e.getStackTrace().filter(elem => elem.toString.contains("fetchEmpXy") && !elem.toString.contains("apply")).mkString(";")

            ret.put("fetchEmpXyMsgMap", errorMsg)
            (null,null)
        }


      result
    }).filter(obj => obj._1 != null).groupByKey().map(obj => {
      /*val retList = List[JSONObject]()
      val iter = obj._2.iterator
      while(iter.hasNext){
        val it = iter.next()
        it._1 :: retList
      }*/
      val retList = obj._2.toList
      //val trajectory_source = obj._2.toList.head._2
      val trajectory_source = JSONUtil.getJsonVal(retList.get(0), "trajectory_source", "")
      if (retList.size > 1) {
        //合并不同来源的轨迹数据,取每段轨迹的最大值的轨迹点合并在一起
        val jsonObj = new JSONObject()
        val errMsgJsonArr = new JSONArray()
        try {
          val mergeArray = getMergeArray(retList)

          jsonObj.put("totalMaxTm", mergeArray.getJSONObject(mergeArray.size() - 1).getLong("tm"))
          jsonObj.put("totalMinTm", mergeArray.getJSONObject(0).getLong("tm"))
          jsonObj.put("xy", mergeArray)
          jsonObj.put("trajectory_source",trajectory_source)

        } catch {
          case e: Exception =>
            val errorMsg = "method=>fetchEmpXy,message=>" + e.fillInStackTrace()
            errMsgJsonArr.add(errorMsg)
        }

        jsonObj.put("fetchEmpXyMsgFilter", errMsgJsonArr)

        (obj._1, jsonObj)
      } else {
        val jsonObj = new JSONObject()
        if(retList != null && retList.get(0) != null){
          jsonObj.fluentPutAll(retList.get(0))
          jsonObj.put("trajectory_source",trajectory_source)
        }
        (obj._1, jsonObj)
      }
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("获取数量轨迹数量：" + trackRdd.count())

    trackRdd
  }


  /**
   *
   * @param un
   * @param date
   * @param
   * @return
   */
  def getPathFix(un: String,date: String): (String,JSONObject) = {
    val empCode = un.replaceAll("^(0+)", "")
    val ak = "07c110b3138b46f7883a3c7b8079d520"
    val appCode = "c4ca4238a0b923820dcc509a6f75849b"
    val startDate = date + "000000"
    val endDate = date + "235959"
    val url = "http://gis-int.int.sfdc.com.cn:1080/lsssearch/api/poshisPeriod?ak=%s&appCode=%s&usrNum=%s&startDate=%s&endDate=%s&rarefies=false&tolerance=10&rectify=true"
    val ret: JSONObject = new JSONObject()
    try {
      if (empCode != null && !empCode.isEmpty) {
        val urls = url.format(ak,appCode,un,startDate,endDate)
        val pathFixInfo = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        logger.error("###################################getPathFix resp. pathFixInfo: " + pathFixInfo)
        Thread.sleep(600000)
        if(pathFixInfo == null){
          logger.error("getPathFix resp null. url: " + urls)
          (empCode,null)
        }else{
          val rsJson = JSON.parseObject(pathFixInfo)
          if(rsJson.getInteger("status") == 0){
            val tracks = rsJson.getJSONArray("result")
            if (tracks != null && tracks.size() > 0) {
              ret.put("tracksSizeAft", "" + tracks.size())
              val xyArray = new JSONArray()
              if (tracks.size() > 1) {
                ret.put("totalMaxTm", tracks.getJSONObject(tracks.size() - 1).getLong("tm"))
                ret.put("totalMinTm", tracks.getJSONObject(0).getLong("tm"))
              }
              for (i <- 0 until tracks.size()) {
                val item = tracks.getJSONObject(i)
                val item1 = new JSONObject()
                item1.put("sum_dist","null")
                item1.put("reliable","null")
                item1.put("matchOrder","null")
                item1.put("x",item.get("dx"))
                item1.put("index","null")
                item1.put("y",item.get("dy"))
                item1.put("tm",item.get("tm"))
                item1.put("time","null")
                item1.put("milltime","null")
                item1.put("speed",item.get("sp"))
                xyArray.add(item1)
              }
              ret.put("xy", xyArray)
              ret.put("trajectory_source","interface")
              (empCode,ret)
            }else{
              (empCode,null)
            }
          }else {
            logger.error("getPathFix status = 1. url - {}, resp - {}", urls, rsJson)
            (empCode,null)
          }
        }

      }else{
        (null,null)
      }
    } catch {
      case e: Exception => logger.error("*************************"+e)
        (null,null)
    }
  }

  def getMergeArray(retList: scala.List[JSONObject]): JSONArray = {
    val mergeArray = new JSONArray()
    //获取每条轨迹记录最值有序序列
    var timeList = List[Long]()

    retList.foreach(elem => {
      val xyArray = elem.getJSONArray("xy")
      timeList = xyArray.getJSONObject(0).getLong("tm") :: timeList
      timeList = xyArray.getJSONObject(xyArray.size() - 1).getLong("tm") :: timeList
    })

    timeList = timeList.sortWith(_.compareTo(_) < 0)

    //遍历每条轨迹数据的tm最值,排序后与后一位切割每一条轨迹数据,计算这个时间段内的

    for (i <- 0 until timeList.size - 1) {
      var segList = List[(Double, List[JSONObject])]()

      try {
        retList.foreach(jsonObj => {
          var tmpDis = 0d
          var segJsonList = List[JSONObject]()
          val tracks = jsonObj.getJSONArray("xy")

          if (tracks.size() > 1) {
            for (j <- 0 until tracks.size - 1) {
              val track1 = tracks.getJSONObject(j)
              val tm = track1.getLong("tm")

              if (tm >= timeList(i) && tm <= timeList(i + 1)) {
                val x1 = track1.getDouble("x")
                val y1 = track1.getDouble("y")

                val track2 = tracks.getJSONObject(j + 1)
                val x2 = track2.getDouble("x")
                val y2 = track2.getDouble("y")

                segJsonList = track1 :: segJsonList
                tmpDis += DistanceTool.getGreatCircleDistance(x1, y1, x2, y2) / 1000
              }
            }
          } else if (tracks.size() == 1) {
            segJsonList = tracks.getJSONObject(0) :: segJsonList
          }

          segJsonList = segJsonList.sortBy(_.getInteger("tm"))

          segList = (tmpDis, segJsonList) :: segList
        })


        val maxTracksArray = segList.maxBy(_._1)
        maxTracksArray._2.foreach(one => mergeArray.add(one))

        //每个时间段拐点位置不参与轨迹计算
        mergeArray.add(JSON.parseObject(s"""{"x":-1,"y":-1,"index":0,"tm":${timeList(i + 1)}}"""))
      } catch {
        case e: Exception =>
          throw new RuntimeException("method=>getMergeArray,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("getMergeArray") && !elem.toString.contains("apply")).mkString(";"))
      }
    }

    mergeArray
  }

  def mergeZcPolygon(obj1: JSONObject, obj2: JSONObject): (JSONObject, String) = {
    val polygonJson1 = obj1.getJSONObject("polygonJson")
    val polygonJson2 = obj2.getJSONObject("polygonJson")
    val level1 = obj1.getString("level")

    polygonJson1.fluentPutAll(polygonJson2)

    (polygonJson1, level1)
  }

  def mergeZcCenter(obj1: JSONObject, obj2: JSONObject): JSONObject = {
    val polygonJson1 = obj1.getJSONObject("centerJson")
    val polygonJson2 = obj2.getJSONObject("centerJson")
    polygonJson1.fluentPutAll(polygonJson2)
    polygonJson1
  }

  def createTcZcPolygon(obj: JSONObject): JSONObject = {
    val polygonJson = obj.getJSONObject("polygonJson")
    val centerJson = obj.getJSONObject("centerJson")
    if (polygonJson.isEmpty || centerJson.isEmpty) {
      return null
    }
    val geometryFactory = JTSFactoryFinder.getGeometryFactory(null)
    val ret = new JSONObject()
    val keySet = polygonJson.keySet()
    for (key <- keySet) {
      try {
        ret.put(key, DistanceTool.createMaxRec(geometryFactory, polygonJson.getString(key), centerJson.getString("lng").toDouble, centerJson.getString("lat").toDouble))
      } catch {
        case e: Exception =>
          throw new RuntimeException("method=>createTcZcPolygon,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("createTcZcPolygon") && !elem.toString.contains("apply")).mkString(";"))
      }
    }
    ret
  }

  def fetchZcAoiXyRdd(
                       spark: SparkSession, date: String,
                       empTotalRdd: RDD[(String, JSONObject)]
                     ) = {
    logger.error(">>>从文件获取网点多边形坐标<<<")
    val wktEmap = getDeptWktFromFile("emap_layer_feature.csv")
    val wktEmapBroadcast = spark.sparkContext.broadcast(wktEmap).value
    val wktEfs = getDeptWktFromFile("efs_emap_layer_feature.csv")
    val wktEfsBroadcast = spark.sparkContext.broadcast(wktEfs).value

    logger.error("获取aoi多边形")
    val aoiWktMap = getAoiWktFromFile("合并网点数据_all.csv")
    val aoiWktMapBroadcast = spark.sparkContext.broadcast(aoiWktMap).value

    val sql =
      s"""
         |select if(t1.zno_code='',t1.code,t1.zno_code),t1.geom_wkt,t1.level,t1.lng,t1.lat,t1.type,t1.code
         | from dm_gis.polygon_all t1
         |where t1.inc_day='$date' and t1.state in ('1','3') and t1.type in ('1','3') and level in('4','5')
       """.stripMargin
    println("sql=" + sql)
    val df = spark.sql(sql)
    df.show(5)
    val dicZcHistoryRdd = df.rdd.repartition(calPartition)
      .map(obj => (obj.getString(0), obj))
      .rightOuterJoin(empTotalRdd)
      .map(obj => {
        val leftbody = obj._2._1
        val ret = new JSONObject()
        val polygonJson = new JSONObject()
        val centerJson = new JSONObject()
        var level = ""
        val zc = obj._1

        if (!leftbody.isEmpty) {
          val row = leftbody.get
          row.getString(0)
          val geom_wkt = row.getString(1)
          level = row.getString(2)
          val lng = row.getString(3)
          val lat = row.getString(4)
          val dataType = row.getString(5)


          //如果是1则是网点中心点;如果是7则是单元区域;否则则是网点内的多边形
          if (dataType.equals("1")) {
            centerJson.put("lng", lng)
            centerJson.put("lat", lat)
          } else {
            polygonJson.put(zc, geom_wkt)
          }

        }

        ret.put("level", level)
        ret.put("polygonJson", polygonJson)
        ret.put("centerJson", centerJson)

        (zc, ret)
      }) /*.filter(obj => obj._1 != null)*/ .reduceByKey((obj1, obj2) => {
      val (polygonJson, level) = mergeZcPolygon(obj1, obj2)
      val centerJson = mergeZcCenter(obj1, obj2)
      obj1.put("level", level)
      obj1.put("polygonJson", polygonJson)
      obj1.put("centerJson", centerJson)
      obj1
    }).map(obj => {
      val deptCode = obj._1
      val polygonJson = obj._2.getJSONObject("polygonJson")
      val tmpPolygonDeptJson = new JSONObject()

      //从文件获取没有取到多边形的网点多边形
      if (polygonJson == null && polygonJson.isEmpty) {
        if (wktEmapBroadcast.contains(deptCode)) {
          tmpPolygonDeptJson.put(deptCode, wktEmapBroadcast(deptCode))
          logger.error("######################emap_layer_feature.csv: " + wktEmapBroadcast(deptCode))
          Thread.sleep(120000)
        } else if (wktEfsBroadcast.contains(deptCode)) {
          tmpPolygonDeptJson.put(deptCode, wktEfsBroadcast(deptCode))
          logger.error("######################efs_emap_layer_feature.csv: " + wktEfsBroadcast(deptCode))
          Thread.sleep(120000)
        }

        polygonJson.fluentPutAll(tmpPolygonDeptJson)
      }

      //网点多边形合并aoi多边形
      if (aoiWktMapBroadcast.containsKey(deptCode)) {
        val aoiPolygonString = aoiWktMapBroadcast.getOrElse(obj._1, "")
        logger.error("######################合并网点数据_all.csv: " + aoiWktMapBroadcast.getOrElse(obj._1, ""))
        Thread.sleep(120000)

        if (StringUtils.nonEmpty(aoiPolygonString)) {
          val aoiPolygon = new JSONObject()
          aoiPolygon.put(obj._1 + "_aoi", aoiPolygonString)
          polygonJson.fluentPutAll(aoiPolygon)

          obj._2.put("aoiPolygon", aoiPolygon)
          obj._2.put("polygonJson", polygonJson)
        }
      }

      obj
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(">>>获取网点中心点坐标 [历史变更网点]数据量：" + dicZcHistoryRdd.count())

    dicZcHistoryRdd

    //遍历网点获取营业站上级多边形坐标并合并上级网点多边形
    //getAndMergeParentDept(dicZcHistoryRdd, empParentMap, empLeafMap)
  }


  def getAndMergeParentDept(dicZcHistoryRdd: RDD[(String, JSONObject)]
                            , empParentMap: Map[String, String],
                            empLeafMap: Map[String, scala.List[String]],zcAoiXyRdd1 : RDD[(String, JSONObject)]) = {
    logger.error(">>>开始获取营业站和营业部相关多边形<<<")
    val parentDeptMap = dicZcHistoryRdd
      .flatMap(obj => {
        val deptCode = obj._1
        val jsonObj = obj._2
        var valueList = List[(String, (JSONObject, JSONObject))]()
        val polygonparentJson = jsonObj.getJSONObject("polygonJson")
        val centerJson = jsonObj.getJSONObject("centerJson")

        //获取营业站上级营业部多边形
        empParentMap.map(elem => {
          if (elem._2.equals(deptCode))
            valueList = (elem._1, (centerJson, polygonparentJson)) :: valueList
        })

        valueList
      }).filter(obj => obj._1 != null)
      .collect().toMap
    logger.error(s">>>获取有效的营业站上级网点多边形共:${parentDeptMap.size}<<<")

    val sonDeptMap = dicZcHistoryRdd
      .map(obj => {
        val deptCode = obj._1
        val jsonObj = obj._2
        var value = null: (String, (JSONObject, JSONObject))
        val polygonSonJson = jsonObj.getJSONObject("polygonJson")
        val centerJson = jsonObj.getJSONObject("centerJson")

        //获取营业部下属营业站多边形
        empLeafMap.map(elem => {
          elem._2.map(sonCode => {
            if (sonCode.equals(deptCode)) {

              value = (elem._1, (centerJson, polygonSonJson))
            }
          })
        })

        value
      })
      .filter(_ != null)
      .groupByKey()
      .map(obj => (obj._1, obj._2.toList))
      .collect().toMap

    logger.error(s">>>获取有效的营业部下属网点多边形共:${sonDeptMap.size}<<<")

    //合并营业站上级上级网点多边形
    val dicZcRdd = zcAoiXyRdd1.map(obj => {
      //合并
      val polygonJson = if (obj._2.getJSONObject("polygonJson") != null) obj._2.getJSONObject("polygonJson") else new JSONObject()
      val centerJson = if (obj._2.getJSONObject("centerJson") != null) obj._2.getJSONObject("centerJson") else new JSONObject()

      //营业站
      if (empParentMap.contains(obj._1)) {
        val (centerParentJson, polygonParentJson) = parentDeptMap.getOrElse(obj._1, (null, null))

        if (polygonParentJson != null)
          polygonJson.fluentPutAll(polygonParentJson)

        if (centerParentJson != null)
          centerJson.fluentPutAll(centerParentJson)

        obj._2.put("centerJson", centerJson)
        obj._2.put("polygonJson", polygonJson)
      }

      //营业部
      if (sonDeptMap.contains(obj._1)) {
        val sonDeptPlygonCenterList = sonDeptMap.getOrElse(obj._1, null)

        if (sonDeptPlygonCenterList != null)
          for (elem <- sonDeptPlygonCenterList)
            if (elem != null) {

              if (elem._1 != null)
                centerJson.fluentPutAll(elem._1)
              if (elem._2 != null)
                polygonJson.fluentPutAll(elem._2)

              obj._2.put("centerJson", centerJson)
              obj._2.put("polygonJson", polygonJson)
            }
      }

      obj
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共获取营业站营业部上下级:${dicZcRdd.count()}")
    zcAoiXyRdd1.unpersist()
    dicZcHistoryRdd.unpersist()

    dicZcRdd
  }

  def doJoinEmpXy(joinFvpTime: RDD[(String, JSONObject)], empXy: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val joinEmpXy = joinFvpTime.leftOuterJoin(empXy).map(obj => {
      val leftBody = obj._2._1
      val rightOption = obj._2._2
      if (rightOption.nonEmpty) {

        leftBody.fluentPutAll(rightOption.get)
        val xy = leftBody.getJSONArray("xy")

        if (xy != null && !xy.isEmpty && xy.size() > 1) {
          val minTimeBody = xy.getJSONObject(0)
          leftBody.put("totalMinTm", minTimeBody.getLong("tm"))
          val maxTimeBody = xy.getJSONObject(xy.size() - 1)
          leftBody.put("totalMaxTm", maxTimeBody.getLong("tm"))
        }

      }
      (obj._1, leftBody)
    }).persist(StorageLevel.DISK_ONLY)

    logger.error("关联轨迹后:" + joinEmpXy.count())

    joinFvpTime.unpersist()
    empXy.unpersist()
    joinEmpXy
  }

  def getDeptWktFromFile(fileName: String): Map[String, String] = {
    var wdpOperMap: Map[String, String] = Map()
    val xiaogePath = System.getProperty("user.dir") + "/" + fileName
    val csvReader = new CsvReader(xiaogePath)
    csvReader.setSafetySwitch(false)
    if (csvReader.readRecord()) println("headers:" + csvReader.getValues.mkString(","))

    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val deptcode = row(0)
      val wkt = row(1)
      if (!deptcode.isEmpty && wkt.contains("POLYGON")) {
        wdpOperMap += (deptcode -> wkt)
      }
    }

    logger.error("数量:" + wdpOperMap.size)
    wdpOperMap
  }

  def getAoiWktFromFile(fileName: String): Map[String, String] = {
    var wdpOperMap: Map[String, String] = Map()
    val xiaogePath = System.getProperty("user.dir") + "/" + fileName
    val csvReader = new CsvReader(xiaogePath)
    csvReader.setSafetySwitch(false)
    if (csvReader.readRecord()) println("headers:" + csvReader.getValues.mkString(","))

    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val deptcode = row(1)
      val wkt = row(2)
      if (!deptcode.isEmpty && wkt.contains("POLYGON")) {
        wdpOperMap += (deptcode -> wkt)
      }
    }

    logger.error("数量:" + wdpOperMap.size)
    wdpOperMap
  }

  def doJoinZcXy(empTotalRdd: RDD[(String, JSONObject)], zcXyRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    //关联网点多边形
    val joinZcXy = empTotalRdd.leftOuterJoin(zcXyRdd).map(obj => {
      val empCode = obj._2._1.getString("empCode").replaceAll("^(0+)", "")
      val zcDataOp = obj._2._2//网点多边形信息
      val empJson = obj._2._1//员工网点信息
      var tcZcPolygon = new JSONObject()
      var polygonJson = new JSONObject()

      //如果 当前节点得aoi多边形不为空则合并
      if (zcDataOp.nonEmpty) {
        val zcData = zcDataOp.get
        empJson.fluentPutAll(zcData)
        polygonJson = zcData.getJSONObject("polygonJson")
      }

      //创建网点aoi融合多边形
      try {
        val tcZcPolygonTmp = createTcZcPolygon(empJson)
        tcZcPolygon = if (tcZcPolygonTmp != null) tcZcPolygonTmp else tcZcPolygon
      } catch {
        case e: Exception =>
          val errorMsg = "method=>fetchZcXyRdd,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("fetchZcXyRdd") && !elem.toString.contains("apply")).mkString(";")

          empJson.put("fetchZcXyRddMsg", errorMsg)
      }

      empJson.put("tcZcPolygon", tcZcPolygon)
      empJson.put("polygonJson", polygonJson)

      (empCode, empJson)
    }).map(obj => {
      val deptCode = obj._2.getString("deptCode")
      val deptParentCode = obj._2.getString("deptParentCode")
      val sonDeptCode = obj._2.getString("sonDeptCode")

      val deptJson = new JSONObject()
      if (StringUtils.nonEmpty(deptCode)) {
        deptJson.put(deptCode, 1)
      }
      obj._2.put("deptJson", deptJson)
      obj._2.remove("deptCode")

      val deptParentJson = new JSONObject()
      if (StringUtils.nonEmpty(deptParentCode)) {
        deptParentJson.put(deptParentCode, 1)
      }
      obj._2.put("deptParentJson", deptParentJson)
      obj._2.remove("deptParentCode")


      val deptSonJson = new JSONObject()
      if (StringUtils.nonEmpty(sonDeptCode)) {
        deptSonJson.put(sonDeptCode, 1)
      }
      obj._2.put("deptSonJson", deptSonJson)
      obj._2.remove("sonDeptCode")

      obj
    }).reduceByKey((obj1, obj2) => {
      val deptCodeJson1 = obj1.getJSONObject("deptJson")
      val deptParentJson1 = obj1.getJSONObject("deptParentJson")
      val polygonJson1 = obj1.getJSONObject("polygonJson")
      val tcZcPolygon1 = obj1.getJSONObject("tcZcPolygon")
      val deptSonJson1 = obj1.getJSONObject("deptSonJson")

      val deptCodeJson2 = obj2.getJSONObject("deptJson")
      val deptParentJson2 = obj2.getJSONObject("deptParentJson")
      val polygonJson2 = obj2.getJSONObject("polygonJson")
      val tcZcPolygon2 = obj2.getJSONObject("tcZcPolygon")
      val deptSonJson2 = obj2.getJSONObject("deptSonJson")

      deptCodeJson1.fluentPutAll(deptCodeJson2)
      deptParentJson1.fluentPutAll(deptParentJson2)
      polygonJson1.fluentPutAll(polygonJson2)
      deptSonJson1.fluentPutAll(deptSonJson2)
      tcZcPolygon1.fluentPutAll(tcZcPolygon2)

      obj1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("关联CMS网点坐标：" + joinZcXy.count())

    empTotalRdd.unpersist()
    zcXyRdd.unpersist()

    joinZcXy
  }

  def getDayLongTime(strTime: String, sep: String): Long = {
    var ret: Long = -1
    try {
      ret = Util.timeToLong(strTime, "yyyy" + sep + "MM" + sep + "dd")
    }
    ret
  }

  def fetchXyPolygon(obj: JSONObject, callMethod: String, zcXys: JSONObject, geometryFactory: GeometryFactory, wKTReader: WKTReader): util.ArrayList[Polygon] = {
    val polygonList = new util.ArrayList[Polygon]()
    if (zcXys == null || zcXys.isEmpty) {
      return polygonList
    }
    val zcXyArray = zcXys.keySet()

    for (zc <- zcXyArray) {
      try {
        val zcXy = zcXys.getString(zc)
        if (!zcXy.isEmpty) {
          val point = wKTReader.read(zcXy).asInstanceOf[Polygon]
          polygonList.add(point)
        }
      } catch {
        case e: Exception =>
          val errorMsg = s"method=>$callMethod,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("fetchXyPolygon")
              && !elem.toString.contains("apply")).mkString(";")

          obj.put("fetchXyPolygonMsg", errorMsg)
      }
    }
    polygonList
  }

  def checkCircleIntersects(geometryFactory: GeometryFactory, pointMid: Point, maxAllowDistance: Double, zcXyPolygon: Polygon): Boolean = {
    val circle = DistanceTool.createRingPolygon(geometryFactory, pointMid.getX, pointMid.getY, maxAllowDistance)
    circle.intersects(zcXyPolygon)
  }

  def minxDistanceWithPolygon(point1: Point, zcXys: Array[Coordinate]): Double = {
    var minDistance: Double = 501
    for (point <- zcXys) {
      val tmpDistance = DistanceTool.getGreatCircleDistance(point.x, point.y, point1.getX, point1.getY)
      if (minDistance > tmpDistance) {
        minDistance = tmpDistance
      }
    }
    minDistance
  }

  def checkInZc(point1: Point, point2: Point, geometryFactory: GeometryFactory, zcXyPolygons: util.ArrayList[Polygon]): Boolean = {
    for (i <- 0 until zcXyPolygons.size()) {
      val zcXyPolygon = zcXyPolygons.get(i)

      try {
        if ((point1.within(zcXyPolygon) || checkCircleIntersects(geometryFactory, point1, maxAllowDistance, zcXyPolygon))
          && (point2.within(zcXyPolygon) || checkCircleIntersects(geometryFactory, point2, maxAllowDistance, zcXyPolygon))) {
          return true
        }
      } catch {
        case e: Exception =>
          throw new RuntimeException("method=>checkInZc,message=>" + e.fillInStackTrace() + ",stack =>" + e.getStackTrace().filter(
            elem => elem.toString.contains("checkInZc") && !elem.toString.contains("apply")).mkString(";"))
      }
    }
    false
  }

  def checkInTcZc(point1: Point, point2: Point, geometryFactory: GeometryFactory, tcXyPolygons: util.ArrayList[Polygon]): Boolean = {
    for (i <- 0 until tcXyPolygons.size()) {
      val tcXyPolygon = tcXyPolygons.get(i)
      try {
        if (point1.within(tcXyPolygon)
          && point2.within(tcXyPolygon)) {
          return true
        }
      } catch {
        case e: Exception =>
          throw new RuntimeException("method=>checkInTcZc,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("checkInTcZc") && !elem.toString.contains("apply")).mkString(";"))
      }
    }
    false
  }

  def calDistance(obj: JSONObject, big1500cntAcc: LongAccumulator, big3000cntAcc: LongAccumulator, big60VcntAcc: LongAccumulator): (String, String, String, String, String, String, String, String, JSONObject) = {
    val tracks = obj.getJSONArray("xy")

    if (tracks == null || tracks.size() < 2) {
      logger.error("tracks non")
      return ("", "", "", "", "", "", "", "", obj)
    }

    var disAll: Double = 0
    var disDeptFvp: Double = 0
    var disDept: Double = 0
    var disTc: Double = 0
    var disAllSupply: Double = 0
    var disDeptFvpSupply: Double = 0
    var disDeptSupply: Double = 0
    var disTcSupply: Double = 0

    val chkTcZcStr = new JSONArray()
    val chkZcStr = new JSONArray()
    val errMsgJsonArr = new JSONArray()

    val geometryFactory = JTSFactoryFinder.getGeometryFactory(null)
    val wKTReader = new WKTReader(geometryFactory)

    var zcXyPolygon = new util.ArrayList[Polygon]()
    var tcXyPolygon = new util.ArrayList[Polygon]()
    var aoiXyPolygon = new util.ArrayList[Polygon]()

    val maxFvpTimeLong = if (obj.getLong("fvpTmMax") == null) -1l else obj.getLong("fvpTmMax").toLong
    val minFvpTimeLong = if (obj.getLong("fvpTmMin") == null) -1l else obj.getLong("fvpTmMin").toLong

    try {
      val zcXy = obj.getJSONObject("polygonJson")
      zcXyPolygon = fetchXyPolygon(obj, "polygonJson", zcXy, geometryFactory, wKTReader)
      obj.put("zcXyPolygon", zcXyPolygon.toString)
      //logger.error("zcXyPolygon:" + zcXyPolygon.toString)

      val tcXy = obj.getJSONObject("tcZcPolygon")
      tcXyPolygon = fetchXyPolygon(obj, "tcZcPolygon", tcXy, geometryFactory, wKTReader)
      //logger.error("tcXyPolygon:" + tcXyPolygon.toString)

      for (i <- 0 until tracks.size() - 1) {

        val track1 = tracks.getJSONObject(i)
        val time1 = track1.getLong("tm")
        val x1 = track1.getDouble("x")
        val y1 = track1.getDouble("y")
        val coord1 = new Coordinate(x1, y1)
        val point1 = geometryFactory.createPoint(coord1)
        val track2 = tracks.getJSONObject(i + 1)
        val time2 = track2.getLong("tm")
        val x2 = track2.getDouble("x")
        val y2 = track2.getDouble("y")
        val coord2 = new Coordinate(x2, y2)
        val point2 = geometryFactory.createPoint(coord2)
        val tmpDis = DistanceTool.getGreatCircleDistance(x1, y1, x2, y2)

        /*logger.error("=====================start===================================================")
        logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
        logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
        logger.error("tmpDis:" + tmpDis)
        logger.error("=====================end===================================================")*/

        if (tmpDis <= maxAllowDistance) {
          //全量
          disAll += tmpDis
          /*logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
          logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
          logger.error("tmpDis:" + tmpDis)
          logger.error("disAll:" + disAll)*/

          //判断是否融合里程内
          val chkTcZc = checkInTcZc(point1, point2, geometryFactory, tcXyPolygon)
          chkTcZcStr.add("chkTcZc_" + x1 + "_" + y1 + ":" + chkTcZc)

          if (!tcXyPolygon.isEmpty && chkTcZc) {
            disTc += tmpDis
          }

          val chkZc = checkInZc(point1, point2, geometryFactory, zcXyPolygon)
          chkZcStr.add("chkZc_" + x1 + "_" + y1 + ":" + chkZc)
          //logger.error("chkZc_" + x1 + "_" + y1 + ":" + chkZc)

          //判断网点内及巴枪扫描里程内
          if (!zcXyPolygon.isEmpty && chkZc) {
            disDept += tmpDis
            /*logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
            logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
            logger.error("tmpDis:" + tmpDis)
            logger.error("disDept:" + disDept)*/

            //logger.error("tmpDis小于等于1500 + tmpDis:" + tmpDis)
            if (maxFvpTimeLong != -1 && minFvpTimeLong != -1
              && time1 <= maxFvpTimeLong && time1 >= minFvpTimeLong
              && time2 <= maxFvpTimeLong && time2 >= minFvpTimeLong) {
              disDeptFvp += tmpDis
            }
          }
        } else {
          big1500cntAcc.add(1L)
          val subTm = Math.abs(time2 - time1) / (60.0 * 60.0)
          val v = (tmpDis / 1000.0) / subTm
          //logger.error("v:" + v)
          if (v <= 60) {
            if (tmpDis > 3000) {
              big3000cntAcc.add(1L)
              //              logger.error("tmpDis:" + tmpDis)
              //              logger.error("time2:" + time2)
              //              logger.error("time1:" + time1)
              //              logger.error("subTm:" + subTm)
              //              logger.error("v:" + v)
              val xyGetDistReq = String.format(xyGetDistUrl, x1, y1, x2, y2)
              //logger.error("xyGetDistReq:" + xyGetDistReq)
              val byxyResp = HttpClientUtils.retryGet(xyGetDistReq)
              val jsonObj = JSON.parseObject(byxyResp)
              var dist = try {
                jsonObj.getJSONObject("result").getString("dist")
              } catch {
                case e: Exception => ""
              }
              //logger.error("dist:" + dist)
              if (StringUtils.nonEmpty(dist)) {
                if (dist.toDouble >= tmpDis * 2) {
                  dist = (tmpDis * 2).toString
                }
                //全量
                disAll += dist.toDouble
                /*logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
                logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
                logger.error("dist:" + dist.toDouble)
                logger.error("disAll:" + disAll)*/

                disAllSupply += dist.toDouble

                //判断是否融合里程内
                val chkTcZc = checkInTcZc(point1, point2, geometryFactory, tcXyPolygon)
                chkTcZcStr.add("chkTcZc_" + x1 + "_" + y1 + ":" + chkTcZc)

                if (!tcXyPolygon.isEmpty && chkTcZc) {
                  disTc += dist.toDouble
                  disTcSupply += dist.toDouble
                }

                val chkZc = checkInZc(point1, point2, geometryFactory, zcXyPolygon)
                chkZcStr.add("chkZc_" + x1 + "_" + y1 + ":" + chkZc)
                //logger.error("chkZc_" + x1 + "_" + y1 + ":" + chkZc)

                //判断网点内及巴枪扫描里程内
                if (!zcXyPolygon.isEmpty && chkZc) {
                  disDept += dist.toDouble
                  /*logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
                  logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
                  logger.error("dist:" + dist.toDouble)
                  logger.error("disDept:" + disDept)*/

                  disDeptSupply += dist.toDouble
                  //logger.error("速度<=60并且tmpDis>3000,dist不为空 + dist:" + dist)
                  if (maxFvpTimeLong != -1 && minFvpTimeLong != -1
                    && time1 <= maxFvpTimeLong && time1 >= minFvpTimeLong
                    && time2 <= maxFvpTimeLong && time2 >= minFvpTimeLong) {
                    disDeptFvp += dist.toDouble
                    disDeptFvpSupply += dist.toDouble
                  }
                }
              } else {
                //全量
                disAll += tmpDis
                /*logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
                logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
                logger.error("tmpDis:" + tmpDis)
                logger.error("disAll:" + disAll)*/

                disAllSupply += tmpDis

                //判断是否融合里程内
                val chkTcZc = checkInTcZc(point1, point2, geometryFactory, tcXyPolygon)
                chkTcZcStr.add("chkTcZc_" + x1 + "_" + y1 + ":" + chkTcZc)

                if (!tcXyPolygon.isEmpty && chkTcZc) {
                  disTc += tmpDis
                  disTcSupply += tmpDis
                }

                val chkZc = checkInZc(point1, point2, geometryFactory, zcXyPolygon)
                chkZcStr.add("chkZc_" + x1 + "_" + y1 + ":" + chkZc)
                //logger.error("chkZc_" + x1 + "_" + y1 + ":" + chkZc)

                //判断网点内及巴枪扫描里程内
                if (!zcXyPolygon.isEmpty && chkZc) {
                  disDept += tmpDis
                  /*logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
                  logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
                  logger.error("tmpDis:" + tmpDis)
                  logger.error("disDept:" + disDept)*/

                  disDeptSupply += tmpDis
                  //logger.error("速度<=60并且tmpDis>3000,dist为空 + tmpDis:" + tmpDis)
                  if (maxFvpTimeLong != -1 && minFvpTimeLong != -1
                    && time1 <= maxFvpTimeLong && time1 >= minFvpTimeLong
                    && time2 <= maxFvpTimeLong && time2 >= minFvpTimeLong) {
                    disDeptFvp += tmpDis
                    disDeptFvpSupply += tmpDis
                  }
                }
              }
            } else {
              //全量
              disAll += tmpDis
              /*logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
              logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
              logger.error("tmpDis:" + tmpDis)
              logger.error("disAll:" + disAll)*/

              disAllSupply += tmpDis

              //判断是否融合里程内
              val chkTcZc = checkInTcZc(point1, point2, geometryFactory, tcXyPolygon)
              chkTcZcStr.add("chkTcZc_" + x1 + "_" + y1 + ":" + chkTcZc)

              if (!tcXyPolygon.isEmpty && chkTcZc) {
                disTc += tmpDis
                disTcSupply += tmpDis
              }

              val chkZc = checkInZc(point1, point2, geometryFactory, zcXyPolygon)
              chkZcStr.add("chkZc_" + x1 + "_" + y1 + ":" + chkZc)
              //logger.error("chkZc_" + x1 + "_" + y1 + ":" + chkZc)

              //判断网点内及巴枪扫描里程内
              if (!zcXyPolygon.isEmpty && chkZc) {
                disDept += tmpDis
                /*logger.error("x1:" + x1 + "," + "y1:" + y1 + "," + "time1:" + time1)
                logger.error("x2:" + x2 + "," + "y2:" + y2 + "," + "time2:" + time2)
                logger.error("tmpDis:" + tmpDis)
                logger.error("disDept:" + disDept)*/

                disDeptSupply += tmpDis
                //logger.error("速度<=60并且tmpDis<=3000 + tmpDis:" + tmpDis)
                if (maxFvpTimeLong != -1 && minFvpTimeLong != -1
                  && time1 <= maxFvpTimeLong && time1 >= minFvpTimeLong
                  && time2 <= maxFvpTimeLong && time2 >= minFvpTimeLong) {
                  disDeptFvp += tmpDis
                  disDeptFvpSupply += tmpDis
                }
              }
            }
          } else {
            big60VcntAcc.add(1L)
          }
        }
      }

    } catch {
      case e: Exception =>
        e.printStackTrace()
      //        val errorMsg = "message=>" + e.fillInStackTrace() + ",stack =>" + e.getStackTrace().mkString(";")
      //        errMsgJsonArr.add(errorMsg)
      //
      //        throw e
    }

    obj.put("calDistanceMsg", errMsgJsonArr)
    obj.put("chkTcZcStr", chkTcZcStr)
    obj.put("chkZcStr", chkZcStr)

    var disAllSupplyRet = (disAllSupply / 1000).toString

    var disTcRet = (disTc / 1000).toString
    var disTcSupplyRet = (disTcSupply / 1000).toString

    if (tcXyPolygon.isEmpty) {
      disTcRet = ""
      disTcSupplyRet = ""
    }

    var disDeptRet = (disDept / 1000).toString
    var disDeptSupplyRet = (disDeptSupply / 1000).toString

    if (zcXyPolygon.isEmpty) {
      disDeptRet = ""
      disDeptSupplyRet = ""
    }

    var disDeptFvpRet = (disDeptFvp / 1000).toString
    var disDeptFvpSupplyRet = (disDeptFvpSupply / 1000).toString

    if (zcXyPolygon.isEmpty || maxFvpTimeLong == -1L || minFvpTimeLong == -1L) {
      disDeptFvpRet = ""
      disDeptFvpSupplyRet = ""
    }


    ((disAll / 1000).toString, disDeptRet, disDeptFvpRet, disTcRet, disAllSupplyRet, disDeptSupplyRet, disDeptFvpSupplyRet, disTcSupplyRet, obj)
  }

  def calDistanceRdd(sc: SparkContext, joinZcXyRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    logger.error("计算里程")

    logger.error("joinZcXyRdd cnt:" + joinZcXyRdd.count())
    val big1500cntAcc = sc.longAccumulator("big1500cnt")
    val big3000cntAcc = sc.longAccumulator("big3000cnt")
    val big60VcntAcc = sc.longAccumulator("big60Vcnt")

        logger.error("================40913016====================")
        val nObject = joinZcXyRdd.values.filter(obj => "40913016".equals(JSONUtil.getJsonVal(obj, "empCode", ""))).collect()
        logger.error("nObject:" + nObject(0).toJSONString)
        val (disAll, disDept, disDeptFvp, disTc, disAllSupply, disDeptSupply, disDeptFvpSupply, disTcSupply, jsonObj) = calDistance(nObject(0), big1500cntAcc, big3000cntAcc, big60VcntAcc)
        logger.error("disAll=" + disAll)
        logger.error("disDept=" + disDept)
        logger.error("disDeptFvp=" + disDeptFvp)
        logger.error("disTc=" + disTc)

        logger.error("disAllSupply=" + disAllSupply)
        logger.error("disDeptSupply=" + disDeptSupply)
        logger.error("disDeptFvpSupply=" + disDeptFvpSupply)
        logger.error("disTcSupply=" + disTcSupply)
        logger.error("=================校验40913016结束======================")

    val disRdd = joinZcXyRdd.map(obj => {
      val (disAll, disDept, disDeptFvp, disTc, disAllSupply, disDeptSupply, disDeptFvpSupply, disTcSupply, jsonObj) = calDistance(obj._2, big1500cntAcc, big3000cntAcc, big60VcntAcc)
      jsonObj.put("disAll", disAll)
      jsonObj.put("disDept", disDept)
      jsonObj.put("disDeptFvp", disDeptFvp)
      jsonObj.put("disTc", disTc)

      jsonObj.put("disAllSupply", disAllSupply)
      jsonObj.put("disDeptSupply", disDeptSupply)
      jsonObj.put("disDeptFvpSupply", disDeptFvpSupply)
      jsonObj.put("disTcSupply", disTcSupply)
      (obj._1, jsonObj)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("计算完距离后的数据量:" + disRdd.count())

    logger.error("big1500cntAcc cnt:" + big1500cntAcc.value)
    logger.error("big3000cntAcc cnt:" + big3000cntAcc.value)
    logger.error("big60VcntAcc cnt:" + big60VcntAcc.value)

    joinZcXyRdd.unpersist()

    disRdd
  }

  def saveResult(spark: SparkSession, distanceRdd: RDD[(String, JSONObject)], date: String): Unit = {
    logger.error(">>>保存数据入库<<<")

    if (distanceRdd.count() == 0) {
      logger.error("数据量为0，不保存~")
      return
    }
    //目标库表名称
    //val descDBName = "dm_gis"
    //val descTableName = "xiaoge_path_distance"
    val descDBName = "default"
    val descTableName = "xiaoge_path_distance_tmp"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$date')
         |SELECT
         |	 date_time
         |	,area
         |	,city
         |	,dept_code
         |	,emp_code
         |	,job
         |	,prop
         |	,path_start_time
         |	,path_end_time
         |	,distance_in_dept
         |	,distance_in_waybill_in_dept
         |	,path_start_time_in_waybill
         |	,path_end_time_in_waybillno
         |	,disall
         |	,diszctc
         |	,distaoi
         |	,disall_add
         |	,distance_in_dept_add
         |	,distance_in_waybill_in_dept_add
         |	,diszctc_add
         |  ,trajectory_source
         |FROM xiaoge_path_distance_test
         |""".stripMargin

    try{
      val schemaString = "date_time,area,city,dept_code,emp_code,job,prop,path_start_time,path_end_time" +
        ",distance_in_dept,distance_in_waybill_in_dept,path_start_time_in_waybill,path_end_time_in_waybillno" +
        ",disall,diszctc,distaoi,disall_add,distance_in_dept_add,distance_in_waybill_in_dept_add,diszctc_add,trajectory_source"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)

      val rdd = distanceRdd.values.repartition(savePartition).map(obj => {
        var fvpTmMin = JSONUtil.getJsonVal(obj, "fvpTmMin", "")
        if (!fvpTmMin.isEmpty) {
          fvpTmMin = Util.longToTime(fvpTmMin.toLong * 1000, "yyyy-MM-dd HH:mm:ss")
        }

        var fvpTmMax = JSONUtil.getJsonVal(obj, "fvpTmMax", "")
        if (!fvpTmMax.isEmpty) {
          fvpTmMax = Util.longToTime(fvpTmMax.toLong * 1000, "yyyy-MM-dd HH:mm:ss")
        }

        var totalMinTm = JSONUtil.getJsonVal(obj, "totalMinTm", "")
        if (!totalMinTm.isEmpty) {
          totalMinTm = Util.longToTime(totalMinTm.toLong * 1000, "yyyy-MM-dd HH:mm:ss")
        }

        var totalMaxTm = JSONUtil.getJsonVal(obj, "totalMaxTm", "")
        if (!totalMaxTm.isEmpty) {
          totalMaxTm = Util.longToTime(totalMaxTm.toLong * 1000, "yyyy-MM-dd HH:mm:ss")
        }

        val sb = new StringBuilder()
        sb.append(date).append("\t")
        sb.append("").append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "cityCode", "")).append("\t")
        sb.append(obj.getJSONObject("deptJson").keySet().mkString(";")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "empCode", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "job", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "prop", "")).append("\t")
        sb.append(totalMinTm).append("\t")
        sb.append(totalMaxTm).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disDept", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disDeptFvp", "")).append("\t")
        sb.append(fvpTmMin).append("\t")
        sb.append(fvpTmMax).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disAll", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disTc", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disAoi", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disAllSupply", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disDeptSupply", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disDeptFvpSupply", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "disTcSupply", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "trajectory_source", "hive"))
        sb.toString()
      }).map(_.split("\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
        ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15)
        ,attr(16),attr(17),attr(18),attr(19),attr(20)))

      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("xiaoge_path_distance_test")

      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  def startSta(spark: SparkSession, date: String, sepDate: String): Unit = {
    logger.error("获取员工工号")
    //empNoRdd = (empCode,员工网点信息)
    val (empCodeSet, empNoRdd) = fetchEmpNo(spark, date)
    empCodeSet.take(2).foreach(println(_))
    empNoRdd.take(2).foreach(println(_))
    logger.error("获取属性信息")
    //empInfoRdd = (empCode,员工网点信息)
    val empInfoRdd = fetchEmpInfo(spark, date)
    empInfoRdd.take(2).foreach(println(_))
    logger.error("关联信息表")
    //empTotalRdd = (deptCode, 员工网点信息)
    val empTotalRdd = doEmpTotal(empNoRdd, empInfoRdd)
    empTotalRdd.take(2).foreach(println(_))
    //过滤出营业站映射营业部
    val empParentRDD = empTotalRdd.filter(obj => {
      StringUtils.nonEmpty(obj._2.getString("deptParentCode"))
    }).persist(StorageLevel.DISK_ONLY)
    //empParentMap = (deptCode,deptParentCode)
    val empParentMap = empParentRDD.map(obj => {
      (obj._1, obj._2.getString("deptParentCode"))
    }
    ).collect().toMap
    logger.error(s">>>过滤出营业站映射上级网点共：${empParentMap.size}<<<")
    //empParentRDD1 = (deptParentCode,new JSONObject())
    val empParentRDD1 = empParentRDD.map(obj => {
      (obj._2.getString("deptParentCode"),new JSONObject())
    }).distinct().persist(StorageLevel.DISK_ONLY)
    empParentRDD1.take(2).foreach(println)
    logger.error(s">>>营业站映射上级网点为key：${empParentRDD1.count()}<<<")

    //过滤出营业部下属营业站
    val empLeafRDD = empTotalRdd.filter(obj => {
      StringUtils.nonEmpty(obj._2.getString("sonDeptCode"))
    }).persist(StorageLevel.DISK_ONLY)

    val empLeafMap = empLeafRDD.map(obj => {
        (obj._1, obj._2.getString("sonDeptCode").split(",").toList)
      }
      ).collect().toMap
    logger.error(s">>>过滤出营业部下属网点共：${empLeafMap.size}<<<")
    //empLeafRDD1 = (sonDeptCode,new JSONObject())
    val empLeafRDD1 = empLeafRDD.flatMap(obj => {
      obj._2.getString("sonDeptCode").split(",")
    }).map(obj => (obj,new JSONObject())).distinct().persist(StorageLevel.DISK_ONLY)
    empLeafRDD1.take(2).foreach(println)
    logger.error(s">>>营业部下属网点为key：${empLeafRDD1.count()}<<<")

    logger.error("获取网点以及营业站上级网点aoi多边形数据")
    val zcAoiXyRdd1 = fetchZcAoiXyRdd(spark, date, empTotalRdd)
    Thread.sleep(240000)
    val zcAoiXyRdd2 = fetchZcAoiXyRdd(spark, date, empParentRDD1)
    Thread.sleep(240000)
    val zcAoiXyRdd3 = fetchZcAoiXyRdd(spark, date, empLeafRDD1)
    Thread.sleep(240000)
    val dicZcHistoryRdd = zcAoiXyRdd1.union(zcAoiXyRdd2).union(zcAoiXyRdd3).distinct().persist(StorageLevel.DISK_ONLY)
    dicZcHistoryRdd.take(2).foreach(println)
    logger.error(s">>>获取网点以及营业站上级网点aoi多边形数据量共：${dicZcHistoryRdd.count()}<<<")
    empParentRDD.unpersist()
    empLeafRDD.unpersist()
    empLeafRDD1.unpersist()
    empParentRDD1.unpersist()

    logger.error("遍历网点获取营业站上级多边形坐标并合并上级网点多边形")
    val zcAoiXyRdd  = getAndMergeParentDept(dicZcHistoryRdd, empParentMap, empLeafMap,zcAoiXyRdd1)
    zcAoiXyRdd.take(2).foreach(println(_))
    logger.error("关联小哥网点aoi多边形数据")
    val joinZcXyRdd = doJoinZcXy(empTotalRdd, zcAoiXyRdd)
    joinZcXyRdd.take(2).foreach(println(_))
    logger.error("获取路由表时间信息")
    val fvpTimeRdd = fetchFvpTimeRdd(spark, date, sepDate)
    fvpTimeRdd.take(2).foreach(println(_))
    logger.error("关联路由表时间")
    val joinFvpTime = doJoinFvpTime(joinZcXyRdd, fvpTimeRdd)
    joinFvpTime.take(2).foreach(println(_))
    logger.error("获取小哥纠偏后轨迹")
    val empXy = fetchEmpXy(spark, date, empCodeSet)
    empXy.take(2).foreach(println)
    logger.error("关联轨迹")
    val joinEmpXy = doJoinEmpXy(joinFvpTime, empXy)
    joinEmpXy.take(2).foreach(println)
    logger.error("开始计算里程")
    val distanceRdd = calDistanceRdd(spark.sparkContext, joinEmpXy)
    distanceRdd.take(2).foreach(println)
    logger.error("计算里程完毕")

    logger.error("保存结果")
    //distanceRdd.collect().foreach(logger.error)

    //保存rdd信息入库
    //saveInfo(spark, distanceRdd, date)

    //入库
    //saveResult(spark, distanceRdd, date)

    //distanceRdd.unpersist()
  }

  def saveInfo(spark: SparkSession, distanceRdd: RDD[(String, JSONObject)], date: String): Any = {
    logger.error(">>>保存rdd信息入库<<<")

    //目标库表名称
    val descDBName = "default"
    val descTableName = "xiaoge_path_distance_msg_tmp"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$date')
         |SELECT
         |	 emp_code
         |	,deptjson
         |	,deptsonjson
         |	,deptparentjson
         |	,xy
         |	,polygonjson
         |	,tczcpolygon
         |	,aoipolygonjson
         |	,chktczcstr
         |	,chkaoistr
         |	,chkzcstr
         |	,errmsg
         |	,trajectory_source
         |  ,zcxypolygon
         |FROM xiaoge_path_distance_msg_test
         |""".stripMargin

    try{
      val schemaString = "emp_code,deptjson,deptsonjson,deptparentjson,xy,polygonjson,tczcpolygon,aoipolygonjson" +
        ",chktczcstr,chkaoistr,chkzcstr,errmsg,trajectory_source,zcxypolygon"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)

      val rdd = distanceRdd.map(obj => {
        val jsonObj = obj._2
        val jsonArr = new JSONArray()

        jsonObj.keySet().foreach(key => {
          if (key.contains("Msg")) {
            val json = new JSONObject()
            json.put(key, jsonObj.getString(key))
            jsonArr.add(json)
          }
        })

        jsonObj.put("errMsg", jsonArr)
        jsonObj
      }).repartition(savePartition).map(obj => {
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(obj, "empCode", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "deptJson", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "deptSonJson", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "deptParentJson", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "xy", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "polygonJson", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "tcZcPolygon", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoiPolygon", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "chkTcZcStr", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "chkAoiStr", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "chkZcStr", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "errMsg", "")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "trajectory_source", "hive")).append("\t")
        sb.append(JSONUtil.getJsonVal(obj, "zcXyPolygon", ""))
        sb.toString()
      }).map(_.split("\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
        ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13)))

      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("xiaoge_path_distance_msg_test")

      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }


    return Unit
    //删除45天以前的数据
    //val expiredDay = JavaUtil.dayAddNum(date, -45)
    //val dropExpiredSql = String.format("alter table dm_gis.%s drop if exists partition(inc_day = '%s')", finalTable, expiredDay)
    //logger.error(dropExpiredSql)
    //spark.sql(dropExpiredSql)

    //ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R hdfs://sfbd/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, expiredDay))
    //logger.error(String.format("hdfs dfs -rm -R hdfs://sfbd/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, expiredDay))
  }

  def start(runTime: String, sepTime: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConfOilCost(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    startSta(spark, runTime, sepTime)
    spark.close()
  }
}
