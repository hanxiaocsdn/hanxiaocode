package com.sf.gis.scala.oms_pai.index.idxCompare

import java.text.DecimalFormat

import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.oms_pai.db.{ManagerFactory, RdsManager}
import com.sf.gis.scala.utils.DbUtils
import org.apache.log4j.Logger

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01368078 on 2019/3/18.
 */
class IdxCompare(curSql: String, refSql: String, threshold: Double, columns: Array[String], keyIdxs: Array[Int],
                 numIdxs: Array[Int], rateIdxs: Array[Int], flags: Array[Int], outTable: String) {
  val logger: Logger = Logger.getLogger(classOf[IdxCompare])
  val df = new DecimalFormat("#.##")
  //  val rplmMap = RplmMap.getRplmMap()

  def idxCompare(incDay: String): Unit = {
    val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
    val curIdxs: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, curSql, columns)
    val curMap = arrToMap(curIdxs)
    val refIdxs: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, refSql, columns)
    val refMap = arrToMap(refIdxs)
    val result = compareIdx(curMap, refMap)
    save(result, incDay)
  }

  /**
   * 数组转成Map
   *
   * @param arrBuffer
   * @return
   */
  def arrToMap(arrBuffer: ArrayBuffer[Array[String]]): Map[String, Array[String]] = {
    var map: Map[String, Array[String]] = Map()
    for (arr <- arrBuffer) {
      val keyBuilder = new StringBuilder
      for (i <- 1 until keyIdxs.length)
        keyBuilder.append(arr(keyIdxs(i)))
      map += (keyBuilder.toString() -> arr)
    }
    map
  }

  /**
   * 对比指标
   *
   * @param curMap
   * @param refMap
   * @return
   */
  def compareIdx(curMap: Map[String, Array[String]], refMap: Map[String, Array[String]]): ArrayBuffer[Array[String]] = {
    val result = new ArrayBuffer[Array[String]]
    for (curKey <- curMap.keySet) {
      val curArr = curMap.apply(curKey)
      if (!refMap.contains(curKey)) { //没有参考值
        logger.error(curKey + " no ref data")
      } else {
        val outArr = new Array[String](columns.length)
        val refArr = refMap.apply(curKey)
        for (keyIdx <- keyIdxs) //key值
          outArr(keyIdx) = curArr(keyIdx)

        for (numIdx <- numIdxs) //数量值
          outArr(numIdx) = curArr(numIdx)

        for (rateIdx <- rateIdxs) { //比率值
          var curIdx = curArr(rateIdx)
          if (curIdx == null || "".equals(curIdx)) curIdx = "0"
          var refIdx = refArr(rateIdx)
          if (refIdx == null || "".equals(refIdx)) refIdx = "0"
          val flag = flags(rateIdx)
          val idx = compareIdx(curIdx.toDouble, refIdx.toDouble, flag)
          outArr(rateIdx) = idx
        }
        result += outArr
      }
    }
    result
  }

  /**
   * 对比单个指标
   *
   * @param curIdx
   * @param refIdx
   * @param flag
   * @return
   */
  def compareIdx(curIdx: Double, refIdx: Double, flag: Int): String = {
    var changeDire: String = ""
    var changeRate: String = "-"
    var isEx: String = "FALSE"
    var isRed: String = "FALSE"
    if (refIdx > 0) {
      changeDire = getChangeDire(curIdx, refIdx)
      val changeRate2 = (curIdx / refIdx - 1) * flag
      changeRate = String.format("%s%%", df.format(Math.abs(changeRate2) * 100))
      if (changeRate2 < 0) {
        isRed = "TRUE"
      }

      if (Math.abs(changeRate2) > threshold) {
        isEx = "TRUE"
      }
    }
    val curIdx2 = String.format("%s%%", df.format(Math.abs(curIdx) * 100))
    s"$curIdx2#$changeDire#$changeRate#$isEx#$isRed"
  }

  def getChangeDire(curIdx: Double, refIdx: Double): String = {
    if (curIdx > refIdx)
      "↑"
    else if (curIdx < refIdx)
      "↓"
    else
      ""
  }

  def save(arrayBuffer: ArrayBuffer[Array[String]], incDay: String): Unit = {
    val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
    val dropSql = s"delete from $outTable where STAT_DATE = '$incDay'"
    DbUtils.executeSql(conn, dropSql)
    for (arr <- arrayBuffer) {
      val keys = new Array[String](keyIdxs.length)
      for (idx <- keyIdxs.indices) //key值
        keys(idx) = arr(keyIdxs(idx))
      val id = MD5Util.getMD5(keys.mkString("_")) //生成id

      val sqlBuilder = new StringBuilder
      sqlBuilder.append("insert ignore into ").append(outTable).append(" (ID, THRESHOLD, ")
      for (i <- columns.indices) {
        if (i != columns.length - 1)
          sqlBuilder.append(columns(i)).append(",")
        else
          sqlBuilder.append(columns(i)).append(")")
      }
      sqlBuilder.append(" values(?,?, ")

      for (i <- columns.indices) {
        if (i != columns.length - 1)
          sqlBuilder.append("?, ")
        else
          sqlBuilder.append("?) ")
      }
      val params = new Array[Any](2 + arr.length)
      params(0) = id
      params(1) = threshold
      for (i <- arr.indices)
        params(i + 2) = arr(i)
      DbUtils.execute(conn, sqlBuilder.toString(), params)
    }
  }

}
