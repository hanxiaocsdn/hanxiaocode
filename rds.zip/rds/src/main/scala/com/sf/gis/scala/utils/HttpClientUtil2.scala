//package com.sf.gis.scala.utils
//
//import com.alibaba.fastjson.{JSON, JSONObject}
//import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet}
//import org.apache.http.impl.client.HttpClients
//import org.apache.http.util.EntityUtils
//import org.apache.http.{HttpEntity, HttpStatus}
//import org.apache.log4j.Logger
//
///**
//  * Created by 01375125 on 2018/11/6.
//  * HttpClient工具类
//  */
//object HttpClientUtil2 {
//  val logger:Logger = Logger.getLogger(this.getClass.getName.replaceAll("$",""))
//
//  /**
//    * 访问http请求，返回字符串结果
//    * @param url
//    * @return
//    */
//  def getStrByGet(url:String): String ={
//    val httpClient = HttpClients.createDefault()
//    var stringEntity:String = null
//    val httpGet = new HttpGet(url)
//    var httpResponse:CloseableHttpResponse = null
//
//    try {
//      httpResponse = httpClient.execute(httpGet)
//    } catch {
//      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
//    }
//    if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
//      val httpEntity:HttpEntity = httpResponse.getEntity
//      try
//        stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
//      catch {
//        case e:Exception=>logger.error(">>>获取stringEntity异常："+e)
//      }
//    }
//    httpResponse.close()
//    httpClient.close()
//
//    stringEntity
//  }
//
//  /**
//    * 访问http请求，返回JSON结果
//    * @param url
//    * @return
//    */
//  def getJsonByGet(url:String): JSONObject ={
//    val httpClient = HttpClients.createDefault()
//    var stringEntity:String = null
//    var jsonObj:JSONObject = null
//    val httpGet = new HttpGet(url)
//    var httpResponse:CloseableHttpResponse = null
//
//    try {
//      httpResponse = httpClient.execute(httpGet)
//    } catch {
//      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
//    }
//    if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
//      val httpEntity:HttpEntity = httpResponse.getEntity
//
//      try{
//        stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
//        try {
//          jsonObj = JSON.parseObject(stringEntity)
//        } catch {
//          case e:Exception =>logger.error(">>>结果转换json独享异常："+e)
//        }
//      }
//      catch {
//        case e:Exception=>logger.error(">>>获取stringEntity异常："+e)
//      }
//    }
//    httpResponse.close()
//    httpClient.close()
//
//    jsonObj
//  }
//
//
//}
