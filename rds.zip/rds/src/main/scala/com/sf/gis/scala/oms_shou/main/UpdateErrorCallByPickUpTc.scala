package com.sf.gis.scala.oms_shou.main


import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.oms_shou.db.{ManagerFactory, PrManager}
import com.sf.gis.scala.utils.DateUtil
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}


/**
 * Created by 01374443 on 2019/11/15.
 */
object UpdateErrorCallByPickUpTc {
  def main(args: Array[String]): Unit = {
    new UpdateErrorCallByPickUpTc().start()
  }
}

//noinspection TypeAnnotation
class UpdateErrorCallByPickUpTc extends Serializable {
  @transient lazy val logger: Logger = LoggerFactory.getLogger(classOf[UpdateErrorCallByPickUpTc])
  //起始天数
  val beginDay = -7
  //结束天数
  val endDay = -7
  //hive表
  val rds_oms_from = "dm_gis.gis_rds_omsfrom"
  val tt_pickup_task_ex = "ods_inc_sgs_core.tt_pickup_task_ex"
  val tt_pickup_task = "ods_inc_sgs_core.tt_pickup_task"
  val join_days = 7

  def start(): Unit = {
    val dateList = fetchDate(beginDay, endDay)
    val sc = getSpark
    for (date <- dateList) {
      startUpdate(sc, date)
      startStaCancel(sc, date)
    }
  }

  /**
   * 按天获取关联信息
   *
   * @param inc_day : 日期
   */
  def selectPickUpInfo(sc: SparkSession, inc_day: String): RDD[(String, JSONObject)] = {
    logger.error("日期：" + inc_day)
    val pickup_sql = "select t.order_no,t.create_time,t.locate_code," +
      "get_json_object(ex.content,'$.receiveOrder.orderUnitareaCode') as pickup_tc,t.resource_id," +
      " t.current_state from" +
      " (select inc_day,locate_code,order_no,create_time,task_id,resource_id,current_state from " + tt_pickup_task + " " +
      " where inc_day = '" + inc_day + "' and create_time <> '') t" +
      " left join (select pid,content from " + tt_pickup_task_ex + " where inc_day = '" + inc_day +
      "' and ex_key='RO_INFO' ) ex on t.task_id = ex.pid "
    logger.error(pickup_sql)
    val pickUpRdd = sc.sql(pickup_sql).rdd.repartition(1600).map(obj => {

      val pickUpArray = new JSONArray()
      val rsltTmp = new JSONObject()
      rsltTmp.put("sysorderno", obj.getString(0))
      rsltTmp.put("create_time", obj.getString(1))
      rsltTmp.put("create_day", obj.getString(1).split(" ").apply(0))
      rsltTmp.put("create_time_stamp", DateUtil.formatStr2TimeStamp(obj.getString(1), "yyyy-MM-dd HH:mm:ss"))
      val tmpCityCode = obj.getString(2).split("/")
      var cityCode: String = null
      if (tmpCityCode.size >= 2) {
        cityCode = tmpCityCode.apply(1)
      }
      rsltTmp.put("city_code", cityCode)
      rsltTmp.put("tc", obj.getString(3))
      rsltTmp.put("resource_id", obj.getString(4))
      rsltTmp.put("current_state", obj.getString(5))
      pickUpArray.add(rsltTmp)
      val key = rsltTmp.getString("city_code") + "_" + rsltTmp.getString("sysorderno")
      val rslt = new JSONObject()
      rslt.put("pickup", pickUpArray)
      if (cityCode == null || obj.getString(2).isEmpty || obj.getString(0).isEmpty) {
        (null, null)
      } else {
        (key, rslt)
      }
    }).filter(obj => obj._1 != null)
    pickUpRdd
  }

  /**
   * 获取揽收数据
   *
   * @return
   */
  def selectAllPickUpInfo(sc: SparkSession, inc_day: String): RDD[(String, JSONObject)] = {
    var pickUpRdd: RDD[(String, JSONObject)] = null
    for (i <- 0 until join_days) {
      val endDate = DateUtil.dateBefore("yyyyMMdd", 0 - i, inc_day)
      val tmpRdd = selectPickUpInfo(sc, endDate)
      if (pickUpRdd == null) {
        pickUpRdd = tmpRdd
      } else {
        pickUpRdd = pickUpRdd.union(tmpRdd)
      }
    }
    val rsltRdd = pickUpRdd.reduceByKey((obj1, obj2) => {
      val pickup1 = obj1.getJSONArray("pickup")
      val pickup2 = obj2.getJSONArray("pickup")
      for (i <- 0 until pickup2.size()) {
        pickup1.add(pickup2.get(i))
      }
      obj1
    }).persist(StorageLevel.DISK_ONLY)
    rsltRdd
  }

  /**
   * 获取oms收件
   *
   * @return
   */
  def selectOmsFrom(sc: SparkSession, inc_day: String): (RDD[(String, JSONObject)], RDD[(String, JSONObject)]) = {
    val oms_from_sql = "select sysorderno,inc_day,citycode,if(syncreqdatetime<>'',syncreqdatetime,asyncreqdatetime) as req_time,syncteamcode," +
      "orderno from " + rds_oms_from + " " +
      " where inc_day='" + inc_day + "' and errcallflag='true' and (sysorderno<> '' or orderno<>'') and citycode <> '' and (syncreqdatetime <> '' or asyncreqdatetime<>'') "
    logger.error(oms_from_sql)
    val omsFromRdd = sc.sql(oms_from_sql).rdd.repartition(1600).map(obj => {
      //      val key = obj.getString(2) + "_" + obj.getString(0)
      val rslt = new JSONObject()
      rslt.put("sysorderno", obj.getString(0))
      rslt.put("inc_day", obj.getString(1))
      rslt.put("citycode", obj.getString(2))
      rslt.put("req_time", obj.getString(3))
      rslt.put("req_day", obj.getString(3).split(" ").apply(0))
      rslt.put("req_time_stamp", DateUtil.formatStr2TimeStamp(obj.getString(3), "yyyy-MM-dd HH:mm:ss SSS"))
      rslt.put("syncteamcode", obj.getString(4))
      rslt.put("orderno", obj.getString(5))
      rslt
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("收件日志总量:" + omsFromRdd.count())
    val omsFromSysOrderNoRdd = omsFromRdd.map(obj => {
      if (!obj.getString("sysorderno").isEmpty) {
        val key = obj.getString("citycode") + "_" + obj.getString("sysorderno")
        (key, obj)
      } else {
        (null, null)
      }
    }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error("按sysorderno聚合收件日志总量:" + omsFromSysOrderNoRdd.count())
    val omsFromOrderNoRdd = omsFromRdd.map(obj => {
      if (!obj.getString("orderno").isEmpty) {
        val key = obj.getString("citycode") + "_" + obj.getString("orderno")
        (key, obj)
      } else {
        (null, null)
      }
    }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error("按orderno聚合收件日志总量:" + omsFromOrderNoRdd.count())
    omsFromRdd.unpersist()
    (omsFromSysOrderNoRdd, omsFromOrderNoRdd)
  }

  /**
   * 获取揽收错call数据
   *
   * @return
   */
  def findPickUpErrorCall(sc: SparkSession, inc_day: String): RDD[JSONObject] = {
    logger.error("获取rds收件日志")
    val omsFromRdd = selectOmsFrom(sc, inc_day)
    logger.error("获取揽收信息")
    val pickUpRdd = selectAllPickUpInfo(sc, inc_day)
    logger.error("揽收数量数量:" + pickUpRdd.count())
    logger.error("关联数据错call和揽收")
    val totalRdd = omsFromRdd._1.union(omsFromRdd._2).union(pickUpRdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).map(obj => {
      mergeOmsFromAndPickUp(obj)
    }).filter(_ != null).persist(StorageLevel.DISK_ONLY)
    //    logger.error("sysOrderNo错call揽收数量:" + sysOrderNoRdd.count())
    //    val orderNoRdd = omsFromRdd._2.union(pickUpRdd).reduceByKey((obj1, obj2) => {
    //      obj1.fluentPutAll(obj2)
    //      obj1
    //    }).map(obj => {
    //      mergeOmsFromAndPickUp(obj)
    //    }).filter(_ != null).persist(StorageLevel.DISK_ONLY)
    //    logger.error("orderNo错call揽收数量:" + orderNoRdd.count())
    //    omsFromRdd._1.unpersist()
    //    omsFromRdd._2.unpersist()
    //    pickUpRdd.unpersist()
    //    val totalRdd = sysOrderNoRdd.union(orderNoRdd).persist(StorageLevel.DISK_ONLY)
    logger.error("总错call揽收数量:" + totalRdd.count())
    //    orderNoRdd.unpersist()
    //    sysOrderNoRdd.unpersist()
    totalRdd
  }

  /**
   * 合并揽收和收件日志
   *
   * @return
   */
  def mergeOmsFromAndPickUp(obj: (String, JSONObject)): JSONObject = {
    var rslt: JSONObject = null
    val jObj = obj._2
    val req_time_stamp = jObj.getLong("req_time_stamp")
    //    val req_day = jObj.getString("req_day")
    if (req_time_stamp != null) {
      val syncteam = jObj.getString("syncteamcode")
      val pickUpArray = jObj.getJSONArray("pickup")
      if (pickUpArray != null) {
        for (i <- 0 until pickUpArray.size()) {
          val pickUpObj = pickUpArray.getJSONObject(i)
          //          val create_time_stamp = pickUpObj.getLong("create_time_stamp")
          //          val create_day = pickUpObj.getString("create_day")
          //            if (req_time_stamp >= create_time_stamp - 180000 && req_time_stamp <= create_time_stamp + 180000) {
          //            if(create_day.equals(req_day)){
          rslt = new JSONObject()
          rslt.fluentPutAll(jObj)
          rslt.remove("pickup")
          val pickUpTc = pickUpObj.getString("tc")
          rslt.put("pick_up_tc", pickUpObj.getString("tc"))
          rslt.put("resource_id", pickUpObj.getString("resource_id"))
          rslt.put("current_state", pickUpObj.getString("current_state"))
          if (pickUpTc != null && !pickUpTc.isEmpty && pickUpTc.equals(syncteam)) {
            rslt.put("is_wrong_report", 1)
          } else {
            rslt.put("is_wrong_report", 0)
          }
          //            }
        }
      }
    }
    rslt
  }

  /**
   * 更新已有的错call数据
   *
   */
  def updateErrorCallData(totalPickUpErrorCallRdd: RDD[JSONObject]): Unit = {
    val conn1 = ManagerFactory.createManager(classOf[PrManager]).getConn
    val stmt = conn1.createStatement()
    var count = 0
    val insertMidBuilder = new StringBuilder

    totalPickUpErrorCallRdd.collect().foreach(obj => {
      try {
        insertMidBuilder.append(" update err_call_data set current_state='" + obj.getString("current_state") + "'")
        appendUpdateStringSql(insertMidBuilder, "resource_id", obj.getString("resource_id"))
        appendUpdateStringSql(insertMidBuilder, "pick_up_tc", obj.getString("pick_up_tc"))
        appendUpdateStringSql(insertMidBuilder, "is_wrong_report", obj.getInteger("is_wrong_report") + "")
        insertMidBuilder.append(" where sysorderno='" + obj.getString("sysorderno") + "'")
        insertMidBuilder.append(" and citycode='" + obj.getString("citycode") + "'")
        insertMidBuilder.append(" and req_date='" + obj.getString("inc_day") + "'")
        count = count + 1
        if (count % 10000 == 0) {
          logger.error(">>>count:" + count)
        }
        stmt.execute(insertMidBuilder.toString())
        //          count = 0
        insertMidBuilder.clear()
        //        } else {
        //          insertMidBuilder.append(";")
        //        }
      } catch {
        case e: Exception => logger.error(">>>入mysql操作异常," + e)
      }
    })
    //      if (count != 0) {
    //        logger.error(">>>count:" + count)
    //        try {
    //          stmt.execute(insertMidBuilder.toString())
    //          insertMidBuilder.clear()
    //        } catch {
    //          case e: Exception => logger.error(">>>入mysql操作异常," + e)
    //        }
    //      }
    conn1.close()

  }

  def appendUpdateStringSql(builder: StringBuilder, col: String, v: String): Unit = {
    if (v != null && !"".equals(v))
      builder.append(", ").append(col).append(" = '").append(v).append("'")
  }

  /**
   * 开始更新
   *
   */
  def startUpdate(sc: SparkSession, inc_day: String): Unit = {
    logger.error("获取揽收的错call数据")
    val totalPickUpErrorCallRdd = findPickUpErrorCall(sc, inc_day)
    logger.error("更新已有错call数据")
    updateErrorCallData(totalPickUpErrorCallRdd)
    logger.error("完毕")
  }

  /**
   * 单独收件日志挂接揽收，获取总数量
   */
  def startStaCancel(sc: SparkSession, inc_day: String): Unit = {
    val oms_from_sql = "select sysorderno,inc_day,citycode,if(syncreqdatetime<>'',syncreqdatetime,asyncreqdatetime) as req_time,syncteamcode," +
      "orderno from " + rds_oms_from + " " +
      " where inc_day='" + inc_day + "' and (sysorderno<> '' or orderno<>'') and citycode <> '' and (syncreqdatetime <> '' or asyncreqdatetime<>'') "
    logger.error(oms_from_sql)
    val omsFromRdd = sc.sql(oms_from_sql).rdd.repartition(1600).map(obj => {
      //      val key = obj.getString(2) + "_" + obj.getString(0)
      val rslt = new JSONObject()
      rslt.put("sysorderno", obj.getString(0))
      rslt.put("inc_day", obj.getString(1))
      rslt.put("citycode", obj.getString(2))
      rslt.put("req_time", obj.getString(3))
      rslt.put("req_day", obj.getString(3).split(" ").apply(0))
      rslt.put("req_time_stamp", DateUtil.formatStr2TimeStamp(obj.getString(3), "yyyy-MM-dd HH:mm:ss SSS"))
      rslt.put("syncteamcode", obj.getString(4))
      rslt.put("orderno", obj.getString(5))
      rslt
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("收件日志总量:" + omsFromRdd.count())
    val omsFromSysOrderNoRdd = omsFromRdd.map(obj => {
      if (!obj.getString("sysorderno").isEmpty) {
        val key = obj.getString("citycode") + "_" + obj.getString("sysorderno")
        (key, obj)
      } else {
        (null, null)
      }
    }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error("按sysorderno聚合收件日志总量:" + omsFromSysOrderNoRdd.count())
    val omsFromOrderNoRdd = omsFromRdd.map(obj => {
      if (!obj.getString("orderno").isEmpty) {
        val key = obj.getString("citycode") + "_" + obj.getString("orderno")
        (key, obj)
      } else {
        (null, null)
      }
    }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error("按orderno聚合收件日志总量:" + omsFromOrderNoRdd.count())
    omsFromRdd.unpersist()
    logger.error("获取揽收信息")
    val pickUpRdd = selectAllPickUpInfo(sc, inc_day)
    logger.error("揽收数量数量:" + pickUpRdd.count())
    logger.error("关联数据错call和揽收")
    val totalRdd = omsFromSysOrderNoRdd.union(omsFromOrderNoRdd).union(pickUpRdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).map(obj => {
      mergeOmsFromAndPickUp(obj)
    }).filter(_ != null)
      .filter(obj => "CANCELED".equals(obj.getString("current_state")))
      .persist(StorageLevel.DISK_ONLY)
    totalRdd.map(obj => {
      (obj.getString("citycode"), 1)
    }).reduceByKey((obj1, obj2) => {
      obj1 + obj2
    }).collect().foreach(obj => {
      logger.error(obj._1 + "," + obj._2)
    })
    logger.error("关联数据错call和揽收的CANCELED数量:" + totalRdd.count())
  }

  /**
   * 获取spark实例
   */
  def getSpark: SparkSession = {
    val conf = new SparkConf().setAppName(classOf[UpdateErrorCallByPickUpTc].getName)
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    //    conf.set("spark.executor.instances", "30")
    //    conf.set("spark.executor.memory", "20g")
    //    conf.set("spark.executor.cores", "10")
    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    spark
  }

  /**
   * 获取日期
   *
   * @return
   */
  def fetchDate(beginDay: Int, endDay: Int): List[String] = {
    var dateList: List[String] = List()
    for (i <- beginDay to endDay) {
      dateList = dateList :+ DateUtil.dateBefore("yyyyMMdd", -i)
    }
    logger.error("日期:" + dateList.head + "," + dateList.last)
    dateList
  }


}