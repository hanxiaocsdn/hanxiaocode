package com.sf.gis.scala.oms_pai.handle

import java.io.{BufferedReader, FileInputStream, InputStreamReader}
import java.util

import org.apache.log4j.Logger

/**
  * Created by 01368078 on 2018/10/27.
  */
object ExcXiaogeNo {
  val logger = Logger.getLogger(ExcXiaogeNo.getClass)

  def getExcXiaogeNo(): util.HashSet[String] = {
    val path = System.getProperty("user.dir") + "/xiaogeno_out.csv"
    logger.info("exc xiaoge path :" + path)
    val br = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"))
    br.readLine()
    var line = br.readLine()
    val set = new util.HashSet[String]()
    while(line != null){
      set.add(line.replaceAll("^(0+)", ""))
      line = br.readLine()
    }
    set
  }

  def getExcXiaogeNoNew(): util.HashSet[String] = {
    //    val path = System.getProperty("user.dir") + "/xiaogeno_out.csv"
    val path = "conf/oms_pai/xiaogeno_out.csv"
    logger.info("exc xiaoge path :" + path)
    val br = new BufferedReader(new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream(path), "utf-8"))
    br.readLine()
    var line = br.readLine()
    val set = new util.HashSet[String]()
    while (line != null) {
      set.add(line.replaceAll("^(0+)", ""))
      line = br.readLine()
    }
    set
  }

  def main(args: Array[String]): Unit = {
    println(getExcXiaogeNo())
  }
}
