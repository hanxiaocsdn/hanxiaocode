//package com.sf.gis.scala.utils;
//
//import java.text.SimpleDateFormat;
//
//public class IDGenerator {
//	private static  long milli;
//	private static int index = 0;
//
//	public static  synchronized String getID(String suffix){
//		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmssSSS");
//		long tmp = System.currentTimeMillis();
//		if(milli == tmp){
//			return sdf.format(tmp) + "" + index++ + "_" + suffix;
//		}else{
//			index = 1;
//			milli = tmp;
//			return  sdf.format(tmp) + "0" + "_" + suffix;
//		}
//	}
//
//	public static void main(String[] args){
//		System.out.println(getID("321"));
//	}
//
//}
