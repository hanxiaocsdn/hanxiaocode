package com.sf.gis.scala.oms_pai.db;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.sf.gis.scala.utils.ConfigurationUtil;
import org.apache.log4j.Logger;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;


public class RdsManager implements IManager{
    private static RdsManager instance;
    private static ComboPooledDataSource dataSource;
    private static Logger logger = Logger.getLogger(RdsManager.class);
    private static Properties props =null;

    private RdsManager() throws PropertyVetoException {
        dataSource = new ComboPooledDataSource();

        dataSource.setDriverClass(props.getProperty("driver"));
        dataSource.setJdbcUrl(props.getProperty("url"));
        dataSource.setUser(props.getProperty("username"));
        dataSource.setPassword(props.getProperty("password"));
        dataSource.setInitialPoolSize(Integer.parseInt(props.getProperty("initialPoolSize")));
        dataSource.setMinPoolSize(Integer.parseInt(props.getProperty("minPoolSize")));
        dataSource.setMaxPoolSize(Integer.parseInt(props.getProperty("maxPoolSize")));
        dataSource.setMaxStatements(Integer.parseInt(props.getProperty("maxStatement")));
        dataSource.setMaxIdleTime(Integer.parseInt(props.getProperty("maxIdleTime")));
    }

    public static RdsManager getInstance(String fileName){
        if(instance == null){
            synchronized (RdsManager.class){
                if(instance == null)
                    try {
                        props = ConfigurationUtil.loadProperties(fileName);
                        instance = new RdsManager();
                    } catch (PropertyVetoException e) {
                        logger.error("创建数据库连接池异常", e);
                    }
            }
        }
        return instance;
    }

    @Override
    public Connection getConn(){
        Connection conn = null;
        try {
            conn = dataSource.getConnection();
        } catch (SQLException e) {
            logger.error(String.format("获取数据库连接异常:driver-%s,db-%s,user-%s,passwd-%s", props.getProperty("driver"),
                    props.getProperty("url"), props.getProperty("username"), props.getProperty("password")), e);
        }
        return conn;
    }
}
