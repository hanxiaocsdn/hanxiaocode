package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_pai.start.JavaUtil
import com.sf.gis.scala.utils.{DbUtils, StringUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * 解析oms日志
 * Created by 01368078 on 2018/5/23.
 */
object ParseOmsLog {
  val logger: Logger = Logger.getLogger(this.getClass.getSimpleName.replace("$", ""))

  /**
   * 获取未匹配上oms的无Gid、请求数据
   *
   * @param date             :日期
   * @param formatedLogMerge : 正常日志
   * @param arssLogRddNoReq  : 无请求的审补日志
   * @param arssLogRddNoGid  : 无gid的审补日志
   * @return
   */
  def findNoMatchNoRelateWaybillData(date: String, formatedLogMerge: RDD[JSONObject],
                                     arssLogRddNoReq: RDD[(String, JSONObject)],
                                     arssLogRddNoGid: RDD[(String, JSONObject)],
                                     logRddAsync: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    //获取未匹配的无请求数据
    val matchedNoReqRdd: RDD[(String, String)] = formatedLogMerge.filter(obj => {
      var flag = false
      val noReq_data = obj.getJSONArray("no_req_data")
      if (noReq_data != null && noReq_data.size() != 0) {
        flag = true
      }
      flag
    }).map(obj => {
      val req_body = obj.getJSONObject("req_body")
      val wayblliNo = req_body.getString("waybillNo")
      (wayblliNo, wayblliNo)
    })
    //    logger.error(">>>匹配到oms的无请求数据量：" + matchedNoReqRdd.count())
    //    matchedNoReqRdd.take(3).foreach(o => println(o))
    val noMatchedNoReqRdd: RDD[(String, JSONObject)] = arssLogRddNoReq.filter(obj => obj._2.getString("async_time").contains(date)).leftOuterJoin(matchedNoReqRdd)
      .filter(obj => obj._2._2.isEmpty).map(obj => {
      val data = new JSONArray()
      data.add(obj._2._1)
      (obj._1, data)
    }).reduceByKey((o1, o2) => {
      for (i <- 0 until o2.size()) {
        o1.add(o2.get(i))
      }
      o1
    }).map(obj => {
      val data = new JSONObject()
      //      data.put("waybillNo",obj._1)
      data.put("oms_no_req_data", obj._2)
      (obj._1, data)
    })
    //  .persist(StorageLevel.DISK_ONLY)
    //    logger.error(">>>未匹配到oms的无请求数据量：" + noMatchedNoReqRdd.count())
    //    noMatchedNoReqRdd.take(3).foreach(o=>print(o))

    //获取未匹配的无Gid数据
    val matchedNoGidRdd: RDD[(String, String)] = formatedLogMerge.filter(obj => {
      var flag = false
      val noGid_data = obj.getJSONArray("no_gid_data")
      if (noGid_data != null && noGid_data.size() != 0) {
        flag = true
      }
      flag
    }).map(obj => {
      val req_body = obj.getJSONObject("req_body")
      val wayblliNo = req_body.getString("waybillNo")
      (wayblliNo, wayblliNo)
    })
    //    logger.error(">>>匹配到oms的无Gid数据量：" + matchedNoGidRdd.count())
    //    matchedNoGidRdd.take(3).foreach(o => println(o))
    val noMatchedNoGidRdd: RDD[(String, JSONObject)] = arssLogRddNoGid.filter(obj => obj._2.getString("async_time").contains(date)).leftOuterJoin(matchedNoGidRdd)
      .filter(obj => obj._2._2.isEmpty).map(obj => {
      val data = new JSONArray()
      data.add(obj._2._1)
      (obj._1, data)
    }).reduceByKey((o1, o2) => {
      for (i <- 0 until o2.size()) {
        o1.add(o2.get(i))
      }
      o1
    }).map(obj => {
      val data = new JSONObject()
      //      data.put("waybillNo",obj._1)
      data.put("oms_no_gid_data", obj._2)
      (obj._1, data)
    })
    //  .persist(StorageLevel.DISK_ONLY)
    //    logger.error(">>>未匹配到oms的无Gid数据量：" + noMatchedNoGidRdd.count())
    //获取未匹配的异步数据
    val matchedAsyncRdd: RDD[(String, String)] = formatedLogMerge.filter(obj => {
      var flag = false
      val async_data = obj.getJSONArray("async_data")
      if (async_data != null && async_data.size() != 0) {
        flag = true
      }
      flag
    }).map(obj => {
      val req_body = obj.getJSONObject("req_body")
      val wayblliNo = req_body.getString("waybillNo")
      (wayblliNo, wayblliNo)
    })
    //    logger.error(">>>匹配到oms的async数据量：" + matchedAsyncRdd.count())
    //    matchedAsyncRdd.take(3).foreach(o => println(o))
    val noMatchedAsyncRdd: RDD[(String, JSONObject)] = logRddAsync.filter(obj => obj._2.getString("async_time").contains(date)).leftOuterJoin(matchedAsyncRdd)
      .filter(obj => obj._2._2.isEmpty).map(obj => {
      val data = new JSONArray()
      data.add(obj._2._1)
      (obj._1, data)
    }).reduceByKey((o1, o2) => {
      for (i <- 0 until o2.size()) {
        o1.add(o2.get(i))
      }
      o1
    }).map(obj => {
      val data = new JSONObject()
      //      data.put("waybillNo",obj._1)
      data.put("oms_async_data", obj._2)
      (obj._1, data)
    })
    //  .persist(StorageLevel.DISK_ONLY)
    //    logger.error(">>>未匹配到oms的async数据量：" + noMatchedAsyncRdd.count())
    //    noMatchedNoGidRdd.take(3).foreach(o=>print(o))
    //合并为未匹配的数据
    val noMatched: RDD[(String, JSONObject)] = noMatchedNoReqRdd.union(noMatchedNoGidRdd).union(noMatchedAsyncRdd).reduceByKey((o1, o2) => {
      o1.fluentPutAll(o2)
      o1
    }).persist(StorageLevel.DISK_ONLY)
    //    noMatchedNoReqRdd.unpersist()
    //    noMatchedNoGidRdd.unpersist()
    //    noMatchedAsyncRdd.unpersist()
    logger.error(">>>未匹配到oms的数据量：" + noMatched.count())
    //    noMatched.take(3).foreach(o=>print(o))
    noMatched
  }

  def mergeArssData(o1: JSONObject, o2: JSONObject) = {
    //先合并，在赋值
    val arss_dept_req_array = JSONUtil.mergeJSONArrayItem(o1.getJSONArray("arss_dept_req_array"), o2.getJSONArray("arss_dept_req_array"))
    val arss_dept_re_array = JSONUtil.mergeJSONArrayItem(o1.getJSONArray("arss_dept_re_array"), o2.getJSONArray("arss_dept_re_array"))
    o1.fluentPutAll(o2)

    if(arss_dept_req_array!=null){
      o1.put("arss_dept_req_array", arss_dept_req_array)
    }
    if(arss_dept_re_array != null){
      o1.put("arss_dept_re_array", arss_dept_re_array)
    }
  }

  /**
   * 合并需要的字段,提取合并后的字段
   *
   * @param o1
   * @param o2
   */
  def mergeMutilData(o1: JSONObject, o2: JSONObject) = {
    val retJson = new JSONObject()
    //atpai报文，如果经过电话配置，则会出现两次调用，在此合并，只保留最后一条报文
    mergeMutilDataDetail(o1, o2, retJson, "atpai_time", "atpai_body")
    //gid_sys_body是atpai访问的衍生品，也需要这么做
    mergeMutilDataDetail(o1, o2, retJson, "gis_to_sys_time", "gis_to_sys_body")
    retJson
  }

  def mergeMutilDataDetail(o1: JSONObject, o2: JSONObject, ret: JSONObject, comparekey: String, valueKey: String): Unit = {
    val value1 = o1.getJSONObject(valueKey)
    val compareData1 = o1.getString(comparekey)
    val value2 = o2.getJSONObject(valueKey)
    val compareData2 = o2.getString(comparekey)
    if (value1 != null && value2 != null) {
      //只有同时存在才需要合并，否则走外部正常流程即可
      if (compareData1.compareTo(compareData2) >= 0) {
        ret.put(comparekey, compareData1)
        ret.put(valueKey, value1)
      } else {
        ret.put(comparekey, compareData2)
        ret.put(valueKey, value2)
      }
    }
  }

  /**
   * 解析日志数据
   *
   * @param validLineRdd : 日志rdd
   * @param date         : 日期
   * @return
   */
  def parseOmsLog(spark: SparkSession, validLineRdd: RDD[String], date: String, javaUtil: JavaUtil): (RDD[JSONObject], RDD[(String, JSONObject)]) = {
    //解析非审补的数据
    val otherLogRdd: RDD[(String, JSONObject)] = validLineRdd.flatMap(line => {
      parserOneLine(line).iterator()
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>非审补数据：" + otherLogRdd.count())
    if(OmsDayIndexMain.testSingleWaybill){
      otherLogRdd.take(100).foreach(obj=>{
        logger.error("非审补数据"+obj)
      })
    }
    //解析审补的数据,审补的数据reqId需要计算 做二次关联
    val arssLogRdd: RDD[(String, JSONObject)] = validLineRdd.flatMap(line => {
      parseReqId(line).iterator()
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>审补数据：" + arssLogRdd.count())
    validLineRdd.unpersist()
    if(OmsDayIndexMain.testSingleWaybill){
      arssLogRdd.take(100).foreach(obj=>{
        logger.error("审补数据"+obj)
      })
    }
    val arssLogRddNoGid: RDD[(String, JSONObject)] = arssLogRdd.map(obj => {
      var waybillNo: String = null
      if (obj._1 == null) {
        val async_data_time = obj._2.getString("async_time")
        if (async_data_time != null) {
          waybillNo = obj._2.getString("async_waybillNo")
        }
      }
      (waybillNo, obj._2)
    }).filter(_._1 != null)
      .persist(StorageLevel.DISK_ONLY)
    logger.error(">>>无gid的数据:" + arssLogRddNoGid.count())
    if(OmsDayIndexMain.testSingleWaybill){
      arssLogRddNoGid.take(100).foreach(obj=>{
        logger.error("无gid的数据"+obj)
      })
    }
    val arssLogRddGid = arssLogRdd.filter(_._1 != null)
      .reduceByKey((o1, o2) => {
        val async_time1 = o1.getString("async_time")
        val async_time2 = o2.getString("async_time")
        mergeArssData(o1, o2)
        if (async_time1 != null && async_time2 != null) {
          if (async_time1.contains(date)) {
            o1.put("async_time", async_time1)
          } else if (async_time2.contains(date)) {
            o1.put("async_time", async_time2)
          } else {
            o1.put("async_time", async_time1)
          }
        }
        o1
      }).map(_._2).map(obj => {
      val reqId = obj.getString("reqId")
      (reqId, obj)
    })
      .persist(StorageLevel.DISK_ONLY)
    logger.error(">>>包含gid的数据数量：" + arssLogRddGid.count())
    arssLogRdd.unpersist()
    if(OmsDayIndexMain.testSingleWaybill){
      arssLogRddGid.take(100).foreach(obj=>{
        logger.error("包含gid的数据数量"+obj)
      })
    }
    val arssLogRddOms = arssLogRddGid.filter(_._1 != null)
      .persist(StorageLevel.DISK_ONLY)
    logger.error(">>>有请求的数据:" + arssLogRddOms.count())
    if(OmsDayIndexMain.testSingleWaybill){
      arssLogRddOms.take(100).foreach(obj=>{
        logger.error("有请求的数据"+obj)
      })
    }
    //    arssLogRddOms.take(3).foreach(o=>println(o))
    //    Thread.sleep(1000*60*60)
    //没有关联oms请求的数据
    val arssLogRddNoReq: RDD[(String, JSONObject)] = arssLogRddGid.map(obj => {
      var waybillNo: String = null
      if (obj._1 == null) {
        val async_data_time = obj._2.getString("async_time")
        if (async_data_time != null) {
          waybillNo = obj._2.getString("async_waybillNo")
        }
      }
      (waybillNo, obj._2)
    }).filter(_._1 != null)
      .persist(StorageLevel.DISK_ONLY)
    logger.error(">>>无请求的数据:" + arssLogRddNoReq.count())
    if(OmsDayIndexMain.testSingleWaybill){
      arssLogRddNoReq.take(100).foreach(obj=>{
        logger.error("无请求的数据"+obj)
      })
    }
    //    arssLogRddNoReq.take(3).foreach(o=>println(o))
    arssLogRddGid.unpersist()
    logger.error(">>>关联数据oms请求数据")
    //将解析的所有数据通过reqId关联在一起
    val formatedLog: RDD[JSONObject] = arssLogRddOms.union(otherLogRdd).reduceByKey((o1, o2) => {
      //先合并，在赋值
      val tmpMergerObj = mergeMutilData(o1, o2)
      val bid_req_body = JSONUtil.mergeJSONArrayItem(o1.getJSONArray("bid_req_body"), o2.getJSONArray("bid_req_body"))
      val bid_re_body = JSONUtil.mergeJSONArrayItem(o1.getJSONArray("bid_re_body"), o2.getJSONArray("bid_re_body"))
      mergeMutiBody(o1, o2, "re_body", putAll = true)
      o1.fluentPutAll(tmpMergerObj);
      if(bid_req_body!=null){
        o1.put("bid_req_body", bid_req_body)
      }
      if(bid_re_body!=null) {
        o1.put("bid_re_body", bid_re_body)
      }
      o1
    }).map(_._2).filter(json => {
      //只要incDay的数据，并且要有请求
      var flag = false
      val req_time = json.getString("req_time")
      val async_data_time = json.getString("async_time")
      if ((req_time != null && req_time.contains(date)) || async_data_time != null) {
        flag = true
      }
      val repeatMark = JSONUtil.getJsonValSingle(json,"repeatMark","")
      if("1".equals(repeatMark)){
        flag = false;
      }
      flag
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("总数据量:" + formatedLog.count())

    //    System.exit(0)
    if(OmsDayIndexMain.testSingleWaybill){
      formatedLog.take(100).foreach(obj=>{
        logger.error("总数据量"+obj)
      })
    }
//    if(OmsDayIndexMain.testSingleWaybill){
//      Thread.sleep(15*60*1000)
//    }
    arssLogRddOms.unpersist()
    otherLogRdd.unpersist()
    logger.error(">>>合并异步审补数据(requestid和oms请求不一致)、无oms请求数据(主动上报)")
    val formatedLogMerge = mergeAsyncData(formatedLog, date, arssLogRddNoReq, arssLogRddNoGid)
    //    formatedLog.unpersist()
    logger.error("关联后的总数据量:" + formatedLogMerge.count())
    Spark.clearPersistWithoutId(spark, formatedLogMerge.id)
    //    logger.error(">>>无oms请求数据(主动上报)，没关联上oms运单的数据,比如跨天")
    //    val arssLogRddNoMatchWaybill: RDD[(String, JSONObject)] = findNoMatchNoRelateWaybillData(date, formatedLogMerge, arssLogRddNoReq, arssLogRddNoGid, logRddAsync)
    //    logger.error("关联后的未匹配数据量:" + arssLogRddNoMatchWaybill.count())
    //    arssLogRddNoGid.unpersist()
    //    arssLogRddNoReq.unpersist()
    //    logRddAsync.unpersist()

    logger.error(">>>标准化城市的大区和城市的对应关系")
    val standardLog = getStandardLogRdd(formatedLogMerge, javaUtil)
    formatedLogMerge.unpersist()
    (standardLog, null)
  }


  def checkEmptyReqGid(str: String): Boolean = {
    StringUtil.isBlank(str) || "null".equals(str)
  }

  /**
   * 合并多个相同body
   *
   * @param o1
   * @param o2
   */
  def mergeMutiBody(o1: JSONObject, o2: JSONObject, key: String, putAll: Boolean): Unit = {
    val reBody1: JSONArray = o1.getJSONArray(key)
    val reBody2: JSONArray = o2.getJSONArray(key)
    if (putAll) {
      o1.fluentPutAll(o2)
    }
    if (reBody1 != null && reBody2 != null) {
      for (i <- 0 until reBody2.size()) {
        reBody1.add(reBody2.get(i))
      }
      o2.remove(key)
      o1.put(key, reBody1)
    } else if (reBody1 == null && reBody2 != null) {
      o2.remove(key)
      o1.put(key, reBody2)
    }
  }

  /**
   * 将无请求数据填补到oms请求中
   *
   * @param omsObj
   * @param noReqObj
   */
  def mergeNotSyncDataToOmsBody(omsObj: JSONObject, noReqObj: JSONObject): Unit = {
    //先合并，在赋值,再删除
    val arss_dept_req_array = JSONUtil.mergeJSONArrayItem(omsObj.getJSONArray("arss_dept_req_array"), noReqObj.getJSONArray("arss_dept_req_array"))
    omsObj.put("arss_dept_req_array", arss_dept_req_array)
    noReqObj.remove("arss_dept_req_array")
    val arss_dept_re_array = JSONUtil.mergeJSONArrayItem(omsObj.getJSONArray("arss_dept_re_array"), noReqObj.getJSONArray("arss_dept_re_array"))
    omsObj.put("arss_dept_re_array", arss_dept_re_array)
    noReqObj.remove("arss_dept_re_array")

    if (!omsObj.containsKey("aoi_dept_req_body")) {
      val arssDeptReBody = noReqObj.getJSONObject("aoi_dept_req_body")
      if (arssDeptReBody != null) {
        omsObj.put("aoi_dept_req_body", arssDeptReBody)
        noReqObj.remove("aoi_dept_req_body")
      }
    }
    if (!omsObj.containsKey("aoi_dept_re_body")) {
      val arssDeptReBody = noReqObj.getJSONObject("aoi_dept_re_body")
      if (arssDeptReBody != null) {
        omsObj.put("aoi_dept_re_body", arssDeptReBody)
        noReqObj.remove("aoi_dept_re_body")
      }
    }
    if (!omsObj.containsKey("address_unkow_check_body")) {
      val arssDeptReBody = noReqObj.getJSONObject("address_unkow_check_body")
      if (arssDeptReBody != null) {
        omsObj.put("address_unkow_check_body", arssDeptReBody)
        noReqObj.remove("address_unkow_check_body")
      }
    }
  }

  def mergeAoiDeptData(omsObj: JSONObject, noReqObj: JSONObject) = {
    //合并aoi_data
    val aoi_dept_re = omsObj.getJSONObject("aoi_dept_re_body")
    val aoi_dept_re_merge = new JSONArray()
    if (aoi_dept_re != null) {
      aoi_dept_re_merge.add(aoi_dept_re)
    }
    if (noReqObj != null) {
      val aoi_dept_re_array = noReqObj.getJSONArray("aoi_dept_re_array")
      if (aoi_dept_re_array != null && aoi_dept_re_array.size() > 0) {
        for (i <- 0 until aoi_dept_re_array.size()) {
          val aoi_dept_re_item = aoi_dept_re_array.getJSONObject(i)
          aoi_dept_re_merge.add(aoi_dept_re_item)
        }
      }
    }


    val aoi_dept_req = omsObj.getJSONObject("aoi_dept_req_body")
    val aoi_dept_req_merge = new JSONArray()
    if (aoi_dept_req != null) {
      aoi_dept_req_merge.add(aoi_dept_req)
    }
    if (noReqObj != null) {
      val aoi_dept_req_array = noReqObj.getJSONArray("aoi_dept_req_array")
      if (aoi_dept_req_array != null && aoi_dept_req_array.size() > 0) {
        for (i <- 0 until aoi_dept_req_array.size()) {
          val aoi_dept_req_item = aoi_dept_req_array.getJSONObject(i)
          aoi_dept_req_merge.add(aoi_dept_req_item)
        }
      }
    }
    if (aoi_dept_req_merge.size() != 0) {
      omsObj.put("aoi_dept_req_body", aoi_dept_req_merge)
    } else if (omsObj.containsKey("aoi_dept_req_body")) {
      omsObj.remove("aoi_dept_req_body")
    }
    if (aoi_dept_re_merge.size() != 0) {
      omsObj.put("aoi_dept_re_body", aoi_dept_re_merge)
    } else if (omsObj.containsKey("aoi_dept_re_body")) {
      omsObj.remove("aoi_dept_re_body")
    }
  }

  def mergeNotSyncDataToOmsBodyNew(omsObj: JSONObject, noReqObj: JSONObject): Unit = {
    //先合并，在赋值,再删除
    val arss_dept_req_array = JSONUtil.mergeJSONArrayItem(omsObj.getJSONArray("arss_dept_req_array"), noReqObj.getJSONArray("arss_dept_req_array"))
    if(arss_dept_req_array!=null){
      omsObj.put("arss_dept_req_array", arss_dept_req_array)
    }
    noReqObj.remove("arss_dept_req_array")
    val arss_dept_re_array = JSONUtil.mergeJSONArrayItem(omsObj.getJSONArray("arss_dept_re_array"), noReqObj.getJSONArray("arss_dept_re_array"))
    if(arss_dept_re_array!=null) {
      omsObj.put("arss_dept_re_array", arss_dept_re_array)
    }
    noReqObj.remove("arss_dept_re_array")


    mergeKsData(omsObj, noReqObj)
    if (!omsObj.containsKey("address_unkow_check_body")) {
      val addressUnkowCheckBody = noReqObj.getJSONObject("address_unkow_check_body")
      if (addressUnkowCheckBody != null) {
        omsObj.put("address_unkow_check_body", addressUnkowCheckBody)
        noReqObj.remove("address_unkow_check_body")
      }
    }
  }

  /**
   * 将无请求数据填补到oms请求中
   *
   * @param omsObj
   * @param noReqObj
   */
  def mergeNotSyncData(omsObj: JSONObject, noReqObj: JSONObject): Unit = {
    //先合并，在赋值,再删除

    val aoi_dept_req_array = JSONUtil.mergeJSONArrayItem(omsObj.getJSONArray("aoi_dept_req_array"), noReqObj.getJSONArray("aoi_dept_req_array"))
    if(aoi_dept_req_array!=null){
      omsObj.put("aoi_dept_req_array", aoi_dept_req_array)
    }
    noReqObj.remove("aoi_dept_req_array")
    val aoi_dept_re_array = JSONUtil.mergeJSONArrayItem(omsObj.getJSONArray("aoi_dept_re_array"), noReqObj.getJSONArray("aoi_dept_re_array"))
    if(aoi_dept_re_array!=null) {
      omsObj.put("aoi_dept_re_array", aoi_dept_re_array)
    }
    noReqObj.remove("aoi_dept_re_array")


    val arss_dept_req_array = JSONUtil.mergeJSONArrayItem(omsObj.getJSONArray("arss_dept_req_array"), noReqObj.getJSONArray("arss_dept_req_array"))
    if(arss_dept_req_array!=null) {
      omsObj.put("arss_dept_req_array", arss_dept_req_array)
    }
    noReqObj.remove("arss_dept_req_array")
    val arss_dept_re_array = JSONUtil.mergeJSONArrayItem(omsObj.getJSONArray("arss_dept_re_array"), noReqObj.getJSONArray("arss_dept_re_array"))
    if(arss_dept_re_array!=null) {
      omsObj.put("arss_dept_re_array", arss_dept_re_array)
    }
    noReqObj.remove("arss_dept_re_array")


    if (!omsObj.containsKey("address_unkow_check_body")) {
      val arssDeptReBody = noReqObj.getJSONObject("address_unkow_check_body")
      if (arssDeptReBody != null) {
        omsObj.put("address_unkow_check_body", arssDeptReBody)
        noReqObj.remove("address_unkow_check_body")
      }
    }
  }

  /**
   * 合并同步和异步的ks信息
   *
   * @param obj
   * @return
   */
  def mergeKsAysncData(obj: JSONObject) = {
    //合并ks数据
    val ksReArray = new JSONArray()
    val syncKsReBody = obj.getJSONObject("ks_re_body")
    val syncKsReTime = obj.getString("ks_re_time")
    if (syncKsReBody != null) {
      syncKsReBody.put("ks_re_time", syncKsReTime)
      ksReArray.add(syncKsReBody)
    }
    val ksReqArray = new JSONArray()
    val syncKsReqBody = obj.getJSONObject("ks_req_body")
    val syncKsReqTime = obj.getString("ks_req_time")
    if (syncKsReqBody != null) {
      syncKsReqBody.put("ks_req_time", syncKsReqTime)
      ksReqArray.add(syncKsReqBody)
    }
    val asyncData = obj.getJSONArray("async_data")
    if (asyncData != null) {
      for (i <- 0 until asyncData.size()) {
        val asyncItem = asyncData.getJSONObject(i)
        val itemKsReBody = asyncItem.getJSONObject("ks_re_body")
        val itemKsReTime = asyncItem.getString("ks_re_time")
        if (itemKsReBody != null) {
          itemKsReBody.put("ks_re_time", itemKsReTime)
          ksReArray.add(itemKsReBody)
        }
        val itemKsReqBody = asyncItem.getJSONObject("ks_req_body")
        val itemKsReqTime = asyncItem.getString("ks_req_time")
        if (itemKsReqBody != null) {
          itemKsReqBody.put("ks_req_time", itemKsReqTime)
          ksReqArray.add(itemKsReqBody)
        }
      }
    }
    //取最新的数据
    val ksReqLatest = OmsDayIndexMain.getLatestBody(ksReqArray, "ks_req_time")
    obj.put("ks_req_body", ksReqLatest)
    if (ksReqLatest != null) {
      obj.put("ks_req_time", ksReqLatest.getString("ks_req_time"))
    }

    val ksReLatest = OmsDayIndexMain.getLatestBody(ksReArray, "ks_re_time")
    obj.put("ks_re_body", ksReLatest)
    if (ksReLatest != null) {
      obj.put("ks_re_time", ksReLatest.getString("ks_re_time"))
    }
    //    if(!ksReqArray.isEmpty){
    //      obj.put("ks_req_array",ksReqArray)
    //    }
    //    if(!ksReArray.isEmpty){
    //      obj.put("ks_re_array",ksReArray)
    //    }
  }

  def queryLatestValidArssReqItem(jArray: JSONArray, dateTimeKey: String): JSONObject = {
    if (jArray == null || jArray.size() == 0) {
      return null
    }
    var re_body_item: JSONObject = null
    for (i <- 0 until jArray.size()) {
      val tmp_re_body = jArray.getJSONObject(i)
      val taskType = tmp_re_body.getString("taskType")
      if ("2".equals(taskType) || "19".equals(taskType) || "9".equals(taskType)) {
        //2和9算做网点审补  2、19、9都算aoi审补
        if (re_body_item == null) {
          re_body_item = tmp_re_body
        } else {
          if (re_body_item.getString(dateTimeKey) < tmp_re_body.getString(dateTimeKey)) {
            re_body_item = tmp_re_body
          }
        }
      }
    }
    re_body_item
  }

  def queryLatestValidArssReItem(jArray: JSONArray, dateTimeKey: String,
                                 gid: String): JSONObject = {
    if (jArray == null || jArray.size() == 0) {
      return null
    }

    var re_body_item: JSONObject = null
    for (i <- 0 until jArray.size()) {
      val tmp_re_body = jArray.getJSONObject(i)
      val tmpGid = tmp_re_body.getString("taskId")
      if (gid.equals(tmpGid)) {
        if (re_body_item == null) {
          re_body_item = tmp_re_body
        } else {
          if (re_body_item.getString(dateTimeKey) < tmp_re_body.getString(dateTimeKey)) {
            re_body_item = tmp_re_body
          }
        }
      }
    }
    re_body_item
  }

  def dealSingleDataFromArray(ret: JSONObject) = {
    //提取数组中的有用item到单独字段,用于分析和统计值
    //arss_dept_req_body
    val arss_dept_req_array = ret.getJSONArray("arss_dept_req_array")
    val arss_dept_req_body = queryLatestValidArssReqItem(arss_dept_req_array, "arss_dept_req_time")
    if (arss_dept_req_body != null) {
      ret.put("arss_dept_req_body", arss_dept_req_body)
      val gid = arss_dept_req_body.getString("gid")
      if (gid != null && !gid.isEmpty) {
        ///取arss结果
        val arss_dept_re_array = ret.getJSONArray("arss_dept_re_array")
        val arss_dept_re_body = queryLatestValidArssReItem(arss_dept_re_array, "arss_dept_re_time", gid)
        if (arss_dept_re_body != null) {
          ret.put("arss_dept_re_body", arss_dept_re_body)
        }
      }
    }
  }

  /**
   * 保留最新的一条数据
   *
   * @param obj1
   * @param obj2
   * @return
   */
  def mergeKsData(obj1: JSONObject, obj2: JSONObject) = {
    val itemKsReqBody1 = obj1.getJSONObject("ks_req_body")
    val itemKsReqTime1 = obj1.getString("ks_req_time")

    val itemKsReqBody2 = obj2.getJSONObject("ks_req_body")
    val itemKsReqTime2 = obj2.getString("ks_req_time")

    if ((itemKsReqBody1 == null && itemKsReqBody2 != null)
      || (itemKsReqBody1 != null && itemKsReqBody2 != null && itemKsReqTime2 > itemKsReqTime1)) {
      obj1.put("ks_req_body", itemKsReqBody2)
      obj1.put("ks_req_time", itemKsReqTime2)
    }

    val itemKsReBody1 = obj1.getJSONObject("ks_re_body")
    val itemKsReTime1 = obj1.getString("ks_re_time")

    val itemKsReBody2 = obj2.getJSONObject("ks_re_body")
    val itemKsReTime2 = obj2.getString("ks_re_time")

    if ((itemKsReBody1 == null && itemKsReBody2 != null)
      || (itemKsReBody1 != null && itemKsReBody2 != null && itemKsReTime2 > itemKsReTime1)) {
      obj1.put("ks_re_body", itemKsReBody2)
      obj1.put("ks_re_time", itemKsReTime2)
    }
  }

  /**
   * 适配一些数组，方便后面处理
   *
   * @param obj
   * @return
   */
  def fixArrayData(obj: (String, JSONObject)) = {

    val jObj = obj._2

    //添加异步标签，用于测试
//    if (jObj.containsKey("re_body")) {
//      val tmpArray = jObj.getJSONArray("re_body")
//      if (tmpArray != null) {
//        for (i <- 0 until tmpArray.size()) {
//          tmpArray.getJSONObject(i).put("z", "1")
//        }
//      }
//
//    } else if (jObj.containsKey("arss_dept_req_array")) {
//      val tmpArray = jObj.getJSONArray("arss_dept_req_array")
//      if (tmpArray != null) {
//        for (i <- 0 until tmpArray.size()) {
//          tmpArray.getJSONObject(i).put("z", "1")
//        }
//      }
//    } else if (jObj.containsKey("arss_dept_re_array")) {
//      val tmpArray = jObj.getJSONArray("arss_dept_re_array")
//      if (tmpArray != null) {
//        for (i <- 0 until tmpArray.size()) {
//          tmpArray.getJSONObject(i).put("z", "1")
//        }
//      }
//    } else if (jObj.containsKey("awsm_tc_req_body")) {
//      if (jObj.getJSONObject("awsm_tc_req_body") != null) {
//        jObj.getJSONObject("awsm_tc_req_body").put("z", "1")
//      }
//    } else if (jObj.containsKey("awsm_tc_re_body")) {
//      if (jObj.getJSONObject("awsm_tc_re_body") != null) {
//        jObj.getJSONObject("awsm_tc_re_body").put("z", "1")
//      }
//    } else if (jObj.containsKey("aoi_dept_req_body")) {
//      if (jObj.getJSONObject("aoi_dept_req_body") != null) {
//        jObj.getJSONObject("aoi_dept_req_body").put("z", "1")
//      }
//    } else if (jObj.containsKey("aoi_dept_re_body")) {
//      if (jObj.getJSONObject("aoi_dept_re_body") != null) {
//        jObj.getJSONObject("aoi_dept_re_body").put("z", "1")
//      }
//
//    }

    //aoi dept data
    if (jObj.containsKey("aoi_dept_re_body")) {
      val aoiDeptReBody = jObj.getJSONObject("aoi_dept_re_body")
      val aoi_dept_re_array = new JSONArray()
      aoi_dept_re_array.add(aoiDeptReBody)
      jObj.put("aoi_dept_re_array", aoi_dept_re_array)
      jObj.remove("aoi_dept_re_body")
    }

    if (jObj.containsKey("aoi_dept_req_body")) {
      val aoiDeptReqBody = jObj.getJSONObject("aoi_dept_req_body")
      val aoi_dept_req_array = new JSONArray()
      aoi_dept_req_array.add(aoiDeptReqBody)
      jObj.put("aoi_dept_req_array", aoi_dept_req_array)
      jObj.remove("aoi_dept_req_body")
    }


    obj
  }

  def mergeAsyncReq(formatedLogRight: RDD[(String, JSONObject)], arssLogRddNoReq: RDD[(String, JSONObject)],
                    arssLogRddNoGid: RDD[(String, JSONObject)]) = {
    val mergeRetRdd = formatedLogRight.union(arssLogRddNoReq).union(arssLogRddNoGid)
      .map(obj => {
        fixArrayData(obj)
      })
      .reduceByKey((obj1, obj2) => {
        mergeMutiBody(obj1, obj2, "re_body", putAll = false)
        mergeNotSyncData(obj1, obj2)
        mergeKsData(obj1, obj2)
        obj1
      })
      .persist(StorageLevel.DISK_ONLY)
    logger.error("异步请求按照运单合并后数量：" + mergeRetRdd.count())
    formatedLogRight.unpersist()
    arssLogRddNoReq.unpersist()
    arssLogRddNoGid.unpersist()
    mergeRetRdd
  }

  /**
   * 用运单号合并异步请求和无请求的数据信息
   *
   * @param formatedLog     : 正常日志
   * @param date            : 日期
   * @param arssLogRddNoReq : 无请求审补日志
   * @param arssLogRddNoGid : 无gid审补日志
   */
  def mergeAsyncData(formatedLog: RDD[JSONObject], date: String, arssLogRddNoReq: RDD[(String, JSONObject)], arssLogRddNoGid: RDD[(String, JSONObject)]) = {
    //oms请求
    val formatedLogLeft: RDD[(String, JSONObject)] = formatedLog
      .filter(obj => obj.getString("req_time") != null && obj.getString("req_time").contains(date)).map(obj => {
      var wayblliNo: String = null
      val req_body = obj.getJSONObject("req_body")
      if(req_body!=null){
        wayblliNo = req_body.getString("waybillNo")
      }
      (wayblliNo, obj)
    }).filter(obj => obj._1 != null)
    //异步请求
    val formatedLogRight = formatedLog.map(obj => {
      var wayblliNo: String = null
      val req_time = obj.getString("req_time")
      val async_time = obj.getString("async_time")
      //只取有没有oms请求的，带异步时间的
      if (req_time == null && async_time != null) {
        wayblliNo = obj.getString("async_waybillNo")
      }
      (wayblliNo, obj)
    }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>异步请求的数据量:" + formatedLogRight.count())
    if(OmsDayIndexMain.testSingleWaybill){
      formatedLogRight.take(100).foreach(obj=>{
        logger.error("异步请求的数据量"+obj)
      })
    }
    //按照运单号聚合异步数据
    logger.error("按照运单号聚合数据，异步请求，无gid数据，无请求数据")
    val mergeAsyncRdd = mergeAsyncReq(formatedLogRight, arssLogRddNoReq, arssLogRddNoGid)
    if(OmsDayIndexMain.testSingleWaybill){
      mergeAsyncRdd.take(100).foreach(obj=>{
        logger.error("按照运单号聚合数据，异步请求，无gid数据，无请求数据"+obj)
      })
    }
    logger.error(">>>合并异步请求数据")
    //合并异步请求id不一致消息
    val formatedLogMergeAsync = formatedLogLeft.leftOuterJoin(mergeAsyncRdd).map(obj => {
      val omsObj = obj._2._1
      val asyncObj = obj._2._2
      if (asyncObj.nonEmpty) {
        val asyncJson = asyncObj.get
        mergeMutiBody(omsObj, asyncJson, "re_body", putAll = false)
        mergeNotSyncDataToOmsBodyNew(omsObj, asyncJson)
        //aoi_dept_req_body 和 aoi_dept_req_body留数组，取最新
        mergeAoiDeptData(omsObj, asyncJson)
        // TODO 给请求打 异步关联标签,测试使用
//        if (omsObj.containsKey("req_body")) {
//          omsObj.getJSONObject("req_body").put("z", "1")
//        }
      } else {
        //转格式
        mergeAoiDeptData(omsObj, null)
      }
      dealSingleDataFromArray(omsObj)
      omsObj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>合并无gid请求后，解析数据量(总请求)：" + formatedLogMergeAsync.count())
    if(OmsDayIndexMain.testSingleWaybill){
      formatedLogMergeAsync.take(100).foreach(obj=>{
        logger.error("合并无gid请求后，解析数据量(总请求)"+obj)
      })
    }
    //放到外面统一释放
    //    formatedLog.unpersist()
    formatedLogMergeAsync.take(3).foreach(o => println(o))
    formatedLogMergeAsync
  }

  /**
   * 用运单号合并异步请求和无请求的数据信息
   *
   * @param formatedLog     : 正常日志
   * @param date            : 日期
   * @param arssLogRddNoReq : 无请求审补日志
   * @param arssLogRddNoGid : 无gid审补日志
   */
  def mergeAsyncDataBak(formatedLog: RDD[JSONObject], date: String, arssLogRddNoReq: RDD[(String, JSONObject)], arssLogRddNoGid: RDD[(String, JSONObject)]) = {
    //oms请求
    val formatedLogLeft: RDD[(String, JSONObject)] = formatedLog
      .filter(obj => obj.getString("req_time") != null && obj.getString("req_time").contains(date)).map(obj => {
      var wayblliNo: String = null
      val req_body = obj.getJSONObject("req_body")
      wayblliNo = req_body.getString("waybillNo")
      (wayblliNo, obj)
    })
    //      .persist(StorageLevel.DISK_ONLY)
    //    logger.error(">>>oms解析数据量：" + formatedLogLeft.count())

    //    formatedLogLeft.take(3).foreach(o=>println(o))
    //异步请求
    val formatedLogRight = formatedLog.map(obj => {
      var wayblliNo: String = null
      val req_time = obj.getString("req_time")
      val async_time = obj.getString("async_time")
      //只取有没有oms请求的，带异步时间的
      if (req_time == null && async_time != null) {
        wayblliNo = obj.getString("async_waybillNo")
      }
      (wayblliNo, obj)
    }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>异步请求的数据量:" + formatedLogRight.count())
    //    formatedLogRight.take(3).foreach(o=>println(o))

    logger.error(">>>合并异步请求数据")
    //合并异步请求id不一致消息
    val formatedLogMergeAsync = formatedLogLeft.leftOuterJoin(formatedLogRight).map(obj => {
      val omsObj = obj._2._1
      val asyncObj = obj._2._2
      if (asyncObj.nonEmpty) {
        val asyncJson = asyncObj.get
        mergeMutiBody(omsObj, asyncJson, "re_body", putAll = false)
        mergeNotSyncDataToOmsBody(omsObj, asyncJson)
        val targetArray = new JSONArray()
        targetArray.add(asyncJson)
        omsObj.put("async_data", targetArray)
      }
      val reqId = omsObj.getString("reqId")
      (reqId, omsObj)
    }).reduceByKey((o1, o2) => {
      var async_data1: JSONArray = o1.getJSONArray("async_data")
      val async_data2: JSONArray = o2.getJSONArray("async_data")
      if (async_data2 != null && async_data2.size() != 0) {
        if (async_data1 == null) {
          async_data1 = new JSONArray()
        }
        for (i <- 0 until async_data2.size()) {
          async_data1.add(async_data2.get(i))
        }
        o1.put("async_data", async_data1)
      }
      o1
    }).map(obj => {
      val req_body = obj._2.getJSONObject("req_body")
      val wayblliNo = req_body.getString("waybillNo")
      mergeKsAysncData(obj._2)
      (wayblliNo, obj._2)
    })
    logger.error(">>>合并无请求数据")
    //合并无请求id数据
    val formatedLogMergeNoReq: RDD[(String, JSONObject)] = formatedLogMergeAsync.leftOuterJoin(arssLogRddNoReq).map(obj => {
      val omsObj = obj._2._1
      //      val req_time = omsObj.getString("req_time")
      val noReqObj = obj._2._2
      if (noReqObj.nonEmpty) {
        val noReqJson = noReqObj.get
        mergeNotSyncDataToOmsBody(omsObj, noReqJson)
        val targetArray = new JSONArray()
        targetArray.add(noReqJson)
        omsObj.put("no_req_data", targetArray)
      }
      val reqId = omsObj.getString("reqId")
      (reqId, omsObj)
    }).reduceByKey((o1, o2) => {
      var noReq_data1: JSONArray = o1.getJSONArray("no_req_data")
      val noReq_data2: JSONArray = o2.getJSONArray("no_req_data")
      if (noReq_data2 != null && noReq_data2.size() != 0) {
        if (noReq_data1 == null) {
          noReq_data1 = new JSONArray()
        }
        for (i <- 0 until noReq_data2.size()) {
          noReq_data1.add(noReq_data2.getJSONObject(i))
        }
        o1.put("no_req_data", noReq_data1)
      }
      o1
    }).map(obj => {
      val req_body = obj._2.getJSONObject("req_body")
      val wayblliNo = req_body.getString("waybillNo")
      (wayblliNo, obj._2)
    }).map(obj => {
      (obj._1, merge_no_sync_data(obj._2))
    })
    logger.error(">>>合并无Gid数据")
    val formatedLogMergeNoGid: RDD[JSONObject] = formatedLogMergeNoReq.leftOuterJoin(arssLogRddNoGid).map(obj => {
      val omsObj = obj._2._1
      val noGidObj = obj._2._2
      if (noGidObj.nonEmpty) {
        val noGidJson = noGidObj.get
        val targetArray = new JSONArray()
        targetArray.add(noGidJson)
        omsObj.put("no_gid_data", targetArray)
      }
      val reqId = omsObj.getString("reqId")
      (reqId, omsObj)
    }).reduceByKey((o1, o2) => {
      var noGid_data1: JSONArray = o1.getJSONArray("no_gid_data")
      val noGid_data2: JSONArray = o2.getJSONArray("no_gid_data")
      if (noGid_data2 != null && noGid_data2.size() != 0) {
        if (noGid_data1 == null) {
          noGid_data1 = new JSONArray()
        }
        for (i <- 0 until noGid_data2.size()) {
          noGid_data1.add(noGid_data2.get(i))
        }
        o1.put("no_gid_data", noGid_data1)
      }
      o1
    }).map(obj => {
      val ret = obj._2
      dealSingleDataFromArray(ret)
      ret
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>合并无gid请求后，解析数据量(总请求)：" + formatedLogMergeNoGid.count())
    //    formatedLogMergeNoGid.take(3).foreach(o=>println(o))

    formatedLogMergeNoGid
  }

  def findMaxTimeFromArray(jsonArray: JSONArray, timeKey: String): JSONObject = {
    var retItem: JSONObject = null
    var retTime: String = null
    for (i <- 0 until jsonArray.size()) {
      val item = jsonArray.getJSONObject(i)
      val itemTime = item.getString(timeKey)
      if (retTime == null || itemTime > retTime) {
        retTime = itemTime
        retItem = item
      }
    }
    retItem
  }

  /**
   * 合并其他字段的属性
   *
   * @param body : 数据体
   * @return
   */
  def merge_no_sync_data(body: JSONObject): JSONObject = {
    //合并aoi_data
    val aoi_dept_req = body.getJSONObject("aoi_dept_req_body")
    val aoi_dept_re = body.getJSONObject("aoi_dept_re_body")
    //    val arss_dept_req = body.getJSONObject("arss_dept_req_body")
    //    val arss_dept_re = body.getJSONObject("arss_dept_re_body")

    val aoi_dept_req_merge = new JSONArray()
    val aoi_dept_re_merge = new JSONArray()
    //    val arss_dept_req_merge = new JSONArray()
    //    val arss_dept_re_merge = new JSONArray()
    if (aoi_dept_req != null) {
      aoi_dept_req_merge.add(aoi_dept_req)
    }
    if (aoi_dept_re != null) {
      aoi_dept_re_merge.add(aoi_dept_re)
    }
    //    if (arss_dept_req != null) {
    //      arss_dept_req_merge.add(arss_dept_req)
    //    }
    //    if (arss_dept_re != null) {
    //      arss_dept_re_merge.add(arss_dept_re)
    //    }
    val no_req_data = body.getJSONArray("no_req_data")
    if (no_req_data != null && no_req_data.size() > 0) {
      for (i <- 0 until no_req_data.size()) {
        val no_req_data_item = no_req_data.getJSONObject(i)
        merge_no_req_data_detail(no_req_data_item, "aoi_dept_req_body", "aoi_dept_req_time",
          aoi_dept_req_merge)
        merge_no_req_data_detail(no_req_data_item, "aoi_dept_re_body", "aoi_dept_re_time",
          aoi_dept_re_merge)
        //        merge_no_req_data_detail(no_req_data_item, "arss_dept_req_body", "arss_dept_req_time",
        //          arss_dept_req_merge)
        //        merge_no_req_data_detail(no_req_data_item, "arss_dept_re_body", "arss_dept_re_time",
        //          arss_dept_re_merge)
      }
    }
    val async_data = body.getJSONArray("async_data")
    if (async_data != null && async_data.size() > 0) {
      for (i <- 0 until async_data.size()) {
        val async_data_item = async_data.getJSONObject(i)
        merge_no_req_data_detail(async_data_item, "aoi_dept_req_body", "aoi_dept_req_time",
          aoi_dept_req_merge)
        merge_no_req_data_detail(async_data_item, "aoi_dept_re_body", "aoi_dept_re_time",
          aoi_dept_re_merge)
        //        merge_no_req_data_detail(async_data_item, "arss_dept_req_body", "arss_dept_req_time",
        //          arss_dept_req_merge)
        //        merge_no_req_data_detail(async_data_item, "arss_dept_re_body", "arss_dept_re_time",
        //          arss_dept_re_merge)
      }
    }
    if (aoi_dept_req_merge.size() != 0) {
      body.put("aoi_dept_req_body", aoi_dept_req_merge)
    } else if (body.containsKey("aoi_dept_req_body")) {
      body.remove("aoi_dept_req_body")
    }
    if (aoi_dept_re_merge.size() != 0) {
      body.put("aoi_dept_re_body", aoi_dept_re_merge)
    } else if (body.containsKey("aoi_dept_re_body")) {
      body.remove("aoi_dept_re_body")
    }

    //    if (arss_dept_req_merge.size() != 0) {
    //      body.put("arss_dept_req_array", arss_dept_req_merge)
    //      body.put("arss_dept_req_body", findMaxTimeFromArray(arss_dept_req_merge, "arss_dept_req_time"))
    //    }
    //    if (arss_dept_re_merge.size() != 0) {
    //      body.put("arss_dept_re_array", arss_dept_re_merge)
    //      body.put("arss_dept_re_body", findMaxTimeFromArray(arss_dept_re_merge, "arss_dept_re_time"))
    //
    //    }
    body
  }

  def merge_no_req_data_detail(no_req_data_item: JSONObject, bodyKey: String, timeKey: String,
                               mergeArray: JSONArray): Unit = {
    if (no_req_data_item != null && no_req_data_item.containsKey(bodyKey)) {
      val aoi_dept_req_item = no_req_data_item.getJSONObject(bodyKey)
      val aoi_dept_req_time = no_req_data_item.getString(timeKey)
      aoi_dept_req_item.put(timeKey, aoi_dept_req_time)
      mergeArray.add(aoi_dept_req_item)
      no_req_data_item.remove(bodyKey)
      no_req_data_item.remove(timeKey)
    }
  }

  /**
   * 额外的操作
   *
   * @param obj
   */
  def extraOp(obj: JSONObject): Unit = {
    val bid_re_body = obj.getJSONArray("bid_re_body")
    if (bid_re_body == null || bid_re_body.size() < 2) {
      return
    }
    val sortBody = bid_re_body.toArray().sortBy(_.asInstanceOf[JSONObject].getString("bid_re_time"))
    obj.put("bid_re_body", sortBody)
  }

  /**
   * 标准化省市区数据
   *
   * @return
   */
  def getStandardLogRdd(logRdd: RDD[JSONObject], javaUtil: JavaUtil): RDD[JSONObject] = {
    //    val conn = DbUtils.getConn
    logger.error(">>>javaUtil：" + javaUtil.getFlag)
    val conn = DbUtils.getConnection(javaUtil)
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("province", "region", "city", "citycode")
    val regionSelectSql = s"select province,region,city,citycode from $regoinCityTable"
    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val citycode = arr(3).toString
      if (cityMap.contains(citycode)) {
        val cityCodeList = cityMap.apply(citycode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (citycode -> cityCodeList)
      }
    }

    val standardLog = logRdd.map(json => {
      //      val json = new JSONObject()
      val req_body = json.getJSONObject("req_body")
      var destCityCode = req_body.getString("destCityCode")
      if (destCityCode == null) destCityCode = "-"
      json.put("city_code", destCityCode)
      val addresseeAddr = req_body.getString("addresseeAddr")
      var flag = false
      if (cityMap.contains(destCityCode)) {
        flag = true
        val cityList: ArrayBuffer[Array[String]] = cityMap.apply(destCityCode)
        if (cityList.length == 1) {
          //如果只有一个list，一一对应的，直接返回
          json.put("province", cityList(0)(0))
          json.put("region", cityList(0)(1))
          json.put("city", cityList(0)(2))
        } else if (cityList.length > 1) {
          //一个城市代码对应多个城市名
          json.put("province", cityList(0)(0))
          json.put("region", cityList(0)(1))
          for (cityObj <- cityList) {
            val city = cityObj(2)
            val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
            if (addresseeAddr != null && (addresseeAddr.contains(city) || addresseeAddr.contains(city1))) {
              json.put("city", cityObj(2))
            } else {
              if (json.getString("city") == null) {
                json.put("city", "-")
              }
            }
          }

        }
      }
      (flag, json)
    }).filter(_._1).values.map(obj => {
      //做额外的操作，如特定数据排序
      extraOp(obj)
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("标准化后地址总数量:" + standardLog.count())
    standardLog
  }

  /**
   * 取最新的请求时间
   *
   * @param o1 : 对象1
   * @param o2 : 对象2
   * @return
   */
  def filterByWaybillno(o1: JSONObject, o2: JSONObject): JSONObject = {
    var json: JSONObject = null
    val req_time1 = o1.getString("req_time")
    val req_time2 = o2.getString("req_time")
    if (req_time1 > req_time2) {
      json = o1
    } else {
      json = o2
    }
    json
  }


  def parseBidReq(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
    val re = new JSONObject()
    val body = JSON.parseObject(chkDisLogMsg)
    val chkDisLogTypeArray = chkDisLogType.split(";")
    val reqId = chkDisLogTypeArray(0)
    re.put("reqId", reqId)
    re.put("bid_req_time", createTime)
    body.put("bid_req_time", createTime)
    //单个模式
    //    re.put("bid_req_body", body)
    //数组多次请求模式
    val tmpArray = new JSONArray()
    tmpArray.add(body)
    re.put("bid_req_body", tmpArray)
    re.put("nodeId", ip)
    re.put("async_waybillNo", chkDisLogTypeArray(2))
    re.put("async_time", createTime)
    (reqId, re)
  }


  def parseBidRes(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
    val re = new JSONObject()
    val body = JSON.parseObject(chkDisLogMsg)
    val chkDisLogTypeArray = chkDisLogType.split(";")
    val reqId = chkDisLogTypeArray(0)
    re.put("reqId", reqId)
    re.put("bid_re_time", createTime)
    body.put("bid_re_time", createTime)
    //单个模式
    //    re.put("bid_re_body", body)
    //数组多次请求模式
    val tmpArray = new JSONArray()
    tmpArray.add(body)
    re.put("bid_re_body", tmpArray)
    re.put("nodeId", ip)
    re.put("async_waybillNo", chkDisLogTypeArray(2))
    re.put("async_time", createTime)
    (reqId, re)
  }

  /**
   * 解析非审补的数据，reqId不需要单独关联
   *
   * @param line : 数据行
   * @return
   */
  def parserOneLine(line: String): util.ArrayList[(String, JSONObject)] = {
    val tpList = new util.ArrayList[(String, JSONObject)]
    var re: Object = null
    try {
      if (line.indexOf("=>receive oms waybill message :") > -1) re = parseOmsToReq(line) //请求的参数
      else if (line.indexOf("=>teamToResult:") > -1) re = parseGisSssRet(line) //从接口返回的数据
      else if (line.indexOf("=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message:") > -1) re = parseOmsToRe(line) //返回的结果
      else if (line.indexOf("ATPai->") > -1) re = parseATPaiData(line) //atPai返回数据
      else if (line.indexOf("=>AtMultiSrcMsg") > -1) re = parseOmsToMutilSrc(line) //多库校验数据
      else if (line.indexOf("=>kafka topic GIS_ASS_RDS_CHK,message:") > -1) re = parseGisToKs(line)
      else if (line.indexOf("=>ksMsg:") > -1) re = parseKsToGis(line)
      else if (line.contains(";getbidArg")) re = parseBidReq(line)
      else if (line.contains(";getbidRet")) re = parseBidRes(line)
      else if (line.indexOf("AddressUnkowCheck:") > -1) re = parseAddressUnkonCheck(line)
      //      else if (line.indexOf("=>kafka topic GIS_ASS_RDS_CHK_DISPATCH_EXT_EVENT,message:") > -1) re = parseChkToExt(line)
    } catch {
      //      case e: NullPointerException => logger.error(e + String.format("日志解析>>>数据空指针异常: %s", line))
      //      case e: com.alibaba.fastjson.JSONException => logger.error(e + String.format("日志解析>>>JSON数据格式异常: %s", line))
      //      case e: Exception => logger.error(String.format(e + "日志解析>>>解析数据未知异常: %s", line))
      case e: Exception =>
    }

    re match {
      case i: (String, JSONObject) => tpList.add(i)
      case x: util.ArrayList[(String, JSONObject)] => tpList.addAll(x)
      case _ =>
    }
    tpList
  }

  /**
   * 解析数据，先把审补数据和reqId关联起来
   *
   * @param line : 数据行
   * @return
   */
  def parseReqId(line: String): util.ArrayList[(String, JSONObject)] = {

    val tpList = new util.ArrayList[(String, JSONObject)]

    var re: Object = null
    try {
      if (line.indexOf("=>link to gid:") > -1) re = linkReqId(line) //把gid和requestId关联起来
      else if (line.indexOf("kafka topic GIS_ASS_RDS_CHK_DISPATCH_TO_ARSS,message:") > -1) re = parseGisToArss(line) //GIS_ASS_RDS_CHKDEST_TO_ARSS(gid) 批量请求arss审补网点 arss
      else if (line.indexOf("kafka topic GIS_ASS_RDS_CHKDEST_TO_ARSS,message:") > -1) re = parseGisToArss(line) //GIS_ASS_RDS_CHKDEST_TO_ARSS(gid) 批量请求arss审补网点 arss
      else if (line.indexOf("=>receive waybill dept chk message :") > -1) re = parseOmsDeptArss(line) //返回arss审补结果(taskId)
      else if (line.indexOf("kafka topic GIS_ASS_RDS_TO_AWSM,message:") > -1) re = parseGisToAwsm(line) //GIS_ASS_RDS_TO_AWSM(gid) 批量请求AWSM审补
      else if (line.indexOf("=>receive awsm message :") > -1) re = parseAwsmToGis(line) //返回AWSM审补结果
      else if (line.indexOf("=>AWSM GEO return data:") > -1) re = parseGeoData(line) //补了经纬度之后的数据
      else if (line.indexOf("kafka topic GIS_ASS_RDS_CHKDEST_ADDR_TO_SSS,message:") > -1) re = parseGisToSss(line) //GIS发往sss审补数据
      else if (line.indexOf("=>receive sss addr chk message :") > -1) re = parseSssToGis(line) //sss返回审补结果
      else if (line.indexOf("=>kafka topic GIS_ASS_RDS_AOI_TO_AWSM,message:") > -1) re = parseGisToAoi(line) //GIS发往aoi审补数据
      else if (line.indexOf("=>chkAoiMsg:") > -1) re = parseAoiToGis(line)

    } catch {
      //      case e: com.alibaba.fastjson.JSONException => logger.error(e + String.format("日志解析>>>JSON数据格式异常: %s", line))
      //      case e: NullPointerException => logger.error(e + String.format("日志解析>>>数据空指针异常: %s", line))
      //      case e: Exception => logger.error(String.format(e + "日志解析>>>解析数据未知异常: %s", line))
      case e: Exception =>
    }

    re match {
      case i: (String, JSONObject) => tpList.add(i)
      case x: util.ArrayList[(String, JSONObject)] => tpList.addAll(x)
      case _ =>
    }
    tpList
  }

  /**
   * 派件CHK发往ext
   *
   * @param line : 数据行
   * @return
   */
  def parseChkToExt(line: String): (String, JSONObject) = {
    val re = new JSONObject()
    val bodyRaw = StringUtil.pickGroup1Str(line, "=>kafka topic GIS_ASS_RDS_CHK_DISPATCH_EXT_EVENT,message:(.*)$").trim
    val body = JSON.parseObject(bodyRaw)
    val reqId = body.getString("requestId")
    val commonAttr = commonParse(line)
    re.put("reqId", reqId)
    re.put("chk_ext_req_time", commonAttr.get("datetime"))
    re.put("chk_ext_req_body", body)
    re.put("nodeId", commonAttr.get("nodeId"))
    re.put("async_waybillNo", body.getString("waybillNo"))
    re.put("async_time", commonAttr.get("datetime"))
    //    println("接口返回数据:"+(reqId,re))
    (reqId, re)
  }

  /**
   * 派件KS审补结果=>ksMsg: :
   *
   * @param line : 数据行
   * @return
   */
  def parseKsToGis(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val body = chkDisLogObj
    val result = body.getJSONObject("result")
    if (result != null) {
      val attachmentObj = result.getJSONObject("attachment")
      val omsReq = attachmentObj.getJSONObject("omsReq")
      if (omsReq != null) {
        re.put("async_waybillNo", omsReq.getString("waybillNo"))
      }
      result.remove("attachment")
      body.put("result", result)
    }
    val reqId = body.getString("requestId")
    re.put("reqId", reqId)
    re.put("ks_re_time", createTime)
    body.put("ks_re_time", createTime)
    re.put("ks_re_body", body)
    re.put("nodeId", ip)

    re.put("async_time", createTime)
    //    println("接口返回数据:"+(reqId,re))
    (reqId, re)
  }

  /**
   * 派件AOI审补结果=>chkAoiMsg: :
   *
   * @param line : 数据行
   * @return
   */
  def parseAoiToGis(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val body = chkDisLogObj
    var gid = body.getString("gid")
    if ("0".equals(gid) || "".equals(gid)) {
      gid = null
    }
    if (!StringUtil.isBlank(requestId)) {
      re.put("reqId", requestId)
    }
    re.put("type", "omsto")
    body.put("aoi_dept_re_time", createTime)
    re.put("aoi_dept_re_body", body)
    re.put("aoi_dept_re_time", createTime)
    re.put("nodeId", ip)
    re.put("async_waybillNo", body.getString("waybillNo"))
    re.put("async_time", createTime)
    //    println("sss审补结果："+(gid,re))
    (gid, re)
  }

  def parseAddressUnkonCheck(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val body = chkDisLogObj

    re.put("type", "omsto")
    body.put("address_unkow_check_time", createTime)
    re.put("address_unkow_check_body", body)
    re.put("address_unkow_check_time", createTime)
    re.put("nodeId", ip)
    re.put("async_waybillNo", body.getString("waybillNo"))
    re.put("async_time", createTime)
    //    println("sss审补结果："+(gid,re))
    re.put("reqId", body.getString("requestId"))
    (body.getString("requestId"), re)
  }

  /**
   *
   * =>kafka topic GIS_ASS_RDS_CHK,message: 派件发往KS审补网点
   * @param line : 数据行
   * @return
   */
  def parseGisToKs(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
    val re = new JSONObject()
    val reqId = StringUtil.pickGroup1Str(chkDisLogType, "^(.*?)=>kafka topic GIS_ASS_RDS_CHK,message:").replace("info ", "").trim
    val body = chkDisLogObj
    re.put("reqId", reqId)
    re.put("type", "omsto")

    re.put("ks_req_time", createTime)
    re.put("nodeId", ip)
    val attachmentObj = body.getJSONObject("attachment")
    if (attachmentObj != null && attachmentObj.getJSONObject("omsReq") != null) {
      re.put("async_waybillNo", attachmentObj.getJSONObject("omsReq").getString("waybillNo"))
    }
    body.remove("attachment")
    body.put("ks_req_time", createTime)
    re.put("ks_req_body", body)
    re.put("async_time", createTime)
    //    println("用户请求参数:"+(reqId,re))
    (reqId, re)
  }

  /**
   *
   * =>kafka topic GIS_ASS_RDS_AOI_TO_AWSM,message: 派件发往AOI审补网点
   * @param line : 数据行
   * @return
   */
  def parseGisToAoi(line: String): util.ArrayList[(String, JSONObject)] = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val list = new util.ArrayList[(String, JSONObject)]
    //    logger.error(">>>包含sss_chkn_req的数据：kafka topic GIS_ASS_RDS_CHKDEST_ADDR_TO_SSS")

    //单个请求
    if (chkDisLogObj != null) {

      val re = new JSONObject()
      val body = chkDisLogObj
      val gid = body.getString("gid")
      if (!StringUtil.isBlank(requestId)) {
        re.put("reqId", requestId)
      }
      re.put("type", "omsto")
      body.put("aoi_dept_req_time", createTime)
      re.put("aoi_dept_req_body", body)
      re.put("aoi_dept_req_time", createTime)

      re.put("nodeId", ip)
      re.put("async_waybillNo", body.getString("waybillNo"))
      re.put("async_time", createTime)
      list.add((gid, re))
    }
    //批量请求
    if (chkDisLogArray != null) {
      val bodys = chkDisLogArray
      for (i <- 0 until bodys.size()) {
        val re = new JSONObject()
        val body = bodys.getJSONObject(i)
        val gid = body.getString("gid")
        val requestId = body.getString("requestId")
        if (!StringUtil.isBlank(requestId)) {
          re.put("reqId", requestId)
        }
        re.put("type", "omsto")
        body.put("aoi_dept_req_time", createTime)
        re.put("aoi_dept_req_body", body)
        re.put("aoi_dept_req_time", createTime)
        re.put("nodeId", ip)
        re.put("async_waybillNo", body.getString("waybillNo"))
        re.put("async_time", createTime)
        //        logger.error(">>>包含sss_chkn_req的数据：kafka topic GIS_ASS_RDS_CHKDEST_ADDR_TO_SSS:"+gid)
        list.add((gid, re))
      }
    }

    //    println("派件批量审补网点："+list)
    list
  }

  /**
   * 业务需要的数据量
   *
   * @param line : 数据行
   * @return
   */
  def isValidLine(line: String): Boolean = {
    val b1 = line.contains("=>link to gid:")
    val b2 = line.contains("kafka topic GIS_ASS_RDS_CHK_DISPATCH_TO_ARSS,message:") || line.contains("kafka topic GIS_ASS_RDS_CHKDEST_TO_ARSS,message:")
    val b3 = line.contains("=>receive waybill dept chk message :")
    val b4 = line.contains("kafka topic GIS_ASS_RDS_TO_AWSM,message:")
    val b5 = line.contains("=>receive awsm message :")
    val b6 = line.contains("=>receive oms waybill message :")
    val b7 = line.contains("=>teamToResult:")
    //    && isOmsTeamToResult(line: String)
    val b8 = line.contains("=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message:")
    val b9 = line.contains("ATPai->")
    val b10 = line.contains("AWSM GEO return data")
    val b11 = line.contains("kafka topic GIS_ASS_RDS_CHKDEST_ADDR_TO_SSS,message:")
    val b12 = line.contains("=>receive sss addr chk message :")
    val b13 = line.contains("=>kafka topic GIS_ASS_RDS_AOI_TO_AWSM,message:")
    val b14 = line.contains("=>chkAoiMsg:")
    val b15 = line.contains("=>kafka topic GIS_ASS_RDS_CHK,message:")
    val b16 = line.contains("=>ksMsg:")
    //    val b17 = line.contains("=>kafka topic GIS_ASS_RDS_CHK_DISPATCH_EXT_EVENT,message:")
    val b18 = line.contains(";getbidArg")
    val b19 = line.contains(";getbidRet")
    val b20 = line.contains("AddressUnkowCheck:")
    b1 || b2 || b3 || b4 || b5 || b6 || b7 || b8 || b9 || b10 || b11 || b12 || b13 || b14 || b15 || b16 || b18 || b19 || b20
  }

  def isShenbuLine(line: String): Boolean = {
    val b1 = line.contains("=>link to gid:")
    val b2 = line.contains("kafka topic GIS_ASS_RDS_CHK_DISPATCH_TO_ARSS,message:") || line.contains("kafka topic GIS_ASS_RDS_CHKDEST_TO_ARSS,message:")
    val b3 = line.contains("=>receive waybill dept chk message :")
    val b13 = line.contains("=>kafka topic GIS_ASS_RDS_AOI_TO_AWSM,message:")
    val b14 = line.contains("=>chkAoiMsg:")
    //这个是rebody不算审补，但是容易跨天
    val b8 = line.contains("=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message:")
    val b20 = line.contains("AddressUnkowCheck:")
    b1 || b2 || b3 || b13 || b14 || b8 || b20
  }

  //
  //  /**
  //    * 判断teamToResult是否是oms的数据
  //    *
  //    * @param line : 数据行
  //    * @return
  //    */
  //  def isOmsTeamToResult(line: String): Boolean = {
  //    //    val reqId = StringUtil.pickGroup1Str(line, "--start-- (.*?)=>teamToResult:").replace("info ","").trim
  //    val isOms = line.contains("_OMS") //oms的数据
  //    //    val isOms = !(reqId.indexOf("qtp") > -1) //非rls的数据
  //    isOms
  //  }


  /**
   * 提取每行记录中的时间和节点，如：{"datetime":"2018-05-24 11:20:55","nodeId":"10.116.116.214"}
   *
   * @param line : 数据行
   * @return
   */
  def commonParse(line: String): JSONObject = {
    val obj: JSONObject = new JSONObject()
    val nodeId = StringUtil.pickGroup1Str(line, "#(\\d+\\.\\d+\\.\\d+\\.\\d+)#").trim
    //    var datetime = StringUtil.pickGroup1Str(line, "\\[(\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2})\\]")
    val datetime = StringUtil.pickGroup1Str(line, "\\[(\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s\\d{3})\\]").trim
    obj.put("nodeId", nodeId)
    obj.put("datetime", datetime)
    obj
  }

  def parseMessageObject(line: String) = {
    val jObj = JSON.parseObject(line.trim)
    var createTime = jObj.getString("createTime")
    if (createTime != null) {
      createTime = createTime.replace(".", " ")
    }
    val ip = jObj.getString("ip")
    val message = JSON.parseObject(jObj.getString("message").trim)
    var requestId = message.getString("requestId")
    if (requestId != null) {
      requestId = requestId.trim
    }
    val chkDisLogType = message.getString("chkDisLogType").trim
    var chkDisLogObj: JSONObject = null
    var chkDisLogArray: JSONArray = null
    var chkDisLogMsg: String = null
    if (message.containsKey("chkDisLogArray")) {
      val tmpArray = message.getJSONArray("chkDisLogArray")
      if (tmpArray != null && tmpArray.size() != 0) {
        chkDisLogArray = new JSONArray()
        for (i <- 0 until tmpArray.size()) {
          chkDisLogArray.add(JSON.parseObject(tmpArray.getString(i).trim))
        }
      }
    } else if (message.containsKey("chkDisLogMsg")) {
      chkDisLogMsg = message.getString("chkDisLogMsg").trim
    } else {
      chkDisLogObj = message
    }
    (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray)
  }

  /**
   * oms请求输入的参数,包含有"=>receive oms waybill message : "
   *
   * @param line : 数据行
   * @return
   */
  def parseOmsToReq(line: String): (String, JSONObject) = {
    ///香港请求特殊，存在一个翻译的过程，如果地址第一次没识别到，会发到arss做翻译，翻译完以后，就会生成一条新的oms请求，发到源头，走全流程链路
    //翻译标志addrChkResult:true
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
    val re = new JSONObject()
    val reqId = StringUtil.pickGroup1Str(chkDisLogType, "^(.*?)=>receive oms waybill message :").replace("info ", "").trim
    val body = chkDisLogObj
    re.put("reqId", reqId)
    val repeatMark = JSONUtil.getJsonValSingle(body,"repeatMark","")
    if("1".equals(repeatMark)){
      //重复的，用于做关联，然后扔掉
      re.put("repeatMark", repeatMark)

    }else {
      re.put("type", "omsto")
      re.put("req_body", body)
      re.put("nodeId", ip)
      re.put("req_time", createTime)
    }
    //    println("用户请求参数:"+(reqId,re))
    (reqId, re)
  }


  /**
   *
   * =>teamToResult: 接口返回的数据
   * @param line : 数据行
   * @return
   */
  def parseGisSssRet(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val reqId = StringUtil.pickGroup1Str(chkDisLogType, "^(.*?)=>teamToResult:").replace("info ", "").trim
    val body = chkDisLogObj
    re.put("reqId", reqId)
    re.put("gis_to_sys_time", createTime)
    re.put("gis_to_sys_body", body)
    re.put("nodeId", ip)
    //    println("接口返回数据:"+(reqId,re))
    (reqId, re)

  }


  /**
   *
   * =>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message: 最后返回给oms的数据信息
   * @param line : 数据行
   * @return
   */
  def parseOmsToRe(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    var reqId = StringUtil.pickGroup1Str(chkDisLogType, "(.*?)=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message:").replace("info ", "").trim
    val body = chkDisLogObj
    val repeatMark = JSONUtil.getJsonValSingle(body,"src","")
    if("repeatMark".equals(repeatMark)){
      //重复的，用于做关联，然后扔掉
      re.put("repeatMark", "1")
    }else{
      re.put("type", "omsto")
      val body_array = new JSONArray()
      body.put("datetime", createTime)
      body_array.add(body)

      re.put("re_body", body_array)
      re.put("re_time", createTime)
      re.put("async_time", createTime)
      re.put("async_waybillNo", body.getString("waybillNo"))
      re.put("nodeId", ip)
    }
    //    println("最后返回数据:"+(reqId,re))
    if ((checkEmptyReqGid(reqId) || "V1".equals(reqId)) && !StringUtil.isBlank(body.getString("waybillNo"))) {
      reqId = reqId + "_" + body.getString("waybillNo")
    }
    re.put("reqId", reqId)
    (reqId, re)
  }

  /**
   *
   * =>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message: 最后返回给oms的数据信息
   * @param line : 数据行
   * @return
   */
  def parseOmsToMutilSrc(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val body = chkDisLogObj
    val reqId = JSONUtil.getJsonVal(body, "dispatchArg.traceId", "")
    re.put("type", "omsto")
    re.put("reqId", reqId)
    re.put("multi_re_body", body)
    re.put("multi_re_time", createTime)
    re.put("nodeId", ip)
    (reqId, re)
  }


  /**
   * 关联审补数据的requestId和gid
   *
   * @param line : 数据行
   * @return
   */
  def linkReqId(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    var reqId: String = StringUtil.pickGroup1Str(requestId, "^(.*?)=>link to gid:").replace("info ", "").trim
    if (StringUtil.isBlank(reqId)) {
      //旧报文格式，不知道啥时候改的，++_++
      reqId = StringUtil.pickGroup1Str(chkDisLogType, "^(.*?)=>link to gid:").replace("info ", "").trim
    }
    val gid: String = chkDisLogMsg
    if (checkEmptyReqGid(reqId)) {
      reqId = null;
    } else {
      re.put("reqId", reqId)
    }
    //    re.put("gid",gid)
    //    println("requestId和gid:"+(gid,re))
    (gid, re)
  }

  /**
   * kafka topic GIS_ASS_RDS_CHKDEST_ADDR_TO_SSS,message: 派件发往sss审补网点
   *
   * @param line : 数据行
   * @return
   */
  def parseGisToSss(line: String): util.ArrayList[(String, JSONObject)] = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val list = new util.ArrayList[(String, JSONObject)]

    //单个请求
    if (chkDisLogObj != null) {

      val re = new JSONObject()
      val body = chkDisLogObj
      val gid = body.getString("gid")
      if (!StringUtil.isBlank(requestId)) {
        re.put("reqId", requestId)
      }
      re.put("type", "omsto")
      re.put("sss_dept_req_body", body)
      re.put("sss_dept_req_time", createTime)
      re.put("nodeId", ip)
      re.put("async_waybillNo", body.getString("waybillNo"))
      re.put("async_time", createTime)
      list.add((gid, re))
    }
    //批量请求
    if (chkDisLogArray != null) {
      val bodys = chkDisLogArray
      for (i <- 0 until bodys.size()) {
        val re = new JSONObject()
        val body = bodys.getJSONObject(i)
        val gid = body.getString("gid")
        val requestId = body.getString("requestId")
        if (!StringUtil.isBlank(requestId)) {
          re.put("reqId", requestId)
        }
        re.put("type", "omsto")
        re.put("sss_dept_req_body", body)
        re.put("sss_dept_req_time", createTime)
        re.put("nodeId", ip)
        re.put("async_waybillNo", body.getString("waybillNo"))
        re.put("async_time", createTime)
        //        logger.error(">>>包含sss_chkn_req的数据：kafka topic GIS_ASS_RDS_CHKDEST_ADDR_TO_SSS:"+gid)
        list.add((gid, re))
      }
    }

    //    println("派件批量审补网点："+list)
    list
  }

  //  /**
  //    * kafka topic GIS_ASS_RDS_CHKDEST_TO_ARSS,message: 派件批量审补网点
  //    * 已无用
  //    * @param line : 数据行
  //    * @return
  //    */
  //  def parseGisToArssBak(line: String): util.ArrayList[(String, JSONObject)] = {
  //    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
  //
  //    val list = new util.ArrayList[(String, JSONObject)]
  //
  //    //单个请求
  //    if (chkDisLogObj != null) {
  //      val re = new JSONObject()
  //      val body = chkDisLogObj
  //      val gid = body.getString("gid")
  //      re.put("type", "omsto")
  //      body.put("arss_dept_req_time", createTime)
  //
  //      re.put("arss_dept_req_body", body)
  //      re.put("arss_dept_req_time", createTime)
  //      re.put("nodeId", ip)
  //      re.put("async_waybillNo", body.getString("waybillNo"))
  //      re.put("async_time", createTime)
  //      val taskType = body.getString("taskType")
  //      if (taskType != null && taskType.equals("2")) {
  //        list.add((gid, re))
  //      }
  //    }
  //    //批量请求
  //    if (chkDisLogArray != null) {
  //      val bodys = chkDisLogArray
  //      for (i <- 0 until bodys.size()) {
  //        val re = new JSONObject()
  //        val body = bodys.getJSONObject(i)
  //        val gid = body.getString("gid")
  //        re.put("type", "omsto")
  //        body.put("arss_dept_req_time", createTime)
  //        re.put("arss_dept_req_body", body)
  //        re.put("arss_dept_req_time", createTime)
  //        re.put("nodeId", ip)
  //        re.put("async_waybillNo", body.getString("waybillNo"))
  //        re.put("async_time", createTime)
  //        val taskType = body.getString("taskType")
  //        if (taskType != null && taskType.equals("2")) {
  //          list.add((gid, re))
  //        }
  //      }
  //    }
  //
  //    //    println("派件批量审补网点："+list)
  //    list
  //  }
  /**
   * kafka topic GIS_ASS_RDS_CHKDEST_TO_ARSS,message: 派件批量审补网点
   *
   * @param line : 数据行
   * @return
   */
  def parseGisToArss(line: String) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val list = new util.ArrayList[(String, JSON)]

    //单个请求
    if (chkDisLogObj != null) {
      val re = new JSONObject()
      val body = chkDisLogObj
      val gid = body.getString("gid")
      if (!StringUtil.isBlank(requestId)) {
        re.put("reqId", requestId)
      }
      re.put("type", "omsto")
      body.put("arss_dept_req_time", createTime)
      val bodyArray = new JSONArray()
      bodyArray.add(body)
      val taskType = body.getString("taskType")
      //      if ("2".equals(taskType)) {
      //        re.put("arss_dept_req_body", body)
      //      }
      re.put("arss_dept_req_array", bodyArray)
      re.put("arss_dept_req_time", createTime)
      re.put("nodeId", ip)
      re.put("async_waybillNo", body.getString("waybillNo"))
      re.put("async_time", createTime)

      list.add((gid, re))

    }
    //批量请求
    if (chkDisLogArray != null) {
      val bodys = chkDisLogArray
      for (i <- 0 until bodys.size()) {
        val re = new JSONObject()
        val body = bodys.getJSONObject(i)
        val gid = body.getString("gid")
        val requestId = body.getString("requestId")
        if (!StringUtil.isBlank(requestId)) {
          re.put("reqId", requestId)
        }
        re.put("type", "omsto")
        body.put("arss_dept_req_time", createTime)
        val bodyArray = new JSONArray()
        bodyArray.add(body)
        //        val taskType = body.getString("taskType")
        //        if ("2".equals(taskType)) {
        //          re.put("arss_dept_req_body", body)
        //        }
        re.put("arss_dept_req_array", bodyArray)
        re.put("arss_dept_req_time", createTime)
        re.put("nodeId", ip)
        re.put("async_waybillNo", body.getString("waybillNo"))
        re.put("async_time", createTime)

        list.add((gid, re))

      }
    }

    //    println("派件批量审补网点："+list)
    list
  }

  /**
   * 派件sss审补结果(taskId) =>receive sss addr chk message :
   *
   * @param line : 数据行
   * @return
   */
  def parseSssToGis(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val body = chkDisLogObj
    var gid = body.getString("gid")
    if ("0".equals(gid)) {
      gid = null
    }
    if (!StringUtil.isBlank(requestId)) {
      re.put("reqId", requestId)
    }
    re.put("type", "omsto")
    re.put("sss_dept_re_body", body)
    re.put("sss_dept_re_time", createTime)
    re.put("nodeId", ip)
    re.put("async_waybillNo", body.getString("waybillNo"))
    re.put("async_time", createTime)
    //    println("sss审补结果："+(gid,re))
    (gid, re)
  }

  /**
   * 派件方网点审补结果(taskId) =>receive waybill dept chk message :
   *
   * @param line : 数据行
   * @return
   */
  def parseOmsDeptArss(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val body = chkDisLogObj
    val gid = body.getString("taskId")
    if (!StringUtil.isBlank(requestId)) {
      re.put("reqId", requestId)
    }
    re.put("type", "omsto")
    body.put("arss_dept_re_time", createTime)

    val bodyArray = new JSONArray()
    bodyArray.add(body)
    //    re.put("arss_dept_re_body", body)
    re.put("arss_dept_re_array", bodyArray)
    re.put("arss_dept_re_time", createTime)
    re.put("nodeId", ip)
    re.put("async_waybillNo", body.getString("waybillNo"))
    re.put("async_time", createTime)
    //    println("sss审补结果："+(gid,re))
    (gid, re)
  }


  /**
   * 派件方批量审补单元区域传参给AWSM
   *
   * @param line : 数据行
   * @return
   */
  def parseGisToAwsm(line: String): util.ArrayList[(String, JSONObject)] = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val list = new util.ArrayList[(String, JSONObject)]

    if (chkDisLogObj != null) {
      val re = new JSONObject()
      val body = chkDisLogObj
      val gid = body.getString("gid")
      if (!StringUtil.isBlank(requestId)) {
        re.put("reqId", requestId)
      }
      re.put("type", "omsto")
      re.put("awsm_tc_req_time", createTime)
      re.put("awsm_tc_req_body", body)
      re.put("nodeId", ip)
      re.put("async_waybillNo", body.getString("waybillNo"))
      re.put("async_time", createTime)
      list.add((gid, re))
    }
    if (chkDisLogArray != null) {
      val bodys = chkDisLogArray
      for (i <- 0 until bodys.size()) {
        val re = new JSONObject()
        val body = bodys.getJSONObject(i)
        val gid = body.getString("gid")
        val requestId = body.getString("requestId")
        if (!StringUtil.isBlank(requestId)) {
          re.put("reqId", requestId)
        }
        re.put("type", "omsto")
        re.put("awsm_tc_req_time", createTime)
        re.put("awsm_tc_req_body", body)
        re.put("nodeId", ip)
        re.put("async_waybillNo", body.getString("waybillNo"))
        re.put("async_time", createTime)
        list.add((gid, re))
      }
    }
    //    println("派件批量awsm审补请求："+list)
    list
  }

  /**
   * oms派件方审单元区域补结果 =>receive awsm message :
   *
   * @param line ：数据行
   * @return
   */
  def parseAwsmToGis(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val body = chkDisLogObj
    val gid = body.getString("gid")
    if (!StringUtil.isBlank(requestId)) {
      re.put("reqId", requestId)
    }
    re.put("type", "omsto")
    re.put("awsm_tc_re_time", createTime)
    re.put("awsm_tc_re_body", body)
    re.put("nodeId", ip)
    re.put("async_waybillNo", body.getString("waybillNo"))
    re.put("async_time", createTime)
    //    println("awsm审补结果："+(gid,re))
    (gid, re)
  }

  //  /**
  //    * 补了经纬度返回的数据
  //    * @return
  //    */
  //  def parseGeoData(line: String): (String, JSONObject) ={
  //    var re = new JSONObject()
  ////    val bodyRaw = StringUtil.pickGroup1Str(line, "调用地理编码返回的 (.*)$")
  //    val reqId = StringUtil.pickGroup1Str(line, "--start-- (.*?)=>AWSM GEO return data:")
  ////    val bodyRaw = StringUtil.pickGroup1Str(line, "--调用地理编码返回的OmsWayBillInfoResultData---->(.*)$")
  //    val bodyRaw = StringUtil.pickGroup1Str(line, "=>AWSM GEO return data:(.*)$")
  //    val body = JSON.parseObject(bodyRaw)
  //    var commonAttr = commonParse(line)
  //    re.put("type", "omsto")
  //    re.put("geo_time", commonAttr.get("datetime"))
  //    re.put("geo_body", body)
  //    re.put("nodeId", commonAttr.get("nodeId"))
  ////        println("geo返回结果："+(reqId,re))
  //    (reqId, re)
  //  }

  /**
   * 补了经纬度返回的数据
   *
   * @return
   */
  def parseGeoData(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)

    val re = new JSONObject()
    val gid = StringUtil.pickGroup1Str(chkDisLogType, "gid:(.*?)---=>AWSM GEO return data:").trim
    val body = chkDisLogObj
    if (!StringUtil.isBlank(requestId)) {
      re.put("reqId", requestId)
    }
    re.put("type", "omsto")
    re.put("geo_time", createTime)
    re.put("geo_body", body)
    re.put("nodeId", ip)
    //    println("geo返回结果："+(gid,re))
    (gid, re)
  }

  //  /**
  //    * ATPai
  //    * @return
  //    */
  //  def parseATPaiData(line: String): (String, JSONObject) ={
  //    var re = new JSONObject()
  //    val bodyRaw = StringUtil.pickGroup1Str(line, "ATPai->(.*)$")
  //    val body = JSON.parseObject(bodyRaw)
  //    val reqId = body.getString("requestId")
  //    val atResBody =  body.getJSONObject("res")
  //    val atPaiBody = new JSONObject()
  //    var notc = "0"
  //    var city = ""
  //    var adcode = ""
  //    var groupIds = new util.ArrayList[String]()
  //    var filters = new util.ArrayList[String]()
  //    var adcodes = new util.ArrayList[String]()
  //    var keys = new util.ArrayList[String]()
  //    var keyWords = new util.ArrayList[String]()
  //    var matchIds = new util.ArrayList[String]()
  //    var splitResult = ""
  //    var splitType = "-1"
  //    try{
  //      if(atResBody.containsKey("result")){
  //        val result = atResBody.getJSONObject("result")
  //        if(result.containsKey("tcs")){
  //          val tcs = result.getJSONArray("tcs")
  //          if(tcs != null && tcs.size() > 0)
  //            notc = tcs.getJSONObject(0).getString("notc")
  //        }
  //        if(result.containsKey("myOther")){
  //          var myOther = result.getJSONObject("myOther")
  //          city = JSONUtil.getJsonVal(myOther, "city", "")
  //          adcode = JSONUtil.getJsonVal(myOther, "adcode", "")
  //          if(myOther.containsKey("normresp")){
  //            val normResp = myOther.getJSONObject("normresp")
  //            if(normResp.containsKey("result")){
  //              val normResult = normResp.getJSONObject("result")
  //              splitResult = JSONUtil.getJsonVal(normResult, "splitResult", "").replaceAll(",", "|")
  //              splitType = JSONUtil.getJsonVal(normResult, "splitType", "-1")
  //              val terms = splitResult.split(";")(0).split("\\|")
  //              if(normResult.containsKey("geocoder")){
  //                val geoCoders = normResult.getJSONArray("geocoder")
  //                for(i <- 0 until geoCoders.size()){
  //                  val geoCoder = geoCoders.getJSONObject(i)
  //                  groupIds.add(JSONUtil.getJsonVal(geoCoder, "group", ""))
  //                  filters.add(JSONUtil.getJsonVal(geoCoder, "filter", ""))
  //                  adcodes.add(JSONUtil.getJsonVal(geoCoder, "adcode", ""))
  //                  matchIds.add(JSONUtil.getJsonVal(geoCoder, "id", ""))
  //                  val key = JSONUtil.getJsonVal(geoCoder, "key", "")
  //                  keys.add(key)
  //                  var keyWordBuilder = new StringBuilder
  //                  if(!"".equals(key)){
  //                    for(keyIdx <- key.split("\\|")){
  //                      keyWordBuilder.append(terms(keyIdx.toInt).split("\\^")(0))
  //                    }
  //                  }
  //                  keyWords.add(keyWordBuilder.toString())
  //                }
  //              }
  //            }
  //          }
  //        }
  //      }
  //    }catch {
  //      case e : Exception => logger.error(e)
  //        e.printStackTrace()
  //    }
  //    atPaiBody.put("notc", notc)
  //    atPaiBody.put("city", city)
  //    atPaiBody.put("adcode", adcode)
  //    atPaiBody.put("splitResult", splitResult)
  //    atPaiBody.put("splitType", splitType)
  //    atPaiBody.put("groupIds", groupIds.mkString("$"))
  //    atPaiBody.put("filters", filters.mkString("$"))
  //    atPaiBody.put("adcodes", adcodes.mkString("$"))
  //    atPaiBody.put("keys", keys.mkString("$"))
  //    atPaiBody.put("keyWords", keyWords.mkString("$"))
  //    atPaiBody.put("matchIds", matchIds.mkString("$"))
  //
  //    var commonAttr = commonParse(line)
  //    re.put("type", "omsto")
  //    re.put("atpai_time", commonAttr.get("datetime"))
  //    re.put("atpai_body", atPaiBody)
  //    re.put("nodeId", commonAttr.get("nodeId"))
  //    (reqId, re)
  //  }

  /**
   * ATPai
   *
   * @return
   */
  def parseATPaiData(line: String): (String, JSONObject) = {
    val (requestId, createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
    val re = new JSONObject()
    val body = chkDisLogObj
    val reqId = body.getString("requestId")
    val atResBody = body.getJSONObject("res")
    val atPaiBody = new JSONObject()
    var notc = "0"
    var chkDeptSrc = ""
    var precision = ""
    var src = ""
    var groupId = ""
    var standardization = ""
    var city = ""
    var adcode = ""
    val groupIds = new util.ArrayList[String]()
    val filters = new util.ArrayList[String]()
    val adcodes = new util.ArrayList[String]()
    val keys = new util.ArrayList[String]()
    val keyWords = new util.ArrayList[String]()
    val matchIds = new util.ArrayList[String]()
    val other_matchid = new util.ArrayList[String]()
    var splitResult = ""
    var splitType = "-1"
    var aoiCode = ""
    var atAoiSrc = ""
    try {
      if (atResBody.containsKey("result")) {
        val result = atResBody.getJSONObject("result")
        var idList = JSONUtil.getJSONObject(result, "idList")
        if (idList == null) {
          idList = JSONUtil.getJSONObject(result, "id_list")
        }
        atPaiBody.put("idList", idList)
        if (result.containsKey("tcs")) {
          val tcs = result.getJSONArray("tcs")
          if (tcs != null && tcs.size() > 0) {
            atPaiBody.put("tcs", tcs)
            val tcObj = tcs.getJSONObject(0)
            aoiCode = tcObj.getString("aoicode")
            atAoiSrc = tcObj.getString("atAoiSrc")
            notc = tcObj.getString("notc")
            src = tcObj.getString("src")
            if (tcObj.containsKey("chkDeptSrc")) {
              //增加审补网点来源
              chkDeptSrc = tcObj.getString("chkDeptSrc")
            }
            if (tcObj.containsKey("precision")) {
              //增加精确度
              precision = tcObj.getString("precision")
            }
            if (tcObj.containsKey("other")) {
              val other_obj = tcObj.getJSONObject("other")
              other_matchid.add(JSONUtil.getJsonVal(other_obj, "matchId", ""))
            }

            groupId = tcObj.getString("groupid")
          }
        }
        var myOther = result.getJSONObject("myOther")
        if (myOther == null) {
          myOther = result.getJSONObject("other")
        }
        if (myOther != null) {
          //          val myOther = result.getJSONObject("myOther")
          city = JSONUtil.getJsonVal(myOther, "city", "")
          adcode = JSONUtil.getJsonVal(myOther, "adcode", "")
          if (myOther.containsKey("normresp")) {
            val normResp = myOther.getJSONObject("normresp")
            if (normResp.containsKey("result")) {
              val normResult = normResp.getJSONObject("result")
              splitResult = JSONUtil.getJsonVal(normResult, "splitResult", "").replaceAll(",", "|")
              splitType = JSONUtil.getJsonVal(normResult, "splitType", "-1")
              val terms = splitResult.split(";")(0).split("\\|")
              if (normResult.containsKey("geocoder")) {
                val geoCoders = normResult.getJSONArray("geocoder")
                for (i <- 0 until geoCoders.size()) {
                  val geoCoder = geoCoders.getJSONObject(i)
                  val group = JSONUtil.getJsonVal(geoCoder, "group", "")
                  groupIds.add(group)
                  if ("norm".equals(src) && group.equals(groupId))
                    standardization = JSONUtil.getJsonVal(geoCoder, "standardization", "")
                  filters.add(JSONUtil.getJsonVal(geoCoder, "filter", ""))
                  adcodes.add(JSONUtil.getJsonVal(geoCoder, "adcode", ""))
                  matchIds.add(JSONUtil.getJsonVal(geoCoder, "id", ""))
                  val key = JSONUtil.getJsonVal(geoCoder, "key", "")
                  keys.add(key)
                  val keyWordBuilder = new StringBuilder
                  if (!"".equals(key)) {
                    for (keyIdx <- key.split("\\|")) {
                      keyWordBuilder.append(terms(keyIdx.toInt).split("\\^")(0))
                    }
                  }
                  keyWords.add(keyWordBuilder.toString())
                }
              }
            }
          }
        }
      }
      if (atResBody.containsKey("rpcInfo")) {
        atPaiBody.put("rpcInfo", atResBody.getJSONObject("rpcInfo"))
      }
    } catch {
      case e: Exception =>
      //        logger.error(e)
      //        e.printStackTrace()
    }
    atPaiBody.put("notc", notc)
    atPaiBody.put("city", city)
    atPaiBody.put("adcode", adcode)
    atPaiBody.put("standardization", standardization)
    atPaiBody.put("splitResult", splitResult)
    atPaiBody.put("splitType", splitType)
    atPaiBody.put("groupIds", groupIds)
    atPaiBody.put("filters", filters)
    atPaiBody.put("adcodes", adcodes)
    atPaiBody.put("keys", keys)
    atPaiBody.put("keyWords", keyWords)
    atPaiBody.put("matchIds", matchIds)
    atPaiBody.put("groupId", groupId)
    atPaiBody.put("chkDeptSrc", chkDeptSrc)
    atPaiBody.put("precision", precision)
    atPaiBody.put("other_matchid", other_matchid)
    atPaiBody.put("aoiCode", aoiCode)
    atPaiBody.put("aoiSrc", atAoiSrc)
    re.put("type", "omsto")
    re.put("atpai_time", createTime)
    re.put("atpai_body", atPaiBody)
    re.put("nodeId", ip)
    (reqId, re)
  }



  def main(args: Array[String]): Unit = {
//    val obj = new JSONObject()
//    val bid_re_body = new JSONArray()
//    obj.put("bid_re_body", bid_re_body)
//    val bid_re_body_item = new JSONObject()
//    bid_re_body_item.put("bid_re_time", "2021-05-21 11:00:11 345")
//    bid_re_body_item.put("data", 1)
//    bid_re_body.add(bid_re_body_item)
//    val bid_re_body_item1 = new JSONObject()
//    bid_re_body_item1.put("bid_re_time", "2021-05-21 10:00:11 345")
//    bid_re_body_item1.put("data", 2)
//    bid_re_body.add(bid_re_body_item1)
//    println(obj.toJSONString)
//    extraOp(obj)
//    println(obj.toJSONString)
        val line = "{\"appname\":\"chk-dispatch\",\"createTime\":\"2023-08-12 19:52:03.694\",\"ip\":\"10.244.16.111\",\"level\":\"HDFS\",\"message\":\"{\\\"flag\\\":\\\"0\\\",\\\"identRs\\\":\\\"714AF\\\",\\\"aoiCode\\\":\\\"714AF000254\\\",\\\"opType\\\":\\\"U\\\",\\\"chkDisLogType\\\":\\\"0007522023081215515461014270VSF1451019857254=>receive waybill dept chk message : \\\",\\\"opTm\\\":\\\"2023-08-12 19:52:03\\\",\\\"checkFlag\\\":\\\"2\\\",\\\"result\\\":\\\"2\\\",\\\"empCode\\\":\\\"AUTO:037841:449555018\\\",\\\"requestId\\\":\\\"0007522023081215515461014270VSF1451019857254\\\",\\\"id\\\":\\\"26611170-2a58-4a27-affd-3a0fd56fa04f_449555018\\\",\\\"aoiId\\\":\\\"8E958C1F17A84EF0BB76B570BB059BBC\\\",\\\"taskId\\\":\\\"19852077023\\\",\\\"chkDisLogLev\\\":\\\"INFO\\\",\\\"waybillNo\\\":\\\"SF1451019857254\\\"}\",\"syn\":false}"
        val xx= parseOmsDeptArss(line)
        println(xx)

  }
}
