package com.sf.gis.scala.oms_shou.main

import java.util.Properties

import com.sf.gis.com.sf.gis.scala.oms_shou.constant.FixedConstant
import com.sf.gis.scala.oms_shou.constant.VariableConstant
import com.sf.gis.scala.utils.ConfigurationUtil
import org.apache.hadoop.hbase.client.{HTable, Put}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}
import org.slf4j.{Logger, LoggerFactory}

import scala.util.Random

/**
 * 先不上线,直接使用etl导入hbase
 * 无用代码,待删除， 01374443 20231031
 */
class MainSaveToHbase extends Serializable {

//  @transient lazy val logger: Logger = LoggerFactory.getLogger(classOf[MainSaveToHbase].getClass)
//  val props: Properties = ConfigurationUtil.loadProperties(VariableConstant.CONF, FixedConstant.CHARSET)
//  val appName: String = props.getProperty("app.name")
//
//
//  def startSta(args: Array[String]): Unit = {
//    val incDay = args(0)
//    start(incDay)
//  }
//
//  def start(incDay: String): Unit = {
//    logger.info(s">>>incDay : $incDay, appName : $appName")
//    val spark = getSparkSession()
//    run(spark, incDay)
//  }
//
//  def getSparkSession(): SparkSession = {
//    val conf = new SparkConf().setAppName(appName)
//    conf.set("spark.port.maxRetries", "100")
//    conf.set("spark.driver.allowMultipleContexts", "true")
//    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
//    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
//    conf.set("quota.consumer.default", (10485760 * 2).toString)
//    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
//    conf.set("hive.exec.dynamic.partition", "true")
//    conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
//    //高峰期配置 begin
//    //    conf.set("spark.executor.instances", "60")
//    //    conf.set("spark.executor.memory", "40g")
//    //    conf.set("spark.yarn.executor.memoryOverhead", "10g")
//    //    conf.set("spark.executor.cores", "10")
//    //高峰期配置 end
//    conf.set("spark.executor.heartbeatInterval", "10000000")
//    conf.set("spark.network.timeout", "10000000")
//    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
//    val sc = new SparkContext(conf)
//    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate
//    sc.setLogLevel("ERROR")
//    spark
//  }
//
//
//  def queryDataFromHive(spark: SparkSession, incDay: String): RDD[(String, String)] = {
//    val sql = s"select rowkey,data from ${MainNew.hbaseTableName} where inc_day='${incDay}'"
//    val dataRdd = spark.sql(sql).rdd.map(obj => {
//      (Random.nextInt(50), (obj.getString(0), obj.getString(1)))
//    }).repartition(50).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("数据量:" + dataRdd.count())
//    dataRdd
//  }
//
//  def run(spark: SparkSession, incDay: String): Unit = {
//    logger.error("获取即将入库的hbase数据")
//    val dataRdd = queryDataFromHive(spark, incDay)
//    logger.error("存储hbase数据")
//    saveToHbase(dataRdd)
//    logger.error("the end~")
//  }
//
//
//  def saveToHbase(orderDataRdd: RDD[(String, String)]): Unit = {
//    orderDataRdd.foreachPartition(rdd => {
//      val table = getTable(props.getProperty("hbase.gis.oms.table"))
//      rdd.foreach(obj => {
//        val key = obj._1
//        val jsonObj = obj._2
//        val put = new Put(Bytes.toBytes(key))
//        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("value"), Bytes.toBytes(jsonObj.toString))
//        table.put(put)
//      })
//      table.flushCommits()
//      table.close()
//    })
//    logger.error(">>>收件下call解析数据入hbase结束。")
//  }
//
//  def getTable(tableName: String): HTable = {
//    val hbaseConf = HBaseConfiguration.create()
//    //设置写入的表
//    hbaseConf.set("zookeeper.znode.parent", props.getProperty("zookeeper.znode.parent"))
//    hbaseConf.set("hbase.zookeeper.quorum", props.getProperty("hbase.zookeeper.quorum"))
//    hbaseConf.set("hbase.zookeeper.property.clientPort", props.getProperty("hbase.zookeeper.property.clientPort"))
//    //noinspection ScalaDeprecation
//    val table = new HTable(hbaseConf, TableName.valueOf(tableName))
////    table.setAutoFlush(false, false)
//    //    table.setWriteBufferSize(1*1024)
////    table.setWriteBufferSize(512)
//    table
//  }
}