//package com.sf.gis.scala.utils;
//
//import com.sf.gis.scala.oms_pai.start.JavaUtil;
//import org.apache.log4j.Logger;
//
//import java.io.Serializable;
//import java.lang.reflect.InvocationHandler;
//import java.lang.reflect.Method;
//import java.lang.reflect.Proxy;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.util.Vector;

///**
// * Created by 01375125 on 2018/6/11.
// * 连接mysql数据库，执行增删改查操作
// */
//public class DbConnection implements Serializable {
//    static Logger logger = Logger.getLogger(DbConnection.class);
//    private static Vector<Connection> pools;
//    private final int POOL_MAXSIZE;
//
////    private String URL;
////    private String NAME;
////    private String USERNAME;
////    private String PASSWORD;
//
//    private static final String NAME = JavaUtil.getString("oms.mysql.driver");
//    private static final String URL = JavaUtil.getString("oms.mysql.url");
//    private static final String USERNAME = JavaUtil.getString("oms.mysql.uid");
//    private static final String PASSWORD = JavaUtil.getString("oms.mysql.pwd");
//
//    public DbConnection() {
//        POOL_MAXSIZE = 50;
//    }


//    public DbConnection(){
//        setURL();
//    }

//    /**
//     * 获取连接
//     *
//     * @return Connection: 结果
//     */
//    public synchronized Connection getConn() {
//        Connection conn;
//        if (pools == null)
//            pools = new Vector<>();
//
//        if (pools.isEmpty()) {
//            conn = createConn();
//        } else {
//            int last_index = pools.size() - 1;
//            conn = pools.get(last_index);
//            pools.remove(last_index);
//        }
//        ConnectionHandler handler = new ConnectionHandler(this);
//        return handler.bind(conn);
//    }

//    /**
//     * 注册驱动连接
//     *
//     * @return Connection:
//     */
//    private static Connection createConn() {
//        Connection conn = null;
//        try {
//            Class.forName(NAME);
//
//            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
//        } catch (Exception e) {
//            logger.error("数据库连接出错,driver=>" + NAME + ",url=>" + URL + ",username=>" + USERNAME + ",password=>" + PASSWORD, e);
//        }
//        return conn;
//    }

//    /**
//     * 关闭链接
//     *
//     * @param conn: 连接
//     */
//    public synchronized void close(Connection conn) {
//        if (pools.size() >= POOL_MAXSIZE) try {
//            if (conn != null)
//                conn.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        else {
//            pools.add(conn);
//        }
//    }


//}
//
//class ConnectionHandler implements InvocationHandler {
//
//    private Connection conn;
//    private DbConnection dbHelper;
//
//    ConnectionHandler(DbConnection dbHelper) {
//        this.dbHelper = dbHelper;
//    }
//
//    Connection bind(Connection conn) {
//        this.conn = conn;
//        return (Connection) Proxy.newProxyInstance(conn.getClass().getClassLoader(), new Class[]{Connection.class}, this);
//    }
//
//    //    @Override
//    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
//        Object object = null;
//        if ("close".equals(method.getName())) {
//            this.dbHelper.close(this.conn);
//        } else {
//            object = method.invoke(this.conn, args);
//        }
//        return object;
//    }

//}
