package com.sf.gis.scala.oms_shou.pojo.rds;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/8.
 */
public class Ret implements Serializable {
    private String retType;
    private String teamRetBy;
    private String src;
    private String taskKey;
    private String groupid;
    private AtSrvRet atSrvRet;
    private String message;
    private boolean notArss;
    private Team team;
    private String buildingId;
    private String buildingName;
    private String buildingAoiId;

    public String getBuildingId() {
        return buildingId;
    }

    public void setBuildingId(String buildingId) {
        this.buildingId = buildingId;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getBuildingAoiId() {
        return buildingAoiId;
    }

    public void setBuildingAoiId(String buildingAoiId) {
        this.buildingAoiId = buildingAoiId;
    }

    public String getRetType() {
        return retType;
    }

    public void setRetType(String retType) {
        this.retType = retType;
    }

    public String getTeamRetBy() {
        return teamRetBy;
    }

    public void setTeamRetBy(String teamRetBy) {
        this.teamRetBy = teamRetBy;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getTaskKey() {
        return taskKey;
    }

    public void setTaskKey(String taskKey) {
        this.taskKey = taskKey;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public AtSrvRet getAtSrvRet() {
        return atSrvRet;
    }

    public void setAtSrvRet(AtSrvRet atSrvRet) {
        this.atSrvRet = atSrvRet;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isNotArss() {
        return notArss;
    }

    public void setNotArss(boolean notArss) {
        this.notArss = notArss;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
}
