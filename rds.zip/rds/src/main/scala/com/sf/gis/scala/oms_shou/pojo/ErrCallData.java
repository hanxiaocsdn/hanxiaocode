package com.sf.gis.scala.oms_shou.pojo;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/8.
 */
public class ErrCallData implements Serializable{
    private String id;
    private String reqDate;
    private String reqTime;
    private int frequency;
    private String sysOrderNo;
    private String province;
    private String city;
    private String county;
    private String cityCode;
    private String address;
    private String matchSrc;
    private String srcDetail;
    private String matchDept;
    private String matchTeam;
    private String matchGroupId;
    private String errCallDept;
    private String errCallTeam;
    private String errCallAddrAbb;
    private String chkDept;
    private String chkTeam;
    private String chkEmpId;
    private String chkModifyUser;
    private String miningDept;
    private String miningTeam;
    private String errCallDate;
    private String company;
    private String mobile;
    private String phone;
    private String aoiId;
    private String current_state;
    private String resource_id;
    private String pick_up_tc;
    private String is_wrong_report;

    public String getResource_id() {
        return resource_id;
    }

    public void setResource_id(String resource_id) {
        this.resource_id = resource_id;
    }

    public String getPick_up_tc() {
        return pick_up_tc;
    }

    public void setPick_up_tc(String pick_up_tc) {
        this.pick_up_tc = pick_up_tc;
    }

    public String getIs_wrong_report() {
        return is_wrong_report;
    }

    public void setIs_wrong_report(String is_wrong_report) {
        this.is_wrong_report = is_wrong_report;
    }

    public String getCurrent_state() {
        return current_state;
    }

    public void setCurrent_state(String current_state) {
        this.current_state = current_state;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getReqDate() {
        return reqDate;
    }

    public void setReqDate(String reqDate) {
        this.reqDate = reqDate;
    }

    public String getReqTime() {
        return reqTime;
    }

    public void setReqTime(String reqTime) {
        this.reqTime = reqTime;
    }

    public int getFrequency() {
        return frequency;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public String getSysOrderNo() {
        return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMatchSrc() {
        return matchSrc;
    }

    public void setMatchSrc(String matchSrc) {
        this.matchSrc = matchSrc;
    }

    public String getSrcDetail() {
        return srcDetail;
    }

    public void setSrcDetail(String srcDetail) {
        this.srcDetail = srcDetail;
    }

    public String getMatchDept() {
        return matchDept;
    }

    public void setMatchDept(String matchDept) {
        this.matchDept = matchDept;
    }

    public String getMatchTeam() {
        return matchTeam;
    }

    public void setMatchTeam(String matchTeam) {
        this.matchTeam = matchTeam;
    }

    public String getMatchGroupId() {
        return matchGroupId;
    }

    public void setMatchGroupId(String matchGroupId) {
        this.matchGroupId = matchGroupId;
    }

    public String getErrCallDept() {
        return errCallDept;
    }

    public void setErrCallDept(String errCallDept) {
        this.errCallDept = errCallDept;
    }

    public String getErrCallTeam() {
        return errCallTeam;
    }

    public void setErrCallTeam(String errCallTeam) {
        this.errCallTeam = errCallTeam;
    }

    public String getErrCallAddrAbb() {
        return errCallAddrAbb;
    }

    public void setErrCallAddrAbb(String errCallAddrAbb) {
        this.errCallAddrAbb = errCallAddrAbb;
    }

    public String getChkDept() {
        return chkDept;
    }

    public void setChkDept(String chkDept) {
        this.chkDept = chkDept;
    }

    public String getChkTeam() {
        return chkTeam;
    }

    public void setChkTeam(String chkTeam) {
        this.chkTeam = chkTeam;
    }

    public String getChkEmpId() {
        return chkEmpId;
    }

    public void setChkEmpId(String chkEmpId) {
        this.chkEmpId = chkEmpId;
    }

    public String getChkModifyUser() {
        return chkModifyUser;
    }

    public void setChkModifyUser(String chkModifyUser) {
        this.chkModifyUser = chkModifyUser;
    }

    public String getMiningDept() {
        return miningDept;
    }

    public void setMiningDept(String miningDept) {
        this.miningDept = miningDept;
    }

    public String getMiningTeam() {
        return miningTeam;
    }

    public void setMiningTeam(String miningTeam) {
        this.miningTeam = miningTeam;
    }

    public String getErrCallDate() {
        return errCallDate;
    }

    public void setErrCallDate(String errCallDate) {
        this.errCallDate = errCallDate;
    }
}
