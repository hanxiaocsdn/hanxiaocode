package com.sf.gis.scala.oms_shou.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/6.
 */
@Entity
public class OmsPuBuz implements Serializable{
    @Column(name = "ID")
    private String id;
    @Column(name = "STAT_DATE")
    private String statDate;    //数据日期
    @Column(name = "PROVINCE")
    private String province;    //省
    @Column(name = "REGION")
    private String region;  //大区
    @Column(name = "CITY_CODE")
    private String cityCode;    //城市代码
    @Column(name = "CITY")
    private String city;    //城市
    @Column(name = "REQ")
    private int req; //请求量
    @Column(name = "ORDER")
    private int order; //订单量
    @Column(name = "SYNC")
    private int sync;   //同步请求量
    @Column(name = "SYNC_RESP")
    private int syncResp;   //同步返回量
    @Column(name = "SYNC_UNRESP")
    private int syncUnResp; //同步未返回量
    @Column(name = "SYNC_KAFKA")
    private int syncKafka; //同步推送kafka的量
    @Column(name = "ASYNC")
    private int async;  //异步请求量
    @Column(name = "ASYNC_RESP")
    private int asyncResp;  //异步返回量
    @Column(name = "ASYNC_UNRESP")
    private int asyncUnResp;    //异步未返回量
    @Column(name = "ASYNC_KAFKA")
    private int asyncKafka;    //异步推送kafka的量
    @Column(name = "ARSS_RECEIVE")
    private int arssReceive;    //ARSS每天的接收量
    @Column(name = "ARSS_SEND")
    private int arssSend;   //ARSS每天完成推到kafka的量
    @Column(name = "KAFKA_RECEIVE")
    private int kafkaReceive; //发送给OMS结果的kafka接收到的量

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getReq() {
        return req;
    }

    public void setReq(int req) {
        this.req = req;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getSync() {
        return sync;
    }

    public void setSync(int sync) {
        this.sync = sync;
    }

    public int getSyncResp() {
        return syncResp;
    }

    public void setSyncResp(int syncResp) {
        this.syncResp = syncResp;
    }

    public int getSyncUnResp() {
        return syncUnResp;
    }

    public void setSyncUnResp(int syncUnResp) {
        this.syncUnResp = syncUnResp;
    }

    public int getSyncKafka() {
        return syncKafka;
    }

    public void setSyncKafka(int syncKafka) {
        this.syncKafka = syncKafka;
    }

    public int getAsync() {
        return async;
    }

    public void setAsync(int async) {
        this.async = async;
    }

    public int getAsyncResp() {
        return asyncResp;
    }

    public void setAsyncResp(int asyncResp) {
        this.asyncResp = asyncResp;
    }

    public int getAsyncUnResp() {
        return asyncUnResp;
    }

    public void setAsyncUnResp(int asyncUnResp) {
        this.asyncUnResp = asyncUnResp;
    }

    public int getAsyncKafka() {
        return asyncKafka;
    }

    public void setAsyncKafka(int asyncKafka) {
        this.asyncKafka = asyncKafka;
    }

    public int getArssReceive() {
        return arssReceive;
    }

    public void setArssReceive(int arssReceive) {
        this.arssReceive = arssReceive;
    }

    public int getArssSend() {
        return arssSend;
    }

    public void setArssSend(int arssSend) {
        this.arssSend = arssSend;
    }

    public int getKafkaReceive() {
        return kafkaReceive;
    }

    public void setKafkaReceive(int kafkaReceive) {
        this.kafkaReceive = kafkaReceive;
    }

    public void merge(OmsPuBuz obj){
        this.req += obj.getReq();
        this.order += obj.getOrder();
        this.sync += obj.getSync();
        this.syncResp += obj.getSyncResp();
        this.syncUnResp += obj.getSyncUnResp();
        this.syncKafka += obj.getSyncKafka();
        this.async += obj.getAsync();
        this.asyncResp += obj.getAsyncResp();
        this.asyncUnResp += obj.getAsyncUnResp();
        this.asyncKafka += obj.getAsyncKafka();
        this.arssReceive += obj.getArssReceive();
        this.arssSend += obj.getArssSend();
        this.kafkaReceive += obj.getKafkaReceive();
    }
}
