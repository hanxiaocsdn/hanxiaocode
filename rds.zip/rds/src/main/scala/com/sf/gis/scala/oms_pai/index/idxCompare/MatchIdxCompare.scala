package com.sf.gis.scala.oms_pai.index.idxCompare

import com.sf.gis.scala.utils.Util
import org.apache.log4j.Logger

/**
  * Created by 01368078 on 2019/3/22.
  */

object MatchIdxCompare{
  def main(args: Array[String]): Unit = {

    val incDay = Util.dateDelta(args(0).toInt,"")
    val comp = new MatchIdxCompare()
    comp.comapre(incDay)
//    comp.comapre(Util.getDay(incDay, -5, ""))
//    comp.comapre(Util.getDay(incDay, -4, ""))
//    comp.comapre(Util.getDay(incDay, -3, ""))
//    comp.comapre(Util.getDay(incDay, -2, ""))
//    comp.comapre(Util.getDay(incDay, -1, ""))
//    comp.comapre(Util.getDay(incDay, 0, ""))
  }
}

class MatchIdxCompare {
  val logger: Logger = Logger.getLogger(classOf[MatchIdxCompare])
  def comapre(incDay : String) : Unit = {
    val refDate = Util.getDay(incDay,-7,"")
    val threshold = 0.02
    val ALL = "ALL"
    val columns = Array("STAT_DATE", "REGION", "CITY", "REQ", "ZC", "ZC_NORM", "ZC_CHKN", "ZC_CHKE", "ZC_PHONE",
      "ZC_ROAD", "ZC_TC2", "ZC_AUTO", "ZC_NORMHP", "ZC_NORMCOMPANY", "ZC_GISSSS", "ZC_SSS", "ZC_ARSS", "ZC_ARSS_REQ", "ZC_ARSS_RESP") //查询的字段
    val keyIdxs = Array(0, 1, 2)  //主键下标
    val numIdxs = Array(3) //数量下标
    val rateIdxs = Array(4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18) //比率下标
    val flags = Array(0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)  //1->上升变好，-1->下降变好

    val DLV_RCG = "DLV_RCG"
    val sqlPat =
      s"""select STAT_DATE, REGION, CITY, sum(coalesce(REQ, 0)) REQ, sum(coalesce(ZC, 0))/sum(coalesce(REQ, 0)) ZC,
         |  sum(coalesce(ZC_NORM, 0))/sum(coalesce(REQ, 0)) ZC_NORM, sum(coalesce(ZC_CHKN, 0))/sum(coalesce(REQ, 0)) ZC_CHKN,
         |  sum(coalesce(ZC_CHKE, 0))/sum(coalesce(REQ, 0)) ZC_CHKE, sum(coalesce(ZC_PHONE, 0))/sum(coalesce(REQ, 0)) ZC_PHONE,
         |  sum(coalesce(ZC_ROAD, 0))/sum(coalesce(REQ, 0)) ZC_ROAD, sum(coalesce(ZC_TC2, 0))/sum(coalesce(REQ, 0)) ZC_TC2,
         |  sum(coalesce(ZC_AUTO, 0))/sum(coalesce(REQ, 0)) ZC_AUTO, sum(coalesce(ZC_NORMHP, 0))/sum(coalesce(REQ, 0)) ZC_NORMHP,
         |  sum(coalesce(ZC_NORMCOMPANY, 0))/sum(coalesce(REQ, 0)) ZC_NORMCOMPANY,
         |  sum(coalesce(ZC_GISSSS, 0))/sum(coalesce(REQ, 0)) ZC_GISSSS, sum(coalesce(ZC_SSS, 0))/sum(coalesce(REQ, 0)) ZC_SSS,
         |  sum(coalesce(ZC_ARSS, 0))/sum(coalesce(REQ, 0)) ZC_ARSS, sum(coalesce(ZC_ARSS_REQ, 0))/sum(coalesce(REQ, 0)) ZC_ARSS_REQ,
         |  sum(coalesce(ZC_ARSS_RESP, 0))/sum(coalesce(REQ, 0)) ZC_ARSS_RESP from $DLV_RCG where STAT_TYPE='REGION' and STAT_DATE = '%s'
         |  group by REGION
         |union
         |  select STAT_DATE, REGION, CITY, sum(coalesce(REQ, 0)) REQ, sum(coalesce(ZC, 0))/sum(coalesce(REQ, 0)) ZC,
         |  sum(coalesce(ZC_NORM, 0))/sum(coalesce(REQ, 0)) ZC_NORM, sum(coalesce(ZC_CHKN, 0))/sum(coalesce(REQ, 0)) ZC_CHKN,
         |  sum(coalesce(ZC_CHKE, 0))/sum(coalesce(REQ, 0)) ZC_CHKE, sum(coalesce(ZC_PHONE, 0))/sum(coalesce(REQ, 0)) ZC_PHONE,
         |  sum(coalesce(ZC_ROAD, 0))/sum(coalesce(REQ, 0)) ZC_ROAD, sum(coalesce(ZC_TC2, 0))/sum(coalesce(REQ, 0)) ZC_TC2,
         |  sum(coalesce(ZC_AUTO, 0))/sum(coalesce(REQ, 0)) ZC_AUTO, sum(coalesce(ZC_NORMHP, 0))/sum(coalesce(REQ, 0)) ZC_NORMHP,
         |  sum(coalesce(ZC_NORMCOMPANY, 0))/sum(coalesce(REQ, 0)) ZC_NORMCOMPANY,
         |  sum(coalesce(ZC_GISSSS, 0))/sum(coalesce(REQ, 0)) ZC_GISSSS, sum(coalesce(ZC_SSS, 0))/sum(coalesce(REQ, 0)) ZC_SSS,
         |  sum(coalesce(ZC_ARSS, 0))/sum(coalesce(REQ, 0)) ZC_ARSS, sum(coalesce(ZC_ARSS_REQ, 0))/sum(coalesce(REQ, 0)) ZC_ARSS_REQ,
         |  sum(coalesce(ZC_ARSS_RESP, 0))/sum(coalesce(REQ, 0)) ZC_ARSS_RESP from $DLV_RCG where STAT_TYPE='CITY' and STAT_DATE = '%s'
         |  group by CITY
       """.stripMargin
    logger.error("sql : " + sqlPat)
    logger.error("get current date : " + incDay)
    val curSql = String.format(sqlPat, incDay, incDay)
    logger.error("get ref date : " + refDate)
    val refSql = String.format(sqlPat, refDate, refDate)
    val outTable = "IC_DLV_RCG"
    new IdxCompare(curSql, refSql, threshold, columns, keyIdxs, numIdxs, rateIdxs, flags, outTable).idxCompare(incDay)
  }
}
