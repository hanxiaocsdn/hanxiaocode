package com.sf.gis.scala.utils

object TestScala {
  def main(args: Array[String]): Unit = {
    //    val hbaseConf = HBaseConfiguration.create()
    //    //设置写入的表
    //    hbaseConf.set("zookeeper.znode.parent", "/hbase")
    //    //cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545
    //    //hbaseConf.set("hbase.zookeeper.quorum", javaUtil.get("hbase.zookeeper.quorum"))
    //    hbaseConf.set("hbase.zookeeper.quorum", "10.117.105.36,10.117.105.37,10.117.105.38,10.117.105.39,10.117.105.40")
    //    hbaseConf.set("hbase.zookeeper.property.clientPort", "2181")
    //
    //    //    hbaseConf.set("hbase.client.keyvalue.maxsize","524288000");
    //    //noinspection ScalaDeprecation
    //    val table = new HTable(hbaseConf, TableName.valueOf("gis:rds_oms_online_stat"))
    //    table.setAutoFlush(false, false)
    //    //    table.setWriteBufferSize(1 * 1024)
    //    table.setWriteBufferSize(512)
    //    val key = getKeyByStr("zxy_test_20220808")
    //    println("key:" + key)
    //    val put = new Put(Bytes.toBytes(key))
    //    put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("oms_value"), Bytes.toBytes("{}"))
    //    table.put(put)
    //    table.flushCommits()
    //    table.close()
  }
}
