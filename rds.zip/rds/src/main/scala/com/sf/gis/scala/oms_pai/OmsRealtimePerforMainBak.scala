package com.sf.gis.scala.oms_pai

import java.sql.Connection
import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.druid.support.json.JSONUtils
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, MD5Util}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import com.sf.gis.scala.oms_pai.start.JavaUtil
import com.sf.gis.scala.utils.DbUtils
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Durations, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ArrayBuffer


/**
 * 派件日志实时指标统计
 */
object OmsRealtimePerforMainBak {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val javaUtil = new JavaUtil(6) //6表示rds服务

  def main(args: Array[String]): Unit = {
    if (args.length == 0) {
      //不传参数，实时
      start()
    } else {
      //传入参数，离线，某天日期，如"2019-08-13"
      val date = args(0)
      dealOfflineTask(date)
    }
  }

  /**
   * 执行入口
   */
  def start(): Unit = {

    val sc = new SparkContext(getConf(appName))
    sc.setLogLevel("ERROR")
    val ssc = new StreamingContext(sc, Durations.seconds(5 * 60))
    ssc.sparkContext.setLogLevel("ERROR")
    val format = FastDateFormat.getInstance("yyyy-MM-dd")
    val today = format.format(Calendar.getInstance().getTime)

    var hdfsPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/chk_pai_log_flink/%s"
    //		var hdfsPath = "hdfs://stream/user/hive/warehouse/dm_gis.db/ods_kafka_bee_logs_gis_ass_rds_chk_dispatch/%s"

    hdfsPath = String.format(hdfsPath, today.replaceAll("-", ""))
    println("-----------------------------------开始数据处理-----------------------------------------------")
    logger.error(">>>统计日期：" + today + ",>>>日志路径：" + hdfsPath + ",>>>appName=" + appName)

    val lines: DStream[String] = ssc.textFileStream(hdfsPath).repartition(100)
    lines.foreachRDD(lineRdd => {
      logger.error(">>>统计日期：" + today + ",>>>日志路径：" + hdfsPath + ",>>>appName=" + appName)
      logger.error(">>>新增日志量：" + lineRdd.count())
    })
    val windowLog: DStream[String] = lines.window(Durations.seconds(10 * 60), Durations.seconds(5 * 60))
    logger.error(">>>处理窗口获取的日志")
    dealWindowLog(sc, windowLog, today)

    ssc.start()
    val checkIntervalMillis = 20000
    var stopFlag = false
    while (!stopFlag) {
      val isStopped = ssc.awaitTerminationOrTimeout(checkIntervalMillis)
      if (isStopped) {
        logger.error("WARNING!!! The spark streaming context is stopped. Exiting application ......")
        stopFlag = true
      }
      val curDay = format.format(Calendar.getInstance().getTime)
      if (!curDay.equals(today)) {
        logger.error("跨天了，强行停止~~~")
        ssc.stop(stopSparkContext = true, stopGracefully = false)
      }
      //      val curTime = DateUtils.longToTime(new Date().getTime,"yyyyMMddHHmm")
      //      if(curTime.startsWith("20200225181")){
      //        streamingContext.stop(stopSparkContext = true,stopGracefully = false)
      //        logger.error("stop~~~")
      //      }else{
      //        logger.error("no stop~~~"+curTime)
      //      }
    }
    logger.error(">>>The end!")
  }

  /**
   * 解析离线日期数据
   */
  def dealOfflineTask(today: String): Unit = {
    //    val today="2019-08-13"
    var hdfsPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/chk_pai_log_flink/%s"
    hdfsPath = String.format(hdfsPath, today.replaceAll("-", ""))
    val spark = Spark.getSparkSession(appName)
    val logRdd = spark.sparkContext.textFile(hdfsPath)
    handleLogData(spark.sparkContext, logRdd: RDD[String], today: String)
  }

  /**
   * 处理窗口获取的日志
   *
   * @param windowLog
   */
  def dealWindowLog(sc: SparkContext, windowLog: DStream[String], today: String): Unit = {
    windowLog.foreachRDD(logRdd => {
      logger.error("---------------------------------本次流数据处理开始-------------------------------------------")
      logger.error(">>>统计日期：" + today + ",>>>appName=" + appName)
      handleLogData(sc, logRdd: RDD[String], today: String)
      logger.error("---------------------------------本次流数据处理结束-------------------------------------------")
    })

  }

  def handleLogData(sc: SparkContext, logRdd: RDD[String], today: String): Unit = {
    try {
      val statLog = parseLog(sc, logRdd, today)
      var indexRdd: RDD[JSONObject] = statIndex(statLog).repartition(1).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error(">>>指标入库量：" + indexRdd.count() + ",指标入库中...")
      updateIndex(indexRdd)
      statLog.unpersist()
      indexRdd.unpersist()
      logger.error(">>>指标入库结束.")
    } catch {
      case e: Exception => logger.error("----------------本次流处理异常--------------------")
    }
  }

  /**
   * 统计实时指标
   *
   * @param statLog
   * @return
   */
  def statIndex(statLog: RDD[JSONObject]): RDD[JSONObject] = {
    val reqRdd = statLog.filter(json => {
      val reqTime = json.getString("reqTime")
      reqTime != null
    }).map(json => {
      var reqTime = json.getString("reqTime")
      val ak = "ALL"
      val dimension = "TOTAL"
      val gisTime = json.getString("gisTime")

      var time = 0
      if (gisTime != null) {
        try {
          time = (timeToLong(gisTime) - timeToLong(reqTime)).toInt
        } catch {
          case e: Exception => logger.error(">>>时间处理错误" + e)
        }
      }
      reqTime = reqTime.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "").substring(0, 12)
      ((reqTime, ak, dimension), time)
    })

    val indexRddMin = reqRdd.groupByKey().map(record => {
      val reqTime = record._1._1
      val ak = record._1._2
      val dimension = record._1._3
      val date = reqTime.substring(0, 8)

      val groupRdd: Iterable[Int] = record._2
      val reqCount = groupRdd.size
      var respTimeList = new ArrayBuffer[Int]()
      for (respTime <- groupRdd) {
        if (respTime != 0) respTimeList += respTime
      }
      respTimeList = respTimeList.sorted //升序排列
      val size = respTimeList.size
      var avgRespTime, maxRespTime, minRespTime, p99RespTime = 0
      if (size > 0) {
        avgRespTime = Math.round(respTimeList.sum / size)
        maxRespTime = respTimeList(respTimeList.length - 1)
        minRespTime = respTimeList(0)
        val p99Index = Math.round(respTimeList.size * 0.99).toInt
        p99RespTime = respTimeList(p99Index - 1)
      }
      val json = new JSONObject()

      json.put("reqTime", reqTime)
      json.put("ak", ak)
      json.put("dimension", dimension)
      json.put("date", date)
      json.put("reqCount", reqCount)
      json.put("maxRespTime", maxRespTime)
      json.put("avgRespTime", avgRespTime)
      json.put("minRespTime", minRespTime)
      json.put("p99RespTime", p99RespTime)
      json
    })
    indexRddMin
  }

  def updateIndex(indexRdd: RDD[JSONObject]): Unit = {
    val REQ_CHK_DLV = "REQ_CHK_DLV"
    val REQ_CHK_DLV_DETAIL = "REQ_CHK_DLV_DETAIL"
    logger.error(">>>打印分钟指标")
    println("id,stat_datetime,ak,stat_dmns,req_count,resp_time,resp_time_99,stat_date")
    indexRdd.take(1).foreach(println)
    //      indexRdd.repartition()
    indexRdd.foreachPartition(partitionRdd => {
      var conn: Connection = null
      try {
        conn = DbUtils.getConn
        partitionRdd.foreach(json => {
          var ak = json.getString("ak")
          if (ak == null) ak = "-"
          val reqTime = json.getString("reqTime")
          val date = json.getString("date")
          val dimension = json.getString("dimension")
          val reqCount = json.getInteger("reqCount")
          val avgRespTime = json.getInteger("avgRespTime")
          val p99RespTime = json.getInteger("p99RespTime")
          val id = MD5Util.getMD5(reqTime + ak + dimension)

          //更新实时分钟表
          val selectSql = String.format("select req_count from %s where id='%s' ", REQ_CHK_DLV_DETAIL, id)
          val insertSql = String.format("insert into %s (id,stat_datetime,ak,stat_dmns,req_count,resp_time,resp_time_99,stat_date) values('%s','%s','%s','%s',%s,'%s',%s,'%s')", REQ_CHK_DLV_DETAIL, id, reqTime, ak, dimension, reqCount.toString, avgRespTime.toString, p99RespTime.toString, date)
          val updateSql = String.format("update %s set req_count=%s,resp_time=%s,resp_time_99=%s where id = '%s' ", REQ_CHK_DLV_DETAIL, reqCount.toString, avgRespTime.toString, p99RespTime.toString, id)
          val stmt = conn.createStatement()
          val resultSet = stmt.executeQuery(selectSql)
          if (resultSet.first()) {
            //调用first判断是否有返回值,移动了光标,因此不需要next(),即可取值,否则查询时先执行while(resultSet.next()).
            val count = resultSet.getInt(1)
            if (count < reqCount) {
              //新增的指标数据更好
              stmt.executeUpdate(updateSql)
            }
          } else {
            //没有查询到数据，直接执行插入
            stmt.executeUpdate(insertSql)
          }

          val arr = Array(id, reqTime, ak, dimension, reqCount, avgRespTime, p99RespTime, date)
          //			println("分钟数据："+arr.mkString(","))


          //更新oms派件实时当天表
          val idDate = MD5Util.getMD5(date + ak + dimension)
          val columns = Array("req_max", "req_avg", "req_min", "resp_time_max", "resp_time_avg", "resp_time_min", "resp_time_99max", "resp_time_99avg", "resp_time_99min")
          val selectSqlDay = String.format(s"select MAX(req_count) req_max,AVG(req_count) req_avg ,MIN(req_count) req_min  , MAX(resp_time) resp_time_max,AVG(resp_time) resp_time_avg,MIN(resp_time) resp_time_min  ,MAX(resp_time_99) resp_time_99max,AVG(resp_time_99) resp_time_99avg ,MIN(resp_time_99) resp_time_99min from $REQ_CHK_DLV_DETAIL where  ak = '%s' and stat_dmns = '%s' AND stat_date= '%s' ", ak, dimension, date)
          val dayIndexss: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, selectSqlDay, null, columns)
          val dayIndexs = dayIndexss(0)
          //			println("按天指标："+dayIndexs.mkString(","))
          //			val insertSqlDay= String.format(s"insert into  $REQ_CHK_DLV(id,stat_date,ak,stat_dmns,req_max,req_avg,req_min,resp_time_max,resp_time_avg,resp_time_min,resp_time_99max,resp_time_99avg,resp_time_99min) values('%s','%s','%s','%s',%s,%s,%s,%s,%s,%s,%s,%s,%s) on duplicate key update id='%s' ",idDate,date,ak,dimension,dayIndexs(0), dayIndexs(1), dayIndexs(2),dayIndexs(3), dayIndexs(4), dayIndexs(5),dayIndexs(6), dayIndexs(7), dayIndexs(8),idDate)
          //			val stmtDay = conn.createStatement()
          //			stmtDay.executeUpdate(insertSqlDay)

          //			println("按天指标："+dayIndexs.mkString(","))
          val insertSqlDay = String.format(s"insert into  $REQ_CHK_DLV(id,stat_date,stat_dmns,ak,req_max,req_avg,req_min,resp_time_max,resp_time_avg,resp_time_min,resp_time_99max,resp_time_99avg,resp_time_99min) values(?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update stat_date=?,stat_dmns=?,ak=?,req_max=?,req_avg=?,req_min=?,resp_time_max=?,resp_time_avg=?,resp_time_min=?,resp_time_99max=?,resp_time_99avg=?,resp_time_99min=? ")
          val paramArray = Array(idDate, date, dimension, ak, dayIndexs(0), dayIndexs(1), dayIndexs(2), dayIndexs(3), dayIndexs(4), dayIndexs(5), dayIndexs(6), dayIndexs(7), dayIndexs(8), date, dimension, ak, dayIndexs(0), dayIndexs(1), dayIndexs(2), dayIndexs(3), dayIndexs(4), dayIndexs(5), dayIndexs(6), dayIndexs(7), dayIndexs(8))
          DbUtils.executeSql(conn, insertSqlDay, paramArray)
        })
      } catch {
        case e: Exception => logger.error(">>>分钟指标入库异常：" + e)
      } finally {
        conn.close()
      }

    })

  }

  def parseMessageObject(line: String): (String, String, String, String, JSONObject, JSONArray) = {
    val jObj = JSON.parseObject(line.trim)
    var createTime = jObj.getString("createTime")
    if (createTime != null) {
      createTime = createTime.replace(".", " ")
    }
    val ip = jObj.getString("ip")
    val message = JSON.parseObject(jObj.getString("message").trim)
    val chkDisLogType = message.getString("chkDisLogType").trim
    var chkDisLogObj: JSONObject = null
    var chkDisLogArray: JSONArray = null
    var chkDisLogMsg: String = null
    if (message.containsKey("chkDisLogArray")) {
      val tmpArray = message.getJSONArray("chkDisLogArray")
      if (tmpArray != null && tmpArray.size() != 0) {
        chkDisLogArray = new JSONArray()
        for (i <- 0 until tmpArray.size()) {
          chkDisLogArray.add(JSON.parseObject(tmpArray.getString(i).trim))
        }
      }
    } else if (message.containsKey("chkDisLogMsg")) {
      chkDisLogMsg = message.getString("chkDisLogMsg").trim
    } else {
      chkDisLogObj = message
    }
    (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray)
  }

  def parseLog(sc: SparkContext, logRdd: RDD[String], today: String): RDD[JSONObject] = {
    var validLog = getValidRdd(sc: SparkContext, logRdd, today)
    val reqLog = validLog.filter(
      line => {
        line.contains("=>receive oms waybill message :")
      }
    ).map(line => {
      val json = new JSONObject()
      val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
      val reqId = StringUtils.pickGroup1Str(chkDisLogType, "^(.*?)=>receive oms waybill message :").replace("info ", "").trim
      json.put("reqTime", createTime)
      //			val datetime = getTime(line)
      //			val reqId = StringUtil.pickGroup1Str(line, "--start-- (.*?)=>receive oms waybill message :")
      //			json.put("reqTime",datetime)
      (reqId, json)
    })
    val gisLog = validLog.filter(
      line => {
        line.contains("=>teamToResult:")
      }
    ).map(line => {
      val json = new JSONObject()
      val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
      val reqId = StringUtils.pickGroup1Str(chkDisLogType, "^(.*?)=>teamToResult:").replace("info ", "").trim
      json.put("gisTime", createTime)
      //			val datetime = getTime(line)
      //			var reqId = StringUtil.pickGroup1Str(line, "--start-- (.*?)=>teamToResult:")
      //			json.put("gisTime",datetime)
      (reqId, json)
    })
    val statLog = reqLog.union(gisLog).repartition(320).reduceByKey((o1, o2) => {
      o1.fluentPutAll(o2)
      o1
    }).map(_._2).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>聚合后日志量：" + statLog.count())
    validLog.unpersist()
    statLog
  }


  def getTime(line: String): String = {
    val datetime = StringUtils.pickGroup1Str(line, "\\[(\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s\\d{3})\\]")
    datetime
  }

  /**
   * 时间字符串转换成毫秒值
   * 样例：2018-10-24 09:54:47 236 ==> 1540346087236
   *
   * @param time
   * @return
   */
  def timeToLong(time: String): Long = {
    val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS")
    val longTime = sdf.parse(time).getTime
    longTime
  }

  /**
   * 获取有效的日志
   *
   * @param logRdd
   * @return
   */
  def getValidRdd(sc: SparkContext, logRdd: RDD[String], date: String): RDD[String] = {
    logger.error(">>>拉取窗口日志量：" + logRdd.count())
    val validRdd: RDD[String] = logRdd.filter(line => {
      var flag = false
      val isDate = line.contains(date)
      val a = line.indexOf("=>receive oms waybill message :") > -1 //用户请求
      val b = line.indexOf("=>teamToResult:") > -1
      isDate && (a || b)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>有效日志量：" + validRdd.count())
    validRdd
  }

  /**
   * 判断teamToResult是否是oms的数据
   *
   * @param line
   * @return
   */
  def isOmsTeamToResult(line: String): Boolean = {
    val reqId = StringUtils.pickGroup1Str(line, "--start-- (.*?)=>teamToResult:")
    val isOms = reqId.indexOf("_OMS_") > -1 //oms的数据
    isOms
  }


  /**
   * 获得有效的日志
   *
   * @param logRdd
   * @param incDay
   * @return
   */
  def getValidLog(logRdd: RDD[String], incDay: String): RDD[JSONObject] = {
    val validRdd: RDD[JSONObject] = logRdd.filter(line => {
      line.contains("log#{\"dateTime\":\"" + incDay)
    }).map(line => {
      var json: JSONObject = null
      try {
        json = JSON.parseObject(line.substring(line.indexOf("{")))
      } catch {
        case e: Exception => {
          logger.error(">>>日志格式不正确：" + e + "," + line)
        }
      }
      json

    }).filter(_ != null)
    validRdd
  }

  def getConf(appName: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
      .set("spark.port.maxRetries", "100")
      .set("spark.driver.maxResultSize", "12g")
      .set("spark.rpc.io.backLog", "10000")
      .set("spark.cleaner.referenceTracking.blocking", "false")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.driver.allowMultipleContexts", "true")
      .set("spark.sql.tungsten.enabled", "false")
      .set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
      .set("quota.consumer.default", (10485760 * 2).toString)
      .set("cache.max.bytes.buffering", (20485760 * 2).toString)
    conf
  }


}
