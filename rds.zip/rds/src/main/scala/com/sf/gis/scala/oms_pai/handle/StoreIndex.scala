package com.sf.gis.scala.oms_pai.handle


import java.sql.Connection

import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.oms_pai.obj.Case.{ReDataDayFinal, ReqDataDayFinal, ReqDataMin}
import com.sf.gis.scala.oms_pai.start.JavaUtil
import com.sf.gis.scala.utils.DbUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01375125 on 2018/10/8.
 * 指标入库
 */
object StoreIndex {
  @transient lazy val logger = Logger.getLogger(this.getClass.getName)

  /**
   *
   * @param statIndex
   */
  def storeIndex(statIndex: (RDD[ReqDataMin], RDD[ReqDataDayFinal], RDD[ReDataDayFinal]),
                 date: String, conn: Connection): Unit = {


    //    println(">>>建表……")
    //    createTable(conn)


    val reqIndexRddMin = statIndex._1
    logger.error(">>>按分钟请求指标详细入库...")
    storeReqIndexDetail(conn, reqIndexRddMin, "REQ_DETAIL", date)

    val reqIndexRddDay = statIndex._2
    logger.error(">>>按天统计请求指标及新增ak入库...")
    storeReqIndexDay(conn, reqIndexRddDay,"REQ_STAT" , date)

    logger.error(">>>按天统计返回指标入库...")
    val reStatIndex = statIndex._3
    storeReIndexDay(conn, reStatIndex, "RESP_STAT", date)


    conn.close()
    logger.error(">>>指标入库结束...")

  }


  /**
   * 按分钟统计详细请求指标入库
   *
   * @param conn
   * @param reqIndexRddMin
   * @param tableName
   */
  def storeReqIndexDetail(conn: Connection, reqIndexRddMin: RDD[ReqDataMin],
                          tableName: String, stat_date: String): Unit = {
    val deleteSql = s"DELETE FROM $tableName WHERE STAT_DATE='$stat_date'"

    DbUtils.executeSql(conn, deleteSql, null)
    val paramList = new ArrayBuffer[Array[String]]
    var paramArr: Array[String] = null
    val sql = "insert into " + tableName + "(id,stat_datetime,ak,req_count,resp_time,resp_time_99,stat_date)  values (?,?,?,?,?,?,?)"
    reqIndexRddMin.take(3).foreach(o => println(o))
    reqIndexRddMin.collect().foreach(obj => {
      val date = obj.date.replaceAll("-", "")
      val datetime = obj.datetime
      var ak = obj.ak
      if (ak == null) ak = "-"
      val req_cnt = obj.req_cnt.toString
      val avgRespTime = obj.avgRespTime.toString
      val p99RespTime = obj.p99RespTime.toString
      val id = MD5Util.getMD5(datetime + ak)

      paramArr = Array(id, datetime, ak, req_cnt, avgRespTime, p99RespTime, date)
      DbUtils.executeSql(conn, sql, paramArr)
      //      paramList += paramArr
      //      null
    })

    //    Util.batchExecute(conn,sql,paramList)
  }

  /**
   * 按天统计请求指标入库
   *
   * @param conn
   * @param reqIndexRddDay
   * @param tableName
   */
  def storeReqIndexDay(conn: Connection, reqIndexRddDay: RDD[ReqDataDayFinal],
                       tableName: String, stat_date: String): Unit = {


    logger.error(">>>请求ak入库...")


    val akList = new ArrayBuffer[Array[String]]
    var akArr: Array[String] = null
    val akSql = "insert into AK (id,ak,project)  values (?,?,?) on duplicate key update id =?"

    reqIndexRddDay.map(obj => {
      val ak = obj.ak
      (ak, 1)
    }).reduceByKey((o1, o2) => {
      o1 + o2
    }).map(_._1).collect().map(obj => {
      val ak = obj
      val project = "RGEO"
      val id = MD5Util.getMD5(ak + project)
      if (ak != "ALL" && ak != "-") {
        akArr = Array(id, ak, project, id)
        akList += akArr
        DbUtils.executeSql(conn, akSql, akArr) //更新ak
      }
      (id, ak)
    }).foreach(o => {
      println("ak:" + o._2)
    })
    val deleteSql = s"DELETE FROM $tableName WHERE STAT_DATE='$stat_date'"

    DbUtils.executeSql(conn, deleteSql, null)
    val paramList = new ArrayBuffer[Array[String]]
    var paramArr: Array[String] = null
    val sql = "insert into " + tableName + "(id,stat_date,ak,req_max,req_avg,req_min,resp_time_max,resp_time_avg,resp_time_min,resp_time_99max,resp_time_99avg,resp_time_99min)  values (?,?,?,?,?,?,?,?,?,?,?,?)"
    reqIndexRddDay.take(3).foreach(o => print(o))
    reqIndexRddDay.collect().foreach(obj => {
      val stat_date = obj.date.replaceAll("-", "")
      var ak = obj.ak
      if (ak == null) ak = "-"
      val req_max = obj.req_cnt_max.toString
      val req_avg = obj.req_cnt_avg.toString
      val req_min = obj.req_cnt_min.toString
      val resp_time_max = obj.maxRespTime.toString
      val resp_time_avg = obj.avgRespTime.toString
      val resp_time_min = obj.minRespTime.toString
      val resp_time_99max = obj.p99RespTimeMax.toString
      val resp_time_99avg = obj.p99RespTimeAvg.toString
      val resp_time_99min = obj.p99RespTimeMin.toString

      val id = MD5Util.getMD5(stat_date + ak)
      paramArr = Array(id, stat_date, ak, req_max, req_avg, req_min, resp_time_max, resp_time_avg, resp_time_min, resp_time_99max, resp_time_99avg, resp_time_99min)
      DbUtils.executeSql(conn, sql, paramArr)
      //      paramList += paramArr
      //      null
    })

    //  Util.batchExecute(conn,sql,paramList)
  }

  /**
   * 按天统计返回指标入库
   *
   * @param conn
   * @param reqIndexRddDay
   * @param tableName
   */
  def storeReIndexDay(conn: Connection, reqIndexRddDay: RDD[ReDataDayFinal], tableName: String, stat_date: String): Unit = {
    val paramList = new ArrayBuffer[Array[String]]
    var paramArr: Array[String] = null
    val deleteSql = s"DELETE FROM $tableName WHERE STAT_DATE='$stat_date'"

    DbUtils.executeSql(conn, deleteSql, null)
    val sql = "insert into " + tableName + " (id,stat_date,ak,resp_status,status_detail,client_req_total,client_req_count,trans_req_total,trans_req_count)  values (?,?,?,?,?,?,?,?,?)"
    reqIndexRddDay.take(1).foreach(o => print(o))
    reqIndexRddDay.collect().foreach(obj => {
      val stat_date = obj.date.replaceAll("-", "")
      var ak = obj.ak
      if (ak == null || ak == "null") ak = "-"
      val resp_status = obj.resp_status.toString
      val status_detail = obj.status_detail.toString
      val client_req_total = obj.req_cnt_sum.toString
      val client_req_count = obj.req_cnt.toString
      val trans_req_total = obj.trans_cnt_sum.toString
      val trans_req_count = obj.trans_cnt.toString

      val id = MD5Util.getMD5(stat_date + ak + resp_status + status_detail)
      paramArr = Array(id, stat_date, ak, resp_status, status_detail, client_req_total, client_req_count, trans_req_total, trans_req_count)
      DbUtils.executeSql(conn, sql, paramArr)
      //      paramList += paramArr
      //      null
    })

    //    paramList.foreach(o=>{println(o.mkString(","))})
    //    Util.batchExecute(conn,sql,paramList)


  }

  /**
   * 创建表
   *
   * @param conn
   */
  def createTable(conn: Connection): Unit = {

    val rgeo_ak_sql =
      s"""
         |CREATE TABLE IF NOT EXISTS `AK` (
         |  `ID` varchar(50) NOT NULL COMMENT '主键（AK+PROJECT的MD5值）',
         |  `AK` varchar(50) NOT NULL COMMENT 'AK值',
         |  `PROJECT` varchar(5) NOT NULL COMMENT '当前AK所属的项目名称（RDS/GEO/RGEO/QB/IPS/PNS/ARS/BN）',
         |  `CREATE_TIME` timestamp NULL DEFAULT current_timestamp(),
         |  `CREATE_USER` varchar(50) DEFAULT NULL,
         |  `MODIFY_TIME` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
         |  `MODIFY_USER` varchar(50) DEFAULT NULL,
         |  PRIMARY KEY (`ID`),
         |  UNIQUE KEY `AK_PROJECT` (`PROJECT`,`AK`)
         |) ENGINE=InnoDB DEFAULT CHARSET=utf8;
       """.stripMargin

    val req_detail_sql =
      s"""
         |CREATE TABLE IF NOT EXISTS `req_detail` (
         |  `ID` varchar(50) NOT NULL COMMENT '主键（STAT_DATETIME+AK的MD5值）',
         |  `STAT_DATETIME` varchar(20) NOT NULL COMMENT '统计时间（到分钟，格式为yyyyMMddHHmm）',
         |  `AK` varchar(50) NOT NULL COMMENT 'AK',
         |  `REQ_COUNT` int(11) DEFAULT NULL COMMENT '当前维度下每分钟请求量',
         |  `REQ_CAL_COUNT` int(11) DEFAULT NULL COMMENT '当前维度下每分钟计算量',
         |  `RESP_TIME` int(11) DEFAULT NULL COMMENT '当前维度下每分钟平均响应时间（ms）',
         |  `RESP_TIME_99` int(11) DEFAULT NULL COMMENT '当前维度下每分钟99%响应时间（ms）',
         |  `STAT_DATE` varchar(50) NOT NULL COMMENT '统计日期（yyyyMMdd）',
         |  `CREATE_TIME` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
         |  `CREATE_USER` varchar(50) DEFAULT NULL,
         |  `MODIFY_TIME` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         |  `MODIFY_USER` varchar(50) DEFAULT NULL,
         |  PRIMARY KEY (`ID`),
         |  KEY `STAT_DATE_AK` (`STAT_DATE`,`AK`)
         |) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='请求量统计明细（每分钟）';
       """.stripMargin

    val req_stat_sql =
      s"""
         |CREATE TABLE IF NOT EXISTS `req_stat` (
         |  `ID` varchar(50) NOT NULL COMMENT '主键（STAT_DATE+AK的MD5值）',
         |  `STAT_DATE` varchar(8) NOT NULL COMMENT '主键（yyyyMMdd）',
         |  `AK` varchar(50) NOT NULL COMMENT 'ak',
         |  `REQ_MAX` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟最大请求量',
         |  `REQ_AVG` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟平均请求量',
         |  `REQ_MIN` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟最小请求量',
         |  `RESP_TIME_MAX` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟最大响应时间',
         |  `RESP_TIME_AVG` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟平均响应时间',
         |  `RESP_TIME_MIN` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟最小响应时间',
         |  `RESP_TIME_99MAX` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟99%最大响应时间',
         |  `RESP_TIME_99AVG` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟99%平均响应时间',
         |  `RESP_TIME_99MIN` int(11) DEFAULT NULL COMMENT '当前维度下当天每分钟99%最小响应时间',
         |  `CREATE_TIME` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
         |  `CREATE_USER` varchar(50) DEFAULT NULL,
         |  `MODIFY_TIME` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         |  `MODIFY_USER` varchar(50) DEFAULT NULL,
         |  PRIMARY KEY (`ID`),
         |  KEY `STAT_DATE_AK` (`STAT_DATE`,`AK`)
         |) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='请求量统计（每分钟最大最小平均值）';
       """.stripMargin

    val resp_stat_sql =
      s"""
         |CREATE TABLE IF NOT EXISTS `resp_stat` (
         |  `ID` varchar(50) NOT NULL COMMENT '主键（STAT_DATE+AK+RESP_STATUS+STATUS_DETAIL的MD5值）',
         |  `STAT_DATE` varchar(8) NOT NULL COMMENT '统计日期（yyyyMMdd）',
         |  `AK` varchar(50) NOT NULL COMMENT '业务部门ak',
         |  `RESP_STATUS` varchar(1) NOT NULL COMMENT '响应状态（0：成功；1：失败；-：无响应）',
         |  `STATUS_DETAIL` varchar(50) NOT NULL COMMENT '当响应状态为0时，存储的是响应来源；当响应状态为1时，存储的是错误类型；当响应状态为无响应时，默认为“-”',
         |  `CLIENT_REQ_TOTAL` int(11) DEFAULT '0' COMMENT '用户请求总量',
         |  `CLIENT_REQ_COUNT` int(11) DEFAULT '0' COMMENT '当前统计维度下的用户请求量',
         |  `TRANS_REQ_TOTAL` int(11) DEFAULT '0' COMMENT '转发请求总量',
         |  `TRANS_REQ_COUNT` int(11) DEFAULT '0' COMMENT '当前统计维度下的转发请求量',
         |  `CREATE_TIME` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
         |  `CREATE_USER` varchar(50) DEFAULT NULL,
         |  `MODIFY_TIME` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
         |  `MODIFY_USER` varchar(50) DEFAULT NULL,
         |  PRIMARY KEY (`ID`),
         |  KEY `STAT_DATE_RESP_STATUS_STATUS_DETAIL` (`STAT_DATE`,`RESP_STATUS`,`STATUS_DETAIL`)
         |) ENGINE=InnoDB DEFAULT CHARSET=utf8;
       """.stripMargin

    DbUtils.executeSql(conn, rgeo_ak_sql, null)
    DbUtils.executeSql(conn, req_detail_sql, null)
    DbUtils.executeSql(conn, req_stat_sql, null)
    DbUtils.executeSql(conn, resp_stat_sql, null)
  }


}
