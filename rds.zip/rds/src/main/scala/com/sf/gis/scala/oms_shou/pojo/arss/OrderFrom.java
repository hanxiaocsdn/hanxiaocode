package com.sf.gis.scala.oms_shou.pojo.arss;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/8.
 */
public class OrderFrom  implements Serializable {
    private String cityCode;
    private String province;
    private String city;
    private String address;
    private String county;
    private String teamCode;
    private String deptCode;
    private String aoiCode;
    private String aoiId;
    private String aoiInfo;
    private String entityAoiCode;
    private String entityAoiId;

    public String getEntityAoiCode() {
        return entityAoiCode;
    }

    public void setEntityAoiCode(String entityAoiCode) {
        this.entityAoiCode = entityAoiCode;
    }

    public String getEntityAoiId() {
        return entityAoiId;
    }

    public void setEntityAoiId(String entityAoiId) {
        this.entityAoiId = entityAoiId;
    }

    public String getAoiInfo() {
        return aoiInfo;
    }

    public void setAoiInfo(String aoiInfo) {
        this.aoiInfo = aoiInfo;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }
}
