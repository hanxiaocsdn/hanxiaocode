package com.sf.gis.scala.rds.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.{DateUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.rds.util.{HttpConnection, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.Random


/**
 * 车油补V1.8：对比巴枪和车载设备采集轨迹
 * 需求方：01430258
 * 开发方：01417629
 * 任务信息：929779
 */
//noinspection DuplicatedCode
object OilCostByDeptFourWheeledVehiclesGPS {
  @transient lazy val logger: Logger = Logger.getLogger(OilCostByDeptFourWheeledVehiclesGPS.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //val url = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/trackquery/api/queryDetail"
  val url = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/queryDetail"
  val limitMin = 2000 / 10

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val parDay_1 = args(0) //20230901
    val parDay_2 = args(1) //20231031
    run(spark, parDay_1, parDay_2)
    spark.close()
  }


  def run(spark: SparkSession, parDay_1: String, parDay_2: String): Unit = {
    //生成日期列表
    val dateList = DateUtil.getDateList(parDay_1,parDay_2,"yyyyMMdd")
    val iter = dateList.iterator()
    while (iter.hasNext){
      val date = iter.next()
      logger.error("date: "+date)
      //读取数据源
      val ret = getCheckRet(spark,date)
      //ret.take(1).foreach(println(_))
      //根据车牌号及时间点获取停留时间段信息
      val res = getPathFix(ret,date)
      //res.take(1).foreach(println(_))
      ret.unpersist()
      //入库
      saveResult_1(spark, res, date)
      res.unpersist()
    }
  }

  def getCheckRet(spark: SparkSession,date : String): RDD[JSONObject] = {
    val sql =
      s"""
         |select
         |	area
         |	,dept_code
         |	,emp_code
         |	,car_code
         |	,type
         |from
         |(
         |	select
         |		area
         |		,dept_code
         |		,emp_code
         |		,car_code
         |		,type
         |		,row_number() over(distribute by car_code sort by flag desc) as rn
         |	from
         |	(
         |		select
         |			b.*
         |		from
         |		(
         |			select
         |				vehicle_code
         |			from dim.dim_vms_vehicle_info_df
         |			where inc_day = '$date'
         |			and vehicle_state = '1'
         |			and hire_vehicle = '0'
         |			and fuel_type in ('1','2','3','4','5','6')
         |		) as a
         |
         |		left join
         |
         |		(
         |			select
         |				'' as area
         |				,tplnr as dept_code
         |				,z_tx_015 as emp_code
         |				,chpai as car_code
         |				,'产权车' as type
         |				,0 as flag
         |			from ods_sap_pm.ztpm_ds_dsj
         |			where inc_day = '$date'
         |		) as b
         |
         |		on a.vehicle_code = b.car_code
         |
         |		union
         |
         |		select
         |			area_code as area
         |			,dept_code
         |			,responsible_no as emp_code
         |			,var1 as car_code
         |			,'租赁车' as type
         |			,1 as flag
         |		from
         |		ods_rental.ods_rental_t_rental_main
         |		where inc_day = '$date'
         |		and device_desc = 'four_whee'
         |		and asset_status in ('in_use', 'renewing', 'renew')
         |	) as t1
         |) as t2
         |where rn = 1
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: " + sql)
    val ret = Util.getRowToJsonNew(spark, sql)
    logger.error(s">>>按条件取数据 ${ret.count()} 条s<<<")
    ret
  }

  def getPathFix(ret: RDD[JSONObject],date : String): RDD[JSONObject] = {
    val res = ret.mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val car_code = JSONUtil.getJsonVal(o, "car_code", "")
        val beginDateTime = date + "000000"
        val endDateTime = date + "235959"
        val jsonObject = new JSONObject()
        jsonObject.put("addpoint", 1)
        //jsonObject.put("ak", "b61f6c427934416dbc3248dbefef5eb0")
        jsonObject.put("ak", "90ee1de9f65b416a94f92bf97cab6215")
        jsonObject.put("type", "400")
        jsonObject.put("compensate", true)
        jsonObject.put("un", car_code)
        jsonObject.put("unType", "0")
        jsonObject.put("compensate", 1)
        jsonObject.put("beginDateTime", beginDateTime)
        jsonObject.put("endDateTime", endDateTime)
        val toJSONString = jsonObject.toString
        val content: String = HttpInvokeUtil.sendPost(url, toJSONString, FixedConstant.MAX_TRY_TIME_ONCE)
        o.put("content", content)
        if (content.nonEmpty) {
          val json = JSONUtil.parseStr2Json(content)
          if (json != null) {
            val status = json.getInteger("status")
            if(status == 0){
              val result = json.getJSONObject("result")
              if(result != null){
                val data = result.getJSONObject("data")
                val tracks = data.getJSONArray("track")
                if (tracks != null && tracks.size() > 0) {
                  o.put("path_end_time", tracks.getJSONObject(tracks.size() - 1).getLong("tm"))
                  o.put("distance_track", tracks.getJSONObject(tracks.size() - 1).getLong("sumDist"))
                  o.put("path_start_time", tracks.getJSONObject(0).getLong("tm"))
                }
              }
            }
          }
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>res ${res.count()} 条s<<<")
    res
  }

  def saveResult_1(spark: SparkSession, res1: RDD[JSONObject], date: String) = {
    val inc_month = date.substring(0,6)
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "oil_cost_by_dept_four_wheeled_vehicles_gps"
    //插入中间表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION (inc_day = '$date')
         |select
         |	'$date' as date_time
         |	,t1.area
         |  ,t1.dept_code
         |  ,t1.emp_code
         |  ,t1.car_code
         |  ,t1.path_start_time
         |  ,t1.path_end_time
         |  ,t1.distance_track
         |	,t2.disall
         |	,t2.distance_in_dept
         |	,t2.distance_in_waybill_in_dept
         |  ,type
         |  ,hq_code
         |from
         |(
         |	select
         |		area,dept_code,emp_code,car_code,path_start_time,path_end_time,(distance_track / 1000) as distance_track,type
         |	from
         |	tmp
         |) as t1
         |
         |left join
         |
         |(
         |	--select emp_code,disall,distance_in_dept,distance_in_waybill_in_dept from dm_gis.xiaoge_path_distance where inc_day = '$date'
         |	select emp_code,disall,distance_in_dept,distance_in_waybill_in_dept from dm_gis.xiaoge_path_distance_new where inc_day = '$date'
         |) as t2
         |
         |on regexp_replace(t1.emp_code, '^(0+)', '') = t2.emp_code
         |
         |left join
         |
         |(
         |  select
         |    hq_code,emp_code
         |  from dm_terminal.dw_frontline_staff_using_dtl_new_month
         |  where inc_month = '$inc_month'
         |  and hq_code in ('CN01', 'CN02', 'CN03', 'CN08')
         |) as t3
         |
         |on t1.emp_code = t3.emp_code
         |""".stripMargin
    val schemaString = "area,dept_code,emp_code,car_code,path_start_time,path_end_time,distance_track,type"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true))
    val schema = StructType(fields)
    val rdd = res1.repartition(10).map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getOrDefault("area", "")).append("\t\t\t")
      sb.append(obj.getOrDefault("dept_code", "")).append("\t\t\t")
      sb.append(obj.getOrDefault("emp_code", "")).append("\t\t\t")
      sb.append(obj.getOrDefault("car_code", "")).append("\t\t\t")
      sb.append(obj.getOrDefault("path_start_time", "")).append("\t\t\t")
      sb.append(obj.getOrDefault("path_end_time", "")).append("\t\t\t")
      sb.append(obj.getOrDefault("distance_track", "")).append("\t\t\t")
      sb.append(obj.getOrDefault("type", "")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4)
      , attr(5), attr(6), attr(7)))
    val df = spark.createDataFrame(rdd, schema)
    df.printSchema()
    df.createOrReplaceTempView("tmp")
    df.show(5)
    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: " + insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }
}
