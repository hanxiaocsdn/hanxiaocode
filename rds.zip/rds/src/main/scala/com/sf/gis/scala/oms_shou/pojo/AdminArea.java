package com.sf.gis.scala.oms_shou.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/5.
 */
@Entity
public class AdminArea implements Serializable{
    @Column(name = "ID")
    private String id;
    @Column(name = "PROVINCE")
    private String province;
    @Column(name = "REGION")
    private String region;
    @Column(name = "CITY")
    private String city;
    @Column(name = "CITYCODE")
    private String cityCode;
    @Column(name = "ADCODE")
    private String adcode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }
}
