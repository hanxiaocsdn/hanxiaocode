package com.sf.gis.scala.rds.app

import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.HttpConnection
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.rds.util.{MD5Util, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * KS11-基于地址的AOI识别,运单宽表预计算
 * Created by 01417629 on 2021-11-11
 */
//noinspection DuplicatedCode
object AOIOnAddrIdentificationPreAmount {
  @transient lazy val logger: Logger = Logger.getLogger(AOIOnAddrIdentificationPreAmount.getClass)

  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val url = "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/saveMax80Aoi?"
  //val url = "http://10.240.16.118:8080/rdsks/api/saveMax80Aoi?"

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val parDay_1 = args(0)
    val parDay_2 = args(1)
    val parDay_3 = args(2)

    run(spark, parDay_1, parDay_2, parDay_3)
    spark.close()
  }

  def run(spark: SparkSession, parDay_1: String, parDay_2: String, parDay_3: String): Unit = {
    println(parDay_1 + "-->" + parDay_2 + "-->" + parDay_3)

    //统计指标预计算
    val max_80_aoi = getWaybillInfoPreCal(spark, parDay_1, parDay_2)

    //统计指标写入Hive
    saveCalResult2Hive(spark, max_80_aoi, parDay_3)

    //存入Redis，返回未写入成功的数据
    val errorList = saveResult2Redis(max_80_aoi)

    //存入Redis，返回未写入成功的数据
    if (errorList.count() > 0) {
      saveErrorList2Hive(spark, errorList, parDay_3)
    }

  }


  /**
   * 统计指标预计算
   *
   * @param spark
   * @param parDay_1
   * @param parDay_2
   */
  def getWaybillInfoPreCal(spark: SparkSession, parDay_1: String, parDay_2: String): RDD[JSONObject] = {
    val calSql =
      s"""
         |SELECT
         |	 t1.citycode                  AS citycode
         |	,t1.address                   AS consignee_addr
         |	,t1.delivery_xy_dept          AS Max_80_zncode
         |	,t1.delivery_xy_aoiid         AS Max_80_aoiid
         |	,t1.inc_day                   AS aoiid_up_to_date
         |	,t1.delivery_xy_aoiid_num     AS Max_80_aoiid_numb
         |	,t1.Max_80_aoiid_freq         AS Max_80_aoiid_freq
         |FROM
         |(
         |	SELECT
         |		 tt1.citycode
         |		,tt1.address
         |		,tt1.delivery_xy_dept
         |		,tt1.delivery_xy_aoiid
         |		,tt1.inc_day
         |		,tt1.delivery_xy_aoiid_num
         |		,tt1.delivery_xy_aoiid_num/tt1.addr_num AS Max_80_aoiid_freq
         |		,row_number() over(partition by tt1.citycode,tt1.address order by tt1.delivery_xy_aoiid_num,tt1.inc_day desc) AS rn
         |	FROM
         |	(
         |		SELECT
         |			 citycode
         |			,address
         |			,delivery_xy_dept
         |			,delivery_xy_aoiid
         |			,inc_day
         |			,count(*) over(distribute by citycode,address) AS addr_num
         |			,count(*) over(distribute by citycode,address,delivery_xy_dept,delivery_xy_aoiid) AS delivery_xy_aoiid_num
         |		FROM
         |		dm_gis.tt_waybill_add_standard_addr
         |		WHERE inc_day BETWEEN '$parDay_1' AND '$parDay_2'
         |	) tt1
         |) t1
         |WHERE t1.rn = 1 AND t1.Max_80_aoiid_freq > 0.5
         |AND (t1.citycode <> '' AND t1.citycode <> 'null' AND t1.citycode is not null
         |AND t1.delivery_xy_aoiid <> '' AND t1.delivery_xy_aoiid <> 'null' AND t1.delivery_xy_aoiid is not null)
         |GROUP BY
         |	 t1.citycode
         |	,t1.address
         |	,t1.delivery_xy_dept
         |	,t1.delivery_xy_aoiid
         |	,t1.inc_day
         |	,t1.delivery_xy_aoiid_num
         |	,t1.Max_80_aoiid_freq
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>指标计算sql: " + calSql)

    val max_80_aoi = Util.getRowToJson(spark, calSql, 100)

    logger.error(s">>>获取max_80_aoi共 ${max_80_aoi.count()} 条s<<<")

    max_80_aoi

  }


  def saveCalResult2Hive(spark: SparkSession, max_80_aoi: RDD[JSONObject], parDay_3: String): Unit = {
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "tt_waybill_add_standard_addr_cal"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION (inc_day = '$parDay_3')
         |SELECT
         |  *
         |FROM tt_waybill_hook_cal_temp
         |""".stripMargin

    try {
      val schemaString = "citycode,consignee_addr,Max_80_zncode,Max_80_aoiid,Max_80_aoiid_numb,Max_80_aoiid_freq,aoiid_up_to_date"

      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true))
      val schema = StructType(fields)

      val rdd = max_80_aoi.map(obj => {

        val consignee_addr = obj.getString("consignee_addr")
        var sub_addr = ""
        if (consignee_addr != null && consignee_addr.length > 0) {
          sub_addr = consignee_addr.substring(1, consignee_addr.length - 1)

        }

        val sb = new StringBuilder()
        sb.append(obj.getString("citycode")).append("\t\t\t")
        sb.append(sub_addr).append("\t\t\t")
        sb.append(obj.getString("Max_80_zncode")).append("\t\t\t")
        sb.append(obj.getString("Max_80_aoiid")).append("\t\t\t")
        sb.append(obj.getString("Max_80_aoiid_numb")).append("\t\t\t")
        sb.append(obj.getString("Max_80_aoiid_freq")).append("\t\t\t")
        sb.append(obj.getString("aoiid_up_to_date")).append("\t\t\t")

        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4), attr(5), attr(6)))

      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.createOrReplaceTempView("tt_waybill_hook_cal_temp")
      df.show(5)

      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      val resultDF = spark.sql(insertSQL)
      resultDF.show(5)
      logger.error(">>>>>>>>>>入hive库结束")

      spark.sql("drop table if exists tt_waybill_hook_cal_temp")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>删除临时表: tt_waybill_hook_cal_temp")

    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  /**
   *
   * @param max_80_aoi
   */
  def saveResult2Redis(max_80_aoi: RDD[JSONObject]): RDD[AnyRef] = {
    logger.error(">>>>>>>>>开始插入数据库<<<<<<<<<<")
    val res = max_80_aoi.repartition(50).mapPartitions(iter => {
      var addrList = new JSONArray()
      var param = new JSONObject()
      val errorList = new JSONArray()
      val md5Instance = MD5Util.getMD5Instance

      while (iter.hasNext) {
        val jsonObject = new JSONObject()
        val obj = iter.next()
        val consignee_addr = JSONUtil.getJsonVal(obj, "consignee_addr", "")
        var sub_addr = ""
        if (consignee_addr != null && consignee_addr.length > 0) {
          sub_addr = consignee_addr.substring(1, consignee_addr.length - 1)
        }
        val addrMd5 = MD5Util.getMD5(md5Instance, sub_addr)

        jsonObject.put("addrMd5", addrMd5)
        jsonObject.put("citycode", JSONUtil.getJsonVal(obj, "citycode", ""))
        jsonObject.put("max80Znocode", JSONUtil.getJsonVal(obj, "Max_80_zncode", ""))
        jsonObject.put("max80AoiId", JSONUtil.getJsonVal(obj, "Max_80_aoiid", ""))
        jsonObject.put("max80AoiRatio", JSONUtil.getJsonVal(obj, "Max_80_aoiid_freq", ""))
        jsonObject.put("max80AoiFreq", JSONUtil.getJsonVal(obj, "Max_80_aoiid_numb", ""))
        jsonObject.put("lastWaybillDate", JSONUtil.getJsonVal(obj, "aoiid_up_to_date", ""))

        addrList.add(jsonObject)

        if (addrList.size() == 100 || iter.hasNext == false) {
          param.put("ak", "fe761b57a7494fb99eb9d3e555111174")
          //param.put("ak","0376a9aa84724dd2a995f858dd963346")
          param.put("addrList", addrList)
          val res = postSave2Redis(url, param.toJSONString)

          if (res != null && res.getString("errorList") != null) {
            errorList.add(res.getString("errorList"))
          }

          addrList = new JSONArray()
          param = new JSONObject()
        }
      }
      errorList.toArray.toIterator
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>>>>>>>入库失败数据量<<<<<<<<<<: " + res.count())
    logger.error(">>>>>>>>>redis入库结束<<<<<<<<<<")

    max_80_aoi.unpersist()
    res
  }


  /**
   *
   * @param url
   * @param params
   * @return
   */
  def postSave2Redis(url: String, params: String): JSONObject = {
    var ret: JSONObject = null
    try {
      if (!params.isEmpty) {
        val httpData = HttpConnection.sendPost(url, params)
        if (httpData != null && httpData.containsKey("content") && httpData.get("content") != null) {
          val content = httpData.get("content").toString
          val xyObj = JSON.parseObject(content)
          if (xyObj != null && xyObj.getJSONObject("result") != null) {
            if (xyObj.getJSONObject("result").getInteger("err") == 109) {
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep(60 - second)
              return postSave2Redis(url, params)
            }
            ret = new JSONObject()
            val result = xyObj.getJSONObject("result")
            if (result != null) {
              val errorList = result.getJSONArray("errorList")
              if (errorList != null && errorList.size() != 0) {
                ret.put("errorList", errorList.toJSONString)
              }
            }
          }
        } else {
          ret.put("code", httpData.get("code"))
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  def saveErrorList2Hive(spark: SparkSession, errorList: RDD[AnyRef], parDay_3: String): Unit = {
    //目标库表名称
    val descDBName = "default"
    val descTableName = "tt_waybill_add_standard_addr_redis_err"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION (inc_day = '$parDay_3')
         |SELECT
         |  errorMsg
         |FROM tt_waybill_hook_cal_err_temp
         |""".stripMargin

    try {
      val schemaString = "errorMsg,other"

      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true))
      val schema = StructType(fields)

      val rdd = errorList.map(attr => Row(attr.toString, "other"))

      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.createOrReplaceTempView("tt_waybill_hook_cal_err_temp")
      df.show(5)

      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      val resultDF = spark.sql(insertSQL)
      resultDF.show(5)
      logger.error(">>>>>>>>>>入hive库结束")

      spark.sql("drop table if exists tt_waybill_hook_cal_err_temp")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>删除临时表: tt_waybill_hook_cal_err_temp")

    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }


}
