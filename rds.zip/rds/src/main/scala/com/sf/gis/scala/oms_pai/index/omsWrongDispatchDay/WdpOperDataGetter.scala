package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

import java.util

import com.sf.gis.scala.oms_pai.db.{ManagerFactory, WdManager}
import com.sf.gis.scala.utils.DbUtils
import org.apache.log4j.Logger

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer


/**
  * Created by 01368078 on 2019/3/13.
  */
object WdpOperDataGetter {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  def main(args: Array[String]): Unit = {
    getWdpOperData("20180910", null)
  }
  def getWdpOperData(incDay : String, zno2DeptMap: Map[String, String]): Map[String,String] ={
    val conn = ManagerFactory.createManager(classOf[WdManager]).getConn
    //noinspection ScalaUnusedSymbol
    var regoinCityTable="ADMIN_AREA"
    val columns = Array("waybillNo","right_zc")
//    val regionSelectSql = s"select a.waybillNo,b.right_zc from " +
//      s"    (select waybillNo,unique_md5,address,DATE_FORMAT(create_time,'%Y%m%d') create_time1  from " +
//      s"      wrong_dispatch_data_origin_by_day where data_time = '$incDay') a " +
//      s"  join " +
//      s"    (select address address1,unique_id,right_zc,DATE_FORMAT(t.create_time,'%Y%m%d') create_time2 from  " +
//      s"      wdp_manu_oper t " +
//      s"    left JOIN " +
//      s"      wdp_manu_oper_history t2 " +
//      s"    ON t.task_id = t2.task_id_new " +
//      s"    where t.data_type=2  and t2.id is null) b " +
//      s"  on a.unique_md5= b.unique_id " +
//      s"  where  a.create_time1 between  b.create_time2  and b.create_time2+7"
    val regionSelectSql = s"select a.waybillNo,b.right_zc from " +
      s"    (select waybillNo,unique_md5,address,DATE_FORMAT(create_time,'%Y-%m-%d') create_time1  from " +
      s"      wrong_dispatch_data_origin_by_day where data_time = '$incDay') a " +
      s"  join " +
      s"    (select address address1,unique_id,right_zc,DATE_FORMAT(t.create_time,'%Y-%m-%d') create_time2 from  " +
      s"      wdp_manu_oper t " +
      s"    left JOIN " +
      s"      wdp_manu_oper_history t2 " +
      s"    ON t.task_id = t2.task_id_new " +
      s"    where t.data_type=2  and t2.id is null) b " +
      s"  on a.unique_md5= b.unique_id " +
      s"  where  a.create_time1 between  b.create_time2  and DATE_FORMAT(DATE_ADD(b.create_time2,INTERVAL 1 week),'%Y-%m-%d')"
    logger.error(">>>wdpOperSelectSql:"+regionSelectSql)
    val operDatas:ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn,regionSelectSql,columns)
    var wdpOperMap:Map[String,String] = Map()
    val keySet = new util.HashSet[String]()
    for(operData <- operDatas){
      val deptMap = if(zno2DeptMap.contains(operData(1))) zno2DeptMap.apply(operData(1)) else operData(1)
      if(wdpOperMap.contains(operData(0)) && deptMap != null && !deptMap.equals(wdpOperMap.apply(operData(0)))){
        //记录出现多次的运单，且网点不一样的数据，后面统一剔除
        keySet.add(operData(0))
      }else{
        wdpOperMap += (operData(0) -> deptMap)
      }
    }
    println(wdpOperMap.size)
    println(keySet.size())
    // 后面统一剔除出现多次的运单，且网点不一样的数据
    for(key <-  keySet){
      wdpOperMap -= key
    }
    println(wdpOperMap.size)
    wdpOperMap
  }
}
