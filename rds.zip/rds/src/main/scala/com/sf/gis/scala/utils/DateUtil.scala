package com.sf.gis.scala.utils

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

/**
  * Created by 01368078 on 2018/7/5.
  */
object DateUtil {
  def dateBefore(dateFormat : String, daysBefore : Int) : String = {
    val sdf = new SimpleDateFormat(dateFormat)
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, 0 - daysBefore)
    val date = sdf.format(cal.getTime)
    date
  }

  def dateBefore(dateFormat : String, daysBefore : Int, spDate : String) : String = {
    val sdf = new SimpleDateFormat(dateFormat)
    val cal = Calendar.getInstance()
    cal.setTime(sdf.parse(spDate))
    cal.add(Calendar.DATE, 0 - daysBefore)
    val date = sdf.format(cal.getTime)
    date
  }

  def getCurrentTime(dateFormat: String) : String = {
    val sdf = new SimpleDateFormat(dateFormat)
    val cal = Calendar.getInstance()
    val date = sdf.format(cal.getTime)
    date
  }

  def formatTimeStamp2Str(timeStamp : Long, format : String) : String = {
    val sdf = new SimpleDateFormat(format)
    sdf.format(new Date(timeStamp))
  }
  def formatStr2TimeStamp(str : String, format : String) : Long = {
    val sdf = new SimpleDateFormat(format)
    val date = sdf.parse(str)
    date.getTime
  }
  def timeToLong(time: String, format: String): Long = {
    val sf = new SimpleDateFormat(format)
    sf.parse(time).getTime
  }
  def main(args: Array[String]): Unit = {
    println(formatStr2TimeStamp("2019-11-08 18:10:57 766","yyyy-MM-dd HH:mm:ss SSS"))
  }
}
