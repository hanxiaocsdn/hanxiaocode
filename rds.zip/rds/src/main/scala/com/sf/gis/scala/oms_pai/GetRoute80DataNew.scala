package com.sf.gis.scala.oms_pai

import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import com.sf.gis.scala.oms_pai.db.AppConfig
import com.sf.gis.scala.oms_pai.handle.{ExcXiaogeNo, Zc2DcMap}
import com.sf.gis.scala.utils.HttpClientUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * 任务id：467468（运单带妥投数据带电话test）
 * 业务方：01369702（蓝媛青）
 * 研发：01399581（匡仁衡）
 * 时间：2023年9月15日11:16:50
 * 任务名称：运单带妥投数据带电话test
 * 描述：妥投运单，用于日志效果环境用的测试工单，修改逻辑，但未上线
 **/
object GetRoute80DataNew {
  def main(args: Array[String]): Unit = {
    val config = AppConfig.getInstance()
    val startDate = args(0)
    new GetRoute80DataNew(config, startDate).start()
  }
}

class GetRoute80DataNew(val appConfig: AppConfig, val startDate: String) extends Serializable {
  val config = appConfig
  @transient lazy val logger = Logger.getLogger(classOf[GetRoute80DataNew])
  val deptByXyUrl = "http://gis-apis.int.sfcloud.local:1080/dept/info/aoi/byxy2?x=%s&y=%s&ak=a4fbd3a08ecc4f9e41bc9b06421ef3b5"

  def start(): Unit = {
    var startTime = System.currentTimeMillis()
    val dbGis = config.getDbGis
    val tableGis = config.getTableGis
    val dbFvp = config.getDbFvp
    val tableFvp = config.getTableFvp
    val appName = "GetRoute80DataNew"
    logger.error(String.format(">>>dbGis: %s , tableGis: %s, dbFvp: %s , tableFvp: %s, appName: %s", dbGis, tableGis, dbFvp, tableFvp, appName))
    getData(dbGis, tableGis, dbFvp, tableFvp, appName, startDate)
    var endTime = System.currentTimeMillis()
    logger.error(String.format(">>>耗时: %sms", (endTime - startTime).toString))
  }

  def unionScanRdd(toAddrRdd: RDD[(String, JSONObject)], scanRdd: RDD[(String, JSONObject)], zc2DcMap: util.HashMap[String, String]): RDD[JSONObject] = {
    val rdd = toAddrRdd.leftOuterJoin(scanRdd, 1600).map(obj => {
      var addrObj = obj._2._1
      var scanInfo = obj._2._2
      if (scanInfo != None) {
        val empObj = scanInfo.get
        val bar_scan_lng = empObj.getString("bar_scan_lng")
        val bar_scan_lat = empObj.getString("bar_scan_lat")

        addrObj.put("bar_scan_lng", bar_scan_lng)
        addrObj.put("bar_scan_lat", bar_scan_lat)
        if (bar_scan_lng != null && !bar_scan_lng.isEmpty && bar_scan_lat != null && !bar_scan_lat.isEmpty) {
          try {
            val req = String.format(deptByXyUrl, bar_scan_lng, bar_scan_lat)
            val re = HttpClientUtil.getJsonByGet(req)
            //            val re = HttpInvokeUtil.sendGetNew(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
            if (re != null && re.getInteger("status") == 0) {
              val aoi_zc = re.getJSONObject("result").getJSONObject("data").getJSONObject("aoi").getString("aoi_zc")
              val aoi_dept = zc2DcMap.get(aoi_zc)
              addrObj.put("bar_scan_zonecode", aoi_zc)
              addrObj.put("bar_scan_deptcode", aoi_dept)
            }
          } catch {
            case e: Exception => logger.error(empObj.toJSONString, e)
          }
        }
      }
      //      (obj._1, addrObj)
      addrObj
    }).map(obj => {
      val zonecode = obj.getString("zonecode")
      val deptcode = obj.getString("deptcode")
      val xiaoge_zonecode = obj.getString("xiaoge_zonecode")
      val xiaoge_deptcode = obj.getString("xiaoge_deptcode")
      val bar_scan_zonecode = obj.getString("bar_scan_zonecode")
      val bar_scan_deptcode = obj.getString("bar_scan_deptcode")
      if (StringUtils.isEmpty(xiaoge_zonecode) || StringUtils.isEmpty(xiaoge_deptcode)) {
        if (StringUtils.isNotEmpty(bar_scan_zonecode) && !StringUtils.equals(zonecode, bar_scan_zonecode)) {
          obj.put("zonecode", "")
          obj.put("deptcode", "")
        }
      } else if (StringUtils.isNotEmpty(xiaoge_deptcode)) {
        if ((StringUtils.isNotEmpty(bar_scan_zonecode) && !(StringUtils.equals(zonecode, xiaoge_zonecode) && StringUtils.equals(xiaoge_zonecode, bar_scan_zonecode)))
          || (StringUtils.isEmpty(bar_scan_zonecode) && !StringUtils.equals(zonecode, xiaoge_zonecode))) {
          obj.put("zonecode", "")
          obj.put("deptcode", "")
        }
      }
      obj
    })
    rdd
  }

  def getData(dbGis: String, tableGis: String, dbFvp: String,
              tableFvp: String, appName: String, startDate: String): Unit = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    conf.set("spark.sql.result.partition.ratio", "0.7")
    conf.set("spark.executor.instances", "40")
    conf.set("spark.executor.memory", "25g")
    conf.set("spark.driver.memory", "15g")
    conf.set("spark.yarn.executor.memoryOverhead", "8g")
    conf.set("spark.executor.cores", "8")
    //    conf.set("spark.network.timeout","10000000")
    //    conf.set("spark.executor.heartbeatInterval","10000000")
    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")

    val sc = new SparkContext(conf)
    var spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    sc.setLogLevel("ERROR")
    //    var i = 6
    //    var n = 6
    //    var dateSet = new util.HashSet[String]()
    //    while(i <= n){
    var incDay = startDate
    //      if(!dateSet.contains(incDay)){
    //        dateSet.add(incDay)
    var date1 = DateUtil.getDateStr(incDay, 1)
    var date2 = DateUtil.getDateStr(incDay, 6)
    var date3 = DateUtil.getDateStr(incDay, 10)
    logger.error(incDay + ">>>" + date1 + ">>>" + date2 + ">>>" + date3)


    var startTime = 0L
    var endTime = 0L
    var spanTime = 0L

    logger.error(">>>获取营业站网点映射关系")
    startTime = System.currentTimeMillis()
    var zc2DcMap = Zc2DcMap.getValidZc2DcMap()
    var zc2DcCnt = zc2DcMap.keySet().size()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>营业站网点映射数据量 : $zc2DcCnt, 耗时 : $spanTime ms""")


    logger.error(s""">>>查询地址数据""")
    startTime = System.currentTimeMillis()
    var toAddrRdd = getToAddrRdd(spark, incDay).persist(StorageLevel.DISK_ONLY)
    var toAddrCnt = toAddrRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>地址数据量 : $toAddrCnt, 耗时 : $spanTime ms""")

    logger.error(">>>获取免除小哥工号")
    var excXiaogeNoSet = ExcXiaogeNo.getExcXiaogeNoNew()
    var excXiaogeNoCnt = excXiaogeNoSet.size()
    logger.error(s""">>>免除小哥数据量 : $excXiaogeNoCnt""")


    logger.error(s""">>>查询回单数据""")
    startTime = System.currentTimeMillis()
    var route80Rdd = getRoute80Rdd(spark, incDay, date2, excXiaogeNoSet).persist(StorageLevel.DISK_ONLY)
    var route80Cnt = route80Rdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>回单数据量 : $route80Cnt, 耗时 : $spanTime ms""")


    logger.error(s""">>>关联工单数据和妥投数据""")
    startTime = System.currentTimeMillis()
    var rdd1 = unionRoute80Data(toAddrRdd, route80Rdd, zc2DcMap).persist(StorageLevel.DISK_ONLY)
    var rddCnt1 = rdd1.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>关联后的数据量 : $rddCnt1, 耗时 : $spanTime ms""")
    toAddrRdd.unpersist()
    route80Rdd.unpersist()


    logger.error(s""">>>获取员工所属网点数据""")
    startTime = System.currentTimeMillis()
    var empInfoRdd = getEmpInfo(spark, incDay, date2).persist(StorageLevel.DISK_ONLY)
    var empInfoCnt = empInfoRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>员工所属网点数据 : $empInfoCnt, 耗时 : $spanTime ms""")

    logger.error(s""">>>关联工单数据和小哥数据""")
    startTime = System.currentTimeMillis()
    var xiaogeRdd = unionEmpInfoData(rdd1, empInfoRdd, zc2DcMap).repartition(320).persist(StorageLevel.DISK_ONLY)
    var xiaogeRddCnt = xiaogeRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>关联后的数据量 : $xiaogeRddCnt, 耗时 : $spanTime ms""")
    rdd1.unpersist()
    empInfoRdd.unpersist()


    logger.error(s""">>>获取运单宽表数据""")
    startTime = System.currentTimeMillis()
    var scanRdd = getScanDataRdd(spark, incDay, date2).persist(StorageLevel.DISK_ONLY)
    var scanCnt = scanRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>获取运单宽表数据 : $scanCnt, 耗时 : $spanTime ms""")

    logger.error(s""">>>关联巴枪扫描数据""")
    startTime = System.currentTimeMillis()
    val xyRdd = unionScanRdd(xiaogeRdd, scanRdd, zc2DcMap).persist(StorageLevel.DISK_ONLY)
    xiaogeRddCnt = xyRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>关联巴枪扫描数据 : $xiaogeRddCnt, 耗时 : $spanTime ms""")
    xiaogeRdd.unpersist()
    scanRdd.unpersist()

    logger.error(s""">>>将关联后的数据入库""")
    startTime = System.currentTimeMillis()
    saveData(spark, xyRdd, incDay, "dm_gis.gis_toaddr_stat_new2_test")
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>数据入库耗时 : $spanTime ms""")
    xyRdd.unpersist()

  }

  /**
   * 左关联，左表存在少部分key倾斜，采用单独处理部分key的方式
   *
   * @param left    左表
   * @param right   右表
   * @param hashNum 散列系数，扩容倍数
   * @param topLean 需要单独处理的倾斜数据量
   */
  def leftOuterJoinOfLeftLeanElem(left: RDD[(String, JSONObject)], right: RDD[(String, JSONObject)], hashNum: Int, topLean: Int = 10): RDD[(String, (JSONObject, Option[JSONObject]))] = {
    val keyCounts = left.map(obj => (obj._1, 1)).reduceByKey(_ + _).sortBy(-_._2).take(topLean)
    val keys = keyCounts.map(obj => obj._1)
    val counts = keyCounts.map(obj => obj._2).sum
    logger.error("单独处理的keys:" + keyCounts.mkString(","))
    logger.error("单独处理的总数量:" + counts)
    //拆分数据为独立处理的key和非独立处理的key
    val leftHashKeyData = left.filter(obj => keys.contains(obj._1))
    val leftOtherData = left.filter(obj => !keys.contains(obj._1))
    val rightHashKeyData = right.filter(obj => keys.contains(obj._1))
    val rightOtherData = right.filter(obj => !keys.contains(obj._1))
    //先关联其他key数据
    val otherJoin = leftOtherData.leftOuterJoin(rightOtherData)
    //扩展单独处理的数据
    val leftHashKeyDataExpand = leftHashKeyData.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      (("00" + hashPrefix, obj._1), obj._2)
    })
    val rightHashKeyDataExpand = rightHashKeyData.flatMap(obj => {
      val dataArray = new ArrayBuffer[((String, String), JSONObject)]()
      for (i <- 0 until hashNum) {
        dataArray.append((("00" + i, obj._1), obj._2))
      }
      dataArray.iterator
    })
    //关联数据
    val hashKeyJoin = leftHashKeyDataExpand.leftOuterJoin(rightHashKeyDataExpand).map(obj => (obj._1._2, obj._2))
    hashKeyJoin.union(otherJoin)
  }

  def getToAddrRdd(spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    spark.sql(String.format("use %s", config.getDbGis))
    //    val toAddrSqlTempate = "select req_waybillno,req_address,req_citycode,re_deptcode,re_teamcode,sys_gisDeptCodeTo,sys_sssDeptCodeTo,sys_groupid " +
    //      "from %s where inc_day='%s' and req_addresstype = '2' and req_citycode <> ''"
    val toAddrSqlTempate = "select req_waybillno ,req_addresseeaddr, req_destcitycode, finalzc, finaltc, gis_to_sys_gisdeptcodeto, " +
      "gis_to_sys_sssdeptcodeto, gis_to_sys_groupid, req_addresseephone, req_addresseemobile, req_time,req_comp_name," +
      "gis_to_sys_groupid, standardization, groupids,gis_to_sys_src,req_province,req_city,req_area from %s where inc_day='%s' and req_destcitycode REGEXP '^[0-9]+$'"
    var toAddrSql = String.format(toAddrSqlTempate, config.getTableGisOmsto, date)
    var toAddrRdd = spark.sql(toAddrSql).repartition(320).rdd.map(row => {
      var re: (String, JSONObject) = null
      try {
        var obj = new JSONObject()
        var waybillNo = row.getString(0)
        var address = row.getString(1)
        var citycode = row.getString(2)
        var logDeptcode = row.getString(3)
        var logTeamcode = row.getString(4)
        var logGisDeptcode = row.getString(5)
        var logSssDeptcode = row.getString(6)
        var logGroupId = row.getString(7)
        var phone = row.getString(8)
        var mobile = row.getString(9)
        var reqTime = row.getString(10)
        var reqCompName = row.getString(11)
        var groupid = row.getString(12)
        var standardization = row.getString(13)
        var groupids = row.getString(14)
        var gis_to_sys_src = row.getString(15)

        if ("null".equals(logGisDeptcode))
          logGisDeptcode = ""
        if ("null".equals(logSssDeptcode))
          logSssDeptcode = ""

        obj.put("waybillno", waybillNo)
        obj.put("address", address)
        obj.put("citycode", citycode)
        obj.put("log_deptcode", logDeptcode)
        obj.put("log_teamcode", logTeamcode)
        obj.put("log_gisdeptcode", logGisDeptcode)
        obj.put("log_sssdeptcode", logSssDeptcode)
        obj.put("log_groupid", logGroupId)
        obj.put("phone", phone)
        obj.put("mobile", mobile)
        obj.put("req_time", reqTime)
        obj.put("req_comp_name", reqCompName)
        obj.put("groupid", groupid)
        obj.put("standardization", standardization)
        obj.put("groupids", groupids)
        obj.put("gis_to_sys_src", gis_to_sys_src)
        obj.put("req_province", row.getString(16))
        obj.put("req_city", row.getString(17))
        obj.put("req_area", row.getString(18))
        re = (String.format("%s_%s", waybillNo, citycode), obj)
      } catch {
        case e: Exception => logger.error(row, e)
      }
      re
    }).reduceByKey((obj1, obj2) => {
      if (obj1.containsKey("re_body"))
        obj1
      else
        obj2
    })
    toAddrRdd
  }

  def getRoute80Rdd(spark: SparkSession, date1: String, date2: String, excXiaogeNoSet: util.HashSet[String]): RDD[(String, JSONObject)] = {
    spark.sql(String.format("use %s", config.getDbFvp))
    val route80SqlTempate = "select mainwaybillno waybillno,zonecode,couriercode xiaoge_no,inc_day,opcode,baruploadtm from %s where inc_day>='%s' and inc_day<='%s' " +
      "and (opcode = '80'or opcode = '99' or (opcode = '33' and staywhycode in ('14', '55', '9', '67'))  or (opcode = '70' and staywhycode in ('14', '55', '9', '67'))  " +
      "or (opcode = '77' and staywhycode in ('14', '55', '103')) or opcode = '648')"
    var route80Sql = String.format(route80SqlTempate, config.getTableFvp, date1, date2)
    var route80Rdd = spark.sql(route80Sql).rdd.repartition(320).map(row => {
      var re: (String, JSONObject) = null
      var obj = new JSONObject()
      var waybillNo = row.getString(0)
      var zonecode = row.getString(1)
      var citycode = zonecode.replaceAll("(\\d*).*", "$1")
      var xiaogeNo = row.getString(2).replaceAll("^(0+)", "")
      var opDate = row.getString(3)
      var opCode = row.getString(4)
      var barUploadTm = row.getString(5)
      obj.put("zonecode", zonecode)
      obj.put("citycode", citycode)
      obj.put("xiaogeNo", xiaogeNo)
      obj.put("opdate", opDate)
      obj.put("opcode", opCode)
      obj.put("barUploadTm", barUploadTm)
      //      re = (waybillNo, obj)
      re = (String.format("%s_%s", waybillNo, citycode), obj)
      re
    }).reduceByKey((obj1, obj2) => {
      null
    }).filter(obj => {
      obj._2 != null && "80".equals(obj._2.getString("opcode")) && !excXiaogeNoSet.contains(String.format("%s,%s", obj._2.getString("xiaogeNo"), obj._2.getString("citycode")))
    })

    route80Rdd
  }

  def getScanDataRdd(spark: SparkSession, date1: String, date2: String): RDD[(String, JSONObject)] = {
    val scanDataTempate = "select waybill_no,delivery_lgt,delivery_lat from dm_gis.tt_waybill_info " +
      " where inc_day between '%s' and '%s' and (delivery_lgt is not null and delivery_lgt <>'') and (delivery_lat is not null and delivery_lat <>'') "
    var scanDataSql = String.format(scanDataTempate, date1, date2)
    var scanDataRdd = spark.sql(scanDataSql).rdd.repartition(320).map(row => {
      var re: (String, JSONObject) = null
      var obj = new JSONObject()
      var waybillNo = row.getString(0)
      obj.put("bar_scan_lng", row.getString(1))
      obj.put("bar_scan_lat", row.getString(2))
      re = (String.format("%s", waybillNo), obj)
      re
    }).reduceByKey((obj1, obj2) => obj1).filter(obj => {
      obj._1.nonEmpty
    })
    scanDataRdd
  }


  def getEmpInfo(spark: SparkSession, date1: String, date2: String): RDD[(String, JSONObject)] = {
    val empInfoSqlTemplate = s"select emp_code, dept_code, inc_day from ${config.getTableEmpInfo} where inc_day between '${date1}' and '${date2}'" +
      s" and cancel_flag<>'Y' and (dept_code not like '020%' and dept_code not like '755%')   "

    val empInfoSqlTbUser = s"select loginid emp_code,service_dept dept_code,inc_day from ods_rmds.tb_res_user " +
      s" where inc_day between '${date1}' and '${date2}' "


    //    val empInfoSql = empInfoSqlTemplate + " union all " + empInfoSqlTbUser
    val empInfoSql = empInfoSqlTbUser
    logger.error("empInfoSql:" + empInfoSql)
    val empInfoRdd = spark.sql(empInfoSql).rdd.repartition(320).map(row => {
      var xiaogeNo = row.getString(0)
      if (xiaogeNo != null)
        xiaogeNo = xiaogeNo.replaceAll("^(0+)", "")
      val xiaoge_zoneCode = row.getString(1)
      val incDay = row.getString(2)
      var obj = new JSONObject()
      obj.put("xiaoge_zonecode", xiaoge_zoneCode)
      if (xiaogeNo == null || xiaogeNo.isEmpty) {
        (null, obj)
      } else {
        (String.format("%s_%s", xiaogeNo, incDay), obj)
      }
    }).filter(obj => obj._1 != null).reduceByKey((obj1, obj2) => {
      obj1
    })
    empInfoRdd
  }

  def unionRoute80Data(toAddrRdd: RDD[(String, JSONObject)], route80Rdd: RDD[(String, JSONObject)], zc2DcMap: util.HashMap[String, String]): RDD[(String, JSONObject)] = {
    val rdd = toAddrRdd.union(route80Rdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).filter(obj => {
      obj._2.containsKey("address")
    }).map(obj => {
      var xiaogeNo = JSONUtil.getJsonVal(obj._2, "xiaogeNo", "").toString
      var zonecode = JSONUtil.getJsonVal(obj._2, "zonecode", "").toString
      var deptcode = zc2DcMap.get(zonecode)
      //      obj._2.put("waybillno", obj._1)
      obj._2.put("deptcode", deptcode)
      (xiaogeNo, obj._2)
    })
    rdd
  }

  def unionEmpInfoData(toAddrRdd: RDD[(String, JSONObject)], empInfo: RDD[(String, JSONObject)], zc2DcMap: util.HashMap[String, String]): RDD[(String, JSONObject)] = {
    val rdd =
      leftOuterJoinOfLeftLeanElem(toAddrRdd.map(obj => {
        val xiaogeNo = JSONUtil.getJsonVal(obj._2, "xiaogeNo", "")
        val opdate = JSONUtil.getJsonVal(obj._2, "opdate", "")
        (String.format("%s_%s", xiaogeNo, opdate), obj._2)
      }), empInfo, 10, 20)
        .map(obj => {
          var addrObj = obj._2._1
          var empInfos = obj._2._2
          if (empInfos != None) {
            var empObj = empInfos.get
            var xiaoge_zoneCode = JSONUtil.getJsonVal(empObj, "xiaoge_zonecode", "").toString
            var xiaoge_deptCode = zc2DcMap.get(xiaoge_zoneCode)
            addrObj.put("xiaoge_zonecode", xiaoge_zoneCode)
            addrObj.put("xiaoge_deptcode", xiaoge_deptCode)
          }
          val waybillNo = JSONUtil.getJsonVal(addrObj, "waybillno", "").toString
          (waybillNo, addrObj)
        })
    rdd
  }

  def unionToData(rdd: RDD[(String, JSONObject)], pickupPlanRdd: RDD[(String, Iterable[JSONObject])], zc2DcMap: util.HashMap[String, String]): RDD[(String, JSONObject)] = {
    var rdd4 = rdd.map(obj => {
      var waybillNo = JSONUtil.getJsonVal(obj._2, "waybillno", "").toString
      (waybillNo, obj._2)
    })
    rdd4
  }


  def saveData(spark: SparkSession, rdd: RDD[JSONObject], incDay: String, tagrt_table: String): Unit = {
    val count = rdd.count().toInt;
    var rows = rdd.repartition(count / 500000 + 1).map(obj => {
      var waybillNo = JSONUtil.getJsonValObject(obj, "waybillno", "")
      var citycode = JSONUtil.getJsonValObject(obj, "citycode", "")
      var address = JSONUtil.getJsonValObject(obj, "address", "").toString
      var logDeptcode = JSONUtil.getJsonValObject(obj, "log_deptcode", "")
      var logTeamcode = JSONUtil.getJsonValObject(obj, "log_teamcode", "")
      var logGisDeptcode = JSONUtil.getJsonValObject(obj, "log_gisdeptcode", "")
      var logSssDeptcode = JSONUtil.getJsonValObject(obj, "log_sssdeptcode", "")
      var logGroupId = JSONUtil.getJsonValObject(obj, "log_groupid", "")
      var logSrc = JSONUtil.getJsonValObject(obj, "log_src", "")
      var xiaoge_no = JSONUtil.getJsonValObject(obj, "xiaogeNo", "")
      if (xiaoge_no == null || "null".equals(xiaoge_no))
        xiaoge_no = ""
      var deptcode = JSONUtil.getJsonValObject(obj, "deptcode", "")
      var zonecode = JSONUtil.getJsonValObject(obj, "zonecode", "")
      var teamcode = JSONUtil.getJsonValObject(obj, "teamcode", "")
      var opDate = JSONUtil.getJsonValObject(obj, "opdate", "")
      var sssZoneCode = JSONUtil.getJsonValObject(obj, "sss_zone_code", "").toString
      var sssZoneCodeTypes = JSONUtil.getJsonValObject(obj, "sss_zone_code_type", "").toString
      var sssIncDays = JSONUtil.getJsonValObject(obj, "sss_inc_day", "").toString
      var sssCnt = JSONUtil.getJsonValObject(obj, "sss_cnt", "").toString
      if (sssZoneCode.contains("#"))
        sssZoneCode = ""
      var gisDeptcode = JSONUtil.getJsonValObject(obj, "gisdeptcode", "")
      var gisTeamcode = JSONUtil.getJsonValObject(obj, "gisteamcode", "")
      var xiaogeDeptCode = JSONUtil.getJsonValObject(obj, "xiaoge_deptcode", "")
      var xiaogeZoneCode = JSONUtil.getJsonValObject(obj, "xiaoge_zonecode", "")
      var gisCorrectFlag = JSONUtil.getJsonValObject(obj, "giscorrectflag", new Integer(-1))
      var sssCorrectFlag = JSONUtil.getJsonValObject(obj, "ssscorrectflag", new Integer(-1))
      var phone = JSONUtil.getJsonValObject(obj, "phone", "")
      var mobile = JSONUtil.getJsonValObject(obj, "mobile", "")
      var barScanLng = JSONUtil.getJsonValObject(obj, "bar_scan_lng", "")
      var barScanLat = JSONUtil.getJsonValObject(obj, "bar_scan_lat", "")
      var reqTime = JSONUtil.getJsonValObject(obj, "req_time", "")
      var reqCompName = JSONUtil.getJsonValObject(obj, "req_comp_name", "")
      var groupid = JSONUtil.getJsonValObject(obj, "groupid", "")
      var standardization = JSONUtil.getJsonValObject(obj, "standardization", "")
      var groupids = JSONUtil.getJsonValObject(obj, "groupids", "")
      var gis_to_sys_src = JSONUtil.getJsonValObject(obj, "gis_to_sys_src", "")
      var req_province = JSONUtil.getJsonValObject(obj, "req_province", "")
      var req_city = JSONUtil.getJsonValObject(obj, "req_city", "")
      var req_area = JSONUtil.getJsonValObject(obj, "req_area", "")
      var row: Row = null
      try {
        row = RowFactory.create(waybillNo, address, logDeptcode, logTeamcode, gisDeptcode, gisTeamcode, xiaoge_no, deptcode,
          teamcode, opDate, gisCorrectFlag, sssCorrectFlag, logGisDeptcode, logSssDeptcode, sssZoneCode, sssZoneCodeTypes,
          sssIncDays, sssCnt, zonecode, xiaogeDeptCode, xiaogeZoneCode, logGroupId, phone, mobile, barScanLng, barScanLat,
          reqTime, reqCompName, groupid, standardization, groupids, gis_to_sys_src, citycode, req_province, req_city, req_area)
      } catch {
        case e: Exception =>
      }
      row
    })

    var structFields = new util.ArrayList[StructField]()
    structFields.add(DataTypes.createStructField("waybillno", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("address", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("logdeptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("logteamcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("gisdeptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("gisteamcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("xiaoge_no", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("deptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("teamcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("opdate", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("giscorrectflag", DataTypes.IntegerType, true))
    structFields.add(DataTypes.createStructField("ssscorrectflag", DataTypes.IntegerType, true))
    structFields.add(DataTypes.createStructField("log_gisdeptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("log_sssdeptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sss_zone_code", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sss_zone_code_type", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sss_inc_day", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sss_cnt", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("zonecode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("xiaoge_deptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("xiaoge_zonecode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("log_groupid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("phone", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("mobile", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bar_scan_lng", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bar_scan_lat", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_time", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_comp_name", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("groupid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("standardization", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("groupids", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("gis_to_sys_src", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("citycode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_province", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_city", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_area", DataTypes.StringType, true))
    val structType = DataTypes.createStructType(structFields)

    var ds = spark.createDataFrame(rows, structType)
    var tempView = "gis_toaddr_stat_new2_test_temp_view_" + System.currentTimeMillis()
    ds.createOrReplaceTempView(tempView)
    //    var cityCodeList = new util.ArrayList[String]()
    //    spark.sql("select distinct(citycode) from %s".format(tempView)).rdd.collect().foreach(row => {
    //      cityCodeList.add(row.getString(0))
    //    })
    //    for(i <- 0 to cityCodeList.size() - 1){
    //      try{
    //        spark.sql(String.format("alter table %s drop if exists partition(inc_day = '%s', citycode = '%s')", config.getTableGis2, incDay, cityCodeList.get(i)))
    //        spark.sql(String.format("alter table %s add partition(inc_day = '%s', citycode = '%s')", config.getTableGis2, incDay, cityCodeList.get(i)))
    //      }catch {
    //        case e : Exception => e.printStackTrace()
    //      }
    //    }
    //    spark.sql(String.format("insert into %s partition(inc_day = '%s',citycode) select * from %s", config.getTableGis2, incDay, tempView))
    spark.sql("set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat")
    spark.sql("set mapreduce.input.fileinputformat.split.maxsize=134217728")
    spark.sql("set mapreduce.input.fileinputformat.split.minsize.per.rack=134217728")
    spark.sql("set mapreduce.input.fileinputformat.split.minsize.per.node=134217728")
    try {
      //重新分区的表
      logger.error(s""">>>写入重新分区的表gis_toaddr_stat_new2""")
      spark.sql(String.format("alter table %s drop if exists partition(inc_day = '%s')", tagrt_table, incDay))
      spark.sql(String.format("alter table %s add partition(inc_day = '%s')", tagrt_table, incDay))
      spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", tagrt_table, incDay, tempView))
    } catch {
      case e: Exception => e.printStackTrace()
    }
  }


  def dateDelta(delta: Int): String = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, delta)
    val date = sdf.format(cal.getTime)
    date
  }
}
