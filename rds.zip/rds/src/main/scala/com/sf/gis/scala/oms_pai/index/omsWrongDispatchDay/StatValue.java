package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay;

/**
 * Created by 01375125 on 2018/12/29.
 * 状态值
 */
@SuppressWarnings("unused")
enum StatValue {
}
