package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay.WdIndexStat.MergeType
import com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay.WdIndexStat.MergeType.MergeType
import com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay.WrongObj.{RecObj, RecObjNew, RecValidNewObj, RecValidObj, ZcRecValidObj}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
  * Created by 01375125 on 2018/12/29.
  * 统计各类识别量
  */
object StatRecIndex {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    test()
  }

  def test(): Unit = {
    var i = 0
    while(i <100 ){
      i = i+ 1
      val dd = RecValidNewObj("dd","dd","dd","dd","dd","dd","dd",
        0,0,0,0,0,
        0,0,0,0,0,0)
      System.out.print(dd.copy(city = "ALL").city)

    }

  }

  /**
    * 获取oms错分行统计rdd
    *
    * @param omsRdd
    * @return
    */
  def getOmsRowRecRdd(omsRdd: RDD[JSONObject]): RDD[RecObj] = {
    val omsRecRdd = omsRdd.flatMap(obj => {
      getRowValidRecIndex(obj).iterator()
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>行指标量" + omsRecRdd.count())
    omsRecRdd.take(2).foreach(o => println(o))
    omsRecRdd
  }

  /**
    * 获取错分指标聚合量
    *
    * @param omsRecRdd
    * @return
    */
  def getOmsValidRecRdd(omsRecRdd: RDD[RecObj]): (RDD[(String, RecValidObj)], RDD[(String, ZcRecValidObj)]) = {
    val omsCityRecRdd = omsRecRdd.filter(obj => Constant.PRE.equals(obj.data_type)).map(obj => {
      val key = Array(obj.stat_date, obj.city_code, obj.city).mkString("_")
      (key, obj)
    }).reduceByKey((o1, o2) => {
      RecObj(o1.data_type, o1.stat_date, o1.province, o1.region, o1.city_code, o1.city, o1.zonecode, o1.req + o2.req, o1.gisRec + o2.gisRec, o1.gisRecDiff + o2.gisRecDiff, o1.sssRec + o2.sssRec, o1.sssRecDiff + o2.sssRecDiff, o1.gisSssRec + o2.gisSssRec, o1.arssRec + o2.arssRec,
        o1.finalRec + o2.finalRec, o1.finalRecDiff + o2.finalRecDiff, o1.gisNoWrong + o2.gisNoWrong, o1.gisNoWrongDiff + o2.gisNoWrongDiff, o1.sssNoWrong + o2.sssNoWrong,
        o1.sssNoWrongDiff + o2.sssNoWrongDiff, o1.gisSssNoWrong + o2.gisSssNoWrong, o1.arssNoWrong + o2.arssNoWrong, o1.finalNoWrong + o2.finalNoWrong,
        o1.finalNoWrongDiff + o2.finalNoWrongDiff,o1.gisRecNorm+o2.gisRecNorm,o1.gisNoWrongNorm+o2.gisNoWrongNorm, o1.ksRec + o2.ksRec)
    }).map(obj => {
      val o = obj._2
      val recValidObj = RecValidObj(o.stat_date, o.province, o.region, o.city_code, o.city, o.gisRec - o.gisNoWrong, o.sssRec - o.sssNoWrong, o.gisSssRec - o.gisSssNoWrong, o.arssRec - o.arssNoWrong,
        o.finalRec - o.finalNoWrong, o.gisRecDiff - o.gisNoWrongDiff, o.sssRecDiff - o.sssNoWrongDiff, o.finalRecDiff - o.finalNoWrongDiff,o.gisRecNorm-o.gisNoWrongNorm, o.ksRec)
      (obj._1, recValidObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>city rec :" + omsCityRecRdd.count())

    val omsZcRecRdd = omsRecRdd.map(obj => {
      val key = Array(obj.data_type, obj.stat_date, obj.city_code, obj.city, obj.zonecode).mkString("_")
      (key, obj)
    }).reduceByKey((o1, o2) => {
      RecObj(o1.data_type, o1.stat_date, o1.province, o1.region, o1.city_code, o1.city, o1.zonecode, o1.req + o2.req,
        o1.gisRec + o2.gisRec, o1.gisRecDiff + o2.gisRecDiff, o1.sssRec + o2.sssRec, o1.sssRecDiff + o2.sssRecDiff,
        o1.gisSssRec + o2.gisSssRec, o1.arssRec + o2.arssRec, o1.finalRec + o2.finalRec, o1.finalRecDiff + o2.finalRecDiff,
        o1.gisNoWrong + o2.gisNoWrong, o1.gisNoWrongDiff + o2.gisNoWrongDiff, o1.sssNoWrong + o2.sssNoWrong, o1.sssNoWrongDiff + o2.sssNoWrongDiff,
        o1.gisSssNoWrong + o2.gisSssNoWrong, o1.arssNoWrong + o2.arssNoWrong, o1.finalNoWrong + o2.finalNoWrong, o1.finalNoWrongDiff + o2.finalNoWrongDiff,
      o1.gisRecNorm+o2.gisRecNorm,o1.gisNoWrongNorm+o2.gisNoWrongNorm, o1.ksRec + o2.ksRec)
    }).map(obj => {
      val o = obj._2
      val zcRecValidObj = ZcRecValidObj(o.data_type, o.stat_date, o.province, o.region, o.city_code, o.city, o.zonecode, o.req, o.gisRec - o.gisNoWrong, o.sssRec - o.sssNoWrong, o.gisSssRec - o.gisSssNoWrong, o.arssRec - o.arssNoWrong, o.finalRec - o.finalNoWrong, o.gisRecDiff - o.gisNoWrongDiff,
      o.gisRecNorm-o.gisNoWrongNorm, o.ksRec)
      (obj._1, zcRecValidObj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //test 定位数量不一致问题 begin
    var total = 0
    omsZcRecRdd.collect().foreach(o => {
      total = Integer.valueOf(o._2.req) + total
    })
    logger.error(">>>zc total req:" + total)
    //test 定位数量不一致问题 end
    logger.error(">>>zc rec :" + omsZcRecRdd.count())
    (omsCityRecRdd, omsZcRecRdd)
  }

  /**
    * 获取新错分指标聚合量
    *
    * @param omsRecRdd
    * @return
    */
  def getOmsValidRecRddNew(omsRecRdd: RDD[RecObj]): (RDD[RecValidNewObj], RDD[RecValidNewObj], RDD[RecValidNewObj], RDD[RecValidNewObj]) = {
    logger.error(">>>按网点统计错分指标...")
    val zcValidRecRdd = statValidRecMerge(MergeType.zc, omsRecRdd)
    logger.error(">>>按网点统计错分指标:"+zcValidRecRdd.count())
    logger.error(">>>按城市名统计错分指标...")
    val cityValidRecRdd = statValidRecMergeNew(MergeType.city, zcValidRecRdd)
    logger.error(">>>按城市名统计错分指标:"+cityValidRecRdd.count())
    logger.error(">>>按大区统计错分指标...")
    val regionValidRecRdd = statValidRecMergeNew(MergeType.region, cityValidRecRdd)
    logger.error(">>>按大区统计错分指标:"+regionValidRecRdd.count())
    logger.error(">>>按日期统计错分指标...")
    val dateValidRecRdd = statValidRecMergeNew(MergeType.date, zcValidRecRdd)
    logger.error(">>>按日期统计错分指标:"+dateValidRecRdd.count())
    (dateValidRecRdd, regionValidRecRdd, cityValidRecRdd, zcValidRecRdd)
  }

  /**
    * 合并有效识别量
    *
    * @param o1
    * @param o2
    * @return
    */
  def mergeRecObj(o1: RecObj, o2: RecObj): RecObj = {
    RecObj(o1.data_type, o1.stat_date, o1.province, o1.region, o1.city_code,
      o1.city, o1.zonecode, o1.req + o2.req, o1.gisRec + o2.gisRec, o1.gisRecDiff + o2.gisRecDiff,
      o1.sssRec + o2.sssRec, o1.sssRecDiff + o2.sssRecDiff, o1.gisSssRec + o2.gisSssRec, o1.arssRec + o2.arssRec,
      o1.finalRec + o2.finalRec, o1.finalRecDiff + o2.finalRecDiff, o1.gisNoWrong + o2.gisNoWrong,
      o1.gisNoWrongDiff + o2.gisNoWrongDiff, o1.sssNoWrong + o2.sssNoWrong, o1.sssNoWrongDiff + o2.sssNoWrongDiff,
      o1.gisSssNoWrong + o2.gisSssNoWrong, o1.arssNoWrong + o2.arssNoWrong, o1.finalNoWrong + o2.finalNoWrong,
      o1.finalNoWrongDiff + o2.finalNoWrongDiff,o1.gisRecNorm+o2.gisRecNorm,o1.gisNoWrongNorm+o2.gisNoWrongNorm, o1.ksRec + o2.ksRec)
  }
  /**
    * 合并有效识别量
    *
    * @param o1
    * @param o2
    * @return
    */
  def mergeRecObjNew(o1: RecValidNewObj, o2: RecValidNewObj): RecValidNewObj = {
    val data_type = o1.data_type
    val stat_date = o1.stat_date
    val region = o1.region
    val city = o1.city
    val city_code= o1.city_code
    val zonecode = o1.zonecode
    val ak = o1.ak
    val req = o1.req + o2.req
    val gisValidRec = o1.gisValidRec + o2.gisValidRec
    val gisSssValidRec = o1.gisSssValidRec + o2.gisSssValidRec
    val sssValidRec = o1.sssValidRec + o2.sssValidRec
    val arssValidRec = o1.arssValidRec + o2.arssValidRec
    val finalValidRec = o1.finalValidRec + o2.finalValidRec
    val gusRecDiff = o1.gusRecDiff + o2.gusRecDiff
    val sssValidRecDiff = o1.sssValidRecDiff + o2.sssValidRecDiff
    val finalValidRecDiff = o1.finalValidRecDiff + o2.finalValidRecDiff
    val gisValidRecNorm = o1.gisValidRecNorm + o2.gisValidRecNorm
    val ksValidRec = o1.ksValidRec + o2.ksValidRec
    RecValidNewObj(data_type,stat_date,region,city,city_code,zonecode,ak,
      req,gisValidRec,sssValidRec,gisSssValidRec,arssValidRec,
      finalValidRec,gusRecDiff,sssValidRecDiff,finalValidRecDiff,gisValidRecNorm, ksValidRec)
  }
  /**
    * 按维度合并错分数据
    *
    * @param mergeType
    * @param omsRecRdd
    * @return
    */
  def statValidRecMergeNew(mergeType: MergeType, omsRecRdd: RDD[RecValidNewObj]): RDD[RecValidNewObj] = {
    var rowIndexRddMerge: RDD[(String,RecValidNewObj)] = null
    if (mergeType.equals(MergeType.date)) {
      rowIndexRddMerge = omsRecRdd.filter(obj=> (obj.region!=null
        && !WdIndexStat.invalidRegion.contains(obj.region))).map(obj => {
        val key = Array(obj.data_type, obj.stat_date, "ALL", "ALL", "ALL", "ALL").mkString("_")
        val objNew = obj.copy(region = "ALL", city = "ALL",city_code="ALL", zonecode = "ALL", ak="ALL")
        (key, objNew)
      })
    } else if (mergeType.equals(MergeType.region)) {
      rowIndexRddMerge = omsRecRdd.map(obj => {
        val key = Array(obj.data_type, obj.stat_date, obj.region, "ALL", "ALL", "ALL").mkString("_")
        val objNew = obj.copy(city = "ALL",city_code="ALL", zonecode = "ALL", ak="ALL")
        (key, objNew)
      })
    } else if (mergeType.equals(MergeType.city)) {
      rowIndexRddMerge = omsRecRdd.map(obj => {
        val key = Array(obj.data_type, obj.stat_date, obj.region, obj.city, "ALL", "ALL").mkString("_")
        val objNew = obj.copy(zonecode = "ALL", ak="ALL")
        (key, objNew)
      })
    } else if (mergeType.equals(MergeType.zc)) {
      rowIndexRddMerge = omsRecRdd.map(obj => {
        val key = Array(obj.data_type, obj.stat_date, obj.region, obj.city, obj.zonecode, "ALL").mkString("_")
        val objNew = obj.copy(ak="ALL")
        (key, objNew)
      })
    } else {
      return null
    }
    rowIndexRddMerge.reduceByKey((o1, o2) => {
      mergeRecObjNew(o1, o2)
    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER)
  }
  def statValidRecMerge(mergeType: MergeType, omsRecRdd: RDD[RecObj]): RDD[RecValidNewObj] = {
    var rowIndexRddMerge: RDD[RecObjNew] = null
    if (mergeType.equals(MergeType.date)) {
      rowIndexRddMerge = omsRecRdd.filter(obj=> (obj.region!=null
        && !WdIndexStat.invalidRegion.contains(obj.region))).map(obj => {
        val key = Array(obj.data_type, obj.stat_date, "ALL", "ALL", "ALL", "ALL").mkString("_")
        (key, obj)
      }).reduceByKey((o1, o2) => {
        mergeRecObj(o1, o2)
      }).map(obj => {
        val obj1 = obj._2
        RecObjNew(obj1.data_type, obj1.stat_date, "ALL", "ALL","ALL", "ALL", "ALL", obj1.req,
          obj1.gisRec, obj1.gisRecDiff, obj1.sssRec, obj1.sssRecDiff, obj1.gisSssRec, obj1.arssRec,
          obj1.finalRec, obj1.finalRecDiff, obj1.gisNoWrong, obj1.gisNoWrongDiff, obj1.sssNoWrong, obj1.sssNoWrongDiff,
          obj1.gisSssNoWrong, obj1.arssNoWrong, obj1.finalNoWrong, obj1.finalNoWrongDiff,obj1.gisRecNorm,obj1.gisNoWrongNorm, obj1.ksRec)
      })
    } else if (mergeType.equals(MergeType.region)) {
      rowIndexRddMerge = omsRecRdd.map(obj => {
        val key = Array(obj.data_type, obj.stat_date, obj.region, "ALL", "ALL", "ALL").mkString("_")
        (key, obj)
      }).reduceByKey((o1, o2) => {
        mergeRecObj(o1, o2)
      }).map(obj => {
        val obj1 = obj._2
        RecObjNew(obj1.data_type, obj1.stat_date, obj1.region, "ALL", "ALL","ALL", "ALL", obj1.req,
          obj1.gisRec, obj1.gisRecDiff, obj1.sssRec, obj1.sssRecDiff, obj1.gisSssRec, obj1.arssRec,
          obj1.finalRec, obj1.finalRecDiff, obj1.gisNoWrong, obj1.gisNoWrongDiff, obj1.sssNoWrong, obj1.sssNoWrongDiff,
          obj1.gisSssNoWrong, obj1.arssNoWrong, obj1.finalNoWrong, obj1.finalNoWrongDiff,obj1.gisRecNorm,obj1.gisNoWrongNorm, obj1.ksRec)
      })
    } else if (mergeType.equals(MergeType.city)) {
      rowIndexRddMerge = omsRecRdd.map(obj => {
        val key = Array(obj.data_type, obj.stat_date, obj.region, obj.city, "ALL", "ALL").mkString("_")
        (key, obj)
      }).reduceByKey((o1, o2) => {
        mergeRecObj(o1, o2)
      }).map(obj => {
        val obj1 = obj._2
        RecObjNew(obj1.data_type, obj1.stat_date, obj1.region, obj1.city,obj1.city_code, "ALL", "ALL", obj1.req,
          obj1.gisRec, obj1.gisRecDiff, obj1.sssRec, obj1.sssRecDiff, obj1.gisSssRec, obj1.arssRec,
          obj1.finalRec, obj1.finalRecDiff, obj1.gisNoWrong, obj1.gisNoWrongDiff, obj1.sssNoWrong, obj1.sssNoWrongDiff,
          obj1.gisSssNoWrong, obj1.arssNoWrong, obj1.finalNoWrong, obj1.finalNoWrongDiff,obj1.gisRecNorm,obj1.gisNoWrongNorm, obj1.ksRec)
      })
    } else if (mergeType.equals(MergeType.zc)) {
      rowIndexRddMerge = omsRecRdd.map(obj => {
        val key = Array(obj.data_type, obj.stat_date, obj.region, obj.city, obj.zonecode, "ALL").mkString("_")
        (key, obj)
      }).reduceByKey((o1, o2) => {
        mergeRecObj(o1, o2)
      }).map(obj => {
        val obj1 = obj._2
        RecObjNew(obj1.data_type, obj1.stat_date, obj1.region, obj1.city,obj1.city_code, obj1.zonecode, "ALL", obj1.req,
          obj1.gisRec, obj1.gisRecDiff, obj1.sssRec, obj1.sssRecDiff, obj1.gisSssRec, obj1.arssRec,
          obj1.finalRec, obj1.finalRecDiff, obj1.gisNoWrong, obj1.gisNoWrongDiff, obj1.sssNoWrong, obj1.sssNoWrongDiff,
          obj1.gisSssNoWrong, obj1.arssNoWrong, obj1.finalNoWrong, obj1.finalNoWrongDiff,obj1.gisRecNorm,obj1.gisNoWrongNorm, obj1.ksRec)
      })
    } else {
      return null
    }
    rowIndexRddMerge.map(o => {
      RecValidNewObj(o.data_type, o.stat_date, o.region, o.city,o.city_code, o.zonecode, o.ak, o.req, o.gisRec - o.gisNoWrong, o.sssRec - o.sssNoWrong, o.gisSssRec - o.gisSssNoWrong, o.arssRec - o.arssNoWrong, o.finalRec - o.finalNoWrong, o.gisRecDiff - o.gisNoWrongDiff, o.sssRecDiff - o.sssNoWrongDiff, o.finalRecDiff - o.finalNoWrongDiff,
      o.gisRecNorm-o.gisNoWrongNorm, o.ksRec)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
  }
  /**
    * 统计行的请求量
    *
    * @param obj
    */
  def getRowValidRecIndex(obj: JSONObject): util.ArrayList[RecObj] = {
    val list = new util.ArrayList[RecObj]()
    list.add(getRowValidRecIndex(obj, oper_flag = false))
    list.add(getRowValidRecIndex(obj, oper_flag = true))
    list
  }

  def getRowValidRecIndex(obj: JSONObject, oper_flag: Boolean): RecObj = {
    val req = 1
    var gisRec, sssRec, gisSssRec, arssRec, ksRec, finalRec, gisRecDiff, sssRecDiff, finalRecDiff = 0
    var gisRecNorm = 0
    var gisNoWrong, sssNoWrong, gisSssNoWrong, arssNoWrong, finalNoWrong, gisNoWrongDiff, sssNoWrongDiff, finalNoWrongDiff = 0
    var gisNoWrongNorm = 0
    val province = obj.getString("province")
    val region = obj.getString("region")
    val cityCode = obj.getString("city_code")
    val city = obj.getString("city")
    val omsBody = obj.getJSONObject("oms_body")
    val reqDate = omsBody.getString("req_date")
    val isGisDeptMatch = omsBody.getBoolean("isGisDeptMatch")
    val isSssDeptMatch = omsBody.getBoolean("isSssDeptMatch")
    val isGisSssDeptMatch = omsBody.getBoolean("isGisSssDeptMatch")
    val isArssDeptMatch = omsBody.getBoolean("isArssDeptMatch")
    val isFinalDeptMatch = omsBody.getBoolean("isFinalDeptMatch")
    val isKsDeptMatch = omsBody.getBoolean("isKsDeptMatch")
    val gis_status = omsBody.getString("gis_status")
    val sss_status = omsBody.getString("sss_status")
    val gis_sss_status = omsBody.getString("gis_sss_status")
    val arss_status = omsBody.getString("arss_status")
    val final_status = omsBody.getString("final_status")
    val isGisSssDiff = omsBody.getString("isGisSssDiff")
    var final_dept = omsBody.getString("final_dept_map")
    val oper_status = omsBody.getString("oper_status")
    val data_type = if (oper_flag) Constant.AFT else Constant.PRE
    if (final_dept == null || "".equals(final_dept)) final_dept = "-"
    if (!oper_flag || !"1".equals(oper_status)) { //不排除或非补码排除件
      if (isGisDeptMatch) {
        gisRec = 1 //gis的识别量
        val src = omsBody.getString("lib_src")
        if(src != null && src.toUpperCase.equals("NORM")){
          gisRecNorm = 1
        }
        if (isGisSssDiff.equals("diff")) gisRecDiff = 1 //gis和sss不一致gis识别量
        if (gis_status.equals("0") || gis_status.equals("2")) {
//          gisNoWrong = 1 //gis不计算错分等无效识别
//          if(gisRecNorm==1)gisNoWrongNorm = 1
//          if (isGisSssDiff.equals("diff")) gisNoWrongDiff = 1 //gis和sss不一致，gis不参与
        }
      }
      if (isSssDeptMatch) {
        sssRec = 1
        if (isGisSssDiff.equals("diff")) sssRecDiff = 1
        if (sss_status.equals("0") || sss_status.equals("2")) {
//          sssNoWrong = 1 //不计算错分的量
//          if (isGisSssDiff.equals("diff")) sssNoWrongDiff = 1
        }
      }
      if (isGisSssDeptMatch) {
        gisSssRec = 1
//        if (gis_sss_status.equals("0") || gis_sss_status.equals("2")) gisSssNoWrong = 1
      }

      if (isArssDeptMatch) {
        arssRec = 1
//        if (arss_status.equals("0") || arss_status.equals("2")) arssNoWrong = 1
      }
      if (isKsDeptMatch) {
        ksRec = 1
      }

      if (isFinalDeptMatch) {
        finalRec = 1
        if (isGisSssDiff.equals("diff")) finalRecDiff = 1
        if (final_status.equals("0") || final_status.equals("2")) {
//          finalNoWrong = 1
//          if (isGisSssDiff.equals("diff")) finalNoWrongDiff = 1
        }
      }
    }
    RecObj(data_type, reqDate, province, region, cityCode, city, final_dept, req, gisRec, gisRecDiff, sssRec, sssRecDiff, gisSssRec,
      arssRec, finalRec, finalRecDiff, gisNoWrong, gisNoWrongDiff, sssNoWrong,
      sssNoWrongDiff, gisSssNoWrong, arssNoWrong, finalNoWrong, finalNoWrongDiff,
      gisRecNorm,gisNoWrongNorm, ksRec)
  }

}
