package com.sf.gis.scala.oms_pai.index.idxCompare

import com.sf.gis.scala.utils.Util
import org.apache.log4j.Logger

/**
  * Created by 01368078 on 2019/3/22.
  */

object WdIdxCompare{
  def main(args: Array[String]): Unit = {
    val incDay = Util.dateDelta(-1,"")
    val comp = new WdIdxCompare()
    comp.comapre(Util.getDay(incDay, -5, ""))
    comp.comapre(Util.getDay(incDay, -4, ""))
    comp.comapre(Util.getDay(incDay, -3, ""))
  }
}

class WdIdxCompare {
  val logger: Logger = Logger.getLogger(classOf[WdIdxCompare])
  def comapre(incDay : String) : Unit = {
    val refDate = Util.getDay(incDay,-7,"")
    val threshold = 0.02
    val ALL = "ALL"
    val columns = Array("STAT_DATE","REGION","CITY","REQ" ,"ZC" ,"ZC_NORM" ,"ZC_CHKN" ,"ZC_CHKE" ,"ZC_PHONE" ,
      "ZC_ROAD" ,"ZC_TC2" ,"ZC_AUTO", "ZC_NORMHP", "ZC_NORMCOMPANY", "ZC_FINAL", "ZC_GISSSS", "ZC_SSS", "ZC_ARSS", "ZC_GUS",
      "ZC_GUS_SSS", "ZC_GUS_BOTH") //查询的字段
    val keyIdxs = Array(0, 1, 2)  //主键下标
    val numIdxs = Array(3) //数量下标
    val rateIdxs = Array(4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20) //比率下标
    val flags = Array(0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1)  //1->上升变好，-1->下降变好

    val OMS_DLV_FD = "OMS_DLV_FD"
    val sqlPat =
      s"""select STAT_DATE, REGION, '$ALL' CITY, sum(coalesce(REQ, 0)) REQ, sum(coalesce(ZC, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC,
         |  sum(coalesce(ZC_NORM, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_NORM, sum(coalesce(ZC_CHKN, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_CHKN,
         |  sum(coalesce(ZC_CHKE, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_CHKE, sum(coalesce(ZC_PHONE, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_PHONE,
         |  sum(coalesce(ZC_ROAD, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_ROAD, sum(coalesce(ZC_TC2, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_TC2,
         |  sum(coalesce(ZC_AUTO, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_AUTO, sum(coalesce(ZC_NORMHP, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_NORMHP,
         |  sum(coalesce(ZC_NORMCOMPANY, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_NORMCOMPANY,
         |  sum(coalesce(ZC_FINAL, 0))/sum(coalesce(RCG_ZC_FINAL_VLD, 0)) ZC_FINAL, sum(coalesce(ZC_GISSSS, 0))/sum(coalesce(RCG_ZC_GISSSS_VLD, 0)) ZC_GISSSS,
         |  sum(coalesce(ZC_SSS, 0))/sum(coalesce(RCG_ZC_SSS_VLD, 0)) ZC_SSS, sum(coalesce(ZC_ARSS, 0))/sum(coalesce(RCG_ZC_ARSS_VLD, 0)) ZC_ARSS,
         |  sum(coalesce(ZC_GUS, 0))/sum(coalesce(RCG_ZC_GUS_VLD, 0)) ZC_GUS, sum(coalesce(ZC_GUS_SSS, 0))/sum(coalesce(RCG_ZC_GUS_VLD, 0)) ZC_GUS_SSS,
         |  sum(coalesce(ZC_GUS_BOTH, 0))/sum(coalesce(RCG_ZC_GUS_VLD, 0)) ZC_GUS_BOTH from $OMS_DLV_FD where STAT_DATE = '%s' and DATA_TYPE = 'AFT'
         |  group by STAT_DATE, REGION
         |union
         |  select STAT_DATE, REGION, CITY, sum(coalesce(REQ, 0)) REQ, sum(coalesce(ZC, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC,
         |  sum(coalesce(ZC_NORM, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_NORM, sum(coalesce(ZC_CHKN, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_CHKN,
         |  sum(coalesce(ZC_CHKE, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_CHKE, sum(coalesce(ZC_PHONE, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_PHONE,
         |  sum(coalesce(ZC_ROAD, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_ROAD, sum(coalesce(ZC_TC2, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_TC2,
         |  sum(coalesce(ZC_AUTO, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_AUTO, sum(coalesce(ZC_NORMHP, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_NORMHP,
         |  sum(coalesce(ZC_NORMCOMPANY, 0))/sum(coalesce(RCG_ZC_VLD, 0)) ZC_NORMCOMPANY,
         |  sum(coalesce(ZC_FINAL, 0))/sum(coalesce(RCG_ZC_FINAL_VLD, 0)) ZC_FINAL, sum(coalesce(ZC_GISSSS, 0))/sum(coalesce(RCG_ZC_GISSSS_VLD, 0)) ZC_GISSSS,
         |  sum(coalesce(ZC_SSS, 0))/sum(coalesce(RCG_ZC_SSS_VLD, 0)) ZC_SSS, sum(coalesce(ZC_ARSS, 0))/sum(coalesce(RCG_ZC_ARSS_VLD, 0)) ZC_ARSS,
         |  sum(coalesce(ZC_GUS, 0))/sum(coalesce(RCG_ZC_GUS_VLD, 0)) ZC_GUS, sum(coalesce(ZC_GUS_SSS, 0))/sum(coalesce(RCG_ZC_GUS_VLD, 0)) ZC_GUS_SSS,
         |  sum(coalesce(ZC_GUS_BOTH, 0))/sum(coalesce(RCG_ZC_GUS_VLD, 0)) ZC_GUS_BOTH from $OMS_DLV_FD where STAT_DATE = '%s' and DATA_TYPE = 'AFT'
         |  group by STAT_DATE, REGION, CITY
       """.stripMargin
    logger.error("sql : " + sqlPat)
    logger.error("get current date : " + incDay)
    val curSql = String.format(sqlPat, incDay, incDay)
    logger.error("get ref date : " + refDate)
    val refSql = String.format(sqlPat, refDate, refDate)
    val outTable = "IC_DLV_FD"
    new IdxCompare(curSql, refSql, threshold, columns, keyIdxs, numIdxs, rateIdxs, flags, outTable).idxCompare(incDay)
  }
}
