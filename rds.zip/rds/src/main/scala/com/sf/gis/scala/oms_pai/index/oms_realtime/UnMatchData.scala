package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.net.URLEncoder
import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpConnection, MD5Util, ShellExcutor}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_pai.db.{ManagerFactory, PrManager, ProManager}
import com.sf.gis.scala.oms_pai.start.JavaUtil
import com.sf.gis.scala.utils.{DbUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks


/**
 * Created by 01368078 on 2019/3/5.
 * 任务id：225139
 * 任务名称：rds派件指标系统-缺失指标
 * 开发：张想远
 * 业务：郭本婕
 */
object UnMatchData {
  @transient lazy val logger: Logger = Logger.getLogger(UnMatchData.getClass)
  //  val pr_db_property = "mysql-pr-config.properties"
  //  val pro_db_property = "mysql-pro-db.properties"
  val nameArr: Array[String] = Array[String]("type", "req_time", "req_addresseephone", "req_addresseemobile", "req_addresseeaddr",
    "req_destcitycode", "req_waybillno", "re_addresseedeptcode", "re_addresseeteamcode", "gis_to_sys_time",
    "gis_to_sys_teamtoretby", "gis_to_sys_gisteamcodeto", "gis_to_sys_src", "gis_to_sys_gisdeptcodeto",
    "gis_to_sys_groupid", "gis_to_sys_depttoretby", "gis_to_sys_sssdeptcodeto", "finalzc", "finaltc",
    "service", "finalzcby", "finaltcby", "atpai_time", "notc", "city", "adcode", "standardization",
    "splitresult", "splittype", "groupids", "matchids", "filters", "adcodes", "keywords", "keys",
    "req_comp_name", "req_province", "req_city", "req_area", "re_body")
  //存放到mysql的未匹配数据
  val mysqlColumn: Array[String] = Array[String]("id", "type", "inc_day", "city", "adcode", "req_waybillno",
    "address_md5",
    "req_addresseeaddr", "req_comp_name", "req_addresseemobile", "gis_to_sys_src", "gis_to_sys_sssdeptcodeto",
    "finalzc", "finalzcby", "notc", "splitresult", "groupids", "matchids", "filters", "keyword",
    "unmatch_type")
  val unmatchType: Array[String] = Array[String]("", "filter为10、32或66", "groupid为单个", "groupid为多个",
    "地址非本市", "地址为0或1", "Auto识别", "地址为纯英文", "地址为数字、符号或空格", "地址编码返回结果有主体",
    "地址长度小于3", "切词包含POI", "切词包含路、巷、街、道", "切词包含村、社区", "切词包含开发区", "其他")
  // 生成的两种类型, 包含在json对象中
  val addNameArr = Array("unMatchType", "keyWord")

  val mysqlTable = "unmatch_data"
  val mysqlTableRecord = "empty_data_to_db_result"
  val delDays = 30
  val getKeyUrlPat = "http://10.119.72.207:8089/getkeyByNormSplit?split_terms=%s"
  //  val getKeyUrlPat = "http://10.202.43.228:3000/getkeyByNormSplit?split_terms=%s"
  val javaUtil = new JavaUtil(6) //6表示路由分单 1表示测试

  val cityMap: Map[String, ArrayBuffer[Array[String]]] = getCityMap
  val incDay: String = Util.dateDelta(-1, "")
  val appName = "UnMatchData"


  def main(args: Array[String]): Unit = {
    start()
  }

  def start(): Unit = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    //    conf.set("spark.executor.instances","30")
    //    conf.set("spark.executor.cores","4")
    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    unMatchDispatch(spark)
  }

  /**
   * 处理缺失数据
   *
   * @param spark : spark session
   */
  def unMatchDispatch(spark: SparkSession): Unit = {

    logger.error(">>>get unmatch data")
    val unMatchRdd = getUnMatchData(spark, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val dataCnt = unMatchRdd.count()
    logger.error(s">>>unmatch num ${dataCnt}")

    logger.error(">>>mark unmatch type")
    val keyId = BdpTaskRecordUtil.startRunNetworkInterface(spark,"0137443","225139","rds派件指标系统-缺失指标",
      "",getKeyUrlPat,"",dataCnt,60)
    val unMatchTypeRdd = markUnMatchType(unMatchRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(s">>>unmatch type num : ${unMatchTypeRdd.count()}")
    unMatchRdd.unpersist()

    logger.error(">>>save unmatch data start")
    saveUnMatchData(spark, unMatchTypeRdd, incDay)
    logger.error(">>>save unmatch data end")
    val unMatchStatRdd = unMatchTypeRdd.filter(obj => {
      //公司名为baison的为测试单
      !"baison".equals(obj.getString("req_comp_name"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(s">>>统计使用的缺失量 : ${unMatchStatRdd.count()}")
    unMatchTypeRdd.unpersist()
    logger.error(">>>保存到运营平台缺失表")
    //    insertIntoMysqlDb(unMatchStatRdd, incDay)
    insertIntoMysqlDbMuti(unMatchStatRdd, incDay)
    logger.error(">>>保存到运营平台缺失表完毕")
    logger.error(">>>stat idx")
    val unMatchIdxRdd = statUnMatchIdx(unMatchStatRdd)
    logger.error(s">>>idx num : ${unMatchIdxRdd.count()}")
    logger.error(">>>save idx start")
    saveUnMatchIdx(unMatchIdxRdd)
    logger.error(">>>save idx end")
    unMatchStatRdd.unpersist()
  }

  def saveUnMatchIdx(rdd: RDD[Obj.nonZcAddrObj]): Unit = {
    val conn = DbUtils.getConnection(javaUtil)
    val md5Instance = MD5Util.getMD5Instance
    val OMS_DLV_NONZCADDR = "OMS_DLV_NONZCADDR"
    try {
      val delNonZcSql = String.format(s"delete from $OMS_DLV_NONZCADDR where stat_date='%s'", incDay)
      logger.error(">>>保存之前，删除non zc addr一天的数据:" + delNonZcSql)
      DbUtils.executeSql(conn, delNonZcSql)

      val nonZcInsertSql = s"insert into $OMS_DLV_NONZCADDR (`id`, `stat_date`, `province`, `region`, `city`, `city_code`, `req`," +
        s"`addr_0_1`, `addr_ll3`, `addr_nsb`, `addr_en`, `other_city`, `key`, `filter_10_32_66`, `id_single`, `id_multi`, `poi`," +
        s"`split_9`, `split_6`,`auto`,`split_other`,`other`) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
      var nonZcParams: Array[Any] = null
      rdd.collect().foreach(o => {
        //计算md5值
        val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.city, o.city_code).mkString("_"))
        nonZcParams = Array(id, o.stat_date, o.province, o.region, o.city, o.city_code, o.req, o.addr_0_1, o.addr_ll_3,
          o.addr_nsb, o.addr_en, o.other_city, o.key, o.filter_10_32_66, o.id_single, o.id_multi, o.poi, o.split_9, o.split_6,
          o.auto_distinguish, o.split_development_zone, o.other)
        //        println("nonZcParams:"+nonZcParams.mkString(","))
        DbUtils.execute(conn, nonZcInsertSql, nonZcParams)
      })
      logger.error(">>>rcg指标入库结束！")
    } catch {
      case e: Exception => logger.error(">>>non zc指标入库失败！" + e)
    }
  }

  def statUnMatchIdx(unMatchTypeRdd: RDD[JSONObject]): RDD[Obj.nonZcAddrObj] = {
    val unMatchIdxRdd = unMatchTypeRdd.map(obj => {
      var req, addr_0_1, addr_ll_3, addr_nsb, addr_en, other_city, key, filter_10_32_66, id_single, id_multi, poi, split_9, split_6 = 0
      var auto_distinguish, split_development_zone, other = 0
      val unMatchType = obj.getString("unMatchType")

      req = 1
      if (Constant.ADDRESS_0_1.equals(unMatchType)) {
        addr_0_1 = 1
      } else if (Constant.SHORT_TEXT.equals(unMatchType)) {
        addr_ll_3 = 1
      } else if (Constant.ADDRESS_NUM_SYMB_BLANK.equals(unMatchType)) {
        addr_nsb = 1
      } else if (Constant.ADDRESS_ENG.equals(unMatchType)) {
        addr_en = 1
      } else if (Constant.ADDRESS_OTHER_CITY.equals(unMatchType)) {
        other_city = 1
      } else if (Constant.KEY_WORD_EXISTS.equals(unMatchType)) {
        key = 1
      } else if (Constant.NO_MATCH.equals(unMatchType)) {
        filter_10_32_66 = 1
      } else if (Constant.SINGLE_GROUP.equals(unMatchType)) {
        id_single = 1
      } else if (Constant.MULTI_GROUP.equals(unMatchType)) {
        id_multi = 1
      } else if (Constant.MARK_13.equals(unMatchType)) {
        poi = 1
      } else if (Constant.MARK_9.equals(unMatchType)) {
        split_9 = 1
      } else if (Constant.MARK_6.equals(unMatchType)) {
        split_6 = 1
      } else if (Constant.DEPT.equals(unMatchType)) {
        auto_distinguish = 1
      } else if (Constant.MARK_4.equals(unMatchType)) {
        split_development_zone = 1
      } else {
        other = 1
      }
      val statDate = incDay
      val cityCode = obj.getString("req_destcitycode")
      val cityTp = getCity(obj.getString("req_addresseeaddr"), cityCode)
      val province = cityTp._1
      val region = cityTp._2
      val city = cityTp._3
      (Array(statDate, city, cityCode).mkString("_"), Obj.nonZcAddrObj(statDate,
        province, region, city, cityCode, req, addr_0_1, addr_ll_3, addr_nsb, addr_en,
        other_city, key, filter_10_32_66, id_single, id_multi, poi, split_9, split_6,
        auto_distinguish, split_development_zone, other))
    }).reduceByKey((obj1, obj2) => {
      val statDate = obj1.stat_date
      val province = obj1.province
      val region = obj1.region
      val city = obj1.city
      val cityCode = obj1.city_code
      val req = obj1.req + obj2.req
      val addr_0_1 = obj1.addr_0_1 + obj2.addr_0_1
      val addr_ll_3 = obj1.addr_ll_3 + obj2.addr_ll_3
      val addr_nsb = obj1.addr_nsb + obj2.addr_nsb
      val addr_en = obj1.addr_en + obj2.addr_en
      val other_city = obj1.other_city + obj2.other_city
      val key = obj1.key + obj2.key
      val filter_10_32_66 = obj1.filter_10_32_66 + obj2.filter_10_32_66
      val id_single = obj1.id_single + obj2.id_single
      val id_multi = obj1.id_multi + obj2.id_multi
      val poi = obj1.poi + obj2.poi
      val split_9 = obj1.split_9 + obj2.split_9
      val split_6 = obj1.split_6 + obj2.split_6
      val auto_distinguish = obj1.auto_distinguish + obj2.auto_distinguish
      val split_development_zone = obj1.split_development_zone + obj2.split_development_zone
      val other = obj1.other + obj2.other
      Obj.nonZcAddrObj(statDate, province, region, city, cityCode, req, addr_0_1, addr_ll_3,
        addr_nsb, addr_en, other_city, key, filter_10_32_66, id_single, id_multi, poi, split_9, split_6,
        auto_distinguish, split_development_zone, other)
    }).values
    unMatchIdxRdd
  }

  /**
   * 创建sql前半部分
   *
   * @return
   */
  def createInsertPrePart(): String = {
    val insertSqlBuilder = new StringBuilder("insert into " + mysqlTable + "(")
    for (i <- mysqlColumn.indices) {
      insertSqlBuilder.append(mysqlColumn(i) + ",")
    }
    insertSqlBuilder.deleteCharAt(insertSqlBuilder.length - 1)
    insertSqlBuilder.append(") VALUES")
    insertSqlBuilder.toString()
  }

  def createInsertLastPart(): String = {
    val insertSqlBuilder = new StringBuilder(" ON DUPLICATE KEY UPDATE ")
    for (i <- mysqlColumn.indices) {
      if (!"id".equals(mysqlColumn(i))) {
        insertSqlBuilder.append(mysqlColumn(i) + "=VALUES(" + mysqlColumn(i) + "),")
      }
    }
    insertSqlBuilder.deleteCharAt(insertSqlBuilder.length - 1)
    insertSqlBuilder.toString()
  }

  /**
   * 插入到mysql数据库
   *
   * @param data
   * @return
   */
  def insertIntoMysqlDb(data: RDD[JSONObject], incDay: String): Unit = {

    //    val tmp = data.take(3)
    val conn = ManagerFactory.createManager(classOf[PrManager]).getConn
    //删除多少天的数据
    val dayDel = Util.dateDelta(0 - delDays, "")
    logger.error("删除过期数据:" + dayDel)
    DbUtils.executeSql(conn, "delete from " + mysqlTable + " where inc_day='" + dayDel + "'")
    logger.error("删除将要入库数据:" + incDay)
    DbUtils.executeSql(conn, "delete from " + mysqlTable + " where inc_day='" + incDay + "'")

    logger.error("开始入运营平台库:")
    val insertSqlPrePart = createInsertPrePart()
    val insertSqlLastPart = createInsertLastPart()
    val insertMidBuilder = new StringBuilder
    var count = 0
    data.collect().foreach(obj => {
      try {
        insertMidBuilder.append("(")
        for (j <- mysqlColumn.indices) {
          var value = ""
          if ("id".equals(mysqlColumn(j))) {
            var req_time = obj.getString("req_time")
            if (null == req_time) {
              req_time = ""
            }
            req_time = req_time.replaceAll("[- :]", "")
            value = obj.getString("req_waybillno") + "_" + req_time
          } else if ("keyword".equals(mysqlColumn(j))) {
            value = JSONUtil.getJsonVal(obj, "keyWord", "")
          } else if ("inc_day".equals(mysqlColumn(j))) {
            value = incDay
          } else if ("address_md5".equals(mysqlColumn(j))) {
            var tmp = obj.getString("req_addresseeaddr")
            if (tmp == null) {
              tmp = ""
            }
            value = tmp.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")
            value = MD5Util.getMD5(value)
          } else if ("unmatch_type".equals(mysqlColumn(j))) {
            val unmatch_type = JSONUtil.getJsonVal(obj, "unMatchType", "").replaceAll("[',\"]", "")
            val tmpIndex = convertToDigit(unmatch_type)
            if (tmpIndex == null || tmpIndex <= 0 || tmpIndex >= unmatchType.length) {
              value = unmatch_type
            } else {
              value = unmatchType(tmpIndex)
            }
            if (value == null) {
              value = ""
            }
          } else if ("city".equals(mysqlColumn(j))) {
            var tmp = obj.getString("req_destcitycode")
            if (tmp == null) {
              tmp = ""
            }
            value = tmp
          }
          else {
            var tmp = obj.getString(mysqlColumn(j))
            if (tmp == null) {
              tmp = ""
            }
            value = tmp
          }
          insertMidBuilder.append("'" + value.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "") + "',")
        }
        insertMidBuilder.deleteCharAt(insertMidBuilder.length - 1)
        insertMidBuilder.append(")")
        count = count + 1
        if (count % 5000 == 0) {
          logger.error(">>>count:" + count)
          val finalSql = insertSqlPrePart + insertMidBuilder.toString() + insertSqlLastPart
          DbUtils.executeSql(conn, finalSql)
          count = 0
          insertMidBuilder.clear()
        } else {
          insertMidBuilder.append(",")
        }
      } catch {
        case e: Exception => logger.error(">>>入mysql操作异常," + e)
      }
    })
    if (count != 0) {
      logger.error(">>>count:" + count)
      try {
        insertMidBuilder.deleteCharAt(insertMidBuilder.length - 1)
        val finalSql = insertSqlPrePart + insertMidBuilder.toString() + insertSqlLastPart
        DbUtils.executeSql(conn, finalSql)
      } catch {
        case e: Exception => logger.error(">>>入mysql操作异常," + e)
      }
    }
    conn.close()
    logger.error("入运营平台库完毕")
    logger.error("插入入库记录")
    val cities = data.map(obj => {
      obj.getString("city")
    }).distinct().collect()
    inserUnmatchRecord(cities, incDay)
    logger.error("插入入库记录完毕")
  }

  /**
   * 并发插入到mysql数据库,连接池不能序列化，需要要解决才行
   * Task not serializable
   * object not serializable (class: com.mchange.v2.c3p0.impl.NewProxyConnection, value: com.mchange.v2.c3p0.impl.NewProxyConnection@6f54d397)
   *
   * @param data
   * @return
   */
  def insertIntoMysqlDbMuti(data: RDD[JSONObject], incDay: String): Unit = {

    //    val tmp = data.take(3)
    val conn = ManagerFactory.createManager(classOf[PrManager]).getConn
    //删除多少天的数据
    val dayDel = Util.dateDelta(0 - delDays, "")
    logger.error("删除过期数据:" + dayDel)
    DbUtils.executeSql(conn, "delete from " + mysqlTable + " where inc_day='" + dayDel + "'")
    logger.error("删除将要入库数据:" + incDay)
    DbUtils.executeSql(conn, "delete from " + mysqlTable + " where inc_day='" + incDay + "'")
    conn.close()
    logger.error("开始入运营平台库:")
    val insertSqlPrePart = createInsertPrePart()
    val insertSqlLastPart = createInsertLastPart()

    data.repartition(10).foreachPartition(p => {
      try {
        var count = 0
        val conn1 = ManagerFactory.createManager(classOf[PrManager]).getConn
        val stmt = conn1.createStatement()
        val insertMidBuilder = new StringBuilder
        while (p.hasNext) {
          val obj = p.next()
          insertMidBuilder.append("(")
          for (j <- mysqlColumn.indices) {
            var value = ""
            if ("id".equals(mysqlColumn(j))) {
              var req_time = obj.getString("req_time")
              if (null == req_time) {
                req_time = ""
              }
              req_time = req_time.replaceAll("[- :]", "")
              value = obj.getString("req_waybillno") + "_" + req_time
            } else if ("keyword".equals(mysqlColumn(j))) {
              value = JSONUtil.getJsonVal(obj, "keyWord", "")
            } else if ("inc_day".equals(mysqlColumn(j))) {
              value = incDay
            } else if ("address_md5".equals(mysqlColumn(j))) {
              var tmp = obj.getString("req_addresseeaddr")
              if (tmp == null) {
                tmp = ""
              }
              value = tmp.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")
              value = MD5Util.getMD5(value)
            } else if ("unmatch_type".equals(mysqlColumn(j))) {
              val unmatch_type = JSONUtil.getJsonVal(obj, "unMatchType", "").replaceAll("[',\"]", "")
              val tmpIndex = convertToDigit(unmatch_type)
              if (tmpIndex == null || tmpIndex <= 0 || tmpIndex >= unmatchType.length) {
                value = unmatch_type
              } else {
                value = unmatchType(tmpIndex)
              }
              if (value == null) {
                value = ""
              }
            } else if ("city".equals(mysqlColumn(j))) {
              var tmp = obj.getString("req_destcitycode")
              if (tmp == null) {
                tmp = ""
              }
              value = tmp
            }
            else {
              var tmp = obj.getString(mysqlColumn(j))
              if (tmp == null) {
                tmp = ""
              }
              value = tmp
            }
            insertMidBuilder.append("'" + value.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "") + "',")
          }
          insertMidBuilder.deleteCharAt(insertMidBuilder.length - 1)
          insertMidBuilder.append(")")
          count = count + 1
          if (count % 5000 == 0) {
            logger.error(">>>count:" + count)
            val finalSql = insertSqlPrePart + insertMidBuilder.toString() + insertSqlLastPart
            stmt.execute(finalSql)
            count = 0
            insertMidBuilder.clear()
          } else {
            insertMidBuilder.append(",")
          }
        }
        if (count != 0) {
          logger.error(">>>count:" + count)
          try {
            insertMidBuilder.deleteCharAt(insertMidBuilder.length - 1)
            val finalSql = insertSqlPrePart + insertMidBuilder.toString() + insertSqlLastPart
            stmt.execute(finalSql)
            insertMidBuilder.clear()
          } catch {
            case e: Exception => logger.error(">>>入mysql操作异常," + e)
          }
        }
        conn1.close()
      } catch {
        case e: Exception => logger.error(">>>入mysql操作异常," + e)
      }
    })

    logger.error("入运营平台库完毕")
    logger.error("插入入库记录")
    val cities = data.map(obj => {
      obj.getString("city")
    }).distinct().collect()
    inserUnmatchRecord(cities, incDay)
    logger.error("插入入库记录完毕")
  }

  /**
   * 转数字
   *
   * @param str
   * @return
   */
  def convertToDigit(str: String): Integer = {
    if (str == null || str.isEmpty) {
      return null
    }
    try {
      return Integer.valueOf(str)
    } catch {
      case _: Exception => logger.error(str)
    }
    null
  }

  /**
   * 插入未匹配数据记录,用于aos下载
   *
   * @param cities
   * @param incDay
   */
  def inserUnmatchRecord(cities: Array[String], incDay: String): Unit = {
    val insertSqlBuilder = new StringBuilder(
      "insert into " + mysqlTableRecord + "(id,date,city_code,data_type,ip,result_file,result_path,exist_state,data_time) values")
    val conn = ManagerFactory.createManager(classOf[ProManager]).getConn
    //    logger.error("库配置：" + pro_db_property)
    for (i <- cities.indices) {
      val idStr = Array(cities(i), incDay, "zc_miss", "", "").mkString("_")
      val id = MD5Util.getMD5(idStr)
      insertSqlBuilder.append("('" + id + "','" + incDay + "','" + cities(i) + "','zc_miss','','','',1,'" + incDay + "'),")
    }
    insertSqlBuilder.deleteCharAt(insertSqlBuilder.length - 1)
    DbUtils.executeSql(conn, insertSqlBuilder.toString())
    conn.close()
  }

  /**
   * 保存数据到hive
   *
   * @param spark
   * @param unMatchTypeRdd
   * @param incDay
   */
  def saveUnMatchData(spark: SparkSession, unMatchTypeRdd: RDD[JSONObject], incDay: String): Unit = {
    val rows = unMatchTypeRdd.map(obj => {
      val rowBuilder = new StringBuilder
      for (name <- nameArr) {
        var tmp = obj.getString(name)
        if (tmp == null) {
          tmp = ""
        }
        rowBuilder.append(tmp.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")).append("\t")
      }
      for (i <- addNameArr.indices) {
        if (i != addNameArr.length - 1) rowBuilder.append(JSONUtil.getJsonVal(obj, addNameArr(i), "").replaceAll("[\\r\\n\\t,\\\\]", "")).append("\t")
        else rowBuilder.append(JSONUtil.getJsonVal(obj, addNameArr(i), "").replaceAll("[',\",\\r,\\n,\\t,\\\\]", ""))
      }
      rowBuilder.toString()
    }).repartition(1)
    spark.sql("use dm_gis")
    val table = "gis_rds_omsto_gis_unmatch"
    val dropSql = String.format("alter table %s drop if exists partition(inc_day = '%s')", table, incDay)
    spark.sql(dropSql)
    ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R /user/hive/warehouse/dm_gis.db/%s/inc_day=%s", table, incDay))
    rows.saveAsTextFile(String.format("/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", table, incDay))
    val addSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
    spark.sql(addSql)
  }

  /**
   * 查询缺失数据
   *
   * @param spark  : spark session
   * @param incDay : 日期
   * @return
   */
  def getUnMatchData(spark: SparkSession, incDay: String): RDD[JSONObject] = {
    val dataBaseName = "dm_gis"
    val hiveTableName = "gis_rds_omsto"
    logger.error(">>>dataBaseName：" + dataBaseName + ",hiveTableName:" + hiveTableName)
    spark.sql(s"""use $dataBaseName""") //hive中的dm_gis库
    val sql =
      s"""select * from(
         |select type, req_time, req_addresseephone, req_addresseemobile, req_addresseeaddr,
         | req_destcitycode, req_waybillno, re_addresseedeptcode, re_addresseeteamcode,
         | gis_to_sys_time, gis_to_sys_teamtoretby, gis_to_sys_gisteamcodeto, gis_to_sys_src,
         | gis_to_sys_gisdeptcodeto, gis_to_sys_groupid, gis_to_sys_depttoretby, gis_to_sys_sssdeptcodeto,
         | finalzc, finaltc, service, finalzcby, finaltcby, atpai_time, notc, city, adcode, standardization,
         | splitresult, splittype, groupids, matchids, filters, adcodes, keywords, keys, req_comp_name,
         | req_province, req_city, req_area,re_body,inc_day,row_number() over(partition BY req_waybillno
         | order by req_time desc ) as rank from $hiveTableName where inc_day = '$incDay'
         | )a where a.rank=1 and a.gis_to_sys_gisdeptcodeto = '' """.stripMargin
    logger.error(">>>unmatch sql :" + sql)
    val rdd = spark.sql(sql).rdd.repartition(800).map(row => {
      val obj = new JSONObject()
      for (i <- nameArr.indices)
        obj.put(nameArr(i), row.getString(i))
      val ks_flag = checkKs(obj)

      (ks_flag, obj)
    }).filter(_._1 == 0).values
    rdd
  }

  /** *
   * 是否ks识别网点
   *
   * @param obj
   * @return
   */
  def checkKs(obj: JSONObject): Int = {
    var ks_flag = 0
    try {
      val re_body = obj.getString("re_body")
      if (re_body != null && !re_body.isEmpty) {
        val re_body_array = JSON.parseArray(re_body)
        if (re_body_array.size() != 0) {
          var re_body: JSONObject = null
          for (i <- 0 until re_body_array.size()) {
            val tmp_re_body = re_body_array.getJSONObject(i)
            if (re_body == null) {
              re_body = tmp_re_body
            } else {
              if (re_body.getString("datetime") < tmp_re_body.getString("datetime")) {
                re_body = tmp_re_body
              }
            }
          }
          val addresseeDeptCode = re_body.getString("addresseeDeptCode")
          val src = re_body.getString("src")
          if ("ks".equals(src) && addresseeDeptCode != null && !addresseeDeptCode.isEmpty) {
            ks_flag = 1
          }
        }
      }
    } catch {
      case e: Exception =>
    }
    ks_flag
  }

  /**
   * 分流缺失数据
   *
   * @param rdd : 数据rdd
   * @return
   */
  def markUnMatchType(rdd: RDD[JSONObject]): RDD[JSONObject] = {
    val city2CityCodeMap = City2AdcodeMap.getCity2CityCodeMap
    val unMatchRdd = rdd.map(obj => {
      val typeTp = markUnMatchType(obj, city2CityCodeMap)
      obj.put("unMatchType", typeTp._1)
      obj.put("keyWord", typeTp._2)
      obj
    })
    unMatchRdd
  }

  def markUnMatchType(obj: JSONObject, city2CityCodeMap: util.HashMap[String, String]): (String, String) = {
    val filterSet = JSONUtil.getJsonVal(obj, "filters", "").split(Constant.SEP).toSet.-("")
    val groupIdSet = JSONUtil.getJsonVal(obj, "groupids", "").split(Constant.SEP).toSet.-("")
    val address = obj.getString("req_addresseeaddr")
    val cityCode = obj.getString("req_destcitycode")
    val splitResult = obj.getString("splitresult")
    var keyWord: String = null
    var _type: String = null

    _type = markByFilter(filterSet, groupIdSet)
    if (_type != null)
      return (_type, keyWord)

    _type = markByAddress(address, cityCode)
    if (_type != null)
      return (_type, keyWord)

    _type = markByCity(splitResult, cityCode, city2CityCodeMap)
    if (_type != null)
      return (_type, keyWord)

    val typeTp = markByKeyWord(splitResult)
    _type = typeTp._1
    keyWord = typeTp._2
    if (_type != null)
      return (_type, keyWord)

    _type = markBySplitType(address, splitResult)


    (_type, keyWord)
  }

  /**
   * 根据filter判断缺失类型
   *
   * @param filterSet  : 过滤set
   * @param groupIdSet : 大组et
   * @return
   */
  def markByFilter(filterSet: Set[String], groupIdSet: Set[String]): String = {
    if (groupIdSet.nonEmpty && (filterSet.contains("10") || filterSet.contains("32") || filterSet.contains("66"))) {
      return Constant.NO_MATCH //未识别
    } else if (filterSet.contains("1") || filterSet.contains("2") || filterSet.contains("8")) {
      if (groupIdSet.size == 1)
        return Constant.SINGLE_GROUP //单groupid
      else if (groupIdSet.size > 1)
        return Constant.MULTI_GROUP //多groupid
    }
    null
  }

  /**
   * 根据地址判断未缺失类型
   *
   * @param address  : 地址
   * @param cityCode : 城市代码
   * @return
   */
  def markByAddress(address: String, cityCode: String): String = {
    if (Set("0", "1").contains(address)) { //0或1
      return Constant.ADDRESS_0_1
    } else if (address.matches(String.format("%s[a-zA-Z]+\\d*", cityCode))) { //网点
      return Constant.DEPT
    } else if (address.matches("^((?![\\u4e00-\\u9fa5]).)*[a-zA-Z]((?![\\u4e00-\\u9fa5]).)*$")) { //英文地址
      return Constant.ADDRESS_ENG
    } else if ("".equals(address) || address.matches("^[^\\u4e00-\\u9fa5]*$")) { //数字或空格或符号
      return Constant.ADDRESS_NUM_SYMB_BLANK
    }
    null
  }

  /**
   * 判断是否其他城市地址
   *
   * @param splitResult : 分词结果
   * @param cityCode    : 城市代码
   * @return
   */
  def markByCity(splitResult: String, cityCode: String, city2CityCodeMap: util.HashMap[String, String]): String = {
    var city: String = null
    val splitTmps = splitResult.split(";")
    try {
      if (!"".equals(splitResult) && splitTmps.nonEmpty) {
        val loop = new Breaks
        loop.breakable(
          for (term <- splitTmps(0).split("\\|")) {
            val keyLevel = term.split("\\^")
            val key = keyLevel(0)
            val level = keyLevel(1).substring(1)
            if ("2".equals(level)) { //获取分词中的城市
              city = key
              loop.break()
            }
          }
        )
      }
    } catch {
      case e: Exception => logger.error(splitResult, e)
    }
    val cityCode2 = city2CityCodeMap.get(city)
    if (cityCode2 != null && !cityCode2.equals(cityCode)) //地址中的城市和城市代码不一致
      return Constant.ADDRESS_OTHER_CITY
    null
  }


  /**
   * 根据主题判断缺失类型
   *
   * @param splitResult : 分词结果
   * @return
   */
  def markByKeyWord(splitResult: String): (String, String) = {
    val splitTmps = splitResult.replaceAll("\\|", ",").split(";")
    if (splitTmps.length != 2)
      return (null, "")
    val getKeyUrl = String.format(getKeyUrlPat, URLEncoder.encode(splitTmps(0), "UTF-8"))
    val re = HttpConnection.sendGet(getKeyUrl)
    val keyContent = re.get("content")
    var keyWord: String = null
    if (keyContent != null && !"".equals(keyContent)) {
      try {
        val jsonObj = JSON.parseObject(keyContent)
        keyWord = jsonObj.getString("key_word")
      } catch {
        case e: Exception => logger.error(e)
      }
    }
    if (keyWord != null && !"".equals(keyWord))
      (Constant.KEY_WORD_EXISTS, keyWord)
    else
      (null, keyWord)
  }

  def markBySplitType(address: String, splitResult: String): String = {
    if (address.length <= 3) {
      return Constant.SHORT_TEXT
    }
    try {
      val set = new util.HashSet[String]()
      val splitTmps = splitResult.split(";")
      if (!"".equals(splitResult) && splitTmps.nonEmpty) {
        for (term <- splitTmps(0).split("\\|")) {
          val keyLevel = term.split("\\^")
          //noinspection ScalaUnusedSymbol
          val key = keyLevel(0)
          val level = keyLevel(1).substring(1)
          set.add(level)
        }
      }
      if (set.contains("13"))
        return Constant.MARK_13
      else if (set.contains("9"))
        return Constant.MARK_9
      else if (set.contains("6"))
        return Constant.MARK_6
      else if (set.contains("4"))
        return Constant.MARK_4
    } catch {
      case _: Exception => logger.error(splitResult)
    }

    Constant.MARK_OTHER
  }

  def getCityMap: Map[String, ArrayBuffer[Array[String]]] = {
    logger.error(">>>javaUtil：" + javaUtil.getFlag)
    val conn = DbUtils.getConnection(javaUtil)
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("province", "region", "city", "citycode")
    val regionSelectSql = s"select province,region,city,citycode from $regoinCityTable"
    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val citycode = arr(3).toString
      if (cityMap.contains(citycode)) {
        val cityCodeList = cityMap.apply(citycode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (citycode -> cityCodeList)
      }
    }
    cityMap
  }

  def getCity(address: String, cityCode: String): (String, String, String) = {
    var flag = false
    var _province = "-"
    var _region = "-"
    var _city = "-"
    if (cityMap.contains(cityCode)) {
      flag = true
      val cityList: ArrayBuffer[Array[String]] = cityMap.apply(cityCode)
      _province = cityList(0)(0)
      _region = cityList(0)(1)
      if (cityList.length == 1) {
        //如果只有一个list，一一对应的，直接返回
        _city = cityList(0)(2)
      } else if (cityList.length > 1) {
        //一个城市代码对应多个城市
        for (cityObj <- cityList) {
          val city = cityObj(2)
          val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
          if (address.contains(city) || address.contains(city1)) {
            _city = city
          }
        }
      }
    }
    (_province, _region, _city)
  }
}
