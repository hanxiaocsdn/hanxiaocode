package com.sf.gis.scala.oms_shou.pojo.rds;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/3/26.
 */
public class Tcs implements Serializable {
    private Other other;
    private int flag;
    private String notc;
    private String src;
    private String groupid;
    private String dept;
    private String team;
    private String aoiid;
    private String aoicode;
    private String atAoiSrc;
    private String atDeptSrc;
    private String atTeamSrc;

    public String getAtAoiSrc() {
        return atAoiSrc;
    }

    public void setAtAoiSrc(String atAoiSrc) {
        this.atAoiSrc = atAoiSrc;
    }

    public String getAtDeptSrc() {
        return atDeptSrc;
    }

    public void setAtDeptSrc(String atDeptSrc) {
        this.atDeptSrc = atDeptSrc;
    }

    public String getAtTeamSrc() {
        return atTeamSrc;
    }

    public void setAtTeamSrc(String atTeamSrc) {
        this.atTeamSrc = atTeamSrc;
    }

    public String getAoicode() {
        return aoicode;
    }

    public void setAoicode(String aoicode) {
        this.aoicode = aoicode;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public Other getOther() {
        return other;
    }

    public void setOther(Other other) {
        this.other = other;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getNotc() {
        return notc;
    }

    public void setNotc(String notc) {
        this.notc = notc;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }
}
