/*
package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

import java.io.{BufferedReader, InputStream, InputStreamReader}
import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_pai.index.oms_realtime.Obj
import com.sf.gis.scala.utils.NormalizerUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
 * Created by 01368078 on 2019/2/28.
 */
object MatchFreq {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def freqData(spark: SparkSession, rdd: RDD[JSONObject], dateArray: Array[String]): Unit = {
    val cityCode2AdcodeMap = cityCode2Adcode()
    println(cityCode2AdcodeMap)
    val freqRdd = rdd.filter(obj=>{
      val incDay = JSONUtil.getJsonVal(obj, "oms_body.inc_day", "")
      dateArray(dateArray.length - 1).equals(incDay)
    }).map(obj => {
      val src = JSONUtil.getJsonVal(obj, "oms_body.lib_src", "")
      if ("norm".equals(src) || "chkn".equals(src) || "chke".equals(src)) {
        val gisStatus = JSONUtil.getJsonVal(obj, "oms_body.gis_status", "")
        val cityCode = JSONUtil.getJsonVal(obj, "oms_body.city_code", "")
        val address = JSONUtil.getJsonVal(obj, "oms_body.req_addresss", "")
        val dept = JSONUtil.getJsonVal(obj, "oms_body.gis_dept", "")
        val team = JSONUtil.getJsonVal(obj, "oms_body.gis_tc", "")
        val groupId = JSONUtil.getJsonVal(obj, "oms_body.gis_to_sys_groupid", "")
        var normAddr = JSONUtil.getJsonVal(obj, "oms_body.standardization", "")
        val incDay = JSONUtil.getJsonVal(obj, "oms_body.inc_day", "")
        val matchTime = JSONUtil.getJsonVal(obj, "oms_body.req_time", "")
        val dlvDept = JSONUtil.getJsonVal(obj, "dlv_body.dlv_dept", "")
        val empCode = JSONUtil.getJsonVal(obj, "dlv_body.courier_code", "")

        var addressId = ""
        if ("norm".equals(src)) {
          addressId = groupId
        } else if ("chkn".equals(src) || "chke".equals(src)) {
          val adcode = cityCode2AdcodeMap.get(cityCode)
          if (adcode != null && !"".equals(cityCode)) {
            val normRet = NormalizerUtil.doNormal(adcode.toInt, cityCode.toInt, address)
            if (normRet != null)
              normAddr = normRet.getAddress
            addressId = MD5Util.getMD5(normRet.getAddress)
          }
        }
        val key = cityCode + "_" + src + "_" + addressId + "_" + dept + "_" + team + "_" + incDay
        val matchFreq = 1
        val errorFreq = if (!"1".equals(gisStatus)) 1 else 0
        (key, Obj.freqObj(key, addressId, normAddr, matchFreq, src, dept, team, matchTime, matchTime, errorFreq, dlvDept, empCode, cityCode, incDay))

      } else {
        null
      }
    }).filter(_ != null).reduceByKey((obj1, obj2) => {
      val matchFreq = obj1.match_freq + obj2.match_freq
      val errorFreq = obj1.error_freq + obj2.error_freq
      val firstMatchTime = minTime(obj1.first_match_time, obj2.first_match_time)
      val lastMatchTime = maxTime(obj1.first_match_time, obj2.first_match_time)
      val dept80 = comb(obj1.dept80, obj2.dept80)
      val empCode80 = comb(obj1.empcode80, obj2.empcode80)
      Obj.freqObj(obj1.key, obj1.address_id, obj1.address, matchFreq, obj1.src, obj1.dept, obj1.team,
        firstMatchTime, lastMatchTime, errorFreq, dept80, empCode80, obj1.citycode, obj1.inc_day)
    }).values
//      .persist(StorageLevel.DISK_ONLY)
    saveFreq(spark, freqRdd, dateArray)
  }


  def saveFreq(spark: SparkSession, freqRdd: RDD[Obj.freqObj], dateList: Array[String]): Unit = {
    val structFileds = new util.ArrayList[StructField]()
    val structs = Array("key", "address_id", "address", "match_freq", "src", "dept", "team", "first_match_time",
      "last_match_time", "error_freq", "dept80", "empcode80", "citycode")
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    //2 构建StructType用于DataFrame的元数据描述
    val structType = DataTypes.createStructType(structFileds)
    spark.sql("use dm_gis")
    val statDate = dateList(dateList.length - 1)
//    for (statDate <- dateList) {
    val dateRdd = freqRdd
//      val dateRdd = freqRdd.filter(freqObj => {
//        statDate.equals(freqObj.inc_day)
//      }).persist(StorageLevel.DISK_ONLY)
//      logger.error(">>>" + statDate + "频次数据量：" + dateRdd.count() + ",数据入库中----------------------------------")
      val rowRdd = dateRdd.map(obj => {
        var row: Row = null
        try {
          val dept80 = obj.dept80
          val empCode80 = obj.empcode80
          row = RowFactory.create(obj.key, obj.address_id, obj.address, obj.match_freq.toString, obj.src, obj.dept, obj.team, obj.first_match_time,
            obj.last_match_time, obj.error_freq.toString, dept80, empCode80, obj.citycode)
        } catch {
          case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
        }
        row
      }).filter(_ != null).repartition(50)
      val df: DataFrame = spark.createDataFrame(rowRdd, structType)
      //5 基于Datarame创建临时表
      val table = "gis_pai_addr_freq_stat"
      val tempView = String.format("%s_temp_view", table)
      df.createOrReplaceTempView(tempView)
      val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, statDate)
      logger.error(">>>删除分区：" + deleteSql)
      spark.sql(deleteSql)
      val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, statDate)
      logger.error(">>>新建分区：" + createPartitionSql)
      spark.sql(createPartitionSql)
      //7 把临时表的数据刷进hive表中
      spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, statDate, tempView))
//    }
  }

  def comb(str1: String, str2: String): String = {
    val deptSet = new util.HashSet[String]()
    for (str <- str1.split("\\|"))
      if (!"".equals(str))
        deptSet.add(str)
    for (str <- str2.split("\\|"))
      if (!"".equals(str))
        deptSet.add(str)
    deptSet.mkString("|")
  }

  def minTime(time1: String, time2: String): String = {
    if (time1 <= time2)
      time1
    else
      time2
  }

  def maxTime(time1: String, time2: String): String = {
    if (time1 >= time2)
      time1
    else
      time2
  }

  def cityCode2Adcode(): java.util.HashMap[String, String] = {
    val map = new java.util.HashMap[String, String]
    var in: InputStream = null
    var isr: InputStreamReader = null
    var br: BufferedReader = null
    try {
      in = WrongDispatchDayMain.getClass.getClassLoader.getResourceAsStream("conf/oms_pai/city_code.properties")
      isr = new InputStreamReader(in, "UTF-8") //解决读取中文出现乱码

      br = new BufferedReader(isr)
      var line = br.readLine
      while (line != null) {
        val strs = line.split(",")
        val adcode = strs(1)
        val cityCode = strs(3)
        map.put(cityCode, adcode)
        line = br.readLine()
      }
    } catch {
      case e: Exception => logger.error("load citycode to adcode error", e)
    }
    if (br != null) br.close()
    if (isr != null) isr.close()
    if (in != null) in.close()
    map
  }
}
*/
