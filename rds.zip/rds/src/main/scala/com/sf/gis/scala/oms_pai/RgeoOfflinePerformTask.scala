package com.sf.gis.scala.oms_pai

import java.sql.{Connection, DriverManager}

import com.sf.gis.scala.base.util.DateUtil
import com.sf.gis.scala.oms_pai.handle.{AnalysisIndex, ParseLog, StoreIndex}
import com.sf.gis.scala.oms_pai.obj.Case.{ReDataDayFinal, ReqDataDayFinal, ReqDataMin}
import com.sf.gis.scala.oms_pai.start.JavaUtil
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
 * Created by 01375125 on 2018/9/27.
 * 逆地理编码离线性能指标统计
 */
object RgeoOfflinePerformTask {
  val appName = this.getClass.getSimpleName.replace("$", "")
  @transient lazy val logger = Logger.getLogger(appName)


  def main(args: Array[String]): Unit = {
    if (args.length == 0) {
      //代码内部传入日期参数
      val date = DateUtil.getDateStr(-1)
      start(date)
    } else if (args.length == 1) {
      //传入参数，单天任务
      val date = args(0)
      start(date)
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      val startDate = args(0)
      val endDate = args(1)
      batchTask(startDate, endDate)
    }

  }

  /**
   * 批量任务
   *
   * @param startDate
   * @param endDate
   */
  def batchTask(startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      start(date)
    }
  }

  /**
   * 开始任务
   */
  def start(inc_day: String): Unit = {
    val hdfs = "hdfs://stream/user/mario/warehouse/ods_kafka_gis/gis_rss_rgeo_cloud_pri_collect/%s"
    var rgeoLogRdd: RDD[String] = null

    //    var inc_day = "2018-10-13"
    var hdfsPath: String = null
    //生产环境
    if (JavaUtil.EN == 1) {
      hdfsPath = String.format(hdfs, inc_day.replaceAll("-", ""))
      //      hdfsPath = String.format(hdfs, inc_day.replaceAll("-", ""),"partition_9_1539433115305.snappy")
      val spark = SparkSession.builder().config(getConf()).enableHiveSupport().getOrCreate()
      rgeoLogRdd = spark.sparkContext.textFile(hdfsPath)
      spark.sparkContext.setLogLevel("ERROR")
    } else {
      hdfsPath = "E:\\demand\\rgeo\\log\\rgeo_20200326_log.csv"
      //      hdfsPath = String.format(hdfs, inc_day.replaceAll("-", ""),"partition_9_1539433115305.snappy")
      val spark = SparkSession.builder().config(getConf()).getOrCreate()
      rgeoLogRdd = spark.sparkContext.textFile(hdfsPath)
      spark.sparkContext.setLogLevel("ERROR")
    }

    //执行解析处理
    logger.error(">>>解析的日志日期：" + inc_day + "------------------------------------------------")
    logger.error(">>> hdfs路径>>>" + hdfsPath + ", appName>>>" + appName)
    handleTask(rgeoLogRdd: RDD[String], inc_day: String)
  }

  /**
   * 配置
   *
   * @return
   */
  def getConf(): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
    if (JavaUtil.EN == 2) conf.setMaster("local[*]")
    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    conf.set("spark.executor.instances", "10")
    conf.set("spark.executor.memory", "20g")
    conf
  }

  /**
   * 处理任务
   */
  def handleTask(rgeoLogRdd: RDD[String], inc_day: String): Unit = {
    logger.error(">>>读取" + inc_day + "号数据量：" + rgeoLogRdd.count() + ",解析日志...")
    rgeoLogRdd.take(1).foreach(println)
    val (reqRdd, reRdd) = ParseLog.parseLog(rgeoLogRdd, inc_day)
    logger.error(">>>统计指标...")
    val statIndex = AnalysisIndex.stat(reqRdd, reRdd)

    logger.error(">>>统计指标入mysql数据库...")
    StoreIndex.storeIndex(statIndex: (RDD[ReqDataMin], RDD[ReqDataDayFinal], RDD[ReDataDayFinal]), inc_day, getConnection)
    logger.error(">>>The End!")

  }

  def getConnection: Connection = {
    Class.forName("com.mysql.jdbc.Driver").newInstance()
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rgeo?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8mb4&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"
    @transient val connection = DriverManager.getConnection(url, "gis_oms_rgeo", "gis_oms_rgeo@123@")
    connection
  }

}
