//package com.sf.gis.scala.utils;
//
//import com.alibaba.druid.pool.DruidDataSource;
//
//import com.sf.gis.scala.oms_pai.start.JavaUtil;
//import org.apache.log4j.Logger;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * Created by 01375125 on 2018/9/27.
// * 数据库工具类
// */
//public class DbUtil {
//    static Logger logger = Logger.getLogger(DbUtil.class);
//
//    private static final String Driver = JavaUtil.getString("oms.mysql.driver");
//    private static final String URL = JavaUtil.getString("oms.mysql.url");
//    private static final String USERNAME = JavaUtil.getString("oms.mysql.uid");
//    private static final String PASSWORD = JavaUtil.getString("oms.mysql.pwd");
//
//    private static DruidDataSource dataSource = null;
//    static{
//        dataSource = new DruidDataSource();
//        dataSource.setDriverClassName(Driver);
//        dataSource.setUrl(URL);
//        dataSource.setUsername(USERNAME);
//        dataSource.setPassword(PASSWORD);
//        dataSource.setMaxActive(20);
//        dataSource.setRemoveAbandoned(false);
//    }
//
//
//    /**
//     * 获取数据库连接
//     * @return Connection:
//     */
//    public static  Connection getConn(){
//        Connection conn = null;
//        try {
//            conn = dataSource.getConnection();
//        } catch (Exception e) {
//            logger.error("数据库连接出错,driver=>" + Driver + ",url=>" + URL + ",username=>" + USERNAME + ",password=>" + PASSWORD,e);
//        }
//
//        return conn;
//    }
//
//
//    /**
//     * 执行查询
//     */
//    public static List<String[]> query(Connection conn,String sql,String [] params,String [] columns){
//        List<String[]> rows = new ArrayList<>();
//        String [] row;
//        PreparedStatement pst;
//        try {
//            pst = conn.prepareStatement(sql);
//            //noinspection StatementWithEmptyBody
//            if(params.length>0){}
//            for (int i = 0; i <params.length ; i++) {
//                pst.setString(i+1,params[i]);
//            }
//            ResultSet rs = pst.executeQuery();
//            while(rs.next()){
//                row = new String[columns.length];
//                for (int i = 0; i < row.length; i++) {
//                    Object field = rs.getObject(columns[i]);
//                    if(field != null){
//                        row[i] = field.toString();
//                    }else{
//                        row[i] = "";
//                    }
//
//                }
//                rows.add(row);
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return rows;
//    }
//
//    /**
//     * 执行查询
//     */
//    public static List<List<String>> query1(Connection conn,String sql,String [] params,String [] columns){
//        List<List<String>> rows = new ArrayList<>();
//        List<String> row;
//        PreparedStatement pst;
//        try {
//            pst = conn.prepareStatement(sql);
//            if(params!=null){
//                for (int i = 0; i <params.length ; i++) {
//                    pst.setString(i+1,params[i]);
//                }
//            }
//
//            ResultSet rs = pst.executeQuery();
//            while(rs.next()){
//                row = new ArrayList<>(columns.length);
//                for (String column : columns) {
//                    Object field = rs.getObject(column);
//                    if (field != null) {
//                        row.add(field.toString());
//                    } else {
//                        row.add("");
//                    }
//
//                }
//                rows.add(row);
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return rows;
//    }
//
//
//    /**
//     * 执行插入
//     */
//    public void insert(){
//
//    }
//
//    /**
//     * 执行更新
//     */
//    public void update(){
//
//    }
//
//
//    public static void main(String[] args) {
//        test();
//    }
//
//    public static void test(){
//
//        Connection conn = getConn();
//
//        String [] columns = new String[]{"date","citycode","req_cnt","tc_awsm","tc_awsm_ret","tc_awsm_suc"};
//        String [] params = new String[]{"all","all","all"};
//        String  sql = "SELECT date,citycode,deptcode,Sum(req_cnt) req_cnt,Sum(tc_arss_match) tc_awsm,SUM(tc_arss_ret) tc_awsm_ret,SUM(tc_suc_arss) tc_awsm_suc FROM rds_oms_index_day_waybillno where groupid=? and teamcode=? and deptcode!=?   GROUP BY deptcode ORDER BY tc_awsm desc;";
//        String  sql1 = "SELECT date,citycode,deptcode,Sum(req_cnt) req_cnt,Sum(tc_arss_match) tc_awsm,SUM(tc_arss_ret) tc_awsm_ret,SUM(tc_suc_arss) tc_awsm_suc FROM rds_oms_index_day_waybillno where groupid='%s' and teamcode='%s' and deptcode!='%s'   GROUP BY deptcode ORDER BY tc_awsm desc;";
//        //noinspection UnusedAssignment
//        sql1 = String.format(sql1,"all","all","all");
//        System.out.println("sql:"+sql);
//        List<List<String>> rows = query1(conn, sql, params, columns);
//        System.out.println(rows);
//    }
//
//
//}
