package com.sf.gis.scala.oms_pai.index.oms_realtime

import org.apache.log4j.Logger

/**
  * Created by 01375125 on 2018/12/4.
  */
object OmsQuery {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {

  }

  def selectTable(): Unit ={
    val sql = "select * from "
  }

}
