package com.sf.gis.scala.oms_pai.db;

import java.sql.Connection;


public interface IManager {
    public Connection getConn();
}
