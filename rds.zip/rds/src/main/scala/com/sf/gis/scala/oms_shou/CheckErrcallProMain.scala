package com.sf.gis.scala.oms_shou

import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil, JSONUtil}
import com.sf.gis.scala.utils.TcUtils
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01375125 on 2019/11/19.
 */
object CheckErrcallProMain {
  private val appName: String = this.getClass.getSimpleName.replace("$", "")
  private val logger = LoggerFactory.getLogger(appName)
  //  var groupid_url = "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?cityCode=%s&addressId=%s&ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1"
  var groupid_url = "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?cityCode=%s&addressId=%s"

  def main(args: Array[String]): Unit = {
    start(args)
  }

  def start(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName(appName)
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("error")
    if (args.length == 0) {
      //代码内部获取日期参数
      val date = DateUtil.getToday
      handleTask(spark, date)
    } else if (args.length == 1) {
      //传入参数，单天任务
      val date = args(0)
      handleTask(spark, date)
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      val startDate = args(0)
      val endDate = args(1)
      batchTask(spark, startDate, endDate)
    }
    spark.stop()
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      handleTask(spark, date)
    }
  }

  def handleTask(spark: SparkSession, date: String): Unit = {
    logger.error(">>>处理" + date + "号的数据，appName=" + appName + "--------------------------------")
    logger.error(">>>获取数据源")
    val sourceRdd = getSourceRdd(spark, date).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>获取数据量：" + sourceRdd.count())
    sourceRdd.take(1).foreach(println)
    logger.error(">>>求地址频次并过滤数据")
    val pcRdd = statFilterData(sourceRdd, date)
    logger.error(">>获取标准库数据")
    val normLibRdd = getNormLibRdd(spark).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>获取标准库数据量：" + normLibRdd.count())
    normLibRdd.take(1).foreach(println)
    logger.error(">>>关联标准库数据，获取right_tc字段")
    val normResultRdd = pcRdd.map(json => {
      val groupid = json.getString("groupid")
      val city = json.getString("city")
      ((groupid, city), json)
    }).leftOuterJoin(normLibRdd).map(obj => {
      val json = obj._2._1
      val normObj = obj._2._2
      if (normObj.nonEmpty) {
        val right_tc = normObj.get
        if (TcUtils.matchTc(right_tc)) json.put("st_tc", right_tc)
      }
      val norm_address = json.getString("norm_address")
      (norm_address, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>关联标准库数据：" + normResultRdd.count())
    normResultRdd.take(1).foreach(println)
    pcRdd.unpersist()
    normLibRdd.unpersist()

    val hasSttcCount = normResultRdd.filter(obj => {
      val json = obj._2
      val st_tc = json.getString("st_tc")
      st_tc != null && st_tc != ""
    }).count()
    logger.error(">>>关联标准库后获取到有st_tc的数据量：" + hasSttcCount)

    logger.error(">>>获取仓管审补库数据")
    val checkRdd: RDD[(String, JSONObject)] = getCheckRdd(spark, date)

    logger.error(">>关联审补库，获取chkn_tc字段")
    val chknResultRdd = normResultRdd.leftOuterJoin(checkRdd).map(obj => {
      val json = obj._2._1
      val checkObj = obj._2._2
      if (checkObj.nonEmpty) {
        val checkJson = checkObj.get
        val chkn_tc = checkJson.getString("chkn_tc")
        if (TcUtils.matchTc(chkn_tc)) checkJson.put("chkn_tc", chkn_tc)
      }
      json
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    chknResultRdd.take(1).foreach(println)

    val hasChkntcCount = chknResultRdd.filter(json => {
      val chkn_tc = json.getString("chkn_tc")
      chkn_tc != null && chkn_tc != ""
    }).count()
    logger.error(">>>关联审补库后获取到有chkn_tc的数据量：" + hasChkntcCount)

    logger.error(">>>通过groupid获取标准库信息")
    val resultRdd = chknResultRdd.map(json => {
      val groupid = json.getString("groupid")
      (groupid, json)
    }).groupByKey().flatMap(obj => {
      val list = obj._2.toList
      val headJson = list.head
      val (oldJson, newJson) = accessNormByGroupid(headJson)
      if (newJson != null) {
        val newList = new ArrayBuffer[JSONObject]()
        for (json <- list) {
          newList += json
        }
        newList += newJson
        newList
      } else {
        list
      }
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(">>>调用完groupid后的数据量：" + resultRdd.count())
    normResultRdd.unpersist()
    checkRdd.unpersist()

    logger.error(">>>数据入库")
    saveDataToHive(resultRdd, spark, date)
    logger.error(">>>数据入库结束！")
  }


  /**
   * 将调用后的数据保存在hive中
   *
   * @param inputRdd
   * @param spark
   * @param date
   */
  def saveDataToHive(inputRdd: RDD[JSONObject], spark: SparkSession, date: String): Unit = {
    try {
      val db = "dm_gis"
      spark.sql(s"use $db")
      val table = "external_errcall_task"
      logger.error(">>>table=" + db + "." + table)
      val structFileds = new util.ArrayList[StructField]()
      val fileds = Array("sysorderno", "province", "cityname", "district", "address", "norm_address", "city", "src_src", "matchchktcsrc", "errcallflag", "groupid", "deptcode", "teamcode", "his_teamcode", "errcallteamid", "company", "errcalladdrabb", "errnorm_address", "errcalladdrgroupid", "errcalldept", "errcallempid", "task_id", "order_no", "waybill_no", "resource_id", "locate_code", "teamid", "pinci", "dept_gis", "dept_ts", "sametc", "recentday", "score", "st_tc", "chkn_tc", "stx", "sty", "label", "groupfreq")
      for (filed <- fileds) structFileds.add(DataTypes.createStructField(filed, DataTypes.StringType, true))
      val structType = DataTypes.createStructType(structFileds)
      val rowRdd = inputRdd.map(obj => {
        var row: Row = null
        try {
          val names = Array("sysorderno", "province", "cityname", "district", "address", "norm_address", "city", "src_src", "matchchktcsrc", "errcallflag", "groupid", "deptcode", "teamcode", "his_teamcode", "errcallteamid", "company", "errcalladdrabb", "errnorm_address", "errcalladdrgroupid", "errcalldept", "errcallempid", "task_id", "order_no", "waybill_no", "resource_id", "locate_code", "teamid", "pinci", "dept_gis", "dept_ts", "sametc", "recentday", "score", "st_tc", "chkn_tc", "stx", "sty", "label", "groupfreq")
          val values = new Array[String](names.length)
          for (i <- names.indices) values(i) = JSONUtil.getJsonVal(obj, names(i), "")
          row = RowFactory.create(values(0), values(1), values(2), values(3), values(4), values(5), values(6), values(7), values(8), values(9), values(10), values(11), values(12), values(13), values(14), values(15), values(16), values(17), values(18), values(19), values(20), values(21), values(22), values(23), values(24), values(25), values(26), values(27), values(28), values(29), values(30), values(31), values(32), values(33), values(34), values(35), values(36), values(37), values(38))
        } catch {
          case e: Exception => logger.error(">>>构造row异常：" + e)
        }
        row
      })
      // 4 构建DataFrame
      val df: DataFrame = spark.createDataFrame(rowRdd, structType)
      //5 基于Datarame创建临时表
      val tempView = String.format("%s_temp_view", table)
      df.createOrReplaceTempView(tempView)
      val partitionSql = String.format(s"partition(inc_day='%s')", date)
      //6 分区、表等操作
      val deletePartitionSql = String.format(s"alter table %s drop if  exists $partitionSql", table)
      logger.error(">>>删除处理日期分区：" + deletePartitionSql)
      spark.sql(deletePartitionSql)

      val createPartitionSql = String.format(s"alter table %s add if not exists $partitionSql", table)
      logger.error(">>>新建分区：" + createPartitionSql)
      spark.sql(createPartitionSql)
      //7 把临时表的数据刷进hive表中
      spark.sql(String.format(s"insert into  %s $partitionSql select * from %s", table, tempView))
      logger.error(">>>明细数据入hive库结束!")
    } catch {
      case e: Exception => logger.error(">>>明细数据入hive异常：" + e)
    }
  }

  def accessNormByGroupid(json: JSONObject): (JSONObject, JSONObject) = {
    var newJson: JSONObject = null
    val groupid = json.getString("groupid")
    val citycode = json.getString("city")
    if (groupid != null && groupid != "") {
      val url = groupid_url.format(citycode, groupid)
      val httpResult = HttpClientUtil.getJsonByGet(url)
      if (httpResult != null) {
        val success = httpResult.getBoolean("success")
        val data = httpResult.getJSONObject("data")
        if (data != null && success != null && success == true) {
          newJson = new JSONObject()
          val norm_address = data.getString("address")
          val city = data.getString("cityCode")
          val teamcode = data.getString("schCode")
          val teamid = data.getString("schCode")
          val deptcode = data.getString("znoCode")
          val stx = data.getString("x")
          val sty = data.getString("y")
          newJson.put("norm_address", norm_address)
          newJson.put("groupid", groupid)
          newJson.put("city", city)
          newJson.put("teamcode", teamcode)
          newJson.put("teamid", teamid)
          newJson.put("deptcode", deptcode)
          newJson.put("stx", stx)
          newJson.put("sty", sty)
          newJson.put("label", "standard")
        }
      }
    }

    (json, newJson)
  }


  /**
   * 统计过滤
   *
   * @param sourceRdd
   * @param date
   * @return
   */
  def statFilterData(sourceRdd: RDD[JSONObject], date: String): RDD[JSONObject] = {
    logger.error(">>>统计地址的频次")
    val addressRdd = sourceRdd.map(json => {
      val norm_address = json.getString("norm_address")
      (norm_address, json)
    }).filter(_._1 != null).groupByKey().flatMapValues(iter => {
      val list = iter.toList
      val pinci = list.size
      for (json <- list) json.put("pinci", pinci)
      list
    }).map(obj => {
      val json = obj._2
      val groupid = json.getString("groupid")
      (groupid, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(">>>统计groupid的频次")
    val groupidNotNullRdd = addressRdd.filter(_._1 != null).groupByKey().flatMap(iter => {
      val list = iter._2.toList
      val groupfreq = list.size
      for (json <- list) json.put("groupfreq", groupfreq)
      list
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>groupid不为空数据量：" + groupidNotNullRdd.count())
    groupidNotNullRdd.take(1).foreach(println)

    val groupidNullRdd = addressRdd.filter(_._1 == null).values.persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>groupid为空数据量：" + groupidNullRdd.count())
    groupidNullRdd.take(1).foreach(println)
    addressRdd.unpersist()

    val statFreqRdd = groupidNotNullRdd.union(groupidNullRdd)
    logger.error(">>>过滤无效地址或者城市数据")

    val filterAddrRdd = statFreqRdd.filter(json => {
      val teamcode = json.getString("teamcode")
      val teamcodeValid = TcUtils.matchTc(teamcode) //取teamcode不为空数据

      val norm_address = json.getString("norm_address")
      val addressInvalid = norm_address.replaceAll(" ", "").matches("[a-zA-Z]+") || norm_address.contains("#") //剔掉全为英文的地址

      val city = json.getString("city")
      val cityInvalid = city == "852" || city == "755" //剔调852数据
      teamcodeValid && !addressInvalid && !cityInvalid
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>过滤无效地址后数据量：" + filterAddrRdd.count())
    filterAddrRdd.take(1).foreach(println)
    groupidNotNullRdd.unpersist()
    groupidNullRdd.unpersist()

    val filterSametcRdd = filterAddrRdd.map(json => {
      val teamcode = json.getString("teamcode")
      var teamid = json.getString("teamid")
      var sametc: Boolean = false
      if (TcUtils.matchTc(teamcode) && TcUtils.matchTc(teamid) && teamcode == teamid) sametc = true
      json.put("sametc", sametc)
      val norm_address = json.getString("norm_address")
      (norm_address, json)
    }).groupByKey().filter(iter => {
      val list = iter._2.toList
      var sametcFlag = true //默认改组sametc都为true，整租需要被剔除
      for (json <- list if sametcFlag) {
        val sametc = json.getBoolean("sametc")
        if (sametc == false) sametcFlag = false //出现了false，该组不可以被剔除
      }
      !sametcFlag //保留判定结果为false的数据，全true的需要剔除掉
    }).flatMap(_._2).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>过滤sametc后数据量：" + filterSametcRdd.count())
    filterSametcRdd.take(1).foreach(println)
    filterAddrRdd.unpersist()

    logger.error(">>>生成两个zc并过滤掉zc不一致的数据")
    val handleZcRdd = filterSametcRdd.map(json => {
      var teamid = json.getString("teamid")
      val errcallteamid = json.getString("errcallteamid")
      if ((!TcUtils.matchTc(teamid)) && TcUtils.matchTc(errcallteamid)) {
        teamid = errcallteamid
        json.put("teamid", teamid)
      }
      val teamcode = json.getString("teamcode")
      var dept_gis: String = ""
      var dept_ts: String = ""
      if (TcUtils.matchTc(teamcode)) {
        dept_gis = TcUtils.getZcBySplitTc(teamcode)
      }
      if (TcUtils.matchTc(teamid)) {
        dept_ts = TcUtils.getZcBySplitTc(teamid)
      }
      json.put("dept_ts", dept_ts)
      json.put("dept_gis", dept_gis)
      json
    }).filter(json => {
      val dept_ts = json.getString("dept_ts")
      val dept_gis = json.getString("dept_gis")
      val zcInvalid = TcUtils.matchZc(dept_ts) && TcUtils.matchZc(dept_gis) && dept_gis != dept_ts //剔调tc不一致的
      !zcInvalid
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>生成两个zc并过滤掉zc不一致的数据后的数据量：" + handleZcRdd.count())
    handleZcRdd.take(1).foreach(println)
    filterSametcRdd.unpersist()

    logger.error(">>>按照norm_address、teamcode、teamid 排重")
    val pcRdd = addrPc(handleZcRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>排重后数据量：" + pcRdd.count())
    pcRdd.take(1).foreach(println)
    handleZcRdd.unpersist()

    val resultRdd = sortData(pcRdd, date).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>排序后数据量：" + pcRdd.count())
    resultRdd.take(1).foreach(println)
    resultRdd
  }

  /**
   * 根据地址等排重
   *
   * @param inputRdd
   * @return
   */
  def addrPc(inputRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val resultRdd = inputRdd.map(json => {
      val norm_address = json.getString("norm_address")
      val teamcode = json.getString("teamcode")
      val teamid = json.getString("teamid")
      ((norm_address, teamcode, teamid), json)
    }).reduceByKey((j1, j2) => {
      val inc_day1 = j1.getString("inc_day")
      val inc_day2 = j1.getString("inc_day")
      if (inc_day1 >= inc_day2) {
        j1
      } else {
        j2
      }
    }).values
    resultRdd
  }

  /**
   * 排序根据得分计算优先级
   *
   * @param inputRdd
   */
  def sortData(inputRdd: RDD[JSONObject], date: String): RDD[JSONObject] = {
    logger.error(">>>排序计算优先级")
    val outRdd = inputRdd.map(json => {
      val norm_address = json.getString("norm_address")
      val inc_day = json.getString("inc_day")
      (norm_address, (inc_day, json))
    }).groupByKey().flatMapValues(iter => {
      val list = iter.toList
      val recentday = list.sortBy(_._1).reverse.head._1
      for (json <- list) json._2.put("recentday", recentday)
      list.map(_._2)
    }).map(obj => {
      val json = obj._2
      val pinci = json.getInteger("pinci")
      val recentday = json.getString("recentday")
      val score = getScore(pinci, recentday, date)
      json.put("score", score)
      json
    }).map(json => {
      val score = json.getInteger("score")
      val norm_address = json.getString("norm_address")
      ((score, norm_address), json)
    }).sortByKey(false).values
    outRdd
  }

  /**
   * 计算得分
   *
   * @param pinci
   * @param recentday
   * @return
   */
  def getScore(pinci: Int, recentday: String, date: String): Int = {
    var score = 0
    try {
      val num = (recentday.toInt - date.toInt) + 9
      score = pinci * num
    } catch {
      case e: Exception => logger.error(">>>计算得分异常：" + e.getMessage)
    }
    score
  }

  /**
   * 获取审补的数据量
   *
   * @param spark
   * @param inputDate
   */
  def getCheckRdd(spark: SparkSession, inputDate: String): RDD[(String, JSONObject)] = {
    val date = DateUtil.changeDateSep(inputDate, "", "-")
    val startDate = DateUtil.getDateStr(date, -8, "-")
    val endDate = DateUtil.getDateStr(date, -1, "-")
    val url = "jdbc:mysql://asscmsaddrcheck-m.db.sfdc.com.cn/asscmsaddrcheck?useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
    var tablename = s"(select city_code,check_sch_code chkn_tc,address from address_data_%s  where data_time >= '$startDate' and data_time < '$endDate' and  source in('chkn_ck','chkn_his') and check_sch_code is not null  and del_flag = 0 and done_state = 1) monthly_account_result_%s"

    val tablename1 = tablename.format(1, 1)
    println(">>>tablename1=" + tablename1)
    var connMap1 = Map("url" -> url, "user" -> "asscmsaddrcheck", "password" -> "wgrwv7vs4s", "dbtable" -> tablename1)
    var df1 = spark.read.format("jdbc").options(connMap1).load()
    println(">>>df1的数据量=" + df1.count())
    df1.show()
    for (i <- 2.to(20)) {
      val name = tablename.format(i, i)
      println(">>>name" + i + "=" + name)
      var connMap = Map("url" -> url, "user" -> "asscmsaddrcheck", "password" -> "wgrwv7vs4s", "dbtable" -> name)
      val df = spark.read.format("jdbc").options(connMap).load()
      println(">>>df" + i + "的数据量=" + df.count())
      df1 = df1.union(df)
    }
    println(">>>df1的数据量=" + df1.count())
    val fields = df1.schema.fields
    val rdd = df1.rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) json.put(fields(i).name, row.getString(i))
      val address = json.getString("address")
      (address, json)
    }).reduceByKey((o1, o2) => o1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>获取到错珂审补完成的数据量为：" + rdd.count())
    rdd.take(1).foreach(println)
    rdd.map(obj => {
      (obj._2.getString("city_code"), 1)
    }).reduceByKey(_ + _).sortBy(_._2, false).collect().mkString(";").foreach(print)
    rdd
  }


  def getNormLibRdd(spark: SparkSession): RDD[((String, String), String)] = {
    val sql =
      s"""
         |select single_group groupid,final_tc,citycode
         |from dm_gis.tcacc_single_group
         |where single_group is not null and final_tc is not null  and final_tc <>''
       """.stripMargin
    println("sql=" + sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val resultRdd = df.rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) json.put(fields(i).name, row.getString(i))
      val groupid = json.getString("groupid")
      val citycode = json.getString("citycode")
      val final_tc = json.getString("final_tc")
      ((groupid, citycode), final_tc)
    }).reduceByKey((o1, o2) => o1)
    resultRdd
  }


  def getSourceRdd(spark: SparkSession, inc_day: String): RDD[JSONObject] = {
    val start_date = DateUtil.getDateStr(inc_day, -8)
    val end_date = DateUtil.getDateStr(inc_day, -1)
    val sql1 =
      s"""
         |select
         |  a.sysorderno as sysorderno,
         |  a.province as province,
         |  a.city as cityName,
         |  a.county as district,
         |  a.address as address,
         |  concat(a.province, a.city, a.county, a.address) as norm_address,
         |  a.citycode as city,
         |  a.src as src_src,
         |  a.matchchktcsrc as matchchktcsrc,
         |  a.errcallflag as errcallflag,
         |  a.groupid as groupid,
         |  a.deptcode as deptcode,
         |  a.teamcode as teamcode,
         |  if (
         |    a.errcallflag = 'true',
         |    a.errcallteamid,
         |    a.teamcode
         |  ) as his_teamcode,
         |  a.errcallteamid as errcallteamid,
         |  a.company as company,
         |  a.inc_day as inc_day,
         |  a.errcalladdrabb as errcalladdrabb,
         |  b.task_id as task_id,
         |  b.order_no as order_no,
         |  b.waybill_no as waybill_no,
         |  b.resource_id as resource_id,
         |  b.locate_code as locate_code,
         |  c.content content
         |FROM
         |  (select * from dm_gis.gis_rds_omsfrom where inc_day between '$start_date' and  '$end_date' and errcallflag = 'true') a
         |  left join (select * from ods_inc_sgs_core.tt_pickup_task where inc_day between '$start_date' and '$end_date' ) b on a.sysorderno = b.order_no
         |  and a.inc_day = b.inc_day
         |  left join (select * from ods_inc_sgs_core.tt_pickup_task_ex where inc_day between '$start_date' and '$end_date' ) c on b.task_id = c.pid
         |  and c.ex_key = 'RO_INFO'
         |  and c.inc_day = a.inc_day
         |
      """.stripMargin

    val sql =
      s"""
         |select
         |  sysorderno as sysorderno,
         |  province as province,
         |  city as cityName,
         |  county as district,
         |  address as address,
         |  concat(province, city, county, address) as norm_address,
         |  citycode as city,
         |  src as src_src,
         |  matchchktcsrc as matchchktcsrc,
         |  errcallflag as errcallflag,
         |  groupid as groupid,
         |  deptcode as deptcode,
         |  teamcode as teamcode,
         |  if (
         |    errcallflag = 'true',
         |    errcallteamid,
         |    teamcode
         |  ) as his_teamcode,
         |  errcallteamid as errcallteamid,
         |  company as company,
         |  inc_day as inc_day,
         |  errcalladdrabb as errcalladdrabb,
         |  pickupbody
         |FROM
         |  dm_gis.gis_rds_omsfrom a where inc_day between '$start_date' and  '$end_date' and errcallflag = 'true'
      """.stripMargin
    println("sql=" + sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val rdd = df.rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) json.put(fields(i).name, row.getString(i))
      var teamid = ""
      var resource_id = ""
      val pickupbody = JSON.parseObject(json.getString("pickupbody"))
      try {
        val teamid = JSONUtil.getJsonVal(pickupbody, "pick_up_tc", "")
        val resource_id = JSONUtil.getJsonVal(pickupbody, "resource_id", "")
      } catch {
        case e: Exception => logger.error(">>>获取teamid异常：" + e.getMessage)
      }
      json.put("teamid", teamid)
      json.put("resource_id", resource_id)
      json
    })
    rdd
  }

  def getSourceRdd1(spark: SparkSession, inc_day: String): RDD[JSONObject] = {
    val sql =
      s"""
         |select sysorderno,province,cityname,district,address,norm_address,city,src_src,matchchktcsrc,errcallflag,groupid,deptcode,teamcode,his_teamcode,errcallteamid,company,inc_day,errcalladdrabb,task_id,order_no,waybill_no,resource_id,locate_code,teamid
         |from dm_gis.external_errcall_task_tmp
       """.stripMargin

    println("sql=" + sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val rdd = df.rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) json.put(fields(i).name, row.getString(i))
      json
    })
    rdd
  }


}

