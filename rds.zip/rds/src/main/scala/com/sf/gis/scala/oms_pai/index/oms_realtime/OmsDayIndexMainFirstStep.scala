package com.sf.gis.scala.oms_pai.index.oms_realtime

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:01369702
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:225056，225129，225128
 * @TaskName:rds派件指标系统，第一步
 * @Description:rds派件日志解析,解析日志，用于预处理跨天的数据，减少关联数据量,主要是挑出rebody出来
 *                                                             未开发完毕
 *
 */
object OmsDayIndexMainFirstStep {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val version = 1.1
  println(version)
  val testSingleWaybill = false

  /**
   * main方法
   *
   * @param args : 参数
   */
  def main(args: Array[String]): Unit = {
    logger.error("testSingleWaybill:" + testSingleWaybill)
    val incDay = args(0)
    start(incDay)
    logger.error("日志解析完毕")
  }


  def queryOriginData(spark: SparkSession, incDay: String) = {
//    val originData = queryOriginData("")
  }

  def singleTask(spark: SparkSession, incDay: String): Unit = {
    logger.error("获取目标天的re_body和请求数据")
    val orginData = queryOriginData(spark, incDay)
  }

  /**
   * 开始任务
   */
  def start(incDay: String): Unit = {
    val spark = SparkSession.builder().config(getConf(appName)).enableHiveSupport().getOrCreate()
    singleTask(spark, incDay)

  }

  /**
   * @param appName : spark任务名
   * @return
   */
  def getConf(appName: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
      .set("spark.port.maxRetries", "100")
      .set("spark.driver.maxResultSize", "12g")
      .set("spark.rpc.io.backLog", "10000")
      .set("spark.cleaner.referenceTracking.blocking", "false")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.driver.allowMultipleContexts", "true")
      .set("spark.sql.tungsten.enabled", "false")
      .set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
      .set("quota.consumer.default", (10485760 * 2).toString)
      .set("cache.max.bytes.buffering", (20485760 * 2).toString)
      .set("spark.sql.broadcastTimeout", "36000")
      .set("spark.network.timeout", "30000")
      .set("spark.executor.heartbeatInterval", "30000")
      .set("hive.exec.dynamic.partition", "true")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.result.partition.ratio", "1")
    //    if(taskCode == 0){
    //      println("excutors:40")
    //      conf.set("spark.executor.instances","40")
    //    }else{
    //      println("excutors:50")
    //高峰期配置 begin
    //    conf.set("spark.executor.instances", "60")
    //    conf.set("spark.executor.instances","40")
    //    conf.set("spark.executor.memory", "30g")
    //    conf.set("spark.yarn.executor.memoryOverhead", "10g")
    //高峰期配置 end
    //    }
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
    conf.set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")

    conf
  }

}
