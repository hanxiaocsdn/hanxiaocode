package com.sf.gis.com.sf.gis.scala.oms_shou.constant

/**
  * Created by 01368078 on 2019/1/4.
  */
object FixedConstant {
  val CHARSET = "UTF-8"
  val DATE_FORMAT = "yyyy-MM-dd"
  val DATE_FORMAT2 = "yyyyMMdd"
  val DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss SSS"
  val TIME_FROMAT = "HHmmss"
  val DATE_TIME_FORMAT_Y_S = "yyyy-MM-dd HH:mm:ss"
}
