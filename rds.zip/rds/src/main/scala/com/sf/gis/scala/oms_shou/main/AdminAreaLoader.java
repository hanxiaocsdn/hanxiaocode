package com.sf.gis.scala.oms_shou.main;

import com.alibaba.fastjson.JSON;
import com.sf.gis.scala.oms_shou.db.DbHelper;
import com.sf.gis.scala.oms_shou.db.RdsManager;
import com.sf.gis.scala.oms_shou.pojo.AdminArea;
import scala.Serializable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AdminAreaLoader implements Serializable{
    public Map<String, List<AdminArea>> loadAdminArea() {
        List<AdminArea> adminAreaList = DbHelper.getResultList("select * from ADMIN_AREA", null, AdminArea.class, RdsManager.class);
        return adminAreaList.stream().collect(Collectors.groupingBy(AdminArea::getCityCode));
    }

    public static void main(String[] args){
        System.out.println(JSON.toJSONString(new AdminAreaLoader().loadAdminArea()));
    }
}
