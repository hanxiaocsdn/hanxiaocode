package com.sf.gis.scala.oms_shou

import java.net.URLEncoder

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil}
import com.sf.gis.scala.utils.TcUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
 * Created by 01375125 on 2019/10/24.
 * 推送月结缺失任务
 * 看起来没啥用了，已冻结
 */

object PuMonthMisTaskMain {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  //  val mistask_url = "http://gis-ass-zb.intsit.sfdc.com.cn/audit/api/monthlyAccount/saveAccount?account=%s&address=%s&cityCode=%s&znoCode=%s&source=%s"
  val mistask_url = "http://gis-aos-cgcs.sf-express.com/audit/api/monthlyAccount/saveAccount?account=%s&address=%s&cityCode=%s&znoCode=%s&source=%s&accountCompanyName=%s&responseUser=%s"
  ///sf bdp集群
  val userHdfsPath = "/user/01374443/upload/addr_tc/"
  //自建　hdfs
//  val userHdfsPath = "/dolphinscheduler/gisbdp/resources/"

  def main(args: Array[String]): Unit = {
    start(args)
    //    test()
  }

  def start(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)

    if (args.length == 0) {
      //代码内部传入日期参数
      val date = DateUtil.getDate(-4)
      handleTask(spark, date)
    } else if (args.length == 1) {
      //传入参数，单天任务
      val date = args(0)
      handleTask(spark, date)
    }
  }

  def test(): Unit = {
    //    val spark = SparkUtil.getLocalSpark(appName)

    //    val json = JSON.parseObject("{\"order_no\":\"12599102114242242918350062\",\"pu_addr\":\"山东省东营市广饶县经济开发区广兴路15号\",\"pu_zc\":\"546JC\",\"pu_emp_code\":\"01164879\",\"inc_day\":\"20191021\",\"freq\":1,\"waybill_no\":\"SF1002192493939\",\"city_code\":\"546\",\"account\":\"5460375247\"}")
    //    json.remove("result")
    //    println(json)
    //    val task = pushMismonthTask(json)
    //    println(task)

  }

  def handleTask(spark: SparkSession, date: String) {
    handleMisTask(spark, date)
  }

  def handleMisTask(spark: SparkSession, date: String): Unit = {
    logger.error(">>>处理月结缺失数据------------------date=" + date + "--------appName=" + appName + "------")
    logger.error(">>>获取大区城市映射关系")
    val cityAreaMap = getCityAreaMap(spark)
    logger.error(">>>获取月结公司名称")
    val (companyMap, userMap) = getMonthAccountCompanyInfo(spark)
    val companyMapBc = spark.sparkContext.broadcast(companyMap)
    val userMapBc = spark.sparkContext.broadcast(userMap)
    logger.error(">>>获取运单宽单数据（根据月结账号和网点取最高频地址）")
    val waybillnoRdd = getWaybillnoRdd(spark, date, cityAreaMap)

    logger.error(">>>获取月结库缺失数据(未处理)")
    val accountRdd: RDD[((String, String), JSONObject)] = getMonthAccountRdd(spark).repartition(40).persist()
    logger.error(">>>获取到月结数据量：" + accountRdd.count())
    accountRdd.take(1).foreach(println)

    logger.error(">>>过滤出有效缺失月结数据（is_finish='Y' 月结账号和网点唯一）")
    val validMisMonthRdd: RDD[((String, String), (JSONObject, Int))] = accountRdd.filter(obj => {
      val json = obj._2
      val is_finish = json.getString("is_finish")
      is_finish != null && is_finish == "Y"
    }).groupByKey().mapValues(iter => {
      val size = iter.size
      val firstJson = iter.toList.head
      (firstJson, size)
    }).filter(obj => {
      val size = obj._2._2
      size == 1
    }).repartition(100).persist()
    logger.error(">>>获取到有效缺失月结的数据量（is_finish='Y' 月结账号和网点唯一）：" + validMisMonthRdd.count())
    validMisMonthRdd.take(1).foreach(println)


    logger.error(">>>获取未匹配上有效月结库的运单数据")
    val misMatchMonthRdd = waybillnoRdd.leftOuterJoin(validMisMonthRdd).mapValues(obj => {
      val waybillJson = obj._1
      val monthObj = obj._2
      var isMisMonth = false
      if (monthObj.isEmpty) {
        //未匹配上月结数据
        isMisMonth = true
      }
      (isMisMonth, waybillJson)
    }).filter(_._2._1).persist()

    logger.error(">>>未匹配上有效月结数据量：" + misMatchMonthRdd.count())

    logger.error(">>>推缺失库前，要获取到缺失库的所有月结数据，并保证月结加网点不重复")
    val monthUniqueRdd: RDD[((String, String), JSONObject)] = accountRdd.reduceByKey((j1, j2) => j1)
    logger.error(">>>月结库中已存在缺失数据量（仅排重）：" + monthUniqueRdd.count())
    monthUniqueRdd.take(1).foreach(println)

    logger.error(">>>未匹配到有效月结的数据，同时在月结库中未匹配到已存在的任务，推月结缺失库任务")
    val filterRdd = misMatchMonthRdd.leftOuterJoin(monthUniqueRdd).repartition(40).mapValues(obj => {
      var json = obj._1._2
      val monthObj = obj._2
      var flag = false
      if (monthObj.isEmpty) {
        //月结库中不存在，可以推
        flag = true
      }
      (json, flag)
    }).values.persist()


    val pushRdd = filterRdd.filter(_._2).keys.repartition(20).persist()
    logger.error(">>>需要推送到缺失任务库的数据量：" + pushRdd.count() + ",推送中...")
    //    pushRdd.collect().foreach(obj=>{
    //      pushMismonthTask(obj)
    //    })s
    //    System.exit(0)
    val resultRdd = pushRdd.map(json => {
      pushMismonthTask(json, companyMapBc.value, userMapBc.value)
    }).persist()

    val rdd = resultRdd.map(json => {
      var flag = false
      val result = json.getJSONObject("result")
      if (result != null) {
        val success = result.getBoolean("success")
        if (success != null) flag = success
      }
      (json, flag)
    }).persist()

    logger.error(">>>推送成功的数据量：" + rdd.filter(_._2).count())
    val failRdd = rdd.filter(!_._2)
    logger.error(">>>推送失败的数据量：" + failRdd.count() + ">失败原因如下：")
    failRdd.map(obj => {
      var message = ""
      val json = obj._1
      val result = json.getJSONObject("result")
      if (result != null) {
        message = result.getString("message")
      }
      (message, 1)
    }).reduceByKey(_ + _).sortBy(_._2, false).take(10).foreach(println)
    logger.error(">>>失败样例数据")
    failRdd.take(10).foreach(println)
    saveCmsRet(spark, date, failRdd.keys)
  }

  def saveCmsRet(spark: SparkSession,
                 incDay: String, dataRdd: RDD[JSONObject]): Unit = {
    import spark.implicits._
    val tmpViewName = "tmp" + System.currentTimeMillis()
    val rows = dataRdd.map(obj => {
      (obj.toJSONString.replace("[\\r\\t\\n]", ""))
    }).toDF("data").repartition(10).createOrReplaceTempView(tmpViewName)
    val finalTable = "dm_gis.pu_month_mis_task_rslt"
    val sql = s"insert overwrite table ${finalTable} partition(inc_day='${incDay}') select * from ${tmpViewName}"
    logger.error(sql)
    spark.sql(sql)
    dataRdd.unpersist()
  }

//  def saveCmsRetOld(spark: SparkSession,
//                    incDay: String, dataRdd: RDD[JSONObject]): Unit = {
//    val rows = dataRdd.repartition(10).map(obj => {
//      obj.toJSONString.replace("[\\r\\t\\n]", "")
//    })
//    val finalTable = "pu_month_mis_task_rslt"
//    val dropSql = String.format("alter table dm_gis.%s drop if exists partition(inc_day = '%s')", finalTable, incDay)
//    spark.sql(dropSql)
//    rows.saveAsTextFile(String.format("/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, incDay))
//    val addSql = String.format("alter table dm_gis.%s add if not exists partition(inc_day = '%s')", finalTable, incDay)
//    spark.sql(addSql)
//    dataRdd.unpersist()
//  }

  def pushMismonthTask(json: JSONObject, companyMap: Map[String, String], userMap: Map[String, String]): JSONObject = {
    var url = ""
    try {
      val account = json.getString("account")
      val address = URLEncoder.encode(json.getString("pu_addr"), "utf-8")
      val cityCode = json.getString("city_code")
      val znoCode = json.getString("pu_zc")
      val source = 2 //缺失任务
      var company = ""
      if (companyMap.contains(account)) {
        company = companyMap.apply(account)
      }
      val userKey = account + "_" + znoCode
      var user = ""
      if (userMap.contains(userKey)) {
        user = userMap.apply(userKey)
      }
      url = mistask_url.format(account, address, cityCode, znoCode, source, company, user)
      //      logger.error(url)
      val httpResult = HttpClientUtil.getJsonByGet(url)
      if (httpResult != null) {
        json.put("result", httpResult)
      }
      //      logger.error("res:"+httpResult)
    } catch {
      case e: Exception => logger.error(">>>推一条缺失任务异常：" + e + ",url:" + url)
    }
    json
  }

  /**
   *
   * @param spark
   * @return
   */
  def getMonthAccountRdd(spark: SparkSession): RDD[((String, String), JSONObject)] = {
    val url = "jdbc:mysql://asscmsaddrcheck-m.db.sfdc.com.cn:3306/asscmsaddrcheck?useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
    val tablename = "(select city_code,account,zno_code,sch_code,source,is_finish from monthly_account where source=2 and del_flag=0) monthly_account_result"
    println("tablename=" + tablename)
    var connMap = Map("url" -> url, "user" -> "asscmsaddrcheck", "password" -> "wgrwv7vs4s", "dbtable" -> tablename)
    val month_df = spark.read.format("jdbc").options(connMap).option("driver", "com.mysql.jdbc.Driver").load()
    val names = Array("city_code", "account", "zno_code", "sch_code", "source", "is_finish")
    val montRdd = month_df.
      rdd.map(row => {
      val json = new JSONObject()
      for (i <- names.indices) json.put(names(i), row.get(i))
      val account = json.getString("account")
      val zno_code = json.getString("zno_code")
      ((account, zno_code), json)
    }).filter(obj => {
      obj._1._1 != null && obj._1._2 != null
    })
    montRdd
  }


  /**
   * 获取月结账号和tc映射数据
   *
   * @param spark
   * @return
   */
  def getLocalMonthAccountRdd(spark: SparkSession): RDD[((String, String), JSONObject)] = {
    val url = "jdbc:mysql://10.202.43.200:3306/gis_manu_oper_04?useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true"
    val tablename = "(select city_code,account,zno_code,sch_code,source,is_finish from monthly_account where source=2 and del_flag=0) monthly_account_result"
    var connMap = Map("url" -> url, "user" -> "gis_manu_oper", "password" -> "gis_manu_oper123456", "dbtable" -> tablename)
    val month_df = spark.read.format("jdbc").options(connMap).load()
    month_df.show(5)
    //    val montRdd = month_df.where("is_finish='Y'").select("city_code","account","zno_code","sch_code","source","is_finish").
    val names = Array("city_code", "account", "zno_code", "sch_code", "source", "is_finish")
    val montRdd = month_df. /*where("source=2 and del_flag=0").select("city_code","account","zno_code","sch_code","source","is_finish").*/
      rdd.map(row => {
      val json = new JSONObject()
      for (i <- names.indices) json.put(names(i), row.get(i))
      val account = json.getString("account")
      val zno_code = json.getString("zno_code")
      ((account, zno_code), json)
    }).filter(obj => {
      obj._1._1 != null && obj._1._2 != null
    }).persist()

    montRdd
  }

  /**
   * 获取运单信息
   *
   * @param spark
   * @param incDay
   * @return
   */
  def getWaybillnoRdd(spark: SparkSession, incDay: String, cityAreaMap: Map[String, String]): RDD[((String, String), JSONObject)] = {
    val table = "dm_gis.dwd_waybill_info_dtl_di"
    spark.sql(s"REFRESH TABLE $table")
    val selectWaySql =
      s"""
         |select * from
         |(select inc_day,waybill_no,order_no,consignee_emp_code,source_zone_code,consignor_addr_decrypt consignor_addr,
         |src_dist_code,freight_monthly_acct_code,
         |row_number() over(partition by waybill_no order by input_tm desc) as rank
         |from $table
         |where inc_day='$incDay'  and waybill_no is not null and freight_payment_type_code = '1' and freight_monthly_acct_code is not null and source_zone_code is not null and consignor_addr is not null) t where t.rank=1
     """.stripMargin
    logger.error(">>>selectWaybillSql:" + selectWaySql)
    val names = Array("inc_day", "waybill_no", "order_no", "pu_emp_code", "pu_zc", "pu_addr", "city_code", "account")
    var json: JSONObject = null
    val waybillnoRdd = spark.sql(selectWaySql)
      .rdd
      .repartition(100)
      .map(row => {
        json = new JSONObject()
        for (i <- names.indices) json.put(names(i), row.getString(i))
        val city_code = json.getString("city_code")
        val pu_zc = json.getString("pu_zc")
        var isValid = cityAreaMap.contains(city_code) && TcUtils.matchZc(pu_zc)
        (isValid, json)
      }).filter(_._1).map(obj => {
      val json = obj._2
      val account = json.getString("account")
      val pu_zc = json.getString("pu_zc")
      val pu_addr = json.getString("pu_addr")
      ((account, pu_zc, pu_addr), json)
    }).filter(obj => {
      val account = obj._1._1
      val pu_zc = obj._1._2
      val pu_addr = obj._1._3
      account != "" && TcUtils.matchZc(pu_zc) && pu_addr != ""
    }).persist()

    logger.error(">>>获取到收件寄付有月结和网点的数据量：" + waybillnoRdd.count() + ",取月结+网点下最高频的地址数据...")

    val freqRdd = waybillnoRdd.groupByKey().map(obj => {
      val account = obj._1._1
      val pu_zc = obj._1._2
      val list = obj._2.toList
      val freq = list.size
      val firstJson = list.head
      firstJson.put("freq", freq)
      ((account, pu_zc), (freq, firstJson))
    }).groupByKey().flatMapValues(iter => {
      iter.toList.sortBy(_._1).reverse.take(1).iterator.map(_._2)
    }).repartition(100).persist()

    logger.error(">>>取最高频地址后月结+网点的数据量：" + freqRdd.count())
    freqRdd.take(1).foreach(println)
    waybillnoRdd.unpersist()
    freqRdd
  }


  /**
   * 获取城市和大区映射关系及优先级
   *
   * @param spark
   * @return
   */
  def getCityAreaMap(spark: SparkSession): Map[String, String] = {

    val cityCodeAreaFile = "citycode_area_priority.csv"
    //    val citycodeAreaDf = spark.read.format("csv").option("header",true).option("multiLine",true).load(userHdfsPath + cityCodeAreaFile)
    val citycodeAreaDf = spark.read.csv(userHdfsPath + cityCodeAreaFile)

    val names = Array("city_code", "area_code")
    val citycodeAreaMap = citycodeAreaDf.rdd.map(row => {
      val city_code = row.getString(0)
      val area_code = row.getString(1).replaceAll("[\r\n\t]", "")
      (city_code, area_code)
    }).filter(obj => !"city_code".equals(obj._1)).collect().toMap
    val sb = new StringBuilder
    citycodeAreaMap.foreach(obj => {
      sb.append(obj._1 + "=>" + obj._2 + ",")
    })
    logger.error(sb.toString())

    citycodeAreaMap
  }

  /**
   * 获取公司网点员工信息
   *
   * @param spark
   * @return
   */
  def getMonthAccountCompanyInfo(spark: SparkSession): (Map[String, String], Map[String, String]) = {
    val monthInfoFile = "menacc.csv"
    //    val citycodeAreaDf = spark.read.format("csv").option("header",true).option("multiLine",true).load(userHdfsPath + cityCodeAreaFile)
    val monthInfoDf = spark.read.csv(userHdfsPath + monthInfoFile)

    val names = Array("account", "znoCode", "account_company_name", "response_user")
    val monthInfoMap = monthInfoDf.rdd.map(row => {
      val account = row.getString(0)
      val znoCode = row.getString(1)
      if (row.getString(2) == null) {
        logger.error("account" + account)
      }
      val account_company_name = row.getString(2)
      //          .replaceAll("[\r\n\t]","")
      val response_user = row.getString(3)
      ((account, znoCode), (account_company_name, response_user))
    })
    val companyMap = monthInfoMap.map(obj => {
      (obj._1._1, obj._2._1)
    }).collect().toMap
    val userMap = monthInfoMap.map(obj => {
      (obj._1._1 + "_" + obj._1._2, obj._2._2)
    }).collect().toMap
    //      .filter(obj=> !"city_code".equals(obj._1)).collect().toMap
    logger.error(companyMap.filter(obj => obj._2 == null).take(2))
    logger.error(userMap.take(2))

    (companyMap, userMap)
  }
}
