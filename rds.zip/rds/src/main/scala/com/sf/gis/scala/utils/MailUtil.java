//package com.sf.gis.scala.utils;
//
//
//
//import com.sf.gis.scala.oms_pai.start.JavaUtil;
//
//
//import javax.mail.Address;
//import javax.mail.MessagingException;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeMessage;
//import java.io.Serializable;
//import java.util.Date;
//import java.util.Properties;
//
//
//public class MailUtil implements  Serializable{
//
//    //发件人地址
//    private static String senderAddress = "deweihe@sf-express.com";
//    //收件人地址
////    public static String recipientTOStr ="deweihe@sf-express.com";
//    private static String recipientTOStr = null;
//    //发件人账户名
//    @SuppressWarnings("FieldCanBeLocal")
//    private static String senderAccount = "01375125";
//    //发件人账户密码
//    @SuppressWarnings("FieldCanBeLocal")
//    private static String senderPassword = "Shenzhen2018";
//
//    @SuppressWarnings("unused")
//    public static void  sendEmail(String subject, String info, String recipientTOStr1){
//        try {
//        Properties properties = new Properties();
//        properties.setProperty("mail.smtp.auth","true");
//        properties.setProperty("mail.transport.protocol","smtp");
//        properties.setProperty("mail.smtp.host","hqmail.sf.com");
//        properties.setProperty("mail.smtp.port","25");
//
//        if(JavaUtil.EN==2){recipientTOStr="deweihe@sf-express.com";}
////        if(JavaUtil.EN==1){recipientTOStr="deweihe@sf-express.com";}
//        if(JavaUtil.EN==1){recipientTOStr = "rongmeihan@sf-express.com,yuanqinglan@sf-express.com,shanchen2@sf-express.com,lishuangshuang@sf-express.com,xuyanyan@sf-express.com,deweihe@sf-express.com,cindy22@sf-express.com,zhangfawang@sfmail.sf-express.com";}
//
//            Session session = Session.getInstance(properties);
//        session.setDebug(true);
//        //根据session对象获取邮件传输对象Transport
//        Transport transport = session.getTransport();
//        //设置发件人的账户名和密码
//          transport.connect(senderAccount, senderPassword);
//        //创建邮件的实例对象
////        Message msg = getMimeMessage(session,subject,info);
//
//        //创建一封邮件的实例对象
//        MimeMessage msg = new MimeMessage(session);
//        //设置发件人地址
//        msg.setFrom(new InternetAddress(senderAddress));
//        /*
//          设置收件人地址（可以增加多个收件人、抄送、密送），即下面这一行代码书写多行
//          MimeMessage.RecipientType.TO:发送
//          MimeMessage.RecipientType.CC：抄送
//          MimeMessage.RecipientType.BCC：密送
//         */
//
//        String[] addressList = recipientTOStr.split(",");
//        Address[]addressArr = new Address[addressList.length];
//        for (int i = 0; i < addressList.length; i++) {
//            addressArr[i] = new InternetAddress(addressList[i]);
//        }
//        msg.setRecipients(MimeMessage.RecipientType.TO,addressArr);
////        msg.setRecipients(MimeMessage.RecipientType.TO,new Address[]{new InternetAddress("deweihe@sf-express.com"),new InternetAddress("linhongdian1@sf-express.com")});
//        //设置邮件主题
//        msg.setSubject(subject,"UTF-8");
//        //设置邮件正文
//        msg.setContent(info, "text/html;charset=UTF-8");
//        //设置邮件的发送时间,默认立即发送
//        msg.setSentDate(new Date());
//
//        //发送邮件，并发送到所有收件人地址，message.getAllRecipients() 获取到的是在创建邮件对象时添加的所有收件人, 抄送人, 密送人
//        transport.sendMessage(msg,msg.getAllRecipients());
//
//        //关闭邮件连接
//         transport.close();
//        } catch (MessagingException e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    @SuppressWarnings("unused")
//    public static MimeMessage getMimeMessage(Session session, String subject, String info, String recipientTOStr) throws MessagingException {
//        //创建一封邮件的实例对象
//        MimeMessage msg = new MimeMessage(session);
//        //设置发件人地址
//        msg.setFrom(new InternetAddress(senderAddress));
//        /*
//         * 设置收件人地址（可以增加多个收件人、抄送、密送），即下面这一行代码书写多行
//         * MimeMessage.RecipientType.TO:发送
//         * MimeMessage.RecipientType.CC：抄送
//         * MimeMessage.RecipientType.BCC：密送
//         */
//        msg.setRecipient(MimeMessage.RecipientType.TO,new InternetAddress("deweihe@sf-express.com"));
////        msg.setRecipients(MimeMessage.RecipientType.TO,new Address[]{new InternetAddress("deweihe@sf-express.com"),new InternetAddress("linhongdian1@sf-express.com")});
//        //设置邮件主题
//        msg.setSubject(subject,"UTF-8");
//        //设置邮件正文
//        msg.setContent(info, "text/html;charset=UTF-8");
//        //设置邮件的发送时间,默认立即发送
//        msg.setSentDate(new Date());
//
//        return msg;
//    }
//
//
//
//    /**
//     * 测试使用
//     * @param args:
//     * @throws Exception:
//     */
//    public static void main(String[] args) throws Exception {
//        String subject = "oms派件趋势分析之异常预警";
//        String info = "gis网点识别率低于预警值!";
//        String recipientTOStr = "deweihe@sf-express.com,linhongdian1@sf-express.com";
//
//        sendEmail(subject,info,recipientTOStr);
//    }
//
//
//
//}
