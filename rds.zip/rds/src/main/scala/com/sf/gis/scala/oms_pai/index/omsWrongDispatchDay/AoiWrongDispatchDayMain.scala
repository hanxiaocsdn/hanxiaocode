package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.oms_pai.db.{CgcsManager, ManagerFactory}
import com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay.WrongObj.AoiWdObj
import com.sf.gis.scala.oms_pai.start.ComUtil
import com.sf.gis.scala.utils.{DbUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
 * Created by 01375125 on 2018/11/13.
 * oms派件错分隔日统计，重构
 * 迁移至新集群,任务id:112
 */
object AoiWrongDispatchDayMain {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val comUtil = new ComUtil(7)
  val today: String = Util.dateDelta(0, "")
  val daysAgo = 1

  //  val incDay: String = Util.dateDelta(-daysAgo, "")
  //  val dateArray = Array(Util.getDay(incDay, -6, ""), Util.getDay(incDay, -5, ""), Util.getDay(incDay, -4, ""), Util.getDay(incDay, -3, ""), Util.getDay(incDay, -2, ""), Util.getDay(incDay, -1, ""), Util.getDay(incDay, 0, ""))
  //  val incDaySep: String = Util.dateDelta(-daysAgo, "-")
  //  val dateArraySep = Array(Util.getDay(incDaySep, -6, "-"), Util.getDay(incDaySep, -5, "-"), Util.getDay(incDaySep, -4, "-"), Util.getDay(incDaySep, -3, "-"), Util.getDay(incDaySep, -2, "-"), Util.getDay(incDaySep, -1, "-"), Util.getDay(incDaySep, 0, "-"))
  case class WdToHive(
                       id: String,
                       stat_date: String,
                       region: String,
                       city_code: String,
                       city: String,
                       req: Int,
                       aoi: Int,
                       aoi_wrong: Int,
                       aoi_ks: Int,
                       aoi_ks_wrong: Int,
                       aoi_arss: Int,
                       aoi_arss_wrong: Int,
                       aoi_gis: Int,
                       aoi_gis_wrong: Int,
                       aoi_gis_wrong_norm: Int,
                       aoi_gis_wrong_chkn: Int,
                       aoi_gis_wrong_chke: Int,
                       aoi_gis_wrong_phone: Int,
                       aoi_gis_wrong_road: Int,
                       aoi_gis_wrong_tc2: Int,
                       aoi_gis_wrong_auto: Int,
                       aoi_gis_wrong_normhp: Int,
                       aoi_gis_wrong_normcompany: Int,
                       aoi_gis_wrong_other: Int
                     )

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dateArray = Array(Util.getDay(incDay, -6, ""), Util.getDay(incDay, -5, ""), Util.getDay(incDay, -4, ""), Util.getDay(incDay, -3, ""), Util.getDay(incDay, -2, ""), Util.getDay(incDay, -1, ""), Util.getDay(incDay, 0, ""))
    start(dateArray)
  }

  /**
   * 开始程序
   */
  def start(dateArray: Array[String]): Unit = {


    val spark = Spark.getSparkSession(appName)
    logger.error(">>>统计aoi派件错分指标-------生产--------start------ComUtil.flag:" + comUtil.getFlag + "-----appName==" + appName + "----------")
    handleTask(dateArray, spark)
  }

  def saveWdIndexToHive(spark: SparkSession, rowIndexRdd: RDD[(String, AoiWdObj)], incDay: String) = {
    //    ID,STAT_DATE,REGION,CITY_CODE,CITY,
    //    REQ,AOI,AOI_WRONG,AOI_KS,AOI_WRONG_KS,AOI_ARSS,AOI_WRONG_ARSS,
    //    AOI_GIS,AOI_WRONG_GIS,AOI_WRONG_GIS_NORM,AOI_WRONG_GIS_CHKN,
    //    AOI_WRONG_GIS_CHKE,AOI_WRONG_GIS_PHONE,AOI_WRONG_GIS_ROAD,
    //    AOI_WRONG_GIS_TC2,AOI_WRONG_GIS_AUTO,AOI_WRONG_GIS_NORMHP,
    //    AOI_WRONG_GIS_NORMCOMPANY,AOI_WRONG_GIS_OTHER
    import spark.implicits._
    val tmpView = "tmp_dm_req_aoi_wd_di"
    rowIndexRdd.map(obj => {
      val o = obj._2
      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.region, o.city_code, o.city).mkString("_"))
      WdToHive(id, o.stat_date, o.region, o.city_code, o.city,
        o.req, o.aoi, o.aoi_wrong, o.aoi_ks, o.aoi_ks_wrong, o.aoi_arss, o.aoi_arss_wrong,
        o.aoi_gis, o.aoi_gis_wrong, o.aoi_gis_wrong_norm, o.aoi_gis_wrong_chkn,
        o.aoi_gis_wrong_chke, o.aoi_gis_wrong_phone, o.aoi_gis_wrong_road,
        o.aoi_gis_wrong_tc2, o.aoi_gis_wrong_auto, o.aoi_gis_wrong_normhp,
        o.aoi_gis_wrong_normcompany, o.aoi_gis_wrong_other
      )
    }).repartition(1).toDF().createOrReplaceTempView(tmpView)
    val tableName = "dm_gis.dm_req_aoi_wd_di"
    val sql = s"insert overwrite table $tableName partition(inc_day='$incDay') select * from $tmpView"
    logger.error(sql)
    spark.sql(sql)

  }

  /**
   * 处理任务
   *
   * @param dateArray
   * @param spark
   *
   */
  def handleTask(dateArray: Array[String], spark: SparkSession): Unit = {
    val startDate = dateArray.apply(0)
    val incDay = dateArray.apply(dateArray.length - 1)
    logger.error("-------统计" + startDate + "--" + incDay
      + "之间，" + dateArray.length + "天的的错分指标--------")

    logger.error(">>>获取cgcs错分表的数据")
    val waybillCgcsList = getCgcsData(startDate)
    val waybillCgcsRdd = spark.sparkContext.parallelize(waybillCgcsList).map(obj => {
      val json = new JSONObject()
      json.put("waybillno", obj)
      (obj, json)
    })
    logger.error(">>>获取cgcs错分表的数据量:" + waybillCgcsList.size())

    logger.error(">>>过滤错分数据...")
    val wrongRdd = filterWrongData(startDate, incDay, spark, waybillCgcsRdd)
    logger.error(">>>统计错分指标-------------------------")
    logger.error(">>>统计错分行指标-------------------------")
    val rowIndexRdd = statRowIndex(wrongRdd).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>错分行指标分组个数:" + rowIndexRdd.count())
    logger.error(">>>错分指标入库...")
    WdIndexStat.saveAoiWdIndex(rowIndexRdd, comUtil, dateArray)
    saveWdIndexToHive(spark, rowIndexRdd, incDay)
    logger.error(">>>错分指标统计结束End--------")
  }

  def statRowIndex(wrongRdd: RDD[JSONObject]): RDD[(String, AoiWdObj)] = {
    val aoiWdRdd = wrongRdd.map(obj => {
      val cityName = obj.getString("city")
      val cityCode = obj.getString("city_code")
      val region = obj.getString("region")
      val oms_body = obj.getJSONObject("oms_body")
      val waybillno = obj.getString("waybillno")
      var cgcsFlag = 0
      if (null != waybillno) {
        cgcsFlag = 1
      }
      val req = 1
      var aoi, aoiGis, aoiKs, aoiArss = 0
      var aoiWrong, aoiWrongGis, aoiWrongKs, aoiWrongArss = 0
      val gisAoiCode = oms_body.getString("gisAoiCode")
      val ksAoiCode = oms_body.getString("ksAoiCode")
      val finalAoiCode = oms_body.getString("finalAoiCode")
      var gisAoiSrc = oms_body.getString("gisAoiSrc")
      val stat_date = oms_body.getString("req_date")
      if (finalAoiCode != null && !finalAoiCode.isEmpty) {
        aoi = 1
        aoiWrong = cgcsFlag
        if (finalAoiCode.equals(gisAoiCode)) {
          aoiGis = 1
          aoiWrongGis = cgcsFlag
        } else if (finalAoiCode.equals(ksAoiCode)) {
          aoiKs = 1
          aoiWrongKs = cgcsFlag
        } else {
          aoiArss = 1
          aoiWrongArss = cgcsFlag
        }
      }
      var aoiWrongGisNorm, aoiWrongGisChkn, aoiWrongGisChke, aoiWrongGisPhone, aoiWrongGisOther = 0
      var aoiWrongGisRoad, aoiWrongGisTc2, aoiWrongGisAuto, aoiWrongGisNormHp, aoiWrongGisNormCompany = 0
      if (aoiWrongGis == 1) {
        if (gisAoiSrc == null) {
          gisAoiSrc = ""
        } else {
          gisAoiSrc = gisAoiSrc.toUpperCase
        }
        gisAoiSrc match {
          case "NORM" => aoiWrongGisNorm = 1
          case "CHKN" => aoiWrongGisChkn = 1
          case "CHKE" => aoiWrongGisChke = 1
          case "PHONE" => aoiWrongGisPhone = 1
          case "ROAD" => aoiWrongGisRoad = 1
          case "TC2" => aoiWrongGisTc2 = 1
          case "AUTO" => aoiWrongGisAuto = 1
          case "NORMHP" => aoiWrongGisNormHp = 1
          case "NORMCOMPANY" => aoiWrongGisNormCompany = 1
          case _ => aoiWrongGisOther = 1
        }
      }
      val aoiObj = AoiWdObj(stat_date, region, cityCode, cityName, "",
        req, aoi, aoiWrong, aoiKs, aoiWrongKs, aoiArss, aoiWrongArss,
        aoiGis, aoiWrongGis, aoiWrongGisNorm, aoiWrongGisChkn, aoiWrongGisChke,
        aoiWrongGisPhone, aoiWrongGisRoad, aoiWrongGisTc2, aoiWrongGisAuto,
        aoiWrongGisNormHp, aoiWrongGisNormCompany, aoiWrongGisOther)
      (stat_date + "_" + cityCode + "_" + cityName, aoiObj)
    }).reduceByKey((obj1, obj2) => {
      mergeAoiIndex(obj1, obj2)
    })
    aoiWdRdd
  }

  def mergeAoiIndex(obj1: AoiWdObj, obj2: AoiWdObj): AoiWdObj = {
    val stat_date = obj1.stat_date
    val region = obj1.region
    val cityName = obj1.city
    val cityCode = obj1.city_code
    val zoneCode = obj1.zone_code
    val req = obj1.req + obj2.req
    val aoi = obj1.aoi + obj2.aoi
    val aoiWrong = obj1.aoi_wrong + obj2.aoi_wrong
    val aoiKs = obj1.aoi_ks + obj2.aoi_ks
    val aoiWrongKs = obj1.aoi_ks_wrong + obj2.aoi_ks_wrong
    val aoiArss = obj1.aoi_arss + obj2.aoi_arss
    val aoiWrongArss = obj1.aoi_arss_wrong + obj2.aoi_arss_wrong
    val aoiGis = obj1.aoi_gis + obj2.aoi_gis
    val aoiWrongGis = obj1.aoi_gis_wrong + obj2.aoi_gis_wrong
    val aoiWrongGisNorm = obj1.aoi_gis_wrong_norm + obj2.aoi_gis_wrong_norm
    val aoiWrongGisChkn = obj1.aoi_gis_wrong_chkn + obj2.aoi_gis_wrong_chkn
    val aoiWrongGisChke = obj1.aoi_gis_wrong_chke + obj2.aoi_gis_wrong_chke
    val aoiWrongGisPhone = obj1.aoi_gis_wrong_phone + obj2.aoi_gis_wrong_phone
    val aoiWrongGisRoad = obj1.aoi_gis_wrong_road + obj2.aoi_gis_wrong_road
    val aoiWrongGisTc2 = obj1.aoi_gis_wrong_tc2 + obj2.aoi_gis_wrong_tc2
    val aoiWrongGisAuto = obj1.aoi_gis_wrong_auto + obj2.aoi_gis_wrong_auto
    val aoiWrongGisNormHp = obj1.aoi_gis_wrong_normhp + obj2.aoi_gis_wrong_normhp
    val aoiWrongGisNormCompany = obj1.aoi_gis_wrong_normcompany + obj2.aoi_gis_wrong_normcompany
    val aoiWrongGisOther = obj1.aoi_gis_wrong_other + obj2.aoi_gis_wrong_other
    AoiWdObj(stat_date, region, cityCode, cityName, zoneCode,
      req, aoi, aoiWrong, aoiKs, aoiWrongKs, aoiArss, aoiWrongArss,
      aoiGis, aoiWrongGis, aoiWrongGisNorm, aoiWrongGisChkn, aoiWrongGisChke,
      aoiWrongGisPhone, aoiWrongGisRoad, aoiWrongGisTc2, aoiWrongGisAuto,
      aoiWrongGisNormHp, aoiWrongGisNormCompany, aoiWrongGisOther)
  }

  /**
   * cgcs获取错分运单
   *
   * @param startDate
   * @return
   */
  def getCgcsData(startDate: String): util.ArrayList[String] = {
    val conn = ManagerFactory.createManager(classOf[CgcsManager]).getConn
    val tableIndex = 21
    val retList = new util.HashSet[String]()
    for (i <- 1 until tableIndex) {
      logger.error("table:" + i)
      val sql = "select waybill_no from origin_address_data_" + i + "" +
        " where create_date between '" + startDate + "' and '" + today + "' group " +
        " by waybill_no"
      val waybillList = DbUtils.selectColumn(conn, sql, Array("waybill_no"))
      logger.error(">>>获取cgcs错分表的数据:" + waybillList.size)
      retList.addAll(waybillList)
    }
    val list = new util.ArrayList[String](retList)
    list
  }


  /**
   * 过滤错分的数据
   *
   * @param startDate
   * @param endDate
   * @param spark
   * @return
   */
  def filterWrongData(startDate: String, endDate: String, spark: SparkSession, cgcsRdd: RDD[(String, JSONObject)]): RDD[JSONObject] = {

    logger.error(">>>获取oms派件的日志数据...")
    val omsRdd = getOmsLogRdd(startDate, endDate, spark).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>获取oms派件的数据量：" + omsRdd.count())
    //logger.error(">>>获取oms派件"+endDate+"的数据量：" + omsRdd.filter(obj=>obj._2.getJSONObject("oms_body").getString("req_date").equals(endDate)).count())
    logger.error(">>>关联CGCS数据...")
    val dlvRdd = omsRdd.union(cgcsRdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).map(obj => {
      if (obj._2.getJSONObject("oms_body") == null) {
        (null, obj._2)
      } else {
        obj
      }
    }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    omsRdd.unpersist()
    logger.error(">>>获取关联cgcs派件后的数据量：" + dlvRdd.count())
    dlvRdd.values
  }

  /**
   * 获取oms派件的数据
   *
   * @param startDate
   * @param endDate
   * @param spark
   * @return
   */
  def getOmsLogRdd(startDate: String, endDate: String, spark: SparkSession): RDD[(String, JSONObject)] = {
    //公司名为baison的为测试单
    val selectOmsSql =
      s"""
         |select * from
         |	(select inc_day,req_waybillno,req_destcitycode,req_time,req_addresseeaddr,gis_to_sys_time,gis_to_sys_src,
         |   gis_to_sys_gisdeptcodeto,gis_to_sys_sssdeptcodeto,gis_to_sys_depttoretby,gis_to_sys_gisteamcodeto,
         |   arss_dept_re_identrs,arss_dept_req_address,gis_to_sys_groupid,standardization,req_addresseemobile,
         |   req_addresseephone,city,adcode,splitresult,splittype,groupids,filters,keywords,matchids,adcodes,inc_day,
         |   chkDeptSrc,precision,req_comp_name,req_province,req_city,req_area,gisAoiCode,ksAoiCode,finalAoiCode,gisAoiSrc,
         |   row_number() over(partition BY req_waybillno order by req_time desc ) as rank
         |   from dm_gis.gis_rds_omsto
         | where inc_day between '$startDate' and '$endDate'  and req_waybillno <> '' and req_comp_name <> 'baison' )a where a.rank=1
      """.stripMargin

    println("selectOmsSql:" + selectOmsSql)
    val omsRdd = spark.sql(selectOmsSql)
      .repartition(2000)
      .rdd
      .map(row => {
        val oms_body = new JSONObject()
        val nameArr = Array("req_date", "waybillno", "city_code", "req_time", "req_addresss", "gis_time", "lib_src",
          "gis_dept", "sss_dept", "sys_src", "gis_tc", "arss_dept", "arss_req_address",
          "gis_to_sys_groupid", "standardization", "req_addresseemobile", "req_addresseephone", "city", "adcode", "splitresult",
          "splittype", "groupids", "filters", "keywords", "matchids", "adcodes", "inc_day", "chkDeptSrc", "precision",
          "req_comp_name", "req_province", "req_city", "req_area", "gisAoiCode", "ksAoiCode", "finalAoiCode", "gisAoiSrc")
        for (i <- nameArr.indices) oms_body.put(nameArr(i), row.getString(i))
        oms_body
      }).map(oms_body => {
      val waybillno = oms_body.getString("waybillno")
      val gisAoiCode = oms_body.getString("gisAoiCode")
      val ksAoiCode = oms_body.getString("ksAoiCode")
      val finalAoiCode = oms_body.getString("finalAoiCode")
      val gisAoiSrc = oms_body.getString("gisAoiSrc")
      val obj = new JSONObject()
      obj.put("city_code", oms_body.getString("city_code"))
      obj.put("req_addresss", oms_body.getString("req_addresss"))
      obj.put("req_date", oms_body.getString("req_date"))
      obj.put("waybillno", waybillno)
      obj.put("gisAoiCode", gisAoiCode)
      obj.put("ksAoiCode", ksAoiCode)
      obj.put("finalAoiCode", finalAoiCode)
      obj.put("gisAoiSrc", gisAoiSrc)
      val result = new JSONObject()
      result.put("oms_body", obj)
      (waybillno, result)
    }).filter(_._1 != null).values
    //logger.error(">>>运单数量:"+endDate+"-"+    omsRdd.filter(obj=> obj.getJSONObject("oms_body").getString("req_date").equals(endDate)).count())
    //    omsRdd.take(5).foreach(o=>println(o))
    logger.error(">>>标准化大区和城市代码...")
    val standardLogRdd = WdIndexStat.getStandardLogRdd(omsRdd, spark.sparkContext, comUtil)
      .map(obj => {
        val waybillno = obj.getJSONObject("oms_body").getString("waybillno")
        (waybillno, obj)
      })
    standardLogRdd
  }

  /**
   * 配置spark的conf
   *
   * @param appName
   * @return
   */
  def getSparkConf(appName: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    conf.set("spark.yarn.executor.memoryOverhead", "4096")
    conf.set("spark.scheduler.maxRegisteredResourcesWaitingTime", "180000")
    //    conf.set("spark.executor.instances","20")
    //    conf.set("spark.executor.memory","20g")
    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")

    //    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    //    conf.set("spark.kryo.registrationRequired", "true")
    //    conf.registerKryoClasses(Array(
    //      classOf[JSONObject],
    //      classOf[FinalObj],
    //      classOf[GisObj],
    //      classOf[RecValidObj],
    //      classOf[ZcRecValidObj],
    //      classOf[ZcWdObj]
    //    ))
    conf
  }


}
