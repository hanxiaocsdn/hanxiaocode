package com.sf.gis.scala.oms_shou.main

import java.util.Properties

import com.alibaba.fastjson.JSONObject
import com.sf.gis.com.sf.gis.scala.oms_shou.constant.FixedConstant
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.oms_shou.constant.VariableConstant
import com.sf.gis.scala.utils.ConfigurationUtil
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.slf4j.{Logger, LoggerFactory}

/**
 * 任务id: 此代码 用于后续改造，当前日志统计和解析未剥离，看看后续性能再定
 * 业务方：01394694（郭本婕）
 * 研发：01399581（匡仁衡）
 */
object ChkShouLogSta {

  @transient lazy val logger: Logger = LoggerFactory.getLogger(MainNewTest.getClass)
  val props: Properties = ConfigurationUtil.loadProperties(VariableConstant.CONF, FixedConstant.CHARSET)
  val appName: String = props.getProperty("app.name")


  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    start(incDay)
  }

  def start(incDay: String): Unit = {
    logger.info(s">>>incDay : $incDay")
    val spark = Spark.getSparkSession(appName)
    run(spark, incDay)
  }


  def queryOriginData(spark: SparkSession, incDay: String): RDD[JSONObject] = {
    null
  }

  def run(spark: SparkSession, incDay: String): Unit = {
    logger.error("获取存储日志")
    val originDataRdd = queryOriginData(spark, incDay)
    statLog(spark, originDataRdd, incDay)

    logger.error("the end~")
  }

  def statLog(spark: SparkSession, orderRdd: RDD[JSONObject], incDay: String): Unit = {
  }
}
