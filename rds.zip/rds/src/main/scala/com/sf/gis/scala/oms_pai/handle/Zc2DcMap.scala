package com.sf.gis.scala.oms_pai.handle

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.oms_pai.db.ConnectionManager

import scala.collection.JavaConversions._

/**
  * Created by 01368078 on 2018/8/6.
  */
object Zc2DcMap {

//  def getValidZc2DcMap(): util.HashMap[String, String] = {
//    var validZc2DcMap = new util.HashMap[String, String]()
//    val zc2DcMap = getZc2DcMap()
//    val zc2DcSet = getZcHasTcSet()
//    for(entry : Entry[String, String] <- zc2DcMap.entrySet()){
//      if(zc2DcSet.contains(entry.getKey))
//        validZc2DcMap.put(entry.getKey, entry.getValue)
//    }
//    zc2DcMap.clear()
//    zc2DcSet.clear()
//    validZc2DcMap
//  }

//  def getZc2DcMap() : util.HashMap[String, String] = {
//    var conn = ConnectionManager.getInstance().getConn
//    val stmt = conn.createStatement()
//    val Zc2Dcsql = "SELECT DEPT_CODE AS zno_code,DEPT_CODE AS depart_code FROM tm_department a WHERE " +
//      "a.TYPE_CODE IN ('FB04-YWX','DB05-DB','FB04-XMFB','DB05-XMDB','FB04-GLX','DB05-DLD') " +
//      "AND a.DELETE_FLG='0' UNION " +
//      "SELECT DEPT_CODE AS zno_code,PARENT_DEPT_CODE AS depart_code FROM tm_department a WHERE " +
//      "a.TYPE_CODE ='DB05-SFZ' AND  a.DELETE_FLG='0'"
//    val rs = stmt.executeQuery(Zc2Dcsql)
//    var zc2DcMap = new util.HashMap[String, String]()
//    while(rs.next()){
//      val znoCode = rs.getString(1)
//      val deptCode = rs.getString(2)
//      zc2DcMap.put(znoCode, deptCode)
//    }
//    conn.close()
//    zc2DcMap
//  }
//  def getZcHasTcSet() : util.HashSet[String] = {
//    var conn = ConnectionManager.getInstance().getConn
//    val stmt = conn.createStatement()
//    val Zc2Dcsql = "select distinct zno_code  FROM st_sch  WHERE sch_code is not null and sch_code not like ''"
//    val rs = stmt.executeQuery(Zc2Dcsql)
//    var zc2DcSet = new util.HashSet[String]()
//    while(rs.next()){
//      val znoCode = rs.getString(1)
//      zc2DcSet.add(znoCode)
//    }
//    conn.close()
//    zc2DcSet
//  }

  def getValidZc2DcMap(): util.HashMap[String, String] = {
    var validZc2DcMap = new util.HashMap[String, String]()
    val zc2DcList = getZc2DcListNew()
//    val zc2DcSet = getZcHasTcSet()
    for(zc2DcObj <- zc2DcList){
//      if("FB04-XMFB".equals(zc2DcObj.getString("TYPE_CODE"))|| "DB05-XMDB".equals(zc2DcObj.getString("TYPE_CODE")) ){
//          if(zc2DcSet.contains(zc2DcObj.getString("zno_code")))
//            validZc2DcMap.put(zc2DcObj.getString("zno_code"), zc2DcObj.getString("depart_code"))
//
//      }else{
//        validZc2DcMap.put(zc2DcObj.getString("zno_code"), zc2DcObj.getString("depart_code"))
//
//      }
      validZc2DcMap.put(zc2DcObj.getString("zno_code"), zc2DcObj.getString("depart_code"))
//      print(zc2DcObj.toJSONString+";")
    }
    println("")
    zc2DcList.clear()
//    zc2DcSet.clear()
    validZc2DcMap
  }

  def getZc2DcListNew() : util.ArrayList[JSONObject] = {
    var conn = ConnectionManager.getInstance().getConn
    val stmt = conn.createStatement()
    val zc2Dcsql = "SELECT DISTINCT a.zno_code zno_code,a.depart_code depart_code,a.TYPE_CODE TYPE_CODE " +
      "FROM (" +
      "select zno_code,depart_code,type_code from st_zno_depart where city_code = '755' and type_code IN ('FB04-YWX','DB05-DB','DB05-DLD', 'DB05-SFZ','FB04-XMFB','DB05-YYZ','ZZC05-SJ','FB04-YWX','DB05-DB','DB05-DLD',	'DB05-SFZ','FB04-XMFB','DB05-WBD','DB05-WHZ') " +
      "union all " +
      "select zno_code,depart_code,type_code from st_sss_zno_depart where city_code <> '755' and type_code IN ('FB04-YWX','DB05-DB','DB05-DLD', 'DB05-SFZ','FB04-XMFB','DB05-YYZ','ZZC05-SJ','FB04-YWX','DB05-DB','DB05-DLD',	'DB05-SFZ','FB04-XMFB','DB05-WBD','DB05-WHZ')" +
      ") a "
    val rs = stmt.executeQuery(zc2Dcsql)
    var zc2DcList = new util.ArrayList[JSONObject]()
    while(rs.next()){
      val obj = new JSONObject()
      obj.put("zno_code", rs.getString(1))
      obj.put("depart_code", rs.getString(2))
      obj.put("TYPE_CODE", rs.getString(3))
      zc2DcList.add(obj)
    }
    conn.close()
    zc2DcList
  }
  def getZc2DcList() : util.ArrayList[JSONObject] = {
    var conn = ConnectionManager.getInstance().getConn
    val stmt = conn.createStatement()
    val zc2Dcsql = "SELECT DISTINCT a.zno_code zno_code,a.depart_code depart_code,b.TYPE_CODE TYPE_CODE " +
      "FROM (" +
          "select zno_code,depart_code from st_zno_depart where city_code = '755' " +
        "union " +
          "select zno_code,depart_code from st_sss_zno_depart where city_code <> '755'" +
      ") a," +
      "tm_department b " +
      "WHERE a.zno_code = b.DEPT_CODE " +
      "AND b.TYPE_CODE IN ('FB04-YWX','DB05-DB','DB05-DLD','DB05-SFZ','FB04-XMFB','DB05-XMDB') " +
      "AND EXISTS (SELECT 1 FROM st_zno c WHERE a.depart_code = c.zno_code AND c.valid = 'Y')"
    val rs = stmt.executeQuery(zc2Dcsql)
    var zc2DcList = new util.ArrayList[JSONObject]()
    while(rs.next()){
      val obj = new JSONObject()
      obj.put("zno_code", rs.getString(1))
      obj.put("depart_code", rs.getString(2))
      obj.put("TYPE_CODE", rs.getString(3))
      zc2DcList.add(obj)
    }
    conn.close()
    zc2DcList
  }
  def getZcHasTcSet() : util.HashSet[String] = {
    var conn = ConnectionManager.getInstance().getConn
    val stmt = conn.createStatement()
    val Zc2Dcsql = "select distinct zno_code  FROM st_sch  WHERE sch_code is not null and sch_code not like ''"
    val rs = stmt.executeQuery(Zc2Dcsql)
    var zc2DcSet = new util.HashSet[String]()
    while(rs.next()){
      val znoCode = rs.getString(1)
      zc2DcSet.add(znoCode)
    }
    conn.close()
    zc2DcSet
  }

  def main(args: Array[String]): Unit = {
    println(getValidZc2DcMap())
  }
}
