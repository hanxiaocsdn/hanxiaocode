package com.sf.gis.scala.oms_pai.db;

import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.Statement;


public class ManagerFactory {
    public static Logger logger = Logger.getLogger(ManagerFactory.class);
    public static IManager createManager(Class<? extends  IManager> clazz){
        if(clazz.equals(WdManager.class)){
            return WdManager.getInstance("conf/oms_pai/wd_detail.properties");
        }else if(clazz.equals(RdsManager.class)){
            return RdsManager.getInstance("conf/oms_pai/rds_db.properties");
        }else if(clazz.equals(PrManager.class)){
            return PrManager.getInstance("conf/oms_pai/mysql-pr-config.properties");
        }else if(clazz.equals(ProManager.class)){
            return ProManager.getInstance("conf/oms_pai/mysql-pro-db.properties");
        }else if(clazz.equals(CgcsManager.class)){
            return CgcsManager.getInstance("conf/oms_pai/cgcs_db.properties");
        }else {
            return null;
        }
    }

    public static void main(String[] args) {
        //noinspection ConstantConditions
        try(Connection conn = ManagerFactory.createManager(WdManager.class).getConn()){
            Statement statement = conn.createStatement();
            //noinspection SqlNoDataSourceInspection
            statement.execute("select * from ADMIN_AREA");

        }catch (Exception ignored){

        }
    }
}
