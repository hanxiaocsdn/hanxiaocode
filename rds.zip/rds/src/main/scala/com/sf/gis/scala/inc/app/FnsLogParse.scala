package com.sf.gis.scala.inc.app

import java.util
import java.util.UUID

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.{Spark, SparkJoin, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
 * 已下线，待删除  01374443 20231103
 */
object FnsLogParse {

//  val className: String = this.getClass.getSimpleName.replace("$", "")
//  @transient
//  val logger: Logger = Logger.getLogger(className)
//  val saveTableName = "dm_gis.rds_fns_to"
//  val log_flag_array = Array("receive fns waybill message",
//    "GIS_RDS_CHK_DISP_TO_FNS",
//    "ATPai->",
//    "RDS-CHK-DIS-FNS",
//    "GIS_RDS_CHK_DISP_FNS_TO_KS",
//    "=>ksMsg",
//    "GIS_RDS_CHK_DISP_FNS_TO_ARSS",
//    "=>receive waybill dept chk message",
//    "GIS_RDS_CHK_DISP_FNS_TO_CGCS",
//    "=>chkAoiMsg",
//    "AddressUnkowCheck",
//    "=>link to gid"
//  )
//
//  //  def isShenbuLine(line: String): Boolean = {
//  //    val b1 = line.contains("=>link to gid:")
//  //    val b2 = line.contains("GIS_RDS_CHK_DISP_TO_FNS")
//  //    val b3 = line.contains("=>receive waybill dept chk message :")
//  //
//  //    val b13 = line.contains("=>kafka topic GIS_ASS_RDS_AOI_TO_AWSM,message:")
//  //    val b14 = line.contains("=>chkAoiMsg:")
//  //    val b8 = line.contains("=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message:")
//  //    val b20 = line.contains("AddressUnkowCheck:")
//  //    b1 || b2 || b3 //|| b13 || b14 || b8 || b20
//  //  }
//
//
//  def queryOriginData(sparkSession: SparkSession, startDay: String, endDay: String,
//                      isCurDay: Boolean, startDaySep: String): RDD[String] = {
//    var src_table_name = "dm_gis.fns_pai_log_flink_collect"
//    if (isCurDay) {
//      src_table_name = "dm_gis.fns_pai_log_flink"
//    }
//    var containRule = log_flag_array.mkString("|")
//    val sql = s"select log from ${src_table_name} where inc_day between '${startDay}' and '${endDay}' and log regexp '${containRule}' group by log "
//    logger.error(sql)
//    val originRdd = SparkRead.readHiveAsRow(sparkSession, sql, 1600)
//    val dataRdd = originRdd._1.filter(obj => {
//      val line = obj.getString(0)
//      !(line.contains("receive fns waybill message") && !line.contains(startDaySep))
//    }).map(obj => {
//      obj.getString(0)
//    })
//    dataRdd
//  }
//
//  def saveRslt(sparkSession: SparkSession, rsltLogRdd: RDD[JSONObject],
//               startDay: String,savePartitionNum:Int): Unit = {
//    logger.error("开始提取数据")
//    val resultRdd = pickupRsltData(rsltLogRdd)
//    val saveKey = Array("reqId", "req_time", "req_inputEmpCode", "req_sno", "req_waybillNo",
//      "req_sourceCityCode", "req_destCityCode", "req_destTelphone", "req_destCompany",
//      "req_destContactsName", "req_destProvince", "req_destCity", "req_destCounty",
//      "req_destAddr", "req_addresseeAddr", "re_time", "re_addresseeDeptCode",
//      "re_addresseeAoiId", "re_addresseeAoiCode", "re_addresseeAoiArea",
//      "re_addresseeTransitCodeCp", "re_addresseeAoiType", "re_addresseeCityCode",
//      "re_src", "re_addresseeKeyWord", "re_kwSrc", "re_systemSrcFlag", "re_fnsFirstDeptCode",
//      "re_fnsDeliveryCode", "re_fnsTransferCode", "re_kyDeptCode", "re_kyTeamCode",
//      "re_kyTransferCode", "req_at_city", "req_at_province", "req_at_cityName", "req_at_district",
//      "req_at_address", "req_at_contact", "req_at_tel", "req_at_mobile", "req_at_company",
//      "req_at_opt", "re_at_dept", "re_at_aoiid", "re_at_aoicode", "re_at_groupid", "re_at_keyWord",
//      "re_at_atDeptSrc", "re_at_atAoiSrc", "re_at_tcs_body", "re_at_other_body", "re_at_id_list",
//      "ks_req_time", "ks_req_dept", "ks_re_dept", "ks_re_aoi", "ks_re_aoiCode", "ks_re_zcTag",
//      "ks_re_aoiTag", "arss_req_time", "arss_req_gid", "arss_req_taskType", "arss_req_errorType",
//      "arss_req_inputEmpCode", "arss_re_opTm", "arss_re_identRs", "arss_re_aoiId",
//      "arss_re_result", "arss_re_cancelReasonCode", "arss_re_checkFlag", "arss_re_empCode",
//      "cgcs_req_zoneCode", "cgcs_req_checkType", "cgcs_req_sysCode", "cgcs_re_time",
//      "cgcs_re_znoCode", "cgcs_re_aoiId", "cgcs_re_dataType", "cgcs_re_operUserName", "req_body",
//      "re_body", "ks_req_body", "ks_re_body",
//      "arss_req_body", "arss_re_body", "cgcs_req_body", "cgcs_re_body", "unknown_check_body", "body_latest_index")
//    var finalSaveNum = savePartitionNum
//    if(finalSaveNum!=50){
//      finalSaveNum = resultRdd.getNumPartitions
//    }
//    SparkWrite.save2HiveStaticRandom(sparkSession, resultRdd, saveKey, saveTableName, Array(("inc_day", startDay)), finalSaveNum)
//  }
//
//  def start(startDay: String, endDay: String,savePartitionNum:Int): Unit = {
//    val sparkSession = Spark.getSparkSession(className)
//    //是否是计算当天的数据
//    val isCurDay = (startDay == DateUtil.getCurrentDate())
//    if (!isCurDay && startDay.equals(endDay)) {
//      logger.error("非今天的实时跑数，退出")
//      return
//    }
//    logger.error("获取日志数据")
//    val startDaySep = startDay.take(4) + '-' + startDay.substring(4, 6) + '-' + startDay.substring(6, 8)
//
//    val originRdd = queryOriginData(sparkSession, startDay, endDay, isCurDay, startDaySep).persist(StorageLevel.DISK_ONLY)
//    logger.error("解析日志")
//    val rsltLogRdd = parseOmsLog(sparkSession,originRdd, startDaySep)
//    logger.error("开始保存数据")
//    saveRslt(sparkSession, rsltLogRdd, startDay,savePartitionNum)
//  }
//
//  /**
//   * 运单关联数据
//   *
//   * @param leftRdd
//   * @param rightOriginRdd
//   * @return
//   */
//  def joinWnData(spark:SparkSession,
//                  leftRdd: RDD[JSONObject],
//                 rightOriginRdd: RDD[JSONObject],
//                 bodyName: String,
//                 linkRdd: RDD[(String, String)],
//                 compareReqId: Boolean = true)= {
//    var rightRdd = rightOriginRdd
//    if (linkRdd != null) {
//      //先用gid关联reqid
//      rightRdd = rightOriginRdd.map(obj => {
//        var gid = JSONUtil.getJsonValSingle(obj, "gid", "")
//        if (gid.isEmpty) {
//          gid = UUID.randomUUID().toString
//        }
//        (gid, obj)
//      }).leftOuterJoin(linkRdd).map(obj => {
//        val left = obj._2._1
//        val body = left.getJSONArray(bodyName)
//        val rightOp = obj._2._2
//        if (rightOp.nonEmpty) {
//          val reqId = rightOp.get
//          left.put("reqId", reqId)
//          if (reqId != null) {
//            for (i <- 0 until body.size()) {
//              body.getJSONObject(i).put("reqId", reqId)
//            }
//          }
//        }
//        left
//      })
//      val count = rightRdd
//        .filter(obj => !JSONUtil.getJsonValSingle(obj, "reqId", "").isEmpty).count()
//      logger.error("关联上请求的数量:" + count)
//    }
//    logger.error("数量：" + rightRdd.count())
//    val reRdd = rightRdd.map(obj => {
//      (obj.getString("wn"), obj)
//    }).reduceByKey((obj1, obj2) => {
//      mergeArrayItem(obj1, obj2, bodyName)
//    })
//    val reJoinRdd = SparkJoin.broadcastOfLeftLeanElemWithRightNoRepeat(spark,leftRdd.map(obj => (obj.getString("wn"),
//      obj)), reRdd, 10, 50,50)
//      .map(obj => {
//        val left = obj._2._1.asInstanceOf[JSONObject]
//        val rightOp = obj._2._2
//        if (rightOp.nonEmpty) {
//          val reqId = left.getString("reqId")
//          val rightArray = rightOp.get.asInstanceOf[JSONObject].getJSONArray(bodyName)
//          val matchReqArray = new JSONArray()
//          for (i <- 0 until rightArray.size()) {
//            val item = rightArray.getJSONObject(i)
//            val itemReqId = JSONUtil.getJsonValSingle(item, "reqId", "")
//            if (!compareReqId || itemReqId.isEmpty || itemReqId.equals(reqId)) {
//              matchReqArray.add(item)
//            }
//          }
//          if (matchReqArray.size() > 0) {
//            left.put(bodyName, matchReqArray)
//          }
//        }
//        (obj._1, left)
//      }).values.persist(StorageLevel.DISK_ONLY)
//    logger.error(s"${bodyName}关联上数据:" + reJoinRdd.filter(obj => obj.containsKey(bodyName)).count())
//    leftRdd.unpersist()
//    reJoinRdd
//  }
//
//
//  /**
//   * 合并多个相同body
//   *
//   * @param o1
//   * @param o2
//   */
//  def mergeArrayItem(o1: JSONObject, o2: JSONObject, key: String): JSONObject = {
//    val array1: JSONArray = o1.getJSONArray(key)
//    val array2: JSONArray = o2.getJSONArray(key)
//    if (array1 != null && array2 != null) {
//      for (i <- 0 until array2.size()) {
//        array1.add(array2.get(i))
//      }
//      o1.put(key, array1)
//    } else if (array1 == null && array2 != null) {
//      o1.put(key, array2)
//    }
//    o1
//  }
//
//  def classfyData(spark:SparkSession,
//                  formatLogRdd: RDD[(String, JSONObject)],
//                  startDaySep: String)= {
//    logger.error("处理req数据")
//    val reqRdd = formatLogRdd.filter(obj => obj._1.equals("req") && obj._2.getString("create_time").startsWith(startDaySep))
//      .map(obj => (obj._2.getString("reqId"), obj._2)).repartition(3200).persist(StorageLevel.DISK_ONLY)
//    logger.error("req数量:" + reqRdd.count())
//    logger.error("关联atp")
//    val atpJoinRdd = joinReqIdData(reqRdd, formatLogRdd.filter(obj => obj._1.equals("atp")).values, "atpai_body")
//    logger.error("关联re数据")
//    val reJoinRdd = joinWnData(spark,atpJoinRdd, formatLogRdd.filter(obj => obj._1.equals("re")).values,
//      "re_body", null, false)
//    logger.error("关联ks请求")
//    val ksReqJoinRdd = joinWnData(spark,reJoinRdd, formatLogRdd.filter(obj => obj._1.equals("ks_req")).values, "ks_req_body", null)
//    logger.error("关联ks响应")
//    val ksReJoinRdd = joinWnData(spark,ksReqJoinRdd, formatLogRdd.filter(obj => obj._1.equals("ks_re")).values, "ks_re_body", null)
//    logger.error("关联arss请求")
//    val arssReqJoinRdd = joinWnData(spark,ksReJoinRdd, formatLogRdd.filter(obj => obj._1.equals("arss_req")).values, "arss_req_body", null)
//
//    logger.error("关联unknown数据")
//    val unknownJoinRdd = joinWnData(spark,arssReqJoinRdd, formatLogRdd.filter(obj => obj._1.equals("unknown")).values, "unknown_check_body", null)
//
//    logger.error("处理link数据")
//    val linkRdd = formatLogRdd.filter(obj => obj._1.equals("link")).map(obj => {
//      (obj._2.getString("gid"), (obj._2.getString("reqId"), obj._2.getString("create_time")))
//    }).reduceByKey((obj1, obj2) => {
//      if (obj1._2 > obj2._2) {
//        obj1
//      } else {
//        obj2
//      }
//    }).map(obj => (obj._1, obj._2._1)).persist(StorageLevel.DISK_ONLY)
//    logger.error("link数量:" + linkRdd.count())
//
//    logger.error("关联arss响应数据")
//    val arssReJoinRdd = joinWnData(spark,unknownJoinRdd.repartition(1600), formatLogRdd.filter(obj => obj._1.equals("arss_re")).values, "arss_re_body", linkRdd)
//    logger.error("关联cgcs请求")
//    val cgcsReqJoinRdd = joinWnData(spark,arssReJoinRdd, formatLogRdd.filter(obj => obj._1.equals("cgcs_req")).values, "cgcs_req_body", linkRdd)
//    logger.error("关联cgcs响应")
//    val cgcsReJoinRdd = joinWnData(spark,cgcsReqJoinRdd, formatLogRdd.filter(obj => obj._1.equals("cgcs_re")).values, "cgcs_re_body", linkRdd)
//    formatLogRdd.unpersist()
//    cgcsReJoinRdd
//  }
//
//  /**
//   * 关联reqId数据
//   *
//   * @param leftRdd
//   * @param rightRdd
//   * @return
//   */
//  def joinReqIdData(leftRdd: RDD[(String, JSONObject)], rightRdd: RDD[JSONObject],
//                    bodyName: String) = {
//    val atpJoinRdd = leftRdd.leftOuterJoin(
//      rightRdd.map(obj => (obj.getString("reqId"), obj))).map(obj => {
//      val left = obj._2._1
//      val rightOpt = obj._2._2
//      if (rightOpt.nonEmpty) {
//        left.put(bodyName, rightOpt.get.getJSONObject(bodyName))
//      }
//      (obj._1, left)
//    }).values.persist(StorageLevel.DISK_ONLY)
//    logger.error(s"${bodyName}关联数量:" + atpJoinRdd.filter(obj => obj.containsKey(bodyName)).count())
//    leftRdd.unpersist()
//
//    atpJoinRdd
//  }
//
//  def pickupRsltData(classfyRdd: RDD[JSONObject]) = {
//    classfyRdd.map(obj => {
//      //latest_index 用于记录各数组的最新时间标号
//      val latestIndexJson = new JSONObject()
//      obj.put("body_latest_index", latestIndexJson)
//      obj.put("req_time", obj.getString("create_time"))
//      val req_body = obj.getJSONObject("req_body")
//      obj.put("req_inputEmpCode", JSONUtil.getJsonValSingle(req_body, "inputEmpCode", ""))
//      obj.put("req_sno", JSONUtil.getJsonVal(req_body, "sno", ""))
//      obj.put("req_waybillNo", JSONUtil.getJsonVal(req_body, "waybillNo", ""))
//      obj.put("req_sourceCityCode", JSONUtil.getJsonVal(req_body, "sourceCityCode", ""))
//      obj.put("req_destCityCode", JSONUtil.getJsonVal(req_body, "destCityCode", ""))
//      obj.put("req_destTelphone", JSONUtil.getJsonVal(req_body, "destTelphone", ""))
//      obj.put("req_destCompany", JSONUtil.getJsonVal(req_body, "destCompany", ""))
//      obj.put("req_destContactsName", JSONUtil.getJsonVal(req_body, "destContactsName", ""))
//      obj.put("req_destProvince", JSONUtil.getJsonVal(req_body, "destProvince", ""))
//      obj.put("req_destCity", JSONUtil.getJsonVal(req_body, "destCity", ""))
//      obj.put("req_destCounty", JSONUtil.getJsonVal(req_body, "destCounty", ""))
//      obj.put("req_destAddr", JSONUtil.getJsonVal(req_body, "destAddr", ""))
//      obj.put("req_addresseeAddr", JSONUtil.getJsonVal(req_body, "addresseeAddr", ""))
//      //at_pai
//      val atpai_body = obj.getJSONObject("atpai_body")
//      if (atpai_body != null) {
//        val req = atpai_body.getJSONObject("req")
//        obj.put("req_at_city", JSONUtil.getJsonVal(req, "city", ""))
//        obj.put("req_at_province", JSONUtil.getJsonValSingle(req, "req.province", ""))
//        obj.put("req_at_cityName", JSONUtil.getJsonValSingle(req, "cityName", ""))
//        obj.put("req_at_district", JSONUtil.getJsonValSingle(req, "district", ""))
//        obj.put("req_at_address", JSONUtil.getJsonValSingle(req, "address", ""))
//        obj.put("req_at_contact", JSONUtil.getJsonValSingle(req, "contact", ""))
//        obj.put("req_at_tel", "")
//        obj.put("req_at_mobile", "")
//        obj.put("req_at_company", JSONUtil.getJsonValSingle(req, "company", ""))
//        obj.put("req_at_opt", JSONUtil.getJsonValSingle(req, "opt", ""))
//        val tcs0 = JSONUtil.getJsonArrayMultiOfFirstObject(atpai_body, "res.result.tcs")
//        obj.put("re_at_dept", JSONUtil.getJsonValSingle(tcs0, "dept", ""))
//        obj.put("re_at_aoiid", JSONUtil.getJsonValSingle(tcs0, "aoiid", ""))
//        obj.put("re_at_aoicode", JSONUtil.getJsonValSingle(tcs0, "aoicode", ""))
//        obj.put("re_at_groupid", JSONUtil.getJsonValSingle(tcs0, "groupid", ""))
//        obj.put("re_at_keyWord", JSONUtil.getJsonValSingle(tcs0, "keyWord", ""))
//        obj.put("re_at_atDeptSrc", JSONUtil.getJsonValSingle(tcs0, "atDeptSrc", ""))
//        obj.put("re_at_atAoiSrc", JSONUtil.getJsonValSingle(tcs0, "atAoiSrc", ""))
//        val tcs = JSONUtil.getJsonArrayFromObject(atpai_body, "res.result.tcs", null)
//        obj.put("re_at_tcs_body", tcs)
//        val other = JSONUtil.getJsonObjectMulti(atpai_body, "res.result.other", null)
//        obj.put("re_at_other_body", other)
//        val idList = JSONUtil.getJsonObjectMulti(atpai_body, "res.result.id_list", null)
//        obj.put("re_at_id_list", idList)
//      }
//      //re_body
//      val (re_body_latest, re_body_latest_index) = getLatestBody(obj.getJSONArray("re_body"), "create_time")
//      latestIndexJson.put("re_body", re_body_latest_index)
//      obj.put("re_time", JSONUtil.getJsonValSingle(re_body_latest, "create_time", ""))
//      obj.put("re_addresseeDeptCode", JSONUtil.getJsonValSingle(re_body_latest, "addresseeDeptCode", ""))
//      obj.put("re_addresseeAoiId", JSONUtil.getJsonValSingle(re_body_latest, "addresseeAoiId", ""))
//      obj.put("re_addresseeAoiCode", JSONUtil.getJsonValSingle(re_body_latest, "addresseeAoiCode", ""))
//      obj.put("re_addresseeAoiArea", JSONUtil.getJsonValSingle(re_body_latest, "addresseeAoiArea", ""))
//      obj.put("re_addresseeTransitCodeCp", JSONUtil.getJsonValSingle(re_body_latest, "addresseeTransitCodeCp", ""))
//      obj.put("re_addresseeAoiType", JSONUtil.getJsonValSingle(re_body_latest, "addresseeAoiType", ""))
//      obj.put("re_addresseeCityCode", JSONUtil.getJsonValSingle(re_body_latest, "addresseeCityCode", ""))
//      obj.put("re_src", JSONUtil.getJsonValSingle(re_body_latest, "src", ""))
//      obj.put("re_addresseeKeyWord", JSONUtil.getJsonValSingle(re_body_latest, "addresseeKeyWord", ""))
//      obj.put("re_kwSrc", JSONUtil.getJsonValSingle(re_body_latest, "kwSrc", ""))
//      obj.put("re_systemSrcFlag", JSONUtil.getJsonValSingle(re_body_latest, "systemSrcFlag", ""))
//      obj.put("re_fnsFirstDeptCode", JSONUtil.getJsonValSingle(re_body_latest, "fnsFirstDeptCode", ""))
//      obj.put("re_fnsDeliveryCode", JSONUtil.getJsonValSingle(re_body_latest, "fnsDeliveryCode", ""))
//      obj.put("re_fnsTransferCode", JSONUtil.getJsonValSingle(re_body_latest, "fnsTransferCode", ""))
//      obj.put("re_kyDeptCode", JSONUtil.getJsonValSingle(re_body_latest, "kyDeptCode", ""))
//      obj.put("re_kyTeamCode", JSONUtil.getJsonValSingle(re_body_latest, "kyTeamCode", ""))
//      obj.put("re_kyTransferCode", JSONUtil.getJsonValSingle(re_body_latest, "kyTransferCode", ""))
//      //ks 请求
//      val (ks_req_body_latest, ks_req_body_latest_index) =
//        getLatestBody(obj.getJSONArray("ks_req_body"), "create_time")
//      latestIndexJson.put("ks_req_body", ks_req_body_latest_index)
//      obj.put("ks_req_time", JSONUtil.getJsonValSingle(ks_req_body_latest, "create_time"))
//      obj.put("ks_req_dept", JSONUtil.getJsonValSingle(ks_req_body_latest, "dept"))
//      //ks返回
//      val (ks_re_body_latest, ks_re_body_latest_index) =
//        getLatestBody(obj.getJSONArray("ks_re_body"), "create_time")
//      latestIndexJson.put("ks_re_body", ks_re_body_latest_index)
//      obj.put("ks_re_dept", JSONUtil.getJsonVal(ks_re_body_latest, "result.dept", ""))
//      obj.put("ks_re_aoi", JSONUtil.getJsonVal(ks_re_body_latest, "result.aoi", ""))
//      obj.put("ks_re_aoiCode", JSONUtil.getJsonVal(ks_re_body_latest, "result.aoiCode", ""))
//      obj.put("ks_re_zcTag", JSONUtil.getJsonVal(ks_re_body_latest, "result.zcTag", ""))
//      obj.put("ks_re_aoiTag", JSONUtil.getJsonVal(ks_re_body_latest, "result.aoiTag", ""))
//      //arss请求
//      val (arss_req_body_latest, arss_req_body_latest_index) =
//        getLatestBody(obj.getJSONArray("arss_req_body"), "create_time")
//      latestIndexJson.put("arss_req_body", arss_req_body_latest_index)
//      obj.put("arss_req_time", JSONUtil.getJsonValSingle(arss_req_body_latest, "create_time", ""))
//      obj.put("arss_req_gid", JSONUtil.getJsonValSingle(arss_req_body_latest, "gid", ""))
//      obj.put("arss_req_taskType", JSONUtil.getJsonValSingle(arss_req_body_latest, "taskType", ""))
//      obj.put("arss_req_errorType", JSONUtil.getJsonValSingle(arss_req_body_latest, "errorType", ""))
//      obj.put("arss_req_inputEmpCode", JSONUtil.getJsonValSingle(arss_req_body_latest, "inputEmpCode", ""))
//      //arss响应
//      val (arss_re_body_latest, arss_re_body_latest_index) =
//        getLatestBody(obj.getJSONArray("arss_re_body"), "create_time")
//      latestIndexJson.put("arss_re_body", arss_re_body_latest_index)
//      obj.put("arss_re_opTm", JSONUtil.getJsonValSingle(arss_re_body_latest, "opTm", ""))
//      obj.put("arss_re_identRs", JSONUtil.getJsonValSingle(arss_re_body_latest, "identRs", ""))
//      obj.put("arss_re_aoiId", JSONUtil.getJsonValSingle(arss_re_body_latest, "aoiId", ""))
//      obj.put("arss_re_result", JSONUtil.getJsonValSingle(arss_re_body_latest, "result", ""))
//      obj.put("arss_re_cancelReasonCode", JSONUtil.getJsonValSingle(arss_re_body_latest, "cancelReasonCode", ""))
//      obj.put("arss_re_checkFlag", JSONUtil.getJsonValSingle(arss_re_body_latest, "checkFlag", ""))
//      obj.put("arss_re_empCode", JSONUtil.getJsonValSingle(arss_re_body_latest, "empCode", ""))
//      //cgcs请求
//      val (cgcs_req_body_latest, cgcs_req_body_latest_index) =
//        getLatestBody(obj.getJSONArray("cgcs_req_body"), "create_time")
//      latestIndexJson.put("cgcs_req_body", cgcs_req_body_latest_index)
//      obj.put("cgcs_req_zoneCode", JSONUtil.getJsonValSingle(cgcs_req_body_latest, "zoneCode", ""))
//      obj.put("cgcs_req_checkType", JSONUtil.getJsonValSingle(cgcs_req_body_latest, "checkType", ""))
//      obj.put("cgcs_req_sysCode", JSONUtil.getJsonValSingle(cgcs_req_body_latest, "sysCode", ""))
//      //cgcs响应
//      val (cgcs_re_body_latest, cgcs_re_body_latest_index) =
//        getLatestBody(obj.getJSONArray("cgcs_re_body"), "create_time")
//      latestIndexJson.put("cgcs_re_body", cgcs_re_body_latest_index)
//      obj.put("cgcs_re_time", JSONUtil.getJsonValSingle(cgcs_re_body_latest, "create_time", ""))
//      obj.put("cgcs_re_znoCode", JSONUtil.getJsonValSingle(cgcs_re_body_latest, "znoCode", ""))
//      obj.put("cgcs_re_aoiId", JSONUtil.getJsonValSingle(cgcs_re_body_latest, "aoiId", ""))
//      obj.put("cgcs_re_dataType", JSONUtil.getJsonValSingle(cgcs_re_body_latest, "dataType", ""))
//      obj.put("cgcs_re_operUserName", JSONUtil.getJsonValSingle(cgcs_re_body_latest, "operUserName", ""))
//      obj
//    })
//  }
//
//  /**
//   * 获取最新的数据
//   *
//   * @param jArray
//   * @param dateTimeKey
//   * @return
//   */
//  def getLatestBody(jArray: JSONArray, dateTimeKey: String): (JSONObject, String) = {
//    if (jArray == null || jArray.size() == 0) {
//      return (null, "-1")
//    }
//    var re_body_item: JSONObject = null
//    var re_body_index: Int = -1
//    for (i <- 0 until jArray.size()) {
//      val tmp_re_body = jArray.getJSONObject(i)
//      if (re_body_item == null) {
//        re_body_item = tmp_re_body
//        re_body_index = i
//      } else {
//        if (re_body_item.getString(dateTimeKey) < tmp_re_body.getString(dateTimeKey)) {
//          re_body_item = tmp_re_body
//          re_body_index = i
//        }
//      }
//    }
//    (re_body_item, re_body_index.toString)
//  }
//
//  /**
//   * 解析日志数据
//   *
//   * @param validLineRdd : 日志rdd
//   * @param startDaySep  : 日期
//   * @return
//   */
//  def parseOmsLog(spark:SparkSession,validLineRdd: RDD[String],
//                  startDaySep: String)= {
//    val formatLogRdd: RDD[(String, JSONObject)] = validLineRdd.flatMap(line => {
//      parserLine(line).iterator()
//    }).persist(StorageLevel.DISK_ONLY)
//    logger.error("转换后总数据量:" + formatLogRdd.count())
//    validLineRdd.unpersist()
//    logger.error("处理各种类型的数据")
//    val classfyRdd = classfyData(spark,formatLogRdd, startDaySep)
//    classfyRdd
//  }
//
//  /**
//   * 解析非审补的数据，reqId不需要单独关联
//   *
//   * @param line : 数据行
//   * @return
//   */
//  def parserLine(line: String): util.ArrayList[(String, JSONObject)] = {
//    val tpList = new util.ArrayList[(String, JSONObject)]
//    var re: Object = null
//    try {
//      if (line.contains("=>receive fns waybill message")) re = parseFnsToReq(line) //请求的参数
//      else if (line.contains("=>kafka topic GIS_RDS_CHK_DISP_TO_FNS,message")) re = parseFnsToRe(line) //返回的结果
//      else if (line.contains("ATPai->")) re = parseATPaiData(line) //atPai返回数据
//      else if (line.contains("=>kafka topic GIS_RDS_CHK_DISP_FNS_TO_KS,message")) re = parseGisToKs(line) //ks请求
//      else if (line.contains("=>ksMsg")) re = parseKsToGis(line) //ks响应
//      else if (line.contains("=>kafka topic GIS_RDS_CHK_DISP_FNS_TO_ARSS,message")) re = parseGisToArss(line) //arss请求
//      else if (line.contains("=>receive waybill dept chk message")) re = parseOmsDeptArss(line) //arss结果
//      else if (line.contains("=>kafka topic GIS_RDS_CHK_DISP_FNS_TO_CGCS,message")) re = parseGisToCgcs(line) //cgcs请求
//      else if (line.contains("=>chkAoiMsg")) re = parseCgcsToGis(line) //cgcs响应
//      else if (line.contains("AddressUnkowCheck:")) re = parseAddressUnkonCheck(line) //判断地址是否不详的报文
//      else if (line.contains("=>link to gid")) re = linkReqId(line) //gid和reqId的映射
//    } catch {
//      case e: NullPointerException => logger.error(e + String.format("日志解析>>>数据空指针异常: %s", line))
//      case e: com.alibaba.fastjson.JSONException => logger.error(e + String.format("日志解析>>>JSON数据格式异常: %s", line))
//      case e: Exception => logger.error(String.format(e + "日志解析>>>解析数据未知异常: %s", line))
//    }
//
//    re match {
//      case i: (String, JSONObject) => tpList.add(i)
//      case x: util.ArrayList[(String, JSONObject)] => tpList.addAll(x)
//      case _ =>
//    }
//    tpList
//  }
//
//  def linkReqId(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//
//    val re = new JSONObject()
//    val reqId: String = StringUtils.pickGroup1Str(chkDisLogType, "^(.*?)=>link to gid(.*)").trim
//    val gid: String = chkDisLogMsg
//    re.put("reqId", reqId)
//    re.put("gid", gid)
//    re.put("create_time", createTime)
//    ("link", re)
//  }
//
//  def parseAddressUnkonCheck(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//    val re = new JSONObject()
//    val body = chkDisLogObj
//    body.put("create_time", createTime)
//    body.put("reqId", body.getString("requestId"))
//    val jArray = new JSONArray()
//    jArray.add(body)
//    re.put("unknown_check_body", jArray)
//    re.put("create_time", createTime)
//    re.put("wn", body.getString("waybillNo"))
//    re.put("reqId", body.getString("requestId"))
//    ("unknown", re)
//  }
//
//  def parseCgcsToGis(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//    val re = new JSONObject()
//    val body = chkDisLogObj
//    val gid = body.getString("gid")
//    body.put("create_time", createTime)
//    body.put("reqId", "")
//    val body_array = new JSONArray()
//    body_array.add(body)
//    re.put("cgcs_re_body", body_array)
//    re.put("create_time", createTime)
//    re.put("gid", gid)
//    re.put("nodeId", ip)
//    re.put("wn", body.getString("waybillNo"))
//    ("cgcs_re", re)
//  }
//
//  def parseGisToCgcs(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//    val re = new JSONObject()
//    val body = chkDisLogObj
//    val gid = body.getString("gid")
//    body.put("create_time", createTime)
//    body.put("reqId", "")
//    val body_array = new JSONArray()
//    body_array.add(body)
//    re.put("cgcs_req_body", body_array)
//    re.put("create_time", createTime)
//    re.put("gid", gid)
//    re.put("nodeId", ip)
//    re.put("wn", body.getString("waybillNo"))
//    ("cgcs_req", re)
//  }
//
//  /**
//   * 派件方网点审补结果(taskId) =>receive waybill dept chk message :
//   *
//   * @param line : 数据行
//   * @return
//   */
//  def parseOmsDeptArss(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//
//    val re = new JSONObject()
//    val body = chkDisLogObj
//    val gid = body.getString("taskId")
//    body.put("create_time", createTime)
//    body.put("reqId", "")
//    val body_array = new JSONArray()
//    body_array.add(body)
//    re.put("arss_re_body", body_array)
//    re.put("create_time", createTime)
//    re.put("gid", gid)
//    re.put("nodeId", ip)
//    re.put("wn", body.getString("waybillNo"))
//    ("arss_re", re)
//  }
//
//  /**
//   * kafka topic GIS_RDS_CHK_DISP_FNS_TO_ARSS,message: 派件批量审补网点
//   *
//   * @param line : 数据行
//   * @return
//   */
//  def parseGisToArss(line: String): util.ArrayList[(String, JSONObject)] = {
//    var (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//    val list = new util.ArrayList[(String, JSONObject)]
//    if (chkDisLogArray == null) {
//      chkDisLogArray = new JSONArray()
//    }
//    //单个请求
//    if (chkDisLogObj != null) {
//      chkDisLogArray.add(chkDisLogObj)
//    }
//
//    for (i <- 0 until chkDisLogArray.size()) {
//      val re = new JSONObject()
//      val body = chkDisLogArray.getJSONObject(i)
//      body.put("create_time", createTime)
//      val reqId = JSONUtil.getJsonVal(body, "requestId", "")
//      body.put("reqId", reqId)
//      val body_array = new JSONArray()
//      body_array.add(body)
//      re.put("reqId", reqId)
//      re.put("arss_req_body", body_array)
//      re.put("create_time", createTime)
//      re.put("nodeId", ip)
//      re.put("wn", JSONUtil.getJsonVal(body, "waybillNo", ""))
//      list.add(("arss_req", re))
//    }
//    list
//  }
//
//  /**
//   * 派件KS审补结果=>ksMsg: :
//   *
//   * @param line : 数据行
//   * @return
//   */
//  def parseKsToGis(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//    val re = new JSONObject()
//    val body = chkDisLogObj
//    body.put("create_time", createTime)
//    val body_array = new JSONArray()
//
//    try{
//      val result = body.getJSONObject("result")
//      if(result!=null){
//        val attachment = result.getJSONObject("attachment")
//        if(attachment!=null){
//          val omsReq = attachment.getJSONObject("omsReq")
//          if(omsReq!= null && omsReq.containsKey("destTelphoneDecrypt")){
//            omsReq.put("destTelphoneDecrypt","")
//            attachment.put("omsReq",omsReq)
//            result.put("attachment",attachment)
//            body.put("result",result)
//          }
//        }
//      }
//    }catch {
//      case e:Exception =>
//    }
//    body_array.add(body)
//    val reqId = JSONUtil.getJsonVal(body, "result.attachment.requestId", "")
//    val waybillNo = JSONUtil.getJsonVal(body, "result.attachment.omsReq.waybillNo", "")
//    body.put("reqId", reqId)
//    re.put("reqId", reqId)
//    re.put("create_time", createTime)
//    re.put("ks_re_body", body_array)
//    re.put("nodeId", ip)
//    re.put("wn", waybillNo)
//    ("ks_re", re)
//  }
//
//  /**
//   * ATPai
//   *
//   * @return
//   */
//  def parseATPaiData(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//    val re = new JSONObject()
//    val body = chkDisLogObj
//    body.put("create_time", createTime)
//    val reqId = body.getString("requestId")
//    val atPaiBody = new JSONObject()
//    re.put("reqId", reqId)
//    re.put("create_time", createTime)
//    re.put("atpai_body", body)
//    re.put("wn", JSONUtil.getJsonVal(body, "waybillNo", ""))
//    re.put("nodeId", ip)
//    ("atp", re)
//  }
//
//  /**
//   *
//   * =>kafka topic GIS_ASS_CORE_DEPT_TO_OMS,message: 最后返回给oms的数据信息
//   * @param line : 数据行
//   * @return
//   */
//  def parseFnsToRe(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//
//    val re = new JSONObject()
//    val reqId = StringUtils.pickGroup1Str(chkDisLogType, "(.*?)=>kafka topic GIS_RDS_CHK_DISP_TO_FNS,message(.*)").trim
//    val body = chkDisLogObj
//    re.put("reqId", reqId)
//    val body_array = new JSONArray()
//    body.put("create_time", createTime)
//    body.put("reqId", reqId)
//    body_array.add(body)
//    re.put("re_body", body_array)
//    re.put("create_time", createTime)
//    re.put("wn", JSONUtil.getJsonVal(body, "waybillNo", ""))
//    re.put("nodeId", ip)
//    ("re", re)
//  }
//
//  /**
//   * fns请求输入的参数,包含有"=>receive fns waybill message : "
//   *
//   * @param line : 数据行
//   * @return
//   */
//  def parseFnsToReq(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//    val re = new JSONObject()
//    val reqId = StringUtils.pickGroup1Str(chkDisLogType, "^(.*?)=>receive fns waybill message(.*)").trim
//    val body = chkDisLogObj
//    re.put("reqId", reqId)
//    re.put("wn", JSONUtil.getJsonVal(body, "waybillNo", ""))
//    //    body.put("create_time",createTime)
//    if(body.containsKey("destTelphoneDecrypt"))
//      body.put("destTelphoneDecrypt","")
//    re.put("req_body", body)
//    re.put("create_time", createTime)
//    re.put("nodeId", ip)
//    ("req", re)
//  }
//
//  def parseMessageObject(line: String): (String, String, String, String, JSONObject, JSONArray) = {
//    val jObj = JSON.parseObject(line.trim)
//    var createTime = jObj.getString("createTime")
//    if (createTime != null) {
//      createTime = createTime.replace(".", " ")
//    }
//    val ip = jObj.getString("ip")
//    val message = JSON.parseObject(jObj.getString("message").trim)
//    val chkDisLogType = message.getString("chkDisLogType").trim
//    var chkDisLogObj: JSONObject = null
//    var chkDisLogArray: JSONArray = null
//    var chkDisLogMsg: String = null
//    if (message.containsKey("chkDisLogArray")) {
//      val tmpArray = message.getJSONArray("chkDisLogArray")
//      if (tmpArray != null && tmpArray.size() != 0) {
//        chkDisLogArray = new JSONArray()
//        for (i <- 0 until tmpArray.size()) {
//          chkDisLogArray.add(JSON.parseObject(tmpArray.getString(i).trim))
//        }
//      }
//    } else if (message.containsKey("chkDisLogMsg")) {
//      chkDisLogMsg = message.getString("chkDisLogMsg").trim
//    } else {
//      chkDisLogObj = message
//    }
//    (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray)
//  }
//
//  /**
//   *
//   * =>kafka topic GIS_RDS_CHK_DISP_FNS_TO_KS,message: 派件发往KS审补网点
//   * @param line : 数据行
//   * @return
//   */
//  def parseGisToKs(line: String): (String, JSONObject) = {
//    val (createTime, ip, chkDisLogType, chkDisLogMsg, chkDisLogObj, chkDisLogArray) = parseMessageObject(line)
//    val re = new JSONObject()
//    val reqId = StringUtils.pickGroup1Str(chkDisLogType, "^(.*?)=>kafka topic GIS_RDS_CHK_DISP_FNS_TO_KS,message(.*)").trim
//    val body = chkDisLogObj
//    body.put("create_time", createTime)
//    body.put("reqId", reqId)
//    val body_array = new JSONArray()
//    try{
//      val attachment = body.getJSONObject("attachment")
//      if(attachment!=null){
//        val omsReq = attachment.getJSONObject("omsReq")
//        if(omsReq!= null && omsReq.containsKey("destTelphoneDecrypt")){
//          omsReq.put("destTelphoneDecrypt","")
//          attachment.put("omsReq",omsReq)
//          body.put("attachment",attachment)
//        }
//      }
//    }catch {
//      case e:Exception =>
//    }
//    body_array.add(body)
//    re.put("reqId", reqId)
//    re.put("ks_req_body", body_array)
//    re.put("create_time", createTime)
//    re.put("nodeId", ip)
//    val waybillNo = JSONUtil.getJsonVal(body, "attachment.omsReq.waybillNo", "")
//    re.put("wn", waybillNo)
//    ("ks_req", re)
//  }
//
//  def main(args: Array[String]): Unit = {
//    //    val line = "{\"appname\":\"chk-disp-fns\",\"createTime\":\"2021-12-05 08:13:21.965\",\"ip\":\"10.244.28.157\",\"level\":\"HDFS\",\"message\":\"{\\\"addressCut\\\":\\\"罗龙街道罗龙街道木桥路鑫源轿车汽修\\\",\\\"sysCode\\\":\\\"GIS-ASS-CMS\\\",\\\"znoCode\\\":\\\"831D\\\",\\\"address\\\":\\\"四川省宜宾市南溪区罗龙街道罗龙街道木桥路鑫源轿车汽修\\\",\\\"gid\\\":\\\"1298902\\\",\\\"aoiCode\\\":\\\"831D000224\\\",\\\"cityCode\\\":\\\"831\\\",\\\"targetSysCode\\\":\\\"GIS-ASS-RDS-CHK-DISP-FNS\\\",\\\"dataType\\\":\\\"1\\\",\\\"mobile\\\":\\\"DEEQAVTvPY47qTjlsHFs%2FXlQZ5pto%3D\\\",\\\"aoiUnit\\\":\\\"\\\",\\\"chkDisLogType\\\":\\\"546_1638663201965=>chkAoiMsg:\\\",\\\"xcoord\\\":\\\"104.89803079510239\\\",\\\"schCode\\\":\\\"\\\",\\\"cityName\\\":\\\"宜宾市\\\",\\\"province\\\":\\\"四川省\\\",\\\"phone\\\":\\\"DEEQAVTvPY47qTjlsHFs%2FXlQZ5pto%3D\\\",\\\"district\\\":\\\"南溪区\\\",\\\"operUserName\\\":\\\"40673674\\\",\\\"aoiId\\\":\\\"DFBE43FB9F7F468183E30F364345659C\\\",\\\"ycoord\\\":\\\"28.798305359142674\\\",\\\"chkDisLogLev\\\":\\\"INFO\\\",\\\"waybillNo\\\":\\\"184551465746\\\"}\",\"syn\":false}"
//    //    val (reqId,body) = parserLine(line).get(0)
//    //    println(reqId)
//    //
//    //    val keySet = body.keySet()
//    //    for(key <- keySet){
//    //      println(key+":"+body.get(key))
//    //    }
//    //    return
//    var startDay = args(0)
//    var endDay = args(1)
//    var savePartitionNum = 50
//    if(args.length>2){
//      savePartitionNum = args(2).toInt
//    }
//    logger.error("日期：" + startDay + "," + endDay+","+savePartitionNum)
//    start(startDay, endDay,savePartitionNum)
//    logger.error("结束流程~")
//  }
}


