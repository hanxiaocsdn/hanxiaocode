package com.sf.gis.scala.oms_pai

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import com.sf.gis.scala.oms_pai.db.AppConfig
import com.sf.gis.scala.oms_pai.handle.{ExcXiaogeNo, Zc2DcMap}
import com.sf.gis.scala.utils.{HttpConnection, StringUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import scala.util.Random
import scala.util.control.Breaks



/**
 * @ProductManager:01369702
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:225336
 * @TaskName:运单带妥投数据带电话
 * @Description: 生成每日工单数据,带了gis识别的网点和妥投网点，用于进行数据迭代
 */
object GetRoute80Data2 {
  def main(args: Array[String]): Unit = {
    val config = AppConfig.getInstance()
    val startDate = args(0)
    new GetRoute80Data2(config, startDate).start()
  }
}

class GetRoute80Data2(val appConfig: AppConfig, val startDate: String) extends Serializable {
  val config = appConfig
  @transient lazy val logger = Logger.getLogger(classOf[GetRoute80Data2])

  def start(): Unit = {
    var startTime = System.currentTimeMillis()
    val dbGis = config.getDbGis
    val tableGis = config.getTableGis
    val dbFvp = config.getDbFvp
    val tableFvp = config.getTableFvp
    val appName = "com.sf.gis.toIterTool.handle.ToIterTool"
    logger.error(String.format(">>>dbGis: %s , tableGis: %s, dbFvp: %s , tableFvp: %s, appName: %s", dbGis, tableGis, dbFvp, tableFvp, appName))
    getData(dbGis, tableGis, dbFvp, tableFvp, appName, startDate)
    var endTime = System.currentTimeMillis()
    logger.error(String.format(">>>耗时: %sms", (endTime - startTime).toString))
  }

  def unionScanRdd(toAddrRdd: RDD[(String, JSONObject)], scanRdd: RDD[(String, JSONObject)], zc2DcMap: util.HashMap[String, String]): RDD[(String, JSONObject)] = {
    //    val rdd = toAddrRdd.repartition(80).leftOuterJoin(scanRdd).map(obj => {
    //      var addrObj = obj._2._1
    //      var scanInfo = obj._2._2
    //      if(scanInfo != None){
    //        var empObj = scanInfo.get
    //        addrObj.put("bar_scan_lng", empObj.getString("bar_scan_lng"))
    //        addrObj.put("bar_scan_lat", empObj.getString("bar_scan_lat"))
    //        var deptByXyUrl = String.format(config.getDeptByxy, empObj.getString("bar_scan_lng"),empObj.getString("bar_scan_lat"))
    //        if(empObj.getString("bar_scan_lng")!=null && !empObj.getString("bar_scan_lng").isEmpty
    //          &&empObj.getString("bar_scan_lat")!=null && !empObj.getString("bar_scan_lat").isEmpty ){
    //          try {
    //            var re = HttpConnection.doGet(deptByXyUrl)
    //            val json = JSON.parseObject(String.valueOf(re.get("content")))
    //            if(json.getJSONObject("result") != null && json.getJSONObject("result").getJSONArray("data") != null
    //              && json.getJSONObject("result").getJSONArray("data").size() == 1 ){
    //              var mapZno = json.getJSONObject("result").getJSONArray("data").getJSONObject(0).getString("zno_code")
    //              addrObj.put("bar_scan_dept", zc2DcMap.get(mapZno))
    //            }
    //            Thread.sleep(75)
    //          }catch{
    //            case e : Exception => logger.error(empObj.toJSONString, e)
    //          }
    //        }
    //      }
    //      (obj._1, addrObj)
    //    })
    //    rdd
    toAddrRdd
  }

  def getData(dbGis: String, tableGis: String, dbFvp: String,
              tableFvp: String, appName: String, startDate: String): Unit = {
//    val conf = new SparkConf().setAppName(appName)
//    conf.set("spark.port.maxRetries", "100")
//    conf.set("spark.driver.allowMultipleContexts", "true")
//    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
//    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
//    conf.set("quota.consumer.default", (10485760 * 2).toString)
//    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
//    conf.set("spark.sql.result.partition.ratio", "1")
////    conf.set("spark.executor.instances", "40")
////    conf.set("spark.executor.memory", "25g")
////    conf.set("spark.driver.memory", "15g")
////    conf.set("spark.yarn.executor.memoryOverhead", "8g")
////    conf.set("spark.executor.cores", "8")
//    //    conf.set("spark.network.timeout","10000000")
//    //    conf.set("spark.executor.heartbeatInterval","10000000")
//    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")
//
//    val sc = new SparkContext(conf)
    var spark = Spark.getSparkSession(appName)
//    sc.setLogLevel("ERROR")
    //    var i = 6
    //    var n = 6
    //    var dateSet = new util.HashSet[String]()
    //    while(i <= n){
    var incDay = startDate
    //      if(!dateSet.contains(incDay)){
    //        dateSet.add(incDay)
    var date1 = DateUtil.getDateStr(incDay, 1)
    var date2 = DateUtil.getDateStr(incDay, 6)
    var date3 = DateUtil.getDateStr(incDay, 10)
    logger.error(incDay + ">>>" + date1 + ">>>" + date2 + ">>>" + date3)


    var startTime = 0L
    var endTime = 0L
    var spanTime = 0L

    logger.error(">>>获取营业站网点映射关系")
    startTime = System.currentTimeMillis()
    var zc2DcMap = Zc2DcMap.getValidZc2DcMap()
    var zc2DcCnt = zc2DcMap.keySet().size()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>营业站网点映射数据量 : $zc2DcCnt, 耗时 : $spanTime ms""")



    logger.error(s""">>>查询地址数据""")
    startTime = System.currentTimeMillis()
    var toAddrRdd = getToAddrRdd(spark, incDay).persist(StorageLevel.DISK_ONLY)
    var toAddrCnt = toAddrRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>地址数据量 : $toAddrCnt, 耗时 : $spanTime ms""")

    logger.error(">>>获取免除小哥工号")
    var excXiaogeNoSet = ExcXiaogeNo.getExcXiaogeNo()
    var excXiaogeNoCnt = excXiaogeNoSet.size()
    logger.error(s""">>>免除小哥数据量 : $excXiaogeNoCnt""")


    logger.error(s""">>>查询回单数据""")
    startTime = System.currentTimeMillis()
    var route80Rdd = getRoute80Rdd(spark, incDay, date2, excXiaogeNoSet).persist(StorageLevel.DISK_ONLY)
    var route80Cnt = route80Rdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>回单数据量 : $route80Cnt, 耗时 : $spanTime ms""")





    //        logger.error(s""">>>获取巴枪扫描数据""")
    //        startTime = System.currentTimeMillis()
    //        var scanRdd= getScanDataRdd(spark, incDay, date2).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //        var scanCnt= scanRdd.count()
    //        endTime = System.currentTimeMillis()
    //        spanTime = endTime - startTime
    //        logger.error(s""">>>获取巴枪扫描数据 : $scanCnt, 耗时 : $spanTime ms""")

    logger.error(s""">>>关联工单数据和妥投数据""")
    startTime = System.currentTimeMillis()
    var rdd1 = unionRoute80Data(toAddrRdd, route80Rdd, zc2DcMap).persist(StorageLevel.DISK_ONLY)
    var rddCnt1 = rdd1.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>关联后的数据量 : $rddCnt1, 耗时 : $spanTime ms""")
    toAddrRdd.unpersist()
    route80Rdd.unpersist()


    logger.error(s""">>>获取员工所属网点数据""")
    startTime = System.currentTimeMillis()
    var empInfoRdd = getEmpInfo(spark, incDay, date2).persist(StorageLevel.DISK_ONLY)
    var empInfoCnt = empInfoRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>员工所属网点数据 : $empInfoCnt, 耗时 : $spanTime ms""")

    logger.error(s""">>>关联工单数据和小哥数据""")
    startTime = System.currentTimeMillis()
    var xiaogeRdd = unionEmpInfoData(rdd1, empInfoRdd, zc2DcMap).repartition(320).persist(StorageLevel.DISK_ONLY)
    var xiaogeRddCnt = xiaogeRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>关联后的数据量 : $xiaogeRddCnt, 耗时 : $spanTime ms""")
    rdd1.unpersist()
    empInfoRdd.unpersist()

    logger.error(s""">>>获取收件排班数据""")
    startTime = System.currentTimeMillis()
    var pickupPlanRdd = getPickUpPlan(spark, incDay, date3).persist(StorageLevel.DISK_ONLY)
    var pickupPlanCnt = pickupPlanRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>排班数据量 : $pickupPlanCnt, 耗时 : $spanTime ms""")

    logger.error(s""">>>关联排班数据""")
    startTime = System.currentTimeMillis()
    var rdd = unionToData(xiaogeRdd, pickupPlanRdd, zc2DcMap).persist(StorageLevel.DISK_ONLY)
    var rddCnt = rdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>关联后的数据量 : $rddCnt, 耗时 : $spanTime ms""")
    pickupPlanRdd.unpersist()
    xiaogeRdd.unpersist()

    logger.error(s""">>>关联巴枪扫描数据""")
    startTime = System.currentTimeMillis()
    rdd = unionScanRdd(rdd, null, zc2DcMap)
    //          .persist(StorageLevel.MEMORY_AND_DISK_SER)
    rddCnt = rdd.count()
    var count = rdd.filter(x => x._2.getString("bar_scan_lng") != null && !x._2.getString("bar_scan_lng").isEmpty && x._2.getString("bar_scan_lat") != null && !x._2.getString("bar_scan_lat").isEmpty).count()
    logger.error(s""">>>坐标访问数量 : $count""")
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>关联巴枪扫描数据 : $rddCnt, 耗时 : $spanTime ms""")

    logger.error(s""">>>获取sss人工审补数据""")
    startTime = System.currentTimeMillis()
    var sssArtifidentRdd = getSssArtifidentData(spark, zc2DcMap, incDay, date1).repartition(320).persist(StorageLevel.DISK_ONLY)
    var sssArtifidentCnt = sssArtifidentRdd.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>sss人工审补数据量 : $sssArtifidentCnt, 耗时 : $spanTime ms""")

//    logger.error(s""">>>获取sss地址识别数据""")
//    startTime = System.currentTimeMillis()
//    var sssAddrIdentRdd = getSssAddrIdentData(spark, zc2DcMap, incDay, date1).persist(StorageLevel.DISK_ONLY)
//    var sssAddrIdentCnt = sssAddrIdentRdd.count()
//    endTime = System.currentTimeMillis()
//    spanTime = endTime - startTime
//    logger.error(s""">>>sss地址识别数据 : $sssAddrIdentCnt, 耗时 : $spanTime ms""")

    logger.error(s""">>>与sss人工审补数据关联""")
    startTime = System.currentTimeMillis()
    var matchRdd1 = matchSssData(rdd, sssArtifidentRdd).persist(StorageLevel.DISK_ONLY)
    var matchArtiRdd1 = matchRdd1.filter(obj => {
      obj._2.getString("sss_zone_code") != null
    }).persist(StorageLevel.DISK_ONLY) //匹配人工审补数据
    var unMatchArtiRdd1 = matchRdd1.filter(obj => {
      obj._2.getString("sss_zone_code") == null
    }).persist(StorageLevel.DISK_ONLY) //未匹配数据
    var matchArtiCnt1 = matchArtiRdd1.count()
    var unMatchArtiCnt1 = unMatchArtiRdd1.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>sss人工审补匹配数据 : $matchArtiCnt1,sss人工审补未匹配数据 : $unMatchArtiCnt1, 耗时 : $spanTime ms""")
    rdd.unpersist()
    sssArtifidentRdd.unpersist()
    matchRdd1.unpersist()


    logger.error(s""">>>与sss地址数据关联""")
    startTime = System.currentTimeMillis()
    //        var matchRdd2 = matchSssData(unMatchArtiRdd1, sssAddrIdentRdd)
    var matchRdd2 = unMatchArtiRdd1
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>sss地址匹配数据 耗时 : $spanTime ms""")

    logger.error(s""">>>合并人工审补数据和地址识别数据""")
    var rdd2 = matchArtiRdd1.union(matchRdd2)

    logger.error(s""">>>请求gis tc服务""")
    startTime = System.currentTimeMillis()
    var rows = queryGisTc(rdd2).persist(StorageLevel.DISK_ONLY)
    var rowsCnt = rows.count()
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>请求gis tc服务数据量: $rowsCnt, 耗时 : $spanTime ms""")
    matchArtiRdd1.unpersist()
    unMatchArtiRdd1.unpersist()
    rdd2.unpersist()

    logger.error(s""">>>将关联后的数据入库""")
    startTime = System.currentTimeMillis()
    saveData(spark, rows, incDay)
    endTime = System.currentTimeMillis()
    spanTime = endTime - startTime
    logger.error(s""">>>数据入库耗时 : $spanTime ms""")
//
//    rows.unpersist()
//    rdd.unpersist()
//    unMatchArtiRdd1.unpersist()
//    matchArtiRdd1.unpersist()
//    matchRdd1.unpersist()
////    sssAddrIdentRdd.unpersist()
//    sssArtifidentRdd.unpersist()
//    xiaogeRdd.unpersist()
//    rdd1.unpersist()
//    empInfoRdd.unpersist()
//    pickupPlanRdd.unpersist()
//    toAddrRdd.unpersist()
//    route80Rdd.unpersist()
//    //      }
//    //      i += 1
//    //    }
//    sc.stop()
  }

  /**
   * 左关联，左表存在少部分key倾斜，采用单独处理部分key的方式
   *
   * @param left    左表
   * @param right   右表
   * @param hashNum 散列系数，扩容倍数
   * @param topLean 需要单独处理的倾斜数据量
   */
  def leftOuterJoinOfLeftLeanElem(left: RDD[(String, JSONObject)], right: RDD[(String, JSONObject)], hashNum: Int, topLean: Int = 10): RDD[(String, (JSONObject, Option[JSONObject]))] = {
    val keyCounts = left.map(obj => (obj._1, 1)).reduceByKey(_ + _).sortBy(-_._2).take(topLean)
    val keys = keyCounts.map(obj => obj._1)
    val counts = keyCounts.map(obj => obj._2).sum
    logger.error("单独处理的keys:" + keyCounts.mkString(","))
    logger.error("单独处理的总数量:" + counts)
    //拆分数据为独立处理的key和非独立处理的key
    val leftHashKeyData = left.filter(obj => keys.contains(obj._1))
    val leftOtherData = left.filter(obj => !keys.contains(obj._1))
    val rightHashKeyData = right.filter(obj => keys.contains(obj._1))
    val rightOtherData = right.filter(obj => !keys.contains(obj._1))
    //先关联其他key数据
    val otherJoin = leftOtherData.leftOuterJoin(rightOtherData)
    //扩展单独处理的数据
    val leftHashKeyDataExpand = leftHashKeyData.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      (("00" + hashPrefix, obj._1), obj._2)
    })
    val rightHashKeyDataExpand = rightHashKeyData.flatMap(obj => {
      val dataArray = new ArrayBuffer[((String, String), JSONObject)]()
      for (i <- 0 until hashNum) {
        dataArray.append((("00" + i, obj._1), obj._2))
      }
      dataArray.iterator
    })
    //关联数据
    val hashKeyJoin = leftHashKeyDataExpand.leftOuterJoin(rightHashKeyDataExpand).map(obj => (obj._1._2, obj._2))
    hashKeyJoin.union(otherJoin)
  }

  def getToAddrRdd(spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    spark.sql(String.format("use %s", config.getDbGis))
    //    val toAddrSqlTempate = "select req_waybillno,req_address,req_citycode,re_deptcode,re_teamcode,sys_gisDeptCodeTo,sys_sssDeptCodeTo,sys_groupid " +
    //      "from %s where inc_day='%s' and req_addresstype = '2' and req_citycode <> ''"
    val toAddrSqlTempate = "select req_waybillno ,req_addresseeaddr, req_destcitycode, finalzc, finaltc, gis_to_sys_gisdeptcodeto, " +
      "gis_to_sys_sssdeptcodeto, gis_to_sys_groupid, req_addresseephone, req_addresseemobile, req_time,req_comp_name," +
      "gis_to_sys_groupid, standardization, groupids,gis_to_sys_src,req_province,req_city,req_area from %s where inc_day='%s' and req_destcitycode REGEXP '^[0-9]+$'"
    var toAddrSql = String.format(toAddrSqlTempate, config.getTableGisOmsto, date)
    var toAddrRdd = spark.sql(toAddrSql).repartition(320).rdd.map(row => {
      var re: (String, JSONObject) = null
      try {
        var obj = new JSONObject()
        var waybillNo = row.getString(0)
        var address = row.getString(1)
        var citycode = row.getString(2)
        var logDeptcode = row.getString(3)
        var logTeamcode = row.getString(4)
        var logGisDeptcode = row.getString(5)
        var logSssDeptcode = row.getString(6)
        var logGroupId = row.getString(7)
        var phone = row.getString(8)
        var mobile = row.getString(9)
        var reqTime = row.getString(10)
        var reqCompName = row.getString(11)
        var groupid = row.getString(12)
        var standardization = row.getString(13)
        var groupids = row.getString(14)
        var gis_to_sys_src = row.getString(15)

        if ("null".equals(logGisDeptcode))
          logGisDeptcode = ""
        if ("null".equals(logSssDeptcode))
          logSssDeptcode = ""

        obj.put("waybillno", waybillNo)
        obj.put("address", address)
        obj.put("citycode", citycode)
        obj.put("log_deptcode", logDeptcode)
        obj.put("log_teamcode", logTeamcode)
        obj.put("log_gisdeptcode", logGisDeptcode)
        obj.put("log_sssdeptcode", logSssDeptcode)
        obj.put("log_groupid", logGroupId)
        obj.put("phone", phone)
        obj.put("mobile", mobile)
        obj.put("req_time", reqTime)
        obj.put("req_comp_name", reqCompName)
        obj.put("groupid", groupid)
        obj.put("standardization", standardization)
        obj.put("groupids", groupids)
        obj.put("gis_to_sys_src", gis_to_sys_src)
        obj.put("req_province", row.getString(16))
        obj.put("req_city", row.getString(17))
        obj.put("req_area", row.getString(18))
        re = (String.format("%s_%s", waybillNo, citycode), obj)
      } catch {
        case e: Exception => logger.error(row, e)
      }
      re
    }).reduceByKey((obj1, obj2) => {
      if (obj1.containsKey("re_body"))
        obj1
      else
        obj2
    })
    toAddrRdd
  }

  def getRoute80Rdd(spark: SparkSession, date1: String, date2: String, excXiaogeNoSet: util.HashSet[String]): RDD[(String, JSONObject)] = {
    spark.sql(String.format("use %s", config.getDbFvp))
    val route80SqlTempate = "select mainwaybillno waybillno,zonecode,couriercode xiaoge_no,inc_day,opcode,baruploadtm from %s where inc_day>='%s' and inc_day<='%s' " +
      "and (opcode = '80'or opcode = '99' or (opcode = '33' and staywhycode in ('14', '55', '9', '67'))  or (opcode = '70' and staywhycode in ('14', '55', '9', '67'))  " +
      "or (opcode = '77' and staywhycode in ('14', '55', '103')) or opcode = '648')"
    var route80Sql = String.format(route80SqlTempate, config.getTableFvp, date1, date2)
    var route80Rdd = spark.sql(route80Sql).rdd.repartition(320).map(row => {
      var re: (String, JSONObject) = null
      var obj = new JSONObject()
      var waybillNo = row.getString(0)
      var zonecode = row.getString(1)
      var citycode = zonecode.replaceAll("(\\d*).*", "$1")
      var xiaogeNo = row.getString(2).replaceAll("^(0+)", "")
      var opDate = row.getString(3)
      var opCode = row.getString(4)
      var barUploadTm = row.getString(5)
      obj.put("zonecode", zonecode)
      obj.put("citycode", citycode)
      obj.put("xiaogeNo", xiaogeNo)
      obj.put("opdate", opDate)
      obj.put("opcode", opCode)
      obj.put("barUploadTm", barUploadTm)
      //      re = (waybillNo, obj)
      re = (String.format("%s_%s", waybillNo, citycode), obj)
      re
    }).reduceByKey((obj1, obj2) => {
      null  //多个的时候扔掉，写法异于常人。。。
    }).filter(obj => {
      obj._2 != null && "80".equals(obj._2.getString("opcode")) && !excXiaogeNoSet.contains(String.format("%s,%s", obj._2.getString("xiaogeNo"), obj._2.getString("citycode")))
    })

    route80Rdd
  }

  def getScanDataRdd(spark: SparkSession, date1: String, date2: String): RDD[(String, JSONObject)] = {
    spark.sql(String.format("use %s", config.getDbFvp))
    val scanDataTempate = "select distinct waybill_no,cast(bar_scan_lng AS string) bar_scan_lng,cast(bar_scan_lat AS string)bar_scan_lat ,bar_80_scan_tm from %s " +
      " where (inc_day between '%s' and '%s') and   (eventpositionmethod='1' or eventpositionmethod='5') and (bar_scan_lng<>'0.0' and bar_scan_lat<>'0.0') "
    var scanDataSql = String.format(scanDataTempate, config.getTable_scan, date1, date2)
    var scanDataRdd = spark.sql(scanDataSql).rdd.repartition(320).map(row => {
      var re: (String, JSONObject) = null
      var obj = new JSONObject()
      var waybillNo = row.getString(0)
      obj.put("bar_scan_lng", row.getString(1))
      obj.put("bar_scan_lat", row.getString(2))
      obj.put("bar_80_scan_tm", row.getString(3))
      re = (String.format("%s", waybillNo), obj)
      re
    }).reduceByKey((obj1, obj2) => {
      var obj = null: JSONObject
      if (obj1 != null && (obj2 == null || (obj2 != null && obj1.getString("bar_80_scan_tm") != null
        && obj1.getString("bar_80_scan_tm").compareTo(obj2.getString("bar_80_scan_tm")) >= 0))) {
        obj = obj1
      } else if (obj1 == null && obj2 != null) {
        obj = obj2
      }
      obj
    }).filter(obj => {
      obj._2 != null
    })
    scanDataRdd
  }

  def getPickUpPlan(spark: SparkSession, date1: String, date2: String): RDD[(String, Iterable[JSONObject])] = {
    spark.sql(String.format("use %s", config.getDbPickUpPlan))
    val pickupPlanSqlTemplate = "select t1.buid, t1.dept_code, t1.unit_arear_code, t1.inc_day, t2.start_tm, t2.end_tm  from " +
      "(select * from %s where inc_day>='%s' and inc_day<='%s') t1 left join " +
      "(select * from ods_sgsrss.tm_rss_send_plan where inc_day>='%s' and inc_day<='%s') t2 " +
      "on t1.classname = t2.classname"
    var pickupPlanSql = String.format(pickupPlanSqlTemplate, config.getTablePickUpPlan, date1, date2, date1, date2)
    logger.error(pickupPlanSqlTemplate)
    var pickupPlanRdd = spark.sql(pickupPlanSql).rdd.repartition(320).map(row => {
      var xiaogeNo = row.getString(0).replaceAll("^(0+)", "")
      var deptcode = row.getString(1)
      var teamcode = row.getString(2)
      var incDay = row.getString(3)
      var startTm = row.getString(4)
      var endTm = row.getString(5)
      startTm = startTm.replaceAll("(\\d{2})(\\d{2})", String.format("%s $1$200", incDay))
      endTm = endTm.replaceAll("(\\d{2})(\\d{2})", String.format("%s $1$200", incDay))

      var obj = new JSONObject()
      obj.put("deptcode", deptcode)
      obj.put("teamcode", teamcode)
      obj.put("startTm", DateUtil.dateToStamp(startTm))
      obj.put("endTm", DateUtil.dateToStamp(endTm))
      (xiaogeNo, obj)
    }).groupByKey().map(obj => {
      (obj._1, obj._2.toSet.toIterable)
    })
    pickupPlanRdd
  }

  def getEmpInfo(spark: SparkSession, date1: String, date2: String): RDD[(String, JSONObject)] = {
    val empInfoSqlTemplate = s"select emp_code, dept_code, inc_day from ${config.getTableEmpInfo} where inc_day between '${date1}' and '${date2}'" +
      s" and cancel_flag<>'Y' and (dept_code not like '020%' and dept_code not like '755%')   "

    val empInfoSqlTbUser = s"select loginid emp_code,service_dept dept_code,inc_day from ods_rmds.tb_res_user " +
      s" where inc_day between '${date1}' and '${date2}' and (service_dept like '020%' or service_dept like '755%') "


    val empInfoSql = empInfoSqlTemplate + " union all " + empInfoSqlTbUser
    logger.error("empInfoSql:" + empInfoSql)
    val empInfoRdd = spark.sql(empInfoSql).rdd.repartition(320).map(row => {
      var xiaogeNo = row.getString(0)
      if (xiaogeNo != null)
        xiaogeNo = xiaogeNo.replaceAll("^(0+)", "")
      val xiaoge_zoneCode = row.getString(1)
      val incDay = row.getString(2)
      var obj = new JSONObject()
      obj.put("xiaoge_zonecode", xiaoge_zoneCode)
      if (xiaogeNo == null || xiaogeNo.isEmpty) {
        (null, obj)
      } else {
        (String.format("%s_%s", xiaogeNo, incDay), obj)
      }
    }).filter(obj => obj._1 != null).reduceByKey((obj1, obj2) => {
      obj1
    })
    empInfoRdd
  }

  def unionRoute80Data(toAddrRdd: RDD[(String, JSONObject)], route80Rdd: RDD[(String, JSONObject)], zc2DcMap: util.HashMap[String, String]): RDD[(String, JSONObject)] = {
    val rdd = toAddrRdd.union(route80Rdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).filter(obj => {
      obj._2.containsKey("address")
    }).map(obj => {
      var xiaogeNo = JSONUtil.getJsonVal(obj._2, "xiaogeNo", "").toString
      var zonecode = JSONUtil.getJsonVal(obj._2, "zonecode", "").toString
      var deptcode = zc2DcMap.get(zonecode)
      //      obj._2.put("waybillno", obj._1)
      obj._2.put("deptcode", deptcode)
      (xiaogeNo, obj._2)
    })
    rdd
  }

  def unionEmpInfoData(toAddrRdd: RDD[(String, JSONObject)], empInfo: RDD[(String, JSONObject)], zc2DcMap: util.HashMap[String, String]): RDD[(String, JSONObject)] = {
    val rdd =
      leftOuterJoinOfLeftLeanElem(toAddrRdd.map(obj => {
        val xiaogeNo = JSONUtil.getJsonVal(obj._2, "xiaogeNo", "")
        val opdate = JSONUtil.getJsonVal(obj._2, "opdate", "")
        (String.format("%s_%s", xiaogeNo, opdate), obj._2)
      }), empInfo, 10, 20)
        .map(obj => {
          var addrObj = obj._2._1
          var empInfos = obj._2._2
          if (empInfos != None) {
            var empObj = empInfos.get
            var xiaoge_zoneCode = JSONUtil.getJsonVal(empObj, "xiaoge_zonecode", "").toString
            var xiaoge_deptCode = zc2DcMap.get(xiaoge_zoneCode)
            addrObj.put("xiaoge_zonecode", xiaoge_zoneCode)
            addrObj.put("xiaoge_deptcode", xiaoge_deptCode)
          }
          var xiaogeNo = JSONUtil.getJsonVal(addrObj, "xiaogeNo", "").toString
          (xiaogeNo, addrObj)
        })
    rdd
  }

  def unionToData(rdd: RDD[(String, JSONObject)], pickupPlanRdd: RDD[(String, Iterable[JSONObject])], zc2DcMap: util.HashMap[String, String]): RDD[(String, JSONObject)] = {
    var rdd1 = rdd.filter(obj => !"".equals(obj._1)) //有小哥工号
    var rdd2 = rdd.filter(obj => "".equals(obj._1)) //无小哥工号
    var rdd3 = rdd1.leftOuterJoin(pickupPlanRdd).map(obj => {
      var waybillObj = obj._2._1
      var plans = obj._2._2
      if (plans != None && plans.get.size > 0) {
        var planList = plans.get.toList
        var barUploadTm = JSONUtil.getJsonVal(waybillObj, "barUploadTm", "-1").toString.toLong
        var teamCodeSet = new util.HashSet[String]()
        var zoneCodeSet = new util.HashSet[String]()
        var deptCodeSet = new util.HashSet[String]()
        var flag = false
        val loop = new Breaks;
        loop.breakable(
          for (plan <- planList) {
            var startTm = JSONUtil.getJsonVal(plan, "startTm", "0").toString.toLong
            var endTm = JSONUtil.getJsonVal(plan, "endTm", "0").toString.toLong
            var teamCode = JSONUtil.getJsonVal(plan, "teamcode", "").toString
            var xiaoge_zoneCode = JSONUtil.getJsonVal(plan, "deptcode", "").toString
            var xiaoge_deptCode = zc2DcMap.get(xiaoge_zoneCode)
            teamCodeSet.add(teamCode)
            zoneCodeSet.add(xiaoge_zoneCode)
            if (xiaoge_deptCode != null)
              deptCodeSet.add(xiaoge_deptCode)
            if (startTm <= barUploadTm && barUploadTm < endTm) {
              if ("".equals(JSONUtil.getJsonVal(waybillObj, "xiaoge_zonecode", ""))) {
                waybillObj.put("xiaoge_zonecode", xiaoge_zoneCode)
                waybillObj.put("xiaoge_deptcode", xiaoge_deptCode)
              }
              waybillObj.put("teamcode", teamCode)
              flag = true
              loop.break()
            }
          }
        )
        if (!flag) {
          if ("".equals(JSONUtil.getJsonVal(waybillObj, "xiaoge_zonecode", ""))) {
            waybillObj.put("xiaoge_zonecode", if (zoneCodeSet.toList.size == 1) zoneCodeSet.mkString("|") else "")
            waybillObj.put("xiaoge_deptcode", if (deptCodeSet.toList.size == 1) deptCodeSet.mkString("|") else "")
          }
          waybillObj.put("teamcode", if (teamCodeSet.toList.size == 1) teamCodeSet.mkString("|") else "")
        }
      }
      (obj._1, waybillObj)
    })
    var rdd4 = rdd2.union(rdd3).map(obj => {
      var waybillNo = JSONUtil.getJsonVal(obj._2, "waybillno", "").toString
      (waybillNo, obj._2)
    })
    rdd4
  }

  /**
   * 获取sss人工审补数据
   *
   * @param spark
   * @return
   */
  def getSssArtifidentData(spark: SparkSession, zno2DeptMap: util.HashMap[String, String], date1: String, date2: String): RDD[(String, Iterable[JSONObject])] = {
    spark.sql("use ods_sss")
    var sssArtifidentRdd = spark.sql(String.format("select waybill_no, dest_zone_code, new_dest_zone_code, inc_day from tl_artifident " +
      "where inc_day between '%s' and '%s'", date1, date2)).rdd.map(row => {
      var obj = new JSONObject()
      var waybill_no = row.getString(0)
      var dest_zone_code = row.getString(1)
      var new_dest_zone_code = row.getString(2)
      var sss_inc_day = row.getString(3)
      var sss_zone_code_type = "-1"
      var sss_zone_code: String = null
      if (new_dest_zone_code != null && new_dest_zone_code.matches("\\d+[A-Z]+.*")) {
        sss_zone_code = new_dest_zone_code
        sss_zone_code_type = "1" //人工审补
      } else if (new_dest_zone_code != null && new_dest_zone_code.matches("\\d+")) {
        sss_zone_code_type = "2" //转城市
      } else if (dest_zone_code != null && dest_zone_code.matches("\\d+[A-Z]+.*")) {
        sss_zone_code = dest_zone_code
        sss_zone_code_type = "3" //地址识别
      } else (
        sss_zone_code_type = "4"
        )

      if (sss_zone_code != null)
        sss_zone_code.replaceAll("(\\d+[A-Z]+).*", "$1")
      if (zno2DeptMap.containsKey(sss_zone_code))
        sss_zone_code = zno2DeptMap.get(sss_zone_code)
      obj.put("waybillno", waybill_no)
      obj.put("sss_zone_code", if (sss_zone_code != null) sss_zone_code.trim.replaceAll("(\\d+[A-Z]+).*", "$1") else sss_zone_code)
      obj.put("sss_zone_code_type", sss_zone_code_type)
      obj.put("sss_inc_day", sss_inc_day)
      (waybill_no, obj)
    }).groupByKey()
    sssArtifidentRdd
  }

  /**
   * 获取sss地址识别数据
   *
   * @param spark
   * @return
   */
  def getSssAddrIdentData(spark: SparkSession, zno2DeptMap: util.HashMap[String, String], date1: String, date2: String): RDD[(String, Iterable[JSONObject])] = {
    spark.sql("use ods_sss")
    var sssAddrIdentData = spark.sql(String.format("select waybill_no, addr_ident_zno, inc_day from tl_addr_ident where " +
      "inc_day between '%s' and '%s'", date1, date2)).rdd.map(row => {
      var obj = new JSONObject()
      var waybill_no = row.getString(0)
      var sss_addr_ident_zno = row.getString(1)
      var sss_inc_day = row.getString(2)
      if (sss_addr_ident_zno != null)
        sss_addr_ident_zno = sss_addr_ident_zno.replaceAll("(\\d+[A-Z]+).*", "$1")
      if (zno2DeptMap.containsKey(sss_addr_ident_zno))
        sss_addr_ident_zno = zno2DeptMap.get(sss_addr_ident_zno)
      obj.put("waybillno", waybill_no)
      obj.put("sss_zone_code", if (sss_addr_ident_zno != null) sss_addr_ident_zno.trim else sss_addr_ident_zno)
      obj.put("sss_zone_code_type", "5")
      obj.put("sss_inc_day", sss_inc_day)
      (waybill_no, obj)
    }).groupByKey()
    sssAddrIdentData
  }

  def matchSssData(unMatchRdd: RDD[(String, JSONObject)], sssRdd: RDD[(String, Iterable[JSONObject])]): RDD[(String, JSONObject)] = {
    var matchRdd = unMatchRdd.leftOuterJoin(sssRdd).repartition(320).map(obj => {
      var unMatchObj = obj._2._1
      var sssArtifidentObjs = obj._2._2
      var sssZoneCodes: String = null
      var sssZoneCodeTypes: String = null
      var sssIncDays: String = null
      var sssCnt = 0
      try {
        if (sssArtifidentObjs != None && sssArtifidentObjs.get.size > 0) {
          var sssArtifidentObjList = sssArtifidentObjs.get.toList
          var objList = new util.ArrayList[JSONObject]()
          var zoneCodeSet = new util.HashSet[String]()
          var sssZoneCodeList = new util.ArrayList[String]()
          var sssZoneCodeTypeList = new util.ArrayList[String]()
          var sssIncDayList = new util.ArrayList[String]()
          for (obj <- sssArtifidentObjList) {
            if (obj.getString("sss_zone_code") != null && !"null".equals(obj.getString("sss_zone_code")) && !zoneCodeSet.contains(obj.getString("sss_zone_code"))) {
              objList.add(obj)
              zoneCodeSet.add(obj.getString("sss_zone_code"))

              sssZoneCodeList.add(obj.getString("sss_zone_code"))
              sssZoneCodeTypeList.add(obj.getString("sss_zone_code_type"))
              sssIncDayList.add(obj.getString("sss_inc_day"))
            }
          }
          sssZoneCodes = sssZoneCodeList.toArray.mkString("#")
          sssZoneCodeTypes = sssZoneCodeTypeList.toArray.mkString("#")
          sssIncDays = sssIncDayList.toArray.mkString("#")
          sssCnt = sssArtifidentObjList.size
        }
      } catch {
        case e: Exception =>
      }
      unMatchObj.put("sss_zone_code", sssZoneCodes)
      unMatchObj.put("sss_zone_code_type", sssZoneCodeTypes)
      unMatchObj.put("sss_inc_day", sssIncDays)
      unMatchObj.put("sss_cnt", sssCnt)
      (obj._1, unMatchObj)
    })
    matchRdd
  }

  def queryGisTc(rdd: RDD[(String, JSONObject)]): RDD[JSONObject] = {
    var rows = rdd.map(obj => {
      var citycode = JSONUtil.getJsonVal(obj._2, "citycode", "")
      var address = JSONUtil.getJsonVal(obj._2, "address", "").toString
      var logDeptcode = JSONUtil.getJsonVal(obj._2, "log_deptcode", "")
      var logTeamcode = JSONUtil.getJsonVal(obj._2, "log_teamcode", "")
      var logGisDeptcode = JSONUtil.getJsonVal(obj._2, "log_gisdeptcode", "")
      var logSssDeptcode = JSONUtil.getJsonVal(obj._2, "log_sssdeptcode", "")
      var zonecode = JSONUtil.getJsonVal(obj._2, "zonecode", "")
      var teamcode = JSONUtil.getJsonVal(obj._2, "teamcode", "")
      var gisDeptcode = ""
      var gisTeamcode = ""
      if (config.getOnCitycodes.contains(citycode)) { //上线城市跑缺失数据
        var url = String.format(config.getGisByAddr, URLEncoder.encode(address, "UTF-8"), citycode)
        var re = HttpConnection.sendGet(url)
        var content: String = null
        if (re.get("content") != null)
          content = re.get("content").toString
        else
          content = ""
        gisDeptcode = StringUtil.pickGroup1Str(content, "\"dept\":\"(.*?)\"")
        gisTeamcode = StringUtil.pickGroup1Str(content, "\"team\":\"(.*?)\"")
      }
      var gisCorrectFlag = new Integer(-1)
      var sssCorrectFlag = new Integer(-1)
      if (!"".equals(gisDeptcode) && !"".equals(zonecode))
        if (gisDeptcode.equals(zonecode))
          gisCorrectFlag = new Integer(1)
        else
          gisCorrectFlag = new Integer(0)
      if (!"".equals(logSssDeptcode) && !"".equals(zonecode))
        if (logSssDeptcode.equals(zonecode))
          sssCorrectFlag = new Integer(1)
        else
          sssCorrectFlag = new Integer(0)
      obj._2.put("gisdeptcode", gisDeptcode)
      obj._2.put("gisteamcode", gisTeamcode)
      obj._2.put("giscorrectflag", gisCorrectFlag)
      obj._2.put("ssscorrectflag", sssCorrectFlag)
      obj._2
    })
    rows
  }

  def saveData(spark: SparkSession, rdd: RDD[JSONObject], incDay: String): Unit = {
    val count = rdd.count().toInt;
    var rows = rdd.repartition(count / 500000 + 1).map(obj => {
      var waybillNo = JSONUtil.getJsonValObject(obj, "waybillno", "")
      var citycode = JSONUtil.getJsonValObject(obj, "citycode", "")
      var address = JSONUtil.getJsonValObject(obj, "address", "").toString
      var logDeptcode = JSONUtil.getJsonValObject(obj, "log_deptcode", "")
      var logTeamcode = JSONUtil.getJsonValObject(obj, "log_teamcode", "")
      var logGisDeptcode = JSONUtil.getJsonValObject(obj, "log_gisdeptcode", "")
      var logSssDeptcode = JSONUtil.getJsonValObject(obj, "log_sssdeptcode", "")
      var logGroupId = JSONUtil.getJsonValObject(obj, "log_groupid", "")
      var logSrc = JSONUtil.getJsonValObject(obj, "log_src", "")
      var xiaoge_no = JSONUtil.getJsonValObject(obj, "xiaogeNo", "")
      if (xiaoge_no == null || "null".equals(xiaoge_no))
        xiaoge_no = ""
      var deptcode = JSONUtil.getJsonValObject(obj, "deptcode", "")
      var zonecode = JSONUtil.getJsonValObject(obj, "zonecode", "")
      var teamcode = JSONUtil.getJsonValObject(obj, "teamcode", "")
      var opDate = JSONUtil.getJsonValObject(obj, "opdate", "")
      var sssZoneCode = JSONUtil.getJsonValObject(obj, "sss_zone_code", "").toString
      var sssZoneCodeTypes = JSONUtil.getJsonValObject(obj, "sss_zone_code_type", "").toString
      var sssIncDays = JSONUtil.getJsonValObject(obj, "sss_inc_day", "").toString
      var sssCnt = JSONUtil.getJsonValObject(obj, "sss_cnt", "").toString
      if (sssZoneCode.contains("#"))
        sssZoneCode = ""
      var gisDeptcode = JSONUtil.getJsonValObject(obj, "gisdeptcode", "")
      var gisTeamcode = JSONUtil.getJsonValObject(obj, "gisteamcode", "")
      var xiaogeDeptCode = JSONUtil.getJsonValObject(obj, "xiaoge_deptcode", "")
      var xiaogeZoneCode = JSONUtil.getJsonValObject(obj, "xiaoge_zonecode", "")
      var gisCorrectFlag = JSONUtil.getJsonValObject(obj, "giscorrectflag", new Integer(-1))
      var sssCorrectFlag = JSONUtil.getJsonValObject(obj, "ssscorrectflag", new Integer(-1))
      var phone = JSONUtil.getJsonValObject(obj, "phone", "")
      var mobile = JSONUtil.getJsonValObject(obj, "mobile", "")
      var barScanLng = JSONUtil.getJsonValObject(obj, "bar_scan_lng", "")
      var barScanLat = JSONUtil.getJsonValObject(obj, "bar_scan_lat", "")
      var reqTime = JSONUtil.getJsonValObject(obj, "req_time", "")
      var reqCompName = JSONUtil.getJsonValObject(obj, "req_comp_name", "")
      var groupid = JSONUtil.getJsonValObject(obj, "groupid", "")
      var standardization = JSONUtil.getJsonValObject(obj, "standardization", "")
      var groupids = JSONUtil.getJsonValObject(obj, "groupids", "")
      var gis_to_sys_src = JSONUtil.getJsonValObject(obj, "gis_to_sys_src", "")
      var req_province = JSONUtil.getJsonValObject(obj, "req_province", "")
      var req_city = JSONUtil.getJsonValObject(obj, "req_city", "")
      var req_area = JSONUtil.getJsonValObject(obj, "req_area", "")
      var row: Row = null
      try {
        row = RowFactory.create(waybillNo, address, logDeptcode, logTeamcode, gisDeptcode, gisTeamcode, xiaoge_no, deptcode,
          teamcode, opDate, gisCorrectFlag, sssCorrectFlag, logGisDeptcode, logSssDeptcode, sssZoneCode, sssZoneCodeTypes,
          sssIncDays, sssCnt, zonecode, xiaogeDeptCode, xiaogeZoneCode, logGroupId, phone, mobile, barScanLng, barScanLat,
          reqTime, reqCompName, groupid, standardization, groupids, gis_to_sys_src, citycode, req_province, req_city, req_area)
      } catch {
        case e: Exception =>
      }
      row
    })

    var structFields = new util.ArrayList[StructField]()
    structFields.add(DataTypes.createStructField("waybillno", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("address", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("logdeptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("logteamcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("gisdeptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("gisteamcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("xiaoge_no", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("deptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("teamcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("opdate", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("giscorrectflag", DataTypes.IntegerType, true))
    structFields.add(DataTypes.createStructField("ssscorrectflag", DataTypes.IntegerType, true))
    structFields.add(DataTypes.createStructField("log_gisdeptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("log_sssdeptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sss_zone_code", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sss_zone_code_type", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sss_inc_day", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sss_cnt", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("zonecode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("xiaoge_deptcode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("xiaoge_zonecode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("log_groupid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("phone", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("mobile", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bar_scan_lng", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bar_scan_lat", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_time", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_comp_name", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("groupid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("standardization", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("groupids", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("gis_to_sys_src", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("citycode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_province", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_city", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("req_area", DataTypes.StringType, true))
    val structType = DataTypes.createStructType(structFields)

    spark.sql(String.format("use %s", config.getDbGis))
    var ds = spark.createDataFrame(rows, structType)
    var tempView = "%s_temp_view".format(config.getTableGis2)
    ds.createOrReplaceTempView(tempView)
    //    var cityCodeList = new util.ArrayList[String]()
    //    spark.sql("select distinct(citycode) from %s".format(tempView)).rdd.collect().foreach(row => {
    //      cityCodeList.add(row.getString(0))
    //    })
    //    for(i <- 0 to cityCodeList.size() - 1){
    //      try{
    //        spark.sql(String.format("alter table %s drop if exists partition(inc_day = '%s', citycode = '%s')", config.getTableGis2, incDay, cityCodeList.get(i)))
    //        spark.sql(String.format("alter table %s add partition(inc_day = '%s', citycode = '%s')", config.getTableGis2, incDay, cityCodeList.get(i)))
    //      }catch {
    //        case e : Exception => e.printStackTrace()
    //      }
    //    }
    //    spark.sql(String.format("insert into %s partition(inc_day = '%s',citycode) select * from %s", config.getTableGis2, incDay, tempView))
    spark.sql("set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat")
    spark.sql("set mapreduce.input.fileinputformat.split.maxsize=134217728")
    spark.sql("set mapreduce.input.fileinputformat.split.minsize.per.rack=134217728")
    spark.sql("set mapreduce.input.fileinputformat.split.minsize.per.node=134217728")
    try {
      //重新分区的表
      logger.error(s""">>>写入重新分区的表gis_toaddr_stat_new2""")
      spark.sql(String.format("alter table %s drop if exists partition(inc_day = '%s')", config.getTableGis2, incDay))
      spark.sql(String.format("alter table %s add partition(inc_day = '%s')", config.getTableGis2, incDay))
      spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", config.getTableGis2, incDay, tempView))
    } catch {
      case e: Exception => e.printStackTrace()
    }
  }


  def dateDelta(delta: Int): String = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, delta)
    val date = sdf.format(cal.getTime)
    date
  }
}
