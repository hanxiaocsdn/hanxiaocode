package com.sf.gis.scala.oms_shou.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.Serializable;

/**
 * OMS收件TC识别量统计
 * Created by 01368078 on 2019/1/6.
 */
@Entity
public class OmsPuRcg implements Serializable{
    @Column(name = "ID")
    private String id;
    @Column(name = "STAT_DATE")
    private String statDate;    //数据日期
    @Column(name = "PROVINCE")
    private String province;    //省
    @Column(name = "REGION")
    private String region;  //大区
    @Column(name = "CITY_CODE")
    private String cityCode;    //城市代码
    @Column(name = "CITY")
    private String city;    //城市
    @Column(name = "ORDER")
    private int order; //下单量
    @Column(name = "TC")
    private int tc; //识别量
    @Column(name = "TC_NORM")
    private int tcNorm;   //norm识别量
    @Column(name = "TC_SCH")
    private int tcSch;   //sch识别量
    @Column(name = "TC_TC2")
    private int tcTc2; //tc2识别量
    @Column(name = "TC_CHKE")
    private int tcChke; //chke识别量
    @Column(name = "TC_CHKN")
    private int tcChkn; //chkn识别量
    @Column(name = "TC_CHKN_HISSCH")
    private int tcChknHisSch; //chkn hissch识别量
    @Column(name = "TC_CHKN_CGCS")
    private int tcChknCgcs; //chkn cgcs识别量
    @Column(name = "TC_CHKN_OMSKAFKA")
    private int tcChknOmsKafka; //chkn omskafka识别量
    @Column(name = "TC_CHKN_CMS")
    private int tcChknCms; //chkn cms识别量
    @Column(name = "TC_CHKN_OTHER")
    private int tcChknOther; //chkn other识别量
    @Column(name = "TC_ARSS")
    private int tcArss; //arss识别量

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getTc() {
        return tc;
    }

    public void setTc(int tc) {
        this.tc = tc;
    }

    public int getTcNorm() {
        return tcNorm;
    }

    public void setTcNorm(int tcNorm) {
        this.tcNorm = tcNorm;
    }

    public int getTcSch() {
        return tcSch;
    }

    public void setTcSch(int tcSch) {
        this.tcSch = tcSch;
    }

    public int getTcTc2() {
        return tcTc2;
    }

    public void setTcTc2(int tcTc2) {
        this.tcTc2 = tcTc2;
    }

    public int getTcChke() {
        return tcChke;
    }

    public void setTcChke(int tcChke) {
        this.tcChke = tcChke;
    }

    public int getTcChkn() {
        return tcChkn;
    }

    public void setTcChkn(int tcChkn) {
        this.tcChkn = tcChkn;
    }

    public int getTcChknHisSch() {
        return tcChknHisSch;
    }

    public void setTcChknHisSch(int tcChknHisSch) {
        this.tcChknHisSch = tcChknHisSch;
    }

    public int getTcChknCgcs() {
        return tcChknCgcs;
    }

    public void setTcChknCgcs(int tcChknCgcs) {
        this.tcChknCgcs = tcChknCgcs;
    }

    public int getTcChknOmsKafka() {
        return tcChknOmsKafka;
    }

    public void setTcChknOmsKafka(int tcChknOmsKafka) {
        this.tcChknOmsKafka = tcChknOmsKafka;
    }

    public int getTcChknCms() {
        return tcChknCms;
    }

    public void setTcChknCms(int tcChknCms) {
        this.tcChknCms = tcChknCms;
    }

    public int getTcChknOther() {
        return tcChknOther;
    }

    public void setTcChknOther(int tcChknOther) {
        this.tcChknOther = tcChknOther;
    }

    public int getTcArss() {
        return tcArss;
    }

    public void setTcArss(int tcArss) {
        this.tcArss = tcArss;
    }

    public void merge(OmsPuRcg obj){
        this.order += obj.getOrder();
        this.tc += obj.getTc();
        this.tcNorm += obj.getTcNorm();
        this.tcSch += obj.getTcSch();
        this.tcTc2 += obj.getTcTc2();
        this.tcChke += obj.getTcChke();
        this.tcChkn += obj.getTcChkn();
        this.tcChknHisSch += obj.getTcChknHisSch();
        this.tcChknCgcs += obj.getTcChknCgcs();
        this.tcChknOmsKafka += obj.getTcChknOmsKafka();
        this.tcChknCms += obj.getTcChknCms();
        this.tcChknOther += obj.getTcChknOther();
        this.tcArss += obj.getTcArss();
    }
}
