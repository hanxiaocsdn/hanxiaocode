package com.sf.gis.scala.oms_shou.db;

import com.alibaba.fastjson.JSONObject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DbHelper {
    @SuppressWarnings("rawtypes")
    public static <resultClass> List<resultClass> getResultList(String sql, String[] params, Class<?> resultClass, Class<? extends IManager> dbClazz) {
        try (Connection conn = ManagerFactory.createManager(dbClazz).getConn()) {
            ResultSetMapper resultSetMapper = new ResultSetMapper();
            PreparedStatement ps = conn.prepareStatement(sql);
            if (params!= null) {
                for(int i = 0; i < params.length; i++){
                    ps.setString(i + 1, params[i]);
                }
            }
            ResultSet resultSet = ps.executeQuery();
            List resultList = resultSetMapper.mapRersultSetToObject(resultSet, resultClass);
            return resultList;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    public static List<JSONObject> getResultList(String sql, String[] params, Class<? extends IManager> dbClazz){
        List<JSONObject> list = new ArrayList<>();
        try (Connection conn = ManagerFactory.createManager(dbClazz).getConn()) {
            PreparedStatement ps = conn.prepareStatement(sql);
            if(params != null){
                for(int i = 0; i < params.length; i++){
                    ps.setString(i + 1, params[i]);
                }
            }
            ResultSet resultSet = ps.executeQuery();
            int colCnt = resultSet.getMetaData().getColumnCount();
            while (resultSet.next()) {
                JSONObject obj = new JSONObject();
                for(int i = 0; i < colCnt; i++){
                    obj.put(resultSet.getMetaData().getColumnName(i + 1), resultSet.getObject(i + 1));
                }
                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<JSONObject> getResultList(String sql, Class<? extends IManager> dbClazz){
        List<JSONObject> list = new ArrayList<>();
        try (Connection conn = ManagerFactory.createManager(dbClazz).getConn()) {
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery(sql);
            int colCnt = resultSet.getMetaData().getColumnCount();
            while (resultSet.next()) {
                JSONObject obj = new JSONObject();
                for(int i = 0; i < colCnt; i++){
                    obj.put(resultSet.getMetaData().getColumnName(i + 1), resultSet.getObject(i + 1));
                }
                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void insert(String sql, Class<? extends IManager> dbClazz){
        try (Connection conn = ManagerFactory.createManager(dbClazz).getConn()) {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

