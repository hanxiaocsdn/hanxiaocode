package com.sf.gis.scala.oms_pai.start;


import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by 01375125 on 2018/7/9.
 * java工具类
 */
public class ComUtil implements Serializable{

    private static final long serialVersionUID = 147258369L;
    //0 测试的库
    //1 生产的库
    //2 oms离线生产
    //3 错分生产
    //4 输入提示生产
    //5 rds生产
    //6 高低精生产
    //7 错分生产
    //8 收件及错珂

    //66 高低精测试
    //77 错分测试

    public static  String ConfigFile = "7";

    private int flag;
    public int getFlag() {
        return flag;
    }
    public void setFlag(int flag) {
        this.flag = flag;
    }
    public ComUtil(int flag) {
        this.flag = flag;
    }


    /**
     * 获取配置文件中属性
     * @param key: key
     * @return String: value
     */
    public  String getValue(String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {
            String configPath = null;
//            if(flag==0)//测试的库
//                configPath = "conf/oms_pai/debug-config.properties";
//            else if(flag==1)//oms生产的库
//                configPath = "conf/oms_pai/pro-config.properties";
//            else if(flag==2)//离线生产的项目
//                configPath = "conf/oms_pai/offline_pro-config.properties";
//            else if(flag==3)//错分的项目
//                configPath = "conf/oms_pai/wrong-config.properties";
//            else if(flag==4)//输入提示的项目
//                configPath = "conf/oms_pai/input.properties";
//            else if(flag==5)//rds路由分单的项目
//                configPath = "conf/oms_pai/rds.properties";
//            else if(flag==6)//高低精库生产
//                configPath = "conf/oms_pai/precision.properties";
            if(flag==7)//错分生产
                configPath = "conf/oms_pai/wd.properties";
//            else if(flag==8)//oms收件及错珂
//                configPath = "conf/oms_pai/fc.properties";
//            else if(flag==9)//错分明细
//                configPath = "conf/oms_pai/address.properties";
//
//            else if(flag==66)//高低精库测试
//                configPath = "conf/oms_pai/precision_debug.properties";
//            else if(flag==77)//错分测试
//                configPath = "conf/oms_pai/wd_debug.properties";
//            else if(flag==99)//错分明细
//                configPath = "conf/oms_pai/wd_detail_debug.properties";
            System.out.println(configPath);
            in = ComUtil.class.getClassLoader().getResourceAsStream(configPath);
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return value;
    }




    /**
     * 获取某个配置文件中某个属性的值
     * @param key: key
     * @return String: value
     */
    public static String get(String configName,String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {
            in = ComUtil.class.getClassLoader().getResourceAsStream(configName);
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }


    /**
     * 读取资源文件
     * @param fileName: 文件名
     * @return String: 结果
     */
    @SuppressWarnings("unused")
    public static Properties getProp(String fileName) {
        Properties props = new Properties();

        try (InputStreamReader in = new InputStreamReader(ComUtil.class.getClassLoader().getResourceAsStream(fileName), "utf-8")) {
            props.load(in);
        } catch (IOException e) {
            System.out.println("Load properties file error! file name:" + fileName + "\n" + e);
        }
        return props;
    }

    /**
     * 读取资源文件
     * @param key: key
     * @return String: value
     */
    public static String get(String key,Properties props) {
        return props.getProperty(key);
    }


    /**
     * 读取资源文件
     * @param fileName: 文件名
     * @return String: 结果
     */
    @SuppressWarnings("unused")
    public static BufferedReader readFile(String fileName) {
        BufferedReader buff = null;
        try{
            InputStreamReader in = new InputStreamReader(ComUtil.class.getClassLoader().getResourceAsStream(fileName), "utf-8");
            buff = new BufferedReader(in);
        }catch(IOException ignored){

        }
        return buff;
    }


    /**
     * 获得两个字符串日期中所有日期的字符格式集合
     * @param startDateStr: 起始时间
     * @param endDateStr: 终止时间
     * @return List: 日期
     */
    @SuppressWarnings("unused")
    public static List<String> getBetweenDatesStr(String startDateStr, String endDateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<String> dateListStr = new ArrayList<>();
        try {
            Date startDate = sdf.parse(startDateStr);
            Date endDate = sdf.parse(endDateStr);
            List<Date> dateList = getBetweenDates(startDate, endDate);
            for (Date aDateList : dateList) {
                dateListStr.add(sdf.format(aDateList));
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateListStr;
    }


    /**
     * 获得两个日期之间的所有日期列表
     * @param start: 起始时间
     * @param end: 终止时间
     * @return List: 列表
     */
    private static List<Date> getBetweenDates(Date start, Date end) {
        List<Date> result = new ArrayList<>();
        Calendar tempStart = Calendar.getInstance();
        tempStart.setTime(start);
        tempStart.add(Calendar.DAY_OF_YEAR, 1);

        Calendar tempEnd = Calendar.getInstance();
        tempEnd.setTime(end);
        while (tempStart.before(tempEnd)) {
            result.add(tempStart.getTime());
            tempStart.add(Calendar.DAY_OF_YEAR, 1);
        }
        return result;
    }


    public static void main(String[] args) {

//        List<String> betweenDatesStr = getBetweenDatesStr("2018-06-25", "2018-07-05");
//        System.out.println(betweenDatesStr);
//        String name =  JavaUtil.class.getClass().getName();
//        String name =  JavaUtil.class.getName();
//        System.out.println("name:"+name);
//
//        String name1 = get("com.sf.gis.rds.properties","oms.mysql.driver");
//        System.out.println(name1);


    }

}
