package com.sf.gis.scala.oms_shou.main

import java.text.DecimalFormat
import java.util
import java.util.Properties

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.com.sf.gis.scala.oms_shou.constant.FixedConstant
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.oms_shou.constant.{AppType, VariableConstant}
import com.sf.gis.scala.oms_shou.pojo.rds.OmsReqBody
import com.sf.gis.scala.oms_shou.pojo.{AdminArea, ErrCallData, OrderData, OrderInfo}
import com.sf.gis.scala.utils.{ConfigurationUtil, DateUtil, StringUtil}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * @ProductManager:01369702
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:225056，225129，225128
 * @TaskName:rds收件指标系统
 * @Description:rds收件日志解析，指标入库,已下线，转移至 ChkShouLogParser
 *
 */
object MainNew {

  @transient lazy val logger: Logger = LoggerFactory.getLogger(MainNew.getClass)
  val props: Properties = ConfigurationUtil.loadProperties(VariableConstant.CONF, FixedConstant.CHARSET)
  val appName: String = props.getProperty("app.name")

  //揽收表
  val tt_pickup_task_ex = "ods_inc_sgs_core.tt_pickup_task_ex"
  val tt_pickup_task = "ods_inc_sgs_core.tt_pickup_task"
  //写入hbase表
  val hbaseTableName = "dm_gis.rds_omsfrom_tohbase_new"

  def main(args: Array[String]): Unit = {
    var appDays: Int = 0
    if (args.length > 0) {
      appDays = args(0).toInt
    }
    var runFlag = ""
    if (args.length > 1) {
      logger.error("runFlag:" + args(1))
      runFlag = args(1)
    }
    val date: String = DateUtil.dateBefore(FixedConstant.DATE_FORMAT, appDays)
    val dateList: util.ArrayList[String] = getDateList(appDays, date, FixedConstant.DATE_FORMAT, 1)
    val incDay: String = date.replaceAll("-", "")
    val incDayList: util.ArrayList[String] = getDateList(appDays, incDay, FixedConstant.DATE_FORMAT2, 1)
    start(date, dateList, incDay, incDayList, appDays, runFlag)
  }

  def start(date: String, dateList: util.ArrayList[String],
            incDay: String, incDayList: util.ArrayList[String], appDays: Int,
            runFlag: String): Unit = {
    logger.info(s">>>incDay : $incDay")
    val spark = getSparkSession()
    run(spark, date, dateList, incDay, incDayList, appDays, runFlag)
  }

  def getSparkSession(): SparkSession = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    conf.set("hive.exec.dynamic.partition", "true")
    conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    //高峰期配置 begin
    //    conf.set("spark.executor.instances", "60")
    //    conf.set("spark.executor.memory", "40g")
    //    conf.set("spark.yarn.executor.memoryOverhead", "10g")
    //    conf.set("spark.executor.cores", "10")
    //高峰期配置 end
    conf.set("spark.executor.heartbeatInterval", "10000000")

    conf.set("spark.network.timeout", "10000000")

    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")

    val sc = new SparkContext(conf)
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate
    sc.setLogLevel("ERROR")
    spark
  }

  def getDateList(appType: Int, date: String, dateFormat: String, days: Int): util.ArrayList[String] = {
    val dateList = new util.ArrayList[String]()
    dateList.add(date)
    if (appType != AppType.REALTIME_TYPE) {
      //      val sdf = new SimpleDateFormat(dateFormat)
      for (i <- 1 to days) {
        //        if(i<appType){
        dateList.add(0, DateUtil.dateBefore(dateFormat, -i, date))
        //        }
      }
    }
    dateList
  }

  def run(spark: SparkSession, date: String,
          dateList: util.ArrayList[String], incDay: String,
          incDayList: util.ArrayList[String], appDays: Int,
          runFlag: String): Unit = {
    logger.error(">>>incDayList." + incDayList)
    logger.error(">>>dateList." + dateList)
//    var tmpDateList = new util.ArrayList[String]()
//    tmpDateList.add(dateList.last)
    //这里传传一天还是多天,需要确认下数据中异步数据是否会带上订单请求日期
    //如果跨天，则还需要穿多天

    val logs = readDataNew(spark, incDayList,dateList)
//      .repartition(3200)
      .persist(StorageLevel.DISK_ONLY_2) //加载日志
    logger.error(">>>log num : {}", logs.count())

    logger.error(">>>get errCall")
    val errcallDayList = getDateList(appDays, incDay, FixedConstant.DATE_FORMAT2, 2)
    var errCallRdd = getErrCallData(spark.sparkContext, errcallDayList)
    if (errCallRdd == null) {
      return
    }
    errCallRdd = errCallRdd.repartition(500).persist(StorageLevel.DISK_ONLY_2)
    logger.error(">>>errCall num : {}", errCallRdd.count())

    logger.error(">>>parse.")
    val validLogRdd = parseLog(logs).persist(StorageLevel.DISK_ONLY_2)
    //    val validLogRdd = logRdd.filter(tp => {
    //      !VariableConstant.ERROR_KEY.equals(tp._1)
    //    }) //无异常rdd
    logger.error(">>>valid log num : {}", validLogRdd.count())
    logs.unpersist()

    val orderRdd = reduceByOrder(spark, validLogRdd, errCallRdd,
      appDays, incDayList.last) //请求rdd
    clearPersistWithoutId(spark, orderRdd.id)

    if (!"onlySaveHive".equals(runFlag)) {
      logger.error("存储所有数据到hbase")
      saveHbaseDataToHive(spark, orderRdd, incDayList.last, true)
    } else {
      logger.error("存储下call数据到hbase")
      saveHbaseDataToHive(spark, orderRdd, incDayList.last, false)
    }

    clearPersistWithoutId(spark, orderRdd.id)

    val singleDateRdd = orderRdd.map(obj => {
      val orderInfo = JSON.toJavaObject(obj, classOf[OrderInfo])
      //      (JSON.parseObject(JSON.toJSONString(orderInfo, SerializerFeature.PrettyFormat)), pickValuableInfo(orderInfo))
      val orderData = pickValuableInfo(orderInfo)
      orderData.setSyncReqBody(obj.getJSONObject("syncReqBody"))
      orderData.setAsyncReqBody(obj.getJSONObject("asyncReqBody"))
      orderData.setSyncReBody(obj.getJSONObject("syncReBody"))
      orderData.setAsyncReBody(obj.getJSONObject("asyncReBody"))
      orderData.setArssReBody(obj.getJSONObject("arssReBody"))
      val rdsArssReqBody = obj.getJSONObject("rdsArssReqBody")
      val arssReqBody = obj.getJSONObject("arssReqBody")
      if (arssReqBody != null) {
        //此处优先使用这个，但是实际貌似为空，疑似作废
        orderData.setArssReqBody(arssReqBody)
      } else {
        orderData.setArssReqBody(rdsArssReqBody)
      }

      orderData
    }).filter(obj => incDayList.last.equals(obj.getReqDate)).persist(StorageLevel.DISK_ONLY_2)
    //分成两部,先写hbase,清掉写hive
    logger.error("过滤了指定个日志的数据量:" + singleDateRdd.count())
    orderRdd.unpersist()
    clearPersistWithoutId(spark, singleDateRdd.id)
    logger.error(">>>save.")
    saveLogSingle(spark, singleDateRdd, incDayList.last, runFlag)
    if (!"onlySaveHive".equals(runFlag)) {
      logger.error(">>>statistics.")
      clearPersistWithoutId(spark, singleDateRdd.id)
      statLog(singleDateRdd, spark, incDayList)
    }
    logger.error("the end~")
  }

  def clearPersistWithoutId(sparkSession: SparkSession, withoutId: Int): Unit = {
    //移除缓存数据
    val ds: collection.Map[Int, RDD[_]] = sparkSession.sparkContext.getPersistentRDDs
    ds.foreach(x => {
      if (withoutId != x._2.id) {
        logger.error("移除缓存RDD,id:" + x._2.id)
        x._2.unpersist()
      }
    })
  }

  def readDataNew(spark: SparkSession,
                  incDayList: util.ArrayList[String],
                  tmpDateList:util.ArrayList[String]
                 ): RDD[String] = {
    val beginDay = incDayList(incDayList.length - 1)
    val endDay = incDayList(0)
    //    val endDay="20210609"
    val today = DateUtil.dateBefore(FixedConstant.DATE_FORMAT2, 0)
    var logTableName = "dm_gis.chk_shou_log_flink_collect"
    if (today.equals(beginDay) && today.equals(endDay)) {
      logTableName = "dm_gis.chk_shou_log_flink"
    }
    val sql = s"select log from $logTableName where " +
      s" inc_day between '$beginDay' and '$endDay' "
    logger.error(sql)
    val logs = spark.sql(sql).rdd.map(row => {
      row.getString(0)
    }).filter(line => {
      //      (line.contains(VariableConstant.LOG_MARKER) || checkChkKsData(line)) && checkDate(line, dateList)
      line.contains("dataType") && checkDate(line, tmpDateList)
    })
    logs
  }
  def checkDate(line: String, dateList: util.ArrayList[String]): Boolean = {
    for (date <- dateList) {
      if (line.contains(date))
        return true
    }
    false
  }

  def parseLog(logs: RDD[String]): RDD[(String, JSONObject)] = {
    val parser = new LogParser()


    val logRdd = parser.parse(logs)
    logRdd
  }

  def getErrCallData(sc: SparkContext, incDayList: util.ArrayList[String]): RDD[(String, JSONObject)] = {
    var errCallRdd: RDD[(String, JSONObject)] = null
    val errCallGetter = new ErrCallGetter()
    for (day <- incDayList) {
      //      var errCallRddTmp: RDD[(String, JSONObject)] = errCallGetter.getErrCallData(sc, day).persist(StorageLevel.DISK_ONLY_2)
      //      var errCallRddTmp: RDD[(String, JSONObject)] = errCallGetter.getErrCallDataNew(sc, day).persist(StorageLevel.DISK_ONLY_2)
      //      errCallRddTmp = errCallRddTmp.union(errCallRddTmpNew)
      val errCallRddTmp: RDD[(String, JSONObject)] = errCallGetter.getErrCallDataNewShidian(sc, day).persist(StorageLevel.DISK_ONLY_2)
      //      errCallRddTmp = errCallRddTmp.union(errCallRddTmpNewShiDian)
      logger.error("错柯数量:" + errCallRddTmp.count())
      if (errCallRddTmp.count() > 0) {
        if (errCallRdd == null)
          errCallRdd = errCallRddTmp
        else
          errCallRdd = errCallRdd.union(errCallRddTmp)
      }
      //      else {
      //        errIncDaySet.add(day)
      //      }
    }
    if (errCallRdd == null) {
      errCallRdd = sc.makeRDD(List())
    }
    errCallRdd
  }

  def findReqDate(obj: JSONObject) = {
    val orderInfo = JSON.toJavaObject(obj, classOf[OrderInfo])
    val orderData = pickValuableInfo(orderInfo)
    (orderData.getReqDate, orderData.isAsyncReqFlag, orderData.isSyncReqFlag)
  }

  def reduceByOrder(spark: SparkSession, rdd: RDD[(String, JSONObject)],
                    errCallRdd: RDD[(String, JSONObject)],
                    appDays: Int, incDay: String
                   ): RDD[JSONObject] = {
    val omsFromSysOrderNoRdd = rdd.reduceByKey((obj1, obj2) => { //按reqId聚合
      val chkToOmsBody = mergeChkToOms(obj1, obj2)
      obj1.fluentPutAll(obj2)
      if (chkToOmsBody != null) {
        obj1.put("chkOmsRebody", chkToOmsBody)
      }
      obj1
    }).filter(obj => {
      val (reqDate, asyncReqFlag, syncReqFlag) = findReqDate(obj._2)
      ((asyncReqFlag || syncReqFlag) && incDay.equals(reqDate))
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("按系统订单聚合数量:" + omsFromSysOrderNoRdd.count())
    rdd.unpersist()
    var mergePickUpRdd = omsFromSysOrderNoRdd
    if (appDays != AppType.REALTIME_TYPE) {
      val omsFromOrderNoRdd = omsFromSysOrderNoRdd.map(obj => { //以sysOrderNo作为key
        val orderNo = obj._2.getString(VariableConstant.ORDERNO_KEY)
        val jsonObject = new JSONObject()
        jsonObject.put(VariableConstant.SYS_ORDERNO_KEY, obj._2.getString(VariableConstant.SYS_ORDERNO_KEY))
        (orderNo, jsonObject)
      }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY_2)
      logger.error("按订单聚合数量:" + omsFromOrderNoRdd.count())
      //如果出现资源不足， 可将lefftOuterJoin改为union，在提出SysorderNo,在合并
      logger.error("获取揽收信息,key为系统订单号和订单号组成")
      val pickUpRdd = selectAllPickUpInfo(spark, incDay, appDays)
      mergePickUpRdd = omsFromSysOrderNoRdd.union(omsFromOrderNoRdd)
        .leftOuterJoin(pickUpRdd).map(obj => {
        val leftObj = obj._2._1
        val rightObj = obj._2._2
        if (rightObj.nonEmpty) {
          val pickUpArray = rightObj.get.getJSONArray("pickup")
          if (pickUpArray.size() > 0) {
            val pickUpObj = pickUpArray.getJSONObject(0)
            val pickUpObjRet = new JSONObject()
            pickUpObjRet.put("pick_up_tc", pickUpObj.getString("tc"))
            pickUpObjRet.put("resource_id", pickUpObj.getString("resource_id"))
            pickUpObjRet.put("current_state", pickUpObj.getString("current_state"))
            leftObj.put("pickupBody", pickUpObjRet)
          }
        }
        (leftObj.getString(VariableConstant.SYS_ORDERNO_KEY), leftObj)
      }).reduceByKey((obj1, obj2) => {
        obj1.fluentPutAll(obj2)
        obj1
      }).persist(StorageLevel.DISK_ONLY_2)
      logger.error("关联揽收后的数量:" + mergePickUpRdd.count())
      pickUpRdd.unpersist()
      omsFromOrderNoRdd.unpersist()
      omsFromSysOrderNoRdd.unpersist()
    } else {
      logger.error("当天数据，不关联揽收")
    }
    val newRdd = mergePickUpRdd.union(errCallRdd).filter(obj => { //过滤无sysOrderNo
      obj._1 != null
    }).reduceByKey((obj1, obj2) => { //按sysOrderNo聚合
      obj1.fluentPutAll(obj2)
      obj1
    }).map(_._2).persist(StorageLevel.DISK_ONLY_2)
    logger.error(">>>order num : {}", newRdd.count())
    mergePickUpRdd.unpersist()
    errCallRdd.unpersist()
    newRdd
  }

  def reduceByOrderNew(spark: SparkSession, rdd: RDD[(String, JSONObject)],
                       errCallRdd: RDD[(String, JSONObject)],
                       appDays: Int, incDayList: util.ArrayList[String]): RDD[JSONObject] = {
    val omsFromSysOrderNoRdd = rdd.reduceByKey((obj1, obj2) => { //按reqId聚合
      val chkToOmsBody = mergeChkToOms(obj1, obj2)
      obj1.fluentPutAll(obj2)
      if (chkToOmsBody != null) {
        obj1.put("chkOmsRebody", chkToOmsBody)
      }
      obj1
    }).map(obj => { //以sysOrderNo作为key
      val sysOrderNo = obj._2.getString(VariableConstant.SYS_ORDERNO_KEY)
      (sysOrderNo, obj._2)
    }).filter(_._1 != null)
      .reduceByKey((obj1, obj2) => {
        obj1.fluentPutAll(obj2)
        obj1
      }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("按系统订单聚合数量:" + omsFromSysOrderNoRdd.count())
    rdd.unpersist()
    var mergePickUpRdd = omsFromSysOrderNoRdd
    if (appDays != AppType.REALTIME_TYPE) {
      val omsFromOrderNoRdd = omsFromSysOrderNoRdd.map(obj => { //以sysOrderNo作为key
        val ret = new JSONObject()
        ret.put(VariableConstant.ORDERNO_KEY, obj._2.getString(VariableConstant.ORDERNO_KEY))
        ret.put(VariableConstant.SYS_ORDERNO_KEY, obj._2.getString(VariableConstant.SYS_ORDERNO_KEY))
        val orderNo = obj._2.getString(VariableConstant.ORDERNO_KEY)
        (orderNo, ret)
      }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY_2)
      logger.error("按订单聚合数量:" + omsFromOrderNoRdd.count())
      //如果出现资源不足， 可将lefftOuterJoin改为union，在提出SysorderNo,在合并
      logger.error("获取揽收信息,key为系统订单号和订单号组成")
      val pickUpRdd = selectAllPickUpInfo(spark, incDayList.get(incDayList.size() - 1), appDays)
      val tmp_order_type_flag = "1-1"
      val mergePickUpSysOrderNoRdd = omsFromSysOrderNoRdd.union(pickUpRdd)
        .reduceByKey((obj1, obj2) => {
          obj1.fluentPutAll(obj2)
          obj1
        }).map(obj => {
        //reduceByKey只有一个时不会进入
        obj._2.put(tmp_order_type_flag, VariableConstant.SYS_ORDERNO_KEY)
        obj
      }).filter(obj => obj._2.getString(VariableConstant.SYS_ORDERNO_KEY) != null)
        .persist(StorageLevel.DISK_ONLY_2)
      logger.error("按系统订单关联揽收数量:" + mergePickUpSysOrderNoRdd.count())
      omsFromSysOrderNoRdd.unpersist()

      val tmp_sys_order_data_flag = "2-2"
      val mergePickUpOrderNoRdd = omsFromOrderNoRdd
        .union(pickUpRdd)
        .reduceByKey((obj1, obj2) => {
          //订单号存在重复，需要将系统订单号存储，关联完揽收后，再恢复
          var sys_order_data_obj1 = obj1.getJSONObject(tmp_sys_order_data_flag)
          if (sys_order_data_obj1 == null) {
            sys_order_data_obj1 = new JSONObject()
            if (obj1.getString(VariableConstant.SYS_ORDERNO_KEY) != null) {
              sys_order_data_obj1.put(obj1.getString(VariableConstant.SYS_ORDERNO_KEY), obj1.getString(VariableConstant.SYS_ORDERNO_KEY))
            }
          }
          if (obj2.getJSONObject(tmp_sys_order_data_flag) != null) {
            sys_order_data_obj1.fluentPutAll(obj2.getJSONObject(tmp_sys_order_data_flag))
          } else if (obj2.getString(VariableConstant.SYS_ORDERNO_KEY) != null) {
            sys_order_data_obj1.put(obj2.getString(VariableConstant.SYS_ORDERNO_KEY), obj2.getString(VariableConstant.SYS_ORDERNO_KEY))
          }
          obj1.fluentPutAll(obj2)
          obj1.put(tmp_sys_order_data_flag, sys_order_data_obj1)
          obj1
        }).filter(obj => obj._2.getString(VariableConstant.ORDERNO_KEY) != null)
        .flatMap(obj => {
          obj._2.put(tmp_order_type_flag, VariableConstant.ORDERNO_KEY)
          val list = new util.ArrayList[(String, JSONObject)]()
          val sys_order_data_obj = obj._2.getJSONObject(tmp_sys_order_data_flag)
          if (sys_order_data_obj != null) {
            for (key <- sys_order_data_obj.keySet()) {
              list.add((key, obj._2))
            }
          } else {
            list.add((obj._2.getString(VariableConstant.SYS_ORDERNO_KEY), obj._2))
          }
          list.iterator()
        }).persist(StorageLevel.DISK_ONLY_2)
      //      val mergePickUpOrderNoRdd = omsFromOrderNoRdd.repartition(7200)
      //        .union(pickUpRdd)
      //        .repartition(7200)
      //        .reduceByKey((obj1,obj2)=>{
      //          //订单号存在重复，需要将系统订单号存储，关联完揽收后，再恢复
      //          var sys_order_data_obj1 = obj1.getJSONObject(tmp_sys_order_data_flag)
      //          if(sys_order_data_obj1 == null){
      //            sys_order_data_obj1 = new JSONObject()
      //            if(obj1.getString(VariableConstant.SYS_ORDERNO_KEY)!=null){
      //              sys_order_data_obj1.put(obj1.getString(VariableConstant.SYS_ORDERNO_KEY),obj1.getString(VariableConstant.SYS_ORDERNO_KEY))
      //            }
      //          }
      //          if(obj2.getJSONObject(tmp_sys_order_data_flag)!=null){
      //            sys_order_data_obj1.fluentPutAll(obj2.getJSONObject(tmp_sys_order_data_flag))
      //          }else if(obj2.getString(VariableConstant.SYS_ORDERNO_KEY) != null){
      //            sys_order_data_obj1.put(obj2.getString(VariableConstant.SYS_ORDERNO_KEY),obj2.getString(VariableConstant.SYS_ORDERNO_KEY))
      //          }
      //          obj1.fluentPutAll(obj2)
      //          obj1.put(tmp_sys_order_data_flag,sys_order_data_obj1)
      //          obj1
      //        }).filter(obj=>obj._2.getString(VariableConstant.ORDERNO_KEY)!=null)
      //        .flatMap(obj=>{
      //          obj._2.put(tmp_order_type_flag,VariableConstant.ORDERNO_KEY)
      //          val list = new util.ArrayList[(String, JSONObject)]()
      //          val sys_order_data_obj = obj._2.getJSONObject(tmp_sys_order_data_flag)
      //          if(sys_order_data_obj != null){
      //            for (key <- sys_order_data_obj.keySet()) {
      //              list.add((key,obj._2))
      //            }
      //          }else{
      //            list.add((obj._2.getString(VariableConstant.SYS_ORDERNO_KEY),obj._2))
      //          }
      //          list.iterator()
      //        }).persist(StorageLevel.DISK_ONLY_2)
      logger.error("按订单关联揽收数量:" + mergePickUpOrderNoRdd.count())
      omsFromOrderNoRdd.unpersist()
      pickUpRdd.unpersist()
      mergePickUpRdd = mergePickUpSysOrderNoRdd.union(mergePickUpOrderNoRdd)
        .map(obj => {
          val pickUpArray = obj._2.getJSONArray("pickup")
          if (pickUpArray != null && pickUpArray.size() > 0) {
            val pickUpObj = pickUpArray.getJSONObject(0)
            val pickUpObjRet = new JSONObject()
            pickUpObjRet.put("pick_up_tc", pickUpObj.getString("tc"))
            pickUpObjRet.put("resource_id", pickUpObj.getString("resource_id"))
            pickUpObjRet.put("current_state", pickUpObj.getString("current_state"))
            obj._2.put("pickupBody", pickUpObjRet)
            obj._2.remove("pickup")
          }
          obj
        }).reduceByKey((obj1, obj2) => {
        //以系统订单号为准，订单号会存在重复去重
        val tmp_key1 = obj1.getString(tmp_order_type_flag)
        val tmp_key2 = obj2.getString(tmp_order_type_flag)
        if (tmp_key1.equals(VariableConstant.SYS_ORDERNO_KEY)) {
          if (!obj1.containsKey("pickupBody")) {
            obj1.put("pickupBody", obj2.getJSONObject("pickupBody"))
          }
          obj1
        } else {
          if (!obj2.containsKey("pickupBody")) {
            obj2.put("pickupBody", obj1.getJSONObject("pickupBody"))
          }
          obj2
        }
      }).filter(obj => obj._2.getString(tmp_order_type_flag).equals(VariableConstant.SYS_ORDERNO_KEY))
        .map(obj => {
          obj._2.remove(tmp_order_type_flag)
          obj
        }).persist(StorageLevel.DISK_ONLY_2)
      logger.error("关联揽收后的总数量:" + mergePickUpRdd.count())
      mergePickUpOrderNoRdd.unpersist()
      mergePickUpSysOrderNoRdd.unpersist()
    } else {
      logger.error("当天数据，不关联揽收")
    }
    val newRdd = mergePickUpRdd.union(errCallRdd).filter(obj => { //过滤无sysOrderNo
      obj._1 != null
    }).reduceByKey((obj1, obj2) => { //按sysOrderNo聚合
      obj1.fluentPutAll(obj2)
      obj1
    }).map(_._2)
    logger.error(">>>关联错柯后的数据量:" + newRdd.count())
    mergePickUpRdd.unpersist()
    errCallRdd.unpersist()
    newRdd
  }

  def mergeChkToOms(obj1: JSONObject, obj2: JSONObject): JSONObject = {
    val chkOmsRebody1 = obj1.getJSONObject("chkOmsRebody")
    val chkOmsRebody2 = obj2.getJSONObject("chkOmsRebody")
    if (chkOmsRebody1 == null && chkOmsRebody2 != null) {
      chkOmsRebody2
    } else if (chkOmsRebody1 != null && chkOmsRebody2 == null) {
      chkOmsRebody1
    } else if (chkOmsRebody1 == null && chkOmsRebody2 == null) {
      chkOmsRebody1
    } else {
      val handleTime1 = chkOmsRebody1.getString("handleTime")
      val handleTime2 = chkOmsRebody2.getString("handleTime")
      if (handleTime1 == null && handleTime2 != null) {
        chkOmsRebody2
      } else if (handleTime1 != null && handleTime2 == null) {
        chkOmsRebody1
      } else if (handleTime1 == null && handleTime2 == null) {
        chkOmsRebody1
      } else {
        if (handleTime1.compareTo(handleTime2) >= 0) {
          chkOmsRebody1
        } else {
          chkOmsRebody2
        }
      }
    }
  }

  /**
   * 提取需要的字段
   *
   * @param orderInfo : 数据体
   * @return
   */
  def pickValuableInfo(orderInfo: OrderInfo): OrderData = {
    val orderData = new OrderData
    val arssReqBody = orderInfo.getArssReqBody
    val arssReBody = orderInfo.getArssReBody
    val syncReqBody = orderInfo.getSyncReqBody
    val syncReBody = orderInfo.getSyncReBody
    val asyncReqBody = orderInfo.getAsyncReqBody
    val asyncReBody = orderInfo.getAsyncReBody
    val rdsArssReqBody = orderInfo.getRdsArssReqBody
    val errCallBody = orderInfo.getErrCallBody
    orderData.setSysOrderNo(orderInfo.getSysOrderNo)
    orderData.setChkKsReBody(orderInfo.getChkKsReBody)
    orderData.setChkKsReqBody(orderInfo.getChkKsReqBody)
    orderData.setChkOmsRebody(orderInfo.getChkOmsRebody)
    orderData.setPickupBody(orderInfo.getPickupBody)
    orderData.setRequestBuildingBody(orderInfo.getRequestBuildingBody)
    orderData.setResponseBuildingBody(orderInfo.getResponseBuildingBody)
    var omsReqData: OmsReqBody = null

    CopyProperties.syncReq2OrderData(orderData, syncReqBody)
    if (syncReqBody != null) {
      omsReqData = syncReqBody
    }

    CopyProperties.syncRe2OrderData(orderData, syncReBody)

    CopyProperties.asyncReq2OrderData(orderData, asyncReqBody)
    if (asyncReqBody != null) {
      omsReqData = asyncReqBody
    }

    CopyProperties.asyncRe2OrderData(orderData, asyncReBody)

    //    CopyProperties.omsReqData2OrderData(orderData, omsReqData)

    CopyProperties.rdsArssReq2OrderData(orderData, rdsArssReqBody)

    CopyProperties.arssReq2OrderData(orderData, arssReqBody)

    CopyProperties.arssRe2OrderData(orderData, arssReBody)
    CopyProperties.omsReqData2OrderData(orderData, omsReqData)
    CopyProperties.errCall2OrderData(orderData, errCallBody)

    if (arssReBody != null) {
      orderData.setStatus(VariableConstant.UNMATCH_STATUS)
      orderData.setSrc(VariableConstant.SRC_CHKE_CUR)
      orderData.setDeptCode(orderData.getArssDeptCode)
      orderData.setTeamCode(orderData.getArssTeamCode)
      orderData.setAoiCode(orderData.getArssAoiCode)
      orderData.setAoiId(orderData.getArssAoiId)
    } else if (asyncReBody != null) {
      orderData.setStatus(orderData.getAsyncReStatus)
      orderData.setSrc(orderData.getAsyncSrc)
      orderData.setGroupId(orderData.getAsyncGroupId)
      orderData.setDeptCode(orderData.getAsyncDeptCode)
      orderData.setTeamCode(orderData.getAsyncTeamCode)
      orderData.setAoiCode(orderData.getAsyncAoiCode)
      orderData.setAoiId(orderData.getAsyncAoiId)
    } else {
      orderData.setStatus(orderData.getSyncReStatus)
      orderData.setSrc(orderData.getSyncSrc)
      orderData.setGroupId(orderData.getSyncGroupId)
      orderData.setDeptCode(orderData.getSyncDeptCode)
      orderData.setTeamCode(orderData.getSyncTeamCode)
      orderData.setAoiCode(orderData.getSyncAoiCode)
      orderData.setAoiId(orderData.getSyncAoiId)
    }
    orderData
  }

  def statLog(orderRdd: RDD[OrderData], spark: SparkSession, incDayList: util.ArrayList[String]): Unit = {

    val statistics = new LogStatistics
    val adminAreaMap: util.Map[String, util.List[AdminArea]] = new AdminAreaLoader().loadAdminArea()
//    var incDay = new util.ArrayList[String]()
//    incDay.add(incDayList.last)

    logger.error(">>>stat pu buz")
    statistics.statPuBuz(orderRdd, incDayList.last, adminAreaMap,spark)

    logger.error(">>>stat pu tc")
    logger.error("获取楼栋范围aoiid数据")
    val joinBidRdd = joinBid(orderRdd, spark)
    statistics.statPuTc(joinBidRdd, incDayList.last, adminAreaMap, spark, null, null)
  }

  /**
   * 左关联，左表存在少部分key倾斜，采用单独处理部分key的方式
   *
   * @param left    左表
   * @param right   右表
   * @param hashNum 散列系数，扩容倍数
   * @param topLean 需要单独处理的倾斜数据量
   */
  def leftOuterJoinOfLeftLeanElem(left: RDD[(String, Object)], right: RDD[(String, Int)], hashNum: Int, topLean: Int = 10): RDD[(String, (Object, Option[Int]))] = {
    val keyCounts = left.map(obj => (obj._1, 1)).reduceByKey(_ + _).sortBy(-_._2).take(topLean)
    val keys = keyCounts.map(obj => obj._1)
    val counts = keyCounts.map(obj => obj._2).sum
    logger.error("单独处理的keys:" + keyCounts.mkString(","))
    logger.error("单独处理的总数量:" + counts)
    //拆分数据为独立处理的key和非独立处理的key
    val leftHashKeyData = left.filter(obj => keys.contains(obj._1))
    val leftOtherData = left.filter(obj => !keys.contains(obj._1))
    val rightHashKeyData = right.filter(obj => keys.contains(obj._1))
    val rightOtherData = right.filter(obj => !keys.contains(obj._1))
    //先关联其他key数据
    val otherJoin = leftOtherData.leftOuterJoin(rightOtherData)
    //扩展单独处理的数据
    val leftHashKeyDataExpand = leftHashKeyData.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      (("00" + hashPrefix, obj._1), obj._2)
    })
    val rightHashKeyDataExpand = rightHashKeyData.flatMap(obj => {
      val dataArray = new ArrayBuffer[((String, String), Int)]()
      for (i <- 0 until hashNum) {
        dataArray.append((("00" + i, obj._1), obj._2))
      }
      dataArray.iterator
    })
    //关联数据
    val hashKeyJoin = leftHashKeyDataExpand.leftOuterJoin(rightHashKeyDataExpand).map(obj => (obj._1._2, obj._2))
    hashKeyJoin.union(otherJoin)
  }

  def convertBidAoi(spark: SparkSession, bidAoiInfoRdd: RDD[(String, Int)]) = {
    val bidAoiInfoMap = bidAoiInfoRdd.map(obj => {
      ((obj._1.hashCode % 5000).toString, (obj._1, obj._2))
    }).groupByKey().map(obj => {
      val map = new util.HashMap[String, Int]()
      val iter = obj._2.iterator
      while (iter.hasNext) {
        val tmp = iter.next()
        map.put(tmp._1, tmp._2)
      }
      (obj._1, map)
    }).collectAsMap()
    logger.error("bidAoi hash后数量:" + bidAoiInfoMap.size)
    //    logger.error("keys:"+bidAoiInfoMap.keySet.mkString(","))
    spark.sparkContext.broadcast(bidAoiInfoMap)
  }

  def joinBid(resultLog: RDD[OrderData], spark: SparkSession): RDD[OrderData] = {
    val bidAoiInfoRdd = fetchBidInfo(spark)
    logger.error("转化为hash值")
    val bidAoiBc = convertBidAoi(spark, bidAoiInfoRdd)
    bidAoiInfoRdd.unpersist()
    val resultLogFinal = resultLog.map(obj => {
      val aoiId = obj.getAoiId
      if (aoiId != null && !aoiId.isEmpty) {
        val hashValue = (aoiId.hashCode % 5000).toString
        val bidMap = bidAoiBc.value
        if (!aoiId.isEmpty && bidMap.contains(hashValue)) {
          val aoiidInfo = bidMap.get(hashValue).get
          if (aoiidInfo.contains(aoiId)) {
            obj.setBidAoiState(aoiidInfo.get(aoiId).toString)
          }
        }
      }
      obj
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("关联楼栋aoiid数据完毕:" + resultLogFinal.count())
    resultLog.unpersist()
    resultLogFinal
  }

  def joinBidNew(resultLog: RDD[OrderData], spark: SparkSession): RDD[OrderData] = {
    val bidAoiInfoRdd = fetchBidInfo(spark)
    val resultLogNoFinalAoi = resultLog.filter(obj => obj.getAoiId == null || obj.getAoiId.isEmpty).persist(StorageLevel.DISK_ONLY_2)
    logger.error("无aoi数据：" + resultLogNoFinalAoi.count())
    val resultLogFinalAoi = resultLog.filter(obj => obj.getAoiId != null && !obj.getAoiId.isEmpty).persist(StorageLevel.DISK_ONLY_2)
    logger.error("有aoi数据：" + resultLogFinalAoi.count())
    resultLog.unpersist()
    val resultLogFinal = leftOuterJoinOfLeftLeanElem(resultLogFinalAoi.map(obj => {
      (MD5Util.getMD5(obj.getAoiId), obj)
    }), bidAoiInfoRdd, 10, 50).map(obj => {
      val left = obj._2._1.asInstanceOf[OrderData]
      val rightOp = obj._2._2
      if (rightOp.nonEmpty) {
        val right = rightOp.get
        left.setBidAoiState(right + "")
      }
      left
    }).union(resultLogNoFinalAoi).persist(StorageLevel.DISK_ONLY_2)
    logger.error("关联楼栋aoiid数据完毕:" + resultLogFinal.count())
    resultLogFinalAoi.unpersist()
    resultLogNoFinalAoi.unpersist()
    bidAoiInfoRdd.unpersist()
    resultLogFinal
  }

  def fetchBidInfo(spark: SparkSession): RDD[(String, Int)] = {
    val sql = " with a as (select distinct aoi_id from dm_gis.t_dm_tmp_aoi_sp_cnt_dist_v1_aoi_list )," +
      " b as (select distinct aoi_id from dm_gis.bid_aoi_reject where data_type='publish') " +
      " select a.aoi_id,if(b.aoi_id is null,0,1) reject from a left join b on a.aoi_id=b.aoi_id "
    logger.error(sql)
    val bidAoiInfoRdd = spark.sql(sql).rdd.map(obj => {
      (obj.getString(0), obj.getInt(1))
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("楼栋的aoi数量:" + bidAoiInfoRdd.count())
    logger.error("楼栋的剔除aoi数量" + bidAoiInfoRdd.filter(obj => obj._2 == 1).count())
    bidAoiInfoRdd
  }

  def fetchAoiidReject(spark: SparkSession): Broadcast[Array[String]] = {
    val sql = "select aoi_id from dm_gis.bid_aoi_reject where data_type='publish' and aoi_id is not null and aoi_id<> ''  group by aoi_id"
    logger.error(sql)
    val dataArray = spark.sql(sql).rdd.map(obj => {
      obj.getString(0)
    }).collect()
    spark.sparkContext.broadcast(dataArray)
  }

  def fetchAoiidSet(spark: SparkSession): Broadcast[Array[String]] = {
    val sql = "select aoi_id from dm_gis.t_dm_tmp_aoi_sp_cnt_dist_v1_aoi_list where aoi_id is not null and aoi_id<> '' group by aoi_id"
    logger.error(sql)
    val dataArray = spark.sql(sql).rdd.map(obj => {
      obj.getString(0)
    }).collect()
    spark.sparkContext.broadcast(dataArray)
  }

  def saveLogSingle(spark: SparkSession, orderDataRdd: RDD[OrderData],
                    incDay: String, runFlag: String): Unit = {
    val conservator = new LogConservator
    logger.error("保存日期:" + incDay)
    if (!"onlySaveHive".equals(runFlag)) {
      logger.error(">>>save errCall data")
      val errCallData = getErrCallData(orderDataRdd.filter(obj => {
        obj.isErrCallFlag && (obj.isSyncReqFlag || obj.isAsyncReqFlag)
      })).persist(StorageLevel.DISK_ONLY_2)
      logger.error(">>>union errCall num : {}", errCallData.count())
      conservator.saveErrCallData(errCallData)
      errCallData.unpersist()
    }

    logger.error(">>>save to hive.")
    val rdd = orderDataRdd.filter(tp => {
      tp.isSyncReqFlag || tp.isAsyncReqFlag
    })
    conservator.save(spark, rdd, incDay)
    logger.error(">>>over")
  }

  def saveHbaseDataToHive(spark: SparkSession, orderDataRdd: RDD[JSONObject],
                          incDay: String, saveNotUnderCall: Boolean): Unit = {

    import spark.implicits._
    //转换rdd，设置put[key,value]得到最终的要存入的结果集
    val inputRdd = orderDataRdd.map(json => {
      val orderInfo = JSON.toJavaObject(json, classOf[OrderInfo])
      val orderData = pickValuableInfo(orderInfo)
      json.put("errcallflag", orderData.isErrCallFlag)
      json.put("syncreqdatetime", orderData.getSyncReqDateTime)
      json.put("citycode", orderData.getCityCode)
      json.put("address", orderData.getAddress)
      json.put("phone", orderData.getPhone)
      json.put("mobile", orderData.getMobile)
      json.put("arssdeptcode", orderData.getArssDeptCode)
      json.put("arssteamcode", orderData.getArssTeamCode)
      json.put("arssempcode", orderData.getArssEmpCode)
      json.put("errcalladdrabb", orderData.getErrCallAddrabb)
      json.put("errcallteamid", orderData.getErrCallTeamid)
      json.put("errcallempid", orderData.getErrCallEmpid)
      json.put("matchsrc", orderData.getMatchSrc)
      json.put("matchgrouid", orderData.getMatchGroupId)
      json.put("matchdeptcode", orderData.getMatchDeptCode)
      json.put("matchteamcode", orderData.getMatchTeamCode)
      json.put("pickUpBody", orderData.getPickupBody)
      json.put("isNotUnderCall", orderData.getIsNotUnderCall)
      val orderNo: String = json.getString(VariableConstant.SYS_ORDERNO_KEY)

      if ((orderData.isSyncReqFlag || orderData.isAsyncReqFlag) && incDay.equals(orderData.getReqDate) && !StringUtil.isBlank(orderNo)) {
        val key = getKeyByStr(orderNo)
        (orderNo, key, orderData.getIsNotUnderCall, json.toJSONString.replaceAll("[\\r\\n\\t]", ""))
      } else {
        (null, null, null, null)
      }
    }).filter(obj => {
      obj._1 != null
    })
    var tmpViewName = "tmp_undercall" + System.currentTimeMillis()
    //下call
    val isNotUnderCallRdd = inputRdd.filter(obj => !"1".equals(obj._3))
      .map(obj => {
        (Random.nextInt(300), (obj._2, obj._4))
      }).repartition(300).values.toDF("rowKey", "data").createOrReplaceTempView(tmpViewName)
    var sql = s"insert overwrite table ${hbaseTableName} partition(inc_day='${incDay}',isnotundercall='0') select * from $tmpViewName "
    logger.error(sql)
    spark.sql(sql)
    logger.error("下call写入hbase分区完毕")
    if (saveNotUnderCall) {
      //非下call
      tmpViewName = "tmp_not_undercall" + System.currentTimeMillis()
      val isUnderCallRdd = inputRdd.filter(obj => "1".equals(obj._3))
        .map(obj => {
          (Random.nextInt(500), (obj._2, obj._4))
        }).repartition(500).values.toDF("rowKey", "data").createOrReplaceTempView(tmpViewName)
      sql = s"insert overwrite table ${hbaseTableName} partition(inc_day='${incDay}',isnotundercall='1') select * from $tmpViewName "
      logger.error(sql)
      spark.sql(sql)
      logger.error("非下call写入hbase分区完毕")
    }
  }


  /**
   * 根据运单号计算key
   *
   * @param waybillNo : 运单号
   * @return
   */
  def getKeyByStr(waybillNo: String): String = {
    var salt = (waybillNo.hashCode() % 30).toString.replace("-", "")
    val df = new DecimalFormat("00")
    if (salt.length == 1) {
      //个位数前面需要补0
      salt = df.format(Integer.parseInt(salt))
    }
    val key = salt + "_" + waybillNo
    key
  }


  def getErrCallData(errCallData: RDD[OrderData]): RDD[ErrCallData] = {
    val errCallRdd1 = errCallData.map(obj => {
      val errCallData = new ErrCallData
      val reqDate = obj.getReqDate
      val reqTime = obj.getReqTime
      var cityCode = obj.getCityCode
      if (cityCode == null || "".equals(cityCode)) {
        cityCode = obj.getErrCallTeamid.replaceAll("(\\d*).*", "$1")
      }
      val sysOrderNo = obj.getSysOrderNo.replaceAll("'", "")
      val province = obj.getProvince.replaceAll("'", "")
      val city = obj.getCity.replaceAll("'", "")
      val county = obj.getCounty.replaceAll("'", "")
      val address = obj.getAddress.replaceAll("'", "").replaceAll("['\\\\]*", "")
      val matchSrc = obj.getSrc.replaceAll("'", "")
      val srcDetail = obj.getMatchChkDeptSrc.replaceAll("'", "")
      val matchDept = obj.getDeptCode.replaceAll("'", "")
      val matchTeam = obj.getTeamCode.replaceAll("'", "")
      val matchGroupId = obj.getGroupId.replaceAll("'", "")
      val errCallDept = obj.getErrCallDept.replaceAll("'", "")
      val errCallTeam = obj.getErrCallTeamid.replaceAll("'", "")
      val errCallAddrabb = obj.getErrCallAddrabb.replaceAll("'", "")
      val errCallAddrDept = obj.getErrCallAddrDept.replaceAll("'", "")
      val errCallAddrTeamCode = obj.getErrCallAddrTeamCode.replaceAll("'", "")
      val errCallTcSouce = obj.getErrCallTcSouce.replaceAll("'", "")
      val chkEmpId = obj.getErrCallOperName.replaceAll("'", "")
      val chkModifyUser = ""
      var chkDept = ""
      var chkTeam = ""
      var miningDept = ""
      var miningTeam = ""
      if ("work".equals(errCallTcSouce) || "CGCS_KDD".equals(errCallTcSouce)) {
        miningDept = errCallAddrDept
        miningTeam = errCallAddrTeamCode
      } else if ("cgcs".equals(errCallTcSouce) || "CK".equals(errCallTcSouce)) {
        chkDept = errCallAddrDept
        chkTeam = errCallAddrTeamCode
      }
      val errCallDate = obj.getErrCallDate
      val id = reqDate + "_" + sysOrderNo
      errCallData.setId(id)
      errCallData.setReqDate(reqDate)
      errCallData.setReqTime(reqTime)
      errCallData.setSysOrderNo(sysOrderNo)
      errCallData.setProvince(province)
      errCallData.setCity(city)
      errCallData.setCounty(county)
      errCallData.setCityCode(cityCode)
      errCallData.setAddress(address)
      errCallData.setMatchSrc(matchSrc)
      errCallData.setSrcDetail(srcDetail)
      errCallData.setMatchDept(matchDept)
      errCallData.setMatchTeam(matchTeam)
      errCallData.setMatchGroupId(matchGroupId)
      errCallData.setErrCallDept(errCallDept)
      errCallData.setErrCallTeam(errCallTeam)
      errCallData.setErrCallAddrAbb(errCallAddrabb.replaceAll("['\\\\]*", "").replaceAll("[\\\\r\\\\n]*", ""))
      errCallData.setChkDept(chkDept)
      errCallData.setChkTeam(chkTeam)
      errCallData.setChkEmpId(chkEmpId)
      errCallData.setChkModifyUser(chkModifyUser)
      errCallData.setMiningDept(miningDept)
      errCallData.setMiningTeam(miningTeam)
      errCallData.setErrCallDate(errCallDate)
      errCallData.setCompany(obj.getCompany.replaceAll("['\\\\]*", "").replaceAll("[\\\\r\\\\n]*", ""))
      errCallData.setPhone(obj.getPhone.replaceAll("'", ""))
      errCallData.setMobile(obj.getMobile.replaceAll("'", ""))
      errCallData.setAoiId(obj.getAoiId)
      val pickupBody = obj.getPickupBody
      if (pickupBody != null) {
        val pick_up_tc = pickupBody.getString("pick_up_tc")
        val resource_id = pickupBody.getString("resource_id")
        val current_state = pickupBody.getString("current_state")
        errCallData.setPick_up_tc(pick_up_tc)
        errCallData.setResource_id(resource_id)
        errCallData.setCurrent_state(current_state)
        if (errCallData.getMatchTeam != null && !errCallData.getMatchTeam.isEmpty
          && pick_up_tc != null && !pick_up_tc.isEmpty) {
          if (pick_up_tc.equals(errCallData.getMatchTeam)) {
            errCallData.setIs_wrong_report("1")
          } else {
            errCallData.setIs_wrong_report("0")
          }
        }
      }
      (reqDate + "_" + address, errCallData)
    })

    val freqRdd = errCallRdd1.map(obj => {
      val id = obj._1
      val address = obj._2.getAddress
      if (address != null && !"".equals(address))
        (id, 1)
      else
        (id, 0)
    }).filter(_ != null).reduceByKey(_ + _)

    val errCallRdd = errCallRdd1.leftOuterJoin(freqRdd).map(tp => {
      val errCallObj = tp._2._1
      val freqObj = tp._2._2
      if (freqObj.nonEmpty)
        errCallObj.setFrequency(freqObj.get)
      errCallObj
    })
    errCallRdd

  }

  /**
   * 获取揽收数据
   *
   * @param sc      : sparksession
   * @param inc_day : 日期
   * @return
   */
  def selectAllPickUpInfo(sc: SparkSession, inc_day: String, appDays: Int): RDD[(String, JSONObject)] = {
    var pickUpRowRdd: RDD[Row] = null
    var pick_up_join_days = 3
    if (appDays == 1) {
      pick_up_join_days = 1
    }
    for (i <- 0 until pick_up_join_days) {
      val endDate = DateUtil.dateBefore("yyyyMMdd", 0 - i, inc_day)
      val tmpRdd = selectPickUpInfo(sc, endDate)
      if (pickUpRowRdd == null) {
        pickUpRowRdd = tmpRdd
      } else {
        pickUpRowRdd = pickUpRowRdd.union(tmpRdd)
      }
    }
    val pickUpRdd = pickUpRowRdd.repartition(3200).map(obj => {
      val pickUpArray = new JSONArray()
      val rsltTmp = new JSONObject()
      rsltTmp.put("sysorderno", obj.getString(0))
      rsltTmp.put("tc", obj.getString(1))
      rsltTmp.put("resource_id", obj.getString(2))
      rsltTmp.put("current_state", obj.getString(3))
      pickUpArray.add(rsltTmp)
      val key = rsltTmp.getString("sysorderno")
      val rslt = new JSONObject()
      rslt.put("pickup", pickUpArray)
      (key, rslt)
    }).reduceByKey((obj1, obj2) => {
      val pickup1 = obj1.getJSONArray("pickup")
      val pickup2 = obj2.getJSONArray("pickup")
      for (i <- 0 until pickup2.size()) {
        pickup1.add(pickup2.get(i))
      }
      obj1
    }).persist(StorageLevel.DISK_ONLY_2)
    logger.error("揽收排重后数量:" + pickUpRdd.count())
    //    pickUpRdd.unpersist()
    pickUpRdd
  }

  //  /**
  //    * 按天获取关联信息
  //    *
  //    * @param inc_day ： 日期
  //    */
  def selectPickUpInfo(sc: SparkSession, inc_day: String): RDD[Row] = {
    logger.error("日期：" + inc_day)
    val pickup_sql = "select t.order_no," +
      "ex.pickup_tc,t.resource_id," +
      " t.current_state from" +
      " (select inc_day,order_no,task_id,resource_id,current_state from " + tt_pickup_task + " " +
      " where inc_day = '" + inc_day + "' and order_no is not null and order_no <> '' ) t" +
      " left join (select pid,get_json_object(content,'$.receiveOrder.orderUnitareaCode') as pickup_tc from " + tt_pickup_task_ex + " where inc_day = '" + inc_day +
      "' and ex_key='RO_INFO' ) ex on t.task_id = ex.pid "
    logger.error(pickup_sql)
    val pickUpRdd = sc.sql(pickup_sql).rdd
    pickUpRdd
  }

}