package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.oms_pai.db.{ManagerFactory, RdsManager}
import com.sf.gis.scala.utils.DbUtils
import org.apache.log4j.Logger

import scala.collection.mutable.ArrayBuffer


/**
  * Created by 01368078 on 2019/3/14.
  */
object CustConf {
  val addrArrKey = "addrArr"
  val waybillNoArrKey = "waybillNoArr"
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  /**
    * 获取大客户配置
    * @return
    */
//  def getCustConf() : Map[String,ArrayBuffer[JSONObject]] = {
//    val path = System.getProperty("user.dir")+"/customer.csv"
//    var custConfMap:Map[String,ArrayBuffer[JSONObject]] = Map()
//    val br = new BufferedReader(new InputStreamReader(new FileInputStream(path)))
//    br.readLine()
//    var line = br.readLine()
//    while(line != null){
//      val row = line.split(",")
//      val cityCode = row(0)
//      val deptCode = row(2)
//      val key = cityCode + "_" + deptCode
//      var custConfList : ArrayBuffer[JSONObject] = null
//      if(custConfMap.contains(key)){
//        custConfList = custConfMap.apply(key)
//      }else{
//        custConfList = new ArrayBuffer[JSONObject]()
//        custConfMap +=(key->custConfList)
//      }
//      val obj = new JSONObject()
//      val addrArr = new JSONArray()
//      for(addr <- row(1).split("\\|"))
//        addrArr.add(addr)
//
//      val waybillNoArr = new JSONArray()
//      if(row.length >=  4){
//        for(waybillNo <- row(3).split("\\|"))
//          waybillNoArr.add(waybillNo)
//      }
//
//      obj.put(addrArrKey, addrArr)
//      obj.put(waybillNoArrKey, waybillNoArr)
//      custConfList += obj
//      line = br.readLine()
//    }
//    br.close()
//    custConfMap
//  }
  def getCustConf(deptMap: Map[String,String]): Map[String,ArrayBuffer[JSONObject]] = {
    val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
    //noinspection ScalaUnusedSymbol
    var regoinCityTable="ADMIN_AREA"
    val columns = Array("CITY_CODE","KEYWORD", "ZONECODE", "WAYBILL_PRE")
    val custConfSelectSql = s"select CITY_CODE, KEYWORD, ZONECODE, WAYBILL_PRE from DTE_CONFIG where DATA_TYPE = 'DLV_FD'"
    logger.error(">>>custConfSelectSql:"+custConfSelectSql)
    val custDatas:ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn,custConfSelectSql,columns)
  var custConfMap:Map[String,ArrayBuffer[JSONObject]] = Map()
    for(row <- custDatas){
      val cityCode = row(0)
      val deptCode = if(deptMap.contains(row(2))) deptMap.apply(row(2)) else row(2)
      val key = cityCode + "_" + deptCode
      var custConfList : ArrayBuffer[JSONObject] = null
      if(custConfMap.contains(key)){
        custConfList = custConfMap.apply(key)
      }else{
        custConfList = new ArrayBuffer[JSONObject]()
        custConfMap +=(key->custConfList)
      }
      val obj = new JSONObject()
      val addrArr = new JSONArray()
      for(addr <- row(1).split("\\|"))
        addrArr.add(addr)

      val waybillNoArr = new JSONArray()
      if(row.length >=  4){
        for(waybillNo <- row(3).split("\\|"))
          waybillNoArr.add(waybillNo)
      }

      obj.put(addrArrKey, addrArr)
      obj.put(waybillNoArrKey, waybillNoArr)
      custConfList += obj
    }
    custConfMap
  }


  /**
    * 获取大客户网点
    * @param custConfMap
    * @param deptSet
    * @param cityCode
    * @param waybillNo
    * @param addr
    * @return
    */
  def getCustDept(custConfMap :Map[String,ArrayBuffer[JSONObject]], deptSet : Set[String], cityCode : String, waybillNo : String, addr : String) : String = {
    for(deptCode <- deptSet){
      if(deptCode != null && !"".equals(deptCode)){
        val key = cityCode + "_" + deptCode
        if(custConfMap.contains(key)){
          val custConfList = custConfMap.apply(key)
          for(custConf <- custConfList){
            val addrArr = custConf.getJSONArray(addrArrKey)
            val waybillNoArr = custConf.getJSONArray(waybillNoArrKey)
            if(isWaybillExists(waybillNoArr, waybillNo) && isAddrExists(addrArr, addr))
              return deptCode
          }
        }
      }
    }
    null
  }

  def isWaybillExists(waybillNoArr : JSONArray, waybillNo : String) : Boolean = {
    if(waybillNoArr.size() == 0)
      return true
    for(i <- 0 until waybillNoArr.size()){
      val waybillNo2 = waybillNoArr.getString(i)
      if(waybillNo.startsWith(waybillNo2))
        return true
    }
    false
  }

  def isAddrExists(addrArr : JSONArray, addr : String) : Boolean = {
    for(i <- 0 until addrArr.size()){
      val addr2 = addrArr.getString(i)
      if(!addr.contains(addr2))
        return false
    }
    true
  }

  def main(args: Array[String]): Unit = {
    val custConfMap: Map[String, ArrayBuffer[JSONObject]] = getCustConf(null)
    println(custConfMap)
    val set = Array[String]("021F", "021FL", "021L").toSet
    println(getCustDept(custConfMap, set, "021", "0111231546", "上海121号花园坊"))
  }
}
