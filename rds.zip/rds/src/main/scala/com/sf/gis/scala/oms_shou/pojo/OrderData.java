package com.sf.gis.scala.oms_shou.pojo;

import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.oms_shou.pojo.rds.Tcs;

import java.io.Serializable;


public class OrderData implements Serializable {
    private boolean syncReqFlag;
    private boolean syncReFlag;
    private boolean asyncReqFlag;
    private boolean asyncReFlag;
    private boolean rdsArssReqFlag;
    private boolean arssReqFlag;
    private boolean arssReFlag;
    private boolean errCallFlag;

    private String syncReqDateTime;
    private String syncReDateTime;
    private String syncReStatus;
    private String syncReqId;
    private String syncNodeId;

    private String asyncReqDateTime;
    private String asyncReDateTime;
    private String asyncReStatus;
    private String asyncReqId;
    private String asyncNodeId;

    private String rdsArssReqDateTime;

    private String arssReqDataTime;
    private String arssReqNodeId;
    private String arssReDataTime;
    private String arssReNodeId;

    private String reqDate;
    private String reqTime;

    private String ak;
    private String url;
    private String remoteIp;
    private String sno;
    private String sysCode;

    private String orderType;
    private String sysSource;
    private String limitTypeCode;
    private String payType;
    private String pickupType;
    private String bookingType;
    private String cargoTypeCode;
    private String expressTypeCode;
    private String weight;
    private String clientCode;

    private String orderNo;
    private String sysOrderNo;
    private String dataTime;

    private String countryCode;
    private String province;
    private String city;
    private String cityCode;
    private String county;
    private String address;
    private String customerAccount;
    private String customerId;
    private String contactsName;
    private String company;
    private String phone;
    private String mobile;
    private String waybillNo;

    private String syncSrc;
    private String syncGroupId;
    private String syncDeptCode;
    private String syncTeamCode;
    private String syncAoiCode;
    private String syncAoiId;
    private String syncChkDeptSrc;
    private String syncChkTcSrc;
    private String syncTc2GeoSrc;
    private String syncTc2Gid;
    private Tcs syncTcs;

    private String asyncSrc;
    private String asyncGroupId;
    private String asyncDeptCode;
    private String asyncTeamCode;
    private String asyncAoiCode;
    private String asyncAoiId;
    private String asyncChkDeptSrc;
    private String asyncChkTcSrc;
    private String asyncTc2GeoSrc;
    private String asyncTc2Gid;
    private Tcs asyncTcs;

    private String arssDeptCode;
    private String arssTeamCode;
    private String arssAoiCode;
    private String arssAoiId;
    private String arssEmpCode;

    private String status;
    private String src;
    private String groupId;
    private String deptCode;
    private String teamCode;
    private String aoiCode;
    private String aoiId;

    private String errCallProvince;
    private String errCallCity;
    private String errCallResno;
    private String errCallAddrabb;
    private String errCallCounty;
    private String errCallTeamid;
    private String errCallDept;
    private String errCallAddrSrc;
    private String errCallAddrGroupid;
    private String errCallAddrDept;
    private String errCallAddrTeamCode;
    private String errCallEmpid;
    private String errCallEmptel;
    private String errCallDate;
    private String errCallTime;
    private String errCallTcSouce;
    private String errCallOperName;
    private String isNotUnderCall;
    private String matchSrc;
    private String matchGroupId;
    private String matchDeptCode;
    private String matchTeamCode;
    private String matchChkDeptSrc;
    private String matchChkTcSrc;
    private String matchTc2GeoSrc;
    private String matchTc2Gid;
    private JSONObject chkKsReqBody;
    private JSONObject chkKsReBody;
    private JSONObject chkOmsRebody;
    private JSONObject pickupBody;
    private JSONObject syncReqBody;
    private JSONObject syncReBody;
    private JSONObject asyncReqBody;
    private JSONObject asyncReBody;
    private JSONObject arssReqBody;
    private JSONObject arssReBody;
    private JSONObject requestBuildingBody;
    private JSONObject responseBuildingBody;
    private JSONObject atShouBody;
    private String bidAoiState;
    //相同订单号不同reqid的序号
    private int tag;
    private String reqId;

    public JSONObject getAtShouBody() {
        return atShouBody;
    }

    public void setAtShouBody(JSONObject atShouBody) {
        this.atShouBody = atShouBody;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public int getTag() {
        return tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }


    public String getDataTime() {
        return dataTime;
    }

    public void setDataTime(String dataTime) {
        this.dataTime = dataTime;
    }

    public JSONObject getArssReqBody() {
        return arssReqBody;
    }

    public void setArssReqBody(JSONObject arssReqBody) {
        this.arssReqBody = arssReqBody;
    }

    public JSONObject getArssReBody() {
        return arssReBody;
    }

    public void setArssReBody(JSONObject arssReBody) {
        this.arssReBody = arssReBody;
    }

    public String getBidAoiState() {
        return bidAoiState;
    }

    public void setBidAoiState(String bidAoiState) {
        this.bidAoiState = bidAoiState;
    }

    public JSONObject getRequestBuildingBody() {
        return requestBuildingBody;
    }

    public void setRequestBuildingBody(JSONObject requestBuildingBody) {
        this.requestBuildingBody = requestBuildingBody;
    }

    public JSONObject getResponseBuildingBody() {
        return responseBuildingBody;
    }

    public void setResponseBuildingBody(JSONObject responseBuildingBody) {
        this.responseBuildingBody = responseBuildingBody;
    }

    public JSONObject getSyncReqBody() {
        return syncReqBody;
    }

    public void setSyncReqBody(JSONObject syncReqBody) {
        this.syncReqBody = syncReqBody;
    }

    public JSONObject getSyncReBody() {
        return syncReBody;
    }

    public void setSyncReBody(JSONObject syncReBody) {
        this.syncReBody = syncReBody;
    }

    public JSONObject getAsyncReqBody() {
        return asyncReqBody;
    }

    public void setAsyncReqBody(JSONObject asyncReqBody) {
        this.asyncReqBody = asyncReqBody;
    }

    public JSONObject getAsyncReBody() {
        return asyncReBody;
    }

    public void setAsyncReBody(JSONObject asyncReBody) {
        this.asyncReBody = asyncReBody;
    }

    public Tcs getSyncTcs() {
        return syncTcs;
    }

    public void setSyncTcs(Tcs syncTcs) {
        this.syncTcs = syncTcs;
    }

    public Tcs getAsyncTcs() {
        return asyncTcs;
    }

    public void setAsyncTcs(Tcs asyncTcs) {
        this.asyncTcs = asyncTcs;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getSyncAoiId() {
        return syncAoiId;
    }

    public void setSyncAoiId(String syncAoiId) {
        this.syncAoiId = syncAoiId;
    }

    public String getAsyncAoiId() {
        return asyncAoiId;
    }

    public void setAsyncAoiId(String asyncAoiId) {
        this.asyncAoiId = asyncAoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getSyncAoiCode() {
        return syncAoiCode;
    }

    public void setSyncAoiCode(String syncAoiCode) {
        this.syncAoiCode = syncAoiCode;
    }

    public String getPickupType() {
        if (pickupType == null) return "";
        else return pickupType;
    }

    public void setPickupType(String pickupType) {
        this.pickupType = pickupType;
    }

    public String getArssAoiCode() {
        return arssAoiCode;
    }

    public void setArssAoiCode(String arssAoiCode) {
        this.arssAoiCode = arssAoiCode;
    }

    public String getArssAoiId() {
        return arssAoiId;
    }

    public void setArssAoiId(String arssAoiId) {
        this.arssAoiId = arssAoiId;
    }

    public String getAsyncAoiCode() {
        return asyncAoiCode;
    }

    public void setAsyncAoiCode(String asyncAoiCode) {
        this.asyncAoiCode = asyncAoiCode;
    }

    public String getIsNotUnderCall() {
        if (isNotUnderCall == null) return "";
        else return isNotUnderCall;
    }

    public void setIsNotUnderCall(String isNotUnderCall) {
        this.isNotUnderCall = isNotUnderCall;
    }

    public JSONObject getPickupBody() {
        return pickupBody;
    }

    public void setPickupBody(JSONObject pickupBody) {
        this.pickupBody = pickupBody;
    }

    public JSONObject getChkOmsRebody() {
        return chkOmsRebody;
    }

    public void setChkOmsRebody(JSONObject chkOmsRebody) {
        this.chkOmsRebody = chkOmsRebody;
    }

    public JSONObject getChkKsReqBody() {
        return chkKsReqBody;
    }

    public void setChkKsReqBody(JSONObject chkKsReqBody) {
        this.chkKsReqBody = chkKsReqBody;
    }

    public JSONObject getChkKsReBody() {
        return chkKsReBody;
    }

    public void setChkKsReBody(JSONObject chkKsReBody) {
        this.chkKsReBody = chkKsReBody;
    }

    public boolean isSyncReqFlag() {
        return syncReqFlag;
    }

    public void setSyncReqFlag(boolean syncReqFlag) {
        this.syncReqFlag = syncReqFlag;
    }

    public boolean isSyncReFlag() {
        return syncReFlag;
    }

    public void setSyncReFlag(boolean syncReFlag) {
        this.syncReFlag = syncReFlag;
    }

    public boolean isAsyncReqFlag() {
        return asyncReqFlag;
    }

    public void setAsyncReqFlag(boolean asyncReqFlag) {
        this.asyncReqFlag = asyncReqFlag;
    }

    public boolean isAsyncReFlag() {
        return asyncReFlag;
    }

    public void setAsyncReFlag(boolean asyncReFlag) {
        this.asyncReFlag = asyncReFlag;
    }

    public boolean isRdsArssReqFlag() {
        return rdsArssReqFlag;
    }

    public void setRdsArssReqFlag(boolean rdsArssReqFlag) {
        this.rdsArssReqFlag = rdsArssReqFlag;
    }

    public boolean isArssReqFlag() {
        return arssReqFlag;
    }

    public void setArssReqFlag(boolean arssReqFlag) {
        this.arssReqFlag = arssReqFlag;
    }

    public boolean isArssReFlag() {
        return arssReFlag;
    }

    public void setArssReFlag(boolean arssReFlag) {
        this.arssReFlag = arssReFlag;
    }

    public boolean isErrCallFlag() {
        return errCallFlag;
    }

    public void setErrCallFlag(boolean errCallFlag) {
        this.errCallFlag = errCallFlag;
    }

    public String getStatus() {
        if (status == null) return "";
        else return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSyncReqDateTime() {
        if (syncReqDateTime == null) return "";
        else return syncReqDateTime;
    }

    public void setSyncReqDateTime(String syncReqDateTime) {
        this.syncReqDateTime = syncReqDateTime;
    }

    public String getSyncReDateTime() {
        if (syncReDateTime == null) return "";
        else return syncReDateTime;
    }

    public void setSyncReDateTime(String syncReDateTime) {
        this.syncReDateTime = syncReDateTime;
    }

    public String getSyncReStatus() {
        if (syncReStatus == null) return "";
        else return syncReStatus;
    }

    public void setSyncReStatus(String syncReStatus) {
        this.syncReStatus = syncReStatus;
    }

    public String getSyncReqId() {
        if (syncReqId == null) return "";
        else return syncReqId;
    }

    public void setSyncReqId(String syncReqId) {
        this.syncReqId = syncReqId;
    }

    public String getSyncNodeId() {
        if (syncNodeId == null) return "";
        else return syncNodeId;
    }

    public void setSyncNodeId(String syncNodeId) {
        this.syncNodeId = syncNodeId;
    }

    public String getAsyncReqDateTime() {
        if (asyncReqDateTime == null) return "";
        else return asyncReqDateTime;
    }

    public void setAsyncReqDateTime(String asyncReqDateTime) {
        this.asyncReqDateTime = asyncReqDateTime;
    }

    public String getAsyncReDateTime() {
        if (asyncReDateTime == null) return "";
        else return asyncReDateTime;
    }

    public void setAsyncReDateTime(String asyncReDateTime) {
        this.asyncReDateTime = asyncReDateTime;
    }

    public String getAsyncReStatus() {
        if (asyncReStatus == null) return "";
        else return asyncReStatus;
    }

    public void setAsyncReStatus(String asyncReStatus) {
        this.asyncReStatus = asyncReStatus;
    }

    public String getAsyncReqId() {
        if (asyncReqId == null) return "";
        else return asyncReqId;
    }

    public void setAsyncReqId(String asyncReqId) {
        this.asyncReqId = asyncReqId;
    }

    public String getAsyncNodeId() {
        if (asyncNodeId == null) return "";
        else return asyncNodeId;
    }

    public void setAsyncNodeId(String asyncNodeId) {
        this.asyncNodeId = asyncNodeId;
    }

    public String getRdsArssReqDateTime() {
        if (rdsArssReqDateTime == null) return "";
        else return rdsArssReqDateTime;
    }

    public void setRdsArssReqDateTime(String rdsArssReqDateTime) {
        this.rdsArssReqDateTime = rdsArssReqDateTime;
    }

    public String getArssReqDataTime() {
        if (arssReqDataTime == null) return "";
        else return arssReqDataTime;
    }

    public void setArssReqDataTime(String arssReqDataTime) {
        this.arssReqDataTime = arssReqDataTime;
    }

    public String getArssReqNodeId() {
        if (arssReqNodeId == null) return "";
        else return arssReqNodeId;
    }

    public void setArssReqNodeId(String arssReqNodeId) {
        this.arssReqNodeId = arssReqNodeId;
    }

    public String getArssReDataTime() {
        if (arssReDataTime == null) return "";
        else return arssReDataTime;
    }

    public void setArssReDataTime(String arssReDataTime) {
        this.arssReDataTime = arssReDataTime;
    }

    public String getArssReNodeId() {
        if (arssReNodeId == null) return "";
        else return arssReNodeId;
    }

    public void setArssReNodeId(String arssReNodeId) {
        this.arssReNodeId = arssReNodeId;
    }

    public String getAk() {
        if (ak == null) return "";
        else return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getUrl() {
        if (url == null) return "";
        else return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRemoteIp() {
        if (remoteIp == null) return "";
        else return remoteIp;
    }

    public void setRemoteIp(String remoteIp) {
        this.remoteIp = remoteIp;
    }

    public String getSno() {
        if (sno == null) return "";
        else return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public String getSysCode() {
        if (sysCode == null) return "";
        else return sysCode;
    }

    public void setSysCode(String sysCode) {
        this.sysCode = sysCode;
    }

    public String getOrderType() {
        if (orderType == null) return "";
        else return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getSysSource() {
        if (sysSource == null) return "";
        else return sysSource;
    }

    public void setSysSource(String sysSource) {
        this.sysSource = sysSource;
    }

    public String getLimitTypeCode() {
        if (limitTypeCode == null) return "";
        else return limitTypeCode;
    }

    public void setLimitTypeCode(String limitTypeCode) {
        this.limitTypeCode = limitTypeCode;
    }

    public String getPayType() {
        if (payType == null) return "";
        else return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getBookingType() {
        if (bookingType == null) return "";
        else return bookingType;
    }

    public void setBookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public String getCargoTypeCode() {
        if (cargoTypeCode == null) return "";
        else return cargoTypeCode;
    }

    public void setCargoTypeCode(String cargoTypeCode) {
        this.cargoTypeCode = cargoTypeCode;
    }

    public String getExpressTypeCode() {
        if (expressTypeCode == null) return "";
        else return expressTypeCode;
    }

    public void setExpressTypeCode(String expressTypeCode) {
        this.expressTypeCode = expressTypeCode;
    }

    public String getWeight() {
        if (weight == null) return "";
        else return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getClientCode() {
        if (clientCode == null) return "";
        else return clientCode;
    }

    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    public String getOrderNo() {
        if (orderNo == null) return "";
        else return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getSysOrderNo() {
        if (sysOrderNo == null) return "";
        else return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public String getCountryCode() {
        if (countryCode == null) return "";
        else return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getProvince() {
        if (province == null) return "";
        else return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        if (city == null) return "";
        else return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityCode() {
        if (cityCode == null) return "";
        else return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCounty() {
        if (county == null) return "";
        else return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getAddress() {
        if (address == null) return "";
        else return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCustomerAccount() {
        if (customerAccount == null) return "";
        else return customerAccount;
    }

    public void setCustomerAccount(String customerAccount) {
        this.customerAccount = customerAccount;
    }

    public String getCustomerId() {
        if (customerId == null) return "";
        else return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getContactsName() {
        if (contactsName == null) return "";
        else return contactsName;
    }

    public void setContactsName(String contactsName) {
        this.contactsName = contactsName;
    }

    public String getCompany() {
        if (company == null) return "";
        else return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getPhone() {
        if (phone == null) return "";
        else return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMobile() {
        if (mobile == null) return "";
        else return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getWaybillNo() {
        if (waybillNo == null) return "";
        else return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getSyncSrc() {
        if (syncSrc == null) return "";
        else return syncSrc;
    }

    public void setSyncSrc(String syncSrc) {
        this.syncSrc = syncSrc;
    }

    public String getSyncGroupId() {
        if (syncGroupId == null) return "";
        else return syncGroupId;
    }

    public void setSyncGroupId(String syncGroupId) {
        this.syncGroupId = syncGroupId;
    }

    public String getSyncDeptCode() {
        if (syncDeptCode == null) return "";
        else return syncDeptCode;
    }

    public void setSyncDeptCode(String syncDeptCode) {
        this.syncDeptCode = syncDeptCode;
    }

    public String getSyncTeamCode() {
        if (syncTeamCode == null) return "";
        else return syncTeamCode;
    }

    public void setSyncTeamCode(String syncTeamCode) {
        this.syncTeamCode = syncTeamCode;
    }

    public String getAsyncSrc() {
        if (asyncSrc == null) return "";
        else return asyncSrc;
    }

    public void setAsyncSrc(String asyncSrc) {
        this.asyncSrc = asyncSrc;
    }

    public String getAsyncGroupId() {
        if (asyncGroupId == null) return "";
        else return asyncGroupId;
    }

    public void setAsyncGroupId(String asyncGroupId) {
        this.asyncGroupId = asyncGroupId;
    }

    public String getAsyncDeptCode() {
        if (asyncDeptCode == null) return "";
        else return asyncDeptCode;
    }

    public void setAsyncDeptCode(String asyncDeptCode) {
        this.asyncDeptCode = asyncDeptCode;
    }

    public String getAsyncTeamCode() {
        if (asyncTeamCode == null) return "";
        else return asyncTeamCode;
    }

    public void setAsyncTeamCode(String asyncTeamCode) {
        this.asyncTeamCode = asyncTeamCode;
    }

    public String getArssDeptCode() {
        if (arssDeptCode == null) return "";
        else return arssDeptCode;
    }

    public void setArssDeptCode(String arssDeptCode) {
        this.arssDeptCode = arssDeptCode;
    }

    public String getArssTeamCode() {
        if (arssTeamCode == null) return "";
        else return arssTeamCode;
    }

    public void setArssTeamCode(String arssTeamCode) {
        this.arssTeamCode = arssTeamCode;
    }

    public String getArssEmpCode() {
        if (arssEmpCode == null) return "";
        else return arssEmpCode;
    }

    public void setArssEmpCode(String arssEmpCode) {
        this.arssEmpCode = arssEmpCode;
    }

    public String getSrc() {
        if (src == null) return "";
        else return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getGroupId() {
        if (groupId == null) return "";
        else return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getDeptCode() {
        if (deptCode == null) return "";
        else return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getTeamCode() {
        if (teamCode == null) return "";
        else return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getErrCallProvince() {
        if (errCallProvince == null) return "";
        else return errCallProvince;
    }

    public void setErrCallProvince(String errCallProvince) {
        this.errCallProvince = errCallProvince;
    }

    public String getErrCallCity() {
        if (errCallCity == null) return "";
        else return errCallCity;
    }

    public void setErrCallCity(String errCallCity) {
        this.errCallCity = errCallCity;
    }

    public String getErrCallResno() {
        if (errCallResno == null) return "";
        else return errCallResno;
    }

    public void setErrCallResno(String errCallResno) {
        this.errCallResno = errCallResno;
    }

    public String getErrCallAddrabb() {
        if (errCallAddrabb == null) return "";
        else return errCallAddrabb;
    }

    public void setErrCallAddrabb(String errCallAddrabb) {
        this.errCallAddrabb = errCallAddrabb;
    }

    public String getErrCallCounty() {
        if (errCallCounty == null) return "";
        else return errCallCounty;
    }

    public void setErrCallCounty(String errCallCounty) {
        this.errCallCounty = errCallCounty;
    }

    public String getErrCallTeamid() {
        if (errCallTeamid == null) return "";
        else return errCallTeamid;
    }

    public void setErrCallTeamid(String errCallTeamid) {
        this.errCallTeamid = errCallTeamid;
    }

    public String getErrCallDept() {
        if (errCallDept == null) return "";
        else return errCallDept;
    }

    public void setErrCallDept(String errCallDept) {
        this.errCallDept = errCallDept;
    }

    public String getErrCallAddrSrc() {
        if (errCallAddrSrc == null) return "";
        else return errCallAddrSrc;
    }

    public void setErrCallAddrSrc(String errCallAddrSrc) {
        this.errCallAddrSrc = errCallAddrSrc;
    }

    public String getErrCallAddrGroupid() {
        if (errCallAddrGroupid == null) return "";
        else return errCallAddrGroupid;
    }

    public void setErrCallAddrGroupid(String errCallAddrGroupid) {
        this.errCallAddrGroupid = errCallAddrGroupid;
    }

    public String getErrCallAddrDept() {
        if (errCallAddrDept == null) return "";
        else return errCallAddrDept;
    }

    public void setErrCallAddrDept(String errCallAddrDept) {
        this.errCallAddrDept = errCallAddrDept;
    }

    public String getErrCallAddrTeamCode() {
        if (errCallAddrTeamCode == null) return "";
        else return errCallAddrTeamCode;
    }

    public void setErrCallAddrTeamCode(String errCallAddrTeamCode) {
        this.errCallAddrTeamCode = errCallAddrTeamCode;
    }

    public String getErrCallEmpid() {
        if (errCallEmpid == null) return "";
        else return errCallEmpid;
    }

    public void setErrCallEmpid(String errCallEmpid) {
        this.errCallEmpid = errCallEmpid;
    }

    public String getErrCallEmptel() {
        if (errCallEmptel == null) return "";
        else return errCallEmptel;
    }

    public void setErrCallEmptel(String errCallEmptel) {
        this.errCallEmptel = errCallEmptel;
    }

    public String getMatchSrc() {
        if (matchSrc == null) return "";
        else return matchSrc;
    }

    public void setMatchSrc(String matchSrc) {
        this.matchSrc = matchSrc;
    }

    public String getMatchGroupId() {
        if (matchGroupId == null) return "";
        else return matchGroupId;
    }

    public void setMatchGroupId(String matchGroupId) {
        this.matchGroupId = matchGroupId;
    }

    public String getMatchDeptCode() {
        if (matchDeptCode == null) return "";
        else return matchDeptCode;
    }

    public void setMatchDeptCode(String matchDeptCode) {
        this.matchDeptCode = matchDeptCode;
    }

    public String getMatchTeamCode() {
        if (matchTeamCode == null) return "";
        else return matchTeamCode;
    }

    public void setMatchTeamCode(String matchTeamCode) {
        this.matchTeamCode = matchTeamCode;
    }

    public String getSyncChkDeptSrc() {
        if (syncChkDeptSrc == null) return "";
        else return syncChkDeptSrc;
    }

    public void setSyncChkDeptSrc(String syncChkDeptSrc) {
        this.syncChkDeptSrc = syncChkDeptSrc;
    }

    public String getSyncChkTcSrc() {
        if (syncChkTcSrc == null) return "";
        else return syncChkTcSrc;
    }

    public void setSyncChkTcSrc(String syncChkTcSrc) {
        this.syncChkTcSrc = syncChkTcSrc;
    }

    public String getAsyncChkDeptSrc() {
        if (asyncChkDeptSrc == null) return "";
        else return asyncChkDeptSrc;
    }

    public void setAsyncChkDeptSrc(String asyncChkDeptSrc) {
        this.asyncChkDeptSrc = asyncChkDeptSrc;
    }

    public String getAsyncChkTcSrc() {
        if (asyncChkTcSrc == null) return "";
        else return asyncChkTcSrc;
    }

    public void setAsyncChkTcSrc(String asyncChkTcSrc) {
        this.asyncChkTcSrc = asyncChkTcSrc;
    }

    public String getMatchChkDeptSrc() {
        if (matchChkDeptSrc == null) return "";
        else return matchChkDeptSrc;
    }

    public void setMatchChkDeptSrc(String matchChkDeptSrc) {
        this.matchChkDeptSrc = matchChkDeptSrc;
    }

    public String getMatchChkTcSrc() {
        if (matchChkTcSrc == null) return "";
        else return matchChkTcSrc;
    }

    public void setMatchChkTcSrc(String matchChkTcSrc) {
        this.matchChkTcSrc = matchChkTcSrc;
    }

    public String getSyncTc2GeoSrc() {
        if (syncTc2GeoSrc == null) return "";
        else return syncTc2GeoSrc;
    }

    public void setSyncTc2GeoSrc(String syncTc2GeoSrc) {
        this.syncTc2GeoSrc = syncTc2GeoSrc;
    }

    public String getSyncTc2Gid() {
        if (syncTc2Gid == null) return "";
        else return syncTc2Gid;
    }

    public void setSyncTc2Gid(String syncTc2Gid) {
        this.syncTc2Gid = syncTc2Gid;
    }

    public String getAsyncTc2GeoSrc() {
        if (asyncTc2GeoSrc == null) return "";
        else return asyncTc2GeoSrc;
    }

    public void setAsyncTc2GeoSrc(String asyncTc2GeoSrc) {
        this.asyncTc2GeoSrc = asyncTc2GeoSrc;
    }

    public String getAsyncTc2Gid() {
        if (asyncTc2Gid == null) return "";
        else return asyncTc2Gid;
    }

    public void setAsyncTc2Gid(String asyncTc2Gid) {
        this.asyncTc2Gid = asyncTc2Gid;
    }

    public String getMatchTc2GeoSrc() {
        if (matchTc2GeoSrc == null) return "";
        else return matchTc2GeoSrc;
    }

    public void setMatchTc2GeoSrc(String matchTc2GeoSrc) {
        this.matchTc2GeoSrc = matchTc2GeoSrc;
    }

    public String getMatchTc2Gid() {
        if (matchTc2Gid == null) return "";
        else return matchTc2Gid;
    }

    public void setMatchTc2Gid(String matchTc2Gid) {
        this.matchTc2Gid = matchTc2Gid;
    }


    public String getReqDate() {
        if (reqDate == null) return "";
        else return reqDate;
    }

    public void setReqDate(String reqDate) {
        this.reqDate = reqDate;
    }

    public String getReqTime() {
        if (reqTime == null) return "";
        else return reqTime;
    }

    public void setReqTime(String reqTime) {
        this.reqTime = reqTime;
    }

    public String getErrCallDate() {
        if (errCallDate == null) return "";
        else return errCallDate;
    }

    public void setErrCallDate(String errCallDate) {
        this.errCallDate = errCallDate;
    }

    public String getErrCallTime() {
        if (errCallTime == null) return "";
        else return errCallTime;
    }

    public void setErrCallTime(String errCallTime) {
        this.errCallTime = errCallTime;
    }

    public String getErrCallTcSouce() {
        if (errCallTcSouce == null) return "";
        else return errCallTcSouce;
    }

    public void setErrCallTcSouce(String errCallTcSouce) {
        this.errCallTcSouce = errCallTcSouce;
    }

    public String getErrCallOperName() {
        if (errCallOperName == null) return "";
        else return errCallOperName;
    }

    public void setErrCallOperName(String errCallOperName) {
        this.errCallOperName = errCallOperName;
    }
}
