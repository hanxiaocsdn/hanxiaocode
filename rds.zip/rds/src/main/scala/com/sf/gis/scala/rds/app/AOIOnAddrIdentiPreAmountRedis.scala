package com.sf.gis.scala.rds.app

import java.io.InputStreamReader
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpConnection}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.rds.util.{MD5Util, Util}
import org.apache.commons.csv.CSVFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * KS11-基于地址的AOI识别,运单宽表预计算存入redis
 * Created by 01417629 on 2021-11-11
 * 任务id: 136
 */
//noinspection DuplicatedCode
object AOIOnAddrIdentiPreAmountRedis {
  @transient lazy val logger: Logger = Logger.getLogger(AOIOnAddrIdentiPreAmountRedis.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val url = "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/saveMax80Aoi?"
  //val url = "http://10.240.16.114:8080/rdsks/api/saveMax80Aoi?"

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val parDay_1 = args(0)//t-17
    val parDay_2 = args(1)//t-15
    val parDay_3 = args(2)//t-14
    val parDay_4 = args(3)//t-12
    val parDay_5 = args(4)//t-11
    val parDay_6 = args(5)//t-9
    val parDay_7 = args(6)//t-8
    val parDay_8 = args(7)//t-6
    val parDay_9 = args(8)//t-5
    val parDay_10 = args(9)//t-3
    val parDay_11 = args(10)//当天日期
    println(parDay_1 + "-->" + parDay_2 + "-->" + parDay_3 + "-->" + parDay_4 + "-->" + parDay_5 + "-->" + parDay_6 + "-->" + parDay_7)
    println(parDay_8 + "-->" + parDay_9 + "-->" + parDay_10 + "-->" + parDay_11)
    //t-17 ~ t-15的数据写入Redis
    println(parDay_1 + "-->" + parDay_2)
    getWaybillInfoPreCalData(spark,parDay_1,parDay_2,parDay_11)
    //t-14 ~ t-12的数据写入Redis
    println(parDay_3 + "-->" + parDay_4)
    getWaybillInfoPreCalData(spark,parDay_3,parDay_4,parDay_11)
    //t-11 ~ t-9的数据写入Redis
    println(parDay_5 + "-->" + parDay_6)
    getWaybillInfoPreCalData(spark,parDay_5,parDay_6,parDay_11)
    //t-8 ~ t-6的数据写入Redis
    println(parDay_7 + "-->" + parDay_8)
    getWaybillInfoPreCalData(spark,parDay_7,parDay_8,parDay_11)
    //t-5 ~ t-3的数据写入Redis
    println(parDay_9 + "-->" + parDay_10)
    getWaybillInfoPreCalData(spark,parDay_9,parDay_10,parDay_11)
    spark.close()
  }


  /**
   * 统计指标预计算
   * @param spark
   * @param inc_day_1
   * @param inc_day_2
   */
  def getWaybillInfoPreCalData(spark: SparkSession,inc_day_1: String,inc_day_2 : String,parDay_11 : String): Unit ={
    val sql =
      s"""
         |SELECT
         |	 citycode
         |	,consignee_addr
         |	,max_80_zncode
         |	,max_80_aoiid
         |	,max_80_aoiid_numb
         |	,max_80_aoiid_freq
         |	,aoiid_up_to_date
         |FROM dm_gis.tt_waybill_add_standard_addr_cal
         |WHERE aoiid_up_to_date >= '$inc_day_1' AND aoiid_up_to_date <='$inc_day_2' AND inc_day= '$parDay_11'
         |""".stripMargin

    logger.error(">>>>>>过滤tt_waybill_add_standard_addr_cal表 inc_day_1 ~ inc_day_2 sql: "+sql)
    val max_80_aoi = Util.getRowToJson(spark,sql,200)
    logger.error(s">>>获取max_80_aoi共 ${max_80_aoi.count()} 条s<<<")
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "136", "AOIOnAddrIdentiPreAmountRedis", "AOIOnAddrIdentiPreAmountRedis", "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/saveMax80Aoi", "fe761b57a7494fb99eb9d3e555111174", max_80_aoi.count(), 50)
    val errorList = saveResult2Redis(max_80_aoi)
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)
    saveErrorList2Hive(spark,errorList,parDay_11)
  }

  /**
   *
   * @param max_80_aoi
   */
  def saveResult2Redis(max_80_aoi : RDD[JSONObject]): RDD[AnyRef] ={
    logger.error(">>>>>>>>>开始插入数据库<<<<<<<<<<")
    val res = max_80_aoi.repartition(20).mapPartitions(iter => {
        var addrList = new JSONArray()
        var param = new JSONObject()
        val errorList = new JSONArray()
        val md5Instance = MD5Util.getMD5Instance
      while (iter.hasNext){
          val jsonObject = new JSONObject()
          val obj = iter.next()
          val consignee_addr = obj.getString("consignee_addr")
          val addrMd5 = MD5Util.getMD5(md5Instance,consignee_addr)
          jsonObject.put("addrMd5",addrMd5)
          jsonObject.put("citycode",obj.getString("citycode"))
          jsonObject.put("max80Znocode",obj.getString("max_80_zncode"))
          jsonObject.put("max80AoiId",obj.getString("max_80_aoiid"))
          jsonObject.put("max80AoiRatio",obj.getString("max_80_aoiid_freq"))
          jsonObject.put("max80AoiFreq",obj.getString("max_80_aoiid_numb"))
          jsonObject.put("lastWaybillDate",obj.getString("aoiid_up_to_date"))
          addrList.add(jsonObject)
          if(addrList.size() == 500 || iter.hasNext == false){
            param.put("ak","fe761b57a7494fb99eb9d3e555111174")
            //param.put("ak","0376a9aa84724dd2a995f858dd963346")
            param.put("addrList",addrList)
            val res = postSave2Redis(url,param.toJSONString)
            if(res != null && res.getString("errorList")  != null){
              errorList.add(res.getString("errorList"))
            }
            addrList = new JSONArray()
            param = new JSONObject()
          }
        }
        errorList.toArray.toIterator
      }).persist(StorageLevel.DISK_ONLY)
      logger.error(">>>>>>>>>入库失败数据量<<<<<<<<<<: " + res.count())
      logger.error(">>>>>>>>>redis入库结束<<<<<<<<<<")
      max_80_aoi.unpersist()
      res
  }




  /**
   *
   * @param url
   * @param params
   * @return
   */
  def postSave2Redis(url: String,params: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!params.isEmpty) {
        val httpData = HttpConnection.sendPost(url,params)
        if (httpData != null && httpData.containsKey("content") && httpData.get("content") != null) {
          val content = httpData.get("content").toString
          val xyObj = JSON.parseObject(content)
          if (xyObj != null && xyObj.getJSONObject("result") != null) {
            if (xyObj.getJSONObject("result").getInteger("err") == 109) {
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep(60 - second)
              return postSave2Redis(url,params)
            }
            val result = xyObj.getJSONObject("result")
            if(result != null){
              val errorList = result.getJSONArray("errorList")
              if(errorList != null && errorList.size() != 0){
                ret.put("errorList",errorList.toJSONString)
              }else{
                ret.put("errorList",null)
              }
            }else{
              ret.put("result",null)
            }
          }else{
            ret.put("xyObj",null)
          }
        }else{
          ret.put("code",httpData.get("code"))
        }
      }else{
        ret.put("params",null)
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  def saveErrorList2Hive(spark : SparkSession,errorList : RDD[AnyRef],parDay_11 : String): Unit ={
    //目标库表名称
    val descDBName = "default"
    val descTableName = "tt_waybill_add_standard_addr_redis_err"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION (inc_day = '$parDay_11')
         |SELECT
         |  errorMsg
         |FROM tt_waybill_hook_cal_err_temp
         |""".stripMargin
    try{
      val schemaString = "errorMsg,other"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
      val schema = StructType(fields)
      val rdd = errorList.map(attr => Row(attr.toString,"other"))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.createOrReplaceTempView("tt_waybill_hook_cal_err_temp")
      df.show(5)
      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      val resultDF = spark.sql(insertSQL)
      resultDF.show(5)
      logger.error(">>>>>>>>>>入hive库结束")
      spark.sql("drop table if exists tt_waybill_hook_cal_err_temp")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>删除临时表: tt_waybill_hook_cal_err_temp")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }




}
