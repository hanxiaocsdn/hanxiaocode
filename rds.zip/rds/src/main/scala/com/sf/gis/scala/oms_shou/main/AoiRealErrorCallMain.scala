package com.sf.gis.scala.oms_shou.main

import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.com.sf.gis.scala.oms_shou.constant.FixedConstant
import com.sf.gis.java.base.util.{MD5Util, ShellExcutor}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_shou.constant.VariableConstant
import com.sf.gis.scala.oms_shou.db.{ManagerFactory, RdsManager}
import com.sf.gis.scala.oms_shou.pojo.{AdminArea, OmsPuAoi}
import com.sf.gis.scala.utils.{ConfigurationUtil, DateUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.JavaConversions._

/**
 *
 * aoi真实错分率
 * 表已下线，任务已不存在
 */
object AoiRealErrorCallMain {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val daysAgo: Int = 4
  val onlyOneDay = false
  val city_code: Array[String] = Array()
  var incDay: String = DateUtil.dateBefore(FixedConstant.DATE_FORMAT2, daysAgo)
  val dateArray = Array(DateUtil.dateBefore(FixedConstant.DATE_FORMAT2, 2, incDay),
    DateUtil.dateBefore(FixedConstant.DATE_FORMAT2, 1, incDay), incDay)
  val omsFromArray = Array("inc_day", "cityCode", "city", "address", "errCallResno", "errCallCity",
    "errCallAddrabb", "orderNo", "sysOrderNo", "chkOmsRebody", "isNotUnderCall",
    "asyncReqFlag", "asyncSrc", "asyncAoiCode", "syncReqFlag", "syncSrc",
    "syncAoiCode", "arssReFlag", "arssAoiCode", "finalAoiCode")
  val omsFieldsSave: Array[String] = Array()
  val batchResultArray = Array("aoi_id", "emp_no", "batch_date", "batch_code")
  val executionArray = Array("order_no", "aoi_id", "batch_code", "act_time",
    "distribute_code", "act_code", "dest_dept_code", "real_distribute_time", "date"
  )
  var needSaveRdd: RDD[(String, JSONObject)] = null

  def main(args: Array[String]): Unit = {
    start()
  }

  /**
   * 开始程序
   */
  def start(): Unit = {
    val conf = getSparkConf(appName)
    val sc = new SparkContext(conf)
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error(">>>统计aoi收件错call指标-------生产--------start--------appName==" + appName + "----------")
    handleTask(dateArray, spark, sc)
    logger.error("the end!")
  }

  /**
   * 处理任务
   *
   */
  def handleTask(dateArray: Array[String], spark: SparkSession, sc: SparkContext): Unit = {
    val startDate = dateArray.apply(0)
    val incDay = dateArray.apply(dateArray.length - 1)
    logger.error("-------统计" + startDate + "--" + incDay
      + "之间，" + dateArray.length + "天的的错分指标--------")
    //    logger.error("-------统计" + startDate + "的错分指标--------")

    logger.error(">>>过滤错分数据...")
    val omsTotalLogRdd = filterWrongData(startDate, incDay, spark, sc)
    val wdLogRdd = omsTotalLogRdd.filter(obj => checkWd(obj)).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>错分日志表数量：" + wdLogRdd.count())

    logger.error(">>>统计错分指标")
    val rowIndexRdd = statRowIndex(omsTotalLogRdd).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>错分行指标分组个数:" + rowIndexRdd.count())
    omsTotalLogRdd.unpersist()
    logger.error(">>>错分指标入库...")
    savePuAoi(rowIndexRdd, spark)
    //    WdIndexStat.saveAoiRealWdIndex(rowIndexRdd, comUtil, dateArray)
    //    rowIndexRdd.unpersist()
    logger.error(">>>保存错分数据")
    saveWd(spark, needSaveRdd.values, dateArray)
    wdLogRdd.unpersist()
  }

  /**
   * OMS收件AOI统计
   *
   * @param puAoiRdd : 数据rdd
   */
  def savePuAoi(puAoiRdd: RDD[OmsPuAoi], spark: SparkSession): Unit = {
    logger.error(">>>save puAoi.")
    val omsPuAoiTable = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("mysql.table.oms_pu_real_aoi")
    try {
      val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
      val stmt = conn.prepareStatement(
        String.format("INSERT INTO %s(`ID`, `UNDER_CALL`,`STAT_DATE`, `PROVINCE`, `REGION`, `CITY_CODE`," +
          " `CITY`, `ORDER`, `AOI`,`AOI_AUTO`,`AOI_GIS`, `AOI_GIS_NORM`, `AOI_GIS_SCH`, `AOI_GIS_TC2`," +
          " `AOI_GIS_CHKE`, `AOI_GIS_CHKN`, `AOI_GIS_DPNORM`,`AOI_GIS_DPTC2`,`AOI_GIS_DPCHKE`,`AOI_GIS_DPCHKN`," +
          "`AOI_GIS_DPROAD`,`AOI_GIS_DPPHONE`," +
          "`AOI_GIS_PHONE`,`AOI_GIS_OTHER`,`AOI_KS`,`AOI_ARSS_RE`,`AOI_ARSS_REQ`," +
          "`FC_AOI`,`FC_AOI_GIS`, `FC_AOI_GIS_NORM`, `FC_AOI_GIS_SCH`, `FC_AOI_GIS_TC2`," +
          "`FC_AOI_GIS_CHKE`, `FC_AOI_GIS_CHKN`, `FC_AOI_GIS_DPNORM`,`FC_AOI_GIS_DPTC2`," +
          "`FC_AOI_GIS_DPCHKE`,`FC_AOI_GIS_DPCHKN`,`FC_AOI_GIS_DPROAD`,`FC_AOI_GIS_DPPHONE`," +
          "`FC_AOI_GIS_PHONE`,`FC_AOI_GIS_OTHER`,`FC_AOI_KS`,`FC_AOI_ARSS`" +
          ") VALUES(?,?,?, ?, ?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
          "ON DUPLICATE KEY UPDATE `ORDER` = ?, `AOI` = ?,`AOI_AUTO` = ?,`AOI_GIS` = ?, `AOI_GIS_NORM` = ?," +
          "`AOI_GIS_SCH` = ?, `AOI_GIS_TC2` = ?, `AOI_GIS_CHKE` = ?, `AOI_GIS_CHKN` = ?, " +
          "`AOI_GIS_DPNORM`= ?,`AOI_GIS_DPTC2`= ?,`AOI_GIS_DPCHKE`= ?,`AOI_GIS_DPCHKN`= ?," +
          "`AOI_GIS_DPROAD`= ?,`AOI_GIS_DPPHONE`= ?,`AOI_GIS_PHONE`= ?,`AOI_GIS_OTHER`= ?," +
          "`AOI_KS`=?,`AOI_ARSS_RE`=?,`AOI_ARSS_REQ`=?," +
          "`FC_AOI` = ?,`FC_AOI_GIS` = ?, `FC_AOI_GIS_NORM` = ?," +
          "`FC_AOI_GIS_SCH` = ?, `FC_AOI_GIS_TC2` = ?, `FC_AOI_GIS_CHKE` = ?, `FC_AOI_GIS_CHKN` = ?, " +
          "`FC_AOI_GIS_DPNORM`= ?,`FC_AOI_GIS_DPTC2`= ?,`FC_AOI_GIS_DPCHKE`= ?,`FC_AOI_GIS_DPCHKN`= ?," +
          "`FC_AOI_GIS_DPROAD`= ?,`FC_AOI_GIS_DPPHONE`= ?,`FC_AOI_GIS_PHONE`= ?,`FC_AOI_GIS_OTHER`= ?," +
          "`FC_AOI_KS`=?,`FC_AOI_ARSS`=?"
          , omsPuAoiTable))
      puAoiRdd.collect().foreach(obj => {
        val params = Array(obj.getId, obj.getUnderCall, obj.getStatDate, obj.getProvince, obj.getRegion,
          obj.getCityCode, obj.getCity, obj.getOrder, obj.getAoi, obj.getAoiAuto, obj.getAoiGis, obj.getAoiNorm,
          obj.getAoiSch, obj.getAoiTc2, obj.getAoiChke, obj.getAoiChkn, obj.getAoiDispatchNorm, obj.getAoiDispatchTc2,
          obj.getAoiDispatchChke, obj.getAoiDispatchChkn, obj.getAoiDispatchRoad, obj.getAoiDispatchPhone,
          obj.getAoiPhone, obj.getAoiOther, obj.getAoiKs, obj.getAoiArssRe, obj.getAoiArssReq,
          obj.getAoiFc, obj.getAoiGisFc, obj.getAoiNormFc,
          obj.getAoiSchFc, obj.getAoiTc2Fc, obj.getAoiChkeFc, obj.getAoiChknFc, obj.getAoiDispatchNormFc, obj.getAoiDispatchTc2Fc,
          obj.getAoiDispatchChkeFc, obj.getAoiDispatchChknFc, obj.getAoiDispatchRoadFc, obj.getAoiDispatchPhoneFc,
          obj.getAoiPhoneFc, obj.getAoiOtherFc, obj.getAoiKsFc, obj.getAoiArssFc,
          obj.getOrder, obj.getAoi, obj.getAoiAuto, obj.getAoiGis, obj.getAoiNorm,
          obj.getAoiSch, obj.getAoiTc2, obj.getAoiChke, obj.getAoiChkn, obj.getAoiDispatchNorm, obj.getAoiDispatchTc2,
          obj.getAoiDispatchChke, obj.getAoiDispatchChkn, obj.getAoiDispatchRoad, obj.getAoiDispatchPhone,
          obj.getAoiPhone, obj.getAoiOther, obj.getAoiKs, obj.getAoiArssRe, obj.getAoiArssReq,
          obj.getAoiFc, obj.getAoiGisFc, obj.getAoiNormFc,
          obj.getAoiSchFc, obj.getAoiTc2Fc, obj.getAoiChkeFc, obj.getAoiChknFc, obj.getAoiDispatchNormFc, obj.getAoiDispatchTc2Fc,
          obj.getAoiDispatchChkeFc, obj.getAoiDispatchChknFc, obj.getAoiDispatchRoadFc, obj.getAoiDispatchPhoneFc,
          obj.getAoiPhoneFc, obj.getAoiOtherFc, obj.getAoiKsFc, obj.getAoiArssFc)
        for (i <- params.indices)
          stmt.setObject(i + 1, params(i))
        try {
          stmt.executeUpdate()
        } catch {
          case e: Exception => e.printStackTrace()
        }
      })
      conn.close()
    } catch {
      case e: Exception => logger.error("insert puAoi error", e)
    }
  }

  def getExecutionRdd(startDate: String, endDate: String, spark: SparkSession, sc: SparkContext): RDD[(String, JSONObject)] = {
    val sqlBuilder = new StringBuilder()
    for (i <- executionArray.indices) {
      if (!executionArray(i).equals("date")) {
        sqlBuilder.append(executionArray(i)).append(",")
      } else {
        sqlBuilder.append("`date`").append(",")
      }
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectSql =
      s"""select * from (
         |select ${sqlBuilder.toString()},
         | row_number() over(partition BY order_no order by
         |   real_distribute_time desc,act_time desc ) as rank
         |   from dm_tc_waybillinfo.execution_detail_shou
         | where inc_day between '$startDate' and '$endDate'  and order_no <> '' )a where a.rank=1
      """.stripMargin
    println("selectExecutionSql:" + selectSql)
    val executionRdd = spark.sql(selectSql)
      .repartition(2000)
      .rdd
      .map(row => {
        val execution_body = new JSONObject()
        for (i <- executionArray.indices) {
          if (executionArray(i).equals("aoi_id")) {
            var aoi_id = row.getString(i)
            if (aoi_id == null) {
              aoi_id = ""
            }
            aoi_id = aoi_id.replaceAll("=", "").replaceAll("\"", "").trim
            execution_body.put(executionArray(i), aoi_id)
          } else {
            execution_body.put(executionArray(i), row.getString(i).trim)
          }
        }

        val orderNo = execution_body.getString("order_no")
        val result = new JSONObject()
        result.put("execution_body", execution_body)
        (orderNo, result)
      }).filter(_._1 != null)
    executionRdd
  }

  def unionOmsExecution(omsRdd: RDD[(String, JSONObject)], omsExecutionRdd: RDD[(String, JSONObject)]): (RDD[(String, JSONObject)], RDD[(String, JSONObject)]) = {
    val executionValid = omsRdd.union(omsExecutionRdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).filter(obj => obj._2.containsKey("oms_body")
      && obj._2.containsKey("execution_body")).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>关联派件执行表后，有效数据量:" + executionValid.count())

    omsRdd.unpersist()
    omsExecutionRdd.unpersist()
    val onlyOmsValid = executionValid.map(obj => {
      val ret = new JSONObject()
      ret.put("oms_body", obj._2.getJSONObject("oms_body"))
      (obj._1, ret)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>omsLog有效数据量:" + onlyOmsValid.count())

    val onlyExecutionValid = executionValid.map(obj => {
      //      obj._2.remove("oms_body")
      val execution_body = obj._2.getJSONObject("execution_body")
      val dest_dept_code = execution_body.getString("dest_dept_code")
      (dest_dept_code, obj._2)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>execution有效数据量:" + onlyExecutionValid.count())
    executionValid.unpersist()
    (onlyOmsValid, onlyExecutionValid)
  }

  def getRunBatchRdd(startDate: String, endDate: String, spark: SparkSession, sc: SparkContext): RDD[(String, JSONObject)] = {
    val runBatchArray = Array("operatezonecode", "date", "planbegintm", "planendtm",
      "batchcode")
    val sqlBuilder = new StringBuilder()
    for (i <- runBatchArray.indices) {
      if (!runBatchArray(i).equals("date")) {
        sqlBuilder.append(runBatchArray(i)).append(",")
      } else {
        sqlBuilder.append("`date`").append(",")
      }
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectSql =
      s"""select ${sqlBuilder.toString()}
         | from dm_tc_waybillinfo.runs_batch_original
         | where inc_day between '$startDate' and '$endDate'  and operatezonecode<>'' and batchcode like "%P"
      """.stripMargin
    println("selectRunBatchSql:" + selectSql)
    val runBatchRdd = spark.sql(selectSql)
      .repartition(2000)
      .rdd
      .map(row => {
        val runbatch_body = new JSONObject()
        val tmpSb = new StringBuilder()
        for (i <- runBatchArray.indices) {
          runbatch_body.put(runBatchArray(i), row.getString(i))
          tmpSb.append(row.getString(i) + "_")
        }
        tmpSb.deleteCharAt(tmpSb.length - 1)
        val result = new JSONObject()
        result.put("runbatch_body", runbatch_body)
        (tmpSb.toString(), result)
      }).filter(_._1 != null).reduceByKey((obj1, _) => {
      obj1
    }).map(obj => {
      val operatezonecode = obj._2.getJSONObject("runbatch_body").getString("operatezonecode")
      (operatezonecode, obj._2)
    })
    runBatchRdd
  }

  def checkBatchCode(runBatchBatchCode: String): Boolean = {
    runBatchBatchCode != null && runBatchBatchCode.endsWith("P") && !runBatchBatchCode.contains(";")
  }

  def joinRunBatch(executionValid: RDD[(String, JSONObject)], runBatchRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val finalBatchRdd = executionValid.leftOuterJoin(runBatchRdd).map(obj => {
      val runBatchOption = obj._2._2
      val executionBody = obj._2._1.getJSONObject("execution_body")
      val real_distribute_time = executionBody.getString("real_distribute_time")
      val act_time = executionBody.getString("act_time")
      try {
        val distributeTime = DateUtil.timeToLong(real_distribute_time, "yyyy-MM-dd HH:mm:ss")
        val actTime = DateUtil.timeToLong(act_time, "yyyy-MM-dd HH:mm:ss")
        //        logger.error("takeover_time:" + takeover_time)
        if (runBatchOption.nonEmpty) {
          val runbatch_body = runBatchOption.get.getJSONObject("runbatch_body")
          val planbegintm = runbatch_body.getString("planbegintm")
          val planendtm = runbatch_body.getString("planendtm")
          val day = runbatch_body.getString("date")
          val beginTime = DateUtil.timeToLong(day + " " + planbegintm, "yyyyMMdd HHmm")
          val endTime = DateUtil.timeToLong(day + " " + planendtm, "yyyyMMdd HHmm")
          //          logger.error("beginTime:" + day + " " + planbegintm)
          //          logger.error("endTime:" + day + " " + planendtm)
          if (distributeTime <= endTime && distributeTime >= beginTime) {
            obj._2._1.put("runBatchBatchCode1", runbatch_body.getString("batchcode"))
          }
          if (actTime <= endTime && actTime >= beginTime) {
            obj._2._1.put("runBatchBatchCode2", runbatch_body.getString("batchcode"))
          }
        }
      } catch {
        case e: Exception => logger.error(">>>时间格式不正确：" + e)
      }
      (executionBody.getString("order_no"), obj._2._1)
    }).reduceByKey((obj1, obj2) => {
      updateBatchCode(obj1, obj2, "runBatchBatchCode1")
      updateBatchCode(obj1, obj2, "runBatchBatchCode2")
      obj1
    }).flatMap(obj => {
      val list = new util.ArrayList[(String, JSONObject)]()
      val executionBody = obj._2.getJSONObject("execution_body")
      val act_code = executionBody.getString("act_code")
      val date = executionBody.getString("date")
      if (checkBatchCode(obj._2.getString("runBatchBatchCode1"))) {
        val tmpObj = new JSONObject()
        tmpObj.fluentPutAll(obj._2)
        tmpObj.put("finalBatchCode1", obj._2.getString("runBatchBatchCode1"))
        list.add((obj._2.getString("runBatchBatchCode1") + "_" + act_code + "_" + date, tmpObj))
      }
      if (checkBatchCode(obj._2.getString("runBatchBatchCode2"))) {
        val tmpObj = new JSONObject()
        tmpObj.fluentPutAll(obj._2)
        tmpObj.put("finalBatchCode2", obj._2.getString("runBatchBatchCode2"))
        list.add((obj._2.getString("runBatchBatchCode2") + "_" + act_code + "_" + date, tmpObj))
      }
      if (!checkBatchCode(obj._2.getString("runBatchBatchCode1"))
        && !checkBatchCode(obj._2.getString("runBatchBatchCode2"))) {
        val tmpObj = new JSONObject()
        tmpObj.fluentPutAll(obj._2)
        tmpObj.put("finalBatchCode", executionBody.getString("batch_code"))
        list.add((executionBody.getString("batch_code") + "_" + act_code + "_" + date, tmpObj))
      }
      list.iterator()
    })
    logger.error("关联上排班表数量:" + finalBatchRdd.filter(obj => obj._2.getString("runBatchBatchCode1") != null || obj._2.getString("runBatchBatchCode2") != null).count())
    //    logger.error("finalBatchRdd:" + finalBatchRdd.count())
    finalBatchRdd
  }

  def updateBatchCode(obj1: JSONObject, obj2: JSONObject, key: String): Unit = {
    var runBatchCode = ""
    val runBatchBatchCode1 = obj1.getString(key)
    if (runBatchBatchCode1 != null && !runBatchBatchCode1.isEmpty) {
      runBatchCode = runBatchBatchCode1
    }
    val runBatchBatchCode2 = obj2.getString(key)
    if (runBatchBatchCode2 != null && !runBatchBatchCode2.isEmpty
      && !runBatchBatchCode2.equals(runBatchCode)) {
      if (!runBatchCode.isEmpty) {
        runBatchCode = runBatchCode + ";" + runBatchBatchCode2
      } else {
        runBatchCode = runBatchBatchCode2
      }
    }
    obj1.put(key, runBatchCode)
  }

  def getBatchResultRdd(startDate: String, endDate: String, spark: SparkSession, sc: SparkContext): RDD[(String, JSONObject)] = {
    val sqlBuilder = new StringBuilder()
    for (i <- batchResultArray.indices) {
      sqlBuilder.append(batchResultArray(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectOmsSql =
      s"""select ${sqlBuilder.toString()}
         |   from dm_tc_waybillinfo.sds_scheduling_result
         | where inc_day between '$startDate' and '$endDate'
      """.stripMargin
    println("selectBatchResultSql:" + selectOmsSql)
    val executionRdd = spark.sql(selectOmsSql)
      .repartition(400)
      .rdd
      .map(row => {
        val batchResult_body = new JSONObject()
        for (i <- batchResultArray.indices) batchResult_body.put(batchResultArray(i), row.getString(i))
        val aoi_id = batchResult_body.getString("aoi_id")
        val emp_no = batchResult_body.getString("emp_no")
        val batch_date = batchResult_body.getString("batch_date")
        val batch_code = batchResult_body.getString("batch_code")
        var key: String = null
        val result = new JSONObject()
        result.put("batchResult_body", batchResult_body)
        if (!aoi_id.isEmpty) {
          try {
            val aoiInfo = JSON.parseObject(aoi_id)
            if (aoiInfo.keySet().size() != 0) {
              batchResult_body.put("aoi_id", aoiInfo)
              batchResult_body.put("aoi_id_key", ";" + aoiInfo.keySet().mkString(";") + ";")
              key = batch_code + "_" + emp_no + "_" + batch_date
            }
          } catch {
            case e: Exception => logger.error(">>>aoi格式不正确：" + e)
          }
        }
        (key, result)
      }).filter(obj => obj._1 != null).reduceByKey((obj1, obj2) => {
      val batchResult_body1 = obj1.getJSONObject("batchResult_body")
      val batchResult_body2 = obj2.getJSONObject("batchResult_body")
      val aoiId1 = batchResult_body1.getJSONObject("aoi_id")
      val aoiId2 = batchResult_body2.getJSONObject("aoi_id")
      aoiId1.fluentPutAll(aoiId2)
      batchResult_body1.put("aoi_id_key", ";" + aoiId1.keySet().mkString(";") + ";")
      obj1
    })
    executionRdd
  }

  def unionBatchResult(runBatchValid: RDD[(String, JSONObject)], batchResultRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    runBatchValid.take(3).foreach(obj => {
      logger.error(obj)
    })
    batchResultRdd.take(3).foreach(obj => {
      logger.error(obj)
    })
    val batchResultUnion = runBatchValid.leftOuterJoin(batchResultRdd).map(obj => {
      val batchResultOption = obj._2._2
      val execution_body = obj._2._1.getJSONObject("execution_body")
      if (batchResultOption.nonEmpty) {
        val batchResult_body = batchResultOption.get.getJSONObject("batchResult_body")
        if (obj._2._1.containsKey("finalBatchCode")) {
          obj._2._1.put("batchResult_body", batchResult_body)
        } else if (obj._2._1.containsKey("finalBatchCode1")) {
          obj._2._1.put("batchResult_body1", batchResult_body)
        } else if (obj._2._1.containsKey("finalBatchCode2")) {
          obj._2._1.put("batchResult_body2", batchResult_body)
        }
        val orderno = execution_body.getString("order_no")
        (orderno, obj._2._1)
      } else {
        (null, obj._2._1)
      }
    }).filter(obj => obj._1 != null)
      .reduceByKey((obj1, obj2) => {
        if (obj2.containsKey("finalBatchCode")) {
          obj1.put("finalBatchCode", obj2.getString("finalBatchCode"))
          obj1.put("batchResult_body", obj2.getJSONObject("batchResult_body"))
        } else if (obj2.containsKey("finalBatchCode1")) {
          obj1.put("finalBatchCode1", obj2.getString("finalBatchCode1"))
          obj1.put("batchResult_body1", obj2.getJSONObject("batchResult_body1"))
        } else if (obj2.containsKey("finalBatchCode2")) {
          obj1.put("finalBatchCode2", obj2.getString("finalBatchCode2"))
          obj1.put("batchResult_body2", obj2.getJSONObject("batchResult_body2"))
        }
        obj1
      })
      .persist(StorageLevel.DISK_ONLY)
    logger.error(">>>关联排班结果表数量：" + batchResultUnion.count())
    logger.error(">>>关联上排班结果表数量：" + batchResultUnion.filter(obj => {
      obj._2.getJSONObject("batchResult_body") != null || obj._2.getJSONObject("batchResult_body1") != null || obj._2.getJSONObject("batchResult_body2") != null
    }).count())
    batchResultUnion.take(3).foreach(obj => {
      logger.error(obj)
    })
    val selectRdd = batchResultUnion.map(obj => {
      val execution_body = obj._2.getJSONObject("execution_body")
      val aoiId = execution_body.getString("aoi_id")
      val isWd = !(checkAoiIdContain(aoiId, obj._2.getJSONObject("batchResult_body"))
        || checkAoiIdContain(aoiId, obj._2.getJSONObject("batchResult_body1"))
        || checkAoiIdContain(aoiId, obj._2.getJSONObject("batchResult_body2")))
      if (!isWd) {
        obj._2.put("tag", "right")
      }
      obj
    })
    val tmpNeedSaveRdd = batchResultUnion.filter(obj => "right".equals(obj._2.getString("tag"))).persist(StorageLevel.DISK_ONLY)
    updateSaveRdd(tmpNeedSaveRdd)
    val wdRd = batchResultUnion.filter(obj => !"right".equals(obj._2.getString("tag")))
    val tmpRdd = wdRd.map(obj => {
      obj._2.put("tag", "wd")
      obj
    })
    updateSaveRdd(tmpRdd)
    wdRd
  }

  def checkAoiIdContain(aoiId: String, obj: JSONObject): Boolean = {
    if (obj != null) {
      val aoiIdList = obj.getString("aoi_id_key")
      aoiIdList.contains(";" + aoiId + ";")
    } else {
      false
    }
  }

  def unionWdOms(wdRdd: RDD[(String, JSONObject)], omsRdd: RDD[(String, JSONObject)]): RDD[JSONObject] = {
    wdRdd.union(omsRdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).values
  }

  def saveWd(spark: SparkSession, wdLogRdd: RDD[JSONObject], dateArray: Array[String]): Unit = {
    val finalTable = "omsfrom_aoi_real_wd"
    logger.error("最终数量:" + wdLogRdd.count())
    val wdRows = wdLogRdd.map(obj => {
      val oms_body = obj.getJSONObject("oms_body")
      val execution_body = obj.getJSONObject("execution_body")
      //      val result_body = obj.getJSONObject("result_body")
      val rowBuilder = new StringBuilder()
      val inc_day = oms_body.getString("inc_day")
      for (name <- executionArray) {
        if (execution_body != null) {
          var tmp = execution_body.getString(name)
          if (tmp == null) {
            tmp = ""
          }
          rowBuilder.append(tmp.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")).append("\t")
        } else {
          rowBuilder.append("").append("\t")
        }
      }
      val finalBatchCode = JSONUtil.getItem(obj, "finalBatchCode", "").toString
      rowBuilder.append(finalBatchCode.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")).append("\t")
      rowBuilder.append(JSONUtil.getJSONObjectString(obj, "batchResult_body", "").replaceAll("['\",\\r,\\n,\\t,\\\\]", "")).append("\t")
      val finalBatchCode1 = JSONUtil.getItem(obj, "finalBatchCode1", "").toString
      rowBuilder.append(finalBatchCode1.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")).append("\t")
      rowBuilder.append(JSONUtil.getJSONObjectString(obj, "batchResult_body1", "").replaceAll("['\",\\r,\\n,\\t,\\\\]", "")).append("\t")
      val finalBatchCode2 = JSONUtil.getItem(obj, "finalBatchCode2", "").toString
      rowBuilder.append(finalBatchCode2.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")).append("\t")
      rowBuilder.append(JSONUtil.getJSONObjectString(obj, "batchResult_body2", "").replaceAll("['\",\\r,\\n,\\t,\\\\]", "")).append("\t")

      //      for (name <- omsFieldsSave) {
      //        if (oms_body != null) {
      //          var tmp = oms_body.getString(name)
      //          if (tmp == null) {
      //            tmp = ""
      //          }
      //          rowBuilder.append(tmp.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")).append("\t")
      //        } else {
      //          rowBuilder.append("").append("\t")
      //        }
      //      }
      val tag = JSONUtil.getItem(obj, "tag", "")
      rowBuilder.append(tag)
      (inc_day, rowBuilder.toString())
    }).persist(StorageLevel.DISK_ONLY)
    wdRows.take(10).foreach(obj => {
      logger.error(obj)
    })
    for (startDate <- dateArray) {
      val rows = wdRows.filter(obj => obj._1.equals(startDate)).values
      val dropSql = String.format("alter table dm_gis.%s drop if exists partition(inc_day = '%s')", finalTable, startDate)
      spark.sql(dropSql)
      ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R /user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, startDate))
      rows.saveAsTextFile(String.format("/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, startDate))
      val addSql = String.format("alter table dm_gis.%s add if not exists partition(inc_day = '%s')", finalTable, startDate)
      spark.sql(addSql)
    }
  }

  def filterDeliverDistributeRdd(rejectDataRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val tmpRdd = rejectDataRdd.map(obj => {
      if (!filterDeliverDistribute(obj._2.getJSONObject("execution_body"))) {
        obj._2.put("tag", "deliverDistributeDiff")
      }
      obj
    })
    val tmpNeedSaveRdd = tmpRdd.filter(obj => "deliverDistributeDiff".equals(obj._2.getString("tag"))).persist(StorageLevel.DISK_ONLY)
    updateSaveRdd(tmpNeedSaveRdd)
    tmpRdd.filter(obj => !"deliverDistributeDiff".equals(obj._2.getString("tag")))
  }

  /**
   * 过滤错分的数据
   *
   * @return
   */
  def filterWrongData(startDate: String, endDate: String, spark: SparkSession, sc: SparkContext): RDD[JSONObject] = {
    logger.error(">>>获取oms收件的日志数据...")
    val omsRdd = getOmsLogRdd(startDate, endDate, spark, sc).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>获取oms收件的数据量：" + omsRdd.count())
    omsRdd.take(1).foreach(obj => logger.error(obj._2.toJSONString))
    logger.error(">>>获取派件执行数据")
    val omsExecutionRdd = getExecutionRdd(startDate, endDate, spark, sc).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>获取派件执行数据数量:" + omsExecutionRdd.count())
    omsExecutionRdd.take(1).foreach(obj => logger.error(obj._2.toJSONString))
    logger.error(">>>关联日志和执行表")
    val executionValid = unionOmsExecution(omsRdd, omsExecutionRdd)
    logger.error(">>>过滤排班小哥和揽收小哥一致")
    val executionValidFilter = filterDeliverDistributeRdd(executionValid._2)
    //    val executionValidFilter = executionValid._2.filter(obj => filterDeliverDistribute(obj._2.getJSONObject("execution_body")))
    logger.error(">>>排班小哥和揽收小哥不一致数据量:" + executionValidFilter.count())
    executionValid._2.unpersist()
    logger.error(">>>关联日志和执行表")
    logger.error(">>>获取班次信息表")
    val runBatchRdd = getRunBatchRdd(startDate, endDate, spark, sc).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>获取班次表数量:" + runBatchRdd.count())
    runBatchRdd.take(1).foreach(obj => logger.error(obj._2.toJSONString))
    logger.error(">>>关联班次表")
    val runBatchValid = joinRunBatch(executionValidFilter, runBatchRdd).persist(StorageLevel.DISK_ONLY)
    logger.error("关联班次表过后数量:" + runBatchValid.count())
    runBatchRdd.unpersist()
    executionValidFilter.unpersist()
    logger.error(">>>获取排班结果表")
    val batchResultRdd = getBatchResultRdd(startDate, endDate, spark, sc).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>获取排班结果表数量：" + batchResultRdd.count())
    batchResultRdd.take(1).foreach(obj => logger.error(obj._2.toJSONString))
    logger.error(">>>关联排班结果表")
    val wdRdd = unionBatchResult(runBatchValid, batchResultRdd).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>错分表数量：" + wdRdd.count())
    batchResultRdd.unpersist()
    runBatchValid.unpersist()
    logger.error(">>>关联回日志表")
    val omsTotalLogRdd = unionWdOms(wdRdd, executionValid._1).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>关联日志日志表数量：" + omsTotalLogRdd.count())
    omsTotalLogRdd
  }

  def checkWd(obj: JSONObject): Boolean = {
    obj.containsKey("execution_body")
  }

  def filterDeliverDistribute(obj: JSONObject): Boolean = {
    if (obj.getString("aoi_id") == null || obj.getString("aoi_id").isEmpty) {
      return false
    }
    val distribute_code = obj.getString("distribute_code")
    val act_code = obj.getString("act_code")
    if (distribute_code != null && act_code != null
      && distribute_code.equals(act_code)) {
      false
    } else {
      true
    }
  }

  /**
   * 获取oms派件的数据
   *
   * @return
   */
  def getOmsLogRdd(startDate: String, endDate: String, spark: SparkSession, sc: SparkContext): RDD[(String, JSONObject)] = {
    //公司名为baison的为测试单
    val sqlBuilder = new StringBuilder()
    for (i <- omsFromArray.indices) {
      sqlBuilder.append(omsFromArray(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val conditionSqlBuilder = new StringBuilder()
    if (onlyOneDay) {
      conditionSqlBuilder.append(" inc_day = '" + startDate + "' ")
    } else {
      conditionSqlBuilder.append(" inc_day between '" + startDate + "' and '" + endDate + "' ")
    }
    if (!city_code.isEmpty) {
      conditionSqlBuilder.append(" and (cityCode in ('" + city_code.mkString("','") + "') or errCallResno in ('" + city_code.mkString("','") + "'))")
    }
    val selectOmsSql =
      s"""
         |select * from
         |	(select ${sqlBuilder.toString()},
         |   row_number() over(partition BY orderNo order by syncReqDateTime desc ) as rank
         |   from dm_gis.gis_rds_omsfrom
         | where ${conditionSqlBuilder.toString()}  and orderNo <> '' )a where a.rank=1
      """.stripMargin

    println("selectOmsSql:" + selectOmsSql)
    val omsRdd = spark.sql(selectOmsSql)
      .repartition(2000)
      .rdd
      .map(row => {
        val oms_body = new JSONObject()
        for (i <- omsFromArray.indices) {
          if (omsFromArray(i).equals("chkOmsRebody")) {
            if (row.getString(i) != null && !row.getString(i).isEmpty) {
              try {
                oms_body.put(omsFromArray(i), JSON.parseObject(row.getString(i)))
              } catch {
                case e: Exception => e.printStackTrace()
              }
            }
          } else {
            oms_body.put(omsFromArray(i), row.getString(i))
          }
        }
        val orderno = oms_body.getString("orderNo")
        val result = new JSONObject()
        result.put("oms_body", oms_body)
        (orderno, result)
      }).filter(_._1 != null)
    omsRdd
  }

  /**
   * 配置spark的conf
   *
   * @return
   */
  def getSparkConf(appName: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    conf.set("spark.yarn.executor.memoryOverhead", "4096")
    conf.set("spark.scheduler.maxRegisteredResourcesWaitingTime", "180000")
    //    conf.set("spark.executor.instances","20")
    //    conf.set("spark.executor.memory","20g")
    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")
    conf
  }

  def statRowIndex(omsTotalLogRdd: RDD[JSONObject]): RDD[OmsPuAoi] = {
    val adminAreaMap: util.Map[String, util.List[AdminArea]] = new AdminAreaLoader().loadAdminArea()
    //    omsTotalLogRdd.collect().foreach(obj=>{
    //      logger.error(obj.toJSONString)
    //    })
    val puRdd = omsTotalLogRdd.map(obj => {
      statAoi(obj, adminAreaMap)
    }).filter(_ != null).persist(StorageLevel.DISK_ONLY)
    logger.error("聚合aoi:" + puRdd.count())
    val puAoiRdd = puRdd.flatMap(obj => {
      val list = new util.ArrayList[(String, OmsPuAoi)]()
      val omsPuAoi = obj
      list.add((String.format("%s_%s_%s_%s", omsPuAoi.getUnderCall, omsPuAoi.getStatDate, omsPuAoi.getCityCode, omsPuAoi.getCity), omsPuAoi))
      list.iterator()
    }).reduceByKey((obj1, obj2) => {
      obj1.merge(obj2)
      obj1
    }).map(tp => {
      tp._2
    })
    puAoiRdd
  }

  def statAoi(data: JSONObject, adminAreaMap: util.Map[String, util.List[AdminArea]]): OmsPuAoi = {
    var omsPuAoi = new OmsPuAoi
    try {
      val obj = data.getJSONObject("oms_body")
      val adminArea = getAdminArea(adminAreaMap, obj.getString("cityCode"),
        obj.getString("city"), obj.getString("address"), obj.getString("errCallResno"),
        obj.getString("errCallCity"), obj.getString("errCallAddrabb"))
      omsPuAoi.setStatDate(obj.getString("inc_day"))
      omsPuAoi.setCityCode(adminArea.getCityCode)
      omsPuAoi.setRegion(adminArea.getRegion)
      omsPuAoi.setCity(adminArea.getCity)
      omsPuAoi.setProvince(adminArea.getProvince)
      var errCallFlag = false
      if (data.containsKey("execution_body")) {
        errCallFlag = true
      }
      var aoiSrc: String = ""
      var aoiCode: String = ""
      var reqFlag = false
      val chkToOmsReBody = obj.getJSONObject("chkOmsRebody")
      var chkToOmsAoiCode: String = null
      if (chkToOmsReBody != null) {
        val orderFrom = chkToOmsReBody.getJSONObject("orderFrom")
        if (orderFrom != null) {
          chkToOmsAoiCode = orderFrom.getString("aoiCode")
        }
      }
      if (obj.getString("asyncReqFlag").equals("true")) { //有异步请求
        aoiSrc = obj.getString("asyncSrc")
        aoiCode = obj.getString("asyncAoiCode")
        if (chkToOmsAoiCode != null && !chkToOmsAoiCode.isEmpty && !chkToOmsAoiCode.equals(aoiCode)) {
          aoiSrc = "ks"
          aoiCode = chkToOmsAoiCode
        }
        reqFlag = true
      } else if (obj.getString("syncReqFlag").equals("true")) {
        aoiSrc = obj.getString("syncSrc")
        aoiCode = obj.getString("syncAoiCode")
        reqFlag = true
      }
      if (reqFlag && obj.getString("arssReFlag").equals("true")) { //审补返回
        aoiCode = obj.getString("arssAoiCode")
        aoiSrc = "chke_cur"
      }

      if (reqFlag) {
        omsPuAoi.setOrder(1)
        updateAoiInfo(omsPuAoi, obj.getString("finalAoiCode"), aoiSrc, errCallFlag)
      }

      omsPuAoi.setUnderCall("YES")
      if ("1".equals(obj.getString("isNotUnderCall"))) {
        omsPuAoi.setUnderCall("NO")
      }
      omsPuAoi.setId(MD5Util.getMD5(String.format("%s%s%s%s", omsPuAoi.getUnderCall, omsPuAoi.getStatDate, omsPuAoi.getCityCode, omsPuAoi.getCity)))
    } catch {
      case e: Exception =>
        logger.error("transform order to tc index error", e)
        omsPuAoi = null
    }
    omsPuAoi
  }

  /**
   * 更新aoi信息
   *
   */
  def updateAoiInfo(omsPuAoi: OmsPuAoi, aoiCode: String, aoiSrc: String, errorCallFlag: Boolean): Unit = {
    if (aoiSrc.equals("chke_cur")) {
      omsPuAoi.setAoiArssReq(1)
    }
    if (aoiCode != null && !aoiCode.isEmpty) {
      omsPuAoi.setAoi(1)
      //aoi 识别量细分
      aoiSrc match {
        case "norm" =>
          omsPuAoi.setAoiNorm(1)
          omsPuAoi.setAoiGis(1)
        case "sch" =>
          omsPuAoi.setAoiSch(1)
          omsPuAoi.setAoiGis(1)
        case "tc2" =>
          omsPuAoi.setAoiTc2(1)
          omsPuAoi.setAoiGis(1)
        case "chke" =>
          omsPuAoi.setAoiChke(1)
          omsPuAoi.setAoiGis(1)
        case "chkn" =>
          omsPuAoi.setAoiChkn(1)
          omsPuAoi.setAoiGis(1)
        case "telnorm" =>
          omsPuAoi.setAoiPhone(1)
          omsPuAoi.setAoiGis(1)
        case "chke_cur" =>
          omsPuAoi.setAoiArssRe(1)
        case "dispatch-norm" =>
          omsPuAoi.setAoiDispatchNorm(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-chkn" =>
          omsPuAoi.setAoiDispatchChkn(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-chke" =>
          omsPuAoi.setAoiDispatchChke(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-tc2" =>
          omsPuAoi.setAoiDispatchTc2(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-road" =>
          omsPuAoi.setAoiDispatchRoad(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-phone" =>
          omsPuAoi.setAoiDispatchPhone(1)
          omsPuAoi.setAoiGis(1)
        case "ks" =>
          omsPuAoi.setAoiKs(1)
        case _ =>
          omsPuAoi.setAoiOther(1)
          omsPuAoi.setAoiGis(1)
      }
      if (omsPuAoi.getAoiGis == 1 || omsPuAoi.getAoiKs == 1) {
        omsPuAoi.setAoiAuto(1)
      }
    }
    var errorCall = 0
    if (errorCallFlag) {
      errorCall = 1
    }
    omsPuAoi.setAoiFc(omsPuAoi.getAoi * errorCall)
    omsPuAoi.setAoiArssFc(omsPuAoi.getAoiArssRe * errorCall)
    omsPuAoi.setAoiChkeFc(omsPuAoi.getAoiChke * errorCall)
    omsPuAoi.setAoiChknFc(omsPuAoi.getAoiChkn * errorCall)
    omsPuAoi.setAoiGisFc(omsPuAoi.getAoiGis * errorCall)
    omsPuAoi.setAoiKsFc(omsPuAoi.getAoiKs * errorCall)
    omsPuAoi.setAoiNormFc(omsPuAoi.getAoiNorm * errorCall)
    omsPuAoi.setAoiOtherFc(omsPuAoi.getAoiOther * errorCall)
    omsPuAoi.setAoiPhoneFc(omsPuAoi.getAoiPhone * errorCall)
    omsPuAoi.setAoiSchFc(omsPuAoi.getAoiSch * errorCall)
    omsPuAoi.setAoiTc2Fc(omsPuAoi.getAoiTc2 * errorCall)
    omsPuAoi.setAoiDispatchChkeFc(omsPuAoi.getAoiDispatchChke * errorCall)
    omsPuAoi.setAoiDispatchChknFc(omsPuAoi.getAoiDispatchChkn * errorCall)
    omsPuAoi.setAoiDispatchNormFc(omsPuAoi.getAoiDispatchNorm * errorCall)
    omsPuAoi.setAoiDispatchPhoneFc(omsPuAoi.getAoiDispatchPhone * errorCall)
    omsPuAoi.setAoiDispatchRoadFc(omsPuAoi.getAoiDispatchRoad * errorCall)
    omsPuAoi.setAoiDispatchTc2Fc(omsPuAoi.getAoiDispatchTc2 * errorCall)
  }

  def getAdminArea(adminAreaMap: util.Map[String, util.List[AdminArea]], cityCode: String,
                   city: String, address: String, errCallResno: String, errCallCity: String, errCallAddrabb: String): AdminArea = {
    var adminArea: AdminArea = null
    if (!cityCode.isEmpty && adminAreaMap.containsKey(cityCode)) {
      val adminAreaList = adminAreaMap.get(cityCode)
      if (adminAreaList.size() == 1) {
        adminArea = adminAreaList.get(0)
      } else {
        for (area: AdminArea <- adminAreaList) {
          if (!city.isEmpty && area.getCity.contains(city)) {
            adminArea = area
          } else if (!errCallCity.isEmpty && area.getCity.contains(errCallCity)) {
            adminArea = area
          } else if (!address.isEmpty && address.contains(area.getCity)) {
            adminArea = area
          } else if (!errCallAddrabb.isEmpty && errCallAddrabb.contains(area.getCity)) {
            adminArea = area
          }
        }
      }
    } else if (!errCallResno.isEmpty && adminAreaMap.containsKey(errCallResno)) {
      val adminAreaList = adminAreaMap.get(errCallResno)
      if (adminAreaList.size() == 1) {
        adminArea = adminAreaList.get(0)
      } else {
        for (area: AdminArea <- adminAreaList) {
          if (!city.isEmpty && area.getCity.contains(city)) {
            adminArea = area
          } else if (!errCallCity.isEmpty && area.getCity.contains(errCallCity)) {
            adminArea = area
          } else if (!address.isEmpty && address.contains(area.getCity)) {
            adminArea = area
          } else if (!errCallAddrabb.isEmpty && errCallAddrabb.contains(area.getCity)) {
            adminArea = area
          }
        }
      }
    }
    if (adminArea == null) {
      adminArea = new AdminArea
      adminArea.setCityCode(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setRegion(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setProvince(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setCity(VariableConstant.DEFAULT_VALUE_STRING)
    }
    adminArea
  }

  def updateSaveRdd(newRdd: RDD[(String, JSONObject)]): Unit = {
    logger.error("需要保存的数量：" + newRdd.count())
    if (needSaveRdd == null) {
      needSaveRdd = newRdd
    } else {
      needSaveRdd = needSaveRdd.union(newRdd)
    }
  }
}
