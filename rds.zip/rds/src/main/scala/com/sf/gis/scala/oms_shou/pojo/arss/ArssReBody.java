package com.sf.gis.scala.oms_shou.pojo.arss;

import java.io.Serializable;

/**
 * Created by 01368078 on 2019/1/8.
 */
public class ArssReBody  implements Serializable {
    private ArssReData data;
    private String dateTime;
    private String dataType;
    private String type;
    private String nodeId;
    private String reqId;

    public ArssReData getData() {
        return data;
    }

    public void setData(ArssReData data) {
        this.data = data;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }
}
