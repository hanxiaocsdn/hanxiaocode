package com.sf.gis.scala.rds.app

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.rds.util.{HttpConnection, MD5Util, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.immutable.StringLike

/**
 * 派件AOI与运单AOI距离计算逻辑_V1.0
 * Created by 01417629 on 2021-12-02
 * 任务id：395512
 */
//noinspection DuplicatedCode
object DispatchWaybillAOIDistance {
  @transient lazy val logger: Logger = Logger.getLogger(DispatchWaybillAOIDistance.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  val url = "http://gis-apis.int.sfcloud.local:1080/dept2/routeplan/aois_boundary?"


  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val parDay_1 = args(0)//t-1分区
    val parDay_2 = args(1)//t-8分区
    val parDay_3 = args(2)//t-2分区
    val parDay_4 = args(3)//t-2分区
    run(spark,parDay_1,parDay_2,parDay_3,parDay_4)
    spark.close()
  }


  def run(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String,parDay_4 : String): Unit ={
    println(parDay_1 + "-->" + parDay_2 + "-->" + parDay_3 + "-->" + parDay_4)
    val waybillInfo = getWaybillInfo(spark,parDay_1,parDay_2,parDay_3,parDay_4)

    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "395512", "派件AOI与运单AOI距离计算逻辑_V1.0", "派件AOI与运单AOI距离计算", "http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy", "7f8938c656044f9ca9bcc40f4407f351", waybillInfo.count(), 1)
    val dispatchAOIID = getDispatchAOIID(waybillInfo)
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)

    val httpInvokeId1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "395512", "派件AOI与运单AOI距离计算逻辑_V1.0", "派件AOI与运单AOI距离计算", "http://gis-apis.int.sfcloud.local:1080/dept2/routeplan/aois_boundary", "7f8938c656044f9ca9bcc40f4407f351", dispatchAOIID.count(), 1)
    val aoisBoundary = getAoisBoundary(dispatchAOIID)
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId1)
    saveResult2Hive(spark,aoisBoundary,parDay_1)
    aoisBoundary.unpersist()
  }


  /**
   * 获取运单信息数据
   * @param spark
   * @param parDay_2
   * @return
   */
  def getWaybillInfo(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String,parDay_4 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |SELECT
         |	 t.mainwaybillno	AS mainwaybillno
         |	,t.aoi_id           AS aoi_id
         |	,t.aoi_code         AS aoi_code
         |	,t.aoi_name         AS aoi_name
         |	,t.aoi_type_code    AS aoi_type_code
         |	,t.delivery_lgt     AS delivery_lgt
         |	,t.delivery_lat     AS delivery_lat
         |FROM
         |(
         |	SELECT
         |		 t1.mainwaybillno   AS mainwaybillno
         |		,t2.aoi_id          AS aoi_id
         |		,t2.aoi_code        AS aoi_code
         |		,t2.aoi_name        AS aoi_name
         |		,t2.aoi_type_code   AS aoi_type_code
         |		,t2.delivery_lgt    AS delivery_lgt
         |		,t2.delivery_lat    AS delivery_lat
         |		,row_number() over(partition by t1.mainwaybillno,t2.aoi_id,t2.aoi_code,t2.aoi_name,t2.aoi_type_code,t2.delivery_lgt,t2.delivery_lat order by t2.inc_day desc) AS rn
         |	FROM
         |	(
         |		SELECT
         |			mainwaybillno
         |		FROM ods_kafka_fvp.fvp_core_fact_route
         |		WHERE inc_day >= '$parDay_4' AND inc_day <= '$parDay_1'
         |		AND opcode='70'
         |		AND staywhycode='4'
         |		GROUP BY mainwaybillno
         |	) t1
         |	LEFT JOIN
         |	(
         |		SELECT
         |			 waybill_no
         |			,aoi_id
         |			,aoi_code
         |			,aoi_name
         |			,aoi_type_code
         |			,delivery_lgt
         |			,delivery_lat
         |			,inc_day
         |		FROM
         |		dm_gis.tt_waybill_hook
         |		WHERE inc_day >= '$parDay_2' AND inc_day <= '$parDay_3'
         |	) t2
         |	ON t1.mainwaybillno = t2.waybill_no
         |) t
         |WHERE t.rn = 1
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val waybillInfo = Util.getRowToJson(spark,sql,1)
    logger.error(s">>>获取运单信息共 ${waybillInfo.count()} 条s<<<")
    waybillInfo
  }


  /**
   * 获取派件AOIID
   * @param waybillInfo
   * @return
   */
  def getDispatchAOIID(waybillInfo: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val dispatchAOIID = waybillInfo.map(obj => {
      val delivery_lgt = obj.getString("delivery_lgt")
      val delivery_lat = obj.getString("delivery_lat")
      var json : JSONObject = null

      val url = "http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy?x=%f&y=%f&ak=7f8938c656044f9ca9bcc40f4407f351"
      json = getRunDispatchAOIID(url,delivery_lgt,delivery_lat)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取AOI信息共 ${dispatchAOIID.count()} 条s<<<")
    waybillInfo.unpersist()
    dispatchAOIID
  }


  /**
   *
   * @param url
   * @param delivery_lgt
   * @param delivery_lat
   * @return
   */
  def getRunDispatchAOIID(url: String,delivery_lgt: String,delivery_lat : String): JSONObject = {
    var ret: JSONObject = null
    try {
      if (!delivery_lgt.isEmpty && !delivery_lat.isEmpty) {
        val urls = url.format(delivery_lgt.toDouble,delivery_lat.toDouble)
        val aoiInfo = HttpClientUtil.getJsonByGet(urls)
        if (aoiInfo != null && aoiInfo.getJSONObject("result") != null) {
          if (aoiInfo.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return getRunDispatchAOIID(url,delivery_lgt,delivery_lat)
          }
          ret = new JSONObject()
          var aoi_id,aoi_code,aoi_name,aoi_type = ""
          val result = aoiInfo.getJSONObject("result")
          if (result != null) {
            if (result.getJSONObject("data") != null){
              val aoi = result.getJSONObject("data").getJSONObject("aoi")
              if(aoi != null){
                aoi_id = aoi.getString("aoi_id")
                aoi_code = aoi.getString("aoi_code")
                aoi_name = aoi.getString("aoi_name")
                aoi_type = aoi.getString("aoi_type")
              }
            }
          }
          ret.put("aoi_id",aoi_id)
          ret.put("aoi_code",aoi_code)
          ret.put("aoi_name",aoi_name)
          ret.put("aoi_type",aoi_type)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  /**
   *  获取派件aoi与运单aoi的最小距离
   * @param dispatchAOIID
   */
  def getAoisBoundary(dispatchAOIID : RDD[(JSONObject,JSONObject)]): RDD[((JSONObject,JSONObject),JSONObject)] ={
    val aoisBoundary = dispatchAOIID.map(obj => {
      val aoi_id_waybill = obj._1.getString("aoi_id")
      var json : JSONObject = null
      var aoi_id_xg = ""
      if(obj._2 != null){
        aoi_id_xg = obj._2.getString("aoi_id")
        val aoi_id_list = Array(aoi_id_xg,aoi_id_waybill)
        val param = new JSONObject()
        param.put("ak","7f8938c656044f9ca9bcc40f4407f351")
        param.put("aoi_id_list",aoi_id_list)
        json = postAoisBoundary(url,param.toJSONString)
      }
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取AOI与AOI LIST边界最小距离共 ${aoisBoundary.count()} 条s<<<")
    dispatchAOIID.unpersist()
    aoisBoundary
  }


  /**
   *
   * @param url
   * @param params
   * @return
   */
  def postAoisBoundary(url: String,params: String): JSONObject = {
    var ret: JSONObject = null
    try {
      if (!params.isEmpty) {
        val httpData = HttpConnection.sendPost(url,params)
        if (httpData != null && httpData.containsKey("content") && httpData.get("content") != null) {
          val content = httpData.get("content").toString
          val xyObj = JSON.parseObject(content)
          if (xyObj != null && xyObj.getJSONObject("result") != null) {
            if (xyObj.getJSONObject("result").getInteger("err") == 109) {
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep(60 - second)
              return postAoisBoundary(url,params)
            }
            ret = new JSONObject()
            var min_dist = ""
            val result = xyObj.getJSONObject("result")
            if(result != null){
              val data = result.getJSONObject("data")
              if(data != null){
                val aois = data.getJSONArray("aois")
                if(aois != null && aois.size() > 0){
                  val json = JSON.parseObject(aois.get(0).toString)
                  if(json != null){
                    min_dist = json.getString("min_dist")
                  }
                }
              }
            }
            ret.put("min_dist",min_dist)
          }
        }else{
          ret.put("code",httpData.get("code"))
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  /**
   * 写入Hive表
   * @param spark
   * @param aoisBoundary
   */
  def saveResult2Hive(spark : SparkSession,aoisBoundary : RDD[((JSONObject,JSONObject),JSONObject)],parDay_1 : String): Unit ={
    val descDBName = "dm_gis"
    val descTableName = "dispatch_waybill_aoi_distance"
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION (inc_day = '$parDay_1')
         |SELECT
         |	 waybill_no
         |	,aoi_id_waybill
         |	,aoi_code_waybill
         |	,aoi_name_waybill
         |	,aoi_type_waybill
         |	,xg_lgt
         |	,xg_lat
         |	,aoi_id_xg
         |	,aoi_code_xg
         |	,aoi_name_xg
         |	,aoi_type_xg
         |	,distance
         |FROM dispatch_waybill_aoi_distance_tmp
         |""".stripMargin
    val schemaString = "waybill_no,aoi_id_waybill,aoi_code_waybill,aoi_name_waybill,aoi_type_waybill" +
      ",xg_lgt,xg_lat,aoi_id_xg,aoi_code_xg,aoi_name_xg,aoi_type_xg,distance"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
    )
    val schema = StructType(fields)
    val rdd = aoisBoundary.map(obj => {
      val row = obj._1._1
      val json = obj._1._2
      val json1 = obj._2
      val sb = new StringBuilder()
      sb.append(row.getString("mainwaybillno")).append("\t\t\t")
      sb.append(row.getString("aoi_id")).append("\t\t\t")
      sb.append(row.getString("aoi_code")).append("\t\t\t")
      sb.append(row.getString("aoi_name")).append("\t\t\t")
      sb.append(row.getString("aoi_type_code")).append("\t\t\t")
      sb.append(row.getString("delivery_lgt")).append("\t\t\t")
      sb.append(row.getString("delivery_lat")).append("\t\t\t")
      if(json != null){
        sb.append(json.getString("aoi_id")).append("\t\t\t")
        sb.append(json.getString("aoi_code")).append("\t\t\t")
        sb.append(json.getString("aoi_name")).append("\t\t\t")
        sb.append(json.getString("aoi_type")).append("\t\t\t")
      }else{
        sb.append("").append("\t\t\t")
        sb.append("").append("\t\t\t")
        sb.append("").append("\t\t\t")
        sb.append("").append("\t\t\t")
      }
      if(json1 != null){
        sb.append(json1.getString("min_dist")).append("\t\t\t")
      }else{
        sb.append("").append("\t\t\t")
      }
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
      ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10),attr(11)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.createOrReplaceTempView("dispatch_waybill_aoi_distance_tmp")
    df.show(5)

    //插入数据
    logger.error(">>>>>>>>>>入hive库开始")
    val resultDF = spark.sql(insertSQL)
    resultDF.show(5)
    logger.error(">>>>>>>>>>入hive库结束")

    spark.sql("drop table if exists dispatch_waybill_aoi_distance_tmp")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>删除临时表: dispatch_waybill_aoi_distance_tmp")

  }




}
