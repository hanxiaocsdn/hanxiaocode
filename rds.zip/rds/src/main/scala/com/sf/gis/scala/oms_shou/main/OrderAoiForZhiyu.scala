package com.sf.gis.scala.oms_shou.main

import java.net.URLEncoder
import java.util.Date

import com.alibaba.fastjson.{JSON, JSONObject}
import com.csvreader.CsvReader
import com.sf.gis.com.sf.gis.scala.oms_shou.constant.FixedConstant
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.config.DomainConfig
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.{HttpConnection, JSONUtil}
import com.sf.gis.scala.utils.{DateUtil, StringUtil}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01374443 on 2019/3/5.
 * 任务id:225151
 * 任务名称：收件日志aoi-智域
 * 开发：张想远
 * 业务：蓝媛青
 *
 */
//TODO 此任务需要优化，按照参数排重再调用接口
object OrderAoiForZhiyu {
  @transient lazy val logger: Logger = Logger.getLogger(OrderAoiForZhiyu.getClass)
  // 生成的两种类型, 包含在json对象中
  val finalTable = "rds_omsfrom_aoi"
  val finalFields = Array("waybillNo", "orderNo", "sysOrderNo", "sysSource",
    "cityCode", "province", "city", "county", "address", "company", "mobile",
    "phone", "contactsName", "reqTime", "orderTime", "customerId",
    "customerAccount", "isNotUnderCall", "orderType", "pickupType",
    "orderMsgSrc", "deptCode", "teamCode", "aoiCode", "aoiParentCode")
  val omsFromTable = "dm_gis.gis_rds_omsfrom"
  val omsFromFields = Array("waybillNo", "orderNo", "sysOrderNo",
    "sysSource", "cityCode", "province", "city", "county", "address",
    "company", "mobile", "phone", "contactsName", "syncReqDateTime",
    "customerId", "customerAccount", "isNotUnderCall", "orderType",
    "pickupType", "deptCode", "teamCode", "finalAoicode", "chkomsaoi")
  val finalFromFieldsMap: Map[String, String] = Map("reqTime" -> "syncReqDateTime",
    "aoiCode" -> "finalAoicode"
  )
  val omsFvpTable = "dm_gis.fvp_log_flink_collect"
  val fvpFields = Array("sfOrderId", "sysOrderId", "sysSource",
    "senderCityCode", "senderProvince", "senderCityName", "senderArea",
    "senderAddr", "senderCompany", "senderMobile", "senderTel",
    "senderName", "orderTime", "monthlyCard", "isUnderCall",
    "orderType", "pickupType")
  val finalFvpFieldsMap: Map[String, String] = Map("orderNo" -> "sfOrderId",
    "sysOrderNo" -> "sysOrderId", "cityCode" -> "senderCityCode",
    "province" -> "senderProvince", "city" -> "senderCityName",
    "county" -> "senderArea", "address" -> "senderAddr", "company" -> "senderCompany",
    "mobile" -> "senderMobile", "phone" -> "senderTel", "contactsName" -> "senderName",
    "customerAccount" -> "monthlyCard", "isNotUnderCall" -> "isUnderCall")
  val omsSgsTable = "dm_gis.sgs_log_flink_collect"
  val sgsFields = Array("waybillMainNo", "txId", "appointmentNo",
    "sysSource", "locationCode", "province", "city", "county", "address",
    "company", "mobile", "phone", "contact", "kafkaTime", "customerId",
    "isUnderCall", "orderType", "pickupType")
  val finalSgsFieldsMap: Map[String, String] = Map("waybillNo" -> "waybillMainNo",
    "orderNo" -> "txId", "sysOrderNo" -> "appointmentNo", "cityCode" -> "locationCode",
    "contactsName" -> "contact", "orderTime" -> "kafkaTime",
    "isNotUnderCall" -> "isUnderCall")
  var incDay: String = DateUtil.dateBefore(FixedConstant.DATE_FORMAT2, 1)
  val appName = "OrderAoiForZhiyu"

  val rongZaiShouUrl: String = "/atconsignee/team/byaddr?" +
    "province=%s&cityName=%s&district=%s&address=%s&city=%s&ak=c274bbf7007c411c8e21a6abe31a9886" +
    "&opt=zh&company=%s&tel=%s&mobile=%s&callDispatch=1"

  def main(args: Array[String]): Unit = {
    if (args.length > 0) {
      incDay = args(0)
    }
    logger.error("incDay:" + incDay)
    start()
  }

  def start(): Unit = {
    //    val conf = new SparkConf().setAppName(appName)
    //    conf.set("spark.port.maxRetries", "100")
    //    conf.set("spark.driver.allowMultipleContexts", "true")
    //    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    //    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    //    conf.set("quota.consumer.default", (10485760 * 2).toString)
    //    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    //    //    conf.set("spark.executor.instances","50")
    //    conf.set("spark.executor.instances", "30")
    //    conf.set("spark.executor.memory", "20g")
    //    conf.set("spark.yarn.executor.memoryOverhead", "8g")
    //    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    //    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    val spark = Spark.getSparkSession(appName)
    spark.sparkContext.setLogLevel("ERROR")
    deal(spark)
  }

  def getCmsDept: Map[String, String] = {
    val cityCodes = "010,511,514,519,660,663,754,768,411,415,769,757,758,766,591,593,598,599,930,931,932,933,934,935,936,937,938,939,941,943,970,971,972,973,974,975,976,977,979,701,791,792,793,798,790,794,795,796,797,799,770,771,772,773,774,775,776,777,778,779,020,751,763,052,053,851,854,855,856,857,858,859,898,8981,451,452,453,454,455,456,457,458,459,464,467,468,469,470,027,710,711,712,713,714,715,716,717,718,719,722,724,728,752,753,762,431,432,433,434,435,436,437,438,439,482,530,531,534,537,538,634,635,313,314,315,316,317,335,310,311,312,318,319,570,578,579,532,535,631,533,536,539,543,546,632,633,025,513,515,471,472,473,474,475,476,477,478,479,483,574,580,951,952,953,954,955,594,595,592,596,597,349,350,351,352,353,354,355,356,357,358,359,029,911,912,913,914,915,916,917,919,021,755,024,412,414,416,417,418,419,421,427,429,028,812,813,816,817,818,825,826,827,830,831,832,833,834,835,836,837,838,839,891,892,893,894,895,896,516,517,518,527,512,576,022,551,552,554,557,558,561,564,550,553,555,556,559,562,563,566,577,510,523,730,7311,7312,7313,734,735,736,737,738,739,743,744,745,746,901,902,903,906,908,909,990,991,992,993,994,995,996,997,998,999,370,371,372,373,378,391,392,393,374,375,376,377,379,394,395,396,398,662,668,750,756,759,760,086,088,691,692,870,871,872,873,874,875,876,877,878,879,883,887,571,572,573,575,023"
    val cityCodeArray = cityCodes.split(",")
    var retMap: Map[String, String] = Map()
    val url = "http://gis-cms-bg.sf-express.com/cms/api/zno/getZnoBySzDepart?cityCode=%s"
    for (cityCode <- cityCodeArray) {
      val urlStr = String.format(url, cityCode)
      logger.error(urlStr)
      try {
        val ret = HttpConnection.doGet(urlStr, FixedConstant.CHARSET)
        val datJson = JSON.parseObject(ret)
        val data = datJson.getJSONArray("data")
        for (i <- 0 until data.size()) {
          val item = data.getJSONObject(i)
          retMap += (item.getString("znoCode") -> item.getString("departCode"))
        }

      } catch {
        case e: Exception => logger.error(e)
      }
    }
    logger.error("cmsDeptMap size:" + retMap.size)
    retMap
  }

  def getVirtualDeptList: ArrayBuffer[String] = {
    val list = new ArrayBuffer[String]
    val xiaogePath = System.getProperty("user.dir") + "/virtual_dept.csv"
    val csvReader = new CsvReader(xiaogePath)
    if (csvReader.readRecord()) println("headers:" + csvReader.getValues.mkString(","))
    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val deptcode = row(0)
      if (deptcode != null && !deptcode.isEmpty) {
        list += deptcode
      }
    }
    logger.error("虚拟网点数量:" + list.size)
    list
  }

  def getRdsFromData(spark: SparkSession, incDay: String): RDD[(String, JSONObject)] = {
    val columnsBuilder = new StringBuilder("")
    for (i <- omsFromFields.indices) {
      columnsBuilder.append(omsFromFields.apply(i)).append(",")
    }
    columnsBuilder.deleteCharAt(columnsBuilder.length - 1)
    val sql =
      s"select * from( " +
        s"select ${columnsBuilder.toString()}, " +
        "get_JSON_object(chkomsrebody,'$.orderFrom.deptCode') ksDeptCode, " +
        s"inc_day,row_number() over(partition BY sysorderno " +
        s" order by syncReqDateTime desc ) as rank from $omsFromTable " +
        s"where inc_day = '$incDay'and sysorderno<> '' " +
        s" )a where a.rank=1  "
    logger.error(">>>aoi sql :" + sql)
    val rdd = spark.sql(sql).rdd.repartition(200) map (row => {
      val obj = new JSONObject()
      for (i <- omsFromFields.indices) {
        obj.put(omsFromFields(i), row.getString(i))
      }
      val ksDeptCode = row.getString(omsFromFields.length)
      val finalAoicode = obj.getString("finalAoicode")
      val chkomsaoi = obj.getString("chkomsaoi")
      if (StringUtil.isBlank(finalAoicode) && !StringUtil.isBlank(chkomsaoi)) {
        obj.put("finalAoicode", chkomsaoi)
        obj.put("deptCode", ksDeptCode)
      }
      obj.put("orderMsgSrc", "1")
      val ret = new JSONObject()
      for (i <- finalFields.indices) {
        if (obj.containsKey(finalFields(i))) {
          ret.put(finalFields(i), obj.getString(finalFields(i)))
        } else if (finalFromFieldsMap.contains(finalFields(i)) && obj.containsKey(finalFromFieldsMap.apply(finalFields(i)))) {
          ret.put(finalFields(i), obj.getString(finalFromFieldsMap.apply(finalFields(i))))
        } else {
          ret.put(finalFields(i), "")
        }
      }
      (ret.getString("sysOrderNo"), ret)
    })
    rdd
  }

  def getOmsFvpData(spark: SparkSession, incDay: String): RDD[(String, JSONObject)] = {
    val columnsBuilder = new StringBuilder("")
    for (i <- fvpFields.indices) {
      columnsBuilder.append(fvpFields.apply(i)).append(",")
    }
    columnsBuilder.deleteCharAt(columnsBuilder.length - 1)
    val sql =
      s"""select * from(
         |select ${columnsBuilder.toString()},inc_day,row_number() over(partition BY sysOrderId
         | order by orderTime desc) as rank from $omsFvpTable where inc_day = '$incDay'and sysOrderId<> ''
         | )a where a.rank=1 """.stripMargin
    logger.error(">>>aoi sql :" + sql)
    val rdd = spark.sql(sql).rdd.repartition(200).map(row => {
      val obj = new JSONObject()
      for (i <- fvpFields.indices) {
        obj.put(fvpFields(i), row.getString(i))
      }
      obj.put("orderMsgSrc", "2")
      val ret = new JSONObject()
      for (i <- finalFields.indices) {
        if (obj.containsKey(finalFields(i))) {
          ret.put(finalFields(i), obj.getString(finalFields(i)))
        } else if (finalFvpFieldsMap.contains(finalFields(i)) && obj.containsKey(finalFvpFieldsMap.apply(finalFields(i)))) {
          ret.put(finalFields(i), obj.getString(finalFvpFieldsMap.apply(finalFields(i))))
        } else {
          ret.put(finalFields(i), "")
        }
      }
      (ret.getString("sysOrderNo"), ret)
    })
    rdd
  }

  def getOmsSgsData(spark: SparkSession, incDay: String): RDD[(String, JSONObject)] = {
    val columnsBuilder = new StringBuilder("")
    for (i <- sgsFields.indices) {
      columnsBuilder.append(sgsFields.apply(i)).append(",")
    }
    columnsBuilder.deleteCharAt(columnsBuilder.length - 1)
    val sql =
      s"""select * from(
         |select ${columnsBuilder.toString()},inc_day,row_number() over(partition BY appointmentNo
         | order by kafkaTime desc) as rank from $omsSgsTable where inc_day = '$incDay'and appointmentNo<> ''
         | )a where a.rank=1 """.stripMargin
    logger.error(">>>aoi sql :" + sql)
    val rdd = spark.sql(sql).rdd.repartition(200) map (row => {
      val obj = new JSONObject()
      for (i <- sgsFields.indices) {
        obj.put(sgsFields(i), row.getString(i))
      }
      obj.put("orderMsgSrc", "3")
      val ret = new JSONObject()
      for (i <- finalFields.indices) {
        if (obj.containsKey(finalFields(i))) {
          ret.put(finalFields(i), obj.getString(finalFields(i)))
        } else if (finalSgsFieldsMap.contains(finalFields(i)) && obj.containsKey(finalSgsFieldsMap.apply(finalFields(i)))) {
          ret.put(finalFields(i), obj.getString(finalSgsFieldsMap.apply(finalFields(i))))
        } else {
          ret.put(finalFields(i), "")
        }
      }
      (ret.getString("sysOrderNo"), ret)
    })
    rdd
  }

  def reduce(rdsFromRdd: RDD[(String, JSONObject)], omsFvpRdd: RDD[(String, JSONObject)], omsSgsRdd: RDD[(String, JSONObject)]): RDD[JSONObject] = {
    val reduceDataRdd = rdsFromRdd.union(omsFvpRdd).union(omsSgsRdd)
      .reduceByKey((obj1, obj2) => {
        if (obj1.getString("orderMsgSrc").equals("1")) {
          obj1
        } else if (obj2.getString("orderMsgSrc").equals("1")) {
          obj2
        } else {
          val reqTime1 = obj1.getString("orderTime")
          val reqTime2 = obj2.getString("orderTime")
          if (reqTime1.compareTo(reqTime2) >= 0) {
            obj1
          } else {
            obj2
          }
        }
      }).values
    reduceDataRdd
  }

  def queryDecryptData(spark: SparkSession, incDay: String) = {
    val sql =
      s" select * from( " +
        s" select addr_encrpt,consignor_addr,row_number() over(partition BY addr_encrpt " +
        s" order by consignor_addr desc ) as rank from dm_gis.waybill_shou_address " +
        s" where inc_day = '$incDay' " +
        s" and consignor_addr is not null " +
        s" and consignor_addr<>'' and consignor_addr not like 'DE#%' " +
        s" )a where a.rank=1  "
    val dataRdd = spark.sql(sql).rdd.map(obj=>{
      (obj.getString(0),obj.getString(1))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("decrypt addr count:"+dataRdd.count())
    dataRdd
  }

  def joinDecryptData(noDeptRdd: RDD[JSONObject], decryptAddrRdd: RDD[(String, String)]) = {
    val joinDataRdd = noDeptRdd.map(obj=>{
      (obj.getString("address"),obj)
    }).leftOuterJoin(decryptAddrRdd).map(obj=>{
      val leftBody = obj._2._1
      val rightBody = obj._2._2
      if(rightBody.nonEmpty){
        val decrptAddr = rightBody.get
        leftBody.put("address",decrptAddr)
      }
      leftBody
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("解密后总数："+joinDataRdd.count())
    noDeptRdd.unpersist()
    decryptAddrRdd.unpersist()
    logger.error("解密地址量："+joinDataRdd.filter(obj=>{
      !JSONUtil.getJsonValSingle(obj,"address","").startsWith("DE#")
    }).count())
    joinDataRdd
  }

  def fillAoiInfo(spark:SparkSession, reduceDataRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val omsFromRdd = reduceDataRdd.filter(obj => "1".equals(obj.getString("orderMsgSrc")))
      .persist(StorageLevel.DISK_ONLY)
    logger.error("omsFrom count:" + omsFromRdd.count())
    val noDeptRdd = reduceDataRdd.filter(obj => !"1".equals(obj.getString("orderMsgSrc")))
      .persist(StorageLevel.DISK_ONLY)
    val dataCount = noDeptRdd.count()
    logger.error("sgs fvp count:" + dataCount)
    reduceDataRdd.unpersist()

    logger.error("join decrypt table")
    val decryptAddrRdd = queryDecryptData(spark,incDay);
    val noDeptJoinRdd = joinDecryptData(noDeptRdd,decryptAddrRdd)
   logger.error("fill aoi fvp")
    val rongDomain = DomainConfig.findRongZaiDomain(spark)
    val id = BdpTaskRecordUtil.startRunNetworkInterface(spark,"01374443","225151","收件日志aoi-智域","",rongDomain+rongZaiShouUrl,"c274bbf7007c411c8e21a6abe31a9886",dataCount,100)
    val fillDeptRdd = noDeptJoinRdd.repartition(100).mapPartitions(obj => {
      var count = 0
      obj.map(objItem => {
        val addr = JSONUtil.getJsonValSingle(objItem,"address","")
        if( !addr.isEmpty && !addr.startsWith("DE#")){
          updateDeptCode(objItem,rongDomain)
        }
        count = count + 1
        if (count % 10000 == 0) {
          logger.error("count:" + count)
        }
        objItem
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error("fill dept count:" + fillDeptRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01374443",id);
    noDeptJoinRdd.unpersist()
    val retRdd = omsFromRdd.union(fillDeptRdd).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>finalDataRdd num ${retRdd.count()}")
    omsFromRdd.unpersist()
    fillDeptRdd.unpersist()
    retRdd
  }

  def updateDeptCode(obj: JSONObject,rongDomain:String): Unit = {
    var tryAgain = true
    var tryCount = 10
    while (tryAgain && tryCount > 0) {
      tryAgain = false
      tryCount = tryCount - 1
      var url = ""
//      var isAkLimit = false
      try {
        val province = URLEncoder.encode(obj.getString("province"), "UTF-8")
        val cityName = URLEncoder.encode(obj.getString("city"), "UTF-8")
        val district = URLEncoder.encode(obj.getString("county"), "UTF-8")
        val address = URLEncoder.encode(obj.getString("address"), "UTF-8")
        val city = obj.getString("cityCode")
        val company = URLEncoder.encode(obj.getString("company"), "UTF-8")
        val tel = URLEncoder.encode(obj.getString("phone"), "UTF-8")
        val mobile = URLEncoder.encode(obj.getString("mobile"), "UTF-8")
        url = String.format(rongDomain+rongZaiShouUrl, province, cityName, district, address, city,
          company, tel, mobile)
        val retStr = HttpConnection.doGet(url, FixedConstant.CHARSET)
        val retObj = JSON.parseObject(retStr)
        if (retObj.getInteger("status") == 0 && retObj.getJSONObject("result") != null
          && retObj.getJSONObject("result").getJSONArray("tcs") != null) {
          val tcs = retObj.getJSONObject("result").getJSONArray("tcs")
          if (tcs.size() > 0) {
            val tcsItem = tcs.getJSONObject(0)
            val dept = tcsItem.getString("dept")
            val team = tcsItem.getString("team")
            val aoicode = tcsItem.getString("aoicode")
            if (dept != null) {
              obj.put("deptCode", dept)
            }
            if (team != null) {
              obj.put("teamCode", team)
            }
            if (team != null) {
              obj.put("aoiCode", aoicode)
            }
          }
        } else if (retObj.getJSONObject("result") != null
          && (retObj.getJSONObject("result").getInteger("err") == 109)) {
//          isAkLimit = true
          tryAgain = true
          logger.error("ak limit")
          val timeSecond = 60 - new Date().getSeconds
          if (timeSecond > 50) {
            Thread.sleep(5000)
          } else if(timeSecond == 0){
            //不会出现
          }
          else {
            Thread.sleep(timeSecond * 1000)
          }
        }
        //        logger.error("over")
      } catch {
        case e: Exception =>
          if(tryCount>7){
            Thread.sleep(1000*(10-tryCount))
            tryAgain=true
          }else{
            logger.error(e.getMessage)
            logger.error("tryCount:"+tryCount+",url:" + url)
          }
      }

    }

  }

  def fillAoiParent(finalDataRdd: RDD[JSONObject],
                    virtualDeptBc: Broadcast[ArrayBuffer[String]],
                    cmsDeptBc: Broadcast[Map[String, String]]): RDD[JSONObject] = {
    finalDataRdd.map(obj => {
      var aoiCode = JSONUtil.getJsonVal(obj, "aoiCode", "")
      val deptCode = JSONUtil.getJsonVal(obj, "deptCode", "")
      if (aoiCode.isEmpty && virtualDeptBc.value.contains(deptCode)) {
        aoiCode = deptCode + "999999"
        obj.put("aoiCode", aoiCode)
      }
      var aoiParentCode = ""
      if (aoiCode.length > 6) {
        val tmpCode = aoiCode.substring(0, aoiCode.length - 6)
        if (cmsDeptBc.value.contains(tmpCode)) {
          aoiParentCode = cmsDeptBc.value.apply(tmpCode)
        }
      }
      obj.put("aoiParentCode", aoiParentCode)
      obj
    })
  }

  /**
   * 处理
   *
   * @param spark : spark session
   */
  def deal(spark: SparkSession): Unit = {
    val virtualDept = getVirtualDeptList
    val virtualDeptBc = spark.sparkContext.broadcast(virtualDept)
    val cmsDept = getCmsDept
    //    System.exit(0)
    val cmsDeptBc = spark.sparkContext.broadcast(cmsDept)
    logger.error(">>>get omsfrom data")
    val rdsFromRdd = getRdsFromData(spark, incDay).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>omsFrom num ${rdsFromRdd.count()}")
    logger.error(">>>get omsFvp data")
    val omsFvpRdd = getOmsFvpData(spark, incDay).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>omsFvp num ${omsFvpRdd.count()}")
    logger.error(">>>get omsSgs data")
    val omsSgsRdd = getOmsSgsData(spark, incDay).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>omsSgs num ${omsSgsRdd.count()}")
    logger.error(s">>>start reduce")
    val reduceDataRdd = reduce(rdsFromRdd, omsFvpRdd, omsSgsRdd).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>reduceDataRdd num ${reduceDataRdd.count()}")
    rdsFromRdd.unpersist()
    omsFvpRdd.unpersist()
    omsSgsRdd.unpersist()
    logger.error("fill dept")
    val finalDataRdd = fillAoiInfo(spark,reduceDataRdd)
    logger.error("填充虚拟网点")
    val fillParentRdd = fillAoiParent(finalDataRdd, virtualDeptBc, cmsDeptBc)
    logger.error("start save final data")
    saveFinalData(spark, fillParentRdd, incDay)
    finalDataRdd.unpersist()
    logger.error("end")
  }

  def saveFinalData(spark: SparkSession, aoiRdd: RDD[JSONObject], incDay: String): Unit = {
    SparkWrite.save2HiveStaticRandom(spark, aoiRdd, finalFields, "dm_gis." + finalTable, Array(("inc_day", incDay)), 80)
  }

  //  def saveFinalData(spark: SparkSession, aoiRdd: RDD[JSONObject], incDay: String): Unit = {
  //    val rows = aoiRdd.map(obj => {
  //      val rowBuilder = new StringBuilder
  //      for (name <- finalFields) {
  //        var tmp = obj.getString(name)
  //        if (tmp == null) {
  //          tmp = ""
  //        }
  //        rowBuilder.append(tmp.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "")).append("\t")
  //      }
  //      rowBuilder.toString()
  //    })
  //
  //    val dropSql = String.format("alter table dm_gis.%s drop if exists partition(inc_day = '%s')", finalTable, incDay)
  //    spark.sql(dropSql)
  //    ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R /user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, incDay))
  //    rows.saveAsTextFile(String.format("/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, incDay))
  //    val addSql = String.format("alter table dm_gis.%s add if not exists partition(inc_day = '%s')", finalTable, incDay)
  //    spark.sql(addSql)
  //  }
}
