package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay

import java.net.URLEncoder
import java.sql.Connection
import java.util
import java.util.Properties

import com.alibaba.druid.pool.DruidDataSource
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{FileUtil, MD5Util, ShellExcutor}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay.WrongObj.AoiProObj
import com.sf.gis.scala.oms_pai.start.{ComUtil, JavaUtil}
import com.sf.gis.scala.utils.{DbUtils, StringUtil, Util}
import org.apache.log4j.Logger
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01374443 on 2020/6/1.
 * 已废弃
 */
object AoiRealWdResultPro {
  @transient lazy val logger: Logger = Logger.getLogger(AoiRealWdResultPro.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val javaUtil = new JavaUtil(6)
  val comUtil = new ComUtil(7)
  val commonPartition = 500

  /**
   * 获取cms库数据库连接
   *
   * @return
   */
  def getRdsConn(comUtil: ComUtil): Connection = {
    var conn: Connection = null
    var dataSource: DruidDataSource = null
    try {
      dataSource = new DruidDataSource()
      dataSource.setDriverClassName(comUtil.getValue("rds_mysql_driver"))
      dataSource.setUrl(comUtil.getValue("rds_mysql_url"))
      dataSource.setUsername(comUtil.getValue("rds_mysql_uid"))
      dataSource.setPassword(comUtil.getValue("rds_mysql_pwd"))
      dataSource.setMaxActive(20)
      dataSource.setMaxWait(3000)
      dataSource.setRemoveAbandoned(false)
      conn = dataSource.getConnection
    } catch {
      case e: Exception => println(">>>mysql数据库连接异常：" + e)
    }
    conn
  }

  def getStandardLogRddOmsBody(inputRdd: RDD[JSONObject],
                               sc: SparkContext,
                               comUtil: ComUtil): RDD[JSONObject] = {
    val conn = getRdsConn(comUtil)
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("province", "region", "city", "citycode")
    val regionSelectSql = s"select province,region,city,citycode from $regoinCityTable"
    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    logger.error("data size :" + regions.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val citycode = arr(3).toString
      if (cityMap.contains(citycode)) {
        val cityCodeList = cityMap.apply(citycode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (citycode -> cityCodeList)
      }
    }
    cityMap = sc.broadcast(cityMap).value
    //    cityMap.take(3).foreach(o=>println(o))

    //    inputRdd.take(5).foreach(o=>println(o))
    val standardLog = inputRdd.map(oms_body => {
      //      val json = new JSONObject()
      //      val oms_body = json.getJSONObject("oms_body")
      var city_code = oms_body.getString("reqCityCode")
      if (city_code == null) city_code = "-"
      oms_body.put("db_region", "")
      oms_body.put("db_province", "")
      oms_body.put("db_city", "")
      oms_body.put("city_code", city_code)
      val addresseeAddr = oms_body.getString("addr")
      var flag = false
      if (cityMap.contains(city_code)) {
        flag = true
        val cityList: ArrayBuffer[Array[String]] = cityMap.apply(city_code)
        if (cityList.length == 1) {
          //如果只有一个list，一一对应的，直接返回
          oms_body.put("db_province", cityList(0)(0))
          oms_body.put("db_region", cityList(0)(1))
          oms_body.put("db_city", cityList(0)(2))
        } else if (cityList.length > 1) {
          //一个城市代码对应多个城市
          oms_body.put("db_province", cityList(0)(0))
          oms_body.put("db_region", cityList(0)(1))
          for (cityObj <- cityList) {
            val city = cityObj(2)
            val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
            if (addresseeAddr.contains(city) || addresseeAddr.contains(city1)) {
              oms_body.put("db_city", cityObj(2))
            } else {
              if (oms_body.getString("db_city") == null) {
                oms_body.put("db_city", "-")
              }

            }
          }

        }
      }
      //      logger.error("region :"+json.getString("region"))
      (flag, oms_body)
    }).filter(_._1 == true).values
    standardLog
  }

  def fetchOriginWd(spark: SparkSession, incDay: String): (RDD[JSONObject], RDD[JSONObject]) = {
    val sql = s"select waybillno,req_addresseeaddr,gis_to_sys_groupid,gisaoisrc,xybodystr," +
      s" req_destcitycode,allAoiList,tag,finalZc,gisaoicode,ksaoicode,finalaoicode from dm_gis.aoi_real_wd_new  " +
      s" where inc_day='$incDay'"
    logger.error(sql)
    val dataRdd = spark.sql(sql).rdd.repartition(commonPartition).map(obj => {
      val json = new JSONObject()
      val columns = Array("waybillno", "addr", "groupId", "gisAoiSrc",
        "xyBodyStr", "reqCityCode", "allAoiList", "tag", "finalZc",
        "gisAoiCode", "ksAoiCode", "finalAoiCode")
      for (i <- columns.indices) {
        if (columns(i).equals("xyBodyStr")) {
          try {
            json.put(columns(i), JSON.parseObject(obj.getString(i)))
          } catch {
            case e: Exception => logger.error(e)
          }
        } else {
          json.put(columns(i), obj.getString(i))
        }
      }
      //      json.put("tag","wd")
      //      json.put("wdTag","origin")
      json
    })
    val standardResult = getStandardLogRddOmsBody(dataRdd,
      spark.sparkContext, comUtil).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("标准化后的地址量：" + standardResult.count())
    val normData = standardResult.filter(obj => !"wd".equals(obj.getString("tag")))
      .map(obj => {
        obj.put("tag", "right")
        obj
      })
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("正确量:" + normData.count())
    val wdData = standardResult.filter(obj => "wd".equals(obj.getString("tag")))
      .map(obj => {
        obj.put("wdTag", "origin")
        obj
      }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("错分量:" + wdData.count())
    standardResult.unpersist()
    (normData, wdData)
  }

  def runNormlize(url: String, addr: String, reqCityCode: String): (String, JSONObject) = {
    val urlStr = url.format(URLEncoder.encode(addr, "utf-8"), reqCityCode)
    val jObj = HttpClientUtil.getJsonByGet(urlStr)
    var normlizeAddress = ""
    if (jObj != null) {
      try {
        val result = jObj.getJSONArray("result")
        if (result.size() > 0) {
          normlizeAddress = result.getString(0)
        }
      } catch {
        case e: Exception => logger.error(e)
      }
    }
    (normlizeAddress, jObj)
  }

  def normlizeData(sc: SparkContext, originWdRdd: RDD[JSONObject], prop: Properties): (RDD[JSONObject], RDD[JSONObject]) = {
    val normlizeUrl = prop.getProperty("normlizeUrl")
    val normlizeBc = sc.broadcast(normlizeUrl)
    val normlizeRdd = originWdRdd.repartition(50).map(obj => {
      val reqCityCode = obj.getString("reqCityCode")
      val addr = obj.getString("addr")
      val (normlizeAddr, normlizeBody) = runNormlize(normlizeBc.value, addr, reqCityCode)
      obj.put("normlizeBody", normlizeBody)
      obj.put("normlizeAddr", normlizeAddr)
      if (!StringUtil.nonEmpty(normlizeAddr)) {
        obj.put("wdTag", "normlizeErr")
      } else {
        obj.put("normlizeAddrMd5", MD5Util.getMD5(normlizeAddr).toUpperCase)
      }
      obj
    }).repartition(commonPartition).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val normlizeOkData = normlizeRdd.filter(obj => StringUtil.nonEmpty(obj.getString("normlizeAddr"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("规范化ok数量:" + normlizeOkData.count())
    val normlizeErrData = normlizeRdd.filter(obj => !StringUtil.nonEmpty(obj.getString("normlizeAddr"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("规范化err数量:" + normlizeErrData.count())
    normlizeRdd.unpersist()
    (normlizeOkData, normlizeErrData)
  }

  def checkChknData(sc: SparkContext, normlizeDataRdd: RDD[JSONObject], prop: Properties,
                    cmsTableMap: util.HashMap[String, String]): (RDD[JSONObject], RDD[JSONObject]) = {
    val propBc = sc.broadcast(prop)
    val cmsTableMapBc = sc.broadcast(cmsTableMap)
    //    val cmsConnect = getCmsConn(propBc.value)
    //    normlizeDataRdd.take(500).foreach(obj=>{
    //      logger.error("start")
    //      val md5Set = new util.HashSet[String]()
    //      val selectChknSql = "select address_md5,aoi_id from cms_address_%s where city_code = '%s' and address_md5 = '%s' " +
    //        " and type = '2' and del_flag = 0 limit 1 "
    //
    //        val md5 = obj.getString("normlizeAddrMd5")
    //        val cityCityCode = obj.getString("reqCityCode")
    //        val cmsTableMap = cmsTableMapBc.value
    //        obj.put("cmsFlag","")
    //        obj.put("cmsAoiId","")
    //        if(cmsTableMap.containsKey(cityCityCode)){
    //          val selectSqlStr = String.format(selectChknSql,cmsTableMap.apply(cityCityCode),cityCityCode,md5)
    //          logger.error(selectSqlStr)
    //          val result = DbUtils.selectColumns(cmsConnect, selectSqlStr, Array("address_md5","aoi_id"))
    //          logger.error("result:"+result)
    //          if(result.length ==1 && md5.equals(result(0)(0))){
    //            obj.put("cmsAoiId",result(0)(1))
    //            obj.put("cmsFlag","chkn")
    //          }
    //          val groupId = obj.getString("groupId")
    //          if(!StringUtil.nonEmpty(obj.getString("cmsAoiId")) && StringUtil.nonEmpty(groupId)){
    //            val selectStdSql = "select address_id,aoi_id from cms_address_%s where city_code = '%s' and address_id = '%s' " +
    //              " and type = '1' and del_flag = 0 limit 1 "
    //            val selectStdSqlStr = String.format(selectStdSql,cmsTableMap.apply(cityCityCode),cityCityCode,groupId)
    //            logger.error(selectStdSqlStr)
    //            val result = DbUtils.selectColumns(cmsConnect, selectStdSqlStr, Array("address_id","aoi_id"))
    //            if(result.length ==1 && groupId.equals(result(0)(0))){
    //              obj.put("cmsAoiId",result(0)(1))
    //              obj.put("cmsFlag","stb")
    //            }
    //          }
    //        }
    //    })
    val chknCheckRdd = normlizeDataRdd.repartition(20).mapPartitions(rdds => {
      val cmsConnect = getCmsConn(propBc.value)
      var count = 0
      val md5Set = new util.HashSet[String]()
      val selectChknSql = "select address_md5,aoi_id from cms_address_%s where city_code = '%s' and address_md5 = '%s' " +
        " and type = '2' and del_flag = 0 limit 1 "
      rdds.map(obj => {
        count = count + 1
        if (count % 1000 == 0) {
          logger.error(count)
        }
        val md5 = obj.getString("normlizeAddrMd5")
        val cityCityCode = obj.getString("reqCityCode")
        val cmsTableMap = cmsTableMapBc.value
        obj.put("cmsFlag", "")
        obj.put("cmsAoiId", "")
        if (cmsTableMap.containsKey(cityCityCode)) {
          val selectSqlStr = String.format(selectChknSql, cmsTableMap.apply(cityCityCode), cityCityCode, md5)
          val result = DbUtils.selectColumns(cmsConnect, selectSqlStr, Array("address_md5", "aoi_id"))
          if (result.length == 1 && md5.equals(result(0)(0))) {
            obj.put("cmsAoiId", result(0)(1))
            obj.put("cmsFlag", "chkn")
          }
          val groupId = obj.getString("groupId")
          if (!StringUtil.nonEmpty(obj.getString("cmsAoiId")) && StringUtil.nonEmpty(groupId)) {
            val selectStdSql = "select address_id,aoi_id from cms_address_%s where city_code = '%s' and address_id = '%s' " +
              " and type = '1' and del_flag = 0 limit 1 "
            val selectStdSqlStr = String.format(selectStdSql, cmsTableMap.apply(cityCityCode), cityCityCode, groupId)
            val result = DbUtils.selectColumns(cmsConnect, selectStdSqlStr, Array("address_id", "aoi_id"))
            if (result.length == 1 && groupId.equals(result(0)(0))) {
              obj.put("cmsAoiId", result(0)(1))
              obj.put("cmsFlag", "std")
            }
          }
        }
        obj
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val matchDataRdd = chknCheckRdd.filter(obj => StringUtil.nonEmpty(obj.getString("cmsAoiId"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("匹配数量:" + matchDataRdd.count())
    val noMatchRdd = chknCheckRdd.filter(obj => !StringUtil.nonEmpty(obj.getString("cmsAoiId"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("无cms aoi数量:" + noMatchRdd.count())
    chknCheckRdd.unpersist()
    (matchDataRdd, noMatchRdd)
  }

  def getCmsConn(prop: Properties): Connection = {
    var conn: Connection = null
    var dataSource: DruidDataSource = null
    try {
      dataSource = new DruidDataSource()
      //      val prop = FileUtil.getFileProperties("cms_db.properties")
      dataSource.setDriverClassName(prop.getProperty("cms.mysql.driver"))
      dataSource.setUrl(prop.getProperty("cms.mysql.url"))
      dataSource.setUsername(prop.getProperty("cms.mysql.uid"))
      dataSource.setPassword(prop.getProperty("cms.mysql.pwd"))
      dataSource.setMaxActive(2)
      dataSource.setMaxWait(3000)
      dataSource.setRemoveAbandoned(false)
      conn = dataSource.getConnection
    } catch {
      case e: Exception => println(">>>mysql数据库连接异常：" + e)
    }
    conn
  }

  def parseCmsTableMap(prop: Properties): util.HashMap[String, String] = {
    val shardingDbObj = JSON.parseObject(prop.getProperty("shardingDb"))
    val shardingDbMap = new util.HashMap[String, String] //每个表的城市集合
    for (entry <- shardingDbObj.entrySet) {
      val array = entry.getValue.toString.split(",")
      for (item <- array) {
        shardingDbMap.put(item, entry.getKey)
      }
    }
    shardingDbMap
  }

  def fetchAoiInfo(spark: SparkSession): RDD[(String, String)] = {
    val sql = "select aoi_id,aoi_code  from  dm_gis.cms_aoi_sch where del_flag = 0 and aoi_id<> ''"
    val aoiInfoRdd = spark.sql(sql).rdd.map(row => {
      (row.getString(0), row.getString(1))
    }).reduceByKey((obj1, obj2) => {
      obj1
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("aoi数量：" + aoiInfoRdd.count())
    aoiInfoRdd
  }

  def fillCmsAoiCode(spark: SparkSession, matchDataRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val totalAoiMap = fetchAoiInfo(spark)
    val cmsAoiCodeRdd = matchDataRdd.repartition(50).map(obj => {
      val cmsAoiId = obj.getString("cmsAoiId")
      (cmsAoiId, obj)
    }).leftOuterJoin(totalAoiMap).map(obj => {
      val left = obj._2._1
      val rightOp = obj._2._2
      if (rightOp.nonEmpty) {
        left.put("cmsAoiCode", rightOp.get)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("关联后的数量:" + cmsAoiCodeRdd.count())
    totalAoiMap.unpersist()
    matchDataRdd.unpersist()
    cmsAoiCodeRdd
  }

  def mergeAoiIndex(obj1: AoiProObj, obj2: AoiProObj): AoiProObj = {
    val stat_date = obj1.stat_date
    val region = obj1.region
    val cityCode = obj1.city_code
    val cityName = obj1.city
    val finalZc = obj1.zone_code
    val aoi = obj1.aoi + obj2.aoi
    val aoiWd = obj1.aoi_wrong + obj2.aoi_wrong
    AoiProObj(stat_date, region, cityCode, cityName,
      finalZc, aoi, aoiWd)
  }

  def statIndex(totalRdd: RDD[JSONObject], incDay: String): (RDD[AoiProObj], RDD[AoiProObj]) = {
    val aoiWdRddZoneCode = totalRdd.map(obj => {
      val cityName = obj.getString("db_city")
      val cityCode = obj.getString("city_code")
      val region = obj.getString("db_region")
      val finalZc = obj.getString("finalZc")
      var aoi = 0
      if (!"cmsAoiCodeEmpty".equals(obj.getString("tag"))) {
        aoi = 1
      }
      var aoiWd = 0
      if ("wd".equals(obj.getString("tag"))) {
        aoiWd = 1
      }
      val aoiObj = AoiProObj(incDay, region, cityCode, cityName,
        finalZc, aoi, aoiWd)
      (incDay + "_" + cityCode + "_" + cityName + "_" + finalZc, aoiObj)
    }).reduceByKey((obj1, obj2) => {
      mergeAoiIndex(obj1, obj2)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val aoiWdRddCityName = aoiWdRddZoneCode.map(obj => {
      val aoiObj = obj._2.copy(zone_code = "ALL")
      (aoiObj.stat_date + "_" + aoiObj.city_code + "_" + aoiObj.city, aoiObj)
    }).reduceByKey((obj1, obj2) => {
      mergeAoiIndex(obj1, obj2)
    })
    (aoiWdRddZoneCode.values, aoiWdRddCityName.values)
  }

  def checkAoiCodeDetail(obj: JSONObject): Unit = {
    val cmsAoiCode = JSONUtil.getJsonVal(obj, "cmsAoiCode", "")
    val gisAoiSrc = JSONUtil.getJsonVal(obj, "gisAoiSrc", "")
    if (!StringUtil.nonEmpty(cmsAoiCode)) {
      if ("norm".equals(gisAoiSrc) || "chkn".equals(gisAoiSrc)) {
        obj.put("tag", "cmsAoiCodeEmpty")
        obj.put("wdTag", "cmsAoiCodeEmpty")
      }
      return
    }
    val allAoiList = ";" + JSONUtil.getJsonVal(obj, "allAoiList", "") + ";"
    obj.put("allAoiList", allAoiList)
    val xyAoiCode = JSONUtil.getJsonVal(obj, "xyBodyStr.xyAoiCode", "")
    obj.put("xyAoiCode", xyAoiCode)
    val tsAoiCode = JSONUtil.getJsonVal(obj, "xyBodyStr.tsXyData.xyAoiCode", "")
    obj.put("tsAoiCode", tsAoiCode)
    val mapAAoiCOde = JSONUtil.getJsonVal(obj, "xyBodyStr.mapAXyData.xyAoiCode", "")
    obj.put("mapAAoiCode", mapAAoiCOde)
    if (allAoiList.contains(";" + cmsAoiCode + ";")) {
      obj.put("tag", "right")
      obj.put("wdTag", "allAoilist")
      return
    }
    if (cmsAoiCode.equals(xyAoiCode)) {
      obj.put("tag", "right")
      obj.put("wdTag", "xyAoiCode")
      return
    }
    if (cmsAoiCode.equals(tsAoiCode)
      && cmsAoiCode.equals(mapAAoiCOde)) {
      obj.put("tag", "right")
      obj.put("wdTag", "mapAoiCode")
      return
    }
  }

  def checkAoiCode(totalRdd: RDD[JSONObject]): RDD[JSONObject] = {
    totalRdd.map(obj => {
      checkAoiCodeDetail(obj)
      obj
    })
  }

  def saveToHive(spark: SparkSession, checkRdd: RDD[JSONObject], incDay: String): Unit = {
    val num = (checkRdd.count() / 500000).toInt
    val rows = checkRdd.repartition(num).map(obj => {
      try {
        val sb = new StringBuilder()
        val tag = obj.getString("tag")
        val waybillno = obj.getString("waybillno")
        val addr = obj.getString("addr").replaceAll("[\\r\\n\\t]", "")
        val groupId = obj.getString("groupId")
        val gisAoiSrc = obj.getString("gisAoiSrc")
        val reqCityCode = obj.getString("reqCityCode")
        val allAoiList = obj.getString("allAoiList")
        val finalZc = obj.getString("finalZc")
        val normlizeAddr = JSONUtil.getJsonVal(obj, "normlizeAddr", "").replaceAll("[\\r\\n\\t]", "")
        val normlizeAddrMd5 = JSONUtil.getJsonVal(obj, "normlizeAddrMd5", "")
        var normlizeBodyStr = ""
        if (obj.getJSONObject("normlizeBody") != null) normlizeBodyStr = obj.getJSONObject("normlizeBody").toJSONString.replaceAll("[\\r\\n\\t]", "")
        val wdTag = JSONUtil.getJsonVal(obj, "wdTag", "")
        val cmsAoiCode = JSONUtil.getJsonVal(obj, "cmsAoiCode", "")
        val cmsAoiId = JSONUtil.getJsonVal(obj, "cmsAoiId", "")
        val cmsFlag = JSONUtil.getJsonVal(obj, "cmsFlag", "")
        val xyAoiCode = JSONUtil.getJsonVal(obj, "xyAoiCode", "")
        val mapAAoiCode = JSONUtil.getJsonVal(obj, "mapAAoiCode", "")
        val tsAoiCode = JSONUtil.getJsonVal(obj, "tsAoiCode", "")
        val gisAoiCode = obj.getString("gisAoiCode")
        val ksAoiCode = obj.getString("ksAoiCode")
        val finalAoiCode = obj.getString("finalAoiCode")

        sb.append(tag).append("\t")
        sb.append(waybillno).append("\t")
        sb.append(addr).append("\t")
        sb.append(groupId).append("\t")
        sb.append(gisAoiSrc).append("\t")
        sb.append(reqCityCode).append("\t")
        sb.append(allAoiList).append("\t")
        sb.append(finalZc).append("\t")
        sb.append(normlizeAddr).append("\t")
        sb.append(normlizeAddrMd5).append("\t")
        sb.append(normlizeBodyStr).append("\t")
        sb.append(wdTag).append("\t")
        sb.append(cmsAoiCode).append("\t")
        sb.append(cmsAoiId).append("\t")
        sb.append(cmsFlag).append("\t")
        sb.append(xyAoiCode).append("\t")
        sb.append(tsAoiCode).append("\t")
        sb.append(mapAAoiCode).append("\t")
        sb.append(gisAoiCode).append("\t")
        sb.append(ksAoiCode).append("\t")
        sb.append(finalAoiCode)
        sb.toString()
      } catch {
        case e: Exception => logger.error(obj, e)
          null
      }
    }).filter(obj => obj != null)
    val finalTable = "aoi_real_wd_pro"
    val dropSql = String.format("alter table dm_gis.%s drop if exists partition(inc_day = '%s')", finalTable, incDay)
    spark.sql(dropSql)
    ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R /user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, incDay))
    rows.saveAsTextFile(String.format("/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, incDay))
    val addSql = String.format("alter table dm_gis.%s add if not exists partition(inc_day = '%s')", finalTable, incDay)
    spark.sql(addSql)
  }

  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("开始统计")
    logger.error("获取数据地区数据记录")
    val (normData, wdData) = fetchOriginWd(spark, incDay)
    logger.error("装载配置文件")
    val prop = FileUtil.getFileProperties("conf/oms_pai/aoi_real_wd_pro.properties")
    val cmsTableMap = parseCmsTableMap(prop)
    logger.error("调用规范化地址")
    val (normlizeOkData, normlizeErrData) = normlizeData(spark.sparkContext, wdData, prop)
    logger.error("检查cms数据")
    val (matchDataRdd, noMatchRdd) = checkChknData(spark.sparkContext, normlizeOkData, prop, cmsTableMap)
    logger.error("补充aoiCode")
    val fillCmsAoiCodeRdd = fillCmsAoiCode(spark, matchDataRdd)
    logger.error("合并数据")
    val totalRdd = normlizeErrData.union(noMatchRdd).union(fillCmsAoiCodeRdd)
    logger.error("检查逻辑")
    val checkRdd = checkAoiCode(totalRdd).union(normData)
    logger.error("统计指标")
    val (aoiWdRddZoneCode, aoiWdRddCityName) = statIndex(checkRdd, incDay)
    logger.error("存储流程信息")
    saveToHive(spark, checkRdd, incDay)
    logger.error("存储指标")
    updateAoiRealWdIndex(aoiWdRddCityName, comUtil, Array(incDay))
    updateAoiRealWdIndexZc(aoiWdRddZoneCode, comUtil, Array(incDay))
    logger.error("end")
  }

  def start(beginDate: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    for (i <- 0 until days) {
      val incDay = Util.getDay(beginDate, i, "")
      logger.error("incDay:" + incDay)
      startSta(spark, incDay)
    }
    logger.error("统计完毕")
  }

  def main(args: Array[String]): Unit = {
    var beginDate: String = Util.dateDelta(-2, "")
    var days = 1
    if (args.length == 2) {
      beginDate = args(0)
      days = args(1).toInt
    }
    logger.error("begin:" + beginDate + ",days:" + days)
    start(beginDate, days)
  }

  def updateAoiRealWdIndex(aoiWdIndexRdd: RDD[AoiProObj],
                           comUtil: ComUtil, dateArray: Array[String]): Unit = {

    val DLV_AOI_REAL_FD = "DLV_AOI_REAL_FD"
    logger.error(">>>AOI真实错分指标表名：" + DLV_AOI_REAL_FD)
    val conn = getRdsConn(comUtil)
    val md5Instance = MD5Util.getMD5Instance
    // 插入有效识别数据
    val updateRecSql =
      s"""update $DLV_AOI_REAL_FD set AOI_PRO=%s, AOI_WRONG_PRO=%s where ID='%s' """.stripMargin
    logger.error(">>>updateRecSql:" + updateRecSql)
    for (incDay <- dateArray) {
      logger.error(">>>日期：" + incDay)
      val tmpRdd = aoiWdIndexRdd.filter(obj => obj.stat_date.equals(incDay))
      if (tmpRdd.count() != 0) {
        logger.error(">>>清空当天aoi生产指标数据")
        val delSql = s"update $DLV_AOI_REAL_FD set AOI_PRO=0, AOI_WRONG_PRO=0 where STAT_DATE='" + incDay + "'"
        DbUtils.executeSql(conn, delSql)
        tmpRdd.collect().foreach(o => {
          //计算md5值
          val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.region, o.city_code, o.city).mkString("_"))
          val fdParams = Array(o.aoi, o.aoi_wrong, id)
          val updateRecSqlStr = String.format(updateRecSql, o.aoi.toString, o.aoi_wrong.toString, id)
          DbUtils.executeSql(conn, updateRecSqlStr)
        })
      }
    }
  }

  def updateAoiRealWdIndexZc(aoiWdIndexRdd: RDD[AoiProObj],
                             comUtil: ComUtil, dateArray: Array[String]): Unit = {

    val DLV_AOI_REAL_FD_ZC = "DLV_AOI_REAL_FD_ZC"
    logger.error(">>>AOI真实错分网点维度指标表名：" + DLV_AOI_REAL_FD_ZC)
    val conn = getRdsConn(comUtil)
    val md5Instance = MD5Util.getMD5Instance
    val updateRecSql =
      s"""update $DLV_AOI_REAL_FD_ZC set AOI_PRO=%s, AOI_WRONG_PRO=%s where ID='%s' """.stripMargin
    logger.error(">>>updateRecSql:" + updateRecSql)
    for (incDay <- dateArray) {
      logger.error(">>>日期：" + incDay)
      val tmpRdd = aoiWdIndexRdd.filter(obj => obj.stat_date.equals(incDay))
      if (tmpRdd.count() != 0) {
        logger.error(">>>清空当天aoi生产指标数据")
        val delSql = s"update $DLV_AOI_REAL_FD_ZC set AOI_PRO=0, AOI_WRONG_PRO=0 where STAT_DATE='" + incDay + "'"
        DbUtils.executeSql(conn, delSql)
        tmpRdd.collect().foreach(o => {
          //计算md5值
          val id = MD5Util.getMD5(md5Instance, Array(o.stat_date, o.region, o.city_code, o.city, o.zone_code).mkString("_"))
          val updateRecSqlStr = String.format(updateRecSql, o.aoi.toString, o.aoi_wrong.toString, id)
          DbUtils.executeSql(conn, updateRecSqlStr)
        }
        )
      }
    }
  }
}
