package com.sf.gis.scala.oms_shou.main

import java.text.DecimalFormat
import java.util
import java.util.Properties

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializerFeature
import com.sf.gis.com.sf.gis.scala.oms_shou.constant.FixedConstant
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_shou.constant.VariableConstant
import com.sf.gis.scala.oms_shou.db.{AosManager, ManagerFactory}
import com.sf.gis.scala.oms_shou.pojo.{ErrCallData, OrderData}
import com.sf.gis.scala.utils.{ConfigurationUtil, StringUtil}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{Row, RowFactory, SparkSession}
import org.slf4j.{Logger, LoggerFactory}

import scala.util.Random

/**
 * Created by 01368078 on 2019/1/4.
 */
class LogConservator extends Serializable {
  @transient val logger: Logger = LoggerFactory.getLogger(classOf[LogConservator])
  val props: Properties = ConfigurationUtil.loadProperties(VariableConstant.CONF, FixedConstant.CHARSET)

  def save(spark: SparkSession, orderRdd: RDD[OrderData],
           incDay: String): Unit = {

    val count = 1000
    val rows = orderRdd.map(obj => {
      var syncTcs = ""
      var asyncTcs = ""
      if (obj.getSyncTcs != null) syncTcs = JSON.toJSONString(obj.getSyncTcs, SerializerFeature.PrettyFormat)
      if (obj.getAsyncTcs != null) asyncTcs = JSON.toJSONString(obj.getAsyncTcs, SerializerFeature.PrettyFormat)
      val chkOmsAoi = JSONUtil.getJsonVal(obj.getChkOmsRebody, "orderFrom.aoiCode", "")
      var syncReqBody = ""
      if (obj.getSyncReqBody != null) {
        syncReqBody = obj.getSyncReqBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var syncReBody = ""
      if (obj.getSyncReBody != null) {
        syncReBody = obj.getSyncReBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var asyncReqBody = ""
      if (obj.getAsyncReqBody != null) {
        asyncReqBody = obj.getAsyncReqBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var asyncReBody = ""
      if (obj.getAsyncReBody != null) {
        asyncReBody = obj.getAsyncReBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }

      var arssReqBody = ""
      if (obj.getArssReqBody != null) {
        arssReqBody = obj.getArssReqBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var arssReBody = ""
      if (obj.getArssReBody != null) {
        arssReBody = obj.getArssReBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }

      //运单号
      var waybillNo = JSONUtil.getJsonVal(obj.getSyncReqBody, "orderInfo.orderFromToList.orderTo.waybillNo", "")
      if (waybillNo.isEmpty) {
        waybillNo = JSONUtil.getJsonVal(obj.getAsyncReqBody, "orderInfo.orderFromToList.orderTo.waybillNo", "")
      }
      var requestBuildingBody = ""
      if (obj.getRequestBuildingBody != null) {
        requestBuildingBody = obj.getRequestBuildingBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }
      var responseBuildingBody = ""
      if (obj.getResponseBuildingBody != null) {
        responseBuildingBody = obj.getResponseBuildingBody.toJSONString.replaceAll("[\\r\\n\\t]", "")
      }

      val deptCode = obj.getDeptCode()
      val ksDeptCode = JSONUtil.getJsonVal(obj.getChkKsReBody, "result.dept", "")
      if (StringUtil.isBlank(deptCode) && !StringUtil.isBlank(ksDeptCode)) {
        obj.setDeptCode(ksDeptCode)
        val ksSrc = JSONUtil.getJsonVal(obj.getChkKsReBody, "result.zcTag", "")
        obj.setSrc(ksSrc)
      }
      val ksAoiCode = JSONUtil.getJsonVal(obj.getChkKsReBody, "result.aoi", "")
      val ksAoiSrc = JSONUtil.getJsonVal(obj.getChkKsReBody, "result.aoiTag", "")

      var aoiSrc = ""
      if (!StringUtil.isBlank(obj.getArssAoiCode)) {
        aoiSrc = "chke_cur"
      } else if (!StringUtil.isBlank(ksAoiCode)) {
        aoiSrc = ksAoiSrc
      } else if (!StringUtil.isBlank(obj.getAsyncAoiCode)) {
        aoiSrc = obj.getAsyncTcs.getAtAoiSrc
      } else if (!StringUtil.isBlank(obj.getSyncAoiCode)) {
        aoiSrc = obj.getSyncTcs.getAtAoiSrc
      }
      val finalAoiid = obj.getAoiId
      val arr = Array[String](obj.isSyncReqFlag.toString, obj.isSyncReFlag.toString, obj.isAsyncReqFlag.toString,
        obj.isAsyncReFlag.toString, obj.isRdsArssReqFlag.toString, obj.isArssReqFlag.toString, obj.isArssReFlag.toString,
        obj.isErrCallFlag.toString, obj.getSyncReqDateTime, obj.getSyncReDateTime, obj.getSyncReStatus,
        obj.getSyncReqId, obj.getSyncNodeId, obj.getAsyncReqDateTime, obj.getAsyncReDateTime, obj.getAsyncReStatus, obj.getAsyncReqId,
        obj.getAsyncNodeId, obj.getRdsArssReqDateTime, obj.getArssReqDataTime, obj.getArssReqNodeId, obj.getArssReDataTime, obj.getArssReNodeId,
        obj.getAk, obj.getUrl, obj.getRemoteIp, obj.getSno, obj.getSysCode, obj.getOrderType, obj.getSysSource, obj.getLimitTypeCode,
        obj.getPayType, obj.getBookingType, obj.getCargoTypeCode, obj.getExpressTypeCode, obj.getWeight, obj.getClientCode,
        obj.getOrderNo, obj.getSysOrderNo, obj.getCountryCode, obj.getProvince, obj.getCity, obj.getCityCode, obj.getCounty,
        obj.getAddress, obj.getCustomerAccount, obj.getCustomerId, obj.getContactsName, obj.getCompany, obj.getPhone, obj.getMobile,
        waybillNo, obj.getSyncSrc, obj.getSyncGroupId, obj.getSyncDeptCode, obj.getSyncTeamCode, obj.getAsyncSrc,
        obj.getAsyncGroupId, obj.getAsyncDeptCode, obj.getAsyncTeamCode, obj.getArssDeptCode, obj.getArssTeamCode, obj.getArssEmpCode,
        obj.getStatus, obj.getSrc, obj.getGroupId, obj.getDeptCode, obj.getTeamCode, obj.getErrCallProvince, obj.getErrCallCity,
        obj.getErrCallResno, obj.getErrCallAddrabb, obj.getErrCallCounty, obj.getErrCallTeamid, obj.getErrCallAddrSrc, obj.getErrCallAddrGroupid,
        obj.getErrCallAddrDept, obj.getErrCallAddrTeamCode, obj.getErrCallEmpid, obj.getErrCallEmptel, obj.getMatchSrc, obj.getMatchGroupId,
        obj.getMatchTeamCode, obj.getMatchDeptCode, obj.getSyncChkDeptSrc, obj.getSyncChkTcSrc, obj.getAsyncChkDeptSrc, obj.getAsyncChkTcSrc,
        obj.getMatchChkDeptSrc, obj.getMatchChkTcSrc, obj.getErrCallDept, obj.getSyncTc2GeoSrc, obj.getSyncTc2Gid,
        obj.getAsyncTc2GeoSrc, obj.getAsyncTc2Gid, obj.getMatchTc2GeoSrc, obj.getMatchTc2Gid,
        JSONUtil.convertJsonToStr(obj.getChkKsReqBody),
        JSONUtil.convertJsonToStr(obj.getChkKsReBody), JSONUtil.convertJsonToStr(obj.getChkOmsRebody)
        , JSONUtil.convertJsonToStr(obj.getPickupBody), obj.getIsNotUnderCall,
        obj.getSyncAoiCode, obj.getAsyncAoiCode, obj.getArssAoiCode, obj.getAoiCode, obj.getPickupType,
        syncTcs, asyncTcs, chkOmsAoi, syncReqBody, syncReBody,
        asyncReqBody, asyncReBody, requestBuildingBody, responseBuildingBody, aoiSrc, arssReqBody, arssReBody,
        finalAoiid
      )

      for (i <- arr.indices) {
        arr(i) = if (arr(i) != null) arr(i).replaceAll("[\\r\\n\\t]", "") else ""
      }

      var row: Row = null
      try {
        row = RowFactory.create(arr(0), arr(1), arr(2), arr(3), arr(4), arr(5), arr(6), arr(7), arr(8), arr(9), arr(10),
          arr(11), arr(12), arr(13), arr(14), arr(15), arr(16), arr(17), arr(18), arr(19), arr(20), arr(21), arr(22),
          arr(23), arr(24), arr(25), arr(26), arr(27), arr(28), arr(29), arr(30), arr(31), arr(32), arr(33), arr(34),
          arr(35), arr(36), arr(37), arr(38), arr(39), arr(40), arr(41), arr(42), arr(43), arr(44), arr(45), arr(46),
          arr(47), arr(48), arr(49), arr(50), arr(51), arr(52), arr(53), arr(54), arr(55), arr(56), arr(57), arr(58),
          arr(59), arr(60), arr(61), arr(62), arr(63), arr(64), arr(65), arr(66), arr(67), arr(68), arr(69), arr(70),
          arr(71), arr(72), arr(73), arr(74), arr(75), arr(76), arr(77), arr(78), arr(79), arr(80), arr(81), arr(82),
          arr(83), arr(84), arr(85), arr(86), arr(87), arr(88), arr(89), arr(90), arr(91), arr(92), arr(93), arr(94),
          arr(95), arr(96), arr(97), arr(98), arr(99), arr(100), arr(101), arr(102), arr(103), arr(104), arr(105), arr(106),
          arr(107), arr(108), arr(109), arr(110), arr(111), arr(112), arr(113), arr(114), arr(115), arr(116), arr(117), arr(118),
          arr(119))
      } catch {
        case e: Exception => logger.error("transfer " + JSON.toJSONString(obj, SerializerFeature.PrettyFormat) + " error", e)
      }
      row
    }).filter(_ != null).map(obj => {
      (Random.nextInt(count), obj)
    }).repartition(count).values
    val structFields = new util.ArrayList[StructField]()
    structFields.add(DataTypes.createStructField("syncReqFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReqFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("rdsArssReqFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReqFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallFlag", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReqDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReStatus", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReqId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncNodeId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReqDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReStatus", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReqId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncNodeId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("rdsArssReqDateTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReqDataTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReqNodeId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReDataTime", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReNodeId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("ak", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("url", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("remoteIp", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sno", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sysCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("orderType", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sysSource", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("limitTypeCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("payType", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bookingType", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("cargoTypeCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("expressTypeCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("weight", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("clientCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("orderNo", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("sysOrderNo", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("countryCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("province", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("city", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("cityCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("county", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("address", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("customerAccount", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("customerId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("contactsName", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("company", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("phone", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("mobile", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("waybillNo", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncGroupId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncDeptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncGroupId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncDeptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssDeptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssEmpCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("status", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("src", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("groupId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("deptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("teamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallProvince", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallCity", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallResno", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrabb", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallCounty", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallTeamid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrGroupid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrDept", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallAddrTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallEmpid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallEmptel", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchGroupId", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchTeamCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchDeptCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncChkDeptSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncChkTcSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncChkDeptSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncChkTcSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchChkDeptSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchChkTcSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("errCallDept", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncTc2GeoSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncTc2Gid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncTc2GeoSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncTc2Gid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchTc2GeoSrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("matchTc2Gid", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("chkKsReqBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("chkKsReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("chkOmsReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("pickUpBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("isNotUnderCall", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncAoiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncAoiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssAoiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("finalAoiCode", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("pickupType", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncTcs", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncTcs", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("chkOmsAoi", DataTypes.StringType, true))

    structFields.add(DataTypes.createStructField("syncReqBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("syncReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReqBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("asyncReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bid_req_body", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("bid_re_body", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("aoisrc", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReqBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("arssReBody", DataTypes.StringType, true))
    structFields.add(DataTypes.createStructField("finalAoiId", DataTypes.StringType, true))
    val structTypes = DataTypes.createStructType(structFields)
    val props = ConfigurationUtil.loadProperties(VariableConstant.CONF, FixedConstant.CHARSET)
    spark.sql(String.format("use %s", props.getProperty("hive.db.gis")))
    val df = spark.createDataFrame(rows, structTypes)
    val table = props.getProperty("hive.table.gis_rds_omsfrom")
    val tempView = "%s_temp_view".format(table)
    df.createOrReplaceTempView(tempView)
    spark.sql(String.format("insert overwrite table %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
  }

  def saveErrCallData(errCallRdd: RDD[ErrCallData]): Unit = {
    val errCallDataTable = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("mysql.table.err_call_data")
    val conn = ManagerFactory.createManager(classOf[AosManager]).getConn
    val stmt = conn.createStatement()
    errCallRdd.collect.foreach(obj => {
      val sqlBuilder = new StringBuilder
      sqlBuilder.append(
        s"""insert ignore into $errCallDataTable(`id`, `req_date`, `req_time`, `frequency`, `sysorderno`,
           |`province`, `city`, `county`, `citycode`, `address`, `match_src`, `src_detail`, `match_dept`,
           |`match_team`, `match_grouid`, `errcall_dept`, `errcall_team`, `errcall_addrabb`, `chk_dept`,
           |`chk_team`, `chk_empid`, `chk_modify_user`, `mining_dept`, `mining_team`, `err_call_date`,
           |`company`, `phone`, `mobile`, `aoi_id`,`current_state`,`pick_up_tc`,`resource_id`,`is_wrong_report`)
           | values ('${obj.getId}', '${obj.getReqDate}', '${obj.getReqTime}', ${obj.getFrequency}, '${obj.getSysOrderNo}',
           | '${obj.getProvince}', '${obj.getCity}', '${obj.getCounty}', '${obj.getCityCode}', '${obj.getAddress}',
           | '${obj.getMatchSrc}', '${obj.getSrcDetail}', '${obj.getMatchDept}', '${obj.getMatchTeam}', '${obj.getMatchGroupId}',
           | '${obj.getErrCallDept}', '${obj.getErrCallTeam}', '${obj.getErrCallAddrAbb}', '${obj.getChkDept}', '${obj.getChkTeam}',
           | '${obj.getChkEmpId}', '${obj.getChkModifyUser}', '${obj.getMiningDept}', '${obj.getMiningTeam}', '${obj.getErrCallDate}',
           | '${obj.getCompany}', '${obj.getPhone}', '${obj.getMobile}','${obj.getAoiId}','${obj.getCurrent_state}',
           | '${obj.getPick_up_tc}','${obj.getResource_id}','${obj.getIs_wrong_report}')
           | on duplicate key update id = id
           |""".stripMargin)

      appendUpdateStringSqlNotNull(sqlBuilder, "req_date", obj.getReqDate)
      appendUpdateStringSqlNotNull(sqlBuilder, "req_time", obj.getReqTime)
      appendUpdateStringSqlNotNull(sqlBuilder, "frequency", "" + obj.getFrequency)
      //      appendUpdateIntSql(sqlBuilder, "frequency", obj.getFrequency, 0)
      appendUpdateStringSqlNotNull(sqlBuilder, "sysorderno", obj.getSysOrderNo)
      appendUpdateStringSqlNotNull(sqlBuilder, "province", obj.getProvince)
      appendUpdateStringSqlNotNull(sqlBuilder, "city", obj.getCity)
      appendUpdateStringSqlNotNull(sqlBuilder, "county", obj.getCounty)
      appendUpdateStringSqlNotNull(sqlBuilder, "citycode", obj.getCityCode)
      appendUpdateStringSqlNotNull(sqlBuilder, "address", obj.getAddress)
      appendUpdateStringSqlNotNull(sqlBuilder, "match_src", obj.getMatchSrc)
      appendUpdateStringSqlNotNull(sqlBuilder, "src_detail", obj.getSrcDetail)
      appendUpdateStringSqlNotNull(sqlBuilder, "match_dept", obj.getMatchDept)
      appendUpdateStringSqlNotNull(sqlBuilder, "match_team", obj.getMatchTeam)
      appendUpdateStringSqlNotNull(sqlBuilder, "match_grouid", obj.getMatchGroupId)
      appendUpdateStringSqlNotNull(sqlBuilder, "errcall_dept", obj.getErrCallDept)
      appendUpdateStringSqlNotNull(sqlBuilder, "errcall_team", obj.getErrCallTeam)
      appendUpdateStringSqlNotNull(sqlBuilder, "errcall_addrabb", obj.getErrCallAddrAbb)
      appendUpdateStringSqlNotNull(sqlBuilder, "chk_dept", obj.getChkDept)
      appendUpdateStringSqlNotNull(sqlBuilder, "chk_team", obj.getChkTeam)
      appendUpdateStringSqlNotNull(sqlBuilder, "chk_empid", obj.getChkEmpId)
      appendUpdateStringSqlNotNull(sqlBuilder, "chk_modify_user", obj.getChkModifyUser)
      appendUpdateStringSqlNotNull(sqlBuilder, "mining_dept", obj.getMiningDept)
      appendUpdateStringSqlNotNull(sqlBuilder, "mining_team", obj.getMiningTeam)
      appendUpdateStringSqlNotNull(sqlBuilder, "err_call_date", obj.getErrCallDate)
      appendUpdateStringSqlNotNull(sqlBuilder, "company", obj.getCompany)
      appendUpdateStringSqlNotNull(sqlBuilder, "phone", obj.getPhone)
      appendUpdateStringSqlNotNull(sqlBuilder, "mobile", obj.getMobile)
      appendUpdateStringSqlNotNull(sqlBuilder, "aoi_id", obj.getAoiId)
      appendUpdateStringSqlNotNull(sqlBuilder, "current_state", obj.getCurrent_state)
      appendUpdateStringSqlNotNull(sqlBuilder, "resource_id", obj.getResource_id)
      appendUpdateStringSqlNotNull(sqlBuilder, "pick_up_tc", obj.getPick_up_tc)
      appendUpdateStringSqlNotNull(sqlBuilder, "is_wrong_report", obj.getIs_wrong_report)
      val sql = sqlBuilder.toString()
      try {
        stmt.execute(sql)
      } catch {
        case e: Exception =>
          logger.error(sql, e)
          logger.error(JSON.toJSONString(obj, SerializerFeature.PrettyFormat))
          e.printStackTrace()
      }
    })
    conn.close()
  }

  def appendUpdateStringSql(builder: StringBuilder, col: String, v: String): Unit = {
    if (v != null && !"".equals(v))
      builder.append(", ").append(col).append(" = '").append(v).append("'")
  }

  /**
   * null转为空
   *
   * @param builder
   * @param col
   * @param v
   */
  def appendUpdateStringSqlNotNull(builder: StringBuilder, col: String, v: String): Unit = {

    if (v != null)
      builder.append(", ").append(col).append(" = '").append(v).append("'")
    else
      builder.append(", ").append(col).append(" = '").append("").append("'")
  }

  def appendUpdateIntSql(builder: StringBuilder, col: String, v: Int, errV: Int): Unit = {
    if (v != errV)
      builder.append(", ").append(col).append(" = ").append(v)
  }

  //  /**
  //   * rds收件下call明细数据入hbase库
  //   *
  //   * @param orderDataRdd : 数据rdd
  //   * @param incDay       : 日期
  //   */
  //  def saveToHbase(orderDataRdd: RDD[(JSONObject, OrderData)], incDay: String): Unit = {
  //    try {
  //
  //      //转换rdd，设置put[key,value]得到最终的要存入的结果集
  //      val inputRdd = orderDataRdd.map(obj => {
  //        val json = obj._1
  //        val orderData = obj._2
  //        json.put("errcallflag", orderData.isErrCallFlag)
  //        json.put("syncreqdatetime", orderData.getSyncReqDateTime)
  //        json.put("citycode", orderData.getCityCode)
  //        json.put("address", orderData.getAddress)
  //        json.put("phone", orderData.getPhone)
  //        json.put("mobile", orderData.getMobile)
  //        json.put("arssdeptcode", orderData.getArssDeptCode)
  //        json.put("arssteamcode", orderData.getArssTeamCode)
  //        json.put("arssempcode", orderData.getArssEmpCode)
  //        json.put("errcalladdrabb", orderData.getErrCallAddrabb)
  //        json.put("errcallteamid", orderData.getErrCallTeamid)
  //        json.put("errcallempid", orderData.getErrCallEmpid)
  //        json.put("matchsrc", orderData.getMatchSrc)
  //        json.put("matchgrouid", orderData.getMatchGroupId)
  //        json.put("matchdeptcode", orderData.getMatchDeptCode)
  //        json.put("matchteamcode", orderData.getMatchTeamCode)
  //        json.put("pickUpBody", orderData.getPickupBody)
  //        json.put("isNotUnderCall", orderData.getIsNotUnderCall)
  //        val orderNo: String = json.getString(VariableConstant.SYS_ORDERNO_KEY)
  //        (orderNo, json)
  //      }).filter(obj => {
  //        obj._1 != null && (obj._2.containsKey(VariableConstant.SYNC_REQ_BODY_KEY) || obj._2.containsKey(VariableConstant.ASYNC_REQ_BODY_KEY))
  //      })
  //
  //      //      logger.error(">>>"+incDay+"号收件下call数据待入hbase库量："+inputRdd.count()+",数据入库中...")
  //      //      inputRdd.take(1).foreach(obj => {println(obj)})
  //      inputRdd.repartition(50).foreachPartition(rdd => {
  //        val table = getTable(props.getProperty("hbase.gis.oms.table"))
  //        rdd.foreach(obj => {
  //          val orderNo = obj._1
  //          val jsonObj = obj._2
  //          val key = getKeyByStr(orderNo)
  //          val put = new Put(Bytes.toBytes(key))
  //          put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("value"), Bytes.toBytes(jsonObj.toString))
  //          table.put(put)
  //        })
  //        table.flushCommits()
  //        table.close()
  //      })
  //      logger.error(">>>" + incDay + "号收件下call解析数据入hbase结束。")
  //    } catch {
  //      case e: Exception => logger.error(">>>" + incDay + "号数据入hbase失败," + e)
  //    }
  //  }

  //  def getTable(tableName: String): HTable = {
  //    val hbaseConf = HBaseConfiguration.create()
  //    //设置写入的表
  //    hbaseConf.set("zookeeper.znode.parent", props.getProperty("zookeeper.znode.parent"))
  //    hbaseConf.set("hbase.zookeeper.quorum", props.getProperty("hbase.zookeeper.quorum"))
  //    hbaseConf.set("hbase.zookeeper.property.clientPort", props.getProperty("hbase.zookeeper.property.clientPort"))
  //    //noinspection ScalaDeprecation
  //    val table = new HTable(hbaseConf, TableName.valueOf(tableName))
  //    table.setAutoFlush(false, false)
  ////    //    table.setWriteBufferSize(1*1024)
  //    table.setWriteBufferSize(512)
  //    table
  //  }

  /**
   * 根据运单号计算key
   *
   * @param waybillNo : 运单号
   * @return
   */
  def getKeyByStr(waybillNo: String): String = {
    var salt = (waybillNo.hashCode() % 30).toString.replace("-", "")
    val df = new DecimalFormat("00")
    if (salt.length == 1) {
      //个位数前面需要补0
      salt = df.format(Integer.parseInt(salt))
    }
    val key = salt + "_" + waybillNo
    key
  }


}
