package com.sf.gis.scala.oms_pai

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2024-01-24 11:15
 * @TaskId:
 * @TaskName:
 * @Description:临时处理的任务，过期下线
 */
object AoiSdkCompare {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def queryLog(sparkSession: SparkSession, incday: String) = {
    val sql = s"select " +
      "get_json_object(get_json_object(log,'$.message'),'$.chkDisLogMsg'),get_json_object(log,'$.createTime') " +
      s"from  dm_gis.chk_pai_log_flink where inc_day ='${incday}' " +
      s"and log like '%AoiAreaGroup-SDK%' and (log like '%021%' or log like '%7311%' or log like '%7313%'  or log like '%755%' or log like '%757%' ) "

    logger.error(sql)
    val dataRdd = sparkSession.sql(sql).rdd.map(obj=>{
      val createTime  = obj.getString(1)
      val log = obj.getString(0)
      val reqIdArray = log.split("reqId:")
      val reqIdItemArray = reqIdArray(1).split(",区域组调用SDK对比日志:")
      val reqId = reqIdItemArray(0)
      val resOldArray = reqIdItemArray(1).split("res-old:")
      val resNewArarray = resOldArray(1).split(",res-new:")

      var resOldJson:JSONObject = null
      var resNewJson:JSONObject = null
      if(resNewArarray.isEmpty) {
        resOldJson = new JSONObject()
        resNewJson = new JSONObject()
      } else if(resNewArarray.length==1){
        if(resNewArarray(0).isEmpty){
          resOldJson = new JSONObject()
        }else{
          resOldJson = JSON.parseObject(resNewArarray(0))
        }
        resNewJson = new JSONObject()
      }
      else {
        if(resNewArarray(0).isEmpty){
          resOldJson = new JSONObject()
        }else{
          resOldJson = JSON.parseObject(resNewArarray(0))
        }
        if(resNewArarray(1).isEmpty){
          resNewJson = new JSONObject()
        }else{
          resNewJson = JSON.parseObject(resNewArarray(1))
        }
      }

      (reqId,resOldJson,resNewJson,createTime)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("数量:"+dataRdd.count())

    dataRdd.filter(obj=>{
      obj._2 == null || obj._3==null
    }).take(10).foreach(obj=>{
      logger.error(obj.toString())
    })

    dataRdd.take(2).foreach(obj=>{
      logger.error(obj.toString())
    })
    dataRdd
  }

  def saveData(sparkSession: SparkSession, dataRdd: RDD[(String, JSONObject, JSONObject,String)], incday: String): Unit = {
    import  sparkSession.implicits._
    dataRdd.map(obj=>{
      val reqId = obj._1
      val old = obj._2
      val newData = obj._3
      (reqId,JSONUtil.getJsonValSingle(old,"aoiCode",""),
        JSONUtil.getJsonValSingle(old,"areaCode",""),
        JSONUtil.getJsonValSingle(old,"areaGroup",""),
        JSONUtil.getJsonValSingle(old,"areaType",""),
        JSONUtil.getJsonValSingle(old,"type",""),
        JSONUtil.getJsonValSingle(old,"znoCode",""),
        JSONUtil.getJsonValSingle(newData,"aoiCode",""),
        JSONUtil.getJsonValSingle(newData,"areaCode",""),
        JSONUtil.getJsonValSingle(newData,"areaGroup",""),
        JSONUtil.getJsonValSingle(newData,"areaType",""),
        JSONUtil.getJsonValSingle(newData,"type",""),
        JSONUtil.getJsonValSingle(newData,"znoCode",""),
        obj._4
      )
    })
      .toDF("reqId","old_aoiCode","old_areaCode","old_areaGroup","old_areaType","old_type","old_znoCode",
      "new_aoiCode","new_areaCode","new_areaGroup","new_areaType","new_type","new_znoCode","createTime")
      .repartition(10).createOrReplaceTempView("tmpView")
    val sql = s"insert overwrite table tmp_dm_gis.aoi_area_compare_sdk_01374443 partition(inc_day='${incday}') " +
      s" select * from tmpView "
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def start(incday: String): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    val dataRdd = queryLog(sparkSession,incday)
    logger.error("解析原始字段")
    saveData(sparkSession,dataRdd,incday)
  }

  def main(args: Array[String]): Unit = {
    val incday = args(0)
    logger.error("incday:"+incday)
    start(incday)
    logger.error("结束")
  }
}
