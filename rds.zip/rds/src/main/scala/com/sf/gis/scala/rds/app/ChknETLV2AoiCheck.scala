package com.sf.gis.scala.rds.app

import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.rds.util.{HttpConnection, Util}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.control.Breaks._

/**
 * 新派件审补下线逻辑
 * 需求方：郭本婕（01394694）
 *
 * @author 韩笑（01417629）
 *         Created on Dec.12 2022
 *         任务信息：：388（新派件审补下线逻辑，每天21时执行，2021年1月1日--）
 */
//noinspection DuplicatedCode
object ChknETLV2AoiCheck {
  @transient lazy val logger: Logger = Logger.getLogger(ChknETLV2AoiCheck.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //val url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/updateAddrAoiCheck"


  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    /*val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")*/
    val parDay_1 = args(0) //t-1分区
    run(spark, parDay_1)
    spark.close()
  }


  def run(spark: SparkSession, parDay_1: String): Unit = {
    println(parDay_1)
    //获取需要调接口的数据
    val data = getData(spark, parDay_1)
    data.take(2).foreach(println(_))
    //调接口
    val aoiCheck = updateAddrAoiCheck(data)
    aoiCheck.take(2).foreach(println(_))
    //保存接口返回数据
    saveResult2Hive(spark, aoiCheck, parDay_1)
    aoiCheck.unpersist()
  }


  /**
   * @param spark
   * @param parDay_1
   * @return
   */
  def getData(spark: SparkSession, parDay_1: String): RDD[JSONObject] = {
    val sql =
      s"""
         |SELECT
         |   concat('[',concat_ws(',', collect_list(concat('"',group_id,'"'))),']') as group_id
         |	,citycode as city_code
         |  ,adcode_shenbu as adcode
         |FROM dm_gis.chkn_etl_v4
         |WHERE inc_day = '$parDay_1'
         |and aoi_check_tag = 'updateAddrAoiCheck'
         |group by citycode,adcode_shenbu
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: " + sql)
    val data = Util.getRowToJson(spark, sql, 100)
    logger.error(s">>>获取信息共 ${data.count()} 条s<<<")
    data
  }

  /**
   * @param data
   */
  def updateAddrAoiCheck(data: RDD[JSONObject]): RDD[(JSONObject, JSONObject)] = {
    val aoiCheck = data.map(obj => {
      val group_id = obj.getString("group_id")
      val city_code = obj.getString("city_code")
      val adcode = obj.getString("adcode")
      var json: JSONObject = null
      if (!StringUtils.isEmpty(group_id)) {
        val addresses = JSON.parseArray(group_id)
        if (addresses != null && addresses.size() > 0) {
          json = updateAddrAoiCheck(city_code, addresses, adcode)
        }
      }
      (obj, json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取数据共 ${aoiCheck.count()} 条s<<<")
    data.unpersist()
    aoiCheck
  }

  def updateAddrAoiCheck(cityCode: String, addresses: JSONArray, adcode: String): JSONObject = {
    var jsonObject: JSONObject = null
    //val url = "http://gisasscmsbgintface-gis-ass-cms.dcn2.k8s.sfcloud.local:1080/cms/api/address/updateAddrAoiCheck"
    //val url = "http://gis-cms-bg.sit.sf-express.com/cms/api/address/updateAddrAoiCheck"
    //val url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/updateAddrAoiCheck"
    val url = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiCheck"
    val json = new JSONObject()
    json.put("cityCode", cityCode)
    json.put("aoiCheckTag", adcode)
    json.put("addressIds", addresses)
    breakable(
      for (i <- 0.until(5)) {
        try {
          jsonObject = com.sf.gis.scala.utils.HttpClientUtil.getJsonByPostJson(url, json.toJSONString)
          //          logger.error(">>>访问updateAddrAoiCheck：url" + i + "=" + url + ", json="+json + ", result="+jsonObject)
          Thread.sleep(100)
          if (jsonObject != null) {
            val code = jsonObject.getString("code")
            if ("200".equalsIgnoreCase(code)) break
            else Thread.sleep(100)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => logger.error(">>>访问updateAddrAoiCheck：url" + i + "=" + url + ", json=" + json + ", result=" + jsonObject)
        }
      }
    )
    jsonObject
  }


  /**
   * 写入Hive表
   *
   * @param spark
   * @param aoiCheck
   */
  def saveResult2Hive(spark: SparkSession, aoiCheck: RDD[(JSONObject, JSONObject)], parDay_1: String): Unit = {
    val descDBName = "default"
    val descTableName = "update_addr_aoi_check_res"
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION (inc_day = '$parDay_1')
         |SELECT
         |	 group_id
         |	,city_code
         |	,adcode
         |	,response
         |FROM update_addr_aoi_check_res_tmp
         |""".stripMargin
    try {
      val schemaString = "group_id,city_code,adcode,response"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
      )
      val schema = StructType(fields)
      val rdd = aoiCheck.map(obj => {
        val row = obj._1
        val json = obj._2
        val sb = new StringBuilder()
        sb.append(row.getString("group_id")).append("\t\t\t")
        sb.append(row.getString("city_code")).append("\t\t\t")
        sb.append(row.getString("adcode")).append("\t\t\t")
        sb.append(json.toJSONString).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3)))
      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.createOrReplaceTempView("update_addr_aoi_check_res_tmp")
      df.show(5)
      //插入数据
      logger.error(">>>>>>>>>>入hive库开始")
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }


}
