package com.sf.gis.scala.oms_pai

import java.sql.{Connection, DriverManager}
import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, DbUtil, StringUtils}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

/**
 * Created by 01375125 on 2019/12/3.
 *
 */
object SendReturnLogProMain {
  private val appName: String = this.getClass.getSimpleName.replace("$", "")
  private val logger = LoggerFactory.getLogger(appName)

  case class IndexObj(date: String, ak: String, province1: String, city1: String, req_cnt: Int, identical_true_cnt: Int, identical_false_cnt: Int, req_suc_count: Int, req_fail_cnt: Int, req_has_re: Int, req_no_re: Int, province1_cnt: Int, city1_cnt: Int, county1_cnt: Int, adcode1_cnt: Int, province2_cnt: Int, city2_cnt: Int, county2_cnt: Int, adcode2_cnt: Int, predict_money: Double)

  def main(args: Array[String]): Unit = {
    start(args)
  }

  def start(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val date = DateUtil.getYesterday
    if (args.length == 0) {
      //代码内部传入日期参数
      val date = DateUtil.getYesterday
      handleTask(spark, date)
    } else if (args.length == 1) {
      //传入参数，单天任务
      val date = args(0)
      handleTask(spark, date)
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      val startDate = args(0)
      val endDate = args(1)
      batchTask(spark, startDate, endDate)
    }
    spark.stop()
  }

  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      handleTask(spark, date)
    }
  }

  def handleTask(spark: SparkSession, date: String): Unit = {
    logger.error("-----------start-------开始" + date + "号的任务，appName=" + appName + "-------------")
    logger.error(">>>解析转寄退回日志")
    val logRdd = parseData(spark, date)
    val logCount = logRdd.count()
    if (logCount > 0) {
      logger.error(">>>关联日志")
      val joinRdd = joinLog(logRdd)
      logRdd.unpersist()

      logger.error(">>>统计指标")
      val indexRdd = statIndex(joinRdd, date)
      joinRdd.unpersist()

      logger.error(">>>指标入库")
      saveIndexToMysql(indexRdd, date)
      indexRdd.unpersist()
    }
    logger.error(">>>程序结束！")
  }

  def saveIndexToMysql(indexRdd: RDD[IndexObj], date: String): Unit = {
    val connection = getConnection
    val tableName = "RP_REDIRECT_STAT"
    val deleteSql = s"DELETE FROM $tableName WHERE DATE='$date'"
    println(">>>删除数据：" + deleteSql)
    DbUtil.execute(connection, deleteSql, null)
    val sql =
      s"""
         |INSERT INTO $tableName (AK,PROVINCE,CITY,DATE,REQ_CNT,IDENTICAL_TRUE_CNT,IDENTICAL_FALSE_CNT,REQ_SUC_COUNT,REQ_FAIL_CNT,REQ_HAS_RE,REQ_NO_RE,PROVINCE1_CNT,CITY1_CNT,COUNTY1_CNT,ADCODE1_CNT,PROVINCE2_CNT,CITY2_CNT,COUNTY2_CNT,ADCODE2_CNT,PREDICT_MONEY) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
       """.stripMargin
    val indexList = indexRdd.map(o => {
      Array(o.ak, o.province1, o.city1, o.date, o.req_cnt, o.identical_true_cnt, o.identical_false_cnt, o.req_suc_count, o.req_fail_cnt, o.req_has_re, o.req_no_re, o.province1_cnt, o.city1_cnt, o.county1_cnt, o.adcode1_cnt, o.province2_cnt, o.city2_cnt, o.county2_cnt, o.adcode2_cnt, o.predict_money)
    }).collect().toList
    DbUtil.batchListExecute(connection, sql, indexList)
    logger.error(">>>指标入库结束！")
    connection.close()
  }


  def getConnection: Connection = {
    Class.forName("com.mysql.jdbc.Driver").newInstance()
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8mb4&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"
    @transient val connection = DriverManager.getConnection(url, "gis_oms_pns", "gis_oms_pns")
    connection
  }


  /**
   * 统计指标
   *
   * @param inputRdd
   * @return
   */
  def statIndex(inputRdd: RDD[JSONObject], date: String): RDD[IndexObj] = {
    val rowIndexRdd = inputRdd.map(json => {
      val datatime = json.getString("dateTime")
      var createDateTime: String = null
      var ak = "-"
      var date = "-"
      var province1 = "-"
      var city1 = "-"
      var status = "-"
      var result_predeict_money = 0.0000

      var req_cnt, req_suc_count, req_fail_cnt, req_has_re, req_no_re, identical_true_cnt, identical_false_cnt, province1_cnt, city1_cnt, county1_cnt, adcode1_cnt, province2_cnt, city2_cnt, county2_cnt, adcode2_cnt = 0
      var predict_money = 0.0000
      req_cnt = 1 //总请求量
      val urlObj = json.getJSONObject("url")
      if (urlObj != null) {
        if (urlObj.getString("ak") != null) ak = urlObj.getString("ak")
        if (urlObj.getLong("createTime") != null) {
          val createLongTime = urlObj.getLong("createTime")
          createDateTime = longToTime(createLongTime)
          date = createDateTime.split(" ")(0).replaceAll("-", "")
        }
      }
      val dataObj = json.getJSONObject("data")
      if (dataObj != null) {
        if (dataObj.getString("status") != null) {
          status = dataObj.getString("status")
          if (status == "0") {
            req_suc_count = 1 //成功请求量
          } else if (status == "1") {
            req_fail_cnt = 1 //失败请求量
          }
        }
        val resultObj = dataObj.getJSONObject("result")
        if (resultObj != null) {
          val regionObj = resultObj.getJSONObject("region")
          if (regionObj != null) {
            province1 = regionObj.getString("province1")
            city1 = regionObj.getString("city1")
            val county1 = regionObj.getString("county1")
            val adcode1 = regionObj.getString("adcode1")
            val province2 = regionObj.getString("province2")
            val city2 = regionObj.getString("city2")
            val county2 = regionObj.getString("county2")
            val adcode2 = regionObj.getString("adcode2")

            if (province1 != null && province1 != "") province1_cnt = 1
            if (city1 != null && city1 != "") city1_cnt = 1
            if (county1 != null && county1 != "") county1_cnt = 1
            if (adcode1 != null && adcode1 != "") adcode1_cnt = 1
            if (province2 != null && province2 != "") province2_cnt = 1
            if (city2 != null && city2 != "") city2_cnt = 1
            if (county2 != null && county2 != "") county2_cnt = 1
            if (adcode2 != null && adcode2 != "") adcode2_cnt = 1
            if (county1 != null && county2 != null) {
              if (county1 == county2) predict_money += 1 * 2
              if (county1 != county2) predict_money += 1 * 10

            }

            val regionFields = List(province1, city1, county1, adcode1, province2, city2, county2, adcode2)
            var allNull = true //默认这几个字段全为空
            for (field <- regionFields if allNull) {
              if (field != null || field != "") allNull = false //有不为空的值了
            }
            if (allNull) {
              req_no_re = 1 //有结果返回量
            } else {
              req_has_re = 1 //无结果返回量，region中的字段全为空
            }

            val identical = regionObj.getBoolean("identical")
            if (identical != null) {
              if (identical) {
                identical_true_cnt = 1 //identical=true的计数
              } else {
                identical_false_cnt = 1 //identical=false的计数
              }
            }
          }
        }
      }
      result_predeict_money = getRate(predict_money, 10000).toDouble //预测金额

      ((date, ak, province1, city1), (req_cnt, identical_true_cnt, identical_false_cnt, req_suc_count, req_fail_cnt, req_has_re, req_no_re, province1_cnt, city1_cnt, county1_cnt, adcode1_cnt, province2_cnt, city2_cnt, county2_cnt, adcode2_cnt, result_predeict_money))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    rowIndexRdd.take(1).foreach(println)

    val indexRdd = rowIndexRdd.reduceByKey((t1, t2) => {
      (t1._1 + t2._1, t1._2 + t2._2, t1._3 + t2._3, t1._4 + t2._4, t1._5 + t2._5, t1._6 + t2._6, t1._7 + t2._7, t1._8 + t2._8, t1._9 + t2._9, t1._10 + t2._10, t1._11 + t2._11, t1._12 + t2._12, t1._13 + t2._13, t1._14 + t2._14, t1._15 + t2._15, t1._16 + t2._16)
    }).map(obj => {
      val k = obj._1
      val v = obj._2
      val predict_money = v._16.formatted("%4f").toDouble
      IndexObj(k._1, k._2, k._3, k._4, v._1, v._2, v._3, v._4, v._5, v._6, v._7, v._8, v._9, v._10, v._11, v._12, v._13, v._14, v._15, predict_money)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>统计后指标数：" + indexRdd.count())
    indexRdd.take(1).foreach(println)
    rowIndexRdd.unpersist()
    indexRdd
  }

  /**
   * 计算两数比例，保留4位小数
   *
   * @param dividend 被除数
   * @param divisor  除数
   * @return
   */
  def getRate(dividend: Double, divisor: Double): String = {
    var tcRate = "0.0000"
    val df = new DecimalFormat("0.0000")
    try {
      val value = dividend / divisor
      tcRate = value.formatted("%.4f")
    } catch {
      case e: Exception => logger.error(">>>计算比例异常：" + e)
    }
    tcRate
  }


  /**
   * 时间字符串转换成毫秒值
   * 样例：2018-10-24 09:54:47 236 ==> 1540346087236
   *
   * @param time
   * @return
   */
  def timeToLong(time: String): Long = {
    val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
    val longTime = sdf.parse(time).getTime
    longTime
  }

  /**
   * long值转换成时间
   *
   * @param time
   * @return
   */
  def longToTime(time: Long): String = {
    var createTime: String = null
    try {
      val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
      val createDate = new Date(time)
      createTime = sdf.format(createDate)
    } catch {
      case e: Exception => logger.error(">>>转换失败：" + e + ",time:" + time)
    }
    createTime
  }

  /**
   * 关联日志
   *
   * @param inputRdd
   * @return
   */
  def joinLog(inputRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val returnRdd = inputRdd.filter(json => {
      val dataType = json.getString("type")
      dataType != null && dataType == "url_e"
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>返回的数据量：" + returnRdd.count())
    returnRdd.take(1).foreach(println)
    returnRdd
  }

  //  hdfs://stream/user/mario/warehouse/ods_kafka_gis/
  def parseData(spark: SparkSession, date: String): RDD[JSONObject] = {
    val hdfsPath = s"hdfs://stream/user/mario/warehouse/ods_kafka_gis/bee_logs_gis_rp_collect/$date"
    println("hdfsPath=" + hdfsPath)
    val outputRdd = spark.sparkContext.textFile(hdfsPath).filter(row => {
      row.contains("redirect")
    }).map(log => {
      var json: JSONObject = null
      try {
        val line: String = StringUtils.pickGroup1Str(log, "system.log#(.*?)$")
        json = JSON.parseObject(line)
        val date = json.getString("dateTime").split(" ")(0).replaceAll("-", "")
        json.put("date", date)

      } catch {
        case e: Exception => logger.error(">>>提取和转json失败：" + e)
      }
      json
    }).filter(json => {
      if (json != null) {
        val logDate = json.getString("date")
        logDate != null && logDate == date
      } else {
        false
      }
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>解析后日志量：" + outputRdd.count())

    outputRdd.map(json => {
      val dataType = json.getString("type")
      (dataType, 1)
    }).filter(_._1 != null).reduceByKey(_ + _).sortBy(_._2, false).collect().foreach(println)
    outputRdd.take(1).foreach(println)
    outputRdd
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def parseDataOld(spark: SparkSession, date: String): RDD[JSONObject] = {
    val sql =
      s"""
         |SELECT logs from ods_kafka_gis.bee_logs_gis_rp_collect where inc_day = '$date' and logs like "%redirect%"
       """.stripMargin

    //    val sql2 =
    //      s"""
    //         |SELECT logs from dm_gis_ass_rds.ods_bee_logs_gis_rp_collect_bdp where inc_day in('20191213','20191214') and logs like "%redirect%"
    //       """.stripMargin

    println("sql=" + sql)
    val outputRdd = spark.sql(sql).rdd.map(row => {
      var line = ""
      try {
        line = row.getString(0)
      } catch {
        case e: Exception => logger.error(">>>异常：" + e)
      }
      line
    }).map(log => {
      var json: JSONObject = null
      try {
        val line: String = StringUtils.pickGroup1Str(log, "system.log#(.*?)$")
        json = JSON.parseObject(line)
        val date = json.getString("dateTime").split(" ")(0).replaceAll("-", "")
        json.put("date", date)

      } catch {
        case e: Exception => logger.error(">>>提取和转json失败：" + e)
      }
      json
    }).filter(json => {
      if (json != null) {
        val logDate = json.getString("date")
        logDate != null && logDate == date
      } else {
        false
      }
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>解析后日志量：" + outputRdd.count())

    outputRdd.map(json => {
      val dataType = json.getString("type")
      (dataType, 1)
    }).filter(_._1 != null).reduceByKey(_ + _).sortBy(_._2, false).collect().foreach(println)
    outputRdd.take(1).foreach(println)
    outputRdd
  }

}
