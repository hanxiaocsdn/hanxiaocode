package com.sf.gis.scala.oms_pai.index.oms_realtime;


public class OmsNoMatchData {
    private String waybillNo;
    private String no_req_body;
    private String no_gid_body;
    private String other_body;

    public OmsNoMatchData(String waybillNo, String no_req_body, String no_gid_body,String other_body) {
        this.waybillNo = waybillNo;
        this.no_req_body = no_req_body;
        this.no_gid_body = no_gid_body;
        this.other_body = other_body;
    }

    public String getOther_body() {
        return other_body;
    }

    public void setOther_body(String other_body) {
        this.other_body = other_body;
    }

    @SuppressWarnings("unused")
    public String getNo_req_body() {
        return no_req_body;
    }
    @SuppressWarnings("unused")
    public void setNo_req_body(String no_req_body) {
        this.no_req_body = no_req_body;
    }
    @SuppressWarnings("unused")
    public String getNo_gid_body() {
        return no_gid_body;
    }
    @SuppressWarnings("unused")
    public void setNo_gid_body(String no_gid_body) {
        this.no_gid_body = no_gid_body;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

}
