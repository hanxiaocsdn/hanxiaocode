package com.sf.gis.scala.oms_shou.main

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.oms_shou.db.{ManagerFactory, RdsManager}
import com.sf.gis.scala.oms_shou.pojo.{OmsPuTc, OrderData, _}
import org.apache.spark.rdd.RDD
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConversions._
import com.sf.gis.scala.oms_shou.constant.VariableConstant
import com.sf.gis.scala.oms_shou.main.Obj.{OmsPuAoiObj, OmsPuAoiZcObj, OmsPutcObj, OmsPutcZcObj, OmsPuzObj}
import com.sf.gis.scala.utils.{ConfigurationUtil, DbUtils}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions.lit
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01368078 on 2019/1/6.
  */
class LogStatistics extends Serializable {
  @transient val logger: Logger = LoggerFactory.getLogger(classOf[LogStatistics])


  def savePuBuzToHive(puBuzRdd: RDD[OmsPuBuz], spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val puTcConvertDf = puBuzRdd.map(obj => {
      OmsPuzObj(obj.getId, obj.getStatDate, obj.getProvince, obj.getRegion, obj.getCityCode, obj.getCity,
        obj.getReq, obj.getOrder, obj.getSync, obj.getSyncResp, obj.getSyncUnResp, obj.getSyncKafka, obj.getAsync,
        obj.getAsyncResp, obj.getAsyncUnResp, obj.getAsyncKafka, obj.getArssReceive, obj.getArssSend, obj.getKafkaReceive)
    }).toDF()
    puTcConvertDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.oms_put_buz_stat")
  }

  /**
    * 统计业务层指标
    */
  def statPuBuz(orderRdd: RDD[OrderData], incDay: String,
                adminAreaMap: util.Map[String, util.List[AdminArea]],
                spark:SparkSession): Unit = {
    try {
      val puBuzRdd = getPuBuz(orderRdd, adminAreaMap)
      savePuBuz(puBuzRdd)
      logger.error("存储pu tc到hive")
      savePuBuzToHive(puBuzRdd, spark, incDay)
      puBuzRdd.unpersist()
    } catch {
      case e: Exception => logger.error("stat puBuz Error", e)
    }
  }

  def getPuBuz(orderRdd: RDD[OrderData], adminAreaMap: util.Map[String, util.List[AdminArea]]): RDD[OmsPuBuz] = {
    logger.error(">>>stat puBuz.")
    val puBuzRdd = orderRdd.map(obj => {
      val omsPuBuz = new OmsPuBuz
      try {
        val adminArea = getAdminArea(obj, adminAreaMap)
        omsPuBuz.setStatDate(obj.getReqDate)
        omsPuBuz.setCityCode(adminArea.getCityCode)
        omsPuBuz.setRegion(adminArea.getRegion)
        omsPuBuz.setProvince(adminArea.getProvince)
        omsPuBuz.setCity(adminArea.getCity)
        if (obj.isSyncReqFlag) { //有同步请求
          omsPuBuz.setReq(omsPuBuz.getReq + 1)
          omsPuBuz.setOrder(1)
          omsPuBuz.setSync(1)
          omsPuBuz.setSyncResp(if (obj.isSyncReFlag) 1 else 0)
          omsPuBuz.setSyncUnResp(omsPuBuz.getSync - omsPuBuz.getSyncResp)
        }
        if (obj.isAsyncReqFlag) { //有异步请求
          omsPuBuz.setReq(omsPuBuz.getReq + 1)
          omsPuBuz.setOrder(1)
          omsPuBuz.setAsync(1)
          omsPuBuz.setAsyncResp(if (obj.isAsyncReFlag) 1 else 0)
          omsPuBuz.setAsyncUnResp(omsPuBuz.getAsync - omsPuBuz.getAsyncResp)
        }
        omsPuBuz.setAsyncKafka(if (obj.isRdsArssReqFlag) 1 else 0)
        omsPuBuz.setArssReceive(if (obj.isArssReqFlag) 1 else 0)
        omsPuBuz.setArssSend(if (obj.isArssReFlag) 1 else 0)

        omsPuBuz.setId(MD5Util.getMD5(String.format("%s%s%s", obj.getReqDate, omsPuBuz.getCityCode, omsPuBuz.getCity)))
      } catch {
        case e: Exception => logger.error("transform order to puz index error", e)
      }
      (String.format("%s_%s_%s", obj.getReqDate, omsPuBuz.getCityCode, omsPuBuz.getCity), omsPuBuz)
    }).filter(_ != null).reduceByKey((obj1, obj2) => {
      obj1.merge(obj2)
      obj1
    }).map(tp => {
      tp._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("业务数据量:" + puBuzRdd.count())
    //    puBuzRdd.collect().foreach(obj => {
    //      logger.error(s"pu buz>>>${JSON.toJSONString(obj, SerializerFeature.PrettyFormat)}")
    //    })
    puBuzRdd
  }

  def savePuBuz(puBuzRdd: RDD[OmsPuBuz]): Unit = {
    logger.error(">>>save puBuz.")
    val omsPuBuzTable = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("mysql.table.oms_pu_buz")
    try {
      val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
      val stmt = conn.prepareStatement(
        String.format("INSERT INTO %s(`ID`, `STAT_DATE`, `PROVINCE`, `REGION`, `CITY_CODE`, `CITY`, " +
          "`REQ`, `ORDER`, `SYNC`, `SYNC_RESP`, `SYNC_UNRESP`, `SYNC_KAFKA`, `ASYNC`, `ASYNC_RESP`, " +
          "`ASYNC_UNRESP`, `ASYNC_KAFKA`, `ARSS_RECEIVE`, `ARSS_SEND`, `KAFKA_RECEIVE`) " +
          "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
          "ON DUPLICATE KEY UPDATE `REQ` = ?, `ORDER` = ?, `SYNC` = ?, `SYNC_RESP` = ?, `SYNC_UNRESP` = ?, " +
          "`SYNC_KAFKA` = ?, `ASYNC` = ?, `ASYNC_RESP` = ?, `ASYNC_UNRESP` = ?, `ASYNC_KAFKA` = ?, " +
          "`ARSS_RECEIVE` = ?, `ARSS_SEND` = ?, `KAFKA_RECEIVE` = ?", omsPuBuzTable))
      puBuzRdd.collect().foreach(obj => {
        val params = Array(obj.getId, obj.getStatDate, obj.getProvince, obj.getRegion, obj.getCityCode, obj.getCity,
          obj.getReq, obj.getOrder, obj.getSync, obj.getSyncResp, obj.getSyncUnResp, obj.getSyncKafka, obj.getAsync,
          obj.getAsyncResp, obj.getAsyncUnResp, obj.getAsyncKafka, obj.getArssReceive, obj.getArssSend, obj.getKafkaReceive,
          obj.getReq, obj.getOrder, obj.getSync, obj.getSyncResp, obj.getSyncUnResp, obj.getSyncKafka, obj.getAsync,
          obj.getAsyncResp, obj.getAsyncUnResp, obj.getAsyncKafka, obj.getArssReceive, obj.getArssSend, obj.getKafkaReceive)
        for (i <- params.indices)
          stmt.setObject(i + 1, params(i))
        try {
          stmt.executeUpdate()
        } catch {
          case e: Exception => e.printStackTrace()
        }
      })
      conn.close()
    } catch {
      case e: Exception => logger.error("insert puBuz error", e)
    }
  }

  //  def statPuTc(orderRdd: RDD[OrderData], incDayList: util.ArrayList[String], adminAreaMap: util.Map[String, util.List[AdminArea]],
  //               spark: SparkSession, bidAoiidArrayBc: Broadcast[Array[String]], bidAoiidRejectArrayBc: Broadcast[Array[String]]): Unit = {
  //    val (puTcRdd, puAoiRdd, puAoiZcRdd, puTcRddZcRdd) = getPuTc(orderRdd, incDayList, adminAreaMap, bidAoiidArrayBc, bidAoiidRejectArrayBc)
  //    savePuTc(puTcRdd, spark, incDayList)
  //    puTcRdd.unpersist()
  //    savePuAoi(puAoiRdd, spark, incDayList)
  //    puAoiRdd.unpersist()
  //    savePuAoiZc(puAoiZcRdd, spark, incDayList)
  //    puAoiZcRdd.unpersist()
  //    savePuTcZc(puTcRddZcRdd, spark, incDayList)
  //    puTcRddZcRdd.unpersist()
  //  }

  def savePuTcToHive(puTcRdd: RDD[OmsPuTc], spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val puTcConvertDf = puTcRdd.map(obj => {
      OmsPutcObj(obj.getId, obj.getUnderCall, obj.getDataType, obj.getStatDate, obj.getProvince, obj.getRegion,
        obj.getCityCode, obj.getCity, obj.getSysSource,
        obj.getOrder, obj.getRcgTc, obj.getRcgNorm, obj.getRcgSch, obj.getRcgTc2, obj.getRcgChke, obj.getRcgChkn,
        obj.getRcgChknHisSch, obj.getRcgChknCgcs, obj.getRcgChknOmsKafka, obj.getRcgChknCms, obj.getRcgChknOther,
        obj.getRcgArss, obj.getFcTc, obj.getFcNorm, obj.getFcSch, obj.getFcTc2, obj.getFcChke, obj.getFcChkn,
        obj.getFcChknHisSch, obj.getFcChknCgcs, obj.getFcChknOmsKafka, obj.getFcChknCms, obj.getFcChknOther,
        obj.getFcArss, obj.getFcPush, obj.getFcTotal, obj.getOvertime, obj.getRcgDispatchNorm, obj.getRcgDispatchTc2,
        obj.getRcgDispatchChke, obj.getRcgDispatchChkn, obj.getRcgChknCgcsKdd, obj.getFcDispatchNorm, obj.getFcDispatchTc2,
        obj.getFcDispatchChke, obj.getFcDispatchChkn, obj.getFcChknCgcsKdd, obj.getRcgDispatchRoad, obj.getRcgDispatchPhone,
        obj.getFcDispatchRoad, obj.getFcDispatchPhone, obj.getRcgPhone, obj.getFcPhone,
        obj.getChkKsReq, obj.getChkKsRe, obj.getChkKsAoi, obj.getChkKsTc, obj.getChkKsGisTc
      )
    }).toDF()
    puTcConvertDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.oms_put_tc_stat")
  }

  def savePuTcZcToHive(puTcZcRdd: RDD[OmsPuTc], spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val puTcZcConvertDf = puTcZcRdd.map(obj => {
      OmsPutcZcObj(obj.getId, obj.getUnderCall, obj.getDataType, obj.getStatDate, obj.getProvince, obj.getRegion,
        obj.getCityCode, obj.getCity, obj.getZoneCode,
        obj.getOrder, obj.getRcgTc, obj.getRcgNorm, obj.getRcgSch, obj.getRcgTc2, obj.getRcgChke, obj.getRcgChkn,
        obj.getRcgChknHisSch, obj.getRcgChknCgcs, obj.getRcgChknOmsKafka, obj.getRcgChknCms, obj.getRcgChknOther,
        obj.getRcgArss, obj.getFcTc, obj.getFcNorm, obj.getFcSch, obj.getFcTc2, obj.getFcChke, obj.getFcChkn,
        obj.getFcChknHisSch, obj.getFcChknCgcs, obj.getFcChknOmsKafka, obj.getFcChknCms, obj.getFcChknOther,
        obj.getFcArss, obj.getFcPush, obj.getFcTotal, obj.getOvertime, obj.getRcgDispatchNorm, obj.getRcgDispatchTc2,
        obj.getRcgDispatchChke, obj.getRcgDispatchChkn, obj.getRcgChknCgcsKdd, obj.getFcDispatchNorm, obj.getFcDispatchTc2,
        obj.getFcDispatchChke, obj.getFcDispatchChkn, obj.getFcChknCgcsKdd, obj.getRcgDispatchRoad, obj.getRcgDispatchPhone,
        obj.getFcDispatchRoad, obj.getFcDispatchPhone, obj.getRcgPhone, obj.getFcPhone,
        obj.getChkKsReq, obj.getChkKsRe, obj.getChkKsAoi, obj.getChkKsTc, obj.getChkKsGisTc
      )
    }).toDF()
    puTcZcConvertDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.oms_put_tc_zc_stat")
  }

  def savePuAoiToHive(puAoiRdd: RDD[OmsPuAoi], spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val puAoiConvertDf = puAoiRdd.map(obj => {
      OmsPuAoiObj(obj.getId, obj.getUnderCall, obj.getStatDate, obj.getProvince, obj.getRegion,
        obj.getCityCode, obj.getCity, obj.getSysSource, obj.getOrder, obj.getAoi, obj.getAoiAuto, obj.getAoiGis, obj.getAoiNorm,
        obj.getAoiSch, obj.getAoiTc2, obj.getAoiChke, obj.getAoiChkn, obj.getAoiDispatchNorm, obj.getAoiDispatchTc2,
        obj.getAoiDispatchChke, obj.getAoiDispatchChkn, obj.getAoiDispatchRoad, obj.getAoiDispatchPhone,
        obj.getAoiPhone, obj.getAoiOther, obj.getAoiKs, obj.getAoiArssRe, obj.getAoiArssReq,
        obj.getAoiFc, obj.getAoiGisFc, obj.getAoiNormFc,
        obj.getAoiSchFc, obj.getAoiTc2Fc, obj.getAoiChkeFc, obj.getAoiChknFc, obj.getAoiDispatchNormFc, obj.getAoiDispatchTc2Fc,
        obj.getAoiDispatchChkeFc, obj.getAoiDispatchChknFc, obj.getAoiDispatchRoadFc, obj.getAoiDispatchPhoneFc,
        obj.getAoiPhoneFc, obj.getAoiOtherFc, obj.getAoiKsFc, obj.getAoiArssFc, obj.getAddressBuilding,
        obj.getBidCollectCnt, obj.getBidCollectRejectCnt, obj.getBidCfCnt, obj.getBidSysCnt, obj.getBidSysOk, obj.getBidAoiidDiff, obj.getBidCfNorm, obj.getBidCfNormMultiGid,
        obj.getBidCfComapny, obj.getBidCfPhone, obj.getBidCfDsPoi, obj.getBidCfMinPoi, obj.getBidCfAoiMapping, obj.getBidCfOther,obj.getAoiMonthAcc,obj.getAoiMonthAccFc
      )
    }).toDF()
    puAoiConvertDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.oms_put_aoi_stat")

  }

  def savePuAoiZcToHive(puAoiZcRdd: RDD[OmsPuAoi], spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val puAoiZcConvertDf = puAoiZcRdd.map(obj => {
      OmsPuAoiZcObj(obj.getId, obj.getUnderCall, obj.getStatDate, obj.getProvince, obj.getRegion,
        obj.getCityCode, obj.getCity, obj.getZoneCode, obj.getSysSource, obj.getOrder, obj.getAoi, obj.getAoiAuto, obj.getAoiGis, obj.getAoiNorm,
        obj.getAoiSch, obj.getAoiTc2, obj.getAoiChke, obj.getAoiChkn, obj.getAoiDispatchNorm, obj.getAoiDispatchTc2,
        obj.getAoiDispatchChke, obj.getAoiDispatchChkn, obj.getAoiDispatchRoad, obj.getAoiDispatchPhone,
        obj.getAoiPhone, obj.getAoiOther, obj.getAoiKs, obj.getAoiArssRe, obj.getAoiArssReq,
        obj.getAoiFc, obj.getAoiGisFc, obj.getAoiNormFc,
        obj.getAoiSchFc, obj.getAoiTc2Fc, obj.getAoiChkeFc, obj.getAoiChknFc, obj.getAoiDispatchNormFc, obj.getAoiDispatchTc2Fc,
        obj.getAoiDispatchChkeFc, obj.getAoiDispatchChknFc, obj.getAoiDispatchRoadFc, obj.getAoiDispatchPhoneFc,
        obj.getAoiPhoneFc, obj.getAoiOtherFc, obj.getAoiKsFc, obj.getAoiArssFc, obj.getAddressBuilding, obj.getBidCollectCnt, obj.getBidCollectRejectCnt,
        obj.getBidCfCnt, obj.getBidSysCnt, obj.getBidSysOk, obj.getBidAoiidDiff, obj.getBidCfNorm, obj.getBidCfNormMultiGid,
        obj.getBidCfComapny, obj.getBidCfPhone, obj.getBidCfDsPoi, obj.getBidCfMinPoi, obj.getBidCfAoiMapping, obj.getBidCfOther,obj.getAoiMonthAcc,obj.getAoiMonthAccFc
      )
    }).toDF()
    puAoiZcConvertDf.withColumn("inc_day", lit(incDay)).repartition(1).write.mode(SaveMode.Overwrite).insertInto("dm_gis.oms_put_aoi_zc_stat")

  }

  def statPuTc(orderRdd: RDD[OrderData], incDay: String, adminAreaMap: util.Map[String, util.List[AdminArea]],
               spark: SparkSession, bidAoiidArrayBc: Broadcast[Array[String]], bidAoiidRejectArrayBc: Broadcast[Array[String]]): Unit = {
    val (puTcRdd, puAoiRdd, puAoiZcRdd, puTcRddZcRdd) = getPuTc(orderRdd, adminAreaMap, bidAoiidArrayBc, bidAoiidRejectArrayBc)
//    savePuTc(puTcRdd, spark, incDayList)
//    savePuAoi(puAoiRdd, spark, incDayList)
//    savePuAoiZc(puAoiZcRdd, spark, incDayList)
//    savePuTcZc(puTcRddZcRdd, spark, incDayList)
    try {
      save_omsputc_to_hive(spark, puTcRdd.repartition(1), incDay)
    } catch {
      case e: Exception => logger.error("insert puTc error", e)
    }
    logger.error("存储pu tc到hive")
    savePuTcToHive(puTcRdd, spark, incDay)
    logger.error("存储pu aoi到hive")
    savePuAoiToHive(puAoiRdd, spark, incDay)
    logger.error("存储pu aoi zc 到hive")
    savePuAoiZcToHive(puAoiZcRdd, spark, incDay)
    logger.error("存储pu tc zc 到hive")
    savePuTcZcToHive(puTcRddZcRdd, spark, incDay)
  }

  /**
    * 解析chk和ks往来的指标
    */
  def parsChkKsStatCount(omsPuTc: OmsPuTc, obj: OrderData): Unit = {

    val chkKsReqBody = obj.getChkKsReqBody
    var chkKsReqCount = 0
    if (chkKsReqBody != null) {
      chkKsReqCount = 1
    }
    omsPuTc.setChkKsReq(chkKsReqCount)

    var chkKsReCount = 0
    var aoiCount = 0
    var tcCount = 0
    val chkKsReBody = obj.getChkKsReBody
    if (chkKsReBody != null) {
      chkKsReCount = 1
      val result = chkKsReBody.getJSONObject("result")
      if (result != null) {
        val aoi = result.getString("aoi")
        if (aoi != null && !aoi.isEmpty) {
          aoiCount = 1
        }
        val tc = result.getString("tc")
        if (tc != null && !tc.isEmpty) {
          tcCount = 1
        }
      }
    }
    omsPuTc.setChkKsAoi(aoiCount)
    omsPuTc.setChkKsRe(chkKsReCount)
    omsPuTc.setChkKsTc(tcCount)
  }

  /**
    * 更新基础信息
    *
    * @param omsPuAoi :
    * @param omsPuTc  :
    */
  def updateAoiBaseInfoByTc(omsPuAoi: OmsPuAoi, omsPuTc: OmsPuTc): Unit = {
    omsPuAoi.setCity(omsPuTc.getCity)
    omsPuAoi.setCityCode(omsPuTc.getCityCode)
    omsPuAoi.setProvince(omsPuTc.getProvince)
    omsPuAoi.setRegion(omsPuTc.getRegion)
    omsPuAoi.setStatDate(omsPuTc.getStatDate)
    omsPuAoi.setUnderCall(omsPuTc.getUnderCall)
    omsPuAoi.setOrder(omsPuTc.getOrder)
    omsPuAoi.setId(MD5Util.getMD5(String.format("%s%s%s%s%s", omsPuTc.getUnderCall, omsPuTc.getStatDate, omsPuTc.getCityCode, omsPuTc.getCity, omsPuAoi.getSysSource)))
  }

  def staBid(omsPuAoi: OmsPuAoi, bidAoiState: String, addresseeAoiId: String, bid_re_body: JSONObject, bidAoiArray: Array[String], bidAoiidRejectArray: Array[String]): Unit = {
    //楼栋识别率
    var bidCollectCnt = 0
    var bidCollectRejectCnt = 0
    var bidCfCnt = 0
    var bidSysCnt = 0
    var bidSysOk = 0
    var bidAoiidDiff = 0

    if (bidAoiState != null && !bidAoiState.isEmpty) {
      bidCollectCnt = 1
      if (!bidAoiState.equals("1")) {
        bidCollectRejectCnt = 1
        val buildingId = JSONUtil.getJsonVal(bid_re_body, "result.buildingId", "")
        if (!buildingId.isEmpty) {
          bidCfCnt = 1
          val bidAoiid = JSONUtil.getJsonVal(bid_re_body, "result.aoiId", "")
          if (bidAoiid.equals(addresseeAoiId)) {
            bidSysCnt = 1
            val tmpLable = JSONUtil.getJsonVal(bid_re_body, "result.label", "")
            if ("2".equals(tmpLable)) {
              bidSysOk = 1
            }
            val tmpSource = JSONUtil.getJsonVal(bid_re_body, "result.source", "")
            if ("DS_POI".equals(tmpSource)) {
              bidSysOk = 1
            }
            val geoPrecision = JSONUtil.getJsonVal(bid_re_body, "result.geoPrecision", "")
            try {
              if (!geoPrecision.isEmpty && geoPrecision.toFloat > 94) {
                bidSysOk = 1
              }
            } catch {
              case e: Exception =>
            }
            //            val others = JSONUtil.getJsonVal(bid_re_body,"result.others")
            //            if(others != null){
            //              val geocoder = others.asInstanceOf[JSONObject].getJSONArray("geocoder")
            //              if(geocoder!=null && !geocoder.isEmpty){
            //                val confidence = geocoder.getJSONObject(0).getInteger("confidence")
            //                if(confidence!=null && confidence>94){
            //                  bidSysOk = 1
            //                }
            //              }
            //            }
          } else {
            bidAoiidDiff = 1
          }
        }

      }
    }
    val bidSource = JSONUtil.getJsonVal(bid_re_body, "result.source", "")
    val (bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping, bidCfOther) = matchBidSource(bidSource, bidCfCnt)
    omsPuAoi.updateBidSta(bidCollectCnt, bidCollectRejectCnt, bidCfCnt, bidSysCnt, bidSysOk, bidAoiidDiff,
      bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping, bidCfOther)
  }

  //匹配bid源数据
  def matchBidSource(bidSource: String, bidCfCnt: Int): (Int, Int, Int, Int, Int, Int, Int, Int) = {
    var bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping, bidCfOther = 0
    if (bidCfCnt == 1) {
      bidSource match {
        case "NORM" => bidCfNorm = 1
        case "NORM_MULTI_GID" => bidCfNormMultiGid = 1
        case "COMPANY" => bidCfComapny = 1
        case "PHONE" => bidCfPhone = 1
        case "DS_POI" => bidCfDsPoi = 1
        case "MIN_POI" => bidCfMinPoi = 1
        case "AOI_MAPPING" => bidCfAoiMapping = 1
        case _ => bidCfOther = 1
      }
    }
    (bidCfNorm, bidCfNormMultiGid, bidCfComapny, bidCfPhone, bidCfDsPoi, bidCfMinPoi, bidCfAoiMapping, bidCfOther)
  }

  def getPuTcDetail(obj: OrderData, adminAreaMap: util.Map[String, util.List[AdminArea]],
                    bidAoiidArray: Array[String], bidAoiidRejectArray: Array[String]):
  (OmsPuAoi, OmsPuTc, OmsPuTc) = {
    val omsPuTc = new OmsPuTc
    var omsPuAoi = new OmsPuAoi
    val omsPuTcNonCancelled = new OmsPuTc
    //    try{
    parsChkKsStatCount(omsPuTc, obj)
    val adminArea = getAdminArea(obj, adminAreaMap)
    if (VariableConstant.DEFAULT_VALUE_STRING.equals(adminArea.getCityCode)) {
      return (null, null, null)
    }
    omsPuTc.setStatDate(obj.getReqDate)
    omsPuTc.setCityCode(adminArea.getCityCode)
    omsPuTc.setRegion(adminArea.getRegion)
    omsPuTc.setCity(adminArea.getCity)
    omsPuTc.setProvince(adminArea.getProvince)

    var status: String = ""
    var src: String = ""
    var aoiSrc: String = ""
    var aoiCode: String = ""
    var tc: String = ""
    var deptCode: String = ""
    var reqFlag = false
    val syncStatus: String = obj.getSyncReStatus
    var chkDeptSrc: String = ""
    val errCallFlag = obj.isErrCallFlag
    var isKsTcFlag = false
    var addressBuilding = 0
    omsPuTc.setZoneCode(deptCode)
    omsPuAoi.setZoneCode(deptCode)
    val chkToOmsReBody = obj.getChkOmsRebody
    //        var chkToOmsSysOrderNo:String = null
    var chkToOmsTc: String = null
    var chkToOmsAoiCode: String = null
    var chkToOmsDept = ""
    if (chkToOmsReBody != null) {
      //          chkToOmsSysOrderNo = chkToOmsReBody.getString(VariableConstant.SYS_ORDERNO_KEY)
      val orderFrom = chkToOmsReBody.getJSONObject("orderFrom")
      if (orderFrom != null) {
        chkToOmsTc = orderFrom.getString("teamCode")
        chkToOmsAoiCode = orderFrom.getString("aoiCode")
        chkToOmsDept = orderFrom.getString("deptCode")
      }
    }
    //      val ksReBody = obj.getChkKsReBody
    //      //        var chkToOmsSysOrderNo:String = null
    //      val chkToOmsTc:String = JSONUtil.getJsonVal(ksReBody,"tc","")
    //      val chkToOmsAoiCode:String = JSONUtil.getJsonVal(ksReBody,"aoiCode","")
    if (obj.isAsyncReqFlag) { //有异步请求
      status = obj.getAsyncReStatus
      src = obj.getAsyncSrc
      aoiSrc = src
      tc = obj.getAsyncTeamCode
      deptCode = obj.getAsyncDeptCode
      aoiCode = obj.getAsyncAoiCode
      if (chkToOmsTc != null && !chkToOmsTc.isEmpty) {
        isKsTcFlag = true
        tc = chkToOmsTc
        src = "ks"
      }
      if (chkToOmsAoiCode != null && !chkToOmsAoiCode.isEmpty) {
        aoiSrc = "ks"
        aoiCode = chkToOmsAoiCode
        deptCode = chkToOmsDept
      }
      reqFlag = true
      chkDeptSrc = obj.getAsyncChkDeptSrc
      val aysncReBody = obj.getAsyncReBody
      val buildingId = JSONUtil.getJsonVal(aysncReBody, "ret.buildingId", "")
      if (!buildingId.isEmpty) {
        addressBuilding = 1
      }
    } else if (obj.isSyncReqFlag) {
      status = obj.getSyncReStatus
      src = obj.getSyncSrc
      aoiSrc = src
      tc = obj.getSyncTeamCode
      deptCode = obj.getSyncDeptCode
      aoiCode = obj.getSyncAoiCode
      reqFlag = true
      chkDeptSrc = obj.getSyncChkDeptSrc
      val syncReBody = obj.getSyncReBody
      val buildingId = JSONUtil.getJsonVal(syncReBody, "ret.buildingId", "")
      if (!buildingId.isEmpty) {
        addressBuilding = 1
      }
    }

    if (reqFlag && obj.isArssReFlag) { //审补返回
      tc = obj.getArssTeamCode
      deptCode = obj.getArssDeptCode
      aoiCode = obj.getArssAoiCode
      src = "chke_cur"
      aoiSrc = src
    }

    if (reqFlag) {
      omsPuTc.setOrder(1)
      omsPuTc.setOvertime(if (VariableConstant.TIMEOUT_STATUS.equals(syncStatus)) 1 else 0)
      omsPuTc.setRcgTc(if (VariableConstant.SUCCESS_STATUS.equals(status)) 1 else 0)
      if (isKsTcFlag) {
        omsPuTc.setRcgTc(1)
        omsPuTc.setChkKsGisTc(1)
      }
      omsPuAoi.setZoneCode(deptCode)
      omsPuAoi.setAddressBuilding(addressBuilding)
      omsPuTc.setZoneCode(deptCode)
      updateAoiInfo(omsPuAoi, aoiCode, aoiSrc, errCallFlag)
      //楼栋相关指标
      staBid(omsPuAoi, obj.getBidAoiState, obj.getAoiId, obj.getResponseBuildingBody, bidAoiidArray, bidAoiidRejectArray)

      //gis 识别量细分
      src match {
        case "norm" =>
          omsPuTc.setRcgNorm(1)
        case "sch" =>
          omsPuTc.setRcgSch(1)
        case "tc2" =>
          omsPuTc.setRcgTc2(1)
        case "chke" =>
          omsPuTc.setRcgChke(1)
        case "chkn" =>
          omsPuTc.setRcgChkn(1)
        case "telnorm" =>
          omsPuTc.setRcgPhone(1)
        case "chke_cur" =>
          omsPuTc.setRcgArss(1)
        case "dispatch-norm" =>
          omsPuTc.setRcgDispatchNorm(1)
        case "dispatch-chkn" =>
          omsPuTc.setRcgDispatchChkn(1)
        case "dispatch-chke" =>
          omsPuTc.setRcgDispatchChke(1)
        case "dispatch-tc2" =>
          omsPuTc.setRcgDispatchTc2(1)
        case "dispatch-road" =>
          omsPuTc.setRcgDispatchRoad(1)
        case "dispatch-phone" =>
          omsPuTc.setRcgDispatchPhone(1)
        case _ =>
      }

      if ("chkn".equals(src)) {
        chkDeptSrc match {
          case "his_sch" =>
            omsPuTc.setRcgChknHisSch(1)
          case "cgcs" =>
            omsPuTc.setRcgChknCgcs(1)
          case "oms_kafka" =>
            omsPuTc.setRcgChknOmsKafka(1)
          case "cms" =>
            omsPuTc.setRcgChknCms(1)
          case "cgcs_kdd" =>
            omsPuTc.setRcgChknCgcsKdd(1)
          case _ =>
            omsPuTc.setRcgChknOther(1)
        }
      }

      if (errCallFlag) {
        omsPuTc.setFcTotal(1)
        omsPuTc.setFcTc(if (VariableConstant.SUCCESS_STATUS.equals(status)) 1 else 0)
        src match {
          case "norm" =>
            omsPuTc.setFcNorm(1)
          case "sch" =>
            omsPuTc.setFcSch(1)
          case "tc2" =>
            omsPuTc.setFcTc2(1)
          case "chke" =>
            omsPuTc.setFcChke(1)
          case "chkn" =>
            omsPuTc.setFcChkn(1)
          case "telnorm" =>
            omsPuTc.setFcPhone(1)
          case "chke_cur" =>
            omsPuTc.setFcArss(1)
          case "dispatch-norm" =>
            omsPuTc.setFcDispatchNorm(1)
          case "dispatch-chkn" =>
            omsPuTc.setFcDispatchChkn(1)
          case "dispatch-chke" =>
            omsPuTc.setFcDispatchChke(1)
          case "dispatch-tc2" =>
            omsPuTc.setFcDispatchTc2(1)
          case "dispatch-road" =>
            omsPuTc.setFcDispatchRoad(1)
          case "dispatch-phone" =>
            omsPuTc.setFcDispatchPhone(1)
          case _ =>
        }
        if ("chkn".equals(src)) {
          chkDeptSrc match {
            case "his_sch" =>
              omsPuTc.setFcChknHisSch(1)
            case "cgcs" =>
              omsPuTc.setFcChknCgcs(1)
            case "oms_kafka" =>
              omsPuTc.setFcChknOmsKafka(1)
            case "cms" =>
              omsPuTc.setFcChknCms(1)
            case "cgcs_kdd" =>
              omsPuTc.setFcChknCgcsKdd(1)
            case _ =>
              omsPuTc.setFcChknOther(1)
          }
        }
      }
    }
    omsPuTc.setUnderCall("YES")
    if (obj.getIsNotUnderCall != null && "1".equals(obj.getIsNotUnderCall)) {
      omsPuTc.setUnderCall("NO")
    }
    val pickUpBody = obj.getPickupBody
    var isCanceled = 0
    var pickupTc: String = null
    var currentState: String = null
    if (pickUpBody != null) {
      currentState = pickUpBody.getString("current_state")
      if ("CANCELED".equals(currentState)) {
        isCanceled = 1
      }
      pickupTc = pickUpBody.getString("pick_up_tc")
    }
    omsPuAoi.setSysSource(obj.getSysSource)
    updateAoiBaseInfoByTc(omsPuAoi, omsPuTc)

    omsPuTc.setDataType("PRE")
    omsPuTc.setId(MD5Util.getMD5(String.format("%s%s%s%s%s%s", omsPuTc.getUnderCall, omsPuTc.getDataType, omsPuTc.getStatDate, omsPuTc.getCityCode, omsPuTc.getCity, omsPuTc.getSysSource)))
    if (errCallFlag) {
      omsPuTc.setFcPush(1)
    } else {
      omsPuTc.setFcPush(0)
    }
    omsPuTcNonCancelled.init(omsPuTc)
    omsPuTcNonCancelled.setDataType("AFT")
    omsPuTcNonCancelled.setId(MD5Util.getMD5(String.format("%s%s%s%s%s%s", omsPuTcNonCancelled.getUnderCall, omsPuTcNonCancelled.getDataType, omsPuTcNonCancelled.getStatDate, omsPuTcNonCancelled.getCityCode, omsPuTcNonCancelled.getCity, omsPuTcNonCancelled.getSysSource)))

    if (isCanceled == 1) {
      omsPuTcNonCancelled.resetAllSta(0)
      omsPuTcNonCancelled.setFcPush(0)
    } else if (pickupTc != null && !pickupTc.isEmpty && "FINISH".equals(currentState)) {
      if (obj.getTeamCode != null && !obj.getTeamCode.isEmpty && obj.getTeamCode.equals(pickupTc)) {
        omsPuTcNonCancelled.setFcTotal(0)
        omsPuTcNonCancelled.setFcPush(0)
      }
      if (obj.getArssTeamCode != null && !obj.getArssTeamCode.isEmpty && obj.getArssTeamCode.equals(pickupTc)) {
        omsPuTcNonCancelled.setFcArss(0)
      }
      if (obj.getAsyncTeamCode != null && !obj.getAsyncTeamCode.isEmpty && obj.getAsyncTeamCode.equals(pickupTc)
        || (obj.getSyncTeamCode != null && !obj.getSyncTeamCode.isEmpty && obj.getSyncTeamCode.equals(pickupTc))) {
        omsPuTcNonCancelled.updateFcGis(0)
      }
    }
    //    }catch {
    //      case e : Exception =>
    //        logger.error("transform order to tc index error", e)
    //        omsPuAoi = null
    //    }
    (omsPuAoi, omsPuTc, omsPuTcNonCancelled)
  }

  def getPuTc(orderRdd: RDD[OrderData],
              adminAreaMap: util.Map[String, util.List[AdminArea]], bidAoiidArrayBc: Broadcast[Array[String]], bidAoiidRejectArrayBc: Broadcast[Array[String]]): (RDD[OmsPuTc], RDD[OmsPuAoi], RDD[OmsPuAoi], RDD[OmsPuTc]) = {
    logger.error(">>>stat puTc.")
    val puRdd = orderRdd.map(obj => {
      getPuTcDetail(obj, adminAreaMap, null, null)
    }).filter(_._1 != null).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("指标转换完毕：" + puRdd.count())
    orderRdd.unpersist()
    logger.error("聚合tc")
    val puTcRdd = puRdd.flatMap(obj => {
      val list = new util.ArrayList[(String, OmsPuTc)]()
      val omsPuTc = obj._2
      list.add((String.format("%s_%s_%s_%s_%s_%s", omsPuTc.getUnderCall, omsPuTc.getDataType, omsPuTc.getStatDate, omsPuTc.getCityCode, omsPuTc.getCity, omsPuTc.getSysSource), omsPuTc))
      val omsPuTcNonCancelled = obj._3
      list.add((String.format("%s_%s_%s_%s_%s_%s", omsPuTcNonCancelled.getUnderCall, omsPuTcNonCancelled.getDataType, omsPuTcNonCancelled.getStatDate, omsPuTcNonCancelled.getCityCode, omsPuTcNonCancelled.getCity, omsPuTcNonCancelled.getSysSource), omsPuTcNonCancelled))
      list.iterator()
    }).reduceByKey((obj1, obj2) => {
      obj1.merge(obj2)
      obj1
    }).map(tp => {
      tp._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("tc聚合后：" + puTcRdd.count())
    //    puTcRdd.filter(obj=> (obj.getSysSource != null && !obj.getSysSource.isEmpty)).take(10).foreach(obj=>{
    //      logger.error("obj:"+obj.getCity+",sysource:"+obj.getSysSource)
    //    })
    logger.error("聚合zc维度的tc")
    val puTcRddZcRdd = puRdd.flatMap(obj => {
      val list = new util.ArrayList[(String, OmsPuTc)]()
      val omsPuTc = obj._2
      omsPuTc.setId(MD5Util.getMD5(String.format("%s%s%s%s%s%s", omsPuTc.getUnderCall, omsPuTc.getDataType, omsPuTc.getStatDate, omsPuTc.getCityCode, omsPuTc.getCity, omsPuTc.getZoneCode)))
      list.add((String.format("%s_%s_%s_%s_%s_%s", omsPuTc.getUnderCall, omsPuTc.getDataType, omsPuTc.getStatDate, omsPuTc.getCityCode, omsPuTc.getCity, omsPuTc.getZoneCode), omsPuTc))
      val omsPuTcNonCancelled = obj._3
      omsPuTcNonCancelled.setId(MD5Util.getMD5(String.format("%s%s%s%s%s%s", omsPuTcNonCancelled.getUnderCall, omsPuTcNonCancelled.getDataType, omsPuTcNonCancelled.getStatDate, omsPuTcNonCancelled.getCityCode, omsPuTcNonCancelled.getCity, omsPuTcNonCancelled.getZoneCode)))
      list.add((String.format("%s_%s_%s_%s_%s_%s", omsPuTcNonCancelled.getUnderCall, omsPuTcNonCancelled.getDataType, omsPuTcNonCancelled.getStatDate, omsPuTcNonCancelled.getCityCode, omsPuTcNonCancelled.getCity, omsPuTcNonCancelled.getZoneCode), omsPuTcNonCancelled))
      list.iterator()
    }).reduceByKey((obj1, obj2) => {
      obj1.merge(obj2)
      obj1
    }).map(tp => {
      tp._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("tcZc聚合后：" + puTcRddZcRdd.count())

    logger.error("聚合aoi")
    val puAoiRdd = puRdd.flatMap(obj => {
      val list = new util.ArrayList[(String, OmsPuAoi)]()
      val omsPuAoi = obj._1
      list.add((String.format("%s_%s_%s_%s_%s", omsPuAoi.getUnderCall, omsPuAoi.getStatDate, omsPuAoi.getCityCode, omsPuAoi.getCity, omsPuAoi.getSysSource), omsPuAoi))
      list.iterator()
    }).reduceByKey((obj1, obj2) => {
      obj1.merge(obj2)
      obj1
    }).map(tp => {
      tp._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("aoi聚合后：" + puAoiRdd.count())
    logger.error("聚合zc维度aoi")
    val puAoiZcRdd = puRdd.flatMap(obj => {
      val list = new util.ArrayList[(String, OmsPuAoi)]()
      val omsPuAoi = obj._1
      omsPuAoi.setId(MD5Util.getMD5(String.format("%s%s%s%s%s%s", omsPuAoi.getUnderCall, omsPuAoi.getStatDate, omsPuAoi.getCityCode, omsPuAoi.getCity, omsPuAoi.getZoneCode, omsPuAoi.getSysSource)))
      list.add((String.format("%s_%s_%s_%s_%s_%s", omsPuAoi.getUnderCall, omsPuAoi.getStatDate, omsPuAoi.getCityCode, omsPuAoi.getCity, omsPuAoi.getZoneCode, omsPuAoi.getSysSource), omsPuAoi))
      list.iterator()
    }).reduceByKey((obj1, obj2) => {
      obj1.merge(obj2)
      obj1
    }).map(tp => {
      tp._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("aoiZc聚合后：" + puAoiZcRdd.count())
    puRdd.unpersist()
    (puTcRdd, puAoiRdd, puAoiZcRdd, puTcRddZcRdd)
  }

  /**
    * 更新aoi信息
    *
    * @param omsPuAoi
    */
  def updateAoiInfo(omsPuAoi: OmsPuAoi, aoiCode: String, aoiSrc: String, errorCallFlag: Boolean): Unit = {
    if (aoiSrc.equals("chke_cur")) {
      omsPuAoi.setAoiArssReq(1)
    }
    if (aoiCode != null && !aoiCode.isEmpty) {
      omsPuAoi.setAoi(1)
      //aoi 识别量细分
      aoiSrc match {
        case "norm" =>
          omsPuAoi.setAoiNorm(1)
          omsPuAoi.setAoiGis(1)
        case "sch" =>
          omsPuAoi.setAoiSch(1)
          omsPuAoi.setAoiGis(1)
        case "tc2" =>
          omsPuAoi.setAoiTc2(1)
          omsPuAoi.setAoiGis(1)
        case "chke" =>
          omsPuAoi.setAoiChke(1)
          omsPuAoi.setAoiGis(1)
        case "chkn" =>
          omsPuAoi.setAoiChkn(1)
          omsPuAoi.setAoiGis(1)
        case "telnorm" =>
          omsPuAoi.setAoiPhone(1)
          omsPuAoi.setAoiGis(1)
        case "chke_cur" =>
          omsPuAoi.setAoiArssRe(1)
        case "dispatch-norm" =>
          omsPuAoi.setAoiDispatchNorm(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-chkn" =>
          omsPuAoi.setAoiDispatchChkn(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-chke" =>
          omsPuAoi.setAoiDispatchChke(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-tc2" =>
          omsPuAoi.setAoiDispatchTc2(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-road" =>
          omsPuAoi.setAoiDispatchRoad(1)
          omsPuAoi.setAoiGis(1)
        case "dispatch-phone" =>
          omsPuAoi.setAoiDispatchPhone(1)
          omsPuAoi.setAoiGis(1)
        case "monthAcc"=>
          omsPuAoi.setAoiMonthAcc(1)
          omsPuAoi.setAoiGis(1)
        case "ks" =>
          omsPuAoi.setAoiKs(1)
        case _ =>
          omsPuAoi.setAoiOther(1)
          omsPuAoi.setAoiGis(1)
      }
      if (omsPuAoi.getAoiGis == 1 || omsPuAoi.getAoiKs == 1) {
        omsPuAoi.setAoiAuto(1)
      }
    }
    var errorCall = 0
    if (errorCallFlag) {
      errorCall = 1
    }
    omsPuAoi.setAoiFc(omsPuAoi.getAoi * errorCall)
    omsPuAoi.setAoiArssFc(omsPuAoi.getAoiArssRe * errorCall)
    omsPuAoi.setAoiChkeFc(omsPuAoi.getAoiChke * errorCall)
    omsPuAoi.setAoiChknFc(omsPuAoi.getAoiChkn * errorCall)
    omsPuAoi.setAoiGisFc(omsPuAoi.getAoiGis * errorCall)
    omsPuAoi.setAoiKsFc(omsPuAoi.getAoiKs * errorCall)
    omsPuAoi.setAoiNormFc(omsPuAoi.getAoiNorm * errorCall)
    omsPuAoi.setAoiOtherFc(omsPuAoi.getAoiOther * errorCall)
    omsPuAoi.setAoiPhoneFc(omsPuAoi.getAoiPhone * errorCall)
    omsPuAoi.setAoiSchFc(omsPuAoi.getAoiSch * errorCall)
    omsPuAoi.setAoiTc2Fc(omsPuAoi.getAoiTc2 * errorCall)
    omsPuAoi.setAoiDispatchChkeFc(omsPuAoi.getAoiDispatchChke * errorCall)
    omsPuAoi.setAoiDispatchChknFc(omsPuAoi.getAoiDispatchChkn * errorCall)
    omsPuAoi.setAoiDispatchNormFc(omsPuAoi.getAoiDispatchNorm * errorCall)
    omsPuAoi.setAoiDispatchPhoneFc(omsPuAoi.getAoiDispatchPhone * errorCall)
    omsPuAoi.setAoiDispatchRoadFc(omsPuAoi.getAoiDispatchRoad * errorCall)
    omsPuAoi.setAoiDispatchTc2Fc(omsPuAoi.getAoiDispatchTc2 * errorCall)
    omsPuAoi.setAoiMonthAccFc(omsPuAoi.getAoiMonthAcc * errorCall)
  }

  /**
    * OMS收件AOI统计
    *
    * @param puAoiRdd : 数据rdd
    */
  def savePuAoi(puAoiRdd: RDD[OmsPuAoi], spark: SparkSession, incDayList: util.ArrayList[String]): Unit = {
    logger.error(">>>save puAoi.")
    val omsPuAoiTable = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("mysql.table.oms_pu_aoi")
    try {
      val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
      val delRcgSql = String.format(s"delete from $omsPuAoiTable where stat_date='%s'", incDayList.get(0))
      logger.error(">>>保存之前，删除rcg一天的数据:" + delRcgSql)
      DbUtils.executeSql(conn, delRcgSql)
      val stmt = conn.prepareStatement(
        String.format("INSERT INTO %s(`ID`, `UNDER_CALL`,`STAT_DATE`, `PROVINCE`, `REGION`, `CITY_CODE`," +
          " `CITY`,`SYSSOURCE`, `ORDER`, `AOI`,`AOI_AUTO`,`AOI_GIS`, `AOI_GIS_NORM`, `AOI_GIS_SCH`, `AOI_GIS_TC2`," +
          " `AOI_GIS_CHKE`, `AOI_GIS_CHKN`, `AOI_GIS_DPNORM`,`AOI_GIS_DPTC2`,`AOI_GIS_DPCHKE`,`AOI_GIS_DPCHKN`," +
          "`AOI_GIS_DPROAD`,`AOI_GIS_DPPHONE`," +
          "`AOI_GIS_PHONE`,`AOI_GIS_OTHER`,`AOI_KS`,`AOI_ARSS_RE`,`AOI_ARSS_REQ`," +
          "`FC_AOI`,`FC_AOI_GIS`, `FC_AOI_GIS_NORM`, `FC_AOI_GIS_SCH`, `FC_AOI_GIS_TC2`," +
          "`FC_AOI_GIS_CHKE`, `FC_AOI_GIS_CHKN`, `FC_AOI_GIS_DPNORM`,`FC_AOI_GIS_DPTC2`," +
          "`FC_AOI_GIS_DPCHKE`,`FC_AOI_GIS_DPCHKN`,`FC_AOI_GIS_DPROAD`,`FC_AOI_GIS_DPPHONE`," +
          "`FC_AOI_GIS_PHONE`,`FC_AOI_GIS_OTHER`,`FC_AOI_KS`,`FC_AOI_ARSS`,`ADDRESS_BUILDING`," +
          "bid_collect_cnt,bid_collect_reject_cnt,bid_cf_cnt,bid_sys_cnt,bid_sys_ok,bid_aoiid_diff," +
          "bid_cf_norm,bid_cf_norm_multi_gid,bid_cf_company,bid_cf_phone,bid_cf_ds_poi,bid_cf_min_poi," +
          "bid_cf_aoi_mapping,bid_cf_other" +
          ") VALUES(?,?,?, ?, ?,?,?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
          "ON DUPLICATE KEY UPDATE `ORDER` = ?, `AOI` = ?,`AOI_AUTO` = ?,`AOI_GIS` = ?, `AOI_GIS_NORM` = ?," +
          "`AOI_GIS_SCH` = ?, `AOI_GIS_TC2` = ?, `AOI_GIS_CHKE` = ?, `AOI_GIS_CHKN` = ?, " +
          "`AOI_GIS_DPNORM`= ?,`AOI_GIS_DPTC2`= ?,`AOI_GIS_DPCHKE`= ?,`AOI_GIS_DPCHKN`= ?," +
          "`AOI_GIS_DPROAD`= ?,`AOI_GIS_DPPHONE`= ?,`AOI_GIS_PHONE`= ?,`AOI_GIS_OTHER`= ?," +
          "`AOI_KS`=?,`AOI_ARSS_RE`=?,`AOI_ARSS_REQ`=?," +
          "`FC_AOI` = ?,`FC_AOI_GIS` = ?, `FC_AOI_GIS_NORM` = ?," +
          "`FC_AOI_GIS_SCH` = ?, `FC_AOI_GIS_TC2` = ?, `FC_AOI_GIS_CHKE` = ?, `FC_AOI_GIS_CHKN` = ?, " +
          "`FC_AOI_GIS_DPNORM`= ?,`FC_AOI_GIS_DPTC2`= ?,`FC_AOI_GIS_DPCHKE`= ?,`FC_AOI_GIS_DPCHKN`= ?," +
          "`FC_AOI_GIS_DPROAD`= ?,`FC_AOI_GIS_DPPHONE`= ?,`FC_AOI_GIS_PHONE`= ?,`FC_AOI_GIS_OTHER`= ?," +
          "`FC_AOI_KS`=?,`FC_AOI_ARSS`=?,`ADDRESS_BUILDING`=?,bid_collect_cnt=?,bid_collect_reject_cnt=?," +
          "bid_cf_cnt=?,bid_sys_cnt=?,bid_sys_ok=?,bid_aoiid_diff=?,bid_cf_norm=?,bid_cf_norm_multi_gid=?,bid_cf_company=?," +
          "bid_cf_phone=?,bid_cf_ds_poi=?,bid_cf_min_poi=?,bid_cf_aoi_mapping=?,bid_cf_other=?"
          , omsPuAoiTable))
      puAoiRdd.collect().foreach(obj => {
        val params = Array(obj.getId, obj.getUnderCall, obj.getStatDate, obj.getProvince, obj.getRegion,
          obj.getCityCode, obj.getCity, obj.getSysSource, obj.getOrder, obj.getAoi, obj.getAoiAuto, obj.getAoiGis, obj.getAoiNorm,
          obj.getAoiSch, obj.getAoiTc2, obj.getAoiChke, obj.getAoiChkn, obj.getAoiDispatchNorm, obj.getAoiDispatchTc2,
          obj.getAoiDispatchChke, obj.getAoiDispatchChkn, obj.getAoiDispatchRoad, obj.getAoiDispatchPhone,
          obj.getAoiPhone, obj.getAoiOther, obj.getAoiKs, obj.getAoiArssRe, obj.getAoiArssReq,
          obj.getAoiFc, obj.getAoiGisFc, obj.getAoiNormFc,
          obj.getAoiSchFc, obj.getAoiTc2Fc, obj.getAoiChkeFc, obj.getAoiChknFc, obj.getAoiDispatchNormFc, obj.getAoiDispatchTc2Fc,
          obj.getAoiDispatchChkeFc, obj.getAoiDispatchChknFc, obj.getAoiDispatchRoadFc, obj.getAoiDispatchPhoneFc,
          obj.getAoiPhoneFc, obj.getAoiOtherFc, obj.getAoiKsFc, obj.getAoiArssFc, obj.getAddressBuilding,
          obj.getBidCollectCnt, obj.getBidCollectRejectCnt, obj.getBidCfCnt, obj.getBidSysCnt, obj.getBidSysOk, obj.getBidAoiidDiff, obj.getBidCfNorm, obj.getBidCfNormMultiGid,
          obj.getBidCfComapny, obj.getBidCfPhone, obj.getBidCfDsPoi, obj.getBidCfMinPoi, obj.getBidCfAoiMapping, obj.getBidCfOther,
          obj.getOrder, obj.getAoi, obj.getAoiAuto, obj.getAoiGis, obj.getAoiNorm,
          obj.getAoiSch, obj.getAoiTc2, obj.getAoiChke, obj.getAoiChkn, obj.getAoiDispatchNorm, obj.getAoiDispatchTc2,
          obj.getAoiDispatchChke, obj.getAoiDispatchChkn, obj.getAoiDispatchRoad, obj.getAoiDispatchPhone,
          obj.getAoiPhone, obj.getAoiOther, obj.getAoiKs, obj.getAoiArssRe, obj.getAoiArssReq,
          obj.getAoiFc, obj.getAoiGisFc, obj.getAoiNormFc,
          obj.getAoiSchFc, obj.getAoiTc2Fc, obj.getAoiChkeFc, obj.getAoiChknFc, obj.getAoiDispatchNormFc, obj.getAoiDispatchTc2Fc,
          obj.getAoiDispatchChkeFc, obj.getAoiDispatchChknFc, obj.getAoiDispatchRoadFc, obj.getAoiDispatchPhoneFc,
          obj.getAoiPhoneFc, obj.getAoiOtherFc, obj.getAoiKsFc, obj.getAoiArssFc, obj.getAddressBuilding, obj.getBidCollectCnt, obj.getBidCollectRejectCnt,
          obj.getBidCfCnt, obj.getBidSysCnt, obj.getBidSysOk, obj.getBidAoiidDiff, obj.getBidCfNorm, obj.getBidCfNormMultiGid,
          obj.getBidCfComapny, obj.getBidCfPhone, obj.getBidCfDsPoi, obj.getBidCfMinPoi, obj.getBidCfAoiMapping, obj.getBidCfOther)
        for (i <- params.indices)
          stmt.setObject(i + 1, params(i))
        try {
          stmt.executeUpdate()
        } catch {
          case e: Exception => e.printStackTrace()
        }
      })
      conn.close()
    } catch {
      case e: Exception => logger.error("insert puAoi error", e)
    }
  }

  /**
    * OMS收件AOI统计Zc维度
    *
    * @param puAoiZcRdd : 数据rdd
    */
  def savePuAoiZc(puAoiZcRdd: RDD[OmsPuAoi], spark: SparkSession, incDayList: util.ArrayList[String]): Unit = {
    logger.error(">>>save puAoi.")
    val omsPuAoiTable = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("mysql.table.oms_pu_aoi_zc")
    try {
      val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
      val delRcgSql = String.format(s"delete from $omsPuAoiTable where stat_date='%s'", incDayList.get(0))
      logger.error(">>>保存之前，删除rcg一天的数据:" + delRcgSql)
      DbUtils.executeSql(conn, delRcgSql)
      val stmt = conn.prepareStatement(
        String.format("INSERT INTO %s(`ID`, `UNDER_CALL`,`STAT_DATE`, `PROVINCE`, `REGION`, `CITY_CODE`," +
          " `CITY`, `ZONE_CODE`,`SYSSOURCE`, `ORDER`, `AOI`,`AOI_AUTO`,`AOI_GIS`, `AOI_GIS_NORM`, `AOI_GIS_SCH`, `AOI_GIS_TC2`," +
          " `AOI_GIS_CHKE`, `AOI_GIS_CHKN`, `AOI_GIS_DPNORM`,`AOI_GIS_DPTC2`,`AOI_GIS_DPCHKE`,`AOI_GIS_DPCHKN`," +
          "`AOI_GIS_DPROAD`,`AOI_GIS_DPPHONE`," +
          "`AOI_GIS_PHONE`,`AOI_GIS_OTHER`,`AOI_KS`,`AOI_ARSS_RE`,`AOI_ARSS_REQ`," +
          "`FC_AOI`,`FC_AOI_GIS`, `FC_AOI_GIS_NORM`, `FC_AOI_GIS_SCH`, `FC_AOI_GIS_TC2`," +
          "`FC_AOI_GIS_CHKE`, `FC_AOI_GIS_CHKN`, `FC_AOI_GIS_DPNORM`,`FC_AOI_GIS_DPTC2`," +
          "`FC_AOI_GIS_DPCHKE`,`FC_AOI_GIS_DPCHKN`,`FC_AOI_GIS_DPROAD`,`FC_AOI_GIS_DPPHONE`," +
          "`FC_AOI_GIS_PHONE`,`FC_AOI_GIS_OTHER`,`FC_AOI_KS`,`FC_AOI_ARSS`,`ADDRESS_BUILDING`," +
          "bid_collect_cnt,bid_collect_reject_cnt,bid_cf_cnt,bid_sys_cnt,bid_sys_ok,bid_aoiid_diff," +
          "bid_cf_norm,bid_cf_norm_multi_gid,bid_cf_company,bid_cf_phone,bid_cf_ds_poi,bid_cf_min_poi," +
          "bid_cf_aoi_mapping,bid_cf_other" +
          ") VALUES(?,?,?, ?, ?,?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?) " +
          "ON DUPLICATE KEY UPDATE `ORDER` = ?, `AOI` = ?,`AOI_AUTO` = ?,`AOI_GIS` = ?, `AOI_GIS_NORM` = ?," +
          "`AOI_GIS_SCH` = ?, `AOI_GIS_TC2` = ?, `AOI_GIS_CHKE` = ?, `AOI_GIS_CHKN` = ?, " +
          "`AOI_GIS_DPNORM`= ?,`AOI_GIS_DPTC2`= ?,`AOI_GIS_DPCHKE`= ?,`AOI_GIS_DPCHKN`= ?," +
          "`AOI_GIS_DPROAD`= ?,`AOI_GIS_DPPHONE`= ?,`AOI_GIS_PHONE`= ?,`AOI_GIS_OTHER`= ?," +
          "`AOI_KS`=?,`AOI_ARSS_RE`=?,`AOI_ARSS_REQ`=?," +
          "`FC_AOI` = ?,`FC_AOI_GIS` = ?, `FC_AOI_GIS_NORM` = ?," +
          "`FC_AOI_GIS_SCH` = ?, `FC_AOI_GIS_TC2` = ?, `FC_AOI_GIS_CHKE` = ?, `FC_AOI_GIS_CHKN` = ?, " +
          "`FC_AOI_GIS_DPNORM`= ?,`FC_AOI_GIS_DPTC2`= ?,`FC_AOI_GIS_DPCHKE`= ?,`FC_AOI_GIS_DPCHKN`= ?," +
          "`FC_AOI_GIS_DPROAD`= ?,`FC_AOI_GIS_DPPHONE`= ?,`FC_AOI_GIS_PHONE`= ?,`FC_AOI_GIS_OTHER`= ?," +
          "`FC_AOI_KS`=?,`FC_AOI_ARSS`=?, `ADDRESS_BUILDING`=?,bid_collect_cnt=?,bid_collect_reject_cnt=?," +
          "bid_cf_cnt=?,bid_sys_cnt=?,bid_sys_ok=?,bid_aoiid_diff=?,bid_cf_norm=?,bid_cf_norm_multi_gid=?,bid_cf_company=?," +
          "bid_cf_phone=?,bid_cf_ds_poi=?,bid_cf_min_poi=?,bid_cf_aoi_mapping=?,bid_cf_other=?"
          , omsPuAoiTable))
      val puAoizc = puAoiZcRdd.collect()
      logger.error("count:" + puAoizc.length)
      puAoizc.foreach(obj => {
        val params = Array(obj.getId, obj.getUnderCall, obj.getStatDate, obj.getProvince, obj.getRegion,
          obj.getCityCode, obj.getCity, obj.getZoneCode, obj.getSysSource, obj.getOrder, obj.getAoi, obj.getAoiAuto, obj.getAoiGis, obj.getAoiNorm,
          obj.getAoiSch, obj.getAoiTc2, obj.getAoiChke, obj.getAoiChkn, obj.getAoiDispatchNorm, obj.getAoiDispatchTc2,
          obj.getAoiDispatchChke, obj.getAoiDispatchChkn, obj.getAoiDispatchRoad, obj.getAoiDispatchPhone,
          obj.getAoiPhone, obj.getAoiOther, obj.getAoiKs, obj.getAoiArssRe, obj.getAoiArssReq,
          obj.getAoiFc, obj.getAoiGisFc, obj.getAoiNormFc,
          obj.getAoiSchFc, obj.getAoiTc2Fc, obj.getAoiChkeFc, obj.getAoiChknFc, obj.getAoiDispatchNormFc, obj.getAoiDispatchTc2Fc,
          obj.getAoiDispatchChkeFc, obj.getAoiDispatchChknFc, obj.getAoiDispatchRoadFc, obj.getAoiDispatchPhoneFc,
          obj.getAoiPhoneFc, obj.getAoiOtherFc, obj.getAoiKsFc, obj.getAoiArssFc, obj.getAddressBuilding, obj.getBidCollectCnt, obj.getBidCollectRejectCnt,
          obj.getBidCfCnt, obj.getBidSysCnt, obj.getBidSysOk, obj.getBidAoiidDiff, obj.getBidCfNorm, obj.getBidCfNormMultiGid,
          obj.getBidCfComapny, obj.getBidCfPhone, obj.getBidCfDsPoi, obj.getBidCfMinPoi, obj.getBidCfAoiMapping, obj.getBidCfOther,
          obj.getOrder, obj.getAoi, obj.getAoiAuto, obj.getAoiGis, obj.getAoiNorm,
          obj.getAoiSch, obj.getAoiTc2, obj.getAoiChke, obj.getAoiChkn, obj.getAoiDispatchNorm, obj.getAoiDispatchTc2,
          obj.getAoiDispatchChke, obj.getAoiDispatchChkn, obj.getAoiDispatchRoad, obj.getAoiDispatchPhone,
          obj.getAoiPhone, obj.getAoiOther, obj.getAoiKs, obj.getAoiArssRe, obj.getAoiArssReq,
          obj.getAoiFc, obj.getAoiGisFc, obj.getAoiNormFc,
          obj.getAoiSchFc, obj.getAoiTc2Fc, obj.getAoiChkeFc, obj.getAoiChknFc, obj.getAoiDispatchNormFc, obj.getAoiDispatchTc2Fc,
          obj.getAoiDispatchChkeFc, obj.getAoiDispatchChknFc, obj.getAoiDispatchRoadFc, obj.getAoiDispatchPhoneFc,
          obj.getAoiPhoneFc, obj.getAoiOtherFc, obj.getAoiKsFc, obj.getAoiArssFc, obj.getAddressBuilding, obj.getBidCollectCnt, obj.getBidCollectRejectCnt,
          obj.getBidCfCnt, obj.getBidSysCnt, obj.getBidSysOk, obj.getBidAoiidDiff, obj.getBidCfNorm, obj.getBidCfNormMultiGid,
          obj.getBidCfComapny, obj.getBidCfPhone, obj.getBidCfDsPoi, obj.getBidCfMinPoi, obj.getBidCfAoiMapping, obj.getBidCfOther)
        for (i <- params.indices)
          stmt.setObject(i + 1, params(i))
        try {
          stmt.executeUpdate()
        } catch {
          case e: Exception => e.printStackTrace()
        }
      })
      conn.close()
    } catch {
      case e: Exception => logger.error("insert puAoiZc error", e)
    }
  }

  /**
    * OMS收件TC统计
    *
    * @param puTcRdd : 数据rdd
    */
  def savePuTc(puTcRdd: RDD[OmsPuTc], spark: SparkSession, incDayList: util.ArrayList[String]): Unit = {
    logger.error(">>>save puTc.")
    val omsPuTcTable = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("mysql.table.oms_pu_tc")
    try {
      val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn

      val stmt = conn.prepareStatement(
        String.format("INSERT INTO %s(`ID`, `UNDER_CALL`, `DATA_TYPE`,  `STAT_DATE`, `PROVINCE`, `REGION`, `CITY_CODE`, `CITY`,`SYSSOURCE`, `ORDER`, " +
          "`RCG_TC`, `RCG_NORM`, `RCG_SCH`, `RCG_TC2`, `RCG_CHKE`, `RCG_CHKN`, `RCG_CHKN_HISSCH`, `RCG_CHKN_CGCS`, " +
          "`RCG_CHKN_OMSKAFKA`, `RCG_CHKN_CMS`, `RCG_CHKN_OTHER`, `RCG_ARSS`, `FC_TC`, `FC_NORM`, " +
          "`FC_SCH`, `FC_TC2`, `FC_CHKE`, `FC_CHKN`, `FC_CHKN_HISSCH`, `FC_CHKN_CGCS`, `FC_CHKN_OMSKAFKA`, " +
          "`FC_CHKN_CMS`, `FC_CHKN_OTHER`, `FC_ARSS`, `FC_TOTAL`, `FC_PUSH`, `OVERTIME`,`RCG_DPNORM`,`RCG_DPTC2`," +
          "`RCG_DPCHKE`,`RCG_DPCHKN`,`RCG_CHKN_CGCSKDD`,`FC_DPNORM`,`FC_DPTC2`,`FC_DPCHKE`,`FC_DPCHKN`," +
          "`FC_CHKN_CGCSKDD`,`RCG_DPROAD`,`RCG_DPPHONE`,`FC_DPROAD`,`FC_DPPHONE`,`RCG_PHONE`,`FC_PHONE`," +
          "`KS_REQ`,`KS_RESP`,`KS_RESP_AOI`,`KS_RESP_TC`,`RCG_KS`) VALUES(?,?,?, ?, ?,?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?) " +
          "ON DUPLICATE KEY UPDATE `ORDER` = ?, `RCG_TC` = ?, `RCG_NORM` = ?, `RCG_SCH` = ?, " +
          "`RCG_TC2` = ?, `RCG_CHKE` = ?, `RCG_CHKN` = ?, `RCG_CHKN_HISSCH` = ?, `RCG_CHKN_CGCS` = ?, " +
          "`RCG_CHKN_OMSKAFKA` = ?, `RCG_CHKN_CMS` = ?, `RCG_CHKN_OTHER` = ?, `RCG_ARSS` = ?, `FC_TC` = ?, " +
          "`FC_NORM` = ?, `FC_SCH` = ?, `FC_TC2` = ?, `FC_CHKE` = ?, `FC_CHKN` = ?, " +
          "`FC_CHKN_HISSCH` = ?, `FC_CHKN_CGCS` = ?, `FC_CHKN_OMSKAFKA` = ?, `FC_CHKN_CMS` = ?, " +
          "`FC_CHKN_OTHER` = ?, `FC_ARSS` = ?, `FC_TOTAL` = ?, `FC_PUSH` = ?, `OVERTIME` = ?," +
          "`RCG_DPNORM`= ?,`RCG_DPTC2`= ?,`RCG_DPCHKE`= ?,`RCG_DPCHKN`= ?,`RCG_CHKN_CGCSKDD`= ?," +
          "`FC_DPNORM`= ?,`FC_DPTC2`= ?,`FC_DPCHKE`= ?,`FC_DPCHKN`= ?,`FC_CHKN_CGCSKDD`= ?," +
          "`RCG_DPROAD`= ?,`RCG_DPPHONE`= ?,`FC_DPROAD`= ?,`FC_DPPHONE`= ?,`RCG_PHONE`= ?,`FC_PHONE`= ?," +
          "`KS_REQ`= ?,`KS_RESP`= ?,`KS_RESP_AOI`= ?,`KS_RESP_TC`= ?, `RCG_KS`=?", omsPuTcTable))
      puTcRdd.collect().foreach(obj => {
        val params = Array(obj.getId, obj.getUnderCall, obj.getDataType, obj.getStatDate, obj.getProvince, obj.getRegion,
          obj.getCityCode, obj.getCity, obj.getSysSource,
          obj.getOrder, obj.getRcgTc, obj.getRcgNorm, obj.getRcgSch, obj.getRcgTc2, obj.getRcgChke, obj.getRcgChkn,
          obj.getRcgChknHisSch, obj.getRcgChknCgcs, obj.getRcgChknOmsKafka, obj.getRcgChknCms, obj.getRcgChknOther,
          obj.getRcgArss, obj.getFcTc, obj.getFcNorm, obj.getFcSch, obj.getFcTc2, obj.getFcChke, obj.getFcChkn,
          obj.getFcChknHisSch, obj.getFcChknCgcs, obj.getFcChknOmsKafka, obj.getFcChknCms, obj.getFcChknOther,
          obj.getFcArss, obj.getFcPush, obj.getFcTotal, obj.getOvertime, obj.getRcgDispatchNorm, obj.getRcgDispatchTc2,
          obj.getRcgDispatchChke, obj.getRcgDispatchChkn, obj.getRcgChknCgcsKdd, obj.getFcDispatchNorm, obj.getFcDispatchTc2,
          obj.getFcDispatchChke, obj.getFcDispatchChkn, obj.getFcChknCgcsKdd, obj.getRcgDispatchRoad, obj.getRcgDispatchPhone,
          obj.getFcDispatchRoad, obj.getFcDispatchPhone, obj.getRcgPhone, obj.getFcPhone,
          obj.getChkKsReq, obj.getChkKsRe, obj.getChkKsAoi, obj.getChkKsTc, obj.getChkKsGisTc,
          obj.getOrder, obj.getRcgTc, obj.getRcgNorm, obj.getRcgSch, obj.getRcgTc2, obj.getRcgChke, obj.getRcgChkn,
          obj.getRcgChknHisSch, obj.getRcgChknCgcs, obj.getRcgChknOmsKafka, obj.getRcgChknCms, obj.getRcgChknOther,
          obj.getRcgArss, obj.getFcTc, obj.getFcNorm, obj.getFcSch, obj.getFcTc2, obj.getFcChke, obj.getFcChkn,
          obj.getFcChknHisSch, obj.getFcChknCgcs, obj.getFcChknOmsKafka, obj.getFcChknCms, obj.getFcChknOther,
          obj.getFcArss, obj.getFcPush, obj.getFcTotal, obj.getOvertime, obj.getRcgDispatchNorm, obj.getRcgDispatchTc2,
          obj.getRcgDispatchChke, obj.getRcgDispatchChkn, obj.getRcgChknCgcsKdd, obj.getFcDispatchNorm, obj.getFcDispatchTc2,
          obj.getFcDispatchChke, obj.getFcDispatchChkn, obj.getFcChknCgcsKdd, obj.getRcgDispatchRoad, obj.getRcgDispatchPhone,
          obj.getFcDispatchRoad, obj.getFcDispatchPhone, obj.getRcgPhone, obj.getFcPhone,
          obj.getChkKsReq, obj.getChkKsRe, obj.getChkKsAoi, obj.getChkKsTc, obj.getChkKsGisTc)
        for (i <- params.indices)
          stmt.setObject(i + 1, params(i))
        try {
          stmt.executeUpdate()
        } catch {
          case e: Exception => e.printStackTrace()
        }
      })
      conn.close()
      //      save_omsputc_to_hive(spark, puTcRdd.repartition(1), incDayList)
    } catch {
      case e: Exception => logger.error("insert puTc error", e)
    }
  }

  /**
    * OMS收件TC统计
    *
    * @param puTcRdd : 数据rdd
    */
  def savePuTcZc(puTcRdd: RDD[OmsPuTc], spark: SparkSession, incDayList: util.ArrayList[String]): Unit = {
    logger.error(">>>save puTc zc.")
    val omsPuTcTable = ConfigurationUtil.loadProperties(VariableConstant.CONF).getProperty("mysql.table.oms_pu_tc_zc")
    try {
      val conn = ManagerFactory.createManager(classOf[RdsManager]).getConn
      val stmt = conn.prepareStatement(
        String.format("INSERT INTO %s(`ID`, `UNDER_CALL`, `DATA_TYPE`,  `STAT_DATE`, `PROVINCE`, `REGION`, `CITY_CODE`, `CITY`,`ZONE_CODE`, `ORDER`, " +
          "`RCG_TC`, `RCG_NORM`, `RCG_SCH`, `RCG_TC2`, `RCG_CHKE`, `RCG_CHKN`, `RCG_CHKN_HISSCH`, `RCG_CHKN_CGCS`, " +
          "`RCG_CHKN_OMSKAFKA`, `RCG_CHKN_CMS`, `RCG_CHKN_OTHER`, `RCG_ARSS`, `FC_TC`, `FC_NORM`, " +
          "`FC_SCH`, `FC_TC2`, `FC_CHKE`, `FC_CHKN`, `FC_CHKN_HISSCH`, `FC_CHKN_CGCS`, `FC_CHKN_OMSKAFKA`, " +
          "`FC_CHKN_CMS`, `FC_CHKN_OTHER`, `FC_ARSS`, `FC_TOTAL`, `FC_PUSH`, `OVERTIME`,`RCG_DPNORM`,`RCG_DPTC2`," +
          "`RCG_DPCHKE`,`RCG_DPCHKN`,`RCG_CHKN_CGCSKDD`,`FC_DPNORM`,`FC_DPTC2`,`FC_DPCHKE`,`FC_DPCHKN`," +
          "`FC_CHKN_CGCSKDD`,`RCG_DPROAD`,`RCG_DPPHONE`,`FC_DPROAD`,`FC_DPPHONE`,`RCG_PHONE`,`FC_PHONE`," +
          "`KS_REQ`,`KS_RESP`,`KS_RESP_AOI`,`KS_RESP_TC`,`RCG_KS`) VALUES(?,?,?, ?, ?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, " +
          "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?) " +
          "ON DUPLICATE KEY UPDATE `ORDER` = ?, `RCG_TC` = ?, `RCG_NORM` = ?, `RCG_SCH` = ?, " +
          "`RCG_TC2` = ?, `RCG_CHKE` = ?, `RCG_CHKN` = ?, `RCG_CHKN_HISSCH` = ?, `RCG_CHKN_CGCS` = ?, " +
          "`RCG_CHKN_OMSKAFKA` = ?, `RCG_CHKN_CMS` = ?, `RCG_CHKN_OTHER` = ?, `RCG_ARSS` = ?, `FC_TC` = ?, " +
          "`FC_NORM` = ?, `FC_SCH` = ?, `FC_TC2` = ?, `FC_CHKE` = ?, `FC_CHKN` = ?, " +
          "`FC_CHKN_HISSCH` = ?, `FC_CHKN_CGCS` = ?, `FC_CHKN_OMSKAFKA` = ?, `FC_CHKN_CMS` = ?, " +
          "`FC_CHKN_OTHER` = ?, `FC_ARSS` = ?, `FC_TOTAL` = ?, `FC_PUSH` = ?, `OVERTIME` = ?," +
          "`RCG_DPNORM`= ?,`RCG_DPTC2`= ?,`RCG_DPCHKE`= ?,`RCG_DPCHKN`= ?,`RCG_CHKN_CGCSKDD`= ?," +
          "`FC_DPNORM`= ?,`FC_DPTC2`= ?,`FC_DPCHKE`= ?,`FC_DPCHKN`= ?,`FC_CHKN_CGCSKDD`= ?," +
          "`RCG_DPROAD`= ?,`RCG_DPPHONE`= ?,`FC_DPROAD`= ?,`FC_DPPHONE`= ?,`RCG_PHONE`= ?,`FC_PHONE`= ?," +
          "`KS_REQ`= ?,`KS_RESP`= ?,`KS_RESP_AOI`= ?,`KS_RESP_TC`= ?, `RCG_KS`=?", omsPuTcTable))
      puTcRdd.collect().foreach(obj => {
        val params = Array(obj.getId, obj.getUnderCall, obj.getDataType, obj.getStatDate, obj.getProvince, obj.getRegion,
          obj.getCityCode, obj.getCity, obj.getZoneCode,
          obj.getOrder, obj.getRcgTc, obj.getRcgNorm, obj.getRcgSch, obj.getRcgTc2, obj.getRcgChke, obj.getRcgChkn,
          obj.getRcgChknHisSch, obj.getRcgChknCgcs, obj.getRcgChknOmsKafka, obj.getRcgChknCms, obj.getRcgChknOther,
          obj.getRcgArss, obj.getFcTc, obj.getFcNorm, obj.getFcSch, obj.getFcTc2, obj.getFcChke, obj.getFcChkn,
          obj.getFcChknHisSch, obj.getFcChknCgcs, obj.getFcChknOmsKafka, obj.getFcChknCms, obj.getFcChknOther,
          obj.getFcArss, obj.getFcPush, obj.getFcTotal, obj.getOvertime, obj.getRcgDispatchNorm, obj.getRcgDispatchTc2,
          obj.getRcgDispatchChke, obj.getRcgDispatchChkn, obj.getRcgChknCgcsKdd, obj.getFcDispatchNorm, obj.getFcDispatchTc2,
          obj.getFcDispatchChke, obj.getFcDispatchChkn, obj.getFcChknCgcsKdd, obj.getRcgDispatchRoad, obj.getRcgDispatchPhone,
          obj.getFcDispatchRoad, obj.getFcDispatchPhone, obj.getRcgPhone, obj.getFcPhone,
          obj.getChkKsReq, obj.getChkKsRe, obj.getChkKsAoi, obj.getChkKsTc, obj.getChkKsGisTc,
          obj.getOrder, obj.getRcgTc, obj.getRcgNorm, obj.getRcgSch, obj.getRcgTc2, obj.getRcgChke, obj.getRcgChkn,
          obj.getRcgChknHisSch, obj.getRcgChknCgcs, obj.getRcgChknOmsKafka, obj.getRcgChknCms, obj.getRcgChknOther,
          obj.getRcgArss, obj.getFcTc, obj.getFcNorm, obj.getFcSch, obj.getFcTc2, obj.getFcChke, obj.getFcChkn,
          obj.getFcChknHisSch, obj.getFcChknCgcs, obj.getFcChknOmsKafka, obj.getFcChknCms, obj.getFcChknOther,
          obj.getFcArss, obj.getFcPush, obj.getFcTotal, obj.getOvertime, obj.getRcgDispatchNorm, obj.getRcgDispatchTc2,
          obj.getRcgDispatchChke, obj.getRcgDispatchChkn, obj.getRcgChknCgcsKdd, obj.getFcDispatchNorm, obj.getFcDispatchTc2,
          obj.getFcDispatchChke, obj.getFcDispatchChkn, obj.getFcChknCgcsKdd, obj.getRcgDispatchRoad, obj.getRcgDispatchPhone,
          obj.getFcDispatchRoad, obj.getFcDispatchPhone, obj.getRcgPhone, obj.getFcPhone,
          obj.getChkKsReq, obj.getChkKsRe, obj.getChkKsAoi, obj.getChkKsTc, obj.getChkKsGisTc)
        for (i <- params.indices)
          stmt.setObject(i + 1, params(i))
        try {
          stmt.executeUpdate()
        } catch {
          case e: Exception => e.printStackTrace()
        }
      })
      conn.close()
    } catch {
      case e: Exception => logger.error("insert puTcZc error", e)
    }
  }

  /**
    * 保存指标结果到hive库
    *
    * @param spark   : spark session
    * @param puTcRdd : 指标结果rdd
    */
  def save_omsputc_to_hive(spark: SparkSession, puTcRdd: RDD[OmsPuTc], incDay: String): Unit = {
    logger.error(">>>omsputc指标入hive库开始！")
    val tmp_table_name = "tmp_oms_pu_tc"
    val oms_pu_tc_hive_table = "dm_gis.oms_pu_tc"
    spark.createDataFrame(puTcRdd, classOf[OmsPuTc]).createOrReplaceTempView(tmp_table_name)
//    for (day <- incDayList) {
      val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", oms_pu_tc_hive_table, incDay)
      logger.error(">>>omsputc指标入hive库:删除已有的数据-" + deleteSql)
      spark.sql(deleteSql)
      val insertsql = String.format("insert into %s partition(inc_day = '%s') select province,region,city,cityCode,cast(`order` as string) `order` from %s", oms_pu_tc_hive_table, incDay, tmp_table_name)
      logger.error(">>>omsputc指标入hive库:入新数据-" + insertsql)
      spark.sql(insertsql)
//    }

    logger.error(">>>omsputc指标入hive库结束！")
  }


  def getAdminArea(obj: OrderData, adminAreaMap: util.Map[String, util.List[AdminArea]]): AdminArea = {
    //    var cityTuple : (String, String, String, String) = null
    //    if(obj.getCityCode != null && !"".equals(obj.getCityCode))
    //      cityTuple = (obj.getCityCode, obj.getProvince, obj.getCity, obj.getAddress)
    //    else if(obj.getErrCallResno != null  && !"".equals(obj.getErrCallResno))
    //      cityTuple = (obj.getErrCallResno, obj.getErrCallProvince, obj.getErrCallCity, obj.getErrCallAddrabb)
    //    getAdminArea(adminAreaMap, cityTuple)
    getAdminAreaNew(adminAreaMap, obj)
  }

  /**
    * 获取大区等信息
    *
    * @param adminAreaMap :
    * @param obj          :
    * @return
    */
  def getAdminAreaNew(adminAreaMap: util.Map[String, util.List[AdminArea]], obj: OrderData): AdminArea = {
    var adminArea: AdminArea = null
    if (!obj.getCityCode.isEmpty && adminAreaMap.containsKey(obj.getCityCode)) {
      val adminAreaList = adminAreaMap.get(obj.getCityCode)
      if (adminAreaList.size() == 1) {
        adminArea = adminAreaList.get(0)
      } else {
        for (area: AdminArea <- adminAreaList) {
          if (!obj.getCity.isEmpty && area.getCity.contains(obj.getCity)) {
            adminArea = area
          } else if (!obj.getErrCallCity.isEmpty && area.getCity.contains(obj.getErrCallCity)) {
            adminArea = area
          } else if (!obj.getAddress.isEmpty && obj.getAddress.contains(area.getCity)) {
            adminArea = area
          } else if (!obj.getErrCallAddrabb.isEmpty && obj.getErrCallAddrabb.contains(area.getCity)) {
            adminArea = area
          }
        }
      }
    } else if (!obj.getErrCallResno.isEmpty && adminAreaMap.containsKey(obj.getErrCallResno)) {
      val adminAreaList = adminAreaMap.get(obj.getErrCallResno)
      if (adminAreaList.size() == 1) {
        adminArea = adminAreaList.get(0)
      } else {
        for (area: AdminArea <- adminAreaList) {
          if (!obj.getCity.isEmpty && area.getCity.contains(obj.getCity)) {
            adminArea = area
          } else if (!obj.getErrCallCity.isEmpty && area.getCity.contains(obj.getErrCallCity)) {
            adminArea = area
          } else if (!obj.getAddress.isEmpty && obj.getAddress.contains(area.getCity)) {
            adminArea = area
          } else if (!obj.getErrCallAddrabb.isEmpty && obj.getErrCallAddrabb.contains(area.getCity)) {
            adminArea = area
          }
        }
      }
    }
    if (adminArea == null) {
      adminArea = new AdminArea
      adminArea.setCityCode(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setRegion(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setProvince(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setCity(VariableConstant.DEFAULT_VALUE_STRING)
    }
    adminArea
  }

  def getAdminArea(adminAreaMap: util.Map[String, util.List[AdminArea]], cityTuple: (String, String, String, String)): AdminArea = {
    var adminArea: AdminArea = null
    if (cityTuple != null && adminAreaMap.containsKey(cityTuple._1)) {
      val adminAreaList = adminAreaMap.get(cityTuple._1)
      if (adminAreaList.size() == 1) {
        adminArea = adminAreaList.get(0)
      } else {
        for (area: AdminArea <- adminAreaList) {
          if (area.getCity.contains(cityTuple._3) || cityTuple._4.contains(area.getCity))
            adminArea = area
        }
      }
    } else if (cityTuple != null) {
      adminArea = new AdminArea
      adminArea.setCityCode(cityTuple._1)
      adminArea.setRegion(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setProvince(cityTuple._2)
      adminArea.setCity(cityTuple._3)
    }
    if (adminArea == null) {
      adminArea = new AdminArea
      adminArea.setCityCode(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setRegion(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setProvince(VariableConstant.DEFAULT_VALUE_STRING)
      adminArea.setCity(VariableConstant.DEFAULT_VALUE_STRING)
    }
    adminArea
  }
}
