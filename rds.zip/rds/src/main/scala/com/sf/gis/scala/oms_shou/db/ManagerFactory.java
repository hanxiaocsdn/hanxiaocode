package com.sf.gis.scala.oms_shou.db;

import com.sf.gis.scala.oms_shou.constant.VariableConstant;
import scala.reflect.internal.Variances;

import java.sql.Connection;
import java.sql.Statement;

/**
 * Created by 01368078 on 2018/8/18.
 */
public class ManagerFactory {
    public static IManager createManager(Class<? extends  IManager> clazz){
        if(clazz.equals(RdsManager.class)){
            return RdsManager.getInstance(VariableConstant.MYSQL_RDS_CONF);
        }else if(clazz.equals(AosManager.class)){
            return AosManager.getInstance(VariableConstant.MYSQL_AOS_CONF);
        }else if(clazz.equals(PrManager.class)){
            return PrManager.getInstance(VariableConstant.MYSQL_PR_CONF);
        }
        else {
            return null;
        }
    }

    public static void main(String[] args) {
        try(Connection conn = ManagerFactory.createManager(RdsManager.class).getConn()){
            Statement statement = conn.createStatement();
            statement.execute("select * from ADMIN_AREA");

        }catch (Exception e){

        }
    }
}
