package com.sf.gis.scala.utils

import com.sf.gis.scala.base.util.StringUtils

/**
 * Created by 01375125 on 2019/10/20.
 */
object TcUtils {


  /**
   * 校验单元区域格式是否匹配
   *
   * @param tc
   * @return
   */
  def matchTc(tc: String): Boolean = {
    tc != null && tc.matches("^[0-9]+[A-Za-z]+[0-9]+$")
  }

  /**
   * 校验网点格式是否匹配
   *
   * @param zc
   * @return
   */
  def matchZc(zc: String): Boolean = {
    zc != null && zc.matches("^[0-9]+[A-Za-z]+$")
  }

  /**
   * 通过tc截取zc
   *
   * @param tc
   */
  def getZcBySplitTc(tc: String) = {
    var sub_zc: String = null
    if (tc != null && matchZc(tc)) sub_zc = StringUtils.pickGroup0Str(tc, "[0-9]+[a-zA-Z]+")
    sub_zc
  }

  def main(args: Array[String]): Unit = {
    val zc = "755agaFSG"
    val b = matchZc(zc)
    println(b)
  }

}
