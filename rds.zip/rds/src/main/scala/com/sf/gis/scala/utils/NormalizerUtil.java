package com.sf.gis.scala.utils;

import com.sf.gis.java.base.util.MD5Util;
//import com.sf.norm.*;
import org.apache.log4j.Logger;


public class NormalizerUtil {
    /*private static Logger logger = Logger.getLogger(NormalizerUtil.class);
    private static NormalizerClient normalizerClient = null;
    private static void initClient() throws NormInitException {
        synchronized (NormalizerUtil.class){
            if(normalizerClient == null){
                 normalizerClient = new NormalizerClient("min");
            }
        }
    }
    public static NormRet doNormal(int adcode, int cityCode, String address) {
        try {
            AdData adData = new AdData();
            adData.setAdCode(adcode);
            adData.setCityCode(cityCode);
            if(normalizerClient == null)
                initClient();
            return normalizerClient.GoNorm(address, adData,
                    new OptData("UTF-8", 1, 1));
        } catch (Exception e) {
            logger.error(e);
            return null;
        }
    }

    public static void main(String[] args) {
        String str = " 深圳市宝安区西乡街道腾联路精工坊306号|———深圳市龙岗区龙东社区吓井一村富源源街7-8号|上海上海市金山区上海市福田区新洲六街中城天邑3座2单元16B|中国 广东省 深圳市 福田区 香蜜湖街道侨香四道 环境检测大厦 410室|九围锦驰第四科技园B栋7楼|南山街道兴海大道月亮湾填海区公交总站到了打电话|园岭街道八卦岭八卦七街宿舍区6栋406|坑梓街道人民路40号名仁洗发店|坪山东胜路65号首层2号，自在时光|坪山新区青兰二路北金威源科技|坪山街道田心社区金田路408号坪山医院田心社区健康服务中心|广东 深圳市 坪山新区 坑梓沙田秀沙路林盛再生资源公司";
        for(String s : str.split("\\|")){
            NormRet normRet =  doNormal(440300, 755, s);
            //noinspection ConstantConditions
            System.out.println(MD5Util.getMD5(normRet.getAddress()));
        }
    }*/

}
