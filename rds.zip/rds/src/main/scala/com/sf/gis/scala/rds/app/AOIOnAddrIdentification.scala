package com.sf.gis.scala.rds.app

import java.io.InputStreamReader

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.api.AddrApi
import com.sf.gis.java.base.dto.StandardAddrInfo
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.rds.util.Util
import org.apache.commons.csv.CSVFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * KS11-基于地址的AOI识别
 * Created by 01417629 on 2021-11-11
 * 任务id:128
 */
//noinspection DuplicatedCode
object AOIOnAddrIdentification {
  @transient lazy val logger: Logger = Logger.getLogger(AOIOnAddrIdentification.getClass)

  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {

    val spark = Spark.getSparkSession(appName)

    val parDay_2 = args(0) //t-3分区
    val flag = args(1)

    run(spark,  parDay_2, flag)
    spark.close()
  }

  def run(spark: SparkSession, parDay_2: String, flag: String): Unit = {
    println(parDay_2 + "-->" + flag)
    //删除parDay_2分区已有标准化地址数据
    //delHiveStandardAddr(spark,parDay_2)

    //获取城市编码表
    val cityMap = getCityMap(flag)
    val iter = cityMap.iterator

    while (iter.hasNext) {
      val city = iter.next()
      val city_code = city._1

      //获取运单数据
      val waybillInfo = getWaybillInfo(spark, parDay_2, city_code)

      if (waybillInfo.count() > 0) {
        //运单数据和城市编码表关联
        val multiRDD = doMultiMapJoin(waybillInfo, cityMap)

        //调取地址标准化接口
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "128", "标准地址_KS11基于地址的AOI识别_V1.0", "标准地址_KS11基于地址的AOI识别", "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api/normal", "31fe971c96804943867610368e2a7a1c", multiRDD.count(), 200)
        val standardAddr = getStandardAddr(multiRDD)
        BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)

        //写入Hive表
        saveResult2Hive(spark, standardAddr, parDay_2)

        standardAddr.unpersist()
      }

      spark.catalog.clearCache()


    }


  }


  def delHiveStandardAddr(spark: SparkSession, parDay_2: String): Unit = {
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "tt_waybill_add_standard_addr"

    //删除分区数据
    val delSQL =
      s"""
         |ALTER TABLE $descDBName.$descTableName DROP IF EXISTS PARTITION (inc_day = '$parDay_2')
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>删除分区sql: " + delSQL)

    spark.sql(delSQL)

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>成功删除分区数据")
  }

  /**
   * 获取运单数据
   *
   * @param spark
   * @param parDay_2
   * @return
   */
  def getWaybillInfo(spark: SparkSession, parDay_2: String, city_code: String): RDD[JSONObject] = {
    val sql =
      s"""
         |SELECT
         |	 waybill_id
         |	,waybill_status
         |	,waybill_no
         |	,dest_city_code
         |	,consignee_addr
         |	,consignee_mobile
         |	,delivery_xy_aoiid
         |	,delivery_xy_dept
         |	,delivery_lgt
         |	,delivery_lat
         |  ,inc_day
         |FROM dm_gis.tt_waybill_hook
         |WHERE inc_day = '$parDay_2'
         |AND dest_city_code = '$city_code'
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: " + sql)

    val waybillInfo = Util.getRowToJson(spark, sql, 400)

    logger.error(s">>>获取运单信息共 ${waybillInfo.count()} 条s<<<")

    waybillInfo
  }


  /**
   * 获取城市编码
   *
   * @return
   */
  def getCityMap1() = {
    val in = new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream("cityName.csv"), "UTF-8")
    val records = CSVFormat.DEFAULT.withHeader().withSkipHeaderRecord().parse(in).iterator()
    var csvMap: Map[String, String] = Map()

    while (records.hasNext) {
      val elem = records.next()
      csvMap += (elem.get("CITY_CODE") -> elem.get("DIST_CODE"))
    }

    logger.error(s">>>获取城市编码映射共：${csvMap.size}<<<")

    csvMap
  }


  /**
   * 获取城市编码
   *
   * @return
   */
  def getCityMap(flag: String) = {
    var name = ""
    if (flag == "10") {
      name = "conf/ks_2_redis/cityName10.csv"
    } else if (flag == "11") {
      name = "conf/ks_2_redis/cityName11.csv"
    } else if (flag == "20") {
      name = "conf/ks_2_redis/cityName20.csv"
    } else if (flag == "21") {
      name = "conf/ks_2_redis/cityName21.csv"
    } else if (flag == "30") {
      name = "conf/ks_2_redis/cityName30.csv"
    } else if (flag == "31") {
      name = "conf/ks_2_redis/cityName31.csv"
    } else if (flag == "40") {
      name = "conf/ks_2_redis/cityName40.csv"
    } else {
      name = "conf/ks_2_redis/cityName41.csv"
    }

    val in = new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream(name), "UTF-8")
    val records = CSVFormat.DEFAULT.withHeader().withSkipHeaderRecord().parse(in).iterator()
    var csvMap: Map[String, String] = Map()

    while (records.hasNext) {
      val elem = records.next()
      csvMap += (elem.get("CITY_CODE") -> elem.get("DIST_CODE"))
    }

    logger.error(s">>>获取城市编码映射共：${csvMap.size}<<<")

    csvMap
  }


  /**
   * 运单数据和城市编码表关联
   *
   * @param waybillInfo
   * @param cityMap
   * @return
   */
  def doMultiMapJoin(waybillInfo: RDD[JSONObject], cityMap: Map[String, String]): RDD[(JSONObject, JSONObject)] = {
    val multiRDD = waybillInfo.map(obj => {
      val jsonObject = new JSONObject()

      val dest_city_code = obj.getString("dest_city_code")

      val cityCode = cityMap.getOrElse(dest_city_code, "")

      jsonObject.put("cityCode", cityCode)

      (obj, jsonObject)

    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>多维度关联后：${multiRDD.count()}<<<")

    waybillInfo.unpersist()

    multiRDD
  }


  /**
   * 调取地址标准化接口
   *
   * @param multiRDD
   * @return
   */
  def getStandardAddr(multiRDD: RDD[(JSONObject, JSONObject)]): RDD[((JSONObject, JSONObject), StandardAddrInfo)] = {
    val standardAddr = multiRDD.map(obj => {
      val consignee_addr = obj._1.getString("consignee_addr")
      val cityCode = obj._2.getString("cityCode")

      var addrInfo: StandardAddrInfo = null

      addrInfo = AddrApi.atdispatchNormal("31fe971c96804943867610368e2a7a1c", "normdetail", cityCode, consignee_addr)


      (obj, addrInfo)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取运单标准地址共 ${standardAddr.count()} 条s<<<")

    multiRDD.unpersist()

    standardAddr
  }


  /**
   * 写入Hive表
   *
   * @param spark
   * @param standardAddr
   */
  def saveResult2Hive(spark: SparkSession, standardAddr: RDD[((JSONObject, JSONObject), StandardAddrInfo)], parDay_2: String): Unit = {
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "tt_waybill_add_standard_addr"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT INTO TABLE $descDBName.$descTableName PARTITION (inc_day = '$parDay_2')
         |SELECT
         |  waybill_id
         | ,waybill_status
         | ,waybill_no
         | ,dest_city_code
         | ,consignee_addr
         | ,consignee_mobile
         | ,delivery_xy_aoiid
         | ,delivery_xy_dept
         | ,delivery_lgt
         | ,delivery_lat
         | ,address
         | ,result
         | ,citycode
         |FROM tt_waybill_hook_temp
         |""".stripMargin

    try {
      val schemaString = "citycode,inc_day,waybill_id,waybill_status,waybill_no,dest_city_code" +
        ",consignee_addr,consignee_mobile,delivery_xy_aoiid,delivery_xy_dept" +
        ",delivery_lgt,delivery_lat,address,result"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
      )
      val schema = StructType(fields)

      val rdd = standardAddr.coalesce(20).map(obj => {
        val row = obj._1._1
        val json = obj._1._2
        val addressInfo = obj._2

        val sb = new StringBuilder()
        sb.append(json.getString("cityCode")).append("\t\t\t")
        sb.append(row.getString("inc_day")).append("\t\t\t")
        sb.append(row.getString("waybill_id")).append("\t\t\t")
        sb.append(row.getString("waybill_status")).append("\t\t\t")
        sb.append(row.getString("waybill_no")).append("\t\t\t")
        sb.append(row.getString("dest_city_code")).append("\t\t\t")
        sb.append(row.getString("consignee_addr")).append("\t\t\t")
        sb.append(row.getString("consignee_mobile")).append("\t\t\t")
        sb.append(row.getString("delivery_xy_aoiid")).append("\t\t\t")
        sb.append(row.getString("delivery_xy_dept")).append("\t\t\t")
        sb.append(row.getString("delivery_lgt")).append("\t\t\t")
        sb.append(row.getString("delivery_lat")).append("\t\t\t")
        sb.append(addressInfo.getStandardAddr).append("\t\t\t")
        sb.append(addressInfo.getResult).append("\t\t\t")


        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4)
        , attr(5), attr(6), attr(7), attr(8), attr(9), attr(10), attr(11), attr(12), attr(13)))

      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.createOrReplaceTempView("tt_waybill_hook_temp")
      df.show(5)

      //插入数据
      logger.error(">>>>>>>>>>入hive库开始")
      val resultDF = spark.sql(insertSQL)
      resultDF.show(5)
      logger.error(">>>>>>>>>>入hive库结束")

      spark.sql("drop table if exists tt_waybill_hook_temp")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>删除临时表: tt_waybill_hook_temp")

      standardAddr.unpersist()
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }


}
