package com.sf.gis.scala.oms_shou.constant

/**
  * Created by 01368078 on 2019/1/8.
  */
object AppType {
  val REALTIME_TYPE = 0
}
