package com.sf.gis.scala.oms_shou.db;

import java.sql.Connection;

/**
 * Created by 01368078 on 2018/8/18.
 */
public interface IManager {
    public Connection getConn();
}
