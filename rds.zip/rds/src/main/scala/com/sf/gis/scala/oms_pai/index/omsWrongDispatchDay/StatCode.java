package com.sf.gis.scala.oms_pai.index.omsWrongDispatchDay;

/**
 * Created by 01375125 on 2018/12/29.
 * 状态码
 */
@SuppressWarnings("unused")
public class StatCode {
    public final static String DLV_VALUE = "dlv";
}
