package com.sf.gis.scala.oms_shou.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.Serializable;

/**
 * OMS收件TC错call统计
 * Created by 01368078 on 2019/1/6.
 */
@Entity
public class OmsPuFc implements Serializable{
    @Column(name = "ID")
    private String id;
    @Column(name = "STAT_DATE")
    private String statDate;    //数据日期
    @Column(name = "PROVINCE")
    private String province;    //省
    @Column(name = "REGION")
    private String region;  //大区
    @Column(name = "CITY_CODE")
    private String cityCode;    //城市代码
    @Column(name = "CITY")
    private String city;    //城市
    @Column(name = "ORDER")
    private int order; //下单量
    @Column(name = "TC")
    private int tc; //GIS自动识别错call量（=TC_NORM+TC_SCH+TC_TC2+TC_CHKE+TC_CHKN）
    @Column(name = "TC_NORM")
    private int tcNorm;   //GIS自动识别量中来自NORM的错call量
    @Column(name = "TC_SCH")
    private int tcSch;   //GIS自动识别量中来自SCH的错call量
    @Column(name = "TC_TC2")
    private int tcTc2; //GIS自动识别量中来自TC2的错call量
    @Column(name = "TC_CHKE")
    private int tcChke; //GIS自动识别量中来自CHKE的错call量
    @Column(name = "TC_CHKN")
    private int tcChkn; //GIS自动识别量中来自CHKN的错call量（=TC_CHKN_HISSCH+TC_CHKN_CGCS+TC_CHKN_OMSKAFKA+TC_CHKN_CMS+TC_CHKN_OTHER）
    @Column(name = "TC_CHKN_HISSCH")
    private int tcChknHisSch; //GIS自动识别量中CHKN错call中来自HIS_SCH的量
    @Column(name = "TC_CHKN_CGCS")
    private int tcChknCgcs; //GIS自动识别量中CHKN错call中来自CGCS的量
    @Column(name = "TC_CHKN_OMSKAFKA")
    private int tcChknOmsKafka; //GIS自动识别量中CHKN错call中来自OMS_KAFKA的量
    @Column(name = "TC_CHKN_CMS")
    private int tcChknCms; //GIS自动识别量中CHKN错call中来自CMS的量
    @Column(name = "TC_CHKN_OTHER")
    private int tcChknOther; //GIS自动识别量中CHKN错call中来自其它源的量
    @Column(name = "TC_ARSS")
    private int tcArss; //人工审补错call量
    @Column(name = "TC_TOTAL")
    private int tcTotal; //总错call量（TC+TC_ARSS）
    @Column(name = "TC_PUSH")
    private int tcPush; //每天推送的错call量

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getTc() {
        return tc;
    }

    public void setTc(int tc) {
        this.tc = tc;
    }

    public int getTcNorm() {
        return tcNorm;
    }

    public void setTcNorm(int tcNorm) {
        this.tcNorm = tcNorm;
    }

    public int getTcSch() {
        return tcSch;
    }

    public void setTcSch(int tcSch) {
        this.tcSch = tcSch;
    }

    public int getTcTc2() {
        return tcTc2;
    }

    public void setTcTc2(int tcTc2) {
        this.tcTc2 = tcTc2;
    }

    public int getTcChke() {
        return tcChke;
    }

    public void setTcChke(int tcChke) {
        this.tcChke = tcChke;
    }

    public int getTcChkn() {
        return tcChkn;
    }

    public void setTcChkn(int tcChkn) {
        this.tcChkn = tcChkn;
    }

    public int getTcChknHisSch() {
        return tcChknHisSch;
    }

    public void setTcChknHisSch(int tcChknHisSch) {
        this.tcChknHisSch = tcChknHisSch;
    }

    public int getTcChknCgcs() {
        return tcChknCgcs;
    }

    public void setTcChknCgcs(int tcChknCgcs) {
        this.tcChknCgcs = tcChknCgcs;
    }

    public int getTcChknOmsKafka() {
        return tcChknOmsKafka;
    }

    public void setTcChknOmsKafka(int tcChknOmsKafka) {
        this.tcChknOmsKafka = tcChknOmsKafka;
    }

    public int getTcChknCms() {
        return tcChknCms;
    }

    public void setTcChknCms(int tcChknCms) {
        this.tcChknCms = tcChknCms;
    }

    public int getTcChknOther() {
        return tcChknOther;
    }

    public void setTcChknOther(int tcChknOther) {
        this.tcChknOther = tcChknOther;
    }

    public int getTcArss() {
        return tcArss;
    }

    public void setTcArss(int tcArss) {
        this.tcArss = tcArss;
    }

    public int getTcTotal() {
        return tcTotal;
    }

    public void setTcTotal(int tcTotal) {
        this.tcTotal = tcTotal;
    }

    public int getTcPush() {
        return tcPush;
    }

    public void setTcPush(int tcPush) {
        this.tcPush = tcPush;
    }

    public void merge(OmsPuFc obj){
        this.order += obj.getOrder();
        this.tc += obj.getTc();
        this.tcNorm += obj.getTcNorm();
        this.tcSch += obj.getTcSch();
        this.tcTc2 += obj.getTcTc2();
        this.tcChke += obj.getTcChke();
        this.tcChkn += obj.getTcChkn();
        this.tcChknHisSch += obj.getTcChknHisSch();
        this.tcChknCgcs += obj.getTcChknCgcs();
        this.tcChknOmsKafka += obj.getTcChknOmsKafka();
        this.tcChknCms += obj.getTcChknCms();
        this.tcChknOther += obj.getTcChknOther();
        this.tcArss += obj.getTcArss();
        this.tcTotal += obj.getTcTotal();
        this.tcPush += obj.getTcPush();
    }
}
