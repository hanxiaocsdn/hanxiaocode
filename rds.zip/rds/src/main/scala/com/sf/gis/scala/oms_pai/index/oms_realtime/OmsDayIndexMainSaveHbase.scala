package com.sf.gis.scala.oms_pai.index.oms_realtime

import java.util

import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.oms_pai.start.JavaUtil
import org.apache.hadoop.hbase.client.{ConnectionFactory, HTable, Put, Table}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.Random

/**
 * @ProductManager:01369702
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:408469，408475，113
 * @TaskName:rds派件指标入hbase
 * @Description:将rds派件日志解析数据入到hbase
 */
object OmsDayIndexMainSaveHbase {

  /*val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  val javaUtil = new JavaUtil(6)

  /**
   * main方法
   *
   * @param args : 参数
   */
  def main(args: Array[String]): Unit = {

    val incDay = args(0)

    start(incDay)
  }

  def test(): Unit = {

  }

  /**
   * 开始任务
   */
  def start(incDay: String): Unit = {
    val spark = Spark.getSparkSession(appName)
    singleTask(spark, incDay)
    //    spark.stop()
  }

  /**
   * @param appName : spark任务名
   * @return
   */
  def getConf(appName: String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
      .set("spark.port.maxRetries", "100")
      .set("spark.driver.maxResultSize", "12g")
      .set("spark.rpc.io.backLog", "10000")
      .set("spark.cleaner.referenceTracking.blocking", "false")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.driver.allowMultipleContexts", "true")
      .set("spark.sql.tungsten.enabled", "false")
      .set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
      .set("quota.consumer.default", (10485760 * 2).toString)
      .set("cache.max.bytes.buffering", (20485760 * 2).toString)
      .set("spark.sql.broadcastTimeout", "36000")
      .set("spark.network.timeout", "6000")
      .set("spark.executor.heartbeatInterval", "30000")
      .set("hive.exec.dynamic.partition", "true")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
    //    if(taskCode == 0){
    //      println("excutors:40")
    //      conf.set("spark.executor.instances","40")
    //    }else{
    //      println("excutors:50")
    //          conf.set("spark.executor.instances","60")
    //          conf.set("spark.executor.memory","30g")
    //          conf.set("spark.yarn.executor.memoryOverhead","10g")
    //    }
    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
    conf.set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:+UseCompressedOops")

    conf
  }

  /**
   * 单个任务
   *
   * @param spark : spark session
   */
  def singleTask(spark: SparkSession, incDay: String): Unit = {
    //取两天数据防止跨天结果返回(人工审补)和跨天打日志
    handleTask(spark, incDay)
  }

  def queryFromHbaseTable(spark: SparkSession, incDay: String) = {

    val sql = s"select data,hashkey from dm_gis.gis_rds_omsto_hbase where inc_day='$incDay'"
    logger.error(sql)
    val dataRow = spark.sql(sql).persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error("数据量：" + dataRow.count())
    dataRow
  }

  /**
   * 处理任务
   */
  def handleTask(spark: SparkSession, incDay: String): Unit = {
    val dataRow = queryFromHbaseTable(spark, incDay)
    logger.error(">>>解析数据入hbase库-----------")
    saveHbase(dataRow)
    logger.error(">>>完毕-----------")
  }

  /**
   * oms解析数据入hbase库
   *
   * @param omsRdd : 数据rdd
   */
  def saveHbase(omsRdd: DataFrame): Unit = {
    omsRdd.rdd.map(obj=>{
      (Random.nextInt(50),obj)
    }).repartition(50).values.foreachPartition(rdd => {
      val table = getTable(javaUtil.get("hbase.gis.oms.table"))
      val putList = new util.ArrayList[Put]()
      rdd.foreach(obj => {
        val put = new Put(Bytes.toBytes(obj.getString(1)))
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("oms_value"), Bytes.toBytes(obj.getString(0)))
        putList.add(put)
        if(putList.size()>=500){
          try {
            table.put(putList)
          } catch {
            case e: Exception => logger.error(e)
          }
          putList.clear()
        }
      })
      if(putList.size()>0){
        try {
          table.put(putList)
        } catch {
          case e: Exception => logger.error(e)
        }
        putList.clear()
      }
      table.close()
    })
  }

  def getTable(tableName: String): Table = {
    val hbaseConf = HBaseConfiguration.create()
    //设置写入的表
    hbaseConf.set("zookeeper.znode.parent", javaUtil.get("zookeeper.znode.parent"))
    //cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545
    hbaseConf.set("hbase.zookeeper.quorum", javaUtil.get("hbase.zookeeper.quorum"))
//    hbaseConf.set("hbase.zookeeper.quorum", "10.117.105.36,10.117.105.37,10.117.105.38,10.117.105.39,10.117.105.40")
    hbaseConf.set("hbase.zookeeper.property.clientPort", javaUtil.get("hbase.zookeeper.property.clientPort"))

    //    hbaseConf.set("hbase.client.keyvalue.maxsize","524288000");
    //noinspection ScalaDeprecation
    val connection = ConnectionFactory.createConnection(hbaseConf)
    val table = connection.getTable(TableName.valueOf(tableName))

//    table.setAutoFlush(false, false)
    //    table.setWriteBufferSize(1 * 1024)
//    table.setWriteBufferSize(512)
//    table.
    table
  }*/

}
