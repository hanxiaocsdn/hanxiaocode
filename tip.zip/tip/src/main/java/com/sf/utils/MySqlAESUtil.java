package com.sf.utils;


import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.Serializable;

/**
 * java使用AES加密解密 AES-128-ECB加密 与mysql数据库aes加密算法通用 数据库aes加密解密 -- 加密 SELECT
 * to_base64(AES_ENCRYPT('www.gowhere.so','jkl;POIU1234++==')); -- 解密 SELECT
 * AES_DECRYPT(from_base64('Oa1NPBSarXrPH8wqSRhh3g=='),'jkl;POIU1234++==');
 *
 * @author orion
 *
 */

public class MySqlAESUtil implements Serializable {

	public static final String key = "jkl;POIU1234++==";
	// 加密
	public static String Encrypt(String sSrc, String sKey) throws Exception {
		if (sKey == null) {
			return null;
		}
		// 判断Key是否为16位
		if (sKey.length() != 16) {

			return null;
		}
		byte[] raw = sKey.getBytes("utf-8");
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");// "算法/模式/补码方式"
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));
		return new BASE64Encoder().encode(encrypted);// 此处使用BASE64做转码功能，同时能起到2次加密的作用。
	}

	// 解密
	public static String Decrypt(String sSrc, String sKey) {
		try {
			// 判断Key是否正确
			if (sKey == null) {

				return null;
			}
			// 判断Key是否为16位
			if (sKey.length() != 16) {
				return null;
			}
			byte[] raw = sKey.getBytes("utf-8");
			SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec);
			byte[] encrypted1 = new BASE64Decoder().decodeBuffer(sSrc);// 先用base64解密
			try {
				byte[] original = cipher.doFinal(encrypted1);
				String originalString = new String(original, "utf-8");
				return originalString;
			}
			catch (Exception e) {
				return sSrc;
			}
		}
		catch (Exception ex) {
			return sSrc;
		}
	}

	public static void main(String[] args) throws Exception {
		/*
		 * 此处使用AES-128-ECB加密模式，key需要为16位。
		 */
		/*
		 * String cKey = "rSo@PO=I+U1494+="; // 需要加密的字串 String cSrc = "www.gowhere.so";
		 * System.out.println(cSrc); // 加密 String enString = Encrypt(cSrc, cKey);
		 * System.out.println("加密后的字串是：" + enString);
		 *
		 * // 解密 String DeString = Decrypt(enString, cKey); System.out.println("解密后的字串是："
		 * + DeString);
		 */
		System.out.println(Decrypt("caNeMjfv9U2fP05ta3+uqw==", "jkl;POIU1234++=="));

	}

}
