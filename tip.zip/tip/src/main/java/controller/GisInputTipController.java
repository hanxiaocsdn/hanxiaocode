//package controller;
//
//import com.sf.gis.java.base.dto.SparkInfo;
//import com.sf.gis.java.base.util.SparkUtil;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.spark.api.java.JavaPairRDD;
//import org.apache.spark.api.java.JavaRDD;
//import org.apache.spark.api.java.JavaSparkContext;
//import org.apache.spark.sql.SparkSession;
//import org.apache.spark.storage.StorageLevel;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import pojo.GisInputtipMroservice;
//import pojo.TtWaybillInfo;
//import scala.Tuple2;
//import service.GisInputTipService;
//
//public class GisInputTipController {
//    private static final Logger logger = LoggerFactory.getLogger(GisInputTipController.class);
//    GisInputTipService service = new GisInputTipService();
//
//    public void process(String date) {
//        logger.error("process start. ");
//        // 初始化spark
//        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
//        JavaSparkContext sc = sparkInfo.getContext();
//        SparkSession spark = sparkInfo.getSession();
//
//        JavaRDD<GisInputtipMroservice> gisInputtipMroserviceRdd = service.loadData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("gisInputtipMroserviceRdd cnt:{}", gisInputtipMroserviceRdd.count());
//
//        JavaRDD<GisInputtipMroservice> userChoiceRdd = gisInputtipMroserviceRdd.filter(o -> StringUtils.equals(o.getClick(), "1")).map(o -> {
//            o.setUser_choice(o.getQ());
//            o.setUser_choice_uid(o.getGroupid());
//
//            o.setNew_gid(o.getGid());
//            o.setNew_sys_order_no(o.getSys_order_no());
//            o.setNew_sver(o.getSver());
//            o.setNew_iver(o.getIver());
//            o.setNew_sn(o.getSn());
//            o.setNew_url(o.getUrl());
//
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("userChoiceRdd cnt:{}", userChoiceRdd.count());
//
//        JavaPairRDD<String, GisInputtipMroservice> snGisInputtipMroserviceRdd = gisInputtipMroserviceRdd.filter(o -> StringUtils.isNotEmpty(o.getSn())).mapToPair(o -> new Tuple2<>(o.getSn(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("snGisInputtipMroserviceRdd cnt:{}", snGisInputtipMroserviceRdd.count());
//        gisInputtipMroserviceRdd.unpersist();
//
//        JavaRDD<GisInputtipMroservice> tagRdd = userChoiceRdd.mapToPair(o -> new Tuple2<>(o.getNew_gid(), o))
//                .leftOuterJoin(snGisInputtipMroserviceRdd).map(tp -> {
//                    GisInputtipMroservice o = tp._2._1;
//                    if (tp._2._2 != null && tp._2._2.isPresent()) {
//                        GisInputtipMroservice gisInputtipMroservice = tp._2._2.get();
//                        o.setNew_q(gisInputtipMroservice.getQ());
//                        o.setNew_uids(gisInputtipMroservice.getUids());
//                        o.setNew_response(gisInputtipMroservice.getResponse());
//                        o.setNew_timestamps(gisInputtipMroservice.getTimestamps());
//                        o.setTag("1");
//                    }
//                    return o;
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("tagRdd cnt:{}", tagRdd.count());
//        userChoiceRdd.unpersist();
//        snGisInputtipMroserviceRdd.unpersist();
//
//        JavaRDD<GisInputtipMroservice> tagNoEmpRdd = tagRdd.filter(o -> StringUtils.isNotEmpty(o.getTag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        JavaRDD<GisInputtipMroservice> tagEmpRdd = tagRdd.filter(o -> StringUtils.isEmpty(o.getTag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("tagNoEmpRdd cnt:{}", tagNoEmpRdd.count());
//        logger.error("tagEmpRdd cnt:{}", tagEmpRdd.count());
//        tagRdd.unpersist();
//
//
//        JavaPairRDD<String, TtWaybillInfo> wayBillRdd = service.loadWaybillData(spark, sc, date).mapToPair(o -> new Tuple2<>(o.getOrder_id(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("wayBillRdd cnt:{}", wayBillRdd.count());
//
//        JavaRDD<GisInputtipMroservice> resultRdd = tagNoEmpRdd.mapToPair(o -> new Tuple2<>(o.getNew_sys_order_no(), o)).leftOuterJoin(wayBillRdd).map(tp -> {
//            GisInputtipMroservice o = tp._2._1;
//            if (tp._2._2 != null && tp._2._2.isPresent()) {
//                TtWaybillInfo ttWaybillInfo = tp._2._2.get();
//                o.setConsignee_addr(ttWaybillInfo.getConsignee_addr());
//                o.setConsignor_addr(ttWaybillInfo.getConsignor_addr());
//            }
//            return o;
//        }).union(tagEmpRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd cnt:{}", resultRdd.count());
//        tagNoEmpRdd.unpersist();
//        tagEmpRdd.unpersist();
//
//        service.saveData(spark, resultRdd, date, "dm_gis.gis_inputtip_mroservice_addr");
//        resultRdd.unpersist();
//
//        sc.stop();
//
//
//    }
//}
