package pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TtWaybillInfo implements Serializable {
    @Column(name = "order_id")
    private String order_id;
    @Column(name = "consignor_addr")
    private String consignor_addr;
    @Column(name = "consignee_addr")
    private String consignee_addr;

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getConsignor_addr() {
        return consignor_addr;
    }

    public void setConsignor_addr(String consignor_addr) {
        this.consignor_addr = consignor_addr;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }
}
