package pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class GisInputtipMroservice implements Serializable {
    @Column(name = "gid")
    private String gid;
    @Column(name = "city")
    private String city;
    @Column(name = "sys_order_no")
    private String sys_order_no;
    @Column(name = "sver")
    private String sver;
    @Column(name = "iver")
    private String iver;
    @Column(name = "sn")
    private String sn;
    @Column(name = "url")
    private String url;
    @Column(name = "click")
    private String click;
    @Column(name = "q")
    private String q;
    @Column(name = "groupid")
    private String groupid;
    @Column(name = "uids")
    private String uids;
    @Column(name = "response")
    private String response;
    @Column(name = "timestamps")
    private String timestamps;
    @Column(name = "province")
    private String province;
    @Column(name = "district")
    private String district;


    private String consignor_addr;
    private String consignee_addr;

    private String new_gid;
    private String new_sys_order_no;
    private String new_sver;
    private String new_iver;
    private String new_sn;
    private String new_url;
    private String user_choice;
    private String user_choice_uid;

    private String new_q;
    private String new_uids;
    private String new_response;
    private String new_timestamps;


    private String tag;

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getNew_q() {
        return new_q;
    }

    public void setNew_q(String new_q) {
        this.new_q = new_q;
    }

    public String getNew_uids() {
        return new_uids;
    }

    public void setNew_uids(String new_uids) {
        this.new_uids = new_uids;
    }

    public String getNew_response() {
        return new_response;
    }

    public void setNew_response(String new_response) {
        this.new_response = new_response;
    }

    public String getNew_timestamps() {
        return new_timestamps;
    }

    public void setNew_timestamps(String new_timestamps) {
        this.new_timestamps = new_timestamps;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getNew_gid() {
        return new_gid;
    }

    public void setNew_gid(String new_gid) {
        this.new_gid = new_gid;
    }

    public String getNew_sys_order_no() {
        return new_sys_order_no;
    }

    public void setNew_sys_order_no(String new_sys_order_no) {
        this.new_sys_order_no = new_sys_order_no;
    }

    public String getNew_sver() {
        return new_sver;
    }

    public void setNew_sver(String new_sver) {
        this.new_sver = new_sver;
    }

    public String getNew_iver() {
        return new_iver;
    }

    public void setNew_iver(String new_iver) {
        this.new_iver = new_iver;
    }

    public String getNew_sn() {
        return new_sn;
    }

    public void setNew_sn(String new_sn) {
        this.new_sn = new_sn;
    }

    public String getNew_url() {
        return new_url;
    }

    public void setNew_url(String new_url) {
        this.new_url = new_url;
    }

    public String getUser_choice() {
        return user_choice;
    }

    public void setUser_choice(String user_choice) {
        this.user_choice = user_choice;
    }

    public String getUser_choice_uid() {
        return user_choice_uid;
    }

    public void setUser_choice_uid(String user_choice_uid) {
        this.user_choice_uid = user_choice_uid;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getSys_order_no() {
        return sys_order_no;
    }

    public void setSys_order_no(String sys_order_no) {
        this.sys_order_no = sys_order_no;
    }

    public String getSver() {
        return sver;
    }

    public void setSver(String sver) {
        this.sver = sver;
    }

    public String getIver() {
        return iver;
    }

    public void setIver(String iver) {
        this.iver = iver;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getClick() {
        return click;
    }

    public void setClick(String click) {
        this.click = click;
    }

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getUids() {
        return uids;
    }

    public void setUids(String uids) {
        this.uids = uids;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getTimestamps() {
        return timestamps;
    }

    public void setTimestamps(String timestamps) {
        this.timestamps = timestamps;
    }

    public String getConsignor_addr() {
        return consignor_addr;
    }

    public void setConsignor_addr(String consignor_addr) {
        this.consignor_addr = consignor_addr;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }
}
