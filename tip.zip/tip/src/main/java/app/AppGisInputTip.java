package app;

import controller.GisInputTipController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id：482739（TIP日志解析埋点数据需求_运单地址）
 * 研发：01399581（匡仁衡）
 * 业务：01410433（赵瑜婷）
 */
public class AppGisInputTip {
    private static final Logger logger = LoggerFactory.getLogger(AppGisInputTip.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        new GisInputTipController().process(date);
        logger.error("process end...");
    }
}
