package service;

import com.sf.gis.java.base.util.CalPartitionUtil;
import com.sf.gis.java.base.util.DataUtil;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pojo.GisInputtipMroservice;
import pojo.TtWaybillInfo;

import java.util.ArrayList;
import java.util.List;

public class GisInputTipService {
    private static final Logger logger = LoggerFactory.getLogger(GisInputTipService.class);

    public JavaRDD<GisInputtipMroservice> loadData(SparkSession ss, JavaSparkContext jsc, String date) {
        String sql = String.format("select gid,city,sys_order_no,sver,iver,sn,url,click,q,groupid,uids,response,timestamps,province,district from dm_gis.gis_inputtip_mroservice where inc_day = '%s'", date);
        return DataUtil.loadData(ss, jsc, sql, GisInputtipMroservice.class);
    }


    public JavaRDD<TtWaybillInfo> loadWaybillData(SparkSession ss, JavaSparkContext jsc, String date) {
        String sql = String.format("select order_id,consignor_addr_decrypt consignor_addr,consignee_addr_decrypt consignee_addr from dm_gis.dwd_waybill_info_dtl_di where inc_day = '%s' and order_type = 'CX'", date);
        return DataUtil.loadData(ss, jsc, sql, TtWaybillInfo.class);
    }

    public void saveData(SparkSession spark, JavaRDD<GisInputtipMroservice> inRdd, String date, String table) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getNew_gid(), o.getCity(), o.getNew_sys_order_no(), o.getNew_sver(), o.getNew_iver(), o.getNew_sn(), o.getNew_url(), o.getNew_q(), o.getNew_uids(), o.getNew_response(),
                    o.getUser_choice(), o.getUser_choice_uid(), o.getNew_timestamps(), o.getConsignor_addr(), o.getConsignee_addr(), o.getProvince(), o.getDistrict()
            );
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        if (rows.count() > 0) {
            int partSize = CalPartitionUtil.getPartitionSize(rows);
            List<StructField> structFieldList = new ArrayList<>();
            String[] columnNames = new String[]{"gid", "city", "sys_order_no", "sver", "iver", "sn", "url", "q", "uids", "response",
                    "user_choice", "user_choice_uid", "timestamps", "consignor_addr", "consignee_addr", "province", "district"};
            DataType stringType = DataTypes.StringType;
            for (String columnName : columnNames) {
                structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
            }
            StructType structType = DataTypes.createStructType(structFieldList);
            Dataset<Row> ds = spark.createDataFrame(rows.repartition(partSize), structType);
            String tempTable = "inputtip_mroservice_addr_" + System.currentTimeMillis();
            ds.createOrReplaceTempView(tempTable);
            logger.error("targetTable:{}", table);
            spark.sql(String.format("insert overwrite table %s partition(inc_day = '%s') " +
                    "select * from %s", table, date, tempTable));
            rows.unpersist();
            spark.catalog().dropTempView(tempTable);
        }
    }

}
