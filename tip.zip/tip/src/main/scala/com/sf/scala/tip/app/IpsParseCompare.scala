package com.sf.scala.tip.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkWrite.overwriteToHiveDynamics
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{asc, col, lit, row_number, trim, udf, when}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import scala.collection.mutable.ArrayBuffer

/**
 *需求名称：IPS生产日志测试环境跑数及结果差分需求
 *需求描述：基于生产反馈的客诉问题，对IPS服务进行更新发版，需要取生产1天的日志，对测试与生产跑数结果进行对比分析，确保服务结果正常。
 *需求方：ft80004001 余攀
 *开发: 周勇(01390943)
 *任务创建时间：20231227
 *任务id：测试bdp：18
 **/

object IpsParseCompare {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    //衡度平台
    val spark = Spark.getSparkSession(className, null, false, 2)
    //科技平台
//    val SparkInfo = SparkUtil.getSpark(className)
//    val spark = SparkInfo.getSession
    import spark.implicits._
    //获取传入参数日期:昨日日期
    val dayvar = args(0)
    val ak = args(1)
    //执行第1段
    logger.error("执行第1段")
    startexe(spark,"1",ak)
    //执行第2段
    logger.error("执行第2段")
    startexe(spark,"2",ak)
    //执行第3段
    logger.error("执行第3段")
    startexe(spark,"3",ak)
    //执行第4段
    logger.error("执行第4段")
    startexe(spark,"4",ak)
    //执行第5段
    logger.error("执行第5段")
    startexe(spark,"5",ak)
    //执行第6段
    logger.error("执行第6段")
    startexe(spark,"6",ak)
    //执行第7段
    logger.error("执行第7段")
    startexe(spark,"7",ak)
    //执行第8段
    logger.error("执行第8段")
    startexe(spark,"8",ak)

    val data_all=spark.sql(
      """
        |select * from dm_gis.dm_ips_input_inc_result_di
        |""".stripMargin )
      .withColumn("inc_day",lit(dayvar))

    val table_allcols = spark.sql("""select * from dm_gis.dm_ips_input_inc_all_di limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, data_all.select(table_allcols: _*), Seq("inc_day"), "dm_gis.dm_ips_input_inc_all_di")

    logger.error("执行完成")

    spark.close()
  }

  def startexe(spark:SparkSession,inc_flag:String,ak:String): Unit ={
    logger.error("当前子任务开始执行>>>>")
    import spark.implicits._
    val ips_data=spark.sql(
      s"""
         |select province,q,city,district,src,response,inc_flag from dm_gis.dm_ips_input_inc_di
         |where inc_flag=$inc_flag
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("inc_flag").orderBy(asc("inc_flag")) ))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val ips_data_rdd=SparkUtils.getDfToJson(spark, ips_data, 300)

    //并行计算
    val  Multi_result=Multi_address_query_url(spark,ips_data_rdd, 20,ak)
      .map(obj=> {
        val rank = obj.getString("rank")
        val src_test = obj.getString("src_test")
        val name_test = obj.getString("name_test")
        (rank,src_test,name_test)
      }).toDF("rank","src_test","name_test")

    //数据拼接
    val result=ips_data.join(Multi_result,Seq("rank"),"left")
      .withColumn("src",when($"src".isNull || trim($"src")==="","").otherwise(to_uper_udf($"src")))
      .withColumn("src_test",when($"src_test".isNull || trim($"src_test")==="","").otherwise(to_uper_udf($"src_test")))
      .withColumn("response",when($"response".isNull || trim($"response")==="","").otherwise($"response"))
      .withColumn("name_test",when($"name_test".isNull || trim($"name_test")==="","").otherwise($"name_test"))
      .withColumn("src_tmp",when($"src".isNull || trim($"src")==="" || $"src"==="-" || $"src"==="EMPTY","").otherwise($"src"))
      .withColumn("src_test_tmp",when($"src_test".isNull || trim($"src_test")==="" || $"src_test"==="-" || $"src_test"==="EMPTY","").otherwise($"src_test"))
      .withColumn("flag",when($"src_tmp"===$"src_test_tmp" && $"response"===$"name_test","两者一致")
        .when($"src_tmp"=!=$"src_test_tmp" && $"response"===$"name_test","src")
        .when($"src_tmp"===$"src_test_tmp" && $"response"=!=$"name_test","name_test")
        .when($"src_tmp"=!=$"src_test_tmp" && $"response"=!=$"name_test","src|name_test")
        .otherwise(""))
      .withColumn("ak",lit(ak))

    //选择所需列
    val table_cols = spark.sql("""select * from dm_gis.dm_ips_input_inc_result_di limit 0""").schema.map(_.name).map(col)
    overwriteToHiveDynamics(spark, result.withColumn("inc_flag",lit(inc_flag)).select(table_cols: _*), Seq("inc_flag"), "dm_gis.dm_ips_input_inc_result_di")
    ips_data.unpersist()
    logger.error("当前子任务执行完毕>>>>")
  }

  //定义获取url数据
  def address_query_url(ak:String,obj:JSONObject): JSONObject = {
    try {
      //考虑到tps限制，每秒500.共20个线程
      Thread.sleep(20)
      val q = URLEncoder.encode(obj.getString("q"), "UTF-8")
      val province =obj.getString("province")
      val city =obj.getString("city")
      val district =obj.getString("district")
      val opt="sf30"
      //获取接口数据
      val url = s"http://gis-int.intsit.sfdc.com.cn:1080/tip/api?ak=$ak&province=$province&q=$q&district=$district&city=$city&opt=$opt"
      val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 4)
      val ret: JSONObject = JSON.parseObject(retStr)

      val status=ret.getString("status")
      var src_test=""
      var name_test=""

      if(status==0 || status=="0"){
        try{
          src_test=ret.getJSONObject("result").getString("POISrc").toUpperCase()
        }
        catch{
          case e: Exception => logger.error(e)
            obj.put("err_msg1",e.getMessage)
        }
      }

      if(status==0 || status=="0"){
        try{
          val key_prefix_tmp=ret.getJSONObject("result").getJSONArray("POISet").getJSONObject(0).getString("key_prefix")
          val name_tmp=ret.getJSONObject("result").getJSONArray("POISet").getJSONObject(0).getString("name")
          val key_prefix=if(key_prefix_tmp==null){""}else{key_prefix_tmp}
          val name=if(name_tmp==null){""}else{name_tmp}
          name_test=key_prefix.concat(name)
        }
        catch{
          case e: Exception => logger.error(e)
            obj.put("err_msg2",e.getMessage)
        }
      }

      obj.put("src_test",src_test)
      obj.put("name_test",name_test)
    }
    catch{
      case e: Exception => logger.error(e)
        obj.put("err_msg",e.getMessage)
    }
    obj
  }

  //并发调取接口并发请求，由于每个ak单分钟限制3000
  def Multi_address_query_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int,ak:String) = {
    //调用开始上报
//    val httpUrl = s"http://gis-int.intsit.sfdc.com.cn:1080/tip/api?"
//    val httpAk="663ee55ce37c42b182c17e37e66171a7"
//    val dataCnt=DataRdd.count()
//    val invokeThreadCnt=DataRdd.getNumPartitions
//    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "000000", "ips跑数",
//      "IPS生产日志测试环境跑数及结果差分需求",
//      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, address_query_url, 20, ak, 30000)

    //调用完成上报
//    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
//
//    logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }


  def to_uper(x:String): String ={
  return x.toUpperCase()
  }

  val to_uper_udf=udf(to_uper _)
}
