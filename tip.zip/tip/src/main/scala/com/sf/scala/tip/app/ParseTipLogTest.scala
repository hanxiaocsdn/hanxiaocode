package com.sf.scala.tip.app

import java.net.URLDecoder
import java.text.DecimalFormat

import com.alibaba.fastjson.JSON
import com.sf.gis.java.base.util.FileUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
 * Created by 刘正 on 2018/7/10.
 * 解析输入提示日志数据并保存到hive,创建临时表的方式
 * 当前相关业务：赵瑜婷 刘思远
 */
object ParseTipLogTest {
  @transient lazy val logger: Logger = Logger.getLogger(ParseTipLog.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class RowObj(
                     province: String,
                     city: String,
                     district: String,
                     q: String,
                     src: String,
                     flag: Int,
                     ak: String,
                     groupId: String,
                     click: Int,
                     respTime: Int,
                     timestamps: String,
                     uids: String,
                     response: String,
                     clkSrc: String,
                     clkInputLen: Int,
                     clkInputReq: Int,
                     clkRespPosition: Int,
                     finalClick: Int,
                     isPaste: Int,
                     req_dup: Int,
                     isOneReq: Int,
                     useTime: Long,
                     input_word_count: Int,
                     final_word_count: Int,
                     is_group_last: Int,
                     input_word_rate: Double
                   )

  def main(args: Array[String]): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    val dataSep = args(0)
    val incDay = dataSep.replaceAll("-", "")
    logger.error(s">>>开始解析日志-----------------------------dataSep:${dataSep}")
    start(sparkSession, dataSep, incDay)


    logger.error("完")
    sparkSession.stop()
  }

  def start(sparkSession: SparkSession, dataSep: String, incDay: String): Unit = {
    //		val timeFormat = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS")
    val proProperties = FileUtil.getFileProperties("conf/province.properties")
    val cityProperties = FileUtil.getFileProperties("conf/city.properties")
    //导入隐饰操作，否则RDD无法调用toDF方法
    val logs = sparkSession.sparkContext.textFile("hdfs://stream/user/mario/warehouse/ods_kafka_gis/bee_logs_gis_tip_collect/" + incDay + "/*")
    val dataFrame = logs.filter(line => line.contains("url_e") && line.contains(dataSep)).map(line => {

      var json: com.alibaba.fastjson.JSONObject = null
      val logObject = JSON.parseObject(line)
      if (logObject != null) {
        try {
          val logString = logObject.getString("message")
          json = JSON.parseObject(logString)
        } catch {
          case e: Exception => {}
        }
      }

      var flag = 1
      var timestamp: java.lang.Long = -1l
      var respTime = 0
      var ak = ""
      var q = ""
      var src: String = "-"
      var response = ""
      var uids = ""
      var groupId: String = "none"
      var click = 0
      var url = ""
      var city = ""
      var province = ""
      var district = ""

      if (json != null) {
        try {
          flag = json.getJSONObject("data").getString("status").toInt
        } catch {
          case e: Exception =>
        }
        //      val timestamp =  sdf.parse(json.getString("dateTime")).getTime
        if (StringUtils.nonEmpty(json.getString("dateTime"))) {
          timestamp = DateUtil.dateToStamp(json.getString("dateTime"), "yyyy-MM-dd HH:mm:ss.SSS")
        }
        //val date = json.getString("dateTime").substring(0, 10)
        try {
          respTime = json.getString("time").toInt
        } catch {
          case e: Exception => {}
        }


        ak = json.getJSONObject("url").getString("ak")
        if (ak == null) {
          ak = "none"
        }
        //val remoteIp = json.getJSONObject("url").getString("remoteIp")
        q = json.getJSONObject("url").getString("q")
        if (q != null) {
          q = q.replaceAll("[,\\s]*", "")
        } else {
          q = ""
          flag = 1
        }
        url = json.getJSONObject("url").getString("url")
        //var city = json.getJSONObject("url").getString("city")
        city = ""
        try {
          if (url != null && url.contains("&city=")) {
            city = url.substring(url.indexOf("&city=") + 6)
            if (city.contains("&")) {
              city = URLDecoder.decode(city.substring(0, city.indexOf("&")).replaceAll("%(?![0-9a-fA-F]{2})", "%25"), "utf-8")
            } else {
              city = ""
            }
          }
        } catch {
          case e: Exception => logger.error(url, e)
        }

        if (city == null || "".equals(city)) {
          city = "未选省市区"
        }
        if (city != null && cityProperties.getProperty(city) != null) {
          city = cityProperties.getProperty(city)
        }
        if (proProperties.getProperty(city) == null) {
          city = "-"
        }
        if (StringUtils.isBlank(city)) {
          city = "-"
        }

        province = proProperties.getProperty(city)
        if (province == null) {
          province = "-"
        }
        district = json.getJSONObject("url").getString("district")
        if (district == null) {
          district = "-"
        }

        if (flag == 0) {
          try {
            src = json.getJSONObject("data").getJSONObject("result").getString("POISrc").toUpperCase
            if ("EMPTY".equals(src) || "".equals(src)) {
              src = "-"
              flag = 1
            }
          } catch {
            case e: Exception => src = "-"
          }

          try {
            val array = json.getJSONObject("data").getJSONObject("result").getJSONArray("POISet").iterator()
            val addr = new StringBuffer()
            val uid = new StringBuffer()
            while (array.hasNext) {
              val poi = JSON.parseObject(array.next().toString)
              addr.append(poi.getString("key_prefix") + poi.getString("name")).append("::")
              uid.append(poi.getString("uid")).append("::")
            }
            if (addr.length() >= 2) {
              response = addr.substring(0, addr.length() - 2).replaceAll("[,\\s]*", "")
              uids = uid.substring(0, uid.length() - 2)
            }
          } catch {
            case e: Exception => println(line)
          }
        }

        if (url.contains("&uid=")) {
          groupId = url.substring(url.indexOf("&uid=") + 5)
          if (groupId.contains("&")) {
            groupId = groupId.substring(0, groupId.indexOf("&"))
          }
        }
        if (StringUtils.isBlank(groupId)) {
          groupId = "none"
        }
        if (url.contains("isclick")) {
          val temp = url.substring(url.indexOf("isclick=") + 8, url.indexOf("isclick=") + 9)
          if (temp.matches("[0-9]"))
            click = temp.toInt
        }
      }

      //(String, String, String, String, String, Int, String, String, Int, Int, String, String, String, String, Int, Int, Int, Int, Int, Int, Int, Int
      (province, city, district, q, src, flag, ak, groupId, click, respTime, timestamp.toString, uids, response, line)
    }).filter(_._5 != null)
    val noUidRdd = dataFrame.filter(line => "none".equals(line._8) || "".equals(line._8)).flatMap(line => {
      var tmpArray = new java.util.ArrayList[Tuple14[String,String,String,String,String,Int,String,String,
        Int,Int,String,String,String,String]]()

      if(!line._12.isEmpty){
        val uidArray = line._12.split("::")
        for(i <- uidArray.indices ){
          val tuple14:Tuple14[String,String,String,String,String,Int,String,String, Int,Int,String,String,String,String]  = new Tuple14(line._1, line._2, line._3, line._4, line._5, line._6, line._7,uidArray(i) , line._9, line._10,line._11, line._12, line._13, line._14)
          tmpArray.add(tuple14)
        }
      }
      tmpArray.iterator()
    }).filter(line=>{
      !"none".equals(line._8) && !"".equals(line._8)
    })

    val df = new DecimalFormat("0.0000")
    //(province, city, district, q, src, flag, ak, groupId, click, respTime, timestamp, uids, response)
    val hasUidRdd = dataFrame.union(noUidRdd).filter(line => !"none".equals(line._8) && !"".equals(line._8)).groupBy(_._8).map(line => {
      val result = new ArrayBuffer[RowObj]()
      val list = line._2.toList.sortBy(_._11)
      (line._1, list)
    }).filter(obj => {
      var click = false;
      var click0 = 0;
      var click1 = 0;
      obj._2.foreach(obj => {
        if (obj._9 == 1) {
          click1 = 1
        } else {
          click0 = 1
        }
      })
      click1 + click0 == 2
    }).take(10).foreach(obj => {
      logger.error("====>groupid:" + obj._1)
      logger.error("数据：")
      obj._2.foreach(item => {
        logger.error(item._14)
      })
      logger.error("结束<=============")
      logger.error("")
      logger.error("")
      logger.error("")
    })
    logger.error("------------数据入hive结束--------------------------")
  }


}
