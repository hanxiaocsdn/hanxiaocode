package com.sf.scala.tip.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.scala.tip.app.TestInputtipMroService.{className, getData, logger, saveKey}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder

/**
 * @ProductManager:01421176
 * @Author: 01407499
 * @CreateTime: 2024-01-30 09:58
 * @TaskId:20
 * @TaskName:
 * @Description:测试iad接口
 */

object TestIad {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val iadurl="http://gis-int.intsit.sfdc.com.cn:1080/iad/api?address=%s&citycode=%s&ak=c28d9ad462a8493e8e6fd968d601598d&opt=detail&province=&city=&county="
    val saveKey=Array("province","city","citycode","county","town","address","multi","exp_multi","exp_split_info","address_cnt","same","response")
    def main(args: Array[String]): Unit = {
        val limitnum = args(0)
        val mode = args(1)
        val start_index=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        if(mode.equals("divide")){
            divideData(sparkSession)
        }else if(mode.equals("calc")){
            for (i <- start_index.toInt until (41)) {
                try {
                    val resultRdd = getData(sparkSession, i.toString, limitnum)
                    logger.error("开始存储数据")
                    SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.new_ipad_address_log_resolution_all_data", Array(("inc_day", i.toString)), 25)
                } catch {
                    case e: Exception => logger.error(e.toString)
                }
            }
        }
    }


    def divideData(spark: SparkSession) = {
        val sql =
            """
              |
              |
              |
              |insert overwrite table dm_gis.new_ipad_address_log_resolution_mid partition(group_num)
              |select
              |province,city,citycode,county,town,address,multi, address_cnt
              |,cast(ntile(40)over(order by address) as string) as group_num
              |from
              |dm_gis.new_ipad_address_log_resolution_text
              |
              |
              |""".stripMargin
        logger.error("切分数据sql---->" + sql)
        spark.sql(sql)
        logger.error("切分结束")
    }

    def getData(spark: SparkSession,end_day:String,limitnum:String)={

        var sql=
            s"""
              |
              |select * from dm_gis.new_ipad_address_log_resolution_mid where group_num='$end_day' limit $limitnum
              |
              |
              |""".stripMargin


        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val value: RDD[JSONObject] = dataRdd.repartition(144).mapPartitionsWithIndex((index, iter) => {
            val startTime = new StratTime(System.currentTimeMillis())
            val cn1 = new Cnt(0)
            for (obj <- iter) yield {
                try{
                    var address = obj.getString("address")
                    val citycode=obj.getString("citycode")
                    val province=obj.getString("province")
                    val county=obj.getString("county")
                    val city=obj.getString("city")
                    address=province+city+county+address
                    val multi=obj.getString("multi")
                    var same="1"
                    SparkUtils.limitAkUse(startTime, cn1, index, 1000, logger)
                    val (exp_multi,exp_split_info,response)=getInterfaceData(address,citycode)
                    if(StringUtils.nonEmpty(multi)&&StringUtils.nonEmpty(exp_multi)&&multi.equals(exp_multi)){
                        same="0"
                    }
                    obj.put("exp_multi",exp_multi)
                    obj.put("exp_split_info",exp_split_info)
                    obj.put("response",response)
                    obj.put("address",address)
                    obj.put("same",same)
                }catch {case e:Exception=>logger.error(e.toString)}
                obj
            }
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("调用接口，数据量--->"+value.count())
        value
    }

    def getInterfaceData(addr:String,citycode:String)={
        val url=String.format(iadurl,URLEncoder.encode(addr,"utf-8"),citycode)
        var response=""
        var multi=""
        var split_info=""
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                response=e.toString
                new JSONObject()
            }

        }
        try {
            if (jSONObject != null&&(!jSONObject.isEmpty)) {
                response=jSONObject.toString()
                multi = JSONUtil.getJsonVal(jSONObject, "result.data.multi", "")
                split_info = JSONUtil.getJsonVal(jSONObject, "result.data.split_info", "")
            }
        } catch {
            case e: Exception => {

            }
        }
        (multi,split_info,response)
    }

}
