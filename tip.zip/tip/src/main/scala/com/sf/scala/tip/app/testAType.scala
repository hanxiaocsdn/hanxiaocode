package com.sf.scala.tip.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.util.Calendar

/**
 * @ProductManager:
 * @Author: 01407499
 * @CreateTime: 2023-11-24 11:02
 * @TaskId:911569
 * @TaskName:
 * @Description:atype跑数
 */

object testAType {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    //4da9bfda40954f648f8fd339878961f1
    //3a7263f9423b47fc9a8d1defbfed10d9
    val atypeUrl = "http://gis-int2.int.sfdc.com.cn:1080/atype/api?ak=4da9bfda40954f648f8fd339878961f1&address=%s&citycode=%s"

    val saveKey=Array("encrypt_addr","decrypt_addr","typecode","bigname","mediumname","smallname","response","url")
    def main(args: Array[String]): Unit = {
        var start_index=args(0)
        val limitnum = args(1)
        val sparkSession = Spark.getSparkSession(className)
        //tmp_dm_gis.r_mia_waybill_addr_result
        //tmp_dm_gis.r_mia_waybill_addr_result_v2
        sparkSession.sparkContext.setLogLevel("ERROR")
        for (i <- start_index.toInt until (41)) {
            try {
                val resultRdd = getData2(sparkSession, i.toString, limitnum)
                logger.error("开始存储数据")
                SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "tmp_dm_gis.r_mia_waybill_addr_result_v3", Array(("inc_day", i.toString)), 25)
                Spark.clearAllPersist(sparkSession)
            } catch {
                case e: Exception => logger.error(e.toString)

            }
        }
    }

    def getData(spark: SparkSession, end_day: String, limitnum: String)={
        //tmp_dm_gis.r_mia_waybill_addr
        //tmp_dm_gis.r_mia_waybill_addr_v2
        var sql=
            s"""
              |
              |
              |select encrypt_addr,decrypt_addr from tmp_dm_gis.r_mia_waybill_addr_v3 where group_num='$end_day' and decrypt_addr<>'' group by encrypt_addr,decrypt_addr limit $limitnum
              |
              |
              |
              |""".stripMargin


        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val decrypt_addr = obj.getString("decrypt_addr")
            val (typecode,bigname,mediumname,smallname,response,url)=getInterFaceData(decrypt_addr,"")
            obj.put("typecode",typecode)
            obj.put("bigname",bigname)
            obj.put("mediumname",mediumname)
            obj.put("smallname",smallname)
            obj.put("response",response)
            obj.put("url",url)
            obj
        })
        resultRdd

    }

    def getData2(spark: SparkSession, end_day: String, limitnum: String)={
        //tmp_dm_gis.r_mia_waybill_addr
        //tmp_dm_gis.r_mia_waybill_addr_v2
        var sql=
        s"""
           |
           |
           |select encrypt_addr,decrypt_addr from tmp_dm_gis.r_mia_waybill_addr_v3 where group_num='$end_day' and decrypt_addr<>'' group by encrypt_addr,decrypt_addr limit $limitnum
           |
           |
           |
           |""".stripMargin

        sql=
            s"""
               |
               |
               |select * from tmp_dm_gis.r_mia_waybill_addr_result_v3 where inc_day='$end_day' and decrypt_addr<>''
               |
               |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val notNeedComplete = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("typecode")) && x.getString("typecode").length > 4)
        val NeedComplete = dataRdd.filter(x => !(StringUtils.nonEmpty(x.getString("typecode")) && x.getString("typecode").length > 4))
        val resultRdd = NeedComplete.map(obj => {
            val decrypt_addr = obj.getString("decrypt_addr")
            val (typecode,bigname,mediumname,smallname,response,url)=getInterFaceData(decrypt_addr,"")
            obj.put("typecode",typecode)
            obj.put("bigname",bigname)
            obj.put("mediumname",mediumname)
            obj.put("smallname",smallname)
            obj.put("response",response)
            obj.put("url",url)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("调用接口数据量----》"+resultRdd.count())
        resultRdd.union(notNeedComplete)

    }

    def getInterFaceData(addr:String,citycode:String)={
        val url=String.format(atypeUrl,URLEncoder.encode(addr, "UTF-8"),citycode)
        var jSONObject = new JSONObject()
        var response=""
        var typecode=""
        var bigname=""
        var mediumname=""
        var smallname=""
        var nowHour = getHour()
        /*
        while (!(nowHour>=6&&nowHour<23)){
            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
            Thread.sleep(1000*60)
            nowHour = getHour()

        }*/
        //15000/min
        Thread.sleep(10)
        jSONObject = try {
            JSON.parseObject(HttpInvokeUtil.sendGet(url, 5000))
        }
        catch {
            case e:Exception=>{
                response=e.toString
                new JSONObject()
            }
        }
        if(jSONObject!=null&&(!jSONObject.isEmpty)){
            response=jSONObject.toString()
            typecode=JSONUtil.getJsonVal(jSONObject,"result.data.typecode","")
            bigname=JSONUtil.getJsonVal(jSONObject,"result.data.bigname","")
            mediumname=JSONUtil.getJsonVal(jSONObject,"result.data.mediumname","")
            smallname=JSONUtil.getJsonVal(jSONObject,"result.data.smallname","")
        }
        (typecode,bigname,mediumname,smallname,response,url)


    }

    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }

}
