package com.sf.scala.tip.app

import com.alibaba.druid.pool.DruidDataSource
import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import com.sf.gis.scala.base.util.DbUtil
import com.sf.scala.tip.app.TestInputtipMroService.className
import com.sf.utils.MySqlAESUtil
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import java.sql.Connection
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * @ProductManager:
 * @Author: 01407499
 * @CreateTime: 2023-12-29 17:06
 * @TaskId:
 * @TaskName:
 * @Description:
 */

object testMysql {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)

    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        getAoiCenter(sparkSession)

    }


    def getConn(): Connection = {
        var conn: Connection = null

        var dataSource: DruidDataSource = null
        try {
            dataSource = new DruidDataSource()
            dataSource.setDriverClassName("com.mysql.jdbc.Driver")
            dataSource.setUrl("jdbc:mysql://asscmsbase-m.dbdr.sfdc.com.cn:3306/asscmsbase?useUnicode=true&amp;characterEncoding=utf-8")
            dataSource.setUsername("asscmsbase")
            dataSource.setPassword("dUh3n45Hgn")
            dataSource.setMaxActive(20)
            dataSource.setMaxWait(3000)
            dataSource.setRemoveAbandoned(false)
            conn = dataSource.getConnection
        } catch {
            case e: Exception => println(">>>mysql数据库连接异常：" + e)
        }
        conn
    }


    def getAoiCenter(sparkSession: SparkSession)={
        val conn = getConn()
        var sql=
            """
              |
              |select aoi_id,center_point from cms_aoi_sch
              |""".stripMargin

        val dataArr: ArrayBuffer[Array[String]] = DbUtil.selectColumns(conn, sql, Array("aoi_id", "center_point"))
        logger.error("aoi中心点数据---》"+dataArr.size)
        dataArr.take(100).foreach(_.foreach(println))

        val aoiCenterDataRdd = sparkSession.sparkContext.parallelize(dataArr).mapPartitions(x=>{
            val listbuffer = new ListBuffer[JSONObject]
//            val mySqlAESUtil =  MySqlAESUtil
            val dataObj = new JSONObject()
            for(arr<-x){
                try{
                    val aoi_id = arr(0)
                    val center_point = arr(1)
                    val str = MySqlAESUtil.Decrypt(center_point, "jkl;POIU1234++==")
                    val lng=str.split("POINT \\(")(1).split("\\)")(0).split(" ")(0)
                    val lat=str.split("POINT \\(")(1).split("\\)")(0).split(" ")(1)
                    dataObj.put("aoi_id",aoi_id)
                    dataObj.put("lng",lng)
                    dataObj.put("lat",lat)

                    listbuffer+=dataObj
                }catch {case e:Exception=>logger.error(e.toString)}


            }


            listbuffer.iterator
        })

        aoiCenterDataRdd.take(100).foreach(println)



    }



}
