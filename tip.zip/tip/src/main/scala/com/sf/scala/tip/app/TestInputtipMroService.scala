package com.sf.scala.tip.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.util
import java.util.Calendar
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:ft80004001
 * @Author: 01407499
 * @CreateTime: 2023-11-10 15:58
 * @TaskId:4
 * @TaskName:测试ips接口
 * @Description:测试环境
 */

object TestInputtipMroService {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val ipsUrl = "http://gis-int.intsit.sfdc.com.cn:1080/tip/api"
    val ipsNewUrl = "http://gis-int.int.sfdc.com.cn:1080/tip/api?ak=3a7263f9423b47fc9a8d1defbfed10d9&province=%s&city=%s&district=%s&q=%s&opt=sf30"
    val saveKey = Array("province", "city", "district", "q", "ak", "src", "response", "src_hd", "name_hd","interfacedata","url")

    def main(args: Array[String]): Unit = {
        val end_day = args(0)
        val limitnum = args(1)
        val mode = args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        if (mode.equals("divide")) {
            divideData(sparkSession)
        } else if (mode.equals("calc")) {
            for (i <- 1 until (41)) {
                try {
                    val resultRdd = getData(sparkSession, i.toString, limitnum)
                    logger.error("开始存储数据")
                    SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "tmp_dm_gis.gis_inputtip_mroservice_all_interface_v1", Array(("inc_day", i.toString)), 25)

                } catch {
                    case e: Exception => logger.error(e.toString)

                }


            }


        }


    }

    def divideData(spark: SparkSession) = {
        val sql =
            """
              |
              |
              |
              |insert overwrite table dm_gis.gis_inputtip_mroservice_all_v7 partition(group_num)
              |select
              |province
              |,city
              |,district
              |,q
              |,src
              |,response
              |,cast(ntile(40)over(order by q) as string) as group_num
              |from
              |(
              |select *,row_number()over(partition by q order by src desc ) rnk from gis_inputtip_mroservice_all
              |) t
              |where t.rnk=1
              |
              |
              |
              |
              |""".stripMargin
        logger.error("切分数据sql---->" + sql)
        spark.sql(sql)
        logger.error("切分结束")


    }

    def getData(spark: SparkSession, end_day: String, limitnum: String) = {


        var sql =
            s"""
               |
               |select
               |province
               |,city
               |,district
               |,q
               |,src
               |,response
               |from
               |(
               |select *,row_number()over(partition by q order by src desc ) rnk from dm_gis.gis_inputtip_mroservice_all_v3
               |) t
               |where t.rnk=1
               |limit $limitnum
               |
               |""".stripMargin

        if (end_day.equals("20231001")) {
            sql =
                s"""
                   |
                   |select
                   |province
                   |,city
                   |,district
                   |,q
                   |,src
                   |,response
                   |from
                   |(
                   |select *,row_number()over(partition by q order by src desc ) rnk from dm_gis.gis_inputtip_mroservice_all_v2
                   |) t
                   |where t.rnk=1
                   |limit $limitnum
                   |
                   |""".stripMargin

        } else if (end_day.equals("20231002")) {
            sql =
                s"""
                   |
                   |
                   |
                   |
                   |select
                   |province
                   |,city
                   |,district
                   |,q
                   |,src
                   |,response
                   |from
                   |(
                   |select *,row_number()over(partition by q order by src desc ) rnk from dm_gis.gis_inputtip_mroservice_all_v3
                   |) t
                   |where t.rnk=1
                   |limit $limitnum
                   |
                   |""".stripMargin

        } else if (end_day.equals("20231003")) {
            sql =
                s"""
                   |
                   |select
                   |province
                   |,city
                   |,district
                   |,q
                   |,src
                   |,response
                   |from
                   |(
                   |select *,row_number()over(partition by q order by src desc ) rnk from dm_gis.gis_inputtip_mroservice_all_v4
                   |) t
                   |where t.rnk=1
                   |limit $limitnum
                   |
                   |
                   |
                   |
                   |
                   |""".stripMargin

        } else if (end_day.equals("20231004")) {
            sql =
                s"""
                   |
                   |select
                   |province
                   |,city
                   |,district
                   |,q
                   |,src
                   |,response
                   |from
                   |(
                   |select *,row_number()over(partition by q order by src desc ) rnk from dm_gis.gis_inputtip_mroservice_all_v5
                   |) t
                   |where t.rnk=1
                   |limit $limitnum
                   |
                   |
                   |
                   |
                   |
                   |""".stripMargin


        }

        sql =
            s"""
               |
               |select
               |province
               |,city
               |,district
               |,regexp_replace(q,'[\\n]+','') q
               |,src
               |,response
               |from tmp_dm_gis.gis_inputtip_mroservice_test where group_num='$end_day' and length(q)>6 and q regexp '[\\u4e00-\\u9fa5]'
               |limit $limitnum
               |
               |""".stripMargin


        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            //province,city,district
            try {

                val province = obj.getString("province")
                val city = obj.getString("city")
                val district = obj.getString("district")
                val q = obj.getString("q")
                val tmpObj = new JSONObject()
                if (StringUtils.nonEmpty(q) && q.length > 6) {
//                    obj.put("ak", "054ea7392d9d4d5698cd49ee2bb3c7e0")
                    obj.put("ak", "3a7263f9423b47fc9a8d1defbfed10d9")
                    val (jSONObject, src, name,url) = getInterFaceNew(province,city,district,q)
                    //            obj.put("interfacedata", jSONObject)
                    obj.put("src_hd", src)
                    obj.put("name_hd", name)
                    obj.put("interfacedata", jSONObject)
                    obj.put("url", url)
                }


            } catch {
                case e: Exception => logger.error(e.toString)
            }


            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("调用接口返回值---》" + resultRdd.count())
        resultRdd

    }

    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }
    def getInterFaceNew(province: String, city: String, d: String, q: String): (String, String, String, String) = {
        val url = String.format(ipsNewUrl, URLEncoder.encode(province, "UTF-8"), URLEncoder.encode(city, "UTF-8"), URLEncoder.encode(d, "UTF-8"), URLEncoder.encode(q, "UTF-8"))
        var jSONObject = new JSONObject()
        var src = ""
        var name = ""
        var status=""
        var response=""
        var nowHour = getHour()

        if((nowHour<6&&nowHour>=0)||nowHour>=21){
            logger.error("nowtime---->+"+nowHour+"继续跑数")
        }else{
            logger.error("nowtime---->+"+nowHour+"停止跑数")
            return (response, src, name,url)
        }
        Thread.sleep(50)
        breakable {
            for(i<- 0 until 2){
                jSONObject = try {
                    HttpUtils.urlConnectionGetJson(url, 5000)
                }
                catch {
                    case e:Exception=>{
                        response=e.toString
                        new JSONObject()
                    }

                }
                status=JSONUtil.getJsonVal(jSONObject,"status","-1")
                if(status.equals("0")){
                    break
                }else{
                    break
//                    val msg = JSONUtil.getJsonVal(jSONObject, "msg", "")
//                    if(msg.contains("found")&&msg.contains("not")){
//                        break
//
//                    }
//                    Thread.sleep(1000)
                }
            }

        }

        try {
            if (jSONObject != null&&(!jSONObject.isEmpty)) {
                response=jSONObject.toString()
                src = JSONUtil.getJsonVal(jSONObject, "result.POISrc", "")
                name = JSONUtil.getJsonArrayFromObject(jSONObject, "result.POISet").getJSONObject(0).getString("key_prefix")+JSONUtil.getJsonArrayFromObject(jSONObject, "result.POISet").getJSONObject(0).getString("name")
            }
        } catch {
            case e: Exception => {

            }
        }
        (response, src, name,url)

    }
}