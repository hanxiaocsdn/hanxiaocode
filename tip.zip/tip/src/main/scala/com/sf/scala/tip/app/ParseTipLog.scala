package com.sf.scala.tip.app

import java.net.URLDecoder
import java.text.DecimalFormat

import com.alibaba.fastjson.JSON
import com.sf.gis.java.base.util.FileUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 刘正 on 2018/7/10.
 * 解析输入提示日志数据并保存到hive,创建临时表的方式
 * 当前相关业务：赵瑜婷 刘思远
 * 任务id:224190
 * 任务名称：TIP日志解析埋点数据需求
 * @Author: 01399581
 */
object ParseTipLog {
  @transient lazy val logger: Logger = Logger.getLogger(ParseTipLog.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class RowObj(
                     province: String,
                     city: String,
                     district: String,
                     q: String,
                     src: String,
                     flag: Int,
                     ak: String,
                     groupId: String,
                     click: Int,
                     respTime: Int,
                     timestamps: String,
                     uids: String,
                     response: String,
                     clkSrc: String,
                     clkInputLen: Int,
                     clkInputReq: Int,
                     clkRespPosition: Int,
                     finalClick: Int,
                     isPaste: Int,
                     req_dup: Int,
                     isOneReq: Int,
                     useTime: Long,
                     input_word_count: Int,
                     final_word_count: Int,
                     is_group_last: Int,
                     input_word_rate: Double,
                     gid: String,
                     sys_order_no: String,
                     sver: String,
                     iver: String,
                     sn: String,
                     url: String
                   )

  def main(args: Array[String]): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    val dataSep = args(0)
    val incDay = dataSep.replaceAll("-", "")
    logger.error(s">>>开始解析日志-----------------------------dataSep:${dataSep}")
    start(sparkSession, dataSep, incDay)


    logger.error("完")
    sparkSession.stop()
  }

  def start(sparkSession: SparkSession, dataSep: String, incDay: String): Unit = {
    //		val timeFormat = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS")
    val proProperties = FileUtil.getFileProperties("conf/province.properties")
    val cityProperties = FileUtil.getFileProperties("conf/city.properties")
    //导入隐饰操作，否则RDD无法调用toDF方法
    val logs = sparkSession.sparkContext.textFile("hdfs://stream/user/mario/warehouse/ods_kafka_gis/bee_logs_gis_tip_collect/" + incDay + "/*").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("logs cnt:" + logs.count())
    logs.take(2).foreach(o => logger.error(o))
    val dataFrame = logs.filter(line => line.contains("url_e") && line.contains(dataSep)).map(line => {

      var json: com.alibaba.fastjson.JSONObject = null
      val logObject = JSON.parseObject(line)
      if (logObject != null) {
        try {
          val logString = logObject.getString("message")
          json = JSON.parseObject(logString)
        } catch {
          case e: Exception => {}
        }
      }

      var flag = 1
      var timestamp: java.lang.Long = -1l
      var respTime = 0
      var ak = ""
      var q = ""
      var src: String = "-"
      var response = ""
      var uids = ""
      var groupId: String = "none"
      var click = 0
      var url = ""
      var city = ""
      var province = ""
      var district = ""
      var gid = ""
      var sys_order_no = ""
      var sver = ""
      var iver = ""
      var sn = ""

      if (json != null) {
        try {
          flag = json.getJSONObject("data").getString("status").toInt
        } catch {
          case e: Exception =>
        }
        //      val timestamp =  sdf.parse(json.getString("dateTime")).getTime
        if (StringUtils.nonEmpty(json.getString("dateTime"))) {
          timestamp = DateUtil.dateToStamp(json.getString("dateTime"), "yyyy-MM-dd HH:mm:ss.SSS")
        }
        //val date = json.getString("dateTime").substring(0, 10)
        try {
          respTime = json.getString("time").toInt
        } catch {
          case e: Exception => {}
        }


        ak = json.getJSONObject("url").getString("ak")
        if (ak == null) {
          ak = "none"
        }
        //val remoteIp = json.getJSONObject("url").getString("remoteIp")
        q = json.getJSONObject("url").getString("q")
        if (q != null) {
          q = q.replaceAll("[,\\s]*", "")
        } else {
          q = ""
          flag = 1
        }
        url = json.getJSONObject("url").getString("url")
        //var city = json.getJSONObject("url").getString("city")
        city = ""
        try {
          if (url != null && url.contains("&city=")) {
            city = url.substring(url.indexOf("&city=") + 6)
            if (city.contains("&")) {
              city = URLDecoder.decode(city.substring(0, city.indexOf("&")).replaceAll("%(?![0-9a-fA-F]{2})", "%25"), "utf-8")
            } else {
              city = ""
            }
          }
        } catch {
          case e: Exception => logger.error(url, e)
        }

        if (city == null || "".equals(city)) {
          city = "未选省市区"
        }
        if (city != null && cityProperties.getProperty(city) != null) {
          city = cityProperties.getProperty(city)
        }
        if (proProperties.getProperty(city) == null) {
          city = "-"
        }
        if (StringUtils.isBlank(city)) {
          city = "-"
        }

        province = proProperties.getProperty(city)
        if (province == null) {
          province = "-"
        }
        district = json.getJSONObject("url").getString("district")
        if (district == null) {
          district = "-"
        }

        if (flag == 0) {
          try {
            src = json.getJSONObject("data").getJSONObject("result").getString("POISrc").toUpperCase
            if ("EMPTY".equals(src) || "".equals(src)) {
              src = "-"
              flag = 1
            }
          } catch {
            case e: Exception => src = "-"
          }

          try {
            val array = json.getJSONObject("data").getJSONObject("result").getJSONArray("POISet").iterator()
            val addr = new StringBuffer()
            val uid = new StringBuffer()
            while (array.hasNext) {
              val poi = JSON.parseObject(array.next().toString)
              addr.append(poi.getString("key_prefix") + poi.getString("name")).append("::")
              uid.append(poi.getString("uid")).append("::")
            }
            if (addr.length() >= 2) {
              response = addr.substring(0, addr.length() - 2).replaceAll("[,\\s]*", "")
              uids = uid.substring(0, uid.length() - 2)
            }
          } catch {
            case e: Exception => println(line)
          }
        }

        if (url.contains("&uid=")) {
          groupId = url.substring(url.indexOf("&uid=") + 5)
          if (groupId.contains("&")) {
            groupId = groupId.substring(0, groupId.indexOf("&"))
          }
        }
        if (StringUtils.isBlank(groupId)) {
          groupId = "none"
        }
        if (url.contains("isclick")) {
          val temp = url.substring(url.indexOf("isclick=") + 8, url.indexOf("isclick=") + 9)
          if (temp.matches("[0-9]"))
            click = temp.toInt
        }
        if (url.contains("&gid=")) {
          gid = url.substring(url.indexOf("&gid=") + 5)
          if (gid.contains("&")) {
            gid = gid.substring(0, gid.indexOf("&"));
          }
        }

        try {
          sys_order_no = json.getJSONObject("data").getJSONObject("result").getJSONObject("Query").getString("sys_order_no")
        } catch {
          case e: Exception => logger.error("e" + e)
        }

        try {
          sver = json.getJSONObject("data").getJSONObject("result").getString("sver")
          iver = json.getJSONObject("data").getJSONObject("result").getString("iver")
        } catch {
          case e: Exception => logger.error("e" + e)
        }

        try {
          sn = json.getString("sn")
        } catch {
          case e: Exception => logger.error("e" + e)
        }


      }
      //(String, String, String, String, String, Int, String, String, Int, Int, String, String, String, String, Int, Int, Int, Int, Int, Int, Int, Int
      (province, city, district, q, src, flag, ak, groupId, click, respTime, timestamp.toString, uids, response, gid, sys_order_no, sver, iver, sn, url)
    }).filter(_._5 != null).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dataFrame cnt:" + dataFrame.count())
    logs.unpersist()

    val schema = StructType(
      List(StructField("province", StringType, true),
        StructField("city", StringType, true),
        StructField("district", StringType, true),
        StructField("q", StringType, true),
        StructField("src", StringType, true),
        StructField("flag", IntegerType, true),
        StructField("ak", StringType, true),
        StructField("groupId", StringType, true),
        StructField("click", IntegerType, true),
        StructField("respTime", IntegerType, true),
        StructField("timestamps", StringType, true),
        StructField("uids", StringType, true),
        StructField("response", StringType, true),
        StructField("clkSrc", StringType, true),
        StructField("clkInputLen", IntegerType, true),
        StructField("clkInputReq", IntegerType, true),
        StructField("clkRespPosition", IntegerType, true),
        StructField("finalClick", IntegerType, true),
        StructField("isPaste", IntegerType, true),
        StructField("req_dup", IntegerType, true),
        StructField("isOneReq", IntegerType, true),
        StructField("useTime", LongType, true),
        StructField("input_word_count", IntegerType, true),
        StructField("final_word_count", IntegerType, true),
        StructField("is_group_last", IntegerType, true),
        StructField("input_word_rate", DoubleType, true),
        StructField("gid", StringType, true),
        StructField("sys_order_no", StringType, true),
        StructField("sver", StringType, true),
        StructField("iver", StringType, true),
        StructField("sn", StringType, true),
        StructField("url", StringType, true)
      )
    )

    val df = new DecimalFormat("0.0000")
    //(province, city, district, q, src, flag, ak, groupId, click, respTime, timestamp, uids, response)
    val hasUidRdd = dataFrame.filter(line => !"none".equals(line._8) && !"".equals(line._8)).groupBy(_._8).map(line => {
      val result = new ArrayBuffer[RowObj]()
      val list = line._2.toList.sortBy(_._11)
      var isPaste = 0
      if (list.head._4.length >= 10) {
        isPaste = 1
      }
      var isOneReq = 1
      var useTime = 0L
      if (list.size > 1) {
        isOneReq = 0
        useTime = list.last._11.toLong - list.head._11.toLong
      }

      //计算输入文字比例 = 用户下单字数/最终下单字数
      var inputWordCount: Int = 0
      //用户输入字数
      var finalWordCount: Int = 0 //最终下单字数--非粘贴组最后一条的字数
      if (isPaste == 0) {
        val qLengthList = list.toStream.map(obj => {
          (obj._9, obj._4.length)
        }).toList
        if (qLengthList.nonEmpty) finalWordCount = qLengthList.last._2
        var tempNum = 0
        for (ele <- qLengthList) {
          if (ele._1 == 0) {
            inputWordCount += (ele._2 - tempNum)
          }
          tempNum = ele._2
        }
      }

      //统计输入文字比例
      var input_word_rate_before = "0.0000"
      if (finalWordCount != 0) input_word_rate_before = df.format(inputWordCount.toDouble / finalWordCount.toDouble)
      var input_word_rate = input_word_rate_before.toDouble

      for ((elem, count) <- list.zipWithIndex) {
        var finalClick = 0
        if (count + 1 == list.size && elem._9 == 1) {
          finalClick = 1
        }
        var clkSrc = ""
        var clkInputLen = 0
        var clkInputReq = 0
        var clkRespPosition = 0
        var req_dup = 0
        var is_group_last = 0 //是否是每组最后一条 0否 1是
        if (count > 0) {
          if (count == list.length - 1) is_group_last = 1
          if (elem._4.equals(list(count - 1)._4) && elem._2.equals(list(count - 1)._2) && elem._5.equals(list(count - 1)._5)) {
            req_dup = 1
          }
          if (elem._9 == 1) {
            val resps = list(count - 1)._13.split("::").toList
            if (resps.indexOf(elem._4) >= 0) {
              clkRespPosition = resps.indexOf(elem._4) + 1
              clkInputReq = count + 1
              clkInputLen = list(count - 1)._4.length
              if (StringUtils.isBlank(list(count - 1)._5)) {
                clkSrc = "-"
              } else {
                clkSrc = list(count - 1)._5
              }
            } else {
              clkSrc = "-"
            }
          }

        } else {
          if (elem._9 == 1) {
            clkSrc = "-"
          }
        }
        result += RowObj(elem._1, elem._2, elem._3, elem._4, elem._5, elem._6, elem._7, elem._8, elem._9, elem._10, elem._11, elem._12, elem._13, clkSrc, clkInputLen, clkInputReq, clkRespPosition, finalClick, isPaste, req_dup, isOneReq, useTime, inputWordCount, finalWordCount, is_group_last, input_word_rate, elem._14, elem._15, elem._16, elem._17, elem._18, elem._19)
        useTime = 0L
        inputWordCount = 0
        finalWordCount = 0
        input_word_rate = 0.0000
      }
      (line._1, result.toList)
    }).flatMap(_._2.iterator).map(obj => Row(obj.province, obj.city, obj.district, obj.q, obj.src, obj.flag, obj.ak, obj.groupId, obj.click, obj.respTime, obj.timestamps, obj.uids, obj.response, obj.clkSrc, obj.clkInputLen, obj.clkInputReq, obj.clkRespPosition, obj.finalClick, obj.isPaste, obj.req_dup, obj.isOneReq, obj.useTime, obj.input_word_count, obj.final_word_count, obj.is_group_last, obj.input_word_rate, obj.gid, obj.sys_order_no, obj.sver, obj.iver, obj.sn, obj.url)).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("hasUidRdd cnt:" + hasUidRdd.count())

    val noUidRdd = dataFrame.filter(line => "none".equals(line._8) || "".equals(line._8)).map(line => {
      var clkSrc = ""
      if (line._9 == 1) {
        clkSrc = "-"
      }
      val clkInputLen = 0
      val clkInputReq = 0
      val clkRespPosition = 0
      val finalClick = 0
      val isPaste = 0
      val req_dup = 0
      val isOneReq = 0
      val useTime = 0L
      val input_word_count = 0
      val final_word_count = 0
      val is_group_last = 0
      val input_word_rate = 0.0000
      RowObj(line._1, line._2, line._3, line._4, line._5, line._6, line._7, line._8, line._9, line._10,
        line._11, line._12, line._13, clkSrc, clkInputLen, clkInputReq, clkRespPosition, finalClick, isPaste, req_dup, isOneReq, useTime, input_word_count, final_word_count, is_group_last, input_word_rate, line._14, line._15, line._16, line._17, line._18, line._19)
    }).repartition(10).map(obj => Row(obj.province, obj.city, obj.district, obj.q, obj.src, obj.flag, obj.ak, obj.groupId, obj.click, obj.respTime, obj.timestamps, obj.uids, obj.response, obj.clkSrc, obj.clkInputLen, obj.clkInputReq, obj.clkRespPosition, obj.finalClick, obj.isPaste, obj.req_dup, obj.isOneReq, obj.useTime, obj.input_word_count, obj.final_word_count, obj.is_group_last, obj.input_word_rate, obj.gid, obj.sys_order_no, obj.sver, obj.iver, obj.sn, obj.url)).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("noUidRdd cnt:" + noUidRdd.count())
    dataFrame.unpersist()


    sparkSession.sql(String.format("alter table dm_gis.gis_inputtip_mroservice drop if EXISTS partition(inc_day='%s')", incDay))
    val tempTableName1 = "gis_inputtip_mroservice_temp1" + System.currentTimeMillis()
    sparkSession.createDataFrame(hasUidRdd.union(noUidRdd), schema).toDF().createOrReplaceTempView(tempTableName1)
    sparkSession.sql("select * from " + tempTableName1).show(10)
    sparkSession.sql(s"insert overwrite table dm_gis.gis_inputtip_mroservice partition(inc_day='${incDay}') select province,city,district,q,src,flag," +
      "ak,groupId,click,respTime,timestamps,uids,response,clkSrc,clkInputLen,clkInputReq,clkRespPosition,finalClick,isPaste,req_dup,isOneReq,useTime,input_word_count,final_word_count,is_group_last,input_word_rate,gid,sys_order_no,sver,iver,sn,url from " + tempTableName1)

    logger.error("------------数据入hive结束--------------------------")
  }


}
