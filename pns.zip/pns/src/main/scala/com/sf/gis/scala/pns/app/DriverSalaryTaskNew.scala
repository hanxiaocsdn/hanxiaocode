package com.sf.gis.scala.pns.app

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel


/**
 * 【司机计提】异常封车数据对接tcas_V1.0
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：957657
 * 任务名称：自营司机任务状态变更明细
 */
object DriverSalaryTaskNew {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def execute(spark: SparkSession, inc_day: String) = {
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore2 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 2)
    val dayBefore4 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 4)

    import spark.implicits._
    val task_old_sql =
      s"""
         |select
         |  task_id,
         |  task_type,
         |  is_rational,
         |  '' as change,
         |  inc_day
         |from
         |  dm_tdsp.self_driver_salary_task_dtl_di
         |where
         |  inc_day >= '$dayBefore4'
         |  and inc_day <= '$dayBefore1'
         |  and task_type = '空驶任务'
         |""".stripMargin
    println(task_old_sql)
    val df_task_old = spark.sql(task_old_sql)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val task_new_sql =
      s"""
         |select
         |  task_id,
         |  is_rational as is_rational_new,
         |  inc_day
         |from
         |  dm_gis.dm_driver_salary_task_new_di
         |where
         |  inc_day >= '$dayBefore4'
         |  and inc_day <= '$dayBefore2'
         |""".stripMargin
    println(task_new_sql)
    val df_task_new = spark.sql(task_new_sql)

    val df_add= df_task_old
      .filter('inc_day >= dayBefore4 and 'inc_day <= dayBefore2)
      .join(df_task_new,Seq("task_id","inc_day"),"left")
      .withColumn("change",when('is_rational === "合理" and 'is_rational_new === "不合理",1)
        .when('is_rational === "不合理" and 'is_rational_new === "合理",2)
        .otherwise(3)
      )
      .filter('change === 1 or 'change === 2)
      .withColumn("is_rational",'is_rational_new)
      .withColumn("inc_day",lit(dayBefore1))
      .select("task_id","task_type","is_rational","change","inc_day")

    val df_all_task = df_task_old
      .filter('inc_day === dayBefore1)
      .select("task_id", "task_type", "is_rational", "change", "inc_day")
      .union(df_add)

    val cols = spark.sql("""select * from dm_gis.dm_driver_salary_task_new_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_all_task.select(cols: _*),Seq("inc_day"),"dm_gis.dm_driver_salary_task_new_di")

    df_task_old.unpersist()
  }

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20240122  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}
