package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.SparkUtil
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

class GisEtaJiaZhiCostGrd {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

    def read_data(spark: SparkSession, incDay: String): Unit = {
        spark.udf.register("get_before_day", new GisEtaDriveLogReject().get_min_date_before_30day _)
        val sql =
            s"""
               |select
               |    grd1,
               |    grd2,
               |    road_fee,
               |    fuel_cost,
               |    miles,
               |    sum_cost,
               |    conduct_type,
               |    case when reject_flag is not null then reject_flag
               |         when road_fee_flag = 0 and miles_flag = 0 then 0
               |         when road_fee_flag = 0 and miles_flag != 0 then miles_flag
               |         when road_fee_flag != 0 and miles_flag = 0 then road_fee_flag
               |         else concat(road_fee_flag, "|", miles_flag) end reject_flag,
               |    date_type
               |from
               |(
               |    select
               |        t2.*,
               |        case when t3.miles_flag is not null then t3.miles_flag
               |             when t2.miles is null or t2.miles = '' or t2.miles = 0 then 1
               |             else 0 end as miles_flag,
               |        case when t3.road_fee_flag is not null then t3.road_fee_flag
               |             when t2.road_fee is null or t2.road_fee = '' or t2.road_fee = 0 then 1
               |             else 0 end as road_fee_flag,
               |        t3.reject_flag
               |    from
               |    (
               |        select
               |            task_id,
               |            grd1,
               |            grd2,
               |            road_fee,
               |            fuel_cost,
               |            miles,
               |            sum_cost,
               |            conduct_type,
               |            if (task_inc_day >= min_day, '上线期', '基准期') date_type
               |        from
               |        (
               |            select
               |                task_id,
               |                grd1,
               |                grd2,
               |                road_fee,
               |                fuel_cost,
               |                miles,
               |                sum_cost,
               |                conduct_type,
               |                task_inc_day,
               |                get_before_day(online_date, 60) as nday,
               |                get_before_day(online_date, 0)   as min_day
               |            from dm_gis.gis_eta_jiazhi_cost_new
               |            where inc_day = '$incDay' and online_date is not null and online_date <> ''
               |        ) t1
               |        where task_inc_day >= nday
               |    ) t2
               |    left join (select * from dm_gis.gis_eta_drive_log_reject where inc_day in (
               |            select max(inc_day) inc_day from dm_gis.gis_eta_drive_log_reject)
               |        ) t3
               |    on t2.task_id = t3.task_id
               |) t4
               |""".stripMargin

        LOGGER.info(sql)
        spark.sql(sql).createOrReplaceTempView("base_table")
    }

    def insert_grd1(spark: SparkSession, incDay: String): Unit = {
        val sql =
            s"""
               |with t1 as (
               |    select
               |        grd1,
               |        avg(road_fee)   as cp_road_fee1,
               |        avg(fuel_cost)  as cp_fuel_cost1,
               |        avg(miles)      as cp_miles1,
               |        avg(sum_cost)   as cp_sum_cost1
               |    from base_table
               |    where date_type = '基准期' and conduct_type = 3 and (reject_flag = 0 or reject_flag is null or reject_flag = '')
               |    group by grd1
               |),
               |t2 as (
               |    select
               |        grd1,
               |        avg(road_fee)   as unexe_road_fee1,
               |        avg(fuel_cost)  as unexe_fuel_cost1,
               |        avg(miles)      as unexe_miles1,
               |        avg(sum_cost)   as unexe_sum_cost1
               |    from base_table
               |    where date_type = '上线期' and conduct_type = 3 and (reject_flag = 0 or reject_flag is null or reject_flag = '')
               |    group by grd1
               |)
               |insert overwrite table dm_gis.gis_eta_jiazhi_cost_grd1 partition (inc_day = '$incDay')
               |select
               |    t.grd1,
               |    if(t1.cp_road_fee1 is null, 0, t1.cp_road_fee1)          as cp_road_fee1,
               |    if(t1.cp_fuel_cost1 is null, 0, t1.cp_fuel_cost1)        as cp_fuel_cost1,
               |    if(t1.cp_miles1 is null, 0, t1.cp_miles1)                as cp_miles1,
               |    if(t1.cp_sum_cost1 is null, 0, t1.cp_sum_cost1)          as cp_sum_cost1,
               |    if(t2.unexe_road_fee1 is null, 0, t2.unexe_road_fee1)    as unexe_road_fee1,
               |    if(t2.unexe_fuel_cost1 is null, 0, t2.unexe_fuel_cost1)  as unexe_fuel_cost1,
               |    if(t2.unexe_miles1 is null, 0, t2.unexe_miles1)          as unexe_miles1,
               |    if(t2.unexe_sum_cost1 is null, 0, t2.unexe_sum_cost1)    as unexe_sum_cost1
               |from (select grd1 from base_table group by grd1) t
               |left join t1 on t.grd1 = t1.grd1
               |left join t2 on t.grd1 = t2.grd1
               |""".stripMargin

        LOGGER.info(sql)
        spark.sql(sql)
        LOGGER.info("dm_gis.gis_eta_jiazhi_cost_grd1表数据插入成功")
    }

    def insert_grd2(spark: SparkSession, incDay: String): Unit = {
        val sql =
            s"""
               |with t1 as (
               |    select
               |        grd2,
               |        avg(road_fee)   as cp_road_fee2,
               |        avg(fuel_cost)  as cp_fuel_cost2,
               |        avg(miles)      as cp_miles2,
               |        avg(sum_cost)   as cp_sum_cost2
               |    from base_table
               |    where date_type = '基准期' and conduct_type = 3 and (reject_flag = 0 or reject_flag is null or reject_flag = '')
               |    group by grd2
               |),
               |t2 as (
               |    select
               |        grd2,
               |        avg(road_fee)   as unexe_road_fee2,
               |        avg(fuel_cost)  as unexe_fuel_cost2,
               |        avg(miles)      as unexe_miles2,
               |        avg(sum_cost)   as unexe_sum_cost2
               |    from base_table
               |    where date_type = '上线期' and conduct_type = 3 and (reject_flag = 0 or reject_flag is null or reject_flag = '')
               |    group by grd2
               |)
               |insert overwrite table dm_gis.gis_eta_jiazhi_cost_grd2 partition (inc_day = '$incDay')
               |select
               |    t.grd2,
               |    if(t1.cp_road_fee2 is null, 0, t1.cp_road_fee2)          as cp_road_fee2,
               |    if(t1.cp_fuel_cost2 is null, 0, t1.cp_fuel_cost2)        as cp_fuel_cost2,
               |    if(t1.cp_miles2 is null, 0, t1.cp_miles2)                as cp_miles2,
               |    if(t1.cp_sum_cost2 is null, 0, t1.cp_sum_cost2)          as cp_sum_cost2,
               |    if(t2.unexe_road_fee2 is null, 0, t2.unexe_road_fee2)    as unexe_road_fee2,
               |    if(t2.unexe_fuel_cost2 is null, 0, t2.unexe_fuel_cost2)  as unexe_fuel_cost2,
               |    if(t2.unexe_miles2 is null, 0, t2.unexe_miles2)          as unexe_miles2,
               |    if(t2.unexe_sum_cost2 is null, 0, t2.unexe_sum_cost2)    as unexe_sum_cost2
               |from (select grd2 from base_table group by grd2) t
               |left join t1 on t.grd2 = t1.grd2
               |left join t2 on t.grd2 = t2.grd2
               |""".stripMargin

        LOGGER.info(sql)
        spark.sql(sql)
        LOGGER.info("dm_gis.gis_eta_jiazhi_cost_grd2表数据插入成功")
    }

    def execute(spark: SparkSession, incDay: String): Unit = {
        read_data(spark, incDay)
        insert_grd1(spark, incDay)
        insert_grd2(spark, incDay)
    }
}

object GisEtaJiaZhiCostGrd {
    def main(args: Array[String]): Unit = {
        val task = new GisEtaJiaZhiCostGrd
        if (args == null || args.length == 0 || StringUtils.isEmpty(args(0))) {
            task.LOGGER.error("请传入日期参数")
            return
        }
        val incDay = args(0)
        task.LOGGER.info("###########################################")
        task.LOGGER.info("incDay: [{}]", incDay)
        task.LOGGER.info("###########################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession

        task.execute(spark, incDay)
        task.LOGGER.info("任务执行完成")

        spark.stop()
    }
}
