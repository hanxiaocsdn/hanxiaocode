package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.pns.utils.Functions.{isEmptyOrNull, timeToCustomTime2, tranTimeToLong}
import com.sf.gis.scala.pns.utils.SparkUtils.{row2Json, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import java.text.SimpleDateFormat
import java.util.Date
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * 【燃油耗能】车辆载货/自定义任务燃油管控V1.1
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：768639
 * 任务名称：非任务场景下轨迹明细
 */
object NonTaskVehicleInfo {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  //val Track_Query: String = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrateDetail"
  val TrackQueryUrl: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"  // 新轨迹中台迁移 20230821
  val TrackQueryAK: String = "93ec117f7f1b4226b4e537c4802319e9"
  val parallelism = 10
  val akMinuLimit = 4000

  // 获取hive数据
  def getDataSouse(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    val dayBefore_1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", -1)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val dayBefore4 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 4)
    val dayBefore30 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 30)
    val monthBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 90).substring(0,6)

    // 获取车牌
    val order_sql =
      s"""
         |select
         |  vehicle_code    as   vehicle_serial,
         |  '$dayBefore1'   as   dayBefore1,
         |  '$dayBefore4'   as   dayBefore4,
         |  count(1)        as   cn
         |from
         |  dm_tdsp.dm_tp_grd_fuel_park_urgent_fuel_explode_mi
         |where
         |  vehicle_code <> ''
         |  and vehicle_code is not null
         |  and inc_month in (
         |    select
         |      inc_month
         |    from
         |      dm_tdsp.dm_tp_grd_fuel_park_urgent_fuel_explode_mi
         |    where
         |      inc_month >= '$monthBefore3'
         |    group by
         |      inc_month
         |    order by
         |      inc_month desc
         |    limit 1)
         |group by
         |  vehicle_code
         |""".stripMargin
    println("获取加油订单表数据 sql语句：")
    println(order_sql)
    val df_order = spark.sql(order_sql).drop("cn")

    // 获取载货任务
    val task_sql =
      s"""
         |select
         |  state,
         |  task_id,
         |  vehicle_serial,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  inc_day
         |from
         |  ods_russtask.tt_vehicle_task_monitor
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore_1'
         |  --and substr(actual_depart_tm,0,10) >= '$dayBefore3'
         |  --and substr(actual_depart_tm,0,10) <= '$dayBefore_1'
         |  and carrier_type = '0'
         |  and state <> '1'
         |  and actual_depart_tm <> ''
         |  and actual_depart_tm is not null
         |""".stripMargin
    println("获取车辆任务监控表数据 sql语句：")
    println(task_sql)
    val df_task = spark.sql(task_sql)
      // 数据过滤和去重
      .withColumn("actual_depart_day",timeToCustomTime2('actual_depart_tm,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("tmp_arrive_tm",timeToCustomTime2(lit(dayBefore_1),lit("yyyyMMdd"),lit("yyyyMMddHHmmss")))
      .withColumn("actual_arrive_tm",when('state === "4", 'tmp_arrive_tm).otherwise('actual_arrive_tm))
      .withColumn("filter_flag",when(('state === "2" or 'state === "3" or 'state === "5" or 'state === "6") and !isEmptyOrNull('actual_depart_tm) and !isEmptyOrNull('actual_arrive_tm), true).otherwise(false))
      .filter('filter_flag and 'actual_depart_day >= dayBefore3 and 'actual_depart_day <= dayBefore_1)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("inc_day"),desc("state"))))
      .filter('rn === 1)  // 按照任务id去重
      .drop("rn")
      //时间转为 10位时间戳
      .withColumn("actual_depart_tm",substring(tranTimeToLong('actual_depart_tm,lit("yyyy-MM-dd HH:mm:ss")),0,10))
      .withColumn("actual_arrive_tm",substring(tranTimeToLong('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss")),0,10))
      .select("task_id","vehicle_serial","actual_depart_tm","actual_arrive_tm","inc_day")

    // 获取空驶任务
    val parse1_sql =
      s"""
         |select
         |  task_id,
         |  vehicle_serial,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  from_unixtime(actual_depart_tm/1000) AS actual_depart_day,
         |  inc_day
         |from
         |  dm_gis.gis_eta_ts_accural_parse1
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore_1'
         |  and length(task_id) > 13
         |""".stripMargin
    println("获取空驶任务信息 sql语句：")
    println(parse1_sql)
    val df_parse1 = spark.sql(parse1_sql)
      // 数据过滤和去重
      .withColumn("filter_flag", when(!isEmptyOrNull('actual_depart_tm) and !isEmptyOrNull('actual_arrive_tm), true).otherwise(false))
      .withColumn("actual_depart_day", timeToCustomTime2('actual_depart_day, lit("yyyy-MM-dd HH:mm:ss"), lit("yyyyMMdd")))
      .filter('filter_flag and 'actual_depart_day >= dayBefore3 and 'actual_depart_day <= dayBefore_1)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("inc_day"))))
      .filter('rn === 1) // 按照任务id去重
      .drop("rn")
      //时间转为 10位时间戳
      .withColumn("actual_depart_tm", substring('actual_depart_tm, 0, 10))
      .withColumn("actual_arrive_tm", substring('actual_arrive_tm, 0, 10))
      .select("task_id","vehicle_serial","actual_depart_tm","actual_arrive_tm","inc_day")

    // 载货任务和空驶任务合并
    val df_all_task = df_task.union(df_parse1)

    // 获取人脸识别结果
    val face_img_sql =
      s"""
         |select
         |  record_id,
         |  sfcode,
         |  score
         |from
         |  dm_gis.tt_fengtu_face_img
         |where
         |  inc_day = '$dayBefore1'
         |  and result <> ''
         |  and result is not null
         |  and sfcode <> ''
         |  and sfcode is not null
         |""".stripMargin
    println("获取人脸识别结果数据 sql语句：")
    println(face_img_sql)
    val df_face_img = spark.sql(face_img_sql)

    // 获取人脸识别入参数据
    val push_detail_sql =
      s"""
         |select
         |  car_no as vehicle_serial,
         |  start_time,
         |  end_time,
         |  record_id
         |from
         |  dm_gis.plan_face_recognition_push_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("获取人脸识别图片推送明细表数据 sql语句：")
    println(push_detail_sql)
    val df_push_detail = spark.sql(push_detail_sql)
      .join(df_face_img,Seq("record_id"),"left")
      .withColumn("num", row_number().over(Window.partitionBy('vehicle_serial,'start_time,'end_time).orderBy(desc("score"))))
      .groupBy("vehicle_serial","start_time","end_time")
      .agg(
        max(when('num === 1, 'sfcode).otherwise(0)) as "sfcode",
        max(when('num === 1, 'score).otherwise(0)) as "score",

        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('sfcode)) as "sfcode1",
        concat_ws("|",collect_list('score)) as "score1"
      )
      .withColumn("sfcode1",sortField('num,'sfcode1))
      .withColumn("score1",sortField('num,'score1))
      .drop("num")

    (df_order,df_all_task,df_push_detail)
  }

  /**
   * 分组收集后的排序函数，保证分组收集的所有字段顺序一一对应
   * @return
   */
  def sortField = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("\\|")
      val other_arr = other.split("\\|")
      val new_arr = num_arr.zip(other_arr).sortWith((x, y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })

  //解析线路查询接口返回值，并对轨迹分组
  def parseTrackQueryHttpData2(ret: JSONObject): (String, String, String,Double) = {
    var distance = 0.0
    if (ret != null) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null,distance)
      } else {
        var tracks = new JSONArray() // 原始轨迹点
        var stayPoints = new JSONArray()

        try {
          tracks = ret.getJSONObject("result").getJSONObject("data").getJSONArray("track")
          stayPoints = ret.getJSONObject("result").getJSONObject("data").getJSONArray("stayPoints")
          distance = ret.getJSONObject("result").getJSONObject("data").getDouble("len")
        } catch {
          case e: Exception => logger.error(e)
        }

        // 剔除停留点
        for (i <- 0 until stayPoints.size()) {
          val stayPoint = stayPoints.getJSONObject(i)
          val startTime = stayPoint.getLong("startTime")
          val endTime = stayPoint.getLong("endTime")

          val tracks_tmp = new JSONArray()
          for (j <- 0 until tracks.size()) {
            val track = tracks.getJSONObject(j)
            val tm = track.getLong("tm")
            if(tm <= startTime || tm >= endTime){
              tracks_tmp.add(track)
            }
          }

          tracks = tracks_tmp
        }

        // 对轨迹分组,轨迹点相差5分钟之内的为一组，保留轨迹每组轨迹的开始和结束时间戳
        var start_time = 0L
        var end_time = 0L
        val track_tm = new ArrayBuffer[String]()
        for (i <- 0 until tracks.size()) {
          val track = tracks.getJSONObject(i)
          val tm = track.getLong("tm")

          if (i == 0) {
            start_time = tm
            end_time = tm
          } else if(i != tracks.size-1){
            if ((tm - end_time) < 5 * 60) {
              end_time = tm
            } else {
              track_tm.append(s"$start_time,$end_time")
              start_time = tm
              end_time = tm
            }
          }else{
            end_time = tm
            track_tm.append(s"$start_time,$end_time")
          }

        }

        return (codeStatue, "成功", track_tm.mkString("|"),distance)
      }
    }
    ("22", "接口返回值为空", null,distance)
  }

  /**
   * 调用轨迹查询接口,获取轨迹点和时间
   * @param spark
   * @param dataDF
   */
  def runTrackQueryInteface2(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val dayBefore1 = JSONUtil.getJsonVal(obj, "dayBefore1", "")
    val dayBefore4 = JSONUtil.getJsonVal(obj, "dayBefore4", "")

    // 将时间戳转换成接口需要的格式
    val beginDateTime = s"${dayBefore1}000000"
    val endDateTime = s"${dayBefore1}235959"

    //初始化轨迹查询接口请求参数
    val param = new JSONObject()
    param.put("addpoint", 1)
    param.put("type", "401")
    param.put("un",vehicle_serial)
    param.put("unType","0")
    param.put("beginDateTime",beginDateTime)
    param.put("endDateTime",endDateTime)
    //v1.7 新增2个入参
    param.put("stayDuration",300)
    param.put("stayRadius",100)
    param.put("ak", ak)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(TrackQueryUrl,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析线路查询接口返回值
    val httpData: (String, String, String, Double) = parseTrackQueryHttpData2(retJSONObject)

    // 查询线路接口新增字段
    obj.put("track_tm",httpData._3)
    obj.put("codeStatue",httpData._1)

    obj
  }

  /**
   * 调用轨迹查询接口,获取轨迹点和时间
   * @param spark
   * @param dataDF
   */
  def runTrackQueryInteface3(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val start_time = JSONUtil.getJsonLong(obj, "start_time", 0)
    val end_time = JSONUtil.getJsonLong(obj, "end_time", 0)

    // 将时间戳转换成接口需要的格式
    var beginDateTime = ""
    var endDateTime = ""
    try {
      val sdf = new SimpleDateFormat("yyyyMMddHHmmss")
      beginDateTime = sdf.format(new Date(start_time*1000))
      endDateTime = sdf.format(new Date(end_time*1000))
    } catch {
      case e:Exception =>println(">>>时间戳解析异常:"+e)
    }

    //初始化轨迹查询接口请求参数
    val param = new JSONObject()
    param.put("addpoint", 1)
    param.put("type", "401")
    param.put("un",vehicle_serial)
    param.put("unType","0")
    param.put("beginDateTime",beginDateTime)
    param.put("endDateTime",endDateTime)
    param.put("ak", ak)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(TrackQueryUrl,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析线路查询接口返回值
    val httpData: (String, String, String, Double) = parseTrackQueryHttpData2(retJSONObject)

    // 查询线路接口新增字段
    obj.put("distance",httpData._4)

    obj
  }


  def getGisEtaNonTaskTrackInfo(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    // 获取hive数据
    val (df_order,df_all_task,df_push_detail) = getDataSouse(spark,incDay)

    val invokeCnt_1 = df_order.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "768639", "非任务场景下轨迹明细", "获取线路轨迹", TrackQueryUrl, TrackQueryAK, invokeCnt_1, parallelism)
    // 调标准线路查询接口
    val rdd_order_tm = SparkNet.runInterfaceWithAkLimit(spark, df_order.rdd.map(row2Json), runTrackQueryInteface2, parallelism, TrackQueryAK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)

   val rdd_vehicle_tm = rdd_order_tm.flatMap(obj=>{
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val track_tm = JSONUtil.getJsonVal(obj, "track_tm", "")
      val codeStatue = JSONUtil.getJsonVal(obj, "codeStatue", "")

      val tm_arr = track_tm.split("\\|")
      val tmpArray = new ArrayBuffer[JSONObject]()
      for (tm <- tm_arr) {
        val tmpObj = new JSONObject()
        var start_time = ""
        var end_time = ""
        try {
          start_time = tm.split(",")(0)
          end_time = tm.split(",")(1)
        } catch {
          case e: Exception => logger.error(e)
        }

        tmpObj.put("vehicle_serial",vehicle_serial)
        tmpObj.put("start_time",start_time)
        tmpObj.put("end_time",end_time)
        tmpObj.put("track_tm",track_tm)
        tmpObj.put("codeStatue",codeStatue)
        tmpArray.append(tmpObj)
      }
      tmpArray.iterator
    }).filter(obj=>{
     val codeStatue = JSONUtil.getJsonVal(obj, "codeStatue", "")
     val start_time = JSONUtil.getJsonVal(obj, "start_time", "")
     val end_time = JSONUtil.getJsonVal(obj, "end_time", "")
     codeStatue == "0" && start_time != end_time
   })  // 过滤掉轨迹为空和开始结束时间相等的数据

    val invokeCnt_2 = rdd_vehicle_tm.count()
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "768639", "非任务场景下轨迹明细", "获取线路轨迹", TrackQueryUrl, TrackQueryAK, invokeCnt_2, parallelism)
    // 调标准线路查询接口
    val rdd_distance_tm = SparkNet.runInterfaceWithAkLimit(spark, rdd_vehicle_tm, runTrackQueryInteface3, parallelism, TrackQueryAK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    val df_distance_tm = rdd_distance_tm.map(obj=>{
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val start_time = JSONUtil.getJsonVal(obj, "start_time", "")
      val end_time = JSONUtil.getJsonVal(obj, "end_time", "")
      val track_tm = JSONUtil.getJsonVal(obj, "track_tm", "")
      val codestatue = JSONUtil.getJsonVal(obj, "codeStatue", "")
      val distance = JSONUtil.getJsonDouble(obj, "distance", 0.0)

      (vehicle_serial,start_time,end_time,track_tm,codestatue,distance)
    }).toDF("vehicle_serial","start_time","end_time","track_tm","codestatue","distance")
      .filter('distance >= 500.0)

    // 车辆轨迹分组后和任务轨迹数据关联
    val df_ret = df_distance_tm.join(df_all_task,Seq("vehicle_serial"),"inner")
      .withColumn("coords",when('codestatue === 0,"有").otherwise("无"))
      .withColumn("task_type",when('start_time > 'actual_arrive_tm || 'end_time < 'actual_depart_tm,"非任务场景").otherwise("任务场景"))
      .withColumn("task_id",when('task_type === "任务场景",'task_id).otherwise(""))
      .withColumn("task_flag",when('task_type === "任务场景",0).otherwise(1))
      .withColumn("rn", row_number().over(Window.partitionBy("vehicle_serial","start_time","end_time").orderBy(asc("task_flag"))))
      .filter('rn === 1)  // 分组去重优先保留任务场景数据
      .drop("rn")
      .withColumn("task_time",('end_time - 'start_time) / 60.0)
      .filter('task_time > 2.0)
      .join(df_push_detail,Seq("vehicle_serial","start_time","end_time"),"left")
      .withColumn("inc_day",lit(dayBefore1))

    //关联车辆信息
    val vehicle_sql =
      s"""
         |select
         |  vehicle_code as vehicle_serial,
         |  hq_code,
         |  hq_name,
         |  area_code,
         |  area_name,
         |  motorcade_name
         |from
         |  dim.dim_vehicle_info_df
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("关联车辆信息 sql语句：")
    println(vehicle_sql)
    val df_vehicle = spark.sql(vehicle_sql)

    val resultDF =  df_ret.join(df_vehicle,Seq("vehicle_serial"),"left")

    // 结果表保存至hive
    val cols_ret = spark.sql("""select * from dm_gis.gis_eta_non_task_track_info limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,resultDF.select(cols_ret: _*),Seq("inc_day"),"dm_gis.gis_eta_non_task_track_info")

  }

  def main(args: Array[String]): Unit = {
    // incDay为业务时间，即跑数日期
    val incDay = args(0)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error(s"++++++++ 20240116  任务开始  incDay=$incDay  ++++")
    // 每天更新t-3两天数据,获取人脸识别入参数据
     getGisEtaNonTaskTrackInfo(spark, dayBefore2)  // 跑T-3
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}
