package com.sf.gis.scala.pns.app

import com.sf.gis.java.base.util.{DateUtil, ShellExcutor, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * GIS-RSS-PNS：【价值路线】司机实走轨迹支持月度下载至ftp190
 * 需求方：张萍（01394382）
 * @author 徐游飞（01417347）
 * 任务ID：500872
 * 任务名称：标准路由监控回溯表下载
 */
object EtaStandardLineRecallDownload {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    val start_day = args(0)
    val end_day = args(1)
    logger.error("start_day="+ start_day + ", end_day=" + end_day)

    // 需要下载的hive表
    val tableName = "eta_std_line_recall"
    SaveHiveTableAsTextFile(spark,tableName,start_day,end_day)

    // 需要下载的hive表
    val tableName2 = "rmsa_tm_distance_times_prol"
    SaveHiveTableAsTextFile2(spark,tableName2,start_day,end_day)

    println("任务结束")
    spark.stop()
  }

  def SaveHiveTableAsTextFile(spark: SparkSession, tableName: String, start_day: String, end_day: String) = {

    val end_day_1 = DateUtil.getDayBefore(end_day,"yyyyMMdd",1)
    //将数据保存为TextFile
    //val hdfsPath = s"/hive/warehouse/dm/dm_gis/${tableName}_${start_day}_${end_day_1}"
    val hdfsPath = s"hdfs://sfbd/user/hive/warehouse/dm_gis/${tableName}_${start_day}_${end_day_1}"
    val file = s"./${tableName}_${start_day}_${end_day_1}.csv"

    ShellExcutor.exeCmd(s"hdfs dfs -rm -r $hdfsPath")
    val sql_seg =
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  task_subid,
         |  carrier_type,
         |  concat_ws('_',line_code,start_dept,end_dept,vehicle_type,actual_capacity_load) as linemload,
         |  start_dept,
         |  end_dept,
         |  line_code,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  vehicle_type,
         |  axls_number,
         |  rt_coords,
         |  x1,
         |  y1,
         |  x2,
         |  y2,
         |  time,
         |  rt_dist,
         |  toll_charge,
         |  inc_day,
         |  concat_ws('_','$start_day','$end_day_1') as inc_day_download,
         |  carrier_name
         |from
         |  dm_gis.${tableName}
         |where
         |  inc_day >= '$start_day' and inc_day < '$end_day'
         |  and line_distance >= 20
         |  and halfway_integrate_rate >= '0.9'
         |  and error_type = '0'
         |""".stripMargin

    println("取数sql为:" + sql_seg)
    println(s"$tableName 表数据开始保存至 $hdfsPath")
    val dataDF = spark.sql(sql_seg)
    println(s" $start_day 至 $end_day 的数据量为："+dataDF.count())

    val unit = dataDF.repartition(1)
      .write
      .format("csv")
      .mode("overwrite")
      .option("header", "true")
      .option("sep","\t")
      .save(hdfsPath)
    println(s"$tableName 表数据已保存至： $hdfsPath")

//    println(s"$tableName 表数据开始合并下载至本地： $file")
//    ShellExcutor.exeCmd(s"hdfs dfs -ls -h $hdfsPath")
//    ShellExcutor.exeCmd(s"rm -r $file")
//    ShellExcutor.exeCmd(s"hdfs dfs -getmerge $hdfsPath $file")
//    println(s"$tableName 表数据下载完成")
//
//    println(s"$tableName 表开始压缩数据")
//    ShellExcutor.exeCmd(s"ls -l $file")
//    ShellExcutor.exeCmd(s"rm -r $file.tgz")
//    ShellExcutor.exeCmd(s"tar czf $file.tgz $file")
//    println(s"$tableName 表数据压缩完成")
//
//    println(s"$tableName 表开始上传至ftp:10.116.49.190")
//    ShellExcutor.exeCmd(s"ls -l $file.tgz")
//    //    ShellExcutor.exeCmd(s"curl ftp://gis:L1iwM21xYF@10.116.49.190/FT20220014/ -T $file.tgz")
//    //    ShellExcutor.exeCmd(s"curl -u devftp:brYsj2.023ftKjdev -T ./$file.tgz  ftp://gisftp.sf-express.com/01417347/XYF/$tableName/")
//    ShellExcutor.exeCmd(s"curl -u ywftp:*fTKJ*.123yunwei -T ./$file.tgz  ftp://gisftp.sf-express.com/01417347/XYF/$tableName/")
//    ShellExcutor.exeCmd(s"rm -r $file")
//    ShellExcutor.exeCmd(s"rm -r $file.tgz")
//    println(s"$tableName 表数据上传成功")
  }

  def SaveHiveTableAsTextFile2(spark: SparkSession, tableName: String, start_day: String, end_day: String) = {

    val end_day_1 = DateUtil.getDayBefore(end_day,"yyyyMMdd",1)
    //将数据保存为TextFile
    //val hdfsPath = s"/hive/warehouse/dm/dm_gis/${tableName}_${start_day}_${end_day_1}"
    val hdfsPath = s"hdfs://sfbd/user/hive/warehouse/dm_gis/${tableName}_${end_day_1}"
    val file = s"./${tableName}_${end_day_1}.csv"

    ShellExcutor.exeCmd(s"hdfs dfs -rm -r $hdfsPath")
    val sql_seg =
      s"""
         |select
         |  *
         |from
         |  dm_pass_rss.rmsa_tm_distance_times_pro
         |where
         |  inc_day in (
         |    select
         |      inc_day
         |    from
         |      dm_pass_rss.rmsa_tm_distance_times_pro
         |    where
         |      inc_day >= '$start_day'
         |      and inc_day <= '$end_day_1'
         |    group by
         |      inc_day
         |    order by
         |      inc_day desc
         |    limit 1
         |  )
         |  and oper_type != 3
         |""".stripMargin

    println("取数sql为:" + sql_seg)
    println(s"$tableName 表数据开始保存至 $hdfsPath")
    val dataDF = spark.sql(sql_seg)
    println(s" $start_day 至 $end_day 的数据量为："+dataDF.count())

    val unit = dataDF.repartition(1)
      .write
      .format("csv")
      .mode("overwrite")
      .option("header", "true")
      .option("sep","\t")
      .save(hdfsPath)
    println(s"$tableName 表数据已保存至： $hdfsPath")

//    println(s"$tableName 表数据开始合并下载至本地： $file")
//    ShellExcutor.exeCmd(s"hdfs dfs -ls -h $hdfsPath")
//    ShellExcutor.exeCmd(s"rm -r $file")
//    ShellExcutor.exeCmd(s"hdfs dfs -getmerge $hdfsPath $file")
//    println(s"$tableName 表数据下载完成")
//
//    println(s"$tableName 表开始压缩数据")
//    ShellExcutor.exeCmd(s"ls -l $file")
//    ShellExcutor.exeCmd(s"rm -r $file.tgz")
//    ShellExcutor.exeCmd(s"tar czf $file.tgz $file")
//    println(s"$tableName 表数据压缩完成")
//
//    println(s"$tableName 表开始上传至ftp:10.116.49.190")
//    ShellExcutor.exeCmd(s"ls -l $file.tgz")
//    //    ShellExcutor.exeCmd(s"curl ftp://gis:L1iwM21xYF@10.116.49.190/FT20220014/ -T $file.tgz")
//    //    ShellExcutor.exeCmd(s"curl -u devftp:brYsj2.023ftKjdev -T ./$file.tgz  ftp://gisftp.sf-express.com/01417347/XYF/$tableName/")
//    ShellExcutor.exeCmd(s"curl -u ywftp:*fTKJ*.123yunwei -T ./$file.tgz  ftp://gisftp.sf-express.com/01417347/XYF/$tableName/")
//    ShellExcutor.exeCmd(s"rm -r $file")
//    ShellExcutor.exeCmd(s"rm -r $file.tgz")
//    println(s"$tableName 表数据上传成功")
  }


}
