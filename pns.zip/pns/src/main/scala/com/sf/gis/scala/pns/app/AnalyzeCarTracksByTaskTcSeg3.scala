package com.sf.gis.scala.pns.app

import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.DateUtil
import com.sf.gis.scala.pns.utils.HttpUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager: 孟俊  01370400 ---马荣 ft80006356 孔令其 01367561 这个是经验路径规划数据生产的，应用到路径规划服务里面
 * @Author: 01374443 张想远 (郭老师代码改造)
 * @CreateTime: 2023-03-017 14:06
 * @TaskId:681064
 * @TaskName:AnalyzeCarTracksByTaskTcSeg3-第三部分
 * @Description: 跑接口提供经验数据,上传给算法团队.
 *               针对不同的数据拆分成了3部分，这是第三部分 （第二部分有一些是直接线上的hive+shell任务，纯上传数据）
 */
//任务ID: 489226 测试版本（482949 ）--已变成一次性任务

object AnalyzeCarTracksByTaskTcSeg3 {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  val retTableName = "dm_gis.analyze_cartracks_backinfo";

  //  val retTableName = "tmp_dm_gis.tmp_analyze_cartracks_backinfo_01374443";

  def main(args: Array[String]): Unit = {
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)
    val buildCitys = ""
    val spark = Spark.getSparkSession(appName)
    initBills(spark, checkDate, buildCitys)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def initBills(spark: SparkSession, checkDate: String, buildCitys: String): Unit = {
    //7天前 的数据
    val dayid = DateUtil.getDateStr(checkDate, -7) //20220717
    sendPath(spark, dayid)
    logger.error(s"准备轨迹数据【$dayid】完成")
  }

  def createTotalDataFrame(spark: SparkSession, dayid: String) = {
    val sql = s"""select regexp_replace(un,' |,|\\t|\\r|\\n|\\'|\"|\\\\(|\\\\)|\\\\[|\\\\]|\\\\{|\\\\}|\\\\\\\\|(null)|(NULL)','') as un,zx,zy,ac,tp,tm,ak,sp,be,task_id,zone_from,zone_to,coor_from,coor_to from ${AnalyzeCarTracksByTaskTcSeg.carPathMergeTableName} where inc_day='$dayid' and tm is not null and tm<>'' """
    logger.error(sql)
    val data = spark.sql(sql).distinct().toDF().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val tmpViewName = "tmpView" + System.currentTimeMillis()
    data.createOrReplaceTempView(tmpViewName)
    logger.error("count:" + data.count())

    var unSql = s"""select zone_from,un,count(1) as cnt from $tmpViewName group by zone_from,un"""
    logger.error(unSql)
    val rddUn = spark.sql(unSql).rdd.sortBy(_.getString(0)).map(_.getString(1)).distinct().collect()
    logger.error("un size:" + rddUn.size)

    logger.error("按照用户先预聚合")
    val tmpSql = s"""select un,zx,zy,ac,tp,tm,ak,'3' as vehicle,sp,be,task_id,zone_from,zone_to,coor_from,coor_to from ${tmpViewName} order by zone_from"""
    val totalInputRdd = spark.sql(tmpSql).rdd.groupBy(d => d.getString(0)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("准备轨迹用户数,总用户数：" + totalInputRdd.count())
    data.unpersist()
    (rddUn, totalInputRdd)
  }

  def dropPartition(spark: SparkSession, dayid: String) = {
    val dropSql = s"alter table $retTableName drop if exists partition(inc_day='$dayid')"
    logger.error(dropSql)
    spark.sql(dropSql)
  }

  def rewriteTable(spark: SparkSession, dayid: String) = {
    val sql = s"select * from $retTableName where inc_day='$dayid' "
    logger.error(sql)
    val tmpView = "tmpView" + System.currentTimeMillis()
    spark.sql(sql).toDF().repartition(1).createOrReplaceTempView(tmpView)
    val overwriteSql = s"insert overwrite table $retTableName partition(inc_day) select * from $tmpView"
    logger.error(overwriteSql)
    spark.sql(overwriteSql)
  }

  def sendPath(spark: SparkSession, dayid: String) = {
    import spark.implicits._
    val (rddUn, totalInputRdd) = createTotalDataFrame(spark, dayid)
    val uncnt = rddUn.size
    val batchSize = 1000
    val loopCount = Math.ceil(uncnt.toDouble / batchSize.toDouble).toInt
    var start = 0
    var end = 0
    var invokeCnt = 0l
    var errorCnt = 0l
    //    var totalRdd: Dataset[Row] = null
    dropPartition(spark, dayid)
    for (i <- 0 to loopCount) {
      start = i * batchSize
      end = Math.min((i + 1) * batchSize, uncnt)
      if (start < uncnt) {
        logger.error("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        logger.error("【" + dayid + "】车行用户数：" + uncnt + "\t批量：" + batchSize + "\t迭代数：" + loopCount + "\t批次：" + i + "\t【" + start + " - " + end + "】")
        val uncnd = rddUn.slice(start, end)
        //          .mkString("'", "','", "'")
        //        val sql = s"""select un,zx,zy,ac,tp,tm,ak,'3' as vehicle,sp,be,task_id,zone_from,zone_to,coor_from,coor_to from ${tmpViewName} where un in($uncnd) order by zone_from"""

        //todo remove zip and limit
        //        val pathRdd = spark.sql(sql).rdd.groupBy(d => d.getString(0)).partitionBy(new HashKeyPartitioner(10)).persist(StorageLevel.MEMORY_AND_DISK_SER_2) //.zipWithIndex().filter(_._2<500).map(_._1)
        val pathRdd = totalInputRdd.filter(obj => {
          uncnd.contains(obj._1)
        }).repartition(10).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        val pcnt = pathRdd.count()
        logger.error("准备轨迹用户数：" + pcnt + "，耗时：")
        //        val properties = Util.properties
        val resultRDD = pathRdd.map(i => {
          val un = i._1
          //按taskid,zonefrom,zoneto，及起终点网点坐标切割轨迹

          i._2.groupBy(d => d.getString(10) + "," + d.getString(11) + "," + d.getString(12) + "," + d.getString(13) + "," + d.getString(14)).map(d => {
            val t = d._1.split(",")
            val taskid = t(0)
            val src_deptcode = t(1)
            val dest_deptcode = t(2)
            var x0, y0, x1, y1 = "0"
            //un,zx,zy,ac,tp,tm,ak,'3' as vehicle,sp,be,task_id,zone_from,zone_to,coor_from,coor_to
            val paths = d._2.groupBy(_.getString(6)).toIndexedSeq.sortBy(d => d._2.size).reverse(0)._2

            try {
              if (t(3) != "" && t(3) != "null") {
                val tt = t(3).split(";", 2)
                x0 = if (tt.length > 0 && tt(0) != "") tt(0) else "0"
                y0 = if (tt.length > 1 && tt(1) != "") tt(1) else "0"
              }
              if (t(4) != "" && t(4) != "null") {
                val tt = t(4).split(";", 2)
                x1 = if (tt.length > 0 && tt(0) != "") tt(0) else "0"
                y1 = if (tt.length > 1 && tt(1) != "") tt(1) else "0"
              }
            } catch {
              case e: Exception => logger.error("有空值" + e.getMessage)
            }
            postData(un, paths, dayid, taskid, x0, y0, x1, y1, src_deptcode, dest_deptcode)
          })
        }).flatMap(d => d).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("resultRDD批次完毕，数量：" + resultRDD.count())
        val intm = DateUtil.tranTstampToTime((System.currentTimeMillis() / 1000).toString)

        val res_cols = spark.sql(s"""select * from $retTableName limit 0""").schema.map(_.name).map(col)

        val backInfo = resultRDD.toDF("un", "tm", "backjson", "gdurl4", "crp_backjson", "crp_err", "src_deptcode", "dest_deptcode", "inc_day")
          .withColumn("intm", lit(intm))
          .select(res_cols: _*)
        SparkWrite.appendToHiveDynamics(spark, backInfo.repartition(1), Seq("inc_day"), retTableName)
        //        if (totalRdd == null) {
        //          totalRdd = backInfo.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        //          logger.error("total size:" + totalRdd.count())
        //        } else {
        //          val tmpRdd = totalRdd.union(backInfo).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        //          logger.error("total size:" + tmpRdd.count())
        //          totalRdd.unpersist()
        //          totalRdd = tmpRdd
        //        }
        val finalresult = resultRDD.filter(_ != null)
        val cntinvok = resultRDD.count()
        val cnterror = finalresult.filter(d => d._3 == null || d._4 != null).count()
        invokeCnt += cntinvok
        errorCnt += cnterror
        logger.error("请求量：" + cntinvok + "，返回量：" + finalresult.count() + "，失败量：" + cnterror)
        finalresult.filter(d => d._3 == null || d._4 != null).take(10).foreach(d => println("===================================================================\n" + d._1 + "\n" + d._2 + "\n" + d._3 + "\n" + d._4))
        logger.error("提交数据耗时：")
        resultRDD.unpersist()
        pathRdd.unpersist()
        //finalresult.take(1).foreach(println)
      }
    }
    //    SparkWrite.appendToHiveDynamics(spark, totalRdd.repartition(1), Seq("inc_day"), retTableName)

    logger.error(s"【$dayid】总请求量：$invokeCnt，总失败量：$errorCnt")
    //    totalRdd.unpersist()
    totalInputRdd.unpersist()
    logger.error("重写结果，减少小文件")
    rewriteTable(spark, dayid)
  }

  def postData(un: String, paths: Iterable[Row], checkDate: String, taskid: String, x0: String, y0: String, x1: String, y1: String, src_deptcode: String, dest_deptcode: String) = {
    //    Util.memTime()
    val pathsRows = paths.toIndexedSeq.sortBy(d => d.getString(5).toInt)
    //val billsRows = bills.toIndexedSeq
    val vehicleType = 3
    //val branch = billsRows(0).getString(2)
    val sb = new StringBuilder()
    var c = 0
    //应孔令其要求，city 属性强行存储taskid信息，推送中附带起终点网点位置坐标参数
    //sb.append("{\"start_point_x\":\""+x0+"\",\"city\":\""+taskid+"\",\"carnum\":\"" + un + "\",\"date\":\"" + checkDate + "\",\"vehicle\":" + vehicleType + ",\"retdata\":\"false\",\"tracks\":[")
    sb.append(s"""{"start_point_x":$x0,"start_point_y":$y0,"end_point_x":$x1,"end_point_y":$y1,"city":"$taskid","carnum":"$un","date":"$checkDate","vehicle":$vehicleType,"src_deptcode":"$src_deptcode","dest_deptcode":"$dest_deptcode","retdata":"false","tracks":[""")
    var ftm = "0"
    for (i <- 0 to pathsRows.length - 1) {
      try {
        val row = pathsRows(i)
        //        un,zx,zy,ac,tp,tm,ak,'3' as vehicle,sp,be,task_id,zone_from,zone_to,coor_from,coor_to
        val x = row.getString(1).toDouble
        val y = row.getString(2).toDouble
        var ac = row.getString(3).toInt;
        var tp = row.getString(4).toInt;
        var tm = row.get(5).toString.toLong
        ftm = pathsRows(0).get(5).toString
        val sp = row.getString(8).toDouble
        val be = row.getString(9).toDouble

        if (tm >= 100000000000L)
          tm = (tm / 1000).toInt
        if (c > 0)
          sb.append(",")

        sb.append("{\"type\":" + tp + ",\"x\":" + x + ",\"y\":" + y + ",\"accuracy\":" + ac + ",\"speed\":" + sp + ",\"azimuth\":" + be + ",\"time\":" + tm + "}")
        c += 1
      } catch {
        case e: Exception => {
          logger.error("轨迹数据错误：\n" + pathsRows(i))
          e.printStackTrace()
        }
      }
    }
    sb.append("]")
    sb.append("}")
    val str = sb.toString()

    val gdurl = "http://jysc.int.sfcloud.local:1080/analyzecartracks"
    val gdurl_res = HttpUtil.tryPostWithDetail(gdurl, str, 1)
    //20230522新增 服务推送 20230915下线
    //    val new_gdurl = "http://crp.int.sfcloud.local:1082/processtracks"
    //    val new_gdurl_res = HttpUtil.tryPostWithDetail(new_gdurl, str, 1)

    (un, ftm, gdurl_res._3, gdurl_res._4, "", "", src_deptcode, dest_deptcode, checkDate)
  }

}
