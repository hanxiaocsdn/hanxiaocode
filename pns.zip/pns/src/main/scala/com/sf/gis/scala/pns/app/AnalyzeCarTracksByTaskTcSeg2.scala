package com.sf.gis.scala.pns.app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager: 马荣 ft80006356 孔令其 01367561
 * @Author: 01374443 张想远 (郭老师代码改造)
 * @CreateTime: 2023-03-017 14:06
 * @TaskId:681386
 * @TaskName:AnalyzeCarTracksByTaskTcSeg2-第二部分-准备推送
 * @Description: 跑接口提供经验数据,上传给算法团队
 *               针对不同的数据拆分成了3部分，这是第二部分（第二部分有一些是直接线上的hive+shell任务(681753,AnalyzeCarTracksByTaskTcSeg2-第二步分-推送数据)，纯上传数据）
 */
//任务ID: 489226 测试版本（482949 ）--已变成一次性任务

object AnalyzeCarTracksByTaskTcSeg2 {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def createPart3Table(spark: SparkSession, checkDate: String) = {
    val tmpTable = "default.tmp_esg_gis_loc_trajectory_200"
    val dropSql = s"drop table if exists $tmpTable"
    spark.sql(dropSql)
    val sql =
      s"""create table $tmpTable
         |ROW FORMAT SERDE
         |'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe'
         |WITH SERDEPROPERTIES (
         |'field.delim'=',',
         | 'line.delim'='\n',
         |'serialization.format'=',')
         |STORED AS textfile
         |as select distinct * from dm_gis.esg_gis_loc_trajectory t where t.inc_day='$checkDate' and ak = 200
         |""".stripMargin
    logger.error(sql)
    spark.sql(sql)
  }

  def createPart2Table(spark: SparkSession, checkDate: String) = {
    val tmpTable = "default.tmp_esg_gis_loc_trajectory_no_300"
    val dropSql = s"drop table if exists $tmpTable"
    spark.sql(dropSql)
    val sql =
      s"""create table $tmpTable
         |ROW FORMAT SERDE
         |'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe'
         |WITH SERDEPROPERTIES (
         |'field.delim'=',',
         | 'line.delim'='\n',
         |'serialization.format'=',')
         |STORED AS textfile
         |as
         |select '' as task_id,'' as zone_from,'' as zone_to,'' as coor_from,'' as coor_to,'' as tm_from,'' as tm_to,un,ak,split(concat_ws(',', collect_set(tm)),',')[0] as tm,
         |zx,zy,ac,tp,sp,be from dm_gis.esg_gis_loc_trajectory t where t.inc_day='$checkDate' and ak<>300 and zx>0 and zy>0 and length(un)<=16
         |and un regexp '[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1,2}' GROUP by un,ak,zx,zy,ac,tp,sp,be""".stripMargin
    logger.error(sql)
    spark.sql(sql)
  }

  def createPart1Table(spark: SparkSession, checkDate: String) = {
    val tmpTable = "default.tmp_tt_vehicle_task_pass_zone_monitor_carpath_merge"
    val dropSql = s"drop table if exists $tmpTable"
    spark.sql(dropSql)
    val sql =
      s"""
         |create table $tmpTable
         |ROW FORMAT SERDE
         |'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe'
         |WITH SERDEPROPERTIES (
         |'field.delim'=',',
         | 'line.delim'='\n',
         |'serialization.format'=',')
         |STORED AS textfile
         |as
         |select task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,split(concat_ws(',', collect_set(tm)),',')[0] as tm,zx,zy,ac,tp,sp,be from
         |${AnalyzeCarTracksByTaskTcSeg.carPathMergeTableName} t where t.inc_day='$checkDate' GROUP by task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,zx,zy,ac,tp,sp,be
         |
         |""".stripMargin
    logger.error(sql)
    spark.sql(sql)
  }

  def start(spark: SparkSession, checkDate: String) = {
    createPart1Table(spark, checkDate)
    createPart2Table(spark, checkDate)
    createPart3Table(spark, checkDate)
  }

  def main(args: Array[String]): Unit = {
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)

    val spark = Spark.getSparkSession(appName)
    start(spark, checkDate)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

}
