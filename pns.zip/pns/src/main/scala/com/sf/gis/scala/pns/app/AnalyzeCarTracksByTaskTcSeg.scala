package com.sf.gis.scala.pns.app


import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager: 马荣 ft80006356 孔令其 01367561
 * @Author: 01374443 张想远 (郭老师代码改造)
 * @CreateTime: 2023-03-017 14:06
 * @TaskId:680977
 * @TaskName:AnalyzeCarTracksByTaskTcSeg-第一部分
 * @Description: 跑接口提供经验数据,上传给算法团队
 *               针对不同的数据拆分成了3部分，这是第一部分（第三部分是直接线上的hive+shell任务，纯上传数据）
 */
//任务ID: 489226 测试版本（482949 ）--已变成一次性任务

object AnalyzeCarTracksByTaskTcSeg {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  var envinited = false

  case class FixedPathBAK(x1: String, x2: String, x3: String, x4: String, x5: String, x6: Long, x7: Long, x8: String, x9: String, x10: String, x11: String, x12: String, x13: String, x14: String, x15: String, x16: String, x17: String)

  val tcSeqTableName = "dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq_bak"
  val carPathTableName = "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_bak"
  val carPathMergeTableName = "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge"

  //  val tcSeqTableName = "tmp_dm_gis.tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak_01374443"
  //  val carPathTableName = "tmp_dm_gis.tmp_tt_vehicle_task_pass_zone_monitor_carpath_bak_01374443"
  //  val carPathMergeTableName = "tmp_dm_gis.tmp_tt_vehicle_task_pass_zone_monitor_carpath_merge_01374443"

  def main(args: Array[String]): Unit = {
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)
    val buildCitys = ""
    val spark = Spark.getSparkSession(appName)
    initBills(spark, checkDate, buildCitys)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def initBills(spark: SparkSession, checkDate: String, buildCitys: String): Unit = {
    //7天前 的数据
    val dayid = DateUtil.getDateStr(checkDate, -7) //20220717
    logger.error(">>>>>>>>>>>>>>>>>>>即将开始舒华新天地--调度作业单元区域区间车辆轨迹推送：" + dayid)
    val ydayid = checkDate
    prepareDataBak(spark, ydayid, step = 0)
    logger.error(s"准备轨迹数据【$ydayid】完成")
    //TODO 这个步骤转化为单个工作流任务， 先生成临时表，在shell任务上传，最后删除表,这个是单独的任务
    //    postToWuhan(spark, ydayid)

  }


  def prepareDataBak(spark: SparkSession, dayid: String, step: Int = 2, moreDays: Boolean = true) = {
    import spark.implicits._
    //    spark.sql("use dm_gis")
    var sql = ""
    //此处为新增补充逻辑
    val taskAll = mergeLogic(spark, dayid).na.fill("").repartition(50).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val taskCnt = taskAll.count()
    logger.error("taskAll数量：" + taskCnt)
    val tt_cols = spark.sql(s"""select * from $tcSeqTableName limit 1""").schema.map(_.name).map(col)
    val tt_1 = taskAll.withColumn("inc_day", lit(dayid)).select(tt_cols: _*)
    SparkWrite.overwriteToHiveDynamics(spark, tt_1.coalesce(1), Seq("inc_day"), tcSeqTableName)
    taskAll.show(false)
    //    val taskCnt = taskAll.count()
    if (taskCnt == 0) {
      println("任务初始化记录为空")
    }
    taskAll.createOrReplaceTempView("tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak")

    sql = "select min(dayid),max(dayid) from tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak"

    if (taskCnt > 0) {
      val dayrange = spark.sql(sql).take(1)(0)
      val daymin = dayrange.getString(0)
      val daymax = dayrange.getString(1)

      val delta = if (moreDays) DateUtil.daysDiff(daymin, daymax).toInt else 0
      (0 to delta).foreach(i => {
        val day = DateUtil.getDateStr(daymin, i)
        val task = taskAll.filter(_.getString(4) == day).rdd.collect().sortBy(d => {
          (try {
            d.getString(1).toLong
          } catch {
            case e: Exception => logger.error(e.getMessage)
              0l
          }) - (try {
            d.getString(0).toLong
          } catch {
            case e: Exception => logger.error(e.getMessage)
              0l
          })
        })
        val dayid = day

        val taskCnt = task.length
        val btask = spark.sparkContext.broadcast(task)
        if (taskCnt > 0) {
          val dateFrom = task.map(_.getString(2).toInt).min
          val dateTo = task.map(_.getString(3).toInt).max
          //          Util.memTime()
          spark.sql("set spark.sql.shuffle.partitions=" + 100 * 2)
          /**
           * 1 轨迹表替换为 dm_gis.gis_rss_eta_navi_track_flatmap 取值
           * 2 轨迹中车牌范围变化 从 tt_vehicle_task_pass_zone_monitor_tc_seq 变化为 tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak
           */
          val flatmap_track_df = spark.sql(
            s"""select distinct regexp_replace(carno,',','') as un,ak,tm,x zx,y zy,ac,tp,sp,be from dm_gis.gis_rss_eta_navi_track_flatmap
               |where inc_day between '$dateFrom' and '$dateTo'
               |      and ak in ('305','306','333','335','334','332')
               |      and tm is not null and tm<>'' and x<>0 and y<>0
               |      and tag = '1'
               |      and regexp_replace(carno,',','') in (SELECT distinct regexp_replace(t.vehicle_serial,',','') as un FROM tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak t where t.vehicle_serial is not null and t.dayid='$dayid')
               |""".stripMargin)
          val fixedPath = flatmap_track_df.na.fill("").rdd.groupBy(_.getString(0)).map(d => {
            val un = d._1
            val paths = d._2
            val fixedPath = btask.value.filter(t => {
              t.getString(6) == un
            }).map(d => {
              val tms = d.getString(0).toLong
              val tme = d.getString(1).toLong
              val taskid = d.getString(5)
              val un = d.getString(6)
              val zoneFrom = d.getString(7)
              val zoneTo = d.getString(8)
              val coorFrom = d.getString(9)
              val coorTo = d.getString(10)
              val rst = paths.filter(path => {
                val tm = path.getString(2).toLong
                tm >= tms - 300 && tm <= tme + 300 //轨迹起止时间各向两端延时5分钟
              }).map(path => {
                s"$taskid,$zoneFrom,$zoneTo,$coorFrom,$coorTo,$tms,$tme,${path.mkString(",")}"
              })
              rst
            }).flatMap(d => d)
            fixedPath
          }).flatMap(d => d)

          val fixedPath_df = fixedPath.map(_.split(",")).map(row => {
            var taskid, zoneFrom, zoneTo, coorFrom, coorTo, un, ak, tm, zx, zy, ac, tp, sp, be, sc = ""
            var tms, tme = 0l
            try {
              taskid = row(0)
              zoneFrom = row(1)
              zoneTo = row(2)
              coorFrom = row(3)
              coorTo = row(4)
              tms = row(5).toLong
              tme = row(6).toLong
              un = row(7)
              ak = row(8)
              tm = row(9)
              zx = row(10)
              zy = row(11)
              ac = row(12)
              tp = row(13)
              sp = row(14)
              be = row(15)
              sc = row(16)
            } catch {
              case e: Exception => logger.error("数据中存在空值" + e.getMessage)
            }
            FixedPathBAK(taskid, zoneFrom, zoneTo, coorFrom, coorTo, tms, tme, un, ak, tm, zx, zy, ac, tp, sp, be, sc)
          }).toDF("task_id", "zone_from", "zone_to", "coor_from", "coor_to", "tm_from", "tm_to", "un", "ak", "tm", "zx", "zy", "ac", "tp", "sp", "be", "sc")
            .withColumn("inc_day", lit(dayid))
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          val select_sc = fixedPath_df.select("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un", "tm", "sc")
            .withColumn("num", row_number().over(Window.partitionBy("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un").orderBy(asc("tm"))))
            .filter("num=1").drop("tm", "num")
          val res_df = fixedPath_df.join(broadcast(select_sc), Seq("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un", "sc"))
            .select("task_id", "zone_from", "zone_to", "coor_from", "coor_to", "tm_from", "tm_to", "un", "ak", "tm", "zx", "zy", "ac", "tp", "sp", "be", "inc_day")
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          //按照已有结果表字段排序
          val res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath limit 0""").schema.map(_.name).map(col)
          val merge_res_cols = spark.sql(s"""select * from $carPathMergeTableName limit 0""").schema.map(_.name).map(col)
          //根据 车牌 和 ak 筛选出 同个车牌 轨迹较多的车牌信息
          val fixedPath_df_ft = res_df.select("un", "ak", "tm_from", "tm_to")
            .withColumn("cnt", lit(1))
            .groupBy("un", "tm_from", "tm_to", "ak")
            .agg(
              sum("cnt") as "ak_cnt"
            )
            .withColumn("num", row_number().over(Window.partitionBy("un", "tm_from", "tm_to").orderBy(desc("ak_cnt"))))
            .filter('num === 1).select("un", "ak", "tm_from", "tm_to")
          //筛选完后的数据
          val fixedPath_df_res = res_df.join(fixedPath_df_ft, Seq("un", "tm_from", "tm_to", "ak"))
            .select(res_cols: _*)
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          val org_catch = spark.sql(s"""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath where inc_day = '$dayid'""").select(res_cols: _*)

          val all_carpath_df = fixedPath_df_res.withColumn("org_flag", lit("result")).union(org_catch.withColumn("org_flag", lit("monitor")))
            .groupBy(merge_res_cols: _*)
            .agg(lit(true))
            .select(merge_res_cols: _*)

          SparkWrite.overwriteToHiveDynamics(spark, fixedPath_df_res.coalesce(10), Seq("inc_day"), carPathTableName)
          SparkWrite.overwriteToHiveDynamics(spark, all_carpath_df.coalesce(60), Seq("inc_day"), carPathMergeTableName)
          logger.error(s"【$dateFrom - $dateTo】 done")
        }
        btask.destroy()
      })
      //TODO 这个步骤转化为单个工作流任务， 先生成临时表，在shell任务上传，最后删除表
      //      makesegPath(spark, dayid)
    } else {
      logger.error("【ERROR】taskAll 初始化记录为空")
    }
    taskAll.unpersist()
  }

  /**
   * 此处逻辑变换
   *
   * @param spark
   * @return
   */
  def mergeLogic(spark: SparkSession, checkDate: String): DataFrame = {
    import spark.implicits._
    val day_bef = DateUtil.getDateStr(checkDate, -1)
    val day_aft = DateUtil.getDateStr(checkDate, 1)
    //"task_id", "vehicle_serial", "tmstart", "tmend", "daystart", "dayend", "zone_from", "zone_to", "coor_from", "coor_to", "dayid", "inc_day"
    val result_coords_df = replaceMonitorSeq(spark, checkDate)
    val sql =
      s"""
         |SELECT task_id,zone_from,zone_to,tm_from,tm_to
         |FROM dm_gis.tt_vehicle_task_pass_zone_monitor_carpath
         |WHERE  inc_day between '$day_bef' and '$day_aft'
         |group by task_id,zone_from,zone_to,tm_from,tm_to
         |""".stripMargin
    logger.error(sql)
    val carpath_df = spark.sql(sql)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val union_cols = Seq(col("tmstart"), col("tmend"), col("daystart"), col("dayend"), col("dayid"),
      col("task_id"), col("vehicle_serial"), col("zone_from"), col("zone_to"), col("coor_from"), col("coor_to"))
    //result_coords_df 有  carpath_df  无
    val p1_merge_df = result_coords_df.join(carpath_df.select("task_id"), Seq("task_id"), "left_anti")
      .select(union_cols: _*)

    val filter_cond = when('tm_from.cast("long") >= 'tmend.cast("long") || 'tmstart.cast("long") >= 'tm_to.cast("long"), true).otherwise(false)

    val p2_merge_df = result_coords_df.join(carpath_df.select("task_id", "tm_from", "tm_to"), Seq("task_id"))
      .withColumn("flag", filter_cond)
      .filter('flag === true) //保留无时间交集的task_id
      .select(union_cols: _*)

    p1_merge_df.union(p2_merge_df)
      .withColumn("num", row_number().over(Window.partitionBy(union_cols: _*).orderBy("task_id")))
      .filter('num === 1)
      .select(union_cols: _*)
  }

  def replaceMonitorSeq(spark: SparkSession, checkDate: String): DataFrame = {
    import spark.implicits._
    val dayid = DateUtil.getDateStr(checkDate, -2)
    //navi_starttime 1654947040004
    val sql =
      s"""
         |select id,task_id,vehicle vehicle_serial,
         |       cast(navi_starttime/1000 as bigint) tmstart,
         |       cast(navi_endtime/1000 as bigint) tmend,
         |       substring(from_unixtime(cast(navi_starttime/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),0,10) as daystart,
         |       substring(from_unixtime(cast(navi_endtime/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),0,10) as dayend,
         |       inc_day dayid,
         |       concat_ws(';',x1,y1) coor_from,
         |       concat_ws(';',x2,y2) coor_to,
         |       inc_day
         |from dm_gis.gis_navi_eta_result1
         |where
         |   req_type = 'top3'
         |   and inc_day = '$checkDate'
         |   and cast(distance as double) > 1000
         |   --and strategy2 not in ('20','21','22')
         |   --and start_type != '1'
         |""".stripMargin
    logger.error(sql)
    val result1_df = spark.sql(sql)
      .withColumn("tmstart", 'tmstart.cast("string"))
      .withColumn("tmend", 'tmend.cast("string"))
      .withColumn("daystart", regexp_replace('daystart, "-", "").cast("string"))
      .withColumn("dayend", regexp_replace('dayend, "-", "").cast("string"))

    val result2_df = spark.sql(
      s"""
         |select id,src_deptcode zone_from,dest_deptcode zone_to,inc_day
         |from dm_gis.gis_navi_eta_result2
         |where
         |  req_type = 'top3'
         |  and inc_day = '$checkDate'
         |  and cast(navi_distance as double) > 1000
         |  and cast(trackstart_distance as double) < 1000
         |  and cast(trackend_distance as double) < 1000
         |""".stripMargin)

    val source_p2_df = result1_df.join(result2_df, Seq("id", "inc_day"))
      .select("task_id", "vehicle_serial", "tmstart", "tmend", "daystart", "dayend", "zone_from", "zone_to", "coor_from", "coor_to", "dayid", "inc_day")
    source_p2_df
  }

}
