package com.sf.gis.scala.pns.app

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.pns.utils.Functions.timeToCustomTime2
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


/**
 * 【司机计提】异常封车数据对接tcas_V1.0
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：987089
 * 任务名称：
 */
object EmptyDrivingAbnormalityMonth {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def execute(spark: SparkSession, inc_day: String) = {

    val beforeMonth = DateUtil.getMouthBefore(inc_day, 1).substring(0,6)

    import spark.implicits._
    val task_new_sql =
      s"""
         |select
         |  task_id,
         |  is_rational as is_rational_new
         |from
         |  dm_gis.dm_driver_salary_task_new_di
         |where
         |  substr(inc_day,0,6) = '$beforeMonth'
         |""".stripMargin
    println(task_new_sql)
    val df_task_new = spark.sql(task_new_sql)

    val abnormality_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.empty_driving_abnormality
         |""".stripMargin
    println(abnormality_sql)
    val df_abnormality = spark.sql(abnormality_sql)
      .withColumn("actual_arrive_yyyyMM",timeToCustomTime2('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMM")))
      .filter('actual_arrive_yyyyMM === beforeMonth)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("proof_time"))))
      .filter('rn === 1) // 按 task_id 去重
      .filter('proof_status =!= "1")
      .join(df_task_new,Seq("task_id"),"left")
      .filter('is_rational_new =!= "合理")
      .filter('main_area_code === "471Y" or 'main_area_code === "025Y" or 'main_area_code === "991Y" or 'main_area_code === "027Y"
        or 'main_area_code === "536Y" or 'main_area_code === "029Y" or 'main_area_code === "700Y" or 'main_area_code === "333Y")
      .withColumn("month",lit(beforeMonth))

    val cols = spark.sql("""select * from dm_gis.dm_empty_driving_abnormality_month_mi limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_abnormality.select(cols: _*),Seq("month"),"dm_gis.dm_empty_driving_abnormality_month_mi")

  }

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20240122  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}
