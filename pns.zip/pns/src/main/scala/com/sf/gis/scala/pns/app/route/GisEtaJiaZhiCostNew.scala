package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class GisEtaJiaZhiCostNew {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

    def gis_eta_jiazhi_cost(spark: SparkSession, incDay: String): DataFrame = {
        spark.udf.register("get_before_day", new GisEtaDriveLogReject().get_min_date_before_30day _)

        // 结果表3关联配置表获取 value_date
//        val df_source = spark.sql("select * from dm_gis.gis_eta_jiazhi_cost_value_date")
//        df_source.createOrReplaceTempView("source_table")

        val sql =
            s"""
               |with t1 as (
               |    select
               |        min(nday) min_day
               |    from
               |    (
               |        select
               |            get_before_day(substr(value_date,0,10), 60) nday
               |        from dm_gis.gis_eta_jiazhi_cost_value_date
               |        where inc_day = '$incDay'
               |        and value_date is not null and value_date != '' and get_before_day(substr(value_date,0,10), 0) <= '$incDay'
               |    ) t
               |)
               |select
               |    task_area_code,
               |    task_id,
               |    start_dept,
               |    end_dept,
               |    start_type,
               |    end_type,
               |    line_code,
               |    std_id,
               |    vehicle_serial,
               |    conduct_type,
               |    is_run_ontime,
               |    start_longitude,
               |    start_latitude,
               |    end_longitude,
               |    end_latitude,
               |    rt_dist,
               |    accrual_dist,
               |    toll_charge,
               |    is_stop,
               |    stop_over_zone_code,
               |    transoport_level,
               |    carrier_type,
               |    carrier_name,
               |    vehicle_type,
               |    axle_number,
               |    length,
               |    weight,
               |    mload,
               |    car_type,
               |    length_weight,
               |    miles,
               |    road_fee,
               |    linevehicle_jz,
               |    std_id_jz,
               |    substr(value_date,0,10) as online_date,
               |    source,
               |    grd1,
               |    grd2,
               |    inc_day,
               |    case when inc_day >= get_before_day(substr(value_date,0,10), 0) then 1
               |         when inc_day >= get_before_day(substr(value_date,0,10), 60) then 2
               |         else 0 end task_type,
               |    value_date
               |from
               |(
               |    select
               |        *,
               |        row_number() over(partition by task_id order by inc_day desc) rn
               |    from (select * from dm_gis.gis_eta_jiazhi_cost_value_date
               |          where value_date is not null and value_date != '' and inc_day <= '$incDay' and get_before_day(substr(value_date,0,10), 0) <= '$incDay'
               |         ) t
               |    left join t1 on 1 = 1
               |) t1
               |where rn = 1 and inc_day >= min_day
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 读取日志平均油价表当天的数据
     * @param spark SparkSession
     * @param incDay incDay
     * @return
     */
    def gis_fule_prices(spark: SparkSession, incDay: String): DataFrame = {
//        val day = DateUtil.getBeforeNDay(incDay, 1)
        val day = DateUtil.getDayBefore(incDay,"yyyyMMdd",1)
        val sql =
            s"""
               |select
               |    fuel_prices
               |from dm_gis.gis_fule_prices
               |where inc_day = '$incDay'
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 读取统计表最新的跑数日期的分区数据
     * @param spark SparkSession
     * @return
     */
    def read_gis_vehicle_fule_stat(spark: SparkSession, incDay: String): DataFrame = {
        val sql =
            s"""
               |select
               |    vehicle_serial,
               |    update_uint_fuel
               |from dm_gis.gis_vehicle_fule_stat
               |where inc_day in (select max(inc_day) inc_day from dm_gis.gis_vehicle_fule_stat)
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 读取日志剔除表最新一天的数据
     * @param spark SparkSession
     * @param incDay incDay
     * @return
     */
    def gis_eta_drive_log_reject(spark: SparkSession, incDay: String): DataFrame = {
        val sql =
            s"""
               |select
               |    task_id,
               |    road_fee_flag,
               |    miles_flag,
               |    reject_flag
               |from dm_gis.gis_eta_drive_log_reject
               |where inc_day in (select max(inc_day) inc_day from dm_gis.gis_eta_drive_log_reject)
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def execute(spark: SparkSession, incDay: String): Unit = {
        val table1 = gis_eta_jiazhi_cost(spark, incDay)
        table1.createOrReplaceTempView("t1")
        val table2 = gis_fule_prices(spark, incDay)
        table2.createOrReplaceTempView("t2")
        val table3 = read_gis_vehicle_fule_stat(spark, incDay)
        table3.createOrReplaceTempView("t3")
        val table4 = gis_eta_drive_log_reject(spark, incDay)
        table4.createOrReplaceTempView("t4")

        val sql =
            s"""
               |insert overwrite table dm_gis.gis_eta_jiazhi_cost_new partition (inc_day = '$incDay')
               |select
               |    t1.task_area_code,
               |    t1.task_id,
               |    t1.start_dept,
               |    t1.end_dept,
               |    t1.start_type,
               |    t1.end_type,
               |    t1.line_code,
               |    t1.std_id,
               |    t1.vehicle_serial,
               |    t1.conduct_type,
               |    t1.is_run_ontime,
               |    t1.start_longitude,
               |    t1.start_latitude,
               |    t1.end_longitude,
               |    t1.end_latitude,
               |    t1.rt_dist,
               |    t1.accrual_dist,
               |    t1.toll_charge,
               |    t1.is_stop,
               |    t1.stop_over_zone_code,
               |    t1.transoport_level,
               |    t1.carrier_type,
               |    t1.carrier_name,
               |    t1.vehicle_type,
               |    t1.axle_number,
               |    t1.length,
               |    t1.weight,
               |    t1.mload,
               |    t1.car_type,
               |    t1.length_weight,
               |    t1.miles,
               |    t1.road_fee,
               |    t4.road_fee_flag,
               |    t4.miles_flag,
               |    t4.reject_flag,
               |    t2.fuel_prices,
               |    t3.update_uint_fuel,
               |    t2.fuel_prices * t3.update_uint_fuel * t1. miles / 100,
               |    t2.fuel_prices * t3.update_uint_fuel * t1. miles / 100 + t1.road_fee,
               |    t1.linevehicle_jz,
               |    t1.std_id_jz,
               |    t1.online_date,
               |    t1.source,
               |    t1.grd1,
               |    t1.grd2,
               |    t1.inc_day,
               |    t1.task_type
               |from t1
               |left join t2 on 1 = 1
               |left join t3 on t1.vehicle_serial = t3.vehicle_serial
               |left join t4 on t1.task_id = t4.task_id
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql("set spark.sql.crossJoin.enabled = true")
        spark.sql(sql)
    }
}

object GisEtaJiaZhiCostNew {
    def main(args: Array[String]): Unit = {
        val task = new GisEtaJiaZhiCostNew
        if (args == null || args.length == 0 || StringUtils.isEmpty(args(0))) {
            task.LOGGER.error("请传入日期参数")
            return
        }
        val incDay = args(0)
        task.LOGGER.info("###########################################")
        task.LOGGER.info("incDay: [{}]", incDay)
        task.LOGGER.info("###########################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession

        task.execute(spark, incDay)
        task.LOGGER.info("任务执行完成")

        spark.stop()
    }
}
