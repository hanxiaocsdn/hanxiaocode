package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.pns.app.NonTaskVehicleInfo.logger
import com.sf.gis.scala.pns.app.route.StandObj.Stand
import org.apache.commons.lang3.StringUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.mutable.ArrayBuffer

class GisEtaJiaZhiCost extends Serializable {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

    /**
     * 读取gis_eta_jiazhi_task表，按task_id分组后按需求取对应列的值
     * @param spark SparkSession
     * @param incDay incDay
     * @return
     */
    def read_gis_eta_jiazhi_task(spark: SparkSession, incDay: String): DataFrame = {
        val sql =
            s"""
               |select * from dm_gis.gis_eta_jiazhi_task where inc_day = '$incDay'
               |""".stripMargin
        LOGGER.info(sql)
        val rdd = spark.sql(sql).rdd
        LOGGER.info("读取gis_eta_jiazhi_task表转rdd")

        val sourceRdd: RDD[(String, Iterable[Field])] = rdd
            .map(x => {
                val task_area_code = if (x.isNullAt(0)) "" else x.getString(0)
                val task_id = if (x.isNullAt(1)) "" else x.getString(1)
                val task_subid = if (x.isNullAt(2)) "" else x.getString(2)
                val sort_num = if (x.isNullAt(3)) 0 else x.getString(3).toInt
                val start_dept = if (x.isNullAt(4)) "" else x.getString(4)
                val end_dept = if (x.isNullAt(5)) "" else x.getString(5)
                val start_type = if (x.isNullAt(6)) "" else x.getString(6)
                val end_type = if (x.isNullAt(7)) "" else x.getString(7)
                val line_code = if (x.isNullAt(8)) "" else x.getString(8)
                val linevehicle = if (x.isNullAt(9)) "" else x.getString(9)
                val linemload = if (x.isNullAt(10)) "" else x.getString(10)
                val std_id = if (x.isNullAt(11)) "" else x.getString(11)
                val vehicle_serial = if (x.isNullAt(12)) "" else x.getString(12)
                val conduct_type = if (x.isNullAt(13)) "" else x.getString(13)
                val is_run_ontime = if (x.isNullAt(14)) "" else x.getString(14)
                val start_longitude = if (x.isNullAt(15)) "" else x.getString(15)
                val start_latitude = if (x.isNullAt(16)) "" else x.getString(16)
                val end_longitude = if (x.isNullAt(17)) "" else x.getString(17)
                val end_latitude = if (x.isNullAt(18)) "" else x.getString(18)
                val rt_dist = if (x.isNullAt(19)) 0 else x.getString(19).toDouble
                val accrual_dist = if (x.isNullAt(20)) 0 else x.getString(20).toDouble
                val toll_charge = if (x.isNullAt(21)) 0 else x.getString(21).toDouble
                val is_stop = if (x.isNullAt(22)) "" else x.getString(22)
                val stop_over_zone_code = if (x.isNullAt(23)) "" else x.getString(23)
                val transoport_level = if (x.isNullAt(24)) "" else x.getString(24)
                val carrier_type = if (x.isNullAt(25)) "" else x.getString(25)
                val carrier_name = if (x.isNullAt(26)) "" else x.getString(26)
                val vehicle_type = if (x.isNullAt(27)) "" else x.getString(27)
                val axle_number = if (x.isNullAt(28)) "" else x.getString(28)
                val length = if (x.isNullAt(29)) "" else x.getString(29)
                val weight = if (x.isNullAt(30)) "" else x.getString(30)
                val mload = if (x.isNullAt(31)) "" else x.getString(31)
                val car_type = if (x.isNullAt(32)) "" else x.getString(32)
                val length_weight = if (x.isNullAt(33)) "" else x.getString(33)
                val miles = if (x.isNullAt(34)) "" else x.getString(34)
                val road_fee = if (x.isNullAt(35)) "" else x.getString(35)
                val fuel_prices = if (x.isNullAt(36)) "" else x.getString(36)
                val error_type = if (x.isNullAt(37)) "" else x.getString(37)
                val exe_reject_flag = if (x.isNullAt(38)) "" else x.getString(38)
                val linevehicle_jz = if (x.isNullAt(39)) "" else x.getString(39)
                val std_id_jz = if (x.isNullAt(40)) "" else x.getString(40)
                val std_id_jz_time = if (x.isNullAt(41)) "" else x.getString(41)
                val add_reason = if (x.isNullAt(42)) "" else x.getString(42)
                val opt_user = if (x.isNullAt(43)) "" else x.getString(43)
                Field(task_area_code, task_id, task_subid, sort_num, start_dept, end_dept,
                    start_type, end_type, line_code, linevehicle, linemload, std_id, vehicle_serial,
                    conduct_type, is_run_ontime, start_longitude, start_latitude, end_longitude,
                    end_latitude, rt_dist, accrual_dist, toll_charge, is_stop, stop_over_zone_code,
                    transoport_level, carrier_type, carrier_name, vehicle_type, axle_number, length,
                    weight, mload, car_type, length_weight, miles, road_fee, fuel_prices, error_type,
                    exe_reject_flag, linevehicle_jz, std_id_jz, std_id_jz_time, add_reason, opt_user
                )
            })
            .groupBy(x => x.task_id)
        LOGGER.info("对task_id分组")

        val mapRDD = sourceRdd.map(x => {
            val task_id = x._1
            var min_sort_num = Int.MinValue
            var max_sort_num = Int.MaxValue
            var task_area_code = ""
            var start_dept = ""
            var end_dept = ""
            var start_type = ""
            var end_type = ""
            var line_code = ""
            val std_id_list = ArrayBuffer[(Int, String)]()
            var vehicle_serial = ""
            var conduct_type = 3
            var is_run_ontime = 1
            var start_longitude = ""
            var start_latitude = ""
            var end_longitude = ""
            var end_latitude = ""
            var rt_dist = 0.0
            var accrual_dist = 0.0
            var toll_charge = 0.0
            var is_stop = ""
            var stop_over_zone_code = ""
            var transoport_level = ""
            var carrier_type = ""
            var carrier_name = ""
            var vehicle_type = ""
            var axle_number = ""
            var length = ""
            var weight = ""
            var mload = ""
            var car_type = ""
            var length_weight = ""
            var miles = ""
            var road_fee = ""
            var fuel_prices = ""
            val linevehicle_jz_list = ArrayBuffer[(Int, String)]()
            val std_id_jz_list = ArrayBuffer[(Int, String)]()
            val online_date_list = ArrayBuffer[(Int, String)]()
            val add_reason_list = ArrayBuffer[(Int, String)]()

            for (data <- x._2) {
                // 按task_id分组取sort_num对应的最大记录
                if (data.sort_num > min_sort_num) {
                    end_dept = data.end_dept
                    end_type = data.end_type
                    end_longitude = data.end_longitude
                    end_latitude = data.end_latitude
                    min_sort_num = data.sort_num
                }
                //  按task_id分组取sort_num对应的最小记录
                if (data.sort_num < max_sort_num) {
                    task_area_code = data.task_area_code
                    start_dept = data.start_dept
                    start_type = data.start_type
                    line_code = data.line_code
                    vehicle_serial = data.vehicle_serial
                    start_longitude = data.start_longitude
                    start_latitude = data.start_latitude
                    is_stop = data.is_stop
                    stop_over_zone_code = data.stop_over_zone_code
                    transoport_level = data.transoport_level
                    carrier_type = data.carrier_type
                    carrier_name = data.carrier_name
                    vehicle_type = data.vehicle_type
                    axle_number = data.axle_number
                    length = data.length
                    weight = data.weight
                    mload = data.mload
                    car_type = data.car_type
                    length_weight = data.length_weight
                    miles = data.miles
                    road_fee = data.road_fee
                    fuel_prices = data.fuel_prices
                    max_sort_num = data.sort_num
                }
                // 剔除linevehicle_jz ！= linevehicle的数据后进行字段拼接
                if (data.linevehicle_jz.equals(data.linevehicle)) {
                    std_id_list.append((data.sort_num, data.std_id))
                    linevehicle_jz_list.append((data.sort_num, data.linevehicle_jz))
                    std_id_jz_list.append((data.sort_num, data.std_id_jz))
                    online_date_list.append((data.sort_num, data.std_id_jz_time))
                    add_reason_list.append((data.sort_num, data.add_reason))
                }
                if ("1".equals(data.conduct_type)) {
                    conduct_type = 1
                }
                if (!"1".equals(data.is_run_ontime)) {
                    is_run_ontime = 0
                }
                // 求和
                rt_dist += data.rt_dist
                accrual_dist += data.accrual_dist
                toll_charge += data.toll_charge
            }

            val std_id = sorted_joint(std_id_jz_list)
            val linevehicle_jz = sorted_joint(linevehicle_jz_list)
            val std_id_jz = sorted_joint(std_id_jz_list)
            val online_date = sorted_joint_date(online_date_list)
            val source = assign_source(add_reason_list)

            try {
              start_longitude = if (StringUtils.isEmpty(start_longitude)) "null" else start_longitude.toDouble.formatted("%.4f")
              start_latitude = if (StringUtils.isEmpty(start_latitude)) "null" else start_latitude.toDouble.formatted("%.4f")
              end_longitude = if (StringUtils.isEmpty(end_longitude)) "null" else end_longitude.toDouble.formatted("%.4f")
              end_latitude = if (StringUtils.isEmpty(end_latitude)) "null" else end_latitude.toDouble.formatted("%.4f")
            } catch {
              case e: Exception => logger.error(e)
            }

            val grd2 = line_code + "_" +
                        start_longitude + "_" +
                        start_latitude + "_" +
                        end_longitude + "_" +
                        end_latitude
            val grd1 = grd2 + "_" + stop_over_zone_code + "_" + length_weight

            Stand(task_area_code, task_id, start_dept, end_dept, start_type, end_type, line_code,
                std_id, vehicle_serial, conduct_type, is_run_ontime, start_longitude, start_latitude,
                end_longitude, end_latitude, rt_dist, accrual_dist, toll_charge, is_stop,
                stop_over_zone_code, transoport_level, carrier_type, carrier_name, vehicle_type,
                axle_number, length, weight, mload, car_type, length_weight, miles, road_fee,
                fuel_prices, linevehicle_jz, std_id_jz, online_date, source, grd1, grd2, incDay)
        })
        LOGGER.info("对task_id分组后取对应的值")
        import spark.implicits._
        mapRDD.toDF()
    }

    /**
     * 对source列赋值判断
     * @param arrayBuffer 按task_id分组后所取得的（sort, add_reason）集合
     * @return
     */
    def assign_source(arrayBuffer: ArrayBuffer[(Int, String)]): String = {
        val add_reason = sorted_joint(arrayBuffer)
        var source = ""
        if (add_reason.contains("融合") && !add_reason.contains("|")) {
            source = "融合"
        } else if (add_reason.contains("新方案") && !add_reason.contains("|")) {
            source = "标准新方案"
        } else if (!add_reason.contains("|")) {
            source = "标准"
        } else if (add_reason.contains("|")) {
            val splits = add_reason.split("\\|")
            var count = 0
            for (i <- splits.indices) {
                if ("融合".equals(splits(i)) || "新方案".equals(splits(i))) {
                    count += 1
                }
            }
            if (count != 0 && count != splits.length) {
                source = "多源"
            } else {
                source = "标准"
            }
        }
        source
    }

    /**
     * 数组元素类型为二元组，按二元组的第一个值对数组进行排序后将二元组的第二个元素拼接返回
     * @param arrayBuffer 按task_id分组后所取得的（sort, column）集合
     * @return
     */
    def sorted_joint(arrayBuffer: ArrayBuffer[(Int, String)]): String = {
        var res = ""
        val tuples = arrayBuffer.sortWith((x, y) => x._1 < y._1)
        for (i <- tuples.indices) {
            if (!StringUtils.isEmpty(tuples(i)._2)) {
                if (res != "") {
                    res += "|"
                }
                res += tuples(i)._2
            }
        }
        res
    }

    /**
     * 数组元素类型为二元组，按二元组的第一个值对数组进行排序后将二元组的第二个元素拼接返回
     * 此处元组第二个元素为yyyy-MM-dd hh:mm:ss，拼接返回只需要日期
     * @param arrayBuffer 按task_id分组后所取得的（sort, column）集合
     * @return
     */
    def sorted_joint_date(arrayBuffer: ArrayBuffer[(Int, String)]): String = {
        var res = ""
        val tuples = arrayBuffer.sortWith((x, y) => x._1 < y._1)
        for (i <- tuples.indices) {
            if (!StringUtils.isEmpty(tuples(i)._2) && tuples(i)._2.length() == 19) {
                if (res != "") {
                    res += "|"
                }
                res += tuples(i)._2.substring(0, 10)
            }
        }
        res
    }

    /**
     * 读取统计表最新的跑数日期的分区数据
     * @param spark SparkSession
     * @return
     */
    def read_gis_vehicle_fule_stat(spark: SparkSession): DataFrame = {
        val sql =
            s"""
               |select
               |    vehicle_serial,
               |    update_uint_fuel
               |from dm_gis.gis_vehicle_fule_stat
               |where inc_day in (select max(inc_day) inc_day from dm_gis.gis_vehicle_fule_stat)
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def execute(spark: SparkSession, incDay: String): Unit = {
        LOGGER.info("gis_eta_jiazhi_task")
        val table1 = read_gis_eta_jiazhi_task(spark, incDay)
        LOGGER.info("gis_vehicle_fule_stat")
        val table2 = read_gis_vehicle_fule_stat(spark)

        table1.createOrReplaceTempView("t1")
        table2.createOrReplaceTempView("t2")

        val sql =
            s"""
               |insert overwrite table dm_gis.gis_eta_jiazhi_cost partition(inc_day = '$incDay')
               |select
               |    t1.task_area_code,
               |    t1.task_id,
               |    t1.start_dept,
               |    t1.end_dept,
               |    t1.start_type,
               |    t1.end_type,
               |    t1.line_code,
               |    t1.std_id,
               |    t1.vehicle_serial,
               |    t1.conduct_type,
               |    t1.is_run_ontime,
               |    t1.start_longitude,
               |    t1.start_latitude,
               |    t1.end_longitude,
               |    t1.end_latitude,
               |    t1.rt_dist,
               |    t1.accrual_dist,
               |    t1.toll_charge,
               |    t1.is_stop,
               |    t1.stop_over_zone_code,
               |    t1.transoport_level,
               |    t1.carrier_type,
               |    t1.carrier_name,
               |    t1.vehicle_type,
               |    t1.axle_number,
               |    t1.length,
               |    t1.weight,
               |    t1.mload,
               |    t1.car_type,
               |    t1.length_weight,
               |    t1.miles,
               |    t1.road_fee,
               |    t1.fuel_prices,
               |    t2.update_uint_fuel,
               |    (t1.fuel_prices * t2.update_uint_fuel * t1.miles / 100) as fuel_cost,
               |    (t1.fuel_prices * t2.update_uint_fuel * t1.miles / 100 + road_fee) as sum_cost,
               |    t1.linevehicle_jz,
               |    t1.std_id_jz,
               |    t1.online_date,
               |    t1.source,
               |    t1.grd1,
               |    t1.grd2
               |from t1
               |left join t2
               |on t1.vehicle_serial = t2.vehicle_serial
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
        LOGGER.info("数据插入dm_gis.gis_eta_jiazhi_cost成功")
    }
}

object GisEtaJiaZhiCost {
    def main(args: Array[String]): Unit = {
        val task = new GisEtaJiaZhiCost
        if (args == null || args.length == 0 || StringUtils.isEmpty(args(0))) {
            task.LOGGER.error("请传入日期参数")
            return
        }
        val incDay = args(0)
        task.LOGGER.info("###########################################")
        task.LOGGER.info("incDay: [{}]", incDay)
        task.LOGGER.info("###########################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession

        println("任务开始20230731")
        task.execute(spark, incDay)


        spark.stop()
    }
}