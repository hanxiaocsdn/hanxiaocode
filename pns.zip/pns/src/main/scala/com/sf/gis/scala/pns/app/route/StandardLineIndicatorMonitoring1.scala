package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.{Logger, LoggerFactory}

class StandardLineIndicatorMonitoring1 extends Serializable {

    private final val CLASS_NAME: String = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER: Logger = LoggerFactory.getLogger(CLASS_NAME)

    /**
     * udf函数，判断车型分组标记字段
     * @param carType 车辆类型
     * @param length 长度
     * @param weight 重量
     * @return
     */
    def judge_length_weight(carType: String, length: Double, weight: Double): String = {
        var length_weight = ""
        if ("牵引车".equals(carType) || "半挂车".equals(carType)) {
            length_weight = "19米1_25吨"
        } else if (length < 5.5 && weight < 4) {
            length_weight = "4米2_3吨"
        } else if (length < 5.5 && weight >= 4 && weight < 6) {
            length_weight = "4米2_5吨"
        } else if (length < 5.5 && weight >= 6 && weight < 8) {
            length_weight = "4米2_7吨"
        } else if (length < 5.5 && weight >= 8 && weight < 12.5) {
            length_weight = "4米2_9吨"
        } else if (length < 5.5 && weight >= 12.5) {
            length_weight = "4米2_13吨+"
        } else if (length >= 5.5 && length < 8.2 && weight < 6) {
            length_weight = "6米8_5吨"
        } else if (length >= 5.5 && length < 8.2 && weight >= 6 && weight < 8) {
            length_weight = "6米8_7吨"
        } else if (length >= 5.5 && length < 8.2 && weight >= 8 && weight < 10.5) {
            length_weight = "6米8_9吨"
        } else if (length >= 5.5 && length < 8.2 && weight >= 10.5 && weight < 14) {
            length_weight = "6米8_12吨"
        } else if (length >= 5.5 && length < 8.2 && weight >= 14 && weight < 20) {
            length_weight = "6米8_16吨"
        } else if (length >= 5.5 && length < 8.2 && weight >= 20 && weight < 27.5) {
            length_weight = "6米8_25吨"
        } else if (length >= 5.5 && length < 8.2 && weight >= 27.5) {
            length_weight = "6米8_20吨+"
        } else if (length >= 8.2 && length < 10.8 && weight < 13) {
            length_weight = "9米6_10吨"
        } else if (length >= 8.2 && length < 10.8 && weight >= 13 && weight < 17) {
            length_weight = "9米6_16吨"
        } else if (length >= 8.2 && length < 10.8 && weight >= 17 && weight < 20) {
            length_weight = "9米6_18吨"
        } else if (length >= 8.2 && length < 10.8 && weight >= 20 && weight < 23.5) {
            length_weight = "9米6_22吨"
        } else if (length >= 8.2 && length < 10.8 && weight >= 23.5 && weight < 27.5) {
            length_weight = "9米6_25吨"
        } else if (length >= 8.2 && length < 10.8 && weight >= 27.5) {
            length_weight = "9米6_30吨+"
        } else if (length >= 10.8 && length < 14 && weight < 21.5) {
            length_weight = "12米_18吨"
        } else if (length >= 10.8 && length < 14 && weight >= 21.5 && weight < 27.5) {
            length_weight = "12米_25吨"
        } else if (length >= 10.8 && length < 14 && weight >= 27.5 && weight < 32.5) {
            length_weight = "12米_30吨"
        } else if (length >= 10.8 && length < 14 && weight >= 32.5 && weight < 37.5) {
            length_weight = "12米_35吨"
        } else if (length >= 10.8 && length < 14 && weight >= 37.5 && weight < 42.5) {
            length_weight = "12米_40吨"
        } else if (length >= 10.8 && length < 14 && weight >= 42.5) {
            length_weight = "12米_45吨+"
        } else if (length >= 14 && length < 18 && weight < 37.5) {
            length_weight = "16米_35吨"
        } else if (length >= 14 && length < 18 && weight >= 37.5 && weight < 50) {
            length_weight = "16米_40吨"
        } else if (length >= 14 && length < 18 && weight >= 50 && weight < 65) {
            length_weight = "16米_60吨"
        } else if (length >= 14 && length < 18 && weight >= 65) {
            length_weight = "16米_70吨"
        } else if (length >= 18 && weight < 21.5) {
            length_weight = "19米1_18吨"
        } else if (length >= 18 && weight >= 21.5) {
            length_weight = "19米1_25吨"
        }
        length_weight
    }

    /**
     * 处理dm_gis.eta_std_line_recall表
     * @param spark SparkSession
     * @param incDay 日期
     * @param areaCodes 大区参数
     * @return
     */
    def eta_std_line_recall(spark: SparkSession, incDay: String, areaCodes: String): DataFrame = {
        val sql =
            s"""
               |select
               |    task_area_code,
               |    task_id,
               |    task_subid,
               |    start_dept,
               |    end_dept,
               |    start_type,
               |    end_type,
               |    line_code,
               |    concat_ws('_', line_code, start_dept, end_dept) as line,
               |    concat_ws('_', line_code, start_dept, end_dept, vehicle_type) as linevehicle,
               |    concat_ws('_', line_code, start_dept, end_dept, vehicle_type, actual_capacity_load) as linemload,
               |    case when actual_capacity_load < 1.5 then 0.84
               |         when actual_capacity_load >= 1.5 and actual_capacity_load < 3 then 0.84
               |         when actual_capacity_load >= 3 and actual_capacity_load < 5 then 0.88
               |         when actual_capacity_load >= 5 and actual_capacity_load < 7 then 1.07
               |         when actual_capacity_load >= 7 and actual_capacity_load < 14 then 1.36
               |         when actual_capacity_load >= 14 and actual_capacity_load < 20 then 1.51
               |         when actual_capacity_load >= 20 and actual_capacity_load < 30 then 1.88
               |         when actual_capacity_load >= 30 then 1.99
               |         end as unitprice,
               |    vehicle_serial,
               |    actual_capacity_load,
               |    actual_depart_tm,
               |    actual_arrive_tm,
               |    line_time,
               |    line_distance,
               |    actual_run_time,
               |    is_stop,
               |    stop_over_zone_code,
               |    transoport_level,
               |    carrier_type,
               |	carrier_name,
               |    plf_flag,
               |    vehicle_type,
               |    axls_number,
               |    log_dist,
               |    duration,
               |    time,
               |    error_type,
               |    rt_dist,
               |    highwaymileage,
               |    toll_charge,
               |    error_type,
               |    pns_dist,
               |    pns_time,
               |    src,
               |    line_distance_std,
               |    line_time_std,
               |    sim1,
               |    sim5,
               |    conduct_type,
               |    is_run_ontime_std,
               |    is_run_ontime,
               |    tl_time,
               |    halfway_integrate_rate,
               |    biz_type,
               |    require_category,
               |    std_toll_charge,
               |    start_longitude,
               |    start_latitude,
               |    end_longitude,
               |    end_latitude,
               |    std_id,
               |	accrual_dist,
               |    sort_num,
               |    inc_day
               |from dm_gis.eta_std_line_recall
               |where inc_day = '$incDay' and carrier_type = 0 and task_area_code not rlike '^[MPTS]{1}.+'
               |order by line_code, line, linevehicle, linemload, task_id
               |""".stripMargin

        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 处理表dm_gis.eta_std_line_conf
     * @param spark SparkSession
     * @return
     */
    def eta_std_line_conf(spark: SparkSession): DataFrame = {
        val sql =
            s"""
               |select
               |    std_id as std_id_jz,
               |	src_deptcode,
               |    dest_deptcode,
               |    line_code,
               |    vehicle,
               |    concat_ws('_', line_code, src_deptcode, dest_deptcode, vehicle) as linevehicle_jz,
               |	is_econ,
               |    create_time ,
               |    update_time ,
               |    add_reason,
               |    opt_user
               |from dm_gis.eta_std_line_conf
               |where delete_flag = 0 and is_econ = 0
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 处理ods_vms.tt_vms_driving_log_item表
     * @param spark SparkSession
     * @param curMonth 当月
     * @param lastMonth 上月
     * @return
     */
    def tt_vms_driving_log_item(spark: SparkSession, curMonth: String, lastMonth: String): DataFrame = {
        val sql =
            s"""
               |with t1 as (
               |	select
               |		task_id,
               |		road_fee,
               |		miles,
               |		fuel_prices
               |	from
               |	(
               |		select
               |			task_id,
               |			road_fee,
               |			miles,
               |			fuel_prices,
               |			row_number() over(partition by driving_log_item_id order by created_tm desc) rn
               |		from ods_vms.tt_vms_driving_log_item
               |		where task_id <> ''
               |			and task_id is not null
               |			and length(task_id) < 15
               |			and inc_month in ('$curMonth', '$lastMonth')
               |	) t
               |	where rn = 1
               |),
               |t2 as (
               |	select
               |		task_id,
               |		sum(cast(road_fee as double)) road_fee,
               |		sum(cast(miles as double)) miles
               |	from t1 group by task_id
               |),
               |t3 as (
               |	select
               |		avg(cast(fuel_prices as double)) fuel_prices
               |	from t1 where fuel_prices <> 0
               |)
               |select
               |	task_id,
               |	road_fee,
               |	miles,
               |	fuel_prices
               |from t2
               |left join t3
               |on 1 = 1
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 读取ods_vms.tm_vms_vehicle表，经过处理后与建制表csv合并
     * @param spark SparkSession
     * @param incDay inc_day
     * @param csvPath 建制表在hdfs的路径
     * @return
     */
    def merge_tm_vms_vehicle_and_csv_file(spark: SparkSession, incDay: String, csvPath: String): DataFrame = {
        val jian_zhi_csv = spark.read
            .option("header", "true")
            .option("sep", "\t")
            .csv(csvPath)
        LOGGER.info("建制表读取成功")

        val sql1 =
            s"""
               |select
               |	vehicle_code                                                             as vehicle_serial,
               |	fuel_type                                                                as energy,
               |	round(cast(max_load as double) / 1000, 2)                                as mload,
               |	round(cast(outer_length as double) / 1000, 2)                            as length,
               |	round(cast(outer_width as double) / 1000, 2)                             as width,
               |	round(cast(outer_height as double) / 1000, 2)                            as height,
               |	plate_color                                                              as plateColor,
               |	axes                                                                     as axle_number,
               |	emissionrulecode                                                         as emitStand,
               |	round((cast(max_load as double) + cast(net_weight as double)) / 1000, 2) as weight,
               |	""                                                                       as car_type
               |from ods_vms.tm_vms_vehicle
               |where inc_day = '$incDay'
               |""".stripMargin

        LOGGER.info(sql1)
        val tm_vms_vehicle = spark.sql(sql1)
        LOGGER.info("ods_vms.tm_vms_vehicle表查询成功.")
        jian_zhi_csv.createOrReplaceTempView("jian_zhi")
        tm_vms_vehicle.createOrReplaceTempView("vms_vehicle")
        spark.udf.register("judge_length_weight", judge_length_weight _)

        val sql2 =
            s"""
               |select
               |	vehicle_serial,
               |	energy,
               |	mload,
               |	length,
               |	width,
               |	height,
               |	plateColor,
               |	axle_number,
               |	emitStand,
               |	weight,
               |    car_type,
               |	judge_length_weight(car_type, length, weight) length_weight
               |from
               |(
               |	select
               |		*,
               |		row_number() over(partition by vehicle_serial order by flag desc) rn
               |	from
               |	(
               |		select
               |			vehicle vehicle_serial,
               |			energy,
               |			cast(mload as double) mload,
               |			cast(length as double) length,
               |			cast(width as double) width,
               |			cast(height as double) height,
               |			plateColor,
               |			axle_number,
               |			emitStand,
               |			cast(weight as double) weight,
               |			car_type,
               |			1 flag
               |		from jian_zhi
               |		union all
               |		select
               |			vehicle_serial,
               |			energy,
               |			mload,
               |			length,
               |			width,
               |			height,
               |			plateColor,
               |			axle_number,
               |			emitStand,
               |			weight,
               |			car_type,
               |			0 flag
               |		from vms_vehicle
               |	) t1
               |) t2
               |where rn = 1
               |""".stripMargin

        LOGGER.info(sql2)
        spark.sql(sql2)
    }

    def execute(spark: SparkSession, areaCodes: String, curMonth: String,
                lastMonth: String, incDay: String, csvPath: String): Unit = {
        LOGGER.info("任务监控表（中间表1）：dm_gis.eta_std_line_recall")
        val table1 = eta_std_line_recall(spark, incDay, areaCodes)
        LOGGER.info("标准线路配置表（中间表2）：dm_gis.eta_std_line_conf")
        val table2 = eta_std_line_conf(spark)
        LOGGER.info("行车日志表（中间表3）：ods_vms.tt_vms_driving_log_item")
        val table3 = tt_vms_driving_log_item(spark, curMonth, lastMonth)
        LOGGER.info("车辆信息表（中间表4）：ods_vms.tm_vms_vehicle")
        val table4 = merge_tm_vms_vehicle_and_csv_file(spark, incDay, csvPath)

        LOGGER.info("##########################注册临时视图查询##########################")

        table1.createOrReplaceTempView("t1")
        table2.createOrReplaceTempView("t2")
        table3.createOrReplaceTempView("t3")
        table4.createOrReplaceTempView("t4")

        val sql =
            s"""
               |insert overwrite table dm_gis.gis_eta_jiazhi_task partition(inc_day = '$incDay')
               |select
               |    t1.task_area_code,
               |    t1.task_id,
               |    t1.task_subid,
               |    t1.sort_num,
               |    t1.start_dept,
               |    t1.end_dept,
               |    t1.start_type,
               |    t1.end_type,
               |    t1.line_code,
               |    t1.linevehicle,
               |	t1.linemload,
               |    t1.std_id,
               |    t1.vehicle_serial,
               |    if(t1.conduct_type = 1 and t1.std_id != '' and t1.std_id is not null and t1.std_id = t2.std_id_jz, 1, 3),
               |    t1.is_run_ontime,
               |    t1.start_longitude,
               |    t1.start_latitude,
               |    t1.end_longitude,
               |    t1.end_latitude,
               |	t1.rt_dist,
               |	t1.accrual_dist,
               |	t1.toll_charge,
               |    t1.is_stop,
               |    t1.stop_over_zone_code,
               |    t1.transoport_level,
               |    t1.carrier_type,
               |    t1.carrier_name,
               |    t1.vehicle_type,
               |    t4.axle_number,
               |    t4.length,
               |    t4.weight,
               |    t4.mload,
               |    t4.car_type,
               |    t4.length_weight,
               |    t3.miles,
               |    t3.road_fee,
               |    t3.fuel_prices,
               |    t1.error_type,
               |    0 reject_flag,
               |    t2.linevehicle_jz,
               |    t2.std_id_jz,
               |    t2.update_time,
               |    t2.add_reason,
               |    t2.opt_user
               |from t1
               |left join t2 on t1.line_code = t2.line_code
               |left join t3 on t1.task_id = t3.task_id
               |left join t4 on t1.vehicle_serial = t4.vehicle_serial
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql("set spark.sql.crossJoin.enabled = true")
        spark.sql(sql)
        LOGGER.info("##########################dm_gis.gis_eta_jiazhi_task写入成功##########################")
    }
}

object StandardLineIndicatorMonitoring1 {
    def main(args: Array[String]): Unit = {
        val task = new StandardLineIndicatorMonitoring1
        task.LOGGER.info("args length: [{}]", args.length)

        if (args == null || args.length != 3) {
            task.LOGGER.error("请传入日期参数和大区参数，日期参数格式[yyyyMMdd], 大区参数格式如[\"333Y\",\"222Y\",\"777Y\"]")
            return
        }
        val incDay = args(0)
        val areaCodes = args(1)
        val csvPath = args(2)
        if (StringUtils.isEmpty(incDay) || StringUtils.isEmpty(areaCodes) || StringUtils.isEmpty(csvPath)) {
            task.LOGGER.error("参数错误存在空值")
            return
        }
//        val curMonth = DateUtil.getBeforeNMonth(incDay, 0)
//        val lastMonth = DateUtil.getBeforeNMonth(incDay, -1)

        val curMonth = DateUtil.getMouthBefore(incDay, 0).substring(0,6)
        val lastMonth = DateUtil.getMouthBefore(incDay, 1).substring(0,6)

        task.LOGGER.info("###########################################################")
        task.LOGGER.info("incDay: [{}]", incDay)
        task.LOGGER.info("curMonth: [{}]", curMonth)
        task.LOGGER.info("lastMonth: [{}]", lastMonth)
        task.LOGGER.info("areaCodes: [{}]", areaCodes)
        task.LOGGER.info("csvPath: [{}]", csvPath)
        task.LOGGER.info("###########################################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession

        task.execute(spark, areaCodes, curMonth, lastMonth, incDay, csvPath)

        task.LOGGER.info("任务执行完成")

        spark.stop()
    }
}
