package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.pns.app.route.GisEtaJiaZhiCostStatNewDetail.{getMload, getOnlineFlag}
import com.sf.gis.scala.pns.utils.Functions.isEmptyOrNull
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * GIS-RDS-PNS 价值线路指标监控需求V2.0
 * 需求方：刘思嘉（01420030）
 * @author 徐游飞（01417347）
 * 任务ID：761521
 * 任务名称：价值线路降本逻辑优化_6.1.1&6.2.1
 * git 未提交
 */
object GisEtaJiazhiCostStatNew2 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  // 计算结果表6_1_1 和 结果表6_2_1
  def gisEtaJiazhiCostStatNew2(spark: SparkSession, dayBefore1: String, dayBefore3: String) = {
    import spark.implicits._
    val start_date = DateUtil.getDayBefore(dayBefore1, "yyyyMMdd", 2)
    val end_date = dayBefore1
    // 获取结果表55_1数据
    val compute_fee_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.gis_eta_jiazhi_cost_compute55_addition_fee
         |where
         |  inc_day >= '$start_date'
         |  and inc_day <= '$end_date'
         |""".stripMargin
    println("获取结果表55_1数据 sql语句：")
    println(compute_fee_sql)
    val df_compute_fee = spark.sql(compute_fee_sql)
      .withColumn("online_date_1", when('online_date_jz > "20230101", 'online_date_jz).otherwise("20230101"))
      .filter(!isEmptyOrNull('diff_sum_cost_new))  // 保留diff_sum_cost 不为空的数据

    val df_start_new = df_compute_fee
      .groupBy("task_area_code", "line_code", "vehicle_type", "online_date_1", "inc_day")
      .agg(
        sum('miles_new) as "miles_new",
        sum('road_fee_new) as "road_fee_new",
        sum('fuel_cost_new) as "fuel_cost_new",
        sum('sum_cost_new) as "sum_cost_new",
        sum('re_road_fee_new) as "re_road_fee_new",
        sum('re_miles_new) as "re_miles_new",
        sum('re_fuel_cost_new) as "re_fuel_cost_new",
        sum('re_sum_cost_new) as "re_sum_cost_new",
        sum('diff_road_fee_new) as "diff_road_fee_new",
        sum('diff_fuel_cost_new) as "diff_fuel_cost_new",
        sum('diff_miles_new) as "diff_miles_new",
        sum('diff_sum_cost_new) as "diff_sum_cost_new",
        count('task_id) as "num_sum",
        count('task_id) as "num",
        max('online_date_jz) as "online_date_jz"
      )
      //.withColumn("online_date",'online_date_old)
//      .na.fill("", Array("sum_cost_new"))
      .withColumn("diff_cost_flag", when('diff_sum_cost_new === 0, 0)
        .when('diff_sum_cost_new > 0, 1)
        .when('diff_sum_cost_new < 0, 2))
      .withColumn("road_fee_mean_new", when('num =!= 0, 'road_fee_new / 'num).otherwise(0))
      .withColumn("miles_mean_new", when('num =!= 0, 'miles_new / 'num).otherwise(0))
      .withColumn("fuel_cost_mean_new", when('num =!= 0, 'fuel_cost_new / 'num).otherwise(0))
      .withColumn("sum_cost_mean_new", when('num =!= 0, 'sum_cost_new / 'num).otherwise(0))
      .withColumn("re_road_fee_mean_new", when('num =!= 0, 're_road_fee_new / 'num).otherwise(0))
      .withColumn("re_miles_mean_new", when('num =!= 0, 're_miles_new / 'num).otherwise(0))
      .withColumn("re_fuel_cost_mean_new", when('num =!= 0, 're_fuel_cost_new / 'num).otherwise(0))
      .withColumn("re_sum_cost_mean_new", when('num =!= 0, 're_sum_cost_new / 'num).otherwise(0))
      .withColumn("diff_road_fee_mean_new", when('num =!= 0, 'diff_road_fee_new / 'num).otherwise(0))
      .withColumn("diff_fuel_cost_mean_new", when('num =!= 0, 'diff_fuel_cost_new / 'num).otherwise(0))
      .withColumn("diff_miles_mean_new", when('num =!= 0, 'diff_miles_new / 'num).otherwise(0))
      .withColumn("diff_sum_cost_mean_new", when('num =!= 0, 'diff_sum_cost_new / 'num).otherwise(0))

    // 结果表6_1_1保存至hive
    val cols_start_new = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_stat_new_addition_fee limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_start_new.select(cols_start_new: _*),Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_stat_new_addition_fee")

    // 计算结果表6_2_1
    gisEtaJiaZhiCostStatNewDetailAdditionFee(spark,df_start_new,dayBefore1,dayBefore3)
  }

  // 获取表6_1_1数据
  def getStatNewFeeData(spark: SparkSession, dayBefore1: String, dayBefore3: String) = {
    val stat_new_sql =
      s"""
         |select
         |  line_code,
         |  vehicle_type,
         |  online_date_1,
         |  task_area_code,
         |  inc_day,
         |  diff_sum_cost_mean_new,
         |  diff_road_fee_mean_new,
         |  diff_fuel_cost_mean_new,
         |  diff_miles_mean_new,
         |  sum_cost_mean_new,
         |  road_fee_mean_new,
         |  fuel_cost_mean_new,
         |  miles_mean_new,
         |  re_sum_cost_mean_new,
         |  re_road_fee_mean_new,
         |  re_fuel_cost_mean_new,
         |  re_miles_mean_new,
         |  diff_cost_flag
         |from
         |  dm_gis.gis_eta_jiazhi_cost_stat_new_addition_fee
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore1'
         |  and diff_cost_flag in ('0','2')
         |  and 	online_date_1 != ''
         |  and 	online_date_1 is not null
         |""".stripMargin
    println("获取表6_1_1数据 sql语句：")
    println(stat_new_sql)
    val df_stat_new = spark.sql(stat_new_sql)

    df_stat_new
  }

  // 获取执行率明细表（结果表4）数据
  def getJiaZhiData(spark: SparkSession, dayBefore1: String, dayBefore3: String) = {

    val jiazhi_1_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall_jiazhi_1
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore1'
         |  and task_type = '1'
         |  and statistical_marker = '2'
         |""".stripMargin
    println("获取执行率明细表（结果表4）数据 sql语句：")
    println(jiazhi_1_sql)
    val df_jiazhi_1 = spark.sql(jiazhi_1_sql)

    df_jiazhi_1
  }

  // 计算结果表6_2_1
  def gisEtaJiaZhiCostStatNewDetailAdditionFee(spark: SparkSession, df_start_new: DataFrame, dayBefore1: String, dayBefore3: String) = {

    import spark.implicits._
    // 获取执行率明细表（结果表4）数据
    val df_jiazhi_1 = getJiaZhiData(spark,dayBefore1,dayBefore3)
    // 获取表6_1_1数据
    val df_stat_new_fee = getStatNewFeeData(spark,dayBefore1,dayBefore3)

    val df_ret = df_jiazhi_1
      .join(df_stat_new_fee, Seq("line_code", "vehicle_type", "online_date_1", "task_area_code", "inc_day"), "left")
      .withColumn("conduct_type", when('conduct_type === 1, "已执行").otherwise("未执行"))
      .withColumn("ac_is_run_ontime_std", when('ac_is_run_ontime_std === 1.0, "准点").otherwise("超时"))
      .withColumn("mload", getMload('linemload))
      .withColumn("online_flag", getOnlineFlag('online_date_1))

    // 结果表6_2_1保存至hive
    val cols_dtl = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_stat_new_detail_addition_fee limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_ret.select(cols_dtl: _*), Seq("inc_day"), "dm_gis.gis_eta_jiazhi_cost_stat_new_detail_addition_fee")

  }

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始  ++++")

    // 计算结果表6_1_1 和 结果表6_2_1
    gisEtaJiazhiCostStatNew2(spark,dayBefore1,dayBefore3)

    logger.error("++++++++  任务完成  ++++")
  }

}
