package com.sf.gis.scala.pns.app.valueLine

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.pns.app.valueLine.StandardLineNewPrecept._
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * GIS-RSS-PNS：【价值线路】筛选工艺流程线上化需求——旧方案
 * 需求方：刘俊荣（ft80006349）
 * @author 徐游飞（01417347）
 * 任务ID：990700
 * 任务名称：筛选工艺流程线上化_旧方案部分—1_2
 */
object StandardLineNewPrecept_old1_2 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def getLineTaskMload(spark: SparkSession, resultNewDF: DataFrame, vmsVehicleDF: DataFrame, dayBefore1: String, dayBefore31: String) = {
    // 7.1取数 --> 标准旧方案筛选,获取任务数据（任务监控表）(表4)
    val lineRecallDF_old = getLineRecallOld(spark, resultNewDF, dayBefore1, dayBefore31).persist(StorageLevel.MEMORY_AND_DISK)

    import spark.implicits._
    // 7.2数据处理-任务数据
    val df_task = lineRecallDF_old
      .groupBy("task_area_code", "linevehicle")
      .agg(
        avg("rt_dist") as "avg_dist",
        count("task_id") as "sum_num"
      )
      .filter('avg_dist / 1000 >= 10 and 'sum_num >= 5)
      .drop("avg_dist", "sum_num")
      .join(lineRecallDF_old, Seq("task_area_code", "linevehicle"), "inner")
      .join(vmsVehicleDF.drop("mload"), Seq("vehicle_serial"), "left")
      .withColumn("mload", coalesce('mload, 'actual_capacity_load))
      .withColumn("mload_1", when('mload <= 1, 1.0)
        .when('mload <= 2, 1.5)
        .when('mload <= 4, 3.0)
        .when('mload <= 6, 5.0)
        .when('mload <= 10, 7.0)
        .when('mload <= 17, 14.0)
        .when('mload <= 25, 20.0)
        .otherwise(30.0)
      )
      .withColumn("inc_day", lit(dayBefore1))

    // 临时中间表，方便异常数据定位
    val cols_1 = spark.sql("""select * from dm_gis.dm_line_task_mload_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_task.select(cols_1: _*).coalesce(10), Seq("inc_day"), "dm_gis.dm_line_task_mload_di")

  }

  def main(args: Array[String]): Unit = {

    val dayBefore1 = args(0)
    val dayBefore31 = args(1)
    val month = args(2)
    val monthBefore1 = args(3)
    //日期检查
    logger.error("DayBefore1="+dayBefore1)
    logger.error("dayBefore31="+dayBefore31)
    logger.error("month="+month)
    logger.error("monthBefore1="+monthBefore1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231207 ++++")
    // 获取新方案结果数据,过滤调已推送的价值线路
    val resultNewDF = spark.sql(s"select * from dm_gis.gis_eta_vl_result_new where inc_day = '$dayBefore1'")
    // 3.获取整合车参信息（表1）
    val vmsVehicleDF = getVmsVehicle(spark, dayBefore1)
    // 7.1 线路匹配接口前数据落表
    getLineTaskMload(spark,resultNewDF,vmsVehicleDF,dayBefore1,dayBefore31)

    logger.error("++++++++  任务结束  ++++")
    spark.stop()
  }
}
