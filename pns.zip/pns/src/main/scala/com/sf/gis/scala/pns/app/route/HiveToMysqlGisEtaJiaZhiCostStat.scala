package com.sf.gis.scala.pns.app.route

import java.sql.{Connection, DriverManager, Statement}
import java.util.UUID
import com.sf.gis.java.base.util.SparkUtil
import org.apache.spark.sql.SaveMode
import org.slf4j.LoggerFactory

object HiveToMysqlGisEtaJiaZhiCostStat {

    val logger = LoggerFactory.getLogger(this.getClass)
    var connection: Connection = null

    def main(args: Array[String]): Unit = {
        val incDay = args(0)
        println("===================================")
        println("incDay: " + incDay)
        println("===================================")

        // 执行插入之前先删除
        drop_current_mysql_data(incDay)

        val SparkInfo = SparkUtil.getSpark("HIveToMysqlGisEtaJiaZhiCostStat")
        val spark = SparkInfo.getSession
        spark.udf.register("uuid", () => (UUID.randomUUID() + "").replace("-", ""))

        val sql =
            s"""
               |select
               |    uuid()                              as id,
               |    inc_day                             as statdate,
               |    task_area_code,
               |    carrier_name,
               |    line_code,
               |    source,
               |    online_date,
               |    task_inc_day,
               |    cast(line_num_sum as int)           as line_num_sum,
               |    cast(line_num as int)               as line_num,
               |    cast(num_sum as int)                as num_sum,
               |    cast(num as int)                    as num,
               |    cast(reject_num as int)             as reject_num,
               |    cast(if(re_cost_mean = 'NaN', null, re_cost_mean) as double)               as re_cost_mean,
               |    cast(if(re_roadfee_mean = 'NaN', null, re_roadfee_mean) as double)         as re_roadfee_mean,
               |    cast(if(re_fuel_cost_mean = 'NaN', null, re_fuel_cost_mean) as double)     as re_fuel_cost_mean,
               |    cast(if(re_miles_mean = 'NaN', null, re_miles_mean) as double)             as re_miles_mean,
               |    cast(if(cost_mean = 'NaN', null, cost_mean) as double)                     as cost_mean,
               |    cast(if(roadfee_mean = 'NaN', null, roadfee_mean) as double)               as roadfee_mean,
               |    cast(if(fuel_cost_mean = 'NaN', null, fuel_cost_mean) as double)           as fuel_cost_mean,
               |    cast(if(miles_mean = 'NaN', null, miles_mean) as double)                   as miles_mean,
               |    cast(if(diff_cost_mean = 'NaN', null, diff_cost_mean) as double)           as diff_cost_mean,
               |    cast(if(diff_roadfee_mean = 'NaN', null, diff_roadfee_mean) as double)     as diff_roadfee_mean,
               |    cast(if(diff_fuel_cost_mean = 'NaN', null, diff_fuel_cost_mean) as double) as diff_fuel_cost_mean,
               |    cast(if(diff_miles_mean = 'NaN', null, diff_miles_mean) as double)         as diff_miles_mean,
               |    cast(if(cost = 'NaN', null, cost) as double)                               as cost,
               |    cast(if(roadfee = 'NaN', null, roadfee) as double)                         as roadfee,
               |    cast(if(fuel_cost = 'NaN', null, fuel_cost) as double)                     as fuel_cost,
               |    cast(if(miles = 'NaN', null, miles) as double)                             as miles,
               |    cast(if(re_cost = 'NaN', null, re_cost) as double)                         as re_cost,
               |    cast(if(re_roadfee = 'NaN', null, re_roadfee) as double)                   as re_roadfee,
               |    cast(if(re_fuel_cost = 'NaN', null, re_fuel_cost) as double)               as re_fuel_cost,
               |    cast(if(re_miles = 'NaN', null, re_miles) as double)                       as re_miles,
               |    cast(if(diff_cost = 'NaN', null, diff_cost) as double)                     as diff_cost,
               |    cast(if(diff_roadfee = 'NaN', null, diff_roadfee) as double)               as diff_roadfee,
               |    cast(if(diff_fuel_cost = 'NaN', null, diff_fuel_cost) as double)           as diff_fuel_cost,
               |    cast(if(diff_miles = 'NaN', null, diff_miles) as double)                   as diff_miles,
               |    cast(if(rate = 'NaN', null, rate) as double)                               as rate,
               |    cast(if(road_fee_rate = 'NaN', null, road_fee_rate) as double)             as road_fee_rate,
               |    cast(if(fuel_cost_rate = 'NaN', null, fuel_cost_rate) as double)           as fuel_cost_rate,
               |    cast(if(miles_rate = 'NaN', null, miles_rate) as double)                   as miles_rate
               |from dm_gis.gis_eta_jiazhi_cost_stat where inc_day = '$incDay'
               |""".stripMargin
        println("===================================")
        println(sql)
        println("===================================")
        val df = spark.sql(sql)

        df.repartition(1) // 小数据量
            .write
            .format("jdbc")
            .mode(SaveMode.Append)
            .option("url", "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useUnicode=true&amp;characterEncoding=utf-8")
            .option("dbtable", "gis_oms_lip_pns.GIS_ETA_JIAZHI_COST_STAT")
            .option("user", "gis_oms_pns")
            .option("password", "gis_oms_pns@123@")
            .option("batchsize","1000")
            .save()

        println("============数据同步完成==============")
        spark.stop()
    }

    /**
     * 防止有跑数的情况，删除业务当天数据
     * @param incDay 分区日期
     */
    def drop_current_mysql_data(incDay: String): Unit = {
        var conn: Connection = null
        var statement: Statement = null
        try {
            conn = getDevMysqlConnect()
            statement = conn.createStatement()
            val sql = "delete from gis_oms_lip_pns.GIS_ETA_JIAZHI_COST_STAT where STATDATE='%s'".format(incDay)
            println("===================================")
            println(sql)
            val n = statement.executeUpdate(sql)
            println("共删除 " + n + " 行数据")
            println("===================================")
        } catch {
            case ex: Exception => {
                println("操作mysql数据库时出现错误")
                throw ex
            }
        } finally {
            if (statement != null) statement.close()
            if (conn != null) conn.close()
        }
    }

    /**
     * 获取数据库连接gis_oms_lip_pns
     */
    def getDevMysqlConnect(): Connection = {
        val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useUnicode=true&characterEncoding=utf-8"
        //驱动名称
        val driver = "com.mysql.jdbc.Driver"
        //用户名
        val username = "gis_oms_pns"
        //密码
        val password = "gis_oms_pns@123@"

        try {
            //注册Driver
            Class.forName(driver)
            //得到连接
            connection = DriverManager.getConnection(url, username, password)
            connection
        } catch {
            case ex: Exception => logger.error("连接mysql数据库时出现错误", ex)
                throw ex
        }
    }
}
