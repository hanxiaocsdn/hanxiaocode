package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil, UrlUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.pns.app.RoadBridgeFeeIntegration.logger
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{asc, col, collect_list, concat, concat_ws, desc, expr, lit, lpad, rand, round, row_number, sort_array, trim, udf, when}
import org.apache.spark.storage.StorageLevel
import com.sf.gis.scala.pns.utils.Utils

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}
import scala.collection.mutable.ArrayBuffer

/**
 **需求名称：路桥费信息整合-外部车辆
 **任务id：780697
 **研发：01390943周勇，需求方：01367324李小璐，01425161黄谦
 **日期：2023-07-24
 **需求背景：外部车收费账单为月度，其对应的任务和轨迹量大，下载到线下处理周期长，线上处理加快迭代周期。
 **/

object RoadBridgeFeeIntegrationWb {
  //****获取应用名称
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args:Array[String]): Unit = {
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取日期：上月最后一天
    val dayvar = args(0)
    //获取月份
    val monthvar = dayvar.substring(0, 6)
    //取跑数T-30日期
    val dayvar30 = getdaysBeforeOrAfter(dayvar, -30)

    logger.error("接收输入变量dayvar:" + dayvar)
    logger.error("接收输入变量monthvar:" + monthvar)
    logger.error("接收输入变量dayvar30:" + dayvar30)

    //获取record表，清洗出task_result
//    val record_data_org=spark.sql(
//      s"""
//         |select '2' as task_type,task_id,trim(plate) as vehicle,
//         |task_start_time as actual_depart_tm,
//         |task_end_time as actual_arrive_tm,
//         |task_result,
//         |vehicle_type
//         |from dm_gis.dm_eta_task_tolls_record_dtl_di
//         |where inc_day='$dayvar' and
//         |vehicle_type is not null and trim(vehicle_type) !=''
//         |""".stripMargin)

    val record_data_org=spark.sql(
      s"""
         |select '2' as task_type,task_id,trim(plate) as vehicle,
         |task_start_time as actual_depart_tm,
         |task_end_time as actual_arrive_tm,
         |task_result,
         |vehicle_type
         |from dm_gis.dm_supplier_roadbridge_fees_dtl
         |where inc_day='$dayvar' and task_status='6' and task_type='0'
         |""".stripMargin)

    //转化为rdd，然后重分区
    val rep_ct=30
    val record_data_rdd = SparkUtils.getDfToJson(spark, record_data_org, rep_ct)

    //计算清洗task_result字段
    val record_data_rdd2 =record_data_rdd.map(x=>{
      val task_type=x.getString("task_type")
      val task_id=x.getString("task_id")
      val vehicle=x.getString("vehicle")
      val actual_depart_tm=x.getString("actual_depart_tm")
      val actual_arrive_tm=x.getString("actual_arrive_tm")
      //val real_amount=x.getString("real_amount")
      val task_result=x.getString("task_result")
      val vehicle_type=x.getString("vehicle_type")
      //解析json字段
      val enplazaname_arr=new ArrayBuffer[String]()
      val explazaname_arr=new ArrayBuffer[String]()
      val discountfee_arr=new ArrayBuffer[Int]()
      val real_amount_arr=new ArrayBuffer[Int]()
      val endatetime_arr=new ArrayBuffer[String]()
      val exdatetime_arr=new ArrayBuffer[String]()

      if(task_result !=null && task_result.trim !=""){
        val json_obj=JSON.parseObject(task_result)
        val json_body=json_obj.getJSONArray("body")
        val s=json_body.size()
        for(i<-0 until  s){
          val enplazaname_i=json_body.getJSONObject(i).getString("enPlazaName")
          val explazaname_i=json_body.getJSONObject(i).getString("exPlazaName")
          val discountfee_i=json_body.getJSONObject(i).getInteger("discountFee")
          val fee_i=json_body.getJSONObject(i).getInteger("fee")
          val endatetime_i=json_body.getJSONObject(i).getString("enDateTime")
          val exdatetime_i=json_body.getJSONObject(i).getString("exDateTime")
          enplazaname_arr.append(enplazaname_i)
          explazaname_arr.append(explazaname_i)
          discountfee_arr.append(discountfee_i)
          real_amount_arr.append(fee_i)
          endatetime_arr.append(endatetime_i)
          exdatetime_arr.append(exdatetime_i)
        }
      }
      val highway_start_name=enplazaname_arr.mkString("|")
      val highway_end_name=explazaname_arr.mkString("|")
      val discout_amount=discountfee_arr.sum
      val real_amount=real_amount_arr.sum
      val endatetime=endatetime_arr.mkString("|")
      val exdatetime=exdatetime_arr.mkString("|")
      (task_type,task_id,vehicle,actual_depart_tm,actual_arrive_tm,highway_start_name,highway_end_name
        ,real_amount,discout_amount,vehicle_type,endatetime,exdatetime)
    }).toDF("task_type","task_id","vehicle","actual_depart_tm","actual_arrive_tm","highway_start_name",
      "highway_end_name","real_amount","discout_amount","vehicle_type","endatetime","exdatetime")

    //获取record表
      val record_data0=record_data_rdd2
      .withColumn("fee_type",lit(""))
      .withColumn("vehicle_classify_id",when($"vehicle_type"==="11","101").
        when($"vehicle_type"==="12","102").when($"vehicle_type"==="13","103").
        when($"vehicle_type"==="14","104").when($"vehicle_type"==="15","105").
        when($"vehicle_type"==="16","106"). when($"vehicle_type"==="1","201").
        when($"vehicle_type"==="2","202"). when($"vehicle_type"==="3","203").
        when($"vehicle_type"==="4","204").when(trim($"vehicle_type")==="" || $"vehicle_type".isNull,"000")
        .otherwise(""))
      .withColumn("gc_vehicle",lit(""))
      .withColumn("gc_axis",lit(""))
      .withColumn("gc_macthtype",lit(""))
      .withColumn("network",lit(""))
      .withColumn("outerlength",when($"vehicle_type"==="11","4.2").
        when($"vehicle_type"==="12","6.2").when($"vehicle_type"==="13","9.6").
        when($"vehicle_type"==="14","12.5").when($"vehicle_type"==="15","14").
        when($"vehicle_type"==="16","17").otherwise(""))
      .withColumn("outerwidth",when($"vehicle_type"==="11","1.9").
        when($"vehicle_type"==="12","2").when($"vehicle_type"==="13","2.3").
        when($"vehicle_type"==="14","2.4").when($"vehicle_type"==="15","2.4").
        when($"vehicle_type"==="16","2.4").otherwise(""))
      .withColumn("loadweight",when($"vehicle_type"==="11","2").
        when($"vehicle_type"==="12","5").when($"vehicle_type"==="13","8").
        when($"vehicle_type"==="14","12").when($"vehicle_type"==="15","25").
        when($"vehicle_type"==="16","30").otherwise(""))
      .withColumn("numberofaxles",when($"vehicle_type"==="11","2").
        when($"vehicle_type"==="12","2").when($"vehicle_type"==="13","3").
        when($"vehicle_type"==="14","4").when($"vehicle_type"==="15","5").
        when($"vehicle_type"==="16","6").otherwise(""))
      .withColumn("emissionstandard",lit(""))
      .withColumn("typelicense",lit(""))
      .withColumn("fueltype",lit(""))
      .withColumn("cardtype",lit(""))
      .withColumn("flag",lit("1"))
      //index为唯一识别号
      .withColumn("index",row_number().over(Window.partitionBy("flag").orderBy(desc("actual_depart_tm"))))
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("record_data0数据量为："+record_data0.count())

    val record_data0a=record_data0.select("index","vehicle","actual_depart_tm","actual_arrive_tm")
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = excutors * cores * 3
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, record_data0a, calPartitions).persist(StorageLevel.MEMORY_AND_DISK)
    val feepoint_result=Multi_feepoint(spark,sql_Rdd,calPartitions)
    //结果数据计算
    val loc_trajectory1: DataFrame =feepoint_result.map(
      obj=>{
        val ret = obj.getString( "ret")
        val index=obj.getString("index")
        val ret_json= JSON.parseObject(ret)
        //获取状态值
        var status=""
        try{
          status = ret_json.getString("status")
        }catch {
          case e:Exception =>
            logger.error("轨迹缺失")
        }

        val needArr = new ArrayBuffer[String]()
        val start_tmp= """{"tracks":[""".stripMargin
        val accuracy_tmp= """{"accuracy":""".stripMargin
        val azimuth_tmp= ""","azimuth":""".stripMargin
        val speed_tmp= ""","speed":""".stripMargin
        val time_tmp= ""","time":""".stripMargin
        val x_tmp= ""","x":""".stripMargin
        val y_tmp= ""","y":""".stripMargin
        val yend_tmp= """}""".stripMargin
        val end_tmp= """]}""".stripMargin

        val error_type=status
        var halfway_integrate_rate=""
        try {
          if (status == "0" || status == 0) {
            val track = ret_json.getJSONObject("result").getJSONObject("data").getJSONArray("track")
            halfway_integrate_rate = ret_json.getJSONObject("result").getJSONObject("data").getJSONObject("rate").getString("offTime")
            val s = track.size()
            for (i <- 0 until s) {
              val track_i = track.getJSONObject(i)
              val accuracy = track_i.getString("ac")
              val azimuth = track_i.getString("be")
              val speed = track_i.getString("sp")
              val time = track_i.getString("tm")
              val x = track_i.getString("zx")
              val y = track_i.getString("zy")
              val result = accuracy_tmp.concat(accuracy).concat(azimuth_tmp).concat(azimuth).concat(speed_tmp).concat(speed)
                .concat(time_tmp).concat(time).concat(x_tmp).concat(x).concat(y_tmp).concat(y).concat(yend_tmp)
              needArr.append(result)
            }
          }
        }
        catch {
          case e=>logger.error("计算错误："+e.getMessage)
        }

        val coords=start_tmp.concat(needArr.mkString(",")).concat(end_tmp)
        (index,coords,error_type,halfway_integrate_rate)
      }
    ).toDF("index","coords","error_type","halfway_integrate_rate")

//    //行车轨迹
//    val loc_trajectory=spark.sql(
//      s"""
//         |select un as vehicle,ac as accuracy,be as azimuth,sp as speed,tm as time,zx as x,zy as y,tm
//         |from dm_gis.esg_gis_loc_trajectory
//         |where inc_day='$dayvar'
//         |""".stripMargin)
//
//    logger.error("loc_trajectory数据量为："+loc_trajectory.count())
//
//    val loc_trajectory1=record_data0.select("index","vehicle","actual_depart_tm","actual_arrive_tm").join(loc_trajectory,Seq("vehicle"),"left")
//      .withColumn("trace_tm",when($"tm".isNull || trim($"tm")==="","").otherwise(tranTimeToStrings_udf($"tm")))
//      .filter($"trace_tm">=$"actual_depart_tm" && $"trace_tm"<=$"actual_arrive_tm")
//      .withColumn("dis_rank", row_number().over(Window.partitionBy("index")
//        .orderBy(asc("tm"))))
//      .withColumn("dis_rank2",concat(lit("index"),lpad($"dis_rank",12,"0")))
//      .withColumn("accuracy_tmp",concat_ws(":",lit("\"accuracy\""),$"accuracy"))
//      .withColumn("azimuth_tmp",concat_ws(":",lit("\"azimuth\""),$"azimuth"))
//      .withColumn("speed_tmp",concat_ws(":",lit("\"speed\""),$"speed"))
//      .withColumn("time_tmp",concat_ws(":",lit("\"time\""),$"tm"))
//      .withColumn("x_tmp",concat_ws(":",lit("\"x\""),$"x"))
//      .withColumn("y_tmp",concat_ws(":",lit("\"y\""),$"y"))
//      .withColumn("tmp",concat_ws(",",$"accuracy_tmp",$"azimuth_tmp",$"speed_tmp",$"time_tmp",$"x_tmp",$"y_tmp"))
//      .withColumn("tmp2",concat(lit("{"),$"tmp",lit("}")))
//      .withColumn("tmp3",concat($"dis_rank2",lit("__"),$"tmp2"))
//      .groupBy("index")
//      .agg(concat_ws(",",sort_array(collect_list($"tmp3"))) as "tmp4"
//      )
//      .withColumn("tmp5",concat(lit("{\"tracks\":["),$"tmp4",lit("]}")))
//      .drop("tmp4")
//      .select(col("*"), expr("regexp_replace(tmp5, 'index([0-9]{12})__', '')").as("coords")
//      )
//      .select("index","coords")

//    //获取recall表,计算errortype
//    val recall_data1=spark.sql(
//      s"""
//         |select task_id,error_type
//         |from dm_gis.eta_std_line_recall
//         |where inc_day>='$dayvar30' and inc_day<='$dayvar'
//         |""".stripMargin)
//      .withColumn("error_type_flag",when($"error_type"==="0",2).otherwise(1))
//      .withColumn("rank",row_number().over(Window.partitionBy("task_id").orderBy(asc("error_type_flag"))))
//      .filter($"rank"==="1")
//      .drop("error_type_flag","rank")
//
//    //获取recall表,halfway就取值最小的 这个是轨迹完整率
//    val recall_data2=spark.sql(
//      s"""
//         |select task_id,halfway_integrate_rate
//         |from dm_gis.eta_std_line_recall
//         |where inc_day>='$dayvar30' and inc_day<='$dayvar'
//         |""".stripMargin)
//      .withColumn("rank",row_number().over(Window.partitionBy("task_id").orderBy(asc("halfway_integrate_rate"))))
//      .filter($"rank"==="1")
//      .drop("rank")

  //结果汇总
    val res_data=record_data0.join(loc_trajectory1,Seq("index"),"left")
//      .join(recall_data1,Seq("task_id"),"left")
//      .join(recall_data2,Seq("task_id"),"left")
      .withColumn("inc_day",lit(dayvar))
      .withColumn("discout_amount",round($"discout_amount"/100.00,2))
      .withColumn("real_amount",round($"real_amount"/100.00,2))
      .withColumn("index",row_number().over(Window.partitionBy("inc_day").orderBy(asc("actual_depart_tm"))))
      .withColumn("coords",when($"coords".isNull || trim($"coords")==="" || trim($"coords")==="{\"tracks\":[]}","").otherwise($"coords"))

    //存入dm表
    val tb_cols = spark.sql("""select * from dm_gis.dm_roadbridgefee_integration_wb_dtl limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, res_data.select(tb_cols:_*).coalesce(5), Seq("inc_day"), "dm_gis.dm_roadbridgefee_integration_wb_dtl")
    logger.error("执行完成")
    spark.close()
  }

  //定义获取url数据
  def feepoint_url(ak:String,obj:JSONObject): JSONObject = {
    //使用新接口
    val url="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrate"
    try {
      val un=obj.getString("vehicle")
      val begindatetime=obj.getString("actual_depart_tm").replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")
      val enddatetime=obj.getString("actual_arrive_tm").replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")

      val parm_str=s"""{
                      |"type": "400",
                      |"un": "$un",
                      |"unType": "0",
                      |"rectify": "false",
                      |"ak": "2646d2d5ef004bd0856743e381e5a37c",
                      |"beginDateTime": $begindatetime,
                      |"endDateTime": $enddatetime,
                      |"offTime":"120",
                      |"hasRate": "true"
                      |}
                      |""".stripMargin

      //val retStr: String = UrlUtil.sendPost(url,parm_str,20)
      val retStr: String = Utils.sendPost(url,parm_str,20)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
      logger.error("返回正确数据，车牌号："+un)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("ret",tmp)
        obj.put("errmsg",e.getMessage)
        val un=obj.getString("un")
        logger.error("返回错误数据，车牌号："+un)
        logger.error("错误信息："+e.getMessage)
    }
    obj
  }

  //调取接口并发请求
  def Multi_feepoint(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrate"
    val httpAk="2646d2d5ef004bd0856743e381e5a37c"
    val dataCnt=DataRdd.count()
    //val dataCnt=32000
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "780697", "路桥费信息整合-外部车辆",
      "外部车收费账单为月度，其对应的任务和轨迹量大，下载到线下处理周期长，线上处理加快迭代周期。",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, feepoint_url, 4, "2646d2d5ef004bd0856743e381e5a37c", 2500)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    logger.error("服务调用完成：" + httpInvokeId )
    returnAtRDD
  }

  //往前推n天
  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

  //时间戳转化：输入秒
  def tranTimeToStrings(tm:String) :String={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val tm1=tm.concat("000")
    val tim = fm.format(new Date(tm1.toLong))
    tim
  }

  val tranTimeToStrings_udf=udf(tranTimeToStrings _)

}
