package com.sf.gis.scala.pns.app.valueLine

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.Functions.getDist
import com.sf.gis.scala.base.util.{JSONUtil, UDAFGetMode}
import com.sf.gis.scala.pns.app.valueLine.PreceptObj.{LineConfPassTrack2, MloadTrack, VlResultNew}
import com.sf.gis.scala.pns.utils.Functions.{stdCoordsToPoints, timeToCustomTime}
import com.sf.gis.scala.pns.utils.SparkUtils.{row2Json, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * GIS-RSS-PNS：【价值线路】筛选工艺流程线上化需求
 * 需求方：张翠霞（01369612）
 * @author 徐游飞（01417347） 更新 周勇（01390943）
 * 备注：此代码为第一版处理逻辑，v1.1版本开始已将新旧逻辑拆分成两个任务
 */
object StandardLineNewPrecept {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  val GETLINE_URL: String = "http://gis-int.int.sfdc.com.cn:1080/etaStdLine/operate/getLine"
  val GETLINE_AK: String = "5e86b3e45f664ecea1d59e6c591aa006"

  //  val QM_URL: String = "http://gis-int.int.sfdc.com.cn:1080/rp/qm_point/sf"
  //  val QM_AK: String = "d6a1f9b11d2441fc8fc1ffb5eb3e61d6"
  val QM_URL: String = "http://rp-c-gd.int.sfcloud.local:1090/qm_point?"
  val QM_AK: String = ""

  val UPDATE_URL: String = "http://gis-int.int.sfdc.com.cn:1080/etaStdLine/operate/updateLineFiled"  // 生产环境url ak:5e86b3e45f664ecea1d59e6c591aa006
  val UPDATE_AK: String = "5e86b3e45f664ecea1d59e6c591aa006"

  val QM_POINT_URL: String = "http://gis-int.int.sfdc.com.cn:1080/rp/qm_point/sf"
  val QM_POINT_AK: String = "259860fe89f948a49c9d784e4567aa38"

  val parallelism = 20
  val akMinuLimit = 1000

  /**
   *  3.获取整合车参信息（表1）
   * @param spark
   * @param dayBefore1
   * @return
   */
  def getVmsVehicle(spark: SparkSession, dayBefore1: String) = {
    val querySql =
      s"""
         |select
         |  vehicle_code as vehicle_serial,
         |  round(outer_height / 1000, 2) as height,
         |  round(outer_length / 1000, 2) as length,
         |  round(outer_width / 1000, 2) as width,
         |  round((max_load + net_weight) / 1000, 2) as weight,
         |  round(max_load / 1000, 2) as mload,
         |  axes as axle_number,
         |  emissionrulecode as emitStand,
         |  fuel_type as energy,
         |  plate_color as plateColor,
         |  '' as passport,
         |  '' as car_type,
         |  0 as type
         |from
         |  ods_vms.tm_vms_vehicle
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println("获取整合车参信息（表1）sql语句：")
    println(querySql)
    var vmsVehicleDF = spark.sql(querySql)

    // 获取建制表数据
    val vehicle11: DataFrame = spark.read
      .format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("/user/01417347/upload/data/vehicle11_建制表.csv")

    import spark.implicits._
    vmsVehicleDF = vehicle11
      .withColumn("type", lit(1))
      .union(vmsVehicleDF)
      .withColumn("rn", row_number().over(Window.partitionBy("vehicle_serial").orderBy(desc("type"))))
      .filter('rn === 1)
      .drop("rn","type")

    vmsVehicleDF
  }

  /**
   * 4.1.1获取任务数据（任务监控表）（表2）
   * @param spark
   * @param dayBefore1
   * @param dayBefore31
   * @return
   */
  def getLineRecallNew(spark: SparkSession, dayBefore1: String, dayBefore31: String) = {
    val querySql =
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  start_type,
         |  end_type,
         |  line_code,
         |  concat_ws('_', line_code, start_dept, end_dept, vehicle_type) as linevehicle,
         |  (
         |    case
         |      when actual_capacity_load < 1.5 then 0.84
         |      when actual_capacity_load >= 1.5
         |      and actual_capacity_load < 3 then 0.84
         |      when actual_capacity_load >= 3
         |      and actual_capacity_load < 5 then 0.88
         |      when actual_capacity_load >= 5
         |      and actual_capacity_load < 7 then 1.07
         |      when actual_capacity_load >= 7
         |      and actual_capacity_load < 14 then 1.36
         |      when actual_capacity_load >= 14
         |      and actual_capacity_load < 20 then 1.51
         |      when actual_capacity_load >= 20
         |      and actual_capacity_load < 30 then 1.88
         |      when actual_capacity_load >= 30 then 1.99
         |    end
         |  ) as unitprice,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  plf_flag,
         |  vehicle_type,
         |  log_dist,
         |  duration,
         |  time,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge,
         |  error_type,
         |  pns_dist,
         |  pns_time,
         |  src,
         |  line_distance_std,
         |  line_time_std,
         |  sim1,
         |  sim5,
         |  conduct_type,
         |  is_run_ontime_std,
         |  is_run_ontime,
         |  tl_time,
         |  halfway_integrate_rate,
         |  biz_type,
         |  require_category,
         |  std_toll_charge,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  std_id,
         |  task_inc_day,
         |  accrual_dist,
         |  accrual_dist_type,
         |  stop_over_zone_code
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day >= '$dayBefore31' and inc_day < '$dayBefore1'
         |  and is_stop = 1
         |  and carrier_type = 0
         |""".stripMargin

    println("获取任务数据（任务监控表）（表2）sql语句：")
    println(querySql)
    var lineRecallDF = spark.sql(querySql)

    import spark.implicits._
    lineRecallDF = lineRecallDF
      .withColumn("rn", row_number().over(Window.partitionBy("task_subid").orderBy(desc("task_inc_day"))))
      .filter('rn === 1)
      .drop("rn")

    lineRecallDF
  }

  /**
   * 4.1.2获取行车日志数据（行车日志表）(表3)
   * @param spark
   * @param month
   * @param monthBefore1
   * @return
   */
  def getDrivingLog(spark: SparkSession, month: String, monthBefore1: String) = {
    val querySql =
      s"""
         |select
         |  task_id,
         |  driving_log_item_id,
         |  created_tm,
         |  road_fee,
         |  miles
         |from
         |  ods_vms.tt_vms_driving_log_item
         |where
         |  inc_month >= '$monthBefore1'
         |  and inc_month <= '$month'
         |  and task_id <> ''
         |  and task_id is not null
         |  and length(task_id) < 15
         |""".stripMargin

    println("获取行车日志数据（行车日志表）(表3)的sql语句：")
    println(querySql)
    var drivingLogDF = spark.sql(querySql)

    import spark.implicits._
    drivingLogDF = drivingLogDF
      .withColumn("rn", row_number().over(Window.partitionBy("driving_log_item_id").orderBy(desc("created_tm"))))
      .filter('rn === 1)
      .groupBy("task_id")
      .agg(
        sum("road_fee") as "road_fee",
        sum("miles") as "miles"
      )

    drivingLogDF
  }

  /**
   * 解析标准线路查询接口返回值
   * @param ret
   * @return
   */
  def parseStandardLineQueryData(ret: JSONObject): String = {

    val list_str = new StringBuilder
    var status = ""
    var cnt = ""
    var stdId = ""
    var isEcon = ""
    var trackStartX = ""
    var trackStartY = ""
    var trackEndX = ""
    var trackEndY = ""
    var updateTime = ""
    var vehicle = ""
    var jyTrack2 = ""

    if (ret != null ) {
      //获取接口返回状态
      status = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(status)) {
        logger.error("获取接口数据失败: " + ret.getJSONObject("result").getString("msg"))
        list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2")

        return list_str.toString()
      } else {
        var list = new JSONArray()
        try {
          list = ret.getJSONObject("result").getJSONArray("list")
          cnt = ret.getJSONObject("result").getString("cnt")
        } catch {
          case _ =>
        }
        if(list.isEmpty){
          list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2")
        }else{
          for(i <- 0 until  list.size()){
            stdId = list.getJSONObject(i).getString("stdId")
            isEcon = list.getJSONObject(i).getString("isEcon")
            trackStartX = list.getJSONObject(i).getString("trackStartX")
            trackStartY = list.getJSONObject(i).getString("trackStartY")
            trackEndX = list.getJSONObject(i).getString("trackEndX")
            trackEndY = list.getJSONObject(i).getString("trackEndY")
            updateTime = list.getJSONObject(i).getString("updateTime")
            vehicle = list.getJSONObject(i).getString("vehicle")
            jyTrack2 = list.getJSONObject(i).getString("jyTrack2")

            if(i.equals(list.size())){
              list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2")
            }else{
              list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2@@")
            }
          }
        }
        return list_str.toString()
      }
    }
    list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2")
    list_str.toString()
  }

  /**
   * 调用标准线路查询接口获取 check_flag 字段
   * @param ak
   * @param obj
   * @return
   */
  def runStandardLineQueryInteface(ak:String, obj: JSONObject): JSONObject = {

    val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
    val src_deptcode = JSONUtil.getJsonVal(obj, "src_deptcode", "")
    val dest_deptcode = JSONUtil.getJsonVal(obj, "dest_deptcode", "")
    val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("optUserId", "01369612")
    param.put("ak", ak)
    param.put("lineCode", line_code)
    param.put("srcDeptcode", src_deptcode)
    param.put("destDeptcode", dest_deptcode)
    param.put("containDeleted","False")
    param.put("vehicle",vehicle_type)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(GETLINE_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析接口返回值
    val httpData =  parseStandardLineQueryData(retJSONObject)
    obj.put("httpData",httpData)
    obj
  }

  /**
   * 解析 qm_point接口返回值
   * @param ret
   * @return
   */
  def parseQMPointHttpData(ret: JSONObject): (String, String, String, String) = {
    if (ret != null ) {
      //获取接口返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null, null)
      } else {

        //依次遍历paths、steps、links、rtic_event数组，取出 title 字段拼接
        val content_arr = new ArrayBuffer[String]()
        val title_arr = new ArrayBuffer[String]()
        try{
          val paths_arr = ret.getJSONObject("route").getJSONArray("paths")
          for(i <- 0 until paths_arr.size){
            val steps_arr = paths_arr.getJSONObject(i).getJSONArray("steps")

            for(j <- 0 until steps_arr.size){
              val links_arr = steps_arr.getJSONObject(j).getJSONArray("links")

              for(k <- 0 until links_arr.size){
                val event_arr = links_arr.getJSONObject(k).getJSONArray("rtic_event")

                for(n <- 0 until event_arr.size){
                  val title = event_arr.getJSONObject(n).getString("title")
                  val content = event_arr.getJSONObject(n).getString("content")
                  title_arr.append(title)
                  content_arr.append(content)
                }
              }
            }
          }
        }catch {
          case e: Exception => logger.error(e)
        }
        val title = title_arr.mkString(",")
        val content = content_arr.mkString(",")

        return (codeStatue, "成功", title, content)
      }
    }
    ("22", "请求失败,接口返回值为空", null, null)
  }

  /**
   * 调 qm_point接口
   * @param ak
   * @param obj
   * @return
   */
  def runQMPointInteface(ak:String, obj: JSONObject): JSONObject = {
    val check_vehicle = JSONUtil.getJsonVal(obj, "check_vehicle", "")
    val check_jyTrack2 = JSONUtil.getJsonVal(obj, "check_jyTrack2", "")
    val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")
    //将数据转换成接口需要的样式
    val date = timeToCustomTime(inc_day, "yyyyMMdd", "yyyyMMddHHmmss")

    //初始化top3接口请求参数1
    val param = new JSONObject()
    param.put("ak", ak)
    param.put("opt", "sf4")
    param.put("strategy", "4")
    param.put("vehicle", check_vehicle)
    param.put("plandate", date)
    param.put("points", check_jyTrack2)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_POINT_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, String, String) = parseQMPointHttpData(retJSONObject)
    obj.put("title",httpData._3)
    obj.put("content",httpData._4)
    //测试字段
    obj.put("param",param.toJSONString)
    obj.put("code_statue",httpData._1)
    obj.put("code_statue2",httpData._2)
    obj
  }

  /**
   * 调接口更新校验数据
   * @param spark
   * @param df_all
   * @param table_name
   * @param dayBefore1
   * @return
   */
  def updateTheVerificationData(spark: SparkSession, df_all: DataFrame, table_name: String, dayBefore1: String) = {

    import spark.implicits._
    df_all.createOrReplaceTempView(table_name)
    var df_allRDD: RDD[JSONObject] = SparkUtils.getRowToJson(spark, s"select linevehicle,std_id,line_code,src_deptcode,dest_deptcode,vehicle_type,x1,y1,x2,y2 from $table_name where choose_flag = 1")

    val invokeCnt_1 = df_allRDD.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "658134", "筛选工艺流程线上化需求_旧方案部分", "获取标准线路", GETLINE_URL, GETLINE_AK, invokeCnt_1, parallelism)
    df_allRDD = SparkNet.runInterfaceWithAkLimit(spark, df_allRDD, runStandardLineQueryInteface, parallelism, GETLINE_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)

    val df_allDF = df_allRDD.repartition(100).map(obj => {
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val src_deptcode = JSONUtil.getJsonVal(obj, "src_deptcode", "")
      val dest_deptcode = JSONUtil.getJsonVal(obj, "dest_deptcode", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val x1 = JSONUtil.getJsonVal(obj, "x1", "")
      val y1 = JSONUtil.getJsonVal(obj, "y1", "")
      val x2 = JSONUtil.getJsonVal(obj, "x2", "")
      val y2 = JSONUtil.getJsonVal(obj, "y2", "")
      val httpData = JSONUtil.getJsonVal(obj, "httpData", "")
      val httpData_arr = httpData.split("@@")

      VlResultNew(linevehicle,line_code,src_deptcode,dest_deptcode,vehicle_type,std_id,x1,y1,x2,y2,httpData_arr)
    }).toDF()

    //(修改20231207) 3
//    val tmp00_cols = spark.sql("select * from dm_gis.check_flag_xyf_tmp00 limit 0").schema.map(_.name).map(col)
//    writeToHive(spark,df_allDF.withColumn("inc_day",lit(dayBefore1)).select(tmp00_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.check_flag_xyf_tmp00")

    // 数据集df1
    val df1 = df_allDF
      .withColumn("httpData", explode('httpData_arr))
      .withColumn("check_status", split('httpData, "##")(0))
      .withColumn("check_cnt", split('httpData, "##")(1))
      .withColumn("check_stdid", split('httpData, "##")(2))
      .withColumn("check_econ", split('httpData, "##")(3))
      .withColumn("check_trackStartX", split('httpData, "##")(4))
      .withColumn("check_trackStartY", split('httpData, "##")(5))
      .withColumn("check_trackEndX", split('httpData, "##")(6))
      .withColumn("check_trackEndY", split('httpData, "##")(7))
      .withColumn("check_updatetime", split('httpData, "##")(8))
      .withColumn("check_vehicle", split('httpData, "##")(9))
      .withColumn("check_jyTrack2", split('httpData, "##")(10))
      .withColumn("start_dist", getDist('x1, 'y1, 'check_trackStartX, 'check_trackStartY))
      .withColumn("end_dist", getDist('x2, 'y2, 'check_trackEndX, 'check_trackEndY))
      .withColumn("df1_flag", when('start_dist <= 500 and 'end_dist <= 500, 0).otherwise(1))

    // 新建数据集df2 (用于获取已推的价值线路)
    val df2 = df1
      .filter('check_econ === 0)
      .withColumn("tag", lit("done"))
      .withColumn("rn",row_number().over(Window.partitionBy("linevehicle").orderBy(desc("check_updateTime"))))
      .filter('rn === 1)
      .select("linevehicle","tag")

    // 新建数据集df3 (用于获取班次车型最新更新时间)
    val df3 = df1
      .withColumn("rn",row_number().over(Window.partitionBy("linevehicle").orderBy(desc("check_updateTime"))))
      .filter('rn === 1)
      .withColumn("update_day", regexp_replace(substring('check_updateTime,0,10),"-",""))
      .withColumn("stdid_new", 'check_stdid)
      .select("linevehicle","update_day","stdid_new")

    // 通过【linevehicle】将df2、df3关联到df1
    val df1_res1 = df1
      .join(df2,Seq("linevehicle"),"left")
      .join(df3,Seq("linevehicle"),"left")
      .withColumn("check_flag1",when('df1_flag === 1,0)
        .when('tag === "done",2)
        .when('std_id =!= 'check_stdid,4)
        .when('std_id === 'stdid_new,1)
        .when('update_day + 6 <= dayBefore1,1)
        .when('update_day + 6 > dayBefore1,3))
      .filter('std_id === 'check_stdid)
      .withColumn("rn",row_number().over(Window.partitionBy("std_id").orderBy(desc("check_updateTime"))))
      .filter('rn === 1)
      .withColumn("inc_day",lit(dayBefore1))

    // 调取路况接口，判断std_id是否封路
    var rdd_fengKong: RDD[JSONObject] = SparkUtils.getDfToJson(spark,df1_res1.filter('check_flag1 === 1))

    val invokeCnt_2 = rdd_fengKong.count()
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "658134", "筛选工艺流程线上化需求_旧方案部分", "获取封控信息", QM_POINT_URL, QM_POINT_AK, invokeCnt_2, parallelism)
    rdd_fengKong = SparkNet.runInterfaceWithAkLimit(spark, rdd_fengKong, runQMPointInteface, parallelism, QM_POINT_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    val df1_fengkong = rdd_fengKong.repartition(100).map(obj => {
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
      val title = JSONUtil.getJsonVal(obj, "title", "")
      val content = JSONUtil.getJsonVal(obj, "content", "")
      val param = JSONUtil.getJsonVal(obj, "param", "")
      val code_statue = JSONUtil.getJsonVal(obj, "code_statue", "")
      val code_statue2 = JSONUtil.getJsonVal(obj, "code_statue2", "")

      var if_fk = 0
      if(content.contains("封闭") || content.contains("封路")) if_fk = 1
      (linevehicle,if_fk,title,content,param,code_statue,code_statue2)
    }).toDF("linevehicle","if_fk","title","content","param","code_statue","code_statue2")

    // 通过recall表获取近一个月的数据判断std_id执行率
    val mouthBefore1 = DateUtil.getMouthBefore(dayBefore1, 1)
    val querySql =
      s"""
         |select
         |  std_id,
         |  conduct_type
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day > '$mouthBefore1'
         |  and inc_day <= '$dayBefore1'
         |  and carrier_type = '0'
         |  and conduct_type = 1
         |group by
         |  std_id,
         |  conduct_type
         |""".stripMargin

    println(querySql)
    val df_recall = spark.sql(querySql).dropDuplicates("std_id","conduct_type")

    val df1_res = df1_res1
      .join(df1_fengkong,Seq("linevehicle"),"left")
      .join(df_recall,Seq("std_id"),"left")
      .withColumn("check_flag",when('df1_flag === 1,0)
        .when('tag === "done",2)
        .when('std_id =!= 'check_stdid,4)
        .when('std_id =!= 'stdid_new and 'update_day + 6 > dayBefore1,3)
        .when('std_id =!= 'stdid_new and 'update_day + 6 <= dayBefore1 and 'if_fk === 0 and 'conduct_type === 1,1)
        .when('std_id === 'stdid_new and 'if_fk === 0 and 'conduct_type === 1,1)
        .when('conduct_type =!= 1,5))
      .filter('std_id === 'check_stdid)
      .withColumn("rn",row_number().over(Window.partitionBy("std_id").orderBy(desc("check_updateTime"))))
      .filter('rn === 1)

    //(修改20231207) 4 5
    // 临时中间表，方便异常数据定位
    val tmp_cols = spark.sql(s"""select * from dm_gis.${table_name}_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df1_res.select(tmp_cols: _*).coalesce(50),Seq("inc_day"),s"""dm_gis.${table_name}_detail""")

    df1_res.select("std_id","check_flag")
  }

  /**
   * 解析推数接口返回值
   * @param ret
   * @return
   */
  def parseStandardLineUpdateData(ret: JSONObject):String = {

    val update_res = new JSONObject()
    val result = new JSONObject()
    var status = ""
    var code = ""
    var info = ""

    if (ret != null) {
      //获取接口返回状态
      status = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(status)) {
        logger.error("获取接口数据失败: " + ret.getJSONObject("result").getString("msg"))
        result.put("code",code)
        result.put("info",info)
        update_res.put("result",result)
        update_res.put("status",status)
        return update_res.toString
      } else {
        try {
          code = ret.getJSONObject("result").getString("code")
          info = ret.getJSONObject("result").getString("info")
          result.put("code",code)
          result.put("info",info)
          update_res.put("result",result)
          update_res.put("status",status)
        } catch {
          case _ =>
        }
        return update_res.toString
      }
    }
    update_res.toString
  }

  /**
   * 6.向接口推送数据更新入库
   * @param ak
   * @param obj
   * @return
   */
  def runStandardLineUpdateInteface(ak:String, obj: JSONObject): JSONObject = {

    val stdId = JSONUtil.getJsonVal(obj, "std_id", "")
    val updateReason = JSONUtil.getJsonVal(obj, "choose_source", "")
    val oilConsumption = JSONUtil.getJsonVal(obj, "oilConsumption", "")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("optUserId", "01369612")
    param.put("stdId", stdId)
    param.put("ak", ak)
    param.put("updateReason", updateReason)
    param.put("oilConsumption", oilConsumption)
    param.put("isEcon",0)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(UPDATE_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析接口返回值
    val update_res =  parseStandardLineUpdateData(retJSONObject)
    obj.put("update_res",update_res)
    obj
  }

  /**
   * 6.向接口推送数据更新入库
   * @param spark
   * @param resultNewDF 经过更新检验的筛选结果数据DataFrame
   */
  def pushDataToInterfaceNew(spark: SparkSession, resultDF: DataFrame) = {

    import spark.implicits._
    resultDF.createOrReplaceTempView("result_table")
    var resultRDD: RDD[JSONObject] = SparkUtils.getRowToJson(spark,"select std_id,choose_source,oilConsumption from result_table where check_flag = '1'")

    val invokeCnt_3 = resultRDD.count()
    val httpInvokeId_3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "658134", "筛选工艺流程线上化需求_旧方案部分", "数据更新入库", UPDATE_URL, UPDATE_AK, invokeCnt_3, parallelism)
    resultRDD = SparkNet.runInterfaceWithAkLimit(spark, resultRDD, runStandardLineUpdateInteface, parallelism, UPDATE_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_3)

    val gisEtaVlResultDF = resultRDD.repartition(100).map(obj => {
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val choose_source = JSONUtil.getJsonVal(obj, "choose_source", "")
      val oilConsumption = JSONUtil.getJsonVal(obj, "oilConsumption", "")
      val update_res = JSONUtil.getJsonVal(obj, "update_res", "")

      (std_id,oilConsumption,choose_source,update_res)
    }).toDF("std_id","oilConsumption","choose_source","update_res")
      .withColumn("rn",row_number().over(Window.partitionBy("std_id","oilConsumption","choose_source").orderBy("std_id")))
      .filter('rn === 1)
      .drop("rn")

    gisEtaVlResultDF
  }

  /**
   * 4.4统计成本相关项
   * @param spark
   * @param itemNewDF 筛选任务明细表DataFrame
   * @param dayBefore1
   * @return
   */
  def gisEtaVlResultNew(spark: SparkSession, itemNewDF: DataFrame, dayBefore1: String) = {

    import spark.implicits._
    // 4.4统计成本相关项
    // 4.4.2班次车型维度,数据集命名为：df_lv
    val df_lv = itemNewDF
      .groupBy("area_linevehicle")
      .agg(
        avg("miles") as "linevehicle_miles",
        avg("road_fee") as "linevehicle_road_fee",
        avg("fuel_cost") as "linevehicle_fuel_cost",
        avg("cost") as "linevehicle_cost",
        avg("actual_run_time") as "linevehicle_time",
        count("task_id") as "linevehicle_num",
        count(when('is_run_ontime === 1, 'task_id).otherwise(null)) as "linevehicle_ontime_num"
      )
      .withColumn("linevehicle_ontime_rate", 'linevehicle_ontime_num / 'linevehicle_num)

    // 4.2.3班次载重维度,数据集命名为：df_lm
    val df_lm = itemNewDF
      .groupBy("area_linemload")
      .agg(
        avg("miles") as "linemload_miles",
        avg("road_fee") as "linemload_road_fee",
        avg("fuel_cost") as "linemload_fuel_cost",
        avg("cost") as "linemload_cost",
        avg("actual_run_time") as "linemload_time",
        count("task_id") as "linemload_num",
        count(when('is_run_ontime === 1, 'task_id).otherwise(null)) as "linemload_ontime_num"
      )
      .withColumn("linemload_ontime_rate", 'linemload_ontime_num / 'linemload_num)

    // 4.2.4.1班次线路维度,All场景,数据集命名为：df_all
    // 注册UDAF
    val getMode = spark.udf.register("getMode", UDAFGetMode)
    val df_all = itemNewDF
      .groupBy("area_linemload_std")
      .agg(
        max("task_area_code") as "task_area_code",
        max("line_code") as "line_code",
        max("start_dept") as "src_deptcode",
        max("end_dept") as "dest_deptcode",
        max("vehicle_type") as "vehicle_type",
        max("linevehicle") as "linevehicle",
        max("mload") as "mload",
        max("stop_over_zone_code") as "stop_over_zone_code",
        max("std_id") as "std_id",
        max("task_inc_day") as "task_inc_day",
        max("unitprice") as "unitprice",
        max("area_linevehicle") as "area_linevehicle",
        max("area_linemload") as "area_linemload",
        avg("miles") as "linemload_std_miles",
        avg("road_fee") as "linemload_std_road_fee",
        avg("fuel_cost") as "linemload_std_fuel_cost",
        avg("cost") as "linemload_std_cost",
        avg("actual_run_time") as "linemload_std_time",
        count("task_id") as "linemload_std_num",
        count(when('is_run_ontime === 1, 'task_id).otherwise(null)) as "linemload_std_ontime_num",
        getMode(concat_ws("_",'start_longitude,'start_latitude,'end_longitude,'end_latitude)) as "xy"
      )
      .withColumn("linemload_std_ontime_rate",'linemload_std_ontime_num / 'linemload_std_num)
      .withColumn("oilConsumption", 'unitprice / 7 * 100 )
      .withColumn("x1",split('xy,"_")(0))
      .withColumn("y1",split('xy,"_")(1))
      .withColumn("x2",split('xy,"_")(2))
      .withColumn("y2",split('xy,"_")(3))
      .withColumn("choose_source",lit("更新价值线路标识-标准新方案"))
      .drop("unitprice","xy")

    // 4.2.4.2班次线路维度,线路执行场景,数据集命名为：df_1
    val df_1 = itemNewDF
      .filter('conduct_type === 1)
      .groupBy("area_linemload_std")
      .agg(
        avg("miles") as "linemload_std_miles1",
        avg("road_fee") as "linemload_std_road_fee1",
        avg("fuel_cost") as "linemload_std_fuel_cost1",
        avg("cost") as "linemload_std_cost1",
        avg("actual_run_time") as "linemload_std_time1",
        count("task_id") as "linemload_std_num1",
        count(when('is_run_ontime === 1, 'task_id).otherwise(null)) as "linemload_std_ontime_num1"
      )
      .withColumn("linemload_std_ontime_rate1", 'linemload_std_ontime_num1 / 'linemload_std_num1)
      .withColumn("area_linemload_std_1",'area_linemload_std)
      .drop("area_linemload_std")

    // 4.2.4.3班次线路维度,线路未执行场景,数据集命名为：df_3
    val df_3 = itemNewDF
      .filter('conduct_type === 3)
      .groupBy("area_linemload_std")
      .agg(
        avg("miles") as "linemload_std_miles3",
        avg("road_fee") as "linemload_std_road_fee3",
        avg("fuel_cost") as "linemload_std_fuel_cost3",
        avg("cost") as "linemload_std_cost3",
        avg("actual_run_time") as "linemload_std_time3",
        count("task_id") as "linemload_std_num3",
        count(when('is_run_ontime === 1, 'task_id).otherwise(null)) as "linemload_std_ontime_num3"
      )
      .withColumn("linemload_std_ontime_rate3", 'linemload_std_ontime_num3 / 'linemload_std_num3)
      .withColumn("area_linemload_std_3",'area_linemload_std)
      .drop("area_linemload_std")

    // 4.5对比成本相关项
    // 数据关联,以[area_linemload_std]的统计结果为基准，将[area_linevehicle]、[area_linemload]统计结果关联过来，关联后的数据集为df_all,并新增相应字段
    val df_all_res = df_all.alias("df_all")
      .join(df_1.alias("df_1"), expr("df_all.area_linemload_std = df_1.area_linemload_std_1"), "left")
      .join(df_3.alias("df_3"), expr("df_all.area_linemload_std = df_3.area_linemload_std_3"), "left")
      .join(df_lm, Seq("area_linemload"), "left")
      .join(df_lv, Seq("area_linevehicle"), "left")
      .drop("area_linemload_std_1","area_linemload_std_3")
      .withColumn("diff_cost", 'linemload_std_cost1 - 'linemload_std_cost3)
      .withColumn("diff_cost_rate", 'diff_cost / 'linemload_std_cost3)
      .withColumn("diff_road_fee", 'linemload_std_road_fee1 - 'linemload_std_road_fee3)
      .withColumn("diff_fuel_cost", 'linemload_std_fuel_cost1 - 'linemload_std_fuel_cost3)
      .withColumn("diff_miles", 'linemload_std_miles1 - 'linemload_std_miles3)
      .withColumn("diff_time", 'linemload_std_time1 - 'linemload_std_time3)
      .withColumn("diff_cost1", 'linemload_std_cost1 - 'linemload_cost)
      .withColumn("diff_cost_rate1", 'diff_cost / 'linemload_cost)
      .withColumn("diff_road_fee1", 'linemload_std_road_fee1 - 'linemload_road_fee)
      .withColumn("diff_fuel_cost1", 'linemload_std_fuel_cost1 - 'linemload_fuel_cost)
      .withColumn("diff_miles1", 'linemload_std_miles1 - 'linemload_miles)
      .withColumn("diff_time1", 'linemload_std_time1 - 'linemload_time)
      .withColumn("diff_time2", 'linemload_std_time1 - 'linevehicle_time)
      .withColumn("mload_rate", 'linemload_num / 'linevehicle_num)
      .withColumn("linemload_std_exe_rate", 'linemload_std_num1 / 'linemload_std_num)
      .withColumn("cost_flag", when('linemload_std_exe_rate === 1, 1)
        .when('linemload_std_exe_rate === 0, 2)
        .when('diff_cost > 0 or 'diff_cost1 > 0, 3)
        .when('diff_cost === 0 or 'diff_cost1 === 0, 4)
        .when('diff_cost >= -5 and 'diff_cost < 0 and 'diff_cost1 >= -5 and 'diff_cost1 < 0, 5)
        .when('diff_cost >= -10 and 'diff_cost < -5 and 'diff_cost1 >= -10 and 'diff_cost1 < -5, 6)
        .when('diff_cost < -5 and 'diff_cost1 >= -5 and 'diff_cost1 < 0, 7)
        .when('diff_cost < -10 and 'diff_cost1 >= -10 and 'diff_cost1 < -5, 8)
        .when('diff_cost_rate >= -0.02 and 'diff_cost_rate < 0 and 'diff_cost_rate1 >= -0.02 and 'diff_cost_rate1 < 0, 9)
        .when('diff_cost_rate >= -0.1 and 'diff_cost_rate < -0.02 and 'diff_cost_rate1 >= -0.1 and 'diff_cost_rate1 < -0.02, 10)
        .when('diff_cost_rate >= -0.2 and 'diff_cost_rate < -0.1 and 'diff_cost_rate1 >= -0.2 and 'diff_cost_rate1 < -0.1, 11)
        .when('diff_cost_rate >= -0.3 and 'diff_cost_rate < -0.2 and 'diff_cost_rate1 >= -0.3 and 'diff_cost_rate1 < -0.2, 12)
        .when('diff_cost_rate >= -0.4 and 'diff_cost_rate < -0.3 and 'diff_cost_rate1 >= -0.4 and 'diff_cost_rate1 < -0.3, 13)
        .when('diff_cost_rate < -0.4 and 'diff_cost_rate1 < -0.4, 14)
        .otherwise(15)
      )
      .withColumn("task_inc_day1",when('cost_flag >= 7 and 'cost_flag <= 13 and 'linemload_std_ontime_rate1 >= 0.9 and ('diff_time <= 10 and 'diff_time1 <= 10 and 'diff_time2 <= 10),'task_inc_day.cast(DoubleType)).otherwise(Double.MinValue))
      .withColumn("task_inc_day1",when('task_inc_day1.isNull,Double.MinValue).otherwise('task_inc_day1))
      .withColumn("repeat_flag", row_number().over(Window.partitionBy("linevehicle").orderBy(desc("task_inc_day1"))) - 1)
      .withColumn("repeat_flag",when('task_inc_day1 === Double.MinValue,999).otherwise('repeat_flag))
      .withColumn("choose_flag",when('cost_flag >= 1 and 'cost_flag <= 4, 0)
        .when('cost_flag >= 5 and 'cost_flag <= 6, 5)
        .when('cost_flag === 14, 6)
        .when('cost_flag >= 7 and 'cost_flag <= 13 and 'linemload_std_ontime_rate1 < 0.9, 2)
        .when('cost_flag >= 7 and 'cost_flag <= 13 and 'linemload_std_ontime_rate1 >= 0.9 and ('diff_time > 10 or 'diff_time1 > 10 or 'diff_time2 > 10), 3)
        .when('cost_flag >= 7 and 'cost_flag <= 13 and 'linemload_std_ontime_rate1 >= 0.9 and ('diff_time <= 10 and 'diff_time1 <= 10 and 'diff_time2 <= 10) and 'repeat_flag === 0, 1)
        .when('cost_flag >= 7 and 'cost_flag <= 13 and 'linemload_std_ontime_rate1 >= 0.9 and ('diff_time <= 10 and 'diff_time1 <= 10 and 'diff_time2 <= 10) and 'repeat_flag =!= 0, 4)
        .otherwise(999)
      )

    //(修改20231207) 2
    // 临时中间表，方便异常数据定位
    val res11_cols = spark.sql("select * from dm_gis.eta_item_before_update_new limit 0").schema.map(_.name).map(col)
    writeToHive(spark,df_all_res.withColumn("inc_day",lit(dayBefore1)).select(res11_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.eta_item_before_update_new")

    // 5.调接口更新校验数据(新方案)
    val df1 = updateTheVerificationData(spark, df_all_res, "df_all_res", dayBefore1)
    // 数据关联
    var resultNewDF = df_all_res
      .join(df1,Seq("std_id"),"left")
      .withColumn("check_flag",when('check_flag.isNull,4).otherwise('check_flag))

    // 6.向接口推送数据更新入库(新方案)
    val df2 = pushDataToInterfaceNew(spark, resultNewDF)
    resultNewDF = resultNewDF
      .join(df2,Seq("std_id","choose_source","oilConsumption"),"left")
      .withColumn("inc_day",lit(dayBefore1))

    // 4.7.2筛选结果表：dm_gis.gis_eta_vl_result_new 保存至BDP
    val res_cols = spark.sql("select * from dm_gis.gis_eta_vl_result_new limit 0").schema.map(_.name).map(col)
    writeToHive(spark,resultNewDF.select(res_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.gis_eta_vl_result_new")

    resultNewDF
  }

  /**
   * 4.使用标准新方案,筛选价值线路更新入库
   * @param spark
   * @param vmsVehicleDF 整合车参信息表DataFrame（表1）
   * @param dayBefore1
   * @param dayBefore31
   * @param month
   * @param monthBefore1
   * @return resultNewDF 标准新方案的筛选结果表DataFrame
   */
  def runStandardPlanNew(spark: SparkSession,vmsVehicleDF: DataFrame,dayBefore1: String,dayBefore31: String,month: String,monthBefore1: String) = {

    // 4.1.1获取任务数据（任务监控表）（表2）
    val lineRecallDF = getLineRecallNew(spark,dayBefore1,dayBefore31)
    // 4.1.2获取行车日志数据（行车日志表）(表3)
    val drivingLogDF = getDrivingLog(spark, month, monthBefore1)

    // 4.2数据预处理,关联、字段新增&重新赋值
    import spark.implicits._
    val lineRecallDF_filter = lineRecallDF
      .groupBy("task_area_code", "linevehicle")
      .agg(
        avg("rt_dist") / 1000 as "avg_dist",
        count("task_id") as "sum_num"
      )

    val mergeDF = lineRecallDF
      .join(lineRecallDF_filter, Seq("task_area_code", "linevehicle"), "left")  // 此处关联只是为了过滤符合条件的数据
      .join(vmsVehicleDF, Seq("vehicle_serial"), "left")
      .join(drivingLogDF, Seq("task_id"), "left")
      .filter('avg_dist>= 10.0 and 'sum_num >= 5)
      .withColumn("mload", coalesce('mload, 'actual_capacity_load))
      .withColumn("mload_1", when('mload <= 1, 1.0)
        .when('mload <= 2, 1.5)
        .when('mload <= 4, 3.0)
        .when('mload <= 6, 5.0)
        .when('mload <= 10, 7.0)
        .when('mload <= 17, 14.0)
        .when('mload <= 25, 20.0)
        .otherwise(30.0)
      )
      .withColumn("linemload",concat_ws("_",'linevehicle,'mload_1))
      .withColumn("area_linevehicle",concat_ws("_",'task_area_code,'linevehicle))
      .withColumn("area_linemload",concat_ws("_",'task_area_code,'linemload))
      .withColumn("area_linemload_std",concat_ws("_",'area_linemload,'std_id))
      .withColumn("miles_ratio",'miles / (when('rt_dist >= 'accrual_dist,'rt_dist).otherwise('accrual_dist) / 1000))
      .withColumn("road_fee_ratio",when('toll_charge <= 1, 1).otherwise('road_fee / 'toll_charge))
      .withColumn("dist_ratio1",abs(('miles - 'line_distance) / 'line_distance))
      .withColumn("dist_ratio2",abs(('rt_dist / 1000 - 'line_distance) / 'line_distance))
      .withColumn("fuel_cost",round(('unitprice / 7 * 8) * 'miles,2))
      .withColumn("cost",'fuel_cost + 'road_fee)
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 4.3异常值处理,新增异常值标记字段reject_flag
    val getMode = spark.udf.register("getMode", UDAFGetMode) // 注册UDAF函数
    val rejectFlagDF = mergeDF
      .groupBy("linemload")
      .agg(
        max('road_fee) as "road_fee_max",
        min('road_fee) as "road_fee_min",
        avg('road_fee) as "road_fee_mean",
        getMode('road_fee) as "road_fee_mode",
        stddev('road_fee) as "road_fee_std",
        getMode('road_fee_ratio) as "road_fee_ratio_mode",
        stddev('road_fee_ratio) as "road_fee_ratio_std",
        max('miles) as "miles_max",
        min('miles) as "miles_min",
        avg('miles) as "miles_mean",
        getMode('miles) as "miles_mode",
        stddev('miles) as "miles_std",
        getMode('miles_ratio) as "miles_ratio_mode",
        stddev('miles_ratio) as "miles_ratio_std"
      )
      .withColumn("road_fee_range",'road_fee_max - 'road_fee_min)
      .withColumn("miles_range",'miles_max - 'miles_min)

    val itemNewDF = mergeDF
      .join(rejectFlagDF,Seq("linemload"),"left")
      .withColumn("reject_flag", when('conduct_type === "3" and 'dist_ratio1 <= 0.05 and 'dist_ratio2 <= 0.05 and ('sim1 > 0.9 or 'sim5 > 0.9),1)
        .when('road_fee === 0 or 'road_fee.isNull, 2)
        .when(('road_fee =!= 0 and 'road_fee.isNotNull)
          and('road_fee < ('road_fee_mode - 'road_fee_std * 3) or 'road_fee > ('road_fee_mode + 'road_fee_std * 3))
          and('road_fee_ratio < ('road_fee_ratio_mode - 'road_fee_ratio_std * 3) or 'road_fee_ratio > ('road_fee_ratio_mode + 'road_fee_ratio_std * 3))
          and('road_fee_range > ('road_fee_mean * 0.1)), 3)
        .when('miles === 0 or 'miles.isNull, 4)
        .when(('miles =!= 0 and 'miles.isNotNull)
          and('miles < ('miles_mode - 'miles_std * 3) or 'miles > ('miles_mode + 'miles_std * 3))
          and('miles_ratio < ('miles_ratio_mode - 'miles_ratio_std * 3) or ('miles_ratio_mode - 'miles_ratio_std * 3) < 0 or 'miles_ratio > ('miles_ratio_mode + 'miles_ratio_std * 3))
          and('miles_range > ('miles_mean * 0.1)), 5)
        .otherwise(0)
      )
      .filter('reject_flag === 0)
      .withColumn("inc_day",lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    //(修改20231207) 1
//    // 临时中间表，方便异常数据定位
//    val item_new_xyf_tmp_cols = spark.sql("select * from dm_gis.item_new_xyf_tmp limit 0").schema.map(_.name).map(col)
//    writeToHive(spark,itemNewDF.select(item_new_xyf_tmp_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.item_new_xyf_tmp")

    // 4.7.1筛选任务明细表：dm_gis.gis_eta_vl_item_new 保存至BDP
    val res_cols = spark.sql("select * from dm_gis.gis_eta_vl_item_new limit 0").schema.map(_.name).map(col)
    writeToHive(spark,itemNewDF.select(res_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.gis_eta_vl_item_new")

    // 4.4统计成本相关项
    val resultNewDF = gisEtaVlResultNew(spark, itemNewDF, dayBefore1)
    mergeDF.unpersist()
    itemNewDF.unpersist()
  }

  /**
   *  标准旧方案筛选
   *  7.1取数 --> 标准旧方案筛选,获取任务数据（任务监控表）(表4)
   * @param spark
   * @param resultNewDF  标准新方案的筛选结果表DataFrame
   * @param dayBefore1
   * @param dayBefore31
   * @return
   */
  def getLineRecallOld(spark: SparkSession,resultNewDF: DataFrame,dayBefore1: String,dayBefore31: String) = {
    val querySql =
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  start_type,
         |  end_type,
         |  line_code,
         |  concat_ws('_', line_code, start_dept, end_dept) as line,
         |  concat_ws('_', line_code, start_dept, end_dept, vehicle_type) as linevehicle,
         |  concat_ws('_', line_code, start_dept, end_dept, vehicle_type, actual_capacity_load) as linemload,
         |  (
         |    case
         |      when actual_capacity_load < 1.5 then 0.84
         |      when actual_capacity_load >= 1.5
         |      and actual_capacity_load < 3 then 0.84
         |      when actual_capacity_load >= 3
         |      and actual_capacity_load < 5 then 0.88
         |      when actual_capacity_load >= 5
         |      and actual_capacity_load < 7 then 1.07
         |      when actual_capacity_load >= 7
         |      and actual_capacity_load < 14 then 1.36
         |      when actual_capacity_load >= 14
         |      and actual_capacity_load < 20 then 1.51
         |      when actual_capacity_load >= 20
         |      and actual_capacity_load < 30 then 1.88
         |      when actual_capacity_load >= 30 then 1.99
         |    end
         |  ) as unitprice,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  plf_flag,
         |  vehicle_type,
         |  axls_number,
         |  log_dist,
         |  duration,
         |  time,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge,
         |  error_type,
         |  pns_dist,
         |  pns_time,
         |  src,
         |  line_distance_std,
         |  line_time_std,
         |  sim1,
         |  sim5,
         |  conduct_type,
         |  is_run_ontime_std,
         |  is_run_ontime,
         |  tl_time,
         |  halfway_integrate_rate,
         |  biz_type,
         |  require_category,
         |  std_toll_charge,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  std_id,
         |  inc_day,
         |  rt_coords
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day >= '$dayBefore31' and inc_day < '$dayBefore1'
         |  and halfway_integrate_rate >= '0.9'
         |  and error_type = '0'
         |""".stripMargin

    println("标准旧方案筛选, 获取任务数据（任务监控表）的sql语句:")
    println(querySql)

    import spark.implicits._
    val lineRecallDF_old: DataFrame = spark.sql(querySql)
      .withColumn("rn",row_number().over(Window.partitionBy("task_subid").orderBy(desc("inc_day"))))
      .filter('rn === 1)
      .join(resultNewDF.drop("line_code","vehicle_type","task_area_code","std_id","inc_day","rn"),Seq("linevehicle"), "left")
      .filter(!('check_flag === "1" and 'update_res.contains("完成字段更新")) or 'check_flag.isNull or 'update_res.isNull)

    lineRecallDF_old
  }

  /**
   *   标准旧方案筛选
   *  获取标准线路配置数据（标准线路配置表）
   * @param spark
   * @param lineRecallDF_old 任务数据（任务监控表）(表4)DataFrame
   * @return
   */
  def getLineConfOld(spark: SparkSession, lineRecallDF_old: DataFrame) = {
    val querySql =
      s"""
         |select
         |  std_id,
         |  src_deptcode,
         |  dest_deptcode,
         |  line_code,
         |  plan_time,
         |  vehicle as vehicle_type,
         |  is_econ,
         |  route_index,
         |  rt_distance / 1000 as rt_distance,
         |  rt_time,
         |  line_distance,
         |  line_time,
         |  highway,
         |  tolls,
         |  tolls_distance,
         |  conf_src,
         |  concat_ws('_', line_code, src_deptcode, dest_deptcode) as line,
         |  concat_ws('_', line_code, src_deptcode, dest_deptcode, vehicle) as linevehicle
         |from
         |  dm_gis.eta_std_line_conf
         |where
         |  delete_flag = 0
         |""".stripMargin

    println("标准旧方案筛选,获取标准线路配置数据（标准线路配置表）的sql语句:")
    println(querySql)

    import spark.implicits._
    val df4 = lineRecallDF_old
      .select("linevehicle", "line_code", "end_dept", "start_dept", "vehicle_type")
      .withColumn("rn",row_number().over(Window.partitionBy("linevehicle", "line_code", "end_dept", "start_dept", "vehicle_type").orderBy(desc("linevehicle"))))
      .filter('rn === 1)
      .withColumn("src_deptcode",'start_dept)
      .withColumn("dest_deptcode",'end_dept)
      .drop("rn","start_dept","end_dept","linevehicle")

    val lineConfDF_old = spark.sql(querySql)
      .join(df4,Seq("line_code","dest_deptcode","src_deptcode","vehicle_type"),"inner")
      .withColumn("rn",row_number().over(Window.partitionBy("std_id","src_deptcode","dest_deptcode","line_code","plan_time","vehicle_type","is_econ",
        "route_index","rt_distance","rt_time","line_distance","line_time","highway","tolls","tolls_distance","conf_src","line","linevehicle").orderBy(desc("std_id"))))
      .filter('rn === 1)
      .drop("rn")

    lineConfDF_old
  }

  /**
   *   标准旧方案筛选
   *  获取pass配置表
   * @param spark
   * @param dayBefore1
   */
  def getTimesPassOld(spark: SparkSession, dayBefore1: String) = {
    val querySql =
      s"""
         |select
         |  id,
         |  load_zone_code,
         |  dest_zone_code,
         |  line_code,
         |  work_days,
         |  plan_depart_tm,
         |  revise_distance,
         |  revise_run_tm,
         |  concat_ws('_', line_code, load_zone_code, dest_zone_code) as line,
         |  inc_day
         |from
         |  dm_pass_rss.rmsa_tm_distance_times_pro
         |where
         |  inc_day = '$dayBefore1'
         |  and oper_type != 3
         |""".stripMargin

    println("标准旧方案筛选,获取pass配置表的sql语句:")
    println(querySql)
    val timesPassDF_old = spark.sql(querySql)

    timesPassDF_old
  }

  /**
   *  标准旧方案筛选
   *  标准线路关联pass配置
   * @param spark
   * @param lineConfDF_old  标准线路配置表DataFrame
   * @param timesPassDF_old  pass配置表DataFrame
   * @param dayBefore1
   * @return
   */
  def getLineConfPassOld(spark: SparkSession, lineConfDF_old: DataFrame, timesPassDF_old: DataFrame, dayBefore1: String) = {

    println("pass表的数据量:"+timesPassDF_old.count())
    println("标准线路配置表的数据量:"+lineConfDF_old.count())
    import spark.implicits._
    val passDF = timesPassDF_old
      .withColumn("rn", row_number().over(Window.partitionBy("load_zone_code", "dest_zone_code", "line_code", "plan_depart_tm", "work_days").orderBy(desc("plan_depart_tm"))))
      .filter('rn === 1)
      .drop("rn")
      .withColumn("join_flag_1",lit("flag_1"))

    println("pass表去重后的数据量:"+passDF.count())

    // 标准线路配置和pass关联
    val lineConfDF_all = lineConfDF_old
      .repartition(1000)
      .join(passDF.drop("line_code"), Seq("line"), "left")
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("标准线路配置表与pass表关联后的数据量:"+lineConfDF_all.count())

    // 情况一，关联上的数据
    val lineConfDF_1 = lineConfDF_all
      .filter('join_flag_1 === "flag_1")  // join_flag_1 === "flag_1" 表示关联上的数据
      .withColumn("pass_id", 'id)
      .withColumn("workday", 'work_days)
      .withColumn("pass_dis", 'revise_distance)
      .withColumn("pass_time", 'revise_run_tm)
      .withColumn("pass_st", lit(""))
      .select("std_id","src_deptcode","dest_deptcode","line_code","plan_time","vehicle_type","is_econ","route_index","rt_distance","rt_time","line_distance","line_time",
        "highway","tolls","tolls_distance","conf_src","line","linevehicle","pass_id","workday","pass_dis","pass_time","pass_st")

    println("情况一,关联上的数据量:"+lineConfDF_1.count())

    // pass新增t1，t2字段
    val passDF_t2 = passDF
      .filter('line_code.isNull or 'line_code === "")
      .withColumn("join_flag_2",lit("flag_2"))     // 没有关联上的数据对新增 join_flag_2 字段并赋值 flag_2
      .withColumn("t1", when('plan_depart_tm.isNotNull and 'plan_depart_tm =!= "", split('plan_depart_tm, "-")(0)).otherwise(0))
      .withColumn("t2", when('plan_depart_tm.isNotNull and 'plan_depart_tm =!= "", split('plan_depart_tm, "-")(1)).otherwise(0))
      .drop("line","line_code")

    // 没有关联上的数据结果集
    val lineConfDF_tmp = lineConfDF_all
      .filter('join_flag_1.isNull)                   // join_flag_1.isNull 表示没有关联上的数据
      .drop("id","load_zone_code","dest_zone_code","work_days","plan_depart_tm","revise_distance","revise_run_tm","inc_day","join_flag_1")

    println("没有关联上的数据量:"+lineConfDF_tmp.count())

    // 没有关联上的数据遍历passDF_t2的新结果集
    val lineConfDF_join = lineConfDF_tmp.alias("lineConfDF_tmp")
      .join(passDF_t2.alias("passDF_t2"), expr("lineConfDF_tmp.src_deptcode = passDF_t2.load_zone_code and lineConfDF_tmp.dest_deptcode = passDF_t2.dest_zone_code"), "left")

    println("遍历后的数据量:"+lineConfDF_join.count())

    // 情况二，没有关联上但是满足条件的数据
    val lineConfDF_2 = lineConfDF_join
      .filter('join_flag_2 === "flag_2" and (('t1 <= 'plan_time and 'plan_time <= 't2) or ('plan_depart_tm.isNull or 'plan_depart_tm === "")))  //join_flag_2 === "flag_2" 表示关联上的数据
      .withColumn("flag",lit(1))
      .withColumn("pass_id", 'id)
      .withColumn("workday", 'work_days)
      .withColumn("pass_dis", 'revise_distance)
      .withColumn("pass_time", 'revise_run_tm)
      .withColumn("pass_st", lit("通配"))
      .select("std_id","src_deptcode","dest_deptcode","line_code","plan_time","vehicle_type","is_econ","route_index","rt_distance","rt_time","line_distance","line_time",
        "highway","tolls","tolls_distance","conf_src","line","linevehicle","pass_id","workday","pass_dis","pass_time","pass_st","flag","t1")

    println("情况二的数据量:"+lineConfDF_2.count())

    // 情况三，没有关联上并且条件不满足的数据
    val lineConfDF_3 = lineConfDF_join
      .filter('join_flag_2.isNull or ('join_flag_2 === "flag_2" and !(('t1 <= 'plan_time and 'plan_time <= 't2) or ('plan_depart_tm.isNull or 'plan_depart_tm === ""))))
      .withColumn("flag",lit(0))
      .withColumn("pass_id", lit(""))
      .withColumn("workday", lit(""))
      .withColumn("pass_dis", lit(""))
      .withColumn("pass_time", lit(""))
      .withColumn("pass_st", lit("无配置"))
      .select("std_id","src_deptcode","dest_deptcode","line_code","plan_time","vehicle_type","is_econ","route_index","rt_distance","rt_time","line_distance","line_time",
        "highway","tolls","tolls_distance","conf_src","line","linevehicle","pass_id","workday","pass_dis","pass_time","pass_st","flag","t1")

    println("情况三的数据量:"+lineConfDF_3.count())

    // 将情况二和情况三的数据合并然后去重
    val lineConfDF_23 = lineConfDF_2
      .union(lineConfDF_3)
      .withColumn("rn", row_number().over(Window.partitionBy("std_id", "src_deptcode", "dest_deptcode", "line_code", "plan_time", "vehicle_type", "is_econ",
        "route_index", "rt_distance", "rt_time", "line_distance", "line_time", "highway", "tolls", "tolls_distance", "conf_src", "line", "linevehicle").orderBy(desc("flag"),desc("t1"))))
      .filter('rn === 1)
      .drop("flag","t1","rn")

    // 三种情况的数据合并
    val lineConfPassDF5 = lineConfDF_1.union(lineConfDF_23).toDF().coalesce(10)

    //(修改20231207) 6
    // 临时中间表，方便异常数据定位
    val pass_join_tmp_cols = spark.sql("select * from dm_gis.pass_join_detail limit 0").schema.map(_.name).map(col)
    writeToHive(spark,lineConfPassDF5.withColumn("inc_day",lit(dayBefore1)).select(pass_join_tmp_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.pass_join_detail")

    lineConfDF_all.unpersist()
  }

  /**
   * 解析QM匹配接口,获取收费字段
   * @param ret
   * @return
   */
  def parseQMData(ret: JSONObject) : (String,String,String,String,String,String) = {

    var t_status = ""
    var t_distance = ""
    var t_tolls = ""
    var t_etc_toll = ""
    var t_highspeed_distance = ""
    var t_toll_distance = ""

    if (ret != null ) {
      //获取接口返回状态
      t_status = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(t_status)) {
        logger.error("获取接口数据失败: " + ret.getString("info"))
        return (t_status,t_distance,t_tolls,t_etc_toll,t_highspeed_distance,t_toll_distance)
      } else {
        var paths = new JSONArray()
        try {
          paths = ret.getJSONObject("route").getJSONArray("paths")
          t_distance = paths.getJSONObject(0).getString("distance")
          t_tolls = paths.getJSONObject(0).getString("tolls")
          t_etc_toll = paths.getJSONObject(0).getString("etc_toll")
          t_highspeed_distance = paths.getJSONObject(0).getString("highspeed_distance")
          t_toll_distance = paths.getJSONObject(0).getString("toll_distance")
        } catch {
          case _ =>
        }
        return (t_status,t_distance,t_tolls,t_etc_toll,t_highspeed_distance,t_toll_distance)
      }
    }
    (t_status,t_distance,t_tolls,t_etc_toll,t_highspeed_distance,t_toll_distance)
  }

  /**
   * 7.2.2 调匹配接口获取收费字段
   * @param ak
   * @param obj
   * @return
   */
  def runQMInteface(ak:String, obj: JSONObject): JSONObject = {

    val test = 0
    val stype = 0
    val etype = 0
    val plate = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "")
    val Mload = JSONUtil.getJsonVal(obj, "mload", "")
    val date = ""
    val mode = 2
    val speed = 1
    val No = JSONUtil.getJsonVal(obj, "task_subid", "")
    val Toll = 1
    val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords", "")
    val points = stdCoordsToPoints(rt_coords)

    //初始化接口请求参数
    val param = s"test=$test&stype=$stype&etype=$etype&plate=$plate&vehicle=$vehicle&Mload=$Mload&date=$date&mode=$mode&speed=$speed&No=$No&Toll=$Toll&points=$points"

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_URL,param,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析接口返回值
    val httpData =  parseQMData(retJSONObject)
    obj.put("t_status",httpData._1)
    obj.put("t_distance",httpData._2)
    obj.put("t_tolls",httpData._3)
    obj.put("t_etc_toll",httpData._4)
    obj.put("t_highspeed_distance",httpData._5)
    obj.put("t_toll_distance",httpData._6)
    obj.remove("rt_coords")

    obj
  }

  /**
   * 标准线路查询接口 获取坐标串
   * @param ret
   * @return
   */
  def parseGetLineData(ret: JSONObject) : (String,String) = {

    var status = ""
    var deleteFlag = ""
    var jyTrack2 = ""

    if (ret != null ) {
      //获取接口返回状态
      status = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(status)) {
        logger.error("获取接口数据失败: " + ret.getJSONObject("result").getString("msg"))
        return (deleteFlag,jyTrack2)
      } else {
        var list = new JSONArray()
        try {
          list = ret.getJSONObject("result").getJSONArray("list")
          deleteFlag = list.getJSONObject(0).getString("deleteFlag")
          jyTrack2 = list.getJSONObject(0).getString("jyTrack2")
        } catch {
          case _ =>
        }
        return (deleteFlag,jyTrack2)
      }
    }
    (deleteFlag,jyTrack2)
  }

  /**
   * 调标准线路查询接口获取坐标串
   * @param ak
   * @param obj
   * @return
   */
  def runGetLineInteface(ak:String, obj: JSONObject): JSONObject = {

    val stdId = JSONUtil.getJsonVal(obj, "std_id", "")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("optUserId", "01369612")
    param.put("stdId", stdId)
    param.put("containDeleted", "true")
    param.put("ak", ak)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(GETLINE_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析接口返回值
    val httpData =  parseGetLineData(retJSONObject)
    obj.put("deleteFlag",httpData._1)
    obj.put("jyTrack2",httpData._2)
    obj
  }

  /**
   * 7.3.3 调匹配接口获取收费字段
   * @param ak
   * @param obj
   * @return
   */
  def runQMInteface2(ak:String, obj: JSONObject): JSONObject = {

    val test = 0
    val stype = 0
    val etype = 0
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "")
    val Mload = JSONUtil.getJsonVal(obj, "mload", "")
    val date = ""
    val mode = 2
    val speed = 1
    val No = JSONUtil.getJsonVal(obj, "linevehicle", "")
    val Toll = 1
    val points = JSONUtil.getJsonVal(obj, "jyTrack2", "")
    //val points = stdCoordsToPoints(jyTrack2)

    //初始化接口请求参数
    val param = s"test=$test&stype=$stype&etype=$etype&vehicle=$vehicle&Mload=$Mload&date=$date&mode=$mode&speed=$speed&No=$No&Toll=$Toll&points=$points"

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_URL,param,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析接口返回值
    val httpData =  parseQMData(retJSONObject)
    obj.put("t_status",httpData._1)
    obj.put("t_distance",httpData._2)
    obj.put("t_tolls",httpData._3)
    obj.put("t_etc_toll",httpData._4)
    obj.put("t_highspeed_distance",httpData._5)
    obj.put("t_toll_distance",httpData._6)

    obj
  }

  /**
   * 7.3.4 统计成本
   * @param spark
   * @param mloadTrackDF_filter
   * @param df_mload
   * @param dayBefore1
   * @return
   */
  def getDfMloadStd(spark: SparkSession, mloadTrackDF_filter: DataFrame, df_mload: DataFrame, dayBefore1: String) = {

    import spark.implicits._
    val df_mload_std = mloadTrackDF_filter
      .withColumn("linemload_std",concat_ws("_",'linemload,'std_id))
      .groupBy("linemload_std")
      .agg(
        max('std_id) as "std_id",
        max('line_code) as "line_code",
        max('src_deptcode) as "src_deptcode",
        max('dest_deptcode) as "dest_deptcode",
        max('vehicle_type) as "vehicle_type",
        max('pass_st) as "pass_st",
        max('linevehicle) as "linevehicle",
        max('is_econ) as "is_econ",
        max('route_index) as "route_index",
        max('plan_time) as "plan_time",
        max('linemload) as "linemload",
        max('rt_distance) as "rt_dist",
        max('unitprice) as "unitprice",
        avg('t_tolls) as "rt_tolls",
        max('rt_time) / 60 as "rt_time",
        max('pass_id) as "pass_id",
        max('workday) as "workday",
        max('pass_dis) / 1000 as "pass_dis",
        max('pass_time) / 60 as "pass_time",
        avg('rt_distance) as "avg_rt_dist"
      )
      .withColumn("oilConsumption",'unitprice / 7 * 100)
      .withColumn("rt_dist_cost",'rt_dist * 'unitprice / 7 * 8)
      .withColumn("rt_cost",'rt_tolls + 'rt_dist_cost)
      .withColumn("choose_source",lit("标准旧方案"))

    val df_all_old = df_mload_std
      .join(df_mload.drop("unitprice","linevehicle"),Seq("linemload"),"left")
      .withColumn("minact_dist_diffpct",('rt_dist - 'min_act_dist) / 'min_act_dist)
      .withColumn("act_dist_diff",'rt_dist - 'avg_act_dist)
      .withColumn("act_dist_diffpct",('rt_dist - 'avg_act_dist) / 'avg_act_dist)
      .withColumn("avg_rt_dist_diffpct",('rt_dist - 'avg_rt_dist) / 'avg_rt_dist)
      .withColumn("act_distcost_diff",'rt_dist_cost - 'avg_act_distcost)
      .withColumn("act_distcost_diffpct",('rt_dist_cost - 'avg_act_distcost) / 'avg_act_distcost)
      .withColumn("act_toll_diff",'rt_tolls - 'avg_act_toll)
      .withColumn("act_toll_diffpct",('rt_tolls - 'avg_act_toll) / 'avg_act_toll)
      .withColumn("act_cost_diff",'rt_cost - 'avg_act_cost)
      .withColumn("act_cost_diffpct",('rt_cost - 'avg_act_cost) / 'avg_act_cost)
      .withColumn("act_time_diff",'rt_time - 'avg_act_time)
      .withColumn("act_time_diffpct",('rt_time - 'avg_act_time) / 'avg_act_time)
      .withColumn("line_time_diff",when('pass_time.isNotNull,'rt_time - 'pass_time).otherwise('rt_time - 'avg_act_time))
      .withColumn("line_time_diffpct",when('pass_time.isNotNull,('rt_time - 'pass_time) / 'pass_time).otherwise(('rt_time - 'avg_act_time) / 'avg_act_time))
      .withColumn("toll_flag",when('rt_tolls <= 0,1)
        .when('act_toll_diff > 0,2)
        .when(abs('act_toll_diff) < 2,3)
        .when(abs('act_toll_diffpct) < 0.02,4)
        .otherwise(5)
      )
      .withColumn("dist_flag",when('minact_dist_diffpct < -0.5,1)
        .when('avg_rt_dist_diffpct < -0.3,2)
        .when('avg_rt_dist_diffpct > 0.3,3)
        .when('act_dist_diff > 0,4)
        .when(abs('act_dist_diff) < 2,5)
        .when(abs('act_dist_diffpct) < 0.01,6)
        .otherwise(7)
      )
      .withColumn("time_flag",when('line_time_diff > 10 and 'line_time_diffpct > 0.1,1)
        .when('line_time_diff > 10,2)
        .when('line_time_diff > 0 and 'act_time_diffpct < 0,3)
        .when('line_time_diff > 5 and 'line_time_diff <= 10,4)
        .when('line_time_diff > 0 and 'line_time_diff <= 5,5)
        .when('line_time_diff <= 0 and 'act_time_diffpct > 0.1,6)
        .when('line_time_diff <= 0,7)
        //        .otherwise(8)
      )
      .withColumn("cost_flag",when('act_cost_diff > 0,1)
        .when('act_cost_diff === 0,2)
        .when('act_cost_diff >= -5 and 'act_cost_diff < 0,3)
        .when('act_cost_diff >= -10 and 'act_cost_diff < -5,4)
        .when('act_cost_diffpct >= -0.02 and 'act_cost_diffpct < 0,5)
        .when('act_cost_diffpct >= -0.1 and 'act_cost_diffpct < -0.02,6)
        .when('act_cost_diffpct >= -0.2 and 'act_cost_diffpct < -0.1,7)
        .when('act_cost_diffpct >= -0.3 and 'act_cost_diffpct < -0.2,8)
        .when('act_cost_diffpct < -0.3,9)
        //        .otherwise(10)
      )
      .withColumn("is_econ1",when('cost_flag >= 5 and 'cost_flag <= 9 and 'time_flag ===7 and 'toll_flag >=2 and 'toll_flag <= 5 and 'dist_flag >= 4 and 'dist_flag <= 7,'is_econ.cast(DoubleType)).otherwise(Double.MaxValue))
      .withColumn("route_index1",when('cost_flag >= 5 and 'cost_flag <= 9 and 'time_flag ===7 and 'toll_flag >=2 and 'toll_flag <= 5 and 'dist_flag >= 4 and 'dist_flag <= 7,'route_index.cast(DoubleType)).otherwise(Double.MaxValue))
      .withColumn("plan_time1",when('cost_flag >= 5 and 'cost_flag <= 9 and 'time_flag ===7 and 'toll_flag >=2 and 'toll_flag <= 5 and 'dist_flag >= 4 and 'dist_flag <= 7,'plan_time.cast(DoubleType)).otherwise(Double.MaxValue))
      .withColumn("is_econ1",when('is_econ1.isNull,Double.MaxValue).otherwise('is_econ1))
      .withColumn("route_index1",when('route_index1.isNull,Double.MaxValue).otherwise('route_index1))
      .withColumn("plan_time1",when('plan_time1.isNull,Double.MaxValue).otherwise('plan_time1))
      .withColumn("repeat_flag",row_number().over(Window.partitionBy("linemload").orderBy(asc("is_econ1"),asc("route_index1"),asc("plan_time1"))) - 1)
      .withColumn("repeat_flag",when('is_econ1 === Double.MaxValue,999).otherwise('repeat_flag))
      .withColumn("linemload_cnt1",when('repeat_flag === 0,'linemload_cnt.cast(DoubleType)).otherwise(Double.MinValue))
      .withColumn("linemload_cnt1",when('linemload_cnt1.isNull,Double.MinValue).otherwise('linemload_cnt1))
      .withColumn("repeat_flag1",row_number().over(Window.partitionBy("linevehicle").orderBy(desc("linemload_cnt1"))) - 1)
      .withColumn("repeat_flag1",when('linemload_cnt1 === Double.MinValue,999).otherwise('repeat_flag1))
      .withColumn("choose_flag",when('cost_flag >= 1 and 'cost_flag <= 2, 0)
        .when('cost_flag >= 3 and 'cost_flag <= 4, 2)
        .when('cost_flag >= 5 and 'cost_flag <= 9 and ('time_flag =!= 7 or 'toll_flag < 2 or 'toll_flag > 5 or 'dist_flag < 4 or 'dist_flag > 7), 3)
        .when('cost_flag >= 5 and 'cost_flag <= 9 and 'time_flag === 7 and 'toll_flag >= 2 and 'toll_flag <= 5 and 'dist_flag >= 4 and 'dist_flag <= 7 and 'repeat_flag =!= 0, 4)
        .when('cost_flag >= 5 and 'cost_flag <= 9 and 'time_flag === 7 and 'toll_flag >= 2 and 'toll_flag <= 5 and 'dist_flag >= 4 and 'dist_flag <= 7 and 'repeat_flag === 0 and 'repeat_flag1 === 0, 1)
        .when('cost_flag >= 5 and 'cost_flag <= 9 and 'time_flag === 7 and 'toll_flag >= 2 and 'toll_flag <= 5 and 'dist_flag >= 4 and 'dist_flag <= 7 and 'repeat_flag === 0 and 'repeat_flag1 =!= 0, 5)
        .otherwise(999)
      )
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 调接口更新校验数据_旧方案
    val df1 = updateTheVerificationData(spark,df_all_old,"df_all_old",dayBefore1)

    // 数据关联_旧方案
    val resultOldDF = df_all_old
      .join(df1,Seq("std_id"),"left")
      .withColumn("check_flag",when('check_flag.isNull,4).otherwise('check_flag))

    // 向接口推送数据更新入库_旧方案
    val df2 = pushDataToInterfaceNew(spark, resultOldDF.filter('zy =!= "外包" and 'check_flag === 1))
    val resultOldResDF = resultOldDF
      .join(df2,Seq("std_id","choose_source","oilConsumption"),"left")
      .withColumn("inc_day",lit(dayBefore1))

    //(修改20231207) 12
//    // 临时中间表，方便异常数据定位
//    val tmp33_cols = spark.sql("""select * from dm_gis.xyf_tmp33 limit 0""").schema.map(_.name).map(col)
//    writeToHive(spark,resultOldResDF.select(tmp33_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.xyf_tmp33")

    // 7.7.2筛选结果表：dm_gis.gis_eta_vl_result_old 保存至BDP
    val res_cols = spark.sql("""select * from dm_gis.gis_eta_vl_result_old limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,resultOldResDF.select(res_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.gis_eta_vl_result_old")

    df_all_old.unpersist()
  }

  /**
   * 7.2.3 统计成本
   * @param spark
   * @param df_task_filter
   * @param lineConfPassDF5
   * @param dayBefore1
   * @return
   */
  def runStatisticalCost(spark: SparkSession,df_task_filter: DataFrame,lineConfPassDF5: DataFrame,dayBefore1: String) = {

    // 1）任务成本统计
    import spark.implicits._
    val df_task_cost = df_task_filter
      .withColumn("linemload", concat_ws("_", 'linevehicle, 'mload_1))
      .withColumn("act_dist", 'rt_dist / 1000)
      .withColumn("act_dist1", 't_distance / 1000)
      .withColumn("act_dist_cost", 'act_dist * 'unitprice / 7 * 8)
      .withColumn("act_cost", 't_tolls + 'act_dist_cost)
      .withColumn("diff_dist", abs('act_dist - 'act_dist1))
      .withColumn("diff_dist_pp", abs('act_dist - 'act_dist1) / 'act_dist)
      .withColumn("inc_day", lit(dayBefore1))
      .drop("t_distance")

    // 2）异常值剔除,数据存入hive表
    val vlItemTaskDF = df_task_cost
      .filter('diff_dist < 10 and 'diff_dist_pp < 0.1)
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 旧方案明细数据存入hive
    val res_cols = spark.sql("""select * from dm_gis.gis_eta_vl_item_task limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,vlItemTaskDF.select(res_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.gis_eta_vl_item_task")

    // 3）linevehicle维度统计
    val df_linevehicle = vlItemTaskDF
      .groupBy("linevehicle")
      .agg(
        count('task_subid) as "num1",
        count(when('carrier_type === 0, 'task_subid).otherwise(null)) as "num2"
      )
      .withColumn("zy", when('num2 / 'num1 === 1, "自营").when('num2 / 'num1 === 0, "外包").otherwise("自营|外包"))
      .drop("num1", "num2")

    // 4）linemload维度成本统计
    val getMode = spark.udf.register("getMode", UDAFGetMode)  // 注册UDAF函数
    val df_mload = vlItemTaskDF
      .groupBy("linemload")
      .agg(
        count('task_subid) as "linemload_cnt",
        max('linevehicle) as "linevehicle",
        max('task_area_code) as "task_area_code",
        max('unitprice) as "unitprice",
        max('mload) as "mload",
        max('mload_1) as "mload_1",
        min('act_dist) as "min_act_dist",
        max('act_dist) as "max_act_dist",
        avg('act_dist) as "avg_act_dist",
        min('act_dist_cost) as "min_act_distcost",
        max('act_dist_cost) as "max_act_distcost",
        avg('act_dist_cost) as "avg_act_distcost",
        min('t_tolls.cast(DoubleType)) as "min_act_toll",
        max('t_tolls.cast(DoubleType)) as "max_act_toll",
        avg('t_tolls.cast(DoubleType)) as "avg_act_toll",
        min('act_cost) as "min_act_cost",
        max('act_cost) as "max_act_cost",
        avg('act_cost) as "avg_act_cost",
        min('actual_run_time.cast(DoubleType)) as "min_act_time",
        max('actual_run_time.cast(DoubleType)) as "max_act_time",
        avg('actual_run_time.cast(DoubleType)) as "avg_act_time",
        avg('line_time.cast(DoubleType)) as "avg_line_time",
        count(when('is_run_ontime === 1,'task_subid).otherwise(null)) as "linemload_ontime_cnt",
        count(when('conduct_type === 1,'task_subid).otherwise(null)) as "linemload_exe_cnt",
        getMode(concat_ws("_",'start_longitude,'start_latitude,'end_longitude,'end_latitude)) as "xy"
      )
      .withColumn("linemload_ontime_rate",'linemload_ontime_cnt / 'linemload_cnt)
      .withColumn("linemload_exe_rate",'linemload_exe_cnt / 'linemload_cnt)
      .withColumn("x1",split('xy,"_")(0))
      .withColumn("y1",split('xy,"_")(1))
      .withColumn("x2",split('xy,"_")(2))
      .withColumn("y2",split('xy,"_")(3))
      .join(df_linevehicle,Seq("linevehicle"),"left")

    //(修改20231207) 9
    // 临时中间表，方便异常数据定位
    val df_mload_detail_cols = spark.sql("""select * from dm_gis.df_mload_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_mload.withColumn("inc_day",lit(dayBefore1)).select(df_mload_detail_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.df_mload_detail")

    //7.3.1 调标准线路查询接口获取坐标串
    var lineConfPassRDD_old: RDD[JSONObject] = lineConfPassDF5.rdd.map(row2Json)

    val invokeCnt_4 = lineConfPassRDD_old.count()
    val httpInvokeId_4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "658134", "筛选工艺流程线上化需求_旧方案部分", "获取标准线路", GETLINE_URL, GETLINE_AK, invokeCnt_4, parallelism)
    lineConfPassRDD_old = SparkNet.runInterfaceWithAkLimit(spark, lineConfPassRDD_old, runGetLineInteface, parallelism, GETLINE_AK, 6000)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_4)

    val df_line_conf_pass_track = lineConfPassRDD_old.repartition(1000).map(obj=>{
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val src_deptcode = JSONUtil.getJsonVal(obj, "src_deptcode", "")
      val dest_deptcode = JSONUtil.getJsonVal(obj, "dest_deptcode", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val is_econ = JSONUtil.getJsonVal(obj, "is_econ", "")
      val route_index = JSONUtil.getJsonVal(obj, "route_index", "")
      val rt_distance = JSONUtil.getJsonVal(obj, "rt_distance", "")
      val rt_time = JSONUtil.getJsonVal(obj, "rt_time", "")
      val line_distance = JSONUtil.getJsonVal(obj, "line_distance", "")
      val line_time = JSONUtil.getJsonVal(obj, "line_time", "")
      val highway = JSONUtil.getJsonVal(obj, "highway", "")
      val tolls = JSONUtil.getJsonVal(obj, "tolls", "")
      val tolls_distance = JSONUtil.getJsonVal(obj, "tolls_distance", "")
      val conf_src = JSONUtil.getJsonVal(obj, "conf_src", "")
      val line = JSONUtil.getJsonVal(obj, "line", "")
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
      val pass_id = JSONUtil.getJsonVal(obj, "pass_id", "")
      val workday = JSONUtil.getJsonVal(obj, "workday", "")
      val pass_dis = JSONUtil.getJsonVal(obj, "pass_dis", "")
      val pass_time = JSONUtil.getJsonVal(obj, "pass_time", "")
      val pass_st = JSONUtil.getJsonVal(obj, "pass_st", "")
      val deleteFlag = JSONUtil.getJsonVal(obj, "deleteFlag", "")
      val jyTrack2 = JSONUtil.getJsonVal(obj, "jyTrack2", "")

      LineConfPassTrack2(std_id,src_deptcode,dest_deptcode,line_code,plan_time,vehicle_type,is_econ,route_index,rt_distance,rt_time,line_distance,line_time,
        highway,tolls,tolls_distance,conf_src,line,linevehicle,pass_id,workday,pass_dis,pass_time,pass_st,deleteFlag,jyTrack2)
    }).toDF()

    // 7.3.2 数据预处理
    val df_task_cost_new = df_task_cost
      .select("linevehicle","mload","mload_1","unitprice")
      .withColumn("mload_1_num",count('mload_1).over(Window.partitionBy("linevehicle")))
      .filter('mload_1_num >= 5)
      .withColumn("rn",row_number().over(Window.partitionBy("linevehicle","mload").orderBy(desc("linevehicle"))))
      .filter('rn === 1)
    val df_mload_track = df_line_conf_pass_track
      .join(df_task_cost_new,Seq("linevehicle"),"left")
      .withColumn("linemload",concat_ws("_",'linevehicle,'mload_1))

    // 7.3.3 调匹配接口获取收费字段
    var mloadTrackRDD: RDD[JSONObject] = df_mload_track.rdd.map(row2Json)

    val invokeCnt_5 = mloadTrackRDD.count()
    val httpInvokeId_5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "658134", "筛选工艺流程线上化需求_旧方案部分", "线路匹配获取收费字段", QM_URL, QM_AK, invokeCnt_5, parallelism)
    mloadTrackRDD = SparkNet.runInterfaceWithAkLimit(spark, mloadTrackRDD, runQMInteface2, parallelism, QM_AK, 6000)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_5)

    val mloadTrackDF = mloadTrackRDD.repartition(1000).map(obj=>{
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val src_deptcode = JSONUtil.getJsonVal(obj, "src_deptcode", "")
      val dest_deptcode = JSONUtil.getJsonVal(obj, "dest_deptcode", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val is_econ = JSONUtil.getJsonVal(obj, "is_econ", "")
      val route_index = JSONUtil.getJsonVal(obj, "route_index", "")
      val rt_distance = JSONUtil.getJsonVal(obj, "rt_distance", "")
      val rt_time = JSONUtil.getJsonVal(obj, "rt_time", "")
      val line_distance = JSONUtil.getJsonVal(obj, "line_distance", "")
      val line_time = JSONUtil.getJsonVal(obj, "line_time", "")
      val highway = JSONUtil.getJsonVal(obj, "highway", "")
      val tolls = JSONUtil.getJsonVal(obj, "tolls", "")
      val tolls_distance = JSONUtil.getJsonVal(obj, "tolls_distance", "")
      val conf_src = JSONUtil.getJsonVal(obj, "conf_src", "")
      val line = JSONUtil.getJsonVal(obj, "line", "")
      val pass_id = JSONUtil.getJsonVal(obj, "pass_id", "")
      val workday = JSONUtil.getJsonVal(obj, "workday", "")
      val pass_dis = JSONUtil.getJsonVal(obj, "pass_dis", "")
      val pass_time = JSONUtil.getJsonVal(obj, "pass_time", "")
      val pass_st = JSONUtil.getJsonVal(obj, "pass_st", "")
      val deleteFlag = JSONUtil.getJsonVal(obj, "deleteFlag", "")
      val jyTrack2 = JSONUtil.getJsonVal(obj, "jyTrack2", "")
      val mload = JSONUtil.getJsonVal(obj, "mload", "")
      val mload_1 = JSONUtil.getJsonVal(obj, "mload_1", "")
      val unitprice = JSONUtil.getJsonVal(obj, "unitprice", "")
      val mload_1_num = JSONUtil.getJsonVal(obj, "mload_1_num", "")
      val linemload = JSONUtil.getJsonVal(obj, "linemload", "")
      val t_status = JSONUtil.getJsonVal(obj, "t_status", "")
      val t_highspeed_distance = JSONUtil.getJsonVal(obj, "t_highspeed_distance", "")
      val t_tolls = JSONUtil.getJsonVal(obj, "t_tolls", "")
      val t_etc_toll = JSONUtil.getJsonVal(obj, "t_etc_toll", "")
      val t_toll_distance = JSONUtil.getJsonVal(obj, "t_toll_distance", "")
      val t_distance = JSONUtil.getJsonVal(obj, "t_distance", "")
      val param = JSONUtil.getJsonVal(obj, "param", "")

      MloadTrack(linevehicle,std_id,src_deptcode,dest_deptcode,line_code,plan_time,vehicle_type,is_econ,route_index,rt_distance,rt_time,line_distance,line_time,
        highway,tolls,tolls_distance,conf_src,line,pass_id,workday,pass_dis,pass_time,pass_st,deleteFlag,jyTrack2,mload,mload_1,unitprice,mload_1_num,linemload,
        t_status,t_highspeed_distance,t_tolls,t_etc_toll,t_toll_distance,t_distance,param)
    }).toDF()

    // 过滤掉接口返回异常的结果,保留条件：t_status=0 and t_tolls>0 或者  t_status=0 and t_tolls=0 and t_highspeed_distance=0 and t_toll_distance=0
    val mloadTrackDF_filter= mloadTrackDF
      .filter(('t_status === 0 and 't_tolls > 0)
        ||  ('t_status===0 and 't_tolls===0 and 't_highspeed_distance===0 and 't_toll_distance===0)
      ).coalesce(100)

    //(修改20231207) 10
    // 临时中间表，方便异常数据定位
    val mload_track_filter_cols = spark.sql("""select * from dm_gis.mload_track_filter_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,mloadTrackDF_filter.withColumn("inc_day",lit(dayBefore1)).select(mload_track_filter_cols: _*).coalesce(50),Seq("inc_day"),"dm_gis.mload_track_filter_detail")

    // (修改20231207) 11 拆任务
//    // 7.3.4 统计成本
//    getDfMloadStd(spark,mloadTrackDF_filter,df_mload,dayBefore1)

    vlItemTaskDF.unpersist()
  }

  /**
   * 7.使用标准旧方案筛选,筛选价值线路更新入库
   * @param spark
   * @param resultNewDF  标准新方案的筛选结果表DataFrame
   * @param vmsVehicleDF 获取整合车参信息（表1）DataFrame
   * @param dayBefore1
   * @param dayBefore31
   */
  def runStandardPlanOld(spark: SparkSession, dayBefore1: String) = {

    import spark.implicits._
    val task_sql =
      s"""
      |select
      |  vehicle_serial,
      |  vehicle_type,
      |  mload,
      |  task_subid,
      |  rt_coords,
      |  actual_arrive_tm
      |from
      |  dm_gis.dm_line_task_mload_di
      |where
      |  inc_day = '$dayBefore1'
      |""".stripMargin
    println(task_sql)

    var df_taskRDD = spark.sql(task_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_subid).orderBy(desc("actual_arrive_tm"))))
      .filter('rn === 1) // 按 task_id 去重
      .rdd.map(row2Json)

    // 7.2.2 调匹配接口获取收费字段
    val invokeCnt_6 = df_taskRDD.count()
    val httpInvokeId_6 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "658134", "筛选工艺流程线上化需求_旧方案部分", "线路匹配获取收费字段", QM_URL, QM_AK, invokeCnt_6, parallelism)
    df_taskRDD = SparkNet.runInterfaceWithAkLimit(spark, df_taskRDD, runQMInteface, parallelism, QM_AK, 6000)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_6)

    val df_task_new = df_taskRDD.repartition(100).map(obj => {
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val mload = JSONUtil.getJsonVal(obj, "mload", "")
      val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")

      val t_status = JSONUtil.getJsonVal(obj, "t_status", "")
      val t_highspeed_distance = JSONUtil.getJsonVal(obj, "t_highspeed_distance", "")
      val t_tolls = JSONUtil.getJsonVal(obj, "t_tolls", "")
      val t_etc_toll = JSONUtil.getJsonVal(obj, "t_etc_toll", "")
      val t_toll_distance = JSONUtil.getJsonVal(obj, "t_toll_distance", "")
      val t_distance = JSONUtil.getJsonVal(obj, "t_distance", "")

      (task_subid,vehicle_serial,vehicle_type,mload,t_status,t_highspeed_distance,t_tolls,t_etc_toll,t_toll_distance,t_distance)
    }).toDF("task_subid","vehicle_serial","vehicle_type","mload","t_status","t_highspeed_distance","t_tolls","t_etc_toll","t_toll_distance","t_distance")

    // 过滤掉接口返回异常的结果,保留条件：t_status=0 and t_tolls>0 或者  t_status=0 and t_tolls=0 and t_highspeed_distance=0 and t_toll_distance=0
    val df_task_filter= df_task_new.filter(('t_status === 0 and 't_tolls > 0)
      ||  ('t_status===0 and 't_tolls===0 and 't_highspeed_distance===0 and 't_toll_distance===0)
    ).coalesce(10)

    //(修改20231207) 7
    // 临时中间表，方便异常数据定位
    val cols_1 = spark.sql("""select * from dm_gis.dm_task_filter_detail_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_task_filter.withColumn("inc_day",lit(dayBefore1)).select(cols_1: _*).coalesce(50),Seq("inc_day"),"dm_gis.dm_task_filter_detail_di")

    //(修改20231207) 8 拆任务
//    // 7.2.3 统计成本
//    runStatisticalCost(spark,df_task_filter,lineConfPassDF5,dayBefore1)

  }

}
