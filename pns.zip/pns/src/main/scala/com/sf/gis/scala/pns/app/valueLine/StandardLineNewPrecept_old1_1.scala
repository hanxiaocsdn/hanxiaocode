package com.sf.gis.scala.pns.app.valueLine

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.pns.app.valueLine.StandardLineNewPrecept._
import org.apache.log4j.Logger

/**
 * GIS-RSS-PNS：【价值线路】筛选工艺流程线上化需求——旧方案
 * 需求方：刘俊荣（ft80006349）
 * @author 徐游飞（01417347）
 * 任务ID：926787
 * 任务名称：筛选工艺流程线上化_旧方案部分—1_1
 */
object StandardLineNewPrecept_old1_1 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val dayBefore1 = args(0)
    val dayBefore31 = args(1)
    val month = args(2)
    val monthBefore1 = args(3)
    //日期检查
    logger.error("DayBefore1="+dayBefore1)
    logger.error("dayBefore31="+dayBefore31)
    logger.error("month="+month)
    logger.error("monthBefore1="+monthBefore1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231207 ++++")
    // 获取新方案结果数据,过滤调已推送的价值线路
    val resultNewDF = spark.sql(s"select * from dm_gis.gis_eta_vl_result_new where inc_day = '$dayBefore1'")
    // 7.1取数 --> 标准旧方案筛选,获取任务数据（任务监控表）(表4)
    val lineRecallDF_old = getLineRecallOld(spark,resultNewDF,dayBefore1,dayBefore31)
    // 7.1取数 --> 获取标准线路配置数据（标准线路配置表）
    val lineConfDF_old = getLineConfOld(spark,lineRecallDF_old)
    // 7.1取数 --> 获取pass配置表
    val timesPassDF_old = getTimesPassOld(spark,dayBefore1)
    // 3.获取整合车参信息（表1）
    val vmsVehicleDF = getVmsVehicle(spark, dayBefore1)

    // 7.使用标准旧方案筛选,标准线路关联pass配置
    getLineConfPassOld(spark,lineConfDF_old,timesPassDF_old,dayBefore1)

    logger.error("++++++++  任务结束  ++++")
    spark.stop()
  }
}
