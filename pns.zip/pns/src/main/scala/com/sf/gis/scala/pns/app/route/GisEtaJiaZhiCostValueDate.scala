package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

/**
 * GIS-RDS-PNS 价值线路指标监控需求V1.5
 * 需求方：刘思嘉（01420030）
 * @author 徐游飞（01417347）
 * 任务ID：684163
 * 任务名称：价值线路结果表3关联配置表
 */
object GisEtaJiaZhiCostValueDate {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  // 结果表3关联配置表获取 value_date
  def getValueDate(spark: SparkSession,incDay: String) = {
    import spark.implicits._
    val df_table3 = spark.sql(s"select * from dm_gis.gis_eta_jiazhi_cost where inc_day = '$incDay'")
    val df_conf = spark.sql("select std_id as si,value_time as value_date from dm_gis.eta_std_line_prop")

    val df_source = df_table3
      .withColumn("si", explode(split('std_id, "\\|")))
      .join(df_conf, Seq("si"), "left")
      .groupBy("std_id")
      .agg(
        min('value_date) as "value_date"
      )

    val df_ret = df_table3.join(df_source, Seq("std_id"), "left")

    println("df_table3 数据量："+df_table3.count())
    println("df_ret 数据量："+df_ret.count())

    // 结果表3关联配置表获取 value_date 后临时表
    val cols = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_value_date limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols: _*),Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_value_date")

  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始--1  ++++")

    // 结果表3关联配置表获取 value_date
    getValueDate(spark,incDay)

    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}