package com.sf.gis.scala.pns.utils

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-03-07 15:33
 * @TaskId:
 * @TaskName:
 * @Description:移植工具类
 */
object HttpUtil {
  def tryPostWithDetail(url:String,para:String,tryTimes:Int,currentTrys:Int=0,msgLength:Int= -1):(String,String,String,String) = {
    // --jars httpclient-4.5.3.jar
    var result:(String,String,String,String) = null
    var ret:String = null
    var err:String = null
    try{
      ret = HttpRequest.sendPost(url,para)
      (url,para,ret,err)
    }catch{
      case e:Exception=>{
        if(msgLength== -1)
          System.err.println("++++++++++++++++++++++++++++++++\n"+para)
        else if(msgLength>0){
          System.err.println("--------------------------------"+(para.substring(0,Math.min(para.length,msgLength))))
        }
        err = "e.getMessage:\n"+e.getMessage+"\n"
        if(currentTrys<tryTimes){
          //System.err.println("retry waiting seconds: "+(currentTrys+1))
          Thread.sleep((currentTrys+1)*500)
          result = tryPostWithDetail(url,para,tryTimes,currentTrys+1,msgLength)
        }else{
          result = (url,para,ret,err)
        }
        result
      }
    }
  }

}
