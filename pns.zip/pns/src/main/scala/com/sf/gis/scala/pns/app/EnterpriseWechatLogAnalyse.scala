package com.sf.gis.scala.pns.app

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.base.util.DateUtil.dateToStamp
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}
import scala.util.control.Breaks.{break, breakable}


/**
 * GIS-LSS-MMS：【安全护航项目】企微群聊天记录表
 * 需求方：黄晓冰（01422522）
 * @author 徐游飞（01417347）
 * 任务ID：956246
 * 任务名称：企微记录分析表
 */
object EnterpriseWechatLogAnalyse {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error(s"++++++++  任务开始 inc_day=$inc_day ++++")
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore7 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 7)

    val dateToStamp_udf = udf(dateToStamp _)
    val getDayBefore_udf = udf(getDateStr _)
    import spark.implicits._
    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.ods_smart_service_enterprise_wechat_log
         |where
         |  inc_day >= '$dayBefore7'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println(sql)
    val df_ret: DataFrame = spark.sql(sql)
      .withColumn("day2",getDayBefore_udf('inc_day,lit(1)))
      .withColumn("day3",getDayBefore_udf('inc_day,lit(2)))
      .withColumn("day",when('inc_day <= 'day3,'inc_day))
      .withColumn("time_timestamp", dateToStamp_udf('time, lit("yyyy-MM-dd HH:mm:ss")))
      .withColumn("is_timeliness", when('group_name.contains("时效") || 'group_name.contains("SFTOB"), "是").otherwise("否"))
      .withColumn("week", getWeek_udf('time, lit("yyyy-MM-dd HH:mm:ss")))
      .withColumn("hour", 'time.substr(12, 2).cast("int"))
      .withColumn("is_workday", when('week =!= "周日" && (('hour >= 9 and 'hour < 12) or ('hour >= 13 and 'hour < 18)), "是").otherwise("否"))
      //null值处理
      .withColumn("role", when('role.isNull, "").otherwise('role))
      .withColumn("name", when('name.isNull, "").otherwise('name))
      .withColumn("time_timestamp", when('time_timestamp.isNull, "").otherwise('time_timestamp))
      .withColumn("message_list", concat_ws("|", collect_list(concat_ws("_", 'role, 'name, 'time_timestamp)).over(Window.partitionBy("group_name"))))
      .withColumn("answerer_name", get_answerer_udf('role, 'time_timestamp, 'message_list, lit("name")))
      .withColumn("answerer_time_diff", get_answerer_udf('role, 'time_timestamp, 'message_list, lit("time_diff")))
      .withColumn("answerer_time", get_answerer_udf('role, 'time_timestamp, 'message_list, lit("time")))
      .withColumn("is_timely", get_timely_udf('role, 'week, 'time, 'is_workday, 'answerer_time,'answerer_time_diff))
      .withColumn("problem_label", when(('role === "运营客服" || 'role === "客服") && ('text.contains("】已解决") || 'text.contains("】已反馈")), regexp_extract('text, "【(.*?)】", 1)).otherwise(""))
      .withColumn("solve_label", when(('role === "运营客服" || 'role === "客服") && 'text.contains("】已解决"), "已解决")
        .when(('role === "运营客服" || 'role === "客服") && 'text.contains("】已反馈"), "已反馈")
        .otherwise(""))
      .withColumn("feedback_id", when(('role === "运营客服" || 'role === "客服") && 'solve_label === "已反馈", regexp_extract('text, "运营工单(\\d{13})", 1)).otherwise(""))

    // 结果表保存至hive
    val cols_dtl = spark.sql("""select * from dm_gis.dm_enterprise_wechat_log_analyse_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_dtl: _*),Seq("inc_day"),"dm_gis.dm_enterprise_wechat_log_analyse_di")

    logger.error("++++++++  任务完成  ++++")
    spark.stop()
  }

  def getDateStr(inputDateStr: String, num: Int): String = {
    val dateStrFormat = "yyyyMMdd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    var inputDate: Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

  /**
   * @return 返回用户发言时间后，相应是否及时标签
   */
  def get_timely(role: String, week: String, time: String, is_workday: String, answerer_time: String, time_diff: String) = {
    var ret = "否"
    if (role.equals("用户") && answerer_time != "" && time_diff != "") {
      try {
        val diff = time_diff.toInt
        val hour = time.substring(11, 13).toInt
        val answerer_hour = answerer_time.substring(11, 13).toInt
        // 工作日
        if (is_workday.equals("是")) {
          if (((hour >= 9 && hour <= 10) || (hour >= 13 && hour <= 16)) && diff <= 3600) ret = "是"
        }
        // 周日
        if (week.equals("周日")) {
          val time_1 = DateUtil.getDayBefore(time, "yyyy-MM-dd HH:mm:ss", -1)
          if (time.substring(0, 10) == answerer_time.substring(0, 10)) ret = "是"
          if (time_1.substring(0, 10) == answerer_time.substring(0, 10) && answerer_hour < 10) ret = "是"
        } else {
          // 周六 17点后
          if (week.equals("周六") && hour >= 17) {
            val time_1 = DateUtil.getDayBefore(time, "yyyy-MM-dd HH:mm:ss", -1)
            val time_2 = DateUtil.getDayBefore(time, "yyyy-MM-dd HH:mm:ss", -2)
            if (time.substring(0, 10) == answerer_time.substring(0, 10)) ret = "是"
            if (time_1.substring(0, 10) == answerer_time.substring(0, 10)) ret = "是"
            if (time_2.substring(0, 10) == answerer_time.substring(0, 10) && answerer_hour < 10) ret = "是"
          }
          // 周一至周六 9点前
          if (hour < 9 && answerer_hour <= 10) ret = "是"
          // 周一至周六 11-12 点
          if (hour >= 11 && hour <= 12 && diff <= 7200) ret = "是"
          // 周一至周五 17点后
          if (!week.equals("周六") && hour >= 17) {
            val time_1 = DateUtil.getDayBefore(time, "yyyy-MM-dd HH:mm:ss", -1)
            if (time.substring(0, 10) == answerer_time.substring(0, 10)) ret = "是"
            if (time_1.substring(0, 10) == answerer_time.substring(0, 10) && answerer_hour < 10) ret = "是"
          }
        }
      } catch {
        case e: Exception => logger.error("数据转换异常" + e.getMessage)
      }
    } else {
      ret = ""
    }

    ret
  }
  val get_timely_udf = udf(get_timely _)

  /**
   * @return 返回用户发言时间后第一个回复的客服信息
   */
  def get_answerer(role: String, time: String, message_list: String, flag: String) = {
    var ret = ""
    if (role.equals("用户")) {
      try {
        val message_arr = message_list.split("\\|").sortBy(_.split("_")(2))
        breakable {
          for (i <- 0 until message_arr.size) {
            val tmp_arr = message_arr(i).split("_")
            val role2 = tmp_arr(0)
            val name2 = tmp_arr(1)
            val time2 = tmp_arr(2)

            if(time2 > time && !role2.equals("用户")){
              if (!role2.equals("运营客服") && !role2.equals("客服")) {
                ret = ""
                break
              }
              if (role2.equals("运营客服") || role2.equals("客服")) {
                if (flag.equals("name")) {
                  ret = name2
                } else if (flag.equals("time_diff")) {
                  ret = ((time2.toLong - time.toLong) / 1000).toString
                } else if (flag.equals("time")) {
                  val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                  ret = sdf.format(new Date(time2.toLong))
                }
                break
              }
            }
          }
        }
      } catch {
        case e: Exception => logger.error("数据为空异常" + e.getMessage)
      }
    }

    ret
  }
  val get_answerer_udf = udf(get_answerer _)

  /**
   * @param date   日期
   * @param format 字符串类型
   * @return 返回对应当天星期日 一 二 三 四 五 六
   */
  def getWeek(date: String, format: String) = {
    val sdf = new SimpleDateFormat(format)
    var inputDate: Date = sdf.parse(date)
    val weeks = Array("周日", "周一", "周二", "周三", "周四", "周五", "周六")
    val cal = Calendar.getInstance()
    cal.setTime(inputDate)
    var week_index = cal.get(Calendar.DAY_OF_WEEK) - 1
    if (week_index < 0) {
      week_index = 0
    }
    weeks(week_index)
  }
  val getWeek_udf = udf(getWeek _)

}
