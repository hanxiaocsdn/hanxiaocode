package com.sf.gis.scala.pns.app.valueLine

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.pns.app.valueLine.StandardLineNewPrecept.runStandardPlanOld
import org.apache.log4j.Logger

/**
 * GIS-RSS-PNS：【价值线路】筛选工艺流程线上化需求——旧方案
 * 需求方：刘俊荣（ft80006349）
 * @author 徐游飞（01417347）
 * 任务ID：926790
 * 任务名称：筛选工艺流程线上化_旧方案部分—2
 */
object StandardLineNewPrecept_old2 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val dayBefore1 = args(0)
    val dayBefore31 = args(1)
    val month = args(2)
    val monthBefore1 = args(3)
    //日期检查
    logger.error("DayBefore1="+dayBefore1)
    logger.error("dayBefore31="+dayBefore31)
    logger.error("month="+month)
    logger.error("monthBefore1="+monthBefore1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231226 ++++")

    // 7.使用标准旧方案筛选,过滤掉线路匹配接口返回收费字段异常数据
    runStandardPlanOld(spark,dayBefore1)

    logger.error("++++++++  任务结束  ++++")
    spark.stop()
  }
}
