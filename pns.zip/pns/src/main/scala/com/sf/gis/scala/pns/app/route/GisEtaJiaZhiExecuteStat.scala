package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.SparkUtil
import org.apache.commons.lang3.StringUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.mutable

class GisEtaJiaZhiExecuteStat {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

    /**
     * dm_gis.gis_eta_jiazhi_task取数
     * @param spark SparkSession
     * @param incDay incDay
     * @return
     */
    def gis_eta_jiazhi_task(spark: SparkSession, incDay: String): DataFrame = {
        val sql =
            s"""
               |select
               |    task_area_code,
               |    carrier_name,
               |    line_code,
               |    case when add_reason regexp '融合' then '融合'
               |         when add_reason regexp '新方案' then '标准新方案'
               |         else '标准' end as source,
               |    case carrier_type
               |         when '0' then '自营'
               |         when '1' then '外包'
               |         else "" end as carrier_type,
               |    date_format(std_id_jz_time, 'yyyyMMdd') as online_date,
               |    task_subid,
               |    exe_reject_flag,
               |    std_id_jz,
               |    std_id,
               |    conduct_type,
               |    is_run_ontime,
               |    error_type
               |from dm_gis.gis_eta_jiazhi_task
               |where inc_day = '$incDay'
               |    and inc_day >= date_format(std_id_jz_time, 'yyyyMMdd')
               |    and linevehicle_jz = linevehicle
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 分组计算
     * @param spark SparkSession
     * @param incDay incDay
     */
    def group_calculate(spark: SparkSession, incDay: String): RDD[(String, String, String, String, String, String, Int, Int, Int, Int, Int, Int, Int, Int, Int, Int)] = {
        val rdd = gis_eta_jiazhi_task(spark, incDay).rdd
        LOGGER.info("数据源转RDD")
        rdd
            .map(x => {
                val task_area_code = if (x.isNullAt(0)) "" else x.getString(0)
                val carrier_name = if (x.isNullAt(1)) "" else x.getString(1)
                val line_code = if (x.isNullAt(2)) "" else x.getString(2)
                val source = if (x.isNullAt(3)) "" else x.getString(3)
                val carrier_type = if (x.isNullAt(4)) "" else x.getString(4)
                val online_date = if (x.isNullAt(5)) "" else x.getString(5)
                val task_subid = if (x.isNullAt(6)) "" else x.getString(6)
                val exe_reject_flag = if (x.isNullAt(7)) "" else x.getString(7)
                val std_id_jz = if (x.isNullAt(8)) "" else x.getString(8)
                val std_id = if (x.isNullAt(9)) "" else x.getString(9)
                val conduct_type = if (x.isNullAt(10)) "" else x.getString(10)
                val is_run_ontime = if (x.isNullAt(11)) "" else x.getString(11)
                val error_type = if (x.isNullAt(12)) "" else x.getString(12)
                (task_area_code, carrier_name, line_code, source, carrier_type, online_date, task_subid,
                    exe_reject_flag, std_id_jz, std_id, conduct_type, is_run_ontime, error_type)
            })
            .groupBy(x => (x._1, x._2, x._3, x._4, x._5, x._6))
            .map(x => {
                val task_area_code = x._1._1
                val carrier_name = x._1._2
                val line_code = x._1._3
                val source = x._1._4
                val carrier_type = x._1._5
                val online_date = x._1._6
                val set1 = new mutable.HashSet[String]()
                val set2 = new mutable.HashSet[String]()
                val set3 = new mutable.HashSet[String]()
                val set4 = new mutable.HashSet[String]()
                val set5 = new mutable.HashSet[String]()
                val set6 = new mutable.HashSet[String]()
                val set7 = new mutable.HashSet[String]()
                val set8 = new mutable.HashSet[String]()
                val set9 = new mutable.HashSet[String]()
                val set10 = new mutable.HashSet[String]()
                for (data <- x._2) {
                    set1.add(data._7)
                    if (!"0".equals(data._13)) {
                        set2.add(data._7)
                    }
                    if (!"0".equals(data._8)) {
                        set3.add(data._7)
                    }
                    if (data._9.equals(data._10)) {
                        set4.add(data._7)
                    }
                    if (data._9.equals(data._10) && "0".equals(data._13) && "0".equals(data._8)) {
                        set5.add(data._7)
                    }
                    if (data._9.equals(data._10) && "1".equals(data._11) &&
                        "0".equals(data._13) && "0".equals(data._8)) {
                        set6.add(data._7)
                    }
                    if (data._9.equals(data._10) && "3".equals(data._11) &&
                        "0".equals(data._13) && "0".equals(data._8)) {
                        set7.add(data._7)
                    }
                    if ("1".equals(data._12)) {
                        set8.add(data._7)
                    }
                    if (data._9.equals(data._10) && "1".equals(data._11) &&
                        "0".equals(data._13) && "0".equals(data._8) && "1".equals(data._12)) {
                        set9.add(data._7)
                    }
                    if (data._9.equals(data._10) && "3".equals(data._11) &&
                        "0".equals(data._13) && "0".equals(data._8) && "1".equals(data._12)) {
                        set10.add(data._7)
                    }
                }
                val num = set1.size
                val err_num = set2.size
                val reject_num = set3.size
                val econ0_num = set4.size
                val valid_econ0_num = set5.size
                val exe_num = set6.size
                val unexe_num = set7.size
                val ontime_num = set8.size
                val exe_ontime_num = set9.size
                val unexe_ontime_num = set10.size
                (task_area_code, carrier_name, line_code, source, carrier_type, online_date,
                    num, err_num, reject_num, econ0_num, valid_econ0_num,
                    exe_num, unexe_num, ontime_num, exe_ontime_num, unexe_ontime_num)
            })
    }

    def gis_eta_jiazhi_execute_stat(spark: SparkSession, incDay: String): Unit = {
        import spark.implicits._
        val frame = group_calculate(spark, incDay).toDF("task_area_code", "carrier_name",
            "line_code", "source", "carrier_type", "online_date", "num", "err_num", "reject_num",
            "econ0_num", "valid_econ0_num", "exe_num", "unexe_num", "ontime_num", "exe_ontime_num",
            "unexe_ontime_num")
        LOGGER.info("rdd转DataFrame")
        frame.createOrReplaceTempView("t1")

        val sql =
            s"""
               |insert overwrite table dm_gis.gis_eta_jiazhi_execute_stat partition (inc_day = '$incDay')
               |select
               |    *,
               |    (exe_ontime_rate - unexe_ontime_rate) as diff_ontime
               |from
               |(
               |    select
               |        *,
               |        econ0_num / num              as econ0_rate,
               |        exe_num / valid_econ0_num    as exe_rate,
               |        ontime_num / num             as ontime_rate,
               |        exe_ontime_num / exe_num     as exe_ontime_rate,
               |        unexe_ontime_num / unexe_num as unexe_ontime_rate
               |    from t1
               |) t
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
        LOGGER.info("数据插入完成")
    }

    def execute(spark: SparkSession, incDay: String): Unit = {
        gis_eta_jiazhi_execute_stat(spark, incDay)
    }
}

object GisEtaJiaZhiExecuteStat {
    def main(args: Array[String]): Unit = {
        val task = new GisEtaJiaZhiExecuteStat
        if (args == null || args.length != 1 || StringUtils.isEmpty(args(0))) {
            task.LOGGER.error("请传入参数")
            return
        }
        val incDay = args(0)
        task.LOGGER.info("#########################################")
        task.LOGGER.info("inc_day: [{}]", incDay)
        task.LOGGER.info("#########################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession
        task.execute(spark, incDay)
        task.LOGGER.info("任务执行完成")
    }
}
